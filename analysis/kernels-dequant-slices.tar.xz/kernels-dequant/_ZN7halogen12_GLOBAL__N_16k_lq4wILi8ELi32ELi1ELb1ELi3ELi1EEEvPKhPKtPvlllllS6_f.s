0000000000869500 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[8:23], s[0:1], null                          // 000000869500: F4100200 F8000000
	s_ashr_i32 s3, s2, 31                                      // 000000869508: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 00000086950C: 32040082
	s_lshl_b64 s[2:3], s[2:3], 3                               // 000000869510: 84828302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000869514: BF8701A9
	v_dual_mov_b32 v24, s3 :: v_dual_and_b32 v1, 15, v0        // 000000869518: CA240003 1800008F
	v_and_b32_e32 v30, 31, v0                                  // 000000869520: 363C009F
	v_and_b32_e32 v2, 60, v2                                   // 000000869524: 360404BC
	v_lshlrev_b32_e32 v7, 2, v0                                // 000000869528: 300E0082
	s_delay_alu instid0(VALU_DEP_4)                            // 00000086952C: BF870004
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000869530: 30020282
	.long 0x7f0c3880                                           // 000000869534: 7F0C3880
	s_waitcnt lgkmcnt(0)                                       // 000000869538: BF89FC07
	s_clause 0x1                                               // 00000086953C: BF850001
	global_load_b32 v3, v1, s[8:9]                             // 000000869540: DC520000 03080001
	global_load_b32 v4, v2, s[8:9]                             // 000000869548: DC520000 04080002
	v_lshrrev_b32_e32 v1, 5, v0                                // 000000869550: 32020085
	s_add_u32 s24, s8, s20                                     // 000000869554: 80181408
	s_addc_u32 s25, s9, s21                                    // 000000869558: 82191509
	s_ashr_i32 s4, s15, 31                                     // 00000086955C: 86049F0F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000869560: BF8704A1
	v_or_b32_e32 v23, s2, v1                                   // 000000869564: 382E0202
	s_lshr_b32 s4, s4, 27                                      // 000000869568: 85049B04
	s_add_u32 s4, s14, s4                                      // 00000086956C: 8004040E
	s_addc_u32 s5, s15, 0                                      // 000000869570: 8205800F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000869574: BF8704A1
	.long 0xd4540002                                           // 000000869578: D4540002
	v_cndmask_b32_e32 v1, s16, v23, vcc_lo                     // 00000086957C: 02022E10
	s_lshr_b64 s[6:7], s[4:5], 5                               // 000000869580: 85868504
	s_cmpk_lt_i32 s6, 0x101                                    // 000000869584: B3860101
	.long 0xd4440004                                           // 000000869588: D4440004
	v_cndmask_b32_e32 v1, s6, v30, vcc_lo                      // 00000086958C: 02023C06
	v_cndmask_b32_e64 v2, 0, v23, s2                           // 000000869590: D5010002 000A2E80
	v_cndmask_b32_e64 v5, 0, s3, s2                            // 000000869598: D5010005 00080680
	s_cselect_b32 s3, -1, 0                                    // 0000008695A0: 980380C1
	s_cmpk_gt_i32 s6, 0x100                                    // 0000008695A4: B2860100
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000008695A8: BF8704B2
	.long 0xd72c0008                                           // 0000008695AC: D72C0008
	v_cndmask_b32_e32 v1, s23, v2, vcc_lo                      // 0000008695B0: 02020417
	v_mad_u64_u32 v[0:1], null, s22, v2, 0                     // 0000008695B4: D6FE7C00 02020416
	s_cselect_b32 s7, -1, 0                                    // 0000008695BC: 980780C1
	s_and_b32 vcc_lo, exec_lo, s7                              // 0000008695C0: 8B6A077E
	s_waitcnt vmcnt(1)                                         // 0000008695C4: BF8907F7
	v_bfe_u32 v9, v3, 16, 1                                    // 0000008695C8: D6100009 02052103
	s_waitcnt vmcnt(0)                                         // 0000008695D0: BF8903F7
	v_bfe_u32 v10, v4, 16, 1                                   // 0000008695D4: D610000A 02052104
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008695DC: BF8701A2
	v_add3_u32 v3, v3, v9, 0x7fff                              // 0000008695E0: D6550003 03FE1303 00007FFF
	.long 0xd72c0009                                           // 0000008695EC: D72C0009
	v_cndmask_b32_e32 v1, s22, v5, vcc_lo                      // 0000008695F0: 02020A16
	v_add3_u32 v4, v4, v10, 0x7fff                             // 0000008695F4: D6550004 03FE1504 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000869600: BF870223
	.long 0x7e0c3983                                           // 000000869604: 7E0C3983
	.long 0xd7000503                                           // 000000869608: D7000503
	v_cndmask_b32_e32 v1, s24, v0, vcc_lo                      // 00000086960C: 02020018
	v_add3_u32 v1, v1, v9, v8                                  // 000000869610: D6550001 04221301
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000869618: BF870113
	v_and_or_b32 v6, 0xffff0000, v4, v6                        // 00000086961C: D6570006 041A08FF FFFF0000
	v_add_co_ci_u32_e64 v4, null, s25, v1, s5                  // 000000869628: D5207C04 00160219
	ds_store_b32 v7, v6                                        // 000000869630: D8340000 00000607
	s_waitcnt lgkmcnt(0)                                       // 000000869638: BF89FC07
	s_barrier                                                  // 00000086963C: BFBD0000
	buffer_gl0_inv                                             // 000000869640: E0AC0000 00000000
	s_cbranch_vccnz 146                                        // 000000869648: BFA40092 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x394>
	v_dual_mov_b32 v8, 0 :: v_dual_mov_b32 v7, 0               // 00000086964C: CA100080 08060080
	s_and_saveexec_b32 s5, s4                                  // 000000869654: BE852004
	s_cbranch_execz 10                                         // 000000869658: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x184>
	v_lshlrev_b32_e32 v6, 1, v30                               // 00000086965C: 300C3C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000869660: BF870091
	.long 0xd7006a06                                           // 000000869664: D7006A06
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 000000869668: 02020D03
	v_add_co_ci_u32_e64 v7, null, 0, v4, vcc_lo                // 00000086966C: D5207C07 01AA0880
	global_load_d16_b16 v6, v[6:7], off                        // 000000869674: DC820000 067C0006
	s_waitcnt vmcnt(0)                                         // 00000086967C: BF8903F7
	v_cvt_f32_f16_e32 v7, v6                                   // 000000869680: 7E0E1706
	s_or_b32 exec_lo, exec_lo, s5                              // 000000869684: 8C7E057E
	v_or_b32_e32 v6, 32, v30                                   // 000000869688: 380C3CA0
	s_mov_b32 s4, exec_lo                                      // 00000086968C: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000869690: BF870001
	.long 0xd4c4007e                                           // 000000869694: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 000000869698: 02020C06
	s_cbranch_execz 10                                         // 00000086969C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x1c8>
	v_lshlrev_b32_e32 v6, 1, v6                                // 0000008696A0: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008696A4: BF870091
	.long 0xd7006a08                                           // 0000008696A8: D7006A08
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000008696AC: 02020D03
	v_add_co_ci_u32_e64 v9, null, 0, v4, vcc_lo                // 0000008696B0: D5207C09 01AA0880
	global_load_d16_b16 v6, v[8:9], off                        // 0000008696B8: DC820000 067C0008
	s_waitcnt vmcnt(0)                                         // 0000008696C0: BF8903F7
	v_cvt_f32_f16_e32 v8, v6                                   // 0000008696C4: 7E101706
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008696C8: 8C7E047E
	v_or_b32_e32 v6, 64, v30                                   // 0000008696CC: 380C3CC0
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v9, 0              // 0000008696D0: CA100080 0A080080
	s_mov_b32 s4, exec_lo                                      // 0000008696D8: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008696DC: BF870002
	.long 0xd4c4007e                                           // 0000008696E0: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 0000008696E4: 02020C06
	s_cbranch_execz 10                                         // 0000008696E8: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x214>
	v_lshlrev_b32_e32 v6, 1, v6                                // 0000008696EC: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008696F0: BF870091
	.long 0xd7006a0b                                           // 0000008696F4: D7006A0B
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000008696F8: 02020D03
	v_add_co_ci_u32_e64 v12, null, 0, v4, vcc_lo               // 0000008696FC: D5207C0C 01AA0880
	global_load_d16_b16 v6, v[11:12], off                      // 000000869704: DC820000 067C000B
	s_waitcnt vmcnt(0)                                         // 00000086970C: BF8903F7
	v_cvt_f32_f16_e32 v9, v6                                   // 000000869710: 7E121706
	s_or_b32 exec_lo, exec_lo, s4                              // 000000869714: 8C7E047E
	v_or_b32_e32 v6, 0x60, v30                                 // 000000869718: 380C3CFF 00000060
	s_mov_b32 s4, exec_lo                                      // 000000869720: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000869724: BF870001
	.long 0xd4c4007e                                           // 000000869728: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 00000086972C: 02020C06
	s_cbranch_execz 10                                         // 000000869730: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x25c>
	v_lshlrev_b32_e32 v6, 1, v6                                // 000000869734: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000869738: BF870091
	.long 0xd7006a0a                                           // 00000086973C: D7006A0A
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 000000869740: 02020D03
	v_add_co_ci_u32_e64 v11, null, 0, v4, vcc_lo               // 000000869744: D5207C0B 01AA0880
	global_load_d16_b16 v6, v[10:11], off                      // 00000086974C: DC820000 067C000A
	s_waitcnt vmcnt(0)                                         // 000000869754: BF8903F7
	v_cvt_f32_f16_e32 v10, v6                                  // 000000869758: 7E141706
	s_or_b32 exec_lo, exec_lo, s4                              // 00000086975C: 8C7E047E
	v_or_b32_e32 v6, 0x80, v30                                 // 000000869760: 380C3CFF 00000080
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v11, 0             // 000000869768: CA100080 0C0A0080
	s_mov_b32 s4, exec_lo                                      // 000000869770: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000869774: BF870002
	.long 0xd4c4007e                                           // 000000869778: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 00000086977C: 02020C06
	s_cbranch_execz 10                                         // 000000869780: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x2ac>
	v_lshlrev_b32_e32 v6, 1, v6                                // 000000869784: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000869788: BF870091
	.long 0xd7006a0d                                           // 00000086978C: D7006A0D
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 000000869790: 02020D03
	v_add_co_ci_u32_e64 v14, null, 0, v4, vcc_lo               // 000000869794: D5207C0E 01AA0880
	global_load_d16_b16 v6, v[13:14], off                      // 00000086979C: DC820000 067C000D
	s_waitcnt vmcnt(0)                                         // 0000008697A4: BF8903F7
	v_cvt_f32_f16_e32 v11, v6                                  // 0000008697A8: 7E161706
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008697AC: 8C7E047E
	v_or_b32_e32 v6, 0xa0, v30                                 // 0000008697B0: 380C3CFF 000000A0
	s_mov_b32 s4, exec_lo                                      // 0000008697B8: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008697BC: BF870001
	.long 0xd4c4007e                                           // 0000008697C0: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 0000008697C4: 02020C06
	s_cbranch_execz 10                                         // 0000008697C8: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x2f4>
	v_lshlrev_b32_e32 v6, 1, v6                                // 0000008697CC: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008697D0: BF870091
	.long 0xd7006a0c                                           // 0000008697D4: D7006A0C
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000008697D8: 02020D03
	v_add_co_ci_u32_e64 v13, null, 0, v4, vcc_lo               // 0000008697DC: D5207C0D 01AA0880
	global_load_d16_b16 v6, v[12:13], off                      // 0000008697E4: DC820000 067C000C
	s_waitcnt vmcnt(0)                                         // 0000008697EC: BF8903F7
	v_cvt_f32_f16_e32 v12, v6                                  // 0000008697F0: 7E181706
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008697F4: 8C7E047E
	v_or_b32_e32 v6, 0xc0, v30                                 // 0000008697F8: 380C3CFF 000000C0
	v_dual_mov_b32 v14, 0 :: v_dual_mov_b32 v13, 0             // 000000869800: CA100080 0E0C0080
	s_mov_b32 s4, exec_lo                                      // 000000869808: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000086980C: BF870002
	.long 0xd4c4007e                                           // 000000869810: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 000000869814: 02020C06
	s_cbranch_execz 10                                         // 000000869818: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x344>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000086981C: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000869820: BF870091
	.long 0xd7006a0f                                           // 000000869824: D7006A0F
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 000000869828: 02020D03
	v_add_co_ci_u32_e64 v16, null, 0, v4, vcc_lo               // 00000086982C: D5207C10 01AA0880
	global_load_d16_b16 v6, v[15:16], off                      // 000000869834: DC820000 067C000F
	s_waitcnt vmcnt(0)                                         // 00000086983C: BF8903F7
	v_cvt_f32_f16_e32 v13, v6                                  // 000000869840: 7E1A1706
	s_or_b32 exec_lo, exec_lo, s4                              // 000000869844: 8C7E047E
	v_or_b32_e32 v6, 0xe0, v30                                 // 000000869848: 380C3CFF 000000E0
	s_mov_b32 s4, exec_lo                                      // 000000869850: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000869854: BF870001
	.long 0xd4c4007e                                           // 000000869858: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 00000086985C: 02020C06
	s_cbranch_execz 10                                         // 000000869860: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x38c>
	v_lshlrev_b32_e32 v6, 1, v6                                // 000000869864: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000869868: BF870091
	.long 0xd7006a0e                                           // 00000086986C: D7006A0E
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 000000869870: 02020D03
	v_add_co_ci_u32_e64 v15, null, 0, v4, vcc_lo               // 000000869874: D5207C0F 01AA0880
	global_load_d16_b16 v6, v[14:15], off                      // 00000086987C: DC820000 067C000E
	s_waitcnt vmcnt(0)                                         // 000000869884: BF8903F7
	v_cvt_f32_f16_e32 v14, v6                                  // 000000869888: 7E1C1706
	s_or_b32 exec_lo, exec_lo, s4                              // 00000086988C: 8C7E047E
	s_branch 9                                                 // 000000869890: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x3b8>
	v_mov_b32_e32 v7, 0                                        // 000000869894: 7E0E0280
	s_delay_alu instid0(VALU_DEP_1)                            // 000000869898: BF870001
	v_mov_b32_e32 v8, v7                                       // 00000086989C: 7E100307
	v_mov_b32_e32 v9, v7                                       // 0000008698A0: 7E120307
	v_mov_b32_e32 v10, v7                                      // 0000008698A4: 7E140307
	v_mov_b32_e32 v11, v7                                      // 0000008698A8: 7E160307
	v_mov_b32_e32 v12, v7                                      // 0000008698AC: 7E180307
	v_mov_b32_e32 v13, v7                                      // 0000008698B0: 7E1A0307
	v_mov_b32_e32 v14, v7                                      // 0000008698B4: 7E1C0307
	s_add_u32 s4, s8, s18                                      // 0000008698B8: 80041208
	s_addc_u32 s5, s9, s19                                     // 0000008698BC: 82051309
	s_lshr_b32 s18, s15, 31                                    // 0000008698C0: 85129F0F
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v44, 0             // 0000008698C4: CA100080 132C0080
	s_add_u32 s18, s14, s18                                    // 0000008698CC: 8012120E
	s_addc_u32 s19, s15, 0                                     // 0000008698D0: 8213800F
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v20, 0             // 0000008698D4: CA100080 1F140080
	s_ashr_i64 s[18:19], s[18:19], 1                           // 0000008698DC: 86928112
	v_cndmask_b32_e64 v32, 0, 1, s7                            // 0000008698E0: D5010020 001D0280
	v_mad_u64_u32 v[25:26], null, v2, s18, s[4:5]              // 0000008698E8: D6FE7C19 00102502
	.long 0xd72c0002                                           // 0000008698F0: D72C0002
	v_cndmask_b32_e32 v0, v2, v19, vcc_lo                      // 0000008698F4: 02002702
	.long 0xd72c0005                                           // 0000008698F8: D72C0005
	v_cndmask_b32_e32 v0, v5, v18, vcc_lo                      // 0000008698FC: 02002505
	.long 0xd4440004                                           // 000000869900: D4440004
	v_cndmask_b32_e32 v1, s6, v30, vcc_lo                      // 000000869904: 02023C06
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v22, 0             // 000000869908: CA100080 15160080
	s_delay_alu instid0(VALU_DEP_3)                            // 000000869910: BF870003
	v_add3_u32 v33, v5, v26, v2                                // 000000869914: D6550021 040A3505
	s_and_saveexec_b32 s5, s4                                  // 00000086991C: BE852004
	s_cbranch_execz 21                                         // 000000869920: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x478>
	v_lshlrev_b32_e32 v2, 4, v30                               // 000000869924: 30043C84
	v_mov_b32_e32 v44, 0                                       // 000000869928: 7E580280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000086992C: BF870092
	.long 0xd7006a05                                           // 000000869930: D7006A05
	v_cndmask_b32_e32 v1, v25, v2, vcc_lo                      // 000000869934: 02020519
	v_add_co_ci_u32_e64 v6, null, 0, v33, vcc_lo               // 000000869938: D5207C06 01AA4280
	s_and_not1_b32 vcc_lo, exec_lo, s7                         // 000000869940: 916A077E
	global_load_b128 v[19:22], v[5:6], off                     // 000000869944: DC5E0000 137C0005
	s_cbranch_vccnz 10                                         // 00000086994C: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x478>
	v_lshlrev_b32_e32 v2, 1, v30                               // 000000869950: 30043C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000869954: BF870091
	.long 0xd7006a02                                           // 000000869958: D7006A02
	v_cndmask_b32_e32 v1, v3, v2, vcc_lo                       // 00000086995C: 02020503
	v_add_co_ci_u32_e64 v3, null, 0, v4, vcc_lo                // 000000869960: D5207C03 01AA0880
	global_load_d16_b16 v2, v[2:3], off                        // 000000869968: DC820000 027C0002
	s_waitcnt vmcnt(0)                                         // 000000869970: BF8903F7
	v_cvt_f32_f16_e32 v44, v2                                  // 000000869974: 7E581702
	s_or_b32 exec_lo, exec_lo, s5                              // 000000869978: 8C7E057E
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v35, 0             // 00000086997C: CA100080 22220080
	v_dual_mov_b32 v36, 0 :: v_dual_mov_b32 v37, 0             // 000000869984: CA100080 24240080
	v_dual_mov_b32 v38, 0 :: v_dual_mov_b32 v39, 0             // 00000086998C: CA100080 26260080
	v_mov_b32_e32 v40, 0                                       // 000000869994: 7E500280
	s_and_saveexec_b32 s5, s4                                  // 000000869998: BE852004
	s_cbranch_execz 685                                        // 00000086999C: BFA502AD <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0xf54>
	v_dual_mov_b32 v27, 0 :: v_dual_lshlrev_b32 v2, 1, v30     // 0000008699A0: CA220080 1B023C81
	.long 0xd7006a00                                           // 0000008699A8: D7006A00
	v_cndmask_b32_e32 v1, s20, v0, vcc_lo                      // 0000008699AC: 02020014
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008699B0: BF870191
	v_add_co_ci_u32_e64 v1, null, s21, v1, vcc_lo              // 0000008699B4: D5207C01 01AA0215
	v_dual_mov_b32 v39, v27 :: v_dual_lshlrev_b32 v26, 5, v30  // 0000008699BC: CA22011B 271A3C85
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008699C4: BF870093
	.long 0xd7006a00                                           // 0000008699C8: D7006A00
	v_cndmask_b32_e32 v1, v0, v2, vcc_lo                       // 0000008699CC: 02020500
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 0000008699D0: D5207C01 01AA0280
	v_lshl_or_b32 v41, v30, 4, 0x200                           // 0000008699D8: D6560029 03FD091E 00000200
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008699E4: BF870093
	.long 0xd7006a00                                           // 0000008699E8: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 0000008699EC: 02020008
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 0000008699F0: D5207C01 01AA0209
	v_dual_mov_b32 v42, v30 :: v_dual_mov_b32 v37, v27         // 0000008699F8: CA10011E 2A24011B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000869A00: BF870093
	.long 0xd7006a1c                                           // 000000869A04: D7006A1C
	v_cndmask_b32_e32 v0, v0, v192, vcc_lo                     // 000000869A08: 02018100
	v_add_co_ci_u32_e64 v29, null, 0, v1, vcc_lo               // 000000869A0C: D5207C1D 01AA0280
	v_dual_mov_b32 v40, v27 :: v_dual_mov_b32 v43, v44         // 000000869A14: CA10011B 282A012C
	v_mov_b32_e32 v38, v27                                     // 000000869A1C: 7E4C031B
	v_mov_b32_e32 v36, v27                                     // 000000869A20: 7E48031B
	v_mov_b32_e32 v35, v27                                     // 000000869A24: 7E46031B
	v_mov_b32_e32 v34, v27                                     // 000000869A28: 7E44031B
	v_mov_b32_e32 v31, v27                                     // 000000869A2C: 7E3E031B
	s_mul_i32 s4, s15, 6                                       // 000000869A30: 9604860F
	s_mul_hi_u32 s7, s14, 6                                    // 000000869A34: 9687860E
	s_lshl_b64 s[18:19], s[14:15], 2                           // 000000869A38: 8492820E
	s_add_i32 s7, s7, s4                                       // 000000869A3C: 81070407
	s_mul_i32 s21, s14, 6                                      // 000000869A40: 9615860E
	s_mov_b32 s20, 0                                           // 000000869A44: BE940080
	s_lshl_b64 s[8:9], s[14:15], 1                             // 000000869A48: 8488810E
	s_branch 612                                               // 000000869A4C: BFA00264 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0xee0>
	s_or_b32 exec_lo, exec_lo, s14                             // 000000869A50: 8C7E0E7E
	v_cndmask_b32_e64 v44, v44, v7, s3                         // 000000869A54: D501002C 000E0F2C
	v_cndmask_b32_e64 v1, v8, v9, s3                           // 000000869A5C: D5010001 000E1308
	v_cndmask_b32_e64 v0, v7, v8, s3                           // 000000869A64: D5010000 000E1107
	v_dual_mov_b32 v7, v14 :: v_dual_and_b32 v8, 0xff, v19     // 000000869A6C: CA24010E 070826FF 000000FF
	v_cndmask_b32_e64 v6, v13, v14, s3                         // 000000869A78: D5010006 000E1D0D
	v_cndmask_b32_e64 v5, v12, v13, s3                         // 000000869A80: D5010005 000E1B0C
	v_cndmask_b32_e64 v4, v11, v12, s3                         // 000000869A88: D5010004 000E190B
	v_cndmask_b32_e64 v3, v10, v11, s3                         // 000000869A90: D5010003 000E170A
	v_lshlrev_b32_e32 v8, 2, v8                                // 000000869A98: 30101082
	v_cndmask_b32_e64 v2, v9, v10, s3                          // 000000869A9C: D5010002 000E1509
	s_and_b32 s4, exec_lo, s4                                  // 000000869AA4: 8B04047E
	v_add_nc_u32_e32 v41, 0x200, v41                           // 000000869AA8: 4A5252FF 00000200
	s_or_b32 s20, s4, s20                                      // 000000869AB0: 8C141404
	ds_load_b32 v14, v8                                        // 000000869AB4: D8D80000 0E000008
	v_lshrrev_b32_e32 v8, 6, v19                               // 000000869ABC: 32102686
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000869AC0: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000869AC4: 361010FF 000003FC
	ds_load_b32 v55, v8                                        // 000000869ACC: D8D80000 37000008
	v_lshrrev_b32_e32 v8, 14, v19                              // 000000869AD4: 3210268E
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000869AD8: 361010FF 000003FC
	ds_load_b32 v56, v8                                        // 000000869AE0: D8D80000 38000008
	v_lshrrev_b32_e32 v8, 22, v19                              // 000000869AE8: 32102696
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000869AEC: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000869AF0: 361010FF 000003FC
	ds_load_b32 v57, v8                                        // 000000869AF8: D8D80000 39000008
	v_and_b32_e32 v8, 0xff, v20                                // 000000869B00: 361028FF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 000000869B08: 30101082
	ds_load_b32 v58, v8                                        // 000000869B0C: D8D80000 3A000008
	v_lshrrev_b32_e32 v8, 6, v20                               // 000000869B14: 32102886
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000869B18: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000869B1C: 361010FF 000003FC
	ds_load_b32 v59, v8                                        // 000000869B24: D8D80000 3B000008
	v_lshrrev_b32_e32 v8, 14, v20                              // 000000869B2C: 3210288E
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000869B30: 361010FF 000003FC
	ds_load_b32 v60, v8                                        // 000000869B38: D8D80000 3C000008
	v_lshrrev_b32_e32 v8, 22, v20                              // 000000869B40: 32102896
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000869B44: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000869B48: 361010FF 000003FC
	ds_load_b32 v61, v8                                        // 000000869B50: D8D80000 3D000008
	v_and_b32_e32 v8, 0xff, v21                                // 000000869B58: 36102AFF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 000000869B60: 30101082
	ds_load_b32 v62, v8                                        // 000000869B64: D8D80000 3E000008
	v_lshrrev_b32_e32 v8, 6, v21                               // 000000869B6C: 32102A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000869B70: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000869B74: 361010FF 000003FC
	ds_load_b32 v63, v8                                        // 000000869B7C: D8D80000 3F000008
	v_lshrrev_b32_e32 v8, 14, v21                              // 000000869B84: 32102A8E
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000869B88: 361010FF 000003FC
	ds_load_b32 v64, v8                                        // 000000869B90: D8D80000 40000008
	v_lshrrev_b32_e32 v8, 22, v21                              // 000000869B98: 32102A96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000869B9C: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000869BA0: 361010FF 000003FC
	ds_load_b32 v65, v8                                        // 000000869BA8: D8D80000 41000008
	v_and_b32_e32 v8, 0xff, v22                                // 000000869BB0: 36102CFF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 000000869BB8: 30101082
	ds_load_b32 v66, v8                                        // 000000869BBC: D8D80000 42000008
	v_lshrrev_b32_e32 v8, 6, v22                               // 000000869BC4: 32102C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000869BC8: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000869BCC: 361010FF 000003FC
	ds_load_b32 v67, v8                                        // 000000869BD4: D8D80000 43000008
	v_lshrrev_b32_e32 v8, 14, v22                              // 000000869BDC: 32102C8E
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000869BE0: 361010FF 000003FC
	ds_load_b32 v68, v8                                        // 000000869BE8: D8D80000 44000008
	v_lshrrev_b32_e32 v8, 22, v22                              // 000000869BF0: 32102C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000869BF4: BF870141
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000869BF8: 361010FF 000003FC
	ds_load_b32 v69, v8                                        // 000000869C00: D8D80000 45000008
	.long 0xd73c0008                                           // 000000869C08: D73C0008
	v_cndmask_b32_e32 v1, 1, v26, vcc_lo                       // 000000869C0C: 02023481
	v_add_nc_u32_e32 v26, 0x400, v26                           // 000000869C10: 4A3434FF 00000400
	.long 0xd7006a0c                                           // 000000869C18: D7006A0C
	v_cndmask_b32_e32 v1, s10, v8, vcc_lo                      // 000000869C1C: 0202100A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000869C20: BF870001
	v_add_co_ci_u32_e64 v13, null, s11, v9, vcc_lo             // 000000869C24: D5207C0D 01AA120B
	s_clause 0x3                                               // 000000869C2C: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 000000869C30: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 000000869C38: DC5E0010 137C000C
	global_load_b128 v[45:48], v[12:13], off offset:32         // 000000869C40: DC5E0020 2D7C000C
	global_load_b128 v[49:52], v[12:13], off offset:48         // 000000869C48: DC5E0030 317C000C
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 000000869C50: BF890CF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 000000869C54: CC1A4008 1A021D08
	s_waitcnt lgkmcnt(14)                                      // 000000869C5C: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000869C60: BF8700A1
	v_dot2_f32_bf16 v8, v9, v55, v8                            // 000000869C64: CC1A4008 1C226F09
	s_waitcnt lgkmcnt(13)                                      // 000000869C6C: BF89FCD7
	v_dot2_f32_bf16 v8, v10, v56, v8                           // 000000869C70: CC1A4008 1C22710A
	s_waitcnt lgkmcnt(12)                                      // 000000869C78: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000869C7C: BF8700A1
	v_dot2_f32_bf16 v8, v11, v57, v8                           // 000000869C80: CC1A4008 1C22730B
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 000000869C88: BF8908B7
	v_dot2_f32_bf16 v8, v19, v58, v8                           // 000000869C8C: CC1A4008 1C227513
	s_waitcnt lgkmcnt(10)                                      // 000000869C94: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000869C98: BF8700A1
	v_dot2_f32_bf16 v8, v20, v59, v8                           // 000000869C9C: CC1A4008 1C227714
	s_waitcnt lgkmcnt(9)                                       // 000000869CA4: BF89FC97
	v_dot2_f32_bf16 v8, v21, v60, v8                           // 000000869CA8: CC1A4008 1C227915
	s_waitcnt lgkmcnt(8)                                       // 000000869CB0: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000869CB4: BF8700A1
	v_dot2_f32_bf16 v8, v22, v61, v8                           // 000000869CB8: CC1A4008 1C227B16
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 000000869CC0: BF890477
	v_dot2_f32_bf16 v8, v45, v62, v8                           // 000000869CC4: CC1A4008 1C227D2D
	s_waitcnt lgkmcnt(6)                                       // 000000869CCC: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000869CD0: BF8700A1
	v_dot2_f32_bf16 v8, v46, v63, v8                           // 000000869CD4: CC1A4008 1C227F2E
	s_waitcnt lgkmcnt(5)                                       // 000000869CDC: BF89FC57
	v_dot2_f32_bf16 v8, v47, v64, v8                           // 000000869CE0: CC1A4008 1C22812F
	s_waitcnt lgkmcnt(4)                                       // 000000869CE8: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000869CEC: BF8700A1
	v_dot2_f32_bf16 v8, v48, v65, v8                           // 000000869CF0: CC1A4008 1C228330
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 000000869CF8: BF890037
	v_dot2_f32_bf16 v8, v49, v66, v8                           // 000000869CFC: CC1A4008 1C228531
	.long 0xd7006a31                                           // 000000869D04: D7006A31
	v_cndmask_b32_e32 v0, v12, v8, vcc_lo                      // 000000869D08: 0200110C
	s_waitcnt lgkmcnt(2)                                       // 000000869D0C: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000869D10: BF8701C2
	v_dot2_f32_bf16 v8, v50, v67, v8                           // 000000869D14: CC1A4008 1C228732
	v_add_co_ci_u32_e64 v50, null, s9, v13, vcc_lo             // 000000869D1C: D5207C32 01AA1A09
	.long 0xd7006a35                                           // 000000869D24: D7006A35
	v_cndmask_b32_e32 v0, v12, v18, vcc_lo                     // 000000869D28: 0200250C
	s_waitcnt lgkmcnt(1)                                       // 000000869D2C: BF89FC17
	v_dot2_f32_bf16 v8, v51, v68, v8                           // 000000869D30: CC1A4008 1C228933
	v_add_co_ci_u32_e64 v54, null, s19, v13, vcc_lo            // 000000869D38: D5207C36 01AA1A13
	.long 0xd7006a0c                                           // 000000869D40: D7006A0C
	v_cndmask_b32_e32 v0, v12, v21, vcc_lo                     // 000000869D44: 02002B0C
	s_waitcnt lgkmcnt(0)                                       // 000000869D48: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000869D4C: BF870123
	v_dot2_f32_bf16 v8, v52, v69, v8                           // 000000869D50: CC1A4008 1C228B34
	v_add_co_ci_u32_e64 v13, null, s7, v13, vcc_lo             // 000000869D58: D5207C0D 01AA1A07
	v_fmac_f32_e32 v40, v44, v8                                // 000000869D60: 5650112C
	s_clause 0x3                                               // 000000869D64: BF850003
	global_load_b128 v[8:11], v[49:50], off                    // 000000869D68: DC5E0000 087C0031
	global_load_b128 v[19:22], v[49:50], off offset:16         // 000000869D70: DC5E0010 137C0031
	global_load_b128 v[45:48], v[49:50], off offset:32         // 000000869D78: DC5E0020 2D7C0031
	global_load_b128 v[49:52], v[49:50], off offset:48         // 000000869D80: DC5E0030 317C0031
	s_waitcnt vmcnt(3)                                         // 000000869D88: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 000000869D8C: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000869D94: BF870091
	v_dot2_f32_bf16 v8, v9, v55, v8                            // 000000869D98: CC1A4008 1C226F09
	v_dot2_f32_bf16 v8, v10, v56, v8                           // 000000869DA0: CC1A4008 1C22710A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000869DA8: BF8700A1
	v_dot2_f32_bf16 v8, v11, v57, v8                           // 000000869DAC: CC1A4008 1C22730B
	s_waitcnt vmcnt(2)                                         // 000000869DB4: BF890BF7
	v_dot2_f32_bf16 v8, v19, v58, v8                           // 000000869DB8: CC1A4008 1C227513
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000869DC0: BF870091
	v_dot2_f32_bf16 v8, v20, v59, v8                           // 000000869DC4: CC1A4008 1C227714
	v_dot2_f32_bf16 v8, v21, v60, v8                           // 000000869DCC: CC1A4008 1C227915
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000869DD4: BF8700A1
	v_dot2_f32_bf16 v8, v22, v61, v8                           // 000000869DD8: CC1A4008 1C227B16
	s_waitcnt vmcnt(1)                                         // 000000869DE0: BF8907F7
	v_dot2_f32_bf16 v8, v45, v62, v8                           // 000000869DE4: CC1A4008 1C227D2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000869DEC: BF870091
	v_dot2_f32_bf16 v8, v46, v63, v8                           // 000000869DF0: CC1A4008 1C227F2E
	v_dot2_f32_bf16 v8, v47, v64, v8                           // 000000869DF8: CC1A4008 1C22812F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000869E00: BF8700A1
	v_dot2_f32_bf16 v8, v48, v65, v8                           // 000000869E04: CC1A4008 1C228330
	s_waitcnt vmcnt(0)                                         // 000000869E0C: BF8903F7
	v_dot2_f32_bf16 v8, v49, v66, v8                           // 000000869E10: CC1A4008 1C228531
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000869E18: BF870091
	v_dot2_f32_bf16 v8, v50, v67, v8                           // 000000869E1C: CC1A4008 1C228732
	v_dot2_f32_bf16 v8, v51, v68, v8                           // 000000869E24: CC1A4008 1C228933
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000869E2C: BF870091
	v_dot2_f32_bf16 v8, v52, v69, v8                           // 000000869E30: CC1A4008 1C228B34
	v_fmac_f32_e32 v39, v44, v8                                // 000000869E38: 564E112C
	s_clause 0x3                                               // 000000869E3C: BF850003
	global_load_b128 v[8:11], v[53:54], off                    // 000000869E40: DC5E0000 087C0035
	global_load_b128 v[19:22], v[53:54], off offset:16         // 000000869E48: DC5E0010 137C0035
	global_load_b128 v[45:48], v[53:54], off offset:32         // 000000869E50: DC5E0020 2D7C0035
	global_load_b128 v[49:52], v[53:54], off offset:48         // 000000869E58: DC5E0030 317C0035
	.long 0xd7006a35                                           // 000000869E60: D7006A35
	v_cndmask_b32_e32 v0, v53, v18, vcc_lo                     // 000000869E64: 02002535
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000869E68: BF8700B1
	v_add_co_ci_u32_e64 v54, null, s19, v54, vcc_lo            // 000000869E6C: D5207C36 01AA6C13
	s_waitcnt vmcnt(3)                                         // 000000869E74: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 000000869E78: CC1A4008 1A021D08
	v_dot2_f32_bf16 v8, v9, v55, v8                            // 000000869E80: CC1A4008 1C226F09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000869E88: BF870091
	v_dot2_f32_bf16 v8, v10, v56, v8                           // 000000869E8C: CC1A4008 1C22710A
	v_dot2_f32_bf16 v8, v11, v57, v8                           // 000000869E94: CC1A4008 1C22730B
	s_waitcnt vmcnt(2)                                         // 000000869E9C: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000869EA0: BF870091
	v_dot2_f32_bf16 v8, v19, v58, v8                           // 000000869EA4: CC1A4008 1C227513
	v_dot2_f32_bf16 v8, v20, v59, v8                           // 000000869EAC: CC1A4008 1C227714
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000869EB4: BF870091
	v_dot2_f32_bf16 v8, v21, v60, v8                           // 000000869EB8: CC1A4008 1C227915
	v_dot2_f32_bf16 v8, v22, v61, v8                           // 000000869EC0: CC1A4008 1C227B16
	s_waitcnt vmcnt(1)                                         // 000000869EC8: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000869ECC: BF870091
	v_dot2_f32_bf16 v8, v45, v62, v8                           // 000000869ED0: CC1A4008 1C227D2D
	v_dot2_f32_bf16 v8, v46, v63, v8                           // 000000869ED8: CC1A4008 1C227F2E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000869EE0: BF870091
	v_dot2_f32_bf16 v8, v47, v64, v8                           // 000000869EE4: CC1A4008 1C22812F
	v_dot2_f32_bf16 v8, v48, v65, v8                           // 000000869EEC: CC1A4008 1C228330
	s_waitcnt vmcnt(0)                                         // 000000869EF4: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000869EF8: BF870091
	v_dot2_f32_bf16 v8, v49, v66, v8                           // 000000869EFC: CC1A4008 1C228531
	v_dot2_f32_bf16 v8, v50, v67, v8                           // 000000869F04: CC1A4008 1C228732
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000869F0C: BF870091
	v_dot2_f32_bf16 v8, v51, v68, v8                           // 000000869F10: CC1A4008 1C228933
	v_dot2_f32_bf16 v8, v52, v69, v8                           // 000000869F18: CC1A4008 1C228B34
	s_delay_alu instid0(VALU_DEP_1)                            // 000000869F20: BF870001
	v_fmac_f32_e32 v38, v44, v8                                // 000000869F24: 564C112C
	s_clause 0x3                                               // 000000869F28: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 000000869F2C: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 000000869F34: DC5E0010 137C000C
	global_load_b128 v[45:48], v[12:13], off offset:32         // 000000869F3C: DC5E0020 2D7C000C
	global_load_b128 v[49:52], v[12:13], off offset:48         // 000000869F44: DC5E0030 317C000C
	.long 0xd7006a0c                                           // 000000869F4C: D7006A0C
	v_cndmask_b32_e32 v0, v12, v18, vcc_lo                     // 000000869F50: 0200250C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000869F54: BF8700B1
	v_add_co_ci_u32_e64 v13, null, s19, v13, vcc_lo            // 000000869F58: D5207C0D 01AA1A13
	s_waitcnt vmcnt(3)                                         // 000000869F60: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 000000869F64: CC1A4008 1A021D08
	v_dot2_f32_bf16 v8, v9, v55, v8                            // 000000869F6C: CC1A4008 1C226F09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000869F74: BF870091
	v_dot2_f32_bf16 v8, v10, v56, v8                           // 000000869F78: CC1A4008 1C22710A
	v_dot2_f32_bf16 v8, v11, v57, v8                           // 000000869F80: CC1A4008 1C22730B
	s_waitcnt vmcnt(2)                                         // 000000869F88: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000869F8C: BF870091
	v_dot2_f32_bf16 v8, v19, v58, v8                           // 000000869F90: CC1A4008 1C227513
	v_dot2_f32_bf16 v8, v20, v59, v8                           // 000000869F98: CC1A4008 1C227714
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000869FA0: BF870091
	v_dot2_f32_bf16 v8, v21, v60, v8                           // 000000869FA4: CC1A4008 1C227915
	v_dot2_f32_bf16 v8, v22, v61, v8                           // 000000869FAC: CC1A4008 1C227B16
	s_waitcnt vmcnt(1)                                         // 000000869FB4: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000869FB8: BF870091
	v_dot2_f32_bf16 v8, v45, v62, v8                           // 000000869FBC: CC1A4008 1C227D2D
	v_dot2_f32_bf16 v8, v46, v63, v8                           // 000000869FC4: CC1A4008 1C227F2E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000869FCC: BF870091
	v_dot2_f32_bf16 v8, v47, v64, v8                           // 000000869FD0: CC1A4008 1C22812F
	v_dot2_f32_bf16 v8, v48, v65, v8                           // 000000869FD8: CC1A4008 1C228330
	s_waitcnt vmcnt(0)                                         // 000000869FE0: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000869FE4: BF870091
	v_dot2_f32_bf16 v8, v49, v66, v8                           // 000000869FE8: CC1A4008 1C228531
	v_dot2_f32_bf16 v8, v50, v67, v8                           // 000000869FF0: CC1A4008 1C228732
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000869FF8: BF870091
	v_dot2_f32_bf16 v8, v51, v68, v8                           // 000000869FFC: CC1A4008 1C228933
	v_dot2_f32_bf16 v8, v52, v69, v8                           // 00000086A004: CC1A4008 1C228B34
	s_delay_alu instid0(VALU_DEP_1)                            // 00000086A00C: BF870001
	v_fmac_f32_e32 v37, v44, v8                                // 00000086A010: 564A112C
	s_clause 0x3                                               // 00000086A014: BF850003
	global_load_b128 v[8:11], v[53:54], off                    // 00000086A018: DC5E0000 087C0035
	global_load_b128 v[19:22], v[53:54], off offset:16         // 00000086A020: DC5E0010 137C0035
	global_load_b128 v[45:48], v[53:54], off offset:32         // 00000086A028: DC5E0020 2D7C0035
	global_load_b128 v[49:52], v[53:54], off offset:48         // 00000086A030: DC5E0030 317C0035
	s_waitcnt vmcnt(3)                                         // 00000086A038: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000086A03C: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000086A044: BF870091
	v_dot2_f32_bf16 v8, v9, v55, v8                            // 00000086A048: CC1A4008 1C226F09
	v_dot2_f32_bf16 v8, v10, v56, v8                           // 00000086A050: CC1A4008 1C22710A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000086A058: BF8700A1
	v_dot2_f32_bf16 v8, v11, v57, v8                           // 00000086A05C: CC1A4008 1C22730B
	s_waitcnt vmcnt(2)                                         // 00000086A064: BF890BF7
	v_dot2_f32_bf16 v8, v19, v58, v8                           // 00000086A068: CC1A4008 1C227513
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000086A070: BF870091
	v_dot2_f32_bf16 v8, v20, v59, v8                           // 00000086A074: CC1A4008 1C227714
	v_dot2_f32_bf16 v8, v21, v60, v8                           // 00000086A07C: CC1A4008 1C227915
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000086A084: BF8700A1
	v_dot2_f32_bf16 v8, v22, v61, v8                           // 00000086A088: CC1A4008 1C227B16
	s_waitcnt vmcnt(1)                                         // 00000086A090: BF8907F7
	v_dot2_f32_bf16 v8, v45, v62, v8                           // 00000086A094: CC1A4008 1C227D2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000086A09C: BF870091
	v_dot2_f32_bf16 v8, v46, v63, v8                           // 00000086A0A0: CC1A4008 1C227F2E
	v_dot2_f32_bf16 v8, v47, v64, v8                           // 00000086A0A8: CC1A4008 1C22812F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000086A0B0: BF8700A1
	v_dot2_f32_bf16 v8, v48, v65, v8                           // 00000086A0B4: CC1A4008 1C228330
	s_waitcnt vmcnt(0)                                         // 00000086A0BC: BF8903F7
	v_dot2_f32_bf16 v8, v49, v66, v8                           // 00000086A0C0: CC1A4008 1C228531
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000086A0C8: BF870091
	v_dot2_f32_bf16 v8, v50, v67, v8                           // 00000086A0CC: CC1A4008 1C228732
	v_dot2_f32_bf16 v8, v51, v68, v8                           // 00000086A0D4: CC1A4008 1C228933
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000086A0DC: BF870091
	v_dot2_f32_bf16 v8, v52, v69, v8                           // 00000086A0E0: CC1A4008 1C228B34
	v_fmac_f32_e32 v36, v44, v8                                // 00000086A0E8: 5648112C
	s_clause 0x3                                               // 00000086A0EC: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 00000086A0F0: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 00000086A0F8: DC5E0010 137C000C
	global_load_b128 v[45:48], v[12:13], off offset:32         // 00000086A100: DC5E0020 2D7C000C
	global_load_b128 v[49:52], v[12:13], off offset:48         // 00000086A108: DC5E0030 317C000C
	s_waitcnt vmcnt(3)                                         // 00000086A110: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000086A114: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000086A11C: BF870091
	v_dot2_f32_bf16 v8, v9, v55, v8                            // 00000086A120: CC1A4008 1C226F09
	v_dot2_f32_bf16 v8, v10, v56, v8                           // 00000086A128: CC1A4008 1C22710A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000086A130: BF8700A1
	v_dot2_f32_bf16 v8, v11, v57, v8                           // 00000086A134: CC1A4008 1C22730B
	s_waitcnt vmcnt(2)                                         // 00000086A13C: BF890BF7
	v_dot2_f32_bf16 v8, v19, v58, v8                           // 00000086A140: CC1A4008 1C227513
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000086A148: BF870091
	v_dot2_f32_bf16 v8, v20, v59, v8                           // 00000086A14C: CC1A4008 1C227714
	v_dot2_f32_bf16 v8, v21, v60, v8                           // 00000086A154: CC1A4008 1C227915
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000086A15C: BF8700A1
	v_dot2_f32_bf16 v8, v22, v61, v8                           // 00000086A160: CC1A4008 1C227B16
	s_waitcnt vmcnt(1)                                         // 00000086A168: BF8907F7
	v_dot2_f32_bf16 v8, v45, v62, v8                           // 00000086A16C: CC1A4008 1C227D2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000086A174: BF870091
	v_dot2_f32_bf16 v8, v46, v63, v8                           // 00000086A178: CC1A4008 1C227F2E
	v_dot2_f32_bf16 v8, v47, v64, v8                           // 00000086A180: CC1A4008 1C22812F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000086A188: BF8700A1
	v_dot2_f32_bf16 v8, v48, v65, v8                           // 00000086A18C: CC1A4008 1C228330
	s_waitcnt vmcnt(0)                                         // 00000086A194: BF8903F7
	v_dot2_f32_bf16 v8, v49, v66, v8                           // 00000086A198: CC1A4008 1C228531
	.long 0xd7006a31                                           // 00000086A1A0: D7006A31
	v_cndmask_b32_e32 v0, v53, v18, vcc_lo                     // 00000086A1A4: 02002535
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000086A1A8: BF8701B2
	v_dot2_f32_bf16 v8, v50, v67, v8                           // 00000086A1AC: CC1A4008 1C228732
	v_add_co_ci_u32_e64 v50, null, s19, v54, vcc_lo            // 00000086A1B4: D5207C32 01AA6C13
	.long 0xd7006a0c                                           // 00000086A1BC: D7006A0C
	v_cndmask_b32_e32 v0, v12, v18, vcc_lo                     // 00000086A1C0: 0200250C
	v_dot2_f32_bf16 v8, v51, v68, v8                           // 00000086A1C4: CC1A4008 1C228933
	v_add_co_ci_u32_e64 v13, null, s19, v13, vcc_lo            // 00000086A1CC: D5207C0D 01AA1A13
	.long 0xd7006a1c                                           // 00000086A1D4: D7006A1C
	v_cndmask_b32_e32 v0, v28, v192, vcc_lo                    // 00000086A1D8: 0201811C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000086A1DC: BF870123
	v_dot2_f32_bf16 v8, v52, v69, v8                           // 00000086A1E0: CC1A4008 1C228B34
	v_add_co_ci_u32_e64 v29, null, 0, v29, vcc_lo              // 00000086A1E8: D5207C1D 01AA3A80
	v_fmac_f32_e32 v35, v44, v8                                // 00000086A1F0: 5646112C
	s_clause 0x3                                               // 00000086A1F4: BF850003
	global_load_b128 v[8:11], v[49:50], off                    // 00000086A1F8: DC5E0000 087C0031
	global_load_b128 v[19:22], v[49:50], off offset:16         // 00000086A200: DC5E0010 137C0031
	global_load_b128 v[45:48], v[49:50], off offset:32         // 00000086A208: DC5E0020 2D7C0031
	global_load_b128 v[49:52], v[49:50], off offset:48         // 00000086A210: DC5E0030 317C0031
	s_waitcnt vmcnt(3)                                         // 00000086A218: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000086A21C: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000086A224: BF870091
	v_dot2_f32_bf16 v8, v9, v55, v8                            // 00000086A228: CC1A4008 1C226F09
	v_dot2_f32_bf16 v8, v10, v56, v8                           // 00000086A230: CC1A4008 1C22710A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000086A238: BF8700A1
	v_dot2_f32_bf16 v8, v11, v57, v8                           // 00000086A23C: CC1A4008 1C22730B
	s_waitcnt vmcnt(2)                                         // 00000086A244: BF890BF7
	v_dot2_f32_bf16 v8, v19, v58, v8                           // 00000086A248: CC1A4008 1C227513
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000086A250: BF870091
	v_dot2_f32_bf16 v8, v20, v59, v8                           // 00000086A254: CC1A4008 1C227714
	v_dot2_f32_bf16 v8, v21, v60, v8                           // 00000086A25C: CC1A4008 1C227915
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000086A264: BF8700A1
	v_dot2_f32_bf16 v8, v22, v61, v8                           // 00000086A268: CC1A4008 1C227B16
	s_waitcnt vmcnt(1)                                         // 00000086A270: BF8907F7
	v_dot2_f32_bf16 v8, v45, v62, v8                           // 00000086A274: CC1A4008 1C227D2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000086A27C: BF870091
	v_dot2_f32_bf16 v8, v46, v63, v8                           // 00000086A280: CC1A4008 1C227F2E
	v_dot2_f32_bf16 v8, v47, v64, v8                           // 00000086A288: CC1A4008 1C22812F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000086A290: BF8700A1
	v_dot2_f32_bf16 v8, v48, v65, v8                           // 00000086A294: CC1A4008 1C228330
	s_waitcnt vmcnt(0)                                         // 00000086A29C: BF8903F7
	v_dot2_f32_bf16 v8, v49, v66, v8                           // 00000086A2A0: CC1A4008 1C228531
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000086A2A8: BF870091
	v_dot2_f32_bf16 v8, v50, v67, v8                           // 00000086A2AC: CC1A4008 1C228732
	v_dot2_f32_bf16 v8, v51, v68, v8                           // 00000086A2B4: CC1A4008 1C228933
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000086A2BC: BF870091
	v_dot2_f32_bf16 v8, v52, v69, v8                           // 00000086A2C0: CC1A4008 1C228B34
	v_fmac_f32_e32 v34, v44, v8                                // 00000086A2C8: 5644112C
	s_clause 0x3                                               // 00000086A2CC: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 00000086A2D0: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 00000086A2D8: DC5E0010 137C000C
	global_load_b128 v[45:48], v[12:13], off offset:32         // 00000086A2E0: DC5E0020 2D7C000C
	global_load_b128 v[49:52], v[12:13], off offset:48         // 00000086A2E8: DC5E0030 317C000C
	s_waitcnt vmcnt(3)                                         // 00000086A2F0: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000086A2F4: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000086A2FC: BF870091
	v_dot2_f32_bf16 v8, v9, v55, v8                            // 00000086A300: CC1A4008 1C226F09
	v_dot2_f32_bf16 v8, v10, v56, v8                           // 00000086A308: CC1A4008 1C22710A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000086A310: BF8700A1
	v_dot2_f32_bf16 v8, v11, v57, v8                           // 00000086A314: CC1A4008 1C22730B
	s_waitcnt vmcnt(2)                                         // 00000086A31C: BF890BF7
	v_dot2_f32_bf16 v8, v19, v58, v8                           // 00000086A320: CC1A4008 1C227513
	v_mov_b32_e32 v19, v15                                     // 00000086A328: 7E26030F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000086A32C: BF870122
	v_dot2_f32_bf16 v8, v20, v59, v8                           // 00000086A330: CC1A4008 1C227714
	v_mov_b32_e32 v20, v16                                     // 00000086A338: 7E280310
	v_dot2_f32_bf16 v8, v21, v60, v8                           // 00000086A33C: CC1A4008 1C227915
	v_mov_b32_e32 v21, v17                                     // 00000086A344: 7E2A0311
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000086A348: BF870132
	v_dot2_f32_bf16 v8, v22, v61, v8                           // 00000086A34C: CC1A4008 1C227B16
	v_mov_b32_e32 v22, v18                                     // 00000086A354: 7E2C0312
	s_waitcnt vmcnt(1)                                         // 00000086A358: BF8907F7
	v_dot2_f32_bf16 v8, v45, v62, v8                           // 00000086A35C: CC1A4008 1C227D2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000086A364: BF870091
	v_dot2_f32_bf16 v8, v46, v63, v8                           // 00000086A368: CC1A4008 1C227F2E
	v_dot2_f32_bf16 v8, v47, v64, v8                           // 00000086A370: CC1A4008 1C22812F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000086A378: BF8700A1
	v_dot2_f32_bf16 v8, v48, v65, v8                           // 00000086A37C: CC1A4008 1C228330
	s_waitcnt vmcnt(0)                                         // 00000086A384: BF8903F7
	v_dot2_f32_bf16 v8, v49, v66, v8                           // 00000086A388: CC1A4008 1C228531
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000086A390: BF870091
	v_dot2_f32_bf16 v8, v50, v67, v8                           // 00000086A394: CC1A4008 1C228732
	v_dot2_f32_bf16 v8, v51, v68, v8                           // 00000086A39C: CC1A4008 1C228933
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000086A3A4: BF870091
	v_dot2_f32_bf16 v8, v52, v69, v8                           // 00000086A3A8: CC1A4008 1C228B34
	v_dual_fmac_f32 v31, v44, v8 :: v_dual_mov_b32 v14, v7     // 00000086A3B0: C810112C 1F0E0107
	v_dual_mov_b32 v44, v43 :: v_dual_mov_b32 v13, v6          // 00000086A3B8: CA10012B 2C0C0106
	v_dual_mov_b32 v12, v5 :: v_dual_mov_b32 v11, v4           // 00000086A3C0: CA100105 0C0A0104
	v_dual_mov_b32 v10, v3 :: v_dual_mov_b32 v9, v2            // 00000086A3C8: CA100103 0A080102
	v_dual_mov_b32 v8, v1 :: v_dual_mov_b32 v7, v0             // 00000086A3D0: CA100101 08060100
	s_and_not1_b32 exec_lo, exec_lo, s20                       // 00000086A3D8: 917E147E
	s_cbranch_execz 28                                         // 00000086A3DC: BFA5001C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0xf50>
	s_waitcnt vmcnt(0)                                         // 00000086A3E0: BF8903F7
	v_dual_mov_b32 v15, v19 :: v_dual_add_nc_u32 v42, 32, v42  // 00000086A3E4: CA200113 0F2A54A0
	v_dual_mov_b32 v16, v20 :: v_dual_mov_b32 v17, v21         // 00000086A3EC: CA100114 10100115
	v_mov_b32_e32 v18, v22                                     // 00000086A3F4: 7E240316
	s_delay_alu instid0(VALU_DEP_3)                            // 00000086A3F8: BF870003
	.long 0xd4430004                                           // 00000086A3FC: D4430004
	v_cndmask_b32_e32 v1, s6, v42, vcc_lo                      // 00000086A400: 02025406
	s_mov_b32 s14, exec_lo                                     // 00000086A404: BE8E007E
	.long 0xd4c4007e                                           // 00000086A408: D4C4007E
	v_cndmask_b32_e32 v1, s6, v42, vcc_lo                      // 00000086A40C: 02025406
	s_cbranch_execz 64911                                      // 00000086A410: BFA5FD8F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x550>
	.long 0xd7006a00                                           // 00000086A414: D7006A00
	v_cndmask_b32_e32 v1, v25, v41, vcc_lo                     // 00000086A418: 02025319
	s_delay_alu instid0(VALU_DEP_1)                            // 00000086A41C: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v33, vcc_lo               // 00000086A420: D5207C01 01AA4280
	v_cmp_ne_u32_e32 vcc_lo, 1, v32                            // 00000086A428: 7C9A4081
	v_mov_b32_e32 v43, v44                                     // 00000086A42C: 7E56032C
	global_load_b128 v[15:18], v[0:1], off                     // 00000086A430: DC5E0000 0F7C0000
	s_cbranch_vccnz 64901                                      // 00000086A438: BFA4FD85 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x550>
	global_load_d16_b16 v0, v[28:29], off                      // 00000086A43C: DC820000 007C001C
	s_waitcnt vmcnt(0)                                         // 00000086A444: BF8903F7
	v_cvt_f32_f16_e32 v43, v0                                  // 00000086A448: 7E561700
	s_branch 64896                                             // 00000086A44C: BFA0FD80 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x550>
	s_or_b32 exec_lo, exec_lo, s20                             // 00000086A450: 8C7E147E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000086A454: BF8700A9
	s_or_b32 exec_lo, exec_lo, s5                              // 00000086A458: 8C7E057E
	.long 0xd71f0000                                           // 00000086A45C: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000086A460: 020100C1
	v_xor_b32_e32 v1, 16, v0                                   // 00000086A464: 3A020090
	v_xor_b32_e32 v9, 8, v0                                    // 00000086A468: 3A120088
	v_xor_b32_e32 v17, 4, v0                                   // 00000086A46C: 3A220084
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000086A470: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v1                            // 00000086A474: 7C9802A0
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 00000086A478: 02020300
	v_cmp_gt_u32_e32 vcc_lo, 32, v9                            // 00000086A47C: 7C9812A0
	s_delay_alu instid0(VALU_DEP_2)                            // 00000086A480: BF870002
	v_lshlrev_b32_e32 v1, 2, v1                                // 00000086A484: 30020282
	ds_bpermute_b32 v2, v1, v40                                // 00000086A488: DACC0000 02002801
	s_waitcnt lgkmcnt(0)                                       // 00000086A490: BF89FC07
	v_add_f32_e32 v2, v40, v2                                  // 00000086A494: 06040528
	ds_bpermute_b32 v8, v1, v34                                // 00000086A498: DACC0000 08002201
	ds_bpermute_b32 v6, v1, v36                                // 00000086A4A0: DACC0000 06002401
	ds_bpermute_b32 v4, v1, v38                                // 00000086A4A8: DACC0000 04002601
	v_cndmask_b32_e32 v9, v0, v9, vcc_lo                       // 00000086A4B0: 02121300
	ds_bpermute_b32 v3, v1, v39                                // 00000086A4B4: DACC0000 03002701
	ds_bpermute_b32 v5, v1, v37                                // 00000086A4BC: DACC0000 05002501
	ds_bpermute_b32 v7, v1, v35                                // 00000086A4C4: DACC0000 07002301
	ds_bpermute_b32 v1, v1, v31                                // 00000086A4CC: DACC0000 01001F01
	v_cmp_gt_u32_e32 vcc_lo, 32, v17                           // 00000086A4D4: 7C9822A0
	s_waitcnt lgkmcnt(6)                                       // 00000086A4D8: BF89FC67
	v_dual_cndmask_b32 v17, v0, v17 :: v_dual_add_f32 v8, v34, v8// 00000086A4DC: CA482300 11081122
	s_waitcnt lgkmcnt(5)                                       // 00000086A4E4: BF89FC57
	v_dual_add_f32 v6, v36, v6 :: v_dual_lshlrev_b32 v9, 2, v9 // 00000086A4E8: C9220D24 06081282
	s_waitcnt lgkmcnt(4)                                       // 00000086A4F0: BF89FC47
	v_add_f32_e32 v4, v38, v4                                  // 00000086A4F4: 06080926
	ds_bpermute_b32 v10, v9, v2                                // 00000086A4F8: DACC0000 0A000209
	s_waitcnt lgkmcnt(4)                                       // 00000086A500: BF89FC47
	v_add_f32_e32 v3, v39, v3                                  // 00000086A504: 06060727
	ds_bpermute_b32 v12, v9, v4                                // 00000086A508: DACC0000 0C000409
	ds_bpermute_b32 v14, v9, v6                                // 00000086A510: DACC0000 0E000609
	ds_bpermute_b32 v16, v9, v8                                // 00000086A518: DACC0000 10000809
	s_waitcnt lgkmcnt(6)                                       // 00000086A520: BF89FC67
	v_add_f32_e32 v5, v37, v5                                  // 00000086A524: 060A0B25
	s_waitcnt lgkmcnt(5)                                       // 00000086A528: BF89FC57
	v_add_f32_e32 v7, v35, v7                                  // 00000086A52C: 060E0F23
	s_waitcnt lgkmcnt(3)                                       // 00000086A530: BF89FC37
	v_dual_add_f32 v1, v31, v1 :: v_dual_add_f32 v2, v2, v10   // 00000086A534: C908031F 01021502
	ds_bpermute_b32 v11, v9, v3                                // 00000086A53C: DACC0000 0B000309
	s_waitcnt lgkmcnt(3)                                       // 00000086A544: BF89FC37
	v_dual_add_f32 v4, v4, v12 :: v_dual_lshlrev_b32 v17, 2, v17// 00000086A548: C9221904 04102282
	ds_bpermute_b32 v13, v9, v5                                // 00000086A550: DACC0000 0D000509
	s_waitcnt lgkmcnt(3)                                       // 00000086A558: BF89FC37
	v_add_f32_e32 v6, v6, v14                                  // 00000086A55C: 060C1D06
	ds_bpermute_b32 v15, v9, v7                                // 00000086A560: DACC0000 0F000709
	s_waitcnt lgkmcnt(3)                                       // 00000086A568: BF89FC37
	v_add_f32_e32 v8, v8, v16                                  // 00000086A56C: 06102108
	ds_bpermute_b32 v9, v9, v1                                 // 00000086A570: DACC0000 09000109
	s_waitcnt lgkmcnt(3)                                       // 00000086A578: BF89FC37
	v_add_f32_e32 v3, v3, v11                                  // 00000086A57C: 06061703
	ds_bpermute_b32 v11, v17, v4                               // 00000086A580: DACC0000 0B000411
	s_waitcnt lgkmcnt(0)                                       // 00000086A588: BF89FC07
	v_dual_add_f32 v4, v4, v11 :: v_dual_add_f32 v1, v1, v9    // 00000086A58C: C9081704 04001301
	ds_bpermute_b32 v9, v17, v2                                // 00000086A594: DACC0000 09000211
	ds_bpermute_b32 v16, v17, v1                               // 00000086A59C: DACC0000 10000111
	s_waitcnt lgkmcnt(1)                                       // 00000086A5A4: BF89FC17
	v_add_f32_e32 v2, v2, v9                                   // 00000086A5A8: 06041302
	ds_bpermute_b32 v10, v17, v3                               // 00000086A5AC: DACC0000 0A000311
	s_waitcnt lgkmcnt(0)                                       // 00000086A5B4: BF89FC07
	v_add_f32_e32 v3, v3, v10                                  // 00000086A5B8: 06061503
	v_xor_b32_e32 v10, 1, v0                                   // 00000086A5BC: 3A140081
	v_add_f32_e32 v7, v7, v15                                  // 00000086A5C0: 060E1F07
	ds_bpermute_b32 v15, v17, v8                               // 00000086A5C4: DACC0000 0F000811
	v_add_f32_e32 v5, v5, v13                                  // 00000086A5CC: 060A1B05
	ds_bpermute_b32 v13, v17, v6                               // 00000086A5D0: DACC0000 0D000611
	ds_bpermute_b32 v14, v17, v7                               // 00000086A5D8: DACC0000 0E000711
	s_waitcnt lgkmcnt(2)                                       // 00000086A5E0: BF89FC27
	v_add_f32_e32 v8, v8, v15                                  // 00000086A5E4: 06101F08
	ds_bpermute_b32 v12, v17, v5                               // 00000086A5E8: DACC0000 0C000511
	v_xor_b32_e32 v17, 2, v0                                   // 00000086A5F0: 3A220082
	s_waitcnt lgkmcnt(2)                                       // 00000086A5F4: BF89FC27
	v_add_f32_e32 v9, v6, v13                                  // 00000086A5F8: 06121B06
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000086A5FC: BF870132
	v_cmp_gt_u32_e32 vcc_lo, 32, v17                           // 00000086A600: 7C9822A0
	v_cndmask_b32_e32 v17, v0, v17, vcc_lo                     // 00000086A604: 02222300
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 00000086A608: 7C9814A0
	v_dual_cndmask_b32 v0, v0, v10 :: v_dual_lshlrev_b32 v17, 2, v17// 00000086A60C: CA621500 00102282
	s_waitcnt lgkmcnt(1)                                       // 00000086A614: BF89FC17
	v_add_f32_e32 v7, v7, v14                                  // 00000086A618: 060E1D07
	v_cmp_eq_u32_e32 vcc_lo, 0, v30                            // 00000086A61C: 7C943C80
	s_waitcnt lgkmcnt(0)                                       // 00000086A620: BF89FC07
	v_add_f32_e32 v5, v5, v12                                  // 00000086A624: 060A1905
	ds_bpermute_b32 v18, v17, v8                               // 00000086A628: DACC0000 12000811
	s_waitcnt vmcnt(0)                                         // 00000086A630: BF8903F7
	v_lshlrev_b32_e32 v19, 2, v0                               // 00000086A634: 30260082
	s_and_b32 s2, vcc_lo, s2                                   // 00000086A638: 8B02026A
	s_waitcnt lgkmcnt(0)                                       // 00000086A63C: BF89FC07
	v_add_f32_e32 v0, v8, v18                                  // 00000086A640: 06002508
	ds_bpermute_b32 v12, v17, v4                               // 00000086A644: DACC0000 0C000411
	ds_bpermute_b32 v14, v17, v5                               // 00000086A64C: DACC0000 0E000511
	ds_bpermute_b32 v15, v17, v9                               // 00000086A654: DACC0000 0F000911
	s_waitcnt lgkmcnt(2)                                       // 00000086A65C: BF89FC27
	v_add_f32_e32 v12, v4, v12                                 // 00000086A660: 06181904
	v_add_f32_e32 v13, v1, v16                                 // 00000086A664: 061A2101
	ds_bpermute_b32 v1, v17, v2                                // 00000086A668: DACC0000 01000211
	ds_bpermute_b32 v16, v17, v7                               // 00000086A670: DACC0000 10000711
	s_waitcnt lgkmcnt(1)                                       // 00000086A678: BF89FC17
	v_add_f32_e32 v10, v2, v1                                  // 00000086A67C: 06140302
	ds_bpermute_b32 v6, v17, v3                                // 00000086A680: DACC0000 06000311
	ds_bpermute_b32 v17, v17, v13                              // 00000086A688: DACC0000 11000D11
	s_waitcnt lgkmcnt(2)                                       // 00000086A690: BF89FC27
	v_dual_add_f32 v2, v9, v15 :: v_dual_add_f32 v1, v7, v16   // 00000086A694: C9081F09 02002107
	ds_bpermute_b32 v15, v19, v12                              // 00000086A69C: DACC0000 0F000C13
	ds_bpermute_b32 v4, v19, v1                                // 00000086A6A4: DACC0000 04000113
	s_waitcnt lgkmcnt(3)                                       // 00000086A6AC: BF89FC37
	v_add_f32_e32 v11, v3, v6                                  // 00000086A6B0: 06160D03
	v_add_f32_e32 v6, v5, v14                                  // 00000086A6B4: 060C1D05
	s_waitcnt lgkmcnt(2)                                       // 00000086A6B8: BF89FC27
	v_add_f32_e32 v7, v13, v17                                 // 00000086A6BC: 060E230D
	ds_bpermute_b32 v13, v19, v10                              // 00000086A6C0: DACC0000 0D000A13
	ds_bpermute_b32 v5, v19, v2                                // 00000086A6C8: DACC0000 05000213
	ds_bpermute_b32 v14, v19, v11                              // 00000086A6D0: DACC0000 0E000B13
	ds_bpermute_b32 v8, v19, v6                                // 00000086A6D8: DACC0000 08000613
	ds_bpermute_b32 v3, v19, v0                                // 00000086A6E0: DACC0000 03000013
	ds_bpermute_b32 v9, v19, v7                                // 00000086A6E8: DACC0000 09000713
	s_and_saveexec_b32 s3, s2                                  // 00000086A6F0: BE832002
	s_cbranch_execz 366                                        // 00000086A6F4: BFA5016E <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x17b0>
	s_waitcnt lgkmcnt(3)                                       // 00000086A6F8: BF89FC37
	v_dual_add_f32 v10, v10, v13 :: v_dual_add_f32 v11, v11, v14// 00000086A6FC: C9081B0A 0A0A1D0B
	s_load_b32 s4, s[0:1], 0x48                                // 00000086A704: F4000100 F8000048
	s_waitcnt lgkmcnt(0)                                       // 00000086A70C: BF89FC07
	v_dual_add_f32 v12, v12, v15 :: v_dual_add_f32 v7, v7, v9  // 00000086A710: C9081F0C 0C061307
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000086A718: BF870232
	v_bfe_u32 v13, v10, 16, 1                                  // 00000086A71C: D610000D 0205210A
	v_bfe_u32 v14, v11, 16, 1                                  // 00000086A724: D610000E 0205210B
	v_add_f32_e32 v2, v2, v5                                   // 00000086A72C: 06040B02
	v_bfe_u32 v15, v12, 16, 1                                  // 00000086A730: D610000F 0205210C
	s_lshl_b64 s[2:3], s[16:17], 2                             // 00000086A738: 84828210
	v_add3_u32 v10, v10, v13, 0x7fff                           // 00000086A73C: D655000A 03FE1B0A 00007FFF
	v_add3_u32 v11, v11, v14, 0x7fff                           // 00000086A748: D655000B 03FE1D0B 00007FFF
	v_add_f32_e32 v6, v6, v8                                   // 00000086A754: 060C1106
	v_add3_u32 v12, v12, v15, 0x7fff                           // 00000086A758: D655000C 03FE1F0C 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000086A764: BF870193
	v_and_b32_e32 v11, 0xffff0000, v11                         // 00000086A768: 361616FF FFFF0000
	v_bfe_u32 v9, v6, 16, 1                                    // 00000086A770: D6100009 02052106
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000086A778: BF870091
	v_add3_u32 v5, v6, v9, 0x7fff                              // 00000086A77C: D6550005 03FE1306 00007FFF
	v_dual_add_f32 v4, v1, v4 :: v_dual_and_b32 v5, 0xffff0000, v5// 00000086A788: C9240901 04040AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000086A794: BF8700A1
	v_dual_mul_f32 v5, s4, v5 :: v_dual_and_b32 v12, 0xffff0000, v12// 00000086A798: C8E40A04 050C18FF FFFF0000
	v_and_b32_e32 v10, 0xffff0000, v10                         // 00000086A7A4: 361414FF FFFF0000
	v_dual_mul_f32 v5, 0xbfb8aa3b, v5 :: v_dual_mul_f32 v8, s4, v10// 00000086A7AC: C8C60AFF 05081404 BFB8AA3B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000086A7B8: BF870113
	v_dual_mul_f32 v10, s4, v11 :: v_dual_mul_f32 v11, s4, v12 // 00000086A7BC: C8C61604 0A0A1804
	v_exp_f32_e32 v5, v5                                       // 00000086A7C4: 7E0A4B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000086A7C8: BF870091
	v_dual_mul_f32 v11, 0xbfb8aa3b, v11 :: v_dual_mul_f32 v8, 0xbfb8aa3b, v8// 00000086A7CC: C8C616FF 0B0810FF BFB8AA3B
	v_exp_f32_e32 v9, v11                                      // 00000086A7D8: 7E124B0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_3)// 00000086A7DC: BF8703A1
	v_exp_f32_e32 v6, v8                                       // 00000086A7E0: 7E0C4B08
	v_bfe_u32 v11, v4, 16, 1                                   // 00000086A7E4: D610000B 02052104
	v_add_f32_e32 v5, 1.0, v5                                  // 00000086A7EC: 060A0AF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 00000086A7F0: BF870312
	v_add3_u32 v4, v4, v11, 0x7fff                             // 00000086A7F4: D6550004 03FE1704 00007FFF
	v_dual_add_f32 v9, 1.0, v9 :: v_dual_mul_f32 v10, 0xbfb8aa3b, v10// 00000086A800: C90612F2 090A14FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000086A80C: BF870111
	v_div_scale_f32 v14, null, v9, v9, 1.0                     // 00000086A810: D6FC7C0E 03CA1309
	v_exp_f32_e32 v8, v10                                      // 00000086A818: 7E104B0A
	v_div_scale_f32 v22, s1, 1.0, v9, 1.0                      // 00000086A81C: D6FC0116 03CA12F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000086A824: BF870292
	v_rcp_f32_e32 v18, v14                                     // 00000086A828: 7E24550E
	v_fma_f32 v20, -v14, v18, 1.0                              // 00000086A82C: D6130014 23CA250E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 00000086A834: BF870311
	v_fmac_f32_e32 v18, v20, v18                               // 00000086A838: 56242514
	v_add_f32_e32 v8, 1.0, v8                                  // 00000086A83C: 061010F2
	v_div_scale_f32 v20, null, v5, v5, 1.0                     // 00000086A840: D6FC7C14 03CA0B05
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000086A848: BF870193
	v_mul_f32_e32 v25, v22, v18                                // 00000086A84C: 10322516
	v_div_scale_f32 v13, null, v8, v8, 1.0                     // 00000086A850: D6FC7C0D 03CA1108
	v_div_scale_f32 v21, s0, 1.0, v8, 1.0                      // 00000086A858: D6FC0015 03CA10F2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000086A860: BF870194
	v_rcp_f32_e32 v26, v20                                     // 00000086A864: 7E345514
	v_fma_f32 v29, -v14, v25, v22                              // 00000086A868: D613001D 245A330E
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000086A870: BF870143
	v_rcp_f32_e32 v17, v13                                     // 00000086A874: 7E22550D
	v_add_f32_e32 v10, v0, v3                                  // 00000086A878: 06140700
	v_bfe_u32 v3, v2, 16, 1                                    // 00000086A87C: D6100003 02052102
	.long 0xd73c0000                                           // 00000086A884: D73C0000
	v_cndmask_b32_e32 v1, 2, v23, vcc_lo                       // 00000086A888: 02022E82
	v_add3_u32 v19, v2, v3, 0x7fff                             // 00000086A88C: D6550013 03FE0702 00007FFF
	v_add_f32_e32 v6, 1.0, v6                                  // 00000086A898: 060C0CF2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000086A89C: BF870293
	.long 0xd7006a00                                           // 00000086A8A0: D7006A00
	v_cndmask_b32_e32 v1, s12, v0, vcc_lo                      // 00000086A8A4: 0202000C
	v_fma_f32 v3, -v13, v17, 1.0                               // 00000086A8A8: D6130003 23CA230D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000086A8B0: BF870214
	v_and_b32_e32 v19, 0xffff0000, v19                         // 00000086A8B4: 362626FF FFFF0000
	v_div_scale_f32 v12, null, v6, v6, 1.0                     // 00000086A8BC: D6FC7C0C 03CA0D06
	v_add_co_ci_u32_e64 v1, null, s13, v1, vcc_lo              // 00000086A8C4: D5207C01 01AA020D
	v_div_scale_f32 v11, vcc_lo, 1.0, v6, 1.0                  // 00000086A8CC: D6FC6A0B 03CA0CF2
	v_fmac_f32_e32 v17, v3, v17                                // 00000086A8D4: 56222303
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000086A8D8: BF870124
	v_rcp_f32_e32 v16, v12                                     // 00000086A8DC: 7E20550C
	v_bfe_u32 v15, v10, 16, 1                                  // 00000086A8E0: D610000F 0205210A
	v_dual_mul_f32 v19, s4, v19 :: v_dual_mul_f32 v24, v21, v17// 00000086A8E8: C8C62604 13182315
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000086A8F0: BF870112
	v_add3_u32 v10, v10, v15, 0x7fff                           // 00000086A8F4: D655000A 03FE1F0A 00007FFF
	v_mul_f32_e32 v19, 0xbfb8aa3b, v19                         // 00000086A900: 102626FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000086A908: BF870293
	v_fma_f32 v28, -v13, v24, v21                              // 00000086A90C: D613001C 2456310D
	v_fma_f32 v2, -v12, v16, 1.0                               // 00000086A914: D6130002 23CA210C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000086A91C: BF870194
	v_and_b32_e32 v10, 0xffff0000, v10                         // 00000086A920: 361414FF FFFF0000
	v_fmac_f32_e32 v24, v28, v17                               // 00000086A928: 5630231C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000086A92C: BF8700A3
	v_fmac_f32_e32 v16, v2, v16                                // 00000086A930: 56202102
	.long 0xd7000202                                           // 00000086A934: D7000202
	v_cndmask_b32_e32 v0, v0, v2, vcc_lo                       // 00000086A938: 02000500
	v_add_co_ci_u32_e64 v3, null, s3, v1, s2                   // 00000086A93C: D5207C03 000A0203
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000086A944: BF870093
	v_mul_f32_e32 v23, v11, v16                                // 00000086A948: 102E210B
	v_fma_f32 v27, -v12, v23, v11                              // 00000086A94C: D613001B 242E2F0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000086A954: BF8701B1
	v_fmac_f32_e32 v23, v27, v16                               // 00000086A958: 562E211B
	v_dual_fmac_f32 v25, v29, v18 :: v_dual_and_b32 v4, 0xffff0000, v4// 00000086A95C: C824251D 190408FF FFFF0000
	v_fma_f32 v27, -v20, v26, 1.0                              // 00000086A968: D613001B 23CA3514
	v_fma_f32 v11, -v12, v23, v11                              // 00000086A970: D613000B 242E2F0C
	v_fma_f32 v12, -v13, v24, v21                              // 00000086A978: D613000C 2456310D
	s_delay_alu instid0(VALU_DEP_4)                            // 00000086A980: BF870004
	v_fma_f32 v13, -v14, v25, v22                              // 00000086A984: D613000D 245A330E
	v_exp_f32_e32 v14, v19                                     // 00000086A98C: 7E1C4B13
	v_fmac_f32_e32 v26, v27, v26                               // 00000086A990: 5634351B
	v_div_fmas_f32 v11, v11, v16, v23                          // 00000086A994: D637000B 045E210B
	s_mov_b32 vcc_lo, s0                                       // 00000086A99C: BEEA0000
	v_div_fmas_f32 v12, v12, v17, v24                          // 00000086A9A0: D637000C 0462230C
	s_mov_b32 vcc_lo, s1                                       // 00000086A9A8: BEEA0001
	s_delay_alu instid0(VALU_DEP_2)                            // 00000086A9AC: BF870002
	v_div_fixup_f32 v6, v11, v6, 1.0                           // 00000086A9B0: D6270006 03CA0D0B
	v_bfe_u32 v11, v7, 16, 1                                   // 00000086A9B8: D610000B 02052107
	v_div_fmas_f32 v13, v13, v18, v25                          // 00000086A9C0: D637000D 0466250D
	v_div_fixup_f32 v8, v12, v8, 1.0                           // 00000086A9C8: D6270008 03CA110C
	v_add_f32_e32 v12, 1.0, v14                                // 00000086A9D0: 06181CF2
	v_add_f32_e32 v6, v6, v6                                   // 00000086A9D4: 060C0D06
	v_add3_u32 v7, v7, v11, 0x7fff                             // 00000086A9D8: D6550007 03FE1707 00007FFF
	v_div_fixup_f32 v9, v13, v9, 1.0                           // 00000086A9E4: D6270009 03CA130D
	v_add_f32_e32 v8, v8, v8                                   // 00000086A9EC: 06101108
	v_div_scale_f32 v13, vcc_lo, 1.0, v5, 1.0                  // 00000086A9F0: D6FC6A0D 03CA0AF2
	global_store_b32 v[0:1], v6, off                           // 00000086A9F8: DC6A0000 007C0600
	v_div_scale_f32 v15, s0, 1.0, v12, 1.0                     // 00000086AA00: D6FC000F 03CA18F2
	global_store_b32 v[2:3], v8, off                           // 00000086AA08: DC6A0000 007C0802
	v_and_b32_e32 v2, 0xffff0000, v7                           // 00000086AA10: 36040EFF FFFF0000
	v_mul_f32_e32 v14, v13, v26                                // 00000086AA18: 101C350D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000086AA1C: BF870112
	v_mul_f32_e32 v2, s4, v2                                   // 00000086AA20: 10040404
	v_fma_f32 v7, -v20, v14, v13                               // 00000086AA24: D6130007 24361D14
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000086AA2C: BF870112
	v_mul_f32_e32 v2, 0xbfb8aa3b, v2                           // 00000086AA30: 100404FF BFB8AA3B
	v_fmac_f32_e32 v14, v7, v26                                // 00000086AA38: 561C3507
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000086AA3C: BF870122
	v_exp_f32_e32 v2, v2                                       // 00000086AA40: 7E044B02
	v_mul_f32_e32 v4, s4, v4                                   // 00000086AA44: 10080804
	v_fma_f32 v13, -v20, v14, v13                              // 00000086AA48: D613000D 24361D14
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000086AA50: BF870115
	v_add_f32_e32 v21, 1.0, v2                                 // 00000086AA54: 062A04F2
	v_div_fmas_f32 v2, v13, v26, v14                           // 00000086AA58: D6370002 043A350D
	s_mov_b32 vcc_lo, s0                                       // 00000086AA60: BEEA0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000086AA64: BF870112
	v_div_scale_f32 v14, null, v21, v21, 1.0                   // 00000086AA68: D6FC7C0E 03CA2B15
	v_div_fixup_f32 v2, v2, v5, 1.0                            // 00000086AA70: D6270002 03CA0B02
	s_delay_alu instid0(VALU_DEP_2)                            // 00000086AA78: BF870002
	v_rcp_f32_e32 v5, v14                                      // 00000086AA7C: 7E0A550E
	v_mul_f32_e32 v6, s4, v10                                  // 00000086AA80: 100C1404
	v_div_scale_f32 v10, null, v12, v12, 1.0                   // 00000086AA84: D6FC7C0A 03CA190C
	s_lshl_b64 s[4:5], s[16:17], 3                             // 00000086AA8C: 84848310
	v_add_f32_e32 v23, v2, v2                                  // 00000086AA90: 062E0502
	v_mul_f32_e32 v6, 0xbfb8aa3b, v6                           // 00000086AA94: 100C0CFF BFB8AA3B
	v_rcp_f32_e32 v11, v10                                     // 00000086AA9C: 7E16550A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000086AAA0: BF870291
	v_exp_f32_e32 v3, v6                                       // 00000086AAA4: 7E064B06
	v_dual_add_f32 v6, v9, v9 :: v_dual_add_f32 v9, 1.0, v3    // 00000086AAA8: C9081309 060806F2
	.long 0xd7000103                                           // 00000086AAB0: D7000103
	v_cndmask_b32_e32 v0, v0, v4, vcc_lo                       // 00000086AAB4: 02000900
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000086AAB8: BF870092
	v_div_scale_f32 v17, null, v9, v9, 1.0                     // 00000086AABC: D6FC7C11 03CA1309
	v_rcp_f32_e32 v19, v17                                     // 00000086AAC4: 7E265511
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000086AAC8: BF870095
	v_fma_f32 v22, -v17, v19, 1.0                              // 00000086AACC: D6130016 23CA2711
	v_dual_mul_f32 v4, 0xbfb8aa3b, v4 :: v_dual_fmac_f32 v19, v22, v19// 00000086AAD4: C8C008FF 04122716 BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 00000086AAE0: BF8702A1
	v_exp_f32_e32 v4, v4                                       // 00000086AAE4: 7E084B04
	v_div_scale_f32 v22, s2, 1.0, v9, 1.0                      // 00000086AAE8: D6FC0216 03CA12F2
	v_add_f32_e32 v8, 1.0, v4                                  // 00000086AAF0: 061008F2
	v_fma_f32 v4, -v10, v11, 1.0                               // 00000086AAF4: D6130004 23CA170A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000086AAFC: BF870112
	v_div_scale_f32 v7, null, v8, v8, 1.0                      // 00000086AB00: D6FC7C07 03CA1108
	v_fmac_f32_e32 v11, v4, v11                                // 00000086AB08: 56161704
	v_add_co_ci_u32_e64 v4, null, s5, v1, s1                   // 00000086AB0C: D5207C04 00060205
	v_mad_u64_u32 v[0:1], null, s16, 12, v[0:1]                // 00000086AB14: D6FE7C00 04011810
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000086AB1C: BF870194
	v_rcp_f32_e32 v16, v7                                      // 00000086AB20: 7E205507
	v_mul_f32_e32 v18, v15, v11                                // 00000086AB24: 1024170F
	global_store_b32 v[3:4], v6, off                           // 00000086AB28: DC6A0000 007C0603
	v_fma_f32 v13, -v10, v18, v15                              // 00000086AB30: D613000D 243E250A
	v_fma_f32 v20, -v7, v16, 1.0                               // 00000086AB38: D6130014 23CA2107
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000086AB40: BF870112
	v_fmac_f32_e32 v18, v13, v11                               // 00000086AB44: 5624170D
	v_fmac_f32_e32 v16, v20, v16                               // 00000086AB48: 56202114
	v_div_scale_f32 v20, s1, 1.0, v8, 1.0                      // 00000086AB4C: D6FC0114 03CA10F2
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000086AB54: BF870233
	v_fma_f32 v2, -v10, v18, v15                               // 00000086AB58: D6130002 243E250A
	v_mul_f32_e32 v10, v22, v19                                // 00000086AB60: 10142716
	v_fma_f32 v15, -v14, v5, 1.0                               // 00000086AB64: D613000F 23CA0B0E
	v_mul_f32_e32 v13, v20, v16                                // 00000086AB6C: 101A2114
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000086AB70: BF870224
	v_div_fmas_f32 v2, v2, v11, v18                            // 00000086AB74: D6370002 044A1702
	v_div_scale_f32 v11, s0, 1.0, v21, 1.0                     // 00000086AB7C: D6FC000B 03CA2AF2
	v_fmac_f32_e32 v5, v15, v5                                 // 00000086AB84: 560A0B0F
	s_mov_b32 vcc_lo, s1                                       // 00000086AB88: BEEA0001
	v_fma_f32 v6, -v7, v13, v20                                // 00000086AB8C: D6130006 24521B07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000086AB94: BF8701B1
	v_fmac_f32_e32 v13, v6, v16                                // 00000086AB98: 561A2106
	v_fma_f32 v6, -v17, v10, v22                               // 00000086AB9C: D6130006 245A1511
	v_div_fixup_f32 v12, v2, v12, 1.0                          // 00000086ABA4: D627000C 03CA1902
	v_fma_f32 v2, -v7, v13, v20                                // 00000086ABAC: D6130002 24521B07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000086ABB4: BF870223
	v_fmac_f32_e32 v10, v6, v19                                // 00000086ABB8: 56142706
	v_mul_f32_e32 v6, v11, v5                                  // 00000086ABBC: 100C0B0B
	v_add_f32_e32 v12, v12, v12                                // 00000086ABC0: 0618190C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000086ABC4: BF870224
	v_div_fmas_f32 v7, v2, v16, v13                            // 00000086ABC8: D6370007 04362102
	v_mad_u64_u32 v[1:2], null, s17, 12, v[1:2]                // 00000086ABD0: D6FE7C01 04051811
	v_fma_f32 v13, -v14, v6, v11                               // 00000086ABD8: D613000D 242E0D0E
	v_fma_f32 v2, -v17, v10, v22                               // 00000086ABE0: D6130002 245A1511
	s_mov_b32 vcc_lo, s2                                       // 00000086ABE8: BEEA0002
	v_div_fixup_f32 v7, v7, v8, 1.0                            // 00000086ABEC: D6270007 03CA1107
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000086ABF4: BF870193
	v_fmac_f32_e32 v6, v13, v5                                 // 00000086ABF8: 560C0B0D
	v_div_fmas_f32 v8, v2, v19, v10                            // 00000086ABFC: D6370008 042A2702
	.long 0xd7006a02                                           // 00000086AC04: D7006A02
	v_cndmask_b32_e32 v0, v3, v4, vcc_lo                       // 00000086AC08: 02000903
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000086AC0C: BF870211
	v_add_co_ci_u32_e64 v3, null, s5, v4, vcc_lo               // 00000086AC10: D5207C03 01AA0805
	v_fma_f32 v4, -v14, v6, v11                                // 00000086AC18: D6130004 242E0D0E
	s_mov_b32 vcc_lo, s0                                       // 00000086AC20: BEEA0000
	v_add_f32_e32 v10, v7, v7                                  // 00000086AC24: 06140F07
	v_div_fixup_f32 v7, v8, v9, 1.0                            // 00000086AC28: D6270007 03CA1308
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000086AC30: BF8700A3
	v_div_fmas_f32 v6, v4, v5, v6                              // 00000086AC34: D6370006 041A0B04
	.long 0xd7006a04                                           // 00000086AC3C: D7006A04
	v_cndmask_b32_e32 v0, v0, v4, vcc_lo                       // 00000086AC40: 02000900
	v_add_co_ci_u32_e64 v5, null, s5, v1, vcc_lo               // 00000086AC44: D5207C05 01AA0205
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000086AC4C: BF870243
	v_div_fixup_f32 v8, v6, v21, 1.0                           // 00000086AC50: D6270008 03CA2B06
	.long 0xd7006a06                                           // 00000086AC58: D7006A06
	v_cndmask_b32_e32 v0, v2, v4, vcc_lo                       // 00000086AC5C: 02000902
	v_add_f32_e32 v11, v7, v7                                  // 00000086AC60: 06160F07
	v_add_co_ci_u32_e64 v7, null, s5, v3, vcc_lo               // 00000086AC64: D5207C07 01AA0605
	v_add_f32_e32 v13, v8, v8                                  // 00000086AC6C: 061A1108
	.long 0xd7006a08                                           // 00000086AC70: D7006A08
	v_cndmask_b32_e32 v0, v4, v4, vcc_lo                       // 00000086AC74: 02000904
	s_delay_alu instid0(VALU_DEP_1)                            // 00000086AC78: BF870001
	v_add_co_ci_u32_e64 v9, null, s5, v5, vcc_lo               // 00000086AC7C: D5207C09 01AA0A05
	s_clause 0x4                                               // 00000086AC84: BF850004
	global_store_b32 v[0:1], v23, off                          // 00000086AC88: DC6A0000 007C1700
	global_store_b32 v[2:3], v12, off                          // 00000086AC90: DC6A0000 007C0C02
	global_store_b32 v[4:5], v10, off                          // 00000086AC98: DC6A0000 007C0A04
	global_store_b32 v[6:7], v11, off                          // 00000086ACA0: DC6A0000 007C0B06
	global_store_b32 v[8:9], v13, off                          // 00000086ACA8: DC6A0000 007C0D08
	s_endpgm                                                   // 00000086ACB0: BFB00000
		...

