0000000000839400 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[8:23], s[0:1], null                          // 000000839400: F4100200 F8000000
	v_and_b32_e32 v1, 15, v0                                   // 000000839408: 3602008F
	v_lshrrev_b32_e32 v2, 2, v0                                // 00000083940C: 32040082
	s_ashr_i32 s3, s2, 31                                      // 000000839410: 86039F02
	v_lshrrev_b32_e32 v3, 5, v0                                // 000000839414: 32060085
	s_lshl_b64 s[2:3], s[2:3], 3                               // 000000839418: 84828302
	v_lshlrev_b32_e32 v1, 2, v1                                // 00000083941C: 30020282
	v_dual_mov_b32 v17, s3 :: v_dual_and_b32 v2, 60, v2        // 000000839420: CA240003 110204BC
	s_delay_alu instid0(VALU_DEP_3)                            // 000000839428: BF870003
	v_or_b32_e32 v16, s2, v3                                   // 00000083942C: 38200602
	.long 0x7f063880                                           // 000000839430: 7F063880
	v_and_b32_e32 v23, 31, v0                                  // 000000839434: 362E009F
	v_lshlrev_b32_e32 v0, 2, v0                                // 000000839438: 30000082
	s_waitcnt lgkmcnt(0)                                       // 00000083943C: BF89FC07
	s_clause 0x1                                               // 000000839440: BF850001
	global_load_b32 v1, v1, s[8:9]                             // 000000839444: DC520000 01080001
	global_load_b32 v2, v2, s[8:9]                             // 00000083944C: DC520000 02080002
	.long 0xd4540002                                           // 000000839454: D4540002
	v_cndmask_b32_e32 v1, s16, v16, vcc_lo                     // 000000839458: 02022010
	s_add_u32 s24, s8, s20                                     // 00000083945C: 80181408
	s_addc_u32 s25, s9, s21                                    // 000000839460: 82191509
	s_ashr_i32 s4, s15, 31                                     // 000000839464: 86049F0F
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000839468: BF870159
	s_lshr_b32 s4, s4, 27                                      // 00000083946C: 85049B04
	v_cndmask_b32_e64 v8, 0, v16, s2                           // 000000839470: D5010008 000A2080
	v_cndmask_b32_e64 v9, 0, s3, s2                            // 000000839478: D5010009 00080680
	s_add_u32 s4, s14, s4                                      // 000000839480: 8004040E
	s_addc_u32 s5, s15, 0                                      // 000000839484: 8205800F
	.long 0xd72c0004                                           // 000000839488: D72C0004
	v_cndmask_b32_e32 v1, s23, v8, vcc_lo                      // 00000083948C: 02021017
	v_mad_u64_u32 v[12:13], null, s22, v8, 0                   // 000000839490: D6FE7C0C 02021016
	s_lshr_b64 s[6:7], s[4:5], 5                               // 000000839498: 85868504
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000083949C: BF870009
	s_cmpk_lt_i32 s6, 0x101                                    // 0000008394A0: B3860101
	.long 0xd4440004                                           // 0000008394A4: D4440004
	v_cndmask_b32_e32 v1, s6, v23, vcc_lo                      // 0000008394A8: 02022E06
	s_cselect_b32 s3, -1, 0                                    // 0000008394AC: 980380C1
	s_cmpk_gt_i32 s6, 0x100                                    // 0000008394B0: B2860100
	.long 0xd700050e                                           // 0000008394B4: D700050E
	v_cndmask_b32_e32 v1, s24, v12, vcc_lo                     // 0000008394B8: 02021818
	s_cselect_b32 s7, -1, 0                                    // 0000008394BC: 980780C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000008394C0: BF870159
	s_and_b32 vcc_lo, exec_lo, s7                              // 0000008394C4: 8B6A077E
	s_waitcnt vmcnt(1)                                         // 0000008394C8: BF8907F7
	v_bfe_u32 v5, v1, 16, 1                                    // 0000008394CC: D6100005 02052101
	s_waitcnt vmcnt(0)                                         // 0000008394D4: BF8903F7
	v_bfe_u32 v6, v2, 16, 1                                    // 0000008394D8: D6100006 02052102
	v_add3_u32 v1, v1, v5, 0x7fff                              // 0000008394E0: D6550001 03FE0B01 00007FFF
	.long 0xd72c0005                                           // 0000008394EC: D72C0005
	v_cndmask_b32_e32 v1, s22, v9, vcc_lo                      // 0000008394F0: 02021216
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008394F4: BF870193
	v_add3_u32 v2, v2, v6, 0x7fff                              // 0000008394F8: D6550002 03FE0D02 00007FFF
	.long 0x7e063981                                           // 000000839504: 7E063981
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000839508: BF870113
	v_add3_u32 v13, v13, v5, v4                                // 00000083950C: D655000D 04120B0D
	v_and_or_b32 v1, 0xffff0000, v2, v3                        // 000000839514: D6570001 040E04FF FFFF0000
	s_delay_alu instid0(VALU_DEP_2)                            // 000000839520: BF870002
	v_add_co_ci_u32_e64 v15, null, s25, v13, s5                // 000000839524: D5207C0F 00161A19
	ds_store_b32 v0, v1                                        // 00000083952C: D8340000 00000100
	s_waitcnt lgkmcnt(0)                                       // 000000839534: BF89FC07
	s_barrier                                                  // 000000839538: BFBD0000
	buffer_gl0_inv                                             // 00000083953C: E0AC0000 00000000
	s_cbranch_vccnz 146                                        // 000000839544: BFA40092 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x390>
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v0, 0               // 000000839548: CA100080 01000080
	s_and_saveexec_b32 s5, s4                                  // 000000839550: BE852004
	s_cbranch_execz 10                                         // 000000839554: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x180>
	v_lshlrev_b32_e32 v0, 1, v23                               // 000000839558: 30002E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000083955C: BF870091
	.long 0xd7006a02                                           // 000000839560: D7006A02
	v_cndmask_b32_e32 v1, v14, v0, vcc_lo                      // 000000839564: 0202010E
	v_add_co_ci_u32_e64 v3, null, 0, v15, vcc_lo               // 000000839568: D5207C03 01AA1E80
	global_load_d16_b16 v0, v[2:3], off                        // 000000839570: DC820000 007C0002
	s_waitcnt vmcnt(0)                                         // 000000839578: BF8903F7
	v_cvt_f32_f16_e32 v0, v0                                   // 00000083957C: 7E001700
	s_or_b32 exec_lo, exec_lo, s5                              // 000000839580: 8C7E057E
	v_or_b32_e32 v2, 32, v23                                   // 000000839584: 38042EA0
	s_mov_b32 s4, exec_lo                                      // 000000839588: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000083958C: BF870001
	.long 0xd4c4007e                                           // 000000839590: D4C4007E
	v_cndmask_b32_e32 v1, s6, v2, vcc_lo                       // 000000839594: 02020406
	s_cbranch_execz 10                                         // 000000839598: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x1c4>
	v_lshlrev_b32_e32 v1, 1, v2                                // 00000083959C: 30020481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008395A0: BF870091
	.long 0xd7006a01                                           // 0000008395A4: D7006A01
	v_cndmask_b32_e32 v1, v14, v1, vcc_lo                      // 0000008395A8: 0202030E
	v_add_co_ci_u32_e64 v2, null, 0, v15, vcc_lo               // 0000008395AC: D5207C02 01AA1E80
	global_load_d16_b16 v1, v[1:2], off                        // 0000008395B4: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000008395BC: BF8903F7
	v_cvt_f32_f16_e32 v1, v1                                   // 0000008395C0: 7E021701
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008395C4: 8C7E047E
	v_or_b32_e32 v4, 64, v23                                   // 0000008395C8: 38082EC0
	v_dual_mov_b32 v3, 0 :: v_dual_mov_b32 v2, 0               // 0000008395CC: CA100080 03020080
	s_mov_b32 s4, exec_lo                                      // 0000008395D4: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008395D8: BF870002
	.long 0xd4c4007e                                           // 0000008395DC: D4C4007E
	v_cndmask_b32_e32 v1, s6, v4, vcc_lo                       // 0000008395E0: 02020806
	s_cbranch_execz 10                                         // 0000008395E4: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x210>
	v_lshlrev_b32_e32 v2, 1, v4                                // 0000008395E8: 30040881
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008395EC: BF870091
	.long 0xd7006a04                                           // 0000008395F0: D7006A04
	v_cndmask_b32_e32 v1, v14, v2, vcc_lo                      // 0000008395F4: 0202050E
	v_add_co_ci_u32_e64 v5, null, 0, v15, vcc_lo               // 0000008395F8: D5207C05 01AA1E80
	global_load_d16_b16 v2, v[4:5], off                        // 000000839600: DC820000 027C0004
	s_waitcnt vmcnt(0)                                         // 000000839608: BF8903F7
	v_cvt_f32_f16_e32 v2, v2                                   // 00000083960C: 7E041702
	s_or_b32 exec_lo, exec_lo, s4                              // 000000839610: 8C7E047E
	v_or_b32_e32 v4, 0x60, v23                                 // 000000839614: 38082EFF 00000060
	s_mov_b32 s4, exec_lo                                      // 00000083961C: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000839620: BF870001
	.long 0xd4c4007e                                           // 000000839624: D4C4007E
	v_cndmask_b32_e32 v1, s6, v4, vcc_lo                       // 000000839628: 02020806
	s_cbranch_execz 10                                         // 00000083962C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x258>
	v_lshlrev_b32_e32 v3, 1, v4                                // 000000839630: 30060881
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000839634: BF870091
	.long 0xd7006a03                                           // 000000839638: D7006A03
	v_cndmask_b32_e32 v1, v14, v3, vcc_lo                      // 00000083963C: 0202070E
	v_add_co_ci_u32_e64 v4, null, 0, v15, vcc_lo               // 000000839640: D5207C04 01AA1E80
	global_load_d16_b16 v3, v[3:4], off                        // 000000839648: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 000000839650: BF8903F7
	v_cvt_f32_f16_e32 v3, v3                                   // 000000839654: 7E061703
	s_or_b32 exec_lo, exec_lo, s4                              // 000000839658: 8C7E047E
	v_or_b32_e32 v6, 0x80, v23                                 // 00000083965C: 380C2EFF 00000080
	v_dual_mov_b32 v5, 0 :: v_dual_mov_b32 v4, 0               // 000000839664: CA100080 05040080
	s_mov_b32 s4, exec_lo                                      // 00000083966C: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000839670: BF870002
	.long 0xd4c4007e                                           // 000000839674: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 000000839678: 02020C06
	s_cbranch_execz 10                                         // 00000083967C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x2a8>
	v_lshlrev_b32_e32 v4, 1, v6                                // 000000839680: 30080C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000839684: BF870091
	.long 0xd7006a06                                           // 000000839688: D7006A06
	v_cndmask_b32_e32 v1, v14, v4, vcc_lo                      // 00000083968C: 0202090E
	v_add_co_ci_u32_e64 v7, null, 0, v15, vcc_lo               // 000000839690: D5207C07 01AA1E80
	global_load_d16_b16 v4, v[6:7], off                        // 000000839698: DC820000 047C0006
	s_waitcnt vmcnt(0)                                         // 0000008396A0: BF8903F7
	v_cvt_f32_f16_e32 v4, v4                                   // 0000008396A4: 7E081704
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008396A8: 8C7E047E
	v_or_b32_e32 v6, 0xa0, v23                                 // 0000008396AC: 380C2EFF 000000A0
	s_mov_b32 s4, exec_lo                                      // 0000008396B4: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008396B8: BF870001
	.long 0xd4c4007e                                           // 0000008396BC: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 0000008396C0: 02020C06
	s_cbranch_execz 10                                         // 0000008396C4: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x2f0>
	v_lshlrev_b32_e32 v5, 1, v6                                // 0000008396C8: 300A0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008396CC: BF870091
	.long 0xd7006a05                                           // 0000008396D0: D7006A05
	v_cndmask_b32_e32 v1, v14, v5, vcc_lo                      // 0000008396D4: 02020B0E
	v_add_co_ci_u32_e64 v6, null, 0, v15, vcc_lo               // 0000008396D8: D5207C06 01AA1E80
	global_load_d16_b16 v5, v[5:6], off                        // 0000008396E0: DC820000 057C0005
	s_waitcnt vmcnt(0)                                         // 0000008396E8: BF8903F7
	v_cvt_f32_f16_e32 v5, v5                                   // 0000008396EC: 7E0A1705
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008396F0: 8C7E047E
	v_or_b32_e32 v10, 0xc0, v23                                // 0000008396F4: 38142EFF 000000C0
	v_dual_mov_b32 v7, 0 :: v_dual_mov_b32 v6, 0               // 0000008396FC: CA100080 07060080
	s_mov_b32 s4, exec_lo                                      // 000000839704: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000839708: BF870002
	.long 0xd4c4007e                                           // 00000083970C: D4C4007E
	v_cndmask_b32_e32 v1, s6, v10, vcc_lo                      // 000000839710: 02021406
	s_cbranch_execz 10                                         // 000000839714: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x340>
	v_lshlrev_b32_e32 v6, 1, v10                               // 000000839718: 300C1481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000083971C: BF870091
	.long 0xd7006a0a                                           // 000000839720: D7006A0A
	v_cndmask_b32_e32 v1, v14, v6, vcc_lo                      // 000000839724: 02020D0E
	v_add_co_ci_u32_e64 v11, null, 0, v15, vcc_lo              // 000000839728: D5207C0B 01AA1E80
	global_load_d16_b16 v6, v[10:11], off                      // 000000839730: DC820000 067C000A
	s_waitcnt vmcnt(0)                                         // 000000839738: BF8903F7
	v_cvt_f32_f16_e32 v6, v6                                   // 00000083973C: 7E0C1706
	s_or_b32 exec_lo, exec_lo, s4                              // 000000839740: 8C7E047E
	v_or_b32_e32 v10, 0xe0, v23                                // 000000839744: 38142EFF 000000E0
	s_mov_b32 s4, exec_lo                                      // 00000083974C: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000839750: BF870001
	.long 0xd4c4007e                                           // 000000839754: D4C4007E
	v_cndmask_b32_e32 v1, s6, v10, vcc_lo                      // 000000839758: 02021406
	s_cbranch_execz 10                                         // 00000083975C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x388>
	v_lshlrev_b32_e32 v7, 1, v10                               // 000000839760: 300E1481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000839764: BF870091
	.long 0xd7006a0a                                           // 000000839768: D7006A0A
	v_cndmask_b32_e32 v1, v14, v7, vcc_lo                      // 00000083976C: 02020F0E
	v_add_co_ci_u32_e64 v11, null, 0, v15, vcc_lo              // 000000839770: D5207C0B 01AA1E80
	global_load_d16_b16 v7, v[10:11], off                      // 000000839778: DC820000 077C000A
	s_waitcnt vmcnt(0)                                         // 000000839780: BF8903F7
	v_cvt_f32_f16_e32 v7, v7                                   // 000000839784: 7E0E1707
	s_or_b32 exec_lo, exec_lo, s4                              // 000000839788: 8C7E047E
	s_branch 9                                                 // 00000083978C: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x3b4>
	v_mov_b32_e32 v0, 0                                        // 000000839790: 7E000280
	s_delay_alu instid0(VALU_DEP_1)                            // 000000839794: BF870001
	v_mov_b32_e32 v1, v0                                       // 000000839798: 7E020300
	v_mov_b32_e32 v2, v0                                       // 00000083979C: 7E040300
	v_mov_b32_e32 v3, v0                                       // 0000008397A0: 7E060300
	v_mov_b32_e32 v4, v0                                       // 0000008397A4: 7E080300
	v_mov_b32_e32 v5, v0                                       // 0000008397A8: 7E0A0300
	v_mov_b32_e32 v6, v0                                       // 0000008397AC: 7E0C0300
	v_mov_b32_e32 v7, v0                                       // 0000008397B0: 7E0E0300
	s_add_u32 s4, s8, s18                                      // 0000008397B4: 80041208
	s_addc_u32 s5, s9, s19                                     // 0000008397B8: 82051309
	s_lshr_b32 s18, s15, 31                                    // 0000008397BC: 85129F0F
	v_mov_b32_e32 v26, 0                                       // 0000008397C0: 7E340280
	s_add_u32 s18, s14, s18                                    // 0000008397C4: 8012120E
	s_addc_u32 s19, s15, 0                                     // 0000008397C8: 8213800F
	v_cndmask_b32_e64 v24, 0, 1, s7                            // 0000008397CC: D5010018 001D0280
	s_ashr_i64 s[18:19], s[18:19], 1                           // 0000008397D4: 86928112
	v_mov_b32_e32 v27, 0                                       // 0000008397D8: 7E360280
	v_mad_u64_u32 v[18:19], null, v8, s18, s[4:5]              // 0000008397DC: D6FE7C12 00102508
	.long 0xd72c000b                                           // 0000008397E4: D72C000B
	v_cndmask_b32_e32 v0, v8, v19, vcc_lo                      // 0000008397E8: 02002708
	.long 0xd72c0014                                           // 0000008397EC: D72C0014
	v_cndmask_b32_e32 v0, v9, v18, vcc_lo                      // 0000008397F0: 02002509
	.long 0xd4440004                                           // 0000008397F4: D4440004
	v_cndmask_b32_e32 v1, s6, v23, vcc_lo                      // 0000008397F8: 02022E06
	v_dual_mov_b32 v8, 0 :: v_dual_mov_b32 v9, 0               // 0000008397FC: CA100080 08080080
	v_mov_b32_e32 v10, 0                                       // 000000839804: 7E140280
	s_delay_alu instid0(VALU_DEP_4)                            // 000000839808: BF870004
	v_add3_u32 v25, v20, v19, v11                              // 00000083980C: D6550019 042E2714
	v_mov_b32_e32 v11, 0                                       // 000000839814: 7E160280
	s_and_saveexec_b32 s5, s4                                  // 000000839818: BE852004
	s_cbranch_execz 21                                         // 00000083981C: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x474>
	v_dual_mov_b32 v27, 0 :: v_dual_lshlrev_b32 v8, 4, v23     // 000000839820: CA220080 1B082E84
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000839828: BF870091
	.long 0xd7006a08                                           // 00000083982C: D7006A08
	v_cndmask_b32_e32 v1, v18, v8, vcc_lo                      // 000000839830: 02021112
	v_add_co_ci_u32_e64 v9, null, 0, v25, vcc_lo               // 000000839834: D5207C09 01AA3280
	s_and_not1_b32 vcc_lo, exec_lo, s7                         // 00000083983C: 916A077E
	global_load_b128 v[8:11], v[8:9], off                      // 000000839840: DC5E0000 087C0008
	s_cbranch_vccnz 10                                         // 000000839848: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x474>
	v_lshlrev_b32_e32 v19, 1, v23                              // 00000083984C: 30262E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000839850: BF870091
	.long 0xd7006a0e                                           // 000000839854: D7006A0E
	v_cndmask_b32_e32 v1, v14, v19, vcc_lo                     // 000000839858: 0202270E
	v_add_co_ci_u32_e64 v15, null, 0, v15, vcc_lo              // 00000083985C: D5207C0F 01AA1E80
	global_load_d16_b16 v14, v[14:15], off                     // 000000839864: DC820000 0E7C000E
	s_waitcnt vmcnt(0)                                         // 00000083986C: BF8903F7
	v_cvt_f32_f16_e32 v27, v14                                 // 000000839870: 7E36170E
	s_or_b32 exec_lo, exec_lo, s5                              // 000000839874: 8C7E057E
	v_mov_b32_e32 v28, 0                                       // 000000839878: 7E380280
	s_and_saveexec_b32 s5, s4                                  // 00000083987C: BE852004
	s_cbranch_execz 305                                        // 000000839880: BFA50131 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x948>
	v_dual_mov_b32 v31, v27 :: v_dual_lshlrev_b32 v14, 1, v23  // 000000839884: CA22011B 1F0E2E81
	.long 0xd7006a0c                                           // 00000083988C: D7006A0C
	v_cndmask_b32_e32 v1, s20, v12, vcc_lo                     // 000000839890: 02021814
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000839894: BF8701A1
	v_add_co_ci_u32_e64 v13, null, s21, v13, vcc_lo            // 000000839898: D5207C0D 01AA1A15
	v_dual_mov_b32 v20, 0 :: v_dual_lshlrev_b32 v19, 5, v23    // 0000008398A0: CA220080 14122E85
	.long 0xd7006a0c                                           // 0000008398A8: D7006A0C
	v_cndmask_b32_e32 v1, v12, v14, vcc_lo                     // 0000008398AC: 02021D0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008398B0: BF8701A1
	v_add_co_ci_u32_e64 v13, null, 0, v13, vcc_lo              // 0000008398B4: D5207C0D 01AA1A80
	v_lshl_or_b32 v29, v23, 4, 0x200                           // 0000008398BC: D656001D 03FD0917 00000200
	.long 0xd7006a0c                                           // 0000008398C8: D7006A0C
	v_cndmask_b32_e32 v1, s8, v12, vcc_lo                      // 0000008398CC: 02021808
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008398D0: BF8701A1
	v_add_co_ci_u32_e64 v13, null, s9, v13, vcc_lo             // 0000008398D4: D5207C0D 01AA1A09
	v_mov_b32_e32 v30, v23                                     // 0000008398DC: 7E3C0317
	.long 0xd7006a15                                           // 0000008398E0: D7006A15
	v_cndmask_b32_e32 v0, v12, v192, vcc_lo                    // 0000008398E4: 0201810C
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008398E8: BF870001
	v_add_co_ci_u32_e64 v22, null, 0, v13, vcc_lo              // 0000008398EC: D5207C16 01AA1A80
	v_mov_b32_e32 v28, v20                                     // 0000008398F4: 7E380314
	v_mov_b32_e32 v26, v20                                     // 0000008398F8: 7E340314
	s_mov_b32 s7, 0                                            // 0000008398FC: BE870080
	s_lshl_b64 s[8:9], s[14:15], 1                             // 000000839900: 8488810E
	s_branch 243                                               // 000000839904: BFA000F3 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x8d4>
	s_or_b32 exec_lo, exec_lo, s14                             // 000000839908: 8C7E0E7E
	.long 0xd73c0020                                           // 00000083990C: D73C0020
	v_cndmask_b32_e32 v1, 1, v19, vcc_lo                       // 000000839910: 02022681
	v_and_b32_e32 v64, 0xff, v8                                // 000000839914: 368010FF 000000FF
	v_lshrrev_b32_e32 v65, 6, v8                               // 00000083991C: 32821086
	v_lshrrev_b32_e32 v66, 14, v8                              // 000000839920: 3284108E
	v_lshrrev_b32_e32 v8, 22, v8                               // 000000839924: 32101096
	v_and_b32_e32 v67, 0xff, v9                                // 000000839928: 368612FF 000000FF
	.long 0xd7006a38                                           // 000000839930: D7006A38
	v_cndmask_b32_e32 v1, s10, v32, vcc_lo                     // 000000839934: 0202400A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000839938: BF8701A1
	v_add_co_ci_u32_e64 v57, null, s11, v33, vcc_lo            // 00000083993C: D5207C39 01AA420B
	v_lshlrev_b32_e32 v64, 2, v64                              // 000000839944: 30808082
	.long 0xd7006a3c                                           // 000000839948: D7006A3C
	v_cndmask_b32_e32 v0, v56, v8, vcc_lo                      // 00000083994C: 02001138
	s_delay_alu instid0(VALU_DEP_1)                            // 000000839950: BF870001
	v_add_co_ci_u32_e64 v61, null, s9, v57, vcc_lo             // 000000839954: D5207C3D 01AA7209
	v_and_b32_e32 v65, 0x3fc, v65                              // 00000083995C: 368282FF 000003FC
	ds_load_b32 v64, v64                                       // 000000839964: D8D80000 40000040
	s_clause 0x7                                               // 00000083996C: BF850007
	global_load_b128 v[32:35], v[56:57], off                   // 000000839970: DC5E0000 207C0038
	global_load_b128 v[36:39], v[60:61], off                   // 000000839978: DC5E0000 247C003C
	global_load_b128 v[40:43], v[56:57], off offset:16         // 000000839980: DC5E0010 287C0038
	global_load_b128 v[44:47], v[60:61], off offset:16         // 000000839988: DC5E0010 2C7C003C
	global_load_b128 v[48:51], v[56:57], off offset:32         // 000000839990: DC5E0020 307C0038
	global_load_b128 v[52:55], v[60:61], off offset:32         // 000000839998: DC5E0020 347C003C
	global_load_b128 v[56:59], v[56:57], off offset:48         // 0000008399A0: DC5E0030 387C0038
	global_load_b128 v[60:63], v[60:61], off offset:48         // 0000008399A8: DC5E0030 3C7C003C
	v_and_b32_e32 v66, 0x3fc, v66                              // 0000008399B0: 368484FF 000003FC
	v_lshrrev_b32_e32 v68, 6, v9                               // 0000008399B8: 32881286
	ds_load_b32 v65, v65                                       // 0000008399BC: D8D80000 41000041
	v_lshrrev_b32_e32 v69, 14, v9                              // 0000008399C4: 328A128E
	v_lshrrev_b32_e32 v9, 22, v9                               // 0000008399C8: 32121296
	ds_load_b32 v66, v66                                       // 0000008399CC: D8D80000 42000042
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008399D4: 361010FF 000003FC
	v_lshlrev_b32_e32 v67, 2, v67                              // 0000008399DC: 30868682
	v_and_b32_e32 v68, 0x3fc, v68                              // 0000008399E0: 368888FF 000003FC
	v_and_b32_e32 v69, 0x3fc, v69                              // 0000008399E8: 368A8AFF 000003FC
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000008399F0: 361212FF 000003FC
	ds_load_b32 v8, v8                                         // 0000008399F8: D8D80000 08000008
	ds_load_b32 v67, v67                                       // 000000839A00: D8D80000 43000043
	ds_load_b32 v68, v68                                       // 000000839A08: D8D80000 44000044
	ds_load_b32 v69, v69                                       // 000000839A10: D8D80000 45000045
	ds_load_b32 v9, v9                                         // 000000839A18: D8D80000 09000009
	.long 0xd7006a15                                           // 000000839A20: D7006A15
	v_cndmask_b32_e32 v0, v21, v192, vcc_lo                    // 000000839A24: 02018115
	v_add_nc_u32_e32 v29, 0x200, v29                           // 000000839A28: 4A3A3AFF 00000200
	v_add_co_ci_u32_e64 v22, null, 0, v22, vcc_lo              // 000000839A30: D5207C16 01AA2C80
	s_and_b32 s4, exec_lo, s4                                  // 000000839A38: 8B04047E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000839A3C: BF870009
	s_or_b32 s7, s4, s7                                        // 000000839A40: 8C070704
	s_waitcnt vmcnt(7) lgkmcnt(7)                              // 000000839A44: BF891C77
	v_dot2_f32_bf16 v32, v32, v64, 0                           // 000000839A48: CC1A4020 1A028120
	s_waitcnt vmcnt(6)                                         // 000000839A50: BF891BF7
	v_dot2_f32_bf16 v36, v36, v64, 0                           // 000000839A54: CC1A4024 1A028124
	v_and_b32_e32 v64, 0xff, v10                               // 000000839A5C: 368014FF 000000FF
	s_waitcnt lgkmcnt(6)                                       // 000000839A64: BF89FC67
	v_dot2_f32_bf16 v32, v33, v65, v32                         // 000000839A68: CC1A4020 1C828321
	s_delay_alu instid0(VALU_DEP_3)                            // 000000839A70: BF870003
	v_dot2_f32_bf16 v33, v37, v65, v36                         // 000000839A74: CC1A4021 1C928325
	v_lshrrev_b32_e32 v36, 6, v10                              // 000000839A7C: 32481486
	v_lshrrev_b32_e32 v37, 14, v10                             // 000000839A80: 324A148E
	v_lshrrev_b32_e32 v10, 22, v10                             // 000000839A84: 32141496
	s_waitcnt lgkmcnt(5)                                       // 000000839A88: BF89FC57
	v_dot2_f32_bf16 v32, v34, v66, v32                         // 000000839A8C: CC1A4020 1C828522
	v_dot2_f32_bf16 v33, v38, v66, v33                         // 000000839A94: CC1A4021 1C868526
	v_and_b32_e32 v34, 0xff, v11                               // 000000839A9C: 364416FF 000000FF
	v_lshrrev_b32_e32 v38, 6, v11                              // 000000839AA4: 324C1686
	v_lshrrev_b32_e32 v65, 14, v11                             // 000000839AA8: 3282168E
	s_waitcnt lgkmcnt(4)                                       // 000000839AAC: BF89FC47
	v_dot2_f32_bf16 v32, v35, v8, v32                          // 000000839AB0: CC1A4020 1C821123
	v_dot2_f32_bf16 v8, v39, v8, v33                           // 000000839AB8: CC1A4008 1C861127
	v_and_b32_e32 v35, 0x3fc, v36                              // 000000839AC0: 364648FF 000003FC
	v_and_b32_e32 v36, 0x3fc, v37                              // 000000839AC8: 36484AFF 000003FC
	v_lshrrev_b32_e32 v11, 22, v11                             // 000000839AD0: 32161696
	s_waitcnt vmcnt(5) lgkmcnt(3)                              // 000000839AD4: BF891437
	v_dot2_f32_bf16 v32, v40, v67, v32                         // 000000839AD8: CC1A4020 1C828728
	s_waitcnt vmcnt(4)                                         // 000000839AE0: BF8913F7
	v_dot2_f32_bf16 v8, v44, v67, v8                           // 000000839AE4: CC1A4008 1C22872C
	v_and_b32_e32 v10, 0x3fc, v10                              // 000000839AEC: 361414FF 000003FC
	v_lshlrev_b32_e32 v34, 2, v34                              // 000000839AF4: 30444482
	v_and_b32_e32 v37, 0x3fc, v38                              // 000000839AF8: 364A4CFF 000003FC
	s_waitcnt lgkmcnt(2)                                       // 000000839B00: BF89FC27
	v_dot2_f32_bf16 v32, v41, v68, v32                         // 000000839B04: CC1A4020 1C828929
	v_dot2_f32_bf16 v8, v45, v68, v8                           // 000000839B0C: CC1A4008 1C22892D
	v_and_b32_e32 v38, 0x3fc, v65                              // 000000839B14: 364C82FF 000003FC
	v_and_b32_e32 v11, 0x3fc, v11                              // 000000839B1C: 361616FF 000003FC
	ds_load_b32 v35, v35                                       // 000000839B24: D8D80000 23000023
	ds_load_b32 v36, v36                                       // 000000839B2C: D8D80000 24000024
	s_waitcnt lgkmcnt(3)                                       // 000000839B34: BF89FC37
	v_dot2_f32_bf16 v32, v42, v69, v32                         // 000000839B38: CC1A4020 1C828B2A
	v_cndmask_b32_e64 v42, v27, v0, s3                         // 000000839B40: D501002A 000E011B
	v_lshlrev_b32_e32 v33, 2, v64                              // 000000839B48: 30428082
	v_dot2_f32_bf16 v8, v46, v69, v8                           // 000000839B4C: CC1A4008 1C228B2E
	v_mov_b32_e32 v27, v31                                     // 000000839B54: 7E36031F
	s_waitcnt lgkmcnt(2)                                       // 000000839B58: BF89FC27
	v_dot2_f32_bf16 v32, v43, v9, v32                          // 000000839B5C: CC1A4020 1C82132B
	ds_load_b32 v33, v33                                       // 000000839B64: D8D80000 21000021
	v_dot2_f32_bf16 v8, v47, v9, v8                            // 000000839B6C: CC1A4008 1C22132F
	ds_load_b32 v9, v10                                        // 000000839B74: D8D80000 0900000A
	ds_load_b32 v10, v34                                       // 000000839B7C: D8D80000 0A000022
	ds_load_b32 v39, v37                                       // 000000839B84: D8D80000 27000025
	ds_load_b32 v40, v38                                       // 000000839B8C: D8D80000 28000026
	ds_load_b32 v41, v11                                       // 000000839B94: D8D80000 2900000B
	v_cndmask_b32_e64 v37, v5, v6, s3                          // 000000839B9C: D5010025 000E0D05
	v_cndmask_b32_e64 v38, v6, v7, s3                          // 000000839BA4: D5010026 000E0F06
	v_cndmask_b32_e64 v34, v2, v3, s3                          // 000000839BAC: D5010022 000E0702
	s_waitcnt vmcnt(3) lgkmcnt(5)                              // 000000839BB4: BF890C57
	v_dot2_f32_bf16 v11, v48, v33, v32                         // 000000839BB8: CC1A400B 1C824330
	s_waitcnt vmcnt(2)                                         // 000000839BC0: BF890BF7
	v_dot2_f32_bf16 v8, v52, v33, v8                           // 000000839BC4: CC1A4008 1C224334
	v_cndmask_b32_e64 v33, v1, v2, s3                          // 000000839BCC: D5010021 000E0501
	v_cndmask_b32_e64 v32, v0, v1, s3                          // 000000839BD4: D5010020 000E0300
	v_dot2_f32_bf16 v11, v49, v35, v11                         // 000000839BDC: CC1A400B 1C2E4731
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000839BE4: BF8701A4
	v_dot2_f32_bf16 v8, v53, v35, v8                           // 000000839BE8: CC1A4008 1C224735
	v_cndmask_b32_e64 v35, v3, v4, s3                          // 000000839BF0: D5010023 000E0903
	v_dot2_f32_bf16 v11, v50, v36, v11                         // 000000839BF8: CC1A400B 1C2E4932
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000839C00: BF8701B3
	v_dot2_f32_bf16 v8, v54, v36, v8                           // 000000839C04: CC1A4008 1C224936
	v_cndmask_b32_e64 v36, v4, v5, s3                          // 000000839C0C: D5010024 000E0B04
	s_waitcnt lgkmcnt(4)                                       // 000000839C14: BF89FC47
	v_dot2_f32_bf16 v11, v51, v9, v11                          // 000000839C18: CC1A400B 1C2E1333
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000839C20: BF8701B3
	v_dot2_f32_bf16 v8, v55, v9, v8                            // 000000839C24: CC1A4008 1C221337
	v_mov_b32_e32 v9, v13                                      // 000000839C2C: 7E12030D
	s_waitcnt vmcnt(1) lgkmcnt(3)                              // 000000839C30: BF890437
	v_dot2_f32_bf16 v4, v56, v10, v11                          // 000000839C34: CC1A4004 1C2E1538
	s_waitcnt vmcnt(0)                                         // 000000839C3C: BF8903F7
	v_dot2_f32_bf16 v5, v60, v10, v8                           // 000000839C40: CC1A4005 1C22153C
	v_dual_mov_b32 v11, v15 :: v_dual_mov_b32 v10, v14         // 000000839C48: CA10010F 0B0A010E
	v_mov_b32_e32 v8, v12                                      // 000000839C50: 7E10030C
	s_waitcnt lgkmcnt(2)                                       // 000000839C54: BF89FC27
	v_dot2_f32_bf16 v0, v57, v39, v4                           // 000000839C58: CC1A4000 1C124F39
	v_dot2_f32_bf16 v1, v61, v39, v5                           // 000000839C60: CC1A4001 1C164F3D
	v_mov_b32_e32 v39, v7                                      // 000000839C68: 7E4E0307
	v_add_nc_u32_e32 v19, 0x400, v19                           // 000000839C6C: 4A2626FF 00000400
	s_waitcnt lgkmcnt(1)                                       // 000000839C74: BF89FC17
	v_dot2_f32_bf16 v0, v58, v40, v0                           // 000000839C78: CC1A4000 1C02513A
	v_dot2_f32_bf16 v1, v62, v40, v1                           // 000000839C80: CC1A4001 1C06513E
	s_waitcnt lgkmcnt(0)                                       // 000000839C88: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000839C8C: BF870112
	v_dot2_f32_bf16 v0, v59, v41, v0                           // 000000839C90: CC1A4000 1C02533B
	v_dot2_f32_bf16 v1, v63, v41, v1                           // 000000839C98: CC1A4001 1C06533F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000839CA0: BF870112
	v_fmac_f32_e32 v28, v42, v0                                // 000000839CA4: 5638012A
	v_fmac_f32_e32 v26, v42, v1                                // 000000839CA8: 5634032A
	v_dual_mov_b32 v0, v32 :: v_dual_mov_b32 v1, v33           // 000000839CAC: CA100120 00000121
	v_dual_mov_b32 v2, v34 :: v_dual_mov_b32 v3, v35           // 000000839CB4: CA100122 02020123
	v_dual_mov_b32 v4, v36 :: v_dual_mov_b32 v5, v37           // 000000839CBC: CA100124 04040125
	v_dual_mov_b32 v6, v38 :: v_dual_mov_b32 v7, v39           // 000000839CC4: CA100126 06060127
	s_and_not1_b32 exec_lo, exec_lo, s7                        // 000000839CCC: 917E077E
	s_cbranch_execz 28                                         // 000000839CD0: BFA5001C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x944>
	s_waitcnt vmcnt(0)                                         // 000000839CD4: BF8903F7
	v_dual_mov_b32 v13, v9 :: v_dual_add_nc_u32 v30, 32, v30   // 000000839CD8: CA200109 0D1E3CA0
	v_dual_mov_b32 v12, v8 :: v_dual_mov_b32 v15, v11          // 000000839CE0: CA100108 0C0E010B
	v_mov_b32_e32 v14, v10                                     // 000000839CE8: 7E1C030A
	s_delay_alu instid0(VALU_DEP_3)                            // 000000839CEC: BF870003
	.long 0xd4430004                                           // 000000839CF0: D4430004
	v_cndmask_b32_e32 v1, s6, v30, vcc_lo                      // 000000839CF4: 02023C06
	s_mov_b32 s14, exec_lo                                     // 000000839CF8: BE8E007E
	.long 0xd4c4007e                                           // 000000839CFC: D4C4007E
	v_cndmask_b32_e32 v1, s6, v30, vcc_lo                      // 000000839D00: 02023C06
	s_cbranch_execz 65280                                      // 000000839D04: BFA5FF00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x508>
	.long 0xd7006a0c                                           // 000000839D08: D7006A0C
	v_cndmask_b32_e32 v1, v18, v29, vcc_lo                     // 000000839D0C: 02023B12
	s_delay_alu instid0(VALU_DEP_1)                            // 000000839D10: BF870001
	v_add_co_ci_u32_e64 v13, null, 0, v25, vcc_lo              // 000000839D14: D5207C0D 01AA3280
	v_cmp_ne_u32_e32 vcc_lo, 1, v24                            // 000000839D1C: 7C9A3081
	v_mov_b32_e32 v31, v27                                     // 000000839D20: 7E3E031B
	global_load_b128 v[12:15], v[12:13], off                   // 000000839D24: DC5E0000 0C7C000C
	s_cbranch_vccnz 65270                                      // 000000839D2C: BFA4FEF6 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x508>
	global_load_d16_b16 v31, v[21:22], off                     // 000000839D30: DC820000 1F7C0015
	s_waitcnt vmcnt(0)                                         // 000000839D38: BF8903F7
	v_cvt_f32_f16_e32 v31, v31                                 // 000000839D3C: 7E3E171F
	s_branch 65265                                             // 000000839D40: BFA0FEF1 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x508>
	s_or_b32 exec_lo, exec_lo, s7                              // 000000839D44: 8C7E077E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000839D48: BF8700A9
	s_or_b32 exec_lo, exec_lo, s5                              // 000000839D4C: 8C7E057E
	.long 0xd71f0000                                           // 000000839D50: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000839D54: 020100C1
	v_xor_b32_e32 v1, 16, v0                                   // 000000839D58: 3A020090
	v_xor_b32_e32 v3, 8, v0                                    // 000000839D5C: 3A060088
	v_xor_b32_e32 v5, 4, v0                                    // 000000839D60: 3A0A0084
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000839D64: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v1                            // 000000839D68: 7C9802A0
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 000000839D6C: 02020300
	v_cmp_gt_u32_e32 vcc_lo, 32, v3                            // 000000839D70: 7C9806A0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000839D74: BF870002
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000839D78: 30020282
	v_cndmask_b32_e32 v3, v0, v3, vcc_lo                       // 000000839D7C: 02060700
	v_cmp_gt_u32_e32 vcc_lo, 32, v5                            // 000000839D80: 7C980AA0
	ds_bpermute_b32 v2, v1, v28                                // 000000839D84: DACC0000 02001C01
	s_waitcnt lgkmcnt(0)                                       // 000000839D8C: BF89FC07
	v_dual_add_f32 v2, v28, v2 :: v_dual_lshlrev_b32 v3, 2, v3 // 000000839D90: C922051C 02020682
	ds_bpermute_b32 v1, v1, v26                                // 000000839D98: DACC0000 01001A01
	ds_bpermute_b32 v4, v3, v2                                 // 000000839DA0: DACC0000 04000203
	s_waitcnt lgkmcnt(1)                                       // 000000839DA8: BF89FC17
	v_add_f32_e32 v1, v26, v1                                  // 000000839DAC: 0602031A
	s_waitcnt lgkmcnt(0)                                       // 000000839DB0: BF89FC07
	v_add_f32_e32 v2, v2, v4                                   // 000000839DB4: 06040902
	ds_bpermute_b32 v3, v3, v1                                 // 000000839DB8: DACC0000 03000103
	v_cndmask_b32_e32 v5, v0, v5, vcc_lo                       // 000000839DC0: 020A0B00
	s_delay_alu instid0(VALU_DEP_1)                            // 000000839DC4: BF870001
	v_lshlrev_b32_e32 v5, 2, v5                                // 000000839DC8: 300A0A82
	s_waitcnt lgkmcnt(0)                                       // 000000839DCC: BF89FC07
	v_add_f32_e32 v1, v1, v3                                   // 000000839DD0: 06020701
	ds_bpermute_b32 v3, v5, v2                                 // 000000839DD4: DACC0000 03000205
	ds_bpermute_b32 v4, v5, v1                                 // 000000839DDC: DACC0000 04000105
	v_xor_b32_e32 v5, 2, v0                                    // 000000839DE4: 3A0A0082
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000839DE8: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v5                            // 000000839DEC: 7C980AA0
	v_cndmask_b32_e32 v5, v0, v5, vcc_lo                       // 000000839DF0: 020A0B00
	s_waitcnt lgkmcnt(1)                                       // 000000839DF4: BF89FC17
	v_dual_add_f32 v2, v2, v3 :: v_dual_lshlrev_b32 v5, 2, v5  // 000000839DF8: C9220702 02040A82
	s_waitcnt lgkmcnt(0)                                       // 000000839E00: BF89FC07
	v_add_f32_e32 v1, v1, v4                                   // 000000839E04: 06020901
	ds_bpermute_b32 v3, v5, v2                                 // 000000839E08: DACC0000 03000205
	ds_bpermute_b32 v4, v5, v1                                 // 000000839E10: DACC0000 04000105
	v_xor_b32_e32 v5, 1, v0                                    // 000000839E18: 3A0A0081
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000839E1C: BF870141
	v_cmp_gt_u32_e32 vcc_lo, 32, v5                            // 000000839E20: 7C980AA0
	v_cndmask_b32_e32 v0, v0, v5, vcc_lo                       // 000000839E24: 02000B00
	v_cmp_eq_u32_e32 vcc_lo, 0, v23                            // 000000839E28: 7C942E80
	s_waitcnt lgkmcnt(1)                                       // 000000839E2C: BF89FC17
	v_dual_add_f32 v0, v2, v3 :: v_dual_lshlrev_b32 v5, 2, v0  // 000000839E30: C9220702 00040082
	s_and_b32 s2, vcc_lo, s2                                   // 000000839E38: 8B02026A
	s_waitcnt lgkmcnt(0)                                       // 000000839E3C: BF89FC07
	v_add_f32_e32 v1, v1, v4                                   // 000000839E40: 06020901
	ds_bpermute_b32 v2, v5, v0                                 // 000000839E44: DACC0000 02000005
	ds_bpermute_b32 v3, v5, v1                                 // 000000839E4C: DACC0000 03000105
	s_and_saveexec_b32 s3, s2                                  // 000000839E54: BE832002
	s_cbranch_execz 102                                        // 000000839E58: BFA50066 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0xbf4>
	s_load_b32 s0, s[0:1], 0x48                                // 000000839E5C: F4000000 F8000048
	s_waitcnt lgkmcnt(0)                                       // 000000839E64: BF89FC07
	v_dual_add_f32 v0, v0, v2 :: v_dual_add_f32 v1, v1, v3     // 000000839E68: C9080500 00000701
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000839E70: BF870111
	v_bfe_u32 v2, v0, 16, 1                                    // 000000839E74: D6100002 02052100
	v_bfe_u32 v3, v1, 16, 1                                    // 000000839E7C: D6100003 02052101
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000839E84: BF870112
	v_add3_u32 v0, v0, v2, 0x7fff                              // 000000839E88: D6550000 03FE0500 00007FFF
	v_add3_u32 v1, v1, v3, 0x7fff                              // 000000839E94: D6550001 03FE0701 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000839EA0: BF870091
	v_and_b32_e32 v1, 0xffff0000, v1                           // 000000839EA4: 360202FF FFFF0000
	v_dual_mul_f32 v1, s0, v1 :: v_dual_and_b32 v0, 0xffff0000, v0// 000000839EAC: C8E40200 010000FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000839EB8: BF870091
	v_dual_mul_f32 v0, s0, v0 :: v_dual_mul_f32 v1, 0xbfb8aa3b, v1// 000000839EBC: C8C60000 000002FF BFB8AA3B
	v_mul_f32_e32 v0, 0xbfb8aa3b, v0                           // 000000839EC8: 100000FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000839ED0: BF870092
	v_exp_f32_e32 v1, v1                                       // 000000839ED4: 7E024B01
	v_exp_f32_e32 v0, v0                                       // 000000839ED8: 7E004B00
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000839EDC: BF870095
	v_dual_add_f32 v3, 1.0, v1 :: v_dual_add_f32 v2, 1.0, v0   // 000000839EE0: C90802F2 030200F2
	v_div_scale_f32 v1, null, v3, v3, 1.0                      // 000000839EE8: D6FC7C01 03CA0703
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000839EF0: BF8701B2
	v_div_scale_f32 v0, null, v2, v2, 1.0                      // 000000839EF4: D6FC7C00 03CA0502
	s_waitcnt vmcnt(0)                                         // 000000839EFC: BF8903F7
	v_div_scale_f32 v8, vcc_lo, 1.0, v2, 1.0                   // 000000839F00: D6FC6A08 03CA04F2
	v_rcp_f32_e32 v5, v1                                       // 000000839F08: 7E0A5501
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000839F0C: BF870312
	v_rcp_f32_e32 v4, v0                                       // 000000839F10: 7E085500
	v_fma_f32 v7, -v1, v5, 1.0                                 // 000000839F14: D6130007 23CA0B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000839F1C: BF870095
	v_fma_f32 v6, -v0, v4, 1.0                                 // 000000839F20: D6130006 23CA0900
	v_dual_fmac_f32 v5, v7, v5 :: v_dual_fmac_f32 v4, v6, v4   // 000000839F28: C8000B07 05040906
	v_div_scale_f32 v6, s0, 1.0, v3, 1.0                       // 000000839F30: D6FC0006 03CA06F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000839F38: BF870112
	v_mul_f32_e32 v7, v8, v4                                   // 000000839F3C: 100E0908
	v_mul_f32_e32 v9, v6, v5                                   // 000000839F40: 10120B06
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000839F44: BF870112
	v_fma_f32 v10, -v0, v7, v8                                 // 000000839F48: D613000A 24220F00
	v_fma_f32 v11, -v1, v9, v6                                 // 000000839F50: D613000B 241A1301
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000839F58: BF870112
	v_fmac_f32_e32 v7, v10, v4                                 // 000000839F5C: 560E090A
	v_fmac_f32_e32 v9, v11, v5                                 // 000000839F60: 56120B0B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000839F64: BF870112
	v_fma_f32 v0, -v0, v7, v8                                  // 000000839F68: D6130000 24220F00
	v_fma_f32 v1, -v1, v9, v6                                  // 000000839F70: D6130001 241A1301
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000839F78: BF870132
	v_div_fmas_f32 v4, v0, v4, v7                              // 000000839F7C: D6370004 041E0900
	s_mov_b32 vcc_lo, s0                                       // 000000839F84: BEEA0000
	s_lshl_b64 s[0:1], s[16:17], 2                             // 000000839F88: 84808210
	v_div_fmas_f32 v5, v1, v5, v9                              // 000000839F8C: D6370005 04260B01
	.long 0xd73c0000                                           // 000000839F94: D73C0000
	v_cndmask_b32_e32 v1, 2, v16, vcc_lo                       // 000000839F98: 02022082
	v_div_fixup_f32 v2, v4, v2, 1.0                            // 000000839F9C: D6270002 03CA0504
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000839FA4: BF870193
	v_div_fixup_f32 v3, v5, v3, 1.0                            // 000000839FA8: D6270003 03CA0705
	.long 0xd7006a00                                           // 000000839FB0: D7006A00
	v_cndmask_b32_e32 v1, s12, v0, vcc_lo                      // 000000839FB4: 0202000C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000839FB8: BF870211
	v_add_co_ci_u32_e64 v1, null, s13, v1, vcc_lo              // 000000839FBC: D5207C01 01AA020D
	v_add_f32_e32 v4, v2, v2                                   // 000000839FC4: 06080502
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000839FC8: BF870223
	.long 0xd7006a02                                           // 000000839FCC: D7006A02
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 000000839FD0: 02000100
	v_add_f32_e32 v5, v3, v3                                   // 000000839FD4: 060A0703
	v_add_co_ci_u32_e64 v3, null, s1, v1, vcc_lo               // 000000839FD8: D5207C03 01AA0201
	s_clause 0x1                                               // 000000839FE0: BF850001
	global_store_b32 v[0:1], v4, off                           // 000000839FE4: DC6A0000 007C0400
	global_store_b32 v[2:3], v5, off                           // 000000839FEC: DC6A0000 007C0502
	s_endpgm                                                   // 000000839FF4: BFB00000
		...

