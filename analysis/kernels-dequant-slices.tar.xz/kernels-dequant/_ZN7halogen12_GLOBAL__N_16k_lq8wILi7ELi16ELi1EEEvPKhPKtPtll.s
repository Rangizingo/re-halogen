00000000002eef00 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi7ELi16ELi1EEEvPKhPKtPtll>:
; _ZN7halogen12_GLOBAL__N_16k_lq8wILi7ELi16ELi1EEEvPKhPKtPtll():
	s_clause 0x1                                               // 0000002EEF00: BF850001
	s_load_b64 s[12:13], s[0:1], 0x20                          // 0000002EEF04: F4040300 F8000020
	s_load_b256 s[4:11], s[0:1], null                          // 0000002EEF0C: F40C0100 F8000000
	v_lshrrev_b32_e32 v1, 4, v0                                // 0000002EEF14: 32020084
	s_mov_b32 s3, 0                                            // 0000002EEF18: BE830080
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v6, 0              // 0000002EEF1C: CA100080 0F060080
	s_lshl_b64 s[0:1], s[2:3], 4                               // 0000002EEF24: 84808402
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000002EEF28: BF8701B9
	v_dual_mov_b32 v9, s1 :: v_dual_and_b32 v14, 15, v0        // 0000002EEF2C: CA240001 090E008F
	v_or_b32_e32 v8, s0, v1                                    // 0000002EEF34: 38100200
	v_mov_b32_e32 v27, 0                                       // 0000002EEF38: 7E360280
	v_dual_mov_b32 v5, 0 :: v_dual_lshlrev_b32 v10, 4, v14     // 0000002EEF3C: CA220080 050A1C84
	v_mov_b32_e32 v4, 0                                        // 0000002EEF44: 7E080280
	s_waitcnt lgkmcnt(0)                                       // 0000002EEF48: BF89FC07
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[8:9]                  // 0000002EEF4C: 7CA8100C
	s_ashr_i32 s0, s11, 31                                     // 0000002EEF50: 86009F0B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000002EEF54: BF870499
	s_lshr_b32 s0, s0, 28                                      // 0000002EEF58: 85009C00
	s_add_u32 s2, s10, s0                                      // 0000002EEF5C: 8002000A
	s_addc_u32 s3, s11, 0                                      // 0000002EEF60: 8203800B
	v_cndmask_b32_e32 v3, 0, v8, vcc_lo                        // 0000002EEF64: 02061080
	v_cndmask_b32_e64 v1, 0, s1, vcc_lo                        // 0000002EEF68: D5010001 01A80280
	s_ashr_i64 s[2:3], s[2:3], 4                               // 0000002EEF70: 86828402
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002EEF74: BF8700A9
	s_add_u32 s0, s2, s10                                      // 0000002EEF78: 80000A02
	s_addc_u32 s1, s3, s11                                     // 0000002EEF7C: 82010B03
	.long 0xd72c0007                                           // 0000002EEF80: D72C0007
	v_cndmask_b32_e32 v0, v1, v0, vcc_lo                       // 0000002EEF84: 02000101
	v_mad_u64_u32 v[1:2], null, v3, s0, 0                      // 0000002EEF88: D6FE7C01 02000103
	.long 0xd72c0003                                           // 0000002EEF90: D72C0003
	v_cndmask_b32_e32 v0, v3, v1, vcc_lo                       // 0000002EEF94: 02000303
	.long 0xd4440000                                           // 0000002EEF98: D4440000
	v_cndmask_b32_e32 v1, s2, v14, vcc_lo                      // 0000002EEF9C: 02021C02
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002EEFA0: BF870193
	.long 0xd7000110                                           // 0000002EEFA4: D7000110
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 0000002EEFA8: 02020204
	v_add3_u32 v2, v2, v3, v7                                  // 0000002EEFAC: D6550002 041E0702
	v_mov_b32_e32 v7, 0                                        // 0000002EEFB4: 7E0E0280
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002EEFB8: BF870002
	v_add_co_ci_u32_e64 v17, null, s5, v2, s1                  // 0000002EEFBC: D5207C11 00060405
	s_and_saveexec_b32 s3, s0                                  // 0000002EEFC4: BE832000
	s_cbranch_execz 21                                         // 0000002EEFC8: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi7ELi16ELi1EEEvPKhPKtPtll+0x120>
	v_lshlrev_b32_e32 v3, 4, v14                               // 0000002EEFCC: 30061C84
	.long 0xd7000105                                           // 0000002EEFD0: D7000105
	v_cndmask_b32_e32 v0, v16, v10, vcc_lo                     // 0000002EEFD4: 02001510
	v_and_b32_e32 v7, 12, v0                                   // 0000002EEFD8: 360E008C
	v_add_co_ci_u32_e64 v6, null, s11, v17, s1                 // 0000002EEFDC: D5207C06 0006220B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EEFE4: BF870094
	.long 0xd7000103                                           // 0000002EEFE8: D7000103
	v_cndmask_b32_e32 v1, v16, v3, vcc_lo                      // 0000002EEFEC: 02020710
	v_add_co_ci_u32_e64 v4, null, 0, v17, s1                   // 0000002EEFF0: D5207C04 00062280
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EEFF8: BF870094
	.long 0xd700010b                                           // 0000002EEFFC: D700010B
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 0000002EF000: 02020F05
	v_add_co_ci_u32_e64 v12, null, 0, v6, s1                   // 0000002EF004: D5207C0C 00060C80
	s_clause 0x1                                               // 0000002EF00C: BF850001
	global_load_b128 v[4:7], v[3:4], off                       // 0000002EF010: DC5E0000 047C0003
	global_load_b32 v27, v[11:12], off                         // 0000002EF018: DC520000 1B7C000B
	s_or_b32 exec_lo, exec_lo, s3                              // 0000002EF020: 8C7E037E
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v18, 0             // 0000002EF024: CA100080 13120080
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v20, 0             // 0000002EF02C: CA100080 15140080
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v22, 0             // 0000002EF034: CA100080 17160080
	s_and_saveexec_b32 s3, s0                                  // 0000002EF03C: BE832000
	s_cbranch_execz 503                                        // 0000002EF040: BFA501F7 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi7ELi16ELi1EEEvPKhPKtPtll+0x920>
	v_and_or_b32 v0, v0, 12, 16                                // 0000002EF044: D6570000 02411900
	.long 0xd7000001                                           // 0000002EF04C: D7000001
	v_cndmask_b32_e32 v1, s10, v1, vcc_lo                      // 0000002EF050: 0202020A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002EF054: BF8701A1
	v_add_co_ci_u32_e64 v2, null, s11, v2, s0                  // 0000002EF058: D5207C02 0002040B
	v_dual_mov_b32 v11, 0 :: v_dual_mov_b32 v24, v14           // 0000002EF060: CA100080 0B18010E
	.long 0xd7000000                                           // 0000002EF068: D7000000
	v_cndmask_b32_e32 v1, v1, v0, vcc_lo                       // 0000002EF06C: 02020101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002EF070: BF870191
	v_add_co_ci_u32_e64 v1, null, 0, v2, s0                    // 0000002EF074: D5207C01 00020480
	v_mov_b32_e32 v22, v11                                     // 0000002EF07C: 7E2C030B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EF080: BF870093
	.long 0xd700000c                                           // 0000002EF084: D700000C
	v_cndmask_b32_e32 v1, s4, v0, vcc_lo                       // 0000002EF088: 02020004
	v_add_co_ci_u32_e64 v13, null, s5, v1, s0                  // 0000002EF08C: D5207C0D 00020205
	v_mov_b32_e32 v23, v11                                     // 0000002EF094: 7E2E030B
	v_mov_b32_e32 v20, v11                                     // 0000002EF098: 7E28030B
	v_mov_b32_e32 v21, v11                                     // 0000002EF09C: 7E2A030B
	v_mov_b32_e32 v18, v11                                     // 0000002EF0A0: 7E24030B
	v_mov_b32_e32 v19, v11                                     // 0000002EF0A4: 7E26030B
	v_mov_b32_e32 v15, v11                                     // 0000002EF0A8: 7E1E030B
	s_mul_i32 s1, s11, 6                                       // 0000002EF0AC: 9601860B
	s_mul_hi_u32 s16, s10, 6                                   // 0000002EF0B0: 9690860A
	s_lshl_b64 s[14:15], s[10:11], 2                           // 0000002EF0B4: 848E820A
	s_add_i32 s16, s16, s1                                     // 0000002EF0B8: 81100110
	s_mul_i32 s18, s10, 6                                      // 0000002EF0BC: 9612860A
	s_mov_b32 s17, 0                                           // 0000002EF0C0: BE910080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 0000002EF0C4: 8484810A
	s_branch 439                                               // 0000002EF0C8: BFA001B7 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi7ELi16ELi1EEEvPKhPKtPtll+0x8a8>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000002EF0CC: 8C7E0A7E
	v_cvt_f32_ubyte0_e32 v28, v4                               // 0000002EF0D0: 7E382304
	s_and_b32 s0, exec_lo, s0                                  // 0000002EF0D4: 8B00007E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EF0D8: BF870099
	s_or_b32 s17, s0, s17                                      // 0000002EF0DC: 8C111100
	v_fma_mix_f32 v28, v28, v27, v27 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002EF0E0: CC20601C 146E371C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EF0E8: BF870091
	v_bfe_u32 v29, v28, 16, 1                                  // 0000002EF0EC: D610001D 0205211C
	v_add3_u32 v28, v28, v29, 0x7fff                           // 0000002EF0F4: D655001C 03FE3B1C 00007FFF
	.long 0x7f3a3880                                           // 0000002EF100: 7F3A3880
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002EF104: BF8700A2
	.long 0x7e3a399c                                           // 0000002EF108: 7E3A399C
	v_cvt_f32_ubyte1_e32 v28, v4                               // 0000002EF10C: 7E382504
	v_fma_mix_f32 v28, v28, v27, v27 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002EF110: CC20601C 146E371C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EF118: BF870091
	v_bfe_u32 v30, v28, 16, 1                                  // 0000002EF11C: D610001E 0205211C
	v_add3_u32 v28, v28, v30, 0x7fff                           // 0000002EF124: D655001C 03FE3D1C 00007FFF
	v_cvt_f32_ubyte2_e32 v30, v4                               // 0000002EF130: 7E3C2704
	v_cvt_f32_ubyte3_e32 v4, v4                                // 0000002EF134: 7E082904
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002EF138: BF870193
	v_and_or_b32 v35, 0xffff0000, v28, v29                     // 0000002EF13C: D6570023 047638FF FFFF0000
	v_fma_mix_f32 v30, v30, v27, v27 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002EF148: CC20601E 146E371E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002EF150: BF870113
	v_fma_mix_f32 v4, v4, v27, v27 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002EF154: CC206004 146E3704
	v_bfe_u32 v31, v30, 16, 1                                  // 0000002EF15C: D610001F 0205211E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002EF164: BF870191
	v_add3_u32 v30, v30, v31, 0x7fff                           // 0000002EF168: D655001E 03FE3F1E 00007FFF
	v_bfe_u32 v31, v4, 16, 1                                   // 0000002EF174: D610001F 02052104
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002EF17C: BF8701A2
	.long 0x7e3c399e                                           // 0000002EF180: 7E3C399E
	.long 0x7f3c399d                                           // 0000002EF184: 7F3C399D
	v_add3_u32 v4, v4, v31, 0x7fff                             // 0000002EF188: D6550004 03FE3F04 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002EF194: BF8700A1
	v_and_or_b32 v36, 0xffff0000, v4, v30                      // 0000002EF198: D6570024 047A08FF FFFF0000
	v_cvt_f32_ubyte0_e32 v4, v5                                // 0000002EF1A4: 7E082305
	v_fma_mix_f32 v4, v4, v27, v27 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002EF1A8: CC206004 146E3704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EF1B0: BF870091
	v_bfe_u32 v28, v4, 16, 1                                   // 0000002EF1B4: D610001C 02052104
	v_add3_u32 v4, v4, v28, 0x7fff                             // 0000002EF1BC: D6550004 03FE3904 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002EF1C8: BF8700A1
	.long 0x7e3a3984                                           // 0000002EF1CC: 7E3A3984
	v_cvt_f32_ubyte1_e32 v4, v5                                // 0000002EF1D0: 7E082505
	v_fma_mix_f32 v4, v4, v27, v27 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002EF1D4: CC206004 146E3704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EF1DC: BF870091
	v_bfe_u32 v28, v4, 16, 1                                   // 0000002EF1E0: D610001C 02052104
	v_add3_u32 v4, v4, v28, 0x7fff                             // 0000002EF1E8: D6550004 03FE3904 00007FFF
	v_cvt_f32_ubyte2_e32 v28, v5                               // 0000002EF1F4: 7E382705
	v_cvt_f32_ubyte3_e32 v5, v5                                // 0000002EF1F8: 7E0A2905
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002EF1FC: BF870193
	v_and_or_b32 v37, 0xffff0000, v4, v29                      // 0000002EF200: D6570025 047608FF FFFF0000
	v_fma_mix_f32 v28, v28, v27, v27 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002EF20C: CC20601C 146E371C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002EF214: BF8701A3
	v_fma_mix_f32 v5, v5, v27, v27 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002EF218: CC206005 146E3705
	v_cvt_f32_ubyte0_e32 v4, v6                                // 0000002EF220: 7E082306
	v_bfe_u32 v30, v28, 16, 1                                  // 0000002EF224: D610001E 0205211C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002EF22C: BF870112
	v_fma_mix_f32 v4, v4, v27, v27 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002EF230: CC206004 146E3704
	v_add3_u32 v28, v28, v30, 0x7fff                           // 0000002EF238: D655001C 03FE3D1C 00007FFF
	v_bfe_u32 v30, v5, 16, 1                                   // 0000002EF244: D610001E 02052105
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002EF24C: BF8701A2
	.long 0x7e38399c                                           // 0000002EF250: 7E38399C
	.long 0x7f38399d                                           // 0000002EF254: 7F38399D
	v_add3_u32 v5, v5, v30, 0x7fff                             // 0000002EF258: D6550005 03FE3D05 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002EF264: BF8700A1
	v_and_or_b32 v38, 0xffff0000, v5, v28                      // 0000002EF268: D6570026 04720AFF FFFF0000
	v_bfe_u32 v5, v4, 16, 1                                    // 0000002EF274: D6100005 02052104
	v_add3_u32 v4, v4, v5, 0x7fff                              // 0000002EF27C: D6550004 03FE0B04 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002EF288: BF8700A1
	.long 0x7e3a3984                                           // 0000002EF28C: 7E3A3984
	v_cvt_f32_ubyte1_e32 v4, v6                                // 0000002EF290: 7E082506
	v_fma_mix_f32 v4, v4, v27, v27 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002EF294: CC206004 146E3704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EF29C: BF870091
	v_bfe_u32 v5, v4, 16, 1                                    // 0000002EF2A0: D6100005 02052104
	v_add3_u32 v4, v4, v5, 0x7fff                              // 0000002EF2A8: D6550004 03FE0B04 00007FFF
	v_cvt_f32_ubyte2_e32 v5, v6                                // 0000002EF2B4: 7E0A2706
	v_cvt_f32_ubyte3_e32 v6, v6                                // 0000002EF2B8: 7E0C2906
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002EF2BC: BF870193
	v_and_or_b32 v39, 0xffff0000, v4, v29                      // 0000002EF2C0: D6570027 047608FF FFFF0000
	v_fma_mix_f32 v5, v5, v27, v27 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002EF2CC: CC206005 146E3705
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002EF2D4: BF8701A3
	v_fma_mix_f32 v6, v6, v27, v27 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002EF2D8: CC206006 146E3706
	v_cvt_f32_ubyte0_e32 v4, v7                                // 0000002EF2E0: 7E082307
	v_bfe_u32 v28, v5, 16, 1                                   // 0000002EF2E4: D610001C 02052105
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002EF2EC: BF870112
	v_fma_mix_f32 v4, v4, v27, v27 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002EF2F0: CC206004 146E3704
	v_add3_u32 v5, v5, v28, 0x7fff                             // 0000002EF2F8: D6550005 03FE3905 00007FFF
	v_bfe_u32 v28, v6, 16, 1                                   // 0000002EF304: D610001C 02052106
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002EF30C: BF8701A2
	.long 0x7e0a3985                                           // 0000002EF310: 7E0A3985
	.long 0x7f0a399d                                           // 0000002EF314: 7F0A399D
	v_add3_u32 v6, v6, v28, 0x7fff                             // 0000002EF318: D6550006 03FE3906 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002EF324: BF8700A1
	v_and_or_b32 v40, 0xffff0000, v6, v5                       // 0000002EF328: D6570028 04160CFF FFFF0000
	v_bfe_u32 v5, v4, 16, 1                                    // 0000002EF334: D6100005 02052104
	v_add3_u32 v4, v4, v5, 0x7fff                              // 0000002EF33C: D6550004 03FE0B04 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002EF348: BF8700A1
	.long 0x7e3a3984                                           // 0000002EF34C: 7E3A3984
	v_cvt_f32_ubyte1_e32 v4, v7                                // 0000002EF350: 7E082507
	v_fma_mix_f32 v4, v4, v27, v27 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002EF354: CC206004 146E3704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EF35C: BF870091
	v_bfe_u32 v5, v4, 16, 1                                    // 0000002EF360: D6100005 02052104
	v_add3_u32 v4, v4, v5, 0x7fff                              // 0000002EF368: D6550004 03FE0B04 00007FFF
	v_cvt_f32_ubyte2_e32 v5, v7                                // 0000002EF374: 7E0A2707
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002EF378: BF870112
	v_and_or_b32 v41, 0xffff0000, v4, v29                      // 0000002EF37C: D6570029 047608FF FFFF0000
	v_fma_mix_f32 v5, v5, v27, v27 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002EF388: CC206005 146E3705
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EF390: BF870091
	v_bfe_u32 v6, v5, 16, 1                                    // 0000002EF394: D6100006 02052105
	v_add3_u32 v5, v5, v6, 0x7fff                              // 0000002EF39C: D6550005 03FE0D05 00007FFF
	v_cvt_f32_ubyte3_e32 v6, v7                                // 0000002EF3A8: 7E0C2907
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002EF3AC: BF870112
	.long 0x7e0a3985                                           // 0000002EF3B0: 7E0A3985
	v_fma_mix_f32 v6, v6, v27, v27 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002EF3B4: CC206006 146E3706
	.long 0x7f0a399d                                           // 0000002EF3BC: 7F0A399D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EF3C0: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 0000002EF3C4: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 0000002EF3CC: D6550006 03FE0F06 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000002EF3D8: BF870131
	v_and_or_b32 v42, 0xffff0000, v6, v5                       // 0000002EF3DC: D657002A 04160CFF FFFF0000
	.long 0xd73c0004                                           // 0000002EF3E8: D73C0004
	v_cndmask_b32_e32 v1, 1, v10, vcc_lo                       // 0000002EF3EC: 02021481
	v_mov_b32_e32 v10, v26                                     // 0000002EF3F0: 7E14031A
	.long 0xd700001f                                           // 0000002EF3F4: D700001F
	v_cndmask_b32_e32 v1, s6, v4, vcc_lo                       // 0000002EF3F8: 02020806
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002EF3FC: BF870001
	v_add_co_ci_u32_e64 v32, null, s7, v5, s0                  // 0000002EF400: D5207C20 00020A07
	s_clause 0x1                                               // 0000002EF408: BF850001
	global_load_b128 v[4:7], v[31:32], off                     // 0000002EF40C: DC5E0000 047C001F
	global_load_b128 v[27:30], v[31:32], off offset:16         // 0000002EF414: DC5E0010 1B7C001F
	s_waitcnt vmcnt(1)                                         // 0000002EF41C: BF8907F7
	v_dot2_f32_bf16 v4, v4, v35, 0                             // 0000002EF420: CC1A4004 1A024704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EF428: BF870091
	v_dot2_f32_bf16 v4, v5, v36, v4                            // 0000002EF42C: CC1A4004 1C124905
	v_dot2_f32_bf16 v4, v6, v37, v4                            // 0000002EF434: CC1A4004 1C124B06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002EF43C: BF8700A1
	v_dot2_f32_bf16 v4, v7, v38, v4                            // 0000002EF440: CC1A4004 1C124D07
	s_waitcnt vmcnt(0)                                         // 0000002EF448: BF8903F7
	v_dot2_f32_bf16 v4, v27, v39, v4                           // 0000002EF44C: CC1A4004 1C124F1B
	.long 0xd700001b                                           // 0000002EF454: D700001B
	v_cndmask_b32_e32 v0, v31, v4, vcc_lo                      // 0000002EF458: 0200091F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000002EF45C: BF8701B2
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 0000002EF460: CC1A4004 1C12511C
	v_add_co_ci_u32_e64 v28, null, s5, v32, s0                 // 0000002EF468: D5207C1C 00024005
	.long 0xd7000021                                           // 0000002EF470: D7000021
	v_cndmask_b32_e32 v0, v31, v14, vcc_lo                     // 0000002EF474: 02001D1F
	v_dot2_f32_bf16 v4, v29, v41, v4                           // 0000002EF478: CC1A4004 1C12531D
	v_add_co_ci_u32_e64 v34, null, s15, v32, s0                // 0000002EF480: D5207C22 0002400F
	.long 0xd700001f                                           // 0000002EF488: D700001F
	v_cndmask_b32_e32 v0, v31, v18, vcc_lo                     // 0000002EF48C: 0200251F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002EF490: BF870123
	v_dot2_f32_bf16 v4, v30, v42, v4                           // 0000002EF494: CC1A4004 1C12551E
	v_add_co_ci_u32_e64 v32, null, s16, v32, s0                // 0000002EF49C: D5207C20 00024010
	v_add_f32_e32 v22, v22, v4                                 // 0000002EF4A4: 062C0916
	s_clause 0x1                                               // 0000002EF4A8: BF850001
	global_load_b128 v[4:7], v[27:28], off                     // 0000002EF4AC: DC5E0000 047C001B
	global_load_b128 v[27:30], v[27:28], off offset:16         // 0000002EF4B4: DC5E0010 1B7C001B
	s_waitcnt vmcnt(1)                                         // 0000002EF4BC: BF8907F7
	v_dot2_f32_bf16 v4, v4, v35, 0                             // 0000002EF4C0: CC1A4004 1A024704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EF4C8: BF870091
	v_dot2_f32_bf16 v4, v5, v36, v4                            // 0000002EF4CC: CC1A4004 1C124905
	v_dot2_f32_bf16 v4, v6, v37, v4                            // 0000002EF4D4: CC1A4004 1C124B06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002EF4DC: BF8700A1
	v_dot2_f32_bf16 v4, v7, v38, v4                            // 0000002EF4E0: CC1A4004 1C124D07
	s_waitcnt vmcnt(0)                                         // 0000002EF4E8: BF8903F7
	v_dot2_f32_bf16 v4, v27, v39, v4                           // 0000002EF4EC: CC1A4004 1C124F1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EF4F4: BF870091
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 0000002EF4F8: CC1A4004 1C12511C
	v_dot2_f32_bf16 v4, v29, v41, v4                           // 0000002EF500: CC1A4004 1C12531D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EF508: BF870091
	v_dot2_f32_bf16 v4, v30, v42, v4                           // 0000002EF50C: CC1A4004 1C12551E
	v_add_f32_e32 v23, v23, v4                                 // 0000002EF514: 062E0917
	s_clause 0x1                                               // 0000002EF518: BF850001
	global_load_b128 v[4:7], v[33:34], off                     // 0000002EF51C: DC5E0000 047C0021
	global_load_b128 v[27:30], v[33:34], off offset:16         // 0000002EF524: DC5E0010 1B7C0021
	.long 0xd7000021                                           // 0000002EF52C: D7000021
	v_cndmask_b32_e32 v0, v33, v14, vcc_lo                     // 0000002EF530: 02001D21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002EF534: BF8700B1
	v_add_co_ci_u32_e64 v34, null, s15, v34, s0                // 0000002EF538: D5207C22 0002440F
	s_waitcnt vmcnt(1)                                         // 0000002EF540: BF8907F7
	v_dot2_f32_bf16 v4, v4, v35, 0                             // 0000002EF544: CC1A4004 1A024704
	v_dot2_f32_bf16 v4, v5, v36, v4                            // 0000002EF54C: CC1A4004 1C124905
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EF554: BF870091
	v_dot2_f32_bf16 v4, v6, v37, v4                            // 0000002EF558: CC1A4004 1C124B06
	v_dot2_f32_bf16 v4, v7, v38, v4                            // 0000002EF560: CC1A4004 1C124D07
	s_waitcnt vmcnt(0)                                         // 0000002EF568: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EF56C: BF870091
	v_dot2_f32_bf16 v4, v27, v39, v4                           // 0000002EF570: CC1A4004 1C124F1B
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 0000002EF578: CC1A4004 1C12511C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EF580: BF870091
	v_dot2_f32_bf16 v4, v29, v41, v4                           // 0000002EF584: CC1A4004 1C12531D
	v_dot2_f32_bf16 v4, v30, v42, v4                           // 0000002EF58C: CC1A4004 1C12551E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002EF594: BF870001
	v_add_f32_e32 v20, v20, v4                                 // 0000002EF598: 06280914
	s_clause 0x1                                               // 0000002EF59C: BF850001
	global_load_b128 v[4:7], v[31:32], off                     // 0000002EF5A0: DC5E0000 047C001F
	global_load_b128 v[27:30], v[31:32], off offset:16         // 0000002EF5A8: DC5E0010 1B7C001F
	s_waitcnt vmcnt(1)                                         // 0000002EF5B0: BF8907F7
	v_dot2_f32_bf16 v4, v4, v35, 0                             // 0000002EF5B4: CC1A4004 1A024704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EF5BC: BF870091
	v_dot2_f32_bf16 v4, v5, v36, v4                            // 0000002EF5C0: CC1A4004 1C124905
	v_dot2_f32_bf16 v4, v6, v37, v4                            // 0000002EF5C8: CC1A4004 1C124B06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002EF5D0: BF8700A1
	v_dot2_f32_bf16 v4, v7, v38, v4                            // 0000002EF5D4: CC1A4004 1C124D07
	s_waitcnt vmcnt(0)                                         // 0000002EF5DC: BF8903F7
	v_dot2_f32_bf16 v4, v27, v39, v4                           // 0000002EF5E0: CC1A4004 1C124F1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EF5E8: BF870091
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 0000002EF5EC: CC1A4004 1C12511C
	v_dot2_f32_bf16 v4, v29, v41, v4                           // 0000002EF5F4: CC1A4004 1C12531D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EF5FC: BF870091
	v_dot2_f32_bf16 v4, v30, v42, v4                           // 0000002EF600: CC1A4004 1C12551E
	v_add_f32_e32 v21, v21, v4                                 // 0000002EF608: 062A0915
	s_clause 0x1                                               // 0000002EF60C: BF850001
	global_load_b128 v[4:7], v[33:34], off                     // 0000002EF610: DC5E0000 047C0021
	global_load_b128 v[27:30], v[33:34], off offset:16         // 0000002EF618: DC5E0010 1B7C0021
	s_waitcnt vmcnt(1)                                         // 0000002EF620: BF8907F7
	v_dot2_f32_bf16 v4, v4, v35, 0                             // 0000002EF624: CC1A4004 1A024704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EF62C: BF870091
	v_dot2_f32_bf16 v4, v5, v36, v4                            // 0000002EF630: CC1A4004 1C124905
	v_dot2_f32_bf16 v4, v6, v37, v4                            // 0000002EF638: CC1A4004 1C124B06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002EF640: BF8700A1
	v_dot2_f32_bf16 v4, v7, v38, v4                            // 0000002EF644: CC1A4004 1C124D07
	s_waitcnt vmcnt(0)                                         // 0000002EF64C: BF8903F7
	v_dot2_f32_bf16 v4, v27, v39, v4                           // 0000002EF650: CC1A4004 1C124F1B
	.long 0xd700001b                                           // 0000002EF658: D700001B
	v_cndmask_b32_e32 v0, v31, v14, vcc_lo                     // 0000002EF65C: 02001D1F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002EF660: BF870122
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 0000002EF664: CC1A4004 1C12511C
	v_add_co_ci_u32_e64 v28, null, s15, v32, s0                // 0000002EF66C: D5207C1C 0002400F
	v_dot2_f32_bf16 v4, v29, v41, v4                           // 0000002EF674: CC1A4004 1C12531D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EF67C: BF870091
	v_dot2_f32_bf16 v4, v30, v42, v4                           // 0000002EF680: CC1A4004 1C12551E
	v_add_f32_e32 v18, v18, v4                                 // 0000002EF688: 06240912
	s_clause 0x1                                               // 0000002EF68C: BF850001
	global_load_b128 v[4:7], v[27:28], off                     // 0000002EF690: DC5E0000 047C001B
	global_load_b128 v[27:30], v[27:28], off offset:16         // 0000002EF698: DC5E0010 1B7C001B
	s_waitcnt vmcnt(1)                                         // 0000002EF6A0: BF8907F7
	v_dot2_f32_bf16 v4, v4, v35, 0                             // 0000002EF6A4: CC1A4004 1A024704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EF6AC: BF870091
	v_dot2_f32_bf16 v4, v5, v36, v4                            // 0000002EF6B0: CC1A4004 1C124905
	v_dot2_f32_bf16 v4, v6, v37, v4                            // 0000002EF6B8: CC1A4004 1C124B06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002EF6C0: BF8700A1
	v_dot2_f32_bf16 v4, v7, v38, v4                            // 0000002EF6C4: CC1A4004 1C124D07
	s_waitcnt vmcnt(0)                                         // 0000002EF6CC: BF8903F7
	v_dot2_f32_bf16 v4, v27, v39, v4                           // 0000002EF6D0: CC1A4004 1C124F1B
	.long 0xd700001b                                           // 0000002EF6D8: D700001B
	v_cndmask_b32_e32 v0, v33, v14, vcc_lo                     // 0000002EF6DC: 02001D21
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000002EF6E0: BF8701B2
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 0000002EF6E4: CC1A4004 1C12511C
	v_add_co_ci_u32_e64 v28, null, s15, v34, s0                // 0000002EF6EC: D5207C1C 0002440F
	.long 0xd700000c                                           // 0000002EF6F4: D700000C
	v_cndmask_b32_e32 v0, v12, v144, vcc_lo                    // 0000002EF6F8: 0201210C
	v_dot2_f32_bf16 v4, v29, v41, v4                           // 0000002EF6FC: CC1A4004 1C12531D
	v_add_co_ci_u32_e64 v13, null, 0, v13, s0                  // 0000002EF704: D5207C0D 00021A80
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EF70C: BF870092
	v_dot2_f32_bf16 v4, v30, v42, v4                           // 0000002EF710: CC1A4004 1C12551E
	v_add_f32_e32 v19, v19, v4                                 // 0000002EF718: 06260913
	s_clause 0x1                                               // 0000002EF71C: BF850001
	global_load_b128 v[4:7], v[27:28], off                     // 0000002EF720: DC5E0000 047C001B
	global_load_b128 v[27:30], v[27:28], off offset:16         // 0000002EF728: DC5E0010 1B7C001B
	s_waitcnt vmcnt(1)                                         // 0000002EF730: BF8907F7
	v_dot2_f32_bf16 v4, v4, v35, 0                             // 0000002EF734: CC1A4004 1A024704
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002EF73C: BF870121
	v_dot2_f32_bf16 v4, v5, v36, v4                            // 0000002EF740: CC1A4004 1C124905
	v_mov_b32_e32 v5, v1                                       // 0000002EF748: 7E0A0301
	v_dot2_f32_bf16 v4, v6, v37, v4                            // 0000002EF74C: CC1A4004 1C124B06
	v_mov_b32_e32 v6, v2                                       // 0000002EF754: 7E0C0302
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000002EF758: BF870132
	v_dot2_f32_bf16 v4, v7, v38, v4                            // 0000002EF75C: CC1A4004 1C124D07
	v_mov_b32_e32 v7, v3                                       // 0000002EF764: 7E0E0303
	s_waitcnt vmcnt(0)                                         // 0000002EF768: BF8903F7
	v_dot2_f32_bf16 v4, v27, v39, v4                           // 0000002EF76C: CC1A4004 1C124F1B
	v_mov_b32_e32 v27, v25                                     // 0000002EF774: 7E360319
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EF778: BF870092
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 0000002EF77C: CC1A4004 1C12511C
	v_dot2_f32_bf16 v4, v29, v41, v4                           // 0000002EF784: CC1A4004 1C12531D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EF78C: BF870091
	v_dot2_f32_bf16 v4, v30, v42, v4                           // 0000002EF790: CC1A4004 1C12551E
	v_dual_add_f32 v15, v15, v4 :: v_dual_mov_b32 v4, v0       // 0000002EF798: C910090F 0F040100
	s_and_not1_b32 exec_lo, exec_lo, s17                       // 0000002EF7A0: 917E117E
	s_cbranch_execz 29                                         // 0000002EF7A4: BFA5001D <_ZN7halogen12_GLOBAL__N_16k_lq8wILi7ELi16ELi1EEEvPKhPKtPtll+0x91c>
	v_add_nc_u32_e32 v24, 16, v24                              // 0000002EF7A8: 4A303090
	v_add_nc_u32_e32 v26, 0x100, v10                           // 0000002EF7AC: 4A3414FF 00000100
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000002EF7B4: BF8704A2
	.long 0xd4430000                                           // 0000002EF7B8: D4430000
	v_cndmask_b32_e32 v1, s2, v24, vcc_lo                      // 0000002EF7BC: 02023002
	s_and_saveexec_b32 s1, s0                                  // 0000002EF7C0: BE812000
	s_xor_b32 s1, exec_lo, s1                                  // 0000002EF7C4: 8D01017E
	v_add_nc_u32_e32 v26, 0x100, v10                           // 0000002EF7C8: 4A3414FF 00000100
	s_or_saveexec_b32 s10, s1                                  // 0000002EF7D0: BE8A2201
	s_waitcnt vmcnt(0)                                         // 0000002EF7D4: BF8903F7
	v_dual_mov_b32 v25, v27 :: v_dual_mov_b32 v0, v4           // 0000002EF7D8: CA10011B 19000104
	v_dual_mov_b32 v1, v5 :: v_dual_mov_b32 v2, v6             // 0000002EF7E0: CA100105 01020106
	v_mov_b32_e32 v3, v7                                       // 0000002EF7E8: 7E060307
	s_xor_b32 exec_lo, exec_lo, s10                            // 0000002EF7EC: 8D7E0A7E
	s_cbranch_execz 65078                                      // 0000002EF7F0: BFA5FE36 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi7ELi16ELi1EEEvPKhPKtPtll+0x1cc>
	.long 0xd7000100                                           // 0000002EF7F4: D7000100
	v_cndmask_b32_e32 v1, v16, v26, vcc_lo                     // 0000002EF7F8: 02023510
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002EF7FC: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v17, s1                   // 0000002EF800: D5207C01 00062280
	global_load_b128 v[0:3], v[0:1], off                       // 0000002EF808: DC5E0000 007C0000
	global_load_b32 v25, v[12:13], off                         // 0000002EF810: DC520000 197C000C
	s_branch 65068                                             // 0000002EF818: BFA0FE2C <_ZN7halogen12_GLOBAL__N_16k_lq8wILi7ELi16ELi1EEEvPKhPKtPtll+0x1cc>
	s_or_b32 exec_lo, exec_lo, s17                             // 0000002EF81C: 8C7E117E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002EF820: BF8700A9
	s_or_b32 exec_lo, exec_lo, s3                              // 0000002EF824: 8C7E037E
	.long 0xd71f0000                                           // 0000002EF828: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000002EF82C: 020100C1
	v_xor_b32_e32 v1, 8, v0                                    // 0000002EF830: 3A020088
	v_xor_b32_e32 v10, 4, v0                                   // 0000002EF834: 3A140084
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EF838: BF870092
	.long 0xd44c0000                                           // 0000002EF83C: D44C0000
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 0000002EF840: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s0                           // 0000002EF844: D5010001 00020300
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002EF84C: BF870113
	.long 0xd44c0000                                           // 0000002EF850: D44C0000
	v_cndmask_b32_e32 v1, 32, v10, vcc_lo                      // 0000002EF854: 020214A0
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000002EF858: 30020282
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002EF85C: BF870002
	v_cndmask_b32_e64 v10, v0, v10, s0                         // 0000002EF860: D501000A 00021500
	ds_bpermute_b32 v2, v1, v15                                // 0000002EF868: DACC0000 02000F01
	s_waitcnt lgkmcnt(0)                                       // 0000002EF870: BF89FC07
	v_add_f32_e32 v2, v15, v2                                  // 0000002EF874: 0604050F
	ds_bpermute_b32 v3, v1, v23                                // 0000002EF878: DACC0000 03001701
	s_waitcnt vmcnt(1)                                         // 0000002EF880: BF8907F7
	ds_bpermute_b32 v4, v1, v22                                // 0000002EF884: DACC0000 04001601
	ds_bpermute_b32 v5, v1, v21                                // 0000002EF88C: DACC0000 05001501
	ds_bpermute_b32 v6, v1, v20                                // 0000002EF894: DACC0000 06001401
	ds_bpermute_b32 v7, v1, v19                                // 0000002EF89C: DACC0000 07001301
	ds_bpermute_b32 v1, v1, v18                                // 0000002EF8A4: DACC0000 01001201
	s_waitcnt lgkmcnt(5)                                       // 0000002EF8AC: BF89FC57
	v_dual_add_f32 v3, v23, v3 :: v_dual_lshlrev_b32 v10, 2, v10// 0000002EF8B0: C9220717 030A1482
	ds_bpermute_b32 v11, v10, v2                               // 0000002EF8B8: DACC0000 0B00020A
	s_waitcnt lgkmcnt(4)                                       // 0000002EF8C0: BF89FC47
	v_dual_add_f32 v4, v22, v4 :: v_dual_add_f32 v5, v21, v5   // 0000002EF8C4: C9080916 04040B15
	s_waitcnt lgkmcnt(2)                                       // 0000002EF8CC: BF89FC27
	v_dual_add_f32 v6, v20, v6 :: v_dual_add_f32 v7, v19, v7   // 0000002EF8D0: C9080D14 06060F13
	s_waitcnt lgkmcnt(1)                                       // 0000002EF8D8: BF89FC17
	v_add_f32_e32 v1, v18, v1                                  // 0000002EF8DC: 06020312
	v_xor_b32_e32 v18, 2, v0                                   // 0000002EF8E0: 3A240082
	ds_bpermute_b32 v12, v10, v3                               // 0000002EF8E4: DACC0000 0C00030A
	ds_bpermute_b32 v13, v10, v4                               // 0000002EF8EC: DACC0000 0D00040A
	ds_bpermute_b32 v15, v10, v5                               // 0000002EF8F4: DACC0000 0F00050A
	ds_bpermute_b32 v16, v10, v6                               // 0000002EF8FC: DACC0000 1000060A
	.long 0xd44c0000                                           // 0000002EF904: D44C0000
	v_cndmask_b32_e32 v1, 32, v18, vcc_lo                      // 0000002EF908: 020224A0
	ds_bpermute_b32 v17, v10, v7                               // 0000002EF90C: DACC0000 1100070A
	v_cndmask_b32_e64 v18, v0, v18, s0                         // 0000002EF914: D5010012 00022500
	s_waitcnt lgkmcnt(5)                                       // 0000002EF91C: BF89FC57
	v_add_f32_e32 v2, v2, v11                                  // 0000002EF920: 06041702
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002EF924: BF870002
	v_lshlrev_b32_e32 v18, 2, v18                              // 0000002EF928: 30242482
	ds_bpermute_b32 v10, v10, v1                               // 0000002EF92C: DACC0000 0A00010A
	s_waitcnt lgkmcnt(5)                                       // 0000002EF934: BF89FC57
	v_add_f32_e32 v3, v3, v12                                  // 0000002EF938: 06061903
	v_xor_b32_e32 v12, 1, v0                                   // 0000002EF93C: 3A180081
	s_waitcnt lgkmcnt(3)                                       // 0000002EF940: BF89FC37
	v_dual_add_f32 v4, v4, v13 :: v_dual_add_f32 v5, v5, v15   // 0000002EF944: C9081B04 04041F05
	s_waitcnt lgkmcnt(1)                                       // 0000002EF94C: BF89FC17
	v_dual_add_f32 v6, v6, v16 :: v_dual_add_f32 v7, v7, v17   // 0000002EF950: C9082106 06062307
	.long 0xd44c0000                                           // 0000002EF958: D44C0000
	v_cndmask_b32_e32 v1, 32, v12, vcc_lo                      // 0000002EF95C: 020218A0
	ds_bpermute_b32 v11, v18, v4                               // 0000002EF960: DACC0000 0B000412
	ds_bpermute_b32 v15, v18, v5                               // 0000002EF968: DACC0000 0F000512
	ds_bpermute_b32 v16, v18, v6                               // 0000002EF970: DACC0000 10000612
	ds_bpermute_b32 v17, v18, v7                               // 0000002EF978: DACC0000 11000712
	v_cndmask_b32_e64 v0, v0, v12, s0                          // 0000002EF980: D5010000 00021900
	.long 0xd44a0000                                           // 0000002EF988: D44A0000
	v_cndmask_b32_e32 v1, 0, v14, vcc_lo                       // 0000002EF98C: 02021C80
	s_waitcnt lgkmcnt(4)                                       // 0000002EF990: BF89FC47
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002EF994: BF870002
	v_dual_add_f32 v1, v1, v10 :: v_dual_lshlrev_b32 v20, 2, v0// 0000002EF998: C9221501 01140082
	ds_bpermute_b32 v10, v18, v3                               // 0000002EF9A0: DACC0000 0A000312
	s_and_b32 s0, s0, vcc_lo                                   // 0000002EF9A8: 8B006A00
	ds_bpermute_b32 v19, v18, v1                               // 0000002EF9AC: DACC0000 13000112
	ds_bpermute_b32 v18, v18, v2                               // 0000002EF9B4: DACC0000 12000212
	s_waitcnt lgkmcnt(6)                                       // 0000002EF9BC: BF89FC67
	v_add_f32_e32 v13, v4, v11                                 // 0000002EF9C0: 061A1704
	s_waitcnt lgkmcnt(4)                                       // 0000002EF9C4: BF89FC47
	v_dual_add_f32 v4, v5, v15 :: v_dual_add_f32 v5, v6, v16   // 0000002EF9C8: C9081F05 04042106
	s_waitcnt lgkmcnt(3)                                       // 0000002EF9D0: BF89FC37
	v_add_f32_e32 v0, v7, v17                                  // 0000002EF9D4: 06002307
	ds_bpermute_b32 v15, v20, v13                              // 0000002EF9D8: DACC0000 0F000D14
	ds_bpermute_b32 v7, v20, v4                                // 0000002EF9E0: DACC0000 07000414
	ds_bpermute_b32 v6, v20, v5                                // 0000002EF9E8: DACC0000 06000514
	s_waitcnt lgkmcnt(4)                                       // 0000002EF9F0: BF89FC47
	v_dual_add_f32 v12, v3, v10 :: v_dual_add_f32 v1, v1, v19  // 0000002EF9F4: C9081503 0C002701
	s_waitcnt lgkmcnt(3)                                       // 0000002EF9FC: BF89FC37
	v_add_f32_e32 v10, v2, v18                                 // 0000002EFA00: 06142502
	ds_bpermute_b32 v16, v20, v12                              // 0000002EFA04: DACC0000 10000C14
	ds_bpermute_b32 v3, v20, v0                                // 0000002EFA0C: DACC0000 03000014
	ds_bpermute_b32 v2, v20, v1                                // 0000002EFA14: DACC0000 02000114
	ds_bpermute_b32 v11, v20, v10                              // 0000002EFA1C: DACC0000 0B000A14
	s_and_saveexec_b32 s1, s0                                  // 0000002EFA24: BE812000
	s_cbranch_execz 102                                        // 0000002EFA28: BFA50066 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi7ELi16ELi1EEEvPKhPKtPtll+0xcc4>
	s_waitcnt lgkmcnt(3)                                       // 0000002EFA2C: BF89FC37
	v_dual_add_f32 v12, v12, v16 :: v_dual_add_f32 v13, v13, v15// 0000002EFA30: C908210C 0C0C1F0D
	.long 0x7f1c3880                                           // 0000002EFA38: 7F1C3880
	.long 0xd73c0008                                           // 0000002EFA3C: D73C0008
	v_cndmask_b32_e32 v1, 1, v8, vcc_lo                        // 0000002EFA40: 02021081
	s_lshl_b64 s[0:1], s[12:13], 1                             // 0000002EFA44: 8480810C
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002EFA48: BF870003
	.long 0x7e1c398c                                           // 0000002EFA4C: 7E1C398C
	.long 0x7e1e398d                                           // 0000002EFA50: 7E1E398D
	.long 0x7f1e398e                                           // 0000002EFA54: 7F1E398E
	s_waitcnt lgkmcnt(0)                                       // 0000002EFA58: BF89FC07
	v_add_f32_e32 v10, v10, v11                                // 0000002EFA5C: 0614170A
	.long 0xd7006a08                                           // 0000002EFA60: D7006A08
	v_cndmask_b32_e32 v1, s8, v8, vcc_lo                       // 0000002EFA64: 02021008
	v_dual_add_f32 v7, v4, v7 :: v_dual_and_b32 v16, 1, v14    // 0000002EFA68: C9240F04 07101C81
	v_dual_add_f32 v6, v5, v6 :: v_dual_and_b32 v15, 1, v15    // 0000002EFA70: C9240D05 060E1E81
	v_add_co_ci_u32_e64 v9, null, s9, v9, vcc_lo               // 0000002EFA78: D5207C09 01AA1209
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000002EFA80: BF870223
	v_add3_u32 v16, v12, v16, 0x7fff                           // 0000002EFA84: D6550010 03FE210C 00007FFF
	.long 0xd7006a0c                                           // 0000002EFA90: D7006A0C
	v_cndmask_b32_e32 v0, v8, v0, vcc_lo                       // 0000002EFA94: 02000108
	v_add3_u32 v15, v13, v15, 0x7fff                           // 0000002EFA98: D655000F 03FE1F0D 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 0000002EFAA4: BF870004
	v_add_co_ci_u32_e64 v13, null, s1, v9, vcc_lo              // 0000002EFAA8: D5207C0D 01AA1201
	s_clause 0x1                                               // 0000002EFAB0: BF850001
	global_store_d16_hi_b16 v[8:9], v15, off                   // 0000002EFAB4: DC960000 007C0F08
	global_store_d16_hi_b16 v[12:13], v16, off                 // 0000002EFABC: DC960000 007C100C
	.long 0x7e1c3987                                           // 0000002EFAC4: 7E1C3987
	v_add_f32_e32 v13, v1, v2                                  // 0000002EFAC8: 061A0501
	s_lshl_b64 s[0:1], s[12:13], 2                             // 0000002EFACC: 8480820C
	.long 0x7e163986                                           // 0000002EFAD0: 7E163986
	.long 0xd7006a04                                           // 0000002EFAD4: D7006A04
	v_cndmask_b32_e32 v0, v8, v0, vcc_lo                       // 0000002EFAD8: 02000108
	.long 0x7f16398e                                           // 0000002EFADC: 7F16398E
	v_add_f32_e32 v12, v0, v3                                  // 0000002EFAE0: 06180700
	v_mad_u64_u32 v[0:1], null, s12, 6, v[8:9]                 // 0000002EFAE4: D6FE7C00 04210C0C
	v_and_b32_e32 v2, 1, v14                                   // 0000002EFAEC: 36041C81
	.long 0x7e10398d                                           // 0000002EFAF0: 7E10398D
	.long 0x7f10398e                                           // 0000002EFAF4: 7F10398E
	v_and_b32_e32 v3, 1, v11                                   // 0000002EFAF8: 36061681
	v_add_co_ci_u32_e64 v5, null, s1, v9, vcc_lo               // 0000002EFAFC: D5207C05 01AA1201
	v_add3_u32 v11, v7, v2, 0x7fff                             // 0000002EFB04: D655000B 03FE0507 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000002EFB10: BF870254
	v_and_b32_e32 v7, 1, v8                                    // 0000002EFB14: 360E1081
	.long 0x7e1c398c                                           // 0000002EFB18: 7E1C398C
	v_mad_u64_u32 v[1:2], null, s13, 6, v[1:2]                 // 0000002EFB1C: D6FE7C01 04050C0D
	v_add3_u32 v15, v6, v3, 0x7fff                             // 0000002EFB24: D655000F 03FE0706 00007FFF
	.long 0xd7006a02                                           // 0000002EFB30: D7006A02
	v_cndmask_b32_e32 v0, v4, v0, vcc_lo                       // 0000002EFB34: 02000104
	v_and_b32_e32 v6, 1, v14                                   // 0000002EFB38: 360C1C81
	v_bfe_u32 v8, v10, 16, 1                                   // 0000002EFB3C: D6100008 0205210A
	v_add_co_ci_u32_e64 v3, null, s1, v5, vcc_lo               // 0000002EFB44: D5207C03 01AA0A01
	v_add3_u32 v13, v13, v7, 0x7fff                            // 0000002EFB4C: D655000D 03FE0F0D 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002EFB58: BF8700A4
	v_add3_u32 v12, v12, v6, 0x7fff                            // 0000002EFB5C: D655000C 03FE0D0C 00007FFF
	.long 0xd7006a06                                           // 0000002EFB68: D7006A06
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 0000002EFB6C: 02000100
	v_add_co_ci_u32_e64 v7, null, s1, v1, vcc_lo               // 0000002EFB70: D5207C07 01AA0201
	v_add3_u32 v10, v10, v8, 0x7fff                            // 0000002EFB78: D655000A 03FE110A 00007FFF
	.long 0xd7006a08                                           // 0000002EFB84: D7006A08
	v_cndmask_b32_e32 v0, v2, v0, vcc_lo                       // 0000002EFB88: 02000102
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002EFB8C: BF870001
	v_add_co_ci_u32_e64 v9, null, s1, v3, vcc_lo               // 0000002EFB90: D5207C09 01AA0601
	s_clause 0x4                                               // 0000002EFB98: BF850004
	global_store_d16_hi_b16 v[4:5], v15, off                   // 0000002EFB9C: DC960000 007C0F04
	global_store_d16_hi_b16 v[0:1], v11, off                   // 0000002EFBA4: DC960000 007C0B00
	global_store_d16_hi_b16 v[2:3], v13, off                   // 0000002EFBAC: DC960000 007C0D02
	global_store_d16_hi_b16 v[6:7], v12, off                   // 0000002EFBB4: DC960000 007C0C06
	global_store_d16_hi_b16 v[8:9], v10, off                   // 0000002EFBBC: DC960000 007C0A08
	s_endpgm                                                   // 0000002EFBC4: BFB00000
		...

