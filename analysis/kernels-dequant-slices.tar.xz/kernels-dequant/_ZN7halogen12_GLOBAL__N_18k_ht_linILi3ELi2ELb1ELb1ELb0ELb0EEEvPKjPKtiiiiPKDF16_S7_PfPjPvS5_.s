0000000000503900 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_>:
; _ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_():
	s_clause 0x2                                               // 000000503900: BF850002
	s_load_b128 s[24:27], s[0:1], 0x10                         // 000000503904: F4080600 F8000010
	s_load_b256 s[12:19], s[0:1], 0x20                         // 00000050390C: F40C0300 F8000020
	s_load_b128 s[20:23], s[0:1], 0x40                         // 000000503914: F4080500 F8000040
	s_mov_b32 s4, s3                                           // 00000050391C: BE840003
	v_and_b32_e32 v42, 31, v0                                  // 000000503920: 3654009F
	v_lshrrev_b32_e32 v40, 5, v0                               // 000000503924: 32500085
	s_delay_alu instid0(VALU_DEP_2)                            // 000000503928: BF870002
	v_lshlrev_b32_e32 v8, 3, v42                               // 00000050392C: 30105483
	s_waitcnt lgkmcnt(0)                                       // 000000503930: BF89FC07
	s_ashr_i32 s34, s25, 31                                    // 000000503934: 86229F19
	s_mul_i32 s33, s27, s4                                     // 000000503938: 9621041B
	s_lshr_b32 s3, s34, 25                                     // 00000050393C: 85039922
	s_add_i32 s5, s33, s27                                     // 000000503940: 81051B21
	s_add_i32 s3, s25, s3                                      // 000000503944: 81030319
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000503948: BF870499
	s_ashr_i32 s3, s3, 7                                       // 00000050394C: 86038703
	s_min_i32 s3, s3, s5                                       // 000000503950: 89030503
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000503954: BF8704B9
	s_sub_i32 s11, s3, s33                                     // 000000503958: 818B2103
	s_mov_b32 s3, exec_lo                                      // 00000050395C: BE83007E
	s_lshl_b32 s10, s11, 1                                     // 000000503960: 840A810B
	.long 0xd4c3007e                                           // 000000503964: D4C3007E
	v_cndmask_b32_e32 v1, s10, v40, vcc_lo                     // 000000503968: 0202500A
	s_xor_b32 s3, exec_lo, s3                                  // 00000050396C: 8D03037E
	v_lshlrev_b32_e32 v8, 3, v42                               // 000000503970: 30105483
	s_or_saveexec_b32 s35, s3                                  // 000000503974: BEA32203
	s_clause 0x1                                               // 000000503978: BF850001
	s_load_b32 s27, s[0:1], 0x54                               // 00000050397C: F40006C0 F8000054
	s_load_b128 s[28:31], s[0:1], null                         // 000000503984: F4080700 F8000000
	v_lshlrev_b32_e32 v41, 2, v42                              // 00000050398C: 30525482
	s_xor_b32 exec_lo, exec_lo, s35                            // 000000503990: 8D7E237E
	s_cbranch_execz 501                                        // 000000503994: BFA501F5 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x86c>
	s_add_i32 s36, s24, -1                                     // 000000503998: 8124C118
	s_cmp_lg_u64 s[22:23], 0                                   // 00000050399C: BF118016
	v_and_b32_e32 v1, 1, v0                                    // 0000005039A0: 36020081
	s_cselect_b32 s37, -1, 0                                   // 0000005039A4: 982580C1
	s_abs_i32 s38, s11                                         // 0000005039A8: BEA6150B
	v_and_b32_e32 v3, 2, v0                                    // 0000005039AC: 36060082
	s_cvt_f32_u32 s0, s38                                      // 0000005039B0: BE806526
	v_dual_mov_b32 v9, v40 :: v_dual_and_b32 v4, 4, v0         // 0000005039B4: CA240128 09040084
	v_and_b32_e32 v5, 8, v0                                    // 0000005039BC: 360A0088
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000005039C0: BF870009
	v_rcp_iflag_f32_e32 v2, s0                                 // 0000005039C4: 7E045600
	v_lshl_or_b32 v6, v40, 8, v8                               // 0000005039C8: D6560006 04211128
	v_add_nc_u32_e32 v7, s33, v40                              // 0000005039D0: 4A0E5021
	s_ashr_i32 s42, s11, 31                                    // 0000005039D4: 862A9F0B
	s_sub_i32 s9, 0, s38                                       // 0000005039D8: 81892680
	s_mul_i32 s44, s42, 0x1400                                 // 0000005039DC: 962CFF2A 00001400
	.long 0xd44c0000                                           // 0000005039E4: D44C0000
	v_cndmask_b32_e32 v1, 16, v42, vcc_lo                      // 0000005039E8: 02025490
	.long 0xd44a0001                                           // 0000005039EC: D44A0001
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000005039F0: 02020280
	.long 0xd44a0005                                           // 0000005039F4: D44A0005
	v_cndmask_b32_e32 v1, 0, v4, vcc_lo                        // 0000005039F8: 02020880
	.long 0xd44a0006                                           // 0000005039FC: D44A0006
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 000000503A00: 02020A80
	v_readfirstlane_b32 s3, v2                                 // 000000503A04: 7E060502
	v_lshl_or_b32 v1, v7, 7, v41                               // 000000503A08: D6560001 04A50F07
	v_subrev_nc_u32_e32 v10, s44, v6                           // 000000503A10: 4E140C2C
	s_lshl_b32 s7, s11, 7                                      // 000000503A14: 8407870B
	s_mov_b32 s39, s25                                         // 000000503A18: BEA70019
	s_mul_f32 s8, s3, 0x4f7ffffe                               // 000000503A1C: A208FF03 4F7FFFFE
	.long 0xd44a0003                                           // 000000503A24: D44A0003
	v_cndmask_b32_e32 v1, 0, v3, vcc_lo                        // 000000503A28: 02020680
	s_mov_b32 s40, 0                                           // 000000503A2C: BEA80080
	s_mov_b32 s41, 0x76543210                                  // 000000503A30: BEA900FF 76543210
	s_cvt_u32_f32 s8, s8                                       // 000000503A38: BE886708
	s_lshl_b32 s43, s11, 8                                     // 000000503A3C: 842B880B
	s_sub_i32 s44, 0, s7                                       // 000000503A40: 81AC0780
	s_mov_b32 s46, 0x3db504f3                                  // 000000503A44: BEAE00FF 3DB504F3
	s_mul_i32 s9, s9, s8                                       // 000000503A4C: 96090809
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000503A50: BF870499
	s_mul_hi_u32 s9, s8, s9                                    // 000000503A54: 96890908
	s_add_i32 s45, s8, s9                                      // 000000503A58: 812D0908
	s_branch 161                                               // 000000503A5C: BFA000A1 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x3e4>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000503A60: BF870091
	.long 0xd7006a02                                           // 000000503A64: D7006A02
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 000000503A68: 0202040C
	v_add_co_ci_u32_e64 v3, null, s13, v3, vcc_lo              // 000000503A6C: D5207C03 01AA060D
	v_add_nc_u32_e32 v1, 0x400, v1                             // 000000503A74: 4A0202FF 00000400
	global_load_d16_b16 v2, v[2:3], off offset:6               // 000000503A7C: DC820006 027C0002
	v_add_f32_e32 v3, v16, v14                                 // 000000503A84: 06061D10
	s_waitcnt vmcnt(0)                                         // 000000503A88: BF8903F7
	v_fma_mix_f32 v5, v15, v2, v13 op_sel_hi:[0,1,0]           // 000000503A8C: CC200005 1436050F
	v_sub_f32_e32 v4, v16, v14                                 // 000000503A94: 08081D10
	v_fma_mix_f32 v2, -v15, v2, v13 op_sel_hi:[0,1,0]          // 000000503A98: CC200002 3436050F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000503AA0: BF870121
	v_dual_add_f32 v6, v3, v5 :: v_dual_add_f32 v7, v4, v2     // 000000503AA4: C9080B03 06060504
	v_sub_f32_e32 v2, v4, v2                                   // 000000503AAC: 08040504
	v_mov_b32_dpp v4, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000503AB0: 7E0802FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 000000503AB8: D5010006 20060D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000503AC0: BF870241
	v_dual_add_f32 v4, v6, v4 :: v_dual_sub_f32 v3, v3, v5     // 000000503AC4: C90A0906 04020B03
	v_mov_b32_dpp v5, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000503ACC: 7E0A02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 000000503AD4: D5010007 20060F07
	.long 0xd72c0006                                           // 000000503ADC: D72C0006
	v_cndmask_b32_e32 v1, 0x1400, v12, vcc_lo                  // 000000503AE0: 020218FF 00001400
	v_mov_b32_dpp v13, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000503AE8: 7E1A02FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 000000503AF0: D5010003 20060703
	s_delay_alu instid0(VALU_DEP_4)                            // 000000503AF8: BF870004
	v_add_f32_e32 v5, v7, v5                                   // 000000503AFC: 060A0B07
	v_mov_b32_dpp v14, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000503B00: 7E1C02FA FF016102
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 000000503B08: D5010002 20060502
	v_mov_b32_dpp v7, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000503B10: 7E0E02FA FF016204
	v_add_f32_e32 v3, v3, v13                                  // 000000503B18: 06061B03
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000503B1C: D5010004 200E0904
	v_mov_b32_dpp v12, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000503B24: 7E1802FA FF016205
	v_add_f32_e32 v2, v2, v14                                  // 000000503B2C: 06041D02
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 000000503B30: D5010005 200E0B05
	v_mov_b32_dpp v13, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000503B38: 7E1A02FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 000000503B40: D5010003 200E0703
	v_add_f32_e32 v4, v4, v7                                   // 000000503B48: 06080F04
	v_mov_b32_dpp v14, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000503B4C: 7E1C02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 000000503B54: D5010002 200E0502
	v_add_f32_e32 v5, v5, v12                                  // 000000503B5C: 060A1905
	.long 0xd72c0007                                           // 000000503B60: D72C0007
	v_cndmask_b32_e32 v1, s43, v11, vcc_lo                     // 000000503B64: 0202162B
	v_add_f32_e32 v3, v3, v13                                  // 000000503B68: 06061B03
	v_mov_b32_dpp v11, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000503B6C: 7E1602FA FF016404
	v_add_f32_e32 v2, v2, v14                                  // 000000503B74: 06041D02
	v_cndmask_b32_e64 v4, -v4, v4, s5                          // 000000503B78: D5010004 20160904
	v_mov_b32_dpp v12, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000503B80: 7E1802FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s5                          // 000000503B88: D5010005 20160B05
	v_mov_b32_dpp v13, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000503B90: 7E1A02FA FF016403
	v_mov_b32_dpp v14, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000503B98: 7E1C02FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s5                          // 000000503BA0: D5010002 20160502
	v_cndmask_b32_e64 v3, -v3, v3, s5                          // 000000503BA8: D5010003 20160703
	v_dual_add_f32 v4, v4, v11 :: v_dual_add_f32 v5, v5, v12   // 000000503BB0: C9081704 04041905
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000503BB8: BF8701A3
	v_dual_add_f32 v2, v2, v14 :: v_dual_add_nc_u32 v9, 8, v9  // 000000503BBC: C9201D02 02081288
	v_sub_nc_u32_e32 v6, v6, v7                                // 000000503BC4: 4C0C0F06
	v_mov_b32_dpp v11, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000503BC8: 7E1602FA FF016804
	v_cndmask_b32_e64 v4, -v4, v4, s6                          // 000000503BD0: D5010004 201A0904
	v_add_f32_e32 v3, v3, v13                                  // 000000503BD8: 06061B03
	v_mov_b32_dpp v12, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000503BDC: 7E1802FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s6                          // 000000503BE4: D5010005 201A0B05
	v_mov_b32_dpp v14, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000503BEC: 7E1C02FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s6                          // 000000503BF4: D5010002 201A0502
	v_add_f32_e32 v4, v4, v11                                  // 000000503BFC: 06081704
	v_mov_b32_dpp v13, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000503C00: 7E1A02FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s6                          // 000000503C08: D5010003 201A0703
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000503C10: BF870214
	v_dual_add_f32 v5, v5, v12 :: v_dual_add_f32 v2, v2, v14   // 000000503C14: C9081905 05021D02
	v_mov_b32_e32 v11, v4                                      // 000000503C1C: 7E160304
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 000000503C20: D5010004 20020904
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000503C28: BF870213
	v_dual_add_f32 v3, v3, v13 :: v_dual_mov_b32 v12, v5       // 000000503C2C: C9101B03 030C0105
	v_mov_b32_e32 v14, v2                                      // 000000503C34: 7E1C0302
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000503C38: BF870224
	v_permlanex16_b32 v11, v11, s41, 0xfedcba98                // 000000503C3C: D65C000B 03FC530B FEDCBA98
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 000000503C48: D5010005 20020B05
	v_mov_b32_e32 v13, v3                                      // 000000503C50: 7E1A0303
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 000000503C54: D5010002 20020502
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 000000503C5C: D5010003 20020703
	v_permlanex16_b32 v12, v12, s41, 0xfedcba98                // 000000503C64: D65C000C 03FC530C FEDCBA98
	v_permlanex16_b32 v14, v14, s41, 0xfedcba98                // 000000503C70: D65C000E 03FC530E FEDCBA98
	v_add_f32_e32 v4, v4, v11                                  // 000000503C7C: 06081704
	v_permlanex16_b32 v13, v13, s41, 0xfedcba98                // 000000503C80: D65C000D 03FC530D FEDCBA98
	v_cmp_le_i32_e32 vcc_lo, s10, v9                           // 000000503C8C: 7C86120A
	v_dual_add_f32 v5, v5, v12 :: v_dual_add_nc_u32 v6, v10, v6// 000000503C90: C9201905 05060D0A
	v_add_f32_e32 v7, v2, v14                                  // 000000503C98: 060E1D02
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000503C9C: BF870194
	v_dual_add_f32 v11, v3, v13 :: v_dual_add_nc_u32 v10, 0x800, v10// 000000503CA0: C9201B03 0B0A14FF 00000800
	v_fma_mixhi_f16 v2, v5, s46, 0                             // 000000503CAC: CC220002 02005D05
	v_fma_mixlo_f16 v2, v4, s46, 0                             // 000000503CB4: CC210002 02005D04
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000503CBC: BF870214
	v_fma_mixhi_f16 v3, v7, s46, 0                             // 000000503CC0: CC220003 02005D07
	v_fma_mixlo_f16 v3, v11, s46, 0                            // 000000503CC8: CC210003 02005D0B
	s_or_b32 s40, vcc_lo, s40                                  // 000000503CD0: 8C28286A
	ds_store_b64 v6, v[2:3]                                    // 000000503CD4: D9340000 00000206
	s_and_not1_b32 exec_lo, exec_lo, s40                       // 000000503CDC: 917E287E
	s_cbranch_execz 289                                        // 000000503CE0: BFA50121 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x868>
	.long 0xd72d0002                                           // 000000503CE4: D72D0002
	v_cndmask_b32_e32 v0, v9, v45, vcc_lo                      // 000000503CE8: 02005B09
	s_mov_b32 s7, -1                                           // 000000503CEC: BE8700C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000503CF0: BF870091
	.long 0xd72c0003                                           // 000000503CF4: D72C0003
	v_cndmask_b32_e32 v0, v2, v38, vcc_lo                      // 000000503CF8: 02004D02
	v_sub_nc_u32_e32 v3, v9, v3                                // 000000503CFC: 4C060709
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000503D00: BF870121
	v_subrev_nc_u32_e32 v5, s38, v3                            // 000000503D04: 4E0A0626
	v_cmp_le_u32_e32 vcc_lo, s38, v3                           // 000000503D08: 7C960626
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_add_nc_u32 v4, 1, v2// 000000503D0C: CA600B03 03040481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000503D14: BF870111
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000503D18: 02040902
	v_cmp_le_u32_e32 vcc_lo, s38, v3                           // 000000503D1C: 7C960626
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000503D20: BF870092
	v_add_nc_u32_e32 v4, 1, v2                                 // 000000503D24: 4A080481
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000503D28: 02040902
	s_and_not1_b32 vcc_lo, exec_lo, s37                        // 000000503D2C: 916A257E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000503D30: BF870091
	v_xor_b32_e32 v12, s42, v2                                 // 000000503D34: 3A18042A
	v_subrev_nc_u32_e32 v11, s42, v12                          // 000000503D38: 4E16182A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000503D3C: BF8700A1
	v_mad_u64_u32 v[6:7], null, s44, v11, v[1:2]               // 000000503D40: D6FE7C06 0406162C
	v_min_i32_e32 v2, s36, v11                                 // 000000503D48: 22041624
	v_mad_i64_i32 v[4:5], null, v2, s39, 0                     // 000000503D4C: D6FF7C04 02004F02
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000503D54: BF870093
	v_ashrrev_i32_e32 v7, 31, v6                               // 000000503D58: 340E0C9F
	.long 0xd73c0002                                           // 000000503D5C: D73C0002
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000503D60: 02020C81
	s_cbranch_vccnz 211                                        // 000000503D64: BFA400D3 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x7b4>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000503D68: BF870093
	.long 0xd7006a06                                           // 000000503D6C: D7006A06
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 000000503D70: 02020D04
	v_add_co_ci_u32_e64 v7, null, v5, v7, vcc_lo               // 000000503D74: D5207C07 01AA0F05
	.long 0x7f3a3880                                           // 000000503D7C: 7F3A3880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000503D80: BF870112
	.long 0xd73c0006                                           // 000000503D84: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000503D88: 02020C81
	.long 0x7f40399d                                           // 000000503D8C: 7F40399D
	s_waitcnt lgkmcnt(0)                                       // 000000503D90: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000503D94: BF870092
	.long 0xd7006a0d                                           // 000000503D98: D7006A0D
	v_cndmask_b32_e32 v1, s30, v6, vcc_lo                      // 000000503D9C: 02020C1E
	v_add_co_ci_u32_e64 v14, null, s31, v7, vcc_lo             // 000000503DA0: D5207C0E 01AA0E1F
	.long 0xd7006a06                                           // 000000503DA8: D7006A06
	v_cndmask_b32_e32 v1, s22, v6, vcc_lo                      // 000000503DAC: 02020C16
	s_delay_alu instid0(VALU_DEP_1)                            // 000000503DB0: BF870001
	v_add_co_ci_u32_e64 v7, null, s23, v7, vcc_lo              // 000000503DB4: D5207C07 01AA0E17
	global_load_b64 v[13:14], v[13:14], off                    // 000000503DBC: DC560000 0D7C000D
	.long 0xd7006a0f                                           // 000000503DC4: D7006A0F
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 000000503DC8: 0202040C
	global_load_b64 v[6:7], v[6:7], off                        // 000000503DCC: DC560000 067C0006
	v_add_co_ci_u32_e64 v16, null, s13, v3, vcc_lo             // 000000503DD4: D5207C10 01AA060D
	s_clause 0x1                                               // 000000503DDC: BF850001
	global_load_b32 v17, v[15:16], off                         // 000000503DE0: DC520000 117C000F
	global_load_d16_b16 v15, v[15:16], off offset:4            // 000000503DE8: DC820004 0F7C000F
	s_waitcnt vmcnt(3)                                         // 000000503DF0: BF890FF7
	.long 0x7e20390d                                           // 000000503DF4: 7E20390D
	s_waitcnt vmcnt(2)                                         // 000000503DF8: BF890BF7
	v_and_b32_e32 v39, 0xffff0000, v6                          // 000000503DFC: 364E0CFF FFFF0000
	v_lshlrev_b32_e32 v6, 16, v6                               // 000000503E04: 300C0C90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000503E08: BF870093
	v_lshlrev_b32_e32 v16, 16, v16                             // 000000503E0C: 30202090
	v_mul_f32_e32 v20, 0xbfb8aa3b, v16                         // 000000503E10: 102820FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000503E18: BF870291
	v_exp_f32_e32 v20, v20                                     // 000000503E1C: 7E284B14
	v_dual_add_f32 v20, 1.0, v20 :: v_dual_and_b32 v13, 0xffff0000, v13// 000000503E20: C92428F2 140C1AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000503E2C: BF870111
	v_mul_f32_e32 v19, 0xbfb8aa3b, v13                         // 000000503E30: 10261AFF BFB8AA3B
	v_div_scale_f32 v24, null, v20, v20, v16                   // 000000503E38: D6FC7C18 04422914
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000503E40: BF8701B2
	v_exp_f32_e32 v19, v19                                     // 000000503E44: 7E264B13
	v_lshlrev_b32_e32 v18, 16, v14                             // 000000503E48: 30241C90
	v_div_scale_f32 v37, s8, v16, v20, v16                     // 000000503E4C: D6FC0825 04422910
	v_rcp_f32_e32 v28, v24                                     // 000000503E54: 7E385518
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000503E58: BF870196
	v_add_f32_e32 v19, 1.0, v19                                // 000000503E5C: 062626F2
	v_mul_f32_e32 v21, 0xbfb8aa3b, v18                         // 000000503E60: 102A24FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000503E68: BF870195
	v_fma_f32 v36, -v24, v28, 1.0                              // 000000503E6C: D6130024 23CA3918
	v_div_scale_f32 v23, null, v19, v19, v13                   // 000000503E74: D6FC7C17 04362713
	s_delay_alu instid0(VALU_DEP_3)                            // 000000503E7C: BF870003
	v_exp_f32_e32 v21, v21                                     // 000000503E80: 7E2A4B15
	v_and_b32_e32 v14, 0xffff0000, v14                         // 000000503E84: 361C1CFF FFFF0000
	v_div_scale_f32 v33, vcc_lo, v13, v19, v13                 // 000000503E8C: D6FC6A21 0436270D
	v_fmac_f32_e32 v28, v36, v28                               // 000000503E94: 56383924
	v_rcp_f32_e32 v26, v23                                     // 000000503E98: 7E345517
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_3)   // 000000503E9C: BF870186
	v_dual_add_f32 v21, 1.0, v21 :: v_dual_mul_f32 v22, 0xbfb8aa3b, v14// 000000503EA0: C9062AF2 15161CFF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000503EAC: BF870115
	v_fma_f32 v34, -v23, v26, 1.0                              // 000000503EB0: D6130022 23CA3517
	v_div_scale_f32 v25, null, v21, v21, v18                   // 000000503EB8: D6FC7C19 044A2B15
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000503EC0: BF8701A3
	v_exp_f32_e32 v22, v22                                     // 000000503EC4: 7E2C4B16
	v_div_scale_f32 v35, s7, v18, v21, v18                     // 000000503EC8: D6FC0723 044A2B12
	v_fmac_f32_e32 v26, v34, v26                               // 000000503ED0: 56343522
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000503ED4: BF870313
	v_rcp_f32_e32 v30, v25                                     // 000000503ED8: 7E3C5519
	v_add_f32_e32 v22, 1.0, v22                                // 000000503EDC: 062C2CF2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000503EE0: BF870115
	v_fma_f32 v38, -v25, v30, 1.0                              // 000000503EE4: D6130026 23CA3D19
	v_div_scale_f32 v27, null, v22, v22, v14                   // 000000503EEC: D6FC7C1B 043A2D16
	v_div_scale_f32 v36, s9, v14, v22, v14                     // 000000503EF4: D6FC0924 043A2D0E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000503EFC: BF870193
	v_fmac_f32_e32 v30, v38, v30                               // 000000503F00: 563C3D26
	v_rcp_f32_e32 v31, v27                                     // 000000503F04: 7E3E551B
	v_mul_f32_e32 v38, v33, v26                                // 000000503F08: 104C3521
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000503F0C: BF870291
	v_fma_f32 v44, -v23, v38, v33                              // 000000503F10: D613002C 24864D17
	v_fma_f32 v34, -v27, v31, 1.0                              // 000000503F18: D6130022 23CA3F1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000503F20: BF870091
	v_dual_fmac_f32 v38, v44, v26 :: v_dual_fmac_f32 v31, v34, v31// 000000503F24: C800352C 261E3F22
	v_fma_f32 v23, -v23, v38, v33                              // 000000503F2C: D6130017 24864D17
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000503F34: BF870092
	v_mul_f32_e32 v45, v36, v31                                // 000000503F38: 105A3F24
	v_fma_f32 v44, -v27, v45, v36                              // 000000503F3C: D613002C 24925B1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000503F44: BF870211
	v_fmac_f32_e32 v45, v44, v31                               // 000000503F48: 565A3F2C
	v_div_fmas_f32 v23, v23, v26, v38                          // 000000503F4C: D6370017 049A3517
	s_mov_b32 vcc_lo, s8                                       // 000000503F54: BEEA0008
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000503F58: BF870191
	v_div_fixup_f32 v13, v23, v19, v13                         // 000000503F5C: D627000D 04362717
	v_fma_f32 v23, -v27, v45, v36                              // 000000503F64: D6130017 24925B1B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000503F6C: BF870122
	v_mul_f32_e32 v13, v13, v39                                // 000000503F70: 101A4F0D
	v_dual_mul_f32 v34, v37, v28 :: v_dual_mul_f32 v43, v35, v30// 000000503F74: C8C63925 222A3D23
	.long 0x7e3a398d                                           // 000000503F7C: 7E3A398D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000503F80: BF870192
	v_fma_f32 v46, -v24, v34, v37                              // 000000503F84: D613002E 24964518
	v_fma_f32 v47, -v25, v43, v35                              // 000000503F8C: D613002F 248E5719
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000503F94: BF870091
	v_dual_fmac_f32 v34, v46, v28 :: v_dual_fmac_f32 v43, v47, v30// 000000503F98: C800392E 222A3D2F
	v_fma_f32 v24, -v24, v34, v37                              // 000000503FA0: D6130018 24964518
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000503FA8: BF870112
	v_fma_f32 v25, -v25, v43, v35                              // 000000503FAC: D6130019 248E5719
	v_div_fmas_f32 v24, v24, v28, v34                          // 000000503FB4: D6370018 048A3918
	s_mov_b32 vcc_lo, s7                                       // 000000503FBC: BEEA0007
	s_mov_b32 s7, 0                                            // 000000503FC0: BE870080
	s_delay_alu instid0(VALU_DEP_2)                            // 000000503FC4: BF870002
	v_div_fmas_f32 v19, v25, v30, v43                          // 000000503FC8: D6370013 04AE3D19
	s_mov_b32 vcc_lo, s9                                       // 000000503FD0: BEEA0009
	v_div_fixup_f32 v16, v24, v20, v16                         // 000000503FD4: D6270010 04422918
	v_lshlrev_b32_e32 v20, 16, v7                              // 000000503FDC: 30280E90
	v_and_b32_e32 v7, 0xffff0000, v7                           // 000000503FE0: 360E0EFF FFFF0000
	v_div_fixup_f32 v18, v19, v21, v18                         // 000000503FE8: D6270012 044A2B13
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000503FF0: BF8700A4
	v_mul_f32_e32 v6, v16, v6                                  // 000000503FF4: 100C0D10
	v_div_fmas_f32 v16, v23, v31, v45                          // 000000503FF8: D6370010 04B63F17
	v_div_fixup_f32 v14, v16, v22, v14                         // 000000504000: D627000E 043A2D10
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000504008: BF870091
	v_dual_mul_f32 v7, v14, v7 :: v_dual_and_b32 v16, 1, v29   // 00000050400C: C8E40F0E 07103A81
	v_add3_u32 v13, v13, v16, 0x7fff                           // 000000504014: D655000D 03FE210D 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000504020: BF870112
	v_bfe_u32 v16, v7, 16, 1                                   // 000000504024: D6100010 02052107
	v_and_b32_e32 v13, 0xffff0000, v13                         // 00000050402C: 361A1AFF FFFF0000
	.long 0x7e403986                                           // 000000504034: 7E403986
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000504038: BF8701A3
	v_add3_u32 v7, v7, v16, 0x7fff                             // 00000050403C: D6550007 03FE2107 00007FFF
	v_mul_f32_e32 v18, v18, v20                                // 000000504048: 10242912
	v_and_b32_e32 v20, 1, v32                                  // 00000050404C: 36284081
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000504050: BF870112
	v_bfe_u32 v19, v18, 16, 1                                  // 000000504054: D6100013 02052112
	v_add3_u32 v6, v6, v20, 0x7fff                             // 00000050405C: D6550006 03FE2906 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000504068: BF870112
	v_add3_u32 v14, v18, v19, 0x7fff                           // 00000050406C: D655000E 03FE2712 00007FFF
	v_and_b32_e32 v6, 0xffff0000, v6                           // 000000504078: 360C0CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000504080: BF8701B2
	v_and_b32_e32 v18, 0xffff0000, v14                         // 000000504084: 36241CFF FFFF0000
	s_waitcnt vmcnt(1)                                         // 00000050408C: BF8907F7
	v_fma_mix_f32 v14, v17, v13, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000504090: CC20080E 8A021B11
	v_fma_mix_f32 v16, v17, v6, neg(0) op_sel_hi:[1,0,0]       // 000000504098: CC200010 8A020D11
	s_waitcnt vmcnt(0)                                         // 0000005040A0: BF8903F7
	v_fma_mix_f32 v13, v15, v18, neg(0) op_sel_hi:[1,0,0]      // 0000005040A4: CC20000D 8A02250F
	v_and_b32_e32 v15, 0xffff0000, v7                          // 0000005040AC: 361E0EFF FFFF0000
	s_and_not1_b32 vcc_lo, exec_lo, s7                         // 0000005040B4: 916A077E
	s_cbranch_vccnz 65129                                      // 0000005040B8: BFA4FE69 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x160>
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005040BC: BF8700A3
	.long 0xd73c0004                                           // 0000005040C0: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 0000005040C4: 02020881
	s_waitcnt lgkmcnt(0)                                       // 0000005040C8: BF89FC07
	.long 0xd7006a04                                           // 0000005040CC: D7006A04
	v_cndmask_b32_e32 v1, s30, v4, vcc_lo                      // 0000005040D0: 0202081E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000005040D4: BF870111
	v_add_co_ci_u32_e64 v5, null, s31, v5, vcc_lo              // 0000005040D8: D5207C05 01AA0A1F
	.long 0xd7006a04                                           // 0000005040E0: D7006A04
	v_cndmask_b32_e32 v1, v4, v2, vcc_lo                       // 0000005040E4: 02020504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005040E8: BF8700A1
	v_add_co_ci_u32_e64 v5, null, v5, v3, vcc_lo               // 0000005040EC: D5207C05 01AA0705
	.long 0xd7006a06                                           // 0000005040F4: D7006A06
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 0000005040F8: 0202040C
	v_add_co_ci_u32_e64 v7, null, s13, v3, vcc_lo              // 0000005040FC: D5207C07 01AA060D
	global_load_b64 v[4:5], v[4:5], off                        // 000000504104: DC560000 047C0004
	s_clause 0x1                                               // 00000050410C: BF850001
	global_load_b32 v15, v[6:7], off                           // 000000504110: DC520000 0F7C0006
	global_load_d16_b16 v6, v[6:7], off offset:4               // 000000504118: DC820004 067C0006
	s_waitcnt vmcnt(2)                                         // 000000504120: BF890BF7
	.long 0x7e0e3904                                           // 000000504124: 7E0E3904
	v_and_b32_e32 v4, 0xffff0000, v4                           // 000000504128: 360808FF FFFF0000
	v_lshlrev_b32_e32 v13, 16, v5                              // 000000504130: 301A0A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000504134: BF8701A3
	v_lshlrev_b32_e32 v7, 16, v7                               // 000000504138: 300E0E90
	s_waitcnt vmcnt(1)                                         // 00000050413C: BF8907F7
	v_fma_mix_f32 v14, v15, v4, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000504140: CC20080E 8A02090F
	s_waitcnt vmcnt(0)                                         // 000000504148: BF8903F7
	v_fma_mix_f32 v13, v6, v13, neg(0) op_sel_hi:[1,0,0]       // 00000050414C: CC20000D 8A021B06
	v_fma_mix_f32 v16, v15, v7, neg(0) op_sel_hi:[1,0,0]       // 000000504154: CC200010 8A020F0F
	v_and_b32_e32 v15, 0xffff0000, v5                          // 00000050415C: 361E0AFF FFFF0000
	s_branch 65086                                             // 000000504164: BFA0FE3E <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x160>
	s_or_b32 exec_lo, exec_lo, s40                             // 000000504168: 8C7E287E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000050416C: BF870009
	s_or_b32 exec_lo, exec_lo, s35                             // 000000504170: 8C7E237E
	s_bfe_i32 s10, s11, 0x1001c                                // 000000504174: 938AFF0B 0001001C
	v_mad_u32_u24 v10, v42, 24, 0x2f0                          // 00000050417C: D60B000A 03FD312A 000002F0
	s_lshr_b64 s[0:1], s[10:11], 29                            // 000000504188: 85809D0A
	s_lshr_b32 s1, s34, 28                                     // 00000050418C: 85019C22
	s_add_i32 s0, s0, 7                                        // 000000504190: 81008700
	s_add_i32 s1, s25, s1                                      // 000000504194: 81010119
	s_ashr_i32 s0, s0, 3                                       // 000000504198: 86008300
	v_lshrrev_b32_e32 v1, 5, v10                               // 00000050419C: 32021485
	.long 0xd72c0007                                           // 0000005041A0: D72C0007
	v_cndmask_b32_e32 v1, s0, v40, vcc_lo                      // 0000005041A4: 02025000
	s_ashr_i32 s1, s1, 4                                       // 0000005041A8: 86018401
	s_lshl_b32 s3, s11, 3                                      // 0000005041AC: 8403830B
	s_lshl_b32 s5, s33, 3                                      // 0000005041B0: 84058321
	s_mul_i32 s7, s1, s2                                       // 0000005041B4: 96070201
	s_ashr_i32 s6, s5, 31                                      // 0000005041B8: 86069F05
	v_subrev_nc_u32_e32 v1, 24, v1                             // 0000005041BC: 4E020298
	v_cmp_eq_u32_e32 vcc_lo, 0, v42                            // 0000005041C0: 7C945480
	v_add_nc_u32_e32 v2, s0, v7                                // 0000005041C4: 4A040E00
	s_mul_hi_i32 s0, s1, s2                                    // 0000005041C8: 97000201
	s_add_u32 s1, s7, s5                                       // 0000005041CC: 80010507
	s_addc_u32 s0, s0, s6                                      // 0000005041D0: 82000600
	s_mul_hi_u32 s5, s1, 0x300                                 // 0000005041D4: 9685FF01 00000300
	v_min_i32_e32 v43, s3, v2                                  // 0000005041DC: 22560403
	s_mul_i32 s3, s0, 0x300                                    // 0000005041E0: 9603FF00 00000300
	s_mulk_i32 s1, 0x300                                       // 0000005041E8: B8010300
	v_cndmask_b32_e64 v16, v1, 23, vcc_lo                      // 0000005041EC: D5010010 01A92F01
	v_add_nc_u32_e32 v11, 8, v10                               // 0000005041F4: 4A161488
	.long 0xd4410000                                           // 0000005041F8: D4410000
	v_cndmask_b32_e32 v1, v7, v43, vcc_lo                      // 0000005041FC: 02025707
	s_add_i32 s5, s5, s3                                       // 000000504200: 81050305
	s_waitcnt lgkmcnt(0)                                       // 000000504204: BF89FC07
	s_add_u32 s6, s28, s1                                      // 000000504208: 8006011C
	s_addc_u32 s7, s29, s5                                     // 00000050420C: 8207051D
	s_barrier                                                  // 000000504210: BFBD0000
	buffer_gl0_inv                                             // 000000504214: E0AC0000 00000000
	s_and_saveexec_b32 s3, s0                                  // 00000050421C: BE832000
	s_cbranch_execz 121                                        // 000000504220: BFA50079 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xb08>
	v_lshrrev_b32_e32 v1, 5, v11                               // 000000504224: 32021685
	.long 0xd4440001                                           // 000000504228: D4440001
	v_cndmask_b32_e32 v1, 23, v16, vcc_lo                      // 00000050422C: 02022097
	v_mov_b32_e32 v17, 0                                       // 000000504230: 7E220280
	v_mad_i64_i32 v[3:4], null, 0x300, v7, s[6:7]              // 000000504234: D6FF7C03 001A0EFF 00000300
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000504240: BF870214
	v_subrev_nc_u32_e32 v1, 24, v1                             // 000000504244: 4E020298
	v_cndmask_b32_e64 v2, 0xe9, 1, s1                          // 000000504248: D5010002 000502FF 000000E9
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000504254: BF870112
	v_cndmask_b32_e64 v1, v1, 23, vcc_lo                       // 000000504258: D5010001 01A92F01
	v_dual_mov_b32 v2, v17 :: v_dual_add_nc_u32 v9, v2, v16    // 000000504260: CA200111 02082102
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000504268: BF870112
	.long 0xd4440001                                           // 00000050426C: D4440001
	v_cndmask_b32_e32 v1, 23, v1, vcc_lo                       // 000000504270: 02020297
	v_lshlrev_b32_e32 v12, 24, v9                              // 000000504274: 30181298
	.long 0xd73c0005                                           // 000000504278: D73C0005
	v_cndmask_b32_e32 v1, 2, v16, vcc_lo                       // 00000050427C: 02022082
	v_bfe_i32 v9, v9, 7, 1                                     // 000000504280: D6110009 02050F09
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000504288: BF870214
	v_cndmask_b32_e64 v13, 0xe9, 1, s1                         // 00000050428C: D501000D 000502FF 000000E9
	v_ashrrev_i32_e32 v12, 22, v12                             // 000000504298: 34181896
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000050429C: BF870194
	.long 0xd7000105                                           // 0000005042A0: D7000105
	v_cndmask_b32_e32 v1, v3, v5, vcc_lo                       // 0000005042A4: 02020B03
	v_add_nc_u32_e32 v13, v13, v1                              // 0000005042A8: 4A1A030D
	.long 0xd73c0001                                           // 0000005042AC: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000005042B0: 02020282
	v_add_co_ci_u32_e64 v6, null, v4, v6, s1                   // 0000005042B4: D5207C06 00060D04
	.long 0xd700010e                                           // 0000005042BC: D700010E
	v_cndmask_b32_e32 v1, v3, v12, vcc_lo                      // 0000005042C0: 02021903
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000005042C4: BF870244
	v_lshlrev_b32_e32 v17, 24, v13                             // 0000005042C8: 30221A98
	v_add_co_ci_u32_e64 v15, null, v4, v9, s1                  // 0000005042CC: D5207C0F 00061304
	v_bfe_i32 v9, v13, 7, 1                                    // 0000005042D4: D6110009 02050F0D
	.long 0xd700012c                                           // 0000005042DC: D700012C
	v_cndmask_b32_e32 v1, v3, v1, vcc_lo                       // 0000005042E0: 02020303
	v_ashrrev_i32_e32 v12, 22, v17                             // 0000005042E4: 34182296
	v_add_co_ci_u32_e64 v45, null, v4, v2, s1                  // 0000005042E8: D5207C2D 00060504
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005042F0: BF870092
	.long 0xd700012e                                           // 0000005042F4: D700012E
	v_cndmask_b32_e32 v1, v3, v12, vcc_lo                      // 0000005042F8: 02021903
	v_add_co_ci_u32_e64 v47, null, v4, v9, s1                  // 0000005042FC: D5207C2F 00061304
	s_clause 0x1f                                              // 000000504304: BF85001F
	global_load_b32 v4, v[5:6], off                            // 000000504308: DC520000 047C0005
	global_load_b32 v2, v[5:6], off offset:96                  // 000000504310: DC520060 027C0005
	global_load_b32 v35, v[5:6], off offset:192                // 000000504318: DC5200C0 237C0005
	global_load_b32 v31, v[5:6], off offset:288                // 000000504320: DC520120 1F7C0005
	global_load_b32 v27, v[5:6], off offset:384                // 000000504328: DC520180 1B7C0005
	global_load_b32 v23, v[5:6], off offset:480                // 000000504330: DC5201E0 177C0005
	global_load_b32 v19, v[5:6], off offset:576                // 000000504338: DC520240 137C0005
	global_load_b32 v13, v[5:6], off offset:672                // 000000504340: DC5202A0 0D7C0005
	global_load_b32 v3, v[14:15], off                          // 000000504348: DC520000 037C000E
	global_load_b32 v1, v[14:15], off offset:96                // 000000504350: DC520060 017C000E
	global_load_b32 v34, v[14:15], off offset:192              // 000000504358: DC5200C0 227C000E
	global_load_b32 v30, v[14:15], off offset:288              // 000000504360: DC520120 1E7C000E
	global_load_b32 v26, v[14:15], off offset:384              // 000000504368: DC520180 1A7C000E
	global_load_b32 v22, v[14:15], off offset:480              // 000000504370: DC5201E0 167C000E
	global_load_b32 v18, v[14:15], off offset:576              // 000000504378: DC520240 127C000E
	global_load_b32 v12, v[14:15], off offset:672              // 000000504380: DC5202A0 0C7C000E
	global_load_b32 v6, v[44:45], off                          // 000000504388: DC520000 067C002C
	global_load_b32 v39, v[44:45], off offset:96               // 000000504390: DC520060 277C002C
	global_load_b32 v37, v[44:45], off offset:192              // 000000504398: DC5200C0 257C002C
	global_load_b32 v33, v[44:45], off offset:288              // 0000005043A0: DC520120 217C002C
	global_load_b32 v29, v[44:45], off offset:384              // 0000005043A8: DC520180 1D7C002C
	global_load_b32 v25, v[44:45], off offset:480              // 0000005043B0: DC5201E0 197C002C
	global_load_b32 v21, v[44:45], off offset:576              // 0000005043B8: DC520240 157C002C
	global_load_b32 v15, v[44:45], off offset:672              // 0000005043C0: DC5202A0 0F7C002C
	global_load_b32 v5, v[46:47], off                          // 0000005043C8: DC520000 057C002E
	global_load_b32 v38, v[46:47], off offset:96               // 0000005043D0: DC520060 267C002E
	global_load_b32 v36, v[46:47], off offset:192              // 0000005043D8: DC5200C0 247C002E
	global_load_b32 v32, v[46:47], off offset:288              // 0000005043E0: DC520120 207C002E
	global_load_b32 v28, v[46:47], off offset:384              // 0000005043E8: DC520180 1C7C002E
	global_load_b32 v24, v[46:47], off offset:480              // 0000005043F0: DC5201E0 187C002E
	global_load_b32 v20, v[46:47], off offset:576              // 0000005043F8: DC520240 147C002E
	global_load_b32 v14, v[46:47], off offset:672              // 000000504400: DC5202A0 0E7C002E
	s_or_b32 exec_lo, exec_lo, s3                              // 000000504408: 8C7E037E
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v44, 0              // 00000050440C: CA100080 092C0080
	v_dual_mov_b32 v45, 0 :: v_dual_mov_b32 v46, 0             // 000000504414: CA100080 2D2E0080
	v_dual_mov_b32 v48, 0 :: v_dual_mov_b32 v49, 0             // 00000050441C: CA100080 30300080
	v_dual_mov_b32 v50, 0 :: v_dual_mov_b32 v47, 0             // 000000504424: CA100080 322E0080
	v_dual_mov_b32 v51, 0 :: v_dual_mov_b32 v52, 0             // 00000050442C: CA100080 33340080
	v_dual_mov_b32 v53, 0 :: v_dual_mov_b32 v54, 0             // 000000504434: CA100080 35360080
	v_dual_mov_b32 v56, 0 :: v_dual_mov_b32 v57, 0             // 00000050443C: CA100080 38380080
	v_dual_mov_b32 v55, 0 :: v_dual_mov_b32 v58, 0             // 000000504444: CA100080 373A0080
	s_ashr_i32 s3, s2, 31                                      // 00000050444C: 86039F02
	s_and_saveexec_b32 s1, s0                                  // 000000504450: BE812000
	s_cbranch_execz 1088                                       // 000000504454: BFA50440 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1c58>
	v_lshrrev_b32_e32 v9, 5, v11                               // 000000504458: 32121685
	v_or_b32_e32 v44, 4, v8                                    // 00000050445C: 38581084
	v_mul_i32_i24_e32 v11, 0xffffffe8, v42                     // 000000504460: 121654FF FFFFFFE8
	v_dual_mov_b32 v45, 23 :: v_dual_and_b32 v10, 0x7e0, v10   // 000000504468: CA240097 2D0A14FF 000007E0
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000504474: BF870234
	v_subrev_nc_u32_e32 v8, 24, v9                             // 000000504478: 4E101298
	.long 0xd7030033                                           // 00000050447C: D7030033
	v_cndmask_b32_e32 v0, v16, v129, vcc_lo                    // 000000504480: 02010310
	v_ashrrev_i32_e32 v17, 31, v16                             // 000000504484: 3422209F
	v_add3_u32 v60, v11, v10, 0xfffffd34                       // 000000504488: D655003C 03FE150B FFFFFD34
	.long 0x7e62392d                                           // 000000504494: 7E62392D
	v_cndmask_b32_e64 v8, v8, 23, vcc_lo                       // 000000504498: D5010008 01A92F08
	.long 0xd762002f                                           // 0000005044A0: D762002F
	v_cndmask_b32_e32 v1, 0xff, v51, vcc_lo                    // 0000005044A4: 020266FF 000000FF
	.long 0xd73c000a                                           // 0000005044AC: D73C000A
	v_cndmask_b32_e32 v1, 2, v16, vcc_lo                       // 0000005044B0: 02022082
	v_mad_u32_u24 v52, v44, 3, 0x2f0                           // 0000005044B4: D60B0034 03FD072C 000002F0
	.long 0xd7040010                                           // 0000005044C0: D7040010
	v_cndmask_b32_e32 v1, v16, v49, vcc_lo                     // 0000005044C4: 02026310
	.long 0xd7034033                                           // 0000005044C8: D7034033
	v_cndmask_b32_e32 v0, v8, v129, vcc_lo                     // 0000005044CC: 02010308
	v_cmp_gt_u16_e32 vcc_lo, 24, v47                           // 0000005044D0: 7C785E98
	v_mul_i32_i24_e32 v54, -3, v44                             // 0000005044D4: 126C58C3
	s_movk_i32 s5, 0x1eee                                      // 0000005044D8: B0051EEE
	v_and_b32_e32 v55, 0x7e0, v52                              // 0000005044DC: 366E68FF 000007E0
	.long 0xd7625010                                           // 0000005044E4: D7625010
	v_cndmask_b32_e32 v1, 0xff, v51, vcc_lo                    // 0000005044E8: 020266FF 000000FF
	v_cndmask_b16 v16, v16, v51, vcc_lo                        // 0000005044F0: D65D0010 01AA6710
	v_mov_b32_e32 v9, 0                                        // 0000005044F8: 7E120280
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000005044FC: BF870214
	v_add3_u32 v61, v54, v55, 0xfffffd34                       // 000000504500: D655003D 03FE6F36 FFFFFD34
	.long 0xd43d1000                                           // 00000050450C: D43D1000
	v_cndmask_b32_e32 v1, 24, v16, vcc_lo                      // 000000504510: 02022098
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000504514: BF870214
	v_and_b32_e32 v56, 0xff, v16                               // 000000504518: 367020FF 000000FF
	v_dual_mov_b32 v46, v9 :: v_dual_and_b32 v59, 16, v0       // 000000504520: CA240109 2E3A0090
	v_mov_b32_e32 v44, v9                                      // 000000504528: 7E580309
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000050452C: BF870244
	v_cndmask_b16 v17, 0, v51, s0                              // 000000504530: D65D1011 00026680
	v_mov_b32_e32 v48, v9                                      // 000000504538: 7E600309
	v_dual_mov_b32 v45, v9 :: v_dual_lshlrev_b32 v62, 2, v56   // 00000050453C: CA220109 2D3E7082
	v_mov_b32_e32 v49, v9                                      // 000000504544: 7E620309
	v_and_b32_e32 v57, 0xff, v17                               // 000000504548: 367222FF 000000FF
	.long 0xd73c0010                                           // 000000504550: D73C0010
	v_cndmask_b32_e32 v1, 2, v8, vcc_lo                        // 000000504554: 02021082
	v_mov_b32_e32 v50, v9                                      // 000000504558: 7E640309
	v_mov_b32_e32 v47, v9                                      // 00000050455C: 7E5E0309
	v_mov_b32_e32 v51, v9                                      // 000000504560: 7E660309
	v_mov_b32_e32 v53, v9                                      // 000000504564: 7E6A0309
	v_dual_mov_b32 v52, v9 :: v_dual_lshlrev_b32 v63, 2, v57   // 000000504568: CA220109 343E7282
	v_mov_b32_e32 v54, v9                                      // 000000504570: 7E6C0309
	v_mov_b32_e32 v56, v9                                      // 000000504574: 7E700309
	v_mov_b32_e32 v57, v9                                      // 000000504578: 7E720309
	v_mov_b32_e32 v55, v9                                      // 00000050457C: 7E6E0309
	v_mov_b32_e32 v58, v9                                      // 000000504580: 7E740309
	s_mov_b32 s0, 0                                            // 000000504584: BE800080
	s_branch 916                                               // 000000504588: BFA00394 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1adc>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000050458C: 8C7E087E
	s_waitcnt vmcnt(23)                                        // 000000504590: BF895FF7
	.long 0xd73d0003                                           // 000000504594: D73D0003
	v_cndmask_b32_e32 v1, v60, v3, vcc_lo                      // 000000504598: 0202073C
	s_waitcnt vmcnt(7)                                         // 00000050459C: BF891FF7
	.long 0xd73d0004                                           // 0000005045A0: D73D0004
	v_cndmask_b32_e32 v1, v61, v5, vcc_lo                      // 0000005045A4: 02020B3D
	s_waitcnt vmcnt(6)                                         // 0000005045A8: BF891BF7
	.long 0xd73d0026                                           // 0000005045AC: D73D0026
	v_cndmask_b32_e32 v1, v61, v38, vcc_lo                     // 0000005045B0: 02024D3D
	v_lshl_or_b32 v100, v7, 5, v59                             // 0000005045B4: D6560064 04ED0B07
	.long 0xd73d0022                                           // 0000005045BC: D73D0022
	v_cndmask_b32_e32 v1, v60, v34, vcc_lo                     // 0000005045C0: 0202453C
	s_waitcnt vmcnt(5)                                         // 0000005045C4: BF8917F7
	.long 0xd73d0023                                           // 0000005045C8: D73D0023
	v_cndmask_b32_e32 v1, v61, v36, vcc_lo                     // 0000005045CC: 0202493D
	v_bfe_u32 v5, v3, 9, 16                                    // 0000005045D0: D6100005 02411303
	v_bfe_u32 v97, v4, 9, 16                                   // 0000005045D8: D6100061 02411304
	v_bfe_u32 v98, v4, 6, 16                                   // 0000005045E0: D6100062 02410D04
	v_bfe_u32 v99, v4, 3, 16                                   // 0000005045E8: D6100063 02410704
	v_and_b32_e32 v4, 0xffff, v4                               // 0000005045F0: 360808FF 0000FFFF
	v_bfe_u32 v6, v3, 6, 16                                    // 0000005045F8: D6100006 02410D03
	v_bfe_u32 v8, v3, 3, 16                                    // 000000504600: D6100008 02410703
	v_and_b32_e32 v3, 0xffff, v3                               // 000000504608: 360606FF 0000FFFF
	.long 0xd72c0063                                           // 000000504610: D72C0063
	v_cndmask_b32_e32 v1, 0x83dcd12d, v99, vcc_lo              // 000000504614: 0202C6FF 83DCD12D
	.long 0xd72c0004                                           // 00000050461C: D72C0004
	v_cndmask_b32_e32 v1, 0x83dcd12d, v4, vcc_lo               // 000000504620: 020208FF 83DCD12D
	.long 0xd72c0061                                           // 000000504628: D72C0061
	v_cndmask_b32_e32 v1, 0x83dcd12d, v97, vcc_lo              // 00000050462C: 0202C2FF 83DCD12D
	.long 0xd72c0008                                           // 000000504634: D72C0008
	v_cndmask_b32_e32 v1, 0x83dcd12d, v8, vcc_lo               // 000000504638: 020210FF 83DCD12D
	.long 0xd72c0003                                           // 000000504640: D72C0003
	v_cndmask_b32_e32 v1, 0x83dcd12d, v3, vcc_lo               // 000000504644: 020206FF 83DCD12D
	.long 0xd72c0005                                           // 00000050464C: D72C0005
	v_cndmask_b32_e32 v1, 0x83dcd12d, v5, vcc_lo               // 000000504650: 02020AFF 83DCD12D
	.long 0xd72c0062                                           // 000000504658: D72C0062
	v_cndmask_b32_e32 v1, 0x83dcd12d, v98, vcc_lo              // 00000050465C: 0202C4FF 83DCD12D
	.long 0xd72c0006                                           // 000000504664: D72C0006
	v_cndmask_b32_e32 v1, 0x83dcd12d, v6, vcc_lo               // 000000504668: 02020CFF 83DCD12D
	v_sad_u8 v99, v99, 0, 0x6400                               // 000000504670: D6220063 03FD0163 00006400
	v_sad_u8 v4, v4, 0, 0x6400                                 // 00000050467C: D6220004 03FD0104 00006400
	v_sad_u8 v97, v97, 0, 0x6400                               // 000000504688: D6220061 03FD0161 00006400
	v_sad_u8 v8, v8, 0, 0x6400                                 // 000000504694: D6220008 03FD0108 00006400
	v_sad_u8 v3, v3, 0, 0x6400                                 // 0000005046A0: D6220003 03FD0103 00006400
	v_sad_u8 v5, v5, 0, 0x6400                                 // 0000005046AC: D6220005 03FD0105 00006400
	v_lshlrev_b32_e32 v105, 16, v4                             // 0000005046B8: 30D20890
	v_and_b32_e32 v101, 0xffff, v97                            // 0000005046BC: 36CAC2FF 0000FFFF
	v_sad_u8 v104, v98, 0, 0x6400                              // 0000005046C4: D6220068 03FD0162 00006400
	.long 0xd73d0061                                           // 0000005046D0: D73D0061
	v_cndmask_b32_e32 v1, v60, v1, vcc_lo                      // 0000005046D4: 0202033C
	v_sad_u8 v6, v6, 0, 0x6400                                 // 0000005046D8: D6220006 03FD0106 00006400
	v_and_or_b32 v99, 0xffff, v99, v105                        // 0000005046E4: D6570063 05A6C6FF 0000FFFF
	v_bfe_u32 v105, v38, 6, 16                                 // 0000005046F0: D6100069 02410D26
	v_lshl_or_b32 v98, v104, 16, v101                          // 0000005046F8: D6560062 05952168
	v_bfe_u32 v104, v38, 9, 16                                 // 000000504700: D6100068 02411326
	v_bfe_u32 v106, v38, 3, 16                                 // 000000504708: D610006A 02410726
	v_pk_fma_f16 v39, v99, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000504710: CC0E0027 0BFC0B63 0000C931
	v_lshlrev_b32_e32 v3, 16, v3                               // 00000050471C: 30060690
	v_pk_fma_f16 v98, v98, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000504720: CC0E0062 0BFC0B62 0000C931
	v_bfe_u32 v37, v34, 6, 16                                  // 00000050472C: D6100025 02410D22
	.long 0xd72c0068                                           // 000000504734: D72C0068
	v_cndmask_b32_e32 v1, 0x83dcd12d, v104, vcc_lo             // 000000504738: 0202D0FF 83DCD12D
	.long 0xd72c0069                                           // 000000504740: D72C0069
	v_cndmask_b32_e32 v1, 0x83dcd12d, v105, vcc_lo             // 000000504744: 0202D2FF 83DCD12D
	v_and_or_b32 v103, 0xffff, v8, v3                          // 00000050474C: D6570067 040E10FF 0000FFFF
	.long 0xd73d001e                                           // 000000504758: D73D001E
	v_cndmask_b32_e32 v1, v60, v30, vcc_lo                     // 00000050475C: 02023D3C
	.long 0xd72c0025                                           // 000000504760: D72C0025
	v_cndmask_b32_e32 v1, 0x83dcd12d, v37, vcc_lo              // 000000504764: 02024AFF 83DCD12D
	.long 0xd73d001a                                           // 00000050476C: D73D001A
	v_cndmask_b32_e32 v1, v60, v26, vcc_lo                     // 000000504770: 0202353C
	s_waitcnt vmcnt(3)                                         // 000000504774: BF890FF7
	.long 0xd73d001b                                           // 000000504778: D73D001B
	v_cndmask_b32_e32 v1, v61, v28, vcc_lo                     // 00000050477C: 0202393D
	v_pk_fma_f16 v101, v103, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000504780: CC0E0065 0BFC0B67 0000C931
	v_and_b32_e32 v5, 0xffff, v5                               // 00000050478C: 360A0AFF 0000FFFF
	v_sad_u8 v104, v104, 0, 0x6400                             // 000000504794: D6220068 03FD0168 00006400
	.long 0xd73d0012                                           // 0000005047A0: D73D0012
	v_cndmask_b32_e32 v1, v60, v18, vcc_lo                     // 0000005047A4: 0202253C
	v_bfe_u32 v29, v26, 6, 16                                  // 0000005047A8: D610001D 02410D1A
	v_sad_u8 v37, v37, 0, 0x6400                               // 0000005047B0: D6220025 03FD0125 00006400
	v_lshl_or_b32 v102, v6, 16, v5                             // 0000005047BC: D6560066 04152106
	ds_load_b128 v[5:8], v100                                  // 0000005047C4: DBFC0000 05000064
	ds_load_b128 v[1:4], v100 offset:5120                      // 0000005047CC: DBFC1400 01000064
	.long 0xd73d0016                                           // 0000005047D4: D73D0016
	v_cndmask_b32_e32 v1, v60, v22, vcc_lo                     // 0000005047D8: 02022D3C
	.long 0xd72c001d                                           // 0000005047DC: D72C001D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v29, vcc_lo              // 0000005047E0: 02023AFF 83DCD12D
	.long 0xd73d000c                                           // 0000005047E8: D73D000C
	v_cndmask_b32_e32 v1, v60, v12, vcc_lo                     // 0000005047EC: 0202193C
	v_pk_fma_f16 v100, v102, s5, 0xc931 op_sel_hi:[1,0,0]      // 0000005047F0: CC0E0064 0BFC0B66 0000C931
	v_bfe_u32 v102, v97, 9, 16                                 // 0000005047FC: D6100066 02411361
	s_waitcnt vmcnt(1)                                         // 000000504804: BF8907F7
	.long 0xd73d0013                                           // 000000504808: D73D0013
	v_cndmask_b32_e32 v1, v61, v20, vcc_lo                     // 00000050480C: 0202293D
	v_bfe_u32 v21, v18, 6, 16                                  // 000000504810: D6100015 02410D12
	v_cmp_eq_u32_e32 vcc_lo, v96, v43                          // 000000504818: 7C945760
	.long 0xd72c0063                                           // 00000050481C: D72C0063
	v_cndmask_b32_e32 v1, 0x83dcd12d, v102, vcc_lo             // 000000504820: 0202CCFF 83DCD12D
	v_bfe_u32 v102, v97, 6, 16                                 // 000000504828: D6100066 02410D61
	v_sad_u8 v29, v29, 0, 0x6400                               // 000000504830: D622001D 03FD011D 00006400
	.long 0xd72c0015                                           // 00000050483C: D72C0015
	v_cndmask_b32_e32 v1, 0x83dcd12d, v21, vcc_lo              // 000000504840: 02022AFF 83DCD12D
	s_or_b32 s0, vcc_lo, s0                                    // 000000504848: 8C00006A
	s_delay_alu instid0(VALU_DEP_3)                            // 00000050484C: BF870003
	.long 0xd72c0066                                           // 000000504850: D72C0066
	v_cndmask_b32_e32 v1, 0x83dcd12d, v102, vcc_lo             // 000000504854: 0202CCFF 83DCD12D
	v_sad_u8 v99, v99, 0, 0x6400                               // 00000050485C: D6220063 03FD0163 00006400
	s_waitcnt lgkmcnt(1)                                       // 000000504868: BF89FC17
	v_dot2acc_f32_f16 v58, v100, v5                            // 00000050486C: 04740B64
	s_waitcnt lgkmcnt(0)                                       // 000000504870: BF89FC07
	v_dot2acc_f32_f16 v55, v100, v1                            // 000000504874: 046E0364
	v_sad_u8 v21, v21, 0, 0x6400                               // 000000504878: D6220015 03FD0115 00006400
	v_and_b32_e32 v99, 0xffff, v99                             // 000000504884: 36C6C6FF 0000FFFF
	v_sad_u8 v102, v102, 0, 0x6400                             // 00000050488C: D6220066 03FD0166 00006400
	v_dot2acc_f32_f16 v58, v101, v6                            // 000000504898: 04740D65
	v_dot2acc_f32_f16 v55, v101, v2                            // 00000050489C: 046E0565
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000005048A0: BF870193
	v_lshl_or_b32 v99, v102, 16, v99                           // 0000005048A4: D6560063 058D2166
	v_dot2acc_f32_f16 v58, v98, v7                             // 0000005048AC: 04740F62
	.long 0xd72c0066                                           // 0000005048B0: D72C0066
	v_cndmask_b32_e32 v1, 0x83dcd12d, v106, vcc_lo             // 0000005048B4: 0202D4FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 0000005048BC: BF870004
	v_dot2acc_f32_f16 v55, v98, v3                             // 0000005048C0: 046E0762
	v_bfe_u32 v98, v34, 9, 16                                  // 0000005048C4: D6100062 02411322
	v_pk_fma_f16 v99, v99, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000005048CC: CC0E0063 0BFC0B63 0000C931
	v_and_b32_e32 v38, 0xffff, v38                             // 0000005048D8: 364C4CFF 0000FFFF
	v_dot2acc_f32_f16 v58, v39, v8                             // 0000005048E0: 04741127
	v_dot2acc_f32_f16 v55, v39, v4                             // 0000005048E4: 046E0927
	v_and_b32_e32 v39, 0xffff, v34                             // 0000005048E8: 364E44FF 0000FFFF
	v_dot2acc_f32_f16 v57, v99, v5                             // 0000005048F0: 04720B63
	.long 0xd72c0026                                           // 0000005048F4: D72C0026
	v_cndmask_b32_e32 v1, 0x83dcd12d, v38, vcc_lo              // 0000005048F8: 02024CFF 83DCD12D
	v_bfe_u32 v34, v34, 3, 16                                  // 000000504900: D6100022 02410722
	v_dot2acc_f32_f16 v56, v99, v1                             // 000000504908: 04700363
	v_and_b32_e32 v103, 0xffff, v97                            // 00000050490C: 36CEC2FF 0000FFFF
	v_bfe_u32 v97, v97, 3, 16                                  // 000000504914: D6100061 02410761
	v_sad_u8 v102, v102, 0, 0x6400                             // 00000050491C: D6220066 03FD0166 00006400
	.long 0xd72c0024                                           // 000000504928: D72C0024
	v_cndmask_b32_e32 v1, 0x83dcd12d, v98, vcc_lo              // 00000050492C: 0202C4FF 83DCD12D
	v_bfe_u32 v98, v35, 6, 16                                  // 000000504934: D6100062 02410D23
	v_sad_u8 v38, v38, 0, 0x6400                               // 00000050493C: D6220026 03FD0126 00006400
	.long 0xd72c0067                                           // 000000504948: D72C0067
	v_cndmask_b32_e32 v1, 0x83dcd12d, v103, vcc_lo             // 00000050494C: 0202CEFF 83DCD12D
	.long 0xd72c0061                                           // 000000504954: D72C0061
	v_cndmask_b32_e32 v1, 0x83dcd12d, v97, vcc_lo              // 000000504958: 0202C2FF 83DCD12D
	.long 0xd72c0027                                           // 000000504960: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 000000504964: 02024EFF 83DCD12D
	.long 0xd72c0022                                           // 00000050496C: D72C0022
	v_cndmask_b32_e32 v1, 0x83dcd12d, v34, vcc_lo              // 000000504970: 020244FF 83DCD12D
	v_lshlrev_b32_e32 v38, 16, v38                             // 000000504978: 304C4C90
	.long 0xd72c0062                                           // 00000050497C: D72C0062
	v_cndmask_b32_e32 v1, 0x83dcd12d, v98, vcc_lo              // 000000504980: 0202C4FF 83DCD12D
	v_sad_u8 v36, v36, 0, 0x6400                               // 000000504988: D6220024 03FD0124 00006400
	v_sad_u8 v103, v103, 0, 0x6400                             // 000000504994: D6220067 03FD0167 00006400
	v_sad_u8 v97, v97, 0, 0x6400                               // 0000005049A0: D6220061 03FD0161 00006400
	v_and_or_b32 v38, 0xffff, v102, v38                        // 0000005049AC: D6570026 049ACCFF 0000FFFF
	v_sad_u8 v39, v39, 0, 0x6400                               // 0000005049B8: D6220027 03FD0127 00006400
	v_sad_u8 v34, v34, 0, 0x6400                               // 0000005049C4: D6220022 03FD0122 00006400
	v_and_b32_e32 v36, 0xffff, v36                             // 0000005049D0: 364848FF 0000FFFF
	v_sad_u8 v98, v98, 0, 0x6400                               // 0000005049D8: D6220062 03FD0162 00006400
	v_pk_fma_f16 v38, v38, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000005049E4: CC0E0026 0BFC0B26 0000C931
	v_lshlrev_b32_e32 v39, 16, v39                             // 0000005049F0: 304E4E90
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000005049F4: BF870114
	v_lshl_or_b32 v36, v37, 16, v36                            // 0000005049F8: D6560024 04912125
	v_and_or_b32 v34, 0xffff, v34, v39                         // 000000504A00: D6570022 049E44FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000504A0C: BF8700A1
	v_pk_fma_f16 v34, v34, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000504A10: CC0E0022 0BFC0B22 0000C931
	v_lshlrev_b32_e32 v103, 16, v103                           // 000000504A1C: 30CECE90
	v_and_or_b32 v97, 0xffff, v97, v103                        // 000000504A20: D6570061 059EC2FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000504A2C: BF870091
	v_pk_fma_f16 v97, v97, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000504A30: CC0E0061 0BFC0B61 0000C931
	v_dual_dot2acc_f32_f16 v56, v97, v2 :: v_dual_and_b32 v103, 0xffff, v104// 000000504A3C: CB240561 3866D0FF 0000FFFF
	v_sad_u8 v104, v105, 0, 0x6400                             // 000000504A48: D6220068 03FD0169 00006400
	v_dot2acc_f32_f16 v57, v97, v6                             // 000000504A54: 04720D61
	v_bfe_u32 v97, v35, 9, 16                                  // 000000504A58: D6100061 02411323
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000504A60: BF870113
	v_lshl_or_b32 v100, v104, 16, v103                         // 000000504A64: D6560064 059D2168
	.long 0xd72c0061                                           // 000000504A6C: D72C0061
	v_cndmask_b32_e32 v1, 0x83dcd12d, v97, vcc_lo              // 000000504A70: 0202C2FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000504A78: BF870112
	v_pk_fma_f16 v100, v100, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000504A7C: CC0E0064 0BFC0B64 0000C931
	v_sad_u8 v97, v97, 0, 0x6400                               // 000000504A88: D6220061 03FD0161 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000504A94: BF8701B2
	v_dot2acc_f32_f16 v56, v100, v3                            // 000000504A98: 04700764
	v_and_b32_e32 v99, 0xffff, v35                             // 000000504A9C: 36C646FF 0000FFFF
	v_bfe_u32 v35, v35, 3, 16                                  // 000000504AA4: D6100023 02410723
	v_dual_dot2acc_f32_f16 v56, v38, v4 :: v_dual_and_b32 v97, 0xffff, v97// 000000504AAC: CB240926 3860C2FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000504AB8: BF870193
	.long 0xd72c0063                                           // 000000504ABC: D72C0063
	v_cndmask_b32_e32 v1, 0x83dcd12d, v99, vcc_lo              // 000000504AC0: 0202C6FF 83DCD12D
	.long 0xd72c0023                                           // 000000504AC8: D72C0023
	v_cndmask_b32_e32 v1, 0x83dcd12d, v35, vcc_lo              // 000000504ACC: 020246FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000504AD4: BF870223
	v_lshl_or_b32 v39, v98, 16, v97                            // 000000504AD8: D6560027 05852162
	v_and_b32_e32 v97, 0xffff, v30                             // 000000504AE0: 36C23CFF 0000FFFF
	v_sad_u8 v99, v99, 0, 0x6400                               // 000000504AE8: D6220063 03FD0163 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000504AF4: BF870114
	v_sad_u8 v35, v35, 0, 0x6400                               // 000000504AF8: D6220023 03FD0123 00006400
	v_lshlrev_b32_e32 v37, 16, v99                             // 000000504B04: 304AC690
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000504B08: BF870241
	v_and_or_b32 v31, 0xffff, v35, v37                         // 000000504B0C: D657001F 049646FF 0000FFFF
	v_bfe_u32 v37, v30, 9, 16                                  // 000000504B18: D6100025 0241131E
	v_pk_fma_f16 v35, v36, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000504B20: CC0E0023 0BFC0B24 0000C931
	v_pk_fma_f16 v36, v39, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000504B2C: CC0E0024 0BFC0B27 0000C931
	v_pk_fma_f16 v39, v31, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000504B38: CC0E0027 0BFC0B1F 0000C931
	.long 0xd73d001f                                           // 000000504B44: D73D001F
	v_cndmask_b32_e32 v1, v61, v32, vcc_lo                     // 000000504B48: 0202413D
	.long 0xd72c0020                                           // 000000504B4C: D72C0020
	v_cndmask_b32_e32 v1, 0x83dcd12d, v37, vcc_lo              // 000000504B50: 02024AFF 83DCD12D
	v_bfe_u32 v33, v30, 6, 16                                  // 000000504B58: D6100021 02410D1E
	.long 0xd72c0025                                           // 000000504B60: D72C0025
	v_cndmask_b32_e32 v1, 0x83dcd12d, v97, vcc_lo              // 000000504B64: 0202C2FF 83DCD12D
	v_bfe_u32 v30, v30, 3, 16                                  // 000000504B6C: D610001E 0241071E
	v_dot2acc_f32_f16 v54, v35, v5                             // 000000504B74: 046C0B23
	v_bfe_u32 v97, v31, 9, 16                                  // 000000504B78: D6100061 0241131F
	.long 0xd72c0021                                           // 000000504B80: D72C0021
	v_cndmask_b32_e32 v1, 0x83dcd12d, v33, vcc_lo              // 000000504B84: 020242FF 83DCD12D
	v_bfe_u32 v98, v31, 6, 16                                  // 000000504B8C: D6100062 02410D1F
	v_sad_u8 v32, v32, 0, 0x6400                               // 000000504B94: D6220020 03FD0120 00006400
	v_bfe_u32 v99, v31, 3, 16                                  // 000000504BA0: D6100063 0241071F
	v_and_b32_e32 v31, 0xffff, v31                             // 000000504BA8: 363E3EFF 0000FFFF
	.long 0xd72c001e                                           // 000000504BB0: D72C001E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v30, vcc_lo              // 000000504BB4: 02023CFF 83DCD12D
	.long 0xd72c0061                                           // 000000504BBC: D72C0061
	v_cndmask_b32_e32 v1, 0x83dcd12d, v97, vcc_lo              // 000000504BC0: 0202C2FF 83DCD12D
	v_and_b32_e32 v32, 0xffff, v32                             // 000000504BC8: 364040FF 0000FFFF
	v_sad_u8 v33, v33, 0, 0x6400                               // 000000504BD0: D6220021 03FD0121 00006400
	.long 0xd72c001f                                           // 000000504BDC: D72C001F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v31, vcc_lo              // 000000504BE0: 02023EFF 83DCD12D
	v_sad_u8 v37, v37, 0, 0x6400                               // 000000504BE8: D6220025 03FD0125 00006400
	.long 0xd72c0062                                           // 000000504BF4: D72C0062
	v_cndmask_b32_e32 v1, 0x83dcd12d, v98, vcc_lo              // 000000504BF8: 0202C4FF 83DCD12D
	v_dual_dot2acc_f32_f16 v57, v100, v7 :: v_dual_dot2acc_f32_f16 v52, v35, v1// 000000504C00: CB180F64 39340323
	v_lshl_or_b32 v32, v33, 16, v32                            // 000000504C08: D6560020 04812121
	.long 0xd72c0021                                           // 000000504C10: D72C0021
	v_cndmask_b32_e32 v1, 0x83dcd12d, v99, vcc_lo              // 000000504C14: 0202C6FF 83DCD12D
	v_sad_u8 v30, v30, 0, 0x6400                               // 000000504C1C: D622001E 03FD011E 00006400
	v_sad_u8 v31, v31, 0, 0x6400                               // 000000504C28: D622001F 03FD011F 00006400
	v_lshlrev_b32_e32 v37, 16, v37                             // 000000504C34: 304A4A90
	v_sad_u8 v97, v97, 0, 0x6400                               // 000000504C38: D6220061 03FD0161 00006400
	v_pk_fma_f16 v32, v32, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000504C44: CC0E0020 0BFC0B20 0000C931
	s_delay_alu instid0(VALU_DEP_4)                            // 000000504C50: BF870004
	v_dual_dot2acc_f32_f16 v54, v34, v6 :: v_dual_lshlrev_b32 v31, 16, v31// 000000504C54: CB220D22 361E3E90
	v_sad_u8 v33, v33, 0, 0x6400                               // 000000504C5C: D6220021 03FD0121 00006400
	v_and_or_b32 v30, 0xffff, v30, v37                         // 000000504C68: D657001E 04963CFF 0000FFFF
	v_and_b32_e32 v37, 0xffff, v97                             // 000000504C74: 364AC2FF 0000FFFF
	v_sad_u8 v97, v98, 0, 0x6400                               // 000000504C7C: D6220061 03FD0162 00006400
	v_dot2acc_f32_f16 v53, v32, v5                             // 000000504C88: 046A0B20
	v_and_or_b32 v31, 0xffff, v33, v31                         // 000000504C8C: D657001F 047E42FF 0000FFFF
	v_bfe_u32 v33, v26, 9, 16                                  // 000000504C98: D6100021 0241131A
	v_pk_fma_f16 v30, v30, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000504CA0: CC0E001E 0BFC0B1E 0000C931
	v_dual_dot2acc_f32_f16 v51, v32, v1 :: v_dual_and_b32 v32, 0xffff, v26// 000000504CAC: CB240320 332034FF 0000FFFF
	v_lshl_or_b32 v35, v97, 16, v37                            // 000000504CB8: D6560023 04952161
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000504CC0: BF870224
	.long 0xd72c001c                                           // 000000504CC4: D72C001C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v33, vcc_lo              // 000000504CC8: 020242FF 83DCD12D
	v_bfe_u32 v26, v26, 3, 16                                  // 000000504CD0: D610001A 0241071A
	v_dot2acc_f32_f16 v51, v30, v2                             // 000000504CD8: 0466051E
	v_dot2acc_f32_f16 v52, v34, v2                             // 000000504CDC: 04680522
	v_pk_fma_f16 v34, v35, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000504CE0: CC0E0022 0BFC0B23 0000C931
	v_bfe_u32 v33, v27, 6, 16                                  // 000000504CEC: D6100021 02410D1B
	v_bfe_u32 v35, v27, 3, 16                                  // 000000504CF4: D6100023 0241071B
	.long 0xd72c001a                                           // 000000504CFC: D72C001A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v26, vcc_lo              // 000000504D00: 020234FF 83DCD12D
	v_sad_u8 v28, v28, 0, 0x6400                               // 000000504D08: D622001C 03FD011C 00006400
	v_dot2acc_f32_f16 v53, v30, v6                             // 000000504D14: 046A0D1E
	.long 0xd72c001e                                           // 000000504D18: D72C001E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v32, vcc_lo              // 000000504D1C: 020240FF 83DCD12D
	v_bfe_u32 v32, v27, 9, 16                                  // 000000504D24: D6100020 0241131B
	v_and_b32_e32 v27, 0xffff, v27                             // 000000504D2C: 363636FF 0000FFFF
	.long 0xd72c0021                                           // 000000504D34: D72C0021
	v_cndmask_b32_e32 v1, 0x83dcd12d, v33, vcc_lo              // 000000504D38: 020242FF 83DCD12D
	.long 0xd72c0023                                           // 000000504D40: D72C0023
	v_cndmask_b32_e32 v1, 0x83dcd12d, v35, vcc_lo              // 000000504D44: 020246FF 83DCD12D
	v_and_b32_e32 v28, 0xffff, v28                             // 000000504D4C: 363838FF 0000FFFF
	.long 0xd72c0020                                           // 000000504D54: D72C0020
	v_cndmask_b32_e32 v1, 0x83dcd12d, v32, vcc_lo              // 000000504D58: 020240FF 83DCD12D
	.long 0xd72c001b                                           // 000000504D60: D72C001B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v27, vcc_lo              // 000000504D64: 020236FF 83DCD12D
	v_sad_u8 v30, v30, 0, 0x6400                               // 000000504D6C: D622001E 03FD011E 00006400
	v_dot2acc_f32_f16 v53, v34, v7                             // 000000504D78: 046A0F22
	v_sad_u8 v26, v26, 0, 0x6400                               // 000000504D7C: D622001A 03FD011A 00006400
	v_lshl_or_b32 v28, v29, 16, v28                            // 000000504D88: D656001C 0471211D
	v_pk_fma_f16 v31, v31, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000504D90: CC0E001F 0BFC0B1F 0000C931
	v_lshlrev_b32_e32 v30, 16, v30                             // 000000504D9C: 303C3C90
	v_sad_u8 v32, v32, 0, 0x6400                               // 000000504DA0: D6220020 03FD0120 00006400
	v_sad_u8 v27, v27, 0, 0x6400                               // 000000504DAC: D622001B 03FD011B 00006400
	v_pk_fma_f16 v28, v28, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000504DB8: CC0E001C 0BFC0B1C 0000C931
	v_dot2acc_f32_f16 v53, v31, v8                             // 000000504DC4: 046A111F
	v_and_or_b32 v26, 0xffff, v26, v30                         // 000000504DC8: D657001A 047A34FF 0000FFFF
	v_and_b32_e32 v29, 0xffff, v32                             // 000000504DD4: 363A40FF 0000FFFF
	v_sad_u8 v30, v33, 0, 0x6400                               // 000000504DDC: D622001E 03FD0121 00006400
	v_sad_u8 v32, v35, 0, 0x6400                               // 000000504DE8: D6220020 03FD0123 00006400
	v_lshlrev_b32_e32 v27, 16, v27                             // 000000504DF4: 30363690
	v_pk_fma_f16 v26, v26, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000504DF8: CC0E001A 0BFC0B1A 0000C931
	v_dot2acc_f32_f16 v47, v28, v5                             // 000000504E04: 045E0B1C
	v_lshl_or_b32 v23, v30, 16, v29                            // 000000504E08: D6560017 0475211E
	v_bfe_u32 v29, v22, 9, 16                                  // 000000504E10: D610001D 02411316
	v_and_or_b32 v27, 0xffff, v32, v27                         // 000000504E18: D657001B 046E40FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000504E24: BF870214
	v_dual_dot2acc_f32_f16 v50, v28, v1 :: v_dual_dot2acc_f32_f16 v47, v26, v6// 000000504E28: CB18031C 322E0D1A
	v_pk_fma_f16 v30, v23, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000504E30: CC0E001E 0BFC0B17 0000C931
	.long 0xd73d0017                                           // 000000504E3C: D73D0017
	v_cndmask_b32_e32 v1, v61, v24, vcc_lo                     // 000000504E40: 0202313D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000504E44: BF870004
	v_pk_fma_f16 v24, v27, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000504E48: CC0E0018 0BFC0B1B 0000C931
	.long 0xd72c0019                                           // 000000504E54: D72C0019
	v_cndmask_b32_e32 v1, 0x83dcd12d, v29, vcc_lo              // 000000504E58: 02023AFF 83DCD12D
	v_bfe_u32 v27, v22, 6, 16                                  // 000000504E60: D610001B 02410D16
	v_dot2acc_f32_f16 v50, v26, v2                             // 000000504E68: 0464051A
	v_dot2acc_f32_f16 v47, v30, v7                             // 000000504E6C: 045E0F1E
	v_bfe_u32 v32, v23, 6, 16                                  // 000000504E70: D6100020 02410D17
	v_bfe_u32 v33, v23, 3, 16                                  // 000000504E78: D6100021 02410717
	.long 0xd72c001b                                           // 000000504E80: D72C001B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v27, vcc_lo              // 000000504E84: 020236FF 83DCD12D
	v_dot2acc_f32_f16 v50, v30, v3                             // 000000504E8C: 0464071E
	v_sad_u8 v25, v25, 0, 0x6400                               // 000000504E90: D6220019 03FD0119 00006400
	v_dot2acc_f32_f16 v47, v24, v8                             // 000000504E9C: 045E1118
	.long 0xd72c0020                                           // 000000504EA0: D72C0020
	v_cndmask_b32_e32 v1, 0x83dcd12d, v32, vcc_lo              // 000000504EA4: 020240FF 83DCD12D
	v_dual_dot2acc_f32_f16 v57, v38, v8 :: v_dual_dot2acc_f32_f16 v54, v36, v7// 000000504EAC: CB181126 39360F24
	s_delay_alu instid0(VALU_DEP_4)                            // 000000504EB4: BF870004
	v_and_b32_e32 v25, 0xffff, v25                             // 000000504EB8: 363232FF 0000FFFF
	v_sad_u8 v27, v27, 0, 0x6400                               // 000000504EC0: D622001B 03FD011B 00006400
	v_dot2acc_f32_f16 v50, v24, v4                             // 000000504ECC: 04640918
	v_bfe_u32 v24, v19, 9, 16                                  // 000000504ED0: D6100018 02411313
	v_dot2acc_f32_f16 v52, v36, v3                             // 000000504ED8: 04680724
	v_dot2acc_f32_f16 v54, v39, v8                             // 000000504EDC: 046C1127
	v_lshl_or_b32 v25, v27, 16, v25                            // 000000504EE0: D6560019 0465211B
	.long 0xd72c001b                                           // 000000504EE8: D72C001B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v33, vcc_lo              // 000000504EEC: 020242FF 83DCD12D
	.long 0xd72c0018                                           // 000000504EF4: D72C0018
	v_cndmask_b32_e32 v1, 0x83dcd12d, v24, vcc_lo              // 000000504EF8: 020230FF 83DCD12D
	v_dual_dot2acc_f32_f16 v52, v39, v4 :: v_dual_mov_b32 v33, v85// 000000504F00: CB100927 34200155
	s_delay_alu instid0(VALU_DEP_4)                            // 000000504F08: BF870004
	v_pk_fma_f16 v25, v25, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000504F0C: CC0E0019 0BFC0B19 0000C931
	v_mov_b32_e32 v37, v88                                     // 000000504F18: 7E4A0358
	v_mov_b32_e32 v35, v69                                     // 000000504F1C: 7E460345
	v_mov_b32_e32 v39, v90                                     // 000000504F20: 7E4E035A
	v_sad_u8 v27, v27, 0, 0x6400                               // 000000504F24: D622001B 03FD011B 00006400
	v_dot2acc_f32_f16 v49, v25, v5                             // 000000504F30: 04620B19
	v_dot2acc_f32_f16 v48, v25, v1                             // 000000504F34: 04600319
	v_bfe_u32 v25, v18, 9, 16                                  // 000000504F38: D6100019 02411312
	v_sad_u8 v24, v24, 0, 0x6400                               // 000000504F40: D6220018 03FD0118 00006400
	v_mov_b32_e32 v30, v78                                     // 000000504F4C: 7E3C034E
	v_mov_b32_e32 v36, v93                                     // 000000504F50: 7E48035D
	v_mov_b32_e32 v38, v94                                     // 000000504F54: 7E4C035E
	.long 0xd72c0014                                           // 000000504F58: D72C0014
	v_cndmask_b32_e32 v1, 0x83dcd12d, v25, vcc_lo              // 000000504F5C: 020232FF 83DCD12D
	v_and_b32_e32 v24, 0xffff, v24                             // 000000504F64: 363030FF 0000FFFF
	v_bfe_u32 v25, v19, 6, 16                                  // 000000504F6C: D6100019 02410D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000504F74: BF870211
	.long 0xd72c0019                                           // 000000504F78: D72C0019
	v_cndmask_b32_e32 v1, 0x83dcd12d, v25, vcc_lo              // 000000504F7C: 020232FF 83DCD12D
	v_sad_u8 v20, v20, 0, 0x6400                               // 000000504F84: D6220014 03FD0114 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000504F90: BF870191
	v_dual_dot2acc_f32_f16 v51, v34, v3 :: v_dual_and_b32 v20, 0xffff, v20// 000000504F94: CB240722 331428FF 0000FFFF
	v_sad_u8 v25, v25, 0, 0x6400                               // 000000504FA0: D6220019 03FD0119 00006400
	v_mov_b32_e32 v34, v81                                     // 000000504FAC: 7E440351
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000504FB0: BF870213
	v_lshl_or_b32 v20, v21, 16, v20                            // 000000504FB4: D6560014 04512115
	v_dot2acc_f32_f16 v51, v31, v4                             // 000000504FBC: 0466091F
	v_and_b32_e32 v31, 0xffff, v22                             // 000000504FC0: 363E2CFF 0000FFFF
	v_bfe_u32 v22, v22, 3, 16                                  // 000000504FC8: D6100016 02410716
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000504FD0: BF8701A2
	.long 0xd72c001d                                           // 000000504FD4: D72C001D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v31, vcc_lo              // 000000504FD8: 02023EFF 83DCD12D
	v_bfe_u32 v31, v23, 9, 16                                  // 000000504FE0: D610001F 02411317
	.long 0xd72c0016                                           // 000000504FE8: D72C0016
	v_cndmask_b32_e32 v1, 0x83dcd12d, v22, vcc_lo              // 000000504FEC: 02022CFF 83DCD12D
	v_and_b32_e32 v23, 0xffff, v23                             // 000000504FF4: 362E2EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000504FFC: BF8701A3
	.long 0xd72c001f                                           // 000000505000: D72C001F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v31, vcc_lo              // 000000505004: 02023EFF 83DCD12D
	v_sad_u8 v29, v29, 0, 0x6400                               // 00000050500C: D622001D 03FD011D 00006400
	.long 0xd72c0017                                           // 000000505018: D72C0017
	v_cndmask_b32_e32 v1, 0x83dcd12d, v23, vcc_lo              // 00000050501C: 02022EFF 83DCD12D
	v_sad_u8 v22, v22, 0, 0x6400                               // 000000505024: D6220016 03FD0116 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000505030: BF870223
	v_lshlrev_b32_e32 v29, 16, v29                             // 000000505034: 303A3A90
	v_sad_u8 v31, v31, 0, 0x6400                               // 000000505038: D622001F 03FD011F 00006400
	v_sad_u8 v23, v23, 0, 0x6400                               // 000000505044: D6220017 03FD0117 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000505050: BF870113
	v_and_or_b32 v22, 0xffff, v22, v29                         // 000000505054: D6570016 04762CFF 0000FFFF
	v_lshlrev_b32_e32 v23, 16, v23                             // 000000505060: 302E2E90
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000505064: BF870112
	v_pk_fma_f16 v22, v22, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000505068: CC0E0016 0BFC0B16 0000C931
	v_and_or_b32 v23, 0xffff, v27, v23                         // 000000505074: D6570017 045E36FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2)                            // 000000505080: BF870002
	v_dot2acc_f32_f16 v49, v22, v6                             // 000000505084: 04620D16
	v_dot2acc_f32_f16 v48, v22, v2                             // 000000505088: 04600516
	v_and_b32_e32 v22, 0xffff, v18                             // 00000050508C: 362C24FF 0000FFFF
	v_and_b32_e32 v27, 0xffff, v19                             // 000000505094: 363626FF 0000FFFF
	v_bfe_u32 v18, v18, 3, 16                                  // 00000050509C: D6100012 02410712
	v_bfe_u32 v19, v19, 3, 16                                  // 0000005050A4: D6100013 02410713
	v_pk_fma_f16 v23, v23, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000005050AC: CC0E0017 0BFC0B17 0000C931
	.long 0xd72c0016                                           // 0000005050B8: D72C0016
	v_cndmask_b32_e32 v1, 0x83dcd12d, v22, vcc_lo              // 0000005050BC: 02022CFF 83DCD12D
	.long 0xd72c001b                                           // 0000005050C4: D72C001B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v27, vcc_lo              // 0000005050C8: 020236FF 83DCD12D
	.long 0xd72c0012                                           // 0000005050D0: D72C0012
	v_cndmask_b32_e32 v1, 0x83dcd12d, v18, vcc_lo              // 0000005050D4: 020224FF 83DCD12D
	.long 0xd72c0013                                           // 0000005050DC: D72C0013
	v_cndmask_b32_e32 v1, 0x83dcd12d, v19, vcc_lo              // 0000005050E0: 020226FF 83DCD12D
	v_and_b32_e32 v29, 0xffff, v31                             // 0000005050E8: 363A3EFF 0000FFFF
	v_sad_u8 v31, v32, 0, 0x6400                               // 0000005050F0: D622001F 03FD0120 00006400
	v_mov_b32_e32 v32, v91                                     // 0000005050FC: 7E40035B
	v_sad_u8 v22, v22, 0, 0x6400                               // 000000505100: D6220016 03FD0116 00006400
	v_sad_u8 v27, v27, 0, 0x6400                               // 00000050510C: D622001B 03FD011B 00006400
	v_sad_u8 v18, v18, 0, 0x6400                               // 000000505118: D6220012 03FD0112 00006400
	v_sad_u8 v19, v19, 0, 0x6400                               // 000000505124: D6220013 03FD0113 00006400
	v_lshl_or_b32 v28, v31, 16, v29                            // 000000505130: D656001C 0475211F
	v_lshlrev_b32_e32 v22, 16, v22                             // 000000505138: 302C2C90
	v_lshlrev_b32_e32 v21, 16, v27                             // 00000050513C: 302A3690
	v_mov_b32_e32 v29, v82                                     // 000000505140: 7E3A0352
	v_mov_b32_e32 v27, v67                                     // 000000505144: 7E360343
	v_pk_fma_f16 v26, v28, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000505148: CC0E001A 0BFC0B1C 0000C931
	v_and_or_b32 v18, 0xffff, v18, v22                         // 000000505154: D6570012 045A24FF 0000FFFF
	v_lshl_or_b32 v22, v25, 16, v24                            // 000000505160: D6560016 04612119
	v_and_or_b32 v13, 0xffff, v19, v21                         // 000000505168: D657000D 045626FF 0000FFFF
	v_bfe_u32 v21, v12, 9, 16                                  // 000000505174: D6100015 0241130C
	v_pk_fma_f16 v19, v20, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000050517C: CC0E0013 0BFC0B14 0000C931
	v_and_b32_e32 v24, 0xffff, v12                             // 000000505188: 363018FF 0000FFFF
	v_pk_fma_f16 v20, v22, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000505190: CC0E0014 0BFC0B16 0000C931
	v_pk_fma_f16 v22, v13, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000050519C: CC0E0016 0BFC0B0D 0000C931
	s_waitcnt vmcnt(0)                                         // 0000005051A8: BF8903F7
	.long 0xd73d000d                                           // 0000005051AC: D73D000D
	v_cndmask_b32_e32 v1, v61, v14, vcc_lo                     // 0000005051B0: 02021D3D
	.long 0xd72c000e                                           // 0000005051B4: D72C000E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v21, vcc_lo              // 0000005051B8: 02022AFF 83DCD12D
	v_bfe_u32 v15, v12, 6, 16                                  // 0000005051C0: D610000F 02410D0C
	v_bfe_u32 v12, v12, 3, 16                                  // 0000005051C8: D610000C 0241070C
	.long 0xd72c0015                                           // 0000005051D0: D72C0015
	v_cndmask_b32_e32 v1, 0x83dcd12d, v24, vcc_lo              // 0000005051D4: 020230FF 83DCD12D
	v_dot2acc_f32_f16 v49, v26, v7                             // 0000005051DC: 04620F1A
	v_bfe_u32 v24, v13, 9, 16                                  // 0000005051E0: D6100018 0241130D
	.long 0xd72c000f                                           // 0000005051E8: D72C000F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v15, vcc_lo              // 0000005051EC: 02021EFF 83DCD12D
	.long 0xd72c000c                                           // 0000005051F4: D72C000C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v12, vcc_lo              // 0000005051F8: 020218FF 83DCD12D
	v_sad_u8 v14, v14, 0, 0x6400                               // 000000505200: D622000E 03FD010E 00006400
	v_dot2acc_f32_f16 v48, v26, v3                             // 00000050520C: 0460071A
	v_bfe_u32 v25, v13, 6, 16                                  // 000000505210: D6100019 02410D0D
	v_sad_u8 v21, v21, 0, 0x6400                               // 000000505218: D6220015 03FD0115 00006400
	v_bfe_u32 v26, v13, 3, 16                                  // 000000505224: D610001A 0241070D
	v_and_b32_e32 v14, 0xffff, v14                             // 00000050522C: 361C1CFF 0000FFFF
	v_sad_u8 v15, v15, 0, 0x6400                               // 000000505234: D622000F 03FD010F 00006400
	.long 0xd72c0018                                           // 000000505240: D72C0018
	v_cndmask_b32_e32 v1, 0x83dcd12d, v24, vcc_lo              // 000000505244: 020230FF 83DCD12D
	v_and_b32_e32 v13, 0xffff, v13                             // 00000050524C: 361A1AFF 0000FFFF
	v_sad_u8 v12, v12, 0, 0x6400                               // 000000505254: D622000C 03FD010C 00006400
	v_lshlrev_b32_e32 v21, 16, v21                             // 000000505260: 302A2A90
	v_lshl_or_b32 v14, v15, 16, v14                            // 000000505264: D656000E 0439210F
	.long 0xd72c0019                                           // 00000050526C: D72C0019
	v_cndmask_b32_e32 v1, 0x83dcd12d, v25, vcc_lo              // 000000505270: 020232FF 83DCD12D
	.long 0xd72c000d                                           // 000000505278: D72C000D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v13, vcc_lo              // 00000050527C: 02021AFF 83DCD12D
	.long 0xd72c000f                                           // 000000505284: D72C000F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v26, vcc_lo              // 000000505288: 020234FF 83DCD12D
	v_sad_u8 v24, v24, 0, 0x6400                               // 000000505290: D6220018 03FD0118 00006400
	v_and_or_b32 v12, 0xffff, v12, v21                         // 00000050529C: D657000C 045618FF 0000FFFF
	v_pk_fma_f16 v14, v14, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000005052A8: CC0E000E 0BFC0B0E 0000C931
	v_pk_fma_f16 v18, v18, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000005052B4: CC0E0012 0BFC0B12 0000C931
	s_delay_alu instid0(VALU_DEP_4)                            // 0000005052C0: BF870004
	v_dual_dot2acc_f32_f16 v46, v19, v5 :: v_dual_and_b32 v21, 0xffff, v24// 0000005052C4: CB240B13 2E1430FF 0000FFFF
	v_sad_u8 v24, v25, 0, 0x6400                               // 0000005052D0: D6220018 03FD0119 00006400
	v_dot2acc_f32_f16 v45, v19, v1                             // 0000005052DC: 045A0313
	v_sad_u8 v13, v13, 0, 0x6400                               // 0000005052E0: D622000D 03FD010D 00006400
	v_pk_fma_f16 v12, v12, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000005052EC: CC0E000C 0BFC0B0C 0000C931
	v_dot2acc_f32_f16 v44, v14, v5                             // 0000005052F8: 04580B0E
	v_dot2acc_f32_f16 v46, v18, v6                             // 0000005052FC: 045C0D12
	v_sad_u8 v15, v15, 0, 0x6400                               // 000000505300: D622000F 03FD010F 00006400
	v_lshlrev_b32_e32 v13, 16, v13                             // 00000050530C: 301A1A90
	v_dot2acc_f32_f16 v9, v14, v1                              // 000000505310: 0412030E
	v_dot2acc_f32_f16 v45, v18, v2                             // 000000505314: 045A0512
	v_dot2acc_f32_f16 v44, v12, v6                             // 000000505318: 04580D0C
	v_mov_b32_e32 v6, v92                                      // 00000050531C: 7E0C035C
	v_lshl_or_b32 v19, v24, 16, v21                            // 000000505320: D6560013 04552118
	v_and_or_b32 v5, 0xffff, v15, v13                          // 000000505328: D6570005 04361EFF 0000FFFF
	v_dot2acc_f32_f16 v46, v20, v7                             // 000000505334: 045C0F14
	v_dual_dot2acc_f32_f16 v45, v20, v3 :: v_dual_mov_b32 v20, v83// 000000505338: CB100714 2D140153
	s_delay_alu instid0(VALU_DEP_4)                            // 000000505340: BF870004
	v_pk_fma_f16 v1, v19, s5, 0xc931 op_sel_hi:[1,0,0]         // 000000505344: CC0E0001 0BFC0B13 0000C931
	v_dot2acc_f32_f16 v9, v12, v2                              // 000000505350: 0412050C
	v_pk_fma_f16 v2, v5, s5, 0xc931 op_sel_hi:[1,0,0]          // 000000505354: CC0E0002 0BFC0B05 0000C931
	v_dot2acc_f32_f16 v49, v23, v8                             // 000000505360: 04621117
	v_dot2acc_f32_f16 v48, v23, v4                             // 000000505364: 04600917
	v_dot2acc_f32_f16 v44, v1, v7                              // 000000505368: 04580F01
	v_dual_dot2acc_f32_f16 v9, v1, v3 :: v_dual_mov_b32 v14, v80// 00000050536C: CB100701 090E0150
	v_dot2acc_f32_f16 v46, v22, v8                             // 000000505374: 045C1116
	v_dot2acc_f32_f16 v45, v22, v4                             // 000000505378: 045A0916
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000050537C: BF870214
	v_dot2acc_f32_f16 v44, v2, v8                              // 000000505380: 04581102
	v_dot2acc_f32_f16 v9, v2, v4                               // 000000505384: 04120902
	v_dual_mov_b32 v24, v86 :: v_dual_mov_b32 v25, v79         // 000000505388: CA100156 1818014F
	v_mov_b32_e32 v22, v74                                     // 000000505390: 7E2C034A
	v_dual_mov_b32 v23, v66 :: v_dual_mov_b32 v28, v89         // 000000505394: CA100142 171C0159
	v_mov_b32_e32 v26, v76                                     // 00000050539C: 7E34034C
	v_mov_b32_e32 v31, v68                                     // 0000005053A0: 7E3E0344
	v_dual_mov_b32 v1, v84 :: v_dual_mov_b32 v2, v70           // 0000005053A4: CA100154 01020146
	v_mov_b32_e32 v5, v95                                      // 0000005053AC: 7E0A035F
	v_mov_b32_e32 v3, v87                                      // 0000005053B0: 7E060357
	v_dual_mov_b32 v4, v71 :: v_dual_mov_b32 v19, v65          // 0000005053B4: CA100147 04120141
	v_mov_b32_e32 v18, v73                                     // 0000005053BC: 7E240349
	v_mov_b32_e32 v21, v77                                     // 0000005053C0: 7E2A034D
	v_mov_b32_e32 v13, v64                                     // 0000005053C4: 7E1A0340
	v_dual_mov_b32 v12, v72 :: v_dual_mov_b32 v15, v75         // 0000005053C8: CA100148 0C0E014B
	v_mov_b32_e32 v7, v96                                      // 0000005053D0: 7E0E0360
	s_and_not1_b32 exec_lo, exec_lo, s0                        // 0000005053D4: 917E007E
	s_cbranch_execz 94                                         // 0000005053D8: BFA5005E <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1c54>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005053DC: BF8700A1
	v_add_nc_u32_e32 v96, 1, v7                                // 0000005053E0: 4AC00E81
	s_mov_b32 s8, exec_lo                                      // 0000005053E4: BE88007E
	.long 0xd4c1007e                                           // 0000005053E8: D4C1007E
	v_cndmask_b32_e32 v1, v96, v43, vcc_lo                     // 0000005053EC: 02025760
	s_cbranch_execz 64614                                      // 0000005053F0: BFA5FC66 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xc8c>
	v_mad_i64_i32 v[64:65], null, 0x300, v96, s[6:7]           // 0000005053F4: D6FF7C40 001AC0FF 00000300
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000505400: BF870091
	.long 0xd7006a48                                           // 000000505404: D7006A48
	v_cndmask_b32_e32 v1, v64, v10, vcc_lo                     // 000000505408: 02021540
	v_add_co_ci_u32_e64 v73, null, v65, v11, vcc_lo            // 00000050540C: D5207C49 01AA1741
	.long 0xd7006a4f                                           // 000000505414: D7006A4F
	v_cndmask_b32_e32 v1, v64, v62, vcc_lo                     // 000000505418: 02027D40
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000050541C: BF8700A1
	v_add_co_ci_u32_e64 v80, null, 0, v65, vcc_lo              // 000000505420: D5207C50 01AA8280
	.long 0xd7006a5d                                           // 000000505428: D7006A5D
	v_cndmask_b32_e32 v1, v64, v16, vcc_lo                     // 00000050542C: 02022140
	v_add_co_ci_u32_e64 v94, null, v65, v17, vcc_lo            // 000000505430: D5207C5E 01AA2341
	.long 0xd7006a61                                           // 000000505438: D7006A61
	v_cndmask_b32_e32 v1, v64, v63, vcc_lo                     // 00000050543C: 02027F40
	s_delay_alu instid0(VALU_DEP_1)                            // 000000505440: BF870001
	v_add_co_ci_u32_e64 v98, null, 0, v65, vcc_lo              // 000000505444: D5207C62 01AA8280
	s_clause 0x1f                                              // 00000050544C: BF85001F
	global_load_b32 v71, v[72:73], off                         // 000000505450: DC520000 477C0048
	global_load_b32 v70, v[72:73], off offset:96               // 000000505458: DC520060 467C0048
	global_load_b32 v69, v[72:73], off offset:192              // 000000505460: DC5200C0 457C0048
	global_load_b32 v68, v[72:73], off offset:288              // 000000505468: DC520120 447C0048
	global_load_b32 v67, v[72:73], off offset:384              // 000000505470: DC520180 437C0048
	global_load_b32 v66, v[72:73], off offset:480              // 000000505478: DC5201E0 427C0048
	global_load_b32 v65, v[72:73], off offset:576              // 000000505480: DC520240 417C0048
	global_load_b32 v64, v[72:73], off offset:672              // 000000505488: DC5202A0 407C0048
	global_load_b32 v87, v[79:80], off                         // 000000505490: DC520000 577C004F
	global_load_b32 v84, v[79:80], off offset:96               // 000000505498: DC520060 547C004F
	global_load_b32 v81, v[79:80], off offset:192              // 0000005054A0: DC5200C0 517C004F
	global_load_b32 v78, v[79:80], off offset:288              // 0000005054A8: DC520120 4E7C004F
	global_load_b32 v76, v[79:80], off offset:384              // 0000005054B0: DC520180 4C7C004F
	global_load_b32 v74, v[79:80], off offset:480              // 0000005054B8: DC5201E0 4A7C004F
	global_load_b32 v73, v[79:80], off offset:576              // 0000005054C0: DC520240 497C004F
	global_load_b32 v72, v[79:80], off offset:672              // 0000005054C8: DC5202A0 487C004F
	global_load_b32 v92, v[93:94], off                         // 0000005054D0: DC520000 5C7C005D
	global_load_b32 v90, v[93:94], off offset:96               // 0000005054D8: DC520060 5A7C005D
	global_load_b32 v88, v[93:94], off offset:192              // 0000005054E0: DC5200C0 587C005D
	global_load_b32 v85, v[93:94], off offset:288              // 0000005054E8: DC520120 557C005D
	global_load_b32 v82, v[93:94], off offset:384              // 0000005054F0: DC520180 527C005D
	global_load_b32 v79, v[93:94], off offset:480              // 0000005054F8: DC5201E0 4F7C005D
	global_load_b32 v77, v[93:94], off offset:576              // 000000505500: DC520240 4D7C005D
	global_load_b32 v75, v[93:94], off offset:672              // 000000505508: DC5202A0 4B7C005D
	global_load_b32 v95, v[97:98], off                         // 000000505510: DC520000 5F7C0061
	global_load_b32 v94, v[97:98], off offset:96               // 000000505518: DC520060 5E7C0061
	global_load_b32 v93, v[97:98], off offset:192              // 000000505520: DC5200C0 5D7C0061
	global_load_b32 v91, v[97:98], off offset:288              // 000000505528: DC520120 5B7C0061
	global_load_b32 v89, v[97:98], off offset:384              // 000000505530: DC520180 597C0061
	global_load_b32 v86, v[97:98], off offset:480              // 000000505538: DC5201E0 567C0061
	global_load_b32 v83, v[97:98], off offset:576              // 000000505540: DC520240 537C0061
	global_load_b32 v80, v[97:98], off offset:672              // 000000505548: DC5202A0 507C0061
	s_branch 64526                                             // 000000505550: BFA0FC0E <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xc8c>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000505554: 8C7E007E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000505558: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 00000050555C: 8C7E017E
	s_waitcnt vmcnt(22)                                        // 000000505560: BF895BF7
	v_dual_mov_b32 v1, v58 :: v_dual_mov_b32 v2, v55           // 000000505564: CA10013A 01020137
	s_waitcnt vmcnt(15)                                        // 00000050556C: BF893FF7
	v_dual_mov_b32 v3, v57 :: v_dual_mov_b32 v6, v56           // 000000505570: CA100139 03060138
	s_waitcnt vmcnt(7)                                         // 000000505578: BF891FF7
	v_dual_mov_b32 v4, v54 :: v_dual_mov_b32 v5, v52           // 00000050557C: CA100136 04040134
	v_dual_mov_b32 v8, v53 :: v_dual_mov_b32 v7, v47           // 000000505584: CA100135 0806012F
	v_dual_mov_b32 v10, v51 :: v_dual_mov_b32 v11, v50         // 00000050558C: CA100133 0A0A0132
	v_dual_mov_b32 v12, v49 :: v_dual_mov_b32 v13, v48         // 000000505594: CA100131 0C0C0130
	s_waitcnt vmcnt(0)                                         // 00000050559C: BF8903F7
	v_dual_mov_b32 v14, v46 :: v_dual_mov_b32 v15, v45         // 0000005055A0: CA10012E 0E0E012D
	v_dual_mov_b32 v16, v44 :: v_dual_mov_b32 v17, v9          // 0000005055A8: CA10012C 10100109
	s_mov_b32 s0, 0x76543210                                   // 0000005055B0: BE8000FF 76543210
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000005055B8: BF870009
	v_permlanex16_b32 v1, v1, s0, 0xfedcba98                   // 0000005055BC: D65C0001 03FC0101 FEDCBA98
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 0000005055C8: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 0000005055D4: D65C0003 03FC0103 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 0000005055E0: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 0000005055EC: D65C0004 03FC0104 FEDCBA98
	v_permlanex16_b32 v5, v5, s0, 0xfedcba98                   // 0000005055F8: D65C0005 03FC0105 FEDCBA98
	v_permlanex16_b32 v8, v8, s0, 0xfedcba98                   // 000000505604: D65C0008 03FC0108 FEDCBA98
	v_permlanex16_b32 v10, v10, s0, 0xfedcba98                 // 000000505610: D65C000A 03FC010A FEDCBA98
	v_permlanex16_b32 v7, v7, s0, 0xfedcba98                   // 00000050561C: D65C0007 03FC0107 FEDCBA98
	v_permlanex16_b32 v11, v11, s0, 0xfedcba98                 // 000000505628: D65C000B 03FC010B FEDCBA98
	v_permlanex16_b32 v12, v12, s0, 0xfedcba98                 // 000000505634: D65C000C 03FC010C FEDCBA98
	v_permlanex16_b32 v13, v13, s0, 0xfedcba98                 // 000000505640: D65C000D 03FC010D FEDCBA98
	v_permlanex16_b32 v14, v14, s0, 0xfedcba98                 // 00000050564C: D65C000E 03FC010E FEDCBA98
	v_permlanex16_b32 v15, v15, s0, 0xfedcba98                 // 000000505658: D65C000F 03FC010F FEDCBA98
	v_permlanex16_b32 v16, v16, s0, 0xfedcba98                 // 000000505664: D65C0010 03FC0110 FEDCBA98
	v_permlanex16_b32 v17, v17, s0, 0xfedcba98                 // 000000505670: D65C0011 03FC0111 FEDCBA98
	.long 0xd44c0000                                           // 00000050567C: D44C0000
	v_cndmask_b32_e32 v1, 16, v42, vcc_lo                      // 000000505680: 02025490
	s_barrier                                                  // 000000505684: BFBD0000
	buffer_gl0_inv                                             // 000000505688: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 000000505690: BE812000
	s_cbranch_execz 34                                         // 000000505694: BFA50022 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1e20>
	v_dual_add_f32 v9, v9, v17 :: v_dual_add_f32 v16, v44, v16 // 000000505698: C9082309 0910212C
	v_dual_add_f32 v8, v53, v8 :: v_dual_add_f32 v1, v58, v1   // 0000005056A0: C9081135 0800033A
	v_dual_add_f32 v6, v56, v6 :: v_dual_add_f32 v3, v57, v3   // 0000005056A8: C9080D38 06020739
	v_lshl_or_b32 v17, v40, 10, v41                            // 0000005056B0: D6560011 04A51528
	v_dual_add_f32 v2, v55, v2 :: v_dual_add_f32 v5, v52, v5   // 0000005056B8: C9080537 02040B34
	v_dual_add_f32 v4, v54, v4 :: v_dual_add_f32 v7, v47, v7   // 0000005056C0: C9080936 04060F2F
	v_dual_add_f32 v11, v50, v11 :: v_dual_add_f32 v10, v51, v10// 0000005056C8: C9081732 0B0A1533
	v_dual_add_f32 v13, v48, v13 :: v_dual_add_f32 v12, v49, v12// 0000005056D0: C9081B30 0D0C1931
	v_dual_add_f32 v15, v45, v15 :: v_dual_add_f32 v14, v46, v14// 0000005056D8: C9081F2D 0F0E1D2E
	ds_store_2addr_b32 v17, v1, v3 offset1:16                  // 0000005056E0: D8381000 00030111
	ds_store_2addr_b32 v17, v2, v6 offset0:128 offset1:144     // 0000005056E8: D8389080 00060211
	ds_store_2addr_b32 v17, v4, v8 offset0:32 offset1:48       // 0000005056F0: D8383020 00080411
	ds_store_2addr_b32 v17, v5, v10 offset0:160 offset1:176    // 0000005056F8: D838B0A0 000A0511
	ds_store_2addr_b32 v17, v7, v12 offset0:64 offset1:80      // 000000505700: D8385040 000C0711
	ds_store_2addr_b32 v17, v11, v13 offset0:192 offset1:208   // 000000505708: D838D0C0 000D0B11
	ds_store_2addr_b32 v17, v14, v16 offset0:96 offset1:112    // 000000505710: D8387060 00100E11
	ds_store_2addr_b32 v17, v15, v9 offset0:224 offset1:240    // 000000505718: D838F0E0 00090F11
	s_or_b32 exec_lo, exec_lo, s1                              // 000000505720: 8C7E017E
	.long 0xd44c0001                                           // 000000505724: D44C0001
	v_cndmask_b32_e32 v1, 0x100, v0, vcc_lo                    // 000000505728: 020200FF 00000100
	s_waitcnt lgkmcnt(0)                                       // 000000505730: BF89FC07
	s_barrier                                                  // 000000505734: BFBD0000
	buffer_gl0_inv                                             // 000000505738: E0AC0000 00000000
	s_and_saveexec_b32 s5, s1                                  // 000000505740: BE852001
	s_cbranch_execnz 9                                         // 000000505744: BFA60009 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1e6c>
	s_or_b32 exec_lo, exec_lo, s5                              // 000000505748: 8C7E057E
	s_cmp_lt_i32 s27, 2                                        // 00000050574C: BF04821B
	s_mov_b32 s5, -1                                           // 000000505750: BE8500C1
	s_cbranch_scc0 35                                          // 000000505754: BFA10023 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1ee4>
	s_and_b32 vcc_lo, exec_lo, s5                              // 000000505758: 8B6A057E
	s_cbranch_vccnz 204                                        // 00000050575C: BFA400CC <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2190>
	s_nop 0                                                    // 000000505760: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000505764: BFB60003
	s_endpgm                                                   // 000000505768: BFB00000
	v_lshlrev_b32_e32 v7, 2, v0                                // 00000050576C: 300E0082
	ds_load_2addr_stride64_b32 v[1:2], v7 offset1:4            // 000000505770: D8E00400 01000007
	ds_load_2addr_stride64_b32 v[3:4], v7 offset0:8 offset1:12 // 000000505778: D8E00C08 03000007
	ds_load_2addr_stride64_b32 v[5:6], v7 offset0:16 offset1:20// 000000505780: D8E01410 05000007
	s_waitcnt lgkmcnt(2)                                       // 000000505788: BF89FC27
	v_add_f32_e32 v1, 0, v1                                    // 00000050578C: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000505790: BF8700A1
	v_add_f32_e32 v1, v1, v2                                   // 000000505794: 06020501
	s_waitcnt lgkmcnt(1)                                       // 000000505798: BF89FC17
	v_add_f32_e32 v3, v1, v3                                   // 00000050579C: 06060701
	ds_load_2addr_stride64_b32 v[1:2], v7 offset0:24 offset1:28// 0000005057A0: D8E01C18 01000007
	v_add_f32_e32 v3, v3, v4                                   // 0000005057A8: 06060903
	s_waitcnt lgkmcnt(1)                                       // 0000005057AC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005057B0: BF870091
	v_add_f32_e32 v3, v3, v5                                   // 0000005057B4: 06060B03
	v_add_f32_e32 v3, v3, v6                                   // 0000005057B8: 06060D03
	s_waitcnt lgkmcnt(0)                                       // 0000005057BC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005057C0: BF870091
	v_add_f32_e32 v1, v3, v1                                   // 0000005057C4: 06020303
	v_add_f32_e32 v1, v1, v2                                   // 0000005057C8: 06020501
	ds_store_b32 v7, v1 offset:8192                            // 0000005057CC: D8342000 00000107
	s_or_b32 exec_lo, exec_lo, s5                              // 0000005057D4: 8C7E057E
	s_cmp_lt_i32 s27, 2                                        // 0000005057D8: BF04821B
	s_mov_b32 s5, -1                                           // 0000005057DC: BE8500C1
	s_cbranch_scc1 65501                                       // 0000005057E0: BFA2FFDD <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1e58>
	s_waitcnt lgkmcnt(0)                                       // 0000005057E4: BF89FC07
	s_barrier                                                  // 0000005057E8: BFBD0000
	buffer_gl0_inv                                             // 0000005057EC: E0AC0000 00000000
	s_and_saveexec_b32 s5, s1                                  // 0000005057F4: BE852001
	s_cbranch_execz 41                                         // 0000005057F8: BFA50029 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1fa0>
	v_lshrrev_b32_e32 v1, 7, v0                                // 0000005057FC: 32020087
	s_ashr_i32 s6, s26, 31                                     // 000000505800: 86069F1A
	v_lshlrev_b32_e32 v4, 2, v0                                // 000000505804: 30080082
	s_delay_alu instid0(VALU_DEP_2)                            // 000000505808: BF870002
	v_lshl_or_b32 v1, s4, 1, v1                                // 00000050580C: D6560001 04050204
	s_ashr_i32 s4, s4, 31                                      // 000000505814: 86049F04
	ds_load_b32 v4, v4 offset:8192                             // 000000505818: D8D82000 04000004
	s_mul_i32 s4, s4, s26                                      // 000000505820: 96041A04
	.long 0xd72c0003                                           // 000000505824: D72C0003
	v_cndmask_b32_e32 v0, v1, v6, vcc_lo                       // 000000505828: 02000D01
	v_mad_u64_u32 v[1:2], null, v1, s26, 0                     // 00000050582C: D6FE7C01 02003501
	s_lshl_b32 s6, s2, 7                                       // 000000505834: 84068702
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000505838: BF870499
	s_ashr_i32 s7, s6, 31                                      // 00000050583C: 86079F06
	s_lshl_b64 s[6:7], s[6:7], 2                               // 000000505840: 84868206
	v_add3_u32 v2, v2, v3, s4                                  // 000000505844: D6550002 00120702
	v_and_b32_e32 v3, 0x7f, v0                                 // 00000050584C: 360600FF 0000007F
	s_add_u32 s4, s16, s6                                      // 000000505854: 80040610
	s_addc_u32 s6, s17, s7                                     // 000000505858: 82060711
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000050585C: BF870112
	.long 0xd73c0001                                           // 000000505860: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000505864: 02020282
	v_lshlrev_b32_e32 v3, 2, v3                                // 000000505868: 30060682
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000050586C: BF870092
	.long 0xd7006a01                                           // 000000505870: D7006A01
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 000000505874: 02020204
	v_add_co_ci_u32_e64 v2, null, s6, v2, vcc_lo               // 000000505878: D5207C02 01AA0406
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000505880: BF870092
	.long 0xd7006a01                                           // 000000505884: D7006A01
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 000000505888: 02020701
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 00000050588C: D5207C02 01AA0480
	s_waitcnt lgkmcnt(0)                                       // 000000505894: BF89FC07
	global_store_b32 v[1:2], v4, off                           // 000000505898: DC6A0000 007C0401
	s_or_b32 exec_lo, exec_lo, s5                              // 0000005058A0: 8C7E057E
	.long 0xd44a0004                                           // 0000005058A4: D44A0004
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 0000005058A8: 02020080
	s_waitcnt_vscnt null, 0x0                                  // 0000005058AC: BC7C0000
	buffer_gl1_inv                                             // 0000005058B0: E0B00000 00000000
	buffer_gl0_inv                                             // 0000005058B8: E0AC0000 00000000
	s_barrier                                                  // 0000005058C0: BFBD0000
	buffer_gl0_inv                                             // 0000005058C4: E0AC0000 00000000
	s_and_saveexec_b32 s5, s4                                  // 0000005058CC: BE852004
	s_cbranch_execz 29                                         // 0000005058D0: BFA5001D <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2048>
	s_mov_b32 s7, exec_lo                                      // 0000005058D4: BE87007E
	s_mov_b32 s6, exec_lo                                      // 0000005058D8: BE86007E
	.long 0xd71f0001                                           // 0000005058DC: D71F0001
	v_cndmask_b32_e32 v0, s7, v128, vcc_lo                     // 0000005058E0: 02010007
	s_delay_alu instid0(VALU_DEP_1)                            // 0000005058E4: BF870001
	v_cmpx_eq_u32_e32 0, v1                                    // 0000005058E8: 7D940280
	s_cbranch_execz 9                                          // 0000005058EC: BFA50009 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2014>
	s_lshl_b64 s[8:9], s[2:3], 2                               // 0000005058F0: 84888202
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000005058F4: BF8704B9
	s_add_u32 s8, s18, s8                                      // 0000005058F8: 80080812
	s_addc_u32 s9, s19, s9                                     // 0000005058FC: 82090913
	s_bcnt1_i32_b32 s7, s7                                     // 000000505900: BE871807
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, s7              // 000000505904: CA100080 02020007
	global_atomic_add_u32 v2, v2, v3, s[8:9] glc               // 00000050590C: DCD64000 02080302
	s_or_b32 exec_lo, exec_lo, s6                              // 000000505914: 8C7E067E
	s_waitcnt vmcnt(0)                                         // 000000505918: BF8903F7
	v_readfirstlane_b32 s6, v2                                 // 00000050591C: 7E0C0502
	s_delay_alu instid0(VALU_DEP_1)                            // 000000505920: BF870001
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s6, v1       // 000000505924: CA200080 02000206
	s_add_i32 s6, s27, -1                                      // 00000050592C: 8106C11B
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000505930: BF870481
	v_cmp_eq_u32_e32 vcc_lo, s6, v1                            // 000000505934: 7C940206
	v_cndmask_b32_e64 v1, 0, 1, vcc_lo                         // 000000505938: D5010001 01A90280
	ds_store_b32 v2, v1 offset:10240                           // 000000505940: D8342800 00000102
	s_or_b32 exec_lo, exec_lo, s5                              // 000000505948: 8C7E057E
	v_mov_b32_e32 v1, 0                                        // 00000050594C: 7E020280
	s_waitcnt lgkmcnt(0)                                       // 000000505950: BF89FC07
	s_barrier                                                  // 000000505954: BFBD0000
	buffer_gl0_inv                                             // 000000505958: E0AC0000 00000000
	ds_load_b32 v1, v1 offset:10240                            // 000000505960: D8D82800 01000001
	s_waitcnt lgkmcnt(0)                                       // 000000505968: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 00000050596C: 7C940280
	s_cbranch_vccnz 70                                         // 000000505970: BFA40046 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x218c>
	buffer_gl1_inv                                             // 000000505974: E0B00000 00000000
	buffer_gl0_inv                                             // 00000050597C: E0AC0000 00000000
	s_and_saveexec_b32 s5, s1                                  // 000000505984: BE852001
	s_cbranch_execz 52                                         // 000000505988: BFA50034 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x215c>
	v_and_b32_e32 v2, 0x7f, v0                                 // 00000050598C: 360400FF 0000007F
	s_lshl_b32 s6, s2, 7                                       // 000000505994: 84068702
	s_ashr_i32 s1, s26, 31                                     // 000000505998: 86019F1A
	s_ashr_i32 s7, s6, 31                                      // 00000050599C: 86079F06
	v_lshrrev_b32_e32 v1, 7, v0                                // 0000005059A0: 32020087
	v_dual_mov_b32 v2, 0 :: v_dual_lshlrev_b32 v3, 2, v2       // 0000005059A4: CA220080 02020482
	s_lshl_b64 s[6:7], s[6:7], 2                               // 0000005059AC: 84868206
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005059B0: BF8700A9
	s_add_u32 s6, s16, s6                                      // 0000005059B4: 80060610
	s_addc_u32 s7, s17, s7                                     // 0000005059B8: 82070711
	.long 0xd7000603                                           // 0000005059BC: D7000603
	v_cndmask_b32_e32 v1, s6, v3, vcc_lo                       // 0000005059C0: 02020606
	s_delay_alu instid0(VALU_DEP_1)                            // 0000005059C4: BF870001
	v_add_co_ci_u32_e64 v4, null, s7, 0, s6                    // 0000005059C8: D5207C04 00190007
	s_nop 0                                                    // 0000005059D0: BF800000
	s_nop 0                                                    // 0000005059D4: BF800000
	s_nop 0                                                    // 0000005059D8: BF800000
	s_nop 0                                                    // 0000005059DC: BF800000
	s_nop 0                                                    // 0000005059E0: BF800000
	s_nop 0                                                    // 0000005059E4: BF800000
	s_nop 0                                                    // 0000005059E8: BF800000
	s_nop 0                                                    // 0000005059EC: BF800000
	s_nop 0                                                    // 0000005059F0: BF800000
	s_nop 0                                                    // 0000005059F4: BF800000
	s_nop 0                                                    // 0000005059F8: BF800000
	s_nop 0                                                    // 0000005059FC: BF800000
	v_mad_u64_u32 v[5:6], null, v1, s26, 0                     // 000000505A00: D6FE7C05 02003501
	s_add_i32 s27, s27, -1                                     // 000000505A08: 811BC11B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000505A0C: BF870139
	s_cmp_eq_u32 s27, 0                                        // 000000505A10: BF06801B
	v_mad_u64_u32 v[6:7], null, v1, s1, v[6:7]                 // 000000505A14: D6FE7C06 04180301
	v_add_nc_u32_e32 v1, 2, v1                                 // 000000505A1C: 4A020282
	.long 0xd73c0005                                           // 000000505A20: D73C0005
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 000000505A24: 02020A82
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000505A28: BF870091
	.long 0xd7006a05                                           // 000000505A2C: D7006A05
	v_cndmask_b32_e32 v1, v3, v5, vcc_lo                       // 000000505A30: 02020B03
	v_add_co_ci_u32_e64 v6, null, v4, v6, vcc_lo               // 000000505A34: D5207C06 01AA0D04
	global_load_b32 v5, v[5:6], off glc                        // 000000505A3C: DC524000 057C0005
	s_waitcnt vmcnt(0)                                         // 000000505A44: BF8903F7
	v_add_f32_e32 v2, v2, v5                                   // 000000505A48: 06040B02
	s_cbranch_scc0 65516                                       // 000000505A4C: BFA1FFEC <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2100>
	v_lshlrev_b32_e32 v1, 2, v0                                // 000000505A50: 30020082
	ds_store_b32 v1, v2 offset:8192                            // 000000505A54: D8342000 00000201
	s_or_b32 exec_lo, exec_lo, s5                              // 000000505A5C: 8C7E057E
	s_and_saveexec_b32 s1, s4                                  // 000000505A60: BE812004
	s_cbranch_execz 6                                          // 000000505A64: BFA50006 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2180>
	s_lshl_b64 s[4:5], s[2:3], 2                               // 000000505A68: 84848202
	v_mov_b32_e32 v1, 0                                        // 000000505A6C: 7E020280
	s_add_u32 s4, s18, s4                                      // 000000505A70: 80040412
	s_addc_u32 s5, s19, s5                                     // 000000505A74: 82050513
	global_store_b32 v1, v1, s[4:5]                            // 000000505A78: DC6A0000 00040101
	s_or_b32 exec_lo, exec_lo, s1                              // 000000505A80: 8C7E017E
	s_cbranch_execz 65334                                      // 000000505A84: BFA5FF36 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1e60>
	s_branch 1                                                 // 000000505A88: BFA00001 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2190>
	s_branch 65332                                             // 000000505A8C: BFA0FF34 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1e60>
	v_cmp_gt_i32_e32 vcc_lo, s24, v40                          // 000000505A90: 7C885018
	.long 0xd44c0001                                           // 000000505A94: D44C0001
	v_cndmask_b32_e32 v1, 64, v0, vcc_lo                       // 000000505A98: 020200C0
	s_waitcnt lgkmcnt(0)                                       // 000000505A9C: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 000000505AA0: BC7C0000
	s_barrier                                                  // 000000505AA4: BFBD0000
	buffer_gl0_inv                                             // 000000505AA8: E0AC0000 00000000
	s_and_b32 s1, vcc_lo, s1                                   // 000000505AB0: 8B01016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000505AB4: BF870009
	s_and_saveexec_b32 s3, s1                                  // 000000505AB8: BE832001
	s_cbranch_execz 65320                                      // 000000505ABC: BFA5FF28 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1e60>
	v_and_b32_e32 v1, 15, v0                                   // 000000505AC0: 3602008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000505AC4: BF870091
	v_lshlrev_b32_e32 v2, 2, v1                                // 000000505AC8: 30040282
	v_lshl_or_b32 v2, v40, 9, v2                               // 000000505ACC: D6560002 04091328
	s_delay_alu instid0(VALU_DEP_1)                            // 000000505AD4: BF870001
	v_add_nc_u32_e32 v8, 0x2000, v2                            // 000000505AD8: 4A1004FF 00002000
	ds_load_2addr_b32 v[2:3], v8 offset1:16                    // 000000505AE0: D8DC1000 02000008
	ds_load_2addr_b32 v[4:5], v8 offset0:32 offset1:48         // 000000505AE8: D8DC3020 04000008
	ds_load_2addr_b32 v[6:7], v8 offset0:64 offset1:80         // 000000505AF0: D8DC5040 06000008
	ds_load_2addr_b32 v[8:9], v8 offset0:96 offset1:112        // 000000505AF8: D8DC7060 08000008
	v_and_b32_e32 v10, 1, v0                                   // 000000505B00: 36140081
	s_waitcnt lgkmcnt(3)                                       // 000000505B04: BF89FC37
	v_dual_add_f32 v12, v2, v3 :: v_dual_and_b32 v11, 2, v0    // 000000505B08: C9240702 0C0A0082
	s_waitcnt lgkmcnt(2)                                       // 000000505B10: BF89FC27
	v_dual_sub_f32 v2, v2, v3 :: v_dual_add_f32 v3, v4, v5     // 000000505B14: C9480702 02020B04
	s_waitcnt lgkmcnt(1)                                       // 000000505B1C: BF89FC17
	v_dual_sub_f32 v4, v4, v5 :: v_dual_add_f32 v5, v6, v7     // 000000505B20: C9480B04 04040F06
	s_waitcnt lgkmcnt(0)                                       // 000000505B28: BF89FC07
	v_dual_sub_f32 v6, v6, v7 :: v_dual_sub_f32 v7, v8, v9     // 000000505B2C: C94A0F06 06061308
	v_dual_add_f32 v8, v8, v9 :: v_dual_and_b32 v9, 4, v0      // 000000505B34: C9241308 08080084
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000505B3C: BF8701A3
	v_add_f32_e32 v13, v2, v4                                  // 000000505B40: 061A0902
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 000000505B44: 7C941480
	v_add_f32_e32 v16, v5, v8                                  // 000000505B48: 06201105
	v_dual_sub_f32 v5, v5, v8 :: v_dual_add_f32 v14, v12, v3   // 000000505B4C: C9481105 050E070C
	v_add_f32_e32 v15, v6, v7                                  // 000000505B54: 061E0F06
	v_dual_sub_f32 v3, v12, v3 :: v_dual_sub_f32 v2, v2, v4    // 000000505B58: C94A070C 03020902
	v_sub_f32_e32 v4, v6, v7                                   // 000000505B60: 08080F06
	.long 0xd44a0001                                           // 000000505B64: D44A0001
	v_cndmask_b32_e32 v1, 0, v9, vcc_lo                        // 000000505B68: 02021280
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000505B6C: BF870214
	v_add_f32_e32 v6, v13, v15                                 // 000000505B70: 060C1F0D
	v_dual_sub_f32 v8, v13, v15 :: v_dual_add_f32 v13, v3, v5  // 000000505B74: C9481F0D 080C0B03
	v_add_f32_e32 v7, v14, v16                                 // 000000505B7C: 060E210E
	v_dual_sub_f32 v3, v3, v5 :: v_dual_add_f32 v12, v2, v4    // 000000505B80: C9480B03 030C0902
	v_sub_f32_e32 v2, v2, v4                                   // 000000505B88: 08040902
	v_mov_b32_dpp v5, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000505B8C: 7E0A02FA FF016106
	s_delay_alu instid0(VALU_DEP_4)                            // 000000505B94: BF870004
	v_mov_b32_dpp v4, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000505B98: 7E0802FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000505BA0: D5010007 21AA0F07
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 000000505BA8: D5010006 21AA0D06
	v_mov_b32_dpp v18, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000505BB0: 7E2402FA FF016103
	v_cndmask_b32_e64 v21, -v3, v3, vcc_lo                     // 000000505BB8: D5010015 21AA0703
	v_mov_b32_dpp v19, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000505BC0: 7E2602FA FF016102
	v_add_f32_e32 v3, v7, v4                                   // 000000505BC8: 06060907
	v_mov_b32_dpp v15, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000505BCC: 7E1E02FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000505BD4: D5010008 21AA1108
	v_cndmask_b32_e64 v20, -v2, v2, vcc_lo                     // 000000505BDC: D5010014 21AA0502
	v_add_f32_e32 v2, v6, v5                                   // 000000505BE4: 06040B06
	v_mov_b32_dpp v6, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000505BE8: 7E0C02FA FF016203
	v_sub_f32_e32 v10, v14, v16                                // 000000505BF0: 0814210E
	v_mov_b32_dpp v16, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000505BF4: 7E2002FA FF01610D
	v_mov_b32_dpp v17, v12 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000505BFC: 7E2202FA FF01610C
	v_cndmask_b32_e64 v12, -v12, v12, vcc_lo                   // 000000505C04: D501000C 21AA190C
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 000000505C0C: D501000D 21AA1B0D
	v_mov_b32_dpp v14, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000505C14: 7E1C02FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 000000505C1C: D501000A 21AA150A
	v_cmp_eq_u32_e32 vcc_lo, 0, v11                            // 000000505C24: 7C941680
	v_add_f32_e32 v4, v8, v15                                  // 000000505C28: 06081F08
	v_dual_add_f32 v7, v12, v17 :: v_dual_add_f32 v8, v13, v16 // 000000505C2C: C908230C 0708210D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000505C34: BF870224
	v_add_f32_e32 v5, v10, v14                                 // 000000505C38: 060A1D0A
	v_add_f32_e32 v13, v20, v19                                // 000000505C3C: 061A2714
	v_mov_b32_dpp v12, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000505C40: 7E1802FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000505C48: D5010004 21AA0904
	v_mov_b32_dpp v10, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000505C50: 7E1402FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 000000505C58: D5010002 21AA0502
	v_mov_b32_dpp v9, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000505C60: 7E1202FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000505C68: D5010008 21AA1108
	v_add_f32_e32 v4, v4, v12                                  // 000000505C70: 06081904
	v_mov_b32_dpp v11, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000505C74: 7E1602FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000505C7C: D5010005 21AA0B05
	v_mov_b32_dpp v15, v13 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000505C84: 7E1E02FA FF01620D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 000000505C8C: D501000D 21AA1B0D
	v_mov_b32_dpp v12, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000505C94: 7E1802FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000505C9C: D5010004 20060904
	v_dual_add_f32 v8, v8, v9 :: v_dual_add_f32 v11, v5, v11   // 000000505CA4: C9081308 080A1705
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000505CAC: D5010003 21AA0703
	v_mov_b32_dpp v14, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000505CB4: 7E1C02FA FF016207
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000505CBC: BF8701C4
	v_add_f32_e32 v4, v4, v12                                  // 000000505CC0: 06081904
	v_add_f32_e32 v12, v21, v18                                // 000000505CC4: 06182515
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000505CC8: D5010007 21AA0F07
	v_add_f32_e32 v3, v3, v6                                   // 000000505CD0: 06060D03
	v_mov_b32_dpp v9, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000505CD4: 7E1202FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, vcc_lo                   // 000000505CDC: D501000C 21AA190C
	v_add_f32_e32 v2, v2, v10                                  // 000000505CE4: 06041502
	v_add_f32_e32 v14, v7, v14                                 // 000000505CE8: 061C1D07
	v_mov_b32_dpp v6, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000505CEC: 7E0C02FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 000000505CF4: D5010003 20060703
	v_add_f32_e32 v9, v12, v9                                  // 000000505CFC: 0612130C
	v_cndmask_b32_e64 v10, -v2, v2, s1                         // 000000505D00: D501000A 20060502
	v_mov_b32_dpp v2, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000505D08: 7E0402FA FF016402
	v_mov_b32_dpp v12, v14 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000505D10: 7E1802FA FF01640E
	v_add_f32_e32 v3, v3, v6                                   // 000000505D18: 06060D03
	v_mov_b32_dpp v16, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000505D1C: 7E2002FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 000000505D24: D5010009 20061309
	v_add_f32_e32 v5, v10, v2                                  // 000000505D2C: 060A050A
	v_mov_b32_dpp v10, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000505D30: 7E1402FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 000000505D38: D501000B 2006170B
	v_mov_b32_dpp v2, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000505D40: 7E0402FA FF016803
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000505D48: BF870194
	v_mov_b32_dpp v6, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000505D4C: 7E0C02FA FF016805
	v_add_f32_e32 v7, v11, v10                                 // 000000505D54: 060E150B
	v_add_f32_e32 v11, v13, v15                                // 000000505D58: 06161F0D
	v_mov_b32_dpp v10, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000505D5C: 7E1402FA FF016408
	v_cndmask_b32_e64 v13, -v14, v14, s1                       // 000000505D64: D501000D 20061D0E
	v_cndmask_b32_e64 v14, -v8, v8, s1                         // 000000505D6C: D501000E 20061108
	v_mov_b32_dpp v8, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000505D74: 7E1002FA FF016807
	v_mov_b32_dpp v18, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000505D7C: 7E2402FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 000000505D84: D501000B 2006170B
	v_add_f32_e32 v17, v13, v12                                // 000000505D8C: 0622190D
	v_dual_add_f32 v15, v14, v10 :: v_dual_add_f32 v14, v9, v16// 000000505D90: C908150E 0F0E2109
	v_mov_b32_dpp v9, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000505D98: 7E1202FA FF016804
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000505DA0: BF870214
	v_add_f32_e32 v16, v11, v18                                // 000000505DA4: 0620250B
	v_mov_b32_dpp v13, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000505DA8: 7E1A02FA FF016811
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000505DB0: BF870224
	v_mov_b32_dpp v11, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000505DB4: 7E1602FA FF01680F
	v_mov_b32_dpp v10, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000505DBC: 7E1402FA FF01680E
	v_mov_b32_dpp v12, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000505DC4: 7E1802FA FF016810
	s_and_b32 exec_lo, exec_lo, s0                             // 000000505DCC: 8B7E007E
	s_cbranch_execz 65123                                      // 000000505DD0: BFA5FE63 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1e60>
	v_lshl_or_b32 v18, s2, 7, v1                               // 000000505DD4: D6560012 04050E02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000505DDC: BF870091
	v_ashrrev_i32_e32 v19, 31, v18                             // 000000505DE0: 3426249F
	.long 0xd73c0014                                           // 000000505DE4: D73C0014
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 000000505DE8: 02022481
	.long 0xd73c0012                                           // 000000505DEC: D73C0012
	v_cndmask_b32_e32 v1, 2, v18, vcc_lo                       // 000000505DF0: 02022482
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000505DF4: BF870092
	.long 0xd7006a14                                           // 000000505DF8: D7006A14
	v_cndmask_b32_e32 v1, s14, v20, vcc_lo                     // 000000505DFC: 0202280E
	v_add_co_ci_u32_e64 v21, null, s15, v21, vcc_lo            // 000000505E00: D5207C15 01AA2A0F
	s_clause 0x7                                               // 000000505E08: BF850007
	global_load_d16_b16 v22, v[20:21], off offset:32           // 000000505E0C: DC820020 167C0014
	global_load_d16_b16 v23, v[20:21], off                     // 000000505E14: DC820000 177C0014
	global_load_d16_b16 v24, v[20:21], off offset:96           // 000000505E1C: DC820060 187C0014
	global_load_d16_b16 v25, v[20:21], off offset:64           // 000000505E24: DC820040 197C0014
	global_load_d16_b16 v26, v[20:21], off offset:160          // 000000505E2C: DC8200A0 1A7C0014
	global_load_d16_b16 v27, v[20:21], off offset:128          // 000000505E34: DC820080 1B7C0014
	global_load_d16_b16 v28, v[20:21], off offset:224          // 000000505E3C: DC8200E0 1C7C0014
	global_load_d16_b16 v20, v[20:21], off offset:192          // 000000505E44: DC8200C0 147C0014
	v_and_b32_e32 v21, 8, v0                                   // 000000505E4C: 362A0088
	v_mad_i64_i32 v[0:1], null, s26, v40, 0                    // 000000505E50: D6FF7C00 0202501A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000505E58: BF870112
	v_cmp_eq_u32_e32 vcc_lo, 0, v21                            // 000000505E5C: 7C942A80
	.long 0xd73c0000                                           // 000000505E60: D73C0000
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 000000505E64: 02020082
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000505E68: D5010005 21AA0B05
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000505E70: D5010003 21AA0703
	v_cndmask_b32_e64 v15, -v15, v15, vcc_lo                   // 000000505E78: D501000F 21AA1F0F
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000505E80: D5010004 21AA0904
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000505E88: D5010007 21AA0F07
	v_add_f32_e32 v5, v5, v6                                   // 000000505E90: 060A0D05
	v_cndmask_b32_e64 v6, -v17, v17, vcc_lo                    // 000000505E94: D5010006 21AA2311
	v_cndmask_b32_e64 v16, -v16, v16, vcc_lo                   // 000000505E9C: D5010010 21AA2110
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 000000505EA4: D501000E 21AA1D0E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000505EAC: BF870214
	v_dual_add_f32 v2, v3, v2 :: v_dual_mul_f32 v3, 0x3db504f3, v5// 000000505EB0: C9060503 02020AFF 3DB504F3
	v_dual_add_f32 v5, v6, v13 :: v_dual_add_f32 v6, v15, v11  // 000000505EBC: C9081B06 0506170F
	.long 0xd7006a00                                           // 000000505EC4: D7006A00
	v_cndmask_b32_e32 v1, s20, v0, vcc_lo                      // 000000505EC8: 02020014
	v_dual_add_f32 v4, v4, v9 :: v_dual_add_f32 v7, v7, v8     // 000000505ECC: C9081304 04061107
	v_add_co_ci_u32_e64 v1, null, s21, v1, vcc_lo              // 000000505ED4: D5207C01 01AA0215
	v_dual_add_f32 v8, v16, v12 :: v_dual_add_f32 v9, v14, v10 // 000000505EDC: C9081910 0808150E
	s_delay_alu instid0(VALU_DEP_3)                            // 000000505EE4: BF870003
	v_mul_f32_e32 v4, 0x3db504f3, v4                           // 000000505EE8: 100808FF 3DB504F3
	v_mul_f32_e32 v2, 0x3db504f3, v2                           // 000000505EF0: 100404FF 3DB504F3
	v_dual_mul_f32 v6, 0x3db504f3, v6 :: v_dual_mul_f32 v5, 0x3db504f3, v5// 000000505EF8: C8C60CFF 06040AFF 3DB504F3
	.long 0xd7006a00                                           // 000000505F04: D7006A00
	v_cndmask_b32_e32 v1, v0, v18, vcc_lo                      // 000000505F08: 02022500
	v_dual_mul_f32 v7, 0x3db504f3, v7 :: v_dual_mul_f32 v8, 0x3db504f3, v8// 000000505F0C: C8C60EFF 070810FF 3DB504F3
	v_add_co_ci_u32_e64 v1, null, v1, v19, vcc_lo              // 000000505F18: D5207C01 01AA2701
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 000000505F20: 101212FF 3DB504F3
	s_waitcnt vmcnt(7)                                         // 000000505F28: BF891FF7
	v_fma_mix_f32 v3, v22, v3, neg(0) op_sel_hi:[1,0,0]        // 000000505F2C: CC200003 8A020716
	s_waitcnt vmcnt(6)                                         // 000000505F34: BF891BF7
	v_fma_mix_f32 v2, v23, v2, neg(0) op_sel_hi:[1,0,0]        // 000000505F38: CC200002 8A020517
	s_waitcnt vmcnt(5)                                         // 000000505F40: BF8917F7
	v_fma_mix_f32 v5, v24, v5, neg(0) op_sel_hi:[1,0,0]        // 000000505F44: CC200005 8A020B18
	s_waitcnt vmcnt(4)                                         // 000000505F4C: BF8913F7
	v_fma_mix_f32 v6, v25, v6, neg(0) op_sel_hi:[1,0,0]        // 000000505F50: CC200006 8A020D19
	s_waitcnt vmcnt(3)                                         // 000000505F58: BF890FF7
	v_fma_mix_f32 v4, v26, v4, neg(0) op_sel_hi:[1,0,0]        // 000000505F5C: CC200004 8A02091A
	s_waitcnt vmcnt(2)                                         // 000000505F64: BF890BF7
	v_fma_mix_f32 v7, v27, v7, neg(0) op_sel_hi:[1,0,0]        // 000000505F68: CC200007 8A020F1B
	s_waitcnt vmcnt(1)                                         // 000000505F70: BF8907F7
	v_fma_mix_f32 v8, v28, v8, neg(0) op_sel_hi:[1,0,0]        // 000000505F74: CC200008 8A02111C
	s_waitcnt vmcnt(0)                                         // 000000505F7C: BF8903F7
	v_fma_mix_f32 v9, v20, v9, neg(0) op_sel_hi:[1,0,0]        // 000000505F80: CC200009 8A021314
	s_clause 0x7                                               // 000000505F88: BF850007
	global_store_b32 v[0:1], v2, off                           // 000000505F8C: DC6A0000 007C0200
	global_store_b32 v[0:1], v3, off offset:64                 // 000000505F94: DC6A0040 007C0300
	global_store_b32 v[0:1], v6, off offset:128                // 000000505F9C: DC6A0080 007C0600
	global_store_b32 v[0:1], v5, off offset:192                // 000000505FA4: DC6A00C0 007C0500
	global_store_b32 v[0:1], v7, off offset:256                // 000000505FAC: DC6A0100 007C0700
	global_store_b32 v[0:1], v4, off offset:320                // 000000505FB4: DC6A0140 007C0400
	global_store_b32 v[0:1], v9, off offset:384                // 000000505FBC: DC6A0180 007C0900
	global_store_b32 v[0:1], v8, off offset:448                // 000000505FC4: DC6A01C0 007C0800
	s_nop 0                                                    // 000000505FCC: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000505FD0: BFB60003
	s_endpgm                                                   // 000000505FD4: BFB00000
		...

