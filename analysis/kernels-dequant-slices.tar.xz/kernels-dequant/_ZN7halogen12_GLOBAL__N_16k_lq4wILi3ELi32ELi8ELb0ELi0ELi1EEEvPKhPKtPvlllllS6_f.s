0000000000552e00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000552E00: F4100100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 000000552E08: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 000000552E0C: 32040082
	v_lshrrev_b32_e32 v22, 5, v0                               // 000000552E10: 322C0085
	v_and_b32_e32 v23, 31, v0                                  // 000000552E14: 362E009F
	.long 0x7f0a3880                                           // 000000552E18: 7F0A3880
	v_lshlrev_b32_e32 v21, 2, v0                               // 000000552E1C: 302A0082
	s_waitcnt lgkmcnt(0)                                       // 000000552E20: BF89FC07
	.long 0xd4510000                                           // 000000552E24: D4510000
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 000000552E28: 02001802
	s_and_b32 s0, s0, exec_lo                                  // 000000552E2C: 8B007E00
	s_cselect_b32 s20, s3, 0                                   // 000000552E30: 98148003
	s_cselect_b32 s21, s2, 0                                   // 000000552E34: 98158002
	s_add_u32 s0, s4, s16                                      // 000000552E38: 80001004
	s_addc_u32 s1, s5, s17                                     // 000000552E3C: 82011105
	v_and_b32_e32 v1, 15, v0                                   // 000000552E40: 3602008F
	v_and_b32_e32 v2, 60, v2                                   // 000000552E44: 360404BC
	s_ashr_i32 s16, s11, 31                                    // 000000552E48: 86109F0B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000552E4C: BF870119
	s_lshr_b32 s16, s16, 27                                    // 000000552E50: 85109B10
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000552E54: 30020282
	s_add_u32 s16, s10, s16                                    // 000000552E58: 8010100A
	s_clause 0x1                                               // 000000552E5C: BF850001
	global_load_b32 v3, v1, s[4:5]                             // 000000552E60: DC520000 03040001
	global_load_b32 v4, v2, s[4:5]                             // 000000552E68: DC520000 04040002
	s_addc_u32 s17, s11, 0                                     // 000000552E70: 8211800B
	v_mov_b32_e32 v2, s1                                       // 000000552E74: 7E040201
	s_lshr_b64 s[16:17], s[16:17], 5                           // 000000552E78: 85908510
	v_mov_b32_e32 v1, s0                                       // 000000552E7C: 7E020200
	s_add_i32 s17, s16, 7                                      // 000000552E80: 81118710
	s_mul_i32 s1, s19, s21                                     // 000000552E84: 96011513
	s_ashr_i32 s22, s17, 31                                    // 000000552E88: 86169F11
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000552E8C: BF8704B9
	s_lshr_b32 s0, s22, 29                                     // 000000552E90: 85009D16
	v_mad_u64_u32 v[17:18], null, s18, s21, v[1:2]             // 000000552E94: D6FE7C11 04042A12
	s_add_i32 s17, s17, s0                                     // 000000552E9C: 81110011
	s_ashr_i32 s0, s17, 3                                      // 000000552EA0: 86008311
	s_cmpk_lt_i32 s16, 0x801                                   // 000000552EA4: B3900801
	.long 0xd72c0001                                           // 000000552EA8: D72C0001
	v_cndmask_b32_e32 v1, s0, v22, vcc_lo                      // 000000552EAC: 02022C00
	s_mul_i32 s17, s18, s20                                    // 000000552EB0: 96111412
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000552EB4: BF870141
	v_add_nc_u32_e32 v7, s0, v1                                // 000000552EB8: 4A0E0200
	v_add_nc_u32_e32 v24, v1, v23                              // 000000552EBC: 4A302F01
	s_cselect_b32 s0, -1, 0                                    // 000000552EC0: 980080C1
	s_cmpk_gt_i32 s16, 0x800                                   // 000000552EC4: B2900800
	v_min_i32_e32 v25, s16, v7                                 // 000000552EC8: 22320E10
	s_cselect_b32 s16, -1, 0                                   // 000000552ECC: 981080C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000552ED0: BF870159
	s_and_b32 vcc_lo, exec_lo, s16                             // 000000552ED4: 8B6A107E
	s_waitcnt vmcnt(1)                                         // 000000552ED8: BF8907F7
	v_bfe_u32 v2, v3, 16, 1                                    // 000000552EDC: D6100002 02052103
	s_waitcnt vmcnt(0)                                         // 000000552EE4: BF8903F7
	v_bfe_u32 v6, v4, 16, 1                                    // 000000552EE8: D6100006 02052104
	v_add3_u32 v2, v3, v2, 0x7fff                              // 000000552EF0: D6550002 03FE0503 00007FFF
	v_add_nc_u32_e32 v3, s1, v18                               // 000000552EFC: 4A062401
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000552F00: BF870223
	v_add3_u32 v4, v4, v6, 0x7fff                              // 000000552F04: D6550004 03FE0D04 00007FFF
	.long 0xd4410001                                           // 000000552F10: D4410001
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 000000552F14: 02023318
	.long 0x7e0a3982                                           // 000000552F18: 7E0A3982
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000552F1C: BF870114
	v_add_nc_u32_e32 v26, s17, v3                              // 000000552F20: 4A340611
	v_and_or_b32 v1, 0xffff0000, v4, v5                        // 000000552F24: D6570001 041608FF FFFF0000
	ds_store_b32 v21, v1                                       // 000000552F30: D8340000 00000115
	s_waitcnt lgkmcnt(0)                                       // 000000552F38: BF89FC07
	s_barrier                                                  // 000000552F3C: BFBD0000
	buffer_gl0_inv                                             // 000000552F40: E0AC0000 00000000
	s_cbranch_vccnz 154                                        // 000000552F48: BFA4009A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x3b4>
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v1, 0               // 000000552F4C: CA100080 02000080
	s_and_saveexec_b32 s17, s1                                 // 000000552F54: BE912001
	s_cbranch_execz 11                                         // 000000552F58: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x188>
	v_lshlrev_b32_e32 v1, 1, v24                               // 000000552F5C: 30023081
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000552F60: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v1                               // 000000552F64: 3408029F
	.long 0xd7006a03                                           // 000000552F68: D7006A03
	v_cndmask_b32_e32 v1, v17, v1, vcc_lo                      // 000000552F6C: 02020311
	v_add_co_ci_u32_e64 v4, null, v26, v4, vcc_lo              // 000000552F70: D5207C04 01AA091A
	global_load_d16_b16 v1, v[3:4], off                        // 000000552F78: DC820000 017C0003
	s_waitcnt vmcnt(0)                                         // 000000552F80: BF8903F7
	v_cvt_f32_f16_e32 v1, v1                                   // 000000552F84: 7E021701
	s_or_b32 exec_lo, exec_lo, s17                             // 000000552F88: 8C7E117E
	v_add_nc_u32_e32 v3, 32, v24                               // 000000552F8C: 4A0630A0
	s_mov_b32 s1, exec_lo                                      // 000000552F90: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000552F94: BF870001
	.long 0xd4c1007e                                           // 000000552F98: D4C1007E
	v_cndmask_b32_e32 v1, v3, v25, vcc_lo                      // 000000552F9C: 02023303
	s_cbranch_execz 11                                         // 000000552FA0: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x1d0>
	v_lshlrev_b32_e32 v2, 1, v3                                // 000000552FA4: 30040681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000552FA8: BF8700A1
	v_ashrrev_i32_e32 v3, 31, v2                               // 000000552FAC: 3406049F
	.long 0xd7006a02                                           // 000000552FB0: D7006A02
	v_cndmask_b32_e32 v1, v17, v2, vcc_lo                      // 000000552FB4: 02020511
	v_add_co_ci_u32_e64 v3, null, v26, v3, vcc_lo              // 000000552FB8: D5207C03 01AA071A
	global_load_d16_b16 v2, v[2:3], off                        // 000000552FC0: DC820000 027C0002
	s_waitcnt vmcnt(0)                                         // 000000552FC8: BF8903F7
	v_cvt_f32_f16_e32 v2, v2                                   // 000000552FCC: 7E041702
	s_or_b32 exec_lo, exec_lo, s1                              // 000000552FD0: 8C7E017E
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v5, 64, v24      // 000000552FD4: CA200080 040430C0
	v_mov_b32_e32 v3, 0                                        // 000000552FDC: 7E060280
	s_mov_b32 s1, exec_lo                                      // 000000552FE0: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000552FE4: BF870002
	.long 0xd4c1007e                                           // 000000552FE8: D4C1007E
	v_cndmask_b32_e32 v1, v5, v25, vcc_lo                      // 000000552FEC: 02023305
	s_cbranch_execz 11                                         // 000000552FF0: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x220>
	v_lshlrev_b32_e32 v3, 1, v5                                // 000000552FF4: 30060A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000552FF8: BF8700A1
	v_ashrrev_i32_e32 v6, 31, v3                               // 000000552FFC: 340C069F
	.long 0xd7006a05                                           // 000000553000: D7006A05
	v_cndmask_b32_e32 v1, v17, v3, vcc_lo                      // 000000553004: 02020711
	v_add_co_ci_u32_e64 v6, null, v26, v6, vcc_lo              // 000000553008: D5207C06 01AA0D1A
	global_load_d16_b16 v3, v[5:6], off                        // 000000553010: DC820000 037C0005
	s_waitcnt vmcnt(0)                                         // 000000553018: BF8903F7
	v_cvt_f32_f16_e32 v3, v3                                   // 00000055301C: 7E061703
	s_or_b32 exec_lo, exec_lo, s1                              // 000000553020: 8C7E017E
	v_add_nc_u32_e32 v5, 0x60, v24                             // 000000553024: 4A0A30FF 00000060
	s_mov_b32 s1, exec_lo                                      // 00000055302C: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000553030: BF870001
	.long 0xd4c1007e                                           // 000000553034: D4C1007E
	v_cndmask_b32_e32 v1, v5, v25, vcc_lo                      // 000000553038: 02023305
	s_cbranch_execz 11                                         // 00000055303C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x26c>
	v_lshlrev_b32_e32 v4, 1, v5                                // 000000553040: 30080A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000553044: BF8700A1
	v_ashrrev_i32_e32 v5, 31, v4                               // 000000553048: 340A089F
	.long 0xd7006a04                                           // 00000055304C: D7006A04
	v_cndmask_b32_e32 v1, v17, v4, vcc_lo                      // 000000553050: 02020911
	v_add_co_ci_u32_e64 v5, null, v26, v5, vcc_lo              // 000000553054: D5207C05 01AA0B1A
	global_load_d16_b16 v4, v[4:5], off                        // 00000055305C: DC820000 047C0004
	s_waitcnt vmcnt(0)                                         // 000000553064: BF8903F7
	v_cvt_f32_f16_e32 v4, v4                                   // 000000553068: 7E081704
	s_or_b32 exec_lo, exec_lo, s1                              // 00000055306C: 8C7E017E
	v_dual_mov_b32 v6, 0 :: v_dual_add_nc_u32 v7, 0x80, v24    // 000000553070: CA200080 060630FF 00000080
	v_mov_b32_e32 v5, 0                                        // 00000055307C: 7E0A0280
	s_mov_b32 s1, exec_lo                                      // 000000553080: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000553084: BF870002
	.long 0xd4c1007e                                           // 000000553088: D4C1007E
	v_cndmask_b32_e32 v1, v7, v25, vcc_lo                      // 00000055308C: 02023307
	s_cbranch_execz 11                                         // 000000553090: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x2c0>
	v_lshlrev_b32_e32 v5, 1, v7                                // 000000553094: 300A0E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000553098: BF8700A1
	v_ashrrev_i32_e32 v8, 31, v5                               // 00000055309C: 34100A9F
	.long 0xd7006a07                                           // 0000005530A0: D7006A07
	v_cndmask_b32_e32 v1, v17, v5, vcc_lo                      // 0000005530A4: 02020B11
	v_add_co_ci_u32_e64 v8, null, v26, v8, vcc_lo              // 0000005530A8: D5207C08 01AA111A
	global_load_d16_b16 v5, v[7:8], off                        // 0000005530B0: DC820000 057C0007
	s_waitcnt vmcnt(0)                                         // 0000005530B8: BF8903F7
	v_cvt_f32_f16_e32 v5, v5                                   // 0000005530BC: 7E0A1705
	s_or_b32 exec_lo, exec_lo, s1                              // 0000005530C0: 8C7E017E
	v_add_nc_u32_e32 v7, 0xa0, v24                             // 0000005530C4: 4A0E30FF 000000A0
	s_mov_b32 s1, exec_lo                                      // 0000005530CC: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000005530D0: BF870001
	.long 0xd4c1007e                                           // 0000005530D4: D4C1007E
	v_cndmask_b32_e32 v1, v7, v25, vcc_lo                      // 0000005530D8: 02023307
	s_cbranch_execz 11                                         // 0000005530DC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x30c>
	v_lshlrev_b32_e32 v6, 1, v7                                // 0000005530E0: 300C0E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005530E4: BF8700A1
	v_ashrrev_i32_e32 v7, 31, v6                               // 0000005530E8: 340E0C9F
	.long 0xd7006a06                                           // 0000005530EC: D7006A06
	v_cndmask_b32_e32 v1, v17, v6, vcc_lo                      // 0000005530F0: 02020D11
	v_add_co_ci_u32_e64 v7, null, v26, v7, vcc_lo              // 0000005530F4: D5207C07 01AA0F1A
	global_load_d16_b16 v6, v[6:7], off                        // 0000005530FC: DC820000 067C0006
	s_waitcnt vmcnt(0)                                         // 000000553104: BF8903F7
	v_cvt_f32_f16_e32 v6, v6                                   // 000000553108: 7E0C1706
	s_or_b32 exec_lo, exec_lo, s1                              // 00000055310C: 8C7E017E
	v_dual_mov_b32 v8, 0 :: v_dual_add_nc_u32 v9, 0xc0, v24    // 000000553110: CA200080 080830FF 000000C0
	v_mov_b32_e32 v7, 0                                        // 00000055311C: 7E0E0280
	s_mov_b32 s1, exec_lo                                      // 000000553120: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000553124: BF870002
	.long 0xd4c1007e                                           // 000000553128: D4C1007E
	v_cndmask_b32_e32 v1, v9, v25, vcc_lo                      // 00000055312C: 02023309
	s_cbranch_execz 11                                         // 000000553130: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x360>
	v_lshlrev_b32_e32 v7, 1, v9                                // 000000553134: 300E1281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000553138: BF8700A1
	v_ashrrev_i32_e32 v10, 31, v7                              // 00000055313C: 34140E9F
	.long 0xd7006a09                                           // 000000553140: D7006A09
	v_cndmask_b32_e32 v1, v17, v7, vcc_lo                      // 000000553144: 02020F11
	v_add_co_ci_u32_e64 v10, null, v26, v10, vcc_lo            // 000000553148: D5207C0A 01AA151A
	global_load_d16_b16 v7, v[9:10], off                       // 000000553150: DC820000 077C0009
	s_waitcnt vmcnt(0)                                         // 000000553158: BF8903F7
	v_cvt_f32_f16_e32 v7, v7                                   // 00000055315C: 7E0E1707
	s_or_b32 exec_lo, exec_lo, s1                              // 000000553160: 8C7E017E
	v_add_nc_u32_e32 v9, 0xe0, v24                             // 000000553164: 4A1230FF 000000E0
	s_mov_b32 s1, exec_lo                                      // 00000055316C: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000553170: BF870001
	.long 0xd4c1007e                                           // 000000553174: D4C1007E
	v_cndmask_b32_e32 v1, v9, v25, vcc_lo                      // 000000553178: 02023309
	s_cbranch_execz 11                                         // 00000055317C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x3ac>
	v_lshlrev_b32_e32 v8, 1, v9                                // 000000553180: 30101281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000553184: BF8700A1
	v_ashrrev_i32_e32 v9, 31, v8                               // 000000553188: 3412109F
	.long 0xd7006a08                                           // 00000055318C: D7006A08
	v_cndmask_b32_e32 v1, v17, v8, vcc_lo                      // 000000553190: 02021111
	v_add_co_ci_u32_e64 v9, null, v26, v9, vcc_lo              // 000000553194: D5207C09 01AA131A
	global_load_d16_b16 v8, v[8:9], off                        // 00000055319C: DC820000 087C0008
	s_waitcnt vmcnt(0)                                         // 0000005531A4: BF8903F7
	v_cvt_f32_f16_e32 v8, v8                                   // 0000005531A8: 7E101708
	s_or_b32 exec_lo, exec_lo, s1                              // 0000005531AC: 8C7E017E
	s_branch 9                                                 // 0000005531B0: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x3d8>
	v_mov_b32_e32 v1, 0                                        // 0000005531B4: 7E020280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000005531B8: BF870001
	v_mov_b32_e32 v2, v1                                       // 0000005531BC: 7E040301
	v_mov_b32_e32 v3, v1                                       // 0000005531C0: 7E060301
	v_mov_b32_e32 v4, v1                                       // 0000005531C4: 7E080301
	v_mov_b32_e32 v5, v1                                       // 0000005531C8: 7E0A0301
	v_mov_b32_e32 v6, v1                                       // 0000005531CC: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 0000005531D0: 7E0E0301
	v_mov_b32_e32 v8, v1                                       // 0000005531D4: 7E100301
	s_add_u32 s4, s4, s14                                      // 0000005531D8: 80040E04
	s_addc_u32 s5, s5, s15                                     // 0000005531DC: 82050F05
	s_lshr_b32 s1, s11, 31                                     // 0000005531E0: 85019F0B
	v_dual_mov_b32 v9, s21 :: v_dual_mov_b32 v10, 0            // 0000005531E4: CA100015 090A0080
	s_add_u32 s14, s10, s1                                     // 0000005531EC: 800E010A
	s_addc_u32 s15, s11, 0                                     // 0000005531F0: 820F800B
	.long 0xd4410001                                           // 0000005531F4: D4410001
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 0000005531F8: 02023318
	s_ashr_i64 s[14:15], s[14:15], 1                           // 0000005531FC: 868E810E
	v_mov_b32_e32 v27, 0                                       // 000000553200: 7E360280
	v_mad_u64_u32 v[18:19], null, v9, s14, s[4:5]              // 000000553204: D6FE7C12 00101D09
	.long 0xd72c000b                                           // 00000055320C: D72C000B
	v_cndmask_b32_e32 v0, s21, v15, vcc_lo                     // 000000553210: 02001E15
	.long 0xd72c000c                                           // 000000553214: D72C000C
	v_cndmask_b32_e32 v0, s20, v14, vcc_lo                     // 000000553218: 02001C14
	v_mov_b32_e32 v9, 0                                        // 00000055321C: 7E120280
	v_cndmask_b32_e64 v28, 0, 1, s16                           // 000000553220: D501001C 00410280
	v_mov_b32_e32 v35, 0                                       // 000000553228: 7E460280
	s_delay_alu instid0(VALU_DEP_4)                            // 00000055322C: BF870004
	v_add3_u32 v29, v12, v19, v11                              // 000000553230: D655001D 042E270C
	v_dual_mov_b32 v11, 0 :: v_dual_mov_b32 v12, 0             // 000000553238: CA100080 0B0C0080
	s_and_saveexec_b32 s4, s1                                  // 000000553240: BE842001
	s_cbranch_execz 22                                         // 000000553244: BFA50016 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x4a0>
	v_lshlrev_b32_e32 v9, 4, v24                               // 000000553248: 30123084
	v_mov_b32_e32 v35, 0                                       // 00000055324C: 7E460280
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000553250: BF8700A2
	v_ashrrev_i32_e32 v10, 31, v9                              // 000000553254: 3414129F
	.long 0xd7006a09                                           // 000000553258: D7006A09
	v_cndmask_b32_e32 v1, v18, v9, vcc_lo                      // 00000055325C: 02021312
	v_add_co_ci_u32_e64 v10, null, v29, v10, vcc_lo            // 000000553260: D5207C0A 01AA151D
	s_and_not1_b32 vcc_lo, exec_lo, s16                        // 000000553268: 916A107E
	global_load_b128 v[9:12], v[9:10], off                     // 00000055326C: DC5E0000 097C0009
	s_cbranch_vccnz 10                                         // 000000553274: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x4a0>
	v_lshlrev_b32_e32 v13, 1, v24                              // 000000553278: 301A3081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000055327C: BF870091
	.long 0xd7006a0d                                           // 000000553280: D7006A0D
	v_cndmask_b32_e32 v1, v17, v13, vcc_lo                     // 000000553284: 02021B11
	v_add_co_ci_u32_e64 v14, null, 0, v26, vcc_lo              // 000000553288: D5207C0E 01AA3480
	global_load_d16_b16 v13, v[13:14], off                     // 000000553290: DC820000 0D7C000D
	s_waitcnt vmcnt(0)                                         // 000000553298: BF8903F7
	v_cvt_f32_f16_e32 v35, v13                                 // 00000055329C: 7E46170D
	s_or_b32 exec_lo, exec_lo, s4                              // 0000005532A0: 8C7E047E
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v30, 0             // 0000005532A4: CA100080 1F1E0080
	s_and_saveexec_b32 s14, s1                                 // 0000005532AC: BE8E2001
	s_cbranch_execz 338                                        // 0000005532B0: BFA50152 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x9fc>
	v_dual_mov_b32 v30, 0 :: v_dual_add_nc_u32 v13, 32, v24    // 0000005532B4: CA200080 1E0C30A0
	v_dual_mov_b32 v34, v35 :: v_dual_lshlrev_b32 v19, 5, v24  // 0000005532BC: CA220123 22123085
	s_delay_alu instid0(VALU_DEP_2)                            // 0000005532C4: BF870002
	v_dual_mov_b32 v31, 0 :: v_dual_lshlrev_b32 v32, 4, v13    // 0000005532C8: CA220080 1F201A84
	v_lshlrev_b32_e32 v33, 1, v13                              // 0000005532D0: 30421A81
	v_mov_b32_e32 v27, 0                                       // 0000005532D4: 7E360280
	s_lshl_b64 s[4:5], s[10:11], 2                             // 0000005532D8: 8484820A
	s_mov_b32 s15, 0                                           // 0000005532DC: BE8F0080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 0000005532E0: 848A810A
	s_branch 289                                               // 0000005532E4: BFA00121 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x96c>
	s_or_b32 exec_lo, exec_lo, s16                             // 0000005532E8: 8C7E107E
	v_ashrrev_i32_e32 v20, 31, v19                             // 0000005532EC: 3428269F
	v_cndmask_b32_e64 v84, v35, v1, s0                         // 0000005532F0: D5010054 00020323
	v_lshrrev_b32_e32 v35, 6, v9                               // 0000005532F8: 32461286
	v_lshrrev_b32_e32 v85, 14, v9                              // 0000005532FC: 32AA128E
	v_and_b32_e32 v86, 0xff, v10                               // 000000553300: 36AC14FF 000000FF
	.long 0xd73c0024                                           // 000000553308: D73C0024
	v_cndmask_b32_e32 v1, 1, v19, vcc_lo                       // 00000055330C: 02022681
	v_and_b32_e32 v20, 0xff, v9                                // 000000553310: 362812FF 000000FF
	v_and_b32_e32 v35, 0x3fc, v35                              // 000000553318: 364646FF 000003FC
	v_and_b32_e32 v85, 0x3fc, v85                              // 000000553320: 36AAAAFF 000003FC
	v_lshrrev_b32_e32 v9, 22, v9                               // 000000553328: 32121296
	v_lshrrev_b32_e32 v87, 6, v10                              // 00000055332C: 32AE1486
	.long 0xd7006a48                                           // 000000553330: D7006A48
	v_cndmask_b32_e32 v1, s6, v36, vcc_lo                      // 000000553334: 02024806
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000553338: BF8701A1
	v_add_co_ci_u32_e64 v73, null, s7, v37, vcc_lo             // 00000055333C: D5207C49 01AA4A07
	v_lshlrev_b32_e32 v20, 2, v20                              // 000000553344: 30282882
	.long 0xd7006a4c                                           // 000000553348: D7006A4C
	v_cndmask_b32_e32 v0, v72, v10, vcc_lo                     // 00000055334C: 02001548
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000553350: BF8700A1
	v_add_co_ci_u32_e64 v77, null, s11, v73, vcc_lo            // 000000553354: D5207C4D 01AA920B
	.long 0xd7006a50                                           // 00000055335C: D7006A50
	v_cndmask_b32_e32 v0, v72, v4, vcc_lo                      // 000000553360: 02000948
	v_add_co_ci_u32_e64 v81, null, s5, v73, vcc_lo             // 000000553364: D5207C51 01AA9205
	s_clause 0xb                                               // 00000055336C: BF85000B
	global_load_b128 v[36:39], v[72:73], off                   // 000000553370: DC5E0000 247C0048
	global_load_b128 v[40:43], v[76:77], off                   // 000000553378: DC5E0000 287C004C
	global_load_b128 v[44:47], v[80:81], off                   // 000000553380: DC5E0000 2C7C0050
	global_load_b128 v[48:51], v[72:73], off offset:16         // 000000553388: DC5E0010 307C0048
	global_load_b128 v[52:55], v[76:77], off offset:16         // 000000553390: DC5E0010 347C004C
	global_load_b128 v[56:59], v[80:81], off offset:16         // 000000553398: DC5E0010 387C0050
	global_load_b128 v[60:63], v[72:73], off offset:32         // 0000005533A0: DC5E0020 3C7C0048
	global_load_b128 v[64:67], v[76:77], off offset:32         // 0000005533A8: DC5E0020 407C004C
	global_load_b128 v[68:71], v[80:81], off offset:32         // 0000005533B0: DC5E0020 447C0050
	global_load_b128 v[72:75], v[72:73], off offset:48         // 0000005533B8: DC5E0030 487C0048
	global_load_b128 v[76:79], v[76:77], off offset:48         // 0000005533C0: DC5E0030 4C7C004C
	global_load_b128 v[80:83], v[80:81], off offset:48         // 0000005533C8: DC5E0030 507C0050
	ds_load_b32 v20, v20                                       // 0000005533D0: D8D80000 14000014
	ds_load_b32 v35, v35                                       // 0000005533D8: D8D80000 23000023
	ds_load_b32 v85, v85                                       // 0000005533E0: D8D80000 55000055
	v_lshrrev_b32_e32 v88, 14, v10                             // 0000005533E8: 32B0148E
	v_lshrrev_b32_e32 v10, 22, v10                             // 0000005533EC: 32141496
	v_lshlrev_b32_e32 v86, 2, v86                              // 0000005533F0: 30ACAC82
	v_and_b32_e32 v87, 0x3fc, v87                              // 0000005533F4: 36AEAEFF 000003FC
	v_and_b32_e32 v89, 0xff, v11                               // 0000005533FC: 36B216FF 000000FF
	v_and_b32_e32 v88, 0x3fc, v88                              // 000000553404: 36B0B0FF 000003FC
	v_lshrrev_b32_e32 v90, 6, v11                              // 00000055340C: 32B41686
	v_lshrrev_b32_e32 v91, 14, v11                             // 000000553410: 32B6168E
	v_lshrrev_b32_e32 v11, 22, v11                             // 000000553414: 32161696
	v_lshrrev_b32_e32 v93, 14, v12                             // 000000553418: 32BA188E
	v_add_nc_u32_e32 v33, 64, v33                              // 00000055341C: 4A4242C0
	v_add_nc_u32_e32 v19, 0x400, v19                           // 000000553420: 4A2626FF 00000400
	s_and_b32 s1, exec_lo, s1                                  // 000000553428: 8B01017E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000055342C: BF870009
	s_or_b32 s15, s1, s15                                      // 000000553430: 8C0F0F01
	s_waitcnt vmcnt(11) lgkmcnt(2)                             // 000000553434: BF892C27
	v_dot2_f32_bf16 v36, v36, v20, 0                           // 000000553438: CC1A4024 1A022924
	s_waitcnt vmcnt(10)                                        // 000000553440: BF892BF7
	v_dot2_f32_bf16 v40, v40, v20, 0                           // 000000553444: CC1A4028 1A022928
	s_waitcnt vmcnt(9)                                         // 00000055344C: BF8927F7
	v_dot2_f32_bf16 v20, v44, v20, 0                           // 000000553450: CC1A4014 1A02292C
	v_lshrrev_b32_e32 v44, 6, v12                              // 000000553458: 32581886
	s_waitcnt lgkmcnt(1)                                       // 00000055345C: BF89FC17
	v_dot2_f32_bf16 v36, v37, v35, v36                         // 000000553460: CC1A4024 1C924725
	v_dot2_f32_bf16 v37, v41, v35, v40                         // 000000553468: CC1A4025 1CA24729
	v_dot2_f32_bf16 v20, v45, v35, v20                         // 000000553470: CC1A4014 1C52472D
	v_and_b32_e32 v40, 0x3fc, v91                              // 000000553478: 3650B6FF 000003FC
	v_and_b32_e32 v41, 0x3fc, v93                              // 000000553480: 3652BAFF 000003FC
	s_waitcnt lgkmcnt(0)                                       // 000000553488: BF89FC07
	v_dot2_f32_bf16 v36, v38, v85, v36                         // 00000055348C: CC1A4024 1C92AB26
	v_dot2_f32_bf16 v37, v42, v85, v37                         // 000000553494: CC1A4025 1C96AB2A
	v_cndmask_b32_e64 v42, v7, v8, s0                          // 00000055349C: D501002A 00021107
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000005534A4: 361212FF 000003FC
	v_and_b32_e32 v10, 0x3fc, v10                              // 0000005534AC: 361414FF 000003FC
	ds_load_b32 v9, v9                                         // 0000005534B4: D8D80000 09000009
	ds_load_b32 v86, v86                                       // 0000005534BC: D8D80000 56000056
	ds_load_b32 v87, v87                                       // 0000005534C4: D8D80000 57000057
	ds_load_b32 v88, v88                                       // 0000005534CC: D8D80000 58000058
	ds_load_b32 v10, v10                                       // 0000005534D4: D8D80000 0A00000A
	v_dot2_f32_bf16 v20, v46, v85, v20                         // 0000005534DC: CC1A4014 1C52AB2E
	v_lshlrev_b32_e32 v35, 2, v89                              // 0000005534E4: 3046B282
	v_and_b32_e32 v38, 0x3fc, v90                              // 0000005534E8: 364CB4FF 000003FC
	ds_load_b32 v35, v35                                       // 0000005534F0: D8D80000 23000023
	ds_load_b32 v38, v38                                       // 0000005534F8: D8D80000 26000026
	s_waitcnt lgkmcnt(6)                                       // 000000553500: BF89FC67
	v_dot2_f32_bf16 v36, v39, v9, v36                          // 000000553504: CC1A4024 1C921327
	v_dot2_f32_bf16 v37, v43, v9, v37                          // 00000055350C: CC1A4025 1C96132B
	v_dot2_f32_bf16 v9, v47, v9, v20                           // 000000553514: CC1A4009 1C52132F
	ds_load_b32 v43, v40                                       // 00000055351C: D8D80000 2B000028
	v_and_b32_e32 v92, 0xff, v12                               // 000000553524: 36B818FF 000000FF
	s_waitcnt vmcnt(8) lgkmcnt(6)                              // 00000055352C: BF892067
	v_dot2_f32_bf16 v36, v48, v86, v36                         // 000000553530: CC1A4024 1C92AD30
	s_waitcnt vmcnt(7)                                         // 000000553538: BF891FF7
	v_dot2_f32_bf16 v37, v52, v86, v37                         // 00000055353C: CC1A4025 1C96AD34
	s_waitcnt vmcnt(6)                                         // 000000553544: BF891BF7
	v_dot2_f32_bf16 v9, v56, v86, v9                           // 000000553548: CC1A4009 1C26AD38
	v_lshrrev_b32_e32 v12, 22, v12                             // 000000553550: 32181896
	v_cndmask_b32_e64 v40, v5, v6, s0                          // 000000553554: D5010028 00020D05
	s_waitcnt lgkmcnt(5)                                       // 00000055355C: BF89FC57
	v_dot2_f32_bf16 v36, v49, v87, v36                         // 000000553560: CC1A4024 1C92AF31
	v_dot2_f32_bf16 v37, v53, v87, v37                         // 000000553568: CC1A4025 1C96AF35
	v_dot2_f32_bf16 v9, v57, v87, v9                           // 000000553570: CC1A4009 1C26AF39
	v_and_b32_e32 v11, 0x3fc, v11                              // 000000553578: 361616FF 000003FC
	v_lshlrev_b32_e32 v20, 2, v92                              // 000000553580: 3028B882
	s_waitcnt lgkmcnt(4)                                       // 000000553584: BF89FC47
	v_dot2_f32_bf16 v36, v50, v88, v36                         // 000000553588: CC1A4024 1C92B132
	v_dot2_f32_bf16 v37, v54, v88, v37                         // 000000553590: CC1A4025 1C96B136
	v_dot2_f32_bf16 v9, v58, v88, v9                           // 000000553598: CC1A4009 1C26B13A
	v_and_b32_e32 v39, 0x3fc, v44                              // 0000005535A0: 364E58FF 000003FC
	v_and_b32_e32 v12, 0x3fc, v12                              // 0000005535A8: 361818FF 000003FC
	s_waitcnt lgkmcnt(3)                                       // 0000005535B0: BF89FC37
	v_dot2_f32_bf16 v36, v51, v10, v36                         // 0000005535B4: CC1A4024 1C921533
	v_dot2_f32_bf16 v37, v55, v10, v37                         // 0000005535BC: CC1A4025 1C961537
	v_dot2_f32_bf16 v9, v59, v10, v9                           // 0000005535C4: CC1A4009 1C26153B
	ds_load_b32 v10, v11                                       // 0000005535CC: D8D80000 0A00000B
	ds_load_b32 v11, v20                                       // 0000005535D4: D8D80000 0B000014
	ds_load_b32 v20, v39                                       // 0000005535DC: D8D80000 14000027
	ds_load_b32 v44, v41                                       // 0000005535E4: D8D80000 2C000029
	ds_load_b32 v45, v12                                       // 0000005535EC: D8D80000 2D00000C
	v_cndmask_b32_e64 v41, v6, v7, s0                          // 0000005535F4: D5010029 00020F06
	s_waitcnt vmcnt(5) lgkmcnt(7)                              // 0000005535FC: BF891477
	v_dot2_f32_bf16 v12, v60, v35, v36                         // 000000553600: CC1A400C 1C92473C
	s_waitcnt vmcnt(4)                                         // 000000553608: BF8913F7
	v_dot2_f32_bf16 v36, v64, v35, v37                         // 00000055360C: CC1A4024 1C964740
	s_waitcnt vmcnt(3)                                         // 000000553614: BF890FF7
	v_dot2_f32_bf16 v9, v68, v35, v9                           // 000000553618: CC1A4009 1C264744
	v_cndmask_b32_e64 v39, v4, v5, s0                          // 000000553620: D5010027 00020B04
	v_cndmask_b32_e64 v37, v2, v3, s0                          // 000000553628: D5010025 00020702
	s_waitcnt lgkmcnt(6)                                       // 000000553630: BF89FC67
	v_dot2_f32_bf16 v7, v61, v38, v12                          // 000000553634: CC1A4007 1C324D3D
	v_dot2_f32_bf16 v12, v65, v38, v36                         // 00000055363C: CC1A400C 1C924D41
	v_dot2_f32_bf16 v9, v69, v38, v9                           // 000000553644: CC1A4009 1C264D45
	v_cndmask_b32_e64 v38, v3, v4, s0                          // 00000055364C: D5010026 00020903
	v_cndmask_b32_e64 v36, v1, v2, s0                          // 000000553654: D5010024 00020501
	s_waitcnt lgkmcnt(5)                                       // 00000055365C: BF89FC57
	v_dot2_f32_bf16 v5, v62, v43, v7                           // 000000553660: CC1A4005 1C1E573E
	v_dot2_f32_bf16 v6, v66, v43, v12                          // 000000553668: CC1A4006 1C325742
	v_dot2_f32_bf16 v7, v70, v43, v9                           // 000000553670: CC1A4007 1C265746
	v_dual_mov_b32 v43, v8 :: v_dual_add_nc_u32 v32, 0x200, v32// 000000553678: CA200108 2B2040FF 00000200
	s_waitcnt lgkmcnt(4)                                       // 000000553684: BF89FC47
	v_dot2_f32_bf16 v3, v63, v10, v5                           // 000000553688: CC1A4003 1C16153F
	v_dot2_f32_bf16 v4, v67, v10, v6                           // 000000553690: CC1A4004 1C1A1543
	v_dot2_f32_bf16 v5, v71, v10, v7                           // 000000553698: CC1A4005 1C1E1547
	v_mov_b32_e32 v12, v16                                     // 0000005536A0: 7E180310
	v_mov_b32_e32 v10, v14                                     // 0000005536A4: 7E14030E
	s_waitcnt vmcnt(2) lgkmcnt(3)                              // 0000005536A8: BF890837
	v_dot2_f32_bf16 v1, v72, v11, v3                           // 0000005536AC: CC1A4001 1C0E1748
	s_waitcnt vmcnt(1)                                         // 0000005536B4: BF8907F7
	v_dot2_f32_bf16 v2, v76, v11, v4                           // 0000005536B8: CC1A4002 1C12174C
	s_waitcnt vmcnt(0)                                         // 0000005536C0: BF8903F7
	v_dot2_f32_bf16 v3, v80, v11, v5                           // 0000005536C4: CC1A4003 1C161750
	v_mov_b32_e32 v11, v15                                     // 0000005536CC: 7E16030F
	v_mov_b32_e32 v9, v13                                      // 0000005536D0: 7E12030D
	s_waitcnt lgkmcnt(2)                                       // 0000005536D4: BF89FC27
	v_dot2_f32_bf16 v1, v73, v20, v1                           // 0000005536D8: CC1A4001 1C062949
	v_dot2_f32_bf16 v2, v77, v20, v2                           // 0000005536E0: CC1A4002 1C0A294D
	v_dot2_f32_bf16 v3, v81, v20, v3                           // 0000005536E8: CC1A4003 1C0E2951
	v_mov_b32_e32 v35, v34                                     // 0000005536F0: 7E460322
	s_waitcnt lgkmcnt(1)                                       // 0000005536F4: BF89FC17
	v_dot2_f32_bf16 v1, v74, v44, v1                           // 0000005536F8: CC1A4001 1C06594A
	v_dot2_f32_bf16 v2, v78, v44, v2                           // 000000553700: CC1A4002 1C0A594E
	v_dot2_f32_bf16 v3, v82, v44, v3                           // 000000553708: CC1A4003 1C0E5952
	s_waitcnt lgkmcnt(0)                                       // 000000553710: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000553714: BF870193
	v_dot2_f32_bf16 v1, v75, v45, v1                           // 000000553718: CC1A4001 1C065B4B
	v_dot2_f32_bf16 v2, v79, v45, v2                           // 000000553720: CC1A4002 1C0A5B4F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000553728: BF870193
	v_dot2_f32_bf16 v3, v83, v45, v3                           // 00000055372C: CC1A4003 1C0E5B53
	v_fmac_f32_e32 v30, v84, v1                                // 000000553734: 563C0354
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000553738: BF870193
	v_fmac_f32_e32 v31, v84, v2                                // 00000055373C: 563E0554
	v_fmac_f32_e32 v27, v84, v3                                // 000000553740: 56360754
	v_dual_mov_b32 v1, v36 :: v_dual_mov_b32 v2, v37           // 000000553744: CA100124 01020125
	v_dual_mov_b32 v3, v38 :: v_dual_mov_b32 v4, v39           // 00000055374C: CA100126 03040127
	v_dual_mov_b32 v5, v40 :: v_dual_mov_b32 v6, v41           // 000000553754: CA100128 05060129
	v_dual_mov_b32 v7, v42 :: v_dual_mov_b32 v8, v43           // 00000055375C: CA10012A 0708012B
	s_and_not1_b32 exec_lo, exec_lo, s15                       // 000000553764: 917E0F7E
	s_cbranch_execz 35                                         // 000000553768: BFA50023 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x9f8>
	s_waitcnt vmcnt(0)                                         // 00000055376C: BF8903F7
	v_dual_mov_b32 v13, v9 :: v_dual_add_nc_u32 v24, 32, v24   // 000000553770: CA200109 0D1830A0
	v_dual_mov_b32 v14, v10 :: v_dual_mov_b32 v15, v11         // 000000553778: CA10010A 0E0E010B
	v_mov_b32_e32 v16, v12                                     // 000000553780: 7E20030C
	s_delay_alu instid0(VALU_DEP_3)                            // 000000553784: BF870003
	.long 0xd4460001                                           // 000000553788: D4460001
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 00000055378C: 02023318
	s_mov_b32 s16, exec_lo                                     // 000000553790: BE90007E
	.long 0xd4c1007e                                           // 000000553794: D4C1007E
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 000000553798: 02023318
	s_cbranch_execz 65234                                      // 00000055379C: BFA5FED2 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x4e8>
	v_ashrrev_i32_e32 v14, 31, v32                             // 0000005537A0: 341C409F
	.long 0xd7006a0d                                           // 0000005537A4: D7006A0D
	v_cndmask_b32_e32 v1, v18, v32, vcc_lo                     // 0000005537A8: 02024112
	v_mov_b32_e32 v34, v35                                     // 0000005537AC: 7E440323
	s_delay_alu instid0(VALU_DEP_3)                            // 0000005537B0: BF870003
	v_add_co_ci_u32_e64 v14, null, v29, v14, vcc_lo            // 0000005537B4: D5207C0E 01AA1D1D
	v_cmp_ne_u32_e32 vcc_lo, 1, v28                            // 0000005537BC: 7C9A3881
	global_load_b128 v[13:16], v[13:14], off                   // 0000005537C0: DC5E0000 0D7C000D
	s_cbranch_vccnz 65223                                      // 0000005537C8: BFA4FEC7 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x4e8>
	v_ashrrev_i32_e32 v20, 31, v33                             // 0000005537CC: 3428429F
	.long 0xd7006a24                                           // 0000005537D0: D7006A24
	v_cndmask_b32_e32 v1, v17, v33, vcc_lo                     // 0000005537D4: 02024311
	s_delay_alu instid0(VALU_DEP_1)                            // 0000005537D8: BF870001
	v_add_co_ci_u32_e64 v37, null, v26, v20, vcc_lo            // 0000005537DC: D5207C25 01AA291A
	global_load_d16_b16 v20, v[36:37], off                     // 0000005537E4: DC820000 147C0024
	s_waitcnt vmcnt(0)                                         // 0000005537EC: BF8903F7
	v_cvt_f32_f16_e32 v34, v20                                 // 0000005537F0: 7E441714
	s_branch 65212                                             // 0000005537F4: BFA0FEBC <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x4e8>
	s_or_b32 exec_lo, exec_lo, s15                             // 0000005537F8: 8C7E0F7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000005537FC: BF8700B9
	s_or_b32 exec_lo, exec_lo, s14                             // 000000553800: 8C7E0E7E
	.long 0xd71f0001                                           // 000000553804: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000553808: 020100C1
	s_mov_b32 s0, exec_lo                                      // 00000055380C: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 000000553810: 3A040290
	v_xor_b32_e32 v5, 8, v1                                    // 000000553814: 3A0A0288
	v_xor_b32_e32 v8, 4, v1                                    // 000000553818: 3A100284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000055381C: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 000000553820: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 000000553824: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v5                            // 000000553828: 7C980AA0
	v_cndmask_b32_e32 v5, v1, v5, vcc_lo                       // 00000055382C: 020A0B01
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 000000553830: 7C9810A0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000553834: BF870002
	v_lshlrev_b32_e32 v5, 2, v5                                // 000000553838: 300A0A82
	v_lshlrev_b32_e32 v2, 2, v2                                // 00000055383C: 30040482
	ds_bpermute_b32 v3, v2, v30                                // 000000553840: DACC0000 03001E02
	s_waitcnt lgkmcnt(0)                                       // 000000553848: BF89FC07
	v_add_f32_e32 v3, v30, v3                                  // 00000055384C: 0606071E
	ds_bpermute_b32 v4, v2, v31                                // 000000553850: DACC0000 04001F02
	ds_bpermute_b32 v2, v2, v27                                // 000000553858: DACC0000 02001B02
	ds_bpermute_b32 v6, v5, v3                                 // 000000553860: DACC0000 06000305
	v_cndmask_b32_e32 v8, v1, v8, vcc_lo                       // 000000553868: 02101101
	s_waitcnt lgkmcnt(2)                                       // 00000055386C: BF89FC27
	v_add_f32_e32 v4, v31, v4                                  // 000000553870: 0608091F
	s_waitcnt lgkmcnt(1)                                       // 000000553874: BF89FC17
	v_add_f32_e32 v2, v27, v2                                  // 000000553878: 0604051B
	s_waitcnt lgkmcnt(0)                                       // 00000055387C: BF89FC07
	v_add_f32_e32 v3, v3, v6                                   // 000000553880: 06060D03
	ds_bpermute_b32 v7, v5, v4                                 // 000000553884: DACC0000 07000405
	ds_bpermute_b32 v5, v5, v2                                 // 00000055388C: DACC0000 05000205
	v_lshlrev_b32_e32 v8, 2, v8                                // 000000553894: 30101082
	s_waitcnt lgkmcnt(0)                                       // 000000553898: BF89FC07
	v_add_f32_e32 v2, v2, v5                                   // 00000055389C: 06040B02
	ds_bpermute_b32 v5, v8, v3                                 // 0000005538A0: DACC0000 05000308
	s_waitcnt lgkmcnt(0)                                       // 0000005538A8: BF89FC07
	v_dual_add_f32 v3, v3, v5 :: v_dual_add_f32 v4, v4, v7     // 0000005538AC: C9080B03 03040F04
	ds_bpermute_b32 v7, v8, v2                                 // 0000005538B4: DACC0000 07000208
	ds_bpermute_b32 v6, v8, v4                                 // 0000005538BC: DACC0000 06000408
	v_xor_b32_e32 v8, 2, v1                                    // 0000005538C4: 3A100282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005538C8: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 0000005538CC: 7C9810A0
	v_cndmask_b32_e32 v8, v1, v8, vcc_lo                       // 0000005538D0: 02101101
	v_lshlrev_b32_e32 v8, 2, v8                                // 0000005538D4: 30101082
	s_waitcnt lgkmcnt(1)                                       // 0000005538D8: BF89FC17
	v_add_f32_e32 v2, v2, v7                                   // 0000005538DC: 06040F02
	s_waitcnt lgkmcnt(0)                                       // 0000005538E0: BF89FC07
	v_add_f32_e32 v4, v4, v6                                   // 0000005538E4: 06080D04
	ds_bpermute_b32 v5, v8, v3                                 // 0000005538E8: DACC0000 05000308
	ds_bpermute_b32 v7, v8, v2                                 // 0000005538F0: DACC0000 07000208
	ds_bpermute_b32 v6, v8, v4                                 // 0000005538F8: DACC0000 06000408
	v_xor_b32_e32 v8, 1, v1                                    // 000000553900: 3A100281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000553904: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 000000553908: 7C9810A0
	v_cndmask_b32_e32 v1, v1, v8, vcc_lo                       // 00000055390C: 02021101
	v_lshlrev_b32_e32 v8, 2, v1                                // 000000553910: 30100282
	s_waitcnt lgkmcnt(1)                                       // 000000553914: BF89FC17
	v_dual_add_f32 v1, v3, v5 :: v_dual_add_f32 v2, v2, v7     // 000000553918: C9080B03 01020F02
	s_waitcnt lgkmcnt(0)                                       // 000000553920: BF89FC07
	v_add_f32_e32 v3, v4, v6                                   // 000000553924: 06060D04
	ds_bpermute_b32 v4, v8, v1                                 // 000000553928: DACC0000 04000108
	ds_bpermute_b32 v5, v8, v2                                 // 000000553930: DACC0000 05000208
	ds_bpermute_b32 v6, v8, v3                                 // 000000553938: DACC0000 06000308
	v_cmpx_eq_u32_e32 0, v23                                   // 000000553940: 7D942E80
	s_cbranch_execz 12                                         // 000000553944: BFA5000C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xb78>
	v_mul_u32_u24_e32 v7, 12, v22                              // 000000553948: 160E2C8C
	s_waitcnt lgkmcnt(0)                                       // 00000055394C: BF89FC07
	v_dual_add_f32 v3, v3, v6 :: v_dual_add_f32 v2, v2, v5     // 000000553950: C9080D03 03020B02
	v_add_f32_e32 v1, v1, v4                                   // 000000553958: 06020901
	s_delay_alu instid0(VALU_DEP_3)                            // 00000055395C: BF870003
	v_or_b32_e32 v4, 0x400, v7                                 // 000000553960: 38080EFF 00000400
	ds_store_2addr_b32 v4, v1, v3 offset1:1                    // 000000553968: D8380100 00030104
	ds_store_b32 v7, v2 offset:1032                            // 000000553970: D8340408 00000207
	s_or_b32 exec_lo, exec_lo, s0                              // 000000553978: 8C7E007E
	.long 0xd4510000                                           // 00000055397C: D4510000
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 000000553980: 02001802
	v_cmp_gt_u32_e32 vcc_lo, 3, v0                             // 000000553984: 7C980083
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000553988: BF890007
	s_barrier                                                  // 00000055398C: BFBD0000
	buffer_gl0_inv                                             // 000000553990: E0AC0000 00000000
	s_and_b32 s0, vcc_lo, s0                                   // 000000553998: 8B00006A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000055399C: BF870009
	s_and_saveexec_b32 s1, s0                                  // 0000005539A0: BE812000
	s_cbranch_execz 51                                         // 0000005539A4: BFA50033 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xc74>
	v_add_nc_u32_e32 v7, 0x400, v21                            // 0000005539A8: 4A0E2AFF 00000400
	s_lshl_b64 s[0:1], s[2:3], 1                               // 0000005539B0: 84808102
	ds_load_2addr_b32 v[1:2], v7 offset1:3                     // 0000005539B4: D8DC0300 01000007
	ds_load_2addr_b32 v[3:4], v7 offset0:6 offset1:9           // 0000005539BC: D8DC0906 03000007
	ds_load_2addr_b32 v[5:6], v7 offset0:12 offset1:15         // 0000005539C4: D8DC0F0C 05000007
	s_waitcnt lgkmcnt(2)                                       // 0000005539CC: BF89FC27
	v_add_f32_e32 v1, 0, v1                                    // 0000005539D0: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005539D4: BF8700A1
	v_add_f32_e32 v1, v1, v2                                   // 0000005539D8: 06020501
	s_waitcnt lgkmcnt(1)                                       // 0000005539DC: BF89FC17
	v_add_f32_e32 v1, v1, v3                                   // 0000005539E0: 06020701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000005539E4: BF870131
	v_add_f32_e32 v3, v1, v4                                   // 0000005539E8: 06060901
	v_mad_u64_u32 v[1:2], null, s12, v0, 0                     // 0000005539EC: D6FE7C01 0202000C
	s_waitcnt lgkmcnt(0)                                       // 0000005539F4: BF89FC07
	v_add_f32_e32 v3, v3, v5                                   // 0000005539F8: 06060B03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000005539FC: BF8700D1
	v_add_f32_e32 v4, v3, v6                                   // 000000553A00: 06080D03
	ds_load_2addr_b32 v[7:8], v7 offset0:18 offset1:21         // 000000553A04: D8DC1512 07000007
	v_mad_u64_u32 v[2:3], null, s13, v0, v[2:3]                // 000000553A0C: D6FE7C02 040A000D
	s_waitcnt lgkmcnt(0)                                       // 000000553A14: BF89FC07
	v_add_f32_e32 v0, v4, v7                                   // 000000553A18: 06000F04
	v_add_f32_e32 v3, v0, v8                                   // 000000553A1C: 06061100
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000553A20: BF870113
	.long 0xd73c0000                                           // 000000553A24: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 000000553A28: 02020281
	v_bfe_u32 v2, v3, 16, 1                                    // 000000553A2C: D6100002 02052103
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000553A34: BF870092
	.long 0xd7006a00                                           // 000000553A38: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 000000553A3C: 02020008
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 000000553A40: D5207C01 01AA0209
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000553A48: BF870193
	v_add3_u32 v2, v3, v2, 0x7fff                              // 000000553A4C: D6550002 03FE0503 00007FFF
	.long 0xd7006a00                                           // 000000553A58: D7006A00
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 000000553A5C: 02000100
	s_delay_alu instid0(VALU_DEP_1)                            // 000000553A60: BF870001
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 000000553A64: D5207C01 01AA0201
	global_store_d16_hi_b16 v[0:1], v2, off                    // 000000553A6C: DC960000 007C0200
	s_endpgm                                                   // 000000553A74: BFB00000
		...

