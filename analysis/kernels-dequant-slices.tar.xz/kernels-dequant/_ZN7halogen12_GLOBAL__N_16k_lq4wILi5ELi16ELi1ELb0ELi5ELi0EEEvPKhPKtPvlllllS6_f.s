00000000008ccc00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 0000008CCC00: F4100100 F8000000
	v_dual_mov_b32 v4, 0 :: v_dual_and_b32 v15, 15, v0         // 0000008CCC08: CA240080 040E008F
	v_lshrrev_b32_e32 v1, 4, v0                                // 0000008CCC10: 32020084
	s_ashr_i32 s3, s2, 31                                      // 0000008CCC14: 86039F02
	v_mov_b32_e32 v16, 0                                       // 0000008CCC18: 7E200280
	s_lshl_b64 s[2:3], s[2:3], 4                               // 0000008CCC1C: 84828402
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000008CCC20: BF870009
	v_dual_mov_b32 v9, s3 :: v_dual_lshlrev_b32 v2, 2, v15     // 0000008CCC24: CA220003 09021E82
	v_lshlrev_b32_e32 v3, 2, v1                                // 0000008CCC2C: 30060282
	v_or_b32_e32 v8, s2, v1                                    // 0000008CCC30: 38100202
	.long 0x7f183880                                           // 0000008CCC34: 7F183880
	v_dual_mov_b32 v5, 0 :: v_dual_mov_b32 v6, 0               // 0000008CCC38: CA100080 05060080
	s_waitcnt lgkmcnt(0)                                       // 0000008CCC40: BF89FC07
	s_clause 0x1                                               // 0000008CCC44: BF850001
	global_load_b32 v7, v2, s[4:5]                             // 0000008CCC48: DC520000 07040002
	global_load_b32 v3, v3, s[4:5]                             // 0000008CCC50: DC520000 03040003
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[8:9]                  // 0000008CCC58: 7CA8100C
	s_add_u32 s14, s4, s14                                     // 0000008CCC5C: 800E0E04
	s_addc_u32 s15, s5, s15                                    // 0000008CCC60: 820F0F05
	s_lshr_b32 s2, s11, 31                                     // 0000008CCC64: 85029F0B
	v_mov_b32_e32 v25, 0                                       // 0000008CCC68: 7E320280
	s_add_u32 s20, s10, s2                                     // 0000008CCC6C: 8014020A
	v_cndmask_b32_e32 v10, 0, v8, vcc_lo                       // 0000008CCC70: 02141080
	v_cndmask_b32_e64 v14, 0, s3, vcc_lo                       // 0000008CCC74: D501000E 01A80680
	s_addc_u32 s21, s11, 0                                     // 0000008CCC7C: 8215800B
	s_ashr_i32 s22, s11, 31                                    // 0000008CCC80: 86169F0B
	s_ashr_i64 s[2:3], s[20:21], 1                             // 0000008CCC84: 86828114
	.long 0xd72c000d                                           // 0000008CCC88: D72C000D
	v_cndmask_b32_e32 v1, s19, v10, vcc_lo                     // 0000008CCC8C: 02021413
	v_mad_u64_u32 v[1:2], null, s18, v10, 0                    // 0000008CCC90: D6FE7C01 02021412
	.long 0xd72c0011                                           // 0000008CCC98: D72C0011
	v_cndmask_b32_e32 v0, v10, v3, vcc_lo                      // 0000008CCC9C: 0200070A
	.long 0xd72c0013                                           // 0000008CCCA0: D72C0013
	v_cndmask_b32_e32 v0, v14, v2, vcc_lo                      // 0000008CCCA4: 0200050E
	.long 0xd72c000e                                           // 0000008CCCA8: D72C000E
	v_cndmask_b32_e32 v1, s18, v14, vcc_lo                     // 0000008CCCAC: 02021C12
	s_lshr_b32 s19, s22, 27                                    // 0000008CCCB0: 85139B16
	s_waitcnt vmcnt(1)                                         // 0000008CCCB4: BF8907F7
	v_bfe_u32 v11, v7, 16, 1                                   // 0000008CCCB8: D610000B 02052107
	s_waitcnt vmcnt(0)                                         // 0000008CCCC0: BF8903F7
	v_bfe_u32 v18, v3, 16, 1                                   // 0000008CCCC4: D6100012 02052103
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008CCCCC: BF870002
	v_add3_u32 v7, v7, v11, 0x7fff                             // 0000008CCCD0: D6550007 03FE1707 00007FFF
	v_mad_u64_u32 v[10:11], null, v10, s2, s[14:15]            // 0000008CCCDC: D6FE7C0A 0038050A
	s_add_u32 s14, s10, s19                                    // 0000008CCCE4: 800E130A
	v_add3_u32 v3, v3, v18, 0x7fff                             // 0000008CCCE8: D6550003 03FE2503 00007FFF
	s_addc_u32 s15, s11, 0                                     // 0000008CCCF4: 820F800B
	.long 0x7e183987                                           // 0000008CCCF8: 7E183987
	s_lshr_b64 s[14:15], s[14:15], 5                           // 0000008CCCFC: 858E850E
	v_dual_mov_b32 v7, 0 :: v_dual_lshlrev_b32 v18, 2, v0      // 0000008CCD00: CA220080 07120082
	.long 0xd4440002                                           // 0000008CCD08: D4440002
	v_cndmask_b32_e32 v1, s14, v15, vcc_lo                     // 0000008CCD0C: 02021E0E
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008CCD10: BF870003
	v_and_or_b32 v3, 0xffff0000, v3, v12                       // 0000008CCD14: D6570003 043206FF FFFF0000
	v_add3_u32 v17, v19, v11, v17                              // 0000008CCD20: D6550011 04461713
	v_add3_u32 v0, v2, v14, v13                                // 0000008CCD28: D6550000 04361D02
	ds_store_b32 v18, v3                                       // 0000008CCD30: D8340000 00000312
	s_waitcnt lgkmcnt(0)                                       // 0000008CCD38: BF89FC07
	s_barrier                                                  // 0000008CCD3C: BFBD0000
	buffer_gl0_inv                                             // 0000008CCD40: E0AC0000 00000000
	s_and_saveexec_b32 s15, s2                                 // 0000008CCD48: BE8F2002
	s_cbranch_execz 26                                         // 0000008CCD4C: BFA5001A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x1b8>
	s_add_u32 s3, s4, s16                                      // 0000008CCD50: 80031004
	s_addc_u32 s18, s5, s17                                    // 0000008CCD54: 82121105
	v_lshlrev_b32_e32 v2, 1, v15                               // 0000008CCD58: 30041E81
	.long 0xd7000303                                           // 0000008CCD5C: D7000303
	v_cndmask_b32_e32 v1, s3, v1, vcc_lo                       // 0000008CCD60: 02020203
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008CCD64: BF8701A1
	v_add_co_ci_u32_e64 v4, null, s18, v0, s3                  // 0000008CCD68: D5207C04 000E0012
	v_lshlrev_b32_e32 v5, 4, v15                               // 0000008CCD70: 300A1E84
	.long 0xd7000302                                           // 0000008CCD74: D7000302
	v_cndmask_b32_e32 v1, v3, v2, vcc_lo                       // 0000008CCD78: 02020503
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008CCD7C: BF870191
	v_add_co_ci_u32_e64 v3, null, 0, v4, s3                    // 0000008CCD80: D5207C03 000E0880
	.long 0xd7000304                                           // 0000008CCD88: D7000304
	v_cndmask_b32_e32 v1, v10, v5, vcc_lo                      // 0000008CCD8C: 02020B0A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008CCD90: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v17, s3                   // 0000008CCD94: D5207C05 000E2280
	s_clause 0x1                                               // 0000008CCD9C: BF850001
	global_load_d16_b16 v2, v[2:3], off                        // 0000008CCDA0: DC820000 027C0002
	global_load_b128 v[4:7], v[4:5], off                       // 0000008CCDA8: DC5E0000 047C0004
	s_waitcnt vmcnt(1)                                         // 0000008CCDB0: BF8907F7
	v_cvt_f32_f16_e32 v25, v2                                  // 0000008CCDB4: 7E321702
	s_or_b32 exec_lo, exec_lo, s15                             // 0000008CCDB8: 8C7E0F7E
	v_dual_mov_b32 v18, 0 :: v_dual_mov_b32 v19, 0             // 0000008CCDBC: CA100080 12120080
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v21, 0             // 0000008CCDC4: CA100080 14140080
	s_and_saveexec_b32 s15, s2                                 // 0000008CCDCC: BE8F2002
	s_cbranch_execz 478                                        // 0000008CCDD0: BFA501DE <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x94c>
	s_mul_i32 s2, s11, 6                                       // 0000008CCDD4: 9602860B
	s_mul_hi_u32 s3, s10, 6                                    // 0000008CCDD8: 9683860A
	v_dual_mov_b32 v23, v15 :: v_dual_lshlrev_b32 v2, 1, v15   // 0000008CCDDC: CA22010F 17021E81
	s_add_i32 s20, s3, s2                                      // 0000008CCDE4: 81140203
	.long 0xd7000201                                           // 0000008CCDE8: D7000201
	v_cndmask_b32_e32 v1, s16, v1, vcc_lo                      // 0000008CCDEC: 02020210
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008CCDF0: BF8701A1
	v_add_co_ci_u32_e64 v0, null, s17, v0, s2                  // 0000008CCDF4: D5207C00 000A0011
	v_dual_mov_b32 v12, 0 :: v_dual_lshlrev_b32 v11, 5, v15    // 0000008CCDFC: CA220080 0C0A1E85
	.long 0xd7000201                                           // 0000008CCE04: D7000201
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 0000008CCE08: 02020501
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008CCE0C: BF8701A1
	v_add_co_ci_u32_e64 v0, null, 0, v0, s2                    // 0000008CCE10: D5207C00 000A0080
	v_lshl_or_b32 v22, v15, 4, 0x100                           // 0000008CCE18: D6560016 03FD090F 00000100
	.long 0xd7000201                                           // 0000008CCE24: D7000201
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 0000008CCE28: 02020204
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008CCE2C: BF8701A1
	v_add_co_ci_u32_e64 v0, null, s5, v0, s2                   // 0000008CCE30: D5207C00 000A0005
	v_dual_mov_b32 v21, v12 :: v_dual_mov_b32 v24, v25         // 0000008CCE38: CA10010C 15180119
	.long 0xd700020d                                           // 0000008CCE40: D700020D
	v_cndmask_b32_e32 v0, v1, v160, vcc_lo                     // 0000008CCE44: 02014101
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008CCE48: BF870001
	v_add_co_ci_u32_e64 v14, null, 0, v0, s2                   // 0000008CCE4C: D5207C0E 000A0080
	v_mov_b32_e32 v20, v12                                     // 0000008CCE54: 7E28030C
	v_mov_b32_e32 v19, v12                                     // 0000008CCE58: 7E26030C
	v_mov_b32_e32 v18, v12                                     // 0000008CCE5C: 7E24030C
	v_mov_b32_e32 v16, v12                                     // 0000008CCE60: 7E20030C
	s_lshl_b64 s[18:19], s[10:11], 2                           // 0000008CCE64: 8492820A
	s_mul_i32 s17, s10, 6                                      // 0000008CCE68: 9611860A
	s_mov_b32 s16, 0                                           // 0000008CCE6C: BE900080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 0000008CCE70: 8484810A
	s_branch 411                                               // 0000008CCE74: BFA0019B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x8e4>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000008CCE78: 8C7E0A7E
	v_and_b32_e32 v26, 0xff, v4                                // 0000008CCE7C: 363408FF 000000FF
	s_and_b32 s2, exec_lo, s2                                  // 0000008CCE84: 8B02027E
	v_add_nc_u32_e32 v22, 0x100, v22                           // 0000008CCE88: 4A2C2CFF 00000100
	s_or_b32 s16, s2, s16                                      // 0000008CCE90: 8C101002
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008CCE94: BF8700B2
	v_lshlrev_b32_e32 v26, 2, v26                              // 0000008CCE98: 30343482
	ds_load_b32 v42, v26                                       // 0000008CCE9C: D8D80000 2A00001A
	v_lshrrev_b32_e32 v26, 6, v4                               // 0000008CCEA4: 32340886
	v_and_b32_e32 v26, 0x3fc, v26                              // 0000008CCEA8: 363434FF 000003FC
	ds_load_b32 v43, v26                                       // 0000008CCEB0: D8D80000 2B00001A
	v_lshrrev_b32_e32 v26, 14, v4                              // 0000008CCEB8: 3234088E
	v_lshrrev_b32_e32 v4, 22, v4                               // 0000008CCEBC: 32080896
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008CCEC0: BF870112
	v_and_b32_e32 v26, 0x3fc, v26                              // 0000008CCEC4: 363434FF 000003FC
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000008CCECC: 360808FF 000003FC
	ds_load_b32 v44, v26                                       // 0000008CCED4: D8D80000 2C00001A
	ds_load_b32 v45, v4                                        // 0000008CCEDC: D8D80000 2D000004
	v_and_b32_e32 v4, 0xff, v5                                 // 0000008CCEE4: 36080AFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008CCEEC: BF8700B1
	v_lshlrev_b32_e32 v4, 2, v4                                // 0000008CCEF0: 30080882
	ds_load_b32 v46, v4                                        // 0000008CCEF4: D8D80000 2E000004
	v_lshrrev_b32_e32 v4, 6, v5                                // 0000008CCEFC: 32080A86
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000008CCF00: 360808FF 000003FC
	ds_load_b32 v47, v4                                        // 0000008CCF08: D8D80000 2F000004
	v_lshrrev_b32_e32 v4, 14, v5                               // 0000008CCF10: 32080A8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008CCF14: BF8700B1
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000008CCF18: 360808FF 000003FC
	ds_load_b32 v48, v4                                        // 0000008CCF20: D8D80000 30000004
	v_lshrrev_b32_e32 v4, 22, v5                               // 0000008CCF28: 32080A96
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000008CCF2C: 360808FF 000003FC
	ds_load_b32 v49, v4                                        // 0000008CCF34: D8D80000 31000004
	v_and_b32_e32 v4, 0xff, v6                                 // 0000008CCF3C: 36080CFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008CCF44: BF8700B1
	v_lshlrev_b32_e32 v4, 2, v4                                // 0000008CCF48: 30080882
	ds_load_b32 v50, v4                                        // 0000008CCF4C: D8D80000 32000004
	v_lshrrev_b32_e32 v4, 6, v6                                // 0000008CCF54: 32080C86
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000008CCF58: 360808FF 000003FC
	ds_load_b32 v51, v4                                        // 0000008CCF60: D8D80000 33000004
	v_lshrrev_b32_e32 v4, 14, v6                               // 0000008CCF68: 32080C8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008CCF6C: BF8700B1
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000008CCF70: 360808FF 000003FC
	ds_load_b32 v52, v4                                        // 0000008CCF78: D8D80000 34000004
	v_lshrrev_b32_e32 v4, 22, v6                               // 0000008CCF80: 32080C96
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000008CCF84: 360808FF 000003FC
	ds_load_b32 v53, v4                                        // 0000008CCF8C: D8D80000 35000004
	v_and_b32_e32 v4, 0xff, v7                                 // 0000008CCF94: 36080EFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008CCF9C: BF8700B1
	v_lshlrev_b32_e32 v4, 2, v4                                // 0000008CCFA0: 30080882
	ds_load_b32 v54, v4                                        // 0000008CCFA4: D8D80000 36000004
	v_lshrrev_b32_e32 v4, 6, v7                                // 0000008CCFAC: 32080E86
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000008CCFB0: 360808FF 000003FC
	ds_load_b32 v55, v4                                        // 0000008CCFB8: D8D80000 37000004
	v_lshrrev_b32_e32 v4, 14, v7                               // 0000008CCFC0: 32080E8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008CCFC4: BF8700B1
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000008CCFC8: 360808FF 000003FC
	ds_load_b32 v56, v4                                        // 0000008CCFD0: D8D80000 38000004
	v_lshrrev_b32_e32 v4, 22, v7                               // 0000008CCFD8: 32080E96
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000008CCFDC: 360808FF 000003FC
	ds_load_b32 v57, v4                                        // 0000008CCFE4: D8D80000 39000004
	.long 0xd73c0004                                           // 0000008CCFEC: D73C0004
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 0000008CCFF0: 02021681
	v_add_nc_u32_e32 v11, 0x200, v11                           // 0000008CCFF4: 4A1616FF 00000200
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008CCFFC: BF870092
	.long 0xd7000226                                           // 0000008CD000: D7000226
	v_cndmask_b32_e32 v1, s6, v4, vcc_lo                       // 0000008CD004: 02020806
	v_add_co_ci_u32_e64 v39, null, s7, v5, s2                  // 0000008CD008: D5207C27 000A0A07
	s_clause 0x3                                               // 0000008CD010: BF850003
	global_load_b128 v[4:7], v[38:39], off                     // 0000008CD014: DC5E0000 047C0026
	global_load_b128 v[26:29], v[38:39], off offset:16         // 0000008CD01C: DC5E0010 1A7C0026
	global_load_b128 v[30:33], v[38:39], off offset:32         // 0000008CD024: DC5E0020 1E7C0026
	global_load_b128 v[34:37], v[38:39], off offset:48         // 0000008CD02C: DC5E0030 227C0026
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 0000008CD034: BF890CF7
	v_dot2_f32_bf16 v4, v4, v42, 0                             // 0000008CD038: CC1A4004 1A025504
	s_waitcnt lgkmcnt(14)                                      // 0000008CD040: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008CD044: BF8700A1
	v_dot2_f32_bf16 v4, v5, v43, v4                            // 0000008CD048: CC1A4004 1C125705
	s_waitcnt lgkmcnt(13)                                      // 0000008CD050: BF89FCD7
	v_dot2_f32_bf16 v4, v6, v44, v4                            // 0000008CD054: CC1A4004 1C125906
	s_waitcnt lgkmcnt(12)                                      // 0000008CD05C: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008CD060: BF8700A1
	v_dot2_f32_bf16 v4, v7, v45, v4                            // 0000008CD064: CC1A4004 1C125B07
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 0000008CD06C: BF8908B7
	v_dot2_f32_bf16 v4, v26, v46, v4                           // 0000008CD070: CC1A4004 1C125D1A
	s_waitcnt lgkmcnt(10)                                      // 0000008CD078: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008CD07C: BF8700A1
	v_dot2_f32_bf16 v4, v27, v47, v4                           // 0000008CD080: CC1A4004 1C125F1B
	s_waitcnt lgkmcnt(9)                                       // 0000008CD088: BF89FC97
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 0000008CD08C: CC1A4004 1C12611C
	s_waitcnt lgkmcnt(8)                                       // 0000008CD094: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008CD098: BF8700A1
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 0000008CD09C: CC1A4004 1C12631D
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 0000008CD0A4: BF890477
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 0000008CD0A8: CC1A4004 1C12651E
	s_waitcnt lgkmcnt(6)                                       // 0000008CD0B0: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008CD0B4: BF8700A1
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 0000008CD0B8: CC1A4004 1C12671F
	s_waitcnt lgkmcnt(5)                                       // 0000008CD0C0: BF89FC57
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 0000008CD0C4: CC1A4004 1C126920
	s_waitcnt lgkmcnt(4)                                       // 0000008CD0CC: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008CD0D0: BF8700A1
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 0000008CD0D4: CC1A4004 1C126B21
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 0000008CD0DC: BF890037
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 0000008CD0E0: CC1A4004 1C126D22
	.long 0xd7000222                                           // 0000008CD0E8: D7000222
	v_cndmask_b32_e32 v0, v38, v4, vcc_lo                      // 0000008CD0EC: 02000926
	s_waitcnt lgkmcnt(2)                                       // 0000008CD0F0: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000008CD0F4: BF8701C2
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 0000008CD0F8: CC1A4004 1C126F23
	v_add_co_ci_u32_e64 v35, null, s5, v39, s2                 // 0000008CD100: D5207C23 000A4E05
	.long 0xd7000228                                           // 0000008CD108: D7000228
	v_cndmask_b32_e32 v0, v38, v18, vcc_lo                     // 0000008CD10C: 02002526
	s_waitcnt lgkmcnt(1)                                       // 0000008CD110: BF89FC17
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 0000008CD114: CC1A4004 1C127124
	v_add_co_ci_u32_e64 v41, null, s19, v39, s2                // 0000008CD11C: D5207C29 000A4E13
	s_waitcnt lgkmcnt(0)                                       // 0000008CD124: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008CD128: BF870092
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 0000008CD12C: CC1A4004 1C127325
	v_fmac_f32_e32 v21, v25, v4                                // 0000008CD134: 562A0919
	s_clause 0x3                                               // 0000008CD138: BF850003
	global_load_b128 v[4:7], v[34:35], off                     // 0000008CD13C: DC5E0000 047C0022
	global_load_b128 v[26:29], v[34:35], off offset:16         // 0000008CD144: DC5E0010 1A7C0022
	global_load_b128 v[30:33], v[34:35], off offset:32         // 0000008CD14C: DC5E0020 1E7C0022
	global_load_b128 v[34:37], v[34:35], off offset:48         // 0000008CD154: DC5E0030 227C0022
	s_waitcnt vmcnt(3)                                         // 0000008CD15C: BF890FF7
	v_dot2_f32_bf16 v4, v4, v42, 0                             // 0000008CD160: CC1A4004 1A025504
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008CD168: BF870091
	v_dot2_f32_bf16 v4, v5, v43, v4                            // 0000008CD16C: CC1A4004 1C125705
	v_dot2_f32_bf16 v4, v6, v44, v4                            // 0000008CD174: CC1A4004 1C125906
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008CD17C: BF8700A1
	v_dot2_f32_bf16 v4, v7, v45, v4                            // 0000008CD180: CC1A4004 1C125B07
	s_waitcnt vmcnt(2)                                         // 0000008CD188: BF890BF7
	v_dot2_f32_bf16 v4, v26, v46, v4                           // 0000008CD18C: CC1A4004 1C125D1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008CD194: BF870091
	v_dot2_f32_bf16 v4, v27, v47, v4                           // 0000008CD198: CC1A4004 1C125F1B
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 0000008CD1A0: CC1A4004 1C12611C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008CD1A8: BF8700A1
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 0000008CD1AC: CC1A4004 1C12631D
	s_waitcnt vmcnt(1)                                         // 0000008CD1B4: BF8907F7
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 0000008CD1B8: CC1A4004 1C12651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008CD1C0: BF870091
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 0000008CD1C4: CC1A4004 1C12671F
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 0000008CD1CC: CC1A4004 1C126920
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008CD1D4: BF8700A1
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 0000008CD1D8: CC1A4004 1C126B21
	s_waitcnt vmcnt(0)                                         // 0000008CD1E0: BF8903F7
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 0000008CD1E4: CC1A4004 1C126D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008CD1EC: BF870091
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 0000008CD1F0: CC1A4004 1C126F23
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 0000008CD1F8: CC1A4004 1C127124
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008CD200: BF870091
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 0000008CD204: CC1A4004 1C127325
	v_fmac_f32_e32 v20, v25, v4                                // 0000008CD20C: 56280919
	s_clause 0x3                                               // 0000008CD210: BF850003
	global_load_b128 v[4:7], v[40:41], off                     // 0000008CD214: DC5E0000 047C0028
	global_load_b128 v[26:29], v[40:41], off offset:16         // 0000008CD21C: DC5E0010 1A7C0028
	global_load_b128 v[30:33], v[40:41], off offset:32         // 0000008CD224: DC5E0020 1E7C0028
	global_load_b128 v[34:37], v[40:41], off offset:48         // 0000008CD22C: DC5E0030 227C0028
	s_waitcnt vmcnt(3)                                         // 0000008CD234: BF890FF7
	v_dot2_f32_bf16 v4, v4, v42, 0                             // 0000008CD238: CC1A4004 1A025504
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008CD240: BF870091
	v_dot2_f32_bf16 v4, v5, v43, v4                            // 0000008CD244: CC1A4004 1C125705
	v_dot2_f32_bf16 v4, v6, v44, v4                            // 0000008CD24C: CC1A4004 1C125906
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008CD254: BF8700A1
	v_dot2_f32_bf16 v4, v7, v45, v4                            // 0000008CD258: CC1A4004 1C125B07
	s_waitcnt vmcnt(2)                                         // 0000008CD260: BF890BF7
	v_dot2_f32_bf16 v4, v26, v46, v4                           // 0000008CD264: CC1A4004 1C125D1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008CD26C: BF870091
	v_dot2_f32_bf16 v4, v27, v47, v4                           // 0000008CD270: CC1A4004 1C125F1B
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 0000008CD278: CC1A4004 1C12611C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008CD280: BF8700A1
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 0000008CD284: CC1A4004 1C12631D
	s_waitcnt vmcnt(1)                                         // 0000008CD28C: BF8907F7
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 0000008CD290: CC1A4004 1C12651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008CD298: BF870091
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 0000008CD29C: CC1A4004 1C12671F
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 0000008CD2A4: CC1A4004 1C126920
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008CD2AC: BF8700A1
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 0000008CD2B0: CC1A4004 1C126B21
	s_waitcnt vmcnt(0)                                         // 0000008CD2B8: BF8903F7
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 0000008CD2BC: CC1A4004 1C126D22
	.long 0xd7000222                                           // 0000008CD2C4: D7000222
	v_cndmask_b32_e32 v0, v38, v17, vcc_lo                     // 0000008CD2C8: 02002326
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008CD2CC: BF870122
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 0000008CD2D0: CC1A4004 1C126F23
	v_add_co_ci_u32_e64 v35, null, s20, v39, s2                // 0000008CD2D8: D5207C23 000A4E14
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 0000008CD2E0: CC1A4004 1C127124
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008CD2E8: BF870091
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 0000008CD2EC: CC1A4004 1C127325
	v_fmac_f32_e32 v19, v25, v4                                // 0000008CD2F4: 56260919
	s_clause 0x3                                               // 0000008CD2F8: BF850003
	global_load_b128 v[4:7], v[34:35], off                     // 0000008CD2FC: DC5E0000 047C0022
	global_load_b128 v[26:29], v[34:35], off offset:16         // 0000008CD304: DC5E0010 1A7C0022
	global_load_b128 v[30:33], v[34:35], off offset:32         // 0000008CD30C: DC5E0020 1E7C0022
	global_load_b128 v[34:37], v[34:35], off offset:48         // 0000008CD314: DC5E0030 227C0022
	s_waitcnt vmcnt(3)                                         // 0000008CD31C: BF890FF7
	v_dot2_f32_bf16 v4, v4, v42, 0                             // 0000008CD320: CC1A4004 1A025504
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008CD328: BF870091
	v_dot2_f32_bf16 v4, v5, v43, v4                            // 0000008CD32C: CC1A4004 1C125705
	v_dot2_f32_bf16 v4, v6, v44, v4                            // 0000008CD334: CC1A4004 1C125906
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008CD33C: BF8700A1
	v_dot2_f32_bf16 v4, v7, v45, v4                            // 0000008CD340: CC1A4004 1C125B07
	s_waitcnt vmcnt(2)                                         // 0000008CD348: BF890BF7
	v_dot2_f32_bf16 v4, v26, v46, v4                           // 0000008CD34C: CC1A4004 1C125D1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008CD354: BF870091
	v_dot2_f32_bf16 v4, v27, v47, v4                           // 0000008CD358: CC1A4004 1C125F1B
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 0000008CD360: CC1A4004 1C12611C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008CD368: BF8700A1
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 0000008CD36C: CC1A4004 1C12631D
	s_waitcnt vmcnt(1)                                         // 0000008CD374: BF8907F7
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 0000008CD378: CC1A4004 1C12651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008CD380: BF870091
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 0000008CD384: CC1A4004 1C12671F
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 0000008CD38C: CC1A4004 1C126920
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008CD394: BF8700A1
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 0000008CD398: CC1A4004 1C126B21
	s_waitcnt vmcnt(0)                                         // 0000008CD3A0: BF8903F7
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 0000008CD3A4: CC1A4004 1C126D22
	.long 0xd7000222                                           // 0000008CD3AC: D7000222
	v_cndmask_b32_e32 v0, v40, v18, vcc_lo                     // 0000008CD3B0: 02002528
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000008CD3B4: BF8701B2
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 0000008CD3B8: CC1A4004 1C126F23
	v_add_co_ci_u32_e64 v35, null, s19, v41, s2                // 0000008CD3C0: D5207C23 000A5213
	.long 0xd700020d                                           // 0000008CD3C8: D700020D
	v_cndmask_b32_e32 v0, v13, v160, vcc_lo                    // 0000008CD3CC: 0201410D
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 0000008CD3D0: CC1A4004 1C127124
	v_add_co_ci_u32_e64 v14, null, 0, v14, s2                  // 0000008CD3D8: D5207C0E 000A1C80
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008CD3E0: BF870092
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 0000008CD3E4: CC1A4004 1C127325
	v_fmac_f32_e32 v18, v25, v4                                // 0000008CD3EC: 56240919
	s_clause 0x3                                               // 0000008CD3F0: BF850003
	global_load_b128 v[4:7], v[34:35], off                     // 0000008CD3F4: DC5E0000 047C0022
	global_load_b128 v[26:29], v[34:35], off offset:16         // 0000008CD3FC: DC5E0010 1A7C0022
	global_load_b128 v[30:33], v[34:35], off offset:32         // 0000008CD404: DC5E0020 1E7C0022
	global_load_b128 v[34:37], v[34:35], off offset:48         // 0000008CD40C: DC5E0030 227C0022
	s_waitcnt vmcnt(3)                                         // 0000008CD414: BF890FF7
	v_dot2_f32_bf16 v4, v4, v42, 0                             // 0000008CD418: CC1A4004 1A025504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008CD420: BF870121
	v_dot2_f32_bf16 v4, v5, v43, v4                            // 0000008CD424: CC1A4004 1C125705
	v_mov_b32_e32 v5, v1                                       // 0000008CD42C: 7E0A0301
	v_dot2_f32_bf16 v4, v6, v44, v4                            // 0000008CD430: CC1A4004 1C125906
	v_mov_b32_e32 v6, v2                                       // 0000008CD438: 7E0C0302
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000008CD43C: BF870132
	v_dot2_f32_bf16 v4, v7, v45, v4                            // 0000008CD440: CC1A4004 1C125B07
	v_mov_b32_e32 v7, v3                                       // 0000008CD448: 7E0E0303
	s_waitcnt vmcnt(2)                                         // 0000008CD44C: BF890BF7
	v_dot2_f32_bf16 v4, v26, v46, v4                           // 0000008CD450: CC1A4004 1C125D1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008CD458: BF870091
	v_dot2_f32_bf16 v4, v27, v47, v4                           // 0000008CD45C: CC1A4004 1C125F1B
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 0000008CD464: CC1A4004 1C12611C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008CD46C: BF8700A1
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 0000008CD470: CC1A4004 1C12631D
	s_waitcnt vmcnt(1)                                         // 0000008CD478: BF8907F7
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 0000008CD47C: CC1A4004 1C12651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008CD484: BF870091
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 0000008CD488: CC1A4004 1C12671F
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 0000008CD490: CC1A4004 1C126920
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008CD498: BF8700A1
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 0000008CD49C: CC1A4004 1C126B21
	s_waitcnt vmcnt(0)                                         // 0000008CD4A4: BF8903F7
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 0000008CD4A8: CC1A4004 1C126D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008CD4B0: BF870091
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 0000008CD4B4: CC1A4004 1C126F23
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 0000008CD4BC: CC1A4004 1C127124
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008CD4C4: BF870091
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 0000008CD4C8: CC1A4004 1C127325
	v_fmac_f32_e32 v16, v25, v4                                // 0000008CD4D0: 56200919
	v_mov_b32_e32 v4, v0                                       // 0000008CD4D4: 7E080300
	v_mov_b32_e32 v25, v24                                     // 0000008CD4D8: 7E320318
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 0000008CD4DC: 917E107E
	s_cbranch_execz 25                                         // 0000008CD4E0: BFA50019 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x948>
	s_waitcnt vmcnt(0)                                         // 0000008CD4E4: BF8903F7
	v_dual_mov_b32 v0, v4 :: v_dual_add_nc_u32 v23, 16, v23    // 0000008CD4E8: CA200104 00162E90
	v_dual_mov_b32 v1, v5 :: v_dual_mov_b32 v2, v6             // 0000008CD4F0: CA100105 01020106
	v_mov_b32_e32 v3, v7                                       // 0000008CD4F8: 7E060307
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008CD4FC: BF870003
	.long 0xd4430002                                           // 0000008CD500: D4430002
	v_cndmask_b32_e32 v1, s14, v23, vcc_lo                     // 0000008CD504: 02022E0E
	s_mov_b32 s10, exec_lo                                     // 0000008CD508: BE8A007E
	.long 0xd4c4007e                                           // 0000008CD50C: D4C4007E
	v_cndmask_b32_e32 v1, s14, v23, vcc_lo                     // 0000008CD510: 02022E0E
	s_cbranch_execz 65112                                      // 0000008CD514: BFA5FE58 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x278>
	.long 0xd7000300                                           // 0000008CD518: D7000300
	v_cndmask_b32_e32 v1, v10, v22, vcc_lo                     // 0000008CD51C: 02022D0A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008CD520: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v17, s3                   // 0000008CD524: D5207C01 000E2280
	global_load_d16_b16 v24, v[13:14], off                     // 0000008CD52C: DC820000 187C000D
	global_load_b128 v[0:3], v[0:1], off                       // 0000008CD534: DC5E0000 007C0000
	s_waitcnt vmcnt(1)                                         // 0000008CD53C: BF8907F7
	v_cvt_f32_f16_e32 v24, v24                                 // 0000008CD540: 7E301718
	s_branch 65100                                             // 0000008CD544: BFA0FE4C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x278>
	s_or_b32 exec_lo, exec_lo, s16                             // 0000008CD548: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008CD54C: BF8700A9
	s_or_b32 exec_lo, exec_lo, s15                             // 0000008CD550: 8C7E0F7E
	.long 0xd71f0000                                           // 0000008CD554: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000008CD558: 020100C1
	v_xor_b32_e32 v1, 8, v0                                    // 0000008CD55C: 3A020088
	s_waitcnt vmcnt(0)                                         // 0000008CD560: BF8903F7
	v_xor_b32_e32 v6, 4, v0                                    // 0000008CD564: 3A0C0084
	v_xor_b32_e32 v13, 2, v0                                   // 0000008CD568: 3A1A0082
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008CD56C: BF870093
	.long 0xd44c0002                                           // 0000008CD570: D44C0002
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 0000008CD574: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s2                           // 0000008CD578: D5010001 000A0300
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008CD580: BF870114
	.long 0xd44c0002                                           // 0000008CD584: D44C0002
	v_cndmask_b32_e32 v1, 32, v6, vcc_lo                       // 0000008CD588: 02020CA0
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000008CD58C: 30020282
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008CD590: BF870002
	v_cndmask_b32_e64 v6, v0, v6, s2                           // 0000008CD594: D5010006 000A0D00
	.long 0xd44c0002                                           // 0000008CD59C: D44C0002
	v_cndmask_b32_e32 v1, 32, v13, vcc_lo                      // 0000008CD5A0: 02021AA0
	ds_bpermute_b32 v2, v1, v21                                // 0000008CD5A4: DACC0000 02001501
	v_cndmask_b32_e64 v13, v0, v13, s2                         // 0000008CD5AC: D501000D 000A1B00
	s_waitcnt lgkmcnt(0)                                       // 0000008CD5B4: BF89FC07
	v_add_f32_e32 v2, v21, v2                                  // 0000008CD5B8: 06040515
	ds_bpermute_b32 v3, v1, v20                                // 0000008CD5BC: DACC0000 03001401
	ds_bpermute_b32 v4, v1, v19                                // 0000008CD5C4: DACC0000 04001301
	ds_bpermute_b32 v5, v1, v18                                // 0000008CD5CC: DACC0000 05001201
	ds_bpermute_b32 v1, v1, v16                                // 0000008CD5D4: DACC0000 01001001
	s_waitcnt lgkmcnt(3)                                       // 0000008CD5DC: BF89FC37
	v_dual_add_f32 v3, v20, v3 :: v_dual_lshlrev_b32 v6, 2, v6 // 0000008CD5E0: C9220714 03060C82
	ds_bpermute_b32 v7, v6, v2                                 // 0000008CD5E8: DACC0000 07000206
	s_waitcnt lgkmcnt(2)                                       // 0000008CD5F0: BF89FC27
	v_dual_add_f32 v4, v19, v4 :: v_dual_add_f32 v5, v18, v5   // 0000008CD5F4: C9080913 04040B12
	s_waitcnt lgkmcnt(1)                                       // 0000008CD5FC: BF89FC17
	v_add_f32_e32 v1, v16, v1                                  // 0000008CD600: 06020310
	ds_bpermute_b32 v10, v6, v3                                // 0000008CD604: DACC0000 0A000306
	ds_bpermute_b32 v11, v6, v4                                // 0000008CD60C: DACC0000 0B000406
	ds_bpermute_b32 v12, v6, v5                                // 0000008CD614: DACC0000 0C000506
	s_waitcnt lgkmcnt(3)                                       // 0000008CD61C: BF89FC37
	v_dual_add_f32 v2, v2, v7 :: v_dual_lshlrev_b32 v13, 2, v13// 0000008CD620: C9220F02 020C1A82
	ds_bpermute_b32 v6, v6, v1                                 // 0000008CD628: DACC0000 06000106
	s_waitcnt lgkmcnt(3)                                       // 0000008CD630: BF89FC37
	v_add_f32_e32 v3, v3, v10                                  // 0000008CD634: 06061503
	s_waitcnt lgkmcnt(1)                                       // 0000008CD638: BF89FC17
	v_dual_add_f32 v7, v4, v11 :: v_dual_add_f32 v10, v5, v12  // 0000008CD63C: C9081704 070A1905
	v_xor_b32_e32 v5, 1, v0                                    // 0000008CD644: 3A0A0081
	ds_bpermute_b32 v12, v13, v10                              // 0000008CD648: DACC0000 0C000A0D
	.long 0xd44c0002                                           // 0000008CD650: D44C0002
	v_cndmask_b32_e32 v1, 32, v5, vcc_lo                       // 0000008CD654: 02020AA0
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008CD658: BF870001
	v_cndmask_b32_e64 v0, v0, v5, s2                           // 0000008CD65C: D5010000 000A0B00
	.long 0xd44a0002                                           // 0000008CD664: D44A0002
	v_cndmask_b32_e32 v1, 0, v15, vcc_lo                       // 0000008CD668: 02021E80
	s_waitcnt lgkmcnt(1)                                       // 0000008CD66C: BF89FC17
	v_add_f32_e32 v6, v1, v6                                   // 0000008CD670: 060C0D01
	ds_bpermute_b32 v1, v13, v2                                // 0000008CD674: DACC0000 0100020D
	ds_bpermute_b32 v11, v13, v7                               // 0000008CD67C: DACC0000 0B00070D
	v_lshlrev_b32_e32 v14, 2, v0                               // 0000008CD684: 301C0082
	ds_bpermute_b32 v4, v13, v3                                // 0000008CD688: DACC0000 0400030D
	ds_bpermute_b32 v13, v13, v6                               // 0000008CD690: DACC0000 0D00060D
	s_and_b32 s2, s2, vcc_lo                                   // 0000008CD698: 8B026A02
	s_waitcnt lgkmcnt(2)                                       // 0000008CD69C: BF89FC27
	v_dual_add_f32 v5, v2, v1 :: v_dual_add_f32 v0, v7, v11    // 0000008CD6A0: C9080302 05001707
	v_add_f32_e32 v1, v10, v12                                 // 0000008CD6A8: 0602190A
	s_waitcnt lgkmcnt(1)                                       // 0000008CD6AC: BF89FC17
	v_add_f32_e32 v4, v3, v4                                   // 0000008CD6B0: 06080903
	s_waitcnt lgkmcnt(0)                                       // 0000008CD6B4: BF89FC07
	v_add_f32_e32 v10, v6, v13                                 // 0000008CD6B8: 06141B06
	ds_bpermute_b32 v6, v14, v5                                // 0000008CD6BC: DACC0000 0600050E
	ds_bpermute_b32 v2, v14, v0                                // 0000008CD6C4: DACC0000 0200000E
	ds_bpermute_b32 v3, v14, v1                                // 0000008CD6CC: DACC0000 0300010E
	ds_bpermute_b32 v7, v14, v4                                // 0000008CD6D4: DACC0000 0700040E
	ds_bpermute_b32 v11, v14, v10                              // 0000008CD6DC: DACC0000 0B000A0E
	s_and_saveexec_b32 s3, s2                                  // 0000008CD6E4: BE832002
	s_cbranch_execz 112                                        // 0000008CD6E8: BFA50070 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0xcac>
	v_ashrrev_i32_e32 v12, 31, v9                              // 0000008CD6EC: 3418129F
	s_load_b64 s[2:3], s[0:1], 0x40                            // 0000008CD6F0: F4040080 F8000040
	s_waitcnt lgkmcnt(0)                                       // 0000008CD6F8: BF89FC07
	v_dual_add_f32 v10, v10, v11 :: v_dual_mov_b32 v13, s9     // 0000008CD6FC: C910170A 0A0C0009
	s_lshr_b32 s0, s13, 31                                     // 0000008CD704: 85009F0D
	v_lshrrev_b32_e32 v12, 23, v12                             // 0000008CD708: 32181897
	s_add_u32 s4, s12, s0                                      // 0000008CD70C: 8004000C
	.long 0x7f1e3880                                           // 0000008CD710: 7F1E3880
	s_addc_u32 s5, s13, 0                                      // 0000008CD714: 8205800D
	v_add_f32_e32 v7, v4, v7                                   // 0000008CD718: 060E0F04
	.long 0xd7006a0c                                           // 0000008CD71C: D7006A0C
	v_cndmask_b32_e32 v1, v8, v12, vcc_lo                      // 0000008CD720: 02021908
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008CD724: BF870191
	v_add_co_ci_u32_e64 v11, null, 0, v9, vcc_lo               // 0000008CD728: D5207C0B 01AA1280
	.long 0x7e1e3987                                           // 0000008CD730: 7E1E3987
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008CD734: BF870093
	v_dual_add_f32 v3, v1, v3 :: v_dual_and_b32 v12, 0xfffffe00, v12// 0000008CD738: C9240701 030C18FF FFFFFE00
	.long 0xd7016a08                                           // 0000008CD744: D7016A08
	v_cndmask_b32_e32 v1, v8, v12, vcc_lo                      // 0000008CD748: 02021908
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008CD74C: BF870111
	v_sub_co_ci_u32_e64 v9, null, v9, v11, vcc_lo              // 0000008CD750: D5217C09 01AA1709
	.long 0xd7000004                                           // 0000008CD758: D7000004
	v_cndmask_b32_e32 v1, 0xffffff00, v8, vcc_lo               // 0000008CD75C: 020210FF FFFFFF00
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008CD764: BF870002
	v_cmp_gt_i64_e32 vcc_lo, 0x100, v[8:9]                     // 0000008CD768: 7CA810FF 00000100
	v_add_f32_e32 v6, v5, v6                                   // 0000008CD770: 060C0D05
	v_add_co_ci_u32_e64 v5, null, -1, v9, s0                   // 0000008CD774: D5207C05 000212C1
	v_mov_b32_e32 v14, s8                                      // 0000008CD77C: 7E1C0208
	s_ashr_i64 s[0:1], s[4:5], 1                               // 0000008CD780: 86808104
	v_dual_cndmask_b32 v13, s3, v13 :: v_dual_cndmask_b32 v4, v4, v8// 0000008CD784: CA521A03 0D041104
	.long 0x7e103986                                           // 0000008CD78C: 7E103986
	.long 0x7f10398f                                           // 0000008CD790: 7F10398F
	v_cndmask_b32_e32 v5, v5, v9, vcc_lo                       // 0000008CD794: 020A1305
	v_dual_cndmask_b32 v9, s2, v14 :: v_dual_and_b32 v14, 1, v15// 0000008CD798: CA641C02 090E1E81
	s_and_b32 s2, s4, -2                                       // 0000008CD7A0: 8B02C204
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008CD7A4: BF870193
	v_and_b32_e32 v8, 1, v8                                    // 0000008CD7A8: 36101081
	.long 0xd73c0004                                           // 0000008CD7AC: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 0000008CD7B0: 02020881
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008CD7B4: BF870093
	.long 0xd7006a09                                           // 0000008CD7B8: D7006A09
	v_cndmask_b32_e32 v1, v9, v12, vcc_lo                      // 0000008CD7BC: 02021909
	v_add_co_ci_u32_e64 v11, null, v13, v11, vcc_lo            // 0000008CD7C0: D5207C0B 01AA170D
	.long 0x7e1e3983                                           // 0000008CD7C8: 7E1E3983
	v_add_f32_e32 v2, v0, v2                                   // 0000008CD7CC: 06040500
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008CD7D0: BF870094
	.long 0xd7006a04                                           // 0000008CD7D4: D7006A04
	v_cndmask_b32_e32 v1, v9, v4, vcc_lo                       // 0000008CD7D8: 02020909
	v_add_co_ci_u32_e64 v5, null, v11, v5, vcc_lo              // 0000008CD7DC: D5207C05 01AA0B0B
	.long 0x7f00398f                                           // 0000008CD7E4: 7F00398F
	v_and_b32_e32 v13, 1, v15                                  // 0000008CD7E8: 361A1E81
	.long 0x7e003982                                           // 0000008CD7EC: 7E003982
	v_add3_u32 v11, v7, v14, 0x7fff                            // 0000008CD7F0: D655000B 03FE1D07 00007FFF
	v_add3_u32 v12, v6, v8, 0x7fff                             // 0000008CD7FC: D655000C 03FE1106 00007FFF
	.long 0xd7006a06                                           // 0000008CD808: D7006A06
	v_cndmask_b32_e32 v0, v4, v2, vcc_lo                       // 0000008CD80C: 02000504
	s_delay_alu instid0(VALU_DEP_4)                            // 0000008CD810: BF870004
	v_and_b32_e32 v14, 1, v0                                   // 0000008CD814: 361C0081
	v_mad_u64_u32 v[0:1], null, s0, 6, v[4:5]                  // 0000008CD818: D6FE7C00 04110C00
	s_lshl_b64 s[2:3], s[0:1], 2                               // 0000008CD820: 84828200
	v_add_co_ci_u32_e64 v7, null, s5, v5, vcc_lo               // 0000008CD824: D5207C07 01AA0A05
	.long 0xd7006a08                                           // 0000008CD82C: D7006A08
	v_cndmask_b32_e32 v0, v4, v2, vcc_lo                       // 0000008CD830: 02000504
	v_bfe_u32 v15, v10, 16, 1                                  // 0000008CD834: D610000F 0205210A
	v_add_co_ci_u32_e64 v9, null, s3, v5, vcc_lo               // 0000008CD83C: D5207C09 01AA0A03
	v_add3_u32 v14, v2, v14, 0x7fff                            // 0000008CD844: D655000E 03FE1D02 00007FFF
	v_mad_u64_u32 v[1:2], null, s1, 6, v[1:2]                  // 0000008CD850: D6FE7C01 04050C01
	.long 0xd7006a02                                           // 0000008CD858: D7006A02
	v_cndmask_b32_e32 v0, v8, v2, vcc_lo                       // 0000008CD85C: 02000508
	v_add3_u32 v13, v3, v13, 0x7fff                            // 0000008CD860: D655000D 03FE1B03 00007FFF
	v_add3_u32 v10, v10, v15, 0x7fff                           // 0000008CD86C: D655000A 03FE1F0A 00007FFF
	v_add_co_ci_u32_e64 v3, null, s3, v9, vcc_lo               // 0000008CD878: D5207C03 01AA1203
	s_clause 0x4                                               // 0000008CD880: BF850004
	global_store_d16_hi_b16 v[4:5], v12, off                   // 0000008CD884: DC960000 007C0C04
	global_store_d16_hi_b16 v[6:7], v11, off                   // 0000008CD88C: DC960000 007C0B06
	global_store_d16_hi_b16 v[8:9], v14, off                   // 0000008CD894: DC960000 007C0E08
	global_store_d16_hi_b16 v[0:1], v13, off                   // 0000008CD89C: DC960000 007C0D00
	global_store_d16_hi_b16 v[2:3], v10, off                   // 0000008CD8A4: DC960000 007C0A02
	s_endpgm                                                   // 0000008CD8AC: BFB00000
		...

