000000000057d400 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 00000057D400: F4100100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 00000057D408: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 00000057D40C: 32040082
	s_lshl_b64 s[0:1], s[2:3], 3                               // 00000057D410: 84808302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000057D414: BF8701A9
	v_dual_mov_b32 v24, s1 :: v_dual_and_b32 v1, 15, v0        // 00000057D418: CA240001 1800008F
	v_and_b32_e32 v30, 31, v0                                  // 00000057D420: 363C009F
	v_and_b32_e32 v2, 60, v2                                   // 00000057D424: 360404BC
	v_lshlrev_b32_e32 v7, 2, v0                                // 00000057D428: 300E0082
	s_delay_alu instid0(VALU_DEP_4)                            // 00000057D42C: BF870004
	v_lshlrev_b32_e32 v1, 2, v1                                // 00000057D430: 30020282
	.long 0x7f0c3880                                           // 00000057D434: 7F0C3880
	s_waitcnt lgkmcnt(0)                                       // 00000057D438: BF89FC07
	s_clause 0x1                                               // 00000057D43C: BF850001
	global_load_b32 v3, v1, s[4:5]                             // 00000057D440: DC520000 03040001
	global_load_b32 v4, v2, s[4:5]                             // 00000057D448: DC520000 04040002
	v_lshrrev_b32_e32 v1, 5, v0                                // 00000057D450: 32020085
	s_add_u32 s22, s4, s16                                     // 00000057D454: 80161004
	s_addc_u32 s23, s5, s17                                    // 00000057D458: 82171105
	s_ashr_i32 s2, s11, 31                                     // 00000057D45C: 86029F0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000057D460: BF8704A1
	v_or_b32_e32 v23, s0, v1                                   // 00000057D464: 382E0200
	s_lshr_b32 s2, s2, 27                                      // 00000057D468: 85029B02
	s_add_u32 s2, s10, s2                                      // 00000057D46C: 8002020A
	s_addc_u32 s3, s11, 0                                      // 00000057D470: 8203800B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000057D474: BF8704A1
	.long 0xd4540000                                           // 00000057D478: D4540000
	v_cndmask_b32_e32 v1, s12, v23, vcc_lo                     // 00000057D47C: 02022E0C
	s_lshr_b64 s[20:21], s[2:3], 5                             // 00000057D480: 85948502
	s_cmpk_lt_i32 s20, 0x101                                   // 00000057D484: B3940101
	.long 0xd4440002                                           // 00000057D488: D4440002
	v_cndmask_b32_e32 v1, s20, v30, vcc_lo                     // 00000057D48C: 02023C14
	v_cndmask_b32_e64 v2, 0, v23, s0                           // 00000057D490: D5010002 00022E80
	v_cndmask_b32_e64 v5, 0, s1, s0                            // 00000057D498: D5010005 00000280
	s_cselect_b32 s1, -1, 0                                    // 00000057D4A0: 980180C1
	s_cmpk_gt_i32 s20, 0x100                                   // 00000057D4A4: B2940100
	s_delay_alu instid0(VALU_DEP_2)                            // 00000057D4A8: BF870002
	.long 0xd72c0008                                           // 00000057D4AC: D72C0008
	v_cndmask_b32_e32 v1, s19, v2, vcc_lo                      // 00000057D4B0: 02020413
	v_mad_u64_u32 v[0:1], null, s18, v2, 0                     // 00000057D4B4: D6FE7C00 02020412
	s_waitcnt vmcnt(1)                                         // 00000057D4BC: BF8907F7
	v_bfe_u32 v9, v3, 16, 1                                    // 00000057D4C0: D6100009 02052103
	s_waitcnt vmcnt(0)                                         // 00000057D4C8: BF8903F7
	v_bfe_u32 v10, v4, 16, 1                                   // 00000057D4CC: D610000A 02052104
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000057D4D4: BF8701A2
	v_add3_u32 v3, v3, v9, 0x7fff                              // 00000057D4D8: D6550003 03FE1303 00007FFF
	.long 0xd72c0009                                           // 00000057D4E4: D72C0009
	v_cndmask_b32_e32 v1, s18, v5, vcc_lo                      // 00000057D4E8: 02020A12
	v_add3_u32 v4, v4, v10, 0x7fff                             // 00000057D4EC: D6550004 03FE1504 00007FFF
	s_cselect_b32 s18, -1, 0                                   // 00000057D4F8: 981280C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000057D4FC: BF870239
	s_and_b32 vcc_lo, exec_lo, s18                             // 00000057D500: 8B6A127E
	.long 0x7e0c3983                                           // 00000057D504: 7E0C3983
	.long 0xd7000303                                           // 00000057D508: D7000303
	v_cndmask_b32_e32 v1, s22, v0, vcc_lo                      // 00000057D50C: 02020016
	v_add3_u32 v1, v1, v9, v8                                  // 00000057D510: D6550001 04221301
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000057D518: BF870113
	v_and_or_b32 v6, 0xffff0000, v4, v6                        // 00000057D51C: D6570006 041A08FF FFFF0000
	v_add_co_ci_u32_e64 v4, null, s23, v1, s3                  // 00000057D528: D5207C04 000E0217
	ds_store_b32 v7, v6                                        // 00000057D530: D8340000 00000607
	s_waitcnt lgkmcnt(0)                                       // 00000057D538: BF89FC07
	s_barrier                                                  // 00000057D53C: BFBD0000
	buffer_gl0_inv                                             // 00000057D540: E0AC0000 00000000
	s_cbranch_vccnz 146                                        // 00000057D548: BFA40092 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x394>
	v_dual_mov_b32 v8, 0 :: v_dual_mov_b32 v7, 0               // 00000057D54C: CA100080 08060080
	s_and_saveexec_b32 s3, s2                                  // 00000057D554: BE832002
	s_cbranch_execz 10                                         // 00000057D558: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x184>
	v_lshlrev_b32_e32 v6, 1, v30                               // 00000057D55C: 300C3C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057D560: BF870091
	.long 0xd7006a06                                           // 00000057D564: D7006A06
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000057D568: 02020D03
	v_add_co_ci_u32_e64 v7, null, 0, v4, vcc_lo                // 00000057D56C: D5207C07 01AA0880
	global_load_d16_b16 v6, v[6:7], off                        // 00000057D574: DC820000 067C0006
	s_waitcnt vmcnt(0)                                         // 00000057D57C: BF8903F7
	v_cvt_f32_f16_e32 v7, v6                                   // 00000057D580: 7E0E1706
	s_or_b32 exec_lo, exec_lo, s3                              // 00000057D584: 8C7E037E
	v_or_b32_e32 v6, 32, v30                                   // 00000057D588: 380C3CA0
	s_mov_b32 s2, exec_lo                                      // 00000057D58C: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000057D590: BF870001
	.long 0xd4c4007e                                           // 00000057D594: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 00000057D598: 02020C14
	s_cbranch_execz 10                                         // 00000057D59C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x1c8>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000057D5A0: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057D5A4: BF870091
	.long 0xd7006a08                                           // 00000057D5A8: D7006A08
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000057D5AC: 02020D03
	v_add_co_ci_u32_e64 v9, null, 0, v4, vcc_lo                // 00000057D5B0: D5207C09 01AA0880
	global_load_d16_b16 v6, v[8:9], off                        // 00000057D5B8: DC820000 067C0008
	s_waitcnt vmcnt(0)                                         // 00000057D5C0: BF8903F7
	v_cvt_f32_f16_e32 v8, v6                                   // 00000057D5C4: 7E101706
	s_or_b32 exec_lo, exec_lo, s2                              // 00000057D5C8: 8C7E027E
	v_or_b32_e32 v6, 64, v30                                   // 00000057D5CC: 380C3CC0
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v9, 0              // 00000057D5D0: CA100080 0A080080
	s_mov_b32 s2, exec_lo                                      // 00000057D5D8: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000057D5DC: BF870002
	.long 0xd4c4007e                                           // 00000057D5E0: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 00000057D5E4: 02020C14
	s_cbranch_execz 10                                         // 00000057D5E8: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x214>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000057D5EC: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057D5F0: BF870091
	.long 0xd7006a0b                                           // 00000057D5F4: D7006A0B
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000057D5F8: 02020D03
	v_add_co_ci_u32_e64 v12, null, 0, v4, vcc_lo               // 00000057D5FC: D5207C0C 01AA0880
	global_load_d16_b16 v6, v[11:12], off                      // 00000057D604: DC820000 067C000B
	s_waitcnt vmcnt(0)                                         // 00000057D60C: BF8903F7
	v_cvt_f32_f16_e32 v9, v6                                   // 00000057D610: 7E121706
	s_or_b32 exec_lo, exec_lo, s2                              // 00000057D614: 8C7E027E
	v_or_b32_e32 v6, 0x60, v30                                 // 00000057D618: 380C3CFF 00000060
	s_mov_b32 s2, exec_lo                                      // 00000057D620: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000057D624: BF870001
	.long 0xd4c4007e                                           // 00000057D628: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 00000057D62C: 02020C14
	s_cbranch_execz 10                                         // 00000057D630: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x25c>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000057D634: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057D638: BF870091
	.long 0xd7006a0a                                           // 00000057D63C: D7006A0A
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000057D640: 02020D03
	v_add_co_ci_u32_e64 v11, null, 0, v4, vcc_lo               // 00000057D644: D5207C0B 01AA0880
	global_load_d16_b16 v6, v[10:11], off                      // 00000057D64C: DC820000 067C000A
	s_waitcnt vmcnt(0)                                         // 00000057D654: BF8903F7
	v_cvt_f32_f16_e32 v10, v6                                  // 00000057D658: 7E141706
	s_or_b32 exec_lo, exec_lo, s2                              // 00000057D65C: 8C7E027E
	v_or_b32_e32 v6, 0x80, v30                                 // 00000057D660: 380C3CFF 00000080
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v11, 0             // 00000057D668: CA100080 0C0A0080
	s_mov_b32 s2, exec_lo                                      // 00000057D670: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000057D674: BF870002
	.long 0xd4c4007e                                           // 00000057D678: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 00000057D67C: 02020C14
	s_cbranch_execz 10                                         // 00000057D680: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x2ac>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000057D684: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057D688: BF870091
	.long 0xd7006a0d                                           // 00000057D68C: D7006A0D
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000057D690: 02020D03
	v_add_co_ci_u32_e64 v14, null, 0, v4, vcc_lo               // 00000057D694: D5207C0E 01AA0880
	global_load_d16_b16 v6, v[13:14], off                      // 00000057D69C: DC820000 067C000D
	s_waitcnt vmcnt(0)                                         // 00000057D6A4: BF8903F7
	v_cvt_f32_f16_e32 v11, v6                                  // 00000057D6A8: 7E161706
	s_or_b32 exec_lo, exec_lo, s2                              // 00000057D6AC: 8C7E027E
	v_or_b32_e32 v6, 0xa0, v30                                 // 00000057D6B0: 380C3CFF 000000A0
	s_mov_b32 s2, exec_lo                                      // 00000057D6B8: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000057D6BC: BF870001
	.long 0xd4c4007e                                           // 00000057D6C0: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 00000057D6C4: 02020C14
	s_cbranch_execz 10                                         // 00000057D6C8: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x2f4>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000057D6CC: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057D6D0: BF870091
	.long 0xd7006a0c                                           // 00000057D6D4: D7006A0C
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000057D6D8: 02020D03
	v_add_co_ci_u32_e64 v13, null, 0, v4, vcc_lo               // 00000057D6DC: D5207C0D 01AA0880
	global_load_d16_b16 v6, v[12:13], off                      // 00000057D6E4: DC820000 067C000C
	s_waitcnt vmcnt(0)                                         // 00000057D6EC: BF8903F7
	v_cvt_f32_f16_e32 v12, v6                                  // 00000057D6F0: 7E181706
	s_or_b32 exec_lo, exec_lo, s2                              // 00000057D6F4: 8C7E027E
	v_or_b32_e32 v6, 0xc0, v30                                 // 00000057D6F8: 380C3CFF 000000C0
	v_dual_mov_b32 v14, 0 :: v_dual_mov_b32 v13, 0             // 00000057D700: CA100080 0E0C0080
	s_mov_b32 s2, exec_lo                                      // 00000057D708: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000057D70C: BF870002
	.long 0xd4c4007e                                           // 00000057D710: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 00000057D714: 02020C14
	s_cbranch_execz 10                                         // 00000057D718: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x344>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000057D71C: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057D720: BF870091
	.long 0xd7006a0f                                           // 00000057D724: D7006A0F
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000057D728: 02020D03
	v_add_co_ci_u32_e64 v16, null, 0, v4, vcc_lo               // 00000057D72C: D5207C10 01AA0880
	global_load_d16_b16 v6, v[15:16], off                      // 00000057D734: DC820000 067C000F
	s_waitcnt vmcnt(0)                                         // 00000057D73C: BF8903F7
	v_cvt_f32_f16_e32 v13, v6                                  // 00000057D740: 7E1A1706
	s_or_b32 exec_lo, exec_lo, s2                              // 00000057D744: 8C7E027E
	v_or_b32_e32 v6, 0xe0, v30                                 // 00000057D748: 380C3CFF 000000E0
	s_mov_b32 s2, exec_lo                                      // 00000057D750: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000057D754: BF870001
	.long 0xd4c4007e                                           // 00000057D758: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 00000057D75C: 02020C14
	s_cbranch_execz 10                                         // 00000057D760: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x38c>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000057D764: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057D768: BF870091
	.long 0xd7006a0e                                           // 00000057D76C: D7006A0E
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000057D770: 02020D03
	v_add_co_ci_u32_e64 v15, null, 0, v4, vcc_lo               // 00000057D774: D5207C0F 01AA0880
	global_load_d16_b16 v6, v[14:15], off                      // 00000057D77C: DC820000 067C000E
	s_waitcnt vmcnt(0)                                         // 00000057D784: BF8903F7
	v_cvt_f32_f16_e32 v14, v6                                  // 00000057D788: 7E1C1706
	s_or_b32 exec_lo, exec_lo, s2                              // 00000057D78C: 8C7E027E
	s_branch 9                                                 // 00000057D790: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x3b8>
	v_mov_b32_e32 v7, 0                                        // 00000057D794: 7E0E0280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000057D798: BF870001
	v_mov_b32_e32 v8, v7                                       // 00000057D79C: 7E100307
	v_mov_b32_e32 v9, v7                                       // 00000057D7A0: 7E120307
	v_mov_b32_e32 v10, v7                                      // 00000057D7A4: 7E140307
	v_mov_b32_e32 v11, v7                                      // 00000057D7A8: 7E160307
	v_mov_b32_e32 v12, v7                                      // 00000057D7AC: 7E180307
	v_mov_b32_e32 v13, v7                                      // 00000057D7B0: 7E1A0307
	v_mov_b32_e32 v14, v7                                      // 00000057D7B4: 7E1C0307
	s_add_u32 s2, s4, s14                                      // 00000057D7B8: 80020E04
	s_addc_u32 s3, s5, s15                                     // 00000057D7BC: 82030F05
	s_lshr_b32 s14, s11, 31                                    // 00000057D7C0: 850E9F0B
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v44, 0             // 00000057D7C4: CA100080 132C0080
	s_add_u32 s14, s10, s14                                    // 00000057D7CC: 800E0E0A
	s_addc_u32 s15, s11, 0                                     // 00000057D7D0: 820F800B
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v20, 0             // 00000057D7D4: CA100080 1F140080
	s_ashr_i64 s[14:15], s[14:15], 1                           // 00000057D7DC: 868E810E
	v_cndmask_b32_e64 v32, 0, 1, s18                           // 00000057D7E0: D5010020 00490280
	v_mad_u64_u32 v[25:26], null, v2, s14, s[2:3]              // 00000057D7E8: D6FE7C19 00081D02
	.long 0xd72c0002                                           // 00000057D7F0: D72C0002
	v_cndmask_b32_e32 v0, v2, v15, vcc_lo                      // 00000057D7F4: 02001F02
	.long 0xd72c0005                                           // 00000057D7F8: D72C0005
	v_cndmask_b32_e32 v0, v5, v14, vcc_lo                      // 00000057D7FC: 02001D05
	.long 0xd4440002                                           // 00000057D800: D4440002
	v_cndmask_b32_e32 v1, s20, v30, vcc_lo                     // 00000057D804: 02023C14
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v22, 0             // 00000057D808: CA100080 15160080
	s_delay_alu instid0(VALU_DEP_3)                            // 00000057D810: BF870003
	v_add3_u32 v33, v5, v26, v2                                // 00000057D814: D6550021 040A3505
	s_and_saveexec_b32 s3, s2                                  // 00000057D81C: BE832002
	s_cbranch_execz 21                                         // 00000057D820: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x478>
	v_lshlrev_b32_e32 v2, 4, v30                               // 00000057D824: 30043C84
	v_mov_b32_e32 v44, 0                                       // 00000057D828: 7E580280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057D82C: BF870092
	.long 0xd7006a05                                           // 00000057D830: D7006A05
	v_cndmask_b32_e32 v1, v25, v2, vcc_lo                      // 00000057D834: 02020519
	v_add_co_ci_u32_e64 v6, null, 0, v33, vcc_lo               // 00000057D838: D5207C06 01AA4280
	s_and_not1_b32 vcc_lo, exec_lo, s18                        // 00000057D840: 916A127E
	global_load_b128 v[19:22], v[5:6], off                     // 00000057D844: DC5E0000 137C0005
	s_cbranch_vccnz 10                                         // 00000057D84C: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x478>
	v_lshlrev_b32_e32 v2, 1, v30                               // 00000057D850: 30043C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057D854: BF870091
	.long 0xd7006a02                                           // 00000057D858: D7006A02
	v_cndmask_b32_e32 v1, v3, v2, vcc_lo                       // 00000057D85C: 02020503
	v_add_co_ci_u32_e64 v3, null, 0, v4, vcc_lo                // 00000057D860: D5207C03 01AA0880
	global_load_d16_b16 v2, v[2:3], off                        // 00000057D868: DC820000 027C0002
	s_waitcnt vmcnt(0)                                         // 00000057D870: BF8903F7
	v_cvt_f32_f16_e32 v44, v2                                  // 00000057D874: 7E581702
	s_or_b32 exec_lo, exec_lo, s3                              // 00000057D878: 8C7E037E
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v35, 0             // 00000057D87C: CA100080 22220080
	v_dual_mov_b32 v36, 0 :: v_dual_mov_b32 v37, 0             // 00000057D884: CA100080 24240080
	v_dual_mov_b32 v38, 0 :: v_dual_mov_b32 v39, 0             // 00000057D88C: CA100080 26260080
	v_mov_b32_e32 v40, 0                                       // 00000057D894: 7E500280
	s_and_saveexec_b32 s3, s2                                  // 00000057D898: BE832002
	s_cbranch_execz 685                                        // 00000057D89C: BFA502AD <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xf54>
	v_dual_mov_b32 v27, 0 :: v_dual_lshlrev_b32 v2, 1, v30     // 00000057D8A0: CA220080 1B023C81
	.long 0xd7006a00                                           // 00000057D8A8: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 00000057D8AC: 02020010
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000057D8B0: BF870191
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 00000057D8B4: D5207C01 01AA0211
	v_dual_mov_b32 v39, v27 :: v_dual_lshlrev_b32 v26, 5, v30  // 00000057D8BC: CA22011B 271A3C85
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057D8C4: BF870093
	.long 0xd7006a00                                           // 00000057D8C8: D7006A00
	v_cndmask_b32_e32 v1, v0, v2, vcc_lo                       // 00000057D8CC: 02020500
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 00000057D8D0: D5207C01 01AA0280
	v_lshl_or_b32 v41, v30, 4, 0x200                           // 00000057D8D8: D6560029 03FD091E 00000200
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057D8E4: BF870093
	.long 0xd7006a00                                           // 00000057D8E8: D7006A00
	v_cndmask_b32_e32 v1, s4, v0, vcc_lo                       // 00000057D8EC: 02020004
	v_add_co_ci_u32_e64 v1, null, s5, v1, vcc_lo               // 00000057D8F0: D5207C01 01AA0205
	v_dual_mov_b32 v42, v30 :: v_dual_mov_b32 v37, v27         // 00000057D8F8: CA10011E 2A24011B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057D900: BF870093
	.long 0xd7006a1c                                           // 00000057D904: D7006A1C
	v_cndmask_b32_e32 v0, v0, v192, vcc_lo                     // 00000057D908: 02018100
	v_add_co_ci_u32_e64 v29, null, 0, v1, vcc_lo               // 00000057D90C: D5207C1D 01AA0280
	v_dual_mov_b32 v40, v27 :: v_dual_mov_b32 v43, v44         // 00000057D914: CA10011B 282A012C
	v_mov_b32_e32 v38, v27                                     // 00000057D91C: 7E4C031B
	v_mov_b32_e32 v35, v27                                     // 00000057D920: 7E46031B
	v_mov_b32_e32 v36, v27                                     // 00000057D924: 7E48031B
	v_mov_b32_e32 v34, v27                                     // 00000057D928: 7E44031B
	v_mov_b32_e32 v31, v27                                     // 00000057D92C: 7E3E031B
	s_mul_i32 s2, s11, 6                                       // 00000057D930: 9602860B
	s_mul_hi_u32 s18, s10, 6                                   // 00000057D934: 9692860A
	s_lshl_b64 s[14:15], s[10:11], 2                           // 00000057D938: 848E820A
	s_add_i32 s18, s18, s2                                     // 00000057D93C: 81120212
	s_mul_i32 s17, s10, 6                                      // 00000057D940: 9611860A
	s_mov_b32 s16, 0                                           // 00000057D944: BE900080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 00000057D948: 8484810A
	s_branch 612                                               // 00000057D94C: BFA00264 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xee0>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000057D950: 8C7E0A7E
	v_cndmask_b32_e64 v44, v44, v7, s1                         // 00000057D954: D501002C 00060F2C
	v_cndmask_b32_e64 v1, v8, v9, s1                           // 00000057D95C: D5010001 00061308
	v_cndmask_b32_e64 v0, v7, v8, s1                           // 00000057D964: D5010000 00061107
	v_dual_mov_b32 v7, v14 :: v_dual_and_b32 v8, 0xff, v19     // 00000057D96C: CA24010E 070826FF 000000FF
	v_cndmask_b32_e64 v6, v13, v14, s1                         // 00000057D978: D5010006 00061D0D
	v_cndmask_b32_e64 v5, v12, v13, s1                         // 00000057D980: D5010005 00061B0C
	v_cndmask_b32_e64 v4, v11, v12, s1                         // 00000057D988: D5010004 0006190B
	v_cndmask_b32_e64 v3, v10, v11, s1                         // 00000057D990: D5010003 0006170A
	v_lshlrev_b32_e32 v8, 2, v8                                // 00000057D998: 30101082
	v_cndmask_b32_e64 v2, v9, v10, s1                          // 00000057D99C: D5010002 00061509
	s_and_b32 s2, exec_lo, s2                                  // 00000057D9A4: 8B02027E
	v_add_nc_u32_e32 v41, 0x200, v41                           // 00000057D9A8: 4A5252FF 00000200
	s_or_b32 s16, s2, s16                                      // 00000057D9B0: 8C101002
	ds_load_b32 v14, v8                                        // 00000057D9B4: D8D80000 0E000008
	v_lshrrev_b32_e32 v8, 6, v19                               // 00000057D9BC: 32102686
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000057D9C0: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000057D9C4: 361010FF 000003FC
	ds_load_b32 v55, v8                                        // 00000057D9CC: D8D80000 37000008
	v_lshrrev_b32_e32 v8, 14, v19                              // 00000057D9D4: 3210268E
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000057D9D8: 361010FF 000003FC
	ds_load_b32 v56, v8                                        // 00000057D9E0: D8D80000 38000008
	v_lshrrev_b32_e32 v8, 22, v19                              // 00000057D9E8: 32102696
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000057D9EC: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000057D9F0: 361010FF 000003FC
	ds_load_b32 v57, v8                                        // 00000057D9F8: D8D80000 39000008
	v_and_b32_e32 v8, 0xff, v20                                // 00000057DA00: 361028FF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 00000057DA08: 30101082
	ds_load_b32 v58, v8                                        // 00000057DA0C: D8D80000 3A000008
	v_lshrrev_b32_e32 v8, 6, v20                               // 00000057DA14: 32102886
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000057DA18: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000057DA1C: 361010FF 000003FC
	ds_load_b32 v59, v8                                        // 00000057DA24: D8D80000 3B000008
	v_lshrrev_b32_e32 v8, 14, v20                              // 00000057DA2C: 3210288E
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000057DA30: 361010FF 000003FC
	ds_load_b32 v60, v8                                        // 00000057DA38: D8D80000 3C000008
	v_lshrrev_b32_e32 v8, 22, v20                              // 00000057DA40: 32102896
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000057DA44: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000057DA48: 361010FF 000003FC
	ds_load_b32 v61, v8                                        // 00000057DA50: D8D80000 3D000008
	v_and_b32_e32 v8, 0xff, v21                                // 00000057DA58: 36102AFF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 00000057DA60: 30101082
	ds_load_b32 v62, v8                                        // 00000057DA64: D8D80000 3E000008
	v_lshrrev_b32_e32 v8, 6, v21                               // 00000057DA6C: 32102A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000057DA70: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000057DA74: 361010FF 000003FC
	ds_load_b32 v63, v8                                        // 00000057DA7C: D8D80000 3F000008
	v_lshrrev_b32_e32 v8, 14, v21                              // 00000057DA84: 32102A8E
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000057DA88: 361010FF 000003FC
	ds_load_b32 v64, v8                                        // 00000057DA90: D8D80000 40000008
	v_lshrrev_b32_e32 v8, 22, v21                              // 00000057DA98: 32102A96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000057DA9C: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000057DAA0: 361010FF 000003FC
	ds_load_b32 v65, v8                                        // 00000057DAA8: D8D80000 41000008
	v_and_b32_e32 v8, 0xff, v22                                // 00000057DAB0: 36102CFF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 00000057DAB8: 30101082
	ds_load_b32 v66, v8                                        // 00000057DABC: D8D80000 42000008
	v_lshrrev_b32_e32 v8, 6, v22                               // 00000057DAC4: 32102C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000057DAC8: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000057DACC: 361010FF 000003FC
	ds_load_b32 v67, v8                                        // 00000057DAD4: D8D80000 43000008
	v_lshrrev_b32_e32 v8, 14, v22                              // 00000057DADC: 32102C8E
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000057DAE0: 361010FF 000003FC
	ds_load_b32 v68, v8                                        // 00000057DAE8: D8D80000 44000008
	v_lshrrev_b32_e32 v8, 22, v22                              // 00000057DAF0: 32102C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000057DAF4: BF870141
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000057DAF8: 361010FF 000003FC
	ds_load_b32 v69, v8                                        // 00000057DB00: D8D80000 45000008
	.long 0xd73c0008                                           // 00000057DB08: D73C0008
	v_cndmask_b32_e32 v1, 1, v26, vcc_lo                       // 00000057DB0C: 02023481
	v_add_nc_u32_e32 v26, 0x400, v26                           // 00000057DB10: 4A3434FF 00000400
	.long 0xd7006a0c                                           // 00000057DB18: D7006A0C
	v_cndmask_b32_e32 v1, s6, v8, vcc_lo                       // 00000057DB1C: 02021006
	s_delay_alu instid0(VALU_DEP_1)                            // 00000057DB20: BF870001
	v_add_co_ci_u32_e64 v13, null, s7, v9, vcc_lo              // 00000057DB24: D5207C0D 01AA1207
	s_clause 0x3                                               // 00000057DB2C: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 00000057DB30: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 00000057DB38: DC5E0010 137C000C
	global_load_b128 v[45:48], v[12:13], off offset:32         // 00000057DB40: DC5E0020 2D7C000C
	global_load_b128 v[49:52], v[12:13], off offset:48         // 00000057DB48: DC5E0030 317C000C
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 00000057DB50: BF890CF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000057DB54: CC1A4008 1A021D08
	s_waitcnt lgkmcnt(14)                                      // 00000057DB5C: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057DB60: BF8700A1
	v_dot2_f32_bf16 v8, v9, v55, v8                            // 00000057DB64: CC1A4008 1C226F09
	s_waitcnt lgkmcnt(13)                                      // 00000057DB6C: BF89FCD7
	v_dot2_f32_bf16 v8, v10, v56, v8                           // 00000057DB70: CC1A4008 1C22710A
	s_waitcnt lgkmcnt(12)                                      // 00000057DB78: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057DB7C: BF8700A1
	v_dot2_f32_bf16 v8, v11, v57, v8                           // 00000057DB80: CC1A4008 1C22730B
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 00000057DB88: BF8908B7
	v_dot2_f32_bf16 v8, v19, v58, v8                           // 00000057DB8C: CC1A4008 1C227513
	s_waitcnt lgkmcnt(10)                                      // 00000057DB94: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057DB98: BF8700A1
	v_dot2_f32_bf16 v8, v20, v59, v8                           // 00000057DB9C: CC1A4008 1C227714
	s_waitcnt lgkmcnt(9)                                       // 00000057DBA4: BF89FC97
	v_dot2_f32_bf16 v8, v21, v60, v8                           // 00000057DBA8: CC1A4008 1C227915
	s_waitcnt lgkmcnt(8)                                       // 00000057DBB0: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057DBB4: BF8700A1
	v_dot2_f32_bf16 v8, v22, v61, v8                           // 00000057DBB8: CC1A4008 1C227B16
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 00000057DBC0: BF890477
	v_dot2_f32_bf16 v8, v45, v62, v8                           // 00000057DBC4: CC1A4008 1C227D2D
	s_waitcnt lgkmcnt(6)                                       // 00000057DBCC: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057DBD0: BF8700A1
	v_dot2_f32_bf16 v8, v46, v63, v8                           // 00000057DBD4: CC1A4008 1C227F2E
	s_waitcnt lgkmcnt(5)                                       // 00000057DBDC: BF89FC57
	v_dot2_f32_bf16 v8, v47, v64, v8                           // 00000057DBE0: CC1A4008 1C22812F
	s_waitcnt lgkmcnt(4)                                       // 00000057DBE8: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057DBEC: BF8700A1
	v_dot2_f32_bf16 v8, v48, v65, v8                           // 00000057DBF0: CC1A4008 1C228330
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 00000057DBF8: BF890037
	v_dot2_f32_bf16 v8, v49, v66, v8                           // 00000057DBFC: CC1A4008 1C228531
	.long 0xd7006a31                                           // 00000057DC04: D7006A31
	v_cndmask_b32_e32 v0, v12, v4, vcc_lo                      // 00000057DC08: 0200090C
	s_waitcnt lgkmcnt(2)                                       // 00000057DC0C: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000057DC10: BF8701C2
	v_dot2_f32_bf16 v8, v50, v67, v8                           // 00000057DC14: CC1A4008 1C228732
	v_add_co_ci_u32_e64 v50, null, s5, v13, vcc_lo             // 00000057DC1C: D5207C32 01AA1A05
	.long 0xd7006a35                                           // 00000057DC24: D7006A35
	v_cndmask_b32_e32 v0, v12, v14, vcc_lo                     // 00000057DC28: 02001D0C
	s_waitcnt lgkmcnt(1)                                       // 00000057DC2C: BF89FC17
	v_dot2_f32_bf16 v8, v51, v68, v8                           // 00000057DC30: CC1A4008 1C228933
	v_add_co_ci_u32_e64 v54, null, s15, v13, vcc_lo            // 00000057DC38: D5207C36 01AA1A0F
	.long 0xd7006a0c                                           // 00000057DC40: D7006A0C
	v_cndmask_b32_e32 v0, v12, v17, vcc_lo                     // 00000057DC44: 0200230C
	s_waitcnt lgkmcnt(0)                                       // 00000057DC48: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000057DC4C: BF870123
	v_dot2_f32_bf16 v8, v52, v69, v8                           // 00000057DC50: CC1A4008 1C228B34
	v_add_co_ci_u32_e64 v13, null, s18, v13, vcc_lo            // 00000057DC58: D5207C0D 01AA1A12
	v_fmac_f32_e32 v39, v44, v8                                // 00000057DC60: 564E112C
	s_clause 0x3                                               // 00000057DC64: BF850003
	global_load_b128 v[8:11], v[49:50], off                    // 00000057DC68: DC5E0000 087C0031
	global_load_b128 v[19:22], v[49:50], off offset:16         // 00000057DC70: DC5E0010 137C0031
	global_load_b128 v[45:48], v[49:50], off offset:32         // 00000057DC78: DC5E0020 2D7C0031
	global_load_b128 v[49:52], v[49:50], off offset:48         // 00000057DC80: DC5E0030 317C0031
	s_waitcnt vmcnt(3)                                         // 00000057DC88: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000057DC8C: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057DC94: BF870091
	v_dot2_f32_bf16 v8, v9, v55, v8                            // 00000057DC98: CC1A4008 1C226F09
	v_dot2_f32_bf16 v8, v10, v56, v8                           // 00000057DCA0: CC1A4008 1C22710A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057DCA8: BF8700A1
	v_dot2_f32_bf16 v8, v11, v57, v8                           // 00000057DCAC: CC1A4008 1C22730B
	s_waitcnt vmcnt(2)                                         // 00000057DCB4: BF890BF7
	v_dot2_f32_bf16 v8, v19, v58, v8                           // 00000057DCB8: CC1A4008 1C227513
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057DCC0: BF870091
	v_dot2_f32_bf16 v8, v20, v59, v8                           // 00000057DCC4: CC1A4008 1C227714
	v_dot2_f32_bf16 v8, v21, v60, v8                           // 00000057DCCC: CC1A4008 1C227915
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057DCD4: BF8700A1
	v_dot2_f32_bf16 v8, v22, v61, v8                           // 00000057DCD8: CC1A4008 1C227B16
	s_waitcnt vmcnt(1)                                         // 00000057DCE0: BF8907F7
	v_dot2_f32_bf16 v8, v45, v62, v8                           // 00000057DCE4: CC1A4008 1C227D2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057DCEC: BF870091
	v_dot2_f32_bf16 v8, v46, v63, v8                           // 00000057DCF0: CC1A4008 1C227F2E
	v_dot2_f32_bf16 v8, v47, v64, v8                           // 00000057DCF8: CC1A4008 1C22812F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057DD00: BF8700A1
	v_dot2_f32_bf16 v8, v48, v65, v8                           // 00000057DD04: CC1A4008 1C228330
	s_waitcnt vmcnt(0)                                         // 00000057DD0C: BF8903F7
	v_dot2_f32_bf16 v8, v49, v66, v8                           // 00000057DD10: CC1A4008 1C228531
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057DD18: BF870091
	v_dot2_f32_bf16 v8, v50, v67, v8                           // 00000057DD1C: CC1A4008 1C228732
	v_dot2_f32_bf16 v8, v51, v68, v8                           // 00000057DD24: CC1A4008 1C228933
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057DD2C: BF870091
	v_dot2_f32_bf16 v8, v52, v69, v8                           // 00000057DD30: CC1A4008 1C228B34
	v_fmac_f32_e32 v40, v44, v8                                // 00000057DD38: 5650112C
	s_clause 0x3                                               // 00000057DD3C: BF850003
	global_load_b128 v[8:11], v[53:54], off                    // 00000057DD40: DC5E0000 087C0035
	global_load_b128 v[19:22], v[53:54], off offset:16         // 00000057DD48: DC5E0010 137C0035
	global_load_b128 v[45:48], v[53:54], off offset:32         // 00000057DD50: DC5E0020 2D7C0035
	global_load_b128 v[49:52], v[53:54], off offset:48         // 00000057DD58: DC5E0030 317C0035
	.long 0xd7006a35                                           // 00000057DD60: D7006A35
	v_cndmask_b32_e32 v0, v53, v14, vcc_lo                     // 00000057DD64: 02001D35
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000057DD68: BF8700B1
	v_add_co_ci_u32_e64 v54, null, s15, v54, vcc_lo            // 00000057DD6C: D5207C36 01AA6C0F
	s_waitcnt vmcnt(3)                                         // 00000057DD74: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000057DD78: CC1A4008 1A021D08
	v_dot2_f32_bf16 v8, v9, v55, v8                            // 00000057DD80: CC1A4008 1C226F09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057DD88: BF870091
	v_dot2_f32_bf16 v8, v10, v56, v8                           // 00000057DD8C: CC1A4008 1C22710A
	v_dot2_f32_bf16 v8, v11, v57, v8                           // 00000057DD94: CC1A4008 1C22730B
	s_waitcnt vmcnt(2)                                         // 00000057DD9C: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057DDA0: BF870091
	v_dot2_f32_bf16 v8, v19, v58, v8                           // 00000057DDA4: CC1A4008 1C227513
	v_dot2_f32_bf16 v8, v20, v59, v8                           // 00000057DDAC: CC1A4008 1C227714
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057DDB4: BF870091
	v_dot2_f32_bf16 v8, v21, v60, v8                           // 00000057DDB8: CC1A4008 1C227915
	v_dot2_f32_bf16 v8, v22, v61, v8                           // 00000057DDC0: CC1A4008 1C227B16
	s_waitcnt vmcnt(1)                                         // 00000057DDC8: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057DDCC: BF870091
	v_dot2_f32_bf16 v8, v45, v62, v8                           // 00000057DDD0: CC1A4008 1C227D2D
	v_dot2_f32_bf16 v8, v46, v63, v8                           // 00000057DDD8: CC1A4008 1C227F2E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057DDE0: BF870091
	v_dot2_f32_bf16 v8, v47, v64, v8                           // 00000057DDE4: CC1A4008 1C22812F
	v_dot2_f32_bf16 v8, v48, v65, v8                           // 00000057DDEC: CC1A4008 1C228330
	s_waitcnt vmcnt(0)                                         // 00000057DDF4: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057DDF8: BF870091
	v_dot2_f32_bf16 v8, v49, v66, v8                           // 00000057DDFC: CC1A4008 1C228531
	v_dot2_f32_bf16 v8, v50, v67, v8                           // 00000057DE04: CC1A4008 1C228732
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057DE0C: BF870091
	v_dot2_f32_bf16 v8, v51, v68, v8                           // 00000057DE10: CC1A4008 1C228933
	v_dot2_f32_bf16 v8, v52, v69, v8                           // 00000057DE18: CC1A4008 1C228B34
	s_delay_alu instid0(VALU_DEP_1)                            // 00000057DE20: BF870001
	v_fmac_f32_e32 v37, v44, v8                                // 00000057DE24: 564A112C
	s_clause 0x3                                               // 00000057DE28: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 00000057DE2C: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 00000057DE34: DC5E0010 137C000C
	global_load_b128 v[45:48], v[12:13], off offset:32         // 00000057DE3C: DC5E0020 2D7C000C
	global_load_b128 v[49:52], v[12:13], off offset:48         // 00000057DE44: DC5E0030 317C000C
	.long 0xd7006a0c                                           // 00000057DE4C: D7006A0C
	v_cndmask_b32_e32 v0, v12, v14, vcc_lo                     // 00000057DE50: 02001D0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000057DE54: BF8700B1
	v_add_co_ci_u32_e64 v13, null, s15, v13, vcc_lo            // 00000057DE58: D5207C0D 01AA1A0F
	s_waitcnt vmcnt(3)                                         // 00000057DE60: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000057DE64: CC1A4008 1A021D08
	v_dot2_f32_bf16 v8, v9, v55, v8                            // 00000057DE6C: CC1A4008 1C226F09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057DE74: BF870091
	v_dot2_f32_bf16 v8, v10, v56, v8                           // 00000057DE78: CC1A4008 1C22710A
	v_dot2_f32_bf16 v8, v11, v57, v8                           // 00000057DE80: CC1A4008 1C22730B
	s_waitcnt vmcnt(2)                                         // 00000057DE88: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057DE8C: BF870091
	v_dot2_f32_bf16 v8, v19, v58, v8                           // 00000057DE90: CC1A4008 1C227513
	v_dot2_f32_bf16 v8, v20, v59, v8                           // 00000057DE98: CC1A4008 1C227714
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057DEA0: BF870091
	v_dot2_f32_bf16 v8, v21, v60, v8                           // 00000057DEA4: CC1A4008 1C227915
	v_dot2_f32_bf16 v8, v22, v61, v8                           // 00000057DEAC: CC1A4008 1C227B16
	s_waitcnt vmcnt(1)                                         // 00000057DEB4: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057DEB8: BF870091
	v_dot2_f32_bf16 v8, v45, v62, v8                           // 00000057DEBC: CC1A4008 1C227D2D
	v_dot2_f32_bf16 v8, v46, v63, v8                           // 00000057DEC4: CC1A4008 1C227F2E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057DECC: BF870091
	v_dot2_f32_bf16 v8, v47, v64, v8                           // 00000057DED0: CC1A4008 1C22812F
	v_dot2_f32_bf16 v8, v48, v65, v8                           // 00000057DED8: CC1A4008 1C228330
	s_waitcnt vmcnt(0)                                         // 00000057DEE0: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057DEE4: BF870091
	v_dot2_f32_bf16 v8, v49, v66, v8                           // 00000057DEE8: CC1A4008 1C228531
	v_dot2_f32_bf16 v8, v50, v67, v8                           // 00000057DEF0: CC1A4008 1C228732
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057DEF8: BF870091
	v_dot2_f32_bf16 v8, v51, v68, v8                           // 00000057DEFC: CC1A4008 1C228933
	v_dot2_f32_bf16 v8, v52, v69, v8                           // 00000057DF04: CC1A4008 1C228B34
	s_delay_alu instid0(VALU_DEP_1)                            // 00000057DF0C: BF870001
	v_fmac_f32_e32 v38, v44, v8                                // 00000057DF10: 564C112C
	s_clause 0x3                                               // 00000057DF14: BF850003
	global_load_b128 v[8:11], v[53:54], off                    // 00000057DF18: DC5E0000 087C0035
	global_load_b128 v[19:22], v[53:54], off offset:16         // 00000057DF20: DC5E0010 137C0035
	global_load_b128 v[45:48], v[53:54], off offset:32         // 00000057DF28: DC5E0020 2D7C0035
	global_load_b128 v[49:52], v[53:54], off offset:48         // 00000057DF30: DC5E0030 317C0035
	s_waitcnt vmcnt(3)                                         // 00000057DF38: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000057DF3C: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057DF44: BF870091
	v_dot2_f32_bf16 v8, v9, v55, v8                            // 00000057DF48: CC1A4008 1C226F09
	v_dot2_f32_bf16 v8, v10, v56, v8                           // 00000057DF50: CC1A4008 1C22710A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057DF58: BF8700A1
	v_dot2_f32_bf16 v8, v11, v57, v8                           // 00000057DF5C: CC1A4008 1C22730B
	s_waitcnt vmcnt(2)                                         // 00000057DF64: BF890BF7
	v_dot2_f32_bf16 v8, v19, v58, v8                           // 00000057DF68: CC1A4008 1C227513
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057DF70: BF870091
	v_dot2_f32_bf16 v8, v20, v59, v8                           // 00000057DF74: CC1A4008 1C227714
	v_dot2_f32_bf16 v8, v21, v60, v8                           // 00000057DF7C: CC1A4008 1C227915
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057DF84: BF8700A1
	v_dot2_f32_bf16 v8, v22, v61, v8                           // 00000057DF88: CC1A4008 1C227B16
	s_waitcnt vmcnt(1)                                         // 00000057DF90: BF8907F7
	v_dot2_f32_bf16 v8, v45, v62, v8                           // 00000057DF94: CC1A4008 1C227D2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057DF9C: BF870091
	v_dot2_f32_bf16 v8, v46, v63, v8                           // 00000057DFA0: CC1A4008 1C227F2E
	v_dot2_f32_bf16 v8, v47, v64, v8                           // 00000057DFA8: CC1A4008 1C22812F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057DFB0: BF8700A1
	v_dot2_f32_bf16 v8, v48, v65, v8                           // 00000057DFB4: CC1A4008 1C228330
	s_waitcnt vmcnt(0)                                         // 00000057DFBC: BF8903F7
	v_dot2_f32_bf16 v8, v49, v66, v8                           // 00000057DFC0: CC1A4008 1C228531
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057DFC8: BF870091
	v_dot2_f32_bf16 v8, v50, v67, v8                           // 00000057DFCC: CC1A4008 1C228732
	v_dot2_f32_bf16 v8, v51, v68, v8                           // 00000057DFD4: CC1A4008 1C228933
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057DFDC: BF870091
	v_dot2_f32_bf16 v8, v52, v69, v8                           // 00000057DFE0: CC1A4008 1C228B34
	v_fmac_f32_e32 v35, v44, v8                                // 00000057DFE8: 5646112C
	s_clause 0x3                                               // 00000057DFEC: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 00000057DFF0: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 00000057DFF8: DC5E0010 137C000C
	global_load_b128 v[45:48], v[12:13], off offset:32         // 00000057E000: DC5E0020 2D7C000C
	global_load_b128 v[49:52], v[12:13], off offset:48         // 00000057E008: DC5E0030 317C000C
	s_waitcnt vmcnt(3)                                         // 00000057E010: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000057E014: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057E01C: BF870091
	v_dot2_f32_bf16 v8, v9, v55, v8                            // 00000057E020: CC1A4008 1C226F09
	v_dot2_f32_bf16 v8, v10, v56, v8                           // 00000057E028: CC1A4008 1C22710A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057E030: BF8700A1
	v_dot2_f32_bf16 v8, v11, v57, v8                           // 00000057E034: CC1A4008 1C22730B
	s_waitcnt vmcnt(2)                                         // 00000057E03C: BF890BF7
	v_dot2_f32_bf16 v8, v19, v58, v8                           // 00000057E040: CC1A4008 1C227513
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057E048: BF870091
	v_dot2_f32_bf16 v8, v20, v59, v8                           // 00000057E04C: CC1A4008 1C227714
	v_dot2_f32_bf16 v8, v21, v60, v8                           // 00000057E054: CC1A4008 1C227915
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057E05C: BF8700A1
	v_dot2_f32_bf16 v8, v22, v61, v8                           // 00000057E060: CC1A4008 1C227B16
	s_waitcnt vmcnt(1)                                         // 00000057E068: BF8907F7
	v_dot2_f32_bf16 v8, v45, v62, v8                           // 00000057E06C: CC1A4008 1C227D2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057E074: BF870091
	v_dot2_f32_bf16 v8, v46, v63, v8                           // 00000057E078: CC1A4008 1C227F2E
	v_dot2_f32_bf16 v8, v47, v64, v8                           // 00000057E080: CC1A4008 1C22812F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057E088: BF8700A1
	v_dot2_f32_bf16 v8, v48, v65, v8                           // 00000057E08C: CC1A4008 1C228330
	s_waitcnt vmcnt(0)                                         // 00000057E094: BF8903F7
	v_dot2_f32_bf16 v8, v49, v66, v8                           // 00000057E098: CC1A4008 1C228531
	.long 0xd7006a31                                           // 00000057E0A0: D7006A31
	v_cndmask_b32_e32 v0, v53, v14, vcc_lo                     // 00000057E0A4: 02001D35
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000057E0A8: BF8701B2
	v_dot2_f32_bf16 v8, v50, v67, v8                           // 00000057E0AC: CC1A4008 1C228732
	v_add_co_ci_u32_e64 v50, null, s15, v54, vcc_lo            // 00000057E0B4: D5207C32 01AA6C0F
	.long 0xd7006a0c                                           // 00000057E0BC: D7006A0C
	v_cndmask_b32_e32 v0, v12, v14, vcc_lo                     // 00000057E0C0: 02001D0C
	v_dot2_f32_bf16 v8, v51, v68, v8                           // 00000057E0C4: CC1A4008 1C228933
	v_add_co_ci_u32_e64 v13, null, s15, v13, vcc_lo            // 00000057E0CC: D5207C0D 01AA1A0F
	.long 0xd7006a1c                                           // 00000057E0D4: D7006A1C
	v_cndmask_b32_e32 v0, v28, v192, vcc_lo                    // 00000057E0D8: 0201811C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000057E0DC: BF870123
	v_dot2_f32_bf16 v8, v52, v69, v8                           // 00000057E0E0: CC1A4008 1C228B34
	v_add_co_ci_u32_e64 v29, null, 0, v29, vcc_lo              // 00000057E0E8: D5207C1D 01AA3A80
	v_fmac_f32_e32 v36, v44, v8                                // 00000057E0F0: 5648112C
	s_clause 0x3                                               // 00000057E0F4: BF850003
	global_load_b128 v[8:11], v[49:50], off                    // 00000057E0F8: DC5E0000 087C0031
	global_load_b128 v[19:22], v[49:50], off offset:16         // 00000057E100: DC5E0010 137C0031
	global_load_b128 v[45:48], v[49:50], off offset:32         // 00000057E108: DC5E0020 2D7C0031
	global_load_b128 v[49:52], v[49:50], off offset:48         // 00000057E110: DC5E0030 317C0031
	s_waitcnt vmcnt(3)                                         // 00000057E118: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000057E11C: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057E124: BF870091
	v_dot2_f32_bf16 v8, v9, v55, v8                            // 00000057E128: CC1A4008 1C226F09
	v_dot2_f32_bf16 v8, v10, v56, v8                           // 00000057E130: CC1A4008 1C22710A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057E138: BF8700A1
	v_dot2_f32_bf16 v8, v11, v57, v8                           // 00000057E13C: CC1A4008 1C22730B
	s_waitcnt vmcnt(2)                                         // 00000057E144: BF890BF7
	v_dot2_f32_bf16 v8, v19, v58, v8                           // 00000057E148: CC1A4008 1C227513
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057E150: BF870091
	v_dot2_f32_bf16 v8, v20, v59, v8                           // 00000057E154: CC1A4008 1C227714
	v_dot2_f32_bf16 v8, v21, v60, v8                           // 00000057E15C: CC1A4008 1C227915
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057E164: BF8700A1
	v_dot2_f32_bf16 v8, v22, v61, v8                           // 00000057E168: CC1A4008 1C227B16
	s_waitcnt vmcnt(1)                                         // 00000057E170: BF8907F7
	v_dot2_f32_bf16 v8, v45, v62, v8                           // 00000057E174: CC1A4008 1C227D2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057E17C: BF870091
	v_dot2_f32_bf16 v8, v46, v63, v8                           // 00000057E180: CC1A4008 1C227F2E
	v_dot2_f32_bf16 v8, v47, v64, v8                           // 00000057E188: CC1A4008 1C22812F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057E190: BF8700A1
	v_dot2_f32_bf16 v8, v48, v65, v8                           // 00000057E194: CC1A4008 1C228330
	s_waitcnt vmcnt(0)                                         // 00000057E19C: BF8903F7
	v_dot2_f32_bf16 v8, v49, v66, v8                           // 00000057E1A0: CC1A4008 1C228531
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057E1A8: BF870091
	v_dot2_f32_bf16 v8, v50, v67, v8                           // 00000057E1AC: CC1A4008 1C228732
	v_dot2_f32_bf16 v8, v51, v68, v8                           // 00000057E1B4: CC1A4008 1C228933
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057E1BC: BF870091
	v_dot2_f32_bf16 v8, v52, v69, v8                           // 00000057E1C0: CC1A4008 1C228B34
	v_fmac_f32_e32 v34, v44, v8                                // 00000057E1C8: 5644112C
	s_clause 0x3                                               // 00000057E1CC: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 00000057E1D0: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 00000057E1D8: DC5E0010 137C000C
	global_load_b128 v[45:48], v[12:13], off offset:32         // 00000057E1E0: DC5E0020 2D7C000C
	global_load_b128 v[49:52], v[12:13], off offset:48         // 00000057E1E8: DC5E0030 317C000C
	s_waitcnt vmcnt(3)                                         // 00000057E1F0: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000057E1F4: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057E1FC: BF870091
	v_dot2_f32_bf16 v8, v9, v55, v8                            // 00000057E200: CC1A4008 1C226F09
	v_dot2_f32_bf16 v8, v10, v56, v8                           // 00000057E208: CC1A4008 1C22710A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057E210: BF8700A1
	v_dot2_f32_bf16 v8, v11, v57, v8                           // 00000057E214: CC1A4008 1C22730B
	s_waitcnt vmcnt(2)                                         // 00000057E21C: BF890BF7
	v_dot2_f32_bf16 v8, v19, v58, v8                           // 00000057E220: CC1A4008 1C227513
	v_mov_b32_e32 v19, v15                                     // 00000057E228: 7E26030F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000057E22C: BF870122
	v_dot2_f32_bf16 v8, v20, v59, v8                           // 00000057E230: CC1A4008 1C227714
	v_mov_b32_e32 v20, v16                                     // 00000057E238: 7E280310
	v_dot2_f32_bf16 v8, v21, v60, v8                           // 00000057E23C: CC1A4008 1C227915
	v_mov_b32_e32 v21, v17                                     // 00000057E244: 7E2A0311
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000057E248: BF870132
	v_dot2_f32_bf16 v8, v22, v61, v8                           // 00000057E24C: CC1A4008 1C227B16
	v_mov_b32_e32 v22, v18                                     // 00000057E254: 7E2C0312
	s_waitcnt vmcnt(1)                                         // 00000057E258: BF8907F7
	v_dot2_f32_bf16 v8, v45, v62, v8                           // 00000057E25C: CC1A4008 1C227D2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057E264: BF870091
	v_dot2_f32_bf16 v8, v46, v63, v8                           // 00000057E268: CC1A4008 1C227F2E
	v_dot2_f32_bf16 v8, v47, v64, v8                           // 00000057E270: CC1A4008 1C22812F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057E278: BF8700A1
	v_dot2_f32_bf16 v8, v48, v65, v8                           // 00000057E27C: CC1A4008 1C228330
	s_waitcnt vmcnt(0)                                         // 00000057E284: BF8903F7
	v_dot2_f32_bf16 v8, v49, v66, v8                           // 00000057E288: CC1A4008 1C228531
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057E290: BF870091
	v_dot2_f32_bf16 v8, v50, v67, v8                           // 00000057E294: CC1A4008 1C228732
	v_dot2_f32_bf16 v8, v51, v68, v8                           // 00000057E29C: CC1A4008 1C228933
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057E2A4: BF870091
	v_dot2_f32_bf16 v8, v52, v69, v8                           // 00000057E2A8: CC1A4008 1C228B34
	v_dual_fmac_f32 v31, v44, v8 :: v_dual_mov_b32 v14, v7     // 00000057E2B0: C810112C 1F0E0107
	v_dual_mov_b32 v44, v43 :: v_dual_mov_b32 v13, v6          // 00000057E2B8: CA10012B 2C0C0106
	v_dual_mov_b32 v12, v5 :: v_dual_mov_b32 v11, v4           // 00000057E2C0: CA100105 0C0A0104
	v_dual_mov_b32 v10, v3 :: v_dual_mov_b32 v9, v2            // 00000057E2C8: CA100103 0A080102
	v_dual_mov_b32 v8, v1 :: v_dual_mov_b32 v7, v0             // 00000057E2D0: CA100101 08060100
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 00000057E2D8: 917E107E
	s_cbranch_execz 28                                         // 00000057E2DC: BFA5001C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xf50>
	s_waitcnt vmcnt(0)                                         // 00000057E2E0: BF8903F7
	v_dual_mov_b32 v15, v19 :: v_dual_add_nc_u32 v42, 32, v42  // 00000057E2E4: CA200113 0F2A54A0
	v_dual_mov_b32 v16, v20 :: v_dual_mov_b32 v17, v21         // 00000057E2EC: CA100114 10100115
	v_mov_b32_e32 v18, v22                                     // 00000057E2F4: 7E240316
	s_delay_alu instid0(VALU_DEP_3)                            // 00000057E2F8: BF870003
	.long 0xd4430002                                           // 00000057E2FC: D4430002
	v_cndmask_b32_e32 v1, s20, v42, vcc_lo                     // 00000057E300: 02025414
	s_mov_b32 s10, exec_lo                                     // 00000057E304: BE8A007E
	.long 0xd4c4007e                                           // 00000057E308: D4C4007E
	v_cndmask_b32_e32 v1, s20, v42, vcc_lo                     // 00000057E30C: 02025414
	s_cbranch_execz 64911                                      // 00000057E310: BFA5FD8F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x550>
	.long 0xd7006a00                                           // 00000057E314: D7006A00
	v_cndmask_b32_e32 v1, v25, v41, vcc_lo                     // 00000057E318: 02025319
	s_delay_alu instid0(VALU_DEP_1)                            // 00000057E31C: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v33, vcc_lo               // 00000057E320: D5207C01 01AA4280
	v_cmp_ne_u32_e32 vcc_lo, 1, v32                            // 00000057E328: 7C9A4081
	v_mov_b32_e32 v43, v44                                     // 00000057E32C: 7E56032C
	global_load_b128 v[15:18], v[0:1], off                     // 00000057E330: DC5E0000 0F7C0000
	s_cbranch_vccnz 64901                                      // 00000057E338: BFA4FD85 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x550>
	global_load_d16_b16 v0, v[28:29], off                      // 00000057E33C: DC820000 007C001C
	s_waitcnt vmcnt(0)                                         // 00000057E344: BF8903F7
	v_cvt_f32_f16_e32 v43, v0                                  // 00000057E348: 7E561700
	s_branch 64896                                             // 00000057E34C: BFA0FD80 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x550>
	s_or_b32 exec_lo, exec_lo, s16                             // 00000057E350: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057E354: BF8700A9
	s_or_b32 exec_lo, exec_lo, s3                              // 00000057E358: 8C7E037E
	.long 0xd71f0000                                           // 00000057E35C: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000057E360: 020100C1
	v_xor_b32_e32 v1, 16, v0                                   // 00000057E364: 3A020090
	v_xor_b32_e32 v9, 8, v0                                    // 00000057E368: 3A120088
	v_xor_b32_e32 v17, 4, v0                                   // 00000057E36C: 3A220084
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000057E370: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v1                            // 00000057E374: 7C9802A0
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 00000057E378: 02020300
	v_cmp_gt_u32_e32 vcc_lo, 32, v9                            // 00000057E37C: 7C9812A0
	s_delay_alu instid0(VALU_DEP_2)                            // 00000057E380: BF870002
	v_lshlrev_b32_e32 v1, 2, v1                                // 00000057E384: 30020282
	ds_bpermute_b32 v2, v1, v40                                // 00000057E388: DACC0000 02002801
	s_waitcnt lgkmcnt(0)                                       // 00000057E390: BF89FC07
	v_add_f32_e32 v2, v40, v2                                  // 00000057E394: 06040528
	ds_bpermute_b32 v8, v1, v31                                // 00000057E398: DACC0000 08001F01
	ds_bpermute_b32 v6, v1, v36                                // 00000057E3A0: DACC0000 06002401
	ds_bpermute_b32 v4, v1, v38                                // 00000057E3A8: DACC0000 04002601
	v_cndmask_b32_e32 v9, v0, v9, vcc_lo                       // 00000057E3B0: 02121300
	ds_bpermute_b32 v3, v1, v39                                // 00000057E3B4: DACC0000 03002701
	ds_bpermute_b32 v5, v1, v37                                // 00000057E3BC: DACC0000 05002501
	ds_bpermute_b32 v7, v1, v35                                // 00000057E3C4: DACC0000 07002301
	ds_bpermute_b32 v1, v1, v34                                // 00000057E3CC: DACC0000 01002201
	v_cmp_gt_u32_e32 vcc_lo, 32, v17                           // 00000057E3D4: 7C9822A0
	s_waitcnt lgkmcnt(6)                                       // 00000057E3D8: BF89FC67
	v_dual_cndmask_b32 v17, v0, v17 :: v_dual_add_f32 v8, v31, v8// 00000057E3DC: CA482300 1108111F
	s_waitcnt lgkmcnt(5)                                       // 00000057E3E4: BF89FC57
	v_dual_add_f32 v6, v36, v6 :: v_dual_lshlrev_b32 v9, 2, v9 // 00000057E3E8: C9220D24 06081282
	s_waitcnt lgkmcnt(4)                                       // 00000057E3F0: BF89FC47
	v_add_f32_e32 v4, v38, v4                                  // 00000057E3F4: 06080926
	ds_bpermute_b32 v10, v9, v2                                // 00000057E3F8: DACC0000 0A000209
	s_waitcnt lgkmcnt(4)                                       // 00000057E400: BF89FC47
	v_add_f32_e32 v3, v39, v3                                  // 00000057E404: 06060727
	ds_bpermute_b32 v12, v9, v4                                // 00000057E408: DACC0000 0C000409
	ds_bpermute_b32 v14, v9, v6                                // 00000057E410: DACC0000 0E000609
	ds_bpermute_b32 v16, v9, v8                                // 00000057E418: DACC0000 10000809
	s_waitcnt lgkmcnt(6)                                       // 00000057E420: BF89FC67
	v_add_f32_e32 v5, v37, v5                                  // 00000057E424: 060A0B25
	s_waitcnt lgkmcnt(5)                                       // 00000057E428: BF89FC57
	v_add_f32_e32 v7, v35, v7                                  // 00000057E42C: 060E0F23
	s_waitcnt lgkmcnt(4)                                       // 00000057E430: BF89FC47
	v_add_f32_e32 v1, v34, v1                                  // 00000057E434: 06020322
	s_waitcnt lgkmcnt(3)                                       // 00000057E438: BF89FC37
	v_add_f32_e32 v2, v2, v10                                  // 00000057E43C: 06041502
	ds_bpermute_b32 v11, v9, v3                                // 00000057E440: DACC0000 0B000309
	s_waitcnt lgkmcnt(3)                                       // 00000057E448: BF89FC37
	v_dual_add_f32 v4, v4, v12 :: v_dual_lshlrev_b32 v17, 2, v17// 00000057E44C: C9221904 04102282
	ds_bpermute_b32 v13, v9, v5                                // 00000057E454: DACC0000 0D000509
	s_waitcnt lgkmcnt(3)                                       // 00000057E45C: BF89FC37
	v_add_f32_e32 v6, v6, v14                                  // 00000057E460: 060C1D06
	ds_bpermute_b32 v15, v9, v7                                // 00000057E464: DACC0000 0F000709
	s_waitcnt lgkmcnt(3)                                       // 00000057E46C: BF89FC37
	v_add_f32_e32 v8, v8, v16                                  // 00000057E470: 06102108
	ds_bpermute_b32 v9, v9, v1                                 // 00000057E474: DACC0000 09000109
	s_waitcnt lgkmcnt(3)                                       // 00000057E47C: BF89FC37
	v_add_f32_e32 v3, v3, v11                                  // 00000057E480: 06061703
	ds_bpermute_b32 v11, v17, v4                               // 00000057E484: DACC0000 0B000411
	s_waitcnt lgkmcnt(2)                                       // 00000057E48C: BF89FC27
	v_add_f32_e32 v7, v7, v15                                  // 00000057E490: 060E1F07
	s_waitcnt lgkmcnt(0)                                       // 00000057E494: BF89FC07
	v_dual_add_f32 v1, v1, v9 :: v_dual_add_f32 v4, v4, v11    // 00000057E498: C9081301 01041704
	ds_bpermute_b32 v9, v17, v2                                // 00000057E4A0: DACC0000 09000211
	ds_bpermute_b32 v15, v17, v8                               // 00000057E4A8: DACC0000 0F000811
	v_add_f32_e32 v5, v5, v13                                  // 00000057E4B0: 060A1B05
	ds_bpermute_b32 v13, v17, v6                               // 00000057E4B4: DACC0000 0D000611
	ds_bpermute_b32 v16, v17, v1                               // 00000057E4BC: DACC0000 10000111
	s_waitcnt lgkmcnt(3)                                       // 00000057E4C4: BF89FC37
	v_add_f32_e32 v2, v2, v9                                   // 00000057E4C8: 06041302
	ds_bpermute_b32 v10, v17, v3                               // 00000057E4CC: DACC0000 0A000311
	s_waitcnt lgkmcnt(2)                                       // 00000057E4D4: BF89FC27
	v_add_f32_e32 v6, v6, v13                                  // 00000057E4D8: 060C1B06
	ds_bpermute_b32 v14, v17, v7                               // 00000057E4DC: DACC0000 0E000711
	s_waitcnt lgkmcnt(1)                                       // 00000057E4E4: BF89FC17
	v_dual_add_f32 v3, v3, v10 :: v_dual_add_f32 v10, v8, v15  // 00000057E4E8: C9081503 030A1F08
	ds_bpermute_b32 v12, v17, v5                               // 00000057E4F0: DACC0000 0C000511
	v_xor_b32_e32 v17, 2, v0                                   // 00000057E4F8: 3A220082
	s_waitcnt lgkmcnt(1)                                       // 00000057E4FC: BF89FC17
	v_add_f32_e32 v7, v7, v14                                  // 00000057E500: 060E1D07
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057E504: BF8700A2
	v_cmp_gt_u32_e32 vcc_lo, 32, v17                           // 00000057E508: 7C9822A0
	v_cndmask_b32_e32 v17, v0, v17, vcc_lo                     // 00000057E50C: 02222300
	v_lshlrev_b32_e32 v17, 2, v17                              // 00000057E510: 30222282
	s_waitcnt lgkmcnt(0)                                       // 00000057E514: BF89FC07
	v_add_f32_e32 v5, v5, v12                                  // 00000057E518: 060A1905
	ds_bpermute_b32 v8, v17, v2                                // 00000057E51C: DACC0000 08000211
	ds_bpermute_b32 v11, v17, v4                               // 00000057E524: DACC0000 0B000411
	v_xor_b32_e32 v12, 1, v0                                   // 00000057E52C: 3A180081
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 00000057E530: BF8701D1
	v_cmp_gt_u32_e32 vcc_lo, 32, v12                           // 00000057E534: 7C9818A0
	v_cndmask_b32_e32 v0, v0, v12, vcc_lo                      // 00000057E538: 02001900
	v_add_f32_e32 v1, v1, v16                                  // 00000057E53C: 06022101
	v_cmp_eq_u32_e32 vcc_lo, 0, v30                            // 00000057E540: 7C943C80
	s_waitcnt vmcnt(0)                                         // 00000057E544: BF8903F7
	v_lshlrev_b32_e32 v19, 2, v0                               // 00000057E548: 30260082
	s_and_b32 s0, vcc_lo, s0                                   // 00000057E54C: 8B00006A
	s_waitcnt lgkmcnt(1)                                       // 00000057E550: BF89FC17
	v_add_f32_e32 v12, v2, v8                                  // 00000057E554: 06181102
	s_waitcnt lgkmcnt(0)                                       // 00000057E558: BF89FC07
	v_add_f32_e32 v8, v4, v11                                  // 00000057E55C: 06101704
	ds_bpermute_b32 v18, v17, v10                              // 00000057E560: DACC0000 12000A11
	ds_bpermute_b32 v9, v17, v3                                // 00000057E568: DACC0000 09000311
	ds_bpermute_b32 v15, v17, v6                               // 00000057E570: DACC0000 0F000611
	ds_bpermute_b32 v16, v17, v7                               // 00000057E578: DACC0000 10000711
	s_waitcnt lgkmcnt(3)                                       // 00000057E580: BF89FC37
	v_add_f32_e32 v0, v10, v18                                 // 00000057E584: 0600250A
	ds_bpermute_b32 v14, v17, v5                               // 00000057E588: DACC0000 0E000511
	ds_bpermute_b32 v17, v17, v1                               // 00000057E590: DACC0000 11000111
	s_waitcnt lgkmcnt(3)                                       // 00000057E598: BF89FC37
	v_dual_add_f32 v13, v3, v9 :: v_dual_add_f32 v4, v6, v15   // 00000057E59C: C9081303 0D041F06
	ds_bpermute_b32 v15, v19, v12                              // 00000057E5A4: DACC0000 0F000C13
	ds_bpermute_b32 v10, v19, v8                               // 00000057E5AC: DACC0000 0A000813
	ds_bpermute_b32 v3, v19, v0                                // 00000057E5B4: DACC0000 03000013
	s_waitcnt lgkmcnt(4)                                       // 00000057E5BC: BF89FC47
	v_add_f32_e32 v9, v5, v14                                  // 00000057E5C0: 06121D05
	v_add_f32_e32 v5, v7, v16                                  // 00000057E5C4: 060A2107
	s_waitcnt lgkmcnt(3)                                       // 00000057E5C8: BF89FC37
	v_add_f32_e32 v1, v1, v17                                  // 00000057E5CC: 06022301
	ds_bpermute_b32 v14, v19, v13                              // 00000057E5D0: DACC0000 0E000D13
	ds_bpermute_b32 v7, v19, v4                                // 00000057E5D8: DACC0000 07000413
	ds_bpermute_b32 v11, v19, v9                               // 00000057E5E0: DACC0000 0B000913
	ds_bpermute_b32 v6, v19, v5                                // 00000057E5E8: DACC0000 06000513
	ds_bpermute_b32 v2, v19, v1                                // 00000057E5F0: DACC0000 02000113
	s_and_saveexec_b32 s1, s0                                  // 00000057E5F8: BE812000
	s_cbranch_execz 116                                        // 00000057E5FC: BFA50074 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x13d0>
	s_waitcnt lgkmcnt(4)                                       // 00000057E600: BF89FC47
	v_dual_add_f32 v15, v12, v15 :: v_dual_add_f32 v14, v13, v14// 00000057E604: C9081F0C 0F0E1D0D
	.long 0x7f203880                                           // 00000057E60C: 7F203880
	.long 0xd73c000c                                           // 00000057E610: D73C000C
	v_cndmask_b32_e32 v1, 1, v23, vcc_lo                       // 00000057E614: 02022E81
	s_lshl_b64 s[0:1], s[12:13], 1                             // 00000057E618: 8480810C
	s_delay_alu instid0(VALU_DEP_3)                            // 00000057E61C: BF870003
	.long 0x7e20398f                                           // 00000057E620: 7E20398F
	.long 0x7e22398e                                           // 00000057E624: 7E22398E
	.long 0x7f223990                                           // 00000057E628: 7F223990
	v_add_f32_e32 v10, v8, v10                                 // 00000057E62C: 06141508
	.long 0xd7006a0c                                           // 00000057E630: D7006A0C
	v_cndmask_b32_e32 v1, s8, v12, vcc_lo                      // 00000057E634: 02021808
	s_waitcnt lgkmcnt(2)                                       // 00000057E638: BF89FC27
	v_dual_add_f32 v11, v9, v11 :: v_dual_and_b32 v18, 1, v16  // 00000057E63C: C9241709 0B122081
	v_and_b32_e32 v17, 1, v17                                  // 00000057E644: 36222281
	v_add_co_ci_u32_e64 v13, null, s9, v13, vcc_lo             // 00000057E648: D5207C0D 01AA1A09
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000057E650: BF870223
	v_add3_u32 v18, v15, v18, 0x7fff                           // 00000057E654: D6550012 03FE250F 00007FFF
	.long 0x7e20398a                                           // 00000057E660: 7E20398A
	v_add3_u32 v17, v14, v17, 0x7fff                           // 00000057E664: D6550011 03FE230E 00007FFF
	.long 0xd7006a0e                                           // 00000057E670: D7006A0E
	v_cndmask_b32_e32 v0, v12, v0, vcc_lo                      // 00000057E674: 0200010C
	s_delay_alu instid0(VALU_DEP_1)                            // 00000057E678: BF870001
	v_add_co_ci_u32_e64 v15, null, s1, v13, vcc_lo             // 00000057E67C: D5207C0F 01AA1A01
	s_clause 0x1                                               // 00000057E684: BF850001
	global_store_d16_hi_b16 v[12:13], v17, off                 // 00000057E688: DC960000 007C110C
	global_store_d16_hi_b16 v[14:15], v18, off                 // 00000057E690: DC960000 007C120E
	.long 0x7e1c398b                                           // 00000057E698: 7E1C398B
	.long 0x7f1c3990                                           // 00000057E69C: 7F1C3990
	v_add_f32_e32 v7, v4, v7                                   // 00000057E6A0: 060E0F04
	s_waitcnt lgkmcnt(1)                                       // 00000057E6A4: BF89FC17
	v_dual_add_f32 v15, v5, v6 :: v_dual_and_b32 v6, 1, v16    // 00000057E6A8: C9240D05 0F062081
	v_mad_u64_u32 v[4:5], null, s12, 6, v[12:13]               // 00000057E6B0: D6FE7C04 04310C0C
	v_and_b32_e32 v14, 1, v14                                  // 00000057E6B8: 361C1C81
	s_lshl_b64 s[0:1], s[12:13], 2                             // 00000057E6BC: 8480820C
	.long 0x7e203987                                           // 00000057E6C0: 7E203987
	.long 0xd7006a08                                           // 00000057E6C4: D7006A08
	v_cndmask_b32_e32 v0, v12, v0, vcc_lo                      // 00000057E6C8: 0200010C
	s_delay_alu instid0(VALU_DEP_1)                            // 00000057E6CC: BF870001
	v_add_co_ci_u32_e64 v9, null, s1, v13, vcc_lo              // 00000057E6D0: D5207C09 01AA1A01
	v_add3_u32 v11, v11, v14, 0x7fff                           // 00000057E6D8: D655000B 03FE1D0B 00007FFF
	.long 0x7e18398f                                           // 00000057E6E4: 7E18398F
	.long 0x7f183990                                           // 00000057E6E8: 7F183990
	v_add3_u32 v10, v10, v6, 0x7fff                            // 00000057E6EC: D655000A 03FE0D0A 00007FFF
	v_mad_u64_u32 v[5:6], null, s13, 6, v[5:6]                 // 00000057E6F8: D6FE7C05 04150C0D
	v_dual_add_f32 v13, v0, v3 :: v_dual_and_b32 v6, 1, v16    // 00000057E700: C9240700 0D062081
	global_store_d16_hi_b16 v[8:9], v11, off                   // 00000057E708: DC960000 007C0B08
	s_waitcnt lgkmcnt(0)                                       // 00000057E710: BF89FC07
	v_dual_add_f32 v12, v1, v2 :: v_dual_and_b32 v11, 1, v12   // 00000057E714: C9240501 0C0A1881
	v_add3_u32 v14, v7, v6, 0x7fff                             // 00000057E71C: D655000E 03FE0D07 00007FFF
	.long 0x7e20398d                                           // 00000057E728: 7E20398D
	.long 0x7f0c3990                                           // 00000057E72C: 7F0C3990
	.long 0xd7006a00                                           // 00000057E730: D7006A00
	v_cndmask_b32_e32 v0, v8, v0, vcc_lo                       // 00000057E734: 02000108
	.long 0x7e0c398c                                           // 00000057E738: 7E0C398C
	v_add_co_ci_u32_e64 v1, null, s1, v9, vcc_lo               // 00000057E73C: D5207C01 01AA1201
	.long 0xd7006a02                                           // 00000057E744: D7006A02
	v_cndmask_b32_e32 v0, v4, v0, vcc_lo                       // 00000057E748: 02000104
	v_and_b32_e32 v8, 1, v16                                   // 00000057E74C: 36102081
	s_delay_alu instid0(VALU_DEP_4)                            // 00000057E750: BF870004
	v_and_b32_e32 v9, 1, v6                                    // 00000057E754: 36120C81
	v_add_co_ci_u32_e64 v3, null, s1, v5, vcc_lo               // 00000057E758: D5207C03 01AA0A01
	.long 0xd7006a06                                           // 00000057E760: D7006A06
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 00000057E764: 02000100
	v_add3_u32 v11, v15, v11, 0x7fff                           // 00000057E768: D655000B 03FE170F 00007FFF
	v_add_co_ci_u32_e64 v7, null, s1, v1, vcc_lo               // 00000057E774: D5207C07 01AA0201
	v_add3_u32 v13, v13, v8, 0x7fff                            // 00000057E77C: D655000D 03FE110D 00007FFF
	.long 0xd7006a08                                           // 00000057E788: D7006A08
	v_cndmask_b32_e32 v0, v2, v0, vcc_lo                       // 00000057E78C: 02000102
	v_add3_u32 v12, v12, v9, 0x7fff                            // 00000057E790: D655000C 03FE130C 00007FFF
	v_add_co_ci_u32_e64 v9, null, s1, v3, vcc_lo               // 00000057E79C: D5207C09 01AA0601
	s_clause 0x4                                               // 00000057E7A4: BF850004
	global_store_d16_hi_b16 v[4:5], v10, off                   // 00000057E7A8: DC960000 007C0A04
	global_store_d16_hi_b16 v[0:1], v11, off                   // 00000057E7B0: DC960000 007C0B00
	global_store_d16_hi_b16 v[2:3], v14, off                   // 00000057E7B8: DC960000 007C0E02
	global_store_d16_hi_b16 v[6:7], v12, off                   // 00000057E7C0: DC960000 007C0C06
	global_store_d16_hi_b16 v[8:9], v13, off                   // 00000057E7C8: DC960000 007C0D08
	s_endpgm                                                   // 00000057E7D0: BFB00000
		...

