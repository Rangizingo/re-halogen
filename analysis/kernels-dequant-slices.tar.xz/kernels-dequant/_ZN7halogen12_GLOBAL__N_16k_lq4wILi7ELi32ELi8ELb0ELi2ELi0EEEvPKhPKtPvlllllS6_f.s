000000000081de00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi8ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi8ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 00000081DE00: F4100100 F8000000
	v_dual_mov_b32 v6, 0 :: v_dual_and_b32 v1, 15, v0          // 00000081DE08: CA240080 0600008F
	v_lshrrev_b32_e32 v2, 2, v0                                // 00000081DE10: 32040082
	s_ashr_i32 s3, s2, 31                                      // 00000081DE14: 86039F02
	v_mov_b32_e32 v5, 0                                        // 00000081DE18: 7E0A0280
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000081DE1C: BF870193
	v_dual_mov_b32 v8, 0 :: v_dual_lshlrev_b32 v1, 2, v1       // 00000081DE20: CA220080 08000282
	v_and_b32_e32 v2, 60, v2                                   // 00000081DE28: 360404BC
	v_lshrrev_b32_e32 v15, 5, v0                               // 00000081DE2C: 321E0085
	v_dual_mov_b32 v29, 0 :: v_dual_and_b32 v16, 31, v0        // 00000081DE30: CA240080 1D10009F
	.long 0x7f263880                                           // 00000081DE38: 7F263880
	v_dual_mov_b32 v17, 0 :: v_dual_lshlrev_b32 v14, 2, v0     // 00000081DE3C: CA220080 110E0082
	s_waitcnt lgkmcnt(0)                                       // 00000081DE44: BF89FC07
	s_clause 0x1                                               // 00000081DE48: BF850001
	global_load_b32 v11, v1, s[4:5]                            // 00000081DE4C: DC520000 0B040001
	global_load_b32 v13, v2, s[4:5]                            // 00000081DE54: DC520000 0D040002
	.long 0xd4510000                                           // 00000081DE5C: D4510000
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 00000081DE60: 02001802
	s_and_b32 s0, s0, exec_lo                                  // 00000081DE64: 8B007E00
	s_cselect_b32 s22, s3, 0                                   // 00000081DE68: 98168003
	s_cselect_b32 s23, s2, 0                                   // 00000081DE6C: 98178002
	s_add_u32 s0, s4, s14                                      // 00000081DE70: 80000E04
	s_addc_u32 s1, s5, s15                                     // 00000081DE74: 82010F05
	s_lshr_b32 s14, s11, 31                                    // 00000081DE78: 850E9F0B
	v_dual_mov_b32 v7, 0 :: v_dual_mov_b32 v2, s1              // 00000081DE7C: CA100080 07020001
	s_add_u32 s14, s10, s14                                    // 00000081DE84: 800E0E0A
	s_addc_u32 s15, s11, 0                                     // 00000081DE88: 820F800B
	s_ashr_i32 s20, s11, 31                                    // 00000081DE8C: 86149F0B
	s_ashr_i64 s[14:15], s[14:15], 1                           // 00000081DE90: 868E810E
	s_lshr_b32 s20, s20, 27                                    // 00000081DE94: 85149B14
	v_mov_b32_e32 v1, s0                                       // 00000081DE98: 7E020200
	s_add_u32 s20, s10, s20                                    // 00000081DE9C: 8014140A
	s_addc_u32 s21, s11, 0                                     // 00000081DEA0: 8215800B
	s_mul_i32 s19, s19, s23                                    // 00000081DEA4: 96131713
	s_lshr_b64 s[20:21], s[20:21], 5                           // 00000081DEA8: 85948514
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000081DEAC: BF870499
	s_add_i32 s21, s20, 7                                      // 00000081DEB0: 81158714
	s_ashr_i32 s24, s21, 31                                    // 00000081DEB4: 86189F15
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000081DEB8: BF870499
	s_lshr_b32 s24, s24, 29                                    // 00000081DEBC: 85189D18
	s_add_i32 s21, s21, s24                                    // 00000081DEC0: 81151815
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000081DEC4: BF870009
	s_ashr_i32 s21, s21, 3                                     // 00000081DEC8: 86158315
	s_add_u32 s0, s4, s16                                      // 00000081DECC: 80001004
	s_addc_u32 s1, s5, s17                                     // 00000081DED0: 82011105
	.long 0xd72c0012                                           // 00000081DED4: D72C0012
	v_cndmask_b32_e32 v1, s21, v15, vcc_lo                     // 00000081DED8: 02021E15
	v_mov_b32_e32 v4, s1                                       // 00000081DEDC: 7E080201
	v_mad_u64_u32 v[9:10], null, s23, s14, v[1:2]              // 00000081DEE0: D6FE7C09 04041C17
	v_mov_b32_e32 v3, s0                                       // 00000081DEE8: 7E060200
	s_mul_i32 s0, s22, s14                                     // 00000081DEEC: 96000E16
	s_waitcnt vmcnt(1)                                         // 00000081DEF0: BF8907F7
	v_bfe_u32 v12, v11, 16, 1                                  // 00000081DEF4: D610000C 0205210B
	s_waitcnt vmcnt(0)                                         // 00000081DEFC: BF8903F7
	v_bfe_u32 v1, v13, 16, 1                                   // 00000081DF00: D6100001 0205210D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000081DF08: BF870112
	v_add3_u32 v2, v11, v12, 0x7fff                            // 00000081DF0C: D6550002 03FE190B 00007FFF
	v_add3_u32 v1, v13, v1, 0x7fff                             // 00000081DF18: D6550001 03FE030D 00007FFF
	s_delay_alu instid0(VALU_DEP_2)                            // 00000081DF24: BF870002
	.long 0x7e263982                                           // 00000081DF28: 7E263982
	v_add_nc_u32_e32 v2, s0, v10                               // 00000081DF2C: 4A041400
	v_mad_u64_u32 v[11:12], null, s18, s23, v[3:4]             // 00000081DF30: D6FE7C0B 040C2E12
	v_add_nc_u32_e32 v3, s21, v18                              // 00000081DF38: 4A062415
	v_add_nc_u32_e32 v10, v18, v16                             // 00000081DF3C: 4A142112
	s_mul_i32 s23, s23, s15                                    // 00000081DF40: 96170F17
	s_mul_i32 s0, s18, s22                                     // 00000081DF44: 96001612
	v_and_or_b32 v1, 0xffff0000, v1, v19                       // 00000081DF48: D6570001 044E02FF FFFF0000
	v_min_i32_e32 v18, s20, v3                                 // 00000081DF54: 22240614
	v_add_nc_u32_e32 v19, s23, v2                              // 00000081DF58: 4A260417
	v_add_nc_u32_e32 v3, s19, v12                              // 00000081DF5C: 4A061813
	ds_store_b32 v14, v1                                       // 00000081DF60: D8340000 0000010E
	v_cmp_lt_i32_e32 vcc_lo, v10, v18                          // 00000081DF68: 7C82250A
	v_add_nc_u32_e32 v20, s0, v3                               // 00000081DF6C: 4A280600
	s_waitcnt lgkmcnt(0)                                       // 00000081DF70: BF89FC07
	s_barrier                                                  // 00000081DF74: BFBD0000
	buffer_gl0_inv                                             // 00000081DF78: E0AC0000 00000000
	s_and_saveexec_b32 s1, vcc_lo                              // 00000081DF80: BE81206A
	s_cbranch_execz 21                                         // 00000081DF84: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi8ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0x1dc>
	v_lshlrev_b32_e32 v1, 1, v10                               // 00000081DF88: 30021481
	v_lshlrev_b32_e32 v3, 4, v10                               // 00000081DF8C: 30061484
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000081DF90: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000081DF94: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 00000081DF98: 3408069F
	.long 0xd7000001                                           // 00000081DF9C: D7000001
	v_cndmask_b32_e32 v1, v11, v1, vcc_lo                      // 00000081DFA0: 0202030B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000081DFA4: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v20, v2, s0                  // 00000081DFA8: D5207C02 00020514
	.long 0xd7000003                                           // 00000081DFB0: D7000003
	v_cndmask_b32_e32 v1, v9, v3, vcc_lo                       // 00000081DFB4: 02020709
	v_add_co_ci_u32_e64 v4, null, v19, v4, s0                  // 00000081DFB8: D5207C04 00020913
	s_clause 0x1                                               // 00000081DFC0: BF850001
	global_load_d16_b16 v1, v[1:2], off                        // 00000081DFC4: DC820000 017C0001
	global_load_b128 v[5:8], v[3:4], off                       // 00000081DFCC: DC5E0000 057C0003
	s_waitcnt vmcnt(1)                                         // 00000081DFD4: BF8907F7
	v_cvt_f32_f16_e32 v29, v1                                  // 00000081DFD8: 7E3A1701
	s_or_b32 exec_lo, exec_lo, s1                              // 00000081DFDC: 8C7E017E
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v23, 0             // 00000081DFE0: CA100080 16160080
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v25, 0             // 00000081DFE8: CA100080 18180080
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v21, 0             // 00000081DFF0: CA100080 1A140080
	s_and_saveexec_b32 s1, vcc_lo                              // 00000081DFF8: BE81206A
	s_cbranch_execz 579                                        // 00000081DFFC: BFA50243 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi8ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0xb0c>
	v_dual_mov_b32 v26, 0 :: v_dual_add_nc_u32 v1, 32, v10     // 00000081E000: CA200080 1A0014A0
	v_dual_mov_b32 v21, 0 :: v_dual_lshlrev_b32 v12, 5, v10    // 00000081E008: CA220080 150C1485
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v22, 0             // 00000081E010: CA100080 17160080
	s_delay_alu instid0(VALU_DEP_3)                            // 00000081E018: BF870003
	v_dual_mov_b32 v24, 0 :: v_dual_lshlrev_b32 v27, 4, v1     // 00000081E01C: CA220080 181A0284
	v_dual_mov_b32 v25, 0 :: v_dual_lshlrev_b32 v28, 1, v1     // 00000081E024: CA220080 191C0281
	v_dual_mov_b32 v17, 0 :: v_dual_mov_b32 v30, v29           // 00000081E02C: CA100080 111E011D
	s_mul_i32 s0, s11, 6                                       // 00000081E034: 9600860B
	s_mul_hi_u32 s14, s10, 6                                   // 00000081E038: 968E860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 00000081E03C: 8484820A
	s_add_i32 s14, s14, s0                                     // 00000081E040: 810E000E
	s_mul_i32 s16, s10, 6                                      // 00000081E044: 9610860A
	s_mov_b32 s15, 0                                           // 00000081E048: BE8F0080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 00000081E04C: 848A810A
	s_branch 526                                               // 00000081E050: BFA0020E <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi8ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0xa8c>
	s_or_b32 exec_lo, exec_lo, s17                             // 00000081E054: 8C7E117E
	v_and_b32_e32 v13, 0xff, v5                                // 00000081E058: 361A0AFF 000000FF
	s_and_b32 s0, exec_lo, vcc_lo                              // 00000081E060: 8B006A7E
	v_add_nc_u32_e32 v27, 0x200, v27                           // 00000081E064: 4A3636FF 00000200
	s_or_b32 s15, s0, s15                                      // 00000081E06C: 8C0F0F00
	v_add_nc_u32_e32 v28, 64, v28                              // 00000081E070: 4A3838C0
	v_lshlrev_b32_e32 v13, 2, v13                              // 00000081E074: 301A1A82
	ds_load_b32 v47, v13                                       // 00000081E078: D8D80000 2F00000D
	v_lshrrev_b32_e32 v13, 6, v5                               // 00000081E080: 321A0A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000081E084: BF870141
	v_and_b32_e32 v13, 0x3fc, v13                              // 00000081E088: 361A1AFF 000003FC
	ds_load_b32 v48, v13                                       // 00000081E090: D8D80000 3000000D
	v_lshrrev_b32_e32 v13, 14, v5                              // 00000081E098: 321A0A8E
	v_lshrrev_b32_e32 v5, 22, v5                               // 00000081E09C: 320A0A96
	v_and_b32_e32 v13, 0x3fc, v13                              // 00000081E0A0: 361A1AFF 000003FC
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 00000081E0A8: BF870152
	v_and_b32_e32 v5, 0x3fc, v5                                // 00000081E0AC: 360A0AFF 000003FC
	ds_load_b32 v49, v13                                       // 00000081E0B4: D8D80000 3100000D
	ds_load_b32 v50, v5                                        // 00000081E0BC: D8D80000 32000005
	v_and_b32_e32 v5, 0xff, v6                                 // 00000081E0C4: 360A0CFF 000000FF
	v_ashrrev_i32_e32 v13, 31, v12                             // 00000081E0CC: 341A189F
	v_lshlrev_b32_e32 v5, 2, v5                                // 00000081E0D0: 300A0A82
	ds_load_b32 v51, v5                                        // 00000081E0D4: D8D80000 33000005
	v_lshrrev_b32_e32 v5, 6, v6                                // 00000081E0DC: 320A0C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000081E0E0: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 00000081E0E4: 360A0AFF 000003FC
	ds_load_b32 v52, v5                                        // 00000081E0EC: D8D80000 34000005
	v_lshrrev_b32_e32 v5, 14, v6                               // 00000081E0F4: 320A0C8E
	v_and_b32_e32 v5, 0x3fc, v5                                // 00000081E0F8: 360A0AFF 000003FC
	ds_load_b32 v53, v5                                        // 00000081E100: D8D80000 35000005
	v_lshrrev_b32_e32 v5, 22, v6                               // 00000081E108: 320A0C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000081E10C: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 00000081E110: 360A0AFF 000003FC
	ds_load_b32 v54, v5                                        // 00000081E118: D8D80000 36000005
	v_and_b32_e32 v5, 0xff, v7                                 // 00000081E120: 360A0EFF 000000FF
	v_lshlrev_b32_e32 v5, 2, v5                                // 00000081E128: 300A0A82
	ds_load_b32 v55, v5                                        // 00000081E12C: D8D80000 37000005
	v_lshrrev_b32_e32 v5, 6, v7                                // 00000081E134: 320A0E86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000081E138: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 00000081E13C: 360A0AFF 000003FC
	ds_load_b32 v56, v5                                        // 00000081E144: D8D80000 38000005
	v_lshrrev_b32_e32 v5, 14, v7                               // 00000081E14C: 320A0E8E
	v_and_b32_e32 v5, 0x3fc, v5                                // 00000081E150: 360A0AFF 000003FC
	ds_load_b32 v57, v5                                        // 00000081E158: D8D80000 39000005
	v_lshrrev_b32_e32 v5, 22, v7                               // 00000081E160: 320A0E96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000081E164: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 00000081E168: 360A0AFF 000003FC
	ds_load_b32 v58, v5                                        // 00000081E170: D8D80000 3A000005
	v_and_b32_e32 v5, 0xff, v8                                 // 00000081E178: 360A10FF 000000FF
	v_lshlrev_b32_e32 v5, 2, v5                                // 00000081E180: 300A0A82
	ds_load_b32 v59, v5                                        // 00000081E184: D8D80000 3B000005
	v_lshrrev_b32_e32 v5, 6, v8                                // 00000081E18C: 320A1086
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000081E190: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 00000081E194: 360A0AFF 000003FC
	ds_load_b32 v60, v5                                        // 00000081E19C: D8D80000 3C000005
	v_lshrrev_b32_e32 v5, 14, v8                               // 00000081E1A4: 320A108E
	v_and_b32_e32 v5, 0x3fc, v5                                // 00000081E1A8: 360A0AFF 000003FC
	ds_load_b32 v61, v5                                        // 00000081E1B0: D8D80000 3D000005
	v_lshrrev_b32_e32 v5, 22, v8                               // 00000081E1B8: 320A1096
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000081E1BC: BF870141
	v_and_b32_e32 v5, 0x3fc, v5                                // 00000081E1C0: 360A0AFF 000003FC
	ds_load_b32 v62, v5                                        // 00000081E1C8: D8D80000 3E000005
	.long 0xd73c0005                                           // 00000081E1D0: D73C0005
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 00000081E1D4: 02021881
	v_add_nc_u32_e32 v12, 0x400, v12                           // 00000081E1D8: 4A1818FF 00000400
	.long 0xd7006a2b                                           // 00000081E1E0: D7006A2B
	v_cndmask_b32_e32 v1, s6, v5, vcc_lo                       // 00000081E1E4: 02020A06
	s_delay_alu instid0(VALU_DEP_1)                            // 00000081E1E8: BF870001
	v_add_co_ci_u32_e64 v44, null, s7, v6, vcc_lo              // 00000081E1EC: D5207C2C 01AA0C07
	s_clause 0x3                                               // 00000081E1F4: BF850003
	global_load_b128 v[5:8], v[43:44], off                     // 00000081E1F8: DC5E0000 057C002B
	global_load_b128 v[31:34], v[43:44], off offset:16         // 00000081E200: DC5E0010 1F7C002B
	global_load_b128 v[35:38], v[43:44], off offset:32         // 00000081E208: DC5E0020 237C002B
	global_load_b128 v[39:42], v[43:44], off offset:48         // 00000081E210: DC5E0030 277C002B
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 00000081E218: BF890CF7
	v_dot2_f32_bf16 v5, v5, v47, 0                             // 00000081E21C: CC1A4005 1A025F05
	s_waitcnt lgkmcnt(14)                                      // 00000081E224: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000081E228: BF8700A1
	v_dot2_f32_bf16 v5, v6, v48, v5                            // 00000081E22C: CC1A4005 1C166106
	s_waitcnt lgkmcnt(13)                                      // 00000081E234: BF89FCD7
	v_dot2_f32_bf16 v5, v7, v49, v5                            // 00000081E238: CC1A4005 1C166307
	s_waitcnt lgkmcnt(12)                                      // 00000081E240: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000081E244: BF8700A1
	v_dot2_f32_bf16 v5, v8, v50, v5                            // 00000081E248: CC1A4005 1C166508
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 00000081E250: BF8908B7
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 00000081E254: CC1A4005 1C16671F
	s_waitcnt lgkmcnt(10)                                      // 00000081E25C: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000081E260: BF8700A1
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 00000081E264: CC1A4005 1C166920
	s_waitcnt lgkmcnt(9)                                       // 00000081E26C: BF89FC97
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 00000081E270: CC1A4005 1C166B21
	s_waitcnt lgkmcnt(8)                                       // 00000081E278: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000081E27C: BF8700A1
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 00000081E280: CC1A4005 1C166D22
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 00000081E288: BF890477
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 00000081E28C: CC1A4005 1C166F23
	s_waitcnt lgkmcnt(6)                                       // 00000081E294: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000081E298: BF8700A1
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 00000081E29C: CC1A4005 1C167124
	s_waitcnt lgkmcnt(5)                                       // 00000081E2A4: BF89FC57
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 00000081E2A8: CC1A4005 1C167325
	s_waitcnt lgkmcnt(4)                                       // 00000081E2B0: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000081E2B4: BF8700A1
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 00000081E2B8: CC1A4005 1C167526
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 00000081E2C0: BF890037
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 00000081E2C4: CC1A4005 1C167727
	.long 0xd7006a27                                           // 00000081E2CC: D7006A27
	v_cndmask_b32_e32 v0, v43, v10, vcc_lo                     // 00000081E2D0: 0200152B
	s_waitcnt lgkmcnt(2)                                       // 00000081E2D4: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000081E2D8: BF8701C2
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 00000081E2DC: CC1A4005 1C167928
	v_add_co_ci_u32_e64 v40, null, s11, v44, vcc_lo            // 00000081E2E4: D5207C28 01AA580B
	.long 0xd7006a2d                                           // 00000081E2EC: D7006A2D
	v_cndmask_b32_e32 v0, v43, v4, vcc_lo                      // 00000081E2F0: 0200092B
	s_waitcnt lgkmcnt(1)                                       // 00000081E2F4: BF89FC17
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 00000081E2F8: CC1A4005 1C167B29
	v_add_co_ci_u32_e64 v46, null, s5, v44, vcc_lo             // 00000081E300: D5207C2E 01AA5805
	.long 0xd7006a2b                                           // 00000081E308: D7006A2B
	v_cndmask_b32_e32 v0, v43, v16, vcc_lo                     // 00000081E30C: 0200212B
	s_waitcnt lgkmcnt(0)                                       // 00000081E310: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000081E314: BF870123
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 00000081E318: CC1A4005 1C167D2A
	v_add_co_ci_u32_e64 v44, null, s14, v44, vcc_lo            // 00000081E320: D5207C2C 01AA580E
	v_fmac_f32_e32 v21, v29, v5                                // 00000081E328: 562A0B1D
	s_clause 0x3                                               // 00000081E32C: BF850003
	global_load_b128 v[5:8], v[39:40], off                     // 00000081E330: DC5E0000 057C0027
	global_load_b128 v[31:34], v[39:40], off offset:16         // 00000081E338: DC5E0010 1F7C0027
	global_load_b128 v[35:38], v[39:40], off offset:32         // 00000081E340: DC5E0020 237C0027
	global_load_b128 v[39:42], v[39:40], off offset:48         // 00000081E348: DC5E0030 277C0027
	s_waitcnt vmcnt(3)                                         // 00000081E350: BF890FF7
	v_dot2_f32_bf16 v5, v5, v47, 0                             // 00000081E354: CC1A4005 1A025F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081E35C: BF870091
	v_dot2_f32_bf16 v5, v6, v48, v5                            // 00000081E360: CC1A4005 1C166106
	v_dot2_f32_bf16 v5, v7, v49, v5                            // 00000081E368: CC1A4005 1C166307
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000081E370: BF8700A1
	v_dot2_f32_bf16 v5, v8, v50, v5                            // 00000081E374: CC1A4005 1C166508
	s_waitcnt vmcnt(2)                                         // 00000081E37C: BF890BF7
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 00000081E380: CC1A4005 1C16671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081E388: BF870091
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 00000081E38C: CC1A4005 1C166920
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 00000081E394: CC1A4005 1C166B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000081E39C: BF8700A1
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 00000081E3A0: CC1A4005 1C166D22
	s_waitcnt vmcnt(1)                                         // 00000081E3A8: BF8907F7
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 00000081E3AC: CC1A4005 1C166F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081E3B4: BF870091
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 00000081E3B8: CC1A4005 1C167124
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 00000081E3C0: CC1A4005 1C167325
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000081E3C8: BF8700A1
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 00000081E3CC: CC1A4005 1C167526
	s_waitcnt vmcnt(0)                                         // 00000081E3D4: BF8903F7
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 00000081E3D8: CC1A4005 1C167727
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081E3E0: BF870091
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 00000081E3E4: CC1A4005 1C167928
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 00000081E3EC: CC1A4005 1C167B29
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081E3F4: BF870091
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 00000081E3F8: CC1A4005 1C167D2A
	v_fmac_f32_e32 v26, v29, v5                                // 00000081E400: 56340B1D
	s_clause 0x3                                               // 00000081E404: BF850003
	global_load_b128 v[5:8], v[45:46], off                     // 00000081E408: DC5E0000 057C002D
	global_load_b128 v[31:34], v[45:46], off offset:16         // 00000081E410: DC5E0010 1F7C002D
	global_load_b128 v[35:38], v[45:46], off offset:32         // 00000081E418: DC5E0020 237C002D
	global_load_b128 v[39:42], v[45:46], off offset:48         // 00000081E420: DC5E0030 277C002D
	.long 0xd7006a2d                                           // 00000081E428: D7006A2D
	v_cndmask_b32_e32 v0, v45, v4, vcc_lo                      // 00000081E42C: 0200092D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000081E430: BF8700B1
	v_add_co_ci_u32_e64 v46, null, s5, v46, vcc_lo             // 00000081E434: D5207C2E 01AA5C05
	s_waitcnt vmcnt(3)                                         // 00000081E43C: BF890FF7
	v_dot2_f32_bf16 v5, v5, v47, 0                             // 00000081E440: CC1A4005 1A025F05
	v_dot2_f32_bf16 v5, v6, v48, v5                            // 00000081E448: CC1A4005 1C166106
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081E450: BF870091
	v_dot2_f32_bf16 v5, v7, v49, v5                            // 00000081E454: CC1A4005 1C166307
	v_dot2_f32_bf16 v5, v8, v50, v5                            // 00000081E45C: CC1A4005 1C166508
	s_waitcnt vmcnt(2)                                         // 00000081E464: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081E468: BF870091
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 00000081E46C: CC1A4005 1C16671F
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 00000081E474: CC1A4005 1C166920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081E47C: BF870091
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 00000081E480: CC1A4005 1C166B21
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 00000081E488: CC1A4005 1C166D22
	s_waitcnt vmcnt(1)                                         // 00000081E490: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081E494: BF870091
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 00000081E498: CC1A4005 1C166F23
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 00000081E4A0: CC1A4005 1C167124
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081E4A8: BF870091
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 00000081E4AC: CC1A4005 1C167325
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 00000081E4B4: CC1A4005 1C167526
	s_waitcnt vmcnt(0)                                         // 00000081E4BC: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081E4C0: BF870091
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 00000081E4C4: CC1A4005 1C167727
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 00000081E4CC: CC1A4005 1C167928
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081E4D4: BF870091
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 00000081E4D8: CC1A4005 1C167B29
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 00000081E4E0: CC1A4005 1C167D2A
	s_delay_alu instid0(VALU_DEP_1)                            // 00000081E4E8: BF870001
	v_fmac_f32_e32 v25, v29, v5                                // 00000081E4EC: 56320B1D
	s_clause 0x3                                               // 00000081E4F0: BF850003
	global_load_b128 v[5:8], v[43:44], off                     // 00000081E4F4: DC5E0000 057C002B
	global_load_b128 v[31:34], v[43:44], off offset:16         // 00000081E4FC: DC5E0010 1F7C002B
	global_load_b128 v[35:38], v[43:44], off offset:32         // 00000081E504: DC5E0020 237C002B
	global_load_b128 v[39:42], v[43:44], off offset:48         // 00000081E50C: DC5E0030 277C002B
	s_waitcnt vmcnt(3)                                         // 00000081E514: BF890FF7
	v_dot2_f32_bf16 v5, v5, v47, 0                             // 00000081E518: CC1A4005 1A025F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081E520: BF870091
	v_dot2_f32_bf16 v5, v6, v48, v5                            // 00000081E524: CC1A4005 1C166106
	v_dot2_f32_bf16 v5, v7, v49, v5                            // 00000081E52C: CC1A4005 1C166307
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000081E534: BF8700A1
	v_dot2_f32_bf16 v5, v8, v50, v5                            // 00000081E538: CC1A4005 1C166508
	s_waitcnt vmcnt(2)                                         // 00000081E540: BF890BF7
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 00000081E544: CC1A4005 1C16671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081E54C: BF870091
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 00000081E550: CC1A4005 1C166920
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 00000081E558: CC1A4005 1C166B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000081E560: BF8700A1
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 00000081E564: CC1A4005 1C166D22
	s_waitcnt vmcnt(1)                                         // 00000081E56C: BF8907F7
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 00000081E570: CC1A4005 1C166F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081E578: BF870091
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 00000081E57C: CC1A4005 1C167124
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 00000081E584: CC1A4005 1C167325
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000081E58C: BF8700A1
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 00000081E590: CC1A4005 1C167526
	s_waitcnt vmcnt(0)                                         // 00000081E598: BF8903F7
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 00000081E59C: CC1A4005 1C167727
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081E5A4: BF870091
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 00000081E5A8: CC1A4005 1C167928
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 00000081E5B0: CC1A4005 1C167B29
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081E5B8: BF870091
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 00000081E5BC: CC1A4005 1C167D2A
	v_fmac_f32_e32 v24, v29, v5                                // 00000081E5C4: 56300B1D
	s_clause 0x3                                               // 00000081E5C8: BF850003
	global_load_b128 v[5:8], v[45:46], off                     // 00000081E5CC: DC5E0000 057C002D
	global_load_b128 v[31:34], v[45:46], off offset:16         // 00000081E5D4: DC5E0010 1F7C002D
	global_load_b128 v[35:38], v[45:46], off offset:32         // 00000081E5DC: DC5E0020 237C002D
	global_load_b128 v[39:42], v[45:46], off offset:48         // 00000081E5E4: DC5E0030 277C002D
	s_waitcnt vmcnt(3)                                         // 00000081E5EC: BF890FF7
	v_dot2_f32_bf16 v5, v5, v47, 0                             // 00000081E5F0: CC1A4005 1A025F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081E5F8: BF870091
	v_dot2_f32_bf16 v5, v6, v48, v5                            // 00000081E5FC: CC1A4005 1C166106
	v_dot2_f32_bf16 v5, v7, v49, v5                            // 00000081E604: CC1A4005 1C166307
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000081E60C: BF8700A1
	v_dot2_f32_bf16 v5, v8, v50, v5                            // 00000081E610: CC1A4005 1C166508
	s_waitcnt vmcnt(2)                                         // 00000081E618: BF890BF7
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 00000081E61C: CC1A4005 1C16671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081E624: BF870091
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 00000081E628: CC1A4005 1C166920
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 00000081E630: CC1A4005 1C166B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000081E638: BF8700A1
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 00000081E63C: CC1A4005 1C166D22
	s_waitcnt vmcnt(1)                                         // 00000081E644: BF8907F7
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 00000081E648: CC1A4005 1C166F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081E650: BF870091
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 00000081E654: CC1A4005 1C167124
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 00000081E65C: CC1A4005 1C167325
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000081E664: BF8700A1
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 00000081E668: CC1A4005 1C167526
	s_waitcnt vmcnt(0)                                         // 00000081E670: BF8903F7
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 00000081E674: CC1A4005 1C167727
	.long 0xd7006a27                                           // 00000081E67C: D7006A27
	v_cndmask_b32_e32 v0, v43, v4, vcc_lo                      // 00000081E680: 0200092B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000081E684: BF870122
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 00000081E688: CC1A4005 1C167928
	v_add_co_ci_u32_e64 v40, null, s5, v44, vcc_lo             // 00000081E690: D5207C28 01AA5805
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 00000081E698: CC1A4005 1C167B29
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081E6A0: BF870091
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 00000081E6A4: CC1A4005 1C167D2A
	v_fmac_f32_e32 v23, v29, v5                                // 00000081E6AC: 562E0B1D
	s_clause 0x3                                               // 00000081E6B0: BF850003
	global_load_b128 v[5:8], v[39:40], off                     // 00000081E6B4: DC5E0000 057C0027
	global_load_b128 v[31:34], v[39:40], off offset:16         // 00000081E6BC: DC5E0010 1F7C0027
	global_load_b128 v[35:38], v[39:40], off offset:32         // 00000081E6C4: DC5E0020 237C0027
	global_load_b128 v[39:42], v[39:40], off offset:48         // 00000081E6CC: DC5E0030 277C0027
	s_waitcnt vmcnt(3)                                         // 00000081E6D4: BF890FF7
	v_dot2_f32_bf16 v5, v5, v47, 0                             // 00000081E6D8: CC1A4005 1A025F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081E6E0: BF870091
	v_dot2_f32_bf16 v5, v6, v48, v5                            // 00000081E6E4: CC1A4005 1C166106
	v_dot2_f32_bf16 v5, v7, v49, v5                            // 00000081E6EC: CC1A4005 1C166307
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000081E6F4: BF8700A1
	v_dot2_f32_bf16 v5, v8, v50, v5                            // 00000081E6F8: CC1A4005 1C166508
	s_waitcnt vmcnt(2)                                         // 00000081E700: BF890BF7
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 00000081E704: CC1A4005 1C16671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081E70C: BF870091
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 00000081E710: CC1A4005 1C166920
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 00000081E718: CC1A4005 1C166B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000081E720: BF8700A1
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 00000081E724: CC1A4005 1C166D22
	s_waitcnt vmcnt(1)                                         // 00000081E72C: BF8907F7
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 00000081E730: CC1A4005 1C166F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081E738: BF870091
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 00000081E73C: CC1A4005 1C167124
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 00000081E744: CC1A4005 1C167325
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000081E74C: BF8700A1
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 00000081E750: CC1A4005 1C167526
	s_waitcnt vmcnt(0)                                         // 00000081E758: BF8903F7
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 00000081E75C: CC1A4005 1C167727
	.long 0xd7006a27                                           // 00000081E764: D7006A27
	v_cndmask_b32_e32 v0, v45, v4, vcc_lo                      // 00000081E768: 0200092D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000081E76C: BF870122
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 00000081E770: CC1A4005 1C167928
	v_add_co_ci_u32_e64 v40, null, s5, v46, vcc_lo             // 00000081E778: D5207C28 01AA5C05
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 00000081E780: CC1A4005 1C167B29
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081E788: BF870091
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 00000081E78C: CC1A4005 1C167D2A
	v_fmac_f32_e32 v22, v29, v5                                // 00000081E794: 562C0B1D
	s_clause 0x3                                               // 00000081E798: BF850003
	global_load_b128 v[5:8], v[39:40], off                     // 00000081E79C: DC5E0000 057C0027
	global_load_b128 v[31:34], v[39:40], off offset:16         // 00000081E7A4: DC5E0010 1F7C0027
	global_load_b128 v[35:38], v[39:40], off offset:32         // 00000081E7AC: DC5E0020 237C0027
	global_load_b128 v[39:42], v[39:40], off offset:48         // 00000081E7B4: DC5E0030 277C0027
	s_waitcnt vmcnt(3)                                         // 00000081E7BC: BF890FF7
	v_dot2_f32_bf16 v5, v5, v47, 0                             // 00000081E7C0: CC1A4005 1A025F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000081E7C8: BF870121
	v_dot2_f32_bf16 v5, v6, v48, v5                            // 00000081E7CC: CC1A4005 1C166106
	v_mov_b32_e32 v6, v2                                       // 00000081E7D4: 7E0C0302
	v_dot2_f32_bf16 v5, v7, v49, v5                            // 00000081E7D8: CC1A4005 1C166307
	v_mov_b32_e32 v7, v3                                       // 00000081E7E0: 7E0E0303
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000081E7E4: BF870132
	v_dot2_f32_bf16 v5, v8, v50, v5                            // 00000081E7E8: CC1A4005 1C166508
	v_mov_b32_e32 v8, v4                                       // 00000081E7F0: 7E100304
	s_waitcnt vmcnt(2)                                         // 00000081E7F4: BF890BF7
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 00000081E7F8: CC1A4005 1C16671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081E800: BF870091
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 00000081E804: CC1A4005 1C166920
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 00000081E80C: CC1A4005 1C166B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000081E814: BF8700A1
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 00000081E818: CC1A4005 1C166D22
	s_waitcnt vmcnt(1)                                         // 00000081E820: BF8907F7
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 00000081E824: CC1A4005 1C166F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081E82C: BF870091
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 00000081E830: CC1A4005 1C167124
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 00000081E838: CC1A4005 1C167325
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000081E840: BF8700A1
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 00000081E844: CC1A4005 1C167526
	s_waitcnt vmcnt(0)                                         // 00000081E84C: BF8903F7
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 00000081E850: CC1A4005 1C167727
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081E858: BF870091
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 00000081E85C: CC1A4005 1C167928
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 00000081E864: CC1A4005 1C167B29
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081E86C: BF870091
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 00000081E870: CC1A4005 1C167D2A
	v_fmac_f32_e32 v17, v29, v5                                // 00000081E878: 56220B1D
	v_mov_b32_e32 v5, v1                                       // 00000081E87C: 7E0A0301
	v_mov_b32_e32 v29, v30                                     // 00000081E880: 7E3A031E
	s_and_not1_b32 exec_lo, exec_lo, s15                       // 00000081E884: 917E0F7E
	s_cbranch_execz 31                                         // 00000081E888: BFA5001F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi8ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0xb08>
	s_waitcnt vmcnt(0)                                         // 00000081E88C: BF8903F7
	v_dual_mov_b32 v1, v5 :: v_dual_add_nc_u32 v10, 32, v10    // 00000081E890: CA200105 010A14A0
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v3, v7             // 00000081E898: CA100106 02020107
	v_mov_b32_e32 v4, v8                                       // 00000081E8A0: 7E080308
	s_mov_b32 s17, exec_lo                                     // 00000081E8A4: BE91007E
	s_delay_alu instid0(VALU_DEP_3)                            // 00000081E8A8: BF870003
	v_cmp_ge_i32_e32 vcc_lo, v10, v18                          // 00000081E8AC: 7C8C250A
	.long 0xd4c1007e                                           // 00000081E8B0: D4C1007E
	v_cndmask_b32_e32 v1, v10, v18, vcc_lo                     // 00000081E8B4: 0202250A
	s_cbranch_execz 64998                                      // 00000081E8B8: BFA5FDE6 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi8ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0x254>
	v_ashrrev_i32_e32 v2, 31, v28                              // 00000081E8BC: 3404389F
	v_ashrrev_i32_e32 v4, 31, v27                              // 00000081E8C0: 3408369F
	.long 0xd7000001                                           // 00000081E8C4: D7000001
	v_cndmask_b32_e32 v1, v11, v28, vcc_lo                     // 00000081E8C8: 0202390B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000081E8CC: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v20, v2, s0                  // 00000081E8D0: D5207C02 00020514
	.long 0xd7000003                                           // 00000081E8D8: D7000003
	v_cndmask_b32_e32 v1, v9, v27, vcc_lo                      // 00000081E8DC: 02023709
	v_add_co_ci_u32_e64 v4, null, v19, v4, s0                  // 00000081E8E0: D5207C04 00020913
	s_clause 0x1                                               // 00000081E8E8: BF850001
	global_load_d16_b16 v13, v[1:2], off                       // 00000081E8EC: DC820000 0D7C0001
	global_load_b128 v[1:4], v[3:4], off                       // 00000081E8F4: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 00000081E8FC: BF8907F7
	v_cvt_f32_f16_e32 v30, v13                                 // 00000081E900: 7E3C170D
	s_branch 64979                                             // 00000081E904: BFA0FDD3 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi8ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0x254>
	s_or_b32 exec_lo, exec_lo, s15                             // 00000081E908: 8C7E0F7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000081E90C: BF8700B9
	s_or_b32 exec_lo, exec_lo, s1                              // 00000081E910: 8C7E017E
	.long 0xd71f0001                                           // 00000081E914: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000081E918: 020100C1
	s_mov_b32 s0, exec_lo                                      // 00000081E91C: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 00000081E920: 3A040290
	v_xor_b32_e32 v9, 8, v1                                    // 00000081E924: 3A120288
	v_xor_b32_e32 v19, 4, v1                                   // 00000081E928: 3A260284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000081E92C: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 00000081E930: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 00000081E934: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v9                            // 00000081E938: 7C9812A0
	v_cndmask_b32_e32 v9, v1, v9, vcc_lo                       // 00000081E93C: 02121301
	v_cmp_gt_u32_e32 vcc_lo, 32, v19                           // 00000081E940: 7C9826A0
	s_delay_alu instid0(VALU_DEP_2)                            // 00000081E944: BF870002
	v_lshlrev_b32_e32 v9, 2, v9                                // 00000081E948: 30121282
	v_lshlrev_b32_e32 v2, 2, v2                                // 00000081E94C: 30040482
	ds_bpermute_b32 v3, v2, v21                                // 00000081E950: DACC0000 03001502
	s_waitcnt lgkmcnt(0)                                       // 00000081E958: BF89FC07
	v_add_f32_e32 v3, v21, v3                                  // 00000081E95C: 06060715
	s_waitcnt vmcnt(0)                                         // 00000081E960: BF8903F7
	ds_bpermute_b32 v5, v2, v25                                // 00000081E964: DACC0000 05001902
	ds_bpermute_b32 v6, v2, v24                                // 00000081E96C: DACC0000 06001802
	ds_bpermute_b32 v4, v2, v26                                // 00000081E974: DACC0000 04001A02
	ds_bpermute_b32 v7, v2, v23                                // 00000081E97C: DACC0000 07001702
	ds_bpermute_b32 v8, v2, v22                                // 00000081E984: DACC0000 08001602
	ds_bpermute_b32 v2, v2, v17                                // 00000081E98C: DACC0000 02001102
	ds_bpermute_b32 v10, v9, v3                                // 00000081E994: DACC0000 0A000309
	s_waitcnt lgkmcnt(5)                                       // 00000081E99C: BF89FC57
	v_dual_add_f32 v5, v25, v5 :: v_dual_add_f32 v6, v24, v6   // 00000081E9A0: C9080B19 05060D18
	s_waitcnt lgkmcnt(3)                                       // 00000081E9A8: BF89FC37
	v_dual_add_f32 v4, v26, v4 :: v_dual_add_f32 v7, v23, v7   // 00000081E9AC: C908091A 04060F17
	s_waitcnt lgkmcnt(2)                                       // 00000081E9B4: BF89FC27
	v_add_f32_e32 v8, v22, v8                                  // 00000081E9B8: 06101116
	ds_bpermute_b32 v12, v9, v5                                // 00000081E9BC: DACC0000 0C000509
	ds_bpermute_b32 v13, v9, v6                                // 00000081E9C4: DACC0000 0D000609
	ds_bpermute_b32 v11, v9, v4                                // 00000081E9CC: DACC0000 0B000409
	v_cndmask_b32_e32 v19, v1, v19, vcc_lo                     // 00000081E9D4: 02262701
	ds_bpermute_b32 v18, v9, v8                                // 00000081E9D8: DACC0000 12000809
	s_waitcnt lgkmcnt(4)                                       // 00000081E9E0: BF89FC47
	v_add_f32_e32 v3, v3, v10                                  // 00000081E9E4: 06061503
	s_waitcnt lgkmcnt(2)                                       // 00000081E9E8: BF89FC27
	v_dual_add_f32 v5, v5, v12 :: v_dual_add_f32 v6, v6, v13   // 00000081E9EC: C9081905 05061B06
	v_dual_add_f32 v2, v17, v2 :: v_dual_lshlrev_b32 v19, 2, v19// 00000081E9F4: C9220511 02122682
	ds_bpermute_b32 v17, v9, v7                                // 00000081E9FC: DACC0000 11000709
	s_waitcnt lgkmcnt(2)                                       // 00000081EA04: BF89FC27
	v_add_f32_e32 v4, v4, v11                                  // 00000081EA08: 06081704
	s_waitcnt lgkmcnt(1)                                       // 00000081EA0C: BF89FC17
	v_add_f32_e32 v8, v8, v18                                  // 00000081EA10: 06102508
	ds_bpermute_b32 v9, v9, v2                                 // 00000081EA14: DACC0000 09000209
	ds_bpermute_b32 v11, v19, v5                               // 00000081EA1C: DACC0000 0B000513
	ds_bpermute_b32 v12, v19, v6                               // 00000081EA24: DACC0000 0C000613
	ds_bpermute_b32 v10, v19, v4                               // 00000081EA2C: DACC0000 0A000413
	s_waitcnt lgkmcnt(4)                                       // 00000081EA34: BF89FC47
	v_add_f32_e32 v7, v7, v17                                  // 00000081EA38: 060E2307
	ds_bpermute_b32 v17, v19, v8                               // 00000081EA3C: DACC0000 11000813
	s_waitcnt lgkmcnt(4)                                       // 00000081EA44: BF89FC47
	v_add_f32_e32 v2, v2, v9                                   // 00000081EA48: 06041302
	ds_bpermute_b32 v9, v19, v3                                // 00000081EA4C: DACC0000 09000313
	s_waitcnt lgkmcnt(2)                                       // 00000081EA54: BF89FC27
	v_dual_add_f32 v5, v5, v11 :: v_dual_add_f32 v4, v4, v10   // 00000081EA58: C9081705 05041504
	ds_bpermute_b32 v13, v19, v7                               // 00000081EA60: DACC0000 0D000713
	ds_bpermute_b32 v18, v19, v2                               // 00000081EA68: DACC0000 12000213
	v_xor_b32_e32 v19, 2, v1                                   // 00000081EA70: 3A260282
	v_add_f32_e32 v6, v6, v12                                  // 00000081EA74: 060C1906
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000081EA78: BF8700B2
	v_cmp_gt_u32_e32 vcc_lo, 32, v19                           // 00000081EA7C: 7C9826A0
	s_waitcnt lgkmcnt(3)                                       // 00000081EA80: BF89FC37
	v_dual_cndmask_b32 v19, v1, v19 :: v_dual_add_f32 v8, v8, v17// 00000081EA84: CA482701 13082308
	v_lshlrev_b32_e32 v19, 2, v19                              // 00000081EA8C: 30262682
	s_waitcnt lgkmcnt(0)                                       // 00000081EA90: BF89FC07
	v_dual_add_f32 v3, v3, v9 :: v_dual_add_f32 v2, v2, v18    // 00000081EA94: C9081303 03022502
	ds_bpermute_b32 v11, v19, v5                               // 00000081EA9C: DACC0000 0B000513
	v_add_f32_e32 v7, v7, v13                                  // 00000081EAA4: 060E1B07
	ds_bpermute_b32 v9, v19, v3                                // 00000081EAA8: DACC0000 09000313
	ds_bpermute_b32 v10, v19, v4                               // 00000081EAB0: DACC0000 0A000413
	ds_bpermute_b32 v12, v19, v6                               // 00000081EAB8: DACC0000 0C000613
	ds_bpermute_b32 v17, v19, v8                               // 00000081EAC0: DACC0000 11000813
	ds_bpermute_b32 v13, v19, v7                               // 00000081EAC8: DACC0000 0D000713
	ds_bpermute_b32 v18, v19, v2                               // 00000081EAD0: DACC0000 12000213
	v_xor_b32_e32 v19, 1, v1                                   // 00000081EAD8: 3A260281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000081EADC: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v19                           // 00000081EAE0: 7C9826A0
	v_cndmask_b32_e32 v1, v1, v19, vcc_lo                      // 00000081EAE4: 02022701
	v_lshlrev_b32_e32 v19, 2, v1                               // 00000081EAE8: 30260282
	s_waitcnt lgkmcnt(5)                                       // 00000081EAEC: BF89FC57
	v_add_f32_e32 v1, v3, v9                                   // 00000081EAF0: 06021303
	s_waitcnt lgkmcnt(4)                                       // 00000081EAF4: BF89FC47
	v_dual_add_f32 v3, v4, v10 :: v_dual_add_f32 v4, v5, v11   // 00000081EAF8: C9081504 03041705
	s_waitcnt lgkmcnt(2)                                       // 00000081EB00: BF89FC27
	v_dual_add_f32 v5, v6, v12 :: v_dual_add_f32 v12, v8, v17  // 00000081EB04: C9081906 050C2308
	s_waitcnt lgkmcnt(1)                                       // 00000081EB0C: BF89FC17
	v_add_f32_e32 v10, v7, v13                                 // 00000081EB10: 06141B07
	s_waitcnt lgkmcnt(0)                                       // 00000081EB14: BF89FC07
	v_add_f32_e32 v2, v2, v18                                  // 00000081EB18: 06042502
	ds_bpermute_b32 v6, v19, v1                                // 00000081EB1C: DACC0000 06000113
	ds_bpermute_b32 v8, v19, v3                                // 00000081EB24: DACC0000 08000313
	ds_bpermute_b32 v9, v19, v4                                // 00000081EB2C: DACC0000 09000413
	ds_bpermute_b32 v11, v19, v5                               // 00000081EB34: DACC0000 0B000513
	ds_bpermute_b32 v13, v19, v10                              // 00000081EB3C: DACC0000 0D000A13
	ds_bpermute_b32 v17, v19, v12                              // 00000081EB44: DACC0000 11000C13
	ds_bpermute_b32 v7, v19, v2                                // 00000081EB4C: DACC0000 07000213
	v_cmpx_eq_u32_e32 0, v16                                   // 00000081EB54: 7D942080
	s_cbranch_execz 28                                         // 00000081EB58: BFA5001C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi8ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0xdcc>
	s_waitcnt lgkmcnt(2)                                       // 00000081EB5C: BF89FC27
	v_dual_add_f32 v10, v10, v13 :: v_dual_add_f32 v3, v3, v8  // 00000081EB60: C9081B0A 0A021103
	v_mul_u32_u24_e32 v13, 28, v15                             // 00000081EB68: 161A1E9C
	v_dual_add_f32 v4, v4, v9 :: v_dual_add_f32 v1, v1, v6     // 00000081EB6C: C9081304 04000D01
	s_waitcnt lgkmcnt(1)                                       // 00000081EB74: BF89FC17
	v_dual_add_f32 v12, v12, v17 :: v_dual_add_f32 v5, v5, v11 // 00000081EB78: C908230C 0C041705
	s_delay_alu instid0(VALU_DEP_3)                            // 00000081EB80: BF870003
	v_or_b32_e32 v6, 0x400, v13                                // 00000081EB84: 380C1AFF 00000400
	v_mad_u32_u24 v8, v15, 28, 0x408                           // 00000081EB8C: D60B0008 03FD390F 00000408
	v_mad_u32_u24 v9, v15, 28, 0x410                           // 00000081EB98: D60B0009 03FD390F 00000410
	s_waitcnt lgkmcnt(0)                                       // 00000081EBA4: BF89FC07
	v_add_f32_e32 v2, v2, v7                                   // 00000081EBA8: 06040F02
	ds_store_2addr_b32 v6, v1, v3 offset1:1                    // 00000081EBAC: D8380100 00030106
	ds_store_2addr_b32 v8, v4, v5 offset1:1                    // 00000081EBB4: D8380100 00050408
	ds_store_2addr_b32 v9, v10, v12 offset1:1                  // 00000081EBBC: D8380100 000C0A09
	ds_store_b32 v13, v2 offset:1048                           // 00000081EBC4: D8340418 0000020D
	s_or_b32 exec_lo, exec_lo, s0                              // 00000081EBCC: 8C7E007E
	.long 0xd4510000                                           // 00000081EBD0: D4510000
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 00000081EBD4: 02001802
	v_cmp_gt_u32_e32 vcc_lo, 7, v0                             // 00000081EBD8: 7C980087
	s_waitcnt lgkmcnt(0)                                       // 00000081EBDC: BF89FC07
	s_barrier                                                  // 00000081EBE0: BFBD0000
	buffer_gl0_inv                                             // 00000081EBE4: E0AC0000 00000000
	s_and_b32 s0, vcc_lo, s0                                   // 00000081EBEC: 8B00006A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000081EBF0: BF870009
	s_and_saveexec_b32 s1, s0                                  // 00000081EBF4: BE812000
	s_cbranch_execz 88                                         // 00000081EBF8: BFA50058 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi8ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0xf5c>
	v_add_nc_u32_e32 v7, 0x400, v14                            // 00000081EBFC: 4A0E1CFF 00000400
	s_lshl_b64 s[0:1], s[2:3], 1                               // 00000081EC04: 84808102
	ds_load_2addr_b32 v[1:2], v7 offset1:7                     // 00000081EC08: D8DC0700 01000007
	ds_load_2addr_b32 v[3:4], v7 offset0:14 offset1:21         // 00000081EC10: D8DC150E 03000007
	ds_load_2addr_b32 v[5:6], v7 offset0:28 offset1:35         // 00000081EC18: D8DC231C 05000007
	s_waitcnt lgkmcnt(2)                                       // 00000081EC20: BF89FC27
	v_add_f32_e32 v1, 0, v1                                    // 00000081EC24: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000081EC28: BF8700C1
	v_add_f32_e32 v8, v1, v2                                   // 00000081EC2C: 06100501
	ds_load_2addr_b32 v[1:2], v7 offset0:42 offset1:49         // 00000081EC30: D8DC312A 01000007
	s_waitcnt lgkmcnt(2)                                       // 00000081EC38: BF89FC27
	v_add_f32_e32 v3, v8, v3                                   // 00000081EC3C: 06060708
	v_add_f32_e32 v3, v3, v4                                   // 00000081EC40: 06060903
	s_waitcnt lgkmcnt(1)                                       // 00000081EC44: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081EC48: BF870091
	v_add_f32_e32 v3, v3, v5                                   // 00000081EC4C: 06060B03
	v_add_f32_e32 v3, v3, v6                                   // 00000081EC50: 06060D03
	s_waitcnt lgkmcnt(0)                                       // 00000081EC54: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081EC58: BF870091
	v_add_f32_e32 v1, v3, v1                                   // 00000081EC5C: 06020303
	v_add_f32_e32 v1, v1, v2                                   // 00000081EC60: 06020501
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081EC64: BF870091
	v_bfe_u32 v2, v1, 16, 1                                    // 00000081EC68: D6100002 02052101
	v_add3_u32 v1, v1, v2, 0x7fff                              // 00000081EC70: D6550001 03FE0501 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081EC7C: BF870091
	v_and_b32_e32 v1, 0xffff0000, v1                           // 00000081EC80: 360202FF FFFF0000
	v_mul_f32_e32 v1, 0xbfb8aa3b, v1                           // 00000081EC88: 100202FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000081EC90: BF870291
	v_exp_f32_e32 v1, v1                                       // 00000081EC94: 7E024B01
	v_add_f32_e32 v4, 1.0, v1                                  // 00000081EC98: 060802F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000081EC9C: BF870121
	v_div_scale_f32 v3, null, v4, v4, 1.0                      // 00000081ECA0: D6FC7C03 03CA0904
	v_div_scale_f32 v6, vcc_lo, 1.0, v4, 1.0                   // 00000081ECA8: D6FC6A06 03CA08F2
	v_rcp_f32_e32 v5, v3                                       // 00000081ECB0: 7E0A5503
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081ECB4: BF870095
	v_fma_f32 v1, -v3, v5, 1.0                                 // 00000081ECB8: D6130001 23CA0B03
	v_fmac_f32_e32 v5, v1, v5                                  // 00000081ECC0: 560A0B01
	v_mad_u64_u32 v[1:2], null, s12, v0, 0                     // 00000081ECC4: D6FE7C01 0202000C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081ECCC: BF870092
	v_mul_f32_e32 v7, v6, v5                                   // 00000081ECD0: 100E0B06
	v_fma_f32 v8, -v3, v7, v6                                  // 00000081ECD4: D6130008 241A0F03
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081ECDC: BF870091
	v_fmac_f32_e32 v7, v8, v5                                  // 00000081ECE0: 560E0B08
	v_fma_f32 v6, -v3, v7, v6                                  // 00000081ECE4: D6130006 241A0F03
	v_mad_u64_u32 v[2:3], null, s13, v0, v[2:3]                // 00000081ECEC: D6FE7C02 040A000D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081ECF4: BF870092
	v_div_fmas_f32 v0, v6, v5, v7                              // 00000081ECF8: D6370000 041E0B06
	v_div_fixup_f32 v3, v0, v4, 1.0                            // 00000081ED00: D6270003 03CA0900
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000081ED08: BF870113
	.long 0xd73c0000                                           // 00000081ED0C: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000081ED10: 02020281
	v_bfe_u32 v2, v3, 16, 1                                    // 00000081ED14: D6100002 02052103
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081ED1C: BF870092
	.long 0xd7006a00                                           // 00000081ED20: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 00000081ED24: 02020008
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 00000081ED28: D5207C01 01AA0209
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000081ED30: BF870193
	v_add3_u32 v2, v3, v2, 0x7fff                              // 00000081ED34: D6550002 03FE0503 00007FFF
	.long 0xd7006a00                                           // 00000081ED40: D7006A00
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 00000081ED44: 02000100
	s_delay_alu instid0(VALU_DEP_1)                            // 00000081ED48: BF870001
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 00000081ED4C: D5207C01 01AA0201
	global_store_d16_hi_b16 v[0:1], v2, off                    // 00000081ED54: DC960000 007C0200
	s_endpgm                                                   // 00000081ED5C: BFB00000
		...

