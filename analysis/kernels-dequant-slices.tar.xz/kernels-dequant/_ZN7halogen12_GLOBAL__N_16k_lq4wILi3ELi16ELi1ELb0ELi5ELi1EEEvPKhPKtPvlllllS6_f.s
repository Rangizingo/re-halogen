00000000008be700 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[8:23], s[0:1], null                          // 0000008BE700: F4100200 F8000000
	v_and_b32_e32 v23, 15, v0                                  // 0000008BE708: 362E008F
	v_lshrrev_b32_e32 v1, 4, v0                                // 0000008BE70C: 32020084
	s_ashr_i32 s3, s2, 31                                      // 0000008BE710: 86039F02
	v_lshlrev_b32_e32 v0, 2, v0                                // 0000008BE714: 30000082
	s_lshl_b64 s[2:3], s[2:3], 4                               // 0000008BE718: 84828402
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000008BE71C: BF870009
	v_dual_mov_b32 v17, s3 :: v_dual_lshlrev_b32 v2, 2, v23    // 0000008BE720: CA220003 11022E82
	v_lshlrev_b32_e32 v3, 2, v1                                // 0000008BE728: 30060282
	v_or_b32_e32 v16, s2, v1                                   // 0000008BE72C: 38200202
	.long 0x7f023880                                           // 0000008BE730: 7F023880
	s_waitcnt lgkmcnt(0)                                       // 0000008BE734: BF89FC07
	s_clause 0x1                                               // 0000008BE738: BF850001
	global_load_b32 v2, v2, s[8:9]                             // 0000008BE73C: DC520000 02080002
	global_load_b32 v3, v3, s[8:9]                             // 0000008BE744: DC520000 03080003
	.long 0xd4540002                                           // 0000008BE74C: D4540002
	v_cndmask_b32_e32 v1, s16, v16, vcc_lo                     // 0000008BE750: 02022010
	s_add_u32 s24, s8, s20                                     // 0000008BE754: 80181408
	s_addc_u32 s25, s9, s21                                    // 0000008BE758: 82191509
	s_ashr_i32 s4, s15, 31                                     // 0000008BE75C: 86049F0F
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000008BE760: BF870159
	s_lshr_b32 s4, s4, 27                                      // 0000008BE764: 85049B04
	v_cndmask_b32_e64 v8, 0, v16, s2                           // 0000008BE768: D5010008 000A2080
	v_cndmask_b32_e64 v9, 0, s3, s2                            // 0000008BE770: D5010009 00080680
	s_add_u32 s4, s14, s4                                      // 0000008BE778: 8004040E
	s_addc_u32 s5, s15, 0                                      // 0000008BE77C: 8205800F
	.long 0xd72c0004                                           // 0000008BE780: D72C0004
	v_cndmask_b32_e32 v1, s23, v8, vcc_lo                      // 0000008BE784: 02021017
	v_mad_u64_u32 v[12:13], null, s22, v8, 0                   // 0000008BE788: D6FE7C0C 02021016
	s_lshr_b64 s[6:7], s[4:5], 5                               // 0000008BE790: 85868504
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000008BE794: BF870009
	s_cmpk_lt_i32 s6, 0x81                                     // 0000008BE798: B3860081
	.long 0xd4440004                                           // 0000008BE79C: D4440004
	v_cndmask_b32_e32 v1, s6, v23, vcc_lo                      // 0000008BE7A0: 02022E06
	s_cselect_b32 s3, -1, 0                                    // 0000008BE7A4: 980380C1
	s_cmpk_gt_i32 s6, 0x80                                     // 0000008BE7A8: B2860080
	.long 0xd700050e                                           // 0000008BE7AC: D700050E
	v_cndmask_b32_e32 v1, s24, v12, vcc_lo                     // 0000008BE7B0: 02021818
	s_cselect_b32 s7, -1, 0                                    // 0000008BE7B4: 980780C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000008BE7B8: BF870159
	s_and_b32 vcc_lo, exec_lo, s7                              // 0000008BE7BC: 8B6A077E
	s_waitcnt vmcnt(1)                                         // 0000008BE7C0: BF8907F7
	v_bfe_u32 v5, v2, 16, 1                                    // 0000008BE7C4: D6100005 02052102
	s_waitcnt vmcnt(0)                                         // 0000008BE7CC: BF8903F7
	v_bfe_u32 v6, v3, 16, 1                                    // 0000008BE7D0: D6100006 02052103
	v_add3_u32 v2, v2, v5, 0x7fff                              // 0000008BE7D8: D6550002 03FE0B02 00007FFF
	.long 0xd72c0005                                           // 0000008BE7E4: D72C0005
	v_cndmask_b32_e32 v1, s22, v9, vcc_lo                      // 0000008BE7E8: 02021216
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008BE7EC: BF870193
	v_add3_u32 v3, v3, v6, 0x7fff                              // 0000008BE7F0: D6550003 03FE0D03 00007FFF
	.long 0x7e023982                                           // 0000008BE7FC: 7E023982
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008BE800: BF870113
	v_add3_u32 v13, v13, v5, v4                                // 0000008BE804: D655000D 04120B0D
	v_and_or_b32 v1, 0xffff0000, v3, v1                        // 0000008BE80C: D6570001 040606FF FFFF0000
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008BE818: BF870002
	v_add_co_ci_u32_e64 v15, null, s25, v13, s5                // 0000008BE81C: D5207C0F 00161A19
	ds_store_b32 v0, v1                                        // 0000008BE824: D8340000 00000100
	s_waitcnt lgkmcnt(0)                                       // 0000008BE82C: BF89FC07
	s_barrier                                                  // 0000008BE830: BFBD0000
	buffer_gl0_inv                                             // 0000008BE834: E0AC0000 00000000
	s_cbranch_vccnz 144                                        // 0000008BE83C: BFA40090 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x380>
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v0, 0               // 0000008BE840: CA100080 01000080
	s_and_saveexec_b32 s5, s4                                  // 0000008BE848: BE852004
	s_cbranch_execz 10                                         // 0000008BE84C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x178>
	v_lshlrev_b32_e32 v0, 1, v23                               // 0000008BE850: 30002E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008BE854: BF870091
	.long 0xd7006a02                                           // 0000008BE858: D7006A02
	v_cndmask_b32_e32 v1, v14, v0, vcc_lo                      // 0000008BE85C: 0202010E
	v_add_co_ci_u32_e64 v3, null, 0, v15, vcc_lo               // 0000008BE860: D5207C03 01AA1E80
	global_load_d16_b16 v0, v[2:3], off                        // 0000008BE868: DC820000 007C0002
	s_waitcnt vmcnt(0)                                         // 0000008BE870: BF8903F7
	v_cvt_f32_f16_e32 v0, v0                                   // 0000008BE874: 7E001700
	s_or_b32 exec_lo, exec_lo, s5                              // 0000008BE878: 8C7E057E
	v_or_b32_e32 v2, 16, v23                                   // 0000008BE87C: 38042E90
	s_mov_b32 s4, exec_lo                                      // 0000008BE880: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008BE884: BF870001
	.long 0xd4c4007e                                           // 0000008BE888: D4C4007E
	v_cndmask_b32_e32 v1, s6, v2, vcc_lo                       // 0000008BE88C: 02020406
	s_cbranch_execz 10                                         // 0000008BE890: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x1bc>
	v_lshlrev_b32_e32 v1, 1, v2                                // 0000008BE894: 30020481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008BE898: BF870091
	.long 0xd7006a01                                           // 0000008BE89C: D7006A01
	v_cndmask_b32_e32 v1, v14, v1, vcc_lo                      // 0000008BE8A0: 0202030E
	v_add_co_ci_u32_e64 v2, null, 0, v15, vcc_lo               // 0000008BE8A4: D5207C02 01AA1E80
	global_load_d16_b16 v1, v[1:2], off                        // 0000008BE8AC: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000008BE8B4: BF8903F7
	v_cvt_f32_f16_e32 v1, v1                                   // 0000008BE8B8: 7E021701
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008BE8BC: 8C7E047E
	v_or_b32_e32 v4, 32, v23                                   // 0000008BE8C0: 38082EA0
	v_dual_mov_b32 v3, 0 :: v_dual_mov_b32 v2, 0               // 0000008BE8C4: CA100080 03020080
	s_mov_b32 s4, exec_lo                                      // 0000008BE8CC: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008BE8D0: BF870002
	.long 0xd4c4007e                                           // 0000008BE8D4: D4C4007E
	v_cndmask_b32_e32 v1, s6, v4, vcc_lo                       // 0000008BE8D8: 02020806
	s_cbranch_execz 10                                         // 0000008BE8DC: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x208>
	v_lshlrev_b32_e32 v2, 1, v4                                // 0000008BE8E0: 30040881
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008BE8E4: BF870091
	.long 0xd7006a04                                           // 0000008BE8E8: D7006A04
	v_cndmask_b32_e32 v1, v14, v2, vcc_lo                      // 0000008BE8EC: 0202050E
	v_add_co_ci_u32_e64 v5, null, 0, v15, vcc_lo               // 0000008BE8F0: D5207C05 01AA1E80
	global_load_d16_b16 v2, v[4:5], off                        // 0000008BE8F8: DC820000 027C0004
	s_waitcnt vmcnt(0)                                         // 0000008BE900: BF8903F7
	v_cvt_f32_f16_e32 v2, v2                                   // 0000008BE904: 7E041702
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008BE908: 8C7E047E
	v_or_b32_e32 v4, 48, v23                                   // 0000008BE90C: 38082EB0
	s_mov_b32 s4, exec_lo                                      // 0000008BE910: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008BE914: BF870001
	.long 0xd4c4007e                                           // 0000008BE918: D4C4007E
	v_cndmask_b32_e32 v1, s6, v4, vcc_lo                       // 0000008BE91C: 02020806
	s_cbranch_execz 10                                         // 0000008BE920: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x24c>
	v_lshlrev_b32_e32 v3, 1, v4                                // 0000008BE924: 30060881
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008BE928: BF870091
	.long 0xd7006a03                                           // 0000008BE92C: D7006A03
	v_cndmask_b32_e32 v1, v14, v3, vcc_lo                      // 0000008BE930: 0202070E
	v_add_co_ci_u32_e64 v4, null, 0, v15, vcc_lo               // 0000008BE934: D5207C04 01AA1E80
	global_load_d16_b16 v3, v[3:4], off                        // 0000008BE93C: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 0000008BE944: BF8903F7
	v_cvt_f32_f16_e32 v3, v3                                   // 0000008BE948: 7E061703
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008BE94C: 8C7E047E
	v_or_b32_e32 v6, 64, v23                                   // 0000008BE950: 380C2EC0
	v_dual_mov_b32 v5, 0 :: v_dual_mov_b32 v4, 0               // 0000008BE954: CA100080 05040080
	s_mov_b32 s4, exec_lo                                      // 0000008BE95C: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008BE960: BF870002
	.long 0xd4c4007e                                           // 0000008BE964: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 0000008BE968: 02020C06
	s_cbranch_execz 10                                         // 0000008BE96C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x298>
	v_lshlrev_b32_e32 v4, 1, v6                                // 0000008BE970: 30080C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008BE974: BF870091
	.long 0xd7006a06                                           // 0000008BE978: D7006A06
	v_cndmask_b32_e32 v1, v14, v4, vcc_lo                      // 0000008BE97C: 0202090E
	v_add_co_ci_u32_e64 v7, null, 0, v15, vcc_lo               // 0000008BE980: D5207C07 01AA1E80
	global_load_d16_b16 v4, v[6:7], off                        // 0000008BE988: DC820000 047C0006
	s_waitcnt vmcnt(0)                                         // 0000008BE990: BF8903F7
	v_cvt_f32_f16_e32 v4, v4                                   // 0000008BE994: 7E081704
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008BE998: 8C7E047E
	v_or_b32_e32 v6, 0x50, v23                                 // 0000008BE99C: 380C2EFF 00000050
	s_mov_b32 s4, exec_lo                                      // 0000008BE9A4: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008BE9A8: BF870001
	.long 0xd4c4007e                                           // 0000008BE9AC: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 0000008BE9B0: 02020C06
	s_cbranch_execz 10                                         // 0000008BE9B4: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x2e0>
	v_lshlrev_b32_e32 v5, 1, v6                                // 0000008BE9B8: 300A0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008BE9BC: BF870091
	.long 0xd7006a05                                           // 0000008BE9C0: D7006A05
	v_cndmask_b32_e32 v1, v14, v5, vcc_lo                      // 0000008BE9C4: 02020B0E
	v_add_co_ci_u32_e64 v6, null, 0, v15, vcc_lo               // 0000008BE9C8: D5207C06 01AA1E80
	global_load_d16_b16 v5, v[5:6], off                        // 0000008BE9D0: DC820000 057C0005
	s_waitcnt vmcnt(0)                                         // 0000008BE9D8: BF8903F7
	v_cvt_f32_f16_e32 v5, v5                                   // 0000008BE9DC: 7E0A1705
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008BE9E0: 8C7E047E
	v_or_b32_e32 v10, 0x60, v23                                // 0000008BE9E4: 38142EFF 00000060
	v_dual_mov_b32 v7, 0 :: v_dual_mov_b32 v6, 0               // 0000008BE9EC: CA100080 07060080
	s_mov_b32 s4, exec_lo                                      // 0000008BE9F4: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008BE9F8: BF870002
	.long 0xd4c4007e                                           // 0000008BE9FC: D4C4007E
	v_cndmask_b32_e32 v1, s6, v10, vcc_lo                      // 0000008BEA00: 02021406
	s_cbranch_execz 10                                         // 0000008BEA04: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x330>
	v_lshlrev_b32_e32 v6, 1, v10                               // 0000008BEA08: 300C1481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008BEA0C: BF870091
	.long 0xd7006a0a                                           // 0000008BEA10: D7006A0A
	v_cndmask_b32_e32 v1, v14, v6, vcc_lo                      // 0000008BEA14: 02020D0E
	v_add_co_ci_u32_e64 v11, null, 0, v15, vcc_lo              // 0000008BEA18: D5207C0B 01AA1E80
	global_load_d16_b16 v6, v[10:11], off                      // 0000008BEA20: DC820000 067C000A
	s_waitcnt vmcnt(0)                                         // 0000008BEA28: BF8903F7
	v_cvt_f32_f16_e32 v6, v6                                   // 0000008BEA2C: 7E0C1706
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008BEA30: 8C7E047E
	v_or_b32_e32 v10, 0x70, v23                                // 0000008BEA34: 38142EFF 00000070
	s_mov_b32 s4, exec_lo                                      // 0000008BEA3C: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008BEA40: BF870001
	.long 0xd4c4007e                                           // 0000008BEA44: D4C4007E
	v_cndmask_b32_e32 v1, s6, v10, vcc_lo                      // 0000008BEA48: 02021406
	s_cbranch_execz 10                                         // 0000008BEA4C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x378>
	v_lshlrev_b32_e32 v7, 1, v10                               // 0000008BEA50: 300E1481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008BEA54: BF870091
	.long 0xd7006a0a                                           // 0000008BEA58: D7006A0A
	v_cndmask_b32_e32 v1, v14, v7, vcc_lo                      // 0000008BEA5C: 02020F0E
	v_add_co_ci_u32_e64 v11, null, 0, v15, vcc_lo              // 0000008BEA60: D5207C0B 01AA1E80
	global_load_d16_b16 v7, v[10:11], off                      // 0000008BEA68: DC820000 077C000A
	s_waitcnt vmcnt(0)                                         // 0000008BEA70: BF8903F7
	v_cvt_f32_f16_e32 v7, v7                                   // 0000008BEA74: 7E0E1707
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008BEA78: 8C7E047E
	s_branch 9                                                 // 0000008BEA7C: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x3a4>
	v_mov_b32_e32 v0, 0                                        // 0000008BEA80: 7E000280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008BEA84: BF870001
	v_mov_b32_e32 v1, v0                                       // 0000008BEA88: 7E020300
	v_mov_b32_e32 v2, v0                                       // 0000008BEA8C: 7E040300
	v_mov_b32_e32 v3, v0                                       // 0000008BEA90: 7E060300
	v_mov_b32_e32 v4, v0                                       // 0000008BEA94: 7E080300
	v_mov_b32_e32 v5, v0                                       // 0000008BEA98: 7E0A0300
	v_mov_b32_e32 v6, v0                                       // 0000008BEA9C: 7E0C0300
	v_mov_b32_e32 v7, v0                                       // 0000008BEAA0: 7E0E0300
	s_add_u32 s4, s8, s18                                      // 0000008BEAA4: 80041208
	s_addc_u32 s5, s9, s19                                     // 0000008BEAA8: 82051309
	s_lshr_b32 s18, s15, 31                                    // 0000008BEAAC: 85129F0F
	v_cndmask_b32_e64 v24, 0, 1, s7                            // 0000008BEAB0: D5010018 001D0280
	s_add_u32 s18, s14, s18                                    // 0000008BEAB8: 8012120E
	s_addc_u32 s19, s15, 0                                     // 0000008BEABC: 8213800F
	v_mov_b32_e32 v32, 0                                       // 0000008BEAC0: 7E400280
	s_ashr_i64 s[18:19], s[18:19], 1                           // 0000008BEAC4: 86928112
	v_mov_b32_e32 v25, 0                                       // 0000008BEAC8: 7E320280
	v_mad_u64_u32 v[18:19], null, v8, s18, s[4:5]              // 0000008BEACC: D6FE7C12 00102508
	.long 0xd72c000b                                           // 0000008BEAD4: D72C000B
	v_cndmask_b32_e32 v0, v8, v19, vcc_lo                      // 0000008BEAD8: 02002708
	.long 0xd72c0014                                           // 0000008BEADC: D72C0014
	v_cndmask_b32_e32 v0, v9, v18, vcc_lo                      // 0000008BEAE0: 02002509
	.long 0xd4440004                                           // 0000008BEAE4: D4440004
	v_cndmask_b32_e32 v1, s6, v23, vcc_lo                      // 0000008BEAE8: 02022E06
	v_dual_mov_b32 v8, 0 :: v_dual_mov_b32 v9, 0               // 0000008BEAEC: CA100080 08080080
	v_mov_b32_e32 v10, 0                                       // 0000008BEAF4: 7E140280
	s_delay_alu instid0(VALU_DEP_4)                            // 0000008BEAF8: BF870004
	v_add3_u32 v26, v20, v19, v11                              // 0000008BEAFC: D655001A 042E2714
	v_mov_b32_e32 v11, 0                                       // 0000008BEB04: 7E160280
	s_and_saveexec_b32 s5, s4                                  // 0000008BEB08: BE852004
	s_cbranch_execz 21                                         // 0000008BEB0C: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x464>
	v_lshlrev_b32_e32 v8, 4, v23                               // 0000008BEB10: 30102E84
	v_mov_b32_e32 v32, 0                                       // 0000008BEB14: 7E400280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008BEB18: BF870092
	.long 0xd7006a08                                           // 0000008BEB1C: D7006A08
	v_cndmask_b32_e32 v1, v18, v8, vcc_lo                      // 0000008BEB20: 02021112
	v_add_co_ci_u32_e64 v9, null, 0, v26, vcc_lo               // 0000008BEB24: D5207C09 01AA3480
	s_and_not1_b32 vcc_lo, exec_lo, s7                         // 0000008BEB2C: 916A077E
	global_load_b128 v[8:11], v[8:9], off                      // 0000008BEB30: DC5E0000 087C0008
	s_cbranch_vccnz 10                                         // 0000008BEB38: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x464>
	v_lshlrev_b32_e32 v19, 1, v23                              // 0000008BEB3C: 30262E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008BEB40: BF870091
	.long 0xd7006a0e                                           // 0000008BEB44: D7006A0E
	v_cndmask_b32_e32 v1, v14, v19, vcc_lo                     // 0000008BEB48: 0202270E
	v_add_co_ci_u32_e64 v15, null, 0, v15, vcc_lo              // 0000008BEB4C: D5207C0F 01AA1E80
	global_load_d16_b16 v14, v[14:15], off                     // 0000008BEB54: DC820000 0E7C000E
	s_waitcnt vmcnt(0)                                         // 0000008BEB5C: BF8903F7
	v_cvt_f32_f16_e32 v32, v14                                 // 0000008BEB60: 7E40170E
	s_or_b32 exec_lo, exec_lo, s5                              // 0000008BEB64: 8C7E057E
	v_dual_mov_b32 v27, 0 :: v_dual_mov_b32 v28, 0             // 0000008BEB68: CA100080 1B1C0080
	s_and_saveexec_b32 s5, s4                                  // 0000008BEB70: BE852004
	s_cbranch_execz 352                                        // 0000008BEB74: BFA50160 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x9f8>
	.long 0xd7006a0c                                           // 0000008BEB78: D7006A0C
	v_cndmask_b32_e32 v1, s20, v12, vcc_lo                     // 0000008BEB7C: 02021814
	v_dual_mov_b32 v20, 0 :: v_dual_lshlrev_b32 v19, 5, v23    // 0000008BEB80: CA220080 14122E85
	v_lshlrev_b32_e32 v14, 1, v23                              // 0000008BEB88: 301C2E81
	v_add_co_ci_u32_e64 v13, null, s21, v13, vcc_lo            // 0000008BEB8C: D5207C0D 01AA1A15
	v_lshl_or_b32 v29, v23, 4, 0x100                           // 0000008BEB94: D656001D 03FD0917 00000100
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000008BEBA0: BF870214
	v_mov_b32_e32 v27, v20                                     // 0000008BEBA4: 7E360314
	.long 0xd7006a0c                                           // 0000008BEBA8: D7006A0C
	v_cndmask_b32_e32 v1, v12, v14, vcc_lo                     // 0000008BEBAC: 02021D0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008BEBB0: BF8701A1
	v_add_co_ci_u32_e64 v13, null, 0, v13, vcc_lo              // 0000008BEBB4: D5207C0D 01AA1A80
	v_dual_mov_b32 v30, v23 :: v_dual_mov_b32 v25, v20         // 0000008BEBBC: CA100117 1E180114
	.long 0xd7006a0c                                           // 0000008BEBC4: D7006A0C
	v_cndmask_b32_e32 v1, s8, v12, vcc_lo                      // 0000008BEBC8: 02021808
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008BEBCC: BF8701A1
	v_add_co_ci_u32_e64 v13, null, s9, v13, vcc_lo             // 0000008BEBD0: D5207C0D 01AA1A09
	v_mov_b32_e32 v28, v20                                     // 0000008BEBD8: 7E380314
	.long 0xd7006a15                                           // 0000008BEBDC: D7006A15
	v_cndmask_b32_e32 v0, v12, v160, vcc_lo                    // 0000008BEBE0: 0201410C
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008BEBE4: BF870001
	v_add_co_ci_u32_e64 v22, null, 0, v13, vcc_lo              // 0000008BEBE8: D5207C16 01AA1A80
	v_mov_b32_e32 v31, v32                                     // 0000008BEBF0: 7E3E0320
	s_lshl_b64 s[8:9], s[14:15], 2                             // 0000008BEBF4: 8488820E
	s_mov_b32 s7, 0                                            // 0000008BEBF8: BE870080
	s_lshl_b64 s[14:15], s[14:15], 1                           // 0000008BEBFC: 848E810E
	s_branch 288                                               // 0000008BEC00: BFA00120 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x984>
	s_or_b32 exec_lo, exec_lo, s18                             // 0000008BEC04: 8C7E127E
	.long 0xd73c0021                                           // 0000008BEC08: D73C0021
	v_cndmask_b32_e32 v1, 1, v19, vcc_lo                       // 0000008BEC0C: 02022681
	v_and_b32_e32 v81, 0xff, v8                                // 0000008BEC10: 36A210FF 000000FF
	v_cndmask_b32_e64 v82, v32, v0, s3                         // 0000008BEC18: D5010052 000E0120
	v_lshrrev_b32_e32 v32, 6, v8                               // 0000008BEC20: 32401086
	v_lshrrev_b32_e32 v83, 14, v8                              // 0000008BEC24: 32A6108E
	v_lshrrev_b32_e32 v8, 22, v8                               // 0000008BEC28: 32101096
	.long 0xd7006a45                                           // 0000008BEC2C: D7006A45
	v_cndmask_b32_e32 v1, s10, v33, vcc_lo                     // 0000008BEC30: 0202420A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008BEC34: BF8701A1
	v_add_co_ci_u32_e64 v70, null, s11, v34, vcc_lo            // 0000008BEC38: D5207C46 01AA440B
	v_lshlrev_b32_e32 v81, 2, v81                              // 0000008BEC40: 30A2A282
	.long 0xd7006a49                                           // 0000008BEC44: D7006A49
	v_cndmask_b32_e32 v0, v69, v14, vcc_lo                     // 0000008BEC48: 02001D45
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008BEC4C: BF8700A1
	v_add_co_ci_u32_e64 v74, null, s15, v70, vcc_lo            // 0000008BEC50: D5207C4A 01AA8C0F
	.long 0xd7006a4d                                           // 0000008BEC58: D7006A4D
	v_cndmask_b32_e32 v0, v69, v8, vcc_lo                      // 0000008BEC5C: 02001145
	v_add_co_ci_u32_e64 v78, null, s9, v70, vcc_lo             // 0000008BEC60: D5207C4E 01AA8C09
	s_clause 0xb                                               // 0000008BEC68: BF85000B
	global_load_b128 v[33:36], v[69:70], off                   // 0000008BEC6C: DC5E0000 217C0045
	global_load_b128 v[37:40], v[73:74], off                   // 0000008BEC74: DC5E0000 257C0049
	global_load_b128 v[41:44], v[77:78], off                   // 0000008BEC7C: DC5E0000 297C004D
	global_load_b128 v[45:48], v[69:70], off offset:16         // 0000008BEC84: DC5E0010 2D7C0045
	global_load_b128 v[49:52], v[73:74], off offset:16         // 0000008BEC8C: DC5E0010 317C0049
	global_load_b128 v[53:56], v[77:78], off offset:16         // 0000008BEC94: DC5E0010 357C004D
	global_load_b128 v[57:60], v[69:70], off offset:32         // 0000008BEC9C: DC5E0020 397C0045
	global_load_b128 v[61:64], v[73:74], off offset:32         // 0000008BECA4: DC5E0020 3D7C0049
	global_load_b128 v[65:68], v[77:78], off offset:32         // 0000008BECAC: DC5E0020 417C004D
	global_load_b128 v[69:72], v[69:70], off offset:48         // 0000008BECB4: DC5E0030 457C0045
	global_load_b128 v[73:76], v[73:74], off offset:48         // 0000008BECBC: DC5E0030 497C0049
	global_load_b128 v[77:80], v[77:78], off offset:48         // 0000008BECC4: DC5E0030 4D7C004D
	v_and_b32_e32 v32, 0x3fc, v32                              // 0000008BECCC: 364040FF 000003FC
	ds_load_b32 v81, v81                                       // 0000008BECD4: D8D80000 51000051
	v_and_b32_e32 v83, 0x3fc, v83                              // 0000008BECDC: 36A6A6FF 000003FC
	v_and_b32_e32 v84, 0xff, v9                                // 0000008BECE4: 36A812FF 000000FF
	v_lshrrev_b32_e32 v85, 6, v9                               // 0000008BECEC: 32AA1286
	v_lshrrev_b32_e32 v86, 14, v9                              // 0000008BECF0: 32AC128E
	v_lshrrev_b32_e32 v9, 22, v9                               // 0000008BECF4: 32121296
	ds_load_b32 v83, v83                                       // 0000008BECF8: D8D80000 53000053
	ds_load_b32 v32, v32                                       // 0000008BED00: D8D80000 20000020
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008BED08: 361010FF 000003FC
	v_lshlrev_b32_e32 v84, 2, v84                              // 0000008BED10: 30A8A882
	v_and_b32_e32 v85, 0x3fc, v85                              // 0000008BED14: 36AAAAFF 000003FC
	v_and_b32_e32 v86, 0x3fc, v86                              // 0000008BED1C: 36ACACFF 000003FC
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000008BED24: 361212FF 000003FC
	ds_load_b32 v8, v8                                         // 0000008BED2C: D8D80000 08000008
	ds_load_b32 v84, v84                                       // 0000008BED34: D8D80000 54000054
	ds_load_b32 v85, v85                                       // 0000008BED3C: D8D80000 55000055
	ds_load_b32 v86, v86                                       // 0000008BED44: D8D80000 56000056
	ds_load_b32 v9, v9                                         // 0000008BED4C: D8D80000 09000009
	v_and_b32_e32 v87, 0xff, v10                               // 0000008BED54: 36AE14FF 000000FF
	v_lshrrev_b32_e32 v88, 6, v10                              // 0000008BED5C: 32B01486
	v_lshrrev_b32_e32 v89, 14, v10                             // 0000008BED60: 32B2148E
	v_lshrrev_b32_e32 v10, 22, v10                             // 0000008BED64: 32141496
	v_and_b32_e32 v90, 0xff, v11                               // 0000008BED68: 36B416FF 000000FF
	v_lshrrev_b32_e32 v91, 14, v11                             // 0000008BED70: 32B6168E
	.long 0xd7006a15                                           // 0000008BED74: D7006A15
	v_cndmask_b32_e32 v0, v21, v160, vcc_lo                    // 0000008BED78: 02014115
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000008BED7C: BF8704A1
	v_add_co_ci_u32_e64 v22, null, 0, v22, vcc_lo              // 0000008BED80: D5207C16 01AA2C80
	s_and_b32 s4, exec_lo, s4                                  // 0000008BED88: 8B04047E
	s_or_b32 s7, s4, s7                                        // 0000008BED8C: 8C070704
	s_waitcnt vmcnt(11) lgkmcnt(7)                             // 0000008BED90: BF892C77
	v_dot2_f32_bf16 v33, v33, v81, 0                           // 0000008BED94: CC1A4021 1A02A321
	s_waitcnt vmcnt(10)                                        // 0000008BED9C: BF892BF7
	v_dot2_f32_bf16 v37, v37, v81, 0                           // 0000008BEDA0: CC1A4025 1A02A325
	s_waitcnt vmcnt(9)                                         // 0000008BEDA8: BF8927F7
	v_dot2_f32_bf16 v41, v41, v81, 0                           // 0000008BEDAC: CC1A4029 1A02A329
	v_lshrrev_b32_e32 v81, 6, v11                              // 0000008BEDB4: 32A21686
	v_lshrrev_b32_e32 v11, 22, v11                             // 0000008BEDB8: 32161696
	s_waitcnt lgkmcnt(5)                                       // 0000008BEDBC: BF89FC57
	v_dot2_f32_bf16 v33, v34, v32, v33                         // 0000008BEDC0: CC1A4021 1C864122
	v_dot2_f32_bf16 v34, v38, v32, v37                         // 0000008BEDC8: CC1A4022 1C964126
	v_dot2_f32_bf16 v32, v42, v32, v41                         // 0000008BEDD0: CC1A4020 1CA6412A
	v_lshlrev_b32_e32 v37, 2, v87                              // 0000008BEDD8: 304AAE82
	v_and_b32_e32 v38, 0x3fc, v89                              // 0000008BEDDC: 364CB2FF 000003FC
	v_dot2_f32_bf16 v33, v35, v83, v33                         // 0000008BEDE4: CC1A4021 1C86A723
	v_dot2_f32_bf16 v34, v39, v83, v34                         // 0000008BEDEC: CC1A4022 1C8AA727
	v_dot2_f32_bf16 v32, v43, v83, v32                         // 0000008BEDF4: CC1A4020 1C82A72B
	v_and_b32_e32 v35, 0x3fc, v88                              // 0000008BEDFC: 3646B0FF 000003FC
	v_and_b32_e32 v39, 0x3fc, v91                              // 0000008BEE04: 364EB6FF 000003FC
	s_waitcnt lgkmcnt(4)                                       // 0000008BEE0C: BF89FC47
	v_dot2_f32_bf16 v33, v36, v8, v33                          // 0000008BEE10: CC1A4021 1C861124
	v_dot2_f32_bf16 v34, v40, v8, v34                          // 0000008BEE18: CC1A4022 1C8A1128
	v_dot2_f32_bf16 v8, v44, v8, v32                           // 0000008BEE20: CC1A4008 1C82112C
	ds_load_b32 v36, v37                                       // 0000008BEE28: D8D80000 24000025
	ds_load_b32 v40, v38                                       // 0000008BEE30: D8D80000 28000026
	ds_load_b32 v35, v35                                       // 0000008BEE38: D8D80000 23000023
	s_waitcnt vmcnt(8) lgkmcnt(6)                              // 0000008BEE40: BF892067
	v_dot2_f32_bf16 v33, v45, v84, v33                         // 0000008BEE44: CC1A4021 1C86A92D
	s_waitcnt vmcnt(7)                                         // 0000008BEE4C: BF891FF7
	v_dot2_f32_bf16 v34, v49, v84, v34                         // 0000008BEE50: CC1A4022 1C8AA931
	s_waitcnt vmcnt(6)                                         // 0000008BEE58: BF891BF7
	v_dot2_f32_bf16 v8, v53, v84, v8                           // 0000008BEE5C: CC1A4008 1C22A935
	v_cndmask_b32_e64 v38, v5, v6, s3                          // 0000008BEE64: D5010026 000E0D05
	v_and_b32_e32 v10, 0x3fc, v10                              // 0000008BEE6C: 361414FF 000003FC
	s_waitcnt lgkmcnt(5)                                       // 0000008BEE74: BF89FC57
	v_dot2_f32_bf16 v33, v46, v85, v33                         // 0000008BEE78: CC1A4021 1C86AB2E
	v_dot2_f32_bf16 v34, v50, v85, v34                         // 0000008BEE80: CC1A4022 1C8AAB32
	v_dot2_f32_bf16 v8, v54, v85, v8                           // 0000008BEE88: CC1A4008 1C22AB36
	v_lshlrev_b32_e32 v32, 2, v90                              // 0000008BEE90: 3040B482
	v_and_b32_e32 v37, 0x3fc, v81                              // 0000008BEE94: 364AA2FF 000003FC
	s_waitcnt lgkmcnt(4)                                       // 0000008BEE9C: BF89FC47
	v_dot2_f32_bf16 v33, v47, v86, v33                         // 0000008BEEA0: CC1A4021 1C86AD2F
	v_dot2_f32_bf16 v34, v51, v86, v34                         // 0000008BEEA8: CC1A4022 1C8AAD33
	v_dot2_f32_bf16 v8, v55, v86, v8                           // 0000008BEEB0: CC1A4008 1C22AD37
	v_and_b32_e32 v11, 0x3fc, v11                              // 0000008BEEB8: 361616FF 000003FC
	s_waitcnt lgkmcnt(3)                                       // 0000008BEEC0: BF89FC37
	v_dot2_f32_bf16 v33, v48, v9, v33                          // 0000008BEEC4: CC1A4021 1C861330
	v_dot2_f32_bf16 v34, v52, v9, v34                          // 0000008BEECC: CC1A4022 1C8A1334
	v_dot2_f32_bf16 v8, v56, v9, v8                            // 0000008BEED4: CC1A4008 1C221338
	ds_load_b32 v9, v10                                        // 0000008BEEDC: D8D80000 0900000A
	ds_load_b32 v10, v32                                       // 0000008BEEE4: D8D80000 0A000020
	ds_load_b32 v32, v37                                       // 0000008BEEEC: D8D80000 20000025
	ds_load_b32 v41, v39                                       // 0000008BEEF4: D8D80000 29000027
	ds_load_b32 v42, v11                                       // 0000008BEEFC: D8D80000 2A00000B
	v_cndmask_b32_e64 v39, v6, v7, s3                          // 0000008BEF04: D5010027 000E0F06
	s_waitcnt vmcnt(5) lgkmcnt(7)                              // 0000008BEF0C: BF891477
	v_dot2_f32_bf16 v11, v57, v36, v33                         // 0000008BEF10: CC1A400B 1C864939
	s_waitcnt vmcnt(4)                                         // 0000008BEF18: BF8913F7
	v_dot2_f32_bf16 v33, v61, v36, v34                         // 0000008BEF1C: CC1A4021 1C8A493D
	s_waitcnt vmcnt(3)                                         // 0000008BEF24: BF890FF7
	v_dot2_f32_bf16 v8, v65, v36, v8                           // 0000008BEF28: CC1A4008 1C224941
	v_cndmask_b32_e64 v37, v4, v5, s3                          // 0000008BEF30: D5010025 000E0B04
	v_cndmask_b32_e64 v36, v3, v4, s3                          // 0000008BEF38: D5010024 000E0903
	s_waitcnt lgkmcnt(5)                                       // 0000008BEF40: BF89FC57
	v_dot2_f32_bf16 v6, v58, v35, v11                          // 0000008BEF44: CC1A4006 1C2E473A
	v_dot2_f32_bf16 v11, v62, v35, v33                         // 0000008BEF4C: CC1A400B 1C86473E
	v_dot2_f32_bf16 v8, v66, v35, v8                           // 0000008BEF54: CC1A4008 1C224742
	v_cndmask_b32_e64 v35, v2, v3, s3                          // 0000008BEF5C: D5010023 000E0702
	v_cndmask_b32_e64 v34, v1, v2, s3                          // 0000008BEF64: D5010022 000E0501
	v_dot2_f32_bf16 v4, v59, v40, v6                           // 0000008BEF6C: CC1A4004 1C1A513B
	v_dot2_f32_bf16 v5, v63, v40, v11                          // 0000008BEF74: CC1A4005 1C2E513F
	v_dot2_f32_bf16 v6, v67, v40, v8                           // 0000008BEF7C: CC1A4006 1C225143
	v_cndmask_b32_e64 v33, v0, v1, s3                          // 0000008BEF84: D5010021 000E0300
	v_mov_b32_e32 v40, v7                                      // 0000008BEF8C: 7E500307
	s_waitcnt lgkmcnt(4)                                       // 0000008BEF90: BF89FC47
	v_dot2_f32_bf16 v2, v60, v9, v4                            // 0000008BEF94: CC1A4002 1C12133C
	v_dot2_f32_bf16 v3, v64, v9, v5                            // 0000008BEF9C: CC1A4003 1C161340
	v_dot2_f32_bf16 v4, v68, v9, v6                            // 0000008BEFA4: CC1A4004 1C1A1344
	v_add_nc_u32_e32 v19, 0x200, v19                           // 0000008BEFAC: 4A2626FF 00000200
	v_add_nc_u32_e32 v29, 0x100, v29                           // 0000008BEFB4: 4A3A3AFF 00000100
	s_waitcnt vmcnt(2) lgkmcnt(3)                              // 0000008BEFBC: BF890837
	v_dot2_f32_bf16 v0, v69, v10, v2                           // 0000008BEFC0: CC1A4000 1C0A1545
	s_waitcnt vmcnt(1)                                         // 0000008BEFC8: BF8907F7
	v_dot2_f32_bf16 v1, v73, v10, v3                           // 0000008BEFCC: CC1A4001 1C0E1549
	s_waitcnt vmcnt(0)                                         // 0000008BEFD4: BF8903F7
	v_dot2_f32_bf16 v2, v77, v10, v4                           // 0000008BEFD8: CC1A4002 1C12154D
	v_dual_mov_b32 v11, v15 :: v_dual_mov_b32 v10, v14         // 0000008BEFE0: CA10010F 0B0A010E
	s_waitcnt lgkmcnt(2)                                       // 0000008BEFE8: BF89FC27
	v_dot2_f32_bf16 v0, v70, v32, v0                           // 0000008BEFEC: CC1A4000 1C024146
	v_dot2_f32_bf16 v1, v74, v32, v1                           // 0000008BEFF4: CC1A4001 1C06414A
	v_dot2_f32_bf16 v2, v78, v32, v2                           // 0000008BEFFC: CC1A4002 1C0A414E
	v_dual_mov_b32 v9, v13 :: v_dual_mov_b32 v8, v12           // 0000008BF004: CA10010D 0908010C
	s_waitcnt lgkmcnt(1)                                       // 0000008BF00C: BF89FC17
	v_dot2_f32_bf16 v0, v71, v41, v0                           // 0000008BF010: CC1A4000 1C025347
	v_dot2_f32_bf16 v1, v75, v41, v1                           // 0000008BF018: CC1A4001 1C06534B
	v_dot2_f32_bf16 v2, v79, v41, v2                           // 0000008BF020: CC1A4002 1C0A534F
	v_mov_b32_e32 v32, v31                                     // 0000008BF028: 7E40031F
	s_waitcnt lgkmcnt(0)                                       // 0000008BF02C: BF89FC07
	v_dot2_f32_bf16 v0, v72, v42, v0                           // 0000008BF030: CC1A4000 1C025548
	v_dot2_f32_bf16 v1, v76, v42, v1                           // 0000008BF038: CC1A4001 1C06554C
	v_dot2_f32_bf16 v2, v80, v42, v2                           // 0000008BF040: CC1A4002 1C0A5550
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008BF048: BF870193
	v_fmac_f32_e32 v28, v82, v0                                // 0000008BF04C: 56380152
	v_fmac_f32_e32 v27, v82, v1                                // 0000008BF050: 56360352
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008BF054: BF870003
	v_dual_fmac_f32 v25, v82, v2 :: v_dual_mov_b32 v0, v33     // 0000008BF058: C8100552 19000121
	v_dual_mov_b32 v1, v34 :: v_dual_mov_b32 v2, v35           // 0000008BF060: CA100122 01020123
	v_dual_mov_b32 v3, v36 :: v_dual_mov_b32 v4, v37           // 0000008BF068: CA100124 03040125
	v_dual_mov_b32 v5, v38 :: v_dual_mov_b32 v6, v39           // 0000008BF070: CA100126 05060127
	v_mov_b32_e32 v7, v40                                      // 0000008BF078: 7E0E0328
	s_and_not1_b32 exec_lo, exec_lo, s7                        // 0000008BF07C: 917E077E
	s_cbranch_execz 28                                         // 0000008BF080: BFA5001C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x9f4>
	s_waitcnt vmcnt(0)                                         // 0000008BF084: BF8903F7
	v_dual_mov_b32 v13, v9 :: v_dual_add_nc_u32 v30, 16, v30   // 0000008BF088: CA200109 0D1E3C90
	v_dual_mov_b32 v12, v8 :: v_dual_mov_b32 v15, v11          // 0000008BF090: CA100108 0C0E010B
	v_mov_b32_e32 v14, v10                                     // 0000008BF098: 7E1C030A
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008BF09C: BF870003
	.long 0xd4430004                                           // 0000008BF0A0: D4430004
	v_cndmask_b32_e32 v1, s6, v30, vcc_lo                      // 0000008BF0A4: 02023C06
	s_mov_b32 s18, exec_lo                                     // 0000008BF0A8: BE92007E
	.long 0xd4c4007e                                           // 0000008BF0AC: D4C4007E
	v_cndmask_b32_e32 v1, s6, v30, vcc_lo                      // 0000008BF0B0: 02023C06
	s_cbranch_execz 65235                                      // 0000008BF0B4: BFA5FED3 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x504>
	.long 0xd7006a0c                                           // 0000008BF0B8: D7006A0C
	v_cndmask_b32_e32 v1, v18, v29, vcc_lo                     // 0000008BF0BC: 02023B12
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008BF0C0: BF870001
	v_add_co_ci_u32_e64 v13, null, 0, v26, vcc_lo              // 0000008BF0C4: D5207C0D 01AA3480
	v_cmp_ne_u32_e32 vcc_lo, 1, v24                            // 0000008BF0CC: 7C9A3081
	v_mov_b32_e32 v31, v32                                     // 0000008BF0D0: 7E3E0320
	global_load_b128 v[12:15], v[12:13], off                   // 0000008BF0D4: DC5E0000 0C7C000C
	s_cbranch_vccnz 65225                                      // 0000008BF0DC: BFA4FEC9 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x504>
	global_load_d16_b16 v31, v[21:22], off                     // 0000008BF0E0: DC820000 1F7C0015
	s_waitcnt vmcnt(0)                                         // 0000008BF0E8: BF8903F7
	v_cvt_f32_f16_e32 v31, v31                                 // 0000008BF0EC: 7E3E171F
	s_branch 65220                                             // 0000008BF0F0: BFA0FEC4 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x504>
	s_or_b32 exec_lo, exec_lo, s7                              // 0000008BF0F4: 8C7E077E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008BF0F8: BF8700A9
	s_or_b32 exec_lo, exec_lo, s5                              // 0000008BF0FC: 8C7E057E
	.long 0xd71f0000                                           // 0000008BF100: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000008BF104: 020100C1
	v_xor_b32_e32 v1, 8, v0                                    // 0000008BF108: 3A020088
	v_xor_b32_e32 v4, 4, v0                                    // 0000008BF10C: 3A080084
	v_xor_b32_e32 v7, 2, v0                                    // 0000008BF110: 3A0E0082
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000008BF114: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v1                            // 0000008BF118: 7C9802A0
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 0000008BF11C: 02020300
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 0000008BF120: 7C9808A0
	v_cndmask_b32_e32 v4, v0, v4, vcc_lo                       // 0000008BF124: 02080900
	v_cmp_gt_u32_e32 vcc_lo, 32, v7                            // 0000008BF128: 7C980EA0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008BF12C: BF870002
	v_lshlrev_b32_e32 v4, 2, v4                                // 0000008BF130: 30080882
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000008BF134: 30020282
	ds_bpermute_b32 v2, v1, v28                                // 0000008BF138: DACC0000 02001C01
	s_waitcnt lgkmcnt(0)                                       // 0000008BF140: BF89FC07
	v_add_f32_e32 v2, v28, v2                                  // 0000008BF144: 0604051C
	ds_bpermute_b32 v3, v1, v27                                // 0000008BF148: DACC0000 03001B01
	ds_bpermute_b32 v1, v1, v25                                // 0000008BF150: DACC0000 01001901
	ds_bpermute_b32 v5, v4, v2                                 // 0000008BF158: DACC0000 05000204
	v_cndmask_b32_e32 v7, v0, v7, vcc_lo                       // 0000008BF160: 020E0F00
	s_waitcnt lgkmcnt(2)                                       // 0000008BF164: BF89FC27
	v_add_f32_e32 v3, v27, v3                                  // 0000008BF168: 0606071B
	s_waitcnt lgkmcnt(1)                                       // 0000008BF16C: BF89FC17
	v_add_f32_e32 v1, v25, v1                                  // 0000008BF170: 06020319
	s_waitcnt lgkmcnt(0)                                       // 0000008BF174: BF89FC07
	v_add_f32_e32 v2, v2, v5                                   // 0000008BF178: 06040B02
	ds_bpermute_b32 v6, v4, v3                                 // 0000008BF17C: DACC0000 06000304
	ds_bpermute_b32 v4, v4, v1                                 // 0000008BF184: DACC0000 04000104
	v_lshlrev_b32_e32 v7, 2, v7                                // 0000008BF18C: 300E0E82
	s_waitcnt lgkmcnt(0)                                       // 0000008BF190: BF89FC07
	v_dual_add_f32 v3, v3, v6 :: v_dual_add_f32 v4, v1, v4     // 0000008BF194: C9080D03 03040901
	ds_bpermute_b32 v1, v7, v2                                 // 0000008BF19C: DACC0000 01000207
	ds_bpermute_b32 v5, v7, v3                                 // 0000008BF1A4: DACC0000 05000307
	ds_bpermute_b32 v6, v7, v4                                 // 0000008BF1AC: DACC0000 06000407
	v_xor_b32_e32 v7, 1, v0                                    // 0000008BF1B4: 3A0E0081
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000008BF1B8: BF870131
	v_cmp_gt_u32_e32 vcc_lo, 32, v7                            // 0000008BF1BC: 7C980EA0
	v_cndmask_b32_e32 v0, v0, v7, vcc_lo                       // 0000008BF1C0: 02000F00
	v_cmp_eq_u32_e32 vcc_lo, 0, v23                            // 0000008BF1C4: 7C942E80
	v_lshlrev_b32_e32 v7, 2, v0                                // 0000008BF1C8: 300E0082
	s_waitcnt lgkmcnt(2)                                       // 0000008BF1CC: BF89FC27
	v_add_f32_e32 v1, v2, v1                                   // 0000008BF1D0: 06020302
	s_and_b32 s2, vcc_lo, s2                                   // 0000008BF1D4: 8B02026A
	s_waitcnt lgkmcnt(1)                                       // 0000008BF1D8: BF89FC17
	v_add_f32_e32 v0, v3, v5                                   // 0000008BF1DC: 06000B03
	s_waitcnt lgkmcnt(0)                                       // 0000008BF1E0: BF89FC07
	v_add_f32_e32 v4, v4, v6                                   // 0000008BF1E4: 06080D04
	ds_bpermute_b32 v2, v7, v1                                 // 0000008BF1E8: DACC0000 02000107
	ds_bpermute_b32 v3, v7, v0                                 // 0000008BF1F0: DACC0000 03000007
	ds_bpermute_b32 v5, v7, v4                                 // 0000008BF1F8: DACC0000 05000407
	s_and_saveexec_b32 s3, s2                                  // 0000008BF200: BE832002
	s_cbranch_execz 85                                         // 0000008BF204: BFA50055 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0xc5c>
	v_ashrrev_i32_e32 v6, 31, v17                              // 0000008BF208: 340C229F
	s_load_b64 s[2:3], s[0:1], 0x40                            // 0000008BF20C: F4040080 F8000040
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000008BF214: BF890007
	v_dual_mov_b32 v10, s12 :: v_dual_add_f32 v3, v0, v3       // 0000008BF218: CA08000C 0A020700
	v_add_f32_e32 v8, v4, v5                                   // 0000008BF220: 06100B04
	v_lshrrev_b32_e32 v6, 23, v6                               // 0000008BF224: 320C0C97
	.long 0x7f163880                                           // 0000008BF228: 7F163880
	s_lshr_b32 s1, s17, 31                                     // 0000008BF22C: 85019F11
	.long 0x7e163983                                           // 0000008BF230: 7E163983
	v_mov_b32_e32 v9, s13                                      // 0000008BF234: 7E12020D
	.long 0xd7006a06                                           // 0000008BF238: D7006A06
	v_cndmask_b32_e32 v1, v16, v6, vcc_lo                      // 0000008BF23C: 02020D10
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008BF240: BF870111
	v_add_co_ci_u32_e64 v7, null, 0, v17, vcc_lo               // 0000008BF244: D5207C07 01AA2280
	v_and_b32_e32 v6, 0xfffffe00, v6                           // 0000008BF24C: 360C0CFF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008BF254: BF870091
	.long 0xd7016a04                                           // 0000008BF258: D7016A04
	v_cndmask_b32_e32 v1, v16, v6, vcc_lo                      // 0000008BF25C: 02020D10
	v_sub_co_ci_u32_e64 v5, null, v17, v7, vcc_lo              // 0000008BF260: D5217C05 01AA0F11
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008BF268: BF870112
	.long 0xd7000000                                           // 0000008BF26C: D7000000
	v_cndmask_b32_e32 v1, 0xffffff00, v4, vcc_lo               // 0000008BF270: 020208FF FFFFFF00
	v_cmp_gt_i64_e32 vcc_lo, 0x100, v[4:5]                     // 0000008BF278: 7CA808FF 00000100
	v_add_f32_e32 v2, v1, v2                                   // 0000008BF280: 06040501
	v_add_co_ci_u32_e64 v1, null, -1, v5, s0                   // 0000008BF284: D5207C01 00020AC1
	s_add_u32 s0, s16, s1                                      // 0000008BF28C: 80000110
	s_addc_u32 s1, s17, 0                                      // 0000008BF290: 82018011
	v_dual_cndmask_b32 v0, v0, v4 :: v_dual_cndmask_b32 v1, v1, v5// 0000008BF294: CA520900 00000B01
	v_cndmask_b32_e32 v5, s2, v10, vcc_lo                      // 0000008BF29C: 020A1402
	v_cndmask_b32_e32 v9, s3, v9, vcc_lo                       // 0000008BF2A0: 02121203
	.long 0x7e083982                                           // 0000008BF2A4: 7E083982
	.long 0x7f08398b                                           // 0000008BF2A8: 7F08398B
	.long 0xd73c0000                                           // 0000008BF2AC: D73C0000
	v_cndmask_b32_e32 v1, 1, v0, vcc_lo                        // 0000008BF2B0: 02020081
	.long 0xd7006a05                                           // 0000008BF2B4: D7006A05
	v_cndmask_b32_e32 v1, v5, v6, vcc_lo                       // 0000008BF2B8: 02020D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000008BF2BC: BF870211
	v_add_co_ci_u32_e64 v6, null, v9, v7, vcc_lo               // 0000008BF2C0: D5207C06 01AA0F09
	v_and_b32_e32 v4, 1, v4                                    // 0000008BF2C8: 36080881
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000008BF2CC: BF870223
	.long 0xd7006a00                                           // 0000008BF2D0: D7006A00
	v_cndmask_b32_e32 v1, v5, v0, vcc_lo                       // 0000008BF2D4: 02020105
	v_and_b32_e32 v10, 1, v11                                  // 0000008BF2D8: 36141681
	v_add_co_ci_u32_e64 v1, null, v6, v1, vcc_lo               // 0000008BF2DC: D5207C01 01AA0306
	s_and_b32 s2, s0, -2                                       // 0000008BF2E4: 8B02C200
	v_add3_u32 v7, v2, v4, 0x7fff                              // 0000008BF2E8: D6550007 03FE0902 00007FFF
	.long 0xd7006a02                                           // 0000008BF2F4: D7006A02
	v_cndmask_b32_e32 v0, v0, v2, vcc_lo                       // 0000008BF2F8: 02000500
	v_bfe_u32 v4, v8, 16, 1                                    // 0000008BF2FC: D6100004 02052108
	v_add3_u32 v6, v3, v10, 0x7fff                             // 0000008BF304: D6550006 03FE1503 00007FFF
	v_add_co_ci_u32_e64 v3, null, s1, v1, vcc_lo               // 0000008BF310: D5207C03 01AA0201
	s_lshl_b64 s[0:1], s[0:1], 1                               // 0000008BF318: 84808100
	v_add3_u32 v8, v8, v4, 0x7fff                              // 0000008BF31C: D6550008 03FE0908 00007FFF
	s_and_b32 s0, s0, -4                                       // 0000008BF328: 8B00C400
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008BF32C: BF870099
	.long 0xd7006a04                                           // 0000008BF330: D7006A04
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 0000008BF334: 02000100
	v_add_co_ci_u32_e64 v5, null, s1, v1, vcc_lo               // 0000008BF338: D5207C05 01AA0201
	s_clause 0x2                                               // 0000008BF340: BF850002
	global_store_d16_hi_b16 v[0:1], v7, off                    // 0000008BF344: DC960000 007C0700
	global_store_d16_hi_b16 v[2:3], v6, off                    // 0000008BF34C: DC960000 007C0602
	global_store_d16_hi_b16 v[4:5], v8, off                    // 0000008BF354: DC960000 007C0804
	s_endpgm                                                   // 0000008BF35C: BFB00000
		...

