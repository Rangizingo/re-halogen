0000000000291400 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl>:
; _ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl():
	s_clause 0x3                                               // 000000291400: BF850003
	s_load_b32 s3, s[0:1], 0x120                               // 000000291404: F40000C0 F8000120
	s_load_b32 s4, s[0:1], 0x88                                // 00000029140C: F4000100 F8000088
	s_load_b32 s5, s[0:1], 0xd0                                // 000000291414: F4000140 F80000D0
	s_load_b32 s6, s[0:1], 0x118                               // 00000029141C: F4000180 F8000118
	v_and_b32_e32 v23, 15, v0                                  // 000000291424: 362E008F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000291428: BF870001
	v_lshlrev_b32_e32 v2, 2, v23                               // 00000029142C: 30042E82
	s_waitcnt lgkmcnt(0)                                       // 000000291430: BF89FC07
	s_cmp_gt_i32 s3, 1                                         // 000000291434: BF028103
	s_cselect_b32 s7, -1, 0                                    // 000000291438: 980780C1
	s_cmp_ge_i32 s2, s4                                        // 00000029143C: BF030402
	s_cselect_b32 s4, -1, 0                                    // 000000291440: 980480C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000291444: BF870009
	s_and_b32 s4, s7, s4                                       // 000000291448: 8B040407
	s_cmp_gt_i32 s3, 2                                         // 00000029144C: BF028203
	v_cndmask_b32_e64 v1, 0, 1, s4                             // 000000291450: D5010001 00110280
	s_cselect_b32 s7, -1, 0                                    // 000000291458: 980780C1
	s_cmp_ge_i32 s2, s5                                        // 00000029145C: BF030502
	s_cselect_b32 s5, -1, 0                                    // 000000291460: 980580C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000291464: BF870009
	s_and_b32 s4, s7, s5                                       // 000000291468: 8B040507
	s_cmp_gt_i32 s3, 3                                         // 00000029146C: BF028303
	v_readfirstlane_b32 s5, v1                                 // 000000291470: 7E0A0501
	s_cselect_b32 s3, -1, 0                                    // 000000291474: 980380C1
	s_cmp_ge_i32 s2, s6                                        // 000000291478: BF030602
	v_lshrrev_b32_e32 v1, 4, v0                                // 00000029147C: 32020084
	s_cselect_b32 s6, -1, 0                                    // 000000291480: 980680C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000291484: BF870009
	s_and_b32 s3, s3, s6                                       // 000000291488: 8B030603
	s_and_b32 s4, s4, exec_lo                                  // 00000029148C: 8B047E04
	s_cselect_b32 s4, 2, s5                                    // 000000291490: 98040582
	s_and_b32 s3, s3, exec_lo                                  // 000000291494: 8B037E03
	s_cselect_b32 s3, 3, s4                                    // 000000291498: 98030483
	v_lshlrev_b32_e32 v3, 2, v1                                // 00000029149C: 30060282
	s_mulk_i32 s3, 0x48                                        // 0000002914A0: B8030048
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002914A4: BF870009
	s_add_u32 s16, s0, s3                                      // 0000002914A8: 80100300
	s_addc_u32 s17, s1, 0                                      // 0000002914AC: 82118001
	s_clause 0x1                                               // 0000002914B0: BF850001
	s_load_b256 s[4:11], s[16:17], 0x18                        // 0000002914B4: F40C0108 F8000018
	s_load_b64 s[18:19], s[16:17], null                        // 0000002914BC: F4040488 F8000000
	s_waitcnt lgkmcnt(0)                                       // 0000002914C4: BF89FC07
	.long 0xd4540003                                           // 0000002914C8: D4540003
	v_cndmask_b32_e32 v0, s10, v136, vcc_lo                    // 0000002914CC: 0201100A
	s_and_b32 s12, s3, exec_lo                                 // 0000002914D0: 8B0C7E03
	s_load_b128 s[12:15], s[0:1], 0x128                        // 0000002914D4: F4080300 F8000128
	s_clause 0x1                                               // 0000002914DC: BF850001
	global_load_b32 v2, v2, s[18:19]                           // 0000002914E0: DC520000 02120002
	global_load_b32 v3, v3, s[18:19]                           // 0000002914E8: DC520000 03120003
	s_cselect_b32 s22, 1, 16                                   // 0000002914F0: 98169081
	s_cselect_b32 s23, 0, 4                                    // 0000002914F4: 98178480
	s_add_i32 s24, s22, -1                                     // 0000002914F8: 8118C116
	v_lshrrev_b32_e32 v24, s23, v1                             // 0000002914FC: 32300217
	v_and_b32_e32 v25, s24, v1                                 // 000000291500: 36320218
	s_waitcnt vmcnt(1)                                         // 000000291504: BF8907F7
	v_bfe_u32 v4, v2, 16, 1                                    // 000000291508: D6100004 02052102
	s_waitcnt vmcnt(0)                                         // 000000291510: BF8903F7
	v_bfe_u32 v5, v3, 16, 1                                    // 000000291514: D6100005 02052103
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000029151C: BF8701A2
	v_add3_u32 v2, v2, v4, 0x7fff                              // 000000291520: D6550002 03FE0902 00007FFF
	.long 0x7f083880                                           // 00000029152C: 7F083880
	v_add3_u32 v3, v3, v5, 0x7fff                              // 000000291530: D6550003 03FE0B03 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000029153C: BF870123
	.long 0x7e083982                                           // 000000291540: 7E083982
	v_lshlrev_b32_e32 v2, 2, v0                                // 000000291544: 30040082
	v_and_or_b32 v3, 0xffff0000, v3, v4                        // 000000291548: D6570003 041206FF FFFF0000
	ds_store_b32 v2, v3                                        // 000000291554: D8340000 00000302
	v_cvt_f32_ubyte0_e32 v2, s22                               // 00000029155C: 7E042216
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000291560: BF870291
	v_rcp_iflag_f32_e32 v2, v2                                 // 000000291564: 7E045702
	v_readfirstlane_b32 s21, v2                                // 000000291568: 7E2A0502
	s_waitcnt lgkmcnt(0)                                       // 00000029156C: BF89FC07
	s_barrier                                                  // 000000291570: BFBD0000
	buffer_gl0_inv                                             // 000000291574: E0AC0000 00000000
	s_load_b32 s20, s[16:17], 0x40                             // 00000029157C: F4000508 F8000040
	s_waitcnt lgkmcnt(0)                                       // 000000291584: BF89FC07
	s_sub_i32 s0, s2, s20                                      // 000000291588: 81801402
	s_mul_f32 s20, s21, 0x4f7ffffe                             // 00000029158C: A214FF15 4F7FFFFE
	s_ashr_i32 s1, s0, 31                                      // 000000291594: 86019F00
	s_and_b32 s3, s3, exec_lo                                  // 000000291598: 8B037E03
	s_cselect_b32 s3, 4, 0                                     // 00000029159C: 98038084
	s_cvt_u32_f32 s25, s20                                     // 0000002915A0: BE996714
	s_lshl_b64 s[0:1], s[0:1], s3                              // 0000002915A4: 84800300
	s_add_u32 s6, s18, s6                                      // 0000002915A8: 80060612
	s_addc_u32 s7, s19, s7                                     // 0000002915AC: 82070713
	s_ashr_i32 s3, s15, 31                                     // 0000002915B0: 86039F0F
	.long 0xd7000011                                           // 0000002915B4: D7000011
	v_cndmask_b32_e32 v1, s0, v24, vcc_lo                      // 0000002915B8: 02023000
	s_lshr_b32 s3, s3, 27                                      // 0000002915BC: 85039B03
	v_add_co_ci_u32_e64 v18, null, s1, 0, s0                   // 0000002915C0: D5207C12 00010001
	s_add_u32 s20, s14, s3                                     // 0000002915C8: 8014030E
	s_addc_u32 s21, s15, 0                                     // 0000002915CC: 8215800F
	s_sub_i32 s3, 0, s22                                       // 0000002915D0: 81831680
	s_lshr_b64 s[20:21], s[20:21], 5                           // 0000002915D4: 85948514
	s_mul_i32 s3, s3, s25                                      // 0000002915D8: 96031903
	s_add_i32 s21, s24, s20                                    // 0000002915DC: 81151418
	s_mul_hi_u32 s3, s25, s3                                   // 0000002915E0: 96830319
	s_abs_i32 s26, s21                                         // 0000002915E4: BE9A1515
	s_add_i32 s25, s25, s3                                     // 0000002915E8: 81190319
	s_ashr_i32 s21, s21, 31                                    // 0000002915EC: 86159F15
	s_mul_hi_u32 s3, s26, s25                                  // 0000002915F0: 9683191A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000002915F4: BF8704B9
	s_mul_i32 s23, s3, s22                                     // 0000002915F8: 96171603
	s_add_i32 s25, s3, 1                                       // 0000002915FC: 81198103
	s_sub_i32 s23, s26, s23                                    // 000000291600: 8197171A
	s_sub_i32 s26, s23, s22                                    // 000000291604: 819A1617
	s_cmp_ge_u32 s23, s22                                      // 000000291608: BF091617
	s_cselect_b32 s0, s25, s3                                  // 00000029160C: 98000319
	s_cselect_b32 s1, s26, s23                                 // 000000291610: 9801171A
	s_add_i32 s3, s0, 1                                        // 000000291614: 81038100
	s_cmp_ge_u32 s1, s22                                       // 000000291618: BF091601
	s_cselect_b32 s1, s3, s0                                   // 00000029161C: 98010003
	.long 0xd4540000                                           // 000000291620: D4540000
	v_cndmask_b32_e32 v1, s10, v17, vcc_lo                     // 000000291624: 0202220A
	s_xor_b32 s1, s1, s21                                      // 000000291628: 8D011501
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000029162C: BF870499
	s_sub_i32 s3, s1, s21                                      // 000000291630: 81831501
	.long 0xd72c000d                                           // 000000291634: D72C000D
	v_cndmask_b32_e32 v1, s3, v25, vcc_lo                      // 000000291638: 02023203
	v_cndmask_b32_e64 v9, 0, v18, s0                           // 00000029163C: D5010009 00022480
	v_cndmask_b32_e64 v10, 0, v17, s0                          // 000000291644: D501000A 00022280
	s_cmpk_lt_i32 s3, 0x81                                     // 00000029164C: B3830081
	s_cselect_b32 s1, -1, 0                                    // 000000291650: 980180C1
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000291654: BF870112
	.long 0xd72c0002                                           // 000000291658: D72C0002
	v_cndmask_b32_e32 v0, v9, v8, vcc_lo                       // 00000029165C: 02001109
	.long 0xd72c0003                                           // 000000291660: D72C0003
	v_cndmask_b32_e32 v0, v10, v9, vcc_lo                      // 000000291664: 0200130A
	v_add_nc_u32_e32 v1, s3, v13                               // 000000291668: 4A021A03
	v_mad_u64_u32 v[19:20], null, v10, s8, s[6:7]              // 00000029166C: D6FE7C13 0018110A
	v_add_nc_u32_e32 v27, v13, v23                             // 000000291674: 4A362F0D
	.long 0xd4510006                                           // 000000291678: D4510006
	v_cndmask_b32_e32 v0, s10, v137, vcc_lo                    // 00000029167C: 0201120A
	s_cmpk_gt_i32 s3, 0x80                                     // 000000291680: B2830080
	v_min_i32_e32 v26, s20, v1                                 // 000000291684: 22340214
	v_mov_b32_e32 v1, 0                                        // 000000291688: 7E020280
	s_cselect_b32 s7, -1, 0                                    // 00000029168C: 980780C1
	v_add3_u32 v28, v2, v20, v3                                // 000000291690: D655001C 040E2902
	s_delay_alu instid0(VALU_DEP_3)                            // 000000291698: BF870003
	.long 0xd4410003                                           // 00000029169C: D4410003
	v_cndmask_b32_e32 v1, v27, v26, vcc_lo                     // 0000002916A0: 0202351B
	s_and_b32 vcc_lo, exec_lo, s7                              // 0000002916A4: 8B6A077E
	s_cbranch_vccnz 151                                        // 0000002916A8: BFA40097 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x508>
	s_and_saveexec_b32 s8, s3                                  // 0000002916AC: BE882003
	s_cbranch_execz 11                                         // 0000002916B0: BFA5000B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x2e0>
	v_lshlrev_b32_e32 v1, 1, v27                               // 0000002916B4: 30023681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002916B8: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000002916BC: 3404029F
	.long 0xd7006a01                                           // 0000002916C0: D7006A01
	v_cndmask_b32_e32 v1, v19, v1, vcc_lo                      // 0000002916C4: 02020313
	v_add_co_ci_u32_e64 v2, null, v28, v2, vcc_lo              // 0000002916C8: D5207C02 01AA051C
	global_load_d16_b16 v1, v[1:2], off                        // 0000002916D0: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000002916D8: BF8903F7
	v_cvt_f32_f16_e32 v1, v1                                   // 0000002916DC: 7E021701
	s_or_b32 exec_lo, exec_lo, s8                              // 0000002916E0: 8C7E087E
	v_dual_mov_b32 v3, 0 :: v_dual_add_nc_u32 v4, 16, v27      // 0000002916E4: CA200080 03043690
	v_mov_b32_e32 v2, 0                                        // 0000002916EC: 7E040280
	s_mov_b32 s3, exec_lo                                      // 0000002916F0: BE83007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002916F4: BF870002
	.long 0xd4c1007e                                           // 0000002916F8: D4C1007E
	v_cndmask_b32_e32 v1, v4, v26, vcc_lo                      // 0000002916FC: 02023504
	s_cbranch_execz 11                                         // 000000291700: BFA5000B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x330>
	v_lshlrev_b32_e32 v2, 1, v4                                // 000000291704: 30040881
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000291708: BF8700A1
	v_ashrrev_i32_e32 v5, 31, v2                               // 00000029170C: 340A049F
	.long 0xd7006a04                                           // 000000291710: D7006A04
	v_cndmask_b32_e32 v1, v19, v2, vcc_lo                      // 000000291714: 02020513
	v_add_co_ci_u32_e64 v5, null, v28, v5, vcc_lo              // 000000291718: D5207C05 01AA0B1C
	global_load_d16_b16 v2, v[4:5], off                        // 000000291720: DC820000 027C0004
	s_waitcnt vmcnt(0)                                         // 000000291728: BF8903F7
	v_cvt_f32_f16_e32 v2, v2                                   // 00000029172C: 7E041702
	s_or_b32 exec_lo, exec_lo, s3                              // 000000291730: 8C7E037E
	v_add_nc_u32_e32 v4, 32, v27                               // 000000291734: 4A0836A0
	s_mov_b32 s3, exec_lo                                      // 000000291738: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000029173C: BF870001
	.long 0xd4c1007e                                           // 000000291740: D4C1007E
	v_cndmask_b32_e32 v1, v4, v26, vcc_lo                      // 000000291744: 02023504
	s_cbranch_execz 11                                         // 000000291748: BFA5000B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x378>
	v_lshlrev_b32_e32 v3, 1, v4                                // 00000029174C: 30060881
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000291750: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000291754: 3408069F
	.long 0xd7006a03                                           // 000000291758: D7006A03
	v_cndmask_b32_e32 v1, v19, v3, vcc_lo                      // 00000029175C: 02020713
	v_add_co_ci_u32_e64 v4, null, v28, v4, vcc_lo              // 000000291760: D5207C04 01AA091C
	global_load_d16_b16 v3, v[3:4], off                        // 000000291768: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 000000291770: BF8903F7
	v_cvt_f32_f16_e32 v3, v3                                   // 000000291774: 7E061703
	s_or_b32 exec_lo, exec_lo, s3                              // 000000291778: 8C7E037E
	v_dual_mov_b32 v5, 0 :: v_dual_add_nc_u32 v6, 48, v27      // 00000029177C: CA200080 050636B0
	v_mov_b32_e32 v4, 0                                        // 000000291784: 7E080280
	s_mov_b32 s3, exec_lo                                      // 000000291788: BE83007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000029178C: BF870002
	.long 0xd4c1007e                                           // 000000291790: D4C1007E
	v_cndmask_b32_e32 v1, v6, v26, vcc_lo                      // 000000291794: 02023506
	s_cbranch_execz 11                                         // 000000291798: BFA5000B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x3c8>
	v_lshlrev_b32_e32 v4, 1, v6                                // 00000029179C: 30080C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002917A0: BF8700A1
	v_ashrrev_i32_e32 v7, 31, v4                               // 0000002917A4: 340E089F
	.long 0xd7006a06                                           // 0000002917A8: D7006A06
	v_cndmask_b32_e32 v1, v19, v4, vcc_lo                      // 0000002917AC: 02020913
	v_add_co_ci_u32_e64 v7, null, v28, v7, vcc_lo              // 0000002917B0: D5207C07 01AA0F1C
	global_load_d16_b16 v4, v[6:7], off                        // 0000002917B8: DC820000 047C0006
	s_waitcnt vmcnt(0)                                         // 0000002917C0: BF8903F7
	v_cvt_f32_f16_e32 v4, v4                                   // 0000002917C4: 7E081704
	s_or_b32 exec_lo, exec_lo, s3                              // 0000002917C8: 8C7E037E
	v_add_nc_u32_e32 v6, 64, v27                               // 0000002917CC: 4A0C36C0
	s_mov_b32 s3, exec_lo                                      // 0000002917D0: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002917D4: BF870001
	.long 0xd4c1007e                                           // 0000002917D8: D4C1007E
	v_cndmask_b32_e32 v1, v6, v26, vcc_lo                      // 0000002917DC: 02023506
	s_cbranch_execz 11                                         // 0000002917E0: BFA5000B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x410>
	v_lshlrev_b32_e32 v5, 1, v6                                // 0000002917E4: 300A0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002917E8: BF8700A1
	v_ashrrev_i32_e32 v6, 31, v5                               // 0000002917EC: 340C0A9F
	.long 0xd7006a05                                           // 0000002917F0: D7006A05
	v_cndmask_b32_e32 v1, v19, v5, vcc_lo                      // 0000002917F4: 02020B13
	v_add_co_ci_u32_e64 v6, null, v28, v6, vcc_lo              // 0000002917F8: D5207C06 01AA0D1C
	global_load_d16_b16 v5, v[5:6], off                        // 000000291800: DC820000 057C0005
	s_waitcnt vmcnt(0)                                         // 000000291808: BF8903F7
	v_cvt_f32_f16_e32 v5, v5                                   // 00000029180C: 7E0A1705
	s_or_b32 exec_lo, exec_lo, s3                              // 000000291810: 8C7E037E
	v_dual_mov_b32 v7, 0 :: v_dual_add_nc_u32 v8, 0x50, v27    // 000000291814: CA200080 070836FF 00000050
	v_mov_b32_e32 v6, 0                                        // 000000291820: 7E0C0280
	s_mov_b32 s3, exec_lo                                      // 000000291824: BE83007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000291828: BF870002
	.long 0xd4c1007e                                           // 00000029182C: D4C1007E
	v_cndmask_b32_e32 v1, v8, v26, vcc_lo                      // 000000291830: 02023508
	s_cbranch_execz 11                                         // 000000291834: BFA5000B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x464>
	v_lshlrev_b32_e32 v6, 1, v8                                // 000000291838: 300C1081
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000029183C: BF8700A1
	v_ashrrev_i32_e32 v8, 31, v6                               // 000000291840: 34100C9F
	.long 0xd7006a0b                                           // 000000291844: D7006A0B
	v_cndmask_b32_e32 v1, v19, v6, vcc_lo                      // 000000291848: 02020D13
	v_add_co_ci_u32_e64 v12, null, v28, v8, vcc_lo             // 00000029184C: D5207C0C 01AA111C
	global_load_d16_b16 v6, v[11:12], off                      // 000000291854: DC820000 067C000B
	s_waitcnt vmcnt(0)                                         // 00000029185C: BF8903F7
	v_cvt_f32_f16_e32 v6, v6                                   // 000000291860: 7E0C1706
	s_or_b32 exec_lo, exec_lo, s3                              // 000000291864: 8C7E037E
	v_add_nc_u32_e32 v8, 0x60, v27                             // 000000291868: 4A1036FF 00000060
	s_mov_b32 s3, exec_lo                                      // 000000291870: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000291874: BF870001
	.long 0xd4c1007e                                           // 000000291878: D4C1007E
	v_cndmask_b32_e32 v1, v8, v26, vcc_lo                      // 00000029187C: 02023508
	s_cbranch_execz 11                                         // 000000291880: BFA5000B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x4b0>
	v_lshlrev_b32_e32 v7, 1, v8                                // 000000291884: 300E1081
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000291888: BF8700A1
	v_ashrrev_i32_e32 v8, 31, v7                               // 00000029188C: 34100E9F
	.long 0xd7006a07                                           // 000000291890: D7006A07
	v_cndmask_b32_e32 v1, v19, v7, vcc_lo                      // 000000291894: 02020F13
	v_add_co_ci_u32_e64 v8, null, v28, v8, vcc_lo              // 000000291898: D5207C08 01AA111C
	global_load_d16_b16 v7, v[7:8], off                        // 0000002918A0: DC820000 077C0007
	s_waitcnt vmcnt(0)                                         // 0000002918A8: BF8903F7
	v_cvt_f32_f16_e32 v7, v7                                   // 0000002918AC: 7E0E1707
	s_or_b32 exec_lo, exec_lo, s3                              // 0000002918B0: 8C7E037E
	v_dual_mov_b32 v8, 0 :: v_dual_add_nc_u32 v11, 0x70, v27   // 0000002918B4: CA200080 080A36FF 00000070
	s_mov_b32 s3, exec_lo                                      // 0000002918C0: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002918C4: BF870001
	.long 0xd4c1007e                                           // 0000002918C8: D4C1007E
	v_cndmask_b32_e32 v1, v11, v26, vcc_lo                     // 0000002918CC: 0202350B
	s_cbranch_execz 11                                         // 0000002918D0: BFA5000B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x500>
	v_lshlrev_b32_e32 v8, 1, v11                               // 0000002918D4: 30101681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002918D8: BF8700A1
	v_ashrrev_i32_e32 v12, 31, v8                              // 0000002918DC: 3418109F
	.long 0xd7006a0b                                           // 0000002918E0: D7006A0B
	v_cndmask_b32_e32 v1, v19, v8, vcc_lo                      // 0000002918E4: 02021113
	v_add_co_ci_u32_e64 v12, null, v28, v12, vcc_lo            // 0000002918E8: D5207C0C 01AA191C
	global_load_d16_b16 v8, v[11:12], off                      // 0000002918F0: DC820000 087C000B
	s_waitcnt vmcnt(0)                                         // 0000002918F8: BF8903F7
	v_cvt_f32_f16_e32 v8, v8                                   // 0000002918FC: 7E101708
	s_or_b32 exec_lo, exec_lo, s3                              // 000000291900: 8C7E037E
	s_branch 9                                                 // 000000291904: BFA00009 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x52c>
	v_mov_b32_e32 v1, 0                                        // 000000291908: 7E020280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000029190C: BF870001
	v_mov_b32_e32 v2, v1                                       // 000000291910: 7E040301
	v_mov_b32_e32 v3, v1                                       // 000000291914: 7E060301
	v_mov_b32_e32 v4, v1                                       // 000000291918: 7E080301
	v_mov_b32_e32 v5, v1                                       // 00000029191C: 7E0A0301
	v_mov_b32_e32 v6, v1                                       // 000000291920: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 000000291924: 7E0E0301
	v_mov_b32_e32 v8, v1                                       // 000000291928: 7E100301
	s_add_u32 s4, s18, s4                                      // 00000029192C: 80040412
	s_addc_u32 s5, s19, s5                                     // 000000291930: 82050513
	s_lshr_b32 s3, s15, 31                                     // 000000291934: 85039F0F
	v_mov_b32_e32 v29, 0                                       // 000000291938: 7E3A0280
	s_add_u32 s8, s14, s3                                      // 00000029193C: 8008030E
	s_addc_u32 s9, s15, 0                                      // 000000291940: 8209800F
	.long 0xd4410003                                           // 000000291944: D4410003
	v_cndmask_b32_e32 v1, v27, v26, vcc_lo                     // 000000291948: 0202351B
	s_ashr_i64 s[8:9], s[8:9], 1                               // 00000029194C: 86888108
	v_cndmask_b32_e64 v30, 0, 1, s7                            // 000000291950: D501001E 001D0280
	v_mad_u64_u32 v[20:21], null, v10, s8, s[4:5]              // 000000291958: D6FE7C14 0010110A
	.long 0xd72c000c                                           // 000000291960: D72C000C
	v_cndmask_b32_e32 v0, v10, v9, vcc_lo                      // 000000291964: 0200130A
	.long 0xd72c000e                                           // 000000291968: D72C000E
	v_cndmask_b32_e32 v0, v9, v8, vcc_lo                       // 00000029196C: 02001109
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v32, 0              // 000000291970: CA100080 09200080
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v11, 0             // 000000291978: CA100080 0A0A0080
	s_delay_alu instid0(VALU_DEP_3)                            // 000000291980: BF870003
	v_add3_u32 v31, v14, v21, v12                              // 000000291984: D655001F 04322B0E
	v_mov_b32_e32 v12, 0                                       // 00000029198C: 7E180280
	s_and_saveexec_b32 s4, s3                                  // 000000291990: BE842003
	s_cbranch_execz 22                                         // 000000291994: BFA50016 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x5f0>
	v_dual_mov_b32 v32, 0 :: v_dual_lshlrev_b32 v9, 4, v27     // 000000291998: CA220080 20083684
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002919A0: BF8700A1
	v_ashrrev_i32_e32 v10, 31, v9                              // 0000002919A4: 3414129F
	.long 0xd7006a09                                           // 0000002919A8: D7006A09
	v_cndmask_b32_e32 v1, v20, v9, vcc_lo                      // 0000002919AC: 02021314
	v_add_co_ci_u32_e64 v10, null, v31, v10, vcc_lo            // 0000002919B0: D5207C0A 01AA151F
	s_and_not1_b32 vcc_lo, exec_lo, s7                         // 0000002919B8: 916A077E
	global_load_b128 v[9:12], v[9:10], off                     // 0000002919BC: DC5E0000 097C0009
	s_cbranch_vccnz 10                                         // 0000002919C4: BFA4000A <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x5f0>
	v_lshlrev_b32_e32 v14, 1, v27                              // 0000002919C8: 301C3681
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002919CC: BF870091
	.long 0xd7006a0e                                           // 0000002919D0: D7006A0E
	v_cndmask_b32_e32 v1, v19, v14, vcc_lo                     // 0000002919D4: 02021D13
	v_add_co_ci_u32_e64 v15, null, 0, v28, vcc_lo              // 0000002919D8: D5207C0F 01AA3880
	global_load_d16_b16 v14, v[14:15], off                     // 0000002919E0: DC820000 0E7C000E
	s_waitcnt vmcnt(0)                                         // 0000002919E8: BF8903F7
	v_cvt_f32_f16_e32 v32, v14                                 // 0000002919EC: 7E40170E
	s_or_b32 exec_lo, exec_lo, s4                              // 0000002919F0: 8C7E047E
	s_and_saveexec_b32 s4, s3                                  // 0000002919F4: BE842003
	s_cbranch_execz 235                                        // 0000002919F8: BFA500EB <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x9a8>
	v_dual_mov_b32 v29, 0 :: v_dual_lshlrev_b32 v14, 5, v23    // 0000002919FC: CA220080 1D0E2E85
	v_add_nc_u32_e32 v15, 16, v27                              // 000000291A04: 4A1E3690
	s_mov_b32 s5, 0                                            // 000000291A08: BE850080
	v_mov_b32_e32 v35, v32                                     // 000000291A0C: 7E460320
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000291A10: BF870193
	v_lshl_add_u32 v21, v13, 5, v14                            // 000000291A14: D6460015 04390B0D
	v_lshlrev_b32_e32 v33, 4, v15                              // 000000291A1C: 30421E84
	v_lshlrev_b32_e32 v34, 1, v15                              // 000000291A20: 30441E81
	s_branch 188                                               // 000000291A24: BFA000BC <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x918>
	s_or_b32 exec_lo, exec_lo, s7                              // 000000291A28: 8C7E077E
	v_ashrrev_i32_e32 v22, 31, v21                             // 000000291A2C: 342C2A9F
	v_lshrrev_b32_e32 v52, 6, v9                               // 000000291A30: 32681286
	v_lshrrev_b32_e32 v53, 14, v9                              // 000000291A34: 326A128E
	v_and_b32_e32 v54, 0xff, v10                               // 000000291A38: 366C14FF 000000FF
	v_lshrrev_b32_e32 v55, 6, v10                              // 000000291A40: 326E1486
	.long 0xd73c0024                                           // 000000291A44: D73C0024
	v_cndmask_b32_e32 v1, 1, v21, vcc_lo                       // 000000291A48: 02022A81
	v_and_b32_e32 v22, 0xff, v9                                // 000000291A4C: 362C12FF 000000FF
	v_and_b32_e32 v52, 0x3fc, v52                              // 000000291A54: 366868FF 000003FC
	v_and_b32_e32 v53, 0x3fc, v53                              // 000000291A5C: 366A6AFF 000003FC
	v_lshrrev_b32_e32 v9, 22, v9                               // 000000291A64: 32121296
	v_lshrrev_b32_e32 v56, 14, v10                             // 000000291A68: 3270148E
	.long 0xd7006a30                                           // 000000291A6C: D7006A30
	v_cndmask_b32_e32 v1, s12, v36, vcc_lo                     // 000000291A70: 0202480C
	s_delay_alu instid0(VALU_DEP_1)                            // 000000291A74: BF870001
	v_add_co_ci_u32_e64 v49, null, s13, v37, vcc_lo            // 000000291A78: D5207C31 01AA4A0D
	v_lshlrev_b32_e32 v22, 2, v22                              // 000000291A80: 302C2C82
	ds_load_b32 v52, v52                                       // 000000291A84: D8D80000 34000034
	ds_load_b32 v53, v53                                       // 000000291A8C: D8D80000 35000035
	s_clause 0x3                                               // 000000291A94: BF850003
	global_load_b128 v[36:39], v[48:49], off                   // 000000291A98: DC5E0000 247C0030
	global_load_b128 v[40:43], v[48:49], off offset:16         // 000000291AA0: DC5E0010 287C0030
	global_load_b128 v[44:47], v[48:49], off offset:32         // 000000291AA8: DC5E0020 2C7C0030
	global_load_b128 v[48:51], v[48:49], off offset:48         // 000000291AB0: DC5E0030 307C0030
	v_lshrrev_b32_e32 v10, 22, v10                             // 000000291AB8: 32141496
	ds_load_b32 v22, v22                                       // 000000291ABC: D8D80000 16000016
	v_and_b32_e32 v9, 0x3fc, v9                                // 000000291AC4: 361212FF 000003FC
	v_lshlrev_b32_e32 v54, 2, v54                              // 000000291ACC: 306C6C82
	v_and_b32_e32 v55, 0x3fc, v55                              // 000000291AD0: 366E6EFF 000003FC
	v_and_b32_e32 v56, 0x3fc, v56                              // 000000291AD8: 367070FF 000003FC
	v_and_b32_e32 v10, 0x3fc, v10                              // 000000291AE0: 361414FF 000003FC
	ds_load_b32 v9, v9                                         // 000000291AE8: D8D80000 09000009
	ds_load_b32 v54, v54                                       // 000000291AF0: D8D80000 36000036
	ds_load_b32 v55, v55                                       // 000000291AF8: D8D80000 37000037
	ds_load_b32 v56, v56                                       // 000000291B00: D8D80000 38000038
	ds_load_b32 v10, v10                                       // 000000291B08: D8D80000 0A00000A
	v_add_nc_u32_e32 v34, 32, v34                              // 000000291B10: 4A4444A0
	s_and_b32 s3, exec_lo, s3                                  // 000000291B14: 8B03037E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000291B18: BF870149
	s_or_b32 s5, s3, s5                                        // 000000291B1C: 8C050503
	s_waitcnt vmcnt(3) lgkmcnt(5)                              // 000000291B20: BF890C57
	v_dot2_f32_bf16 v22, v36, v22, 0                           // 000000291B24: CC1A4016 1A022D24
	v_and_b32_e32 v36, 0xff, v11                               // 000000291B2C: 364816FF 000000FF
	v_dot2_f32_bf16 v22, v37, v52, v22                         // 000000291B34: CC1A4016 1C5A6925
	v_lshrrev_b32_e32 v37, 6, v11                              // 000000291B3C: 324A1686
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000291B40: BF8701A2
	v_dot2_f32_bf16 v22, v38, v53, v22                         // 000000291B44: CC1A4016 1C5A6B26
	v_lshrrev_b32_e32 v38, 14, v11                             // 000000291B4C: 324C168E
	v_and_b32_e32 v37, 0x3fc, v37                              // 000000291B50: 364A4AFF 000003FC
	v_lshrrev_b32_e32 v11, 22, v11                             // 000000291B58: 32161696
	s_waitcnt lgkmcnt(4)                                       // 000000291B5C: BF89FC47
	v_dot2_f32_bf16 v9, v39, v9, v22                           // 000000291B60: CC1A4009 1C5A1327
	v_and_b32_e32 v38, 0x3fc, v38                              // 000000291B68: 364C4CFF 000003FC
	v_lshrrev_b32_e32 v39, 6, v12                              // 000000291B70: 324E1886
	ds_load_b32 v37, v37                                       // 000000291B74: D8D80000 25000025
	s_waitcnt vmcnt(2) lgkmcnt(4)                              // 000000291B7C: BF890847
	v_dot2_f32_bf16 v9, v40, v54, v9                           // 000000291B80: CC1A4009 1C266D28
	ds_load_b32 v38, v38                                       // 000000291B88: D8D80000 26000026
	v_lshrrev_b32_e32 v40, 14, v12                             // 000000291B90: 3250188E
	v_and_b32_e32 v39, 0x3fc, v39                              // 000000291B94: 364E4EFF 000003FC
	s_waitcnt lgkmcnt(4)                                       // 000000291B9C: BF89FC47
	v_dot2_f32_bf16 v9, v41, v55, v9                           // 000000291BA0: CC1A4009 1C266F29
	v_cndmask_b32_e64 v41, v6, v7, s1                          // 000000291BA8: D5010029 00060F06
	v_and_b32_e32 v40, 0x3fc, v40                              // 000000291BB0: 365050FF 000003FC
	s_waitcnt lgkmcnt(3)                                       // 000000291BB8: BF89FC37
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000291BBC: BF870133
	v_dot2_f32_bf16 v9, v42, v56, v9                           // 000000291BC0: CC1A4009 1C26712A
	v_cndmask_b32_e64 v42, v7, v8, s1                          // 000000291BC8: D501002A 00061107
	s_waitcnt lgkmcnt(2)                                       // 000000291BD0: BF89FC27
	v_dot2_f32_bf16 v9, v43, v10, v9                           // 000000291BD4: CC1A4009 1C26152B
	v_dual_mov_b32 v43, v8 :: v_dual_lshlrev_b32 v22, 2, v36   // 000000291BDC: CA220108 2B164882
	v_and_b32_e32 v36, 0xff, v12                               // 000000291BE4: 364818FF 000000FF
	v_lshrrev_b32_e32 v12, 22, v12                             // 000000291BEC: 32181896
	ds_load_b32 v22, v22                                       // 000000291BF0: D8D80000 16000016
	v_lshlrev_b32_e32 v36, 2, v36                              // 000000291BF8: 30484882
	v_and_b32_e32 v12, 0x3fc, v12                              // 000000291BFC: 361818FF 000003FC
	s_waitcnt vmcnt(1) lgkmcnt(0)                              // 000000291C04: BF890407
	v_dot2_f32_bf16 v9, v44, v22, v9                           // 000000291C08: CC1A4009 1C262D2C
	v_cndmask_b32_e64 v22, v32, v1, s1                         // 000000291C10: D5010016 00060320
	v_mov_b32_e32 v32, v35                                     // 000000291C18: 7E400323
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000291C1C: BF870123
	v_dot2_f32_bf16 v9, v45, v37, v9                           // 000000291C20: CC1A4009 1C264B2D
	v_cndmask_b32_e64 v37, v2, v3, s1                          // 000000291C28: D5010025 00060702
	v_dot2_f32_bf16 v9, v46, v38, v9                           // 000000291C30: CC1A4009 1C264D2E
	v_cndmask_b32_e64 v38, v3, v4, s1                          // 000000291C38: D5010026 00060903
	v_and_b32_e32 v11, 0x3fc, v11                              // 000000291C40: 361616FF 000003FC
	ds_load_b32 v10, v11                                       // 000000291C48: D8D80000 0A00000B
	ds_load_b32 v11, v36                                       // 000000291C50: D8D80000 0B000024
	ds_load_b32 v36, v39                                       // 000000291C58: D8D80000 24000027
	ds_load_b32 v52, v40                                       // 000000291C60: D8D80000 34000028
	ds_load_b32 v53, v12                                       // 000000291C68: D8D80000 3500000C
	v_cndmask_b32_e64 v40, v5, v6, s1                          // 000000291C70: D5010028 00060D05
	v_cndmask_b32_e64 v39, v4, v5, s1                          // 000000291C78: D5010027 00060B04
	v_mov_b32_e32 v12, v16                                     // 000000291C80: 7E180310
	s_waitcnt lgkmcnt(4)                                       // 000000291C84: BF89FC47
	v_dot2_f32_bf16 v9, v47, v10, v9                           // 000000291C88: CC1A4009 1C26152F
	v_mov_b32_e32 v10, v14                                     // 000000291C90: 7E14030E
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 000000291C94: BF890037
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000291C98: BF870132
	v_dot2_f32_bf16 v9, v48, v11, v9                           // 000000291C9C: CC1A4009 1C261730
	v_mov_b32_e32 v11, v15                                     // 000000291CA4: 7E16030F
	s_waitcnt lgkmcnt(2)                                       // 000000291CA8: BF89FC27
	v_dot2_f32_bf16 v5, v49, v36, v9                           // 000000291CAC: CC1A4005 1C264931
	v_cndmask_b32_e64 v36, v1, v2, s1                          // 000000291CB4: D5010024 00060501
	v_add_nc_u32_e32 v33, 0x100, v33                           // 000000291CBC: 4A4242FF 00000100
	v_mov_b32_e32 v9, v13                                      // 000000291CC4: 7E12030D
	v_add_nc_u32_e32 v21, 0x200, v21                           // 000000291CC8: 4A2A2AFF 00000200
	s_waitcnt lgkmcnt(1)                                       // 000000291CD0: BF89FC17
	v_dot2_f32_bf16 v1, v50, v52, v5                           // 000000291CD4: CC1A4001 1C166932
	s_waitcnt lgkmcnt(0)                                       // 000000291CDC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000291CE0: BF870091
	v_dot2_f32_bf16 v1, v51, v53, v1                           // 000000291CE4: CC1A4001 1C066B33
	v_fmac_f32_e32 v29, v22, v1                                // 000000291CEC: 563A0316
	v_dual_mov_b32 v1, v36 :: v_dual_mov_b32 v2, v37           // 000000291CF0: CA100124 01020125
	v_dual_mov_b32 v3, v38 :: v_dual_mov_b32 v4, v39           // 000000291CF8: CA100126 03040127
	v_dual_mov_b32 v5, v40 :: v_dual_mov_b32 v6, v41           // 000000291D00: CA100128 05060129
	v_dual_mov_b32 v7, v42 :: v_dual_mov_b32 v8, v43           // 000000291D08: CA10012A 0708012B
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 000000291D10: 917E057E
	s_cbranch_execz 35                                         // 000000291D14: BFA50023 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x9a4>
	s_waitcnt vmcnt(0)                                         // 000000291D18: BF8903F7
	v_dual_mov_b32 v14, v10 :: v_dual_add_nc_u32 v27, 16, v27  // 000000291D1C: CA20010A 0E1A3690
	v_dual_mov_b32 v13, v9 :: v_dual_mov_b32 v16, v12          // 000000291D24: CA100109 0D10010C
	v_mov_b32_e32 v15, v11                                     // 000000291D2C: 7E1E030B
	s_delay_alu instid0(VALU_DEP_3)                            // 000000291D30: BF870003
	.long 0xd4460003                                           // 000000291D34: D4460003
	v_cndmask_b32_e32 v1, v27, v26, vcc_lo                     // 000000291D38: 0202351B
	s_mov_b32 s7, exec_lo                                      // 000000291D3C: BE87007E
	.long 0xd4c1007e                                           // 000000291D40: D4C1007E
	v_cndmask_b32_e32 v1, v27, v26, vcc_lo                     // 000000291D44: 0202351B
	s_cbranch_execz 65335                                      // 000000291D48: BFA5FF37 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x628>
	v_ashrrev_i32_e32 v14, 31, v33                             // 000000291D4C: 341C429F
	.long 0xd7006a0d                                           // 000000291D50: D7006A0D
	v_cndmask_b32_e32 v1, v20, v33, vcc_lo                     // 000000291D54: 02024314
	v_mov_b32_e32 v35, v32                                     // 000000291D58: 7E460320
	s_delay_alu instid0(VALU_DEP_3)                            // 000000291D5C: BF870003
	v_add_co_ci_u32_e64 v14, null, v31, v14, vcc_lo            // 000000291D60: D5207C0E 01AA1D1F
	v_cmp_ne_u32_e32 vcc_lo, 1, v30                            // 000000291D68: 7C9A3C81
	global_load_b128 v[13:16], v[13:14], off                   // 000000291D6C: DC5E0000 0D7C000D
	s_cbranch_vccnz 65324                                      // 000000291D74: BFA4FF2C <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x628>
	v_ashrrev_i32_e32 v22, 31, v34                             // 000000291D78: 342C449F
	.long 0xd7006a23                                           // 000000291D7C: D7006A23
	v_cndmask_b32_e32 v1, v19, v34, vcc_lo                     // 000000291D80: 02024513
	s_delay_alu instid0(VALU_DEP_1)                            // 000000291D84: BF870001
	v_add_co_ci_u32_e64 v36, null, v28, v22, vcc_lo            // 000000291D88: D5207C24 01AA2D1C
	global_load_d16_b16 v22, v[35:36], off                     // 000000291D90: DC820000 167C0023
	s_waitcnt vmcnt(0)                                         // 000000291D98: BF8903F7
	v_cvt_f32_f16_e32 v35, v22                                 // 000000291D9C: 7E461716
	s_branch 65313                                             // 000000291DA0: BFA0FF21 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x628>
	s_or_b32 exec_lo, exec_lo, s5                              // 000000291DA4: 8C7E057E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000291DA8: BF870009
	s_or_b32 exec_lo, exec_lo, s4                              // 000000291DAC: 8C7E047E
	.long 0xd71f0001                                           // 000000291DB0: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000291DB4: 020100C1
	.long 0xd44a0001                                           // 000000291DB8: D44A0001
	v_cndmask_b32_e32 v1, 0, v23, vcc_lo                       // 000000291DBC: 02022E80
	s_mov_b32 s8, -1                                           // 000000291DC0: BE8800C1
	v_xor_b32_e32 v2, 8, v1                                    // 000000291DC4: 3A040288
	v_xor_b32_e32 v3, 4, v1                                    // 000000291DC8: 3A060284
	v_xor_b32_e32 v4, 2, v1                                    // 000000291DCC: 3A080282
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000291DD0: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 000000291DD4: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 000000291DD8: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v3                            // 000000291DDC: 7C9806A0
	v_cndmask_b32_e32 v3, v1, v3, vcc_lo                       // 000000291DE0: 02060701
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 000000291DE4: 7C9808A0
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo                       // 000000291DE8: 02080901
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000291DEC: BF870211
	v_lshlrev_b32_e32 v4, 2, v4                                // 000000291DF0: 30080882
	v_lshlrev_b32_e32 v3, 2, v3                                // 000000291DF4: 30060682
	v_lshlrev_b32_e32 v2, 2, v2                                // 000000291DF8: 30040482
	ds_bpermute_b32 v2, v2, v29                                // 000000291DFC: DACC0000 02001D02
	s_waitcnt lgkmcnt(0)                                       // 000000291E04: BF89FC07
	v_add_f32_e32 v2, v29, v2                                  // 000000291E08: 0604051D
	ds_bpermute_b32 v3, v3, v2                                 // 000000291E0C: DACC0000 03000203
	s_waitcnt lgkmcnt(0)                                       // 000000291E14: BF89FC07
	v_add_f32_e32 v2, v2, v3                                   // 000000291E18: 06040702
	ds_bpermute_b32 v3, v4, v2                                 // 000000291E1C: DACC0000 03000204
	v_xor_b32_e32 v4, 1, v1                                    // 000000291E24: 3A080281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000291E28: BF8700C1
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 000000291E2C: 7C9808A0
	v_cndmask_b32_e32 v1, v1, v4, vcc_lo                       // 000000291E30: 02020901
	s_and_b32 vcc_lo, exec_lo, s6                              // 000000291E34: 8B6A067E
	s_waitcnt lgkmcnt(0)                                       // 000000291E38: BF89FC07
	v_dual_add_f32 v2, v2, v3 :: v_dual_lshlrev_b32 v1, 2, v1  // 000000291E3C: C9220702 02000282
	ds_bpermute_b32 v1, v1, v2                                 // 000000291E44: DACC0000 01000201
	s_waitcnt lgkmcnt(0)                                       // 000000291E4C: BF89FC07
	v_add_f32_e32 v2, v2, v1                                   // 000000291E50: 06040302
	s_cbranch_vccz 362                                         // 000000291E54: BFA3016A <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1000>
	s_and_saveexec_b32 s3, s1                                  // 000000291E58: BE832001
	v_lshlrev_b32_e32 v1, 6, v24                               // 000000291E5C: 30023086
	s_delay_alu instid0(VALU_DEP_1)                            // 000000291E60: BF870001
	v_lshl_or_b32 v1, v25, 2, v1                               // 000000291E64: D6560001 04050519
	ds_store_b32 v1, v2 offset:1024                            // 000000291E6C: D8340400 00000201
	s_or_b32 exec_lo, exec_lo, s3                              // 000000291E74: 8C7E037E
	s_mov_b32 s8, 0                                            // 000000291E78: BE880080
	s_mov_b32 s9, exec_lo                                      // 000000291E7C: BE89007E
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000291E80: BF890007
	s_barrier                                                  // 000000291E84: BFBD0000
	buffer_gl0_inv                                             // 000000291E88: E0AC0000 00000000
	v_cmpx_eq_u32_e32 0, v0                                    // 000000291E90: 7D940080
	s_cbranch_execz 345                                        // 000000291E94: BFA50159 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0xffc>
	s_load_b32 s3, s[16:17], 0x40                              // 000000291E98: F40000C8 F8000040
	s_waitcnt lgkmcnt(0)                                       // 000000291EA0: BF89FC07
	s_sub_i32 s2, s2, s3                                       // 000000291EA4: 81820302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000291EA8: BF870499
	s_ashr_i32 s3, s2, 31                                      // 000000291EAC: 86039F02
	.long 0xd4530004                                           // 000000291EB0: D4530004
	v_cndmask_b32_e32 v0, s10, v2, vcc_lo                      // 000000291EB4: 0200040A
	s_and_b32 vcc_lo, exec_lo, s4                              // 000000291EB8: 8B6A047E
	s_cbranch_vccnz 335                                        // 000000291EBC: BFA4014F <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0xffc>
	v_mov_b32_e32 v0, 0                                        // 000000291EC0: 7E000280
	s_mov_b32 s13, -1                                          // 000000291EC4: BE8D00C1
	ds_load_b128 v[3:6], v0 offset:1024                        // 000000291EC8: DBFC0400 03000000
	ds_load_b128 v[7:10], v0 offset:1040                       // 000000291ED0: DBFC0410 07000000
	ds_load_b128 v[11:14], v0 offset:1056                      // 000000291ED8: DBFC0420 0B000000
	s_waitcnt lgkmcnt(2)                                       // 000000291EE0: BF89FC27
	v_readfirstlane_b32 s4, v3                                 // 000000291EE4: 7E080503
	v_readfirstlane_b32 s5, v4                                 // 000000291EE8: 7E0A0504
	v_readfirstlane_b32 s6, v5                                 // 000000291EEC: 7E0C0505
	s_add_f32 s4, s4, 0                                        // 000000291EF0: A0048004
	s_delay_alu instid0(SALU_CYCLE_3)                          // 000000291EF4: BF87000B
	s_add_f32 s4, s4, s5                                       // 000000291EF8: A0040504
	v_readfirstlane_b32 s5, v6                                 // 000000291EFC: 7E0A0506
	ds_load_b128 v[3:6], v0 offset:1072                        // 000000291F00: DBFC0430 03000000
	s_add_f32 s4, s4, s6                                       // 000000291F08: A0040604
	s_waitcnt lgkmcnt(2)                                       // 000000291F0C: BF89FC27
	v_readfirstlane_b32 s6, v7                                 // 000000291F10: 7E0C0507
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_2)// 000000291F14: BF870529
	s_add_f32 s4, s4, s5                                       // 000000291F18: A0040504
	v_readfirstlane_b32 s5, v8                                 // 000000291F1C: 7E0A0508
	s_add_f32 s4, s4, s6                                       // 000000291F20: A0040604
	v_readfirstlane_b32 s6, v9                                 // 000000291F24: 7E0C0509
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_2)// 000000291F28: BF87052A
	s_add_f32 s4, s4, s5                                       // 000000291F2C: A0040504
	v_readfirstlane_b32 s5, v10                                // 000000291F30: 7E0A050A
	s_add_f32 s4, s4, s6                                       // 000000291F34: A0040604
	s_waitcnt lgkmcnt(1)                                       // 000000291F38: BF89FC17
	v_readfirstlane_b32 s6, v11                                // 000000291F3C: 7E0C050B
	s_waitcnt lgkmcnt(0)                                       // 000000291F40: BF89FC07
	v_readfirstlane_b32 s10, v3                                // 000000291F44: 7E140503
	v_readfirstlane_b32 s12, v4                                // 000000291F48: 7E180504
	s_add_f32 s4, s4, s5                                       // 000000291F4C: A0040504
	v_readfirstlane_b32 s5, v12                                // 000000291F50: 7E0A050C
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_2)// 000000291F54: BF87052A
	s_add_f32 s4, s4, s6                                       // 000000291F58: A0040604
	v_readfirstlane_b32 s6, v13                                // 000000291F5C: 7E0C050D
	s_add_f32 s4, s4, s5                                       // 000000291F60: A0040504
	v_readfirstlane_b32 s5, v14                                // 000000291F64: 7E0A050E
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_2)// 000000291F68: BF87052A
	s_add_f32 s4, s4, s6                                       // 000000291F6C: A0040604
	s_load_b64 s[6:7], s[16:17], 0x38                          // 000000291F70: F4040188 F8000038
	s_add_f32 s11, s4, s5                                      // 000000291F78: A00B0504
	s_load_b64 s[4:5], s[16:17], 0x8                           // 000000291F7C: F4040108 F8000008
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_2)// 000000291F84: BF87052A
	s_add_f32 s10, s11, s10                                    // 000000291F88: A00A0A0B
	v_readfirstlane_b32 s11, v5                                // 000000291F8C: 7E160505
	s_add_f32 s10, s10, s12                                    // 000000291F90: A00A0C0A
	v_readfirstlane_b32 s12, v6                                // 000000291F94: 7E180506
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_2)// 000000291F98: BF87052A
	s_add_f32 s10, s10, s11                                    // 000000291F9C: A00A0B0A
	s_mov_b32 s11, 0                                           // 000000291FA0: BE8B0080
	s_add_f32 s10, s10, s12                                    // 000000291FA4: A00A0C0A
	s_waitcnt lgkmcnt(0)                                       // 000000291FA8: BF89FC07
	s_cmp_lt_i32 s7, 3                                         // 000000291FAC: BF048307
	s_mov_b32 s12, 0                                           // 000000291FB0: BE8C0080
	s_cbranch_scc1 142                                         // 000000291FB4: BFA2008E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0xdf0>
	s_cmp_gt_i32 s7, 3                                         // 000000291FB8: BF028307
	s_cbranch_scc0 90                                          // 000000291FBC: BFA1005A <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0xd28>
	s_cmp_gt_i32 s7, 4                                         // 000000291FC0: BF028407
	s_cbranch_scc0 47                                          // 000000291FC4: BFA1002F <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0xc84>
	s_cmp_eq_u32 s7, 5                                         // 000000291FC8: BF068507
	s_mov_b32 s12, -1                                          // 000000291FCC: BE8C00C1
	s_cbranch_scc0 43                                          // 000000291FD0: BFA1002B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0xc80>
	s_ashr_i32 s14, s2, 31                                     // 000000291FD4: 860E9F02
	s_load_b64 s[12:13], s[16:17], 0x10                        // 000000291FD8: F4040308 F8000010
	s_lshr_b32 s14, s14, 23                                    // 000000291FE0: 850E970E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000291FE4: BF870499
	s_add_i32 s14, s2, s14                                     // 000000291FE8: 810E0E02
	s_ashr_i32 s14, s14, 9                                     // 000000291FEC: 860E890E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000291FF0: BF870499
	s_ashr_i32 s15, s14, 31                                    // 000000291FF4: 860F9F0E
	s_lshl_b64 s[14:15], s[14:15], 9                           // 000000291FF8: 848E890E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000291FFC: BF8704A9
	s_sub_u32 s18, s2, s14                                     // 000000292000: 80920E02
	s_subb_u32 s19, s3, s15                                    // 000000292004: 82930F03
	.long 0xd4540014                                           // 000000292008: D4540014
	v_cndmask_b32_e32 v0, 0x100, v18, vcc_lo                   // 00000029200C: 020024FF 00000100
	s_and_b32 s21, s20, exec_lo                                // 000000292014: 8B157E14
	s_waitcnt lgkmcnt(0)                                       // 000000292018: BF89FC07
	s_cselect_b32 s21, s5, s13                                 // 00000029201C: 98150D05
	s_cselect_b32 s22, s4, s12                                 // 000000292020: 98160C04
	s_bfe_u32 s12, s10, 0x10010                                // 000000292024: 930CFF0A 00010010
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000029202C: BF870499
	s_add_i32 s12, s10, s12                                    // 000000292030: 810C0C0A
	s_add_i32 s23, s12, 0x7fff                                 // 000000292034: 8117FF0C 00007FFF
	s_add_u32 s12, s18, 0xffffff00                             // 00000029203C: 800CFF12 FFFFFF00
	s_addc_u32 s13, s19, -1                                    // 000000292044: 820DC113
	s_and_b32 s20, s20, exec_lo                                // 000000292048: 8B147E14
	s_cselect_b32 s13, s19, s13                                // 00000029204C: 980D0D13
	s_cselect_b32 s12, s18, s12                                // 000000292050: 980C0C12
	s_add_u32 s14, s22, s14                                    // 000000292054: 800E0E16
	v_dual_mov_b32 v0, 0 :: v_dual_mov_b32 v1, s23             // 000000292058: CA100080 00000017
	s_addc_u32 s15, s21, s15                                   // 000000292060: 820F0F15
	s_lshl_b64 s[12:13], s[12:13], 1                           // 000000292064: 848C810C
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000292068: BF870009
	s_add_u32 s14, s14, s12                                    // 00000029206C: 800E0C0E
	s_addc_u32 s15, s15, s13                                   // 000000292070: 820F0D0F
	s_mov_b32 s12, 0                                           // 000000292074: BE8C0080
	global_store_d16_hi_b16 v0, v1, s[14:15]                   // 000000292078: DC960000 000E0100
	s_mov_b32 s13, 0                                           // 000000292080: BE8D0080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000292084: BF870009
	s_and_b32 vcc_lo, exec_lo, s13                             // 000000292088: 8B6A0D7E
	s_cbranch_vccz 37                                          // 00000029208C: BFA30025 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0xd24>
	s_mul_f32 s13, s10, 0xbfb8aa3b                             // 000000292090: A20DFF0A BFB8AA3B
	s_lshl_b64 s[14:15], s[2:3], 2                             // 000000292098: 848E8202
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000029209C: BF870499
	s_add_u32 s14, s4, s14                                     // 0000002920A0: 800E0E04
	v_exp_f32_e32 v0, s13                                      // 0000002920A4: 7E004A0D
	s_addc_u32 s15, s5, s15                                    // 0000002920A8: 820F0F05
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002920AC: BF870095
	v_add_f32_e32 v0, 1.0, v0                                  // 0000002920B0: 060000F2
	v_div_scale_f32 v1, null, v0, v0, 1.0                      // 0000002920B4: D6FC7C01 03CA0100
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002920BC: BF870001
	v_rcp_f32_e32 v3, v1                                       // 0000002920C0: 7E065501
	v_xor_b32_e32 v1, 0x80000000, v1                           // 0000002920C4: 3A0202FF 80000000
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_1)   // 0000002920CC: BF870085
	v_fma_f32 v4, v1, v3, 1.0                                  // 0000002920D0: D6130004 03CA0701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002920D8: BF8700A1
	v_fmac_f32_e32 v3, v4, v3                                  // 0000002920DC: 56060704
	v_div_scale_f32 v5, vcc_lo, 1.0, v0, 1.0                   // 0000002920E0: D6FC6A05 03CA00F2
	v_mul_f32_e32 v4, v5, v3                                   // 0000002920E8: 10080705
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002920EC: BF870091
	v_fma_f32 v6, v1, v4, v5                                   // 0000002920F0: D6130006 04160901
	v_fmac_f32_e32 v4, v6, v3                                  // 0000002920F8: 56080706
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002920FC: BF870091
	v_fmac_f32_e32 v5, v1, v4                                  // 000000292100: 560A0901
	v_div_fmas_f32 v1, v5, v3, v4                              // 000000292104: D6370001 04120705
	s_delay_alu instid0(VALU_DEP_1)                            // 00000029210C: BF870001
	v_div_fixup_f32 v0, v1, v0, 1.0                            // 000000292110: D6270000 03CA0101
	v_mov_b32_e32 v1, 0                                        // 000000292118: 7E020280
	global_store_b32 v1, v0, s[14:15]                          // 00000029211C: DC6A0000 000E0001
	s_mov_b32 s13, 0                                           // 000000292124: BE8D0080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000292128: BF870009
	s_and_b32 vcc_lo, exec_lo, s13                             // 00000029212C: 8B6A0D7E
	s_cbranch_vccz 46                                          // 000000292130: BFA3002E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0xdec>
	s_bfe_u32 s13, s10, 0x10010                                // 000000292134: 930DFF0A 00010010
	s_lshl_b64 s[14:15], s[2:3], 2                             // 00000029213C: 848E8202
	s_add_i32 s13, s10, s13                                    // 000000292140: 810D0D0A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000292144: BF870499
	s_addk_i32 s13, 0x7fff                                     // 000000292148: B78D7FFF
	s_and_b32 s13, s13, 0xffff0000                             // 00000029214C: 8B0DFF0D FFFF0000
	s_add_u32 s14, s4, s14                                     // 000000292154: 800E0E04
	s_mul_f32 s13, s6, s13                                     // 000000292158: A20D0D06
	s_addc_u32 s15, s5, s15                                    // 00000029215C: 820F0F05
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 000000292160: BF87059A
	s_mul_f32 s13, s13, 0xbfb8aa3b                             // 000000292164: A20DFF0D BFB8AA3B
	v_exp_f32_e32 v0, s13                                      // 00000029216C: 7E004A0D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000292170: BF870095
	v_add_f32_e32 v0, 1.0, v0                                  // 000000292174: 060000F2
	v_div_scale_f32 v1, null, v0, v0, 1.0                      // 000000292178: D6FC7C01 03CA0100
	s_delay_alu instid0(VALU_DEP_1)                            // 000000292180: BF870001
	v_rcp_f32_e32 v3, v1                                       // 000000292184: 7E065501
	v_xor_b32_e32 v1, 0x80000000, v1                           // 000000292188: 3A0202FF 80000000
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_1)   // 000000292190: BF870085
	v_fma_f32 v4, v1, v3, 1.0                                  // 000000292194: D6130004 03CA0701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000029219C: BF8700A1
	v_fmac_f32_e32 v3, v4, v3                                  // 0000002921A0: 56060704
	v_div_scale_f32 v5, vcc_lo, 1.0, v0, 1.0                   // 0000002921A4: D6FC6A05 03CA00F2
	v_mul_f32_e32 v4, v5, v3                                   // 0000002921AC: 10080705
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002921B0: BF870091
	v_fma_f32 v6, v1, v4, v5                                   // 0000002921B4: D6130006 04160901
	v_fmac_f32_e32 v4, v6, v3                                  // 0000002921BC: 56080706
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002921C0: BF870091
	v_fmac_f32_e32 v5, v1, v4                                  // 0000002921C4: 560A0901
	v_div_fmas_f32 v1, v5, v3, v4                              // 0000002921C8: D6370001 04120705
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002921D0: BF870091
	v_div_fixup_f32 v0, v1, v0, 1.0                            // 0000002921D4: D6270000 03CA0101
	v_dual_mov_b32 v1, 0 :: v_dual_add_f32 v0, v0, v0          // 0000002921DC: CA080080 01000100
	global_store_b32 v1, v0, s[14:15]                          // 0000002921E4: DC6A0000 000E0001
	s_mov_b32 s13, 0                                           // 0000002921EC: BE8D0080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002921F0: BF870009
	s_and_b32 vcc_lo, exec_lo, s13                             // 0000002921F4: 8B6A0D7E
	s_cbranch_vccz 59                                          // 0000002921F8: BFA3003B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0xee8>
	s_cmp_gt_i32 s7, 1                                         // 0000002921FC: BF028107
	s_mov_b32 s11, -1                                          // 000000292200: BE8B00C1
	s_cbranch_scc0 50                                          // 000000292204: BFA10032 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0xed0>
	s_bfe_u32 s11, s10, 0x10010                                // 000000292208: 930BFF0A 00010010
	s_lshl_b64 s[14:15], s[2:3], 1                             // 000000292210: 848E8102
	s_add_i32 s11, s10, s11                                    // 000000292214: 810B0B0A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000292218: BF870499
	s_addk_i32 s11, 0x7fff                                     // 00000029221C: B78B7FFF
	s_and_b32 s11, s11, 0xffff0000                             // 000000292220: 8B0BFF0B FFFF0000
	s_add_u32 s14, s4, s14                                     // 000000292228: 800E0E04
	s_mul_f32 s11, s11, 0xbfb8aa3b                             // 00000029222C: A20BFF0B BFB8AA3B
	s_addc_u32 s15, s5, s15                                    // 000000292234: 820F0F05
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 000000292238: BF8702AA
	v_exp_f32_e32 v0, s11                                      // 00000029223C: 7E004A0B
	s_mov_b32 s11, 0                                           // 000000292240: BE8B0080
	v_add_f32_e32 v0, 1.0, v0                                  // 000000292244: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000292248: BF870091
	v_div_scale_f32 v1, null, v0, v0, 1.0                      // 00000029224C: D6FC7C01 03CA0100
	v_rcp_f32_e32 v3, v1                                       // 000000292254: 7E065501
	v_xor_b32_e32 v1, 0x80000000, v1                           // 000000292258: 3A0202FF 80000000
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_1)   // 000000292260: BF870085
	v_fma_f32 v4, v1, v3, 1.0                                  // 000000292264: D6130004 03CA0701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000029226C: BF8700A1
	v_fmac_f32_e32 v3, v4, v3                                  // 000000292270: 56060704
	v_div_scale_f32 v5, vcc_lo, 1.0, v0, 1.0                   // 000000292274: D6FC6A05 03CA00F2
	v_mul_f32_e32 v4, v5, v3                                   // 00000029227C: 10080705
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000292280: BF870091
	v_fma_f32 v6, v1, v4, v5                                   // 000000292284: D6130006 04160901
	v_fmac_f32_e32 v4, v6, v3                                  // 00000029228C: 56080706
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000292290: BF870091
	v_fmac_f32_e32 v5, v1, v4                                  // 000000292294: 560A0901
	v_div_fmas_f32 v1, v5, v3, v4                              // 000000292298: D6370001 04120705
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002922A0: BF870091
	v_div_fixup_f32 v0, v1, v0, 1.0                            // 0000002922A4: D6270000 03CA0101
	v_bfe_u32 v1, v0, 16, 1                                    // 0000002922AC: D6100001 02052100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002922B4: BF870091
	v_dual_mov_b32 v1, 0 :: v_dual_add_nc_u32 v0, v0, v1       // 0000002922B8: CA200080 01000300
	v_add_nc_u32_e32 v0, 0x7fff, v0                            // 0000002922C0: 4A0000FF 00007FFF
	global_store_d16_hi_b16 v1, v0, s[14:15]                   // 0000002922C8: DC960000 000E0001
	s_and_not1_b32 vcc_lo, exec_lo, s11                        // 0000002922D0: 916A0B7E
	s_mov_b32 s11, 0                                           // 0000002922D4: BE8B0080
	s_cbranch_vccnz 3                                          // 0000002922D8: BFA40003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0xee8>
	s_cmp_lg_u32 s7, 1                                         // 0000002922DC: BF078107
	s_mov_b32 s11, -1                                          // 0000002922E0: BE8B00C1
	s_cselect_b32 s12, -1, 0                                   // 0000002922E4: 980C80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002922E8: BF870009
	s_and_b32 vcc_lo, exec_lo, s12                             // 0000002922EC: 8B6A0C7E
	s_cbranch_vccz 13                                          // 0000002922F0: BFA3000D <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0xf28>
	s_bfe_u32 s7, s10, 0x10010                                 // 0000002922F4: 9307FF0A 00010010
	s_lshl_b64 s[12:13], s[2:3], 1                             // 0000002922FC: 848C8102
	s_add_i32 s7, s10, s7                                      // 000000292300: 8107070A
	s_mov_b32 s11, 0                                           // 000000292304: BE8B0080
	s_addk_i32 s7, 0x7fff                                      // 000000292308: B7877FFF
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000029230C: BF870009
	v_dual_mov_b32 v0, 0 :: v_dual_mov_b32 v1, s7              // 000000292310: CA100080 00000007
	s_add_u32 s12, s4, s12                                     // 000000292318: 800C0C04
	s_addc_u32 s13, s5, s13                                    // 00000029231C: 820D0D05
	global_store_d16_hi_b16 v0, v1, s[12:13]                   // 000000292320: DC960000 000C0100
	s_and_not1_b32 vcc_lo, exec_lo, s11                        // 000000292328: 916A0B7E
	s_cbranch_vccnz 51                                         // 00000029232C: BFA40033 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0xffc>
	s_bfe_u32 s7, s10, 0x10010                                 // 000000292330: 9307FF0A 00010010
	s_lshl_b64 s[2:3], s[2:3], 1                               // 000000292338: 84828102
	s_add_i32 s7, s10, s7                                      // 00000029233C: 8107070A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000292340: BF870499
	s_addk_i32 s7, 0x7fff                                      // 000000292344: B7877FFF
	s_and_b32 s7, s7, 0xffff0000                               // 000000292348: 8B07FF07 FFFF0000
	s_add_u32 s2, s4, s2                                       // 000000292350: 80020204
	s_mul_f32 s6, s6, s7                                       // 000000292354: A2060706
	s_addc_u32 s3, s5, s3                                      // 000000292358: 82030305
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 00000029235C: BF87059A
	s_mul_f32 s7, s6, 0xbfb8aa3b                               // 000000292360: A207FF06 BFB8AA3B
	v_exp_f32_e32 v0, s7                                       // 000000292368: 7E004A07
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029236C: BF870095
	v_add_f32_e32 v0, 1.0, v0                                  // 000000292370: 060000F2
	v_div_scale_f32 v1, null, v0, v0, s6                       // 000000292374: D6FC7C01 001A0100
	s_delay_alu instid0(VALU_DEP_1)                            // 00000029237C: BF870001
	v_rcp_f32_e32 v3, v1                                       // 000000292380: 7E065501
	v_xor_b32_e32 v1, 0x80000000, v1                           // 000000292384: 3A0202FF 80000000
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_1)   // 00000029238C: BF870085
	v_fma_f32 v4, v1, v3, 1.0                                  // 000000292390: D6130004 03CA0701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000292398: BF8700A1
	v_fmac_f32_e32 v3, v4, v3                                  // 00000029239C: 56060704
	v_div_scale_f32 v5, vcc_lo, s6, v0, s6                     // 0000002923A0: D6FC6A05 001A0006
	v_mul_f32_e32 v4, v5, v3                                   // 0000002923A8: 10080705
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002923AC: BF870091
	v_fma_f32 v6, v1, v4, v5                                   // 0000002923B0: D6130006 04160901
	v_fmac_f32_e32 v4, v6, v3                                  // 0000002923B8: 56080706
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002923BC: BF870091
	v_fmac_f32_e32 v5, v1, v4                                  // 0000002923C0: 560A0901
	v_div_fmas_f32 v1, v5, v3, v4                              // 0000002923C4: D6370001 04120705
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002923CC: BF870091
	v_div_fixup_f32 v0, v1, v0, s6                             // 0000002923D0: D6270000 001A0101
	v_bfe_u32 v1, v0, 16, 1                                    // 0000002923D8: D6100001 02052100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002923E0: BF870091
	v_dual_mov_b32 v1, 0 :: v_dual_add_nc_u32 v0, v0, v1       // 0000002923E4: CA200080 01000300
	v_add_nc_u32_e32 v0, 0x7fff, v0                            // 0000002923EC: 4A0000FF 00007FFF
	global_store_d16_hi_b16 v1, v0, s[2:3]                     // 0000002923F4: DC960000 00020001
	s_or_b32 exec_lo, exec_lo, s9                              // 0000002923FC: 8C7E097E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000292400: BF870009
	s_and_b32 vcc_lo, exec_lo, s8                              // 000000292404: 8B6A087E
	s_cbranch_vccz 301                                         // 000000292408: BFA3012D <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x14c0>
	s_and_b32 s0, s1, s0                                       // 00000029240C: 8B000001
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000292410: BF870009
	s_and_saveexec_b32 s1, s0                                  // 000000292414: BE812000
	s_cbranch_execz 297                                        // 000000292418: BFA50129 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x14c0>
	s_clause 0x1                                               // 00000029241C: BF850001
	s_load_b64 s[2:3], s[16:17], 0x38                          // 000000292420: F4040088 F8000038
	s_load_b64 s[0:1], s[16:17], 0x8                           // 000000292428: F4040008 F8000008
	s_mov_b32 s6, -1                                           // 000000292430: BE8600C1
	s_mov_b32 s4, 0                                            // 000000292434: BE840080
	s_mov_b32 s5, 0                                            // 000000292438: BE850080
	s_waitcnt lgkmcnt(0)                                       // 00000029243C: BF89FC07
	s_cmp_lt_i32 s3, 3                                         // 000000292440: BF048303
	s_cbranch_scc1 156                                         // 000000292444: BFA2009C <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x12b8>
	s_cmp_gt_i32 s3, 3                                         // 000000292448: BF028303
	s_cbranch_scc0 101                                         // 00000029244C: BFA10065 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x11e4>
	s_cmp_gt_i32 s3, 4                                         // 000000292450: BF028403
	s_cbranch_scc0 58                                          // 000000292454: BFA1003A <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1140>
	s_cmp_eq_u32 s3, 5                                         // 000000292458: BF068503
	s_mov_b32 s5, -1                                           // 00000029245C: BE8500C1
	s_cbranch_scc0 54                                          // 000000292460: BFA10036 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x113c>
	v_ashrrev_i32_e32 v0, 31, v18                              // 000000292464: 3400249F
	s_load_b64 s[6:7], s[16:17], 0x10                          // 000000292468: F4040188 F8000010
	s_mov_b32 s5, 0                                            // 000000292470: BE850080
	v_mov_b32_e32 v7, s0                                       // 000000292474: 7E0E0200
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000292478: BF870092
	v_lshrrev_b32_e32 v0, 23, v0                               // 00000029247C: 32000097
	.long 0xd7006a00                                           // 000000292480: D7006A00
	v_cndmask_b32_e32 v1, v17, v0, vcc_lo                      // 000000292484: 02020111
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000292488: BF870111
	v_add_co_ci_u32_e64 v3, null, 0, v18, vcc_lo               // 00000029248C: D5207C03 01AA2480
	v_and_b32_e32 v4, 0xfffffe00, v0                           // 000000292494: 360800FF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029249C: BF870091
	.long 0xd7016a00                                           // 0000002924A0: D7016A00
	v_cndmask_b32_e32 v1, v17, v4, vcc_lo                      // 0000002924A4: 02020911
	v_sub_co_ci_u32_e64 v1, null, v18, v3, vcc_lo              // 0000002924A8: D5217C01 01AA0712
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002924B0: BF870092
	.long 0xd7006a05                                           // 0000002924B4: D7006A05
	v_cndmask_b32_e32 v1, 0xffffff00, v0, vcc_lo               // 0000002924B8: 020200FF FFFFFF00
	v_add_co_ci_u32_e64 v6, null, -1, v1, vcc_lo               // 0000002924C0: D5207C06 01AA02C1
	v_cmp_gt_i64_e32 vcc_lo, 0x100, v[0:1]                     // 0000002924C8: 7CA800FF 00000100
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000002924D0: BF870132
	v_dual_mov_b32 v8, s1 :: v_dual_cndmask_b32 v1, v6, v1     // 0000002924D4: CA120001 08000306
	s_waitcnt lgkmcnt(0)                                       // 0000002924DC: BF89FC07
	v_dual_cndmask_b32 v0, v5, v0 :: v_dual_cndmask_b32 v5, s6, v7// 0000002924E0: CA520105 00040E06
	v_cndmask_b32_e32 v7, s7, v8, vcc_lo                       // 0000002924E8: 020E1007
	v_bfe_u32 v6, v2, 16, 1                                    // 0000002924EC: D6100006 02052102
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002924F4: BF870213
	.long 0xd73c0000                                           // 0000002924F8: D73C0000
	v_cndmask_b32_e32 v1, 1, v0, vcc_lo                        // 0000002924FC: 02020081
	.long 0xd7006a04                                           // 000000292500: D7006A04
	v_cndmask_b32_e32 v1, v5, v4, vcc_lo                       // 000000292504: 02020905
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000292508: BF870211
	v_add_co_ci_u32_e64 v3, null, v7, v3, vcc_lo               // 00000029250C: D5207C03 01AA0707
	v_add3_u32 v5, v2, v6, 0x7fff                              // 000000292514: D6550005 03FE0D02 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000292520: BF870093
	.long 0xd7006a00                                           // 000000292524: D7006A00
	v_cndmask_b32_e32 v1, v4, v0, vcc_lo                       // 000000292528: 02020104
	v_add_co_ci_u32_e64 v1, null, v3, v1, vcc_lo               // 00000029252C: D5207C01 01AA0303
	global_store_d16_hi_b16 v[0:1], v5, off                    // 000000292534: DC960000 007C0500
	s_mov_b32 s6, 0                                            // 00000029253C: BE860080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000292540: BF870009
	s_and_b32 vcc_lo, exec_lo, s6                              // 000000292544: 8B6A067E
	s_cbranch_vccz 37                                          // 000000292548: BFA30025 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x11e0>
	v_mul_f32_e32 v0, 0xbfb8aa3b, v2                           // 00000029254C: 100004FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000292554: BF870291
	v_exp_f32_e32 v0, v0                                       // 000000292558: 7E004B00
	v_add_f32_e32 v3, 1.0, v0                                  // 00000029255C: 060600F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000292560: BF870091
	v_div_scale_f32 v0, null, v3, v3, 1.0                      // 000000292564: D6FC7C00 03CA0703
	v_rcp_f32_e32 v4, v0                                       // 00000029256C: 7E085500
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000292570: BF870095
	v_fma_f32 v1, -v0, v4, 1.0                                 // 000000292574: D6130001 23CA0900
	v_fmac_f32_e32 v4, v1, v4                                  // 00000029257C: 56080901
	v_div_scale_f32 v1, vcc_lo, 1.0, v3, 1.0                   // 000000292580: D6FC6A01 03CA06F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000292588: BF870091
	v_mul_f32_e32 v5, v1, v4                                   // 00000029258C: 100A0901
	v_fma_f32 v6, -v0, v5, v1                                  // 000000292590: D6130006 24060B00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000292598: BF870091
	v_fmac_f32_e32 v5, v6, v4                                  // 00000029259C: 560A0906
	v_fma_f32 v6, -v0, v5, v1                                  // 0000002925A0: D6130006 24060B00
	.long 0xd73c0000                                           // 0000002925A8: D73C0000
	v_cndmask_b32_e32 v1, 2, v17, vcc_lo                       // 0000002925AC: 02022282
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002925B0: BF870112
	v_div_fmas_f32 v4, v6, v4, v5                              // 0000002925B4: D6370004 04160906
	.long 0xd7006a00                                           // 0000002925BC: D7006A00
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 0000002925C0: 02020000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002925C4: BF870191
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 0000002925C8: D5207C01 01AA0201
	v_div_fixup_f32 v3, v4, v3, 1.0                            // 0000002925D0: D6270003 03CA0704
	global_store_b32 v[0:1], v3, off                           // 0000002925D8: DC6A0000 007C0300
	s_mov_b32 s6, 0                                            // 0000002925E0: BE860080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002925E4: BF870009
	s_and_b32 vcc_lo, exec_lo, s6                              // 0000002925E8: 8B6A067E
	s_cbranch_vccz 49                                          // 0000002925EC: BFA30031 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x12b4>
	v_bfe_u32 v0, v2, 16, 1                                    // 0000002925F0: D6100000 02052102
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002925F8: BF870091
	v_add3_u32 v0, v2, v0, 0x7fff                              // 0000002925FC: D6550000 03FE0102 00007FFF
	v_and_b32_e32 v0, 0xffff0000, v0                           // 000000292608: 360000FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000292610: BF870091
	v_mul_f32_e32 v0, s2, v0                                   // 000000292614: 10000002
	v_mul_f32_e32 v0, 0xbfb8aa3b, v0                           // 000000292618: 100000FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000292620: BF870291
	v_exp_f32_e32 v0, v0                                       // 000000292624: 7E004B00
	v_add_f32_e32 v3, 1.0, v0                                  // 000000292628: 060600F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029262C: BF870091
	v_div_scale_f32 v0, null, v3, v3, 1.0                      // 000000292630: D6FC7C00 03CA0703
	v_rcp_f32_e32 v1, v0                                       // 000000292638: 7E025500
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029263C: BF870095
	v_fma_f32 v4, -v0, v1, 1.0                                 // 000000292640: D6130004 23CA0300
	v_fmac_f32_e32 v1, v4, v1                                  // 000000292648: 56020304
	v_div_scale_f32 v4, vcc_lo, 1.0, v3, 1.0                   // 00000029264C: D6FC6A04 03CA06F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000292654: BF870091
	v_mul_f32_e32 v5, v4, v1                                   // 000000292658: 100A0304
	v_fma_f32 v6, -v0, v5, v4                                  // 00000029265C: D6130006 24120B00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000292664: BF870091
	v_fmac_f32_e32 v5, v6, v1                                  // 000000292668: 560A0306
	v_fma_f32 v0, -v0, v5, v4                                  // 00000029266C: D6130000 24120B00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000292674: BF870121
	v_div_fmas_f32 v4, v0, v1, v5                              // 000000292678: D6370004 04160300
	.long 0xd73c0000                                           // 000000292680: D73C0000
	v_cndmask_b32_e32 v1, 2, v17, vcc_lo                       // 000000292684: 02022282
	v_div_fixup_f32 v3, v4, v3, 1.0                            // 000000292688: D6270003 03CA0704
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000292690: BF870092
	.long 0xd7006a00                                           // 000000292694: D7006A00
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 000000292698: 02020000
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 00000029269C: D5207C01 01AA0201
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002926A4: BF870003
	v_add_f32_e32 v3, v3, v3                                   // 0000002926A8: 06060703
	global_store_b32 v[0:1], v3, off                           // 0000002926AC: DC6A0000 007C0300
	s_mov_b32 s6, 0                                            // 0000002926B4: BE860080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002926B8: BF870009
	s_and_b32 vcc_lo, exec_lo, s6                              // 0000002926BC: 8B6A067E
	s_cbranch_vccz 62                                          // 0000002926C0: BFA3003E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x13bc>
	s_cmp_gt_i32 s3, 1                                         // 0000002926C4: BF028103
	s_mov_b32 s4, -1                                           // 0000002926C8: BE8400C1
	s_cbranch_scc0 53                                          // 0000002926CC: BFA10035 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x13a4>
	v_bfe_u32 v0, v2, 16, 1                                    // 0000002926D0: D6100000 02052102
	s_mov_b32 s4, 0                                            // 0000002926D8: BE840080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002926DC: BF870091
	v_add3_u32 v0, v2, v0, 0x7fff                              // 0000002926E0: D6550000 03FE0102 00007FFF
	v_and_b32_e32 v0, 0xffff0000, v0                           // 0000002926EC: 360000FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002926F4: BF870091
	v_mul_f32_e32 v0, 0xbfb8aa3b, v0                           // 0000002926F8: 100000FF BFB8AA3B
	v_exp_f32_e32 v0, v0                                       // 000000292700: 7E004B00
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000292704: BF870095
	v_add_f32_e32 v0, 1.0, v0                                  // 000000292708: 060000F2
	v_div_scale_f32 v1, null, v0, v0, 1.0                      // 00000029270C: D6FC7C01 03CA0100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000292714: BF870291
	v_rcp_f32_e32 v3, v1                                       // 000000292718: 7E065501
	v_fma_f32 v4, -v1, v3, 1.0                                 // 00000029271C: D6130004 23CA0701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000292724: BF8700A1
	v_fmac_f32_e32 v3, v4, v3                                  // 000000292728: 56060704
	v_div_scale_f32 v4, vcc_lo, 1.0, v0, 1.0                   // 00000029272C: D6FC6A04 03CA00F2
	v_mul_f32_e32 v5, v4, v3                                   // 000000292734: 100A0704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000292738: BF870091
	v_fma_f32 v6, -v1, v5, v4                                  // 00000029273C: D6130006 24120B01
	v_fmac_f32_e32 v5, v6, v3                                  // 000000292744: 560A0706
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000292748: BF870091
	v_fma_f32 v1, -v1, v5, v4                                  // 00000029274C: D6130001 24120B01
	v_div_fmas_f32 v1, v1, v3, v5                              // 000000292754: D6370001 04160701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000029275C: BF870121
	v_div_fixup_f32 v3, v1, v0, 1.0                            // 000000292760: D6270003 03CA0101
	.long 0xd73c0000                                           // 000000292768: D73C0000
	v_cndmask_b32_e32 v1, 1, v17, vcc_lo                       // 00000029276C: 02022281
	v_bfe_u32 v4, v3, 16, 1                                    // 000000292770: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000292778: BF870092
	.long 0xd7006a00                                           // 00000029277C: D7006A00
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 000000292780: 02020000
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 000000292784: D5207C01 01AA0201
	s_delay_alu instid0(VALU_DEP_3)                            // 00000029278C: BF870003
	v_add3_u32 v3, v3, v4, 0x7fff                              // 000000292790: D6550003 03FE0903 00007FFF
	global_store_d16_hi_b16 v[0:1], v3, off                    // 00000029279C: DC960000 007C0300
	s_and_not1_b32 vcc_lo, exec_lo, s4                         // 0000002927A4: 916A047E
	s_mov_b32 s4, 0                                            // 0000002927A8: BE840080
	s_cbranch_vccnz 3                                          // 0000002927AC: BFA40003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x13bc>
	s_cmp_lg_u32 s3, 1                                         // 0000002927B0: BF078103
	s_mov_b32 s4, -1                                           // 0000002927B4: BE8400C1
	s_cselect_b32 s5, -1, 0                                    // 0000002927B8: 980580C1
	v_bfe_u32 v3, v2, 16, 1                                    // 0000002927BC: D6100003 02052102
	.long 0xd73c0000                                           // 0000002927C4: D73C0000
	v_cndmask_b32_e32 v1, 1, v17, vcc_lo                       // 0000002927C8: 02022281
	s_and_b32 vcc_lo, exec_lo, s5                              // 0000002927CC: 8B6A057E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002927D0: BF870002
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000002927D4: D6550002 03FE0702 00007FFF
	s_cbranch_vccz 8                                           // 0000002927E0: BFA30008 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1404>
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002927E4: BF870092
	.long 0xd7006a03                                           // 0000002927E8: D7006A03
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 0000002927EC: 02020000
	v_add_co_ci_u32_e64 v4, null, s1, v1, vcc_lo               // 0000002927F0: D5207C04 01AA0201
	s_mov_b32 s4, 0                                            // 0000002927F8: BE840080
	global_store_d16_hi_b16 v[3:4], v2, off                    // 0000002927FC: DC960000 007C0203
	s_and_not1_b32 vcc_lo, exec_lo, s4                         // 000000292804: 916A047E
	s_cbranch_vccnz 45                                         // 000000292808: BFA4002D <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi1ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x14c0>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029280C: BF870091
	v_and_b32_e32 v2, 0xffff0000, v2                           // 000000292810: 360404FF FFFF0000
	v_mul_f32_e32 v2, s2, v2                                   // 000000292818: 10040402
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029281C: BF870091
	v_mul_f32_e32 v3, 0xbfb8aa3b, v2                           // 000000292820: 100604FF BFB8AA3B
	v_exp_f32_e32 v3, v3                                       // 000000292828: 7E064B03
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029282C: BF870095
	v_add_f32_e32 v3, 1.0, v3                                  // 000000292830: 060606F2
	v_div_scale_f32 v4, null, v3, v3, v2                       // 000000292834: D6FC7C04 040A0703
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000029283C: BF870291
	v_rcp_f32_e32 v5, v4                                       // 000000292840: 7E0A5504
	v_fma_f32 v6, -v4, v5, 1.0                                 // 000000292844: D6130006 23CA0B04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000029284C: BF8700A1
	v_fmac_f32_e32 v5, v6, v5                                  // 000000292850: 560A0B06
	v_div_scale_f32 v6, vcc_lo, v2, v3, v2                     // 000000292854: D6FC6A06 040A0702
	v_mul_f32_e32 v7, v6, v5                                   // 00000029285C: 100E0B06
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000292860: BF870091
	v_fma_f32 v8, -v4, v7, v6                                  // 000000292864: D6130008 241A0F04
	v_fmac_f32_e32 v7, v8, v5                                  // 00000029286C: 560E0B08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000292870: BF870091
	v_fma_f32 v4, -v4, v7, v6                                  // 000000292874: D6130004 241A0F04
	v_div_fmas_f32 v4, v4, v5, v7                              // 00000029287C: D6370004 041E0B04
	.long 0xd7006a00                                           // 000000292884: D7006A00
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 000000292888: 02020000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000029288C: BF870191
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 000000292890: D5207C01 01AA0201
	v_div_fixup_f32 v2, v4, v3, v2                             // 000000292898: D6270002 040A0704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002928A0: BF870091
	v_bfe_u32 v3, v2, 16, 1                                    // 0000002928A4: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000002928AC: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off                    // 0000002928B8: DC960000 007C0200
	s_endpgm                                                   // 0000002928C0: BFB00000
		...

