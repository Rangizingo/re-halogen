000000000074f800 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 00000074F800: F4100100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 00000074F808: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 00000074F80C: 32040082
	s_lshl_b64 s[2:3], s[2:3], 2                               // 00000074F810: 84828202
	v_and_b32_e32 v1, 15, v0                                   // 00000074F814: 3602008F
	v_lshrrev_b32_e32 v28, 6, v0                               // 00000074F818: 32380086
	v_bfe_u32 v29, v0, 5, 1                                    // 00000074F81C: D610001D 02050B00
	v_and_b32_e32 v2, 60, v2                                   // 00000074F824: 360404BC
	v_and_b32_e32 v30, 31, v0                                  // 00000074F828: 363C009F
	v_lshlrev_b32_e32 v1, 2, v1                                // 00000074F82C: 30020282
	.long 0x7f0a3880                                           // 00000074F830: 7F0A3880
	v_lshlrev_b32_e32 v6, 2, v0                                // 00000074F834: 300C0082
	s_waitcnt lgkmcnt(0)                                       // 00000074F838: BF89FC07
	s_clause 0x1                                               // 00000074F83C: BF850001
	global_load_b32 v3, v1, s[4:5]                             // 00000074F840: DC520000 03040001
	global_load_b32 v4, v2, s[4:5]                             // 00000074F848: DC520000 04040002
	s_add_u32 s0, s4, s16                                      // 00000074F850: 80001004
	s_addc_u32 s1, s5, s17                                     // 00000074F854: 82011105
	s_ashr_i32 s16, s11, 31                                    // 00000074F858: 86109F0B
	v_mov_b32_e32 v2, s3                                       // 00000074F85C: 7E040203
	s_lshr_b32 s16, s16, 27                                    // 00000074F860: 85109B10
	v_or_b32_e32 v1, s2, v28                                   // 00000074F864: 38023802
	s_add_u32 s16, s10, s16                                    // 00000074F868: 8010100A
	s_addc_u32 s17, s11, 0                                     // 00000074F86C: 8211800B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000074F870: BF870099
	s_lshr_b64 s[16:17], s[16:17], 5                           // 00000074F874: 85908510
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 00000074F878: 7CA8020C
	s_add_i32 s17, s16, 1                                      // 00000074F87C: 81118110
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000074F880: BF870499
	s_lshr_b32 s20, s17, 31                                    // 00000074F884: 85149F11
	s_add_i32 s17, s17, s20                                    // 00000074F888: 81111411
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000074F88C: 02020280
	s_ashr_i32 s17, s17, 1                                     // 00000074F890: 86118111
	v_cndmask_b32_e64 v2, 0, s3, vcc_lo                        // 00000074F894: D5010002 01A80680
	.long 0xd72c0007                                           // 00000074F89C: D72C0007
	v_cndmask_b32_e32 v1, s17, v29, vcc_lo                     // 00000074F8A0: 02023A11
	s_cmpk_lt_i32 s16, 0x201                                   // 00000074F8A4: B3900201
	.long 0xd72c0009                                           // 00000074F8A8: D72C0009
	v_cndmask_b32_e32 v1, s19, v1, vcc_lo                      // 00000074F8AC: 02020213
	v_mad_u64_u32 v[24:25], null, s18, v1, s[0:1]              // 00000074F8B0: D6FE7C18 00020212
	s_cselect_b32 s0, -1, 0                                    // 00000074F8B8: 980080C1
	s_cmpk_gt_i32 s16, 0x200                                   // 00000074F8BC: B2900200
	v_add_nc_u32_e32 v11, s17, v7                              // 00000074F8C0: 4A160E11
	v_add_nc_u32_e32 v31, v7, v30                              // 00000074F8C4: 4A3E3D07
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000074F8C8: BF8704A2
	v_min_i32_e32 v32, s16, v11                                // 00000074F8CC: 22401610
	s_cselect_b32 s16, -1, 0                                   // 00000074F8D0: 981080C1
	s_and_b32 vcc_lo, exec_lo, s16                             // 00000074F8D4: 8B6A107E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 00000074F8D8: BF870151
	.long 0xd4410001                                           // 00000074F8DC: D4410001
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 00000074F8E0: 0202411F
	s_waitcnt vmcnt(1)                                         // 00000074F8E4: BF8907F7
	v_bfe_u32 v8, v3, 16, 1                                    // 00000074F8E8: D6100008 02052103
	s_waitcnt vmcnt(0)                                         // 00000074F8F0: BF8903F7
	v_bfe_u32 v10, v4, 16, 1                                   // 00000074F8F4: D610000A 02052104
	v_add3_u32 v3, v3, v8, 0x7fff                              // 00000074F8FC: D6550003 03FE1103 00007FFF
	.long 0xd72c0008                                           // 00000074F908: D72C0008
	v_cndmask_b32_e32 v1, s18, v2, vcc_lo                      // 00000074F90C: 02020412
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000074F910: BF870193
	v_add3_u32 v4, v4, v10, 0x7fff                             // 00000074F914: D6550004 03FE1504 00007FFF
	.long 0x7e0a3983                                           // 00000074F920: 7E0A3983
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000074F924: BF870113
	v_add3_u32 v33, v9, v25, v8                                // 00000074F928: D6550021 04223309
	v_and_or_b32 v3, 0xffff0000, v4, v5                        // 00000074F930: D6570003 041608FF FFFF0000
	ds_store_b32 v6, v3                                        // 00000074F93C: D8340000 00000306
	s_waitcnt lgkmcnt(0)                                       // 00000074F944: BF89FC07
	s_barrier                                                  // 00000074F948: BFBD0000
	buffer_gl0_inv                                             // 00000074F94C: E0AC0000 00000000
	s_cbranch_vccnz 154                                        // 00000074F954: BFA4009A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x3c0>
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v8, 0               // 00000074F958: CA100080 09080080
	s_and_saveexec_b32 s17, s1                                 // 00000074F960: BE912001
	s_cbranch_execz 11                                         // 00000074F964: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x194>
	v_lshlrev_b32_e32 v3, 1, v31                               // 00000074F968: 30063E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000074F96C: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 00000074F970: 3408069F
	.long 0xd7006a03                                           // 00000074F974: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 00000074F978: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 00000074F97C: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 00000074F984: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 00000074F98C: BF8903F7
	v_cvt_f32_f16_e32 v8, v3                                   // 00000074F990: 7E101703
	s_or_b32 exec_lo, exec_lo, s17                             // 00000074F994: 8C7E117E
	v_add_nc_u32_e32 v3, 32, v31                               // 00000074F998: 4A063EA0
	s_mov_b32 s1, exec_lo                                      // 00000074F99C: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000074F9A0: BF870001
	.long 0xd4c1007e                                           // 00000074F9A4: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 00000074F9A8: 02024103
	s_cbranch_execz 11                                         // 00000074F9AC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x1dc>
	v_lshlrev_b32_e32 v3, 1, v3                                // 00000074F9B0: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000074F9B4: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 00000074F9B8: 3408069F
	.long 0xd7006a03                                           // 00000074F9BC: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 00000074F9C0: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 00000074F9C4: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 00000074F9CC: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 00000074F9D4: BF8903F7
	v_cvt_f32_f16_e32 v9, v3                                   // 00000074F9D8: 7E121703
	s_or_b32 exec_lo, exec_lo, s1                              // 00000074F9DC: 8C7E017E
	v_dual_mov_b32 v10, 0 :: v_dual_add_nc_u32 v3, 64, v31     // 00000074F9E0: CA200080 0A023EC0
	v_mov_b32_e32 v11, 0                                       // 00000074F9E8: 7E160280
	s_mov_b32 s1, exec_lo                                      // 00000074F9EC: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000074F9F0: BF870002
	.long 0xd4c1007e                                           // 00000074F9F4: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 00000074F9F8: 02024103
	s_cbranch_execz 11                                         // 00000074F9FC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x22c>
	v_lshlrev_b32_e32 v3, 1, v3                                // 00000074FA00: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000074FA04: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 00000074FA08: 3408069F
	.long 0xd7006a03                                           // 00000074FA0C: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 00000074FA10: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 00000074FA14: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 00000074FA1C: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 00000074FA24: BF8903F7
	v_cvt_f32_f16_e32 v10, v3                                  // 00000074FA28: 7E141703
	s_or_b32 exec_lo, exec_lo, s1                              // 00000074FA2C: 8C7E017E
	v_add_nc_u32_e32 v3, 0x60, v31                             // 00000074FA30: 4A063EFF 00000060
	s_mov_b32 s1, exec_lo                                      // 00000074FA38: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000074FA3C: BF870001
	.long 0xd4c1007e                                           // 00000074FA40: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 00000074FA44: 02024103
	s_cbranch_execz 11                                         // 00000074FA48: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x278>
	v_lshlrev_b32_e32 v3, 1, v3                                // 00000074FA4C: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000074FA50: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 00000074FA54: 3408069F
	.long 0xd7006a03                                           // 00000074FA58: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 00000074FA5C: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 00000074FA60: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 00000074FA68: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 00000074FA70: BF8903F7
	v_cvt_f32_f16_e32 v11, v3                                  // 00000074FA74: 7E161703
	s_or_b32 exec_lo, exec_lo, s1                              // 00000074FA78: 8C7E017E
	v_dual_mov_b32 v12, 0 :: v_dual_add_nc_u32 v3, 0x80, v31   // 00000074FA7C: CA200080 0C023EFF 00000080
	v_mov_b32_e32 v13, 0                                       // 00000074FA88: 7E1A0280
	s_mov_b32 s1, exec_lo                                      // 00000074FA8C: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000074FA90: BF870002
	.long 0xd4c1007e                                           // 00000074FA94: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 00000074FA98: 02024103
	s_cbranch_execz 11                                         // 00000074FA9C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x2cc>
	v_lshlrev_b32_e32 v3, 1, v3                                // 00000074FAA0: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000074FAA4: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 00000074FAA8: 3408069F
	.long 0xd7006a03                                           // 00000074FAAC: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 00000074FAB0: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 00000074FAB4: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 00000074FABC: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 00000074FAC4: BF8903F7
	v_cvt_f32_f16_e32 v12, v3                                  // 00000074FAC8: 7E181703
	s_or_b32 exec_lo, exec_lo, s1                              // 00000074FACC: 8C7E017E
	v_add_nc_u32_e32 v3, 0xa0, v31                             // 00000074FAD0: 4A063EFF 000000A0
	s_mov_b32 s1, exec_lo                                      // 00000074FAD8: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000074FADC: BF870001
	.long 0xd4c1007e                                           // 00000074FAE0: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 00000074FAE4: 02024103
	s_cbranch_execz 11                                         // 00000074FAE8: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x318>
	v_lshlrev_b32_e32 v3, 1, v3                                // 00000074FAEC: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000074FAF0: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 00000074FAF4: 3408069F
	.long 0xd7006a03                                           // 00000074FAF8: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 00000074FAFC: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 00000074FB00: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 00000074FB08: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 00000074FB10: BF8903F7
	v_cvt_f32_f16_e32 v13, v3                                  // 00000074FB14: 7E1A1703
	s_or_b32 exec_lo, exec_lo, s1                              // 00000074FB18: 8C7E017E
	v_dual_mov_b32 v14, 0 :: v_dual_add_nc_u32 v3, 0xc0, v31   // 00000074FB1C: CA200080 0E023EFF 000000C0
	v_mov_b32_e32 v15, 0                                       // 00000074FB28: 7E1E0280
	s_mov_b32 s1, exec_lo                                      // 00000074FB2C: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000074FB30: BF870002
	.long 0xd4c1007e                                           // 00000074FB34: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 00000074FB38: 02024103
	s_cbranch_execz 11                                         // 00000074FB3C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x36c>
	v_lshlrev_b32_e32 v3, 1, v3                                // 00000074FB40: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000074FB44: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 00000074FB48: 3408069F
	.long 0xd7006a03                                           // 00000074FB4C: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 00000074FB50: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 00000074FB54: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 00000074FB5C: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 00000074FB64: BF8903F7
	v_cvt_f32_f16_e32 v14, v3                                  // 00000074FB68: 7E1C1703
	s_or_b32 exec_lo, exec_lo, s1                              // 00000074FB6C: 8C7E017E
	v_add_nc_u32_e32 v3, 0xe0, v31                             // 00000074FB70: 4A063EFF 000000E0
	s_mov_b32 s1, exec_lo                                      // 00000074FB78: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000074FB7C: BF870001
	.long 0xd4c1007e                                           // 00000074FB80: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 00000074FB84: 02024103
	s_cbranch_execz 11                                         // 00000074FB88: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x3b8>
	v_lshlrev_b32_e32 v3, 1, v3                                // 00000074FB8C: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000074FB90: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 00000074FB94: 3408069F
	.long 0xd7006a03                                           // 00000074FB98: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 00000074FB9C: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 00000074FBA0: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 00000074FBA8: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 00000074FBB0: BF8903F7
	v_cvt_f32_f16_e32 v15, v3                                  // 00000074FBB4: 7E1E1703
	s_or_b32 exec_lo, exec_lo, s1                              // 00000074FBB8: 8C7E017E
	s_branch 9                                                 // 00000074FBBC: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x3e4>
	v_mov_b32_e32 v8, 0                                        // 00000074FBC0: 7E100280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000074FBC4: BF870001
	v_mov_b32_e32 v9, v8                                       // 00000074FBC8: 7E120308
	v_mov_b32_e32 v10, v8                                      // 00000074FBCC: 7E140308
	v_mov_b32_e32 v11, v8                                      // 00000074FBD0: 7E160308
	v_mov_b32_e32 v12, v8                                      // 00000074FBD4: 7E180308
	v_mov_b32_e32 v13, v8                                      // 00000074FBD8: 7E1A0308
	v_mov_b32_e32 v14, v8                                      // 00000074FBDC: 7E1C0308
	v_mov_b32_e32 v15, v8                                      // 00000074FBE0: 7E1E0308
	s_add_u32 s4, s4, s14                                      // 00000074FBE4: 80040E04
	s_addc_u32 s5, s5, s15                                     // 00000074FBE8: 82050F05
	s_lshr_b32 s1, s11, 31                                     // 00000074FBEC: 85019F0B
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v27, 0             // 00000074FBF0: CA100080 141A0080
	s_add_u32 s14, s10, s1                                     // 00000074FBF8: 800E010A
	s_addc_u32 s15, s11, 0                                     // 00000074FBFC: 820F800B
	.long 0xd4410001                                           // 00000074FC00: D4410001
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 00000074FC04: 0202411F
	s_ashr_i64 s[14:15], s[14:15], 1                           // 00000074FC08: 868E810E
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v21, 0             // 00000074FC0C: CA100080 22140080
	v_mad_u64_u32 v[25:26], null, v1, s14, s[4:5]              // 00000074FC14: D6FE7C19 00101D01
	.long 0xd72c0001                                           // 00000074FC1C: D72C0001
	v_cndmask_b32_e32 v0, v1, v15, vcc_lo                      // 00000074FC20: 02001F01
	.long 0xd72c0002                                           // 00000074FC24: D72C0002
	v_cndmask_b32_e32 v0, v2, v14, vcc_lo                      // 00000074FC28: 02001D02
	v_cndmask_b32_e64 v35, 0, 1, s16                           // 00000074FC2C: D5010023 00410280
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v23, 0             // 00000074FC34: CA100080 16160080
	s_delay_alu instid0(VALU_DEP_3)                            // 00000074FC3C: BF870003
	v_add3_u32 v36, v2, v26, v1                                // 00000074FC40: D6550024 04063502
	s_and_saveexec_b32 s4, s1                                  // 00000074FC48: BE842001
	s_cbranch_execz 22                                         // 00000074FC4C: BFA50016 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x4a8>
	v_lshlrev_b32_e32 v1, 4, v31                               // 00000074FC50: 30023E84
	v_mov_b32_e32 v27, 0                                       // 00000074FC54: 7E360280
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000074FC58: BF8700A2
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000074FC5C: 3404029F
	.long 0xd7006a01                                           // 00000074FC60: D7006A01
	v_cndmask_b32_e32 v1, v25, v1, vcc_lo                      // 00000074FC64: 02020319
	v_add_co_ci_u32_e64 v2, null, v36, v2, vcc_lo              // 00000074FC68: D5207C02 01AA0524
	s_and_not1_b32 vcc_lo, exec_lo, s16                        // 00000074FC70: 916A107E
	global_load_b128 v[20:23], v[1:2], off                     // 00000074FC74: DC5E0000 147C0001
	s_cbranch_vccnz 10                                         // 00000074FC7C: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x4a8>
	v_lshlrev_b32_e32 v1, 1, v31                               // 00000074FC80: 30023E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000074FC84: BF870091
	.long 0xd7006a01                                           // 00000074FC88: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 00000074FC8C: 02020318
	v_add_co_ci_u32_e64 v2, null, 0, v33, vcc_lo               // 00000074FC90: D5207C02 01AA4280
	global_load_d16_b16 v1, v[1:2], off                        // 00000074FC98: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 00000074FCA0: BF8903F7
	v_cvt_f32_f16_e32 v27, v1                                  // 00000074FCA4: 7E361701
	s_or_b32 exec_lo, exec_lo, s4                              // 00000074FCA8: 8C7E047E
	v_dual_mov_b32 v38, 0 :: v_dual_mov_b32 v39, 0             // 00000074FCAC: CA100080 26260080
	v_dual_mov_b32 v40, 0 :: v_dual_mov_b32 v37, 0             // 00000074FCB4: CA100080 28240080
	s_and_saveexec_b32 s14, s1                                 // 00000074FCBC: BE8E2001
	s_cbranch_execz 490                                        // 00000074FCC0: BFA501EA <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xc6c>
	v_dual_mov_b32 v40, 0 :: v_dual_add_nc_u32 v1, 32, v31     // 00000074FCC4: CA200080 28003EA0
	v_dual_mov_b32 v37, 0 :: v_dual_lshlrev_b32 v26, 5, v31    // 00000074FCCC: CA220080 251A3E85
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v43, v27           // 00000074FCD4: CA100080 222A011B
	s_delay_alu instid0(VALU_DEP_3)                            // 00000074FCDC: BF870003
	v_dual_mov_b32 v38, 0 :: v_dual_lshlrev_b32 v41, 4, v1     // 00000074FCE0: CA220080 26280284
	v_dual_mov_b32 v39, 0 :: v_dual_lshlrev_b32 v42, 1, v1     // 00000074FCE8: CA220080 272A0281
	s_mul_i32 s1, s11, 6                                       // 00000074FCF0: 9601860B
	s_mul_hi_u32 s15, s10, 6                                   // 00000074FCF4: 968F860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 00000074FCF8: 8484820A
	s_add_i32 s15, s15, s1                                     // 00000074FCFC: 810F010F
	s_mul_i32 s17, s10, 6                                      // 00000074FD00: 9611860A
	s_mov_b32 s16, 0                                           // 00000074FD04: BE900080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 00000074FD08: 848A810A
	s_branch 435                                               // 00000074FD0C: BFA001B3 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xbdc>
	s_or_b32 exec_lo, exec_lo, s18                             // 00000074FD10: 8C7E127E
	v_cndmask_b32_e64 v54, v27, v8, s0                         // 00000074FD14: D5010036 0002111B
	v_cndmask_b32_e64 v2, v9, v10, s0                          // 00000074FD1C: D5010002 00021509
	v_cndmask_b32_e64 v1, v8, v9, s0                           // 00000074FD24: D5010001 00021308
	v_dual_mov_b32 v8, v15 :: v_dual_and_b32 v9, 0xff, v20     // 00000074FD2C: CA24010F 080828FF 000000FF
	v_cndmask_b32_e64 v7, v14, v15, s0                         // 00000074FD38: D5010007 00021F0E
	v_cndmask_b32_e64 v6, v13, v14, s0                         // 00000074FD40: D5010006 00021D0D
	v_cndmask_b32_e64 v5, v12, v13, s0                         // 00000074FD48: D5010005 00021B0C
	v_cndmask_b32_e64 v4, v11, v12, s0                         // 00000074FD50: D5010004 0002190B
	v_lshlrev_b32_e32 v9, 2, v9                                // 00000074FD58: 30121282
	v_cndmask_b32_e64 v3, v10, v11, s0                         // 00000074FD5C: D5010003 0002170A
	v_ashrrev_i32_e32 v27, 31, v26                             // 00000074FD64: 3436349F
	v_add_nc_u32_e32 v41, 0x200, v41                           // 00000074FD68: 4A5252FF 00000200
	s_and_b32 s1, exec_lo, s1                                  // 00000074FD70: 8B01017E
	ds_load_b32 v15, v9                                        // 00000074FD74: D8D80000 0F000009
	v_lshrrev_b32_e32 v9, 6, v20                               // 00000074FD7C: 32122886
	s_or_b32 s16, s1, s16                                      // 00000074FD80: 8C101001
	v_add_nc_u32_e32 v42, 64, v42                              // 00000074FD84: 4A5454C0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000074FD88: BF8700B2
	v_and_b32_e32 v9, 0x3fc, v9                                // 00000074FD8C: 361212FF 000003FC
	ds_load_b32 v55, v9                                        // 00000074FD94: D8D80000 37000009
	v_lshrrev_b32_e32 v9, 14, v20                              // 00000074FD9C: 3212288E
	v_and_b32_e32 v9, 0x3fc, v9                                // 00000074FDA0: 361212FF 000003FC
	ds_load_b32 v56, v9                                        // 00000074FDA8: D8D80000 38000009
	v_lshrrev_b32_e32 v9, 22, v20                              // 00000074FDB0: 32122896
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000074FDB4: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 00000074FDB8: 361212FF 000003FC
	ds_load_b32 v57, v9                                        // 00000074FDC0: D8D80000 39000009
	v_and_b32_e32 v9, 0xff, v21                                // 00000074FDC8: 36122AFF 000000FF
	v_lshlrev_b32_e32 v9, 2, v9                                // 00000074FDD0: 30121282
	ds_load_b32 v58, v9                                        // 00000074FDD4: D8D80000 3A000009
	v_lshrrev_b32_e32 v9, 6, v21                               // 00000074FDDC: 32122A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000074FDE0: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 00000074FDE4: 361212FF 000003FC
	ds_load_b32 v59, v9                                        // 00000074FDEC: D8D80000 3B000009
	v_lshrrev_b32_e32 v9, 14, v21                              // 00000074FDF4: 32122A8E
	v_and_b32_e32 v9, 0x3fc, v9                                // 00000074FDF8: 361212FF 000003FC
	ds_load_b32 v60, v9                                        // 00000074FE00: D8D80000 3C000009
	v_lshrrev_b32_e32 v9, 22, v21                              // 00000074FE08: 32122A96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000074FE0C: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 00000074FE10: 361212FF 000003FC
	ds_load_b32 v61, v9                                        // 00000074FE18: D8D80000 3D000009
	v_and_b32_e32 v9, 0xff, v22                                // 00000074FE20: 36122CFF 000000FF
	v_lshlrev_b32_e32 v9, 2, v9                                // 00000074FE28: 30121282
	ds_load_b32 v62, v9                                        // 00000074FE2C: D8D80000 3E000009
	v_lshrrev_b32_e32 v9, 6, v22                               // 00000074FE34: 32122C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000074FE38: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 00000074FE3C: 361212FF 000003FC
	ds_load_b32 v63, v9                                        // 00000074FE44: D8D80000 3F000009
	v_lshrrev_b32_e32 v9, 14, v22                              // 00000074FE4C: 32122C8E
	v_and_b32_e32 v9, 0x3fc, v9                                // 00000074FE50: 361212FF 000003FC
	ds_load_b32 v64, v9                                        // 00000074FE58: D8D80000 40000009
	v_lshrrev_b32_e32 v9, 22, v22                              // 00000074FE60: 32122C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000074FE64: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 00000074FE68: 361212FF 000003FC
	ds_load_b32 v65, v9                                        // 00000074FE70: D8D80000 41000009
	v_and_b32_e32 v9, 0xff, v23                                // 00000074FE78: 36122EFF 000000FF
	v_lshlrev_b32_e32 v9, 2, v9                                // 00000074FE80: 30121282
	ds_load_b32 v66, v9                                        // 00000074FE84: D8D80000 42000009
	v_lshrrev_b32_e32 v9, 6, v23                               // 00000074FE8C: 32122E86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000074FE90: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 00000074FE94: 361212FF 000003FC
	ds_load_b32 v67, v9                                        // 00000074FE9C: D8D80000 43000009
	v_lshrrev_b32_e32 v9, 14, v23                              // 00000074FEA4: 32122E8E
	v_and_b32_e32 v9, 0x3fc, v9                                // 00000074FEA8: 361212FF 000003FC
	ds_load_b32 v68, v9                                        // 00000074FEB0: D8D80000 44000009
	v_lshrrev_b32_e32 v9, 22, v23                              // 00000074FEB8: 32122E96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000074FEBC: BF870141
	v_and_b32_e32 v9, 0x3fc, v9                                // 00000074FEC0: 361212FF 000003FC
	ds_load_b32 v69, v9                                        // 00000074FEC8: D8D80000 45000009
	.long 0xd73c0009                                           // 00000074FED0: D73C0009
	v_cndmask_b32_e32 v1, 1, v26, vcc_lo                       // 00000074FED4: 02023481
	v_dual_mov_b32 v27, v43 :: v_dual_add_nc_u32 v26, 0x400, v26// 00000074FED8: CA20012B 1B1A34FF 00000400
	.long 0xd7006a0d                                           // 00000074FEE4: D7006A0D
	v_cndmask_b32_e32 v1, s6, v9, vcc_lo                       // 00000074FEE8: 02021206
	s_delay_alu instid0(VALU_DEP_1)                            // 00000074FEEC: BF870001
	v_add_co_ci_u32_e64 v14, null, s7, v10, vcc_lo             // 00000074FEF0: D5207C0E 01AA1407
	s_clause 0x3                                               // 00000074FEF8: BF850003
	global_load_b128 v[9:12], v[13:14], off                    // 00000074FEFC: DC5E0000 097C000D
	global_load_b128 v[20:23], v[13:14], off offset:16         // 00000074FF04: DC5E0010 147C000D
	global_load_b128 v[44:47], v[13:14], off offset:32         // 00000074FF0C: DC5E0020 2C7C000D
	global_load_b128 v[48:51], v[13:14], off offset:48         // 00000074FF14: DC5E0030 307C000D
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 00000074FF1C: BF890CF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 00000074FF20: CC1A4009 1A021F09
	s_waitcnt lgkmcnt(14)                                      // 00000074FF28: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000074FF2C: BF8700A1
	v_dot2_f32_bf16 v9, v10, v55, v9                           // 00000074FF30: CC1A4009 1C266F0A
	s_waitcnt lgkmcnt(13)                                      // 00000074FF38: BF89FCD7
	v_dot2_f32_bf16 v9, v11, v56, v9                           // 00000074FF3C: CC1A4009 1C26710B
	s_waitcnt lgkmcnt(12)                                      // 00000074FF44: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000074FF48: BF8700A1
	v_dot2_f32_bf16 v9, v12, v57, v9                           // 00000074FF4C: CC1A4009 1C26730C
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 00000074FF54: BF8908B7
	v_dot2_f32_bf16 v9, v20, v58, v9                           // 00000074FF58: CC1A4009 1C267514
	s_waitcnt lgkmcnt(10)                                      // 00000074FF60: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000074FF64: BF8700A1
	v_dot2_f32_bf16 v9, v21, v59, v9                           // 00000074FF68: CC1A4009 1C267715
	s_waitcnt lgkmcnt(9)                                       // 00000074FF70: BF89FC97
	v_dot2_f32_bf16 v9, v22, v60, v9                           // 00000074FF74: CC1A4009 1C267916
	s_waitcnt lgkmcnt(8)                                       // 00000074FF7C: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000074FF80: BF8700A1
	v_dot2_f32_bf16 v9, v23, v61, v9                           // 00000074FF84: CC1A4009 1C267B17
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 00000074FF8C: BF890477
	v_dot2_f32_bf16 v9, v44, v62, v9                           // 00000074FF90: CC1A4009 1C267D2C
	s_waitcnt lgkmcnt(6)                                       // 00000074FF98: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000074FF9C: BF8700A1
	v_dot2_f32_bf16 v9, v45, v63, v9                           // 00000074FFA0: CC1A4009 1C267F2D
	s_waitcnt lgkmcnt(5)                                       // 00000074FFA8: BF89FC57
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 00000074FFAC: CC1A4009 1C26812E
	s_waitcnt lgkmcnt(4)                                       // 00000074FFB4: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000074FFB8: BF8700A1
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 00000074FFBC: CC1A4009 1C26832F
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 00000074FFC4: BF890037
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 00000074FFC8: CC1A4009 1C268530
	.long 0xd7006a30                                           // 00000074FFD0: D7006A30
	v_cndmask_b32_e32 v0, v13, v10, vcc_lo                     // 00000074FFD4: 0200150D
	s_waitcnt lgkmcnt(2)                                       // 00000074FFD8: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000074FFDC: BF8701C2
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 00000074FFE0: CC1A4009 1C268731
	v_add_co_ci_u32_e64 v49, null, s11, v14, vcc_lo            // 00000074FFE8: D5207C31 01AA1C0B
	.long 0xd7006a34                                           // 00000074FFF0: D7006A34
	v_cndmask_b32_e32 v0, v13, v4, vcc_lo                      // 00000074FFF4: 0200090D
	s_waitcnt lgkmcnt(1)                                       // 00000074FFF8: BF89FC17
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 00000074FFFC: CC1A4009 1C268932
	v_add_co_ci_u32_e64 v53, null, s5, v14, vcc_lo             // 000000750004: D5207C35 01AA1C05
	.long 0xd7006a0d                                           // 00000075000C: D7006A0D
	v_cndmask_b32_e32 v0, v13, v17, vcc_lo                     // 000000750010: 0200230D
	s_waitcnt lgkmcnt(0)                                       // 000000750014: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000750018: BF870123
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 00000075001C: CC1A4009 1C268B33
	v_add_co_ci_u32_e64 v14, null, s15, v14, vcc_lo            // 000000750024: D5207C0E 01AA1C0F
	v_fmac_f32_e32 v37, v54, v9                                // 00000075002C: 564A1336
	s_clause 0x3                                               // 000000750030: BF850003
	global_load_b128 v[9:12], v[48:49], off                    // 000000750034: DC5E0000 097C0030
	global_load_b128 v[20:23], v[48:49], off offset:16         // 00000075003C: DC5E0010 147C0030
	global_load_b128 v[44:47], v[48:49], off offset:32         // 000000750044: DC5E0020 2C7C0030
	global_load_b128 v[48:51], v[48:49], off offset:48         // 00000075004C: DC5E0030 307C0030
	s_waitcnt vmcnt(3)                                         // 000000750054: BF890FF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 000000750058: CC1A4009 1A021F09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000750060: BF870091
	v_dot2_f32_bf16 v9, v10, v55, v9                           // 000000750064: CC1A4009 1C266F0A
	v_dot2_f32_bf16 v9, v11, v56, v9                           // 00000075006C: CC1A4009 1C26710B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000750074: BF8700A1
	v_dot2_f32_bf16 v9, v12, v57, v9                           // 000000750078: CC1A4009 1C26730C
	s_waitcnt vmcnt(2)                                         // 000000750080: BF890BF7
	v_dot2_f32_bf16 v9, v20, v58, v9                           // 000000750084: CC1A4009 1C267514
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075008C: BF870091
	v_dot2_f32_bf16 v9, v21, v59, v9                           // 000000750090: CC1A4009 1C267715
	v_dot2_f32_bf16 v9, v22, v60, v9                           // 000000750098: CC1A4009 1C267916
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007500A0: BF8700A1
	v_dot2_f32_bf16 v9, v23, v61, v9                           // 0000007500A4: CC1A4009 1C267B17
	s_waitcnt vmcnt(1)                                         // 0000007500AC: BF8907F7
	v_dot2_f32_bf16 v9, v44, v62, v9                           // 0000007500B0: CC1A4009 1C267D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007500B8: BF870091
	v_dot2_f32_bf16 v9, v45, v63, v9                           // 0000007500BC: CC1A4009 1C267F2D
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 0000007500C4: CC1A4009 1C26812E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007500CC: BF8700A1
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 0000007500D0: CC1A4009 1C26832F
	s_waitcnt vmcnt(0)                                         // 0000007500D8: BF8903F7
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 0000007500DC: CC1A4009 1C268530
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007500E4: BF870091
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 0000007500E8: CC1A4009 1C268731
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 0000007500F0: CC1A4009 1C268932
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007500F8: BF870091
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 0000007500FC: CC1A4009 1C268B33
	v_fmac_f32_e32 v40, v54, v9                                // 000000750104: 56501336
	s_clause 0x3                                               // 000000750108: BF850003
	global_load_b128 v[9:12], v[52:53], off                    // 00000075010C: DC5E0000 097C0034
	global_load_b128 v[20:23], v[52:53], off offset:16         // 000000750114: DC5E0010 147C0034
	global_load_b128 v[44:47], v[52:53], off offset:32         // 00000075011C: DC5E0020 2C7C0034
	global_load_b128 v[48:51], v[52:53], off offset:48         // 000000750124: DC5E0030 307C0034
	s_waitcnt vmcnt(3)                                         // 00000075012C: BF890FF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 000000750130: CC1A4009 1A021F09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000750138: BF870091
	v_dot2_f32_bf16 v9, v10, v55, v9                           // 00000075013C: CC1A4009 1C266F0A
	v_dot2_f32_bf16 v9, v11, v56, v9                           // 000000750144: CC1A4009 1C26710B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000075014C: BF8700A1
	v_dot2_f32_bf16 v9, v12, v57, v9                           // 000000750150: CC1A4009 1C26730C
	s_waitcnt vmcnt(2)                                         // 000000750158: BF890BF7
	v_dot2_f32_bf16 v9, v20, v58, v9                           // 00000075015C: CC1A4009 1C267514
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000750164: BF870091
	v_dot2_f32_bf16 v9, v21, v59, v9                           // 000000750168: CC1A4009 1C267715
	v_dot2_f32_bf16 v9, v22, v60, v9                           // 000000750170: CC1A4009 1C267916
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000750178: BF8700A1
	v_dot2_f32_bf16 v9, v23, v61, v9                           // 00000075017C: CC1A4009 1C267B17
	s_waitcnt vmcnt(1)                                         // 000000750184: BF8907F7
	v_dot2_f32_bf16 v9, v44, v62, v9                           // 000000750188: CC1A4009 1C267D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000750190: BF870091
	v_dot2_f32_bf16 v9, v45, v63, v9                           // 000000750194: CC1A4009 1C267F2D
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 00000075019C: CC1A4009 1C26812E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007501A4: BF8700A1
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 0000007501A8: CC1A4009 1C26832F
	s_waitcnt vmcnt(0)                                         // 0000007501B0: BF8903F7
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 0000007501B4: CC1A4009 1C268530
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007501BC: BF870091
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 0000007501C0: CC1A4009 1C268731
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 0000007501C8: CC1A4009 1C268932
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007501D0: BF870091
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 0000007501D4: CC1A4009 1C268B33
	v_fmac_f32_e32 v39, v54, v9                                // 0000007501DC: 564E1336
	s_clause 0x3                                               // 0000007501E0: BF850003
	global_load_b128 v[9:12], v[13:14], off                    // 0000007501E4: DC5E0000 097C000D
	global_load_b128 v[20:23], v[13:14], off offset:16         // 0000007501EC: DC5E0010 147C000D
	global_load_b128 v[44:47], v[13:14], off offset:32         // 0000007501F4: DC5E0020 2C7C000D
	global_load_b128 v[48:51], v[13:14], off offset:48         // 0000007501FC: DC5E0030 307C000D
	.long 0xd7006a0d                                           // 000000750204: D7006A0D
	v_cndmask_b32_e32 v0, v52, v4, vcc_lo                      // 000000750208: 02000934
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000075020C: BF8700B1
	v_add_co_ci_u32_e64 v14, null, s5, v53, vcc_lo             // 000000750210: D5207C0E 01AA6A05
	s_waitcnt vmcnt(3)                                         // 000000750218: BF890FF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 00000075021C: CC1A4009 1A021F09
	v_dot2_f32_bf16 v9, v10, v55, v9                           // 000000750224: CC1A4009 1C266F0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075022C: BF870091
	v_dot2_f32_bf16 v9, v11, v56, v9                           // 000000750230: CC1A4009 1C26710B
	v_dot2_f32_bf16 v9, v12, v57, v9                           // 000000750238: CC1A4009 1C26730C
	s_waitcnt vmcnt(2)                                         // 000000750240: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000750244: BF870091
	v_dot2_f32_bf16 v9, v20, v58, v9                           // 000000750248: CC1A4009 1C267514
	v_dot2_f32_bf16 v9, v21, v59, v9                           // 000000750250: CC1A4009 1C267715
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000750258: BF870091
	v_dot2_f32_bf16 v9, v22, v60, v9                           // 00000075025C: CC1A4009 1C267916
	v_dot2_f32_bf16 v9, v23, v61, v9                           // 000000750264: CC1A4009 1C267B17
	s_waitcnt vmcnt(1)                                         // 00000075026C: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000750270: BF870091
	v_dot2_f32_bf16 v9, v44, v62, v9                           // 000000750274: CC1A4009 1C267D2C
	v_dot2_f32_bf16 v9, v45, v63, v9                           // 00000075027C: CC1A4009 1C267F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000750284: BF870091
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 000000750288: CC1A4009 1C26812E
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 000000750290: CC1A4009 1C26832F
	s_waitcnt vmcnt(0)                                         // 000000750298: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075029C: BF870091
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 0000007502A0: CC1A4009 1C268530
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 0000007502A8: CC1A4009 1C268731
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007502B0: BF870091
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 0000007502B4: CC1A4009 1C268932
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 0000007502BC: CC1A4009 1C268B33
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007502C4: BF870001
	v_fmac_f32_e32 v38, v54, v9                                // 0000007502C8: 564C1336
	s_clause 0x3                                               // 0000007502CC: BF850003
	global_load_b128 v[9:12], v[13:14], off                    // 0000007502D0: DC5E0000 097C000D
	global_load_b128 v[20:23], v[13:14], off offset:16         // 0000007502D8: DC5E0010 147C000D
	global_load_b128 v[44:47], v[13:14], off offset:32         // 0000007502E0: DC5E0020 2C7C000D
	global_load_b128 v[48:51], v[13:14], off offset:48         // 0000007502E8: DC5E0030 307C000D
	s_waitcnt vmcnt(3)                                         // 0000007502F0: BF890FF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 0000007502F4: CC1A4009 1A021F09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007502FC: BF870091
	v_dot2_f32_bf16 v9, v10, v55, v9                           // 000000750300: CC1A4009 1C266F0A
	v_dot2_f32_bf16 v9, v11, v56, v9                           // 000000750308: CC1A4009 1C26710B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000750310: BF8700A1
	v_dot2_f32_bf16 v9, v12, v57, v9                           // 000000750314: CC1A4009 1C26730C
	s_waitcnt vmcnt(2)                                         // 00000075031C: BF890BF7
	v_dot2_f32_bf16 v9, v20, v58, v9                           // 000000750320: CC1A4009 1C267514
	v_mov_b32_e32 v20, v16                                     // 000000750328: 7E280310
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000075032C: BF870122
	v_dot2_f32_bf16 v9, v21, v59, v9                           // 000000750330: CC1A4009 1C267715
	v_mov_b32_e32 v21, v17                                     // 000000750338: 7E2A0311
	v_dot2_f32_bf16 v9, v22, v60, v9                           // 00000075033C: CC1A4009 1C267916
	v_mov_b32_e32 v22, v18                                     // 000000750344: 7E2C0312
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000750348: BF870132
	v_dot2_f32_bf16 v9, v23, v61, v9                           // 00000075034C: CC1A4009 1C267B17
	v_mov_b32_e32 v23, v19                                     // 000000750354: 7E2E0313
	s_waitcnt vmcnt(1)                                         // 000000750358: BF8907F7
	v_dot2_f32_bf16 v9, v44, v62, v9                           // 00000075035C: CC1A4009 1C267D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000750364: BF870091
	v_dot2_f32_bf16 v9, v45, v63, v9                           // 000000750368: CC1A4009 1C267F2D
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 000000750370: CC1A4009 1C26812E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000750378: BF8700A1
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 00000075037C: CC1A4009 1C26832F
	s_waitcnt vmcnt(0)                                         // 000000750384: BF8903F7
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 000000750388: CC1A4009 1C268530
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000750390: BF870091
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 000000750394: CC1A4009 1C268731
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 00000075039C: CC1A4009 1C268932
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007503A4: BF870091
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 0000007503A8: CC1A4009 1C268B33
	v_dual_fmac_f32 v34, v54, v9 :: v_dual_mov_b32 v15, v8     // 0000007503B0: C8101336 220E0108
	v_dual_mov_b32 v14, v7 :: v_dual_mov_b32 v13, v6           // 0000007503B8: CA100107 0E0C0106
	v_dual_mov_b32 v12, v5 :: v_dual_mov_b32 v11, v4           // 0000007503C0: CA100105 0C0A0104
	v_dual_mov_b32 v10, v3 :: v_dual_mov_b32 v9, v2            // 0000007503C8: CA100103 0A080102
	v_mov_b32_e32 v8, v1                                       // 0000007503D0: 7E100301
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 0000007503D4: 917E107E
	s_cbranch_execz 35                                         // 0000007503D8: BFA50023 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xc68>
	s_waitcnt vmcnt(0)                                         // 0000007503DC: BF8903F7
	v_dual_mov_b32 v16, v20 :: v_dual_add_nc_u32 v31, 32, v31  // 0000007503E0: CA200114 101E3EA0
	v_dual_mov_b32 v17, v21 :: v_dual_mov_b32 v18, v22         // 0000007503E8: CA100115 11120116
	v_mov_b32_e32 v19, v23                                     // 0000007503F0: 7E260317
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007503F4: BF870003
	.long 0xd4460001                                           // 0000007503F8: D4460001
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 0000007503FC: 0202411F
	s_mov_b32 s18, exec_lo                                     // 000000750400: BE92007E
	.long 0xd4c1007e                                           // 000000750404: D4C1007E
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 000000750408: 0202411F
	s_cbranch_execz 65088                                      // 00000075040C: BFA5FE40 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x510>
	v_ashrrev_i32_e32 v2, 31, v41                              // 000000750410: 3404529F
	.long 0xd7006a01                                           // 000000750414: D7006A01
	v_cndmask_b32_e32 v1, v25, v41, vcc_lo                     // 000000750418: 02025319
	v_mov_b32_e32 v43, v27                                     // 00000075041C: 7E56031B
	s_delay_alu instid0(VALU_DEP_3)                            // 000000750420: BF870003
	v_add_co_ci_u32_e64 v2, null, v36, v2, vcc_lo              // 000000750424: D5207C02 01AA0524
	v_cmp_ne_u32_e32 vcc_lo, 1, v35                            // 00000075042C: 7C9A4681
	global_load_b128 v[16:19], v[1:2], off                     // 000000750430: DC5E0000 107C0001
	s_cbranch_vccnz 65077                                      // 000000750438: BFA4FE35 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x510>
	v_ashrrev_i32_e32 v2, 31, v42                              // 00000075043C: 3404549F
	.long 0xd7006a01                                           // 000000750440: D7006A01
	v_cndmask_b32_e32 v1, v24, v42, vcc_lo                     // 000000750444: 02025518
	s_delay_alu instid0(VALU_DEP_1)                            // 000000750448: BF870001
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 00000075044C: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 000000750454: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 00000075045C: BF8903F7
	v_cvt_f32_f16_e32 v43, v1                                  // 000000750460: 7E561701
	s_branch 65066                                             // 000000750464: BFA0FE2A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x510>
	s_or_b32 exec_lo, exec_lo, s16                             // 000000750468: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000075046C: BF8700B9
	s_or_b32 exec_lo, exec_lo, s14                             // 000000750470: 8C7E0E7E
	.long 0xd71f0001                                           // 000000750474: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000750478: 020100C1
	s_mov_b32 s0, exec_lo                                      // 00000075047C: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 000000750480: 3A040290
	v_xor_b32_e32 v7, 8, v1                                    // 000000750484: 3A0E0288
	v_xor_b32_e32 v12, 4, v1                                   // 000000750488: 3A180284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000075048C: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 000000750490: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 000000750494: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v7                            // 000000750498: 7C980EA0
	v_cndmask_b32_e32 v7, v1, v7, vcc_lo                       // 00000075049C: 020E0F01
	v_cmp_gt_u32_e32 vcc_lo, 32, v12                           // 0000007504A0: 7C9818A0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007504A4: BF870002
	v_lshlrev_b32_e32 v7, 2, v7                                // 0000007504A8: 300E0E82
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000007504AC: 30040482
	ds_bpermute_b32 v3, v2, v37                                // 0000007504B0: DACC0000 03002502
	s_waitcnt lgkmcnt(0)                                       // 0000007504B8: BF89FC07
	v_add_f32_e32 v3, v37, v3                                  // 0000007504BC: 06060725
	ds_bpermute_b32 v4, v2, v40                                // 0000007504C0: DACC0000 04002802
	ds_bpermute_b32 v5, v2, v39                                // 0000007504C8: DACC0000 05002702
	ds_bpermute_b32 v6, v2, v38                                // 0000007504D0: DACC0000 06002602
	ds_bpermute_b32 v2, v2, v34                                // 0000007504D8: DACC0000 02002202
	ds_bpermute_b32 v8, v7, v3                                 // 0000007504E0: DACC0000 08000307
	s_waitcnt lgkmcnt(3)                                       // 0000007504E8: BF89FC37
	v_dual_add_f32 v4, v40, v4 :: v_dual_add_f32 v5, v39, v5   // 0000007504EC: C9080928 04040B27
	s_waitcnt lgkmcnt(2)                                       // 0000007504F4: BF89FC27
	v_add_f32_e32 v6, v38, v6                                  // 0000007504F8: 060C0D26
	s_waitcnt lgkmcnt(0)                                       // 0000007504FC: BF89FC07
	v_dual_add_f32 v2, v34, v2 :: v_dual_add_f32 v3, v3, v8    // 000000750500: C9080522 02021103
	ds_bpermute_b32 v9, v7, v4                                 // 000000750508: DACC0000 09000407
	ds_bpermute_b32 v10, v7, v5                                // 000000750510: DACC0000 0A000507
	v_cndmask_b32_e32 v12, v1, v12, vcc_lo                     // 000000750518: 02181901
	ds_bpermute_b32 v11, v7, v6                                // 00000075051C: DACC0000 0B000607
	ds_bpermute_b32 v7, v7, v2                                 // 000000750524: DACC0000 07000207
	v_lshlrev_b32_e32 v12, 2, v12                              // 00000075052C: 30181882
	s_waitcnt lgkmcnt(2)                                       // 000000750530: BF89FC27
	v_dual_add_f32 v4, v4, v9 :: v_dual_add_f32 v5, v5, v10    // 000000750534: C9081304 04041505
	ds_bpermute_b32 v8, v12, v4                                // 00000075053C: DACC0000 0800040C
	ds_bpermute_b32 v9, v12, v5                                // 000000750544: DACC0000 0900050C
	s_waitcnt lgkmcnt(3)                                       // 00000075054C: BF89FC37
	v_add_f32_e32 v6, v6, v11                                  // 000000750550: 060C1706
	s_waitcnt lgkmcnt(1)                                       // 000000750554: BF89FC17
	v_add_f32_e32 v4, v4, v8                                   // 000000750558: 06081104
	v_add_f32_e32 v2, v2, v7                                   // 00000075055C: 06040F02
	ds_bpermute_b32 v7, v12, v3                                // 000000750560: DACC0000 0700030C
	s_waitcnt lgkmcnt(1)                                       // 000000750568: BF89FC17
	v_add_f32_e32 v5, v5, v9                                   // 00000075056C: 060A1305
	ds_bpermute_b32 v10, v12, v6                               // 000000750570: DACC0000 0A00060C
	ds_bpermute_b32 v11, v12, v2                               // 000000750578: DACC0000 0B00020C
	v_xor_b32_e32 v12, 2, v1                                   // 000000750580: 3A180282
	s_delay_alu instid0(VALU_DEP_1)                            // 000000750584: BF870001
	v_cmp_gt_u32_e32 vcc_lo, 32, v12                           // 000000750588: 7C9818A0
	s_waitcnt lgkmcnt(2)                                       // 00000075058C: BF89FC27
	v_dual_add_f32 v3, v3, v7 :: v_dual_cndmask_b32 v12, v1, v12// 000000750590: C9120F03 030C1901
	s_waitcnt lgkmcnt(1)                                       // 000000750598: BF89FC17
	v_add_f32_e32 v6, v6, v10                                  // 00000075059C: 060C1506
	s_waitcnt lgkmcnt(0)                                       // 0000007505A0: BF89FC07
	v_add_f32_e32 v2, v2, v11                                  // 0000007505A4: 06041702
	v_lshlrev_b32_e32 v12, 2, v12                              // 0000007505A8: 30181882
	ds_bpermute_b32 v7, v12, v3                                // 0000007505AC: DACC0000 0700030C
	ds_bpermute_b32 v8, v12, v4                                // 0000007505B4: DACC0000 0800040C
	ds_bpermute_b32 v9, v12, v5                                // 0000007505BC: DACC0000 0900050C
	ds_bpermute_b32 v10, v12, v6                               // 0000007505C4: DACC0000 0A00060C
	ds_bpermute_b32 v11, v12, v2                               // 0000007505CC: DACC0000 0B00020C
	v_xor_b32_e32 v12, 1, v1                                   // 0000007505D4: 3A180281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007505D8: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v12                           // 0000007505DC: 7C9818A0
	v_cndmask_b32_e32 v1, v1, v12, vcc_lo                      // 0000007505E0: 02021901
	s_waitcnt lgkmcnt(4)                                       // 0000007505E4: BF89FC47
	v_dual_add_f32 v1, v3, v7 :: v_dual_lshlrev_b32 v12, 2, v1 // 0000007505E8: C9220F03 010C0282
	s_waitcnt lgkmcnt(2)                                       // 0000007505F0: BF89FC27
	v_dual_add_f32 v3, v4, v8 :: v_dual_add_f32 v4, v5, v9     // 0000007505F4: C9081104 03041305
	s_waitcnt lgkmcnt(1)                                       // 0000007505FC: BF89FC17
	v_add_f32_e32 v7, v6, v10                                  // 000000750600: 060E1506
	s_waitcnt lgkmcnt(0)                                       // 000000750604: BF89FC07
	v_add_f32_e32 v2, v2, v11                                  // 000000750608: 06041702
	ds_bpermute_b32 v5, v12, v1                                // 00000075060C: DACC0000 0500010C
	ds_bpermute_b32 v8, v12, v3                                // 000000750614: DACC0000 0800030C
	ds_bpermute_b32 v9, v12, v4                                // 00000075061C: DACC0000 0900040C
	ds_bpermute_b32 v10, v12, v7                               // 000000750624: DACC0000 0A00070C
	ds_bpermute_b32 v6, v12, v2                                // 00000075062C: DACC0000 0600020C
	v_cmpx_eq_u32_e32 0, v30                                   // 000000750634: 7D943C80
	s_cbranch_execz 21                                         // 000000750638: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xe90>
	.long 0xd72c000b                                           // 00000075063C: D72C000B
	v_cndmask_b32_e32 v0, v28, v168, vcc_lo                    // 000000750640: 0201511C
	s_waitcnt lgkmcnt(0)                                       // 000000750644: BF89FC07
	v_dual_add_f32 v1, v1, v5 :: v_dual_add_f32 v2, v2, v6     // 000000750648: C9080B01 01020D02
	v_dual_add_f32 v7, v7, v10 :: v_dual_add_f32 v4, v4, v9    // 000000750650: C9081507 07041304
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000750658: BF870093
	v_mad_u32_u24 v11, v29, 20, v11                            // 00000075065C: D60B000B 042D291D
	v_dual_add_f32 v3, v3, v8 :: v_dual_add_nc_u32 v8, 0x408, v11// 000000750664: C9201103 030816FF 00000408
	v_add_nc_u32_e32 v5, 0x400, v11                            // 000000750670: 4A0A16FF 00000400
	ds_store_2addr_b32 v5, v1, v3 offset1:1                    // 000000750678: D8380100 00030105
	ds_store_2addr_b32 v8, v4, v7 offset1:1                    // 000000750680: D8380100 00070408
	ds_store_b32 v11, v2 offset:1040                           // 000000750688: D8340410 0000020B
	s_or_b32 exec_lo, exec_lo, s0                              // 000000750690: 8C7E007E
	.long 0xd7050001                                           // 000000750694: D7050001
	v_cndmask_b32_e32 v1, 0xcd, v0, vcc_lo                     // 000000750698: 020200FF 000000CD
	.long 0x7f063880                                           // 0000007506A0: 7F063880
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000007506A4: BF890007
	s_barrier                                                  // 0000007506A8: BFBD0000
	buffer_gl0_inv                                             // 0000007506AC: E0AC0000 00000000
	.long 0xd7390003                                           // 0000007506B4: D7390003
	v_cndmask_b32_e32 v1, 10, v1, vcc_lo                       // 0000007506B8: 0202028A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007506BC: BF870091
	.long 0xd7000001                                           // 0000007506C0: D7000001
	v_cndmask_b32_e32 v1, s2, v3, vcc_lo                       // 0000007506C4: 02020602
	v_add_co_ci_u32_e64 v2, null, s3, 0, s0                    // 0000007506C8: D5207C02 00010003
	.long 0xd44c0000                                           // 0000007506D0: D44C0000
	v_cndmask_b32_e32 v1, 20, v0, vcc_lo                       // 0000007506D4: 02020094
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000007506D8: BF8704A2
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 0000007506DC: 7CA8020C
	s_and_b32 s0, s0, vcc_lo                                   // 0000007506E0: 8B006A00
	s_and_saveexec_b32 s1, s0                                  // 0000007506E4: BE812000
	s_cbranch_execz 39                                         // 0000007506E8: BFA50027 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xf88>
	.long 0xd7054000                                           // 0000007506EC: D7054000
	v_cndmask_b32_e32 v0, v3, v133, vcc_lo                     // 0000007506F0: 02010B03
	v_mul_u32_u24_e32 v3, 40, v3                               // 0000007506F4: 160606A8
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007506F8: BF870092
	.long 0xd7041000                                           // 0000007506FC: D7041000
	v_cndmask_b32_e32 v1, v0, v0, vcc_lo                       // 000000750700: 02020100
	v_and_b32_e32 v0, 0xff, v0                                 // 000000750704: 360000FF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075070C: BF870091
	v_lshl_add_u32 v3, v0, 2, v3                               // 000000750710: D6460003 040D0500
	v_add_nc_u32_e32 v5, 0x400, v3                             // 000000750718: 4A0A06FF 00000400
	v_mad_u64_u32 v[3:4], null, s12, v0, 0                     // 000000750720: D6FE7C03 0202000C
	ds_load_2addr_b32 v[6:7], v5 offset1:5                     // 000000750728: D8DC0500 06000005
	v_mad_u64_u32 v[4:5], null, s13, v0, v[4:5]                // 000000750730: D6FE7C04 0412000D
	.long 0xd73c0000                                           // 000000750738: D73C0000
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000075073C: 02020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000750740: BF870092
	.long 0xd73c0003                                           // 000000750744: D73C0003
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 000000750748: 02020682
	.long 0xd7006a03                                           // 00000075074C: D7006A03
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 000000750750: 02020608
	s_waitcnt lgkmcnt(0)                                       // 000000750754: BF89FC07
	v_add_f32_e32 v2, 0, v6                                    // 000000750758: 06040C80
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000075075C: BF870193
	v_add_co_ci_u32_e64 v4, null, s9, v4, vcc_lo               // 000000750760: D5207C04 01AA0809
	.long 0xd7006a00                                           // 000000750768: D7006A00
	v_cndmask_b32_e32 v1, v3, v0, vcc_lo                       // 00000075076C: 02020103
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000750770: BF870193
	v_add_f32_e32 v2, v2, v7                                   // 000000750774: 06040F02
	v_add_co_ci_u32_e64 v1, null, v4, v1, vcc_lo               // 000000750778: D5207C01 01AA0304
	global_store_b32 v[0:1], v2, off                           // 000000750780: DC6A0000 007C0200
	s_endpgm                                                   // 000000750788: BFB00000
		...

