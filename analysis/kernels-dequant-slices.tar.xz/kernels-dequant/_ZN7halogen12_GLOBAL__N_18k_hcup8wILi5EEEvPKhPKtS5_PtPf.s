00000000003d7000 <_ZN7halogen12_GLOBAL__N_18k_hcup8wILi5EEEvPKhPKtS5_PtPf>:
; _ZN7halogen12_GLOBAL__N_18k_hcup8wILi5EEEvPKhPKtS5_PtPf():
	s_load_b256 s[4:11], s[0:1], null                          // 0000003D7000: F40C0100 F8000000
	v_lshrrev_b32_e32 v1, 6, v0                                // 0000003D7008: 32020086
	v_bfe_u32 v2, v0, 4, 2                                     // 0000003D700C: D6100002 02090900
	s_lshl_b32 s2, s2, 2                                       // 0000003D7014: 84028202
	v_dual_mov_b32 v12, 0 :: v_dual_and_b32 v11, 15, v0        // 0000003D7018: CA240080 0C0A008F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003D7020: BF870193
	v_or_b32_e32 v1, s2, v1                                    // 0000003D7024: 38020202
	v_mul_u32_u24_e32 v2, 0xa00, v2                            // 0000003D7028: 160404FF 00000A00
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000003D7030: BF870223
	v_lshlrev_b32_e32 v15, 4, v11                              // 0000003D7034: 301E1684
	v_or_b32_e32 v13, 16, v11                                  // 0000003D7038: 381A1690
	v_ashrrev_i32_e32 v3, 31, v1                               // 0000003D703C: 3406029F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003D7040: BF870094
	.long 0xd7006a01                                           // 0000003D7044: D7006A01
	v_cndmask_b32_e32 v1, v2, v1, vcc_lo                       // 0000003D7048: 02020302
	v_add_co_ci_u32_e64 v2, null, 0, v3, vcc_lo                // 0000003D704C: D5207C02 01AA0680
	v_and_b32_e32 v3, 12, v0                                   // 0000003D7054: 3606008C
	s_waitcnt lgkmcnt(0)                                       // 0000003D7058: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000003D705C: BF8700D3
	v_mad_u64_u32 v[9:10], null, 0x154, v1, s[4:5]             // 0000003D7060: D6FE7C09 001202FF 00000154
	s_load_b64 s[4:5], s[0:1], 0x20                            // 0000003D706C: F4040100 F8000020
	s_mov_b32 s0, exec_lo                                      // 0000003D7074: BE80007E
	v_mad_i32_i24 v10, 0x154, v2, v10                          // 0000003D7078: D60A000A 042A04FF 00000154
	.long 0xd7006a01                                           // 0000003D7084: D7006A01
	v_cndmask_b32_e32 v1, v9, v15, vcc_lo                      // 0000003D7088: 02021F09
	v_add_co_ci_u32_e64 v2, null, 0, v10, vcc_lo               // 0000003D708C: D5207C02 01AA1480
	.long 0xd7006a03                                           // 0000003D7094: D7006A03
	v_cndmask_b32_e32 v1, v9, v3, vcc_lo                       // 0000003D7098: 02020709
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003D709C: BF870001
	v_add_co_ci_u32_e64 v4, null, 0, v10, vcc_lo               // 0000003D70A0: D5207C04 01AA1480
	s_clause 0x1                                               // 0000003D70A8: BF850001
	global_load_b128 v[5:8], v[1:2], off                       // 0000003D70AC: DC5E0000 057C0001
	global_load_b32 v14, v[3:4], off offset:320                // 0000003D70B4: DC520140 0E7C0003
	v_cmpx_gt_u32_e32 20, v13                                  // 0000003D70BC: 7D981A94
	s_cbranch_execz 5                                          // 0000003D70C0: BFA50005 <_ZN7halogen12_GLOBAL__N_18k_hcup8wILi5EEEvPKhPKtS5_PtPf+0xd8>
	s_clause 0x1                                               // 0000003D70C4: BF850001
	global_load_b128 v[1:4], v[1:2], off offset:256            // 0000003D70C8: DC5E0100 017C0001
	global_load_b32 v12, v[9:10], off offset:336               // 0000003D70D0: DC520150 0C7C0009
	s_or_b32 exec_lo, exec_lo, s0                              // 0000003D70D8: 8C7E007E
	v_lshlrev_b32_e32 v15, 1, v15                              // 0000003D70DC: 301E1E81
	s_waitcnt vmcnt(1)                                         // 0000003D70E0: BF8907F7
	v_cvt_f32_ubyte0_e32 v10, v5                               // 0000003D70E4: 7E142305
	v_cvt_f32_ubyte1_e32 v56, v5                               // 0000003D70E8: 7E702505
	v_cvt_f32_ubyte2_e32 v57, v5                               // 0000003D70EC: 7E722705
	v_cvt_f32_ubyte3_e32 v5, v5                                // 0000003D70F0: 7E0A2905
	s_clause 0x9                                               // 0000003D70F4: BF850009
	global_load_b128 v[16:19], v15, s[6:7]                     // 0000003D70F8: DC5E0000 1006000F
	global_load_b128 v[20:23], v15, s[6:7] offset:640          // 0000003D7100: DC5E0280 1406000F
	global_load_b128 v[24:27], v15, s[6:7] offset:1280         // 0000003D7108: DC5E0500 1806000F
	global_load_b128 v[28:31], v15, s[6:7] offset:1920         // 0000003D7110: DC5E0780 1C06000F
	global_load_b128 v[32:35], v15, s[6:7] offset:2560         // 0000003D7118: DC5E0A00 2006000F
	global_load_b128 v[36:39], v15, s[6:7] offset:16           // 0000003D7120: DC5E0010 2406000F
	global_load_b128 v[40:43], v15, s[6:7] offset:656          // 0000003D7128: DC5E0290 2806000F
	global_load_b128 v[44:47], v15, s[6:7] offset:1296         // 0000003D7130: DC5E0510 2C06000F
	global_load_b128 v[48:51], v15, s[6:7] offset:1936         // 0000003D7138: DC5E0790 3006000F
	global_load_b128 v[52:55], v15, s[6:7] offset:2576         // 0000003D7140: DC5E0A10 3406000F
	v_cvt_f32_ubyte0_e32 v58, v6                               // 0000003D7148: 7E742306
	v_cvt_f32_ubyte1_e32 v59, v6                               // 0000003D714C: 7E762506
	v_cvt_f32_ubyte2_e32 v60, v6                               // 0000003D7150: 7E782706
	v_cvt_f32_ubyte3_e32 v6, v6                                // 0000003D7154: 7E0C2906
	v_cvt_f32_ubyte0_e32 v61, v7                               // 0000003D7158: 7E7A2307
	v_cvt_f32_ubyte1_e32 v62, v7                               // 0000003D715C: 7E7C2507
	v_cvt_f32_ubyte2_e32 v63, v7                               // 0000003D7160: 7E7E2707
	v_cvt_f32_ubyte3_e32 v7, v7                                // 0000003D7164: 7E0E2907
	v_cvt_f32_ubyte0_e32 v64, v8                               // 0000003D7168: 7E802308
	v_cvt_f32_ubyte1_e32 v65, v8                               // 0000003D716C: 7E822508
	v_cvt_f32_ubyte2_e32 v66, v8                               // 0000003D7170: 7E842708
	v_cvt_f32_ubyte3_e32 v8, v8                                // 0000003D7174: 7E102908
	s_waitcnt vmcnt(10)                                        // 0000003D7178: BF892BF7
	v_fma_mix_f32 v10, v10, v14, v14 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D717C: CC20600A 143A1D0A
	v_fma_mix_f32 v56, v56, v14, v14 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D7184: CC206038 143A1D38
	v_fma_mix_f32 v57, v57, v14, v14 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D718C: CC206039 143A1D39
	v_fma_mix_f32 v5, v5, v14, v14 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D7194: CC206005 143A1D05
	v_fma_mix_f32 v58, v58, v14, v14 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D719C: CC20603A 143A1D3A
	v_fma_mix_f32 v59, v59, v14, v14 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D71A4: CC20603B 143A1D3B
	v_fma_mix_f32 v60, v60, v14, v14 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D71AC: CC20603C 143A1D3C
	v_fma_mix_f32 v6, v6, v14, v14 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D71B4: CC206006 143A1D06
	v_fma_mix_f32 v61, v61, v14, v14 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D71BC: CC20603D 143A1D3D
	v_fma_mix_f32 v62, v62, v14, v14 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D71C4: CC20603E 143A1D3E
	v_fma_mix_f32 v63, v63, v14, v14 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D71CC: CC20603F 143A1D3F
	v_fma_mix_f32 v7, v7, v14, v14 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D71D4: CC206007 143A1D07
	v_fma_mix_f32 v64, v64, v14, v14 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D71DC: CC206040 143A1D40
	v_fma_mix_f32 v65, v65, v14, v14 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D71E4: CC206041 143A1D41
	v_fma_mix_f32 v66, v66, v14, v14 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D71EC: CC206042 143A1D42
	v_fma_mix_f32 v8, v8, v14, v14 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D71F4: CC206008 143A1D08
	v_bfe_u32 v14, v10, 16, 1                                  // 0000003D71FC: D610000E 0205210A
	v_bfe_u32 v71, v56, 16, 1                                  // 0000003D7204: D6100047 02052138
	v_bfe_u32 v72, v57, 16, 1                                  // 0000003D720C: D6100048 02052139
	.long 0x7f123880                                           // 0000003D7214: 7F123880
	v_bfe_u32 v73, v5, 16, 1                                   // 0000003D7218: D6100049 02052105
	v_add3_u32 v10, v10, v14, 0x7fff                           // 0000003D7220: D655000A 03FE1D0A 00007FFF
	v_bfe_u32 v74, v58, 16, 1                                  // 0000003D722C: D610004A 0205213A
	v_add3_u32 v14, v56, v71, 0x7fff                           // 0000003D7234: D655000E 03FE8F38 00007FFF
	v_add3_u32 v56, v57, v72, 0x7fff                           // 0000003D7240: D6550038 03FE9139 00007FFF
	.long 0x7f863989                                           // 0000003D724C: 7F863989
	.long 0x7e12398a                                           // 0000003D7250: 7E12398A
	v_bfe_u32 v75, v59, 16, 1                                  // 0000003D7254: D610004B 0205213B
	v_bfe_u32 v76, v60, 16, 1                                  // 0000003D725C: D610004C 0205213C
	v_add3_u32 v5, v5, v73, 0x7fff                             // 0000003D7264: D6550005 03FE9305 00007FFF
	v_add3_u32 v57, v58, v74, 0x7fff                           // 0000003D7270: D6550039 03FE953A 00007FFF
	v_and_or_b32 v14, 0xffff0000, v14, v9                      // 0000003D727C: D657000E 04261CFF FFFF0000
	.long 0x7e8639b8                                           // 0000003D7288: 7E8639B8
	v_bfe_u32 v77, v6, 16, 1                                   // 0000003D728C: D610004D 02052106
	v_bfe_u32 v78, v61, 16, 1                                  // 0000003D7294: D610004E 0205213D
	v_add3_u32 v58, v59, v75, 0x7fff                           // 0000003D729C: D655003A 03FE973B 00007FFF
	v_add3_u32 v59, v60, v76, 0x7fff                           // 0000003D72A8: D655003B 03FE993C 00007FFF
	.long 0x7e1239b9                                           // 0000003D72B4: 7E1239B9
	v_and_or_b32 v5, 0xffff0000, v5, v67                       // 0000003D72B8: D6570005 050E0AFF FFFF0000
	.long 0x7f883989                                           // 0000003D72C4: 7F883989
	v_bfe_u32 v79, v62, 16, 1                                  // 0000003D72C8: D610004F 0205213E
	v_bfe_u32 v80, v63, 16, 1                                  // 0000003D72D0: D6100050 0205213F
	v_add3_u32 v6, v6, v77, 0x7fff                             // 0000003D72D8: D6550006 03FE9B06 00007FFF
	v_add3_u32 v10, v61, v78, 0x7fff                           // 0000003D72E4: D655000A 03FE9D3D 00007FFF
	v_and_or_b32 v58, 0xffff0000, v58, v9                      // 0000003D72F0: D657003A 042674FF FFFF0000
	.long 0x7e8839bb                                           // 0000003D72FC: 7E8839BB
	v_bfe_u32 v81, v7, 16, 1                                   // 0000003D7300: D6100051 02052107
	v_bfe_u32 v82, v64, 16, 1                                  // 0000003D7308: D6100052 02052140
	v_add3_u32 v60, v62, v79, 0x7fff                           // 0000003D7310: D655003C 03FE9F3E 00007FFF
	v_add3_u32 v61, v63, v80, 0x7fff                           // 0000003D731C: D655003D 03FEA13F 00007FFF
	.long 0x7e12398a                                           // 0000003D7328: 7E12398A
	v_and_or_b32 v6, 0xffff0000, v6, v68                       // 0000003D732C: D6570006 05120CFF FFFF0000
	.long 0x7f8a3989                                           // 0000003D7338: 7F8A3989
	v_bfe_u32 v83, v65, 16, 1                                  // 0000003D733C: D6100053 02052141
	v_bfe_u32 v84, v66, 16, 1                                  // 0000003D7344: D6100054 02052142
	v_add3_u32 v7, v7, v81, 0x7fff                             // 0000003D734C: D6550007 03FEA307 00007FFF
	v_add3_u32 v57, v64, v82, 0x7fff                           // 0000003D7358: D6550039 03FEA540 00007FFF
	.long 0x7e8a39bd                                           // 0000003D7364: 7E8A39BD
	v_and_or_b32 v10, 0xffff0000, v60, v9                      // 0000003D7368: D657000A 042678FF FFFF0000
	v_bfe_u32 v85, v8, 16, 1                                   // 0000003D7374: D6100055 02052108
	v_add3_u32 v62, v65, v83, 0x7fff                           // 0000003D737C: D655003E 03FEA741 00007FFF
	v_add3_u32 v63, v66, v84, 0x7fff                           // 0000003D7388: D655003F 03FEA942 00007FFF
	.long 0x7e1239b9                                           // 0000003D7394: 7E1239B9
	v_and_or_b32 v7, 0xffff0000, v7, v69                       // 0000003D7398: D6570007 05160EFF FFFF0000
	.long 0x7f8c3989                                           // 0000003D73A4: 7F8C3989
	v_add3_u32 v8, v8, v85, 0x7fff                             // 0000003D73A8: D6550008 03FEAB08 00007FFF
	.long 0x7e8c39bf                                           // 0000003D73B4: 7E8C39BF
	v_and_or_b32 v56, 0xffff0000, v62, v9                      // 0000003D73B8: D6570038 04267CFF FFFF0000
	s_mov_b32 s0, exec_lo                                      // 0000003D73C4: BE80007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000003D73C8: BF870002
	v_and_or_b32 v8, 0xffff0000, v8, v70                       // 0000003D73CC: D6570008 051A10FF FFFF0000
	s_waitcnt vmcnt(9)                                         // 0000003D73D8: BF8927F7
	v_dot2_f32_bf16 v16, v16, v14, 0                           // 0000003D73DC: CC1A4010 1A021D10
	s_waitcnt vmcnt(8)                                         // 0000003D73E4: BF8923F7
	v_dot2_f32_bf16 v20, v20, v14, 0                           // 0000003D73E8: CC1A4014 1A021D14
	s_waitcnt vmcnt(7)                                         // 0000003D73F0: BF891FF7
	v_dot2_f32_bf16 v24, v24, v14, 0                           // 0000003D73F4: CC1A4018 1A021D18
	s_waitcnt vmcnt(6)                                         // 0000003D73FC: BF891BF7
	v_dot2_f32_bf16 v28, v28, v14, 0                           // 0000003D7400: CC1A401C 1A021D1C
	s_waitcnt vmcnt(5)                                         // 0000003D7408: BF8917F7
	v_dot2_f32_bf16 v14, v32, v14, 0                           // 0000003D740C: CC1A400E 1A021D20
	v_dot2_f32_bf16 v16, v17, v5, v16                          // 0000003D7414: CC1A4010 1C420B11
	v_dot2_f32_bf16 v17, v21, v5, v20                          // 0000003D741C: CC1A4011 1C520B15
	v_dot2_f32_bf16 v20, v25, v5, v24                          // 0000003D7424: CC1A4014 1C620B19
	v_dot2_f32_bf16 v21, v29, v5, v28                          // 0000003D742C: CC1A4015 1C720B1D
	v_dot2_f32_bf16 v5, v33, v5, v14                           // 0000003D7434: CC1A4005 1C3A0B21
	v_dot2_f32_bf16 v14, v18, v58, v16                         // 0000003D743C: CC1A400E 1C427512
	v_dot2_f32_bf16 v16, v22, v58, v17                         // 0000003D7444: CC1A4010 1C467516
	v_dot2_f32_bf16 v17, v26, v58, v20                         // 0000003D744C: CC1A4011 1C52751A
	v_dot2_f32_bf16 v18, v30, v58, v21                         // 0000003D7454: CC1A4012 1C56751E
	v_dot2_f32_bf16 v5, v34, v58, v5                           // 0000003D745C: CC1A4005 1C167522
	v_dot2_f32_bf16 v14, v19, v6, v14                          // 0000003D7464: CC1A400E 1C3A0D13
	v_dot2_f32_bf16 v16, v23, v6, v16                          // 0000003D746C: CC1A4010 1C420D17
	v_dot2_f32_bf16 v17, v27, v6, v17                          // 0000003D7474: CC1A4011 1C460D1B
	v_dot2_f32_bf16 v18, v31, v6, v18                          // 0000003D747C: CC1A4012 1C4A0D1F
	v_dot2_f32_bf16 v5, v35, v6, v5                            // 0000003D7484: CC1A4005 1C160D23
	s_waitcnt vmcnt(4)                                         // 0000003D748C: BF8913F7
	v_dot2_f32_bf16 v6, v36, v10, v14                          // 0000003D7490: CC1A4006 1C3A1524
	s_waitcnt vmcnt(3)                                         // 0000003D7498: BF890FF7
	v_dot2_f32_bf16 v14, v40, v10, v16                         // 0000003D749C: CC1A400E 1C421528
	s_waitcnt vmcnt(2)                                         // 0000003D74A4: BF890BF7
	v_dot2_f32_bf16 v16, v44, v10, v17                         // 0000003D74A8: CC1A4010 1C46152C
	s_waitcnt vmcnt(1)                                         // 0000003D74B0: BF8907F7
	v_dot2_f32_bf16 v17, v48, v10, v18                         // 0000003D74B4: CC1A4011 1C4A1530
	s_waitcnt vmcnt(0)                                         // 0000003D74BC: BF8903F7
	v_dot2_f32_bf16 v5, v52, v10, v5                           // 0000003D74C0: CC1A4005 1C161534
	v_dot2_f32_bf16 v6, v37, v7, v6                            // 0000003D74C8: CC1A4006 1C1A0F25
	v_dot2_f32_bf16 v10, v41, v7, v14                          // 0000003D74D0: CC1A400A 1C3A0F29
	v_dot2_f32_bf16 v14, v45, v7, v16                          // 0000003D74D8: CC1A400E 1C420F2D
	v_dot2_f32_bf16 v16, v49, v7, v17                          // 0000003D74E0: CC1A4010 1C460F31
	v_dot2_f32_bf16 v5, v53, v7, v5                            // 0000003D74E8: CC1A4005 1C160F35
	v_dot2_f32_bf16 v6, v38, v56, v6                           // 0000003D74F0: CC1A4006 1C1A7126
	v_dot2_f32_bf16 v7, v42, v56, v10                          // 0000003D74F8: CC1A4007 1C2A712A
	v_dot2_f32_bf16 v10, v46, v56, v14                         // 0000003D7500: CC1A400A 1C3A712E
	v_dot2_f32_bf16 v14, v50, v56, v16                         // 0000003D7508: CC1A400E 1C427132
	v_dot2_f32_bf16 v5, v54, v56, v5                           // 0000003D7510: CC1A4005 1C167136
	v_dot2_f32_bf16 v6, v39, v8, v6                            // 0000003D7518: CC1A4006 1C1A1127
	v_dot2_f32_bf16 v7, v43, v8, v7                            // 0000003D7520: CC1A4007 1C1E112B
	v_dot2_f32_bf16 v16, v47, v8, v10                          // 0000003D7528: CC1A4010 1C2A112F
	v_dot2_f32_bf16 v14, v51, v8, v14                          // 0000003D7530: CC1A400E 1C3A1133
	v_dot2_f32_bf16 v17, v55, v8, v5                           // 0000003D7538: CC1A4011 1C161137
	v_add_f32_e32 v8, 0, v6                                    // 0000003D7540: 06100C80
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003D7544: BF870194
	v_dual_add_f32 v10, 0, v7 :: v_dual_add_f32 v5, 0, v16     // 0000003D7548: C9080E80 0A042080
	v_dual_add_f32 v6, 0, v14 :: v_dual_add_f32 v7, 0, v17     // 0000003D7550: C9081C80 06062280
	v_cmpx_gt_u32_e32 20, v13                                  // 0000003D7558: 7D981A94
	s_cbranch_execz 287                                        // 0000003D755C: BFA5011F <_ZN7halogen12_GLOBAL__N_18k_hcup8wILi5EEEvPKhPKtS5_PtPf+0x9dc>
	.long 0xd7000131                                           // 0000003D7560: D7000131
	v_cndmask_b32_e32 v1, s6, v15, vcc_lo                      // 0000003D7564: 02021E06
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003D7568: BF870001
	v_add_co_ci_u32_e64 v50, null, s7, 0, s1                   // 0000003D756C: D5207C32 00050007
	v_cvt_f32_ubyte0_e32 v53, v1                               // 0000003D7574: 7E6A2301
	v_cvt_f32_ubyte1_e32 v54, v1                               // 0000003D7578: 7E6C2501
	v_cvt_f32_ubyte2_e32 v55, v1                               // 0000003D757C: 7E6E2701
	s_clause 0x9                                               // 0000003D7580: BF850009
	global_load_b128 v[13:16], v[49:50], off offset:512        // 0000003D7584: DC5E0200 0D7C0031
	global_load_b128 v[17:20], v[49:50], off offset:1152       // 0000003D758C: DC5E0480 117C0031
	global_load_b128 v[21:24], v[49:50], off offset:1792       // 0000003D7594: DC5E0700 157C0031
	global_load_b128 v[25:28], v[49:50], off offset:2432       // 0000003D759C: DC5E0980 197C0031
	global_load_b128 v[29:32], v[49:50], off offset:3072       // 0000003D75A4: DC5E0C00 1D7C0031
	global_load_b128 v[33:36], v[49:50], off offset:528        // 0000003D75AC: DC5E0210 217C0031
	global_load_b128 v[37:40], v[49:50], off offset:1168       // 0000003D75B4: DC5E0490 257C0031
	global_load_b128 v[41:44], v[49:50], off offset:1808       // 0000003D75BC: DC5E0710 297C0031
	global_load_b128 v[45:48], v[49:50], off offset:2448       // 0000003D75C4: DC5E0990 2D7C0031
	global_load_b128 v[49:52], v[49:50], off offset:3088       // 0000003D75CC: DC5E0C10 317C0031
	v_cvt_f32_ubyte3_e32 v1, v1                                // 0000003D75D4: 7E022901
	v_cvt_f32_ubyte0_e32 v57, v2                               // 0000003D75D8: 7E722302
	v_cvt_f32_ubyte1_e32 v58, v2                               // 0000003D75DC: 7E742502
	v_cvt_f32_ubyte2_e32 v59, v2                               // 0000003D75E0: 7E762702
	v_cvt_f32_ubyte3_e32 v2, v2                                // 0000003D75E4: 7E042902
	v_cvt_f32_ubyte0_e32 v61, v3                               // 0000003D75E8: 7E7A2303
	v_cvt_f32_ubyte1_e32 v62, v3                               // 0000003D75EC: 7E7C2503
	v_cvt_f32_ubyte2_e32 v63, v3                               // 0000003D75F0: 7E7E2703
	v_cvt_f32_ubyte3_e32 v3, v3                                // 0000003D75F4: 7E062903
	v_cvt_f32_ubyte0_e32 v65, v4                               // 0000003D75F8: 7E822304
	v_cvt_f32_ubyte1_e32 v66, v4                               // 0000003D75FC: 7E842504
	v_cvt_f32_ubyte2_e32 v67, v4                               // 0000003D7600: 7E862704
	v_cvt_f32_ubyte3_e32 v4, v4                                // 0000003D7604: 7E082904
	v_fma_mix_f32 v53, v53, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D7608: CC206035 14321935
	v_fma_mix_f32 v54, v54, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D7610: CC206036 14321936
	v_fma_mix_f32 v55, v55, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D7618: CC206037 14321937
	v_fma_mix_f32 v1, v1, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D7620: CC206001 14321901
	v_fma_mix_f32 v57, v57, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D7628: CC206039 14321939
	v_fma_mix_f32 v58, v58, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D7630: CC20603A 1432193A
	v_fma_mix_f32 v59, v59, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D7638: CC20603B 1432193B
	v_fma_mix_f32 v2, v2, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D7640: CC206002 14321902
	v_fma_mix_f32 v61, v61, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D7648: CC20603D 1432193D
	v_fma_mix_f32 v62, v62, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D7650: CC20603E 1432193E
	v_fma_mix_f32 v63, v63, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D7658: CC20603F 1432193F
	v_fma_mix_f32 v3, v3, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D7660: CC206003 14321903
	v_fma_mix_f32 v65, v65, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D7668: CC206041 14321941
	v_fma_mix_f32 v66, v66, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D7670: CC206042 14321942
	v_fma_mix_f32 v67, v67, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D7678: CC206043 14321943
	v_fma_mix_f32 v4, v4, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D7680: CC206004 14321904
	v_bfe_u32 v12, v53, 16, 1                                  // 0000003D7688: D610000C 02052135
	v_bfe_u32 v69, v54, 16, 1                                  // 0000003D7690: D6100045 02052136
	v_bfe_u32 v70, v55, 16, 1                                  // 0000003D7698: D6100046 02052137
	v_bfe_u32 v71, v1, 16, 1                                   // 0000003D76A0: D6100047 02052101
	v_bfe_u32 v72, v57, 16, 1                                  // 0000003D76A8: D6100048 02052139
	v_add3_u32 v12, v53, v12, 0x7fff                           // 0000003D76B0: D655000C 03FE1935 00007FFF
	v_add3_u32 v53, v54, v69, 0x7fff                           // 0000003D76BC: D6550035 03FE8B36 00007FFF
	v_add3_u32 v54, v55, v70, 0x7fff                           // 0000003D76C8: D6550036 03FE8D37 00007FFF
	.long 0x7f703989                                           // 0000003D76D4: 7F703989
	v_bfe_u32 v73, v58, 16, 1                                  // 0000003D76D8: D6100049 0205213A
	.long 0x7e12398c                                           // 0000003D76E0: 7E12398C
	v_bfe_u32 v74, v59, 16, 1                                  // 0000003D76E4: D610004A 0205213B
	v_add3_u32 v1, v1, v71, 0x7fff                             // 0000003D76EC: D6550001 03FE8F01 00007FFF
	v_add3_u32 v55, v57, v72, 0x7fff                           // 0000003D76F8: D6550037 03FE9139 00007FFF
	.long 0x7e7039b6                                           // 0000003D7704: 7E7039B6
	v_and_or_b32 v53, 0xffff0000, v53, v9                      // 0000003D7708: D6570035 04266AFF FFFF0000
	v_bfe_u32 v75, v2, 16, 1                                   // 0000003D7714: D610004B 02052102
	v_bfe_u32 v76, v61, 16, 1                                  // 0000003D771C: D610004C 0205213D
	v_add3_u32 v57, v58, v73, 0x7fff                           // 0000003D7724: D6550039 03FE933A 00007FFF
	v_add3_u32 v58, v59, v74, 0x7fff                           // 0000003D7730: D655003A 03FE953B 00007FFF
	.long 0x7e1239b7                                           // 0000003D773C: 7E1239B7
	v_and_or_b32 v1, 0xffff0000, v1, v56                       // 0000003D7740: D6570001 04E202FF FFFF0000
	.long 0x7f783989                                           // 0000003D774C: 7F783989
	v_bfe_u32 v77, v62, 16, 1                                  // 0000003D7750: D610004D 0205213E
	v_bfe_u32 v78, v63, 16, 1                                  // 0000003D7758: D610004E 0205213F
	v_add3_u32 v2, v2, v75, 0x7fff                             // 0000003D7760: D6550002 03FE9702 00007FFF
	v_add3_u32 v12, v61, v76, 0x7fff                           // 0000003D776C: D655000C 03FE993D 00007FFF
	v_and_or_b32 v57, 0xffff0000, v57, v9                      // 0000003D7778: D6570039 042672FF FFFF0000
	.long 0x7e7839ba                                           // 0000003D7784: 7E7839BA
	v_bfe_u32 v79, v3, 16, 1                                   // 0000003D7788: D610004F 02052103
	v_bfe_u32 v80, v65, 16, 1                                  // 0000003D7790: D6100050 02052141
	v_add3_u32 v59, v62, v77, 0x7fff                           // 0000003D7798: D655003B 03FE9B3E 00007FFF
	v_add3_u32 v61, v63, v78, 0x7fff                           // 0000003D77A4: D655003D 03FE9D3F 00007FFF
	.long 0x7e12398c                                           // 0000003D77B0: 7E12398C
	v_and_or_b32 v2, 0xffff0000, v2, v60                       // 0000003D77B4: D6570002 04F204FF FFFF0000
	.long 0x7f803989                                           // 0000003D77C0: 7F803989
	v_bfe_u32 v81, v66, 16, 1                                  // 0000003D77C4: D6100051 02052142
	v_bfe_u32 v82, v67, 16, 1                                  // 0000003D77CC: D6100052 02052143
	v_add3_u32 v3, v3, v79, 0x7fff                             // 0000003D77D4: D6550003 03FE9F03 00007FFF
	v_add3_u32 v55, v65, v80, 0x7fff                           // 0000003D77E0: D6550037 03FEA141 00007FFF
	.long 0x7e8039bd                                           // 0000003D77EC: 7E8039BD
	v_and_or_b32 v12, 0xffff0000, v59, v9                      // 0000003D77F0: D657000C 042676FF FFFF0000
	v_bfe_u32 v83, v4, 16, 1                                   // 0000003D77FC: D6100053 02052104
	v_add3_u32 v62, v66, v81, 0x7fff                           // 0000003D7804: D655003E 03FEA342 00007FFF
	v_add3_u32 v63, v67, v82, 0x7fff                           // 0000003D7810: D655003F 03FEA543 00007FFF
	.long 0x7e1239b7                                           // 0000003D781C: 7E1239B7
	v_and_or_b32 v3, 0xffff0000, v3, v64                       // 0000003D7820: D6570003 050206FF FFFF0000
	.long 0x7f883989                                           // 0000003D782C: 7F883989
	v_add3_u32 v4, v4, v83, 0x7fff                             // 0000003D7830: D6550004 03FEA704 00007FFF
	.long 0x7e8839bf                                           // 0000003D783C: 7E8839BF
	v_and_or_b32 v9, 0xffff0000, v62, v9                       // 0000003D7840: D6570009 04267CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2)                            // 0000003D784C: BF870002
	v_and_or_b32 v4, 0xffff0000, v4, v68                       // 0000003D7850: D6570004 051208FF FFFF0000
	s_waitcnt vmcnt(9)                                         // 0000003D785C: BF8927F7
	v_dot2_f32_bf16 v13, v13, v53, 0                           // 0000003D7860: CC1A400D 1A026B0D
	s_waitcnt vmcnt(8)                                         // 0000003D7868: BF8923F7
	v_dot2_f32_bf16 v17, v17, v53, 0                           // 0000003D786C: CC1A4011 1A026B11
	s_waitcnt vmcnt(7)                                         // 0000003D7874: BF891FF7
	v_dot2_f32_bf16 v21, v21, v53, 0                           // 0000003D7878: CC1A4015 1A026B15
	s_waitcnt vmcnt(6)                                         // 0000003D7880: BF891BF7
	v_dot2_f32_bf16 v25, v25, v53, 0                           // 0000003D7884: CC1A4019 1A026B19
	s_waitcnt vmcnt(5)                                         // 0000003D788C: BF8917F7
	v_dot2_f32_bf16 v29, v29, v53, 0                           // 0000003D7890: CC1A401D 1A026B1D
	v_dot2_f32_bf16 v13, v14, v1, v13                          // 0000003D7898: CC1A400D 1C36030E
	v_dot2_f32_bf16 v14, v18, v1, v17                          // 0000003D78A0: CC1A400E 1C460312
	v_dot2_f32_bf16 v17, v22, v1, v21                          // 0000003D78A8: CC1A4011 1C560316
	v_dot2_f32_bf16 v18, v26, v1, v25                          // 0000003D78B0: CC1A4012 1C66031A
	v_dot2_f32_bf16 v1, v30, v1, v29                           // 0000003D78B8: CC1A4001 1C76031E
	v_dot2_f32_bf16 v13, v15, v57, v13                         // 0000003D78C0: CC1A400D 1C36730F
	v_dot2_f32_bf16 v14, v19, v57, v14                         // 0000003D78C8: CC1A400E 1C3A7313
	v_dot2_f32_bf16 v15, v23, v57, v17                         // 0000003D78D0: CC1A400F 1C467317
	v_dot2_f32_bf16 v17, v27, v57, v18                         // 0000003D78D8: CC1A4011 1C4A731B
	v_dot2_f32_bf16 v1, v31, v57, v1                           // 0000003D78E0: CC1A4001 1C06731F
	v_dot2_f32_bf16 v13, v16, v2, v13                          // 0000003D78E8: CC1A400D 1C360510
	v_dot2_f32_bf16 v14, v20, v2, v14                          // 0000003D78F0: CC1A400E 1C3A0514
	v_dot2_f32_bf16 v15, v24, v2, v15                          // 0000003D78F8: CC1A400F 1C3E0518
	v_dot2_f32_bf16 v16, v28, v2, v17                          // 0000003D7900: CC1A4010 1C46051C
	v_dot2_f32_bf16 v1, v32, v2, v1                            // 0000003D7908: CC1A4001 1C060520
	s_waitcnt vmcnt(4)                                         // 0000003D7910: BF8913F7
	v_dot2_f32_bf16 v2, v33, v12, v13                          // 0000003D7914: CC1A4002 1C361921
	s_waitcnt vmcnt(3)                                         // 0000003D791C: BF890FF7
	v_dot2_f32_bf16 v13, v37, v12, v14                         // 0000003D7920: CC1A400D 1C3A1925
	s_waitcnt vmcnt(2)                                         // 0000003D7928: BF890BF7
	v_dot2_f32_bf16 v14, v41, v12, v15                         // 0000003D792C: CC1A400E 1C3E1929
	s_waitcnt vmcnt(1)                                         // 0000003D7934: BF8907F7
	v_dot2_f32_bf16 v15, v45, v12, v16                         // 0000003D7938: CC1A400F 1C42192D
	s_waitcnt vmcnt(0)                                         // 0000003D7940: BF8903F7
	v_dot2_f32_bf16 v1, v49, v12, v1                           // 0000003D7944: CC1A4001 1C061931
	v_dot2_f32_bf16 v2, v34, v3, v2                            // 0000003D794C: CC1A4002 1C0A0722
	v_dot2_f32_bf16 v12, v38, v3, v13                          // 0000003D7954: CC1A400C 1C360726
	v_dot2_f32_bf16 v13, v42, v3, v14                          // 0000003D795C: CC1A400D 1C3A072A
	v_dot2_f32_bf16 v14, v46, v3, v15                          // 0000003D7964: CC1A400E 1C3E072E
	v_dot2_f32_bf16 v1, v50, v3, v1                            // 0000003D796C: CC1A4001 1C060732
	v_dot2_f32_bf16 v2, v35, v9, v2                            // 0000003D7974: CC1A4002 1C0A1323
	v_dot2_f32_bf16 v3, v39, v9, v12                           // 0000003D797C: CC1A4003 1C321327
	v_dot2_f32_bf16 v12, v43, v9, v13                          // 0000003D7984: CC1A400C 1C36132B
	v_dot2_f32_bf16 v13, v47, v9, v14                          // 0000003D798C: CC1A400D 1C3A132F
	v_dot2_f32_bf16 v1, v51, v9, v1                            // 0000003D7994: CC1A4001 1C061333
	v_dot2_f32_bf16 v2, v36, v4, v2                            // 0000003D799C: CC1A4002 1C0A0924
	v_dot2_f32_bf16 v3, v40, v4, v3                            // 0000003D79A4: CC1A4003 1C0E0928
	v_dot2_f32_bf16 v9, v44, v4, v12                           // 0000003D79AC: CC1A4009 1C32092C
	v_dot2_f32_bf16 v12, v48, v4, v13                          // 0000003D79B4: CC1A400C 1C360930
	v_dot2_f32_bf16 v1, v52, v4, v1                            // 0000003D79BC: CC1A4001 1C060934
	v_add_f32_e32 v8, v8, v2                                   // 0000003D79C4: 06100508
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003D79C8: BF870194
	v_dual_add_f32 v10, v10, v3 :: v_dual_add_f32 v5, v5, v9   // 0000003D79CC: C908070A 0A041305
	v_dual_add_f32 v6, v6, v12 :: v_dual_add_f32 v7, v7, v1    // 0000003D79D4: C9081906 06060307
	s_or_b32 exec_lo, exec_lo, s0                              // 0000003D79DC: 8C7E007E
	.long 0xd71f0001                                           // 0000003D79E0: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000003D79E4: 020100C1
	s_mov_b32 s0, exec_lo                                      // 0000003D79E8: BE80007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003D79EC: BF870121
	v_xor_b32_e32 v2, 8, v1                                    // 0000003D79F0: 3A040288
	v_xor_b32_e32 v13, 4, v1                                   // 0000003D79F4: 3A1A0284
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000003D79F8: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 0000003D79FC: 02040501
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003D7A00: BF8700A3
	v_cmp_gt_u32_e32 vcc_lo, 32, v13                           // 0000003D7A04: 7C981AA0
	v_cndmask_b32_e32 v13, v1, v13, vcc_lo                     // 0000003D7A08: 021A1B01
	v_lshlrev_b32_e32 v13, 2, v13                              // 0000003D7A0C: 301A1A82
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003D7A10: BF870004
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000003D7A14: 30040482
	ds_bpermute_b32 v3, v2, v8                                 // 0000003D7A18: DACC0000 03000802
	s_waitcnt lgkmcnt(0)                                       // 0000003D7A20: BF89FC07
	v_add_f32_e32 v3, v8, v3                                   // 0000003D7A24: 06060708
	ds_bpermute_b32 v4, v2, v10                                // 0000003D7A28: DACC0000 04000A02
	ds_bpermute_b32 v9, v2, v5                                 // 0000003D7A30: DACC0000 09000502
	ds_bpermute_b32 v12, v2, v6                                // 0000003D7A38: DACC0000 0C000602
	ds_bpermute_b32 v2, v2, v7                                 // 0000003D7A40: DACC0000 02000702
	s_waitcnt lgkmcnt(2)                                       // 0000003D7A48: BF89FC27
	v_dual_add_f32 v4, v10, v4 :: v_dual_add_f32 v5, v5, v9    // 0000003D7A4C: C908090A 04041305
	s_waitcnt lgkmcnt(1)                                       // 0000003D7A54: BF89FC17
	v_add_f32_e32 v6, v6, v12                                  // 0000003D7A58: 060C1906
	s_waitcnt lgkmcnt(0)                                       // 0000003D7A5C: BF89FC07
	v_add_f32_e32 v2, v7, v2                                   // 0000003D7A60: 06040507
	ds_bpermute_b32 v7, v13, v3                                // 0000003D7A64: DACC0000 0700030D
	ds_bpermute_b32 v8, v13, v4                                // 0000003D7A6C: DACC0000 0800040D
	ds_bpermute_b32 v9, v13, v5                                // 0000003D7A74: DACC0000 0900050D
	ds_bpermute_b32 v10, v13, v6                               // 0000003D7A7C: DACC0000 0A00060D
	ds_bpermute_b32 v12, v13, v2                               // 0000003D7A84: DACC0000 0C00020D
	v_xor_b32_e32 v13, 2, v1                                   // 0000003D7A8C: 3A1A0282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000003D7A90: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v13                           // 0000003D7A94: 7C981AA0
	v_cndmask_b32_e32 v13, v1, v13, vcc_lo                     // 0000003D7A98: 021A1B01
	s_waitcnt lgkmcnt(3)                                       // 0000003D7A9C: BF89FC37
	v_dual_add_f32 v4, v4, v8 :: v_dual_lshlrev_b32 v13, 2, v13// 0000003D7AA0: C9221104 040C1A82
	s_waitcnt lgkmcnt(1)                                       // 0000003D7AA8: BF89FC17
	v_dual_add_f32 v3, v3, v7 :: v_dual_add_f32 v6, v6, v10    // 0000003D7AAC: C9080F03 03061506
	s_waitcnt lgkmcnt(0)                                       // 0000003D7AB4: BF89FC07
	v_dual_add_f32 v5, v5, v9 :: v_dual_add_f32 v2, v2, v12    // 0000003D7AB8: C9081305 05021902
	ds_bpermute_b32 v8, v13, v4                                // 0000003D7AC0: DACC0000 0800040D
	ds_bpermute_b32 v7, v13, v3                                // 0000003D7AC8: DACC0000 0700030D
	ds_bpermute_b32 v10, v13, v6                               // 0000003D7AD0: DACC0000 0A00060D
	ds_bpermute_b32 v9, v13, v5                                // 0000003D7AD8: DACC0000 0900050D
	ds_bpermute_b32 v12, v13, v2                               // 0000003D7AE0: DACC0000 0C00020D
	v_xor_b32_e32 v13, 1, v1                                   // 0000003D7AE8: 3A1A0281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000003D7AEC: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v13                           // 0000003D7AF0: 7C981AA0
	s_waitcnt lgkmcnt(4)                                       // 0000003D7AF4: BF89FC47
	v_dual_cndmask_b32 v1, v1, v13 :: v_dual_add_f32 v8, v4, v8// 0000003D7AF8: CA481B01 01081104
	v_lshlrev_b32_e32 v13, 2, v1                               // 0000003D7B00: 301A0282
	s_waitcnt lgkmcnt(1)                                       // 0000003D7B04: BF89FC17
	v_dual_add_f32 v7, v3, v7 :: v_dual_add_f32 v4, v5, v9     // 0000003D7B08: C9080F03 07041305
	v_add_f32_e32 v3, v6, v10                                  // 0000003D7B10: 06061506
	s_waitcnt lgkmcnt(0)                                       // 0000003D7B14: BF89FC07
	v_add_f32_e32 v1, v2, v12                                  // 0000003D7B18: 06021902
	ds_bpermute_b32 v10, v13, v8                               // 0000003D7B1C: DACC0000 0A00080D
	ds_bpermute_b32 v9, v13, v7                                // 0000003D7B24: DACC0000 0900070D
	ds_bpermute_b32 v6, v13, v4                                // 0000003D7B2C: DACC0000 0600040D
	ds_bpermute_b32 v5, v13, v3                                // 0000003D7B34: DACC0000 0500030D
	ds_bpermute_b32 v2, v13, v1                                // 0000003D7B3C: DACC0000 0200010D
	v_cmpx_eq_u32_e32 0, v11                                   // 0000003D7B44: 7D941680
	s_cbranch_execz 46                                         // 0000003D7B48: BFA5002E <_ZN7halogen12_GLOBAL__N_18k_hcup8wILi5EEEvPKhPKtS5_PtPf+0xc04>
	s_waitcnt lgkmcnt(3)                                       // 0000003D7B4C: BF89FC37
	v_dual_add_f32 v8, v8, v10 :: v_dual_add_f32 v7, v7, v9    // 0000003D7B50: C9081508 08061307
	s_waitcnt lgkmcnt(1)                                       // 0000003D7B58: BF89FC17
	v_dual_add_f32 v4, v4, v6 :: v_dual_add_f32 v3, v3, v5     // 0000003D7B5C: C9080D04 04020B03
	.long 0x7f0c3880                                           // 0000003D7B64: 7F0C3880
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000003D7B68: BF870223
	.long 0x7e0c3988                                           // 0000003D7B6C: 7E0C3988
	.long 0x7e123987                                           // 0000003D7B70: 7E123987
	.long 0x7e0a3984                                           // 0000003D7B74: 7E0A3984
	v_lshrrev_b32_e32 v10, 4, v0                               // 0000003D7B78: 32140084
	.long 0x7f0a3986                                           // 0000003D7B7C: 7F0A3986
	.long 0x7f123986                                           // 0000003D7B80: 7F123986
	v_and_b32_e32 v11, 1, v6                                   // 0000003D7B84: 36160C81
	.long 0x7e0c3983                                           // 0000003D7B88: 7E0C3983
	s_waitcnt lgkmcnt(0)                                       // 0000003D7B8C: BF89FC07
	v_dual_add_f32 v12, v1, v2 :: v_dual_and_b32 v5, 1, v5     // 0000003D7B90: C9240501 0C040A81
	v_and_b32_e32 v9, 1, v9                                    // 0000003D7B98: 36121281
	v_add3_u32 v1, v8, v11, 0x7fff                             // 0000003D7B9C: D6550001 03FE1708 00007FFF
	v_and_b32_e32 v2, 1, v6                                    // 0000003D7BA8: 36040C81
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003D7BAC: BF870004
	v_bfe_u32 v6, v12, 16, 1                                   // 0000003D7BB0: D6100006 0205210C
	v_add3_u32 v4, v4, v5, 0x7fff                              // 0000003D7BB8: D6550004 03FE0B04 00007FFF
	v_add3_u32 v5, v7, v9, 0x7fff                              // 0000003D7BC4: D6550005 03FE1307 00007FFF
	v_mul_u32_u24_e32 v10, 10, v10                             // 0000003D7BD0: 1614148A
	v_add3_u32 v2, v3, v2, 0x7fff                              // 0000003D7BD4: D6550002 03FE0503 00007FFF
	v_add3_u32 v3, v12, v6, 0x7fff                             // 0000003D7BE0: D6550003 03FE0D0C 00007FFF
	.long 0x7e043984                                           // 0000003D7BEC: 7E043984
	.long 0x7e023985                                           // 0000003D7BF0: 7E023985
	ds_store_b64 v10, v[1:2]                                   // 0000003D7BF4: D9340000 0000010A
	ds_store_b16_d16_hi v10, v3 offset:8                       // 0000003D7BFC: DA840008 0000030A
	s_or_b32 exec_lo, exec_lo, s0                              // 0000003D7C04: 8C7E007E
	s_waitcnt lgkmcnt(0)                                       // 0000003D7C08: BF89FC07
	s_barrier                                                  // 0000003D7C0C: BFBD0000
	buffer_gl0_inv                                             // 0000003D7C10: E0AC0000 00000000
	s_mov_b32 s0, exec_lo                                      // 0000003D7C18: BE80007E
	v_cmpx_gt_u32_e32 20, v0                                   // 0000003D7C1C: 7D980094
	s_cbranch_execz 260                                        // 0000003D7C20: BFA50104 <_ZN7halogen12_GLOBAL__N_18k_hcup8wILi5EEEvPKhPKtS5_PtPf+0x1034>
	.long 0xd7054000                                           // 0000003D7C24: D7054000
	v_cndmask_b32_e32 v1, 0xcd, v0, vcc_lo                     // 0000003D7C28: 020200FF 000000CD
	.long 0x7f143880                                           // 0000003D7C30: 7F143880
	s_cmp_eq_u64 s[4:5], 0                                     // 0000003D7C34: BF108004
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003D7C38: BF870092
	.long 0xd739100a                                           // 0000003D7C3C: D739100A
	v_cndmask_b32_e32 v1, 10, v0, vcc_lo                       // 0000003D7C40: 0202008A
	.long 0xd7054000                                           // 0000003D7C44: D7054000
	v_cndmask_b32_e32 v0, v10, v133, vcc_lo                    // 0000003D7C48: 02010B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003D7C4C: BF870121
	.long 0xd7041001                                           // 0000003D7C50: D7041001
	v_cndmask_b32_e32 v1, v0, v0, vcc_lo                       // 0000003D7C54: 02020100
	v_add_nc_u32_e32 v0, s2, v10                               // 0000003D7C58: 4A001402
	v_and_b32_e32 v11, 0xff, v1                                // 0000003D7C5C: 361602FF 000000FF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003D7C64: BF870112
	v_ashrrev_i32_e32 v1, 31, v0                               // 0000003D7C68: 3402009F
	v_mad_u64_u32 v[2:3], null, 0x5000, v11, s[8:9]            // 0000003D7C6C: D6FE7C02 002216FF 00005000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003D7C78: BF870092
	.long 0xd73c0004                                           // 0000003D7C7C: D73C0004
	v_cndmask_b32_e32 v1, 1, v0, vcc_lo                        // 0000003D7C80: 02020081
	.long 0xd7006a02                                           // 0000003D7C84: D7006A02
	v_cndmask_b32_e32 v1, v2, v4, vcc_lo                       // 0000003D7C88: 02020902
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003D7C8C: BF870111
	v_add_co_ci_u32_e64 v3, null, v3, v5, vcc_lo               // 0000003D7C90: D5207C03 01AA0B03
	.long 0xd7006a04                                           // 0000003D7C98: D7006A04
	v_cndmask_b32_e32 v1, 0x2000, v2, vcc_lo                   // 0000003D7C9C: 020204FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003D7CA4: BF8700A1
	v_add_co_ci_u32_e64 v5, null, 0, v3, vcc_lo                // 0000003D7CA8: D5207C05 01AA0680
	.long 0xd7006a06                                           // 0000003D7CB0: D7006A06
	v_cndmask_b32_e32 v1, 0x3000, v2, vcc_lo                   // 0000003D7CB4: 020204FF 00003000
	v_add_co_ci_u32_e64 v7, null, 0, v3, vcc_lo                // 0000003D7CBC: D5207C07 01AA0680
	.long 0xd7006a08                                           // 0000003D7CC4: D7006A08
	v_cndmask_b32_e32 v1, 0x1000, v2, vcc_lo                   // 0000003D7CC8: 020204FF 00001000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003D7CD0: BF870001
	v_add_co_ci_u32_e64 v9, null, 0, v3, vcc_lo                // 0000003D7CD4: D5207C09 01AA0680
	s_clause 0x3                                               // 0000003D7CDC: BF850003
	global_load_u16 v4, v[4:5], off offset:2048                // 0000003D7CE0: DC4A0800 047C0004
	global_load_u16 v5, v[6:7], off offset:3072                // 0000003D7CE8: DC4A0C00 057C0006
	global_load_u16 v2, v[2:3], off                            // 0000003D7CF0: DC4A0000 027C0002
	global_load_u16 v3, v[8:9], off offset:1024                // 0000003D7CF8: DC4A0400 037C0008
	v_mul_u32_u24_e32 v6, 40, v10                              // 0000003D7D00: 160C14A8
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003D7D04: BF870001
	v_lshl_add_u32 v6, v11, 1, v6                              // 0000003D7D08: D6460006 0419030B
	ds_load_u16 v7, v6                                         // 0000003D7D10: D8F00000 07000006
	ds_load_u16 v8, v6 offset:10                               // 0000003D7D18: D8F0000A 08000006
	ds_load_u16 v9, v6 offset:20                               // 0000003D7D20: D8F00014 09000006
	ds_load_u16 v6, v6 offset:30                               // 0000003D7D28: D8F0001E 06000006
	s_waitcnt lgkmcnt(0)                                       // 0000003D7D30: BF89FC07
	v_lshlrev_b32_e32 v6, 16, v6                               // 0000003D7D34: 300C0C90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003D7D38: BF870091
	v_dual_mul_f32 v6, 0xbfb8aa3b, v6 :: v_dual_lshlrev_b32 v9, 16, v9// 0000003D7D3C: C8E20CFF 06081290 BFB8AA3B
	v_dual_mul_f32 v9, 0xbfb8aa3b, v9 :: v_dual_lshlrev_b32 v8, 16, v8// 0000003D7D48: C8E212FF 09081090 BFB8AA3B
	v_lshlrev_b32_e32 v7, 16, v7                               // 0000003D7D54: 300E0E90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003D7D58: BF870113
	v_exp_f32_e32 v6, v6                                       // 0000003D7D5C: 7E0C4B06
	v_mul_f32_e32 v8, 0xbfb8aa3b, v8                           // 0000003D7D60: 101010FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003D7D68: BF870113
	v_exp_f32_e32 v9, v9                                       // 0000003D7D6C: 7E124B09
	v_mul_f32_e32 v7, 0xbfb8aa3b, v7                           // 0000003D7D70: 100E0EFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003D7D78: BF870092
	v_exp_f32_e32 v8, v8                                       // 0000003D7D7C: 7E104B08
	v_exp_f32_e32 v7, v7                                       // 0000003D7D80: 7E0E4B07
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003D7D84: BF870097
	v_dual_add_f32 v6, 1.0, v6 :: v_dual_add_f32 v9, 1.0, v9   // 0000003D7D88: C9080CF2 060812F2
	v_div_scale_f32 v14, null, v6, v6, 1.0                     // 0000003D7D90: D6FC7C0E 03CA0D06
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003D7D98: BF870196
	v_add_f32_e32 v8, 1.0, v8                                  // 0000003D7D9C: 061010F2
	v_div_scale_f32 v13, null, v9, v9, 1.0                     // 0000003D7DA0: D6FC7C0D 03CA1309
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000003D7DA8: BF870005
	v_add_f32_e32 v7, 1.0, v7                                  // 0000003D7DAC: 060E0EF2
	v_div_scale_f32 v24, s1, 1.0, v9, 1.0                      // 0000003D7DB0: D6FC0118 03CA12F2
	v_rcp_f32_e32 v18, v14                                     // 0000003D7DB8: 7E24550E
	v_div_scale_f32 v12, null, v8, v8, 1.0                     // 0000003D7DBC: D6FC7C0C 03CA1108
	v_rcp_f32_e32 v17, v13                                     // 0000003D7DC4: 7E22550D
	v_div_scale_f32 v10, null, v7, v7, 1.0                     // 0000003D7DC8: D6FC7C0A 03CA0F07
	v_div_scale_f32 v19, vcc_lo, 1.0, v7, 1.0                  // 0000003D7DD0: D6FC6A13 03CA0EF2
	v_div_scale_f32 v20, s0, 1.0, v8, 1.0                      // 0000003D7DD8: D6FC0014 03CA10F2
	v_rcp_f32_e32 v16, v12                                     // 0000003D7DE0: 7E20550C
	v_mad_u64_u32 v[0:1], null, 0xa00, v11, v[0:1]             // 0000003D7DE4: D6FE7C00 040216FF 00000A00
	v_rcp_f32_e32 v15, v10                                     // 0000003D7DF0: 7E1E550A
	v_fma_f32 v25, -v14, v18, 1.0                              // 0000003D7DF4: D6130019 23CA250E
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003D7DFC: BF870117
	v_fma_f32 v23, -v13, v17, 1.0                              // 0000003D7E00: D6130017 23CA230D
	v_fmac_f32_e32 v18, v25, v18                               // 0000003D7E08: 56242519
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003D7E0C: BF870196
	v_fma_f32 v22, -v12, v16, 1.0                              // 0000003D7E10: D6130016 23CA210C
	v_fmac_f32_e32 v17, v23, v17                               // 0000003D7E18: 56222317
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003D7E1C: BF870095
	v_fma_f32 v21, -v10, v15, 1.0                              // 0000003D7E20: D6130015 23CA1F0A
	v_dual_fmac_f32 v16, v22, v16 :: v_dual_fmac_f32 v15, v21, v15// 0000003D7E28: C8002116 100E1F15
	v_div_scale_f32 v21, s2, 1.0, v6, 1.0                      // 0000003D7E30: D6FC0215 03CA0CF2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003D7E38: BF870194
	v_mul_f32_e32 v25, v24, v17                                // 0000003D7E3C: 10322318
	v_dual_mul_f32 v23, v20, v16 :: v_dual_mul_f32 v22, v19, v15// 0000003D7E40: C8C62114 17161F13
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003D7E48: BF870193
	v_mul_f32_e32 v26, v21, v18                                // 0000003D7E4C: 10342515
	v_fma_f32 v29, -v13, v25, v24                              // 0000003D7E50: D613001D 2462330D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003D7E58: BF870213
	v_fma_f32 v28, -v12, v23, v20                              // 0000003D7E5C: D613001C 24522F0C
	v_fma_f32 v27, -v10, v22, v19                              // 0000003D7E64: D613001B 244E2D0A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003D7E6C: BF870214
	v_fma_f32 v30, -v14, v26, v21                              // 0000003D7E70: D613001E 2456350E
	v_fmac_f32_e32 v25, v29, v17                               // 0000003D7E78: 5632231D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003D7E7C: BF870193
	v_dual_fmac_f32 v23, v28, v16 :: v_dual_fmac_f32 v22, v27, v15// 0000003D7E80: C800211C 17161F1B
	v_fmac_f32_e32 v26, v30, v18                               // 0000003D7E88: 5634251E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003D7E8C: BF870193
	v_fma_f32 v13, -v13, v25, v24                              // 0000003D7E90: D613000D 2462330D
	v_fma_f32 v12, -v12, v23, v20                              // 0000003D7E98: D613000C 24522F0C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003D7EA0: BF870214
	v_fma_f32 v10, -v10, v22, v19                              // 0000003D7EA4: D613000A 244E2D0A
	v_fma_f32 v14, -v14, v26, v21                              // 0000003D7EAC: D613000E 2456350E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000003D7EB4: BF870142
	v_div_fmas_f32 v10, v10, v15, v22                          // 0000003D7EB8: D637000A 045A1F0A
	s_mov_b32 vcc_lo, s0                                       // 0000003D7EC0: BEEA0000
	v_div_fmas_f32 v12, v12, v16, v23                          // 0000003D7EC4: D637000C 045E210C
	s_mov_b32 vcc_lo, s1                                       // 0000003D7ECC: BEEA0001
	v_div_fixup_f32 v7, v10, v7, 1.0                           // 0000003D7ED0: D6270007 03CA0F0A
	v_div_fmas_f32 v10, v13, v17, v25                          // 0000003D7ED8: D637000A 0466230D
	s_mov_b32 vcc_lo, s2                                       // 0000003D7EE0: BEEA0002
	v_div_fixup_f32 v8, v12, v8, 1.0                           // 0000003D7EE4: D6270008 03CA110C
	v_div_fmas_f32 v13, v14, v18, v26                          // 0000003D7EEC: D637000D 046A250E
	v_bfe_u32 v12, v7, 16, 1                                   // 0000003D7EF4: D610000C 02052107
	v_div_fixup_f32 v9, v10, v9, 1.0                           // 0000003D7EFC: D6270009 03CA130A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003D7F04: BF870214
	v_bfe_u32 v10, v8, 16, 1                                   // 0000003D7F08: D610000A 02052108
	v_div_fixup_f32 v6, v13, v6, 1.0                           // 0000003D7F10: D6270006 03CA0D0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003D7F18: BF870214
	v_add3_u32 v7, v7, v12, 0x7fff                             // 0000003D7F1C: D6550007 03FE1907 00007FFF
	v_bfe_u32 v12, v9, 16, 1                                   // 0000003D7F28: D610000C 02052109
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003D7F30: BF870214
	v_add3_u32 v8, v8, v10, 0x7fff                             // 0000003D7F34: D6550008 03FE1508 00007FFF
	v_bfe_u32 v10, v6, 16, 1                                   // 0000003D7F40: D610000A 02052106
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003D7F48: BF870193
	v_add3_u32 v9, v9, v12, 0x7fff                             // 0000003D7F4C: D6550009 03FE1909 00007FFF
	v_and_b32_e32 v8, 0xffff0000, v8                           // 0000003D7F58: 361010FF FFFF0000
	s_delay_alu instid0(VALU_DEP_3)                            // 0000003D7F60: BF870003
	v_add3_u32 v6, v6, v10, 0x7fff                             // 0000003D7F64: D6550006 03FE1506 00007FFF
	s_waitcnt vmcnt(3)                                         // 0000003D7F70: BF890FF7
	v_lshlrev_b32_e32 v4, 16, v4                               // 0000003D7F74: 30080890
	s_waitcnt vmcnt(2)                                         // 0000003D7F78: BF890BF7
	v_lshlrev_b32_e32 v5, 16, v5                               // 0000003D7F7C: 300A0A90
	s_waitcnt vmcnt(1)                                         // 0000003D7F80: BF8907F7
	v_lshlrev_b32_e32 v2, 16, v2                               // 0000003D7F84: 30040490
	s_waitcnt vmcnt(0)                                         // 0000003D7F88: BF8903F7
	v_lshlrev_b32_e32 v3, 16, v3                               // 0000003D7F8C: 30060690
	v_and_b32_e32 v7, 0xffff0000, v7                           // 0000003D7F90: 360E0EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003D7F98: BF870091
	v_fma_f32 v2, v2, v7, 0                                    // 0000003D7F9C: D6130002 02020F02
	v_dual_fmac_f32 v2, v3, v8 :: v_dual_and_b32 v3, 0xffff0000, v6// 0000003D7FA4: C8241103 02020CFF FFFF0000
	v_and_b32_e32 v7, 0xffff0000, v9                           // 0000003D7FB0: 360E12FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003D7FB8: BF870091
	v_fmac_f32_e32 v2, v4, v7                                  // 0000003D7FBC: 56040F04
	v_fmac_f32_e32 v2, v5, v3                                  // 0000003D7FC0: 56040705
	.long 0xd73c0003                                           // 0000003D7FC4: D73C0003
	v_cndmask_b32_e32 v1, 1, v0, vcc_lo                        // 0000003D7FC8: 02020081
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003D7FCC: BF870112
	v_mul_f32_e32 v2, 0x3e800000, v2                           // 0000003D7FD0: 100404FF 3E800000
	.long 0xd7006a03                                           // 0000003D7FD8: D7006A03
	v_cndmask_b32_e32 v1, s10, v3, vcc_lo                      // 0000003D7FDC: 0202060A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003D7FE0: BF870191
	v_add_co_ci_u32_e64 v4, null, s11, v4, vcc_lo              // 0000003D7FE4: D5207C04 01AA080B
	v_bfe_u32 v5, v2, 16, 1                                    // 0000003D7FEC: D6100005 02052102
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003D7FF4: BF870001
	v_add3_u32 v5, v2, v5, 0x7fff                              // 0000003D7FF8: D6550005 03FE0B02 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off                    // 0000003D8004: DC960000 007C0503
	s_cbranch_scc1 9                                           // 0000003D800C: BFA20009 <_ZN7halogen12_GLOBAL__N_18k_hcup8wILi5EEEvPKhPKtS5_PtPf+0x1034>
	.long 0xd73c0000                                           // 0000003D8010: D73C0000
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 0000003D8014: 02020082
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003D8018: BF870091
	.long 0xd7006a00                                           // 0000003D801C: D7006A00
	v_cndmask_b32_e32 v1, s4, v0, vcc_lo                       // 0000003D8020: 02020004
	v_add_co_ci_u32_e64 v1, null, s5, v1, vcc_lo               // 0000003D8024: D5207C01 01AA0205
	global_store_b32 v[0:1], v2, off                           // 0000003D802C: DC6A0000 007C0200
	s_endpgm                                                   // 0000003D8034: BFB00000
		...

