000000000071fe00 <_ZN7halogen12_GLOBAL__N_16k_lq6kILi8ELi32ELi2ELb1EEEvPKhPKtPvll>:
; _ZN7halogen12_GLOBAL__N_16k_lq6kILi8ELi32ELi2ELb1EEEvPKhPKtPvll():
	s_load_b256 s[4:11], s[0:1], null                          // 00000071FE00: F40C0100 F8000000
	s_mov_b32 s3, 0                                            // 00000071FE08: BE830080
	v_bfe_u32 v5, v0, 5, 1                                     // 00000071FE0C: D6100005 02050B00
	s_lshl_b64 s[14:15], s[2:3], 2                             // 00000071FE14: 848E8202
	v_dual_mov_b32 v10, 0 :: v_dual_and_b32 v7, 31, v0         // 00000071FE18: CA240080 0A06009F
	v_dual_mov_b32 v11, 0 :: v_dual_mov_b32 v12, 0             // 00000071FE20: CA100080 0B0C0080
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v8, 0              // 00000071FE28: CA100080 0F080080
	v_mov_b32_e32 v17, 0                                       // 00000071FE30: 7E220280
	v_lshrrev_b32_e32 v6, 6, v0                                // 00000071FE34: 320C0086
	v_mov_b32_e32 v16, 0                                       // 00000071FE38: 7E200280
	s_waitcnt lgkmcnt(0)                                       // 00000071FE3C: BF89FC07
	s_ashr_i32 s12, s11, 31                                    // 00000071FE40: 860C9F0B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000071FE44: BF870499
	s_lshr_b32 s12, s12, 28                                    // 00000071FE48: 850C9C0C
	s_add_u32 s12, s10, s12                                    // 00000071FE4C: 800C0C0A
	s_addc_u32 s13, s11, 0                                     // 00000071FE50: 820D800B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000071FE54: BF870499
	s_lshr_b64 s[16:17], s[12:13], 4                           // 00000071FE58: 8590840C
	s_add_i32 s2, s16, 1                                       // 00000071FE5C: 81028110
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000071FE60: BF870499
	s_lshr_b32 s12, s2, 31                                     // 00000071FE64: 850C9F02
	s_add_i32 s2, s2, s12                                      // 00000071FE68: 81020C02
	s_load_b64 s[12:13], s[0:1], 0x20                          // 00000071FE6C: F4040300 F8000020
	s_ashr_i32 s2, s2, 1                                       // 00000071FE74: 86028102
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071FE78: BF870099
	.long 0xd72c0001                                           // 00000071FE7C: D72C0001
	v_cndmask_b32_e32 v1, s2, v5, vcc_lo                       // 00000071FE80: 02020A02
	v_dual_mov_b32 v9, 0 :: v_dual_add_nc_u32 v2, s2, v1       // 00000071FE84: CA200080 09020202
	v_add_nc_u32_e32 v13, v1, v7                               // 00000071FE8C: 4A1A0F01
	s_mov_b32 s2, exec_lo                                      // 00000071FE90: BE82007E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071FE94: BF870092
	v_min_i32_e32 v14, s16, v2                                 // 00000071FE98: 221C0410
	.long 0xd4c1007e                                           // 00000071FE9C: D4C1007E
	v_cndmask_b32_e32 v1, v13, v14, vcc_lo                     // 00000071FEA0: 02021D0D
	s_cbranch_execz 668                                        // 00000071FEA4: BFA5029C <_ZN7halogen12_GLOBAL__N_16k_lq6kILi8ELi32ELi2ELb1EEEvPKhPKtPvll+0xb18>
	.long 0xd7000001                                           // 00000071FEA8: D7000001
	v_cndmask_b32_e32 v1, s14, v6, vcc_lo                      // 00000071FEAC: 02020C0E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000071FEB0: BF870001
	v_add_co_ci_u32_e64 v2, null, s15, 0, s0                   // 00000071FEB4: D5207C02 0001000F
	s_ashr_i32 s0, s11, 31                                     // 00000071FEBC: 86009F0B
	v_dual_mov_b32 v8, 0 :: v_dual_lshlrev_b32 v3, 4, v13      // 00000071FEC0: CA220080 08021A84
	s_lshr_b32 s0, s0, 24                                      // 00000071FEC8: 85009800
	s_waitcnt lgkmcnt(0)                                       // 00000071FECC: BF89FC07
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 00000071FED0: 7CA8020C
	s_add_u32 s0, s10, s0                                      // 00000071FED4: 8000000A
	s_addc_u32 s1, s11, 0                                      // 00000071FED8: 8201800B
	v_dual_mov_b32 v17, 0 :: v_dual_mov_b32 v16, 0             // 00000071FEDC: CA100080 11100080
	s_ashr_i64 s[0:1], s[0:1], 8                               // 00000071FEE4: 86808800
	v_dual_cndmask_b32 v2, 0, v2 :: v_dual_cndmask_b32 v1, 0, v1// 00000071FEE8: CA520480 02000280
	s_mulk_i32 s1, 0xd2                                        // 00000071FEF0: B80100D2
	s_mul_hi_u32 s16, s0, 0xd2                                 // 00000071FEF4: 9690FF00 000000D2
	s_mulk_i32 s0, 0xd2                                        // 00000071FEFC: B80000D2
	s_add_i32 s16, s16, s1                                     // 00000071FF00: 81100110
	.long 0xd72c0009                                           // 00000071FF04: D72C0009
	v_cndmask_b32_e32 v1, s0, v2, vcc_lo                       // 00000071FF08: 02020400
	.long 0xd72c0004                                           // 00000071FF0C: D72C0004
	v_cndmask_b32_e32 v1, s16, v1, vcc_lo                      // 00000071FF10: 02020210
	v_mad_u64_u32 v[1:2], null, s0, v1, s[4:5]                 // 00000071FF14: D6FE7C01 00120200
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v12, 0             // 00000071FF1C: CA100080 0F0C0080
	v_dual_mov_b32 v11, 0 :: v_dual_mov_b32 v10, 0             // 00000071FF24: CA100080 0B0A0080
	s_mul_i32 s4, s11, 6                                       // 00000071FF2C: 9604860B
	s_mul_hi_u32 s5, s10, 6                                    // 00000071FF30: 9685860A
	s_lshl_b64 s[0:1], s[10:11], 2                             // 00000071FF34: 8480820A
	s_delay_alu instid0(VALU_DEP_3)                            // 00000071FF38: BF870003
	v_add3_u32 v2, v4, v2, v9                                  // 00000071FF3C: D6550002 04260504
	v_mov_b32_e32 v9, 0                                        // 00000071FF44: 7E120280
	s_add_i32 s16, s5, s4                                      // 00000071FF48: 81100405
	s_mul_i32 s17, s10, 6                                      // 00000071FF4C: 9611860A
	s_lshl_b64 s[4:5], s[10:11], 1                             // 00000071FF50: 8484810A
	v_ashrrev_i32_e32 v4, 4, v13                               // 00000071FF54: 34081A84
	v_bfe_u32 v26, v13, 3, 1                                   // 00000071FF58: D610001A 0205070D
	v_and_b32_e32 v21, 32, v3                                  // 00000071FF60: 362A06A0
	v_and_b32_e32 v27, 16, v3                                  // 00000071FF64: 36360690
	v_and_b32_e32 v30, 15, v13                                 // 00000071FF68: 363C1A8F
	.long 0xd72c0004                                           // 00000071FF6C: D72C0004
	v_cndmask_b32_e32 v1, 0xd2, v4, vcc_lo                     // 00000071FF70: 020208FF 000000D2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000071FF78: BF8701B1
	v_ashrrev_i32_e32 v19, 31, v4                              // 00000071FF7C: 3426089F
	.long 0xd7006a12                                           // 00000071FF80: D7006A12
	v_cndmask_b32_e32 v1, v1, v4, vcc_lo                       // 00000071FF84: 02020901
	v_lshlrev_b32_e32 v4, 6, v26                               // 00000071FF88: 30083486
	v_add_co_ci_u32_e64 v19, null, v2, v19, vcc_lo             // 00000071FF8C: D5207C13 01AA2702
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071FF94: BF870092
	.long 0xd7006a04                                           // 00000071FF98: D7006A04
	v_cndmask_b32_e32 v1, v18, v4, vcc_lo                      // 00000071FF9C: 02020912
	v_add_co_ci_u32_e64 v20, null, 0, v19, vcc_lo              // 00000071FFA0: D5207C14 01AA2680
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071FFA8: BF870092
	.long 0xd7006a04                                           // 00000071FFAC: D7006A04
	v_cndmask_b32_e32 v1, v4, v21, vcc_lo                      // 00000071FFB0: 02022B04
	v_add_co_ci_u32_e64 v21, null, 0, v20, vcc_lo              // 00000071FFB4: D5207C15 01AA2880
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000071FFBC: BF8701A2
	.long 0xd7006a14                                           // 00000071FFC0: D7006A14
	v_cndmask_b32_e32 v1, v4, v27, vcc_lo                      // 00000071FFC4: 02023704
	v_lshlrev_b32_e32 v4, 5, v26                               // 00000071FFC8: 30083485
	v_add_co_ci_u32_e64 v21, null, 0, v21, vcc_lo              // 00000071FFCC: D5207C15 01AA2A80
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000071FFD4: BF8700C2
	.long 0xd7006a04                                           // 00000071FFD8: D7006A04
	v_cndmask_b32_e32 v1, v18, v4, vcc_lo                      // 00000071FFDC: 02020912
	global_load_b128 v[22:25], v[20:21], off                   // 00000071FFE0: DC5E0000 167C0014
	v_add_co_ci_u32_e64 v21, null, 0, v19, vcc_lo              // 00000071FFE8: D5207C15 01AA2680
	.long 0xd7006a14                                           // 00000071FFF0: D7006A14
	v_cndmask_b32_e32 v1, v4, v27, vcc_lo                      // 00000071FFF4: 02023704
	v_add_co_ci_u32_e64 v21, null, 0, v21, vcc_lo              // 00000071FFF8: D5207C15 01AA2A80
	global_load_b128 v[26:29], v[20:21], off offset:128        // 000000720000: DC5E0080 1A7C0014
	.long 0xd7006a14                                           // 000000720008: D7006A14
	v_cndmask_b32_e32 v1, v18, v30, vcc_lo                     // 00000072000C: 02023D12
	s_delay_alu instid0(VALU_DEP_1)                            // 000000720010: BF870001
	v_add_co_ci_u32_e64 v21, null, 0, v19, vcc_lo              // 000000720014: D5207C15 01AA2680
	s_clause 0x1                                               // 00000072001C: BF850001
	global_load_d16_b16 v18, v[18:19], off offset:208          // 000000720020: DC8200D0 127C0012
	global_load_i8 v4, v[20:21], off offset:192                // 000000720028: DC4600C0 047C0014
	s_waitcnt vmcnt(0)                                         // 000000720030: BF8903F7
	v_cvt_f32_i32_e32 v4, v4                                   // 000000720034: 7E080B04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000720038: BF8701C1
	v_fma_mix_f32 v4, v18, v4, neg(0) op_sel_hi:[1,0,0]        // 00000072003C: CC200004 8A020912
	v_and_b32_e32 v31, 6, v13                                  // 000000720044: 363E1A86
	v_and_b32_e32 v30, 4, v13                                  // 000000720048: 363C1A84
	v_add_nc_u32_e32 v13, 32, v13                              // 00000072004C: 4A1A1AA0
	v_lshrrev_b32_e32 v19, v31, v26                            // 000000720050: 3226351F
	s_delay_alu instid0(VALU_DEP_3)                            // 000000720054: BF870003
	v_bfe_u32 v18, v22, v30, 4                                 // 000000720058: D6100012 02123D16
	v_or_b32_e32 v33, 8, v31                                   // 000000720060: 38423E88
	v_or_b32_e32 v32, 8, v30                                   // 000000720064: 38403C88
	v_or_b32_e32 v35, 16, v31                                  // 000000720068: 38463E90
	v_lshlrev_b32_e32 v19, 4, v19                              // 00000072006C: 30262684
	v_or_b32_e32 v34, 16, v30                                  // 000000720070: 38443C90
	v_or_b32_e32 v36, 24, v30                                  // 000000720074: 38483C98
	v_or_b32_e32 v37, 24, v31                                  // 000000720078: 384A3E98
	v_lshrrev_b32_e32 v21, v35, v26                            // 00000072007C: 322A3523
	v_and_or_b32 v18, v19, 48, v18                             // 000000720080: D6570012 04496113
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000720088: BF870112
	v_lshlrev_b32_e32 v21, 4, v21                              // 00000072008C: 302A2A84
	v_subrev_nc_u32_e32 v18, 32, v18                           // 000000720090: 4E2424A0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000720094: BF870091
	v_cvt_f32_i32_e32 v18, v18                                 // 000000720098: 7E240B12
	v_mul_f32_e32 v18, v4, v18                                 // 00000072009C: 10242504
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007200A0: BF870091
	v_bfe_u32 v19, v18, 16, 1                                  // 0000007200A4: D6100013 02052112
	v_add3_u32 v20, v18, v19, 0x7fff                           // 0000007200AC: D6550014 03FE2712 00007FFF
	v_lshrrev_b32_e32 v19, v33, v26                            // 0000007200B8: 32263521
	v_bfe_u32 v18, v22, v32, 4                                 // 0000007200BC: D6100012 02124116
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007200C4: BF870092
	v_lshlrev_b32_e32 v19, 4, v19                              // 0000007200C8: 30262684
	v_and_or_b32 v18, v19, 48, v18                             // 0000007200CC: D6570012 04496113
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007200D4: BF870091
	v_subrev_nc_u32_e32 v18, 32, v18                           // 0000007200D8: 4E2424A0
	v_cvt_f32_i32_e32 v18, v18                                 // 0000007200DC: 7E240B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007200E0: BF870091
	v_mul_f32_e32 v18, v4, v18                                 // 0000007200E4: 10242504
	v_bfe_u32 v19, v18, 16, 1                                  // 0000007200E8: D6100013 02052112
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000007200F0: BF870131
	v_add3_u32 v18, v18, v19, 0x7fff                           // 0000007200F4: D6550012 03FE2712 00007FFF
	v_bfe_u32 v19, v22, v34, 4                                 // 000000720100: D6100013 02124516
	.long 0x7e243994                                           // 000000720108: 7E243994
	v_and_or_b32 v19, v21, 48, v19                             // 00000072010C: D6570013 044D6115
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000720114: BF870091
	v_subrev_nc_u32_e32 v19, 32, v19                           // 000000720118: 4E2626A0
	v_cvt_f32_i32_e32 v19, v19                                 // 00000072011C: 7E260B13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000720120: BF870091
	v_mul_f32_e32 v19, v4, v19                                 // 000000720124: 10262704
	v_bfe_u32 v21, v19, 16, 1                                  // 000000720128: D6100015 02052113
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000720130: BF870141
	v_add3_u32 v21, v19, v21, 0x7fff                           // 000000720134: D6550015 03FE2B13 00007FFF
	v_bfe_u32 v19, v22, v36, 4                                 // 000000720140: D6100013 02124916
	v_lshrrev_b32_e32 v22, v37, v26                            // 000000720148: 322C3525
	v_lshrrev_b32_e32 v26, v35, v27                            // 00000072014C: 32343723
	v_lshlrev_b32_e32 v22, 4, v22                              // 000000720150: 302C2C84
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000720154: BF870112
	v_lshlrev_b32_e32 v26, 4, v26                              // 000000720158: 30343484
	v_and_or_b32 v19, v22, 48, v19                             // 00000072015C: D6570013 044D6116
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000720164: BF870091
	v_subrev_nc_u32_e32 v19, 32, v19                           // 000000720168: 4E2626A0
	v_cvt_f32_i32_e32 v19, v19                                 // 00000072016C: 7E260B13
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000720170: BF870121
	v_mul_f32_e32 v19, v4, v19                                 // 000000720174: 10262704
	v_bfe_u32 v20, v23, v30, 4                                 // 000000720178: D6100014 02123D17
	v_bfe_u32 v22, v19, 16, 1                                  // 000000720180: D6100016 02052113
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000720188: BF8700B1
	v_add3_u32 v19, v19, v22, 0x7fff                           // 00000072018C: D6550013 03FE2D13 00007FFF
	.long 0x7e263995                                           // 000000720198: 7E263995
	v_lshrrev_b32_e32 v21, v31, v27                            // 00000072019C: 322A371F
	v_lshlrev_b32_e32 v21, 4, v21                              // 0000007201A0: 302A2A84
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007201A4: BF870091
	v_and_or_b32 v20, v21, 48, v20                             // 0000007201A8: D6570014 04516115
	v_subrev_nc_u32_e32 v20, 32, v20                           // 0000007201B0: 4E2828A0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007201B4: BF870091
	v_cvt_f32_i32_e32 v20, v20                                 // 0000007201B8: 7E280B14
	v_mul_f32_e32 v20, v4, v20                                 // 0000007201BC: 10282904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007201C0: BF870091
	v_bfe_u32 v21, v20, 16, 1                                  // 0000007201C4: D6100015 02052114
	v_add3_u32 v22, v20, v21, 0x7fff                           // 0000007201CC: D6550016 03FE2B14 00007FFF
	v_lshrrev_b32_e32 v21, v33, v27                            // 0000007201D8: 322A3721
	v_bfe_u32 v20, v23, v32, 4                                 // 0000007201DC: D6100014 02124117
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007201E4: BF870092
	v_lshlrev_b32_e32 v21, 4, v21                              // 0000007201E8: 302A2A84
	v_and_or_b32 v20, v21, 48, v20                             // 0000007201EC: D6570014 04516115
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007201F4: BF870091
	v_subrev_nc_u32_e32 v20, 32, v20                           // 0000007201F8: 4E2828A0
	v_cvt_f32_i32_e32 v20, v20                                 // 0000007201FC: 7E280B14
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000720200: BF870091
	v_mul_f32_e32 v20, v4, v20                                 // 000000720204: 10282904
	v_bfe_u32 v21, v20, 16, 1                                  // 000000720208: D6100015 02052114
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000720210: BF8701C1
	v_add3_u32 v20, v20, v21, 0x7fff                           // 000000720214: D6550014 03FE2B14 00007FFF
	v_bfe_u32 v21, v23, v34, 4                                 // 000000720220: D6100015 02124517
	.long 0x7e283996                                           // 000000720228: 7E283996
	v_bfe_u32 v22, v24, v30, 4                                 // 00000072022C: D6100016 02123D18
	v_and_or_b32 v21, v26, 48, v21                             // 000000720234: D6570015 0455611A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000072023C: BF870091
	v_subrev_nc_u32_e32 v21, 32, v21                           // 000000720240: 4E2A2AA0
	v_cvt_f32_i32_e32 v21, v21                                 // 000000720244: 7E2A0B15
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000720248: BF870091
	v_mul_f32_e32 v21, v4, v21                                 // 00000072024C: 102A2B04
	v_bfe_u32 v26, v21, 16, 1                                  // 000000720250: D610001A 02052115
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000720258: BF870141
	v_add3_u32 v26, v21, v26, 0x7fff                           // 00000072025C: D655001A 03FE3515 00007FFF
	v_bfe_u32 v21, v23, v36, 4                                 // 000000720268: D6100015 02124917
	v_lshrrev_b32_e32 v23, v37, v27                            // 000000720270: 322E3725
	v_lshrrev_b32_e32 v27, v35, v28                            // 000000720274: 32363923
	v_lshlrev_b32_e32 v23, 4, v23                              // 000000720278: 302E2E84
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000072027C: BF870112
	v_lshlrev_b32_e32 v27, 4, v27                              // 000000720280: 30363684
	v_and_or_b32 v21, v23, 48, v21                             // 000000720284: D6570015 04556117
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000072028C: BF870091
	v_subrev_nc_u32_e32 v21, 32, v21                           // 000000720290: 4E2A2AA0
	v_cvt_f32_i32_e32 v21, v21                                 // 000000720294: 7E2A0B15
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000720298: BF870091
	v_mul_f32_e32 v21, v4, v21                                 // 00000072029C: 102A2B04
	v_bfe_u32 v23, v21, 16, 1                                  // 0000007202A0: D6100017 02052115
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000007202A8: BF870131
	v_add3_u32 v21, v21, v23, 0x7fff                           // 0000007202AC: D6550015 03FE2F15 00007FFF
	v_lshrrev_b32_e32 v23, v31, v28                            // 0000007202B8: 322E391F
	.long 0x7e2a399a                                           // 0000007202BC: 7E2A399A
	v_lshlrev_b32_e32 v23, 4, v23                              // 0000007202C0: 302E2E84
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007202C4: BF870091
	v_and_or_b32 v22, v23, 48, v22                             // 0000007202C8: D6570016 04596117
	v_subrev_nc_u32_e32 v22, 32, v22                           // 0000007202D0: 4E2C2CA0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007202D4: BF870091
	v_cvt_f32_i32_e32 v22, v22                                 // 0000007202D8: 7E2C0B16
	v_mul_f32_e32 v22, v4, v22                                 // 0000007202DC: 102C2D04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007202E0: BF870091
	v_bfe_u32 v23, v22, 16, 1                                  // 0000007202E4: D6100017 02052116
	v_add3_u32 v26, v22, v23, 0x7fff                           // 0000007202EC: D655001A 03FE2F16 00007FFF
	v_lshrrev_b32_e32 v23, v33, v28                            // 0000007202F8: 322E3921
	v_bfe_u32 v22, v24, v32, 4                                 // 0000007202FC: D6100016 02124118
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000720304: BF870092
	v_lshlrev_b32_e32 v23, 4, v23                              // 000000720308: 302E2E84
	v_and_or_b32 v22, v23, 48, v22                             // 00000072030C: D6570016 04596117
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000720314: BF870091
	v_subrev_nc_u32_e32 v22, 32, v22                           // 000000720318: 4E2C2CA0
	v_cvt_f32_i32_e32 v22, v22                                 // 00000072031C: 7E2C0B16
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000720320: BF870091
	v_mul_f32_e32 v22, v4, v22                                 // 000000720324: 102C2D04
	v_bfe_u32 v23, v22, 16, 1                                  // 000000720328: D6100017 02052116
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000720330: BF8701C1
	v_add3_u32 v22, v22, v23, 0x7fff                           // 000000720334: D6550016 03FE2F16 00007FFF
	v_bfe_u32 v23, v24, v34, 4                                 // 000000720340: D6100017 02124518
	.long 0x7e2c399a                                           // 000000720348: 7E2C399A
	v_lshrrev_b32_e32 v26, v31, v29                            // 00000072034C: 32343B1F
	v_and_or_b32 v23, v27, 48, v23                             // 000000720350: D6570017 045D611B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000720358: BF870112
	v_lshlrev_b32_e32 v26, 4, v26                              // 00000072035C: 30343484
	v_subrev_nc_u32_e32 v23, 32, v23                           // 000000720360: 4E2E2EA0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000720364: BF870091
	v_cvt_f32_i32_e32 v23, v23                                 // 000000720368: 7E2E0B17
	v_mul_f32_e32 v23, v4, v23                                 // 00000072036C: 102E2F04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000720370: BF870091
	v_bfe_u32 v27, v23, 16, 1                                  // 000000720374: D610001B 02052117
	v_add3_u32 v27, v23, v27, 0x7fff                           // 00000072037C: D655001B 03FE3717 00007FFF
	v_bfe_u32 v23, v24, v36, 4                                 // 000000720388: D6100017 02124918
	v_lshrrev_b32_e32 v24, v37, v28                            // 000000720390: 32303925
	v_lshrrev_b32_e32 v28, v35, v29                            // 000000720394: 32383B23
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000720398: BF870112
	v_lshlrev_b32_e32 v24, 4, v24                              // 00000072039C: 30303084
	v_lshlrev_b32_e32 v28, 4, v28                              // 0000007203A0: 30383884
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007203A4: BF870092
	v_and_or_b32 v23, v24, 48, v23                             // 0000007203A8: D6570017 045D6118
	v_subrev_nc_u32_e32 v23, 32, v23                           // 0000007203B0: 4E2E2EA0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007203B4: BF870091
	v_cvt_f32_i32_e32 v23, v23                                 // 0000007203B8: 7E2E0B17
	v_mul_f32_e32 v23, v4, v23                                 // 0000007203BC: 102E2F04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007203C0: BF870091
	v_bfe_u32 v24, v23, 16, 1                                  // 0000007203C4: D6100018 02052117
	v_add3_u32 v23, v23, v24, 0x7fff                           // 0000007203CC: D6550017 03FE3117 00007FFF
	v_bfe_u32 v24, v25, v30, 4                                 // 0000007203D8: D6100018 02123D19
	.long 0x7e2e399b                                           // 0000007203E0: 7E2E399B
	v_lshrrev_b32_e32 v27, v33, v29                            // 0000007203E4: 32363B21
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007203E8: BF870113
	v_and_or_b32 v24, v26, 48, v24                             // 0000007203EC: D6570018 0461611A
	v_lshlrev_b32_e32 v27, 4, v27                              // 0000007203F4: 30363684
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007203F8: BF870092
	v_subrev_nc_u32_e32 v24, 32, v24                           // 0000007203FC: 4E3030A0
	v_cvt_f32_i32_e32 v24, v24                                 // 000000720400: 7E300B18
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000720404: BF870091
	v_mul_f32_e32 v24, v4, v24                                 // 000000720408: 10303104
	v_bfe_u32 v26, v24, 16, 1                                  // 00000072040C: D610001A 02052118
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000720414: BF8700A1
	v_add3_u32 v26, v24, v26, 0x7fff                           // 000000720418: D655001A 03FE3518 00007FFF
	v_bfe_u32 v24, v25, v32, 4                                 // 000000720424: D6100018 02124119
	v_and_or_b32 v24, v27, 48, v24                             // 00000072042C: D6570018 0461611B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000720434: BF870091
	v_subrev_nc_u32_e32 v24, 32, v24                           // 000000720438: 4E3030A0
	v_cvt_f32_i32_e32 v24, v24                                 // 00000072043C: 7E300B18
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000720440: BF870091
	v_mul_f32_e32 v24, v4, v24                                 // 000000720444: 10303104
	v_bfe_u32 v27, v24, 16, 1                                  // 000000720448: D610001B 02052118
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000720450: BF8701C1
	v_add3_u32 v24, v24, v27, 0x7fff                           // 000000720454: D6550018 03FE3718 00007FFF
	v_bfe_u32 v27, v25, v34, 4                                 // 000000720460: D610001B 02124519
	v_bfe_u32 v25, v25, v36, 4                                 // 000000720468: D6100019 02124919
	.long 0x7e30399a                                           // 000000720470: 7E30399A
	v_and_or_b32 v27, v28, 48, v27                             // 000000720474: D657001B 046D611C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000072047C: BF870091
	v_subrev_nc_u32_e32 v27, 32, v27                           // 000000720480: 4E3636A0
	v_cvt_f32_i32_e32 v27, v27                                 // 000000720484: 7E360B1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000720488: BF870091
	v_mul_f32_e32 v27, v4, v27                                 // 00000072048C: 10363704
	v_bfe_u32 v28, v27, 16, 1                                  // 000000720490: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000720498: BF8700A1
	v_add3_u32 v27, v27, v28, 0x7fff                           // 00000072049C: D655001B 03FE391B 00007FFF
	v_lshrrev_b32_e32 v28, v37, v29                            // 0000007204A8: 32383B25
	v_lshlrev_b32_e32 v28, 4, v28                              // 0000007204AC: 30383884
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007204B0: BF870091
	v_and_or_b32 v25, v28, 48, v25                             // 0000007204B4: D6570019 0465611C
	v_subrev_nc_u32_e32 v25, 32, v25                           // 0000007204BC: 4E3232A0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007204C0: BF870091
	v_cvt_f32_i32_e32 v25, v25                                 // 0000007204C4: 7E320B19
	v_mul_f32_e32 v4, v4, v25                                  // 0000007204C8: 10083304
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007204CC: BF870091
	v_bfe_u32 v25, v4, 16, 1                                   // 0000007204D0: D6100019 02052104
	v_add3_u32 v25, v4, v25, 0x7fff                            // 0000007204D8: D6550019 03FE3304 00007FFF
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000007204E4: 3408069F
	.long 0x7e32399b                                           // 0000007204E8: 7E32399B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007204EC: BF870122
	.long 0xd73c001a                                           // 0000007204F0: D73C001A
	v_cndmask_b32_e32 v1, 1, v3, vcc_lo                        // 0000007204F4: 02020681
	v_add_nc_u32_e32 v3, 0x200, v3                             // 0000007204F8: 4A0606FF 00000200
	.long 0xd7006a22                                           // 000000720500: D7006A22
	v_cndmask_b32_e32 v1, s6, v26, vcc_lo                      // 000000720504: 02023406
	s_delay_alu instid0(VALU_DEP_1)                            // 000000720508: BF870001
	v_add_co_ci_u32_e64 v35, null, s7, v27, vcc_lo             // 00000072050C: D5207C23 01AA3607
	s_clause 0x1                                               // 000000720514: BF850001
	global_load_b128 v[26:29], v[34:35], off                   // 000000720518: DC5E0000 1A7C0022
	global_load_b128 v[30:33], v[34:35], off offset:16         // 000000720520: DC5E0010 1E7C0022
	s_waitcnt vmcnt(1)                                         // 000000720528: BF8907F7
	v_dot2_f32_bf16 v4, v26, v18, 0                            // 00000072052C: CC1A4004 1A02251A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000720534: BF870091
	v_dot2_f32_bf16 v4, v27, v19, v4                           // 000000720538: CC1A4004 1C12271B
	v_dot2_f32_bf16 v4, v28, v20, v4                           // 000000720540: CC1A4004 1C12291C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000720548: BF8700A1
	v_dot2_f32_bf16 v4, v29, v21, v4                           // 00000072054C: CC1A4004 1C122B1D
	s_waitcnt vmcnt(0)                                         // 000000720554: BF8903F7
	v_dot2_f32_bf16 v4, v30, v22, v4                           // 000000720558: CC1A4004 1C122D1E
	.long 0xd7006a1e                                           // 000000720560: D7006A1E
	v_cndmask_b32_e32 v0, v34, v4, vcc_lo                      // 000000720564: 02000922
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000720568: BF8701B2
	v_dot2_f32_bf16 v4, v31, v23, v4                           // 00000072056C: CC1A4004 1C122F1F
	v_add_co_ci_u32_e64 v31, null, s5, v35, vcc_lo             // 000000720574: D5207C1F 01AA4605
	.long 0xd7006a24                                           // 00000072057C: D7006A24
	v_cndmask_b32_e32 v0, v34, v0, vcc_lo                      // 000000720580: 02000122
	v_dot2_f32_bf16 v4, v32, v24, v4                           // 000000720584: CC1A4004 1C123120
	v_add_co_ci_u32_e64 v37, null, s1, v35, vcc_lo             // 00000072058C: D5207C25 01AA4601
	.long 0xd7006a22                                           // 000000720594: D7006A22
	v_cndmask_b32_e32 v0, v34, v17, vcc_lo                     // 000000720598: 02002322
	s_delay_alu instid0(VALU_DEP_3)                            // 00000072059C: BF870003
	v_dot2_f32_bf16 v4, v33, v25, v4                           // 0000007205A0: CC1A4004 1C123321
	s_clause 0x1                                               // 0000007205A8: BF850001
	global_load_b128 v[26:29], v[30:31], off                   // 0000007205AC: DC5E0000 1A7C001E
	global_load_b128 v[30:33], v[30:31], off offset:16         // 0000007205B4: DC5E0010 1E7C001E
	v_add_co_ci_u32_e64 v35, null, s16, v35, vcc_lo            // 0000007205BC: D5207C23 01AA4610
	v_add_f32_e32 v8, v8, v4                                   // 0000007205C4: 06100908
	s_waitcnt vmcnt(1)                                         // 0000007205C8: BF8907F7
	v_dot2_f32_bf16 v4, v26, v18, 0                            // 0000007205CC: CC1A4004 1A02251A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007205D4: BF870091
	v_dot2_f32_bf16 v4, v27, v19, v4                           // 0000007205D8: CC1A4004 1C12271B
	v_dot2_f32_bf16 v4, v28, v20, v4                           // 0000007205E0: CC1A4004 1C12291C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007205E8: BF8700A1
	v_dot2_f32_bf16 v4, v29, v21, v4                           // 0000007205EC: CC1A4004 1C122B1D
	s_waitcnt vmcnt(0)                                         // 0000007205F4: BF8903F7
	v_dot2_f32_bf16 v4, v30, v22, v4                           // 0000007205F8: CC1A4004 1C122D1E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000720600: BF870091
	v_dot2_f32_bf16 v4, v31, v23, v4                           // 000000720604: CC1A4004 1C122F1F
	v_dot2_f32_bf16 v4, v32, v24, v4                           // 00000072060C: CC1A4004 1C123120
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000720614: BF8700D1
	v_dot2_f32_bf16 v4, v33, v25, v4                           // 000000720618: CC1A4004 1C123321
	s_clause 0x1                                               // 000000720620: BF850001
	global_load_b128 v[26:29], v[36:37], off                   // 000000720624: DC5E0000 1A7C0024
	global_load_b128 v[30:33], v[36:37], off offset:16         // 00000072062C: DC5E0010 1E7C0024
	.long 0xd7006a24                                           // 000000720634: D7006A24
	v_cndmask_b32_e32 v0, v36, v0, vcc_lo                      // 000000720638: 02000124
	v_add_co_ci_u32_e64 v37, null, s1, v37, vcc_lo             // 00000072063C: D5207C25 01AA4A01
	v_add_f32_e32 v17, v17, v4                                 // 000000720644: 06220911
	s_waitcnt vmcnt(1)                                         // 000000720648: BF8907F7
	v_dot2_f32_bf16 v4, v26, v18, 0                            // 00000072064C: CC1A4004 1A02251A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000720654: BF870091
	v_dot2_f32_bf16 v4, v27, v19, v4                           // 000000720658: CC1A4004 1C12271B
	v_dot2_f32_bf16 v4, v28, v20, v4                           // 000000720660: CC1A4004 1C12291C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000720668: BF8700A1
	v_dot2_f32_bf16 v4, v29, v21, v4                           // 00000072066C: CC1A4004 1C122B1D
	s_waitcnt vmcnt(0)                                         // 000000720674: BF8903F7
	v_dot2_f32_bf16 v4, v30, v22, v4                           // 000000720678: CC1A4004 1C122D1E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000720680: BF870091
	v_dot2_f32_bf16 v4, v31, v23, v4                           // 000000720684: CC1A4004 1C122F1F
	v_dot2_f32_bf16 v4, v32, v24, v4                           // 00000072068C: CC1A4004 1C123120
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000720694: BF8700D1
	v_dot2_f32_bf16 v4, v33, v25, v4                           // 000000720698: CC1A4004 1C123321
	s_clause 0x1                                               // 0000007206A0: BF850001
	global_load_b128 v[26:29], v[34:35], off                   // 0000007206A4: DC5E0000 1A7C0022
	global_load_b128 v[30:33], v[34:35], off offset:16         // 0000007206AC: DC5E0010 1E7C0022
	.long 0xd7006a22                                           // 0000007206B4: D7006A22
	v_cndmask_b32_e32 v0, v34, v0, vcc_lo                      // 0000007206B8: 02000122
	v_add_co_ci_u32_e64 v35, null, s1, v35, vcc_lo             // 0000007206BC: D5207C23 01AA4601
	v_add_f32_e32 v16, v16, v4                                 // 0000007206C4: 06200910
	s_waitcnt vmcnt(1)                                         // 0000007206C8: BF8907F7
	v_dot2_f32_bf16 v4, v26, v18, 0                            // 0000007206CC: CC1A4004 1A02251A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007206D4: BF870091
	v_dot2_f32_bf16 v4, v27, v19, v4                           // 0000007206D8: CC1A4004 1C12271B
	v_dot2_f32_bf16 v4, v28, v20, v4                           // 0000007206E0: CC1A4004 1C12291C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007206E8: BF8700A1
	v_dot2_f32_bf16 v4, v29, v21, v4                           // 0000007206EC: CC1A4004 1C122B1D
	s_waitcnt vmcnt(0)                                         // 0000007206F4: BF8903F7
	v_dot2_f32_bf16 v4, v30, v22, v4                           // 0000007206F8: CC1A4004 1C122D1E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000720700: BF870091
	v_dot2_f32_bf16 v4, v31, v23, v4                           // 000000720704: CC1A4004 1C122F1F
	v_dot2_f32_bf16 v4, v32, v24, v4                           // 00000072070C: CC1A4004 1C123120
	s_delay_alu instid0(VALU_DEP_1)                            // 000000720714: BF870001
	v_dot2_f32_bf16 v4, v33, v25, v4                           // 000000720718: CC1A4004 1C123321
	s_clause 0x1                                               // 000000720720: BF850001
	global_load_b128 v[26:29], v[36:37], off                   // 000000720724: DC5E0000 1A7C0024
	global_load_b128 v[30:33], v[36:37], off offset:16         // 00000072072C: DC5E0010 1E7C0024
	v_add_f32_e32 v15, v15, v4                                 // 000000720734: 061E090F
	s_waitcnt vmcnt(1)                                         // 000000720738: BF8907F7
	v_dot2_f32_bf16 v4, v26, v18, 0                            // 00000072073C: CC1A4004 1A02251A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000720744: BF870091
	v_dot2_f32_bf16 v4, v27, v19, v4                           // 000000720748: CC1A4004 1C12271B
	v_dot2_f32_bf16 v4, v28, v20, v4                           // 000000720750: CC1A4004 1C12291C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000720758: BF8700A1
	v_dot2_f32_bf16 v4, v29, v21, v4                           // 00000072075C: CC1A4004 1C122B1D
	s_waitcnt vmcnt(0)                                         // 000000720764: BF8903F7
	v_dot2_f32_bf16 v4, v30, v22, v4                           // 000000720768: CC1A4004 1C122D1E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000720770: BF870091
	v_dot2_f32_bf16 v4, v31, v23, v4                           // 000000720774: CC1A4004 1C122F1F
	v_dot2_f32_bf16 v4, v32, v24, v4                           // 00000072077C: CC1A4004 1C123120
	s_delay_alu instid0(VALU_DEP_1)                            // 000000720784: BF870001
	v_dot2_f32_bf16 v4, v33, v25, v4                           // 000000720788: CC1A4004 1C123321
	s_clause 0x1                                               // 000000720790: BF850001
	global_load_b128 v[26:29], v[34:35], off                   // 000000720794: DC5E0000 1A7C0022
	global_load_b128 v[30:33], v[34:35], off offset:16         // 00000072079C: DC5E0010 1E7C0022
	v_add_f32_e32 v12, v12, v4                                 // 0000007207A4: 0618090C
	s_waitcnt vmcnt(1)                                         // 0000007207A8: BF8907F7
	v_dot2_f32_bf16 v4, v26, v18, 0                            // 0000007207AC: CC1A4004 1A02251A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007207B4: BF870091
	v_dot2_f32_bf16 v4, v27, v19, v4                           // 0000007207B8: CC1A4004 1C12271B
	v_dot2_f32_bf16 v4, v28, v20, v4                           // 0000007207C0: CC1A4004 1C12291C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007207C8: BF8700A1
	v_dot2_f32_bf16 v4, v29, v21, v4                           // 0000007207CC: CC1A4004 1C122B1D
	s_waitcnt vmcnt(0)                                         // 0000007207D4: BF8903F7
	v_dot2_f32_bf16 v4, v30, v22, v4                           // 0000007207D8: CC1A4004 1C122D1E
	.long 0xd7006a1e                                           // 0000007207E0: D7006A1E
	v_cndmask_b32_e32 v0, v36, v0, vcc_lo                      // 0000007207E4: 02000124
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007207E8: BF870122
	v_dot2_f32_bf16 v4, v31, v23, v4                           // 0000007207EC: CC1A4004 1C122F1F
	v_add_co_ci_u32_e64 v31, null, s1, v37, vcc_lo             // 0000007207F4: D5207C1F 01AA4A01
	v_dot2_f32_bf16 v4, v32, v24, v4                           // 0000007207FC: CC1A4004 1C123120
	s_delay_alu instid0(VALU_DEP_1)                            // 000000720804: BF870001
	v_dot2_f32_bf16 v4, v33, v25, v4                           // 000000720808: CC1A4004 1C123321
	s_clause 0x1                                               // 000000720810: BF850001
	global_load_b128 v[26:29], v[30:31], off                   // 000000720814: DC5E0000 1A7C001E
	global_load_b128 v[30:33], v[30:31], off offset:16         // 00000072081C: DC5E0010 1E7C001E
	v_add_f32_e32 v11, v11, v4                                 // 000000720824: 0616090B
	s_waitcnt vmcnt(1)                                         // 000000720828: BF8907F7
	v_dot2_f32_bf16 v4, v26, v18, 0                            // 00000072082C: CC1A4004 1A02251A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000720834: BF870091
	v_dot2_f32_bf16 v4, v27, v19, v4                           // 000000720838: CC1A4004 1C12271B
	v_dot2_f32_bf16 v4, v28, v20, v4                           // 000000720840: CC1A4004 1C12291C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000720848: BF8700A1
	v_dot2_f32_bf16 v4, v29, v21, v4                           // 00000072084C: CC1A4004 1C122B1D
	s_waitcnt vmcnt(0)                                         // 000000720854: BF8903F7
	v_dot2_f32_bf16 v4, v30, v22, v4                           // 000000720858: CC1A4004 1C122D1E
	.long 0xd7006a1e                                           // 000000720860: D7006A1E
	v_cndmask_b32_e32 v0, v34, v0, vcc_lo                      // 000000720864: 02000122
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000720868: BF8701B2
	v_dot2_f32_bf16 v4, v31, v23, v4                           // 00000072086C: CC1A4004 1C122F1F
	v_add_co_ci_u32_e64 v31, null, s1, v35, vcc_lo             // 000000720874: D5207C1F 01AA4601
	v_cmp_ge_i32_e32 vcc_lo, v13, v14                          // 00000072087C: 7C8C1D0D
	v_dot2_f32_bf16 v4, v32, v24, v4                           // 000000720880: CC1A4004 1C123120
	s_or_b32 s3, vcc_lo, s3                                    // 000000720888: 8C03036A
	s_delay_alu instid0(VALU_DEP_1)                            // 00000072088C: BF870001
	v_dot2_f32_bf16 v4, v33, v25, v4                           // 000000720890: CC1A4004 1C123321
	s_clause 0x1                                               // 000000720898: BF850001
	global_load_b128 v[26:29], v[30:31], off                   // 00000072089C: DC5E0000 1A7C001E
	global_load_b128 v[30:33], v[30:31], off offset:16         // 0000007208A4: DC5E0010 1E7C001E
	v_add_f32_e32 v10, v10, v4                                 // 0000007208AC: 0614090A
	s_waitcnt vmcnt(1)                                         // 0000007208B0: BF8907F7
	v_dot2_f32_bf16 v4, v26, v18, 0                            // 0000007208B4: CC1A4004 1A02251A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007208BC: BF870091
	v_dot2_f32_bf16 v4, v27, v19, v4                           // 0000007208C0: CC1A4004 1C12271B
	v_dot2_f32_bf16 v4, v28, v20, v4                           // 0000007208C8: CC1A4004 1C12291C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007208D0: BF8700A1
	v_dot2_f32_bf16 v4, v29, v21, v4                           // 0000007208D4: CC1A4004 1C122B1D
	s_waitcnt vmcnt(0)                                         // 0000007208DC: BF8903F7
	v_dot2_f32_bf16 v4, v30, v22, v4                           // 0000007208E0: CC1A4004 1C122D1E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007208E8: BF870091
	v_dot2_f32_bf16 v4, v31, v23, v4                           // 0000007208EC: CC1A4004 1C122F1F
	v_dot2_f32_bf16 v4, v32, v24, v4                           // 0000007208F4: CC1A4004 1C123120
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007208FC: BF870091
	v_dot2_f32_bf16 v4, v33, v25, v4                           // 000000720900: CC1A4004 1C123321
	v_add_f32_e32 v9, v9, v4                                   // 000000720908: 06120909
	s_and_not1_b32 exec_lo, exec_lo, s3                        // 00000072090C: 917E037E
	s_cbranch_execnz 64912                                     // 000000720910: BFA6FD90 <_ZN7halogen12_GLOBAL__N_16k_lq6kILi8ELi32ELi2ELb1EEEvPKhPKtPvll+0x154>
	s_or_b32 exec_lo, exec_lo, s3                              // 000000720914: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000720918: BF8700B9
	s_or_b32 exec_lo, exec_lo, s2                              // 00000072091C: 8C7E027E
	.long 0xd71f0001                                           // 000000720920: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000720924: 020100C1
	s_mov_b32 s0, exec_lo                                      // 000000720928: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 00000072092C: 3A040290
	v_xor_b32_e32 v21, 8, v1                                   // 000000720930: 3A2A0288
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000720934: BF8701A2
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 000000720938: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 00000072093C: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v21                           // 000000720940: 7C982AA0
	v_cndmask_b32_e32 v21, v1, v21, vcc_lo                     // 000000720944: 022A2B01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000720948: BF870211
	v_lshlrev_b32_e32 v21, 2, v21                              // 00000072094C: 302A2A82
	v_lshlrev_b32_e32 v2, 2, v2                                // 000000720950: 30040482
	ds_bpermute_b32 v3, v2, v8                                 // 000000720954: DACC0000 03000802
	s_waitcnt lgkmcnt(0)                                       // 00000072095C: BF89FC07
	v_add_f32_e32 v3, v8, v3                                   // 000000720960: 06060708
	ds_bpermute_b32 v4, v2, v17                                // 000000720964: DACC0000 04001102
	ds_bpermute_b32 v13, v2, v16                               // 00000072096C: DACC0000 0D001002
	ds_bpermute_b32 v14, v2, v15                               // 000000720974: DACC0000 0E000F02
	ds_bpermute_b32 v18, v2, v12                               // 00000072097C: DACC0000 12000C02
	ds_bpermute_b32 v19, v2, v11                               // 000000720984: DACC0000 13000B02
	ds_bpermute_b32 v20, v2, v10                               // 00000072098C: DACC0000 14000A02
	ds_bpermute_b32 v2, v2, v9                                 // 000000720994: DACC0000 02000902
	s_waitcnt lgkmcnt(6)                                       // 00000072099C: BF89FC67
	v_add_f32_e32 v4, v17, v4                                  // 0000007209A0: 06080911
	s_waitcnt lgkmcnt(4)                                       // 0000007209A4: BF89FC47
	v_dual_add_f32 v8, v16, v13 :: v_dual_add_f32 v13, v15, v14// 0000007209A8: C9081B10 080C1D0F
	s_waitcnt lgkmcnt(2)                                       // 0000007209B0: BF89FC27
	v_dual_add_f32 v12, v12, v18 :: v_dual_add_f32 v11, v11, v19// 0000007209B4: C908250C 0C0A270B
	s_waitcnt lgkmcnt(1)                                       // 0000007209BC: BF89FC17
	v_add_f32_e32 v10, v10, v20                                // 0000007209C0: 0614290A
	s_waitcnt lgkmcnt(0)                                       // 0000007209C4: BF89FC07
	v_add_f32_e32 v2, v9, v2                                   // 0000007209C8: 06040509
	ds_bpermute_b32 v9, v21, v3                                // 0000007209CC: DACC0000 09000315
	ds_bpermute_b32 v14, v21, v4                               // 0000007209D4: DACC0000 0E000415
	ds_bpermute_b32 v15, v21, v8                               // 0000007209DC: DACC0000 0F000815
	ds_bpermute_b32 v16, v21, v13                              // 0000007209E4: DACC0000 10000D15
	ds_bpermute_b32 v17, v21, v12                              // 0000007209EC: DACC0000 11000C15
	ds_bpermute_b32 v18, v21, v11                              // 0000007209F4: DACC0000 12000B15
	ds_bpermute_b32 v19, v21, v10                              // 0000007209FC: DACC0000 13000A15
	ds_bpermute_b32 v20, v21, v2                               // 000000720A04: DACC0000 14000215
	v_xor_b32_e32 v21, 4, v1                                   // 000000720A0C: 3A2A0284
	s_delay_alu instid0(VALU_DEP_1)                            // 000000720A10: BF870001
	v_cmp_gt_u32_e32 vcc_lo, 32, v21                           // 000000720A14: 7C982AA0
	v_cndmask_b32_e32 v21, v1, v21, vcc_lo                     // 000000720A18: 022A2B01
	s_waitcnt lgkmcnt(6)                                       // 000000720A1C: BF89FC67
	v_dual_add_f32 v3, v3, v9 :: v_dual_add_f32 v4, v4, v14    // 000000720A20: C9081303 03041D04
	s_waitcnt lgkmcnt(4)                                       // 000000720A28: BF89FC47
	v_dual_add_f32 v8, v8, v15 :: v_dual_add_f32 v9, v13, v16  // 000000720A2C: C9081F08 0808210D
	v_lshlrev_b32_e32 v21, 2, v21                              // 000000720A34: 302A2A82
	s_waitcnt lgkmcnt(2)                                       // 000000720A38: BF89FC27
	v_dual_add_f32 v12, v12, v17 :: v_dual_add_f32 v11, v11, v18// 000000720A3C: C908230C 0C0A250B
	s_waitcnt lgkmcnt(1)                                       // 000000720A44: BF89FC17
	v_add_f32_e32 v10, v10, v19                                // 000000720A48: 0614270A
	s_waitcnt lgkmcnt(0)                                       // 000000720A4C: BF89FC07
	v_add_f32_e32 v2, v2, v20                                  // 000000720A50: 06042902
	ds_bpermute_b32 v13, v21, v3                               // 000000720A54: DACC0000 0D000315
	ds_bpermute_b32 v14, v21, v4                               // 000000720A5C: DACC0000 0E000415
	ds_bpermute_b32 v15, v21, v8                               // 000000720A64: DACC0000 0F000815
	ds_bpermute_b32 v16, v21, v9                               // 000000720A6C: DACC0000 10000915
	ds_bpermute_b32 v17, v21, v12                              // 000000720A74: DACC0000 11000C15
	ds_bpermute_b32 v18, v21, v11                              // 000000720A7C: DACC0000 12000B15
	ds_bpermute_b32 v19, v21, v10                              // 000000720A84: DACC0000 13000A15
	ds_bpermute_b32 v20, v21, v2                               // 000000720A8C: DACC0000 14000215
	v_xor_b32_e32 v21, 2, v1                                   // 000000720A94: 3A2A0282
	s_delay_alu instid0(VALU_DEP_1)                            // 000000720A98: BF870001
	v_cmp_gt_u32_e32 vcc_lo, 32, v21                           // 000000720A9C: 7C982AA0
	v_cndmask_b32_e32 v21, v1, v21, vcc_lo                     // 000000720AA0: 022A2B01
	s_waitcnt lgkmcnt(6)                                       // 000000720AA4: BF89FC67
	v_dual_add_f32 v3, v3, v13 :: v_dual_add_f32 v4, v4, v14   // 000000720AA8: C9081B03 03041D04
	s_waitcnt lgkmcnt(4)                                       // 000000720AB0: BF89FC47
	v_dual_add_f32 v8, v8, v15 :: v_dual_add_f32 v9, v9, v16   // 000000720AB4: C9081F08 08082109
	v_lshlrev_b32_e32 v21, 2, v21                              // 000000720ABC: 302A2A82
	s_waitcnt lgkmcnt(2)                                       // 000000720AC0: BF89FC27
	v_dual_add_f32 v12, v12, v17 :: v_dual_add_f32 v11, v11, v18// 000000720AC4: C908230C 0C0A250B
	s_waitcnt lgkmcnt(1)                                       // 000000720ACC: BF89FC17
	v_add_f32_e32 v10, v10, v19                                // 000000720AD0: 0614270A
	ds_bpermute_b32 v14, v21, v4                               // 000000720AD4: DACC0000 0E000415
	s_waitcnt lgkmcnt(1)                                       // 000000720ADC: BF89FC17
	v_add_f32_e32 v13, v2, v20                                 // 000000720AE0: 061A2902
	ds_bpermute_b32 v2, v21, v3                                // 000000720AE4: DACC0000 02000315
	ds_bpermute_b32 v15, v21, v8                               // 000000720AEC: DACC0000 0F000815
	ds_bpermute_b32 v16, v21, v9                               // 000000720AF4: DACC0000 10000915
	ds_bpermute_b32 v17, v21, v12                              // 000000720AFC: DACC0000 11000C15
	ds_bpermute_b32 v18, v21, v11                              // 000000720B04: DACC0000 12000B15
	ds_bpermute_b32 v19, v21, v10                              // 000000720B0C: DACC0000 13000A15
	ds_bpermute_b32 v20, v21, v13                              // 000000720B14: DACC0000 14000D15
	v_xor_b32_e32 v21, 1, v1                                   // 000000720B1C: 3A2A0281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000720B20: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v21                           // 000000720B24: 7C982AA0
	v_cndmask_b32_e32 v1, v1, v21, vcc_lo                      // 000000720B28: 02022B01
	v_lshlrev_b32_e32 v21, 2, v1                               // 000000720B2C: 302A0282
	s_waitcnt lgkmcnt(6)                                       // 000000720B30: BF89FC67
	v_add_f32_e32 v1, v3, v2                                   // 000000720B34: 06020503
	v_add_f32_e32 v2, v4, v14                                  // 000000720B38: 06041D04
	s_waitcnt lgkmcnt(5)                                       // 000000720B3C: BF89FC57
	v_add_f32_e32 v4, v8, v15                                  // 000000720B40: 06081F08
	s_waitcnt lgkmcnt(3)                                       // 000000720B44: BF89FC37
	v_dual_add_f32 v8, v9, v16 :: v_dual_add_f32 v3, v12, v17  // 000000720B48: C9082109 0802230C
	s_waitcnt lgkmcnt(1)                                       // 000000720B50: BF89FC17
	v_dual_add_f32 v14, v11, v18 :: v_dual_add_f32 v15, v10, v19// 000000720B54: C908250B 0E0E270A
	s_waitcnt lgkmcnt(0)                                       // 000000720B5C: BF89FC07
	v_add_f32_e32 v16, v13, v20                                // 000000720B60: 0620290D
	ds_bpermute_b32 v9, v21, v1                                // 000000720B64: DACC0000 09000115
	ds_bpermute_b32 v10, v21, v2                               // 000000720B6C: DACC0000 0A000215
	ds_bpermute_b32 v12, v21, v4                               // 000000720B74: DACC0000 0C000415
	ds_bpermute_b32 v13, v21, v8                               // 000000720B7C: DACC0000 0D000815
	ds_bpermute_b32 v11, v21, v3                               // 000000720B84: DACC0000 0B000315
	ds_bpermute_b32 v17, v21, v14                              // 000000720B8C: DACC0000 11000E15
	ds_bpermute_b32 v18, v21, v15                              // 000000720B94: DACC0000 12000F15
	ds_bpermute_b32 v19, v21, v16                              // 000000720B9C: DACC0000 13001015
	v_cmpx_eq_u32_e32 0, v7                                    // 000000720BA4: 7D940E80
	s_cbranch_execz 16                                         // 000000720BA8: BFA50010 <_ZN7halogen12_GLOBAL__N_16k_lq6kILi8ELi32ELi2ELb1EEEvPKhPKtPvll+0xdec>
	s_waitcnt lgkmcnt(0)                                       // 000000720BAC: BF89FC07
	v_dual_add_f32 v16, v16, v19 :: v_dual_lshlrev_b32 v5, 5, v5// 000000720BB0: C9222710 10040A85
	v_dual_add_f32 v15, v15, v18 :: v_dual_add_f32 v14, v14, v17// 000000720BB8: C908250F 0F0E230E
	v_add_f32_e32 v19, v4, v12                                 // 000000720BC0: 06261904
	v_dual_add_f32 v20, v8, v13 :: v_dual_add_f32 v13, v3, v11 // 000000720BC4: C9081B08 140C1703
	v_dual_add_f32 v18, v2, v10 :: v_dual_add_f32 v17, v1, v9  // 000000720BCC: C9081502 12101301
	v_lshl_or_b32 v1, v6, 6, v5                                // 000000720BD4: D6560001 04150D06
	ds_store_b128 v1, v[17:20]                                 // 000000720BDC: DB7C0000 00001101
	ds_store_b128 v1, v[13:16] offset:16                       // 000000720BE4: DB7C0010 00000D01
	s_or_b32 exec_lo, exec_lo, s0                              // 000000720BEC: 8C7E007E
	v_lshrrev_b32_e32 v3, 3, v0                                // 000000720BF0: 32060083
	v_mov_b32_e32 v2, s15                                      // 000000720BF4: 7E04020F
	.long 0xd44c0000                                           // 000000720BF8: D44C0000
	v_cndmask_b32_e32 v1, 32, v0, vcc_lo                       // 000000720BFC: 020200A0
	s_waitcnt lgkmcnt(0)                                       // 000000720C00: BF89FC07
	s_barrier                                                  // 000000720C04: BFBD0000
	v_or_b32_e32 v1, s14, v3                                   // 000000720C08: 3802060E
	buffer_gl0_inv                                             // 000000720C0C: E0AC0000 00000000
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 000000720C14: 7CA8020C
	s_and_b32 s0, s0, vcc_lo                                   // 000000720C18: 8B006A00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000720C1C: BF870009
	s_and_saveexec_b32 s1, s0                                  // 000000720C20: BE812000
	s_cbranch_execz 31                                         // 000000720C24: BFA5001F <_ZN7halogen12_GLOBAL__N_16k_lq6kILi8ELi32ELi2ELb1EEEvPKhPKtPvll+0xea4>
	v_and_b32_e32 v0, 7, v0                                    // 000000720C28: 36000087
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000720C2C: BF870091
	v_lshlrev_b32_e32 v4, 2, v0                                // 000000720C30: 30080082
	v_lshl_or_b32 v5, v3, 6, v4                                // 000000720C34: D6560005 04110D03
	v_mad_u64_u32 v[3:4], null, s12, v0, 0                     // 000000720C3C: D6FE7C03 0202000C
	ds_load_2addr_b32 v[6:7], v5 offset1:8                     // 000000720C44: D8DC0800 06000005
	v_mad_u64_u32 v[4:5], null, s13, v0, v[4:5]                // 000000720C4C: D6FE7C04 0412000D
	.long 0xd73c0000                                           // 000000720C54: D73C0000
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000720C58: 02020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000720C5C: BF870092
	.long 0xd73c0003                                           // 000000720C60: D73C0003
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 000000720C64: 02020682
	.long 0xd7006a03                                           // 000000720C68: D7006A03
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 000000720C6C: 02020608
	s_waitcnt lgkmcnt(0)                                       // 000000720C70: BF89FC07
	v_add_f32_e32 v2, 0, v6                                    // 000000720C74: 06040C80
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000720C78: BF870193
	v_add_co_ci_u32_e64 v4, null, s9, v4, vcc_lo               // 000000720C7C: D5207C04 01AA0809
	.long 0xd7006a00                                           // 000000720C84: D7006A00
	v_cndmask_b32_e32 v1, v3, v0, vcc_lo                       // 000000720C88: 02020103
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000720C8C: BF870193
	v_add_f32_e32 v2, v2, v7                                   // 000000720C90: 06040F02
	v_add_co_ci_u32_e64 v1, null, v4, v1, vcc_lo               // 000000720C94: D5207C01 01AA0304
	global_store_b32 v[0:1], v2, off                           // 000000720C9C: DC6A0000 007C0200
	s_endpgm                                                   // 000000720CA4: BFB00000
		...

