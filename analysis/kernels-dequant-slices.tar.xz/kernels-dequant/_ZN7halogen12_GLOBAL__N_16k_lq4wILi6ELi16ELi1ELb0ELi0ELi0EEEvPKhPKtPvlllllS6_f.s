000000000056b100 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 00000056B100: F4100100 F8000000
	v_dual_mov_b32 v4, 0 :: v_dual_and_b32 v15, 15, v0         // 00000056B108: CA240080 040E008F
	v_lshrrev_b32_e32 v1, 4, v0                                // 00000056B110: 32020084
	s_ashr_i32 s3, s2, 31                                      // 00000056B114: 86039F02
	v_mov_b32_e32 v16, 0                                       // 00000056B118: 7E200280
	s_lshl_b64 s[0:1], s[2:3], 4                               // 00000056B11C: 84808402
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000056B120: BF870009
	v_dual_mov_b32 v9, s1 :: v_dual_lshlrev_b32 v2, 2, v15     // 00000056B124: CA220001 09021E82
	v_lshlrev_b32_e32 v3, 2, v1                                // 00000056B12C: 30060282
	v_or_b32_e32 v8, s0, v1                                    // 00000056B130: 38100200
	.long 0x7f183880                                           // 00000056B134: 7F183880
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v5, 0              // 00000056B138: CA100080 1A040080
	v_mov_b32_e32 v6, 0                                        // 00000056B140: 7E0C0280
	s_waitcnt lgkmcnt(0)                                       // 00000056B144: BF89FC07
	s_clause 0x1                                               // 00000056B148: BF850001
	global_load_b32 v7, v2, s[4:5]                             // 00000056B14C: DC520000 07040002
	global_load_b32 v3, v3, s[4:5]                             // 00000056B154: DC520000 03040003
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[8:9]                  // 00000056B15C: 7CA8100C
	s_add_u32 s2, s4, s14                                      // 00000056B160: 80020E04
	s_addc_u32 s3, s5, s15                                     // 00000056B164: 82030F05
	s_lshr_b32 s0, s11, 31                                     // 00000056B168: 85009F0B
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000056B16C: BF870009
	s_add_u32 s14, s10, s0                                     // 00000056B170: 800E000A
	v_cndmask_b32_e32 v10, 0, v8, vcc_lo                       // 00000056B174: 02141080
	v_cndmask_b32_e64 v14, 0, s1, vcc_lo                       // 00000056B178: D501000E 01A80280
	s_addc_u32 s15, s11, 0                                     // 00000056B180: 820F800B
	s_ashr_i32 s20, s11, 31                                    // 00000056B184: 86149F0B
	s_ashr_i64 s[0:1], s[14:15], 1                             // 00000056B188: 8680810E
	s_lshr_b32 s14, s20, 27                                    // 00000056B18C: 850E9B14
	.long 0xd72c0013                                           // 00000056B190: D72C0013
	v_cndmask_b32_e32 v0, v14, v0, vcc_lo                      // 00000056B194: 0200010E
	.long 0xd72c000e                                           // 00000056B198: D72C000E
	v_cndmask_b32_e32 v1, s18, v14, vcc_lo                     // 00000056B19C: 02021C12
	s_waitcnt vmcnt(1)                                         // 00000056B1A0: BF8907F7
	v_bfe_u32 v11, v7, 16, 1                                   // 00000056B1A4: D610000B 02052107
	s_waitcnt vmcnt(0)                                         // 00000056B1AC: BF8903F7
	v_bfe_u32 v18, v3, 16, 1                                   // 00000056B1B0: D6100012 02052103
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000056B1B8: BF870112
	v_add3_u32 v7, v7, v11, 0x7fff                             // 00000056B1BC: D6550007 03FE1707 00007FFF
	v_add3_u32 v3, v3, v18, 0x7fff                             // 00000056B1C8: D6550003 03FE2503 00007FFF
	v_lshlrev_b32_e32 v18, 2, v0                               // 00000056B1D4: 30240082
	s_delay_alu instid0(VALU_DEP_3)                            // 00000056B1D8: BF870003
	.long 0x7e183987                                           // 00000056B1DC: 7E183987
	v_mov_b32_e32 v7, 0                                        // 00000056B1E0: 7E0E0280
	.long 0xd72c000d                                           // 00000056B1E4: D72C000D
	v_cndmask_b32_e32 v1, s19, v10, vcc_lo                     // 00000056B1E8: 02021413
	v_mad_u64_u32 v[1:2], null, s18, v10, 0                    // 00000056B1EC: D6FE7C01 02021412
	.long 0xd72c0011                                           // 00000056B1F4: D72C0011
	v_cndmask_b32_e32 v0, v10, v1, vcc_lo                      // 00000056B1F8: 0200030A
	v_mad_u64_u32 v[10:11], null, v10, s0, s[2:3]              // 00000056B1FC: D6FE7C0A 0008010A
	s_add_u32 s2, s10, s14                                     // 00000056B204: 80020E0A
	s_addc_u32 s3, s11, 0                                      // 00000056B208: 8203800B
	v_and_or_b32 v3, 0xffff0000, v3, v12                       // 00000056B20C: D6570003 043206FF FFFF0000
	s_lshr_b64 s[2:3], s[2:3], 5                               // 00000056B218: 85828502
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000056B21C: BF870009
	.long 0xd4440000                                           // 00000056B220: D4440000
	v_cndmask_b32_e32 v1, s2, v15, vcc_lo                      // 00000056B224: 02021E02
	v_add3_u32 v0, v2, v14, v13                                // 00000056B228: D6550000 04361D02
	v_add3_u32 v17, v19, v11, v17                              // 00000056B230: D6550011 04461713
	ds_store_b32 v18, v3                                       // 00000056B238: D8340000 00000312
	s_waitcnt lgkmcnt(0)                                       // 00000056B240: BF89FC07
	s_barrier                                                  // 00000056B244: BFBD0000
	buffer_gl0_inv                                             // 00000056B248: E0AC0000 00000000
	s_and_saveexec_b32 s3, s0                                  // 00000056B250: BE832000
	s_cbranch_execz 26                                         // 00000056B254: BFA5001A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x1c0>
	s_add_u32 s1, s4, s16                                      // 00000056B258: 80011004
	s_addc_u32 s14, s5, s17                                    // 00000056B25C: 820E1105
	v_lshlrev_b32_e32 v2, 1, v15                               // 00000056B260: 30041E81
	.long 0xd7000103                                           // 00000056B264: D7000103
	v_cndmask_b32_e32 v1, s1, v1, vcc_lo                       // 00000056B268: 02020201
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000056B26C: BF8701A1
	v_add_co_ci_u32_e64 v4, null, s14, v0, s1                  // 00000056B270: D5207C04 0006000E
	v_lshlrev_b32_e32 v5, 4, v15                               // 00000056B278: 300A1E84
	.long 0xd7000102                                           // 00000056B27C: D7000102
	v_cndmask_b32_e32 v1, v3, v2, vcc_lo                       // 00000056B280: 02020503
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000056B284: BF870191
	v_add_co_ci_u32_e64 v3, null, 0, v4, s1                    // 00000056B288: D5207C03 00060880
	.long 0xd7000104                                           // 00000056B290: D7000104
	v_cndmask_b32_e32 v1, v10, v5, vcc_lo                      // 00000056B294: 02020B0A
	s_delay_alu instid0(VALU_DEP_1)                            // 00000056B298: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v17, s1                   // 00000056B29C: D5207C05 00062280
	s_clause 0x1                                               // 00000056B2A4: BF850001
	global_load_d16_b16 v2, v[2:3], off                        // 00000056B2A8: DC820000 027C0002
	global_load_b128 v[4:7], v[4:5], off                       // 00000056B2B0: DC5E0000 047C0004
	s_waitcnt vmcnt(1)                                         // 00000056B2B8: BF8907F7
	v_cvt_f32_f16_e32 v26, v2                                  // 00000056B2BC: 7E341702
	s_or_b32 exec_lo, exec_lo, s3                              // 00000056B2C0: 8C7E037E
	v_dual_mov_b32 v18, 0 :: v_dual_mov_b32 v19, 0             // 00000056B2C4: CA100080 12120080
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v21, 0             // 00000056B2CC: CA100080 14140080
	v_mov_b32_e32 v22, 0                                       // 00000056B2D4: 7E2C0280
	s_and_saveexec_b32 s3, s0                                  // 00000056B2D8: BE832000
	s_cbranch_execz 537                                        // 00000056B2DC: BFA50219 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0xa44>
	s_mul_i32 s0, s11, 6                                       // 00000056B2E0: 9600860B
	s_mul_hi_u32 s1, s10, 6                                    // 00000056B2E4: 9681860A
	v_dual_mov_b32 v12, 0 :: v_dual_lshlrev_b32 v11, 5, v15    // 00000056B2E8: CA220080 0C0A1E85
	s_add_i32 s18, s1, s0                                      // 00000056B2F0: 81120001
	v_lshlrev_b32_e32 v2, 1, v15                               // 00000056B2F4: 30041E81
	.long 0xd7000001                                           // 00000056B2F8: D7000001
	v_cndmask_b32_e32 v1, s16, v1, vcc_lo                      // 00000056B2FC: 02020210
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000056B300: BF8701A1
	v_add_co_ci_u32_e64 v0, null, s17, v0, s0                  // 00000056B304: D5207C00 00020011
	v_mov_b32_e32 v21, v12                                     // 00000056B30C: 7E2A030C
	.long 0xd7000001                                           // 00000056B310: D7000001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 00000056B314: 02020501
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000056B318: BF8701A1
	v_add_co_ci_u32_e64 v0, null, 0, v0, s0                    // 00000056B31C: D5207C00 00020080
	v_lshl_or_b32 v23, v15, 4, 0x100                           // 00000056B324: D6560017 03FD090F 00000100
	.long 0xd7000001                                           // 00000056B330: D7000001
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 00000056B334: 02020204
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000056B338: BF8701A1
	v_add_co_ci_u32_e64 v0, null, s5, v0, s0                   // 00000056B33C: D5207C00 00020005
	v_dual_mov_b32 v24, v15 :: v_dual_mov_b32 v19, v12         // 00000056B344: CA10010F 1812010C
	.long 0xd700000d                                           // 00000056B34C: D700000D
	v_cndmask_b32_e32 v0, v1, v160, vcc_lo                     // 00000056B350: 02014101
	s_delay_alu instid0(VALU_DEP_1)                            // 00000056B354: BF870001
	v_add_co_ci_u32_e64 v14, null, 0, v0, s0                   // 00000056B358: D5207C0E 00020080
	v_dual_mov_b32 v22, v12 :: v_dual_mov_b32 v25, v26         // 00000056B360: CA10010C 1618011A
	v_mov_b32_e32 v20, v12                                     // 00000056B368: 7E28030C
	v_mov_b32_e32 v18, v12                                     // 00000056B36C: 7E24030C
	v_mov_b32_e32 v16, v12                                     // 00000056B370: 7E20030C
	s_lshl_b64 s[14:15], s[10:11], 2                           // 00000056B374: 848E820A
	s_mul_i32 s17, s10, 6                                      // 00000056B378: 9611860A
	s_mov_b32 s16, 0                                           // 00000056B37C: BE900080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 00000056B380: 8484810A
	s_branch 469                                               // 00000056B384: BFA001D5 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x9dc>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000056B388: 8C7E0A7E
	v_and_b32_e32 v27, 0xff, v4                                // 00000056B38C: 363608FF 000000FF
	s_and_b32 s0, exec_lo, s0                                  // 00000056B394: 8B00007E
	v_add_nc_u32_e32 v23, 0x100, v23                           // 00000056B398: 4A2E2EFF 00000100
	s_or_b32 s16, s0, s16                                      // 00000056B3A0: 8C101000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000056B3A4: BF8700B2
	v_lshlrev_b32_e32 v27, 2, v27                              // 00000056B3A8: 30363682
	ds_load_b32 v43, v27                                       // 00000056B3AC: D8D80000 2B00001B
	v_lshrrev_b32_e32 v27, 6, v4                               // 00000056B3B4: 32360886
	v_and_b32_e32 v27, 0x3fc, v27                              // 00000056B3B8: 363636FF 000003FC
	ds_load_b32 v44, v27                                       // 00000056B3C0: D8D80000 2C00001B
	v_lshrrev_b32_e32 v27, 14, v4                              // 00000056B3C8: 3236088E
	v_lshrrev_b32_e32 v4, 22, v4                               // 00000056B3CC: 32080896
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000056B3D0: BF870112
	v_and_b32_e32 v27, 0x3fc, v27                              // 00000056B3D4: 363636FF 000003FC
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000056B3DC: 360808FF 000003FC
	ds_load_b32 v45, v27                                       // 00000056B3E4: D8D80000 2D00001B
	ds_load_b32 v46, v4                                        // 00000056B3EC: D8D80000 2E000004
	v_and_b32_e32 v4, 0xff, v5                                 // 00000056B3F4: 36080AFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000056B3FC: BF8700B1
	v_lshlrev_b32_e32 v4, 2, v4                                // 00000056B400: 30080882
	ds_load_b32 v47, v4                                        // 00000056B404: D8D80000 2F000004
	v_lshrrev_b32_e32 v4, 6, v5                                // 00000056B40C: 32080A86
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000056B410: 360808FF 000003FC
	ds_load_b32 v48, v4                                        // 00000056B418: D8D80000 30000004
	v_lshrrev_b32_e32 v4, 14, v5                               // 00000056B420: 32080A8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000056B424: BF8700B1
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000056B428: 360808FF 000003FC
	ds_load_b32 v49, v4                                        // 00000056B430: D8D80000 31000004
	v_lshrrev_b32_e32 v4, 22, v5                               // 00000056B438: 32080A96
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000056B43C: 360808FF 000003FC
	ds_load_b32 v50, v4                                        // 00000056B444: D8D80000 32000004
	v_and_b32_e32 v4, 0xff, v6                                 // 00000056B44C: 36080CFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000056B454: BF8700B1
	v_lshlrev_b32_e32 v4, 2, v4                                // 00000056B458: 30080882
	ds_load_b32 v51, v4                                        // 00000056B45C: D8D80000 33000004
	v_lshrrev_b32_e32 v4, 6, v6                                // 00000056B464: 32080C86
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000056B468: 360808FF 000003FC
	ds_load_b32 v52, v4                                        // 00000056B470: D8D80000 34000004
	v_lshrrev_b32_e32 v4, 14, v6                               // 00000056B478: 32080C8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000056B47C: BF8700B1
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000056B480: 360808FF 000003FC
	ds_load_b32 v53, v4                                        // 00000056B488: D8D80000 35000004
	v_lshrrev_b32_e32 v4, 22, v6                               // 00000056B490: 32080C96
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000056B494: 360808FF 000003FC
	ds_load_b32 v54, v4                                        // 00000056B49C: D8D80000 36000004
	v_and_b32_e32 v4, 0xff, v7                                 // 00000056B4A4: 36080EFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000056B4AC: BF8700B1
	v_lshlrev_b32_e32 v4, 2, v4                                // 00000056B4B0: 30080882
	ds_load_b32 v55, v4                                        // 00000056B4B4: D8D80000 37000004
	v_lshrrev_b32_e32 v4, 6, v7                                // 00000056B4BC: 32080E86
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000056B4C0: 360808FF 000003FC
	ds_load_b32 v56, v4                                        // 00000056B4C8: D8D80000 38000004
	v_lshrrev_b32_e32 v4, 14, v7                               // 00000056B4D0: 32080E8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000056B4D4: BF8700B1
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000056B4D8: 360808FF 000003FC
	ds_load_b32 v57, v4                                        // 00000056B4E0: D8D80000 39000004
	v_lshrrev_b32_e32 v4, 22, v7                               // 00000056B4E8: 32080E96
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000056B4EC: 360808FF 000003FC
	ds_load_b32 v58, v4                                        // 00000056B4F4: D8D80000 3A000004
	.long 0xd73c0004                                           // 00000056B4FC: D73C0004
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 00000056B500: 02021681
	v_add_nc_u32_e32 v11, 0x200, v11                           // 00000056B504: 4A1616FF 00000200
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056B50C: BF870092
	.long 0xd7000027                                           // 00000056B510: D7000027
	v_cndmask_b32_e32 v1, s6, v4, vcc_lo                       // 00000056B514: 02020806
	v_add_co_ci_u32_e64 v40, null, s7, v5, s0                  // 00000056B518: D5207C28 00020A07
	s_clause 0x3                                               // 00000056B520: BF850003
	global_load_b128 v[4:7], v[39:40], off                     // 00000056B524: DC5E0000 047C0027
	global_load_b128 v[27:30], v[39:40], off offset:16         // 00000056B52C: DC5E0010 1B7C0027
	global_load_b128 v[31:34], v[39:40], off offset:32         // 00000056B534: DC5E0020 1F7C0027
	global_load_b128 v[35:38], v[39:40], off offset:48         // 00000056B53C: DC5E0030 237C0027
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 00000056B544: BF890CF7
	v_dot2_f32_bf16 v4, v4, v43, 0                             // 00000056B548: CC1A4004 1A025704
	s_waitcnt lgkmcnt(14)                                      // 00000056B550: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056B554: BF8700A1
	v_dot2_f32_bf16 v4, v5, v44, v4                            // 00000056B558: CC1A4004 1C125905
	s_waitcnt lgkmcnt(13)                                      // 00000056B560: BF89FCD7
	v_dot2_f32_bf16 v4, v6, v45, v4                            // 00000056B564: CC1A4004 1C125B06
	s_waitcnt lgkmcnt(12)                                      // 00000056B56C: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056B570: BF8700A1
	v_dot2_f32_bf16 v4, v7, v46, v4                            // 00000056B574: CC1A4004 1C125D07
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 00000056B57C: BF8908B7
	v_dot2_f32_bf16 v4, v27, v47, v4                           // 00000056B580: CC1A4004 1C125F1B
	s_waitcnt lgkmcnt(10)                                      // 00000056B588: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056B58C: BF8700A1
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 00000056B590: CC1A4004 1C12611C
	s_waitcnt lgkmcnt(9)                                       // 00000056B598: BF89FC97
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 00000056B59C: CC1A4004 1C12631D
	s_waitcnt lgkmcnt(8)                                       // 00000056B5A4: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056B5A8: BF8700A1
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 00000056B5AC: CC1A4004 1C12651E
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 00000056B5B4: BF890477
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 00000056B5B8: CC1A4004 1C12671F
	s_waitcnt lgkmcnt(6)                                       // 00000056B5C0: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056B5C4: BF8700A1
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 00000056B5C8: CC1A4004 1C126920
	s_waitcnt lgkmcnt(5)                                       // 00000056B5D0: BF89FC57
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 00000056B5D4: CC1A4004 1C126B21
	s_waitcnt lgkmcnt(4)                                       // 00000056B5DC: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056B5E0: BF8700A1
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 00000056B5E4: CC1A4004 1C126D22
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 00000056B5EC: BF890037
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 00000056B5F0: CC1A4004 1C126F23
	.long 0xd7000023                                           // 00000056B5F8: D7000023
	v_cndmask_b32_e32 v0, v39, v4, vcc_lo                      // 00000056B5FC: 02000927
	s_waitcnt lgkmcnt(2)                                       // 00000056B600: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000056B604: BF8701C2
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 00000056B608: CC1A4004 1C127124
	v_add_co_ci_u32_e64 v36, null, s5, v40, s0                 // 00000056B610: D5207C24 00025005
	.long 0xd7000029                                           // 00000056B618: D7000029
	v_cndmask_b32_e32 v0, v39, v14, vcc_lo                     // 00000056B61C: 02001D27
	s_waitcnt lgkmcnt(1)                                       // 00000056B620: BF89FC17
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 00000056B624: CC1A4004 1C127325
	v_add_co_ci_u32_e64 v42, null, s15, v40, s0                // 00000056B62C: D5207C2A 0002500F
	.long 0xd7000027                                           // 00000056B634: D7000027
	v_cndmask_b32_e32 v0, v39, v17, vcc_lo                     // 00000056B638: 02002327
	s_waitcnt lgkmcnt(0)                                       // 00000056B63C: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000056B640: BF870123
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 00000056B644: CC1A4004 1C127526
	v_add_co_ci_u32_e64 v40, null, s18, v40, s0                // 00000056B64C: D5207C28 00025012
	v_fmac_f32_e32 v21, v26, v4                                // 00000056B654: 562A091A
	s_clause 0x3                                               // 00000056B658: BF850003
	global_load_b128 v[4:7], v[35:36], off                     // 00000056B65C: DC5E0000 047C0023
	global_load_b128 v[27:30], v[35:36], off offset:16         // 00000056B664: DC5E0010 1B7C0023
	global_load_b128 v[31:34], v[35:36], off offset:32         // 00000056B66C: DC5E0020 1F7C0023
	global_load_b128 v[35:38], v[35:36], off offset:48         // 00000056B674: DC5E0030 237C0023
	s_waitcnt vmcnt(3)                                         // 00000056B67C: BF890FF7
	v_dot2_f32_bf16 v4, v4, v43, 0                             // 00000056B680: CC1A4004 1A025704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056B688: BF870091
	v_dot2_f32_bf16 v4, v5, v44, v4                            // 00000056B68C: CC1A4004 1C125905
	v_dot2_f32_bf16 v4, v6, v45, v4                            // 00000056B694: CC1A4004 1C125B06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056B69C: BF8700A1
	v_dot2_f32_bf16 v4, v7, v46, v4                            // 00000056B6A0: CC1A4004 1C125D07
	s_waitcnt vmcnt(2)                                         // 00000056B6A8: BF890BF7
	v_dot2_f32_bf16 v4, v27, v47, v4                           // 00000056B6AC: CC1A4004 1C125F1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056B6B4: BF870091
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 00000056B6B8: CC1A4004 1C12611C
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 00000056B6C0: CC1A4004 1C12631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056B6C8: BF8700A1
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 00000056B6CC: CC1A4004 1C12651E
	s_waitcnt vmcnt(1)                                         // 00000056B6D4: BF8907F7
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 00000056B6D8: CC1A4004 1C12671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056B6E0: BF870091
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 00000056B6E4: CC1A4004 1C126920
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 00000056B6EC: CC1A4004 1C126B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056B6F4: BF8700A1
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 00000056B6F8: CC1A4004 1C126D22
	s_waitcnt vmcnt(0)                                         // 00000056B700: BF8903F7
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 00000056B704: CC1A4004 1C126F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056B70C: BF870091
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 00000056B710: CC1A4004 1C127124
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 00000056B718: CC1A4004 1C127325
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056B720: BF870091
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 00000056B724: CC1A4004 1C127526
	v_fmac_f32_e32 v22, v26, v4                                // 00000056B72C: 562C091A
	s_clause 0x3                                               // 00000056B730: BF850003
	global_load_b128 v[4:7], v[41:42], off                     // 00000056B734: DC5E0000 047C0029
	global_load_b128 v[27:30], v[41:42], off offset:16         // 00000056B73C: DC5E0010 1B7C0029
	global_load_b128 v[31:34], v[41:42], off offset:32         // 00000056B744: DC5E0020 1F7C0029
	global_load_b128 v[35:38], v[41:42], off offset:48         // 00000056B74C: DC5E0030 237C0029
	s_waitcnt vmcnt(3)                                         // 00000056B754: BF890FF7
	v_dot2_f32_bf16 v4, v4, v43, 0                             // 00000056B758: CC1A4004 1A025704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056B760: BF870091
	v_dot2_f32_bf16 v4, v5, v44, v4                            // 00000056B764: CC1A4004 1C125905
	v_dot2_f32_bf16 v4, v6, v45, v4                            // 00000056B76C: CC1A4004 1C125B06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056B774: BF8700A1
	v_dot2_f32_bf16 v4, v7, v46, v4                            // 00000056B778: CC1A4004 1C125D07
	s_waitcnt vmcnt(2)                                         // 00000056B780: BF890BF7
	v_dot2_f32_bf16 v4, v27, v47, v4                           // 00000056B784: CC1A4004 1C125F1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056B78C: BF870091
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 00000056B790: CC1A4004 1C12611C
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 00000056B798: CC1A4004 1C12631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056B7A0: BF8700A1
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 00000056B7A4: CC1A4004 1C12651E
	s_waitcnt vmcnt(1)                                         // 00000056B7AC: BF8907F7
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 00000056B7B0: CC1A4004 1C12671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056B7B8: BF870091
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 00000056B7BC: CC1A4004 1C126920
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 00000056B7C4: CC1A4004 1C126B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056B7CC: BF8700A1
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 00000056B7D0: CC1A4004 1C126D22
	s_waitcnt vmcnt(0)                                         // 00000056B7D8: BF8903F7
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 00000056B7DC: CC1A4004 1C126F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056B7E4: BF870091
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 00000056B7E8: CC1A4004 1C127124
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 00000056B7F0: CC1A4004 1C127325
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056B7F8: BF870091
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 00000056B7FC: CC1A4004 1C127526
	v_fmac_f32_e32 v19, v26, v4                                // 00000056B804: 5626091A
	s_clause 0x3                                               // 00000056B808: BF850003
	global_load_b128 v[4:7], v[39:40], off                     // 00000056B80C: DC5E0000 047C0027
	global_load_b128 v[27:30], v[39:40], off offset:16         // 00000056B814: DC5E0010 1B7C0027
	global_load_b128 v[31:34], v[39:40], off offset:32         // 00000056B81C: DC5E0020 1F7C0027
	global_load_b128 v[35:38], v[39:40], off offset:48         // 00000056B824: DC5E0030 237C0027
	s_waitcnt vmcnt(3)                                         // 00000056B82C: BF890FF7
	v_dot2_f32_bf16 v4, v4, v43, 0                             // 00000056B830: CC1A4004 1A025704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056B838: BF870091
	v_dot2_f32_bf16 v4, v5, v44, v4                            // 00000056B83C: CC1A4004 1C125905
	v_dot2_f32_bf16 v4, v6, v45, v4                            // 00000056B844: CC1A4004 1C125B06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056B84C: BF8700A1
	v_dot2_f32_bf16 v4, v7, v46, v4                            // 00000056B850: CC1A4004 1C125D07
	s_waitcnt vmcnt(2)                                         // 00000056B858: BF890BF7
	v_dot2_f32_bf16 v4, v27, v47, v4                           // 00000056B85C: CC1A4004 1C125F1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056B864: BF870091
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 00000056B868: CC1A4004 1C12611C
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 00000056B870: CC1A4004 1C12631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056B878: BF8700A1
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 00000056B87C: CC1A4004 1C12651E
	s_waitcnt vmcnt(1)                                         // 00000056B884: BF8907F7
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 00000056B888: CC1A4004 1C12671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056B890: BF870091
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 00000056B894: CC1A4004 1C126920
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 00000056B89C: CC1A4004 1C126B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056B8A4: BF8700A1
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 00000056B8A8: CC1A4004 1C126D22
	s_waitcnt vmcnt(0)                                         // 00000056B8B0: BF8903F7
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 00000056B8B4: CC1A4004 1C126F23
	.long 0xd7000023                                           // 00000056B8BC: D7000023
	v_cndmask_b32_e32 v0, v41, v14, vcc_lo                     // 00000056B8C0: 02001D29
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000056B8C4: BF870122
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 00000056B8C8: CC1A4004 1C127124
	v_add_co_ci_u32_e64 v36, null, s15, v42, s0                // 00000056B8D0: D5207C24 0002540F
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 00000056B8D8: CC1A4004 1C127325
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056B8E0: BF870091
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 00000056B8E4: CC1A4004 1C127526
	v_fmac_f32_e32 v20, v26, v4                                // 00000056B8EC: 5628091A
	s_clause 0x3                                               // 00000056B8F0: BF850003
	global_load_b128 v[4:7], v[35:36], off                     // 00000056B8F4: DC5E0000 047C0023
	global_load_b128 v[27:30], v[35:36], off offset:16         // 00000056B8FC: DC5E0010 1B7C0023
	global_load_b128 v[31:34], v[35:36], off offset:32         // 00000056B904: DC5E0020 1F7C0023
	global_load_b128 v[35:38], v[35:36], off offset:48         // 00000056B90C: DC5E0030 237C0023
	s_waitcnt vmcnt(3)                                         // 00000056B914: BF890FF7
	v_dot2_f32_bf16 v4, v4, v43, 0                             // 00000056B918: CC1A4004 1A025704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056B920: BF870091
	v_dot2_f32_bf16 v4, v5, v44, v4                            // 00000056B924: CC1A4004 1C125905
	v_dot2_f32_bf16 v4, v6, v45, v4                            // 00000056B92C: CC1A4004 1C125B06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056B934: BF8700A1
	v_dot2_f32_bf16 v4, v7, v46, v4                            // 00000056B938: CC1A4004 1C125D07
	s_waitcnt vmcnt(2)                                         // 00000056B940: BF890BF7
	v_dot2_f32_bf16 v4, v27, v47, v4                           // 00000056B944: CC1A4004 1C125F1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056B94C: BF870091
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 00000056B950: CC1A4004 1C12611C
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 00000056B958: CC1A4004 1C12631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056B960: BF8700A1
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 00000056B964: CC1A4004 1C12651E
	s_waitcnt vmcnt(1)                                         // 00000056B96C: BF8907F7
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 00000056B970: CC1A4004 1C12671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056B978: BF870091
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 00000056B97C: CC1A4004 1C126920
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 00000056B984: CC1A4004 1C126B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056B98C: BF8700A1
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 00000056B990: CC1A4004 1C126D22
	s_waitcnt vmcnt(0)                                         // 00000056B998: BF8903F7
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 00000056B99C: CC1A4004 1C126F23
	.long 0xd7000023                                           // 00000056B9A4: D7000023
	v_cndmask_b32_e32 v0, v39, v14, vcc_lo                     // 00000056B9A8: 02001D27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000056B9AC: BF8701B2
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 00000056B9B0: CC1A4004 1C127124
	v_add_co_ci_u32_e64 v36, null, s15, v40, s0                // 00000056B9B8: D5207C24 0002500F
	.long 0xd700000d                                           // 00000056B9C0: D700000D
	v_cndmask_b32_e32 v0, v13, v160, vcc_lo                    // 00000056B9C4: 0201410D
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 00000056B9C8: CC1A4004 1C127325
	v_add_co_ci_u32_e64 v14, null, 0, v14, s0                  // 00000056B9D0: D5207C0E 00021C80
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056B9D8: BF870092
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 00000056B9DC: CC1A4004 1C127526
	v_fmac_f32_e32 v18, v26, v4                                // 00000056B9E4: 5624091A
	s_clause 0x3                                               // 00000056B9E8: BF850003
	global_load_b128 v[4:7], v[35:36], off                     // 00000056B9EC: DC5E0000 047C0023
	global_load_b128 v[27:30], v[35:36], off offset:16         // 00000056B9F4: DC5E0010 1B7C0023
	global_load_b128 v[31:34], v[35:36], off offset:32         // 00000056B9FC: DC5E0020 1F7C0023
	global_load_b128 v[35:38], v[35:36], off offset:48         // 00000056BA04: DC5E0030 237C0023
	s_waitcnt vmcnt(3)                                         // 00000056BA0C: BF890FF7
	v_dot2_f32_bf16 v4, v4, v43, 0                             // 00000056BA10: CC1A4004 1A025704
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000056BA18: BF870121
	v_dot2_f32_bf16 v4, v5, v44, v4                            // 00000056BA1C: CC1A4004 1C125905
	v_mov_b32_e32 v5, v1                                       // 00000056BA24: 7E0A0301
	v_dot2_f32_bf16 v4, v6, v45, v4                            // 00000056BA28: CC1A4004 1C125B06
	v_mov_b32_e32 v6, v2                                       // 00000056BA30: 7E0C0302
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000056BA34: BF870132
	v_dot2_f32_bf16 v4, v7, v46, v4                            // 00000056BA38: CC1A4004 1C125D07
	v_mov_b32_e32 v7, v3                                       // 00000056BA40: 7E0E0303
	s_waitcnt vmcnt(2)                                         // 00000056BA44: BF890BF7
	v_dot2_f32_bf16 v4, v27, v47, v4                           // 00000056BA48: CC1A4004 1C125F1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056BA50: BF870091
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 00000056BA54: CC1A4004 1C12611C
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 00000056BA5C: CC1A4004 1C12631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056BA64: BF8700A1
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 00000056BA68: CC1A4004 1C12651E
	s_waitcnt vmcnt(1)                                         // 00000056BA70: BF8907F7
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 00000056BA74: CC1A4004 1C12671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056BA7C: BF870091
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 00000056BA80: CC1A4004 1C126920
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 00000056BA88: CC1A4004 1C126B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056BA90: BF8700A1
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 00000056BA94: CC1A4004 1C126D22
	s_waitcnt vmcnt(0)                                         // 00000056BA9C: BF8903F7
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 00000056BAA0: CC1A4004 1C126F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056BAA8: BF870091
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 00000056BAAC: CC1A4004 1C127124
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 00000056BAB4: CC1A4004 1C127325
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056BABC: BF870091
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 00000056BAC0: CC1A4004 1C127526
	v_fmac_f32_e32 v16, v26, v4                                // 00000056BAC8: 5620091A
	v_mov_b32_e32 v4, v0                                       // 00000056BACC: 7E080300
	v_mov_b32_e32 v26, v25                                     // 00000056BAD0: 7E340319
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 00000056BAD4: 917E107E
	s_cbranch_execz 25                                         // 00000056BAD8: BFA50019 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0xa40>
	s_waitcnt vmcnt(0)                                         // 00000056BADC: BF8903F7
	v_dual_mov_b32 v1, v5 :: v_dual_add_nc_u32 v24, 16, v24    // 00000056BAE0: CA200105 01183090
	v_dual_mov_b32 v0, v4 :: v_dual_mov_b32 v3, v7             // 00000056BAE8: CA100104 00020107
	v_mov_b32_e32 v2, v6                                       // 00000056BAF0: 7E040306
	s_delay_alu instid0(VALU_DEP_3)                            // 00000056BAF4: BF870003
	.long 0xd4430000                                           // 00000056BAF8: D4430000
	v_cndmask_b32_e32 v1, s2, v24, vcc_lo                      // 00000056BAFC: 02023002
	s_mov_b32 s10, exec_lo                                     // 00000056BB00: BE8A007E
	.long 0xd4c4007e                                           // 00000056BB04: D4C4007E
	v_cndmask_b32_e32 v1, s2, v24, vcc_lo                      // 00000056BB08: 02023002
	s_cbranch_execz 65054                                      // 00000056BB0C: BFA5FE1E <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x288>
	.long 0xd7000100                                           // 00000056BB10: D7000100
	v_cndmask_b32_e32 v1, v10, v23, vcc_lo                     // 00000056BB14: 02022F0A
	s_delay_alu instid0(VALU_DEP_1)                            // 00000056BB18: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v17, s1                   // 00000056BB1C: D5207C01 00062280
	global_load_d16_b16 v25, v[13:14], off                     // 00000056BB24: DC820000 197C000D
	global_load_b128 v[0:3], v[0:1], off                       // 00000056BB2C: DC5E0000 007C0000
	s_waitcnt vmcnt(1)                                         // 00000056BB34: BF8907F7
	v_cvt_f32_f16_e32 v25, v25                                 // 00000056BB38: 7E321719
	s_branch 65042                                             // 00000056BB3C: BFA0FE12 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x288>
	s_or_b32 exec_lo, exec_lo, s16                             // 00000056BB40: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056BB44: BF8700A9
	s_or_b32 exec_lo, exec_lo, s3                              // 00000056BB48: 8C7E037E
	.long 0xd71f0000                                           // 00000056BB4C: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000056BB50: 020100C1
	v_xor_b32_e32 v1, 8, v0                                    // 00000056BB54: 3A020088
	s_waitcnt vmcnt(0)                                         // 00000056BB58: BF8903F7
	v_xor_b32_e32 v7, 4, v0                                    // 00000056BB5C: 3A0E0084
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056BB60: BF870092
	.long 0xd44c0000                                           // 00000056BB64: D44C0000
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 00000056BB68: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s0                           // 00000056BB6C: D5010001 00020300
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000056BB74: BF870113
	.long 0xd44c0000                                           // 00000056BB78: D44C0000
	v_cndmask_b32_e32 v1, 32, v7, vcc_lo                       // 00000056BB7C: 02020EA0
	v_lshlrev_b32_e32 v1, 2, v1                                // 00000056BB80: 30020282
	s_delay_alu instid0(VALU_DEP_2)                            // 00000056BB84: BF870002
	v_cndmask_b32_e64 v7, v0, v7, s0                           // 00000056BB88: D5010007 00020F00
	ds_bpermute_b32 v2, v1, v22                                // 00000056BB90: DACC0000 02001601
	s_waitcnt lgkmcnt(0)                                       // 00000056BB98: BF89FC07
	v_add_f32_e32 v2, v22, v2                                  // 00000056BB9C: 06040516
	ds_bpermute_b32 v4, v1, v20                                // 00000056BBA0: DACC0000 04001401
	ds_bpermute_b32 v3, v1, v21                                // 00000056BBA8: DACC0000 03001501
	ds_bpermute_b32 v6, v1, v16                                // 00000056BBB0: DACC0000 06001001
	ds_bpermute_b32 v5, v1, v19                                // 00000056BBB8: DACC0000 05001301
	ds_bpermute_b32 v1, v1, v18                                // 00000056BBC0: DACC0000 01001201
	s_waitcnt lgkmcnt(4)                                       // 00000056BBC8: BF89FC47
	v_dual_add_f32 v4, v20, v4 :: v_dual_lshlrev_b32 v7, 2, v7 // 00000056BBCC: C9220914 04060E82
	s_waitcnt lgkmcnt(2)                                       // 00000056BBD4: BF89FC27
	v_dual_add_f32 v3, v21, v3 :: v_dual_add_f32 v6, v16, v6   // 00000056BBD8: C9080715 03060D10
	v_xor_b32_e32 v16, 2, v0                                   // 00000056BBE0: 3A200082
	ds_bpermute_b32 v10, v7, v2                                // 00000056BBE4: DACC0000 0A000207
	ds_bpermute_b32 v12, v7, v4                                // 00000056BBEC: DACC0000 0C000407
	s_waitcnt lgkmcnt(2)                                       // 00000056BBF4: BF89FC27
	v_add_f32_e32 v1, v18, v1                                  // 00000056BBF8: 06020312
	ds_bpermute_b32 v11, v7, v3                                // 00000056BBFC: DACC0000 0B000307
	.long 0xd44c0000                                           // 00000056BC04: D44C0000
	v_cndmask_b32_e32 v1, 32, v16, vcc_lo                      // 00000056BC08: 020220A0
	ds_bpermute_b32 v14, v7, v6                                // 00000056BC0C: DACC0000 0E000607
	v_cndmask_b32_e64 v16, v0, v16, s0                         // 00000056BC14: D5010010 00022100
	s_delay_alu instid0(VALU_DEP_1)                            // 00000056BC1C: BF870001
	v_dual_add_f32 v5, v19, v5 :: v_dual_lshlrev_b32 v16, 2, v16// 00000056BC20: C9220B13 05102082
	ds_bpermute_b32 v13, v7, v5                                // 00000056BC28: DACC0000 0D000507
	s_waitcnt lgkmcnt(4)                                       // 00000056BC30: BF89FC47
	v_add_f32_e32 v2, v2, v10                                  // 00000056BC34: 06041502
	s_waitcnt lgkmcnt(3)                                       // 00000056BC38: BF89FC37
	v_add_f32_e32 v4, v4, v12                                  // 00000056BC3C: 06081904
	ds_bpermute_b32 v7, v7, v1                                 // 00000056BC40: DACC0000 07000107
	s_waitcnt lgkmcnt(3)                                       // 00000056BC48: BF89FC37
	v_add_f32_e32 v3, v3, v11                                  // 00000056BC4C: 06061703
	v_xor_b32_e32 v10, 1, v0                                   // 00000056BC50: 3A140081
	s_waitcnt lgkmcnt(2)                                       // 00000056BC54: BF89FC27
	v_add_f32_e32 v6, v6, v14                                  // 00000056BC58: 060C1D06
	ds_bpermute_b32 v12, v16, v4                               // 00000056BC5C: DACC0000 0C000410
	ds_bpermute_b32 v11, v16, v3                               // 00000056BC64: DACC0000 0B000310
	.long 0xd44c0000                                           // 00000056BC6C: D44C0000
	v_cndmask_b32_e32 v1, 32, v10, vcc_lo                      // 00000056BC70: 020214A0
	ds_bpermute_b32 v14, v16, v6                               // 00000056BC74: DACC0000 0E000610
	v_cndmask_b32_e64 v0, v0, v10, s0                          // 00000056BC7C: D5010000 00021500
	s_waitcnt lgkmcnt(4)                                       // 00000056BC84: BF89FC47
	v_add_f32_e32 v5, v5, v13                                  // 00000056BC88: 060A1B05
	.long 0xd44a0000                                           // 00000056BC8C: D44A0000
	v_cndmask_b32_e32 v1, 0, v15, vcc_lo                       // 00000056BC90: 02021E80
	ds_bpermute_b32 v13, v16, v5                               // 00000056BC94: DACC0000 0D000510
	s_and_b32 s0, s0, vcc_lo                                   // 00000056BC9C: 8B006A00
	s_waitcnt lgkmcnt(4)                                       // 00000056BCA0: BF89FC47
	v_add_f32_e32 v1, v1, v7                                   // 00000056BCA4: 06020F01
	ds_bpermute_b32 v7, v16, v2                                // 00000056BCA8: DACC0000 07000210
	v_lshlrev_b32_e32 v17, 2, v0                               // 00000056BCB0: 30220082
	s_waitcnt lgkmcnt(4)                                       // 00000056BCB4: BF89FC47
	v_add_f32_e32 v4, v4, v12                                  // 00000056BCB8: 06081904
	ds_bpermute_b32 v16, v16, v1                               // 00000056BCBC: DACC0000 10000110
	s_waitcnt lgkmcnt(3)                                       // 00000056BCC4: BF89FC37
	v_dual_add_f32 v11, v3, v11 :: v_dual_add_f32 v0, v6, v14  // 00000056BCC8: C9081703 0B001D06
	s_waitcnt lgkmcnt(1)                                       // 00000056BCD0: BF89FC17
	v_dual_add_f32 v5, v5, v13 :: v_dual_add_f32 v10, v2, v7   // 00000056BCD4: C9081B05 050A0F02
	ds_bpermute_b32 v13, v17, v11                              // 00000056BCDC: DACC0000 0D000B11
	ds_bpermute_b32 v6, v17, v5                                // 00000056BCE4: DACC0000 06000511
	ds_bpermute_b32 v7, v17, v4                                // 00000056BCEC: DACC0000 07000411
	s_waitcnt lgkmcnt(3)                                       // 00000056BCF4: BF89FC37
	v_add_f32_e32 v1, v1, v16                                  // 00000056BCF8: 06022101
	ds_bpermute_b32 v12, v17, v10                              // 00000056BCFC: DACC0000 0C000A11
	ds_bpermute_b32 v3, v17, v0                                // 00000056BD04: DACC0000 03000011
	ds_bpermute_b32 v2, v17, v1                                // 00000056BD0C: DACC0000 02000111
	s_and_saveexec_b32 s1, s0                                  // 00000056BD14: BE812000
	s_cbranch_execz 88                                         // 00000056BD18: BFA50058 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0xd7c>
	s_waitcnt lgkmcnt(2)                                       // 00000056BD1C: BF89FC27
	v_dual_add_f32 v11, v11, v13 :: v_dual_add_f32 v12, v10, v12// 00000056BD20: C9081B0B 0B0C190A
	.long 0x7f1a3880                                           // 00000056BD28: 7F1A3880
	.long 0xd73c0008                                           // 00000056BD2C: D73C0008
	v_cndmask_b32_e32 v1, 1, v8, vcc_lo                        // 00000056BD30: 02021081
	s_lshl_b64 s[0:1], s[12:13], 1                             // 00000056BD34: 8480810C
	s_delay_alu instid0(VALU_DEP_3)                            // 00000056BD38: BF870003
	.long 0x7e14398b                                           // 00000056BD3C: 7E14398B
	.long 0x7e1a398c                                           // 00000056BD40: 7E1A398C
	.long 0x7f14398d                                           // 00000056BD44: 7F14398D
	s_waitcnt lgkmcnt(0)                                       // 00000056BD48: BF89FC07
	v_add_f32_e32 v16, v1, v2                                  // 00000056BD4C: 06200501
	.long 0xd7006a08                                           // 00000056BD50: D7006A08
	v_cndmask_b32_e32 v1, s8, v8, vcc_lo                       // 00000056BD54: 02021008
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000056BD58: BF8701B3
	v_dual_add_f32 v7, v4, v7 :: v_dual_and_b32 v10, 1, v10    // 00000056BD5C: C9240F04 070A1481
	v_add_co_ci_u32_e64 v9, null, s9, v9, vcc_lo               // 00000056BD64: D5207C09 01AA1209
	v_and_b32_e32 v14, 1, v13                                  // 00000056BD6C: 361C1A81
	.long 0x7e1a3987                                           // 00000056BD70: 7E1A3987
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056BD74: BF8700A4
	v_add3_u32 v15, v11, v10, 0x7fff                           // 00000056BD78: D655000F 03FE150B 00007FFF
	.long 0xd7006a0a                                           // 00000056BD84: D7006A0A
	v_cndmask_b32_e32 v0, v8, v0, vcc_lo                       // 00000056BD88: 02000108
	v_add_co_ci_u32_e64 v11, null, s1, v9, vcc_lo              // 00000056BD8C: D5207C0B 01AA1201
	s_lshl_b64 s[0:1], s[12:13], 2                             // 00000056BD94: 8480820C
	global_store_d16_hi_b16 v[8:9], v15, off                   // 00000056BD98: DC960000 007C0F08
	.long 0xd7006a04                                           // 00000056BDA0: D7006A04
	v_cndmask_b32_e32 v0, v8, v0, vcc_lo                       // 00000056BDA4: 02000108
	v_add_f32_e32 v15, v0, v3                                  // 00000056BDA8: 061E0700
	v_mad_u64_u32 v[0:1], null, s12, 6, v[8:9]                 // 00000056BDAC: D6FE7C00 04210C0C
	v_and_b32_e32 v2, 1, v13                                   // 00000056BDB4: 36041A81
	.long 0x7e103990                                           // 00000056BDB8: 7E103990
	.long 0x7f10398d                                           // 00000056BDBC: 7F10398D
	v_add_f32_e32 v6, v5, v6                                   // 00000056BDC0: 060C0D05
	v_add3_u32 v12, v12, v14, 0x7fff                           // 00000056BDC4: D655000C 03FE1D0C 00007FFF
	v_add_co_ci_u32_e64 v5, null, s1, v9, vcc_lo               // 00000056BDD0: D5207C05 01AA1201
	.long 0x7f1c398d                                           // 00000056BDD8: 7F1C398D
	v_add3_u32 v9, v7, v2, 0x7fff                              // 00000056BDDC: D6550009 03FE0507 00007FFF
	v_and_b32_e32 v7, 1, v8                                    // 00000056BDE8: 360E1081
	.long 0x7e1c3986                                           // 00000056BDEC: 7E1C3986
	.long 0x7e1a398f                                           // 00000056BDF0: 7E1A398F
	v_mad_u64_u32 v[1:2], null, s13, 6, v[1:2]                 // 00000056BDF4: D6FE7C01 04050C0D
	.long 0xd7006a02                                           // 00000056BDFC: D7006A02
	v_cndmask_b32_e32 v0, v4, v0, vcc_lo                       // 00000056BE00: 02000104
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056BE04: BF870094
	v_and_b32_e32 v3, 1, v14                                   // 00000056BE08: 36061C81
	v_add3_u32 v14, v6, v3, 0x7fff                             // 00000056BE0C: D655000E 03FE0706 00007FFF
	v_and_b32_e32 v6, 1, v13                                   // 00000056BE18: 360C1A81
	v_add_co_ci_u32_e64 v3, null, s1, v5, vcc_lo               // 00000056BE1C: D5207C03 01AA0A01
	v_add3_u32 v13, v16, v7, 0x7fff                            // 00000056BE24: D655000D 03FE0F10 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056BE30: BF8700A3
	v_add3_u32 v8, v15, v6, 0x7fff                             // 00000056BE34: D6550008 03FE0D0F 00007FFF
	.long 0xd7006a06                                           // 00000056BE40: D7006A06
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 00000056BE44: 02000100
	v_add_co_ci_u32_e64 v7, null, s1, v1, vcc_lo               // 00000056BE48: D5207C07 01AA0201
	s_clause 0x4                                               // 00000056BE50: BF850004
	global_store_d16_hi_b16 v[10:11], v12, off                 // 00000056BE54: DC960000 007C0C0A
	global_store_d16_hi_b16 v[4:5], v14, off                   // 00000056BE5C: DC960000 007C0E04
	global_store_d16_hi_b16 v[0:1], v9, off                    // 00000056BE64: DC960000 007C0900
	global_store_d16_hi_b16 v[2:3], v13, off                   // 00000056BE6C: DC960000 007C0D02
	global_store_d16_hi_b16 v[6:7], v8, off                    // 00000056BE74: DC960000 007C0806
	s_endpgm                                                   // 00000056BE7C: BFB00000
		...

