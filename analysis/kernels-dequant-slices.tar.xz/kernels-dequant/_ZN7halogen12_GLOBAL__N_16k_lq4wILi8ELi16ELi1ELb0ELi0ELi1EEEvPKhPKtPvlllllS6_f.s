000000000057af00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi16ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi16ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 00000057AF00: F4100100 F8000000
	v_and_b32_e32 v30, 15, v0                                  // 00000057AF08: 363C008F
	v_lshrrev_b32_e32 v1, 4, v0                                // 00000057AF0C: 32020084
	s_ashr_i32 s3, s2, 31                                      // 00000057AF10: 86039F02
	v_lshlrev_b32_e32 v7, 2, v0                                // 00000057AF14: 300E0082
	s_lshl_b64 s[0:1], s[2:3], 4                               // 00000057AF18: 84808402
	v_lshlrev_b32_e32 v2, 2, v30                               // 00000057AF1C: 30043C82
	v_dual_mov_b32 v24, s1 :: v_dual_lshlrev_b32 v3, 2, v1     // 00000057AF20: CA220001 18020282
	v_or_b32_e32 v23, s0, v1                                   // 00000057AF28: 382E0200
	.long 0x7f0c3880                                           // 00000057AF2C: 7F0C3880
	s_waitcnt lgkmcnt(0)                                       // 00000057AF30: BF89FC07
	s_clause 0x1                                               // 00000057AF34: BF850001
	global_load_b32 v4, v2, s[4:5]                             // 00000057AF38: DC520000 04040002
	global_load_b32 v3, v3, s[4:5]                             // 00000057AF40: DC520000 03040003
	.long 0xd4540000                                           // 00000057AF48: D4540000
	v_cndmask_b32_e32 v1, s12, v23, vcc_lo                     // 00000057AF4C: 02022E0C
	s_add_u32 s22, s4, s16                                     // 00000057AF50: 80161004
	s_addc_u32 s23, s5, s17                                    // 00000057AF54: 82171105
	s_ashr_i32 s2, s11, 31                                     // 00000057AF58: 86029F0B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 00000057AF5C: BF870159
	s_lshr_b32 s2, s2, 27                                      // 00000057AF60: 85029B02
	v_cndmask_b32_e64 v2, 0, v23, s0                           // 00000057AF64: D5010002 00022E80
	v_cndmask_b32_e64 v5, 0, s1, s0                            // 00000057AF6C: D5010005 00000280
	s_add_u32 s2, s10, s2                                      // 00000057AF74: 8002020A
	s_addc_u32 s3, s11, 0                                      // 00000057AF78: 8203800B
	.long 0xd72c0008                                           // 00000057AF7C: D72C0008
	v_cndmask_b32_e32 v1, s19, v2, vcc_lo                      // 00000057AF80: 02020413
	v_mad_u64_u32 v[0:1], null, s18, v2, 0                     // 00000057AF84: D6FE7C00 02020412
	s_lshr_b64 s[20:21], s[2:3], 5                             // 00000057AF8C: 85948502
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000057AF90: BF870009
	s_cmpk_lt_i32 s20, 0x81                                    // 00000057AF94: B3940081
	.long 0xd4440002                                           // 00000057AF98: D4440002
	v_cndmask_b32_e32 v1, s20, v30, vcc_lo                     // 00000057AF9C: 02023C14
	s_cselect_b32 s1, -1, 0                                    // 00000057AFA0: 980180C1
	s_cmpk_gt_i32 s20, 0x80                                    // 00000057AFA4: B2940080
	s_waitcnt vmcnt(1)                                         // 00000057AFA8: BF8907F7
	v_bfe_u32 v9, v4, 16, 1                                    // 00000057AFAC: D6100009 02052104
	s_waitcnt vmcnt(0)                                         // 00000057AFB4: BF8903F7
	v_bfe_u32 v10, v3, 16, 1                                   // 00000057AFB8: D610000A 02052103
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000057AFC0: BF8701A2
	v_add3_u32 v4, v4, v9, 0x7fff                              // 00000057AFC4: D6550004 03FE1304 00007FFF
	.long 0xd72c0009                                           // 00000057AFD0: D72C0009
	v_cndmask_b32_e32 v1, s18, v5, vcc_lo                      // 00000057AFD4: 02020A12
	v_add3_u32 v3, v3, v10, 0x7fff                             // 00000057AFD8: D6550003 03FE1503 00007FFF
	s_cselect_b32 s18, -1, 0                                   // 00000057AFE4: 981280C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000057AFE8: BF8701A9
	s_and_b32 vcc_lo, exec_lo, s18                             // 00000057AFEC: 8B6A127E
	.long 0x7e0c3984                                           // 00000057AFF0: 7E0C3984
	v_add3_u32 v1, v1, v9, v8                                  // 00000057AFF4: D6550001 04221301
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057AFFC: BF8700A2
	v_and_or_b32 v6, 0xffff0000, v3, v6                        // 00000057B000: D6570006 041A06FF FFFF0000
	.long 0xd7000303                                           // 00000057B00C: D7000303
	v_cndmask_b32_e32 v1, s22, v0, vcc_lo                      // 00000057B010: 02020016
	v_add_co_ci_u32_e64 v4, null, s23, v1, s3                  // 00000057B014: D5207C04 000E0217
	ds_store_b32 v7, v6                                        // 00000057B01C: D8340000 00000607
	s_waitcnt lgkmcnt(0)                                       // 00000057B024: BF89FC07
	s_barrier                                                  // 00000057B028: BFBD0000
	buffer_gl0_inv                                             // 00000057B02C: E0AC0000 00000000
	s_cbranch_vccnz 144                                        // 00000057B034: BFA40090 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi16ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x378>
	v_dual_mov_b32 v8, 0 :: v_dual_mov_b32 v7, 0               // 00000057B038: CA100080 08060080
	s_and_saveexec_b32 s3, s2                                  // 00000057B040: BE832002
	s_cbranch_execz 10                                         // 00000057B044: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi16ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x170>
	v_lshlrev_b32_e32 v6, 1, v30                               // 00000057B048: 300C3C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057B04C: BF870091
	.long 0xd7006a06                                           // 00000057B050: D7006A06
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000057B054: 02020D03
	v_add_co_ci_u32_e64 v7, null, 0, v4, vcc_lo                // 00000057B058: D5207C07 01AA0880
	global_load_d16_b16 v6, v[6:7], off                        // 00000057B060: DC820000 067C0006
	s_waitcnt vmcnt(0)                                         // 00000057B068: BF8903F7
	v_cvt_f32_f16_e32 v7, v6                                   // 00000057B06C: 7E0E1706
	s_or_b32 exec_lo, exec_lo, s3                              // 00000057B070: 8C7E037E
	v_or_b32_e32 v6, 16, v30                                   // 00000057B074: 380C3C90
	s_mov_b32 s2, exec_lo                                      // 00000057B078: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000057B07C: BF870001
	.long 0xd4c4007e                                           // 00000057B080: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 00000057B084: 02020C14
	s_cbranch_execz 10                                         // 00000057B088: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi16ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x1b4>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000057B08C: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057B090: BF870091
	.long 0xd7006a08                                           // 00000057B094: D7006A08
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000057B098: 02020D03
	v_add_co_ci_u32_e64 v9, null, 0, v4, vcc_lo                // 00000057B09C: D5207C09 01AA0880
	global_load_d16_b16 v6, v[8:9], off                        // 00000057B0A4: DC820000 067C0008
	s_waitcnt vmcnt(0)                                         // 00000057B0AC: BF8903F7
	v_cvt_f32_f16_e32 v8, v6                                   // 00000057B0B0: 7E101706
	s_or_b32 exec_lo, exec_lo, s2                              // 00000057B0B4: 8C7E027E
	v_or_b32_e32 v6, 32, v30                                   // 00000057B0B8: 380C3CA0
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v9, 0              // 00000057B0BC: CA100080 0A080080
	s_mov_b32 s2, exec_lo                                      // 00000057B0C4: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000057B0C8: BF870002
	.long 0xd4c4007e                                           // 00000057B0CC: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 00000057B0D0: 02020C14
	s_cbranch_execz 10                                         // 00000057B0D4: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi16ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x200>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000057B0D8: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057B0DC: BF870091
	.long 0xd7006a0b                                           // 00000057B0E0: D7006A0B
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000057B0E4: 02020D03
	v_add_co_ci_u32_e64 v12, null, 0, v4, vcc_lo               // 00000057B0E8: D5207C0C 01AA0880
	global_load_d16_b16 v6, v[11:12], off                      // 00000057B0F0: DC820000 067C000B
	s_waitcnt vmcnt(0)                                         // 00000057B0F8: BF8903F7
	v_cvt_f32_f16_e32 v9, v6                                   // 00000057B0FC: 7E121706
	s_or_b32 exec_lo, exec_lo, s2                              // 00000057B100: 8C7E027E
	v_or_b32_e32 v6, 48, v30                                   // 00000057B104: 380C3CB0
	s_mov_b32 s2, exec_lo                                      // 00000057B108: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000057B10C: BF870001
	.long 0xd4c4007e                                           // 00000057B110: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 00000057B114: 02020C14
	s_cbranch_execz 10                                         // 00000057B118: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi16ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x244>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000057B11C: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057B120: BF870091
	.long 0xd7006a0a                                           // 00000057B124: D7006A0A
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000057B128: 02020D03
	v_add_co_ci_u32_e64 v11, null, 0, v4, vcc_lo               // 00000057B12C: D5207C0B 01AA0880
	global_load_d16_b16 v6, v[10:11], off                      // 00000057B134: DC820000 067C000A
	s_waitcnt vmcnt(0)                                         // 00000057B13C: BF8903F7
	v_cvt_f32_f16_e32 v10, v6                                  // 00000057B140: 7E141706
	s_or_b32 exec_lo, exec_lo, s2                              // 00000057B144: 8C7E027E
	v_or_b32_e32 v6, 64, v30                                   // 00000057B148: 380C3CC0
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v11, 0             // 00000057B14C: CA100080 0C0A0080
	s_mov_b32 s2, exec_lo                                      // 00000057B154: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000057B158: BF870002
	.long 0xd4c4007e                                           // 00000057B15C: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 00000057B160: 02020C14
	s_cbranch_execz 10                                         // 00000057B164: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi16ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x290>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000057B168: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057B16C: BF870091
	.long 0xd7006a0d                                           // 00000057B170: D7006A0D
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000057B174: 02020D03
	v_add_co_ci_u32_e64 v14, null, 0, v4, vcc_lo               // 00000057B178: D5207C0E 01AA0880
	global_load_d16_b16 v6, v[13:14], off                      // 00000057B180: DC820000 067C000D
	s_waitcnt vmcnt(0)                                         // 00000057B188: BF8903F7
	v_cvt_f32_f16_e32 v11, v6                                  // 00000057B18C: 7E161706
	s_or_b32 exec_lo, exec_lo, s2                              // 00000057B190: 8C7E027E
	v_or_b32_e32 v6, 0x50, v30                                 // 00000057B194: 380C3CFF 00000050
	s_mov_b32 s2, exec_lo                                      // 00000057B19C: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000057B1A0: BF870001
	.long 0xd4c4007e                                           // 00000057B1A4: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 00000057B1A8: 02020C14
	s_cbranch_execz 10                                         // 00000057B1AC: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi16ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x2d8>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000057B1B0: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057B1B4: BF870091
	.long 0xd7006a0c                                           // 00000057B1B8: D7006A0C
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000057B1BC: 02020D03
	v_add_co_ci_u32_e64 v13, null, 0, v4, vcc_lo               // 00000057B1C0: D5207C0D 01AA0880
	global_load_d16_b16 v6, v[12:13], off                      // 00000057B1C8: DC820000 067C000C
	s_waitcnt vmcnt(0)                                         // 00000057B1D0: BF8903F7
	v_cvt_f32_f16_e32 v12, v6                                  // 00000057B1D4: 7E181706
	s_or_b32 exec_lo, exec_lo, s2                              // 00000057B1D8: 8C7E027E
	v_or_b32_e32 v6, 0x60, v30                                 // 00000057B1DC: 380C3CFF 00000060
	v_dual_mov_b32 v14, 0 :: v_dual_mov_b32 v13, 0             // 00000057B1E4: CA100080 0E0C0080
	s_mov_b32 s2, exec_lo                                      // 00000057B1EC: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000057B1F0: BF870002
	.long 0xd4c4007e                                           // 00000057B1F4: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 00000057B1F8: 02020C14
	s_cbranch_execz 10                                         // 00000057B1FC: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi16ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x328>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000057B200: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057B204: BF870091
	.long 0xd7006a0f                                           // 00000057B208: D7006A0F
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000057B20C: 02020D03
	v_add_co_ci_u32_e64 v16, null, 0, v4, vcc_lo               // 00000057B210: D5207C10 01AA0880
	global_load_d16_b16 v6, v[15:16], off                      // 00000057B218: DC820000 067C000F
	s_waitcnt vmcnt(0)                                         // 00000057B220: BF8903F7
	v_cvt_f32_f16_e32 v13, v6                                  // 00000057B224: 7E1A1706
	s_or_b32 exec_lo, exec_lo, s2                              // 00000057B228: 8C7E027E
	v_or_b32_e32 v6, 0x70, v30                                 // 00000057B22C: 380C3CFF 00000070
	s_mov_b32 s2, exec_lo                                      // 00000057B234: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000057B238: BF870001
	.long 0xd4c4007e                                           // 00000057B23C: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 00000057B240: 02020C14
	s_cbranch_execz 10                                         // 00000057B244: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi16ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x370>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000057B248: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057B24C: BF870091
	.long 0xd7006a0e                                           // 00000057B250: D7006A0E
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000057B254: 02020D03
	v_add_co_ci_u32_e64 v15, null, 0, v4, vcc_lo               // 00000057B258: D5207C0F 01AA0880
	global_load_d16_b16 v6, v[14:15], off                      // 00000057B260: DC820000 067C000E
	s_waitcnt vmcnt(0)                                         // 00000057B268: BF8903F7
	v_cvt_f32_f16_e32 v14, v6                                  // 00000057B26C: 7E1C1706
	s_or_b32 exec_lo, exec_lo, s2                              // 00000057B270: 8C7E027E
	s_branch 9                                                 // 00000057B274: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi16ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x39c>
	v_mov_b32_e32 v7, 0                                        // 00000057B278: 7E0E0280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000057B27C: BF870001
	v_mov_b32_e32 v8, v7                                       // 00000057B280: 7E100307
	v_mov_b32_e32 v9, v7                                       // 00000057B284: 7E120307
	v_mov_b32_e32 v10, v7                                      // 00000057B288: 7E140307
	v_mov_b32_e32 v11, v7                                      // 00000057B28C: 7E160307
	v_mov_b32_e32 v12, v7                                      // 00000057B290: 7E180307
	v_mov_b32_e32 v13, v7                                      // 00000057B294: 7E1A0307
	v_mov_b32_e32 v14, v7                                      // 00000057B298: 7E1C0307
	s_add_u32 s2, s4, s14                                      // 00000057B29C: 80020E04
	s_addc_u32 s3, s5, s15                                     // 00000057B2A0: 82030F05
	s_lshr_b32 s14, s11, 31                                    // 00000057B2A4: 850E9F0B
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v44, 0             // 00000057B2A8: CA100080 132C0080
	s_add_u32 s14, s10, s14                                    // 00000057B2B0: 800E0E0A
	s_addc_u32 s15, s11, 0                                     // 00000057B2B4: 820F800B
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v20, 0             // 00000057B2B8: CA100080 1F140080
	s_ashr_i64 s[14:15], s[14:15], 1                           // 00000057B2C0: 868E810E
	v_cndmask_b32_e64 v32, 0, 1, s18                           // 00000057B2C4: D5010020 00490280
	v_mad_u64_u32 v[25:26], null, v2, s14, s[2:3]              // 00000057B2CC: D6FE7C19 00081D02
	.long 0xd72c0002                                           // 00000057B2D4: D72C0002
	v_cndmask_b32_e32 v0, v2, v15, vcc_lo                      // 00000057B2D8: 02001F02
	.long 0xd72c0005                                           // 00000057B2DC: D72C0005
	v_cndmask_b32_e32 v0, v5, v14, vcc_lo                      // 00000057B2E0: 02001D05
	.long 0xd4440002                                           // 00000057B2E4: D4440002
	v_cndmask_b32_e32 v1, s20, v30, vcc_lo                     // 00000057B2E8: 02023C14
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v22, 0             // 00000057B2EC: CA100080 15160080
	s_delay_alu instid0(VALU_DEP_3)                            // 00000057B2F4: BF870003
	v_add3_u32 v33, v5, v26, v2                                // 00000057B2F8: D6550021 040A3505
	s_and_saveexec_b32 s3, s2                                  // 00000057B300: BE832002
	s_cbranch_execz 21                                         // 00000057B304: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi16ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x45c>
	v_lshlrev_b32_e32 v2, 4, v30                               // 00000057B308: 30043C84
	v_mov_b32_e32 v44, 0                                       // 00000057B30C: 7E580280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057B310: BF870092
	.long 0xd7006a05                                           // 00000057B314: D7006A05
	v_cndmask_b32_e32 v1, v25, v2, vcc_lo                      // 00000057B318: 02020519
	v_add_co_ci_u32_e64 v6, null, 0, v33, vcc_lo               // 00000057B31C: D5207C06 01AA4280
	s_and_not1_b32 vcc_lo, exec_lo, s18                        // 00000057B324: 916A127E
	global_load_b128 v[19:22], v[5:6], off                     // 00000057B328: DC5E0000 137C0005
	s_cbranch_vccnz 10                                         // 00000057B330: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi16ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x45c>
	v_lshlrev_b32_e32 v2, 1, v30                               // 00000057B334: 30043C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057B338: BF870091
	.long 0xd7006a02                                           // 00000057B33C: D7006A02
	v_cndmask_b32_e32 v1, v3, v2, vcc_lo                       // 00000057B340: 02020503
	v_add_co_ci_u32_e64 v3, null, 0, v4, vcc_lo                // 00000057B344: D5207C03 01AA0880
	global_load_d16_b16 v2, v[2:3], off                        // 00000057B34C: DC820000 027C0002
	s_waitcnt vmcnt(0)                                         // 00000057B354: BF8903F7
	v_cvt_f32_f16_e32 v44, v2                                  // 00000057B358: 7E581702
	s_or_b32 exec_lo, exec_lo, s3                              // 00000057B35C: 8C7E037E
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v35, 0             // 00000057B360: CA100080 22220080
	v_dual_mov_b32 v36, 0 :: v_dual_mov_b32 v37, 0             // 00000057B368: CA100080 24240080
	v_dual_mov_b32 v38, 0 :: v_dual_mov_b32 v39, 0             // 00000057B370: CA100080 26260080
	v_mov_b32_e32 v40, 0                                       // 00000057B378: 7E500280
	s_and_saveexec_b32 s3, s2                                  // 00000057B37C: BE832002
	s_cbranch_execz 685                                        // 00000057B380: BFA502AD <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi16ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xf38>
	v_dual_mov_b32 v27, 0 :: v_dual_lshlrev_b32 v2, 1, v30     // 00000057B384: CA220080 1B023C81
	.long 0xd7006a00                                           // 00000057B38C: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 00000057B390: 02020010
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000057B394: BF870191
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 00000057B398: D5207C01 01AA0211
	v_dual_mov_b32 v39, v27 :: v_dual_lshlrev_b32 v26, 5, v30  // 00000057B3A0: CA22011B 271A3C85
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057B3A8: BF870093
	.long 0xd7006a00                                           // 00000057B3AC: D7006A00
	v_cndmask_b32_e32 v1, v0, v2, vcc_lo                       // 00000057B3B0: 02020500
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 00000057B3B4: D5207C01 01AA0280
	v_lshl_or_b32 v41, v30, 4, 0x100                           // 00000057B3BC: D6560029 03FD091E 00000100
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057B3C8: BF870093
	.long 0xd7006a00                                           // 00000057B3CC: D7006A00
	v_cndmask_b32_e32 v1, s4, v0, vcc_lo                       // 00000057B3D0: 02020004
	v_add_co_ci_u32_e64 v1, null, s5, v1, vcc_lo               // 00000057B3D4: D5207C01 01AA0205
	v_dual_mov_b32 v42, v30 :: v_dual_mov_b32 v37, v27         // 00000057B3DC: CA10011E 2A24011B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057B3E4: BF870093
	.long 0xd7006a1c                                           // 00000057B3E8: D7006A1C
	v_cndmask_b32_e32 v0, v0, v160, vcc_lo                     // 00000057B3EC: 02014100
	v_add_co_ci_u32_e64 v29, null, 0, v1, vcc_lo               // 00000057B3F0: D5207C1D 01AA0280
	v_dual_mov_b32 v40, v27 :: v_dual_mov_b32 v43, v44         // 00000057B3F8: CA10011B 282A012C
	v_mov_b32_e32 v38, v27                                     // 00000057B400: 7E4C031B
	v_mov_b32_e32 v35, v27                                     // 00000057B404: 7E46031B
	v_mov_b32_e32 v36, v27                                     // 00000057B408: 7E48031B
	v_mov_b32_e32 v34, v27                                     // 00000057B40C: 7E44031B
	v_mov_b32_e32 v31, v27                                     // 00000057B410: 7E3E031B
	s_mul_i32 s2, s11, 6                                       // 00000057B414: 9602860B
	s_mul_hi_u32 s18, s10, 6                                   // 00000057B418: 9692860A
	s_lshl_b64 s[14:15], s[10:11], 2                           // 00000057B41C: 848E820A
	s_add_i32 s18, s18, s2                                     // 00000057B420: 81120212
	s_mul_i32 s17, s10, 6                                      // 00000057B424: 9611860A
	s_mov_b32 s16, 0                                           // 00000057B428: BE900080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 00000057B42C: 8484810A
	s_branch 612                                               // 00000057B430: BFA00264 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi16ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xec4>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000057B434: 8C7E0A7E
	v_cndmask_b32_e64 v44, v44, v7, s1                         // 00000057B438: D501002C 00060F2C
	v_cndmask_b32_e64 v1, v8, v9, s1                           // 00000057B440: D5010001 00061308
	v_cndmask_b32_e64 v0, v7, v8, s1                           // 00000057B448: D5010000 00061107
	v_dual_mov_b32 v7, v14 :: v_dual_and_b32 v8, 0xff, v19     // 00000057B450: CA24010E 070826FF 000000FF
	v_cndmask_b32_e64 v6, v13, v14, s1                         // 00000057B45C: D5010006 00061D0D
	v_cndmask_b32_e64 v5, v12, v13, s1                         // 00000057B464: D5010005 00061B0C
	v_cndmask_b32_e64 v4, v11, v12, s1                         // 00000057B46C: D5010004 0006190B
	v_cndmask_b32_e64 v3, v10, v11, s1                         // 00000057B474: D5010003 0006170A
	v_lshlrev_b32_e32 v8, 2, v8                                // 00000057B47C: 30101082
	v_cndmask_b32_e64 v2, v9, v10, s1                          // 00000057B480: D5010002 00061509
	s_and_b32 s2, exec_lo, s2                                  // 00000057B488: 8B02027E
	v_add_nc_u32_e32 v41, 0x100, v41                           // 00000057B48C: 4A5252FF 00000100
	s_or_b32 s16, s2, s16                                      // 00000057B494: 8C101002
	ds_load_b32 v14, v8                                        // 00000057B498: D8D80000 0E000008
	v_lshrrev_b32_e32 v8, 6, v19                               // 00000057B4A0: 32102686
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000057B4A4: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000057B4A8: 361010FF 000003FC
	ds_load_b32 v55, v8                                        // 00000057B4B0: D8D80000 37000008
	v_lshrrev_b32_e32 v8, 14, v19                              // 00000057B4B8: 3210268E
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000057B4BC: 361010FF 000003FC
	ds_load_b32 v56, v8                                        // 00000057B4C4: D8D80000 38000008
	v_lshrrev_b32_e32 v8, 22, v19                              // 00000057B4CC: 32102696
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000057B4D0: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000057B4D4: 361010FF 000003FC
	ds_load_b32 v57, v8                                        // 00000057B4DC: D8D80000 39000008
	v_and_b32_e32 v8, 0xff, v20                                // 00000057B4E4: 361028FF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 00000057B4EC: 30101082
	ds_load_b32 v58, v8                                        // 00000057B4F0: D8D80000 3A000008
	v_lshrrev_b32_e32 v8, 6, v20                               // 00000057B4F8: 32102886
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000057B4FC: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000057B500: 361010FF 000003FC
	ds_load_b32 v59, v8                                        // 00000057B508: D8D80000 3B000008
	v_lshrrev_b32_e32 v8, 14, v20                              // 00000057B510: 3210288E
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000057B514: 361010FF 000003FC
	ds_load_b32 v60, v8                                        // 00000057B51C: D8D80000 3C000008
	v_lshrrev_b32_e32 v8, 22, v20                              // 00000057B524: 32102896
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000057B528: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000057B52C: 361010FF 000003FC
	ds_load_b32 v61, v8                                        // 00000057B534: D8D80000 3D000008
	v_and_b32_e32 v8, 0xff, v21                                // 00000057B53C: 36102AFF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 00000057B544: 30101082
	ds_load_b32 v62, v8                                        // 00000057B548: D8D80000 3E000008
	v_lshrrev_b32_e32 v8, 6, v21                               // 00000057B550: 32102A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000057B554: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000057B558: 361010FF 000003FC
	ds_load_b32 v63, v8                                        // 00000057B560: D8D80000 3F000008
	v_lshrrev_b32_e32 v8, 14, v21                              // 00000057B568: 32102A8E
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000057B56C: 361010FF 000003FC
	ds_load_b32 v64, v8                                        // 00000057B574: D8D80000 40000008
	v_lshrrev_b32_e32 v8, 22, v21                              // 00000057B57C: 32102A96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000057B580: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000057B584: 361010FF 000003FC
	ds_load_b32 v65, v8                                        // 00000057B58C: D8D80000 41000008
	v_and_b32_e32 v8, 0xff, v22                                // 00000057B594: 36102CFF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 00000057B59C: 30101082
	ds_load_b32 v66, v8                                        // 00000057B5A0: D8D80000 42000008
	v_lshrrev_b32_e32 v8, 6, v22                               // 00000057B5A8: 32102C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000057B5AC: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000057B5B0: 361010FF 000003FC
	ds_load_b32 v67, v8                                        // 00000057B5B8: D8D80000 43000008
	v_lshrrev_b32_e32 v8, 14, v22                              // 00000057B5C0: 32102C8E
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000057B5C4: 361010FF 000003FC
	ds_load_b32 v68, v8                                        // 00000057B5CC: D8D80000 44000008
	v_lshrrev_b32_e32 v8, 22, v22                              // 00000057B5D4: 32102C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000057B5D8: BF870141
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000057B5DC: 361010FF 000003FC
	ds_load_b32 v69, v8                                        // 00000057B5E4: D8D80000 45000008
	.long 0xd73c0008                                           // 00000057B5EC: D73C0008
	v_cndmask_b32_e32 v1, 1, v26, vcc_lo                       // 00000057B5F0: 02023481
	v_add_nc_u32_e32 v26, 0x200, v26                           // 00000057B5F4: 4A3434FF 00000200
	.long 0xd7006a0c                                           // 00000057B5FC: D7006A0C
	v_cndmask_b32_e32 v1, s6, v8, vcc_lo                       // 00000057B600: 02021006
	s_delay_alu instid0(VALU_DEP_1)                            // 00000057B604: BF870001
	v_add_co_ci_u32_e64 v13, null, s7, v9, vcc_lo              // 00000057B608: D5207C0D 01AA1207
	s_clause 0x3                                               // 00000057B610: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 00000057B614: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 00000057B61C: DC5E0010 137C000C
	global_load_b128 v[45:48], v[12:13], off offset:32         // 00000057B624: DC5E0020 2D7C000C
	global_load_b128 v[49:52], v[12:13], off offset:48         // 00000057B62C: DC5E0030 317C000C
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 00000057B634: BF890CF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000057B638: CC1A4008 1A021D08
	s_waitcnt lgkmcnt(14)                                      // 00000057B640: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057B644: BF8700A1
	v_dot2_f32_bf16 v8, v9, v55, v8                            // 00000057B648: CC1A4008 1C226F09
	s_waitcnt lgkmcnt(13)                                      // 00000057B650: BF89FCD7
	v_dot2_f32_bf16 v8, v10, v56, v8                           // 00000057B654: CC1A4008 1C22710A
	s_waitcnt lgkmcnt(12)                                      // 00000057B65C: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057B660: BF8700A1
	v_dot2_f32_bf16 v8, v11, v57, v8                           // 00000057B664: CC1A4008 1C22730B
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 00000057B66C: BF8908B7
	v_dot2_f32_bf16 v8, v19, v58, v8                           // 00000057B670: CC1A4008 1C227513
	s_waitcnt lgkmcnt(10)                                      // 00000057B678: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057B67C: BF8700A1
	v_dot2_f32_bf16 v8, v20, v59, v8                           // 00000057B680: CC1A4008 1C227714
	s_waitcnt lgkmcnt(9)                                       // 00000057B688: BF89FC97
	v_dot2_f32_bf16 v8, v21, v60, v8                           // 00000057B68C: CC1A4008 1C227915
	s_waitcnt lgkmcnt(8)                                       // 00000057B694: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057B698: BF8700A1
	v_dot2_f32_bf16 v8, v22, v61, v8                           // 00000057B69C: CC1A4008 1C227B16
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 00000057B6A4: BF890477
	v_dot2_f32_bf16 v8, v45, v62, v8                           // 00000057B6A8: CC1A4008 1C227D2D
	s_waitcnt lgkmcnt(6)                                       // 00000057B6B0: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057B6B4: BF8700A1
	v_dot2_f32_bf16 v8, v46, v63, v8                           // 00000057B6B8: CC1A4008 1C227F2E
	s_waitcnt lgkmcnt(5)                                       // 00000057B6C0: BF89FC57
	v_dot2_f32_bf16 v8, v47, v64, v8                           // 00000057B6C4: CC1A4008 1C22812F
	s_waitcnt lgkmcnt(4)                                       // 00000057B6CC: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057B6D0: BF8700A1
	v_dot2_f32_bf16 v8, v48, v65, v8                           // 00000057B6D4: CC1A4008 1C228330
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 00000057B6DC: BF890037
	v_dot2_f32_bf16 v8, v49, v66, v8                           // 00000057B6E0: CC1A4008 1C228531
	.long 0xd7006a31                                           // 00000057B6E8: D7006A31
	v_cndmask_b32_e32 v0, v12, v4, vcc_lo                      // 00000057B6EC: 0200090C
	s_waitcnt lgkmcnt(2)                                       // 00000057B6F0: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000057B6F4: BF8701C2
	v_dot2_f32_bf16 v8, v50, v67, v8                           // 00000057B6F8: CC1A4008 1C228732
	v_add_co_ci_u32_e64 v50, null, s5, v13, vcc_lo             // 00000057B700: D5207C32 01AA1A05
	.long 0xd7006a35                                           // 00000057B708: D7006A35
	v_cndmask_b32_e32 v0, v12, v14, vcc_lo                     // 00000057B70C: 02001D0C
	s_waitcnt lgkmcnt(1)                                       // 00000057B710: BF89FC17
	v_dot2_f32_bf16 v8, v51, v68, v8                           // 00000057B714: CC1A4008 1C228933
	v_add_co_ci_u32_e64 v54, null, s15, v13, vcc_lo            // 00000057B71C: D5207C36 01AA1A0F
	.long 0xd7006a0c                                           // 00000057B724: D7006A0C
	v_cndmask_b32_e32 v0, v12, v17, vcc_lo                     // 00000057B728: 0200230C
	s_waitcnt lgkmcnt(0)                                       // 00000057B72C: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000057B730: BF870123
	v_dot2_f32_bf16 v8, v52, v69, v8                           // 00000057B734: CC1A4008 1C228B34
	v_add_co_ci_u32_e64 v13, null, s18, v13, vcc_lo            // 00000057B73C: D5207C0D 01AA1A12
	v_fmac_f32_e32 v39, v44, v8                                // 00000057B744: 564E112C
	s_clause 0x3                                               // 00000057B748: BF850003
	global_load_b128 v[8:11], v[49:50], off                    // 00000057B74C: DC5E0000 087C0031
	global_load_b128 v[19:22], v[49:50], off offset:16         // 00000057B754: DC5E0010 137C0031
	global_load_b128 v[45:48], v[49:50], off offset:32         // 00000057B75C: DC5E0020 2D7C0031
	global_load_b128 v[49:52], v[49:50], off offset:48         // 00000057B764: DC5E0030 317C0031
	s_waitcnt vmcnt(3)                                         // 00000057B76C: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000057B770: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057B778: BF870091
	v_dot2_f32_bf16 v8, v9, v55, v8                            // 00000057B77C: CC1A4008 1C226F09
	v_dot2_f32_bf16 v8, v10, v56, v8                           // 00000057B784: CC1A4008 1C22710A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057B78C: BF8700A1
	v_dot2_f32_bf16 v8, v11, v57, v8                           // 00000057B790: CC1A4008 1C22730B
	s_waitcnt vmcnt(2)                                         // 00000057B798: BF890BF7
	v_dot2_f32_bf16 v8, v19, v58, v8                           // 00000057B79C: CC1A4008 1C227513
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057B7A4: BF870091
	v_dot2_f32_bf16 v8, v20, v59, v8                           // 00000057B7A8: CC1A4008 1C227714
	v_dot2_f32_bf16 v8, v21, v60, v8                           // 00000057B7B0: CC1A4008 1C227915
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057B7B8: BF8700A1
	v_dot2_f32_bf16 v8, v22, v61, v8                           // 00000057B7BC: CC1A4008 1C227B16
	s_waitcnt vmcnt(1)                                         // 00000057B7C4: BF8907F7
	v_dot2_f32_bf16 v8, v45, v62, v8                           // 00000057B7C8: CC1A4008 1C227D2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057B7D0: BF870091
	v_dot2_f32_bf16 v8, v46, v63, v8                           // 00000057B7D4: CC1A4008 1C227F2E
	v_dot2_f32_bf16 v8, v47, v64, v8                           // 00000057B7DC: CC1A4008 1C22812F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057B7E4: BF8700A1
	v_dot2_f32_bf16 v8, v48, v65, v8                           // 00000057B7E8: CC1A4008 1C228330
	s_waitcnt vmcnt(0)                                         // 00000057B7F0: BF8903F7
	v_dot2_f32_bf16 v8, v49, v66, v8                           // 00000057B7F4: CC1A4008 1C228531
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057B7FC: BF870091
	v_dot2_f32_bf16 v8, v50, v67, v8                           // 00000057B800: CC1A4008 1C228732
	v_dot2_f32_bf16 v8, v51, v68, v8                           // 00000057B808: CC1A4008 1C228933
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057B810: BF870091
	v_dot2_f32_bf16 v8, v52, v69, v8                           // 00000057B814: CC1A4008 1C228B34
	v_fmac_f32_e32 v40, v44, v8                                // 00000057B81C: 5650112C
	s_clause 0x3                                               // 00000057B820: BF850003
	global_load_b128 v[8:11], v[53:54], off                    // 00000057B824: DC5E0000 087C0035
	global_load_b128 v[19:22], v[53:54], off offset:16         // 00000057B82C: DC5E0010 137C0035
	global_load_b128 v[45:48], v[53:54], off offset:32         // 00000057B834: DC5E0020 2D7C0035
	global_load_b128 v[49:52], v[53:54], off offset:48         // 00000057B83C: DC5E0030 317C0035
	.long 0xd7006a35                                           // 00000057B844: D7006A35
	v_cndmask_b32_e32 v0, v53, v14, vcc_lo                     // 00000057B848: 02001D35
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000057B84C: BF8700B1
	v_add_co_ci_u32_e64 v54, null, s15, v54, vcc_lo            // 00000057B850: D5207C36 01AA6C0F
	s_waitcnt vmcnt(3)                                         // 00000057B858: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000057B85C: CC1A4008 1A021D08
	v_dot2_f32_bf16 v8, v9, v55, v8                            // 00000057B864: CC1A4008 1C226F09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057B86C: BF870091
	v_dot2_f32_bf16 v8, v10, v56, v8                           // 00000057B870: CC1A4008 1C22710A
	v_dot2_f32_bf16 v8, v11, v57, v8                           // 00000057B878: CC1A4008 1C22730B
	s_waitcnt vmcnt(2)                                         // 00000057B880: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057B884: BF870091
	v_dot2_f32_bf16 v8, v19, v58, v8                           // 00000057B888: CC1A4008 1C227513
	v_dot2_f32_bf16 v8, v20, v59, v8                           // 00000057B890: CC1A4008 1C227714
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057B898: BF870091
	v_dot2_f32_bf16 v8, v21, v60, v8                           // 00000057B89C: CC1A4008 1C227915
	v_dot2_f32_bf16 v8, v22, v61, v8                           // 00000057B8A4: CC1A4008 1C227B16
	s_waitcnt vmcnt(1)                                         // 00000057B8AC: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057B8B0: BF870091
	v_dot2_f32_bf16 v8, v45, v62, v8                           // 00000057B8B4: CC1A4008 1C227D2D
	v_dot2_f32_bf16 v8, v46, v63, v8                           // 00000057B8BC: CC1A4008 1C227F2E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057B8C4: BF870091
	v_dot2_f32_bf16 v8, v47, v64, v8                           // 00000057B8C8: CC1A4008 1C22812F
	v_dot2_f32_bf16 v8, v48, v65, v8                           // 00000057B8D0: CC1A4008 1C228330
	s_waitcnt vmcnt(0)                                         // 00000057B8D8: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057B8DC: BF870091
	v_dot2_f32_bf16 v8, v49, v66, v8                           // 00000057B8E0: CC1A4008 1C228531
	v_dot2_f32_bf16 v8, v50, v67, v8                           // 00000057B8E8: CC1A4008 1C228732
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057B8F0: BF870091
	v_dot2_f32_bf16 v8, v51, v68, v8                           // 00000057B8F4: CC1A4008 1C228933
	v_dot2_f32_bf16 v8, v52, v69, v8                           // 00000057B8FC: CC1A4008 1C228B34
	s_delay_alu instid0(VALU_DEP_1)                            // 00000057B904: BF870001
	v_fmac_f32_e32 v37, v44, v8                                // 00000057B908: 564A112C
	s_clause 0x3                                               // 00000057B90C: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 00000057B910: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 00000057B918: DC5E0010 137C000C
	global_load_b128 v[45:48], v[12:13], off offset:32         // 00000057B920: DC5E0020 2D7C000C
	global_load_b128 v[49:52], v[12:13], off offset:48         // 00000057B928: DC5E0030 317C000C
	.long 0xd7006a0c                                           // 00000057B930: D7006A0C
	v_cndmask_b32_e32 v0, v12, v14, vcc_lo                     // 00000057B934: 02001D0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000057B938: BF8700B1
	v_add_co_ci_u32_e64 v13, null, s15, v13, vcc_lo            // 00000057B93C: D5207C0D 01AA1A0F
	s_waitcnt vmcnt(3)                                         // 00000057B944: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000057B948: CC1A4008 1A021D08
	v_dot2_f32_bf16 v8, v9, v55, v8                            // 00000057B950: CC1A4008 1C226F09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057B958: BF870091
	v_dot2_f32_bf16 v8, v10, v56, v8                           // 00000057B95C: CC1A4008 1C22710A
	v_dot2_f32_bf16 v8, v11, v57, v8                           // 00000057B964: CC1A4008 1C22730B
	s_waitcnt vmcnt(2)                                         // 00000057B96C: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057B970: BF870091
	v_dot2_f32_bf16 v8, v19, v58, v8                           // 00000057B974: CC1A4008 1C227513
	v_dot2_f32_bf16 v8, v20, v59, v8                           // 00000057B97C: CC1A4008 1C227714
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057B984: BF870091
	v_dot2_f32_bf16 v8, v21, v60, v8                           // 00000057B988: CC1A4008 1C227915
	v_dot2_f32_bf16 v8, v22, v61, v8                           // 00000057B990: CC1A4008 1C227B16
	s_waitcnt vmcnt(1)                                         // 00000057B998: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057B99C: BF870091
	v_dot2_f32_bf16 v8, v45, v62, v8                           // 00000057B9A0: CC1A4008 1C227D2D
	v_dot2_f32_bf16 v8, v46, v63, v8                           // 00000057B9A8: CC1A4008 1C227F2E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057B9B0: BF870091
	v_dot2_f32_bf16 v8, v47, v64, v8                           // 00000057B9B4: CC1A4008 1C22812F
	v_dot2_f32_bf16 v8, v48, v65, v8                           // 00000057B9BC: CC1A4008 1C228330
	s_waitcnt vmcnt(0)                                         // 00000057B9C4: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057B9C8: BF870091
	v_dot2_f32_bf16 v8, v49, v66, v8                           // 00000057B9CC: CC1A4008 1C228531
	v_dot2_f32_bf16 v8, v50, v67, v8                           // 00000057B9D4: CC1A4008 1C228732
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057B9DC: BF870091
	v_dot2_f32_bf16 v8, v51, v68, v8                           // 00000057B9E0: CC1A4008 1C228933
	v_dot2_f32_bf16 v8, v52, v69, v8                           // 00000057B9E8: CC1A4008 1C228B34
	s_delay_alu instid0(VALU_DEP_1)                            // 00000057B9F0: BF870001
	v_fmac_f32_e32 v38, v44, v8                                // 00000057B9F4: 564C112C
	s_clause 0x3                                               // 00000057B9F8: BF850003
	global_load_b128 v[8:11], v[53:54], off                    // 00000057B9FC: DC5E0000 087C0035
	global_load_b128 v[19:22], v[53:54], off offset:16         // 00000057BA04: DC5E0010 137C0035
	global_load_b128 v[45:48], v[53:54], off offset:32         // 00000057BA0C: DC5E0020 2D7C0035
	global_load_b128 v[49:52], v[53:54], off offset:48         // 00000057BA14: DC5E0030 317C0035
	s_waitcnt vmcnt(3)                                         // 00000057BA1C: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000057BA20: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057BA28: BF870091
	v_dot2_f32_bf16 v8, v9, v55, v8                            // 00000057BA2C: CC1A4008 1C226F09
	v_dot2_f32_bf16 v8, v10, v56, v8                           // 00000057BA34: CC1A4008 1C22710A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057BA3C: BF8700A1
	v_dot2_f32_bf16 v8, v11, v57, v8                           // 00000057BA40: CC1A4008 1C22730B
	s_waitcnt vmcnt(2)                                         // 00000057BA48: BF890BF7
	v_dot2_f32_bf16 v8, v19, v58, v8                           // 00000057BA4C: CC1A4008 1C227513
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057BA54: BF870091
	v_dot2_f32_bf16 v8, v20, v59, v8                           // 00000057BA58: CC1A4008 1C227714
	v_dot2_f32_bf16 v8, v21, v60, v8                           // 00000057BA60: CC1A4008 1C227915
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057BA68: BF8700A1
	v_dot2_f32_bf16 v8, v22, v61, v8                           // 00000057BA6C: CC1A4008 1C227B16
	s_waitcnt vmcnt(1)                                         // 00000057BA74: BF8907F7
	v_dot2_f32_bf16 v8, v45, v62, v8                           // 00000057BA78: CC1A4008 1C227D2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057BA80: BF870091
	v_dot2_f32_bf16 v8, v46, v63, v8                           // 00000057BA84: CC1A4008 1C227F2E
	v_dot2_f32_bf16 v8, v47, v64, v8                           // 00000057BA8C: CC1A4008 1C22812F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057BA94: BF8700A1
	v_dot2_f32_bf16 v8, v48, v65, v8                           // 00000057BA98: CC1A4008 1C228330
	s_waitcnt vmcnt(0)                                         // 00000057BAA0: BF8903F7
	v_dot2_f32_bf16 v8, v49, v66, v8                           // 00000057BAA4: CC1A4008 1C228531
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057BAAC: BF870091
	v_dot2_f32_bf16 v8, v50, v67, v8                           // 00000057BAB0: CC1A4008 1C228732
	v_dot2_f32_bf16 v8, v51, v68, v8                           // 00000057BAB8: CC1A4008 1C228933
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057BAC0: BF870091
	v_dot2_f32_bf16 v8, v52, v69, v8                           // 00000057BAC4: CC1A4008 1C228B34
	v_fmac_f32_e32 v35, v44, v8                                // 00000057BACC: 5646112C
	s_clause 0x3                                               // 00000057BAD0: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 00000057BAD4: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 00000057BADC: DC5E0010 137C000C
	global_load_b128 v[45:48], v[12:13], off offset:32         // 00000057BAE4: DC5E0020 2D7C000C
	global_load_b128 v[49:52], v[12:13], off offset:48         // 00000057BAEC: DC5E0030 317C000C
	s_waitcnt vmcnt(3)                                         // 00000057BAF4: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000057BAF8: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057BB00: BF870091
	v_dot2_f32_bf16 v8, v9, v55, v8                            // 00000057BB04: CC1A4008 1C226F09
	v_dot2_f32_bf16 v8, v10, v56, v8                           // 00000057BB0C: CC1A4008 1C22710A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057BB14: BF8700A1
	v_dot2_f32_bf16 v8, v11, v57, v8                           // 00000057BB18: CC1A4008 1C22730B
	s_waitcnt vmcnt(2)                                         // 00000057BB20: BF890BF7
	v_dot2_f32_bf16 v8, v19, v58, v8                           // 00000057BB24: CC1A4008 1C227513
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057BB2C: BF870091
	v_dot2_f32_bf16 v8, v20, v59, v8                           // 00000057BB30: CC1A4008 1C227714
	v_dot2_f32_bf16 v8, v21, v60, v8                           // 00000057BB38: CC1A4008 1C227915
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057BB40: BF8700A1
	v_dot2_f32_bf16 v8, v22, v61, v8                           // 00000057BB44: CC1A4008 1C227B16
	s_waitcnt vmcnt(1)                                         // 00000057BB4C: BF8907F7
	v_dot2_f32_bf16 v8, v45, v62, v8                           // 00000057BB50: CC1A4008 1C227D2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057BB58: BF870091
	v_dot2_f32_bf16 v8, v46, v63, v8                           // 00000057BB5C: CC1A4008 1C227F2E
	v_dot2_f32_bf16 v8, v47, v64, v8                           // 00000057BB64: CC1A4008 1C22812F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057BB6C: BF8700A1
	v_dot2_f32_bf16 v8, v48, v65, v8                           // 00000057BB70: CC1A4008 1C228330
	s_waitcnt vmcnt(0)                                         // 00000057BB78: BF8903F7
	v_dot2_f32_bf16 v8, v49, v66, v8                           // 00000057BB7C: CC1A4008 1C228531
	.long 0xd7006a31                                           // 00000057BB84: D7006A31
	v_cndmask_b32_e32 v0, v53, v14, vcc_lo                     // 00000057BB88: 02001D35
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000057BB8C: BF8701B2
	v_dot2_f32_bf16 v8, v50, v67, v8                           // 00000057BB90: CC1A4008 1C228732
	v_add_co_ci_u32_e64 v50, null, s15, v54, vcc_lo            // 00000057BB98: D5207C32 01AA6C0F
	.long 0xd7006a0c                                           // 00000057BBA0: D7006A0C
	v_cndmask_b32_e32 v0, v12, v14, vcc_lo                     // 00000057BBA4: 02001D0C
	v_dot2_f32_bf16 v8, v51, v68, v8                           // 00000057BBA8: CC1A4008 1C228933
	v_add_co_ci_u32_e64 v13, null, s15, v13, vcc_lo            // 00000057BBB0: D5207C0D 01AA1A0F
	.long 0xd7006a1c                                           // 00000057BBB8: D7006A1C
	v_cndmask_b32_e32 v0, v28, v160, vcc_lo                    // 00000057BBBC: 0201411C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000057BBC0: BF870123
	v_dot2_f32_bf16 v8, v52, v69, v8                           // 00000057BBC4: CC1A4008 1C228B34
	v_add_co_ci_u32_e64 v29, null, 0, v29, vcc_lo              // 00000057BBCC: D5207C1D 01AA3A80
	v_fmac_f32_e32 v36, v44, v8                                // 00000057BBD4: 5648112C
	s_clause 0x3                                               // 00000057BBD8: BF850003
	global_load_b128 v[8:11], v[49:50], off                    // 00000057BBDC: DC5E0000 087C0031
	global_load_b128 v[19:22], v[49:50], off offset:16         // 00000057BBE4: DC5E0010 137C0031
	global_load_b128 v[45:48], v[49:50], off offset:32         // 00000057BBEC: DC5E0020 2D7C0031
	global_load_b128 v[49:52], v[49:50], off offset:48         // 00000057BBF4: DC5E0030 317C0031
	s_waitcnt vmcnt(3)                                         // 00000057BBFC: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000057BC00: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057BC08: BF870091
	v_dot2_f32_bf16 v8, v9, v55, v8                            // 00000057BC0C: CC1A4008 1C226F09
	v_dot2_f32_bf16 v8, v10, v56, v8                           // 00000057BC14: CC1A4008 1C22710A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057BC1C: BF8700A1
	v_dot2_f32_bf16 v8, v11, v57, v8                           // 00000057BC20: CC1A4008 1C22730B
	s_waitcnt vmcnt(2)                                         // 00000057BC28: BF890BF7
	v_dot2_f32_bf16 v8, v19, v58, v8                           // 00000057BC2C: CC1A4008 1C227513
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057BC34: BF870091
	v_dot2_f32_bf16 v8, v20, v59, v8                           // 00000057BC38: CC1A4008 1C227714
	v_dot2_f32_bf16 v8, v21, v60, v8                           // 00000057BC40: CC1A4008 1C227915
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057BC48: BF8700A1
	v_dot2_f32_bf16 v8, v22, v61, v8                           // 00000057BC4C: CC1A4008 1C227B16
	s_waitcnt vmcnt(1)                                         // 00000057BC54: BF8907F7
	v_dot2_f32_bf16 v8, v45, v62, v8                           // 00000057BC58: CC1A4008 1C227D2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057BC60: BF870091
	v_dot2_f32_bf16 v8, v46, v63, v8                           // 00000057BC64: CC1A4008 1C227F2E
	v_dot2_f32_bf16 v8, v47, v64, v8                           // 00000057BC6C: CC1A4008 1C22812F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057BC74: BF8700A1
	v_dot2_f32_bf16 v8, v48, v65, v8                           // 00000057BC78: CC1A4008 1C228330
	s_waitcnt vmcnt(0)                                         // 00000057BC80: BF8903F7
	v_dot2_f32_bf16 v8, v49, v66, v8                           // 00000057BC84: CC1A4008 1C228531
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057BC8C: BF870091
	v_dot2_f32_bf16 v8, v50, v67, v8                           // 00000057BC90: CC1A4008 1C228732
	v_dot2_f32_bf16 v8, v51, v68, v8                           // 00000057BC98: CC1A4008 1C228933
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057BCA0: BF870091
	v_dot2_f32_bf16 v8, v52, v69, v8                           // 00000057BCA4: CC1A4008 1C228B34
	v_fmac_f32_e32 v34, v44, v8                                // 00000057BCAC: 5644112C
	s_clause 0x3                                               // 00000057BCB0: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 00000057BCB4: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 00000057BCBC: DC5E0010 137C000C
	global_load_b128 v[45:48], v[12:13], off offset:32         // 00000057BCC4: DC5E0020 2D7C000C
	global_load_b128 v[49:52], v[12:13], off offset:48         // 00000057BCCC: DC5E0030 317C000C
	s_waitcnt vmcnt(3)                                         // 00000057BCD4: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000057BCD8: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057BCE0: BF870091
	v_dot2_f32_bf16 v8, v9, v55, v8                            // 00000057BCE4: CC1A4008 1C226F09
	v_dot2_f32_bf16 v8, v10, v56, v8                           // 00000057BCEC: CC1A4008 1C22710A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057BCF4: BF8700A1
	v_dot2_f32_bf16 v8, v11, v57, v8                           // 00000057BCF8: CC1A4008 1C22730B
	s_waitcnt vmcnt(2)                                         // 00000057BD00: BF890BF7
	v_dot2_f32_bf16 v8, v19, v58, v8                           // 00000057BD04: CC1A4008 1C227513
	v_mov_b32_e32 v19, v15                                     // 00000057BD0C: 7E26030F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000057BD10: BF870122
	v_dot2_f32_bf16 v8, v20, v59, v8                           // 00000057BD14: CC1A4008 1C227714
	v_mov_b32_e32 v20, v16                                     // 00000057BD1C: 7E280310
	v_dot2_f32_bf16 v8, v21, v60, v8                           // 00000057BD20: CC1A4008 1C227915
	v_mov_b32_e32 v21, v17                                     // 00000057BD28: 7E2A0311
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000057BD2C: BF870132
	v_dot2_f32_bf16 v8, v22, v61, v8                           // 00000057BD30: CC1A4008 1C227B16
	v_mov_b32_e32 v22, v18                                     // 00000057BD38: 7E2C0312
	s_waitcnt vmcnt(1)                                         // 00000057BD3C: BF8907F7
	v_dot2_f32_bf16 v8, v45, v62, v8                           // 00000057BD40: CC1A4008 1C227D2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057BD48: BF870091
	v_dot2_f32_bf16 v8, v46, v63, v8                           // 00000057BD4C: CC1A4008 1C227F2E
	v_dot2_f32_bf16 v8, v47, v64, v8                           // 00000057BD54: CC1A4008 1C22812F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057BD5C: BF8700A1
	v_dot2_f32_bf16 v8, v48, v65, v8                           // 00000057BD60: CC1A4008 1C228330
	s_waitcnt vmcnt(0)                                         // 00000057BD68: BF8903F7
	v_dot2_f32_bf16 v8, v49, v66, v8                           // 00000057BD6C: CC1A4008 1C228531
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057BD74: BF870091
	v_dot2_f32_bf16 v8, v50, v67, v8                           // 00000057BD78: CC1A4008 1C228732
	v_dot2_f32_bf16 v8, v51, v68, v8                           // 00000057BD80: CC1A4008 1C228933
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057BD88: BF870091
	v_dot2_f32_bf16 v8, v52, v69, v8                           // 00000057BD8C: CC1A4008 1C228B34
	v_dual_fmac_f32 v31, v44, v8 :: v_dual_mov_b32 v14, v7     // 00000057BD94: C810112C 1F0E0107
	v_dual_mov_b32 v44, v43 :: v_dual_mov_b32 v13, v6          // 00000057BD9C: CA10012B 2C0C0106
	v_dual_mov_b32 v12, v5 :: v_dual_mov_b32 v11, v4           // 00000057BDA4: CA100105 0C0A0104
	v_dual_mov_b32 v10, v3 :: v_dual_mov_b32 v9, v2            // 00000057BDAC: CA100103 0A080102
	v_dual_mov_b32 v8, v1 :: v_dual_mov_b32 v7, v0             // 00000057BDB4: CA100101 08060100
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 00000057BDBC: 917E107E
	s_cbranch_execz 28                                         // 00000057BDC0: BFA5001C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi16ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xf34>
	s_waitcnt vmcnt(0)                                         // 00000057BDC4: BF8903F7
	v_dual_mov_b32 v15, v19 :: v_dual_add_nc_u32 v42, 16, v42  // 00000057BDC8: CA200113 0F2A5490
	v_dual_mov_b32 v16, v20 :: v_dual_mov_b32 v17, v21         // 00000057BDD0: CA100114 10100115
	v_mov_b32_e32 v18, v22                                     // 00000057BDD8: 7E240316
	s_delay_alu instid0(VALU_DEP_3)                            // 00000057BDDC: BF870003
	.long 0xd4430002                                           // 00000057BDE0: D4430002
	v_cndmask_b32_e32 v1, s20, v42, vcc_lo                     // 00000057BDE4: 02025414
	s_mov_b32 s10, exec_lo                                     // 00000057BDE8: BE8A007E
	.long 0xd4c4007e                                           // 00000057BDEC: D4C4007E
	v_cndmask_b32_e32 v1, s20, v42, vcc_lo                     // 00000057BDF0: 02025414
	s_cbranch_execz 64911                                      // 00000057BDF4: BFA5FD8F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi16ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x534>
	.long 0xd7006a00                                           // 00000057BDF8: D7006A00
	v_cndmask_b32_e32 v1, v25, v41, vcc_lo                     // 00000057BDFC: 02025319
	s_delay_alu instid0(VALU_DEP_1)                            // 00000057BE00: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v33, vcc_lo               // 00000057BE04: D5207C01 01AA4280
	v_cmp_ne_u32_e32 vcc_lo, 1, v32                            // 00000057BE0C: 7C9A4081
	v_mov_b32_e32 v43, v44                                     // 00000057BE10: 7E56032C
	global_load_b128 v[15:18], v[0:1], off                     // 00000057BE14: DC5E0000 0F7C0000
	s_cbranch_vccnz 64901                                      // 00000057BE1C: BFA4FD85 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi16ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x534>
	global_load_d16_b16 v0, v[28:29], off                      // 00000057BE20: DC820000 007C001C
	s_waitcnt vmcnt(0)                                         // 00000057BE28: BF8903F7
	v_cvt_f32_f16_e32 v43, v0                                  // 00000057BE2C: 7E561700
	s_branch 64896                                             // 00000057BE30: BFA0FD80 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi16ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x534>
	s_or_b32 exec_lo, exec_lo, s16                             // 00000057BE34: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057BE38: BF8700A9
	s_or_b32 exec_lo, exec_lo, s3                              // 00000057BE3C: 8C7E037E
	.long 0xd71f0000                                           // 00000057BE40: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000057BE44: 020100C1
	v_xor_b32_e32 v1, 8, v0                                    // 00000057BE48: 3A020088
	v_xor_b32_e32 v9, 4, v0                                    // 00000057BE4C: 3A120084
	v_xor_b32_e32 v17, 2, v0                                   // 00000057BE50: 3A220082
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000057BE54: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v1                            // 00000057BE58: 7C9802A0
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 00000057BE5C: 02020300
	v_cmp_gt_u32_e32 vcc_lo, 32, v9                            // 00000057BE60: 7C9812A0
	s_delay_alu instid0(VALU_DEP_2)                            // 00000057BE64: BF870002
	v_lshlrev_b32_e32 v1, 2, v1                                // 00000057BE68: 30020282
	ds_bpermute_b32 v2, v1, v40                                // 00000057BE6C: DACC0000 02002801
	s_waitcnt lgkmcnt(0)                                       // 00000057BE74: BF89FC07
	v_add_f32_e32 v2, v40, v2                                  // 00000057BE78: 06040528
	ds_bpermute_b32 v6, v1, v36                                // 00000057BE7C: DACC0000 06002401
	ds_bpermute_b32 v8, v1, v31                                // 00000057BE84: DACC0000 08001F01
	ds_bpermute_b32 v4, v1, v38                                // 00000057BE8C: DACC0000 04002601
	v_cndmask_b32_e32 v9, v0, v9, vcc_lo                       // 00000057BE94: 02121300
	ds_bpermute_b32 v3, v1, v39                                // 00000057BE98: DACC0000 03002701
	ds_bpermute_b32 v7, v1, v35                                // 00000057BEA0: DACC0000 07002301
	ds_bpermute_b32 v5, v1, v37                                // 00000057BEA8: DACC0000 05002501
	ds_bpermute_b32 v1, v1, v34                                // 00000057BEB0: DACC0000 01002201
	v_cmp_gt_u32_e32 vcc_lo, 32, v17                           // 00000057BEB8: 7C9822A0
	s_waitcnt lgkmcnt(6)                                       // 00000057BEBC: BF89FC67
	v_add_f32_e32 v6, v36, v6                                  // 00000057BEC0: 060C0D24
	s_waitcnt lgkmcnt(5)                                       // 00000057BEC4: BF89FC57
	v_dual_add_f32 v8, v31, v8 :: v_dual_lshlrev_b32 v9, 2, v9 // 00000057BEC8: C922111F 08081282
	s_waitcnt lgkmcnt(4)                                       // 00000057BED0: BF89FC47
	v_add_f32_e32 v4, v38, v4                                  // 00000057BED4: 06080926
	ds_bpermute_b32 v10, v9, v2                                // 00000057BED8: DACC0000 0A000209
	ds_bpermute_b32 v14, v9, v6                                // 00000057BEE0: DACC0000 0E000609
	ds_bpermute_b32 v12, v9, v4                                // 00000057BEE8: DACC0000 0C000409
	s_waitcnt lgkmcnt(6)                                       // 00000057BEF0: BF89FC67
	v_add_f32_e32 v3, v39, v3                                  // 00000057BEF4: 06060727
	s_waitcnt lgkmcnt(5)                                       // 00000057BEF8: BF89FC57
	v_add_f32_e32 v7, v35, v7                                  // 00000057BEFC: 060E0F23
	ds_bpermute_b32 v16, v9, v8                                // 00000057BF00: DACC0000 10000809
	s_waitcnt lgkmcnt(5)                                       // 00000057BF08: BF89FC57
	v_add_f32_e32 v5, v37, v5                                  // 00000057BF0C: 060A0B25
	s_waitcnt lgkmcnt(4)                                       // 00000057BF10: BF89FC47
	v_add_f32_e32 v1, v34, v1                                  // 00000057BF14: 06020322
	s_waitcnt lgkmcnt(3)                                       // 00000057BF18: BF89FC37
	v_add_f32_e32 v2, v2, v10                                  // 00000057BF1C: 06041502
	ds_bpermute_b32 v11, v9, v3                                // 00000057BF20: DACC0000 0B000309
	s_waitcnt lgkmcnt(3)                                       // 00000057BF28: BF89FC37
	v_add_f32_e32 v6, v6, v14                                  // 00000057BF2C: 060C1D06
	ds_bpermute_b32 v15, v9, v7                                // 00000057BF30: DACC0000 0F000709
	v_cndmask_b32_e32 v17, v0, v17, vcc_lo                     // 00000057BF38: 02222300
	s_waitcnt lgkmcnt(3)                                       // 00000057BF3C: BF89FC37
	v_add_f32_e32 v4, v4, v12                                  // 00000057BF40: 06081904
	v_xor_b32_e32 v12, 1, v0                                   // 00000057BF44: 3A180081
	ds_bpermute_b32 v13, v9, v5                                // 00000057BF48: DACC0000 0D000509
	s_waitcnt lgkmcnt(3)                                       // 00000057BF50: BF89FC37
	v_add_f32_e32 v10, v8, v16                                 // 00000057BF54: 06142108
	ds_bpermute_b32 v9, v9, v1                                 // 00000057BF58: DACC0000 09000109
	v_cmp_gt_u32_e32 vcc_lo, 32, v12                           // 00000057BF60: 7C9818A0
	v_dual_cndmask_b32 v0, v0, v12 :: v_dual_lshlrev_b32 v17, 2, v17// 00000057BF64: CA621900 00102282
	ds_bpermute_b32 v8, v17, v2                                // 00000057BF6C: DACC0000 08000211
	ds_bpermute_b32 v18, v17, v10                              // 00000057BF74: DACC0000 12000A11
	v_cmp_eq_u32_e32 vcc_lo, 0, v30                            // 00000057BF7C: 7C943C80
	s_waitcnt lgkmcnt(5)                                       // 00000057BF80: BF89FC57
	v_add_f32_e32 v3, v3, v11                                  // 00000057BF84: 06061703
	ds_bpermute_b32 v11, v17, v4                               // 00000057BF88: DACC0000 0B000411
	s_waitcnt lgkmcnt(5)                                       // 00000057BF90: BF89FC57
	v_add_f32_e32 v7, v7, v15                                  // 00000057BF94: 060E1F07
	ds_bpermute_b32 v15, v17, v6                               // 00000057BF98: DACC0000 0F000611
	s_waitcnt vmcnt(0)                                         // 00000057BFA0: BF8903F7
	v_lshlrev_b32_e32 v19, 2, v0                               // 00000057BFA4: 30260082
	s_and_b32 s0, vcc_lo, s0                                   // 00000057BFA8: 8B00006A
	s_waitcnt lgkmcnt(5)                                       // 00000057BFAC: BF89FC57
	v_add_f32_e32 v5, v5, v13                                  // 00000057BFB0: 060A1B05
	ds_bpermute_b32 v16, v17, v7                               // 00000057BFB4: DACC0000 10000711
	s_waitcnt lgkmcnt(4)                                       // 00000057BFBC: BF89FC47
	v_dual_add_f32 v1, v1, v9 :: v_dual_add_f32 v12, v2, v8    // 00000057BFC0: C9081301 010C1102
	s_waitcnt lgkmcnt(3)                                       // 00000057BFC8: BF89FC37
	v_add_f32_e32 v0, v10, v18                                 // 00000057BFCC: 0600250A
	ds_bpermute_b32 v9, v17, v3                                // 00000057BFD0: DACC0000 09000311
	s_waitcnt lgkmcnt(3)                                       // 00000057BFD8: BF89FC37
	v_add_f32_e32 v8, v4, v11                                  // 00000057BFDC: 06101704
	ds_bpermute_b32 v14, v17, v5                               // 00000057BFE0: DACC0000 0E000511
	s_waitcnt lgkmcnt(3)                                       // 00000057BFE8: BF89FC37
	v_add_f32_e32 v4, v6, v15                                  // 00000057BFEC: 06081F06
	ds_bpermute_b32 v17, v17, v1                               // 00000057BFF0: DACC0000 11000111
	ds_bpermute_b32 v15, v19, v12                              // 00000057BFF8: DACC0000 0F000C13
	ds_bpermute_b32 v10, v19, v8                               // 00000057C000: DACC0000 0A000813
	s_waitcnt lgkmcnt(4)                                       // 00000057C008: BF89FC47
	v_add_f32_e32 v13, v3, v9                                  // 00000057C00C: 061A1303
	ds_bpermute_b32 v3, v19, v0                                // 00000057C010: DACC0000 03000013
	s_waitcnt lgkmcnt(4)                                       // 00000057C018: BF89FC47
	v_add_f32_e32 v9, v5, v14                                  // 00000057C01C: 06121D05
	v_add_f32_e32 v5, v7, v16                                  // 00000057C020: 060A2107
	s_waitcnt lgkmcnt(3)                                       // 00000057C024: BF89FC37
	v_add_f32_e32 v1, v1, v17                                  // 00000057C028: 06022301
	ds_bpermute_b32 v14, v19, v13                              // 00000057C02C: DACC0000 0E000D13
	ds_bpermute_b32 v7, v19, v4                                // 00000057C034: DACC0000 07000413
	ds_bpermute_b32 v11, v19, v9                               // 00000057C03C: DACC0000 0B000913
	ds_bpermute_b32 v6, v19, v5                                // 00000057C044: DACC0000 06000513
	ds_bpermute_b32 v2, v19, v1                                // 00000057C04C: DACC0000 02000113
	s_and_saveexec_b32 s1, s0                                  // 00000057C054: BE812000
	s_cbranch_execz 116                                        // 00000057C058: BFA50074 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi16ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x132c>
	s_waitcnt lgkmcnt(4)                                       // 00000057C05C: BF89FC47
	v_dual_add_f32 v15, v12, v15 :: v_dual_add_f32 v14, v13, v14// 00000057C060: C9081F0C 0F0E1D0D
	.long 0x7f203880                                           // 00000057C068: 7F203880
	.long 0xd73c000c                                           // 00000057C06C: D73C000C
	v_cndmask_b32_e32 v1, 1, v23, vcc_lo                       // 00000057C070: 02022E81
	s_lshl_b64 s[0:1], s[12:13], 1                             // 00000057C074: 8480810C
	s_delay_alu instid0(VALU_DEP_3)                            // 00000057C078: BF870003
	.long 0x7e20398f                                           // 00000057C07C: 7E20398F
	.long 0x7e22398e                                           // 00000057C080: 7E22398E
	.long 0x7f223990                                           // 00000057C084: 7F223990
	v_add_f32_e32 v10, v8, v10                                 // 00000057C088: 06141508
	.long 0xd7006a0c                                           // 00000057C08C: D7006A0C
	v_cndmask_b32_e32 v1, s8, v12, vcc_lo                      // 00000057C090: 02021808
	s_waitcnt lgkmcnt(2)                                       // 00000057C094: BF89FC27
	v_dual_add_f32 v11, v9, v11 :: v_dual_and_b32 v18, 1, v16  // 00000057C098: C9241709 0B122081
	v_and_b32_e32 v17, 1, v17                                  // 00000057C0A0: 36222281
	v_add_co_ci_u32_e64 v13, null, s9, v13, vcc_lo             // 00000057C0A4: D5207C0D 01AA1A09
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000057C0AC: BF870223
	v_add3_u32 v18, v15, v18, 0x7fff                           // 00000057C0B0: D6550012 03FE250F 00007FFF
	.long 0x7e20398a                                           // 00000057C0BC: 7E20398A
	v_add3_u32 v17, v14, v17, 0x7fff                           // 00000057C0C0: D6550011 03FE230E 00007FFF
	.long 0xd7006a0e                                           // 00000057C0CC: D7006A0E
	v_cndmask_b32_e32 v0, v12, v0, vcc_lo                      // 00000057C0D0: 0200010C
	s_delay_alu instid0(VALU_DEP_1)                            // 00000057C0D4: BF870001
	v_add_co_ci_u32_e64 v15, null, s1, v13, vcc_lo             // 00000057C0D8: D5207C0F 01AA1A01
	s_clause 0x1                                               // 00000057C0E0: BF850001
	global_store_d16_hi_b16 v[12:13], v17, off                 // 00000057C0E4: DC960000 007C110C
	global_store_d16_hi_b16 v[14:15], v18, off                 // 00000057C0EC: DC960000 007C120E
	.long 0x7e1c398b                                           // 00000057C0F4: 7E1C398B
	.long 0x7f1c3990                                           // 00000057C0F8: 7F1C3990
	v_add_f32_e32 v7, v4, v7                                   // 00000057C0FC: 060E0F04
	s_waitcnt lgkmcnt(1)                                       // 00000057C100: BF89FC17
	v_dual_add_f32 v15, v5, v6 :: v_dual_and_b32 v6, 1, v16    // 00000057C104: C9240D05 0F062081
	v_mad_u64_u32 v[4:5], null, s12, 6, v[12:13]               // 00000057C10C: D6FE7C04 04310C0C
	v_and_b32_e32 v14, 1, v14                                  // 00000057C114: 361C1C81
	s_lshl_b64 s[0:1], s[12:13], 2                             // 00000057C118: 8480820C
	.long 0x7e203987                                           // 00000057C11C: 7E203987
	.long 0xd7006a08                                           // 00000057C120: D7006A08
	v_cndmask_b32_e32 v0, v12, v0, vcc_lo                      // 00000057C124: 0200010C
	s_delay_alu instid0(VALU_DEP_1)                            // 00000057C128: BF870001
	v_add_co_ci_u32_e64 v9, null, s1, v13, vcc_lo              // 00000057C12C: D5207C09 01AA1A01
	v_add3_u32 v11, v11, v14, 0x7fff                           // 00000057C134: D655000B 03FE1D0B 00007FFF
	.long 0x7e18398f                                           // 00000057C140: 7E18398F
	.long 0x7f183990                                           // 00000057C144: 7F183990
	v_add3_u32 v10, v10, v6, 0x7fff                            // 00000057C148: D655000A 03FE0D0A 00007FFF
	v_mad_u64_u32 v[5:6], null, s13, 6, v[5:6]                 // 00000057C154: D6FE7C05 04150C0D
	v_dual_add_f32 v13, v0, v3 :: v_dual_and_b32 v6, 1, v16    // 00000057C15C: C9240700 0D062081
	global_store_d16_hi_b16 v[8:9], v11, off                   // 00000057C164: DC960000 007C0B08
	s_waitcnt lgkmcnt(0)                                       // 00000057C16C: BF89FC07
	v_dual_add_f32 v12, v1, v2 :: v_dual_and_b32 v11, 1, v12   // 00000057C170: C9240501 0C0A1881
	v_add3_u32 v14, v7, v6, 0x7fff                             // 00000057C178: D655000E 03FE0D07 00007FFF
	.long 0x7e20398d                                           // 00000057C184: 7E20398D
	.long 0x7f0c3990                                           // 00000057C188: 7F0C3990
	.long 0xd7006a00                                           // 00000057C18C: D7006A00
	v_cndmask_b32_e32 v0, v8, v0, vcc_lo                       // 00000057C190: 02000108
	.long 0x7e0c398c                                           // 00000057C194: 7E0C398C
	v_add_co_ci_u32_e64 v1, null, s1, v9, vcc_lo               // 00000057C198: D5207C01 01AA1201
	.long 0xd7006a02                                           // 00000057C1A0: D7006A02
	v_cndmask_b32_e32 v0, v4, v0, vcc_lo                       // 00000057C1A4: 02000104
	v_and_b32_e32 v8, 1, v16                                   // 00000057C1A8: 36102081
	s_delay_alu instid0(VALU_DEP_4)                            // 00000057C1AC: BF870004
	v_and_b32_e32 v9, 1, v6                                    // 00000057C1B0: 36120C81
	v_add_co_ci_u32_e64 v3, null, s1, v5, vcc_lo               // 00000057C1B4: D5207C03 01AA0A01
	.long 0xd7006a06                                           // 00000057C1BC: D7006A06
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 00000057C1C0: 02000100
	v_add3_u32 v11, v15, v11, 0x7fff                           // 00000057C1C4: D655000B 03FE170F 00007FFF
	v_add_co_ci_u32_e64 v7, null, s1, v1, vcc_lo               // 00000057C1D0: D5207C07 01AA0201
	v_add3_u32 v13, v13, v8, 0x7fff                            // 00000057C1D8: D655000D 03FE110D 00007FFF
	.long 0xd7006a08                                           // 00000057C1E4: D7006A08
	v_cndmask_b32_e32 v0, v2, v0, vcc_lo                       // 00000057C1E8: 02000102
	v_add3_u32 v12, v12, v9, 0x7fff                            // 00000057C1EC: D655000C 03FE130C 00007FFF
	v_add_co_ci_u32_e64 v9, null, s1, v3, vcc_lo               // 00000057C1F8: D5207C09 01AA0601
	s_clause 0x4                                               // 00000057C200: BF850004
	global_store_d16_hi_b16 v[4:5], v10, off                   // 00000057C204: DC960000 007C0A04
	global_store_d16_hi_b16 v[0:1], v11, off                   // 00000057C20C: DC960000 007C0B00
	global_store_d16_hi_b16 v[2:3], v14, off                   // 00000057C214: DC960000 007C0E02
	global_store_d16_hi_b16 v[6:7], v12, off                   // 00000057C21C: DC960000 007C0C06
	global_store_d16_hi_b16 v[8:9], v13, off                   // 00000057C224: DC960000 007C0D08
	s_endpgm                                                   // 00000057C22C: BFB00000
		...

