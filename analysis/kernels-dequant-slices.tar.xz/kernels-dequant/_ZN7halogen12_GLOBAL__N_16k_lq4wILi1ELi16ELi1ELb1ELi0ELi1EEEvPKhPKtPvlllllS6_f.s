000000000073ac00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi16ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi16ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 00000073AC00: F4100100 F8000000
	v_and_b32_e32 v23, 15, v0                                  // 00000073AC08: 362E008F
	v_lshrrev_b32_e32 v1, 4, v0                                // 00000073AC0C: 32020084
	s_ashr_i32 s3, s2, 31                                      // 00000073AC10: 86039F02
	v_lshlrev_b32_e32 v0, 2, v0                                // 00000073AC14: 30000082
	s_lshl_b64 s[0:1], s[2:3], 4                               // 00000073AC18: 84808402
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000073AC1C: BF870009
	v_dual_mov_b32 v17, s1 :: v_dual_lshlrev_b32 v2, 2, v23    // 00000073AC20: CA220001 11022E82
	v_lshlrev_b32_e32 v3, 2, v1                                // 00000073AC28: 30060282
	v_or_b32_e32 v16, s0, v1                                   // 00000073AC2C: 38200200
	.long 0x7f023880                                           // 00000073AC30: 7F023880
	s_waitcnt lgkmcnt(0)                                       // 00000073AC34: BF89FC07
	s_clause 0x1                                               // 00000073AC38: BF850001
	global_load_b32 v2, v2, s[4:5]                             // 00000073AC3C: DC520000 02040002
	global_load_b32 v3, v3, s[4:5]                             // 00000073AC44: DC520000 03040003
	.long 0xd4540000                                           // 00000073AC4C: D4540000
	v_cndmask_b32_e32 v1, s12, v16, vcc_lo                     // 00000073AC50: 0202200C
	s_add_u32 s20, s4, s16                                     // 00000073AC54: 80141004
	s_addc_u32 s21, s5, s17                                    // 00000073AC58: 82151105
	s_ashr_i32 s2, s11, 31                                     // 00000073AC5C: 86029F0B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 00000073AC60: BF870159
	s_lshr_b32 s2, s2, 27                                      // 00000073AC64: 85029B02
	v_cndmask_b32_e64 v8, 0, v16, s0                           // 00000073AC68: D5010008 00022080
	v_cndmask_b32_e64 v9, 0, s1, s0                            // 00000073AC70: D5010009 00000280
	s_add_u32 s2, s10, s2                                      // 00000073AC78: 8002020A
	s_addc_u32 s3, s11, 0                                      // 00000073AC7C: 8203800B
	.long 0xd72c0004                                           // 00000073AC80: D72C0004
	v_cndmask_b32_e32 v1, s19, v8, vcc_lo                      // 00000073AC84: 02021013
	v_mad_u64_u32 v[12:13], null, s18, v8, 0                   // 00000073AC88: D6FE7C0C 02021012
	s_lshr_b64 s[12:13], s[2:3], 5                             // 00000073AC90: 858C8502
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000073AC94: BF870009
	s_cmpk_lt_i32 s12, 0x81                                    // 00000073AC98: B38C0081
	.long 0xd4440002                                           // 00000073AC9C: D4440002
	v_cndmask_b32_e32 v1, s12, v23, vcc_lo                     // 00000073ACA0: 02022E0C
	s_cselect_b32 s1, -1, 0                                    // 00000073ACA4: 980180C1
	s_cmpk_gt_i32 s12, 0x80                                    // 00000073ACA8: B28C0080
	.long 0xd700030e                                           // 00000073ACAC: D700030E
	v_cndmask_b32_e32 v1, s20, v12, vcc_lo                     // 00000073ACB0: 02021814
	s_cselect_b32 s13, -1, 0                                   // 00000073ACB4: 980D80C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 00000073ACB8: BF870159
	s_and_b32 vcc_lo, exec_lo, s13                             // 00000073ACBC: 8B6A0D7E
	s_waitcnt vmcnt(1)                                         // 00000073ACC0: BF8907F7
	v_bfe_u32 v5, v2, 16, 1                                    // 00000073ACC4: D6100005 02052102
	s_waitcnt vmcnt(0)                                         // 00000073ACCC: BF8903F7
	v_bfe_u32 v6, v3, 16, 1                                    // 00000073ACD0: D6100006 02052103
	v_add3_u32 v2, v2, v5, 0x7fff                              // 00000073ACD8: D6550002 03FE0B02 00007FFF
	.long 0xd72c0005                                           // 00000073ACE4: D72C0005
	v_cndmask_b32_e32 v1, s18, v9, vcc_lo                      // 00000073ACE8: 02021212
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000073ACEC: BF870193
	v_add3_u32 v3, v3, v6, 0x7fff                              // 00000073ACF0: D6550003 03FE0D03 00007FFF
	.long 0x7e023982                                           // 00000073ACFC: 7E023982
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000073AD00: BF870113
	v_add3_u32 v13, v13, v5, v4                                // 00000073AD04: D655000D 04120B0D
	v_and_or_b32 v1, 0xffff0000, v3, v1                        // 00000073AD0C: D6570001 040606FF FFFF0000
	s_delay_alu instid0(VALU_DEP_2)                            // 00000073AD18: BF870002
	v_add_co_ci_u32_e64 v15, null, s21, v13, s3                // 00000073AD1C: D5207C0F 000E1A15
	ds_store_b32 v0, v1                                        // 00000073AD24: D8340000 00000100
	s_waitcnt lgkmcnt(0)                                       // 00000073AD2C: BF89FC07
	s_barrier                                                  // 00000073AD30: BFBD0000
	buffer_gl0_inv                                             // 00000073AD34: E0AC0000 00000000
	s_cbranch_vccnz 144                                        // 00000073AD3C: BFA40090 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi16ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x380>
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v0, 0               // 00000073AD40: CA100080 01000080
	s_and_saveexec_b32 s3, s2                                  // 00000073AD48: BE832002
	s_cbranch_execz 10                                         // 00000073AD4C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi16ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x178>
	v_lshlrev_b32_e32 v0, 1, v23                               // 00000073AD50: 30002E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000073AD54: BF870091
	.long 0xd7006a02                                           // 00000073AD58: D7006A02
	v_cndmask_b32_e32 v1, v14, v0, vcc_lo                      // 00000073AD5C: 0202010E
	v_add_co_ci_u32_e64 v3, null, 0, v15, vcc_lo               // 00000073AD60: D5207C03 01AA1E80
	global_load_d16_b16 v0, v[2:3], off                        // 00000073AD68: DC820000 007C0002
	s_waitcnt vmcnt(0)                                         // 00000073AD70: BF8903F7
	v_cvt_f32_f16_e32 v0, v0                                   // 00000073AD74: 7E001700
	s_or_b32 exec_lo, exec_lo, s3                              // 00000073AD78: 8C7E037E
	v_or_b32_e32 v2, 16, v23                                   // 00000073AD7C: 38042E90
	s_mov_b32 s2, exec_lo                                      // 00000073AD80: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000073AD84: BF870001
	.long 0xd4c4007e                                           // 00000073AD88: D4C4007E
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 00000073AD8C: 0202040C
	s_cbranch_execz 10                                         // 00000073AD90: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi16ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x1bc>
	v_lshlrev_b32_e32 v1, 1, v2                                // 00000073AD94: 30020481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000073AD98: BF870091
	.long 0xd7006a01                                           // 00000073AD9C: D7006A01
	v_cndmask_b32_e32 v1, v14, v1, vcc_lo                      // 00000073ADA0: 0202030E
	v_add_co_ci_u32_e64 v2, null, 0, v15, vcc_lo               // 00000073ADA4: D5207C02 01AA1E80
	global_load_d16_b16 v1, v[1:2], off                        // 00000073ADAC: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 00000073ADB4: BF8903F7
	v_cvt_f32_f16_e32 v1, v1                                   // 00000073ADB8: 7E021701
	s_or_b32 exec_lo, exec_lo, s2                              // 00000073ADBC: 8C7E027E
	v_or_b32_e32 v4, 32, v23                                   // 00000073ADC0: 38082EA0
	v_dual_mov_b32 v3, 0 :: v_dual_mov_b32 v2, 0               // 00000073ADC4: CA100080 03020080
	s_mov_b32 s2, exec_lo                                      // 00000073ADCC: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000073ADD0: BF870002
	.long 0xd4c4007e                                           // 00000073ADD4: D4C4007E
	v_cndmask_b32_e32 v1, s12, v4, vcc_lo                      // 00000073ADD8: 0202080C
	s_cbranch_execz 10                                         // 00000073ADDC: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi16ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x208>
	v_lshlrev_b32_e32 v2, 1, v4                                // 00000073ADE0: 30040881
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000073ADE4: BF870091
	.long 0xd7006a04                                           // 00000073ADE8: D7006A04
	v_cndmask_b32_e32 v1, v14, v2, vcc_lo                      // 00000073ADEC: 0202050E
	v_add_co_ci_u32_e64 v5, null, 0, v15, vcc_lo               // 00000073ADF0: D5207C05 01AA1E80
	global_load_d16_b16 v2, v[4:5], off                        // 00000073ADF8: DC820000 027C0004
	s_waitcnt vmcnt(0)                                         // 00000073AE00: BF8903F7
	v_cvt_f32_f16_e32 v2, v2                                   // 00000073AE04: 7E041702
	s_or_b32 exec_lo, exec_lo, s2                              // 00000073AE08: 8C7E027E
	v_or_b32_e32 v4, 48, v23                                   // 00000073AE0C: 38082EB0
	s_mov_b32 s2, exec_lo                                      // 00000073AE10: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000073AE14: BF870001
	.long 0xd4c4007e                                           // 00000073AE18: D4C4007E
	v_cndmask_b32_e32 v1, s12, v4, vcc_lo                      // 00000073AE1C: 0202080C
	s_cbranch_execz 10                                         // 00000073AE20: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi16ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x24c>
	v_lshlrev_b32_e32 v3, 1, v4                                // 00000073AE24: 30060881
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000073AE28: BF870091
	.long 0xd7006a03                                           // 00000073AE2C: D7006A03
	v_cndmask_b32_e32 v1, v14, v3, vcc_lo                      // 00000073AE30: 0202070E
	v_add_co_ci_u32_e64 v4, null, 0, v15, vcc_lo               // 00000073AE34: D5207C04 01AA1E80
	global_load_d16_b16 v3, v[3:4], off                        // 00000073AE3C: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 00000073AE44: BF8903F7
	v_cvt_f32_f16_e32 v3, v3                                   // 00000073AE48: 7E061703
	s_or_b32 exec_lo, exec_lo, s2                              // 00000073AE4C: 8C7E027E
	v_or_b32_e32 v6, 64, v23                                   // 00000073AE50: 380C2EC0
	v_dual_mov_b32 v5, 0 :: v_dual_mov_b32 v4, 0               // 00000073AE54: CA100080 05040080
	s_mov_b32 s2, exec_lo                                      // 00000073AE5C: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000073AE60: BF870002
	.long 0xd4c4007e                                           // 00000073AE64: D4C4007E
	v_cndmask_b32_e32 v1, s12, v6, vcc_lo                      // 00000073AE68: 02020C0C
	s_cbranch_execz 10                                         // 00000073AE6C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi16ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x298>
	v_lshlrev_b32_e32 v4, 1, v6                                // 00000073AE70: 30080C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000073AE74: BF870091
	.long 0xd7006a06                                           // 00000073AE78: D7006A06
	v_cndmask_b32_e32 v1, v14, v4, vcc_lo                      // 00000073AE7C: 0202090E
	v_add_co_ci_u32_e64 v7, null, 0, v15, vcc_lo               // 00000073AE80: D5207C07 01AA1E80
	global_load_d16_b16 v4, v[6:7], off                        // 00000073AE88: DC820000 047C0006
	s_waitcnt vmcnt(0)                                         // 00000073AE90: BF8903F7
	v_cvt_f32_f16_e32 v4, v4                                   // 00000073AE94: 7E081704
	s_or_b32 exec_lo, exec_lo, s2                              // 00000073AE98: 8C7E027E
	v_or_b32_e32 v6, 0x50, v23                                 // 00000073AE9C: 380C2EFF 00000050
	s_mov_b32 s2, exec_lo                                      // 00000073AEA4: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000073AEA8: BF870001
	.long 0xd4c4007e                                           // 00000073AEAC: D4C4007E
	v_cndmask_b32_e32 v1, s12, v6, vcc_lo                      // 00000073AEB0: 02020C0C
	s_cbranch_execz 10                                         // 00000073AEB4: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi16ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x2e0>
	v_lshlrev_b32_e32 v5, 1, v6                                // 00000073AEB8: 300A0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000073AEBC: BF870091
	.long 0xd7006a05                                           // 00000073AEC0: D7006A05
	v_cndmask_b32_e32 v1, v14, v5, vcc_lo                      // 00000073AEC4: 02020B0E
	v_add_co_ci_u32_e64 v6, null, 0, v15, vcc_lo               // 00000073AEC8: D5207C06 01AA1E80
	global_load_d16_b16 v5, v[5:6], off                        // 00000073AED0: DC820000 057C0005
	s_waitcnt vmcnt(0)                                         // 00000073AED8: BF8903F7
	v_cvt_f32_f16_e32 v5, v5                                   // 00000073AEDC: 7E0A1705
	s_or_b32 exec_lo, exec_lo, s2                              // 00000073AEE0: 8C7E027E
	v_or_b32_e32 v10, 0x60, v23                                // 00000073AEE4: 38142EFF 00000060
	v_dual_mov_b32 v7, 0 :: v_dual_mov_b32 v6, 0               // 00000073AEEC: CA100080 07060080
	s_mov_b32 s2, exec_lo                                      // 00000073AEF4: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000073AEF8: BF870002
	.long 0xd4c4007e                                           // 00000073AEFC: D4C4007E
	v_cndmask_b32_e32 v1, s12, v10, vcc_lo                     // 00000073AF00: 0202140C
	s_cbranch_execz 10                                         // 00000073AF04: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi16ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x330>
	v_lshlrev_b32_e32 v6, 1, v10                               // 00000073AF08: 300C1481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000073AF0C: BF870091
	.long 0xd7006a0a                                           // 00000073AF10: D7006A0A
	v_cndmask_b32_e32 v1, v14, v6, vcc_lo                      // 00000073AF14: 02020D0E
	v_add_co_ci_u32_e64 v11, null, 0, v15, vcc_lo              // 00000073AF18: D5207C0B 01AA1E80
	global_load_d16_b16 v6, v[10:11], off                      // 00000073AF20: DC820000 067C000A
	s_waitcnt vmcnt(0)                                         // 00000073AF28: BF8903F7
	v_cvt_f32_f16_e32 v6, v6                                   // 00000073AF2C: 7E0C1706
	s_or_b32 exec_lo, exec_lo, s2                              // 00000073AF30: 8C7E027E
	v_or_b32_e32 v10, 0x70, v23                                // 00000073AF34: 38142EFF 00000070
	s_mov_b32 s2, exec_lo                                      // 00000073AF3C: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000073AF40: BF870001
	.long 0xd4c4007e                                           // 00000073AF44: D4C4007E
	v_cndmask_b32_e32 v1, s12, v10, vcc_lo                     // 00000073AF48: 0202140C
	s_cbranch_execz 10                                         // 00000073AF4C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi16ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x378>
	v_lshlrev_b32_e32 v7, 1, v10                               // 00000073AF50: 300E1481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000073AF54: BF870091
	.long 0xd7006a0a                                           // 00000073AF58: D7006A0A
	v_cndmask_b32_e32 v1, v14, v7, vcc_lo                      // 00000073AF5C: 02020F0E
	v_add_co_ci_u32_e64 v11, null, 0, v15, vcc_lo              // 00000073AF60: D5207C0B 01AA1E80
	global_load_d16_b16 v7, v[10:11], off                      // 00000073AF68: DC820000 077C000A
	s_waitcnt vmcnt(0)                                         // 00000073AF70: BF8903F7
	v_cvt_f32_f16_e32 v7, v7                                   // 00000073AF74: 7E0E1707
	s_or_b32 exec_lo, exec_lo, s2                              // 00000073AF78: 8C7E027E
	s_branch 9                                                 // 00000073AF7C: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi16ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x3a4>
	v_mov_b32_e32 v0, 0                                        // 00000073AF80: 7E000280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000073AF84: BF870001
	v_mov_b32_e32 v1, v0                                       // 00000073AF88: 7E020300
	v_mov_b32_e32 v2, v0                                       // 00000073AF8C: 7E040300
	v_mov_b32_e32 v3, v0                                       // 00000073AF90: 7E060300
	v_mov_b32_e32 v4, v0                                       // 00000073AF94: 7E080300
	v_mov_b32_e32 v5, v0                                       // 00000073AF98: 7E0A0300
	v_mov_b32_e32 v6, v0                                       // 00000073AF9C: 7E0C0300
	v_mov_b32_e32 v7, v0                                       // 00000073AFA0: 7E0E0300
	s_add_u32 s2, s4, s14                                      // 00000073AFA4: 80020E04
	s_addc_u32 s3, s5, s15                                     // 00000073AFA8: 82030F05
	s_lshr_b32 s14, s11, 31                                    // 00000073AFAC: 850E9F0B
	v_mov_b32_e32 v26, 0                                       // 00000073AFB0: 7E340280
	s_add_u32 s10, s10, s14                                    // 00000073AFB4: 800A0E0A
	s_addc_u32 s11, s11, 0                                     // 00000073AFB8: 820B800B
	v_cndmask_b32_e64 v24, 0, 1, s13                           // 00000073AFBC: D5010018 00350280
	s_ashr_i64 s[10:11], s[10:11], 1                           // 00000073AFC4: 868A810A
	v_mov_b32_e32 v27, 0                                       // 00000073AFC8: 7E360280
	v_mad_u64_u32 v[18:19], null, v8, s10, s[2:3]              // 00000073AFCC: D6FE7C12 00081508
	.long 0xd72c000b                                           // 00000073AFD4: D72C000B
	v_cndmask_b32_e32 v0, v8, v11, vcc_lo                      // 00000073AFD8: 02001708
	.long 0xd72c0014                                           // 00000073AFDC: D72C0014
	v_cndmask_b32_e32 v0, v9, v10, vcc_lo                      // 00000073AFE0: 02001509
	.long 0xd4440002                                           // 00000073AFE4: D4440002
	v_cndmask_b32_e32 v1, s12, v23, vcc_lo                     // 00000073AFE8: 02022E0C
	v_dual_mov_b32 v8, 0 :: v_dual_mov_b32 v9, 0               // 00000073AFEC: CA100080 08080080
	v_mov_b32_e32 v10, 0                                       // 00000073AFF4: 7E140280
	s_delay_alu instid0(VALU_DEP_4)                            // 00000073AFF8: BF870004
	v_add3_u32 v25, v20, v19, v11                              // 00000073AFFC: D6550019 042E2714
	v_mov_b32_e32 v11, 0                                       // 00000073B004: 7E160280
	s_and_saveexec_b32 s3, s2                                  // 00000073B008: BE832002
	s_cbranch_execz 21                                         // 00000073B00C: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi16ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x464>
	v_dual_mov_b32 v27, 0 :: v_dual_lshlrev_b32 v8, 4, v23     // 00000073B010: CA220080 1B082E84
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000073B018: BF870091
	.long 0xd7006a08                                           // 00000073B01C: D7006A08
	v_cndmask_b32_e32 v1, v18, v8, vcc_lo                      // 00000073B020: 02021112
	v_add_co_ci_u32_e64 v9, null, 0, v25, vcc_lo               // 00000073B024: D5207C09 01AA3280
	s_and_not1_b32 vcc_lo, exec_lo, s13                        // 00000073B02C: 916A0D7E
	global_load_b128 v[8:11], v[8:9], off                      // 00000073B030: DC5E0000 087C0008
	s_cbranch_vccnz 10                                         // 00000073B038: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi16ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x464>
	v_lshlrev_b32_e32 v19, 1, v23                              // 00000073B03C: 30262E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000073B040: BF870091
	.long 0xd7006a0e                                           // 00000073B044: D7006A0E
	v_cndmask_b32_e32 v1, v14, v19, vcc_lo                     // 00000073B048: 0202270E
	v_add_co_ci_u32_e64 v15, null, 0, v15, vcc_lo              // 00000073B04C: D5207C0F 01AA1E80
	global_load_d16_b16 v14, v[14:15], off                     // 00000073B054: DC820000 0E7C000E
	s_waitcnt vmcnt(0)                                         // 00000073B05C: BF8903F7
	v_cvt_f32_f16_e32 v27, v14                                 // 00000073B060: 7E36170E
	s_or_b32 exec_lo, exec_lo, s3                              // 00000073B064: 8C7E037E
	s_and_saveexec_b32 s3, s2                                  // 00000073B068: BE832002
	s_cbranch_execz 256                                        // 00000073B06C: BFA50100 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi16ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x870>
	v_dual_mov_b32 v29, v23 :: v_dual_lshlrev_b32 v14, 1, v23  // 00000073B070: CA220117 1D0E2E81
	.long 0xd7006a0c                                           // 00000073B078: D7006A0C
	v_cndmask_b32_e32 v1, s16, v12, vcc_lo                     // 00000073B07C: 02021810
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000073B080: BF8701A1
	v_add_co_ci_u32_e64 v13, null, s17, v13, vcc_lo            // 00000073B084: D5207C0D 01AA1A11
	v_dual_mov_b32 v20, 0 :: v_dual_lshlrev_b32 v19, 5, v23    // 00000073B08C: CA220080 14122E85
	.long 0xd7006a0c                                           // 00000073B094: D7006A0C
	v_cndmask_b32_e32 v1, v12, v14, vcc_lo                     // 00000073B098: 02021D0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000073B09C: BF8701A1
	v_add_co_ci_u32_e64 v13, null, 0, v13, vcc_lo              // 00000073B0A0: D5207C0D 01AA1A80
	v_lshl_or_b32 v28, v23, 4, 0x100                           // 00000073B0A8: D656001C 03FD0917 00000100
	.long 0xd7006a0c                                           // 00000073B0B4: D7006A0C
	v_cndmask_b32_e32 v1, s4, v12, vcc_lo                      // 00000073B0B8: 02021804
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000073B0BC: BF8701A1
	v_add_co_ci_u32_e64 v13, null, s5, v13, vcc_lo             // 00000073B0C0: D5207C0D 01AA1A05
	v_mov_b32_e32 v26, v20                                     // 00000073B0C8: 7E340314
	.long 0xd7006a15                                           // 00000073B0CC: D7006A15
	v_cndmask_b32_e32 v0, v12, v160, vcc_lo                    // 00000073B0D0: 0201410C
	s_delay_alu instid0(VALU_DEP_1)                            // 00000073B0D4: BF870001
	v_add_co_ci_u32_e64 v22, null, 0, v13, vcc_lo              // 00000073B0D8: D5207C16 01AA1A80
	v_mov_b32_e32 v30, v27                                     // 00000073B0E0: 7E3C031B
	s_mov_b32 s4, 0                                            // 00000073B0E4: BE840080
	s_branch 196                                               // 00000073B0E8: BFA000C4 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi16ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x7fc>
	s_or_b32 exec_lo, exec_lo, s5                              // 00000073B0EC: 8C7E057E
	.long 0xd73c001f                                           // 00000073B0F0: D73C001F
	v_cndmask_b32_e32 v1, 1, v19, vcc_lo                       // 00000073B0F4: 02022681
	v_and_b32_e32 v47, 0xff, v8                                // 00000073B0F8: 365E10FF 000000FF
	v_lshrrev_b32_e32 v48, 6, v8                               // 00000073B100: 32601086
	v_lshrrev_b32_e32 v49, 14, v8                              // 00000073B104: 3262108E
	v_lshrrev_b32_e32 v8, 22, v8                               // 00000073B108: 32101096
	v_and_b32_e32 v50, 0xff, v9                                // 00000073B10C: 366412FF 000000FF
	.long 0xd7006a2b                                           // 00000073B114: D7006A2B
	v_cndmask_b32_e32 v1, s6, v31, vcc_lo                      // 00000073B118: 02023E06
	s_delay_alu instid0(VALU_DEP_1)                            // 00000073B11C: BF870001
	v_add_co_ci_u32_e64 v44, null, s7, v32, vcc_lo             // 00000073B120: D5207C2C 01AA4007
	v_lshlrev_b32_e32 v47, 2, v47                              // 00000073B128: 305E5E82
	v_and_b32_e32 v48, 0x3fc, v48                              // 00000073B12C: 366060FF 000003FC
	v_and_b32_e32 v49, 0x3fc, v49                              // 00000073B134: 366262FF 000003FC
	s_clause 0x3                                               // 00000073B13C: BF850003
	global_load_b128 v[31:34], v[43:44], off                   // 00000073B140: DC5E0000 1F7C002B
	global_load_b128 v[35:38], v[43:44], off offset:16         // 00000073B148: DC5E0010 237C002B
	global_load_b128 v[39:42], v[43:44], off offset:32         // 00000073B150: DC5E0020 277C002B
	global_load_b128 v[43:46], v[43:44], off offset:48         // 00000073B158: DC5E0030 2B7C002B
	v_lshrrev_b32_e32 v51, 6, v9                               // 00000073B160: 32661286
	ds_load_b32 v47, v47                                       // 00000073B164: D8D80000 2F00002F
	ds_load_b32 v48, v48                                       // 00000073B16C: D8D80000 30000030
	ds_load_b32 v49, v49                                       // 00000073B174: D8D80000 31000031
	v_lshrrev_b32_e32 v52, 14, v9                              // 00000073B17C: 3268128E
	v_lshrrev_b32_e32 v9, 22, v9                               // 00000073B180: 32121296
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000073B184: 361010FF 000003FC
	v_lshlrev_b32_e32 v50, 2, v50                              // 00000073B18C: 30646482
	v_and_b32_e32 v51, 0x3fc, v51                              // 00000073B190: 366666FF 000003FC
	v_and_b32_e32 v52, 0x3fc, v52                              // 00000073B198: 366868FF 000003FC
	v_and_b32_e32 v9, 0x3fc, v9                                // 00000073B1A0: 361212FF 000003FC
	ds_load_b32 v8, v8                                         // 00000073B1A8: D8D80000 08000008
	ds_load_b32 v50, v50                                       // 00000073B1B0: D8D80000 32000032
	ds_load_b32 v51, v51                                       // 00000073B1B8: D8D80000 33000033
	ds_load_b32 v52, v52                                       // 00000073B1C0: D8D80000 34000034
	ds_load_b32 v9, v9                                         // 00000073B1C8: D8D80000 09000009
	.long 0xd7006a15                                           // 00000073B1D0: D7006A15
	v_cndmask_b32_e32 v0, v21, v160, vcc_lo                    // 00000073B1D4: 02014115
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000073B1D8: BF8704A1
	v_add_co_ci_u32_e64 v22, null, 0, v22, vcc_lo              // 00000073B1DC: D5207C16 01AA2C80
	s_and_b32 s2, exec_lo, s2                                  // 00000073B1E4: 8B02027E
	s_or_b32 s4, s2, s4                                        // 00000073B1E8: 8C040402
	s_waitcnt vmcnt(3) lgkmcnt(7)                              // 00000073B1EC: BF890C77
	v_dot2_f32_bf16 v31, v31, v47, 0                           // 00000073B1F0: CC1A401F 1A025F1F
	v_lshrrev_b32_e32 v47, 14, v10                             // 00000073B1F8: 325E148E
	s_waitcnt lgkmcnt(6)                                       // 00000073B1FC: BF89FC67
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000073B200: BF870132
	v_dot2_f32_bf16 v31, v32, v48, v31                         // 00000073B204: CC1A401F 1C7E6120
	v_and_b32_e32 v32, 0xff, v10                               // 00000073B20C: 364014FF 000000FF
	s_waitcnt lgkmcnt(5)                                       // 00000073B214: BF89FC57
	v_dot2_f32_bf16 v31, v33, v49, v31                         // 00000073B218: CC1A401F 1C7E6321
	v_lshrrev_b32_e32 v33, 6, v10                              // 00000073B220: 32421486
	v_lshrrev_b32_e32 v10, 22, v10                             // 00000073B224: 32141496
	s_waitcnt lgkmcnt(4)                                       // 00000073B228: BF89FC47
	s_delay_alu instid0(VALU_DEP_3)                            // 00000073B22C: BF870003
	v_dot2_f32_bf16 v8, v34, v8, v31                           // 00000073B230: CC1A4008 1C7E1122
	v_lshlrev_b32_e32 v31, 2, v32                              // 00000073B238: 303E4082
	v_and_b32_e32 v33, 0x3fc, v33                              // 00000073B23C: 364242FF 000003FC
	v_and_b32_e32 v32, 0xff, v11                               // 00000073B244: 364016FF 000000FF
	v_lshrrev_b32_e32 v34, 6, v11                              // 00000073B24C: 32441686
	s_waitcnt vmcnt(2) lgkmcnt(3)                              // 00000073B250: BF890837
	v_dot2_f32_bf16 v8, v35, v50, v8                           // 00000073B254: CC1A4008 1C226523
	ds_load_b32 v31, v31                                       // 00000073B25C: D8D80000 1F00001F
	ds_load_b32 v33, v33                                       // 00000073B264: D8D80000 21000021
	v_lshrrev_b32_e32 v35, 14, v11                             // 00000073B26C: 3246168E
	v_lshrrev_b32_e32 v11, 22, v11                             // 00000073B270: 32161696
	s_waitcnt lgkmcnt(4)                                       // 00000073B274: BF89FC47
	v_dot2_f32_bf16 v8, v36, v51, v8                           // 00000073B278: CC1A4008 1C226724
	v_lshlrev_b32_e32 v32, 2, v32                              // 00000073B280: 30404082
	v_and_b32_e32 v34, 0x3fc, v34                              // 00000073B284: 364444FF 000003FC
	v_and_b32_e32 v35, 0x3fc, v35                              // 00000073B28C: 364646FF 000003FC
	s_waitcnt lgkmcnt(3)                                       // 00000073B294: BF89FC37
	v_dot2_f32_bf16 v8, v37, v52, v8                           // 00000073B298: CC1A4008 1C226925
	v_cndmask_b32_e64 v37, v6, v7, s1                          // 00000073B2A0: D5010025 00060F06
	v_and_b32_e32 v47, 0x3fc, v47                              // 00000073B2A8: 365E5EFF 000003FC
	s_waitcnt lgkmcnt(2)                                       // 00000073B2B0: BF89FC27
	s_delay_alu instid0(VALU_DEP_3)                            // 00000073B2B4: BF870003
	v_dot2_f32_bf16 v8, v38, v9, v8                            // 00000073B2B8: CC1A4008 1C221326
	ds_load_b32 v36, v47                                       // 00000073B2C0: D8D80000 2400002F
	s_waitcnt vmcnt(1) lgkmcnt(2)                              // 00000073B2C8: BF890427
	v_dot2_f32_bf16 v8, v39, v31, v8                           // 00000073B2CC: CC1A4008 1C223F27
	v_cndmask_b32_e64 v31, v0, v1, s1                          // 00000073B2D4: D501001F 00060300
	v_cndmask_b32_e64 v39, v27, v0, s1                         // 00000073B2DC: D5010027 0006011B
	v_mov_b32_e32 v27, v30                                     // 00000073B2E4: 7E36031E
	s_waitcnt lgkmcnt(1)                                       // 00000073B2E8: BF89FC17
	v_dot2_f32_bf16 v8, v40, v33, v8                           // 00000073B2EC: CC1A4008 1C224328
	v_cndmask_b32_e64 v33, v2, v3, s1                          // 00000073B2F4: D5010021 00060702
	s_waitcnt lgkmcnt(0)                                       // 00000073B2FC: BF89FC07
	s_delay_alu instid0(VALU_DEP_2)                            // 00000073B300: BF870002
	v_dot2_f32_bf16 v8, v41, v36, v8                           // 00000073B304: CC1A4008 1C224929
	v_cndmask_b32_e64 v36, v5, v6, s1                          // 00000073B30C: D5010024 00060D05
	v_and_b32_e32 v10, 0x3fc, v10                              // 00000073B314: 361414FF 000003FC
	v_and_b32_e32 v11, 0x3fc, v11                              // 00000073B31C: 361616FF 000003FC
	ds_load_b32 v9, v10                                        // 00000073B324: D8D80000 0900000A
	ds_load_b32 v10, v32                                       // 00000073B32C: D8D80000 0A000020
	ds_load_b32 v38, v34                                       // 00000073B334: D8D80000 26000022
	ds_load_b32 v47, v35                                       // 00000073B33C: D8D80000 2F000023
	ds_load_b32 v48, v11                                       // 00000073B344: D8D80000 3000000B
	v_cndmask_b32_e64 v32, v1, v2, s1                          // 00000073B34C: D5010020 00060501
	v_cndmask_b32_e64 v35, v4, v5, s1                          // 00000073B354: D5010023 00060B04
	v_cndmask_b32_e64 v34, v3, v4, s1                          // 00000073B35C: D5010022 00060903
	v_mov_b32_e32 v11, v15                                     // 00000073B364: 7E16030F
	s_waitcnt lgkmcnt(4)                                       // 00000073B368: BF89FC47
	v_dot2_f32_bf16 v8, v42, v9, v8                            // 00000073B36C: CC1A4008 1C22132A
	v_mov_b32_e32 v9, v13                                      // 00000073B374: 7E12030D
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 00000073B378: BF890037
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000073B37C: BF8701C2
	v_dot2_f32_bf16 v6, v43, v10, v8                           // 00000073B380: CC1A4006 1C22152B
	v_mov_b32_e32 v10, v14                                     // 00000073B388: 7E14030E
	v_mov_b32_e32 v8, v12                                      // 00000073B38C: 7E10030C
	s_waitcnt lgkmcnt(2)                                       // 00000073B390: BF89FC27
	v_dot2_f32_bf16 v2, v44, v38, v6                           // 00000073B394: CC1A4002 1C1A4D2C
	v_dual_mov_b32 v38, v7 :: v_dual_add_nc_u32 v19, 0x200, v19// 00000073B39C: CA200107 261226FF 00000200
	v_add_nc_u32_e32 v28, 0x100, v28                           // 00000073B3A8: 4A3838FF 00000100
	s_waitcnt lgkmcnt(1)                                       // 00000073B3B0: BF89FC17
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000073B3B4: BF8700A3
	v_dot2_f32_bf16 v0, v45, v47, v2                           // 00000073B3B8: CC1A4000 1C0A5F2D
	s_waitcnt lgkmcnt(0)                                       // 00000073B3C0: BF89FC07
	v_dot2_f32_bf16 v0, v46, v48, v0                           // 00000073B3C4: CC1A4000 1C02612E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000073B3CC: BF870001
	v_fmac_f32_e32 v26, v39, v0                                // 00000073B3D0: 56340127
	v_dual_mov_b32 v0, v31 :: v_dual_mov_b32 v1, v32           // 00000073B3D4: CA10011F 00000120
	v_dual_mov_b32 v2, v33 :: v_dual_mov_b32 v3, v34           // 00000073B3DC: CA100121 02020122
	v_dual_mov_b32 v4, v35 :: v_dual_mov_b32 v5, v36           // 00000073B3E4: CA100123 04040124
	v_dual_mov_b32 v6, v37 :: v_dual_mov_b32 v7, v38           // 00000073B3EC: CA100125 06060126
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000073B3F4: 917E047E
	s_cbranch_execz 28                                         // 00000073B3F8: BFA5001C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi16ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x86c>
	s_waitcnt vmcnt(0)                                         // 00000073B3FC: BF8903F7
	v_dual_mov_b32 v12, v8 :: v_dual_add_nc_u32 v29, 16, v29   // 00000073B400: CA200108 0C1C3A90
	v_dual_mov_b32 v13, v9 :: v_dual_mov_b32 v14, v10          // 00000073B408: CA100109 0D0E010A
	v_mov_b32_e32 v15, v11                                     // 00000073B410: 7E1E030B
	s_delay_alu instid0(VALU_DEP_3)                            // 00000073B414: BF870003
	.long 0xd4430002                                           // 00000073B418: D4430002
	v_cndmask_b32_e32 v1, s12, v29, vcc_lo                     // 00000073B41C: 02023A0C
	s_mov_b32 s5, exec_lo                                      // 00000073B420: BE85007E
	.long 0xd4c4007e                                           // 00000073B424: D4C4007E
	v_cndmask_b32_e32 v1, s12, v29, vcc_lo                     // 00000073B428: 02023A0C
	s_cbranch_execz 65327                                      // 00000073B42C: BFA5FF2F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi16ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x4ec>
	.long 0xd7006a0c                                           // 00000073B430: D7006A0C
	v_cndmask_b32_e32 v1, v18, v28, vcc_lo                     // 00000073B434: 02023912
	s_delay_alu instid0(VALU_DEP_1)                            // 00000073B438: BF870001
	v_add_co_ci_u32_e64 v13, null, 0, v25, vcc_lo              // 00000073B43C: D5207C0D 01AA3280
	v_cmp_ne_u32_e32 vcc_lo, 1, v24                            // 00000073B444: 7C9A3081
	v_mov_b32_e32 v30, v27                                     // 00000073B448: 7E3C031B
	global_load_b128 v[12:15], v[12:13], off                   // 00000073B44C: DC5E0000 0C7C000C
	s_cbranch_vccnz 65317                                      // 00000073B454: BFA4FF25 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi16ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x4ec>
	global_load_d16_b16 v30, v[21:22], off                     // 00000073B458: DC820000 1E7C0015
	s_waitcnt vmcnt(0)                                         // 00000073B460: BF8903F7
	v_cvt_f32_f16_e32 v30, v30                                 // 00000073B464: 7E3C171E
	s_branch 65312                                             // 00000073B468: BFA0FF20 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi16ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x4ec>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000073B46C: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000073B470: BF8700A9
	s_or_b32 exec_lo, exec_lo, s3                              // 00000073B474: 8C7E037E
	.long 0xd71f0000                                           // 00000073B478: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000073B47C: 020100C1
	v_xor_b32_e32 v1, 8, v0                                    // 00000073B480: 3A020088
	v_xor_b32_e32 v2, 4, v0                                    // 00000073B484: 3A040084
	v_xor_b32_e32 v3, 2, v0                                    // 00000073B488: 3A060082
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000073B48C: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v1                            // 00000073B490: 7C9802A0
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 00000073B494: 02020300
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 00000073B498: 7C9804A0
	v_cndmask_b32_e32 v2, v0, v2, vcc_lo                       // 00000073B49C: 02040500
	v_cmp_gt_u32_e32 vcc_lo, 32, v3                            // 00000073B4A0: 7C9806A0
	s_delay_alu instid0(VALU_DEP_2)                            // 00000073B4A4: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 00000073B4A8: 30040482
	v_lshlrev_b32_e32 v1, 2, v1                                // 00000073B4AC: 30020282
	ds_bpermute_b32 v1, v1, v26                                // 00000073B4B0: DACC0000 01001A01
	s_waitcnt lgkmcnt(0)                                       // 00000073B4B8: BF89FC07
	v_add_f32_e32 v1, v26, v1                                  // 00000073B4BC: 0602031A
	ds_bpermute_b32 v2, v2, v1                                 // 00000073B4C0: DACC0000 02000102
	s_waitcnt lgkmcnt(0)                                       // 00000073B4C8: BF89FC07
	v_add_f32_e32 v1, v1, v2                                   // 00000073B4CC: 06020501
	v_cndmask_b32_e32 v3, v0, v3, vcc_lo                       // 00000073B4D0: 02060700
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000073B4D4: BF8700B1
	v_lshlrev_b32_e32 v3, 2, v3                                // 00000073B4D8: 30060682
	ds_bpermute_b32 v2, v3, v1                                 // 00000073B4DC: DACC0000 02000103
	v_xor_b32_e32 v3, 1, v0                                    // 00000073B4E4: 3A060081
	v_cmp_gt_u32_e32 vcc_lo, 32, v3                            // 00000073B4E8: 7C9806A0
	v_cndmask_b32_e32 v3, v0, v3, vcc_lo                       // 00000073B4EC: 02060700
	v_cmp_eq_u32_e32 vcc_lo, 0, v23                            // 00000073B4F0: 7C942E80
	s_and_b32 s0, vcc_lo, s0                                   // 00000073B4F4: 8B00006A
	s_waitcnt lgkmcnt(0)                                       // 00000073B4F8: BF89FC07
	s_delay_alu instid0(VALU_DEP_2)                            // 00000073B4FC: BF870002
	v_dual_add_f32 v0, v1, v2 :: v_dual_lshlrev_b32 v1, 2, v3  // 00000073B500: C9220501 00000682
	ds_bpermute_b32 v1, v1, v0                                 // 00000073B508: DACC0000 01000001
	s_and_saveexec_b32 s1, s0                                  // 00000073B510: BE812000
	s_cbranch_execz 11                                         // 00000073B514: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi16ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x944>
	.long 0xd73c0002                                           // 00000073B518: D73C0002
	v_cndmask_b32_e32 v1, 2, v16, vcc_lo                       // 00000073B51C: 02022082
	s_waitcnt lgkmcnt(0)                                       // 00000073B520: BF89FC07
	v_add_f32_e32 v0, v0, v1                                   // 00000073B524: 06000300
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000073B528: BF870092
	.long 0xd7006a02                                           // 00000073B52C: D7006A02
	v_cndmask_b32_e32 v1, s8, v2, vcc_lo                       // 00000073B530: 02020408
	v_add_co_ci_u32_e64 v3, null, s9, v3, vcc_lo               // 00000073B534: D5207C03 01AA0609
	global_store_b32 v[2:3], v0, off                           // 00000073B53C: DC6A0000 007C0002
	s_endpgm                                                   // 00000073B544: BFB00000
		...

