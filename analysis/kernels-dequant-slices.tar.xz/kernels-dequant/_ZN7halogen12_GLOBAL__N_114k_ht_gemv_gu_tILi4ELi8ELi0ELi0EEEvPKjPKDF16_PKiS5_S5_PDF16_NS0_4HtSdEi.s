0000000000a78900 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi0ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi>:
; _ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi0ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi():
	s_load_b256 s[4:11], s[0:1], null                          // 000000A78900: F40C0100 F8000000
	s_mul_hi_i32 s3, s2, 0x66666667                            // 000000A78908: 9703FF02 66666667
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000A78910: BF8704A9
	s_lshr_b32 s12, s3, 31                                     // 000000A78914: 850C9F03
	s_ashr_i32 s3, s3, 1                                       // 000000A78918: 86038103
	s_add_i32 s16, s3, s12                                     // 000000A7891C: 81100C03
	s_mov_b32 s3, exec_lo                                      // 000000A78920: BE83007E
	s_ashr_i32 s17, s16, 31                                    // 000000A78924: 86119F10
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A78928: BF870009
	s_lshl_b64 s[12:13], s[16:17], 2                           // 000000A7892C: 848C8210
	s_waitcnt lgkmcnt(0)                                       // 000000A78930: BF89FC07
	s_add_u32 s8, s8, s12                                      // 000000A78934: 80080C08
	s_addc_u32 s9, s9, s13                                     // 000000A78938: 82090D09
	s_load_b128 s[12:15], s[0:1], 0x20                         // 000000A7893C: F4080300 F8000020
	s_load_b32 s1, s[8:9], null                                // 000000A78944: F4000044 F8000000
	v_cmpx_gt_u32_e32 0x140, v0                                // 000000A7894C: 7D9800FF 00000140
	s_cbranch_execz 46                                         // 000000A78954: BFA5002E <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi0ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x110>
	s_mul_hi_i32 s0, s2, 0x51eb851f                            // 000000A78958: 9700FF02 51EB851F
	v_lshlrev_b32_e32 v4, 4, v0                                // 000000A78960: 30080084
	s_lshr_b32 s8, s0, 31                                      // 000000A78964: 85089F00
	s_ashr_i32 s0, s0, 4                                       // 000000A78968: 86008400
	v_or_b32_e32 v3, 0xffffff00, v0                            // 000000A7896C: 380600FF FFFFFF00
	s_add_i32 s0, s0, s8                                       // 000000A78974: 81000800
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000A78978: BF8700D9
	s_mul_i32 s8, s0, 0x1400                                   // 000000A7897C: 9608FF00 00001400
	s_mul_hi_i32 s0, s0, 0x1400                                // 000000A78984: 9700FF00 00001400
	s_add_u32 s6, s6, s8                                       // 000000A7898C: 80060806
	s_addc_u32 s0, s7, s0                                      // 000000A78990: 82000007
	.long 0xd7000601                                           // 000000A78994: D7000601
	v_cndmask_b32_e32 v1, s6, v4, vcc_lo                       // 000000A78998: 02020806
	v_add_co_ci_u32_e64 v2, null, s0, 0, s6                    // 000000A7899C: D5207C02 00190000
	s_mov_b32 s6, 0                                            // 000000A789A4: BE860080
	s_nop 0                                                    // 000000A789A8: BF800000
	s_nop 0                                                    // 000000A789AC: BF800000
	s_nop 0                                                    // 000000A789B0: BF800000
	s_nop 0                                                    // 000000A789B4: BF800000
	s_nop 0                                                    // 000000A789B8: BF800000
	s_nop 0                                                    // 000000A789BC: BF800000
	global_load_b128 v[5:8], v[1:2], off                       // 000000A789C0: DC5E0000 057C0001
	v_add_nc_u32_e32 v3, 0x100, v3                             // 000000A789C8: 4A0606FF 00000100
	.long 0xd7006a01                                           // 000000A789D0: D7006A01
	v_cndmask_b32_e32 v1, 0x1000, v1, vcc_lo                   // 000000A789D4: 020202FF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A789DC: BF870191
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 000000A789E0: D5207C02 01AA0480
	.long 0xd4490000                                           // 000000A789E8: D4490000
	v_cndmask_b32_e32 v1, 63, v3, vcc_lo                       // 000000A789EC: 020206BF
	s_or_b32 s6, s0, s6                                        // 000000A789F0: 8C060600
	s_waitcnt vmcnt(0)                                         // 000000A789F4: BF8903F7
	ds_store_b128 v4, v[5:8]                                   // 000000A789F8: DB7C0000 00000504
	v_add_nc_u32_e32 v4, 0x1000, v4                            // 000000A78A00: 4A0808FF 00001000
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 000000A78A08: 917E067E
	s_cbranch_execnz 65516                                     // 000000A78A0C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi0ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0xc0>
	s_or_b32 exec_lo, exec_lo, s3                              // 000000A78A10: 8C7E037E
	v_lshrrev_b32_e32 v24, 5, v0                               // 000000A78A14: 32300085
	v_and_b32_e32 v25, 31, v0                                  // 000000A78A18: 3632009F
	v_mov_b32_e32 v1, 0                                        // 000000A78A1C: 7E020280
	s_mul_i32 s0, s16, -5                                      // 000000A78A20: 9600C510
	s_waitcnt lgkmcnt(0)                                       // 000000A78A24: BF89FC07
	s_mul_hi_i32 s6, s1, 0x190000                              // 000000A78A28: 9706FF01 00190000
	v_mul_u32_u24_e32 v18, 20, v24                             // 000000A78A30: 16243094
	v_lshlrev_b32_e32 v26, 2, v25                              // 000000A78A34: 30343282
	v_mov_b32_e32 v16, v1                                      // 000000A78A38: 7E200301
	v_mov_b32_e32 v2, v1                                       // 000000A78A3C: 7E040301
	v_mov_b32_e32 v3, v1                                       // 000000A78A40: 7E060301
	v_min_u32_e32 v19, 0x8c, v18                               // 000000A78A44: 262624FF 0000008C
	v_mov_b32_e32 v4, v1                                       // 000000A78A4C: 7E080301
	v_mov_b32_e32 v5, v1                                       // 000000A78A50: 7E0A0301
	v_mov_b32_e32 v6, v1                                       // 000000A78A54: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 000000A78A58: 7E0E0301
	v_dual_mov_b32 v8, v1 :: v_dual_add_nc_u32 v27, 20, v19    // 000000A78A5C: CA200101 081A2694
	v_mov_b32_e32 v9, v1                                       // 000000A78A64: 7E120301
	v_mov_b32_e32 v10, v1                                      // 000000A78A68: 7E140301
	v_mov_b32_e32 v11, v1                                      // 000000A78A6C: 7E160301
	v_mov_b32_e32 v12, v1                                      // 000000A78A70: 7E180301
	v_mov_b32_e32 v13, v1                                      // 000000A78A74: 7E1A0301
	v_mov_b32_e32 v14, v1                                      // 000000A78A78: 7E1C0301
	v_mov_b32_e32 v15, v1                                      // 000000A78A7C: 7E1E0301
	v_mov_b32_e32 v17, v16                                     // 000000A78A80: 7E220310
	v_cmp_lt_u32_e32 vcc_lo, v18, v27                          // 000000A78A84: 7C923712
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A78A88: BF870003
	v_mov_b32_e32 v16, v15                                     // 000000A78A8C: 7E20030F
	v_mov_b32_e32 v15, v14                                     // 000000A78A90: 7E1E030E
	v_mov_b32_e32 v14, v13                                     // 000000A78A94: 7E1C030D
	v_mov_b32_e32 v13, v12                                     // 000000A78A98: 7E1A030C
	v_mov_b32_e32 v12, v11                                     // 000000A78A9C: 7E18030B
	v_mov_b32_e32 v11, v10                                     // 000000A78AA0: 7E16030A
	v_mov_b32_e32 v10, v9                                      // 000000A78AA4: 7E140309
	v_mov_b32_e32 v9, v8                                       // 000000A78AA8: 7E120308
	v_mov_b32_e32 v8, v7                                       // 000000A78AAC: 7E100307
	v_mov_b32_e32 v7, v6                                       // 000000A78AB0: 7E0E0306
	v_mov_b32_e32 v6, v5                                       // 000000A78AB4: 7E0C0305
	v_mov_b32_e32 v5, v4                                       // 000000A78AB8: 7E0A0304
	v_mov_b32_e32 v4, v3                                       // 000000A78ABC: 7E080303
	v_mov_b32_e32 v3, v2                                       // 000000A78AC0: 7E060302
	v_mov_b32_e32 v2, v1                                       // 000000A78AC4: 7E040301
	s_add_i32 s2, s0, s2                                       // 000000A78AC8: 81020200
	s_mul_i32 s8, s1, 0x190000                                 // 000000A78ACC: 9608FF01 00190000
	s_mul_hi_i32 s7, s2, 0x50000                               // 000000A78AD4: 9707FF02 00050000
	s_mul_i32 s9, s2, 0x50000                                  // 000000A78ADC: 9609FF02 00050000
	s_barrier                                                  // 000000A78AE4: BFBD0000
	buffer_gl0_inv                                             // 000000A78AE8: E0AC0000 00000000
	s_and_saveexec_b32 s3, vcc_lo                              // 000000A78AF0: BE83206A
	s_cbranch_execz 49                                         // 000000A78AF4: BFA50031 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi0ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2bc>
	v_mul_u32_u24_e32 v2, 0xa000, v24                          // 000000A78AF8: 160430FF 0000A000
	s_add_u32 s0, s4, s8                                       // 000000A78B00: 80000804
	s_addc_u32 s17, s5, s6                                     // 000000A78B04: 82110605
	s_add_u32 s0, s0, s9                                       // 000000A78B08: 80000900
	s_addc_u32 s17, s17, s7                                    // 000000A78B0C: 82110711
	.long 0xd7000002                                           // 000000A78B10: D7000002
	v_cndmask_b32_e32 v1, s0, v2, vcc_lo                       // 000000A78B14: 02020400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A78B18: BF870111
	v_add_co_ci_u32_e64 v3, null, s17, 0, s0                   // 000000A78B1C: D5207C03 00010011
	.long 0xd7000014                                           // 000000A78B24: D7000014
	v_cndmask_b32_e32 v1, v2, v26, vcc_lo                      // 000000A78B28: 02023502
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A78B2C: BF870001
	v_add_co_ci_u32_e64 v21, null, 0, v3, s0                   // 000000A78B30: D5207C15 00020680
	s_clause 0xf                                               // 000000A78B38: BF85000F
	global_load_b32 v2, v[20:21], off                          // 000000A78B3C: DC520000 027C0014
	global_load_b32 v3, v[20:21], off offset:128               // 000000A78B44: DC520080 037C0014
	global_load_b32 v4, v[20:21], off offset:256               // 000000A78B4C: DC520100 047C0014
	global_load_b32 v5, v[20:21], off offset:384               // 000000A78B54: DC520180 057C0014
	global_load_b32 v6, v[20:21], off offset:512               // 000000A78B5C: DC520200 067C0014
	global_load_b32 v7, v[20:21], off offset:640               // 000000A78B64: DC520280 077C0014
	global_load_b32 v8, v[20:21], off offset:768               // 000000A78B6C: DC520300 087C0014
	global_load_b32 v9, v[20:21], off offset:896               // 000000A78B74: DC520380 097C0014
	global_load_b32 v10, v[20:21], off offset:1024             // 000000A78B7C: DC520400 0A7C0014
	global_load_b32 v11, v[20:21], off offset:1152             // 000000A78B84: DC520480 0B7C0014
	global_load_b32 v12, v[20:21], off offset:1280             // 000000A78B8C: DC520500 0C7C0014
	global_load_b32 v13, v[20:21], off offset:1408             // 000000A78B94: DC520580 0D7C0014
	global_load_b32 v14, v[20:21], off offset:1536             // 000000A78B9C: DC520600 0E7C0014
	global_load_b32 v15, v[20:21], off offset:1664             // 000000A78BA4: DC520680 0F7C0014
	global_load_b32 v16, v[20:21], off offset:1792             // 000000A78BAC: DC520700 107C0014
	global_load_b32 v17, v[20:21], off offset:1920             // 000000A78BB4: DC520780 117C0014
	s_or_b32 exec_lo, exec_lo, s3                              // 000000A78BBC: 8C7E037E
	v_dual_mov_b32 v29, 0 :: v_dual_mov_b32 v30, 0             // 000000A78BC0: CA100080 1D1E0080
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v32, 0             // 000000A78BC8: CA100080 1F200080
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v34, 0             // 000000A78BD0: CA100080 21220080
	v_dual_mov_b32 v35, 0 :: v_dual_mov_b32 v36, 0             // 000000A78BD8: CA100080 23240080
	v_dual_mov_b32 v37, 0 :: v_dual_mov_b32 v38, 0             // 000000A78BE0: CA100080 25260080
	v_dual_mov_b32 v39, 0 :: v_dual_mov_b32 v40, 0             // 000000A78BE8: CA100080 27280080
	v_dual_mov_b32 v41, 0 :: v_dual_mov_b32 v42, 0             // 000000A78BF0: CA100080 292A0080
	v_mov_b32_e32 v28, 0                                       // 000000A78BF8: 7E380280
	s_and_saveexec_b32 s3, vcc_lo                              // 000000A78BFC: BE83206A
	s_cbranch_execz 1871                                       // 000000A78C00: BFA5074F <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi0ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2040>
	v_dual_mov_b32 v28, 0 :: v_dual_lshlrev_b32 v1, 5, v25     // 000000A78C04: CA220080 1C003285
	v_cmp_ne_u32_e32 vcc_lo, 0, v25                            // 000000A78C0C: 7C9A3280
	v_dual_mov_b32 v39, 0 :: v_dual_lshlrev_b32 v30, 11, v18   // 000000A78C10: CA220080 271E248B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000A78C18: BF870143
	v_dual_mov_b32 v41, 0 :: v_dual_add_nc_u32 v20, 0x3f0, v1  // 000000A78C1C: CA200080 291402FF 000003F0
	s_add_u32 s0, s8, s9                                       // 000000A78C28: 80000908
	s_addc_u32 s6, s6, s7                                      // 000000A78C2C: 82060706
	v_mul_u32_u24_e32 v21, 0x840, v24                          // 000000A78C30: 162A30FF 00000840
	v_lshrrev_b32_e32 v22, 5, v20                              // 000000A78C38: 322C2885
	v_dual_mov_b32 v37, 0 :: v_dual_and_b32 v20, 0x7e0, v20    // 000000A78C3C: CA240080 251428FF 000007E0
	v_mad_u32_u24 v29, 0x840, v24, v26                         // 000000A78C48: D60B001D 046A30FF 00000840
	v_sub_nc_u32_e32 v45, 0, v19                               // 000000A78C54: 4C5A2680
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A78C58: BF870004
	v_subrev_nc_u32_e32 v22, 32, v22                           // 000000A78C5C: 4E2C2CA0
	v_and_b32_e32 v23, 16, v0                                  // 000000A78C60: 362E0090
	v_sub_nc_u32_e32 v1, v20, v1                               // 000000A78C64: 4C020314
	v_add_nc_u32_e32 v46, 1, v18                               // 000000A78C68: 4A5C2481
	v_dual_mov_b32 v40, 0 :: v_dual_add_nc_u32 v47, 0x1400, v29// 000000A78C6C: CA200080 282E3AFF 00001400
	v_cndmask_b32_e32 v22, 31, v22, vcc_lo                     // 000000A78C78: 022C2C9F
	v_lshl_or_b32 v43, v18, 5, v23                             // 000000A78C7C: D656002B 045D0B12
	.long 0xd7000017                                           // 000000A78C84: D7000017
	v_cndmask_b32_e32 v1, s0, v30, vcc_lo                      // 000000A78C88: 02023C00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A78C8C: BF870211
	v_add_co_ci_u32_e64 v30, null, s6, 0, s0                   // 000000A78C90: D5207C1E 00010006
	v_dual_mov_b32 v42, 0 :: v_dual_add_nc_u32 v31, 1, v22     // 000000A78C98: CA200080 2A1E2C81
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A78CA0: BF870093
	.long 0xd7006a17                                           // 000000A78CA4: D7006A17
	v_cndmask_b32_e32 v1, v23, v26, vcc_lo                     // 000000A78CA8: 02023517
	v_add_co_ci_u32_e64 v30, null, 0, v30, vcc_lo              // 000000A78CAC: D5207C1E 01AA3C80
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A78CB4: BF870193
	v_dual_mov_b32 v35, 0 :: v_dual_and_b32 v20, 31, v31       // 000000A78CB8: CA240080 23143E9F
	.long 0xd7006a17                                           // 000000A78CC0: D7006A17
	v_cndmask_b32_e32 v1, s4, v23, vcc_lo                      // 000000A78CC4: 02022E04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000A78CC8: BF8700D1
	v_add_co_ci_u32_e64 v30, null, s5, v30, vcc_lo             // 000000A78CCC: D5207C1E 01AA3C05
	v_dual_mov_b32 v33, 0 :: v_dual_add_nc_u32 v44, 0xfffffc30, v1// 000000A78CD4: CA200080 212C02FF FFFFFC30
	v_lshl_add_u32 v1, v22, 2, v21                             // 000000A78CE0: D6460001 04550516
	v_lshl_add_u32 v20, v20, 2, v21                            // 000000A78CE8: D6460014 04550514
	.long 0xd7006a16                                           // 000000A78CF0: D7006A16
	v_cndmask_b32_e32 v1, 0x800, v23, vcc_lo                   // 000000A78CF4: 02022EFF 00000800
	v_add_co_ci_u32_e64 v23, null, 0, v30, vcc_lo              // 000000A78CFC: D5207C17 01AA3C80
	v_dual_mov_b32 v29, 0 :: v_dual_add_nc_u32 v48, 0x1800, v29// 000000A78D04: CA200080 1D303AFF 00001800
	v_dual_mov_b32 v38, 0 :: v_dual_add_nc_u32 v49, 0x1400, v1 // 000000A78D10: CA200080 263002FF 00001400
	v_add_nc_u32_e32 v50, 0x1400, v20                          // 000000A78D1C: 4A6428FF 00001400
	v_dual_mov_b32 v36, 0 :: v_dual_add_nc_u32 v51, 0x1800, v1 // 000000A78D24: CA200080 243202FF 00001800
	v_add_nc_u32_e32 v52, 0x1800, v20                          // 000000A78D30: 4A6828FF 00001800
	v_mov_b32_e32 v34, 0                                       // 000000A78D38: 7E440280
	v_dual_mov_b32 v32, 0 :: v_dual_mov_b32 v31, 0             // 000000A78D3C: CA100080 201E0080
	v_dual_mov_b32 v30, 0 :: v_dual_mov_b32 v1, 0              // 000000A78D44: CA100080 1E000080
	s_mov_b32 s4, 0                                            // 000000A78D4C: BE840080
	s_movk_i32 s5, 0x1eee                                      // 000000A78D50: B0051EEE
	s_branch 1723                                              // 000000A78D54: BFA006BB <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi0ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1f44>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A78D58: 8C7E007E
	ds_load_2addr_b32 v[53:54], v50 offset1:32                 // 000000A78D5C: D8DC2000 35000032
	ds_load_2addr_b32 v[63:64], v47 offset1:32                 // 000000A78D64: D8DC2000 3F00002F
	ds_load_2addr_b32 v[57:58], v49 offset1:32                 // 000000A78D6C: D8DC2000 39000031
	ds_load_b128 v[18:21], v43                                 // 000000A78D74: DBFC0000 1200002B
	ds_load_2addr_b32 v[59:60], v49 offset0:64 offset1:96      // 000000A78D7C: D8DC6040 3B000031
	ds_load_2addr_b32 v[61:62], v50 offset0:64 offset1:96      // 000000A78D84: D8DC6040 3D000032
	.long 0xd7000016                                           // 000000A78D8C: D7000016
	v_cndmask_b32_e32 v1, 0x800, v22, vcc_lo                   // 000000A78D90: 02022CFF 00000800
	v_add_nc_u32_e32 v43, 32, v43                              // 000000A78D98: 4A5656A0
	v_add_co_ci_u32_e64 v23, null, 0, v23, s0                  // 000000A78D9C: D5207C17 00022E80
	s_waitcnt lgkmcnt(5)                                       // 000000A78DA4: BF89FC57
	v_mov_b32_e32 v56, v53                                     // 000000A78DA8: 7E700335
	s_waitcnt lgkmcnt(4)                                       // 000000A78DAC: BF89FC47
	v_bfe_u32 v53, v63, 12, 16                                 // 000000A78DB0: D6100035 0241193F
	v_bfe_u32 v65, v63, 8, 16                                  // 000000A78DB8: D6100041 0241113F
	v_bfe_u32 v66, v63, 4, 16                                  // 000000A78DC0: D6100042 0241093F
	v_and_b32_e32 v63, 0xffff, v63                             // 000000A78DC8: 367E7EFF 0000FFFF
	s_waitcnt lgkmcnt(3)                                       // 000000A78DD0: BF89FC37
	.long 0xd73d0038                                           // 000000A78DD4: D73D0038
	v_cndmask_b32_e32 v1, v44, v56, vcc_lo                     // 000000A78DD8: 0202712C
	v_mov_b32_e32 v55, v58                                     // 000000A78DDC: 7E6E033A
	v_bfe_u32 v58, v64, 12, 16                                 // 000000A78DE0: D610003A 02411940
	v_bfe_u32 v67, v64, 8, 16                                  // 000000A78DE8: D6100043 02411140
	v_bfe_u32 v68, v64, 4, 16                                  // 000000A78DF0: D6100044 02410940
	v_and_b32_e32 v64, 0xffff, v64                             // 000000A78DF8: 368080FF 0000FFFF
	.long 0xd72c0039                                           // 000000A78E00: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000A78E04: 02026AFF 83DCD12D
	.long 0xd73d0035                                           // 000000A78E0C: D73D0035
	v_cndmask_b32_e32 v1, v44, v54, vcc_lo                     // 000000A78E10: 02026D2C
	v_bfe_u32 v55, v56, 12, 16                                 // 000000A78E14: D6100037 02411938
	.long 0xd72c0036                                           // 000000A78E1C: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A78E20: 020274FF 83DCD12D
	v_bfe_u32 v58, v56, 8, 16                                  // 000000A78E28: D610003A 02411138
	v_bfe_u32 v69, v56, 4, 16                                  // 000000A78E30: D6100045 02410938
	v_and_b32_e32 v56, 0xffff, v56                             // 000000A78E38: 367070FF 0000FFFF
	.long 0xd72c0037                                           // 000000A78E40: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000A78E44: 02026EFF 83DCD12D
	.long 0xd72c0041                                           // 000000A78E4C: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000A78E50: 020282FF 83DCD12D
	.long 0xd72c003a                                           // 000000A78E58: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A78E5C: 020274FF 83DCD12D
	v_sad_u8 v57, v57, 0, 0x6400                               // 000000A78E64: D6220039 03FD0139 00006400
	.long 0xd72c0038                                           // 000000A78E70: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000A78E74: 020270FF 83DCD12D
	.long 0xd72c0045                                           // 000000A78E7C: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 000000A78E80: 02028AFF 83DCD12D
	v_bfe_u32 v70, v53, 12, 16                                 // 000000A78E88: D6100046 02411935
	v_bfe_u32 v71, v53, 8, 16                                  // 000000A78E90: D6100047 02411135
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000A78E98: D6220037 03FD0137 00006400
	v_bfe_u32 v72, v53, 4, 16                                  // 000000A78EA4: D6100048 02410935
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000A78EAC: D622003A 03FD013A 00006400
	v_sad_u8 v65, v65, 0, 0x6400                               // 000000A78EB8: D6220041 03FD0141 00006400
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000A78EC4: D6220038 03FD0138 00006400
	v_and_b32_e32 v55, 0xffff, v55                             // 000000A78ED0: 366E6EFF 0000FFFF
	.long 0xd72c003f                                           // 000000A78ED8: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000A78EDC: 02027EFF 83DCD12D
	.long 0xd72c0042                                           // 000000A78EE4: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 000000A78EE8: 020284FF 83DCD12D
	.long 0xd72c0046                                           // 000000A78EF0: D72C0046
	v_cndmask_b32_e32 v1, 0x83dcd12d, v70, vcc_lo              // 000000A78EF4: 02028CFF 83DCD12D
	v_lshlrev_b32_e32 v56, 16, v56                             // 000000A78EFC: 30707090
	v_lshl_or_b32 v55, v58, 16, v55                            // 000000A78F00: D6560037 04DD213A
	.long 0xd72c0047                                           // 000000A78F08: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000A78F0C: 02028EFF 83DCD12D
	.long 0xd72c0043                                           // 000000A78F14: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000A78F18: 020286FF 83DCD12D
	v_sad_u8 v54, v54, 0, 0x6400                               // 000000A78F20: D6220036 03FD0136 00006400
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000A78F2C: D622003F 03FD013F 00006400
	v_pk_fma_f16 v55, v55, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A78F38: CC0E0037 0BFC0B37 0000C931
	v_and_b32_e32 v53, 0xffff, v53                             // 000000A78F44: 366A6AFF 0000FFFF
	v_sad_u8 v66, v66, 0, 0x6400                               // 000000A78F4C: D6220042 03FD0142 00006400
	.long 0xd72c0048                                           // 000000A78F58: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000A78F5C: 020290FF 83DCD12D
	.long 0xd72c0040                                           // 000000A78F64: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000A78F68: 020280FF 83DCD12D
	s_waitcnt lgkmcnt(2)                                       // 000000A78F70: BF89FC27
	v_dual_dot2acc_f32_f16 v28, v55, v18 :: v_dual_and_b32 v57, 0xffff, v57// 000000A78F74: CB242537 1C3872FF 0000FFFF
	.long 0xd72c0035                                           // 000000A78F80: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000A78F84: 02026AFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A78F8C: BF8701A2
	v_lshl_or_b32 v57, v65, 16, v57                            // 000000A78F90: D6560039 04E52141
	v_sad_u8 v65, v69, 0, 0x6400                               // 000000A78F98: D6220041 03FD0145 00006400
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000A78FA4: D6220035 03FD0135 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A78FB0: BF870193
	v_pk_fma_f16 v69, v57, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A78FB4: CC0E0045 0BFC0B39 0000C931
	v_and_or_b32 v56, 0xffff, v65, v56                         // 000000A78FC0: D6570038 04E282FF 0000FFFF
	v_sad_u8 v65, v72, 0, 0x6400                               // 000000A78FCC: D6220041 03FD0148 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A78FD8: BF870092
	v_pk_fma_f16 v56, v56, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A78FDC: CC0E0038 0BFC0B38 0000C931
	v_dot2acc_f32_f16 v28, v56, v19                            // 000000A78FE8: 04382738
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A78FEC: BF870091
	v_dual_dot2acc_f32_f16 v28, v69, v20 :: v_dual_lshlrev_b32 v63, 16, v63// 000000A78FF0: CB222945 1C3E7E90
	v_and_or_b32 v58, 0xffff, v66, v63                         // 000000A78FF8: D657003A 04FE84FF 0000FFFF
	v_sad_u8 v63, v70, 0, 0x6400                               // 000000A79004: D622003F 03FD0146 00006400
	v_sad_u8 v66, v71, 0, 0x6400                               // 000000A79010: D6220042 03FD0147 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A7901C: BF8701A3
	v_pk_fma_f16 v70, v58, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A79020: CC0E0046 0BFC0B3A 0000C931
	s_waitcnt lgkmcnt(0)                                       // 000000A7902C: BF89FC07
	v_dual_mov_b32 v58, v61 :: v_dual_and_b32 v63, 0xffff, v63 // 000000A79030: CA24013D 3A3E7EFF 0000FFFF
	v_sad_u8 v61, v67, 0, 0x6400                               // 000000A7903C: D622003D 03FD0143 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A79048: BF870193
	v_dot2acc_f32_f16 v28, v70, v21                            // 000000A7904C: 04382B46
	v_lshl_or_b32 v63, v66, 16, v63                            // 000000A79050: D656003F 04FD2142
	v_and_b32_e32 v66, 0xffff, v54                             // 000000A79058: 36846CFF 0000FFFF
	.long 0xd73d0038                                           // 000000A79060: D73D0038
	v_cndmask_b32_e32 v1, v44, v58, vcc_lo                     // 000000A79064: 0202752C
	v_sad_u8 v59, v64, 0, 0x6400                               // 000000A79068: D622003B 03FD0140 00006400
	ds_load_2addr_b32 v[54:55], v47 offset0:64 offset1:96      // 000000A79074: D8DC6040 3600002F
	v_pk_fma_f16 v58, v63, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A7907C: CC0E003A 0BFC0B3F 0000C931
	v_lshl_or_b32 v57, v61, 16, v66                            // 000000A79088: D6560039 0509213D
	v_bfe_u32 v61, v56, 12, 16                                 // 000000A79090: D610003D 02411938
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A79098: BF870193
	v_dual_dot2acc_f32_f16 v42, v58, v18 :: v_dual_lshlrev_b32 v59, 16, v59// 000000A7909C: CB22253A 2A3A7690
	v_pk_fma_f16 v64, v57, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A790A4: CC0E0040 0BFC0B39 0000C931
	v_lshlrev_b32_e32 v53, 16, v53                             // 000000A790B0: 306A6A90
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A790B4: BF870114
	.long 0xd72c003d                                           // 000000A790B8: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000A790BC: 02027AFF 83DCD12D
	v_and_or_b32 v53, 0xffff, v65, v53                         // 000000A790C4: D6570035 04D682FF 0000FFFF
	.long 0xd72c0041                                           // 000000A790D0: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 000000A790D4: 020288FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A790DC: BF870193
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000A790E0: D622003D 03FD013D 00006400
	v_pk_fma_f16 v53, v53, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A790EC: CC0E0035 0BFC0B35 0000C931
	v_and_b32_e32 v63, 0xffff, v56                             // 000000A790F8: 367E70FF 0000FFFF
	s_waitcnt lgkmcnt(0)                                       // 000000A79100: BF89FC07
	v_bfe_u32 v66, v54, 12, 16                                 // 000000A79104: D6100042 02411936
	v_bfe_u32 v67, v54, 8, 16                                  // 000000A7910C: D6100043 02411136
	v_sad_u8 v57, v65, 0, 0x6400                               // 000000A79114: D6220039 03FD0141 00006400
	v_bfe_u32 v65, v56, 8, 16                                  // 000000A79120: D6100041 02411138
	v_and_b32_e32 v61, 0xffff, v61                             // 000000A79128: 367A7AFF 0000FFFF
	v_bfe_u32 v56, v56, 4, 16                                  // 000000A79130: D6100038 02410938
	v_dot2acc_f32_f16 v42, v53, v19                            // 000000A79138: 04542735
	.long 0xd72c003f                                           // 000000A7913C: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000A79140: 02027EFF 83DCD12D
	.long 0xd72c0041                                           // 000000A79148: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000A7914C: 020282FF 83DCD12D
	v_and_or_b32 v57, 0xffff, v57, v59                         // 000000A79154: D6570039 04EE72FF 0000FFFF
	.long 0xd72c0038                                           // 000000A79160: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000A79164: 020270FF 83DCD12D
	.long 0xd72c0042                                           // 000000A7916C: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 000000A79170: 020284FF 83DCD12D
	.long 0xd72c0043                                           // 000000A79178: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000A7917C: 020286FF 83DCD12D
	v_dot2acc_f32_f16 v42, v64, v20                            // 000000A79184: 04542940
	v_bfe_u32 v68, v54, 4, 16                                  // 000000A79188: D6100044 02410936
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000A79190: D622003F 03FD013F 00006400
	v_sad_u8 v65, v65, 0, 0x6400                               // 000000A7919C: D6220041 03FD0141 00006400
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000A791A8: D6220038 03FD0138 00006400
	v_sad_u8 v66, v66, 0, 0x6400                               // 000000A791B4: D6220042 03FD0142 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A791C0: BF8701B3
	v_lshl_or_b32 v59, v65, 16, v61                            // 000000A791C4: D656003B 04F52141
	v_sad_u8 v65, v67, 0, 0x6400                               // 000000A791CC: D6220041 03FD0143 00006400
	.long 0xd72c003d                                           // 000000A791D8: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 000000A791DC: 020288FF 83DCD12D
	v_pk_fma_f16 v58, v59, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A791E4: CC0E003A 0BFC0B3B 0000C931
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000A791F0: BF8701C1
	v_dot2acc_f32_f16 v41, v58, v18                            // 000000A791F4: 0452253A
	v_pk_fma_f16 v58, v57, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A791F8: CC0E003A 0BFC0B39 0000C931
	v_lshlrev_b32_e32 v63, 16, v63                             // 000000A79204: 307E7E90
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000A79208: D622003D 03FD013D 00006400
	v_dot2acc_f32_f16 v42, v58, v21                            // 000000A79214: 04542B3A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000A79218: BF870123
	v_and_or_b32 v56, 0xffff, v56, v63                         // 000000A7921C: D6570038 04FE70FF 0000FFFF
	v_and_b32_e32 v63, 0xffff, v66                             // 000000A79228: 367E84FF 0000FFFF
	v_pk_fma_f16 v56, v56, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A79230: CC0E0038 0BFC0B38 0000C931
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A7923C: BF8701A2
	v_lshl_or_b32 v59, v65, 16, v63                            // 000000A79240: D656003B 04FD2141
	v_mov_b32_e32 v63, v60                                     // 000000A79248: 7E7E033C
	v_dot2acc_f32_f16 v41, v56, v19                            // 000000A7924C: 04522738
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A79250: BF870223
	v_pk_fma_f16 v53, v59, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A79254: CC0E0035 0BFC0B3B 0000C931
	v_and_b32_e32 v54, 0xffff, v54                             // 000000A79260: 366C6CFF 0000FFFF
	.long 0xd73d0038                                           // 000000A79268: D73D0038
	v_cndmask_b32_e32 v1, v44, v62, vcc_lo                     // 000000A7926C: 02027D2C
	v_bfe_u32 v62, v55, 8, 16                                  // 000000A79270: D610003E 02411137
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A79278: BF870214
	v_dot2acc_f32_f16 v41, v53, v20                            // 000000A7927C: 04522935
	.long 0xd72c0036                                           // 000000A79280: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 000000A79284: 02026CFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000A7928C: BF870244
	v_bfe_u32 v53, v56, 12, 16                                 // 000000A79290: D6100035 02411938
	v_bfe_u32 v57, v56, 8, 16                                  // 000000A79298: D6100039 02411138
	v_bfe_u32 v58, v56, 4, 16                                  // 000000A792A0: D610003A 02410938
	v_and_b32_e32 v60, 0xffff, v56                             // 000000A792A8: 367870FF 0000FFFF
	.long 0xd72c003b                                           // 000000A792B0: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000A792B4: 02026AFF 83DCD12D
	v_sad_u8 v54, v54, 0, 0x6400                               // 000000A792BC: D6220036 03FD0136 00006400
	.long 0xd72c003f                                           // 000000A792C8: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 000000A792CC: 020272FF 83DCD12D
	ds_load_2addr_b32 v[56:57], v49 offset0:128 offset1:160    // 000000A792D4: D8DCA080 38000031
	v_and_b32_e32 v64, 0xffff, v55                             // 000000A792DC: 36806EFF 0000FFFF
	.long 0xd72c003a                                           // 000000A792E4: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A792E8: 020274FF 83DCD12D
	v_lshlrev_b32_e32 v54, 16, v54                             // 000000A792F0: 306C6C90
	.long 0xd72c003c                                           // 000000A792F4: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000A792F8: 020278FF 83DCD12D
	v_sad_u8 v59, v59, 0, 0x6400                               // 000000A79300: D622003B 03FD013B 00006400
	.long 0xd72c0040                                           // 000000A7930C: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000A79310: 020280FF 83DCD12D
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000A79318: D622003F 03FD013F 00006400
	v_and_or_b32 v54, 0xffff, v61, v54                         // 000000A79324: D6570036 04DA7AFF 0000FFFF
	v_bfe_u32 v61, v55, 12, 16                                 // 000000A79330: D610003D 02411937
	v_bfe_u32 v55, v55, 4, 16                                  // 000000A79338: D6100037 02410937
	v_sad_u8 v66, v58, 0, 0x6400                               // 000000A79340: D6220042 03FD013A 00006400
	v_and_b32_e32 v65, 0xffff, v59                             // 000000A7934C: 368276FF 0000FFFF
	v_pk_fma_f16 v54, v54, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A79354: CC0E0036 0BFC0B36 0000C931
	.long 0xd72c003d                                           // 000000A79360: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000A79364: 02027AFF 83DCD12D
	v_sad_u8 v58, v60, 0, 0x6400                               // 000000A7936C: D622003A 03FD013C 00006400
	v_sad_u8 v64, v64, 0, 0x6400                               // 000000A79378: D6220040 03FD0140 00006400
	v_lshl_or_b32 v63, v63, 16, v65                            // 000000A79384: D656003F 0505213F
	v_dot2acc_f32_f16 v41, v54, v21                            // 000000A7938C: 04522B36
	ds_load_2addr_b32 v[53:54], v50 offset0:128 offset1:160    // 000000A79390: D8DCA080 35000032
	v_sad_u8 v60, v61, 0, 0x6400                               // 000000A79398: D622003C 03FD013D 00006400
	.long 0xd72c003d                                           // 000000A793A4: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000A793A8: 02027CFF 83DCD12D
	.long 0xd72c003e                                           // 000000A793B0: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000A793B4: 02026EFF 83DCD12D
	s_waitcnt lgkmcnt(0)                                       // 000000A793BC: BF89FC07
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A793C0: BF870003
	v_dual_mov_b32 v55, v53 :: v_dual_and_b32 v60, 0xffff, v60 // 000000A793C4: CA240135 373C78FF 0000FFFF
	v_lshlrev_b32_e32 v53, 16, v58                             // 000000A793D0: 306A7490
	ds_load_2addr_b32 v[58:59], v47 offset0:128 offset1:160    // 000000A793D4: D8DCA080 3A00002F
	.long 0xd73d0037                                           // 000000A793DC: D73D0037
	v_cndmask_b32_e32 v1, v44, v55, vcc_lo                     // 000000A793E0: 02026F2C
	v_sad_u8 v56, v61, 0, 0x6400                               // 000000A793E4: D6220038 03FD013D 00006400
	v_sad_u8 v61, v62, 0, 0x6400                               // 000000A793F0: D622003D 03FD013E 00006400
	v_lshlrev_b32_e32 v62, 16, v64                             // 000000A793FC: 307C8090
	v_and_or_b32 v53, 0xffff, v66, v53                         // 000000A79400: D6570035 04D684FF 0000FFFF
	v_bfe_u32 v64, v55, 12, 16                                 // 000000A7940C: D6100040 02411937
	v_lshl_or_b32 v56, v56, 16, v60                            // 000000A79414: D6560038 04F12138
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A7941C: BF870004
	v_and_or_b32 v60, 0xffff, v61, v62                         // 000000A79420: D657003C 04FA7AFF 0000FFFF
	v_pk_fma_f16 v61, v63, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A7942C: CC0E003D 0BFC0B3F 0000C931
	v_pk_fma_f16 v53, v53, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A79438: CC0E0035 0BFC0B35 0000C931
	.long 0xd72c003e                                           // 000000A79444: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000A79448: 020280FF 83DCD12D
	v_and_b32_e32 v63, 0xffff, v55                             // 000000A79450: 367E6EFF 0000FFFF
	v_pk_fma_f16 v56, v56, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A79458: CC0E0038 0BFC0B38 0000C931
	v_dot2acc_f32_f16 v40, v61, v18                            // 000000A79464: 0450253D
	v_bfe_u32 v61, v55, 8, 16                                  // 000000A79468: D610003D 02411137
	v_bfe_u32 v55, v55, 4, 16                                  // 000000A79470: D6100037 02410937
	s_waitcnt lgkmcnt(0)                                       // 000000A79478: BF89FC07
	v_bfe_u32 v64, v58, 12, 16                                 // 000000A7947C: D6100040 0241193A
	.long 0xd72c003f                                           // 000000A79484: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000A79488: 02027EFF 83DCD12D
	v_sad_u8 v62, v62, 0, 0x6400                               // 000000A79490: D622003E 03FD013E 00006400
	.long 0xd72c003d                                           // 000000A7949C: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000A794A0: 02027AFF 83DCD12D
	v_dot2acc_f32_f16 v40, v53, v19                            // 000000A794A8: 04502735
	v_bfe_u32 v53, v58, 8, 16                                  // 000000A794AC: D6100035 0241113A
	.long 0xd72c0037                                           // 000000A794B4: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000A794B8: 02026EFF 83DCD12D
	v_and_b32_e32 v62, 0xffff, v62                             // 000000A794C0: 367C7CFF 0000FFFF
	.long 0xd72c0040                                           // 000000A794C8: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000A794CC: 020280FF 83DCD12D
	v_bfe_u32 v65, v58, 4, 16                                  // 000000A794D4: D6100041 0241093A
	.long 0xd72c0035                                           // 000000A794DC: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000A794E0: 02026AFF 83DCD12D
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000A794E8: D622003D 03FD013D 00006400
	v_and_b32_e32 v58, 0xffff, v58                             // 000000A794F4: 367474FF 0000FFFF
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000A794FC: D622003F 03FD013F 00006400
	v_dot2acc_f32_f16 v40, v56, v20                            // 000000A79508: 04502938
	v_pk_fma_f16 v60, v60, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A7950C: CC0E003C 0BFC0B3C 0000C931
	v_lshl_or_b32 v61, v61, 16, v62                            // 000000A79518: D656003D 04F9213D
	v_sad_u8 v62, v55, 0, 0x6400                               // 000000A79520: D622003E 03FD0137 00006400
	v_mov_b32_e32 v55, v57                                     // 000000A7952C: 7E6E0339
	.long 0xd72c0039                                           // 000000A79530: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A79534: 020274FF 83DCD12D
	v_sad_u8 v64, v64, 0, 0x6400                               // 000000A7953C: D6220040 03FD0140 00006400
	v_sad_u8 v58, v53, 0, 0x6400                               // 000000A79548: D622003A 03FD0135 00006400
	v_lshlrev_b32_e32 v63, 16, v63                             // 000000A79554: 307E7E90
	.long 0xd73d0035                                           // 000000A79558: D73D0035
	v_cndmask_b32_e32 v1, v44, v54, vcc_lo                     // 000000A7955C: 02026D2C
	v_pk_fma_f16 v55, v61, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A79560: CC0E0037 0BFC0B3D 0000C931
	v_and_b32_e32 v64, 0xffff, v64                             // 000000A7956C: 368080FF 0000FFFF
	v_bfe_u32 v67, v59, 4, 16                                  // 000000A79574: D6100043 0241093B
	v_sad_u8 v56, v57, 0, 0x6400                               // 000000A7957C: D6220038 03FD0139 00006400
	v_and_or_b32 v62, 0xffff, v62, v63                         // 000000A79588: D657003E 04FE7CFF 0000FFFF
	v_bfe_u32 v57, v53, 12, 16                                 // 000000A79594: D6100039 02411935
	v_lshl_or_b32 v54, v58, 16, v64                            // 000000A7959C: D6560036 0501213A
	v_bfe_u32 v58, v59, 12, 16                                 // 000000A795A4: D610003A 0241193B
	v_lshlrev_b32_e32 v64, 16, v56                             // 000000A795AC: 30807090
	v_pk_fma_f16 v61, v62, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A795B0: CC0E003D 0BFC0B3E 0000C931
	.long 0xd72c0038                                           // 000000A795BC: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 000000A795C0: 020272FF 83DCD12D
	v_bfe_u32 v57, v53, 8, 16                                  // 000000A795C8: D6100039 02411135
	v_pk_fma_f16 v62, v54, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A795D0: CC0E003E 0BFC0B36 0000C931
	v_and_b32_e32 v54, 0xffff, v53                             // 000000A795DC: 366C6AFF 0000FFFF
	v_bfe_u32 v53, v53, 4, 16                                  // 000000A795E4: D6100035 02410935
	.long 0xd72c003f                                           // 000000A795EC: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000A795F0: 020282FF 83DCD12D
	.long 0xd72c0039                                           // 000000A795F8: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 000000A795FC: 020272FF 83DCD12D
	v_bfe_u32 v65, v59, 8, 16                                  // 000000A79604: D6100041 0241113B
	.long 0xd72c0042                                           // 000000A7960C: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 000000A79610: 02026CFF 83DCD12D
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000A79618: D6220038 03FD0138 00006400
	.long 0xd72c0044                                           // 000000A79624: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000A79628: 02026AFF 83DCD12D
	ds_load_2addr_b32 v[53:54], v50 offset0:192 offset1:224    // 000000A79630: D8DCE0C0 35000032
	v_dual_dot2acc_f32_f16 v40, v60, v21 :: v_dual_and_b32 v59, 0xffff, v59// 000000A79638: CB242B3C 283A76FF 0000FFFF
	.long 0xd72c003a                                           // 000000A79644: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A79648: 020274FF 83DCD12D
	v_and_b32_e32 v69, 0xffff, v56                             // 000000A79650: 368A70FF 0000FFFF
	v_sad_u8 v70, v57, 0, 0x6400                               // 000000A79658: D6220046 03FD0139 00006400
	ds_load_2addr_b32 v[56:57], v49 offset0:192 offset1:224    // 000000A79664: D8DCE0C0 38000031
	.long 0xd72c0041                                           // 000000A7966C: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000A79670: 020282FF 83DCD12D
	.long 0xd72c003b                                           // 000000A79678: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000A7967C: 020276FF 83DCD12D
	v_sad_u8 v66, v66, 0, 0x6400                               // 000000A79684: D6220042 03FD0142 00006400
	.long 0xd72c0043                                           // 000000A79690: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000A79694: 020286FF 83DCD12D
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000A7969C: D622003A 03FD013A 00006400
	v_sad_u8 v68, v68, 0, 0x6400                               // 000000A796A8: D6220044 03FD0144 00006400
	v_dot2acc_f32_f16 v39, v55, v18                            // 000000A796B4: 044E2537
	v_lshlrev_b32_e32 v66, 16, v66                             // 000000A796B8: 30848490
	v_lshl_or_b32 v55, v70, 16, v69                            // 000000A796BC: D6560037 05152146
	v_and_b32_e32 v58, 0xffff, v58                             // 000000A796C4: 367474FF 0000FFFF
	v_sad_u8 v65, v65, 0, 0x6400                               // 000000A796CC: D6220041 03FD0141 00006400
	v_sad_u8 v59, v59, 0, 0x6400                               // 000000A796D8: D622003B 03FD013B 00006400
	v_and_or_b32 v66, 0xffff, v68, v66                         // 000000A796E4: D6570042 050A88FF 0000FFFF
	v_pk_fma_f16 v68, v55, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A796F0: CC0E0044 0BFC0B37 0000C931
	s_waitcnt lgkmcnt(1)                                       // 000000A796FC: BF89FC17
	v_mov_b32_e32 v55, v53                                     // 000000A79700: 7E6E0335
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000A79704: D622003F 03FD013F 00006400
	v_lshl_or_b32 v53, v65, 16, v58                            // 000000A79710: D6560035 04E92141
	v_sad_u8 v65, v67, 0, 0x6400                               // 000000A79718: D6220041 03FD0143 00006400
	v_lshlrev_b32_e32 v67, 16, v59                             // 000000A79724: 30867690
	ds_load_2addr_b32 v[58:59], v47 offset0:192 offset1:224    // 000000A79728: D8DCE0C0 3A00002F
	s_waitcnt lgkmcnt(1)                                       // 000000A79730: BF89FC17
	.long 0xd73d0037                                           // 000000A79734: D73D0037
	v_cndmask_b32_e32 v1, v44, v55, vcc_lo                     // 000000A79738: 02026F2C
	v_pk_fma_f16 v66, v66, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A7973C: CC0E0042 0BFC0B42 0000C931
	v_dot2acc_f32_f16 v38, v68, v18                            // 000000A79748: 044C2544
	v_and_or_b32 v56, 0xffff, v63, v64                         // 000000A7974C: D6570038 05027EFF 0000FFFF
	v_dot2acc_f32_f16 v39, v61, v19                            // 000000A79758: 044E273D
	v_pk_fma_f16 v53, v53, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A7975C: CC0E0035 0BFC0B35 0000C931
	v_bfe_u32 v63, v55, 12, 16                                 // 000000A79768: D610003F 02411937
	v_dot2acc_f32_f16 v38, v66, v19                            // 000000A79770: 044C2742
	v_pk_fma_f16 v56, v56, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A79774: CC0E0038 0BFC0B38 0000C931
	v_dot2acc_f32_f16 v39, v62, v20                            // 000000A79780: 044E293E
	v_and_or_b32 v61, 0xffff, v65, v67                         // 000000A79784: D657003D 050E82FF 0000FFFF
	v_bfe_u32 v62, v55, 8, 16                                  // 000000A79790: D610003E 02411137
	v_dot2acc_f32_f16 v38, v53, v20                            // 000000A79798: 044C2935
	.long 0xd72c0035                                           // 000000A7979C: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000A797A0: 02027EFF 83DCD12D
	v_dot2acc_f32_f16 v39, v56, v21                            // 000000A797A8: 044E2B38
	v_bfe_u32 v56, v55, 4, 16                                  // 000000A797AC: D6100038 02410937
	v_and_b32_e32 v55, 0xffff, v55                             // 000000A797B4: 366E6EFF 0000FFFF
	v_pk_fma_f16 v61, v61, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A797BC: CC0E003D 0BFC0B3D 0000C931
	.long 0xd72c003c                                           // 000000A797C8: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000A797CC: 02027CFF 83DCD12D
	s_waitcnt lgkmcnt(0)                                       // 000000A797D4: BF89FC07
	v_and_b32_e32 v63, 0xffff, v58                             // 000000A797D8: 367E74FF 0000FFFF
	v_bfe_u32 v62, v58, 8, 16                                  // 000000A797E0: D610003E 0241113A
	.long 0xd72c0037                                           // 000000A797E8: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000A797EC: 02026EFF 83DCD12D
	v_dot2acc_f32_f16 v38, v61, v21                            // 000000A797F4: 044C2B3D
	v_bfe_u32 v61, v58, 12, 16                                 // 000000A797F8: D610003D 0241193A
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000A79800: D6220035 03FD0135 00006400
	v_bfe_u32 v58, v58, 4, 16                                  // 000000A7980C: D610003A 0241093A
	.long 0xd72c0038                                           // 000000A79814: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000A79818: 020270FF 83DCD12D
	.long 0xd72c003f                                           // 000000A79820: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000A79824: 02027EFF 83DCD12D
	.long 0xd72c003d                                           // 000000A7982C: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000A79830: 02027AFF 83DCD12D
	v_and_b32_e32 v53, 0xffff, v53                             // 000000A79838: 366A6AFF 0000FFFF
	v_sad_u8 v60, v60, 0, 0x6400                               // 000000A79840: D622003C 03FD013C 00006400
	v_sad_u8 v64, v55, 0, 0x6400                               // 000000A7984C: D6220040 03FD0137 00006400
	v_mov_b32_e32 v55, v57                                     // 000000A79858: 7E6E0339
	.long 0xd72c003e                                           // 000000A7985C: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000A79860: 02027CFF 83DCD12D
	.long 0xd72c0039                                           // 000000A79868: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A7986C: 020274FF 83DCD12D
	v_lshl_or_b32 v60, v60, 16, v53                            // 000000A79874: D656003C 04D5213C
	v_sad_u8 v58, v61, 0, 0x6400                               // 000000A7987C: D622003A 03FD013D 00006400
	.long 0xd73d0035                                           // 000000A79888: D73D0035
	v_cndmask_b32_e32 v1, v44, v54, vcc_lo                     // 000000A7988C: 02026D2C
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000A79890: D6220038 03FD0138 00006400
	v_sad_u8 v61, v63, 0, 0x6400                               // 000000A7989C: D622003D 03FD013F 00006400
	v_lshlrev_b32_e32 v54, 16, v64                             // 000000A798A8: 306C8090
	v_and_b32_e32 v55, 0xffff, v58                             // 000000A798AC: 366E74FF 0000FFFF
	v_sad_u8 v58, v62, 0, 0x6400                               // 000000A798B4: D622003A 03FD013E 00006400
	v_sad_u8 v57, v57, 0, 0x6400                               // 000000A798C0: D6220039 03FD0139 00006400
	v_lshlrev_b32_e32 v61, 16, v61                             // 000000A798CC: 307A7A90
	v_pk_fma_f16 v60, v60, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A798D0: CC0E003C 0BFC0B3C 0000C931
	v_and_or_b32 v54, 0xffff, v56, v54                         // 000000A798DC: D6570036 04DA70FF 0000FFFF
	v_bfe_u32 v62, v53, 12, 16                                 // 000000A798E8: D610003E 02411935
	v_lshl_or_b32 v55, v58, 16, v55                            // 000000A798F0: D6560037 04DD213A
	v_and_or_b32 v56, 0xffff, v57, v61                         // 000000A798F8: D6570038 04F672FF 0000FFFF
	v_dot2acc_f32_f16 v37, v60, v18                            // 000000A79904: 044A253C
	v_pk_fma_f16 v61, v54, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A79908: CC0E003D 0BFC0B36 0000C931
	.long 0xd72c0039                                           // 000000A79914: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000A79918: 02027CFF 83DCD12D
	v_pk_fma_f16 v62, v55, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A79920: CC0E003E 0BFC0B37 0000C931
	v_bfe_u32 v58, v53, 8, 16                                  // 000000A7992C: D610003A 02411135
	v_pk_fma_f16 v63, v56, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A79934: CC0E003F 0BFC0B38 0000C931
	v_dual_dot2acc_f32_f16 v37, v61, v19 :: v_dual_and_b32 v54, 0xffff, v53// 000000A79940: CB24273D 25366AFF 0000FFFF
	v_bfe_u32 v65, v59, 8, 16                                  // 000000A7994C: D6100041 0241113B
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A79954: BF870004
	.long 0xd72c0037                                           // 000000A79958: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A7995C: 020274FF 83DCD12D
	v_sad_u8 v56, v57, 0, 0x6400                               // 000000A79964: D6220038 03FD0139 00006400
	v_bfe_u32 v57, v53, 4, 16                                  // 000000A79970: D6100039 02410935
	v_dot2acc_f32_f16 v37, v62, v20                            // 000000A79978: 044A293E
	.long 0xd72c003c                                           // 000000A7997C: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 000000A79980: 02026CFF 83DCD12D
	ds_load_2addr_b32 v[53:54], v52 offset1:32                 // 000000A79988: D8DC2000 35000034
	v_and_b32_e32 v64, 0xffff, v56                             // 000000A79990: 368070FF 0000FFFF
	.long 0xd72c0042                                           // 000000A79998: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 000000A7999C: 020272FF 83DCD12D
	ds_load_2addr_b32 v[56:57], v51 offset1:32                 // 000000A799A4: D8DC2000 38000033
	v_bfe_u32 v58, v59, 12, 16                                 // 000000A799AC: D610003A 0241193B
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000A799B4: D6220037 03FD0137 00006400
	v_and_b32_e32 v67, 0xffff, v59                             // 000000A799C0: 368676FF 0000FFFF
	v_sad_u8 v60, v60, 0, 0x6400                               // 000000A799C8: D622003C 03FD013C 00006400
	v_bfe_u32 v59, v59, 4, 16                                  // 000000A799D4: D610003B 0241093B
	.long 0xd72c003a                                           // 000000A799DC: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A799E0: 020274FF 83DCD12D
	v_lshl_or_b32 v55, v55, 16, v64                            // 000000A799E8: D6560037 05012137
	.long 0xd72c0041                                           // 000000A799F0: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000A799F4: 020282FF 83DCD12D
	.long 0xd72c0040                                           // 000000A799FC: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000A79A00: 020286FF 83DCD12D
	v_sad_u8 v66, v66, 0, 0x6400                               // 000000A79A08: D6220042 03FD0142 00006400
	v_lshlrev_b32_e32 v60, 16, v60                             // 000000A79A14: 30787890
	v_pk_fma_f16 v67, v55, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A79A18: CC0E0043 0BFC0B37 0000C931
	.long 0xd72c0044                                           // 000000A79A24: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000A79A28: 020276FF 83DCD12D
	v_sad_u8 v69, v58, 0, 0x6400                               // 000000A79A30: D6220045 03FD013A 00006400
	ds_load_2addr_b32 v[58:59], v48 offset1:32                 // 000000A79A3C: D8DC2000 3A000030
	v_and_or_b32 v60, 0xffff, v66, v60                         // 000000A79A44: D657003C 04F284FF 0000FFFF
	s_waitcnt lgkmcnt(2)                                       // 000000A79A50: BF89FC27
	v_mov_b32_e32 v55, v53                                     // 000000A79A54: 7E6E0335
	v_sad_u8 v65, v65, 0, 0x6400                               // 000000A79A58: D6220041 03FD0141 00006400
	v_and_b32_e32 v53, 0xffff, v69                             // 000000A79A64: 366A8AFF 0000FFFF
	v_sad_u8 v64, v64, 0, 0x6400                               // 000000A79A6C: D6220040 03FD0140 00006400
	v_dot2acc_f32_f16 v36, v67, v18                            // 000000A79A78: 04482543
	s_waitcnt lgkmcnt(1)                                       // 000000A79A7C: BF89FC17
	.long 0xd73d0037                                           // 000000A79A80: D73D0037
	v_cndmask_b32_e32 v1, v44, v55, vcc_lo                     // 000000A79A84: 02026F2C
	v_pk_fma_f16 v56, v60, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A79A88: CC0E0038 0BFC0B3C 0000C931
	v_lshl_or_b32 v53, v65, 16, v53                            // 000000A79A94: D6560035 04D52141
	v_sad_u8 v66, v68, 0, 0x6400                               // 000000A79A9C: D6220042 03FD0144 00006400
	v_dual_dot2acc_f32_f16 v37, v63, v21 :: v_dual_lshlrev_b32 v64, 16, v64// 000000A79AA8: CB222B3F 25408090
	v_bfe_u32 v61, v55, 12, 16                                 // 000000A79AB0: D610003D 02411937
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A79AB8: BF870004
	v_pk_fma_f16 v62, v53, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A79ABC: CC0E003E 0BFC0B35 0000C931
	v_dot2acc_f32_f16 v36, v56, v19                            // 000000A79AC8: 04482738
	v_bfe_u32 v56, v55, 8, 16                                  // 000000A79ACC: D6100038 02411137
	v_and_or_b32 v60, 0xffff, v66, v64                         // 000000A79AD4: D657003C 050284FF 0000FFFF
	.long 0xd72c0035                                           // 000000A79AE0: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000A79AE4: 02027AFF 83DCD12D
	v_and_b32_e32 v61, 0xffff, v55                             // 000000A79AEC: 367A6EFF 0000FFFF
	v_bfe_u32 v55, v55, 4, 16                                  // 000000A79AF4: D6100037 02410937
	s_waitcnt lgkmcnt(0)                                       // 000000A79AFC: BF89FC07
	v_bfe_u32 v64, v58, 12, 16                                 // 000000A79B00: D6100040 0241193A
	.long 0xd72c0038                                           // 000000A79B08: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000A79B0C: 020270FF 83DCD12D
	v_bfe_u32 v65, v58, 8, 16                                  // 000000A79B14: D6100041 0241113A
	.long 0xd72c003d                                           // 000000A79B1C: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000A79B20: 02027AFF 83DCD12D
	.long 0xd72c0037                                           // 000000A79B28: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000A79B2C: 02026EFF 83DCD12D
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000A79B34: D6220035 03FD0135 00006400
	.long 0xd72c0040                                           // 000000A79B40: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000A79B44: 020280FF 83DCD12D
	.long 0xd72c0041                                           // 000000A79B4C: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000A79B50: 020282FF 83DCD12D
	v_bfe_u32 v66, v58, 4, 16                                  // 000000A79B58: D6100042 0241093A
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000A79B60: D6220038 03FD0138 00006400
	v_and_b32_e32 v53, 0xffff, v53                             // 000000A79B6C: 366A6AFF 0000FFFF
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000A79B74: D622003D 03FD013D 00006400
	v_sad_u8 v67, v55, 0, 0x6400                               // 000000A79B80: D6220043 03FD0137 00006400
	v_mov_b32_e32 v55, v57                                     // 000000A79B8C: 7E6E0339
	v_sad_u8 v64, v64, 0, 0x6400                               // 000000A79B90: D6220040 03FD0140 00006400
	v_lshl_or_b32 v56, v56, 16, v53                            // 000000A79B9C: D6560038 04D52138
	v_lshlrev_b32_e32 v61, 16, v61                             // 000000A79BA4: 307A7A90
	.long 0xd72c0042                                           // 000000A79BA8: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 000000A79BAC: 020284FF 83DCD12D
	.long 0xd73d0035                                           // 000000A79BB4: D73D0035
	v_cndmask_b32_e32 v1, v44, v54, vcc_lo                     // 000000A79BB8: 02026D2C
	v_and_b32_e32 v57, 0xffff, v64                             // 000000A79BBC: 367280FF 0000FFFF
	v_sad_u8 v64, v65, 0, 0x6400                               // 000000A79BC4: D6220040 03FD0141 00006400
	v_and_or_b32 v54, 0xffff, v67, v61                         // 000000A79BD0: D6570036 04F686FF 0000FFFF
	v_pk_fma_f16 v61, v56, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A79BDC: CC0E003D 0BFC0B38 0000C931
	v_bfe_u32 v67, v59, 4, 16                                  // 000000A79BE8: D6100043 0241093B
	v_bfe_u32 v56, v53, 12, 16                                 // 000000A79BF0: D6100038 02411935
	v_lshl_or_b32 v55, v64, 16, v57                            // 000000A79BF8: D6560037 04E52140
	v_pk_fma_f16 v64, v54, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A79C00: CC0E0040 0BFC0B36 0000C931
	v_dot2acc_f32_f16 v35, v61, v18                            // 000000A79C0C: 0446253D
	v_and_b32_e32 v58, 0xffff, v58                             // 000000A79C10: 367474FF 0000FFFF
	v_sad_u8 v57, v66, 0, 0x6400                               // 000000A79C18: D6220039 03FD0142 00006400
	v_pk_fma_f16 v65, v55, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A79C24: CC0E0041 0BFC0B37 0000C931
	.long 0xd72c0037                                           // 000000A79C30: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000A79C34: 020270FF 83DCD12D
	v_dot2acc_f32_f16 v35, v64, v19                            // 000000A79C3C: 04462740
	.long 0xd72c003a                                           // 000000A79C40: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A79C44: 020274FF 83DCD12D
	v_bfe_u32 v56, v53, 8, 16                                  // 000000A79C4C: D6100038 02411135
	.long 0xd72c0043                                           // 000000A79C54: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000A79C58: 020286FF 83DCD12D
	v_pk_fma_f16 v60, v60, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A79C60: CC0E003C 0BFC0B3C 0000C931
	v_dot2acc_f32_f16 v35, v65, v20                            // 000000A79C6C: 04462941
	v_dot2acc_f32_f16 v36, v62, v20                            // 000000A79C70: 0448293E
	.long 0xd72c0038                                           // 000000A79C74: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000A79C78: 020270FF 83DCD12D
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000A79C80: D6220037 03FD0137 00006400
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000A79C8C: D622003A 03FD013A 00006400
	v_sad_u8 v67, v67, 0, 0x6400                               // 000000A79C98: D6220043 03FD0143 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A79CA4: BF870193
	v_dual_dot2acc_f32_f16 v36, v60, v21 :: v_dual_and_b32 v55, 0xffff, v55// 000000A79CA8: CB242B3C 24366EFF 0000FFFF
	v_lshlrev_b32_e32 v58, 16, v58                             // 000000A79CB4: 30747490
	v_sad_u8 v69, v56, 0, 0x6400                               // 000000A79CB8: D6220045 03FD0138 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A79CC4: BF8701A2
	v_and_or_b32 v66, 0xffff, v57, v58                         // 000000A79CC8: D6570042 04EA72FF 0000FFFF
	v_bfe_u32 v57, v59, 12, 16                                 // 000000A79CD4: D6100039 0241193B
	v_lshl_or_b32 v55, v69, 16, v55                            // 000000A79CDC: D6560037 04DD2145
	v_bfe_u32 v58, v59, 8, 16                                  // 000000A79CE4: D610003A 0241113B
	v_and_b32_e32 v59, 0xffff, v59                             // 000000A79CEC: 367676FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A79CF4: BF870214
	.long 0xd72c0039                                           // 000000A79CF8: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 000000A79CFC: 020272FF 83DCD12D
	v_pk_fma_f16 v55, v55, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A79D04: CC0E0037 0BFC0B37 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A79D10: BF870214
	.long 0xd72c003a                                           // 000000A79D14: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A79D18: 020274FF 83DCD12D
	.long 0xd72c003b                                           // 000000A79D20: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000A79D24: 020276FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A79D2C: BF870003
	v_dot2acc_f32_f16 v34, v55, v18                            // 000000A79D30: 04442537
	v_sad_u8 v71, v57, 0, 0x6400                               // 000000A79D34: D6220047 03FD0139 00006400
	ds_load_2addr_b32 v[56:57], v51 offset0:64 offset1:96      // 000000A79D40: D8DC6040 38000033
	v_and_b32_e32 v54, 0xffff, v53                             // 000000A79D48: 366C6AFF 0000FFFF
	v_bfe_u32 v53, v53, 4, 16                                  // 000000A79D50: D6100035 02410935
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000A79D58: D622003A 03FD013A 00006400
	v_and_b32_e32 v69, 0xffff, v71                             // 000000A79D64: 368A8EFF 0000FFFF
	v_sad_u8 v59, v59, 0, 0x6400                               // 000000A79D6C: D622003B 03FD013B 00006400
	.long 0xd72c0036                                           // 000000A79D78: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 000000A79D7C: 02026CFF 83DCD12D
	.long 0xd72c0035                                           // 000000A79D84: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000A79D88: 02026AFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A79D90: BF870112
	v_sad_u8 v68, v54, 0, 0x6400                               // 000000A79D94: D6220044 03FD0136 00006400
	v_sad_u8 v70, v53, 0, 0x6400                               // 000000A79DA0: D6220046 03FD0135 00006400
	ds_load_2addr_b32 v[53:54], v52 offset0:64 offset1:96      // 000000A79DAC: D8DC6040 35000034
	s_waitcnt lgkmcnt(0)                                       // 000000A79DB4: BF89FC07
	v_mov_b32_e32 v55, v53                                     // 000000A79DB8: 7E6E0335
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A79DBC: BF8700A1
	.long 0xd73d0037                                           // 000000A79DC0: D73D0037
	v_cndmask_b32_e32 v1, v44, v55, vcc_lo                     // 000000A79DC4: 02026F2C
	v_pk_fma_f16 v56, v66, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A79DC8: CC0E0038 0BFC0B42 0000C931
	v_dual_dot2acc_f32_f16 v35, v56, v21 :: v_dual_lshlrev_b32 v68, 16, v68// 000000A79DD4: CB222B38 23448890
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A79DDC: BF870211
	v_and_or_b32 v68, 0xffff, v70, v68                         // 000000A79DE0: D6570044 05128CFF 0000FFFF
	v_and_b32_e32 v56, 0xffff, v55                             // 000000A79DEC: 36706EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2)                            // 000000A79DF4: BF870002
	v_pk_fma_f16 v61, v68, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A79DF8: CC0E003D 0BFC0B44 0000C931
	v_lshl_or_b32 v68, v58, 16, v69                            // 000000A79E04: D6560044 0515213A
	v_lshlrev_b32_e32 v69, 16, v59                             // 000000A79E0C: 308A7690
	ds_load_2addr_b32 v[58:59], v48 offset0:64 offset1:96      // 000000A79E10: D8DC6040 3A000030
	v_dot2acc_f32_f16 v34, v61, v19                            // 000000A79E18: 0444273D
	v_pk_fma_f16 v53, v68, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A79E1C: CC0E0035 0BFC0B44 0000C931
	v_and_or_b32 v64, 0xffff, v67, v69                         // 000000A79E28: D6570040 051686FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A79E34: BF870112
	v_dot2acc_f32_f16 v34, v53, v20                            // 000000A79E38: 04442935
	v_pk_fma_f16 v61, v64, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A79E3C: CC0E003D 0BFC0B40 0000C931
	v_bfe_u32 v53, v55, 12, 16                                 // 000000A79E48: D6100035 02411937
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A79E50: BF870112
	v_dot2acc_f32_f16 v34, v61, v21                            // 000000A79E54: 04442B3D
	.long 0xd72c0035                                           // 000000A79E58: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000A79E5C: 02026AFF 83DCD12D
	v_bfe_u32 v61, v55, 8, 16                                  // 000000A79E64: D610003D 02411137
	v_bfe_u32 v55, v55, 4, 16                                  // 000000A79E6C: D6100037 02410937
	s_waitcnt lgkmcnt(0)                                       // 000000A79E74: BF89FC07
	v_bfe_u32 v60, v58, 12, 16                                 // 000000A79E78: D610003C 0241193A
	v_bfe_u32 v62, v58, 8, 16                                  // 000000A79E80: D610003E 0241113A
	.long 0xd72c003d                                           // 000000A79E88: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000A79E8C: 02027AFF 83DCD12D
	v_bfe_u32 v63, v58, 4, 16                                  // 000000A79E94: D610003F 0241093A
	v_and_b32_e32 v58, 0xffff, v58                             // 000000A79E9C: 367474FF 0000FFFF
	.long 0xd72c003c                                           // 000000A79EA4: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000A79EA8: 020278FF 83DCD12D
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000A79EB0: D6220035 03FD0135 00006400
	.long 0xd72c0037                                           // 000000A79EBC: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000A79EC0: 02026EFF 83DCD12D
	.long 0xd72c003e                                           // 000000A79EC8: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000A79ECC: 02027CFF 83DCD12D
	.long 0xd72c003a                                           // 000000A79ED4: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A79ED8: 020274FF 83DCD12D
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000A79EE0: D622003D 03FD013D 00006400
	v_and_b32_e32 v53, 0xffff, v53                             // 000000A79EEC: 366A6AFF 0000FFFF
	.long 0xd72c003f                                           // 000000A79EF4: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000A79EF8: 02027EFF 83DCD12D
	v_sad_u8 v60, v60, 0, 0x6400                               // 000000A79F00: D622003C 03FD013C 00006400
	v_bfe_u32 v66, v59, 4, 16                                  // 000000A79F0C: D6100042 0241093B
	v_sad_u8 v64, v55, 0, 0x6400                               // 000000A79F14: D6220040 03FD0137 00006400
	v_mov_b32_e32 v55, v57                                     // 000000A79F20: 7E6E0339
	v_sad_u8 v57, v62, 0, 0x6400                               // 000000A79F24: D6220039 03FD013E 00006400
	v_and_b32_e32 v60, 0xffff, v60                             // 000000A79F30: 367878FF 0000FFFF
	v_lshl_or_b32 v61, v61, 16, v53                            // 000000A79F38: D656003D 04D5213D
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000A79F40: D622003A 03FD013A 00006400
	.long 0xd73d0035                                           // 000000A79F4C: D73D0035
	v_cndmask_b32_e32 v1, v44, v54, vcc_lo                     // 000000A79F50: 02026D2C
	v_sad_u8 v55, v63, 0, 0x6400                               // 000000A79F54: D6220037 03FD013F 00006400
	v_lshl_or_b32 v54, v57, 16, v60                            // 000000A79F60: D6560036 04F12139
	v_bfe_u32 v63, v59, 12, 16                                 // 000000A79F68: D610003F 0241193B
	v_lshlrev_b32_e32 v57, 16, v58                             // 000000A79F70: 30727490
	v_pk_fma_f16 v58, v61, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A79F74: CC0E003A 0BFC0B3D 0000C931
	v_bfe_u32 v60, v53, 12, 16                                 // 000000A79F80: D610003C 02411935
	v_pk_fma_f16 v61, v54, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A79F88: CC0E003D 0BFC0B36 0000C931
	.long 0xd72c003f                                           // 000000A79F94: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000A79F98: 02027EFF 83DCD12D
	v_and_or_b32 v54, 0xffff, v55, v57                         // 000000A79FA0: D6570036 04E66EFF 0000FFFF
	v_dot2acc_f32_f16 v33, v58, v18                            // 000000A79FAC: 0442253A
	.long 0xd72c0038                                           // 000000A79FB0: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000A79FB4: 020270FF 83DCD12D
	v_bfe_u32 v55, v53, 8, 16                                  // 000000A79FBC: D6100037 02411135
	.long 0xd72c0039                                           // 000000A79FC4: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000A79FC8: 020278FF 83DCD12D
	v_pk_fma_f16 v60, v54, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A79FD0: CC0E003C 0BFC0B36 0000C931
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000A79FDC: D622003F 03FD013F 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A79FE8: BF870234
	.long 0xd72c0037                                           // 000000A79FEC: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000A79FF0: 02026EFF 83DCD12D
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000A79FF8: D6220038 03FD0138 00006400
	v_sad_u8 v62, v57, 0, 0x6400                               // 000000A7A004: D622003E 03FD0139 00006400
	v_and_b32_e32 v63, 0xffff, v63                             // 000000A7A010: 367E7EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000A7A018: BF870123
	v_lshlrev_b32_e32 v56, 16, v56                             // 000000A7A01C: 30707090
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000A7A020: D6220037 03FD0137 00006400
	v_and_or_b32 v56, 0xffff, v64, v56                         // 000000A7A02C: D6570038 04E280FF 0000FFFF
	v_bfe_u32 v64, v59, 8, 16                                  // 000000A7A038: D6100040 0241113B
	v_and_b32_e32 v59, 0xffff, v59                             // 000000A7A040: 367676FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A7A048: BF870193
	v_pk_fma_f16 v56, v56, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A7A04C: CC0E0038 0BFC0B38 0000C931
	.long 0xd72c0040                                           // 000000A7A058: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000A7A05C: 020280FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A7A064: BF870193
	.long 0xd72c003b                                           // 000000A7A068: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000A7A06C: 020276FF 83DCD12D
	v_dual_dot2acc_f32_f16 v33, v56, v19 :: v_dual_and_b32 v58, 0xffff, v53// 000000A7A074: CB242738 213A6AFF 0000FFFF
	v_bfe_u32 v56, v53, 4, 16                                  // 000000A7A080: D6100038 02410935
	ds_load_2addr_b32 v[53:54], v52 offset0:128 offset1:160    // 000000A7A088: D8DCA080 35000034
	v_sad_u8 v64, v64, 0, 0x6400                               // 000000A7A090: D6220040 03FD0140 00006400
	v_dot2acc_f32_f16 v33, v61, v20                            // 000000A7A09C: 0442293D
	.long 0xd72c003a                                           // 000000A7A0A0: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A7A0A4: 020274FF 83DCD12D
	.long 0xd72c0041                                           // 000000A7A0AC: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000A7A0B0: 020270FF 83DCD12D
	ds_load_2addr_b32 v[56:57], v51 offset0:128 offset1:160    // 000000A7A0B8: D8DCA080 38000033
	v_dual_dot2acc_f32_f16 v33, v60, v21 :: v_dual_and_b32 v62, 0xffff, v62// 000000A7A0C0: CB242B3C 213E7CFF 0000FFFF
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000A7A0CC: D622003A 03FD013A 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A7A0D8: BF8701A2
	v_lshl_or_b32 v55, v55, 16, v62                            // 000000A7A0DC: D6560037 04F92137
	v_sad_u8 v62, v65, 0, 0x6400                               // 000000A7A0E4: D622003E 03FD0141 00006400
	v_lshlrev_b32_e32 v58, 16, v58                             // 000000A7A0F0: 30747490
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A7A0F4: BF870003
	v_pk_fma_f16 v65, v55, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A7A0F8: CC0E0041 0BFC0B37 0000C931
	s_waitcnt lgkmcnt(1)                                       // 000000A7A104: BF89FC17
	v_mov_b32_e32 v55, v53                                     // 000000A7A108: 7E6E0335
	.long 0xd72c0035                                           // 000000A7A10C: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 000000A7A110: 020284FF 83DCD12D
	v_and_or_b32 v62, 0xffff, v62, v58                         // 000000A7A118: D657003E 04EA7CFF 0000FFFF
	v_sad_u8 v66, v59, 0, 0x6400                               // 000000A7A124: D6220042 03FD013B 00006400
	ds_load_2addr_b32 v[58:59], v48 offset0:128 offset1:160    // 000000A7A130: D8DCA080 3A000030
	s_waitcnt lgkmcnt(1)                                       // 000000A7A138: BF89FC17
	.long 0xd73d0037                                           // 000000A7A13C: D73D0037
	v_cndmask_b32_e32 v1, v44, v55, vcc_lo                     // 000000A7A140: 02026F2C
	v_dot2acc_f32_f16 v32, v65, v18                            // 000000A7A144: 04402541
	v_pk_fma_f16 v56, v62, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A7A148: CC0E0038 0BFC0B3E 0000C931
	v_lshl_or_b32 v62, v64, 16, v63                            // 000000A7A154: D656003E 04FD2140
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000A7A15C: D6220035 03FD0135 00006400
	v_lshlrev_b32_e32 v63, 16, v66                             // 000000A7A168: 307E8490
	v_bfe_u32 v64, v55, 12, 16                                 // 000000A7A16C: D6100040 02411937
	v_dot2acc_f32_f16 v32, v56, v19                            // 000000A7A174: 04402738
	v_pk_fma_f16 v61, v62, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A7A178: CC0E003D 0BFC0B3E 0000C931
	v_bfe_u32 v62, v55, 8, 16                                  // 000000A7A184: D610003E 02411137
	v_and_or_b32 v53, 0xffff, v53, v63                         // 000000A7A18C: D6570035 04FE6AFF 0000FFFF
	.long 0xd72c0038                                           // 000000A7A198: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000A7A19C: 020280FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A7A1A4: BF870214
	v_dot2acc_f32_f16 v32, v61, v20                            // 000000A7A1A8: 0440293D
	.long 0xd72c003d                                           // 000000A7A1AC: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000A7A1B0: 02027CFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A7A1B8: BF870004
	v_pk_fma_f16 v60, v53, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A7A1BC: CC0E003C 0BFC0B35 0000C931
	v_bfe_u32 v53, v55, 4, 16                                  // 000000A7A1C8: D6100035 02410937
	v_and_b32_e32 v55, 0xffff, v55                             // 000000A7A1D0: 366E6EFF 0000FFFF
	s_waitcnt lgkmcnt(0)                                       // 000000A7A1D8: BF89FC07
	v_bfe_u32 v62, v58, 12, 16                                 // 000000A7A1DC: D610003E 0241193A
	v_and_b32_e32 v64, 0xffff, v58                             // 000000A7A1E4: 368074FF 0000FFFF
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000A7A1EC: D6220038 03FD0138 00006400
	.long 0xd72c0037                                           // 000000A7A1F8: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000A7A1FC: 02026EFF 83DCD12D
	.long 0xd72c0035                                           // 000000A7A204: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000A7A208: 02026AFF 83DCD12D
	.long 0xd72c003e                                           // 000000A7A210: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000A7A214: 02027CFF 83DCD12D
	.long 0xd72c0040                                           // 000000A7A21C: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000A7A220: 020280FF 83DCD12D
	v_bfe_u32 v63, v58, 8, 16                                  // 000000A7A228: D610003F 0241113A
	v_and_b32_e32 v56, 0xffff, v56                             // 000000A7A230: 367070FF 0000FFFF
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000A7A238: D622003D 03FD013D 00006400
	v_bfe_u32 v58, v58, 4, 16                                  // 000000A7A244: D610003A 0241093A
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000A7A24C: D6220037 03FD0137 00006400
	v_dot2acc_f32_f16 v32, v60, v21                            // 000000A7A258: 04402B3C
	v_sad_u8 v62, v62, 0, 0x6400                               // 000000A7A25C: D622003E 03FD013E 00006400
	v_lshl_or_b32 v56, v61, 16, v56                            // 000000A7A268: D6560038 04E1213D
	.long 0xd72c003d                                           // 000000A7A270: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000A7A274: 02027EFF 83DCD12D
	v_sad_u8 v63, v53, 0, 0x6400                               // 000000A7A27C: D622003F 03FD0135 00006400
	v_lshlrev_b32_e32 v65, 16, v55                             // 000000A7A288: 30826E90
	v_sad_u8 v53, v64, 0, 0x6400                               // 000000A7A28C: D6220035 03FD0140 00006400
	v_mov_b32_e32 v55, v57                                     // 000000A7A298: 7E6E0339
	v_and_b32_e32 v57, 0xffff, v62                             // 000000A7A29C: 36727CFF 0000FFFF
	.long 0xd72c003a                                           // 000000A7A2A4: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A7A2A8: 020274FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A7A2B0: BF870214
	v_lshlrev_b32_e32 v62, 16, v53                             // 000000A7A2B4: 307C6A90
	.long 0xd73d0035                                           // 000000A7A2B8: D73D0035
	v_cndmask_b32_e32 v1, v44, v54, vcc_lo                     // 000000A7A2BC: 02026D2C
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000A7A2C0: D622003D 03FD013D 00006400
	v_and_or_b32 v54, 0xffff, v63, v65                         // 000000A7A2CC: D6570036 05067EFF 0000FFFF
	v_pk_fma_f16 v55, v56, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A7A2D8: CC0E0037 0BFC0B38 0000C931
	v_bfe_u32 v63, v59, 4, 16                                  // 000000A7A2E4: D610003F 0241093B
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000A7A2EC: D622003A 03FD013A 00006400
	v_lshl_or_b32 v56, v61, 16, v57                            // 000000A7A2F8: D6560038 04E5213D
	v_pk_fma_f16 v54, v54, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A7A300: CC0E0036 0BFC0B36 0000C931
	v_dot2acc_f32_f16 v31, v55, v18                            // 000000A7A30C: 043E2537
	.long 0xd72c003f                                           // 000000A7A310: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000A7A314: 02027EFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A7A31C: BF870224
	v_pk_fma_f16 v60, v56, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A7A320: CC0E003C 0BFC0B38 0000C931
	v_bfe_u32 v56, v53, 8, 16                                  // 000000A7A32C: D6100038 02411135
	v_dot2acc_f32_f16 v31, v54, v19                            // 000000A7A334: 043E2736
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A7A338: BF870112
	.long 0xd72c0038                                           // 000000A7A33C: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000A7A340: 020270FF 83DCD12D
	v_dot2acc_f32_f16 v31, v60, v20                            // 000000A7A348: 043E293C
	v_and_or_b32 v57, 0xffff, v58, v62                         // 000000A7A34C: D6570039 04FA74FF 0000FFFF
	v_bfe_u32 v58, v53, 12, 16                                 // 000000A7A358: D610003A 02411935
	v_bfe_u32 v62, v59, 8, 16                                  // 000000A7A360: D610003E 0241113B
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000A7A368: D622003F 03FD013F 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A7A374: BF870214
	v_pk_fma_f16 v61, v57, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A7A378: CC0E003D 0BFC0B39 0000C931
	.long 0xd72c0037                                           // 000000A7A384: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A7A388: 020274FF 83DCD12D
	v_bfe_u32 v57, v53, 4, 16                                  // 000000A7A390: D6100039 02410935
	v_and_b32_e32 v53, 0xffff, v53                             // 000000A7A398: 366A6AFF 0000FFFF
	v_bfe_u32 v58, v59, 12, 16                                 // 000000A7A3A0: D610003A 0241193B
	v_and_b32_e32 v59, 0xffff, v59                             // 000000A7A3A8: 367676FF 0000FFFF
	v_sad_u8 v65, v56, 0, 0x6400                               // 000000A7A3B0: D6220041 03FD0138 00006400
	.long 0xd72c0042                                           // 000000A7A3BC: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 000000A7A3C0: 020272FF 83DCD12D
	.long 0xd72c0040                                           // 000000A7A3C8: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000A7A3CC: 02026AFF 83DCD12D
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000A7A3D4: D6220037 03FD0137 00006400
	ds_load_2addr_b32 v[53:54], v52 offset0:192 offset1:224    // 000000A7A3E0: D8DCE0C0 35000034
	ds_load_2addr_b32 v[56:57], v51 offset0:192 offset1:224    // 000000A7A3E8: D8DCE0C0 38000033
	.long 0xd72c003b                                           // 000000A7A3F0: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000A7A3F4: 020276FF 83DCD12D
	.long 0xd72c003a                                           // 000000A7A3FC: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A7A400: 020274FF 83DCD12D
	v_and_b32_e32 v55, 0xffff, v55                             // 000000A7A408: 366E6EFF 0000FFFF
	.long 0xd72c003e                                           // 000000A7A410: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000A7A414: 02027CFF 83DCD12D
	v_sad_u8 v66, v66, 0, 0x6400                               // 000000A7A41C: D6220042 03FD0142 00006400
	v_dot2acc_f32_f16 v31, v61, v21                            // 000000A7A428: 043E2B3D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000A7A42C: BF870244
	v_lshl_or_b32 v65, v65, 16, v55                            // 000000A7A430: D6560041 04DD2141
	v_sad_u8 v55, v64, 0, 0x6400                               // 000000A7A438: D6220037 03FD0140 00006400
	v_sad_u8 v64, v58, 0, 0x6400                               // 000000A7A444: D6220040 03FD013A 00006400
	v_sad_u8 v62, v62, 0, 0x6400                               // 000000A7A450: D622003E 03FD013E 00006400
	v_pk_fma_f16 v65, v65, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A7A45C: CC0E0041 0BFC0B41 0000C931
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A7A468: BF870004
	v_lshlrev_b32_e32 v67, 16, v55                             // 000000A7A46C: 30866E90
	v_sad_u8 v55, v59, 0, 0x6400                               // 000000A7A470: D6220037 03FD013B 00006400
	ds_load_2addr_b32 v[58:59], v48 offset0:192 offset1:224    // 000000A7A47C: D8DCE0C0 3A000030
	v_and_b32_e32 v64, 0xffff, v64                             // 000000A7A484: 368080FF 0000FFFF
	v_dot2acc_f32_f16 v30, v65, v18                            // 000000A7A48C: 043C2541
	s_waitcnt lgkmcnt(2)                                       // 000000A7A490: BF89FC27
	v_dual_mov_b32 v55, v53 :: v_dual_lshlrev_b32 v68, 16, v55 // 000000A7A494: CA220135 37446E90
	v_and_or_b32 v53, 0xffff, v66, v67                         // 000000A7A49C: D6570035 050E84FF 0000FFFF
	v_lshl_or_b32 v62, v62, 16, v64                            // 000000A7A4A8: D656003E 0501213E
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A7A4B0: BF870003
	v_and_or_b32 v63, 0xffff, v63, v68                         // 000000A7A4B4: D657003F 05127EFF 0000FFFF
	s_waitcnt lgkmcnt(1)                                       // 000000A7A4C0: BF89FC17
	.long 0xd73d0037                                           // 000000A7A4C4: D73D0037
	v_cndmask_b32_e32 v1, v44, v55, vcc_lo                     // 000000A7A4C8: 02026F2C
	v_pk_fma_f16 v53, v53, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A7A4CC: CC0E0035 0BFC0B35 0000C931
	v_pk_fma_f16 v56, v62, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A7A4D8: CC0E0038 0BFC0B3E 0000C931
	v_pk_fma_f16 v60, v63, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A7A4E4: CC0E003C 0BFC0B3F 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A7A4F0: BF870214
	v_bfe_u32 v62, v55, 12, 16                                 // 000000A7A4F4: D610003E 02411937
	v_dot2acc_f32_f16 v30, v53, v19                            // 000000A7A4FC: 043C2735
	v_and_b32_e32 v53, 0xffff, v55                             // 000000A7A500: 366A6EFF 0000FFFF
	v_bfe_u32 v63, v55, 8, 16                                  // 000000A7A508: D610003F 02411137
	s_waitcnt lgkmcnt(0)                                       // 000000A7A510: BF89FC07
	v_bfe_u32 v64, v58, 12, 16                                 // 000000A7A514: D6100040 0241193A
	.long 0xd72c003e                                           // 000000A7A51C: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000A7A520: 02027CFF 83DCD12D
	v_bfe_u32 v55, v55, 4, 16                                  // 000000A7A528: D6100037 02410937
	.long 0xd72c0035                                           // 000000A7A530: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000A7A534: 02026AFF 83DCD12D
	.long 0xd72c003f                                           // 000000A7A53C: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000A7A540: 02027EFF 83DCD12D
	v_bfe_u32 v65, v58, 8, 16                                  // 000000A7A548: D6100041 0241113A
	.long 0xd72c0040                                           // 000000A7A550: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000A7A554: 020280FF 83DCD12D
	.long 0xd72c0037                                           // 000000A7A55C: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000A7A560: 02026EFF 83DCD12D
	v_dot2acc_f32_f16 v30, v56, v20                            // 000000A7A568: 043C2938
	v_sad_u8 v62, v62, 0, 0x6400                               // 000000A7A56C: D622003E 03FD013E 00006400
	.long 0xd72c0041                                           // 000000A7A578: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000A7A57C: 020282FF 83DCD12D
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000A7A584: D6220035 03FD0135 00006400
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000A7A590: D622003F 03FD013F 00006400
	v_bfe_u32 v66, v58, 4, 16                                  // 000000A7A59C: D6100042 0241093A
	v_and_b32_e32 v62, 0xffff, v62                             // 000000A7A5A4: 367C7CFF 0000FFFF
	v_sad_u8 v64, v64, 0, 0x6400                               // 000000A7A5AC: D6220040 03FD0140 00006400
	v_sad_u8 v67, v55, 0, 0x6400                               // 000000A7A5B8: D6220043 03FD0137 00006400
	v_lshlrev_b32_e32 v53, 16, v53                             // 000000A7A5C4: 306A6A90
	v_mov_b32_e32 v55, v57                                     // 000000A7A5C8: 7E6E0339
	v_lshl_or_b32 v62, v63, 16, v62                            // 000000A7A5CC: D656003E 04F9213F
	v_and_b32_e32 v64, 0xffff, v64                             // 000000A7A5D4: 368080FF 0000FFFF
	v_sad_u8 v57, v65, 0, 0x6400                               // 000000A7A5DC: D6220039 03FD0141 00006400
	v_and_or_b32 v63, 0xffff, v67, v53                         // 000000A7A5E8: D657003F 04D686FF 0000FFFF
	.long 0xd73d0035                                           // 000000A7A5F4: D73D0035
	v_cndmask_b32_e32 v1, v44, v54, vcc_lo                     // 000000A7A5F8: 02026D2C
	v_pk_fma_f16 v56, v62, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A7A5FC: CC0E0038 0BFC0B3E 0000C931
	.long 0xd72c0041                                           // 000000A7A608: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 000000A7A60C: 020284FF 83DCD12D
	v_lshl_or_b32 v54, v57, 16, v64                            // 000000A7A614: D6560036 05012139
	v_pk_fma_f16 v57, v63, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A7A61C: CC0E0039 0BFC0B3F 0000C931
	v_bfe_u32 v66, v59, 8, 16                                  // 000000A7A628: D6100042 0241113B
	v_dot2acc_f32_f16 v29, v56, v18                            // 000000A7A630: 043A2538
	v_and_b32_e32 v58, 0xffff, v58                             // 000000A7A634: 367474FF 0000FFFF
	v_and_b32_e32 v63, 0xffff, v53                             // 000000A7A63C: 367E6AFF 0000FFFF
	v_bfe_u32 v64, v53, 8, 16                                  // 000000A7A644: D6100040 02411135
	v_pk_fma_f16 v54, v54, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A7A64C: CC0E0036 0BFC0B36 0000C931
	v_dot2acc_f32_f16 v29, v57, v19                            // 000000A7A658: 043A2739
	.long 0xd72c0037                                           // 000000A7A65C: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A7A660: 020274FF 83DCD12D
	v_bfe_u32 v58, v53, 12, 16                                 // 000000A7A668: D610003A 02411935
	v_bfe_u32 v53, v53, 4, 16                                  // 000000A7A670: D6100035 02410935
	.long 0xd72c003f                                           // 000000A7A678: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000A7A67C: 02027EFF 83DCD12D
	.long 0xd72c0040                                           // 000000A7A684: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000A7A688: 020280FF 83DCD12D
	v_sad_u8 v62, v65, 0, 0x6400                               // 000000A7A690: D622003E 03FD0141 00006400
	.long 0xd72c003a                                           // 000000A7A69C: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A7A6A0: 020274FF 83DCD12D
	.long 0xd72c0035                                           // 000000A7A6A8: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000A7A6AC: 02026AFF 83DCD12D
	v_bfe_u32 v65, v59, 12, 16                                 // 000000A7A6B4: D6100041 0241193B
	v_dot2acc_f32_f16 v29, v54, v20                            // 000000A7A6BC: 043A2936
	v_bfe_u32 v67, v59, 4, 16                                  // 000000A7A6C0: D6100043 0241093B
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000A7A6C8: D622003F 03FD013F 00006400
	v_sad_u8 v64, v64, 0, 0x6400                               // 000000A7A6D4: D6220040 03FD0140 00006400
	.long 0xd72c0041                                           // 000000A7A6E0: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000A7A6E4: 020282FF 83DCD12D
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000A7A6EC: D622003A 03FD013A 00006400
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000A7A6F8: D6220035 03FD0135 00006400
	v_lshlrev_b32_e32 v63, 16, v63                             // 000000A7A704: 307E7E90
	v_and_b32_e32 v59, 0xffff, v59                             // 000000A7A708: 367676FF 0000FFFF
	.long 0xd72c0042                                           // 000000A7A710: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 000000A7A714: 020284FF 83DCD12D
	v_and_b32_e32 v58, 0xffff, v58                             // 000000A7A71C: 367474FF 0000FFFF
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000A7A724: D6220037 03FD0137 00006400
	v_and_or_b32 v53, 0xffff, v53, v63                         // 000000A7A730: D6570035 04FE6AFF 0000FFFF
	.long 0xd72c003b                                           // 000000A7A73C: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000A7A740: 020276FF 83DCD12D
	v_sad_u8 v65, v65, 0, 0x6400                               // 000000A7A748: D6220041 03FD0141 00006400
	v_lshl_or_b32 v58, v64, 16, v58                            // 000000A7A754: D656003A 04E92140
	.long 0xd72c003f                                           // 000000A7A75C: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000A7A760: 020286FF 83DCD12D
	v_pk_fma_f16 v53, v53, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A7A768: CC0E0035 0BFC0B35 0000C931
	v_dual_dot2acc_f32_f16 v30, v60, v21 :: v_dual_lshlrev_b32 v55, 16, v55// 000000A7A774: CB222B3C 1E366E90
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000A7A77C: BF870134
	v_pk_fma_f16 v58, v58, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A7A780: CC0E003A 0BFC0B3A 0000C931
	v_sad_u8 v56, v59, 0, 0x6400                               // 000000A7A78C: D6220038 03FD013B 00006400
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000A7A798: D622003F 03FD013F 00006400
	v_dual_dot2acc_f32_f16 v1, v58, v18 :: v_dual_lshlrev_b32 v56, 16, v56// 000000A7A7A4: CB22253A 01387090
	v_and_or_b32 v18, 0xffff, v62, v55                         // 000000A7A7AC: D6570012 04DE7CFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A7A7B8: BF870222
	v_dual_dot2acc_f32_f16 v1, v53, v19 :: v_dual_and_b32 v64, 0xffff, v65// 000000A7A7BC: CB242735 014082FF 0000FFFF
	v_sad_u8 v65, v66, 0, 0x6400                               // 000000A7A7C8: D6220041 03FD0142 00006400
	v_and_or_b32 v56, 0xffff, v63, v56                         // 000000A7A7D4: D6570038 04E27EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A7A7E0: BF870224
	v_pk_fma_f16 v18, v18, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A7A7E4: CC0E0012 0BFC0B12 0000C931
	v_add_nc_u32_e32 v46, 1, v46                               // 000000A7A7F0: 4A5C5C81
	v_lshl_or_b32 v59, v65, 16, v64                            // 000000A7A7F4: D656003B 05012141
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A7A7FC: BF870214
	v_pk_fma_f16 v19, v56, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A7A800: CC0E0013 0BFC0B38 0000C931
	v_dot2acc_f32_f16 v29, v18, v21                            // 000000A7A80C: 043A2B12
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A7A810: BF870093
	v_pk_fma_f16 v55, v59, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A7A814: CC0E0037 0BFC0B3B 0000C931
	v_dual_dot2acc_f32_f16 v1, v55, v20 :: v_dual_add_nc_u32 v20, v45, v46// 000000A7A820: CB202937 01145D2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A7A828: BF870111
	v_dot2acc_f32_f16 v1, v19, v21                             // 000000A7A82C: 04022B13
	v_cmp_eq_u32_e32 vcc_lo, 21, v20                           // 000000A7A830: 7C942895
	s_or_b32 s4, vcc_lo, s4                                    // 000000A7A834: 8C04046A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A7A838: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000A7A83C: 917E047E
	s_cbranch_execz 62                                         // 000000A7A840: BFA5003E <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi0ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x203c>
	s_mov_b32 s0, exec_lo                                      // 000000A7A844: BE80007E
	s_waitcnt vmcnt(14)                                        // 000000A7A848: BF893BF7
	ds_store_2addr_b32 v47, v2, v3 offset1:32                  // 000000A7A84C: D8382000 0003022F
	s_waitcnt vmcnt(12)                                        // 000000A7A854: BF8933F7
	ds_store_2addr_b32 v47, v4, v5 offset0:64 offset1:96       // 000000A7A858: D8386040 0005042F
	s_waitcnt vmcnt(10)                                        // 000000A7A860: BF892BF7
	ds_store_2addr_b32 v47, v6, v7 offset0:128 offset1:160     // 000000A7A864: D838A080 0007062F
	s_waitcnt vmcnt(8)                                         // 000000A7A86C: BF8923F7
	ds_store_2addr_b32 v47, v8, v9 offset0:192 offset1:224     // 000000A7A870: D838E0C0 0009082F
	s_waitcnt vmcnt(6)                                         // 000000A7A878: BF891BF7
	ds_store_2addr_b32 v48, v10, v11 offset1:32                // 000000A7A87C: D8382000 000B0A30
	s_waitcnt vmcnt(4)                                         // 000000A7A884: BF8913F7
	ds_store_2addr_b32 v48, v12, v13 offset0:64 offset1:96     // 000000A7A888: D8386040 000D0C30
	s_waitcnt vmcnt(2)                                         // 000000A7A890: BF890BF7
	ds_store_2addr_b32 v48, v14, v15 offset0:128 offset1:160   // 000000A7A894: D838A080 000F0E30
	s_waitcnt vmcnt(0)                                         // 000000A7A89C: BF8903F7
	ds_store_2addr_b32 v48, v16, v17 offset0:192 offset1:224   // 000000A7A8A0: D838E0C0 00111030
	.long 0xd4c9007e                                           // 000000A7A8A8: D4C9007E
	v_cndmask_b32_e32 v1, v46, v27, vcc_lo                     // 000000A7A8AC: 0202372E
	s_cbranch_execz 63785                                      // 000000A7A8B0: BFA5F929 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi0ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x458>
	s_clause 0xf                                               // 000000A7A8B4: BF85000F
	global_load_b32 v2, v[22:23], off                          // 000000A7A8B8: DC520000 027C0016
	global_load_b32 v3, v[22:23], off offset:128               // 000000A7A8C0: DC520080 037C0016
	global_load_b32 v4, v[22:23], off offset:256               // 000000A7A8C8: DC520100 047C0016
	global_load_b32 v5, v[22:23], off offset:384               // 000000A7A8D0: DC520180 057C0016
	global_load_b32 v6, v[22:23], off offset:512               // 000000A7A8D8: DC520200 067C0016
	global_load_b32 v7, v[22:23], off offset:640               // 000000A7A8E0: DC520280 077C0016
	global_load_b32 v8, v[22:23], off offset:768               // 000000A7A8E8: DC520300 087C0016
	global_load_b32 v9, v[22:23], off offset:896               // 000000A7A8F0: DC520380 097C0016
	global_load_b32 v10, v[22:23], off offset:1024             // 000000A7A8F8: DC520400 0A7C0016
	global_load_b32 v11, v[22:23], off offset:1152             // 000000A7A900: DC520480 0B7C0016
	global_load_b32 v12, v[22:23], off offset:1280             // 000000A7A908: DC520500 0C7C0016
	global_load_b32 v13, v[22:23], off offset:1408             // 000000A7A910: DC520580 0D7C0016
	global_load_b32 v14, v[22:23], off offset:1536             // 000000A7A918: DC520600 0E7C0016
	global_load_b32 v15, v[22:23], off offset:1664             // 000000A7A920: DC520680 0F7C0016
	global_load_b32 v16, v[22:23], off offset:1792             // 000000A7A928: DC520700 107C0016
	global_load_b32 v17, v[22:23], off offset:1920             // 000000A7A930: DC520780 117C0016
	s_branch 63751                                             // 000000A7A938: BFA0F907 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi0ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x458>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000A7A93C: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A7A940: BF870009
	s_or_b32 exec_lo, exec_lo, s3                              // 000000A7A944: 8C7E037E
	s_waitcnt vmcnt(14)                                        // 000000A7A948: BF893BF7
	v_dual_mov_b32 v2, v28 :: v_dual_mov_b32 v3, v42           // 000000A7A94C: CA10011C 0202012A
	s_waitcnt vmcnt(12)                                        // 000000A7A954: BF8933F7
	v_dual_mov_b32 v4, v41 :: v_dual_mov_b32 v5, v40           // 000000A7A958: CA100129 04040128
	s_waitcnt vmcnt(10)                                        // 000000A7A960: BF892BF7
	v_dual_mov_b32 v6, v39 :: v_dual_mov_b32 v7, v38           // 000000A7A964: CA100127 06060126
	s_waitcnt vmcnt(8)                                         // 000000A7A96C: BF8923F7
	v_dual_mov_b32 v8, v37 :: v_dual_mov_b32 v9, v36           // 000000A7A970: CA100125 08080124
	s_waitcnt vmcnt(6)                                         // 000000A7A978: BF891BF7
	v_dual_mov_b32 v10, v35 :: v_dual_mov_b32 v11, v34         // 000000A7A97C: CA100123 0A0A0122
	s_waitcnt vmcnt(4)                                         // 000000A7A984: BF8913F7
	v_dual_mov_b32 v12, v33 :: v_dual_mov_b32 v13, v32         // 000000A7A988: CA100121 0C0C0120
	s_waitcnt vmcnt(2)                                         // 000000A7A990: BF890BF7
	v_dual_mov_b32 v14, v31 :: v_dual_mov_b32 v15, v30         // 000000A7A994: CA10011F 0E0E011E
	s_waitcnt vmcnt(1)                                         // 000000A7A99C: BF8907F7
	v_mov_b32_e32 v16, v29                                     // 000000A7A9A0: 7E20031D
	s_waitcnt vmcnt(0)                                         // 000000A7A9A4: BF8903F7
	v_mov_b32_e32 v17, v1                                      // 000000A7A9A8: 7E220301
	s_mov_b32 s0, 0x76543210                                   // 000000A7A9AC: BE8000FF 76543210
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A7A9B4: BF870009
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 000000A7A9B8: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 000000A7A9C4: D65C0003 03FC0103 FEDCBA98
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 000000A7A9D0: D65C0004 03FC0104 FEDCBA98
	v_permlanex16_b32 v5, v5, s0, 0xfedcba98                   // 000000A7A9DC: D65C0005 03FC0105 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 000000A7A9E8: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v7, v7, s0, 0xfedcba98                   // 000000A7A9F4: D65C0007 03FC0107 FEDCBA98
	v_permlanex16_b32 v8, v8, s0, 0xfedcba98                   // 000000A7AA00: D65C0008 03FC0108 FEDCBA98
	v_permlanex16_b32 v9, v9, s0, 0xfedcba98                   // 000000A7AA0C: D65C0009 03FC0109 FEDCBA98
	v_permlanex16_b32 v10, v10, s0, 0xfedcba98                 // 000000A7AA18: D65C000A 03FC010A FEDCBA98
	v_permlanex16_b32 v11, v11, s0, 0xfedcba98                 // 000000A7AA24: D65C000B 03FC010B FEDCBA98
	v_permlanex16_b32 v12, v12, s0, 0xfedcba98                 // 000000A7AA30: D65C000C 03FC010C FEDCBA98
	v_permlanex16_b32 v13, v13, s0, 0xfedcba98                 // 000000A7AA3C: D65C000D 03FC010D FEDCBA98
	v_permlanex16_b32 v14, v14, s0, 0xfedcba98                 // 000000A7AA48: D65C000E 03FC010E FEDCBA98
	v_permlanex16_b32 v15, v15, s0, 0xfedcba98                 // 000000A7AA54: D65C000F 03FC010F FEDCBA98
	v_permlanex16_b32 v16, v16, s0, 0xfedcba98                 // 000000A7AA60: D65C0010 03FC0110 FEDCBA98
	v_permlanex16_b32 v17, v17, s0, 0xfedcba98                 // 000000A7AA6C: D65C0011 03FC0111 FEDCBA98
	.long 0xd44c0000                                           // 000000A7AA78: D44C0000
	v_cndmask_b32_e32 v1, 16, v25, vcc_lo                      // 000000A7AA7C: 02023290
	s_barrier                                                  // 000000A7AA80: BFBD0000
	buffer_gl0_inv                                             // 000000A7AA84: E0AC0000 00000000
	s_and_saveexec_b32 s3, s0                                  // 000000A7AA8C: BE832000
	s_cbranch_execz 34                                         // 000000A7AA90: BFA50022 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi0ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x221c>
	v_dual_add_f32 v1, v1, v17 :: v_dual_add_f32 v2, v28, v2   // 000000A7AA94: C9082301 0102051C
	v_dual_add_f32 v3, v42, v3 :: v_dual_add_f32 v4, v41, v4   // 000000A7AA9C: C908072A 03040929
	v_lshl_or_b32 v17, v24, 10, v26                            // 000000A7AAA4: D6560011 04691518
	v_dual_add_f32 v5, v40, v5 :: v_dual_add_f32 v6, v39, v6   // 000000A7AAAC: C9080B28 05060D27
	v_dual_add_f32 v7, v38, v7 :: v_dual_add_f32 v8, v37, v8   // 000000A7AAB4: C9080F26 07081125
	v_dual_add_f32 v9, v36, v9 :: v_dual_add_f32 v10, v35, v10 // 000000A7AABC: C9081324 090A1523
	v_dual_add_f32 v11, v34, v11 :: v_dual_add_f32 v12, v33, v12// 000000A7AAC4: C9081722 0B0C1921
	v_dual_add_f32 v13, v32, v13 :: v_dual_add_f32 v14, v31, v14// 000000A7AACC: C9081B20 0D0E1D1F
	v_dual_add_f32 v15, v30, v15 :: v_dual_add_f32 v16, v29, v16// 000000A7AAD4: C9081F1E 0F10211D
	ds_store_2addr_b32 v17, v2, v3 offset1:16                  // 000000A7AADC: D8381000 00030211
	ds_store_2addr_b32 v17, v4, v5 offset0:32 offset1:48       // 000000A7AAE4: D8383020 00050411
	ds_store_2addr_b32 v17, v6, v7 offset0:64 offset1:80       // 000000A7AAEC: D8385040 00070611
	ds_store_2addr_b32 v17, v8, v9 offset0:96 offset1:112      // 000000A7AAF4: D8387060 00090811
	ds_store_2addr_b32 v17, v10, v11 offset0:128 offset1:144   // 000000A7AAFC: D8389080 000B0A11
	ds_store_2addr_b32 v17, v12, v13 offset0:160 offset1:176   // 000000A7AB04: D838B0A0 000D0C11
	ds_store_2addr_b32 v17, v14, v15 offset0:192 offset1:208   // 000000A7AB0C: D838D0C0 000F0E11
	ds_store_2addr_b32 v17, v16, v1 offset0:224 offset1:240    // 000000A7AB14: D838F0E0 00011011
	s_or_b32 exec_lo, exec_lo, s3                              // 000000A7AB1C: 8C7E037E
	s_waitcnt lgkmcnt(0)                                       // 000000A7AB20: BF89FC07
	s_barrier                                                  // 000000A7AB24: BFBD0000
	buffer_gl0_inv                                             // 000000A7AB28: E0AC0000 00000000
	s_mov_b32 s3, exec_lo                                      // 000000A7AB30: BE83007E
	v_cmpx_eq_u32_e32 0, v24                                   // 000000A7AB34: 7D943080
	s_cbranch_execz 1332                                       // 000000A7AB38: BFA50534 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi0ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x370c>
	v_and_b32_e32 v3, 15, v0                                   // 000000A7AB3C: 3606008F
	s_mul_i32 s3, s1, 0xa00                                    // 000000A7AB40: 9603FF01 00000A00
	s_mul_hi_i32 s4, s1, 0xa00                                 // 000000A7AB48: 9704FF01 00000A00
	s_add_u32 s5, s10, s3                                      // 000000A7AB50: 8005030A
	s_addc_u32 s4, s11, s4                                     // 000000A7AB54: 8204040B
	v_lshlrev_b32_e32 v4, 2, v3                                // 000000A7AB58: 30080682
	s_lshl_b32 s2, s2, 7                                       // 000000A7AB5C: 84028702
	ds_load_2addr_b32 v[1:2], v4 offset1:16                    // 000000A7AB60: D8DC1000 01000004
	ds_load_2addr_b32 v[5:6], v4 offset0:128 offset1:144       // 000000A7AB68: D8DC9080 05000004
	s_ashr_i32 s3, s2, 31                                      // 000000A7AB70: 86039F02
	v_lshlrev_b32_e32 v52, 1, v0                               // 000000A7AB74: 30680081
	s_lshl_b64 s[10:11], s[2:3], 1                             // 000000A7AB78: 848A8102
	s_mul_i32 s2, s1, 0x500                                    // 000000A7AB7C: 9602FF01 00000500
	s_add_u32 s6, s5, s10                                      // 000000A7AB84: 80060A05
	s_addc_u32 s7, s4, s11                                     // 000000A7AB88: 82070B04
	s_mul_hi_i32 s1, s1, 0x500                                 // 000000A7AB8C: 9701FF01 00000500
	s_add_u32 s2, s12, s2                                      // 000000A7AB94: 8002020C
	s_addc_u32 s1, s13, s1                                     // 000000A7AB98: 8201010D
	s_add_u32 s8, s2, s10                                      // 000000A7AB9C: 80080A02
	s_addc_u32 s9, s1, s11                                     // 000000A7ABA0: 82090B01
	s_waitcnt lgkmcnt(1)                                       // 000000A7ABA4: BF89FC17
	v_add_f32_e32 v1, 0, v1                                    // 000000A7ABA8: 06020280
	v_add_nc_u32_e32 v45, 0x400, v4                            // 000000A7ABAC: 4A5A08FF 00000400
	s_waitcnt lgkmcnt(0)                                       // 000000A7ABB4: BF89FC07
	v_dual_add_f32 v5, 0, v5 :: v_dual_add_nc_u32 v46, 0x800, v4// 000000A7ABB8: C9200A80 052E08FF 00000800
	v_add_nc_u32_e32 v47, 0xc00, v4                            // 000000A7ABC4: 4A5E08FF 00000C00
	v_add_nc_u32_e32 v48, 0x1000, v4                           // 000000A7ABCC: 4A6008FF 00001000
	v_add_nc_u32_e32 v49, 0x1400, v4                           // 000000A7ABD4: 4A6208FF 00001400
	v_add_nc_u32_e32 v50, 0x1800, v4                           // 000000A7ABDC: 4A6408FF 00001800
	v_add_nc_u32_e32 v51, 0x1c00, v4                           // 000000A7ABE4: 4A6608FF 00001C00
	ds_load_2addr_b32 v[7:8], v45 offset1:16                   // 000000A7ABEC: D8DC1000 0700002D
	ds_load_2addr_b32 v[9:10], v4 offset0:32 offset1:48        // 000000A7ABF4: D8DC3020 09000004
	ds_load_2addr_b32 v[11:12], v4 offset0:160 offset1:176     // 000000A7ABFC: D8DCB0A0 0B000004
	ds_load_2addr_b32 v[13:14], v45 offset0:128 offset1:144    // 000000A7AC04: D8DC9080 0D00002D
	ds_load_2addr_b32 v[15:16], v46 offset1:16                 // 000000A7AC0C: D8DC1000 0F00002E
	ds_load_2addr_b32 v[17:18], v46 offset0:128 offset1:144    // 000000A7AC14: D8DC9080 1100002E
	ds_load_2addr_b32 v[19:20], v47 offset1:16                 // 000000A7AC1C: D8DC1000 1300002F
	ds_load_2addr_b32 v[21:22], v47 offset0:128 offset1:144    // 000000A7AC24: D8DC9080 1500002F
	ds_load_2addr_b32 v[23:24], v48 offset1:16                 // 000000A7AC2C: D8DC1000 17000030
	ds_load_2addr_b32 v[25:26], v48 offset0:128 offset1:144    // 000000A7AC34: D8DC9080 19000030
	ds_load_2addr_b32 v[27:28], v49 offset1:16                 // 000000A7AC3C: D8DC1000 1B000031
	ds_load_2addr_b32 v[29:30], v49 offset0:128 offset1:144    // 000000A7AC44: D8DC9080 1D000031
	ds_load_2addr_b32 v[31:32], v50 offset1:16                 // 000000A7AC4C: D8DC1000 1F000032
	ds_load_2addr_b32 v[33:34], v50 offset0:128 offset1:144    // 000000A7AC54: D8DC9080 21000032
	ds_load_2addr_b32 v[35:36], v51 offset1:16                 // 000000A7AC5C: D8DC1000 23000033
	v_add_f32_e32 v2, 0, v2                                    // 000000A7AC64: 06040480
	ds_load_2addr_b32 v[43:44], v46 offset0:32 offset1:48      // 000000A7AC68: D8DC3020 2B00002E
	s_waitcnt lgkmcnt(15)                                      // 000000A7AC70: BF89FCF7
	v_add_f32_e32 v1, v1, v7                                   // 000000A7AC74: 06020F01
	v_dual_add_f32 v7, 0, v6 :: v_dual_add_f32 v2, v2, v8      // 000000A7AC78: C9080C80 07021102
	s_waitcnt lgkmcnt(12)                                      // 000000A7AC80: BF89FCC7
	v_add_f32_e32 v13, v5, v13                                 // 000000A7AC84: 061A1B05
	ds_load_2addr_b32 v[5:6], v46 offset0:160 offset1:176      // 000000A7AC88: D8DCB0A0 0500002E
	s_waitcnt lgkmcnt(12)                                      // 000000A7AC90: BF89FCC7
	v_dual_add_f32 v1, v1, v15 :: v_dual_add_f32 v14, v7, v14  // 000000A7AC94: C9081F01 010E1D07
	s_waitcnt lgkmcnt(11)                                      // 000000A7AC9C: BF89FCB7
	v_dual_add_f32 v2, v2, v16 :: v_dual_add_f32 v13, v13, v17 // 000000A7ACA0: C9082102 020C230D
	ds_load_2addr_b32 v[15:16], v48 offset0:32 offset1:48      // 000000A7ACA8: D8DC3020 0F000030
	v_add_f32_e32 v14, v14, v18                                // 000000A7ACB0: 061C250E
	s_waitcnt lgkmcnt(11)                                      // 000000A7ACB4: BF89FCB7
	v_dual_add_f32 v2, v2, v20 :: v_dual_add_f32 v1, v1, v19   // 000000A7ACB8: C9082902 02002701
	ds_load_2addr_b32 v[7:8], v47 offset0:32 offset1:48        // 000000A7ACC0: D8DC3020 0700002F
	ds_load_2addr_b32 v[17:18], v48 offset0:160 offset1:176    // 000000A7ACC8: D8DCB0A0 11000030
	s_waitcnt lgkmcnt(12)                                      // 000000A7ACD0: BF89FCC7
	v_add_f32_e32 v14, v14, v22                                // 000000A7ACD4: 061C2D0E
	s_waitcnt lgkmcnt(11)                                      // 000000A7ACD8: BF89FCB7
	v_dual_add_f32 v2, v2, v24 :: v_dual_add_f32 v1, v1, v23   // 000000A7ACDC: C9083102 02002F01
	ds_load_2addr_b32 v[19:20], v49 offset0:32 offset1:48      // 000000A7ACE4: D8DC3020 13000031
	s_waitcnt lgkmcnt(11)                                      // 000000A7ACEC: BF89FCB7
	v_add_f32_e32 v14, v14, v26                                // 000000A7ACF0: 061C350E
	ds_load_2addr_b32 v[37:38], v51 offset0:128 offset1:144    // 000000A7ACF4: D8DC9080 25000033
	ds_load_2addr_b32 v[39:40], v45 offset0:32 offset1:48      // 000000A7ACFC: D8DC3020 2700002D
	ds_load_2addr_b32 v[41:42], v45 offset0:160 offset1:176    // 000000A7AD04: D8DCB0A0 2900002D
	v_add_f32_e32 v13, v13, v21                                // 000000A7AD0C: 061A2B0D
	s_waitcnt lgkmcnt(13)                                      // 000000A7AD10: BF89FCD7
	v_add_f32_e32 v1, v1, v27                                  // 000000A7AD14: 06023701
	v_add_f32_e32 v23, v2, v28                                 // 000000A7AD18: 062E3902
	s_waitcnt lgkmcnt(12)                                      // 000000A7AD1C: BF89FCC7
	v_dual_add_f32 v24, v14, v30 :: v_dual_add_f32 v9, 0, v9   // 000000A7AD20: C9083D0E 18081280
	ds_load_2addr_b32 v[21:22], v49 offset0:160 offset1:176    // 000000A7AD28: D8DCB0A0 15000031
	v_add_f32_e32 v11, 0, v11                                  // 000000A7AD30: 06161680
	s_waitcnt lgkmcnt(11)                                      // 000000A7AD34: BF89FCB7
	v_dual_add_f32 v1, v1, v31 :: v_dual_add_f32 v26, v24, v34 // 000000A7AD38: C9083F01 011A4518
	s_waitcnt lgkmcnt(3)                                       // 000000A7AD40: BF89FC37
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A7AD44: BF870001
	v_dual_add_f32 v13, v13, v25 :: v_dual_add_f32 v54, v26, v38// 000000A7AD48: C908330D 0D364D1A
	s_waitcnt lgkmcnt(2)                                       // 000000A7AD50: BF89FC27
	v_add_f32_e32 v9, v9, v39                                  // 000000A7AD54: 06124F09
	v_add_f32_e32 v39, v1, v35                                 // 000000A7AD58: 064E4701
	v_lshlrev_b32_e32 v1, 1, v3                                // 000000A7AD5C: 30020681
	s_waitcnt lgkmcnt(1)                                       // 000000A7AD60: BF89FC17
	v_add_f32_e32 v3, v11, v41                                 // 000000A7AD64: 0606530B
	v_add_f32_e32 v11, v23, v32                                // 000000A7AD68: 06164117
	v_add_f32_e32 v9, v9, v43                                  // 000000A7AD6C: 06125709
	ds_load_2addr_b32 v[23:24], v50 offset0:32 offset1:48      // 000000A7AD70: D8DC3020 17000032
	v_or_b32_e32 v41, 32, v52                                  // 000000A7AD78: 385268A0
	v_add_f32_e32 v5, v3, v5                                   // 000000A7AD7C: 060A0B03
	v_add_f32_e32 v53, v11, v36                                // 000000A7AD80: 066A490B
	v_add_f32_e32 v7, v9, v7                                   // 000000A7AD84: 060E0F09
	global_load_d16_b16 v3, v41, s[6:7]                        // 000000A7AD88: DC820000 03060029
	v_add_f32_e32 v7, v7, v15                                  // 000000A7AD90: 060E1F07
	v_add_f32_e32 v15, 0, v12                                  // 000000A7AD94: 061E1880
	ds_load_2addr_b32 v[11:12], v4 offset0:192 offset1:208     // 000000A7AD98: D8DCD0C0 0B000004
	ds_load_2addr_b32 v[27:28], v51 offset0:32 offset1:48      // 000000A7ADA0: D8DC3020 1B000033
	v_add_f32_e32 v7, v7, v19                                  // 000000A7ADA8: 060E2707
	s_waitcnt lgkmcnt(2)                                       // 000000A7ADAC: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A7ADB0: BF870001
	v_add_f32_e32 v19, v7, v23                                 // 000000A7ADB4: 06262F07
	v_add_f32_e32 v13, v13, v29                                // 000000A7ADB8: 061A3B0D
	ds_load_2addr_b32 v[29:30], v45 offset0:64 offset1:80      // 000000A7ADBC: D8DC5040 1D00002D
	ds_load_2addr_b32 v[31:32], v45 offset0:192 offset1:208    // 000000A7ADC4: D8DCD0C0 1F00002D
	v_add_f32_e32 v25, v13, v33                                // 000000A7ADCC: 0632430D
	ds_load_2addr_b32 v[13:14], v47 offset0:160 offset1:176    // 000000A7ADD0: D8DCB0A0 0D00002F
	s_waitcnt lgkmcnt(4)                                       // 000000A7ADD8: BF89FC47
	v_add_f32_e32 v11, 0, v11                                  // 000000A7ADDC: 06161680
	v_add_f32_e32 v43, v25, v37                                // 000000A7ADE0: 06564B19
	ds_load_2addr_b32 v[25:26], v50 offset0:160 offset1:176    // 000000A7ADE4: D8DCB0A0 19000032
	ds_load_2addr_b32 v[37:38], v48 offset0:192 offset1:208    // 000000A7ADEC: D8DCD0C0 25000030
	s_waitcnt lgkmcnt(3)                                       // 000000A7ADF4: BF89FC37
	v_add_f32_e32 v11, v11, v31                                // 000000A7ADF8: 06163F0B
	s_waitcnt lgkmcnt(2)                                       // 000000A7ADFC: BF89FC27
	v_add_f32_e32 v5, v5, v13                                  // 000000A7AE00: 060A1B05
	v_add_f32_e32 v13, 0, v10                                  // 000000A7AE04: 061A1480
	ds_load_2addr_b32 v[9:10], v4 offset0:64 offset1:80        // 000000A7AE08: D8DC5040 09000004
	v_add_f32_e32 v5, v5, v17                                  // 000000A7AE10: 060A2305
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000A7AE14: BF8701C1
	v_add_f32_e32 v17, v5, v21                                 // 000000A7AE18: 06222B05
	v_add_f32_e32 v5, v13, v40                                 // 000000A7AE1C: 060A510D
	v_add_f32_e32 v13, v15, v42                                // 000000A7AE20: 061A550F
	s_waitcnt lgkmcnt(2)                                       // 000000A7AE24: BF89FC27
	v_dual_add_f32 v40, v19, v27 :: v_dual_add_f32 v21, v17, v25// 000000A7AE28: C9083713 28143311
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A7AE30: BF870193
	v_add_f32_e32 v7, v5, v44                                  // 000000A7AE34: 060E5905
	v_add_f32_e32 v13, v13, v6                                 // 000000A7AE38: 061A0D0D
	ds_load_2addr_b32 v[5:6], v46 offset0:64 offset1:80        // 000000A7AE3C: D8DC5040 0500002E
	ds_load_2addr_b32 v[33:34], v46 offset0:192 offset1:208    // 000000A7AE44: D8DCD0C0 2100002E
	ds_load_2addr_b32 v[35:36], v51 offset0:160 offset1:176    // 000000A7AE4C: D8DCB0A0 23000033
	v_add_f32_e32 v15, v7, v8                                  // 000000A7AE54: 061E1107
	ds_load_2addr_b32 v[7:8], v47 offset0:64 offset1:80        // 000000A7AE58: D8DC5040 0700002F
	v_add_f32_e32 v17, v13, v14                                // 000000A7AE60: 06221D0D
	ds_load_2addr_b32 v[13:14], v47 offset0:192 offset1:208    // 000000A7AE64: D8DCD0C0 0D00002F
	s_waitcnt lgkmcnt(5)                                       // 000000A7AE6C: BF89FC57
	v_add_f32_e32 v9, 0, v9                                    // 000000A7AE70: 06121280
	v_add_f32_e32 v23, v15, v16                                // 000000A7AE74: 062E210F
	ds_load_2addr_b32 v[15:16], v48 offset0:64 offset1:80      // 000000A7AE78: D8DC5040 0F000030
	v_add_f32_e32 v17, v17, v18                                // 000000A7AE80: 06222511
	v_add_f32_e32 v9, v9, v29                                  // 000000A7AE84: 06123B09
	v_add_f32_e32 v23, v23, v20                                // 000000A7AE88: 062E2917
	ds_load_2addr_b32 v[19:20], v49 offset0:192 offset1:208    // 000000A7AE8C: D8DCD0C0 13000031
	v_add_f32_e32 v22, v17, v22                                // 000000A7AE94: 062C2D11
	ds_load_2addr_b32 v[17:18], v49 offset0:64 offset1:80      // 000000A7AE98: D8DC5040 11000031
	s_waitcnt lgkmcnt(7)                                       // 000000A7AEA0: BF89FC77
	v_add_f32_e32 v5, v9, v5                                   // 000000A7AEA4: 060A0B09
	s_waitcnt lgkmcnt(5)                                       // 000000A7AEA8: BF89FC57
	v_dual_add_f32 v9, v11, v33 :: v_dual_add_f32 v42, v21, v35// 000000A7AEAC: C908430B 092A4715
	v_add_f32_e32 v27, v23, v24                                // 000000A7AEB4: 06363117
	v_add_f32_e32 v33, v22, v26                                // 000000A7AEB8: 06423516
	ds_load_2addr_b32 v[21:22], v50 offset0:64 offset1:80      // 000000A7AEBC: D8DC5040 15000032
	ds_load_2addr_b32 v[23:24], v50 offset0:192 offset1:208    // 000000A7AEC4: D8DCD0C0 17000032
	s_waitcnt lgkmcnt(6)                                       // 000000A7AECC: BF89FC67
	v_add_f32_e32 v5, v5, v7                                   // 000000A7AED0: 060A0F05
	s_waitcnt lgkmcnt(5)                                       // 000000A7AED4: BF89FC57
	v_add_f32_e32 v7, v9, v13                                  // 000000A7AED8: 060E1B09
	s_waitcnt lgkmcnt(4)                                       // 000000A7AEDC: BF89FC47
	s_delay_alu instid0(VALU_DEP_2)                            // 000000A7AEE0: BF870002
	v_add_f32_e32 v13, v5, v15                                 // 000000A7AEE4: 061A1F05
	v_add_f32_e32 v5, 0, v10                                   // 000000A7AEE8: 060A1480
	ds_load_2addr_b32 v[9:10], v51 offset0:64 offset1:80       // 000000A7AEEC: D8DC5040 09000033
	ds_load_2addr_b32 v[25:26], v51 offset0:192 offset1:208    // 000000A7AEF4: D8DCD0C0 19000033
	v_add_f32_e32 v7, v7, v37                                  // 000000A7AEFC: 060E4B07
	v_add_f32_e32 v15, 0, v12                                  // 000000A7AF00: 061E1880
	ds_load_2addr_b32 v[11:12], v4 offset0:96 offset1:112      // 000000A7AF04: D8DC7060 0B000004
	v_add_f32_e32 v31, v5, v30                                 // 000000A7AF0C: 063E3D05
	ds_load_2addr_b32 v[29:30], v4 offset0:224 offset1:240     // 000000A7AF10: D8DCF0E0 1D000004
	s_waitcnt lgkmcnt(6)                                       // 000000A7AF18: BF89FC67
	v_dual_add_f32 v13, v13, v17 :: v_dual_add_f32 v4, v15, v32// 000000A7AF1C: C908230D 0D04410F
	v_add_f32_e32 v15, v7, v19                                 // 000000A7AF24: 061E2707
	v_add_f32_e32 v17, v31, v6                                 // 000000A7AF28: 06220D1F
	ds_load_2addr_b32 v[6:7], v45 offset0:96 offset1:112       // 000000A7AF2C: D8DC7060 0600002D
	ds_load_2addr_b32 v[31:32], v45 offset0:224 offset1:240    // 000000A7AF34: D8DCF0E0 1F00002D
	s_waitcnt lgkmcnt(7)                                       // 000000A7AF3C: BF89FC77
	v_dual_add_f32 v13, v13, v21 :: v_dual_add_f32 v4, v4, v34 // 000000A7AF40: C9082B0D 0D044504
	s_waitcnt lgkmcnt(6)                                       // 000000A7AF48: BF89FC67
	v_dual_add_f32 v15, v15, v23 :: v_dual_add_f32 v8, v17, v8 // 000000A7AF4C: C9082F0F 0F081111
	s_clause 0x1                                               // 000000A7AF54: BF850001
	global_load_d16_b16 v2, v1, s[6:7]                         // 000000A7AF58: DC820000 02060001
	global_load_d16_b16 v5, v1, s[6:7] offset:64               // 000000A7AF60: DC820040 05060001
	v_dual_add_f32 v4, v4, v14 :: v_dual_add_f32 v37, v27, v28 // 000000A7AF68: C9081D04 0424391B
	s_waitcnt lgkmcnt(5)                                       // 000000A7AF70: BF89FC57
	v_add_f32_e32 v23, v13, v9                                 // 000000A7AF74: 062E130D
	s_waitcnt lgkmcnt(4)                                       // 000000A7AF78: BF89FC47
	v_dual_add_f32 v25, v15, v25 :: v_dual_add_f32 v8, v8, v16 // 000000A7AF7C: C908330F 19082108
	ds_load_2addr_b32 v[13:14], v46 offset0:96 offset1:112     // 000000A7AF84: D8DC7060 0D00002E
	ds_load_2addr_b32 v[15:16], v46 offset0:224 offset1:240    // 000000A7AF8C: D8DCF0E0 0F00002E
	v_add_f32_e32 v9, v4, v38                                  // 000000A7AF94: 06124D04
	s_waitcnt lgkmcnt(5)                                       // 000000A7AF98: BF89FC57
	v_add_f32_e32 v11, 0, v11                                  // 000000A7AF9C: 06161680
	s_waitcnt lgkmcnt(4)                                       // 000000A7AFA0: BF89FC47
	v_dual_add_f32 v17, 0, v29 :: v_dual_add_f32 v38, v8, v18  // 000000A7AFA4: C9083A80 11262508
	v_add_f32_e32 v21, v33, v36                                // 000000A7AFAC: 062A4921
	v_add_f32_e32 v44, v9, v20                                 // 000000A7AFB0: 06582909
	s_waitcnt lgkmcnt(2)                                       // 000000A7AFB4: BF89FC27
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A7AFB8: BF870003
	v_dual_add_f32 v8, v11, v6 :: v_dual_add_f32 v11, v17, v31 // 000000A7AFBC: C9080D0B 080A3F11
	ds_load_2addr_b32 v[17:18], v47 offset0:96 offset1:112     // 000000A7AFC4: D8DC7060 1100002F
	ds_load_2addr_b32 v[19:20], v47 offset0:224 offset1:240    // 000000A7AFCC: D8DCF0E0 1300002F
	ds_load_2addr_b32 v[27:28], v48 offset0:96 offset1:112     // 000000A7AFD4: D8DC7060 1B000030
	ds_load_2addr_b32 v[33:34], v48 offset0:224 offset1:240    // 000000A7AFDC: D8DCF0E0 21000030
	v_add_f32_e32 v31, 0, v12                                  // 000000A7AFE4: 063E1880
	v_add_f32_e32 v35, 0, v30                                  // 000000A7AFE8: 06463C80
	s_clause 0x1                                               // 000000A7AFEC: BF850001
	global_load_d16_b16 v6, v41, s[6:7] offset:1280            // 000000A7AFF0: DC820500 06060029
	global_load_d16_b16 v4, v1, s[6:7] offset:1280             // 000000A7AFF8: DC820500 04060001
	v_or_b32_e32 v45, 0x60, v52                                // 000000A7B000: 385A68FF 00000060
	v_add_f32_e32 v7, v31, v7                                  // 000000A7B008: 060E0F1F
	s_waitcnt lgkmcnt(5)                                       // 000000A7B00C: BF89FC57
	v_add_f32_e32 v13, v8, v13                                 // 000000A7B010: 061A1B08
	global_load_d16_b16 v8, v41, s[8:9]                        // 000000A7B014: DC820000 08080029
	s_waitcnt lgkmcnt(4)                                       // 000000A7B01C: BF89FC47
	v_add_f32_e32 v15, v11, v15                                // 000000A7B020: 061E1F0B
	ds_load_2addr_b32 v[11:12], v49 offset0:96 offset1:112     // 000000A7B024: D8DC7060 0B000031
	ds_load_2addr_b32 v[29:30], v49 offset0:224 offset1:240    // 000000A7B02C: D8DCF0E0 1D000031
	v_add_f32_e32 v41, v35, v32                                // 000000A7B034: 06524123
	ds_load_2addr_b32 v[31:32], v50 offset0:96 offset1:112     // 000000A7B038: D8DC7060 1F000032
	ds_load_2addr_b32 v[35:36], v50 offset0:224 offset1:240    // 000000A7B040: D8DCF0E0 23000032
	v_add_f32_e32 v7, v7, v14                                  // 000000A7B048: 060E1D07
	global_load_d16_b16 v9, v45, s[6:7]                        // 000000A7B04C: DC820000 0906002D
	v_add_f32_e32 v41, v41, v16                                // 000000A7B054: 06522129
	s_waitcnt lgkmcnt(7)                                       // 000000A7B058: BF89FC77
	v_add_f32_e32 v17, v13, v17                                // 000000A7B05C: 0622230D
	s_waitcnt lgkmcnt(6)                                       // 000000A7B060: BF89FC67
	v_add_f32_e32 v19, v15, v19                                // 000000A7B064: 0626270F
	ds_load_2addr_b32 v[13:14], v51 offset0:96 offset1:112     // 000000A7B068: D8DC7060 0D000033
	ds_load_2addr_b32 v[15:16], v51 offset0:224 offset1:240    // 000000A7B070: D8DCF0E0 0F000033
	v_dual_add_f32 v7, v7, v18 :: v_dual_add_f32 v18, v41, v20 // 000000A7B078: C9082507 07122929
	s_waitcnt lgkmcnt(7)                                       // 000000A7B080: BF89FC77
	v_add_f32_e32 v17, v17, v27                                // 000000A7B084: 06223711
	s_waitcnt lgkmcnt(6)                                       // 000000A7B088: BF89FC67
	v_dual_add_f32 v19, v19, v33 :: v_dual_add_f32 v20, v38, v22// 000000A7B08C: C9084313 13142D26
	v_dual_add_f32 v7, v7, v28 :: v_dual_add_f32 v18, v18, v34 // 000000A7B094: C9083907 07124512
	v_add_f32_e32 v22, v44, v24                                // 000000A7B09C: 062C312C
	v_or_b32_e32 v28, 0xa0, v52                                // 000000A7B0A0: 383868FF 000000A0
	s_waitcnt lgkmcnt(5)                                       // 000000A7B0A8: BF89FC57
	v_add_f32_e32 v11, v17, v11                                // 000000A7B0AC: 06161711
	s_waitcnt lgkmcnt(4)                                       // 000000A7B0B0: BF89FC47
	v_add_f32_e32 v17, v19, v29                                // 000000A7B0B4: 06223B13
	v_dual_add_f32 v7, v7, v12 :: v_dual_add_f32 v12, v18, v30 // 000000A7B0B8: C9081907 070C3D12
	s_waitcnt lgkmcnt(3)                                       // 000000A7B0C0: BF89FC37
	v_dual_add_f32 v10, v20, v10 :: v_dual_add_f32 v11, v11, v31// 000000A7B0C4: C9081514 0A0A3F0B
	s_waitcnt lgkmcnt(2)                                       // 000000A7B0CC: BF89FC27
	v_dual_add_f32 v17, v17, v35 :: v_dual_add_f32 v18, v22, v26// 000000A7B0D0: C9084711 11123516
	v_add_f32_e32 v12, v12, v36                                // 000000A7B0D8: 0618490C
	v_add_f32_e32 v7, v7, v32                                  // 000000A7B0DC: 060E4107
	s_waitcnt lgkmcnt(1)                                       // 000000A7B0E0: BF89FC17
	v_add_f32_e32 v11, v11, v13                                // 000000A7B0E4: 06161B0B
	s_waitcnt lgkmcnt(0)                                       // 000000A7B0E8: BF89FC07
	v_add_f32_e32 v13, v17, v15                                // 000000A7B0EC: 061A1F11
	v_dual_add_f32 v19, v23, v10 :: v_dual_add_f32 v12, v12, v16// 000000A7B0F0: C9081517 130C210C
	v_sub_f32_e32 v10, v23, v10                                // 000000A7B0F8: 08141517
	v_dual_add_f32 v22, v43, v54 :: v_dual_add_f32 v23, v42, v21// 000000A7B0FC: C9086D2B 16162B2A
	v_add_f32_e32 v24, v25, v18                                // 000000A7B104: 06302519
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A7B108: BF870004
	v_add_f32_e32 v27, v13, v12                                // 000000A7B10C: 0636190D
	v_add_f32_e32 v7, v7, v14                                  // 000000A7B110: 060E1D07
	v_sub_f32_e32 v15, v39, v53                                // 000000A7B114: 081E6B27
	v_add_f32_e32 v16, v40, v37                                // 000000A7B118: 06204B28
	v_dual_sub_f32 v17, v40, v37 :: v_dual_add_f32 v30, v22, v23// 000000A7B11C: C9484B28 111E2F16
	v_add_f32_e32 v31, v24, v27                                // 000000A7B124: 063E3718
	v_dual_add_f32 v20, v11, v7 :: v_dual_and_b32 v37, 1, v0   // 000000A7B128: C9240F0B 14240081
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A7B130: BF870223
	v_add_f32_e32 v36, v15, v17                                // 000000A7B134: 0648230F
	v_sub_f32_e32 v15, v15, v17                                // 000000A7B138: 081E230F
	v_add_f32_e32 v17, v30, v31                                // 000000A7B13C: 06223F1E
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A7B140: BF870004
	.long 0xd44a0002                                           // 000000A7B144: D44A0002
	v_cndmask_b32_e32 v1, 0, v37, vcc_lo                       // 000000A7B148: 02024A80
	v_add_f32_e32 v14, v39, v53                                // 000000A7B14C: 061C6B27
	v_add_f32_e32 v39, v19, v20                                // 000000A7B150: 064E2913
	v_sub_f32_e32 v19, v19, v20                                // 000000A7B154: 08262913
	v_mov_b32_dpp v20, v17 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A7B158: 7E2802FA FF016111
	v_cndmask_b32_e64 v17, -v17, v17, s2                       // 000000A7B160: D5010011 200A2311
	v_sub_f32_e32 v37, v43, v54                                // 000000A7B168: 084A6D2B
	v_dual_sub_f32 v21, v42, v21 :: v_dual_sub_f32 v18, v25, v18// 000000A7B16C: C94A2B2A 15122519
	v_dual_sub_f32 v12, v13, v12 :: v_dual_sub_f32 v11, v11, v7// 000000A7B174: C94A190D 0C0A0F0B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A7B17C: BF8701A4
	v_add_f32_e32 v13, v17, v20                                // 000000A7B180: 061A2911
	v_and_b32_e32 v17, 2, v0                                   // 000000A7B184: 36220082
	v_dual_add_f32 v25, v37, v21 :: v_dual_add_f32 v40, v18, v12// 000000A7B188: C9082B25 19281912
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A7B190: BF870224
	v_add_f32_e32 v20, v10, v11                                // 000000A7B194: 0628170A
	v_sub_f32_e32 v10, v10, v11                                // 000000A7B198: 0814170A
	.long 0xd44a0003                                           // 000000A7B19C: D44A0003
	v_cndmask_b32_e32 v1, 0, v17, vcc_lo                       // 000000A7B1A0: 02022280
	v_sub_f32_e32 v17, v22, v23                                // 000000A7B1A4: 08222F16
	v_dual_add_f32 v11, v25, v40 :: v_dual_sub_f32 v22, v24, v27// 000000A7B1A8: C90A5119 0B163718
	v_and_b32_e32 v23, 4, v0                                   // 000000A7B1B0: 362E0084
	v_mov_b32_dpp v41, v13 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A7B1B4: 7E5202FA FF01620D
	v_cndmask_b32_e64 v13, -v13, v13, s3                       // 000000A7B1BC: D501000D 200E1B0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000A7B1C4: BF870254
	v_mov_b32_dpp v24, v11 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A7B1C8: 7E3002FA FF01610B
	v_cndmask_b32_e64 v11, -v11, v11, s2                       // 000000A7B1D0: D501000B 200A170B
	v_add_f32_e32 v27, v17, v22                                // 000000A7B1D8: 06362D11
	.long 0xd44a0004                                           // 000000A7B1DC: D44A0004
	v_cndmask_b32_e32 v1, 0, v23, vcc_lo                       // 000000A7B1E0: 02022E80
	v_dual_add_f32 v13, v13, v41 :: v_dual_and_b32 v0, 8, v0   // 000000A7B1E4: C924530D 0D000088
	v_add_f32_e32 v11, v11, v24                                // 000000A7B1EC: 0616310B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A7B1F0: BF870224
	v_mov_b32_dpp v23, v27 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A7B1F4: 7E2E02FA FF01611B
	v_cndmask_b32_e64 v24, -v27, v27, s2                       // 000000A7B1FC: D5010018 200A371B
	.long 0xd44a0001                                           // 000000A7B204: D44A0001
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 000000A7B208: 02020080
	v_sub_f32_e32 v0, v37, v21                                 // 000000A7B20C: 08002B25
	v_mov_b32_dpp v27, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A7B210: 7E3602FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s3                       // 000000A7B218: D501000B 200E170B
	v_dual_add_f32 v23, v24, v23 :: v_dual_sub_f32 v12, v18, v12// 000000A7B220: C90A2F18 170C1912
	v_mov_b32_dpp v41, v13 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A7B228: 7E5202FA FF01640D
	v_cndmask_b32_e64 v13, -v13, v13, s4                       // 000000A7B230: D501000D 20121B0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A7B238: BF870214
	v_add_f32_e32 v11, v11, v27                                // 000000A7B23C: 0616370B
	v_mov_b32_dpp v18, v23 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A7B240: 7E2402FA FF016217
	v_cndmask_b32_e64 v21, -v23, v23, s3                       // 000000A7B248: D5010015 200E2F17
	v_sub_f32_e32 v24, v25, v40                                // 000000A7B250: 08305119
	v_add_f32_e32 v13, v13, v41                                // 000000A7B254: 061A530D
	v_mov_b32_dpp v25, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A7B258: 7E3202FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s4                       // 000000A7B260: D501000B 2012170B
	v_dual_add_f32 v18, v21, v18 :: v_dual_add_f32 v21, v0, v12// 000000A7B268: C9082515 12141900
	v_sub_f32_e32 v23, v30, v31                                // 000000A7B270: 082E3F1E
	v_sub_f32_e32 v17, v17, v22                                // 000000A7B274: 08222D11
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A7B278: BF870214
	v_add_f32_e32 v11, v11, v25                                // 000000A7B27C: 0616330B
	v_mov_b32_dpp v25, v18 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A7B280: 7E3202FA FF016412
	v_cndmask_b32_e64 v18, -v18, v18, s4                       // 000000A7B288: D5010012 20122512
	v_mov_b32_dpp v30, v21 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A7B290: 7E3C02FA FF016115
	v_cndmask_b32_e64 v21, -v21, v21, s2                       // 000000A7B298: D5010015 200A2B15
	v_mov_b32_dpp v22, v13 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A7B2A0: 7E2C02FA FF01680D
	v_cndmask_b32_e64 v13, -v13, v13, s1                       // 000000A7B2A8: D501000D 20061B0D
	v_add_f32_e32 v18, v18, v25                                // 000000A7B2B0: 06243312
	v_add_f32_e32 v29, v14, v16                                // 000000A7B2B4: 063A210E
	v_dual_add_f32 v21, v21, v30 :: v_dual_sub_f32 v14, v14, v16// 000000A7B2B8: C90A3D15 150E210E
	v_or_b32_e32 v16, 0xe0, v52                                // 000000A7B2C0: 382068FF 000000E0
	v_sub_f32_e32 v0, v0, v12                                  // 000000A7B2C8: 08001900
	v_add_f32_e32 v12, v13, v22                                // 000000A7B2CC: 06182D0D
	v_mov_b32_dpp v13, v18 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A7B2D0: 7E1A02FA FF016812
	v_mov_b32_dpp v22, v21 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A7B2D8: 7E2C02FA FF016215
	v_cndmask_b32_e64 v21, -v21, v21, s3                       // 000000A7B2E0: D5010015 200E2B15
	v_cndmask_b32_e64 v18, -v18, v18, s1                       // 000000A7B2E8: D5010012 20062512
	v_mov_b32_dpp v25, v23 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A7B2F0: 7E3202FA FF016117
	v_cndmask_b32_e64 v23, -v23, v23, s2                       // 000000A7B2F8: D5010017 200A2F17
	global_load_d16_b16 v38, v16, s[6:7]                       // 000000A7B300: DC820000 26060010
	v_add_f32_e32 v21, v21, v22                                // 000000A7B308: 062A2D15
	v_add_f32_e32 v13, v18, v13                                // 000000A7B30C: 061A1B12
	global_load_d16_b16 v22, v28, s[6:7] offset:1280           // 000000A7B310: DC820500 1606001C
	v_add_f32_e32 v18, v23, v25                                // 000000A7B318: 06243317
	s_clause 0x7                                               // 000000A7B31C: BF850007
	global_load_d16_b16 v25, v16, s[6:7] offset:1280           // 000000A7B320: DC820500 19060010
	global_load_d16_b16 v26, v1, s[6:7] offset:128             // 000000A7B328: DC820080 1A060001
	global_load_d16_b16 v32, v28, s[6:7]                       // 000000A7B330: DC820000 2006001C
	global_load_d16_b16 v33, v1, s[6:7] offset:1344            // 000000A7B338: DC820540 21060001
	global_load_d16_b16 v7, v1, s[6:7] offset:1408             // 000000A7B340: DC820580 07060001
	global_load_d16_b16 v34, v1, s[6:7] offset:1472            // 000000A7B348: DC8205C0 22060001
	global_load_d16_b16 v35, v1, s[6:7] offset:192             // 000000A7B350: DC8200C0 23060001
	global_load_d16_b16 v27, v45, s[6:7] offset:1280           // 000000A7B358: DC820500 1B06002D
	v_mov_b32_dpp v23, v21 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A7B360: 7E2E02FA FF016415
	v_cndmask_b32_e64 v21, -v21, v21, s4                       // 000000A7B368: D5010015 20122B15
	s_clause 0x5                                               // 000000A7B370: BF850005
	global_load_d16_b16 v28, v28, s[8:9]                       // 000000A7B374: DC820000 1C08001C
	global_load_d16_b16 v16, v16, s[8:9]                       // 000000A7B37C: DC820000 10080010
	global_load_d16_b16 v37, v1, s[8:9]                        // 000000A7B384: DC820000 25080001
	global_load_d16_b16 v40, v1, s[8:9] offset:64              // 000000A7B38C: DC820040 28080001
	global_load_d16_b16 v41, v1, s[8:9] offset:128             // 000000A7B394: DC820080 29080001
	global_load_d16_b16 v42, v1, s[8:9] offset:192             // 000000A7B39C: DC8200C0 2A080001
	v_mov_b32_dpp v31, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A7B3A4: 7E3E02FA FF01680B
	v_add_f32_e32 v21, v21, v23                                // 000000A7B3AC: 062A2F15
	global_load_d16_b16 v23, v45, s[8:9]                       // 000000A7B3B0: DC820000 1708002D
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 000000A7B3B8: D501000B 2006170B
	v_mov_b32_dpp v30, v18 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A7B3C0: 7E3C02FA FF016212
	v_cndmask_b32_e64 v18, -v18, v18, s3                       // 000000A7B3C8: D5010012 200E2512
	v_add_f32_e32 v43, v36, v20                                // 000000A7B3D0: 06562924
	v_mov_b32_dpp v47, v24 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A7B3D4: 7E5E02FA FF016118
	v_add_f32_e32 v11, v11, v31                                // 000000A7B3DC: 06163F0B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A7B3E0: BF870214
	v_dual_add_f32 v31, v29, v39 :: v_dual_add_f32 v18, v18, v30// 000000A7B3E4: C9084F1D 1F123D12
	v_mov_b32_dpp v45, v43 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A7B3EC: 7E5A02FA FF01612B
	v_cndmask_b32_e64 v43, -v43, v43, s2                       // 000000A7B3F4: D501002B 200A572B
	v_cndmask_b32_e64 v24, -v24, v24, s2                       // 000000A7B3FC: D5010018 200A3118
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A7B404: BF870004
	v_mov_b32_dpp v30, v31 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A7B408: 7E3C02FA FF01611F
	v_cndmask_b32_e64 v31, -v31, v31, s2                       // 000000A7B410: D501001F 200A3F1F
	v_mov_b32_dpp v44, v21 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A7B418: 7E5802FA FF016815
	v_add_f32_e32 v43, v43, v45                                // 000000A7B420: 06565B2B
	v_cndmask_b32_e64 v21, -v21, v21, s1                       // 000000A7B424: D5010015 20062B15
	v_add_f32_e32 v24, v24, v47                                // 000000A7B42C: 06305F18
	v_add_f32_e32 v30, v31, v30                                // 000000A7B430: 063C3D1F
	v_mov_b32_dpp v31, v18 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A7B434: 7E3E02FA FF016412
	v_cndmask_b32_e64 v18, -v18, v18, s4                       // 000000A7B43C: D5010012 20122512
	v_add_f32_e32 v21, v21, v44                                // 000000A7B444: 062A5915
	v_mul_f32_e32 v12, 0x3db504f3, v12                         // 000000A7B448: 101818FF 3DB504F3
	v_mov_b32_dpp v46, v30 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A7B450: 7E5C02FA FF01621E
	v_cndmask_b32_e64 v30, -v30, v30, s3                       // 000000A7B458: D501001E 200E3D1E
	v_add_f32_e32 v18, v18, v31                                // 000000A7B460: 06243F12
	v_mov_b32_dpp v31, v43 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A7B464: 7E3E02FA FF01622B
	v_cndmask_b32_e64 v43, -v43, v43, s3                       // 000000A7B46C: D501002B 200E572B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A7B474: BF870234
	v_dual_sub_f32 v29, v29, v39 :: v_dual_add_f32 v30, v30, v46// 000000A7B478: C9484F1D 1D1E5D1E
	v_mov_b32_dpp v46, v24 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A7B480: 7E5C02FA FF016218
	v_cndmask_b32_e64 v24, -v24, v24, s3                       // 000000A7B488: D5010018 200E3118
	v_add_f32_e32 v31, v43, v31                                // 000000A7B490: 063E3F2B
	v_mov_b32_dpp v43, v18 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A7B494: 7E5602FA FF016812
	v_mov_b32_dpp v45, v30 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A7B49C: 7E5A02FA FF01641E
	v_cndmask_b32_e64 v30, -v30, v30, s4                       // 000000A7B4A4: D501001E 20123D1E
	v_add_f32_e32 v24, v24, v46                                // 000000A7B4AC: 06305D18
	v_mov_b32_dpp v44, v31 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A7B4B0: 7E5802FA FF01641F
	v_cndmask_b32_e64 v31, -v31, v31, s4                       // 000000A7B4B8: D501001F 20123F1F
	v_mov_b32_dpp v46, v17 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A7B4C0: 7E5C02FA FF016111
	v_add_f32_e32 v30, v30, v45                                // 000000A7B4C8: 063C5B1E
	v_cndmask_b32_e64 v17, -v17, v17, s2                       // 000000A7B4CC: D5010011 200A2311
	v_cndmask_b32_e64 v18, -v18, v18, s1                       // 000000A7B4D4: D5010012 20062512
	v_add_f32_e32 v31, v31, v44                                // 000000A7B4DC: 063E591F
	v_mov_b32_dpp v44, v24 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A7B4E0: 7E5802FA FF016418
	v_mov_b32_dpp v45, v30 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A7B4E8: 7E5A02FA FF01681E
	v_cndmask_b32_e64 v30, -v30, v30, s1                       // 000000A7B4F0: D501001E 20063D1E
	v_add_f32_e32 v17, v17, v46                                // 000000A7B4F8: 06225D11
	v_cndmask_b32_e64 v24, -v24, v24, s4                       // 000000A7B4FC: D5010018 20123118
	v_add_f32_e32 v18, v18, v43                                // 000000A7B504: 06245712
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A7B508: BF870004
	v_dual_mul_f32 v11, 0x3db504f3, v11 :: v_dual_add_f32 v30, v30, v45// 000000A7B50C: C8C816FF 0B1E5B1E 3DB504F3
	v_mov_b32_dpp v45, v31 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A7B518: 7E5A02FA FF01681F
	v_cndmask_b32_e64 v31, -v31, v31, s1                       // 000000A7B520: D501001F 20063F1F
	v_mov_b32_dpp v46, v17 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A7B528: 7E5C02FA FF016211
	v_cndmask_b32_e64 v17, -v17, v17, s3                       // 000000A7B530: D5010011 200E2311
	v_mul_f32_e32 v30, 0x3db504f3, v30                         // 000000A7B538: 103C3CFF 3DB504F3
	v_add_f32_e32 v24, v24, v44                                // 000000A7B540: 06305918
	v_dual_sub_f32 v20, v36, v20 :: v_dual_mul_f32 v13, 0x3db504f3, v13// 000000A7B544: C9462924 140C1AFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A7B550: BF8701A4
	v_add_f32_e32 v17, v17, v46                                // 000000A7B554: 06225D11
	v_dual_mul_f32 v21, 0x3db504f3, v21 :: v_dual_mul_f32 v18, 0x3db504f3, v18// 000000A7B558: C8C62AFF 151224FF 3DB504F3
	v_mov_b32_dpp v36, v20 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A7B564: 7E4802FA FF016114
	v_cndmask_b32_e64 v20, -v20, v20, s2                       // 000000A7B56C: D5010014 200A2914
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A7B574: BF8700A4
	v_mov_b32_dpp v44, v17 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A7B578: 7E5802FA FF016411
	v_cndmask_b32_e64 v17, -v17, v17, s4                       // 000000A7B580: D5010011 20122311
	v_add_f32_e32 v17, v17, v44                                // 000000A7B588: 06225911
	v_mov_b32_dpp v44, v0 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A7B58C: 7E5802FA FF016100
	v_cndmask_b32_e64 v0, -v0, v0, s2                          // 000000A7B594: D5010000 200A0100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A7B59C: BF870211
	v_add_f32_e32 v0, v0, v44                                  // 000000A7B5A0: 06005900
	v_mov_b32_dpp v44, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A7B5A4: 7E5802FA FF016811
	v_cndmask_b32_e64 v17, -v17, v17, s1                       // 000000A7B5AC: D5010011 20062311
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A7B5B4: BF870091
	v_add_f32_e32 v17, v17, v44                                // 000000A7B5B8: 06225911
	v_mul_f32_e32 v17, 0x3db504f3, v17                         // 000000A7B5BC: 102222FF 3DB504F3
	s_waitcnt vmcnt(22)                                        // 000000A7B5C4: BF895BF7
	v_fma_mix_f32 v2, v2, v30, neg(0) op_sel_hi:[1,0,0]        // 000000A7B5C8: CC200002 8A023D02
	v_add_f32_e32 v30, v31, v45                                // 000000A7B5D0: 063C5B1F
	v_mov_b32_dpp v31, v24 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A7B5D4: 7E3E02FA FF016818
	v_cndmask_b32_e64 v24, -v24, v24, s1                       // 000000A7B5DC: D5010018 20063118
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A7B5E4: BF870214
	v_mul_f32_e32 v43, 0xbfb8aa3b, v2                          // 000000A7B5E8: 105604FF BFB8AA3B
	v_mul_f32_e32 v30, 0x3db504f3, v30                         // 000000A7B5F0: 103C3CFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A7B5F8: BF870223
	v_add_f32_e32 v24, v24, v31                                // 000000A7B5FC: 06303F18
	v_add_f32_e32 v31, v14, v19                                // 000000A7B600: 063E270E
	v_exp_f32_e32 v43, v43                                     // 000000A7B604: 7E564B2B
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A7B608: BF870003
	v_fma_mix_f32 v3, v3, v30, neg(0) op_sel_hi:[1,0,0]        // 000000A7B60C: CC200003 8A023D03
	v_sub_f32_e32 v14, v14, v19                                // 000000A7B614: 081C270E
	v_mul_f32_e32 v24, 0x3db504f3, v24                         // 000000A7B618: 103030FF 3DB504F3
	v_mov_b32_dpp v45, v31 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A7B620: 7E5A02FA FF01611F
	v_cndmask_b32_e64 v31, -v31, v31, s2                       // 000000A7B628: D501001F 200A3F1F
	v_mul_f32_e32 v30, 0xbfb8aa3b, v3                          // 000000A7B630: 103C06FF BFB8AA3B
	v_mov_b32_dpp v19, v14 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A7B638: 7E2602FA FF01610E
	v_cndmask_b32_e64 v14, -v14, v14, s2                       // 000000A7B640: D501000E 200A1D0E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A7B648: BF870215
	v_add_f32_e32 v43, 1.0, v43                                // 000000A7B64C: 065656F2
	v_exp_f32_e32 v30, v30                                     // 000000A7B650: 7E3C4B1E
	v_add_f32_e32 v31, v31, v45                                // 000000A7B654: 063E5B1F
	v_mov_b32_dpp v45, v0 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A7B658: 7E5A02FA FF016200
	v_cndmask_b32_e64 v0, -v0, v0, s3                          // 000000A7B660: D5010000 200E0100
	v_div_scale_f32 v46, null, v43, v43, v2                    // 000000A7B668: D6FC7C2E 040A572B
	s_waitcnt vmcnt(19)                                        // 000000A7B670: BF894FF7
	v_fma_mix_f32 v4, v4, v12, neg(0) op_sel_hi:[1,0,0]        // 000000A7B674: CC200004 8A021904
	v_mov_b32_dpp v48, v31 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A7B67C: 7E6002FA FF01621F
	v_cndmask_b32_e64 v31, -v31, v31, s3                       // 000000A7B684: D501001F 200E3F1F
	v_add_f32_e32 v0, v0, v45                                  // 000000A7B68C: 06005B00
	v_rcp_f32_e32 v47, v46                                     // 000000A7B690: 7E5E552E
	v_add_f32_e32 v30, 1.0, v30                                // 000000A7B694: 063C3CF2
	v_fma_mix_f32 v6, v6, v11, neg(0) op_sel_hi:[1,0,0]        // 000000A7B698: CC200006 8A021706
	v_add_f32_e32 v31, v31, v48                                // 000000A7B6A0: 063E611F
	v_mov_b32_dpp v44, v0 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A7B6A4: 7E5802FA FF016400
	v_cndmask_b32_e64 v0, -v0, v0, s4                          // 000000A7B6AC: D5010000 20120100
	v_div_scale_f32 v45, null, v30, v30, v3                    // 000000A7B6B4: D6FC7C2D 040E3D1E
	v_add_f32_e32 v14, v14, v19                                // 000000A7B6BC: 061C270E
	v_mov_b32_dpp v50, v31 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A7B6C0: 7E6402FA FF01641F
	v_cndmask_b32_e64 v31, -v31, v31, s4                       // 000000A7B6C8: D501001F 20123F1F
	v_add_f32_e32 v0, v0, v44                                  // 000000A7B6D0: 06005900
	v_rcp_f32_e32 v48, v45                                     // 000000A7B6D4: 7E60552D
	v_add_f32_e32 v44, v15, v10                                // 000000A7B6D8: 0658150F
	v_fma_f32 v49, -v46, v47, 1.0                              // 000000A7B6DC: D6130031 23CA5F2E
	v_add_f32_e32 v31, v31, v50                                // 000000A7B6E4: 063E651F
	v_sub_f32_e32 v10, v15, v10                                // 000000A7B6E8: 0814150F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(TRANS32_DEP_1)// 000000A7B6EC: BF8702C4
	v_mov_b32_dpp v51, v44 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A7B6F0: 7E6602FA FF01612C
	v_cndmask_b32_e64 v44, -v44, v44, s2                       // 000000A7B6F8: D501002C 200A592C
	v_fmac_f32_e32 v47, v49, v47                               // 000000A7B700: 565E5F31
	v_div_scale_f32 v49, vcc_lo, v2, v43, v2                   // 000000A7B704: D6FC6A31 040A5702
	v_fma_f32 v50, -v45, v48, 1.0                              // 000000A7B70C: D6130032 23CA612D
	v_mov_b32_dpp v52, v31 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A7B714: 7E6802FA FF01681F
	v_cndmask_b32_e64 v31, -v31, v31, s1                       // 000000A7B71C: D501001F 20063F1F
	v_add_f32_e32 v44, v44, v51                                // 000000A7B724: 0658672C
	v_mov_b32_dpp v51, v0 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A7B728: 7E6602FA FF016800
	v_fmac_f32_e32 v48, v50, v48                               // 000000A7B730: 56606132
	v_div_scale_f32 v50, s5, v3, v30, v3                       // 000000A7B734: D6FC0532 040E3D03
	v_dual_add_f32 v31, v31, v52 :: v_dual_mul_f32 v52, v49, v47// 000000A7B73C: C906691F 1F345F31
	v_mov_b32_dpp v54, v44 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A7B744: 7E6C02FA FF01622C
	v_cndmask_b32_e64 v44, -v44, v44, s3                       // 000000A7B74C: D501002C 200E592C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A7B754: BF870214
	v_mul_f32_e32 v53, v50, v48                                // 000000A7B758: 106A6132
	v_mul_f32_e32 v31, 0x3db504f3, v31                         // 000000A7B75C: 103E3EFF 3DB504F3
	v_fma_f32 v55, -v46, v52, v49                              // 000000A7B764: D6130037 24C6692E
	v_cndmask_b32_e64 v0, -v0, v0, s1                          // 000000A7B76C: D5010000 20060100
	v_add_f32_e32 v44, v44, v54                                // 000000A7B774: 06586D2C
	v_fma_f32 v56, -v45, v53, v50                              // 000000A7B778: D6130038 24CA6B2D
	v_fma_mix_f32 v5, v5, v31, neg(0) op_sel_hi:[1,0,0]        // 000000A7B780: CC200005 8A023F05
	v_fmac_f32_e32 v52, v55, v47                               // 000000A7B788: 56685F37
	v_add_f32_e32 v0, v0, v51                                  // 000000A7B78C: 06006700
	v_mov_b32_dpp v31, v44 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A7B790: 7E3E02FA FF01642C
	v_cndmask_b32_e64 v44, -v44, v44, s4                       // 000000A7B798: D501002C 2012592C
	v_fmac_f32_e32 v53, v56, v48                               // 000000A7B7A0: 566A6138
	v_fma_f32 v46, -v46, v52, v49                              // 000000A7B7A4: D613002E 24C6692E
	v_mul_f32_e32 v51, 0xbfb8aa3b, v5                          // 000000A7B7AC: 10660AFF BFB8AA3B
	v_mov_b32_dpp v19, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A7B7B4: 7E2602FA FF01610A
	v_add_f32_e32 v31, v44, v31                                // 000000A7B7BC: 063E3F2C
	v_fma_f32 v45, -v45, v53, v50                              // 000000A7B7C0: D613002D 24CA6B2D
	v_div_fmas_f32 v44, v46, v47, v52                          // 000000A7B7C8: D637002C 04D25F2E
	s_mov_b32 vcc_lo, s5                                       // 000000A7B7D0: BEEA0005
	v_exp_f32_e32 v49, v51                                     // 000000A7B7D4: 7E624B33
	v_mov_b32_dpp v46, v31 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A7B7D8: 7E5C02FA FF01681F
	v_cndmask_b32_e64 v31, -v31, v31, s1                       // 000000A7B7E0: D501001F 20063F1F
	v_div_fmas_f32 v45, v45, v48, v53                          // 000000A7B7E8: D637002D 04D6612D
	v_div_fixup_f32 v2, v44, v43, v2                           // 000000A7B7F0: D6270002 040A572C
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 000000A7B7F8: D501000A 200A150A
	v_mul_f32_e32 v0, 0x3db504f3, v0                           // 000000A7B800: 100000FF 3DB504F3
	v_add_f32_e32 v12, v31, v46                                // 000000A7B808: 06185D1F
	v_mov_b32_dpp v31, v29 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A7B80C: 7E3E02FA FF01611D
	v_cndmask_b32_e64 v29, -v29, v29, s2                       // 000000A7B814: D501001D 200A3B1D
	v_div_fixup_f32 v3, v45, v30, v3                           // 000000A7B81C: D6270003 040E3D2D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A7B824: BF870224
	v_dual_mul_f32 v2, v4, v2 :: v_dual_mul_f32 v11, 0x3db504f3, v12// 000000A7B828: C8C60504 020A18FF 3DB504F3
	v_add_f32_e32 v10, v10, v19                                // 000000A7B834: 0614270A
	v_add_f32_e32 v4, v29, v31                                 // 000000A7B838: 06083F1D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A7B83C: BF870004
	v_mul_f32_e32 v3, v6, v3                                   // 000000A7B840: 10060706
	v_add_f32_e32 v47, 1.0, v49                                // 000000A7B844: 065E62F2
	s_waitcnt vmcnt(17)                                        // 000000A7B848: BF8947F7
	v_fma_mix_f32 v6, v9, v11, neg(0) op_sel_hi:[1,0,0]        // 000000A7B84C: CC200006 8A021709
	v_add_f32_e32 v9, v20, v36                                 // 000000A7B854: 06124914
	v_mov_b32_dpp v20, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A7B858: 7E2802FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000A7B860: D5010004 200E0904
	v_fma_mix_f32 v3, v8, v3, neg(0) op_sel_hi:[1,0,0]         // 000000A7B868: CC200003 8A020708
	v_mul_f32_e32 v8, 0xbfb8aa3b, v6                           // 000000A7B870: 10100CFF BFB8AA3B
	v_mov_b32_dpp v29, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A7B878: 7E3A02FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 000000A7B880: D5010009 200E1309
	v_add_f32_e32 v4, v4, v20                                  // 000000A7B888: 06082904
	v_div_scale_f32 v30, null, v47, v47, v5                    // 000000A7B88C: D6FC7C1E 04165F2F
	v_exp_f32_e32 v8, v8                                       // 000000A7B894: 7E104B08
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A7B898: BF870193
	v_add_f32_e32 v9, v9, v29                                  // 000000A7B89C: 06123B09
	v_mov_b32_dpp v15, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A7B8A0: 7E1E02FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s4                          // 000000A7B8A8: D5010004 20120904
	v_mov_b32_dpp v29, v14 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A7B8B0: 7E3A02FA FF01620E
	v_cndmask_b32_e64 v14, -v14, v14, s3                       // 000000A7B8B8: D501000E 200E1D0E
	v_mov_b32_dpp v20, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A7B8C0: 7E2802FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s4                          // 000000A7B8C8: D5010009 20121309
	v_add_f32_e32 v4, v4, v15                                  // 000000A7B8D0: 06081F04
	v_mov_b32_dpp v15, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A7B8D4: 7E1E02FA FF01620A
	v_add_f32_e32 v14, v14, v29                                // 000000A7B8DC: 061C3B0E
	v_cndmask_b32_e64 v10, -v10, v10, s3                       // 000000A7B8E0: D501000A 200E150A
	v_add_f32_e32 v9, v9, v20                                  // 000000A7B8E8: 06122909
	v_mov_b32_dpp v19, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A7B8EC: 7E2602FA FF016804
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000A7B8F4: D5010004 20060904
	v_mov_b32_dpp v20, v14 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A7B8FC: 7E2802FA FF01640E
	v_cndmask_b32_e64 v14, -v14, v14, s4                       // 000000A7B904: D501000E 20121D0E
	v_add_f32_e32 v10, v10, v15                                // 000000A7B90C: 06141F0A
	v_rcp_f32_e32 v12, v30                                     // 000000A7B910: 7E18551E
	v_mov_b32_dpp v15, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A7B914: 7E1E02FA FF016809
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 000000A7B91C: D5010009 20061309
	v_add_f32_e32 v4, v4, v19                                  // 000000A7B924: 06082704
	v_add_f32_e32 v14, v14, v20                                // 000000A7B928: 061C290E
	v_mov_b32_dpp v19, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A7B92C: 7E2602FA FF01640A
	v_cndmask_b32_e64 v10, -v10, v10, s4                       // 000000A7B934: D501000A 2012150A
	v_dual_add_f32 v8, 1.0, v8 :: v_dual_add_f32 v9, v9, v15   // 000000A7B93C: C90810F2 08081F09
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A7B944: BF870224
	v_mov_b32_dpp v15, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A7B948: 7E1E02FA FF01680E
	v_cndmask_b32_e64 v14, -v14, v14, s1                       // 000000A7B950: D501000E 20061D0E
	v_add_f32_e32 v10, v10, v19                                // 000000A7B958: 0614270A
	v_fma_f32 v11, -v30, v12, 1.0                              // 000000A7B95C: D613000B 23CA191E
	v_mul_f32_e32 v4, 0x3db504f3, v4                           // 000000A7B964: 100808FF 3DB504F3
	v_div_scale_f32 v19, null, v8, v8, v6                      // 000000A7B96C: D6FC7C13 041A1108
	v_add_f32_e32 v14, v14, v15                                // 000000A7B974: 061C1F0E
	v_mov_b32_dpp v15, v10 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A7B978: 7E1E02FA FF01680A
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 000000A7B980: D501000A 2006150A
	v_fmac_f32_e32 v12, v11, v12                               // 000000A7B988: 5618190B
	v_div_scale_f32 v11, vcc_lo, v5, v47, v5                   // 000000A7B98C: D6FC6A0B 04165F05
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 000000A7B994: 101212FF 3DB504F3
	v_rcp_f32_e32 v20, v19                                     // 000000A7B99C: 7E285513
	v_add_f32_e32 v10, v10, v15                                // 000000A7B9A0: 06141F0A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A7B9A4: BF8701B3
	v_dual_mul_f32 v14, 0x3db504f3, v14 :: v_dual_mul_f32 v15, v11, v12// 000000A7B9A8: C8C61CFF 0E0E190B 3DB504F3
	s_waitcnt vmcnt(12)                                        // 000000A7B9B4: BF8933F7
	v_fma_mix_f32 v9, v32, v9, neg(0) op_sel_hi:[1,0,0]        // 000000A7B9B8: CC200009 8A021320
	v_mul_f32_e32 v10, 0x3db504f3, v10                         // 000000A7B9C0: 101414FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A7B9C8: BF870003
	v_fma_f32 v31, -v30, v15, v11                              // 000000A7B9CC: D613001F 242E1F1E
	v_fma_mix_f32 v4, v26, v4, neg(0) op_sel_hi:[1,0,0]        // 000000A7B9D4: CC200004 8A02091A
	s_waitcnt vmcnt(8)                                         // 000000A7B9DC: BF8923F7
	v_fma_mix_f32 v14, v35, v14, neg(0) op_sel_hi:[1,0,0]      // 000000A7B9E0: CC20000E 8A021D23
	v_mul_f32_e32 v29, 0xbfb8aa3b, v9                          // 000000A7B9E8: 103A12FF BFB8AA3B
	v_fma_f32 v32, -v19, v20, 1.0                              // 000000A7B9F0: D6130020 23CA2913
	v_fma_mix_f32 v10, v38, v10, neg(0) op_sel_hi:[1,0,0]      // 000000A7B9F8: CC20000A 8A021526
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A7BA00: BF870214
	v_dual_mul_f32 v26, 0xbfb8aa3b, v4 :: v_dual_mul_f32 v35, 0xbfb8aa3b, v14// 000000A7BA04: C8C608FF 1A221CFF BFB8AA3B
	v_exp_f32_e32 v29, v29                                     // 000000A7BA10: 7E3A4B1D
	v_fmac_f32_e32 v15, v31, v12                               // 000000A7BA14: 561E191F
	v_fmac_f32_e32 v20, v32, v20                               // 000000A7BA18: 56282920
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A7BA1C: BF870003
	v_exp_f32_e32 v26, v26                                     // 000000A7BA20: 7E344B1A
	v_mul_f32_e32 v32, 0xbfb8aa3b, v10                         // 000000A7BA24: 104014FF BFB8AA3B
	v_exp_f32_e32 v31, v35                                     // 000000A7BA2C: 7E3E4B23
	v_fma_f32 v11, -v30, v15, v11                              // 000000A7BA30: D613000B 242E1F1E
	v_div_scale_f32 v35, s5, v6, v8, v6                        // 000000A7BA38: D6FC0523 041A1106
	v_fma_mix_f32 v13, v33, v13, neg(0) op_sel_hi:[1,0,0]      // 000000A7BA40: CC20000D 8A021B21
	v_exp_f32_e32 v30, v32                                     // 000000A7BA48: 7E3C4B20
	v_add_f32_e32 v29, 1.0, v29                                // 000000A7BA4C: 063A3AF2
	v_div_fmas_f32 v11, v11, v12, v15                          // 000000A7BA50: D637000B 043E190B
	v_mul_f32_e32 v32, v35, v20                                // 000000A7BA58: 10402923
	v_add_f32_e32 v26, 1.0, v26                                // 000000A7BA5C: 063434F2
	s_mov_b32 vcc_lo, s5                                       // 000000A7BA60: BEEA0005
	v_add_f32_e32 v31, 1.0, v31                                // 000000A7BA64: 063E3EF2
	v_div_scale_f32 v39, null, v29, v29, v9                    // 000000A7BA68: D6FC7C27 04263B1D
	v_fma_f32 v15, -v19, v32, v35                              // 000000A7BA70: D613000F 248E4113
	v_div_scale_f32 v36, null, v26, v26, v4                    // 000000A7BA78: D6FC7C24 0412351A
	v_add_f32_e32 v30, 1.0, v30                                // 000000A7BA80: 063C3CF2
	v_div_scale_f32 v12, null, v31, v31, v14                   // 000000A7BA84: D6FC7C0C 043A3F1F
	v_rcp_f32_e32 v43, v39                                     // 000000A7BA8C: 7E565527
	v_fmac_f32_e32 v32, v15, v20                               // 000000A7BA90: 5640290F
	v_rcp_f32_e32 v38, v36                                     // 000000A7BA94: 7E4C5524
	v_div_scale_f32 v33, null, v30, v30, v10                   // 000000A7BA98: D6FC7C21 042A3D1E
	v_rcp_f32_e32 v45, v12                                     // 000000A7BAA0: 7E5A550C
	v_div_fixup_f32 v5, v11, v47, v5                           // 000000A7BAA4: D6270005 04165F0B
	v_div_scale_f32 v11, s6, v4, v26, v4                       // 000000A7BAAC: D6FC060B 04123504
	v_fma_f32 v19, -v19, v32, v35                              // 000000A7BAB4: D6130013 248E4113
	v_rcp_f32_e32 v15, v33                                     // 000000A7BABC: 7E1E5521
	s_waitcnt vmcnt(7)                                         // 000000A7BAC0: BF891FF7
	v_fma_mix_f32 v21, v27, v21, neg(0) op_sel_hi:[1,0,0]      // 000000A7BAC4: CC200015 8A022B1B
	v_mul_f32_e32 v5, v13, v5                                  // 000000A7BACC: 100A0B0D
	v_fma_mix_f32 v0, v25, v0, neg(0) op_sel_hi:[1,0,0]        // 000000A7BAD0: CC200000 8A020119
	v_fma_f32 v44, -v36, v38, 1.0                              // 000000A7BAD8: D613002C 23CA4D24
	v_div_fmas_f32 v19, v19, v20, v32                          // 000000A7BAE0: D6370013 04822913
	v_fma_f32 v13, -v12, v45, 1.0                              // 000000A7BAE8: D613000D 23CA5B0C
	s_mov_b32 vcc_lo, s6                                       // 000000A7BAF0: BEEA0006
	v_fma_mix_f32 v7, v7, v18, neg(0) op_sel_hi:[1,0,0]        // 000000A7BAF4: CC200007 8A022507
	v_fmac_f32_e32 v38, v44, v38                               // 000000A7BAFC: 564C4D2C
	v_fma_f32 v44, -v39, v43, 1.0                              // 000000A7BB00: D613002C 23CA5727
	v_fma_f32 v46, -v33, v15, 1.0                              // 000000A7BB08: D613002E 23CA1F21
	v_fmac_f32_e32 v45, v13, v45                               // 000000A7BB10: 565A5B0D
	v_div_scale_f32 v13, s8, v14, v31, v14                     // 000000A7BB14: D6FC080D 043A3F0E
	v_mul_f32_e32 v35, v11, v38                                // 000000A7BB1C: 10464D0B
	v_fmac_f32_e32 v43, v44, v43                               // 000000A7BB20: 5656572C
	v_div_scale_f32 v44, s7, v9, v29, v9                       // 000000A7BB24: D6FC072C 04263B09
	v_fmac_f32_e32 v15, v46, v15                               // 000000A7BB2C: 561E1F2E
	v_div_scale_f32 v46, s5, v10, v30, v10                     // 000000A7BB30: D6FC052E 042A3D0A
	v_fma_f32 v20, -v36, v35, v11                              // 000000A7BB38: D6130014 242E4724
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A7BB40: BF8701A4
	v_dual_mul_f32 v47, v13, v45 :: v_dual_mul_f32 v32, v44, v43// 000000A7BB44: C8C65B0D 2F20572C
	v_div_fixup_f32 v6, v19, v8, v6                            // 000000A7BB4C: D6270006 041A1113
	v_dual_fmac_f32 v35, v20, v38 :: v_dual_mul_f32 v20, v46, v15// 000000A7BB54: C8064D14 23141F2E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A7BB5C: BF870213
	v_fma_f32 v8, -v39, v32, v44                               // 000000A7BB60: D6130008 24B24127
	v_fma_f32 v19, -v12, v47, v13                              // 000000A7BB68: D6130013 24365F0C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A7BB70: BF870214
	v_mul_f32_e32 v6, v21, v6                                  // 000000A7BB74: 100C0D15
	v_fma_f32 v11, -v36, v35, v11                              // 000000A7BB78: D613000B 242E4724
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A7BB80: BF870234
	v_fmac_f32_e32 v32, v8, v43                                // 000000A7BB84: 56405708
	v_fma_f32 v8, -v33, v20, v46                               // 000000A7BB88: D6130008 24BA2921
	v_fmac_f32_e32 v47, v19, v45                               // 000000A7BB90: 565E5B13
	v_div_fmas_f32 v11, v11, v38, v35                          // 000000A7BB94: D637000B 048E4D0B
	s_mov_b32 vcc_lo, s7                                       // 000000A7BB9C: BEEA0007
	v_fma_f32 v19, -v39, v32, v44                              // 000000A7BBA0: D6130013 24B24127
	v_fmac_f32_e32 v20, v8, v15                                // 000000A7BBA8: 56281F08
	v_fma_f32 v8, -v12, v47, v13                               // 000000A7BBAC: D6130008 24365F0C
	v_div_fixup_f32 v4, v11, v26, v4                           // 000000A7BBB4: D6270004 0412350B
	v_fma_mix_f32 v11, v34, v17, neg(0) op_sel_hi:[1,0,0]      // 000000A7BBBC: CC20000B 8A022322
	v_div_fmas_f32 v12, v19, v43, v32                          // 000000A7BBC4: D637000C 04825713
	v_fma_f32 v13, -v33, v20, v46                              // 000000A7BBCC: D613000D 24BA2921
	s_mov_b32 vcc_lo, s8                                       // 000000A7BBD4: BEEA0008
	s_waitcnt vmcnt(0)                                         // 000000A7BBD8: BF8903F7
	v_fma_mix_f32 v6, v23, v6, neg(0) op_sel_hi:[1,0,0]        // 000000A7BBDC: CC200006 8A020D17
	v_div_fmas_f32 v8, v8, v45, v47                            // 000000A7BBE4: D6370008 04BE5B08
	s_mov_b32 vcc_lo, s5                                       // 000000A7BBEC: BEEA0005
	v_div_fixup_f32 v9, v12, v29, v9                           // 000000A7BBF0: D6270009 04263B0C
	v_div_fmas_f32 v13, v13, v15, v20                          // 000000A7BBF8: D637000D 04521F0D
	v_fma_mix_f32 v12, v22, v24, neg(0) op_sel_hi:[1,0,0]      // 000000A7BC00: CC20000C 8A023116
	v_div_fixup_f32 v8, v8, v31, v14                           // 000000A7BC08: D6270008 043A3F08
	v_mul_f32_e32 v4, v7, v4                                   // 000000A7BC10: 10080907
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A7BC14: BF870194
	v_div_fixup_f32 v10, v13, v30, v10                         // 000000A7BC18: D627000A 042A3D0D
	v_dual_mul_f32 v9, v12, v9 :: v_dual_mul_f32 v8, v11, v8   // 000000A7BC20: C8C6130C 0908110B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A7BC28: BF870112
	v_mul_f32_e32 v0, v0, v10                                  // 000000A7BC2C: 10001500
	v_fma_mix_f32 v7, v28, v9, neg(0) op_sel_hi:[1,0,0]        // 000000A7BC30: CC200007 8A02131C
	v_fma_mix_f32 v9, v2, v37, v3 op_sel_hi:[0,1,0]            // 000000A7BC38: CC200009 140E4B02
	v_fma_mix_f32 v10, v5, v40, v6 op_sel_hi:[0,1,0]           // 000000A7BC40: CC20000A 141A5105
	v_fma_mix_f32 v2, v2, v37, -v3 op_sel_hi:[0,1,0]           // 000000A7BC48: CC200002 940E4B02
	v_fma_mix_f32 v0, v16, v0, neg(0) op_sel_hi:[1,0,0]        // 000000A7BC50: CC200000 8A020110
	v_fma_mix_f32 v11, v4, v41, v7 op_sel_hi:[0,1,0]           // 000000A7BC58: CC20000B 141E5304
	v_fma_mix_f32 v3, v5, v40, -v6 op_sel_hi:[0,1,0]           // 000000A7BC60: CC200003 941A5105
	v_fma_mix_f32 v4, v4, v41, -v7 op_sel_hi:[0,1,0]           // 000000A7BC68: CC200004 941E5304
	v_add_f32_e32 v5, v9, v10                                  // 000000A7BC70: 060A1509
	v_fma_mix_f32 v12, v8, v42, v0 op_sel_hi:[0,1,0]           // 000000A7BC74: CC20000C 14025508
	v_fma_mix_f32 v0, v8, v42, -v0 op_sel_hi:[0,1,0]           // 000000A7BC7C: CC200000 94025508
	v_dual_sub_f32 v7, v9, v10 :: v_dual_add_f32 v8, v2, v3    // 000000A7BC84: C9481509 07080702
	v_sub_f32_e32 v2, v2, v3                                   // 000000A7BC8C: 08040702
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A7BC90: BF8701B4
	v_add_f32_e32 v6, v11, v12                                 // 000000A7BC94: 060C190B
	v_sub_f32_e32 v9, v11, v12                                 // 000000A7BC98: 0812190B
	v_add_f32_e32 v10, v4, v0                                  // 000000A7BC9C: 06140104
	v_dual_sub_f32 v0, v4, v0 :: v_dual_add_f32 v3, v5, v6     // 000000A7BCA0: C9480104 00020D05
	v_sub_f32_e32 v4, v5, v6                                   // 000000A7BCA8: 08080D05
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A7BCAC: BF870003
	v_add_f32_e32 v6, v8, v10                                  // 000000A7BCB0: 060C1508
	v_sub_f32_e32 v8, v8, v10                                  // 000000A7BCB4: 08101508
	v_add_f32_e32 v10, v7, v9                                  // 000000A7BCB8: 06141307
	v_mov_b32_dpp v5, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A7BCBC: 7E0A02FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s2                          // 000000A7BCC4: D5010003 200A0703
	v_sub_f32_e32 v7, v7, v9                                   // 000000A7BCCC: 080E1307
	v_mov_b32_dpp v14, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A7BCD0: 7E1C02FA FF016104
	v_mov_b32_dpp v9, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A7BCD8: 7E1202FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 000000A7BCE0: D501000A 200A150A
	v_add_f32_e32 v3, v3, v5                                   // 000000A7BCE8: 06060B03
	v_mov_b32_dpp v5, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A7BCEC: 7E0A02FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s2                          // 000000A7BCF4: D5010006 200A0D06
	v_cndmask_b32_e64 v15, -v4, v4, s2                         // 000000A7BCFC: D501000F 200A0904
	v_add_f32_e32 v9, v10, v9                                  // 000000A7BD04: 0612130A
	v_mov_b32_dpp v11, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A7BD08: 7E1602FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 000000A7BD10: D5010003 200E0703
	v_add_f32_e32 v5, v6, v5                                   // 000000A7BD18: 060A0B06
	v_add_f32_e32 v6, v2, v0                                   // 000000A7BD1C: 060C0102
	v_sub_f32_e32 v10, v2, v0                                  // 000000A7BD20: 08140102
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A7BD24: BF870214
	v_add_f32_e32 v0, v3, v11                                  // 000000A7BD28: 06001703
	v_mov_b32_dpp v2, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A7BD2C: 7E0402FA FF016205
	v_cndmask_b32_e64 v3, -v5, v5, s3                          // 000000A7BD34: D5010003 200E0B05
	v_mov_b32_dpp v5, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A7BD3C: 7E0A02FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 000000A7BD44: D5010009 200E1309
	v_mov_b32_dpp v11, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A7BD4C: 7E1602FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s2                          // 000000A7BD54: D5010006 200A0D06
	v_add_f32_e32 v2, v3, v2                                   // 000000A7BD5C: 06040503
	v_mov_b32_dpp v16, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A7BD60: 7E2002FA FF01610A
	v_add_f32_e32 v5, v9, v5                                   // 000000A7BD68: 060A0B09
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 000000A7BD6C: D501000A 200A150A
	v_add_f32_e32 v6, v6, v11                                  // 000000A7BD74: 060C1706
	v_mov_b32_dpp v9, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A7BD78: 7E1202FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s4                          // 000000A7BD80: D5010002 20120502
	v_mov_b32_dpp v11, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A7BD88: 7E1602FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s4                          // 000000A7BD90: D5010005 20120B05
	v_mov_b32_dpp v12, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A7BD98: 7E1802FA FF016206
	v_cndmask_b32_e64 v13, -v6, v6, s3                         // 000000A7BDA0: D501000D 200E0D06
	v_add_f32_e32 v4, v2, v9                                   // 000000A7BDA8: 06081302
	v_add_f32_e32 v10, v10, v16                                // 000000A7BDAC: 0614210A
	v_dual_add_f32 v6, v5, v11 :: v_dual_add_f32 v11, v15, v14 // 000000A7BDB0: C9081705 060A1D0F
	v_mov_b32_dpp v14, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A7BDB8: 7E1C02FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 000000A7BDC0: D5010008 200A1108
	v_mov_b32_dpp v15, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A7BDC8: 7E1E02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s2                          // 000000A7BDD0: D5010007 200A0F07
	v_add_f32_e32 v9, v13, v12                                 // 000000A7BDD8: 0612190D
	v_mov_b32_dpp v13, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A7BDDC: 7E1A02FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s3                       // 000000A7BDE4: D501000B 200E170B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A7BDEC: BF870234
	v_dual_add_f32 v8, v8, v14 :: v_dual_add_f32 v7, v7, v15   // 000000A7BDF0: C9081D08 08061F07
	v_mov_b32_dpp v15, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A7BDF8: 7E1E02FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, s3                       // 000000A7BE00: D501000A 200E150A
	v_add_f32_e32 v11, v11, v13                                // 000000A7BE08: 06161B0B
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A7BE0C: BF870004
	v_mov_b32_dpp v13, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A7BE10: 7E1A02FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s3                          // 000000A7BE18: D5010008 200E1108
	v_mov_b32_dpp v14, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A7BE20: 7E1C02FA FF016207
	v_cndmask_b32_e64 v7, -v7, v7, s3                          // 000000A7BE28: D5010007 200E0F07
	v_add_f32_e32 v10, v10, v15                                // 000000A7BE30: 06141F0A
	v_mov_b32_dpp v3, v0 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A7BE34: 7E0602FA FF016400
	v_add_f32_e32 v8, v8, v13                                  // 000000A7BE3C: 06101B08
	v_cndmask_b32_e64 v0, -v0, v0, s4                          // 000000A7BE40: D5010000 20120100
	v_add_f32_e32 v7, v7, v14                                  // 000000A7BE48: 060E1D07
	v_mov_b32_dpp v12, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A7BE4C: 7E1802FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s4                          // 000000A7BE54: D5010009 20121309
	v_mov_b32_dpp v13, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A7BE5C: 7E1A02FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s4                       // 000000A7BE64: D501000B 2012170B
	v_mov_b32_dpp v14, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A7BE6C: 7E1C02FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, s4                          // 000000A7BE74: D5010008 20121108
	v_mov_b32_dpp v15, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A7BE7C: 7E1E02FA FF016407
	v_cndmask_b32_e64 v7, -v7, v7, s4                          // 000000A7BE84: D5010007 20120F07
	v_mov_b32_dpp v16, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A7BE8C: 7E2002FA FF01640A
	v_cndmask_b32_e64 v17, -v10, v10, s4                       // 000000A7BE94: D5010011 2012150A
	v_dual_add_f32 v0, v0, v3 :: v_dual_add_f32 v9, v9, v12    // 000000A7BE9C: C9080700 00081909
	v_dual_add_f32 v10, v11, v13 :: v_dual_add_f32 v11, v8, v14// 000000A7BEA4: C9081B0B 0A0A1D08
	v_add_f32_e32 v13, v7, v15                                 // 000000A7BEAC: 061A1F07
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A7BEB0: BF870214
	v_add_f32_e32 v15, v17, v16                                // 000000A7BEB4: 061E2111
	v_mov_b32_dpp v2, v0 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A7BEB8: 7E0402FA FF016800
	v_mov_b32_dpp v3, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A7BEC0: 7E0602FA FF016804
	v_mov_b32_dpp v5, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A7BEC8: 7E0A02FA FF016806
	v_mov_b32_dpp v7, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A7BED0: 7E0E02FA FF016809
	v_mov_b32_dpp v8, v10 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A7BED8: 7E1002FA FF01680A
	v_mov_b32_dpp v12, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A7BEE0: 7E1802FA FF01680B
	v_mov_b32_dpp v14, v13 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A7BEE8: 7E1C02FA FF01680D
	v_mov_b32_dpp v16, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A7BEF0: 7E2002FA FF01680F
	s_mov_b32 s2, 0x3db504f3                                   // 000000A7BEF8: BE8200FF 3DB504F3
	s_and_b32 exec_lo, exec_lo, s0                             // 000000A7BF00: 8B7E007E
	s_cbranch_execz 65                                         // 000000A7BF04: BFA50041 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi0ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x370c>
	v_cndmask_b32_e64 v15, -v15, v15, s1                       // 000000A7BF08: D501000F 20061F0F
	v_cndmask_b32_e64 v0, -v0, v0, s1                          // 000000A7BF10: D5010000 20060100
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000A7BF18: D5010004 20060904
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 000000A7BF20: D5010006 20060D06
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 000000A7BF28: D5010009 20061309
	v_cndmask_b32_e64 v13, -v13, v13, s1                       // 000000A7BF30: D501000D 20061B0D
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 000000A7BF38: D501000A 2006150A
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 000000A7BF40: D501000B 2006170B
	v_dual_add_f32 v15, v15, v16 :: v_dual_add_f32 v0, v0, v2  // 000000A7BF48: C908210F 0F000500
	v_add_f32_e32 v3, v4, v3                                   // 000000A7BF50: 06060704
	v_add_f32_e32 v5, v6, v5                                   // 000000A7BF54: 060A0B06
	v_add_f32_e32 v7, v9, v7                                   // 000000A7BF58: 060E0F09
	s_mul_i32 s0, s16, 0x500                                   // 000000A7BF5C: 9600FF10 00000500
	v_dual_add_f32 v13, v13, v14 :: v_dual_add_f32 v8, v10, v8 // 000000A7BF64: C9081D0D 0D08110A
	s_mul_hi_i32 s1, s16, 0x500                                // 000000A7BF6C: 9701FF10 00000500
	v_add_f32_e32 v11, v11, v12                                // 000000A7BF74: 0616190B
	s_add_u32 s0, s14, s0                                      // 000000A7BF78: 8000000E
	v_fma_mixlo_f16 v0, v0, s2, 0                              // 000000A7BF7C: CC210000 02000500
	s_addc_u32 s1, s15, s1                                     // 000000A7BF84: 8201010F
	v_fma_mixhi_f16 v0, v3, s2, 0                              // 000000A7BF88: CC220000 02000503
	s_add_u32 s0, s0, s10                                      // 000000A7BF90: 80000A00
	v_fma_mixlo_f16 v2, v5, s2, 0                              // 000000A7BF94: CC210002 02000505
	s_addc_u32 s1, s1, s11                                     // 000000A7BF9C: 82010B01
	v_fma_mixhi_f16 v2, v7, s2, 0                              // 000000A7BFA0: CC220002 02000507
	v_fma_mixlo_f16 v3, v8, s2, 0                              // 000000A7BFA8: CC210003 02000508
	v_fma_mixhi_f16 v3, v11, s2, 0                             // 000000A7BFB0: CC220003 0200050B
	v_fma_mixlo_f16 v4, v13, s2, 0                             // 000000A7BFB8: CC210004 0200050D
	v_fma_mixhi_f16 v4, v15, s2, 0                             // 000000A7BFC0: CC220004 0200050F
	s_clause 0x7                                               // 000000A7BFC8: BF850007
	global_store_b16 v1, v0, s[0:1]                            // 000000A7BFCC: DC660000 00000001
	global_store_d16_hi_b16 v1, v0, s[0:1] offset:32           // 000000A7BFD4: DC960020 00000001
	global_store_b16 v1, v2, s[0:1] offset:64                  // 000000A7BFDC: DC660040 00000201
	global_store_d16_hi_b16 v1, v2, s[0:1] offset:96           // 000000A7BFE4: DC960060 00000201
	global_store_b16 v1, v3, s[0:1] offset:128                 // 000000A7BFEC: DC660080 00000301
	global_store_d16_hi_b16 v1, v3, s[0:1] offset:160          // 000000A7BFF4: DC9600A0 00000301
	global_store_b16 v1, v4, s[0:1] offset:192                 // 000000A7BFFC: DC6600C0 00000401
	global_store_d16_hi_b16 v1, v4, s[0:1] offset:224          // 000000A7C004: DC9600E0 00000401
	s_endpgm                                                   // 000000A7C00C: BFB00000
		...

