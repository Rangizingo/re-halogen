000000000026e200 <_ZN7halogen12_GLOBAL__N_116k_deq_q4cp_probeILi4ELi2EEEvPKhPtjjllllNS0_5DeqCbE>:
; _ZN7halogen12_GLOBAL__N_116k_deq_q4cp_probeILi4ELi2EEEvPKhPtjjllllNS0_5DeqCbE():
	s_mov_b32 s3, exec_lo                                      // 00000026E200: BE83007E
	v_cmpx_eq_u32_e32 0, v0                                    // 00000026E204: 7D940080
	s_cbranch_execz 28                                         // 00000026E208: BFA5001C <_ZN7halogen12_GLOBAL__N_116k_deq_q4cp_probeILi4ELi2EEEvPKhPtjjllllNS0_5DeqCbE+0x7c>
	s_load_b512 s[4:19], s[0:1], 0x38                          // 00000026E20C: F4100100 F8000038
	s_waitcnt lgkmcnt(0)                                       // 00000026E214: BF89FC07
	v_dual_mov_b32 v17, 0 :: v_dual_mov_b32 v2, s5             // 00000026E218: CA100080 11020005
	v_dual_mov_b32 v1, s4 :: v_dual_mov_b32 v4, s7             // 00000026E220: CA100004 01040007
	v_dual_mov_b32 v3, s6 :: v_dual_mov_b32 v6, s9             // 00000026E228: CA100006 03060009
	v_dual_mov_b32 v5, s8 :: v_dual_mov_b32 v8, s11            // 00000026E230: CA100008 0508000B
	v_dual_mov_b32 v7, s10 :: v_dual_mov_b32 v10, s13          // 00000026E238: CA10000A 070A000D
	v_dual_mov_b32 v9, s12 :: v_dual_mov_b32 v12, s15          // 00000026E240: CA10000C 090C000F
	v_dual_mov_b32 v11, s14 :: v_dual_mov_b32 v14, s17         // 00000026E248: CA10000E 0B0E0011
	v_dual_mov_b32 v13, s16 :: v_dual_mov_b32 v16, s19         // 00000026E250: CA100010 0D100013
	v_mov_b32_e32 v15, s18                                     // 00000026E258: 7E1E0212
	ds_store_b128 v17, v[1:4]                                  // 00000026E25C: DB7C0000 00000111
	ds_store_b128 v17, v[5:8] offset:16                        // 00000026E264: DB7C0010 00000511
	ds_store_b128 v17, v[9:12] offset:32                       // 00000026E26C: DB7C0020 00000911
	ds_store_b128 v17, v[13:16] offset:48                      // 00000026E274: DB7C0030 00000D11
	s_or_b32 exec_lo, exec_lo, s3                              // 00000026E27C: 8C7E037E
	s_load_b64 s[16:17], s[0:1], 0x10                          // 00000026E280: F4040400 F8000010
	s_lshl_b32 s18, s2, 10                                     // 00000026E288: 84128A02
	s_waitcnt lgkmcnt(0)                                       // 00000026E28C: BF89FC07
	s_cmp_ge_u32 s18, s17                                      // 00000026E290: BF091112
	s_cbranch_scc1 995                                         // 00000026E294: BFA203E3 <_ZN7halogen12_GLOBAL__N_116k_deq_q4cp_probeILi4ELi2EEEvPKhPtjjllllNS0_5DeqCbE+0x1024>
	s_load_b256 s[4:11], s[0:1], 0x18                          // 00000026E298: F40C0100 F8000018
	s_cvt_f32_u32 s3, s16                                      // 00000026E2A0: BE836510
	s_clause 0x1                                               // 00000026E2A4: BF850001
	s_load_b128 s[12:15], s[0:1], null                         // 00000026E2A8: F4080300 F8000000
	s_load_b32 s1, s[0:1], 0x78                                // 00000026E2B0: F4000040 F8000078
	v_mov_b32_e32 v9, 0                                        // 00000026E2B8: 7E120280
	v_rcp_iflag_f32_e32 v1, s3                                 // 00000026E2BC: 7E025603
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 00000026E2C0: BF8704C5
	v_readfirstlane_b32 s3, v1                                 // 00000026E2C4: 7E060501
	s_mul_f32 s0, s3, 0x4f7ffffe                               // 00000026E2C8: A200FF03 4F7FFFFE
	s_waitcnt lgkmcnt(0)                                       // 00000026E2D0: BF89FC07
	s_lshr_b32 s3, s5, 31                                      // 00000026E2D4: 85039F05
	s_add_u32 s4, s4, s3                                       // 00000026E2D8: 80040304
	s_addc_u32 s5, s5, 0                                       // 00000026E2DC: 82058005
	s_cvt_u32_f32 s0, s0                                       // 00000026E2E0: BE806700
	s_ashr_i64 s[4:5], s[4:5], 1                               // 00000026E2E4: 86848104
	s_add_u32 s6, s12, s6                                      // 00000026E2E8: 8006060C
	s_addc_u32 s7, s13, s7                                     // 00000026E2EC: 8207070D
	s_add_u32 s8, s12, s8                                      // 00000026E2F0: 8008080C
	s_addc_u32 s9, s13, s9                                     // 00000026E2F4: 8209090D
	s_sub_i32 s3, 0, s16                                       // 00000026E2F8: 81831080
	s_mov_b32 s13, -1                                          // 00000026E2FC: BE8D00C1
	s_mul_i32 s3, s3, s0                                       // 00000026E300: 96030003
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000026E304: BF870009
	s_mul_hi_u32 s12, s0, s3                                   // 00000026E308: 968C0300
	s_mov_b32 s3, 0                                            // 00000026E30C: BE830080
	s_add_i32 s12, s0, s12                                     // 00000026E310: 810C0C00
	s_branch 457                                               // 00000026E314: BFA001C9 <_ZN7halogen12_GLOBAL__N_116k_deq_q4cp_probeILi4ELi2EEEvPKhPtjjllllNS0_5DeqCbE+0x83c>
	s_waitcnt vmcnt(2)                                         // 00000026E318: BF890BF7
	v_lshrrev_b32_e32 v20, 10, v6                              // 00000026E31C: 32280C8A
	v_lshrrev_b32_e32 v21, 14, v6                              // 00000026E320: 322A0C8E
	v_lshrrev_b32_e32 v22, 18, v6                              // 00000026E324: 322C0C92
	v_lshrrev_b32_e32 v23, 22, v6                              // 00000026E328: 322E0C96
	v_lshrrev_b32_e32 v15, 6, v6                               // 00000026E32C: 321E0C86
	v_and_b32_e32 v18, 15, v6                                  // 00000026E330: 36240C8F
	v_lshrrev_b32_e32 v19, 2, v6                               // 00000026E334: 32260C82
	v_lshrrev_b32_e32 v6, 26, v6                               // 00000026E338: 320C0C9A
	v_and_b32_e32 v20, 60, v20                                 // 00000026E33C: 362828BC
	v_and_b32_e32 v21, 60, v21                                 // 00000026E340: 362A2ABC
	v_and_b32_e32 v22, 60, v22                                 // 00000026E344: 362C2CBC
	v_and_b32_e32 v23, 60, v23                                 // 00000026E348: 362E2EBC
	v_and_b32_e32 v6, 60, v6                                   // 00000026E34C: 360C0CBC
	ds_load_b32 v20, v20                                       // 00000026E350: D8D80000 14000014
	ds_load_b32 v21, v21                                       // 00000026E358: D8D80000 15000015
	ds_load_b32 v22, v22                                       // 00000026E360: D8D80000 16000016
	ds_load_b32 v23, v23                                       // 00000026E368: D8D80000 17000017
	ds_load_b32 v6, v6                                         // 00000026E370: D8D80000 06000006
	v_and_b32_e32 v10, 15, v5                                  // 00000026E378: 36140A8F
	v_lshrrev_b32_e32 v11, 2, v5                               // 00000026E37C: 32160A82
	v_lshrrev_b32_e32 v12, 6, v5                               // 00000026E380: 32180A86
	v_lshrrev_b32_e32 v13, 10, v5                              // 00000026E384: 321A0A8A
	v_lshrrev_b32_e32 v14, 14, v5                              // 00000026E388: 321C0A8E
	v_lshrrev_b32_e32 v16, 18, v5                              // 00000026E38C: 32200A92
	v_lshrrev_b32_e32 v17, 22, v5                              // 00000026E390: 32220A96
	v_lshrrev_b32_e32 v5, 26, v5                               // 00000026E394: 320A0A9A
	v_and_b32_e32 v15, 60, v15                                 // 00000026E398: 361E1EBC
	v_lshlrev_b32_e32 v10, 2, v10                              // 00000026E39C: 30141482
	v_and_b32_e32 v11, 60, v11                                 // 00000026E3A0: 361616BC
	v_and_b32_e32 v12, 60, v12                                 // 00000026E3A4: 361818BC
	v_and_b32_e32 v13, 60, v13                                 // 00000026E3A8: 361A1ABC
	v_and_b32_e32 v14, 60, v14                                 // 00000026E3AC: 361C1CBC
	v_and_b32_e32 v16, 60, v16                                 // 00000026E3B0: 362020BC
	v_and_b32_e32 v17, 60, v17                                 // 00000026E3B4: 362222BC
	s_waitcnt lgkmcnt(2)                                       // 00000026E3B8: BF89FC27
	v_dual_mul_f32 v22, v2, v22 :: v_dual_and_b32 v5, 60, v5   // 00000026E3BC: C8E42D02 16040ABC
	s_waitcnt lgkmcnt(1)                                       // 00000026E3C4: BF89FC17
	v_mul_f32_e32 v23, v2, v23                                 // 00000026E3C8: 102E2F02
	s_waitcnt lgkmcnt(0)                                       // 00000026E3CC: BF89FC07
	v_mul_f32_e32 v6, v2, v6                                   // 00000026E3D0: 100C0D02
	ds_load_b32 v15, v15                                       // 00000026E3D4: D8D80000 0F00000F
	ds_load_b32 v10, v10                                       // 00000026E3DC: D8D80000 0A00000A
	ds_load_b32 v11, v11                                       // 00000026E3E4: D8D80000 0B00000B
	ds_load_b32 v12, v12                                       // 00000026E3EC: D8D80000 0C00000C
	ds_load_b32 v13, v13                                       // 00000026E3F4: D8D80000 0D00000D
	ds_load_b32 v14, v14                                       // 00000026E3FC: D8D80000 0E00000E
	ds_load_b32 v17, v17                                       // 00000026E404: D8D80000 11000011
	ds_load_b32 v16, v16                                       // 00000026E40C: D8D80000 10000010
	ds_load_b32 v5, v5                                         // 00000026E414: D8D80000 05000005
	v_mul_f32_e32 v21, v2, v21                                 // 00000026E41C: 102A2B02
	v_and_b32_e32 v19, 60, v19                                 // 00000026E420: 362626BC
	v_bfe_u32 v28, v23, 16, 1                                  // 00000026E424: D610001C 02052117
	s_add_i32 s2, s2, s1                                       // 00000026E42C: 81020102
	s_mov_b32 s13, 0                                           // 00000026E430: BE8D0080
	v_bfe_u32 v31, v21, 16, 1                                  // 00000026E434: D610001F 02052115
	s_lshl_b32 s18, s2, 10                                     // 00000026E43C: 84128A02
	v_add3_u32 v23, v23, v28, 0x7fff                           // 00000026E440: D6550017 03FE3917 00007FFF
	s_cmp_ge_u32 s18, s17                                      // 00000026E44C: BF091112
	s_delay_alu instid0(VALU_DEP_2)                            // 00000026E450: BF870002
	v_add3_u32 v21, v21, v31, 0x7fff                           // 00000026E454: D6550015 03FE3F15 00007FFF
	s_waitcnt lgkmcnt(7)                                       // 00000026E460: BF89FC77
	v_dual_mul_f32 v15, v2, v15 :: v_dual_mul_f32 v10, v1, v10 // 00000026E464: C8C61F02 0F0A1501
	s_waitcnt lgkmcnt(5)                                       // 00000026E46C: BF89FC57
	v_mul_f32_e32 v12, v1, v12                                 // 00000026E470: 10181901
	s_waitcnt lgkmcnt(4)                                       // 00000026E474: BF89FC47
	v_mul_f32_e32 v13, v1, v13                                 // 00000026E478: 101A1B01
	s_waitcnt lgkmcnt(3)                                       // 00000026E47C: BF89FC37
	v_mul_f32_e32 v14, v1, v14                                 // 00000026E480: 101C1D01
	s_waitcnt lgkmcnt(2)                                       // 00000026E484: BF89FC27
	v_mul_f32_e32 v17, v1, v17                                 // 00000026E488: 10222301
	v_bfe_u32 v25, v15, 16, 1                                  // 00000026E48C: D6100019 0205210F
	v_bfe_u32 v27, v12, 16, 1                                  // 00000026E494: D610001B 0205210C
	s_waitcnt lgkmcnt(0)                                       // 00000026E49C: BF89FC07
	v_mul_f32_e32 v5, v1, v5                                   // 00000026E4A0: 100A0B01
	v_bfe_u32 v26, v14, 16, 1                                  // 00000026E4A4: D610001A 0205210E
	v_bfe_u32 v24, v17, 16, 1                                  // 00000026E4AC: D6100018 02052111
	v_add3_u32 v15, v15, v25, 0x7fff                           // 00000026E4B4: D655000F 03FE330F 00007FFF
	v_add3_u32 v12, v12, v27, 0x7fff                           // 00000026E4C0: D655000C 03FE370C 00007FFF
	v_mul_f32_e32 v16, v1, v16                                 // 00000026E4CC: 10202101
	v_bfe_u32 v25, v13, 16, 1                                  // 00000026E4D0: D6100019 0205210D
	v_add3_u32 v17, v17, v24, 0x7fff                           // 00000026E4D8: D6550011 03FE3111 00007FFF
	.long 0x7f303880                                           // 00000026E4E4: 7F303880
	v_add3_u32 v14, v14, v26, 0x7fff                           // 00000026E4E8: D655000E 03FE350E 00007FFF
	.long 0x7e18398c                                           // 00000026E4F4: 7E18398C
	v_bfe_u32 v27, v16, 16, 1                                  // 00000026E4F8: D610001B 02052110
	.long 0x7e303991                                           // 00000026E500: 7E303991
	v_mul_f32_e32 v17, v2, v20                                 // 00000026E504: 10222902
	v_bfe_u32 v20, v5, 16, 1                                   // 00000026E508: D6100014 02052105
	.long 0x7f183998                                           // 00000026E510: 7F183998
	v_add3_u32 v13, v13, v25, 0x7fff                           // 00000026E514: D655000D 03FE330D 00007FFF
	s_waitcnt vmcnt(1)                                         // 00000026E520: BF8907F7
	v_lshrrev_b32_e32 v25, 14, v7                              // 00000026E524: 32320E8E
	v_bfe_u32 v26, v17, 16, 1                                  // 00000026E528: D610001A 02052111
	v_add3_u32 v5, v5, v20, 0x7fff                             // 00000026E530: D6550005 03FE2905 00007FFF
	v_lshrrev_b32_e32 v20, 6, v7                               // 00000026E53C: 32280E86
	.long 0x7e1c398e                                           // 00000026E540: 7E1C398E
	.long 0x7f1c3998                                           // 00000026E544: 7F1C3998
	v_add3_u32 v16, v16, v27, 0x7fff                           // 00000026E548: D6550010 03FE3710 00007FFF
	v_and_or_b32 v12, 0x7fff0000, v13, v12                     // 00000026E554: D657000C 04321AFF 7FFF0000
	v_and_b32_e32 v13, 60, v20                                 // 00000026E560: 361A28BC
	v_and_b32_e32 v20, 15, v7                                  // 00000026E564: 36280E8F
	.long 0x7e1e398f                                           // 00000026E568: 7E1E398F
	.long 0x7f1e3998                                           // 00000026E56C: 7F1E3998
	v_add3_u32 v17, v17, v26, 0x7fff                           // 00000026E570: D6550011 03FE3511 00007FFF
	v_and_b32_e32 v25, 60, v25                                 // 00000026E57C: 363232BC
	v_and_or_b32 v14, 0x3fff0000, v16, v14                     // 00000026E580: D657000E 043A20FF 3FFF0000
	v_dual_mul_f32 v1, v1, v11 :: v_dual_lshlrev_b32 v16, 2, v20// 00000026E58C: C8E21701 01102882
	v_lshrrev_b32_e32 v20, 2, v7                               // 00000026E594: 32280E82
	v_and_or_b32 v15, 0x7fff0000, v17, v15                     // 00000026E598: D657000F 043E22FF 7FFF0000
	ds_load_b32 v17, v25                                       // 00000026E5A4: D8D80000 11000019
	v_lshrrev_b32_e32 v25, 10, v7                              // 00000026E5AC: 32320E8A
	v_lshrrev_b32_e32 v26, 18, v7                              // 00000026E5B0: 32340E92
	v_lshrrev_b32_e32 v27, 22, v7                              // 00000026E5B4: 32360E96
	v_lshrrev_b32_e32 v7, 26, v7                               // 00000026E5B8: 320E0E9A
	v_and_b32_e32 v20, 60, v20                                 // 00000026E5BC: 362828BC
	v_and_b32_e32 v25, 60, v25                                 // 00000026E5C0: 363232BC
	v_and_b32_e32 v26, 60, v26                                 // 00000026E5C4: 363434BC
	v_and_b32_e32 v27, 60, v27                                 // 00000026E5C8: 363636BC
	v_and_b32_e32 v7, 60, v7                                   // 00000026E5CC: 360E0EBC
	ds_load_b32 v16, v16                                       // 00000026E5D0: D8D80000 10000010
	ds_load_b32 v20, v20                                       // 00000026E5D8: D8D80000 14000014
	ds_load_b32 v25, v25                                       // 00000026E5E0: D8D80000 19000019
	ds_load_b32 v26, v26                                       // 00000026E5E8: D8D80000 1A00001A
	ds_load_b32 v27, v27                                       // 00000026E5F0: D8D80000 1B00001B
	ds_load_b32 v7, v7                                         // 00000026E5F8: D8D80000 07000007
	ds_load_b32 v13, v13                                       // 00000026E600: D8D80000 0D00000D
	v_and_or_b32 v5, 0x1fff0000, v5, v24                       // 00000026E608: D6570005 04620AFF 1FFF0000
	.long 0x7e303997                                           // 00000026E614: 7E303997
	.long 0x7e2a3995                                           // 00000026E618: 7E2A3995
	.long 0x7f2a3998                                           // 00000026E61C: 7F2A3998
	v_bfe_u32 v34, v10, 16, 1                                  // 00000026E620: D6100022 0205210A
	s_waitcnt lgkmcnt(7)                                       // 00000026E628: BF89FC77
	v_mul_f32_e32 v17, v3, v17                                 // 00000026E62C: 10222303
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000026E630: BF870112
	v_add3_u32 v10, v10, v34, 0x7fff                           // 00000026E634: D655000A 03FE450A 00007FFF
	v_bfe_u32 v30, v17, 16, 1                                  // 00000026E640: D610001E 02052111
	s_waitcnt lgkmcnt(6)                                       // 00000026E648: BF89FC67
	v_mul_f32_e32 v16, v3, v16                                 // 00000026E64C: 10202103
	s_waitcnt lgkmcnt(4)                                       // 00000026E650: BF89FC47
	v_mul_f32_e32 v25, v3, v25                                 // 00000026E654: 10323303
	s_waitcnt lgkmcnt(3)                                       // 00000026E658: BF89FC37
	v_mul_f32_e32 v23, v3, v26                                 // 00000026E65C: 102E3503
	v_bfe_u32 v26, v22, 16, 1                                  // 00000026E660: D610001A 02052116
	v_add3_u32 v17, v17, v30, 0x7fff                           // 00000026E668: D6550011 03FE3D11 00007FFF
	v_bfe_u32 v31, v16, 16, 1                                  // 00000026E674: D610001F 02052110
	v_bfe_u32 v30, v25, 16, 1                                  // 00000026E67C: D610001E 02052119
	v_bfe_u32 v28, v23, 16, 1                                  // 00000026E684: D610001C 02052117
	v_add3_u32 v22, v22, v26, 0x7fff                           // 00000026E68C: D6550016 03FE3516 00007FFF
	s_waitcnt vmcnt(0)                                         // 00000026E698: BF8903F7
	v_and_b32_e32 v26, 15, v8                                  // 00000026E69C: 3634108F
	.long 0x7e223991                                           // 00000026E6A0: 7E223991
	.long 0x7f223998                                           // 00000026E6A4: 7F223998
	v_add3_u32 v23, v23, v28, 0x7fff                           // 00000026E6A8: D6550017 03FE3917 00007FFF
	v_and_or_b32 v21, 0x3fff0000, v22, v21                     // 00000026E6B4: D6570015 04562CFF 3FFF0000
	v_lshlrev_b32_e32 v22, 2, v26                              // 00000026E6C0: 302C3482
	v_add3_u32 v25, v25, v30, 0x7fff                           // 00000026E6C4: D6550019 03FE3D19 00007FFF
	v_lshrrev_b32_e32 v26, 10, v8                              // 00000026E6D0: 3234108A
	v_and_or_b32 v17, 0x3fff0000, v23, v17                     // 00000026E6D4: D6570011 04462EFF 3FFF0000
	v_lshrrev_b32_e32 v23, 2, v8                               // 00000026E6E0: 322E1082
	ds_load_b32 v22, v22                                       // 00000026E6E4: D8D80000 16000016
	s_waitcnt lgkmcnt(1)                                       // 00000026E6EC: BF89FC17
	v_dual_mul_f32 v13, v3, v13 :: v_dual_lshlrev_b32 v18, 2, v18// 00000026E6F0: C8E21B03 0D122482
	v_lshrrev_b32_e32 v28, 14, v8                              // 00000026E6F8: 3238108E
	ds_load_b32 v18, v18                                       // 00000026E6FC: D8D80000 12000012
	ds_load_b32 v19, v19                                       // 00000026E704: D8D80000 13000013
	v_bfe_u32 v29, v13, 16, 1                                  // 00000026E70C: D610001D 0205210D
	v_lshrrev_b32_e32 v30, 22, v8                              // 00000026E714: 323C1096
	v_and_b32_e32 v23, 60, v23                                 // 00000026E718: 362E2EBC
	v_and_b32_e32 v26, 60, v26                                 // 00000026E71C: 363434BC
	v_and_b32_e32 v28, 60, v28                                 // 00000026E720: 363838BC
	v_add3_u32 v13, v13, v29, 0x7fff                           // 00000026E724: D655000D 03FE3B0D 00007FFF
	v_bfe_u32 v29, v6, 16, 1                                   // 00000026E730: D610001D 02052106
	v_and_b32_e32 v30, 60, v30                                 // 00000026E738: 363C3CBC
	v_add3_u32 v16, v16, v31, 0x7fff                           // 00000026E73C: D6550010 03FE3F10 00007FFF
	v_lshlrev_b32_e32 v5, 3, v5                                // 00000026E748: 300A0A83
	.long 0x7e1a398d                                           // 00000026E74C: 7E1A398D
	.long 0x7f1a3998                                           // 00000026E750: 7F1A3998
	v_add3_u32 v6, v6, v29, 0x7fff                             // 00000026E754: D6550006 03FE3B06 00007FFF
	v_lshrrev_b32_e32 v29, 18, v8                              // 00000026E760: 323A1092
	s_waitcnt lgkmcnt(2)                                       // 00000026E764: BF89FC27
	v_mul_f32_e32 v22, v4, v22                                 // 00000026E768: 102C2D04
	v_mul_f32_e32 v20, v3, v20                                 // 00000026E76C: 10282903
	v_and_or_b32 v13, 0x7fff0000, v25, v13                     // 00000026E770: D657000D 043632FF 7FFF0000
	v_lshrrev_b32_e32 v25, 6, v8                               // 00000026E77C: 32321086
	v_lshrrev_b32_e32 v8, 26, v8                               // 00000026E780: 3210109A
	v_and_b32_e32 v29, 60, v29                                 // 00000026E784: 363A3ABC
	v_bfe_u32 v32, v22, 16, 1                                  // 00000026E788: D6100020 02052116
	s_waitcnt lgkmcnt(1)                                       // 00000026E790: BF89FC17
	v_dual_mul_f32 v18, v2, v18 :: v_dual_and_b32 v25, 60, v25 // 00000026E794: C8E42502 121832BC
	v_and_b32_e32 v8, 60, v8                                   // 00000026E79C: 361010BC
	ds_load_b32 v23, v23                                       // 00000026E7A0: D8D80000 17000017
	ds_load_b32 v25, v25                                       // 00000026E7A8: D8D80000 19000019
	ds_load_b32 v26, v26                                       // 00000026E7B0: D8D80000 1A00001A
	ds_load_b32 v28, v28                                       // 00000026E7B8: D8D80000 1C00001C
	ds_load_b32 v29, v29                                       // 00000026E7C0: D8D80000 1D00001D
	ds_load_b32 v30, v30                                       // 00000026E7C8: D8D80000 1E00001E
	ds_load_b32 v8, v8                                         // 00000026E7D0: D8D80000 08000008
	v_add3_u32 v22, v22, v32, 0x7fff                           // 00000026E7D8: D6550016 03FE4116 00007FFF
	s_waitcnt lgkmcnt(7)                                       // 00000026E7E4: BF89FC77
	v_mul_f32_e32 v2, v2, v19                                  // 00000026E7E8: 10042702
	v_bfe_u32 v11, v20, 16, 1                                  // 00000026E7EC: D610000B 02052114
	v_bfe_u32 v31, v1, 16, 1                                   // 00000026E7F4: D610001F 02052101
	.long 0x7e14398a                                           // 00000026E7FC: 7E14398A
	.long 0x7e203996                                           // 00000026E800: 7E203996
	.long 0x7f143998                                           // 00000026E804: 7F143998
	v_add3_u32 v11, v20, v11, 0x7fff                           // 00000026E808: D655000B 03FE1714 00007FFF
	v_add3_u32 v1, v1, v31, 0x7fff                             // 00000026E814: D6550001 03FE3F01 00007FFF
	v_lshlrev_b32_e32 v15, 1, v15                              // 00000026E820: 301E1E81
	v_and_or_b32 v6, 0x1fff0000, v6, v24                       // 00000026E824: D6570006 04620CFF 1FFF0000
	.long 0x7e303990                                           // 00000026E830: 7E303990
	v_bfe_u32 v33, v18, 16, 1                                  // 00000026E834: D6100021 02052112
	s_waitcnt lgkmcnt(6)                                       // 00000026E83C: BF89FC67
	v_mul_f32_e32 v22, v4, v23                                 // 00000026E840: 102C2F04
	v_bfe_u32 v23, v2, 16, 1                                   // 00000026E844: D6100017 02052102
	s_waitcnt lgkmcnt(5)                                       // 00000026E84C: BF89FC57
	v_mul_f32_e32 v25, v4, v25                                 // 00000026E850: 10323304
	v_and_or_b32 v1, 0xffff0000, v1, v10                       // 00000026E854: D6570001 042A02FF FFFF0000
	v_and_or_b32 v11, 0xffff0000, v11, v24                     // 00000026E860: D657000B 046216FF FFFF0000
	v_bfe_u32 v19, v22, 16, 1                                  // 00000026E86C: D6100013 02052116
	v_add3_u32 v2, v2, v23, 0x7fff                             // 00000026E874: D6550002 03FE2F02 00007FFF
	s_waitcnt lgkmcnt(1)                                       // 00000026E880: BF89FC17
	v_dual_mul_f32 v20, v4, v30 :: v_dual_mul_f32 v23, v3, v27 // 00000026E884: C8C63D04 14163703
	v_mul_f32_e32 v3, v3, v7                                   // 00000026E88C: 10060F03
	v_add3_u32 v19, v22, v19, 0x7fff                           // 00000026E890: D6550013 03FE2716 00007FFF
	v_mul_f32_e32 v22, v4, v28                                 // 00000026E89C: 102C3904
	s_delay_alu instid0(VALU_DEP_4)                            // 00000026E8A0: BF870004
	v_bfe_u32 v27, v20, 16, 1                                  // 00000026E8A4: D610001B 02052114
	v_bfe_u32 v10, v23, 16, 1                                  // 00000026E8AC: D610000A 02052117
	v_bfe_u32 v30, v25, 16, 1                                  // 00000026E8B4: D610001E 02052119
	s_waitcnt lgkmcnt(0)                                       // 00000026E8BC: BF89FC07
	v_mul_f32_e32 v8, v4, v8                                   // 00000026E8C0: 10101104
	v_bfe_u32 v28, v22, 16, 1                                  // 00000026E8C4: D610001C 02052116
	v_add3_u32 v20, v20, v27, 0x7fff                           // 00000026E8CC: D6550014 03FE3714 00007FFF
	v_add3_u32 v10, v23, v10, 0x7fff                           // 00000026E8D8: D655000A 03FE1517 00007FFF
	v_bfe_u32 v27, v3, 16, 1                                   // 00000026E8E4: D610001B 02052103
	v_add3_u32 v23, v25, v30, 0x7fff                           // 00000026E8EC: D6550017 03FE3D19 00007FFF
	v_add3_u32 v22, v22, v28, 0x7fff                           // 00000026E8F8: D6550016 03FE3916 00007FFF
	v_bfe_u32 v25, v8, 16, 1                                   // 00000026E904: D6100019 02052108
	.long 0x7e14398a                                           // 00000026E90C: 7E14398A
	.long 0x7f143998                                           // 00000026E910: 7F143998
	v_add3_u32 v3, v3, v27, 0x7fff                             // 00000026E914: D6550003 03FE3703 00007FFF
	.long 0x7e283996                                           // 00000026E920: 7E283996
	v_mul_f32_e32 v22, v4, v26                                 // 00000026E924: 102C3504
	.long 0x7e0e3997                                           // 00000026E928: 7E0E3997
	.long 0x7f0e3998                                           // 00000026E92C: 7F0E3998
	v_and_or_b32 v3, 0x1fff0000, v3, v10                       // 00000026E930: D6570003 042A06FF 1FFF0000
	v_mul_f32_e32 v4, v4, v29                                  // 00000026E93C: 10083B04
	v_bfe_u32 v23, v22, 16, 1                                  // 00000026E940: D6100017 02052116
	.long 0x7e303994                                           // 00000026E948: 7E303994
	.long 0x7f283998                                           // 00000026E94C: 7F283998
	v_lshlrev_b32_e32 v3, 3, v3                                // 00000026E950: 30060683
	v_bfe_u32 v26, v4, 16, 1                                   // 00000026E954: D610001A 02052104
	v_add3_u32 v22, v22, v23, 0x7fff                           // 00000026E95C: D6550016 03FE2F16 00007FFF
	v_add3_u32 v8, v8, v25, 0x7fff                             // 00000026E968: D6550008 03FE3308 00007FFF
	v_lshlrev_b32_e32 v13, 1, v13                              // 00000026E974: 301A1A81
	v_lshlrev_b32_e32 v17, 2, v17                              // 00000026E978: 30222282
	v_add3_u32 v4, v4, v26, 0x7fff                             // 00000026E97C: D6550004 03FE3504 00007FFF
	v_and_or_b32 v7, 0x7fff0000, v22, v7                       // 00000026E988: D6570007 041E2CFF 7FFF0000
	v_add3_u32 v18, v18, v33, 0x7fff                           // 00000026E994: D6550012 03FE4312 00007FFF
	.long 0x7f203998                                           // 00000026E9A0: 7F203998
	v_and_or_b32 v8, 0x1fff0000, v8, v24                       // 00000026E9A4: D6570008 046210FF 1FFF0000
	v_and_or_b32 v4, 0x3fff0000, v4, v20                       // 00000026E9B0: D6570004 045208FF 3FFF0000
	v_xor_b32_e32 v10, v14, v21                                // 00000026E9BC: 3A142B0E
	v_xor_b32_e32 v7, v12, v7                                  // 00000026E9C0: 3A0E0F0C
	v_lshlrev_b32_e32 v6, 3, v6                                // 00000026E9C4: 300C0C83
	.long 0x7e243992                                           // 00000026E9C8: 7E243992
	.long 0x7f243998                                           // 00000026E9CC: 7F243998
	v_and_or_b32 v16, 0xffff0000, v19, v16                     // 00000026E9D0: D6570010 044226FF FFFF0000
	v_lshlrev_b32_e32 v8, 3, v8                                // 00000026E9DC: 30101083
	v_lshlrev_b32_e32 v4, 2, v4                                // 00000026E9E0: 30080882
	v_lshlrev_b32_e32 v10, 2, v10                              // 00000026E9E4: 30141482
	v_lshlrev_b32_e32 v7, 1, v7                                // 00000026E9E8: 300E0E81
	v_xor_b32_e32 v12, v15, v17                                // 00000026E9EC: 3A18230F
	v_xor_b32_e32 v5, v5, v13                                  // 00000026E9F0: 3A0A1B05
	v_and_or_b32 v2, 0xffff0000, v2, v18                       // 00000026E9F4: D6570002 044A04FF FFFF0000
	v_xor_b32_e32 v3, v10, v3                                  // 00000026EA00: 3A06070A
	v_xor_b32_e32 v6, v7, v6                                   // 00000026EA04: 3A0C0D07
	v_xor3_b32 v7, v12, v8, v16                                // 00000026EA08: D6400007 0442110C
	v_xor3_b32 v4, v5, v4, v11                                 // 00000026EA10: D6400004 042E0905
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000026EA18: BF870112
	v_xor3_b32 v2, v6, v2, v7                                  // 00000026EA1C: D6400002 041E0506
	v_xor3_b32 v1, v3, v1, v4                                  // 00000026EA24: D6400001 04120303
	s_delay_alu instid0(VALU_DEP_1)                            // 00000026EA2C: BF870001
	v_xor3_b32 v9, v1, v2, v9                                  // 00000026EA30: D6400009 04260501
	s_cbranch_scc1 497                                         // 00000026EA38: BFA201F1 <_ZN7halogen12_GLOBAL__N_116k_deq_q4cp_probeILi4ELi2EEEvPKhPtjjllllNS0_5DeqCbE+0x1000>
	v_or_b32_e32 v13, s18, v0                                  // 00000026EA3C: 381A0012
	s_add_i32 s0, s18, 0x400                                   // 00000026EA40: 8100FF12 00000400
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000026EA48: BF8700A9
	s_cmp_gt_u32 s0, s17                                       // 00000026EA4C: BF081100
	s_mov_b32 s0, -1                                           // 00000026EA50: BE8000C1
	v_add_nc_u32_e32 v12, 0x100, v13                           // 00000026EA54: 4A181AFF 00000100
	v_add_nc_u32_e32 v11, 0x200, v13                           // 00000026EA5C: 4A161AFF 00000200
	v_add_nc_u32_e32 v10, 0x300, v13                           // 00000026EA64: 4A141AFF 00000300
	s_cbranch_scc0 5                                           // 00000026EA6C: BFA10005 <_ZN7halogen12_GLOBAL__N_116k_deq_q4cp_probeILi4ELi2EEEvPKhPtjjllllNS0_5DeqCbE+0x884>
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 00000026EA70: 916A007E
	s_cbranch_vccz 202                                         // 00000026EA74: BFA300CA <_ZN7halogen12_GLOBAL__N_116k_deq_q4cp_probeILi4ELi2EEEvPKhPtjjllllNS0_5DeqCbE+0xba0>
	s_and_not1_b32 vcc_lo, exec_lo, s13                        // 00000026EA78: 916A0D7E
	s_cbranch_vccnz 65062                                      // 00000026EA7C: BFA4FE26 <_ZN7halogen12_GLOBAL__N_116k_deq_q4cp_probeILi4ELi2EEEvPKhPtjjllllNS0_5DeqCbE+0x118>
	s_branch 474                                               // 00000026EA80: BFA001DA <_ZN7halogen12_GLOBAL__N_116k_deq_q4cp_probeILi4ELi2EEEvPKhPtjjllllNS0_5DeqCbE+0xfec>
	.long 0xd72d0001                                           // 00000026EA84: D72D0001
	v_cndmask_b32_e32 v0, v13, v12, vcc_lo                     // 00000026EA88: 0200190D
	.long 0xd72d0002                                           // 00000026EA8C: D72D0002
	v_cndmask_b32_e32 v0, v12, v12, vcc_lo                     // 00000026EA90: 0200190C
	.long 0xd72d0004                                           // 00000026EA94: D72D0004
	v_cndmask_b32_e32 v0, v11, v12, vcc_lo                     // 00000026EA98: 0200190B
	.long 0xd72d0013                                           // 00000026EA9C: D72D0013
	v_cndmask_b32_e32 v0, v10, v12, vcc_lo                     // 00000026EAA0: 0200190A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000026EAA4: BF870214
	.long 0xd72c0003                                           // 00000026EAA8: D72C0003
	v_cndmask_b32_e32 v0, v1, v16, vcc_lo                      // 00000026EAAC: 02002101
	.long 0xd72c0006                                           // 00000026EAB0: D72C0006
	v_cndmask_b32_e32 v0, v2, v16, vcc_lo                      // 00000026EAB4: 02002102
	v_add_nc_u32_e32 v7, 1, v2                                 // 00000026EAB8: 4A0E0481
	v_add_nc_u32_e32 v5, 1, v1                                 // 00000026EABC: 4A0A0281
	.long 0xd72c0008                                           // 00000026EAC0: D72C0008
	v_cndmask_b32_e32 v0, v4, v16, vcc_lo                      // 00000026EAC4: 02002104
	.long 0xd72c000f                                           // 00000026EAC8: D72C000F
	v_cndmask_b32_e32 v0, v19, v16, vcc_lo                     // 00000026EACC: 02002113
	v_sub_nc_u32_e32 v3, v13, v3                               // 00000026EAD0: 4C06070D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000026EAD4: BF870112
	v_sub_nc_u32_e32 v21, v10, v15                             // 00000026EAD8: 4C2A1F0A
	v_cmp_le_u32_e32 vcc_lo, s16, v3                           // 00000026EADC: 7C960610
	v_add_nc_u32_e32 v14, 1, v4                                // 00000026EAE0: 4A1C0881
	v_subrev_nc_u32_e32 v16, s16, v3                           // 00000026EAE4: 4E200610
	v_dual_cndmask_b32 v1, v1, v5 :: v_dual_add_nc_u32 v20, 1, v19// 00000026EAE8: CA600B01 01142681
	v_sub_nc_u32_e32 v5, v12, v6                               // 00000026EAF0: 4C0A0D0C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000026EAF4: BF8701A3
	v_cndmask_b32_e32 v3, v3, v16, vcc_lo                      // 00000026EAF8: 02062103
	v_sub_nc_u32_e32 v6, v11, v8                               // 00000026EAFC: 4C0C110B
	v_cmp_le_u32_e32 vcc_lo, s16, v5                           // 00000026EB00: 7C960A10
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000026EB04: BF8700B3
	.long 0xd44b0000                                           // 00000026EB08: D44B0000
	v_cndmask_b32_e32 v1, s16, v3, vcc_lo                      // 00000026EB0C: 02020610
	v_cndmask_b32_e32 v2, v2, v7, vcc_lo                       // 00000026EB10: 02040F02
	v_subrev_nc_u32_e32 v7, s16, v5                            // 00000026EB14: 4E0E0A10
	v_dual_cndmask_b32 v3, v5, v7 :: v_dual_add_nc_u32 v8, 1, v1// 00000026EB18: CA600F05 03080281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000026EB20: BF870231
	v_cndmask_b32_e64 v16, v1, v8, s0                          // 00000026EB24: D5010010 00021101
	.long 0xd44b0000                                           // 00000026EB2C: D44B0000
	v_cndmask_b32_e32 v1, s16, v6, vcc_lo                      // 00000026EB30: 02020C10
	v_subrev_nc_u32_e32 v1, s16, v6                            // 00000026EB34: 4E020C10
	v_cmp_le_u32_e32 vcc_lo, s16, v3                           // 00000026EB38: 7C960610
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000026EB3C: BF870214
	.long 0xd72c0005                                           // 00000026EB40: D72C0005
	v_cndmask_b32_e32 v0, v16, v16, vcc_lo                     // 00000026EB44: 02002110
	v_cndmask_b32_e64 v8, v4, v14, s0                          // 00000026EB48: D5010008 00021D04
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000026EB50: BF870114
	v_cndmask_b32_e64 v6, v6, v1, s0                           // 00000026EB54: D5010006 00020306
	v_add_nc_u32_e32 v7, 1, v8                                 // 00000026EB5C: 4A0E1081
	v_add_nc_u32_e32 v4, 1, v2                                 // 00000026EB60: 4A080481
	v_sub_nc_u32_e32 v17, v13, v5                              // 00000026EB64: 4C220B0D
	s_delay_alu instid0(VALU_DEP_2)                            // 00000026EB68: BF870002
	v_cndmask_b32_e32 v22, v2, v4, vcc_lo                      // 00000026EB6C: 022C0902
	v_mad_u64_u32 v[1:2], null, s4, v16, s[6:7]                // 00000026EB70: D6FE7C01 001A2004
	v_mad_u64_u32 v[3:4], null, s10, v16, s[8:9]               // 00000026EB78: D6FE7C03 0022200A
	v_cmp_le_u32_e32 vcc_lo, s16, v6                           // 00000026EB80: 7C960C10
	v_lshlrev_b32_e32 v23, 2, v17                              // 00000026EB84: 302E2282
	v_mad_u64_u32 v[5:6], null, s4, v22, s[6:7]                // 00000026EB88: D6FE7C05 001A2C04
	.long 0xd72c0012                                           // 00000026EB90: D72C0012
	v_cndmask_b32_e32 v0, v22, v16, vcc_lo                     // 00000026EB94: 02002116
	v_cndmask_b32_e32 v25, v8, v7, vcc_lo                      // 00000026EB98: 02320F08
	v_mad_u64_u32 v[7:8], null, s10, v22, s[8:9]               // 00000026EB9C: D6FE7C07 00222C0A
	v_mad_u64_u32 v[14:15], null, s5, v16, v[2:3]              // 00000026EBA4: D6FE7C0E 040A2005
	v_lshrrev_b32_e32 v2, 1, v17                               // 00000026EBAC: 32042281
	v_mad_u64_u32 v[15:16], null, s11, v16, v[4:5]             // 00000026EBB0: D6FE7C0F 0412200B
	v_and_b32_e32 v4, 0x7ffffffc, v23                          // 00000026EBB8: 36082EFF 7FFFFFFC
	v_sub_nc_u32_e32 v23, v12, v18                             // 00000026EBC0: 4C2E250C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000026EBC4: BF8700C4
	v_and_b32_e32 v2, 0xffffffe, v2                            // 00000026EBC8: 360404FF 0FFFFFFE
	v_mad_u64_u32 v[16:17], null, s5, v22, v[6:7]              // 00000026EBD0: D6FE7C10 041A2C05
	v_subrev_nc_u32_e32 v6, s16, v21                           // 00000026EBD8: 4E0C2A10
	.long 0xd7006a11                                           // 00000026EBDC: D7006A11
	v_cndmask_b32_e32 v1, v1, v4, vcc_lo                       // 00000026EBE0: 02020901
	v_add_co_ci_u32_e64 v18, null, 0, v14, vcc_lo              // 00000026EBE4: D5207C12 01AA1C80
	.long 0xd7006a0e                                           // 00000026EBEC: D7006A0E
	v_cndmask_b32_e32 v1, v3, v2, vcc_lo                       // 00000026EBF0: 02020503
	s_delay_alu instid0(VALU_DEP_1)                            // 00000026EBF4: BF870001
	v_add_co_ci_u32_e64 v15, null, 0, v15, vcc_lo              // 00000026EBF8: D5207C0F 01AA1E80
	v_cmp_le_u32_e32 vcc_lo, s16, v21                          // 00000026EC00: 7C962A10
	v_mad_u64_u32 v[3:4], null, s11, v22, v[8:9]               // 00000026EC04: D6FE7C03 04222C0B
	.long 0xd72c0002                                           // 00000026EC0C: D72C0002
	v_cndmask_b32_e32 v0, v25, v16, vcc_lo                     // 00000026EC10: 02002119
	v_lshlrev_b32_e32 v1, 2, v23                               // 00000026EC14: 30022E82
	v_dual_cndmask_b32 v19, v19, v20 :: v_dual_cndmask_b32 v4, v21, v6// 00000026EC18: CA522913 13040D15
	v_lshrrev_b32_e32 v20, 1, v23                              // 00000026EC20: 32282E81
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000026EC24: BF870193
	v_and_b32_e32 v23, 0x7ffffffc, v1                          // 00000026EC28: 362E02FF 7FFFFFFC
	v_add_nc_u32_e32 v6, 1, v19                                // 00000026EC30: 4A0C2681
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000026EC34: BF8701C4
	v_cmp_le_u32_e32 vcc_lo, s16, v4                           // 00000026EC38: 7C960810
	v_sub_nc_u32_e32 v24, v11, v2                              // 00000026EC3C: 4C30050B
	v_and_b32_e32 v8, 0xffffffe, v20                           // 00000026EC40: 361028FF 0FFFFFFE
	v_mad_u64_u32 v[1:2], null, s4, v25, s[6:7]                // 00000026EC48: D6FE7C01 001A3204
	v_dual_cndmask_b32 v29, v19, v6 :: v_dual_lshlrev_b32 v4, 2, v24// 00000026EC50: CA620D13 1D043082
	.long 0xd7006a13                                           // 00000026EC58: D7006A13
	v_cndmask_b32_e32 v1, v5, v23, vcc_lo                      // 00000026EC5C: 02022F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000026EC60: BF870191
	v_add_co_ci_u32_e64 v20, null, 0, v16, vcc_lo              // 00000026EC64: D5207C14 01AA2080
	.long 0xd72c0005                                           // 00000026EC6C: D72C0005
	v_cndmask_b32_e32 v0, v29, v16, vcc_lo                     // 00000026EC70: 0200211D
	.long 0xd7006a15                                           // 00000026EC74: D7006A15
	v_cndmask_b32_e32 v1, v7, v8, vcc_lo                       // 00000026EC78: 02021107
	v_mad_u64_u32 v[6:7], null, s5, v25, v[2:3]                // 00000026EC7C: D6FE7C06 040A3205
	v_and_b32_e32 v7, 0x7ffffffc, v4                           // 00000026EC84: 360E08FF 7FFFFFFC
	v_add_co_ci_u32_e64 v22, null, 0, v3, vcc_lo               // 00000026EC8C: D5207C16 01AA0680
	v_mad_u64_u32 v[2:3], null, s10, v25, s[8:9]               // 00000026EC94: D6FE7C02 0022320A
	v_sub_nc_u32_e32 v16, v10, v5                              // 00000026EC9C: 4C200B0A
	v_mad_u64_u32 v[4:5], null, s10, v29, s[8:9]               // 00000026ECA0: D6FE7C04 00223A0A
	.long 0xd7006a17                                           // 00000026ECA8: D7006A17
	v_cndmask_b32_e32 v1, v1, v7, vcc_lo                       // 00000026ECAC: 02020F01
	v_lshrrev_b32_e32 v8, 1, v24                               // 00000026ECB0: 32103081
	v_add_co_ci_u32_e64 v24, null, 0, v6, vcc_lo               // 00000026ECB4: D5207C18 01AA0C80
	v_mad_u64_u32 v[6:7], null, s4, v29, s[6:7]                // 00000026ECBC: D6FE7C06 001A3A04
	v_lshrrev_b32_e32 v1, 1, v16                               // 00000026ECC4: 32022081
	v_mad_u64_u32 v[25:26], null, s11, v25, v[3:4]             // 00000026ECC8: D6FE7C19 040E320B
	v_and_b32_e32 v3, 0xffffffe, v8                            // 00000026ECD0: 360610FF 0FFFFFFE
	v_lshlrev_b32_e32 v8, 2, v16                               // 00000026ECD8: 30102082
	v_mad_u64_u32 v[26:27], null, s11, v29, v[5:6]             // 00000026ECDC: D6FE7C1A 04163A0B
	v_and_b32_e32 v5, 0xffffffe, v1                            // 00000026ECE4: 360A02FF 0FFFFFFE
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000026ECEC: BF870214
	.long 0xd7006a1b                                           // 00000026ECF0: D7006A1B
	v_cndmask_b32_e32 v1, v2, v3, vcc_lo                       // 00000026ECF4: 02020702
	v_mad_u64_u32 v[1:2], null, s5, v29, v[7:8]                // 00000026ECF8: D6FE7C01 041E3A05
	v_and_b32_e32 v2, 0x7ffffffc, v8                           // 00000026ED00: 360410FF 7FFFFFFC
	v_add_co_ci_u32_e64 v28, null, 0, v25, vcc_lo              // 00000026ED08: D5207C1C 01AA3280
	.long 0xd7006a04                                           // 00000026ED10: D7006A04
	v_cndmask_b32_e32 v1, v4, v5, vcc_lo                       // 00000026ED14: 02020B04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000026ED18: BF870211
	v_add_co_ci_u32_e64 v5, null, 0, v26, vcc_lo               // 00000026ED1C: D5207C05 01AA3480
	.long 0xd7006a19                                           // 00000026ED24: D7006A19
	v_cndmask_b32_e32 v1, v6, v2, vcc_lo                       // 00000026ED28: 02020506
	s_delay_alu instid0(VALU_DEP_1)                            // 00000026ED2C: BF870001
	v_add_co_ci_u32_e64 v26, null, 0, v1, vcc_lo               // 00000026ED30: D5207C1A 01AA0280
	s_clause 0x7                                               // 00000026ED38: BF850007
	global_load_d16_b16 v1, v[14:15], off                      // 00000026ED3C: DC820000 017C000E
	global_load_d16_b16 v2, v[21:22], off                      // 00000026ED44: DC820000 027C0015
	global_load_d16_b16 v3, v[27:28], off                      // 00000026ED4C: DC820000 037C001B
	global_load_d16_b16 v4, v[4:5], off                        // 00000026ED54: DC820000 047C0004
	global_load_b32 v5, v[17:18], off                          // 00000026ED5C: DC520000 057C0011
	global_load_b32 v6, v[19:20], off                          // 00000026ED64: DC520000 067C0013
	global_load_b32 v7, v[23:24], off                          // 00000026ED6C: DC520000 077C0017
	global_load_b32 v8, v[25:26], off                          // 00000026ED74: DC520000 087C0019
	s_waitcnt vmcnt(7)                                         // 00000026ED7C: BF891FF7
	v_cvt_f32_f16_e32 v1, v1                                   // 00000026ED80: 7E021701
	s_waitcnt vmcnt(6)                                         // 00000026ED84: BF891BF7
	v_cvt_f32_f16_e32 v2, v2                                   // 00000026ED88: 7E041702
	s_waitcnt vmcnt(5)                                         // 00000026ED8C: BF8917F7
	v_cvt_f32_f16_e32 v3, v3                                   // 00000026ED90: 7E061703
	s_waitcnt vmcnt(4)                                         // 00000026ED94: BF8913F7
	v_cvt_f32_f16_e32 v4, v4                                   // 00000026ED98: 7E081704
	s_cbranch_execnz 65334                                     // 00000026ED9C: BFA6FF36 <_ZN7halogen12_GLOBAL__N_116k_deq_q4cp_probeILi4ELi2EEEvPKhPtjjllllNS0_5DeqCbE+0x878>
	s_mov_b32 s0, exec_lo                                      // 00000026EDA0: BE80007E
	.long 0xd4cb007e                                           // 00000026EDA4: D4CB007E
	v_cndmask_b32_e32 v1, s17, v13, vcc_lo                     // 00000026EDA8: 02021A11
	s_xor_b32 s0, exec_lo, s0                                  // 00000026EDAC: 8D00007E
	s_cbranch_execz 2                                          // 00000026EDB0: BFA50002 <_ZN7halogen12_GLOBAL__N_116k_deq_q4cp_probeILi4ELi2EEEvPKhPtjjllllNS0_5DeqCbE+0xbbc>
	s_waitcnt vmcnt(1)                                         // 00000026EDB4: BF8907F7
	v_mov_b32_e32 v5, s3                                       // 00000026EDB8: 7E0A0203
	s_or_saveexec_b32 s0, s0                                   // 00000026EDBC: BE802200
	v_mov_b32_e32 v1, 0                                        // 00000026EDC0: 7E020280
	s_xor_b32 exec_lo, exec_lo, s0                             // 00000026EDC4: 8D7E007E
	s_cbranch_execz 56                                         // 00000026EDC8: BFA50038 <_ZN7halogen12_GLOBAL__N_116k_deq_q4cp_probeILi4ELi2EEEvPKhPtjjllllNS0_5DeqCbE+0xcac>
	.long 0xd72d0001                                           // 00000026EDCC: D72D0001
	v_cndmask_b32_e32 v0, v13, v12, vcc_lo                     // 00000026EDD0: 0200190D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000026EDD4: BF870091
	.long 0xd72c0002                                           // 00000026EDD8: D72C0002
	v_cndmask_b32_e32 v0, v1, v16, vcc_lo                      // 00000026EDDC: 02002101
	v_sub_nc_u32_e32 v2, v13, v2                               // 00000026EDE0: 4C04050D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000026EDE4: BF870121
	v_subrev_nc_u32_e32 v4, s16, v2                            // 00000026EDE8: 4E080410
	v_cmp_le_u32_e32 vcc_lo, s16, v2                           // 00000026EDEC: 7C960410
	v_dual_cndmask_b32 v2, v2, v4 :: v_dual_add_nc_u32 v3, 1, v1// 00000026EDF0: CA600902 02020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000026EDF8: BF870111
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 00000026EDFC: 02020701
	v_cmp_le_u32_e32 vcc_lo, s16, v2                           // 00000026EE00: 7C960410
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000026EE04: BF8700A2
	v_add_nc_u32_e32 v3, 1, v1                                 // 00000026EE08: 4A060281
	s_waitcnt vmcnt(1)                                         // 00000026EE0C: BF8907F7
	v_cndmask_b32_e32 v7, v1, v3, vcc_lo                       // 00000026EE10: 020E0701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000026EE14: BF870121
	.long 0xd72c0001                                           // 00000026EE18: D72C0001
	v_cndmask_b32_e32 v0, v7, v16, vcc_lo                      // 00000026EE1C: 02002107
	v_mad_u64_u32 v[3:4], null, s4, v7, s[6:7]                 // 00000026EE20: D6FE7C03 001A0E04
	v_sub_nc_u32_e32 v5, v13, v1                               // 00000026EE28: 4C0A030D
	v_mad_u64_u32 v[1:2], null, s10, v7, s[8:9]                // 00000026EE2C: D6FE7C01 00220E0A
	s_waitcnt vmcnt(0)                                         // 00000026EE34: BF8903F7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000026EE38: BF8701A2
	v_lshrrev_b32_e32 v8, 1, v5                                // 00000026EE3C: 32100A81
	v_lshlrev_b32_e32 v13, 2, v5                               // 00000026EE40: 301A0A82
	v_mad_u64_u32 v[5:6], null, s11, v7, v[2:3]                // 00000026EE44: D6FE7C05 040A0E0B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000026EE4C: BF870093
	v_and_b32_e32 v2, 0xffffffe, v8                            // 00000026EE50: 360410FF 0FFFFFFE
	.long 0xd7006a01                                           // 00000026EE58: D7006A01
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 00000026EE5C: 02020501
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000026EE60: BF870133
	v_mad_u64_u32 v[6:7], null, s5, v7, v[4:5]                 // 00000026EE64: D6FE7C06 04120E05
	v_and_b32_e32 v4, 0x7ffffffc, v13                          // 00000026EE6C: 36081AFF 7FFFFFFC
	v_add_co_ci_u32_e64 v2, null, 0, v5, vcc_lo                // 00000026EE74: D5207C02 01AA0A80
	.long 0xd7006a03                                           // 00000026EE7C: D7006A03
	v_cndmask_b32_e32 v1, v3, v4, vcc_lo                       // 00000026EE80: 02020903
	s_delay_alu instid0(VALU_DEP_1)                            // 00000026EE84: BF870001
	v_add_co_ci_u32_e64 v4, null, 0, v6, vcc_lo                // 00000026EE88: D5207C04 01AA0C80
	s_clause 0x1                                               // 00000026EE90: BF850001
	global_load_d16_b16 v1, v[1:2], off                        // 00000026EE94: DC820000 017C0001
	global_load_b32 v5, v[3:4], off                            // 00000026EE9C: DC520000 057C0003
	s_waitcnt vmcnt(1)                                         // 00000026EEA4: BF8907F7
	v_cvt_f32_f16_e32 v1, v1                                   // 00000026EEA8: 7E021701
	s_or_b32 exec_lo, exec_lo, s0                              // 00000026EEAC: 8C7E007E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000026EEB0: BF870009
	s_mov_b32 s0, exec_lo                                      // 00000026EEB4: BE80007E
	.long 0xd4cb007e                                           // 00000026EEB8: D4CB007E
	v_cndmask_b32_e32 v1, s17, v12, vcc_lo                     // 00000026EEBC: 02021811
	s_xor_b32 s0, exec_lo, s0                                  // 00000026EEC0: 8D00007E
	s_cbranch_execz 2                                          // 00000026EEC4: BFA50002 <_ZN7halogen12_GLOBAL__N_116k_deq_q4cp_probeILi4ELi2EEEvPKhPtjjllllNS0_5DeqCbE+0xcd0>
	s_waitcnt vmcnt(2)                                         // 00000026EEC8: BF890BF7
	v_mov_b32_e32 v6, s3                                       // 00000026EECC: 7E0C0203
	s_or_saveexec_b32 s0, s0                                   // 00000026EED0: BE802200
	v_mov_b32_e32 v2, 0                                        // 00000026EED4: 7E040280
	s_xor_b32 exec_lo, exec_lo, s0                             // 00000026EED8: 8D7E007E
	s_cbranch_execz 56                                         // 00000026EEDC: BFA50038 <_ZN7halogen12_GLOBAL__N_116k_deq_q4cp_probeILi4ELi2EEEvPKhPtjjllllNS0_5DeqCbE+0xdc0>
	.long 0xd72d0002                                           // 00000026EEE0: D72D0002
	v_cndmask_b32_e32 v0, v12, v12, vcc_lo                     // 00000026EEE4: 0200190C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000026EEE8: BF870121
	.long 0xd72c0003                                           // 00000026EEEC: D72C0003
	v_cndmask_b32_e32 v0, v2, v16, vcc_lo                      // 00000026EEF0: 02002102
	v_add_nc_u32_e32 v4, 1, v2                                 // 00000026EEF4: 4A080481
	v_sub_nc_u32_e32 v3, v12, v3                               // 00000026EEF8: 4C06070C
	s_waitcnt vmcnt(2)                                         // 00000026EEFC: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000026EF00: BF870121
	v_subrev_nc_u32_e32 v6, s16, v3                            // 00000026EF04: 4E0C0610
	v_cmp_le_u32_e32 vcc_lo, s16, v3                           // 00000026EF08: 7C960610
	v_dual_cndmask_b32 v2, v2, v4 :: v_dual_cndmask_b32 v3, v3, v6// 00000026EF0C: CA520902 02020D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000026EF14: BF870111
	v_add_nc_u32_e32 v4, 1, v2                                 // 00000026EF18: 4A080481
	v_cmp_le_u32_e32 vcc_lo, s16, v3                           // 00000026EF1C: 7C960610
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000026EF20: BF870092
	v_cndmask_b32_e32 v6, v2, v4, vcc_lo                       // 00000026EF24: 020C0902
	.long 0xd72c0002                                           // 00000026EF28: D72C0002
	v_cndmask_b32_e32 v0, v6, v16, vcc_lo                      // 00000026EF2C: 02002106
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000026EF30: BF8701C1
	v_sub_nc_u32_e32 v4, v12, v2                               // 00000026EF34: 4C08050C
	v_mad_u64_u32 v[2:3], null, s10, v6, s[8:9]                // 00000026EF38: D6FE7C02 00220C0A
	v_mad_u64_u32 v[12:13], null, s4, v6, s[6:7]               // 00000026EF40: D6FE7C0C 001A0C04
	s_waitcnt vmcnt(0)                                         // 00000026EF48: BF8903F7
	v_lshrrev_b32_e32 v8, 1, v4                                // 00000026EF4C: 32100881
	v_lshlrev_b32_e32 v15, 2, v4                               // 00000026EF50: 301E0882
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000026EF54: BF870194
	v_mad_u64_u32 v[3:4], null, s11, v6, v[3:4]                // 00000026EF58: D6FE7C03 040E0C0B
	v_and_b32_e32 v4, 0xffffffe, v8                            // 00000026EF60: 360810FF 0FFFFFFE
	v_mad_u64_u32 v[13:14], null, s5, v6, v[13:14]             // 00000026EF68: D6FE7C0D 04360C05
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000026EF70: BF870194
	v_and_b32_e32 v6, 0x7ffffffc, v15                          // 00000026EF74: 360C1EFF 7FFFFFFC
	.long 0xd7006a02                                           // 00000026EF7C: D7006A02
	v_cndmask_b32_e32 v1, v2, v4, vcc_lo                       // 00000026EF80: 02020902
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000026EF84: BF870191
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 00000026EF88: D5207C03 01AA0680
	.long 0xd7006a0c                                           // 00000026EF90: D7006A0C
	v_cndmask_b32_e32 v1, v12, v6, vcc_lo                      // 00000026EF94: 02020D0C
	s_delay_alu instid0(VALU_DEP_1)                            // 00000026EF98: BF870001
	v_add_co_ci_u32_e64 v13, null, 0, v13, vcc_lo              // 00000026EF9C: D5207C0D 01AA1A80
	s_clause 0x1                                               // 00000026EFA4: BF850001
	global_load_d16_b16 v2, v[2:3], off                        // 00000026EFA8: DC820000 027C0002
	global_load_b32 v6, v[12:13], off                          // 00000026EFB0: DC520000 067C000C
	s_waitcnt vmcnt(1)                                         // 00000026EFB8: BF8907F7
	v_cvt_f32_f16_e32 v2, v2                                   // 00000026EFBC: 7E041702
	s_or_b32 exec_lo, exec_lo, s0                              // 00000026EFC0: 8C7E007E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000026EFC4: BF870009
	s_mov_b32 s0, exec_lo                                      // 00000026EFC8: BE80007E
	.long 0xd4cb007e                                           // 00000026EFCC: D4CB007E
	v_cndmask_b32_e32 v1, s17, v11, vcc_lo                     // 00000026EFD0: 02021611
	s_xor_b32 s0, exec_lo, s0                                  // 00000026EFD4: 8D00007E
	s_cbranch_execz 2                                          // 00000026EFD8: BFA50002 <_ZN7halogen12_GLOBAL__N_116k_deq_q4cp_probeILi4ELi2EEEvPKhPtjjllllNS0_5DeqCbE+0xde4>
	s_waitcnt vmcnt(1)                                         // 00000026EFDC: BF8907F7
	v_mov_b32_e32 v7, s3                                       // 00000026EFE0: 7E0E0203
	s_or_saveexec_b32 s0, s0                                   // 00000026EFE4: BE802200
	v_mov_b32_e32 v3, 0                                        // 00000026EFE8: 7E060280
	s_xor_b32 exec_lo, exec_lo, s0                             // 00000026EFEC: 8D7E007E
	s_cbranch_execz 55                                         // 00000026EFF0: BFA50037 <_ZN7halogen12_GLOBAL__N_116k_deq_q4cp_probeILi4ELi2EEEvPKhPtjjllllNS0_5DeqCbE+0xed0>
	.long 0xd72d0003                                           // 00000026EFF4: D72D0003
	v_cndmask_b32_e32 v0, v11, v12, vcc_lo                     // 00000026EFF8: 0200190B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000026EFFC: BF870091
	.long 0xd72c0004                                           // 00000026F000: D72C0004
	v_cndmask_b32_e32 v0, v3, v16, vcc_lo                      // 00000026F004: 02002103
	v_sub_nc_u32_e32 v4, v11, v4                               // 00000026F008: 4C08090B
	s_waitcnt vmcnt(0)                                         // 00000026F00C: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000026F010: BF870121
	v_subrev_nc_u32_e32 v8, s16, v4                            // 00000026F014: 4E100810
	v_cmp_le_u32_e32 vcc_lo, s16, v4                           // 00000026F018: 7C960810
	v_dual_cndmask_b32 v4, v4, v8 :: v_dual_add_nc_u32 v7, 1, v3// 00000026F01C: CA601104 04060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000026F024: BF870111
	v_cndmask_b32_e32 v3, v3, v7, vcc_lo                       // 00000026F028: 02060F03
	v_cmp_le_u32_e32 vcc_lo, s16, v4                           // 00000026F02C: 7C960810
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000026F030: BF870092
	v_add_nc_u32_e32 v7, 1, v3                                 // 00000026F034: 4A0E0681
	v_cndmask_b32_e32 v13, v3, v7, vcc_lo                      // 00000026F038: 021A0F03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000026F03C: BF870121
	.long 0xd72c0003                                           // 00000026F040: D72C0003
	v_cndmask_b32_e32 v0, v13, v16, vcc_lo                     // 00000026F044: 0200210D
	v_mad_u64_u32 v[7:8], null, s4, v13, s[6:7]                // 00000026F048: D6FE7C07 001A1A04
	v_sub_nc_u32_e32 v11, v11, v3                              // 00000026F050: 4C16070B
	v_mad_u64_u32 v[3:4], null, s10, v13, s[8:9]               // 00000026F054: D6FE7C03 00221A0A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000026F05C: BF8701A2
	v_lshrrev_b32_e32 v14, 1, v11                              // 00000026F060: 321C1681
	v_lshlrev_b32_e32 v15, 2, v11                              // 00000026F064: 301E1682
	v_mad_u64_u32 v[11:12], null, s11, v13, v[4:5]             // 00000026F068: D6FE7C0B 04121A0B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000026F070: BF870223
	v_and_b32_e32 v4, 0xffffffe, v14                           // 00000026F074: 36081CFF 0FFFFFFE
	v_mad_u64_u32 v[12:13], null, s5, v13, v[8:9]              // 00000026F07C: D6FE7C0C 04221A05
	v_and_b32_e32 v8, 0x7ffffffc, v15                          // 00000026F084: 36101EFF 7FFFFFFC
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000026F08C: BF870093
	.long 0xd7006a03                                           // 00000026F090: D7006A03
	v_cndmask_b32_e32 v1, v3, v4, vcc_lo                       // 00000026F094: 02020903
	v_add_co_ci_u32_e64 v4, null, 0, v11, vcc_lo               // 00000026F098: D5207C04 01AA1680
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000026F0A0: BF870093
	.long 0xd7006a07                                           // 00000026F0A4: D7006A07
	v_cndmask_b32_e32 v1, v7, v8, vcc_lo                       // 00000026F0A8: 02021107
	v_add_co_ci_u32_e64 v8, null, 0, v12, vcc_lo               // 00000026F0AC: D5207C08 01AA1880
	s_clause 0x1                                               // 00000026F0B4: BF850001
	global_load_d16_b16 v3, v[3:4], off                        // 00000026F0B8: DC820000 037C0003
	global_load_b32 v7, v[7:8], off                            // 00000026F0C0: DC520000 077C0007
	s_waitcnt vmcnt(1)                                         // 00000026F0C8: BF8907F7
	v_cvt_f32_f16_e32 v3, v3                                   // 00000026F0CC: 7E061703
	s_or_b32 exec_lo, exec_lo, s0                              // 00000026F0D0: 8C7E007E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000026F0D4: BF870009
	s_mov_b32 s0, exec_lo                                      // 00000026F0D8: BE80007E
	.long 0xd4cb007e                                           // 00000026F0DC: D4CB007E
	v_cndmask_b32_e32 v1, s17, v10, vcc_lo                     // 00000026F0E0: 02021411
	s_xor_b32 s0, exec_lo, s0                                  // 00000026F0E4: 8D00007E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000026F0E8: BF870009
	s_or_saveexec_b32 s0, s0                                   // 00000026F0EC: BE802200
	s_waitcnt vmcnt(0)                                         // 00000026F0F0: BF8903F7
	v_mov_b32_e32 v8, 0                                        // 00000026F0F4: 7E100280
	v_mov_b32_e32 v4, 0                                        // 00000026F0F8: 7E080280
	s_xor_b32 exec_lo, exec_lo, s0                             // 00000026F0FC: 8D7E007E
	s_cbranch_execz 54                                         // 00000026F100: BFA50036 <_ZN7halogen12_GLOBAL__N_116k_deq_q4cp_probeILi4ELi2EEEvPKhPtjjllllNS0_5DeqCbE+0xfdc>
	.long 0xd72d0004                                           // 00000026F104: D72D0004
	v_cndmask_b32_e32 v0, v10, v12, vcc_lo                     // 00000026F108: 0200190A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000026F10C: BF870121
	.long 0xd72c0008                                           // 00000026F110: D72C0008
	v_cndmask_b32_e32 v0, v4, v16, vcc_lo                      // 00000026F114: 02002104
	v_add_nc_u32_e32 v11, 1, v4                                // 00000026F118: 4A160881
	v_sub_nc_u32_e32 v8, v10, v8                               // 00000026F11C: 4C10110A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000026F120: BF870221
	v_subrev_nc_u32_e32 v12, s16, v8                           // 00000026F124: 4E181010
	v_cmp_le_u32_e32 vcc_lo, s16, v8                           // 00000026F128: 7C961010
	v_cndmask_b32_e32 v4, v4, v11, vcc_lo                      // 00000026F12C: 02081704
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000026F130: BF870113
	v_cndmask_b32_e32 v8, v8, v12, vcc_lo                      // 00000026F134: 02101908
	v_add_nc_u32_e32 v11, 1, v4                                // 00000026F138: 4A160881
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000026F13C: BF870112
	v_cmp_le_u32_e32 vcc_lo, s16, v8                           // 00000026F140: 7C961010
	v_cndmask_b32_e32 v4, v4, v11, vcc_lo                      // 00000026F144: 02081704
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000026F148: BF870121
	.long 0xd72c0008                                           // 00000026F14C: D72C0008
	v_cndmask_b32_e32 v0, v4, v16, vcc_lo                      // 00000026F150: 02002104
	v_mad_u64_u32 v[12:13], null, s4, v4, s[6:7]               // 00000026F154: D6FE7C0C 001A0804
	v_sub_nc_u32_e32 v8, v10, v8                               // 00000026F15C: 4C10110A
	v_mad_u64_u32 v[10:11], null, s10, v4, s[8:9]              // 00000026F160: D6FE7C0A 0022080A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000026F168: BF8701A2
	v_lshrrev_b32_e32 v16, 1, v8                               // 00000026F16C: 32201081
	v_lshlrev_b32_e32 v8, 2, v8                                // 00000026F170: 30101082
	v_mad_u64_u32 v[14:15], null, s11, v4, v[11:12]            // 00000026F174: D6FE7C0E 042E080B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000026F17C: BF870093
	v_and_b32_e32 v11, 0xffffffe, v16                          // 00000026F180: 361620FF 0FFFFFFE
	.long 0xd7006a0a                                           // 00000026F188: D7006A0A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 00000026F18C: 0202170A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000026F190: BF870133
	v_mad_u64_u32 v[15:16], null, s5, v4, v[13:14]             // 00000026F194: D6FE7C0F 04360805
	v_and_b32_e32 v4, 0x7ffffffc, v8                           // 00000026F19C: 360810FF 7FFFFFFC
	v_add_co_ci_u32_e64 v11, null, 0, v14, vcc_lo              // 00000026F1A4: D5207C0B 01AA1C80
	.long 0xd7006a0c                                           // 00000026F1AC: D7006A0C
	v_cndmask_b32_e32 v1, v12, v4, vcc_lo                      // 00000026F1B0: 0202090C
	s_delay_alu instid0(VALU_DEP_1)                            // 00000026F1B4: BF870001
	v_add_co_ci_u32_e64 v13, null, 0, v15, vcc_lo              // 00000026F1B8: D5207C0D 01AA1E80
	s_clause 0x1                                               // 00000026F1C0: BF850001
	global_load_d16_b16 v4, v[10:11], off                      // 00000026F1C4: DC820000 047C000A
	global_load_b32 v8, v[12:13], off                          // 00000026F1CC: DC520000 087C000C
	s_waitcnt vmcnt(1)                                         // 00000026F1D4: BF8907F7
	v_cvt_f32_f16_e32 v4, v4                                   // 00000026F1D8: 7E081704
	s_or_b32 exec_lo, exec_lo, s0                              // 00000026F1DC: 8C7E007E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000026F1E0: BF870009
	s_and_not1_b32 vcc_lo, exec_lo, s13                        // 00000026F1E4: 916A0D7E
	s_cbranch_vccnz 64587                                      // 00000026F1E8: BFA4FC4B <_ZN7halogen12_GLOBAL__N_116k_deq_q4cp_probeILi4ELi2EEEvPKhPtjjllllNS0_5DeqCbE+0x118>
	s_waitcnt vmcnt(0)                                         // 00000026F1EC: BF8903F7
	s_barrier                                                  // 00000026F1F0: BFBD0000
	buffer_gl0_inv                                             // 00000026F1F4: E0AC0000 00000000
	s_branch 64582                                             // 00000026F1FC: BFA0FC46 <_ZN7halogen12_GLOBAL__N_116k_deq_q4cp_probeILi4ELi2EEEvPKhPtjjllllNS0_5DeqCbE+0x118>
	s_mov_b32 s0, exec_lo                                      // 00000026F200: BE80007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000026F204: BF870001
	v_cmpx_eq_u32_e32 0x9e3779b9, v9                           // 00000026F208: 7D9412FF 9E3779B9
	s_cbranch_execz 4                                          // 00000026F210: BFA50004 <_ZN7halogen12_GLOBAL__N_116k_deq_q4cp_probeILi4ELi2EEEvPKhPtjjllllNS0_5DeqCbE+0x1024>
	v_lshlrev_b32_e32 v1, 1, v0                                // 00000026F214: 30020081
	.long 0x7e003881                                           // 00000026F218: 7E003881
	global_store_b16 v1, v0, s[14:15]                          // 00000026F21C: DC660000 000E0001
	s_endpgm                                                   // 00000026F224: BFB00000
		...

