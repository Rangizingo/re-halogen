0000000000818000 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000818000: F4100100 F8000000
	v_and_b32_e32 v30, 15, v0                                  // 000000818008: 363C008F
	v_lshrrev_b32_e32 v1, 4, v0                                // 00000081800C: 32020084
	s_ashr_i32 s3, s2, 31                                      // 000000818010: 86039F02
	v_lshlrev_b32_e32 v7, 2, v0                                // 000000818014: 300E0082
	s_lshl_b64 s[0:1], s[2:3], 4                               // 000000818018: 84808402
	v_lshlrev_b32_e32 v2, 2, v30                               // 00000081801C: 30043C82
	v_dual_mov_b32 v24, s1 :: v_dual_lshlrev_b32 v3, 2, v1     // 000000818020: CA220001 18020282
	v_or_b32_e32 v23, s0, v1                                   // 000000818028: 382E0200
	.long 0x7f0c3880                                           // 00000081802C: 7F0C3880
	s_waitcnt lgkmcnt(0)                                       // 000000818030: BF89FC07
	s_clause 0x1                                               // 000000818034: BF850001
	global_load_b32 v4, v2, s[4:5]                             // 000000818038: DC520000 04040002
	global_load_b32 v3, v3, s[4:5]                             // 000000818040: DC520000 03040003
	.long 0xd4540000                                           // 000000818048: D4540000
	v_cndmask_b32_e32 v1, s12, v23, vcc_lo                     // 00000081804C: 02022E0C
	s_add_u32 s22, s4, s16                                     // 000000818050: 80161004
	s_addc_u32 s23, s5, s17                                    // 000000818054: 82171105
	s_ashr_i32 s2, s11, 31                                     // 000000818058: 86029F0B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 00000081805C: BF870159
	s_lshr_b32 s2, s2, 27                                      // 000000818060: 85029B02
	v_cndmask_b32_e64 v2, 0, v23, s0                           // 000000818064: D5010002 00022E80
	v_cndmask_b32_e64 v5, 0, s1, s0                            // 00000081806C: D5010005 00000280
	s_add_u32 s2, s10, s2                                      // 000000818074: 8002020A
	s_addc_u32 s3, s11, 0                                      // 000000818078: 8203800B
	.long 0xd72c0008                                           // 00000081807C: D72C0008
	v_cndmask_b32_e32 v1, s19, v2, vcc_lo                      // 000000818080: 02020413
	v_mad_u64_u32 v[0:1], null, s18, v2, 0                     // 000000818084: D6FE7C00 02020412
	s_lshr_b64 s[20:21], s[2:3], 5                             // 00000081808C: 85948502
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000818090: BF870009
	s_cmpk_lt_i32 s20, 0x81                                    // 000000818094: B3940081
	.long 0xd4440002                                           // 000000818098: D4440002
	v_cndmask_b32_e32 v1, s20, v30, vcc_lo                     // 00000081809C: 02023C14
	s_cselect_b32 s1, -1, 0                                    // 0000008180A0: 980180C1
	s_cmpk_gt_i32 s20, 0x80                                    // 0000008180A4: B2940080
	s_waitcnt vmcnt(1)                                         // 0000008180A8: BF8907F7
	v_bfe_u32 v9, v4, 16, 1                                    // 0000008180AC: D6100009 02052104
	s_waitcnt vmcnt(0)                                         // 0000008180B4: BF8903F7
	v_bfe_u32 v10, v3, 16, 1                                   // 0000008180B8: D610000A 02052103
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008180C0: BF8701A2
	v_add3_u32 v4, v4, v9, 0x7fff                              // 0000008180C4: D6550004 03FE1304 00007FFF
	.long 0xd72c0009                                           // 0000008180D0: D72C0009
	v_cndmask_b32_e32 v1, s18, v5, vcc_lo                      // 0000008180D4: 02020A12
	v_add3_u32 v3, v3, v10, 0x7fff                             // 0000008180D8: D6550003 03FE1503 00007FFF
	s_cselect_b32 s18, -1, 0                                   // 0000008180E4: 981280C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008180E8: BF8701A9
	s_and_b32 vcc_lo, exec_lo, s18                             // 0000008180EC: 8B6A127E
	.long 0x7e0c3984                                           // 0000008180F0: 7E0C3984
	v_add3_u32 v1, v1, v9, v8                                  // 0000008180F4: D6550001 04221301
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008180FC: BF8700A2
	v_and_or_b32 v6, 0xffff0000, v3, v6                        // 000000818100: D6570006 041A06FF FFFF0000
	.long 0xd7000303                                           // 00000081810C: D7000303
	v_cndmask_b32_e32 v1, s22, v0, vcc_lo                      // 000000818110: 02020016
	v_add_co_ci_u32_e64 v4, null, s23, v1, s3                  // 000000818114: D5207C04 000E0217
	ds_store_b32 v7, v6                                        // 00000081811C: D8340000 00000607
	s_waitcnt lgkmcnt(0)                                       // 000000818124: BF89FC07
	s_barrier                                                  // 000000818128: BFBD0000
	buffer_gl0_inv                                             // 00000081812C: E0AC0000 00000000
	s_cbranch_vccnz 144                                        // 000000818134: BFA40090 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x378>
	v_dual_mov_b32 v8, 0 :: v_dual_mov_b32 v7, 0               // 000000818138: CA100080 08060080
	s_and_saveexec_b32 s3, s2                                  // 000000818140: BE832002
	s_cbranch_execz 10                                         // 000000818144: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x170>
	v_lshlrev_b32_e32 v6, 1, v30                               // 000000818148: 300C3C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081814C: BF870091
	.long 0xd7006a06                                           // 000000818150: D7006A06
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 000000818154: 02020D03
	v_add_co_ci_u32_e64 v7, null, 0, v4, vcc_lo                // 000000818158: D5207C07 01AA0880
	global_load_d16_b16 v6, v[6:7], off                        // 000000818160: DC820000 067C0006
	s_waitcnt vmcnt(0)                                         // 000000818168: BF8903F7
	v_cvt_f32_f16_e32 v7, v6                                   // 00000081816C: 7E0E1706
	s_or_b32 exec_lo, exec_lo, s3                              // 000000818170: 8C7E037E
	v_or_b32_e32 v6, 16, v30                                   // 000000818174: 380C3C90
	s_mov_b32 s2, exec_lo                                      // 000000818178: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000081817C: BF870001
	.long 0xd4c4007e                                           // 000000818180: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 000000818184: 02020C14
	s_cbranch_execz 10                                         // 000000818188: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x1b4>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000081818C: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000818190: BF870091
	.long 0xd7006a08                                           // 000000818194: D7006A08
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 000000818198: 02020D03
	v_add_co_ci_u32_e64 v9, null, 0, v4, vcc_lo                // 00000081819C: D5207C09 01AA0880
	global_load_d16_b16 v6, v[8:9], off                        // 0000008181A4: DC820000 067C0008
	s_waitcnt vmcnt(0)                                         // 0000008181AC: BF8903F7
	v_cvt_f32_f16_e32 v8, v6                                   // 0000008181B0: 7E101706
	s_or_b32 exec_lo, exec_lo, s2                              // 0000008181B4: 8C7E027E
	v_or_b32_e32 v6, 32, v30                                   // 0000008181B8: 380C3CA0
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v9, 0              // 0000008181BC: CA100080 0A080080
	s_mov_b32 s2, exec_lo                                      // 0000008181C4: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008181C8: BF870002
	.long 0xd4c4007e                                           // 0000008181CC: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 0000008181D0: 02020C14
	s_cbranch_execz 10                                         // 0000008181D4: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x200>
	v_lshlrev_b32_e32 v6, 1, v6                                // 0000008181D8: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008181DC: BF870091
	.long 0xd7006a0b                                           // 0000008181E0: D7006A0B
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000008181E4: 02020D03
	v_add_co_ci_u32_e64 v12, null, 0, v4, vcc_lo               // 0000008181E8: D5207C0C 01AA0880
	global_load_d16_b16 v6, v[11:12], off                      // 0000008181F0: DC820000 067C000B
	s_waitcnt vmcnt(0)                                         // 0000008181F8: BF8903F7
	v_cvt_f32_f16_e32 v9, v6                                   // 0000008181FC: 7E121706
	s_or_b32 exec_lo, exec_lo, s2                              // 000000818200: 8C7E027E
	v_or_b32_e32 v6, 48, v30                                   // 000000818204: 380C3CB0
	s_mov_b32 s2, exec_lo                                      // 000000818208: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000081820C: BF870001
	.long 0xd4c4007e                                           // 000000818210: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 000000818214: 02020C14
	s_cbranch_execz 10                                         // 000000818218: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x244>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000081821C: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000818220: BF870091
	.long 0xd7006a0a                                           // 000000818224: D7006A0A
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 000000818228: 02020D03
	v_add_co_ci_u32_e64 v11, null, 0, v4, vcc_lo               // 00000081822C: D5207C0B 01AA0880
	global_load_d16_b16 v6, v[10:11], off                      // 000000818234: DC820000 067C000A
	s_waitcnt vmcnt(0)                                         // 00000081823C: BF8903F7
	v_cvt_f32_f16_e32 v10, v6                                  // 000000818240: 7E141706
	s_or_b32 exec_lo, exec_lo, s2                              // 000000818244: 8C7E027E
	v_or_b32_e32 v6, 64, v30                                   // 000000818248: 380C3CC0
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v11, 0             // 00000081824C: CA100080 0C0A0080
	s_mov_b32 s2, exec_lo                                      // 000000818254: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000818258: BF870002
	.long 0xd4c4007e                                           // 00000081825C: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 000000818260: 02020C14
	s_cbranch_execz 10                                         // 000000818264: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x290>
	v_lshlrev_b32_e32 v6, 1, v6                                // 000000818268: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081826C: BF870091
	.long 0xd7006a0d                                           // 000000818270: D7006A0D
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 000000818274: 02020D03
	v_add_co_ci_u32_e64 v14, null, 0, v4, vcc_lo               // 000000818278: D5207C0E 01AA0880
	global_load_d16_b16 v6, v[13:14], off                      // 000000818280: DC820000 067C000D
	s_waitcnt vmcnt(0)                                         // 000000818288: BF8903F7
	v_cvt_f32_f16_e32 v11, v6                                  // 00000081828C: 7E161706
	s_or_b32 exec_lo, exec_lo, s2                              // 000000818290: 8C7E027E
	v_or_b32_e32 v6, 0x50, v30                                 // 000000818294: 380C3CFF 00000050
	s_mov_b32 s2, exec_lo                                      // 00000081829C: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008182A0: BF870001
	.long 0xd4c4007e                                           // 0000008182A4: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 0000008182A8: 02020C14
	s_cbranch_execz 10                                         // 0000008182AC: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x2d8>
	v_lshlrev_b32_e32 v6, 1, v6                                // 0000008182B0: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008182B4: BF870091
	.long 0xd7006a0c                                           // 0000008182B8: D7006A0C
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000008182BC: 02020D03
	v_add_co_ci_u32_e64 v13, null, 0, v4, vcc_lo               // 0000008182C0: D5207C0D 01AA0880
	global_load_d16_b16 v6, v[12:13], off                      // 0000008182C8: DC820000 067C000C
	s_waitcnt vmcnt(0)                                         // 0000008182D0: BF8903F7
	v_cvt_f32_f16_e32 v12, v6                                  // 0000008182D4: 7E181706
	s_or_b32 exec_lo, exec_lo, s2                              // 0000008182D8: 8C7E027E
	v_or_b32_e32 v6, 0x60, v30                                 // 0000008182DC: 380C3CFF 00000060
	v_dual_mov_b32 v14, 0 :: v_dual_mov_b32 v13, 0             // 0000008182E4: CA100080 0E0C0080
	s_mov_b32 s2, exec_lo                                      // 0000008182EC: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008182F0: BF870002
	.long 0xd4c4007e                                           // 0000008182F4: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 0000008182F8: 02020C14
	s_cbranch_execz 10                                         // 0000008182FC: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x328>
	v_lshlrev_b32_e32 v6, 1, v6                                // 000000818300: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000818304: BF870091
	.long 0xd7006a0f                                           // 000000818308: D7006A0F
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000081830C: 02020D03
	v_add_co_ci_u32_e64 v16, null, 0, v4, vcc_lo               // 000000818310: D5207C10 01AA0880
	global_load_d16_b16 v6, v[15:16], off                      // 000000818318: DC820000 067C000F
	s_waitcnt vmcnt(0)                                         // 000000818320: BF8903F7
	v_cvt_f32_f16_e32 v13, v6                                  // 000000818324: 7E1A1706
	s_or_b32 exec_lo, exec_lo, s2                              // 000000818328: 8C7E027E
	v_or_b32_e32 v6, 0x70, v30                                 // 00000081832C: 380C3CFF 00000070
	s_mov_b32 s2, exec_lo                                      // 000000818334: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000818338: BF870001
	.long 0xd4c4007e                                           // 00000081833C: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 000000818340: 02020C14
	s_cbranch_execz 10                                         // 000000818344: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x370>
	v_lshlrev_b32_e32 v6, 1, v6                                // 000000818348: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081834C: BF870091
	.long 0xd7006a0e                                           // 000000818350: D7006A0E
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 000000818354: 02020D03
	v_add_co_ci_u32_e64 v15, null, 0, v4, vcc_lo               // 000000818358: D5207C0F 01AA0880
	global_load_d16_b16 v6, v[14:15], off                      // 000000818360: DC820000 067C000E
	s_waitcnt vmcnt(0)                                         // 000000818368: BF8903F7
	v_cvt_f32_f16_e32 v14, v6                                  // 00000081836C: 7E1C1706
	s_or_b32 exec_lo, exec_lo, s2                              // 000000818370: 8C7E027E
	s_branch 9                                                 // 000000818374: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x39c>
	v_mov_b32_e32 v7, 0                                        // 000000818378: 7E0E0280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000081837C: BF870001
	v_mov_b32_e32 v8, v7                                       // 000000818380: 7E100307
	v_mov_b32_e32 v9, v7                                       // 000000818384: 7E120307
	v_mov_b32_e32 v10, v7                                      // 000000818388: 7E140307
	v_mov_b32_e32 v11, v7                                      // 00000081838C: 7E160307
	v_mov_b32_e32 v12, v7                                      // 000000818390: 7E180307
	v_mov_b32_e32 v13, v7                                      // 000000818394: 7E1A0307
	v_mov_b32_e32 v14, v7                                      // 000000818398: 7E1C0307
	s_add_u32 s2, s4, s14                                      // 00000081839C: 80020E04
	s_addc_u32 s3, s5, s15                                     // 0000008183A0: 82030F05
	s_lshr_b32 s14, s11, 31                                    // 0000008183A4: 850E9F0B
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v32, 0             // 0000008183A8: CA100080 13200080
	s_add_u32 s14, s10, s14                                    // 0000008183B0: 800E0E0A
	s_addc_u32 s15, s11, 0                                     // 0000008183B4: 820F800B
	v_cndmask_b32_e64 v31, 0, 1, s18                           // 0000008183B8: D501001F 00490280
	s_ashr_i64 s[14:15], s[14:15], 1                           // 0000008183C0: 868E810E
	v_dual_mov_b32 v42, 0 :: v_dual_mov_b32 v21, 0             // 0000008183C4: CA100080 2A140080
	v_mad_u64_u32 v[25:26], null, v2, s14, s[2:3]              // 0000008183CC: D6FE7C19 00081D02
	.long 0xd72c0002                                           // 0000008183D4: D72C0002
	v_cndmask_b32_e32 v0, v2, v15, vcc_lo                      // 0000008183D8: 02001F02
	.long 0xd72c0005                                           // 0000008183DC: D72C0005
	v_cndmask_b32_e32 v0, v5, v14, vcc_lo                      // 0000008183E0: 02001D05
	.long 0xd4440002                                           // 0000008183E4: D4440002
	v_cndmask_b32_e32 v1, s20, v30, vcc_lo                     // 0000008183E8: 02023C14
	v_mov_b32_e32 v20, 0                                       // 0000008183EC: 7E280280
	v_mov_b32_e32 v22, 0                                       // 0000008183F0: 7E2C0280
	s_delay_alu instid0(VALU_DEP_4)                            // 0000008183F4: BF870004
	v_add3_u32 v33, v5, v26, v2                                // 0000008183F8: D6550021 040A3505
	s_and_saveexec_b32 s3, s2                                  // 000000818400: BE832002
	s_cbranch_execz 21                                         // 000000818404: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x45c>
	v_lshlrev_b32_e32 v2, 4, v30                               // 000000818408: 30043C84
	v_mov_b32_e32 v42, 0                                       // 00000081840C: 7E540280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000818410: BF870092
	.long 0xd7006a05                                           // 000000818414: D7006A05
	v_cndmask_b32_e32 v1, v25, v2, vcc_lo                      // 000000818418: 02020519
	v_add_co_ci_u32_e64 v6, null, 0, v33, vcc_lo               // 00000081841C: D5207C06 01AA4280
	s_and_not1_b32 vcc_lo, exec_lo, s18                        // 000000818424: 916A127E
	global_load_b128 v[19:22], v[5:6], off                     // 000000818428: DC5E0000 137C0005
	s_cbranch_vccnz 10                                         // 000000818430: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x45c>
	v_lshlrev_b32_e32 v2, 1, v30                               // 000000818434: 30043C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000818438: BF870091
	.long 0xd7006a02                                           // 00000081843C: D7006A02
	v_cndmask_b32_e32 v1, v3, v2, vcc_lo                       // 000000818440: 02020503
	v_add_co_ci_u32_e64 v3, null, 0, v4, vcc_lo                // 000000818444: D5207C03 01AA0880
	global_load_d16_b16 v2, v[2:3], off                        // 00000081844C: DC820000 027C0002
	s_waitcnt vmcnt(0)                                         // 000000818454: BF8903F7
	v_cvt_f32_f16_e32 v42, v2                                  // 000000818458: 7E541702
	s_or_b32 exec_lo, exec_lo, s3                              // 00000081845C: 8C7E037E
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v35, 0             // 000000818460: CA100080 22220080
	v_dual_mov_b32 v36, 0 :: v_dual_mov_b32 v37, 0             // 000000818468: CA100080 24240080
	v_mov_b32_e32 v38, 0                                       // 000000818470: 7E4C0280
	s_and_saveexec_b32 s3, s2                                  // 000000818474: BE832002
	s_cbranch_execz 565                                        // 000000818478: BFA50235 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0xd50>
	v_dual_mov_b32 v27, 0 :: v_dual_lshlrev_b32 v2, 1, v30     // 00000081847C: CA220080 1B023C81
	.long 0xd7006a00                                           // 000000818484: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 000000818488: 02020010
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000081848C: BF870191
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 000000818490: D5207C01 01AA0211
	v_dual_mov_b32 v37, v27 :: v_dual_lshlrev_b32 v26, 5, v30  // 000000818498: CA22011B 251A3C85
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008184A0: BF870093
	.long 0xd7006a00                                           // 0000008184A4: D7006A00
	v_cndmask_b32_e32 v1, v0, v2, vcc_lo                       // 0000008184A8: 02020500
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 0000008184AC: D5207C01 01AA0280
	v_lshl_or_b32 v39, v30, 4, 0x100                           // 0000008184B4: D6560027 03FD091E 00000100
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008184C0: BF870093
	.long 0xd7006a00                                           // 0000008184C4: D7006A00
	v_cndmask_b32_e32 v1, s4, v0, vcc_lo                       // 0000008184C8: 02020004
	v_add_co_ci_u32_e64 v1, null, s5, v1, vcc_lo               // 0000008184CC: D5207C01 01AA0205
	v_dual_mov_b32 v40, v30 :: v_dual_mov_b32 v35, v27         // 0000008184D4: CA10011E 2822011B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008184DC: BF870093
	.long 0xd7006a1c                                           // 0000008184E0: D7006A1C
	v_cndmask_b32_e32 v0, v0, v160, vcc_lo                     // 0000008184E4: 02014100
	v_add_co_ci_u32_e64 v29, null, 0, v1, vcc_lo               // 0000008184E8: D5207C1D 01AA0280
	v_dual_mov_b32 v38, v27 :: v_dual_mov_b32 v41, v42         // 0000008184F0: CA10011B 2628012A
	v_mov_b32_e32 v36, v27                                     // 0000008184F8: 7E48031B
	v_mov_b32_e32 v34, v27                                     // 0000008184FC: 7E44031B
	v_mov_b32_e32 v32, v27                                     // 000000818500: 7E40031B
	s_mul_i32 s2, s11, 6                                       // 000000818504: 9602860B
	s_mul_hi_u32 s18, s10, 6                                   // 000000818508: 9692860A
	s_lshl_b64 s[14:15], s[10:11], 2                           // 00000081850C: 848E820A
	s_add_i32 s18, s18, s2                                     // 000000818510: 81120212
	s_mul_i32 s17, s10, 6                                      // 000000818514: 9611860A
	s_mov_b32 s16, 0                                           // 000000818518: BE900080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 00000081851C: 8484810A
	s_branch 494                                               // 000000818520: BFA001EE <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0xcdc>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000818524: 8C7E0A7E
	v_cndmask_b32_e64 v52, v42, v7, s1                         // 000000818528: D5010034 00060F2A
	v_cndmask_b32_e64 v1, v8, v9, s1                           // 000000818530: D5010001 00061308
	v_cndmask_b32_e64 v0, v7, v8, s1                           // 000000818538: D5010000 00061107
	v_dual_mov_b32 v7, v14 :: v_dual_and_b32 v8, 0xff, v19     // 000000818540: CA24010E 070826FF 000000FF
	v_cndmask_b32_e64 v6, v13, v14, s1                         // 00000081854C: D5010006 00061D0D
	v_cndmask_b32_e64 v5, v12, v13, s1                         // 000000818554: D5010005 00061B0C
	v_cndmask_b32_e64 v4, v11, v12, s1                         // 00000081855C: D5010004 0006190B
	v_cndmask_b32_e64 v3, v10, v11, s1                         // 000000818564: D5010003 0006170A
	v_lshlrev_b32_e32 v8, 2, v8                                // 00000081856C: 30101082
	v_cndmask_b32_e64 v2, v9, v10, s1                          // 000000818570: D5010002 00061509
	s_and_b32 s2, exec_lo, s2                                  // 000000818578: 8B02027E
	v_add_nc_u32_e32 v39, 0x100, v39                           // 00000081857C: 4A4E4EFF 00000100
	s_or_b32 s16, s2, s16                                      // 000000818584: 8C101002
	ds_load_b32 v14, v8                                        // 000000818588: D8D80000 0E000008
	v_lshrrev_b32_e32 v8, 6, v19                               // 000000818590: 32102686
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000818594: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000818598: 361010FF 000003FC
	ds_load_b32 v53, v8                                        // 0000008185A0: D8D80000 35000008
	v_lshrrev_b32_e32 v8, 14, v19                              // 0000008185A8: 3210268E
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008185AC: 361010FF 000003FC
	ds_load_b32 v54, v8                                        // 0000008185B4: D8D80000 36000008
	v_lshrrev_b32_e32 v8, 22, v19                              // 0000008185BC: 32102696
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008185C0: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008185C4: 361010FF 000003FC
	ds_load_b32 v55, v8                                        // 0000008185CC: D8D80000 37000008
	v_and_b32_e32 v8, 0xff, v20                                // 0000008185D4: 361028FF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 0000008185DC: 30101082
	ds_load_b32 v56, v8                                        // 0000008185E0: D8D80000 38000008
	v_lshrrev_b32_e32 v8, 6, v20                               // 0000008185E8: 32102886
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008185EC: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008185F0: 361010FF 000003FC
	ds_load_b32 v57, v8                                        // 0000008185F8: D8D80000 39000008
	v_lshrrev_b32_e32 v8, 14, v20                              // 000000818600: 3210288E
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000818604: 361010FF 000003FC
	ds_load_b32 v58, v8                                        // 00000081860C: D8D80000 3A000008
	v_lshrrev_b32_e32 v8, 22, v20                              // 000000818614: 32102896
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000818618: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000081861C: 361010FF 000003FC
	ds_load_b32 v59, v8                                        // 000000818624: D8D80000 3B000008
	v_and_b32_e32 v8, 0xff, v21                                // 00000081862C: 36102AFF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 000000818634: 30101082
	ds_load_b32 v60, v8                                        // 000000818638: D8D80000 3C000008
	v_lshrrev_b32_e32 v8, 6, v21                               // 000000818640: 32102A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000818644: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000818648: 361010FF 000003FC
	ds_load_b32 v61, v8                                        // 000000818650: D8D80000 3D000008
	v_lshrrev_b32_e32 v8, 14, v21                              // 000000818658: 32102A8E
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000081865C: 361010FF 000003FC
	ds_load_b32 v62, v8                                        // 000000818664: D8D80000 3E000008
	v_lshrrev_b32_e32 v8, 22, v21                              // 00000081866C: 32102A96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000818670: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000818674: 361010FF 000003FC
	ds_load_b32 v63, v8                                        // 00000081867C: D8D80000 3F000008
	v_and_b32_e32 v8, 0xff, v22                                // 000000818684: 36102CFF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 00000081868C: 30101082
	ds_load_b32 v64, v8                                        // 000000818690: D8D80000 40000008
	v_lshrrev_b32_e32 v8, 6, v22                               // 000000818698: 32102C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000081869C: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008186A0: 361010FF 000003FC
	ds_load_b32 v65, v8                                        // 0000008186A8: D8D80000 41000008
	v_lshrrev_b32_e32 v8, 14, v22                              // 0000008186B0: 32102C8E
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008186B4: 361010FF 000003FC
	ds_load_b32 v66, v8                                        // 0000008186BC: D8D80000 42000008
	v_lshrrev_b32_e32 v8, 22, v22                              // 0000008186C4: 32102C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000008186C8: BF870141
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008186CC: 361010FF 000003FC
	ds_load_b32 v67, v8                                        // 0000008186D4: D8D80000 43000008
	.long 0xd73c0008                                           // 0000008186DC: D73C0008
	v_cndmask_b32_e32 v1, 1, v26, vcc_lo                       // 0000008186E0: 02023481
	v_add_nc_u32_e32 v26, 0x200, v26                           // 0000008186E4: 4A3434FF 00000200
	.long 0xd7006a0c                                           // 0000008186EC: D7006A0C
	v_cndmask_b32_e32 v1, s6, v8, vcc_lo                       // 0000008186F0: 02021006
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008186F4: BF870001
	v_add_co_ci_u32_e64 v13, null, s7, v9, vcc_lo              // 0000008186F8: D5207C0D 01AA1207
	s_clause 0x3                                               // 000000818700: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 000000818704: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 00000081870C: DC5E0010 137C000C
	global_load_b128 v[42:45], v[12:13], off offset:32         // 000000818714: DC5E0020 2A7C000C
	global_load_b128 v[46:49], v[12:13], off offset:48         // 00000081871C: DC5E0030 2E7C000C
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 000000818724: BF890CF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 000000818728: CC1A4008 1A021D08
	s_waitcnt lgkmcnt(14)                                      // 000000818730: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000818734: BF8700A1
	v_dot2_f32_bf16 v8, v9, v53, v8                            // 000000818738: CC1A4008 1C226B09
	s_waitcnt lgkmcnt(13)                                      // 000000818740: BF89FCD7
	v_dot2_f32_bf16 v8, v10, v54, v8                           // 000000818744: CC1A4008 1C226D0A
	s_waitcnt lgkmcnt(12)                                      // 00000081874C: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000818750: BF8700A1
	v_dot2_f32_bf16 v8, v11, v55, v8                           // 000000818754: CC1A4008 1C226F0B
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 00000081875C: BF8908B7
	v_dot2_f32_bf16 v8, v19, v56, v8                           // 000000818760: CC1A4008 1C227113
	s_waitcnt lgkmcnt(10)                                      // 000000818768: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000081876C: BF8700A1
	v_dot2_f32_bf16 v8, v20, v57, v8                           // 000000818770: CC1A4008 1C227314
	s_waitcnt lgkmcnt(9)                                       // 000000818778: BF89FC97
	v_dot2_f32_bf16 v8, v21, v58, v8                           // 00000081877C: CC1A4008 1C227515
	s_waitcnt lgkmcnt(8)                                       // 000000818784: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000818788: BF8700A1
	v_dot2_f32_bf16 v8, v22, v59, v8                           // 00000081878C: CC1A4008 1C227716
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 000000818794: BF890477
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 000000818798: CC1A4008 1C22792A
	s_waitcnt lgkmcnt(6)                                       // 0000008187A0: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008187A4: BF8700A1
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 0000008187A8: CC1A4008 1C227B2B
	s_waitcnt lgkmcnt(5)                                       // 0000008187B0: BF89FC57
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 0000008187B4: CC1A4008 1C227D2C
	s_waitcnt lgkmcnt(4)                                       // 0000008187BC: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008187C0: BF8700A1
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 0000008187C4: CC1A4008 1C227F2D
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 0000008187CC: BF890037
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 0000008187D0: CC1A4008 1C22812E
	.long 0xd7006a2e                                           // 0000008187D8: D7006A2E
	v_cndmask_b32_e32 v0, v12, v4, vcc_lo                      // 0000008187DC: 0200090C
	s_waitcnt lgkmcnt(2)                                       // 0000008187E0: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000008187E4: BF8701C2
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 0000008187E8: CC1A4008 1C22832F
	v_add_co_ci_u32_e64 v47, null, s5, v13, vcc_lo             // 0000008187F0: D5207C2F 01AA1A05
	.long 0xd7006a32                                           // 0000008187F8: D7006A32
	v_cndmask_b32_e32 v0, v12, v14, vcc_lo                     // 0000008187FC: 02001D0C
	s_waitcnt lgkmcnt(1)                                       // 000000818800: BF89FC17
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 000000818804: CC1A4008 1C228530
	v_add_co_ci_u32_e64 v51, null, s15, v13, vcc_lo            // 00000081880C: D5207C33 01AA1A0F
	.long 0xd7006a0c                                           // 000000818814: D7006A0C
	v_cndmask_b32_e32 v0, v12, v17, vcc_lo                     // 000000818818: 0200230C
	s_waitcnt lgkmcnt(0)                                       // 00000081881C: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000818820: BF870123
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 000000818824: CC1A4008 1C228731
	v_add_co_ci_u32_e64 v13, null, s18, v13, vcc_lo            // 00000081882C: D5207C0D 01AA1A12
	v_fmac_f32_e32 v38, v52, v8                                // 000000818834: 564C1134
	s_clause 0x3                                               // 000000818838: BF850003
	global_load_b128 v[8:11], v[46:47], off                    // 00000081883C: DC5E0000 087C002E
	global_load_b128 v[19:22], v[46:47], off offset:16         // 000000818844: DC5E0010 137C002E
	global_load_b128 v[42:45], v[46:47], off offset:32         // 00000081884C: DC5E0020 2A7C002E
	global_load_b128 v[46:49], v[46:47], off offset:48         // 000000818854: DC5E0030 2E7C002E
	s_waitcnt vmcnt(3)                                         // 00000081885C: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 000000818860: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000818868: BF870091
	v_dot2_f32_bf16 v8, v9, v53, v8                            // 00000081886C: CC1A4008 1C226B09
	v_dot2_f32_bf16 v8, v10, v54, v8                           // 000000818874: CC1A4008 1C226D0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000081887C: BF8700A1
	v_dot2_f32_bf16 v8, v11, v55, v8                           // 000000818880: CC1A4008 1C226F0B
	s_waitcnt vmcnt(2)                                         // 000000818888: BF890BF7
	v_dot2_f32_bf16 v8, v19, v56, v8                           // 00000081888C: CC1A4008 1C227113
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000818894: BF870091
	v_dot2_f32_bf16 v8, v20, v57, v8                           // 000000818898: CC1A4008 1C227314
	v_dot2_f32_bf16 v8, v21, v58, v8                           // 0000008188A0: CC1A4008 1C227515
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008188A8: BF8700A1
	v_dot2_f32_bf16 v8, v22, v59, v8                           // 0000008188AC: CC1A4008 1C227716
	s_waitcnt vmcnt(1)                                         // 0000008188B4: BF8907F7
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 0000008188B8: CC1A4008 1C22792A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008188C0: BF870091
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 0000008188C4: CC1A4008 1C227B2B
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 0000008188CC: CC1A4008 1C227D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008188D4: BF8700A1
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 0000008188D8: CC1A4008 1C227F2D
	s_waitcnt vmcnt(0)                                         // 0000008188E0: BF8903F7
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 0000008188E4: CC1A4008 1C22812E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008188EC: BF870091
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 0000008188F0: CC1A4008 1C22832F
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 0000008188F8: CC1A4008 1C228530
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000818900: BF870091
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 000000818904: CC1A4008 1C228731
	v_fmac_f32_e32 v37, v52, v8                                // 00000081890C: 564A1134
	s_clause 0x3                                               // 000000818910: BF850003
	global_load_b128 v[8:11], v[50:51], off                    // 000000818914: DC5E0000 087C0032
	global_load_b128 v[19:22], v[50:51], off offset:16         // 00000081891C: DC5E0010 137C0032
	global_load_b128 v[42:45], v[50:51], off offset:32         // 000000818924: DC5E0020 2A7C0032
	global_load_b128 v[46:49], v[50:51], off offset:48         // 00000081892C: DC5E0030 2E7C0032
	s_waitcnt vmcnt(3)                                         // 000000818934: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 000000818938: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000818940: BF870091
	v_dot2_f32_bf16 v8, v9, v53, v8                            // 000000818944: CC1A4008 1C226B09
	v_dot2_f32_bf16 v8, v10, v54, v8                           // 00000081894C: CC1A4008 1C226D0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000818954: BF8700A1
	v_dot2_f32_bf16 v8, v11, v55, v8                           // 000000818958: CC1A4008 1C226F0B
	s_waitcnt vmcnt(2)                                         // 000000818960: BF890BF7
	v_dot2_f32_bf16 v8, v19, v56, v8                           // 000000818964: CC1A4008 1C227113
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081896C: BF870091
	v_dot2_f32_bf16 v8, v20, v57, v8                           // 000000818970: CC1A4008 1C227314
	v_dot2_f32_bf16 v8, v21, v58, v8                           // 000000818978: CC1A4008 1C227515
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000818980: BF8700A1
	v_dot2_f32_bf16 v8, v22, v59, v8                           // 000000818984: CC1A4008 1C227716
	s_waitcnt vmcnt(1)                                         // 00000081898C: BF8907F7
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 000000818990: CC1A4008 1C22792A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000818998: BF870091
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 00000081899C: CC1A4008 1C227B2B
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 0000008189A4: CC1A4008 1C227D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008189AC: BF8700A1
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 0000008189B0: CC1A4008 1C227F2D
	s_waitcnt vmcnt(0)                                         // 0000008189B8: BF8903F7
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 0000008189BC: CC1A4008 1C22812E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008189C4: BF870091
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 0000008189C8: CC1A4008 1C22832F
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 0000008189D0: CC1A4008 1C228530
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008189D8: BF870091
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 0000008189DC: CC1A4008 1C228731
	v_fmac_f32_e32 v36, v52, v8                                // 0000008189E4: 56481134
	s_clause 0x3                                               // 0000008189E8: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 0000008189EC: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 0000008189F4: DC5E0010 137C000C
	global_load_b128 v[42:45], v[12:13], off offset:32         // 0000008189FC: DC5E0020 2A7C000C
	global_load_b128 v[46:49], v[12:13], off offset:48         // 000000818A04: DC5E0030 2E7C000C
	s_waitcnt vmcnt(3)                                         // 000000818A0C: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 000000818A10: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000818A18: BF870091
	v_dot2_f32_bf16 v8, v9, v53, v8                            // 000000818A1C: CC1A4008 1C226B09
	v_dot2_f32_bf16 v8, v10, v54, v8                           // 000000818A24: CC1A4008 1C226D0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000818A2C: BF8700A1
	v_dot2_f32_bf16 v8, v11, v55, v8                           // 000000818A30: CC1A4008 1C226F0B
	s_waitcnt vmcnt(2)                                         // 000000818A38: BF890BF7
	v_dot2_f32_bf16 v8, v19, v56, v8                           // 000000818A3C: CC1A4008 1C227113
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000818A44: BF870091
	v_dot2_f32_bf16 v8, v20, v57, v8                           // 000000818A48: CC1A4008 1C227314
	v_dot2_f32_bf16 v8, v21, v58, v8                           // 000000818A50: CC1A4008 1C227515
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000818A58: BF8700A1
	v_dot2_f32_bf16 v8, v22, v59, v8                           // 000000818A5C: CC1A4008 1C227716
	s_waitcnt vmcnt(1)                                         // 000000818A64: BF8907F7
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 000000818A68: CC1A4008 1C22792A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000818A70: BF870091
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 000000818A74: CC1A4008 1C227B2B
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 000000818A7C: CC1A4008 1C227D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000818A84: BF8700A1
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 000000818A88: CC1A4008 1C227F2D
	s_waitcnt vmcnt(0)                                         // 000000818A90: BF8903F7
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 000000818A94: CC1A4008 1C22812E
	.long 0xd7006a2e                                           // 000000818A9C: D7006A2E
	v_cndmask_b32_e32 v0, v50, v14, vcc_lo                     // 000000818AA0: 02001D32
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000818AA4: BF8701B2
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 000000818AA8: CC1A4008 1C22832F
	v_add_co_ci_u32_e64 v47, null, s15, v51, vcc_lo            // 000000818AB0: D5207C2F 01AA660F
	.long 0xd7006a0c                                           // 000000818AB8: D7006A0C
	v_cndmask_b32_e32 v0, v12, v14, vcc_lo                     // 000000818ABC: 02001D0C
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 000000818AC0: CC1A4008 1C228530
	v_add_co_ci_u32_e64 v13, null, s15, v13, vcc_lo            // 000000818AC8: D5207C0D 01AA1A0F
	.long 0xd7006a1c                                           // 000000818AD0: D7006A1C
	v_cndmask_b32_e32 v0, v28, v160, vcc_lo                    // 000000818AD4: 0201411C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000818AD8: BF870123
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 000000818ADC: CC1A4008 1C228731
	v_add_co_ci_u32_e64 v29, null, 0, v29, vcc_lo              // 000000818AE4: D5207C1D 01AA3A80
	v_fmac_f32_e32 v35, v52, v8                                // 000000818AEC: 56461134
	s_clause 0x3                                               // 000000818AF0: BF850003
	global_load_b128 v[8:11], v[46:47], off                    // 000000818AF4: DC5E0000 087C002E
	global_load_b128 v[19:22], v[46:47], off offset:16         // 000000818AFC: DC5E0010 137C002E
	global_load_b128 v[42:45], v[46:47], off offset:32         // 000000818B04: DC5E0020 2A7C002E
	global_load_b128 v[46:49], v[46:47], off offset:48         // 000000818B0C: DC5E0030 2E7C002E
	s_waitcnt vmcnt(3)                                         // 000000818B14: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 000000818B18: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000818B20: BF870091
	v_dot2_f32_bf16 v8, v9, v53, v8                            // 000000818B24: CC1A4008 1C226B09
	v_dot2_f32_bf16 v8, v10, v54, v8                           // 000000818B2C: CC1A4008 1C226D0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000818B34: BF8700A1
	v_dot2_f32_bf16 v8, v11, v55, v8                           // 000000818B38: CC1A4008 1C226F0B
	s_waitcnt vmcnt(2)                                         // 000000818B40: BF890BF7
	v_dot2_f32_bf16 v8, v19, v56, v8                           // 000000818B44: CC1A4008 1C227113
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000818B4C: BF870091
	v_dot2_f32_bf16 v8, v20, v57, v8                           // 000000818B50: CC1A4008 1C227314
	v_dot2_f32_bf16 v8, v21, v58, v8                           // 000000818B58: CC1A4008 1C227515
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000818B60: BF8700A1
	v_dot2_f32_bf16 v8, v22, v59, v8                           // 000000818B64: CC1A4008 1C227716
	s_waitcnt vmcnt(1)                                         // 000000818B6C: BF8907F7
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 000000818B70: CC1A4008 1C22792A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000818B78: BF870091
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 000000818B7C: CC1A4008 1C227B2B
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 000000818B84: CC1A4008 1C227D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000818B8C: BF8700A1
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 000000818B90: CC1A4008 1C227F2D
	s_waitcnt vmcnt(0)                                         // 000000818B98: BF8903F7
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 000000818B9C: CC1A4008 1C22812E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000818BA4: BF870091
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 000000818BA8: CC1A4008 1C22832F
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 000000818BB0: CC1A4008 1C228530
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000818BB8: BF870091
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 000000818BBC: CC1A4008 1C228731
	v_fmac_f32_e32 v34, v52, v8                                // 000000818BC4: 56441134
	s_clause 0x3                                               // 000000818BC8: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 000000818BCC: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 000000818BD4: DC5E0010 137C000C
	global_load_b128 v[42:45], v[12:13], off offset:32         // 000000818BDC: DC5E0020 2A7C000C
	global_load_b128 v[46:49], v[12:13], off offset:48         // 000000818BE4: DC5E0030 2E7C000C
	s_waitcnt vmcnt(3)                                         // 000000818BEC: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 000000818BF0: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000818BF8: BF870091
	v_dot2_f32_bf16 v8, v9, v53, v8                            // 000000818BFC: CC1A4008 1C226B09
	v_dot2_f32_bf16 v8, v10, v54, v8                           // 000000818C04: CC1A4008 1C226D0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000818C0C: BF8700A1
	v_dot2_f32_bf16 v8, v11, v55, v8                           // 000000818C10: CC1A4008 1C226F0B
	s_waitcnt vmcnt(2)                                         // 000000818C18: BF890BF7
	v_dot2_f32_bf16 v8, v19, v56, v8                           // 000000818C1C: CC1A4008 1C227113
	v_mov_b32_e32 v19, v15                                     // 000000818C24: 7E26030F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000818C28: BF870122
	v_dot2_f32_bf16 v8, v20, v57, v8                           // 000000818C2C: CC1A4008 1C227314
	v_mov_b32_e32 v20, v16                                     // 000000818C34: 7E280310
	v_dot2_f32_bf16 v8, v21, v58, v8                           // 000000818C38: CC1A4008 1C227515
	v_mov_b32_e32 v21, v17                                     // 000000818C40: 7E2A0311
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000818C44: BF870132
	v_dot2_f32_bf16 v8, v22, v59, v8                           // 000000818C48: CC1A4008 1C227716
	v_mov_b32_e32 v22, v18                                     // 000000818C50: 7E2C0312
	s_waitcnt vmcnt(1)                                         // 000000818C54: BF8907F7
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 000000818C58: CC1A4008 1C22792A
	v_mov_b32_e32 v42, v41                                     // 000000818C60: 7E540329
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000818C64: BF870092
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 000000818C68: CC1A4008 1C227B2B
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 000000818C70: CC1A4008 1C227D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000818C78: BF8700A1
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 000000818C7C: CC1A4008 1C227F2D
	s_waitcnt vmcnt(0)                                         // 000000818C84: BF8903F7
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 000000818C88: CC1A4008 1C22812E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000818C90: BF870091
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 000000818C94: CC1A4008 1C22832F
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 000000818C9C: CC1A4008 1C228530
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000818CA4: BF870091
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 000000818CA8: CC1A4008 1C228731
	v_fmac_f32_e32 v32, v52, v8                                // 000000818CB0: 56401134
	v_mov_b32_e32 v14, v7                                      // 000000818CB4: 7E1C0307
	v_dual_mov_b32 v13, v6 :: v_dual_mov_b32 v12, v5           // 000000818CB8: CA100106 0D0C0105
	v_dual_mov_b32 v11, v4 :: v_dual_mov_b32 v10, v3           // 000000818CC0: CA100104 0B0A0103
	v_dual_mov_b32 v9, v2 :: v_dual_mov_b32 v8, v1             // 000000818CC8: CA100102 09080101
	v_mov_b32_e32 v7, v0                                       // 000000818CD0: 7E0E0300
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 000000818CD4: 917E107E
	s_cbranch_execz 28                                         // 000000818CD8: BFA5001C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0xd4c>
	s_waitcnt vmcnt(0)                                         // 000000818CDC: BF8903F7
	v_dual_mov_b32 v15, v19 :: v_dual_add_nc_u32 v40, 16, v40  // 000000818CE0: CA200113 0F285090
	v_dual_mov_b32 v16, v20 :: v_dual_mov_b32 v17, v21         // 000000818CE8: CA100114 10100115
	v_mov_b32_e32 v18, v22                                     // 000000818CF0: 7E240316
	s_delay_alu instid0(VALU_DEP_3)                            // 000000818CF4: BF870003
	.long 0xd4430002                                           // 000000818CF8: D4430002
	v_cndmask_b32_e32 v1, s20, v40, vcc_lo                     // 000000818CFC: 02025014
	s_mov_b32 s10, exec_lo                                     // 000000818D00: BE8A007E
	.long 0xd4c4007e                                           // 000000818D04: D4C4007E
	v_cndmask_b32_e32 v1, s20, v40, vcc_lo                     // 000000818D08: 02025014
	s_cbranch_execz 65029                                      // 000000818D0C: BFA5FE05 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x524>
	.long 0xd7006a00                                           // 000000818D10: D7006A00
	v_cndmask_b32_e32 v1, v25, v39, vcc_lo                     // 000000818D14: 02024F19
	s_delay_alu instid0(VALU_DEP_1)                            // 000000818D18: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v33, vcc_lo               // 000000818D1C: D5207C01 01AA4280
	v_cmp_ne_u32_e32 vcc_lo, 1, v31                            // 000000818D24: 7C9A3E81
	v_mov_b32_e32 v41, v42                                     // 000000818D28: 7E52032A
	global_load_b128 v[15:18], v[0:1], off                     // 000000818D2C: DC5E0000 0F7C0000
	s_cbranch_vccnz 65019                                      // 000000818D34: BFA4FDFB <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x524>
	global_load_d16_b16 v0, v[28:29], off                      // 000000818D38: DC820000 007C001C
	s_waitcnt vmcnt(0)                                         // 000000818D40: BF8903F7
	v_cvt_f32_f16_e32 v41, v0                                  // 000000818D44: 7E521700
	s_branch 65014                                             // 000000818D48: BFA0FDF6 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x524>
	s_or_b32 exec_lo, exec_lo, s16                             // 000000818D4C: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000818D50: BF8700A9
	s_or_b32 exec_lo, exec_lo, s3                              // 000000818D54: 8C7E037E
	.long 0xd71f0000                                           // 000000818D58: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000818D5C: 020100C1
	v_xor_b32_e32 v1, 8, v0                                    // 000000818D60: 3A020088
	v_xor_b32_e32 v7, 4, v0                                    // 000000818D64: 3A0E0084
	v_xor_b32_e32 v13, 2, v0                                   // 000000818D68: 3A1A0082
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000818D6C: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v1                            // 000000818D70: 7C9802A0
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 000000818D74: 02020300
	v_cmp_gt_u32_e32 vcc_lo, 32, v7                            // 000000818D78: 7C980EA0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000818D7C: BF870002
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000818D80: 30020282
	ds_bpermute_b32 v4, v1, v36                                // 000000818D84: DACC0000 04002401
	s_waitcnt lgkmcnt(0)                                       // 000000818D8C: BF89FC07
	v_add_f32_e32 v4, v36, v4                                  // 000000818D90: 06080924
	ds_bpermute_b32 v2, v1, v38                                // 000000818D94: DACC0000 02002601
	ds_bpermute_b32 v6, v1, v34                                // 000000818D9C: DACC0000 06002201
	v_cndmask_b32_e32 v7, v0, v7, vcc_lo                       // 000000818DA4: 020E0F00
	ds_bpermute_b32 v3, v1, v37                                // 000000818DA8: DACC0000 03002501
	ds_bpermute_b32 v5, v1, v35                                // 000000818DB0: DACC0000 05002301
	ds_bpermute_b32 v1, v1, v32                                // 000000818DB8: DACC0000 01002001
	v_cmp_gt_u32_e32 vcc_lo, 32, v13                           // 000000818DC0: 7C981AA0
	s_waitcnt lgkmcnt(4)                                       // 000000818DC4: BF89FC47
	v_add_f32_e32 v2, v38, v2                                  // 000000818DC8: 06040526
	s_waitcnt lgkmcnt(3)                                       // 000000818DCC: BF89FC37
	v_dual_add_f32 v6, v34, v6 :: v_dual_lshlrev_b32 v7, 2, v7 // 000000818DD0: C9220D22 06060E82
	s_waitcnt lgkmcnt(1)                                       // 000000818DD8: BF89FC17
	v_add_f32_e32 v5, v35, v5                                  // 000000818DDC: 060A0B23
	ds_bpermute_b32 v8, v7, v2                                 // 000000818DE0: DACC0000 08000207
	s_waitcnt lgkmcnt(0)                                       // 000000818DE8: BF89FC07
	v_add_f32_e32 v2, v2, v8                                   // 000000818DEC: 06041102
	ds_bpermute_b32 v10, v7, v4                                // 000000818DF0: DACC0000 0A000407
	v_add_f32_e32 v3, v37, v3                                  // 000000818DF8: 06060725
	ds_bpermute_b32 v11, v7, v5                                // 000000818DFC: DACC0000 0B000507
	v_add_f32_e32 v1, v32, v1                                  // 000000818E04: 06020320
	ds_bpermute_b32 v12, v7, v6                                // 000000818E08: DACC0000 0C000607
	s_waitcnt lgkmcnt(2)                                       // 000000818E10: BF89FC27
	v_add_f32_e32 v4, v4, v10                                  // 000000818E14: 06081504
	ds_bpermute_b32 v9, v7, v3                                 // 000000818E18: DACC0000 09000307
	s_waitcnt lgkmcnt(2)                                       // 000000818E20: BF89FC27
	v_add_f32_e32 v8, v5, v11                                  // 000000818E24: 06101705
	ds_bpermute_b32 v7, v7, v1                                 // 000000818E28: DACC0000 07000107
	v_xor_b32_e32 v5, 1, v0                                    // 000000818E30: 3A0A0081
	s_waitcnt lgkmcnt(1)                                       // 000000818E34: BF89FC17
	v_add_f32_e32 v3, v3, v9                                   // 000000818E38: 06061303
	v_cndmask_b32_e32 v13, v0, v13, vcc_lo                     // 000000818E3C: 021A1B00
	s_delay_alu instid0(VALU_DEP_3)                            // 000000818E40: BF870003
	v_cmp_gt_u32_e32 vcc_lo, 32, v5                            // 000000818E44: 7C980AA0
	v_add_f32_e32 v9, v6, v12                                  // 000000818E48: 06121906
	s_waitcnt lgkmcnt(0)                                       // 000000818E4C: BF89FC07
	v_add_f32_e32 v7, v1, v7                                   // 000000818E50: 060E0F01
	v_lshlrev_b32_e32 v13, 2, v13                              // 000000818E54: 301A1A82
	v_cndmask_b32_e32 v0, v0, v5, vcc_lo                       // 000000818E58: 02000B00
	v_cmp_eq_u32_e32 vcc_lo, 0, v30                            // 000000818E5C: 7C943C80
	ds_bpermute_b32 v10, v13, v4                               // 000000818E60: DACC0000 0A00040D
	v_lshlrev_b32_e32 v14, 2, v0                               // 000000818E68: 301C0082
	s_and_b32 s0, vcc_lo, s0                                   // 000000818E6C: 8B00006A
	s_waitcnt lgkmcnt(0)                                       // 000000818E70: BF89FC07
	v_add_f32_e32 v4, v4, v10                                  // 000000818E74: 06081504
	ds_bpermute_b32 v11, v13, v8                               // 000000818E78: DACC0000 0B00080D
	ds_bpermute_b32 v1, v13, v2                                // 000000818E80: DACC0000 0100020D
	ds_bpermute_b32 v12, v13, v9                               // 000000818E88: DACC0000 0C00090D
	s_waitcnt lgkmcnt(2)                                       // 000000818E90: BF89FC27
	v_add_f32_e32 v0, v8, v11                                  // 000000818E94: 06001708
	ds_bpermute_b32 v6, v13, v3                                // 000000818E98: DACC0000 0600030D
	ds_bpermute_b32 v13, v13, v7                               // 000000818EA0: DACC0000 0D00070D
	s_waitcnt lgkmcnt(3)                                       // 000000818EA8: BF89FC37
	v_add_f32_e32 v5, v2, v1                                   // 000000818EAC: 060A0302
	s_waitcnt lgkmcnt(2)                                       // 000000818EB0: BF89FC27
	v_add_f32_e32 v1, v9, v12                                  // 000000818EB4: 06021909
	ds_bpermute_b32 v8, v14, v4                                // 000000818EB8: DACC0000 0800040E
	ds_bpermute_b32 v2, v14, v0                                // 000000818EC0: DACC0000 0200000E
	ds_bpermute_b32 v9, v14, v5                                // 000000818EC8: DACC0000 0900050E
	s_waitcnt lgkmcnt(4)                                       // 000000818ED0: BF89FC47
	v_add_f32_e32 v6, v3, v6                                   // 000000818ED4: 060C0D03
	s_waitcnt lgkmcnt(3)                                       // 000000818ED8: BF89FC37
	v_add_f32_e32 v7, v7, v13                                  // 000000818EDC: 060E1B07
	ds_bpermute_b32 v3, v14, v1                                // 000000818EE0: DACC0000 0300010E
	ds_bpermute_b32 v10, v14, v6                               // 000000818EE8: DACC0000 0A00060E
	ds_bpermute_b32 v11, v14, v7                               // 000000818EF0: DACC0000 0B00070E
	s_and_saveexec_b32 s1, s0                                  // 000000818EF8: BE812000
	s_cbranch_execz 287                                        // 000000818EFC: BFA5011F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x137c>
	s_waitcnt lgkmcnt(1)                                       // 000000818F00: BF89FC17
	v_dual_add_f32 v5, v5, v9 :: v_dual_add_f32 v6, v6, v10    // 000000818F04: C9081305 05061506
	s_waitcnt lgkmcnt(0)                                       // 000000818F0C: BF89FC07
	v_dual_add_f32 v7, v7, v11 :: v_dual_add_f32 v4, v4, v8    // 000000818F10: C9081707 07041104
	v_dual_add_f32 v2, v0, v2 :: v_dual_add_f32 v3, v1, v3     // 000000818F18: C9080500 02020701
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000818F20: BF870193
	v_bfe_u32 v9, v6, 16, 1                                    // 000000818F24: D6100009 02052106
	v_bfe_u32 v13, v7, 16, 1                                   // 000000818F2C: D610000D 02052107
	v_bfe_u32 v8, v5, 16, 1                                    // 000000818F34: D6100008 02052105
	s_delay_alu instid0(VALU_DEP_4)                            // 000000818F3C: BF870004
	v_bfe_u32 v11, v2, 16, 1                                   // 000000818F40: D610000B 02052102
	v_bfe_u32 v12, v3, 16, 1                                   // 000000818F48: D610000C 02052103
	v_add3_u32 v6, v6, v9, 0x7fff                              // 000000818F50: D6550006 03FE1306 00007FFF
	v_add3_u32 v7, v7, v13, 0x7fff                             // 000000818F5C: D6550007 03FE1B07 00007FFF
	v_add3_u32 v5, v5, v8, 0x7fff                              // 000000818F68: D6550005 03FE1105 00007FFF
	v_add3_u32 v2, v2, v11, 0x7fff                             // 000000818F74: D6550002 03FE1702 00007FFF
	v_bfe_u32 v9, v4, 16, 1                                    // 000000818F80: D6100009 02052104
	v_and_b32_e32 v6, 0xffff0000, v6                           // 000000818F88: 360C0CFF FFFF0000
	v_and_b32_e32 v7, 0xffff0000, v7                           // 000000818F90: 360E0EFF FFFF0000
	.long 0xd73c0000                                           // 000000818F98: D73C0000
	v_cndmask_b32_e32 v1, 1, v23, vcc_lo                       // 000000818F9C: 02022E81
	v_and_b32_e32 v2, 0xffff0000, v2                           // 000000818FA0: 360404FF FFFF0000
	v_add3_u32 v4, v4, v9, 0x7fff                              // 000000818FA8: D6550004 03FE1304 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000818FB4: BF8701B4
	v_dual_mul_f32 v6, 0xbfb8aa3b, v6 :: v_dual_mul_f32 v7, 0xbfb8aa3b, v7// 000000818FB8: C8C60CFF 06060EFF BFB8AA3B
	v_add3_u32 v3, v3, v12, 0x7fff                             // 000000818FC4: D6550003 03FE1903 00007FFF
	.long 0xd7006a00                                           // 000000818FD0: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 000000818FD4: 02020008
	v_exp_f32_e32 v6, v6                                       // 000000818FD8: 7E0C4B06
	v_and_b32_e32 v5, 0xffff0000, v5                           // 000000818FDC: 360A0AFF FFFF0000
	v_and_b32_e32 v4, 0xffff0000, v4                           // 000000818FE4: 360808FF FFFF0000
	s_lshl_b64 s[0:1], s[12:13], 1                             // 000000818FEC: 8480810C
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 000000818FF0: D5207C01 01AA0209
	v_exp_f32_e32 v7, v7                                       // 000000818FF8: 7E0E4B07
	.long 0x7f143880                                           // 000000818FFC: 7F143880
	v_mul_f32_e32 v2, 0xbfb8aa3b, v2                           // 000000819000: 100404FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000819008: BF870196
	v_dual_add_f32 v6, 1.0, v6 :: v_dual_mul_f32 v5, 0xbfb8aa3b, v5// 00000081900C: C9060CF2 06040AFF BFB8AA3B
	.long 0x7f10398a                                           // 000000819018: 7F10398A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000081901C: BF8701A3
	v_exp_f32_e32 v2, v2                                       // 000000819020: 7E044B02
	v_and_b32_e32 v3, 0xffff0000, v3                           // 000000819024: 360606FF FFFF0000
	v_div_scale_f32 v11, null, v6, v6, 1.0                     // 00000081902C: D6FC7C0B 03CA0D06
	v_exp_f32_e32 v5, v5                                       // 000000819034: 7E0A4B05
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000819038: BF870117
	v_add_f32_e32 v7, 1.0, v7                                  // 00000081903C: 060E0EF2
	v_rcp_f32_e32 v14, v11                                     // 000000819040: 7E1C550B
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000819044: BF870296
	v_dual_add_f32 v2, 1.0, v2 :: v_dual_add_f32 v5, 1.0, v5   // 000000819048: C90804F2 02040AF2
	v_fma_f32 v17, -v11, v14, 1.0                              // 000000819050: D6130011 23CA1D0B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000819058: BF870112
	v_div_scale_f32 v9, null, v5, v5, 1.0                      // 00000081905C: D6FC7C09 03CA0B05
	v_fmac_f32_e32 v14, v17, v14                               // 000000819064: 561C1D11
	s_delay_alu instid0(VALU_DEP_2)                            // 000000819068: BF870002
	v_rcp_f32_e32 v13, v9                                      // 00000081906C: 7E1A5509
	v_mul_f32_e32 v12, 0xbfb8aa3b, v3                          // 000000819070: 101806FF BFB8AA3B
	.long 0xd7006a03                                           // 000000819078: D7006A03
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 00000081907C: 02000100
	s_waitcnt vmcnt(0)                                         // 000000819080: BF8903F7
	v_div_scale_f32 v19, s0, 1.0, v6, 1.0                      // 000000819084: D6FC0013 03CA0CF2
	v_mul_f32_e32 v4, 0xbfb8aa3b, v4                           // 00000081908C: 100808FF BFB8AA3B
	v_div_scale_f32 v17, null, v2, v2, 1.0                     // 000000819094: D6FC7C11 03CA0502
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000081909C: BF870193
	v_mul_f32_e32 v21, v19, v14                                // 0000008190A0: 102A1D13
	v_exp_f32_e32 v15, v4                                      // 0000008190A4: 7E1E4B04
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000008190A8: BF8701C6
	v_fma_f32 v16, -v9, v13, 1.0                               // 0000008190AC: D6130010 23CA1B09
	v_add_co_ci_u32_e64 v4, null, s1, v1, vcc_lo               // 0000008190B4: D5207C04 01AA0201
	v_div_scale_f32 v18, vcc_lo, 1.0, v5, 1.0                  // 0000008190BC: D6FC6A12 03CA0AF2
	v_rcp_f32_e32 v23, v17                                     // 0000008190C4: 7E2E5511
	v_fmac_f32_e32 v13, v16, v13                               // 0000008190C8: 561A1B10
	v_fma_f32 v25, -v11, v21, v19                              // 0000008190CC: D6130019 244E2B0B
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_2)   // 0000008190D4: BF870106
	v_dual_add_f32 v15, 1.0, v15 :: v_dual_mul_f32 v20, v18, v13// 0000008190D8: C9061EF2 0F141B12
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008190E0: BF870122
	v_fmac_f32_e32 v21, v25, v14                               // 0000008190E4: 562A1D19
	v_exp_f32_e32 v12, v12                                     // 0000008190E8: 7E184B0C
	v_div_scale_f32 v16, null, v15, v15, 1.0                   // 0000008190EC: D6FC7C10 03CA1F0F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000008190F4: BF870313
	v_fma_f32 v24, -v9, v20, v18                               // 0000008190F8: D6130018 244A2909
	v_fma_f32 v28, -v17, v23, 1.0                              // 000000819100: D613001C 23CA2F11
	v_fma_f32 v11, -v11, v21, v19                              // 000000819108: D613000B 244E2B0B
	v_div_scale_f32 v26, s1, 1.0, v15, 1.0                     // 000000819110: D6FC011A 03CA1EF2
	v_rcp_f32_e32 v22, v16                                     // 000000819118: 7E2C5510
	v_fmac_f32_e32 v20, v24, v13                               // 00000081911C: 56281B18
	v_div_scale_f32 v24, null, v7, v7, 1.0                     // 000000819120: D6FC7C18 03CA0F07
	v_fmac_f32_e32 v23, v28, v23                               // 000000819128: 562E2F1C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000081912C: BF870193
	v_fma_f32 v9, -v9, v20, v18                                // 000000819130: D6130009 244A2909
	v_rcp_f32_e32 v29, v24                                     // 000000819138: 7E3A5518
	v_div_scale_f32 v18, s2, 1.0, v2, 1.0                      // 00000081913C: D6FC0212 03CA04F2
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000819144: BF870196
	v_fma_f32 v25, -v16, v22, 1.0                              // 000000819148: D6130019 23CA2D10
	v_div_fmas_f32 v9, v9, v13, v20                            // 000000819150: D6370009 04521B09
	s_mov_b32 vcc_lo, s0                                       // 000000819158: BEEA0000
	v_div_scale_f32 v20, s4, 1.0, v7, 1.0                      // 00000081915C: D6FC0414 03CA0EF2
	v_div_fmas_f32 v11, v11, v14, v21                          // 000000819164: D637000B 04561D0B
	v_fmac_f32_e32 v22, v25, v22                               // 00000081916C: 562C2D19
	v_add_f32_e32 v12, 1.0, v12                                // 000000819170: 061818F2
	v_div_fixup_f32 v5, v9, v5, 1.0                            // 000000819174: D6270005 03CA0B09
	v_fma_f32 v14, -v24, v29, 1.0                              // 00000081917C: D613000E 23CA3B18
	v_div_fixup_f32 v6, v11, v6, 1.0                           // 000000819184: D6270006 03CA0D0B
	v_mul_f32_e32 v11, v26, v22                                // 00000081918C: 10162D1A
	v_div_scale_f32 v27, null, v12, v12, 1.0                   // 000000819190: D6FC7C1B 03CA190C
	.long 0x7e103985                                           // 000000819198: 7E103985
	v_mul_f32_e32 v21, v18, v23                                // 00000081919C: 102A2F12
	.long 0x7e143986                                           // 0000008191A0: 7E143986
	v_fmac_f32_e32 v29, v14, v29                               // 0000008191A4: 563A3B0E
	v_rcp_f32_e32 v19, v27                                     // 0000008191A8: 7E26551B
	v_and_b32_e32 v8, 1, v8                                    // 0000008191AC: 36101081
	v_div_scale_f32 v13, s3, 1.0, v12, 1.0                     // 0000008191B0: D6FC030D 03CA18F2
	v_and_b32_e32 v14, 1, v10                                  // 0000008191B8: 361C1481
	s_mov_b32 vcc_lo, s1                                       // 0000008191BC: BEEA0001
	s_lshl_b64 s[0:1], s[12:13], 2                             // 0000008191C0: 8480820C
	v_add3_u32 v5, v5, v8, 0x7fff                              // 0000008191C4: D6550005 03FE1105 00007FFF
	v_fma_f32 v8, -v17, v21, v18                               // 0000008191D0: D6130008 244A2B11
	v_add3_u32 v14, v6, v14, 0x7fff                            // 0000008191D8: D655000E 03FE1D06 00007FFF
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000008191E4: BF8700D5
	v_fma_f32 v9, -v27, v19, 1.0                               // 0000008191E8: D6130009 23CA271B
	global_store_d16_hi_b16 v[0:1], v5, off                    // 0000008191F0: DC960000 007C0500
	v_fmac_f32_e32 v21, v8, v23                                // 0000008191F8: 562A2F08
	v_dual_mul_f32 v8, v20, v29 :: v_dual_fmac_f32 v19, v9, v19// 0000008191FC: C8C03B14 08122709
	v_fma_f32 v9, -v16, v11, v26                               // 000000819204: D6130009 246A1710
	v_fmac_f32_e32 v11, v9, v22                                // 00000081920C: 56162D09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000819210: BF870211
	v_fma_f32 v5, -v16, v11, v26                               // 000000819214: D6130005 246A1710
	v_fma_f32 v16, -v24, v8, v20                               // 00000081921C: D6130010 24521118
	v_mul_f32_e32 v9, v13, v19                                 // 000000819224: 1012270D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000819228: BF870193
	v_div_fmas_f32 v5, v5, v22, v11                            // 00000081922C: D6370005 042E2D05
	v_fmac_f32_e32 v8, v16, v29                                // 000000819234: 56103B10
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000819238: BF870133
	v_fma_f32 v6, -v27, v9, v13                                // 00000081923C: D6130006 2436131B
	v_fma_f32 v11, -v17, v21, v18                              // 000000819244: D613000B 244A2B11
	s_mov_b32 vcc_lo, s2                                       // 00000081924C: BEEA0002
	v_fmac_f32_e32 v9, v6, v19                                 // 000000819250: 56122706
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000819254: BF8701B2
	v_div_fmas_f32 v6, v11, v23, v21                           // 000000819258: D6370006 04562F0B
	v_div_fixup_f32 v11, v5, v15, 1.0                          // 000000819260: D627000B 03CA1F05
	s_mov_b32 vcc_lo, s3                                       // 000000819268: BEEA0003
	v_fma_f32 v5, -v27, v9, v13                                // 00000081926C: D6130005 2436131B
	s_delay_alu instid0(VALU_DEP_3)                            // 000000819274: BF870003
	v_div_fixup_f32 v2, v6, v2, 1.0                            // 000000819278: D6270002 03CA0506
	v_fma_f32 v6, -v24, v8, v20                                // 000000819280: D6130006 24521118
	.long 0x7e1a398b                                           // 000000819288: 7E1A398B
	.long 0x7f1a398a                                           // 00000081928C: 7F1A398A
	v_div_fmas_f32 v9, v5, v19, v9                             // 000000819290: D6370009 04262705
	s_mov_b32 vcc_lo, s4                                       // 000000819298: BEEA0004
	.long 0x7e143982                                           // 00000081929C: 7E143982
	v_div_fmas_f32 v8, v6, v29, v8                             // 0000008192A0: D6370008 04223B06
	.long 0xd7006a05                                           // 0000008192A8: D7006A05
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 0000008192AC: 02000100
	v_div_fixup_f32 v9, v9, v12, 1.0                           // 0000008192B0: D6270009 03CA1909
	v_add_co_ci_u32_e64 v6, null, s1, v1, vcc_lo               // 0000008192B8: D5207C06 01AA0201
	s_delay_alu instid0(VALU_DEP_4)                            // 0000008192C0: BF870004
	v_div_fixup_f32 v15, v8, v7, 1.0                           // 0000008192C4: D627000F 03CA0F08
	v_mad_u64_u32 v[0:1], null, s12, 6, v[0:1]                 // 0000008192CC: D6FE7C00 04010C0C
	v_and_b32_e32 v7, 1, v10                                   // 0000008192D4: 360E1481
	.long 0x7e183989                                           // 0000008192D8: 7E183989
	.long 0x7f18398a                                           // 0000008192DC: 7F18398A
	.long 0x7e14398f                                           // 0000008192E0: 7E14398F
	v_and_b32_e32 v8, 1, v13                                   // 0000008192E4: 36101A81
	v_add3_u32 v13, v2, v7, 0x7fff                             // 0000008192E8: D655000D 03FE0F02 00007FFF
	.long 0xd7006a07                                           // 0000008192F4: D7006A07
	v_cndmask_b32_e32 v0, v5, v0, vcc_lo                       // 0000008192F8: 02000105
	v_mad_u64_u32 v[1:2], null, s13, 6, v[1:2]                 // 0000008192FC: D6FE7C01 04050C0D
	v_and_b32_e32 v2, 1, v10                                   // 000000819304: 36041481
	v_and_b32_e32 v10, 1, v12                                  // 000000819308: 36141881
	v_add3_u32 v11, v11, v8, 0x7fff                            // 00000081930C: D655000B 03FE110B 00007FFF
	v_add_co_ci_u32_e64 v8, null, s1, v6, vcc_lo               // 000000819318: D5207C08 01AA0C01
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000819320: BF870214
	v_add3_u32 v2, v15, v2, 0x7fff                             // 000000819324: D6550002 03FE050F 00007FFF
	v_add3_u32 v12, v9, v10, 0x7fff                            // 000000819330: D655000C 03FE1509 00007FFF
	.long 0xd7006a09                                           // 00000081933C: D7006A09
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 000000819340: 02000100
	s_delay_alu instid0(VALU_DEP_1)                            // 000000819344: BF870001
	v_add_co_ci_u32_e64 v10, null, s1, v1, vcc_lo              // 000000819348: D5207C0A 01AA0201
	s_clause 0x4                                               // 000000819350: BF850004
	global_store_d16_hi_b16 v[3:4], v14, off                   // 000000819354: DC960000 007C0E03
	global_store_d16_hi_b16 v[5:6], v11, off                   // 00000081935C: DC960000 007C0B05
	global_store_d16_hi_b16 v[0:1], v13, off                   // 000000819364: DC960000 007C0D00
	global_store_d16_hi_b16 v[7:8], v12, off                   // 00000081936C: DC960000 007C0C07
	global_store_d16_hi_b16 v[9:10], v2, off                   // 000000819374: DC960000 007C0209
	s_endpgm                                                   // 00000081937C: BFB00000
		...

