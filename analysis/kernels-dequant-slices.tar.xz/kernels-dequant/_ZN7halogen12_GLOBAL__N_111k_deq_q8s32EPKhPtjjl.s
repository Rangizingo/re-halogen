0000000000228200 <_ZN7halogen12_GLOBAL__N_111k_deq_q8s32EPKhPtjjl>:
; _ZN7halogen12_GLOBAL__N_111k_deq_q8s32EPKhPtjjl():
	s_load_b64 s[8:9], s[0:1], 0x10                            // 000000228200: F4040200 F8000010
	v_lshl_or_b32 v2, s2, 8, v0                                // 000000228208: D6560002 04011002
	s_mov_b32 s2, exec_lo                                      // 000000228210: BE82007E
	s_waitcnt lgkmcnt(0)                                       // 000000228214: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 000000228218: BF870001
	.long 0xd4cc007e                                           // 00000022821C: D4CC007E
	v_cndmask_b32_e32 v1, s9, v2, vcc_lo                       // 000000228220: 02020409
	s_cbranch_execz 506                                        // 000000228224: BFA501FA <_ZN7halogen12_GLOBAL__N_111k_deq_q8s32EPKhPtjjl+0x810>
	s_load_b64 s[2:3], s[0:1], 0x18                            // 000000228228: F4040080 F8000018
	s_cvt_f32_u32 s4, s8                                       // 000000228230: BE846508
	s_load_b32 s12, s[0:1], 0x20                               // 000000228234: F4000300 F8000020
	v_mov_b32_e32 v1, 0                                        // 00000022823C: 7E020280
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(TRANS32_DEP_1)// 000000228240: BF8702B9
	v_rcp_iflag_f32_e32 v0, s4                                 // 000000228244: 7E005604
	s_load_b128 s[4:7], s[0:1], null                           // 000000228248: F4080100 F8000000
	s_mov_b32 s1, 0                                            // 000000228250: BE810080
	v_readfirstlane_b32 s10, v0                                // 000000228254: 7E140500
	s_mul_f32 s13, s10, 0x4f7ffffe                             // 000000228258: A20DFF0A 4F7FFFFE
	s_waitcnt lgkmcnt(0)                                       // 000000228260: BF89FC07
	s_ashr_i32 s11, s3, 31                                     // 000000228264: 860B9F03
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000228268: BF870499
	s_lshr_b32 s0, s11, 28                                     // 00000022826C: 85009C0B
	s_add_u32 s10, s2, s0                                      // 000000228270: 800A0002
	s_addc_u32 s11, s3, 0                                      // 000000228274: 820B8003
	s_cvt_u32_f32 s0, s13                                      // 000000228278: BE80670D
	s_ashr_i64 s[10:11], s[10:11], 4                           // 00000022827C: 868A840A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000228280: BF870009
	s_add_u32 s10, s2, s10                                     // 000000228284: 800A0A02
	s_addc_u32 s11, s3, s11                                    // 000000228288: 820B0B03
	s_add_u32 s13, s10, 15                                     // 00000022828C: 800D8F0A
	s_addc_u32 s10, s11, 0                                     // 000000228290: 820A800B
	s_sub_i32 s14, 0, s8                                       // 000000228294: 818E0880
	s_and_b32 s11, s13, -16                                    // 000000228298: 8B0BD00D
	s_mul_i32 s14, s14, s0                                     // 00000022829C: 960E000E
	s_lshl_b32 s12, s12, 8                                     // 0000002282A0: 840C880C
	s_mul_hi_u32 s13, s0, s14                                  // 0000002282A4: 968D0E00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002282A8: BF870009
	s_add_i32 s13, s0, s13                                     // 0000002282AC: 810D0D00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002282B0: BF8700A9
	.long 0xd72d0000                                           // 0000002282B4: D72D0000
	v_cndmask_b32_e32 v0, v2, v13, vcc_lo                      // 0000002282B8: 02001B02
	.long 0x7f223880                                           // 0000002282BC: 7F223880
	.long 0x7f1e3991                                           // 0000002282C0: 7F1E3991
	.long 0x7f2a3991                                           // 0000002282C4: 7F2A3991
	s_delay_alu instid0(VALU_DEP_4)                            // 0000002282C8: BF870004
	.long 0xd72c0003                                           // 0000002282CC: D72C0003
	v_cndmask_b32_e32 v0, v0, v8, vcc_lo                       // 0000002282D0: 02001100
	.long 0x7f2c3991                                           // 0000002282D4: 7F2C3991
	.long 0x7f2e3991                                           // 0000002282D8: 7F2E3991
	.long 0x7f243991                                           // 0000002282DC: 7F243991
	.long 0x7f323991                                           // 0000002282E0: 7F323991
	.long 0x7f203991                                           // 0000002282E4: 7F203991
	.long 0x7f303991                                           // 0000002282E8: 7F303991
	v_sub_nc_u32_e32 v3, v2, v3                                // 0000002282EC: 4C060702
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002282F0: BF870121
	v_subrev_nc_u32_e32 v5, s8, v3                             // 0000002282F4: 4E0A0608
	v_cmp_le_u32_e32 vcc_lo, s8, v3                            // 0000002282F8: 7C960608
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_add_nc_u32 v4, 1, v0// 0000002282FC: CA600B03 03040081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000228304: BF870111
	v_cndmask_b32_e32 v0, v0, v4, vcc_lo                       // 000000228308: 02000900
	v_cmp_le_u32_e32 vcc_lo, s8, v3                            // 00000022830C: 7C960608
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000228310: BF870092
	v_add_nc_u32_e32 v4, 1, v0                                 // 000000228314: 4A080081
	v_cndmask_b32_e32 v13, v0, v4, vcc_lo                      // 000000228318: 021A0900
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000022831C: BF870091
	.long 0xd72c0000                                           // 000000228320: D72C0000
	v_cndmask_b32_e32 v0, v13, v8, vcc_lo                      // 000000228324: 0200110D
	v_sub_nc_u32_e32 v0, v2, v0                                // 000000228328: 4C000102
	v_add_nc_u32_e32 v2, s12, v2                               // 00000022832C: 4A04040C
	v_mad_u64_u32 v[3:4], null, s11, v13, s[4:5]               // 000000228330: D6FE7C03 00121A0B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000228338: BF870113
	v_lshlrev_b32_e32 v8, 1, v0                                // 00000022833C: 30100081
	v_mad_u64_u32 v[4:5], null, s10, v13, v[4:5]               // 000000228340: D6FE7C04 04121A0A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000228348: BF8701A3
	.long 0xd7006a07                                           // 00000022834C: D7006A07
	v_cndmask_b32_e32 v0, v3, v2, vcc_lo                       // 000000228350: 02000503
	.long 0xd73c0005                                           // 000000228354: D73C0005
	v_cndmask_b32_e32 v1, 5, v0, vcc_lo                        // 000000228358: 02020085
	v_add_co_ci_u32_e64 v11, null, s3, v4, vcc_lo              // 00000022835C: D5207C0B 01AA0803
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000228364: BF870193
	.long 0xd7006a07                                           // 000000228368: D7006A07
	v_cndmask_b32_e32 v1, v7, v8, vcc_lo                       // 00000022836C: 02021107
	.long 0xd7000009                                           // 000000228370: D7000009
	v_cndmask_b32_e32 v1, v3, v5, vcc_lo                       // 000000228374: 02020B03
	s_delay_alu instid0(VALU_DEP_3)                            // 000000228378: BF870003
	v_add_co_ci_u32_e64 v8, null, 0, v11, vcc_lo               // 00000022837C: D5207C08 01AA1680
	v_add_co_ci_u32_e64 v10, null, v4, v6, s0                  // 000000228384: D5207C0A 00020D04
	s_clause 0x2                                               // 00000022838C: BF850002
	global_load_d16_b16 v15, v[7:8], off                       // 000000228390: DC820000 0F7C0007
	global_load_b128 v[3:6], v[9:10], off                      // 000000228398: DC5E0000 037C0009
	global_load_b128 v[7:10], v[9:10], off offset:16           // 0000002283A0: DC5E0010 077C0009
	v_mad_u64_u32 v[11:12], null, s2, v13, 0                   // 0000002283A8: D6FE7C0B 02021A02
	v_cmp_le_u32_e32 vcc_lo, s9, v2                            // 0000002283B0: 7C960409
	s_or_b32 s1, vcc_lo, s1                                    // 0000002283B4: 8C01016A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002283B8: BF870122
	v_mad_u64_u32 v[12:13], null, s3, v13, v[12:13]            // 0000002283BC: D6FE7C0C 04321A03
	.long 0xd73c000d                                           // 0000002283C4: D73C000D
	v_cndmask_b32_e32 v1, 6, v0, vcc_lo                        // 0000002283C8: 02020086
	.long 0xd73c000b                                           // 0000002283CC: D73C000B
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 0000002283D0: 02021681
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002283D4: BF870091
	.long 0xd7000000                                           // 0000002283D8: D7000000
	v_cndmask_b32_e32 v1, s6, v11, vcc_lo                      // 0000002283DC: 02021606
	v_add_co_ci_u32_e64 v11, null, s7, v12, s0                 // 0000002283E0: D5207C0B 00021807
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002283E8: BF870092
	.long 0xd7000013                                           // 0000002283EC: D7000013
	v_cndmask_b32_e32 v1, v0, v13, vcc_lo                      // 0000002283F0: 02021B00
	v_add_co_ci_u32_e64 v20, null, v11, v14, s0                // 0000002283F4: D5207C14 00021D0B
	s_waitcnt vmcnt(1)                                         // 0000002283FC: BF8907F7
	v_bfe_i32 v33, v3, 0, 8                                    // 000000228400: D6110021 02210103
	s_waitcnt vmcnt(0)                                         // 000000228408: BF8903F7
	v_bfe_i32 v11, v7, 8, 8                                    // 00000022840C: D611000B 02211107
	v_bfe_i32 v14, v8, 8, 8                                    // 000000228414: D611000E 02211108
	v_bfe_i32 v29, v9, 16, 8                                   // 00000022841C: D611001D 02212109
	v_bfe_i32 v30, v10, 0, 8                                   // 000000228424: D611001E 0221010A
	v_bfe_i32 v31, v10, 8, 8                                   // 00000022842C: D611001F 0221110A
	v_bfe_i32 v0, v7, 0, 8                                     // 000000228434: D6110000 02210107
	v_bfe_i32 v12, v7, 16, 8                                   // 00000022843C: D611000C 02212107
	v_ashrrev_i32_e32 v7, 24, v7                               // 000000228444: 340E0E98
	v_bfe_i32 v26, v8, 16, 8                                   // 000000228448: D611001A 02212108
	v_bfe_i32 v27, v9, 0, 8                                    // 000000228450: D611001B 02210109
	v_bfe_i32 v28, v9, 8, 8                                    // 000000228458: D611001C 02211109
	v_ashrrev_i32_e32 v9, 24, v9                               // 000000228460: 34121298
	v_bfe_i32 v32, v10, 16, 8                                  // 000000228464: D6110020 0221210A
	v_bfe_i32 v34, v3, 8, 8                                    // 00000022846C: D6110022 02211103
	v_bfe_i32 v35, v3, 16, 8                                   // 000000228474: D6110023 02212103
	v_ashrrev_i32_e32 v3, 24, v3                               // 00000022847C: 34060698
	v_bfe_i32 v36, v4, 0, 8                                    // 000000228480: D6110024 02210104
	v_bfe_i32 v38, v4, 16, 8                                   // 000000228488: D6110026 02212104
	v_cvt_f32_i32_e32 v11, v11                                 // 000000228490: 7E160B0B
	v_cvt_f32_i32_e32 v14, v14                                 // 000000228494: 7E1C0B0E
	v_cvt_f32_i32_e32 v29, v29                                 // 000000228498: 7E3A0B1D
	v_cvt_f32_i32_e32 v30, v30                                 // 00000022849C: 7E3C0B1E
	v_cvt_f32_i32_e32 v31, v31                                 // 0000002284A0: 7E3E0B1F
	v_cvt_f32_i32_e32 v33, v33                                 // 0000002284A4: 7E420B21
	v_bfe_i32 v37, v4, 8, 8                                    // 0000002284A8: D6110025 02211104
	v_ashrrev_i32_e32 v4, 24, v4                               // 0000002284B0: 34080898
	v_bfe_i32 v39, v5, 0, 8                                    // 0000002284B4: D6110027 02210105
	v_cvt_f32_i32_e32 v0, v0                                   // 0000002284BC: 7E000B00
	v_cvt_f32_i32_e32 v7, v7                                   // 0000002284C0: 7E0E0B07
	v_cvt_f32_i32_e32 v26, v26                                 // 0000002284C4: 7E340B1A
	v_cvt_f32_i32_e32 v27, v27                                 // 0000002284C8: 7E360B1B
	v_cvt_f32_i32_e32 v28, v28                                 // 0000002284CC: 7E380B1C
	v_cvt_f32_i32_e32 v9, v9                                   // 0000002284D0: 7E120B09
	v_cvt_f32_i32_e32 v32, v32                                 // 0000002284D4: 7E400B20
	v_cvt_f32_i32_e32 v34, v34                                 // 0000002284D8: 7E440B22
	v_cvt_f32_i32_e32 v35, v35                                 // 0000002284DC: 7E460B23
	v_cvt_f32_i32_e32 v3, v3                                   // 0000002284E0: 7E060B03
	v_cvt_f32_i32_e32 v36, v36                                 // 0000002284E4: 7E480B24
	v_cvt_f32_i32_e32 v38, v38                                 // 0000002284E8: 7E4C0B26
	v_fma_mix_f32 v11, v15, v11, neg(0) op_sel_hi:[1,0,0]      // 0000002284EC: CC20000B 8A02170F
	v_fma_mix_f32 v14, v15, v14, neg(0) op_sel_hi:[1,0,0]      // 0000002284F4: CC20000E 8A021D0F
	v_fma_mix_f32 v29, v15, v29, neg(0) op_sel_hi:[1,0,0]      // 0000002284FC: CC20001D 8A023B0F
	v_fma_mix_f32 v30, v15, v30, neg(0) op_sel_hi:[1,0,0]      // 000000228504: CC20001E 8A023D0F
	v_fma_mix_f32 v31, v15, v31, neg(0) op_sel_hi:[1,0,0]      // 00000022850C: CC20001F 8A023F0F
	v_fma_mix_f32 v33, v15, v33, neg(0) op_sel_hi:[1,0,0]      // 000000228514: CC200021 8A02430F
	v_bfe_i32 v40, v5, 8, 8                                    // 00000022851C: D6110028 02211105
	v_bfe_i32 v41, v5, 16, 8                                   // 000000228524: D6110029 02212105
	v_ashrrev_i32_e32 v5, 24, v5                               // 00000022852C: 340A0A98
	v_bfe_i32 v42, v6, 0, 8                                    // 000000228530: D611002A 02210106
	v_cvt_f32_i32_e32 v37, v37                                 // 000000228538: 7E4A0B25
	v_cvt_f32_i32_e32 v4, v4                                   // 00000022853C: 7E080B04
	v_cvt_f32_i32_e32 v39, v39                                 // 000000228540: 7E4E0B27
	v_fma_mix_f32 v0, v15, v0, neg(0) op_sel_hi:[1,0,0]        // 000000228544: CC200000 8A02010F
	v_fma_mix_f32 v7, v15, v7, neg(0) op_sel_hi:[1,0,0]        // 00000022854C: CC200007 8A020F0F
	v_fma_mix_f32 v26, v15, v26, neg(0) op_sel_hi:[1,0,0]      // 000000228554: CC20001A 8A02350F
	v_fma_mix_f32 v27, v15, v27, neg(0) op_sel_hi:[1,0,0]      // 00000022855C: CC20001B 8A02370F
	v_fma_mix_f32 v28, v15, v28, neg(0) op_sel_hi:[1,0,0]      // 000000228564: CC20001C 8A02390F
	v_fma_mix_f32 v9, v15, v9, neg(0) op_sel_hi:[1,0,0]        // 00000022856C: CC200009 8A02130F
	v_fma_mix_f32 v32, v15, v32, neg(0) op_sel_hi:[1,0,0]      // 000000228574: CC200020 8A02410F
	v_fma_mix_f32 v34, v15, v34, neg(0) op_sel_hi:[1,0,0]      // 00000022857C: CC200022 8A02450F
	v_fma_mix_f32 v35, v15, v35, neg(0) op_sel_hi:[1,0,0]      // 000000228584: CC200023 8A02470F
	v_fma_mix_f32 v3, v15, v3, neg(0) op_sel_hi:[1,0,0]        // 00000022858C: CC200003 8A02070F
	v_fma_mix_f32 v36, v15, v36, neg(0) op_sel_hi:[1,0,0]      // 000000228594: CC200024 8A02490F
	v_fma_mix_f32 v38, v15, v38, neg(0) op_sel_hi:[1,0,0]      // 00000022859C: CC200026 8A024D0F
	v_bfe_u32 v46, v11, 16, 1                                  // 0000002285A4: D610002E 0205210B
	v_bfe_u32 v50, v14, 16, 1                                  // 0000002285AC: D6100032 0205210E
	v_bfe_u32 v55, v29, 16, 1                                  // 0000002285B4: D6100037 0205211D
	v_bfe_u32 v57, v30, 16, 1                                  // 0000002285BC: D6100039 0205211E
	v_bfe_u32 v58, v31, 16, 1                                  // 0000002285C4: D610003A 0205211F
	v_bfe_u32 v61, v33, 16, 1                                  // 0000002285CC: D610003D 02052121
	v_bfe_i32 v43, v6, 8, 8                                    // 0000002285D4: D611002B 02211106
	v_cvt_f32_i32_e32 v40, v40                                 // 0000002285DC: 7E500B28
	v_cvt_f32_i32_e32 v41, v41                                 // 0000002285E0: 7E520B29
	v_cvt_f32_i32_e32 v5, v5                                   // 0000002285E4: 7E0A0B05
	v_cvt_f32_i32_e32 v42, v42                                 // 0000002285E8: 7E540B2A
	v_fma_mix_f32 v37, v15, v37, neg(0) op_sel_hi:[1,0,0]      // 0000002285EC: CC200025 8A024B0F
	v_fma_mix_f32 v4, v15, v4, neg(0) op_sel_hi:[1,0,0]        // 0000002285F4: CC200004 8A02090F
	v_fma_mix_f32 v39, v15, v39, neg(0) op_sel_hi:[1,0,0]      // 0000002285FC: CC200027 8A024F0F
	v_bfe_u32 v45, v0, 16, 1                                   // 000000228604: D610002D 02052100
	v_bfe_u32 v48, v7, 16, 1                                   // 00000022860C: D6100030 02052107
	v_bfe_u32 v51, v26, 16, 1                                  // 000000228614: D6100033 0205211A
	v_bfe_u32 v53, v27, 16, 1                                  // 00000022861C: D6100035 0205211B
	v_bfe_u32 v54, v28, 16, 1                                  // 000000228624: D6100036 0205211C
	v_bfe_u32 v56, v9, 16, 1                                   // 00000022862C: D6100038 02052109
	v_bfe_u32 v59, v32, 16, 1                                  // 000000228634: D610003B 02052120
	v_bfe_u32 v62, v34, 16, 1                                  // 00000022863C: D610003E 02052122
	v_bfe_u32 v63, v35, 16, 1                                  // 000000228644: D610003F 02052123
	v_bfe_u32 v64, v3, 16, 1                                   // 00000022864C: D6100040 02052103
	v_bfe_u32 v65, v36, 16, 1                                  // 000000228654: D6100041 02052124
	v_bfe_u32 v67, v38, 16, 1                                  // 00000022865C: D6100043 02052126
	v_add3_u32 v11, v11, v46, 0x7fff                           // 000000228664: D655000B 03FE5D0B 00007FFF
	v_add3_u32 v46, v14, v50, 0x7fff                           // 000000228670: D655002E 03FE650E 00007FFF
	v_add3_u32 v14, v29, v55, 0x7fff                           // 00000022867C: D655000E 03FE6F1D 00007FFF
	v_add3_u32 v29, v30, v57, 0x7fff                           // 000000228688: D655001D 03FE731E 00007FFF
	v_add3_u32 v30, v31, v58, 0x7fff                           // 000000228694: D655001E 03FE751F 00007FFF
	v_add3_u32 v31, v33, v61, 0x7fff                           // 0000002286A0: D655001F 03FE7B21 00007FFF
	v_bfe_i32 v13, v8, 0, 8                                    // 0000002286AC: D611000D 02210108
	v_cvt_f32_i32_e32 v43, v43                                 // 0000002286B4: 7E560B2B
	v_fma_mix_f32 v40, v15, v40, neg(0) op_sel_hi:[1,0,0]      // 0000002286B8: CC200028 8A02510F
	v_fma_mix_f32 v41, v15, v41, neg(0) op_sel_hi:[1,0,0]      // 0000002286C0: CC200029 8A02530F
	v_fma_mix_f32 v5, v15, v5, neg(0) op_sel_hi:[1,0,0]        // 0000002286C8: CC200005 8A020B0F
	v_fma_mix_f32 v42, v15, v42, neg(0) op_sel_hi:[1,0,0]      // 0000002286D0: CC20002A 8A02550F
	v_bfe_u32 v66, v37, 16, 1                                  // 0000002286D8: D6100042 02052125
	v_bfe_u32 v68, v4, 16, 1                                   // 0000002286E0: D6100044 02052104
	v_bfe_u32 v69, v39, 16, 1                                  // 0000002286E8: D6100045 02052127
	v_add3_u32 v0, v0, v45, 0x7fff                             // 0000002286F0: D6550000 03FE5B00 00007FFF
	v_add3_u32 v45, v7, v48, 0x7fff                            // 0000002286FC: D655002D 03FE6107 00007FFF
	v_add3_u32 v7, v26, v51, 0x7fff                            // 000000228708: D6550007 03FE671A 00007FFF
	v_add3_u32 v26, v27, v53, 0x7fff                           // 000000228714: D655001A 03FE6B1B 00007FFF
	v_add3_u32 v27, v28, v54, 0x7fff                           // 000000228720: D655001B 03FE6D1C 00007FFF
	v_add3_u32 v28, v9, v56, 0x7fff                            // 00000022872C: D655001C 03FE7109 00007FFF
	v_add3_u32 v9, v32, v59, 0x7fff                            // 000000228738: D6550009 03FE7720 00007FFF
	v_add3_u32 v32, v34, v62, 0x7fff                           // 000000228744: D6550020 03FE7D22 00007FFF
	v_add3_u32 v33, v35, v63, 0x7fff                           // 000000228750: D6550021 03FE7F23 00007FFF
	v_add3_u32 v34, v3, v64, 0x7fff                            // 00000022875C: D6550022 03FE8103 00007FFF
	v_add3_u32 v35, v36, v65, 0x7fff                           // 000000228768: D6550023 03FE8324 00007FFF
	v_add3_u32 v3, v38, v67, 0x7fff                            // 000000228774: D6550003 03FE8726 00007FFF
	.long 0x7e22399f                                           // 000000228780: 7E22399F
	v_cvt_f32_i32_e32 v13, v13                                 // 000000228784: 7E1A0B0D
	v_fma_mix_f32 v43, v15, v43, neg(0) op_sel_hi:[1,0,0]      // 000000228788: CC20002B 8A02570F
	v_bfe_u32 v70, v40, 16, 1                                  // 000000228790: D6100046 02052128
	v_bfe_u32 v71, v41, 16, 1                                  // 000000228798: D6100047 02052129
	v_bfe_u32 v72, v5, 16, 1                                   // 0000002287A0: D6100048 02052105
	v_bfe_u32 v73, v42, 16, 1                                  // 0000002287A8: D6100049 0205212A
	v_add3_u32 v36, v37, v66, 0x7fff                           // 0000002287B0: D6550024 03FE8525 00007FFF
	v_add3_u32 v37, v4, v68, 0x7fff                            // 0000002287BC: D6550025 03FE8904 00007FFF
	v_add3_u32 v4, v39, v69, 0x7fff                            // 0000002287C8: D6550004 03FE8B27 00007FFF
	.long 0x7e2a3983                                           // 0000002287D4: 7E2A3983
	v_and_or_b32 v3, 0xffff0000, v32, v17                      // 0000002287D8: D6570003 044640FF FFFF0000
	.long 0x7e2239a3                                           // 0000002287E4: 7E2239A3
	v_bfe_i32 v44, v6, 16, 8                                   // 0000002287E8: D611002C 02212106
	v_fma_mix_f32 v13, v15, v13, neg(0) op_sel_hi:[1,0,0]      // 0000002287F0: CC20000D 8A021B0F
	v_bfe_u32 v74, v43, 16, 1                                  // 0000002287F8: D610004A 0205212B
	v_add3_u32 v38, v40, v70, 0x7fff                           // 000000228800: D6550026 03FE8D28 00007FFF
	v_add3_u32 v39, v41, v71, 0x7fff                           // 00000022880C: D6550027 03FE8F29 00007FFF
	v_add3_u32 v40, v5, v72, 0x7fff                            // 000000228818: D6550028 03FE9105 00007FFF
	v_add3_u32 v41, v42, v73, 0x7fff                           // 000000228824: D6550029 03FE932A 00007FFF
	v_and_or_b32 v5, 0xffff0000, v36, v17                      // 000000228830: D6570005 044648FF FFFF0000
	.long 0x7e223984                                           // 00000022883C: 7E223984
	v_ashrrev_i32_e32 v8, 24, v8                               // 000000228840: 34101098
	v_ashrrev_i32_e32 v10, 24, v10                             // 000000228844: 34141498
	v_ashrrev_i32_e32 v6, 24, v6                               // 000000228848: 340C0C98
	v_cvt_f32_i32_e32 v44, v44                                 // 00000022884C: 7E580B2C
	v_cvt_f32_i32_e32 v12, v12                                 // 000000228850: 7E180B0C
	v_bfe_u32 v49, v13, 16, 1                                  // 000000228854: D6100031 0205210D
	v_add3_u32 v42, v43, v74, 0x7fff                           // 00000022885C: D655002A 03FE952B 00007FFF
	.long 0x7e243987                                           // 000000228868: 7E243987
	v_and_or_b32 v7, 0xffff0000, v38, v17                      // 00000022886C: D6570007 04464CFF FFFF0000
	.long 0x7e2239a9                                           // 000000228878: 7E2239A9
	v_cvt_f32_i32_e32 v8, v8                                   // 00000022887C: 7E100B08
	v_cvt_f32_i32_e32 v10, v10                                 // 000000228880: 7E140B0A
	v_cvt_f32_i32_e32 v6, v6                                   // 000000228884: 7E0C0B06
	v_fma_mix_f32 v44, v15, v44, neg(0) op_sel_hi:[1,0,0]      // 000000228888: CC20002C 8A02590F
	v_fma_mix_f32 v12, v15, v12, neg(0) op_sel_hi:[1,0,0]      // 000000228890: CC20000C 8A02190F
	v_add3_u32 v13, v13, v49, 0x7fff                           // 000000228898: D655000D 03FE630D 00007FFF
	.long 0x7e323989                                           // 0000002288A4: 7E323989
	v_and_or_b32 v9, 0xffff0000, v42, v17                      // 0000002288A8: D6570009 044654FF FFFF0000
	.long 0x7e223980                                           // 0000002288B4: 7E223980
	v_fma_mix_f32 v8, v15, v8, neg(0) op_sel_hi:[1,0,0]        // 0000002288B8: CC200008 8A02110F
	v_fma_mix_f32 v10, v15, v10, neg(0) op_sel_hi:[1,0,0]      // 0000002288C0: CC20000A 8A02150F
	v_fma_mix_f32 v6, v15, v6, neg(0) op_sel_hi:[1,0,0]        // 0000002288C8: CC200006 8A020D0F
	v_bfe_u32 v75, v44, 16, 1                                  // 0000002288D0: D610004B 0205212C
	v_bfe_u32 v47, v12, 16, 1                                  // 0000002288D8: D610002F 0205210C
	v_and_or_b32 v11, 0xffff0000, v11, v17                     // 0000002288E0: D657000B 044616FF FFFF0000
	.long 0x7e22398d                                           // 0000002288EC: 7E22398D
	v_bfe_u32 v52, v8, 16, 1                                   // 0000002288F0: D6100034 02052108
	v_bfe_u32 v60, v10, 16, 1                                  // 0000002288F8: D610003C 0205210A
	v_bfe_u32 v76, v6, 16, 1                                   // 000000228900: D610004C 02052106
	v_add3_u32 v43, v44, v75, 0x7fff                           // 000000228908: D655002B 03FE972C 00007FFF
	v_add3_u32 v12, v12, v47, 0x7fff                           // 000000228914: D655000C 03FE5F0C 00007FFF
	.long 0x7e1e39a1                                           // 000000228920: 7E1E39A1
	v_and_or_b32 v13, 0xffff0000, v46, v17                     // 000000228924: D657000D 04465CFF FFFF0000
	.long 0x7e22399a                                           // 000000228930: 7E22399A
	v_add3_u32 v8, v8, v52, 0x7fff                             // 000000228934: D6550008 03FE6908 00007FFF
	v_add3_u32 v10, v10, v60, 0x7fff                           // 000000228940: D655000A 03FE790A 00007FFF
	v_add3_u32 v44, v6, v76, 0x7fff                            // 00000022894C: D655002C 03FE9906 00007FFF
	.long 0x7e2c39a7                                           // 000000228958: 7E2C39A7
	.long 0x7e2e39ab                                           // 00000022895C: 7E2E39AB
	.long 0x7e20398c                                           // 000000228960: 7E20398C
	.long 0x7e30398e                                           // 000000228964: 7E30398E
	v_and_or_b32 v4, 0xffff0000, v34, v15                      // 000000228968: D6570004 043E44FF FFFF0000
	v_and_or_b32 v15, 0xffff0000, v27, v17                     // 000000228974: D657000F 044636FF FFFF0000
	.long 0x7e22399d                                           // 000000228980: 7E22399D
	v_and_or_b32 v6, 0xffff0000, v37, v21                      // 000000228984: D6570006 04564AFF FFFF0000
	v_and_or_b32 v14, 0xffff0000, v8, v18                      // 000000228990: D657000E 044A10FF FFFF0000
	v_and_or_b32 v18, 0xffff0000, v10, v25                     // 00000022899C: D6570012 046614FF FFFF0000
	v_and_or_b32 v8, 0xffff0000, v40, v22                      // 0000002289A8: D6570008 045A50FF FFFF0000
	v_and_or_b32 v10, 0xffff0000, v44, v23                     // 0000002289B4: D657000A 045E58FF FFFF0000
	v_and_or_b32 v12, 0xffff0000, v45, v16                     // 0000002289C0: D657000C 04425AFF FFFF0000
	v_and_or_b32 v16, 0xffff0000, v28, v24                     // 0000002289CC: D6570010 046238FF FFFF0000
	v_and_or_b32 v17, 0xffff0000, v30, v17                     // 0000002289D8: D6570011 04463CFF FFFF0000
	s_clause 0x3                                               // 0000002289E4: BF850003
	global_store_b128 v[19:20], v[3:6], off                    // 0000002289E8: DC760000 007C0313
	global_store_b128 v[19:20], v[7:10], off offset:16         // 0000002289F0: DC760010 007C0713
	global_store_b128 v[19:20], v[11:14], off offset:32        // 0000002289F8: DC760020 007C0B13
	global_store_b128 v[19:20], v[15:18], off offset:48        // 000000228A00: DC760030 007C0F13
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 000000228A08: 917E017E
	s_cbranch_execnz 65064                                     // 000000228A0C: BFA6FE28 <_ZN7halogen12_GLOBAL__N_111k_deq_q8s32EPKhPtjjl+0xb0>
	s_endpgm                                                   // 000000228A10: BFB00000
		...

