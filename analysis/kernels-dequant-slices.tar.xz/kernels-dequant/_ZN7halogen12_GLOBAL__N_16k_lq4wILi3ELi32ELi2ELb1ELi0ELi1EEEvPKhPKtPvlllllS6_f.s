0000000000743500 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000743500: F4100100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 000000743508: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 00000074350C: 32040082
	s_lshl_b64 s[2:3], s[2:3], 2                               // 000000743510: 84828202
	v_and_b32_e32 v1, 15, v0                                   // 000000743514: 3602008F
	v_lshrrev_b32_e32 v21, 6, v0                               // 000000743518: 322A0086
	v_bfe_u32 v22, v0, 5, 1                                    // 00000074351C: D6100016 02050B00
	v_and_b32_e32 v2, 60, v2                                   // 000000743524: 360404BC
	v_and_b32_e32 v23, 31, v0                                  // 000000743528: 362E009F
	v_lshlrev_b32_e32 v1, 2, v1                                // 00000074352C: 30020282
	.long 0x7f0a3880                                           // 000000743530: 7F0A3880
	s_waitcnt lgkmcnt(0)                                       // 000000743534: BF89FC07
	s_clause 0x1                                               // 000000743538: BF850001
	global_load_b32 v3, v1, s[4:5]                             // 00000074353C: DC520000 03040001
	global_load_b32 v4, v2, s[4:5]                             // 000000743544: DC520000 04040002
	s_add_u32 s0, s4, s16                                      // 00000074354C: 80001004
	s_addc_u32 s1, s5, s17                                     // 000000743550: 82011105
	s_ashr_i32 s16, s11, 31                                    // 000000743554: 86109F0B
	v_mov_b32_e32 v2, s3                                       // 000000743558: 7E040203
	s_lshr_b32 s16, s16, 27                                    // 00000074355C: 85109B10
	v_or_b32_e32 v1, s2, v21                                   // 000000743560: 38022A02
	s_add_u32 s16, s10, s16                                    // 000000743564: 8010100A
	s_addc_u32 s17, s11, 0                                     // 000000743568: 8211800B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000074356C: BF870099
	s_lshr_b64 s[16:17], s[16:17], 5                           // 000000743570: 85908510
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 000000743574: 7CA8020C
	s_add_i32 s17, s16, 1                                      // 000000743578: 81118110
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000074357C: BF870499
	s_lshr_b32 s20, s17, 31                                    // 000000743580: 85149F11
	s_add_i32 s17, s17, s20                                    // 000000743584: 81111411
	v_cndmask_b32_e32 v9, 0, v1, vcc_lo                        // 000000743588: 02120280
	s_ashr_i32 s17, s17, 1                                     // 00000074358C: 86118111
	v_cndmask_b32_e64 v10, 0, s3, vcc_lo                       // 000000743590: D501000A 01A80680
	.long 0xd72c0002                                           // 000000743598: D72C0002
	v_cndmask_b32_e32 v1, s17, v22, vcc_lo                     // 00000074359C: 02022C11
	s_cmpk_lt_i32 s16, 0x201                                   // 0000007435A0: B3900201
	.long 0xd72c0007                                           // 0000007435A4: D72C0007
	v_cndmask_b32_e32 v1, s19, v9, vcc_lo                      // 0000007435A8: 02021213
	v_mad_u64_u32 v[17:18], null, s18, v9, s[0:1]              // 0000007435AC: D6FE7C11 00021212
	s_cselect_b32 s0, -1, 0                                    // 0000007435B4: 980080C1
	s_cmpk_gt_i32 s16, 0x200                                   // 0000007435B8: B2900200
	v_lshlrev_b32_e32 v1, 2, v0                                // 0000007435BC: 30020082
	v_add_nc_u32_e32 v11, s17, v2                              // 0000007435C0: 4A160411
	v_add_nc_u32_e32 v24, v2, v23                              // 0000007435C4: 4A302F02
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000007435C8: BF8704A2
	v_min_i32_e32 v25, s16, v11                                // 0000007435CC: 22321610
	s_cselect_b32 s16, -1, 0                                   // 0000007435D0: 981080C1
	s_and_b32 vcc_lo, exec_lo, s16                             // 0000007435D4: 8B6A107E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000007435D8: BF870151
	.long 0xd4410001                                           // 0000007435DC: D4410001
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 0000007435E0: 02023318
	s_waitcnt vmcnt(1)                                         // 0000007435E4: BF8907F7
	v_bfe_u32 v6, v3, 16, 1                                    // 0000007435E8: D6100006 02052103
	s_waitcnt vmcnt(0)                                         // 0000007435F0: BF8903F7
	v_bfe_u32 v8, v4, 16, 1                                    // 0000007435F4: D6100008 02052104
	v_add3_u32 v3, v3, v6, 0x7fff                              // 0000007435FC: D6550003 03FE0D03 00007FFF
	.long 0xd72c0006                                           // 000000743608: D72C0006
	v_cndmask_b32_e32 v1, s18, v10, vcc_lo                     // 00000074360C: 02021412
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000743610: BF870193
	v_add3_u32 v4, v4, v8, 0x7fff                              // 000000743614: D6550004 03FE1104 00007FFF
	.long 0x7e0a3983                                           // 000000743620: 7E0A3983
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000743624: BF870113
	v_add3_u32 v26, v7, v18, v6                                // 000000743628: D655001A 041A2507
	v_and_or_b32 v2, 0xffff0000, v4, v5                        // 000000743630: D6570002 041608FF FFFF0000
	ds_store_b32 v1, v2                                        // 00000074363C: D8340000 00000201
	s_waitcnt lgkmcnt(0)                                       // 000000743644: BF89FC07
	s_barrier                                                  // 000000743648: BFBD0000
	buffer_gl0_inv                                             // 00000074364C: E0AC0000 00000000
	s_cbranch_vccnz 154                                        // 000000743654: BFA4009A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x3c0>
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v1, 0               // 000000743658: CA100080 02000080
	s_and_saveexec_b32 s17, s1                                 // 000000743660: BE912001
	s_cbranch_execz 11                                         // 000000743664: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x194>
	v_lshlrev_b32_e32 v1, 1, v24                               // 000000743668: 30023081
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000074366C: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v1                               // 000000743670: 3408029F
	.long 0xd7006a03                                           // 000000743674: D7006A03
	v_cndmask_b32_e32 v1, v17, v1, vcc_lo                      // 000000743678: 02020311
	v_add_co_ci_u32_e64 v4, null, v26, v4, vcc_lo              // 00000074367C: D5207C04 01AA091A
	global_load_d16_b16 v1, v[3:4], off                        // 000000743684: DC820000 017C0003
	s_waitcnt vmcnt(0)                                         // 00000074368C: BF8903F7
	v_cvt_f32_f16_e32 v1, v1                                   // 000000743690: 7E021701
	s_or_b32 exec_lo, exec_lo, s17                             // 000000743694: 8C7E117E
	v_add_nc_u32_e32 v3, 32, v24                               // 000000743698: 4A0630A0
	s_mov_b32 s1, exec_lo                                      // 00000074369C: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007436A0: BF870001
	.long 0xd4c1007e                                           // 0000007436A4: D4C1007E
	v_cndmask_b32_e32 v1, v3, v25, vcc_lo                      // 0000007436A8: 02023303
	s_cbranch_execz 11                                         // 0000007436AC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x1dc>
	v_lshlrev_b32_e32 v2, 1, v3                                // 0000007436B0: 30040681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007436B4: BF8700A1
	v_ashrrev_i32_e32 v3, 31, v2                               // 0000007436B8: 3406049F
	.long 0xd7006a02                                           // 0000007436BC: D7006A02
	v_cndmask_b32_e32 v1, v17, v2, vcc_lo                      // 0000007436C0: 02020511
	v_add_co_ci_u32_e64 v3, null, v26, v3, vcc_lo              // 0000007436C4: D5207C03 01AA071A
	global_load_d16_b16 v2, v[2:3], off                        // 0000007436CC: DC820000 027C0002
	s_waitcnt vmcnt(0)                                         // 0000007436D4: BF8903F7
	v_cvt_f32_f16_e32 v2, v2                                   // 0000007436D8: 7E041702
	s_or_b32 exec_lo, exec_lo, s1                              // 0000007436DC: 8C7E017E
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v5, 64, v24      // 0000007436E0: CA200080 040430C0
	v_mov_b32_e32 v3, 0                                        // 0000007436E8: 7E060280
	s_mov_b32 s1, exec_lo                                      // 0000007436EC: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007436F0: BF870002
	.long 0xd4c1007e                                           // 0000007436F4: D4C1007E
	v_cndmask_b32_e32 v1, v5, v25, vcc_lo                      // 0000007436F8: 02023305
	s_cbranch_execz 11                                         // 0000007436FC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x22c>
	v_lshlrev_b32_e32 v3, 1, v5                                // 000000743700: 30060A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000743704: BF8700A1
	v_ashrrev_i32_e32 v6, 31, v3                               // 000000743708: 340C069F
	.long 0xd7006a05                                           // 00000074370C: D7006A05
	v_cndmask_b32_e32 v1, v17, v3, vcc_lo                      // 000000743710: 02020711
	v_add_co_ci_u32_e64 v6, null, v26, v6, vcc_lo              // 000000743714: D5207C06 01AA0D1A
	global_load_d16_b16 v3, v[5:6], off                        // 00000074371C: DC820000 037C0005
	s_waitcnt vmcnt(0)                                         // 000000743724: BF8903F7
	v_cvt_f32_f16_e32 v3, v3                                   // 000000743728: 7E061703
	s_or_b32 exec_lo, exec_lo, s1                              // 00000074372C: 8C7E017E
	v_add_nc_u32_e32 v5, 0x60, v24                             // 000000743730: 4A0A30FF 00000060
	s_mov_b32 s1, exec_lo                                      // 000000743738: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000074373C: BF870001
	.long 0xd4c1007e                                           // 000000743740: D4C1007E
	v_cndmask_b32_e32 v1, v5, v25, vcc_lo                      // 000000743744: 02023305
	s_cbranch_execz 11                                         // 000000743748: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x278>
	v_lshlrev_b32_e32 v4, 1, v5                                // 00000074374C: 30080A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000743750: BF8700A1
	v_ashrrev_i32_e32 v5, 31, v4                               // 000000743754: 340A089F
	.long 0xd7006a04                                           // 000000743758: D7006A04
	v_cndmask_b32_e32 v1, v17, v4, vcc_lo                      // 00000074375C: 02020911
	v_add_co_ci_u32_e64 v5, null, v26, v5, vcc_lo              // 000000743760: D5207C05 01AA0B1A
	global_load_d16_b16 v4, v[4:5], off                        // 000000743768: DC820000 047C0004
	s_waitcnt vmcnt(0)                                         // 000000743770: BF8903F7
	v_cvt_f32_f16_e32 v4, v4                                   // 000000743774: 7E081704
	s_or_b32 exec_lo, exec_lo, s1                              // 000000743778: 8C7E017E
	v_dual_mov_b32 v6, 0 :: v_dual_add_nc_u32 v7, 0x80, v24    // 00000074377C: CA200080 060630FF 00000080
	v_mov_b32_e32 v5, 0                                        // 000000743788: 7E0A0280
	s_mov_b32 s1, exec_lo                                      // 00000074378C: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000743790: BF870002
	.long 0xd4c1007e                                           // 000000743794: D4C1007E
	v_cndmask_b32_e32 v1, v7, v25, vcc_lo                      // 000000743798: 02023307
	s_cbranch_execz 11                                         // 00000074379C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x2cc>
	v_lshlrev_b32_e32 v5, 1, v7                                // 0000007437A0: 300A0E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007437A4: BF8700A1
	v_ashrrev_i32_e32 v8, 31, v5                               // 0000007437A8: 34100A9F
	.long 0xd7006a07                                           // 0000007437AC: D7006A07
	v_cndmask_b32_e32 v1, v17, v5, vcc_lo                      // 0000007437B0: 02020B11
	v_add_co_ci_u32_e64 v8, null, v26, v8, vcc_lo              // 0000007437B4: D5207C08 01AA111A
	global_load_d16_b16 v5, v[7:8], off                        // 0000007437BC: DC820000 057C0007
	s_waitcnt vmcnt(0)                                         // 0000007437C4: BF8903F7
	v_cvt_f32_f16_e32 v5, v5                                   // 0000007437C8: 7E0A1705
	s_or_b32 exec_lo, exec_lo, s1                              // 0000007437CC: 8C7E017E
	v_add_nc_u32_e32 v7, 0xa0, v24                             // 0000007437D0: 4A0E30FF 000000A0
	s_mov_b32 s1, exec_lo                                      // 0000007437D8: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007437DC: BF870001
	.long 0xd4c1007e                                           // 0000007437E0: D4C1007E
	v_cndmask_b32_e32 v1, v7, v25, vcc_lo                      // 0000007437E4: 02023307
	s_cbranch_execz 11                                         // 0000007437E8: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x318>
	v_lshlrev_b32_e32 v6, 1, v7                                // 0000007437EC: 300C0E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007437F0: BF8700A1
	v_ashrrev_i32_e32 v7, 31, v6                               // 0000007437F4: 340E0C9F
	.long 0xd7006a06                                           // 0000007437F8: D7006A06
	v_cndmask_b32_e32 v1, v17, v6, vcc_lo                      // 0000007437FC: 02020D11
	v_add_co_ci_u32_e64 v7, null, v26, v7, vcc_lo              // 000000743800: D5207C07 01AA0F1A
	global_load_d16_b16 v6, v[6:7], off                        // 000000743808: DC820000 067C0006
	s_waitcnt vmcnt(0)                                         // 000000743810: BF8903F7
	v_cvt_f32_f16_e32 v6, v6                                   // 000000743814: 7E0C1706
	s_or_b32 exec_lo, exec_lo, s1                              // 000000743818: 8C7E017E
	v_dual_mov_b32 v8, 0 :: v_dual_add_nc_u32 v11, 0xc0, v24   // 00000074381C: CA200080 080A30FF 000000C0
	v_mov_b32_e32 v7, 0                                        // 000000743828: 7E0E0280
	s_mov_b32 s1, exec_lo                                      // 00000074382C: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000743830: BF870002
	.long 0xd4c1007e                                           // 000000743834: D4C1007E
	v_cndmask_b32_e32 v1, v11, v25, vcc_lo                     // 000000743838: 0202330B
	s_cbranch_execz 11                                         // 00000074383C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x36c>
	v_lshlrev_b32_e32 v7, 1, v11                               // 000000743840: 300E1681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000743844: BF8700A1
	v_ashrrev_i32_e32 v12, 31, v7                              // 000000743848: 34180E9F
	.long 0xd7006a0b                                           // 00000074384C: D7006A0B
	v_cndmask_b32_e32 v1, v17, v7, vcc_lo                      // 000000743850: 02020F11
	v_add_co_ci_u32_e64 v12, null, v26, v12, vcc_lo            // 000000743854: D5207C0C 01AA191A
	global_load_d16_b16 v7, v[11:12], off                      // 00000074385C: DC820000 077C000B
	s_waitcnt vmcnt(0)                                         // 000000743864: BF8903F7
	v_cvt_f32_f16_e32 v7, v7                                   // 000000743868: 7E0E1707
	s_or_b32 exec_lo, exec_lo, s1                              // 00000074386C: 8C7E017E
	v_add_nc_u32_e32 v11, 0xe0, v24                            // 000000743870: 4A1630FF 000000E0
	s_mov_b32 s1, exec_lo                                      // 000000743878: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000074387C: BF870001
	.long 0xd4c1007e                                           // 000000743880: D4C1007E
	v_cndmask_b32_e32 v1, v11, v25, vcc_lo                     // 000000743884: 0202330B
	s_cbranch_execz 11                                         // 000000743888: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x3b8>
	v_lshlrev_b32_e32 v8, 1, v11                               // 00000074388C: 30101681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000743890: BF8700A1
	v_ashrrev_i32_e32 v12, 31, v8                              // 000000743894: 3418109F
	.long 0xd7006a0b                                           // 000000743898: D7006A0B
	v_cndmask_b32_e32 v1, v17, v8, vcc_lo                      // 00000074389C: 02021111
	v_add_co_ci_u32_e64 v12, null, v26, v12, vcc_lo            // 0000007438A0: D5207C0C 01AA191A
	global_load_d16_b16 v8, v[11:12], off                      // 0000007438A8: DC820000 087C000B
	s_waitcnt vmcnt(0)                                         // 0000007438B0: BF8903F7
	v_cvt_f32_f16_e32 v8, v8                                   // 0000007438B4: 7E101708
	s_or_b32 exec_lo, exec_lo, s1                              // 0000007438B8: 8C7E017E
	s_branch 9                                                 // 0000007438BC: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x3e4>
	v_mov_b32_e32 v1, 0                                        // 0000007438C0: 7E020280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007438C4: BF870001
	v_mov_b32_e32 v2, v1                                       // 0000007438C8: 7E040301
	v_mov_b32_e32 v3, v1                                       // 0000007438CC: 7E060301
	v_mov_b32_e32 v4, v1                                       // 0000007438D0: 7E080301
	v_mov_b32_e32 v5, v1                                       // 0000007438D4: 7E0A0301
	v_mov_b32_e32 v6, v1                                       // 0000007438D8: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 0000007438DC: 7E0E0301
	v_mov_b32_e32 v8, v1                                       // 0000007438E0: 7E100301
	s_add_u32 s4, s4, s14                                      // 0000007438E4: 80040E04
	s_addc_u32 s5, s5, s15                                     // 0000007438E8: 82050F05
	s_lshr_b32 s1, s11, 31                                     // 0000007438EC: 85019F0B
	v_mov_b32_e32 v27, 0                                       // 0000007438F0: 7E360280
	s_add_u32 s14, s10, s1                                     // 0000007438F4: 800E010A
	s_addc_u32 s15, s11, 0                                     // 0000007438F8: 820F800B
	.long 0xd4410001                                           // 0000007438FC: D4410001
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 000000743900: 02023318
	s_ashr_i64 s[14:15], s[14:15], 1                           // 000000743904: 868E810E
	v_cndmask_b32_e64 v28, 0, 1, s16                           // 000000743908: D501001C 00410280
	v_mad_u64_u32 v[18:19], null, v9, s14, s[4:5]              // 000000743910: D6FE7C12 00101D09
	.long 0xd72c000c                                           // 000000743918: D72C000C
	v_cndmask_b32_e32 v0, v9, v15, vcc_lo                      // 00000074391C: 02001F09
	.long 0xd72c000d                                           // 000000743920: D72C000D
	v_cndmask_b32_e32 v0, v10, v14, vcc_lo                     // 000000743924: 02001D0A
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v10, 0              // 000000743928: CA100080 090A0080
	v_mov_b32_e32 v35, 0                                       // 000000743930: 7E460280
	v_mov_b32_e32 v11, 0                                       // 000000743934: 7E160280
	s_delay_alu instid0(VALU_DEP_4)                            // 000000743938: BF870004
	v_add3_u32 v29, v13, v19, v12                              // 00000074393C: D655001D 0432270D
	v_mov_b32_e32 v12, 0                                       // 000000743944: 7E180280
	s_and_saveexec_b32 s4, s1                                  // 000000743948: BE842001
	s_cbranch_execz 22                                         // 00000074394C: BFA50016 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x4a8>
	v_lshlrev_b32_e32 v9, 4, v24                               // 000000743950: 30123084
	v_mov_b32_e32 v35, 0                                       // 000000743954: 7E460280
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000743958: BF8700A2
	v_ashrrev_i32_e32 v10, 31, v9                              // 00000074395C: 3414129F
	.long 0xd7006a09                                           // 000000743960: D7006A09
	v_cndmask_b32_e32 v1, v18, v9, vcc_lo                      // 000000743964: 02021312
	v_add_co_ci_u32_e64 v10, null, v29, v10, vcc_lo            // 000000743968: D5207C0A 01AA151D
	s_and_not1_b32 vcc_lo, exec_lo, s16                        // 000000743970: 916A107E
	global_load_b128 v[9:12], v[9:10], off                     // 000000743974: DC5E0000 097C0009
	s_cbranch_vccnz 10                                         // 00000074397C: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x4a8>
	v_lshlrev_b32_e32 v13, 1, v24                              // 000000743980: 301A3081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000743984: BF870091
	.long 0xd7006a0d                                           // 000000743988: D7006A0D
	v_cndmask_b32_e32 v1, v17, v13, vcc_lo                     // 00000074398C: 02021B11
	v_add_co_ci_u32_e64 v14, null, 0, v26, vcc_lo              // 000000743990: D5207C0E 01AA3480
	global_load_d16_b16 v13, v[13:14], off                     // 000000743998: DC820000 0D7C000D
	s_waitcnt vmcnt(0)                                         // 0000007439A0: BF8903F7
	v_cvt_f32_f16_e32 v35, v13                                 // 0000007439A4: 7E46170D
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007439A8: 8C7E047E
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v30, 0             // 0000007439AC: CA100080 1F1E0080
	s_and_saveexec_b32 s14, s1                                 // 0000007439B4: BE8E2001
	s_cbranch_execz 338                                        // 0000007439B8: BFA50152 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xa04>
	v_dual_mov_b32 v30, 0 :: v_dual_add_nc_u32 v13, 32, v24    // 0000007439BC: CA200080 1E0C30A0
	v_dual_mov_b32 v34, v35 :: v_dual_lshlrev_b32 v19, 5, v24  // 0000007439C4: CA220123 22123085
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007439CC: BF870002
	v_dual_mov_b32 v31, 0 :: v_dual_lshlrev_b32 v32, 4, v13    // 0000007439D0: CA220080 1F201A84
	v_lshlrev_b32_e32 v33, 1, v13                              // 0000007439D8: 30421A81
	v_mov_b32_e32 v27, 0                                       // 0000007439DC: 7E360280
	s_lshl_b64 s[4:5], s[10:11], 2                             // 0000007439E0: 8484820A
	s_mov_b32 s15, 0                                           // 0000007439E4: BE8F0080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 0000007439E8: 848A810A
	s_branch 289                                               // 0000007439EC: BFA00121 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x974>
	s_or_b32 exec_lo, exec_lo, s16                             // 0000007439F0: 8C7E107E
	v_ashrrev_i32_e32 v20, 31, v19                             // 0000007439F4: 3428269F
	v_cndmask_b32_e64 v84, v35, v1, s0                         // 0000007439F8: D5010054 00020323
	v_lshrrev_b32_e32 v35, 6, v9                               // 000000743A00: 32461286
	v_lshrrev_b32_e32 v85, 14, v9                              // 000000743A04: 32AA128E
	v_and_b32_e32 v86, 0xff, v10                               // 000000743A08: 36AC14FF 000000FF
	.long 0xd73c0024                                           // 000000743A10: D73C0024
	v_cndmask_b32_e32 v1, 1, v19, vcc_lo                       // 000000743A14: 02022681
	v_and_b32_e32 v20, 0xff, v9                                // 000000743A18: 362812FF 000000FF
	v_and_b32_e32 v35, 0x3fc, v35                              // 000000743A20: 364646FF 000003FC
	v_and_b32_e32 v85, 0x3fc, v85                              // 000000743A28: 36AAAAFF 000003FC
	v_lshrrev_b32_e32 v9, 22, v9                               // 000000743A30: 32121296
	v_lshrrev_b32_e32 v87, 6, v10                              // 000000743A34: 32AE1486
	.long 0xd7006a48                                           // 000000743A38: D7006A48
	v_cndmask_b32_e32 v1, s6, v36, vcc_lo                      // 000000743A3C: 02024806
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000743A40: BF8701A1
	v_add_co_ci_u32_e64 v73, null, s7, v37, vcc_lo             // 000000743A44: D5207C49 01AA4A07
	v_lshlrev_b32_e32 v20, 2, v20                              // 000000743A4C: 30282882
	.long 0xd7006a4c                                           // 000000743A50: D7006A4C
	v_cndmask_b32_e32 v0, v72, v10, vcc_lo                     // 000000743A54: 02001548
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000743A58: BF8700A1
	v_add_co_ci_u32_e64 v77, null, s11, v73, vcc_lo            // 000000743A5C: D5207C4D 01AA920B
	.long 0xd7006a50                                           // 000000743A64: D7006A50
	v_cndmask_b32_e32 v0, v72, v4, vcc_lo                      // 000000743A68: 02000948
	v_add_co_ci_u32_e64 v81, null, s5, v73, vcc_lo             // 000000743A6C: D5207C51 01AA9205
	s_clause 0xb                                               // 000000743A74: BF85000B
	global_load_b128 v[36:39], v[72:73], off                   // 000000743A78: DC5E0000 247C0048
	global_load_b128 v[40:43], v[76:77], off                   // 000000743A80: DC5E0000 287C004C
	global_load_b128 v[44:47], v[80:81], off                   // 000000743A88: DC5E0000 2C7C0050
	global_load_b128 v[48:51], v[72:73], off offset:16         // 000000743A90: DC5E0010 307C0048
	global_load_b128 v[52:55], v[76:77], off offset:16         // 000000743A98: DC5E0010 347C004C
	global_load_b128 v[56:59], v[80:81], off offset:16         // 000000743AA0: DC5E0010 387C0050
	global_load_b128 v[60:63], v[72:73], off offset:32         // 000000743AA8: DC5E0020 3C7C0048
	global_load_b128 v[64:67], v[76:77], off offset:32         // 000000743AB0: DC5E0020 407C004C
	global_load_b128 v[68:71], v[80:81], off offset:32         // 000000743AB8: DC5E0020 447C0050
	global_load_b128 v[72:75], v[72:73], off offset:48         // 000000743AC0: DC5E0030 487C0048
	global_load_b128 v[76:79], v[76:77], off offset:48         // 000000743AC8: DC5E0030 4C7C004C
	global_load_b128 v[80:83], v[80:81], off offset:48         // 000000743AD0: DC5E0030 507C0050
	ds_load_b32 v20, v20                                       // 000000743AD8: D8D80000 14000014
	ds_load_b32 v35, v35                                       // 000000743AE0: D8D80000 23000023
	ds_load_b32 v85, v85                                       // 000000743AE8: D8D80000 55000055
	v_lshrrev_b32_e32 v88, 14, v10                             // 000000743AF0: 32B0148E
	v_lshrrev_b32_e32 v10, 22, v10                             // 000000743AF4: 32141496
	v_lshlrev_b32_e32 v86, 2, v86                              // 000000743AF8: 30ACAC82
	v_and_b32_e32 v87, 0x3fc, v87                              // 000000743AFC: 36AEAEFF 000003FC
	v_and_b32_e32 v89, 0xff, v11                               // 000000743B04: 36B216FF 000000FF
	v_and_b32_e32 v88, 0x3fc, v88                              // 000000743B0C: 36B0B0FF 000003FC
	v_lshrrev_b32_e32 v90, 6, v11                              // 000000743B14: 32B41686
	v_lshrrev_b32_e32 v91, 14, v11                             // 000000743B18: 32B6168E
	v_lshrrev_b32_e32 v11, 22, v11                             // 000000743B1C: 32161696
	v_lshrrev_b32_e32 v93, 14, v12                             // 000000743B20: 32BA188E
	v_add_nc_u32_e32 v33, 64, v33                              // 000000743B24: 4A4242C0
	v_add_nc_u32_e32 v19, 0x400, v19                           // 000000743B28: 4A2626FF 00000400
	s_and_b32 s1, exec_lo, s1                                  // 000000743B30: 8B01017E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000743B34: BF870009
	s_or_b32 s15, s1, s15                                      // 000000743B38: 8C0F0F01
	s_waitcnt vmcnt(11) lgkmcnt(2)                             // 000000743B3C: BF892C27
	v_dot2_f32_bf16 v36, v36, v20, 0                           // 000000743B40: CC1A4024 1A022924
	s_waitcnt vmcnt(10)                                        // 000000743B48: BF892BF7
	v_dot2_f32_bf16 v40, v40, v20, 0                           // 000000743B4C: CC1A4028 1A022928
	s_waitcnt vmcnt(9)                                         // 000000743B54: BF8927F7
	v_dot2_f32_bf16 v20, v44, v20, 0                           // 000000743B58: CC1A4014 1A02292C
	v_lshrrev_b32_e32 v44, 6, v12                              // 000000743B60: 32581886
	s_waitcnt lgkmcnt(1)                                       // 000000743B64: BF89FC17
	v_dot2_f32_bf16 v36, v37, v35, v36                         // 000000743B68: CC1A4024 1C924725
	v_dot2_f32_bf16 v37, v41, v35, v40                         // 000000743B70: CC1A4025 1CA24729
	v_dot2_f32_bf16 v20, v45, v35, v20                         // 000000743B78: CC1A4014 1C52472D
	v_and_b32_e32 v40, 0x3fc, v91                              // 000000743B80: 3650B6FF 000003FC
	v_and_b32_e32 v41, 0x3fc, v93                              // 000000743B88: 3652BAFF 000003FC
	s_waitcnt lgkmcnt(0)                                       // 000000743B90: BF89FC07
	v_dot2_f32_bf16 v36, v38, v85, v36                         // 000000743B94: CC1A4024 1C92AB26
	v_dot2_f32_bf16 v37, v42, v85, v37                         // 000000743B9C: CC1A4025 1C96AB2A
	v_cndmask_b32_e64 v42, v7, v8, s0                          // 000000743BA4: D501002A 00021107
	v_and_b32_e32 v9, 0x3fc, v9                                // 000000743BAC: 361212FF 000003FC
	v_and_b32_e32 v10, 0x3fc, v10                              // 000000743BB4: 361414FF 000003FC
	ds_load_b32 v9, v9                                         // 000000743BBC: D8D80000 09000009
	ds_load_b32 v86, v86                                       // 000000743BC4: D8D80000 56000056
	ds_load_b32 v87, v87                                       // 000000743BCC: D8D80000 57000057
	ds_load_b32 v88, v88                                       // 000000743BD4: D8D80000 58000058
	ds_load_b32 v10, v10                                       // 000000743BDC: D8D80000 0A00000A
	v_dot2_f32_bf16 v20, v46, v85, v20                         // 000000743BE4: CC1A4014 1C52AB2E
	v_lshlrev_b32_e32 v35, 2, v89                              // 000000743BEC: 3046B282
	v_and_b32_e32 v38, 0x3fc, v90                              // 000000743BF0: 364CB4FF 000003FC
	ds_load_b32 v35, v35                                       // 000000743BF8: D8D80000 23000023
	ds_load_b32 v38, v38                                       // 000000743C00: D8D80000 26000026
	s_waitcnt lgkmcnt(6)                                       // 000000743C08: BF89FC67
	v_dot2_f32_bf16 v36, v39, v9, v36                          // 000000743C0C: CC1A4024 1C921327
	v_dot2_f32_bf16 v37, v43, v9, v37                          // 000000743C14: CC1A4025 1C96132B
	v_dot2_f32_bf16 v9, v47, v9, v20                           // 000000743C1C: CC1A4009 1C52132F
	ds_load_b32 v43, v40                                       // 000000743C24: D8D80000 2B000028
	v_and_b32_e32 v92, 0xff, v12                               // 000000743C2C: 36B818FF 000000FF
	s_waitcnt vmcnt(8) lgkmcnt(6)                              // 000000743C34: BF892067
	v_dot2_f32_bf16 v36, v48, v86, v36                         // 000000743C38: CC1A4024 1C92AD30
	s_waitcnt vmcnt(7)                                         // 000000743C40: BF891FF7
	v_dot2_f32_bf16 v37, v52, v86, v37                         // 000000743C44: CC1A4025 1C96AD34
	s_waitcnt vmcnt(6)                                         // 000000743C4C: BF891BF7
	v_dot2_f32_bf16 v9, v56, v86, v9                           // 000000743C50: CC1A4009 1C26AD38
	v_lshrrev_b32_e32 v12, 22, v12                             // 000000743C58: 32181896
	v_cndmask_b32_e64 v40, v5, v6, s0                          // 000000743C5C: D5010028 00020D05
	s_waitcnt lgkmcnt(5)                                       // 000000743C64: BF89FC57
	v_dot2_f32_bf16 v36, v49, v87, v36                         // 000000743C68: CC1A4024 1C92AF31
	v_dot2_f32_bf16 v37, v53, v87, v37                         // 000000743C70: CC1A4025 1C96AF35
	v_dot2_f32_bf16 v9, v57, v87, v9                           // 000000743C78: CC1A4009 1C26AF39
	v_and_b32_e32 v11, 0x3fc, v11                              // 000000743C80: 361616FF 000003FC
	v_lshlrev_b32_e32 v20, 2, v92                              // 000000743C88: 3028B882
	s_waitcnt lgkmcnt(4)                                       // 000000743C8C: BF89FC47
	v_dot2_f32_bf16 v36, v50, v88, v36                         // 000000743C90: CC1A4024 1C92B132
	v_dot2_f32_bf16 v37, v54, v88, v37                         // 000000743C98: CC1A4025 1C96B136
	v_dot2_f32_bf16 v9, v58, v88, v9                           // 000000743CA0: CC1A4009 1C26B13A
	v_and_b32_e32 v39, 0x3fc, v44                              // 000000743CA8: 364E58FF 000003FC
	v_and_b32_e32 v12, 0x3fc, v12                              // 000000743CB0: 361818FF 000003FC
	s_waitcnt lgkmcnt(3)                                       // 000000743CB8: BF89FC37
	v_dot2_f32_bf16 v36, v51, v10, v36                         // 000000743CBC: CC1A4024 1C921533
	v_dot2_f32_bf16 v37, v55, v10, v37                         // 000000743CC4: CC1A4025 1C961537
	v_dot2_f32_bf16 v9, v59, v10, v9                           // 000000743CCC: CC1A4009 1C26153B
	ds_load_b32 v10, v11                                       // 000000743CD4: D8D80000 0A00000B
	ds_load_b32 v11, v20                                       // 000000743CDC: D8D80000 0B000014
	ds_load_b32 v20, v39                                       // 000000743CE4: D8D80000 14000027
	ds_load_b32 v44, v41                                       // 000000743CEC: D8D80000 2C000029
	ds_load_b32 v45, v12                                       // 000000743CF4: D8D80000 2D00000C
	v_cndmask_b32_e64 v41, v6, v7, s0                          // 000000743CFC: D5010029 00020F06
	s_waitcnt vmcnt(5) lgkmcnt(7)                              // 000000743D04: BF891477
	v_dot2_f32_bf16 v12, v60, v35, v36                         // 000000743D08: CC1A400C 1C92473C
	s_waitcnt vmcnt(4)                                         // 000000743D10: BF8913F7
	v_dot2_f32_bf16 v36, v64, v35, v37                         // 000000743D14: CC1A4024 1C964740
	s_waitcnt vmcnt(3)                                         // 000000743D1C: BF890FF7
	v_dot2_f32_bf16 v9, v68, v35, v9                           // 000000743D20: CC1A4009 1C264744
	v_cndmask_b32_e64 v39, v4, v5, s0                          // 000000743D28: D5010027 00020B04
	v_cndmask_b32_e64 v37, v2, v3, s0                          // 000000743D30: D5010025 00020702
	s_waitcnt lgkmcnt(6)                                       // 000000743D38: BF89FC67
	v_dot2_f32_bf16 v7, v61, v38, v12                          // 000000743D3C: CC1A4007 1C324D3D
	v_dot2_f32_bf16 v12, v65, v38, v36                         // 000000743D44: CC1A400C 1C924D41
	v_dot2_f32_bf16 v9, v69, v38, v9                           // 000000743D4C: CC1A4009 1C264D45
	v_cndmask_b32_e64 v38, v3, v4, s0                          // 000000743D54: D5010026 00020903
	v_cndmask_b32_e64 v36, v1, v2, s0                          // 000000743D5C: D5010024 00020501
	s_waitcnt lgkmcnt(5)                                       // 000000743D64: BF89FC57
	v_dot2_f32_bf16 v5, v62, v43, v7                           // 000000743D68: CC1A4005 1C1E573E
	v_dot2_f32_bf16 v6, v66, v43, v12                          // 000000743D70: CC1A4006 1C325742
	v_dot2_f32_bf16 v7, v70, v43, v9                           // 000000743D78: CC1A4007 1C265746
	v_dual_mov_b32 v43, v8 :: v_dual_add_nc_u32 v32, 0x200, v32// 000000743D80: CA200108 2B2040FF 00000200
	s_waitcnt lgkmcnt(4)                                       // 000000743D8C: BF89FC47
	v_dot2_f32_bf16 v3, v63, v10, v5                           // 000000743D90: CC1A4003 1C16153F
	v_dot2_f32_bf16 v4, v67, v10, v6                           // 000000743D98: CC1A4004 1C1A1543
	v_dot2_f32_bf16 v5, v71, v10, v7                           // 000000743DA0: CC1A4005 1C1E1547
	v_mov_b32_e32 v12, v16                                     // 000000743DA8: 7E180310
	v_mov_b32_e32 v10, v14                                     // 000000743DAC: 7E14030E
	s_waitcnt vmcnt(2) lgkmcnt(3)                              // 000000743DB0: BF890837
	v_dot2_f32_bf16 v1, v72, v11, v3                           // 000000743DB4: CC1A4001 1C0E1748
	s_waitcnt vmcnt(1)                                         // 000000743DBC: BF8907F7
	v_dot2_f32_bf16 v2, v76, v11, v4                           // 000000743DC0: CC1A4002 1C12174C
	s_waitcnt vmcnt(0)                                         // 000000743DC8: BF8903F7
	v_dot2_f32_bf16 v3, v80, v11, v5                           // 000000743DCC: CC1A4003 1C161750
	v_mov_b32_e32 v11, v15                                     // 000000743DD4: 7E16030F
	v_mov_b32_e32 v9, v13                                      // 000000743DD8: 7E12030D
	s_waitcnt lgkmcnt(2)                                       // 000000743DDC: BF89FC27
	v_dot2_f32_bf16 v1, v73, v20, v1                           // 000000743DE0: CC1A4001 1C062949
	v_dot2_f32_bf16 v2, v77, v20, v2                           // 000000743DE8: CC1A4002 1C0A294D
	v_dot2_f32_bf16 v3, v81, v20, v3                           // 000000743DF0: CC1A4003 1C0E2951
	v_mov_b32_e32 v35, v34                                     // 000000743DF8: 7E460322
	s_waitcnt lgkmcnt(1)                                       // 000000743DFC: BF89FC17
	v_dot2_f32_bf16 v1, v74, v44, v1                           // 000000743E00: CC1A4001 1C06594A
	v_dot2_f32_bf16 v2, v78, v44, v2                           // 000000743E08: CC1A4002 1C0A594E
	v_dot2_f32_bf16 v3, v82, v44, v3                           // 000000743E10: CC1A4003 1C0E5952
	s_waitcnt lgkmcnt(0)                                       // 000000743E18: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000743E1C: BF870193
	v_dot2_f32_bf16 v1, v75, v45, v1                           // 000000743E20: CC1A4001 1C065B4B
	v_dot2_f32_bf16 v2, v79, v45, v2                           // 000000743E28: CC1A4002 1C0A5B4F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000743E30: BF870193
	v_dot2_f32_bf16 v3, v83, v45, v3                           // 000000743E34: CC1A4003 1C0E5B53
	v_fmac_f32_e32 v30, v84, v1                                // 000000743E3C: 563C0354
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000743E40: BF870193
	v_fmac_f32_e32 v31, v84, v2                                // 000000743E44: 563E0554
	v_fmac_f32_e32 v27, v84, v3                                // 000000743E48: 56360754
	v_dual_mov_b32 v1, v36 :: v_dual_mov_b32 v2, v37           // 000000743E4C: CA100124 01020125
	v_dual_mov_b32 v3, v38 :: v_dual_mov_b32 v4, v39           // 000000743E54: CA100126 03040127
	v_dual_mov_b32 v5, v40 :: v_dual_mov_b32 v6, v41           // 000000743E5C: CA100128 05060129
	v_dual_mov_b32 v7, v42 :: v_dual_mov_b32 v8, v43           // 000000743E64: CA10012A 0708012B
	s_and_not1_b32 exec_lo, exec_lo, s15                       // 000000743E6C: 917E0F7E
	s_cbranch_execz 35                                         // 000000743E70: BFA50023 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xa00>
	s_waitcnt vmcnt(0)                                         // 000000743E74: BF8903F7
	v_dual_mov_b32 v13, v9 :: v_dual_add_nc_u32 v24, 32, v24   // 000000743E78: CA200109 0D1830A0
	v_dual_mov_b32 v14, v10 :: v_dual_mov_b32 v15, v11         // 000000743E80: CA10010A 0E0E010B
	v_mov_b32_e32 v16, v12                                     // 000000743E88: 7E20030C
	s_delay_alu instid0(VALU_DEP_3)                            // 000000743E8C: BF870003
	.long 0xd4460001                                           // 000000743E90: D4460001
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 000000743E94: 02023318
	s_mov_b32 s16, exec_lo                                     // 000000743E98: BE90007E
	.long 0xd4c1007e                                           // 000000743E9C: D4C1007E
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 000000743EA0: 02023318
	s_cbranch_execz 65234                                      // 000000743EA4: BFA5FED2 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x4f0>
	v_ashrrev_i32_e32 v14, 31, v32                             // 000000743EA8: 341C409F
	.long 0xd7006a0d                                           // 000000743EAC: D7006A0D
	v_cndmask_b32_e32 v1, v18, v32, vcc_lo                     // 000000743EB0: 02024112
	v_mov_b32_e32 v34, v35                                     // 000000743EB4: 7E440323
	s_delay_alu instid0(VALU_DEP_3)                            // 000000743EB8: BF870003
	v_add_co_ci_u32_e64 v14, null, v29, v14, vcc_lo            // 000000743EBC: D5207C0E 01AA1D1D
	v_cmp_ne_u32_e32 vcc_lo, 1, v28                            // 000000743EC4: 7C9A3881
	global_load_b128 v[13:16], v[13:14], off                   // 000000743EC8: DC5E0000 0D7C000D
	s_cbranch_vccnz 65223                                      // 000000743ED0: BFA4FEC7 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x4f0>
	v_ashrrev_i32_e32 v20, 31, v33                             // 000000743ED4: 3428429F
	.long 0xd7006a24                                           // 000000743ED8: D7006A24
	v_cndmask_b32_e32 v1, v17, v33, vcc_lo                     // 000000743EDC: 02024311
	s_delay_alu instid0(VALU_DEP_1)                            // 000000743EE0: BF870001
	v_add_co_ci_u32_e64 v37, null, v26, v20, vcc_lo            // 000000743EE4: D5207C25 01AA291A
	global_load_d16_b16 v20, v[36:37], off                     // 000000743EEC: DC820000 147C0024
	s_waitcnt vmcnt(0)                                         // 000000743EF4: BF8903F7
	v_cvt_f32_f16_e32 v34, v20                                 // 000000743EF8: 7E441714
	s_branch 65212                                             // 000000743EFC: BFA0FEBC <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x4f0>
	s_or_b32 exec_lo, exec_lo, s15                             // 000000743F00: 8C7E0F7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000743F04: BF8700B9
	s_or_b32 exec_lo, exec_lo, s14                             // 000000743F08: 8C7E0E7E
	.long 0xd71f0001                                           // 000000743F0C: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000743F10: 020100C1
	s_mov_b32 s0, exec_lo                                      // 000000743F14: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 000000743F18: 3A040290
	v_xor_b32_e32 v5, 8, v1                                    // 000000743F1C: 3A0A0288
	v_xor_b32_e32 v8, 4, v1                                    // 000000743F20: 3A100284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000743F24: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 000000743F28: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 000000743F2C: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v5                            // 000000743F30: 7C980AA0
	v_cndmask_b32_e32 v5, v1, v5, vcc_lo                       // 000000743F34: 020A0B01
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 000000743F38: 7C9810A0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000743F3C: BF870002
	v_lshlrev_b32_e32 v5, 2, v5                                // 000000743F40: 300A0A82
	v_lshlrev_b32_e32 v2, 2, v2                                // 000000743F44: 30040482
	ds_bpermute_b32 v3, v2, v30                                // 000000743F48: DACC0000 03001E02
	s_waitcnt lgkmcnt(0)                                       // 000000743F50: BF89FC07
	v_add_f32_e32 v3, v30, v3                                  // 000000743F54: 0606071E
	ds_bpermute_b32 v4, v2, v31                                // 000000743F58: DACC0000 04001F02
	ds_bpermute_b32 v2, v2, v27                                // 000000743F60: DACC0000 02001B02
	ds_bpermute_b32 v6, v5, v3                                 // 000000743F68: DACC0000 06000305
	v_cndmask_b32_e32 v8, v1, v8, vcc_lo                       // 000000743F70: 02101101
	s_waitcnt lgkmcnt(2)                                       // 000000743F74: BF89FC27
	v_add_f32_e32 v4, v31, v4                                  // 000000743F78: 0608091F
	s_waitcnt lgkmcnt(1)                                       // 000000743F7C: BF89FC17
	v_add_f32_e32 v2, v27, v2                                  // 000000743F80: 0604051B
	s_waitcnt lgkmcnt(0)                                       // 000000743F84: BF89FC07
	v_add_f32_e32 v3, v3, v6                                   // 000000743F88: 06060D03
	ds_bpermute_b32 v7, v5, v4                                 // 000000743F8C: DACC0000 07000405
	ds_bpermute_b32 v5, v5, v2                                 // 000000743F94: DACC0000 05000205
	v_lshlrev_b32_e32 v8, 2, v8                                // 000000743F9C: 30101082
	s_waitcnt lgkmcnt(0)                                       // 000000743FA0: BF89FC07
	v_add_f32_e32 v2, v2, v5                                   // 000000743FA4: 06040B02
	ds_bpermute_b32 v5, v8, v3                                 // 000000743FA8: DACC0000 05000308
	s_waitcnt lgkmcnt(0)                                       // 000000743FB0: BF89FC07
	v_dual_add_f32 v3, v3, v5 :: v_dual_add_f32 v4, v4, v7     // 000000743FB4: C9080B03 03040F04
	ds_bpermute_b32 v7, v8, v2                                 // 000000743FBC: DACC0000 07000208
	ds_bpermute_b32 v6, v8, v4                                 // 000000743FC4: DACC0000 06000408
	v_xor_b32_e32 v8, 2, v1                                    // 000000743FCC: 3A100282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000743FD0: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 000000743FD4: 7C9810A0
	v_cndmask_b32_e32 v8, v1, v8, vcc_lo                       // 000000743FD8: 02101101
	v_lshlrev_b32_e32 v8, 2, v8                                // 000000743FDC: 30101082
	s_waitcnt lgkmcnt(1)                                       // 000000743FE0: BF89FC17
	v_add_f32_e32 v2, v2, v7                                   // 000000743FE4: 06040F02
	s_waitcnt lgkmcnt(0)                                       // 000000743FE8: BF89FC07
	v_add_f32_e32 v4, v4, v6                                   // 000000743FEC: 06080D04
	ds_bpermute_b32 v5, v8, v3                                 // 000000743FF0: DACC0000 05000308
	ds_bpermute_b32 v7, v8, v2                                 // 000000743FF8: DACC0000 07000208
	ds_bpermute_b32 v6, v8, v4                                 // 000000744000: DACC0000 06000408
	v_xor_b32_e32 v8, 1, v1                                    // 000000744008: 3A100281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000074400C: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 000000744010: 7C9810A0
	v_cndmask_b32_e32 v1, v1, v8, vcc_lo                       // 000000744014: 02021101
	v_lshlrev_b32_e32 v8, 2, v1                                // 000000744018: 30100282
	s_waitcnt lgkmcnt(1)                                       // 00000074401C: BF89FC17
	v_dual_add_f32 v1, v3, v5 :: v_dual_add_f32 v2, v2, v7     // 000000744020: C9080B03 01020F02
	s_waitcnt lgkmcnt(0)                                       // 000000744028: BF89FC07
	v_add_f32_e32 v3, v4, v6                                   // 00000074402C: 06060D04
	ds_bpermute_b32 v4, v8, v1                                 // 000000744030: DACC0000 04000108
	ds_bpermute_b32 v5, v8, v2                                 // 000000744038: DACC0000 05000208
	ds_bpermute_b32 v6, v8, v3                                 // 000000744040: DACC0000 06000308
	v_cmpx_eq_u32_e32 0, v23                                   // 000000744048: 7D942E80
	s_cbranch_execz 16                                         // 00000074404C: BFA50010 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xb90>
	.long 0xd72c0007                                           // 000000744050: D72C0007
	v_cndmask_b32_e32 v0, v21, v152, vcc_lo                    // 000000744054: 02013115
	s_waitcnt lgkmcnt(1)                                       // 000000744058: BF89FC17
	v_dual_add_f32 v1, v1, v4 :: v_dual_add_f32 v2, v2, v5     // 00000074405C: C9080901 01020B02
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000744064: BF8700A2
	v_mad_u32_u24 v7, v22, 12, v7                              // 000000744068: D60B0007 041D1916
	s_waitcnt lgkmcnt(0)                                       // 000000744070: BF89FC07
	v_dual_add_f32 v3, v3, v6 :: v_dual_add_nc_u32 v4, 0x400, v7// 000000744074: C9200D03 03040EFF 00000400
	ds_store_2addr_b32 v4, v1, v3 offset1:1                    // 000000744080: D8380100 00030104
	ds_store_b32 v7, v2 offset:1032                            // 000000744088: D8340408 00000207
	s_or_b32 exec_lo, exec_lo, s0                              // 000000744090: 8C7E007E
	.long 0xd7050001                                           // 000000744094: D7050001
	v_cndmask_b32_e32 v1, 0xab, v0, vcc_lo                     // 000000744098: 020200FF 000000AB
	.long 0x7f063880                                           // 0000007440A0: 7F063880
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000007440A4: BF890007
	s_barrier                                                  // 0000007440A8: BFBD0000
	buffer_gl0_inv                                             // 0000007440AC: E0AC0000 00000000
	.long 0xd7390003                                           // 0000007440B4: D7390003
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 0000007440B8: 02020289
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007440BC: BF870091
	.long 0xd7000001                                           // 0000007440C0: D7000001
	v_cndmask_b32_e32 v1, s2, v3, vcc_lo                       // 0000007440C4: 02020602
	v_add_co_ci_u32_e64 v2, null, s3, 0, s0                    // 0000007440C8: D5207C02 00010003
	.long 0xd44c0000                                           // 0000007440D0: D44C0000
	v_cndmask_b32_e32 v1, 12, v0, vcc_lo                       // 0000007440D4: 0202008C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000007440D8: BF8704A2
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 0000007440DC: 7CA8020C
	s_and_b32 s0, s0, vcc_lo                                   // 0000007440E0: 8B006A00
	s_and_saveexec_b32 s1, s0                                  // 0000007440E4: BE812000
	s_cbranch_execz 39                                         // 0000007440E8: BFA50027 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xc88>
	.long 0xd7054000                                           // 0000007440EC: D7054000
	v_cndmask_b32_e32 v0, v3, v131, vcc_lo                     // 0000007440F0: 02010703
	v_mul_u32_u24_e32 v3, 24, v3                               // 0000007440F4: 16060698
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007440F8: BF870092
	.long 0xd7041000                                           // 0000007440FC: D7041000
	v_cndmask_b32_e32 v1, v0, v0, vcc_lo                       // 000000744100: 02020100
	v_and_b32_e32 v0, 0xff, v0                                 // 000000744104: 360000FF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000074410C: BF870091
	v_lshl_add_u32 v3, v0, 2, v3                               // 000000744110: D6460003 040D0500
	v_add_nc_u32_e32 v5, 0x400, v3                             // 000000744118: 4A0A06FF 00000400
	v_mad_u64_u32 v[3:4], null, s12, v0, 0                     // 000000744120: D6FE7C03 0202000C
	ds_load_2addr_b32 v[6:7], v5 offset1:3                     // 000000744128: D8DC0300 06000005
	v_mad_u64_u32 v[4:5], null, s13, v0, v[4:5]                // 000000744130: D6FE7C04 0412000D
	.long 0xd73c0000                                           // 000000744138: D73C0000
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000074413C: 02020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000744140: BF870092
	.long 0xd73c0003                                           // 000000744144: D73C0003
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 000000744148: 02020682
	.long 0xd7006a03                                           // 00000074414C: D7006A03
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 000000744150: 02020608
	s_waitcnt lgkmcnt(0)                                       // 000000744154: BF89FC07
	v_add_f32_e32 v2, 0, v6                                    // 000000744158: 06040C80
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000074415C: BF870193
	v_add_co_ci_u32_e64 v4, null, s9, v4, vcc_lo               // 000000744160: D5207C04 01AA0809
	.long 0xd7006a00                                           // 000000744168: D7006A00
	v_cndmask_b32_e32 v1, v3, v0, vcc_lo                       // 00000074416C: 02020103
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000744170: BF870193
	v_add_f32_e32 v2, v2, v7                                   // 000000744174: 06040F02
	v_add_co_ci_u32_e64 v1, null, v4, v1, vcc_lo               // 000000744178: D5207C01 01AA0304
	global_store_b32 v[0:1], v2, off                           // 000000744180: DC6A0000 007C0200
	s_endpgm                                                   // 000000744188: BFB00000
		...

