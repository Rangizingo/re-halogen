0000000000a5bd00 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi0ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi>:
; _ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi0ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi():
	s_load_b256 s[4:11], s[0:1], null                          // 000000A5BD00: F40C0100 F8000000
	s_mul_hi_i32 s3, s2, 0x66666667                            // 000000A5BD08: 9703FF02 66666667
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000A5BD10: BF8704A9
	s_lshr_b32 s12, s3, 31                                     // 000000A5BD14: 850C9F03
	s_ashr_i32 s3, s3, 1                                       // 000000A5BD18: 86038103
	s_add_i32 s16, s3, s12                                     // 000000A5BD1C: 81100C03
	s_mov_b32 s3, exec_lo                                      // 000000A5BD20: BE83007E
	s_ashr_i32 s17, s16, 31                                    // 000000A5BD24: 86119F10
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A5BD28: BF870009
	s_lshl_b64 s[12:13], s[16:17], 2                           // 000000A5BD2C: 848C8210
	s_waitcnt lgkmcnt(0)                                       // 000000A5BD30: BF89FC07
	s_add_u32 s8, s8, s12                                      // 000000A5BD34: 80080C08
	s_addc_u32 s9, s9, s13                                     // 000000A5BD38: 82090D09
	s_load_b128 s[12:15], s[0:1], 0x20                         // 000000A5BD3C: F4080300 F8000020
	s_load_b32 s1, s[8:9], null                                // 000000A5BD44: F4000044 F8000000
	v_cmpx_gt_u32_e32 0x140, v0                                // 000000A5BD4C: 7D9800FF 00000140
	s_cbranch_execz 46                                         // 000000A5BD54: BFA5002E <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi0ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x110>
	s_mul_hi_i32 s0, s2, 0x51eb851f                            // 000000A5BD58: 9700FF02 51EB851F
	v_lshlrev_b32_e32 v4, 4, v0                                // 000000A5BD60: 30080084
	s_lshr_b32 s8, s0, 31                                      // 000000A5BD64: 85089F00
	s_ashr_i32 s0, s0, 4                                       // 000000A5BD68: 86008400
	v_or_b32_e32 v3, 0xffffff00, v0                            // 000000A5BD6C: 380600FF FFFFFF00
	s_add_i32 s0, s0, s8                                       // 000000A5BD74: 81000800
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000A5BD78: BF8700D9
	s_mul_i32 s8, s0, 0x1400                                   // 000000A5BD7C: 9608FF00 00001400
	s_mul_hi_i32 s0, s0, 0x1400                                // 000000A5BD84: 9700FF00 00001400
	s_add_u32 s6, s6, s8                                       // 000000A5BD8C: 80060806
	s_addc_u32 s0, s7, s0                                      // 000000A5BD90: 82000007
	.long 0xd7000601                                           // 000000A5BD94: D7000601
	v_cndmask_b32_e32 v1, s6, v4, vcc_lo                       // 000000A5BD98: 02020806
	v_add_co_ci_u32_e64 v2, null, s0, 0, s6                    // 000000A5BD9C: D5207C02 00190000
	s_mov_b32 s6, 0                                            // 000000A5BDA4: BE860080
	s_nop 0                                                    // 000000A5BDA8: BF800000
	s_nop 0                                                    // 000000A5BDAC: BF800000
	s_nop 0                                                    // 000000A5BDB0: BF800000
	s_nop 0                                                    // 000000A5BDB4: BF800000
	s_nop 0                                                    // 000000A5BDB8: BF800000
	s_nop 0                                                    // 000000A5BDBC: BF800000
	global_load_b128 v[5:8], v[1:2], off                       // 000000A5BDC0: DC5E0000 057C0001
	v_add_nc_u32_e32 v3, 0x100, v3                             // 000000A5BDC8: 4A0606FF 00000100
	.long 0xd7006a01                                           // 000000A5BDD0: D7006A01
	v_cndmask_b32_e32 v1, 0x1000, v1, vcc_lo                   // 000000A5BDD4: 020202FF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A5BDDC: BF870191
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 000000A5BDE0: D5207C02 01AA0480
	.long 0xd4490000                                           // 000000A5BDE8: D4490000
	v_cndmask_b32_e32 v1, 63, v3, vcc_lo                       // 000000A5BDEC: 020206BF
	s_or_b32 s6, s0, s6                                        // 000000A5BDF0: 8C060600
	s_waitcnt vmcnt(0)                                         // 000000A5BDF4: BF8903F7
	ds_store_b128 v4, v[5:8]                                   // 000000A5BDF8: DB7C0000 00000504
	v_add_nc_u32_e32 v4, 0x1000, v4                            // 000000A5BE00: 4A0808FF 00001000
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 000000A5BE08: 917E067E
	s_cbranch_execnz 65516                                     // 000000A5BE0C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi0ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0xc0>
	s_or_b32 exec_lo, exec_lo, s3                              // 000000A5BE10: 8C7E037E
	v_lshrrev_b32_e32 v20, 5, v0                               // 000000A5BE14: 32280085
	v_dual_mov_b32 v1, 0 :: v_dual_and_b32 v22, 31, v0         // 000000A5BE18: CA240080 0116009F
	s_mul_i32 s0, s16, -5                                      // 000000A5BE20: 9600C510
	s_waitcnt lgkmcnt(0)                                       // 000000A5BE24: BF89FC07
	s_mul_hi_i32 s6, s1, 0x12c000                              // 000000A5BE28: 9706FF01 0012C000
	v_mul_u32_u24_e32 v14, 20, v20                             // 000000A5BE30: 161C2894
	v_mov_b32_e32 v12, v1                                      // 000000A5BE34: 7E180301
	v_mov_b32_e32 v3, v1                                       // 000000A5BE38: 7E060301
	v_dual_mov_b32 v4, v1 :: v_dual_lshlrev_b32 v21, 2, v22    // 000000A5BE3C: CA220101 04142C82
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A5BE44: BF870004
	v_min_u32_e32 v15, 0x8c, v14                               // 000000A5BE48: 261E1CFF 0000008C
	v_mov_b32_e32 v2, v1                                       // 000000A5BE50: 7E040301
	v_mov_b32_e32 v5, v1                                       // 000000A5BE54: 7E0A0301
	v_mov_b32_e32 v6, v1                                       // 000000A5BE58: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 000000A5BE5C: 7E0E0301
	v_dual_mov_b32 v8, v1 :: v_dual_add_nc_u32 v23, 20, v15    // 000000A5BE60: CA200101 08161E94
	v_mov_b32_e32 v9, v1                                       // 000000A5BE68: 7E120301
	v_mov_b32_e32 v10, v1                                      // 000000A5BE6C: 7E140301
	v_mov_b32_e32 v11, v1                                      // 000000A5BE70: 7E160301
	v_mov_b32_e32 v13, v12                                     // 000000A5BE74: 7E1A030C
	v_cmp_lt_u32_e32 vcc_lo, v14, v23                          // 000000A5BE78: 7C922F0E
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A5BE7C: BF870003
	v_mov_b32_e32 v12, v11                                     // 000000A5BE80: 7E18030B
	v_mov_b32_e32 v11, v10                                     // 000000A5BE84: 7E16030A
	v_mov_b32_e32 v10, v9                                      // 000000A5BE88: 7E140309
	v_mov_b32_e32 v9, v8                                       // 000000A5BE8C: 7E120308
	v_mov_b32_e32 v8, v7                                       // 000000A5BE90: 7E100307
	v_mov_b32_e32 v7, v6                                       // 000000A5BE94: 7E0E0306
	v_mov_b32_e32 v6, v5                                       // 000000A5BE98: 7E0C0305
	v_mov_b32_e32 v5, v4                                       // 000000A5BE9C: 7E0A0304
	v_mov_b32_e32 v4, v3                                       // 000000A5BEA0: 7E080303
	v_mov_b32_e32 v3, v2                                       // 000000A5BEA4: 7E060302
	v_mov_b32_e32 v2, v1                                       // 000000A5BEA8: 7E040301
	s_add_i32 s2, s0, s2                                       // 000000A5BEAC: 81020200
	s_mul_i32 s7, s1, 0x12c000                                 // 000000A5BEB0: 9607FF01 0012C000
	s_mul_hi_i32 s8, s2, 0x3c000                               // 000000A5BEB8: 9708FF02 0003C000
	s_mul_i32 s9, s2, 0x3c000                                  // 000000A5BEC0: 9609FF02 0003C000
	s_barrier                                                  // 000000A5BEC8: BFBD0000
	buffer_gl0_inv                                             // 000000A5BECC: E0AC0000 00000000
	s_and_saveexec_b32 s3, vcc_lo                              // 000000A5BED4: BE83206A
	s_cbranch_execz 41                                         // 000000A5BED8: BFA50029 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi0ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x280>
	v_mul_u32_u24_e32 v2, 0x7800, v20                          // 000000A5BEDC: 160428FF 00007800
	s_add_u32 s0, s4, s7                                       // 000000A5BEE4: 80000704
	s_addc_u32 s17, s5, s6                                     // 000000A5BEE8: 82110605
	s_add_u32 s0, s0, s9                                       // 000000A5BEEC: 80000900
	s_addc_u32 s17, s17, s8                                    // 000000A5BEF0: 82110811
	.long 0xd7000002                                           // 000000A5BEF4: D7000002
	v_cndmask_b32_e32 v1, s0, v2, vcc_lo                       // 000000A5BEF8: 02020400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A5BEFC: BF870111
	v_add_co_ci_u32_e64 v3, null, s17, 0, s0                   // 000000A5BF00: D5207C03 00010011
	.long 0xd7000010                                           // 000000A5BF08: D7000010
	v_cndmask_b32_e32 v1, v2, v21, vcc_lo                      // 000000A5BF0C: 02022B02
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A5BF10: BF870001
	v_add_co_ci_u32_e64 v17, null, 0, v3, s0                   // 000000A5BF14: D5207C11 00020680
	s_clause 0xb                                               // 000000A5BF1C: BF85000B
	global_load_b32 v2, v[16:17], off                          // 000000A5BF20: DC520000 027C0010
	global_load_b32 v3, v[16:17], off offset:128               // 000000A5BF28: DC520080 037C0010
	global_load_b32 v4, v[16:17], off offset:256               // 000000A5BF30: DC520100 047C0010
	global_load_b32 v5, v[16:17], off offset:384               // 000000A5BF38: DC520180 057C0010
	global_load_b32 v6, v[16:17], off offset:512               // 000000A5BF40: DC520200 067C0010
	global_load_b32 v7, v[16:17], off offset:640               // 000000A5BF48: DC520280 077C0010
	global_load_b32 v8, v[16:17], off offset:768               // 000000A5BF50: DC520300 087C0010
	global_load_b32 v9, v[16:17], off offset:896               // 000000A5BF58: DC520380 097C0010
	global_load_b32 v10, v[16:17], off offset:1024             // 000000A5BF60: DC520400 0A7C0010
	global_load_b32 v11, v[16:17], off offset:1152             // 000000A5BF68: DC520480 0B7C0010
	global_load_b32 v12, v[16:17], off offset:1280             // 000000A5BF70: DC520500 0C7C0010
	global_load_b32 v13, v[16:17], off offset:1408             // 000000A5BF78: DC520580 0D7C0010
	s_or_b32 exec_lo, exec_lo, s3                              // 000000A5BF80: 8C7E037E
	v_dual_mov_b32 v25, 0 :: v_dual_mov_b32 v26, 0             // 000000A5BF84: CA100080 191A0080
	v_dual_mov_b32 v27, 0 :: v_dual_mov_b32 v28, 0             // 000000A5BF8C: CA100080 1B1C0080
	v_dual_mov_b32 v29, 0 :: v_dual_mov_b32 v30, 0             // 000000A5BF94: CA100080 1D1E0080
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v32, 0             // 000000A5BF9C: CA100080 1F200080
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v34, 0             // 000000A5BFA4: CA100080 21220080
	v_dual_mov_b32 v35, 0 :: v_dual_mov_b32 v36, 0             // 000000A5BFAC: CA100080 23240080
	v_dual_mov_b32 v37, 0 :: v_dual_mov_b32 v38, 0             // 000000A5BFB4: CA100080 25260080
	v_mov_b32_e32 v24, 0                                       // 000000A5BFBC: 7E300280
	s_and_saveexec_b32 s3, vcc_lo                              // 000000A5BFC0: BE83206A
	s_cbranch_execz 1989                                       // 000000A5BFC4: BFA507C5 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi0ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x21dc>
	v_lshl_or_b32 v1, v22, 3, 4                                // 000000A5BFC8: D6560001 02110716
	v_mad_u32_u24 v25, v22, 24, 0x2f0                          // 000000A5BFD0: D60B0019 03FD3116 000002F0
	s_add_u32 s18, s7, s9                                      // 000000A5BFDC: 80120907
	s_addc_u32 s19, s6, s8                                     // 000000A5BFE0: 82130806
	v_mul_i32_i24_e32 v26, 0xffffffe8, v22                     // 000000A5BFE4: 12342CFF FFFFFFE8
	v_mad_u32_u24 v19, v1, 3, 0x2f0                            // 000000A5BFEC: D60B0013 03FD0701 000002F0
	v_cmp_lt_u32_e32 vcc_lo, 5, v1                             // 000000A5BFF8: 7C920285
	v_lshrrev_b32_e32 v29, 5, v25                              // 000000A5BFFC: 323A3285
	v_mad_u32_u24 v27, 0x640, v20, v21                         // 000000A5C000: D60B001B 045628FF 00000640
	v_dual_mov_b32 v24, 0 :: v_dual_and_b32 v25, 0x7e0, v25    // 000000A5C00C: CA240080 181832FF 000007E0
	v_lshrrev_b32_e32 v28, 5, v19                              // 000000A5C018: 32382685
	v_mad_u64_u32 v[16:17], null, 0x600, v14, s[18:19]         // 000000A5C01C: D6FE7C10 004A1CFF 00000600
	v_mul_i32_i24_e32 v30, -3, v1                              // 000000A5C028: 123C02C3
	v_subrev_nc_u32_e32 v29, 24, v29                           // 000000A5C02C: 4E3A3A98
	v_add3_u32 v39, v26, v25, 0xfffffd34                       // 000000A5C030: D6550027 03FE331A FFFFFD34
	v_subrev_nc_u32_e32 v28, 24, v28                           // 000000A5C03C: 4E383898
	v_mul_u32_u24_e32 v18, 0x640, v20                          // 000000A5C040: 162428FF 00000640
	v_dual_mov_b32 v38, 0 :: v_dual_and_b32 v19, 0x7e0, v19    // 000000A5C048: CA240080 261226FF 000007E0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A5C054: BF8701A3
	v_dual_cndmask_b32 v1, 23, v28 :: v_dual_add_nc_u32 v44, 0x1400, v27// 000000A5C058: CA603897 012C36FF 00001400
	v_cmp_ne_u32_e32 vcc_lo, 0, v22                            // 000000A5C064: 7C9A2C80
	v_add3_u32 v40, v30, v19, 0xfffffd34                       // 000000A5C068: D6550028 03FE271E FFFFFD34
	v_sub_nc_u32_e32 v42, 0, v15                               // 000000A5C074: 4C541E80
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A5C078: BF870004
	v_dual_mov_b32 v37, 0 :: v_dual_add_nc_u32 v26, 1, v1      // 000000A5C07C: CA200080 251A0281
	v_cndmask_b32_e32 v25, 23, v29, vcc_lo                     // 000000A5C084: 02323A97
	.long 0xd7006a10                                           // 000000A5C088: D7006A10
	v_cndmask_b32_e32 v1, v16, v21, vcc_lo                     // 000000A5C08C: 02022B10
	v_subrev_nc_u32_e32 v28, 23, v1                            // 000000A5C090: 4E380297
	v_add_co_ci_u32_e64 v17, null, 0, v17, vcc_lo              // 000000A5C094: D5207C11 01AA2280
	v_cmp_gt_u32_e32 vcc_lo, 24, v26                           // 000000A5C09C: 7C983498
	v_lshl_add_u32 v1, v1, 2, v18                              // 000000A5C0A0: D6460001 04490501
	v_dual_mov_b32 v34, 0 :: v_dual_add_nc_u32 v43, 1, v14     // 000000A5C0A8: CA200080 222A1C81
	v_dual_mov_b32 v32, 0 :: v_dual_add_nc_u32 v45, 0x1800, v27// 000000A5C0B0: CA200080 202C36FF 00001800
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A5C0BC: BF8701B3
	v_dual_cndmask_b32 v19, v28, v26 :: v_dual_add_nc_u32 v48, 0x1400, v1// 000000A5C0C0: CA60351C 133002FF 00001400
	v_lshl_add_u32 v26, v25, 2, v18                            // 000000A5C0CC: D646001A 04490519
	v_dual_mov_b32 v31, 0 :: v_dual_add_nc_u32 v52, 0x1600, v1 // 000000A5C0D4: CA200080 1F3402FF 00001600
	v_lshl_add_u32 v28, v19, 2, v18                            // 000000A5C0E0: D646001C 04490513
	v_and_b32_e32 v18, 16, v0                                  // 000000A5C0E8: 36240090
	v_cmp_gt_i32_e32 vcc_lo, 23, v25                           // 000000A5C0EC: 7C883297
	v_dual_mov_b32 v35, 0 :: v_dual_add_nc_u32 v46, 0x1400, v26// 000000A5C0F0: CA200080 232E34FF 00001400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A5C0FC: BF870214
	v_add_nc_u32_e32 v49, 0x1400, v28                          // 000000A5C100: 4A6238FF 00001400
	v_lshl_or_b32 v41, v14, 5, v18                             // 000000A5C108: D6560029 04490B0E
	v_cndmask_b32_e64 v25, 0xffffffa4, 4, vcc_lo               // 000000A5C110: D5010019 01A908FF FFFFFFA4
	.long 0xd7006a10                                           // 000000A5C11C: D7006A10
	v_cndmask_b32_e32 v1, s4, v16, vcc_lo                      // 000000A5C120: 02022004
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A5C124: BF870191
	v_add_co_ci_u32_e64 v17, null, s5, v17, vcc_lo             // 000000A5C128: D5207C11 01AA2205
	v_dual_mov_b32 v36, 0 :: v_dual_add_nc_u32 v15, v26, v25   // 000000A5C130: CA200080 240E331A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A5C138: BF870093
	.long 0xd7006a12                                           // 000000A5C13C: D7006A12
	v_cndmask_b32_e32 v1, 0x600, v16, vcc_lo                   // 000000A5C140: 020220FF 00000600
	v_add_co_ci_u32_e64 v19, null, 0, v17, vcc_lo              // 000000A5C148: D5207C13 01AA2280
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A5C150: BF870003
	v_dual_mov_b32 v30, 0 :: v_dual_add_nc_u32 v47, 0x1400, v15// 000000A5C154: CA200080 1E2E1EFF 00001400
	v_dual_mov_b32 v33, 0 :: v_dual_add_nc_u32 v50, 0x1600, v26// 000000A5C160: CA200080 213234FF 00001600
	v_add_nc_u32_e32 v51, 0x1600, v15                          // 000000A5C16C: 4A661EFF 00001600
	v_add_nc_u32_e32 v53, 0x1600, v28                          // 000000A5C174: 4A6A38FF 00001600
	v_dual_mov_b32 v29, 0 :: v_dual_add_nc_u32 v54, 0x1800, v26// 000000A5C17C: CA200080 1D3634FF 00001800
	v_add_nc_u32_e32 v55, 0x1800, v15                          // 000000A5C188: 4A6E1EFF 00001800
	v_dual_mov_b32 v27, 0 :: v_dual_add_nc_u32 v56, 0x1800, v1 // 000000A5C190: CA200080 1B3802FF 00001800
	v_dual_mov_b32 v28, 0 :: v_dual_add_nc_u32 v57, 0x1800, v28// 000000A5C19C: CA200080 1C3838FF 00001800
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v25, 0             // 000000A5C1A8: CA100080 1A180080
	v_mov_b32_e32 v1, 0                                        // 000000A5C1B0: 7E020280
	s_mov_b32 s4, 0                                            // 000000A5C1B4: BE840080
	s_movk_i32 s5, 0x1eee                                      // 000000A5C1B8: B0051EEE
	s_branch 1814                                              // 000000A5C1BC: BFA00716 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi0ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2118>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A5C1C0: 8C7E007E
	ds_load_2addr_b32 v[58:59], v47 offset1:24                 // 000000A5C1C4: D8DC1800 3A00002F
	ds_load_2addr_b32 v[60:61], v49 offset1:24                 // 000000A5C1CC: D8DC1800 3C000031
	ds_load_2addr_b32 v[64:65], v46 offset1:24                 // 000000A5C1D4: D8DC1800 4000002E
	ds_load_2addr_b32 v[67:68], v48 offset1:24                 // 000000A5C1DC: D8DC1800 43000030
	ds_load_b128 v[14:17], v41                                 // 000000A5C1E4: DBFC0000 0E000029
	v_add_nc_u32_e32 v43, 1, v43                               // 000000A5C1EC: 4A565681
	.long 0xd7000012                                           // 000000A5C1F0: D7000012
	v_cndmask_b32_e32 v1, 0x600, v18, vcc_lo                   // 000000A5C1F4: 020224FF 00000600
	v_add_nc_u32_e32 v41, 32, v41                              // 000000A5C1FC: 4A5252A0
	v_add_co_ci_u32_e64 v19, null, 0, v19, s0                  // 000000A5C200: D5207C13 00022680
	s_waitcnt lgkmcnt(3)                                       // 000000A5C208: BF89FC37
	v_dual_mov_b32 v63, v58 :: v_dual_mov_b32 v66, v60         // 000000A5C20C: CA10013A 3F42013C
	s_waitcnt lgkmcnt(2)                                       // 000000A5C214: BF89FC27
	v_mov_b32_e32 v60, v65                                     // 000000A5C218: 7E780341
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A5C21C: BF8701B2
	.long 0xd73d0046                                           // 000000A5C220: D73D0046
	v_cndmask_b32_e32 v1, v39, v63, vcc_lo                     // 000000A5C224: 02027F27
	s_waitcnt lgkmcnt(1)                                       // 000000A5C228: BF89FC17
	.long 0xd73d0041                                           // 000000A5C22C: D73D0041
	v_cndmask_b32_e32 v1, v40, v66, vcc_lo                     // 000000A5C230: 02028528
	.long 0xd73d003a                                           // 000000A5C234: D73D003A
	v_cndmask_b32_e32 v1, v39, v59, vcc_lo                     // 000000A5C238: 02027727
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A5C23C: BF870193
	v_and_b32_e32 v66, 0xffff, v70                             // 000000A5C240: 36848CFF 0000FFFF
	v_bfe_u32 v67, v65, 9, 16                                  // 000000A5C248: D6100043 02411341
	v_bfe_u32 v71, v65, 3, 16                                  // 000000A5C250: D6100047 02410741
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A5C258: BF870004
	v_bfe_u32 v72, v58, 9, 16                                  // 000000A5C25C: D6100048 0241133A
	v_bfe_u32 v73, v58, 6, 16                                  // 000000A5C264: D6100049 02410D3A
	.long 0xd72c0042                                           // 000000A5C26C: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 000000A5C270: 020284FF 83DCD12D
	.long 0xd72c0043                                           // 000000A5C278: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000A5C27C: 020286FF 83DCD12D
	.long 0xd72c0047                                           // 000000A5C284: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000A5C288: 02028EFF 83DCD12D
	.long 0xd72c0048                                           // 000000A5C290: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000A5C294: 020290FF 83DCD12D
	v_bfe_u32 v74, v58, 3, 16                                  // 000000A5C29C: D610004A 0241073A
	v_and_b32_e32 v58, 0xffff, v58                             // 000000A5C2A4: 367474FF 0000FFFF
	.long 0xd72c0049                                           // 000000A5C2AC: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000A5C2B0: 020292FF 83DCD12D
	v_sad_u8 v66, v66, 0, 0x6400                               // 000000A5C2B8: D6220042 03FD0142 00006400
	v_sad_u8 v67, v67, 0, 0x6400                               // 000000A5C2C4: D6220043 03FD0143 00006400
	v_mov_b32_e32 v62, v68                                     // 000000A5C2D0: 7E7C0344
	ds_load_2addr_b32 v[63:64], v46 offset0:48 offset1:72      // 000000A5C2D4: D8DC4830 3F00002E
	ds_load_2addr_b32 v[68:69], v47 offset0:48 offset1:72      // 000000A5C2DC: D8DC4830 4400002F
	v_sad_u8 v71, v71, 0, 0x6400                               // 000000A5C2E4: D6220047 03FD0147 00006400
	v_lshlrev_b32_e32 v66, 16, v66                             // 000000A5C2F0: 30848490
	v_and_b32_e32 v67, 0xffff, v67                             // 000000A5C2F4: 368686FF 0000FFFF
	.long 0xd73d003b                                           // 000000A5C2FC: D73D003B
	v_cndmask_b32_e32 v1, v40, v61, vcc_lo                     // 000000A5C300: 02027B28
	v_bfe_u32 v60, v70, 9, 16                                  // 000000A5C304: D610003C 02411346
	v_bfe_u32 v61, v70, 6, 16                                  // 000000A5C30C: D610003D 02410D46
	v_bfe_u32 v62, v70, 3, 16                                  // 000000A5C314: D610003E 02410746
	v_bfe_u32 v70, v65, 6, 16                                  // 000000A5C31C: D6100046 02410D41
	v_and_b32_e32 v65, 0xffff, v65                             // 000000A5C324: 368282FF 0000FFFF
	.long 0xd72c003c                                           // 000000A5C32C: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000A5C330: 020278FF 83DCD12D
	.long 0xd72c003d                                           // 000000A5C338: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000A5C33C: 02027AFF 83DCD12D
	.long 0xd72c003e                                           // 000000A5C344: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000A5C348: 02027CFF 83DCD12D
	.long 0xd72c0046                                           // 000000A5C350: D72C0046
	v_cndmask_b32_e32 v1, 0x83dcd12d, v70, vcc_lo              // 000000A5C354: 02028CFF 83DCD12D
	.long 0xd72c0041                                           // 000000A5C35C: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000A5C360: 020282FF 83DCD12D
	v_sad_u8 v72, v72, 0, 0x6400                               // 000000A5C368: D6220048 03FD0148 00006400
	.long 0xd72c004a                                           // 000000A5C374: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000A5C378: 020294FF 83DCD12D
	.long 0xd72c003a                                           // 000000A5C380: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A5C384: 020274FF 83DCD12D
	v_sad_u8 v60, v60, 0, 0x6400                               // 000000A5C38C: D622003C 03FD013C 00006400
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000A5C398: D622003D 03FD013D 00006400
	v_sad_u8 v62, v62, 0, 0x6400                               // 000000A5C3A4: D622003E 03FD013E 00006400
	v_sad_u8 v70, v70, 0, 0x6400                               // 000000A5C3B0: D6220046 03FD0146 00006400
	v_sad_u8 v65, v65, 0, 0x6400                               // 000000A5C3BC: D6220041 03FD0141 00006400
	v_and_b32_e32 v60, 0xffff, v60                             // 000000A5C3C8: 367878FF 0000FFFF
	v_bfe_u32 v75, v59, 9, 16                                  // 000000A5C3D0: D610004B 0241133B
	v_and_or_b32 v62, 0xffff, v62, v66                         // 000000A5C3D8: D657003E 050A7CFF 0000FFFF
	v_lshl_or_b32 v66, v70, 16, v67                            // 000000A5C3E4: D6560042 050D2146
	v_and_b32_e32 v67, 0xffff, v72                             // 000000A5C3EC: 368690FF 0000FFFF
	v_lshl_or_b32 v60, v61, 16, v60                            // 000000A5C3F4: D656003C 04F1213D
	v_sad_u8 v61, v73, 0, 0x6400                               // 000000A5C3FC: D622003D 03FD0149 00006400
	v_pk_fma_f16 v70, v62, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A5C408: CC0E0046 0BFC0B3E 0000C931
	v_bfe_u32 v62, v59, 3, 16                                  // 000000A5C414: D610003E 0241073B
	v_bfe_u32 v76, v59, 6, 16                                  // 000000A5C41C: D610004C 02410D3B
	v_pk_fma_f16 v60, v60, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A5C424: CC0E003C 0BFC0B3C 0000C931
	v_lshlrev_b32_e32 v65, 16, v65                             // 000000A5C430: 30828290
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000A5C434: D622003A 03FD013A 00006400
	s_waitcnt lgkmcnt(2)                                       // 000000A5C440: BF89FC27
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A5C444: BF870193
	v_dot2acc_f32_f16 v24, v60, v14                            // 000000A5C448: 04301D3C
	v_and_or_b32 v65, 0xffff, v71, v65                         // 000000A5C44C: D6570041 05068EFF 0000FFFF
	v_pk_fma_f16 v71, v66, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A5C458: CC0E0047 0BFC0B42 0000C931
	.long 0xd72c0042                                           // 000000A5C464: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000A5C468: 020298FF 83DCD12D
	v_lshlrev_b32_e32 v58, 16, v58                             // 000000A5C470: 30747490
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A5C474: BF870004
	v_pk_fma_f16 v72, v65, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A5C478: CC0E0048 0BFC0B41 0000C931
	v_sad_u8 v65, v74, 0, 0x6400                               // 000000A5C484: D6220041 03FD014A 00006400
	.long 0xd72c004a                                           // 000000A5C490: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000A5C494: 02027CFF 83DCD12D
	s_waitcnt lgkmcnt(0)                                       // 000000A5C49C: BF89FC07
	v_mov_b32_e32 v62, v68                                     // 000000A5C4A0: 7E7C0344
	v_lshl_or_b32 v60, v61, 16, v67                            // 000000A5C4A4: D656003C 050D213D
	.long 0xd72c003d                                           // 000000A5C4AC: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000A5C4B0: 020296FF 83DCD12D
	v_and_or_b32 v73, 0xffff, v65, v58                         // 000000A5C4B8: D6570049 04EA82FF 0000FFFF
	v_sad_u8 v75, v66, 0, 0x6400                               // 000000A5C4C4: D622004B 03FD0142 00006400
	.long 0xd73d0041                                           // 000000A5C4D0: D73D0041
	v_cndmask_b32_e32 v1, v39, v62, vcc_lo                     // 000000A5C4D4: 02027D27
	v_pk_fma_f16 v60, v60, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A5C4D8: CC0E003C 0BFC0B3C 0000C931
	v_and_b32_e32 v59, 0xffff, v59                             // 000000A5C4E4: 367676FF 0000FFFF
	v_pk_fma_f16 v63, v73, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A5C4EC: CC0E003F 0BFC0B49 0000C931
	v_dot2acc_f32_f16 v24, v70, v15                            // 000000A5C4F8: 04301F46
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000A5C4FC: D622003D 03FD013D 00006400
	v_dot2acc_f32_f16 v38, v60, v14                            // 000000A5C508: 044C1D3C
	.long 0xd72c0043                                           // 000000A5C50C: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000A5C510: 020276FF 83DCD12D
	ds_load_2addr_b32 v[58:59], v49 offset0:48 offset1:72      // 000000A5C518: D8DC4830 3A000031
	v_bfe_u32 v60, v65, 9, 16                                  // 000000A5C520: D610003C 02411341
	v_and_b32_e32 v68, 0xffff, v61                             // 000000A5C528: 36887AFF 0000FFFF
	ds_load_2addr_b32 v[61:62], v48 offset0:48 offset1:72      // 000000A5C530: D8DC4830 3D000030
	v_dot2acc_f32_f16 v38, v63, v15                            // 000000A5C538: 044C1F3F
	v_mov_b32_e32 v70, v64                                     // 000000A5C53C: 7E8C0340
	.long 0xd72c003f                                           // 000000A5C540: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000A5C544: 020278FF 83DCD12D
	v_sad_u8 v67, v67, 0, 0x6400                               // 000000A5C54C: D6220043 03FD0143 00006400
	v_lshl_or_b32 v66, v75, 16, v68                            // 000000A5C558: D6560042 0511214B
	v_sad_u8 v68, v74, 0, 0x6400                               // 000000A5C560: D6220044 03FD014A 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000A5C56C: BF8700B2
	v_pk_fma_f16 v66, v66, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A5C570: CC0E0042 0BFC0B42 0000C931
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000A5C57C: D622003F 03FD013F 00006400
	s_waitcnt lgkmcnt(1)                                       // 000000A5C588: BF89FC17
	v_dual_mov_b32 v60, v58 :: v_dual_and_b32 v63, 0xffff, v63 // 000000A5C58C: CA24013A 3C3E7EFF 0000FFFF
	s_waitcnt lgkmcnt(0)                                       // 000000A5C598: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000A5C59C: BF870131
	.long 0xd73d003c                                           // 000000A5C5A0: D73D003C
	v_cndmask_b32_e32 v1, v40, v60, vcc_lo                     // 000000A5C5A4: 02027928
	v_and_b32_e32 v61, 0xffff, v65                             // 000000A5C5A8: 367A82FF 0000FFFF
	v_dual_dot2acc_f32_f16 v24, v71, v16 :: v_dual_lshlrev_b32 v67, 16, v67// 000000A5C5B0: CB222147 18428690
	.long 0xd72c003d                                           // 000000A5C5B8: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000A5C5BC: 02027AFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A5C5C4: BF8701B2
	v_and_or_b32 v67, 0xffff, v68, v67                         // 000000A5C5C8: D6570043 050E88FF 0000FFFF
	v_bfe_u32 v68, v65, 6, 16                                  // 000000A5C5D4: D6100044 02410D41
	v_bfe_u32 v65, v65, 3, 16                                  // 000000A5C5DC: D6100041 02410741
	v_pk_fma_f16 v67, v67, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A5C5E4: CC0E0043 0BFC0B43 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000A5C5F0: BF870253
	.long 0xd72c003a                                           // 000000A5C5F4: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 000000A5C5F8: 020288FF 83DCD12D
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000A5C600: D622003D 03FD013D 00006400
	v_dot2acc_f32_f16 v38, v66, v16                            // 000000A5C60C: 044C2142
	v_bfe_u32 v66, v60, 9, 16                                  // 000000A5C610: D6100042 0241133C
	.long 0xd72c0041                                           // 000000A5C618: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000A5C61C: 020282FF 83DCD12D
	v_lshlrev_b32_e32 v61, 16, v61                             // 000000A5C624: 307A7A90
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000A5C628: BF8701C4
	v_dot2acc_f32_f16 v38, v67, v17                            // 000000A5C62C: 044C2343
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000A5C630: D622003A 03FD013A 00006400
	v_and_b32_e32 v67, 0xffff, v60                             // 000000A5C63C: 368678FF 0000FFFF
	v_sad_u8 v65, v65, 0, 0x6400                               // 000000A5C644: D6220041 03FD0141 00006400
	v_lshl_or_b32 v58, v58, 16, v63                            // 000000A5C650: D656003A 04FD213A
	.long 0xd72c003f                                           // 000000A5C658: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 000000A5C65C: 020284FF 83DCD12D
	v_bfe_u32 v66, v60, 6, 16                                  // 000000A5C664: D6100042 02410D3C
	v_bfe_u32 v60, v60, 3, 16                                  // 000000A5C66C: D610003C 0241073C
	.long 0xd72c0043                                           // 000000A5C674: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000A5C678: 020286FF 83DCD12D
	v_pk_fma_f16 v58, v58, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A5C680: CC0E003A 0BFC0B3A 0000C931
	v_and_or_b32 v61, 0xffff, v65, v61                         // 000000A5C68C: D657003D 04F682FF 0000FFFF
	.long 0xd72c0042                                           // 000000A5C698: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 000000A5C69C: 020284FF 83DCD12D
	.long 0xd72c003c                                           // 000000A5C6A4: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000A5C6A8: 020278FF 83DCD12D
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000A5C6B0: D622003F 03FD013F 00006400
	v_dot2acc_f32_f16 v37, v58, v14                            // 000000A5C6BC: 044A1D3A
	v_pk_fma_f16 v61, v61, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A5C6C0: CC0E003D 0BFC0B3D 0000C931
	v_sad_u8 v67, v67, 0, 0x6400                               // 000000A5C6CC: D6220043 03FD0143 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A5C6D8: BF870004
	v_and_b32_e32 v68, 0xffff, v63                             // 000000A5C6DC: 36887EFF 0000FFFF
	.long 0xd73d003f                                           // 000000A5C6E4: D73D003F
	v_cndmask_b32_e32 v1, v39, v69, vcc_lo                     // 000000A5C6E8: 02028B27
	v_sad_u8 v66, v66, 0, 0x6400                               // 000000A5C6EC: D6220042 03FD0142 00006400
	v_sad_u8 v60, v60, 0, 0x6400                               // 000000A5C6F8: D622003C 03FD013C 00006400
	v_lshlrev_b32_e32 v64, 16, v67                             // 000000A5C704: 30808690
	v_dual_dot2acc_f32_f16 v24, v72, v17 :: v_dual_dot2acc_f32_f16 v37, v61, v15// 000000A5C708: CB182348 18241F3D
	v_bfe_u32 v58, v63, 9, 16                                  // 000000A5C710: D610003A 0241133F
	v_lshl_or_b32 v65, v66, 16, v68                            // 000000A5C718: D6560041 05112142
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A5C720: BF870004
	v_and_or_b32 v64, 0xffff, v60, v64                         // 000000A5C724: D6570040 050278FF 0000FFFF
	v_mov_b32_e32 v60, v62                                     // 000000A5C730: 7E78033E
	v_bfe_u32 v62, v63, 6, 16                                  // 000000A5C734: D610003E 02410D3F
	.long 0xd72c003a                                           // 000000A5C73C: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A5C740: 020274FF 83DCD12D
	v_pk_fma_f16 v65, v65, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A5C748: CC0E0041 0BFC0B41 0000C931
	v_pk_fma_f16 v68, v64, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A5C754: CC0E0044 0BFC0B40 0000C931
	.long 0xd73d003c                                           // 000000A5C760: D73D003C
	v_cndmask_b32_e32 v1, v40, v59, vcc_lo                     // 000000A5C764: 02027728
	v_and_b32_e32 v59, 0xffff, v63                             // 000000A5C768: 36767EFF 0000FFFF
	.long 0xd72c003e                                           // 000000A5C770: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000A5C774: 02027CFF 83DCD12D
	v_dot2acc_f32_f16 v37, v65, v16                            // 000000A5C77C: 044A2141
	v_bfe_u32 v61, v63, 3, 16                                  // 000000A5C780: D610003D 0241073F
	v_sad_u8 v63, v58, 0, 0x6400                               // 000000A5C788: D622003F 03FD013A 00006400
	.long 0xd72c0041                                           // 000000A5C794: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000A5C798: 020276FF 83DCD12D
	ds_load_2addr_b32 v[58:59], v47 offset0:96 offset1:120     // 000000A5C7A0: D8DC7860 3A00002F
	v_bfe_u32 v64, v60, 9, 16                                  // 000000A5C7A8: D6100040 0241133C
	.long 0xd72c0043                                           // 000000A5C7B0: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000A5C7B4: 02027AFF 83DCD12D
	v_sad_u8 v69, v62, 0, 0x6400                               // 000000A5C7BC: D6220045 03FD013E 00006400
	ds_load_2addr_b32 v[61:62], v46 offset0:96 offset1:120     // 000000A5C7C8: D8DC7860 3D00002E
	v_bfe_u32 v66, v60, 6, 16                                  // 000000A5C7D0: D6100042 02410D3C
	.long 0xd72c0040                                           // 000000A5C7D8: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000A5C7DC: 020280FF 83DCD12D
	v_bfe_u32 v70, v60, 3, 16                                  // 000000A5C7E4: D6100046 0241073C
	v_and_b32_e32 v60, 0xffff, v60                             // 000000A5C7EC: 367878FF 0000FFFF
	v_and_b32_e32 v63, 0xffff, v63                             // 000000A5C7F4: 367E7EFF 0000FFFF
	v_sad_u8 v65, v65, 0, 0x6400                               // 000000A5C7FC: D6220041 03FD0141 00006400
	.long 0xd72c0048                                           // 000000A5C808: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 000000A5C80C: 020284FF 83DCD12D
	v_sad_u8 v67, v67, 0, 0x6400                               // 000000A5C814: D6220043 03FD0143 00006400
	.long 0xd72c0049                                           // 000000A5C820: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000A5C824: 020278FF 83DCD12D
	v_lshl_or_b32 v69, v69, 16, v63                            // 000000A5C82C: D6560045 04FD2145
	v_lshlrev_b32_e32 v65, 16, v65                             // 000000A5C834: 30828290
	v_sad_u8 v71, v64, 0, 0x6400                               // 000000A5C838: D6220047 03FD0140 00006400
	.long 0xd72c0046                                           // 000000A5C844: D72C0046
	v_cndmask_b32_e32 v1, 0x83dcd12d, v70, vcc_lo              // 000000A5C848: 02028CFF 83DCD12D
	ds_load_2addr_b32 v[63:64], v49 offset0:96 offset1:120     // 000000A5C850: D8DC7860 3F000031
	v_pk_fma_f16 v69, v69, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A5C858: CC0E0045 0BFC0B45 0000C931
	s_waitcnt lgkmcnt(2)                                       // 000000A5C864: BF89FC27
	v_mov_b32_e32 v60, v58                                     // 000000A5C868: 7E78033A
	v_and_or_b32 v65, 0xffff, v67, v65                         // 000000A5C86C: D6570041 050686FF 0000FFFF
	v_and_b32_e32 v71, 0xffff, v71                             // 000000A5C878: 368E8EFF 0000FFFF
	v_sad_u8 v58, v73, 0, 0x6400                               // 000000A5C880: D622003A 03FD0149 00006400
	v_sad_u8 v72, v72, 0, 0x6400                               // 000000A5C88C: D6220048 03FD0148 00006400
	s_waitcnt lgkmcnt(1)                                       // 000000A5C898: BF89FC17
	.long 0xd73d003c                                           // 000000A5C89C: D73D003C
	v_cndmask_b32_e32 v1, v39, v60, vcc_lo                     // 000000A5C8A0: 02027927
	v_pk_fma_f16 v65, v65, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A5C8A4: CC0E0041 0BFC0B41 0000C931
	v_sad_u8 v61, v70, 0, 0x6400                               // 000000A5C8B0: D622003D 03FD0146 00006400
	v_lshlrev_b32_e32 v58, 16, v58                             // 000000A5C8BC: 30747490
	v_lshl_or_b32 v70, v72, 16, v71                            // 000000A5C8C0: D6560046 051D2148
	v_dot2acc_f32_f16 v36, v69, v14                            // 000000A5C8C8: 04481D45
	ds_load_2addr_b32 v[66:67], v48 offset0:96 offset1:120     // 000000A5C8CC: D8DC7860 42000030
	v_dot2acc_f32_f16 v37, v68, v17                            // 000000A5C8D4: 044A2344
	v_and_or_b32 v58, 0xffff, v61, v58                         // 000000A5C8D8: D657003A 04EA7AFF 0000FFFF
	v_pk_fma_f16 v61, v70, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A5C8E4: CC0E003D 0BFC0B46 0000C931
	v_dot2acc_f32_f16 v36, v65, v15                            // 000000A5C8F0: 04481F41
	v_bfe_u32 v68, v60, 9, 16                                  // 000000A5C8F4: D6100044 0241133C
	s_waitcnt lgkmcnt(1)                                       // 000000A5C8FC: BF89FC17
	v_mov_b32_e32 v65, v63                                     // 000000A5C900: 7E82033F
	v_pk_fma_f16 v58, v58, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A5C904: CC0E003A 0BFC0B3A 0000C931
	v_dot2acc_f32_f16 v36, v61, v16                            // 000000A5C910: 0448213D
	v_and_b32_e32 v61, 0xffff, v60                             // 000000A5C914: 367A78FF 0000FFFF
	.long 0xd72c003f                                           // 000000A5C91C: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 000000A5C920: 020288FF 83DCD12D
	v_bfe_u32 v68, v60, 6, 16                                  // 000000A5C928: D6100044 02410D3C
	v_bfe_u32 v60, v60, 3, 16                                  // 000000A5C930: D610003C 0241073C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A5C938: BF870114
	.long 0xd72c003d                                           // 000000A5C93C: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000A5C940: 02027AFF 83DCD12D
	.long 0xd72c003c                                           // 000000A5C948: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000A5C94C: 020278FF 83DCD12D
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000A5C954: D622003F 03FD013F 00006400
	s_waitcnt lgkmcnt(0)                                       // 000000A5C960: BF89FC07
	.long 0xd73d0041                                           // 000000A5C964: D73D0041
	v_cndmask_b32_e32 v1, v40, v65, vcc_lo                     // 000000A5C968: 02028328
	.long 0xd72c0042                                           // 000000A5C96C: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 000000A5C970: 020288FF 83DCD12D
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000A5C978: D622003D 03FD013D 00006400
	v_and_b32_e32 v63, 0xffff, v63                             // 000000A5C984: 367E7EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A5C98C: BF870224
	v_bfe_u32 v68, v65, 6, 16                                  // 000000A5C990: D6100044 02410D41
	v_bfe_u32 v69, v65, 3, 16                                  // 000000A5C998: D6100045 02410741
	v_lshlrev_b32_e32 v61, 16, v61                             // 000000A5C9A0: 307A7A90
	v_dot2acc_f32_f16 v36, v58, v17                            // 000000A5C9A4: 0448233A
	v_bfe_u32 v58, v65, 9, 16                                  // 000000A5C9A8: D610003A 02411341
	v_sad_u8 v66, v66, 0, 0x6400                               // 000000A5C9B0: D6220042 03FD0142 00006400
	v_and_b32_e32 v65, 0xffff, v65                             // 000000A5C9BC: 368282FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A5C9C4: BF870193
	.long 0xd72c003a                                           // 000000A5C9C8: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A5C9CC: 020274FF 83DCD12D
	v_lshl_or_b32 v63, v66, 16, v63                            // 000000A5C9D4: D656003F 04FD2142
	v_sad_u8 v66, v60, 0, 0x6400                               // 000000A5C9DC: D6220042 03FD013C 00006400
	v_mov_b32_e32 v60, v62                                     // 000000A5C9E8: 7E78033E
	.long 0xd72c003e                                           // 000000A5C9EC: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 000000A5C9F0: 020288FF 83DCD12D
	.long 0xd72c0044                                           // 000000A5C9F8: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 000000A5C9FC: 02028AFF 83DCD12D
	v_pk_fma_f16 v63, v63, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A5CA04: CC0E003F 0BFC0B3F 0000C931
	.long 0xd72c0041                                           // 000000A5CA10: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000A5CA14: 020282FF 83DCD12D
	v_sad_u8 v69, v58, 0, 0x6400                               // 000000A5CA1C: D6220045 03FD013A 00006400
	.long 0xd73d003a                                           // 000000A5CA28: D73D003A
	v_cndmask_b32_e32 v1, v39, v59, vcc_lo                     // 000000A5CA2C: 02027727
	v_and_or_b32 v59, 0xffff, v66, v61                         // 000000A5CA30: D657003B 04F684FF 0000FFFF
	v_dot2acc_f32_f16 v35, v63, v14                            // 000000A5CA3C: 04461D3F
	v_sad_u8 v62, v62, 0, 0x6400                               // 000000A5CA40: D622003E 03FD013E 00006400
	v_and_b32_e32 v61, 0xffff, v69                             // 000000A5CA4C: 367A8AFF 0000FFFF
	v_sad_u8 v66, v68, 0, 0x6400                               // 000000A5CA54: D6220042 03FD0144 00006400
	v_bfe_u32 v68, v58, 9, 16                                  // 000000A5CA60: D6100044 0241133A
	v_pk_fma_f16 v59, v59, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A5CA68: CC0E003B 0BFC0B3B 0000C931
	v_sad_u8 v60, v65, 0, 0x6400                               // 000000A5CA74: D622003C 03FD0141 00006400
	v_lshl_or_b32 v61, v62, 16, v61                            // 000000A5CA80: D656003D 04F5213E
	v_mov_b32_e32 v65, v67                                     // 000000A5CA88: 7E820343
	.long 0xd72c003e                                           // 000000A5CA8C: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 000000A5CA90: 020288FF 83DCD12D
	v_dot2acc_f32_f16 v35, v59, v15                            // 000000A5CA98: 04461F3B
	v_bfe_u32 v63, v58, 6, 16                                  // 000000A5CA9C: D610003F 02410D3A
	v_pk_fma_f16 v68, v61, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A5CAA4: CC0E0044 0BFC0B3D 0000C931
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000A5CAB0: BF870251
	v_dot2acc_f32_f16 v35, v68, v16                            // 000000A5CAB4: 04462144
	v_lshlrev_b32_e32 v60, 16, v60                             // 000000A5CAB8: 30787890
	v_sad_u8 v59, v62, 0, 0x6400                               // 000000A5CABC: D622003B 03FD013E 00006400
	v_and_b32_e32 v62, 0xffff, v58                             // 000000A5CAC8: 367C74FF 0000FFFF
	v_bfe_u32 v58, v58, 3, 16                                  // 000000A5CAD0: D610003A 0241073A
	v_and_or_b32 v66, 0xffff, v66, v60                         // 000000A5CAD8: D6570042 04F284FF 0000FFFF
	.long 0xd73d003c                                           // 000000A5CAE4: D73D003C
	v_cndmask_b32_e32 v1, v40, v64, vcc_lo                     // 000000A5CAE8: 02028128
	.long 0xd72c003d                                           // 000000A5CAEC: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000A5CAF0: 02027EFF 83DCD12D
	.long 0xd72c003e                                           // 000000A5CAF8: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000A5CAFC: 02027CFF 83DCD12D
	v_and_b32_e32 v65, 0xffff, v59                             // 000000A5CB04: 368276FF 0000FFFF
	.long 0xd72c0043                                           // 000000A5CB0C: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A5CB10: 020274FF 83DCD12D
	ds_load_2addr_b32 v[58:59], v47 offset0:144 offset1:168    // 000000A5CB18: D8DCA890 3A00002F
	v_bfe_u32 v63, v60, 9, 16                                  // 000000A5CB20: D610003F 0241133C
	v_bfe_u32 v64, v60, 6, 16                                  // 000000A5CB28: D6100040 02410D3C
	v_pk_fma_f16 v69, v66, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A5CB30: CC0E0045 0BFC0B42 0000C931
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000A5CB3C: D622003D 03FD013D 00006400
	v_bfe_u32 v66, v60, 3, 16                                  // 000000A5CB48: D6100042 0241073C
	.long 0xd72c003f                                           // 000000A5CB50: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000A5CB54: 02027EFF 83DCD12D
	v_sad_u8 v70, v62, 0, 0x6400                               // 000000A5CB5C: D6220046 03FD013E 00006400
	.long 0xd72c0048                                           // 000000A5CB68: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000A5CB6C: 020280FF 83DCD12D
	v_lshl_or_b32 v65, v61, 16, v65                            // 000000A5CB74: D6560041 0505213D
	ds_load_2addr_b32 v[61:62], v46 offset0:144 offset1:168    // 000000A5CB7C: D8DCA890 3D00002E
	v_and_b32_e32 v60, 0xffff, v60                             // 000000A5CB84: 367878FF 0000FFFF
	v_sad_u8 v73, v67, 0, 0x6400                               // 000000A5CB8C: D6220049 03FD0143 00006400
	.long 0xd72c004a                                           // 000000A5CB98: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 000000A5CB9C: 020284FF 83DCD12D
	v_sad_u8 v71, v63, 0, 0x6400                               // 000000A5CBA4: D6220047 03FD013F 00006400
	ds_load_2addr_b32 v[63:64], v49 offset0:144 offset1:168    // 000000A5CBB0: D8DCA890 3F000031
	ds_load_2addr_b32 v[66:67], v48 offset0:144 offset1:168    // 000000A5CBB8: D8DCA890 42000030
	.long 0xd72c003c                                           // 000000A5CBC0: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000A5CBC4: 020278FF 83DCD12D
	v_lshlrev_b32_e32 v70, 16, v70                             // 000000A5CBCC: 308C8C90
	v_and_b32_e32 v71, 0xffff, v71                             // 000000A5CBD0: 368E8EFF 0000FFFF
	v_pk_fma_f16 v65, v65, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A5CBD8: CC0E0041 0BFC0B41 0000C931
	v_sad_u8 v72, v72, 0, 0x6400                               // 000000A5CBE4: D6220048 03FD0148 00006400
	v_dot2acc_f32_f16 v35, v69, v17                            // 000000A5CBF0: 04462345
	v_and_or_b32 v70, 0xffff, v73, v70                         // 000000A5CBF4: D6570046 051A92FF 0000FFFF
	v_sad_u8 v68, v60, 0, 0x6400                               // 000000A5CC00: D6220044 03FD013C 00006400
	s_waitcnt lgkmcnt(3)                                       // 000000A5CC0C: BF89FC37
	v_mov_b32_e32 v60, v58                                     // 000000A5CC10: 7E78033A
	v_lshl_or_b32 v71, v72, 16, v71                            // 000000A5CC14: D6560047 051D2148
	v_sad_u8 v58, v74, 0, 0x6400                               // 000000A5CC1C: D622003A 03FD014A 00006400
	v_pk_fma_f16 v70, v70, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A5CC28: CC0E0046 0BFC0B46 0000C931
	v_lshlrev_b32_e32 v68, 16, v68                             // 000000A5CC34: 30888890
	s_waitcnt lgkmcnt(2)                                       // 000000A5CC38: BF89FC27
	.long 0xd73d003c                                           // 000000A5CC3C: D73D003C
	v_cndmask_b32_e32 v1, v39, v60, vcc_lo                     // 000000A5CC40: 02027927
	v_dot2acc_f32_f16 v34, v65, v14                            // 000000A5CC44: 04441D41
	v_pk_fma_f16 v61, v71, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A5CC48: CC0E003D 0BFC0B47 0000C931
	s_waitcnt lgkmcnt(1)                                       // 000000A5CC54: BF89FC17
	v_mov_b32_e32 v65, v63                                     // 000000A5CC58: 7E82033F
	v_and_or_b32 v58, 0xffff, v58, v68                         // 000000A5CC5C: D657003A 051274FF 0000FFFF
	v_bfe_u32 v63, v60, 9, 16                                  // 000000A5CC68: D610003F 0241133C
	s_waitcnt lgkmcnt(0)                                       // 000000A5CC70: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000A5CC74: BF870243
	.long 0xd73d0041                                           // 000000A5CC78: D73D0041
	v_cndmask_b32_e32 v1, v40, v65, vcc_lo                     // 000000A5CC7C: 02028328
	v_dot2acc_f32_f16 v34, v70, v15                            // 000000A5CC80: 04441F46
	v_pk_fma_f16 v68, v58, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A5CC84: CC0E0044 0BFC0B3A 0000C931
	v_bfe_u32 v58, v60, 6, 16                                  // 000000A5CC90: D610003A 02410D3C
	v_bfe_u32 v66, v65, 9, 16                                  // 000000A5CC98: D6100042 02411341
	v_bfe_u32 v69, v65, 6, 16                                  // 000000A5CCA0: D6100045 02410D41
	v_bfe_u32 v70, v65, 3, 16                                  // 000000A5CCA8: D6100046 02410741
	v_dual_dot2acc_f32_f16 v34, v61, v16 :: v_dual_and_b32 v65, 0xffff, v65// 000000A5CCB0: CB24213D 224082FF 0000FFFF
	.long 0xd72c003d                                           // 000000A5CCBC: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000A5CCC0: 02027EFF 83DCD12D
	v_and_b32_e32 v63, 0xffff, v60                             // 000000A5CCC8: 367E78FF 0000FFFF
	v_bfe_u32 v60, v60, 3, 16                                  // 000000A5CCD0: D610003C 0241073C
	.long 0xd72c0042                                           // 000000A5CCD8: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 000000A5CCDC: 020284FF 83DCD12D
	.long 0xd72c0041                                           // 000000A5CCE4: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000A5CCE8: 020282FF 83DCD12D
	.long 0xd72c003a                                           // 000000A5CCF0: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A5CCF4: 020274FF 83DCD12D
	.long 0xd72c003f                                           // 000000A5CCFC: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000A5CD00: 02027EFF 83DCD12D
	.long 0xd72c003c                                           // 000000A5CD08: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000A5CD0C: 020278FF 83DCD12D
	.long 0xd72c0045                                           // 000000A5CD14: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 000000A5CD18: 02028AFF 83DCD12D
	.long 0xd72c0046                                           // 000000A5CD20: D72C0046
	v_cndmask_b32_e32 v1, 0x83dcd12d, v70, vcc_lo              // 000000A5CD24: 02028CFF 83DCD12D
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000A5CD2C: D622003D 03FD013D 00006400
	v_sad_u8 v66, v66, 0, 0x6400                               // 000000A5CD38: D6220042 03FD0142 00006400
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000A5CD44: D622003A 03FD013A 00006400
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000A5CD50: D622003F 03FD013F 00006400
	v_sad_u8 v71, v60, 0, 0x6400                               // 000000A5CD5C: D6220047 03FD013C 00006400
	v_sad_u8 v60, v65, 0, 0x6400                               // 000000A5CD68: D622003C 03FD0141 00006400
	v_and_b32_e32 v61, 0xffff, v61                             // 000000A5CD74: 367A7AFF 0000FFFF
	v_and_b32_e32 v65, 0xffff, v66                             // 000000A5CD7C: 368284FF 0000FFFF
	v_lshlrev_b32_e32 v63, 16, v63                             // 000000A5CD84: 307E7E90
	v_sad_u8 v66, v69, 0, 0x6400                               // 000000A5CD88: D6220042 03FD0145 00006400
	v_sad_u8 v69, v70, 0, 0x6400                               // 000000A5CD94: D6220045 03FD0146 00006400
	v_lshlrev_b32_e32 v70, 16, v60                             // 000000A5CDA0: 308C7890
	v_mov_b32_e32 v60, v62                                     // 000000A5CDA4: 7E78033E
	v_lshl_or_b32 v61, v58, 16, v61                            // 000000A5CDA8: D656003D 04F5213A
	v_and_or_b32 v62, 0xffff, v71, v63                         // 000000A5CDB0: D657003E 04FE8EFF 0000FFFF
	v_lshl_or_b32 v63, v66, 16, v65                            // 000000A5CDBC: D656003F 05052142
	v_mov_b32_e32 v65, v67                                     // 000000A5CDC4: 7E820343
	.long 0xd73d003a                                           // 000000A5CDC8: D73D003A
	v_cndmask_b32_e32 v1, v39, v59, vcc_lo                     // 000000A5CDCC: 02027727
	v_and_or_b32 v66, 0xffff, v69, v70                         // 000000A5CDD0: D6570042 051A8AFF 0000FFFF
	v_pk_fma_f16 v61, v61, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A5CDDC: CC0E003D 0BFC0B3D 0000C931
	v_pk_fma_f16 v69, v62, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A5CDE8: CC0E0045 0BFC0B3E 0000C931
	.long 0xd73d003b                                           // 000000A5CDF4: D73D003B
	v_cndmask_b32_e32 v1, v40, v64, vcc_lo                     // 000000A5CDF8: 02028128
	v_pk_fma_f16 v70, v63, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A5CDFC: CC0E0046 0BFC0B3F 0000C931
	v_bfe_u32 v62, v58, 9, 16                                  // 000000A5CE08: D610003E 0241133A
	v_dot2acc_f32_f16 v33, v61, v14                            // 000000A5CE10: 04421D3D
	v_bfe_u32 v60, v58, 6, 16                                  // 000000A5CE14: D610003C 02410D3A
	v_pk_fma_f16 v71, v66, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A5CE1C: CC0E0047 0BFC0B42 0000C931
	v_bfe_u32 v64, v59, 6, 16                                  // 000000A5CE28: D6100040 02410D3B
	.long 0xd72c003d                                           // 000000A5CE30: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000A5CE34: 02027CFF 83DCD12D
	v_dot2acc_f32_f16 v33, v69, v15                            // 000000A5CE3C: 04421F45
	.long 0xd72c003c                                           // 000000A5CE40: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000A5CE44: 020278FF 83DCD12D
	v_bfe_u32 v65, v59, 3, 16                                  // 000000A5CE4C: D6100041 0241073B
	.long 0xd72c004a                                           // 000000A5CE54: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000A5CE58: 020280FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A5CE60: BF870224
	v_dual_dot2acc_f32_f16 v34, v68, v17 :: v_dual_dot2acc_f32_f16 v33, v70, v16// 000000A5CE64: CB182344 22202146
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000A5CE6C: D622003D 03FD013D 00006400
	.long 0xd72c0041                                           // 000000A5CE78: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000A5CE7C: 020282FF 83DCD12D
	v_sad_u8 v60, v60, 0, 0x6400                               // 000000A5CE84: D622003C 03FD013C 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000A5CE90: BF8700B4
	v_dot2acc_f32_f16 v33, v71, v17                            // 000000A5CE94: 04422347
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000A5CE98: D622004A 03FD014A 00006400
	v_and_b32_e32 v72, 0xffff, v61                             // 000000A5CEA4: 36907AFF 0000FFFF
	v_lshl_or_b32 v60, v60, 16, v72                            // 000000A5CEAC: D656003C 0521213C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A5CEB4: BF870091
	v_pk_fma_f16 v76, v60, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A5CEB8: CC0E004C 0BFC0B3C 0000C931
	v_dual_dot2acc_f32_f16 v32, v76, v14 :: v_dual_and_b32 v67, 0xffff, v59// 000000A5CEC4: CB241D4C 204276FF 0000FFFF
	v_and_b32_e32 v63, 0xffff, v58                             // 000000A5CED0: 367E74FF 0000FFFF
	v_bfe_u32 v58, v58, 3, 16                                  // 000000A5CED8: D610003A 0241073A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A5CEE0: BF870193
	.long 0xd72c0048                                           // 000000A5CEE4: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000A5CEE8: 020286FF 83DCD12D
	.long 0xd72c003e                                           // 000000A5CEF0: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000A5CEF4: 02027EFF 83DCD12D
	v_bfe_u32 v63, v59, 9, 16                                  // 000000A5CEFC: D610003F 0241133B
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A5CF04: BF870004
	.long 0xd72c0042                                           // 000000A5CF08: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A5CF0C: 020274FF 83DCD12D
	ds_load_2addr_b32 v[58:59], v47 offset0:192 offset1:216    // 000000A5CF14: D8DCD8C0 3A00002F
	v_sad_u8 v72, v72, 0, 0x6400                               // 000000A5CF1C: D6220048 03FD0148 00006400
	.long 0xd72c003f                                           // 000000A5CF28: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000A5CF2C: 02027EFF 83DCD12D
	v_sad_u8 v62, v62, 0, 0x6400                               // 000000A5CF34: D622003E 03FD013E 00006400
	v_sad_u8 v66, v66, 0, 0x6400                               // 000000A5CF40: D6220042 03FD0142 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 000000A5CF4C: BF870002
	v_lshlrev_b32_e32 v73, 16, v62                             // 000000A5CF50: 30927C90
	ds_load_2addr_b32 v[61:62], v46 offset0:192 offset1:216    // 000000A5CF54: D8DCD8C0 3D00002E
	v_sad_u8 v75, v63, 0, 0x6400                               // 000000A5CF5C: D622004B 03FD013F 00006400
	ds_load_2addr_b32 v[63:64], v49 offset0:192 offset1:216    // 000000A5CF68: D8DCD8C0 3F000031
	v_and_or_b32 v73, 0xffff, v66, v73                         // 000000A5CF70: D6570049 052684FF 0000FFFF
	ds_load_2addr_b32 v[66:67], v48 offset0:192 offset1:216    // 000000A5CF7C: D8DCD8C0 42000030
	s_waitcnt lgkmcnt(3)                                       // 000000A5CF84: BF89FC37
	v_dual_mov_b32 v60, v58 :: v_dual_and_b32 v75, 0xffff, v75 // 000000A5CF88: CA24013A 3C4A96FF 0000FFFF
	v_pk_fma_f16 v73, v73, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A5CF94: CC0E0049 0BFC0B49 0000C931
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A5CFA0: BF8701A2
	v_lshl_or_b32 v74, v74, 16, v75                            // 000000A5CFA4: D656004A 052D214A
	v_sad_u8 v58, v65, 0, 0x6400                               // 000000A5CFAC: D622003A 03FD0141 00006400
	v_dot2acc_f32_f16 v32, v73, v15                            // 000000A5CFB8: 04401F49
	s_waitcnt lgkmcnt(2)                                       // 000000A5CFBC: BF89FC27
	.long 0xd73d003c                                           // 000000A5CFC0: D73D003C
	v_cndmask_b32_e32 v1, v39, v60, vcc_lo                     // 000000A5CFC4: 02027927
	v_pk_fma_f16 v61, v74, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A5CFC8: CC0E003D 0BFC0B4A 0000C931
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A5CFD4: BF8700A1
	v_dot2acc_f32_f16 v32, v61, v16                            // 000000A5CFD8: 0440213D
	v_lshlrev_b32_e32 v65, 16, v72                             // 000000A5CFDC: 30829090
	v_and_or_b32 v58, 0xffff, v58, v65                         // 000000A5CFE0: D657003A 050674FF 0000FFFF
	s_waitcnt lgkmcnt(1)                                       // 000000A5CFEC: BF89FC17
	v_mov_b32_e32 v65, v63                                     // 000000A5CFF0: 7E82033F
	v_bfe_u32 v63, v60, 9, 16                                  // 000000A5CFF4: D610003F 0241133C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A5CFFC: BF8701A3
	v_pk_fma_f16 v58, v58, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A5D000: CC0E003A 0BFC0B3A 0000C931
	s_waitcnt lgkmcnt(0)                                       // 000000A5D00C: BF89FC07
	.long 0xd73d0041                                           // 000000A5D010: D73D0041
	v_cndmask_b32_e32 v1, v40, v65, vcc_lo                     // 000000A5D014: 02028328
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A5D018: BF870003
	.long 0xd72c003d                                           // 000000A5D01C: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000A5D020: 02027EFF 83DCD12D
	v_bfe_u32 v63, v60, 3, 16                                  // 000000A5D028: D610003F 0241073C
	v_dot2acc_f32_f16 v32, v58, v17                            // 000000A5D030: 0440233A
	v_bfe_u32 v58, v60, 6, 16                                  // 000000A5D034: D610003A 02410D3C
	v_and_b32_e32 v69, 0xffff, v65                             // 000000A5D03C: 368A82FF 0000FFFF
	v_bfe_u32 v66, v65, 9, 16                                  // 000000A5D044: D6100042 02411341
	v_bfe_u32 v68, v65, 6, 16                                  // 000000A5D04C: D6100044 02410D41
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000A5D054: D622003D 03FD013D 00006400
	.long 0xd72c003a                                           // 000000A5D060: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A5D064: 020274FF 83DCD12D
	v_bfe_u32 v65, v65, 3, 16                                  // 000000A5D06C: D6100041 02410741
	.long 0xd72c003f                                           // 000000A5D074: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000A5D078: 02027EFF 83DCD12D
	.long 0xd72c0045                                           // 000000A5D080: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 000000A5D084: 02028AFF 83DCD12D
	v_and_b32_e32 v61, 0xffff, v61                             // 000000A5D08C: 367A7AFF 0000FFFF
	v_and_b32_e32 v60, 0xffff, v60                             // 000000A5D094: 367878FF 0000FFFF
	.long 0xd72c0041                                           // 000000A5D09C: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000A5D0A0: 020282FF 83DCD12D
	.long 0xd72c0042                                           // 000000A5D0A8: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 000000A5D0AC: 020284FF 83DCD12D
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000A5D0B4: D622003A 03FD013A 00006400
	.long 0xd72c0044                                           // 000000A5D0C0: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 000000A5D0C4: 020288FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2)                            // 000000A5D0CC: BF870002
	v_lshl_or_b32 v58, v58, 16, v61                            // 000000A5D0D0: D656003A 04F5213A
	v_sad_u8 v61, v63, 0, 0x6400                               // 000000A5D0D8: D622003D 03FD013F 00006400
	v_sad_u8 v63, v69, 0, 0x6400                               // 000000A5D0E4: D622003F 03FD0145 00006400
	v_sad_u8 v65, v65, 0, 0x6400                               // 000000A5D0F0: D6220041 03FD0141 00006400
	v_sad_u8 v66, v66, 0, 0x6400                               // 000000A5D0FC: D6220042 03FD0142 00006400
	v_sad_u8 v68, v68, 0, 0x6400                               // 000000A5D108: D6220044 03FD0144 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A5D114: BF870194
	v_lshlrev_b32_e32 v63, 16, v63                             // 000000A5D118: 307E7E90
	v_and_b32_e32 v66, 0xffff, v66                             // 000000A5D11C: 368484FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000A5D124: BF8700B2
	v_and_or_b32 v63, 0xffff, v65, v63                         // 000000A5D128: D657003F 04FE82FF 0000FFFF
	v_mov_b32_e32 v65, v67                                     // 000000A5D134: 7E820343
	.long 0xd72c003c                                           // 000000A5D138: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000A5D13C: 020278FF 83DCD12D
	v_sad_u8 v60, v60, 0, 0x6400                               // 000000A5D144: D622003C 03FD013C 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A5D150: BF8701B1
	v_dual_mov_b32 v60, v62 :: v_dual_lshlrev_b32 v69, 16, v60 // 000000A5D154: CA22013E 3C447890
	v_lshl_or_b32 v62, v68, 16, v66                            // 000000A5D15C: D656003E 05092144
	v_pk_fma_f16 v66, v58, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A5D164: CC0E0042 0BFC0B3A 0000C931
	v_and_or_b32 v61, 0xffff, v61, v69                         // 000000A5D170: D657003D 05167AFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A5D17C: BF870214
	.long 0xd73d003a                                           // 000000A5D180: D73D003A
	v_cndmask_b32_e32 v1, v39, v59, vcc_lo                     // 000000A5D184: 02027727
	v_pk_fma_f16 v68, v62, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A5D188: CC0E0044 0BFC0B3E 0000C931
	v_pk_fma_f16 v69, v63, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A5D194: CC0E0045 0BFC0B3F 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000A5D1A0: BF870254
	v_pk_fma_f16 v59, v61, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A5D1A4: CC0E003B 0BFC0B3D 0000C931
	.long 0xd73d003c                                           // 000000A5D1B0: D73D003C
	v_cndmask_b32_e32 v1, v40, v64, vcc_lo                     // 000000A5D1B4: 02028128
	v_dot2acc_f32_f16 v31, v66, v14                            // 000000A5D1B8: 043E1D42
	v_bfe_u32 v62, v58, 9, 16                                  // 000000A5D1BC: D610003E 0241133A
	v_and_b32_e32 v63, 0xffff, v58                             // 000000A5D1C4: 367E74FF 0000FFFF
	v_bfe_u32 v64, v60, 9, 16                                  // 000000A5D1CC: D6100040 0241133C
	v_bfe_u32 v65, v60, 6, 16                                  // 000000A5D1D4: D6100041 02410D3C
	v_bfe_u32 v71, v60, 3, 16                                  // 000000A5D1DC: D6100047 0241073C
	v_dual_dot2acc_f32_f16 v31, v59, v15 :: v_dual_and_b32 v60, 0xffff, v60// 000000A5D1E4: CB241F3B 1F3C78FF 0000FFFF
	v_bfe_u32 v59, v58, 6, 16                                  // 000000A5D1F0: D610003B 02410D3A
	.long 0xd72c003d                                           // 000000A5D1F8: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000A5D1FC: 02027CFF 83DCD12D
	.long 0xd72c003e                                           // 000000A5D204: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000A5D208: 02027EFF 83DCD12D
	v_bfe_u32 v63, v58, 3, 16                                  // 000000A5D210: D610003F 0241073A
	.long 0xd72c0040                                           // 000000A5D218: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000A5D21C: 020280FF 83DCD12D
	.long 0xd72c0042                                           // 000000A5D224: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000A5D228: 020276FF 83DCD12D
	ds_load_2addr_b32 v[58:59], v51 offset0:112 offset1:136    // 000000A5D230: D8DC8870 3A000033
	v_dot2acc_f32_f16 v31, v68, v16                            // 000000A5D238: 043E2144
	.long 0xd72c003f                                           // 000000A5D23C: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000A5D240: 02027EFF 83DCD12D
	v_sad_u8 v67, v61, 0, 0x6400                               // 000000A5D248: D6220043 03FD013D 00006400
	v_sad_u8 v70, v62, 0, 0x6400                               // 000000A5D254: D6220046 03FD013E 00006400
	ds_load_2addr_b32 v[61:62], v50 offset0:112 offset1:136    // 000000A5D260: D8DC8870 3D000032
	v_sad_u8 v72, v64, 0, 0x6400                               // 000000A5D268: D6220048 03FD0140 00006400
	v_sad_u8 v66, v66, 0, 0x6400                               // 000000A5D274: D6220042 03FD0142 00006400
	v_and_b32_e32 v67, 0xffff, v67                             // 000000A5D280: 368686FF 0000FFFF
	v_lshlrev_b32_e32 v70, 16, v70                             // 000000A5D288: 308C8C90
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000A5D28C: D622003F 03FD013F 00006400
	.long 0xd72c0041                                           // 000000A5D298: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000A5D29C: 020282FF 83DCD12D
	.long 0xd72c004a                                           // 000000A5D2A4: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000A5D2A8: 020278FF 83DCD12D
	v_lshl_or_b32 v73, v66, 16, v67                            // 000000A5D2B0: D6560049 050D2142
	ds_load_2addr_b32 v[66:67], v52 offset0:112 offset1:136    // 000000A5D2B8: D8DC8870 42000034
	v_and_or_b32 v70, 0xffff, v63, v70                         // 000000A5D2C0: D6570046 051A7EFF 0000FFFF
	ds_load_2addr_b32 v[63:64], v53 offset0:112 offset1:136    // 000000A5D2CC: D8DC8870 3F000035
	v_and_b32_e32 v72, 0xffff, v72                             // 000000A5D2D4: 369090FF 0000FFFF
	.long 0xd72c0047                                           // 000000A5D2DC: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000A5D2E0: 02028EFF 83DCD12D
	s_waitcnt lgkmcnt(3)                                       // 000000A5D2E8: BF89FC37
	v_mov_b32_e32 v60, v58                                     // 000000A5D2EC: 7E78033A
	v_sad_u8 v58, v65, 0, 0x6400                               // 000000A5D2F0: D622003A 03FD0141 00006400
	v_pk_fma_f16 v65, v73, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A5D2FC: CC0E0041 0BFC0B49 0000C931
	v_sad_u8 v73, v74, 0, 0x6400                               // 000000A5D308: D6220049 03FD014A 00006400
	s_waitcnt lgkmcnt(2)                                       // 000000A5D314: BF89FC27
	.long 0xd73d003c                                           // 000000A5D318: D73D003C
	v_cndmask_b32_e32 v1, v39, v60, vcc_lo                     // 000000A5D31C: 02027927
	v_pk_fma_f16 v61, v70, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A5D320: CC0E003D 0BFC0B46 0000C931
	v_dot2acc_f32_f16 v30, v65, v14                            // 000000A5D32C: 043C1D41
	v_sad_u8 v70, v71, 0, 0x6400                               // 000000A5D330: D6220046 03FD0147 00006400
	v_lshlrev_b32_e32 v71, 16, v73                             // 000000A5D33C: 308E9290
	v_bfe_u32 v65, v60, 9, 16                                  // 000000A5D340: D6100041 0241133C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A5D348: BF870194
	v_dot2acc_f32_f16 v30, v61, v15                            // 000000A5D34C: 043C1F3D
	v_and_or_b32 v68, 0xffff, v70, v71                         // 000000A5D350: D6570044 051E8CFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A5D35C: BF870003
	.long 0xd72c003d                                           // 000000A5D360: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000A5D364: 020282FF 83DCD12D
	s_waitcnt lgkmcnt(0)                                       // 000000A5D36C: BF89FC07
	v_mov_b32_e32 v65, v63                                     // 000000A5D370: 7E82033F
	v_lshl_or_b32 v58, v58, 16, v72                            // 000000A5D374: D656003A 0521213A
	v_bfe_u32 v63, v60, 6, 16                                  // 000000A5D37C: D610003F 02410D3C
	v_pk_fma_f16 v68, v68, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A5D384: CC0E0044 0BFC0B44 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A5D390: BF870214
	.long 0xd73d0041                                           // 000000A5D394: D73D0041
	v_cndmask_b32_e32 v1, v40, v65, vcc_lo                     // 000000A5D398: 02028328
	v_pk_fma_f16 v58, v58, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A5D39C: CC0E003A 0BFC0B3A 0000C931
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000A5D3A8: D622003D 03FD013D 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 000000A5D3B4: BF870002
	v_dot2acc_f32_f16 v30, v58, v16                            // 000000A5D3B8: 043C213A
	.long 0xd72c003a                                           // 000000A5D3BC: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000A5D3C0: 02027EFF 83DCD12D
	v_and_b32_e32 v63, 0xffff, v60                             // 000000A5D3C8: 367E78FF 0000FFFF
	v_bfe_u32 v60, v60, 3, 16                                  // 000000A5D3D0: D610003C 0241073C
	v_bfe_u32 v66, v65, 9, 16                                  // 000000A5D3D8: D6100042 02411341
	v_and_b32_e32 v61, 0xffff, v61                             // 000000A5D3E0: 367A7AFF 0000FFFF
	v_dot2acc_f32_f16 v30, v68, v17                            // 000000A5D3E8: 043C2344
	.long 0xd72c003f                                           // 000000A5D3EC: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000A5D3F0: 02027EFF 83DCD12D
	.long 0xd72c003c                                           // 000000A5D3F8: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000A5D3FC: 020278FF 83DCD12D
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000A5D404: D622003A 03FD013A 00006400
	.long 0xd72c0042                                           // 000000A5D410: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 000000A5D414: 020284FF 83DCD12D
	v_bfe_u32 v68, v65, 6, 16                                  // 000000A5D41C: D6100044 02410D41
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A5D424: BF870003
	v_lshl_or_b32 v61, v58, 16, v61                            // 000000A5D428: D656003D 04F5213A
	v_sad_u8 v58, v63, 0, 0x6400                               // 000000A5D430: D622003A 03FD013F 00006400
	v_dot2acc_f32_f16 v31, v69, v17                            // 000000A5D43C: 043E2345
	v_bfe_u32 v69, v65, 3, 16                                  // 000000A5D440: D6100045 02410741
	v_and_b32_e32 v65, 0xffff, v65                             // 000000A5D448: 368282FF 0000FFFF
	.long 0xd72c003f                                           // 000000A5D450: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 000000A5D454: 020288FF 83DCD12D
	v_sad_u8 v68, v60, 0, 0x6400                               // 000000A5D45C: D6220044 03FD013C 00006400
	v_mov_b32_e32 v60, v62                                     // 000000A5D468: 7E78033E
	v_sad_u8 v66, v66, 0, 0x6400                               // 000000A5D46C: D6220042 03FD0142 00006400
	.long 0xd72c0041                                           // 000000A5D478: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000A5D47C: 020282FF 83DCD12D
	v_lshlrev_b32_e32 v62, 16, v58                             // 000000A5D484: 307C7490
	.long 0xd72c0045                                           // 000000A5D488: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 000000A5D48C: 02028AFF 83DCD12D
	.long 0xd73d003a                                           // 000000A5D494: D73D003A
	v_cndmask_b32_e32 v1, v39, v59, vcc_lo                     // 000000A5D498: 02027727
	v_and_b32_e32 v66, 0xffff, v66                             // 000000A5D49C: 368484FF 0000FFFF
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000A5D4A4: D622003F 03FD013F 00006400
	v_pk_fma_f16 v59, v61, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A5D4B0: CC0E003B 0BFC0B3D 0000C931
	v_and_or_b32 v61, 0xffff, v68, v62                         // 000000A5D4BC: D657003D 04FA88FF 0000FFFF
	v_sad_u8 v60, v65, 0, 0x6400                               // 000000A5D4C8: D622003C 03FD0141 00006400
	v_mov_b32_e32 v65, v67                                     // 000000A5D4D4: 7E820343
	v_lshl_or_b32 v62, v63, 16, v66                            // 000000A5D4D8: D656003E 0509213F
	v_bfe_u32 v66, v58, 9, 16                                  // 000000A5D4E0: D6100042 0241133A
	v_sad_u8 v63, v69, 0, 0x6400                               // 000000A5D4E8: D622003F 03FD0145 00006400
	v_dual_dot2acc_f32_f16 v29, v59, v14 :: v_dual_lshlrev_b32 v60, 16, v60// 000000A5D4F4: CB221D3B 1D3C7890
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A5D4FC: BF870214
	v_pk_fma_f16 v69, v62, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A5D500: CC0E0045 0BFC0B3E 0000C931
	.long 0xd72c003e                                           // 000000A5D50C: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 000000A5D510: 020284FF 83DCD12D
	v_and_b32_e32 v59, 0xffff, v58                             // 000000A5D518: 367674FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A5D520: BF870004
	v_and_or_b32 v70, 0xffff, v63, v60                         // 000000A5D524: D6570046 04F27EFF 0000FFFF
	v_bfe_u32 v63, v58, 6, 16                                  // 000000A5D530: D610003F 02410D3A
	v_pk_fma_f16 v68, v61, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A5D538: CC0E0044 0BFC0B3D 0000C931
	.long 0xd73d003c                                           // 000000A5D544: D73D003C
	v_cndmask_b32_e32 v1, v40, v64, vcc_lo                     // 000000A5D548: 02028128
	v_bfe_u32 v58, v58, 3, 16                                  // 000000A5D54C: D610003A 0241073A
	.long 0xd72c0040                                           // 000000A5D554: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000A5D558: 020276FF 83DCD12D
	.long 0xd72c003d                                           // 000000A5D560: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000A5D564: 02027EFF 83DCD12D
	v_sad_u8 v62, v62, 0, 0x6400                               // 000000A5D56C: D622003E 03FD013E 00006400
	v_dot2acc_f32_f16 v29, v68, v15                            // 000000A5D578: 043A1F44
	v_bfe_u32 v63, v60, 9, 16                                  // 000000A5D57C: D610003F 0241133C
	.long 0xd72c0043                                           // 000000A5D584: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A5D588: 020274FF 83DCD12D
	ds_load_2addr_b32 v[58:59], v55 offset0:32 offset1:56      // 000000A5D590: D8DC3820 3A000037
	v_and_b32_e32 v62, 0xffff, v62                             // 000000A5D598: 367C7CFF 0000FFFF
	v_sad_u8 v64, v64, 0, 0x6400                               // 000000A5D5A0: D6220040 03FD0140 00006400
	.long 0xd72c003f                                           // 000000A5D5AC: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000A5D5B0: 02027EFF 83DCD12D
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000A5D5B8: D622003D 03FD013D 00006400
	v_dot2acc_f32_f16 v29, v69, v16                            // 000000A5D5C4: 043A2145
	v_bfe_u32 v65, v60, 6, 16                                  // 000000A5D5C8: D6100041 02410D3C
	v_sad_u8 v67, v67, 0, 0x6400                               // 000000A5D5D0: D6220043 03FD0143 00006400
	v_lshlrev_b32_e32 v64, 16, v64                             // 000000A5D5DC: 30808090
	v_lshl_or_b32 v71, v61, 16, v62                            // 000000A5D5E0: D6560047 04F9213D
	ds_load_2addr_b32 v[61:62], v54 offset0:32 offset1:56      // 000000A5D5E8: D8DC3820 3D000036
	v_bfe_u32 v66, v60, 3, 16                                  // 000000A5D5F0: D6100042 0241073C
	v_sad_u8 v72, v63, 0, 0x6400                               // 000000A5D5F8: D6220048 03FD013F 00006400
	v_and_or_b32 v67, 0xffff, v67, v64                         // 000000A5D604: D6570043 050286FF 0000FFFF
	ds_load_2addr_b32 v[63:64], v57 offset0:32 offset1:56      // 000000A5D610: D8DC3820 3F000039
	v_and_b32_e32 v60, 0xffff, v60                             // 000000A5D618: 367878FF 0000FFFF
	.long 0xd72c0041                                           // 000000A5D620: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000A5D624: 020282FF 83DCD12D
	.long 0xd72c0049                                           // 000000A5D62C: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 000000A5D630: 020284FF 83DCD12D
	v_pk_fma_f16 v71, v71, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A5D638: CC0E0047 0BFC0B47 0000C931
	v_pk_fma_f16 v74, v67, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A5D644: CC0E004A 0BFC0B43 0000C931
	.long 0xd72c003c                                           // 000000A5D650: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000A5D654: 020278FF 83DCD12D
	ds_load_2addr_b32 v[66:67], v56 offset0:32 offset1:56      // 000000A5D65C: D8DC3820 42000038
	v_and_b32_e32 v72, 0xffff, v72                             // 000000A5D664: 369090FF 0000FFFF
	v_dot2acc_f32_f16 v28, v71, v14                            // 000000A5D66C: 04381D47
	v_sad_u8 v65, v65, 0, 0x6400                               // 000000A5D670: D6220041 03FD0141 00006400
	v_sad_u8 v75, v60, 0, 0x6400                               // 000000A5D67C: D622004B 03FD013C 00006400
	s_waitcnt lgkmcnt(3)                                       // 000000A5D688: BF89FC37
	v_mov_b32_e32 v60, v58                                     // 000000A5D68C: 7E78033A
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A5D690: BF870003
	v_lshl_or_b32 v58, v65, 16, v72                            // 000000A5D694: D656003A 05212141
	v_sad_u8 v65, v73, 0, 0x6400                               // 000000A5D69C: D6220041 03FD0149 00006400
	v_dot2acc_f32_f16 v28, v74, v15                            // 000000A5D6A8: 04381F4A
	v_lshlrev_b32_e32 v72, 16, v75                             // 000000A5D6AC: 30909690
	s_waitcnt lgkmcnt(2)                                       // 000000A5D6B0: BF89FC27
	.long 0xd73d003c                                           // 000000A5D6B4: D73D003C
	v_cndmask_b32_e32 v1, v39, v60, vcc_lo                     // 000000A5D6B8: 02027927
	v_pk_fma_f16 v58, v58, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A5D6BC: CC0E003A 0BFC0B3A 0000C931
	v_pk_fma_f16 v61, v70, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A5D6C8: CC0E003D 0BFC0B46 0000C931
	v_and_or_b32 v65, 0xffff, v65, v72                         // 000000A5D6D4: D6570041 052282FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A5D6E0: BF870214
	v_bfe_u32 v68, v60, 9, 16                                  // 000000A5D6E4: D6100044 0241133C
	v_dot2acc_f32_f16 v28, v58, v16                            // 000000A5D6EC: 0438213A
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A5D6F0: BF870003
	v_pk_fma_f16 v69, v65, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A5D6F4: CC0E0045 0BFC0B41 0000C931
	s_waitcnt lgkmcnt(1)                                       // 000000A5D700: BF89FC17
	v_mov_b32_e32 v65, v63                                     // 000000A5D704: 7E82033F
	.long 0xd72c003a                                           // 000000A5D708: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 000000A5D70C: 020288FF 83DCD12D
	v_bfe_u32 v63, v60, 6, 16                                  // 000000A5D714: D610003F 02410D3C
	v_dot2acc_f32_f16 v28, v69, v17                            // 000000A5D71C: 04382345
	s_waitcnt lgkmcnt(0)                                       // 000000A5D720: BF89FC07
	.long 0xd73d0041                                           // 000000A5D724: D73D0041
	v_cndmask_b32_e32 v1, v40, v65, vcc_lo                     // 000000A5D728: 02028328
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A5D72C: BF8701A3
	.long 0xd72c003f                                           // 000000A5D730: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000A5D734: 02027EFF 83DCD12D
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000A5D73C: D622003A 03FD013A 00006400
	v_bfe_u32 v66, v65, 9, 16                                  // 000000A5D748: D6100042 02411341
	v_and_b32_e32 v69, 0xffff, v65                             // 000000A5D750: 368A82FF 0000FFFF
	v_bfe_u32 v68, v65, 6, 16                                  // 000000A5D758: D6100044 02410D41
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A5D760: BF870004
	v_and_b32_e32 v58, 0xffff, v58                             // 000000A5D764: 367474FF 0000FFFF
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000A5D76C: D622003F 03FD013F 00006400
	v_dot2acc_f32_f16 v29, v61, v17                            // 000000A5D778: 043A233D
	v_bfe_u32 v61, v60, 3, 16                                  // 000000A5D77C: D610003D 0241073C
	.long 0xd72c0042                                           // 000000A5D784: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 000000A5D788: 020284FF 83DCD12D
	v_bfe_u32 v65, v65, 3, 16                                  // 000000A5D790: D6100041 02410741
	v_lshl_or_b32 v63, v63, 16, v58                            // 000000A5D798: D656003F 04E9213F
	.long 0xd72c0044                                           // 000000A5D7A0: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 000000A5D7A4: 020288FF 83DCD12D
	.long 0xd72c003d                                           // 000000A5D7AC: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000A5D7B0: 02027AFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A5D7B8: BF870214
	.long 0xd72c0041                                           // 000000A5D7BC: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000A5D7C0: 020282FF 83DCD12D
	v_pk_fma_f16 v63, v63, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A5D7C8: CC0E003F 0BFC0B3F 0000C931
	v_sad_u8 v66, v66, 0, 0x6400                               // 000000A5D7D4: D6220042 03FD0142 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A5D7E0: BF8701B2
	v_dual_dot2acc_f32_f16 v27, v63, v14 :: v_dual_and_b32 v60, 0xffff, v60// 000000A5D7E4: CB241D3F 1B3C78FF 0000FFFF
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000A5D7F0: D622003D 03FD013D 00006400
	v_sad_u8 v65, v65, 0, 0x6400                               // 000000A5D7FC: D6220041 03FD0141 00006400
	.long 0xd72c003c                                           // 000000A5D808: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000A5D80C: 020278FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A5D814: BF870001
	v_sad_u8 v58, v60, 0, 0x6400                               // 000000A5D818: D622003A 03FD013C 00006400
	v_mov_b32_e32 v60, v62                                     // 000000A5D824: 7E78033E
	.long 0xd72c0045                                           // 000000A5D828: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 000000A5D82C: 02028AFF 83DCD12D
	v_and_b32_e32 v62, 0xffff, v66                             // 000000A5D834: 367C84FF 0000FFFF
	v_sad_u8 v66, v68, 0, 0x6400                               // 000000A5D83C: D6220042 03FD0144 00006400
	v_lshlrev_b32_e32 v70, 16, v58                             // 000000A5D848: 308C7490
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A5D84C: BF870094
	v_sad_u8 v58, v69, 0, 0x6400                               // 000000A5D850: D622003A 03FD0145 00006400
	v_lshlrev_b32_e32 v68, 16, v58                             // 000000A5D85C: 30887490
	.long 0xd73d003a                                           // 000000A5D860: D73D003A
	v_cndmask_b32_e32 v1, v39, v59, vcc_lo                     // 000000A5D864: 02027727
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A5D868: BF870224
	v_and_or_b32 v59, 0xffff, v61, v70                         // 000000A5D86C: D657003B 051A7AFF 0000FFFF
	v_lshl_or_b32 v60, v66, 16, v62                            // 000000A5D878: D656003C 04F92142
	v_and_or_b32 v61, 0xffff, v65, v68                         // 000000A5D880: D657003D 051282FF 0000FFFF
	v_mov_b32_e32 v65, v67                                     // 000000A5D88C: 7E820343
	v_bfe_u32 v62, v58, 9, 16                                  // 000000A5D890: D610003E 0241133A
	v_pk_fma_f16 v68, v59, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A5D898: CC0E0044 0BFC0B3B 0000C931
	v_pk_fma_f16 v69, v60, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A5D8A4: CC0E0045 0BFC0B3C 0000C931
	v_pk_fma_f16 v70, v61, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A5D8B0: CC0E0046 0BFC0B3D 0000C931
	.long 0xd73d003b                                           // 000000A5D8BC: D73D003B
	v_cndmask_b32_e32 v1, v40, v64, vcc_lo                     // 000000A5D8C0: 02028128
	.long 0xd72c003c                                           // 000000A5D8C4: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000A5D8C8: 02027CFF 83DCD12D
	v_and_b32_e32 v61, 0xffff, v58                             // 000000A5D8D0: 367A74FF 0000FFFF
	v_bfe_u32 v62, v58, 6, 16                                  // 000000A5D8D8: D610003E 02410D3A
	v_bfe_u32 v58, v58, 3, 16                                  // 000000A5D8E0: D610003A 0241073A
	v_dot2acc_f32_f16 v27, v68, v15                            // 000000A5D8E8: 04361F44
	v_bfe_u32 v63, v59, 9, 16                                  // 000000A5D8EC: D610003F 0241133B
	.long 0xd72c003d                                           // 000000A5D8F4: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000A5D8F8: 02027AFF 83DCD12D
	v_bfe_u32 v65, v59, 6, 16                                  // 000000A5D900: D6100041 02410D3B
	v_sad_u8 v60, v60, 0, 0x6400                               // 000000A5D908: D622003C 03FD013C 00006400
	.long 0xd72c0040                                           // 000000A5D914: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A5D918: 020274FF 83DCD12D
	v_bfe_u32 v71, v59, 3, 16                                  // 000000A5D920: D6100047 0241073B
	v_and_b32_e32 v66, 0xffff, v59                             // 000000A5D928: 368476FF 0000FFFF
	ds_load_2addr_b32 v[58:59], v55 offset0:80 offset1:104     // 000000A5D930: D8DC6850 3A000037
	v_and_b32_e32 v72, 0xffff, v60                             // 000000A5D938: 369078FF 0000FFFF
	v_sad_u8 v60, v61, 0, 0x6400                               // 000000A5D940: D622003C 03FD013D 00006400
	.long 0xd72c003e                                           // 000000A5D94C: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000A5D950: 02027CFF 83DCD12D
	.long 0xd72c0043                                           // 000000A5D958: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000A5D95C: 02027EFF 83DCD12D
	v_sad_u8 v73, v64, 0, 0x6400                               // 000000A5D964: D6220049 03FD0140 00006400
	.long 0xd72c0041                                           // 000000A5D970: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000A5D974: 020282FF 83DCD12D
	v_lshlrev_b32_e32 v74, 16, v60                             // 000000A5D97C: 30947890
	ds_load_2addr_b32 v[60:61], v57 offset0:80 offset1:104     // 000000A5D980: D8DC6850 3C000039
	ds_load_2addr_b32 v[63:64], v54 offset0:80 offset1:104     // 000000A5D988: D8DC6850 3F000036
	.long 0xd72c0047                                           // 000000A5D990: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000A5D994: 02028EFF 83DCD12D
	v_dot2acc_f32_f16 v27, v69, v16                            // 000000A5D99C: 04362145
	v_sad_u8 v62, v62, 0, 0x6400                               // 000000A5D9A0: D622003E 03FD013E 00006400
	v_sad_u8 v75, v67, 0, 0x6400                               // 000000A5D9AC: D622004B 03FD0143 00006400
	v_sad_u8 v65, v65, 0, 0x6400                               // 000000A5D9B8: D6220041 03FD0141 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A5D9C4: BF870214
	v_dot2acc_f32_f16 v27, v70, v17                            // 000000A5D9C8: 04362346
	v_lshl_or_b32 v62, v62, 16, v72                            // 000000A5D9CC: D656003E 0521213E
	v_and_or_b32 v72, 0xffff, v73, v74                         // 000000A5D9D4: D6570048 052A92FF 0000FFFF
	v_and_b32_e32 v73, 0xffff, v75                             // 000000A5D9E0: 369296FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A5D9E8: BF8701B3
	v_pk_fma_f16 v68, v62, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A5D9EC: CC0E0044 0BFC0B3E 0000C931
	s_waitcnt lgkmcnt(2)                                       // 000000A5D9F8: BF89FC27
	v_mov_b32_e32 v62, v58                                     // 000000A5D9FC: 7E7C033A
	v_lshl_or_b32 v73, v65, 16, v73                            // 000000A5DA00: D6560049 05252141
	v_pk_fma_f16 v72, v72, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A5DA08: CC0E0048 0BFC0B48 0000C931
	v_sad_u8 v58, v71, 0, 0x6400                               // 000000A5DA14: D622003A 03FD0147 00006400
	s_waitcnt lgkmcnt(1)                                       // 000000A5DA20: BF89FC17
	v_mov_b32_e32 v65, v60                                     // 000000A5DA24: 7E82033C
	s_waitcnt lgkmcnt(0)                                       // 000000A5DA28: BF89FC07
	.long 0xd73d003e                                           // 000000A5DA2C: D73D003E
	v_cndmask_b32_e32 v1, v39, v62, vcc_lo                     // 000000A5DA30: 02027D27
	v_pk_fma_f16 v60, v73, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A5DA34: CC0E003C 0BFC0B49 0000C931
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A5DA40: BF870092
	v_bfe_u32 v63, v62, 9, 16                                  // 000000A5DA44: D610003F 0241133E
	.long 0xd72c003f                                           // 000000A5DA4C: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000A5DA50: 02027EFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A5DA58: BF8701B1
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000A5DA5C: D622003F 03FD013F 00006400
	v_dot2acc_f32_f16 v26, v68, v14                            // 000000A5DA68: 04341D44
	v_bfe_u32 v68, v62, 6, 16                                  // 000000A5DA6C: D6100044 02410D3E
	v_and_b32_e32 v63, 0xffff, v63                             // 000000A5DA74: 367E7EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A5DA7C: BF870193
	v_dot2acc_f32_f16 v26, v72, v15                            // 000000A5DA80: 04341F48
	.long 0xd72c0044                                           // 000000A5DA84: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 000000A5DA88: 020288FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A5DA90: BF870091
	v_sad_u8 v68, v68, 0, 0x6400                               // 000000A5DA94: D6220044 03FD0144 00006400
	v_lshl_or_b32 v63, v68, 16, v63                            // 000000A5DAA0: D656003F 04FD2144
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A5DAA8: BF870091
	v_pk_fma_f16 v63, v63, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A5DAAC: CC0E003F 0BFC0B3F 0000C931
	v_dot2acc_f32_f16 v25, v63, v14                            // 000000A5DAB8: 04321D3F
	.long 0xd72c004c                                           // 000000A5DABC: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 000000A5DAC0: 020284FF 83DCD12D
	ds_load_2addr_b32 v[66:67], v56 offset0:80 offset1:104     // 000000A5DAC8: D8DC6850 42000038
	v_sad_u8 v74, v76, 0, 0x6400                               // 000000A5DAD0: D622004A 03FD014C 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A5DADC: BF870091
	v_lshlrev_b32_e32 v71, 16, v74                             // 000000A5DAE0: 308E9490
	v_and_or_b32 v58, 0xffff, v58, v71                         // 000000A5DAE4: D657003A 051E74FF 0000FFFF
	s_waitcnt lgkmcnt(0)                                       // 000000A5DAF0: BF89FC07
	.long 0xd73d0041                                           // 000000A5DAF4: D73D0041
	v_cndmask_b32_e32 v1, v40, v65, vcc_lo                     // 000000A5DAF8: 02028328
	v_dot2acc_f32_f16 v26, v60, v16                            // 000000A5DAFC: 0434213C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A5DB00: BF870193
	v_pk_fma_f16 v66, v58, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A5DB04: CC0E0042 0BFC0B3A 0000C931
	v_bfe_u32 v60, v65, 9, 16                                  // 000000A5DB10: D610003C 02411341
	v_bfe_u32 v69, v65, 6, 16                                  // 000000A5DB18: D6100045 02410D41
	v_bfe_u32 v71, v65, 3, 16                                  // 000000A5DB20: D6100047 02410741
	v_and_b32_e32 v65, 0xffff, v65                             // 000000A5DB28: 368282FF 0000FFFF
	v_dot2acc_f32_f16 v26, v66, v17                            // 000000A5DB30: 04342342
	.long 0xd72c003c                                           // 000000A5DB34: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000A5DB38: 020278FF 83DCD12D
	.long 0xd72c0045                                           // 000000A5DB40: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 000000A5DB44: 02028AFF 83DCD12D
	.long 0xd72c0044                                           // 000000A5DB4C: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000A5DB50: 02028EFF 83DCD12D
	.long 0xd72c0041                                           // 000000A5DB58: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000A5DB5C: 020282FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A5DB64: BF870214
	v_sad_u8 v60, v60, 0, 0x6400                               // 000000A5DB68: D622003C 03FD013C 00006400
	v_sad_u8 v69, v69, 0, 0x6400                               // 000000A5DB74: D6220045 03FD0145 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A5DB80: BF870194
	v_sad_u8 v68, v68, 0, 0x6400                               // 000000A5DB84: D6220044 03FD0144 00006400
	v_and_b32_e32 v72, 0xffff, v60                             // 000000A5DB90: 369078FF 0000FFFF
	v_mov_b32_e32 v60, v64                                     // 000000A5DB98: 7E780340
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A5DB9C: BF870092
	v_lshl_or_b32 v64, v69, 16, v72                            // 000000A5DBA0: D6560040 05212145
	v_pk_fma_f16 v64, v64, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A5DBA8: CC0E0040 0BFC0B40 0000C931
	v_and_b32_e32 v58, 0xffff, v62                             // 000000A5DBB4: 36747CFF 0000FFFF
	v_bfe_u32 v62, v62, 3, 16                                  // 000000A5DBBC: D610003E 0241073E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A5DBC4: BF870112
	.long 0xd72c003a                                           // 000000A5DBC8: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A5DBCC: 020274FF 83DCD12D
	.long 0xd72c003e                                           // 000000A5DBD4: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000A5DBD8: 02027CFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A5DBE0: BF870112
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000A5DBE4: D622003A 03FD013A 00006400
	v_sad_u8 v62, v62, 0, 0x6400                               // 000000A5DBF0: D622003E 03FD013E 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A5DBFC: BF870092
	v_lshlrev_b32_e32 v58, 16, v58                             // 000000A5DC00: 30747490
	v_and_or_b32 v62, 0xffff, v62, v58                         // 000000A5DC04: D657003E 04EA7CFF 0000FFFF
	.long 0xd73d003a                                           // 000000A5DC10: D73D003A
	v_cndmask_b32_e32 v1, v39, v59, vcc_lo                     // 000000A5DC14: 02027727
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A5DC18: BF8701A2
	v_pk_fma_f16 v69, v62, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A5DC1C: CC0E0045 0BFC0B3E 0000C931
	v_mov_b32_e32 v62, v67                                     // 000000A5DC28: 7E7C0343
	v_bfe_u32 v67, v58, 9, 16                                  // 000000A5DC2C: D6100043 0241133A
	v_and_b32_e32 v71, 0xffff, v58                             // 000000A5DC34: 368E74FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A5DC3C: BF870214
	v_dot2acc_f32_f16 v25, v69, v15                            // 000000A5DC40: 04321F45
	.long 0xd73d003b                                           // 000000A5DC44: D73D003B
	v_cndmask_b32_e32 v1, v40, v61, vcc_lo                     // 000000A5DC48: 02027B28
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A5DC4C: BF870004
	.long 0xd72c003d                                           // 000000A5DC50: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000A5DC54: 020286FF 83DCD12D
	v_bfe_u32 v62, v58, 6, 16                                  // 000000A5DC5C: D610003E 02410D3A
	v_sad_u8 v60, v65, 0, 0x6400                               // 000000A5DC64: D622003C 03FD0141 00006400
	v_bfe_u32 v58, v58, 3, 16                                  // 000000A5DC70: D610003A 0241073A
	.long 0xd72c0041                                           // 000000A5DC78: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000A5DC7C: 02028EFF 83DCD12D
	v_bfe_u32 v67, v59, 9, 16                                  // 000000A5DC84: D6100043 0241133B
	.long 0xd72c003e                                           // 000000A5DC8C: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000A5DC90: 02027CFF 83DCD12D
	v_bfe_u32 v71, v59, 6, 16                                  // 000000A5DC98: D6100047 02410D3B
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000A5DCA0: D622003D 03FD013D 00006400
	.long 0xd72c003a                                           // 000000A5DCAC: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A5DCB0: 020274FF 83DCD12D
	v_bfe_u32 v72, v59, 3, 16                                  // 000000A5DCB8: D6100048 0241073B
	.long 0xd72c0043                                           // 000000A5DCC0: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000A5DCC4: 020286FF 83DCD12D
	v_and_b32_e32 v59, 0xffff, v59                             // 000000A5DCCC: 367676FF 0000FFFF
	v_sad_u8 v65, v65, 0, 0x6400                               // 000000A5DCD4: D6220041 03FD0141 00006400
	v_and_b32_e32 v61, 0xffff, v61                             // 000000A5DCE0: 367A7AFF 0000FFFF
	v_sad_u8 v62, v62, 0, 0x6400                               // 000000A5DCE8: D622003E 03FD013E 00006400
	.long 0xd72c0047                                           // 000000A5DCF4: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000A5DCF8: 02028EFF 83DCD12D
	.long 0xd72c003b                                           // 000000A5DD00: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000A5DD04: 020276FF 83DCD12D
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000A5DD0C: D622003A 03FD013A 00006400
	v_lshlrev_b32_e32 v65, 16, v65                             // 000000A5DD18: 30828290
	v_sad_u8 v67, v67, 0, 0x6400                               // 000000A5DD1C: D6220043 03FD0143 00006400
	v_lshl_or_b32 v61, v62, 16, v61                            // 000000A5DD28: D656003D 04F5213E
	.long 0xd72c003e                                           // 000000A5DD30: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000A5DD34: 020290FF 83DCD12D
	v_dot2acc_f32_f16 v25, v64, v16                            // 000000A5DD3C: 04322140
	v_and_or_b32 v58, 0xffff, v58, v65                         // 000000A5DD40: D657003A 050674FF 0000FFFF
	v_and_b32_e32 v65, 0xffff, v67                             // 000000A5DD4C: 368286FF 0000FFFF
	v_sad_u8 v67, v71, 0, 0x6400                               // 000000A5DD54: D6220043 03FD0147 00006400
	v_sad_u8 v59, v59, 0, 0x6400                               // 000000A5DD60: D622003B 03FD013B 00006400
	v_pk_fma_f16 v61, v61, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A5DD6C: CC0E003D 0BFC0B3D 0000C931
	v_lshlrev_b32_e32 v60, 16, v60                             // 000000A5DD78: 30787890
	v_pk_fma_f16 v58, v58, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A5DD7C: CC0E003A 0BFC0B3A 0000C931
	v_lshl_or_b32 v63, v67, 16, v65                            // 000000A5DD88: D656003F 05052143
	v_sad_u8 v62, v62, 0, 0x6400                               // 000000A5DD90: D622003E 03FD013E 00006400
	v_lshlrev_b32_e32 v59, 16, v59                             // 000000A5DD9C: 30767690
	v_dot2acc_f32_f16 v1, v61, v14                             // 000000A5DDA0: 04021D3D
	v_and_or_b32 v14, 0xffff, v68, v60                         // 000000A5DDA4: D657000E 04F288FF 0000FFFF
	v_pk_fma_f16 v60, v63, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A5DDB0: CC0E003C 0BFC0B3F 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A5DDBC: BF870214
	v_and_or_b32 v59, 0xffff, v62, v59                         // 000000A5DDC0: D657003B 04EE7CFF 0000FFFF
	v_dot2acc_f32_f16 v1, v58, v15                             // 000000A5DDCC: 04021F3A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A5DDD0: BF870194
	v_pk_fma_f16 v14, v14, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A5DDD4: CC0E000E 0BFC0B0E 0000C931
	v_pk_fma_f16 v15, v59, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000A5DDE0: CC0E000F 0BFC0B3B 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A5DDEC: BF870193
	v_dual_dot2acc_f32_f16 v1, v60, v16 :: v_dual_add_nc_u32 v16, v42, v43// 000000A5DDF0: CB20213C 0110572A
	v_dot2acc_f32_f16 v25, v14, v17                            // 000000A5DDF8: 0432230E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A5DDFC: BF870192
	v_dot2acc_f32_f16 v1, v15, v17                             // 000000A5DE00: 0402230F
	v_cmp_eq_u32_e32 vcc_lo, 21, v16                           // 000000A5DE04: 7C942095
	s_or_b32 s4, vcc_lo, s4                                    // 000000A5DE08: 8C04046A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A5DE0C: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000A5DE10: 917E047E
	s_cbranch_execz 48                                         // 000000A5DE14: BFA50030 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi0ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x21d8>
	s_mov_b32 s0, exec_lo                                      // 000000A5DE18: BE80007E
	s_waitcnt vmcnt(10)                                        // 000000A5DE1C: BF892BF7
	ds_store_2addr_b32 v44, v2, v3 offset1:32                  // 000000A5DE20: D8382000 0003022C
	s_waitcnt vmcnt(8)                                         // 000000A5DE28: BF8923F7
	ds_store_2addr_b32 v44, v4, v5 offset0:64 offset1:96       // 000000A5DE2C: D8386040 0005042C
	s_waitcnt vmcnt(6)                                         // 000000A5DE34: BF891BF7
	ds_store_2addr_b32 v44, v6, v7 offset0:128 offset1:160     // 000000A5DE38: D838A080 0007062C
	s_waitcnt vmcnt(4)                                         // 000000A5DE40: BF8913F7
	ds_store_2addr_b32 v44, v8, v9 offset0:192 offset1:224     // 000000A5DE44: D838E0C0 0009082C
	s_waitcnt vmcnt(2)                                         // 000000A5DE4C: BF890BF7
	ds_store_2addr_b32 v45, v10, v11 offset1:32                // 000000A5DE50: D8382000 000B0A2D
	s_waitcnt vmcnt(0)                                         // 000000A5DE58: BF8903F7
	ds_store_2addr_b32 v45, v12, v13 offset0:64 offset1:96     // 000000A5DE5C: D8386040 000D0C2D
	.long 0xd4c9007e                                           // 000000A5DE64: D4C9007E
	v_cndmask_b32_e32 v1, v43, v23, vcc_lo                     // 000000A5DE68: 02022F2B
	s_cbranch_execz 63700                                      // 000000A5DE6C: BFA5F8D4 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi0ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x4c0>
	s_clause 0xb                                               // 000000A5DE70: BF85000B
	global_load_b32 v2, v[18:19], off                          // 000000A5DE74: DC520000 027C0012
	global_load_b32 v3, v[18:19], off offset:128               // 000000A5DE7C: DC520080 037C0012
	global_load_b32 v4, v[18:19], off offset:256               // 000000A5DE84: DC520100 047C0012
	global_load_b32 v5, v[18:19], off offset:384               // 000000A5DE8C: DC520180 057C0012
	global_load_b32 v6, v[18:19], off offset:512               // 000000A5DE94: DC520200 067C0012
	global_load_b32 v7, v[18:19], off offset:640               // 000000A5DE9C: DC520280 077C0012
	global_load_b32 v8, v[18:19], off offset:768               // 000000A5DEA4: DC520300 087C0012
	global_load_b32 v9, v[18:19], off offset:896               // 000000A5DEAC: DC520380 097C0012
	global_load_b32 v10, v[18:19], off offset:1024             // 000000A5DEB4: DC520400 0A7C0012
	global_load_b32 v11, v[18:19], off offset:1152             // 000000A5DEBC: DC520480 0B7C0012
	global_load_b32 v12, v[18:19], off offset:1280             // 000000A5DEC4: DC520500 0C7C0012
	global_load_b32 v13, v[18:19], off offset:1408             // 000000A5DECC: DC520580 0D7C0012
	s_branch 63674                                             // 000000A5DED4: BFA0F8BA <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi0ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x4c0>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000A5DED8: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A5DEDC: BF870009
	s_or_b32 exec_lo, exec_lo, s3                              // 000000A5DEE0: 8C7E037E
	s_waitcnt vmcnt(10)                                        // 000000A5DEE4: BF892BF7
	v_dual_mov_b32 v2, v24 :: v_dual_mov_b32 v3, v38           // 000000A5DEE8: CA100118 02020126
	s_waitcnt vmcnt(8)                                         // 000000A5DEF0: BF8923F7
	v_dual_mov_b32 v4, v37 :: v_dual_mov_b32 v5, v36           // 000000A5DEF4: CA100125 04040124
	s_waitcnt vmcnt(6)                                         // 000000A5DEFC: BF891BF7
	v_dual_mov_b32 v6, v35 :: v_dual_mov_b32 v7, v34           // 000000A5DF00: CA100123 06060122
	s_waitcnt vmcnt(4)                                         // 000000A5DF08: BF8913F7
	v_dual_mov_b32 v8, v33 :: v_dual_mov_b32 v9, v32           // 000000A5DF0C: CA100121 08080120
	s_waitcnt vmcnt(2)                                         // 000000A5DF14: BF890BF7
	v_dual_mov_b32 v10, v31 :: v_dual_mov_b32 v11, v30         // 000000A5DF18: CA10011F 0A0A011E
	s_waitcnt vmcnt(0)                                         // 000000A5DF20: BF8903F7
	v_dual_mov_b32 v12, v29 :: v_dual_mov_b32 v13, v28         // 000000A5DF24: CA10011D 0C0C011C
	v_dual_mov_b32 v14, v27 :: v_dual_mov_b32 v15, v26         // 000000A5DF2C: CA10011B 0E0E011A
	v_mov_b32_e32 v16, v25                                     // 000000A5DF34: 7E200319
	v_mov_b32_e32 v17, v1                                      // 000000A5DF38: 7E220301
	s_mov_b32 s0, 0x76543210                                   // 000000A5DF3C: BE8000FF 76543210
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A5DF44: BF870009
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 000000A5DF48: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 000000A5DF54: D65C0003 03FC0103 FEDCBA98
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 000000A5DF60: D65C0004 03FC0104 FEDCBA98
	v_permlanex16_b32 v5, v5, s0, 0xfedcba98                   // 000000A5DF6C: D65C0005 03FC0105 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 000000A5DF78: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v7, v7, s0, 0xfedcba98                   // 000000A5DF84: D65C0007 03FC0107 FEDCBA98
	v_permlanex16_b32 v8, v8, s0, 0xfedcba98                   // 000000A5DF90: D65C0008 03FC0108 FEDCBA98
	v_permlanex16_b32 v9, v9, s0, 0xfedcba98                   // 000000A5DF9C: D65C0009 03FC0109 FEDCBA98
	v_permlanex16_b32 v10, v10, s0, 0xfedcba98                 // 000000A5DFA8: D65C000A 03FC010A FEDCBA98
	v_permlanex16_b32 v11, v11, s0, 0xfedcba98                 // 000000A5DFB4: D65C000B 03FC010B FEDCBA98
	v_permlanex16_b32 v12, v12, s0, 0xfedcba98                 // 000000A5DFC0: D65C000C 03FC010C FEDCBA98
	v_permlanex16_b32 v13, v13, s0, 0xfedcba98                 // 000000A5DFCC: D65C000D 03FC010D FEDCBA98
	v_permlanex16_b32 v14, v14, s0, 0xfedcba98                 // 000000A5DFD8: D65C000E 03FC010E FEDCBA98
	v_permlanex16_b32 v15, v15, s0, 0xfedcba98                 // 000000A5DFE4: D65C000F 03FC010F FEDCBA98
	v_permlanex16_b32 v16, v16, s0, 0xfedcba98                 // 000000A5DFF0: D65C0010 03FC0110 FEDCBA98
	v_permlanex16_b32 v17, v17, s0, 0xfedcba98                 // 000000A5DFFC: D65C0011 03FC0111 FEDCBA98
	.long 0xd44c0000                                           // 000000A5E008: D44C0000
	v_cndmask_b32_e32 v1, 16, v22, vcc_lo                      // 000000A5E00C: 02022C90
	s_barrier                                                  // 000000A5E010: BFBD0000
	buffer_gl0_inv                                             // 000000A5E014: E0AC0000 00000000
	s_and_saveexec_b32 s3, s0                                  // 000000A5E01C: BE832000
	s_cbranch_execz 34                                         // 000000A5E020: BFA50022 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi0ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x23ac>
	v_dual_add_f32 v1, v1, v17 :: v_dual_add_f32 v2, v24, v2   // 000000A5E024: C9082301 01020518
	v_dual_add_f32 v3, v38, v3 :: v_dual_add_f32 v4, v37, v4   // 000000A5E02C: C9080726 03040925
	v_lshl_or_b32 v17, v20, 10, v21                            // 000000A5E034: D6560011 04551514
	v_dual_add_f32 v5, v36, v5 :: v_dual_add_f32 v6, v35, v6   // 000000A5E03C: C9080B24 05060D23
	v_dual_add_f32 v7, v34, v7 :: v_dual_add_f32 v8, v33, v8   // 000000A5E044: C9080F22 07081121
	v_dual_add_f32 v9, v32, v9 :: v_dual_add_f32 v10, v31, v10 // 000000A5E04C: C9081320 090A151F
	v_dual_add_f32 v11, v30, v11 :: v_dual_add_f32 v12, v29, v12// 000000A5E054: C908171E 0B0C191D
	v_dual_add_f32 v13, v28, v13 :: v_dual_add_f32 v14, v27, v14// 000000A5E05C: C9081B1C 0D0E1D1B
	v_dual_add_f32 v15, v26, v15 :: v_dual_add_f32 v16, v25, v16// 000000A5E064: C9081F1A 0F102119
	ds_store_2addr_b32 v17, v2, v3 offset1:16                  // 000000A5E06C: D8381000 00030211
	ds_store_2addr_b32 v17, v4, v5 offset0:32 offset1:48       // 000000A5E074: D8383020 00050411
	ds_store_2addr_b32 v17, v6, v7 offset0:64 offset1:80       // 000000A5E07C: D8385040 00070611
	ds_store_2addr_b32 v17, v8, v9 offset0:96 offset1:112      // 000000A5E084: D8387060 00090811
	ds_store_2addr_b32 v17, v10, v11 offset0:128 offset1:144   // 000000A5E08C: D8389080 000B0A11
	ds_store_2addr_b32 v17, v12, v13 offset0:160 offset1:176   // 000000A5E094: D838B0A0 000D0C11
	ds_store_2addr_b32 v17, v14, v15 offset0:192 offset1:208   // 000000A5E09C: D838D0C0 000F0E11
	ds_store_2addr_b32 v17, v16, v1 offset0:224 offset1:240    // 000000A5E0A4: D838F0E0 00011011
	s_or_b32 exec_lo, exec_lo, s3                              // 000000A5E0AC: 8C7E037E
	s_waitcnt lgkmcnt(0)                                       // 000000A5E0B0: BF89FC07
	s_barrier                                                  // 000000A5E0B4: BFBD0000
	buffer_gl0_inv                                             // 000000A5E0B8: E0AC0000 00000000
	s_mov_b32 s3, exec_lo                                      // 000000A5E0C0: BE83007E
	v_cmpx_eq_u32_e32 0, v20                                   // 000000A5E0C4: 7D942880
	s_cbranch_execz 1332                                       // 000000A5E0C8: BFA50534 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi0ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x389c>
	v_and_b32_e32 v3, 15, v0                                   // 000000A5E0CC: 3606008F
	s_mul_i32 s3, s1, 0xa00                                    // 000000A5E0D0: 9603FF01 00000A00
	s_mul_hi_i32 s4, s1, 0xa00                                 // 000000A5E0D8: 9704FF01 00000A00
	s_add_u32 s5, s10, s3                                      // 000000A5E0E0: 8005030A
	s_addc_u32 s4, s11, s4                                     // 000000A5E0E4: 8204040B
	v_lshlrev_b32_e32 v4, 2, v3                                // 000000A5E0E8: 30080682
	s_lshl_b32 s2, s2, 7                                       // 000000A5E0EC: 84028702
	ds_load_2addr_b32 v[1:2], v4 offset1:16                    // 000000A5E0F0: D8DC1000 01000004
	ds_load_2addr_b32 v[5:6], v4 offset0:128 offset1:144       // 000000A5E0F8: D8DC9080 05000004
	s_ashr_i32 s3, s2, 31                                      // 000000A5E100: 86039F02
	v_lshlrev_b32_e32 v52, 1, v0                               // 000000A5E104: 30680081
	s_lshl_b64 s[10:11], s[2:3], 1                             // 000000A5E108: 848A8102
	s_mul_i32 s2, s1, 0x500                                    // 000000A5E10C: 9602FF01 00000500
	s_add_u32 s6, s5, s10                                      // 000000A5E114: 80060A05
	s_addc_u32 s7, s4, s11                                     // 000000A5E118: 82070B04
	s_mul_hi_i32 s1, s1, 0x500                                 // 000000A5E11C: 9701FF01 00000500
	s_add_u32 s2, s12, s2                                      // 000000A5E124: 8002020C
	s_addc_u32 s1, s13, s1                                     // 000000A5E128: 8201010D
	s_add_u32 s8, s2, s10                                      // 000000A5E12C: 80080A02
	s_addc_u32 s9, s1, s11                                     // 000000A5E130: 82090B01
	s_waitcnt lgkmcnt(1)                                       // 000000A5E134: BF89FC17
	v_add_f32_e32 v1, 0, v1                                    // 000000A5E138: 06020280
	v_add_nc_u32_e32 v45, 0x400, v4                            // 000000A5E13C: 4A5A08FF 00000400
	s_waitcnt lgkmcnt(0)                                       // 000000A5E144: BF89FC07
	v_dual_add_f32 v5, 0, v5 :: v_dual_add_nc_u32 v46, 0x800, v4// 000000A5E148: C9200A80 052E08FF 00000800
	v_add_nc_u32_e32 v47, 0xc00, v4                            // 000000A5E154: 4A5E08FF 00000C00
	v_add_nc_u32_e32 v48, 0x1000, v4                           // 000000A5E15C: 4A6008FF 00001000
	v_add_nc_u32_e32 v49, 0x1400, v4                           // 000000A5E164: 4A6208FF 00001400
	v_add_nc_u32_e32 v50, 0x1800, v4                           // 000000A5E16C: 4A6408FF 00001800
	v_add_nc_u32_e32 v51, 0x1c00, v4                           // 000000A5E174: 4A6608FF 00001C00
	ds_load_2addr_b32 v[7:8], v45 offset1:16                   // 000000A5E17C: D8DC1000 0700002D
	ds_load_2addr_b32 v[9:10], v4 offset0:32 offset1:48        // 000000A5E184: D8DC3020 09000004
	ds_load_2addr_b32 v[11:12], v4 offset0:160 offset1:176     // 000000A5E18C: D8DCB0A0 0B000004
	ds_load_2addr_b32 v[13:14], v45 offset0:128 offset1:144    // 000000A5E194: D8DC9080 0D00002D
	ds_load_2addr_b32 v[15:16], v46 offset1:16                 // 000000A5E19C: D8DC1000 0F00002E
	ds_load_2addr_b32 v[17:18], v46 offset0:128 offset1:144    // 000000A5E1A4: D8DC9080 1100002E
	ds_load_2addr_b32 v[19:20], v47 offset1:16                 // 000000A5E1AC: D8DC1000 1300002F
	ds_load_2addr_b32 v[21:22], v47 offset0:128 offset1:144    // 000000A5E1B4: D8DC9080 1500002F
	ds_load_2addr_b32 v[23:24], v48 offset1:16                 // 000000A5E1BC: D8DC1000 17000030
	ds_load_2addr_b32 v[25:26], v48 offset0:128 offset1:144    // 000000A5E1C4: D8DC9080 19000030
	ds_load_2addr_b32 v[27:28], v49 offset1:16                 // 000000A5E1CC: D8DC1000 1B000031
	ds_load_2addr_b32 v[29:30], v49 offset0:128 offset1:144    // 000000A5E1D4: D8DC9080 1D000031
	ds_load_2addr_b32 v[31:32], v50 offset1:16                 // 000000A5E1DC: D8DC1000 1F000032
	ds_load_2addr_b32 v[33:34], v50 offset0:128 offset1:144    // 000000A5E1E4: D8DC9080 21000032
	ds_load_2addr_b32 v[35:36], v51 offset1:16                 // 000000A5E1EC: D8DC1000 23000033
	v_add_f32_e32 v2, 0, v2                                    // 000000A5E1F4: 06040480
	ds_load_2addr_b32 v[43:44], v46 offset0:32 offset1:48      // 000000A5E1F8: D8DC3020 2B00002E
	s_waitcnt lgkmcnt(15)                                      // 000000A5E200: BF89FCF7
	v_add_f32_e32 v1, v1, v7                                   // 000000A5E204: 06020F01
	v_dual_add_f32 v7, 0, v6 :: v_dual_add_f32 v2, v2, v8      // 000000A5E208: C9080C80 07021102
	s_waitcnt lgkmcnt(12)                                      // 000000A5E210: BF89FCC7
	v_add_f32_e32 v13, v5, v13                                 // 000000A5E214: 061A1B05
	ds_load_2addr_b32 v[5:6], v46 offset0:160 offset1:176      // 000000A5E218: D8DCB0A0 0500002E
	s_waitcnt lgkmcnt(12)                                      // 000000A5E220: BF89FCC7
	v_dual_add_f32 v1, v1, v15 :: v_dual_add_f32 v14, v7, v14  // 000000A5E224: C9081F01 010E1D07
	s_waitcnt lgkmcnt(11)                                      // 000000A5E22C: BF89FCB7
	v_dual_add_f32 v2, v2, v16 :: v_dual_add_f32 v13, v13, v17 // 000000A5E230: C9082102 020C230D
	ds_load_2addr_b32 v[15:16], v48 offset0:32 offset1:48      // 000000A5E238: D8DC3020 0F000030
	v_add_f32_e32 v14, v14, v18                                // 000000A5E240: 061C250E
	s_waitcnt lgkmcnt(11)                                      // 000000A5E244: BF89FCB7
	v_dual_add_f32 v2, v2, v20 :: v_dual_add_f32 v1, v1, v19   // 000000A5E248: C9082902 02002701
	ds_load_2addr_b32 v[7:8], v47 offset0:32 offset1:48        // 000000A5E250: D8DC3020 0700002F
	ds_load_2addr_b32 v[17:18], v48 offset0:160 offset1:176    // 000000A5E258: D8DCB0A0 11000030
	s_waitcnt lgkmcnt(12)                                      // 000000A5E260: BF89FCC7
	v_add_f32_e32 v14, v14, v22                                // 000000A5E264: 061C2D0E
	s_waitcnt lgkmcnt(11)                                      // 000000A5E268: BF89FCB7
	v_dual_add_f32 v2, v2, v24 :: v_dual_add_f32 v1, v1, v23   // 000000A5E26C: C9083102 02002F01
	ds_load_2addr_b32 v[19:20], v49 offset0:32 offset1:48      // 000000A5E274: D8DC3020 13000031
	s_waitcnt lgkmcnt(11)                                      // 000000A5E27C: BF89FCB7
	v_add_f32_e32 v14, v14, v26                                // 000000A5E280: 061C350E
	ds_load_2addr_b32 v[37:38], v51 offset0:128 offset1:144    // 000000A5E284: D8DC9080 25000033
	ds_load_2addr_b32 v[39:40], v45 offset0:32 offset1:48      // 000000A5E28C: D8DC3020 2700002D
	ds_load_2addr_b32 v[41:42], v45 offset0:160 offset1:176    // 000000A5E294: D8DCB0A0 2900002D
	v_add_f32_e32 v13, v13, v21                                // 000000A5E29C: 061A2B0D
	s_waitcnt lgkmcnt(13)                                      // 000000A5E2A0: BF89FCD7
	v_add_f32_e32 v1, v1, v27                                  // 000000A5E2A4: 06023701
	v_add_f32_e32 v23, v2, v28                                 // 000000A5E2A8: 062E3902
	s_waitcnt lgkmcnt(12)                                      // 000000A5E2AC: BF89FCC7
	v_dual_add_f32 v24, v14, v30 :: v_dual_add_f32 v9, 0, v9   // 000000A5E2B0: C9083D0E 18081280
	ds_load_2addr_b32 v[21:22], v49 offset0:160 offset1:176    // 000000A5E2B8: D8DCB0A0 15000031
	v_add_f32_e32 v11, 0, v11                                  // 000000A5E2C0: 06161680
	s_waitcnt lgkmcnt(11)                                      // 000000A5E2C4: BF89FCB7
	v_dual_add_f32 v1, v1, v31 :: v_dual_add_f32 v26, v24, v34 // 000000A5E2C8: C9083F01 011A4518
	s_waitcnt lgkmcnt(3)                                       // 000000A5E2D0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A5E2D4: BF870001
	v_dual_add_f32 v13, v13, v25 :: v_dual_add_f32 v54, v26, v38// 000000A5E2D8: C908330D 0D364D1A
	s_waitcnt lgkmcnt(2)                                       // 000000A5E2E0: BF89FC27
	v_add_f32_e32 v9, v9, v39                                  // 000000A5E2E4: 06124F09
	v_add_f32_e32 v39, v1, v35                                 // 000000A5E2E8: 064E4701
	v_lshlrev_b32_e32 v1, 1, v3                                // 000000A5E2EC: 30020681
	s_waitcnt lgkmcnt(1)                                       // 000000A5E2F0: BF89FC17
	v_add_f32_e32 v3, v11, v41                                 // 000000A5E2F4: 0606530B
	v_add_f32_e32 v11, v23, v32                                // 000000A5E2F8: 06164117
	v_add_f32_e32 v9, v9, v43                                  // 000000A5E2FC: 06125709
	ds_load_2addr_b32 v[23:24], v50 offset0:32 offset1:48      // 000000A5E300: D8DC3020 17000032
	v_or_b32_e32 v41, 32, v52                                  // 000000A5E308: 385268A0
	v_add_f32_e32 v5, v3, v5                                   // 000000A5E30C: 060A0B03
	v_add_f32_e32 v53, v11, v36                                // 000000A5E310: 066A490B
	v_add_f32_e32 v7, v9, v7                                   // 000000A5E314: 060E0F09
	global_load_d16_b16 v3, v41, s[6:7]                        // 000000A5E318: DC820000 03060029
	v_add_f32_e32 v7, v7, v15                                  // 000000A5E320: 060E1F07
	v_add_f32_e32 v15, 0, v12                                  // 000000A5E324: 061E1880
	ds_load_2addr_b32 v[11:12], v4 offset0:192 offset1:208     // 000000A5E328: D8DCD0C0 0B000004
	ds_load_2addr_b32 v[27:28], v51 offset0:32 offset1:48      // 000000A5E330: D8DC3020 1B000033
	v_add_f32_e32 v7, v7, v19                                  // 000000A5E338: 060E2707
	s_waitcnt lgkmcnt(2)                                       // 000000A5E33C: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A5E340: BF870001
	v_add_f32_e32 v19, v7, v23                                 // 000000A5E344: 06262F07
	v_add_f32_e32 v13, v13, v29                                // 000000A5E348: 061A3B0D
	ds_load_2addr_b32 v[29:30], v45 offset0:64 offset1:80      // 000000A5E34C: D8DC5040 1D00002D
	ds_load_2addr_b32 v[31:32], v45 offset0:192 offset1:208    // 000000A5E354: D8DCD0C0 1F00002D
	v_add_f32_e32 v25, v13, v33                                // 000000A5E35C: 0632430D
	ds_load_2addr_b32 v[13:14], v47 offset0:160 offset1:176    // 000000A5E360: D8DCB0A0 0D00002F
	s_waitcnt lgkmcnt(4)                                       // 000000A5E368: BF89FC47
	v_add_f32_e32 v11, 0, v11                                  // 000000A5E36C: 06161680
	v_add_f32_e32 v43, v25, v37                                // 000000A5E370: 06564B19
	ds_load_2addr_b32 v[25:26], v50 offset0:160 offset1:176    // 000000A5E374: D8DCB0A0 19000032
	ds_load_2addr_b32 v[37:38], v48 offset0:192 offset1:208    // 000000A5E37C: D8DCD0C0 25000030
	s_waitcnt lgkmcnt(3)                                       // 000000A5E384: BF89FC37
	v_add_f32_e32 v11, v11, v31                                // 000000A5E388: 06163F0B
	s_waitcnt lgkmcnt(2)                                       // 000000A5E38C: BF89FC27
	v_add_f32_e32 v5, v5, v13                                  // 000000A5E390: 060A1B05
	v_add_f32_e32 v13, 0, v10                                  // 000000A5E394: 061A1480
	ds_load_2addr_b32 v[9:10], v4 offset0:64 offset1:80        // 000000A5E398: D8DC5040 09000004
	v_add_f32_e32 v5, v5, v17                                  // 000000A5E3A0: 060A2305
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000A5E3A4: BF8701C1
	v_add_f32_e32 v17, v5, v21                                 // 000000A5E3A8: 06222B05
	v_add_f32_e32 v5, v13, v40                                 // 000000A5E3AC: 060A510D
	v_add_f32_e32 v13, v15, v42                                // 000000A5E3B0: 061A550F
	s_waitcnt lgkmcnt(2)                                       // 000000A5E3B4: BF89FC27
	v_dual_add_f32 v40, v19, v27 :: v_dual_add_f32 v21, v17, v25// 000000A5E3B8: C9083713 28143311
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A5E3C0: BF870193
	v_add_f32_e32 v7, v5, v44                                  // 000000A5E3C4: 060E5905
	v_add_f32_e32 v13, v13, v6                                 // 000000A5E3C8: 061A0D0D
	ds_load_2addr_b32 v[5:6], v46 offset0:64 offset1:80        // 000000A5E3CC: D8DC5040 0500002E
	ds_load_2addr_b32 v[33:34], v46 offset0:192 offset1:208    // 000000A5E3D4: D8DCD0C0 2100002E
	ds_load_2addr_b32 v[35:36], v51 offset0:160 offset1:176    // 000000A5E3DC: D8DCB0A0 23000033
	v_add_f32_e32 v15, v7, v8                                  // 000000A5E3E4: 061E1107
	ds_load_2addr_b32 v[7:8], v47 offset0:64 offset1:80        // 000000A5E3E8: D8DC5040 0700002F
	v_add_f32_e32 v17, v13, v14                                // 000000A5E3F0: 06221D0D
	ds_load_2addr_b32 v[13:14], v47 offset0:192 offset1:208    // 000000A5E3F4: D8DCD0C0 0D00002F
	s_waitcnt lgkmcnt(5)                                       // 000000A5E3FC: BF89FC57
	v_add_f32_e32 v9, 0, v9                                    // 000000A5E400: 06121280
	v_add_f32_e32 v23, v15, v16                                // 000000A5E404: 062E210F
	ds_load_2addr_b32 v[15:16], v48 offset0:64 offset1:80      // 000000A5E408: D8DC5040 0F000030
	v_add_f32_e32 v17, v17, v18                                // 000000A5E410: 06222511
	v_add_f32_e32 v9, v9, v29                                  // 000000A5E414: 06123B09
	v_add_f32_e32 v23, v23, v20                                // 000000A5E418: 062E2917
	ds_load_2addr_b32 v[19:20], v49 offset0:192 offset1:208    // 000000A5E41C: D8DCD0C0 13000031
	v_add_f32_e32 v22, v17, v22                                // 000000A5E424: 062C2D11
	ds_load_2addr_b32 v[17:18], v49 offset0:64 offset1:80      // 000000A5E428: D8DC5040 11000031
	s_waitcnt lgkmcnt(7)                                       // 000000A5E430: BF89FC77
	v_add_f32_e32 v5, v9, v5                                   // 000000A5E434: 060A0B09
	s_waitcnt lgkmcnt(5)                                       // 000000A5E438: BF89FC57
	v_dual_add_f32 v9, v11, v33 :: v_dual_add_f32 v42, v21, v35// 000000A5E43C: C908430B 092A4715
	v_add_f32_e32 v27, v23, v24                                // 000000A5E444: 06363117
	v_add_f32_e32 v33, v22, v26                                // 000000A5E448: 06423516
	ds_load_2addr_b32 v[21:22], v50 offset0:64 offset1:80      // 000000A5E44C: D8DC5040 15000032
	ds_load_2addr_b32 v[23:24], v50 offset0:192 offset1:208    // 000000A5E454: D8DCD0C0 17000032
	s_waitcnt lgkmcnt(6)                                       // 000000A5E45C: BF89FC67
	v_add_f32_e32 v5, v5, v7                                   // 000000A5E460: 060A0F05
	s_waitcnt lgkmcnt(5)                                       // 000000A5E464: BF89FC57
	v_add_f32_e32 v7, v9, v13                                  // 000000A5E468: 060E1B09
	s_waitcnt lgkmcnt(4)                                       // 000000A5E46C: BF89FC47
	s_delay_alu instid0(VALU_DEP_2)                            // 000000A5E470: BF870002
	v_add_f32_e32 v13, v5, v15                                 // 000000A5E474: 061A1F05
	v_add_f32_e32 v5, 0, v10                                   // 000000A5E478: 060A1480
	ds_load_2addr_b32 v[9:10], v51 offset0:64 offset1:80       // 000000A5E47C: D8DC5040 09000033
	ds_load_2addr_b32 v[25:26], v51 offset0:192 offset1:208    // 000000A5E484: D8DCD0C0 19000033
	v_add_f32_e32 v7, v7, v37                                  // 000000A5E48C: 060E4B07
	v_add_f32_e32 v15, 0, v12                                  // 000000A5E490: 061E1880
	ds_load_2addr_b32 v[11:12], v4 offset0:96 offset1:112      // 000000A5E494: D8DC7060 0B000004
	v_add_f32_e32 v31, v5, v30                                 // 000000A5E49C: 063E3D05
	ds_load_2addr_b32 v[29:30], v4 offset0:224 offset1:240     // 000000A5E4A0: D8DCF0E0 1D000004
	s_waitcnt lgkmcnt(6)                                       // 000000A5E4A8: BF89FC67
	v_dual_add_f32 v13, v13, v17 :: v_dual_add_f32 v4, v15, v32// 000000A5E4AC: C908230D 0D04410F
	v_add_f32_e32 v15, v7, v19                                 // 000000A5E4B4: 061E2707
	v_add_f32_e32 v17, v31, v6                                 // 000000A5E4B8: 06220D1F
	ds_load_2addr_b32 v[6:7], v45 offset0:96 offset1:112       // 000000A5E4BC: D8DC7060 0600002D
	ds_load_2addr_b32 v[31:32], v45 offset0:224 offset1:240    // 000000A5E4C4: D8DCF0E0 1F00002D
	s_waitcnt lgkmcnt(7)                                       // 000000A5E4CC: BF89FC77
	v_dual_add_f32 v13, v13, v21 :: v_dual_add_f32 v4, v4, v34 // 000000A5E4D0: C9082B0D 0D044504
	s_waitcnt lgkmcnt(6)                                       // 000000A5E4D8: BF89FC67
	v_dual_add_f32 v15, v15, v23 :: v_dual_add_f32 v8, v17, v8 // 000000A5E4DC: C9082F0F 0F081111
	s_clause 0x1                                               // 000000A5E4E4: BF850001
	global_load_d16_b16 v2, v1, s[6:7]                         // 000000A5E4E8: DC820000 02060001
	global_load_d16_b16 v5, v1, s[6:7] offset:64               // 000000A5E4F0: DC820040 05060001
	v_dual_add_f32 v4, v4, v14 :: v_dual_add_f32 v37, v27, v28 // 000000A5E4F8: C9081D04 0424391B
	s_waitcnt lgkmcnt(5)                                       // 000000A5E500: BF89FC57
	v_add_f32_e32 v23, v13, v9                                 // 000000A5E504: 062E130D
	s_waitcnt lgkmcnt(4)                                       // 000000A5E508: BF89FC47
	v_dual_add_f32 v25, v15, v25 :: v_dual_add_f32 v8, v8, v16 // 000000A5E50C: C908330F 19082108
	ds_load_2addr_b32 v[13:14], v46 offset0:96 offset1:112     // 000000A5E514: D8DC7060 0D00002E
	ds_load_2addr_b32 v[15:16], v46 offset0:224 offset1:240    // 000000A5E51C: D8DCF0E0 0F00002E
	v_add_f32_e32 v9, v4, v38                                  // 000000A5E524: 06124D04
	s_waitcnt lgkmcnt(5)                                       // 000000A5E528: BF89FC57
	v_add_f32_e32 v11, 0, v11                                  // 000000A5E52C: 06161680
	s_waitcnt lgkmcnt(4)                                       // 000000A5E530: BF89FC47
	v_dual_add_f32 v17, 0, v29 :: v_dual_add_f32 v38, v8, v18  // 000000A5E534: C9083A80 11262508
	v_add_f32_e32 v21, v33, v36                                // 000000A5E53C: 062A4921
	v_add_f32_e32 v44, v9, v20                                 // 000000A5E540: 06582909
	s_waitcnt lgkmcnt(2)                                       // 000000A5E544: BF89FC27
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A5E548: BF870003
	v_dual_add_f32 v8, v11, v6 :: v_dual_add_f32 v11, v17, v31 // 000000A5E54C: C9080D0B 080A3F11
	ds_load_2addr_b32 v[17:18], v47 offset0:96 offset1:112     // 000000A5E554: D8DC7060 1100002F
	ds_load_2addr_b32 v[19:20], v47 offset0:224 offset1:240    // 000000A5E55C: D8DCF0E0 1300002F
	ds_load_2addr_b32 v[27:28], v48 offset0:96 offset1:112     // 000000A5E564: D8DC7060 1B000030
	ds_load_2addr_b32 v[33:34], v48 offset0:224 offset1:240    // 000000A5E56C: D8DCF0E0 21000030
	v_add_f32_e32 v31, 0, v12                                  // 000000A5E574: 063E1880
	v_add_f32_e32 v35, 0, v30                                  // 000000A5E578: 06463C80
	s_clause 0x1                                               // 000000A5E57C: BF850001
	global_load_d16_b16 v6, v41, s[6:7] offset:1280            // 000000A5E580: DC820500 06060029
	global_load_d16_b16 v4, v1, s[6:7] offset:1280             // 000000A5E588: DC820500 04060001
	v_or_b32_e32 v45, 0x60, v52                                // 000000A5E590: 385A68FF 00000060
	v_add_f32_e32 v7, v31, v7                                  // 000000A5E598: 060E0F1F
	s_waitcnt lgkmcnt(5)                                       // 000000A5E59C: BF89FC57
	v_add_f32_e32 v13, v8, v13                                 // 000000A5E5A0: 061A1B08
	global_load_d16_b16 v8, v41, s[8:9]                        // 000000A5E5A4: DC820000 08080029
	s_waitcnt lgkmcnt(4)                                       // 000000A5E5AC: BF89FC47
	v_add_f32_e32 v15, v11, v15                                // 000000A5E5B0: 061E1F0B
	ds_load_2addr_b32 v[11:12], v49 offset0:96 offset1:112     // 000000A5E5B4: D8DC7060 0B000031
	ds_load_2addr_b32 v[29:30], v49 offset0:224 offset1:240    // 000000A5E5BC: D8DCF0E0 1D000031
	v_add_f32_e32 v41, v35, v32                                // 000000A5E5C4: 06524123
	ds_load_2addr_b32 v[31:32], v50 offset0:96 offset1:112     // 000000A5E5C8: D8DC7060 1F000032
	ds_load_2addr_b32 v[35:36], v50 offset0:224 offset1:240    // 000000A5E5D0: D8DCF0E0 23000032
	v_add_f32_e32 v7, v7, v14                                  // 000000A5E5D8: 060E1D07
	global_load_d16_b16 v9, v45, s[6:7]                        // 000000A5E5DC: DC820000 0906002D
	v_add_f32_e32 v41, v41, v16                                // 000000A5E5E4: 06522129
	s_waitcnt lgkmcnt(7)                                       // 000000A5E5E8: BF89FC77
	v_add_f32_e32 v17, v13, v17                                // 000000A5E5EC: 0622230D
	s_waitcnt lgkmcnt(6)                                       // 000000A5E5F0: BF89FC67
	v_add_f32_e32 v19, v15, v19                                // 000000A5E5F4: 0626270F
	ds_load_2addr_b32 v[13:14], v51 offset0:96 offset1:112     // 000000A5E5F8: D8DC7060 0D000033
	ds_load_2addr_b32 v[15:16], v51 offset0:224 offset1:240    // 000000A5E600: D8DCF0E0 0F000033
	v_dual_add_f32 v7, v7, v18 :: v_dual_add_f32 v18, v41, v20 // 000000A5E608: C9082507 07122929
	s_waitcnt lgkmcnt(7)                                       // 000000A5E610: BF89FC77
	v_add_f32_e32 v17, v17, v27                                // 000000A5E614: 06223711
	s_waitcnt lgkmcnt(6)                                       // 000000A5E618: BF89FC67
	v_dual_add_f32 v19, v19, v33 :: v_dual_add_f32 v20, v38, v22// 000000A5E61C: C9084313 13142D26
	v_dual_add_f32 v7, v7, v28 :: v_dual_add_f32 v18, v18, v34 // 000000A5E624: C9083907 07124512
	v_add_f32_e32 v22, v44, v24                                // 000000A5E62C: 062C312C
	v_or_b32_e32 v28, 0xa0, v52                                // 000000A5E630: 383868FF 000000A0
	s_waitcnt lgkmcnt(5)                                       // 000000A5E638: BF89FC57
	v_add_f32_e32 v11, v17, v11                                // 000000A5E63C: 06161711
	s_waitcnt lgkmcnt(4)                                       // 000000A5E640: BF89FC47
	v_add_f32_e32 v17, v19, v29                                // 000000A5E644: 06223B13
	v_dual_add_f32 v7, v7, v12 :: v_dual_add_f32 v12, v18, v30 // 000000A5E648: C9081907 070C3D12
	s_waitcnt lgkmcnt(3)                                       // 000000A5E650: BF89FC37
	v_dual_add_f32 v10, v20, v10 :: v_dual_add_f32 v11, v11, v31// 000000A5E654: C9081514 0A0A3F0B
	s_waitcnt lgkmcnt(2)                                       // 000000A5E65C: BF89FC27
	v_dual_add_f32 v17, v17, v35 :: v_dual_add_f32 v18, v22, v26// 000000A5E660: C9084711 11123516
	v_add_f32_e32 v12, v12, v36                                // 000000A5E668: 0618490C
	v_add_f32_e32 v7, v7, v32                                  // 000000A5E66C: 060E4107
	s_waitcnt lgkmcnt(1)                                       // 000000A5E670: BF89FC17
	v_add_f32_e32 v11, v11, v13                                // 000000A5E674: 06161B0B
	s_waitcnt lgkmcnt(0)                                       // 000000A5E678: BF89FC07
	v_add_f32_e32 v13, v17, v15                                // 000000A5E67C: 061A1F11
	v_dual_add_f32 v19, v23, v10 :: v_dual_add_f32 v12, v12, v16// 000000A5E680: C9081517 130C210C
	v_sub_f32_e32 v10, v23, v10                                // 000000A5E688: 08141517
	v_dual_add_f32 v22, v43, v54 :: v_dual_add_f32 v23, v42, v21// 000000A5E68C: C9086D2B 16162B2A
	v_add_f32_e32 v24, v25, v18                                // 000000A5E694: 06302519
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A5E698: BF870004
	v_add_f32_e32 v27, v13, v12                                // 000000A5E69C: 0636190D
	v_add_f32_e32 v7, v7, v14                                  // 000000A5E6A0: 060E1D07
	v_sub_f32_e32 v15, v39, v53                                // 000000A5E6A4: 081E6B27
	v_add_f32_e32 v16, v40, v37                                // 000000A5E6A8: 06204B28
	v_dual_sub_f32 v17, v40, v37 :: v_dual_add_f32 v30, v22, v23// 000000A5E6AC: C9484B28 111E2F16
	v_add_f32_e32 v31, v24, v27                                // 000000A5E6B4: 063E3718
	v_dual_add_f32 v20, v11, v7 :: v_dual_and_b32 v37, 1, v0   // 000000A5E6B8: C9240F0B 14240081
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A5E6C0: BF870223
	v_add_f32_e32 v36, v15, v17                                // 000000A5E6C4: 0648230F
	v_sub_f32_e32 v15, v15, v17                                // 000000A5E6C8: 081E230F
	v_add_f32_e32 v17, v30, v31                                // 000000A5E6CC: 06223F1E
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A5E6D0: BF870004
	.long 0xd44a0002                                           // 000000A5E6D4: D44A0002
	v_cndmask_b32_e32 v1, 0, v37, vcc_lo                       // 000000A5E6D8: 02024A80
	v_add_f32_e32 v14, v39, v53                                // 000000A5E6DC: 061C6B27
	v_add_f32_e32 v39, v19, v20                                // 000000A5E6E0: 064E2913
	v_sub_f32_e32 v19, v19, v20                                // 000000A5E6E4: 08262913
	v_mov_b32_dpp v20, v17 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A5E6E8: 7E2802FA FF016111
	v_cndmask_b32_e64 v17, -v17, v17, s2                       // 000000A5E6F0: D5010011 200A2311
	v_sub_f32_e32 v37, v43, v54                                // 000000A5E6F8: 084A6D2B
	v_dual_sub_f32 v21, v42, v21 :: v_dual_sub_f32 v18, v25, v18// 000000A5E6FC: C94A2B2A 15122519
	v_dual_sub_f32 v12, v13, v12 :: v_dual_sub_f32 v11, v11, v7// 000000A5E704: C94A190D 0C0A0F0B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A5E70C: BF8701A4
	v_add_f32_e32 v13, v17, v20                                // 000000A5E710: 061A2911
	v_and_b32_e32 v17, 2, v0                                   // 000000A5E714: 36220082
	v_dual_add_f32 v25, v37, v21 :: v_dual_add_f32 v40, v18, v12// 000000A5E718: C9082B25 19281912
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A5E720: BF870224
	v_add_f32_e32 v20, v10, v11                                // 000000A5E724: 0628170A
	v_sub_f32_e32 v10, v10, v11                                // 000000A5E728: 0814170A
	.long 0xd44a0003                                           // 000000A5E72C: D44A0003
	v_cndmask_b32_e32 v1, 0, v17, vcc_lo                       // 000000A5E730: 02022280
	v_sub_f32_e32 v17, v22, v23                                // 000000A5E734: 08222F16
	v_dual_add_f32 v11, v25, v40 :: v_dual_sub_f32 v22, v24, v27// 000000A5E738: C90A5119 0B163718
	v_and_b32_e32 v23, 4, v0                                   // 000000A5E740: 362E0084
	v_mov_b32_dpp v41, v13 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A5E744: 7E5202FA FF01620D
	v_cndmask_b32_e64 v13, -v13, v13, s3                       // 000000A5E74C: D501000D 200E1B0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000A5E754: BF870254
	v_mov_b32_dpp v24, v11 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A5E758: 7E3002FA FF01610B
	v_cndmask_b32_e64 v11, -v11, v11, s2                       // 000000A5E760: D501000B 200A170B
	v_add_f32_e32 v27, v17, v22                                // 000000A5E768: 06362D11
	.long 0xd44a0004                                           // 000000A5E76C: D44A0004
	v_cndmask_b32_e32 v1, 0, v23, vcc_lo                       // 000000A5E770: 02022E80
	v_dual_add_f32 v13, v13, v41 :: v_dual_and_b32 v0, 8, v0   // 000000A5E774: C924530D 0D000088
	v_add_f32_e32 v11, v11, v24                                // 000000A5E77C: 0616310B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A5E780: BF870224
	v_mov_b32_dpp v23, v27 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A5E784: 7E2E02FA FF01611B
	v_cndmask_b32_e64 v24, -v27, v27, s2                       // 000000A5E78C: D5010018 200A371B
	.long 0xd44a0001                                           // 000000A5E794: D44A0001
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 000000A5E798: 02020080
	v_sub_f32_e32 v0, v37, v21                                 // 000000A5E79C: 08002B25
	v_mov_b32_dpp v27, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A5E7A0: 7E3602FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s3                       // 000000A5E7A8: D501000B 200E170B
	v_dual_add_f32 v23, v24, v23 :: v_dual_sub_f32 v12, v18, v12// 000000A5E7B0: C90A2F18 170C1912
	v_mov_b32_dpp v41, v13 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A5E7B8: 7E5202FA FF01640D
	v_cndmask_b32_e64 v13, -v13, v13, s4                       // 000000A5E7C0: D501000D 20121B0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A5E7C8: BF870214
	v_add_f32_e32 v11, v11, v27                                // 000000A5E7CC: 0616370B
	v_mov_b32_dpp v18, v23 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A5E7D0: 7E2402FA FF016217
	v_cndmask_b32_e64 v21, -v23, v23, s3                       // 000000A5E7D8: D5010015 200E2F17
	v_sub_f32_e32 v24, v25, v40                                // 000000A5E7E0: 08305119
	v_add_f32_e32 v13, v13, v41                                // 000000A5E7E4: 061A530D
	v_mov_b32_dpp v25, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A5E7E8: 7E3202FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s4                       // 000000A5E7F0: D501000B 2012170B
	v_dual_add_f32 v18, v21, v18 :: v_dual_add_f32 v21, v0, v12// 000000A5E7F8: C9082515 12141900
	v_sub_f32_e32 v23, v30, v31                                // 000000A5E800: 082E3F1E
	v_sub_f32_e32 v17, v17, v22                                // 000000A5E804: 08222D11
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A5E808: BF870214
	v_add_f32_e32 v11, v11, v25                                // 000000A5E80C: 0616330B
	v_mov_b32_dpp v25, v18 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A5E810: 7E3202FA FF016412
	v_cndmask_b32_e64 v18, -v18, v18, s4                       // 000000A5E818: D5010012 20122512
	v_mov_b32_dpp v30, v21 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A5E820: 7E3C02FA FF016115
	v_cndmask_b32_e64 v21, -v21, v21, s2                       // 000000A5E828: D5010015 200A2B15
	v_mov_b32_dpp v22, v13 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A5E830: 7E2C02FA FF01680D
	v_cndmask_b32_e64 v13, -v13, v13, s1                       // 000000A5E838: D501000D 20061B0D
	v_add_f32_e32 v18, v18, v25                                // 000000A5E840: 06243312
	v_add_f32_e32 v29, v14, v16                                // 000000A5E844: 063A210E
	v_dual_add_f32 v21, v21, v30 :: v_dual_sub_f32 v14, v14, v16// 000000A5E848: C90A3D15 150E210E
	v_or_b32_e32 v16, 0xe0, v52                                // 000000A5E850: 382068FF 000000E0
	v_sub_f32_e32 v0, v0, v12                                  // 000000A5E858: 08001900
	v_add_f32_e32 v12, v13, v22                                // 000000A5E85C: 06182D0D
	v_mov_b32_dpp v13, v18 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A5E860: 7E1A02FA FF016812
	v_mov_b32_dpp v22, v21 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A5E868: 7E2C02FA FF016215
	v_cndmask_b32_e64 v21, -v21, v21, s3                       // 000000A5E870: D5010015 200E2B15
	v_cndmask_b32_e64 v18, -v18, v18, s1                       // 000000A5E878: D5010012 20062512
	v_mov_b32_dpp v25, v23 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A5E880: 7E3202FA FF016117
	v_cndmask_b32_e64 v23, -v23, v23, s2                       // 000000A5E888: D5010017 200A2F17
	global_load_d16_b16 v38, v16, s[6:7]                       // 000000A5E890: DC820000 26060010
	v_add_f32_e32 v21, v21, v22                                // 000000A5E898: 062A2D15
	v_add_f32_e32 v13, v18, v13                                // 000000A5E89C: 061A1B12
	global_load_d16_b16 v22, v28, s[6:7] offset:1280           // 000000A5E8A0: DC820500 1606001C
	v_add_f32_e32 v18, v23, v25                                // 000000A5E8A8: 06243317
	s_clause 0x7                                               // 000000A5E8AC: BF850007
	global_load_d16_b16 v25, v16, s[6:7] offset:1280           // 000000A5E8B0: DC820500 19060010
	global_load_d16_b16 v26, v1, s[6:7] offset:128             // 000000A5E8B8: DC820080 1A060001
	global_load_d16_b16 v32, v28, s[6:7]                       // 000000A5E8C0: DC820000 2006001C
	global_load_d16_b16 v33, v1, s[6:7] offset:1344            // 000000A5E8C8: DC820540 21060001
	global_load_d16_b16 v7, v1, s[6:7] offset:1408             // 000000A5E8D0: DC820580 07060001
	global_load_d16_b16 v34, v1, s[6:7] offset:1472            // 000000A5E8D8: DC8205C0 22060001
	global_load_d16_b16 v35, v1, s[6:7] offset:192             // 000000A5E8E0: DC8200C0 23060001
	global_load_d16_b16 v27, v45, s[6:7] offset:1280           // 000000A5E8E8: DC820500 1B06002D
	v_mov_b32_dpp v23, v21 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A5E8F0: 7E2E02FA FF016415
	v_cndmask_b32_e64 v21, -v21, v21, s4                       // 000000A5E8F8: D5010015 20122B15
	s_clause 0x5                                               // 000000A5E900: BF850005
	global_load_d16_b16 v28, v28, s[8:9]                       // 000000A5E904: DC820000 1C08001C
	global_load_d16_b16 v16, v16, s[8:9]                       // 000000A5E90C: DC820000 10080010
	global_load_d16_b16 v37, v1, s[8:9]                        // 000000A5E914: DC820000 25080001
	global_load_d16_b16 v40, v1, s[8:9] offset:64              // 000000A5E91C: DC820040 28080001
	global_load_d16_b16 v41, v1, s[8:9] offset:128             // 000000A5E924: DC820080 29080001
	global_load_d16_b16 v42, v1, s[8:9] offset:192             // 000000A5E92C: DC8200C0 2A080001
	v_mov_b32_dpp v31, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A5E934: 7E3E02FA FF01680B
	v_add_f32_e32 v21, v21, v23                                // 000000A5E93C: 062A2F15
	global_load_d16_b16 v23, v45, s[8:9]                       // 000000A5E940: DC820000 1708002D
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 000000A5E948: D501000B 2006170B
	v_mov_b32_dpp v30, v18 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A5E950: 7E3C02FA FF016212
	v_cndmask_b32_e64 v18, -v18, v18, s3                       // 000000A5E958: D5010012 200E2512
	v_add_f32_e32 v43, v36, v20                                // 000000A5E960: 06562924
	v_mov_b32_dpp v47, v24 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A5E964: 7E5E02FA FF016118
	v_add_f32_e32 v11, v11, v31                                // 000000A5E96C: 06163F0B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A5E970: BF870214
	v_dual_add_f32 v31, v29, v39 :: v_dual_add_f32 v18, v18, v30// 000000A5E974: C9084F1D 1F123D12
	v_mov_b32_dpp v45, v43 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A5E97C: 7E5A02FA FF01612B
	v_cndmask_b32_e64 v43, -v43, v43, s2                       // 000000A5E984: D501002B 200A572B
	v_cndmask_b32_e64 v24, -v24, v24, s2                       // 000000A5E98C: D5010018 200A3118
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A5E994: BF870004
	v_mov_b32_dpp v30, v31 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A5E998: 7E3C02FA FF01611F
	v_cndmask_b32_e64 v31, -v31, v31, s2                       // 000000A5E9A0: D501001F 200A3F1F
	v_mov_b32_dpp v44, v21 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A5E9A8: 7E5802FA FF016815
	v_add_f32_e32 v43, v43, v45                                // 000000A5E9B0: 06565B2B
	v_cndmask_b32_e64 v21, -v21, v21, s1                       // 000000A5E9B4: D5010015 20062B15
	v_add_f32_e32 v24, v24, v47                                // 000000A5E9BC: 06305F18
	v_add_f32_e32 v30, v31, v30                                // 000000A5E9C0: 063C3D1F
	v_mov_b32_dpp v31, v18 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A5E9C4: 7E3E02FA FF016412
	v_cndmask_b32_e64 v18, -v18, v18, s4                       // 000000A5E9CC: D5010012 20122512
	v_add_f32_e32 v21, v21, v44                                // 000000A5E9D4: 062A5915
	v_mul_f32_e32 v12, 0x3db504f3, v12                         // 000000A5E9D8: 101818FF 3DB504F3
	v_mov_b32_dpp v46, v30 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A5E9E0: 7E5C02FA FF01621E
	v_cndmask_b32_e64 v30, -v30, v30, s3                       // 000000A5E9E8: D501001E 200E3D1E
	v_add_f32_e32 v18, v18, v31                                // 000000A5E9F0: 06243F12
	v_mov_b32_dpp v31, v43 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A5E9F4: 7E3E02FA FF01622B
	v_cndmask_b32_e64 v43, -v43, v43, s3                       // 000000A5E9FC: D501002B 200E572B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A5EA04: BF870234
	v_dual_sub_f32 v29, v29, v39 :: v_dual_add_f32 v30, v30, v46// 000000A5EA08: C9484F1D 1D1E5D1E
	v_mov_b32_dpp v46, v24 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A5EA10: 7E5C02FA FF016218
	v_cndmask_b32_e64 v24, -v24, v24, s3                       // 000000A5EA18: D5010018 200E3118
	v_add_f32_e32 v31, v43, v31                                // 000000A5EA20: 063E3F2B
	v_mov_b32_dpp v43, v18 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A5EA24: 7E5602FA FF016812
	v_mov_b32_dpp v45, v30 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A5EA2C: 7E5A02FA FF01641E
	v_cndmask_b32_e64 v30, -v30, v30, s4                       // 000000A5EA34: D501001E 20123D1E
	v_add_f32_e32 v24, v24, v46                                // 000000A5EA3C: 06305D18
	v_mov_b32_dpp v44, v31 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A5EA40: 7E5802FA FF01641F
	v_cndmask_b32_e64 v31, -v31, v31, s4                       // 000000A5EA48: D501001F 20123F1F
	v_mov_b32_dpp v46, v17 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A5EA50: 7E5C02FA FF016111
	v_add_f32_e32 v30, v30, v45                                // 000000A5EA58: 063C5B1E
	v_cndmask_b32_e64 v17, -v17, v17, s2                       // 000000A5EA5C: D5010011 200A2311
	v_cndmask_b32_e64 v18, -v18, v18, s1                       // 000000A5EA64: D5010012 20062512
	v_add_f32_e32 v31, v31, v44                                // 000000A5EA6C: 063E591F
	v_mov_b32_dpp v44, v24 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A5EA70: 7E5802FA FF016418
	v_mov_b32_dpp v45, v30 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A5EA78: 7E5A02FA FF01681E
	v_cndmask_b32_e64 v30, -v30, v30, s1                       // 000000A5EA80: D501001E 20063D1E
	v_add_f32_e32 v17, v17, v46                                // 000000A5EA88: 06225D11
	v_cndmask_b32_e64 v24, -v24, v24, s4                       // 000000A5EA8C: D5010018 20123118
	v_add_f32_e32 v18, v18, v43                                // 000000A5EA94: 06245712
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A5EA98: BF870004
	v_dual_mul_f32 v11, 0x3db504f3, v11 :: v_dual_add_f32 v30, v30, v45// 000000A5EA9C: C8C816FF 0B1E5B1E 3DB504F3
	v_mov_b32_dpp v45, v31 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A5EAA8: 7E5A02FA FF01681F
	v_cndmask_b32_e64 v31, -v31, v31, s1                       // 000000A5EAB0: D501001F 20063F1F
	v_mov_b32_dpp v46, v17 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A5EAB8: 7E5C02FA FF016211
	v_cndmask_b32_e64 v17, -v17, v17, s3                       // 000000A5EAC0: D5010011 200E2311
	v_mul_f32_e32 v30, 0x3db504f3, v30                         // 000000A5EAC8: 103C3CFF 3DB504F3
	v_add_f32_e32 v24, v24, v44                                // 000000A5EAD0: 06305918
	v_dual_sub_f32 v20, v36, v20 :: v_dual_mul_f32 v13, 0x3db504f3, v13// 000000A5EAD4: C9462924 140C1AFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A5EAE0: BF8701A4
	v_add_f32_e32 v17, v17, v46                                // 000000A5EAE4: 06225D11
	v_dual_mul_f32 v21, 0x3db504f3, v21 :: v_dual_mul_f32 v18, 0x3db504f3, v18// 000000A5EAE8: C8C62AFF 151224FF 3DB504F3
	v_mov_b32_dpp v36, v20 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A5EAF4: 7E4802FA FF016114
	v_cndmask_b32_e64 v20, -v20, v20, s2                       // 000000A5EAFC: D5010014 200A2914
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A5EB04: BF8700A4
	v_mov_b32_dpp v44, v17 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A5EB08: 7E5802FA FF016411
	v_cndmask_b32_e64 v17, -v17, v17, s4                       // 000000A5EB10: D5010011 20122311
	v_add_f32_e32 v17, v17, v44                                // 000000A5EB18: 06225911
	v_mov_b32_dpp v44, v0 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A5EB1C: 7E5802FA FF016100
	v_cndmask_b32_e64 v0, -v0, v0, s2                          // 000000A5EB24: D5010000 200A0100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A5EB2C: BF870211
	v_add_f32_e32 v0, v0, v44                                  // 000000A5EB30: 06005900
	v_mov_b32_dpp v44, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A5EB34: 7E5802FA FF016811
	v_cndmask_b32_e64 v17, -v17, v17, s1                       // 000000A5EB3C: D5010011 20062311
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A5EB44: BF870091
	v_add_f32_e32 v17, v17, v44                                // 000000A5EB48: 06225911
	v_mul_f32_e32 v17, 0x3db504f3, v17                         // 000000A5EB4C: 102222FF 3DB504F3
	s_waitcnt vmcnt(22)                                        // 000000A5EB54: BF895BF7
	v_fma_mix_f32 v2, v2, v30, neg(0) op_sel_hi:[1,0,0]        // 000000A5EB58: CC200002 8A023D02
	v_add_f32_e32 v30, v31, v45                                // 000000A5EB60: 063C5B1F
	v_mov_b32_dpp v31, v24 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A5EB64: 7E3E02FA FF016818
	v_cndmask_b32_e64 v24, -v24, v24, s1                       // 000000A5EB6C: D5010018 20063118
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A5EB74: BF870214
	v_mul_f32_e32 v43, 0xbfb8aa3b, v2                          // 000000A5EB78: 105604FF BFB8AA3B
	v_mul_f32_e32 v30, 0x3db504f3, v30                         // 000000A5EB80: 103C3CFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A5EB88: BF870223
	v_add_f32_e32 v24, v24, v31                                // 000000A5EB8C: 06303F18
	v_add_f32_e32 v31, v14, v19                                // 000000A5EB90: 063E270E
	v_exp_f32_e32 v43, v43                                     // 000000A5EB94: 7E564B2B
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A5EB98: BF870003
	v_fma_mix_f32 v3, v3, v30, neg(0) op_sel_hi:[1,0,0]        // 000000A5EB9C: CC200003 8A023D03
	v_sub_f32_e32 v14, v14, v19                                // 000000A5EBA4: 081C270E
	v_mul_f32_e32 v24, 0x3db504f3, v24                         // 000000A5EBA8: 103030FF 3DB504F3
	v_mov_b32_dpp v45, v31 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A5EBB0: 7E5A02FA FF01611F
	v_cndmask_b32_e64 v31, -v31, v31, s2                       // 000000A5EBB8: D501001F 200A3F1F
	v_mul_f32_e32 v30, 0xbfb8aa3b, v3                          // 000000A5EBC0: 103C06FF BFB8AA3B
	v_mov_b32_dpp v19, v14 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A5EBC8: 7E2602FA FF01610E
	v_cndmask_b32_e64 v14, -v14, v14, s2                       // 000000A5EBD0: D501000E 200A1D0E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A5EBD8: BF870215
	v_add_f32_e32 v43, 1.0, v43                                // 000000A5EBDC: 065656F2
	v_exp_f32_e32 v30, v30                                     // 000000A5EBE0: 7E3C4B1E
	v_add_f32_e32 v31, v31, v45                                // 000000A5EBE4: 063E5B1F
	v_mov_b32_dpp v45, v0 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A5EBE8: 7E5A02FA FF016200
	v_cndmask_b32_e64 v0, -v0, v0, s3                          // 000000A5EBF0: D5010000 200E0100
	v_div_scale_f32 v46, null, v43, v43, v2                    // 000000A5EBF8: D6FC7C2E 040A572B
	s_waitcnt vmcnt(19)                                        // 000000A5EC00: BF894FF7
	v_fma_mix_f32 v4, v4, v12, neg(0) op_sel_hi:[1,0,0]        // 000000A5EC04: CC200004 8A021904
	v_mov_b32_dpp v48, v31 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A5EC0C: 7E6002FA FF01621F
	v_cndmask_b32_e64 v31, -v31, v31, s3                       // 000000A5EC14: D501001F 200E3F1F
	v_add_f32_e32 v0, v0, v45                                  // 000000A5EC1C: 06005B00
	v_rcp_f32_e32 v47, v46                                     // 000000A5EC20: 7E5E552E
	v_add_f32_e32 v30, 1.0, v30                                // 000000A5EC24: 063C3CF2
	v_fma_mix_f32 v6, v6, v11, neg(0) op_sel_hi:[1,0,0]        // 000000A5EC28: CC200006 8A021706
	v_add_f32_e32 v31, v31, v48                                // 000000A5EC30: 063E611F
	v_mov_b32_dpp v44, v0 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A5EC34: 7E5802FA FF016400
	v_cndmask_b32_e64 v0, -v0, v0, s4                          // 000000A5EC3C: D5010000 20120100
	v_div_scale_f32 v45, null, v30, v30, v3                    // 000000A5EC44: D6FC7C2D 040E3D1E
	v_add_f32_e32 v14, v14, v19                                // 000000A5EC4C: 061C270E
	v_mov_b32_dpp v50, v31 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A5EC50: 7E6402FA FF01641F
	v_cndmask_b32_e64 v31, -v31, v31, s4                       // 000000A5EC58: D501001F 20123F1F
	v_add_f32_e32 v0, v0, v44                                  // 000000A5EC60: 06005900
	v_rcp_f32_e32 v48, v45                                     // 000000A5EC64: 7E60552D
	v_add_f32_e32 v44, v15, v10                                // 000000A5EC68: 0658150F
	v_fma_f32 v49, -v46, v47, 1.0                              // 000000A5EC6C: D6130031 23CA5F2E
	v_add_f32_e32 v31, v31, v50                                // 000000A5EC74: 063E651F
	v_sub_f32_e32 v10, v15, v10                                // 000000A5EC78: 0814150F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(TRANS32_DEP_1)// 000000A5EC7C: BF8702C4
	v_mov_b32_dpp v51, v44 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A5EC80: 7E6602FA FF01612C
	v_cndmask_b32_e64 v44, -v44, v44, s2                       // 000000A5EC88: D501002C 200A592C
	v_fmac_f32_e32 v47, v49, v47                               // 000000A5EC90: 565E5F31
	v_div_scale_f32 v49, vcc_lo, v2, v43, v2                   // 000000A5EC94: D6FC6A31 040A5702
	v_fma_f32 v50, -v45, v48, 1.0                              // 000000A5EC9C: D6130032 23CA612D
	v_mov_b32_dpp v52, v31 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A5ECA4: 7E6802FA FF01681F
	v_cndmask_b32_e64 v31, -v31, v31, s1                       // 000000A5ECAC: D501001F 20063F1F
	v_add_f32_e32 v44, v44, v51                                // 000000A5ECB4: 0658672C
	v_mov_b32_dpp v51, v0 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A5ECB8: 7E6602FA FF016800
	v_fmac_f32_e32 v48, v50, v48                               // 000000A5ECC0: 56606132
	v_div_scale_f32 v50, s5, v3, v30, v3                       // 000000A5ECC4: D6FC0532 040E3D03
	v_dual_add_f32 v31, v31, v52 :: v_dual_mul_f32 v52, v49, v47// 000000A5ECCC: C906691F 1F345F31
	v_mov_b32_dpp v54, v44 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A5ECD4: 7E6C02FA FF01622C
	v_cndmask_b32_e64 v44, -v44, v44, s3                       // 000000A5ECDC: D501002C 200E592C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A5ECE4: BF870214
	v_mul_f32_e32 v53, v50, v48                                // 000000A5ECE8: 106A6132
	v_mul_f32_e32 v31, 0x3db504f3, v31                         // 000000A5ECEC: 103E3EFF 3DB504F3
	v_fma_f32 v55, -v46, v52, v49                              // 000000A5ECF4: D6130037 24C6692E
	v_cndmask_b32_e64 v0, -v0, v0, s1                          // 000000A5ECFC: D5010000 20060100
	v_add_f32_e32 v44, v44, v54                                // 000000A5ED04: 06586D2C
	v_fma_f32 v56, -v45, v53, v50                              // 000000A5ED08: D6130038 24CA6B2D
	v_fma_mix_f32 v5, v5, v31, neg(0) op_sel_hi:[1,0,0]        // 000000A5ED10: CC200005 8A023F05
	v_fmac_f32_e32 v52, v55, v47                               // 000000A5ED18: 56685F37
	v_add_f32_e32 v0, v0, v51                                  // 000000A5ED1C: 06006700
	v_mov_b32_dpp v31, v44 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A5ED20: 7E3E02FA FF01642C
	v_cndmask_b32_e64 v44, -v44, v44, s4                       // 000000A5ED28: D501002C 2012592C
	v_fmac_f32_e32 v53, v56, v48                               // 000000A5ED30: 566A6138
	v_fma_f32 v46, -v46, v52, v49                              // 000000A5ED34: D613002E 24C6692E
	v_mul_f32_e32 v51, 0xbfb8aa3b, v5                          // 000000A5ED3C: 10660AFF BFB8AA3B
	v_mov_b32_dpp v19, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A5ED44: 7E2602FA FF01610A
	v_add_f32_e32 v31, v44, v31                                // 000000A5ED4C: 063E3F2C
	v_fma_f32 v45, -v45, v53, v50                              // 000000A5ED50: D613002D 24CA6B2D
	v_div_fmas_f32 v44, v46, v47, v52                          // 000000A5ED58: D637002C 04D25F2E
	s_mov_b32 vcc_lo, s5                                       // 000000A5ED60: BEEA0005
	v_exp_f32_e32 v49, v51                                     // 000000A5ED64: 7E624B33
	v_mov_b32_dpp v46, v31 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A5ED68: 7E5C02FA FF01681F
	v_cndmask_b32_e64 v31, -v31, v31, s1                       // 000000A5ED70: D501001F 20063F1F
	v_div_fmas_f32 v45, v45, v48, v53                          // 000000A5ED78: D637002D 04D6612D
	v_div_fixup_f32 v2, v44, v43, v2                           // 000000A5ED80: D6270002 040A572C
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 000000A5ED88: D501000A 200A150A
	v_mul_f32_e32 v0, 0x3db504f3, v0                           // 000000A5ED90: 100000FF 3DB504F3
	v_add_f32_e32 v12, v31, v46                                // 000000A5ED98: 06185D1F
	v_mov_b32_dpp v31, v29 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A5ED9C: 7E3E02FA FF01611D
	v_cndmask_b32_e64 v29, -v29, v29, s2                       // 000000A5EDA4: D501001D 200A3B1D
	v_div_fixup_f32 v3, v45, v30, v3                           // 000000A5EDAC: D6270003 040E3D2D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A5EDB4: BF870224
	v_dual_mul_f32 v2, v4, v2 :: v_dual_mul_f32 v11, 0x3db504f3, v12// 000000A5EDB8: C8C60504 020A18FF 3DB504F3
	v_add_f32_e32 v10, v10, v19                                // 000000A5EDC4: 0614270A
	v_add_f32_e32 v4, v29, v31                                 // 000000A5EDC8: 06083F1D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A5EDCC: BF870004
	v_mul_f32_e32 v3, v6, v3                                   // 000000A5EDD0: 10060706
	v_add_f32_e32 v47, 1.0, v49                                // 000000A5EDD4: 065E62F2
	s_waitcnt vmcnt(17)                                        // 000000A5EDD8: BF8947F7
	v_fma_mix_f32 v6, v9, v11, neg(0) op_sel_hi:[1,0,0]        // 000000A5EDDC: CC200006 8A021709
	v_add_f32_e32 v9, v20, v36                                 // 000000A5EDE4: 06124914
	v_mov_b32_dpp v20, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A5EDE8: 7E2802FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000A5EDF0: D5010004 200E0904
	v_fma_mix_f32 v3, v8, v3, neg(0) op_sel_hi:[1,0,0]         // 000000A5EDF8: CC200003 8A020708
	v_mul_f32_e32 v8, 0xbfb8aa3b, v6                           // 000000A5EE00: 10100CFF BFB8AA3B
	v_mov_b32_dpp v29, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A5EE08: 7E3A02FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 000000A5EE10: D5010009 200E1309
	v_add_f32_e32 v4, v4, v20                                  // 000000A5EE18: 06082904
	v_div_scale_f32 v30, null, v47, v47, v5                    // 000000A5EE1C: D6FC7C1E 04165F2F
	v_exp_f32_e32 v8, v8                                       // 000000A5EE24: 7E104B08
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A5EE28: BF870193
	v_add_f32_e32 v9, v9, v29                                  // 000000A5EE2C: 06123B09
	v_mov_b32_dpp v15, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A5EE30: 7E1E02FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s4                          // 000000A5EE38: D5010004 20120904
	v_mov_b32_dpp v29, v14 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A5EE40: 7E3A02FA FF01620E
	v_cndmask_b32_e64 v14, -v14, v14, s3                       // 000000A5EE48: D501000E 200E1D0E
	v_mov_b32_dpp v20, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A5EE50: 7E2802FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s4                          // 000000A5EE58: D5010009 20121309
	v_add_f32_e32 v4, v4, v15                                  // 000000A5EE60: 06081F04
	v_mov_b32_dpp v15, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A5EE64: 7E1E02FA FF01620A
	v_add_f32_e32 v14, v14, v29                                // 000000A5EE6C: 061C3B0E
	v_cndmask_b32_e64 v10, -v10, v10, s3                       // 000000A5EE70: D501000A 200E150A
	v_add_f32_e32 v9, v9, v20                                  // 000000A5EE78: 06122909
	v_mov_b32_dpp v19, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A5EE7C: 7E2602FA FF016804
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000A5EE84: D5010004 20060904
	v_mov_b32_dpp v20, v14 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A5EE8C: 7E2802FA FF01640E
	v_cndmask_b32_e64 v14, -v14, v14, s4                       // 000000A5EE94: D501000E 20121D0E
	v_add_f32_e32 v10, v10, v15                                // 000000A5EE9C: 06141F0A
	v_rcp_f32_e32 v12, v30                                     // 000000A5EEA0: 7E18551E
	v_mov_b32_dpp v15, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A5EEA4: 7E1E02FA FF016809
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 000000A5EEAC: D5010009 20061309
	v_add_f32_e32 v4, v4, v19                                  // 000000A5EEB4: 06082704
	v_add_f32_e32 v14, v14, v20                                // 000000A5EEB8: 061C290E
	v_mov_b32_dpp v19, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A5EEBC: 7E2602FA FF01640A
	v_cndmask_b32_e64 v10, -v10, v10, s4                       // 000000A5EEC4: D501000A 2012150A
	v_dual_add_f32 v8, 1.0, v8 :: v_dual_add_f32 v9, v9, v15   // 000000A5EECC: C90810F2 08081F09
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A5EED4: BF870224
	v_mov_b32_dpp v15, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A5EED8: 7E1E02FA FF01680E
	v_cndmask_b32_e64 v14, -v14, v14, s1                       // 000000A5EEE0: D501000E 20061D0E
	v_add_f32_e32 v10, v10, v19                                // 000000A5EEE8: 0614270A
	v_fma_f32 v11, -v30, v12, 1.0                              // 000000A5EEEC: D613000B 23CA191E
	v_mul_f32_e32 v4, 0x3db504f3, v4                           // 000000A5EEF4: 100808FF 3DB504F3
	v_div_scale_f32 v19, null, v8, v8, v6                      // 000000A5EEFC: D6FC7C13 041A1108
	v_add_f32_e32 v14, v14, v15                                // 000000A5EF04: 061C1F0E
	v_mov_b32_dpp v15, v10 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A5EF08: 7E1E02FA FF01680A
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 000000A5EF10: D501000A 2006150A
	v_fmac_f32_e32 v12, v11, v12                               // 000000A5EF18: 5618190B
	v_div_scale_f32 v11, vcc_lo, v5, v47, v5                   // 000000A5EF1C: D6FC6A0B 04165F05
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 000000A5EF24: 101212FF 3DB504F3
	v_rcp_f32_e32 v20, v19                                     // 000000A5EF2C: 7E285513
	v_add_f32_e32 v10, v10, v15                                // 000000A5EF30: 06141F0A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A5EF34: BF8701B3
	v_dual_mul_f32 v14, 0x3db504f3, v14 :: v_dual_mul_f32 v15, v11, v12// 000000A5EF38: C8C61CFF 0E0E190B 3DB504F3
	s_waitcnt vmcnt(12)                                        // 000000A5EF44: BF8933F7
	v_fma_mix_f32 v9, v32, v9, neg(0) op_sel_hi:[1,0,0]        // 000000A5EF48: CC200009 8A021320
	v_mul_f32_e32 v10, 0x3db504f3, v10                         // 000000A5EF50: 101414FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A5EF58: BF870003
	v_fma_f32 v31, -v30, v15, v11                              // 000000A5EF5C: D613001F 242E1F1E
	v_fma_mix_f32 v4, v26, v4, neg(0) op_sel_hi:[1,0,0]        // 000000A5EF64: CC200004 8A02091A
	s_waitcnt vmcnt(8)                                         // 000000A5EF6C: BF8923F7
	v_fma_mix_f32 v14, v35, v14, neg(0) op_sel_hi:[1,0,0]      // 000000A5EF70: CC20000E 8A021D23
	v_mul_f32_e32 v29, 0xbfb8aa3b, v9                          // 000000A5EF78: 103A12FF BFB8AA3B
	v_fma_f32 v32, -v19, v20, 1.0                              // 000000A5EF80: D6130020 23CA2913
	v_fma_mix_f32 v10, v38, v10, neg(0) op_sel_hi:[1,0,0]      // 000000A5EF88: CC20000A 8A021526
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A5EF90: BF870214
	v_dual_mul_f32 v26, 0xbfb8aa3b, v4 :: v_dual_mul_f32 v35, 0xbfb8aa3b, v14// 000000A5EF94: C8C608FF 1A221CFF BFB8AA3B
	v_exp_f32_e32 v29, v29                                     // 000000A5EFA0: 7E3A4B1D
	v_fmac_f32_e32 v15, v31, v12                               // 000000A5EFA4: 561E191F
	v_fmac_f32_e32 v20, v32, v20                               // 000000A5EFA8: 56282920
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A5EFAC: BF870003
	v_exp_f32_e32 v26, v26                                     // 000000A5EFB0: 7E344B1A
	v_mul_f32_e32 v32, 0xbfb8aa3b, v10                         // 000000A5EFB4: 104014FF BFB8AA3B
	v_exp_f32_e32 v31, v35                                     // 000000A5EFBC: 7E3E4B23
	v_fma_f32 v11, -v30, v15, v11                              // 000000A5EFC0: D613000B 242E1F1E
	v_div_scale_f32 v35, s5, v6, v8, v6                        // 000000A5EFC8: D6FC0523 041A1106
	v_fma_mix_f32 v13, v33, v13, neg(0) op_sel_hi:[1,0,0]      // 000000A5EFD0: CC20000D 8A021B21
	v_exp_f32_e32 v30, v32                                     // 000000A5EFD8: 7E3C4B20
	v_add_f32_e32 v29, 1.0, v29                                // 000000A5EFDC: 063A3AF2
	v_div_fmas_f32 v11, v11, v12, v15                          // 000000A5EFE0: D637000B 043E190B
	v_mul_f32_e32 v32, v35, v20                                // 000000A5EFE8: 10402923
	v_add_f32_e32 v26, 1.0, v26                                // 000000A5EFEC: 063434F2
	s_mov_b32 vcc_lo, s5                                       // 000000A5EFF0: BEEA0005
	v_add_f32_e32 v31, 1.0, v31                                // 000000A5EFF4: 063E3EF2
	v_div_scale_f32 v39, null, v29, v29, v9                    // 000000A5EFF8: D6FC7C27 04263B1D
	v_fma_f32 v15, -v19, v32, v35                              // 000000A5F000: D613000F 248E4113
	v_div_scale_f32 v36, null, v26, v26, v4                    // 000000A5F008: D6FC7C24 0412351A
	v_add_f32_e32 v30, 1.0, v30                                // 000000A5F010: 063C3CF2
	v_div_scale_f32 v12, null, v31, v31, v14                   // 000000A5F014: D6FC7C0C 043A3F1F
	v_rcp_f32_e32 v43, v39                                     // 000000A5F01C: 7E565527
	v_fmac_f32_e32 v32, v15, v20                               // 000000A5F020: 5640290F
	v_rcp_f32_e32 v38, v36                                     // 000000A5F024: 7E4C5524
	v_div_scale_f32 v33, null, v30, v30, v10                   // 000000A5F028: D6FC7C21 042A3D1E
	v_rcp_f32_e32 v45, v12                                     // 000000A5F030: 7E5A550C
	v_div_fixup_f32 v5, v11, v47, v5                           // 000000A5F034: D6270005 04165F0B
	v_div_scale_f32 v11, s6, v4, v26, v4                       // 000000A5F03C: D6FC060B 04123504
	v_fma_f32 v19, -v19, v32, v35                              // 000000A5F044: D6130013 248E4113
	v_rcp_f32_e32 v15, v33                                     // 000000A5F04C: 7E1E5521
	s_waitcnt vmcnt(7)                                         // 000000A5F050: BF891FF7
	v_fma_mix_f32 v21, v27, v21, neg(0) op_sel_hi:[1,0,0]      // 000000A5F054: CC200015 8A022B1B
	v_mul_f32_e32 v5, v13, v5                                  // 000000A5F05C: 100A0B0D
	v_fma_mix_f32 v0, v25, v0, neg(0) op_sel_hi:[1,0,0]        // 000000A5F060: CC200000 8A020119
	v_fma_f32 v44, -v36, v38, 1.0                              // 000000A5F068: D613002C 23CA4D24
	v_div_fmas_f32 v19, v19, v20, v32                          // 000000A5F070: D6370013 04822913
	v_fma_f32 v13, -v12, v45, 1.0                              // 000000A5F078: D613000D 23CA5B0C
	s_mov_b32 vcc_lo, s6                                       // 000000A5F080: BEEA0006
	v_fma_mix_f32 v7, v7, v18, neg(0) op_sel_hi:[1,0,0]        // 000000A5F084: CC200007 8A022507
	v_fmac_f32_e32 v38, v44, v38                               // 000000A5F08C: 564C4D2C
	v_fma_f32 v44, -v39, v43, 1.0                              // 000000A5F090: D613002C 23CA5727
	v_fma_f32 v46, -v33, v15, 1.0                              // 000000A5F098: D613002E 23CA1F21
	v_fmac_f32_e32 v45, v13, v45                               // 000000A5F0A0: 565A5B0D
	v_div_scale_f32 v13, s8, v14, v31, v14                     // 000000A5F0A4: D6FC080D 043A3F0E
	v_mul_f32_e32 v35, v11, v38                                // 000000A5F0AC: 10464D0B
	v_fmac_f32_e32 v43, v44, v43                               // 000000A5F0B0: 5656572C
	v_div_scale_f32 v44, s7, v9, v29, v9                       // 000000A5F0B4: D6FC072C 04263B09
	v_fmac_f32_e32 v15, v46, v15                               // 000000A5F0BC: 561E1F2E
	v_div_scale_f32 v46, s5, v10, v30, v10                     // 000000A5F0C0: D6FC052E 042A3D0A
	v_fma_f32 v20, -v36, v35, v11                              // 000000A5F0C8: D6130014 242E4724
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A5F0D0: BF8701A4
	v_dual_mul_f32 v47, v13, v45 :: v_dual_mul_f32 v32, v44, v43// 000000A5F0D4: C8C65B0D 2F20572C
	v_div_fixup_f32 v6, v19, v8, v6                            // 000000A5F0DC: D6270006 041A1113
	v_dual_fmac_f32 v35, v20, v38 :: v_dual_mul_f32 v20, v46, v15// 000000A5F0E4: C8064D14 23141F2E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A5F0EC: BF870213
	v_fma_f32 v8, -v39, v32, v44                               // 000000A5F0F0: D6130008 24B24127
	v_fma_f32 v19, -v12, v47, v13                              // 000000A5F0F8: D6130013 24365F0C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A5F100: BF870214
	v_mul_f32_e32 v6, v21, v6                                  // 000000A5F104: 100C0D15
	v_fma_f32 v11, -v36, v35, v11                              // 000000A5F108: D613000B 242E4724
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A5F110: BF870234
	v_fmac_f32_e32 v32, v8, v43                                // 000000A5F114: 56405708
	v_fma_f32 v8, -v33, v20, v46                               // 000000A5F118: D6130008 24BA2921
	v_fmac_f32_e32 v47, v19, v45                               // 000000A5F120: 565E5B13
	v_div_fmas_f32 v11, v11, v38, v35                          // 000000A5F124: D637000B 048E4D0B
	s_mov_b32 vcc_lo, s7                                       // 000000A5F12C: BEEA0007
	v_fma_f32 v19, -v39, v32, v44                              // 000000A5F130: D6130013 24B24127
	v_fmac_f32_e32 v20, v8, v15                                // 000000A5F138: 56281F08
	v_fma_f32 v8, -v12, v47, v13                               // 000000A5F13C: D6130008 24365F0C
	v_div_fixup_f32 v4, v11, v26, v4                           // 000000A5F144: D6270004 0412350B
	v_fma_mix_f32 v11, v34, v17, neg(0) op_sel_hi:[1,0,0]      // 000000A5F14C: CC20000B 8A022322
	v_div_fmas_f32 v12, v19, v43, v32                          // 000000A5F154: D637000C 04825713
	v_fma_f32 v13, -v33, v20, v46                              // 000000A5F15C: D613000D 24BA2921
	s_mov_b32 vcc_lo, s8                                       // 000000A5F164: BEEA0008
	s_waitcnt vmcnt(0)                                         // 000000A5F168: BF8903F7
	v_fma_mix_f32 v6, v23, v6, neg(0) op_sel_hi:[1,0,0]        // 000000A5F16C: CC200006 8A020D17
	v_div_fmas_f32 v8, v8, v45, v47                            // 000000A5F174: D6370008 04BE5B08
	s_mov_b32 vcc_lo, s5                                       // 000000A5F17C: BEEA0005
	v_div_fixup_f32 v9, v12, v29, v9                           // 000000A5F180: D6270009 04263B0C
	v_div_fmas_f32 v13, v13, v15, v20                          // 000000A5F188: D637000D 04521F0D
	v_fma_mix_f32 v12, v22, v24, neg(0) op_sel_hi:[1,0,0]      // 000000A5F190: CC20000C 8A023116
	v_div_fixup_f32 v8, v8, v31, v14                           // 000000A5F198: D6270008 043A3F08
	v_mul_f32_e32 v4, v7, v4                                   // 000000A5F1A0: 10080907
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A5F1A4: BF870194
	v_div_fixup_f32 v10, v13, v30, v10                         // 000000A5F1A8: D627000A 042A3D0D
	v_dual_mul_f32 v9, v12, v9 :: v_dual_mul_f32 v8, v11, v8   // 000000A5F1B0: C8C6130C 0908110B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A5F1B8: BF870112
	v_mul_f32_e32 v0, v0, v10                                  // 000000A5F1BC: 10001500
	v_fma_mix_f32 v7, v28, v9, neg(0) op_sel_hi:[1,0,0]        // 000000A5F1C0: CC200007 8A02131C
	v_fma_mix_f32 v9, v2, v37, v3 op_sel_hi:[0,1,0]            // 000000A5F1C8: CC200009 140E4B02
	v_fma_mix_f32 v10, v5, v40, v6 op_sel_hi:[0,1,0]           // 000000A5F1D0: CC20000A 141A5105
	v_fma_mix_f32 v2, v2, v37, -v3 op_sel_hi:[0,1,0]           // 000000A5F1D8: CC200002 940E4B02
	v_fma_mix_f32 v0, v16, v0, neg(0) op_sel_hi:[1,0,0]        // 000000A5F1E0: CC200000 8A020110
	v_fma_mix_f32 v11, v4, v41, v7 op_sel_hi:[0,1,0]           // 000000A5F1E8: CC20000B 141E5304
	v_fma_mix_f32 v3, v5, v40, -v6 op_sel_hi:[0,1,0]           // 000000A5F1F0: CC200003 941A5105
	v_fma_mix_f32 v4, v4, v41, -v7 op_sel_hi:[0,1,0]           // 000000A5F1F8: CC200004 941E5304
	v_add_f32_e32 v5, v9, v10                                  // 000000A5F200: 060A1509
	v_fma_mix_f32 v12, v8, v42, v0 op_sel_hi:[0,1,0]           // 000000A5F204: CC20000C 14025508
	v_fma_mix_f32 v0, v8, v42, -v0 op_sel_hi:[0,1,0]           // 000000A5F20C: CC200000 94025508
	v_dual_sub_f32 v7, v9, v10 :: v_dual_add_f32 v8, v2, v3    // 000000A5F214: C9481509 07080702
	v_sub_f32_e32 v2, v2, v3                                   // 000000A5F21C: 08040702
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A5F220: BF8701B4
	v_add_f32_e32 v6, v11, v12                                 // 000000A5F224: 060C190B
	v_sub_f32_e32 v9, v11, v12                                 // 000000A5F228: 0812190B
	v_add_f32_e32 v10, v4, v0                                  // 000000A5F22C: 06140104
	v_dual_sub_f32 v0, v4, v0 :: v_dual_add_f32 v3, v5, v6     // 000000A5F230: C9480104 00020D05
	v_sub_f32_e32 v4, v5, v6                                   // 000000A5F238: 08080D05
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A5F23C: BF870003
	v_add_f32_e32 v6, v8, v10                                  // 000000A5F240: 060C1508
	v_sub_f32_e32 v8, v8, v10                                  // 000000A5F244: 08101508
	v_add_f32_e32 v10, v7, v9                                  // 000000A5F248: 06141307
	v_mov_b32_dpp v5, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A5F24C: 7E0A02FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s2                          // 000000A5F254: D5010003 200A0703
	v_sub_f32_e32 v7, v7, v9                                   // 000000A5F25C: 080E1307
	v_mov_b32_dpp v14, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A5F260: 7E1C02FA FF016104
	v_mov_b32_dpp v9, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A5F268: 7E1202FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 000000A5F270: D501000A 200A150A
	v_add_f32_e32 v3, v3, v5                                   // 000000A5F278: 06060B03
	v_mov_b32_dpp v5, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A5F27C: 7E0A02FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s2                          // 000000A5F284: D5010006 200A0D06
	v_cndmask_b32_e64 v15, -v4, v4, s2                         // 000000A5F28C: D501000F 200A0904
	v_add_f32_e32 v9, v10, v9                                  // 000000A5F294: 0612130A
	v_mov_b32_dpp v11, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A5F298: 7E1602FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 000000A5F2A0: D5010003 200E0703
	v_add_f32_e32 v5, v6, v5                                   // 000000A5F2A8: 060A0B06
	v_add_f32_e32 v6, v2, v0                                   // 000000A5F2AC: 060C0102
	v_sub_f32_e32 v10, v2, v0                                  // 000000A5F2B0: 08140102
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A5F2B4: BF870214
	v_add_f32_e32 v0, v3, v11                                  // 000000A5F2B8: 06001703
	v_mov_b32_dpp v2, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A5F2BC: 7E0402FA FF016205
	v_cndmask_b32_e64 v3, -v5, v5, s3                          // 000000A5F2C4: D5010003 200E0B05
	v_mov_b32_dpp v5, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A5F2CC: 7E0A02FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 000000A5F2D4: D5010009 200E1309
	v_mov_b32_dpp v11, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A5F2DC: 7E1602FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s2                          // 000000A5F2E4: D5010006 200A0D06
	v_add_f32_e32 v2, v3, v2                                   // 000000A5F2EC: 06040503
	v_mov_b32_dpp v16, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A5F2F0: 7E2002FA FF01610A
	v_add_f32_e32 v5, v9, v5                                   // 000000A5F2F8: 060A0B09
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 000000A5F2FC: D501000A 200A150A
	v_add_f32_e32 v6, v6, v11                                  // 000000A5F304: 060C1706
	v_mov_b32_dpp v9, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A5F308: 7E1202FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s4                          // 000000A5F310: D5010002 20120502
	v_mov_b32_dpp v11, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A5F318: 7E1602FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s4                          // 000000A5F320: D5010005 20120B05
	v_mov_b32_dpp v12, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A5F328: 7E1802FA FF016206
	v_cndmask_b32_e64 v13, -v6, v6, s3                         // 000000A5F330: D501000D 200E0D06
	v_add_f32_e32 v4, v2, v9                                   // 000000A5F338: 06081302
	v_add_f32_e32 v10, v10, v16                                // 000000A5F33C: 0614210A
	v_dual_add_f32 v6, v5, v11 :: v_dual_add_f32 v11, v15, v14 // 000000A5F340: C9081705 060A1D0F
	v_mov_b32_dpp v14, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A5F348: 7E1C02FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 000000A5F350: D5010008 200A1108
	v_mov_b32_dpp v15, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A5F358: 7E1E02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s2                          // 000000A5F360: D5010007 200A0F07
	v_add_f32_e32 v9, v13, v12                                 // 000000A5F368: 0612190D
	v_mov_b32_dpp v13, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A5F36C: 7E1A02FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s3                       // 000000A5F374: D501000B 200E170B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A5F37C: BF870234
	v_dual_add_f32 v8, v8, v14 :: v_dual_add_f32 v7, v7, v15   // 000000A5F380: C9081D08 08061F07
	v_mov_b32_dpp v15, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A5F388: 7E1E02FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, s3                       // 000000A5F390: D501000A 200E150A
	v_add_f32_e32 v11, v11, v13                                // 000000A5F398: 06161B0B
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A5F39C: BF870004
	v_mov_b32_dpp v13, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A5F3A0: 7E1A02FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s3                          // 000000A5F3A8: D5010008 200E1108
	v_mov_b32_dpp v14, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A5F3B0: 7E1C02FA FF016207
	v_cndmask_b32_e64 v7, -v7, v7, s3                          // 000000A5F3B8: D5010007 200E0F07
	v_add_f32_e32 v10, v10, v15                                // 000000A5F3C0: 06141F0A
	v_mov_b32_dpp v3, v0 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A5F3C4: 7E0602FA FF016400
	v_add_f32_e32 v8, v8, v13                                  // 000000A5F3CC: 06101B08
	v_cndmask_b32_e64 v0, -v0, v0, s4                          // 000000A5F3D0: D5010000 20120100
	v_add_f32_e32 v7, v7, v14                                  // 000000A5F3D8: 060E1D07
	v_mov_b32_dpp v12, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A5F3DC: 7E1802FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s4                          // 000000A5F3E4: D5010009 20121309
	v_mov_b32_dpp v13, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A5F3EC: 7E1A02FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s4                       // 000000A5F3F4: D501000B 2012170B
	v_mov_b32_dpp v14, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A5F3FC: 7E1C02FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, s4                          // 000000A5F404: D5010008 20121108
	v_mov_b32_dpp v15, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A5F40C: 7E1E02FA FF016407
	v_cndmask_b32_e64 v7, -v7, v7, s4                          // 000000A5F414: D5010007 20120F07
	v_mov_b32_dpp v16, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A5F41C: 7E2002FA FF01640A
	v_cndmask_b32_e64 v17, -v10, v10, s4                       // 000000A5F424: D5010011 2012150A
	v_dual_add_f32 v0, v0, v3 :: v_dual_add_f32 v9, v9, v12    // 000000A5F42C: C9080700 00081909
	v_dual_add_f32 v10, v11, v13 :: v_dual_add_f32 v11, v8, v14// 000000A5F434: C9081B0B 0A0A1D08
	v_add_f32_e32 v13, v7, v15                                 // 000000A5F43C: 061A1F07
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A5F440: BF870214
	v_add_f32_e32 v15, v17, v16                                // 000000A5F444: 061E2111
	v_mov_b32_dpp v2, v0 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A5F448: 7E0402FA FF016800
	v_mov_b32_dpp v3, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A5F450: 7E0602FA FF016804
	v_mov_b32_dpp v5, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A5F458: 7E0A02FA FF016806
	v_mov_b32_dpp v7, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A5F460: 7E0E02FA FF016809
	v_mov_b32_dpp v8, v10 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A5F468: 7E1002FA FF01680A
	v_mov_b32_dpp v12, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A5F470: 7E1802FA FF01680B
	v_mov_b32_dpp v14, v13 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A5F478: 7E1C02FA FF01680D
	v_mov_b32_dpp v16, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A5F480: 7E2002FA FF01680F
	s_mov_b32 s2, 0x3db504f3                                   // 000000A5F488: BE8200FF 3DB504F3
	s_and_b32 exec_lo, exec_lo, s0                             // 000000A5F490: 8B7E007E
	s_cbranch_execz 65                                         // 000000A5F494: BFA50041 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi3ELi8ELi0ELi0EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x389c>
	v_cndmask_b32_e64 v15, -v15, v15, s1                       // 000000A5F498: D501000F 20061F0F
	v_cndmask_b32_e64 v0, -v0, v0, s1                          // 000000A5F4A0: D5010000 20060100
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000A5F4A8: D5010004 20060904
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 000000A5F4B0: D5010006 20060D06
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 000000A5F4B8: D5010009 20061309
	v_cndmask_b32_e64 v13, -v13, v13, s1                       // 000000A5F4C0: D501000D 20061B0D
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 000000A5F4C8: D501000A 2006150A
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 000000A5F4D0: D501000B 2006170B
	v_dual_add_f32 v15, v15, v16 :: v_dual_add_f32 v0, v0, v2  // 000000A5F4D8: C908210F 0F000500
	v_add_f32_e32 v3, v4, v3                                   // 000000A5F4E0: 06060704
	v_add_f32_e32 v5, v6, v5                                   // 000000A5F4E4: 060A0B06
	v_add_f32_e32 v7, v9, v7                                   // 000000A5F4E8: 060E0F09
	s_mul_i32 s0, s16, 0x500                                   // 000000A5F4EC: 9600FF10 00000500
	v_dual_add_f32 v13, v13, v14 :: v_dual_add_f32 v8, v10, v8 // 000000A5F4F4: C9081D0D 0D08110A
	s_mul_hi_i32 s1, s16, 0x500                                // 000000A5F4FC: 9701FF10 00000500
	v_add_f32_e32 v11, v11, v12                                // 000000A5F504: 0616190B
	s_add_u32 s0, s14, s0                                      // 000000A5F508: 8000000E
	v_fma_mixlo_f16 v0, v0, s2, 0                              // 000000A5F50C: CC210000 02000500
	s_addc_u32 s1, s15, s1                                     // 000000A5F514: 8201010F
	v_fma_mixhi_f16 v0, v3, s2, 0                              // 000000A5F518: CC220000 02000503
	s_add_u32 s0, s0, s10                                      // 000000A5F520: 80000A00
	v_fma_mixlo_f16 v2, v5, s2, 0                              // 000000A5F524: CC210002 02000505
	s_addc_u32 s1, s1, s11                                     // 000000A5F52C: 82010B01
	v_fma_mixhi_f16 v2, v7, s2, 0                              // 000000A5F530: CC220002 02000507
	v_fma_mixlo_f16 v3, v8, s2, 0                              // 000000A5F538: CC210003 02000508
	v_fma_mixhi_f16 v3, v11, s2, 0                             // 000000A5F540: CC220003 0200050B
	v_fma_mixlo_f16 v4, v13, s2, 0                             // 000000A5F548: CC210004 0200050D
	v_fma_mixhi_f16 v4, v15, s2, 0                             // 000000A5F550: CC220004 0200050F
	s_clause 0x7                                               // 000000A5F558: BF850007
	global_store_b16 v1, v0, s[0:1]                            // 000000A5F55C: DC660000 00000001
	global_store_d16_hi_b16 v1, v0, s[0:1] offset:32           // 000000A5F564: DC960020 00000001
	global_store_b16 v1, v2, s[0:1] offset:64                  // 000000A5F56C: DC660040 00000201
	global_store_d16_hi_b16 v1, v2, s[0:1] offset:96           // 000000A5F574: DC960060 00000201
	global_store_b16 v1, v3, s[0:1] offset:128                 // 000000A5F57C: DC660080 00000301
	global_store_d16_hi_b16 v1, v3, s[0:1] offset:160          // 000000A5F584: DC9600A0 00000301
	global_store_b16 v1, v4, s[0:1] offset:192                 // 000000A5F58C: DC6600C0 00000401
	global_store_d16_hi_b16 v1, v4, s[0:1] offset:224          // 000000A5F594: DC9600E0 00000401
	s_endpgm                                                   // 000000A5F59C: BFB00000
		...

