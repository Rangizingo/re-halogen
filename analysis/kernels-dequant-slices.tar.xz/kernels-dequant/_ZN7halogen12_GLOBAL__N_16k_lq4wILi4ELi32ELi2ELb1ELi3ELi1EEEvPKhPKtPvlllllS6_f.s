0000000000842700 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000842700: F4100100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 000000842708: 86039F02
	v_lshrrev_b32_e32 v21, 2, v0                               // 00000084270C: 322A0082
	s_lshl_b64 s[20:21], s[2:3], 2                             // 000000842710: 84948202
	v_and_b32_e32 v1, 15, v0                                   // 000000842714: 3602008F
	v_lshrrev_b32_e32 v22, 6, v0                               // 000000842718: 322C0086
	v_bfe_u32 v23, v0, 5, 1                                    // 00000084271C: D6100017 02050B00
	v_and_b32_e32 v2, 60, v21                                  // 000000842724: 36042ABC
	.long 0x7f0a3880                                           // 000000842728: 7F0A3880
	v_lshlrev_b32_e32 v1, 2, v1                                // 00000084272C: 30020282
	s_waitcnt lgkmcnt(0)                                       // 000000842730: BF89FC07
	s_clause 0x1                                               // 000000842734: BF850001
	global_load_b32 v3, v1, s[4:5]                             // 000000842738: DC520000 03040001
	global_load_b32 v4, v2, s[4:5]                             // 000000842740: DC520000 04040002
	s_add_u32 s2, s4, s16                                      // 000000842748: 80021004
	s_addc_u32 s3, s5, s17                                     // 00000084274C: 82031105
	s_ashr_i32 s16, s11, 31                                    // 000000842750: 86109F0B
	v_mov_b32_e32 v2, s21                                      // 000000842754: 7E040215
	s_lshr_b32 s16, s16, 27                                    // 000000842758: 85109B10
	v_or_b32_e32 v1, s20, v22                                  // 00000084275C: 38022C14
	s_add_u32 s16, s10, s16                                    // 000000842760: 8010100A
	s_addc_u32 s17, s11, 0                                     // 000000842764: 8211800B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000842768: BF870099
	s_lshr_b64 s[16:17], s[16:17], 5                           // 00000084276C: 85908510
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 000000842770: 7CA8020C
	s_add_i32 s17, s16, 1                                      // 000000842774: 81118110
	v_and_b32_e32 v24, 31, v0                                  // 000000842778: 3630009F
	s_lshr_b32 s22, s17, 31                                    // 00000084277C: 85169F11
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000842780: BF870009
	s_add_i32 s17, s17, s22                                    // 000000842784: 81111611
	v_cndmask_b32_e32 v9, 0, v1, vcc_lo                        // 000000842788: 02120280
	s_ashr_i32 s17, s17, 1                                     // 00000084278C: 86118111
	v_cndmask_b32_e64 v10, 0, s21, vcc_lo                      // 000000842790: D501000A 01A82A80
	.long 0xd72c0002                                           // 000000842798: D72C0002
	v_cndmask_b32_e32 v1, s17, v23, vcc_lo                     // 00000084279C: 02022E11
	s_cmpk_lt_i32 s16, 0x201                                   // 0000008427A0: B3900201
	.long 0xd72c0007                                           // 0000008427A4: D72C0007
	v_cndmask_b32_e32 v1, s19, v9, vcc_lo                      // 0000008427A8: 02021213
	v_mad_u64_u32 v[17:18], null, s18, v9, s[2:3]              // 0000008427AC: D6FE7C11 000A1212
	s_cselect_b32 s2, -1, 0                                    // 0000008427B4: 980280C1
	s_cmpk_gt_i32 s16, 0x200                                   // 0000008427B8: B2900200
	v_lshlrev_b32_e32 v1, 2, v0                                // 0000008427BC: 30020082
	v_add_nc_u32_e32 v11, s17, v2                              // 0000008427C0: 4A160411
	v_add_nc_u32_e32 v25, v2, v24                              // 0000008427C4: 4A323102
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000008427C8: BF8704A2
	v_min_i32_e32 v26, s16, v11                                // 0000008427CC: 22341610
	s_cselect_b32 s16, -1, 0                                   // 0000008427D0: 981080C1
	s_and_b32 vcc_lo, exec_lo, s16                             // 0000008427D4: 8B6A107E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000008427D8: BF870151
	.long 0xd4410003                                           // 0000008427DC: D4410003
	v_cndmask_b32_e32 v1, v25, v26, vcc_lo                     // 0000008427E0: 02023519
	s_waitcnt vmcnt(1)                                         // 0000008427E4: BF8907F7
	v_bfe_u32 v6, v3, 16, 1                                    // 0000008427E8: D6100006 02052103
	s_waitcnt vmcnt(0)                                         // 0000008427F0: BF8903F7
	v_bfe_u32 v8, v4, 16, 1                                    // 0000008427F4: D6100008 02052104
	v_add3_u32 v3, v3, v6, 0x7fff                              // 0000008427FC: D6550003 03FE0D03 00007FFF
	.long 0xd72c0006                                           // 000000842808: D72C0006
	v_cndmask_b32_e32 v1, s18, v10, vcc_lo                     // 00000084280C: 02021412
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000842810: BF870193
	v_add3_u32 v4, v4, v8, 0x7fff                              // 000000842814: D6550004 03FE1104 00007FFF
	.long 0x7e0a3983                                           // 000000842820: 7E0A3983
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000842824: BF870113
	v_add3_u32 v27, v7, v18, v6                                // 000000842828: D655001B 041A2507
	v_and_or_b32 v2, 0xffff0000, v4, v5                        // 000000842830: D6570002 041608FF FFFF0000
	ds_store_b32 v1, v2                                        // 00000084283C: D8340000 00000201
	s_waitcnt lgkmcnt(0)                                       // 000000842844: BF89FC07
	s_barrier                                                  // 000000842848: BFBD0000
	buffer_gl0_inv                                             // 00000084284C: E0AC0000 00000000
	s_cbranch_vccnz 154                                        // 000000842854: BFA4009A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x3c0>
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v1, 0               // 000000842858: CA100080 02000080
	s_and_saveexec_b32 s17, s3                                 // 000000842860: BE912003
	s_cbranch_execz 11                                         // 000000842864: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x194>
	v_lshlrev_b32_e32 v1, 1, v25                               // 000000842868: 30023281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084286C: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v1                               // 000000842870: 3408029F
	.long 0xd7006a03                                           // 000000842874: D7006A03
	v_cndmask_b32_e32 v1, v17, v1, vcc_lo                      // 000000842878: 02020311
	v_add_co_ci_u32_e64 v4, null, v27, v4, vcc_lo              // 00000084287C: D5207C04 01AA091B
	global_load_d16_b16 v1, v[3:4], off                        // 000000842884: DC820000 017C0003
	s_waitcnt vmcnt(0)                                         // 00000084288C: BF8903F7
	v_cvt_f32_f16_e32 v1, v1                                   // 000000842890: 7E021701
	s_or_b32 exec_lo, exec_lo, s17                             // 000000842894: 8C7E117E
	v_add_nc_u32_e32 v3, 32, v25                               // 000000842898: 4A0632A0
	s_mov_b32 s3, exec_lo                                      // 00000084289C: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008428A0: BF870001
	.long 0xd4c1007e                                           // 0000008428A4: D4C1007E
	v_cndmask_b32_e32 v1, v3, v26, vcc_lo                      // 0000008428A8: 02023503
	s_cbranch_execz 11                                         // 0000008428AC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x1dc>
	v_lshlrev_b32_e32 v2, 1, v3                                // 0000008428B0: 30040681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008428B4: BF8700A1
	v_ashrrev_i32_e32 v3, 31, v2                               // 0000008428B8: 3406049F
	.long 0xd7006a02                                           // 0000008428BC: D7006A02
	v_cndmask_b32_e32 v1, v17, v2, vcc_lo                      // 0000008428C0: 02020511
	v_add_co_ci_u32_e64 v3, null, v27, v3, vcc_lo              // 0000008428C4: D5207C03 01AA071B
	global_load_d16_b16 v2, v[2:3], off                        // 0000008428CC: DC820000 027C0002
	s_waitcnt vmcnt(0)                                         // 0000008428D4: BF8903F7
	v_cvt_f32_f16_e32 v2, v2                                   // 0000008428D8: 7E041702
	s_or_b32 exec_lo, exec_lo, s3                              // 0000008428DC: 8C7E037E
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v5, 64, v25      // 0000008428E0: CA200080 040432C0
	v_mov_b32_e32 v3, 0                                        // 0000008428E8: 7E060280
	s_mov_b32 s3, exec_lo                                      // 0000008428EC: BE83007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008428F0: BF870002
	.long 0xd4c1007e                                           // 0000008428F4: D4C1007E
	v_cndmask_b32_e32 v1, v5, v26, vcc_lo                      // 0000008428F8: 02023505
	s_cbranch_execz 11                                         // 0000008428FC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x22c>
	v_lshlrev_b32_e32 v3, 1, v5                                // 000000842900: 30060A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000842904: BF8700A1
	v_ashrrev_i32_e32 v6, 31, v3                               // 000000842908: 340C069F
	.long 0xd7006a05                                           // 00000084290C: D7006A05
	v_cndmask_b32_e32 v1, v17, v3, vcc_lo                      // 000000842910: 02020711
	v_add_co_ci_u32_e64 v6, null, v27, v6, vcc_lo              // 000000842914: D5207C06 01AA0D1B
	global_load_d16_b16 v3, v[5:6], off                        // 00000084291C: DC820000 037C0005
	s_waitcnt vmcnt(0)                                         // 000000842924: BF8903F7
	v_cvt_f32_f16_e32 v3, v3                                   // 000000842928: 7E061703
	s_or_b32 exec_lo, exec_lo, s3                              // 00000084292C: 8C7E037E
	v_add_nc_u32_e32 v5, 0x60, v25                             // 000000842930: 4A0A32FF 00000060
	s_mov_b32 s3, exec_lo                                      // 000000842938: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000084293C: BF870001
	.long 0xd4c1007e                                           // 000000842940: D4C1007E
	v_cndmask_b32_e32 v1, v5, v26, vcc_lo                      // 000000842944: 02023505
	s_cbranch_execz 11                                         // 000000842948: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x278>
	v_lshlrev_b32_e32 v4, 1, v5                                // 00000084294C: 30080A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000842950: BF8700A1
	v_ashrrev_i32_e32 v5, 31, v4                               // 000000842954: 340A089F
	.long 0xd7006a04                                           // 000000842958: D7006A04
	v_cndmask_b32_e32 v1, v17, v4, vcc_lo                      // 00000084295C: 02020911
	v_add_co_ci_u32_e64 v5, null, v27, v5, vcc_lo              // 000000842960: D5207C05 01AA0B1B
	global_load_d16_b16 v4, v[4:5], off                        // 000000842968: DC820000 047C0004
	s_waitcnt vmcnt(0)                                         // 000000842970: BF8903F7
	v_cvt_f32_f16_e32 v4, v4                                   // 000000842974: 7E081704
	s_or_b32 exec_lo, exec_lo, s3                              // 000000842978: 8C7E037E
	v_dual_mov_b32 v6, 0 :: v_dual_add_nc_u32 v7, 0x80, v25    // 00000084297C: CA200080 060632FF 00000080
	v_mov_b32_e32 v5, 0                                        // 000000842988: 7E0A0280
	s_mov_b32 s3, exec_lo                                      // 00000084298C: BE83007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000842990: BF870002
	.long 0xd4c1007e                                           // 000000842994: D4C1007E
	v_cndmask_b32_e32 v1, v7, v26, vcc_lo                      // 000000842998: 02023507
	s_cbranch_execz 11                                         // 00000084299C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x2cc>
	v_lshlrev_b32_e32 v5, 1, v7                                // 0000008429A0: 300A0E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008429A4: BF8700A1
	v_ashrrev_i32_e32 v8, 31, v5                               // 0000008429A8: 34100A9F
	.long 0xd7006a07                                           // 0000008429AC: D7006A07
	v_cndmask_b32_e32 v1, v17, v5, vcc_lo                      // 0000008429B0: 02020B11
	v_add_co_ci_u32_e64 v8, null, v27, v8, vcc_lo              // 0000008429B4: D5207C08 01AA111B
	global_load_d16_b16 v5, v[7:8], off                        // 0000008429BC: DC820000 057C0007
	s_waitcnt vmcnt(0)                                         // 0000008429C4: BF8903F7
	v_cvt_f32_f16_e32 v5, v5                                   // 0000008429C8: 7E0A1705
	s_or_b32 exec_lo, exec_lo, s3                              // 0000008429CC: 8C7E037E
	v_add_nc_u32_e32 v7, 0xa0, v25                             // 0000008429D0: 4A0E32FF 000000A0
	s_mov_b32 s3, exec_lo                                      // 0000008429D8: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008429DC: BF870001
	.long 0xd4c1007e                                           // 0000008429E0: D4C1007E
	v_cndmask_b32_e32 v1, v7, v26, vcc_lo                      // 0000008429E4: 02023507
	s_cbranch_execz 11                                         // 0000008429E8: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x318>
	v_lshlrev_b32_e32 v6, 1, v7                                // 0000008429EC: 300C0E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008429F0: BF8700A1
	v_ashrrev_i32_e32 v7, 31, v6                               // 0000008429F4: 340E0C9F
	.long 0xd7006a06                                           // 0000008429F8: D7006A06
	v_cndmask_b32_e32 v1, v17, v6, vcc_lo                      // 0000008429FC: 02020D11
	v_add_co_ci_u32_e64 v7, null, v27, v7, vcc_lo              // 000000842A00: D5207C07 01AA0F1B
	global_load_d16_b16 v6, v[6:7], off                        // 000000842A08: DC820000 067C0006
	s_waitcnt vmcnt(0)                                         // 000000842A10: BF8903F7
	v_cvt_f32_f16_e32 v6, v6                                   // 000000842A14: 7E0C1706
	s_or_b32 exec_lo, exec_lo, s3                              // 000000842A18: 8C7E037E
	v_dual_mov_b32 v8, 0 :: v_dual_add_nc_u32 v11, 0xc0, v25   // 000000842A1C: CA200080 080A32FF 000000C0
	v_mov_b32_e32 v7, 0                                        // 000000842A28: 7E0E0280
	s_mov_b32 s3, exec_lo                                      // 000000842A2C: BE83007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000842A30: BF870002
	.long 0xd4c1007e                                           // 000000842A34: D4C1007E
	v_cndmask_b32_e32 v1, v11, v26, vcc_lo                     // 000000842A38: 0202350B
	s_cbranch_execz 11                                         // 000000842A3C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x36c>
	v_lshlrev_b32_e32 v7, 1, v11                               // 000000842A40: 300E1681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000842A44: BF8700A1
	v_ashrrev_i32_e32 v12, 31, v7                              // 000000842A48: 34180E9F
	.long 0xd7006a0b                                           // 000000842A4C: D7006A0B
	v_cndmask_b32_e32 v1, v17, v7, vcc_lo                      // 000000842A50: 02020F11
	v_add_co_ci_u32_e64 v12, null, v27, v12, vcc_lo            // 000000842A54: D5207C0C 01AA191B
	global_load_d16_b16 v7, v[11:12], off                      // 000000842A5C: DC820000 077C000B
	s_waitcnt vmcnt(0)                                         // 000000842A64: BF8903F7
	v_cvt_f32_f16_e32 v7, v7                                   // 000000842A68: 7E0E1707
	s_or_b32 exec_lo, exec_lo, s3                              // 000000842A6C: 8C7E037E
	v_add_nc_u32_e32 v11, 0xe0, v25                            // 000000842A70: 4A1632FF 000000E0
	s_mov_b32 s3, exec_lo                                      // 000000842A78: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000842A7C: BF870001
	.long 0xd4c1007e                                           // 000000842A80: D4C1007E
	v_cndmask_b32_e32 v1, v11, v26, vcc_lo                     // 000000842A84: 0202350B
	s_cbranch_execz 11                                         // 000000842A88: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x3b8>
	v_lshlrev_b32_e32 v8, 1, v11                               // 000000842A8C: 30101681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000842A90: BF8700A1
	v_ashrrev_i32_e32 v12, 31, v8                              // 000000842A94: 3418109F
	.long 0xd7006a0b                                           // 000000842A98: D7006A0B
	v_cndmask_b32_e32 v1, v17, v8, vcc_lo                      // 000000842A9C: 02021111
	v_add_co_ci_u32_e64 v12, null, v27, v12, vcc_lo            // 000000842AA0: D5207C0C 01AA191B
	global_load_d16_b16 v8, v[11:12], off                      // 000000842AA8: DC820000 087C000B
	s_waitcnt vmcnt(0)                                         // 000000842AB0: BF8903F7
	v_cvt_f32_f16_e32 v8, v8                                   // 000000842AB4: 7E101708
	s_or_b32 exec_lo, exec_lo, s3                              // 000000842AB8: 8C7E037E
	s_branch 9                                                 // 000000842ABC: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x3e4>
	v_mov_b32_e32 v1, 0                                        // 000000842AC0: 7E020280
	s_delay_alu instid0(VALU_DEP_1)                            // 000000842AC4: BF870001
	v_mov_b32_e32 v2, v1                                       // 000000842AC8: 7E040301
	v_mov_b32_e32 v3, v1                                       // 000000842ACC: 7E060301
	v_mov_b32_e32 v4, v1                                       // 000000842AD0: 7E080301
	v_mov_b32_e32 v5, v1                                       // 000000842AD4: 7E0A0301
	v_mov_b32_e32 v6, v1                                       // 000000842AD8: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 000000842ADC: 7E0E0301
	v_mov_b32_e32 v8, v1                                       // 000000842AE0: 7E100301
	s_add_u32 s4, s4, s14                                      // 000000842AE4: 80040E04
	s_addc_u32 s5, s5, s15                                     // 000000842AE8: 82050F05
	s_lshr_b32 s3, s11, 31                                     // 000000842AEC: 85039F0B
	v_dual_mov_b32 v13, 0 :: v_dual_mov_b32 v28, 0             // 000000842AF0: CA100080 0D1C0080
	s_add_u32 s14, s10, s3                                     // 000000842AF8: 800E030A
	s_addc_u32 s15, s11, 0                                     // 000000842AFC: 820F800B
	.long 0xd4410003                                           // 000000842B00: D4410003
	v_cndmask_b32_e32 v1, v25, v26, vcc_lo                     // 000000842B04: 02023519
	s_ashr_i64 s[14:15], s[14:15], 1                           // 000000842B08: 868E810E
	v_cndmask_b32_e64 v29, 0, 1, s16                           // 000000842B0C: D501001D 00410280
	v_mad_u64_u32 v[18:19], null, v9, s14, s[4:5]              // 000000842B14: D6FE7C12 00101D09
	.long 0xd72c0009                                           // 000000842B1C: D72C0009
	v_cndmask_b32_e32 v0, v9, v15, vcc_lo                      // 000000842B20: 02001F09
	.long 0xd72c000a                                           // 000000842B24: D72C000A
	v_cndmask_b32_e32 v0, v10, v14, vcc_lo                     // 000000842B28: 02001D0A
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v15, 0             // 000000842B2C: CA100080 140E0080
	v_mov_b32_e32 v14, 0                                       // 000000842B34: 7E1C0280
	v_mov_b32_e32 v16, 0                                       // 000000842B38: 7E200280
	s_delay_alu instid0(VALU_DEP_4)                            // 000000842B3C: BF870004
	v_add3_u32 v30, v10, v19, v9                               // 000000842B40: D655001E 0426270A
	s_and_saveexec_b32 s4, s3                                  // 000000842B48: BE842003
	s_cbranch_execz 22                                         // 000000842B4C: BFA50016 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x4a8>
	v_dual_mov_b32 v20, 0 :: v_dual_lshlrev_b32 v9, 4, v25     // 000000842B50: CA220080 14083284
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000842B58: BF8700A1
	v_ashrrev_i32_e32 v10, 31, v9                              // 000000842B5C: 3414129F
	.long 0xd7006a09                                           // 000000842B60: D7006A09
	v_cndmask_b32_e32 v1, v18, v9, vcc_lo                      // 000000842B64: 02021312
	v_add_co_ci_u32_e64 v10, null, v30, v10, vcc_lo            // 000000842B68: D5207C0A 01AA151E
	s_and_not1_b32 vcc_lo, exec_lo, s16                        // 000000842B70: 916A107E
	global_load_b128 v[13:16], v[9:10], off                    // 000000842B74: DC5E0000 0D7C0009
	s_cbranch_vccnz 10                                         // 000000842B7C: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x4a8>
	v_lshlrev_b32_e32 v9, 1, v25                               // 000000842B80: 30123281
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000842B84: BF870091
	.long 0xd7006a09                                           // 000000842B88: D7006A09
	v_cndmask_b32_e32 v1, v17, v9, vcc_lo                      // 000000842B8C: 02021311
	v_add_co_ci_u32_e64 v10, null, 0, v27, vcc_lo              // 000000842B90: D5207C0A 01AA3680
	global_load_d16_b16 v9, v[9:10], off                       // 000000842B98: DC820000 097C0009
	s_waitcnt vmcnt(0)                                         // 000000842BA0: BF8903F7
	v_cvt_f32_f16_e32 v20, v9                                  // 000000842BA4: 7E281709
	s_or_b32 exec_lo, exec_lo, s4                              // 000000842BA8: 8C7E047E
	v_dual_mov_b32 v32, 0 :: v_dual_mov_b32 v33, 0             // 000000842BAC: CA100080 20200080
	v_mov_b32_e32 v31, 0                                       // 000000842BB4: 7E3E0280
	s_and_saveexec_b32 s14, s3                                 // 000000842BB8: BE8E2003
	s_cbranch_execz 430                                        // 000000842BBC: BFA501AE <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0xb78>
	v_dual_mov_b32 v32, 0 :: v_dual_add_nc_u32 v9, 32, v25     // 000000842BC0: CA200080 200832A0
	v_dual_mov_b32 v28, 0 :: v_dual_lshlrev_b32 v19, 5, v25    // 000000842BC8: CA220080 1C123285
	s_delay_alu instid0(VALU_DEP_2)                            // 000000842BD0: BF870002
	v_dual_mov_b32 v33, 0 :: v_dual_lshlrev_b32 v34, 4, v9     // 000000842BD4: CA220080 21221284
	v_mov_b32_e32 v31, 0                                       // 000000842BDC: 7E3E0280
	v_dual_mov_b32 v36, v20 :: v_dual_lshlrev_b32 v35, 1, v9   // 000000842BE0: CA220114 24221281
	s_mul_i32 s3, s11, 6                                       // 000000842BE8: 9603860B
	s_mul_hi_u32 s15, s10, 6                                   // 000000842BEC: 968F860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 000000842BF0: 8484820A
	s_add_i32 s15, s15, s3                                     // 000000842BF4: 810F030F
	s_mul_i32 s17, s10, 6                                      // 000000842BF8: 9611860A
	s_mov_b32 s16, 0                                           // 000000842BFC: BE900080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 000000842C00: 848A810A
	s_branch 376                                               // 000000842C04: BFA00178 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0xae8>
	s_or_b32 exec_lo, exec_lo, s18                             // 000000842C08: 8C7E127E
	v_cndmask_b32_e64 v51, v20, v1, s2                         // 000000842C0C: D5010033 000A0314
	v_cndmask_b32_e64 v37, v1, v2, s2                          // 000000842C14: D5010025 000A0501
	v_dual_mov_b32 v44, v8 :: v_dual_and_b32 v1, 0xff, v13     // 000000842C1C: CA240108 2C001AFF 000000FF
	v_cndmask_b32_e64 v43, v7, v8, s2                          // 000000842C28: D501002B 000A1107
	v_cndmask_b32_e64 v42, v6, v7, s2                          // 000000842C30: D501002A 000A0F06
	v_cndmask_b32_e64 v41, v5, v6, s2                          // 000000842C38: D5010029 000A0D05
	v_cndmask_b32_e64 v40, v4, v5, s2                          // 000000842C40: D5010028 000A0B04
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000842C48: 30020282
	v_cndmask_b32_e64 v39, v3, v4, s2                          // 000000842C4C: D5010027 000A0903
	v_cndmask_b32_e64 v38, v2, v3, s2                          // 000000842C54: D5010026 000A0702
	v_ashrrev_i32_e32 v20, 31, v19                             // 000000842C5C: 3428269F
	s_and_b32 s3, exec_lo, s3                                  // 000000842C60: 8B03037E
	ds_load_b32 v52, v1                                        // 000000842C64: D8D80000 34000001
	v_lshrrev_b32_e32 v1, 6, v13                               // 000000842C6C: 32021A86
	s_or_b32 s16, s3, s16                                      // 000000842C70: 8C101003
	v_add_nc_u32_e32 v34, 0x200, v34                           // 000000842C74: 4A4444FF 00000200
	v_add_nc_u32_e32 v35, 64, v35                              // 000000842C7C: 4A4646C0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000842C80: BF8700B3
	v_and_b32_e32 v1, 0x3fc, v1                                // 000000842C84: 360202FF 000003FC
	ds_load_b32 v53, v1                                        // 000000842C8C: D8D80000 35000001
	v_lshrrev_b32_e32 v1, 14, v13                              // 000000842C94: 32021A8E
	v_and_b32_e32 v1, 0x3fc, v1                                // 000000842C98: 360202FF 000003FC
	ds_load_b32 v54, v1                                        // 000000842CA0: D8D80000 36000001
	v_lshrrev_b32_e32 v1, 22, v13                              // 000000842CA8: 32021A96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000842CAC: BF8700B1
	v_and_b32_e32 v1, 0x3fc, v1                                // 000000842CB0: 360202FF 000003FC
	ds_load_b32 v55, v1                                        // 000000842CB8: D8D80000 37000001
	v_and_b32_e32 v1, 0xff, v14                                // 000000842CC0: 36021CFF 000000FF
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000842CC8: 30020282
	ds_load_b32 v56, v1                                        // 000000842CCC: D8D80000 38000001
	v_lshrrev_b32_e32 v1, 6, v14                               // 000000842CD4: 32021C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000842CD8: BF8700B1
	v_and_b32_e32 v1, 0x3fc, v1                                // 000000842CDC: 360202FF 000003FC
	ds_load_b32 v57, v1                                        // 000000842CE4: D8D80000 39000001
	v_lshrrev_b32_e32 v1, 14, v14                              // 000000842CEC: 32021C8E
	v_and_b32_e32 v1, 0x3fc, v1                                // 000000842CF0: 360202FF 000003FC
	ds_load_b32 v58, v1                                        // 000000842CF8: D8D80000 3A000001
	v_lshrrev_b32_e32 v1, 22, v14                              // 000000842D00: 32021C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000842D04: BF8700B1
	v_and_b32_e32 v1, 0x3fc, v1                                // 000000842D08: 360202FF 000003FC
	ds_load_b32 v59, v1                                        // 000000842D10: D8D80000 3B000001
	v_and_b32_e32 v1, 0xff, v15                                // 000000842D18: 36021EFF 000000FF
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000842D20: 30020282
	ds_load_b32 v60, v1                                        // 000000842D24: D8D80000 3C000001
	v_lshrrev_b32_e32 v1, 6, v15                               // 000000842D2C: 32021E86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000842D30: BF8700B1
	v_and_b32_e32 v1, 0x3fc, v1                                // 000000842D34: 360202FF 000003FC
	ds_load_b32 v61, v1                                        // 000000842D3C: D8D80000 3D000001
	v_lshrrev_b32_e32 v1, 14, v15                              // 000000842D44: 32021E8E
	v_and_b32_e32 v1, 0x3fc, v1                                // 000000842D48: 360202FF 000003FC
	ds_load_b32 v62, v1                                        // 000000842D50: D8D80000 3E000001
	v_lshrrev_b32_e32 v1, 22, v15                              // 000000842D58: 32021E96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000842D5C: BF8700B1
	v_and_b32_e32 v1, 0x3fc, v1                                // 000000842D60: 360202FF 000003FC
	ds_load_b32 v63, v1                                        // 000000842D68: D8D80000 3F000001
	v_and_b32_e32 v1, 0xff, v16                                // 000000842D70: 360220FF 000000FF
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000842D78: 30020282
	ds_load_b32 v64, v1                                        // 000000842D7C: D8D80000 40000001
	v_lshrrev_b32_e32 v1, 6, v16                               // 000000842D84: 32022086
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000842D88: BF8700B1
	v_and_b32_e32 v1, 0x3fc, v1                                // 000000842D8C: 360202FF 000003FC
	ds_load_b32 v65, v1                                        // 000000842D94: D8D80000 41000001
	v_lshrrev_b32_e32 v1, 14, v16                              // 000000842D9C: 3202208E
	v_and_b32_e32 v1, 0x3fc, v1                                // 000000842DA0: 360202FF 000003FC
	ds_load_b32 v66, v1                                        // 000000842DA8: D8D80000 42000001
	v_lshrrev_b32_e32 v1, 22, v16                              // 000000842DB0: 32022096
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000842DB4: BF870141
	v_and_b32_e32 v1, 0x3fc, v1                                // 000000842DB8: 360202FF 000003FC
	ds_load_b32 v67, v1                                        // 000000842DC0: D8D80000 43000001
	.long 0xd73c0001                                           // 000000842DC8: D73C0001
	v_cndmask_b32_e32 v1, 1, v19, vcc_lo                       // 000000842DCC: 02022681
	v_dual_mov_b32 v20, v36 :: v_dual_add_nc_u32 v19, 0x400, v19// 000000842DD0: CA200124 141226FF 00000400
	.long 0xd7006a31                                           // 000000842DDC: D7006A31
	v_cndmask_b32_e32 v1, s6, v1, vcc_lo                       // 000000842DE0: 02020206
	s_delay_alu instid0(VALU_DEP_1)                            // 000000842DE4: BF870001
	v_add_co_ci_u32_e64 v50, null, s7, v2, vcc_lo              // 000000842DE8: D5207C32 01AA0407
	s_clause 0x3                                               // 000000842DF0: BF850003
	global_load_b128 v[1:4], v[49:50], off                     // 000000842DF4: DC5E0000 017C0031
	global_load_b128 v[5:8], v[49:50], off offset:16           // 000000842DFC: DC5E0010 057C0031
	global_load_b128 v[13:16], v[49:50], off offset:32         // 000000842E04: DC5E0020 0D7C0031
	global_load_b128 v[45:48], v[49:50], off offset:48         // 000000842E0C: DC5E0030 2D7C0031
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 000000842E14: BF890CF7
	v_dot2_f32_bf16 v1, v1, v52, 0                             // 000000842E18: CC1A4001 1A026901
	s_waitcnt lgkmcnt(14)                                      // 000000842E20: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000842E24: BF8700A1
	v_dot2_f32_bf16 v1, v2, v53, v1                            // 000000842E28: CC1A4001 1C066B02
	s_waitcnt lgkmcnt(13)                                      // 000000842E30: BF89FCD7
	v_dot2_f32_bf16 v1, v3, v54, v1                            // 000000842E34: CC1A4001 1C066D03
	s_waitcnt lgkmcnt(12)                                      // 000000842E3C: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000842E40: BF8700A1
	v_dot2_f32_bf16 v1, v4, v55, v1                            // 000000842E44: CC1A4001 1C066F04
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 000000842E4C: BF8908B7
	v_dot2_f32_bf16 v1, v5, v56, v1                            // 000000842E50: CC1A4001 1C067105
	s_waitcnt lgkmcnt(10)                                      // 000000842E58: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000842E5C: BF8700A1
	v_dot2_f32_bf16 v1, v6, v57, v1                            // 000000842E60: CC1A4001 1C067306
	s_waitcnt lgkmcnt(9)                                       // 000000842E68: BF89FC97
	v_dot2_f32_bf16 v1, v7, v58, v1                            // 000000842E6C: CC1A4001 1C067507
	s_waitcnt lgkmcnt(8)                                       // 000000842E74: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000842E78: BF8700A1
	v_dot2_f32_bf16 v1, v8, v59, v1                            // 000000842E7C: CC1A4001 1C067708
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 000000842E84: BF890477
	v_dot2_f32_bf16 v1, v13, v60, v1                           // 000000842E88: CC1A4001 1C06790D
	s_waitcnt lgkmcnt(6)                                       // 000000842E90: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000842E94: BF8700A1
	v_dot2_f32_bf16 v1, v14, v61, v1                           // 000000842E98: CC1A4001 1C067B0E
	s_waitcnt lgkmcnt(5)                                       // 000000842EA0: BF89FC57
	v_dot2_f32_bf16 v1, v15, v62, v1                           // 000000842EA4: CC1A4001 1C067D0F
	s_waitcnt lgkmcnt(4)                                       // 000000842EAC: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000842EB0: BF8700A1
	v_dot2_f32_bf16 v1, v16, v63, v1                           // 000000842EB4: CC1A4001 1C067F10
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 000000842EBC: BF890037
	v_dot2_f32_bf16 v1, v45, v64, v1                           // 000000842EC0: CC1A4001 1C06812D
	.long 0xd7006a2d                                           // 000000842EC8: D7006A2D
	v_cndmask_b32_e32 v0, v49, v10, vcc_lo                     // 000000842ECC: 02001531
	s_waitcnt lgkmcnt(2)                                       // 000000842ED0: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000842ED4: BF870132
	v_dot2_f32_bf16 v1, v46, v65, v1                           // 000000842ED8: CC1A4001 1C06832E
	v_add_co_ci_u32_e64 v46, null, s11, v50, vcc_lo            // 000000842EE0: D5207C2E 01AA640B
	s_waitcnt lgkmcnt(1)                                       // 000000842EE8: BF89FC17
	v_dot2_f32_bf16 v1, v47, v66, v1                           // 000000842EEC: CC1A4001 1C06852F
	s_waitcnt lgkmcnt(0)                                       // 000000842EF4: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000842EF8: BF870091
	v_dot2_f32_bf16 v1, v48, v67, v1                           // 000000842EFC: CC1A4001 1C068730
	v_fmac_f32_e32 v31, v51, v1                                // 000000842F04: 563E0333
	s_clause 0x3                                               // 000000842F08: BF850003
	global_load_b128 v[1:4], v[45:46], off                     // 000000842F0C: DC5E0000 017C002D
	global_load_b128 v[5:8], v[45:46], off offset:16           // 000000842F14: DC5E0010 057C002D
	global_load_b128 v[13:16], v[45:46], off offset:32         // 000000842F1C: DC5E0020 0D7C002D
	global_load_b128 v[45:48], v[45:46], off offset:48         // 000000842F24: DC5E0030 2D7C002D
	s_waitcnt vmcnt(3)                                         // 000000842F2C: BF890FF7
	v_dot2_f32_bf16 v1, v1, v52, 0                             // 000000842F30: CC1A4001 1A026901
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000842F38: BF870091
	v_dot2_f32_bf16 v1, v2, v53, v1                            // 000000842F3C: CC1A4001 1C066B02
	v_dot2_f32_bf16 v1, v3, v54, v1                            // 000000842F44: CC1A4001 1C066D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000842F4C: BF8700A1
	v_dot2_f32_bf16 v1, v4, v55, v1                            // 000000842F50: CC1A4001 1C066F04
	s_waitcnt vmcnt(2)                                         // 000000842F58: BF890BF7
	v_dot2_f32_bf16 v1, v5, v56, v1                            // 000000842F5C: CC1A4001 1C067105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000842F64: BF870091
	v_dot2_f32_bf16 v1, v6, v57, v1                            // 000000842F68: CC1A4001 1C067306
	v_dot2_f32_bf16 v1, v7, v58, v1                            // 000000842F70: CC1A4001 1C067507
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000842F78: BF8700A1
	v_dot2_f32_bf16 v1, v8, v59, v1                            // 000000842F7C: CC1A4001 1C067708
	s_waitcnt vmcnt(1)                                         // 000000842F84: BF8907F7
	v_dot2_f32_bf16 v1, v13, v60, v1                           // 000000842F88: CC1A4001 1C06790D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000842F90: BF870091
	v_dot2_f32_bf16 v1, v14, v61, v1                           // 000000842F94: CC1A4001 1C067B0E
	v_dot2_f32_bf16 v1, v15, v62, v1                           // 000000842F9C: CC1A4001 1C067D0F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000842FA4: BF8700A1
	v_dot2_f32_bf16 v1, v16, v63, v1                           // 000000842FA8: CC1A4001 1C067F10
	s_waitcnt vmcnt(0)                                         // 000000842FB0: BF8903F7
	v_dot2_f32_bf16 v1, v45, v64, v1                           // 000000842FB4: CC1A4001 1C06812D
	.long 0xd7006a2d                                           // 000000842FBC: D7006A2D
	v_cndmask_b32_e32 v0, v49, v4, vcc_lo                      // 000000842FC0: 02000931
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000842FC4: BF870122
	v_dot2_f32_bf16 v1, v46, v65, v1                           // 000000842FC8: CC1A4001 1C06832E
	v_add_co_ci_u32_e64 v46, null, s5, v50, vcc_lo             // 000000842FD0: D5207C2E 01AA6405
	v_dot2_f32_bf16 v1, v47, v66, v1                           // 000000842FD8: CC1A4001 1C06852F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000842FE0: BF870091
	v_dot2_f32_bf16 v1, v48, v67, v1                           // 000000842FE4: CC1A4001 1C068730
	v_fmac_f32_e32 v33, v51, v1                                // 000000842FEC: 56420333
	s_clause 0x3                                               // 000000842FF0: BF850003
	global_load_b128 v[1:4], v[45:46], off                     // 000000842FF4: DC5E0000 017C002D
	global_load_b128 v[5:8], v[45:46], off offset:16           // 000000842FFC: DC5E0010 057C002D
	global_load_b128 v[13:16], v[45:46], off offset:32         // 000000843004: DC5E0020 0D7C002D
	global_load_b128 v[45:48], v[45:46], off offset:48         // 00000084300C: DC5E0030 2D7C002D
	s_waitcnt vmcnt(3)                                         // 000000843014: BF890FF7
	v_dot2_f32_bf16 v1, v1, v52, 0                             // 000000843018: CC1A4001 1A026901
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000843020: BF870091
	v_dot2_f32_bf16 v1, v2, v53, v1                            // 000000843024: CC1A4001 1C066B02
	v_dot2_f32_bf16 v1, v3, v54, v1                            // 00000084302C: CC1A4001 1C066D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000843034: BF8700A1
	v_dot2_f32_bf16 v1, v4, v55, v1                            // 000000843038: CC1A4001 1C066F04
	s_waitcnt vmcnt(2)                                         // 000000843040: BF890BF7
	v_dot2_f32_bf16 v1, v5, v56, v1                            // 000000843044: CC1A4001 1C067105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084304C: BF870091
	v_dot2_f32_bf16 v1, v6, v57, v1                            // 000000843050: CC1A4001 1C067306
	v_dot2_f32_bf16 v1, v7, v58, v1                            // 000000843058: CC1A4001 1C067507
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000843060: BF8700A1
	v_dot2_f32_bf16 v1, v8, v59, v1                            // 000000843064: CC1A4001 1C067708
	s_waitcnt vmcnt(1)                                         // 00000084306C: BF8907F7
	v_dot2_f32_bf16 v1, v13, v60, v1                           // 000000843070: CC1A4001 1C06790D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000843078: BF870091
	v_dot2_f32_bf16 v1, v14, v61, v1                           // 00000084307C: CC1A4001 1C067B0E
	v_dot2_f32_bf16 v1, v15, v62, v1                           // 000000843084: CC1A4001 1C067D0F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084308C: BF8700A1
	v_dot2_f32_bf16 v1, v16, v63, v1                           // 000000843090: CC1A4001 1C067F10
	s_waitcnt vmcnt(0)                                         // 000000843098: BF8903F7
	v_dot2_f32_bf16 v1, v45, v64, v1                           // 00000084309C: CC1A4001 1C06812D
	.long 0xd7006a2d                                           // 0000008430A4: D7006A2D
	v_cndmask_b32_e32 v0, v49, v17, vcc_lo                     // 0000008430A8: 02002331
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008430AC: BF870122
	v_dot2_f32_bf16 v1, v46, v65, v1                           // 0000008430B0: CC1A4001 1C06832E
	v_add_co_ci_u32_e64 v46, null, s15, v50, vcc_lo            // 0000008430B8: D5207C2E 01AA640F
	v_dot2_f32_bf16 v1, v47, v66, v1                           // 0000008430C0: CC1A4001 1C06852F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008430C8: BF870091
	v_dot2_f32_bf16 v1, v48, v67, v1                           // 0000008430CC: CC1A4001 1C068730
	v_fmac_f32_e32 v32, v51, v1                                // 0000008430D4: 56400333
	s_clause 0x3                                               // 0000008430D8: BF850003
	global_load_b128 v[1:4], v[45:46], off                     // 0000008430DC: DC5E0000 017C002D
	global_load_b128 v[5:8], v[45:46], off offset:16           // 0000008430E4: DC5E0010 057C002D
	global_load_b128 v[13:16], v[45:46], off offset:32         // 0000008430EC: DC5E0020 0D7C002D
	global_load_b128 v[45:48], v[45:46], off offset:48         // 0000008430F4: DC5E0030 2D7C002D
	s_waitcnt vmcnt(3)                                         // 0000008430FC: BF890FF7
	v_dot2_f32_bf16 v1, v1, v52, 0                             // 000000843100: CC1A4001 1A026901
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000843108: BF870091
	v_dot2_f32_bf16 v1, v2, v53, v1                            // 00000084310C: CC1A4001 1C066B02
	v_dot2_f32_bf16 v1, v3, v54, v1                            // 000000843114: CC1A4001 1C066D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084311C: BF8700A1
	v_dot2_f32_bf16 v1, v4, v55, v1                            // 000000843120: CC1A4001 1C066F04
	s_waitcnt vmcnt(2)                                         // 000000843128: BF890BF7
	v_dot2_f32_bf16 v1, v5, v56, v1                            // 00000084312C: CC1A4001 1C067105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000843134: BF870091
	v_dot2_f32_bf16 v1, v6, v57, v1                            // 000000843138: CC1A4001 1C067306
	v_dot2_f32_bf16 v1, v7, v58, v1                            // 000000843140: CC1A4001 1C067507
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000843148: BF8700A1
	v_dot2_f32_bf16 v1, v8, v59, v1                            // 00000084314C: CC1A4001 1C067708
	s_waitcnt vmcnt(1)                                         // 000000843154: BF8907F7
	v_dot2_f32_bf16 v1, v13, v60, v1                           // 000000843158: CC1A4001 1C06790D
	v_mov_b32_e32 v13, v9                                      // 000000843160: 7E1A0309
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000843164: BF870122
	v_dot2_f32_bf16 v1, v14, v61, v1                           // 000000843168: CC1A4001 1C067B0E
	v_mov_b32_e32 v14, v10                                     // 000000843170: 7E1C030A
	v_dot2_f32_bf16 v1, v15, v62, v1                           // 000000843174: CC1A4001 1C067D0F
	v_mov_b32_e32 v15, v11                                     // 00000084317C: 7E1E030B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000843180: BF870132
	v_dot2_f32_bf16 v1, v16, v63, v1                           // 000000843184: CC1A4001 1C067F10
	v_mov_b32_e32 v16, v12                                     // 00000084318C: 7E20030C
	s_waitcnt vmcnt(0)                                         // 000000843190: BF8903F7
	v_dot2_f32_bf16 v1, v45, v64, v1                           // 000000843194: CC1A4001 1C06812D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084319C: BF870091
	v_dot2_f32_bf16 v1, v46, v65, v1                           // 0000008431A0: CC1A4001 1C06832E
	v_dot2_f32_bf16 v1, v47, v66, v1                           // 0000008431A8: CC1A4001 1C06852F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008431B0: BF870091
	v_dot2_f32_bf16 v1, v48, v67, v1                           // 0000008431B4: CC1A4001 1C068730
	v_dual_fmac_f32 v28, v51, v1 :: v_dual_mov_b32 v1, v37     // 0000008431BC: C8100333 1C000125
	v_dual_mov_b32 v2, v38 :: v_dual_mov_b32 v3, v39           // 0000008431C4: CA100126 02020127
	v_dual_mov_b32 v4, v40 :: v_dual_mov_b32 v5, v41           // 0000008431CC: CA100128 04040129
	v_dual_mov_b32 v6, v42 :: v_dual_mov_b32 v7, v43           // 0000008431D4: CA10012A 0606012B
	v_mov_b32_e32 v8, v44                                      // 0000008431DC: 7E10032C
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 0000008431E0: 917E107E
	s_cbranch_execz 35                                         // 0000008431E4: BFA50023 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0xb74>
	s_waitcnt vmcnt(0)                                         // 0000008431E8: BF8903F7
	v_dual_mov_b32 v10, v14 :: v_dual_add_nc_u32 v25, 32, v25  // 0000008431EC: CA20010E 0A1832A0
	v_dual_mov_b32 v9, v13 :: v_dual_mov_b32 v12, v16          // 0000008431F4: CA10010D 090C0110
	v_mov_b32_e32 v11, v15                                     // 0000008431FC: 7E16030F
	s_delay_alu instid0(VALU_DEP_3)                            // 000000843200: BF870003
	.long 0xd4460003                                           // 000000843204: D4460003
	v_cndmask_b32_e32 v1, v25, v26, vcc_lo                     // 000000843208: 02023519
	s_mov_b32 s18, exec_lo                                     // 00000084320C: BE92007E
	.long 0xd4c1007e                                           // 000000843210: D4C1007E
	v_cndmask_b32_e32 v1, v25, v26, vcc_lo                     // 000000843214: 02023519
	s_cbranch_execz 65147                                      // 000000843218: BFA5FE7B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x508>
	v_ashrrev_i32_e32 v10, 31, v34                             // 00000084321C: 3414449F
	.long 0xd7006a09                                           // 000000843220: D7006A09
	v_cndmask_b32_e32 v1, v18, v34, vcc_lo                     // 000000843224: 02024512
	v_mov_b32_e32 v36, v20                                     // 000000843228: 7E480314
	s_delay_alu instid0(VALU_DEP_3)                            // 00000084322C: BF870003
	v_add_co_ci_u32_e64 v10, null, v30, v10, vcc_lo            // 000000843230: D5207C0A 01AA151E
	v_cmp_ne_u32_e32 vcc_lo, 1, v29                            // 000000843238: 7C9A3A81
	global_load_b128 v[9:12], v[9:10], off                     // 00000084323C: DC5E0000 097C0009
	s_cbranch_vccnz 65136                                      // 000000843244: BFA4FE70 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x508>
	v_ashrrev_i32_e32 v37, 31, v35                             // 000000843248: 344A469F
	.long 0xd7006a24                                           // 00000084324C: D7006A24
	v_cndmask_b32_e32 v1, v17, v35, vcc_lo                     // 000000843250: 02024711
	s_delay_alu instid0(VALU_DEP_1)                            // 000000843254: BF870001
	v_add_co_ci_u32_e64 v37, null, v27, v37, vcc_lo            // 000000843258: D5207C25 01AA4B1B
	global_load_d16_b16 v36, v[36:37], off                     // 000000843260: DC820000 247C0024
	s_waitcnt vmcnt(0)                                         // 000000843268: BF8903F7
	v_cvt_f32_f16_e32 v36, v36                                 // 00000084326C: 7E481724
	s_branch 65125                                             // 000000843270: BFA0FE65 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x508>
	s_or_b32 exec_lo, exec_lo, s16                             // 000000843274: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000843278: BF8700B9
	s_or_b32 exec_lo, exec_lo, s14                             // 00000084327C: 8C7E0E7E
	.long 0xd71f0001                                           // 000000843280: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000843284: 020100C1
	s_mov_b32 s2, exec_lo                                      // 000000843288: BE82007E
	v_xor_b32_e32 v2, 16, v1                                   // 00000084328C: 3A040290
	v_xor_b32_e32 v6, 8, v1                                    // 000000843290: 3A0C0288
	v_xor_b32_e32 v10, 4, v1                                   // 000000843294: 3A140284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000843298: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 00000084329C: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 0000008432A0: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 0000008432A4: 7C980CA0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008432A8: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000008432AC: 30040482
	ds_bpermute_b32 v5, v2, v32                                // 0000008432B0: DACC0000 05002002
	s_waitcnt lgkmcnt(0)                                       // 0000008432B8: BF89FC07
	v_add_f32_e32 v5, v32, v5                                  // 0000008432BC: 060A0B20
	ds_bpermute_b32 v3, v2, v31                                // 0000008432C0: DACC0000 03001F02
	ds_bpermute_b32 v4, v2, v33                                // 0000008432C8: DACC0000 04002102
	ds_bpermute_b32 v2, v2, v28                                // 0000008432D0: DACC0000 02001C02
	s_waitcnt lgkmcnt(2)                                       // 0000008432D8: BF89FC27
	v_dual_add_f32 v3, v31, v3 :: v_dual_cndmask_b32 v6, v1, v6// 0000008432DC: C912071F 03060D01
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 0000008432E4: 7C9814A0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008432E8: BF870002
	v_lshlrev_b32_e32 v6, 2, v6                                // 0000008432EC: 300C0C82
	v_cndmask_b32_e32 v10, v1, v10, vcc_lo                     // 0000008432F0: 02141501
	ds_bpermute_b32 v9, v6, v5                                 // 0000008432F4: DACC0000 09000506
	s_waitcnt lgkmcnt(0)                                       // 0000008432FC: BF89FC07
	v_dual_add_f32 v5, v5, v9 :: v_dual_lshlrev_b32 v10, 2, v10// 000000843300: C9221305 050A1482
	ds_bpermute_b32 v7, v6, v3                                 // 000000843308: DACC0000 07000306
	s_waitcnt lgkmcnt(0)                                       // 000000843310: BF89FC07
	v_dual_add_f32 v2, v28, v2 :: v_dual_add_f32 v3, v3, v7    // 000000843314: C908051C 02020F03
	v_add_f32_e32 v4, v33, v4                                  // 00000084331C: 06080921
	ds_bpermute_b32 v8, v6, v4                                 // 000000843320: DACC0000 08000406
	ds_bpermute_b32 v6, v6, v2                                 // 000000843328: DACC0000 06000206
	s_waitcnt lgkmcnt(0)                                       // 000000843330: BF89FC07
	v_add_f32_e32 v2, v2, v6                                   // 000000843334: 06040D02
	ds_bpermute_b32 v6, v10, v3                                // 000000843338: DACC0000 0600030A
	ds_bpermute_b32 v9, v10, v2                                // 000000843340: DACC0000 0900020A
	s_waitcnt lgkmcnt(1)                                       // 000000843348: BF89FC17
	v_dual_add_f32 v3, v3, v6 :: v_dual_add_f32 v4, v4, v8     // 00000084334C: C9080D03 03041104
	ds_bpermute_b32 v8, v10, v5                                // 000000843354: DACC0000 0800050A
	s_waitcnt lgkmcnt(1)                                       // 00000084335C: BF89FC17
	v_add_f32_e32 v6, v2, v9                                   // 000000843360: 060C1302
	ds_bpermute_b32 v7, v10, v4                                // 000000843364: DACC0000 0700040A
	v_xor_b32_e32 v10, 2, v1                                   // 00000084336C: 3A140282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000843370: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 000000843374: 7C9814A0
	v_cndmask_b32_e32 v10, v1, v10, vcc_lo                     // 000000843378: 02141501
	s_waitcnt lgkmcnt(1)                                       // 00000084337C: BF89FC17
	v_dual_add_f32 v5, v5, v8 :: v_dual_lshlrev_b32 v10, 2, v10// 000000843380: C9221105 050A1482
	ds_bpermute_b32 v2, v10, v3                                // 000000843388: DACC0000 0200030A
	s_waitcnt lgkmcnt(1)                                       // 000000843390: BF89FC17
	v_add_f32_e32 v4, v4, v7                                   // 000000843394: 06080F04
	ds_bpermute_b32 v8, v10, v5                                // 000000843398: DACC0000 0800050A
	ds_bpermute_b32 v9, v10, v6                                // 0000008433A0: DACC0000 0900060A
	ds_bpermute_b32 v7, v10, v4                                // 0000008433A8: DACC0000 0700040A
	v_xor_b32_e32 v10, 1, v1                                   // 0000008433B0: 3A140281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008433B4: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 0000008433B8: 7C9814A0
	v_cndmask_b32_e32 v1, v1, v10, vcc_lo                      // 0000008433BC: 02021501
	s_waitcnt lgkmcnt(3)                                       // 0000008433C0: BF89FC37
	v_dual_add_f32 v1, v3, v2 :: v_dual_lshlrev_b32 v10, 2, v1 // 0000008433C4: C9220503 010A0282
	s_waitcnt lgkmcnt(2)                                       // 0000008433CC: BF89FC27
	v_add_f32_e32 v3, v5, v8                                   // 0000008433D0: 06061105
	s_waitcnt lgkmcnt(0)                                       // 0000008433D4: BF89FC07
	v_dual_add_f32 v5, v6, v9 :: v_dual_add_f32 v2, v4, v7     // 0000008433D8: C9081306 05020F04
	ds_bpermute_b32 v4, v10, v1                                // 0000008433E0: DACC0000 0400010A
	ds_bpermute_b32 v7, v10, v3                                // 0000008433E8: DACC0000 0700030A
	ds_bpermute_b32 v8, v10, v5                                // 0000008433F0: DACC0000 0800050A
	ds_bpermute_b32 v6, v10, v2                                // 0000008433F8: DACC0000 0600020A
	v_cmpx_eq_u32_e32 0, v24                                   // 000000843400: 7D943080
	s_cbranch_execz 12                                         // 000000843404: BFA5000C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0xd38>
	s_waitcnt lgkmcnt(1)                                       // 000000843408: BF89FC17
	v_dual_add_f32 v8, v5, v8 :: v_dual_lshlrev_b32 v9, 4, v23 // 00000084340C: C9221105 08082E84
	s_waitcnt lgkmcnt(0)                                       // 000000843414: BF89FC07
	v_dual_add_f32 v7, v3, v7 :: v_dual_add_f32 v6, v2, v6     // 000000843418: C9080F03 07060D02
	v_add_f32_e32 v5, v1, v4                                   // 000000843420: 060A0901
	s_delay_alu instid0(VALU_DEP_3)                            // 000000843424: BF870003
	v_lshl_or_b32 v1, v22, 5, v9                               // 000000843428: D6560001 04250B16
	ds_store_b128 v1, v[5:8] offset:1024                       // 000000843430: DB7C0400 00000501
	s_or_b32 exec_lo, exec_lo, s2                              // 000000843438: 8C7E027E
	v_or_b32_e32 v1, s20, v21                                  // 00000084343C: 38022A14
	v_mov_b32_e32 v2, s21                                      // 000000843440: 7E040215
	.long 0xd44c0002                                           // 000000843444: D44C0002
	v_cndmask_b32_e32 v1, 16, v0, vcc_lo                       // 000000843448: 02020090
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000084344C: BF890007
	s_barrier                                                  // 000000843450: BFBD0000
	buffer_gl0_inv                                             // 000000843454: E0AC0000 00000000
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 00000084345C: 7CA8020C
	s_and_b32 s2, s2, vcc_lo                                   // 000000843460: 8B026A02
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000843464: BF870009
	s_and_saveexec_b32 s3, s2                                  // 000000843468: BE832002
	s_cbranch_execz 76                                         // 00000084346C: BFA5004C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0xea0>
	v_and_b32_e32 v0, 3, v0                                    // 000000843470: 36000083
	s_load_b32 s0, s[0:1], 0x48                                // 000000843474: F4000000 F8000048
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084347C: BF870091
	v_lshlrev_b32_e32 v3, 2, v0                                // 000000843480: 30060082
	v_lshl_or_b32 v3, v21, 5, v3                               // 000000843484: D6560003 040D0B15
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000084348C: BF8700C1
	v_add_nc_u32_e32 v3, 0x400, v3                             // 000000843490: 4A0606FF 00000400
	ds_load_2addr_b32 v[3:4], v3 offset1:4                     // 000000843498: D8DC0400 03000003
	s_waitcnt lgkmcnt(0)                                       // 0000008434A0: BF89FC07
	v_add_f32_e32 v3, 0, v3                                    // 0000008434A4: 06060680
	v_add_f32_e32 v3, v3, v4                                   // 0000008434A8: 06060903
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008434AC: BF870091
	v_bfe_u32 v4, v3, 16, 1                                    // 0000008434B0: D6100004 02052103
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000008434B8: D6550003 03FE0903 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008434C4: BF870091
	v_and_b32_e32 v3, 0xffff0000, v3                           // 0000008434C8: 360606FF FFFF0000
	v_mul_f32_e32 v3, s0, v3                                   // 0000008434D0: 10060600
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008434D4: BF870091
	v_mul_f32_e32 v3, 0xbfb8aa3b, v3                           // 0000008434D8: 100606FF BFB8AA3B
	v_exp_f32_e32 v3, v3                                       // 0000008434E0: 7E064B03
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008434E4: BF870095
	v_add_f32_e32 v6, 1.0, v3                                  // 0000008434E8: 060C06F2
	v_div_scale_f32 v7, null, v6, v6, 1.0                      // 0000008434EC: D6FC7C07 03CA0D06
	v_div_scale_f32 v9, vcc_lo, 1.0, v6, 1.0                   // 0000008434F4: D6FC6A09 03CA0CF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000008434FC: BF870292
	v_rcp_f32_e32 v8, v7                                       // 000000843500: 7E105507
	v_fma_f32 v3, -v7, v8, 1.0                                 // 000000843504: D6130003 23CA1107
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000084350C: BF870121
	v_fmac_f32_e32 v8, v3, v8                                  // 000000843510: 56101103
	v_mad_u64_u32 v[3:4], null, s12, v0, 0                     // 000000843514: D6FE7C03 0202000C
	v_mul_f32_e32 v10, v9, v8                                  // 00000084351C: 10141109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000843520: BF870091
	v_fma_f32 v5, -v7, v10, v9                                 // 000000843524: D6130005 24261507
	v_fmac_f32_e32 v10, v5, v8                                 // 00000084352C: 56141105
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000843530: BF870114
	v_mad_u64_u32 v[4:5], null, s13, v0, v[4:5]                // 000000843534: D6FE7C04 0412000D
	v_fma_f32 v0, -v7, v10, v9                                 // 00000084353C: D6130000 24261507
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000843544: BF870112
	.long 0xd73c0003                                           // 000000843548: D73C0003
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 00000084354C: 02020682
	v_div_fmas_f32 v5, v0, v8, v10                             // 000000843550: D6370005 042A1100
	.long 0xd73c0000                                           // 000000843558: D73C0000
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000084355C: 02020282
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000843560: BF870193
	.long 0xd7006a03                                           // 000000843564: D7006A03
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 000000843568: 02020608
	v_div_fixup_f32 v2, v5, v6, 1.0                            // 00000084356C: D6270002 03CA0D05
	v_add_co_ci_u32_e64 v4, null, s9, v4, vcc_lo               // 000000843574: D5207C04 01AA0809
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000084357C: BF870193
	.long 0xd7006a00                                           // 000000843580: D7006A00
	v_cndmask_b32_e32 v1, v3, v0, vcc_lo                       // 000000843584: 02020103
	v_add_f32_e32 v2, v2, v2                                   // 000000843588: 06040502
	s_delay_alu instid0(VALU_DEP_3)                            // 00000084358C: BF870003
	v_add_co_ci_u32_e64 v1, null, v4, v1, vcc_lo               // 000000843590: D5207C01 01AA0304
	global_store_b32 v[0:1], v2, off                           // 000000843598: DC6A0000 007C0200
	s_endpgm                                                   // 0000008435A0: BFB00000
		...

