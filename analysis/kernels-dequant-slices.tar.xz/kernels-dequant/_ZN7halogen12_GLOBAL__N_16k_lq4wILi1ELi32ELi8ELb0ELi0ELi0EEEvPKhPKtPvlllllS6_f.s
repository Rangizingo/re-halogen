000000000054a300 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 00000054A300: F4100100 F8000000
	v_dual_mov_b32 v16, 0 :: v_dual_and_b32 v1, 15, v0         // 00000054A308: CA240080 1000008F
	v_lshrrev_b32_e32 v2, 2, v0                                // 00000054A310: 32040082
	s_ashr_i32 s3, s2, 31                                      // 00000054A314: 86039F02
	v_lshrrev_b32_e32 v14, 5, v0                               // 00000054A318: 321C0085
	s_delay_alu instid0(VALU_DEP_3)                            // 00000054A31C: BF870003
	v_lshlrev_b32_e32 v1, 2, v1                                // 00000054A320: 30020282
	v_and_b32_e32 v15, 31, v0                                  // 00000054A324: 361E009F
	v_and_b32_e32 v2, 60, v2                                   // 00000054A328: 360404BC
	.long 0x7f263880                                           // 00000054A32C: 7F263880
	v_dual_mov_b32 v17, 0 :: v_dual_mov_b32 v4, 0              // 00000054A330: CA100080 11040080
	s_waitcnt lgkmcnt(0)                                       // 00000054A338: BF89FC07
	s_clause 0x1                                               // 00000054A33C: BF850001
	global_load_b32 v11, v1, s[4:5]                            // 00000054A340: DC520000 0B040001
	global_load_b32 v13, v2, s[4:5]                            // 00000054A348: DC520000 0D040002
	.long 0xd4510000                                           // 00000054A350: D4510000
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 00000054A354: 02001802
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v2, 0               // 00000054A358: CA100080 01020080
	s_and_b32 s0, s0, exec_lo                                  // 00000054A360: 8B007E00
	s_cselect_b32 s20, s3, 0                                   // 00000054A364: 98148003
	s_cselect_b32 s21, s2, 0                                   // 00000054A368: 98158002
	s_add_u32 s0, s4, s14                                      // 00000054A36C: 80000E04
	s_addc_u32 s1, s5, s15                                     // 00000054A370: 82010F05
	s_lshr_b32 s14, s11, 31                                    // 00000054A374: 850E9F0B
	v_dual_mov_b32 v3, 0 :: v_dual_mov_b32 v6, s1              // 00000054A378: CA100080 03060001
	s_add_u32 s14, s10, s14                                    // 00000054A380: 800E0E0A
	s_addc_u32 s15, s11, 0                                     // 00000054A384: 820F800B
	s_ashr_i32 s22, s11, 31                                    // 00000054A388: 86169F0B
	s_ashr_i64 s[14:15], s[14:15], 1                           // 00000054A38C: 868E810E
	s_lshr_b32 s22, s22, 27                                    // 00000054A390: 85169B16
	v_mov_b32_e32 v5, s0                                       // 00000054A394: 7E0A0200
	s_add_u32 s10, s10, s22                                    // 00000054A398: 800A160A
	s_addc_u32 s11, s11, 0                                     // 00000054A39C: 820B800B
	s_mul_i32 s19, s19, s21                                    // 00000054A3A0: 96131513
	s_lshr_b64 s[10:11], s[10:11], 5                           // 00000054A3A4: 858A850A
	v_mad_u64_u32 v[9:10], null, s21, s14, v[5:6]              // 00000054A3A8: D6FE7C09 04141C15
	s_add_i32 s11, s10, 7                                      // 00000054A3B0: 810B870A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000054A3B4: BF870499
	s_ashr_i32 s22, s11, 31                                    // 00000054A3B8: 86169F0B
	s_lshr_b32 s22, s22, 29                                    // 00000054A3BC: 85169D16
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000054A3C0: BF870499
	s_add_i32 s11, s11, s22                                    // 00000054A3C4: 810B160B
	s_ashr_i32 s11, s11, 3                                     // 00000054A3C8: 860B830B
	s_add_u32 s0, s4, s16                                      // 00000054A3CC: 80001004
	.long 0xd72c0012                                           // 00000054A3D0: D72C0012
	v_cndmask_b32_e32 v1, s11, v14, vcc_lo                     // 00000054A3D4: 02021C0B
	s_addc_u32 s1, s5, s17                                     // 00000054A3D8: 82011105
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000054A3DC: BF870009
	v_dual_mov_b32 v8, s1 :: v_dual_lshlrev_b32 v21, 2, v0     // 00000054A3E0: CA220001 08140082
	v_mov_b32_e32 v7, s0                                       // 00000054A3E8: 7E0E0200
	s_mul_i32 s0, s20, s14                                     // 00000054A3EC: 96000E14
	s_waitcnt vmcnt(1)                                         // 00000054A3F0: BF8907F7
	v_bfe_u32 v12, v11, 16, 1                                  // 00000054A3F4: D610000C 0205210B
	s_waitcnt vmcnt(0)                                         // 00000054A3FC: BF8903F7
	v_bfe_u32 v5, v13, 16, 1                                   // 00000054A400: D6100005 0205210D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000054A408: BF870112
	v_add3_u32 v6, v11, v12, 0x7fff                            // 00000054A40C: D6550006 03FE190B 00007FFF
	v_add3_u32 v5, v13, v5, 0x7fff                             // 00000054A418: D6550005 03FE0B0D 00007FFF
	s_delay_alu instid0(VALU_DEP_2)                            // 00000054A424: BF870002
	.long 0x7e263986                                           // 00000054A428: 7E263986
	v_add_nc_u32_e32 v6, s0, v10                               // 00000054A42C: 4A0C1400
	v_add_nc_u32_e32 v10, v18, v15                             // 00000054A430: 4A141F12
	v_mad_u64_u32 v[11:12], null, s18, s21, v[7:8]             // 00000054A434: D6FE7C0B 041C2A12
	v_add_nc_u32_e32 v7, s11, v18                              // 00000054A43C: 4A0E240B
	s_mul_i32 s21, s21, s15                                    // 00000054A440: 96150F15
	s_mul_i32 s0, s18, s20                                     // 00000054A444: 96001412
	v_and_or_b32 v5, 0xffff0000, v5, v19                       // 00000054A448: D6570005 044E0AFF FFFF0000
	v_add_nc_u32_e32 v19, s21, v6                              // 00000054A454: 4A260C15
	v_min_i32_e32 v18, s10, v7                                 // 00000054A458: 22240E0A
	v_add_nc_u32_e32 v7, s19, v12                              // 00000054A45C: 4A0E1813
	ds_store_b32 v21, v5 offset:32                             // 00000054A460: D8340020 00000515
	v_cmp_lt_i32_e32 vcc_lo, v10, v18                          // 00000054A468: 7C82250A
	v_add_nc_u32_e32 v20, s0, v7                               // 00000054A46C: 4A280E00
	s_waitcnt lgkmcnt(0)                                       // 00000054A470: BF89FC07
	s_barrier                                                  // 00000054A474: BFBD0000
	buffer_gl0_inv                                             // 00000054A478: E0AC0000 00000000
	s_and_saveexec_b32 s1, vcc_lo                              // 00000054A480: BE81206A
	s_cbranch_execz 21                                         // 00000054A484: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x1dc>
	v_lshlrev_b32_e32 v1, 1, v10                               // 00000054A488: 30021481
	v_lshlrev_b32_e32 v3, 4, v10                               // 00000054A48C: 30061484
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000054A490: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000054A494: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 00000054A498: 3408069F
	.long 0xd7000001                                           // 00000054A49C: D7000001
	v_cndmask_b32_e32 v1, v11, v1, vcc_lo                      // 00000054A4A0: 0202030B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000054A4A4: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v20, v2, s0                  // 00000054A4A8: D5207C02 00020514
	.long 0xd7000003                                           // 00000054A4B0: D7000003
	v_cndmask_b32_e32 v1, v9, v3, vcc_lo                       // 00000054A4B4: 02020709
	v_add_co_ci_u32_e64 v4, null, v19, v4, s0                  // 00000054A4B8: D5207C04 00020913
	s_clause 0x1                                               // 00000054A4C0: BF850001
	global_load_d16_b16 v5, v[1:2], off                        // 00000054A4C4: DC820000 057C0001
	global_load_b128 v[1:4], v[3:4], off                       // 00000054A4CC: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 00000054A4D4: BF8907F7
	v_cvt_f32_f16_e32 v17, v5                                  // 00000054A4D8: 7E221705
	s_or_b32 exec_lo, exec_lo, s1                              // 00000054A4DC: 8C7E017E
	s_and_saveexec_b32 s1, vcc_lo                              // 00000054A4E0: BE81206A
	s_cbranch_execz 207                                        // 00000054A4E4: BFA500CF <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x524>
	v_dual_mov_b32 v16, 0 :: v_dual_add_nc_u32 v5, 32, v10     // 00000054A4E8: CA200080 100414A0
	v_dual_mov_b32 v23, v17 :: v_dual_lshlrev_b32 v12, 5, v10  // 00000054A4F0: CA220111 170C1485
	s_mov_b32 s4, 0                                            // 00000054A4F8: BE840080
	s_delay_alu instid0(VALU_DEP_2)                            // 00000054A4FC: BF870002
	v_lshlrev_b32_e32 v21, 4, v5                               // 00000054A500: 302A0A84
	v_lshlrev_b32_e32 v22, 1, v5                               // 00000054A504: 302C0A81
	s_branch 166                                               // 00000054A508: BFA000A6 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x4a4>
	s_or_b32 exec_lo, exec_lo, s5                              // 00000054A50C: 8C7E057E
	v_ashrrev_i32_e32 v13, 31, v12                             // 00000054A510: 341A189F
	v_lshrrev_b32_e32 v40, 6, v1                               // 00000054A514: 32500286
	v_lshrrev_b32_e32 v41, 14, v1                              // 00000054A518: 3252028E
	v_and_b32_e32 v42, 0xff, v2                                // 00000054A51C: 365404FF 000000FF
	v_lshrrev_b32_e32 v43, 6, v2                               // 00000054A524: 32560486
	.long 0xd73c0018                                           // 00000054A528: D73C0018
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 00000054A52C: 02021881
	v_and_b32_e32 v13, 0xff, v1                                // 00000054A530: 361A02FF 000000FF
	v_and_b32_e32 v40, 0x3fc, v40                              // 00000054A538: 365050FF 000003FC
	v_and_b32_e32 v41, 0x3fc, v41                              // 00000054A540: 365252FF 000003FC
	v_lshrrev_b32_e32 v1, 22, v1                               // 00000054A548: 32020296
	v_lshrrev_b32_e32 v44, 14, v2                              // 00000054A54C: 3258048E
	.long 0xd7000024                                           // 00000054A550: D7000024
	v_cndmask_b32_e32 v1, s6, v24, vcc_lo                      // 00000054A554: 02023006
	s_delay_alu instid0(VALU_DEP_1)                            // 00000054A558: BF870001
	v_add_co_ci_u32_e64 v37, null, s7, v25, s0                 // 00000054A55C: D5207C25 00023207
	v_lshlrev_b32_e32 v13, 2, v13                              // 00000054A564: 301A1A82
	ds_load_b32 v40, v40 offset:32                             // 00000054A568: D8D80020 28000028
	ds_load_b32 v41, v41 offset:32                             // 00000054A570: D8D80020 29000029
	s_clause 0x3                                               // 00000054A578: BF850003
	global_load_b128 v[24:27], v[36:37], off                   // 00000054A57C: DC5E0000 187C0024
	global_load_b128 v[28:31], v[36:37], off offset:16         // 00000054A584: DC5E0010 1C7C0024
	global_load_b128 v[32:35], v[36:37], off offset:32         // 00000054A58C: DC5E0020 207C0024
	global_load_b128 v[36:39], v[36:37], off offset:48         // 00000054A594: DC5E0030 247C0024
	v_lshrrev_b32_e32 v2, 22, v2                               // 00000054A59C: 32040496
	ds_load_b32 v13, v13 offset:32                             // 00000054A5A0: D8D80020 0D00000D
	v_and_b32_e32 v1, 0x3fc, v1                                // 00000054A5A8: 360202FF 000003FC
	v_lshlrev_b32_e32 v42, 2, v42                              // 00000054A5B0: 30545482
	v_and_b32_e32 v43, 0x3fc, v43                              // 00000054A5B4: 365656FF 000003FC
	v_and_b32_e32 v44, 0x3fc, v44                              // 00000054A5BC: 365858FF 000003FC
	v_and_b32_e32 v2, 0x3fc, v2                                // 00000054A5C4: 360404FF 000003FC
	ds_load_b32 v1, v1 offset:32                               // 00000054A5CC: D8D80020 01000001
	ds_load_b32 v42, v42 offset:32                             // 00000054A5D4: D8D80020 2A00002A
	ds_load_b32 v43, v43 offset:32                             // 00000054A5DC: D8D80020 2B00002B
	ds_load_b32 v44, v44 offset:32                             // 00000054A5E4: D8D80020 2C00002C
	ds_load_b32 v2, v2 offset:32                               // 00000054A5EC: D8D80020 02000002
	v_add_nc_u32_e32 v21, 0x200, v21                           // 00000054A5F4: 4A2A2AFF 00000200
	v_add_nc_u32_e32 v22, 64, v22                              // 00000054A5FC: 4A2C2CC0
	v_add_nc_u32_e32 v12, 0x400, v12                           // 00000054A600: 4A1818FF 00000400
	s_and_b32 s0, exec_lo, vcc_lo                              // 00000054A608: 8B006A7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000054A60C: BF870149
	s_or_b32 s4, s0, s4                                        // 00000054A610: 8C040400
	s_waitcnt vmcnt(3) lgkmcnt(5)                              // 00000054A614: BF890C57
	v_dot2_f32_bf16 v13, v24, v13, 0                           // 00000054A618: CC1A400D 1A021B18
	v_and_b32_e32 v24, 0xff, v3                                // 00000054A620: 363006FF 000000FF
	v_dot2_f32_bf16 v13, v25, v40, v13                         // 00000054A628: CC1A400D 1C365119
	v_lshrrev_b32_e32 v25, 6, v3                               // 00000054A630: 32320686
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000054A634: BF8701A2
	v_dot2_f32_bf16 v13, v26, v41, v13                         // 00000054A638: CC1A400D 1C36531A
	v_lshrrev_b32_e32 v26, 14, v3                              // 00000054A640: 3234068E
	v_and_b32_e32 v25, 0x3fc, v25                              // 00000054A644: 363232FF 000003FC
	v_lshrrev_b32_e32 v3, 22, v3                               // 00000054A64C: 32060696
	s_waitcnt lgkmcnt(4)                                       // 00000054A650: BF89FC47
	v_dot2_f32_bf16 v1, v27, v1, v13                           // 00000054A654: CC1A4001 1C36031B
	v_lshlrev_b32_e32 v13, 2, v24                              // 00000054A65C: 301A3082
	v_and_b32_e32 v26, 0x3fc, v26                              // 00000054A660: 363434FF 000003FC
	v_and_b32_e32 v24, 0xff, v4                                // 00000054A668: 363008FF 000000FF
	v_lshrrev_b32_e32 v27, 6, v4                               // 00000054A670: 32360886
	s_waitcnt vmcnt(2) lgkmcnt(3)                              // 00000054A674: BF890837
	v_dot2_f32_bf16 v1, v28, v42, v1                           // 00000054A678: CC1A4001 1C06551C
	ds_load_b32 v13, v13 offset:32                             // 00000054A680: D8D80020 0D00000D
	ds_load_b32 v25, v25 offset:32                             // 00000054A688: D8D80020 19000019
	ds_load_b32 v26, v26 offset:32                             // 00000054A690: D8D80020 1A00001A
	v_lshrrev_b32_e32 v28, 14, v4                              // 00000054A698: 3238088E
	s_waitcnt lgkmcnt(5)                                       // 00000054A69C: BF89FC57
	v_dot2_f32_bf16 v1, v29, v43, v1                           // 00000054A6A0: CC1A4001 1C06571D
	v_lshrrev_b32_e32 v4, 22, v4                               // 00000054A6A8: 32080896
	v_and_b32_e32 v3, 0x3fc, v3                                // 00000054A6AC: 360606FF 000003FC
	v_lshlrev_b32_e32 v24, 2, v24                              // 00000054A6B4: 30303082
	v_and_b32_e32 v27, 0x3fc, v27                              // 00000054A6B8: 363636FF 000003FC
	s_waitcnt lgkmcnt(4)                                       // 00000054A6C0: BF89FC47
	v_dot2_f32_bf16 v1, v30, v44, v1                           // 00000054A6C4: CC1A4001 1C06591E
	v_and_b32_e32 v28, 0x3fc, v28                              // 00000054A6CC: 363838FF 000003FC
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000054A6D4: 360808FF 000003FC
	s_waitcnt lgkmcnt(3)                                       // 00000054A6DC: BF89FC37
	s_delay_alu instid0(VALU_DEP_3)                            // 00000054A6E0: BF870003
	v_dot2_f32_bf16 v1, v31, v2, v1                            // 00000054A6E4: CC1A4001 1C06051F
	ds_load_b32 v2, v3 offset:32                               // 00000054A6EC: D8D80020 02000003
	ds_load_b32 v3, v24 offset:32                              // 00000054A6F4: D8D80020 03000018
	ds_load_b32 v24, v27 offset:32                             // 00000054A6FC: D8D80020 1800001B
	ds_load_b32 v27, v28 offset:32                             // 00000054A704: D8D80020 1B00001C
	ds_load_b32 v28, v4 offset:32                              // 00000054A70C: D8D80020 1C000004
	v_mov_b32_e32 v4, v8                                       // 00000054A714: 7E080308
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 00000054A718: BF890477
	v_dot2_f32_bf16 v1, v32, v13, v1                           // 00000054A71C: CC1A4001 1C061B20
	s_waitcnt lgkmcnt(6)                                       // 00000054A724: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000054A728: BF8700A1
	v_dot2_f32_bf16 v1, v33, v25, v1                           // 00000054A72C: CC1A4001 1C063321
	s_waitcnt lgkmcnt(5)                                       // 00000054A734: BF89FC57
	v_dot2_f32_bf16 v1, v34, v26, v1                           // 00000054A738: CC1A4001 1C063522
	s_waitcnt lgkmcnt(4)                                       // 00000054A740: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000054A744: BF870131
	v_dot2_f32_bf16 v1, v35, v2, v1                            // 00000054A748: CC1A4001 1C060523
	v_mov_b32_e32 v2, v6                                       // 00000054A750: 7E040306
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 00000054A754: BF890037
	v_dot2_f32_bf16 v1, v36, v3, v1                            // 00000054A758: CC1A4001 1C060724
	v_mov_b32_e32 v3, v7                                       // 00000054A760: 7E060307
	s_waitcnt lgkmcnt(2)                                       // 00000054A764: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000054A768: BF8700A2
	v_dot2_f32_bf16 v1, v37, v24, v1                           // 00000054A76C: CC1A4001 1C063125
	s_waitcnt lgkmcnt(1)                                       // 00000054A774: BF89FC17
	v_dot2_f32_bf16 v1, v38, v27, v1                           // 00000054A778: CC1A4001 1C063726
	s_waitcnt lgkmcnt(0)                                       // 00000054A780: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000054A784: BF870121
	v_dot2_f32_bf16 v8, v39, v28, v1                           // 00000054A788: CC1A4008 1C063927
	v_mov_b32_e32 v1, v5                                       // 00000054A790: 7E020305
	v_dual_fmac_f32 v16, v17, v8 :: v_dual_mov_b32 v17, v23    // 00000054A794: C8101111 10100117
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000054A79C: 917E047E
	s_cbranch_execz 31                                         // 00000054A7A0: BFA5001F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x520>
	s_waitcnt vmcnt(0)                                         // 00000054A7A4: BF8903F7
	v_dual_mov_b32 v5, v1 :: v_dual_add_nc_u32 v10, 32, v10    // 00000054A7A8: CA200101 050A14A0
	v_dual_mov_b32 v6, v2 :: v_dual_mov_b32 v7, v3             // 00000054A7B0: CA100102 06060103
	v_mov_b32_e32 v8, v4                                       // 00000054A7B8: 7E100304
	s_mov_b32 s5, exec_lo                                      // 00000054A7BC: BE85007E
	s_delay_alu instid0(VALU_DEP_3)                            // 00000054A7C0: BF870003
	v_cmp_ge_i32_e32 vcc_lo, v10, v18                          // 00000054A7C4: 7C8C250A
	.long 0xd4c1007e                                           // 00000054A7C8: D4C1007E
	v_cndmask_b32_e32 v1, v10, v18, vcc_lo                     // 00000054A7CC: 0202250A
	s_cbranch_execz 65358                                      // 00000054A7D0: BFA5FF4E <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x20c>
	v_ashrrev_i32_e32 v6, 31, v22                              // 00000054A7D4: 340C2C9F
	v_ashrrev_i32_e32 v8, 31, v21                              // 00000054A7D8: 34102A9F
	.long 0xd7000005                                           // 00000054A7DC: D7000005
	v_cndmask_b32_e32 v1, v11, v22, vcc_lo                     // 00000054A7E0: 02022D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000054A7E4: BF8700A1
	v_add_co_ci_u32_e64 v6, null, v20, v6, s0                  // 00000054A7E8: D5207C06 00020D14
	.long 0xd7000007                                           // 00000054A7F0: D7000007
	v_cndmask_b32_e32 v1, v9, v21, vcc_lo                      // 00000054A7F4: 02022B09
	v_add_co_ci_u32_e64 v8, null, v19, v8, s0                  // 00000054A7F8: D5207C08 00021113
	s_clause 0x1                                               // 00000054A800: BF850001
	global_load_d16_b16 v13, v[5:6], off                       // 00000054A804: DC820000 0D7C0005
	global_load_b128 v[5:8], v[7:8], off                       // 00000054A80C: DC5E0000 057C0007
	s_waitcnt vmcnt(1)                                         // 00000054A814: BF8907F7
	v_cvt_f32_f16_e32 v23, v13                                 // 00000054A818: 7E2E170D
	s_branch 65339                                             // 00000054A81C: BFA0FF3B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x20c>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000054A820: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000054A824: BF8700C9
	s_or_b32 exec_lo, exec_lo, s1                              // 00000054A828: 8C7E017E
	s_waitcnt vmcnt(0)                                         // 00000054A82C: BF8903F7
	.long 0xd71f0001                                           // 00000054A830: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000054A834: 020100C1
	s_mov_b32 s0, exec_lo                                      // 00000054A838: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 00000054A83C: 3A040290
	v_xor_b32_e32 v3, 8, v1                                    // 00000054A840: 3A060288
	v_xor_b32_e32 v4, 4, v1                                    // 00000054A844: 3A080284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000054A848: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 00000054A84C: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 00000054A850: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v3                            // 00000054A854: 7C9806A0
	v_cndmask_b32_e32 v3, v1, v3, vcc_lo                       // 00000054A858: 02060701
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 00000054A85C: 7C9808A0
	s_delay_alu instid0(VALU_DEP_2)                            // 00000054A860: BF870002
	v_lshlrev_b32_e32 v3, 2, v3                                // 00000054A864: 30060682
	v_lshlrev_b32_e32 v2, 2, v2                                // 00000054A868: 30040482
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo                       // 00000054A86C: 02080901
	ds_bpermute_b32 v2, v2, v16                                // 00000054A870: DACC0000 02001002
	v_lshlrev_b32_e32 v4, 2, v4                                // 00000054A878: 30080882
	s_waitcnt lgkmcnt(0)                                       // 00000054A87C: BF89FC07
	v_add_f32_e32 v2, v16, v2                                  // 00000054A880: 06040510
	ds_bpermute_b32 v3, v3, v2                                 // 00000054A884: DACC0000 03000203
	s_waitcnt lgkmcnt(0)                                       // 00000054A88C: BF89FC07
	v_add_f32_e32 v2, v2, v3                                   // 00000054A890: 06040702
	ds_bpermute_b32 v3, v4, v2                                 // 00000054A894: DACC0000 03000204
	v_xor_b32_e32 v4, 2, v1                                    // 00000054A89C: 3A080282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000054A8A0: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 00000054A8A4: 7C9808A0
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo                       // 00000054A8A8: 02080901
	v_lshlrev_b32_e32 v4, 2, v4                                // 00000054A8AC: 30080882
	s_waitcnt lgkmcnt(0)                                       // 00000054A8B0: BF89FC07
	v_add_f32_e32 v2, v2, v3                                   // 00000054A8B4: 06040702
	ds_bpermute_b32 v3, v4, v2                                 // 00000054A8B8: DACC0000 03000204
	v_xor_b32_e32 v4, 1, v1                                    // 00000054A8C0: 3A080281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000054A8C4: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 00000054A8C8: 7C9808A0
	s_waitcnt lgkmcnt(0)                                       // 00000054A8CC: BF89FC07
	v_dual_cndmask_b32 v4, v1, v4 :: v_dual_add_f32 v1, v2, v3 // 00000054A8D0: CA480901 04000702
	v_lshlrev_b32_e32 v2, 2, v4                                // 00000054A8D8: 30040882
	ds_bpermute_b32 v2, v2, v1                                 // 00000054A8DC: DACC0000 02000102
	v_cmpx_eq_u32_e32 0, v15                                   // 00000054A8E4: 7D941E80
	s_cbranch_execz 5                                          // 00000054A8E8: BFA50005 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x600>
	v_lshlrev_b32_e32 v3, 2, v14                               // 00000054A8EC: 30061C82
	s_waitcnt lgkmcnt(0)                                       // 00000054A8F0: BF89FC07
	v_add_f32_e32 v1, v1, v2                                   // 00000054A8F4: 06020501
	ds_store_b32 v3, v1                                        // 00000054A8F8: D8340000 00000103
	s_or_b32 exec_lo, exec_lo, s0                              // 00000054A900: 8C7E007E
	.long 0xd4510000                                           // 00000054A904: D4510000
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 00000054A908: 02001802
	v_cmp_eq_u32_e32 vcc_lo, 0, v0                             // 00000054A90C: 7C940080
	s_waitcnt lgkmcnt(0)                                       // 00000054A910: BF89FC07
	s_barrier                                                  // 00000054A914: BFBD0000
	buffer_gl0_inv                                             // 00000054A918: E0AC0000 00000000
	s_and_b32 s0, vcc_lo, s0                                   // 00000054A920: 8B00006A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000054A924: BF870009
	s_and_saveexec_b32 s1, s0                                  // 00000054A928: BE812000
	s_cbranch_execz 30                                         // 00000054A92C: BFA5001E <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x6a8>
	v_mov_b32_e32 v8, 0                                        // 00000054A930: 7E100280
	s_lshl_b64 s[0:1], s[2:3], 1                               // 00000054A934: 84808102
	ds_load_b128 v[0:3], v8                                    // 00000054A938: DBFC0000 00000008
	ds_load_b128 v[4:7], v8 offset:16                          // 00000054A940: DBFC0010 04000008
	s_add_u32 s0, s8, s0                                       // 00000054A948: 80000008
	s_addc_u32 s1, s9, s1                                      // 00000054A94C: 82010109
	s_waitcnt lgkmcnt(1)                                       // 00000054A950: BF89FC17
	v_add_f32_e32 v0, 0, v0                                    // 00000054A954: 06000080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000054A958: BF870091
	v_add_f32_e32 v0, v0, v1                                   // 00000054A95C: 06000300
	v_add_f32_e32 v0, v0, v2                                   // 00000054A960: 06000500
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000054A964: BF8700A1
	v_add_f32_e32 v0, v0, v3                                   // 00000054A968: 06000700
	s_waitcnt lgkmcnt(0)                                       // 00000054A96C: BF89FC07
	v_add_f32_e32 v0, v0, v4                                   // 00000054A970: 06000900
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000054A974: BF870091
	v_add_f32_e32 v0, v0, v5                                   // 00000054A978: 06000B00
	v_add_f32_e32 v0, v0, v6                                   // 00000054A97C: 06000D00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000054A980: BF870091
	v_add_f32_e32 v0, v0, v7                                   // 00000054A984: 06000F00
	v_bfe_u32 v1, v0, 16, 1                                    // 00000054A988: D6100001 02052100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000054A990: BF870091
	v_add_nc_u32_e32 v0, v0, v1                                // 00000054A994: 4A000300
	v_add_nc_u32_e32 v0, 0x7fff, v0                            // 00000054A998: 4A0000FF 00007FFF
	global_store_d16_hi_b16 v8, v0, s[0:1]                     // 00000054A9A0: DC960000 00000008
	s_endpgm                                                   // 00000054A9A8: BFB00000
		...

