00000000002cbe00 <_ZN7halogen12_GLOBAL__N_17k_hcup4ILi1ELi0EEEvPKhlllPKtS5_PtPf>:
; _ZN7halogen12_GLOBAL__N_17k_hcup4ILi1ELi0EEEvPKhlllPKtS5_PtPf():
	s_load_b512 s[4:19], s[0:1], null                          // 0000002CBE00: F4100100 F8000000
	v_and_b32_e32 v2, 15, v0                                   // 0000002CBE08: 3604008F
	v_lshrrev_b32_e32 v1, 4, v0                                // 0000002CBE0C: 32020084
	.long 0x7f0c3880                                           // 0000002CBE10: 7F0C3880
	v_bfe_u32 v8, v0, 4, 1                                     // 0000002CBE14: D6100008 02050900
	s_lshl_b32 s0, s2, 4                                       // 0000002CBE1C: 84008402
	v_lshlrev_b32_e32 v3, 2, v2                                // 0000002CBE20: 30060482
	v_lshlrev_b32_e32 v4, 2, v1                                // 0000002CBE24: 30080282
	v_and_b32_e32 v1, 14, v1                                   // 0000002CBE28: 3602028E
	v_lshlrev_b32_e32 v9, 2, v0                                // 0000002CBE2C: 30120082
	s_waitcnt lgkmcnt(0)                                       // 0000002CBE30: BF89FC07
	s_clause 0x1                                               // 0000002CBE34: BF850001
	global_load_b32 v3, v3, s[4:5]                             // 0000002CBE38: DC520000 03040003
	global_load_b32 v4, v4, s[4:5]                             // 0000002CBE40: DC520000 04040004
	s_waitcnt vmcnt(1)                                         // 0000002CBE48: BF8907F7
	v_bfe_u32 v5, v3, 16, 1                                    // 0000002CBE4C: D6100005 02052103
	s_waitcnt vmcnt(0)                                         // 0000002CBE54: BF8903F7
	v_bfe_u32 v7, v4, 16, 1                                    // 0000002CBE58: D6100007 02052104
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002CBE60: BF870112
	v_add3_u32 v5, v3, v5, 0x7fff                              // 0000002CBE64: D6550005 03FE0B03 00007FFF
	v_add3_u32 v7, v4, v7, 0x7fff                              // 0000002CBE70: D6550007 03FE0F04 00007FFF
	v_dual_mov_b32 v3, 0 :: v_dual_mov_b32 v4, 0               // 0000002CBE7C: CA100080 03040080
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002CBE84: BF870123
	.long 0x7e0c3985                                           // 0000002CBE88: 7E0C3985
	v_mov_b32_e32 v5, 0                                        // 0000002CBE8C: 7E0A0280
	v_and_or_b32 v7, 0xffff0000, v7, v6                        // 0000002CBE90: D6570007 041A0EFF FFFF0000
	v_mov_b32_e32 v6, 0                                        // 0000002CBE9C: 7E0C0280
	v_or3_b32 v0, v1, s0, v8                                   // 0000002CBEA0: D6580000 04200101
	s_mov_b32 s0, exec_lo                                      // 0000002CBEA8: BE80007E
	ds_store_b32 v9, v7                                        // 0000002CBEAC: D8340000 00000709
	v_ashrrev_i32_e32 v1, 31, v0                               // 0000002CBEB4: 3402009F
	s_waitcnt lgkmcnt(0)                                       // 0000002CBEB8: BF89FC07
	s_barrier                                                  // 0000002CBEBC: BFBD0000
	buffer_gl0_inv                                             // 0000002CBEC0: E0AC0000 00000000
	v_cmpx_gt_u32_e32 10, v2                                   // 0000002CBEC8: 7D98048A
	s_cbranch_execz 579                                        // 0000002CBECC: BFA50243 <_ZN7halogen12_GLOBAL__N_17k_hcup4ILi1ELi0EEEvPKhlllPKtS5_PtPf+0x9dc>
	v_lshlrev_b32_e32 v3, 4, v2                                // 0000002CBED0: 30060484
	s_add_u32 s1, s4, s6                                       // 0000002CBED4: 80010604
	s_addc_u32 s2, s5, s7                                      // 0000002CBED8: 82020705
	v_lshlrev_b32_e32 v33, 6, v2                               // 0000002CBEDC: 30420486
	v_lshlrev_b32_e32 v31, 1, v2                               // 0000002CBEE0: 303E0481
	.long 0xd7000103                                           // 0000002CBEE4: D7000103
	v_cndmask_b32_e32 v1, s1, v3, vcc_lo                       // 0000002CBEE8: 02020601
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002CBEEC: BF870001
	v_add_co_ci_u32_e64 v4, null, s2, 0, s1                    // 0000002CBEF0: D5207C04 00050002
	s_clause 0x2                                               // 0000002CBEF8: BF850002
	global_load_b128 v[19:22], v33, s[12:13]                   // 0000002CBEFC: DC5E0000 130C0021
	global_load_b128 v[23:26], v33, s[12:13] offset:16         // 0000002CBF04: DC5E0010 170C0021
	global_load_b128 v[27:30], v33, s[12:13] offset:32         // 0000002CBF0C: DC5E0020 1B0C0021
	s_add_u32 s1, s4, s8                                       // 0000002CBF14: 80010804
	s_addc_u32 s2, s5, s9                                      // 0000002CBF18: 82020905
	v_mad_i64_i32 v[15:16], null, 0xa0, v0, v[3:4]             // 0000002CBF1C: D6FF7C0F 040E00FF 000000A0
	.long 0xd700011f                                           // 0000002CBF28: D700011F
	v_cndmask_b32_e32 v1, s1, v31, vcc_lo                      // 0000002CBF2C: 02023E01
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000002CBF30: BF8700D1
	v_add_co_ci_u32_e64 v32, null, s2, 0, s1                   // 0000002CBF34: D5207C20 00050002
	.long 0xd72c0025                                           // 0000002CBF3C: D72C0025
	v_cndmask_b32_e32 v1, s11, v0, vcc_lo                      // 0000002CBF40: 0202000B
	.long 0xd72c0026                                           // 0000002CBF44: D72C0026
	v_cndmask_b32_e32 v1, s10, v1, vcc_lo                      // 0000002CBF48: 0202020A
	s_mul_i32 s1, s11, 0xa00                                   // 0000002CBF4C: 9601FF0B 00000A00
	.long 0xd7006a07                                           // 0000002CBF54: D7006A07
	v_cndmask_b32_e32 v1, 0x64000, v15, vcc_lo                 // 0000002CBF58: 02021EFF 00064000
	v_add_co_ci_u32_e64 v8, null, 0, v16, vcc_lo               // 0000002CBF60: D5207C08 01AA2080
	.long 0xd7006a0b                                           // 0000002CBF68: D7006A0B
	v_cndmask_b32_e32 v1, 0xc8000, v15, vcc_lo                 // 0000002CBF6C: 02021EFF 000C8000
	global_load_b128 v[3:6], v[15:16], off                     // 0000002CBF74: DC5E0000 037C000F
	v_add_co_ci_u32_e64 v12, null, 0, v16, vcc_lo              // 0000002CBF7C: D5207C0C 01AA2080
	.long 0xd7006a0f                                           // 0000002CBF84: D7006A0F
	v_cndmask_b32_e32 v1, 0x12c000, v15, vcc_lo                // 0000002CBF88: 02021EFF 0012C000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002CBF90: BF870001
	v_add_co_ci_u32_e64 v16, null, 0, v16, vcc_lo              // 0000002CBF94: D5207C10 01AA2080
	s_clause 0x1                                               // 0000002CBF9C: BF850001
	global_load_b128 v[7:10], v[7:8], off                      // 0000002CBFA0: DC5E0000 077C0007
	global_load_b128 v[11:14], v[11:12], off                   // 0000002CBFA8: DC5E0000 0B7C000B
	v_mad_u64_u32 v[35:36], null, s10, v0, v[31:32]            // 0000002CBFB0: D6FE7C23 047E000A
	global_load_b128 v[15:18], v[15:16], off                   // 0000002CBFB8: DC5E0000 0F7C000F
	global_load_b128 v[31:34], v33, s[12:13] offset:48         // 0000002CBFC0: DC5E0030 1F0C0021
	s_mul_hi_u32 s2, s10, 0xa00                                // 0000002CBFC8: 9682FF0A 00000A00
	s_mul_i32 s3, s10, 0xa00                                   // 0000002CBFD0: 9603FF0A 00000A00
	s_add_i32 s2, s2, s1                                       // 0000002CBFD8: 81020102
	v_add3_u32 v36, v37, v36, v38                              // 0000002CBFDC: D6550024 049A4925
	.long 0xd7006a25                                           // 0000002CBFE4: D7006A25
	v_cndmask_b32_e32 v0, v35, v3, vcc_lo                      // 0000002CBFE8: 02000723
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002CBFEC: BF870111
	v_add_co_ci_u32_e64 v38, null, s2, v36, vcc_lo             // 0000002CBFF0: D5207C26 01AA4802
	.long 0xd7006a27                                           // 0000002CBFF8: D7006A27
	v_cndmask_b32_e32 v0, v37, v3, vcc_lo                      // 0000002CBFFC: 02000725
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002CC000: BF870111
	v_add_co_ci_u32_e64 v40, null, s2, v38, vcc_lo             // 0000002CC004: D5207C28 01AA4C02
	.long 0xd7006a29                                           // 0000002CC00C: D7006A29
	v_cndmask_b32_e32 v0, v39, v3, vcc_lo                      // 0000002CC010: 02000727
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002CC014: BF870001
	v_add_co_ci_u32_e64 v42, null, s2, v40, vcc_lo             // 0000002CC018: D5207C2A 01AA5002
	s_clause 0x3                                               // 0000002CC020: BF850003
	global_load_d16_b16 v35, v[35:36], off                     // 0000002CC024: DC820000 237C0023
	global_load_d16_b16 v36, v[37:38], off                     // 0000002CC02C: DC820000 247C0025
	global_load_d16_b16 v37, v[39:40], off                     // 0000002CC034: DC820000 257C0027
	global_load_d16_b16 v38, v[41:42], off                     // 0000002CC03C: DC820000 267C0029
	s_waitcnt vmcnt(8)                                         // 0000002CC044: BF8923F7
	v_and_b32_e32 v39, 0xff, v3                                // 0000002CC048: 364E06FF 000000FF
	v_lshrrev_b32_e32 v40, 6, v3                               // 0000002CC050: 32500686
	v_lshrrev_b32_e32 v41, 14, v3                              // 0000002CC054: 3252068E
	v_lshrrev_b32_e32 v3, 22, v3                               // 0000002CC058: 32060696
	v_and_b32_e32 v42, 0xff, v4                                // 0000002CC05C: 365408FF 000000FF
	v_lshrrev_b32_e32 v43, 6, v4                               // 0000002CC064: 32560886
	v_lshrrev_b32_e32 v44, 14, v4                              // 0000002CC068: 3258088E
	v_lshrrev_b32_e32 v4, 22, v4                               // 0000002CC06C: 32080896
	s_waitcnt vmcnt(6)                                         // 0000002CC070: BF891BF7
	v_and_b32_e32 v63, 0xff, v11                               // 0000002CC074: 367E16FF 000000FF
	v_and_b32_e32 v45, 0xff, v5                                // 0000002CC07C: 365A0AFF 000000FF
	s_waitcnt vmcnt(5)                                         // 0000002CC084: BF8917F7
	v_and_b32_e32 v75, 0xff, v15                               // 0000002CC088: 36961EFF 000000FF
	v_lshrrev_b32_e32 v46, 6, v5                               // 0000002CC090: 325C0A86
	v_lshrrev_b32_e32 v47, 14, v5                              // 0000002CC094: 325E0A8E
	v_lshrrev_b32_e32 v5, 22, v5                               // 0000002CC098: 320A0A96
	v_and_b32_e32 v48, 0xff, v6                                // 0000002CC09C: 36600CFF 000000FF
	v_lshrrev_b32_e32 v49, 6, v6                               // 0000002CC0A4: 32620C86
	v_lshrrev_b32_e32 v50, 14, v6                              // 0000002CC0A8: 32640C8E
	v_lshrrev_b32_e32 v6, 22, v6                               // 0000002CC0AC: 320C0C96
	v_and_b32_e32 v51, 0xff, v7                                // 0000002CC0B0: 36660EFF 000000FF
	v_lshlrev_b32_e32 v39, 2, v39                              // 0000002CC0B8: 304E4E82
	v_lshrrev_b32_e32 v52, 6, v7                               // 0000002CC0BC: 32680E86
	v_and_b32_e32 v40, 0x3fc, v40                              // 0000002CC0C0: 365050FF 000003FC
	v_lshrrev_b32_e32 v53, 14, v7                              // 0000002CC0C8: 326A0E8E
	v_lshrrev_b32_e32 v7, 22, v7                               // 0000002CC0CC: 320E0E96
	v_and_b32_e32 v54, 0xff, v8                                // 0000002CC0D0: 366C10FF 000000FF
	v_lshrrev_b32_e32 v55, 6, v8                               // 0000002CC0D8: 326E1086
	v_lshrrev_b32_e32 v56, 14, v8                              // 0000002CC0DC: 3270108E
	v_lshrrev_b32_e32 v8, 22, v8                               // 0000002CC0E0: 32101096
	v_lshrrev_b32_e32 v64, 6, v11                              // 0000002CC0E4: 32801686
	v_lshrrev_b32_e32 v65, 14, v11                             // 0000002CC0E8: 3282168E
	v_lshrrev_b32_e32 v11, 22, v11                             // 0000002CC0EC: 32161696
	v_and_b32_e32 v66, 0xff, v12                               // 0000002CC0F0: 368418FF 000000FF
	v_lshrrev_b32_e32 v67, 6, v12                              // 0000002CC0F8: 32861886
	v_lshrrev_b32_e32 v68, 14, v12                             // 0000002CC0FC: 3288188E
	v_lshrrev_b32_e32 v12, 22, v12                             // 0000002CC100: 32181896
	v_lshrrev_b32_e32 v76, 6, v15                              // 0000002CC104: 32981E86
	v_lshrrev_b32_e32 v77, 14, v15                             // 0000002CC108: 329A1E8E
	v_lshrrev_b32_e32 v15, 22, v15                             // 0000002CC10C: 321E1E96
	v_and_b32_e32 v78, 0xff, v16                               // 0000002CC110: 369C20FF 000000FF
	v_lshrrev_b32_e32 v79, 6, v16                              // 0000002CC118: 329E2086
	v_lshrrev_b32_e32 v80, 14, v16                             // 0000002CC11C: 32A0208E
	v_lshrrev_b32_e32 v16, 22, v16                             // 0000002CC120: 32202096
	v_and_b32_e32 v41, 0x3fc, v41                              // 0000002CC124: 365252FF 000003FC
	v_lshlrev_b32_e32 v63, 2, v63                              // 0000002CC12C: 307E7E82
	v_and_b32_e32 v3, 0x3fc, v3                                // 0000002CC130: 360606FF 000003FC
	v_lshlrev_b32_e32 v75, 2, v75                              // 0000002CC138: 30969682
	v_lshlrev_b32_e32 v42, 2, v42                              // 0000002CC13C: 30545482
	v_and_b32_e32 v43, 0x3fc, v43                              // 0000002CC140: 365656FF 000003FC
	v_and_b32_e32 v44, 0x3fc, v44                              // 0000002CC148: 365858FF 000003FC
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000002CC150: 360808FF 000003FC
	v_lshlrev_b32_e32 v45, 2, v45                              // 0000002CC158: 305A5A82
	v_and_b32_e32 v46, 0x3fc, v46                              // 0000002CC15C: 365C5CFF 000003FC
	v_and_b32_e32 v47, 0x3fc, v47                              // 0000002CC164: 365E5EFF 000003FC
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000002CC16C: 360A0AFF 000003FC
	v_lshlrev_b32_e32 v48, 2, v48                              // 0000002CC174: 30606082
	v_and_b32_e32 v49, 0x3fc, v49                              // 0000002CC178: 366262FF 000003FC
	v_and_b32_e32 v50, 0x3fc, v50                              // 0000002CC180: 366464FF 000003FC
	v_and_b32_e32 v6, 0x3fc, v6                                // 0000002CC188: 360C0CFF 000003FC
	v_lshlrev_b32_e32 v51, 2, v51                              // 0000002CC190: 30666682
	ds_load_b32 v39, v39                                       // 0000002CC194: D8D80000 27000027
	ds_load_b32 v40, v40                                       // 0000002CC19C: D8D80000 28000028
	ds_load_b32 v41, v41                                       // 0000002CC1A4: D8D80000 29000029
	ds_load_b32 v3, v3                                         // 0000002CC1AC: D8D80000 03000003
	ds_load_b32 v42, v42                                       // 0000002CC1B4: D8D80000 2A00002A
	ds_load_b32 v43, v43                                       // 0000002CC1BC: D8D80000 2B00002B
	ds_load_b32 v44, v44                                       // 0000002CC1C4: D8D80000 2C00002C
	ds_load_b32 v4, v4                                         // 0000002CC1CC: D8D80000 04000004
	ds_load_b32 v45, v45                                       // 0000002CC1D4: D8D80000 2D00002D
	ds_load_b32 v46, v46                                       // 0000002CC1DC: D8D80000 2E00002E
	ds_load_b32 v47, v47                                       // 0000002CC1E4: D8D80000 2F00002F
	ds_load_b32 v5, v5                                         // 0000002CC1EC: D8D80000 05000005
	ds_load_b32 v48, v48                                       // 0000002CC1F4: D8D80000 30000030
	ds_load_b32 v49, v49                                       // 0000002CC1FC: D8D80000 31000031
	ds_load_b32 v50, v50                                       // 0000002CC204: D8D80000 32000032
	ds_load_b32 v6, v6                                         // 0000002CC20C: D8D80000 06000006
	v_and_b32_e32 v52, 0x3fc, v52                              // 0000002CC214: 366868FF 000003FC
	v_and_b32_e32 v53, 0x3fc, v53                              // 0000002CC21C: 366A6AFF 000003FC
	v_and_b32_e32 v7, 0x3fc, v7                                // 0000002CC224: 360E0EFF 000003FC
	v_lshlrev_b32_e32 v54, 2, v54                              // 0000002CC22C: 306C6C82
	v_and_b32_e32 v55, 0x3fc, v55                              // 0000002CC230: 366E6EFF 000003FC
	v_and_b32_e32 v56, 0x3fc, v56                              // 0000002CC238: 367070FF 000003FC
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000002CC240: 361010FF 000003FC
	v_and_b32_e32 v64, 0x3fc, v64                              // 0000002CC248: 368080FF 000003FC
	v_and_b32_e32 v65, 0x3fc, v65                              // 0000002CC250: 368282FF 000003FC
	v_and_b32_e32 v11, 0x3fc, v11                              // 0000002CC258: 361616FF 000003FC
	v_lshlrev_b32_e32 v66, 2, v66                              // 0000002CC260: 30848482
	v_and_b32_e32 v67, 0x3fc, v67                              // 0000002CC264: 368686FF 000003FC
	v_and_b32_e32 v68, 0x3fc, v68                              // 0000002CC26C: 368888FF 000003FC
	v_and_b32_e32 v12, 0x3fc, v12                              // 0000002CC274: 361818FF 000003FC
	v_and_b32_e32 v76, 0x3fc, v76                              // 0000002CC27C: 369898FF 000003FC
	v_and_b32_e32 v77, 0x3fc, v77                              // 0000002CC284: 369A9AFF 000003FC
	v_and_b32_e32 v15, 0x3fc, v15                              // 0000002CC28C: 361E1EFF 000003FC
	v_lshlrev_b32_e32 v78, 2, v78                              // 0000002CC294: 309C9C82
	v_and_b32_e32 v79, 0x3fc, v79                              // 0000002CC298: 369E9EFF 000003FC
	v_and_b32_e32 v80, 0x3fc, v80                              // 0000002CC2A0: 36A0A0FF 000003FC
	v_and_b32_e32 v16, 0x3fc, v16                              // 0000002CC2A8: 362020FF 000003FC
	ds_load_b32 v63, v63                                       // 0000002CC2B0: D8D80000 3F00003F
	ds_load_b32 v75, v75                                       // 0000002CC2B8: D8D80000 4B00004B
	ds_load_b32 v51, v51                                       // 0000002CC2C0: D8D80000 33000033
	ds_load_b32 v52, v52                                       // 0000002CC2C8: D8D80000 34000034
	ds_load_b32 v53, v53                                       // 0000002CC2D0: D8D80000 35000035
	ds_load_b32 v7, v7                                         // 0000002CC2D8: D8D80000 07000007
	ds_load_b32 v54, v54                                       // 0000002CC2E0: D8D80000 36000036
	ds_load_b32 v55, v55                                       // 0000002CC2E8: D8D80000 37000037
	ds_load_b32 v56, v56                                       // 0000002CC2F0: D8D80000 38000038
	ds_load_b32 v8, v8                                         // 0000002CC2F8: D8D80000 08000008
	ds_load_b32 v64, v64                                       // 0000002CC300: D8D80000 40000040
	ds_load_b32 v76, v76                                       // 0000002CC308: D8D80000 4C00004C
	ds_load_b32 v77, v77                                       // 0000002CC310: D8D80000 4D00004D
	ds_load_b32 v65, v65                                       // 0000002CC318: D8D80000 41000041
	ds_load_b32 v11, v11                                       // 0000002CC320: D8D80000 0B00000B
	ds_load_b32 v66, v66                                       // 0000002CC328: D8D80000 42000042
	ds_load_b32 v67, v67                                       // 0000002CC330: D8D80000 43000043
	ds_load_b32 v68, v68                                       // 0000002CC338: D8D80000 44000044
	ds_load_b32 v12, v12                                       // 0000002CC340: D8D80000 0C00000C
	ds_load_b32 v15, v15                                       // 0000002CC348: D8D80000 0F00000F
	ds_load_b32 v78, v78                                       // 0000002CC350: D8D80000 4E00004E
	ds_load_b32 v79, v79                                       // 0000002CC358: D8D80000 4F00004F
	ds_load_b32 v80, v80                                       // 0000002CC360: D8D80000 50000050
	ds_load_b32 v16, v16                                       // 0000002CC368: D8D80000 10000010
	s_waitcnt lgkmcnt(39)                                      // 0000002CC370: BF89FE77
	v_dot2_f32_bf16 v39, v19, v39, 0                           // 0000002CC374: CC1A4027 1A024F13
	s_waitcnt lgkmcnt(21)                                      // 0000002CC37C: BF89FD57
	v_dot2_f32_bf16 v51, v19, v51, 0                           // 0000002CC380: CC1A4033 1A026713
	v_dot2_f32_bf16 v63, v19, v63, 0                           // 0000002CC388: CC1A403F 1A027F13
	v_dot2_f32_bf16 v19, v19, v75, 0                           // 0000002CC390: CC1A4013 1A029713
	v_and_b32_e32 v81, 0xff, v17                               // 0000002CC398: 36A222FF 000000FF
	v_dot2_f32_bf16 v39, v20, v40, v39                         // 0000002CC3A0: CC1A4027 1C9E5114
	s_waitcnt lgkmcnt(20)                                      // 0000002CC3A8: BF89FD47
	v_dot2_f32_bf16 v40, v20, v52, v51                         // 0000002CC3AC: CC1A4028 1CCE6914
	s_waitcnt lgkmcnt(13)                                      // 0000002CC3B4: BF89FCD7
	v_dot2_f32_bf16 v51, v20, v64, v63                         // 0000002CC3B8: CC1A4033 1CFE8114
	s_waitcnt lgkmcnt(12)                                      // 0000002CC3C0: BF89FCC7
	v_dot2_f32_bf16 v19, v20, v76, v19                         // 0000002CC3C4: CC1A4013 1C4E9914
	v_lshrrev_b32_e32 v82, 6, v17                              // 0000002CC3CC: 32A42286
	v_dot2_f32_bf16 v20, v21, v41, v39                         // 0000002CC3D0: CC1A4014 1C9E5315
	v_dot2_f32_bf16 v39, v21, v53, v40                         // 0000002CC3D8: CC1A4027 1CA26B15
	s_waitcnt lgkmcnt(10)                                      // 0000002CC3E0: BF89FCA7
	v_dot2_f32_bf16 v40, v21, v65, v51                         // 0000002CC3E4: CC1A4028 1CCE8315
	v_dot2_f32_bf16 v19, v21, v77, v19                         // 0000002CC3EC: CC1A4013 1C4E9B15
	v_lshlrev_b32_e32 v81, 2, v81                              // 0000002CC3F4: 30A2A282
	v_dot2_f32_bf16 v3, v22, v3, v20                           // 0000002CC3F8: CC1A4003 1C520716
	v_dot2_f32_bf16 v7, v22, v7, v39                           // 0000002CC400: CC1A4007 1C9E0F16
	s_waitcnt lgkmcnt(9)                                       // 0000002CC408: BF89FC97
	v_dot2_f32_bf16 v11, v22, v11, v40                         // 0000002CC40C: CC1A400B 1CA21716
	s_waitcnt lgkmcnt(4)                                       // 0000002CC414: BF89FC47
	v_dot2_f32_bf16 v15, v22, v15, v19                         // 0000002CC418: CC1A400F 1C4E1F16
	v_and_b32_e32 v57, 0xff, v9                                // 0000002CC420: 367212FF 000000FF
	v_and_b32_e32 v69, 0xff, v13                               // 0000002CC428: 368A1AFF 000000FF
	v_lshrrev_b32_e32 v58, 6, v9                               // 0000002CC430: 32741286
	v_lshrrev_b32_e32 v70, 6, v13                              // 0000002CC434: 328C1A86
	v_lshrrev_b32_e32 v59, 14, v9                              // 0000002CC438: 3276128E
	v_lshrrev_b32_e32 v71, 14, v13                             // 0000002CC43C: 328E1A8E
	v_lshrrev_b32_e32 v9, 22, v9                               // 0000002CC440: 32121296
	v_lshrrev_b32_e32 v13, 22, v13                             // 0000002CC444: 321A1A96
	v_lshrrev_b32_e32 v83, 14, v17                             // 0000002CC448: 32A6228E
	v_and_b32_e32 v82, 0x3fc, v82                              // 0000002CC44C: 36A4A4FF 000003FC
	v_dot2_f32_bf16 v3, v23, v42, v3                           // 0000002CC454: CC1A4003 1C0E5517
	v_dot2_f32_bf16 v7, v23, v54, v7                           // 0000002CC45C: CC1A4007 1C1E6D17
	v_dot2_f32_bf16 v11, v23, v66, v11                         // 0000002CC464: CC1A400B 1C2E8517
	s_waitcnt lgkmcnt(3)                                       // 0000002CC46C: BF89FC37
	v_dot2_f32_bf16 v15, v23, v78, v15                         // 0000002CC470: CC1A400F 1C3E9D17
	ds_load_b32 v23, v81                                       // 0000002CC478: D8D80000 17000051
	v_and_b32_e32 v60, 0xff, v10                               // 0000002CC480: 367814FF 000000FF
	v_lshrrev_b32_e32 v61, 6, v10                              // 0000002CC488: 327A1486
	v_lshrrev_b32_e32 v62, 14, v10                             // 0000002CC48C: 327C148E
	v_lshrrev_b32_e32 v10, 22, v10                             // 0000002CC490: 32141496
	v_and_b32_e32 v72, 0xff, v14                               // 0000002CC494: 36901CFF 000000FF
	v_lshrrev_b32_e32 v73, 6, v14                              // 0000002CC49C: 32921C86
	v_lshrrev_b32_e32 v74, 14, v14                             // 0000002CC4A0: 32941C8E
	v_lshrrev_b32_e32 v14, 22, v14                             // 0000002CC4A4: 321C1C96
	v_lshlrev_b32_e32 v57, 2, v57                              // 0000002CC4A8: 30727282
	v_lshlrev_b32_e32 v69, 2, v69                              // 0000002CC4AC: 308A8A82
	v_and_b32_e32 v58, 0x3fc, v58                              // 0000002CC4B0: 367474FF 000003FC
	v_and_b32_e32 v70, 0x3fc, v70                              // 0000002CC4B8: 368C8CFF 000003FC
	v_and_b32_e32 v59, 0x3fc, v59                              // 0000002CC4C0: 367676FF 000003FC
	v_and_b32_e32 v71, 0x3fc, v71                              // 0000002CC4C8: 368E8EFF 000003FC
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000002CC4D0: 361212FF 000003FC
	v_and_b32_e32 v13, 0x3fc, v13                              // 0000002CC4D8: 361A1AFF 000003FC
	v_and_b32_e32 v83, 0x3fc, v83                              // 0000002CC4E0: 36A6A6FF 000003FC
	v_dot2_f32_bf16 v3, v24, v43, v3                           // 0000002CC4E8: CC1A4003 1C0E5718
	v_dot2_f32_bf16 v7, v24, v55, v7                           // 0000002CC4F0: CC1A4007 1C1E6F18
	v_dot2_f32_bf16 v11, v24, v67, v11                         // 0000002CC4F8: CC1A400B 1C2E8718
	s_waitcnt lgkmcnt(3)                                       // 0000002CC500: BF89FC37
	v_dot2_f32_bf16 v15, v24, v79, v15                         // 0000002CC504: CC1A400F 1C3E9F18
	ds_load_b32 v24, v82                                       // 0000002CC50C: D8D80000 18000052
	v_lshlrev_b32_e32 v60, 2, v60                              // 0000002CC514: 30787882
	v_and_b32_e32 v10, 0x3fc, v10                              // 0000002CC518: 361414FF 000003FC
	v_lshlrev_b32_e32 v72, 2, v72                              // 0000002CC520: 30909082
	v_and_b32_e32 v14, 0x3fc, v14                              // 0000002CC524: 361C1CFF 000003FC
	v_and_b32_e32 v61, 0x3fc, v61                              // 0000002CC52C: 367A7AFF 000003FC
	v_and_b32_e32 v62, 0x3fc, v62                              // 0000002CC534: 367C7CFF 000003FC
	v_and_b32_e32 v73, 0x3fc, v73                              // 0000002CC53C: 369292FF 000003FC
	v_and_b32_e32 v74, 0x3fc, v74                              // 0000002CC544: 369494FF 000003FC
	ds_load_b32 v21, v57                                       // 0000002CC54C: D8D80000 15000039
	ds_load_b32 v41, v58                                       // 0000002CC554: D8D80000 2900003A
	ds_load_b32 v51, v59                                       // 0000002CC55C: D8D80000 3300003B
	ds_load_b32 v9, v9                                         // 0000002CC564: D8D80000 09000009
	ds_load_b32 v52, v60                                       // 0000002CC56C: D8D80000 3400003C
	ds_load_b32 v53, v61                                       // 0000002CC574: D8D80000 3500003D
	ds_load_b32 v57, v62                                       // 0000002CC57C: D8D80000 3900003E
	ds_load_b32 v10, v10                                       // 0000002CC584: D8D80000 0A00000A
	ds_load_b32 v19, v69                                       // 0000002CC58C: D8D80000 13000045
	ds_load_b32 v20, v70                                       // 0000002CC594: D8D80000 14000046
	ds_load_b32 v22, v71                                       // 0000002CC59C: D8D80000 16000047
	ds_load_b32 v13, v13                                       // 0000002CC5A4: D8D80000 0D00000D
	ds_load_b32 v39, v72                                       // 0000002CC5AC: D8D80000 27000048
	ds_load_b32 v40, v73                                       // 0000002CC5B4: D8D80000 28000049
	ds_load_b32 v58, v74                                       // 0000002CC5BC: D8D80000 3A00004A
	ds_load_b32 v14, v14                                       // 0000002CC5C4: D8D80000 0E00000E
	v_lshrrev_b32_e32 v17, 22, v17                             // 0000002CC5CC: 32222296
	v_and_b32_e32 v84, 0xff, v18                               // 0000002CC5D0: 36A824FF 000000FF
	v_dot2_f32_bf16 v3, v25, v44, v3                           // 0000002CC5D8: CC1A4003 1C0E5919
	v_dot2_f32_bf16 v7, v25, v56, v7                           // 0000002CC5E0: CC1A4007 1C1E7119
	v_dot2_f32_bf16 v11, v25, v68, v11                         // 0000002CC5E8: CC1A400B 1C2E8919
	s_waitcnt lgkmcnt(19)                                      // 0000002CC5F0: BF89FD37
	v_dot2_f32_bf16 v15, v25, v80, v15                         // 0000002CC5F4: CC1A400F 1C3EA119
	ds_load_b32 v25, v83                                       // 0000002CC5FC: D8D80000 19000053
	v_lshrrev_b32_e32 v85, 6, v18                              // 0000002CC604: 32AA2486
	v_lshrrev_b32_e32 v86, 14, v18                             // 0000002CC608: 32AC248E
	v_lshrrev_b32_e32 v18, 22, v18                             // 0000002CC60C: 32242496
	v_and_b32_e32 v17, 0x3fc, v17                              // 0000002CC610: 362222FF 000003FC
	v_lshlrev_b32_e32 v84, 2, v84                              // 0000002CC618: 30A8A882
	v_dot2_f32_bf16 v3, v26, v4, v3                            // 0000002CC61C: CC1A4003 1C0E091A
	v_dot2_f32_bf16 v4, v26, v8, v7                            // 0000002CC624: CC1A4004 1C1E111A
	v_dot2_f32_bf16 v7, v26, v12, v11                          // 0000002CC62C: CC1A4007 1C2E191A
	s_waitcnt lgkmcnt(19)                                      // 0000002CC634: BF89FD37
	v_dot2_f32_bf16 v8, v26, v16, v15                          // 0000002CC638: CC1A4008 1C3E211A
	v_and_b32_e32 v85, 0x3fc, v85                              // 0000002CC640: 36AAAAFF 000003FC
	v_and_b32_e32 v75, 0x3fc, v86                              // 0000002CC648: 3696ACFF 000003FC
	v_and_b32_e32 v18, 0x3fc, v18                              // 0000002CC650: 362424FF 000003FC
	ds_load_b32 v11, v17                                       // 0000002CC658: D8D80000 0B000011
	ds_load_b32 v12, v84                                       // 0000002CC660: D8D80000 0C000054
	ds_load_b32 v15, v85                                       // 0000002CC668: D8D80000 0F000055
	ds_load_b32 v16, v75                                       // 0000002CC670: D8D80000 1000004B
	ds_load_b32 v17, v18                                       // 0000002CC678: D8D80000 11000012
	v_dot2_f32_bf16 v3, v27, v45, v3                           // 0000002CC680: CC1A4003 1C0E5B1B
	s_waitcnt lgkmcnt(21)                                      // 0000002CC688: BF89FD57
	v_dot2_f32_bf16 v4, v27, v21, v4                           // 0000002CC68C: CC1A4004 1C122B1B
	s_waitcnt lgkmcnt(13)                                      // 0000002CC694: BF89FCD7
	v_dot2_f32_bf16 v7, v27, v19, v7                           // 0000002CC698: CC1A4007 1C1E271B
	v_dot2_f32_bf16 v8, v27, v23, v8                           // 0000002CC6A0: CC1A4008 1C222F1B
	v_dot2_f32_bf16 v3, v28, v46, v3                           // 0000002CC6A8: CC1A4003 1C0E5D1C
	v_dot2_f32_bf16 v4, v28, v41, v4                           // 0000002CC6B0: CC1A4004 1C12531C
	s_waitcnt lgkmcnt(12)                                      // 0000002CC6B8: BF89FCC7
	v_dot2_f32_bf16 v7, v28, v20, v7                           // 0000002CC6BC: CC1A4007 1C1E291C
	v_dot2_f32_bf16 v8, v28, v24, v8                           // 0000002CC6C4: CC1A4008 1C22311C
	v_dot2_f32_bf16 v3, v29, v47, v3                           // 0000002CC6CC: CC1A4003 1C0E5F1D
	v_dot2_f32_bf16 v4, v29, v51, v4                           // 0000002CC6D4: CC1A4004 1C12671D
	s_waitcnt lgkmcnt(11)                                      // 0000002CC6DC: BF89FCB7
	v_dot2_f32_bf16 v7, v29, v22, v7                           // 0000002CC6E0: CC1A4007 1C1E2D1D
	s_waitcnt lgkmcnt(5)                                       // 0000002CC6E8: BF89FC57
	v_dot2_f32_bf16 v8, v29, v25, v8                           // 0000002CC6EC: CC1A4008 1C22331D
	v_dot2_f32_bf16 v3, v30, v5, v3                            // 0000002CC6F4: CC1A4003 1C0E0B1E
	v_dot2_f32_bf16 v4, v30, v9, v4                            // 0000002CC6FC: CC1A4004 1C12131E
	v_dot2_f32_bf16 v5, v30, v13, v7                           // 0000002CC704: CC1A4005 1C1E1B1E
	s_waitcnt lgkmcnt(4)                                       // 0000002CC70C: BF89FC47
	v_dot2_f32_bf16 v7, v30, v11, v8                           // 0000002CC710: CC1A4007 1C22171E
	s_waitcnt vmcnt(4)                                         // 0000002CC718: BF8913F7
	v_dot2_f32_bf16 v3, v31, v48, v3                           // 0000002CC71C: CC1A4003 1C0E611F
	v_dot2_f32_bf16 v4, v31, v52, v4                           // 0000002CC724: CC1A4004 1C12691F
	v_dot2_f32_bf16 v5, v31, v39, v5                           // 0000002CC72C: CC1A4005 1C164F1F
	s_waitcnt lgkmcnt(3)                                       // 0000002CC734: BF89FC37
	v_dot2_f32_bf16 v7, v31, v12, v7                           // 0000002CC738: CC1A4007 1C1E191F
	v_dot2_f32_bf16 v3, v32, v49, v3                           // 0000002CC740: CC1A4003 1C0E6320
	v_dot2_f32_bf16 v4, v32, v53, v4                           // 0000002CC748: CC1A4004 1C126B20
	v_dot2_f32_bf16 v5, v32, v40, v5                           // 0000002CC750: CC1A4005 1C165120
	s_waitcnt lgkmcnt(2)                                       // 0000002CC758: BF89FC27
	v_dot2_f32_bf16 v7, v32, v15, v7                           // 0000002CC75C: CC1A4007 1C1E1F20
	v_dot2_f32_bf16 v3, v33, v50, v3                           // 0000002CC764: CC1A4003 1C0E6521
	v_dot2_f32_bf16 v4, v33, v57, v4                           // 0000002CC76C: CC1A4004 1C127321
	v_dot2_f32_bf16 v5, v33, v58, v5                           // 0000002CC774: CC1A4005 1C167521
	s_waitcnt lgkmcnt(1)                                       // 0000002CC77C: BF89FC17
	v_dot2_f32_bf16 v7, v33, v16, v7                           // 0000002CC780: CC1A4007 1C1E2121
	v_dot2_f32_bf16 v3, v34, v6, v3                            // 0000002CC788: CC1A4003 1C0E0D22
	v_dot2_f32_bf16 v4, v34, v10, v4                           // 0000002CC790: CC1A4004 1C121522
	v_dot2_f32_bf16 v5, v34, v14, v5                           // 0000002CC798: CC1A4005 1C161D22
	s_waitcnt lgkmcnt(0)                                       // 0000002CC7A0: BF89FC07
	v_dot2_f32_bf16 v6, v34, v17, v7                           // 0000002CC7A4: CC1A4006 1C1E2322
	s_waitcnt vmcnt(3)                                         // 0000002CC7AC: BF890FF7
	v_fma_mix_f32 v3, v35, v3, 0 op_sel_hi:[1,0,0]             // 0000002CC7B0: CC200003 0A020723
	s_waitcnt vmcnt(2)                                         // 0000002CC7B8: BF890BF7
	v_fma_mix_f32 v4, v36, v4, 0 op_sel_hi:[1,0,0]             // 0000002CC7BC: CC200004 0A020924
	s_waitcnt vmcnt(1)                                         // 0000002CC7C4: BF8907F7
	v_fma_mix_f32 v5, v37, v5, 0 op_sel_hi:[1,0,0]             // 0000002CC7C8: CC200005 0A020B25
	s_waitcnt vmcnt(0)                                         // 0000002CC7D0: BF8903F7
	v_fma_mix_f32 v6, v38, v6, 0 op_sel_hi:[1,0,0]             // 0000002CC7D4: CC200006 0A020D26
	s_or_b32 exec_lo, exec_lo, s0                              // 0000002CC7DC: 8C7E007E
	.long 0xd71f0007                                           // 0000002CC7E0: D71F0007
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000002CC7E4: 020100C1
	s_mov_b32 s0, exec_lo                                      // 0000002CC7E8: BE80007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002CC7EC: BF870121
	v_xor_b32_e32 v8, 8, v7                                    // 0000002CC7F0: 3A100E88
	v_xor_b32_e32 v12, 4, v7                                   // 0000002CC7F4: 3A180E84
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 0000002CC7F8: 7C9810A0
	v_cndmask_b32_e32 v8, v7, v8, vcc_lo                       // 0000002CC7FC: 02101107
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002CC800: BF870113
	v_cmp_gt_u32_e32 vcc_lo, 32, v12                           // 0000002CC804: 7C9818A0
	v_lshlrev_b32_e32 v8, 2, v8                                // 0000002CC808: 30101082
	ds_bpermute_b32 v9, v8, v3                                 // 0000002CC80C: DACC0000 09000308
	s_waitcnt lgkmcnt(0)                                       // 0000002CC814: BF89FC07
	v_add_f32_e32 v3, v3, v9                                   // 0000002CC818: 06061303
	ds_bpermute_b32 v11, v8, v5                                // 0000002CC81C: DACC0000 0B000508
	ds_bpermute_b32 v10, v8, v4                                // 0000002CC824: DACC0000 0A000408
	ds_bpermute_b32 v8, v8, v6                                 // 0000002CC82C: DACC0000 08000608
	s_waitcnt lgkmcnt(2)                                       // 0000002CC834: BF89FC27
	v_dual_add_f32 v5, v5, v11 :: v_dual_cndmask_b32 v12, v7, v12// 0000002CC838: C9121705 050C1907
	s_waitcnt lgkmcnt(0)                                       // 0000002CC840: BF89FC07
	v_add_f32_e32 v6, v6, v8                                   // 0000002CC844: 060C1106
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002CC848: BF870002
	v_lshlrev_b32_e32 v12, 2, v12                              // 0000002CC84C: 30181882
	ds_bpermute_b32 v8, v12, v3                                // 0000002CC850: DACC0000 0800030C
	v_add_f32_e32 v4, v4, v10                                  // 0000002CC858: 06081504
	ds_bpermute_b32 v10, v12, v5                               // 0000002CC85C: DACC0000 0A00050C
	ds_bpermute_b32 v11, v12, v6                               // 0000002CC864: DACC0000 0B00060C
	s_waitcnt lgkmcnt(2)                                       // 0000002CC86C: BF89FC27
	v_add_f32_e32 v3, v3, v8                                   // 0000002CC870: 06061103
	ds_bpermute_b32 v9, v12, v4                                // 0000002CC874: DACC0000 0900040C
	v_xor_b32_e32 v12, 2, v7                                   // 0000002CC87C: 3A180E82
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000002CC880: BF8700D1
	v_cmp_gt_u32_e32 vcc_lo, 32, v12                           // 0000002CC884: 7C9818A0
	s_waitcnt lgkmcnt(0)                                       // 0000002CC888: BF89FC07
	v_dual_add_f32 v8, v4, v9 :: v_dual_add_f32 v9, v5, v10    // 0000002CC88C: C9081304 08081505
	v_add_f32_e32 v10, v6, v11                                 // 0000002CC894: 06141706
	v_cndmask_b32_e32 v12, v7, v12, vcc_lo                     // 0000002CC898: 02181907
	v_lshlrev_b32_e32 v12, 2, v12                              // 0000002CC89C: 30181882
	ds_bpermute_b32 v4, v12, v3                                // 0000002CC8A0: DACC0000 0400030C
	ds_bpermute_b32 v5, v12, v8                                // 0000002CC8A8: DACC0000 0500080C
	ds_bpermute_b32 v6, v12, v9                                // 0000002CC8B0: DACC0000 0600090C
	ds_bpermute_b32 v11, v12, v10                              // 0000002CC8B8: DACC0000 0B000A0C
	v_xor_b32_e32 v12, 1, v7                                   // 0000002CC8C0: 3A180E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002CC8C4: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v12                           // 0000002CC8C8: 7C9818A0
	v_cndmask_b32_e32 v7, v7, v12, vcc_lo                      // 0000002CC8CC: 020E1907
	v_lshlrev_b32_e32 v12, 2, v7                               // 0000002CC8D0: 30180E82
	s_waitcnt lgkmcnt(2)                                       // 0000002CC8D4: BF89FC27
	v_dual_add_f32 v4, v3, v4 :: v_dual_add_f32 v5, v8, v5     // 0000002CC8D8: C9080903 04040B08
	s_waitcnt lgkmcnt(0)                                       // 0000002CC8E0: BF89FC07
	v_dual_add_f32 v6, v9, v6 :: v_dual_add_f32 v7, v10, v11   // 0000002CC8E4: C9080D09 0606170A
	ds_bpermute_b32 v8, v12, v4                                // 0000002CC8EC: DACC0000 0800040C
	ds_bpermute_b32 v9, v12, v5                                // 0000002CC8F4: DACC0000 0900050C
	ds_bpermute_b32 v10, v12, v6                               // 0000002CC8FC: DACC0000 0A00060C
	ds_bpermute_b32 v11, v12, v7                               // 0000002CC904: DACC0000 0B00070C
	v_cmpx_eq_u32_e32 0, v2                                    // 0000002CC90C: 7D940480
	s_cbranch_execz 256                                        // 0000002CC910: BFA50100 <_ZN7halogen12_GLOBAL__N_17k_hcup4ILi1ELi0EEEvPKhlllPKtS5_PtPf+0xf14>
	.long 0xd73c0002                                           // 0000002CC914: D73C0002
	v_cndmask_b32_e32 v1, 1, v0, vcc_lo                        // 0000002CC918: 02020081
	s_waitcnt lgkmcnt(2)                                       // 0000002CC91C: BF89FC27
	v_dual_add_f32 v4, v4, v8 :: v_dual_add_f32 v5, v5, v9     // 0000002CC920: C9081104 04041305
	s_waitcnt lgkmcnt(0)                                       // 0000002CC928: BF89FC07
	v_dual_add_f32 v6, v6, v10 :: v_dual_add_f32 v7, v7, v11   // 0000002CC92C: C9081506 06061707
	s_cmp_eq_u64 s[18:19], 0                                   // 0000002CC934: BF108012
	.long 0xd7006a0c                                           // 0000002CC938: D7006A0C
	v_cndmask_b32_e32 v1, s14, v2, vcc_lo                      // 0000002CC93C: 0202040E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002CC940: BF8701A1
	v_add_co_ci_u32_e64 v13, null, s15, v3, vcc_lo             // 0000002CC944: D5207C0D 01AA060F
	v_bfe_u32 v9, v5, 16, 1                                    // 0000002CC94C: D6100009 02052105
	.long 0xd7006a0e                                           // 0000002CC954: D7006A0E
	v_cndmask_b32_e32 v1, 0x1000, v12, vcc_lo                  // 0000002CC958: 020218FF 00001000
	global_load_u16 v18, v[12:13], off                         // 0000002CC960: DC4A0000 127C000C
	v_add_co_ci_u32_e64 v15, null, 0, v13, vcc_lo              // 0000002CC968: D5207C0F 01AA1A80
	.long 0xd7006a10                                           // 0000002CC970: D7006A10
	v_cndmask_b32_e32 v1, 0x2000, v12, vcc_lo                  // 0000002CC974: 020218FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000002CC97C: BF8700D1
	v_add_co_ci_u32_e64 v17, null, 0, v13, vcc_lo              // 0000002CC980: D5207C11 01AA1A80
	s_clause 0x1                                               // 0000002CC988: BF850001
	global_load_u16 v14, v[14:15], off offset:1024             // 0000002CC98C: DC4A0400 0E7C000E
	global_load_u16 v15, v[16:17], off offset:2048             // 0000002CC994: DC4A0800 0F7C0010
	.long 0xd7006a0c                                           // 0000002CC99C: D7006A0C
	v_cndmask_b32_e32 v1, 0x3000, v12, vcc_lo                  // 0000002CC9A0: 020218FF 00003000
	v_add_co_ci_u32_e64 v13, null, 0, v13, vcc_lo              // 0000002CC9A8: D5207C0D 01AA1A80
	v_add3_u32 v5, v5, v9, 0x7fff                              // 0000002CC9B0: D6550005 03FE1305 00007FFF
	v_bfe_u32 v8, v4, 16, 1                                    // 0000002CC9BC: D6100008 02052104
	v_bfe_u32 v11, v7, 16, 1                                   // 0000002CC9C4: D610000B 02052107
	global_load_u16 v12, v[12:13], off offset:3072             // 0000002CC9CC: DC4A0C00 0C7C000C
	v_bfe_u32 v10, v6, 16, 1                                   // 0000002CC9D4: D610000A 02052106
	v_and_b32_e32 v5, 0xffff0000, v5                           // 0000002CC9DC: 360A0AFF FFFF0000
	v_add3_u32 v4, v4, v8, 0x7fff                              // 0000002CC9E4: D6550004 03FE1104 00007FFF
	v_add3_u32 v7, v7, v11, 0x7fff                             // 0000002CC9F0: D6550007 03FE1707 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002CC9FC: BF870214
	v_add3_u32 v6, v6, v10, 0x7fff                             // 0000002CCA00: D6550006 03FE1506 00007FFF
	v_mul_f32_e32 v5, 0xbfb8aa3b, v5                           // 0000002CCA0C: 100A0AFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002CCA14: BF870113
	v_and_b32_e32 v7, 0xffff0000, v7                           // 0000002CCA18: 360E0EFF FFFF0000
	v_exp_f32_e32 v5, v5                                       // 0000002CCA20: 7E0A4B05
	v_and_b32_e32 v4, 0xffff0000, v4                           // 0000002CCA24: 360808FF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CCA2C: BF870092
	v_mul_f32_e32 v7, 0xbfb8aa3b, v7                           // 0000002CCA30: 100E0EFF BFB8AA3B
	v_exp_f32_e32 v7, v7                                       // 0000002CCA38: 7E0E4B07
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002CCA3C: BF870196
	v_dual_add_f32 v5, 1.0, v5 :: v_dual_and_b32 v6, 0xffff0000, v6// 0000002CCA40: C9240AF2 05060CFF FFFF0000
	v_mul_f32_e32 v4, 0xbfb8aa3b, v4                           // 0000002CCA4C: 100808FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002CCA54: BF870112
	v_div_scale_f32 v9, null, v5, v5, 1.0                      // 0000002CCA58: D6FC7C09 03CA0B05
	v_exp_f32_e32 v4, v4                                       // 0000002CCA60: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_3)   // 0000002CCA64: BF870186
	v_dual_add_f32 v7, 1.0, v7 :: v_dual_mul_f32 v6, 0xbfb8aa3b, v6// 0000002CCA68: C9060EF2 07060CFF BFB8AA3B
	v_div_scale_f32 v21, s0, 1.0, v5, 1.0                      // 0000002CCA74: D6FC0015 03CA0AF2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002CCA7C: BF870113
	v_rcp_f32_e32 v16, v9                                      // 0000002CCA80: 7E205509
	v_div_scale_f32 v11, null, v7, v7, 1.0                     // 0000002CCA84: D6FC7C0B 03CA0F07
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_3)// 0000002CCA8C: BF870393
	v_exp_f32_e32 v6, v6                                       // 0000002CCA90: 7E0C4B06
	v_add_f32_e32 v4, 1.0, v4                                  // 0000002CCA94: 060808F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_3)// 0000002CCA98: BF870392
	v_rcp_f32_e32 v19, v11                                     // 0000002CCA9C: 7E26550B
	v_fma_f32 v23, -v9, v16, 1.0                               // 0000002CCAA0: D6130017 23CA2109
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_2)// 0000002CCAA8: BF870322
	v_div_scale_f32 v8, null, v4, v4, 1.0                      // 0000002CCAAC: D6FC7C08 03CA0904
	v_div_scale_f32 v20, vcc_lo, 1.0, v4, 1.0                  // 0000002CCAB4: D6FC6A14 03CA08F2
	v_add_f32_e32 v6, 1.0, v6                                  // 0000002CCABC: 060C0CF2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002CCAC0: BF870214
	v_fmac_f32_e32 v16, v23, v16                               // 0000002CCAC4: 56202117
	v_rcp_f32_e32 v13, v8                                      // 0000002CCAC8: 7E1A5508
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002CCACC: BF870196
	v_fma_f32 v26, -v11, v19, 1.0                              // 0000002CCAD0: D613001A 23CA270B
	v_div_scale_f32 v10, null, v6, v6, 1.0                     // 0000002CCAD8: D6FC7C0A 03CA0D06
	v_div_scale_f32 v25, s1, 1.0, v6, 1.0                      // 0000002CCAE0: D6FC0119 03CA0CF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000002CCAE8: BF870312
	v_rcp_f32_e32 v17, v10                                     // 0000002CCAEC: 7E22550A
	v_fma_f32 v22, -v8, v13, 1.0                               // 0000002CCAF0: D6130016 23CA1B08
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 0000002CCAF8: BF8702A1
	v_fmac_f32_e32 v13, v22, v13                               // 0000002CCAFC: 561A1B16
	v_div_scale_f32 v22, s2, 1.0, v7, 1.0                      // 0000002CCB00: D6FC0216 03CA0EF2
	v_fma_f32 v24, -v10, v17, 1.0                              // 0000002CCB08: D6130018 23CA230A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CCB10: BF870091
	v_dual_fmac_f32 v17, v24, v17 :: v_dual_mul_f32 v24, v21, v16// 0000002CCB14: C8062318 11182115
	v_dual_fmac_f32 v19, v26, v19 :: v_dual_mul_f32 v26, v25, v17// 0000002CCB1C: C806271A 131A2319
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002CCB24: BF8701A2
	v_fma_f32 v29, -v9, v24, v21                               // 0000002CCB28: D613001D 24563109
	v_mul_f32_e32 v23, v20, v13                                // 0000002CCB30: 102E1B14
	v_fma_f32 v30, -v10, v26, v25                              // 0000002CCB34: D613001E 2466350A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002CCB3C: BF870193
	v_fmac_f32_e32 v24, v29, v16                               // 0000002CCB40: 5630211D
	v_fma_f32 v28, -v8, v23, v20                               // 0000002CCB44: D613001C 24522F08
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002CCB4C: BF870112
	v_fma_f32 v9, -v9, v24, v21                                // 0000002CCB50: D6130009 24563109
	v_fmac_f32_e32 v23, v28, v13                               // 0000002CCB58: 562E1B1C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CCB5C: BF870091
	v_fma_f32 v8, -v8, v23, v20                                // 0000002CCB60: D6130008 24522F08
	v_div_fmas_f32 v8, v8, v13, v23                            // 0000002CCB68: D6370008 045E1B08
	s_mov_b32 vcc_lo, s0                                       // 0000002CCB70: BEEA0000
	v_div_fmas_f32 v9, v9, v16, v24                            // 0000002CCB74: D6370009 04622109
	s_mov_b32 vcc_lo, s1                                       // 0000002CCB7C: BEEA0001
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002CCB80: BF870112
	v_div_fixup_f32 v4, v8, v4, 1.0                            // 0000002CCB84: D6270004 03CA0908
	v_div_fixup_f32 v5, v9, v5, 1.0                            // 0000002CCB8C: D6270005 03CA0B09
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CCB94: BF870092
	v_bfe_u32 v9, v4, 16, 1                                    // 0000002CCB98: D6100009 02052104
	v_add3_u32 v4, v4, v9, 0x7fff                              // 0000002CCBA0: D6550004 03FE1304 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CCBAC: BF870091
	v_dual_mul_f32 v27, v22, v19 :: v_dual_and_b32 v4, 0xffff0000, v4// 0000002CCBB0: C8E42716 1B0408FF FFFF0000
	v_fma_f32 v31, -v11, v27, v22                              // 0000002CCBBC: D613001F 245A370B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CCBC4: BF870091
	v_dual_fmac_f32 v26, v30, v17 :: v_dual_fmac_f32 v27, v31, v19// 0000002CCBC8: C800231E 1A1A271F
	v_fma_f32 v10, -v10, v26, v25                              // 0000002CCBD0: D613000A 2466350A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002CCBD8: BF870112
	v_fma_f32 v11, -v11, v27, v22                              // 0000002CCBDC: D613000B 245A370B
	v_div_fmas_f32 v8, v10, v17, v26                           // 0000002CCBE4: D6370008 046A230A
	s_mov_b32 vcc_lo, s2                                       // 0000002CCBEC: BEEA0002
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002CCBF0: BF870112
	v_div_fmas_f32 v10, v11, v19, v27                          // 0000002CCBF4: D637000A 046E270B
	v_div_fixup_f32 v6, v8, v6, 1.0                            // 0000002CCBFC: D6270006 03CA0D08
	v_bfe_u32 v8, v5, 16, 1                                    // 0000002CCC04: D6100008 02052105
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002CCC0C: BF870193
	v_div_fixup_f32 v7, v10, v7, 1.0                           // 0000002CCC10: D6270007 03CA0F0A
	v_bfe_u32 v9, v6, 16, 1                                    // 0000002CCC18: D6100009 02052106
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002CCC20: BF870193
	v_add3_u32 v5, v5, v8, 0x7fff                              // 0000002CCC24: D6550005 03FE1105 00007FFF
	v_bfe_u32 v10, v7, 16, 1                                   // 0000002CCC30: D610000A 02052107
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002CCC38: BF870193
	v_add3_u32 v6, v6, v9, 0x7fff                              // 0000002CCC3C: D6550006 03FE1306 00007FFF
	v_and_b32_e32 v5, 0xffff0000, v5                           // 0000002CCC48: 360A0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002CCC50: BF870193
	v_add3_u32 v7, v7, v10, 0x7fff                             // 0000002CCC54: D6550007 03FE1507 00007FFF
	v_and_b32_e32 v6, 0xffff0000, v6                           // 0000002CCC60: 360C0CFF FFFF0000
	s_waitcnt vmcnt(3)                                         // 0000002CCC68: BF890FF7
	v_lshlrev_b32_e32 v8, 16, v18                              // 0000002CCC6C: 30102490
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000002CCC70: BF8700C1
	v_fma_f32 v4, v4, v8, 0                                    // 0000002CCC74: D6130004 02021104
	s_waitcnt vmcnt(2)                                         // 0000002CCC7C: BF890BF7
	v_lshlrev_b32_e32 v8, 16, v14                              // 0000002CCC80: 30101C90
	s_waitcnt vmcnt(1)                                         // 0000002CCC84: BF8907F7
	v_dual_fmac_f32 v4, v5, v8 :: v_dual_lshlrev_b32 v9, 16, v15// 0000002CCC88: C8221105 04081E90
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002CCC90: BF8700B1
	v_dual_fmac_f32 v4, v6, v9 :: v_dual_and_b32 v5, 0xffff0000, v7// 0000002CCC94: C8241306 04040EFF FFFF0000
	s_waitcnt vmcnt(0)                                         // 0000002CCCA0: BF8903F7
	v_lshlrev_b32_e32 v6, 16, v12                              // 0000002CCCA4: 300C1890
	v_fmac_f32_e32 v4, v5, v6                                  // 0000002CCCA8: 56080D05
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002CCCAC: BF870001
	v_mul_f32_e32 v4, 0x3e800000, v4                           // 0000002CCCB0: 100808FF 3E800000
	s_cbranch_scc1 9                                           // 0000002CCCB8: BFA20009 <_ZN7halogen12_GLOBAL__N_17k_hcup4ILi1ELi0EEEvPKhlllPKtS5_PtPf+0xee0>
	.long 0xd73c0000                                           // 0000002CCCBC: D73C0000
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 0000002CCCC0: 02020082
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CCCC4: BF870091
	.long 0xd7006a00                                           // 0000002CCCC8: D7006A00
	v_cndmask_b32_e32 v1, s18, v0, vcc_lo                      // 0000002CCCCC: 02020012
	v_add_co_ci_u32_e64 v1, null, s19, v1, vcc_lo              // 0000002CCCD0: D5207C01 01AA0213
	global_store_b32 v[0:1], v4, off                           // 0000002CCCD8: DC6A0000 007C0400
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002CCCE0: BF8700A1
	v_bfe_u32 v5, v4, 16, 1                                    // 0000002CCCE4: D6100005 02052104
	.long 0xd7006a00                                           // 0000002CCCEC: D7006A00
	v_cndmask_b32_e32 v1, s16, v2, vcc_lo                      // 0000002CCCF0: 02020410
	v_add_co_ci_u32_e64 v1, null, s17, v3, vcc_lo              // 0000002CCCF4: D5207C01 01AA0611
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002CCCFC: BF870003
	v_add3_u32 v2, v4, v5, 0x7fff                              // 0000002CCD00: D6550002 03FE0B04 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off                    // 0000002CCD0C: DC960000 007C0200
	s_endpgm                                                   // 0000002CCD14: BFB00000
		...

