00000000007c7800 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi1ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi1ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 0000007C7800: F4100100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 0000007C7808: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 0000007C780C: 32040082
	s_lshl_b64 s[2:3], s[2:3], 3                               // 0000007C7810: 84828302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007C7814: BF8701A9
	v_dual_mov_b32 v10, s3 :: v_dual_and_b32 v1, 15, v0        // 0000007C7818: CA240003 0A00008F
	.long 0x7f103880                                           // 0000007C7820: 7F103880
	v_and_b32_e32 v2, 60, v2                                   // 0000007C7824: 360404BC
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007C7828: BF870003
	v_dual_mov_b32 v18, 0 :: v_dual_lshlrev_b32 v1, 2, v1      // 0000007C782C: CA220080 12000282
	v_dual_mov_b32 v3, 0 :: v_dual_and_b32 v16, 31, v0         // 0000007C7834: CA240080 0310009F
	v_mov_b32_e32 v17, 0                                       // 0000007C783C: 7E220280
	s_waitcnt lgkmcnt(0)                                       // 0000007C7840: BF89FC07
	s_clause 0x1                                               // 0000007C7844: BF850001
	global_load_b32 v4, v1, s[4:5]                             // 0000007C7848: DC520000 04040001
	global_load_b32 v7, v2, s[4:5]                             // 0000007C7850: DC520000 07040002
	v_lshrrev_b32_e32 v2, 5, v0                                // 0000007C7858: 32040085
	s_add_u32 s14, s4, s14                                     // 0000007C785C: 800E0E04
	s_addc_u32 s15, s5, s15                                    // 0000007C7860: 820F0F05
	v_mov_b32_e32 v1, 0                                        // 0000007C7864: 7E020280
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007C7868: BF870002
	v_or_b32_e32 v9, s2, v2                                    // 0000007C786C: 38120402
	s_lshr_b32 s2, s11, 31                                     // 0000007C7870: 85029F0B
	v_mov_b32_e32 v2, 0                                        // 0000007C7874: 7E040280
	s_add_u32 s20, s10, s2                                     // 0000007C7878: 8014020A
	s_addc_u32 s21, s11, 0                                     // 0000007C787C: 8215800B
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[9:10]                 // 0000007C7880: 7CA8120C
	s_ashr_i32 s22, s11, 31                                    // 0000007C7884: 86169F0B
	v_cndmask_b32_e32 v11, 0, v9, vcc_lo                       // 0000007C7888: 02161280
	v_cndmask_b32_e64 v14, 0, s3, vcc_lo                       // 0000007C788C: D501000E 01A80680
	s_ashr_i64 s[2:3], s[20:21], 1                             // 0000007C7894: 86828114
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000007C7898: BF870481
	.long 0xd72c0014                                           // 0000007C789C: D72C0014
	v_cndmask_b32_e32 v0, v14, v2, vcc_lo                      // 0000007C78A0: 0200050E
	.long 0xd72c000e                                           // 0000007C78A4: D72C000E
	v_cndmask_b32_e32 v1, s18, v14, vcc_lo                     // 0000007C78A8: 02021C12
	s_waitcnt vmcnt(1)                                         // 0000007C78AC: BF8907F7
	v_bfe_u32 v12, v4, 16, 1                                   // 0000007C78B0: D610000C 02052104
	s_waitcnt vmcnt(0)                                         // 0000007C78B8: BF8903F7
	v_bfe_u32 v19, v7, 16, 1                                   // 0000007C78BC: D6100013 02052107
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007C78C4: BF870112
	v_add3_u32 v4, v4, v12, 0x7fff                             // 0000007C78C8: D6550004 03FE1904 00007FFF
	v_add3_u32 v7, v7, v19, 0x7fff                             // 0000007C78D4: D6550007 03FE2707 00007FFF
	v_lshlrev_b32_e32 v19, 2, v0                               // 0000007C78E0: 30260082
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007C78E4: BF870003
	.long 0x7e103984                                           // 0000007C78E8: 7E103984
	v_mov_b32_e32 v4, 0                                        // 0000007C78EC: 7E080280
	.long 0xd72c000d                                           // 0000007C78F0: D72C000D
	v_cndmask_b32_e32 v1, s19, v11, vcc_lo                     // 0000007C78F4: 02021613
	v_mad_u64_u32 v[5:6], null, s18, v11, 0                    // 0000007C78F8: D6FE7C05 02021612
	.long 0xd72c000f                                           // 0000007C7900: D72C000F
	v_cndmask_b32_e32 v0, v11, v3, vcc_lo                      // 0000007C7904: 0200070B
	v_mad_u64_u32 v[11:12], null, v11, s2, s[14:15]            // 0000007C7908: D6FE7C0B 0038050B
	s_lshr_b32 s19, s22, 27                                    // 0000007C7910: 85139B16
	v_and_or_b32 v7, 0xffff0000, v7, v8                        // 0000007C7914: D6570007 04220EFF FFFF0000
	s_add_u32 s14, s10, s19                                    // 0000007C7920: 800E130A
	s_addc_u32 s15, s11, 0                                     // 0000007C7924: 820F800B
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000007C7928: BF870009
	s_lshr_b64 s[14:15], s[14:15], 5                           // 0000007C792C: 858E850E
	v_add3_u32 v6, v6, v14, v13                                // 0000007C7930: D6550006 04361D06
	.long 0xd4440002                                           // 0000007C7938: D4440002
	v_cndmask_b32_e32 v1, s14, v16, vcc_lo                     // 0000007C793C: 0202200E
	v_add3_u32 v0, v20, v12, v15                               // 0000007C7940: D6550000 043E1914
	ds_store_b32 v19, v7                                       // 0000007C7948: D8340000 00000713
	s_waitcnt lgkmcnt(0)                                       // 0000007C7950: BF89FC07
	s_barrier                                                  // 0000007C7954: BFBD0000
	buffer_gl0_inv                                             // 0000007C7958: E0AC0000 00000000
	s_and_saveexec_b32 s15, s2                                 // 0000007C7960: BE8F2002
	s_cbranch_execz 26                                         // 0000007C7964: BFA5001A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi1ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x1d0>
	s_add_u32 s3, s4, s16                                      // 0000007C7968: 80031004
	s_addc_u32 s18, s5, s17                                    // 0000007C796C: 82121105
	v_lshlrev_b32_e32 v1, 1, v16                               // 0000007C7970: 30022081
	.long 0xd7000302                                           // 0000007C7974: D7000302
	v_cndmask_b32_e32 v1, s3, v5, vcc_lo                       // 0000007C7978: 02020A03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007C797C: BF8701A1
	v_add_co_ci_u32_e64 v3, null, s18, v6, s3                  // 0000007C7980: D5207C03 000E0C12
	v_lshlrev_b32_e32 v4, 4, v16                               // 0000007C7988: 30082084
	.long 0xd7000301                                           // 0000007C798C: D7000301
	v_cndmask_b32_e32 v1, v2, v1, vcc_lo                       // 0000007C7990: 02020302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007C7994: BF870191
	v_add_co_ci_u32_e64 v2, null, 0, v3, s3                    // 0000007C7998: D5207C02 000E0680
	.long 0xd7000303                                           // 0000007C79A0: D7000303
	v_cndmask_b32_e32 v1, v11, v4, vcc_lo                      // 0000007C79A4: 0202090B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007C79A8: BF870001
	v_add_co_ci_u32_e64 v4, null, 0, v0, s3                    // 0000007C79AC: D5207C04 000E0080
	s_clause 0x1                                               // 0000007C79B4: BF850001
	global_load_d16_b16 v7, v[1:2], off                        // 0000007C79B8: DC820000 077C0001
	global_load_b128 v[1:4], v[3:4], off                       // 0000007C79C0: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 0000007C79C8: BF8907F7
	v_cvt_f32_f16_e32 v18, v7                                  // 0000007C79CC: 7E241707
	s_or_b32 exec_lo, exec_lo, s15                             // 0000007C79D0: 8C7E0F7E
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v20, 0             // 0000007C79D4: CA100080 13140080
	s_and_saveexec_b32 s15, s2                                 // 0000007C79DC: BE8F2002
	s_cbranch_execz 331                                        // 0000007C79E0: BFA5014B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi1ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x710>
	v_dual_mov_b32 v22, v16 :: v_dual_lshlrev_b32 v7, 1, v16   // 0000007C79E4: CA220110 16062081
	.long 0xd7000205                                           // 0000007C79EC: D7000205
	v_cndmask_b32_e32 v1, s16, v5, vcc_lo                      // 0000007C79F0: 02020A10
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007C79F4: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s17, v6, s2                  // 0000007C79F8: D5207C06 000A0C11
	v_dual_mov_b32 v13, 0 :: v_dual_lshlrev_b32 v12, 5, v16    // 0000007C7A00: CA220080 0D0C2085
	.long 0xd7000205                                           // 0000007C7A08: D7000205
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 0000007C7A0C: 02020F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007C7A10: BF8701A1
	v_add_co_ci_u32_e64 v6, null, 0, v6, s2                    // 0000007C7A14: D5207C06 000A0C80
	v_lshl_or_b32 v21, v16, 4, 0x200                           // 0000007C7A1C: D6560015 03FD0910 00000200
	.long 0xd7000205                                           // 0000007C7A28: D7000205
	v_cndmask_b32_e32 v1, s4, v5, vcc_lo                       // 0000007C7A2C: 02020A04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007C7A30: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s5, v6, s2                   // 0000007C7A34: D5207C06 000A0C05
	v_dual_mov_b32 v20, v13 :: v_dual_mov_b32 v23, v18         // 0000007C7A3C: CA10010D 14160112
	.long 0xd700020e                                           // 0000007C7A44: D700020E
	v_cndmask_b32_e32 v0, v5, v192, vcc_lo                     // 0000007C7A48: 02018105
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007C7A4C: BF870001
	v_add_co_ci_u32_e64 v15, null, 0, v6, s2                   // 0000007C7A50: D5207C0F 000A0C80
	v_mov_b32_e32 v19, v13                                     // 0000007C7A58: 7E26030D
	v_mov_b32_e32 v17, v13                                     // 0000007C7A5C: 7E22030D
	s_lshl_b64 s[4:5], s[10:11], 2                             // 0000007C7A60: 8484820A
	s_mov_b32 s16, 0                                           // 0000007C7A64: BE900080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 0000007C7A68: 848A810A
	s_branch 270                                               // 0000007C7A6C: BFA0010E <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi1ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x6a8>
	s_or_b32 exec_lo, exec_lo, s17                             // 0000007C7A70: 8C7E117E
	.long 0xd73c0018                                           // 0000007C7A74: D73C0018
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 0000007C7A78: 02021881
	v_and_b32_e32 v72, 0xff, v1                                // 0000007C7A7C: 369002FF 000000FF
	v_lshrrev_b32_e32 v73, 6, v1                               // 0000007C7A84: 32920286
	v_lshrrev_b32_e32 v74, 14, v1                              // 0000007C7A88: 3294028E
	v_lshrrev_b32_e32 v1, 22, v1                               // 0000007C7A8C: 32020296
	v_and_b32_e32 v75, 0xff, v2                                // 0000007C7A90: 369604FF 000000FF
	.long 0xd700033c                                           // 0000007C7A98: D700033C
	v_cndmask_b32_e32 v1, s6, v24, vcc_lo                      // 0000007C7A9C: 02023006
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007C7AA0: BF8701A1
	v_add_co_ci_u32_e64 v61, null, s7, v25, s3                 // 0000007C7AA4: D5207C3D 000E3207
	v_lshlrev_b32_e32 v72, 2, v72                              // 0000007C7AAC: 30909082
	.long 0xd7000340                                           // 0000007C7AB0: D7000340
	v_cndmask_b32_e32 v0, v60, v10, vcc_lo                     // 0000007C7AB4: 0200153C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007C7AB8: BF8700A1
	v_add_co_ci_u32_e64 v65, null, s11, v61, s3                // 0000007C7ABC: D5207C41 000E7A0B
	.long 0xd7000344                                           // 0000007C7AC4: D7000344
	v_cndmask_b32_e32 v0, v60, v4, vcc_lo                      // 0000007C7AC8: 0200093C
	v_add_co_ci_u32_e64 v69, null, s5, v61, s3                 // 0000007C7ACC: D5207C45 000E7A05
	s_clause 0xb                                               // 0000007C7AD4: BF85000B
	global_load_b128 v[24:27], v[60:61], off                   // 0000007C7AD8: DC5E0000 187C003C
	global_load_b128 v[28:31], v[64:65], off                   // 0000007C7AE0: DC5E0000 1C7C0040
	global_load_b128 v[32:35], v[68:69], off                   // 0000007C7AE8: DC5E0000 207C0044
	global_load_b128 v[36:39], v[60:61], off offset:16         // 0000007C7AF0: DC5E0010 247C003C
	global_load_b128 v[40:43], v[64:65], off offset:16         // 0000007C7AF8: DC5E0010 287C0040
	global_load_b128 v[44:47], v[68:69], off offset:16         // 0000007C7B00: DC5E0010 2C7C0044
	global_load_b128 v[48:51], v[60:61], off offset:32         // 0000007C7B08: DC5E0020 307C003C
	global_load_b128 v[52:55], v[64:65], off offset:32         // 0000007C7B10: DC5E0020 347C0040
	global_load_b128 v[56:59], v[68:69], off offset:32         // 0000007C7B18: DC5E0020 387C0044
	global_load_b128 v[60:63], v[60:61], off offset:48         // 0000007C7B20: DC5E0030 3C7C003C
	global_load_b128 v[64:67], v[64:65], off offset:48         // 0000007C7B28: DC5E0030 407C0040
	global_load_b128 v[68:71], v[68:69], off offset:48         // 0000007C7B30: DC5E0030 447C0044
	v_and_b32_e32 v73, 0x3fc, v73                              // 0000007C7B38: 369292FF 000003FC
	ds_load_b32 v72, v72                                       // 0000007C7B40: D8D80000 48000048
	v_and_b32_e32 v74, 0x3fc, v74                              // 0000007C7B48: 369494FF 000003FC
	v_lshrrev_b32_e32 v76, 6, v2                               // 0000007C7B50: 32980486
	v_lshrrev_b32_e32 v77, 14, v2                              // 0000007C7B54: 329A048E
	ds_load_b32 v73, v73                                       // 0000007C7B58: D8D80000 49000049
	v_lshrrev_b32_e32 v2, 22, v2                               // 0000007C7B60: 32040496
	ds_load_b32 v74, v74                                       // 0000007C7B64: D8D80000 4A00004A
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000007C7B6C: 360202FF 000003FC
	v_lshlrev_b32_e32 v75, 2, v75                              // 0000007C7B74: 30969682
	v_and_b32_e32 v76, 0x3fc, v76                              // 0000007C7B78: 369898FF 000003FC
	v_and_b32_e32 v77, 0x3fc, v77                              // 0000007C7B80: 369A9AFF 000003FC
	v_and_b32_e32 v2, 0x3fc, v2                                // 0000007C7B88: 360404FF 000003FC
	ds_load_b32 v1, v1                                         // 0000007C7B90: D8D80000 01000001
	ds_load_b32 v75, v75                                       // 0000007C7B98: D8D80000 4B00004B
	ds_load_b32 v76, v76                                       // 0000007C7BA0: D8D80000 4C00004C
	ds_load_b32 v77, v77                                       // 0000007C7BA8: D8D80000 4D00004D
	ds_load_b32 v2, v2                                         // 0000007C7BB0: D8D80000 02000002
	v_and_b32_e32 v78, 0xff, v3                                // 0000007C7BB8: 369C06FF 000000FF
	v_lshrrev_b32_e32 v79, 6, v3                               // 0000007C7BC0: 329E0686
	v_lshrrev_b32_e32 v80, 14, v3                              // 0000007C7BC4: 32A0068E
	v_lshrrev_b32_e32 v3, 22, v3                               // 0000007C7BC8: 32060696
	v_and_b32_e32 v81, 0xff, v4                                // 0000007C7BCC: 36A208FF 000000FF
	v_lshrrev_b32_e32 v82, 14, v4                              // 0000007C7BD4: 32A4088E
	s_and_b32 s3, exec_lo, s2                                  // 0000007C7BD8: 8B03027E
	.long 0xd700020e                                           // 0000007C7BDC: D700020E
	v_cndmask_b32_e32 v0, v14, v192, vcc_lo                    // 0000007C7BE0: 0201810E
	v_and_b32_e32 v3, 0x3fc, v3                                // 0000007C7BE4: 360606FF 000003FC
	v_add_nc_u32_e32 v12, 0x400, v12                           // 0000007C7BEC: 4A1818FF 00000400
	v_add_nc_u32_e32 v21, 0x200, v21                           // 0000007C7BF4: 4A2A2AFF 00000200
	v_add_co_ci_u32_e64 v15, null, 0, v15, s2                  // 0000007C7BFC: D5207C0F 000A1E80
	s_or_b32 s16, s3, s16                                      // 0000007C7C04: 8C101003
	s_waitcnt vmcnt(11) lgkmcnt(7)                             // 0000007C7C08: BF892C77
	v_dot2_f32_bf16 v24, v24, v72, 0                           // 0000007C7C0C: CC1A4018 1A029118
	s_waitcnt vmcnt(10)                                        // 0000007C7C14: BF892BF7
	v_dot2_f32_bf16 v28, v28, v72, 0                           // 0000007C7C18: CC1A401C 1A02911C
	s_waitcnt vmcnt(9)                                         // 0000007C7C20: BF8927F7
	v_dot2_f32_bf16 v32, v32, v72, 0                           // 0000007C7C24: CC1A4020 1A029120
	v_lshrrev_b32_e32 v72, 6, v4                               // 0000007C7C2C: 32900886
	v_lshrrev_b32_e32 v4, 22, v4                               // 0000007C7C30: 32080896
	s_waitcnt lgkmcnt(6)                                       // 0000007C7C34: BF89FC67
	v_dot2_f32_bf16 v24, v25, v73, v24                         // 0000007C7C38: CC1A4018 1C629319
	v_dot2_f32_bf16 v25, v29, v73, v28                         // 0000007C7C40: CC1A4019 1C72931D
	v_dot2_f32_bf16 v28, v33, v73, v32                         // 0000007C7C48: CC1A401C 1C829321
	v_lshlrev_b32_e32 v29, 2, v78                              // 0000007C7C50: 303A9C82
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000007C7C54: 360808FF 000003FC
	s_waitcnt lgkmcnt(5)                                       // 0000007C7C5C: BF89FC57
	v_dot2_f32_bf16 v24, v26, v74, v24                         // 0000007C7C60: CC1A4018 1C62951A
	v_dot2_f32_bf16 v25, v30, v74, v25                         // 0000007C7C68: CC1A4019 1C66951E
	v_dot2_f32_bf16 v26, v34, v74, v28                         // 0000007C7C70: CC1A401A 1C729522
	v_and_b32_e32 v28, 0x3fc, v79                              // 0000007C7C78: 36389EFF 000003FC
	v_and_b32_e32 v30, 0x3fc, v80                              // 0000007C7C80: 363CA0FF 000003FC
	s_waitcnt lgkmcnt(4)                                       // 0000007C7C88: BF89FC47
	v_dot2_f32_bf16 v24, v27, v1, v24                          // 0000007C7C8C: CC1A4018 1C62031B
	v_dot2_f32_bf16 v25, v31, v1, v25                          // 0000007C7C94: CC1A4019 1C66031F
	v_dot2_f32_bf16 v1, v35, v1, v26                           // 0000007C7C9C: CC1A4001 1C6A0323
	ds_load_b32 v27, v29                                       // 0000007C7CA4: D8D80000 1B00001D
	ds_load_b32 v30, v30                                       // 0000007C7CAC: D8D80000 1E00001E
	ds_load_b32 v28, v28                                       // 0000007C7CB4: D8D80000 1C00001C
	s_waitcnt vmcnt(8) lgkmcnt(6)                              // 0000007C7CBC: BF892067
	v_dot2_f32_bf16 v24, v36, v75, v24                         // 0000007C7CC0: CC1A4018 1C629724
	s_waitcnt vmcnt(7)                                         // 0000007C7CC8: BF891FF7
	v_dot2_f32_bf16 v25, v40, v75, v25                         // 0000007C7CCC: CC1A4019 1C669728
	s_waitcnt vmcnt(6)                                         // 0000007C7CD4: BF891BF7
	v_dot2_f32_bf16 v1, v44, v75, v1                           // 0000007C7CD8: CC1A4001 1C06972C
	v_lshlrev_b32_e32 v26, 2, v81                              // 0000007C7CE0: 3034A282
	v_and_b32_e32 v29, 0x3fc, v72                              // 0000007C7CE4: 363A90FF 000003FC
	s_waitcnt lgkmcnt(5)                                       // 0000007C7CEC: BF89FC57
	v_dot2_f32_bf16 v24, v37, v76, v24                         // 0000007C7CF0: CC1A4018 1C629925
	v_dot2_f32_bf16 v25, v41, v76, v25                         // 0000007C7CF8: CC1A4019 1C669929
	v_dot2_f32_bf16 v1, v45, v76, v1                           // 0000007C7D00: CC1A4001 1C06992D
	v_and_b32_e32 v31, 0x3fc, v82                              // 0000007C7D08: 363EA4FF 000003FC
	s_waitcnt lgkmcnt(4)                                       // 0000007C7D10: BF89FC47
	v_dot2_f32_bf16 v24, v38, v77, v24                         // 0000007C7D14: CC1A4018 1C629B26
	v_dot2_f32_bf16 v25, v42, v77, v25                         // 0000007C7D1C: CC1A4019 1C669B2A
	v_dot2_f32_bf16 v1, v46, v77, v1                           // 0000007C7D24: CC1A4001 1C069B2E
	s_waitcnt lgkmcnt(3)                                       // 0000007C7D2C: BF89FC37
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007C7D30: BF870193
	v_dot2_f32_bf16 v24, v39, v2, v24                          // 0000007C7D34: CC1A4018 1C620527
	v_dot2_f32_bf16 v25, v43, v2, v25                          // 0000007C7D3C: CC1A4019 1C66052B
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007C7D44: BF870003
	v_dot2_f32_bf16 v1, v47, v2, v1                            // 0000007C7D48: CC1A4001 1C06052F
	ds_load_b32 v2, v3                                         // 0000007C7D50: D8D80000 02000003
	ds_load_b32 v3, v26                                        // 0000007C7D58: D8D80000 0300001A
	ds_load_b32 v26, v29                                       // 0000007C7D60: D8D80000 1A00001D
	ds_load_b32 v29, v31                                       // 0000007C7D68: D8D80000 1D00001F
	ds_load_b32 v31, v4                                        // 0000007C7D70: D8D80000 1F000004
	s_waitcnt vmcnt(5) lgkmcnt(7)                              // 0000007C7D78: BF891477
	v_dot2_f32_bf16 v4, v48, v27, v24                          // 0000007C7D7C: CC1A4004 1C623730
	s_waitcnt vmcnt(4)                                         // 0000007C7D84: BF8913F7
	v_dot2_f32_bf16 v24, v52, v27, v25                         // 0000007C7D88: CC1A4018 1C663734
	s_waitcnt vmcnt(3)                                         // 0000007C7D90: BF890FF7
	v_dot2_f32_bf16 v1, v56, v27, v1                           // 0000007C7D94: CC1A4001 1C063738
	s_waitcnt lgkmcnt(5)                                       // 0000007C7D9C: BF89FC57
	v_dot2_f32_bf16 v4, v49, v28, v4                           // 0000007C7DA0: CC1A4004 1C123931
	v_dot2_f32_bf16 v24, v53, v28, v24                         // 0000007C7DA8: CC1A4018 1C623935
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007C7DB0: BF870193
	v_dot2_f32_bf16 v1, v57, v28, v1                           // 0000007C7DB4: CC1A4001 1C063939
	v_dot2_f32_bf16 v4, v50, v30, v4                           // 0000007C7DBC: CC1A4004 1C123D32
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007C7DC4: BF870193
	v_dot2_f32_bf16 v24, v54, v30, v24                         // 0000007C7DC8: CC1A4018 1C623D36
	v_dot2_f32_bf16 v1, v58, v30, v1                           // 0000007C7DD0: CC1A4001 1C063D3A
	s_waitcnt lgkmcnt(4)                                       // 0000007C7DD8: BF89FC47
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007C7DDC: BF870193
	v_dot2_f32_bf16 v4, v51, v2, v4                            // 0000007C7DE0: CC1A4004 1C120533
	v_dot2_f32_bf16 v24, v55, v2, v24                          // 0000007C7DE8: CC1A4018 1C620537
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007C7DF0: BF8701A3
	v_dot2_f32_bf16 v1, v59, v2, v1                            // 0000007C7DF4: CC1A4001 1C06053B
	s_waitcnt vmcnt(2) lgkmcnt(3)                              // 0000007C7DFC: BF890837
	v_dot2_f32_bf16 v2, v60, v3, v4                            // 0000007C7E00: CC1A4002 1C12073C
	s_waitcnt vmcnt(1)                                         // 0000007C7E08: BF8907F7
	v_dot2_f32_bf16 v4, v64, v3, v24                           // 0000007C7E0C: CC1A4004 1C620740
	s_waitcnt vmcnt(0)                                         // 0000007C7E14: BF8903F7
	v_dot2_f32_bf16 v1, v68, v3, v1                            // 0000007C7E18: CC1A4001 1C060744
	s_waitcnt lgkmcnt(2)                                       // 0000007C7E20: BF89FC27
	v_dot2_f32_bf16 v2, v61, v26, v2                           // 0000007C7E24: CC1A4002 1C0A353D
	v_dot2_f32_bf16 v3, v65, v26, v4                           // 0000007C7E2C: CC1A4003 1C123541
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007C7E34: BF870003
	v_dot2_f32_bf16 v1, v69, v26, v1                           // 0000007C7E38: CC1A4001 1C063545
	v_mov_b32_e32 v4, v8                                       // 0000007C7E40: 7E080308
	s_waitcnt lgkmcnt(1)                                       // 0000007C7E44: BF89FC17
	v_dot2_f32_bf16 v2, v62, v29, v2                           // 0000007C7E48: CC1A4002 1C0A3B3E
	v_dot2_f32_bf16 v24, v66, v29, v3                          // 0000007C7E50: CC1A4018 1C0E3B42
	v_dot2_f32_bf16 v1, v70, v29, v1                           // 0000007C7E58: CC1A4001 1C063B46
	v_mov_b32_e32 v3, v7                                       // 0000007C7E60: 7E060307
	s_waitcnt lgkmcnt(0)                                       // 0000007C7E64: BF89FC07
	v_dot2_f32_bf16 v7, v63, v31, v2                           // 0000007C7E68: CC1A4007 1C0A3F3F
	v_dot2_f32_bf16 v8, v67, v31, v24                          // 0000007C7E70: CC1A4008 1C623F43
	v_dot2_f32_bf16 v24, v71, v31, v1                          // 0000007C7E78: CC1A4018 1C063F47
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v1, v5             // 0000007C7E80: CA100106 02000105
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000007C7E88: BF870214
	v_fmac_f32_e32 v20, v18, v7                                // 0000007C7E8C: 56280F12
	v_fmac_f32_e32 v19, v18, v8                                // 0000007C7E90: 56261112
	s_delay_alu instid0(VALU_DEP_4)                            // 0000007C7E94: BF870004
	v_dual_fmac_f32 v17, v18, v24 :: v_dual_mov_b32 v18, v23   // 0000007C7E98: C8103112 11120117
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 0000007C7EA0: 917E107E
	s_cbranch_execz 25                                         // 0000007C7EA4: BFA50019 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi1ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x70c>
	s_waitcnt vmcnt(0)                                         // 0000007C7EA8: BF8903F7
	v_dual_mov_b32 v5, v1 :: v_dual_add_nc_u32 v22, 32, v22    // 0000007C7EAC: CA200101 05162CA0
	v_dual_mov_b32 v6, v2 :: v_dual_mov_b32 v7, v3             // 0000007C7EB4: CA100102 06060103
	v_mov_b32_e32 v8, v4                                       // 0000007C7EBC: 7E100304
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007C7EC0: BF870003
	.long 0xd4430002                                           // 0000007C7EC4: D4430002
	v_cndmask_b32_e32 v1, s14, v22, vcc_lo                     // 0000007C7EC8: 02022C0E
	s_mov_b32 s17, exec_lo                                     // 0000007C7ECC: BE91007E
	.long 0xd4c4007e                                           // 0000007C7ED0: D4C4007E
	v_cndmask_b32_e32 v1, s14, v22, vcc_lo                     // 0000007C7ED4: 02022C0E
	s_cbranch_execz 65253                                      // 0000007C7ED8: BFA5FEE5 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi1ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x270>
	.long 0xd7000305                                           // 0000007C7EDC: D7000305
	v_cndmask_b32_e32 v1, v11, v21, vcc_lo                     // 0000007C7EE0: 02022B0B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007C7EE4: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v0, s3                    // 0000007C7EE8: D5207C06 000E0080
	global_load_d16_b16 v23, v[14:15], off                     // 0000007C7EF0: DC820000 177C000E
	global_load_b128 v[5:8], v[5:6], off                       // 0000007C7EF8: DC5E0000 057C0005
	s_waitcnt vmcnt(1)                                         // 0000007C7F00: BF8907F7
	v_cvt_f32_f16_e32 v23, v23                                 // 0000007C7F04: 7E2E1717
	s_branch 65241                                             // 0000007C7F08: BFA0FED9 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi1ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x270>
	s_or_b32 exec_lo, exec_lo, s16                             // 0000007C7F0C: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007C7F10: BF8700B9
	s_or_b32 exec_lo, exec_lo, s15                             // 0000007C7F14: 8C7E0F7E
	.long 0xd71f0000                                           // 0000007C7F18: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000007C7F1C: 020100C1
	s_waitcnt vmcnt(0)                                         // 0000007C7F20: BF8903F7
	v_xor_b32_e32 v1, 16, v0                                   // 0000007C7F24: 3A020090
	v_xor_b32_e32 v4, 8, v0                                    // 0000007C7F28: 3A080088
	v_xor_b32_e32 v7, 4, v0                                    // 0000007C7F2C: 3A0E0084
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C7F30: BF870093
	.long 0xd44c0002                                           // 0000007C7F34: D44C0002
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 0000007C7F38: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s2                           // 0000007C7F3C: D5010001 000A0300
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007C7F44: BF870114
	.long 0xd44c0002                                           // 0000007C7F48: D44C0002
	v_cndmask_b32_e32 v1, 32, v4, vcc_lo                       // 0000007C7F4C: 020208A0
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000007C7F50: 30020282
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007C7F54: BF870002
	v_cndmask_b32_e64 v4, v0, v4, s2                           // 0000007C7F58: D5010004 000A0900
	.long 0xd44c0002                                           // 0000007C7F60: D44C0002
	v_cndmask_b32_e32 v1, 32, v7, vcc_lo                       // 0000007C7F64: 02020EA0
	ds_bpermute_b32 v2, v1, v20                                // 0000007C7F68: DACC0000 02001401
	v_cndmask_b32_e64 v7, v0, v7, s2                           // 0000007C7F70: D5010007 000A0F00
	s_waitcnt lgkmcnt(0)                                       // 0000007C7F78: BF89FC07
	v_add_f32_e32 v2, v20, v2                                  // 0000007C7F7C: 06040514
	ds_bpermute_b32 v3, v1, v19                                // 0000007C7F80: DACC0000 03001301
	v_lshlrev_b32_e32 v4, 2, v4                                // 0000007C7F88: 30080882
	ds_bpermute_b32 v1, v1, v17                                // 0000007C7F8C: DACC0000 01001101
	s_waitcnt lgkmcnt(1)                                       // 0000007C7F94: BF89FC17
	v_add_f32_e32 v3, v19, v3                                  // 0000007C7F98: 06060713
	ds_bpermute_b32 v5, v4, v2                                 // 0000007C7F9C: DACC0000 05000204
	v_lshlrev_b32_e32 v7, 2, v7                                // 0000007C7FA4: 300E0E82
	ds_bpermute_b32 v6, v4, v3                                 // 0000007C7FA8: DACC0000 06000304
	s_waitcnt lgkmcnt(1)                                       // 0000007C7FB0: BF89FC17
	v_add_f32_e32 v2, v2, v5                                   // 0000007C7FB4: 06040B02
	v_add_f32_e32 v1, v17, v1                                  // 0000007C7FB8: 06020311
	ds_bpermute_b32 v4, v4, v1                                 // 0000007C7FBC: DACC0000 04000104
	s_waitcnt lgkmcnt(0)                                       // 0000007C7FC4: BF89FC07
	v_add_f32_e32 v1, v1, v4                                   // 0000007C7FC8: 06020901
	ds_bpermute_b32 v4, v7, v2                                 // 0000007C7FCC: DACC0000 04000207
	s_waitcnt lgkmcnt(0)                                       // 0000007C7FD4: BF89FC07
	v_dual_add_f32 v2, v2, v4 :: v_dual_add_f32 v3, v3, v6     // 0000007C7FD8: C9080902 02020D03
	ds_bpermute_b32 v6, v7, v1                                 // 0000007C7FE0: DACC0000 06000107
	ds_bpermute_b32 v5, v7, v3                                 // 0000007C7FE8: DACC0000 05000307
	v_xor_b32_e32 v7, 2, v0                                    // 0000007C7FF0: 3A0E0082
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C7FF4: BF870091
	.long 0xd44c0002                                           // 0000007C7FF8: D44C0002
	v_cndmask_b32_e32 v1, 32, v7, vcc_lo                       // 0000007C7FFC: 02020EA0
	v_cndmask_b32_e64 v7, v0, v7, s2                           // 0000007C8000: D5010007 000A0F00
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007C8008: BF870001
	v_lshlrev_b32_e32 v7, 2, v7                                // 0000007C800C: 300E0E82
	ds_bpermute_b32 v4, v7, v2                                 // 0000007C8010: DACC0000 04000207
	s_waitcnt lgkmcnt(0)                                       // 0000007C8018: BF89FC07
	v_dual_add_f32 v4, v2, v4 :: v_dual_add_f32 v3, v3, v5     // 0000007C801C: C9080902 04020B03
	ds_bpermute_b32 v5, v7, v3                                 // 0000007C8024: DACC0000 05000307
	s_waitcnt lgkmcnt(0)                                       // 0000007C802C: BF89FC07
	v_dual_add_f32 v2, v3, v5 :: v_dual_add_f32 v1, v1, v6     // 0000007C8030: C9080B03 02000D01
	ds_bpermute_b32 v6, v7, v1                                 // 0000007C8038: DACC0000 06000107
	v_xor_b32_e32 v7, 1, v0                                    // 0000007C8040: 3A0E0081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C8044: BF870091
	.long 0xd44c0002                                           // 0000007C8048: D44C0002
	v_cndmask_b32_e32 v1, 32, v7, vcc_lo                       // 0000007C804C: 02020EA0
	v_cndmask_b32_e64 v0, v0, v7, s2                           // 0000007C8050: D5010000 000A0F00
	.long 0xd44a0002                                           // 0000007C8058: D44A0002
	v_cndmask_b32_e32 v1, 0, v16, vcc_lo                       // 0000007C805C: 02022080
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007C8060: BF870002
	v_lshlrev_b32_e32 v7, 2, v0                                // 0000007C8064: 300E0082
	s_and_b32 s2, s2, vcc_lo                                   // 0000007C8068: 8B026A02
	s_waitcnt lgkmcnt(0)                                       // 0000007C806C: BF89FC07
	v_add_f32_e32 v0, v1, v6                                   // 0000007C8070: 06000D01
	ds_bpermute_b32 v5, v7, v4                                 // 0000007C8074: DACC0000 05000407
	ds_bpermute_b32 v3, v7, v2                                 // 0000007C807C: DACC0000 03000207
	ds_bpermute_b32 v1, v7, v0                                 // 0000007C8084: DACC0000 01000007
	s_and_saveexec_b32 s3, s2                                  // 0000007C808C: BE832002
	s_cbranch_execz 163                                        // 0000007C8090: BFA500A3 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi1ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0xb20>
	s_waitcnt lgkmcnt(2)                                       // 0000007C8094: BF89FC27
	v_add_f32_e32 v4, v4, v5                                   // 0000007C8098: 06080B04
	.long 0x7f0a3880                                           // 0000007C809C: 7F0A3880
	s_waitcnt lgkmcnt(1)                                       // 0000007C80A0: BF89FC17
	v_add_f32_e32 v2, v2, v3                                   // 0000007C80A4: 06040702
	s_load_b32 s0, s[0:1], 0x48                                // 0000007C80A8: F4000000 F8000048
	s_waitcnt lgkmcnt(0)                                       // 0000007C80B0: BF89FC07
	v_add_f32_e32 v0, v0, v1                                   // 0000007C80B4: 06000300
	.long 0x7e063984                                           // 0000007C80B8: 7E063984
	.long 0x7f063985                                           // 0000007C80BC: 7F063985
	s_lshl_b64 s[2:3], s[12:13], 1                             // 0000007C80C0: 8482810C
	s_lshl_b64 s[4:5], s[12:13], 2                             // 0000007C80C4: 8484820C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007C80C8: BF870121
	v_and_b32_e32 v1, 1, v3                                    // 0000007C80CC: 36020681
	v_bfe_u32 v3, v0, 16, 1                                    // 0000007C80D0: D6100003 02052100
	v_add3_u32 v1, v4, v1, 0x7fff                              // 0000007C80D8: D6550001 03FE0304 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007C80E4: BF870112
	v_add3_u32 v0, v0, v3, 0x7fff                              // 0000007C80E8: D6550000 03FE0700 00007FFF
	v_and_b32_e32 v1, 0xffff0000, v1                           // 0000007C80F4: 360202FF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007C80FC: BF870122
	v_and_b32_e32 v0, 0xffff0000, v0                           // 0000007C8100: 360000FF FFFF0000
	.long 0x7e0a3982                                           // 0000007C8108: 7E0A3982
	v_dual_mul_f32 v3, s0, v1 :: v_dual_mul_f32 v4, s0, v0     // 0000007C810C: C8C60200 03040000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C8114: BF870091
	v_dual_mul_f32 v0, 0xbfb8aa3b, v3 :: v_dual_mul_f32 v1, 0xbfb8aa3b, v4// 0000007C8118: C8C606FF 000008FF BFB8AA3B
	v_exp_f32_e32 v0, v0                                       // 0000007C8124: 7E004B00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000007C8128: BF870311
	v_exp_f32_e32 v1, v1                                       // 0000007C812C: 7E024B01
	v_dual_add_f32 v7, 1.0, v0 :: v_dual_and_b32 v6, 1, v5     // 0000007C8130: C92400F2 07060A81
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007C8138: BF870115
	v_add_f32_e32 v8, 1.0, v1                                  // 0000007C813C: 061002F2
	v_add3_u32 v2, v2, v6, 0x7fff                              // 0000007C8140: D6550002 03FE0D02 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007C814C: BF870193
	v_div_scale_f32 v11, null, v7, v7, v3                      // 0000007C8150: D6FC7C0B 040E0F07
	v_div_scale_f32 v12, null, v8, v8, v4                      // 0000007C8158: D6FC7C0C 04121108
	v_div_scale_f32 v19, vcc_lo, v3, v7, v3                    // 0000007C8160: D6FC6A13 040E0F03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007C8168: BF870113
	v_rcp_f32_e32 v14, v11                                     // 0000007C816C: 7E1C550B
	v_rcp_f32_e32 v15, v12                                     // 0000007C8170: 7E1E550C
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000007C8174: BF870296
	v_fma_f32 v0, -v11, v14, 1.0                               // 0000007C8178: D6130000 23CA1D0B
	v_fma_f32 v1, -v12, v15, 1.0                               // 0000007C8180: D6130001 23CA1F0C
	v_and_b32_e32 v2, 0xffff0000, v2                           // 0000007C8188: 360404FF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007C8190: BF870112
	v_dual_fmac_f32 v14, v0, v14 :: v_dual_fmac_f32 v15, v1, v15// 0000007C8194: C8001D00 0E0E1F01
	v_mul_f32_e32 v2, s0, v2                                   // 0000007C819C: 10040400
	v_div_scale_f32 v17, s0, v4, v8, v4                        // 0000007C81A0: D6FC0011 04121104
	.long 0xd73c0000                                           // 0000007C81A8: D73C0000
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 0000007C81AC: 02021281
	.long 0x7f123985                                           // 0000007C81B0: 7F123985
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C81B4: BF870093
	v_mul_f32_e32 v21, v17, v15                                // 0000007C81B8: 102A1F11
	v_fma_f32 v24, -v12, v21, v17                              // 0000007C81BC: D6130018 24462B0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C81C4: BF870091
	v_dual_fmac_f32 v21, v24, v15 :: v_dual_mul_f32 v6, 0xbfb8aa3b, v2// 0000007C81C8: C8061F18 150604FF BFB8AA3B
	v_exp_f32_e32 v6, v6                                       // 0000007C81D4: 7E0C4B06
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C81D8: BF870095
	v_add_f32_e32 v6, 1.0, v6                                  // 0000007C81DC: 060C0CF2
	v_div_scale_f32 v13, null, v6, v6, v2                      // 0000007C81E0: D6FC7C0D 040A0D06
	v_div_scale_f32 v20, s1, v2, v6, v2                        // 0000007C81E8: D6FC0114 040A0D02
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000007C81F0: BF870292
	v_rcp_f32_e32 v16, v13                                     // 0000007C81F4: 7E20550D
	v_fma_f32 v18, -v13, v16, 1.0                              // 0000007C81F8: D6130012 23CA210D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007C8200: BF870121
	v_fmac_f32_e32 v16, v18, v16                               // 0000007C8204: 56202112
	v_mul_f32_e32 v18, v19, v14                                // 0000007C8208: 10241D13
	v_mul_f32_e32 v22, v20, v16                                // 0000007C820C: 102C2114
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007C8210: BF870112
	v_fma_f32 v23, -v11, v18, v19                              // 0000007C8214: D6130017 244E250B
	v_fma_f32 v25, -v13, v22, v20                              // 0000007C821C: D6130019 24522D0D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007C8224: BF870112
	v_fmac_f32_e32 v18, v23, v14                               // 0000007C8228: 56241D17
	v_fmac_f32_e32 v22, v25, v16                               // 0000007C822C: 562C2119
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007C8230: BF8701A2
	v_fma_f32 v10, -v11, v18, v19                              // 0000007C8234: D613000A 244E250B
	v_fma_f32 v11, -v12, v21, v17                              // 0000007C823C: D613000B 24462B0C
	v_fma_f32 v12, -v13, v22, v20                              // 0000007C8244: D613000C 24522D0D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007C824C: BF870123
	v_div_fmas_f32 v10, v10, v14, v18                          // 0000007C8250: D637000A 044A1D0A
	s_mov_b32 vcc_lo, s1                                       // 0000007C8258: BEEA0001
	v_div_fmas_f32 v12, v12, v16, v22                          // 0000007C825C: D637000C 045A210C
	s_mov_b32 vcc_lo, s0                                       // 0000007C8264: BEEA0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000007C8268: BF870242
	v_div_fixup_f32 v7, v10, v7, v3                            // 0000007C826C: D6270007 040E0F0A
	v_div_fmas_f32 v11, v11, v15, v21                          // 0000007C8274: D637000B 04561F0B
	.long 0xd7006a00                                           // 0000007C827C: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 0000007C8280: 02020008
	v_div_fixup_f32 v6, v12, v6, v2                            // 0000007C8284: D6270006 040A0D0C
	.long 0x7e123987                                           // 0000007C828C: 7E123987
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000007C8290: BF870224
	v_div_fixup_f32 v8, v11, v8, v4                            // 0000007C8294: D6270008 0412110B
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 0000007C829C: D5207C01 01AA0209
	.long 0x7e0a3986                                           // 0000007C82A4: 7E0A3986
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000007C82A8: BF870214
	v_and_b32_e32 v9, 1, v9                                    // 0000007C82AC: 36121281
	v_bfe_u32 v10, v8, 16, 1                                   // 0000007C82B0: D610000A 02052108
	.long 0xd7006a02                                           // 0000007C82B8: D7006A02
	v_cndmask_b32_e32 v0, v0, v2, vcc_lo                       // 0000007C82BC: 02000500
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000007C82C0: BF870244
	v_and_b32_e32 v11, 1, v5                                   // 0000007C82C4: 36160A81
	v_add_co_ci_u32_e64 v3, null, s3, v1, vcc_lo               // 0000007C82C8: D5207C03 01AA0203
	.long 0xd7006a04                                           // 0000007C82D0: D7006A04
	v_cndmask_b32_e32 v0, v0, v4, vcc_lo                       // 0000007C82D4: 02000900
	v_add3_u32 v7, v7, v9, 0x7fff                              // 0000007C82D8: D6550007 03FE1307 00007FFF
	v_add3_u32 v6, v6, v11, 0x7fff                             // 0000007C82E4: D6550006 03FE1706 00007FFF
	v_add_co_ci_u32_e64 v5, null, s5, v1, vcc_lo               // 0000007C82F0: D5207C05 01AA0205
	v_add3_u32 v8, v8, v10, 0x7fff                             // 0000007C82F8: D6550008 03FE1508 00007FFF
	s_clause 0x2                                               // 0000007C8304: BF850002
	global_store_d16_hi_b16 v[0:1], v7, off                    // 0000007C8308: DC960000 007C0700
	global_store_d16_hi_b16 v[2:3], v6, off                    // 0000007C8310: DC960000 007C0602
	global_store_d16_hi_b16 v[4:5], v8, off                    // 0000007C8318: DC960000 007C0804
	s_endpgm                                                   // 0000007C8320: BFB00000
		...

