0000000000723200 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi1ELi32ELi2ELb1EEEvPKhPKtPvll>:
; _ZN7halogen12_GLOBAL__N_18k_lq8s32ILi1ELi32ELi2ELb1EEEvPKhPKtPvll():
	s_clause 0x1                                               // 000000723200: BF850001
	s_load_b256 s[4:11], s[0:1], null                          // 000000723204: F40C0100 F8000000
	s_load_b64 s[12:13], s[0:1], 0x20                          // 00000072320C: F4040300 F8000020
	s_mov_b32 s3, 0                                            // 000000723214: BE830080
	v_lshrrev_b32_e32 v14, 6, v0                               // 000000723218: 321C0086
	s_lshl_b64 s[2:3], s[2:3], 2                               // 00000072321C: 84828202
	v_bfe_u32 v15, v0, 5, 1                                    // 000000723220: D610000F 02050B00
	v_dual_mov_b32 v17, 0 :: v_dual_and_b32 v16, 31, v0        // 000000723228: CA240080 1110009F
	s_delay_alu instid0(VALU_DEP_3)                            // 000000723230: BF870003
	v_or_b32_e32 v1, s2, v14                                   // 000000723234: 38021C02
	v_mov_b32_e32 v2, s3                                       // 000000723238: 7E040203
	.long 0x7e2e3880                                           // 00000072323C: 7E2E3880
	v_dual_mov_b32 v5, 0 :: v_dual_mov_b32 v6, 0               // 000000723240: CA100080 05060080
	v_mov_b32_e32 v8, 0                                        // 000000723248: 7E100280
	s_waitcnt lgkmcnt(0)                                       // 00000072324C: BF89FC07
	s_ashr_i32 s0, s11, 31                                     // 000000723250: 86009F0B
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 000000723254: 7CA8020C
	s_lshr_b32 s0, s0, 28                                      // 000000723258: 85009C00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000072325C: BF8704A9
	s_add_u32 s0, s10, s0                                      // 000000723260: 8000000A
	s_addc_u32 s1, s11, 0                                      // 000000723264: 8201800B
	s_ashr_i64 s[0:1], s[0:1], 4                               // 000000723268: 86808400
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000072326C: 02020280
	s_add_u32 s14, s10, s0                                     // 000000723270: 800E000A
	s_addc_u32 s1, s11, s1                                     // 000000723274: 8201010B
	s_add_u32 s14, s14, 15                                     // 000000723278: 800E8F0E
	s_addc_u32 s1, s1, 0                                       // 00000072327C: 82018001
	s_add_i32 s15, s0, 1                                       // 000000723280: 810F8100
	v_cndmask_b32_e64 v2, 0, s3, vcc_lo                        // 000000723284: D5010002 01A80680
	s_lshr_b32 s16, s15, 31                                    // 00000072328C: 85109F0F
	s_and_b32 s14, s14, -16                                    // 000000723290: 8B0ED00E
	s_add_i32 s15, s15, s16                                    // 000000723294: 810F100F
	.long 0xd72c0004                                           // 000000723298: D72C0004
	v_cndmask_b32_e32 v0, v1, v1, vcc_lo                       // 00000072329C: 02000301
	s_ashr_i32 s15, s15, 1                                     // 0000007232A0: 860F810F
	.long 0xd72c0002                                           // 0000007232A4: D72C0002
	v_cndmask_b32_e32 v0, v2, v14, vcc_lo                      // 0000007232A8: 02001D02
	.long 0xd72c0003                                           // 0000007232AC: D72C0003
	v_cndmask_b32_e32 v1, s15, v15, vcc_lo                     // 0000007232B0: 02021E0F
	v_mad_u64_u32 v[10:11], null, v1, s14, s[4:5]              // 0000007232B4: D6FE7C0A 00101D01
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007232BC: BF8701A2
	v_dual_mov_b32 v7, 0 :: v_dual_add_nc_u32 v18, v3, v16     // 0000007232C0: CA200080 07122103
	v_add_nc_u32_e32 v1, s15, v3                               // 0000007232C8: 4A02060F
	v_add3_u32 v11, v2, v11, v4                                // 0000007232CC: D655000B 04121702
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000007232D4: BF870214
	.long 0xd7006a14                                           // 0000007232D8: D7006A14
	v_cndmask_b32_e32 v0, v10, v10, vcc_lo                     // 0000007232DC: 0200150A
	v_lshlrev_b32_e32 v12, 4, v18                              // 0000007232E0: 30182484
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000007232E4: BF870214
	v_min_i32_e32 v19, s0, v1                                  // 0000007232E8: 22260200
	v_add_co_ci_u32_e64 v21, null, s11, v11, vcc_lo            // 0000007232EC: D5207C15 01AA160B
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007232F4: BF870002
	v_cmp_lt_i32_e32 vcc_lo, v18, v19                          // 0000007232F8: 7C822712
	s_and_saveexec_b32 s1, vcc_lo                              // 0000007232FC: BE81206A
	s_cbranch_execz 19                                         // 000000723300: BFA50013 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi1ELi32ELi2ELb1EEEvPKhPKtPvll+0x150>
	v_lshlrev_b32_e32 v1, 4, v18                               // 000000723304: 30022484
	v_and_b32_e32 v3, -2, v18                                  // 000000723308: 360624C2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000072330C: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000723310: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000723314: 3408069F
	.long 0xd7000001                                           // 000000723318: D7000001
	v_cndmask_b32_e32 v1, v10, v1, vcc_lo                      // 00000072331C: 0202030A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000723320: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v11, v2, s0                  // 000000723324: D5207C02 0002050B
	.long 0xd7000003                                           // 00000072332C: D7000003
	v_cndmask_b32_e32 v1, v20, v3, vcc_lo                      // 000000723330: 02020714
	v_add_co_ci_u32_e64 v4, null, v21, v4, s0                  // 000000723334: D5207C04 00020915
	s_clause 0x1                                               // 00000072333C: BF850001
	global_load_b128 v[5:8], v[1:2], off                       // 000000723340: DC5E0000 057C0001
	global_load_d16_b16 v23, v[3:4], off                       // 000000723348: DC820000 177C0003
	s_or_b32 exec_lo, exec_lo, s1                              // 000000723350: 8C7E017E
	s_and_saveexec_b32 s1, vcc_lo                              // 000000723354: BE81206A
	s_cbranch_execz 282                                        // 000000723358: BFA5011A <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi1ELi32ELi2ELb1EEEvPKhPKtPvll+0x5c4>
	v_dual_mov_b32 v17, 0 :: v_dual_add_nc_u32 v22, 0x200, v12 // 00000072335C: CA200080 111618FF 00000200
	s_mov_b32 s4, 0                                            // 000000723368: BE840080
	s_branch 244                                               // 00000072336C: BFA000F4 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi1ELi32ELi2ELb1EEEvPKhPKtPvll+0x540>
	s_or_b32 exec_lo, exec_lo, s5                              // 000000723370: 8C7E057E
	v_ashrrev_i32_e32 v13, 31, v12                             // 000000723374: 341A189F
	v_bfe_i32 v32, v5, 8, 8                                    // 000000723378: D6110020 02211105
	v_bfe_i32 v33, v5, 16, 8                                   // 000000723380: D6110021 02212105
	.long 0x7f2e3880                                           // 000000723388: 7F2E3880
	v_bfe_i32 v34, v6, 0, 8                                    // 00000072338C: D6110022 02210106
	.long 0xd73c0018                                           // 000000723394: D73C0018
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 000000723398: 02021881
	v_bfe_i32 v13, v5, 0, 8                                    // 00000072339C: D611000D 02210105
	v_ashrrev_i32_e32 v5, 24, v5                               // 0000007233A4: 340A0A98
	v_cvt_f32_i32_e32 v32, v32                                 // 0000007233A8: 7E400B20
	v_cvt_f32_i32_e32 v33, v33                                 // 0000007233AC: 7E420B21
	v_bfe_i32 v35, v6, 8, 8                                    // 0000007233B0: D6110023 02211106
	.long 0xd700001c                                           // 0000007233B8: D700001C
	v_cndmask_b32_e32 v1, s6, v24, vcc_lo                      // 0000007233BC: 02023006
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007233C0: BF870001
	v_add_co_ci_u32_e64 v29, null, s7, v25, s0                 // 0000007233C4: D5207C1D 00023207
	v_cvt_f32_i32_e32 v13, v13                                 // 0000007233CC: 7E1A0B0D
	v_bfe_i32 v36, v6, 16, 8                                   // 0000007233D0: D6110024 02212106
	v_ashrrev_i32_e32 v6, 24, v6                               // 0000007233D8: 340C0C98
	s_clause 0x1                                               // 0000007233DC: BF850001
	global_load_b128 v[24:27], v[28:29], off                   // 0000007233E0: DC5E0000 187C001C
	global_load_b128 v[28:31], v[28:29], off offset:16         // 0000007233E8: DC5E0010 1C7C001C
	v_bfe_i32 v37, v7, 0, 8                                    // 0000007233F0: D6110025 02210107
	v_fma_mix_f32 v13, v23, v13, neg(0) op_sel_hi:[1,0,0]      // 0000007233F8: CC20000D 8A021B17
	v_bfe_i32 v38, v7, 8, 8                                    // 000000723400: D6110026 02211107
	v_bfe_i32 v39, v7, 16, 8                                   // 000000723408: D6110027 02212107
	v_ashrrev_i32_e32 v7, 24, v7                               // 000000723410: 340E0E98
	v_bfe_i32 v40, v8, 0, 8                                    // 000000723414: D6110028 02210108
	v_bfe_i32 v41, v8, 8, 8                                    // 00000072341C: D6110029 02211108
	v_bfe_i32 v42, v8, 16, 8                                   // 000000723424: D611002A 02212108
	v_ashrrev_i32_e32 v8, 24, v8                               // 00000072342C: 34101098
	v_cvt_f32_i32_e32 v5, v5                                   // 000000723430: 7E0A0B05
	v_cvt_f32_i32_e32 v34, v34                                 // 000000723434: 7E440B22
	v_fma_mix_f32 v32, v23, v32, neg(0) op_sel_hi:[1,0,0]      // 000000723438: CC200020 8A024117
	v_fma_mix_f32 v33, v23, v33, neg(0) op_sel_hi:[1,0,0]      // 000000723440: CC200021 8A024317
	v_bfe_u32 v46, v13, 16, 1                                  // 000000723448: D610002E 0205210D
	v_cvt_f32_i32_e32 v35, v35                                 // 000000723450: 7E460B23
	v_cvt_f32_i32_e32 v36, v36                                 // 000000723454: 7E480B24
	v_cvt_f32_i32_e32 v6, v6                                   // 000000723458: 7E0C0B06
	v_cvt_f32_i32_e32 v37, v37                                 // 00000072345C: 7E4A0B25
	v_cvt_f32_i32_e32 v38, v38                                 // 000000723460: 7E4C0B26
	v_cvt_f32_i32_e32 v39, v39                                 // 000000723464: 7E4E0B27
	v_cvt_f32_i32_e32 v7, v7                                   // 000000723468: 7E0E0B07
	v_cvt_f32_i32_e32 v40, v40                                 // 00000072346C: 7E500B28
	v_cvt_f32_i32_e32 v41, v41                                 // 000000723470: 7E520B29
	v_cvt_f32_i32_e32 v42, v42                                 // 000000723474: 7E540B2A
	v_cvt_f32_i32_e32 v8, v8                                   // 000000723478: 7E100B08
	v_fma_mix_f32 v5, v23, v5, neg(0) op_sel_hi:[1,0,0]        // 00000072347C: CC200005 8A020B17
	v_fma_mix_f32 v34, v23, v34, neg(0) op_sel_hi:[1,0,0]      // 000000723484: CC200022 8A024517
	v_bfe_u32 v47, v32, 16, 1                                  // 00000072348C: D610002F 02052120
	v_bfe_u32 v48, v33, 16, 1                                  // 000000723494: D6100030 02052121
	v_add3_u32 v13, v13, v46, 0x7fff                           // 00000072349C: D655000D 03FE5D0D 00007FFF
	v_fma_mix_f32 v35, v23, v35, neg(0) op_sel_hi:[1,0,0]      // 0000007234A8: CC200023 8A024717
	v_fma_mix_f32 v36, v23, v36, neg(0) op_sel_hi:[1,0,0]      // 0000007234B0: CC200024 8A024917
	v_fma_mix_f32 v6, v23, v6, neg(0) op_sel_hi:[1,0,0]        // 0000007234B8: CC200006 8A020D17
	v_fma_mix_f32 v37, v23, v37, neg(0) op_sel_hi:[1,0,0]      // 0000007234C0: CC200025 8A024B17
	v_fma_mix_f32 v38, v23, v38, neg(0) op_sel_hi:[1,0,0]      // 0000007234C8: CC200026 8A024D17
	v_fma_mix_f32 v39, v23, v39, neg(0) op_sel_hi:[1,0,0]      // 0000007234D0: CC200027 8A024F17
	v_fma_mix_f32 v7, v23, v7, neg(0) op_sel_hi:[1,0,0]        // 0000007234D8: CC200007 8A020F17
	v_fma_mix_f32 v40, v23, v40, neg(0) op_sel_hi:[1,0,0]      // 0000007234E0: CC200028 8A025117
	v_fma_mix_f32 v41, v23, v41, neg(0) op_sel_hi:[1,0,0]      // 0000007234E8: CC200029 8A025317
	v_fma_mix_f32 v42, v23, v42, neg(0) op_sel_hi:[1,0,0]      // 0000007234F0: CC20002A 8A025517
	v_fma_mix_f32 v8, v23, v8, neg(0) op_sel_hi:[1,0,0]        // 0000007234F8: CC200008 8A021117
	v_bfe_u32 v49, v5, 16, 1                                   // 000000723500: D6100031 02052105
	v_bfe_u32 v50, v34, 16, 1                                  // 000000723508: D6100032 02052122
	v_add3_u32 v33, v33, v48, 0x7fff                           // 000000723510: D6550021 03FE6121 00007FFF
	v_add3_u32 v32, v32, v47, 0x7fff                           // 00000072351C: D6550020 03FE5F20 00007FFF
	.long 0x7e2e398d                                           // 000000723528: 7E2E398D
	.long 0x7f563997                                           // 00000072352C: 7F563997
	v_bfe_u32 v51, v35, 16, 1                                  // 000000723530: D6100033 02052123
	v_bfe_u32 v52, v36, 16, 1                                  // 000000723538: D6100034 02052124
	v_add3_u32 v5, v5, v49, 0x7fff                             // 000000723540: D6550005 03FE6305 00007FFF
	.long 0x7e5639a1                                           // 00000072354C: 7E5639A1
	v_add3_u32 v33, v34, v50, 0x7fff                           // 000000723550: D6550021 03FE6522 00007FFF
	v_and_or_b32 v32, 0xffff0000, v32, v23                     // 00000072355C: D6570020 045E40FF FFFF0000
	v_bfe_u32 v53, v6, 16, 1                                   // 000000723568: D6100035 02052106
	v_bfe_u32 v54, v37, 16, 1                                  // 000000723570: D6100036 02052125
	v_add3_u32 v34, v35, v51, 0x7fff                           // 000000723578: D6550022 03FE6723 00007FFF
	v_add3_u32 v35, v36, v52, 0x7fff                           // 000000723584: D6550023 03FE6924 00007FFF
	v_and_or_b32 v5, 0xffff0000, v5, v43                       // 000000723590: D6570005 04AE0AFF FFFF0000
	.long 0x7e2e39a1                                           // 00000072359C: 7E2E39A1
	.long 0x7f583997                                           // 0000007235A0: 7F583997
	v_bfe_u32 v55, v38, 16, 1                                  // 0000007235A4: D6100037 02052126
	v_bfe_u32 v56, v39, 16, 1                                  // 0000007235AC: D6100038 02052127
	v_add3_u32 v6, v6, v53, 0x7fff                             // 0000007235B4: D6550006 03FE6B06 00007FFF
	.long 0x7e5839a3                                           // 0000007235C0: 7E5839A3
	v_and_or_b32 v33, 0xffff0000, v34, v23                     // 0000007235C4: D6570021 045E44FF FFFF0000
	v_bfe_u32 v57, v7, 16, 1                                   // 0000007235D0: D6100039 02052107
	v_bfe_u32 v58, v40, 16, 1                                  // 0000007235D8: D610003A 02052128
	.long 0x7f5a3997                                           // 0000007235E0: 7F5A3997
	v_and_or_b32 v6, 0xffff0000, v6, v44                       // 0000007235E4: D6570006 04B20CFF FFFF0000
	v_bfe_u32 v46, v41, 16, 1                                  // 0000007235F0: D610002E 02052129
	v_bfe_u32 v59, v42, 16, 1                                  // 0000007235F8: D610003B 0205212A
	v_add3_u32 v7, v7, v57, 0x7fff                             // 000000723600: D6550007 03FE7307 00007FFF
	v_bfe_u32 v13, v8, 16, 1                                   // 00000072360C: D610000D 02052108
	v_add_nc_u32_e32 v22, 0x200, v22                           // 000000723614: 4A2C2CFF 00000200
	v_add_nc_u32_e32 v12, 0x200, v12                           // 00000072361C: 4A1818FF 00000200
	s_and_b32 s0, exec_lo, vcc_lo                              // 000000723624: 8B006A7E
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000723628: BF870153
	v_add3_u32 v8, v8, v13, 0x7fff                             // 00000072362C: D6550008 03FE1B08 00007FFF
	s_or_b32 s4, s0, s4                                        // 000000723638: 8C040400
	s_waitcnt vmcnt(1)                                         // 00000072363C: BF8907F7
	v_dot2_f32_bf16 v24, v24, v32, 0                           // 000000723640: CC1A4018 1A024118
	v_add3_u32 v32, v37, v54, 0x7fff                           // 000000723648: D6550020 03FE6D25 00007FFF
	v_dot2_f32_bf16 v5, v25, v5, v24                           // 000000723654: CC1A4005 1C620B19
	v_add3_u32 v24, v38, v55, 0x7fff                           // 00000072365C: D6550018 03FE6F26 00007FFF
	v_add3_u32 v25, v39, v56, 0x7fff                           // 000000723668: D6550019 03FE7127 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000723674: BF870214
	.long 0x7e2e39a0                                           // 000000723678: 7E2E39A0
	v_dot2_f32_bf16 v5, v26, v33, v5                           // 00000072367C: CC1A4005 1C16431A
	v_add3_u32 v26, v40, v58, 0x7fff                           // 000000723684: D655001A 03FE7528 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000723690: BF870214
	.long 0x7e5a3999                                           // 000000723694: 7E5A3999
	v_and_or_b32 v24, 0xffff0000, v24, v23                     // 000000723698: D6570018 045E30FF FFFF0000
	v_add3_u32 v25, v42, v59, 0x7fff                           // 0000007236A4: D6550019 03FE772A 00007FFF
	v_dot2_f32_bf16 v5, v27, v6, v5                            // 0000007236B0: CC1A4005 1C160D1B
	v_add3_u32 v6, v41, v46, 0x7fff                            // 0000007236B8: D6550006 03FE5D29 00007FFF
	v_and_or_b32 v7, 0xffff0000, v7, v45                       // 0000007236C4: D6570007 04B60EFF FFFF0000
	.long 0x7e2e399a                                           // 0000007236D0: 7E2E399A
	s_waitcnt vmcnt(0)                                         // 0000007236D4: BF8903F7
	v_dot2_f32_bf16 v5, v28, v24, v5                           // 0000007236D8: CC1A4005 1C16311C
	.long 0x7f303997                                           // 0000007236E0: 7F303997
	.long 0x7e303999                                           // 0000007236E4: 7E303999
	v_and_or_b32 v6, 0xffff0000, v6, v23                       // 0000007236E8: D6570006 045E0CFF FFFF0000
	.long 0x7e2e3909                                           // 0000007236F4: 7E2E3909
	v_dot2_f32_bf16 v5, v29, v7, v5                            // 0000007236F8: CC1A4005 1C160F1D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000723700: BF8701A4
	v_and_or_b32 v7, 0xffff0000, v8, v24                       // 000000723704: D6570007 046210FF FFFF0000
	v_mov_b32_e32 v8, v4                                       // 000000723710: 7E100304
	v_dot2_f32_bf16 v5, v30, v6, v5                            // 000000723714: CC1A4005 1C160D1E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000072371C: BF8701B1
	v_dot2_f32_bf16 v4, v31, v7, v5                            // 000000723720: CC1A4004 1C160F1F
	v_dual_mov_b32 v7, v3 :: v_dual_mov_b32 v6, v2             // 000000723728: CA100103 07060102
	v_mov_b32_e32 v5, v1                                       // 000000723730: 7E0A0301
	v_add_f32_e32 v17, v17, v4                                 // 000000723734: 06220911
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000723738: 917E047E
	s_cbranch_execz 32                                         // 00000072373C: BFA50020 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi1ELi32ELi2ELb1EEEvPKhPKtPvll+0x5c0>
	s_waitcnt vmcnt(1)                                         // 000000723740: BF8907F7
	v_dual_mov_b32 v1, v5 :: v_dual_add_nc_u32 v18, 32, v18    // 000000723744: CA200105 011224A0
	s_waitcnt vmcnt(0)                                         // 00000072374C: BF8903F7
	.long 0x7e123917                                           // 000000723750: 7E123917
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v3, v7             // 000000723754: CA100106 02020107
	v_mov_b32_e32 v4, v8                                       // 00000072375C: 7E080308
	s_mov_b32 s5, exec_lo                                      // 000000723760: BE85007E
	v_cmp_ge_i32_e32 vcc_lo, v18, v19                          // 000000723764: 7C8C2712
	.long 0xd4c1007e                                           // 000000723768: D4C1007E
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 00000072376C: 02022712
	s_cbranch_execz 65279                                      // 000000723770: BFA5FEFF <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi1ELi32ELi2ELb1EEEvPKhPKtPvll+0x170>
	v_and_b32_e32 v3, -2, v18                                  // 000000723774: 360624C2
	v_ashrrev_i32_e32 v2, 31, v22                              // 000000723778: 34042C9F
	.long 0xd7000001                                           // 00000072377C: D7000001
	v_cndmask_b32_e32 v1, v10, v22, vcc_lo                     // 000000723780: 02022D0A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000723784: BF870193
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000723788: 3408069F
	v_add_co_ci_u32_e64 v2, null, v11, v2, s0                  // 00000072378C: D5207C02 0002050B
	.long 0xd7000018                                           // 000000723794: D7000018
	v_cndmask_b32_e32 v1, v20, v3, vcc_lo                      // 000000723798: 02020714
	s_delay_alu instid0(VALU_DEP_1)                            // 00000072379C: BF870001
	v_add_co_ci_u32_e64 v25, null, v21, v4, s0                 // 0000007237A0: D5207C19 00020915
	s_clause 0x1                                               // 0000007237A8: BF850001
	global_load_b128 v[1:4], v[1:2], off                       // 0000007237AC: DC5E0000 017C0001
	global_load_d16_b16 v9, v[24:25], off                      // 0000007237B4: DC820000 097C0018
	s_branch 65260                                             // 0000007237BC: BFA0FEEC <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi1ELi32ELi2ELb1EEEvPKhPKtPvll+0x170>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007237C0: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007237C4: BF8700B9
	s_or_b32 exec_lo, exec_lo, s1                              // 0000007237C8: 8C7E017E
	.long 0xd71f0001                                           // 0000007237CC: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000007237D0: 020100C1
	s_mov_b32 s0, exec_lo                                      // 0000007237D4: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 0000007237D8: 3A040290
	v_xor_b32_e32 v3, 8, v1                                    // 0000007237DC: 3A060288
	v_xor_b32_e32 v4, 4, v1                                    // 0000007237E0: 3A080284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000007237E4: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000007237E8: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 0000007237EC: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v3                            // 0000007237F0: 7C9806A0
	v_cndmask_b32_e32 v3, v1, v3, vcc_lo                       // 0000007237F4: 02060701
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 0000007237F8: 7C9808A0
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo                       // 0000007237FC: 02080901
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000723800: BF870211
	v_lshlrev_b32_e32 v4, 2, v4                                // 000000723804: 30080882
	v_lshlrev_b32_e32 v3, 2, v3                                // 000000723808: 30060682
	v_lshlrev_b32_e32 v2, 2, v2                                // 00000072380C: 30040482
	ds_bpermute_b32 v2, v2, v17                                // 000000723810: DACC0000 02001102
	s_waitcnt lgkmcnt(0)                                       // 000000723818: BF89FC07
	v_add_f32_e32 v2, v17, v2                                  // 00000072381C: 06040511
	ds_bpermute_b32 v3, v3, v2                                 // 000000723820: DACC0000 03000203
	s_waitcnt lgkmcnt(0)                                       // 000000723828: BF89FC07
	v_add_f32_e32 v2, v2, v3                                   // 00000072382C: 06040702
	ds_bpermute_b32 v3, v4, v2                                 // 000000723830: DACC0000 03000204
	v_xor_b32_e32 v4, 2, v1                                    // 000000723838: 3A080282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000072383C: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 000000723840: 7C9808A0
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo                       // 000000723844: 02080901
	v_lshlrev_b32_e32 v4, 2, v4                                // 000000723848: 30080882
	s_waitcnt lgkmcnt(0)                                       // 00000072384C: BF89FC07
	v_add_f32_e32 v2, v2, v3                                   // 000000723850: 06040702
	ds_bpermute_b32 v3, v4, v2                                 // 000000723854: DACC0000 03000204
	v_xor_b32_e32 v4, 1, v1                                    // 00000072385C: 3A080281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000723860: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 000000723864: 7C9808A0
	s_waitcnt lgkmcnt(0)                                       // 000000723868: BF89FC07
	v_dual_cndmask_b32 v4, v1, v4 :: v_dual_add_f32 v1, v2, v3 // 00000072386C: CA480901 04000702
	v_lshlrev_b32_e32 v2, 2, v4                                // 000000723874: 30040882
	ds_bpermute_b32 v2, v2, v1                                 // 000000723878: DACC0000 02000102
	v_cmpx_eq_u32_e32 0, v16                                   // 000000723880: 7D942080
	s_cbranch_execz 8                                          // 000000723884: BFA50008 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi1ELi32ELi2ELb1EEEvPKhPKtPvll+0x6a8>
	v_lshlrev_b32_e32 v3, 2, v15                               // 000000723888: 30061E82
	s_waitcnt lgkmcnt(0)                                       // 00000072388C: BF89FC07
	v_add_f32_e32 v1, v1, v2                                   // 000000723890: 06020501
	s_delay_alu instid0(VALU_DEP_2)                            // 000000723894: BF870002
	v_lshl_or_b32 v2, v14, 3, v3                               // 000000723898: D6560002 040D070E
	ds_store_b32 v2, v1                                        // 0000007238A0: D8340000 00000102
	s_or_b32 exec_lo, exec_lo, s0                              // 0000007238A8: 8C7E007E
	v_or_b32_e32 v1, s2, v0                                    // 0000007238AC: 38020002
	s_waitcnt lgkmcnt(0)                                       // 0000007238B0: BF89FC07
	v_mov_b32_e32 v2, s3                                       // 0000007238B4: 7E040203
	.long 0xd44c0000                                           // 0000007238B8: D44C0000
	v_cndmask_b32_e32 v1, 4, v0, vcc_lo                        // 0000007238BC: 02020084
	s_waitcnt vmcnt(0)                                         // 0000007238C0: BF8903F7
	s_barrier                                                  // 0000007238C4: BFBD0000
	buffer_gl0_inv                                             // 0000007238C8: E0AC0000 00000000
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 0000007238D0: 7CA8020C
	s_and_b32 s0, s0, vcc_lo                                   // 0000007238D4: 8B006A00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000007238D8: BF870009
	s_and_saveexec_b32 s1, s0                                  // 0000007238DC: BE812000
	s_cbranch_execz 16                                         // 0000007238E0: BFA50010 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi1ELi32ELi2ELb1EEEvPKhPKtPvll+0x724>
	v_lshlrev_b32_e32 v0, 3, v0                                // 0000007238E4: 30000083
	ds_load_b64 v[3:4], v0                                     // 0000007238E8: D9D80000 03000000
	.long 0xd73c0000                                           // 0000007238F0: D73C0000
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000007238F4: 02020282
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007238F8: BF870091
	.long 0xd7006a00                                           // 0000007238FC: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 000000723900: 02020008
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 000000723904: D5207C01 01AA0209
	s_waitcnt lgkmcnt(0)                                       // 00000072390C: BF89FC07
	v_add_f32_e32 v3, 0, v3                                    // 000000723910: 06060680
	s_delay_alu instid0(VALU_DEP_1)                            // 000000723914: BF870001
	v_add_f32_e32 v2, v3, v4                                   // 000000723918: 06040903
	global_store_b32 v[0:1], v2, off                           // 00000072391C: DC6A0000 007C0200
	s_endpgm                                                   // 000000723924: BFB00000
		...

