0000000000df4400 <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi2EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi>:
; _ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi2EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi():
	s_clause 0x1                                               // 000000DF4400: BF850001
	s_load_b32 s3, s[0:1], 0xa0                                // 000000DF4404: F40000C0 F80000A0
	s_load_b512 s[12:27], s[0:1], 0x40                         // 000000DF440C: F4100300 F8000040
	s_mov_b32 s4, -1                                           // 000000DF4414: BE8400C1
	s_waitcnt lgkmcnt(0)                                       // 000000DF4418: BF89FC07
	s_cmp_lt_i32 s2, s3                                        // 000000DF441C: BF040302
	s_cbranch_scc1 2427                                        // 000000DF4420: BFA2097B <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi2EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x2610>
	s_load_b64 s[10:11], s[0:1], 0x94                          // 000000DF4424: F4040280 F8000094
	s_sub_i32 s3, s2, s3                                       // 000000DF442C: 81830302
	s_clause 0x1                                               // 000000DF4430: BF850001
	s_load_b128 s[28:31], s[0:1], 0x88                         // 000000DF4434: F4080700 F8000088
	s_load_b64 s[36:37], s[0:1], 0x80                          // 000000DF443C: F4040900 F8000080
	v_lshrrev_b32_e32 v11, 5, v0                               // 000000DF4444: 32160085
	v_and_b32_e32 v12, 31, v0                                  // 000000DF4448: 3618009F
	s_mov_b32 s41, 0                                           // 000000DF444C: BEA90080
	s_mov_b32 s40, exec_lo                                     // 000000DF4450: BEA8007E
	s_waitcnt lgkmcnt(0)                                       // 000000DF4454: BF89FC07
	s_abs_i32 s4, s11                                          // 000000DF4458: BE84150B
	s_ashr_i32 s7, s11, 31                                     // 000000DF445C: 86079F0B
	s_cvt_f32_u32 s5, s4                                       // 000000DF4460: BE856504
	s_sub_i32 s6, 0, s4                                        // 000000DF4464: 81860480
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000DF4468: BF87029A
	v_rcp_iflag_f32_e32 v1, s5                                 // 000000DF446C: 7E025605
	v_readfirstlane_b32 s5, v1                                 // 000000DF4470: 7E0A0501
	s_mul_f32 s5, s5, 0x4f7ffffe                               // 000000DF4474: A205FF05 4F7FFFFE
	s_delay_alu instid0(SALU_CYCLE_3) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 000000DF447C: BF87059B
	s_cvt_u32_f32 s5, s5                                       // 000000DF4480: BE856705
	s_mul_i32 s6, s6, s5                                       // 000000DF4484: 96060506
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000DF4488: BF870499
	s_mul_hi_u32 s6, s5, s6                                    // 000000DF448C: 96860605
	s_add_i32 s5, s5, s6                                       // 000000DF4490: 81050605
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000DF4494: BF870499
	s_mul_hi_u32 s5, s3, s5                                    // 000000DF4498: 96850503
	s_mul_i32 s6, s5, s4                                       // 000000DF449C: 96060405
	s_add_i32 s8, s5, 1                                        // 000000DF44A0: 81088105
	s_sub_i32 s6, s3, s6                                       // 000000DF44A4: 81860603
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000DF44A8: BF870009
	s_sub_i32 s9, s6, s4                                       // 000000DF44AC: 81890406
	s_cmp_ge_u32 s6, s4                                        // 000000DF44B0: BF090406
	s_cselect_b32 s5, s8, s5                                   // 000000DF44B4: 98050508
	s_cselect_b32 s6, s9, s6                                   // 000000DF44B8: 98060609
	s_add_i32 s8, s5, 1                                        // 000000DF44BC: 81088105
	s_cmp_ge_u32 s6, s4                                        // 000000DF44C0: BF090406
	s_cselect_b32 s4, s8, s5                                   // 000000DF44C4: 98040508
	s_ashr_i32 s33, s30, 31                                    // 000000DF44C8: 86219F1E
	s_xor_b32 s4, s4, s7                                       // 000000DF44CC: 8D040704
	s_lshr_b32 s5, s33, 25                                     // 000000DF44D0: 85059921
	s_sub_i32 s34, s4, s7                                      // 000000DF44D4: 81A20704
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000DF44D8: BF870499
	s_mul_i32 s4, s34, s11                                     // 000000DF44DC: 96040B22
	s_sub_i32 s31, s3, s4                                      // 000000DF44E0: 819F0403
	s_add_i32 s3, s30, s5                                      // 000000DF44E4: 8103051E
	s_mul_i32 s35, s31, s10                                    // 000000DF44E8: 96230A1F
	s_ashr_i32 s3, s3, 7                                       // 000000DF44EC: 86038703
	s_add_i32 s4, s35, s10                                     // 000000DF44F0: 81040A23
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000DF44F4: BF870499
	s_min_i32 s3, s3, s4                                       // 000000DF44F8: 89030403
	s_sub_i32 s39, s3, s35                                     // 000000DF44FC: 81A72303
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000DF4500: BF870499
	s_lshl_b32 s38, s39, 1                                     // 000000DF4504: 84268127
	.long 0xd4c4007e                                           // 000000DF4508: D4C4007E
	v_cndmask_b32_e32 v1, s38, v11, vcc_lo                     // 000000DF450C: 02021626
	s_cbranch_execz 505                                        // 000000DF4510: BFA501F9 <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi2EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x8f8>
	s_add_i32 s42, s28, -1                                     // 000000DF4514: 812AC11C
	s_cmp_lg_u64 s[22:23], 0                                   // 000000DF4518: BF118016
	v_dual_mov_b32 v8, v11 :: v_dual_and_b32 v1, 1, v0         // 000000DF451C: CA24010B 08000081
	s_cselect_b32 s43, -1, 0                                   // 000000DF4524: 982B80C1
	s_abs_i32 s44, s39                                         // 000000DF4528: BEAC1527
	v_and_b32_e32 v2, 2, v0                                    // 000000DF452C: 36040082
	s_cvt_f32_u32 s3, s44                                      // 000000DF4530: BE83652C
	v_lshlrev_b32_e32 v6, 3, v12                               // 000000DF4534: 300C1883
	v_lshlrev_b32_e32 v7, 7, v11                               // 000000DF4538: 300E1687
	v_and_b32_e32 v3, 4, v0                                    // 000000DF453C: 36060084
	v_rcp_iflag_f32_e32 v4, s3                                 // 000000DF4540: 7E085603
	v_and_b32_e32 v5, 8, v0                                    // 000000DF4544: 360A0088
	.long 0xd44a0004                                           // 000000DF4548: D44A0004
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000DF454C: 02020280
	.long 0xd44a0005                                           // 000000DF4550: D44A0005
	v_cndmask_b32_e32 v1, 0, v2, vcc_lo                        // 000000DF4554: 02020480
	v_lshl_or_b32 v1, v11, 8, v6                               // 000000DF4558: D6560001 0419110B
	v_lshl_add_u32 v2, s35, 7, v7                              // 000000DF4560: D6460002 041D0E23
	s_ashr_i32 s46, s39, 31                                    // 000000DF4568: 862E9F27
	s_sub_i32 s48, 0, s44                                      // 000000DF456C: 81B02C80
	s_mul_i32 s10, s46, 0x1400                                 // 000000DF4570: 960AFF2E 00001400
	.long 0xd44c0003                                           // 000000DF4578: D44C0003
	v_cndmask_b32_e32 v1, 16, v12, vcc_lo                      // 000000DF457C: 02021890
	v_readfirstlane_b32 s7, v4                                 // 000000DF4580: 7E0E0504
	.long 0xd44a0006                                           // 000000DF4584: D44A0006
	v_cndmask_b32_e32 v1, 0, v3, vcc_lo                        // 000000DF4588: 02020680
	v_subrev_nc_u32_e32 v9, s10, v1                            // 000000DF458C: 4E12020A
	v_lshl_or_b32 v1, v12, 2, v2                               // 000000DF4590: D6560001 0409050C
	s_lshl_b32 s8, s39, 7                                      // 000000DF4598: 84088727
	s_mul_f32 s9, s7, 0x4f7ffffe                               // 000000DF459C: A209FF07 4F7FFFFE
	.long 0xd44a0007                                           // 000000DF45A4: D44A0007
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 000000DF45A8: 02020A80
	s_mov_b32 s45, 0x76543210                                  // 000000DF45AC: BEAD00FF 76543210
	s_lshl_b32 s47, s39, 8                                     // 000000DF45B4: 842F8827
	s_cvt_u32_f32 s9, s9                                       // 000000DF45B8: BE896709
	s_mov_b32 s50, 0x3db504f3                                  // 000000DF45BC: BEB200FF 3DB504F3
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000DF45C4: BF87049A
	s_mul_i32 s48, s48, s9                                     // 000000DF45C8: 96300930
	s_mul_hi_u32 s10, s9, s48                                  // 000000DF45CC: 968A3009
	s_sub_i32 s48, 0, s8                                       // 000000DF45D0: 81B00880
	s_add_i32 s49, s9, s10                                     // 000000DF45D4: 81310A09
	s_branch 166                                               // 000000DF45D8: BFA000A6 <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi2EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x474>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF45DC: BF870091
	.long 0xd7006a02                                           // 000000DF45E0: D7006A02
	v_cndmask_b32_e32 v1, s16, v2, vcc_lo                      // 000000DF45E4: 02020410
	v_add_co_ci_u32_e64 v3, null, s17, v3, vcc_lo              // 000000DF45E8: D5207C03 01AA0611
	v_add_nc_u32_e32 v1, 0x400, v1                             // 000000DF45F0: 4A0202FF 00000400
	v_add_nc_u32_e32 v8, 8, v8                                 // 000000DF45F8: 4A101088
	global_load_d16_b16 v2, v[2:3], off offset:6               // 000000DF45FC: DC820006 027C0002
	v_cmp_le_i32_e32 vcc_lo, s38, v8                           // 000000DF4604: 7C861026
	s_or_b32 s41, vcc_lo, s41                                  // 000000DF4608: 8C29296A
	s_waitcnt vmcnt(0)                                         // 000000DF460C: BF8903F7
	v_fma_mix_f32 v5, v16, v2, v14 op_sel_hi:[0,1,0]           // 000000DF4610: CC200005 143A0510
	v_sub_f32_e32 v4, v17, v15                                 // 000000DF4618: 08081F11
	v_fma_mix_f32 v2, -v16, v2, v14 op_sel_hi:[0,1,0]          // 000000DF461C: CC200002 343A0510
	v_add_f32_e32 v3, v17, v15                                 // 000000DF4624: 06061F11
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DF4628: BF8701A2
	v_add_f32_e32 v7, v4, v2                                   // 000000DF462C: 060E0504
	v_sub_f32_e32 v2, v4, v2                                   // 000000DF4630: 08040504
	v_add_f32_e32 v6, v3, v5                                   // 000000DF4634: 060C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 000000DF4638: 08060B03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF463C: BF870193
	v_mov_b32_dpp v15, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DF4640: 7E1E02FA FF016102
	v_mov_b32_dpp v4, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DF4648: 7E0802FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s4                          // 000000DF4650: D5010006 20120D06
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000DF4658: BF870234
	v_mov_b32_dpp v14, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DF465C: 7E1C02FA FF016103
	v_cndmask_b32_e64 v2, -v2, v2, s4                          // 000000DF4664: D5010002 20120502
	v_cndmask_b32_e64 v3, -v3, v3, s4                          // 000000DF466C: D5010003 20120703
	v_add_f32_e32 v4, v6, v4                                   // 000000DF4674: 06080906
	v_mov_b32_dpp v5, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DF4678: 7E0A02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s4                          // 000000DF4680: D5010007 20120F07
	.long 0xd72c0006                                           // 000000DF4688: D72C0006
	v_cndmask_b32_e32 v1, 0x1400, v13, vcc_lo                  // 000000DF468C: 02021AFF 00001400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000DF4694: BF870242
	v_dual_add_f32 v2, v2, v15 :: v_dual_add_f32 v5, v7, v5    // 000000DF4698: C9081F02 02040B07
	v_mov_b32_dpp v7, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DF46A0: 7E0E02FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s5                          // 000000DF46A8: D5010004 20160904
	v_add_f32_e32 v3, v3, v14                                  // 000000DF46B0: 06061D03
	v_mov_b32_dpp v15, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DF46B4: 7E1E02FA FF016202
	v_mov_b32_dpp v13, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DF46BC: 7E1A02FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s5                          // 000000DF46C4: D5010005 20160B05
	v_cndmask_b32_e64 v2, -v2, v2, s5                          // 000000DF46CC: D5010002 20160502
	v_add_f32_e32 v4, v4, v7                                   // 000000DF46D4: 06080F04
	v_mov_b32_dpp v14, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DF46D8: 7E1C02FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s5                          // 000000DF46E0: D5010003 20160703
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000DF46E8: BF870234
	v_dual_add_f32 v5, v5, v13 :: v_dual_add_f32 v2, v2, v15   // 000000DF46EC: C9081B05 05021F02
	.long 0xd72c0007                                           // 000000DF46F4: D72C0007
	v_cndmask_b32_e32 v1, s47, v10, vcc_lo                     // 000000DF46F8: 0202142F
	v_mov_b32_dpp v10, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DF46FC: 7E1402FA FF016404
	v_add_f32_e32 v3, v3, v14                                  // 000000DF4704: 06061D03
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DF4708: BF870004
	v_mov_b32_dpp v13, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DF470C: 7E1A02FA FF016405
	v_cndmask_b32_e64 v4, -v4, v4, s6                          // 000000DF4714: D5010004 201A0904
	v_cndmask_b32_e64 v5, -v5, v5, s6                          // 000000DF471C: D5010005 201A0B05
	v_mov_b32_dpp v15, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DF4724: 7E1E02FA FF016402
	v_mov_b32_dpp v14, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DF472C: 7E1C02FA FF016403
	v_cndmask_b32_e64 v2, -v2, v2, s6                          // 000000DF4734: D5010002 201A0502
	v_cndmask_b32_e64 v3, -v3, v3, s6                          // 000000DF473C: D5010003 201A0703
	v_dual_add_f32 v4, v4, v10 :: v_dual_add_f32 v5, v5, v13   // 000000DF4744: C9081504 04041B05
	v_sub_nc_u32_e32 v6, v6, v7                                // 000000DF474C: 4C0C0F06
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF4750: BF870193
	v_dual_add_f32 v2, v2, v15 :: v_dual_add_f32 v3, v3, v14   // 000000DF4754: C9081F02 02021D03
	v_mov_b32_dpp v10, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DF475C: 7E1402FA FF016804
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DF4764: BF870004
	v_mov_b32_dpp v13, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DF4768: 7E1A02FA FF016805
	v_cndmask_b32_e64 v4, -v4, v4, s7                          // 000000DF4770: D5010004 201E0904
	v_cndmask_b32_e64 v5, -v5, v5, s7                          // 000000DF4778: D5010005 201E0B05
	v_mov_b32_dpp v14, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DF4780: 7E1C02FA FF016803
	v_mov_b32_dpp v15, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DF4788: 7E1E02FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s7                          // 000000DF4790: D5010002 201E0502
	v_cndmask_b32_e64 v3, -v3, v3, s7                          // 000000DF4798: D5010003 201E0703
	v_dual_add_f32 v4, v4, v10 :: v_dual_add_f32 v5, v5, v13   // 000000DF47A0: C9081504 04041B05
	v_add_nc_u32_e32 v6, v9, v6                                // 000000DF47A8: 4A0C0D09
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF47AC: BF870193
	v_dual_add_f32 v2, v2, v15 :: v_dual_add_f32 v3, v3, v14   // 000000DF47B0: C9081F02 02021D03
	v_dual_mov_b32 v10, v4 :: v_dual_mov_b32 v13, v5           // 000000DF47B8: CA100104 0A0C0105
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 000000DF47C0: D5010005 200E0B05
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DF47C8: BF870003
	v_mov_b32_e32 v15, v2                                      // 000000DF47CC: 7E1E0302
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000DF47D0: D5010004 200E0904
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 000000DF47D8: D5010002 200E0502
	v_permlanex16_b32 v13, v13, s45, 0xfedcba98                // 000000DF47E0: D65C000D 03FC5B0D FEDCBA98
	v_mov_b32_e32 v14, v3                                      // 000000DF47EC: 7E1C0303
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 000000DF47F0: D5010003 200E0703
	v_permlanex16_b32 v10, v10, s45, 0xfedcba98                // 000000DF47F8: D65C000A 03FC5B0A FEDCBA98
	v_permlanex16_b32 v15, v15, s45, 0xfedcba98                // 000000DF4804: D65C000F 03FC5B0F FEDCBA98
	v_add_f32_e32 v5, v5, v13                                  // 000000DF4810: 060A1B05
	v_permlanex16_b32 v14, v14, s45, 0xfedcba98                // 000000DF4814: D65C000E 03FC5B0E FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DF4820: BF870214
	v_dual_add_f32 v4, v4, v10 :: v_dual_add_nc_u32 v9, 0x800, v9// 000000DF4824: C9201504 040812FF 00000800
	v_add_f32_e32 v7, v2, v15                                  // 000000DF4830: 060E1F02
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DF4834: BF870214
	v_fma_mixhi_f16 v2, v5, s50, 0                             // 000000DF4838: CC220002 02006505
	v_add_f32_e32 v10, v3, v14                                 // 000000DF4840: 06141D03
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DF4844: BF870214
	v_fma_mixlo_f16 v2, v4, s50, 0                             // 000000DF4848: CC210002 02006504
	v_fma_mixhi_f16 v3, v7, s50, 0                             // 000000DF4850: CC220003 02006507
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DF4858: BF870003
	v_fma_mixlo_f16 v3, v10, s50, 0                            // 000000DF485C: CC210003 0200650A
	ds_store_b64 v6, v[2:3]                                    // 000000DF4864: D9340000 00000206
	s_and_not1_b32 exec_lo, exec_lo, s41                       // 000000DF486C: 917E297E
	s_cbranch_execz 289                                        // 000000DF4870: BFA50121 <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi2EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x8f8>
	.long 0xd72d0002                                           // 000000DF4874: D72D0002
	v_cndmask_b32_e32 v0, v8, v49, vcc_lo                      // 000000DF4878: 02006308
	s_mov_b32 s8, -1                                           // 000000DF487C: BE8800C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF4880: BF870091
	.long 0xd72c0003                                           // 000000DF4884: D72C0003
	v_cndmask_b32_e32 v0, v2, v44, vcc_lo                      // 000000DF4888: 02005902
	v_sub_nc_u32_e32 v3, v8, v3                                // 000000DF488C: 4C060708
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DF4890: BF870121
	v_subrev_nc_u32_e32 v5, s44, v3                            // 000000DF4894: 4E0A062C
	v_cmp_le_u32_e32 vcc_lo, s44, v3                           // 000000DF4898: 7C96062C
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_add_nc_u32 v4, 1, v2// 000000DF489C: CA600B03 03040481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF48A4: BF870111
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000DF48A8: 02040902
	v_cmp_le_u32_e32 vcc_lo, s44, v3                           // 000000DF48AC: 7C96062C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF48B0: BF870092
	v_add_nc_u32_e32 v4, 1, v2                                 // 000000DF48B4: 4A080481
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000DF48B8: 02040902
	s_and_not1_b32 vcc_lo, exec_lo, s43                        // 000000DF48BC: 916A2B7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF48C0: BF870091
	v_xor_b32_e32 v13, s46, v2                                 // 000000DF48C4: 3A1A042E
	v_subrev_nc_u32_e32 v10, s46, v13                          // 000000DF48C8: 4E141A2E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DF48CC: BF8700A1
	v_mad_u64_u32 v[6:7], null, s48, v10, v[1:2]               // 000000DF48D0: D6FE7C06 04061430
	v_min_i32_e32 v2, s42, v10                                 // 000000DF48D8: 2204142A
	v_mad_i64_i32 v[4:5], null, v2, s30, 0                     // 000000DF48DC: D6FF7C04 02003D02
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF48E4: BF870093
	v_ashrrev_i32_e32 v7, 31, v6                               // 000000DF48E8: 340E0C9F
	.long 0xd73c0002                                           // 000000DF48EC: D73C0002
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000DF48F0: 02020C81
	s_cbranch_vccnz 212                                        // 000000DF48F4: BFA400D4 <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi2EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x848>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF48F8: BF870093
	.long 0xd7006a06                                           // 000000DF48FC: D7006A06
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 000000DF4900: 02020D04
	v_add_co_ci_u32_e64 v7, null, v5, v7, vcc_lo               // 000000DF4904: D5207C07 01AA0F05
	.long 0x7f3c3880                                           // 000000DF490C: 7F3C3880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF4910: BF870112
	.long 0xd73c0006                                           // 000000DF4914: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000DF4918: 02020C81
	.long 0x7f42399e                                           // 000000DF491C: 7F42399E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF4920: BF870092
	.long 0xd7006a0e                                           // 000000DF4924: D7006A0E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 000000DF4928: 02020C14
	v_add_co_ci_u32_e64 v15, null, s21, v7, vcc_lo             // 000000DF492C: D5207C0F 01AA0E15
	.long 0xd7006a06                                           // 000000DF4934: D7006A06
	v_cndmask_b32_e32 v1, s22, v6, vcc_lo                      // 000000DF4938: 02020C16
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DF493C: BF870001
	v_add_co_ci_u32_e64 v7, null, s23, v7, vcc_lo              // 000000DF4940: D5207C07 01AA0E17
	global_load_b64 v[14:15], v[14:15], off                    // 000000DF4948: DC560000 0E7C000E
	.long 0xd7006a10                                           // 000000DF4950: D7006A10
	v_cndmask_b32_e32 v1, s16, v2, vcc_lo                      // 000000DF4954: 02020410
	global_load_b64 v[6:7], v[6:7], off                        // 000000DF4958: DC560000 067C0006
	v_add_co_ci_u32_e64 v17, null, s17, v3, vcc_lo             // 000000DF4960: D5207C11 01AA0611
	s_clause 0x1                                               // 000000DF4968: BF850001
	global_load_b32 v18, v[16:17], off                         // 000000DF496C: DC520000 127C0010
	global_load_d16_b16 v16, v[16:17], off offset:4            // 000000DF4974: DC820004 107C0010
	s_waitcnt vmcnt(3)                                         // 000000DF497C: BF890FF7
	.long 0x7e22390e                                           // 000000DF4980: 7E22390E
	s_waitcnt vmcnt(2)                                         // 000000DF4984: BF890BF7
	v_and_b32_e32 v40, 0xffff0000, v6                          // 000000DF4988: 36500CFF FFFF0000
	v_lshlrev_b32_e32 v6, 16, v6                               // 000000DF4990: 300C0C90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF4994: BF870093
	v_lshlrev_b32_e32 v17, 16, v17                             // 000000DF4998: 30222290
	v_mul_f32_e32 v21, 0xbfb8aa3b, v17                         // 000000DF499C: 102A22FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000DF49A4: BF870291
	v_exp_f32_e32 v21, v21                                     // 000000DF49A8: 7E2A4B15
	v_dual_add_f32 v21, 1.0, v21 :: v_dual_and_b32 v14, 0xffff0000, v14// 000000DF49AC: C9242AF2 150E1CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF49B8: BF870111
	v_mul_f32_e32 v20, 0xbfb8aa3b, v14                         // 000000DF49BC: 10281CFF BFB8AA3B
	v_div_scale_f32 v25, null, v21, v21, v17                   // 000000DF49C4: D6FC7C19 04462B15
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000DF49CC: BF8701B2
	v_exp_f32_e32 v20, v20                                     // 000000DF49D0: 7E284B14
	v_lshlrev_b32_e32 v19, 16, v15                             // 000000DF49D4: 30261E90
	v_div_scale_f32 v38, s9, v17, v21, v17                     // 000000DF49D8: D6FC0926 04462B11
	v_rcp_f32_e32 v29, v25                                     // 000000DF49E0: 7E3A5519
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF49E4: BF870196
	v_add_f32_e32 v20, 1.0, v20                                // 000000DF49E8: 062828F2
	v_mul_f32_e32 v22, 0xbfb8aa3b, v19                         // 000000DF49EC: 102C26FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF49F4: BF870195
	v_fma_f32 v37, -v25, v29, 1.0                              // 000000DF49F8: D6130025 23CA3B19
	v_div_scale_f32 v24, null, v20, v20, v14                   // 000000DF4A00: D6FC7C18 043A2914
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000DF4A08: BF8701B3
	v_exp_f32_e32 v22, v22                                     // 000000DF4A0C: 7E2C4B16
	v_and_b32_e32 v15, 0xffff0000, v15                         // 000000DF4A10: 361E1EFF FFFF0000
	v_div_scale_f32 v34, vcc_lo, v14, v20, v14                 // 000000DF4A18: D6FC6A22 043A290E
	v_rcp_f32_e32 v27, v24                                     // 000000DF4A20: 7E365518
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_2)   // 000000DF4A24: BF870106
	v_dual_add_f32 v22, 1.0, v22 :: v_dual_mul_f32 v23, 0xbfb8aa3b, v15// 000000DF4A28: C9062CF2 16161EFF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF4A34: BF870115
	v_fma_f32 v35, -v24, v27, 1.0                              // 000000DF4A38: D6130023 23CA3718
	v_div_scale_f32 v26, null, v22, v22, v19                   // 000000DF4A40: D6FC7C1A 044E2D16
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DF4A48: BF8701A3
	v_exp_f32_e32 v23, v23                                     // 000000DF4A4C: 7E2E4B17
	v_div_scale_f32 v36, s8, v19, v22, v19                     // 000000DF4A50: D6FC0824 044E2D13
	v_fmac_f32_e32 v27, v35, v27                               // 000000DF4A58: 56363723
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000DF4A5C: BF870313
	v_rcp_f32_e32 v31, v26                                     // 000000DF4A60: 7E3E551A
	v_add_f32_e32 v23, 1.0, v23                                // 000000DF4A64: 062E2EF2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF4A68: BF870115
	v_fma_f32 v39, -v26, v31, 1.0                              // 000000DF4A6C: D6130027 23CA3F1A
	v_div_scale_f32 v28, null, v23, v23, v15                   // 000000DF4A74: D6FC7C1C 043E2F17
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DF4A7C: BF8701A2
	v_fmac_f32_e32 v31, v39, v31                               // 000000DF4A80: 563E3F27
	v_mul_f32_e32 v39, v34, v27                                // 000000DF4A84: 104E3722
	v_rcp_f32_e32 v32, v28                                     // 000000DF4A88: 7E40551C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF4A8C: BF870091
	v_fma_f32 v42, -v24, v39, v34                              // 000000DF4A90: D613002A 248A4F18
	v_fmac_f32_e32 v39, v42, v27                               // 000000DF4A98: 564E372A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF4A9C: BF870115
	v_fma_f32 v35, -v28, v32, 1.0                              // 000000DF4AA0: D6130023 23CA411C
	v_fma_f32 v24, -v24, v39, v34                              // 000000DF4AA8: D6130018 248A4F18
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF4AB0: BF870112
	v_fmac_f32_e32 v32, v35, v32                               // 000000DF4AB4: 56404123
	v_div_fmas_f32 v24, v24, v27, v39                          // 000000DF4AB8: D6370018 049E3718
	s_mov_b32 vcc_lo, s9                                       // 000000DF4AC0: BEEA0009
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000DF4AC4: BF8701B1
	v_div_fixup_f32 v14, v24, v20, v14                         // 000000DF4AC8: D627000E 043A2918
	v_fmac_f32_e32 v29, v37, v29                               // 000000DF4AD0: 563A3B25
	v_div_scale_f32 v37, s10, v15, v23, v15                    // 000000DF4AD4: D6FC0A25 043E2F0F
	v_mul_f32_e32 v14, v14, v40                                // 000000DF4ADC: 101C510E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF4AE0: BF870193
	v_mul_f32_e32 v35, v38, v29                                // 000000DF4AE4: 10463B26
	v_mul_f32_e32 v43, v37, v32                                // 000000DF4AE8: 10564125
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF4AEC: BF870193
	.long 0x7e3c398e                                           // 000000DF4AF0: 7E3C398E
	v_fma_f32 v44, -v25, v35, v38                              // 000000DF4AF4: D613002C 249A4719
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF4AFC: BF870113
	v_fma_f32 v42, -v28, v43, v37                              // 000000DF4B00: D613002A 2496571C
	v_fmac_f32_e32 v35, v44, v29                               // 000000DF4B08: 56463B2C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF4B0C: BF870112
	v_fmac_f32_e32 v43, v42, v32                               // 000000DF4B10: 5656412A
	v_fma_f32 v25, -v25, v35, v38                              // 000000DF4B14: D6130019 249A4719
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF4B1C: BF870112
	v_fma_f32 v24, -v28, v43, v37                              // 000000DF4B20: D6130018 2496571C
	v_div_fmas_f32 v25, v25, v29, v35                          // 000000DF4B28: D6370019 048E3B19
	s_mov_b32 vcc_lo, s8                                       // 000000DF4B30: BEEA0008
	s_mov_b32 s8, 0                                            // 000000DF4B34: BE880080
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DF4B38: BF870121
	v_div_fixup_f32 v17, v25, v21, v17                         // 000000DF4B3C: D6270011 04462B19
	v_lshlrev_b32_e32 v21, 16, v7                              // 000000DF4B44: 302A0E90
	v_dual_mul_f32 v6, v17, v6 :: v_dual_and_b32 v7, 0xffff0000, v7// 000000DF4B48: C8E40D11 06060EFF FFFF0000
	v_mul_f32_e32 v41, v36, v31                                // 000000DF4B54: 10523F24
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF4B58: BF870112
	.long 0x7e423986                                           // 000000DF4B5C: 7E423986
	v_fma_f32 v45, -v26, v41, v36                              // 000000DF4B60: D613002D 2492531A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF4B68: BF870091
	v_fmac_f32_e32 v41, v45, v31                               // 000000DF4B6C: 56523F2D
	v_fma_f32 v26, -v26, v41, v36                              // 000000DF4B70: D613001A 2492531A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000DF4B78: BF870131
	v_div_fmas_f32 v20, v26, v31, v41                          // 000000DF4B7C: D6370014 04A63F1A
	s_mov_b32 vcc_lo, s10                                      // 000000DF4B84: BEEA000A
	v_div_fmas_f32 v17, v24, v32, v43                          // 000000DF4B88: D6370011 04AE4118
	v_div_fixup_f32 v19, v20, v22, v19                         // 000000DF4B90: D6270013 044E2D14
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DF4B98: BF8701A2
	v_div_fixup_f32 v15, v17, v23, v15                         // 000000DF4B9C: D627000F 043E2F11
	v_and_b32_e32 v17, 1, v30                                  // 000000DF4BA4: 36223C81
	v_mul_f32_e32 v19, v19, v21                                // 000000DF4BA8: 10262B13
	v_and_b32_e32 v21, 1, v33                                  // 000000DF4BAC: 362A4281
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DF4BB0: BF870214
	v_mul_f32_e32 v7, v15, v7                                  // 000000DF4BB4: 100E0F0F
	v_add3_u32 v14, v14, v17, 0x7fff                           // 000000DF4BB8: D655000E 03FE230E 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DF4BC4: BF870214
	v_bfe_u32 v20, v19, 16, 1                                  // 000000DF4BC8: D6100014 02052113
	v_add3_u32 v6, v6, v21, 0x7fff                             // 000000DF4BD0: D6550006 03FE2B06 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DF4BDC: BF870214
	v_bfe_u32 v17, v7, 16, 1                                   // 000000DF4BE0: D6100011 02052107
	v_and_b32_e32 v14, 0xffff0000, v14                         // 000000DF4BE8: 361C1CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DF4BF0: BF870214
	v_add3_u32 v15, v19, v20, 0x7fff                           // 000000DF4BF4: D655000F 03FE2913 00007FFF
	v_and_b32_e32 v6, 0xffff0000, v6                           // 000000DF4C00: 360C0CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF4C08: BF870194
	v_add3_u32 v7, v7, v17, 0x7fff                             // 000000DF4C0C: D6550007 03FE2307 00007FFF
	v_and_b32_e32 v19, 0xffff0000, v15                         // 000000DF4C18: 36261EFF FFFF0000
	s_waitcnt vmcnt(1)                                         // 000000DF4C20: BF8907F7
	v_fma_mix_f32 v15, v18, v14, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DF4C24: CC20080F 8A021D12
	v_fma_mix_f32 v17, v18, v6, neg(0) op_sel_hi:[1,0,0]       // 000000DF4C2C: CC200011 8A020D12
	s_waitcnt vmcnt(0)                                         // 000000DF4C34: BF8903F7
	v_fma_mix_f32 v14, v16, v19, neg(0) op_sel_hi:[1,0,0]      // 000000DF4C38: CC20000E 8A022710
	v_and_b32_e32 v16, 0xffff0000, v7                          // 000000DF4C40: 36200EFF FFFF0000
	s_and_not1_b32 vcc_lo, exec_lo, s8                         // 000000DF4C48: 916A087E
	s_cbranch_vccnz 65123                                      // 000000DF4C4C: BFA4FE63 <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi2EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x1dc>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF4C50: BF870093
	.long 0xd73c0004                                           // 000000DF4C54: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 000000DF4C58: 02020881
	.long 0xd7006a04                                           // 000000DF4C5C: D7006A04
	v_cndmask_b32_e32 v1, s20, v4, vcc_lo                      // 000000DF4C60: 02020814
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF4C64: BF870111
	v_add_co_ci_u32_e64 v5, null, s21, v5, vcc_lo              // 000000DF4C68: D5207C05 01AA0A15
	.long 0xd7006a04                                           // 000000DF4C70: D7006A04
	v_cndmask_b32_e32 v1, v4, v2, vcc_lo                       // 000000DF4C74: 02020504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DF4C78: BF8700A1
	v_add_co_ci_u32_e64 v5, null, v5, v3, vcc_lo               // 000000DF4C7C: D5207C05 01AA0705
	.long 0xd7006a06                                           // 000000DF4C84: D7006A06
	v_cndmask_b32_e32 v1, s16, v2, vcc_lo                      // 000000DF4C88: 02020410
	v_add_co_ci_u32_e64 v7, null, s17, v3, vcc_lo              // 000000DF4C8C: D5207C07 01AA0611
	global_load_b64 v[4:5], v[4:5], off                        // 000000DF4C94: DC560000 047C0004
	s_clause 0x1                                               // 000000DF4C9C: BF850001
	global_load_b32 v16, v[6:7], off                           // 000000DF4CA0: DC520000 107C0006
	global_load_d16_b16 v6, v[6:7], off offset:4               // 000000DF4CA8: DC820004 067C0006
	s_waitcnt vmcnt(2)                                         // 000000DF4CB0: BF890BF7
	.long 0x7e0e3904                                           // 000000DF4CB4: 7E0E3904
	v_and_b32_e32 v4, 0xffff0000, v4                           // 000000DF4CB8: 360808FF FFFF0000
	v_lshlrev_b32_e32 v14, 16, v5                              // 000000DF4CC0: 301C0A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DF4CC4: BF8701A3
	v_lshlrev_b32_e32 v7, 16, v7                               // 000000DF4CC8: 300E0E90
	s_waitcnt vmcnt(1)                                         // 000000DF4CCC: BF8907F7
	v_fma_mix_f32 v15, v16, v4, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DF4CD0: CC20080F 8A020910
	s_waitcnt vmcnt(0)                                         // 000000DF4CD8: BF8903F7
	v_fma_mix_f32 v14, v6, v14, neg(0) op_sel_hi:[1,0,0]       // 000000DF4CDC: CC20000E 8A021D06
	v_fma_mix_f32 v17, v16, v7, neg(0) op_sel_hi:[1,0,0]       // 000000DF4CE4: CC200011 8A020F10
	v_and_b32_e32 v16, 0xffff0000, v5                          // 000000DF4CEC: 36200AFF FFFF0000
	s_branch 65081                                             // 000000DF4CF4: BFA0FE39 <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi2EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x1dc>
	s_or_b32 exec_lo, exec_lo, s40                             // 000000DF4CF8: 8C7E287E
	s_bfe_i32 s38, s39, 0x1001c                                // 000000DF4CFC: 93A6FF27 0001001C
	s_lshl_b32 s6, s35, 3                                      // 000000DF4D04: 84068323
	s_lshr_b64 s[4:5], s[38:39], 29                            // 000000DF4D08: 85849D26
	s_lshr_b32 s5, s33, 28                                     // 000000DF4D0C: 85059C21
	s_add_i32 s3, s4, 7                                        // 000000DF4D10: 81038704
	s_add_i32 s5, s30, s5                                      // 000000DF4D14: 8105051E
	s_ashr_i32 s3, s3, 3                                       // 000000DF4D18: 86038303
	s_lshl_b32 s4, s39, 3                                      // 000000DF4D1C: 84048327
	.long 0xd72c0001                                           // 000000DF4D20: D72C0001
	v_cndmask_b32_e32 v1, s3, v11, vcc_lo                      // 000000DF4D24: 02021603
	v_lshlrev_b32_e32 v13, 2, v12                              // 000000DF4D28: 301A1882
	s_waitcnt lgkmcnt(0)                                       // 000000DF4D2C: BF89FC07
	s_barrier                                                  // 000000DF4D30: BFBD0000
	buffer_gl0_inv                                             // 000000DF4D34: E0AC0000 00000000
	v_add_nc_u32_e32 v2, s3, v1                                // 000000DF4D3C: 4A040203
	s_ashr_i32 s3, s5, 4                                       // 000000DF4D40: 86038405
	s_ashr_i32 s5, s6, 31                                      // 000000DF4D44: 86059F06
	s_mul_hi_i32 s7, s34, s3                                   // 000000DF4D48: 97070322
	s_mul_i32 s3, s34, s3                                      // 000000DF4D4C: 96030322
	v_min_i32_e32 v14, s4, v2                                  // 000000DF4D50: 221C0404
	s_add_u32 s4, s3, s6                                       // 000000DF4D54: 80040603
	s_addc_u32 s5, s7, s5                                      // 000000DF4D58: 82050507
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF4D5C: BF870099
	s_lshl_b64 s[4:5], s[4:5], 10                              // 000000DF4D60: 84848A04
	v_cmp_lt_i32_e32 vcc_lo, v1, v14                           // 000000DF4D64: 7C821D01
	s_add_u32 s4, s14, s4                                      // 000000DF4D68: 8004040E
	s_addc_u32 s5, s15, s5                                     // 000000DF4D6C: 8205050F
	s_and_saveexec_b32 s6, vcc_lo                              // 000000DF4D70: BE86206A
	s_cbranch_execz 93                                         // 000000DF4D74: BFA5005D <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi2EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0xaec>
	.long 0xd7010302                                           // 000000DF4D78: D7010302
	v_cndmask_b32_e32 v0, v12, v129, vcc_lo                    // 000000DF4D7C: 0201030C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DF4D80: BF870121
	v_cndmask_b32_e64 v3, v2, 31, s3                           // 000000DF4D84: D5010003 000D3F02
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000DF4D8C: 3404029F
	.long 0xd44c0003                                           // 000000DF4D90: D44C0003
	v_cndmask_b32_e32 v1, 31, v3, vcc_lo                       // 000000DF4D94: 0202069F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF4D98: BF870091
	v_cndmask_b32_e64 v5, 0xe1, 1, s3                          // 000000DF4D9C: D5010005 000D02FF 000000E1
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v7, v5, v3       // 000000DF4DA8: CA200080 04060705
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF4DB0: BF870114
	.long 0xd73c0005                                           // 000000DF4DB4: D73C0005
	v_cndmask_b32_e32 v1, 10, v1, vcc_lo                       // 000000DF4DB8: 0202028A
	.long 0xd73c0002                                           // 000000DF4DBC: D73C0002
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 000000DF4DC0: 02020682
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DF4DC4: BF870223
	v_lshlrev_b32_e32 v4, 24, v7                               // 000000DF4DC8: 30080E98
	v_bfe_i32 v8, v7, 7, 1                                     // 000000DF4DCC: D6110008 02050F07
	.long 0xd7000309                                           // 000000DF4DD4: D7000309
	v_cndmask_b32_e32 v1, s4, v5, vcc_lo                       // 000000DF4DD8: 02020A04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DF4DDC: BF870211
	v_add_co_ci_u32_e64 v10, null, s5, v6, s3                  // 000000DF4DE0: D5207C0A 000E0C05
	v_ashrrev_i32_e32 v4, 22, v4                               // 000000DF4DE8: 34080896
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF4DEC: BF870093
	.long 0xd7000305                                           // 000000DF4DF0: D7000305
	v_cndmask_b32_e32 v1, v9, v2, vcc_lo                       // 000000DF4DF4: 02020509
	v_add_co_ci_u32_e64 v6, null, v10, v3, s3                  // 000000DF4DF8: D5207C06 000E070A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF4E00: BF870093
	.long 0xd7000307                                           // 000000DF4E04: D7000307
	v_cndmask_b32_e32 v1, v9, v4, vcc_lo                       // 000000DF4E08: 02020909
	v_add_co_ci_u32_e64 v8, null, v10, v8, s3                  // 000000DF4E0C: D5207C08 000E110A
	.long 0xd7000309                                           // 000000DF4E14: D7000309
	v_cndmask_b32_e32 v1, v9, v13, vcc_lo                      // 000000DF4E18: 02021B09
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DF4E1C: BF870001
	v_add_co_ci_u32_e64 v10, null, 0, v10, s3                  // 000000DF4E20: D5207C0A 000E1480
	s_clause 0x17                                              // 000000DF4E28: BF850017
	global_load_b32 v4, v[5:6], off                            // 000000DF4E2C: DC520000 047C0005
	global_load_b32 v2, v[5:6], off offset:128                 // 000000DF4E34: DC520080 027C0005
	global_load_b32 v65, v[5:6], off offset:256                // 000000DF4E3C: DC520100 417C0005
	global_load_b32 v62, v[5:6], off offset:384                // 000000DF4E44: DC520180 3E7C0005
	global_load_b32 v59, v[5:6], off offset:512                // 000000DF4E4C: DC520200 3B7C0005
	global_load_b32 v56, v[5:6], off offset:640                // 000000DF4E54: DC520280 387C0005
	global_load_b32 v53, v[5:6], off offset:768                // 000000DF4E5C: DC520300 357C0005
	global_load_b32 v35, v[5:6], off offset:896                // 000000DF4E64: DC520380 237C0005
	global_load_b32 v6, v[7:8], off                            // 000000DF4E6C: DC520000 067C0007
	global_load_b32 v3, v[7:8], off offset:128                 // 000000DF4E74: DC520080 037C0007
	global_load_b32 v66, v[7:8], off offset:256                // 000000DF4E7C: DC520100 427C0007
	global_load_b32 v63, v[7:8], off offset:384                // 000000DF4E84: DC520180 3F7C0007
	global_load_b32 v60, v[7:8], off offset:512                // 000000DF4E8C: DC520200 3C7C0007
	global_load_b32 v57, v[7:8], off offset:640                // 000000DF4E94: DC520280 397C0007
	global_load_b32 v55, v[7:8], off offset:768                // 000000DF4E9C: DC520300 377C0007
	global_load_b32 v36, v[7:8], off offset:896                // 000000DF4EA4: DC520380 247C0007
	global_load_b32 v5, v[9:10], off                           // 000000DF4EAC: DC520000 057C0009
	global_load_b32 v67, v[9:10], off offset:128               // 000000DF4EB4: DC520080 437C0009
	global_load_b32 v64, v[9:10], off offset:256               // 000000DF4EBC: DC520100 407C0009
	global_load_b32 v61, v[9:10], off offset:384               // 000000DF4EC4: DC520180 3D7C0009
	global_load_b32 v58, v[9:10], off offset:512               // 000000DF4ECC: DC520200 3A7C0009
	global_load_b32 v54, v[9:10], off offset:640               // 000000DF4ED4: DC520280 367C0009
	global_load_b32 v52, v[9:10], off offset:768               // 000000DF4EDC: DC520300 347C0009
	global_load_b32 v34, v[9:10], off offset:896               // 000000DF4EE4: DC520380 227C0009
	s_or_b32 exec_lo, exec_lo, s6                              // 000000DF4EEC: 8C7E067E
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v18, 0             // 000000DF4EF0: CA100080 0F120080
	v_dual_mov_b32 v17, 0 :: v_dual_mov_b32 v20, 0             // 000000DF4EF8: CA100080 11140080
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v22, 0             // 000000DF4F00: CA100080 15160080
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v25, 0             // 000000DF4F08: CA100080 18180080
	v_dual_mov_b32 v16, 0 :: v_dual_mov_b32 v19, 0             // 000000DF4F10: CA100080 10120080
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v23, 0             // 000000DF4F18: CA100080 1A160080
	v_dual_mov_b32 v28, 0 :: v_dual_mov_b32 v29, 0             // 000000DF4F20: CA100080 1C1C0080
	v_dual_mov_b32 v27, 0 :: v_dual_mov_b32 v30, 0             // 000000DF4F28: CA100080 1B1E0080
	s_ashr_i32 s35, s34, 31                                    // 000000DF4F30: 86239F22
	s_and_saveexec_b32 s3, vcc_lo                              // 000000DF4F34: BE83206A
	s_cbranch_execz 1008                                       // 000000DF4F38: BFA503F0 <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi2EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x1afc>
	v_dual_mov_b32 v18, 0 :: v_dual_add_nc_u32 v7, -1, v0      // 000000DF4F3C: CA200080 120600C1
	v_dual_mov_b32 v15, 0 :: v_dual_lshlrev_b32 v32, 2, v12    // 000000DF4F44: CA220080 0F201882
	v_dual_mov_b32 v20, 0 :: v_dual_and_b32 v31, 16, v0        // 000000DF4F4C: CA240080 141E0090
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000DF4F54: BF8701B3
	v_dual_mov_b32 v24, 0 :: v_dual_and_b32 v7, 31, v7         // 000000DF4F58: CA240080 18060E9F
	v_dual_mov_b32 v17, 0 :: v_dual_mov_b32 v22, 0             // 000000DF4F60: CA100080 11160080
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v16, 0             // 000000DF4F68: CA100080 15100080
	v_dual_mov_b32 v26, 0 :: v_dual_lshlrev_b32 v33, 2, v7     // 000000DF4F70: CA220080 1A200E82
	v_dual_mov_b32 v25, 0 :: v_dual_mov_b32 v28, 0             // 000000DF4F78: CA100080 191C0080
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v30, 0             // 000000DF4F80: CA100080 131E0080
	v_mov_b32_e32 v23, 0                                       // 000000DF4F88: 7E2E0280
	v_mov_b32_e32 v29, 0                                       // 000000DF4F8C: 7E3A0280
	v_mov_b32_e32 v27, 0                                       // 000000DF4F90: 7E360280
	s_mov_b32 s6, 0                                            // 000000DF4F94: BE860080
	s_movk_i32 s7, 0x1eee                                      // 000000DF4F98: B0071EEE
	s_branch 924                                               // 000000DF4F9C: BFA0039C <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi2EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x1a10>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000DF4FA0: 8C7E087E
	s_waitcnt vmcnt(15)                                        // 000000DF4FA4: BF893FF7
	v_alignbit_b32 v4, v4, v6, 16                              // 000000DF4FA8: D6160004 02420D04
	s_waitcnt vmcnt(7)                                         // 000000DF4FB0: BF891FF7
	v_bfe_u32 v68, v5, 12, 16                                  // 000000DF4FB4: D6100044 02411905
	v_bfe_u32 v69, v5, 8, 16                                   // 000000DF4FBC: D6100045 02411105
	v_bfe_u32 v70, v5, 4, 16                                   // 000000DF4FC4: D6100046 02410905
	v_lshl_or_b32 v1, v1, 5, v31                               // 000000DF4FCC: D6560001 047D0B01
	v_and_b32_e32 v7, 0xffff, v4                               // 000000DF4FD4: 360E08FF 0000FFFF
	v_bfe_u32 v74, v4, 4, 16                                   // 000000DF4FDC: D610004A 02410904
	.long 0xd72c0044                                           // 000000DF4FE4: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 000000DF4FE8: 020288FF 83DCD12D
	.long 0xd72c0045                                           // 000000DF4FF0: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 000000DF4FF4: 02028AFF 83DCD12D
	v_bfe_u32 v6, v4, 12, 16                                   // 000000DF4FFC: D6100006 02411904
	.long 0xd72c004c                                           // 000000DF5004: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v7, vcc_lo               // 000000DF5008: 02020EFF 83DCD12D
	.long 0xd72c004a                                           // 000000DF5010: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000DF5014: 020294FF 83DCD12D
	v_alignbit_b32 v72, v2, v3, 16                             // 000000DF501C: D6160048 02420702
	.long 0xd72c0046                                           // 000000DF5024: D72C0046
	v_cndmask_b32_e32 v1, 0x83dcd12d, v70, vcc_lo              // 000000DF5028: 02028CFF 83DCD12D
	.long 0xd72c0049                                           // 000000DF5030: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v6, vcc_lo               // 000000DF5034: 02020CFF 83DCD12D
	v_sad_u8 v68, v68, 0, 0x6400                               // 000000DF503C: D6220044 03FD0144 00006400
	v_sad_u8 v69, v69, 0, 0x6400                               // 000000DF5048: D6220045 03FD0145 00006400
	s_waitcnt vmcnt(6)                                         // 000000DF5054: BF891BF7
	v_bfe_u32 v77, v67, 4, 16                                  // 000000DF5058: D610004D 02410943
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000DF5060: D622004C 03FD014C 00006400
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000DF506C: D622004A 03FD014A 00006400
	v_and_b32_e32 v68, 0xffff, v68                             // 000000DF5078: 368888FF 0000FFFF
	v_sad_u8 v70, v70, 0, 0x6400                               // 000000DF5080: D6220046 03FD0146 00006400
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000DF508C: D6220049 03FD0149 00006400
	v_lshlrev_b32_e32 v76, 16, v76                             // 000000DF5098: 30989890
	v_alignbit_b32 v65, v65, v66, 16                           // 000000DF509C: D6160041 02428541
	v_lshl_or_b32 v68, v69, 16, v68                            // 000000DF50A4: D6560044 05112145
	v_alignbit_b32 v62, v62, v63, 16                           // 000000DF50AC: D616003E 02427F3E
	v_alignbit_b32 v59, v59, v60, 16                           // 000000DF50B4: D616003B 0242793B
	v_and_or_b32 v74, 0xffff, v74, v76                         // 000000DF50BC: D657004A 053294FF 0000FFFF
	v_bfe_u32 v76, v67, 8, 16                                  // 000000DF50C8: D610004C 02411143
	v_pk_fma_f16 v68, v68, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DF50D0: CC0E0044 0BFC0F44 0000C931
	v_alignbit_b32 v56, v56, v57, 16                           // 000000DF50DC: D6160038 02427338
	v_alignbit_b32 v53, v53, v55, 16                           // 000000DF50E4: D6160035 02426F35
	v_pk_fma_f16 v69, v74, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DF50EC: CC0E0045 0BFC0F4A 0000C931
	v_and_b32_e32 v71, 0xffff, v5                              // 000000DF50F8: 368E0AFF 0000FFFF
	v_bfe_u32 v5, v4, 8, 16                                    // 000000DF5100: D6100005 02411104
	v_bfe_u32 v74, v72, 12, 16                                 // 000000DF5108: D610004A 02411948
	.long 0xd72c004c                                           // 000000DF5110: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000DF5114: 020298FF 83DCD12D
	v_bfe_u32 v55, v53, 12, 16                                 // 000000DF511C: D6100037 02411935
	v_alignbit_b32 v35, v35, v36, 16                           // 000000DF5124: D6160023 02424923
	.long 0xd72c004b                                           // 000000DF512C: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v5, vcc_lo               // 000000DF5130: 02020AFF 83DCD12D
	ds_load_b128 v[5:8], v1                                    // 000000DF5138: DBFC0000 05000001
	ds_load_b128 v[1:4], v1 offset:5120                        // 000000DF5140: DBFC1400 01000001
	v_and_b32_e32 v73, 0xffff, v73                             // 000000DF5148: 369292FF 0000FFFF
	.long 0xd72c004a                                           // 000000DF5150: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000DF5154: 020294FF 83DCD12D
	.long 0xd72c0037                                           // 000000DF515C: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000DF5160: 02026EFF 83DCD12D
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000DF5168: D622004C 03FD014C 00006400
	v_cmp_eq_u32_e32 vcc_lo, v9, v14                           // 000000DF5174: 7C941D09
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000DF5178: D622004B 03FD014B 00006400
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000DF5184: D622004A 03FD014A 00006400
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000DF5190: D6220037 03FD0137 00006400
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DF519C: BF870003
	v_lshl_or_b32 v73, v75, 16, v73                            // 000000DF51A0: D6560049 0525214B
	v_bfe_u32 v75, v72, 8, 16                                  // 000000DF51A8: D610004B 02411148
	s_or_b32 s6, vcc_lo, s6                                    // 000000DF51B0: 8C06066A
	v_and_b32_e32 v74, 0xffff, v74                             // 000000DF51B4: 369494FF 0000FFFF
	v_and_b32_e32 v55, 0xffff, v55                             // 000000DF51BC: 366E6EFF 0000FFFF
	v_pk_fma_f16 v73, v73, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DF51C4: CC0E0049 0BFC0F49 0000C931
	.long 0xd72c004b                                           // 000000DF51D0: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000DF51D4: 020296FF 83DCD12D
	s_waitcnt lgkmcnt(1)                                       // 000000DF51DC: BF89FC17
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000DF51E0: BF870242
	v_dot2acc_f32_f16 v30, v73, v5                             // 000000DF51E4: 043C0B49
	s_waitcnt lgkmcnt(0)                                       // 000000DF51E8: BF89FC07
	v_dot2acc_f32_f16 v27, v73, v1                             // 000000DF51EC: 04360349
	v_bfe_u32 v73, v67, 12, 16                                 // 000000DF51F0: D6100049 02411943
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000DF51F8: D622004B 03FD014B 00006400
	v_dot2acc_f32_f16 v30, v69, v6                             // 000000DF5204: 043C0D45
	.long 0xd72c0047                                           // 000000DF5208: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000DF520C: 02028EFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000DF5214: BF870254
	.long 0xd72c0049                                           // 000000DF5218: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000DF521C: 020292FF 83DCD12D
	v_dot2acc_f32_f16 v27, v69, v2                             // 000000DF5224: 04360545
	v_lshl_or_b32 v74, v75, 16, v74                            // 000000DF5228: D656004A 0529214B
	v_dot2acc_f32_f16 v30, v68, v7                             // 000000DF5230: 043C0F44
	.long 0xd72c004b                                           // 000000DF5234: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000DF5238: 02029AFF 83DCD12D
	v_dot2acc_f32_f16 v27, v68, v3                             // 000000DF5240: 04360744
	v_sad_u8 v71, v71, 0, 0x6400                               // 000000DF5244: D6220047 03FD0147 00006400
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000DF5250: D6220049 03FD0149 00006400
	v_bfe_u32 v68, v65, 4, 16                                  // 000000DF525C: D6100044 02410941
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF5264: BF870113
	v_lshlrev_b32_e32 v71, 16, v71                             // 000000DF5268: 308E8E90
	.long 0xd72c0044                                           // 000000DF526C: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 000000DF5270: 020288FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000DF5278: BF8701B2
	v_and_or_b32 v70, 0xffff, v70, v71                         // 000000DF527C: D6570046 051E8CFF 0000FFFF
	v_and_b32_e32 v71, 0xffff, v72                             // 000000DF5288: 368E90FF 0000FFFF
	v_bfe_u32 v72, v72, 4, 16                                  // 000000DF5290: D6100048 02410948
	v_pk_fma_f16 v70, v70, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DF5298: CC0E0046 0BFC0F46 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF52A4: BF870193
	.long 0xd72c0047                                           // 000000DF52A8: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000DF52AC: 02028EFF 83DCD12D
	.long 0xd72c0048                                           // 000000DF52B4: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000DF52B8: 020290FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DF52C0: BF870003
	v_dot2acc_f32_f16 v27, v70, v4                             // 000000DF52C4: 04360946
	v_dot2acc_f32_f16 v30, v70, v8                             // 000000DF52C8: 043C1146
	s_waitcnt vmcnt(5)                                         // 000000DF52CC: BF8917F7
	v_bfe_u32 v70, v64, 8, 16                                  // 000000DF52D0: D6100046 02411140
	v_sad_u8 v71, v71, 0, 0x6400                               // 000000DF52D8: D6220047 03FD0147 00006400
	v_sad_u8 v72, v72, 0, 0x6400                               // 000000DF52E4: D6220048 03FD0148 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF52F0: BF870193
	.long 0xd72c0046                                           // 000000DF52F4: D72C0046
	v_cndmask_b32_e32 v1, 0x83dcd12d, v70, vcc_lo              // 000000DF52F8: 02028CFF 83DCD12D
	v_lshlrev_b32_e32 v71, 16, v71                             // 000000DF5300: 308E8E90
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000DF5304: BF870241
	v_and_or_b32 v69, 0xffff, v72, v71                         // 000000DF5308: D6570045 051E90FF 0000FFFF
	v_pk_fma_f16 v71, v74, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DF5314: CC0E0047 0BFC0F4A 0000C931
	v_and_b32_e32 v67, 0xffff, v67                             // 000000DF5320: 368686FF 0000FFFF
	v_sad_u8 v70, v70, 0, 0x6400                               // 000000DF5328: D6220046 03FD0146 00006400
	v_pk_fma_f16 v69, v69, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DF5334: CC0E0045 0BFC0F45 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DF5340: BF870214
	v_dot2acc_f32_f16 v28, v71, v1                             // 000000DF5344: 04380347
	.long 0xd72c0043                                           // 000000DF5348: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000DF534C: 020286FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DF5354: BF870122
	v_dual_dot2acc_f32_f16 v29, v71, v5 :: v_dual_dot2acc_f32_f16 v28, v69, v2// 000000DF5358: CB180B47 1D1C0545
	v_and_b32_e32 v73, 0xffff, v73                             // 000000DF5360: 369292FF 0000FFFF
	v_dot2acc_f32_f16 v29, v69, v6                             // 000000DF5368: 043A0D45
	v_bfe_u32 v69, v64, 12, 16                                 // 000000DF536C: D6100045 02411940
	v_sad_u8 v67, v67, 0, 0x6400                               // 000000DF5374: D6220043 03FD0143 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DF5380: BF870224
	v_lshl_or_b32 v72, v76, 16, v73                            // 000000DF5384: D6560048 0525214C
	v_sad_u8 v73, v75, 0, 0x6400                               // 000000DF538C: D6220049 03FD014B 00006400
	.long 0xd72c0045                                           // 000000DF5398: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 000000DF539C: 02028AFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000DF53A4: BF870133
	v_pk_fma_f16 v71, v72, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DF53A8: CC0E0047 0BFC0F48 0000C931
	s_waitcnt vmcnt(4)                                         // 000000DF53B4: BF8913F7
	v_bfe_u32 v72, v61, 4, 16                                  // 000000DF53B8: D6100048 0241093D
	v_dot2acc_f32_f16 v28, v71, v3                             // 000000DF53C0: 04380747
	v_lshlrev_b32_e32 v67, 16, v67                             // 000000DF53C4: 30868690
	v_dot2acc_f32_f16 v29, v71, v7                             // 000000DF53C8: 043A0F47
	v_and_b32_e32 v71, 0xffff, v64                             // 000000DF53CC: 368E80FF 0000FFFF
	v_bfe_u32 v64, v64, 4, 16                                  // 000000DF53D4: D6100040 02410940
	v_sad_u8 v69, v69, 0, 0x6400                               // 000000DF53DC: D6220045 03FD0145 00006400
	v_and_or_b32 v67, 0xffff, v73, v67                         // 000000DF53E8: D6570043 050E92FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DF53F4: BF870214
	.long 0xd72c0047                                           // 000000DF53F8: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000DF53FC: 02028EFF 83DCD12D
	.long 0xd72c0040                                           // 000000DF5404: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000DF5408: 020280FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DF5410: BF870214
	v_and_b32_e32 v69, 0xffff, v69                             // 000000DF5414: 368A8AFF 0000FFFF
	v_pk_fma_f16 v66, v67, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DF541C: CC0E0042 0BFC0F43 0000C931
	v_bfe_u32 v67, v65, 12, 16                                 // 000000DF5428: D6100043 02411941
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF5430: BF870193
	v_lshl_or_b32 v63, v70, 16, v69                            // 000000DF5434: D656003F 05152146
	v_dot2acc_f32_f16 v29, v66, v8                             // 000000DF543C: 043A1142
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DF5440: BF870003
	.long 0xd72c0043                                           // 000000DF5444: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000DF5448: 020286FF 83DCD12D
	v_dot2acc_f32_f16 v28, v66, v4                             // 000000DF5450: 04380942
	v_bfe_u32 v66, v65, 8, 16                                  // 000000DF5454: D6100042 02411141
	v_and_b32_e32 v65, 0xffff, v65                             // 000000DF545C: 368282FF 0000FFFF
	v_sad_u8 v64, v64, 0, 0x6400                               // 000000DF5464: D6220040 03FD0140 00006400
	v_bfe_u32 v69, v62, 8, 16                                  // 000000DF5470: D6100045 0241113E
	v_bfe_u32 v70, v61, 12, 16                                 // 000000DF5478: D6100046 0241193D
	.long 0xd72c0042                                           // 000000DF5480: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 000000DF5484: 020284FF 83DCD12D
	.long 0xd72c0041                                           // 000000DF548C: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000DF5490: 020282FF 83DCD12D
	v_sad_u8 v67, v67, 0, 0x6400                               // 000000DF5498: D6220043 03FD0143 00006400
	.long 0xd72c0045                                           // 000000DF54A4: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 000000DF54A8: 02028AFF 83DCD12D
	.long 0xd72c0046                                           // 000000DF54B0: D72C0046
	v_cndmask_b32_e32 v1, 0x83dcd12d, v70, vcc_lo              // 000000DF54B4: 02028CFF 83DCD12D
	v_pk_fma_f16 v63, v63, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DF54BC: CC0E003F 0BFC0F3F 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000DF54C8: BF870254
	v_and_b32_e32 v67, 0xffff, v67                             // 000000DF54CC: 368686FF 0000FFFF
	v_sad_u8 v66, v66, 0, 0x6400                               // 000000DF54D4: D6220042 03FD0142 00006400
	v_sad_u8 v65, v65, 0, 0x6400                               // 000000DF54E0: D6220041 03FD0141 00006400
	v_sad_u8 v69, v69, 0, 0x6400                               // 000000DF54EC: D6220045 03FD0145 00006400
	v_sad_u8 v70, v70, 0, 0x6400                               // 000000DF54F8: D6220046 03FD0146 00006400
	v_lshl_or_b32 v66, v66, 16, v67                            // 000000DF5504: D6560042 050D2142
	v_sad_u8 v67, v68, 0, 0x6400                               // 000000DF550C: D6220043 03FD0144 00006400
	v_sad_u8 v68, v71, 0, 0x6400                               // 000000DF5518: D6220044 03FD0147 00006400
	v_lshlrev_b32_e32 v65, 16, v65                             // 000000DF5524: 30828290
	v_bfe_u32 v71, v61, 8, 16                                  // 000000DF5528: D6100047 0241113D
	v_pk_fma_f16 v66, v66, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DF5530: CC0E0042 0BFC0F42 0000C931
	v_and_b32_e32 v61, 0xffff, v61                             // 000000DF553C: 367A7AFF 0000FFFF
	v_lshlrev_b32_e32 v68, 16, v68                             // 000000DF5544: 30888890
	v_and_or_b32 v65, 0xffff, v67, v65                         // 000000DF5548: D6570041 050686FF 0000FFFF
	v_bfe_u32 v67, v62, 12, 16                                 // 000000DF5554: D6100043 0241193E
	v_dot2acc_f32_f16 v23, v66, v5                             // 000000DF555C: 042E0B42
	v_dot2acc_f32_f16 v19, v66, v1                             // 000000DF5560: 04260342
	v_and_or_b32 v64, 0xffff, v64, v68                         // 000000DF5564: D6570040 051280FF 0000FFFF
	v_and_b32_e32 v68, 0xffff, v62                             // 000000DF5570: 36887CFF 0000FFFF
	.long 0xd72c0043                                           // 000000DF5578: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000DF557C: 020286FF 83DCD12D
	v_bfe_u32 v62, v62, 4, 16                                  // 000000DF5584: D610003E 0241093E
	.long 0xd72c0047                                           // 000000DF558C: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000DF5590: 02028EFF 83DCD12D
	.long 0xd72c003d                                           // 000000DF5598: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000DF559C: 02027AFF 83DCD12D
	.long 0xd72c0044                                           // 000000DF55A4: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 000000DF55A8: 020288FF 83DCD12D
	v_pk_fma_f16 v65, v65, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DF55B0: CC0E0041 0BFC0F41 0000C931
	.long 0xd72c003e                                           // 000000DF55BC: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000DF55C0: 02027CFF 83DCD12D
	v_pk_fma_f16 v64, v64, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DF55C8: CC0E0040 0BFC0F40 0000C931
	v_sad_u8 v67, v67, 0, 0x6400                               // 000000DF55D4: D6220043 03FD0143 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000DF55E0: BF870234
	v_dot2acc_f32_f16 v23, v65, v6                             // 000000DF55E4: 042E0D41
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000DF55E8: D622003D 03FD013D 00006400
	v_sad_u8 v68, v68, 0, 0x6400                               // 000000DF55F4: D6220044 03FD0144 00006400
	v_and_b32_e32 v67, 0xffff, v67                             // 000000DF5600: 368686FF 0000FFFF
	v_sad_u8 v62, v62, 0, 0x6400                               // 000000DF5608: D622003E 03FD013E 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DF5614: BF870214
	v_lshlrev_b32_e32 v61, 16, v61                             // 000000DF5618: 307A7A90
	v_lshlrev_b32_e32 v68, 16, v68                             // 000000DF561C: 30888890
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000DF5620: BF870234
	v_lshl_or_b32 v67, v69, 16, v67                            // 000000DF5624: D6560043 050D2145
	v_and_b32_e32 v69, 0xffff, v70                             // 000000DF562C: 368A8CFF 0000FFFF
	v_sad_u8 v70, v71, 0, 0x6400                               // 000000DF5634: D6220046 03FD0147 00006400
	v_and_or_b32 v62, 0xffff, v62, v68                         // 000000DF5640: D657003E 05127CFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DF564C: BF870224
	v_pk_fma_f16 v66, v67, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DF5650: CC0E0042 0BFC0F43 0000C931
	.long 0xd72c0044                                           // 000000DF565C: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000DF5660: 020290FF 83DCD12D
	v_lshl_or_b32 v67, v70, 16, v69                            // 000000DF5668: D6560043 05152146
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DF5670: BF870214
	v_pk_fma_f16 v62, v62, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DF5674: CC0E003E 0BFC0F3E 0000C931
	v_dot2acc_f32_f16 v26, v66, v5                             // 000000DF5680: 04340B42
	v_dot2acc_f32_f16 v25, v66, v1                             // 000000DF5684: 04320342
	s_waitcnt vmcnt(2)                                         // 000000DF5688: BF890BF7
	v_bfe_u32 v66, v54, 4, 16                                  // 000000DF568C: D6100042 02410936
	v_sad_u8 v68, v68, 0, 0x6400                               // 000000DF5694: D6220044 03FD0144 00006400
	v_dot2acc_f32_f16 v26, v62, v6                             // 000000DF56A0: 04340D3E
	v_dual_dot2acc_f32_f16 v25, v62, v2 :: v_dual_and_b32 v62, 0xffff, v59// 000000DF56A4: CB24053E 193E76FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF56B0: BF870113
	v_and_or_b32 v61, 0xffff, v68, v61                         // 000000DF56B4: D657003D 04F688FF 0000FFFF
	.long 0xd72c003e                                           // 000000DF56C0: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000DF56C4: 02027CFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DF56CC: BF8701A2
	v_pk_fma_f16 v60, v61, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DF56D0: CC0E003C 0BFC0F3D 0000C931
	v_bfe_u32 v61, v59, 12, 16                                 // 000000DF56DC: D610003D 0241193B
	v_sad_u8 v62, v62, 0, 0x6400                               // 000000DF56E4: D622003E 03FD013E 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF56F0: BF870112
	.long 0xd72c003d                                           // 000000DF56F4: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000DF56F8: 02027AFF 83DCD12D
	v_lshlrev_b32_e32 v62, 16, v62                             // 000000DF5700: 307C7C90
	v_dot2acc_f32_f16 v19, v65, v2                             // 000000DF5704: 04260541
	v_pk_fma_f16 v65, v67, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DF5708: CC0E0041 0BFC0F43 0000C931
	v_mov_b32_e32 v67, v50                                     // 000000DF5714: 7E860332
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000DF5718: D622003D 03FD013D 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000DF5724: BF8701B3
	v_dot2acc_f32_f16 v26, v65, v7                             // 000000DF5728: 04340F41
	v_dot2acc_f32_f16 v25, v65, v3                             // 000000DF572C: 04320741
	v_bfe_u32 v65, v58, 4, 16                                  // 000000DF5730: D6100041 0241093A
	v_dot2acc_f32_f16 v26, v60, v8                             // 000000DF5738: 0434113C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000DF573C: BF8701C3
	v_dot2acc_f32_f16 v25, v60, v4                             // 000000DF5740: 0432093C
	v_bfe_u32 v60, v59, 8, 16                                  // 000000DF5744: D610003C 0241113B
	v_bfe_u32 v59, v59, 4, 16                                  // 000000DF574C: D610003B 0241093B
	.long 0xd72c0041                                           // 000000DF5754: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000DF5758: 020282FF 83DCD12D
	.long 0xd72c003c                                           // 000000DF5760: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000DF5764: 020278FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF576C: BF870193
	.long 0xd72c003b                                           // 000000DF5770: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000DF5774: 020276FF 83DCD12D
	v_sad_u8 v65, v65, 0, 0x6400                               // 000000DF577C: D6220041 03FD0141 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF5788: BF870193
	v_sad_u8 v60, v60, 0, 0x6400                               // 000000DF578C: D622003C 03FD013C 00006400
	v_sad_u8 v59, v59, 0, 0x6400                               // 000000DF5798: D622003B 03FD013B 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DF57A4: BF870121
	v_and_or_b32 v59, 0xffff, v59, v62                         // 000000DF57A8: D657003B 04FA76FF 0000FFFF
	v_dual_dot2acc_f32_f16 v23, v63, v7 :: v_dual_and_b32 v62, 0xffff, v56// 000000DF57B4: CB240F3F 173E70FF 0000FFFF
	v_pk_fma_f16 v59, v59, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DF57C0: CC0E003B 0BFC0F3B 0000C931
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF57CC: BF870192
	.long 0xd72c003e                                           // 000000DF57D0: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000DF57D4: 02027CFF 83DCD12D
	v_dot2acc_f32_f16 v23, v64, v8                             // 000000DF57DC: 042E1140
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000DF57E0: BF870132
	v_sad_u8 v62, v62, 0, 0x6400                               // 000000DF57E4: D622003E 03FD013E 00006400
	v_dot2acc_f32_f16 v19, v63, v3                             // 000000DF57F0: 0426073F
	v_bfe_u32 v63, v58, 12, 16                                 // 000000DF57F4: D610003F 0241193A
	v_dual_dot2acc_f32_f16 v19, v64, v4 :: v_dual_lshlrev_b32 v62, 16, v62// 000000DF57FC: CB220940 133E7C90
	v_bfe_u32 v64, v58, 8, 16                                  // 000000DF5804: D6100040 0241113A
	v_and_b32_e32 v58, 0xffff, v58                             // 000000DF580C: 367474FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF5814: BF870194
	.long 0xd72c003f                                           // 000000DF5818: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000DF581C: 02027EFF 83DCD12D
	.long 0xd72c0040                                           // 000000DF5824: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000DF5828: 020280FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF5830: BF870193
	.long 0xd72c003a                                           // 000000DF5834: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000DF5838: 020274FF 83DCD12D
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000DF5840: D622003F 03FD013F 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF584C: BF870193
	v_sad_u8 v64, v64, 0, 0x6400                               // 000000DF5850: D6220040 03FD0140 00006400
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000DF585C: D622003A 03FD013A 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF5868: BF870091
	v_lshlrev_b32_e32 v58, 16, v58                             // 000000DF586C: 30747490
	v_and_or_b32 v58, 0xffff, v65, v58                         // 000000DF5870: D657003A 04EA82FF 0000FFFF
	v_bfe_u32 v65, v54, 8, 16                                  // 000000DF587C: D6100041 02411136
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000DF5884: BF870232
	v_pk_fma_f16 v58, v58, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DF5888: CC0E003A 0BFC0F3A 0000C931
	v_and_b32_e32 v61, 0xffff, v61                             // 000000DF5894: 367A7AFF 0000FFFF
	v_and_b32_e32 v63, 0xffff, v63                             // 000000DF589C: 367E7EFF 0000FFFF
	.long 0xd72c0041                                           // 000000DF58A4: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000DF58A8: 020282FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF58B0: BF870193
	v_lshl_or_b32 v60, v60, 16, v61                            // 000000DF58B4: D656003C 04F5213C
	v_lshl_or_b32 v57, v64, 16, v63                            // 000000DF58BC: D6560039 04FD2140
	v_bfe_u32 v61, v56, 12, 16                                 // 000000DF58C4: D610003D 02411938
	v_bfe_u32 v63, v56, 8, 16                                  // 000000DF58CC: D610003F 02411138
	v_bfe_u32 v56, v56, 4, 16                                  // 000000DF58D4: D6100038 02410938
	v_bfe_u32 v64, v54, 12, 16                                 // 000000DF58DC: D6100040 02411936
	v_and_b32_e32 v54, 0xffff, v54                             // 000000DF58E4: 366C6CFF 0000FFFF
	.long 0xd72c003d                                           // 000000DF58EC: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000DF58F0: 02027AFF 83DCD12D
	.long 0xd72c003f                                           // 000000DF58F8: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000DF58FC: 02027EFF 83DCD12D
	.long 0xd72c0038                                           // 000000DF5904: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000DF5908: 020270FF 83DCD12D
	v_pk_fma_f16 v60, v60, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DF5910: CC0E003C 0BFC0F3C 0000C931
	.long 0xd72c0036                                           // 000000DF591C: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 000000DF5920: 02026CFF 83DCD12D
	v_pk_fma_f16 v57, v57, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DF5928: CC0E0039 0BFC0F39 0000C931
	.long 0xd72c0040                                           // 000000DF5934: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000DF5938: 020280FF 83DCD12D
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000DF5940: D622003D 03FD013D 00006400
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000DF594C: D622003F 03FD013F 00006400
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000DF5958: D6220038 03FD0138 00006400
	v_dot2acc_f32_f16 v16, v60, v5                             // 000000DF5964: 04200B3C
	v_sad_u8 v54, v54, 0, 0x6400                               // 000000DF5968: D6220036 03FD0136 00006400
	v_dot2acc_f32_f16 v24, v60, v1                             // 000000DF5974: 0430033C
	v_sad_u8 v64, v64, 0, 0x6400                               // 000000DF5978: D6220040 03FD0140 00006400
	v_and_or_b32 v56, 0xffff, v56, v62                         // 000000DF5984: D6570038 04FA70FF 0000FFFF
	.long 0xd72c003e                                           // 000000DF5990: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 000000DF5994: 020284FF 83DCD12D
	v_lshlrev_b32_e32 v54, 16, v54                             // 000000DF599C: 306C6C90
	v_dot2acc_f32_f16 v16, v59, v6                             // 000000DF59A0: 04200D3B
	v_dot2acc_f32_f16 v24, v59, v2                             // 000000DF59A4: 0430053B
	v_pk_fma_f16 v56, v56, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DF59A8: CC0E0038 0BFC0F38 0000C931
	v_mov_b32_e32 v66, v49                                     // 000000DF59B4: 7E840331
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000DF59B8: BF8701B4
	v_dot2acc_f32_f16 v16, v57, v7                             // 000000DF59BC: 04200F39
	v_sad_u8 v62, v62, 0, 0x6400                               // 000000DF59C0: D622003E 03FD013E 00006400
	v_dot2acc_f32_f16 v24, v57, v3                             // 000000DF59CC: 04300739
	v_dot2acc_f32_f16 v16, v58, v8                             // 000000DF59D0: 0420113A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF59D4: BF870193
	v_and_or_b32 v54, 0xffff, v62, v54                         // 000000DF59D8: D6570036 04DA7CFF 0000FFFF
	v_dot2acc_f32_f16 v24, v58, v4                             // 000000DF59E4: 0430093A
	s_waitcnt vmcnt(1)                                         // 000000DF59E8: BF8907F7
	v_bfe_u32 v58, v52, 12, 16                                 // 000000DF59EC: D610003A 02411934
	v_mov_b32_e32 v62, v40                                     // 000000DF59F4: 7E7C0328
	v_pk_fma_f16 v54, v54, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DF59F8: CC0E0036 0BFC0F36 0000C931
	v_and_b32_e32 v61, 0xffff, v61                             // 000000DF5A04: 367A7AFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF5A0C: BF870114
	.long 0xd72c003a                                           // 000000DF5A10: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000DF5A14: 020274FF 83DCD12D
	v_lshl_or_b32 v61, v63, 16, v61                            // 000000DF5A1C: D656003D 04F5213F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF5A24: BF870112
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000DF5A28: D622003A 03FD013A 00006400
	v_pk_fma_f16 v60, v61, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DF5A34: CC0E003C 0BFC0F3D 0000C931
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF5A40: BF870112
	v_and_b32_e32 v58, 0xffff, v58                             // 000000DF5A44: 367474FF 0000FFFF
	v_dot2acc_f32_f16 v22, v60, v5                             // 000000DF5A4C: 042C0B3C
	v_dot2acc_f32_f16 v21, v60, v1                             // 000000DF5A50: 042A033C
	v_bfe_u32 v60, v52, 4, 16                                  // 000000DF5A54: D610003C 02410934
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF5A5C: BF870193
	v_dot2acc_f32_f16 v22, v56, v6                             // 000000DF5A60: 042C0D38
	v_dot2acc_f32_f16 v21, v56, v2                             // 000000DF5A64: 042A0538
	v_bfe_u32 v56, v53, 8, 16                                  // 000000DF5A68: D6100038 02411135
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF5A70: BF870114
	.long 0xd72c003c                                           // 000000DF5A74: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000DF5A78: 020278FF 83DCD12D
	.long 0xd72c0038                                           // 000000DF5A80: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000DF5A84: 020270FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF5A8C: BF870112
	v_sad_u8 v60, v60, 0, 0x6400                               // 000000DF5A90: D622003C 03FD013C 00006400
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000DF5A9C: D6220038 03FD0138 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DF5AA8: BF870121
	v_lshl_or_b32 v55, v56, 16, v55                            // 000000DF5AAC: D6560037 04DD2138
	v_bfe_u32 v56, v35, 12, 16                                 // 000000DF5AB4: D6100038 02411923
	v_pk_fma_f16 v55, v55, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DF5ABC: CC0E0037 0BFC0F37 0000C931
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF5AC8: BF870112
	.long 0xd72c0038                                           // 000000DF5ACC: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000DF5AD0: 020270FF 83DCD12D
	v_dot2acc_f32_f16 v18, v55, v1                             // 000000DF5AD8: 04240337
	v_and_b32_e32 v57, 0xffff, v53                             // 000000DF5ADC: 36726AFF 0000FFFF
	v_bfe_u32 v53, v53, 4, 16                                  // 000000DF5AE4: D6100035 02410935
	v_dot2acc_f32_f16 v20, v55, v5                             // 000000DF5AEC: 04280B37
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000DF5AF0: D6220038 03FD0138 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DF5AFC: BF870214
	.long 0xd72c0039                                           // 000000DF5B00: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 000000DF5B04: 020272FF 83DCD12D
	.long 0xd72c0035                                           // 000000DF5B0C: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000DF5B10: 02026AFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF5B18: BF870193
	v_and_b32_e32 v56, 0xffff, v56                             // 000000DF5B1C: 367070FF 0000FFFF
	v_sad_u8 v57, v57, 0, 0x6400                               // 000000DF5B24: D6220039 03FD0139 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF5B30: BF870113
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000DF5B34: D6220035 03FD0135 00006400
	v_lshlrev_b32_e32 v57, 16, v57                             // 000000DF5B40: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF5B44: BF870091
	v_and_or_b32 v53, 0xffff, v53, v57                         // 000000DF5B48: D6570035 04E66AFF 0000FFFF
	v_pk_fma_f16 v53, v53, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DF5B54: CC0E0035 0BFC0F35 0000C931
	v_and_b32_e32 v63, 0xffff, v64                             // 000000DF5B60: 367E80FF 0000FFFF
	v_sad_u8 v64, v65, 0, 0x6400                               // 000000DF5B68: D6220040 03FD0141 00006400
	v_mov_b32_e32 v65, v41                                     // 000000DF5B74: 7E820329
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DF5B78: BF870224
	v_dot2acc_f32_f16 v20, v53, v6                             // 000000DF5B7C: 04280D35
	v_dot2acc_f32_f16 v18, v53, v2                             // 000000DF5B80: 04240535
	v_lshl_or_b32 v61, v64, 16, v63                            // 000000DF5B84: D656003D 04FD2140
	v_mov_b32_e32 v63, v48                                     // 000000DF5B8C: 7E7E0330
	v_mov_b32_e32 v53, v37                                     // 000000DF5B90: 7E6A0325
	v_mov_b32_e32 v64, v49                                     // 000000DF5B94: 7E800331
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000DF5B98: BF870134
	v_pk_fma_f16 v59, v61, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DF5B9C: CC0E003B 0BFC0F3D 0000C931
	s_waitcnt vmcnt(0)                                         // 000000DF5BA8: BF8903F7
	v_bfe_u32 v61, v34, 4, 16                                  // 000000DF5BAC: D610003D 02410922
	v_dot2acc_f32_f16 v22, v59, v7                             // 000000DF5BB4: 042C0F3B
	v_dot2acc_f32_f16 v21, v59, v3                             // 000000DF5BB8: 042A073B
	v_bfe_u32 v59, v52, 8, 16                                  // 000000DF5BBC: D610003B 02411134
	v_and_b32_e32 v52, 0xffff, v52                             // 000000DF5BC4: 366868FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DF5BCC: BF870214
	v_dot2acc_f32_f16 v22, v54, v8                             // 000000DF5BD0: 042C1136
	v_dot2acc_f32_f16 v21, v54, v4                             // 000000DF5BD4: 042A0936
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DF5BD8: BF870214
	.long 0xd72c003b                                           // 000000DF5BDC: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000DF5BE0: 020276FF 83DCD12D
	.long 0xd72c0034                                           // 000000DF5BE8: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 000000DF5BEC: 020268FF 83DCD12D
	v_mov_b32_e32 v54, v46                                     // 000000DF5BF4: 7E6C032E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF5BF8: BF870193
	v_sad_u8 v59, v59, 0, 0x6400                               // 000000DF5BFC: D622003B 03FD013B 00006400
	v_sad_u8 v52, v52, 0, 0x6400                               // 000000DF5C08: D6220034 03FD0134 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF5C14: BF870112
	v_lshl_or_b32 v36, v59, 16, v58                            // 000000DF5C18: D6560024 04E9213B
	v_lshlrev_b32_e32 v52, 16, v52                             // 000000DF5C20: 30686890
	v_bfe_u32 v58, v35, 8, 16                                  // 000000DF5C24: D610003A 02411123
	v_bfe_u32 v59, v34, 12, 16                                 // 000000DF5C2C: D610003B 02411922
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DF5C34: BF870214
	v_pk_fma_f16 v36, v36, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DF5C38: CC0E0024 0BFC0F24 0000C931
	v_and_or_b32 v52, 0xffff, v60, v52                         // 000000DF5C44: D6570034 04D278FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DF5C50: BF870004
	.long 0xd72c003a                                           // 000000DF5C54: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000DF5C58: 020274FF 83DCD12D
	v_bfe_u32 v60, v34, 8, 16                                  // 000000DF5C60: D610003C 02411122
	.long 0xd72c003b                                           // 000000DF5C68: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000DF5C6C: 020276FF 83DCD12D
	v_dot2acc_f32_f16 v18, v36, v3                             // 000000DF5C74: 04240724
	v_pk_fma_f16 v52, v52, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DF5C78: CC0E0034 0BFC0F34 0000C931
	v_and_b32_e32 v57, 0xffff, v35                             // 000000DF5C84: 367246FF 0000FFFF
	v_bfe_u32 v35, v35, 4, 16                                  // 000000DF5C8C: D6100023 02410923
	v_and_b32_e32 v34, 0xffff, v34                             // 000000DF5C94: 364444FF 0000FFFF
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000DF5C9C: D622003A 03FD013A 00006400
	v_dot2acc_f32_f16 v18, v52, v4                             // 000000DF5CA8: 04240934
	.long 0xd72c0039                                           // 000000DF5CAC: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 000000DF5CB0: 020272FF 83DCD12D
	.long 0xd72c0023                                           // 000000DF5CB8: D72C0023
	v_cndmask_b32_e32 v1, 0x83dcd12d, v35, vcc_lo              // 000000DF5CBC: 020246FF 83DCD12D
	.long 0xd72c003c                                           // 000000DF5CC4: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000DF5CC8: 020278FF 83DCD12D
	.long 0xd72c0022                                           // 000000DF5CD0: D72C0022
	v_cndmask_b32_e32 v1, 0x83dcd12d, v34, vcc_lo              // 000000DF5CD4: 020244FF 83DCD12D
	v_sad_u8 v59, v59, 0, 0x6400                               // 000000DF5CDC: D622003B 03FD013B 00006400
	v_lshl_or_b32 v56, v58, 16, v56                            // 000000DF5CE8: D6560038 04E1213A
	v_dot2acc_f32_f16 v20, v36, v7                             // 000000DF5CF0: 04280F24
	v_mov_b32_e32 v36, v43                                     // 000000DF5CF4: 7E48032B
	v_sad_u8 v57, v57, 0, 0x6400                               // 000000DF5CF8: D6220039 03FD0139 00006400
	v_sad_u8 v35, v35, 0, 0x6400                               // 000000DF5D04: D6220023 03FD0123 00006400
	v_pk_fma_f16 v55, v56, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DF5D10: CC0E0037 0BFC0F38 0000C931
	v_and_b32_e32 v58, 0xffff, v59                             // 000000DF5D1C: 367476FF 0000FFFF
	v_sad_u8 v59, v60, 0, 0x6400                               // 000000DF5D24: D622003B 03FD013C 00006400
	v_lshlrev_b32_e32 v57, 16, v57                             // 000000DF5D30: 30727290
	v_sad_u8 v34, v34, 0, 0x6400                               // 000000DF5D34: D6220022 03FD0122 00006400
	v_dot2acc_f32_f16 v17, v55, v5                             // 000000DF5D40: 04220B37
	v_dot2acc_f32_f16 v15, v55, v1                             // 000000DF5D44: 041E0337
	v_lshl_or_b32 v56, v59, 16, v58                            // 000000DF5D48: D6560038 04E9213B
	v_and_or_b32 v35, 0xffff, v35, v57                         // 000000DF5D50: D6570023 04E646FF 0000FFFF
	.long 0xd72c0039                                           // 000000DF5D5C: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000DF5D60: 02027AFF 83DCD12D
	v_lshlrev_b32_e32 v34, 16, v34                             // 000000DF5D68: 30444490
	v_dot2acc_f32_f16 v20, v52, v8                             // 000000DF5D6C: 04281134
	v_pk_fma_f16 v1, v56, s7, 0xc931 op_sel_hi:[1,0,0]         // 000000DF5D70: CC0E0001 0BFC0F38 0000C931
	v_pk_fma_f16 v35, v35, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DF5D7C: CC0E0023 0BFC0F23 0000C931
	v_mov_b32_e32 v56, v38                                     // 000000DF5D88: 7E700326
	v_mov_b32_e32 v58, v47                                     // 000000DF5D8C: 7E74032F
	v_mov_b32_e32 v60, v47                                     // 000000DF5D90: 7E78032F
	v_sad_u8 v57, v57, 0, 0x6400                               // 000000DF5D94: D6220039 03FD0139 00006400
	v_dot2acc_f32_f16 v17, v35, v6                             // 000000DF5DA0: 04220D23
	v_dot2acc_f32_f16 v15, v35, v2                             // 000000DF5DA4: 041E0523
	v_mov_b32_e32 v59, v39                                     // 000000DF5DA8: 7E760327
	v_dual_mov_b32 v61, v48 :: v_dual_mov_b32 v6, v51          // 000000DF5DAC: CA100130 3D060133
	v_and_or_b32 v5, 0xffff, v57, v34                          // 000000DF5DB4: D6570005 048A72FF 0000FFFF
	v_dot2acc_f32_f16 v17, v1, v7                              // 000000DF5DC0: 04220F01
	v_dot2acc_f32_f16 v15, v1, v3                              // 000000DF5DC4: 041E0701
	v_mov_b32_e32 v57, v46                                     // 000000DF5DC8: 7E72032E
	v_dual_mov_b32 v3, v50 :: v_dual_mov_b32 v34, v43          // 000000DF5DCC: CA100132 0322012B
	v_pk_fma_f16 v2, v5, s7, 0xc931 op_sel_hi:[1,0,0]          // 000000DF5DD4: CC0E0002 0BFC0F05 0000C931
	v_mov_b32_e32 v5, v51                                      // 000000DF5DE0: 7E0A0333
	v_mov_b32_e32 v55, v45                                     // 000000DF5DE4: 7E6E032D
	v_dual_mov_b32 v52, v45 :: v_dual_mov_b32 v35, v10         // 000000DF5DE8: CA10012D 3422010A
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DF5DF0: BF870004
	v_dot2acc_f32_f16 v17, v2, v8                              // 000000DF5DF4: 04221102
	v_dual_dot2acc_f32_f16 v15, v2, v4 :: v_dual_mov_b32 v2, v44// 000000DF5DF8: CB100902 0F02012C
	v_dual_mov_b32 v4, v42 :: v_dual_mov_b32 v1, v9            // 000000DF5E00: CA10012A 04000109
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 000000DF5E08: 917E067E
	s_cbranch_execz 58                                         // 000000DF5E0C: BFA5003A <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi2EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x1af8>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DF5E10: BF8700A1
	v_add_nc_u32_e32 v9, 1, v1                                 // 000000DF5E14: 4A120281
	s_mov_b32 s8, exec_lo                                      // 000000DF5E18: BE88007E
	.long 0xd4c1007e                                           // 000000DF5E1C: D4C1007E
	v_cndmask_b32_e32 v1, v9, v14, vcc_lo                      // 000000DF5E20: 02021D09
	s_cbranch_execz 64606                                      // 000000DF5E24: BFA5FC5E <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi2EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0xba0>
	v_ashrrev_i32_e32 v10, 31, v9                              // 000000DF5E28: 3414129F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF5E2C: BF870091
	.long 0xd73c0007                                           // 000000DF5E30: D73C0007
	v_cndmask_b32_e32 v1, 10, v9, vcc_lo                       // 000000DF5E34: 0202128A
	.long 0xd7006a0a                                           // 000000DF5E38: D7006A0A
	v_cndmask_b32_e32 v1, s4, v7, vcc_lo                       // 000000DF5E3C: 02020E04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF5E40: BF870111
	v_add_co_ci_u32_e64 v37, null, s5, v8, vcc_lo              // 000000DF5E44: D5207C25 01AA1005
	.long 0xd7006a07                                           // 000000DF5E4C: D7006A07
	v_cndmask_b32_e32 v1, v10, v33, vcc_lo                     // 000000DF5E50: 0202430A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DF5E54: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v37, vcc_lo               // 000000DF5E58: D5207C08 01AA4A80
	.long 0xd7006a44                                           // 000000DF5E60: D7006A44
	v_cndmask_b32_e32 v1, v10, v32, vcc_lo                     // 000000DF5E64: 0202410A
	v_add_co_ci_u32_e64 v69, null, 0, v37, vcc_lo              // 000000DF5E68: D5207C45 01AA4A80
	s_clause 0xf                                               // 000000DF5E70: BF85000F
	global_load_b32 v42, v[7:8], off                           // 000000DF5E74: DC520000 2A7C0007
	global_load_b32 v44, v[7:8], off offset:128                // 000000DF5E7C: DC520080 2C7C0007
	global_load_b32 v41, v[7:8], off offset:256                // 000000DF5E84: DC520100 297C0007
	global_load_b32 v40, v[7:8], off offset:384                // 000000DF5E8C: DC520180 287C0007
	global_load_b32 v39, v[7:8], off offset:512                // 000000DF5E94: DC520200 277C0007
	global_load_b32 v38, v[7:8], off offset:640                // 000000DF5E9C: DC520280 267C0007
	global_load_b32 v37, v[7:8], off offset:768                // 000000DF5EA4: DC520300 257C0007
	global_load_b32 v10, v[7:8], off offset:896                // 000000DF5EAC: DC520380 0A7C0007
	global_load_b32 v51, v[68:69], off                         // 000000DF5EB4: DC520000 337C0044
	global_load_b32 v50, v[68:69], off offset:128              // 000000DF5EBC: DC520080 327C0044
	global_load_b32 v49, v[68:69], off offset:256              // 000000DF5EC4: DC520100 317C0044
	global_load_b32 v48, v[68:69], off offset:384              // 000000DF5ECC: DC520180 307C0044
	global_load_b32 v47, v[68:69], off offset:512              // 000000DF5ED4: DC520200 2F7C0044
	global_load_b32 v46, v[68:69], off offset:640              // 000000DF5EDC: DC520280 2E7C0044
	global_load_b32 v45, v[68:69], off offset:768              // 000000DF5EE4: DC520300 2D7C0044
	global_load_b32 v43, v[68:69], off offset:896              // 000000DF5EEC: DC520380 2B7C0044
	s_branch 64554                                             // 000000DF5EF4: BFA0FC2A <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi2EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0xba0>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000DF5EF8: 8C7E067E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000DF5EFC: BF870009
	s_or_b32 exec_lo, exec_lo, s3                              // 000000DF5F00: 8C7E037E
	s_waitcnt vmcnt(22)                                        // 000000DF5F04: BF895BF7
	v_dual_mov_b32 v1, v30 :: v_dual_mov_b32 v2, v27           // 000000DF5F08: CA10011E 0102011B
	s_waitcnt vmcnt(14)                                        // 000000DF5F10: BF893BF7
	v_dual_mov_b32 v3, v29 :: v_dual_mov_b32 v6, v28           // 000000DF5F14: CA10011D 0306011C
	v_dual_mov_b32 v4, v23 :: v_dual_mov_b32 v9, v25           // 000000DF5F1C: CA100117 04080119
	s_waitcnt vmcnt(7)                                         // 000000DF5F24: BF891FF7
	v_dual_mov_b32 v5, v19 :: v_dual_mov_b32 v8, v26           // 000000DF5F28: CA100113 0508011A
	v_dual_mov_b32 v7, v16 :: v_dual_mov_b32 v14, v22          // 000000DF5F30: CA100110 070E0116
	v_dual_mov_b32 v10, v24 :: v_dual_mov_b32 v31, v21         // 000000DF5F38: CA100118 0A1E0115
	v_dual_mov_b32 v32, v20 :: v_dual_mov_b32 v33, v18         // 000000DF5F40: CA100114 20200112
	s_waitcnt vmcnt(0)                                         // 000000DF5F48: BF8903F7
	v_dual_mov_b32 v34, v17 :: v_dual_mov_b32 v35, v15         // 000000DF5F4C: CA100111 2222010F
	s_mov_b32 s3, 0x76543210                                   // 000000DF5F54: BE8300FF 76543210
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000DF5F5C: BF870009
	v_permlanex16_b32 v1, v1, s3, 0xfedcba98                   // 000000DF5F60: D65C0001 03FC0701 FEDCBA98
	v_permlanex16_b32 v2, v2, s3, 0xfedcba98                   // 000000DF5F6C: D65C0002 03FC0702 FEDCBA98
	v_permlanex16_b32 v3, v3, s3, 0xfedcba98                   // 000000DF5F78: D65C0003 03FC0703 FEDCBA98
	v_permlanex16_b32 v6, v6, s3, 0xfedcba98                   // 000000DF5F84: D65C0006 03FC0706 FEDCBA98
	v_permlanex16_b32 v4, v4, s3, 0xfedcba98                   // 000000DF5F90: D65C0004 03FC0704 FEDCBA98
	v_permlanex16_b32 v5, v5, s3, 0xfedcba98                   // 000000DF5F9C: D65C0005 03FC0705 FEDCBA98
	v_permlanex16_b32 v8, v8, s3, 0xfedcba98                   // 000000DF5FA8: D65C0008 03FC0708 FEDCBA98
	v_permlanex16_b32 v9, v9, s3, 0xfedcba98                   // 000000DF5FB4: D65C0009 03FC0709 FEDCBA98
	v_permlanex16_b32 v7, v7, s3, 0xfedcba98                   // 000000DF5FC0: D65C0007 03FC0707 FEDCBA98
	v_permlanex16_b32 v10, v10, s3, 0xfedcba98                 // 000000DF5FCC: D65C000A 03FC070A FEDCBA98
	v_permlanex16_b32 v14, v14, s3, 0xfedcba98                 // 000000DF5FD8: D65C000E 03FC070E FEDCBA98
	v_permlanex16_b32 v31, v31, s3, 0xfedcba98                 // 000000DF5FE4: D65C001F 03FC071F FEDCBA98
	v_permlanex16_b32 v32, v32, s3, 0xfedcba98                 // 000000DF5FF0: D65C0020 03FC0720 FEDCBA98
	v_permlanex16_b32 v33, v33, s3, 0xfedcba98                 // 000000DF5FFC: D65C0021 03FC0721 FEDCBA98
	v_permlanex16_b32 v34, v34, s3, 0xfedcba98                 // 000000DF6008: D65C0022 03FC0722 FEDCBA98
	v_permlanex16_b32 v35, v35, s3, 0xfedcba98                 // 000000DF6014: D65C0023 03FC0723 FEDCBA98
	.long 0xd44c0003                                           // 000000DF6020: D44C0003
	v_cndmask_b32_e32 v1, 16, v12, vcc_lo                      // 000000DF6024: 02021890
	s_barrier                                                  // 000000DF6028: BFBD0000
	buffer_gl0_inv                                             // 000000DF602C: E0AC0000 00000000
	s_and_saveexec_b32 s4, s3                                  // 000000DF6034: BE842003
	s_cbranch_execz 34                                         // 000000DF6038: BFA50022 <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi2EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x1cc4>
	v_dual_add_f32 v12, v15, v35 :: v_dual_add_f32 v15, v17, v34// 000000DF603C: C908470F 0C0E4511
	v_dual_add_f32 v17, v18, v33 :: v_dual_add_f32 v18, v20, v32// 000000DF6044: C9084312 11124114
	v_dual_add_f32 v20, v21, v31 :: v_dual_add_f32 v1, v30, v1 // 000000DF604C: C9083F15 1400031E
	v_dual_add_f32 v10, v24, v10 :: v_dual_add_f32 v3, v29, v3 // 000000DF6054: C9081518 0A02071D
	v_lshl_or_b32 v13, v11, 10, v13                            // 000000DF605C: D656000D 0435150B
	v_add_f32_e32 v6, v28, v6                                  // 000000DF6064: 060C0D1C
	v_dual_add_f32 v2, v27, v2 :: v_dual_add_f32 v7, v16, v7   // 000000DF6068: C908051B 02060F10
	v_dual_add_f32 v8, v26, v8 :: v_dual_add_f32 v5, v19, v5   // 000000DF6070: C908111A 08040B13
	v_add_f32_e32 v4, v23, v4                                  // 000000DF6078: 06080917
	v_dual_add_f32 v14, v22, v14 :: v_dual_add_f32 v9, v25, v9 // 000000DF607C: C9081D16 0E081319
	ds_store_2addr_b32 v13, v1, v3 offset1:16                  // 000000DF6084: D8381000 0003010D
	ds_store_2addr_b32 v13, v2, v6 offset0:128 offset1:144     // 000000DF608C: D8389080 0006020D
	ds_store_2addr_b32 v13, v4, v8 offset0:32 offset1:48       // 000000DF6094: D8383020 0008040D
	ds_store_2addr_b32 v13, v5, v9 offset0:160 offset1:176     // 000000DF609C: D838B0A0 0009050D
	ds_store_2addr_b32 v13, v7, v14 offset0:64 offset1:80      // 000000DF60A4: D8385040 000E070D
	ds_store_2addr_b32 v13, v10, v20 offset0:192 offset1:208   // 000000DF60AC: D838D0C0 00140A0D
	ds_store_2addr_b32 v13, v18, v15 offset0:96 offset1:112    // 000000DF60B4: D8387060 000F120D
	ds_store_2addr_b32 v13, v17, v12 offset0:224 offset1:240   // 000000DF60BC: D838F0E0 000C110D
	s_or_b32 exec_lo, exec_lo, s4                              // 000000DF60C4: 8C7E047E
	.long 0xd44c0004                                           // 000000DF60C8: D44C0004
	v_cndmask_b32_e32 v1, 0x100, v0, vcc_lo                    // 000000DF60CC: 020200FF 00000100
	s_waitcnt lgkmcnt(0)                                       // 000000DF60D4: BF89FC07
	s_barrier                                                  // 000000DF60D8: BFBD0000
	buffer_gl0_inv                                             // 000000DF60DC: E0AC0000 00000000
	s_and_saveexec_b32 s5, s4                                  // 000000DF60E4: BE852004
	s_cbranch_execnz 7                                         // 000000DF60E8: BFA60007 <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi2EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x1d08>
	s_or_b32 exec_lo, exec_lo, s5                              // 000000DF60EC: 8C7E057E
	s_cmp_lt_i32 s11, 2                                        // 000000DF60F0: BF04820B
	s_mov_b32 s5, -1                                           // 000000DF60F4: BE8500C1
	s_cbranch_scc0 33                                          // 000000DF60F8: BFA10021 <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi2EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x1d80>
	s_and_b32 vcc_lo, exec_lo, s5                              // 000000DF60FC: 8B6A057E
	s_cbranch_vccnz 196                                        // 000000DF6100: BFA400C4 <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi2EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x2014>
	s_branch 577                                               // 000000DF6104: BFA00241 <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi2EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x260c>
	v_lshlrev_b32_e32 v7, 2, v0                                // 000000DF6108: 300E0082
	ds_load_2addr_stride64_b32 v[1:2], v7 offset1:4            // 000000DF610C: D8E00400 01000007
	ds_load_2addr_stride64_b32 v[3:4], v7 offset0:8 offset1:12 // 000000DF6114: D8E00C08 03000007
	ds_load_2addr_stride64_b32 v[5:6], v7 offset0:16 offset1:20// 000000DF611C: D8E01410 05000007
	s_waitcnt lgkmcnt(2)                                       // 000000DF6124: BF89FC27
	v_add_f32_e32 v1, 0, v1                                    // 000000DF6128: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DF612C: BF8700A1
	v_add_f32_e32 v1, v1, v2                                   // 000000DF6130: 06020501
	s_waitcnt lgkmcnt(1)                                       // 000000DF6134: BF89FC17
	v_add_f32_e32 v3, v1, v3                                   // 000000DF6138: 06060701
	ds_load_2addr_stride64_b32 v[1:2], v7 offset0:24 offset1:28// 000000DF613C: D8E01C18 01000007
	v_add_f32_e32 v3, v3, v4                                   // 000000DF6144: 06060903
	s_waitcnt lgkmcnt(1)                                       // 000000DF6148: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF614C: BF870091
	v_add_f32_e32 v3, v3, v5                                   // 000000DF6150: 06060B03
	v_add_f32_e32 v3, v3, v6                                   // 000000DF6154: 06060D03
	s_waitcnt lgkmcnt(0)                                       // 000000DF6158: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF615C: BF870091
	v_add_f32_e32 v1, v3, v1                                   // 000000DF6160: 06020303
	v_add_f32_e32 v1, v1, v2                                   // 000000DF6164: 06020501
	ds_store_b32 v7, v1 offset:8192                            // 000000DF6168: D8342000 00000107
	s_or_b32 exec_lo, exec_lo, s5                              // 000000DF6170: 8C7E057E
	s_cmp_lt_i32 s11, 2                                        // 000000DF6174: BF04820B
	s_mov_b32 s5, -1                                           // 000000DF6178: BE8500C1
	s_cbranch_scc1 65503                                       // 000000DF617C: BFA2FFDF <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi2EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x1cfc>
	s_waitcnt lgkmcnt(0)                                       // 000000DF6180: BF89FC07
	s_barrier                                                  // 000000DF6184: BFBD0000
	buffer_gl0_inv                                             // 000000DF6188: E0AC0000 00000000
	s_and_saveexec_b32 s5, s4                                  // 000000DF6190: BE852004
	s_cbranch_execz 41                                         // 000000DF6194: BFA50029 <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi2EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x1e3c>
	v_lshrrev_b32_e32 v1, 7, v0                                // 000000DF6198: 32020087
	s_ashr_i32 s6, s29, 31                                     // 000000DF619C: 86069F1D
	v_lshlrev_b32_e32 v4, 2, v0                                // 000000DF61A0: 30080082
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 000000DF61A4: BF8704D2
	v_lshl_or_b32 v1, s31, 1, v1                               // 000000DF61A8: D6560001 0405021F
	ds_load_b32 v4, v4 offset:8192                             // 000000DF61B0: D8D82000 04000004
	.long 0xd72c0003                                           // 000000DF61B8: D72C0003
	v_cndmask_b32_e32 v0, v1, v6, vcc_lo                       // 000000DF61BC: 02000D01
	v_mad_u64_u32 v[1:2], null, v1, s29, 0                     // 000000DF61C0: D6FE7C01 02003B01
	s_ashr_i32 s6, s31, 31                                     // 000000DF61C8: 86069F1F
	s_mul_i32 s6, s6, s29                                      // 000000DF61CC: 96061D06
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000DF61D0: BF870149
	v_add3_u32 v2, v2, v3, s6                                  // 000000DF61D4: D6550002 001A0702
	s_lshl_b32 s6, s34, 7                                      // 000000DF61DC: 84068722
	v_and_b32_e32 v3, 0x7f, v0                                 // 000000DF61E0: 360600FF 0000007F
	s_ashr_i32 s7, s6, 31                                      // 000000DF61E8: 86079F06
	.long 0xd73c0001                                           // 000000DF61EC: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000DF61F0: 02020282
	s_lshl_b64 s[6:7], s[6:7], 2                               // 000000DF61F4: 84868206
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000DF61F8: BF870132
	v_lshlrev_b32_e32 v3, 2, v3                                // 000000DF61FC: 30060682
	s_add_u32 s6, s26, s6                                      // 000000DF6200: 8006061A
	s_addc_u32 s7, s27, s7                                     // 000000DF6204: 8207071B
	.long 0xd7006a01                                           // 000000DF6208: D7006A01
	v_cndmask_b32_e32 v1, s6, v1, vcc_lo                       // 000000DF620C: 02020206
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF6210: BF870111
	v_add_co_ci_u32_e64 v2, null, s7, v2, vcc_lo               // 000000DF6214: D5207C02 01AA0407
	.long 0xd7006a01                                           // 000000DF621C: D7006A01
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 000000DF6220: 02020701
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DF6224: BF870001
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 000000DF6228: D5207C02 01AA0480
	s_waitcnt lgkmcnt(0)                                       // 000000DF6230: BF89FC07
	global_store_b32 v[1:2], v4, off                           // 000000DF6234: DC6A0000 007C0401
	s_or_b32 exec_lo, exec_lo, s5                              // 000000DF623C: 8C7E057E
	.long 0xd44a0005                                           // 000000DF6240: D44A0005
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 000000DF6244: 02020080
	s_waitcnt_vscnt null, 0x0                                  // 000000DF6248: BC7C0000
	buffer_gl1_inv                                             // 000000DF624C: E0B00000 00000000
	buffer_gl0_inv                                             // 000000DF6254: E0AC0000 00000000
	s_barrier                                                  // 000000DF625C: BFBD0000
	buffer_gl0_inv                                             // 000000DF6260: E0AC0000 00000000
	s_and_saveexec_b32 s6, s5                                  // 000000DF6268: BE862005
	s_cbranch_execz 29                                         // 000000DF626C: BFA5001D <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi2EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x1ee4>
	s_mov_b32 s8, exec_lo                                      // 000000DF6270: BE88007E
	s_mov_b32 s7, exec_lo                                      // 000000DF6274: BE87007E
	.long 0xd71f0001                                           // 000000DF6278: D71F0001
	v_cndmask_b32_e32 v0, s8, v128, vcc_lo                     // 000000DF627C: 02010008
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DF6280: BF870001
	v_cmpx_eq_u32_e32 0, v1                                    // 000000DF6284: 7D940280
	s_cbranch_execz 9                                          // 000000DF6288: BFA50009 <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi2EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x1eb0>
	s_lshl_b64 s[14:15], s[34:35], 2                           // 000000DF628C: 848E8222
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000DF6290: BF8704B9
	s_add_u32 s14, s36, s14                                    // 000000DF6294: 800E0E24
	s_addc_u32 s15, s37, s15                                   // 000000DF6298: 820F0F25
	s_bcnt1_i32_b32 s8, s8                                     // 000000DF629C: BE881808
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, s8              // 000000DF62A0: CA100080 02020008
	global_atomic_add_u32 v2, v2, v3, s[14:15] glc             // 000000DF62A8: DCD64000 020E0302
	s_or_b32 exec_lo, exec_lo, s7                              // 000000DF62B0: 8C7E077E
	s_waitcnt vmcnt(0)                                         // 000000DF62B4: BF8903F7
	v_readfirstlane_b32 s7, v2                                 // 000000DF62B8: 7E0E0502
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DF62BC: BF870001
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s7, v1       // 000000DF62C0: CA200080 02000207
	s_add_i32 s7, s11, -1                                      // 000000DF62C8: 8107C10B
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000DF62CC: BF870481
	v_cmp_eq_u32_e32 vcc_lo, s7, v1                            // 000000DF62D0: 7C940207
	v_cndmask_b32_e64 v1, 0, 1, vcc_lo                         // 000000DF62D4: D5010001 01A90280
	ds_store_b32 v2, v1 offset:15360                           // 000000DF62DC: D8343C00 00000102
	s_or_b32 exec_lo, exec_lo, s6                              // 000000DF62E4: 8C7E067E
	v_mov_b32_e32 v1, 0                                        // 000000DF62E8: 7E020280
	s_waitcnt lgkmcnt(0)                                       // 000000DF62EC: BF89FC07
	s_barrier                                                  // 000000DF62F0: BFBD0000
	buffer_gl0_inv                                             // 000000DF62F4: E0AC0000 00000000
	ds_load_b32 v1, v1 offset:15360                            // 000000DF62FC: D8D83C00 01000001
	s_waitcnt lgkmcnt(0)                                       // 000000DF6304: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 000000DF6308: 7C940280
	s_cbranch_vccnz 64                                         // 000000DF630C: BFA40040 <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi2EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x2010>
	buffer_gl1_inv                                             // 000000DF6310: E0B00000 00000000
	buffer_gl0_inv                                             // 000000DF6318: E0AC0000 00000000
	s_and_saveexec_b32 s6, s4                                  // 000000DF6320: BE862004
	s_cbranch_execz 46                                         // 000000DF6324: BFA5002E <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi2EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x1fe0>
	v_and_b32_e32 v2, 0x7f, v0                                 // 000000DF6328: 360400FF 0000007F
	s_lshl_b32 s8, s34, 7                                      // 000000DF6330: 84088722
	s_ashr_i32 s4, s29, 31                                     // 000000DF6334: 86049F1D
	s_ashr_i32 s9, s8, 31                                      // 000000DF6338: 86099F08
	v_lshrrev_b32_e32 v1, 7, v0                                // 000000DF633C: 32020087
	v_dual_mov_b32 v2, 0 :: v_dual_lshlrev_b32 v3, 2, v2       // 000000DF6340: CA220080 02020482
	s_lshl_b64 s[8:9], s[8:9], 2                               // 000000DF6348: 84888208
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DF634C: BF8700A9
	s_add_u32 s7, s26, s8                                      // 000000DF6350: 8007081A
	s_addc_u32 s8, s27, s9                                     // 000000DF6354: 8208091B
	.long 0xd7000703                                           // 000000DF6358: D7000703
	v_cndmask_b32_e32 v1, s7, v3, vcc_lo                       // 000000DF635C: 02020607
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DF6360: BF870001
	v_add_co_ci_u32_e64 v4, null, s8, 0, s7                    // 000000DF6364: D5207C04 001D0008
	s_mov_b32 s7, s29                                          // 000000DF636C: BE87001D
	s_nop 0                                                    // 000000DF6370: BF800000
	s_nop 0                                                    // 000000DF6374: BF800000
	s_nop 0                                                    // 000000DF6378: BF800000
	s_nop 0                                                    // 000000DF637C: BF800000
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000DF6380: BF8704A9
	v_mad_u64_u32 v[5:6], null, v1, s7, 0                      // 000000DF6384: D6FE7C05 02000F01
	s_add_i32 s11, s11, -1                                     // 000000DF638C: 810BC10B
	s_cmp_eq_u32 s11, 0                                        // 000000DF6390: BF06800B
	v_mad_u64_u32 v[6:7], null, v1, s4, v[6:7]                 // 000000DF6394: D6FE7C06 04180901
	v_add_nc_u32_e32 v1, 2, v1                                 // 000000DF639C: 4A020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF63A0: BF870092
	.long 0xd73c0005                                           // 000000DF63A4: D73C0005
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 000000DF63A8: 02020A82
	.long 0xd7006a05                                           // 000000DF63AC: D7006A05
	v_cndmask_b32_e32 v1, v3, v5, vcc_lo                       // 000000DF63B0: 02020B03
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DF63B4: BF870001
	v_add_co_ci_u32_e64 v6, null, v4, v6, vcc_lo               // 000000DF63B8: D5207C06 01AA0D04
	global_load_b32 v5, v[5:6], off glc                        // 000000DF63C0: DC524000 057C0005
	s_waitcnt vmcnt(0)                                         // 000000DF63C8: BF8903F7
	v_add_f32_e32 v2, v2, v5                                   // 000000DF63CC: 06040B02
	s_cbranch_scc0 65515                                       // 000000DF63D0: BFA1FFEB <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi2EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x1f80>
	v_lshlrev_b32_e32 v1, 2, v0                                // 000000DF63D4: 30020082
	ds_store_b32 v1, v2 offset:8192                            // 000000DF63D8: D8342000 00000201
	s_or_b32 exec_lo, exec_lo, s6                              // 000000DF63E0: 8C7E067E
	s_and_saveexec_b32 s4, s5                                  // 000000DF63E4: BE842005
	s_cbranch_execz 6                                          // 000000DF63E8: BFA50006 <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi2EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x2004>
	s_lshl_b64 s[6:7], s[34:35], 2                             // 000000DF63EC: 84868222
	v_mov_b32_e32 v1, 0                                        // 000000DF63F0: 7E020280
	s_add_u32 s6, s36, s6                                      // 000000DF63F4: 80060624
	s_addc_u32 s7, s37, s7                                     // 000000DF63F8: 82070725
	global_store_b32 v1, v1, s[6:7]                            // 000000DF63FC: DC6A0000 00060101
	s_or_b32 exec_lo, exec_lo, s4                              // 000000DF6404: 8C7E047E
	s_cbranch_execnz 2                                         // 000000DF6408: BFA60002 <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi2EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x2014>
	s_branch 383                                               // 000000DF640C: BFA0017F <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi2EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x260c>
	s_branch 382                                               // 000000DF6410: BFA0017E <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi2EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x260c>
	v_cmp_gt_i32_e32 vcc_lo, s28, v11                          // 000000DF6414: 7C88161C
	.long 0xd44c0004                                           // 000000DF6418: D44C0004
	v_cndmask_b32_e32 v1, 64, v0, vcc_lo                       // 000000DF641C: 020200C0
	s_waitcnt lgkmcnt(0)                                       // 000000DF6420: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 000000DF6424: BC7C0000
	s_barrier                                                  // 000000DF6428: BFBD0000
	buffer_gl0_inv                                             // 000000DF642C: E0AC0000 00000000
	s_and_b32 s4, vcc_lo, s4                                   // 000000DF6434: 8B04046A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000DF6438: BF870009
	s_and_saveexec_b32 s5, s4                                  // 000000DF643C: BE852004
	s_cbranch_execz 369                                        // 000000DF6440: BFA50171 <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi2EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x2608>
	v_and_b32_e32 v1, 15, v0                                   // 000000DF6444: 3602008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF6448: BF870091
	v_lshlrev_b32_e32 v2, 2, v1                                // 000000DF644C: 30040282
	v_lshl_or_b32 v2, v11, 9, v2                               // 000000DF6450: D6560002 0409130B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DF6458: BF870001
	v_add_nc_u32_e32 v8, 0x2000, v2                            // 000000DF645C: 4A1004FF 00002000
	ds_load_2addr_b32 v[2:3], v8 offset1:16                    // 000000DF6464: D8DC1000 02000008
	ds_load_2addr_b32 v[4:5], v8 offset0:32 offset1:48         // 000000DF646C: D8DC3020 04000008
	ds_load_2addr_b32 v[6:7], v8 offset0:64 offset1:80         // 000000DF6474: D8DC5040 06000008
	ds_load_2addr_b32 v[8:9], v8 offset0:96 offset1:112        // 000000DF647C: D8DC7060 08000008
	v_and_b32_e32 v10, 1, v0                                   // 000000DF6484: 36140081
	s_waitcnt lgkmcnt(3)                                       // 000000DF6488: BF89FC37
	v_dual_add_f32 v14, v2, v3 :: v_dual_and_b32 v13, 4, v0    // 000000DF648C: C9240702 0E0C0084
	s_waitcnt lgkmcnt(2)                                       // 000000DF6494: BF89FC27
	v_dual_sub_f32 v2, v2, v3 :: v_dual_add_f32 v3, v4, v5     // 000000DF6498: C9480702 02020B04
	s_waitcnt lgkmcnt(1)                                       // 000000DF64A0: BF89FC17
	v_dual_sub_f32 v4, v4, v5 :: v_dual_add_f32 v5, v6, v7     // 000000DF64A4: C9480B04 04040F06
	s_waitcnt lgkmcnt(0)                                       // 000000DF64AC: BF89FC07
	v_dual_sub_f32 v6, v6, v7 :: v_dual_add_f32 v7, v8, v9     // 000000DF64B0: C9480F06 06061308
	v_sub_f32_e32 v8, v8, v9                                   // 000000DF64B8: 08101308
	v_dual_add_f32 v9, v14, v3 :: v_dual_and_b32 v12, 2, v0    // 000000DF64BC: C924070E 090C0082
	v_sub_f32_e32 v3, v14, v3                                  // 000000DF64C4: 0806070E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000DF64C8: BF8701B4
	v_dual_add_f32 v14, v2, v4 :: v_dual_add_f32 v15, v5, v7   // 000000DF64CC: C9080902 0E0E0F05
	v_sub_f32_e32 v2, v2, v4                                   // 000000DF64D4: 08040902
	v_dual_add_f32 v4, v6, v8 :: v_dual_sub_f32 v5, v5, v7     // 000000DF64D8: C90A1106 04040F05
	v_dual_sub_f32 v6, v6, v8 :: v_dual_add_f32 v7, v9, v15    // 000000DF64E0: C9481106 06061F09
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DF64E8: BF870222
	v_dual_sub_f32 v8, v9, v15 :: v_dual_add_f32 v9, v14, v4   // 000000DF64EC: C9481F09 0808090E
	v_sub_f32_e32 v4, v14, v4                                  // 000000DF64F4: 0808090E
	v_add_f32_e32 v14, v3, v5                                  // 000000DF64F8: 061C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 000000DF64FC: 08060B03
	v_add_f32_e32 v5, v2, v6                                   // 000000DF6500: 060A0D02
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 000000DF6504: 7C941480
	v_mov_b32_dpp v10, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DF6508: 7E1402FA FF016109
	v_mov_b32_dpp v18, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DF6510: 7E2402FA FF016104
	v_mov_b32_dpp v15, v14 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DF6518: 7E1E02FA FF01610E
	v_mov_b32_dpp v16, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DF6520: 7E2002FA FF016105
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000DF6528: D5010009 21AA1309
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000DF6530: D5010005 21AA0B05
	v_sub_f32_e32 v2, v2, v6                                   // 000000DF6538: 08040D02
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000DF653C: D5010004 21AA0904
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 000000DF6544: D501000E 21AA1D0E
	v_mov_b32_dpp v17, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DF654C: 7E2202FA FF016108
	v_add_f32_e32 v5, v5, v16                                  // 000000DF6554: 060A2105
	v_mov_b32_dpp v21, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DF6558: 7E2A02FA FF016102
	v_cndmask_b32_e64 v22, -v2, v2, vcc_lo                     // 000000DF6560: D5010016 21AA0502
	v_add_f32_e32 v2, v9, v10                                  // 000000DF6568: 06041509
	v_add_f32_e32 v9, v4, v18                                  // 000000DF656C: 06122504
	v_mov_b32_dpp v6, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DF6570: 7E0C02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000DF6578: D5010007 21AA0F07
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000DF6580: D5010008 21AA1108
	v_mov_b32_dpp v19, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DF6588: 7E2602FA FF016103
	v_cndmask_b32_e64 v20, -v3, v3, vcc_lo                     // 000000DF6590: D5010014 21AA0703
	v_cmp_eq_u32_e32 vcc_lo, 0, v12                            // 000000DF6598: 7C941880
	v_add_f32_e32 v3, v7, v6                                   // 000000DF659C: 06060D07
	.long 0xd44a0004                                           // 000000DF65A0: D44A0004
	v_cndmask_b32_e32 v1, 0, v13, vcc_lo                       // 000000DF65A4: 02021A80
	v_mov_b32_dpp v12, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DF65A8: 7E1802FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000DF65B0: D5010005 21AA0B05
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DF65B8: BF8700A4
	v_mov_b32_dpp v4, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DF65BC: 7E0802FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000DF65C4: D5010003 21AA0703
	v_add_f32_e32 v3, v3, v4                                   // 000000DF65CC: 06060903
	v_mov_b32_dpp v7, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DF65D0: 7E0E02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 000000DF65D8: D5010002 21AA0502
	v_add_f32_e32 v4, v5, v12                                  // 000000DF65E0: 06081905
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DF65E4: BF8700A4
	v_mov_b32_dpp v5, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DF65E8: 7E0A02FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s4                          // 000000DF65F0: D5010003 20120703
	v_dual_add_f32 v2, v2, v7 :: v_dual_add_f32 v3, v3, v5     // 000000DF65F8: C9080F02 02020B03
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DF6600: BF870001
	v_cndmask_b32_e64 v7, -v2, v2, s4                          // 000000DF6604: D5010007 20120502
	v_mov_b32_dpp v2, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DF660C: 7E0402FA FF016402
	v_add_f32_e32 v6, v14, v15                                 // 000000DF6614: 060C1F0E
	v_add_f32_e32 v14, v22, v21                                // 000000DF6618: 061C2B16
	v_mov_b32_dpp v15, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DF661C: 7E1E02FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000DF6624: D5010009 21AA1309
	v_add_f32_e32 v7, v7, v2                                   // 000000DF662C: 060E0507
	v_mov_b32_dpp v10, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DF6630: 7E1402FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 000000DF6638: D5010006 21AA0D06
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000DF6640: BF870234
	v_dual_add_f32 v8, v8, v17 :: v_dual_add_f32 v9, v9, v15   // 000000DF6644: C9082308 08081F09
	v_mov_b32_dpp v16, v14 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DF664C: 7E2002FA FF01620E
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 000000DF6654: D501000E 21AA1D0E
	v_add_f32_e32 v6, v6, v10                                  // 000000DF665C: 060C1506
	v_mov_b32_dpp v10, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DF6660: 7E1402FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s4                          // 000000DF6668: D5010004 20120904
	v_mov_b32_dpp v13, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DF6670: 7E1A02FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000DF6678: D5010008 21AA1108
	v_mov_b32_dpp v12, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DF6680: 7E1802FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s4                          // 000000DF6688: D5010006 20120D06
	v_add_f32_e32 v4, v4, v10                                  // 000000DF6690: 06081504
	v_add_f32_e32 v10, v20, v19                                // 000000DF6694: 06142714
	v_add_f32_e32 v8, v8, v13                                  // 000000DF6698: 06101B08
	v_mov_b32_dpp v2, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DF669C: 7E0402FA FF016803
	v_add_f32_e32 v6, v6, v12                                  // 000000DF66A4: 060C1906
	v_mov_b32_dpp v5, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DF66A8: 7E0A02FA FF016807
	v_mov_b32_dpp v13, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DF66B0: 7E1A02FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 000000DF66B8: D501000A 21AA150A
	v_mov_b32_dpp v12, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DF66C0: 7E1802FA FF016408
	v_cndmask_b32_e64 v15, -v8, v8, s4                         // 000000DF66C8: D501000F 20121108
	v_mov_b32_dpp v8, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DF66D0: 7E1002FA FF016806
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DF66D8: BF870004
	v_add_f32_e32 v10, v10, v13                                // 000000DF66DC: 06141B0A
	v_add_f32_e32 v13, v14, v16                                // 000000DF66E0: 061A210E
	v_mov_b32_dpp v14, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DF66E4: 7E1C02FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s4                          // 000000DF66EC: D5010009 20121309
	v_add_f32_e32 v15, v15, v12                                // 000000DF66F4: 061E190F
	v_mov_b32_dpp v16, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DF66F8: 7E2002FA FF01640A
	v_mov_b32_dpp v18, v13 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DF6700: 7E2402FA FF01640D
	v_cndmask_b32_e64 v10, -v10, v10, s4                       // 000000DF6708: D501000A 2012150A
	v_cndmask_b32_e64 v13, -v13, v13, s4                       // 000000DF6710: D501000D 20121B0D
	v_add_f32_e32 v17, v9, v14                                 // 000000DF6718: 06221D09
	v_mov_b32_dpp v9, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DF671C: 7E1202FA FF016804
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DF6724: BF870214
	v_add_f32_e32 v16, v10, v16                                // 000000DF6728: 0620210A
	v_add_f32_e32 v18, v13, v18                                // 000000DF672C: 0624250D
	v_mov_b32_dpp v10, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DF6730: 7E1402FA FF01680F
	v_mov_b32_dpp v12, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DF6738: 7E1802FA FF016811
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DF6740: BF870214
	v_mov_b32_dpp v13, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DF6744: 7E1A02FA FF016810
	v_mov_b32_dpp v14, v18 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DF674C: 7E1C02FA FF016812
	s_and_b32 exec_lo, exec_lo, s3                             // 000000DF6754: 8B7E037E
	s_cbranch_execz 171                                        // 000000DF6758: BFA500AB <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi2EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x2608>
	v_lshl_or_b32 v19, s34, 7, v1                              // 000000DF675C: D6560013 04050E22
	v_and_b32_e32 v1, 8, v0                                    // 000000DF6764: 36020088
	.long 0x7f2e3880                                           // 000000DF6768: 7F2E3880
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF676C: BF870113
	v_ashrrev_i32_e32 v20, 31, v19                             // 000000DF6770: 3428269F
	.long 0x7f303997                                           // 000000DF6774: 7F303997
	.long 0x7f323997                                           // 000000DF6778: 7F323997
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF677C: BF870093
	.long 0xd73c0013                                           // 000000DF6780: D73C0013
	v_cndmask_b32_e32 v1, 1, v19, vcc_lo                       // 000000DF6784: 02022681
	.long 0xd7006a15                                           // 000000DF6788: D7006A15
	v_cndmask_b32_e32 v1, s18, v19, vcc_lo                     // 000000DF678C: 02022612
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DF6790: BF870001
	v_add_co_ci_u32_e64 v22, null, s19, v20, vcc_lo            // 000000DF6794: D5207C16 01AA2813
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 000000DF679C: 7C940280
	s_clause 0x7                                               // 000000DF67A0: BF850007
	global_load_d16_b16 v23, v[21:22], off offset:32           // 000000DF67A4: DC820020 177C0015
	global_load_d16_b16 v24, v[21:22], off                     // 000000DF67AC: DC820000 187C0015
	global_load_d16_b16 v25, v[21:22], off offset:64           // 000000DF67B4: DC820040 197C0015
	global_load_d16_b16 v26, v[21:22], off offset:96           // 000000DF67BC: DC820060 1A7C0015
	global_load_d16_b16 v27, v[21:22], off offset:128          // 000000DF67C4: DC820080 1B7C0015
	global_load_d16_b16 v28, v[21:22], off offset:160          // 000000DF67CC: DC8200A0 1C7C0015
	global_load_d16_b16 v29, v[21:22], off offset:192          // 000000DF67D4: DC8200C0 1D7C0015
	global_load_d16_b16 v30, v[21:22], off offset:224          // 000000DF67DC: DC8200E0 1E7C0015
	v_mad_i64_i32 v[21:22], null, s29, v11, 0                  // 000000DF67E4: D6FF7C15 0202161D
	v_cndmask_b32_e64 v1, -v7, v7, vcc_lo                      // 000000DF67EC: D5010001 21AA0F07
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000DF67F4: D5010003 21AA0703
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000DF67FC: D5010004 21AA0904
	v_cndmask_b32_e64 v15, -v15, v15, vcc_lo                   // 000000DF6804: D501000F 21AA1F0F
	v_cndmask_b32_e64 v16, -v16, v16, vcc_lo                   // 000000DF680C: D5010010 21AA2110
	v_add_f32_e32 v1, v1, v5                                   // 000000DF6814: 06020B01
	v_cndmask_b32_e64 v5, -v6, v6, vcc_lo                      // 000000DF6818: D5010005 21AA0D06
	.long 0xd73c0015                                           // 000000DF6820: D73C0015
	v_cndmask_b32_e32 v1, 1, v21, vcc_lo                       // 000000DF6824: 02022A81
	v_cndmask_b32_e64 v6, -v17, v17, vcc_lo                    // 000000DF6828: D5010006 21AA2311
	v_cndmask_b32_e64 v17, -v18, v18, vcc_lo                   // 000000DF6830: D5010011 21AA2512
	v_add_f32_e32 v4, v4, v9                                   // 000000DF6838: 06081304
	v_add_f32_e32 v9, v16, v13                                 // 000000DF683C: 06121B10
	s_waitcnt vmcnt(7)                                         // 000000DF6840: BF891FF7
	.long 0x7f0e3997                                           // 000000DF6844: 7F0E3997
	.long 0xd7006a12                                           // 000000DF6848: D7006A12
	v_cndmask_b32_e32 v1, s24, v21, vcc_lo                     // 000000DF684C: 02022A18
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000DF6850: BF8701C1
	v_add_co_ci_u32_e64 v21, null, s25, v22, vcc_lo            // 000000DF6854: D5207C15 01AA2C19
	v_add_f32_e32 v6, v6, v12                                  // 000000DF685C: 060C1906
	v_dual_add_f32 v5, v5, v8 :: v_dual_add_f32 v8, v15, v10   // 000000DF6860: C9081105 0508150F
	v_dual_add_f32 v3, v3, v2 :: v_dual_mul_f32 v22, 0x3db504f3, v1// 000000DF6868: C9060503 031602FF 3DB504F3
	v_mul_f32_e32 v6, 0x3db504f3, v6                           // 000000DF6874: 100C0CFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF687C: BF870193
	v_dual_mul_f32 v4, 0x3db504f3, v4 :: v_dual_mul_f32 v5, 0x3db504f3, v5// 000000DF6880: C8C608FF 04040AFF 3DB504F3
	v_dual_add_f32 v10, v17, v14 :: v_dual_mul_f32 v3, 0x3db504f3, v3// 000000DF688C: C9061D11 0A0206FF 3DB504F3
	v_dual_mul_f32 v8, 0x3db504f3, v8 :: v_dual_mul_f32 v9, 0x3db504f3, v9// 000000DF6898: C8C610FF 080812FF 3DB504F3
	.long 0x7f163997                                           // 000000DF68A4: 7F163997
	.long 0xd7006a01                                           // 000000DF68A8: D7006A01
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 000000DF68AC: 02022712
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DF68B0: BF870001
	v_add_co_ci_u32_e64 v2, null, v21, v20, vcc_lo             // 000000DF68B4: D5207C02 01AA2915
	v_fma_mix_f32 v12, v23, v22, neg(0) op_sel_hi:[1,0,0]      // 000000DF68BC: CC20000C 8A022D17
	s_waitcnt vmcnt(6)                                         // 000000DF68C4: BF891BF7
	v_fma_mix_f32 v3, v24, v3, neg(0) op_sel_hi:[1,0,0]        // 000000DF68C8: CC200003 8A020718
	s_waitcnt vmcnt(5)                                         // 000000DF68D0: BF8917F7
	v_fma_mix_f32 v5, v25, v5, neg(0) op_sel_hi:[1,0,0]        // 000000DF68D4: CC200005 8A020B19
	s_waitcnt vmcnt(4)                                         // 000000DF68DC: BF8913F7
	v_fma_mix_f32 v4, v26, v4, neg(0) op_sel_hi:[1,0,0]        // 000000DF68E0: CC200004 8A02091A
	s_waitcnt vmcnt(3)                                         // 000000DF68E8: BF890FF7
	v_fma_mix_f32 v8, v27, v8, neg(0) op_sel_hi:[1,0,0]        // 000000DF68EC: CC200008 8A02111B
	.long 0x7e2e398c                                           // 000000DF68F4: 7E2E398C
	v_mul_f32_e32 v10, 0x3db504f3, v10                         // 000000DF68F8: 101414FF 3DB504F3
	s_waitcnt vmcnt(2)                                         // 000000DF6900: BF890BF7
	v_fma_mix_f32 v6, v28, v6, neg(0) op_sel_hi:[1,0,0]        // 000000DF6904: CC200006 8A020D1C
	s_waitcnt vmcnt(1)                                         // 000000DF690C: BF8907F7
	v_fma_mix_f32 v9, v29, v9, neg(0) op_sel_hi:[1,0,0]        // 000000DF6910: CC200009 8A02131D
	.long 0x7e0e3983                                           // 000000DF6918: 7E0E3983
	v_and_b32_e32 v13, 1, v23                                  // 000000DF691C: 361A2E81
	.long 0x7e2e3984                                           // 000000DF6920: 7E2E3984
	s_waitcnt vmcnt(0)                                         // 000000DF6924: BF8903F7
	v_fma_mix_f32 v10, v30, v10, neg(0) op_sel_hi:[1,0,0]      // 000000DF6928: CC20000A 8A02151E
	.long 0x7e163985                                           // 000000DF6930: 7E163985
	.long 0x7e303988                                           // 000000DF6934: 7E303988
	.long 0x7e323989                                           // 000000DF6938: 7E323989
	v_and_b32_e32 v14, 1, v23                                  // 000000DF693C: 361C2E81
	.long 0x7e2e3986                                           // 000000DF6940: 7E2E3986
	v_and_b32_e32 v7, 1, v7                                    // 000000DF6944: 360E0E81
	v_and_b32_e32 v11, 1, v11                                  // 000000DF6948: 36161681
	v_and_b32_e32 v15, 1, v24                                  // 000000DF694C: 361E3081
	v_and_b32_e32 v17, 1, v25                                  // 000000DF6950: 36223281
	v_and_b32_e32 v16, 1, v23                                  // 000000DF6954: 36202E81
	.long 0x7e2e398a                                           // 000000DF6958: 7E2E398A
	v_add3_u32 v3, v3, v7, 0x7fff                              // 000000DF695C: D6550003 03FE0F03 00007FFF
	v_add3_u32 v12, v12, v13, 0x7fff                           // 000000DF6968: D655000C 03FE1B0C 00007FFF
	v_add3_u32 v5, v5, v11, 0x7fff                             // 000000DF6974: D6550005 03FE1705 00007FFF
	v_add3_u32 v4, v4, v14, 0x7fff                             // 000000DF6980: D6550004 03FE1D04 00007FFF
	v_and_b32_e32 v7, 1, v23                                   // 000000DF698C: 360E2E81
	v_add3_u32 v8, v8, v15, 0x7fff                             // 000000DF6990: D6550008 03FE1F08 00007FFF
	v_add3_u32 v9, v9, v17, 0x7fff                             // 000000DF699C: D6550009 03FE2309 00007FFF
	v_add3_u32 v6, v6, v16, 0x7fff                             // 000000DF69A8: D6550006 03FE2106 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DF69B4: BF870004
	v_add3_u32 v7, v10, v7, 0x7fff                             // 000000DF69B8: D6550007 03FE0F0A 00007FFF
	s_clause 0x7                                               // 000000DF69C4: BF850007
	global_store_d16_hi_b16 v[1:2], v3, off                    // 000000DF69C8: DC960000 007C0301
	global_store_d16_hi_b16 v[1:2], v12, off offset:32         // 000000DF69D0: DC960020 007C0C01
	global_store_d16_hi_b16 v[1:2], v5, off offset:64          // 000000DF69D8: DC960040 007C0501
	global_store_d16_hi_b16 v[1:2], v4, off offset:96          // 000000DF69E0: DC960060 007C0401
	global_store_d16_hi_b16 v[1:2], v8, off offset:128         // 000000DF69E8: DC960080 007C0801
	global_store_d16_hi_b16 v[1:2], v6, off offset:160         // 000000DF69F0: DC9600A0 007C0601
	global_store_d16_hi_b16 v[1:2], v9, off offset:192         // 000000DF69F8: DC9600C0 007C0901
	global_store_d16_hi_b16 v[1:2], v7, off offset:224         // 000000DF6A00: DC9600E0 007C0701
	s_or_b32 exec_lo, exec_lo, s5                              // 000000DF6A08: 8C7E057E
	s_mov_b32 s4, 0                                            // 000000DF6A0C: BE840080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000DF6A10: BF870009
	s_and_b32 vcc_lo, exec_lo, s4                              // 000000DF6A14: 8B6A047E
	s_cbranch_vccz 4575                                        // 000000DF6A18: BFA311DF <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi2EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x6d98>
	s_load_b512 s[16:31], s[0:1], null                         // 000000DF6A1C: F4100400 F8000000
	s_mov_b32 s1, exec_lo                                      // 000000DF6A24: BE81007E
	v_cmpx_gt_u32_e32 0x140, v0                                // 000000DF6A28: 7D9800FF 00000140
	s_cbranch_execz 39                                         // 000000DF6A30: BFA50027 <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi2EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x26d0>
	s_mul_hi_u32 s0, s2, 0x51eb851f                            // 000000DF6A34: 9680FF02 51EB851F
	v_lshlrev_b32_e32 v4, 4, v0                                // 000000DF6A3C: 30080084
	s_lshr_b32 s0, s0, 6                                       // 000000DF6A40: 85008600
	v_or_b32_e32 v3, 0xffffff00, v0                            // 000000DF6A44: 380600FF FFFFFF00
	s_mul_i32 s3, s0, 0x1400                                   // 000000DF6A4C: 9603FF00 00001400
	s_mul_hi_u32 s0, s0, 0x1400                                // 000000DF6A54: 9680FF00 00001400
	s_waitcnt lgkmcnt(0)                                       // 000000DF6A5C: BF89FC07
	s_add_u32 s3, s20, s3                                      // 000000DF6A60: 80030314
	s_addc_u32 s0, s21, s0                                     // 000000DF6A64: 82000015
	.long 0xd7000301                                           // 000000DF6A68: D7000301
	v_cndmask_b32_e32 v1, s3, v4, vcc_lo                       // 000000DF6A6C: 02020803
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DF6A70: BF870001
	v_add_co_ci_u32_e64 v2, null, s0, 0, s3                    // 000000DF6A74: D5207C02 000D0000
	s_mov_b32 s3, 0                                            // 000000DF6A7C: BE830080
	global_load_b128 v[5:8], v[1:2], off                       // 000000DF6A80: DC5E0000 057C0001
	v_add_nc_u32_e32 v3, 0x100, v3                             // 000000DF6A88: 4A0606FF 00000100
	.long 0xd7006a01                                           // 000000DF6A90: D7006A01
	v_cndmask_b32_e32 v1, 0x1000, v1, vcc_lo                   // 000000DF6A94: 020202FF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF6A9C: BF870191
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 000000DF6AA0: D5207C02 01AA0480
	.long 0xd4490000                                           // 000000DF6AA8: D4490000
	v_cndmask_b32_e32 v1, 63, v3, vcc_lo                       // 000000DF6AAC: 020206BF
	s_or_b32 s3, s0, s3                                        // 000000DF6AB0: 8C030300
	s_waitcnt vmcnt(0)                                         // 000000DF6AB4: BF8903F7
	ds_store_b128 v4, v[5:8] offset:10240                      // 000000DF6AB8: DB7C2800 00000504
	v_add_nc_u32_e32 v4, 0x1000, v4                            // 000000DF6AC0: 4A0808FF 00001000
	s_and_not1_b32 exec_lo, exec_lo, s3                        // 000000DF6AC8: 917E037E
	s_cbranch_execnz 65516                                     // 000000DF6ACC: BFA6FFEC <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi2EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x2680>
	s_or_b32 exec_lo, exec_lo, s1                              // 000000DF6AD0: 8C7E017E
	s_mul_hi_u32 s0, s2, 0xcccccccd                            // 000000DF6AD4: 9680FF02 CCCCCCCD
	v_lshrrev_b32_e32 v2, 2, v0                                // 000000DF6ADC: 32040082
	s_lshr_b32 s9, s0, 4                                       // 000000DF6AE0: 85098400
	s_waitcnt lgkmcnt(0)                                       // 000000DF6AE4: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 000000DF6AE8: BC7C0000
	s_lshl_b32 s0, s9, 2                                       // 000000DF6AEC: 84008209
	s_barrier                                                  // 000000DF6AF0: BFBD0000
	v_dual_mov_b32 v1, s0 :: v_dual_and_b32 v2, 56, v2         // 000000DF6AF4: CA240000 010204B8
	buffer_gl0_inv                                             // 000000DF6AFC: E0AC0000 00000000
	s_mul_i32 s0, s9, 0xffffffec                               // 000000DF6B04: 9600FF09 FFFFFFEC
	v_bfe_u32 v3, v0, 2, 3                                     // 000000DF6B0C: D6100003 020D0500
	global_load_b32 v1, v1, s[22:23]                           // 000000DF6B14: DC520000 01160001
	s_add_i32 s0, s0, s2                                       // 000000DF6B1C: 81000200
	v_dual_mov_b32 v94, 0 :: v_dual_and_b32 v87, 3, v0         // 000000DF6B20: CA240080 5E560083
	s_lshl_b32 s1, s0, 6                                       // 000000DF6B28: 84018600
	v_mov_b32_e32 v92, 0                                       // 000000DF6B2C: 7EB80280
	v_or3_b32 v81, s1, v2, v3                                  // 000000DF6B30: D6580051 040E0401
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DF6B38: BF870003
	v_lshlrev_b32_e32 v3, 4, v87                               // 000000DF6B3C: 3006AE84
	v_dual_mov_b32 v93, 0 :: v_dual_lshlrev_b32 v88, 6, v87    // 000000DF6B40: CA220080 5D58AE86
	ds_load_b128 v[33:36], v88 offset:10240                    // 000000DF6B48: DBFC2800 21000058
	ds_load_b128 v[45:48], v88 offset:10256                    // 000000DF6B50: DBFC2810 2D000058
	ds_load_b128 v[37:40], v88 offset:11520                    // 000000DF6B58: DBFC2D00 25000058
	ds_load_b128 v[41:44], v88 offset:11776                    // 000000DF6B60: DBFC2E00 29000058
	ds_load_b128 v[59:62], v88 offset:10496                    // 000000DF6B68: DBFC2900 3B000058
	ds_load_b128 v[49:52], v88 offset:10512                    // 000000DF6B70: DBFC2910 31000058
	v_ashrrev_i32_e32 v82, 31, v81                             // 000000DF6B78: 34A4A29F
	ds_load_b128 v[63:66], v88 offset:10752                    // 000000DF6B7C: DBFC2A00 3F000058
	ds_load_b128 v[53:56], v88 offset:10768                    // 000000DF6B84: DBFC2A10 35000058
	v_dual_mov_b32 v91, 0 :: v_dual_mov_b32 v90, 0             // 000000DF6B8C: CA100080 5B5A0080
	s_add_u32 s2, s16, s18                                     // 000000DF6B94: 80021210
	s_addc_u32 s3, s17, s19                                    // 000000DF6B98: 82031311
	s_mov_b32 s1, exec_lo                                      // 000000DF6B9C: BE81007E
	ds_load_b128 v[100:103], v88 offset:12080                  // 000000DF6BA0: DBFC2F30 64000058
	ds_load_b128 v[104:107], v88 offset:12336                  // 000000DF6BA8: DBFC3030 68000058
	s_waitcnt vmcnt(0)                                         // 000000DF6BB0: BF8903F7
	v_mad_i64_i32 v[85:86], null, 0x500, v1, v[81:82]          // 000000DF6BB4: D6FF7C55 054602FF 00000500
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF6BC0: BF870091
	v_mad_u64_u32 v[1:2], null, 0x500, v85, s[16:17]           // 000000DF6BC4: D6FE7C01 0042AAFF 00000500
	v_mad_i32_i24 v2, 0x500, v86, v2                           // 000000DF6BD0: D60A0002 040AACFF 00000500
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF6BDC: BF870092
	.long 0xd7006a53                                           // 000000DF6BE0: D7006A53
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 000000DF6BE4: 02020701
	v_add_co_ci_u32_e64 v84, null, 0, v2, vcc_lo               // 000000DF6BE8: D5207C54 01AA0480
	s_clause 0x7                                               // 000000DF6BF0: BF850007
	global_load_b128 v[29:32], v[83:84], off                   // 000000DF6BF4: DC5E0000 1D7C0053
	global_load_b128 v[25:28], v[83:84], off offset:64         // 000000DF6BFC: DC5E0040 197C0053
	global_load_b128 v[21:24], v[83:84], off offset:128        // 000000DF6C04: DC5E0080 157C0053
	global_load_b128 v[17:20], v[83:84], off offset:192        // 000000DF6C0C: DC5E00C0 117C0053
	global_load_b128 v[13:16], v[83:84], off offset:256        // 000000DF6C14: DC5E0100 0D7C0053
	global_load_b128 v[9:12], v[83:84], off offset:320         // 000000DF6C1C: DC5E0140 097C0053
	global_load_b128 v[5:8], v[83:84], off offset:384          // 000000DF6C24: DC5E0180 057C0053
	global_load_b128 v[1:4], v[83:84], off offset:448          // 000000DF6C2C: DC5E01C0 017C0053
	s_waitcnt vmcnt(7)                                         // 000000DF6C34: BF891FF7
	v_lshrrev_b32_e32 v57, 4, v29                              // 000000DF6C38: 32723A84
	v_and_b32_e32 v29, 0xf0f0f0f, v29                          // 000000DF6C3C: 363A3AFF 0F0F0F0F
	s_waitcnt vmcnt(6)                                         // 000000DF6C44: BF891BF7
	v_lshrrev_b32_e32 v58, 4, v25                              // 000000DF6C48: 32743284
	s_waitcnt vmcnt(5)                                         // 000000DF6C4C: BF8917F7
	v_lshrrev_b32_e32 v67, 4, v21                              // 000000DF6C50: 32862A84
	v_mov_b32_e32 v89, 0                                       // 000000DF6C54: 7EB20280
	v_and_b32_e32 v57, 0xf0f0f0f, v57                          // 000000DF6C58: 367272FF 0F0F0F0F
	v_and_b32_e32 v25, 0xf0f0f0f, v25                          // 000000DF6C60: 363232FF 0F0F0F0F
	v_and_b32_e32 v21, 0xf0f0f0f, v21                          // 000000DF6C68: 362A2AFF 0F0F0F0F
	v_and_b32_e32 v58, 0xf0f0f0f, v58                          // 000000DF6C70: 367474FF 0F0F0F0F
	v_and_b32_e32 v67, 0xf0f0f0f, v67                          // 000000DF6C78: 368686FF 0F0F0F0F
	v_perm_b32 v68, v57, v29, 0xc040c00                        // 000000DF6C80: D6440044 03FE3B39 0C040C00
	v_perm_b32 v69, v57, v29, 0xc050c01                        // 000000DF6C8C: D6440045 03FE3B39 0C050C01
	v_perm_b32 v70, v57, v29, 0xc060c02                        // 000000DF6C98: D6440046 03FE3B39 0C060C02
	v_perm_b32 v29, v57, v29, 0xc070c03                        // 000000DF6CA4: D644001D 03FE3B39 0C070C03
	v_perm_b32 v57, v58, v25, 0xc040c00                        // 000000DF6CB0: D6440039 03FE333A 0C040C00
	v_perm_b32 v71, v67, v21, 0xc040c00                        // 000000DF6CBC: D6440047 03FE2B43 0C040C00
	v_perm_b32 v72, v58, v25, 0xc050c01                        // 000000DF6CC8: D6440048 03FE333A 0C050C01
	v_perm_b32 v73, v58, v25, 0xc060c02                        // 000000DF6CD4: D6440049 03FE333A 0C060C02
	v_perm_b32 v25, v58, v25, 0xc070c03                        // 000000DF6CE0: D6440019 03FE333A 0C070C03
	v_perm_b32 v58, v67, v21, 0xc050c01                        // 000000DF6CEC: D644003A 03FE2B43 0C050C01
	v_perm_b32 v74, v67, v21, 0xc060c02                        // 000000DF6CF8: D644004A 03FE2B43 0C060C02
	v_perm_b32 v21, v67, v21, 0xc070c03                        // 000000DF6D04: D6440015 03FE2B43 0C070C03
	v_or_b32_e32 v67, 0x64006400, v68                          // 000000DF6D10: 388688FF 64006400
	v_or_b32_e32 v68, 0x64006400, v69                          // 000000DF6D18: 38888AFF 64006400
	v_or_b32_e32 v69, 0x64006400, v70                          // 000000DF6D20: 388A8CFF 64006400
	v_or_b32_e32 v57, 0x64006400, v57                          // 000000DF6D28: 387272FF 64006400
	v_or_b32_e32 v70, 0x64006400, v71                          // 000000DF6D30: 388C8EFF 64006400
	.long 0xcc0f4043                                           // 000000DF6D38: CC0F4043
	v_mul_i32_i24_e32 v1, 0xe408, v67                          // 000000DF6D3C: 120286FF 0000E408
	v_or_b32_e32 v71, 0x64006400, v72                          // 000000DF6D44: 388E90FF 64006400
	v_or_b32_e32 v58, 0x64006400, v58                          // 000000DF6D4C: 387474FF 64006400
	.long 0xcc0f4044                                           // 000000DF6D54: CC0F4044
	v_mul_i32_i24_e32 v1, 0xe408, v68                          // 000000DF6D58: 120288FF 0000E408
	.long 0xcc0f4039                                           // 000000DF6D60: CC0F4039
	v_mul_i32_i24_e32 v1, 0xe408, v57                          // 000000DF6D64: 120272FF 0000E408
	.long 0xcc0f4046                                           // 000000DF6D6C: CC0F4046
	v_mul_i32_i24_e32 v1, 0xe408, v70                          // 000000DF6D70: 12028CFF 0000E408
	s_waitcnt lgkmcnt(9)                                       // 000000DF6D78: BF89FC97
	v_dot2acc_f32_f16 v94, v67, v33                            // 000000DF6D7C: 04BC4343
	.long 0xcc0f4021                                           // 000000DF6D80: CC0F4021
	v_mul_i32_i24_e32 v1, 0xe408, v71                          // 000000DF6D84: 12028EFF 0000E408
	.long 0xcc0f403a                                           // 000000DF6D8C: CC0F403A
	v_mul_i32_i24_e32 v1, 0xe408, v58                          // 000000DF6D90: 120274FF 0000E408
	s_waitcnt lgkmcnt(5)                                       // 000000DF6D98: BF89FC57
	v_dot2acc_f32_f16 v93, v57, v59                            // 000000DF6D9C: 04BA7739
	s_waitcnt lgkmcnt(3)                                       // 000000DF6DA0: BF89FC37
	v_dot2acc_f32_f16 v92, v70, v63                            // 000000DF6DA4: 04B87F46
	v_dot2acc_f32_f16 v94, v68, v34                            // 000000DF6DA8: 04BC4544
	v_or_b32_e32 v34, 0x64006400, v74                          // 000000DF6DAC: 384494FF 64006400
	v_or_b32_e32 v72, 0x64006400, v73                          // 000000DF6DB4: 389092FF 64006400
	v_dot2acc_f32_f16 v93, v33, v60                            // 000000DF6DBC: 04BA7921
	v_dot2acc_f32_f16 v92, v58, v64                            // 000000DF6DC0: 04B8813A
	v_or_b32_e32 v21, 0x64006400, v21                          // 000000DF6DC4: 382A2AFF 64006400
	.long 0xcc0f4021                                           // 000000DF6DCC: CC0F4021
	v_mul_i32_i24_e32 v1, 0xe408, v34                          // 000000DF6DD0: 120244FF 0000E408
	.long 0xcc0f4045                                           // 000000DF6DD8: CC0F4045
	v_mul_i32_i24_e32 v1, 0xe408, v69                          // 000000DF6DDC: 12028AFF 0000E408
	.long 0xcc0f403f                                           // 000000DF6DE4: CC0F403F
	v_mul_i32_i24_e32 v1, 0xe408, v72                          // 000000DF6DE8: 120290FF 0000E408
	v_or_b32_e32 v29, 0x64006400, v29                          // 000000DF6DF0: 383A3AFF 64006400
	v_or_b32_e32 v25, 0x64006400, v25                          // 000000DF6DF8: 383232FF 64006400
	s_waitcnt vmcnt(4)                                         // 000000DF6E00: BF8913F7
	v_lshrrev_b32_e32 v34, 4, v17                              // 000000DF6E04: 32442284
	v_dot2acc_f32_f16 v92, v33, v65                            // 000000DF6E08: 04B88321
	.long 0xcc0f4015                                           // 000000DF6E0C: CC0F4015
	v_mul_i32_i24_e32 v1, 0xe408, v21                          // 000000DF6E10: 12022AFF 0000E408
	v_dot2acc_f32_f16 v94, v69, v35                            // 000000DF6E18: 04BC4745
	.long 0xcc0f401d                                           // 000000DF6E1C: CC0F401D
	v_mul_i32_i24_e32 v1, 0xe408, v29                          // 000000DF6E20: 12023AFF 0000E408
	.long 0xcc0f4019                                           // 000000DF6E28: CC0F4019
	v_mul_i32_i24_e32 v1, 0xe408, v25                          // 000000DF6E2C: 120232FF 0000E408
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DF6E34: BF870004
	v_dual_dot2acc_f32_f16 v92, v21, v66 :: v_dual_and_b32 v17, 0xf0f0f0f, v17// 000000DF6E38: CB248515 5C1022FF 0F0F0F0F
	v_and_b32_e32 v65, 0xf0f0f0f, v34                          // 000000DF6E44: 368244FF 0F0F0F0F
	s_waitcnt vmcnt(2)                                         // 000000DF6E4C: BF890BF7
	v_and_b32_e32 v66, 0xf0f0f0f, v9                           // 000000DF6E50: 368412FF 0F0F0F0F
	v_dual_dot2acc_f32_f16 v93, v63, v61 :: v_dual_dot2acc_f32_f16 v94, v29, v36// 000000DF6E58: CB187B3F 5D5E491D
	ds_load_b128 v[67:70], v88 offset:11008                    // 000000DF6E60: DBFC2B00 43000058
	ds_load_b128 v[57:60], v88 offset:11024                    // 000000DF6E68: DBFC2B10 39000058
	v_lshrrev_b32_e32 v29, 4, v13                              // 000000DF6E70: 323A1A84
	v_perm_b32 v21, v65, v17, 0xc050c01                        // 000000DF6E74: D6440015 03FE2341 0C050C01
	v_dot2acc_f32_f16 v93, v25, v62                            // 000000DF6E80: 04BA7D19
	v_perm_b32 v25, v65, v17, 0xc040c00                        // 000000DF6E84: D6440019 03FE2341 0C040C00
	ds_load_b128 v[33:36], v88 offset:11264                    // 000000DF6E90: DBFC2C00 21000058
	ds_load_b128 v[61:64], v88 offset:11280                    // 000000DF6E98: DBFC2C10 3D000058
	v_and_b32_e32 v13, 0xf0f0f0f, v13                          // 000000DF6EA0: 361A1AFF 0F0F0F0F
	v_or_b32_e32 v21, 0x64006400, v21                          // 000000DF6EA8: 382A2AFF 64006400
	v_and_b32_e32 v29, 0xf0f0f0f, v29                          // 000000DF6EB0: 363A3AFF 0F0F0F0F
	v_or_b32_e32 v25, 0x64006400, v25                          // 000000DF6EB8: 383232FF 64006400
	v_perm_b32 v71, v65, v17, 0xc060c02                        // 000000DF6EC0: D6440047 03FE2341 0C060C02
	v_perm_b32 v17, v65, v17, 0xc070c03                        // 000000DF6ECC: D6440011 03FE2341 0C070C03
	.long 0xcc0f4015                                           // 000000DF6ED8: CC0F4015
	v_mul_i32_i24_e32 v1, 0xe408, v21                          // 000000DF6EDC: 12022AFF 0000E408
	v_lshrrev_b32_e32 v9, 4, v9                                // 000000DF6EE4: 32121284
	.long 0xcc0f4019                                           // 000000DF6EE8: CC0F4019
	v_mul_i32_i24_e32 v1, 0xe408, v25                          // 000000DF6EEC: 120232FF 0000E408
	v_or_b32_e32 v65, 0x64006400, v71                          // 000000DF6EF4: 38828EFF 64006400
	v_or_b32_e32 v17, 0x64006400, v17                          // 000000DF6EFC: 382222FF 64006400
	v_mov_b32_e32 v95, 0                                       // 000000DF6F04: 7EBE0280
	s_waitcnt lgkmcnt(3)                                       // 000000DF6F08: BF89FC37
	v_dot2acc_f32_f16 v91, v25, v67                            // 000000DF6F0C: 04B68719
	v_perm_b32 v67, v29, v13, 0xc040c00                        // 000000DF6F10: D6440043 03FE1B1D 0C040C00
	.long 0xcc0f4041                                           // 000000DF6F1C: CC0F4041
	v_mul_i32_i24_e32 v1, 0xe408, v65                          // 000000DF6F20: 120282FF 0000E408
	.long 0xcc0f4011                                           // 000000DF6F28: CC0F4011
	v_mul_i32_i24_e32 v1, 0xe408, v17                          // 000000DF6F2C: 120222FF 0000E408
	s_waitcnt vmcnt(1)                                         // 000000DF6F34: BF8907F7
	v_lshrrev_b32_e32 v25, 4, v5                               // 000000DF6F38: 32320A84
	v_dot2acc_f32_f16 v91, v21, v68                            // 000000DF6F3C: 04B68915
	v_perm_b32 v21, v29, v13, 0xc050c01                        // 000000DF6F40: D6440015 03FE1B1D 0C050C01
	v_or_b32_e32 v67, 0x64006400, v67                          // 000000DF6F4C: 388686FF 64006400
	v_and_b32_e32 v5, 0xf0f0f0f, v5                            // 000000DF6F54: 360A0AFF 0F0F0F0F
	v_and_b32_e32 v25, 0xf0f0f0f, v25                          // 000000DF6F5C: 363232FF 0F0F0F0F
	v_dot2acc_f32_f16 v91, v65, v69                            // 000000DF6F64: 04B68B41
	v_or_b32_e32 v21, 0x64006400, v21                          // 000000DF6F68: 382A2AFF 64006400
	.long 0xcc0f4047                                           // 000000DF6F70: CC0F4047
	v_mul_i32_i24_e32 v1, 0xe408, v67                          // 000000DF6F74: 120286FF 0000E408
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF6F7C: BF870193
	v_dot2acc_f32_f16 v91, v17, v70                            // 000000DF6F80: 04B68D11
	.long 0xcc0f4015                                           // 000000DF6F84: CC0F4015
	v_mul_i32_i24_e32 v1, 0xe408, v21                          // 000000DF6F88: 12022AFF 0000E408
	s_waitcnt lgkmcnt(1)                                       // 000000DF6F90: BF89FC17
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF6F94: BF870093
	v_dot2acc_f32_f16 v90, v71, v33                            // 000000DF6F98: 04B44347
	v_dual_dot2acc_f32_f16 v90, v21, v34 :: v_dual_and_b32 v9, 0xf0f0f0f, v9// 000000DF6F9C: CB244515 5A0812FF 0F0F0F0F
	v_perm_b32 v69, v29, v13, 0xc060c02                        // 000000DF6FA8: D6440045 03FE1B1D 0C060C02
	v_perm_b32 v13, v29, v13, 0xc070c03                        // 000000DF6FB4: D644000D 03FE1B1D 0C070C03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF6FC0: BF870193
	v_perm_b32 v29, v9, v66, 0xc040c00                         // 000000DF6FC4: D644001D 03FE8509 0C040C00
	v_or_b32_e32 v33, 0x64006400, v69                          // 000000DF6FD0: 38428AFF 64006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF6FD8: BF870193
	v_or_b32_e32 v13, 0x64006400, v13                          // 000000DF6FDC: 381A1AFF 64006400
	v_or_b32_e32 v29, 0x64006400, v29                          // 000000DF6FE4: 383A3AFF 64006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF6FEC: BF870112
	.long 0xcc0f400d                                           // 000000DF6FF0: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF6FF4: 12021AFF 0000E408
	.long 0xcc0f401d                                           // 000000DF6FFC: CC0F401D
	v_mul_i32_i24_e32 v1, 0xe408, v29                          // 000000DF7000: 12023AFF 0000E408
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DF7008: BF8700A1
	v_dot2acc_f32_f16 v89, v29, v37                            // 000000DF700C: 04B24B1D
	.long 0xcc0f401d                                           // 000000DF7010: CC0F401D
	v_mul_i32_i24_e32 v1, 0xe408, v33                          // 000000DF7014: 120242FF 0000E408
	v_dot2acc_f32_f16 v90, v29, v35                            // 000000DF701C: 04B4471D
	v_perm_b32 v17, v9, v66, 0xc050c01                         // 000000DF7020: D6440011 03FE8509 0C050C01
	v_perm_b32 v70, v9, v66, 0xc060c02                         // 000000DF702C: D6440046 03FE8509 0C060C02
	v_perm_b32 v9, v9, v66, 0xc070c03                          // 000000DF7038: D6440009 03FE8509 0C070C03
	s_waitcnt vmcnt(0)                                         // 000000DF7044: BF8903F7
	v_dual_dot2acc_f32_f16 v90, v13, v36 :: v_dual_and_b32 v29, 0xf0f0f0f, v1// 000000DF7048: CB24490D 5A1C02FF 0F0F0F0F
	v_or_b32_e32 v17, 0x64006400, v17                          // 000000DF7054: 382222FF 64006400
	v_or_b32_e32 v69, 0x64006400, v70                          // 000000DF705C: 388A8CFF 64006400
	v_or_b32_e32 v21, 0x64006400, v9                           // 000000DF7064: 382A12FF 64006400
	v_perm_b32 v13, v25, v5, 0xc050c01                         // 000000DF706C: D644000D 03FE0B19 0C050C01
	v_mov_b32_e32 v9, 0                                        // 000000DF7078: 7E120280
	.long 0xcc0f4011                                           // 000000DF707C: CC0F4011
	v_mul_i32_i24_e32 v1, 0xe408, v17                          // 000000DF7080: 120222FF 0000E408
	.long 0xcc0f4021                                           // 000000DF7088: CC0F4021
	v_mul_i32_i24_e32 v1, 0xe408, v69                          // 000000DF708C: 12028AFF 0000E408
	ds_load_b128 v[65:68], v88 offset:11536                    // 000000DF7094: DBFC2D10 41000058
	v_or_b32_e32 v13, 0x64006400, v13                          // 000000DF709C: 381A1AFF 64006400
	ds_load_b128 v[69:72], v88 offset:12048                    // 000000DF70A4: DBFC2F10 45000058
	v_dot2acc_f32_f16 v89, v17, v38                            // 000000DF70AC: 04B24D11
	.long 0xcc0f4011                                           // 000000DF70B0: CC0F4011
	v_mul_i32_i24_e32 v1, 0xe408, v21                          // 000000DF70B4: 12022AFF 0000E408
	v_perm_b32 v21, v25, v5, 0xc040c00                         // 000000DF70BC: D6440015 03FE0B19 0C040C00
	.long 0xcc0f400d                                           // 000000DF70C8: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF70CC: 12021AFF 0000E408
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DF70D4: BF870004
	v_dot2acc_f32_f16 v89, v33, v39                            // 000000DF70D8: 04B24F21
	ds_load_b128 v[33:36], v88 offset:12032                    // 000000DF70DC: DBFC2F00 21000058
	ds_load_b128 v[73:76], v88 offset:11792                    // 000000DF70E4: DBFC2E10 49000058
	v_dot2acc_f32_f16 v89, v17, v40                            // 000000DF70EC: 04B25111
	v_or_b32_e32 v17, 0x64006400, v21                          // 000000DF70F0: 38222AFF 64006400
	global_load_b128 v[37:40], v[83:84], off offset:512        // 000000DF70F8: DC5E0200 257C0053
	v_lshrrev_b32_e32 v21, 4, v1                               // 000000DF7100: 322A0284
	v_perm_b32 v1, v25, v5, 0xc060c02                          // 000000DF7104: D6440001 03FE0B19 0C060C02
	v_perm_b32 v5, v25, v5, 0xc070c03                          // 000000DF7110: D6440005 03FE0B19 0C070C03
	.long 0xcc0f4011                                           // 000000DF711C: CC0F4011
	v_mul_i32_i24_e32 v1, 0xe408, v17                          // 000000DF7120: 120222FF 0000E408
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DF7128: BF870214
	v_and_b32_e32 v21, 0xf0f0f0f, v21                          // 000000DF712C: 362A2AFF 0F0F0F0F
	v_or_b32_e32 v1, 0x64006400, v1                            // 000000DF7134: 380202FF 64006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DF713C: BF870214
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000DF7140: 380A0AFF 64006400
	v_dot2acc_f32_f16 v9, v17, v41                             // 000000DF7148: 04125311
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DF714C: BF870214
	v_perm_b32 v17, v21, v29, 0xc040c00                        // 000000DF7150: D6440011 03FE3B15 0C040C00
	.long 0xcc0f4001                                           // 000000DF715C: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DF7160: 120202FF 0000E408
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DF7168: BF870214
	.long 0xcc0f4005                                           // 000000DF716C: CC0F4005
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DF7170: 12020AFF 0000E408
	v_dot2acc_f32_f16 v9, v13, v42                             // 000000DF7178: 0412550D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DF717C: BF8701A4
	v_or_b32_e32 v13, 0x64006400, v17                          // 000000DF7180: 381A22FF 64006400
	v_perm_b32 v17, v21, v29, 0xc060c02                        // 000000DF7188: D6440011 03FE3B15 0C060C02
	v_dot2acc_f32_f16 v9, v1, v43                              // 000000DF7194: 04125701
	v_mov_b32_e32 v1, 0                                        // 000000DF7198: 7E020280
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF719C: BF870194
	.long 0xcc0f400d                                           // 000000DF71A0: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF71A4: 12021AFF 0000E408
	v_dot2acc_f32_f16 v9, v5, v44                              // 000000DF71AC: 04125905
	v_perm_b32 v5, v21, v29, 0xc050c01                         // 000000DF71B0: D6440005 03FE3B15 0C050C01
	v_perm_b32 v21, v21, v29, 0xc070c03                        // 000000DF71BC: D6440015 03FE3B15 0C070C03
	s_waitcnt lgkmcnt(1)                                       // 000000DF71C8: BF89FC17
	v_dot2acc_f32_f16 v1, v13, v33                             // 000000DF71CC: 0402430D
	v_or_b32_e32 v13, 0x64006400, v17                          // 000000DF71D0: 381A22FF 64006400
	ds_load_b128 v[41:44], v88 offset:12288                    // 000000DF71D8: DBFC3000 29000058
	ds_load_b128 v[77:80], v88 offset:12304                    // 000000DF71E0: DBFC3010 4D000058
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000DF71E8: 380A0AFF 64006400
	v_or_b32_e32 v17, 0x64006400, v21                          // 000000DF71F0: 38222AFF 64006400
	.long 0xcc0f400d                                           // 000000DF71F8: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF71FC: 12021AFF 0000E408
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF7204: BF870093
	.long 0xcc0f4005                                           // 000000DF7208: CC0F4005
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DF720C: 12020AFF 0000E408
	v_dot2acc_f32_f16 v1, v5, v34                              // 000000DF7214: 04024505
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF7218: BF870114
	.long 0xcc0f4005                                           // 000000DF721C: CC0F4005
	v_mul_i32_i24_e32 v1, 0xe408, v17                          // 000000DF7220: 120222FF 0000E408
	v_dot2acc_f32_f16 v1, v13, v35                             // 000000DF7228: 0402470D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000DF722C: BF870151
	v_dot2acc_f32_f16 v1, v5, v36                              // 000000DF7230: 04024905
	global_load_b128 v[33:36], v[83:84], off offset:576        // 000000DF7234: DC5E0240 217C0053
	s_waitcnt vmcnt(1)                                         // 000000DF723C: BF8907F7
	v_lshrrev_b32_e32 v5, 4, v37                               // 000000DF7240: 320A4A84
	v_and_b32_e32 v13, 0xf0f0f0f, v37                          // 000000DF7244: 361A4AFF 0F0F0F0F
	v_and_b32_e32 v5, 0xf0f0f0f, v5                            // 000000DF724C: 360A0AFF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000DF7254: BF870241
	v_perm_b32 v17, v5, v13, 0xc040c00                         // 000000DF7258: D6440011 03FE1B05 0C040C00
	v_perm_b32 v21, v5, v13, 0xc050c01                         // 000000DF7264: D6440015 03FE1B05 0C050C01
	v_perm_b32 v25, v5, v13, 0xc060c02                         // 000000DF7270: D6440019 03FE1B05 0C060C02
	v_perm_b32 v5, v5, v13, 0xc070c03                          // 000000DF727C: D6440005 03FE1B05 0C070C03
	v_or_b32_e32 v13, 0x64006400, v17                          // 000000DF7288: 381A22FF 64006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF7290: BF870112
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000DF7294: 380A0AFF 64006400
	.long 0xcc0f400d                                           // 000000DF729C: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF72A0: 12021AFF 0000E408
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DF72A8: BF870122
	.long 0xcc0f4005                                           // 000000DF72AC: CC0F4005
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DF72B0: 12020AFF 0000E408
	s_waitcnt lgkmcnt(1)                                       // 000000DF72B8: BF89FC17
	v_dot2acc_f32_f16 v95, v13, v41                            // 000000DF72BC: 04BE530D
	v_or_b32_e32 v13, 0x64006400, v21                          // 000000DF72C0: 381A2AFF 64006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF72C8: BF870091
	.long 0xcc0f400d                                           // 000000DF72CC: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF72D0: 12021AFF 0000E408
	v_dot2acc_f32_f16 v95, v13, v42                            // 000000DF72D8: 04BE550D
	v_or_b32_e32 v13, 0x64006400, v25                          // 000000DF72DC: 381A32FF 64006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF72E4: BF870091
	.long 0xcc0f400d                                           // 000000DF72E8: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF72EC: 12021AFF 0000E408
	v_dot2acc_f32_f16 v95, v13, v43                            // 000000DF72F4: 04BE570D
	s_waitcnt vmcnt(0)                                         // 000000DF72F8: BF8903F7
	v_and_b32_e32 v13, 0xf0f0f0f, v33                          // 000000DF72FC: 361A42FF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_2)                            // 000000DF7304: BF870002
	v_dot2acc_f32_f16 v95, v5, v44                             // 000000DF7308: 04BE5905
	v_lshrrev_b32_e32 v5, 4, v33                               // 000000DF730C: 320A4284
	ds_load_b128 v[96:99], v88 offset:12544                    // 000000DF7310: DBFC3100 60000058
	ds_load_b128 v[41:44], v88 offset:12560                    // 000000DF7318: DBFC3110 29000058
	v_mov_b32_e32 v33, 0                                       // 000000DF7320: 7E420280
	v_and_b32_e32 v5, 0xf0f0f0f, v5                            // 000000DF7324: 360A0AFF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000DF732C: BF870241
	v_perm_b32 v17, v5, v13, 0xc040c00                         // 000000DF7330: D6440011 03FE1B05 0C040C00
	v_perm_b32 v21, v5, v13, 0xc050c01                         // 000000DF733C: D6440015 03FE1B05 0C050C01
	v_perm_b32 v25, v5, v13, 0xc060c02                         // 000000DF7348: D6440019 03FE1B05 0C060C02
	v_perm_b32 v5, v5, v13, 0xc070c03                          // 000000DF7354: D6440005 03FE1B05 0C070C03
	v_or_b32_e32 v13, 0x64006400, v17                          // 000000DF7360: 381A22FF 64006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF7368: BF870112
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000DF736C: 380A0AFF 64006400
	.long 0xcc0f400d                                           // 000000DF7374: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF7378: 12021AFF 0000E408
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DF7380: BF870122
	.long 0xcc0f4005                                           // 000000DF7384: CC0F4005
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DF7388: 12020AFF 0000E408
	s_waitcnt lgkmcnt(1)                                       // 000000DF7390: BF89FC17
	v_dot2acc_f32_f16 v33, v13, v96                            // 000000DF7394: 0442C10D
	v_or_b32_e32 v13, 0x64006400, v21                          // 000000DF7398: 381A2AFF 64006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF73A0: BF870091
	.long 0xcc0f400d                                           // 000000DF73A4: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF73A8: 12021AFF 0000E408
	v_dot2acc_f32_f16 v33, v13, v97                            // 000000DF73B0: 0442C30D
	v_or_b32_e32 v13, 0x64006400, v25                          // 000000DF73B4: 381A32FF 64006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF73BC: BF870091
	.long 0xcc0f400d                                           // 000000DF73C0: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF73C4: 12021AFF 0000E408
	v_dot2acc_f32_f16 v33, v13, v98                            // 000000DF73CC: 0442C50D
	v_and_b32_e32 v13, 0xf0f0f0f, v30                          // 000000DF73D0: 361A3CFF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000DF73D8: BF8700C2
	v_dot2acc_f32_f16 v33, v5, v99                             // 000000DF73DC: 0442C705
	v_lshrrev_b32_e32 v5, 4, v30                               // 000000DF73E0: 320A3C84
	ds_load_b128 v[96:99], v88 offset:11824                    // 000000DF73E4: DBFC2E30 60000058
	v_and_b32_e32 v5, 0xf0f0f0f, v5                            // 000000DF73EC: 360A0AFF 0F0F0F0F
	v_perm_b32 v17, v5, v13, 0xc040c00                         // 000000DF73F4: D6440011 03FE1B05 0C040C00
	v_perm_b32 v21, v5, v13, 0xc050c01                         // 000000DF7400: D6440015 03FE1B05 0C050C01
	v_perm_b32 v25, v5, v13, 0xc060c02                         // 000000DF740C: D6440019 03FE1B05 0C060C02
	v_perm_b32 v5, v5, v13, 0xc070c03                          // 000000DF7418: D6440005 03FE1B05 0C070C03
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF7424: BF870114
	v_or_b32_e32 v13, 0x64006400, v17                          // 000000DF7428: 381A22FF 64006400
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000DF7430: 380A0AFF 64006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF7438: BF870112
	.long 0xcc0f400d                                           // 000000DF743C: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF7440: 12021AFF 0000E408
	.long 0xcc0f4005                                           // 000000DF7448: CC0F4005
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DF744C: 12020AFF 0000E408
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DF7454: BF8700A2
	v_dot2acc_f32_f16 v94, v13, v45                            // 000000DF7458: 04BC5B0D
	v_or_b32_e32 v13, 0x64006400, v21                          // 000000DF745C: 381A2AFF 64006400
	.long 0xcc0f400d                                           // 000000DF7464: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF7468: 12021AFF 0000E408
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DF7470: BF8700A1
	v_dot2acc_f32_f16 v94, v13, v46                            // 000000DF7474: 04BC5D0D
	v_or_b32_e32 v13, 0x64006400, v25                          // 000000DF7478: 381A32FF 64006400
	.long 0xcc0f400d                                           // 000000DF7480: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF7484: 12021AFF 0000E408
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF748C: BF870091
	v_dual_dot2acc_f32_f16 v94, v13, v47 :: v_dual_and_b32 v13, 0xf0f0f0f, v26// 000000DF7490: CB245F0D 5E0C34FF 0F0F0F0F
	v_dot2acc_f32_f16 v94, v5, v48                             // 000000DF749C: 04BC6105
	v_lshrrev_b32_e32 v5, 4, v26                               // 000000DF74A0: 320A3484
	ds_load_b128 v[45:48], v88 offset:10272                    // 000000DF74A4: DBFC2820 2D000058
	v_and_b32_e32 v5, 0xf0f0f0f, v5                            // 000000DF74AC: 360A0AFF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000DF74B4: BF870241
	v_perm_b32 v17, v5, v13, 0xc040c00                         // 000000DF74B8: D6440011 03FE1B05 0C040C00
	v_perm_b32 v21, v5, v13, 0xc050c01                         // 000000DF74C4: D6440015 03FE1B05 0C050C01
	v_perm_b32 v25, v5, v13, 0xc060c02                         // 000000DF74D0: D6440019 03FE1B05 0C060C02
	v_perm_b32 v5, v5, v13, 0xc070c03                          // 000000DF74DC: D6440005 03FE1B05 0C070C03
	v_or_b32_e32 v13, 0x64006400, v17                          // 000000DF74E8: 381A22FF 64006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF74F0: BF870112
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000DF74F4: 380A0AFF 64006400
	.long 0xcc0f400d                                           // 000000DF74FC: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF7500: 12021AFF 0000E408
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF7508: BF870112
	.long 0xcc0f4005                                           // 000000DF750C: CC0F4005
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DF7510: 12020AFF 0000E408
	v_dot2acc_f32_f16 v93, v13, v49                            // 000000DF7518: 04BA630D
	v_or_b32_e32 v13, 0x64006400, v21                          // 000000DF751C: 381A2AFF 64006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF7524: BF870091
	.long 0xcc0f400d                                           // 000000DF7528: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF752C: 12021AFF 0000E408
	v_dot2acc_f32_f16 v93, v13, v50                            // 000000DF7534: 04BA650D
	v_or_b32_e32 v13, 0x64006400, v25                          // 000000DF7538: 381A32FF 64006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF7540: BF870091
	.long 0xcc0f400d                                           // 000000DF7544: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF7548: 12021AFF 0000E408
	v_dot2acc_f32_f16 v93, v13, v51                            // 000000DF7550: 04BA670D
	v_and_b32_e32 v13, 0xf0f0f0f, v22                          // 000000DF7554: 361A2CFF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000DF755C: BF8700C2
	v_dot2acc_f32_f16 v93, v5, v52                             // 000000DF7560: 04BA6905
	v_lshrrev_b32_e32 v5, 4, v22                               // 000000DF7564: 320A2C84
	ds_load_b128 v[49:52], v88 offset:10784                    // 000000DF7568: DBFC2A20 31000058
	v_and_b32_e32 v5, 0xf0f0f0f, v5                            // 000000DF7570: 360A0AFF 0F0F0F0F
	v_perm_b32 v17, v5, v13, 0xc040c00                         // 000000DF7578: D6440011 03FE1B05 0C040C00
	v_perm_b32 v21, v5, v13, 0xc050c01                         // 000000DF7584: D6440015 03FE1B05 0C050C01
	v_perm_b32 v22, v5, v13, 0xc060c02                         // 000000DF7590: D6440016 03FE1B05 0C060C02
	v_perm_b32 v5, v5, v13, 0xc070c03                          // 000000DF759C: D6440005 03FE1B05 0C070C03
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF75A8: BF870114
	v_or_b32_e32 v13, 0x64006400, v17                          // 000000DF75AC: 381A22FF 64006400
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000DF75B4: 380A0AFF 64006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF75BC: BF870112
	.long 0xcc0f400d                                           // 000000DF75C0: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF75C4: 12021AFF 0000E408
	.long 0xcc0f4005                                           // 000000DF75CC: CC0F4005
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DF75D0: 12020AFF 0000E408
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DF75D8: BF8700A2
	v_dot2acc_f32_f16 v92, v13, v53                            // 000000DF75DC: 04B86B0D
	v_or_b32_e32 v13, 0x64006400, v21                          // 000000DF75E0: 381A2AFF 64006400
	.long 0xcc0f400d                                           // 000000DF75E8: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF75EC: 12021AFF 0000E408
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DF75F4: BF8700A1
	v_dot2acc_f32_f16 v92, v13, v54                            // 000000DF75F8: 04B86D0D
	v_or_b32_e32 v13, 0x64006400, v22                          // 000000DF75FC: 381A2CFF 64006400
	.long 0xcc0f400d                                           // 000000DF7604: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF7608: 12021AFF 0000E408
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF7610: BF870091
	v_dual_dot2acc_f32_f16 v92, v13, v55 :: v_dual_and_b32 v13, 0xf0f0f0f, v18// 000000DF7614: CB246F0D 5C0C24FF 0F0F0F0F
	v_dot2acc_f32_f16 v92, v5, v56                             // 000000DF7620: 04B87105
	v_lshrrev_b32_e32 v5, 4, v18                               // 000000DF7624: 320A2484
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF7628: BF870091
	v_and_b32_e32 v5, 0xf0f0f0f, v5                            // 000000DF762C: 360A0AFF 0F0F0F0F
	v_perm_b32 v17, v5, v13, 0xc040c00                         // 000000DF7634: D6440011 03FE1B05 0C040C00
	v_perm_b32 v18, v5, v13, 0xc050c01                         // 000000DF7640: D6440012 03FE1B05 0C050C01
	v_perm_b32 v21, v5, v13, 0xc060c02                         // 000000DF764C: D6440015 03FE1B05 0C060C02
	v_perm_b32 v5, v5, v13, 0xc070c03                          // 000000DF7658: D6440005 03FE1B05 0C070C03
	v_lshrrev_b32_e32 v13, 4, v14                              // 000000DF7664: 321A1C84
	v_and_b32_e32 v14, 0xf0f0f0f, v14                          // 000000DF7668: 361C1CFF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF7670: BF870193
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000DF7674: 380A0AFF 64006400
	v_and_b32_e32 v13, 0xf0f0f0f, v13                          // 000000DF767C: 361A1AFF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF7684: BF870112
	.long 0xcc0f4005                                           // 000000DF7688: CC0F4005
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DF768C: 12020AFF 0000E408
	v_perm_b32 v22, v13, v14, 0xc040c00                        // 000000DF7694: D6440016 03FE1D0D 0C040C00
	v_perm_b32 v25, v13, v14, 0xc050c01                        // 000000DF76A0: D6440019 03FE1D0D 0C050C01
	v_perm_b32 v26, v13, v14, 0xc060c02                        // 000000DF76AC: D644001A 03FE1D0D 0C060C02
	v_perm_b32 v13, v13, v14, 0xc070c03                        // 000000DF76B8: D644000D 03FE1D0D 0C070C03
	v_or_b32_e32 v14, 0x64006400, v17                          // 000000DF76C4: 381C22FF 64006400
	v_or_b32_e32 v17, 0x64006400, v21                          // 000000DF76CC: 38222AFF 64006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF76D4: BF870193
	v_or_b32_e32 v13, 0x64006400, v13                          // 000000DF76D8: 381A1AFF 64006400
	.long 0xcc0f400e                                           // 000000DF76E0: CC0F400E
	v_mul_i32_i24_e32 v1, 0xe408, v14                          // 000000DF76E4: 12021CFF 0000E408
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF76EC: BF870193
	.long 0xcc0f4011                                           // 000000DF76F0: CC0F4011
	v_mul_i32_i24_e32 v1, 0xe408, v17                          // 000000DF76F4: 120222FF 0000E408
	.long 0xcc0f400d                                           // 000000DF76FC: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF7700: 12021AFF 0000E408
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000DF7708: BF8700C3
	v_dot2acc_f32_f16 v91, v14, v57                            // 000000DF770C: 04B6730E
	v_or_b32_e32 v14, 0x64006400, v22                          // 000000DF7710: 381C2CFF 64006400
	ds_load_b128 v[54:57], v88 offset:10288                    // 000000DF7718: DBFC2830 36000058
	.long 0xcc0f400e                                           // 000000DF7720: CC0F400E
	v_mul_i32_i24_e32 v1, 0xe408, v14                          // 000000DF7724: 12021CFF 0000E408
	v_dot2acc_f32_f16 v90, v14, v61                            // 000000DF772C: 04B47B0E
	v_or_b32_e32 v14, 0x64006400, v18                          // 000000DF7730: 381C24FF 64006400
	v_or_b32_e32 v18, 0x64006400, v26                          // 000000DF7738: 382434FF 64006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF7740: BF870112
	.long 0xcc0f400e                                           // 000000DF7744: CC0F400E
	v_mul_i32_i24_e32 v1, 0xe408, v14                          // 000000DF7748: 12021CFF 0000E408
	.long 0xcc0f4012                                           // 000000DF7750: CC0F4012
	v_mul_i32_i24_e32 v1, 0xe408, v18                          // 000000DF7754: 120224FF 0000E408
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DF775C: BF870122
	v_dot2acc_f32_f16 v91, v14, v58                            // 000000DF7760: 04B6750E
	v_or_b32_e32 v14, 0x64006400, v25                          // 000000DF7764: 381C32FF 64006400
	v_dot2acc_f32_f16 v91, v17, v59                            // 000000DF776C: 04B67711
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DF7770: BF870122
	.long 0xcc0f400e                                           // 000000DF7774: CC0F400E
	v_mul_i32_i24_e32 v1, 0xe408, v14                          // 000000DF7778: 12021CFF 0000E408
	v_lshrrev_b32_e32 v17, 4, v6                               // 000000DF7780: 32220C84
	v_dual_dot2acc_f32_f16 v91, v5, v60 :: v_dual_dot2acc_f32_f16 v90, v14, v62// 000000DF7784: CB187905 5B5A7D0E
	v_lshrrev_b32_e32 v14, 4, v10                              // 000000DF778C: 321C1484
	v_and_b32_e32 v10, 0xf0f0f0f, v10                          // 000000DF7790: 361414FF 0F0F0F0F
	v_and_b32_e32 v5, 0xf0f0f0f, v6                            // 000000DF7798: 360A0CFF 0F0F0F0F
	v_and_b32_e32 v6, 0xf0f0f0f, v17                           // 000000DF77A0: 360C22FF 0F0F0F0F
	v_dot2acc_f32_f16 v90, v18, v63                            // 000000DF77A8: 04B47F12
	v_and_b32_e32 v14, 0xf0f0f0f, v14                          // 000000DF77AC: 361C1CFF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF77B4: BF870193
	v_perm_b32 v21, v6, v5, 0xc050c01                          // 000000DF77B8: D6440015 03FE0B06 0C050C01
	v_dot2acc_f32_f16 v90, v13, v64                            // 000000DF77C4: 04B4810D
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DF77C8: BF870003
	v_perm_b32 v13, v14, v10, 0xc040c00                        // 000000DF77CC: D644000D 03FE150E 0C040C00
	v_perm_b32 v17, v14, v10, 0xc050c01                        // 000000DF77D8: D6440011 03FE150E 0C050C01
	v_perm_b32 v18, v14, v10, 0xc060c02                        // 000000DF77E4: D6440012 03FE150E 0C060C02
	v_perm_b32 v10, v14, v10, 0xc070c03                        // 000000DF77F0: D644000A 03FE150E 0C070C03
	v_perm_b32 v14, v6, v5, 0xc040c00                          // 000000DF77FC: D644000E 03FE0B06 0C040C00
	v_or_b32_e32 v13, 0x64006400, v13                          // 000000DF7808: 381A1AFF 64006400
	v_perm_b32 v22, v6, v5, 0xc060c02                          // 000000DF7810: D6440016 03FE0B06 0C060C02
	v_perm_b32 v5, v6, v5, 0xc070c03                           // 000000DF781C: D6440005 03FE0B06 0C070C03
	v_or_b32_e32 v17, 0x64006400, v17                          // 000000DF7828: 382222FF 64006400
	v_or_b32_e32 v6, 0x64006400, v14                           // 000000DF7830: 380C1CFF 64006400
	.long 0xcc0f400d                                           // 000000DF7838: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF783C: 12021AFF 0000E408
	v_and_b32_e32 v14, 0xf0f0f0f, v2                           // 000000DF7844: 361C04FF 0F0F0F0F
	v_or_b32_e32 v21, 0x64006400, v21                          // 000000DF784C: 382A2AFF 64006400
	v_lshrrev_b32_e32 v2, 4, v2                                // 000000DF7854: 32040484
	.long 0xcc0f4006                                           // 000000DF7858: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DF785C: 12020CFF 0000E408
	.long 0xcc0f4011                                           // 000000DF7864: CC0F4011
	v_mul_i32_i24_e32 v1, 0xe408, v17                          // 000000DF7868: 120222FF 0000E408
	v_or_b32_e32 v10, 0x64006400, v10                          // 000000DF7870: 381414FF 64006400
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000DF7878: 380A0AFF 64006400
	v_dual_dot2acc_f32_f16 v89, v13, v65 :: v_dual_and_b32 v2, 0xf0f0f0f, v2// 000000DF7880: CB24830D 590204FF 0F0F0F0F
	v_or_b32_e32 v13, 0x64006400, v18                          // 000000DF788C: 381A24FF 64006400
	.long 0xcc0f4012                                           // 000000DF7894: CC0F4012
	v_mul_i32_i24_e32 v1, 0xe408, v21                          // 000000DF7898: 12022AFF 0000E408
	v_dot2acc_f32_f16 v9, v6, v73                              // 000000DF78A0: 04129306
	v_or_b32_e32 v21, 0x64006400, v22                          // 000000DF78A4: 382A2CFF 64006400
	v_dot2acc_f32_f16 v89, v17, v66                            // 000000DF78AC: 04B28511
	.long 0xcc0f400d                                           // 000000DF78B0: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF78B4: 12021AFF 0000E408
	.long 0xcc0f400a                                           // 000000DF78BC: CC0F400A
	v_mul_i32_i24_e32 v1, 0xe408, v10                          // 000000DF78C0: 120214FF 0000E408
	v_dot2acc_f32_f16 v9, v18, v74                             // 000000DF78C8: 04129512
	.long 0xcc0f4015                                           // 000000DF78CC: CC0F4015
	v_mul_i32_i24_e32 v1, 0xe408, v21                          // 000000DF78D0: 12022AFF 0000E408
	v_lshrrev_b32_e32 v18, 4, v38                              // 000000DF78D8: 32244C84
	v_dot2acc_f32_f16 v89, v13, v67                            // 000000DF78DC: 04B2870D
	v_lshrrev_b32_e32 v6, 4, v31                               // 000000DF78E0: 320C3E84
	v_and_b32_e32 v17, 0xf0f0f0f, v38                          // 000000DF78E4: 36224CFF 0F0F0F0F
	v_dot2acc_f32_f16 v9, v21, v75                             // 000000DF78EC: 04129715
	v_perm_b32 v21, v2, v14, 0xc040c00                         // 000000DF78F0: D6440015 03FE1D02 0C040C00
	v_and_b32_e32 v18, 0xf0f0f0f, v18                          // 000000DF78FC: 362424FF 0F0F0F0F
	.long 0xcc0f4005                                           // 000000DF7904: CC0F4005
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DF7908: 12020AFF 0000E408
	v_dot2acc_f32_f16 v89, v10, v68                            // 000000DF7910: 04B2890A
	v_perm_b32 v10, v2, v14, 0xc050c01                         // 000000DF7914: D644000A 03FE1D02 0C050C01
	v_or_b32_e32 v21, 0x64006400, v21                          // 000000DF7920: 382A2AFF 64006400
	v_and_b32_e32 v13, 0xf0f0f0f, v31                          // 000000DF7928: 361A3EFF 0F0F0F0F
	v_and_b32_e32 v6, 0xf0f0f0f, v6                            // 000000DF7930: 360C0CFF 0F0F0F0F
	v_perm_b32 v22, v2, v14, 0xc060c02                         // 000000DF7938: D6440016 03FE1D02 0C060C02
	v_dot2acc_f32_f16 v9, v5, v76                              // 000000DF7944: 04129905
	v_perm_b32 v5, v18, v17, 0xc040c00                         // 000000DF7948: D6440005 03FE2312 0C040C00
	v_or_b32_e32 v10, 0x64006400, v10                          // 000000DF7954: 381414FF 64006400
	.long 0xcc0f4015                                           // 000000DF795C: CC0F4015
	v_mul_i32_i24_e32 v1, 0xe408, v21                          // 000000DF7960: 12022AFF 0000E408
	v_perm_b32 v2, v2, v14, 0xc070c03                          // 000000DF7968: D6440002 03FE1D02 0C070C03
	v_perm_b32 v14, v6, v13, 0xc040c00                         // 000000DF7974: D644000E 03FE1B06 0C040C00
	v_perm_b32 v25, v6, v13, 0xc050c01                         // 000000DF7980: D6440019 03FE1B06 0C050C01
	v_perm_b32 v26, v18, v17, 0xc050c01                        // 000000DF798C: D644001A 03FE2312 0C050C01
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000DF7998: 380A0AFF 64006400
	v_perm_b32 v29, v6, v13, 0xc060c02                         // 000000DF79A0: D644001D 03FE1B06 0C060C02
	v_perm_b32 v6, v6, v13, 0xc070c03                          // 000000DF79AC: D6440006 03FE1B06 0C070C03
	.long 0xcc0f400a                                           // 000000DF79B8: CC0F400A
	v_mul_i32_i24_e32 v1, 0xe408, v10                          // 000000DF79BC: 120214FF 0000E408
	v_dot2acc_f32_f16 v1, v21, v69                             // 000000DF79C4: 04028B15
	v_perm_b32 v13, v18, v17, 0xc060c02                        // 000000DF79C8: D644000D 03FE2312 0C060C02
	v_perm_b32 v17, v18, v17, 0xc070c03                        // 000000DF79D4: D6440011 03FE2312 0C070C03
	v_or_b32_e32 v18, 0x64006400, v22                          // 000000DF79E0: 38242CFF 64006400
	.long 0xcc0f4005                                           // 000000DF79E8: CC0F4005
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DF79EC: 12020AFF 0000E408
	v_dot2acc_f32_f16 v1, v10, v70                             // 000000DF79F4: 04028D0A
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DF79F8: 380404FF 64006400
	v_or_b32_e32 v14, 0x64006400, v14                          // 000000DF7A00: 381C1CFF 64006400
	.long 0xcc0f400a                                           // 000000DF7A08: CC0F400A
	v_mul_i32_i24_e32 v1, 0xe408, v18                          // 000000DF7A0C: 120224FF 0000E408
	v_dot2acc_f32_f16 v95, v5, v77                             // 000000DF7A14: 04BE9B05
	v_or_b32_e32 v5, 0x64006400, v26                           // 000000DF7A18: 380A34FF 64006400
	v_or_b32_e32 v18, 0x64006400, v25                          // 000000DF7A20: 382432FF 64006400
	.long 0xcc0f4002                                           // 000000DF7A28: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DF7A2C: 120204FF 0000E408
	v_dot2acc_f32_f16 v1, v10, v71                             // 000000DF7A34: 04028F0A
	.long 0xcc0f400a                                           // 000000DF7A38: CC0F400A
	v_mul_i32_i24_e32 v1, 0xe408, v14                          // 000000DF7A3C: 12021CFF 0000E408
	.long 0xcc0f4005                                           // 000000DF7A44: CC0F4005
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DF7A48: 12020AFF 0000E408
	v_or_b32_e32 v13, 0x64006400, v13                          // 000000DF7A50: 381A1AFF 64006400
	.long 0xcc0f400e                                           // 000000DF7A58: CC0F400E
	v_mul_i32_i24_e32 v1, 0xe408, v18                          // 000000DF7A5C: 120224FF 0000E408
	v_dot2acc_f32_f16 v1, v2, v72                              // 000000DF7A64: 04029102
	s_waitcnt lgkmcnt(2)                                       // 000000DF7A68: BF89FC27
	v_dot2acc_f32_f16 v94, v10, v45                            // 000000DF7A6C: 04BC5B0A
	v_or_b32_e32 v2, 0x64006400, v29                           // 000000DF7A70: 38043AFF 64006400
	v_dot2acc_f32_f16 v95, v5, v78                             // 000000DF7A78: 04BE9D05
	.long 0xcc0f4005                                           // 000000DF7A7C: CC0F4005
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF7A80: 12021AFF 0000E408
	v_or_b32_e32 v13, 0x64006400, v17                          // 000000DF7A88: 381A22FF 64006400
	v_dot2acc_f32_f16 v94, v14, v46                            // 000000DF7A90: 04BC5D0E
	.long 0xcc0f4002                                           // 000000DF7A94: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DF7A98: 120204FF 0000E408
	v_and_b32_e32 v10, 0xf0f0f0f, v27                          // 000000DF7AA0: 361436FF 0F0F0F0F
	v_dot2acc_f32_f16 v95, v5, v79                             // 000000DF7AA8: 04BE9F05
	v_lshrrev_b32_e32 v5, 4, v27                               // 000000DF7AAC: 320A3684
	.long 0xcc0f400d                                           // 000000DF7AB0: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF7AB4: 12021AFF 0000E408
	v_dot2acc_f32_f16 v94, v2, v47                             // 000000DF7ABC: 04BC5F02
	v_lshrrev_b32_e32 v2, 4, v23                               // 000000DF7AC0: 32042E84
	v_or_b32_e32 v6, 0x64006400, v6                            // 000000DF7AC4: 380C0CFF 64006400
	v_and_b32_e32 v5, 0xf0f0f0f, v5                            // 000000DF7ACC: 360A0AFF 0F0F0F0F
	v_dot2acc_f32_f16 v95, v13, v80                            // 000000DF7AD4: 04BEA10D
	v_and_b32_e32 v13, 0xf0f0f0f, v23                          // 000000DF7AD8: 361A2EFF 0F0F0F0F
	v_and_b32_e32 v2, 0xf0f0f0f, v2                            // 000000DF7AE0: 360404FF 0F0F0F0F
	ds_load_b128 v[58:61], v88 offset:10528                    // 000000DF7AE8: DBFC2920 3A000058
	ds_load_b128 v[62:65], v88 offset:10544                    // 000000DF7AF0: DBFC2930 3E000058
	.long 0xcc0f4006                                           // 000000DF7AF8: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DF7AFC: 12020CFF 0000E408
	v_perm_b32 v14, v5, v10, 0xc040c00                         // 000000DF7B04: D644000E 03FE1505 0C040C00
	v_perm_b32 v17, v5, v10, 0xc060c02                         // 000000DF7B10: D6440011 03FE1505 0C060C02
	v_perm_b32 v18, v2, v13, 0xc040c00                         // 000000DF7B1C: D6440012 03FE1B02 0C040C00
	ds_load_b128 v[66:69], v88 offset:10800                    // 000000DF7B28: DBFC2A30 42000058
	v_dot2acc_f32_f16 v94, v6, v48                             // 000000DF7B30: 04BC6106
	v_perm_b32 v6, v5, v10, 0xc050c01                          // 000000DF7B34: D6440006 03FE1505 0C050C01
	v_or_b32_e32 v14, 0x64006400, v14                          // 000000DF7B40: 381C1CFF 64006400
	v_perm_b32 v5, v5, v10, 0xc070c03                          // 000000DF7B48: D6440005 03FE1505 0C070C03
	v_perm_b32 v10, v2, v13, 0xc050c01                         // 000000DF7B54: D644000A 03FE1B02 0C050C01
	v_or_b32_e32 v18, 0x64006400, v18                          // 000000DF7B60: 382424FF 64006400
	v_or_b32_e32 v6, 0x64006400, v6                            // 000000DF7B68: 380C0CFF 64006400
	.long 0xcc0f400e                                           // 000000DF7B70: CC0F400E
	v_mul_i32_i24_e32 v1, 0xe408, v14                          // 000000DF7B74: 12021CFF 0000E408
	v_perm_b32 v21, v2, v13, 0xc060c02                         // 000000DF7B7C: D6440015 03FE1B02 0C060C02
	v_or_b32_e32 v10, 0x64006400, v10                          // 000000DF7B88: 381414FF 64006400
	.long 0xcc0f4012                                           // 000000DF7B90: CC0F4012
	v_mul_i32_i24_e32 v1, 0xe408, v18                          // 000000DF7B94: 120224FF 0000E408
	.long 0xcc0f4006                                           // 000000DF7B9C: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DF7BA0: 12020CFF 0000E408
	v_perm_b32 v2, v2, v13, 0xc070c03                          // 000000DF7BA8: D6440002 03FE1B02 0C070C03
	s_waitcnt lgkmcnt(2)                                       // 000000DF7BB4: BF89FC27
	v_dot2acc_f32_f16 v93, v14, v58                            // 000000DF7BB8: 04BA750E
	v_or_b32_e32 v13, 0x64006400, v17                          // 000000DF7BBC: 381A22FF 64006400
	.long 0xcc0f400a                                           // 000000DF7BC4: CC0F400A
	v_mul_i32_i24_e32 v1, 0xe408, v10                          // 000000DF7BC8: 120214FF 0000E408
	v_dot2acc_f32_f16 v92, v18, v49                            // 000000DF7BD0: 04B86312
	ds_load_b128 v[45:48], v88 offset:11040                    // 000000DF7BD4: DBFC2B20 2D000058
	ds_load_b128 v[70:73], v88 offset:11056                    // 000000DF7BDC: DBFC2B30 46000058
	v_dot2acc_f32_f16 v93, v6, v59                             // 000000DF7BE4: 04BA7706
	.long 0xcc0f4006                                           // 000000DF7BE8: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF7BEC: 12021AFF 0000E408
	v_or_b32_e32 v13, 0x64006400, v21                          // 000000DF7BF4: 381A2AFF 64006400
	v_dot2acc_f32_f16 v92, v10, v50                            // 000000DF7BFC: 04B8650A
	v_lshrrev_b32_e32 v10, 4, v19                              // 000000DF7C00: 32142684
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000DF7C04: 380A0AFF 64006400
	v_dual_dot2acc_f32_f16 v93, v6, v60 :: v_dual_and_b32 v6, 0xf0f0f0f, v19// 000000DF7C0C: CB247906 5D0626FF 0F0F0F0F
	.long 0xcc0f400d                                           // 000000DF7C18: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF7C1C: 12021AFF 0000E408
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DF7C24: BF870004
	v_and_b32_e32 v10, 0xf0f0f0f, v10                          // 000000DF7C28: 361414FF 0F0F0F0F
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DF7C30: 380404FF 64006400
	.long 0xcc0f4005                                           // 000000DF7C38: CC0F4005
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DF7C3C: 12020AFF 0000E408
	ds_load_b128 v[74:77], v88 offset:11312                    // 000000DF7C44: DBFC2C30 4A000058
	v_dot2acc_f32_f16 v92, v13, v51                            // 000000DF7C4C: 04B8670D
	v_perm_b32 v13, v10, v6, 0xc040c00                         // 000000DF7C50: D644000D 03FE0D0A 0C040C00
	.long 0xcc0f4002                                           // 000000DF7C5C: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DF7C60: 120204FF 0000E408
	v_dot2acc_f32_f16 v93, v5, v61                             // 000000DF7C68: 04BA7B05
	v_perm_b32 v5, v10, v6, 0xc050c01                          // 000000DF7C6C: D6440005 03FE0D0A 0C050C01
	ds_load_b128 v[58:61], v88 offset:11296                    // 000000DF7C78: DBFC2C20 3A000058
	v_or_b32_e32 v13, 0x64006400, v13                          // 000000DF7C80: 381A1AFF 64006400
	v_dot2acc_f32_f16 v92, v2, v52                             // 000000DF7C88: 04B86902
	v_perm_b32 v2, v10, v6, 0xc060c02                          // 000000DF7C8C: D6440002 03FE0D0A 0C060C02
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000DF7C98: 380A0AFF 64006400
	v_perm_b32 v6, v10, v6, 0xc070c03                          // 000000DF7CA0: D6440006 03FE0D0A 0C070C03
	.long 0xcc0f400d                                           // 000000DF7CAC: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF7CB0: 12021AFF 0000E408
	v_lshrrev_b32_e32 v10, 4, v15                              // 000000DF7CB8: 32141E84
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DF7CBC: 380404FF 64006400
	.long 0xcc0f4005                                           // 000000DF7CC4: CC0F4005
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DF7CC8: 12020AFF 0000E408
	v_or_b32_e32 v6, 0x64006400, v6                            // 000000DF7CD0: 380C0CFF 64006400
	s_waitcnt lgkmcnt(3)                                       // 000000DF7CD8: BF89FC37
	v_dot2acc_f32_f16 v91, v13, v45                            // 000000DF7CDC: 04B65B0D
	v_and_b32_e32 v13, 0xf0f0f0f, v15                          // 000000DF7CE0: 361A1EFF 0F0F0F0F
	v_and_b32_e32 v10, 0xf0f0f0f, v10                          // 000000DF7CE8: 361414FF 0F0F0F0F
	.long 0xcc0f4002                                           // 000000DF7CF0: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DF7CF4: 120204FF 0000E408
	.long 0xcc0f4006                                           // 000000DF7CFC: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DF7D00: 12020CFF 0000E408
	v_dot2acc_f32_f16 v91, v5, v46                             // 000000DF7D08: 04B65D05
	v_and_b32_e32 v19, 0xf0f0f0f, v24                          // 000000DF7D0C: 362630FF 0F0F0F0F
	v_perm_b32 v5, v10, v13, 0xc040c00                         // 000000DF7D14: D6440005 03FE1B0A 0C040C00
	v_lshrrev_b32_e32 v25, 4, v24                              // 000000DF7D20: 32323084
	ds_load_b128 v[21:24], v88 offset:12064                    // 000000DF7D24: DBFC2F20 15000058
	v_dot2acc_f32_f16 v91, v2, v47                             // 000000DF7D2C: 04B65F02
	v_perm_b32 v2, v10, v13, 0xc050c01                         // 000000DF7D30: D6440002 03FE1B0A 0C050C01
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000DF7D3C: 380A0AFF 64006400
	v_and_b32_e32 v17, 0xf0f0f0f, v28                          // 000000DF7D44: 362238FF 0F0F0F0F
	v_lshrrev_b32_e32 v18, 4, v28                              // 000000DF7D4C: 32243884
	v_dot2acc_f32_f16 v91, v6, v48                             // 000000DF7D50: 04B66106
	v_perm_b32 v6, v10, v13, 0xc060c02                         // 000000DF7D54: D6440006 03FE1B0A 0C060C02
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DF7D60: 380404FF 64006400
	.long 0xcc0f4005                                           // 000000DF7D68: CC0F4005
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DF7D6C: 12020AFF 0000E408
	v_perm_b32 v10, v10, v13, 0xc070c03                        // 000000DF7D74: D644000A 03FE1B0A 0C070C03
	ds_load_b128 v[45:48], v88 offset:11552                    // 000000DF7D80: DBFC2D20 2D000058
	v_or_b32_e32 v6, 0x64006400, v6                            // 000000DF7D88: 380C0CFF 64006400
	.long 0xcc0f4002                                           // 000000DF7D90: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DF7D94: 120204FF 0000E408
	s_waitcnt lgkmcnt(2)                                       // 000000DF7D9C: BF89FC27
	v_dot2acc_f32_f16 v90, v5, v58                             // 000000DF7DA0: 04B47505
	v_or_b32_e32 v5, 0x64006400, v10                           // 000000DF7DA4: 380A14FF 64006400
	v_and_b32_e32 v10, 0xf0f0f0f, v32                          // 000000DF7DAC: 361440FF 0F0F0F0F
	.long 0xcc0f4006                                           // 000000DF7DB4: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DF7DB8: 12020CFF 0000E408
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DF7DC0: BF870214
	v_dual_dot2acc_f32_f16 v90, v2, v59 :: v_dual_and_b32 v27, 0xf0f0f0f, v16// 000000DF7DC4: CB247702 5A1A20FF 0F0F0F0F
	.long 0xcc0f4002                                           // 000000DF7DD0: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DF7DD4: 12020AFF 0000E408
	v_lshrrev_b32_e32 v5, 4, v11                               // 000000DF7DDC: 320A1684
	v_lshrrev_b32_e32 v28, 4, v16                              // 000000DF7DE0: 32382084
	v_mad_u64_u32 v[37:38], null, v85, 40, s[2:3]              // 000000DF7DE4: D6FE7C25 00095155
	v_dot2acc_f32_f16 v90, v6, v60                             // 000000DF7DEC: 04B47906
	v_and_b32_e32 v26, 0xf0f0f0f, v20                          // 000000DF7DF0: 363428FF 0F0F0F0F
	v_and_b32_e32 v5, 0xf0f0f0f, v5                            // 000000DF7DF8: 360A0AFF 0F0F0F0F
	v_lshrrev_b32_e32 v20, 4, v20                              // 000000DF7E00: 32282884
	global_load_b128 v[49:52], v[83:84], off offset:704        // 000000DF7E04: DC5E02C0 317C0053
	v_dot2acc_f32_f16 v90, v2, v61                             // 000000DF7E0C: 04B47B02
	v_and_b32_e32 v2, 0xf0f0f0f, v11                           // 000000DF7E10: 360416FF 0F0F0F0F
	ds_load_b128 v[58:61], v88 offset:11568                    // 000000DF7E18: DBFC2D30 3A000058
	v_lshrrev_b32_e32 v11, 4, v32                              // 000000DF7E20: 32164084
	ds_load_b128 v[29:32], v88 offset:11808                    // 000000DF7E24: DBFC2E20 1D000058
	v_mad_i32_i24 v38, v86, 40, v38                            // 000000DF7E2C: D60A0026 04995156
	v_perm_b32 v6, v5, v2, 0xc040c00                           // 000000DF7E34: D6440006 03FE0505 0C040C00
	v_perm_b32 v13, v5, v2, 0xc050c01                          // 000000DF7E40: D644000D 03FE0505 0C050C01
	v_perm_b32 v14, v5, v2, 0xc060c02                          // 000000DF7E4C: D644000E 03FE0505 0C060C02
	v_perm_b32 v2, v5, v2, 0xc070c03                           // 000000DF7E58: D6440002 03FE0505 0C070C03
	global_load_b128 v[108:111], v[37:38], off                 // 000000DF7E64: DC5E0000 6C7C0025
	v_or_b32_e32 v6, 0x64006400, v6                            // 000000DF7E6C: 380C0CFF 64006400
	v_or_b32_e32 v5, 0x64006400, v13                           // 000000DF7E74: 380A1AFF 64006400
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DF7E7C: 380404FF 64006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF7E84: BF870193
	.long 0xcc0f4006                                           // 000000DF7E88: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DF7E8C: 12020CFF 0000E408
	.long 0xcc0f4005                                           // 000000DF7E94: CC0F4005
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DF7E98: 12020AFF 0000E408
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DF7EA0: BF8701A3
	.long 0xcc0f4002                                           // 000000DF7EA4: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DF7EA8: 120204FF 0000E408
	s_waitcnt lgkmcnt(2)                                       // 000000DF7EB0: BF89FC27
	v_dot2acc_f32_f16 v89, v6, v45                             // 000000DF7EB4: 04B25B06
	v_or_b32_e32 v6, 0x64006400, v14                           // 000000DF7EB8: 380C1CFF 64006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF7EC0: BF870112
	v_dot2acc_f32_f16 v89, v5, v46                             // 000000DF7EC4: 04B25D05
	.long 0xcc0f4006                                           // 000000DF7EC8: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DF7ECC: 12020CFF 0000E408
	v_lshrrev_b32_e32 v5, 4, v7                                // 000000DF7ED4: 320A0E84
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF7ED8: BF870112
	v_dot2acc_f32_f16 v89, v6, v47                             // 000000DF7EDC: 04B25F06
	v_and_b32_e32 v5, 0xf0f0f0f, v5                            // 000000DF7EE0: 360A0AFF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_2)                            // 000000DF7EE8: BF870002
	v_dual_dot2acc_f32_f16 v89, v2, v48 :: v_dual_and_b32 v2, 0xf0f0f0f, v7// 000000DF7EEC: CB246102 59020EFF 0F0F0F0F
	global_load_b128 v[45:48], v[83:84], off offset:768        // 000000DF7EF8: DC5E0300 2D7C0053
	v_perm_b32 v6, v5, v2, 0xc040c00                           // 000000DF7F00: D6440006 03FE0505 0C040C00
	v_perm_b32 v7, v5, v2, 0xc050c01                           // 000000DF7F0C: D6440007 03FE0505 0C050C01
	v_perm_b32 v13, v5, v2, 0xc060c02                          // 000000DF7F18: D644000D 03FE0505 0C060C02
	v_perm_b32 v2, v5, v2, 0xc070c03                           // 000000DF7F24: D6440002 03FE0505 0C070C03
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DF7F30: BF870214
	v_or_b32_e32 v6, 0x64006400, v6                            // 000000DF7F34: 380C0CFF 64006400
	v_or_b32_e32 v5, 0x64006400, v7                            // 000000DF7F3C: 380A0EFF 64006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF7F44: BF870193
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DF7F48: 380404FF 64006400
	.long 0xcc0f4006                                           // 000000DF7F50: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DF7F54: 12020CFF 0000E408
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF7F5C: BF870193
	.long 0xcc0f4005                                           // 000000DF7F60: CC0F4005
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DF7F64: 12020AFF 0000E408
	.long 0xcc0f4002                                           // 000000DF7F6C: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DF7F70: 120204FF 0000E408
	s_waitcnt lgkmcnt(0)                                       // 000000DF7F78: BF89FC07
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DF7F7C: BF870003
	v_dot2acc_f32_f16 v9, v6, v29                              // 000000DF7F80: 04123B06
	v_or_b32_e32 v6, 0x64006400, v13                           // 000000DF7F84: 380C1AFF 64006400
	ds_load_b128 v[13:16], v88 offset:12320                    // 000000DF7F8C: DBFC3020 0D000058
	v_dot2acc_f32_f16 v9, v5, v30                              // 000000DF7F94: 04123D05
	.long 0xcc0f4006                                           // 000000DF7F98: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DF7F9C: 12020CFF 0000E408
	v_lshrrev_b32_e32 v5, 4, v3                                // 000000DF7FA4: 320A0684
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF7FA8: BF870092
	v_dot2acc_f32_f16 v9, v6, v31                              // 000000DF7FAC: 04123F06
	v_dual_dot2acc_f32_f16 v9, v2, v32 :: v_dual_and_b32 v2, 0xf0f0f0f, v3// 000000DF7FB0: CB244102 090206FF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DF7FBC: BF870003
	v_and_b32_e32 v3, 0xf0f0f0f, v5                            // 000000DF7FC0: 36060AFF 0F0F0F0F
	global_load_b128 v[29:32], v[83:84], off offset:832        // 000000DF7FC8: DC5E0340 1D7C0053
	v_perm_b32 v5, v3, v2, 0xc040c00                           // 000000DF7FD0: D6440005 03FE0503 0C040C00
	v_perm_b32 v6, v3, v2, 0xc050c01                           // 000000DF7FDC: D6440006 03FE0503 0C050C01
	v_perm_b32 v7, v3, v2, 0xc060c02                           // 000000DF7FE8: D6440007 03FE0503 0C060C02
	v_perm_b32 v2, v3, v2, 0xc070c03                           // 000000DF7FF4: D6440002 03FE0503 0C070C03
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DF8000: BF870214
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000DF8004: 380A0AFF 64006400
	v_or_b32_e32 v3, 0x64006400, v6                            // 000000DF800C: 38060CFF 64006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF8014: BF870193
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DF8018: 380404FF 64006400
	.long 0xcc0f4005                                           // 000000DF8020: CC0F4005
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DF8024: 12020AFF 0000E408
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF802C: BF870193
	.long 0xcc0f4003                                           // 000000DF8030: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DF8034: 120206FF 0000E408
	.long 0xcc0f4002                                           // 000000DF803C: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DF8040: 120204FF 0000E408
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000DF8048: BF870243
	v_dot2acc_f32_f16 v1, v5, v21                              // 000000DF804C: 04022B05
	v_or_b32_e32 v5, 0x64006400, v7                            // 000000DF8050: 380A0EFF 64006400
	v_and_b32_e32 v21, 0xf0f0f0f, v12                          // 000000DF8058: 362A18FF 0F0F0F0F
	v_lshrrev_b32_e32 v12, 4, v12                              // 000000DF8060: 32181884
	v_dot2acc_f32_f16 v1, v3, v22                              // 000000DF8064: 04022D03
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DF8068: BF870124
	.long 0xcc0f4005                                           // 000000DF806C: CC0F4005
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DF8070: 12020AFF 0000E408
	v_lshrrev_b32_e32 v3, 4, v39                               // 000000DF8078: 32064E84
	v_dual_dot2acc_f32_f16 v1, v5, v23 :: v_dual_and_b32 v12, 0xf0f0f0f, v12// 000000DF807C: CB242F05 010C18FF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF8088: BF870112
	v_and_b32_e32 v3, 0xf0f0f0f, v3                            // 000000DF808C: 360606FF 0F0F0F0F
	v_dual_dot2acc_f32_f16 v1, v2, v24 :: v_dual_and_b32 v2, 0xf0f0f0f, v39// 000000DF8094: CB243102 01024EFF 0F0F0F0F
	v_and_b32_e32 v39, 0xf0f0f0f, v4                           // 000000DF80A0: 364E08FF 0F0F0F0F
	v_lshrrev_b32_e32 v4, 4, v4                                // 000000DF80A8: 32080884
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DF80AC: BF870003
	v_perm_b32 v5, v3, v2, 0xc040c00                           // 000000DF80B0: D6440005 03FE0503 0C040C00
	v_perm_b32 v6, v3, v2, 0xc050c01                           // 000000DF80BC: D6440006 03FE0503 0C050C01
	v_perm_b32 v7, v3, v2, 0xc060c02                           // 000000DF80C8: D6440007 03FE0503 0C060C02
	v_perm_b32 v2, v3, v2, 0xc070c03                           // 000000DF80D4: D6440002 03FE0503 0C070C03
	v_and_b32_e32 v4, 0xf0f0f0f, v4                            // 000000DF80E0: 360808FF 0F0F0F0F
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000DF80E8: 380A0AFF 64006400
	v_or_b32_e32 v3, 0x64006400, v6                            // 000000DF80F0: 38060CFF 64006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF80F8: BF870194
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DF80FC: 380404FF 64006400
	.long 0xcc0f4005                                           // 000000DF8104: CC0F4005
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DF8108: 12020AFF 0000E408
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF8110: BF870193
	.long 0xcc0f4003                                           // 000000DF8114: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DF8118: 120206FF 0000E408
	.long 0xcc0f4002                                           // 000000DF8120: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DF8124: 120204FF 0000E408
	s_waitcnt lgkmcnt(0)                                       // 000000DF812C: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF8130: BF870093
	v_dot2acc_f32_f16 v95, v5, v13                             // 000000DF8134: 04BE1B05
	v_dot2acc_f32_f16 v95, v3, v14                             // 000000DF8138: 04BE1D03
	v_or_b32_e32 v3, 0x64006400, v7                            // 000000DF813C: 38060EFF 64006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF8144: BF870091
	.long 0xcc0f4003                                           // 000000DF8148: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DF814C: 120206FF 0000E408
	v_dot2acc_f32_f16 v95, v3, v15                             // 000000DF8154: 04BE1F03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DF8158: BF870121
	v_dual_dot2acc_f32_f16 v95, v2, v16 :: v_dual_and_b32 v2, 0xf0f0f0f, v11// 000000DF815C: CB242102 5F0216FF 0F0F0F0F
	v_lshrrev_b32_e32 v11, 4, v8                               // 000000DF8168: 32161084
	v_perm_b32 v3, v2, v10, 0xc040c00                          // 000000DF816C: D6440003 03FE1502 0C040C00
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF8178: BF870112
	v_and_b32_e32 v11, 0xf0f0f0f, v11                          // 000000DF817C: 361616FF 0F0F0F0F
	v_or_b32_e32 v3, 0x64006400, v3                            // 000000DF8184: 380606FF 64006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF818C: BF870091
	.long 0xcc0f4003                                           // 000000DF8190: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DF8194: 120206FF 0000E408
	v_dot2acc_f32_f16 v94, v3, v54                             // 000000DF819C: 04BC6D03
	v_perm_b32 v3, v2, v10, 0xc050c01                          // 000000DF81A0: D6440003 03FE1502 0C050C01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DF81AC: BF870091
	v_or_b32_e32 v3, 0x64006400, v3                            // 000000DF81B0: 380606FF 64006400
	.long 0xcc0f4003                                           // 000000DF81B8: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DF81BC: 120206FF 0000E408
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DF81C4: BF870001
	v_dot2acc_f32_f16 v94, v3, v55                             // 000000DF81C8: 04BC6F03
	v_perm_b32 v3, v2, v10, 0xc060c02                          // 000000DF81CC: D6440003 03FE1502 0C060C02
	v_perm_b32 v2, v2, v10, 0xc070c03                          // 000000DF81D8: D6440002 03FE1502 0C070C03
	v_and_b32_e32 v10, 0xf0f0f0f, v8                           // 000000DF81E4: 361410FF 0F0F0F0F
	global_load_b128 v[5:8], v[37:38], off offset:16           // 000000DF81EC: DC5E0010 057C0025
	v_or_b32_e32 v3, 0x64006400, v3                            // 000000DF81F4: 380606FF 64006400
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DF81FC: 380404FF 64006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF8204: BF870112
	.long 0xcc0f4003                                           // 000000DF8208: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DF820C: 120206FF 0000E408
	.long 0xcc0f4002                                           // 000000DF8214: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DF8218: 120204FF 0000E408
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 000000DF8220: BF8701D2
	v_dot2acc_f32_f16 v94, v3, v56                             // 000000DF8224: 04BC7103
	global_load_b128 v[53:56], v[83:84], off offset:640        // 000000DF8228: DC5E0280 357C0053
	v_and_b32_e32 v3, 0xf0f0f0f, v25                           // 000000DF8230: 360632FF 0F0F0F0F
	v_dot2acc_f32_f16 v94, v2, v57                             // 000000DF8238: 04BC7302
	v_and_b32_e32 v2, 0xf0f0f0f, v18                           // 000000DF823C: 360424FF 0F0F0F0F
	v_perm_b32 v14, v3, v19, 0xc040c00                         // 000000DF8244: D644000E 03FE2703 0C040C00
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DF8250: BF870112
	v_perm_b32 v13, v2, v17, 0xc040c00                         // 000000DF8254: D644000D 03FE2302 0C040C00
	v_or_b32_e32 v14, 0x64006400, v14                          // 000000DF8260: 381C1CFF 64006400
	v_perm_b32 v15, v2, v17, 0xc050c01                         // 000000DF8268: D644000F 03FE2302 0C050C01
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF8274: BF870193
	v_or_b32_e32 v13, 0x64006400, v13                          // 000000DF8278: 381A1AFF 64006400
	.long 0xcc0f400e                                           // 000000DF8280: CC0F400E
	v_mul_i32_i24_e32 v1, 0xe408, v14                          // 000000DF8284: 12021CFF 0000E408
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF828C: BF870193
	v_or_b32_e32 v15, 0x64006400, v15                          // 000000DF8290: 381E1EFF 64006400
	.long 0xcc0f400d                                           // 000000DF8298: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF829C: 12021AFF 0000E408
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DF82A4: BF870223
	v_dot2acc_f32_f16 v92, v14, v66                            // 000000DF82A8: 04B8850E
	v_perm_b32 v14, v3, v19, 0xc050c01                         // 000000DF82AC: D644000E 03FE2703 0C050C01
	.long 0xcc0f400f                                           // 000000DF82B8: CC0F400F
	v_mul_i32_i24_e32 v1, 0xe408, v15                          // 000000DF82BC: 12021EFF 0000E408
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000DF82C4: BF870244
	v_dot2acc_f32_f16 v93, v13, v62                            // 000000DF82C8: 04BA7D0D
	v_perm_b32 v13, v2, v17, 0xc060c02                         // 000000DF82CC: D644000D 03FE2302 0C060C02
	v_perm_b32 v2, v2, v17, 0xc070c03                          // 000000DF82D8: D6440002 03FE2302 0C070C03
	v_or_b32_e32 v14, 0x64006400, v14                          // 000000DF82E4: 381C1CFF 64006400
	v_dual_dot2acc_f32_f16 v93, v15, v63 :: v_dual_and_b32 v62, 0xf0f0f0f, v40// 000000DF82EC: CB247F0F 5D3E50FF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DF82F8: BF870004
	v_or_b32_e32 v13, 0x64006400, v13                          // 000000DF82FC: 381A1AFF 64006400
	v_perm_b32 v15, v3, v19, 0xc060c02                         // 000000DF8304: D644000F 03FE2703 0C060C02
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DF8310: 380404FF 64006400
	.long 0xcc0f400e                                           // 000000DF8318: CC0F400E
	v_mul_i32_i24_e32 v1, 0xe408, v14                          // 000000DF831C: 12021CFF 0000E408
	v_perm_b32 v3, v3, v19, 0xc070c03                          // 000000DF8324: D6440003 03FE2703 0C070C03
	.long 0xcc0f400d                                           // 000000DF8330: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF8334: 12021AFF 0000E408
	v_lshrrev_b32_e32 v40, 4, v40                              // 000000DF833C: 32505084
	.long 0xcc0f4002                                           // 000000DF8340: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DF8344: 120204FF 0000E408
	v_dot2acc_f32_f16 v92, v14, v67                            // 000000DF834C: 04B8870E
	v_or_b32_e32 v3, 0x64006400, v3                            // 000000DF8350: 380606FF 64006400
	v_dot2acc_f32_f16 v93, v13, v64                            // 000000DF8358: 04BA810D
	v_or_b32_e32 v13, 0x64006400, v15                          // 000000DF835C: 381A1EFF 64006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF8364: BF870193
	.long 0xcc0f4003                                           // 000000DF8368: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DF836C: 120206FF 0000E408
	v_dot2acc_f32_f16 v93, v2, v65                             // 000000DF8374: 04BA8302
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DF8378: BF870123
	.long 0xcc0f400d                                           // 000000DF837C: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF8380: 12021AFF 0000E408
	v_and_b32_e32 v2, 0xf0f0f0f, v20                           // 000000DF8388: 360428FF 0F0F0F0F
	v_dot2acc_f32_f16 v92, v13, v68                            // 000000DF8390: 04B8890D
	v_and_b32_e32 v13, 0xf0f0f0f, v28                          // 000000DF8394: 361A38FF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DF839C: BF870003
	v_perm_b32 v14, v2, v26, 0xc040c00                         // 000000DF83A0: D644000E 03FE3502 0C040C00
	v_perm_b32 v15, v2, v26, 0xc050c01                         // 000000DF83AC: D644000F 03FE3502 0C050C01
	v_perm_b32 v16, v2, v26, 0xc060c02                         // 000000DF83B8: D6440010 03FE3502 0C060C02
	v_dot2acc_f32_f16 v92, v3, v69                             // 000000DF83C4: 04B88B03
	v_perm_b32 v3, v13, v27, 0xc040c00                         // 000000DF83C8: D6440003 03FE370D 0C040C00
	v_or_b32_e32 v14, 0x64006400, v14                          // 000000DF83D4: 381C1CFF 64006400
	v_or_b32_e32 v15, 0x64006400, v15                          // 000000DF83DC: 381E1EFF 64006400
	v_perm_b32 v2, v2, v26, 0xc070c03                          // 000000DF83E4: D6440002 03FE3502 0C070C03
	v_or_b32_e32 v16, 0x64006400, v16                          // 000000DF83F0: 382020FF 64006400
	v_or_b32_e32 v3, 0x64006400, v3                            // 000000DF83F8: 380606FF 64006400
	.long 0xcc0f400e                                           // 000000DF8400: CC0F400E
	v_mul_i32_i24_e32 v1, 0xe408, v14                          // 000000DF8404: 12021CFF 0000E408
	.long 0xcc0f400f                                           // 000000DF840C: CC0F400F
	v_mul_i32_i24_e32 v1, 0xe408, v15                          // 000000DF8410: 12021EFF 0000E408
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DF8418: 380404FF 64006400
	v_perm_b32 v17, v13, v27, 0xc050c01                        // 000000DF8420: D6440011 03FE370D 0C050C01
	.long 0xcc0f4003                                           // 000000DF842C: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DF8430: 120206FF 0000E408
	v_dot2acc_f32_f16 v91, v14, v70                            // 000000DF8438: 04B68D0E
	.long 0xcc0f400e                                           // 000000DF843C: CC0F400E
	v_mul_i32_i24_e32 v1, 0xe408, v16                          // 000000DF8440: 120220FF 0000E408
	.long 0xcc0f4002                                           // 000000DF8448: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DF844C: 120204FF 0000E408
	v_perm_b32 v18, v13, v27, 0xc060c02                        // 000000DF8454: D6440012 03FE370D 0C060C02
	v_dot2acc_f32_f16 v90, v3, v74                             // 000000DF8460: 04B49503
	v_perm_b32 v3, v12, v21, 0xc040c00                         // 000000DF8464: D6440003 03FE2B0C 0C040C00
	v_dot2acc_f32_f16 v91, v15, v71                            // 000000DF8470: 04B68F0F
	v_perm_b32 v15, v12, v21, 0xc050c01                        // 000000DF8474: D644000F 03FE2B0C 0C050C01
	v_perm_b32 v13, v13, v27, 0xc070c03                        // 000000DF8480: D644000D 03FE370D 0C070C03
	v_or_b32_e32 v16, 0x64006400, v17                          // 000000DF848C: 382022FF 64006400
	v_or_b32_e32 v3, 0x64006400, v3                            // 000000DF8494: 380606FF 64006400
	v_dot2acc_f32_f16 v91, v14, v72                            // 000000DF849C: 04B6910E
	v_perm_b32 v14, v12, v21, 0xc060c02                        // 000000DF84A0: D644000E 03FE2B0C 0C060C02
	v_perm_b32 v12, v12, v21, 0xc070c03                        // 000000DF84AC: D644000C 03FE2B0C 0C070C03
	v_or_b32_e32 v17, 0x64006400, v18                          // 000000DF84B8: 382224FF 64006400
	.long 0xcc0f4003                                           // 000000DF84C0: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DF84C4: 120206FF 0000E408
	v_dot2acc_f32_f16 v91, v2, v73                             // 000000DF84CC: 04B69302
	v_or_b32_e32 v2, 0x64006400, v15                           // 000000DF84D0: 38041EFF 64006400
	.long 0xcc0f4010                                           // 000000DF84D8: CC0F4010
	v_mul_i32_i24_e32 v1, 0xe408, v16                          // 000000DF84DC: 120220FF 0000E408
	v_or_b32_e32 v12, 0x64006400, v12                          // 000000DF84E4: 381818FF 64006400
	v_dot2acc_f32_f16 v89, v3, v58                             // 000000DF84EC: 04B27503
	v_or_b32_e32 v3, 0x64006400, v13                           // 000000DF84F0: 38061AFF 64006400
	v_or_b32_e32 v13, 0x64006400, v14                          // 000000DF84F8: 381A1CFF 64006400
	.long 0xcc0f4002                                           // 000000DF8500: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DF8504: 120204FF 0000E408
	.long 0xcc0f4011                                           // 000000DF850C: CC0F4011
	v_mul_i32_i24_e32 v1, 0xe408, v17                          // 000000DF8510: 120222FF 0000E408
	v_dot2acc_f32_f16 v90, v16, v75                            // 000000DF8518: 04B49710
	.long 0xcc0f400c                                           // 000000DF851C: CC0F400C
	v_mul_i32_i24_e32 v1, 0xe408, v12                          // 000000DF8520: 120218FF 0000E408
	.long 0xcc0f4039                                           // 000000DF8528: CC0F4039
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF852C: 12021AFF 0000E408
	v_dot2acc_f32_f16 v89, v2, v59                             // 000000DF8534: 04B27702
	.long 0xcc0f4003                                           // 000000DF8538: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DF853C: 120206FF 0000E408
	v_dot2acc_f32_f16 v90, v17, v76                            // 000000DF8544: 04B49911
	s_clause 0x1                                               // 000000DF8548: BF850001
	global_load_b128 v[17:20], v[83:84], off offset:1024       // 000000DF854C: DC5E0400 117C0053
	global_load_b128 v[13:16], v[83:84], off offset:1088       // 000000DF8554: DC5E0440 0D7C0053
	v_lshrrev_b32_e32 v2, 4, v34                               // 000000DF855C: 32044484
	v_dot2acc_f32_f16 v89, v57, v60                            // 000000DF8560: 04B27939
	v_perm_b32 v57, v11, v10, 0xc060c02                        // 000000DF8564: D6440039 03FE150B 0C060C02
	v_dual_dot2acc_f32_f16 v90, v3, v77 :: v_dual_and_b32 v3, 0xf0f0f0f, v34// 000000DF8570: CB249B03 5A0244FF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DF857C: BF870003
	v_dual_dot2acc_f32_f16 v89, v12, v61 :: v_dual_and_b32 v34, 0xf0f0f0f, v40// 000000DF8580: CB247B0C 592250FF 0F0F0F0F
	v_perm_b32 v12, v11, v10, 0xc040c00                        // 000000DF858C: D644000C 03FE150B 0C040C00
	v_perm_b32 v40, v11, v10, 0xc050c01                        // 000000DF8598: D6440028 03FE150B 0C050C01
	v_perm_b32 v10, v11, v10, 0xc070c03                        // 000000DF85A4: D644000A 03FE150B 0C070C03
	v_perm_b32 v11, v4, v39, 0xc040c00                         // 000000DF85B0: D644000B 03FE4F04 0C040C00
	v_perm_b32 v58, v4, v39, 0xc050c01                         // 000000DF85BC: D644003A 03FE4F04 0C050C01
	v_or_b32_e32 v12, 0x64006400, v12                          // 000000DF85C8: 381818FF 64006400
	v_or_b32_e32 v40, 0x64006400, v40                          // 000000DF85D0: 385050FF 64006400
	v_perm_b32 v59, v4, v39, 0xc060c02                         // 000000DF85D8: D644003B 03FE4F04 0C060C02
	v_or_b32_e32 v11, 0x64006400, v11                          // 000000DF85E4: 381616FF 64006400
	v_or_b32_e32 v57, 0x64006400, v57                          // 000000DF85EC: 387272FF 64006400
	.long 0xcc0f400c                                           // 000000DF85F4: CC0F400C
	v_mul_i32_i24_e32 v1, 0xe408, v12                          // 000000DF85F8: 120218FF 0000E408
	.long 0xcc0f4028                                           // 000000DF8600: CC0F4028
	v_mul_i32_i24_e32 v1, 0xe408, v40                          // 000000DF8604: 120250FF 0000E408
	v_or_b32_e32 v58, 0x64006400, v58                          // 000000DF860C: 387474FF 64006400
	.long 0xcc0f400b                                           // 000000DF8614: CC0F400B
	v_mul_i32_i24_e32 v1, 0xe408, v11                          // 000000DF8618: 120216FF 0000E408
	s_waitcnt vmcnt(6)                                         // 000000DF8620: BF891BF7
	v_fma_mix_f32 v60, v108, v94, 0 op_sel_hi:[1,0,0]          // 000000DF8624: CC20003C 0A02BD6C
	v_dual_dot2acc_f32_f16 v9, v12, v96 :: v_dual_and_b32 v2, 0xf0f0f0f, v2// 000000DF862C: CB24C10C 090204FF 0F0F0F0F
	v_perm_b32 v4, v4, v39, 0xc070c03                          // 000000DF8638: D6440004 03FE4F04 0C070C03
	v_dot2acc_f32_f16 v1, v11, v100                            // 000000DF8644: 0402C90B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DF8648: BF870214
	v_fma_mix_f32 v60, v108, v93, v60 op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DF864C: CC20083C 0CF2BB6C
	v_dot2acc_f32_f16 v9, v40, v97                             // 000000DF8654: 0412C328
	v_or_b32_e32 v10, 0x64006400, v10                          // 000000DF8658: 381414FF 64006400
	v_or_b32_e32 v59, 0x64006400, v59                          // 000000DF8660: 387676FF 64006400
	.long 0xcc0f4039                                           // 000000DF8668: CC0F4039
	v_mul_i32_i24_e32 v1, 0xe408, v57                          // 000000DF866C: 120272FF 0000E408
	v_fma_mix_f32 v60, v109, v92, v60 op_sel_hi:[1,0,0]        // 000000DF8674: CC20003C 0CF2B96D
	.long 0xcc0f403a                                           // 000000DF867C: CC0F403A
	v_mul_i32_i24_e32 v1, 0xe408, v58                          // 000000DF8680: 120274FF 0000E408
	v_perm_b32 v39, v34, v62, 0xc040c00                        // 000000DF8688: D6440027 03FE7D22 0C040C00
	v_perm_b32 v11, v2, v3, 0xc040c00                          // 000000DF8694: D644000B 03FE0702 0C040C00
	v_or_b32_e32 v4, 0x64006400, v4                            // 000000DF86A0: 380808FF 64006400
	v_fma_mix_f32 v60, v109, v91, v60 op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DF86A8: CC20083C 0CF2B76D
	.long 0xcc0f400a                                           // 000000DF86B0: CC0F400A
	v_mul_i32_i24_e32 v1, 0xe408, v10                          // 000000DF86B4: 120214FF 0000E408
	.long 0xcc0f403b                                           // 000000DF86BC: CC0F403B
	v_mul_i32_i24_e32 v1, 0xe408, v59                          // 000000DF86C0: 120276FF 0000E408
	v_dot2acc_f32_f16 v1, v58, v101                            // 000000DF86C8: 0402CB3A
	v_dot2acc_f32_f16 v9, v57, v98                             // 000000DF86CC: 0412C539
	v_fma_mix_f32 v57, v110, v90, v60 op_sel_hi:[1,0,0]        // 000000DF86D0: CC200039 0CF2B56E
	v_perm_b32 v12, v34, v62, 0xc050c01                        // 000000DF86D8: D644000C 03FE7D22 0C050C01
	v_perm_b32 v40, v2, v3, 0xc050c01                          // 000000DF86E4: D6440028 03FE0702 0C050C01
	v_or_b32_e32 v39, 0x64006400, v39                          // 000000DF86F0: 384E4EFF 64006400
	v_or_b32_e32 v11, 0x64006400, v11                          // 000000DF86F8: 381616FF 64006400
	.long 0xcc0f4004                                           // 000000DF8700: CC0F4004
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DF8704: 120208FF 0000E408
	v_dot2acc_f32_f16 v1, v59, v102                            // 000000DF870C: 0402CD3B
	v_dot2acc_f32_f16 v9, v10, v99                             // 000000DF8710: 0412C70A
	v_fma_mix_f32 v10, v110, v89, v57 op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DF8714: CC20080A 0CE6B36E
	v_perm_b32 v63, v2, v3, 0xc060c02                          // 000000DF871C: D644003F 03FE0702 0C060C02
	v_or_b32_e32 v12, 0x64006400, v12                          // 000000DF8728: 381818FF 64006400
	v_or_b32_e32 v40, 0x64006400, v40                          // 000000DF8730: 385050FF 64006400
	.long 0xcc0f4027                                           // 000000DF8738: CC0F4027
	v_mul_i32_i24_e32 v1, 0xe408, v39                          // 000000DF873C: 12024EFF 0000E408
	.long 0xcc0f400b                                           // 000000DF8744: CC0F400B
	v_mul_i32_i24_e32 v1, 0xe408, v11                          // 000000DF8748: 120216FF 0000E408
	v_dot2acc_f32_f16 v1, v4, v103                             // 000000DF8750: 0402CF04
	v_fma_mix_f32 v4, v111, v9, v10 op_sel_hi:[1,0,0]          // 000000DF8754: CC200004 0C2A136F
	v_lshrrev_b32_e32 v9, 4, v35                               // 000000DF875C: 32124684
	.long 0xcc0f400c                                           // 000000DF8760: CC0F400C
	v_mul_i32_i24_e32 v1, 0xe408, v12                          // 000000DF8764: 120218FF 0000E408
	v_dot2acc_f32_f16 v95, v39, v104                           // 000000DF876C: 04BED127
	v_dot2acc_f32_f16 v33, v11, v41                            // 000000DF8770: 0442530B
	.long 0xcc0f400a                                           // 000000DF8774: CC0F400A
	v_mul_i32_i24_e32 v1, 0xe408, v40                          // 000000DF8778: 120250FF 0000E408
	v_or_b32_e32 v11, 0x64006400, v63                          // 000000DF8780: 38167EFF 64006400
	v_perm_b32 v2, v2, v3, 0xc070c03                           // 000000DF8788: D6440002 03FE0702 0C070C03
	v_and_b32_e32 v3, 0xf0f0f0f, v35                           // 000000DF8794: 360646FF 0F0F0F0F
	v_and_b32_e32 v9, 0xf0f0f0f, v9                            // 000000DF879C: 361212FF 0F0F0F0F
	ds_load_b128 v[57:60], v88 offset:12576                    // 000000DF87A4: DBFC3120 39000058
	s_clause 0x1                                               // 000000DF87AC: BF850001
	global_load_b128 v[25:28], v[83:84], off offset:896        // 000000DF87B0: DC5E0380 197C0053
	global_load_b128 v[21:24], v[83:84], off offset:960        // 000000DF87B8: DC5E03C0 157C0053
	v_perm_b32 v61, v34, v62, 0xc060c02                        // 000000DF87C0: D644003D 03FE7D22 0C060C02
	v_dot2acc_f32_f16 v95, v12, v105                           // 000000DF87CC: 04BED30C
	v_perm_b32 v12, v34, v62, 0xc070c03                        // 000000DF87D0: D644000C 03FE7D22 0C070C03
	v_dot2acc_f32_f16 v33, v10, v42                            // 000000DF87DC: 0442550A
	.long 0xcc0f400a                                           // 000000DF87E0: CC0F400A
	v_mul_i32_i24_e32 v1, 0xe408, v11                          // 000000DF87E4: 120216FF 0000E408
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DF87EC: 380404FF 64006400
	v_perm_b32 v11, v9, v3, 0xc040c00                          // 000000DF87F4: D644000B 03FE0709 0C040C00
	v_or_b32_e32 v61, 0x64006400, v61                          // 000000DF8800: 387A7AFF 64006400
	v_or_b32_e32 v12, 0x64006400, v12                          // 000000DF8808: 381818FF 64006400
	v_dot2acc_f32_f16 v33, v10, v43                            // 000000DF8810: 0442570A
	.long 0xcc0f4002                                           // 000000DF8814: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DF8818: 120204FF 0000E408
	v_or_b32_e32 v10, 0x64006400, v11                          // 000000DF8820: 381416FF 64006400
	.long 0xcc0f4027                                           // 000000DF8828: CC0F4027
	v_mul_i32_i24_e32 v1, 0xe408, v61                          // 000000DF882C: 12027AFF 0000E408
	.long 0xcc0f400b                                           // 000000DF8834: CC0F400B
	v_mul_i32_i24_e32 v1, 0xe408, v12                          // 000000DF8838: 120218FF 0000E408
	v_perm_b32 v12, v9, v3, 0xc050c01                          // 000000DF8840: D644000C 03FE0709 0C050C01
	v_fma_mix_f32 v34, v111, v1, v4 op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DF884C: CC200822 0C12036F
	v_dot2acc_f32_f16 v33, v2, v44                             // 000000DF8854: 04425902
	.long 0xcc0f4001                                           // 000000DF8858: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v10                          // 000000DF885C: 120214FF 0000E408
	v_dot2acc_f32_f16 v95, v39, v106                           // 000000DF8864: 04BED527
	v_or_b32_e32 v2, 0x64006400, v12                           // 000000DF8868: 380418FF 64006400
	v_perm_b32 v4, v9, v3, 0xc060c02                           // 000000DF8870: D6440004 03FE0709 0C060C02
	ds_load_b128 v[39:42], v88 offset:12592                    // 000000DF887C: DBFC3130 27000058
	s_waitcnt lgkmcnt(1)                                       // 000000DF8884: BF89FC17
	v_dot2acc_f32_f16 v33, v1, v57                             // 000000DF8888: 04427301
	ds_load_b128 v[61:64], v88 offset:12800                    // 000000DF888C: DBFC3200 3D000058
	ds_load_b128 v[65:68], v88 offset:12816                    // 000000DF8894: DBFC3210 41000058
	.long 0xcc0f4002                                           // 000000DF889C: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DF88A0: 120204FF 0000E408
	v_or_b32_e32 v4, 0x64006400, v4                            // 000000DF88A8: 380808FF 64006400
	v_mov_b32_e32 v69, 0                                       // 000000DF88B0: 7E8A0280
	v_perm_b32 v3, v9, v3, 0xc070c03                           // 000000DF88B4: D6440003 03FE0709 0C070C03
	v_dot2acc_f32_f16 v95, v11, v107                           // 000000DF88C0: 04BED70B
	v_dot2acc_f32_f16 v33, v2, v58                             // 000000DF88C4: 04427502
	.long 0xcc0f402c                                           // 000000DF88C8: CC0F402C
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DF88CC: 120208FF 0000E408
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DF88D4: BF870001
	v_dot2acc_f32_f16 v33, v44, v59                            // 000000DF88D8: 0442772C
	s_waitcnt vmcnt(5)                                         // 000000DF88DC: BF8917F7
	v_fma_mix_f32 v34, v5, v95, v34 op_sel_hi:[1,0,0]          // 000000DF88E0: CC200022 0C8ABF05
	s_waitcnt vmcnt(4)                                         // 000000DF88E8: BF8913F7
	v_lshrrev_b32_e32 v1, 4, v53                               // 000000DF88EC: 32026A84
	v_and_b32_e32 v35, 0xf0f0f0f, v53                          // 000000DF88F0: 36466AFF 0F0F0F0F
	v_or_b32_e32 v53, 0x64006400, v3                           // 000000DF88F8: 386A06FF 64006400
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DF8900: BF870003
	v_and_b32_e32 v43, 0xf0f0f0f, v1                           // 000000DF8904: 365602FF 0F0F0F0F
	s_clause 0x1                                               // 000000DF890C: BF850001
	global_load_b128 v[9:12], v[83:84], off offset:1152        // 000000DF8910: DC5E0480 097C0053
	global_load_b128 v[1:4], v[83:84], off offset:1216         // 000000DF8918: DC5E04C0 017C0053
	.long 0xcc0f4035                                           // 000000DF8920: CC0F4035
	v_mul_i32_i24_e32 v1, 0xe408, v53                          // 000000DF8924: 12026AFF 0000E408
	v_perm_b32 v57, v43, v35, 0xc040c00                        // 000000DF892C: D6440039 03FE472B 0C040C00
	v_perm_b32 v58, v43, v35, 0xc050c01                        // 000000DF8938: D644003A 03FE472B 0C050C01
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF8944: BF870193
	v_dot2acc_f32_f16 v33, v53, v60                            // 000000DF8948: 04427935
	v_or_b32_e32 v44, 0x64006400, v57                          // 000000DF894C: 385872FF 64006400
	v_lshrrev_b32_e32 v57, 4, v36                              // 000000DF8954: 32724884
	v_and_b32_e32 v36, 0xf0f0f0f, v36                          // 000000DF8958: 364848FF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DF8960: BF870193
	.long 0xcc0f402c                                           // 000000DF8964: CC0F402C
	v_mul_i32_i24_e32 v1, 0xe408, v44                          // 000000DF8968: 120258FF 0000E408
	v_and_b32_e32 v70, 0xf0f0f0f, v57                          // 000000DF8970: 368C72FF 0F0F0F0F
	v_or_b32_e32 v57, 0x64006400, v58                          // 000000DF8978: 387274FF 64006400
	v_perm_b32 v58, v43, v35, 0xc060c02                        // 000000DF8980: D644003A 03FE472B 0C060C02
	v_perm_b32 v35, v43, v35, 0xc070c03                        // 000000DF898C: D6440023 03FE472B 0C070C03
	s_waitcnt lgkmcnt(1)                                       // 000000DF8998: BF89FC17
	v_dot2acc_f32_f16 v69, v44, v61                            // 000000DF899C: 048A7B2C
	v_lshrrev_b32_e32 v44, 4, v54                              // 000000DF89A0: 32586C84
	.long 0xcc0f4039                                           // 000000DF89A4: CC0F4039
	v_mul_i32_i24_e32 v1, 0xe408, v57                          // 000000DF89A8: 120272FF 0000E408
	v_or_b32_e32 v58, 0x64006400, v58                          // 000000DF89B0: 387474FF 64006400
	v_and_b32_e32 v43, 0xf0f0f0f, v54                          // 000000DF89B8: 36566CFF 0F0F0F0F
	v_perm_b32 v54, v70, v36, 0xc040c00                        // 000000DF89C0: D6440036 03FE4946 0C040C00
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DF89CC: BF870214
	v_dual_dot2acc_f32_f16 v69, v57, v62 :: v_dual_and_b32 v44, 0xf0f0f0f, v44// 000000DF89D0: CB247D39 452C58FF 0F0F0F0F
	.long 0xcc0f4039                                           // 000000DF89DC: CC0F4039
	v_mul_i32_i24_e32 v1, 0xe408, v58                          // 000000DF89E0: 120274FF 0000E408
	v_or_b32_e32 v35, 0x64006400, v35                          // 000000DF89E8: 384646FF 64006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DF89F0: BF870214
	v_or_b32_e32 v54, 0x64006400, v54                          // 000000DF89F4: 386C6CFF 64006400
	v_perm_b32 v58, v44, v43, 0xc040c00                        // 000000DF89FC: D644003A 03FE572C 0C040C00
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DF8A08: BF870214
	v_dot2acc_f32_f16 v69, v57, v63                            // 000000DF8A0C: 048A7F39
	.long 0xcc0f4023                                           // 000000DF8A10: CC0F4023
	v_mul_i32_i24_e32 v1, 0xe408, v35                          // 000000DF8A14: 120246FF 0000E408
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DF8A1C: BF870214
	.long 0xcc0f4036                                           // 000000DF8A20: CC0F4036
	v_mul_i32_i24_e32 v1, 0xe408, v54                          // 000000DF8A24: 12026CFF 0000E408
	v_or_b32_e32 v53, 0x64006400, v58                          // 000000DF8A2C: 386A74FF 64006400
	v_perm_b32 v57, v44, v43, 0xc050c01                        // 000000DF8A34: D6440039 03FE572C 0C050C01
	v_perm_b32 v58, v70, v36, 0xc050c01                        // 000000DF8A40: D644003A 03FE4946 0C050C01
	v_dot2acc_f32_f16 v69, v35, v64                            // 000000DF8A4C: 048A8123
	v_dot2acc_f32_f16 v33, v54, v39                            // 000000DF8A50: 04424F36
	.long 0xcc0f4023                                           // 000000DF8A54: CC0F4023
	v_mul_i32_i24_e32 v1, 0xe408, v53                          // 000000DF8A58: 12026AFF 0000E408
	v_or_b32_e32 v39, 0x64006400, v57                          // 000000DF8A60: 384E72FF 64006400
	v_perm_b32 v53, v44, v43, 0xc060c02                        // 000000DF8A68: D6440035 03FE572C 0C060C02
	v_or_b32_e32 v54, 0x64006400, v58                          // 000000DF8A74: 386C74FF 64006400
	v_perm_b32 v43, v44, v43, 0xc070c03                        // 000000DF8A7C: D644002B 03FE572C 0C070C03
	s_waitcnt lgkmcnt(0)                                       // 000000DF8A88: BF89FC07
	v_dot2acc_f32_f16 v69, v35, v65                            // 000000DF8A8C: 048A8323
	v_lshrrev_b32_e32 v35, 4, v55                              // 000000DF8A90: 32466E84
	.long 0xcc0f4027                                           // 000000DF8A94: CC0F4027
	v_mul_i32_i24_e32 v1, 0xe408, v39                          // 000000DF8A98: 12024EFF 0000E408
	v_or_b32_e32 v53, 0x64006400, v53                          // 000000DF8AA0: 386A6AFF 64006400
	v_and_b32_e32 v44, 0xf0f0f0f, v55                          // 000000DF8AA8: 36586EFF 0F0F0F0F
	ds_load_b128 v[57:60], v88 offset:12832                    // 000000DF8AB0: DBFC3220 39000058
	ds_load_b128 v[61:64], v88 offset:12848                    // 000000DF8AB8: DBFC3230 3D000058
	v_and_b32_e32 v35, 0xf0f0f0f, v35                          // 000000DF8AC0: 364646FF 0F0F0F0F
	v_dot2acc_f32_f16 v69, v39, v66                            // 000000DF8AC8: 048A8527
	.long 0xcc0f4027                                           // 000000DF8ACC: CC0F4027
	v_mul_i32_i24_e32 v1, 0xe408, v53                          // 000000DF8AD0: 12026AFF 0000E408
	v_or_b32_e32 v43, 0x64006400, v43                          // 000000DF8AD8: 385656FF 64006400
	.long 0xcc0f4036                                           // 000000DF8AE0: CC0F4036
	v_mul_i32_i24_e32 v1, 0xe408, v54                          // 000000DF8AE4: 12026CFF 0000E408
	v_perm_b32 v53, v35, v44, 0xc040c00                        // 000000DF8AEC: D6440035 03FE5923 0C040C00
	v_perm_b32 v55, v70, v36, 0xc060c02                        // 000000DF8AF8: D6440037 03FE4946 0C060C02
	v_dot2acc_f32_f16 v69, v39, v67                            // 000000DF8B04: 048A8727
	.long 0xcc0f4027                                           // 000000DF8B08: CC0F4027
	v_mul_i32_i24_e32 v1, 0xe408, v43                          // 000000DF8B0C: 120256FF 0000E408
	v_dot2acc_f32_f16 v33, v54, v40                            // 000000DF8B14: 04425136
	v_or_b32_e32 v43, 0x64006400, v53                          // 000000DF8B18: 38566AFF 64006400
	v_perm_b32 v40, v35, v44, 0xc050c01                        // 000000DF8B20: D6440028 03FE5923 0C050C01
	v_or_b32_e32 v55, 0x64006400, v55                          // 000000DF8B2C: 386E6EFF 64006400
	v_dot2acc_f32_f16 v69, v39, v68                            // 000000DF8B34: 048A8927
	ds_load_b128 v[65:68], v88 offset:13056                    // 000000DF8B38: DBFC3300 41000058
	.long 0xcc0f4027                                           // 000000DF8B40: CC0F4027
	v_mul_i32_i24_e32 v1, 0xe408, v43                          // 000000DF8B44: 120256FF 0000E408
	v_or_b32_e32 v40, 0x64006400, v40                          // 000000DF8B4C: 385050FF 64006400
	v_perm_b32 v43, v35, v44, 0xc060c02                        // 000000DF8B54: D644002B 03FE5923 0C060C02
	v_perm_b32 v35, v35, v44, 0xc070c03                        // 000000DF8B60: D6440023 03FE5923 0C070C03
	v_and_b32_e32 v44, 0xf0f0f0f, v49                          // 000000DF8B6C: 365862FF 0F0F0F0F
	s_waitcnt lgkmcnt(2)                                       // 000000DF8B74: BF89FC27
	v_dot2acc_f32_f16 v69, v39, v57                            // 000000DF8B78: 048A7327
	v_lshrrev_b32_e32 v39, 4, v49                              // 000000DF8B7C: 324E6284
	.long 0xcc0f4028                                           // 000000DF8B80: CC0F4028
	v_mul_i32_i24_e32 v1, 0xe408, v40                          // 000000DF8B84: 120250FF 0000E408
	v_or_b32_e32 v43, 0x64006400, v43                          // 000000DF8B8C: 385656FF 64006400
	.long 0xcc0f4035                                           // 000000DF8B94: CC0F4035
	v_mul_i32_i24_e32 v1, 0xe408, v55                          // 000000DF8B98: 12026EFF 0000E408
	v_mov_b32_e32 v57, 0                                       // 000000DF8BA0: 7E720280
	v_and_b32_e32 v39, 0xf0f0f0f, v39                          // 000000DF8BA4: 364E4EFF 0F0F0F0F
	v_dot2acc_f32_f16 v69, v40, v58                            // 000000DF8BAC: 048A7528
	.long 0xcc0f4028                                           // 000000DF8BB0: CC0F4028
	v_mul_i32_i24_e32 v1, 0xe408, v43                          // 000000DF8BB4: 120256FF 0000E408
	v_dot2acc_f32_f16 v33, v53, v41                            // 000000DF8BBC: 04425335
	v_lshrrev_b32_e32 v41, 4, v56                              // 000000DF8BC0: 32527084
	v_perm_b32 v43, v39, v44, 0xc040c00                        // 000000DF8BC4: D644002B 03FE5927 0C040C00
	v_and_b32_e32 v49, 0xf0f0f0f, v56                          // 000000DF8BD0: 366270FF 0F0F0F0F
	v_dot2acc_f32_f16 v69, v40, v59                            // 000000DF8BD8: 048A7728
	ds_load_b128 v[53:56], v88 offset:13072                    // 000000DF8BDC: DBFC3310 35000058
	v_and_b32_e32 v58, 0xf0f0f0f, v41                          // 000000DF8BE4: 367452FF 0F0F0F0F
	v_or_b32_e32 v40, 0x64006400, v43                          // 000000DF8BEC: 385056FF 64006400
	v_perm_b32 v43, v39, v44, 0xc050c01                        // 000000DF8BF4: D644002B 03FE5927 0C050C01
	v_or_b32_e32 v35, 0x64006400, v35                          // 000000DF8C00: 384646FF 64006400
	v_perm_b32 v36, v70, v36, 0xc070c03                        // 000000DF8C08: D6440024 03FE4946 0C070C03
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DF8C14: BF870214
	.long 0xcc0f4028                                           // 000000DF8C18: CC0F4028
	v_mul_i32_i24_e32 v1, 0xe408, v40                          // 000000DF8C1C: 120250FF 0000E408
	v_or_b32_e32 v41, 0x64006400, v43                          // 000000DF8C24: 385256FF 64006400
	v_perm_b32 v43, v39, v44, 0xc060c02                        // 000000DF8C2C: D644002B 03FE5927 0C060C02
	v_perm_b32 v39, v39, v44, 0xc070c03                        // 000000DF8C38: D6440027 03FE5927 0C070C03
	s_waitcnt lgkmcnt(1)                                       // 000000DF8C44: BF89FC17
	v_dual_dot2acc_f32_f16 v57, v40, v65 :: v_dual_and_b32 v44, 0xf0f0f0f, v50// 000000DF8C48: CB248328 392C64FF 0F0F0F0F
	v_lshrrev_b32_e32 v40, 4, v50                              // 000000DF8C54: 32506484
	.long 0xcc0f4029                                           // 000000DF8C58: CC0F4029
	v_mul_i32_i24_e32 v1, 0xe408, v41                          // 000000DF8C5C: 120252FF 0000E408
	v_or_b32_e32 v43, 0x64006400, v43                          // 000000DF8C64: 385656FF 64006400
	.long 0xcc0f4023                                           // 000000DF8C6C: CC0F4023
	v_mul_i32_i24_e32 v1, 0xe408, v35                          // 000000DF8C70: 120246FF 0000E408
	v_or_b32_e32 v39, 0x64006400, v39                          // 000000DF8C78: 384E4EFF 64006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DF8C80: BF870214
	v_dual_dot2acc_f32_f16 v57, v41, v66 :: v_dual_and_b32 v40, 0xf0f0f0f, v40// 000000DF8C84: CB248529 392850FF 0F0F0F0F
	.long 0xcc0f4029                                           // 000000DF8C90: CC0F4029
	v_mul_i32_i24_e32 v1, 0xe408, v43                          // 000000DF8C94: 120256FF 0000E408
	v_or_b32_e32 v36, 0x64006400, v36                          // 000000DF8C9C: 384848FF 64006400
	v_perm_b32 v50, v58, v49, 0xc040c00                        // 000000DF8CA4: D6440032 03FE633A 0C040C00
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DF8CB0: BF870004
	v_perm_b32 v43, v40, v44, 0xc040c00                        // 000000DF8CB4: D644002B 03FE5928 0C040C00
	v_dot2acc_f32_f16 v69, v35, v60                            // 000000DF8CC0: 048A7923
	v_dot2acc_f32_f16 v57, v41, v67                            // 000000DF8CC4: 04728729
	.long 0xcc0f4023                                           // 000000DF8CC8: CC0F4023
	v_mul_i32_i24_e32 v1, 0xe408, v39                          // 000000DF8CCC: 12024EFF 0000E408
	.long 0xcc0f4024                                           // 000000DF8CD4: CC0F4024
	v_mul_i32_i24_e32 v1, 0xe408, v36                          // 000000DF8CD8: 120248FF 0000E408
	v_or_b32_e32 v39, 0x64006400, v43                          // 000000DF8CE0: 384E56FF 64006400
	v_or_b32_e32 v50, 0x64006400, v50                          // 000000DF8CE8: 386464FF 64006400
	v_perm_b32 v43, v40, v44, 0xc050c01                        // 000000DF8CF0: D644002B 03FE5928 0C050C01
	v_dot2acc_f32_f16 v57, v35, v68                            // 000000DF8CFC: 04728923
	v_dot2acc_f32_f16 v33, v36, v42                            // 000000DF8D00: 04425524
	.long 0xcc0f4023                                           // 000000DF8D04: CC0F4023
	v_mul_i32_i24_e32 v1, 0xe408, v39                          // 000000DF8D08: 12024EFF 0000E408
	.long 0xcc0f4029                                           // 000000DF8D10: CC0F4029
	v_mul_i32_i24_e32 v1, 0xe408, v50                          // 000000DF8D14: 120264FF 0000E408
	v_or_b32_e32 v36, 0x64006400, v43                          // 000000DF8D1C: 384856FF 64006400
	v_perm_b32 v39, v40, v44, 0xc060c02                        // 000000DF8D24: D6440027 03FE5928 0C060C02
	v_perm_b32 v43, v58, v49, 0xc050c01                        // 000000DF8D30: D644002B 03FE633A 0C050C01
	s_waitcnt lgkmcnt(0)                                       // 000000DF8D3C: BF89FC07
	v_dot2acc_f32_f16 v57, v35, v53                            // 000000DF8D40: 04726B23
	v_lshrrev_b32_e32 v35, 4, v51                              // 000000DF8D44: 32466684
	v_dot2acc_f32_f16 v69, v41, v61                            // 000000DF8D48: 048A7B29
	.long 0xcc0f4024                                           // 000000DF8D4C: CC0F4024
	v_mul_i32_i24_e32 v1, 0xe408, v36                          // 000000DF8D50: 120248FF 0000E408
	v_or_b32_e32 v50, 0x64006400, v39                          // 000000DF8D58: 38644EFF 64006400
	v_perm_b32 v44, v40, v44, 0xc070c03                        // 000000DF8D60: D644002C 03FE5928 0C070C03
	v_and_b32_e32 v51, 0xf0f0f0f, v51                          // 000000DF8D6C: 366666FF 0F0F0F0F
	v_and_b32_e32 v35, 0xf0f0f0f, v35                          // 000000DF8D74: 364646FF 0F0F0F0F
	ds_load_b128 v[39:42], v88 offset:13088                    // 000000DF8D7C: DBFC3320 27000058
	v_or_b32_e32 v43, 0x64006400, v43                          // 000000DF8D84: 385656FF 64006400
	v_dot2acc_f32_f16 v57, v36, v54                            // 000000DF8D8C: 04726D24
	.long 0xcc0f4024                                           // 000000DF8D90: CC0F4024
	v_mul_i32_i24_e32 v1, 0xe408, v50                          // 000000DF8D94: 120264FF 0000E408
	v_or_b32_e32 v44, 0x64006400, v44                          // 000000DF8D9C: 385858FF 64006400
	v_perm_b32 v50, v35, v51, 0xc040c00                        // 000000DF8DA4: D6440032 03FE6723 0C040C00
	.long 0xcc0f402b                                           // 000000DF8DB0: CC0F402B
	v_mul_i32_i24_e32 v1, 0xe408, v43                          // 000000DF8DB4: 120256FF 0000E408
	v_perm_b32 v53, v58, v49, 0xc060c02                        // 000000DF8DBC: D6440035 03FE633A 0C060C02
	v_dot2acc_f32_f16 v57, v36, v55                            // 000000DF8DC8: 04726F24
	.long 0xcc0f4024                                           // 000000DF8DCC: CC0F4024
	v_mul_i32_i24_e32 v1, 0xe408, v44                          // 000000DF8DD0: 120258FF 0000E408
	v_or_b32_e32 v44, 0x64006400, v50                          // 000000DF8DD8: 385864FF 64006400
	v_perm_b32 v50, v35, v51, 0xc050c01                        // 000000DF8DE0: D6440032 03FE6723 0C050C01
	v_or_b32_e32 v53, 0x64006400, v53                          // 000000DF8DEC: 386A6AFF 64006400
	v_dot2acc_f32_f16 v69, v43, v62                            // 000000DF8DF4: 048A7D2B
	v_dot2acc_f32_f16 v57, v36, v56                            // 000000DF8DF8: 04727124
	.long 0xcc0f4024                                           // 000000DF8DFC: CC0F4024
	v_mul_i32_i24_e32 v1, 0xe408, v44                          // 000000DF8E00: 120258FF 0000E408
	v_or_b32_e32 v43, 0x64006400, v50                          // 000000DF8E08: 385664FF 64006400
	.long 0xcc0f402c                                           // 000000DF8E10: CC0F402C
	v_mul_i32_i24_e32 v1, 0xe408, v53                          // 000000DF8E14: 12026AFF 0000E408
	ds_load_b128 v[53:56], v88 offset:13104                    // 000000DF8E1C: DBFC3330 35000058
	v_fma_mix_f32 v5, v5, v33, v34 op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DF8E24: CC200805 0C8A4305
	s_waitcnt lgkmcnt(1)                                       // 000000DF8E2C: BF89FC17
	v_dot2acc_f32_f16 v57, v36, v39                            // 000000DF8E30: 04724F24
	.long 0xcc0f4024                                           // 000000DF8E34: CC0F4024
	v_mul_i32_i24_e32 v1, 0xe408, v43                          // 000000DF8E38: 120256FF 0000E408
	v_perm_b32 v39, v35, v51, 0xc060c02                        // 000000DF8E40: D6440027 03FE6723 0C060C02
	v_lshrrev_b32_e32 v33, 4, v45                              // 000000DF8E4C: 32425A84
	v_perm_b32 v49, v58, v49, 0xc070c03                        // 000000DF8E50: D6440031 03FE633A 0C070C03
	v_dot2acc_f32_f16 v69, v44, v63                            // 000000DF8E5C: 048A7F2C
	v_dot2acc_f32_f16 v57, v36, v40                            // 000000DF8E60: 04725124
	v_or_b32_e32 v39, 0x64006400, v39                          // 000000DF8E64: 384E4EFF 64006400
	v_perm_b32 v40, v35, v51, 0xc070c03                        // 000000DF8E6C: D6440028 03FE6723 0C070C03
	v_lshrrev_b32_e32 v44, 4, v52                              // 000000DF8E78: 32586884
	v_and_b32_e32 v45, 0xf0f0f0f, v45                          // 000000DF8E7C: 365A5AFF 0F0F0F0F
	v_and_b32_e32 v50, 0xf0f0f0f, v33                          // 000000DF8E84: 366442FF 0F0F0F0F
	ds_load_b128 v[33:36], v88 offset:13312                    // 000000DF8E8C: DBFC3400 21000058
	v_or_b32_e32 v43, 0x64006400, v49                          // 000000DF8E94: 385662FF 64006400
	v_and_b32_e32 v49, 0xf0f0f0f, v52                          // 000000DF8E9C: 366268FF 0F0F0F0F
	v_and_b32_e32 v44, 0xf0f0f0f, v44                          // 000000DF8EA4: 365858FF 0F0F0F0F
	.long 0xcc0f4027                                           // 000000DF8EAC: CC0F4027
	v_mul_i32_i24_e32 v1, 0xe408, v39                          // 000000DF8EB0: 12024EFF 0000E408
	v_or_b32_e32 v40, 0x64006400, v40                          // 000000DF8EB8: 385050FF 64006400
	v_perm_b32 v51, v50, v45, 0xc040c00                        // 000000DF8EC0: D6440033 03FE5B32 0C040C00
	.long 0xcc0f402b                                           // 000000DF8ECC: CC0F402B
	v_mul_i32_i24_e32 v1, 0xe408, v43                          // 000000DF8ED0: 120256FF 0000E408
	v_perm_b32 v52, v44, v49, 0xc040c00                        // 000000DF8ED8: D6440034 03FE632C 0C040C00
	v_dot2acc_f32_f16 v57, v39, v41                            // 000000DF8EE4: 04725327
	.long 0xcc0f4027                                           // 000000DF8EE8: CC0F4027
	v_mul_i32_i24_e32 v1, 0xe408, v40                          // 000000DF8EEC: 120250FF 0000E408
	v_or_b32_e32 v40, 0x64006400, v51                          // 000000DF8EF4: 385066FF 64006400
	v_dot2acc_f32_f16 v69, v43, v64                            // 000000DF8EFC: 048A812B
	v_or_b32_e32 v41, 0x64006400, v52                          // 000000DF8F00: 385268FF 64006400
	v_perm_b32 v43, v50, v45, 0xc050c01                        // 000000DF8F08: D644002B 03FE5B32 0C050C01
	v_mov_b32_e32 v52, 0                                       // 000000DF8F14: 7E680280
	.long 0xcc0f4033                                           // 000000DF8F18: CC0F4033
	v_mul_i32_i24_e32 v1, 0xe408, v40                          // 000000DF8F1C: 120250FF 0000E408
	v_dot2acc_f32_f16 v57, v39, v42                            // 000000DF8F24: 04725527
	.long 0xcc0f403a                                           // 000000DF8F28: CC0F403A
	v_mul_i32_i24_e32 v1, 0xe408, v41                          // 000000DF8F2C: 120252FF 0000E408
	v_or_b32_e32 v43, 0x64006400, v43                          // 000000DF8F34: 385656FF 64006400
	v_perm_b32 v59, v50, v45, 0xc060c02                        // 000000DF8F3C: D644003B 03FE5B32 0C060C02
	ds_load_b128 v[39:42], v88 offset:13328                    // 000000DF8F48: DBFC3410 27000058
	s_waitcnt lgkmcnt(1)                                       // 000000DF8F50: BF89FC17
	v_dot2acc_f32_f16 v52, v51, v33                            // 000000DF8F54: 04684333
	v_lshrrev_b32_e32 v33, 4, v46                              // 000000DF8F58: 32425C84
	.long 0xcc0f402b                                           // 000000DF8F5C: CC0F402B
	v_mul_i32_i24_e32 v1, 0xe408, v43                          // 000000DF8F60: 120256FF 0000E408
	v_or_b32_e32 v51, 0x64006400, v59                          // 000000DF8F68: 386676FF 64006400
	v_perm_b32 v45, v50, v45, 0xc070c03                        // 000000DF8F70: D644002D 03FE5B32 0C070C03
	v_and_b32_e32 v46, 0xf0f0f0f, v46                          // 000000DF8F7C: 365C5CFF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DF8F84: BF870214
	v_dual_dot2acc_f32_f16 v52, v43, v34 :: v_dual_and_b32 v33, 0xf0f0f0f, v33// 000000DF8F88: CB24452B 342042FF 0F0F0F0F
	.long 0xcc0f4022                                           // 000000DF8F94: CC0F4022
	v_mul_i32_i24_e32 v1, 0xe408, v51                          // 000000DF8F98: 120266FF 0000E408
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DF8FA0: BF870224
	v_or_b32_e32 v43, 0x64006400, v45                          // 000000DF8FA4: 38565AFF 64006400
	v_perm_b32 v50, v44, v49, 0xc050c01                        // 000000DF8FAC: D6440032 03FE632C 0C050C01
	v_perm_b32 v45, v33, v46, 0xc040c00                        // 000000DF8FB8: D644002D 03FE5D21 0C040C00
	v_dot2acc_f32_f16 v57, v58, v53                            // 000000DF8FC4: 04726B3A
	v_dot2acc_f32_f16 v52, v34, v35                            // 000000DF8FC8: 04684722
	.long 0xcc0f4022                                           // 000000DF8FCC: CC0F4022
	v_mul_i32_i24_e32 v1, 0xe408, v43                          // 000000DF8FD0: 120256FF 0000E408
	v_or_b32_e32 v50, 0x64006400, v50                          // 000000DF8FD8: 386464FF 64006400
	v_or_b32_e32 v35, 0x64006400, v45                          // 000000DF8FE0: 38465AFF 64006400
	v_perm_b32 v45, v33, v46, 0xc050c01                        // 000000DF8FE8: D644002D 03FE5D21 0C050C01
	v_fma_mix_f32 v5, v6, v69, v5 op_sel_hi:[1,0,0]            // 000000DF8FF4: CC200005 0C168B06
	v_dot2acc_f32_f16 v52, v34, v36                            // 000000DF8FFC: 04684922
	.long 0xcc0f402b                                           // 000000DF9000: CC0F402B
	v_mul_i32_i24_e32 v1, 0xe408, v50                          // 000000DF9004: 120264FF 0000E408
	.long 0xcc0f4022                                           // 000000DF900C: CC0F4022
	v_mul_i32_i24_e32 v1, 0xe408, v35                          // 000000DF9010: 120246FF 0000E408
	v_or_b32_e32 v35, 0x64006400, v45                          // 000000DF9018: 38465AFF 64006400
	v_perm_b32 v36, v33, v46, 0xc060c02                        // 000000DF9020: D6440024 03FE5D21 0C060C02
	v_perm_b32 v46, v33, v46, 0xc070c03                        // 000000DF902C: D644002E 03FE5D21 0C070C03
	s_waitcnt lgkmcnt(0)                                       // 000000DF9038: BF89FC07
	v_dual_dot2acc_f32_f16 v57, v43, v54 :: v_dual_dot2acc_f32_f16 v52, v34, v39// 000000DF903C: CB186D2B 39344F22
	v_lshrrev_b32_e32 v34, 4, v47                              // 000000DF9044: 32445E84
	v_perm_b32 v43, v44, v49, 0xc060c02                        // 000000DF9048: D644002B 03FE632C 0C060C02
	.long 0xcc0f4027                                           // 000000DF9054: CC0F4027
	v_mul_i32_i24_e32 v1, 0xe408, v35                          // 000000DF9058: 120246FF 0000E408
	v_or_b32_e32 v45, 0x64006400, v36                          // 000000DF9060: 385A48FF 64006400
	v_and_b32_e32 v47, 0xf0f0f0f, v47                          // 000000DF9068: 365E5EFF 0F0F0F0F
	v_and_b32_e32 v50, 0xf0f0f0f, v34                          // 000000DF9070: 366444FF 0F0F0F0F
	ds_load_b128 v[33:36], v88 offset:13344                    // 000000DF9078: DBFC3420 21000058
	v_or_b32_e32 v43, 0x64006400, v43                          // 000000DF9080: 385656FF 64006400
	v_dot2acc_f32_f16 v52, v39, v40                            // 000000DF9088: 04685127
	.long 0xcc0f4027                                           // 000000DF908C: CC0F4027
	v_mul_i32_i24_e32 v1, 0xe408, v45                          // 000000DF9090: 12025AFF 0000E408
	v_or_b32_e32 v40, 0x64006400, v46                          // 000000DF9098: 38505CFF 64006400
	v_perm_b32 v45, v50, v47, 0xc040c00                        // 000000DF90A0: D644002D 03FE5F32 0C040C00
	v_perm_b32 v44, v44, v49, 0xc070c03                        // 000000DF90AC: D644002C 03FE632C 0C070C03
	.long 0xcc0f402b                                           // 000000DF90B8: CC0F402B
	v_mul_i32_i24_e32 v1, 0xe408, v43                          // 000000DF90BC: 120256FF 0000E408
	v_dot2acc_f32_f16 v52, v39, v41                            // 000000DF90C4: 04685327
	.long 0xcc0f4027                                           // 000000DF90C8: CC0F4027
	v_mul_i32_i24_e32 v1, 0xe408, v40                          // 000000DF90CC: 120250FF 0000E408
	v_or_b32_e32 v40, 0x64006400, v45                          // 000000DF90D4: 38505AFF 64006400
	v_or_b32_e32 v41, 0x64006400, v44                          // 000000DF90DC: 385258FF 64006400
	v_perm_b32 v44, v50, v47, 0xc050c01                        // 000000DF90E4: D644002C 03FE5F32 0C050C01
	v_dot2acc_f32_f16 v57, v43, v55                            // 000000DF90F0: 04726F2B
	v_dot2acc_f32_f16 v52, v39, v42                            // 000000DF90F4: 04685527
	.long 0xcc0f402b                                           // 000000DF90F8: CC0F402B
	v_mul_i32_i24_e32 v1, 0xe408, v40                          // 000000DF90FC: 120250FF 0000E408
	.long 0xcc0f4031                                           // 000000DF9104: CC0F4031
	v_mul_i32_i24_e32 v1, 0xe408, v41                          // 000000DF9108: 120252FF 0000E408
	v_or_b32_e32 v44, 0x64006400, v44                          // 000000DF9110: 385858FF 64006400
	v_perm_b32 v45, v50, v47, 0xc060c02                        // 000000DF9118: D644002D 03FE5F32 0C060C02
	ds_load_b128 v[39:42], v88 offset:13360                    // 000000DF9124: DBFC3430 27000058
	s_waitcnt lgkmcnt(1)                                       // 000000DF912C: BF89FC17
	v_dot2acc_f32_f16 v52, v43, v33                            // 000000DF9130: 0468432B
	v_lshrrev_b32_e32 v33, 4, v29                              // 000000DF9134: 32423A84
	.long 0xcc0f4033                                           // 000000DF9138: CC0F4033
	v_mul_i32_i24_e32 v1, 0xe408, v44                          // 000000DF913C: 120258FF 0000E408
	v_or_b32_e32 v53, 0x64006400, v45                          // 000000DF9144: 386A5AFF 64006400
	v_and_b32_e32 v29, 0xf0f0f0f, v29                          // 000000DF914C: 363A3AFF 0F0F0F0F
	ds_load_b128 v[43:46], v88 offset:13568                    // 000000DF9154: DBFC3500 2B000058
	v_and_b32_e32 v54, 0xf0f0f0f, v33                          // 000000DF915C: 366C42FF 0F0F0F0F
	v_perm_b32 v47, v50, v47, 0xc070c03                        // 000000DF9164: D644002F 03FE5F32 0C070C03
	v_dual_dot2acc_f32_f16 v57, v49, v56 :: v_dual_dot2acc_f32_f16 v52, v51, v34// 000000DF9170: CB187131 39344533
	.long 0xcc0f4031                                           // 000000DF9178: CC0F4031
	v_mul_i32_i24_e32 v1, 0xe408, v53                          // 000000DF917C: 12026AFF 0000E408
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DF9184: BF870214
	v_perm_b32 v50, v54, v29, 0xc040c00                        // 000000DF9188: D6440032 03FE3B36 0C040C00
	v_or_b32_e32 v47, 0x64006400, v47                          // 000000DF9194: 385E5EFF 64006400
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DF919C: BF870004
	v_fma_mix_f32 v5, v6, v57, v5 op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DF91A0: CC200805 0C167306
	global_load_b64 v[33:34], v[37:38], off offset:32          // 000000DF91A8: DC560020 217C0025
	v_lshrrev_b32_e32 v37, 4, v48                              // 000000DF91B0: 324A6084
	v_or_b32_e32 v6, 0x64006400, v50                           // 000000DF91B4: 380C64FF 64006400
	v_perm_b32 v38, v54, v29, 0xc050c01                        // 000000DF91BC: D6440026 03FE3B36 0C050C01
	v_dual_mov_b32 v53, 0 :: v_dual_dot2acc_f32_f16 v52, v49, v35// 000000DF91C8: CA180080 35344731
	.long 0xcc0f4023                                           // 000000DF91D0: CC0F4023
	v_mul_i32_i24_e32 v1, 0xe408, v47                          // 000000DF91D4: 12025EFF 0000E408
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DF91DC: BF870004
	.long 0xcc0f4006                                           // 000000DF91E0: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DF91E4: 12020CFF 0000E408
	v_and_b32_e32 v51, 0xf0f0f0f, v48                          // 000000DF91EC: 366660FF 0F0F0F0F
	v_and_b32_e32 v55, 0xf0f0f0f, v37                          // 000000DF91F4: 366E4AFF 0F0F0F0F
	v_or_b32_e32 v37, 0x64006400, v38                          // 000000DF91FC: 384A4CFF 64006400
	v_perm_b32 v38, v54, v29, 0xc060c02                        // 000000DF9204: D6440026 03FE3B36 0C060C02
	ds_load_b128 v[47:50], v88 offset:13584                    // 000000DF9210: DBFC3510 2F000058
	s_waitcnt lgkmcnt(1)                                       // 000000DF9218: BF89FC17
	v_dot2acc_f32_f16 v53, v6, v43                             // 000000DF921C: 046A5706
	v_lshrrev_b32_e32 v6, 4, v30                               // 000000DF9220: 320C3C84
	.long 0xcc0f4025                                           // 000000DF9224: CC0F4025
	v_mul_i32_i24_e32 v1, 0xe408, v37                          // 000000DF9228: 12024AFF 0000E408
	v_or_b32_e32 v38, 0x64006400, v38                          // 000000DF9230: 384C4CFF 64006400
	v_perm_b32 v29, v54, v29, 0xc070c03                        // 000000DF9238: D644001D 03FE3B36 0C070C03
	v_and_b32_e32 v30, 0xf0f0f0f, v30                          // 000000DF9244: 363C3CFF 0F0F0F0F
	v_and_b32_e32 v6, 0xf0f0f0f, v6                            // 000000DF924C: 360C0CFF 0F0F0F0F
	v_perm_b32 v43, v55, v51, 0xc040c00                        // 000000DF9254: D644002B 03FE6737 0C040C00
	v_dot2acc_f32_f16 v53, v37, v44                            // 000000DF9260: 046A5925
	.long 0xcc0f4025                                           // 000000DF9264: CC0F4025
	v_mul_i32_i24_e32 v1, 0xe408, v38                          // 000000DF9268: 12024CFF 0000E408
	v_or_b32_e32 v29, 0x64006400, v29                          // 000000DF9270: 383A3AFF 64006400
	v_perm_b32 v38, v6, v30, 0xc040c00                         // 000000DF9278: D6440026 03FE3D06 0C040C00
	v_or_b32_e32 v43, 0x64006400, v43                          // 000000DF9284: 385656FF 64006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DF928C: BF870214
	v_dual_dot2acc_f32_f16 v52, v35, v36 :: v_dual_dot2acc_f32_f16 v53, v37, v45// 000000DF9290: CB184923 34345B25
	.long 0xcc0f401d                                           // 000000DF9298: CC0F401D
	v_mul_i32_i24_e32 v1, 0xe408, v29                          // 000000DF929C: 12023AFF 0000E408
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DF92A4: BF870214
	v_or_b32_e32 v35, 0x64006400, v38                          // 000000DF92A8: 38464CFF 64006400
	.long 0xcc0f4024                                           // 000000DF92B0: CC0F4024
	v_mul_i32_i24_e32 v1, 0xe408, v43                          // 000000DF92B4: 120256FF 0000E408
	v_perm_b32 v37, v6, v30, 0xc050c01                         // 000000DF92BC: D6440025 03FE3D06 0C050C01
	v_perm_b32 v38, v55, v51, 0xc050c01                        // 000000DF92C8: D6440026 03FE6737 0C050C01
	v_dot2acc_f32_f16 v53, v29, v46                            // 000000DF92D4: 046A5D1D
	.long 0xcc0f401d                                           // 000000DF92D8: CC0F401D
	v_mul_i32_i24_e32 v1, 0xe408, v35                          // 000000DF92DC: 120246FF 0000E408
	v_dot2acc_f32_f16 v52, v36, v39                            // 000000DF92E4: 04684F24
	v_or_b32_e32 v35, 0x64006400, v37                          // 000000DF92E8: 38464AFF 64006400
	v_perm_b32 v36, v6, v30, 0xc060c02                         // 000000DF92F0: D6440024 03FE3D06 0C060C02
	v_or_b32_e32 v39, 0x64006400, v38                          // 000000DF92FC: 384E4CFF 64006400
	s_waitcnt lgkmcnt(0)                                       // 000000DF9304: BF89FC07
	v_dot2acc_f32_f16 v53, v29, v47                            // 000000DF9308: 046A5F1D
	v_lshrrev_b32_e32 v29, 4, v31                              // 000000DF930C: 323A3E84
	.long 0xcc0f402b                                           // 000000DF9310: CC0F402B
	v_mul_i32_i24_e32 v1, 0xe408, v35                          // 000000DF9314: 120246FF 0000E408
	v_or_b32_e32 v44, 0x64006400, v36                          // 000000DF931C: 385848FF 64006400
	v_perm_b32 v6, v6, v30, 0xc070c03                          // 000000DF9324: D6440006 03FE3D06 0C070C03
	v_and_b32_e32 v30, 0xf0f0f0f, v31                          // 000000DF9330: 363C3EFF 0F0F0F0F
	v_and_b32_e32 v29, 0xf0f0f0f, v29                          // 000000DF9338: 363A3AFF 0F0F0F0F
	ds_load_b128 v[35:38], v88 offset:13600                    // 000000DF9340: DBFC3520 23000058
	v_dot2acc_f32_f16 v53, v43, v48                            // 000000DF9348: 046A612B
	.long 0xcc0f402b                                           // 000000DF934C: CC0F402B
	v_mul_i32_i24_e32 v1, 0xe408, v44                          // 000000DF9350: 120258FF 0000E408
	v_or_b32_e32 v6, 0x64006400, v6                            // 000000DF9358: 380C0CFF 64006400
	v_perm_b32 v44, v29, v30, 0xc040c00                        // 000000DF9360: D644002C 03FE3D1D 0C040C00
	.long 0xcc0f4027                                           // 000000DF936C: CC0F4027
	v_mul_i32_i24_e32 v1, 0xe408, v39                          // 000000DF9370: 12024EFF 0000E408
	v_perm_b32 v47, v29, v30, 0xc060c02                        // 000000DF9378: D644002F 03FE3D1D 0C060C02
	v_dot2acc_f32_f16 v53, v43, v49                            // 000000DF9384: 046A632B
	.long 0xcc0f4006                                           // 000000DF9388: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DF938C: 12020CFF 0000E408
	v_or_b32_e32 v43, 0x64006400, v44                          // 000000DF9394: 385658FF 64006400
	v_dot2acc_f32_f16 v52, v39, v40                            // 000000DF939C: 04685127
	v_perm_b32 v39, v29, v30, 0xc050c01                        // 000000DF93A0: D6440027 03FE3D1D 0C050C01
	v_perm_b32 v31, v55, v51, 0xc060c02                        // 000000DF93AC: D644001F 03FE6737 0C060C02
	v_dot2acc_f32_f16 v53, v6, v50                             // 000000DF93B8: 046A6506
	.long 0xcc0f4006                                           // 000000DF93BC: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v43                          // 000000DF93C0: 120256FF 0000E408
	ds_load_b128 v[43:46], v88 offset:13616                    // 000000DF93C8: DBFC3530 2B000058
	v_or_b32_e32 v39, 0x64006400, v39                          // 000000DF93D0: 384E4EFF 64006400
	v_perm_b32 v40, v55, v51, 0xc070c03                        // 000000DF93D8: D6440028 03FE6737 0C070C03
	v_or_b32_e32 v31, 0x64006400, v31                          // 000000DF93E4: 383E3EFF 64006400
	v_perm_b32 v29, v29, v30, 0xc070c03                        // 000000DF93EC: D644001D 03FE3D1D 0C070C03
	s_waitcnt lgkmcnt(1)                                       // 000000DF93F8: BF89FC17
	v_dot2acc_f32_f16 v53, v6, v35                             // 000000DF93FC: 046A4706
	s_waitcnt vmcnt(4)                                         // 000000DF9400: BF8913F7
	v_lshrrev_b32_e32 v6, 4, v25                               // 000000DF9404: 320C3284
	.long 0xcc0f4023                                           // 000000DF9408: CC0F4023
	v_mul_i32_i24_e32 v1, 0xe408, v39                          // 000000DF940C: 12024EFF 0000E408
	v_or_b32_e32 v39, 0x64006400, v47                          // 000000DF9414: 384E5EFF 64006400
	v_and_b32_e32 v25, 0xf0f0f0f, v25                          // 000000DF941C: 363232FF 0F0F0F0F
	ds_load_b128 v[47:50], v88 offset:13824                    // 000000DF9424: DBFC3600 2F000058
	v_and_b32_e32 v6, 0xf0f0f0f, v6                            // 000000DF942C: 360C0CFF 0F0F0F0F
	v_or_b32_e32 v30, 0x64006400, v40                          // 000000DF9434: 383C50FF 64006400
	v_dot2acc_f32_f16 v53, v35, v36                            // 000000DF943C: 046A4923
	.long 0xcc0f401f                                           // 000000DF9440: CC0F401F
	v_mul_i32_i24_e32 v1, 0xe408, v31                          // 000000DF9444: 12023EFF 0000E408
	.long 0xcc0f4023                                           // 000000DF944C: CC0F4023
	v_mul_i32_i24_e32 v1, 0xe408, v39                          // 000000DF9450: 12024EFF 0000E408
	v_perm_b32 v36, v6, v25, 0xc040c00                         // 000000DF9458: D6440024 03FE3306 0C040C00
	v_or_b32_e32 v29, 0x64006400, v29                          // 000000DF9464: 383A3AFF 64006400
	.long 0xcc0f4027                                           // 000000DF946C: CC0F4027
	v_mul_i32_i24_e32 v1, 0xe408, v30                          // 000000DF9470: 12023CFF 0000E408
	v_dot2acc_f32_f16 v52, v31, v41                            // 000000DF9478: 0468531F
	v_dot2acc_f32_f16 v53, v35, v37                            // 000000DF947C: 046A4B23
	v_or_b32_e32 v30, 0x64006400, v36                          // 000000DF9480: 383C48FF 64006400
	.long 0xcc0f4023                                           // 000000DF9488: CC0F4023
	v_mul_i32_i24_e32 v1, 0xe408, v29                          // 000000DF948C: 12023AFF 0000E408
	v_lshrrev_b32_e32 v29, 4, v32                              // 000000DF9494: 323A4084
	v_perm_b32 v31, v6, v25, 0xc050c01                         // 000000DF9498: D644001F 03FE3306 0C050C01
	v_mov_b32_e32 v51, 0                                       // 000000DF94A4: 7E660280
	.long 0xcc0f4024                                           // 000000DF94A8: CC0F4024
	v_mul_i32_i24_e32 v1, 0xe408, v30                          // 000000DF94AC: 12023CFF 0000E408
	v_and_b32_e32 v40, 0xf0f0f0f, v32                          // 000000DF94B4: 365040FF 0F0F0F0F
	v_and_b32_e32 v41, 0xf0f0f0f, v29                          // 000000DF94BC: 36523AFF 0F0F0F0F
	v_or_b32_e32 v37, 0x64006400, v31                          // 000000DF94C4: 384A3EFF 64006400
	v_perm_b32 v54, v6, v25, 0xc060c02                         // 000000DF94CC: D6440036 03FE3306 0C060C02
	ds_load_b128 v[29:32], v88 offset:13840                    // 000000DF94D8: DBFC3610 1D000058
	s_waitcnt lgkmcnt(1)                                       // 000000DF94E0: BF89FC17
	v_dot2acc_f32_f16 v51, v36, v47                            // 000000DF94E4: 04665F24
	v_lshrrev_b32_e32 v36, 4, v26                              // 000000DF94E8: 32483484
	.long 0xcc0f4025                                           // 000000DF94EC: CC0F4025
	v_mul_i32_i24_e32 v1, 0xe408, v37                          // 000000DF94F0: 12024AFF 0000E408
	v_or_b32_e32 v47, 0x64006400, v54                          // 000000DF94F8: 385E6CFF 64006400
	v_perm_b32 v6, v6, v25, 0xc070c03                          // 000000DF9500: D6440006 03FE3306 0C070C03
	v_and_b32_e32 v25, 0xf0f0f0f, v26                          // 000000DF950C: 363234FF 0F0F0F0F
	v_and_b32_e32 v26, 0xf0f0f0f, v36                          // 000000DF9514: 363448FF 0F0F0F0F
	v_perm_b32 v36, v41, v40, 0xc040c00                        // 000000DF951C: D6440024 03FE5129 0C040C00
	v_dot2acc_f32_f16 v51, v37, v48                            // 000000DF9528: 04666125
	.long 0xcc0f4025                                           // 000000DF952C: CC0F4025
	v_mul_i32_i24_e32 v1, 0xe408, v47                          // 000000DF9530: 12025EFF 0000E408
	v_or_b32_e32 v6, 0x64006400, v6                            // 000000DF9538: 380C0CFF 64006400
	v_perm_b32 v47, v26, v25, 0xc040c00                        // 000000DF9540: D644002F 03FE331A 0C040C00
	v_or_b32_e32 v36, 0x64006400, v36                          // 000000DF954C: 384848FF 64006400
	v_dot2acc_f32_f16 v53, v35, v38                            // 000000DF9554: 046A4D23
	v_dot2acc_f32_f16 v51, v37, v49                            // 000000DF9558: 04666325
	.long 0xcc0f4006                                           // 000000DF955C: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DF9560: 12020CFF 0000E408
	v_or_b32_e32 v35, 0x64006400, v47                          // 000000DF9568: 38465EFF 64006400
	.long 0xcc0f4024                                           // 000000DF9570: CC0F4024
	v_mul_i32_i24_e32 v1, 0xe408, v36                          // 000000DF9574: 120248FF 0000E408
	v_perm_b32 v37, v26, v25, 0xc050c01                        // 000000DF957C: D6440025 03FE331A 0C050C01
	v_dot2acc_f32_f16 v52, v39, v42                            // 000000DF9588: 04685527
	v_dot2acc_f32_f16 v51, v6, v50                             // 000000DF958C: 04666506
	.long 0xcc0f4006                                           // 000000DF9590: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v35                          // 000000DF9594: 120246FF 0000E408
	v_dot2acc_f32_f16 v53, v36, v43                            // 000000DF959C: 046A5724
	v_or_b32_e32 v35, 0x64006400, v37                          // 000000DF95A0: 38464AFF 64006400
	v_perm_b32 v36, v26, v25, 0xc060c02                        // 000000DF95A8: D6440024 03FE331A 0C060C02
	v_perm_b32 v39, v41, v40, 0xc050c01                        // 000000DF95B4: D6440027 03FE5129 0C050C01
	s_waitcnt lgkmcnt(0)                                       // 000000DF95C0: BF89FC07
	v_dot2acc_f32_f16 v51, v6, v29                             // 000000DF95C4: 04663B06
	v_lshrrev_b32_e32 v6, 4, v27                               // 000000DF95C8: 320C3684
	.long 0xcc0f401d                                           // 000000DF95CC: CC0F401D
	v_mul_i32_i24_e32 v1, 0xe408, v35                          // 000000DF95D0: 120246FF 0000E408
	v_or_b32_e32 v42, 0x64006400, v36                          // 000000DF95D8: 385448FF 64006400
	v_perm_b32 v25, v26, v25, 0xc070c03                        // 000000DF95E0: D6440019 03FE331A 0C070C03
	v_and_b32_e32 v26, 0xf0f0f0f, v27                          // 000000DF95EC: 363436FF 0F0F0F0F
	v_and_b32_e32 v6, 0xf0f0f0f, v6                            // 000000DF95F4: 360C0CFF 0F0F0F0F
	ds_load_b128 v[35:38], v88 offset:13856                    // 000000DF95FC: DBFC3620 23000058
	v_or_b32_e32 v27, 0x64006400, v39                          // 000000DF9604: 38364EFF 64006400
	v_dot2acc_f32_f16 v51, v29, v30                            // 000000DF960C: 04663D1D
	.long 0xcc0f401d                                           // 000000DF9610: CC0F401D
	v_mul_i32_i24_e32 v1, 0xe408, v42                          // 000000DF9614: 120254FF 0000E408
	v_or_b32_e32 v25, 0x64006400, v25                          // 000000DF961C: 383232FF 64006400
	v_perm_b32 v30, v6, v26, 0xc040c00                         // 000000DF9624: D644001E 03FE3506 0C040C00
	.long 0xcc0f401b                                           // 000000DF9630: CC0F401B
	v_mul_i32_i24_e32 v1, 0xe408, v27                          // 000000DF9634: 120236FF 0000E408
	v_perm_b32 v39, v41, v40, 0xc060c02                        // 000000DF963C: D6440027 03FE5129 0C060C02
	v_dot2acc_f32_f16 v51, v29, v31                            // 000000DF9648: 04663F1D
	.long 0xcc0f4019                                           // 000000DF964C: CC0F4019
	v_mul_i32_i24_e32 v1, 0xe408, v25                          // 000000DF9650: 120232FF 0000E408
	v_or_b32_e32 v29, 0x64006400, v30                          // 000000DF9658: 383A3CFF 64006400
	v_perm_b32 v30, v6, v26, 0xc050c01                         // 000000DF9660: D644001E 03FE3506 0C050C01
	v_or_b32_e32 v31, 0x64006400, v39                          // 000000DF966C: 383E4EFF 64006400
	v_dot2acc_f32_f16 v53, v27, v44                            // 000000DF9674: 046A591B
	v_dot2acc_f32_f16 v51, v25, v32                            // 000000DF9678: 04664119
	.long 0xcc0f4019                                           // 000000DF967C: CC0F4019
	v_mul_i32_i24_e32 v1, 0xe408, v29                          // 000000DF9680: 12023AFF 0000E408
	v_or_b32_e32 v27, 0x64006400, v30                          // 000000DF9688: 38363CFF 64006400
	.long 0xcc0f4027                                           // 000000DF9690: CC0F4027
	v_mul_i32_i24_e32 v1, 0xe408, v31                          // 000000DF9694: 12023EFF 0000E408
	ds_load_b128 v[29:32], v88 offset:13872                    // 000000DF969C: DBFC3630 1D000058
	v_perm_b32 v40, v41, v40, 0xc070c03                        // 000000DF96A4: D6440028 03FE5129 0C070C03
	s_waitcnt lgkmcnt(1)                                       // 000000DF96B0: BF89FC17
	v_dot2acc_f32_f16 v51, v25, v35                            // 000000DF96B4: 04664719
	.long 0xcc0f4019                                           // 000000DF96B8: CC0F4019
	v_mul_i32_i24_e32 v1, 0xe408, v27                          // 000000DF96BC: 120236FF 0000E408
	v_perm_b32 v27, v6, v26, 0xc060c02                         // 000000DF96C4: D644001B 03FE3506 0C060C02
	v_dot2acc_f32_f16 v53, v39, v45                            // 000000DF96D0: 046A5B27
	v_or_b32_e32 v35, 0x64006400, v40                          // 000000DF96D4: 384650FF 64006400
	v_perm_b32 v6, v6, v26, 0xc070c03                          // 000000DF96DC: D6440006 03FE3506 0C070C03
	v_dot2acc_f32_f16 v51, v25, v36                            // 000000DF96E8: 04664919
	s_waitcnt vmcnt(3)                                         // 000000DF96EC: BF890FF7
	v_lshrrev_b32_e32 v25, 4, v21                              // 000000DF96F0: 32322A84
	v_or_b32_e32 v36, 0x64006400, v27                          // 000000DF96F4: 384836FF 64006400
	v_lshrrev_b32_e32 v39, 4, v28                              // 000000DF96FC: 324E3884
	v_and_b32_e32 v40, 0xf0f0f0f, v28                          // 000000DF9700: 365038FF 0F0F0F0F
	v_and_b32_e32 v21, 0xf0f0f0f, v21                          // 000000DF9708: 362A2AFF 0F0F0F0F
	v_and_b32_e32 v41, 0xf0f0f0f, v25                          // 000000DF9710: 365232FF 0F0F0F0F
	ds_load_b128 v[25:28], v88 offset:14080                    // 000000DF9718: DBFC3700 19000058
	v_and_b32_e32 v39, 0xf0f0f0f, v39                          // 000000DF9720: 364E4EFF 0F0F0F0F
	.long 0xcc0f4024                                           // 000000DF9728: CC0F4024
	v_mul_i32_i24_e32 v1, 0xe408, v36                          // 000000DF972C: 120248FF 0000E408
	v_or_b32_e32 v6, 0x64006400, v6                            // 000000DF9734: 380C0CFF 64006400
	v_perm_b32 v42, v41, v21, 0xc040c00                        // 000000DF973C: D644002A 03FE2B29 0C040C00
	.long 0xcc0f4023                                           // 000000DF9748: CC0F4023
	v_mul_i32_i24_e32 v1, 0xe408, v35                          // 000000DF974C: 120246FF 0000E408
	v_perm_b32 v43, v39, v40, 0xc040c00                        // 000000DF9754: D644002B 03FE5127 0C040C00
	v_dot2acc_f32_f16 v51, v36, v37                            // 000000DF9760: 04664B24
	.long 0xcc0f4006                                           // 000000DF9764: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DF9768: 12020CFF 0000E408
	v_or_b32_e32 v36, 0x64006400, v42                          // 000000DF9770: 384854FF 64006400
	v_dot2acc_f32_f16 v53, v35, v46                            // 000000DF9778: 046A5D23
	v_or_b32_e32 v35, 0x64006400, v43                          // 000000DF977C: 384656FF 64006400
	v_perm_b32 v37, v41, v21, 0xc050c01                        // 000000DF9784: D6440025 03FE2B29 0C050C01
	v_dot2acc_f32_f16 v51, v6, v38                             // 000000DF9790: 04664D06
	.long 0xcc0f4006                                           // 000000DF9794: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v36                          // 000000DF9798: 120248FF 0000E408
	v_mov_b32_e32 v43, 0                                       // 000000DF97A0: 7E560280
	.long 0xcc0f402a                                           // 000000DF97A4: CC0F402A
	v_mul_i32_i24_e32 v1, 0xe408, v35                          // 000000DF97A8: 120246FF 0000E408
	v_or_b32_e32 v44, 0x64006400, v37                          // 000000DF97B0: 38584AFF 64006400
	v_perm_b32 v45, v41, v21, 0xc060c02                        // 000000DF97B8: D644002D 03FE2B29 0C060C02
	ds_load_b128 v[35:38], v88 offset:14096                    // 000000DF97C4: DBFC3710 23000058
	s_waitcnt lgkmcnt(1)                                       // 000000DF97CC: BF89FC17
	v_dot2acc_f32_f16 v43, v6, v25                             // 000000DF97D0: 04563306
	v_lshrrev_b32_e32 v6, 4, v22                               // 000000DF97D4: 320C2C84
	.long 0xcc0f4019                                           // 000000DF97D8: CC0F4019
	v_mul_i32_i24_e32 v1, 0xe408, v44                          // 000000DF97DC: 120258FF 0000E408
	v_or_b32_e32 v44, 0x64006400, v45                          // 000000DF97E4: 38585AFF 64006400
	v_perm_b32 v21, v41, v21, 0xc070c03                        // 000000DF97EC: D6440015 03FE2B29 0C070C03
	v_and_b32_e32 v22, 0xf0f0f0f, v22                          // 000000DF97F8: 362C2CFF 0F0F0F0F
	v_and_b32_e32 v6, 0xf0f0f0f, v6                            // 000000DF9800: 360C0CFF 0F0F0F0F
	v_dot2acc_f32_f16 v43, v25, v26                            // 000000DF9808: 04563519
	.long 0xcc0f4019                                           // 000000DF980C: CC0F4019
	v_mul_i32_i24_e32 v1, 0xe408, v44                          // 000000DF9810: 120258FF 0000E408
	v_or_b32_e32 v21, 0x64006400, v21                          // 000000DF9818: 382A2AFF 64006400
	v_fma_mix_f32 v5, v7, v52, v5 op_sel_hi:[1,0,0]            // 000000DF9820: CC200005 0C166907
	v_perm_b32 v26, v6, v22, 0xc040c00                         // 000000DF9828: D644001A 03FE2D06 0C040C00
	v_perm_b32 v41, v39, v40, 0xc050c01                        // 000000DF9834: D6440029 03FE5127 0C050C01
	v_dot2acc_f32_f16 v43, v25, v27                            // 000000DF9840: 04563719
	.long 0xcc0f4015                                           // 000000DF9844: CC0F4015
	v_mul_i32_i24_e32 v1, 0xe408, v21                          // 000000DF9848: 12022AFF 0000E408
	v_perm_b32 v27, v6, v22, 0xc050c01                         // 000000DF9850: D644001B 03FE2D06 0C050C01
	v_or_b32_e32 v25, 0x64006400, v26                          // 000000DF985C: 383234FF 64006400
	v_or_b32_e32 v41, 0x64006400, v41                          // 000000DF9864: 385252FF 64006400
	v_fma_mix_f32 v7, v7, v53, v5 op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DF986C: CC200807 0C166B07
	v_dot2acc_f32_f16 v43, v21, v28                            // 000000DF9874: 04563915
	v_dot2acc_f32_f16 v51, v42, v29                            // 000000DF9878: 04663B2A
	.long 0xcc0f4005                                           // 000000DF987C: CC0F4005
	v_mul_i32_i24_e32 v1, 0xe408, v25                          // 000000DF9880: 120232FF 0000E408
	.long 0xcc0f401a                                           // 000000DF9888: CC0F401A
	v_mul_i32_i24_e32 v1, 0xe408, v41                          // 000000DF988C: 120252FF 0000E408
	v_or_b32_e32 v21, 0x64006400, v27                          // 000000DF9894: 382A36FF 64006400
	v_perm_b32 v25, v6, v22, 0xc060c02                         // 000000DF989C: D6440019 03FE2D06 0C060C02
	v_perm_b32 v29, v39, v40, 0xc060c02                        // 000000DF98A8: D644001D 03FE5127 0C060C02
	s_waitcnt lgkmcnt(0)                                       // 000000DF98B4: BF89FC07
	v_dot2acc_f32_f16 v43, v5, v35                             // 000000DF98B8: 04564705
	v_lshrrev_b32_e32 v5, 4, v23                               // 000000DF98BC: 320A2E84
	v_dot2acc_f32_f16 v51, v26, v30                            // 000000DF98C0: 04663D1A
	.long 0xcc0f4015                                           // 000000DF98C4: CC0F4015
	v_mul_i32_i24_e32 v1, 0xe408, v21                          // 000000DF98C8: 12022AFF 0000E408
	v_or_b32_e32 v30, 0x64006400, v25                          // 000000DF98D0: 383C32FF 64006400
	v_perm_b32 v6, v6, v22, 0xc070c03                          // 000000DF98D8: D6440006 03FE2D06 0C070C03
	v_and_b32_e32 v22, 0xf0f0f0f, v23                          // 000000DF98E4: 362C2EFF 0F0F0F0F
	v_and_b32_e32 v5, 0xf0f0f0f, v5                            // 000000DF98EC: 360A0AFF 0F0F0F0F
	ds_load_b128 v[25:28], v88 offset:14112                    // 000000DF98F4: DBFC3720 19000058
	v_or_b32_e32 v23, 0x64006400, v29                          // 000000DF98FC: 382E3AFF 64006400
	v_dot2acc_f32_f16 v43, v21, v36                            // 000000DF9904: 04564915
	.long 0xcc0f4015                                           // 000000DF9908: CC0F4015
	v_mul_i32_i24_e32 v1, 0xe408, v30                          // 000000DF990C: 12023CFF 0000E408
	v_or_b32_e32 v6, 0x64006400, v6                            // 000000DF9914: 380C0CFF 64006400
	v_perm_b32 v29, v5, v22, 0xc040c00                         // 000000DF991C: D644001D 03FE2D05 0C040C00
	v_perm_b32 v30, v39, v40, 0xc070c03                        // 000000DF9928: D644001E 03FE5127 0C070C03
	.long 0xcc0f4017                                           // 000000DF9934: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v23                          // 000000DF9938: 12022EFF 0000E408
	v_dot2acc_f32_f16 v43, v21, v37                            // 000000DF9940: 04564B15
	.long 0xcc0f4006                                           // 000000DF9944: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DF9948: 12020CFF 0000E408
	v_or_b32_e32 v21, 0x64006400, v29                          // 000000DF9950: 382A3AFF 64006400
	v_or_b32_e32 v29, 0x64006400, v30                          // 000000DF9958: 383A3CFF 64006400
	v_perm_b32 v30, v5, v22, 0xc050c01                         // 000000DF9960: D644001E 03FE2D05 0C050C01
	v_dot2acc_f32_f16 v51, v23, v31                            // 000000DF996C: 04663F17
	v_dot2acc_f32_f16 v43, v6, v38                             // 000000DF9970: 04564D06
	.long 0xcc0f4006                                           // 000000DF9974: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v21                          // 000000DF9978: 12022AFF 0000E408
	.long 0xcc0f4015                                           // 000000DF9980: CC0F4015
	v_mul_i32_i24_e32 v1, 0xe408, v29                          // 000000DF9984: 12023AFF 0000E408
	v_or_b32_e32 v23, 0x64006400, v30                          // 000000DF998C: 382E3CFF 64006400
	v_perm_b32 v29, v5, v22, 0xc060c02                         // 000000DF9994: D644001D 03FE2D05 0C060C02
	ds_load_b128 v[35:38], v88 offset:14128                    // 000000DF99A0: DBFC3730 23000058
	s_waitcnt lgkmcnt(1)                                       // 000000DF99A8: BF89FC17
	v_dot2acc_f32_f16 v43, v6, v25                             // 000000DF99AC: 04563306
	v_lshrrev_b32_e32 v6, 4, v17                               // 000000DF99B0: 320C2284
	.long 0xcc0f4017                                           // 000000DF99B4: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v23                          // 000000DF99B8: 12022EFF 0000E408
	v_or_b32_e32 v25, 0x64006400, v29                          // 000000DF99C0: 38323AFF 64006400
	v_and_b32_e32 v17, 0xf0f0f0f, v17                          // 000000DF99C8: 362222FF 0F0F0F0F
	ds_load_b128 v[39:42], v88 offset:14336                    // 000000DF99D0: DBFC3800 27000058
	v_and_b32_e32 v6, 0xf0f0f0f, v6                            // 000000DF99D8: 360C0CFF 0F0F0F0F
	v_perm_b32 v5, v5, v22, 0xc070c03                          // 000000DF99E0: D6440005 03FE2D05 0C070C03
	v_dot2acc_f32_f16 v51, v21, v32                            // 000000DF99EC: 04664115
	v_dot2acc_f32_f16 v43, v23, v26                            // 000000DF99F0: 04563517
	.long 0xcc0f4015                                           // 000000DF99F4: CC0F4015
	v_mul_i32_i24_e32 v1, 0xe408, v25                          // 000000DF99F8: 120232FF 0000E408
	v_perm_b32 v22, v6, v17, 0xc040c00                         // 000000DF9A00: D6440016 03FE2306 0C040C00
	v_or_b32_e32 v23, 0x64006400, v5                           // 000000DF9A0C: 382E0AFF 64006400
	v_dual_mov_b32 v44, 0 :: v_dual_and_b32 v29, 0xf0f0f0f, v24// 000000DF9A14: CA240080 2C1C30FF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DF9A20: BF870214
	v_dot2acc_f32_f16 v43, v21, v27                            // 000000DF9A24: 04563715
	v_or_b32_e32 v21, 0x64006400, v22                          // 000000DF9A28: 382A2CFF 64006400
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DF9A30: BF870004
	.long 0xcc0f4019                                           // 000000DF9A34: CC0F4019
	v_mul_i32_i24_e32 v1, 0xe408, v23                          // 000000DF9A38: 12022EFF 0000E408
	v_lshrrev_b32_e32 v22, 4, v24                              // 000000DF9A40: 322C3084
	v_perm_b32 v23, v6, v17, 0xc050c01                         // 000000DF9A44: D6440017 03FE2306 0C050C01
	v_perm_b32 v31, v6, v17, 0xc060c02                         // 000000DF9A50: D644001F 03FE2306 0C060C02
	.long 0xcc0f401a                                           // 000000DF9A5C: CC0F401A
	v_mul_i32_i24_e32 v1, 0xe408, v21                          // 000000DF9A60: 12022AFF 0000E408
	v_perm_b32 v6, v6, v17, 0xc070c03                          // 000000DF9A68: D6440006 03FE2306 0C070C03
	v_and_b32_e32 v30, 0xf0f0f0f, v22                          // 000000DF9A74: 363C2CFF 0F0F0F0F
	v_or_b32_e32 v27, 0x64006400, v23                          // 000000DF9A7C: 38362EFF 64006400
	ds_load_b128 v[21:24], v88 offset:14352                    // 000000DF9A84: DBFC3810 15000058
	s_waitcnt lgkmcnt(1)                                       // 000000DF9A8C: BF89FC17
	v_dot2acc_f32_f16 v44, v26, v39                            // 000000DF9A90: 04584F1A
	v_lshrrev_b32_e32 v26, 4, v18                              // 000000DF9A94: 32342484
	v_or_b32_e32 v31, 0x64006400, v31                          // 000000DF9A98: 383E3EFF 64006400
	.long 0xcc0f401b                                           // 000000DF9AA0: CC0F401B
	v_mul_i32_i24_e32 v1, 0xe408, v27                          // 000000DF9AA4: 120236FF 0000E408
	v_and_b32_e32 v17, 0xf0f0f0f, v18                          // 000000DF9AAC: 362224FF 0F0F0F0F
	v_or_b32_e32 v6, 0x64006400, v6                            // 000000DF9AB4: 380C0CFF 64006400
	v_and_b32_e32 v18, 0xf0f0f0f, v26                          // 000000DF9ABC: 362434FF 0F0F0F0F
	v_perm_b32 v26, v30, v29, 0xc040c00                        // 000000DF9AC4: D644001A 03FE3B1E 0C040C00
	v_dot2acc_f32_f16 v44, v27, v40                            // 000000DF9AD0: 0458511B
	.long 0xcc0f401b                                           // 000000DF9AD4: CC0F401B
	v_mul_i32_i24_e32 v1, 0xe408, v31                          // 000000DF9AD8: 12023EFF 0000E408
	v_dot2acc_f32_f16 v43, v25, v28                            // 000000DF9AE0: 04563919
	v_perm_b32 v31, v18, v17, 0xc040c00                        // 000000DF9AE4: D644001F 03FE2312 0C040C00
	v_or_b32_e32 v26, 0x64006400, v26                          // 000000DF9AF0: 383434FF 64006400
	.long 0xcc0f4006                                           // 000000DF9AF8: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DF9AFC: 12020CFF 0000E408
	v_dot2acc_f32_f16 v44, v27, v41                            // 000000DF9B04: 0458531B
	v_perm_b32 v27, v18, v17, 0xc050c01                        // 000000DF9B08: D644001B 03FE2312 0C050C01
	v_or_b32_e32 v25, 0x64006400, v31                          // 000000DF9B14: 38323EFF 64006400
	.long 0xcc0f401a                                           // 000000DF9B1C: CC0F401A
	v_mul_i32_i24_e32 v1, 0xe408, v26                          // 000000DF9B20: 120234FF 0000E408
	v_perm_b32 v28, v30, v29, 0xc050c01                        // 000000DF9B28: D644001C 03FE3B1E 0C050C01
	v_dot2acc_f32_f16 v44, v6, v42                             // 000000DF9B34: 04585506
	v_fma_mix_f32 v7, v8, v51, v7 op_sel_hi:[1,0,0]            // 000000DF9B38: CC200007 0C1E6708
	.long 0xcc0f4006                                           // 000000DF9B40: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v25                          // 000000DF9B44: 120232FF 0000E408
	v_dot2acc_f32_f16 v43, v26, v35                            // 000000DF9B4C: 0456471A
	v_or_b32_e32 v25, 0x64006400, v27                          // 000000DF9B50: 383236FF 64006400
	v_perm_b32 v26, v18, v17, 0xc060c02                        // 000000DF9B58: D644001A 03FE2312 0C060C02
	v_or_b32_e32 v31, 0x64006400, v28                          // 000000DF9B64: 383E38FF 64006400
	s_waitcnt lgkmcnt(0)                                       // 000000DF9B6C: BF89FC07
	v_dot2acc_f32_f16 v44, v6, v21                             // 000000DF9B70: 04582B06
	v_lshrrev_b32_e32 v6, 4, v19                               // 000000DF9B74: 320C2684
	.long 0xcc0f4015                                           // 000000DF9B78: CC0F4015
	v_mul_i32_i24_e32 v1, 0xe408, v25                          // 000000DF9B7C: 120232FF 0000E408
	v_or_b32_e32 v32, 0x64006400, v26                          // 000000DF9B84: 384034FF 64006400
	v_perm_b32 v17, v18, v17, 0xc070c03                        // 000000DF9B8C: D6440011 03FE2312 0C070C03
	v_and_b32_e32 v18, 0xf0f0f0f, v19                          // 000000DF9B98: 362426FF 0F0F0F0F
	v_and_b32_e32 v6, 0xf0f0f0f, v6                            // 000000DF9BA0: 360C0CFF 0F0F0F0F
	ds_load_b128 v[25:28], v88 offset:14368                    // 000000DF9BA8: DBFC3820 19000058
	v_dot2acc_f32_f16 v44, v21, v22                            // 000000DF9BB0: 04582D15
	.long 0xcc0f4015                                           // 000000DF9BB4: CC0F4015
	v_mul_i32_i24_e32 v1, 0xe408, v32                          // 000000DF9BB8: 120240FF 0000E408
	v_or_b32_e32 v17, 0x64006400, v17                          // 000000DF9BC0: 382222FF 64006400
	v_perm_b32 v22, v6, v18, 0xc040c00                         // 000000DF9BC8: D6440016 03FE2506 0C040C00
	v_perm_b32 v19, v30, v29, 0xc060c02                        // 000000DF9BD4: D6440013 03FE3B1E 0C060C02
	.long 0xcc0f401f                                           // 000000DF9BE0: CC0F401F
	v_mul_i32_i24_e32 v1, 0xe408, v31                          // 000000DF9BE4: 12023EFF 0000E408
	v_dot2acc_f32_f16 v44, v21, v23                            // 000000DF9BEC: 04582F15
	.long 0xcc0f4011                                           // 000000DF9BF0: CC0F4011
	v_mul_i32_i24_e32 v1, 0xe408, v17                          // 000000DF9BF4: 120222FF 0000E408
	v_or_b32_e32 v21, 0x64006400, v22                          // 000000DF9BFC: 382A2CFF 64006400
	v_perm_b32 v22, v6, v18, 0xc050c01                         // 000000DF9C04: D6440016 03FE2506 0C050C01
	v_perm_b32 v35, v30, v29, 0xc070c03                        // 000000DF9C10: D6440023 03FE3B1E 0C070C03
	v_perm_b32 v30, v6, v18, 0xc060c02                         // 000000DF9C1C: D644001E 03FE2506 0C060C02
	v_dot2acc_f32_f16 v44, v17, v24                            // 000000DF9C28: 04583111
	.long 0xcc0f4011                                           // 000000DF9C2C: CC0F4011
	v_mul_i32_i24_e32 v1, 0xe408, v21                          // 000000DF9C30: 12022AFF 0000E408
	v_or_b32_e32 v29, 0x64006400, v22                          // 000000DF9C38: 383A2CFF 64006400
	ds_load_b128 v[21:24], v88 offset:14384                    // 000000DF9C40: DBFC3830 15000058
	v_dot2acc_f32_f16 v43, v31, v36                            // 000000DF9C48: 0456491F
	v_or_b32_e32 v36, 0x64006400, v30                          // 000000DF9C4C: 38483CFF 64006400
	v_or_b32_e32 v19, 0x64006400, v19                          // 000000DF9C54: 382626FF 64006400
	s_waitcnt lgkmcnt(1)                                       // 000000DF9C5C: BF89FC17
	v_dot2acc_f32_f16 v44, v17, v25                            // 000000DF9C60: 04583311
	v_lshrrev_b32_e32 v17, 4, v13                              // 000000DF9C64: 32221A84
	.long 0xcc0f4019                                           // 000000DF9C68: CC0F4019
	v_mul_i32_i24_e32 v1, 0xe408, v29                          // 000000DF9C6C: 12023AFF 0000E408
	v_and_b32_e32 v13, 0xf0f0f0f, v13                          // 000000DF9C74: 361A1AFF 0F0F0F0F
	ds_load_b128 v[29:32], v88 offset:14592                    // 000000DF9C7C: DBFC3900 1D000058
	.long 0xcc0f4013                                           // 000000DF9C84: CC0F4013
	v_mul_i32_i24_e32 v1, 0xe408, v19                          // 000000DF9C88: 120226FF 0000E408
	v_and_b32_e32 v39, 0xf0f0f0f, v17                          // 000000DF9C90: 364E22FF 0F0F0F0F
	v_or_b32_e32 v17, 0x64006400, v35                          // 000000DF9C98: 382246FF 64006400
	v_dot2acc_f32_f16 v44, v25, v26                            // 000000DF9CA0: 04583519
	v_perm_b32 v6, v6, v18, 0xc070c03                          // 000000DF9CA4: D6440006 03FE2506 0C070C03
	.long 0xcc0f4012                                           // 000000DF9CB0: CC0F4012
	v_mul_i32_i24_e32 v1, 0xe408, v36                          // 000000DF9CB4: 120248FF 0000E408
	v_perm_b32 v25, v39, v13, 0xc040c00                        // 000000DF9CBC: D6440019 03FE1B27 0C040C00
	.long 0xcc0f401a                                           // 000000DF9CC8: CC0F401A
	v_mul_i32_i24_e32 v1, 0xe408, v17                          // 000000DF9CCC: 120222FF 0000E408
	v_dot2acc_f32_f16 v43, v19, v37                            // 000000DF9CD4: 04564B13
	v_perm_b32 v19, v39, v13, 0xc050c01                        // 000000DF9CD8: D6440013 03FE1B27 0C050C01
	v_dot2acc_f32_f16 v44, v18, v27                            // 000000DF9CE4: 04583712
	v_or_b32_e32 v17, 0x64006400, v25                          // 000000DF9CE8: 382232FF 64006400
	v_lshrrev_b32_e32 v18, 4, v20                              // 000000DF9CF0: 32242884
	v_dual_mov_b32 v36, 0 :: v_dual_and_b32 v35, 0xf0f0f0f, v20// 000000DF9CF4: CA240080 242228FF 0F0F0F0F
	v_or_b32_e32 v27, 0x64006400, v19                          // 000000DF9D00: 383626FF 64006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DF9D08: BF870214
	.long 0xcc0f4019                                           // 000000DF9D0C: CC0F4019
	v_mul_i32_i24_e32 v1, 0xe408, v17                          // 000000DF9D10: 120222FF 0000E408
	v_and_b32_e32 v37, 0xf0f0f0f, v18                          // 000000DF9D18: 364A24FF 0F0F0F0F
	v_perm_b32 v40, v39, v13, 0xc060c02                        // 000000DF9D20: D6440028 03FE1B27 0C060C02
	ds_load_b128 v[17:20], v88 offset:14608                    // 000000DF9D2C: DBFC3910 11000058
	v_or_b32_e32 v6, 0x64006400, v6                            // 000000DF9D34: 380C0CFF 64006400
	s_waitcnt lgkmcnt(1)                                       // 000000DF9D3C: BF89FC17
	v_dot2acc_f32_f16 v36, v25, v29                            // 000000DF9D40: 04483B19
	v_lshrrev_b32_e32 v25, 4, v14                              // 000000DF9D44: 32321C84
	.long 0xcc0f401b                                           // 000000DF9D48: CC0F401B
	v_mul_i32_i24_e32 v1, 0xe408, v27                          // 000000DF9D4C: 120236FF 0000E408
	v_or_b32_e32 v29, 0x64006400, v40                          // 000000DF9D54: 383A50FF 64006400
	v_perm_b32 v13, v39, v13, 0xc070c03                        // 000000DF9D5C: D644000D 03FE1B27 0C070C03
	v_and_b32_e32 v14, 0xf0f0f0f, v14                          // 000000DF9D68: 361C1CFF 0F0F0F0F
	v_and_b32_e32 v25, 0xf0f0f0f, v25                          // 000000DF9D70: 363232FF 0F0F0F0F
	.long 0xcc0f4006                                           // 000000DF9D78: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DF9D7C: 12020CFF 0000E408
	v_perm_b32 v39, v37, v35, 0xc040c00                        // 000000DF9D84: D6440027 03FE4725 0C040C00
	v_dot2acc_f32_f16 v36, v27, v30                            // 000000DF9D90: 04483D1B
	.long 0xcc0f401b                                           // 000000DF9D94: CC0F401B
	v_mul_i32_i24_e32 v1, 0xe408, v29                          // 000000DF9D98: 12023AFF 0000E408
	v_or_b32_e32 v13, 0x64006400, v13                          // 000000DF9DA0: 381A1AFF 64006400
	v_perm_b32 v29, v25, v14, 0xc040c00                        // 000000DF9DA8: D644001D 03FE1D19 0C040C00
	v_or_b32_e32 v30, 0x64006400, v39                          // 000000DF9DB4: 383C4EFF 64006400
	v_dot2acc_f32_f16 v44, v6, v28                             // 000000DF9DBC: 04583906
	v_dot2acc_f32_f16 v36, v27, v31                            // 000000DF9DC0: 04483F1B
	.long 0xcc0f4006                                           // 000000DF9DC4: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF9DC8: 12021AFF 0000E408
	v_or_b32_e32 v13, 0x64006400, v29                          // 000000DF9DD0: 381A3AFF 64006400
	.long 0xcc0f401b                                           // 000000DF9DD8: CC0F401B
	v_mul_i32_i24_e32 v1, 0xe408, v30                          // 000000DF9DDC: 12023CFF 0000E408
	v_perm_b32 v28, v25, v14, 0xc050c01                        // 000000DF9DE4: D644001C 03FE1D19 0C050C01
	v_dot2acc_f32_f16 v43, v26, v38                            // 000000DF9DF0: 04564D1A
	v_dot2acc_f32_f16 v36, v6, v32                             // 000000DF9DF4: 04484106
	.long 0xcc0f4006                                           // 000000DF9DF8: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF9DFC: 12021AFF 0000E408
	v_dot2acc_f32_f16 v44, v27, v21                            // 000000DF9E04: 04582B1B
	v_or_b32_e32 v13, 0x64006400, v28                          // 000000DF9E08: 381A38FF 64006400
	v_perm_b32 v21, v25, v14, 0xc060c02                        // 000000DF9E10: D6440015 03FE1D19 0C060C02
	v_perm_b32 v29, v37, v35, 0xc050c01                        // 000000DF9E1C: D644001D 03FE4725 0C050C01
	s_waitcnt lgkmcnt(0)                                       // 000000DF9E28: BF89FC07
	v_dot2acc_f32_f16 v36, v6, v17                             // 000000DF9E2C: 04482306
	v_lshrrev_b32_e32 v6, 4, v15                               // 000000DF9E30: 320C1E84
	.long 0xcc0f400d                                           // 000000DF9E34: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF9E38: 12021AFF 0000E408
	v_or_b32_e32 v17, 0x64006400, v21                          // 000000DF9E40: 38222AFF 64006400
	v_perm_b32 v14, v25, v14, 0xc070c03                        // 000000DF9E48: D644000E 03FE1D19 0C070C03
	v_and_b32_e32 v15, 0xf0f0f0f, v15                          // 000000DF9E54: 361E1EFF 0F0F0F0F
	v_and_b32_e32 v6, 0xf0f0f0f, v6                            // 000000DF9E5C: 360C0CFF 0F0F0F0F
	ds_load_b128 v[25:28], v88 offset:14624                    // 000000DF9E64: DBFC3920 19000058
	v_or_b32_e32 v21, 0x64006400, v29                          // 000000DF9E6C: 382A3AFF 64006400
	v_dot2acc_f32_f16 v36, v13, v18                            // 000000DF9E74: 0448250D
	.long 0xcc0f400d                                           // 000000DF9E78: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v17                          // 000000DF9E7C: 120222FF 0000E408
	v_or_b32_e32 v14, 0x64006400, v14                          // 000000DF9E84: 381C1CFF 64006400
	v_perm_b32 v17, v6, v15, 0xc040c00                         // 000000DF9E8C: D6440011 03FE1F06 0C040C00
	.long 0xcc0f4012                                           // 000000DF9E98: CC0F4012
	v_mul_i32_i24_e32 v1, 0xe408, v21                          // 000000DF9E9C: 12022AFF 0000E408
	v_perm_b32 v21, v37, v35, 0xc060c02                        // 000000DF9EA4: D6440015 03FE4725 0C060C02
	v_dot2acc_f32_f16 v36, v13, v19                            // 000000DF9EB0: 0448270D
	.long 0xcc0f400d                                           // 000000DF9EB4: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v14                          // 000000DF9EB8: 12021CFF 0000E408
	v_or_b32_e32 v14, 0x64006400, v17                          // 000000DF9EC0: 381C22FF 64006400
	v_perm_b32 v17, v6, v15, 0xc050c01                         // 000000DF9EC8: D6440011 03FE1F06 0C050C01
	v_or_b32_e32 v19, 0x64006400, v21                          // 000000DF9ED4: 38262AFF 64006400
	v_dot2acc_f32_f16 v44, v18, v22                            // 000000DF9EDC: 04582D12
	v_dot2acc_f32_f16 v36, v13, v20                            // 000000DF9EE0: 0448290D
	.long 0xcc0f400d                                           // 000000DF9EE4: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v14                          // 000000DF9EE8: 12021CFF 0000E408
	v_or_b32_e32 v14, 0x64006400, v17                          // 000000DF9EF0: 381C22FF 64006400
	.long 0xcc0f4015                                           // 000000DF9EF8: CC0F4015
	v_mul_i32_i24_e32 v1, 0xe408, v19                          // 000000DF9EFC: 120226FF 0000E408
	ds_load_b128 v[17:20], v88 offset:14640                    // 000000DF9F04: DBFC3930 11000058
	v_perm_b32 v22, v37, v35, 0xc070c03                        // 000000DF9F0C: D6440016 03FE4725 0C070C03
	s_waitcnt lgkmcnt(1)                                       // 000000DF9F18: BF89FC17
	v_dot2acc_f32_f16 v36, v13, v25                            // 000000DF9F1C: 0448330D
	.long 0xcc0f400d                                           // 000000DF9F20: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v14                          // 000000DF9F24: 12021CFF 0000E408
	v_perm_b32 v14, v6, v15, 0xc060c02                         // 000000DF9F2C: D644000E 03FE1F06 0C060C02
	v_fma_mix_f32 v25, v8, v43, v7 op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DF9F38: CC200819 0C1E5708
	s_waitcnt vmcnt(2)                                         // 000000DF9F40: BF890BF7
	v_lshrrev_b32_e32 v7, 4, v9                                // 000000DF9F44: 320E1284
	v_dot2acc_f32_f16 v44, v21, v23                            // 000000DF9F48: 04582F15
	v_dot2acc_f32_f16 v36, v13, v26                            // 000000DF9F4C: 0448350D
	v_or_b32_e32 v13, 0x64006400, v14                          // 000000DF9F50: 381A1CFF 64006400
	v_perm_b32 v14, v6, v15, 0xc070c03                         // 000000DF9F58: D644000E 03FE1F06 0C070C03
	v_lshrrev_b32_e32 v15, 4, v16                              // 000000DF9F64: 321E2084
	v_and_b32_e32 v23, 0xf0f0f0f, v9                           // 000000DF9F68: 362E12FF 0F0F0F0F
	v_and_b32_e32 v26, 0xf0f0f0f, v7                           // 000000DF9F70: 36340EFF 0F0F0F0F
	ds_load_b128 v[6:9], v88 offset:14848                      // 000000DF9F78: DBFC3A00 06000058
	v_or_b32_e32 v21, 0x64006400, v22                          // 000000DF9F80: 382A2CFF 64006400
	v_and_b32_e32 v22, 0xf0f0f0f, v16                          // 000000DF9F88: 362C20FF 0F0F0F0F
	v_and_b32_e32 v29, 0xf0f0f0f, v15                          // 000000DF9F90: 363A1EFF 0F0F0F0F
	.long 0xcc0f400d                                           // 000000DF9F98: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DF9F9C: 12021AFF 0000E408
	v_or_b32_e32 v14, 0x64006400, v14                          // 000000DF9FA4: 381C1CFF 64006400
	v_perm_b32 v15, v26, v23, 0xc040c00                        // 000000DF9FAC: D644000F 03FE2F1A 0C040C00
	.long 0xcc0f4010                                           // 000000DF9FB8: CC0F4010
	v_mul_i32_i24_e32 v1, 0xe408, v21                          // 000000DF9FBC: 12022AFF 0000E408
	v_perm_b32 v21, v29, v22, 0xc040c00                        // 000000DF9FC4: D6440015 03FE2D1D 0C040C00
	v_dot2acc_f32_f16 v36, v13, v27                            // 000000DF9FD0: 0448370D
	.long 0xcc0f400d                                           // 000000DF9FD4: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v14                          // 000000DF9FD8: 12021CFF 0000E408
	v_or_b32_e32 v14, 0x64006400, v15                          // 000000DF9FE0: 381C1EFF 64006400
	v_dot2acc_f32_f16 v44, v16, v24                            // 000000DF9FE8: 04583110
	v_or_b32_e32 v15, 0x64006400, v21                          // 000000DF9FEC: 381E2AFF 64006400
	v_perm_b32 v16, v26, v23, 0xc050c01                        // 000000DF9FF4: D6440010 03FE2F1A 0C050C01
	v_mov_b32_e32 v27, 0                                       // 000000DFA000: 7E360280
	.long 0xcc0f4015                                           // 000000DFA004: CC0F4015
	v_mul_i32_i24_e32 v1, 0xe408, v14                          // 000000DFA008: 12021CFF 0000E408
	v_dot2acc_f32_f16 v36, v13, v28                            // 000000DFA010: 0448390D
	.long 0xcc0f4018                                           // 000000DFA014: CC0F4018
	v_mul_i32_i24_e32 v1, 0xe408, v15                          // 000000DFA018: 12021EFF 0000E408
	v_or_b32_e32 v28, 0x64006400, v16                          // 000000DFA020: 383820FF 64006400
	v_perm_b32 v30, v26, v23, 0xc060c02                        // 000000DFA028: D644001E 03FE2F1A 0C060C02
	ds_load_b128 v[13:16], v88 offset:14864                    // 000000DFA034: DBFC3A10 0D000058
	s_waitcnt lgkmcnt(1)                                       // 000000DFA03C: BF89FC17
	v_dot2acc_f32_f16 v27, v21, v6                             // 000000DFA040: 04360D15
	v_lshrrev_b32_e32 v6, 4, v10                               // 000000DFA044: 320C1484
	.long 0xcc0f4015                                           // 000000DFA048: CC0F4015
	v_mul_i32_i24_e32 v1, 0xe408, v28                          // 000000DFA04C: 120238FF 0000E408
	v_or_b32_e32 v28, 0x64006400, v30                          // 000000DFA054: 38383CFF 64006400
	v_perm_b32 v23, v26, v23, 0xc070c03                        // 000000DFA05C: D6440017 03FE2F1A 0C070C03
	v_and_b32_e32 v10, 0xf0f0f0f, v10                          // 000000DFA068: 361414FF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DFA070: BF870214
	v_dual_dot2acc_f32_f16 v27, v21, v7 :: v_dual_and_b32 v6, 0xf0f0f0f, v6// 000000DFA074: CB240F15 1B060CFF 0F0F0F0F
	.long 0xcc0f4007                                           // 000000DFA080: CC0F4007
	v_mul_i32_i24_e32 v1, 0xe408, v28                          // 000000DFA084: 120238FF 0000E408
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DFA08C: BF870224
	v_or_b32_e32 v21, 0x64006400, v23                          // 000000DFA090: 382A2EFF 64006400
	v_perm_b32 v26, v29, v22, 0xc050c01                        // 000000DFA098: D644001A 03FE2D1D 0C050C01
	v_perm_b32 v23, v6, v10, 0xc040c00                         // 000000DFA0A4: D6440017 03FE1506 0C040C00
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DFA0B0: BF870214
	v_dual_dot2acc_f32_f16 v36, v24, v17 :: v_dual_dot2acc_f32_f16 v27, v7, v8// 000000DFA0B4: CB182318 241A1107
	.long 0xcc0f4007                                           // 000000DFA0BC: CC0F4007
	v_mul_i32_i24_e32 v1, 0xe408, v21                          // 000000DFA0C0: 12022AFF 0000E408
	v_perm_b32 v21, v6, v10, 0xc050c01                         // 000000DFA0C8: D6440015 03FE1506 0C050C01
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DFA0D4: BF870004
	v_or_b32_e32 v8, 0x64006400, v23                           // 000000DFA0D8: 38102EFF 64006400
	v_or_b32_e32 v26, 0x64006400, v26                          // 000000DFA0E0: 383434FF 64006400
	v_perm_b32 v23, v29, v22, 0xc060c02                        // 000000DFA0E8: D6440017 03FE2D1D 0C060C02
	v_dot2acc_f32_f16 v27, v7, v9                              // 000000DFA0F4: 04361307
	v_perm_b32 v9, v6, v10, 0xc060c02                          // 000000DFA0F8: D6440009 03FE1506 0C060C02
	.long 0xcc0f4007                                           // 000000DFA104: CC0F4007
	v_mul_i32_i24_e32 v1, 0xe408, v8                           // 000000DFA108: 120210FF 0000E408
	v_or_b32_e32 v8, 0x64006400, v21                           // 000000DFA110: 38102AFF 64006400
	.long 0xcc0f4011                                           // 000000DFA118: CC0F4011
	v_mul_i32_i24_e32 v1, 0xe408, v26                          // 000000DFA11C: 120234FF 0000E408
	v_perm_b32 v10, v6, v10, 0xc070c03                         // 000000DFA124: D644000A 03FE1506 0C070C03
	v_mov_b32_e32 v5, 0                                        // 000000DFA130: 7E0A0280
	s_waitcnt lgkmcnt(0)                                       // 000000DFA134: BF89FC07
	v_dot2acc_f32_f16 v27, v7, v13                             // 000000DFA138: 04361B07
	v_lshrrev_b32_e32 v7, 4, v11                               // 000000DFA13C: 320E1684
	.long 0xcc0f4008                                           // 000000DFA140: CC0F4008
	v_mul_i32_i24_e32 v1, 0xe408, v8                           // 000000DFA144: 120210FF 0000E408
	v_or_b32_e32 v13, 0x64006400, v9                           // 000000DFA14C: 381A12FF 64006400
	v_and_b32_e32 v11, 0xf0f0f0f, v11                          // 000000DFA154: 361616FF 0F0F0F0F
	v_or_b32_e32 v10, 0x64006400, v10                          // 000000DFA15C: 381414FF 64006400
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DFA164: BF870004
	v_dual_dot2acc_f32_f16 v27, v8, v14 :: v_dual_and_b32 v26, 0xf0f0f0f, v7// 000000DFA168: CB241D08 1B1A0EFF 0F0F0F0F
	ds_load_b128 v[6:9], v88 offset:14880                      // 000000DFA174: DBFC3A20 06000058
	.long 0xcc0f400d                                           // 000000DFA17C: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DFA180: 12021AFF 0000E408
	.long 0xcc0f400a                                           // 000000DFA188: CC0F400A
	v_mul_i32_i24_e32 v1, 0xe408, v10                          // 000000DFA18C: 120214FF 0000E408
	v_perm_b32 v14, v26, v11, 0xc040c00                        // 000000DFA194: D644000E 03FE171A 0C040C00
	v_dot2acc_f32_f16 v36, v17, v18                            // 000000DFA1A0: 04482511
	v_perm_b32 v18, v29, v22, 0xc070c03                        // 000000DFA1A4: D6440012 03FE2D1D 0C070C03
	v_dot2acc_f32_f16 v27, v13, v15                            // 000000DFA1B0: 04361F0D
	s_waitcnt vmcnt(1)                                         // 000000DFA1B4: BF8907F7
	v_lshrrev_b32_e32 v15, 4, v1                               // 000000DFA1B8: 321E0284
	v_or_b32_e32 v13, 0x64006400, v14                          // 000000DFA1BC: 381A1CFF 64006400
	v_perm_b32 v14, v26, v11, 0xc050c01                        // 000000DFA1C4: D644000E 03FE171A 0C050C01
	v_and_b32_e32 v1, 0xf0f0f0f, v1                            // 000000DFA1D0: 360202FF 0F0F0F0F
	v_dot2acc_f32_f16 v27, v10, v16                            // 000000DFA1D8: 0436210A
	v_and_b32_e32 v29, 0xf0f0f0f, v15                          // 000000DFA1DC: 363A1EFF 0F0F0F0F
	.long 0xcc0f400a                                           // 000000DFA1E4: CC0F400A
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DFA1E8: 12021AFF 0000E408
	v_or_b32_e32 v28, 0x64006400, v14                          // 000000DFA1F0: 38381CFF 64006400
	ds_load_b128 v[13:16], v88 offset:15104                    // 000000DFA1F8: DBFC3B00 0D000058
	v_or_b32_e32 v17, 0x64006400, v23                          // 000000DFA200: 38222EFF 64006400
	v_perm_b32 v30, v26, v11, 0xc060c02                        // 000000DFA208: D644001E 03FE171A 0C060C02
	ds_load_b128 v[21:24], v88 offset:14896                    // 000000DFA214: DBFC3A30 15000058
	v_or_b32_e32 v18, 0x64006400, v18                          // 000000DFA21C: 382424FF 64006400
	s_waitcnt lgkmcnt(2)                                       // 000000DFA224: BF89FC27
	v_dot2acc_f32_f16 v27, v10, v6                             // 000000DFA228: 04360D0A
	.long 0xcc0f4006                                           // 000000DFA22C: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v28                          // 000000DFA230: 120238FF 0000E408
	v_perm_b32 v10, v29, v1, 0xc040c00                         // 000000DFA238: D644000A 03FE031D 0C040C00
	.long 0xcc0f4011                                           // 000000DFA244: CC0F4011
	v_mul_i32_i24_e32 v1, 0xe408, v17                          // 000000DFA248: 120222FF 0000E408
	v_or_b32_e32 v28, 0x64006400, v30                          // 000000DFA250: 38383CFF 64006400
	s_waitcnt vmcnt(0)                                         // 000000DFA258: BF8903F7
	v_fma_mix_f32 v25, v33, v44, v25 op_sel_hi:[1,0,0]         // 000000DFA25C: CC200019 0C665921
	v_dot2acc_f32_f16 v27, v6, v7                              // 000000DFA264: 04360F06
	v_or_b32_e32 v6, 0x64006400, v10                           // 000000DFA268: 380C14FF 64006400
	v_dot2acc_f32_f16 v36, v17, v19                            // 000000DFA270: 04482711
	.long 0xcc0f4011                                           // 000000DFA274: CC0F4011
	v_mul_i32_i24_e32 v1, 0xe408, v18                          // 000000DFA278: 120224FF 0000E408
	.long 0xcc0f4007                                           // 000000DFA280: CC0F4007
	v_mul_i32_i24_e32 v1, 0xe408, v28                          // 000000DFA284: 120238FF 0000E408
	v_perm_b32 v10, v29, v1, 0xc050c01                         // 000000DFA28C: D644000A 03FE031D 0C050C01
	.long 0xcc0f4006                                           // 000000DFA298: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DFA29C: 12020CFF 0000E408
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DFA2A4: BF870214
	v_dot2acc_f32_f16 v36, v17, v20                            // 000000DFA2A8: 04482911
	v_dot2acc_f32_f16 v27, v7, v8                              // 000000DFA2AC: 04361107
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DFA2B0: BF870004
	v_or_b32_e32 v7, 0x64006400, v10                           // 000000DFA2B4: 380E14FF 64006400
	v_perm_b32 v8, v29, v1, 0xc060c02                          // 000000DFA2BC: D6440008 03FE031D 0C060C02
	ds_load_b128 v[17:20], v88 offset:15120                    // 000000DFA2C8: DBFC3B10 11000058
	s_waitcnt lgkmcnt(2)                                       // 000000DFA2D0: BF89FC27
	v_dot2acc_f32_f16 v5, v6, v13                              // 000000DFA2D4: 040A1B06
	v_lshrrev_b32_e32 v6, 4, v2                                // 000000DFA2D8: 320C0484
	.long 0xcc0f4007                                           // 000000DFA2DC: CC0F4007
	v_mul_i32_i24_e32 v1, 0xe408, v7                           // 000000DFA2E0: 12020EFF 0000E408
	v_or_b32_e32 v8, 0x64006400, v8                            // 000000DFA2E8: 381010FF 64006400
	v_perm_b32 v1, v29, v1, 0xc070c03                          // 000000DFA2F0: D6440001 03FE031D 0C070C03
	v_and_b32_e32 v2, 0xf0f0f0f, v2                            // 000000DFA2FC: 360404FF 0F0F0F0F
	v_and_b32_e32 v6, 0xf0f0f0f, v6                            // 000000DFA304: 360C0CFF 0F0F0F0F
	v_dot2acc_f32_f16 v5, v7, v14                              // 000000DFA30C: 040A1D07
	.long 0xcc0f4007                                           // 000000DFA310: CC0F4007
	v_mul_i32_i24_e32 v1, 0xe408, v8                           // 000000DFA314: 120210FF 0000E408
	v_or_b32_e32 v1, 0x64006400, v1                            // 000000DFA31C: 380202FF 64006400
	v_perm_b32 v10, v26, v11, 0xc070c03                        // 000000DFA324: D644000A 03FE171A 0C070C03
	v_perm_b32 v8, v6, v2, 0xc040c00                           // 000000DFA330: D6440008 03FE0506 0C040C00
	v_lshrrev_b32_e32 v11, 4, v12                              // 000000DFA33C: 32161884
	v_dot2acc_f32_f16 v5, v7, v15                              // 000000DFA340: 040A1F07
	.long 0xcc0f4001                                           // 000000DFA344: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DFA348: 120202FF 0000E408
	v_or_b32_e32 v10, 0x64006400, v10                          // 000000DFA350: 381414FF 64006400
	v_or_b32_e32 v7, 0x64006400, v8                            // 000000DFA358: 380E10FF 64006400
	v_perm_b32 v8, v6, v2, 0xc050c01                           // 000000DFA360: D6440008 03FE0506 0C050C01
	v_and_b32_e32 v14, 0xf0f0f0f, v12                          // 000000DFA36C: 361C18FF 0F0F0F0F
	v_dot2acc_f32_f16 v5, v1, v16                              // 000000DFA374: 040A2101
	v_and_b32_e32 v15, 0xf0f0f0f, v11                          // 000000DFA378: 361E16FF 0F0F0F0F
	.long 0xcc0f4001                                           // 000000DFA380: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v7                           // 000000DFA384: 12020EFF 0000E408
	.long 0xcc0f4007                                           // 000000DFA38C: CC0F4007
	v_mul_i32_i24_e32 v1, 0xe408, v10                          // 000000DFA390: 120214FF 0000E408
	v_or_b32_e32 v8, 0x64006400, v8                            // 000000DFA398: 381010FF 64006400
	v_perm_b32 v10, v6, v2, 0xc060c02                          // 000000DFA3A0: D644000A 03FE0506 0C060C02
	v_perm_b32 v16, v15, v14, 0xc040c00                        // 000000DFA3AC: D6440010 03FE1D0F 0C040C00
	s_waitcnt lgkmcnt(0)                                       // 000000DFA3B8: BF89FC07
	v_dot2acc_f32_f16 v5, v1, v17                              // 000000DFA3BC: 040A2301
	v_lshrrev_b32_e32 v1, 4, v3                                // 000000DFA3C0: 32020684
	.long 0xcc0f4008                                           // 000000DFA3C4: CC0F4008
	v_mul_i32_i24_e32 v1, 0xe408, v8                           // 000000DFA3C8: 120210FF 0000E408
	v_or_b32_e32 v17, 0x64006400, v10                          // 000000DFA3D0: 382214FF 64006400
	v_perm_b32 v2, v6, v2, 0xc070c03                           // 000000DFA3D8: D6440002 03FE0506 0C070C03
	v_and_b32_e32 v3, 0xf0f0f0f, v3                            // 000000DFA3E4: 360606FF 0F0F0F0F
	v_and_b32_e32 v1, 0xf0f0f0f, v1                            // 000000DFA3EC: 360202FF 0F0F0F0F
	ds_load_b128 v[10:13], v88 offset:15136                    // 000000DFA3F4: DBFC3B20 0A000058
	v_or_b32_e32 v6, 0x64006400, v16                           // 000000DFA3FC: 380C20FF 64006400
	v_dot2acc_f32_f16 v5, v8, v18                              // 000000DFA404: 040A2508
	.long 0xcc0f4008                                           // 000000DFA408: CC0F4008
	v_mul_i32_i24_e32 v1, 0xe408, v17                          // 000000DFA40C: 120222FF 0000E408
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DFA414: 380404FF 64006400
	v_perm_b32 v16, v1, v3, 0xc040c00                          // 000000DFA41C: D6440010 03FE0701 0C040C00
	v_dot2acc_f32_f16 v27, v7, v9                              // 000000DFA428: 04361307
	.long 0xcc0f4006                                           // 000000DFA42C: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DFA430: 12020CFF 0000E408
	v_dot2acc_f32_f16 v5, v8, v19                              // 000000DFA438: 040A2708
	.long 0xcc0f4002                                           // 000000DFA43C: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DFA440: 120204FF 0000E408
	v_or_b32_e32 v7, 0x64006400, v16                           // 000000DFA448: 380E20FF 64006400
	v_perm_b32 v8, v15, v14, 0xc050c01                         // 000000DFA450: D6440008 03FE1D0F 0C050C01
	v_perm_b32 v9, v1, v3, 0xc050c01                           // 000000DFA45C: D6440009 03FE0701 0C050C01
	v_dot2acc_f32_f16 v27, v6, v21                             // 000000DFA468: 04362B06
	v_dot2acc_f32_f16 v5, v2, v20                              // 000000DFA46C: 040A2902
	.long 0xcc0f4002                                           // 000000DFA470: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v7                           // 000000DFA474: 12020EFF 0000E408
	v_or_b32_e32 v16, 0x64006400, v8                           // 000000DFA47C: 382010FF 64006400
	v_or_b32_e32 v17, 0x64006400, v9                           // 000000DFA484: 382212FF 64006400
	v_perm_b32 v18, v1, v3, 0xc060c02                          // 000000DFA48C: D6440012 03FE0701 0C060C02
	ds_load_b128 v[6:9], v88 offset:15152                      // 000000DFA498: DBFC3B30 06000058
	s_waitcnt lgkmcnt(1)                                       // 000000DFA4A0: BF89FC17
	v_dot2acc_f32_f16 v5, v2, v10                              // 000000DFA4A4: 040A1502
	v_lshrrev_b32_e32 v2, 4, v4                                // 000000DFA4A8: 32040884
	.long 0xcc0f400a                                           // 000000DFA4AC: CC0F400A
	v_mul_i32_i24_e32 v1, 0xe408, v17                          // 000000DFA4B0: 120222FF 0000E408
	v_or_b32_e32 v17, 0x64006400, v18                          // 000000DFA4B8: 382224FF 64006400
	v_perm_b32 v1, v1, v3, 0xc070c03                           // 000000DFA4C0: D6440001 03FE0701 0C070C03
	v_and_b32_e32 v3, 0xf0f0f0f, v4                            // 000000DFA4CC: 360608FF 0F0F0F0F
	v_and_b32_e32 v2, 0xf0f0f0f, v2                            // 000000DFA4D4: 360404FF 0F0F0F0F
	.long 0xcc0f4004                                           // 000000DFA4DC: CC0F4004
	v_mul_i32_i24_e32 v1, 0xe408, v16                          // 000000DFA4E0: 120220FF 0000E408
	v_dot2acc_f32_f16 v5, v10, v11                             // 000000DFA4E8: 040A170A
	.long 0xcc0f400a                                           // 000000DFA4EC: CC0F400A
	v_mul_i32_i24_e32 v1, 0xe408, v17                          // 000000DFA4F0: 120222FF 0000E408
	v_or_b32_e32 v1, 0x64006400, v1                            // 000000DFA4F8: 380202FF 64006400
	v_perm_b32 v11, v2, v3, 0xc040c00                          // 000000DFA500: D644000B 03FE0702 0C040C00
	v_dot2acc_f32_f16 v27, v4, v22                             // 000000DFA50C: 04362D04
	v_perm_b32 v4, v15, v14, 0xc060c02                         // 000000DFA510: D6440004 03FE1D0F 0C060C02
	v_dot2acc_f32_f16 v5, v10, v12                             // 000000DFA51C: 040A190A
	.long 0xcc0f4001                                           // 000000DFA520: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DFA524: 120202FF 0000E408
	v_or_b32_e32 v10, 0x64006400, v11                          // 000000DFA52C: 381416FF 64006400
	v_perm_b32 v11, v2, v3, 0xc050c01                          // 000000DFA534: D644000B 03FE0702 0C050C01
	v_or_b32_e32 v4, 0x64006400, v4                            // 000000DFA540: 380808FF 64006400
	v_perm_b32 v12, v15, v14, 0xc070c03                        // 000000DFA548: D644000C 03FE1D0F 0C070C03
	v_dot2acc_f32_f16 v5, v1, v13                              // 000000DFA554: 040A1B01
	.long 0xcc0f4001                                           // 000000DFA558: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v10                          // 000000DFA55C: 120214FF 0000E408
	v_or_b32_e32 v10, 0x64006400, v11                          // 000000DFA564: 381416FF 64006400
	v_perm_b32 v11, v2, v3, 0xc060c02                          // 000000DFA56C: D644000B 03FE0702 0C060C02
	.long 0xcc0f4004                                           // 000000DFA578: CC0F4004
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DFA57C: 120208FF 0000E408
	v_or_b32_e32 v12, 0x64006400, v12                          // 000000DFA584: 381818FF 64006400
	s_waitcnt lgkmcnt(0)                                       // 000000DFA58C: BF89FC07
	v_dot2acc_f32_f16 v5, v1, v6                               // 000000DFA590: 040A0D01
	.long 0xcc0f4001                                           // 000000DFA594: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v10                          // 000000DFA598: 120214FF 0000E408
	v_or_b32_e32 v6, 0x64006400, v11                           // 000000DFA5A0: 380C16FF 64006400
	v_perm_b32 v2, v2, v3, 0xc070c03                           // 000000DFA5A8: D6440002 03FE0702 0C070C03
	v_dot2acc_f32_f16 v27, v4, v23                             // 000000DFA5B4: 04362F04
	.long 0xcc0f4003                                           // 000000DFA5B8: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v12                          // 000000DFA5BC: 120218FF 0000E408
	v_dot2acc_f32_f16 v5, v1, v7                               // 000000DFA5C4: 040A0F01
	.long 0xcc0f4001                                           // 000000DFA5C8: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DFA5CC: 12020CFF 0000E408
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DFA5D4: 380404FF 64006400
	v_fma_mix_f32 v4, v33, v36, v25 op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DFA5DC: CC200804 0C664921
	v_dot2acc_f32_f16 v27, v3, v24                             // 000000DFA5E4: 04363103
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DFA5E8: BF870214
	v_dot2acc_f32_f16 v5, v1, v8                               // 000000DFA5EC: 040A1101
	.long 0xcc0f4001                                           // 000000DFA5F0: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DFA5F4: 120204FF 0000E408
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DFA5FC: BF870113
	v_fma_mix_f32 v2, v34, v27, v4 op_sel_hi:[1,0,0]           // 000000DFA600: CC200002 0C123722
	v_dot2acc_f32_f16 v5, v1, v9                               // 000000DFA608: 040A1301
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DFA60C: BF870091
	v_fma_mix_f32 v1, v34, v5, v2 op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DFA610: CC200801 0C0A0B22
	v_mov_b32_dpp v2, v1 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DFA618: 7E0402FA FF016101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DFA620: BF870091
	v_add_f32_e32 v1, v1, v2                                   // 000000DFA624: 06020501
	v_mov_b32_dpp v2, v1 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DFA628: 7E0402FA FF016201
	v_cmpx_eq_u32_e32 0, v87                                   // 000000DFA630: 7D94AE80
	s_cbranch_execz 17                                         // 000000DFA634: BFA50011 <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi2EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x627c>
	s_delay_alu instid0(VALU_DEP_2)                            // 000000DFA638: BF870002
	v_add_f32_e32 v3, v1, v2                                   // 000000DFA63C: 06060501
	.long 0xd73c0001                                           // 000000DFA640: D73C0001
	v_cndmask_b32_e32 v1, 2, v81, vcc_lo                       // 000000DFA644: 0202A282
	s_mul_i32 s2, s9, 0x1400                                   // 000000DFA648: 9602FF09 00001400
	s_mul_hi_u32 s3, s9, 0x1400                                // 000000DFA650: 9683FF09 00001400
	s_add_u32 s2, s24, s2                                      // 000000DFA658: 80020218
	s_addc_u32 s3, s25, s3                                     // 000000DFA65C: 82030319
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DFA660: BF870091
	.long 0xd7006a01                                           // 000000DFA664: D7006A01
	v_cndmask_b32_e32 v1, s2, v1, vcc_lo                       // 000000DFA668: 02020202
	v_add_co_ci_u32_e64 v2, null, s3, v2, vcc_lo               // 000000DFA66C: D5207C02 01AA0403
	global_store_b32 v[1:2], v3, off                           // 000000DFA674: DC6A0000 007C0301
	s_or_b32 exec_lo, exec_lo, s1                              // 000000DFA67C: 8C7E017E
	s_mul_hi_i32 s1, s0, 0x66666667                            // 000000DFA680: 9701FF00 66666667
	s_waitcnt_vscnt null, 0x0                                  // 000000DFA688: BC7C0000
	buffer_gl1_inv                                             // 000000DFA68C: E0B00000 00000000
	buffer_gl0_inv                                             // 000000DFA694: E0AC0000 00000000
	s_lshr_b32 s2, s1, 31                                      // 000000DFA69C: 85029F01
	s_lshr_b32 s1, s1, 2                                       // 000000DFA6A0: 85018201
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000DFA6A4: BF870009
	s_add_i32 s1, s1, s2                                       // 000000DFA6A8: 81010201
	s_mul_i32 s2, s9, 5                                        // 000000DFA6AC: 96028509
	s_mul_i32 s1, s1, 10                                       // 000000DFA6B0: 96018A01
	s_barrier                                                  // 000000DFA6B4: BFBD0000
	s_sub_i32 s0, s0, s1                                       // 000000DFA6B8: 81800100
	buffer_gl0_inv                                             // 000000DFA6BC: E0AC0000 00000000
	s_bfe_u32 s1, s0, 0x10007                                  // 000000DFA6C4: 9301FF00 00010007
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000DFA6CC: BF870499
	s_add_i32 s0, s0, s1                                       // 000000DFA6D0: 81000100
	s_bfe_i32 s0, s0, 0x80000                                  // 000000DFA6D4: 9380FF00 00080000
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000DFA6DC: BF8704B9
	s_sext_i32_i16 s1, s0                                      // 000000DFA6E0: BE810F00
	.long 0xd44a0000                                           // 000000DFA6E4: D44A0000
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 000000DFA6E8: 02020080
	s_ashr_i32 s1, s1, 1                                       // 000000DFA6EC: 86018101
	s_add_i32 s10, s2, s1                                      // 000000DFA6F0: 810A0102
	s_and_saveexec_b32 s2, s0                                  // 000000DFA6F4: BE822000
	s_cbranch_execz 29                                         // 000000DFA6F8: BFA5001D <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi2EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x6370>
	s_mov_b32 s4, exec_lo                                      // 000000DFA6FC: BE84007E
	s_mov_b32 s3, exec_lo                                      // 000000DFA700: BE83007E
	.long 0xd71f0001                                           // 000000DFA704: D71F0001
	v_cndmask_b32_e32 v0, s4, v128, vcc_lo                     // 000000DFA708: 02010004
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DFA70C: BF870001
	v_cmpx_eq_u32_e32 0, v1                                    // 000000DFA710: 7D940280
	s_cbranch_execz 11                                         // 000000DFA714: BFA5000B <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi2EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x6344>
	s_ashr_i32 s11, s10, 31                                    // 000000DFA718: 860B9F0A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000DFA71C: BF870499
	s_lshl_b64 s[6:7], s[10:11], 2                             // 000000DFA720: 8486820A
	s_add_u32 s6, s12, s6                                      // 000000DFA724: 8006060C
	s_addc_u32 s7, s13, s7                                     // 000000DFA728: 8207070D
	s_bcnt1_i32_b32 s4, s4                                     // 000000DFA72C: BE841804
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000DFA730: BF870009
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, s4              // 000000DFA734: CA100080 02020004
	global_atomic_add_u32 v2, v2, v3, s[6:7] glc               // 000000DFA73C: DCD64000 02060302
	s_or_b32 exec_lo, exec_lo, s3                              // 000000DFA744: 8C7E037E
	s_waitcnt vmcnt(0)                                         // 000000DFA748: BF8903F7
	v_readfirstlane_b32 s3, v2                                 // 000000DFA74C: 7E060502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DFA750: BF870091
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s3, v1       // 000000DFA754: CA200080 02000203
	v_cmp_eq_u32_e32 vcc_lo, 3, v1                             // 000000DFA75C: 7C940283
	v_cndmask_b32_e64 v1, 0, 1, vcc_lo                         // 000000DFA760: D5010001 01A90280
	ds_store_b32 v2, v1 offset:15364                           // 000000DFA768: D8343C04 00000102
	s_or_b32 exec_lo, exec_lo, s2                              // 000000DFA770: 8C7E027E
	v_mov_b32_e32 v1, 0                                        // 000000DFA774: 7E020280
	s_waitcnt lgkmcnt(0)                                       // 000000DFA778: BF89FC07
	s_barrier                                                  // 000000DFA77C: BFBD0000
	buffer_gl0_inv                                             // 000000DFA780: E0AC0000 00000000
	ds_load_b32 v1, v1 offset:15364                            // 000000DFA788: D8D83C04 01000001
	s_waitcnt lgkmcnt(0)                                       // 000000DFA790: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 000000DFA794: 7C940280
	s_cbranch_vccnz 639                                        // 000000DFA798: BFA4027F <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi2EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x6d98>
	buffer_gl1_inv                                             // 000000DFA79C: E0B00000 00000000
	buffer_gl0_inv                                             // 000000DFA7A4: E0AC0000 00000000
	s_mov_b32 s2, exec_lo                                      // 000000DFA7AC: BE82007E
	v_cmpx_gt_u32_e32 32, v0                                   // 000000DFA7B0: 7D9800A0
	s_cbranch_execz 632                                        // 000000DFA7B4: BFA50278 <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi2EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x6d98>
	s_mul_i32 s2, s9, 0x1400                                   // 000000DFA7B8: 9602FF09 00001400
	s_mul_hi_u32 s3, s9, 0x1400                                // 000000DFA7C0: 9683FF09 00001400
	s_add_u32 s4, s24, s2                                      // 000000DFA7C8: 80040218
	s_addc_u32 s5, s25, s3                                     // 000000DFA7CC: 82050319
	s_lshl_b32 s14, s1, 7                                      // 000000DFA7D0: 840E8701
	v_lshlrev_b32_e32 v1, 4, v0                                // 000000DFA7D4: 30020084
	s_ashr_i32 s15, s14, 31                                    // 000000DFA7D8: 860F9F0E
	s_mov_b32 s11, 0x76543210                                  // 000000DFA7DC: BE8B00FF 76543210
	s_lshl_b64 s[2:3], s[14:15], 2                             // 000000DFA7E4: 8482820E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000DFA7E8: BF870009
	s_add_u32 s2, s4, s2                                       // 000000DFA7EC: 80020204
	s_addc_u32 s3, s5, s3                                      // 000000DFA7F0: 82030305
	s_clause 0x7                                               // 000000DFA7F4: BF850007
	global_load_b32 v7, v1, s[2:3] glc                         // 000000DFA7F8: DC524000 07020001
	global_load_b32 v8, v1, s[2:3] offset:2560 glc             // 000000DFA800: DC524A00 08020001
	global_load_b32 v9, v1, s[2:3] offset:4 glc                // 000000DFA808: DC524004 09020001
	global_load_b32 v10, v1, s[2:3] offset:2564 glc            // 000000DFA810: DC524A04 0A020001
	global_load_b32 v11, v1, s[2:3] offset:8 glc               // 000000DFA818: DC524008 0B020001
	global_load_b32 v12, v1, s[2:3] offset:2568 glc            // 000000DFA820: DC524A08 0C020001
	global_load_b32 v13, v1, s[2:3] offset:12 glc              // 000000DFA828: DC52400C 0D020001
	global_load_b32 v14, v1, s[2:3] offset:2572 glc            // 000000DFA830: DC524A0C 0E020001
	v_lshl_or_b32 v1, v0, 2, s14                               // 000000DFA838: D6560001 00390500
	v_and_b32_e32 v15, 1, v0                                   // 000000DFA840: 361E0081
	v_and_b32_e32 v16, 2, v0                                   // 000000DFA844: 36200082
	v_and_b32_e32 v17, 4, v0                                   // 000000DFA848: 36220084
	v_and_b32_e32 v18, 8, v0                                   // 000000DFA84C: 36240088
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000DFA850: 3404029F
	.long 0xd44c0005                                           // 000000DFA854: D44C0005
	v_cndmask_b32_e32 v1, 16, v0, vcc_lo                       // 000000DFA858: 02020090
	v_lshlrev_b32_e32 v0, 3, v0                                // 000000DFA85C: 30000083
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DFA860: BF870093
	.long 0xd73c0001                                           // 000000DFA864: D73C0001
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 000000DFA868: 02020281
	.long 0xd7006a03                                           // 000000DFA86C: D7006A03
	v_cndmask_b32_e32 v1, s26, v1, vcc_lo                      // 000000DFA870: 0202021A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000DFA874: BF8700D1
	v_add_co_ci_u32_e64 v4, null, s27, v2, vcc_lo              // 000000DFA878: D5207C04 01AA041B
	s_clause 0x1                                               // 000000DFA880: BF850001
	global_load_b64 v[5:6], v[3:4], off                        // 000000DFA884: DC560000 057C0003
	global_load_b64 v[3:4], v[3:4], off offset:1280            // 000000DFA88C: DC560500 037C0003
	.long 0xd7006a01                                           // 000000DFA894: D7006A01
	v_cndmask_b32_e32 v1, s28, v1, vcc_lo                      // 000000DFA898: 0202021C
	v_add_co_ci_u32_e64 v2, null, s29, v2, vcc_lo              // 000000DFA89C: D5207C02 01AA041D
	global_load_b64 v[1:2], v[1:2], off                        // 000000DFA8A4: DC560000 017C0001
	s_waitcnt vmcnt(8)                                         // 000000DFA8AC: BF8923F7
	v_add_f32_e32 v19, v7, v9                                  // 000000DFA8B0: 06261307
	v_sub_f32_e32 v7, v7, v9                                   // 000000DFA8B4: 080E1307
	.long 0xd44a0002                                           // 000000DFA8B8: D44A0002
	v_cndmask_b32_e32 v1, 0, v16, vcc_lo                       // 000000DFA8BC: 02022080
	.long 0xd44a0004                                           // 000000DFA8C0: D44A0004
	v_cndmask_b32_e32 v1, 0, v18, vcc_lo                       // 000000DFA8C4: 02022480
	s_waitcnt vmcnt(4)                                         // 000000DFA8C8: BF8913F7
	v_add_f32_e32 v9, v11, v13                                 // 000000DFA8CC: 06121B0B
	v_sub_f32_e32 v11, v11, v13                                // 000000DFA8D0: 08161B0B
	v_add_f32_e32 v13, v8, v10                                 // 000000DFA8D4: 061A1508
	v_sub_f32_e32 v8, v8, v10                                  // 000000DFA8D8: 08101508
	s_waitcnt vmcnt(3)                                         // 000000DFA8DC: BF890FF7
	v_add_f32_e32 v10, v12, v14                                // 000000DFA8E0: 06141D0C
	v_sub_f32_e32 v12, v12, v14                                // 000000DFA8E4: 08181D0C
	.long 0xd44a0001                                           // 000000DFA8E8: D44A0001
	v_cndmask_b32_e32 v1, 0, v15, vcc_lo                       // 000000DFA8EC: 02021E80
	.long 0xd44a0003                                           // 000000DFA8F0: D44A0003
	v_cndmask_b32_e32 v1, 0, v17, vcc_lo                       // 000000DFA8F4: 02022280
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000DFA8F8: BF870133
	v_add_f32_e32 v15, v8, v12                                 // 000000DFA8FC: 061E1908
	v_sub_f32_e32 v8, v8, v12                                  // 000000DFA900: 08101908
	v_add_f32_e32 v20, v7, v11                                 // 000000DFA904: 06281707
	v_mov_b32_dpp v25, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DFA908: 7E3202FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, s1                          // 000000DFA910: D5010008 20061108
	v_sub_f32_e32 v7, v7, v11                                  // 000000DFA918: 080E1707
	v_add_f32_e32 v11, v13, v10                                // 000000DFA91C: 0616150D
	v_sub_f32_e32 v10, v13, v10                                // 000000DFA920: 0814150D
	v_add_f32_e32 v14, v19, v9                                 // 000000DFA924: 061C1313
	v_add_f32_e32 v8, v8, v25                                  // 000000DFA928: 06103308
	v_mov_b32_dpp v21, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DFA92C: 7E2A02FA FF016107
	v_mov_b32_dpp v22, v11 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DFA934: 7E2C02FA FF01610B
	v_mov_b32_dpp v24, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DFA93C: 7E3002FA FF01610A
	v_mov_b32_dpp v12, v14 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DFA944: 7E1802FA FF01610E
	v_cndmask_b32_e64 v13, -v14, v14, s1                       // 000000DFA94C: D501000D 20061D0E
	v_mov_b32_dpp v14, v20 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DFA954: 7E1C02FA FF016114
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 000000DFA95C: D501000A 2006150A
	v_sub_f32_e32 v9, v19, v9                                  // 000000DFA964: 08121313
	v_cndmask_b32_e64 v19, -v20, v20, s1                       // 000000DFA968: D5010013 20062914
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 000000DFA970: D501000B 2006170B
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 000000DFA978: D5010007 20060F07
	v_add_f32_e32 v10, v10, v24                                // 000000DFA980: 0614310A
	v_mov_b32_dpp v20, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DFA984: 7E2802FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 000000DFA98C: D5010009 20061309
	v_add_f32_e32 v14, v19, v14                                // 000000DFA994: 061C1D13
	v_mov_b32_dpp v23, v15 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DFA998: 7E2E02FA FF01610F
	v_cndmask_b32_e64 v15, -v15, v15, s1                       // 000000DFA9A0: D501000F 20061F0F
	v_dual_add_f32 v11, v11, v22 :: v_dual_add_f32 v12, v13, v12// 000000DFA9A8: C9082D0B 0B0C190D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DFA9B0: BF870004
	v_mov_b32_dpp v22, v14 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DFA9B4: 7E2C02FA FF01620E
	v_cndmask_b32_e64 v14, -v14, v14, s2                       // 000000DFA9BC: D501000E 200A1D0E
	v_add_f32_e32 v9, v9, v20                                  // 000000DFA9C4: 06122909
	v_mov_b32_dpp v20, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DFA9C8: 7E2802FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 000000DFA9D0: D5010008 200A1108
	v_add_f32_e32 v15, v15, v23                                // 000000DFA9D8: 061E2F0F
	v_mov_b32_dpp v13, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DFA9DC: 7E1A02FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s2                       // 000000DFA9E4: D501000B 200A170B
	v_mov_b32_dpp v19, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DFA9EC: 7E2602FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 000000DFA9F4: D501000A 200A150A
	v_add_f32_e32 v7, v7, v21                                  // 000000DFA9FC: 060E2B07
	v_mov_b32_dpp v21, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DFAA00: 7E2A02FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, s2                       // 000000DFAA08: D501000C 200A190C
	v_add_f32_e32 v8, v8, v20                                  // 000000DFAA10: 06102908
	v_mov_b32_dpp v16, v15 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DFAA14: 7E2002FA FF01620F
	v_cndmask_b32_e64 v15, -v15, v15, s2                       // 000000DFAA1C: D501000F 200A1F0F
	v_add_f32_e32 v10, v10, v19                                // 000000DFAA24: 0614270A
	v_mov_b32_dpp v24, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DFAA28: 7E3002FA FF016207
	v_cndmask_b32_e64 v7, -v7, v7, s2                          // 000000DFAA30: D5010007 200A0F07
	v_add_f32_e32 v14, v14, v22                                // 000000DFAA38: 061C2D0E
	v_add_f32_e32 v12, v12, v21                                // 000000DFAA3C: 06182B0C
	v_mov_b32_dpp v19, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DFAA40: 7E2602FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, s3                          // 000000DFAA48: D5010008 200E1108
	v_add_f32_e32 v11, v11, v13                                // 000000DFAA50: 06161B0B
	v_add_f32_e32 v13, v15, v16                                // 000000DFAA54: 061A210F
	v_mov_b32_dpp v23, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DFAA58: 7E2E02FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s2                          // 000000DFAA60: D5010009 200A1309
	v_mov_b32_dpp v17, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DFAA68: 7E2202FA FF01640A
	v_cndmask_b32_e64 v10, -v10, v10, s3                       // 000000DFAA70: D501000A 200E150A
	v_add_f32_e32 v7, v7, v24                                  // 000000DFAA78: 060E3107
	v_mov_b32_dpp v20, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DFAA7C: 7E2802FA FF01640C
	v_mov_b32_dpp v21, v14 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DFAA84: 7E2A02FA FF01640E
	v_cndmask_b32_e64 v14, -v14, v14, s3                       // 000000DFAA8C: D501000E 200E1D0E
	v_cndmask_b32_e64 v12, -v12, v12, s3                       // 000000DFAA94: D501000C 200E190C
	v_add_f32_e32 v8, v8, v19                                  // 000000DFAA9C: 06102708
	v_mov_b32_dpp v15, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DFAAA0: 7E1E02FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s3                       // 000000DFAAA8: D501000B 200E170B
	v_dual_add_f32 v9, v9, v23 :: v_dual_add_f32 v14, v14, v21 // 000000DFAAB0: C9082F09 090E2B0E
	v_mov_b32_dpp v16, v13 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DFAAB8: 7E2002FA FF01640D
	v_cndmask_b32_e64 v13, -v13, v13, s3                       // 000000DFAAC0: D501000D 200E1B0D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DFAAC8: BF870004
	v_dual_add_f32 v11, v11, v15 :: v_dual_add_f32 v12, v12, v20// 000000DFAACC: C9081F0B 0B0C290C
	v_add_f32_e32 v10, v10, v17                                // 000000DFAAD4: 0614230A
	v_mov_b32_dpp v23, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DFAAD8: 7E2E02FA FF016407
	v_cndmask_b32_e64 v7, -v7, v7, s3                          // 000000DFAAE0: D5010007 200E0F07
	v_mov_b32_dpp v22, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DFAAE8: 7E2C02FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 000000DFAAF0: D5010009 200E1309
	v_mov_b32_dpp v17, v10 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DFAAF8: 7E2202FA FF01680A
	v_cndmask_b32_e64 v10, -v10, v10, s4                       // 000000DFAB00: D501000A 2012150A
	v_add_f32_e32 v13, v13, v16                                // 000000DFAB08: 061A210D
	v_mov_b32_dpp v19, v12 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DFAB0C: 7E2602FA FF01680C
	v_mov_b32_dpp v20, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DFAB14: 7E2802FA FF01680E
	v_cndmask_b32_e64 v14, -v14, v14, s4                       // 000000DFAB1C: D501000E 20121D0E
	v_add_f32_e32 v7, v7, v23                                  // 000000DFAB24: 060E2F07
	v_cndmask_b32_e64 v12, -v12, v12, s4                       // 000000DFAB28: D501000C 2012190C
	v_add_f32_e32 v9, v9, v22                                  // 000000DFAB30: 06122D09
	v_mov_b32_dpp v15, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DFAB34: 7E1E02FA FF01680B
	v_cndmask_b32_e64 v11, -v11, v11, s4                       // 000000DFAB3C: D501000B 2012170B
	v_add_f32_e32 v10, v10, v17                                // 000000DFAB44: 0614230A
	v_mov_b32_dpp v16, v13 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DFAB48: 7E2002FA FF01680D
	v_cndmask_b32_e64 v13, -v13, v13, s4                       // 000000DFAB50: D501000D 20121B0D
	v_add_f32_e32 v12, v12, v19                                // 000000DFAB58: 0618270C
	v_add_f32_e32 v14, v14, v20                                // 000000DFAB5C: 061C290E
	v_mov_b32_dpp v22, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DFAB60: 7E2C02FA FF016807
	v_cndmask_b32_e64 v7, -v7, v7, s4                          // 000000DFAB68: D5010007 20120F07
	v_add_f32_e32 v11, v11, v15                                // 000000DFAB70: 06161F0B
	v_mov_b32_dpp v21, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DFAB74: 7E2A02FA FF016809
	v_cndmask_b32_e64 v9, -v9, v9, s4                          // 000000DFAB7C: D5010009 20121309
	v_mov_b32_dpp v18, v8 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DFAB84: 7E2402FA FF016808
	v_add_f32_e32 v7, v7, v22                                  // 000000DFAB8C: 060E2D07
	v_dual_add_f32 v13, v13, v16 :: v_dual_mov_b32 v16, v12    // 000000DFAB90: C910210D 0D10010C
	v_cndmask_b32_e64 v12, -v12, v12, s5                       // 000000DFAB98: D501000C 2016190C
	v_cndmask_b32_e64 v8, -v8, v8, s4                          // 000000DFABA0: D5010008 20121108
	v_add_f32_e32 v9, v9, v21                                  // 000000DFABA8: 06122B09
	v_cndmask_b32_e64 v15, -v11, v11, s5                       // 000000DFABAC: D501000F 2016170B
	v_permlanex16_b32 v16, v16, s11, 0xfedcba98                // 000000DFABB4: D65C0010 03FC1710 FEDCBA98
	v_permlanex16_b32 v11, v11, s11, 0xfedcba98                // 000000DFABC0: D65C000B 03FC170B FEDCBA98
	v_add_f32_e32 v8, v8, v18                                  // 000000DFABCC: 06102508
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000DFABD0: BF870243
	v_dual_add_f32 v12, v12, v16 :: v_dual_mov_b32 v17, v14    // 000000DFABD4: C910210C 0C10010E
	v_cndmask_b32_e64 v14, -v14, v14, s5                       // 000000DFABDC: D501000E 20161D0E
	v_mov_b32_e32 v20, v7                                      // 000000DFABE4: 7E280307
	v_cndmask_b32_e64 v7, -v7, v7, s5                          // 000000DFABE8: D5010007 20160F07
	v_mul_f32_e32 v12, 0x3db504f3, v12                         // 000000DFABF0: 101818FF 3DB504F3
	v_permlanex16_b32 v17, v17, s11, 0xfedcba98                // 000000DFABF8: D65C0011 03FC1711 FEDCBA98
	v_mov_b32_e32 v19, v9                                      // 000000DFAC04: 7E260309
	v_cndmask_b32_e64 v9, -v9, v9, s5                          // 000000DFAC08: D5010009 20161309
	v_permlanex16_b32 v20, v20, s11, 0xfedcba98                // 000000DFAC10: D65C0014 03FC1714 FEDCBA98
	s_waitcnt vmcnt(2)                                         // 000000DFAC1C: BF890BF7
	v_fma_mix_f32 v12, v5, v12, neg(0) op_sel_hi:[1,0,0]       // 000000DFAC20: CC20000C 8A021905
	v_add_f32_e32 v14, v14, v17                                // 000000DFAC28: 061C230E
	v_permlanex16_b32 v19, v19, s11, 0xfedcba98                // 000000DFAC2C: D65C0013 03FC1713 FEDCBA98
	v_dual_mov_b32 v16, v13 :: v_dual_add_f32 v7, v7, v20      // 000000DFAC38: CA08010D 10062907
	v_mov_b32_e32 v20, v8                                      // 000000DFAC40: 7E280308
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000DFAC44: BF870233
	v_dual_mul_f32 v14, 0x3db504f3, v14 :: v_dual_add_f32 v9, v9, v19// 000000DFAC48: C8C81CFF 0E082709 3DB504F3
	v_mov_b32_e32 v19, v10                                     // 000000DFAC54: 7E26030A
	v_cndmask_b32_e64 v8, -v8, v8, s5                          // 000000DFAC58: D5010008 20161108
	v_permlanex16_b32 v20, v20, s11, 0xfedcba98                // 000000DFAC60: D65C0014 03FC1714 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DFAC6C: BF870004
	v_fma_mix_f32 v5, v5, v14, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DFAC70: CC200805 8A021D05
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 000000DFAC78: 101212FF 3DB504F3
	v_cndmask_b32_e64 v10, -v10, v10, s5                       // 000000DFAC80: D501000A 2016150A
	v_permlanex16_b32 v19, v19, s11, 0xfedcba98                // 000000DFAC88: D65C0013 03FC1713 FEDCBA98
	v_add_f32_e32 v8, v8, v20                                  // 000000DFAC94: 06102908
	v_mul_f32_e32 v14, 0xbfb8aa3b, v5                          // 000000DFAC98: 101C0AFF BFB8AA3B
	v_fma_mix_f32 v9, v6, v9, neg(0) op_sel_hi:[1,0,0]         // 000000DFACA0: CC200009 8A021306
	v_permlanex16_b32 v16, v16, s11, 0xfedcba98                // 000000DFACA8: D65C0010 03FC1710 FEDCBA98
	v_add_f32_e32 v10, v10, v19                                // 000000DFACB4: 0614270A
	v_mul_f32_e32 v8, 0x3db504f3, v8                           // 000000DFACB8: 101010FF 3DB504F3
	v_exp_f32_e32 v14, v14                                     // 000000DFACC0: 7E1C4B0E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000DFACC4: BF870292
	v_dual_mul_f32 v7, 0x3db504f3, v7 :: v_dual_mul_f32 v10, 0x3db504f3, v10// 000000DFACC8: C8C60EFF 070A14FF 3DB504F3
	v_add_f32_e32 v14, 1.0, v14                                // 000000DFACD4: 061C1CF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000DFACD8: BF870232
	v_fma_mix_f32 v6, v6, v7, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DFACDC: CC200806 8A020F06
	v_cndmask_b32_e64 v7, -v13, v13, s5                        // 000000DFACE4: D5010007 20161B0D
	v_mul_f32_e32 v13, 0xbfb8aa3b, v12                         // 000000DFACEC: 101A18FF BFB8AA3B
	v_div_scale_f32 v22, null, v14, v14, v5                    // 000000DFACF4: D6FC7C16 04161D0E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DFACFC: BF870224
	v_mul_f32_e32 v18, 0xbfb8aa3b, v6                          // 000000DFAD00: 10240CFF BFB8AA3B
	v_div_scale_f32 v19, s6, v5, v14, v5                       // 000000DFAD08: D6FC0613 04161D05
	v_exp_f32_e32 v13, v13                                     // 000000DFAD10: 7E1A4B0D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DFAD14: BF870113
	v_rcp_f32_e32 v25, v22                                     // 000000DFAD18: 7E325516
	v_exp_f32_e32 v18, v18                                     // 000000DFAD1C: 7E244B12
	v_mul_f32_e32 v17, 0xbfb8aa3b, v9                          // 000000DFAD20: 102212FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000DFAD28: BF870317
	v_add_f32_e32 v13, 1.0, v13                                // 000000DFAD2C: 061A1AF2
	v_fma_f32 v29, -v22, v25, 1.0                              // 000000DFAD30: D613001D 23CA3316
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DFAD38: BF870215
	v_add_f32_e32 v18, 1.0, v18                                // 000000DFAD3C: 062424F2
	v_exp_f32_e32 v17, v17                                     // 000000DFAD40: 7E224B11
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DFAD44: BF870113
	v_div_scale_f32 v21, null, v13, v13, v12                   // 000000DFAD48: D6FC7C15 04321B0D
	v_div_scale_f32 v24, null, v18, v18, v6                    // 000000DFAD50: D6FC7C18 041A2512
	v_div_scale_f32 v32, s8, v6, v18, v6                       // 000000DFAD58: D6FC0820 041A2506
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000DFAD60: BF870312
	v_rcp_f32_e32 v27, v24                                     // 000000DFAD64: 7E365518
	v_add_f32_e32 v17, 1.0, v17                                // 000000DFAD68: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 000000DFAD6C: BF8702A1
	v_div_scale_f32 v23, null, v17, v17, v9                    // 000000DFAD70: D6FC7C17 04262311
	v_div_scale_f32 v20, s7, v9, v17, v9                       // 000000DFAD78: D6FC0714 04262309
	v_fma_f32 v31, -v24, v27, 1.0                              // 000000DFAD80: D613001F 23CA3718
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DFAD88: BF870093
	v_rcp_f32_e32 v26, v23                                     // 000000DFAD8C: 7E345517
	v_fmac_f32_e32 v27, v31, v27                               // 000000DFAD90: 5636371F
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000DFAD94: BF870135
	v_fma_f32 v30, -v23, v26, 1.0                              // 000000DFAD98: D613001E 23CA3517
	v_add_f32_e32 v11, v15, v11                                // 000000DFADA0: 0616170F
	v_rcp_f32_e32 v15, v21                                     // 000000DFADA4: 7E1E5515
	v_dual_fmac_f32 v26, v30, v26 :: v_dual_fmac_f32 v25, v29, v25// 000000DFADA8: C800351E 1A18331D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000DFADB0: BF870291
	v_mul_f32_e32 v30, v20, v26                                // 000000DFADB4: 103C3514
	v_fma_f32 v28, -v21, v15, 1.0                              // 000000DFADB8: D613001C 23CA1F15
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DFADC0: BF8701A2
	v_fma_f32 v35, -v23, v30, v20                              // 000000DFADC4: D6130023 24523D17
	v_mul_f32_e32 v11, 0x3db504f3, v11                         // 000000DFADCC: 101616FF 3DB504F3
	v_fmac_f32_e32 v15, v28, v15                               // 000000DFADD4: 561E1F1C
	v_add_f32_e32 v7, v7, v16                                  // 000000DFADD8: 060E2107
	v_div_scale_f32 v16, vcc_lo, v12, v13, v12                 // 000000DFADDC: D6FC6A10 04321B0C
	v_fmac_f32_e32 v30, v35, v26                               // 000000DFADE4: 563C3523
	s_waitcnt vmcnt(1)                                         // 000000DFADE8: BF8907F7
	v_fma_mix_f32 v11, v3, v11, neg(0) op_sel_hi:[1,0,0]       // 000000DFADEC: CC20000B 8A021703
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DFADF4: BF870193
	v_mul_f32_e32 v28, v16, v15                                // 000000DFADF8: 10381F10
	v_fma_f32 v20, -v23, v30, v20                              // 000000DFADFC: D6130014 24523D17
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DFAE04: BF870092
	v_fma_f32 v33, -v21, v28, v16                              // 000000DFAE08: D6130021 24423915
	v_dual_mul_f32 v29, v19, v25 :: v_dual_fmac_f32 v28, v33, v15// 000000DFAE10: C8C03313 1D1C1F21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DFAE18: BF870111
	v_fma_f32 v34, -v22, v29, v19                              // 000000DFAE1C: D6130022 244E3B16
	v_fma_f32 v16, -v21, v28, v16                              // 000000DFAE24: D6130010 24423915
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DFAE2C: BF870112
	v_fmac_f32_e32 v29, v34, v25                               // 000000DFAE30: 563A3322
	v_div_fmas_f32 v15, v16, v15, v28                          // 000000DFAE34: D637000F 04721F10
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DFAE3C: BF8700A2
	v_fma_f32 v19, -v22, v29, v19                              // 000000DFAE40: D6130013 244E3B16
	s_mov_b32 vcc_lo, s6                                       // 000000DFAE48: BEEA0006
	v_div_fmas_f32 v16, v19, v25, v29                          // 000000DFAE4C: D6370010 04763313
	s_mov_b32 vcc_lo, s7                                       // 000000DFAE54: BEEA0007
	v_div_fmas_f32 v19, v20, v26, v30                          // 000000DFAE58: D6370013 047A3514
	s_mov_b32 vcc_lo, s8                                       // 000000DFAE60: BEEA0008
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DFAE64: BF870112
	v_div_fixup_f32 v5, v16, v14, v5                           // 000000DFAE68: D6270005 04161D10
	v_div_fixup_f32 v9, v19, v17, v9                           // 000000DFAE70: D6270009 04262313
	v_mul_f32_e32 v7, 0x3db504f3, v7                           // 000000DFAE78: 100E0EFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DFAE80: BF870001
	v_fma_mix_f32 v3, v3, v7, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DFAE84: CC200803 8A020F03
	v_fma_mix_f32 v7, v4, v8, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DFAE8C: CC200807 8A021104
	v_div_fixup_f32 v8, v15, v13, v12                          // 000000DFAE94: D6270008 04321B0F
	v_mul_f32_e32 v31, v32, v27                                // 000000DFAE9C: 103E3720
	v_fma_mix_f32 v4, v4, v10, neg(0) op_sel_hi:[1,0,0]        // 000000DFAEA0: CC200004 8A021504
	v_mul_f32_e32 v3, v3, v5                                   // 000000DFAEA8: 10060B03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DFAEAC: BF870193
	v_fma_f32 v36, -v24, v31, v32                              // 000000DFAEB0: D6130024 24823F18
	v_mul_f32_e32 v4, v4, v9                                   // 000000DFAEB8: 10081304
	s_waitcnt vmcnt(0)                                         // 000000DFAEBC: BF8903F7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DFAEC0: BF870193
	v_fma_mix_f32 v3, v1, v3, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DFAEC4: CC200803 8A020701
	v_fmac_f32_e32 v31, v36, v27                               // 000000DFAECC: 563E3724
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DFAED0: BF870091
	v_fma_f32 v21, -v24, v31, v32                              // 000000DFAED4: D6130015 24823F18
	v_div_fmas_f32 v20, v21, v27, v31                          // 000000DFAEDC: D6370014 047E3715
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DFAEE4: BF870091
	v_div_fixup_f32 v6, v20, v18, v6                           // 000000DFAEE8: D6270006 041A2514
	v_mul_f32_e32 v5, v7, v6                                   // 000000DFAEF0: 100A0D07
	v_mul_f32_e32 v6, v11, v8                                  // 000000DFAEF4: 100C110B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DFAEF8: BF870112
	v_fma_mix_f32 v5, v2, v5, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DFAEFC: CC200805 8A020B02
	v_fma_mix_f32 v7, v6, v1, v3 op_sel_hi:[0,1,0]             // 000000DFAF04: CC200007 140E0306
	v_fma_mix_f32 v1, v6, v1, -v3 op_sel_hi:[0,1,0]            // 000000DFAF0C: CC200001 940E0306
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DFAF14: BF8700A3
	v_fma_mix_f32 v8, v4, v2, v5 op_sel_hi:[0,1,0]             // 000000DFAF18: CC200008 14160504
	v_fma_mix_f32 v2, v4, v2, -v5 op_sel_hi:[0,1,0]            // 000000DFAF20: CC200002 94160504
	v_dual_add_f32 v3, v7, v8 :: v_dual_add_f32 v4, v1, v2     // 000000DFAF28: C9081107 03040501
	v_sub_f32_e32 v5, v7, v8                                   // 000000DFAF30: 080A1107
	v_sub_f32_e32 v1, v1, v2                                   // 000000DFAF34: 08020501
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DFAF38: BF870003
	v_mov_b32_dpp v2, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DFAF3C: 7E0402FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 000000DFAF44: D5010003 20060703
	v_mov_b32_dpp v6, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DFAF4C: 7E0C02FA FF016104
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000DFAF54: D5010004 20060904
	v_mov_b32_dpp v7, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DFAF5C: 7E0E02FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, s1                          // 000000DFAF64: D5010005 20060B05
	v_add_f32_e32 v2, v3, v2                                   // 000000DFAF6C: 06040503
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DFAF70: BF870112
	v_dual_add_f32 v3, v4, v6 :: v_dual_add_f32 v4, v5, v7     // 000000DFAF74: C9080D04 03040F05
	v_mov_b32_dpp v5, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DFAF7C: 7E0A02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s2                          // 000000DFAF84: D5010002 200A0502
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DFAF8C: BF8701A3
	v_mov_b32_dpp v7, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DFAF90: 7E0E02FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s2                          // 000000DFAF98: D5010004 200A0904
	v_add_f32_e32 v2, v2, v5                                   // 000000DFAFA0: 06040B02
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DFAFA4: BF870112
	v_add_f32_e32 v4, v4, v7                                   // 000000DFAFA8: 06080F04
	v_mov_b32_dpp v5, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DFAFAC: 7E0A02FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 000000DFAFB4: D5010002 200E0502
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DFAFBC: BF8701A3
	v_mov_b32_dpp v7, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DFAFC0: 7E0E02FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000DFAFC8: D5010004 200E0904
	v_add_f32_e32 v2, v2, v5                                   // 000000DFAFD0: 06040B02
	v_mov_b32_dpp v8, v1 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DFAFD4: 7E1002FA FF016101
	v_cndmask_b32_e64 v1, -v1, v1, s1                          // 000000DFAFDC: D5010001 20060301
	s_mov_b32 s1, 0x3db504f3                                   // 000000DFAFE4: BE8100FF 3DB504F3
	v_add_f32_e32 v4, v4, v7                                   // 000000DFAFEC: 06080F04
	v_mov_b32_dpp v5, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DFAFF0: 7E0A02FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s4                          // 000000DFAFF8: D5010002 20120502
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DFB000: BF8701A3
	v_mov_b32_dpp v7, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DFB004: 7E0E02FA FF016804
	v_cndmask_b32_e64 v4, -v4, v4, s4                          // 000000DFB00C: D5010004 20120904
	v_dual_add_f32 v1, v1, v8 :: v_dual_add_f32 v2, v2, v5     // 000000DFB014: C9081101 01020B02
	v_mov_b32_dpp v6, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DFB01C: 7E0C02FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s2                          // 000000DFB024: D5010003 200A0703
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DFB02C: BF870214
	v_add_f32_e32 v4, v4, v7                                   // 000000DFB030: 06080F04
	v_mov_b32_dpp v8, v1 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DFB034: 7E1002FA FF016201
	v_cndmask_b32_e64 v1, -v1, v1, s2                          // 000000DFB03C: D5010001 200A0301
	v_mov_b32_e32 v5, v2                                       // 000000DFB044: 7E0A0302
	v_cndmask_b32_e64 v2, -v2, v2, s5                          // 000000DFB048: D5010002 20160502
	v_mov_b32_e32 v7, v4                                       // 000000DFB050: 7E0E0304
	v_cndmask_b32_e64 v4, -v4, v4, s5                          // 000000DFB054: D5010004 20160904
	v_add_f32_e32 v1, v1, v8                                   // 000000DFB05C: 06021101
	v_permlanex16_b32 v5, v5, s11, 0xfedcba98                  // 000000DFB060: D65C0005 03FC1705 FEDCBA98
	s_mul_hi_u32 s2, s9, 0x500                                 // 000000DFB06C: 9682FF09 00000500
	v_permlanex16_b32 v7, v7, s11, 0xfedcba98                  // 000000DFB074: D65C0007 03FC1707 FEDCBA98
	s_mulk_i32 s9, 0x500                                       // 000000DFB080: B8090500
	v_mov_b32_dpp v8, v1 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DFB084: 7E1002FA FF016401
	v_cndmask_b32_e64 v1, -v1, v1, s3                          // 000000DFB08C: D5010001 200E0301
	v_add_f32_e32 v2, v2, v5                                   // 000000DFB094: 06040B02
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DFB098: BF870092
	v_dual_add_f32 v4, v4, v7 :: v_dual_add_f32 v1, v1, v8     // 000000DFB09C: C9080F04 04001101
	v_mov_b32_dpp v8, v1 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DFB0A4: 7E1002FA FF016801
	v_cndmask_b32_e64 v1, -v1, v1, s4                          // 000000DFB0AC: D5010001 20120301
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DFB0B4: BF870091
	v_add_f32_e32 v1, v1, v8                                   // 000000DFB0B8: 06021101
	v_dual_add_f32 v3, v3, v6 :: v_dual_mov_b32 v8, v1         // 000000DFB0BC: C9100D03 03080101
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000DFB0C4: BF870231
	v_mov_b32_dpp v6, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DFB0C8: 7E0C02FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 000000DFB0D0: D5010003 200E0703
	v_cndmask_b32_e64 v1, -v1, v1, s5                          // 000000DFB0D8: D5010001 20160301
	v_permlanex16_b32 v8, v8, s11, 0xfedcba98                  // 000000DFB0E0: D65C0008 03FC1708 FEDCBA98
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DFB0EC: BF870113
	v_add_f32_e32 v3, v3, v6                                   // 000000DFB0F0: 06060D03
	v_add_f32_e32 v5, v1, v8                                   // 000000DFB0F4: 060A1101
	v_fma_mixlo_f16 v1, v2, s1, 0                              // 000000DFB0F8: CC210001 02000302
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 000000DFB100: BF8701D3
	v_mov_b32_dpp v6, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DFB104: 7E0C02FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s4                          // 000000DFB10C: D5010003 20120703
	s_add_u32 s4, s30, s9                                      // 000000DFB114: 8004091E
	v_fma_mixlo_f16 v2, v4, s1, 0                              // 000000DFB118: CC210002 02000304
	v_fma_mixhi_f16 v2, v5, s1, 0                              // 000000DFB120: CC220002 02000305
	v_add_f32_e32 v3, v3, v6                                   // 000000DFB128: 06060D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000DFB12C: BF870141
	v_mov_b32_e32 v6, v3                                       // 000000DFB130: 7E0C0303
	v_cndmask_b32_e64 v3, -v3, v3, s5                          // 000000DFB134: D5010003 20160703
	s_addc_u32 s5, s31, s2                                     // 000000DFB13C: 8205021F
	s_lshl_b64 s[2:3], s[14:15], 1                             // 000000DFB140: 8482810E
	v_permlanex16_b32 v6, v6, s11, 0xfedcba98                  // 000000DFB144: D65C0006 03FC1706 FEDCBA98
	s_add_u32 s2, s4, s2                                       // 000000DFB150: 80020204
	s_addc_u32 s3, s5, s3                                      // 000000DFB154: 82030305
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DFB158: BF870091
	v_add_f32_e32 v3, v3, v6                                   // 000000DFB15C: 06060D03
	v_fma_mixhi_f16 v1, v3, s1, 0                              // 000000DFB160: CC220001 02000303
	global_store_b64 v0, v[1:2], s[2:3]                        // 000000DFB168: DC6E0000 00020100
	s_and_b32 exec_lo, exec_lo, s0                             // 000000DFB170: 8B7E007E
	s_cbranch_execz 8                                          // 000000DFB174: BFA50008 <_ZN7halogen12_GLOBAL__N_113k_i4r_rows_glILi2EEEvPKhlPKDF16_PKiPfS5_S5_PDF16_PjNS0_5I4rSdEi+0x6d98>
	s_ashr_i32 s11, s10, 31                                    // 000000DFB178: 860B9F0A
	v_mov_b32_e32 v0, 0                                        // 000000DFB17C: 7E000280
	s_lshl_b64 s[0:1], s[10:11], 2                             // 000000DFB180: 8480820A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000DFB184: BF870009
	s_add_u32 s0, s12, s0                                      // 000000DFB188: 8000000C
	s_addc_u32 s1, s13, s1                                     // 000000DFB18C: 8201010D
	global_store_b32 v0, v0, s[0:1]                            // 000000DFB190: DC6A0000 00000000
	s_nop 0                                                    // 000000DFB198: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000DFB19C: BFB60003
	s_endpgm                                                   // 000000DFB1A0: BFB00000
		...

