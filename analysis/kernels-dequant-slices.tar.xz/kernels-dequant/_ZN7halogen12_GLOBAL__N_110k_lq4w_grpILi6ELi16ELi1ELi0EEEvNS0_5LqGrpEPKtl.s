00000000002b4800 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl>:
; _ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl():
	s_clause 0x3                                               // 0000002B4800: BF850003
	s_load_b32 s3, s[0:1], 0x120                               // 0000002B4804: F40000C0 F8000120
	s_load_b32 s4, s[0:1], 0x88                                // 0000002B480C: F4000100 F8000088
	s_load_b32 s5, s[0:1], 0xd0                                // 0000002B4814: F4000140 F80000D0
	s_load_b32 s6, s[0:1], 0x118                               // 0000002B481C: F4000180 F8000118
	v_dual_mov_b32 v20, 0 :: v_dual_and_b32 v17, 15, v0        // 0000002B4824: CA240080 1410008F
	v_lshrrev_b32_e32 v2, 4, v0                                // 0000002B482C: 32040084
	v_lshlrev_b32_e32 v16, 2, v0                               // 0000002B4830: 30200082
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002B4834: BF870002
	v_dual_mov_b32 v24, 0 :: v_dual_lshlrev_b32 v3, 2, v2      // 0000002B4838: CA220080 18020482
	s_waitcnt lgkmcnt(0)                                       // 0000002B4840: BF89FC07
	s_cmp_gt_i32 s3, 1                                         // 0000002B4844: BF028103
	s_cselect_b32 s7, -1, 0                                    // 0000002B4848: 980780C1
	s_cmp_ge_i32 s2, s4                                        // 0000002B484C: BF030402
	s_cselect_b32 s4, -1, 0                                    // 0000002B4850: 980480C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002B4854: BF870009
	s_and_b32 s4, s7, s4                                       // 0000002B4858: 8B040407
	s_cmp_gt_i32 s3, 2                                         // 0000002B485C: BF028203
	v_cndmask_b32_e64 v1, 0, 1, s4                             // 0000002B4860: D5010001 00110280
	s_cselect_b32 s7, -1, 0                                    // 0000002B4868: 980780C1
	s_cmp_ge_i32 s2, s5                                        // 0000002B486C: BF030502
	s_cselect_b32 s5, -1, 0                                    // 0000002B4870: 980580C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002B4874: BF870009
	s_and_b32 s4, s7, s5                                       // 0000002B4878: 8B040507
	s_cmp_gt_i32 s3, 3                                         // 0000002B487C: BF028303
	v_readfirstlane_b32 s5, v1                                 // 0000002B4880: 7E0A0501
	s_cselect_b32 s3, -1, 0                                    // 0000002B4884: 980380C1
	s_cmp_ge_i32 s2, s6                                        // 0000002B4888: BF030602
	v_lshlrev_b32_e32 v1, 2, v17                               // 0000002B488C: 30022282
	s_cselect_b32 s6, -1, 0                                    // 0000002B4890: 980680C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 0000002B4894: BF8704D9
	s_and_b32 s3, s3, s6                                       // 0000002B4898: 8B030603
	s_and_b32 s4, s4, exec_lo                                  // 0000002B489C: 8B047E04
	s_cselect_b32 s4, 2, s5                                    // 0000002B48A0: 98040582
	s_and_b32 s3, s3, exec_lo                                  // 0000002B48A4: 8B037E03
	s_cselect_b32 s3, 3, s4                                    // 0000002B48A8: 98030483
	s_mulk_i32 s3, 0x48                                        // 0000002B48AC: B8030048
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002B48B0: BF870009
	s_add_u32 s16, s0, s3                                      // 0000002B48B4: 80100300
	s_addc_u32 s17, s1, 0                                      // 0000002B48B8: 82118001
	s_clause 0x1                                               // 0000002B48BC: BF850001
	s_load_b256 s[4:11], s[16:17], 0x18                        // 0000002B48C0: F40C0108 F8000018
	s_load_b64 s[18:19], s[16:17], null                        // 0000002B48C8: F4040488 F8000000
	s_waitcnt lgkmcnt(0)                                       // 0000002B48D0: BF89FC07
	.long 0xd4540003                                           // 0000002B48D4: D4540003
	v_cndmask_b32_e32 v0, s10, v136, vcc_lo                    // 0000002B48D8: 0201100A
	s_and_b32 s12, s3, exec_lo                                 // 0000002B48DC: 8B0C7E03
	s_load_b128 s[12:15], s[0:1], 0x128                        // 0000002B48E0: F4080300 F8000128
	s_clause 0x1                                               // 0000002B48E8: BF850001
	global_load_b32 v1, v1, s[18:19]                           // 0000002B48EC: DC520000 01120001
	global_load_b32 v3, v3, s[18:19]                           // 0000002B48F4: DC520000 03120003
	s_cselect_b32 s24, 1, 16                                   // 0000002B48FC: 98189081
	s_cselect_b32 s0, 0, 4                                     // 0000002B4900: 98008480
	s_add_i32 s25, s24, -1                                     // 0000002B4904: 8119C118
	v_lshrrev_b32_e32 v18, s0, v2                              // 0000002B4908: 32240400
	v_and_b32_e32 v19, s25, v2                                 // 0000002B490C: 36260419
	s_waitcnt vmcnt(1)                                         // 0000002B4910: BF8907F7
	v_bfe_u32 v4, v1, 16, 1                                    // 0000002B4914: D6100004 02052101
	s_waitcnt vmcnt(0)                                         // 0000002B491C: BF8903F7
	v_bfe_u32 v5, v3, 16, 1                                    // 0000002B4920: D6100005 02052103
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002B4928: BF8701A2
	v_add3_u32 v1, v1, v4, 0x7fff                              // 0000002B492C: D6550001 03FE0901 00007FFF
	.long 0x7f083880                                           // 0000002B4938: 7F083880
	v_add3_u32 v3, v3, v5, 0x7fff                              // 0000002B493C: D6550003 03FE0B03 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B4948: BF870093
	.long 0x7e083981                                           // 0000002B494C: 7E083981
	v_and_or_b32 v1, 0xffff0000, v3, v4                        // 0000002B4950: D6570001 041206FF FFFF0000
	ds_store_b32 v16, v1                                       // 0000002B495C: D8340000 00000110
	v_cvt_f32_ubyte0_e32 v1, s24                               // 0000002B4964: 7E022218
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002B4968: BF870291
	v_rcp_iflag_f32_e32 v1, v1                                 // 0000002B496C: 7E025701
	v_readfirstlane_b32 s1, v1                                 // 0000002B4970: 7E020501
	v_mov_b32_e32 v1, 0                                        // 0000002B4974: 7E020280
	s_mul_f32 s22, s1, 0x4f7ffffe                              // 0000002B4978: A216FF01 4F7FFFFE
	s_delay_alu instid0(SALU_CYCLE_3)                          // 0000002B4980: BF87000B
	s_cvt_u32_f32 s26, s22                                     // 0000002B4984: BE9A6716
	s_waitcnt lgkmcnt(0)                                       // 0000002B4988: BF89FC07
	s_barrier                                                  // 0000002B498C: BFBD0000
	buffer_gl0_inv                                             // 0000002B4990: E0AC0000 00000000
	s_load_b32 s20, s[16:17], 0x40                             // 0000002B4998: F4000508 F8000040
	s_waitcnt lgkmcnt(0)                                       // 0000002B49A0: BF89FC07
	s_sub_i32 s0, s2, s20                                      // 0000002B49A4: 81801402
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002B49A8: BF870009
	s_ashr_i32 s1, s0, 31                                      // 0000002B49AC: 86019F00
	s_and_b32 s3, s3, exec_lo                                  // 0000002B49B0: 8B037E03
	s_cselect_b32 s3, 4, 0                                     // 0000002B49B4: 98038084
	s_lshr_b32 s20, s15, 31                                    // 0000002B49B8: 85149F0F
	s_lshl_b64 s[0:1], s[0:1], s3                              // 0000002B49BC: 84800300
	s_add_u32 s20, s14, s20                                    // 0000002B49C0: 8014140E
	s_addc_u32 s21, s15, 0                                     // 0000002B49C4: 8215800F
	s_ashr_i32 s3, s15, 31                                     // 0000002B49C8: 86039F0F
	s_ashr_i64 s[20:21], s[20:21], 1                           // 0000002B49CC: 86948114
	s_lshr_b32 s3, s3, 27                                      // 0000002B49D0: 85039B03
	.long 0xd7000009                                           // 0000002B49D4: D7000009
	v_cndmask_b32_e32 v1, s0, v18, vcc_lo                      // 0000002B49D8: 02022400
	s_add_u32 s22, s14, s3                                     // 0000002B49DC: 8016030E
	s_addc_u32 s23, s15, 0                                     // 0000002B49E0: 8217800F
	s_sub_i32 s3, 0, s24                                       // 0000002B49E4: 81831880
	s_lshr_b64 s[22:23], s[22:23], 5                           // 0000002B49E8: 85968516
	s_mul_i32 s3, s3, s26                                      // 0000002B49EC: 96031A03
	s_add_i32 s23, s25, s22                                    // 0000002B49F0: 81171619
	s_mul_hi_u32 s3, s26, s3                                   // 0000002B49F4: 9683031A
	s_abs_i32 s27, s23                                         // 0000002B49F8: BE9B1517
	s_add_i32 s26, s26, s3                                     // 0000002B49FC: 811A031A
	v_add_co_ci_u32_e64 v10, null, s1, 0, s0                   // 0000002B4A00: D5207C0A 00010001
	s_mul_hi_u32 s3, s27, s26                                  // 0000002B4A08: 96831A1B
	s_ashr_i32 s1, s23, 31                                     // 0000002B4A0C: 86019F17
	s_mul_i32 s0, s3, s24                                      // 0000002B4A10: 96001803
	s_add_i32 s26, s3, 1                                       // 0000002B4A14: 811A8103
	s_sub_i32 s23, s27, s0                                     // 0000002B4A18: 8197001B
	.long 0xd4540000                                           // 0000002B4A1C: D4540000
	v_cndmask_b32_e32 v1, s10, v9, vcc_lo                      // 0000002B4A20: 0202120A
	s_sub_i32 s27, s23, s24                                    // 0000002B4A24: 819B1817
	s_cmp_ge_u32 s23, s24                                      // 0000002B4A28: BF091817
	s_cselect_b32 s3, s26, s3                                  // 0000002B4A2C: 9803031A
	s_cselect_b32 s23, s27, s23                                // 0000002B4A30: 9817171B
	s_add_i32 s26, s3, 1                                       // 0000002B4A34: 811A8103
	s_cmp_ge_u32 s23, s24                                      // 0000002B4A38: BF091817
	v_cndmask_b32_e64 v3, 0, v10, s0                           // 0000002B4A3C: D5010003 00021480
	s_cselect_b32 s3, s26, s3                                  // 0000002B4A44: 9803031A
	v_cndmask_b32_e64 v2, 0, v9, s0                            // 0000002B4A48: D5010002 00021280
	s_xor_b32 s3, s3, s1                                       // 0000002B4A50: 8D030103
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002B4A54: BF870009
	s_sub_i32 s1, s3, s1                                       // 0000002B4A58: 81810103
	s_add_u32 s4, s18, s4                                      // 0000002B4A5C: 80040412
	s_addc_u32 s5, s19, s5                                     // 0000002B4A60: 82050513
	.long 0xd72c0004                                           // 0000002B4A64: D72C0004
	v_cndmask_b32_e32 v0, v3, v20, vcc_lo                      // 0000002B4A68: 02002903
	.long 0xd72c0007                                           // 0000002B4A6C: D72C0007
	v_cndmask_b32_e32 v0, v2, v21, vcc_lo                      // 0000002B4A70: 02002B02
	v_mad_u64_u32 v[11:12], null, v2, s20, s[4:5]              // 0000002B4A74: D6FE7C0B 00102902
	s_add_u32 s6, s18, s6                                      // 0000002B4A7C: 80060612
	.long 0xd72c0006                                           // 0000002B4A80: D72C0006
	v_cndmask_b32_e32 v0, v3, v8, vcc_lo                       // 0000002B4A84: 02001103
	s_addc_u32 s7, s19, s7                                     // 0000002B4A88: 82070713
	.long 0xd72c0008                                           // 0000002B4A8C: D72C0008
	v_cndmask_b32_e32 v0, v2, v9, vcc_lo                       // 0000002B4A90: 02001302
	v_mad_u64_u32 v[13:14], null, v2, s8, s[6:7]               // 0000002B4A94: D6FE7C0D 00181102
	.long 0xd4510003                                           // 0000002B4A9C: D4510003
	v_cndmask_b32_e32 v0, s10, v137, vcc_lo                    // 0000002B4AA0: 0201120A
	v_mov_b32_e32 v2, 0                                        // 0000002B4AA4: 7E040280
	v_add3_u32 v12, v4, v12, v7                                // 0000002B4AA8: D655000C 041E1904
	v_mov_b32_e32 v4, 0                                        // 0000002B4AB0: 7E080280
	.long 0xd72c0005                                           // 0000002B4AB4: D72C0005
	v_cndmask_b32_e32 v1, s1, v19, vcc_lo                      // 0000002B4AB8: 02022601
	v_add3_u32 v23, v6, v14, v8                                // 0000002B4ABC: D6550017 04221D06
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002B4AC4: BF870122
	v_add_nc_u32_e32 v3, s1, v5                                // 0000002B4AC8: 4A060A01
	v_add_nc_u32_e32 v21, v5, v17                              // 0000002B4ACC: 4A2A2305
	v_min_i32_e32 v22, s22, v3                                 // 0000002B4AD0: 222C0616
	v_mov_b32_e32 v3, 0                                        // 0000002B4AD4: 7E060280
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002B4AD8: BF870002
	v_cmp_lt_i32_e32 vcc_lo, v21, v22                          // 0000002B4ADC: 7C822D15
	s_and_saveexec_b32 s4, vcc_lo                              // 0000002B4AE0: BE84206A
	s_cbranch_execz 21                                         // 0000002B4AE4: BFA50015 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x33c>
	v_lshlrev_b32_e32 v1, 1, v21                               // 0000002B4AE8: 30022A81
	v_lshlrev_b32_e32 v3, 4, v21                               // 0000002B4AEC: 30062A84
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002B4AF0: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000002B4AF4: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000002B4AF8: 3408069F
	.long 0xd7000101                                           // 0000002B4AFC: D7000101
	v_cndmask_b32_e32 v1, v13, v1, vcc_lo                      // 0000002B4B00: 0202030D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002B4B04: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v23, v2, s1                  // 0000002B4B08: D5207C02 00060517
	.long 0xd7000103                                           // 0000002B4B10: D7000103
	v_cndmask_b32_e32 v1, v11, v3, vcc_lo                      // 0000002B4B14: 0202070B
	v_add_co_ci_u32_e64 v4, null, v12, v4, s1                  // 0000002B4B18: D5207C04 0006090C
	s_clause 0x1                                               // 0000002B4B20: BF850001
	global_load_d16_b16 v6, v[1:2], off                        // 0000002B4B24: DC820000 067C0001
	global_load_b128 v[1:4], v[3:4], off                       // 0000002B4B2C: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 0000002B4B34: BF8907F7
	v_cvt_f32_f16_e32 v24, v6                                  // 0000002B4B38: 7E301706
	s_or_b32 exec_lo, exec_lo, s4                              // 0000002B4B3C: 8C7E047E
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v27, 0             // 0000002B4B40: CA100080 1A1A0080
	v_dual_mov_b32 v28, 0 :: v_dual_mov_b32 v29, 0             // 0000002B4B48: CA100080 1C1C0080
	v_mov_b32_e32 v25, 0                                       // 0000002B4B50: 7E320280
	s_and_saveexec_b32 s8, vcc_lo                              // 0000002B4B54: BE88206A
	s_cbranch_execz 473                                        // 0000002B4B58: BFA501D9 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0xac0>
	v_dual_mov_b32 v25, 0 :: v_dual_lshlrev_b32 v6, 5, v17     // 0000002B4B5C: CA220080 19062285
	v_dual_mov_b32 v28, 0 :: v_dual_add_nc_u32 v7, 16, v21     // 0000002B4B64: CA200080 1C062A90
	v_dual_mov_b32 v27, 0 :: v_dual_mov_b32 v20, 0             // 0000002B4B6C: CA100080 1B140080
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002B4B74: BF870193
	v_lshl_add_u32 v14, v5, 5, v6                              // 0000002B4B78: D646000E 04190B05
	v_dual_mov_b32 v29, 0 :: v_dual_lshlrev_b32 v30, 4, v7     // 0000002B4B80: CA220080 1D1E0E84
	v_dual_mov_b32 v26, 0 :: v_dual_lshlrev_b32 v31, 1, v7     // 0000002B4B88: CA220080 1A1E0E81
	v_mov_b32_e32 v32, v24                                     // 0000002B4B90: 7E400318
	s_mul_i32 s1, s15, 6                                       // 0000002B4B94: 9601860F
	s_mul_hi_u32 s6, s14, 6                                    // 0000002B4B98: 9686860E
	s_lshl_b64 s[4:5], s[14:15], 2                             // 0000002B4B9C: 8484820E
	s_add_i32 s9, s6, s1                                       // 0000002B4BA0: 81090106
	s_mul_i32 s19, s14, 6                                      // 0000002B4BA4: 9613860E
	s_mov_b32 s18, 0                                           // 0000002B4BA8: BE920080
	s_lshl_b64 s[6:7], s[14:15], 1                             // 0000002B4BAC: 8486810E
	s_branch 419                                               // 0000002B4BB0: BFA001A3 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0xa40>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000002B4BB4: 8C7E0E7E
	v_ashrrev_i32_e32 v15, 31, v14                             // 0000002B4BB8: 341E1C9F
	v_lshrrev_b32_e32 v61, 6, v1                               // 0000002B4BBC: 327A0286
	v_and_b32_e32 v109, 0xff, v3                               // 0000002B4BC0: 36DA06FF 000000FF
	v_lshrrev_b32_e32 v110, 6, v3                              // 0000002B4BC8: 32DC0686
	v_lshrrev_b32_e32 v111, 14, v3                             // 0000002B4BCC: 32DE068E
	.long 0xd73c0021                                           // 0000002B4BD0: D73C0021
	v_cndmask_b32_e32 v1, 1, v14, vcc_lo                       // 0000002B4BD4: 02021C81
	v_and_b32_e32 v15, 0xff, v1                                // 0000002B4BD8: 361E02FF 000000FF
	v_lshrrev_b32_e32 v112, 22, v3                             // 0000002B4BE0: 32E00696
	v_lshrrev_b32_e32 v62, 14, v1                              // 0000002B4BE4: 327C028E
	v_and_b32_e32 v65, 0x3fc, v61                              // 0000002B4BE8: 36827AFF 000003FC
	v_lshrrev_b32_e32 v1, 22, v1                               // 0000002B4BF0: 32020296
	.long 0xd7000161                                           // 0000002B4BF4: D7000161
	v_cndmask_b32_e32 v1, s12, v33, vcc_lo                     // 0000002B4BF8: 0202420C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002B4BFC: BF8701A1
	v_add_co_ci_u32_e64 v98, null, s13, v34, s1                // 0000002B4C00: D5207C62 0006440D
	v_lshlrev_b32_e32 v3, 2, v15                               // 0000002B4C08: 30061E82
	.long 0xd7000163                                           // 0000002B4C0C: D7000163
	v_cndmask_b32_e32 v0, v97, v6, vcc_lo                      // 0000002B4C10: 02000D61
	s_clause 0x1                                               // 0000002B4C14: BF850001
	global_load_b128 v[33:36], v[97:98], off                   // 0000002B4C18: DC5E0000 217C0061
	global_load_b128 v[57:60], v[97:98], off offset:16         // 0000002B4C20: DC5E0010 397C0061
	v_add_co_ci_u32_e64 v100, null, s7, v98, s1                // 0000002B4C28: D5207C64 0006C407
	.long 0xd7000165                                           // 0000002B4C30: D7000165
	v_cndmask_b32_e32 v0, v97, v4, vcc_lo                      // 0000002B4C34: 02000961
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002B4C38: BF8700B1
	v_add_co_ci_u32_e64 v102, null, s5, v98, s1                // 0000002B4C3C: D5207C66 0006C405
	global_load_b128 v[37:40], v[99:100], off                  // 0000002B4C44: DC5E0000 257C0063
	.long 0xd7000167                                           // 0000002B4C4C: D7000167
	v_cndmask_b32_e32 v0, v97, v19, vcc_lo                     // 0000002B4C50: 02002761
	v_add_co_ci_u32_e64 v104, null, s9, v98, s1                // 0000002B4C54: D5207C68 0006C409
	s_clause 0x1                                               // 0000002B4C5C: BF850001
	global_load_b128 v[41:44], v[101:102], off                 // 0000002B4C60: DC5E0000 297C0065
	global_load_b128 v[45:48], v[103:104], off                 // 0000002B4C68: DC5E0000 2D7C0067
	.long 0xd7000169                                           // 0000002B4C70: D7000169
	v_cndmask_b32_e32 v0, v101, v4, vcc_lo                     // 0000002B4C74: 02000965
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002B4C78: BF8700A1
	v_add_co_ci_u32_e64 v106, null, s5, v102, s1               // 0000002B4C7C: D5207C6A 0006CC05
	.long 0xd700016b                                           // 0000002B4C84: D700016B
	v_cndmask_b32_e32 v0, v103, v4, vcc_lo                     // 0000002B4C88: 02000967
	v_add_co_ci_u32_e64 v108, null, s5, v104, s1               // 0000002B4C8C: D5207C6C 0006D005
	s_clause 0x1                                               // 0000002B4C94: BF850001
	global_load_b128 v[49:52], v[105:106], off                 // 0000002B4C98: DC5E0000 317C0069
	global_load_b128 v[53:56], v[107:108], off                 // 0000002B4CA0: DC5E0000 357C006B
	ds_load_b32 v115, v3                                       // 0000002B4CA8: D8D80000 73000003
	ds_load_b32 v117, v65                                      // 0000002B4CB0: D8D80000 75000041
	v_and_b32_e32 v3, 0x3fc, v62                               // 0000002B4CB8: 36067CFF 000003FC
	v_and_b32_e32 v69, 0xff, v2                                // 0000002B4CC0: 368A04FF 000000FF
	v_lshrrev_b32_e32 v73, 6, v2                               // 0000002B4CC8: 32920486
	v_lshrrev_b32_e32 v74, 14, v2                              // 0000002B4CCC: 3294048E
	global_load_b128 v[61:64], v[99:100], off offset:16        // 0000002B4CD0: DC5E0010 3D7C0063
	ds_load_b32 v118, v3                                       // 0000002B4CD8: D8D80000 76000003
	v_lshrrev_b32_e32 v2, 22, v2                               // 0000002B4CE0: 32040496
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000002B4CE4: 360202FF 000003FC
	v_and_b32_e32 v15, 0xff, v4                                // 0000002B4CEC: 361E08FF 000000FF
	v_lshrrev_b32_e32 v113, 6, v4                              // 0000002B4CF4: 32E20886
	v_lshrrev_b32_e32 v114, 14, v4                             // 0000002B4CF8: 32E4088E
	v_lshrrev_b32_e32 v116, 22, v4                             // 0000002B4CFC: 32E80896
	global_load_b128 v[65:68], v[101:102], off offset:16       // 0000002B4D00: DC5E0010 417C0065
	v_lshlrev_b32_e32 v4, 2, v69                               // 0000002B4D08: 30088A82
	global_load_b128 v[69:72], v[103:104], off offset:16       // 0000002B4D0C: DC5E0010 457C0067
	v_and_b32_e32 v81, 0x3fc, v73                              // 0000002B4D14: 36A292FF 000003FC
	v_and_b32_e32 v3, 0x3fc, v74                               // 0000002B4D1C: 360694FF 000003FC
	s_clause 0x1                                               // 0000002B4D24: BF850001
	global_load_b128 v[73:76], v[105:106], off offset:16       // 0000002B4D28: DC5E0010 497C0069
	global_load_b128 v[77:80], v[107:108], off offset:16       // 0000002B4D30: DC5E0010 4D7C006B
	v_and_b32_e32 v2, 0x3fc, v2                                // 0000002B4D38: 360404FF 000003FC
	ds_load_b32 v119, v1                                       // 0000002B4D40: D8D80000 77000001
	ds_load_b32 v120, v4                                       // 0000002B4D48: D8D80000 78000004
	ds_load_b32 v121, v81                                      // 0000002B4D50: D8D80000 79000051
	ds_load_b32 v122, v3                                       // 0000002B4D58: D8D80000 7A000003
	ds_load_b32 v123, v2                                       // 0000002B4D60: D8D80000 7B000002
	s_waitcnt vmcnt(12)                                        // 0000002B4D68: BF8933F7
	v_dual_mov_b32 v4, v8 :: v_dual_mov_b32 v3, v7             // 0000002B4D6C: CA100108 04020107
	v_mov_b32_e32 v2, v6                                       // 0000002B4D74: 7E040306
	s_clause 0x3                                               // 0000002B4D78: BF850003
	global_load_b128 v[81:84], v[97:98], off offset:32         // 0000002B4D7C: DC5E0020 517C0061
	global_load_b128 v[85:88], v[101:102], off offset:32       // 0000002B4D84: DC5E0020 557C0065
	global_load_b128 v[89:92], v[103:104], off offset:32       // 0000002B4D8C: DC5E0020 597C0067
	global_load_b128 v[93:96], v[105:106], off offset:32       // 0000002B4D94: DC5E0020 5D7C0069
	v_lshlrev_b32_e32 v15, 2, v15                              // 0000002B4D9C: 301E1E82
	v_add_nc_u32_e32 v31, 32, v31                              // 0000002B4DA0: 4A3E3EA0
	v_add_nc_u32_e32 v14, 0x200, v14                           // 0000002B4DA4: 4A1C1CFF 00000200
	s_and_b32 s1, exec_lo, vcc_lo                              // 0000002B4DAC: 8B016A7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000002B4DB0: BF8700C9
	s_or_b32 s18, s1, s18                                      // 0000002B4DB4: 8C121201
	s_waitcnt vmcnt(15) lgkmcnt(7)                             // 0000002B4DB8: BF893C77
	v_dot2_f32_bf16 v1, v33, v115, 0                           // 0000002B4DBC: CC1A4001 1A02E721
	s_waitcnt lgkmcnt(6)                                       // 0000002B4DC4: BF89FC67
	v_dot2_f32_bf16 v33, v34, v117, v1                         // 0000002B4DC8: CC1A4021 1C06EB22
	v_mov_b32_e32 v1, v5                                       // 0000002B4DD0: 7E020305
	global_load_b128 v[5:8], v[99:100], off offset:32          // 0000002B4DD4: DC5E0020 057C0063
	s_waitcnt vmcnt(14)                                        // 0000002B4DDC: BF893BF7
	v_dot2_f32_bf16 v34, v37, v115, 0                          // 0000002B4DE0: CC1A4022 1A02E725
	s_waitcnt lgkmcnt(5)                                       // 0000002B4DE8: BF89FC57
	v_dot2_f32_bf16 v33, v35, v118, v33                        // 0000002B4DEC: CC1A4021 1C86ED23
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002B4DF4: BF870002
	v_dot2_f32_bf16 v37, v38, v117, v34                        // 0000002B4DF8: CC1A4025 1C8AEB26
	s_waitcnt vmcnt(13)                                        // 0000002B4E00: BF8937F7
	v_dot2_f32_bf16 v38, v41, v115, 0                          // 0000002B4E04: CC1A4026 1A02E729
	s_waitcnt lgkmcnt(4)                                       // 0000002B4E0C: BF89FC47
	v_dot2_f32_bf16 v124, v36, v119, v33                       // 0000002B4E10: CC1A407C 1C86EF24
	global_load_b128 v[33:36], v[107:108], off offset:32       // 0000002B4E18: DC5E0020 217C006B
	s_waitcnt vmcnt(13)                                        // 0000002B4E20: BF8937F7
	v_dot2_f32_bf16 v41, v45, v115, 0                          // 0000002B4E24: CC1A4029 1A02E72D
	v_dot2_f32_bf16 v37, v39, v118, v37                        // 0000002B4E2C: CC1A4025 1C96ED27
	v_dot2_f32_bf16 v42, v42, v117, v38                        // 0000002B4E34: CC1A402A 1C9AEB2A
	s_waitcnt lgkmcnt(3)                                       // 0000002B4E3C: BF89FC37
	v_dot2_f32_bf16 v57, v57, v120, v124                       // 0000002B4E40: CC1A4039 1DF2F139
	v_dot2_f32_bf16 v41, v46, v117, v41                        // 0000002B4E48: CC1A4029 1CA6EB2E
	v_dot2_f32_bf16 v125, v40, v119, v37                       // 0000002B4E50: CC1A407D 1C96EF28
	v_dot2_f32_bf16 v42, v43, v118, v42                        // 0000002B4E58: CC1A402A 1CAAED2B
	s_clause 0x1                                               // 0000002B4E60: BF850001
	global_load_b128 v[37:40], v[97:98], off offset:48         // 0000002B4E64: DC5E0030 257C0061
	global_load_b128 v[97:100], v[99:100], off offset:48       // 0000002B4E6C: DC5E0030 617C0063
	v_dot2_f32_bf16 v45, v47, v118, v41                        // 0000002B4E74: CC1A402D 1CA6ED2F
	s_waitcnt vmcnt(14)                                        // 0000002B4E7C: BF893BF7
	v_dot2_f32_bf16 v49, v49, v115, 0                          // 0000002B4E80: CC1A4031 1A02E731
	v_dot2_f32_bf16 v126, v44, v119, v42                       // 0000002B4E88: CC1A407E 1CAAEF2C
	s_clause 0x1                                               // 0000002B4E90: BF850001
	global_load_b128 v[41:44], v[101:102], off offset:48       // 0000002B4E94: DC5E0030 297C0065
	global_load_b128 v[101:104], v[103:104], off offset:48     // 0000002B4E9C: DC5E0030 657C0067
	s_waitcnt vmcnt(15)                                        // 0000002B4EA4: BF893FF7
	v_dot2_f32_bf16 v53, v53, v115, 0                          // 0000002B4EA8: CC1A4035 1A02E735
	v_dot2_f32_bf16 v127, v48, v119, v45                       // 0000002B4EB0: CC1A407F 1CB6EF30
	s_clause 0x1                                               // 0000002B4EB8: BF850001
	global_load_b128 v[45:48], v[105:106], off offset:48       // 0000002B4EBC: DC5E0030 2D7C0069
	global_load_b128 v[105:108], v[107:108], off offset:48     // 0000002B4EC4: DC5E0030 697C006B
	v_dot2_f32_bf16 v49, v50, v117, v49                        // 0000002B4ECC: CC1A4031 1CC6EB32
	v_dot2_f32_bf16 v50, v54, v117, v53                        // 0000002B4ED4: CC1A4032 1CD6EB36
	v_lshlrev_b32_e32 v53, 2, v109                             // 0000002B4EDC: 306ADA82
	v_and_b32_e32 v54, 0x3fc, v110                             // 0000002B4EE0: 366CDCFF 000003FC
	v_and_b32_e32 v109, 0x3fc, v111                            // 0000002B4EE8: 36DADEFF 000003FC
	v_dot2_f32_bf16 v49, v51, v118, v49                        // 0000002B4EF0: CC1A4031 1CC6ED33
	v_dot2_f32_bf16 v50, v55, v118, v50                        // 0000002B4EF8: CC1A4032 1CCAED37
	s_waitcnt vmcnt(16)                                        // 0000002B4F00: BF8943F7
	v_dot2_f32_bf16 v55, v61, v120, v125                       // 0000002B4F04: CC1A4037 1DF6F13D
	v_and_b32_e32 v110, 0x3fc, v112                            // 0000002B4F0C: 36DCE0FF 000003FC
	v_and_b32_e32 v111, 0x3fc, v113                            // 0000002B4F14: 36DEE2FF 000003FC
	v_dot2_f32_bf16 v49, v52, v119, v49                        // 0000002B4F1C: CC1A4031 1CC6EF34
	v_dot2_f32_bf16 v50, v56, v119, v50                        // 0000002B4F24: CC1A4032 1CCAEF38
	s_waitcnt vmcnt(15)                                        // 0000002B4F2C: BF893FF7
	v_dot2_f32_bf16 v52, v65, v120, v126                       // 0000002B4F30: CC1A4034 1DFAF141
	s_waitcnt vmcnt(14)                                        // 0000002B4F38: BF893BF7
	v_dot2_f32_bf16 v56, v69, v120, v127                       // 0000002B4F3C: CC1A4038 1DFEF145
	s_waitcnt lgkmcnt(2)                                       // 0000002B4F44: BF89FC27
	v_dot2_f32_bf16 v55, v62, v121, v55                        // 0000002B4F48: CC1A4037 1CDEF33E
	s_waitcnt vmcnt(13)                                        // 0000002B4F50: BF8937F7
	v_dot2_f32_bf16 v49, v73, v120, v49                        // 0000002B4F54: CC1A4031 1CC6F149
	s_waitcnt vmcnt(12)                                        // 0000002B4F5C: BF8933F7
	v_dot2_f32_bf16 v50, v77, v120, v50                        // 0000002B4F60: CC1A4032 1CCAF14D
	v_and_b32_e32 v112, 0x3fc, v114                            // 0000002B4F68: 36E0E4FF 000003FC
	v_and_b32_e32 v113, 0x3fc, v116                            // 0000002B4F70: 36E2E8FF 000003FC
	ds_load_b32 v51, v53                                       // 0000002B4F78: D8D80000 33000035
	ds_load_b32 v53, v54                                       // 0000002B4F80: D8D80000 35000036
	ds_load_b32 v54, v109                                      // 0000002B4F88: D8D80000 3600006D
	ds_load_b32 v109, v110                                     // 0000002B4F90: D8D80000 6D00006E
	ds_load_b32 v15, v15                                       // 0000002B4F98: D8D80000 0F00000F
	ds_load_b32 v110, v111                                     // 0000002B4FA0: D8D80000 6E00006F
	ds_load_b32 v111, v112                                     // 0000002B4FA8: D8D80000 6F000070
	ds_load_b32 v112, v113                                     // 0000002B4FB0: D8D80000 70000071
	v_dot2_f32_bf16 v57, v58, v121, v57                        // 0000002B4FB8: CC1A4039 1CE6F33A
	v_dot2_f32_bf16 v52, v66, v121, v52                        // 0000002B4FC0: CC1A4034 1CD2F342
	v_dot2_f32_bf16 v56, v70, v121, v56                        // 0000002B4FC8: CC1A4038 1CE2F346
	s_waitcnt lgkmcnt(9)                                       // 0000002B4FD0: BF89FC97
	v_dot2_f32_bf16 v55, v63, v122, v55                        // 0000002B4FD4: CC1A4037 1CDEF53F
	v_dot2_f32_bf16 v49, v74, v121, v49                        // 0000002B4FDC: CC1A4031 1CC6F34A
	v_dot2_f32_bf16 v50, v78, v121, v50                        // 0000002B4FE4: CC1A4032 1CCAF34E
	v_dot2_f32_bf16 v57, v59, v122, v57                        // 0000002B4FEC: CC1A4039 1CE6F53B
	v_dot2_f32_bf16 v52, v67, v122, v52                        // 0000002B4FF4: CC1A4034 1CD2F543
	v_dot2_f32_bf16 v56, v71, v122, v56                        // 0000002B4FFC: CC1A4038 1CE2F547
	s_waitcnt lgkmcnt(8)                                       // 0000002B5004: BF89FC87
	v_dot2_f32_bf16 v55, v64, v123, v55                        // 0000002B5008: CC1A4037 1CDEF740
	v_dot2_f32_bf16 v49, v75, v122, v49                        // 0000002B5010: CC1A4031 1CC6F54B
	v_dot2_f32_bf16 v50, v79, v122, v50                        // 0000002B5018: CC1A4032 1CCAF54F
	v_dot2_f32_bf16 v57, v60, v123, v57                        // 0000002B5020: CC1A4039 1CE6F73C
	v_dot2_f32_bf16 v52, v68, v123, v52                        // 0000002B5028: CC1A4034 1CD2F744
	v_dot2_f32_bf16 v56, v72, v123, v56                        // 0000002B5030: CC1A4038 1CE2F748
	v_dot2_f32_bf16 v49, v76, v123, v49                        // 0000002B5038: CC1A4031 1CC6F74C
	v_dot2_f32_bf16 v50, v80, v123, v50                        // 0000002B5040: CC1A4032 1CCAF750
	s_waitcnt vmcnt(11) lgkmcnt(7)                             // 0000002B5048: BF892C77
	v_dot2_f32_bf16 v57, v81, v51, v57                         // 0000002B504C: CC1A4039 1CE66751
	s_waitcnt vmcnt(10)                                        // 0000002B5054: BF892BF7
	v_dot2_f32_bf16 v52, v85, v51, v52                         // 0000002B5058: CC1A4034 1CD26755
	s_waitcnt vmcnt(8)                                         // 0000002B5060: BF8923F7
	v_dot2_f32_bf16 v49, v93, v51, v49                         // 0000002B5064: CC1A4031 1CC6675D
	s_waitcnt lgkmcnt(6)                                       // 0000002B506C: BF89FC67
	v_dot2_f32_bf16 v57, v82, v53, v57                         // 0000002B5070: CC1A4039 1CE66B52
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002B5078: BF870002
	v_dot2_f32_bf16 v49, v94, v53, v49                         // 0000002B507C: CC1A4031 1CC66B5E
	s_waitcnt vmcnt(7)                                         // 0000002B5084: BF891FF7
	v_dot2_f32_bf16 v5, v5, v51, v55                           // 0000002B5088: CC1A4005 1CDE6705
	v_dot2_f32_bf16 v55, v89, v51, v56                         // 0000002B5090: CC1A4037 1CE26759
	s_waitcnt lgkmcnt(5)                                       // 0000002B5098: BF89FC57
	v_dot2_f32_bf16 v56, v83, v54, v57                         // 0000002B509C: CC1A4038 1CE66D53
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002B50A4: BF870003
	v_dot2_f32_bf16 v5, v6, v53, v5                            // 0000002B50A8: CC1A4005 1C166B06
	v_dot2_f32_bf16 v6, v86, v53, v52                          // 0000002B50B0: CC1A4006 1CD26B56
	v_dot2_f32_bf16 v52, v90, v53, v55                         // 0000002B50B8: CC1A4034 1CDE6B5A
	s_waitcnt vmcnt(6)                                         // 0000002B50C0: BF891BF7
	v_dot2_f32_bf16 v33, v33, v51, v50                         // 0000002B50C4: CC1A4021 1CCA6721
	v_dot2_f32_bf16 v5, v7, v54, v5                            // 0000002B50CC: CC1A4005 1C166D07
	v_dot2_f32_bf16 v6, v87, v54, v6                           // 0000002B50D4: CC1A4006 1C1A6D57
	v_dot2_f32_bf16 v7, v91, v54, v52                          // 0000002B50DC: CC1A4007 1CD26D5B
	s_waitcnt lgkmcnt(4)                                       // 0000002B50E4: BF89FC47
	v_dot2_f32_bf16 v50, v84, v109, v56                        // 0000002B50E8: CC1A4032 1CE2DB54
	v_dot2_f32_bf16 v33, v34, v53, v33                         // 0000002B50F0: CC1A4021 1C866B22
	v_dot2_f32_bf16 v5, v8, v109, v5                           // 0000002B50F8: CC1A4005 1C16DB08
	v_dot2_f32_bf16 v8, v95, v54, v49                          // 0000002B5100: CC1A4008 1CC66D5F
	v_dot2_f32_bf16 v6, v88, v109, v6                          // 0000002B5108: CC1A4006 1C1ADB58
	v_dot2_f32_bf16 v7, v92, v109, v7                          // 0000002B5110: CC1A4007 1C1EDB5C
	v_dot2_f32_bf16 v33, v35, v54, v33                         // 0000002B5118: CC1A4021 1C866D23
	s_waitcnt vmcnt(5) lgkmcnt(3)                              // 0000002B5120: BF891437
	v_dot2_f32_bf16 v34, v37, v15, v50                         // 0000002B5124: CC1A4022 1CCA1F25
	v_dot2_f32_bf16 v8, v96, v109, v8                          // 0000002B512C: CC1A4008 1C22DB60
	s_waitcnt vmcnt(4)                                         // 0000002B5134: BF8913F7
	v_dot2_f32_bf16 v5, v97, v15, v5                           // 0000002B5138: CC1A4005 1C161F61
	s_waitcnt vmcnt(3)                                         // 0000002B5140: BF890FF7
	v_dot2_f32_bf16 v6, v41, v15, v6                           // 0000002B5144: CC1A4006 1C1A1F29
	v_dot2_f32_bf16 v33, v36, v109, v33                        // 0000002B514C: CC1A4021 1C86DB24
	s_waitcnt vmcnt(2)                                         // 0000002B5154: BF890BF7
	v_dot2_f32_bf16 v7, v101, v15, v7                          // 0000002B5158: CC1A4007 1C1E1F65
	s_waitcnt vmcnt(1)                                         // 0000002B5160: BF8907F7
	v_dot2_f32_bf16 v8, v45, v15, v8                           // 0000002B5164: CC1A4008 1C221F2D
	s_waitcnt lgkmcnt(2)                                       // 0000002B516C: BF89FC27
	v_dot2_f32_bf16 v34, v38, v110, v34                        // 0000002B5170: CC1A4022 1C8ADD26
	v_dot2_f32_bf16 v5, v98, v110, v5                          // 0000002B5178: CC1A4005 1C16DD62
	s_waitcnt vmcnt(0)                                         // 0000002B5180: BF8903F7
	v_dot2_f32_bf16 v15, v105, v15, v33                        // 0000002B5184: CC1A400F 1C861F69
	v_dot2_f32_bf16 v6, v42, v110, v6                          // 0000002B518C: CC1A4006 1C1ADD2A
	v_dot2_f32_bf16 v7, v102, v110, v7                         // 0000002B5194: CC1A4007 1C1EDD66
	v_dot2_f32_bf16 v8, v46, v110, v8                          // 0000002B519C: CC1A4008 1C22DD2E
	s_waitcnt lgkmcnt(1)                                       // 0000002B51A4: BF89FC17
	v_dot2_f32_bf16 v34, v39, v111, v34                        // 0000002B51A8: CC1A4022 1C8ADF27
	v_dot2_f32_bf16 v15, v106, v110, v15                       // 0000002B51B0: CC1A400F 1C3EDD6A
	v_dot2_f32_bf16 v5, v99, v111, v5                          // 0000002B51B8: CC1A4005 1C16DF63
	v_dot2_f32_bf16 v6, v43, v111, v6                          // 0000002B51C0: CC1A4006 1C1ADF2B
	v_dot2_f32_bf16 v7, v103, v111, v7                         // 0000002B51C8: CC1A4007 1C1EDF67
	v_dot2_f32_bf16 v8, v47, v111, v8                          // 0000002B51D0: CC1A4008 1C22DF2F
	v_dot2_f32_bf16 v15, v107, v111, v15                       // 0000002B51D8: CC1A400F 1C3EDF6B
	s_waitcnt lgkmcnt(0)                                       // 0000002B51E0: BF89FC07
	v_dot2_f32_bf16 v33, v40, v112, v34                        // 0000002B51E4: CC1A4021 1C8AE128
	v_dot2_f32_bf16 v5, v100, v112, v5                         // 0000002B51EC: CC1A4005 1C16E164
	v_dot2_f32_bf16 v6, v44, v112, v6                          // 0000002B51F4: CC1A4006 1C1AE12C
	v_dot2_f32_bf16 v7, v104, v112, v7                         // 0000002B51FC: CC1A4007 1C1EE168
	v_dot2_f32_bf16 v8, v48, v112, v8                          // 0000002B5204: CC1A4008 1C22E130
	v_dot2_f32_bf16 v15, v108, v112, v15                       // 0000002B520C: CC1A400F 1C3EE16C
	v_dual_fmac_f32 v25, v24, v33 :: v_dual_add_nc_u32 v30, 0x100, v30// 0000002B5214: C8204318 191E3CFF 00000100
	v_fmac_f32_e32 v29, v24, v5                                // 0000002B5220: 563A0B18
	v_fmac_f32_e32 v28, v24, v6                                // 0000002B5224: 56380D18
	v_fmac_f32_e32 v27, v24, v7                                // 0000002B5228: 56360F18
	v_fmac_f32_e32 v26, v24, v8                                // 0000002B522C: 56341118
	v_fmac_f32_e32 v20, v24, v15                               // 0000002B5230: 56281F18
	v_mov_b32_e32 v24, v32                                     // 0000002B5234: 7E300320
	s_and_not1_b32 exec_lo, exec_lo, s18                       // 0000002B5238: 917E127E
	s_cbranch_execz 31                                         // 0000002B523C: BFA5001F <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0xabc>
	s_waitcnt vmcnt(0)                                         // 0000002B5240: BF8903F7
	v_dual_mov_b32 v6, v2 :: v_dual_add_nc_u32 v21, 16, v21    // 0000002B5244: CA200102 06142A90
	v_dual_mov_b32 v5, v1 :: v_dual_mov_b32 v8, v4             // 0000002B524C: CA100101 05080104
	v_mov_b32_e32 v7, v3                                       // 0000002B5254: 7E0E0303
	s_mov_b32 s14, exec_lo                                     // 0000002B5258: BE8E007E
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002B525C: BF870003
	v_cmp_ge_i32_e32 vcc_lo, v21, v22                          // 0000002B5260: 7C8C2D15
	.long 0xd4c1007e                                           // 0000002B5264: D4C1007E
	v_cndmask_b32_e32 v1, v21, v22, vcc_lo                     // 0000002B5268: 02022D15
	s_cbranch_execz 65105                                      // 0000002B526C: BFA5FE51 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x3b4>
	v_ashrrev_i32_e32 v6, 31, v31                              // 0000002B5270: 340C3E9F
	v_ashrrev_i32_e32 v8, 31, v30                              // 0000002B5274: 34103C9F
	.long 0xd7000105                                           // 0000002B5278: D7000105
	v_cndmask_b32_e32 v1, v13, v31, vcc_lo                     // 0000002B527C: 02023F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002B5280: BF8700A1
	v_add_co_ci_u32_e64 v6, null, v23, v6, s1                  // 0000002B5284: D5207C06 00060D17
	.long 0xd7000107                                           // 0000002B528C: D7000107
	v_cndmask_b32_e32 v1, v11, v30, vcc_lo                     // 0000002B5290: 02023D0B
	v_add_co_ci_u32_e64 v8, null, v12, v8, s1                  // 0000002B5294: D5207C08 0006110C
	s_clause 0x1                                               // 0000002B529C: BF850001
	global_load_d16_b16 v15, v[5:6], off                       // 0000002B52A0: DC820000 0F7C0005
	global_load_b128 v[5:8], v[7:8], off                       // 0000002B52A8: DC5E0000 057C0007
	s_waitcnt vmcnt(1)                                         // 0000002B52B0: BF8907F7
	v_cvt_f32_f16_e32 v32, v15                                 // 0000002B52B4: 7E40170F
	s_branch 65086                                             // 0000002B52B8: BFA0FE3E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x3b4>
	s_or_b32 exec_lo, exec_lo, s18                             // 0000002B52BC: 8C7E127E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000002B52C0: BF870149
	s_or_b32 exec_lo, exec_lo, s8                              // 0000002B52C4: 8C7E087E
	s_waitcnt vmcnt(0)                                         // 0000002B52C8: BF8903F7
	.long 0xd71f0001                                           // 0000002B52CC: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000002B52D0: 020100C1
	.long 0xd44a0001                                           // 0000002B52D4: D44A0001
	v_cndmask_b32_e32 v1, 0, v17, vcc_lo                       // 0000002B52D8: 02022280
	v_xor_b32_e32 v2, 8, v1                                    // 0000002B52DC: 3A040288
	v_xor_b32_e32 v8, 4, v1                                    // 0000002B52E0: 3A100284
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002B52E4: BF8701A2
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000002B52E8: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 0000002B52EC: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 0000002B52F0: 7C9810A0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002B52F4: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000002B52F8: 30040482
	ds_bpermute_b32 v3, v2, v25                                // 0000002B52FC: DACC0000 03001902
	s_waitcnt lgkmcnt(0)                                       // 0000002B5304: BF89FC07
	v_add_f32_e32 v3, v25, v3                                  // 0000002B5308: 06060719
	ds_bpermute_b32 v7, v2, v26                                // 0000002B530C: DACC0000 07001A02
	v_cndmask_b32_e32 v8, v1, v8, vcc_lo                       // 0000002B5314: 02101101
	ds_bpermute_b32 v5, v2, v28                                // 0000002B5318: DACC0000 05001C02
	ds_bpermute_b32 v6, v2, v27                                // 0000002B5320: DACC0000 06001B02
	ds_bpermute_b32 v4, v2, v29                                // 0000002B5328: DACC0000 04001D02
	ds_bpermute_b32 v2, v2, v20                                // 0000002B5330: DACC0000 02001402
	s_waitcnt lgkmcnt(4)                                       // 0000002B5338: BF89FC47
	v_dual_add_f32 v7, v26, v7 :: v_dual_lshlrev_b32 v8, 2, v8 // 0000002B533C: C9220F1A 07081082
	s_waitcnt lgkmcnt(3)                                       // 0000002B5344: BF89FC37
	v_add_f32_e32 v5, v28, v5                                  // 0000002B5348: 060A0B1C
	s_waitcnt lgkmcnt(0)                                       // 0000002B534C: BF89FC07
	v_add_f32_e32 v2, v20, v2                                  // 0000002B5350: 06040514
	ds_bpermute_b32 v11, v8, v3                                // 0000002B5354: DACC0000 0B000308
	v_xor_b32_e32 v20, 2, v1                                   // 0000002B535C: 3A280282
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002B5360: BF870001
	v_cmp_gt_u32_e32 vcc_lo, 32, v20                           // 0000002B5364: 7C9828A0
	s_waitcnt lgkmcnt(0)                                       // 0000002B5368: BF89FC07
	v_dual_cndmask_b32 v20, v1, v20 :: v_dual_add_f32 v3, v3, v11// 0000002B536C: CA482901 14021703
	ds_bpermute_b32 v13, v8, v5                                // 0000002B5374: DACC0000 0D000508
	v_add_f32_e32 v6, v27, v6                                  // 0000002B537C: 060C0D1B
	ds_bpermute_b32 v15, v8, v7                                // 0000002B5380: DACC0000 0F000708
	v_add_f32_e32 v4, v29, v4                                  // 0000002B5388: 0608091D
	s_waitcnt lgkmcnt(1)                                       // 0000002B538C: BF89FC17
	v_add_f32_e32 v5, v5, v13                                  // 0000002B5390: 060A1B05
	ds_bpermute_b32 v14, v8, v6                                // 0000002B5394: DACC0000 0E000608
	s_waitcnt lgkmcnt(1)                                       // 0000002B539C: BF89FC17
	v_dual_add_f32 v7, v7, v15 :: v_dual_lshlrev_b32 v20, 2, v20// 0000002B53A0: C9221F07 07142882
	ds_bpermute_b32 v12, v8, v4                                // 0000002B53A8: DACC0000 0C000408
	ds_bpermute_b32 v8, v8, v2                                 // 0000002B53B0: DACC0000 08000208
	s_waitcnt lgkmcnt(2)                                       // 0000002B53B8: BF89FC27
	v_add_f32_e32 v6, v6, v14                                  // 0000002B53BC: 060C1D06
	ds_bpermute_b32 v14, v20, v7                               // 0000002B53C0: DACC0000 0E000714
	s_waitcnt lgkmcnt(0)                                       // 0000002B53C8: BF89FC07
	v_dual_add_f32 v4, v4, v12 :: v_dual_add_f32 v7, v7, v14   // 0000002B53CC: C9081904 04061D07
	v_add_f32_e32 v2, v2, v8                                   // 0000002B53D4: 06041102
	ds_bpermute_b32 v8, v20, v3                                // 0000002B53D8: DACC0000 08000314
	ds_bpermute_b32 v12, v20, v5                               // 0000002B53E0: DACC0000 0C000514
	ds_bpermute_b32 v11, v20, v4                               // 0000002B53E8: DACC0000 0B000414
	ds_bpermute_b32 v15, v20, v2                               // 0000002B53F0: DACC0000 0F000214
	s_waitcnt lgkmcnt(3)                                       // 0000002B53F8: BF89FC37
	v_add_f32_e32 v3, v3, v8                                   // 0000002B53FC: 06061103
	ds_bpermute_b32 v13, v20, v6                               // 0000002B5400: DACC0000 0D000614
	v_xor_b32_e32 v20, 1, v1                                   // 0000002B5408: 3A280281
	s_waitcnt lgkmcnt(1)                                       // 0000002B540C: BF89FC17
	v_dual_add_f32 v5, v5, v12 :: v_dual_add_f32 v2, v2, v15   // 0000002B5410: C9081905 05021F02
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000002B5418: BF8700C2
	v_cmp_gt_u32_e32 vcc_lo, 32, v20                           // 0000002B541C: 7C9828A0
	v_cndmask_b32_e32 v1, v1, v20, vcc_lo                      // 0000002B5420: 02022901
	s_and_b32 vcc_lo, exec_lo, s3                              // 0000002B5424: 8B6A037E
	s_mov_b32 s3, -1                                           // 0000002B5428: BE8300C1
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000002B542C: 30020282
	s_waitcnt lgkmcnt(0)                                       // 0000002B5430: BF89FC07
	v_add_f32_e32 v6, v6, v13                                  // 0000002B5434: 060C1B06
	ds_bpermute_b32 v13, v1, v5                                // 0000002B5438: DACC0000 0D000501
	ds_bpermute_b32 v8, v1, v3                                 // 0000002B5440: DACC0000 08000301
	ds_bpermute_b32 v15, v1, v7                                // 0000002B5448: DACC0000 0F000701
	ds_bpermute_b32 v20, v1, v2                                // 0000002B5450: DACC0000 14000201
	ds_bpermute_b32 v14, v1, v6                                // 0000002B5458: DACC0000 0E000601
	s_waitcnt lgkmcnt(4)                                       // 0000002B5460: BF89FC47
	v_dual_add_f32 v5, v5, v13 :: v_dual_add_f32 v4, v4, v11   // 0000002B5464: C9081B05 05041704
	s_waitcnt lgkmcnt(3)                                       // 0000002B546C: BF89FC37
	v_add_f32_e32 v11, v3, v8                                  // 0000002B5470: 06161103
	s_waitcnt lgkmcnt(1)                                       // 0000002B5474: BF89FC17
	v_add_f32_e32 v2, v2, v20                                  // 0000002B5478: 06042902
	s_waitcnt lgkmcnt(0)                                       // 0000002B547C: BF89FC07
	v_add_f32_e32 v6, v6, v14                                  // 0000002B5480: 060C1D06
	ds_bpermute_b32 v12, v1, v4                                // 0000002B5484: DACC0000 0C000401
	s_waitcnt lgkmcnt(0)                                       // 0000002B548C: BF89FC07
	v_dual_add_f32 v1, v7, v15 :: v_dual_add_f32 v12, v4, v12  // 0000002B5490: C9081F07 010C1904
	s_cbranch_vccz 429                                         // 0000002B5498: BFA301AD <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1350>
	s_and_saveexec_b32 s3, s1                                  // 0000002B549C: BE832001
	s_cbranch_execz 8                                          // 0000002B54A0: BFA50008 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0xcc4>
	v_lshl_or_b32 v3, v18, 4, v19                              // 0000002B54A4: D6560003 044D0912
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002B54AC: BF870001
	v_mul_u32_u24_e32 v3, 24, v3                               // 0000002B54B0: 16060698
	ds_store_2addr_b64 v3, v[11:12], v[5:6] offset0:128 offset1:129// 0000002B54B4: D9388180 00050B03
	ds_store_b64 v3, v[1:2] offset:1040                        // 0000002B54BC: D9340410 00000103
	s_or_b32 exec_lo, exec_lo, s3                              // 0000002B54C4: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002B54C8: BF870009
	s_mov_b32 s8, exec_lo                                      // 0000002B54CC: BE88007E
	s_waitcnt lgkmcnt(0)                                       // 0000002B54D0: BF89FC07
	s_barrier                                                  // 0000002B54D4: BFBD0000
	buffer_gl0_inv                                             // 0000002B54D8: E0AC0000 00000000
	v_cmpx_gt_u32_e32 6, v0                                    // 0000002B54E0: 7D980086
	s_cbranch_execz 408                                        // 0000002B54E4: BFA50198 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1348>
	s_load_b32 s3, s[16:17], 0x40                              // 0000002B54E8: F40000C8 F8000040
	s_waitcnt lgkmcnt(0)                                       // 0000002B54F0: BF89FC07
	s_sub_i32 s2, s2, s3                                       // 0000002B54F4: 81820302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000002B54F8: BF870499
	s_ashr_i32 s3, s2, 31                                      // 0000002B54FC: 86039F02
	.long 0xd4530004                                           // 0000002B5500: D4530004
	v_cndmask_b32_e32 v0, s10, v2, vcc_lo                      // 0000002B5504: 0200040A
	s_and_b32 vcc_lo, exec_lo, s4                              // 0000002B5508: 8B6A047E
	s_cbranch_vccnz 398                                        // 0000002B550C: BFA4018E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1348>
	v_add_nc_u32_e32 v15, 0x400, v16                           // 0000002B5510: 4A1E20FF 00000400
	s_clause 0x1                                               // 0000002B5518: BF850001
	s_load_b64 s[6:7], s[16:17], 0x38                          // 0000002B551C: F4040188 F8000038
	s_load_b64 s[4:5], s[16:17], 0x8                           // 0000002B5524: F4040108 F8000008
	s_mov_b32 s9, 0                                            // 0000002B552C: BE890080
	s_mov_b32 s13, -1                                          // 0000002B5530: BE8D00C1
	s_mov_b32 s12, 0                                           // 0000002B5534: BE8C0080
	ds_load_2addr_b32 v[3:4], v15 offset1:6                    // 0000002B5538: D8DC0600 0300000F
	ds_load_2addr_b32 v[7:8], v15 offset0:12 offset1:18        // 0000002B5540: D8DC120C 0700000F
	ds_load_2addr_b32 v[13:14], v15 offset0:24 offset1:30      // 0000002B5548: D8DC1E18 0D00000F
	s_waitcnt lgkmcnt(0)                                       // 0000002B5550: BF89FC07
	s_cmp_lt_i32 s7, 3                                         // 0000002B5554: BF048307
	v_add_f32_e32 v3, 0, v3                                    // 0000002B5558: 06060680
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B555C: BF870091
	v_add_f32_e32 v16, v3, v4                                  // 0000002B5560: 06200903
	v_add_f32_e32 v7, v16, v7                                  // 0000002B5564: 060E0F10
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B5568: BF870091
	v_add_f32_e32 v16, v7, v8                                  // 0000002B556C: 06201107
	v_add_f32_e32 v13, v16, v13                                // 0000002B5570: 061A1B10
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002B5574: BF870001
	v_add_f32_e32 v16, v13, v14                                // 0000002B5578: 06201D0D
	ds_load_2addr_b32 v[3:4], v15 offset0:36 offset1:42        // 0000002B557C: D8DC2A24 0300000F
	ds_load_2addr_b32 v[7:8], v15 offset0:48 offset1:54        // 0000002B5584: D8DC3630 0700000F
	ds_load_2addr_b32 v[13:14], v15 offset0:60 offset1:66      // 0000002B558C: D8DC423C 0D00000F
	s_waitcnt lgkmcnt(2)                                       // 0000002B5594: BF89FC27
	v_add_f32_e32 v3, v16, v3                                  // 0000002B5598: 06060710
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002B559C: BF8700A1
	v_add_f32_e32 v3, v3, v4                                   // 0000002B55A0: 06060903
	s_waitcnt lgkmcnt(1)                                       // 0000002B55A4: BF89FC17
	v_add_f32_e32 v7, v3, v7                                   // 0000002B55A8: 060E0F03
	ds_load_2addr_b32 v[3:4], v15 offset0:72 offset1:78        // 0000002B55AC: D8DC4E48 0300000F
	v_add_f32_e32 v7, v7, v8                                   // 0000002B55B4: 060E1107
	s_waitcnt lgkmcnt(1)                                       // 0000002B55B8: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000002B55BC: BF8700C1
	v_add_f32_e32 v13, v7, v13                                 // 0000002B55C0: 061A1B07
	ds_load_2addr_b32 v[7:8], v15 offset0:84 offset1:90        // 0000002B55C4: D8DC5A54 0700000F
	v_add_f32_e32 v13, v13, v14                                // 0000002B55CC: 061A1D0D
	s_waitcnt lgkmcnt(1)                                       // 0000002B55D0: BF89FC17
	v_add_f32_e32 v3, v13, v3                                  // 0000002B55D4: 0606070D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002B55D8: BF8700A1
	v_add_f32_e32 v3, v3, v4                                   // 0000002B55DC: 06060903
	s_waitcnt lgkmcnt(0)                                       // 0000002B55E0: BF89FC07
	v_add_f32_e32 v3, v3, v7                                   // 0000002B55E4: 06060F03
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002B55E8: BF870001
	v_add_f32_e32 v3, v3, v8                                   // 0000002B55EC: 06061103
	s_cbranch_scc1 177                                         // 0000002B55F0: BFA200B1 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x10b8>
	s_cmp_gt_i32 s7, 3                                         // 0000002B55F4: BF028307
	s_cbranch_scc0 111                                         // 0000002B55F8: BFA1006F <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0xfb8>
	s_cmp_gt_i32 s7, 4                                         // 0000002B55FC: BF028407
	s_cbranch_scc0 58                                          // 0000002B5600: BFA1003A <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0xeec>
	s_cmp_eq_u32 s7, 5                                         // 0000002B5604: BF068507
	s_mov_b32 s12, -1                                          // 0000002B5608: BE8C00C1
	s_cbranch_scc0 54                                          // 0000002B560C: BFA10036 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0xee8>
	s_ashr_i32 s14, s2, 31                                     // 0000002B5610: 860E9F02
	s_load_b64 s[12:13], s[16:17], 0x10                        // 0000002B5614: F4040308 F8000010
	s_lshr_b32 s14, s14, 23                                    // 0000002B561C: 850E970E
	s_lshr_b32 s15, s10, 31                                    // 0000002B5620: 850F9F0A
	s_add_i32 s14, s2, s14                                     // 0000002B5624: 810E0E02
	s_add_i32 s18, s10, s15                                    // 0000002B5628: 81120F0A
	s_ashr_i32 s14, s14, 9                                     // 0000002B562C: 860E890E
	s_ashr_i32 s18, s18, 1                                     // 0000002B5630: 86128112
	s_ashr_i32 s15, s14, 31                                    // 0000002B5634: 860F9F0E
	v_mad_i64_i32 v[7:8], null, s18, v0, 0                     // 0000002B5638: D6FF7C07 02020012
	s_lshl_b64 s[14:15], s[14:15], 9                           // 0000002B5640: 848E890E
	v_bfe_u32 v4, v3, 16, 1                                    // 0000002B5644: D6100004 02052103
	s_sub_u32 s18, s2, s14                                     // 0000002B564C: 80920E02
	s_subb_u32 s19, s3, s15                                    // 0000002B5650: 82930F03
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002B5654: BF870119
	.long 0xd4540014                                           // 0000002B5658: D4540014
	v_cndmask_b32_e32 v0, 0x100, v18, vcc_lo                   // 0000002B565C: 020024FF 00000100
	v_add3_u32 v4, v3, v4, 0x7fff                              // 0000002B5664: D6550004 03FE0903 00007FFF
	.long 0xd73c0007                                           // 0000002B5670: D73C0007
	v_cndmask_b32_e32 v1, 1, v7, vcc_lo                        // 0000002B5674: 02020E81
	s_and_b32 s21, s20, exec_lo                                // 0000002B5678: 8B157E14
	s_waitcnt lgkmcnt(0)                                       // 0000002B567C: BF89FC07
	s_cselect_b32 s12, s4, s12                                 // 0000002B5680: 980C0C04
	s_cselect_b32 s21, s5, s13                                 // 0000002B5684: 98150D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B5688: BF870091
	.long 0xd7006a07                                           // 0000002B568C: D7006A07
	v_cndmask_b32_e32 v1, s12, v7, vcc_lo                      // 0000002B5690: 02020E0C
	v_add_co_ci_u32_e64 v8, null, s21, v8, vcc_lo              // 0000002B5694: D5207C08 01AA1015
	s_add_u32 s22, s18, 0xffffff00                             // 0000002B569C: 8016FF12 FFFFFF00
	s_addc_u32 s13, s19, -1                                    // 0000002B56A4: 820DC113
	s_and_b32 s20, s20, exec_lo                                // 0000002B56A8: 8B147E14
	.long 0xd7006a07                                           // 0000002B56AC: D7006A07
	v_cndmask_b32_e32 v0, v7, v14, vcc_lo                      // 0000002B56B0: 02001D07
	s_cselect_b32 s13, s19, s13                                // 0000002B56B4: 980D0D13
	s_cselect_b32 s12, s18, s22                                // 0000002B56B8: 980C1612
	v_add_co_ci_u32_e64 v8, null, s15, v8, vcc_lo              // 0000002B56BC: D5207C08 01AA100F
	s_lshl_b64 s[12:13], s[12:13], 1                           // 0000002B56C4: 848C810C
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B56C8: BF870099
	.long 0xd7006a07                                           // 0000002B56CC: D7006A07
	v_cndmask_b32_e32 v0, v7, v12, vcc_lo                      // 0000002B56D0: 02001907
	v_add_co_ci_u32_e64 v8, null, s13, v8, vcc_lo              // 0000002B56D4: D5207C08 01AA100D
	s_mov_b32 s12, 0                                           // 0000002B56DC: BE8C0080
	global_store_d16_hi_b16 v[7:8], v4, off                    // 0000002B56E0: DC960000 007C0407
	s_mov_b32 s13, 0                                           // 0000002B56E8: BE8D0080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002B56EC: BF870009
	s_and_b32 vcc_lo, exec_lo, s13                             // 0000002B56F0: 8B6A0D7E
	s_cbranch_vccz 47                                          // 0000002B56F4: BFA3002F <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0xfb4>
	v_mul_f32_e32 v4, 0xbfb8aa3b, v3                           // 0000002B56F8: 100806FF BFB8AA3B
	v_mad_u64_u32 v[13:14], null, s10, v0, 0                   // 0000002B5700: D6FE7C0D 0202000A
	s_lshl_b64 s[14:15], s[2:3], 2                             // 0000002B5708: 848E8202
	v_exp_f32_e32 v4, v4                                       // 0000002B570C: 7E084B04
	v_mad_u64_u32 v[14:15], null, s11, v0, v[14:15]            // 0000002B5710: D6FE7C0E 043A000B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B5718: BF870095
	v_add_f32_e32 v4, 1.0, v4                                  // 0000002B571C: 060808F2
	v_div_scale_f32 v7, null, v4, v4, 1.0                      // 0000002B5720: D6FC7C07 03CA0904
	v_div_scale_f32 v17, vcc_lo, 1.0, v4, 1.0                  // 0000002B5728: D6FC6A11 03CA08F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002B5730: BF870292
	v_rcp_f32_e32 v16, v7                                      // 0000002B5734: 7E205507
	v_fma_f32 v8, -v7, v16, 1.0                                // 0000002B5738: D6130008 23CA2107
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B5740: BF870091
	v_fmac_f32_e32 v16, v8, v16                                // 0000002B5744: 56202108
	v_mul_f32_e32 v18, v17, v16                                // 0000002B5748: 10242111
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B574C: BF870091
	v_fma_f32 v8, -v7, v18, v17                                // 0000002B5750: D6130008 24462507
	v_fmac_f32_e32 v18, v8, v16                                // 0000002B5758: 56242108
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002B575C: BF870121
	v_fma_f32 v15, -v7, v18, v17                               // 0000002B5760: D613000F 24462507
	.long 0xd73c0007                                           // 0000002B5768: D73C0007
	v_cndmask_b32_e32 v1, 2, v13, vcc_lo                       // 0000002B576C: 02021A82
	v_div_fmas_f32 v13, v15, v16, v18                          // 0000002B5770: D637000D 044A210F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B5778: BF870092
	.long 0xd7006a07                                           // 0000002B577C: D7006A07
	v_cndmask_b32_e32 v1, s4, v7, vcc_lo                       // 0000002B5780: 02020E04
	v_add_co_ci_u32_e64 v8, null, s5, v8, vcc_lo               // 0000002B5784: D5207C08 01AA1005
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002B578C: BF870193
	v_div_fixup_f32 v4, v13, v4, 1.0                           // 0000002B5790: D6270004 03CA090D
	.long 0xd7006a07                                           // 0000002B5798: D7006A07
	v_cndmask_b32_e32 v0, v7, v14, vcc_lo                      // 0000002B579C: 02001D07
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002B57A0: BF870001
	v_add_co_ci_u32_e64 v8, null, s15, v8, vcc_lo              // 0000002B57A4: D5207C08 01AA100F
	global_store_b32 v[7:8], v4, off                           // 0000002B57AC: DC6A0000 007C0407
	s_mov_b32 s13, 0                                           // 0000002B57B4: BE8D0080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002B57B8: BF870009
	s_and_b32 vcc_lo, exec_lo, s13                             // 0000002B57BC: 8B6A0D7E
	s_cbranch_vccz 60                                          // 0000002B57C0: BFA3003C <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x10b4>
	v_bfe_u32 v4, v3, 16, 1                                    // 0000002B57C4: D6100004 02052103
	s_lshl_b64 s[14:15], s[2:3], 2                             // 0000002B57CC: 848E8202
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B57D0: BF870091
	v_add3_u32 v4, v3, v4, 0x7fff                              // 0000002B57D4: D6550004 03FE0903 00007FFF
	v_and_b32_e32 v4, 0xffff0000, v4                           // 0000002B57E0: 360808FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B57E8: BF870091
	v_mul_f32_e32 v4, s6, v4                                   // 0000002B57EC: 10080806
	v_mul_f32_e32 v4, 0xbfb8aa3b, v4                           // 0000002B57F0: 100808FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002B57F8: BF870291
	v_exp_f32_e32 v4, v4                                       // 0000002B57FC: 7E084B04
	v_add_f32_e32 v4, 1.0, v4                                  // 0000002B5800: 060808F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002B5804: BF870121
	v_div_scale_f32 v7, null, v4, v4, 1.0                      // 0000002B5808: D6FC7C07 03CA0904
	v_div_scale_f32 v16, vcc_lo, 1.0, v4, 1.0                  // 0000002B5810: D6FC6A10 03CA08F2
	v_rcp_f32_e32 v8, v7                                       // 0000002B5818: 7E105507
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B581C: BF870095
	v_fma_f32 v13, -v7, v8, 1.0                                // 0000002B5820: D613000D 23CA1107
	v_fmac_f32_e32 v8, v13, v8                                 // 0000002B5828: 5610110D
	v_mad_u64_u32 v[13:14], null, s10, v0, 0                   // 0000002B582C: D6FE7C0D 0202000A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B5834: BF870092
	v_mul_f32_e32 v17, v16, v8                                 // 0000002B5838: 10221110
	v_fma_f32 v15, -v7, v17, v16                               // 0000002B583C: D613000F 24422307
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002B5844: BF870211
	v_fmac_f32_e32 v17, v15, v8                                // 0000002B5848: 5622110F
	v_mad_u64_u32 v[14:15], null, s11, v0, v[14:15]            // 0000002B584C: D6FE7C0E 043A000B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B5854: BF870092
	v_fma_f32 v7, -v7, v17, v16                                // 0000002B5858: D6130007 24422307
	v_div_fmas_f32 v15, v7, v8, v17                            // 0000002B5860: D637000F 04461107
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002B5868: BF870113
	.long 0xd73c0007                                           // 0000002B586C: D73C0007
	v_cndmask_b32_e32 v1, 2, v13, vcc_lo                       // 0000002B5870: 02021A82
	v_div_fixup_f32 v4, v15, v4, 1.0                           // 0000002B5874: D6270004 03CA090F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B587C: BF870092
	.long 0xd7006a07                                           // 0000002B5880: D7006A07
	v_cndmask_b32_e32 v1, s4, v7, vcc_lo                       // 0000002B5884: 02020E04
	v_add_co_ci_u32_e64 v8, null, s5, v8, vcc_lo               // 0000002B5888: D5207C08 01AA1005
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002B5890: BF870193
	v_add_f32_e32 v4, v4, v4                                   // 0000002B5894: 06080904
	.long 0xd7006a07                                           // 0000002B5898: D7006A07
	v_cndmask_b32_e32 v0, v7, v14, vcc_lo                      // 0000002B589C: 02001D07
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002B58A0: BF870001
	v_add_co_ci_u32_e64 v8, null, s15, v8, vcc_lo              // 0000002B58A4: D5207C08 01AA100F
	global_store_b32 v[7:8], v4, off                           // 0000002B58AC: DC6A0000 007C0407
	s_mov_b32 s13, 0                                           // 0000002B58B4: BE8D0080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002B58B8: BF870009
	s_and_b32 vcc_lo, exec_lo, s13                             // 0000002B58BC: 8B6A0D7E
	s_cbranch_vccz 72                                          // 0000002B58C0: BFA30048 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x11e4>
	s_cmp_gt_i32 s7, 1                                         // 0000002B58C4: BF028107
	s_mov_b32 s9, -1                                           // 0000002B58C8: BE8900C1
	s_cbranch_scc0 63                                          // 0000002B58CC: BFA1003F <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x11cc>
	v_bfe_u32 v4, v3, 16, 1                                    // 0000002B58D0: D6100004 02052103
	s_lshl_b64 s[14:15], s[2:3], 1                             // 0000002B58D8: 848E8102
	s_mov_b32 s9, 0                                            // 0000002B58DC: BE890080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B58E0: BF870091
	v_add3_u32 v4, v3, v4, 0x7fff                              // 0000002B58E4: D6550004 03FE0903 00007FFF
	v_and_b32_e32 v4, 0xffff0000, v4                           // 0000002B58F0: 360808FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B58F8: BF870091
	v_mul_f32_e32 v4, 0xbfb8aa3b, v4                           // 0000002B58FC: 100808FF BFB8AA3B
	v_exp_f32_e32 v4, v4                                       // 0000002B5904: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B5908: BF870095
	v_add_f32_e32 v4, 1.0, v4                                  // 0000002B590C: 060808F2
	v_div_scale_f32 v7, null, v4, v4, 1.0                      // 0000002B5910: D6FC7C07 03CA0904
	v_div_scale_f32 v15, vcc_lo, 1.0, v4, 1.0                  // 0000002B5918: D6FC6A0F 03CA08F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002B5920: BF870292
	v_rcp_f32_e32 v8, v7                                       // 0000002B5924: 7E105507
	v_fma_f32 v13, -v7, v8, 1.0                                // 0000002B5928: D613000D 23CA1107
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002B5930: BF870121
	v_fmac_f32_e32 v8, v13, v8                                 // 0000002B5934: 5610110D
	v_mad_u64_u32 v[13:14], null, s10, v0, 0                   // 0000002B5938: D6FE7C0D 0202000A
	v_mul_f32_e32 v16, v15, v8                                 // 0000002B5940: 1020110F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B5944: BF870091
	v_fma_f32 v17, -v7, v16, v15                               // 0000002B5948: D6130011 243E2107
	v_fmac_f32_e32 v16, v17, v8                                // 0000002B5950: 56201111
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002B5954: BF870121
	v_fma_f32 v7, -v7, v16, v15                                // 0000002B5958: D6130007 243E2107
	v_mad_u64_u32 v[14:15], null, s11, v0, v[14:15]            // 0000002B5960: D6FE7C0E 043A000B
	v_div_fmas_f32 v7, v7, v8, v16                             // 0000002B5968: D6370007 04421107
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002B5970: BF870191
	v_div_fixup_f32 v4, v7, v4, 1.0                            // 0000002B5974: D6270004 03CA0907
	.long 0xd73c0007                                           // 0000002B597C: D73C0007
	v_cndmask_b32_e32 v1, 1, v13, vcc_lo                       // 0000002B5980: 02021A81
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002B5984: BF870112
	v_bfe_u32 v13, v4, 16, 1                                   // 0000002B5988: D610000D 02052104
	.long 0xd7006a07                                           // 0000002B5990: D7006A07
	v_cndmask_b32_e32 v1, s4, v7, vcc_lo                       // 0000002B5994: 02020E04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002B5998: BF870191
	v_add_co_ci_u32_e64 v8, null, s5, v8, vcc_lo               // 0000002B599C: D5207C08 01AA1005
	v_add3_u32 v4, v4, v13, 0x7fff                             // 0000002B59A4: D6550004 03FE1B04 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B59B0: BF870093
	.long 0xd7006a07                                           // 0000002B59B4: D7006A07
	v_cndmask_b32_e32 v0, v7, v14, vcc_lo                      // 0000002B59B8: 02001D07
	v_add_co_ci_u32_e64 v8, null, s15, v8, vcc_lo              // 0000002B59BC: D5207C08 01AA100F
	global_store_d16_hi_b16 v[7:8], v4, off                    // 0000002B59C4: DC960000 007C0407
	s_and_not1_b32 vcc_lo, exec_lo, s9                         // 0000002B59CC: 916A097E
	s_mov_b32 s9, 0                                            // 0000002B59D0: BE890080
	s_cbranch_vccnz 3                                          // 0000002B59D4: BFA40003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x11e4>
	s_cmp_lg_u32 s7, 1                                         // 0000002B59D8: BF078107
	s_mov_b32 s9, -1                                           // 0000002B59DC: BE8900C1
	s_cselect_b32 s12, -1, 0                                   // 0000002B59E0: 980C80C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002B59E4: BF8700A1
	v_bfe_u32 v4, v3, 16, 1                                    // 0000002B59E8: D6100004 02052103
	s_and_b32 vcc_lo, exec_lo, s12                             // 0000002B59F0: 8B6A0C7E
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000002B59F4: D6550003 03FE0903 00007FFF
	s_cbranch_vccz 21                                          // 0000002B5A00: BFA30015 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1258>
	v_mad_u64_u32 v[13:14], null, s10, v0, 0                   // 0000002B5A04: D6FE7C0D 0202000A
	s_lshl_b64 s[12:13], s[2:3], 1                             // 0000002B5A0C: 848C8102
	s_mov_b32 s9, 0                                            // 0000002B5A10: BE890080
	v_mad_u64_u32 v[14:15], null, s11, v0, v[14:15]            // 0000002B5A14: D6FE7C0E 043A000B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B5A1C: BF870091
	.long 0xd73c0007                                           // 0000002B5A20: D73C0007
	v_cndmask_b32_e32 v1, 1, v13, vcc_lo                       // 0000002B5A24: 02021A81
	.long 0xd7006a04                                           // 0000002B5A28: D7006A04
	v_cndmask_b32_e32 v1, s4, v7, vcc_lo                       // 0000002B5A2C: 02020E04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002B5A30: BF870111
	v_add_co_ci_u32_e64 v8, null, s5, v8, vcc_lo               // 0000002B5A34: D5207C08 01AA1005
	.long 0xd7006a07                                           // 0000002B5A3C: D7006A07
	v_cndmask_b32_e32 v0, v4, v12, vcc_lo                      // 0000002B5A40: 02001904
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002B5A44: BF870001
	v_add_co_ci_u32_e64 v8, null, s13, v8, vcc_lo              // 0000002B5A48: D5207C08 01AA100D
	global_store_d16_hi_b16 v[7:8], v3, off                    // 0000002B5A50: DC960000 007C0307
	s_and_not1_b32 vcc_lo, exec_lo, s9                         // 0000002B5A58: 916A097E
	s_cbranch_vccnz 58                                         // 0000002B5A5C: BFA4003A <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1348>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002B5A60: BF8700A1
	v_and_b32_e32 v3, 0xffff0000, v3                           // 0000002B5A64: 360606FF FFFF0000
	s_lshl_b64 s[2:3], s[2:3], 1                               // 0000002B5A6C: 84828102
	v_mul_f32_e32 v3, s6, v3                                   // 0000002B5A70: 10060606
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B5A74: BF870091
	v_mul_f32_e32 v4, 0xbfb8aa3b, v3                           // 0000002B5A78: 100806FF BFB8AA3B
	v_exp_f32_e32 v4, v4                                       // 0000002B5A80: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B5A84: BF870095
	v_add_f32_e32 v4, 1.0, v4                                  // 0000002B5A88: 060808F2
	v_div_scale_f32 v7, null, v4, v4, v3                       // 0000002B5A8C: D6FC7C07 040E0904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002B5A94: BF870291
	v_rcp_f32_e32 v8, v7                                       // 0000002B5A98: 7E105507
	v_fma_f32 v13, -v7, v8, 1.0                                // 0000002B5A9C: D613000D 23CA1107
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000002B5AA4: BF870131
	v_fmac_f32_e32 v8, v13, v8                                 // 0000002B5AA8: 5610110D
	v_div_scale_f32 v15, vcc_lo, v3, v4, v3                    // 0000002B5AAC: D6FC6A0F 040E0903
	v_mad_u64_u32 v[13:14], null, s10, v0, 0                   // 0000002B5AB4: D6FE7C0D 0202000A
	v_mul_f32_e32 v16, v15, v8                                 // 0000002B5ABC: 1020110F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B5AC0: BF870091
	v_fma_f32 v17, -v7, v16, v15                               // 0000002B5AC4: D6130011 243E2107
	v_fmac_f32_e32 v16, v17, v8                                // 0000002B5ACC: 56201111
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002B5AD0: BF870121
	v_fma_f32 v7, -v7, v16, v15                                // 0000002B5AD4: D6130007 243E2107
	v_mad_u64_u32 v[14:15], null, s11, v0, v[14:15]            // 0000002B5ADC: D6FE7C0E 043A000B
	v_div_fmas_f32 v0, v7, v8, v16                             // 0000002B5AE4: D6370000 04421107
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002B5AEC: BF870191
	v_div_fixup_f32 v0, v0, v4, v3                             // 0000002B5AF0: D6270000 040E0900
	.long 0xd73c0003                                           // 0000002B5AF8: D73C0003
	v_cndmask_b32_e32 v1, 1, v13, vcc_lo                       // 0000002B5AFC: 02021A81
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002B5B00: BF870112
	v_bfe_u32 v7, v0, 16, 1                                    // 0000002B5B04: D6100007 02052100
	.long 0xd7006a03                                           // 0000002B5B0C: D7006A03
	v_cndmask_b32_e32 v1, s4, v3, vcc_lo                       // 0000002B5B10: 02020604
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002B5B14: BF870191
	v_add_co_ci_u32_e64 v4, null, s5, v4, vcc_lo               // 0000002B5B18: D5207C04 01AA0805
	v_add3_u32 v0, v0, v7, 0x7fff                              // 0000002B5B20: D6550000 03FE0F00 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B5B2C: BF870093
	.long 0xd7006a03                                           // 0000002B5B30: D7006A03
	v_cndmask_b32_e32 v0, v3, v2, vcc_lo                       // 0000002B5B34: 02000503
	v_add_co_ci_u32_e64 v4, null, s3, v4, vcc_lo               // 0000002B5B38: D5207C04 01AA0803
	global_store_d16_hi_b16 v[3:4], v0, off                    // 0000002B5B40: DC960000 007C0003
	s_or_b32 exec_lo, exec_lo, s8                              // 0000002B5B48: 8C7E087E
	s_mov_b32 s3, 0                                            // 0000002B5B4C: BE830080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002B5B50: BF870009
	s_and_b32 vcc_lo, exec_lo, s3                              // 0000002B5B54: 8B6A037E
	s_cbranch_vccz 1620                                        // 0000002B5B58: BFA30654 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2cac>
	s_and_b32 s0, s1, s0                                       // 0000002B5B5C: 8B000001
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002B5B60: BF870009
	s_and_saveexec_b32 s1, s0                                  // 0000002B5B64: BE812000
	s_cbranch_execz 1616                                       // 0000002B5B68: BFA50650 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2cac>
	v_ashrrev_i32_e32 v0, 31, v10                              // 0000002B5B6C: 3400149F
	s_clause 0x1                                               // 0000002B5B70: BF850001
	s_load_b64 s[4:5], s[16:17], 0x8                           // 0000002B5B74: F4040108 F8000008
	s_load_b64 s[2:3], s[16:17], 0x38                          // 0000002B5B7C: F4040088 F8000038
	.long 0xd73c0003                                           // 0000002B5B84: D73C0003
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 0000002B5B88: 02021281
	.long 0xd73c0007                                           // 0000002B5B8C: D73C0007
	v_cndmask_b32_e32 v1, 2, v9, vcc_lo                        // 0000002B5B90: 02021282
	s_mov_b32 s7, -1                                           // 0000002B5B94: BE8700C1
	v_lshrrev_b32_e32 v0, 23, v0                               // 0000002B5B98: 32000097
	s_mov_b32 s1, 0                                            // 0000002B5B9C: BE810080
	s_mov_b32 s6, 0                                            // 0000002B5BA0: BE860080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B5BA4: BF870091
	.long 0xd7006a0d                                           // 0000002B5BA8: D7006A0D
	v_cndmask_b32_e32 v1, v9, v0, vcc_lo                       // 0000002B5BAC: 02020109
	v_add_co_ci_u32_e64 v0, null, 0, v10, vcc_lo               // 0000002B5BB0: D5207C00 01AA1480
	.long 0xd7016a03                                           // 0000002B5BB8: D7016A03
	v_cndmask_b32_e32 v1, 0, v3, vcc_lo                        // 0000002B5BBC: 02020680
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002B5BC0: BF870123
	v_and_b32_e32 v13, 0xfffffe00, v13                         // 0000002B5BC4: 361A1AFF FFFFFE00
	v_sub_co_ci_u32_e64 v4, null, 0, v4, vcc_lo                // 0000002B5BCC: D5217C04 01AA0880
	.long 0xd7016a09                                           // 0000002B5BD4: D7016A09
	v_cndmask_b32_e32 v1, v9, v13, vcc_lo                      // 0000002B5BD8: 02021B09
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002B5BDC: BF8700B1
	v_sub_co_ci_u32_e64 v10, null, v10, v0, vcc_lo             // 0000002B5BE0: D5217C0A 01AA010A
	s_waitcnt lgkmcnt(0)                                       // 0000002B5BE8: BF89FC07
	.long 0xd7006a07                                           // 0000002B5BEC: D7006A07
	v_cndmask_b32_e32 v1, s4, v7, vcc_lo                       // 0000002B5BF0: 02020E04
	v_add_co_ci_u32_e64 v8, null, s5, v8, vcc_lo               // 0000002B5BF4: D5207C08 01AA1005
	.long 0xd7006a0e                                           // 0000002B5BFC: D7006A0E
	v_cndmask_b32_e32 v1, 0xffffff00, v9, vcc_lo               // 0000002B5C00: 020212FF FFFFFF00
	.long 0xd4540000                                           // 0000002B5C08: D4540000
	v_cndmask_b32_e32 v1, 0x100, v9, vcc_lo                    // 0000002B5C0C: 020212FF 00000100
	v_add_co_ci_u32_e64 v15, null, -1, v10, vcc_lo             // 0000002B5C14: D5207C0F 01AA14C1
	.long 0xd7006a03                                           // 0000002B5C1C: D7006A03
	v_cndmask_b32_e32 v1, v7, v3, vcc_lo                       // 0000002B5C20: 02020707
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002B5C24: BF870191
	v_add_co_ci_u32_e64 v4, null, v8, v4, vcc_lo               // 0000002B5C28: D5207C04 01AA0908
	v_cndmask_b32_e64 v10, v15, v10, s0                        // 0000002B5C30: D501000A 0002150F
	v_cndmask_b32_e64 v9, v14, v9, s0                          // 0000002B5C38: D5010009 0002130E
	s_cmp_lt_i32 s3, 3                                         // 0000002B5C40: BF048303
	s_cbranch_scc1 118                                         // 0000002B5C44: BFA20076 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1620>
	s_cmp_gt_i32 s3, 3                                         // 0000002B5C48: BF028303
	s_cbranch_scc0 70                                          // 0000002B5C4C: BFA10046 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1568>
	s_cmp_gt_i32 s3, 4                                         // 0000002B5C50: BF028403
	s_cbranch_scc0 34                                          // 0000002B5C54: BFA10022 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x14e0>
	s_cmp_eq_u32 s3, 5                                         // 0000002B5C58: BF068503
	s_mov_b32 s6, -1                                           // 0000002B5C5C: BE8600C1
	s_cbranch_scc0 30                                          // 0000002B5C60: BFA1001E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x14dc>
	s_load_b64 s[6:7], s[16:17], 0x10                          // 0000002B5C64: F4040188 F8000010
	v_dual_mov_b32 v14, s4 :: v_dual_mov_b32 v15, s5           // 0000002B5C6C: CA100004 0E0E0005
	v_bfe_u32 v17, v11, 16, 1                                  // 0000002B5C74: D6100011 0205210B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002B5C7C: BF8701A1
	v_add3_u32 v17, v11, v17, 0x7fff                           // 0000002B5C80: D6550011 03FE230B 00007FFF
	s_waitcnt lgkmcnt(0)                                       // 0000002B5C8C: BF89FC07
	v_cndmask_b32_e64 v16, s6, v14, s0                         // 0000002B5C90: D5010010 00021C06
	v_cndmask_b32_e64 v18, s7, v15, s0                         // 0000002B5C98: D5010012 00021E07
	.long 0xd73c000e                                           // 0000002B5CA0: D73C000E
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 0000002B5CA4: 02021281
	s_mov_b32 s6, 0                                            // 0000002B5CA8: BE860080
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B5CAC: BF870093
	.long 0xd7006a10                                           // 0000002B5CB0: D7006A10
	v_cndmask_b32_e32 v1, v16, v13, vcc_lo                     // 0000002B5CB4: 02021B10
	v_add_co_ci_u32_e64 v18, null, v18, v0, vcc_lo             // 0000002B5CB8: D5207C12 01AA0112
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B5CC0: BF870092
	.long 0xd7006a0e                                           // 0000002B5CC4: D7006A0E
	v_cndmask_b32_e32 v1, v16, v14, vcc_lo                     // 0000002B5CC8: 02021D10
	v_add_co_ci_u32_e64 v15, null, v18, v15, vcc_lo            // 0000002B5CCC: D5207C0F 01AA1F12
	global_store_d16_hi_b16 v[14:15], v17, off                 // 0000002B5CD4: DC960000 007C110E
	s_mov_b32 s7, 0                                            // 0000002B5CDC: BE870080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002B5CE0: BF870009
	s_and_b32 vcc_lo, exec_lo, s7                              // 0000002B5CE4: 8B6A077E
	s_cbranch_vccz 30                                          // 0000002B5CE8: BFA3001E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1564>
	v_mul_f32_e32 v14, 0xbfb8aa3b, v11                         // 0000002B5CEC: 101C16FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002B5CF4: BF870291
	v_exp_f32_e32 v14, v14                                     // 0000002B5CF8: 7E1C4B0E
	v_add_f32_e32 v14, 1.0, v14                                // 0000002B5CFC: 061C1CF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B5D00: BF870091
	v_div_scale_f32 v15, null, v14, v14, 1.0                   // 0000002B5D04: D6FC7C0F 03CA1D0E
	v_rcp_f32_e32 v16, v15                                     // 0000002B5D0C: 7E20550F
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B5D10: BF870095
	v_fma_f32 v17, -v15, v16, 1.0                              // 0000002B5D14: D6130011 23CA210F
	v_fmac_f32_e32 v16, v17, v16                               // 0000002B5D1C: 56202111
	v_div_scale_f32 v17, vcc_lo, 1.0, v14, 1.0                 // 0000002B5D20: D6FC6A11 03CA1CF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B5D28: BF870091
	v_mul_f32_e32 v18, v17, v16                                // 0000002B5D2C: 10242111
	v_fma_f32 v19, -v15, v18, v17                              // 0000002B5D30: D6130013 2446250F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B5D38: BF870091
	v_fmac_f32_e32 v18, v19, v16                               // 0000002B5D3C: 56242113
	v_fma_f32 v15, -v15, v18, v17                              // 0000002B5D40: D613000F 2446250F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B5D48: BF870091
	v_div_fmas_f32 v15, v15, v16, v18                          // 0000002B5D4C: D637000F 044A210F
	v_div_fixup_f32 v14, v15, v14, 1.0                         // 0000002B5D54: D627000E 03CA1D0F
	global_store_b32 v[7:8], v14, off                          // 0000002B5D5C: DC6A0000 007C0E07
	s_mov_b32 s7, 0                                            // 0000002B5D64: BE870080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002B5D68: BF870009
	s_and_b32 vcc_lo, exec_lo, s7                              // 0000002B5D6C: 8B6A077E
	s_cbranch_vccz 42                                          // 0000002B5D70: BFA3002A <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x161c>
	v_bfe_u32 v14, v11, 16, 1                                  // 0000002B5D74: D610000E 0205210B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B5D7C: BF870091
	v_add3_u32 v14, v11, v14, 0x7fff                           // 0000002B5D80: D655000E 03FE1D0B 00007FFF
	v_and_b32_e32 v14, 0xffff0000, v14                         // 0000002B5D8C: 361C1CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B5D94: BF870091
	v_mul_f32_e32 v14, s2, v14                                 // 0000002B5D98: 101C1C02
	v_mul_f32_e32 v14, 0xbfb8aa3b, v14                         // 0000002B5D9C: 101C1CFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002B5DA4: BF870291
	v_exp_f32_e32 v14, v14                                     // 0000002B5DA8: 7E1C4B0E
	v_add_f32_e32 v14, 1.0, v14                                // 0000002B5DAC: 061C1CF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B5DB0: BF870091
	v_div_scale_f32 v15, null, v14, v14, 1.0                   // 0000002B5DB4: D6FC7C0F 03CA1D0E
	v_rcp_f32_e32 v16, v15                                     // 0000002B5DBC: 7E20550F
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B5DC0: BF870095
	v_fma_f32 v17, -v15, v16, 1.0                              // 0000002B5DC4: D6130011 23CA210F
	v_fmac_f32_e32 v16, v17, v16                               // 0000002B5DCC: 56202111
	v_div_scale_f32 v17, vcc_lo, 1.0, v14, 1.0                 // 0000002B5DD0: D6FC6A11 03CA1CF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B5DD8: BF870091
	v_mul_f32_e32 v18, v17, v16                                // 0000002B5DDC: 10242111
	v_fma_f32 v19, -v15, v18, v17                              // 0000002B5DE0: D6130013 2446250F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B5DE8: BF870091
	v_fmac_f32_e32 v18, v19, v16                               // 0000002B5DEC: 56242113
	v_fma_f32 v15, -v15, v18, v17                              // 0000002B5DF0: D613000F 2446250F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B5DF8: BF870091
	v_div_fmas_f32 v15, v15, v16, v18                          // 0000002B5DFC: D637000F 044A210F
	v_div_fixup_f32 v14, v15, v14, 1.0                         // 0000002B5E04: D627000E 03CA1D0F
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002B5E0C: BF870001
	v_add_f32_e32 v14, v14, v14                                // 0000002B5E10: 061C1D0E
	global_store_b32 v[7:8], v14, off                          // 0000002B5E14: DC6A0000 007C0E07
	s_mov_b32 s7, 0                                            // 0000002B5E1C: BE870080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002B5E20: BF870009
	s_and_b32 vcc_lo, exec_lo, s7                              // 0000002B5E24: 8B6A077E
	s_cbranch_vccz 55                                          // 0000002B5E28: BFA30037 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1708>
	s_cmp_gt_i32 s3, 1                                         // 0000002B5E2C: BF028103
	s_mov_b32 s1, -1                                           // 0000002B5E30: BE8100C1
	s_cbranch_scc0 46                                          // 0000002B5E34: BFA1002E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x16f0>
	v_bfe_u32 v14, v11, 16, 1                                  // 0000002B5E38: D610000E 0205210B
	s_mov_b32 s1, 0                                            // 0000002B5E40: BE810080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B5E44: BF870091
	v_add3_u32 v14, v11, v14, 0x7fff                           // 0000002B5E48: D655000E 03FE1D0B 00007FFF
	v_and_b32_e32 v14, 0xffff0000, v14                         // 0000002B5E54: 361C1CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B5E5C: BF870091
	v_mul_f32_e32 v14, 0xbfb8aa3b, v14                         // 0000002B5E60: 101C1CFF BFB8AA3B
	v_exp_f32_e32 v14, v14                                     // 0000002B5E68: 7E1C4B0E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B5E6C: BF870095
	v_add_f32_e32 v14, 1.0, v14                                // 0000002B5E70: 061C1CF2
	v_div_scale_f32 v15, null, v14, v14, 1.0                   // 0000002B5E74: D6FC7C0F 03CA1D0E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002B5E7C: BF870291
	v_rcp_f32_e32 v16, v15                                     // 0000002B5E80: 7E20550F
	v_fma_f32 v17, -v15, v16, 1.0                              // 0000002B5E84: D6130011 23CA210F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002B5E8C: BF8700A1
	v_fmac_f32_e32 v16, v17, v16                               // 0000002B5E90: 56202111
	v_div_scale_f32 v17, vcc_lo, 1.0, v14, 1.0                 // 0000002B5E94: D6FC6A11 03CA1CF2
	v_mul_f32_e32 v18, v17, v16                                // 0000002B5E9C: 10242111
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B5EA0: BF870091
	v_fma_f32 v19, -v15, v18, v17                              // 0000002B5EA4: D6130013 2446250F
	v_fmac_f32_e32 v18, v19, v16                               // 0000002B5EAC: 56242113
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B5EB0: BF870091
	v_fma_f32 v15, -v15, v18, v17                              // 0000002B5EB4: D613000F 2446250F
	v_div_fmas_f32 v15, v15, v16, v18                          // 0000002B5EBC: D637000F 044A210F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B5EC4: BF870091
	v_div_fixup_f32 v14, v15, v14, 1.0                         // 0000002B5EC8: D627000E 03CA1D0F
	v_bfe_u32 v15, v14, 16, 1                                  // 0000002B5ED0: D610000F 0205210E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002B5ED8: BF870001
	v_add3_u32 v14, v14, v15, 0x7fff                           // 0000002B5EDC: D655000E 03FE1F0E 00007FFF
	global_store_d16_hi_b16 v[3:4], v14, off                   // 0000002B5EE8: DC960000 007C0E03
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002B5EF0: 916A017E
	s_mov_b32 s1, 0                                            // 0000002B5EF4: BE810080
	s_cbranch_vccnz 3                                          // 0000002B5EF8: BFA40003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1708>
	s_cmp_lg_u32 s3, 1                                         // 0000002B5EFC: BF078103
	s_mov_b32 s1, -1                                           // 0000002B5F00: BE8100C1
	s_cselect_b32 s6, -1, 0                                    // 0000002B5F04: 980680C1
	v_bfe_u32 v14, v11, 16, 1                                  // 0000002B5F08: D610000E 0205210B
	s_and_b32 vcc_lo, exec_lo, s6                              // 0000002B5F10: 8B6A067E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002B5F14: BF870001
	v_add3_u32 v11, v11, v14, 0x7fff                           // 0000002B5F18: D655000B 03FE1D0B 00007FFF
	s_cbranch_vccz 3                                           // 0000002B5F24: BFA30003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1734>
	s_mov_b32 s1, 0                                            // 0000002B5F28: BE810080
	global_store_d16_hi_b16 v[3:4], v11, off                   // 0000002B5F2C: DC960000 007C0B03
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002B5F34: 916A017E
	s_cbranch_vccnz 41                                         // 0000002B5F38: BFA40029 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x17e0>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B5F3C: BF870091
	v_and_b32_e32 v11, 0xffff0000, v11                         // 0000002B5F40: 361616FF FFFF0000
	v_mul_f32_e32 v11, s2, v11                                 // 0000002B5F48: 10161602
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B5F4C: BF870091
	v_mul_f32_e32 v14, 0xbfb8aa3b, v11                         // 0000002B5F50: 101C16FF BFB8AA3B
	v_exp_f32_e32 v14, v14                                     // 0000002B5F58: 7E1C4B0E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B5F5C: BF870095
	v_add_f32_e32 v14, 1.0, v14                                // 0000002B5F60: 061C1CF2
	v_div_scale_f32 v15, null, v14, v14, v11                   // 0000002B5F64: D6FC7C0F 042E1D0E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002B5F6C: BF870291
	v_rcp_f32_e32 v16, v15                                     // 0000002B5F70: 7E20550F
	v_fma_f32 v17, -v15, v16, 1.0                              // 0000002B5F74: D6130011 23CA210F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002B5F7C: BF8700A1
	v_fmac_f32_e32 v16, v17, v16                               // 0000002B5F80: 56202111
	v_div_scale_f32 v17, vcc_lo, v11, v14, v11                 // 0000002B5F84: D6FC6A11 042E1D0B
	v_mul_f32_e32 v18, v17, v16                                // 0000002B5F8C: 10242111
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B5F90: BF870091
	v_fma_f32 v19, -v15, v18, v17                              // 0000002B5F94: D6130013 2446250F
	v_fmac_f32_e32 v18, v19, v16                               // 0000002B5F9C: 56242113
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B5FA0: BF870091
	v_fma_f32 v15, -v15, v18, v17                              // 0000002B5FA4: D613000F 2446250F
	v_div_fmas_f32 v15, v15, v16, v18                          // 0000002B5FAC: D637000F 044A210F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B5FB4: BF870091
	v_div_fixup_f32 v11, v15, v14, v11                         // 0000002B5FB8: D627000B 042E1D0F
	v_bfe_u32 v14, v11, 16, 1                                  // 0000002B5FC0: D610000E 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002B5FC8: BF870001
	v_add3_u32 v11, v11, v14, 0x7fff                           // 0000002B5FCC: D655000B 03FE1D0B 00007FFF
	global_store_d16_hi_b16 v[3:4], v11, off                   // 0000002B5FD8: DC960000 007C0B03
	s_lshr_b64 s[6:7], s[10:11], 1                             // 0000002B5FE0: 8586810A
	s_mov_b32 s9, -1                                           // 0000002B5FE4: BE8900C1
	s_mov_b32 s1, 0                                            // 0000002B5FE8: BE810080
	s_cmp_lt_i32 s3, 3                                         // 0000002B5FEC: BF048303
	s_mov_b32 s8, 0                                            // 0000002B5FF0: BE880080
	s_cbranch_scc1 135                                         // 0000002B5FF4: BFA20087 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1a14>
	s_cmp_gt_i32 s3, 3                                         // 0000002B5FF8: BF028303
	s_cbranch_scc0 82                                          // 0000002B5FFC: BFA10052 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1948>
	s_cmp_gt_i32 s3, 4                                         // 0000002B6000: BF028403
	s_cbranch_scc0 40                                          // 0000002B6004: BFA10028 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x18a8>
	s_cmp_eq_u32 s3, 5                                         // 0000002B6008: BF068503
	s_mov_b32 s8, -1                                           // 0000002B600C: BE8800C1
	s_cbranch_scc0 36                                          // 0000002B6010: BFA10024 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x18a4>
	s_load_b64 s[8:9], s[16:17], 0x10                          // 0000002B6014: F4040208 F8000010
	v_dual_mov_b32 v11, s4 :: v_dual_mov_b32 v14, s5           // 0000002B601C: CA100004 0B0E0005
	v_bfe_u32 v16, v12, 16, 1                                  // 0000002B6024: D6100010 0205210C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002B602C: BF8701A1
	v_add3_u32 v16, v12, v16, 0x7fff                           // 0000002B6030: D6550010 03FE210C 00007FFF
	s_waitcnt lgkmcnt(0)                                       // 0000002B603C: BF89FC07
	v_cndmask_b32_e64 v11, s8, v11, s0                         // 0000002B6040: D501000B 00021608
	v_cndmask_b32_e64 v14, s9, v14, s0                         // 0000002B6048: D501000E 00021C09
	s_lshl_b64 s[8:9], s[6:7], 1                               // 0000002B6050: 84888106
	s_delay_alu instid0(VALU_DEP_2) | instid1(SALU_CYCLE_1)    // 0000002B6054: BF870482
	.long 0xd7006a0b                                           // 0000002B6058: D7006A0B
	v_cndmask_b32_e32 v0, v11, v8, vcc_lo                      // 0000002B605C: 0200110B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002B6060: BF8701A1
	v_add_co_ci_u32_e64 v17, null, s9, v14, vcc_lo             // 0000002B6064: D5207C11 01AA1C09
	.long 0xd73c000e                                           // 0000002B606C: D73C000E
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 0000002B6070: 02021281
	.long 0xd7006a0b                                           // 0000002B6074: D7006A0B
	v_cndmask_b32_e32 v1, v11, v13, vcc_lo                     // 0000002B6078: 02021B0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002B607C: BF8700B1
	v_add_co_ci_u32_e64 v17, null, v17, v0, vcc_lo             // 0000002B6080: D5207C11 01AA0111
	s_mov_b32 s8, 0                                            // 0000002B6088: BE880080
	.long 0xd7006a0e                                           // 0000002B608C: D7006A0E
	v_cndmask_b32_e32 v1, v11, v14, vcc_lo                     // 0000002B6090: 02021D0B
	v_add_co_ci_u32_e64 v15, null, v17, v15, vcc_lo            // 0000002B6094: D5207C0F 01AA1F11
	global_store_d16_hi_b16 v[14:15], v16, off                 // 0000002B609C: DC960000 007C100E
	s_mov_b32 s9, 0                                            // 0000002B60A4: BE890080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002B60A8: BF870009
	s_and_b32 vcc_lo, exec_lo, s9                              // 0000002B60AC: 8B6A097E
	s_cbranch_vccz 36                                          // 0000002B60B0: BFA30024 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1944>
	v_mul_f32_e32 v11, 0xbfb8aa3b, v12                         // 0000002B60B4: 101618FF BFB8AA3B
	s_lshl_b64 s[12:13], s[10:11], 2                           // 0000002B60BC: 848C820A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002B60C0: BF870291
	v_exp_f32_e32 v11, v11                                     // 0000002B60C4: 7E164B0B
	v_add_f32_e32 v11, 1.0, v11                                // 0000002B60C8: 061616F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002B60CC: BF870121
	v_div_scale_f32 v14, null, v11, v11, 1.0                   // 0000002B60D0: D6FC7C0E 03CA170B
	v_div_scale_f32 v17, vcc_lo, 1.0, v11, 1.0                 // 0000002B60D8: D6FC6A11 03CA16F2
	v_rcp_f32_e32 v15, v14                                     // 0000002B60E0: 7E1E550E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B60E4: BF870095
	v_fma_f32 v16, -v14, v15, 1.0                              // 0000002B60E8: D6130010 23CA1F0E
	v_fmac_f32_e32 v15, v16, v15                               // 0000002B60F0: 561E1F10
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B60F4: BF870091
	v_mul_f32_e32 v16, v17, v15                                // 0000002B60F8: 10201F11
	v_fma_f32 v18, -v14, v16, v17                              // 0000002B60FC: D6130012 2446210E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B6104: BF870091
	v_fmac_f32_e32 v16, v18, v15                               // 0000002B6108: 56201F12
	v_fma_f32 v14, -v14, v16, v17                              // 0000002B610C: D613000E 2446210E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B6114: BF870091
	v_div_fmas_f32 v14, v14, v15, v16                          // 0000002B6118: D637000E 04421F0E
	v_div_fixup_f32 v11, v14, v11, 1.0                         // 0000002B6120: D627000B 03CA170E
	.long 0xd7006a0e                                           // 0000002B6128: D7006A0E
	v_cndmask_b32_e32 v0, v7, v12, vcc_lo                      // 0000002B612C: 02001907
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002B6130: BF870001
	v_add_co_ci_u32_e64 v15, null, s13, v8, vcc_lo             // 0000002B6134: D5207C0F 01AA100D
	global_store_b32 v[14:15], v11, off                        // 0000002B613C: DC6A0000 007C0B0E
	s_mov_b32 s9, 0                                            // 0000002B6144: BE890080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002B6148: BF870009
	s_and_b32 vcc_lo, exec_lo, s9                              // 0000002B614C: 8B6A097E
	s_cbranch_vccz 47                                          // 0000002B6150: BFA3002F <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1a10>
	v_bfe_u32 v11, v12, 16, 1                                  // 0000002B6154: D610000B 0205210C
	s_lshl_b64 s[12:13], s[10:11], 2                           // 0000002B615C: 848C820A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B6160: BF870091
	v_add3_u32 v11, v12, v11, 0x7fff                           // 0000002B6164: D655000B 03FE170C 00007FFF
	v_and_b32_e32 v11, 0xffff0000, v11                         // 0000002B6170: 361616FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B6178: BF870091
	v_mul_f32_e32 v11, s2, v11                                 // 0000002B617C: 10161602
	v_mul_f32_e32 v11, 0xbfb8aa3b, v11                         // 0000002B6180: 101616FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002B6188: BF870291
	v_exp_f32_e32 v11, v11                                     // 0000002B618C: 7E164B0B
	v_add_f32_e32 v11, 1.0, v11                                // 0000002B6190: 061616F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002B6194: BF870121
	v_div_scale_f32 v14, null, v11, v11, 1.0                   // 0000002B6198: D6FC7C0E 03CA170B
	v_div_scale_f32 v17, vcc_lo, 1.0, v11, 1.0                 // 0000002B61A0: D6FC6A11 03CA16F2
	v_rcp_f32_e32 v15, v14                                     // 0000002B61A8: 7E1E550E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B61AC: BF870095
	v_fma_f32 v16, -v14, v15, 1.0                              // 0000002B61B0: D6130010 23CA1F0E
	v_fmac_f32_e32 v15, v16, v15                               // 0000002B61B8: 561E1F10
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B61BC: BF870091
	v_mul_f32_e32 v16, v17, v15                                // 0000002B61C0: 10201F11
	v_fma_f32 v18, -v14, v16, v17                              // 0000002B61C4: D6130012 2446210E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B61CC: BF870091
	v_fmac_f32_e32 v16, v18, v15                               // 0000002B61D0: 56201F12
	v_fma_f32 v14, -v14, v16, v17                              // 0000002B61D4: D613000E 2446210E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B61DC: BF870091
	v_div_fmas_f32 v14, v14, v15, v16                          // 0000002B61E0: D637000E 04421F0E
	v_div_fixup_f32 v11, v14, v11, 1.0                         // 0000002B61E8: D627000B 03CA170E
	.long 0xd7006a0e                                           // 0000002B61F0: D7006A0E
	v_cndmask_b32_e32 v0, v7, v12, vcc_lo                      // 0000002B61F4: 02001907
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002B61F8: BF870191
	v_add_co_ci_u32_e64 v15, null, s13, v8, vcc_lo             // 0000002B61FC: D5207C0F 01AA100D
	v_add_f32_e32 v11, v11, v11                                // 0000002B6204: 0616170B
	global_store_b32 v[14:15], v11, off                        // 0000002B6208: DC6A0000 007C0B0E
	s_mov_b32 s9, 0                                            // 0000002B6210: BE890080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002B6214: BF870009
	s_and_b32 vcc_lo, exec_lo, s9                              // 0000002B6218: 8B6A097E
	s_cbranch_vccz 60                                          // 0000002B621C: BFA3003C <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1b10>
	s_cmp_gt_i32 s3, 1                                         // 0000002B6220: BF028103
	s_mov_b32 s1, -1                                           // 0000002B6224: BE8100C1
	s_cbranch_scc0 51                                          // 0000002B6228: BFA10033 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1af8>
	v_bfe_u32 v11, v12, 16, 1                                  // 0000002B622C: D610000B 0205210C
	s_lshl_b64 s[12:13], s[10:11], 1                           // 0000002B6234: 848C810A
	s_mov_b32 s1, 0                                            // 0000002B6238: BE810080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B623C: BF870091
	v_add3_u32 v11, v12, v11, 0x7fff                           // 0000002B6240: D655000B 03FE170C 00007FFF
	v_and_b32_e32 v11, 0xffff0000, v11                         // 0000002B624C: 361616FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B6254: BF870091
	v_mul_f32_e32 v11, 0xbfb8aa3b, v11                         // 0000002B6258: 101616FF BFB8AA3B
	v_exp_f32_e32 v11, v11                                     // 0000002B6260: 7E164B0B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B6264: BF870095
	v_add_f32_e32 v11, 1.0, v11                                // 0000002B6268: 061616F2
	v_div_scale_f32 v14, null, v11, v11, 1.0                   // 0000002B626C: D6FC7C0E 03CA170B
	v_div_scale_f32 v17, vcc_lo, 1.0, v11, 1.0                 // 0000002B6274: D6FC6A11 03CA16F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002B627C: BF870292
	v_rcp_f32_e32 v15, v14                                     // 0000002B6280: 7E1E550E
	v_fma_f32 v16, -v14, v15, 1.0                              // 0000002B6284: D6130010 23CA1F0E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B628C: BF870091
	v_fmac_f32_e32 v15, v16, v15                               // 0000002B6290: 561E1F10
	v_mul_f32_e32 v16, v17, v15                                // 0000002B6294: 10201F11
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B6298: BF870091
	v_fma_f32 v18, -v14, v16, v17                              // 0000002B629C: D6130012 2446210E
	v_fmac_f32_e32 v16, v18, v15                               // 0000002B62A4: 56201F12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B62A8: BF870091
	v_fma_f32 v14, -v14, v16, v17                              // 0000002B62AC: D613000E 2446210E
	v_div_fmas_f32 v14, v14, v15, v16                          // 0000002B62B4: D637000E 04421F0E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B62BC: BF870091
	v_div_fixup_f32 v11, v14, v11, 1.0                         // 0000002B62C0: D627000B 03CA170E
	v_bfe_u32 v14, v11, 16, 1                                  // 0000002B62C8: D610000E 0205210B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002B62D0: BF8700A1
	v_add3_u32 v11, v11, v14, 0x7fff                           // 0000002B62D4: D655000B 03FE1D0B 00007FFF
	.long 0xd7006a0e                                           // 0000002B62E0: D7006A0E
	v_cndmask_b32_e32 v0, v3, v12, vcc_lo                      // 0000002B62E4: 02001903
	v_add_co_ci_u32_e64 v15, null, s13, v4, vcc_lo             // 0000002B62E8: D5207C0F 01AA080D
	global_store_d16_hi_b16 v[14:15], v11, off                 // 0000002B62F0: DC960000 007C0B0E
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002B62F8: 916A017E
	s_mov_b32 s1, 0                                            // 0000002B62FC: BE810080
	s_cbranch_vccnz 3                                          // 0000002B6300: BFA40003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1b10>
	s_cmp_lg_u32 s3, 1                                         // 0000002B6304: BF078103
	s_mov_b32 s1, -1                                           // 0000002B6308: BE8100C1
	s_cselect_b32 s8, -1, 0                                    // 0000002B630C: 980880C1
	v_bfe_u32 v11, v12, 16, 1                                  // 0000002B6310: D610000B 0205210C
	s_and_b32 vcc_lo, exec_lo, s8                              // 0000002B6318: 8B6A087E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002B631C: BF870001
	v_add3_u32 v11, v12, v11, 0x7fff                           // 0000002B6320: D655000B 03FE170C 00007FFF
	s_cbranch_vccz 9                                           // 0000002B632C: BFA30009 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1b54>
	s_lshl_b64 s[8:9], s[10:11], 1                             // 0000002B6330: 8488810A
	s_mov_b32 s1, 0                                            // 0000002B6334: BE810080
	.long 0xd7006a0e                                           // 0000002B6338: D7006A0E
	v_cndmask_b32_e32 v0, v3, v8, vcc_lo                       // 0000002B633C: 02001103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002B6340: BF870001
	v_add_co_ci_u32_e64 v15, null, s9, v4, vcc_lo              // 0000002B6344: D5207C0F 01AA0809
	global_store_d16_hi_b16 v[14:15], v11, off                 // 0000002B634C: DC960000 007C0B0E
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002B6354: 916A017E
	s_cbranch_vccnz 46                                         // 0000002B6358: BFA4002E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1c14>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002B635C: BF8700A1
	v_and_b32_e32 v11, 0xffff0000, v11                         // 0000002B6360: 361616FF FFFF0000
	s_lshl_b64 s[8:9], s[10:11], 1                             // 0000002B6368: 8488810A
	v_mul_f32_e32 v11, s2, v11                                 // 0000002B636C: 10161602
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B6370: BF870091
	v_mul_f32_e32 v12, 0xbfb8aa3b, v11                         // 0000002B6374: 101816FF BFB8AA3B
	v_exp_f32_e32 v12, v12                                     // 0000002B637C: 7E184B0C
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B6380: BF870095
	v_add_f32_e32 v12, 1.0, v12                                // 0000002B6384: 061818F2
	v_div_scale_f32 v14, null, v12, v12, v11                   // 0000002B6388: D6FC7C0E 042E190C
	v_div_scale_f32 v17, vcc_lo, v11, v12, v11                 // 0000002B6390: D6FC6A11 042E190B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002B6398: BF870292
	v_rcp_f32_e32 v15, v14                                     // 0000002B639C: 7E1E550E
	v_fma_f32 v16, -v14, v15, 1.0                              // 0000002B63A0: D6130010 23CA1F0E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B63A8: BF870091
	v_fmac_f32_e32 v15, v16, v15                               // 0000002B63AC: 561E1F10
	v_mul_f32_e32 v16, v17, v15                                // 0000002B63B0: 10201F11
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B63B4: BF870091
	v_fma_f32 v18, -v14, v16, v17                              // 0000002B63B8: D6130012 2446210E
	v_fmac_f32_e32 v16, v18, v15                               // 0000002B63C0: 56201F12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B63C4: BF870091
	v_fma_f32 v14, -v14, v16, v17                              // 0000002B63C8: D613000E 2446210E
	v_div_fmas_f32 v14, v14, v15, v16                          // 0000002B63D0: D637000E 04421F0E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B63D8: BF870091
	v_div_fixup_f32 v11, v14, v12, v11                         // 0000002B63DC: D627000B 042E190E
	v_bfe_u32 v12, v11, 16, 1                                  // 0000002B63E4: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002B63EC: BF8700A1
	v_add3_u32 v14, v11, v12, 0x7fff                           // 0000002B63F0: D655000E 03FE190B 00007FFF
	.long 0xd7006a0b                                           // 0000002B63FC: D7006A0B
	v_cndmask_b32_e32 v0, v3, v8, vcc_lo                       // 0000002B6400: 02001103
	v_add_co_ci_u32_e64 v12, null, s9, v4, vcc_lo              // 0000002B6404: D5207C0C 01AA0809
	global_store_d16_hi_b16 v[11:12], v14, off                 // 0000002B640C: DC960000 007C0E0B
	s_mov_b32 s9, -1                                           // 0000002B6414: BE8900C1
	s_mov_b32 s1, 0                                            // 0000002B6418: BE810080
	s_cmp_lt_i32 s3, 3                                         // 0000002B641C: BF048303
	s_mov_b32 s8, 0                                            // 0000002B6420: BE880080
	s_cbranch_scc1 138                                         // 0000002B6424: BFA2008A <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1e50>
	s_cmp_gt_i32 s3, 3                                         // 0000002B6428: BF028303
	s_cbranch_scc0 85                                          // 0000002B642C: BFA10055 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1d84>
	s_cmp_gt_i32 s3, 4                                         // 0000002B6430: BF028403
	s_cbranch_scc0 43                                          // 0000002B6434: BFA1002B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1ce4>
	s_cmp_eq_u32 s3, 5                                         // 0000002B6438: BF068503
	s_mov_b32 s8, -1                                           // 0000002B643C: BE8800C1
	s_cbranch_scc0 39                                          // 0000002B6440: BFA10027 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1ce0>
	s_load_b64 s[8:9], s[16:17], 0x10                          // 0000002B6444: F4040208 F8000010
	v_dual_mov_b32 v11, s4 :: v_dual_mov_b32 v12, s5           // 0000002B644C: CA100004 0B0C0005
	s_and_b32 s13, s11, 0x7fffffff                             // 0000002B6454: 8B0DFF0B 7FFFFFFF
	s_and_b32 s12, s10, -2                                     // 0000002B645C: 8B0CC20A
	v_bfe_u32 v14, v5, 16, 1                                   // 0000002B6460: D610000E 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002B6468: BF870001
	v_add3_u32 v14, v5, v14, 0x7fff                            // 0000002B646C: D655000E 03FE1D05 00007FFF
	s_waitcnt lgkmcnt(0)                                       // 0000002B6478: BF89FC07
	v_cndmask_b32_e64 v11, s8, v11, s0                         // 0000002B647C: D501000B 00021608
	v_cndmask_b32_e64 v12, s9, v12, s0                         // 0000002B6484: D501000C 00021809
	s_lshl_b64 s[8:9], s[12:13], 1                             // 0000002B648C: 8488810C
	s_delay_alu instid0(VALU_DEP_2) | instid1(SALU_CYCLE_1)    // 0000002B6490: BF870482
	.long 0xd7006a0f                                           // 0000002B6494: D7006A0F
	v_cndmask_b32_e32 v0, v11, v8, vcc_lo                      // 0000002B6498: 0200110B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002B649C: BF8701A1
	v_add_co_ci_u32_e64 v16, null, s9, v12, vcc_lo             // 0000002B64A0: D5207C10 01AA1809
	.long 0xd73c000b                                           // 0000002B64A8: D73C000B
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 0000002B64AC: 02021281
	.long 0xd7006a0f                                           // 0000002B64B0: D7006A0F
	v_cndmask_b32_e32 v1, v15, v13, vcc_lo                     // 0000002B64B4: 02021B0F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002B64B8: BF8700B1
	v_add_co_ci_u32_e64 v16, null, v16, v0, vcc_lo             // 0000002B64BC: D5207C10 01AA0110
	s_mov_b32 s8, 0                                            // 0000002B64C4: BE880080
	.long 0xd7006a0b                                           // 0000002B64C8: D7006A0B
	v_cndmask_b32_e32 v1, v15, v11, vcc_lo                     // 0000002B64CC: 0202170F
	v_add_co_ci_u32_e64 v12, null, v16, v12, vcc_lo            // 0000002B64D0: D5207C0C 01AA1910
	global_store_d16_hi_b16 v[11:12], v14, off                 // 0000002B64D8: DC960000 007C0E0B
	s_mov_b32 s9, 0                                            // 0000002B64E0: BE890080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002B64E4: BF870009
	s_and_b32 vcc_lo, exec_lo, s9                              // 0000002B64E8: 8B6A097E
	s_cbranch_vccz 36                                          // 0000002B64EC: BFA30024 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1d80>
	v_mul_f32_e32 v11, 0xbfb8aa3b, v5                          // 0000002B64F0: 10160AFF BFB8AA3B
	s_lshl_b64 s[12:13], s[10:11], 3                           // 0000002B64F8: 848C830A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002B64FC: BF870291
	v_exp_f32_e32 v11, v11                                     // 0000002B6500: 7E164B0B
	v_add_f32_e32 v11, 1.0, v11                                // 0000002B6504: 061616F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002B6508: BF870121
	v_div_scale_f32 v12, null, v11, v11, 1.0                   // 0000002B650C: D6FC7C0C 03CA170B
	v_div_scale_f32 v16, vcc_lo, 1.0, v11, 1.0                 // 0000002B6514: D6FC6A10 03CA16F2
	v_rcp_f32_e32 v14, v12                                     // 0000002B651C: 7E1C550C
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B6520: BF870095
	v_fma_f32 v15, -v12, v14, 1.0                              // 0000002B6524: D613000F 23CA1D0C
	v_fmac_f32_e32 v14, v15, v14                               // 0000002B652C: 561C1D0F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B6530: BF870091
	v_mul_f32_e32 v15, v16, v14                                // 0000002B6534: 101E1D10
	v_fma_f32 v17, -v12, v15, v16                              // 0000002B6538: D6130011 24421F0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B6540: BF870091
	v_fmac_f32_e32 v15, v17, v14                               // 0000002B6544: 561E1D11
	v_fma_f32 v12, -v12, v15, v16                              // 0000002B6548: D613000C 24421F0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B6550: BF870091
	v_div_fmas_f32 v12, v12, v14, v15                          // 0000002B6554: D637000C 043E1D0C
	v_div_fixup_f32 v14, v12, v11, 1.0                         // 0000002B655C: D627000E 03CA170C
	.long 0xd7006a0b                                           // 0000002B6564: D7006A0B
	v_cndmask_b32_e32 v0, v7, v12, vcc_lo                      // 0000002B6568: 02001907
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002B656C: BF870001
	v_add_co_ci_u32_e64 v12, null, s13, v8, vcc_lo             // 0000002B6570: D5207C0C 01AA100D
	global_store_b32 v[11:12], v14, off                        // 0000002B6578: DC6A0000 007C0E0B
	s_mov_b32 s9, 0                                            // 0000002B6580: BE890080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002B6584: BF870009
	s_and_b32 vcc_lo, exec_lo, s9                              // 0000002B6588: 8B6A097E
	s_cbranch_vccz 47                                          // 0000002B658C: BFA3002F <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1e4c>
	v_bfe_u32 v11, v5, 16, 1                                   // 0000002B6590: D610000B 02052105
	s_lshl_b64 s[12:13], s[10:11], 3                           // 0000002B6598: 848C830A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B659C: BF870091
	v_add3_u32 v11, v5, v11, 0x7fff                            // 0000002B65A0: D655000B 03FE1705 00007FFF
	v_and_b32_e32 v11, 0xffff0000, v11                         // 0000002B65AC: 361616FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B65B4: BF870091
	v_mul_f32_e32 v11, s2, v11                                 // 0000002B65B8: 10161602
	v_mul_f32_e32 v11, 0xbfb8aa3b, v11                         // 0000002B65BC: 101616FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002B65C4: BF870291
	v_exp_f32_e32 v11, v11                                     // 0000002B65C8: 7E164B0B
	v_add_f32_e32 v11, 1.0, v11                                // 0000002B65CC: 061616F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002B65D0: BF870121
	v_div_scale_f32 v12, null, v11, v11, 1.0                   // 0000002B65D4: D6FC7C0C 03CA170B
	v_div_scale_f32 v16, vcc_lo, 1.0, v11, 1.0                 // 0000002B65DC: D6FC6A10 03CA16F2
	v_rcp_f32_e32 v14, v12                                     // 0000002B65E4: 7E1C550C
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B65E8: BF870095
	v_fma_f32 v15, -v12, v14, 1.0                              // 0000002B65EC: D613000F 23CA1D0C
	v_fmac_f32_e32 v14, v15, v14                               // 0000002B65F4: 561C1D0F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B65F8: BF870091
	v_mul_f32_e32 v15, v16, v14                                // 0000002B65FC: 101E1D10
	v_fma_f32 v17, -v12, v15, v16                              // 0000002B6600: D6130011 24421F0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B6608: BF870091
	v_fmac_f32_e32 v15, v17, v14                               // 0000002B660C: 561E1D11
	v_fma_f32 v12, -v12, v15, v16                              // 0000002B6610: D613000C 24421F0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B6618: BF870091
	v_div_fmas_f32 v12, v12, v14, v15                          // 0000002B661C: D637000C 043E1D0C
	v_div_fixup_f32 v11, v12, v11, 1.0                         // 0000002B6624: D627000B 03CA170C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002B662C: BF8700A1
	v_add_f32_e32 v14, v11, v11                                // 0000002B6630: 061C170B
	.long 0xd7006a0b                                           // 0000002B6634: D7006A0B
	v_cndmask_b32_e32 v0, v7, v12, vcc_lo                      // 0000002B6638: 02001907
	v_add_co_ci_u32_e64 v12, null, s13, v8, vcc_lo             // 0000002B663C: D5207C0C 01AA100D
	global_store_b32 v[11:12], v14, off                        // 0000002B6644: DC6A0000 007C0E0B
	s_mov_b32 s9, 0                                            // 0000002B664C: BE890080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002B6650: BF870009
	s_and_b32 vcc_lo, exec_lo, s9                              // 0000002B6654: 8B6A097E
	s_cbranch_vccz 60                                          // 0000002B6658: BFA3003C <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1f4c>
	s_cmp_gt_i32 s3, 1                                         // 0000002B665C: BF028103
	s_mov_b32 s1, -1                                           // 0000002B6660: BE8100C1
	s_cbranch_scc0 51                                          // 0000002B6664: BFA10033 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1f34>
	v_bfe_u32 v11, v5, 16, 1                                   // 0000002B6668: D610000B 02052105
	s_lshl_b64 s[12:13], s[10:11], 2                           // 0000002B6670: 848C820A
	s_mov_b32 s1, 0                                            // 0000002B6674: BE810080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B6678: BF870091
	v_add3_u32 v11, v5, v11, 0x7fff                            // 0000002B667C: D655000B 03FE1705 00007FFF
	v_and_b32_e32 v11, 0xffff0000, v11                         // 0000002B6688: 361616FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B6690: BF870091
	v_mul_f32_e32 v11, 0xbfb8aa3b, v11                         // 0000002B6694: 101616FF BFB8AA3B
	v_exp_f32_e32 v11, v11                                     // 0000002B669C: 7E164B0B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B66A0: BF870095
	v_add_f32_e32 v11, 1.0, v11                                // 0000002B66A4: 061616F2
	v_div_scale_f32 v12, null, v11, v11, 1.0                   // 0000002B66A8: D6FC7C0C 03CA170B
	v_div_scale_f32 v16, vcc_lo, 1.0, v11, 1.0                 // 0000002B66B0: D6FC6A10 03CA16F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002B66B8: BF870292
	v_rcp_f32_e32 v14, v12                                     // 0000002B66BC: 7E1C550C
	v_fma_f32 v15, -v12, v14, 1.0                              // 0000002B66C0: D613000F 23CA1D0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B66C8: BF870091
	v_fmac_f32_e32 v14, v15, v14                               // 0000002B66CC: 561C1D0F
	v_mul_f32_e32 v15, v16, v14                                // 0000002B66D0: 101E1D10
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B66D4: BF870091
	v_fma_f32 v17, -v12, v15, v16                              // 0000002B66D8: D6130011 24421F0C
	v_fmac_f32_e32 v15, v17, v14                               // 0000002B66E0: 561E1D11
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B66E4: BF870091
	v_fma_f32 v12, -v12, v15, v16                              // 0000002B66E8: D613000C 24421F0C
	v_div_fmas_f32 v12, v12, v14, v15                          // 0000002B66F0: D637000C 043E1D0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B66F8: BF870091
	v_div_fixup_f32 v11, v12, v11, 1.0                         // 0000002B66FC: D627000B 03CA170C
	v_bfe_u32 v12, v11, 16, 1                                  // 0000002B6704: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002B670C: BF8700A1
	v_add3_u32 v14, v11, v12, 0x7fff                           // 0000002B6710: D655000E 03FE190B 00007FFF
	.long 0xd7006a0b                                           // 0000002B671C: D7006A0B
	v_cndmask_b32_e32 v0, v3, v12, vcc_lo                      // 0000002B6720: 02001903
	v_add_co_ci_u32_e64 v12, null, s13, v4, vcc_lo             // 0000002B6724: D5207C0C 01AA080D
	global_store_d16_hi_b16 v[11:12], v14, off                 // 0000002B672C: DC960000 007C0E0B
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002B6734: 916A017E
	s_mov_b32 s1, 0                                            // 0000002B6738: BE810080
	s_cbranch_vccnz 3                                          // 0000002B673C: BFA40003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1f4c>
	s_cmp_lg_u32 s3, 1                                         // 0000002B6740: BF078103
	s_mov_b32 s1, -1                                           // 0000002B6744: BE8100C1
	s_cselect_b32 s8, -1, 0                                    // 0000002B6748: 980880C1
	v_bfe_u32 v11, v5, 16, 1                                   // 0000002B674C: D610000B 02052105
	s_and_b32 vcc_lo, exec_lo, s8                              // 0000002B6754: 8B6A087E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002B6758: BF870001
	v_add3_u32 v5, v5, v11, 0x7fff                             // 0000002B675C: D6550005 03FE1705 00007FFF
	s_cbranch_vccz 9                                           // 0000002B6768: BFA30009 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1f90>
	s_lshl_b64 s[8:9], s[10:11], 2                             // 0000002B676C: 8488820A
	s_mov_b32 s1, 0                                            // 0000002B6770: BE810080
	.long 0xd7006a0b                                           // 0000002B6774: D7006A0B
	v_cndmask_b32_e32 v0, v3, v8, vcc_lo                       // 0000002B6778: 02001103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002B677C: BF870001
	v_add_co_ci_u32_e64 v12, null, s9, v4, vcc_lo              // 0000002B6780: D5207C0C 01AA0809
	global_store_d16_hi_b16 v[11:12], v5, off                  // 0000002B6788: DC960000 007C050B
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002B6790: 916A017E
	s_cbranch_vccnz 46                                         // 0000002B6794: BFA4002E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2050>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002B6798: BF8700A1
	v_and_b32_e32 v5, 0xffff0000, v5                           // 0000002B679C: 360A0AFF FFFF0000
	s_lshl_b64 s[8:9], s[10:11], 2                             // 0000002B67A4: 8488820A
	v_mul_f32_e32 v5, s2, v5                                   // 0000002B67A8: 100A0A02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B67AC: BF870091
	v_mul_f32_e32 v11, 0xbfb8aa3b, v5                          // 0000002B67B0: 10160AFF BFB8AA3B
	v_exp_f32_e32 v11, v11                                     // 0000002B67B8: 7E164B0B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B67BC: BF870095
	v_add_f32_e32 v11, 1.0, v11                                // 0000002B67C0: 061616F2
	v_div_scale_f32 v12, null, v11, v11, v5                    // 0000002B67C4: D6FC7C0C 0416170B
	v_div_scale_f32 v16, vcc_lo, v5, v11, v5                   // 0000002B67CC: D6FC6A10 04161705
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002B67D4: BF870292
	v_rcp_f32_e32 v14, v12                                     // 0000002B67D8: 7E1C550C
	v_fma_f32 v15, -v12, v14, 1.0                              // 0000002B67DC: D613000F 23CA1D0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B67E4: BF870091
	v_fmac_f32_e32 v14, v15, v14                               // 0000002B67E8: 561C1D0F
	v_mul_f32_e32 v15, v16, v14                                // 0000002B67EC: 101E1D10
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B67F0: BF870091
	v_fma_f32 v17, -v12, v15, v16                              // 0000002B67F4: D6130011 24421F0C
	v_fmac_f32_e32 v15, v17, v14                               // 0000002B67FC: 561E1D11
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B6800: BF870091
	v_fma_f32 v12, -v12, v15, v16                              // 0000002B6804: D613000C 24421F0C
	v_div_fmas_f32 v12, v12, v14, v15                          // 0000002B680C: D637000C 043E1D0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B6814: BF870091
	v_div_fixup_f32 v5, v12, v11, v5                           // 0000002B6818: D6270005 0416170C
	v_bfe_u32 v11, v5, 16, 1                                   // 0000002B6820: D610000B 02052105
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002B6828: BF8700A1
	v_add3_u32 v5, v5, v11, 0x7fff                             // 0000002B682C: D6550005 03FE1705 00007FFF
	.long 0xd7006a0b                                           // 0000002B6838: D7006A0B
	v_cndmask_b32_e32 v0, v3, v8, vcc_lo                       // 0000002B683C: 02001103
	v_add_co_ci_u32_e64 v12, null, s9, v4, vcc_lo              // 0000002B6840: D5207C0C 01AA0809
	global_store_d16_hi_b16 v[11:12], v5, off                  // 0000002B6848: DC960000 007C050B
	s_mov_b32 s9, -1                                           // 0000002B6850: BE8900C1
	s_mov_b32 s1, 0                                            // 0000002B6854: BE810080
	s_cmp_lt_i32 s3, 3                                         // 0000002B6858: BF048303
	s_mov_b32 s8, 0                                            // 0000002B685C: BE880080
	s_cbranch_scc1 133                                         // 0000002B6860: BFA20085 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2278>
	s_cmp_gt_i32 s3, 3                                         // 0000002B6864: BF028303
	s_cbranch_scc0 81                                          // 0000002B6868: BFA10051 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x21b0>
	s_cmp_gt_i32 s3, 4                                         // 0000002B686C: BF028403
	s_cbranch_scc0 40                                          // 0000002B6870: BFA10028 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2114>
	s_cmp_eq_u32 s3, 5                                         // 0000002B6874: BF068503
	s_mov_b32 s8, -1                                           // 0000002B6878: BE8800C1
	s_cbranch_scc0 36                                          // 0000002B687C: BFA10024 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2110>
	s_load_b64 s[8:9], s[16:17], 0x10                          // 0000002B6880: F4040208 F8000010
	v_mov_b32_e32 v5, s5                                       // 0000002B6888: 7E0A0205
	v_mov_b32_e32 v11, s4                                      // 0000002B688C: 7E160204
	s_waitcnt lgkmcnt(0)                                       // 0000002B6890: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002B6894: BF870112
	v_cndmask_b32_e64 v12, s9, v5, s0                          // 0000002B6898: D501000C 00020A09
	v_cndmask_b32_e64 v11, s8, v11, s0                         // 0000002B68A0: D501000B 00021608
	v_bfe_u32 v5, v6, 16, 1                                    // 0000002B68A8: D6100005 02052106
	s_mov_b32 s8, 0                                            // 0000002B68B0: BE880080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002B68B4: BF870112
	v_mad_u64_u32 v[11:12], null, s6, 6, v[11:12]              // 0000002B68B8: D6FE7C0B 042D0C06
	v_add3_u32 v5, v6, v5, 0x7fff                              // 0000002B68C0: D6550005 03FE0B06 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000002B68CC: BF870222
	v_mad_u64_u32 v[14:15], null, s7, 6, v[12:13]              // 0000002B68D0: D6FE7C0E 04310C07
	.long 0xd73c000f                                           // 0000002B68D8: D73C000F
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 0000002B68DC: 02021281
	.long 0xd7006a0b                                           // 0000002B68E0: D7006A0B
	v_cndmask_b32_e32 v1, v11, v13, vcc_lo                     // 0000002B68E4: 02021B0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002B68E8: BF870111
	v_add_co_ci_u32_e64 v12, null, v14, v0, vcc_lo             // 0000002B68EC: D5207C0C 01AA010E
	.long 0xd7006a0b                                           // 0000002B68F4: D7006A0B
	v_cndmask_b32_e32 v1, v11, v15, vcc_lo                     // 0000002B68F8: 02021F0B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002B68FC: BF870001
	v_add_co_ci_u32_e64 v12, null, v12, v16, vcc_lo            // 0000002B6900: D5207C0C 01AA210C
	global_store_d16_hi_b16 v[11:12], v5, off                  // 0000002B6908: DC960000 007C050B
	s_mov_b32 s9, 0                                            // 0000002B6910: BE890080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002B6914: BF870009
	s_and_b32 vcc_lo, exec_lo, s9                              // 0000002B6918: 8B6A097E
	s_cbranch_vccz 35                                          // 0000002B691C: BFA30023 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x21ac>
	v_mul_f32_e32 v5, 0xbfb8aa3b, v6                           // 0000002B6920: 100A0CFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002B6928: BF870291
	v_exp_f32_e32 v5, v5                                       // 0000002B692C: 7E0A4B05
	v_add_f32_e32 v5, 1.0, v5                                  // 0000002B6930: 060A0AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002B6934: BF870121
	v_div_scale_f32 v11, null, v5, v5, 1.0                     // 0000002B6938: D6FC7C0B 03CA0B05
	v_div_scale_f32 v16, vcc_lo, 1.0, v5, 1.0                  // 0000002B6940: D6FC6A10 03CA0AF2
	v_rcp_f32_e32 v12, v11                                     // 0000002B6948: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B694C: BF870095
	v_fma_f32 v14, -v11, v12, 1.0                              // 0000002B6950: D613000E 23CA190B
	v_fmac_f32_e32 v12, v14, v12                               // 0000002B6958: 5618190E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B695C: BF870091
	v_mul_f32_e32 v17, v16, v12                                // 0000002B6960: 10221910
	v_fma_f32 v14, -v11, v17, v16                              // 0000002B6964: D613000E 2442230B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002B696C: BF870121
	v_fmac_f32_e32 v17, v14, v12                               // 0000002B6970: 5622190E
	v_mad_u64_u32 v[14:15], null, s10, 12, v[7:8]              // 0000002B6974: D6FE7C0E 041D180A
	v_fma_f32 v11, -v11, v17, v16                              // 0000002B697C: D613000B 2442230B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002B6984: BF870112
	v_mad_u64_u32 v[15:16], null, s11, 12, v[15:16]            // 0000002B6988: D6FE7C0F 043D180B
	v_div_fmas_f32 v11, v11, v12, v17                          // 0000002B6990: D637000B 0446190B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002B6998: BF870001
	v_div_fixup_f32 v5, v11, v5, 1.0                           // 0000002B699C: D6270005 03CA0B0B
	global_store_b32 v[14:15], v5, off                         // 0000002B69A4: DC6A0000 007C050E
	s_mov_b32 s9, 0                                            // 0000002B69AC: BE890080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002B69B0: BF870009
	s_and_b32 vcc_lo, exec_lo, s9                              // 0000002B69B4: 8B6A097E
	s_cbranch_vccz 46                                          // 0000002B69B8: BFA3002E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2274>
	v_bfe_u32 v5, v6, 16, 1                                    // 0000002B69BC: D6100005 02052106
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B69C4: BF870091
	v_add3_u32 v5, v6, v5, 0x7fff                              // 0000002B69C8: D6550005 03FE0B06 00007FFF
	v_and_b32_e32 v5, 0xffff0000, v5                           // 0000002B69D4: 360A0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B69DC: BF870091
	v_mul_f32_e32 v5, s2, v5                                   // 0000002B69E0: 100A0A02
	v_mul_f32_e32 v5, 0xbfb8aa3b, v5                           // 0000002B69E4: 100A0AFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002B69EC: BF870291
	v_exp_f32_e32 v5, v5                                       // 0000002B69F0: 7E0A4B05
	v_add_f32_e32 v5, 1.0, v5                                  // 0000002B69F4: 060A0AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B69F8: BF870091
	v_div_scale_f32 v11, null, v5, v5, 1.0                     // 0000002B69FC: D6FC7C0B 03CA0B05
	v_rcp_f32_e32 v12, v11                                     // 0000002B6A04: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B6A08: BF870095
	v_fma_f32 v14, -v11, v12, 1.0                              // 0000002B6A0C: D613000E 23CA190B
	v_fmac_f32_e32 v12, v14, v12                               // 0000002B6A14: 5618190E
	v_div_scale_f32 v14, vcc_lo, 1.0, v5, 1.0                  // 0000002B6A18: D6FC6A0E 03CA0AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B6A20: BF870091
	v_mul_f32_e32 v16, v14, v12                                // 0000002B6A24: 1020190E
	v_fma_f32 v15, -v11, v16, v14                              // 0000002B6A28: D613000F 243A210B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B6A30: BF870091
	v_fmac_f32_e32 v16, v15, v12                               // 0000002B6A34: 5620190F
	v_fma_f32 v11, -v11, v16, v14                              // 0000002B6A38: D613000B 243A210B
	v_mad_u64_u32 v[14:15], null, s10, 12, v[7:8]              // 0000002B6A40: D6FE7C0E 041D180A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002B6A48: BF870112
	v_div_fmas_f32 v11, v11, v12, v16                          // 0000002B6A4C: D637000B 0442190B
	v_mad_u64_u32 v[15:16], null, s11, 12, v[15:16]            // 0000002B6A54: D6FE7C0F 043D180B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B6A5C: BF870092
	v_div_fixup_f32 v5, v11, v5, 1.0                           // 0000002B6A60: D6270005 03CA0B0B
	v_add_f32_e32 v5, v5, v5                                   // 0000002B6A68: 060A0B05
	global_store_b32 v[14:15], v5, off                         // 0000002B6A6C: DC6A0000 007C050E
	s_mov_b32 s9, 0                                            // 0000002B6A74: BE890080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002B6A78: BF870009
	s_and_b32 vcc_lo, exec_lo, s9                              // 0000002B6A7C: 8B6A097E
	s_cbranch_vccz 59                                          // 0000002B6A80: BFA3003B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2370>
	s_cmp_gt_i32 s3, 1                                         // 0000002B6A84: BF028103
	s_mov_b32 s1, -1                                           // 0000002B6A88: BE8100C1
	s_cbranch_scc0 50                                          // 0000002B6A8C: BFA10032 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2358>
	v_bfe_u32 v5, v6, 16, 1                                    // 0000002B6A90: D6100005 02052106
	s_mov_b32 s1, 0                                            // 0000002B6A98: BE810080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B6A9C: BF870091
	v_add3_u32 v5, v6, v5, 0x7fff                              // 0000002B6AA0: D6550005 03FE0B06 00007FFF
	v_and_b32_e32 v5, 0xffff0000, v5                           // 0000002B6AAC: 360A0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B6AB4: BF870091
	v_mul_f32_e32 v5, 0xbfb8aa3b, v5                           // 0000002B6AB8: 100A0AFF BFB8AA3B
	v_exp_f32_e32 v5, v5                                       // 0000002B6AC0: 7E0A4B05
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B6AC4: BF870095
	v_add_f32_e32 v5, 1.0, v5                                  // 0000002B6AC8: 060A0AF2
	v_div_scale_f32 v11, null, v5, v5, 1.0                     // 0000002B6ACC: D6FC7C0B 03CA0B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002B6AD4: BF870291
	v_rcp_f32_e32 v12, v11                                     // 0000002B6AD8: 7E18550B
	v_fma_f32 v14, -v11, v12, 1.0                              // 0000002B6ADC: D613000E 23CA190B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002B6AE4: BF8700A1
	v_fmac_f32_e32 v12, v14, v12                               // 0000002B6AE8: 5618190E
	v_div_scale_f32 v14, vcc_lo, 1.0, v5, 1.0                  // 0000002B6AEC: D6FC6A0E 03CA0AF2
	v_mul_f32_e32 v15, v14, v12                                // 0000002B6AF4: 101E190E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B6AF8: BF870091
	v_fma_f32 v16, -v11, v15, v14                              // 0000002B6AFC: D6130010 243A1F0B
	v_fmac_f32_e32 v15, v16, v12                               // 0000002B6B04: 561E1910
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B6B08: BF870091
	v_fma_f32 v11, -v11, v15, v14                              // 0000002B6B0C: D613000B 243A1F0B
	v_div_fmas_f32 v11, v11, v12, v15                          // 0000002B6B14: D637000B 043E190B
	v_mad_u64_u32 v[14:15], null, s10, 6, v[3:4]               // 0000002B6B1C: D6FE7C0E 040D0C0A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002B6B24: BF870112
	v_div_fixup_f32 v5, v11, v5, 1.0                           // 0000002B6B28: D6270005 03CA0B0B
	v_mad_u64_u32 v[15:16], null, s11, 6, v[15:16]             // 0000002B6B30: D6FE7C0F 043D0C0B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B6B38: BF870092
	v_bfe_u32 v11, v5, 16, 1                                   // 0000002B6B3C: D610000B 02052105
	v_add3_u32 v5, v5, v11, 0x7fff                             // 0000002B6B44: D6550005 03FE1705 00007FFF
	global_store_d16_hi_b16 v[14:15], v5, off                  // 0000002B6B50: DC960000 007C050E
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002B6B58: 916A017E
	s_mov_b32 s1, 0                                            // 0000002B6B5C: BE810080
	s_cbranch_vccnz 3                                          // 0000002B6B60: BFA40003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2370>
	s_cmp_lg_u32 s3, 1                                         // 0000002B6B64: BF078103
	s_mov_b32 s1, -1                                           // 0000002B6B68: BE8100C1
	s_cselect_b32 s8, -1, 0                                    // 0000002B6B6C: 980880C1
	v_bfe_u32 v5, v6, 16, 1                                    // 0000002B6B70: D6100005 02052106
	s_and_b32 vcc_lo, exec_lo, s8                              // 0000002B6B78: 8B6A087E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002B6B7C: BF870001
	v_add3_u32 v5, v6, v5, 0x7fff                              // 0000002B6B80: D6550005 03FE0B06 00007FFF
	s_cbranch_vccz 7                                           // 0000002B6B8C: BFA30007 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x23ac>
	v_mad_u64_u32 v[14:15], null, s10, 6, v[3:4]               // 0000002B6B90: D6FE7C0E 040D0C0A
	s_mov_b32 s1, 0                                            // 0000002B6B98: BE810080
	v_mad_u64_u32 v[15:16], null, s11, 6, v[15:16]             // 0000002B6B9C: D6FE7C0F 043D0C0B
	global_store_d16_hi_b16 v[14:15], v5, off                  // 0000002B6BA4: DC960000 007C050E
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002B6BAC: 916A017E
	s_cbranch_vccnz 45                                         // 0000002B6BB0: BFA4002D <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2468>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B6BB4: BF870091
	v_and_b32_e32 v5, 0xffff0000, v5                           // 0000002B6BB8: 360A0AFF FFFF0000
	v_mul_f32_e32 v5, s2, v5                                   // 0000002B6BC0: 100A0A02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B6BC4: BF870091
	v_mul_f32_e32 v6, 0xbfb8aa3b, v5                           // 0000002B6BC8: 100C0AFF BFB8AA3B
	v_exp_f32_e32 v6, v6                                       // 0000002B6BD0: 7E0C4B06
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B6BD4: BF870095
	v_add_f32_e32 v6, 1.0, v6                                  // 0000002B6BD8: 060C0CF2
	v_div_scale_f32 v11, null, v6, v6, v5                      // 0000002B6BDC: D6FC7C0B 04160D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002B6BE4: BF870291
	v_rcp_f32_e32 v12, v11                                     // 0000002B6BE8: 7E18550B
	v_fma_f32 v14, -v11, v12, 1.0                              // 0000002B6BEC: D613000E 23CA190B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002B6BF4: BF8700A1
	v_fmac_f32_e32 v12, v14, v12                               // 0000002B6BF8: 5618190E
	v_div_scale_f32 v14, vcc_lo, v5, v6, v5                    // 0000002B6BFC: D6FC6A0E 04160D05
	v_mul_f32_e32 v15, v14, v12                                // 0000002B6C04: 101E190E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B6C08: BF870091
	v_fma_f32 v16, -v11, v15, v14                              // 0000002B6C0C: D6130010 243A1F0B
	v_fmac_f32_e32 v15, v16, v12                               // 0000002B6C14: 561E1910
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B6C18: BF870091
	v_fma_f32 v11, -v11, v15, v14                              // 0000002B6C1C: D613000B 243A1F0B
	v_div_fmas_f32 v11, v11, v12, v15                          // 0000002B6C24: D637000B 043E190B
	v_mad_u64_u32 v[14:15], null, s10, 6, v[3:4]               // 0000002B6C2C: D6FE7C0E 040D0C0A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002B6C34: BF870112
	v_div_fixup_f32 v5, v11, v6, v5                            // 0000002B6C38: D6270005 04160D0B
	v_mad_u64_u32 v[15:16], null, s11, 6, v[15:16]             // 0000002B6C40: D6FE7C0F 043D0C0B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B6C48: BF870092
	v_bfe_u32 v6, v5, 16, 1                                    // 0000002B6C4C: D6100006 02052105
	v_add3_u32 v5, v5, v6, 0x7fff                              // 0000002B6C54: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[14:15], v5, off                  // 0000002B6C60: DC960000 007C050E
	s_mov_b32 s9, -1                                           // 0000002B6C68: BE8900C1
	s_mov_b32 s1, 0                                            // 0000002B6C6C: BE810080
	s_cmp_lt_i32 s3, 3                                         // 0000002B6C70: BF048303
	s_mov_b32 s8, 0                                            // 0000002B6C74: BE880080
	s_cbranch_scc1 135                                         // 0000002B6C78: BFA20087 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2698>
	s_cmp_gt_i32 s3, 3                                         // 0000002B6C7C: BF028303
	s_cbranch_scc0 82                                          // 0000002B6C80: BFA10052 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x25cc>
	s_cmp_gt_i32 s3, 4                                         // 0000002B6C84: BF028403
	s_cbranch_scc0 40                                          // 0000002B6C88: BFA10028 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x252c>
	s_cmp_eq_u32 s3, 5                                         // 0000002B6C8C: BF068503
	s_mov_b32 s8, -1                                           // 0000002B6C90: BE8800C1
	s_cbranch_scc0 36                                          // 0000002B6C94: BFA10024 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2528>
	s_load_b64 s[8:9], s[16:17], 0x10                          // 0000002B6C98: F4040208 F8000010
	v_dual_mov_b32 v5, s4 :: v_dual_mov_b32 v6, s5             // 0000002B6CA0: CA100004 05060005
	v_bfe_u32 v11, v1, 16, 1                                   // 0000002B6CA8: D610000B 02052101
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002B6CB0: BF8701A1
	v_add3_u32 v11, v1, v11, 0x7fff                            // 0000002B6CB4: D655000B 03FE1701 00007FFF
	s_waitcnt lgkmcnt(0)                                       // 0000002B6CC0: BF89FC07
	v_cndmask_b32_e64 v5, s8, v5, s0                           // 0000002B6CC4: D5010005 00020A08
	v_cndmask_b32_e64 v6, s9, v6, s0                           // 0000002B6CCC: D5010006 00020C09
	s_lshl_b64 s[8:9], s[6:7], 3                               // 0000002B6CD4: 84888306
	s_delay_alu instid0(VALU_DEP_2) | instid1(SALU_CYCLE_1)    // 0000002B6CD8: BF870482
	.long 0xd7006a0c                                           // 0000002B6CDC: D7006A0C
	v_cndmask_b32_e32 v0, v5, v8, vcc_lo                       // 0000002B6CE0: 02001105
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002B6CE4: BF8701A1
	v_add_co_ci_u32_e64 v14, null, s9, v6, vcc_lo              // 0000002B6CE8: D5207C0E 01AA0C09
	.long 0xd73c0005                                           // 0000002B6CF0: D73C0005
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 0000002B6CF4: 02021281
	.long 0xd7006a0c                                           // 0000002B6CF8: D7006A0C
	v_cndmask_b32_e32 v1, v12, v13, vcc_lo                     // 0000002B6CFC: 02021B0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002B6D00: BF8700B1
	v_add_co_ci_u32_e64 v14, null, v14, v0, vcc_lo             // 0000002B6D04: D5207C0E 01AA010E
	s_mov_b32 s8, 0                                            // 0000002B6D0C: BE880080
	.long 0xd7006a05                                           // 0000002B6D10: D7006A05
	v_cndmask_b32_e32 v1, v12, v5, vcc_lo                      // 0000002B6D14: 02020B0C
	v_add_co_ci_u32_e64 v6, null, v14, v6, vcc_lo              // 0000002B6D18: D5207C06 01AA0D0E
	global_store_d16_hi_b16 v[5:6], v11, off                   // 0000002B6D20: DC960000 007C0B05
	s_mov_b32 s9, 0                                            // 0000002B6D28: BE890080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002B6D2C: BF870009
	s_and_b32 vcc_lo, exec_lo, s9                              // 0000002B6D30: 8B6A097E
	s_cbranch_vccz 36                                          // 0000002B6D34: BFA30024 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x25c8>
	v_mul_f32_e32 v5, 0xbfb8aa3b, v1                           // 0000002B6D38: 100A02FF BFB8AA3B
	s_lshl_b64 s[12:13], s[10:11], 4                           // 0000002B6D40: 848C840A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002B6D44: BF870291
	v_exp_f32_e32 v5, v5                                       // 0000002B6D48: 7E0A4B05
	v_add_f32_e32 v5, 1.0, v5                                  // 0000002B6D4C: 060A0AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002B6D50: BF870121
	v_div_scale_f32 v6, null, v5, v5, 1.0                      // 0000002B6D54: D6FC7C06 03CA0B05
	v_div_scale_f32 v14, vcc_lo, 1.0, v5, 1.0                  // 0000002B6D5C: D6FC6A0E 03CA0AF2
	v_rcp_f32_e32 v11, v6                                      // 0000002B6D64: 7E165506
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B6D68: BF870095
	v_fma_f32 v12, -v6, v11, 1.0                               // 0000002B6D6C: D613000C 23CA1706
	v_fmac_f32_e32 v11, v12, v11                               // 0000002B6D74: 5616170C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B6D78: BF870091
	v_mul_f32_e32 v12, v14, v11                                // 0000002B6D7C: 1018170E
	v_fma_f32 v15, -v6, v12, v14                               // 0000002B6D80: D613000F 243A1906
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B6D88: BF870091
	v_fmac_f32_e32 v12, v15, v11                               // 0000002B6D8C: 5618170F
	v_fma_f32 v6, -v6, v12, v14                                // 0000002B6D90: D6130006 243A1906
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B6D98: BF870091
	v_div_fmas_f32 v6, v6, v11, v12                            // 0000002B6D9C: D6370006 04321706
	v_div_fixup_f32 v11, v6, v5, 1.0                           // 0000002B6DA4: D627000B 03CA0B06
	.long 0xd7006a05                                           // 0000002B6DAC: D7006A05
	v_cndmask_b32_e32 v0, v7, v12, vcc_lo                      // 0000002B6DB0: 02001907
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002B6DB4: BF870001
	v_add_co_ci_u32_e64 v6, null, s13, v8, vcc_lo              // 0000002B6DB8: D5207C06 01AA100D
	global_store_b32 v[5:6], v11, off                          // 0000002B6DC0: DC6A0000 007C0B05
	s_mov_b32 s9, 0                                            // 0000002B6DC8: BE890080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002B6DCC: BF870009
	s_and_b32 vcc_lo, exec_lo, s9                              // 0000002B6DD0: 8B6A097E
	s_cbranch_vccz 47                                          // 0000002B6DD4: BFA3002F <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2694>
	v_bfe_u32 v5, v1, 16, 1                                    // 0000002B6DD8: D6100005 02052101
	s_lshl_b64 s[12:13], s[10:11], 4                           // 0000002B6DE0: 848C840A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B6DE4: BF870091
	v_add3_u32 v5, v1, v5, 0x7fff                              // 0000002B6DE8: D6550005 03FE0B01 00007FFF
	v_and_b32_e32 v5, 0xffff0000, v5                           // 0000002B6DF4: 360A0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B6DFC: BF870091
	v_mul_f32_e32 v5, s2, v5                                   // 0000002B6E00: 100A0A02
	v_mul_f32_e32 v5, 0xbfb8aa3b, v5                           // 0000002B6E04: 100A0AFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002B6E0C: BF870291
	v_exp_f32_e32 v5, v5                                       // 0000002B6E10: 7E0A4B05
	v_add_f32_e32 v5, 1.0, v5                                  // 0000002B6E14: 060A0AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002B6E18: BF870121
	v_div_scale_f32 v6, null, v5, v5, 1.0                      // 0000002B6E1C: D6FC7C06 03CA0B05
	v_div_scale_f32 v14, vcc_lo, 1.0, v5, 1.0                  // 0000002B6E24: D6FC6A0E 03CA0AF2
	v_rcp_f32_e32 v11, v6                                      // 0000002B6E2C: 7E165506
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B6E30: BF870095
	v_fma_f32 v12, -v6, v11, 1.0                               // 0000002B6E34: D613000C 23CA1706
	v_fmac_f32_e32 v11, v12, v11                               // 0000002B6E3C: 5616170C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B6E40: BF870091
	v_mul_f32_e32 v12, v14, v11                                // 0000002B6E44: 1018170E
	v_fma_f32 v15, -v6, v12, v14                               // 0000002B6E48: D613000F 243A1906
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B6E50: BF870091
	v_fmac_f32_e32 v12, v15, v11                               // 0000002B6E54: 5618170F
	v_fma_f32 v6, -v6, v12, v14                                // 0000002B6E58: D6130006 243A1906
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B6E60: BF870091
	v_div_fmas_f32 v6, v6, v11, v12                            // 0000002B6E64: D6370006 04321706
	v_div_fixup_f32 v5, v6, v5, 1.0                            // 0000002B6E6C: D6270005 03CA0B06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002B6E74: BF8700A1
	v_add_f32_e32 v11, v5, v5                                  // 0000002B6E78: 06160B05
	.long 0xd7006a05                                           // 0000002B6E7C: D7006A05
	v_cndmask_b32_e32 v0, v7, v12, vcc_lo                      // 0000002B6E80: 02001907
	v_add_co_ci_u32_e64 v6, null, s13, v8, vcc_lo              // 0000002B6E84: D5207C06 01AA100D
	global_store_b32 v[5:6], v11, off                          // 0000002B6E8C: DC6A0000 007C0B05
	s_mov_b32 s9, 0                                            // 0000002B6E94: BE890080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002B6E98: BF870009
	s_and_b32 vcc_lo, exec_lo, s9                              // 0000002B6E9C: 8B6A097E
	s_cbranch_vccz 60                                          // 0000002B6EA0: BFA3003C <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2794>
	s_cmp_gt_i32 s3, 1                                         // 0000002B6EA4: BF028103
	s_mov_b32 s1, -1                                           // 0000002B6EA8: BE8100C1
	s_cbranch_scc0 51                                          // 0000002B6EAC: BFA10033 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x277c>
	v_bfe_u32 v5, v1, 16, 1                                    // 0000002B6EB0: D6100005 02052101
	s_lshl_b64 s[12:13], s[10:11], 3                           // 0000002B6EB8: 848C830A
	s_mov_b32 s1, 0                                            // 0000002B6EBC: BE810080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B6EC0: BF870091
	v_add3_u32 v5, v1, v5, 0x7fff                              // 0000002B6EC4: D6550005 03FE0B01 00007FFF
	v_and_b32_e32 v5, 0xffff0000, v5                           // 0000002B6ED0: 360A0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B6ED8: BF870091
	v_mul_f32_e32 v5, 0xbfb8aa3b, v5                           // 0000002B6EDC: 100A0AFF BFB8AA3B
	v_exp_f32_e32 v5, v5                                       // 0000002B6EE4: 7E0A4B05
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B6EE8: BF870095
	v_add_f32_e32 v5, 1.0, v5                                  // 0000002B6EEC: 060A0AF2
	v_div_scale_f32 v6, null, v5, v5, 1.0                      // 0000002B6EF0: D6FC7C06 03CA0B05
	v_div_scale_f32 v14, vcc_lo, 1.0, v5, 1.0                  // 0000002B6EF8: D6FC6A0E 03CA0AF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002B6F00: BF870292
	v_rcp_f32_e32 v11, v6                                      // 0000002B6F04: 7E165506
	v_fma_f32 v12, -v6, v11, 1.0                               // 0000002B6F08: D613000C 23CA1706
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B6F10: BF870091
	v_fmac_f32_e32 v11, v12, v11                               // 0000002B6F14: 5616170C
	v_mul_f32_e32 v12, v14, v11                                // 0000002B6F18: 1018170E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B6F1C: BF870091
	v_fma_f32 v15, -v6, v12, v14                               // 0000002B6F20: D613000F 243A1906
	v_fmac_f32_e32 v12, v15, v11                               // 0000002B6F28: 5618170F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B6F2C: BF870091
	v_fma_f32 v6, -v6, v12, v14                                // 0000002B6F30: D6130006 243A1906
	v_div_fmas_f32 v6, v6, v11, v12                            // 0000002B6F38: D6370006 04321706
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B6F40: BF870091
	v_div_fixup_f32 v5, v6, v5, 1.0                            // 0000002B6F44: D6270005 03CA0B06
	v_bfe_u32 v6, v5, 16, 1                                    // 0000002B6F4C: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002B6F54: BF8700A1
	v_add3_u32 v11, v5, v6, 0x7fff                             // 0000002B6F58: D655000B 03FE0D05 00007FFF
	.long 0xd7006a05                                           // 0000002B6F64: D7006A05
	v_cndmask_b32_e32 v0, v3, v12, vcc_lo                      // 0000002B6F68: 02001903
	v_add_co_ci_u32_e64 v6, null, s13, v4, vcc_lo              // 0000002B6F6C: D5207C06 01AA080D
	global_store_d16_hi_b16 v[5:6], v11, off                   // 0000002B6F74: DC960000 007C0B05
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002B6F7C: 916A017E
	s_mov_b32 s1, 0                                            // 0000002B6F80: BE810080
	s_cbranch_vccnz 3                                          // 0000002B6F84: BFA40003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2794>
	s_cmp_lg_u32 s3, 1                                         // 0000002B6F88: BF078103
	s_mov_b32 s1, -1                                           // 0000002B6F8C: BE8100C1
	s_cselect_b32 s8, -1, 0                                    // 0000002B6F90: 980880C1
	v_bfe_u32 v5, v1, 16, 1                                    // 0000002B6F94: D6100005 02052101
	s_and_b32 vcc_lo, exec_lo, s8                              // 0000002B6F9C: 8B6A087E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002B6FA0: BF870001
	v_add3_u32 v1, v1, v5, 0x7fff                              // 0000002B6FA4: D6550001 03FE0B01 00007FFF
	s_cbranch_vccz 9                                           // 0000002B6FB0: BFA30009 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x27d8>
	s_lshl_b64 s[8:9], s[10:11], 3                             // 0000002B6FB4: 8488830A
	s_mov_b32 s1, 0                                            // 0000002B6FB8: BE810080
	.long 0xd7006a05                                           // 0000002B6FBC: D7006A05
	v_cndmask_b32_e32 v0, v3, v8, vcc_lo                       // 0000002B6FC0: 02001103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002B6FC4: BF870001
	v_add_co_ci_u32_e64 v6, null, s9, v4, vcc_lo               // 0000002B6FC8: D5207C06 01AA0809
	global_store_d16_hi_b16 v[5:6], v1, off                    // 0000002B6FD0: DC960000 007C0105
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002B6FD8: 916A017E
	s_cbranch_vccnz 46                                         // 0000002B6FDC: BFA4002E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2898>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002B6FE0: BF8700A1
	v_and_b32_e32 v1, 0xffff0000, v1                           // 0000002B6FE4: 360202FF FFFF0000
	s_lshl_b64 s[8:9], s[10:11], 3                             // 0000002B6FEC: 8488830A
	v_mul_f32_e32 v1, s2, v1                                   // 0000002B6FF0: 10020202
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B6FF4: BF870091
	v_mul_f32_e32 v5, 0xbfb8aa3b, v1                           // 0000002B6FF8: 100A02FF BFB8AA3B
	v_exp_f32_e32 v5, v5                                       // 0000002B7000: 7E0A4B05
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B7004: BF870095
	v_add_f32_e32 v5, 1.0, v5                                  // 0000002B7008: 060A0AF2
	v_div_scale_f32 v6, null, v5, v5, v1                       // 0000002B700C: D6FC7C06 04060B05
	v_div_scale_f32 v14, vcc_lo, v1, v5, v1                    // 0000002B7014: D6FC6A0E 04060B01
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002B701C: BF870292
	v_rcp_f32_e32 v11, v6                                      // 0000002B7020: 7E165506
	v_fma_f32 v12, -v6, v11, 1.0                               // 0000002B7024: D613000C 23CA1706
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B702C: BF870091
	v_fmac_f32_e32 v11, v12, v11                               // 0000002B7030: 5616170C
	v_mul_f32_e32 v12, v14, v11                                // 0000002B7034: 1018170E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B7038: BF870091
	v_fma_f32 v15, -v6, v12, v14                               // 0000002B703C: D613000F 243A1906
	v_fmac_f32_e32 v12, v15, v11                               // 0000002B7044: 5618170F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B7048: BF870091
	v_fma_f32 v6, -v6, v12, v14                                // 0000002B704C: D6130006 243A1906
	v_div_fmas_f32 v6, v6, v11, v12                            // 0000002B7054: D6370006 04321706
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B705C: BF870091
	v_div_fixup_f32 v1, v6, v5, v1                             // 0000002B7060: D6270001 04060B06
	v_bfe_u32 v5, v1, 16, 1                                    // 0000002B7068: D6100005 02052101
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002B7070: BF8700A1
	v_add3_u32 v1, v1, v5, 0x7fff                              // 0000002B7074: D6550001 03FE0B01 00007FFF
	.long 0xd7006a05                                           // 0000002B7080: D7006A05
	v_cndmask_b32_e32 v0, v3, v8, vcc_lo                       // 0000002B7084: 02001103
	v_add_co_ci_u32_e64 v6, null, s9, v4, vcc_lo               // 0000002B7088: D5207C06 01AA0809
	global_store_d16_hi_b16 v[5:6], v1, off                    // 0000002B7090: DC960000 007C0105
	s_mov_b32 s9, -1                                           // 0000002B7098: BE8900C1
	s_mov_b32 s1, 0                                            // 0000002B709C: BE810080
	s_cmp_lt_i32 s3, 3                                         // 0000002B70A0: BF048303
	s_mov_b32 s8, 0                                            // 0000002B70A4: BE880080
	s_cbranch_scc1 133                                         // 0000002B70A8: BFA20085 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2ac0>
	s_cmp_gt_i32 s3, 3                                         // 0000002B70AC: BF028303
	s_cbranch_scc0 42                                          // 0000002B70B0: BFA1002A <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x295c>
	s_cmp_gt_i32 s3, 4                                         // 0000002B70B4: BF028403
	s_cbranch_scc0 42                                          // 0000002B70B8: BFA1002A <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2964>
	s_cmp_eq_u32 s3, 5                                         // 0000002B70BC: BF068503
	s_mov_b32 s8, -1                                           // 0000002B70C0: BE8800C1
	s_cbranch_scc0 35                                          // 0000002B70C4: BFA10023 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2954>
	s_load_b64 s[8:9], s[16:17], 0x10                          // 0000002B70C8: F4040208 F8000010
	v_mov_b32_e32 v1, s5                                       // 0000002B70D0: 7E020205
	v_mov_b32_e32 v5, s4                                       // 0000002B70D4: 7E0A0204
	.long 0xd73c0009                                           // 0000002B70D8: D73C0009
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 0000002B70DC: 02021281
	s_waitcnt lgkmcnt(0)                                       // 0000002B70E0: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002B70E4: BF870193
	v_cndmask_b32_e64 v6, s9, v1, s0                           // 0000002B70E8: D5010006 00020209
	v_cndmask_b32_e64 v5, s8, v5, s0                           // 0000002B70F0: D5010005 00020A08
	v_bfe_u32 v1, v2, 16, 1                                    // 0000002B70F8: D6100001 02052102
	s_mov_b32 s8, 0                                            // 0000002B7100: BE880080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B7104: BF870092
	v_mad_u64_u32 v[5:6], null, s6, 10, v[5:6]                 // 0000002B7108: D6FE7C05 04151406
	v_mad_u64_u32 v[11:12], null, s7, 10, v[6:7]               // 0000002B7110: D6FE7C0B 04191407
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B7118: BF870092
	.long 0xd7006a05                                           // 0000002B711C: D7006A05
	v_cndmask_b32_e32 v1, v5, v13, vcc_lo                      // 0000002B7120: 02021B05
	v_add_co_ci_u32_e64 v6, null, v11, v0, vcc_lo              // 0000002B7124: D5207C06 01AA010B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002B712C: BF8701A2
	.long 0xd7006a00                                           // 0000002B7130: D7006A00
	v_cndmask_b32_e32 v1, v5, v9, vcc_lo                       // 0000002B7134: 02021305
	v_add3_u32 v11, v2, v1, 0x7fff                             // 0000002B7138: D655000B 03FE0302 00007FFF
	v_add_co_ci_u32_e64 v1, null, v6, v10, vcc_lo              // 0000002B7144: D5207C01 01AA1506
	global_store_d16_hi_b16 v[0:1], v11, off                   // 0000002B714C: DC960000 007C0B00
	s_mov_b32 s0, 0                                            // 0000002B7154: BE800080
	s_branch 3                                                 // 0000002B7158: BFA00003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2968>
	s_cbranch_execnz 41                                        // 0000002B715C: BFA60029 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2a04>
	s_branch 86                                                // 0000002B7160: BFA00056 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2abc>
	s_mov_b32 s0, -1                                           // 0000002B7164: BE8000C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002B7168: BF870009
	s_and_b32 vcc_lo, exec_lo, s0                              // 0000002B716C: 8B6A007E
	s_cbranch_vccz 35                                          // 0000002B7170: BFA30023 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2a00>
	v_mul_f32_e32 v0, 0xbfb8aa3b, v2                           // 0000002B7174: 100004FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002B717C: BF870291
	v_exp_f32_e32 v0, v0                                       // 0000002B7180: 7E004B00
	v_add_f32_e32 v0, 1.0, v0                                  // 0000002B7184: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B7188: BF870091
	v_div_scale_f32 v1, null, v0, v0, 1.0                      // 0000002B718C: D6FC7C01 03CA0100
	v_rcp_f32_e32 v5, v1                                       // 0000002B7194: 7E0A5501
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B7198: BF870095
	v_fma_f32 v6, -v1, v5, 1.0                                 // 0000002B719C: D6130006 23CA0B01
	v_fmac_f32_e32 v5, v6, v5                                  // 0000002B71A4: 560A0B06
	v_div_scale_f32 v6, vcc_lo, 1.0, v0, 1.0                   // 0000002B71A8: D6FC6A06 03CA00F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B71B0: BF870091
	v_mul_f32_e32 v11, v6, v5                                  // 0000002B71B4: 10160B06
	v_fma_f32 v9, -v1, v11, v6                                 // 0000002B71B8: D6130009 241A1701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002B71C0: BF870121
	v_fmac_f32_e32 v11, v9, v5                                 // 0000002B71C4: 56160B09
	v_mad_u64_u32 v[9:10], null, s10, 20, v[7:8]               // 0000002B71C8: D6FE7C09 041D280A
	v_fma_f32 v1, -v1, v11, v6                                 // 0000002B71D0: D6130001 241A1701
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002B71D8: BF870191
	v_div_fmas_f32 v1, v1, v5, v11                             // 0000002B71DC: D6370001 042E0B01
	v_mad_u64_u32 v[10:11], null, s11, 20, v[10:11]            // 0000002B71E4: D6FE7C0A 0429280B
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002B71EC: BF870002
	v_div_fixup_f32 v0, v1, v0, 1.0                            // 0000002B71F0: D6270000 03CA0101
	global_store_b32 v[9:10], v0, off                          // 0000002B71F8: DC6A0000 007C0009
	s_branch 46                                                // 0000002B7200: BFA0002E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2abc>
	v_bfe_u32 v0, v2, 16, 1                                    // 0000002B7204: D6100000 02052102
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B720C: BF870091
	v_add3_u32 v0, v2, v0, 0x7fff                              // 0000002B7210: D6550000 03FE0102 00007FFF
	v_and_b32_e32 v0, 0xffff0000, v0                           // 0000002B721C: 360000FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B7224: BF870091
	v_mul_f32_e32 v0, s2, v0                                   // 0000002B7228: 10000002
	v_mul_f32_e32 v0, 0xbfb8aa3b, v0                           // 0000002B722C: 100000FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002B7234: BF870291
	v_exp_f32_e32 v0, v0                                       // 0000002B7238: 7E004B00
	v_add_f32_e32 v0, 1.0, v0                                  // 0000002B723C: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B7240: BF870091
	v_div_scale_f32 v1, null, v0, v0, 1.0                      // 0000002B7244: D6FC7C01 03CA0100
	v_rcp_f32_e32 v9, v1                                       // 0000002B724C: 7E125501
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B7250: BF870095
	v_fma_f32 v5, -v1, v9, 1.0                                 // 0000002B7254: D6130005 23CA1301
	v_fmac_f32_e32 v9, v5, v9                                  // 0000002B725C: 56121305
	v_div_scale_f32 v5, vcc_lo, 1.0, v0, 1.0                   // 0000002B7260: D6FC6A05 03CA00F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B7268: BF870091
	v_mul_f32_e32 v10, v5, v9                                  // 0000002B726C: 10141305
	v_fma_f32 v6, -v1, v10, v5                                 // 0000002B7270: D6130006 24161501
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B7278: BF870091
	v_fmac_f32_e32 v10, v6, v9                                 // 0000002B727C: 56141306
	v_fma_f32 v1, -v1, v10, v5                                 // 0000002B7280: D6130001 24161501
	v_mad_u64_u32 v[5:6], null, s10, 20, v[7:8]                // 0000002B7288: D6FE7C05 041D280A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002B7290: BF870112
	v_div_fmas_f32 v1, v1, v9, v10                             // 0000002B7294: D6370001 042A1301
	v_mad_u64_u32 v[6:7], null, s11, 20, v[6:7]                // 0000002B729C: D6FE7C06 0419280B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B72A4: BF870092
	v_div_fixup_f32 v0, v1, v0, 1.0                            // 0000002B72A8: D6270000 03CA0101
	v_add_f32_e32 v0, v0, v0                                   // 0000002B72B0: 06000100
	global_store_b32 v[5:6], v0, off                           // 0000002B72B4: DC6A0000 007C0005
	s_mov_b32 s9, 0                                            // 0000002B72BC: BE890080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002B72C0: BF870009
	s_and_b32 vcc_lo, exec_lo, s9                              // 0000002B72C4: 8B6A097E
	s_cbranch_vccz 58                                          // 0000002B72C8: BFA3003A <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2bb4>
	s_cmp_gt_i32 s3, 1                                         // 0000002B72CC: BF028103
	s_mov_b32 s0, -1                                           // 0000002B72D0: BE8000C1
	s_cbranch_scc0 50                                          // 0000002B72D4: BFA10032 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2ba0>
	v_bfe_u32 v0, v2, 16, 1                                    // 0000002B72D8: D6100000 02052102
	s_mov_b32 s0, 0                                            // 0000002B72E0: BE800080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B72E4: BF870091
	v_add3_u32 v0, v2, v0, 0x7fff                              // 0000002B72E8: D6550000 03FE0102 00007FFF
	v_and_b32_e32 v0, 0xffff0000, v0                           // 0000002B72F4: 360000FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B72FC: BF870091
	v_mul_f32_e32 v0, 0xbfb8aa3b, v0                           // 0000002B7300: 100000FF BFB8AA3B
	v_exp_f32_e32 v0, v0                                       // 0000002B7308: 7E004B00
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B730C: BF870095
	v_add_f32_e32 v0, 1.0, v0                                  // 0000002B7310: 060000F2
	v_div_scale_f32 v1, null, v0, v0, 1.0                      // 0000002B7314: D6FC7C01 03CA0100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002B731C: BF870291
	v_rcp_f32_e32 v5, v1                                       // 0000002B7320: 7E0A5501
	v_fma_f32 v6, -v1, v5, 1.0                                 // 0000002B7324: D6130006 23CA0B01
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002B732C: BF8700A1
	v_fmac_f32_e32 v5, v6, v5                                  // 0000002B7330: 560A0B06
	v_div_scale_f32 v6, vcc_lo, 1.0, v0, 1.0                   // 0000002B7334: D6FC6A06 03CA00F2
	v_mul_f32_e32 v7, v6, v5                                   // 0000002B733C: 100E0B06
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B7340: BF870091
	v_fma_f32 v8, -v1, v7, v6                                  // 0000002B7344: D6130008 241A0F01
	v_fmac_f32_e32 v7, v8, v5                                  // 0000002B734C: 560E0B08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B7350: BF870091
	v_fma_f32 v1, -v1, v7, v6                                  // 0000002B7354: D6130001 241A0F01
	v_div_fmas_f32 v1, v1, v5, v7                              // 0000002B735C: D6370001 041E0B01
	v_mad_u64_u32 v[5:6], null, s10, 10, v[3:4]                // 0000002B7364: D6FE7C05 040D140A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002B736C: BF870112
	v_div_fixup_f32 v0, v1, v0, 1.0                            // 0000002B7370: D6270000 03CA0101
	v_mad_u64_u32 v[6:7], null, s11, 10, v[6:7]                // 0000002B7378: D6FE7C06 0419140B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B7380: BF870092
	v_bfe_u32 v1, v0, 16, 1                                    // 0000002B7384: D6100001 02052100
	v_add3_u32 v0, v0, v1, 0x7fff                              // 0000002B738C: D6550000 03FE0300 00007FFF
	global_store_d16_hi_b16 v[5:6], v0, off                    // 0000002B7398: DC960000 007C0005
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 0000002B73A0: 916A007E
	s_cbranch_vccnz 3                                          // 0000002B73A4: BFA40003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2bb4>
	s_cmp_lg_u32 s3, 1                                         // 0000002B73A8: BF078103
	s_mov_b32 s1, -1                                           // 0000002B73AC: BE8100C1
	s_cselect_b32 s8, -1, 0                                    // 0000002B73B0: 980880C1
	v_bfe_u32 v0, v2, 16, 1                                    // 0000002B73B4: D6100000 02052102
	s_and_b32 vcc_lo, exec_lo, s8                              // 0000002B73BC: 8B6A087E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002B73C0: BF870001
	v_add3_u32 v0, v2, v0, 0x7fff                              // 0000002B73C4: D6550000 03FE0102 00007FFF
	s_cbranch_vccz 7                                           // 0000002B73D0: BFA30007 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2bf0>
	v_mad_u64_u32 v[5:6], null, s10, 10, v[3:4]                // 0000002B73D4: D6FE7C05 040D140A
	s_mov_b32 s1, 0                                            // 0000002B73DC: BE810080
	v_mad_u64_u32 v[6:7], null, s11, 10, v[6:7]                // 0000002B73E0: D6FE7C06 0419140B
	global_store_d16_hi_b16 v[5:6], v0, off                    // 0000002B73E8: DC960000 007C0005
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002B73F0: 916A017E
	s_cbranch_vccnz 45                                         // 0000002B73F4: BFA4002D <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi6ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2cac>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B73F8: BF870091
	v_and_b32_e32 v0, 0xffff0000, v0                           // 0000002B73FC: 360000FF FFFF0000
	v_mul_f32_e32 v2, s2, v0                                   // 0000002B7404: 10040002
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B7408: BF870091
	v_mul_f32_e32 v0, 0xbfb8aa3b, v2                           // 0000002B740C: 100004FF BFB8AA3B
	v_exp_f32_e32 v0, v0                                       // 0000002B7414: 7E004B00
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B7418: BF870095
	v_add_f32_e32 v5, 1.0, v0                                  // 0000002B741C: 060A00F2
	v_div_scale_f32 v0, null, v5, v5, v2                       // 0000002B7420: D6FC7C00 040A0B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002B7428: BF870291
	v_rcp_f32_e32 v1, v0                                       // 0000002B742C: 7E025500
	v_fma_f32 v6, -v0, v1, 1.0                                 // 0000002B7430: D6130006 23CA0300
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002B7438: BF8700A1
	v_fmac_f32_e32 v1, v6, v1                                  // 0000002B743C: 56020306
	v_div_scale_f32 v6, vcc_lo, v2, v5, v2                     // 0000002B7440: D6FC6A06 040A0B02
	v_mul_f32_e32 v7, v6, v1                                   // 0000002B7448: 100E0306
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B744C: BF870091
	v_fma_f32 v8, -v0, v7, v6                                  // 0000002B7450: D6130008 241A0F00
	v_fmac_f32_e32 v7, v8, v1                                  // 0000002B7458: 560E0308
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B745C: BF870091
	v_fma_f32 v0, -v0, v7, v6                                  // 0000002B7460: D6130000 241A0F00
	v_div_fmas_f32 v6, v0, v1, v7                              // 0000002B7468: D6370006 041E0300
	v_mad_u64_u32 v[0:1], null, s10, 10, v[3:4]                // 0000002B7470: D6FE7C00 040D140A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002B7478: BF870112
	v_div_fixup_f32 v3, v6, v5, v2                             // 0000002B747C: D6270003 040A0B06
	v_mad_u64_u32 v[1:2], null, s11, 10, v[1:2]                // 0000002B7484: D6FE7C01 0405140B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002B748C: BF870092
	v_bfe_u32 v4, v3, 16, 1                                    // 0000002B7490: D6100004 02052103
	v_add3_u32 v2, v3, v4, 0x7fff                              // 0000002B7498: D6550002 03FE0903 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off                    // 0000002B74A4: DC960000 007C0200
	s_nop 0                                                    // 0000002B74AC: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000002B74B0: BFB60003
	s_endpgm                                                   // 0000002B74B4: BFB00000
		...

