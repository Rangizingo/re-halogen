0000000000583b00 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi3ELi32ELi8ELb0EEEvPKhPKtPvll>:
; _ZN7halogen12_GLOBAL__N_18k_lq8s32ILi3ELi32ELi8ELb0EEEvPKhPKtPvll():
	s_clause 0x1                                               // 000000583B00: BF850001
	s_load_b256 s[4:11], s[0:1], null                          // 000000583B04: F40C0100 F8000000
	s_load_b64 s[12:13], s[0:1], 0x20                          // 000000583B0C: F4040300 F8000020
	s_mov_b32 s3, 0                                            // 000000583B14: BE830080
	v_lshrrev_b32_e32 v14, 5, v0                               // 000000583B18: 321C0085
	v_dual_mov_b32 v6, 0 :: v_dual_and_b32 v15, 31, v0         // 000000583B1C: CA240080 060E009F
	v_dual_mov_b32 v16, 0 :: v_dual_mov_b32 v5, 0              // 000000583B24: CA100080 10040080
	.long 0x7e303880                                           // 000000583B2C: 7E303880
	v_mov_b32_e32 v8, 0                                        // 000000583B30: 7E100280
	s_waitcnt lgkmcnt(0)                                       // 000000583B34: BF89FC07
	s_ashr_i32 s0, s11, 31                                     // 000000583B38: 86009F0B
	.long 0xd451000e                                           // 000000583B3C: D451000E
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 000000583B40: 02001802
	s_lshr_b32 s0, s0, 28                                      // 000000583B44: 85009C00
	v_dual_mov_b32 v1, s4 :: v_dual_mov_b32 v2, s5             // 000000583B48: CA100004 01020005
	s_add_u32 s0, s10, s0                                      // 000000583B50: 8000000A
	s_addc_u32 s1, s11, 0                                      // 000000583B54: 8201800B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000583B58: BF870499
	s_ashr_i64 s[0:1], s[0:1], 4                               // 000000583B5C: 86808400
	s_add_u32 s15, s10, s0                                     // 000000583B60: 800F000A
	s_addc_u32 s1, s11, s1                                     // 000000583B64: 8201010B
	s_add_u32 s15, s15, 15                                     // 000000583B68: 800F8F0F
	s_addc_u32 s1, s1, 0                                       // 000000583B6C: 82018001
	s_and_b32 s15, s15, -16                                    // 000000583B70: 8B0FD00F
	s_and_b32 s14, s14, exec_lo                                // 000000583B74: 8B0E7E0E
	s_cselect_b32 s14, s2, 0                                   // 000000583B78: 980E8002
	s_add_i32 s16, s0, 7                                       // 000000583B7C: 81108700
	v_mad_u64_u32 v[10:11], null, s14, s15, v[1:2]             // 000000583B80: D6FE7C0A 04041E0E
	s_ashr_i32 s17, s16, 31                                    // 000000583B88: 86119F10
	s_mul_i32 s14, s14, s1                                     // 000000583B8C: 960E010E
	s_lshr_b32 s17, s17, 29                                    // 000000583B90: 85119D11
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000583B94: BF870499
	s_add_i32 s16, s16, s17                                    // 000000583B98: 81101110
	s_ashr_i32 s4, s16, 3                                      // 000000583B9C: 86048310
	v_add_nc_u32_e32 v11, s14, v11                             // 000000583BA0: 4A16160E
	.long 0xd72c0003                                           // 000000583BA4: D72C0003
	v_cndmask_b32_e32 v1, s4, v14, vcc_lo                      // 000000583BA8: 02021C04
	.long 0xd7006a13                                           // 000000583BAC: D7006A13
	v_cndmask_b32_e32 v0, v10, v10, vcc_lo                     // 000000583BB0: 0200150A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000583BB4: BF870191
	v_add_co_ci_u32_e64 v20, null, s11, v11, vcc_lo            // 000000583BB8: D5207C14 01AA160B
	v_add_nc_u32_e32 v1, s4, v3                                // 000000583BC0: 4A020604
	v_add_nc_u32_e32 v17, v3, v15                              // 000000583BC4: 4A221F03
	v_mov_b32_e32 v7, 0                                        // 000000583BC8: 7E0E0280
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000583BCC: BF870193
	v_min_i32_e32 v18, s0, v1                                  // 000000583BD0: 22240200
	v_lshlrev_b32_e32 v12, 4, v17                              // 000000583BD4: 30182284
	s_delay_alu instid0(VALU_DEP_2)                            // 000000583BD8: BF870002
	v_cmp_lt_i32_e32 vcc_lo, v17, v18                          // 000000583BDC: 7C822511
	s_and_saveexec_b32 s1, vcc_lo                              // 000000583BE0: BE81206A
	s_cbranch_execz 19                                         // 000000583BE4: BFA50013 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi3ELi32ELi8ELb0EEEvPKhPKtPvll+0x134>
	v_lshlrev_b32_e32 v1, 4, v17                               // 000000583BE8: 30022284
	v_and_b32_e32 v3, -2, v17                                  // 000000583BEC: 360622C2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000583BF0: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000583BF4: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000583BF8: 3408069F
	.long 0xd7000001                                           // 000000583BFC: D7000001
	v_cndmask_b32_e32 v1, v10, v1, vcc_lo                      // 000000583C00: 0202030A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000583C04: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v11, v2, s0                  // 000000583C08: D5207C02 0002050B
	.long 0xd7000003                                           // 000000583C10: D7000003
	v_cndmask_b32_e32 v1, v19, v3, vcc_lo                      // 000000583C14: 02020713
	v_add_co_ci_u32_e64 v4, null, v20, v4, s0                  // 000000583C18: D5207C04 00020914
	s_clause 0x1                                               // 000000583C20: BF850001
	global_load_b128 v[5:8], v[1:2], off                       // 000000583C24: DC5E0000 057C0001
	global_load_d16_b16 v24, v[3:4], off                       // 000000583C2C: DC820000 187C0003
	s_or_b32 exec_lo, exec_lo, s1                              // 000000583C34: 8C7E017E
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v21, 0             // 000000583C38: CA100080 16140080
	s_and_saveexec_b32 s1, vcc_lo                              // 000000583C40: BE81206A
	s_cbranch_execz 344                                        // 000000583C44: BFA50158 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi3ELi32ELi8ELb0EEEvPKhPKtPvll+0x6a8>
	v_dual_mov_b32 v22, 0 :: v_dual_add_nc_u32 v23, 0x200, v12 // 000000583C48: CA200080 161618FF 00000200
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v16, 0             // 000000583C54: CA100080 15100080
	s_lshl_b64 s[4:5], s[10:11], 2                             // 000000583C5C: 8484820A
	s_mov_b32 s14, 0                                           // 000000583C60: BE8E0080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 000000583C64: 848A810A
	s_branch 302                                               // 000000583C68: BFA0012E <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi3ELi32ELi8ELb0EEEvPKhPKtPvll+0x624>
	s_or_b32 exec_lo, exec_lo, s15                             // 000000583C6C: 8C7E0F7E
	v_ashrrev_i32_e32 v13, 31, v12                             // 000000583C70: 341A189F
	v_bfe_i32 v49, v5, 8, 8                                    // 000000583C74: D6110031 02211105
	v_bfe_i32 v50, v5, 16, 8                                   // 000000583C7C: D6110032 02212105
	.long 0x7f303880                                           // 000000583C84: 7F303880
	v_bfe_i32 v51, v6, 0, 8                                    // 000000583C88: D6110033 02210106
	.long 0xd73c0019                                           // 000000583C90: D73C0019
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 000000583C94: 02021881
	v_bfe_i32 v13, v5, 0, 8                                    // 000000583C98: D611000D 02210105
	v_ashrrev_i32_e32 v5, 24, v5                               // 000000583CA0: 340A0A98
	v_cvt_f32_i32_e32 v49, v49                                 // 000000583CA4: 7E620B31
	v_cvt_f32_i32_e32 v50, v50                                 // 000000583CA8: 7E640B32
	v_bfe_i32 v52, v6, 8, 8                                    // 000000583CAC: D6110034 02211106
	.long 0xd7000025                                           // 000000583CB4: D7000025
	v_cndmask_b32_e32 v1, s6, v25, vcc_lo                      // 000000583CB8: 02023206
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000583CBC: BF8701A1
	v_add_co_ci_u32_e64 v38, null, s7, v26, s0                 // 000000583CC0: D5207C26 00023407
	v_cvt_f32_i32_e32 v13, v13                                 // 000000583CC8: 7E1A0B0D
	.long 0xd7000029                                           // 000000583CCC: D7000029
	v_cndmask_b32_e32 v0, v37, v10, vcc_lo                     // 000000583CD0: 02001525
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000583CD4: BF8700A1
	v_add_co_ci_u32_e64 v42, null, s11, v38, s0                // 000000583CD8: D5207C2A 00024C0B
	.long 0xd700002d                                           // 000000583CE0: D700002D
	v_cndmask_b32_e32 v0, v37, v4, vcc_lo                      // 000000583CE4: 02000925
	v_add_co_ci_u32_e64 v46, null, s5, v38, s0                 // 000000583CE8: D5207C2E 00024C05
	s_clause 0x5                                               // 000000583CF0: BF850005
	global_load_b128 v[25:28], v[37:38], off                   // 000000583CF4: DC5E0000 197C0025
	global_load_b128 v[29:32], v[41:42], off                   // 000000583CFC: DC5E0000 1D7C0029
	global_load_b128 v[33:36], v[45:46], off                   // 000000583D04: DC5E0000 217C002D
	global_load_b128 v[37:40], v[37:38], off offset:16         // 000000583D0C: DC5E0010 257C0025
	global_load_b128 v[41:44], v[41:42], off offset:16         // 000000583D14: DC5E0010 297C0029
	global_load_b128 v[45:48], v[45:46], off offset:16         // 000000583D1C: DC5E0010 2D7C002D
	v_fma_mix_f32 v13, v24, v13, neg(0) op_sel_hi:[1,0,0]      // 000000583D24: CC20000D 8A021B18
	v_bfe_i32 v53, v6, 16, 8                                   // 000000583D2C: D6110035 02212106
	v_ashrrev_i32_e32 v6, 24, v6                               // 000000583D34: 340C0C98
	v_bfe_i32 v54, v7, 0, 8                                    // 000000583D38: D6110036 02210107
	v_bfe_i32 v55, v7, 8, 8                                    // 000000583D40: D6110037 02211107
	v_bfe_i32 v56, v7, 16, 8                                   // 000000583D48: D6110038 02212107
	v_ashrrev_i32_e32 v7, 24, v7                               // 000000583D50: 340E0E98
	v_bfe_i32 v57, v8, 0, 8                                    // 000000583D54: D6110039 02210108
	v_bfe_i32 v58, v8, 8, 8                                    // 000000583D5C: D611003A 02211108
	v_bfe_i32 v59, v8, 16, 8                                   // 000000583D64: D611003B 02212108
	v_ashrrev_i32_e32 v8, 24, v8                               // 000000583D6C: 34101098
	v_cvt_f32_i32_e32 v5, v5                                   // 000000583D70: 7E0A0B05
	v_cvt_f32_i32_e32 v51, v51                                 // 000000583D74: 7E660B33
	v_fma_mix_f32 v49, v24, v49, neg(0) op_sel_hi:[1,0,0]      // 000000583D78: CC200031 8A026318
	v_fma_mix_f32 v50, v24, v50, neg(0) op_sel_hi:[1,0,0]      // 000000583D80: CC200032 8A026518
	v_bfe_u32 v64, v13, 16, 1                                  // 000000583D88: D6100040 0205210D
	v_cvt_f32_i32_e32 v52, v52                                 // 000000583D90: 7E680B34
	v_cvt_f32_i32_e32 v53, v53                                 // 000000583D94: 7E6A0B35
	v_cvt_f32_i32_e32 v6, v6                                   // 000000583D98: 7E0C0B06
	v_cvt_f32_i32_e32 v54, v54                                 // 000000583D9C: 7E6C0B36
	v_cvt_f32_i32_e32 v55, v55                                 // 000000583DA0: 7E6E0B37
	v_cvt_f32_i32_e32 v56, v56                                 // 000000583DA4: 7E700B38
	v_cvt_f32_i32_e32 v7, v7                                   // 000000583DA8: 7E0E0B07
	v_cvt_f32_i32_e32 v57, v57                                 // 000000583DAC: 7E720B39
	v_cvt_f32_i32_e32 v58, v58                                 // 000000583DB0: 7E740B3A
	v_cvt_f32_i32_e32 v59, v59                                 // 000000583DB4: 7E760B3B
	v_cvt_f32_i32_e32 v8, v8                                   // 000000583DB8: 7E100B08
	v_fma_mix_f32 v5, v24, v5, neg(0) op_sel_hi:[1,0,0]        // 000000583DBC: CC200005 8A020B18
	v_fma_mix_f32 v51, v24, v51, neg(0) op_sel_hi:[1,0,0]      // 000000583DC4: CC200033 8A026718
	v_bfe_u32 v65, v49, 16, 1                                  // 000000583DCC: D6100041 02052131
	v_bfe_u32 v66, v50, 16, 1                                  // 000000583DD4: D6100042 02052132
	v_add3_u32 v13, v13, v64, 0x7fff                           // 000000583DDC: D655000D 03FE810D 00007FFF
	v_fma_mix_f32 v52, v24, v52, neg(0) op_sel_hi:[1,0,0]      // 000000583DE8: CC200034 8A026918
	v_fma_mix_f32 v53, v24, v53, neg(0) op_sel_hi:[1,0,0]      // 000000583DF0: CC200035 8A026B18
	v_fma_mix_f32 v6, v24, v6, neg(0) op_sel_hi:[1,0,0]        // 000000583DF8: CC200006 8A020D18
	v_fma_mix_f32 v54, v24, v54, neg(0) op_sel_hi:[1,0,0]      // 000000583E00: CC200036 8A026D18
	v_fma_mix_f32 v55, v24, v55, neg(0) op_sel_hi:[1,0,0]      // 000000583E08: CC200037 8A026F18
	v_fma_mix_f32 v56, v24, v56, neg(0) op_sel_hi:[1,0,0]      // 000000583E10: CC200038 8A027118
	v_fma_mix_f32 v7, v24, v7, neg(0) op_sel_hi:[1,0,0]        // 000000583E18: CC200007 8A020F18
	v_fma_mix_f32 v57, v24, v57, neg(0) op_sel_hi:[1,0,0]      // 000000583E20: CC200039 8A027318
	v_fma_mix_f32 v58, v24, v58, neg(0) op_sel_hi:[1,0,0]      // 000000583E28: CC20003A 8A027518
	v_fma_mix_f32 v59, v24, v59, neg(0) op_sel_hi:[1,0,0]      // 000000583E30: CC20003B 8A027718
	v_fma_mix_f32 v8, v24, v8, neg(0) op_sel_hi:[1,0,0]        // 000000583E38: CC200008 8A021118
	v_bfe_u32 v67, v5, 16, 1                                   // 000000583E40: D6100043 02052105
	v_bfe_u32 v68, v51, 16, 1                                  // 000000583E48: D6100044 02052133
	v_add3_u32 v49, v49, v65, 0x7fff                           // 000000583E50: D6550031 03FE8331 00007FFF
	v_add3_u32 v50, v50, v66, 0x7fff                           // 000000583E5C: D6550032 03FE8532 00007FFF
	.long 0x7e30398d                                           // 000000583E68: 7E30398D
	.long 0x7f783998                                           // 000000583E6C: 7F783998
	v_bfe_u32 v69, v52, 16, 1                                  // 000000583E70: D6100045 02052134
	v_bfe_u32 v70, v53, 16, 1                                  // 000000583E78: D6100046 02052135
	v_bfe_u32 v77, v58, 16, 1                                  // 000000583E80: D610004D 0205213A
	v_bfe_u32 v79, v8, 16, 1                                   // 000000583E88: D610004F 02052108
	v_add3_u32 v5, v5, v67, 0x7fff                             // 000000583E90: D6550005 03FE8705 00007FFF
	v_add3_u32 v51, v51, v68, 0x7fff                           // 000000583E9C: D6550033 03FE8933 00007FFF
	.long 0x7e7839b2                                           // 000000583EA8: 7E7839B2
	v_and_or_b32 v49, 0xffff0000, v49, v24                     // 000000583EAC: D6570031 046262FF FFFF0000
	v_bfe_u32 v71, v6, 16, 1                                   // 000000583EB8: D6100047 02052106
	v_bfe_u32 v72, v54, 16, 1                                  // 000000583EC0: D6100048 02052136
	v_add3_u32 v52, v52, v69, 0x7fff                           // 000000583EC8: D6550034 03FE8B34 00007FFF
	v_add3_u32 v53, v53, v70, 0x7fff                           // 000000583ED4: D6550035 03FE8D35 00007FFF
	v_add3_u32 v50, v58, v77, 0x7fff                           // 000000583EE0: D6550032 03FE9B3A 00007FFF
	v_add3_u32 v58, v8, v79, 0x7fff                            // 000000583EEC: D655003A 03FE9F08 00007FFF
	v_and_or_b32 v5, 0xffff0000, v5, v60                       // 000000583EF8: D6570005 04F20AFF FFFF0000
	.long 0x7e3039b3                                           // 000000583F04: 7E3039B3
	.long 0x7f7a3998                                           // 000000583F08: 7F7A3998
	v_bfe_u32 v73, v55, 16, 1                                  // 000000583F0C: D6100049 02052137
	v_bfe_u32 v74, v56, 16, 1                                  // 000000583F14: D610004A 02052138
	v_add3_u32 v6, v6, v71, 0x7fff                             // 000000583F1C: D6550006 03FE8F06 00007FFF
	v_add3_u32 v54, v54, v72, 0x7fff                           // 000000583F28: D6550036 03FE9136 00007FFF
	.long 0x7e7a39b5                                           // 000000583F34: 7E7A39B5
	v_bfe_u32 v75, v7, 16, 1                                   // 000000583F38: D610004B 02052107
	v_bfe_u32 v76, v57, 16, 1                                  // 000000583F40: D610004C 02052139
	v_add3_u32 v55, v55, v73, 0x7fff                           // 000000583F48: D6550037 03FE9337 00007FFF
	v_add3_u32 v56, v56, v74, 0x7fff                           // 000000583F54: D6550038 03FE9538 00007FFF
	v_and_or_b32 v6, 0xffff0000, v6, v61                       // 000000583F60: D6570006 04F60CFF FFFF0000
	.long 0x7f7c3998                                           // 000000583F6C: 7F7C3998
	v_bfe_u32 v78, v59, 16, 1                                  // 000000583F70: D610004E 0205213B
	v_add3_u32 v7, v7, v75, 0x7fff                             // 000000583F78: D6550007 03FE9707 00007FFF
	v_add3_u32 v13, v57, v76, 0x7fff                           // 000000583F84: D655000D 03FE9939 00007FFF
	.long 0x7e7c39b8                                           // 000000583F90: 7E7C39B8
	.long 0x7f7e3998                                           // 000000583F94: 7F7E3998
	v_add3_u32 v57, v59, v78, 0x7fff                           // 000000583F98: D6550039 03FE9D3B 00007FFF
	v_add_nc_u32_e32 v23, 0x200, v23                           // 000000583FA4: 4A2E2EFF 00000200
	s_and_b32 s0, exec_lo, vcc_lo                              // 000000583FAC: 8B006A7E
	v_add_nc_u32_e32 v12, 0x200, v12                           // 000000583FB0: 4A1818FF 00000200
	s_or_b32 s14, s0, s14                                      // 000000583FB8: 8C0E0E00
	.long 0x7e7e39b9                                           // 000000583FBC: 7E7E39B9
	s_waitcnt vmcnt(5)                                         // 000000583FC0: BF8917F7
	v_dot2_f32_bf16 v8, v25, v49, 0                            // 000000583FC4: CC1A4008 1A026319
	s_waitcnt vmcnt(4)                                         // 000000583FCC: BF8913F7
	v_dot2_f32_bf16 v25, v29, v49, 0                           // 000000583FD0: CC1A4019 1A02631D
	s_waitcnt vmcnt(3)                                         // 000000583FD8: BF890FF7
	v_dot2_f32_bf16 v29, v33, v49, 0                           // 000000583FDC: CC1A401D 1A026321
	v_and_or_b32 v33, 0xffff0000, v52, v24                     // 000000583FE4: D6570021 046268FF FFFF0000
	.long 0x7e3039b6                                           // 000000583FF0: 7E3039B6
	v_dot2_f32_bf16 v8, v26, v5, v8                            // 000000583FF4: CC1A4008 1C220B1A
	v_dot2_f32_bf16 v25, v30, v5, v25                          // 000000583FFC: CC1A4019 1C660B1E
	v_dot2_f32_bf16 v5, v34, v5, v29                           // 000000584004: CC1A4005 1C760B22
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000058400C: BF870214
	v_and_or_b32 v26, 0xffff0000, v55, v24                     // 000000584010: D657001A 04626EFF FFFF0000
	v_dot2_f32_bf16 v8, v27, v33, v8                           // 00000058401C: CC1A4008 1C22431B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000584024: BF870214
	v_dot2_f32_bf16 v25, v31, v33, v25                         // 000000584028: CC1A4019 1C66431F
	v_dot2_f32_bf16 v5, v35, v33, v5                           // 000000584030: CC1A4005 1C164323
	.long 0x7e30398d                                           // 000000584038: 7E30398D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000058403C: BF870214
	v_dot2_f32_bf16 v8, v28, v6, v8                            // 000000584040: CC1A4008 1C220D1C
	v_dot2_f32_bf16 v25, v32, v6, v25                          // 000000584048: CC1A4019 1C660D20
	s_delay_alu instid0(VALU_DEP_4)                            // 000000584050: BF870004
	v_dot2_f32_bf16 v5, v36, v6, v5                            // 000000584054: CC1A4005 1C160D24
	v_and_or_b32 v6, 0xffff0000, v7, v62                       // 00000058405C: D6570006 04FA0EFF FFFF0000
	v_and_or_b32 v13, 0xffff0000, v50, v24                     // 000000584068: D657000D 046264FF FFFF0000
	s_waitcnt vmcnt(2)                                         // 000000584074: BF890BF7
	v_dot2_f32_bf16 v7, v37, v26, v8                           // 000000584078: CC1A4007 1C223525
	s_waitcnt vmcnt(1)                                         // 000000584080: BF8907F7
	v_dot2_f32_bf16 v8, v41, v26, v25                          // 000000584084: CC1A4008 1C663529
	s_waitcnt vmcnt(0)                                         // 00000058408C: BF8903F7
	v_dot2_f32_bf16 v5, v45, v26, v5                           // 000000584090: CC1A4005 1C16352D
	v_dot2_f32_bf16 v7, v38, v6, v7                            // 000000584098: CC1A4007 1C1E0D26
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000005840A0: BF870193
	v_dot2_f32_bf16 v24, v42, v6, v8                           // 0000005840A4: CC1A4018 1C220D2A
	v_dot2_f32_bf16 v5, v46, v6, v5                            // 0000005840AC: CC1A4005 1C160D2E
	v_mov_b32_e32 v8, v4                                       // 0000005840B4: 7E100304
	v_and_or_b32 v4, 0xffff0000, v58, v63                      // 0000005840B8: D6570004 04FE74FF FFFF0000
	v_dot2_f32_bf16 v25, v39, v13, v7                          // 0000005840C4: CC1A4019 1C1E1B27
	v_dot2_f32_bf16 v24, v43, v13, v24                         // 0000005840CC: CC1A4018 1C621B2B
	v_dot2_f32_bf16 v5, v47, v13, v5                           // 0000005840D4: CC1A4005 1C161B2F
	v_dual_mov_b32 v7, v3 :: v_dual_mov_b32 v6, v2             // 0000005840DC: CA100103 07060102
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000005840E4: BF870214
	v_dot2_f32_bf16 v2, v40, v4, v25                           // 0000005840E8: CC1A4002 1C660928
	v_dot2_f32_bf16 v3, v44, v4, v24                           // 0000005840F0: CC1A4003 1C62092C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000005840F8: BF870234
	v_dot2_f32_bf16 v4, v48, v4, v5                            // 0000005840FC: CC1A4004 1C160930
	v_mov_b32_e32 v5, v1                                       // 000000584104: 7E0A0301
	.long 0x7e303909                                           // 000000584108: 7E303909
	v_dual_add_f32 v21, v21, v2 :: v_dual_add_f32 v22, v22, v3 // 00000058410C: C9080515 15160716
	s_delay_alu instid0(VALU_DEP_4)                            // 000000584114: BF870004
	v_add_f32_e32 v16, v16, v4                                 // 000000584118: 06200910
	s_and_not1_b32 exec_lo, exec_lo, s14                       // 00000058411C: 917E0E7E
	s_cbranch_execz 32                                         // 000000584120: BFA50020 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi3ELi32ELi8ELb0EEEvPKhPKtPvll+0x6a4>
	s_waitcnt vmcnt(1)                                         // 000000584124: BF8907F7
	v_dual_mov_b32 v2, v6 :: v_dual_add_nc_u32 v17, 32, v17    // 000000584128: CA200106 021022A0
	s_waitcnt vmcnt(0)                                         // 000000584130: BF8903F7
	.long 0x7e123918                                           // 000000584134: 7E123918
	v_dual_mov_b32 v1, v5 :: v_dual_mov_b32 v4, v8             // 000000584138: CA100105 01040108
	v_mov_b32_e32 v3, v7                                       // 000000584140: 7E060307
	s_mov_b32 s15, exec_lo                                     // 000000584144: BE8F007E
	v_cmp_ge_i32_e32 vcc_lo, v17, v18                          // 000000584148: 7C8C2511
	.long 0xd4c1007e                                           // 00000058414C: D4C1007E
	v_cndmask_b32_e32 v1, v17, v18, vcc_lo                     // 000000584150: 02022511
	s_cbranch_execz 65221                                      // 000000584154: BFA5FEC5 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi3ELi32ELi8ELb0EEEvPKhPKtPvll+0x16c>
	v_and_b32_e32 v3, -2, v17                                  // 000000584158: 360622C2
	v_ashrrev_i32_e32 v2, 31, v23                              // 00000058415C: 34042E9F
	.long 0xd7000001                                           // 000000584160: D7000001
	v_cndmask_b32_e32 v1, v10, v23, vcc_lo                     // 000000584164: 02022F0A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000584168: BF870193
	v_ashrrev_i32_e32 v4, 31, v3                               // 00000058416C: 3408069F
	v_add_co_ci_u32_e64 v2, null, v11, v2, s0                  // 000000584170: D5207C02 0002050B
	.long 0xd7000019                                           // 000000584178: D7000019
	v_cndmask_b32_e32 v1, v19, v3, vcc_lo                      // 00000058417C: 02020713
	s_delay_alu instid0(VALU_DEP_1)                            // 000000584180: BF870001
	v_add_co_ci_u32_e64 v26, null, v20, v4, s0                 // 000000584184: D5207C1A 00020914
	s_clause 0x1                                               // 00000058418C: BF850001
	global_load_b128 v[1:4], v[1:2], off                       // 000000584190: DC5E0000 017C0001
	global_load_d16_b16 v9, v[25:26], off                      // 000000584198: DC820000 097C0019
	s_branch 65202                                             // 0000005841A0: BFA0FEB2 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi3ELi32ELi8ELb0EEEvPKhPKtPvll+0x16c>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000005841A4: 8C7E0E7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000005841A8: BF8700B9
	s_or_b32 exec_lo, exec_lo, s1                              // 0000005841AC: 8C7E017E
	.long 0xd71f0001                                           // 0000005841B0: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000005841B4: 020100C1
	s_mov_b32 s0, exec_lo                                      // 0000005841B8: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 0000005841BC: 3A040290
	s_waitcnt vmcnt(1)                                         // 0000005841C0: BF8907F7
	v_xor_b32_e32 v5, 8, v1                                    // 0000005841C4: 3A0A0288
	v_xor_b32_e32 v8, 4, v1                                    // 0000005841C8: 3A100284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000005841CC: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000005841D0: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 0000005841D4: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v5                            // 0000005841D8: 7C980AA0
	v_cndmask_b32_e32 v5, v1, v5, vcc_lo                       // 0000005841DC: 020A0B01
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 0000005841E0: 7C9810A0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000005841E4: BF870002
	v_lshlrev_b32_e32 v5, 2, v5                                // 0000005841E8: 300A0A82
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000005841EC: 30040482
	ds_bpermute_b32 v3, v2, v21                                // 0000005841F0: DACC0000 03001502
	s_waitcnt lgkmcnt(0)                                       // 0000005841F8: BF89FC07
	v_add_f32_e32 v3, v21, v3                                  // 0000005841FC: 06060715
	ds_bpermute_b32 v4, v2, v22                                // 000000584200: DACC0000 04001602
	ds_bpermute_b32 v2, v2, v16                                // 000000584208: DACC0000 02001002
	ds_bpermute_b32 v6, v5, v3                                 // 000000584210: DACC0000 06000305
	v_cndmask_b32_e32 v8, v1, v8, vcc_lo                       // 000000584218: 02101101
	s_waitcnt lgkmcnt(0)                                       // 00000058421C: BF89FC07
	v_dual_add_f32 v4, v22, v4 :: v_dual_add_f32 v3, v3, v6    // 000000584220: C9080916 04020D03
	ds_bpermute_b32 v7, v5, v4                                 // 000000584228: DACC0000 07000405
	v_add_f32_e32 v2, v16, v2                                  // 000000584230: 06040510
	v_lshlrev_b32_e32 v8, 2, v8                                // 000000584234: 30101082
	ds_bpermute_b32 v5, v5, v2                                 // 000000584238: DACC0000 05000205
	s_waitcnt lgkmcnt(1)                                       // 000000584240: BF89FC17
	v_add_f32_e32 v4, v4, v7                                   // 000000584244: 06080F04
	ds_bpermute_b32 v6, v8, v4                                 // 000000584248: DACC0000 06000408
	s_waitcnt lgkmcnt(0)                                       // 000000584250: BF89FC07
	v_add_f32_e32 v4, v4, v6                                   // 000000584254: 06080D04
	v_add_f32_e32 v2, v2, v5                                   // 000000584258: 06040B02
	ds_bpermute_b32 v5, v8, v3                                 // 00000058425C: DACC0000 05000308
	ds_bpermute_b32 v7, v8, v2                                 // 000000584264: DACC0000 07000208
	v_xor_b32_e32 v8, 2, v1                                    // 00000058426C: 3A100282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000584270: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 000000584274: 7C9810A0
	v_cndmask_b32_e32 v8, v1, v8, vcc_lo                       // 000000584278: 02101101
	s_waitcnt lgkmcnt(1)                                       // 00000058427C: BF89FC17
	v_dual_add_f32 v3, v3, v5 :: v_dual_lshlrev_b32 v8, 2, v8  // 000000584280: C9220B03 03081082
	s_waitcnt lgkmcnt(0)                                       // 000000584288: BF89FC07
	v_add_f32_e32 v2, v2, v7                                   // 00000058428C: 06040F02
	ds_bpermute_b32 v6, v8, v4                                 // 000000584290: DACC0000 06000408
	ds_bpermute_b32 v5, v8, v3                                 // 000000584298: DACC0000 05000308
	ds_bpermute_b32 v7, v8, v2                                 // 0000005842A0: DACC0000 07000208
	v_xor_b32_e32 v8, 1, v1                                    // 0000005842A8: 3A100281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005842AC: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 0000005842B0: 7C9810A0
	v_cndmask_b32_e32 v1, v1, v8, vcc_lo                       // 0000005842B4: 02021101
	v_lshlrev_b32_e32 v8, 2, v1                                // 0000005842B8: 30100282
	s_waitcnt lgkmcnt(1)                                       // 0000005842BC: BF89FC17
	v_add_f32_e32 v1, v3, v5                                   // 0000005842C0: 06020B03
	s_waitcnt lgkmcnt(0)                                       // 0000005842C4: BF89FC07
	v_dual_add_f32 v3, v4, v6 :: v_dual_add_f32 v2, v2, v7     // 0000005842C8: C9080D04 03020F02
	ds_bpermute_b32 v4, v8, v1                                 // 0000005842D0: DACC0000 04000108
	ds_bpermute_b32 v6, v8, v3                                 // 0000005842D8: DACC0000 06000308
	ds_bpermute_b32 v5, v8, v2                                 // 0000005842E0: DACC0000 05000208
	v_cmpx_eq_u32_e32 0, v15                                   // 0000005842E8: 7D941E80
	s_cbranch_execz 9                                          // 0000005842EC: BFA50009 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi3ELi32ELi8ELb0EEEvPKhPKtPvll+0x814>
	s_waitcnt lgkmcnt(0)                                       // 0000005842F0: BF89FC07
	v_dual_add_f32 v3, v3, v6 :: v_dual_add_f32 v2, v2, v5     // 0000005842F4: C9080D03 03020B02
	v_add_f32_e32 v1, v1, v4                                   // 0000005842FC: 06020901
	v_mul_u32_u24_e32 v4, 12, v14                              // 000000584300: 16081C8C
	ds_store_2addr_b32 v4, v1, v3 offset1:1                    // 000000584304: D8380100 00030104
	ds_store_b32 v4, v2 offset:8                               // 00000058430C: D8340008 00000204
	s_or_b32 exec_lo, exec_lo, s0                              // 000000584314: 8C7E007E
	.long 0xd4510000                                           // 000000584318: D4510000
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 00000058431C: 02001802
	v_cmp_gt_u32_e32 vcc_lo, 3, v0                             // 000000584320: 7C980083
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000584324: BF890007
	s_barrier                                                  // 000000584328: BFBD0000
	buffer_gl0_inv                                             // 00000058432C: E0AC0000 00000000
	s_and_b32 s0, vcc_lo, s0                                   // 000000584334: 8B00006A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000584338: BF870009
	s_and_saveexec_b32 s1, s0                                  // 00000058433C: BE812000
	s_cbranch_execz 50                                         // 000000584340: BFA50032 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi3ELi32ELi8ELb0EEEvPKhPKtPvll+0x90c>
	v_lshlrev_b32_e32 v7, 2, v0                                // 000000584344: 300E0082
	s_lshl_b64 s[0:1], s[2:3], 1                               // 000000584348: 84808102
	ds_load_2addr_b32 v[1:2], v7 offset1:3                     // 00000058434C: D8DC0300 01000007
	ds_load_2addr_b32 v[3:4], v7 offset0:6 offset1:9           // 000000584354: D8DC0906 03000007
	ds_load_2addr_b32 v[5:6], v7 offset0:12 offset1:15         // 00000058435C: D8DC0F0C 05000007
	s_waitcnt lgkmcnt(2)                                       // 000000584364: BF89FC27
	v_add_f32_e32 v1, 0, v1                                    // 000000584368: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000058436C: BF8700A1
	v_add_f32_e32 v1, v1, v2                                   // 000000584370: 06020501
	s_waitcnt lgkmcnt(1)                                       // 000000584374: BF89FC17
	v_add_f32_e32 v1, v1, v3                                   // 000000584378: 06020701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000058437C: BF870131
	v_add_f32_e32 v3, v1, v4                                   // 000000584380: 06060901
	v_mad_u64_u32 v[1:2], null, s12, v0, 0                     // 000000584384: D6FE7C01 0202000C
	s_waitcnt lgkmcnt(0)                                       // 00000058438C: BF89FC07
	v_add_f32_e32 v3, v3, v5                                   // 000000584390: 06060B03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000584394: BF8700D1
	v_add_f32_e32 v4, v3, v6                                   // 000000584398: 06080D03
	ds_load_2addr_b32 v[7:8], v7 offset0:18 offset1:21         // 00000058439C: D8DC1512 07000007
	v_mad_u64_u32 v[2:3], null, s13, v0, v[2:3]                // 0000005843A4: D6FE7C02 040A000D
	s_waitcnt lgkmcnt(0)                                       // 0000005843AC: BF89FC07
	v_add_f32_e32 v0, v4, v7                                   // 0000005843B0: 06000F04
	v_add_f32_e32 v3, v0, v8                                   // 0000005843B4: 06061100
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000005843B8: BF870113
	.long 0xd73c0000                                           // 0000005843BC: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000005843C0: 02020281
	v_bfe_u32 v2, v3, 16, 1                                    // 0000005843C4: D6100002 02052103
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005843CC: BF870092
	.long 0xd7006a00                                           // 0000005843D0: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 0000005843D4: 02020008
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 0000005843D8: D5207C01 01AA0209
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000005843E0: BF870193
	v_add3_u32 v2, v3, v2, 0x7fff                              // 0000005843E4: D6550002 03FE0503 00007FFF
	.long 0xd7006a00                                           // 0000005843F0: D7006A00
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 0000005843F4: 02000100
	s_delay_alu instid0(VALU_DEP_1)                            // 0000005843F8: BF870001
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 0000005843FC: D5207C01 01AA0201
	global_store_d16_hi_b16 v[0:1], v2, off                    // 000000584404: DC960000 007C0200
	s_endpgm                                                   // 00000058440C: BFB00000
		...

