00000000002e6c00 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi4ELi32ELi1EEEvPKhPKtPtll>:
; _ZN7halogen12_GLOBAL__N_16k_lq8wILi4ELi32ELi1EEEvPKhPKtPtll():
	s_clause 0x1                                               // 0000002E6C00: BF850001
	s_load_b64 s[12:13], s[0:1], 0x20                          // 0000002E6C04: F4040300 F8000020
	s_load_b256 s[4:11], s[0:1], null                          // 0000002E6C0C: F40C0100 F8000000
	v_lshrrev_b32_e32 v1, 5, v0                                // 0000002E6C14: 32020085
	s_mov_b32 s3, 0                                            // 0000002E6C18: BE830080
	v_dual_mov_b32 v16, 0 :: v_dual_and_b32 v15, 31, v0        // 0000002E6C1C: CA240080 100E009F
	s_lshl_b64 s[0:1], s[2:3], 3                               // 0000002E6C24: 84808302
	v_mov_b32_e32 v22, 0                                       // 0000002E6C28: 7E2C0280
	v_or_b32_e32 v9, s0, v1                                    // 0000002E6C2C: 38120200
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000002E6C30: BF870133
	v_dual_mov_b32 v10, s1 :: v_dual_lshlrev_b32 v11, 4, v15   // 0000002E6C34: CA220001 0A0A1E84
	v_mov_b32_e32 v3, 0                                        // 0000002E6C3C: 7E060280
	s_waitcnt lgkmcnt(0)                                       // 0000002E6C40: BF89FC07
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[9:10]                 // 0000002E6C44: 7CA8120C
	s_ashr_i32 s0, s11, 31                                     // 0000002E6C48: 86009F0B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000002E6C4C: BF870499
	s_lshr_b32 s0, s0, 28                                      // 0000002E6C50: 85009C00
	s_add_u32 s2, s10, s0                                      // 0000002E6C54: 8002000A
	s_addc_u32 s3, s11, 0                                      // 0000002E6C58: 8203800B
	v_cndmask_b32_e32 v1, 0, v9, vcc_lo                        // 0000002E6C5C: 02021280
	v_cndmask_b32_e64 v2, 0, s1, vcc_lo                        // 0000002E6C60: D5010002 01A80280
	s_ashr_i64 s[2:3], s[2:3], 4                               // 0000002E6C68: 86828402
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002E6C6C: BF8700A9
	s_add_u32 s0, s2, s10                                      // 0000002E6C70: 80000A02
	s_addc_u32 s1, s3, s11                                     // 0000002E6C74: 82010B03
	.long 0xd72c0004                                           // 0000002E6C78: D72C0004
	v_cndmask_b32_e32 v0, v2, v0, vcc_lo                       // 0000002E6C7C: 02000102
	v_mad_u64_u32 v[5:6], null, v1, s0, 0                      // 0000002E6C80: D6FE7C05 02000101
	.long 0xd72c0007                                           // 0000002E6C88: D72C0007
	v_cndmask_b32_e32 v0, v1, v1, vcc_lo                       // 0000002E6C8C: 02000301
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v2, 0               // 0000002E6C90: CA100080 01020080
	.long 0xd4440000                                           // 0000002E6C98: D4440000
	v_cndmask_b32_e32 v1, s2, v15, vcc_lo                      // 0000002E6C9C: 02021E02
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002E6CA0: BF870214
	.long 0xd7000111                                           // 0000002E6CA4: D7000111
	v_cndmask_b32_e32 v1, s4, v5, vcc_lo                       // 0000002E6CA8: 02020A04
	v_add3_u32 v6, v6, v7, v4                                  // 0000002E6CAC: D6550006 04120F06
	v_mov_b32_e32 v4, 0                                        // 0000002E6CB4: 7E080280
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002E6CB8: BF870002
	v_add_co_ci_u32_e64 v18, null, s5, v6, s1                  // 0000002E6CBC: D5207C12 00060C05
	s_and_saveexec_b32 s3, s0                                  // 0000002E6CC4: BE832000
	s_cbranch_execz 21                                         // 0000002E6CC8: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi4ELi32ELi1EEEvPKhPKtPtll+0x120>
	v_lshlrev_b32_e32 v1, 4, v15                               // 0000002E6CCC: 30021E84
	.long 0xd7000103                                           // 0000002E6CD0: D7000103
	v_cndmask_b32_e32 v0, v17, v10, vcc_lo                     // 0000002E6CD4: 02001511
	v_and_b32_e32 v7, 28, v0                                   // 0000002E6CD8: 360E009C
	v_add_co_ci_u32_e64 v4, null, s11, v18, s1                 // 0000002E6CDC: D5207C04 0006240B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E6CE4: BF870094
	.long 0xd7000101                                           // 0000002E6CE8: D7000101
	v_cndmask_b32_e32 v1, v17, v1, vcc_lo                      // 0000002E6CEC: 02020311
	v_add_co_ci_u32_e64 v2, null, 0, v18, s1                   // 0000002E6CF0: D5207C02 00062480
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E6CF8: BF870094
	.long 0xd7000107                                           // 0000002E6CFC: D7000107
	v_cndmask_b32_e32 v1, v3, v7, vcc_lo                       // 0000002E6D00: 02020F03
	v_add_co_ci_u32_e64 v8, null, 0, v4, s1                    // 0000002E6D04: D5207C08 00060880
	s_clause 0x1                                               // 0000002E6D0C: BF850001
	global_load_b128 v[1:4], v[1:2], off                       // 0000002E6D10: DC5E0000 017C0001
	global_load_b32 v22, v[7:8], off                           // 0000002E6D18: DC520000 167C0007
	s_or_b32 exec_lo, exec_lo, s3                              // 0000002E6D20: 8C7E037E
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v20, 0             // 0000002E6D24: CA100080 13140080
	v_mov_b32_e32 v21, 0                                       // 0000002E6D2C: 7E2A0280
	s_and_saveexec_b32 s3, s0                                  // 0000002E6D30: BE832000
	s_cbranch_execz 358                                        // 0000002E6D34: BFA50166 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi4ELi32ELi1EEEvPKhPKtPtll+0x6d0>
	v_and_or_b32 v0, v0, 28, 32                                // 0000002E6D38: D6570000 02813900
	.long 0xd7000005                                           // 0000002E6D40: D7000005
	v_cndmask_b32_e32 v1, s10, v5, vcc_lo                      // 0000002E6D44: 02020A0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002E6D48: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s11, v6, s0                  // 0000002E6D4C: D5207C06 00020C0B
	v_mov_b32_e32 v12, 0                                       // 0000002E6D54: 7E180280
	.long 0xd7000000                                           // 0000002E6D58: D7000000
	v_cndmask_b32_e32 v1, v5, v0, vcc_lo                       // 0000002E6D5C: 02020105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002E6D60: BF870191
	v_add_co_ci_u32_e64 v5, null, 0, v6, s0                    // 0000002E6D64: D5207C05 00020C80
	v_mov_b32_e32 v21, v12                                     // 0000002E6D6C: 7E2A030C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E6D70: BF870093
	.long 0xd700000d                                           // 0000002E6D74: D700000D
	v_cndmask_b32_e32 v1, s4, v0, vcc_lo                       // 0000002E6D78: 02020004
	v_add_co_ci_u32_e64 v14, null, s5, v5, s0                  // 0000002E6D7C: D5207C0E 00020A05
	v_mov_b32_e32 v0, v15                                      // 0000002E6D84: 7E00030F
	v_mov_b32_e32 v20, v12                                     // 0000002E6D88: 7E28030C
	v_mov_b32_e32 v19, v12                                     // 0000002E6D8C: 7E26030C
	v_mov_b32_e32 v16, v12                                     // 0000002E6D90: 7E20030C
	s_mul_i32 s1, s11, 6                                       // 0000002E6D94: 9601860B
	s_mul_hi_u32 s16, s10, 6                                   // 0000002E6D98: 9690860A
	s_lshl_b64 s[14:15], s[10:11], 2                           // 0000002E6D9C: 848E820A
	s_add_i32 s16, s16, s1                                     // 0000002E6DA0: 81100110
	s_mul_i32 s18, s10, 6                                      // 0000002E6DA4: 9612860A
	s_mov_b32 s17, 0                                           // 0000002E6DA8: BE910080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 0000002E6DAC: 8484810A
	s_branch 297                                               // 0000002E6DB0: BFA00129 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi4ELi32ELi1EEEvPKhPKtPtll+0x658>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000002E6DB4: 8C7E0A7E
	.long 0xd73c0019                                           // 0000002E6DB8: D73C0019
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 0000002E6DBC: 02021681
	v_cvt_f32_ubyte0_e32 v57, v1                               // 0000002E6DC0: 7E722301
	v_cvt_f32_ubyte1_e32 v59, v1                               // 0000002E6DC4: 7E762501
	v_cvt_f32_ubyte2_e32 v60, v1                               // 0000002E6DC8: 7E782701
	v_cvt_f32_ubyte3_e32 v1, v1                                // 0000002E6DCC: 7E022901
	v_cvt_f32_ubyte0_e32 v61, v2                               // 0000002E6DD0: 7E7A2302
	.long 0xd7000129                                           // 0000002E6DD4: D7000129
	v_cndmask_b32_e32 v1, s6, v25, vcc_lo                      // 0000002E6DD8: 02023206
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002E6DDC: BF8701A1
	v_add_co_ci_u32_e64 v42, null, s7, v26, s1                 // 0000002E6DE0: D5207C2A 00063407
	v_cvt_f32_ubyte1_e32 v62, v2                               // 0000002E6DE8: 7E7C2502
	.long 0xd700012d                                           // 0000002E6DEC: D700012D
	v_cndmask_b32_e32 v0, v41, v4, vcc_lo                      // 0000002E6DF0: 02000929
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002E6DF4: BF8700A1
	v_add_co_ci_u32_e64 v46, null, s5, v42, s1                 // 0000002E6DF8: D5207C2E 00065405
	.long 0xd7000131                                           // 0000002E6E00: D7000131
	v_cndmask_b32_e32 v0, v41, v14, vcc_lo                     // 0000002E6E04: 02001D29
	v_add_co_ci_u32_e64 v50, null, s15, v42, s1                // 0000002E6E08: D5207C32 0006540F
	.long 0xd7000135                                           // 0000002E6E10: D7000135
	v_cndmask_b32_e32 v0, v41, v18, vcc_lo                     // 0000002E6E14: 02002529
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002E6E18: BF870001
	v_add_co_ci_u32_e64 v54, null, s16, v42, s1                // 0000002E6E1C: D5207C36 00065410
	s_clause 0x7                                               // 0000002E6E24: BF850007
	global_load_b128 v[25:28], v[41:42], off                   // 0000002E6E28: DC5E0000 197C0029
	global_load_b128 v[29:32], v[45:46], off                   // 0000002E6E30: DC5E0000 1D7C002D
	global_load_b128 v[33:36], v[49:50], off                   // 0000002E6E38: DC5E0000 217C0031
	global_load_b128 v[37:40], v[53:54], off                   // 0000002E6E40: DC5E0000 257C0035
	global_load_b128 v[41:44], v[41:42], off offset:16         // 0000002E6E48: DC5E0010 297C0029
	global_load_b128 v[45:48], v[45:46], off offset:16         // 0000002E6E50: DC5E0010 2D7C002D
	global_load_b128 v[49:52], v[49:50], off offset:16         // 0000002E6E58: DC5E0010 317C0031
	global_load_b128 v[53:56], v[53:54], off offset:16         // 0000002E6E60: DC5E0010 357C0035
	v_cvt_f32_ubyte2_e32 v63, v2                               // 0000002E6E68: 7E7E2702
	v_cvt_f32_ubyte3_e32 v2, v2                                // 0000002E6E6C: 7E042902
	v_cvt_f32_ubyte0_e32 v64, v3                               // 0000002E6E70: 7E802303
	v_cvt_f32_ubyte1_e32 v65, v3                               // 0000002E6E74: 7E822503
	v_cvt_f32_ubyte2_e32 v66, v3                               // 0000002E6E78: 7E842703
	v_cvt_f32_ubyte3_e32 v67, v3                               // 0000002E6E7C: 7E862903
	v_cvt_f32_ubyte0_e32 v68, v4                               // 0000002E6E80: 7E882304
	v_cvt_f32_ubyte1_e32 v69, v4                               // 0000002E6E84: 7E8A2504
	v_cvt_f32_ubyte2_e32 v70, v4                               // 0000002E6E88: 7E8C2704
	v_cvt_f32_ubyte3_e32 v71, v4                               // 0000002E6E8C: 7E8E2904
	s_waitcnt vmcnt(9)                                         // 0000002E6E90: BF8927F7
	v_dual_mov_b32 v4, v8 :: v_dual_mov_b32 v3, v7             // 0000002E6E94: CA100108 04020107
	v_fma_mix_f32 v7, v57, v22, v22 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E6E9C: CC206007 145A2D39
	v_mov_b32_e32 v11, v24                                     // 0000002E6EA4: 7E160318
	v_fma_mix_f32 v8, v59, v22, v22 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E6EA8: CC206008 145A2D3B
	v_fma_mix_f32 v24, v60, v22, v22 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E6EB0: CC206018 145A2D3C
	v_fma_mix_f32 v1, v1, v22, v22 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E6EB8: CC206001 145A2D01
	v_fma_mix_f32 v59, v61, v22, v22 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E6EC0: CC20603B 145A2D3D
	v_fma_mix_f32 v60, v62, v22, v22 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E6EC8: CC20603C 145A2D3E
	v_fma_mix_f32 v61, v63, v22, v22 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E6ED0: CC20603D 145A2D3F
	v_fma_mix_f32 v2, v2, v22, v22 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E6ED8: CC206002 145A2D02
	v_fma_mix_f32 v63, v64, v22, v22 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E6EE0: CC20603F 145A2D40
	v_fma_mix_f32 v64, v65, v22, v22 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E6EE8: CC206040 145A2D41
	v_fma_mix_f32 v65, v66, v22, v22 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E6EF0: CC206041 145A2D42
	v_fma_mix_f32 v67, v67, v22, v22 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E6EF8: CC206043 145A2D43
	v_fma_mix_f32 v68, v68, v22, v22 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E6F00: CC206044 145A2D44
	v_fma_mix_f32 v69, v69, v22, v22 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E6F08: CC206045 145A2D45
	v_fma_mix_f32 v70, v70, v22, v22 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E6F10: CC206046 145A2D46
	v_fma_mix_f32 v22, v71, v22, v22 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E6F18: CC206016 145A2D47
	v_bfe_u32 v71, v7, 16, 1                                   // 0000002E6F20: D6100047 02052107
	v_bfe_u32 v73, v8, 16, 1                                   // 0000002E6F28: D6100049 02052108
	v_bfe_u32 v74, v24, 16, 1                                  // 0000002E6F30: D610004A 02052118
	.long 0x7f743880                                           // 0000002E6F38: 7F743880
	v_bfe_u32 v75, v1, 16, 1                                   // 0000002E6F3C: D610004B 02052101
	v_add3_u32 v7, v7, v71, 0x7fff                             // 0000002E6F44: D6550007 03FE8F07 00007FFF
	v_bfe_u32 v76, v59, 16, 1                                  // 0000002E6F50: D610004C 0205213B
	v_add3_u32 v8, v8, v73, 0x7fff                             // 0000002E6F58: D6550008 03FE9308 00007FFF
	v_add3_u32 v24, v24, v74, 0x7fff                           // 0000002E6F64: D6550018 03FE9518 00007FFF
	.long 0x7f7239ba                                           // 0000002E6F70: 7F7239BA
	.long 0x7e743987                                           // 0000002E6F74: 7E743987
	v_bfe_u32 v77, v60, 16, 1                                  // 0000002E6F78: D610004D 0205213C
	v_bfe_u32 v78, v61, 16, 1                                  // 0000002E6F80: D610004E 0205213D
	v_add3_u32 v1, v1, v75, 0x7fff                             // 0000002E6F88: D6550001 03FE9701 00007FFF
	v_add3_u32 v59, v59, v76, 0x7fff                           // 0000002E6F94: D655003B 03FE993B 00007FFF
	.long 0x7e723998                                           // 0000002E6FA0: 7E723998
	v_and_or_b32 v7, 0xffff0000, v8, v58                       // 0000002E6FA4: D6570007 04EA10FF FFFF0000
	v_bfe_u32 v79, v2, 16, 1                                   // 0000002E6FB0: D610004F 02052102
	v_bfe_u32 v80, v63, 16, 1                                  // 0000002E6FB8: D6100050 0205213F
	v_add3_u32 v60, v60, v77, 0x7fff                           // 0000002E6FC0: D655003C 03FE9B3C 00007FFF
	v_add3_u32 v61, v61, v78, 0x7fff                           // 0000002E6FCC: D655003D 03FE9D3D 00007FFF
	v_and_or_b32 v1, 0xffff0000, v1, v57                       // 0000002E6FD8: D6570001 04E602FF FFFF0000
	.long 0x7e7439bb                                           // 0000002E6FE4: 7E7439BB
	.long 0x7f7c39ba                                           // 0000002E6FE8: 7F7C39BA
	v_bfe_u32 v81, v64, 16, 1                                  // 0000002E6FEC: D6100051 02052140
	v_bfe_u32 v82, v65, 16, 1                                  // 0000002E6FF4: D6100052 02052141
	v_add3_u32 v2, v2, v79, 0x7fff                             // 0000002E6FFC: D6550002 03FE9F02 00007FFF
	v_add3_u32 v63, v63, v80, 0x7fff                           // 0000002E7008: D655003F 03FEA13F 00007FFF
	.long 0x7e7c39bd                                           // 0000002E7014: 7E7C39BD
	v_bfe_u32 v83, v67, 16, 1                                  // 0000002E7018: D6100053 02052143
	v_bfe_u32 v84, v68, 16, 1                                  // 0000002E7020: D6100054 02052144
	v_add3_u32 v64, v64, v81, 0x7fff                           // 0000002E7028: D6550040 03FEA340 00007FFF
	v_add3_u32 v65, v65, v82, 0x7fff                           // 0000002E7034: D6550041 03FEA541 00007FFF
	v_and_or_b32 v2, 0xffff0000, v2, v62                       // 0000002E7040: D6570002 04FA04FF FFFF0000
	.long 0x7f8439ba                                           // 0000002E704C: 7F8439BA
	v_bfe_u32 v85, v69, 16, 1                                  // 0000002E7050: D6100055 02052145
	v_bfe_u32 v86, v70, 16, 1                                  // 0000002E7058: D6100056 02052146
	v_add3_u32 v67, v67, v83, 0x7fff                           // 0000002E7060: D6550043 03FEA743 00007FFF
	v_add3_u32 v68, v68, v84, 0x7fff                           // 0000002E706C: D6550044 03FEA944 00007FFF
	.long 0x7e8439c1                                           // 0000002E7078: 7E8439C1
	v_bfe_u32 v87, v22, 16, 1                                  // 0000002E707C: D6100057 02052116
	v_add3_u32 v69, v69, v85, 0x7fff                           // 0000002E7084: D6550045 03FEAB45 00007FFF
	v_add3_u32 v70, v70, v86, 0x7fff                           // 0000002E7090: D6550046 03FEAD46 00007FFF
	.long 0x7f9039ba                                           // 0000002E709C: 7F9039BA
	v_and_or_b32 v8, 0xffff0000, v67, v66                      // 0000002E70A0: D6570008 050A86FF FFFF0000
	v_add3_u32 v22, v22, v87, 0x7fff                           // 0000002E70AC: D6550016 03FEAF16 00007FFF
	s_and_b32 s1, exec_lo, s0                                  // 0000002E70B8: 8B01007E
	.long 0x7e9039c6                                           // 0000002E70BC: 7E9039C6
	.long 0xd700000d                                           // 0000002E70C0: D700000D
	v_cndmask_b32_e32 v0, v13, v160, vcc_lo                    // 0000002E70C4: 0201410D
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002E70C8: BF870001
	v_add_co_ci_u32_e64 v14, null, 0, v14, s0                  // 0000002E70CC: D5207C0E 00021C80
	s_or_b32 s17, s1, s17                                      // 0000002E70D4: 8C111101
	s_waitcnt vmcnt(7)                                         // 0000002E70D8: BF891FF7
	v_dot2_f32_bf16 v24, v25, v7, 0                            // 0000002E70DC: CC1A4018 1A020F19
	s_waitcnt vmcnt(6)                                         // 0000002E70E4: BF891BF7
	v_dot2_f32_bf16 v25, v29, v7, 0                            // 0000002E70E8: CC1A4019 1A020F1D
	s_waitcnt vmcnt(5)                                         // 0000002E70F0: BF8917F7
	v_dot2_f32_bf16 v29, v33, v7, 0                            // 0000002E70F4: CC1A401D 1A020F21
	s_waitcnt vmcnt(4)                                         // 0000002E70FC: BF8913F7
	v_dot2_f32_bf16 v7, v37, v7, 0                             // 0000002E7100: CC1A4007 1A020F25
	v_and_or_b32 v33, 0xffff0000, v60, v58                     // 0000002E7108: D6570021 04EA78FF FFFF0000
	v_dot2_f32_bf16 v24, v26, v1, v24                          // 0000002E7114: CC1A4018 1C62031A
	v_dot2_f32_bf16 v25, v30, v1, v25                          // 0000002E711C: CC1A4019 1C66031E
	v_dot2_f32_bf16 v26, v34, v1, v29                          // 0000002E7124: CC1A401A 1C760322
	v_dot2_f32_bf16 v1, v38, v1, v7                            // 0000002E712C: CC1A4001 1C1E0326
	.long 0x7e7439bf                                           // 0000002E7134: 7E7439BF
	v_dot2_f32_bf16 v7, v27, v33, v24                          // 0000002E7138: CC1A4007 1C62431B
	v_dot2_f32_bf16 v24, v31, v33, v25                         // 0000002E7140: CC1A4018 1C66431F
	v_dot2_f32_bf16 v25, v35, v33, v26                         // 0000002E7148: CC1A4019 1C6A4323
	v_dot2_f32_bf16 v1, v39, v33, v1                           // 0000002E7150: CC1A4001 1C064327
	v_and_or_b32 v26, 0xffff0000, v64, v58                     // 0000002E7158: D657001A 04EA80FF FFFF0000
	v_dot2_f32_bf16 v7, v28, v2, v7                            // 0000002E7164: CC1A4007 1C1E051C
	v_dot2_f32_bf16 v24, v32, v2, v24                          // 0000002E716C: CC1A4018 1C620520
	v_dot2_f32_bf16 v25, v36, v2, v25                          // 0000002E7174: CC1A4019 1C660524
	v_dot2_f32_bf16 v1, v40, v2, v1                            // 0000002E717C: CC1A4001 1C060528
	.long 0x7e7439c4                                           // 0000002E7184: 7E7439C4
	s_waitcnt vmcnt(3)                                         // 0000002E7188: BF890FF7
	v_dot2_f32_bf16 v2, v41, v26, v7                           // 0000002E718C: CC1A4002 1C1E3529
	s_waitcnt vmcnt(2)                                         // 0000002E7194: BF890BF7
	v_dot2_f32_bf16 v7, v45, v26, v24                          // 0000002E7198: CC1A4007 1C62352D
	s_waitcnt vmcnt(1)                                         // 0000002E71A0: BF8907F7
	v_dot2_f32_bf16 v24, v49, v26, v25                         // 0000002E71A4: CC1A4018 1C663531
	s_waitcnt vmcnt(0)                                         // 0000002E71AC: BF8903F7
	v_dot2_f32_bf16 v1, v53, v26, v1                           // 0000002E71B0: CC1A4001 1C063535
	v_and_or_b32 v25, 0xffff0000, v69, v58                     // 0000002E71B8: D6570019 04EA8AFF FFFF0000
	v_dot2_f32_bf16 v2, v42, v8, v2                            // 0000002E71C4: CC1A4002 1C0A112A
	v_dot2_f32_bf16 v7, v46, v8, v7                            // 0000002E71CC: CC1A4007 1C1E112E
	v_dot2_f32_bf16 v24, v50, v8, v24                          // 0000002E71D4: CC1A4018 1C621132
	v_dot2_f32_bf16 v1, v54, v8, v1                            // 0000002E71DC: CC1A4001 1C061136
	v_and_or_b32 v8, 0xffff0000, v22, v72                      // 0000002E71E4: D6570008 05222CFF FFFF0000
	v_dot2_f32_bf16 v22, v43, v25, v2                          // 0000002E71F0: CC1A4016 1C0A332B
	v_dot2_f32_bf16 v7, v47, v25, v7                           // 0000002E71F8: CC1A4007 1C1E332F
	v_dot2_f32_bf16 v24, v51, v25, v24                         // 0000002E7200: CC1A4018 1C623333
	v_dot2_f32_bf16 v1, v55, v25, v1                           // 0000002E7208: CC1A4001 1C063337
	v_mov_b32_e32 v2, v6                                       // 0000002E7210: 7E040306
	v_dot2_f32_bf16 v6, v44, v8, v22                           // 0000002E7214: CC1A4006 1C5A112C
	v_dot2_f32_bf16 v7, v48, v8, v7                            // 0000002E721C: CC1A4007 1C1E1130
	v_dot2_f32_bf16 v22, v52, v8, v24                          // 0000002E7224: CC1A4016 1C621134
	v_dot2_f32_bf16 v8, v56, v8, v1                            // 0000002E722C: CC1A4008 1C061138
	v_mov_b32_e32 v1, v5                                       // 0000002E7234: 7E020305
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002E7238: BF870194
	v_dual_add_f32 v21, v21, v6 :: v_dual_add_f32 v20, v20, v7 // 0000002E723C: C9080D15 15140F14
	v_dual_add_f32 v19, v19, v22 :: v_dual_add_f32 v16, v16, v8// 0000002E7244: C9082D13 13101110
	v_mov_b32_e32 v22, v23                                     // 0000002E724C: 7E2C0317
	s_and_not1_b32 exec_lo, exec_lo, s17                       // 0000002E7250: 917E117E
	s_cbranch_execz 29                                         // 0000002E7254: BFA5001D <_ZN7halogen12_GLOBAL__N_16k_lq8wILi4ELi32ELi1EEEvPKhPKtPtll+0x6cc>
	v_add_nc_u32_e32 v0, 32, v0                                // 0000002E7258: 4A0000A0
	v_add_nc_u32_e32 v24, 0x200, v11                           // 0000002E725C: 4A3016FF 00000200
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000002E7264: BF8704A2
	.long 0xd4430000                                           // 0000002E7268: D4430000
	v_cndmask_b32_e32 v1, s2, v0, vcc_lo                       // 0000002E726C: 02020002
	s_and_saveexec_b32 s1, s0                                  // 0000002E7270: BE812000
	s_xor_b32 s1, exec_lo, s1                                  // 0000002E7274: 8D01017E
	v_add_nc_u32_e32 v24, 0x200, v11                           // 0000002E7278: 4A3016FF 00000200
	s_or_saveexec_b32 s10, s1                                  // 0000002E7280: BE8A2201
	s_waitcnt vmcnt(0)                                         // 0000002E7284: BF8903F7
	v_dual_mov_b32 v23, v22 :: v_dual_mov_b32 v8, v4           // 0000002E7288: CA100116 17080104
	v_dual_mov_b32 v5, v1 :: v_dual_mov_b32 v6, v2             // 0000002E7290: CA100101 05060102
	v_mov_b32_e32 v7, v3                                       // 0000002E7298: 7E0E0303
	s_xor_b32 exec_lo, exec_lo, s10                            // 0000002E729C: 8D7E0A7E
	s_cbranch_execz 65220                                      // 0000002E72A0: BFA5FEC4 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi4ELi32ELi1EEEvPKhPKtPtll+0x1b4>
	.long 0xd7000105                                           // 0000002E72A4: D7000105
	v_cndmask_b32_e32 v1, v17, v24, vcc_lo                     // 0000002E72A8: 02023111
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002E72AC: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v18, s1                   // 0000002E72B0: D5207C06 00062480
	global_load_b128 v[5:8], v[5:6], off                       // 0000002E72B8: DC5E0000 057C0005
	global_load_b32 v23, v[13:14], off                         // 0000002E72C0: DC520000 177C000D
	s_branch 65210                                             // 0000002E72C8: BFA0FEBA <_ZN7halogen12_GLOBAL__N_16k_lq8wILi4ELi32ELi1EEEvPKhPKtPtll+0x1b4>
	s_or_b32 exec_lo, exec_lo, s17                             // 0000002E72CC: 8C7E117E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002E72D0: BF8700B9
	s_or_b32 exec_lo, exec_lo, s3                              // 0000002E72D4: 8C7E037E
	.long 0xd71f0000                                           // 0000002E72D8: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000002E72DC: 020100C1
	s_waitcnt vmcnt(1)                                         // 0000002E72E0: BF8907F7
	v_xor_b32_e32 v1, 16, v0                                   // 0000002E72E4: 3A020090
	v_xor_b32_e32 v5, 8, v0                                    // 0000002E72E8: 3A0A0088
	v_xor_b32_e32 v11, 4, v0                                   // 0000002E72EC: 3A160084
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E72F0: BF870093
	.long 0xd44c0000                                           // 0000002E72F4: D44C0000
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 0000002E72F8: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s0                           // 0000002E72FC: D5010001 00020300
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002E7304: BF870114
	.long 0xd44c0000                                           // 0000002E7308: D44C0000
	v_cndmask_b32_e32 v1, 32, v5, vcc_lo                       // 0000002E730C: 02020AA0
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000002E7310: 30020282
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002E7314: BF870002
	v_cndmask_b32_e64 v5, v0, v5, s0                           // 0000002E7318: D5010005 00020B00
	.long 0xd44c0000                                           // 0000002E7320: D44C0000
	v_cndmask_b32_e32 v1, 32, v11, vcc_lo                      // 0000002E7324: 020216A0
	ds_bpermute_b32 v2, v1, v21                                // 0000002E7328: DACC0000 02001501
	v_cndmask_b32_e64 v11, v0, v11, s0                         // 0000002E7330: D501000B 00021700
	s_waitcnt lgkmcnt(0)                                       // 0000002E7338: BF89FC07
	v_add_f32_e32 v2, v21, v2                                  // 0000002E733C: 06040515
	ds_bpermute_b32 v4, v1, v19                                // 0000002E7340: DACC0000 04001301
	ds_bpermute_b32 v3, v1, v20                                // 0000002E7348: DACC0000 03001401
	ds_bpermute_b32 v1, v1, v16                                // 0000002E7350: DACC0000 01001001
	s_waitcnt lgkmcnt(2)                                       // 0000002E7358: BF89FC27
	v_dual_add_f32 v4, v19, v4 :: v_dual_lshlrev_b32 v5, 2, v5 // 0000002E735C: C9220913 04040A82
	ds_bpermute_b32 v6, v5, v2                                 // 0000002E7364: DACC0000 06000205
	s_waitcnt lgkmcnt(2)                                       // 0000002E736C: BF89FC27
	v_add_f32_e32 v3, v20, v3                                  // 0000002E7370: 06060714
	s_waitcnt lgkmcnt(1)                                       // 0000002E7374: BF89FC17
	v_add_f32_e32 v1, v16, v1                                  // 0000002E7378: 06020310
	ds_bpermute_b32 v8, v5, v4                                 // 0000002E737C: DACC0000 08000405
	s_waitcnt lgkmcnt(1)                                       // 0000002E7384: BF89FC17
	v_dual_add_f32 v2, v2, v6 :: v_dual_lshlrev_b32 v11, 2, v11// 0000002E7388: C9220D02 020A1682
	ds_bpermute_b32 v7, v5, v3                                 // 0000002E7390: DACC0000 07000305
	ds_bpermute_b32 v5, v5, v1                                 // 0000002E7398: DACC0000 05000105
	s_waitcnt lgkmcnt(0)                                       // 0000002E73A0: BF89FC07
	v_dual_add_f32 v4, v4, v8 :: v_dual_add_f32 v1, v1, v5     // 0000002E73A4: C9081104 04000B01
	ds_bpermute_b32 v5, v11, v2                                // 0000002E73AC: DACC0000 0500020B
	v_add_f32_e32 v3, v3, v7                                   // 0000002E73B4: 06060F03
	ds_bpermute_b32 v7, v11, v4                                // 0000002E73B8: DACC0000 0700040B
	s_waitcnt lgkmcnt(1)                                       // 0000002E73C0: BF89FC17
	v_add_f32_e32 v2, v2, v5                                   // 0000002E73C4: 06040B02
	ds_bpermute_b32 v6, v11, v3                                // 0000002E73C8: DACC0000 0600030B
	s_waitcnt lgkmcnt(0)                                       // 0000002E73D0: BF89FC07
	v_dual_add_f32 v3, v3, v6 :: v_dual_add_f32 v6, v4, v7     // 0000002E73D4: C9080D03 03060F04
	ds_bpermute_b32 v8, v11, v1                                // 0000002E73DC: DACC0000 0800010B
	v_xor_b32_e32 v11, 2, v0                                   // 0000002E73E4: 3A160082
	v_xor_b32_e32 v4, 1, v0                                    // 0000002E73E8: 3A080081
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E73EC: BF870092
	.long 0xd44c0000                                           // 0000002E73F0: D44C0000
	v_cndmask_b32_e32 v1, 32, v11, vcc_lo                      // 0000002E73F4: 020216A0
	v_cndmask_b32_e64 v11, v0, v11, s0                         // 0000002E73F8: D501000B 00021700
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002E7400: BF870113
	.long 0xd44c0000                                           // 0000002E7404: D44C0000
	v_cndmask_b32_e32 v1, 32, v4, vcc_lo                       // 0000002E7408: 020208A0
	v_lshlrev_b32_e32 v11, 2, v11                              // 0000002E740C: 30161682
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002E7410: BF870002
	v_cndmask_b32_e64 v0, v0, v4, s0                           // 0000002E7414: D5010000 00020900
	.long 0xd44a0000                                           // 0000002E741C: D44A0000
	v_cndmask_b32_e32 v1, 0, v15, vcc_lo                       // 0000002E7420: 02021E80
	s_waitcnt lgkmcnt(0)                                       // 0000002E7424: BF89FC07
	v_add_f32_e32 v7, v1, v8                                   // 0000002E7428: 060E1101
	ds_bpermute_b32 v1, v11, v2                                // 0000002E742C: DACC0000 0100020B
	v_lshlrev_b32_e32 v12, 2, v0                               // 0000002E7434: 30180082
	s_and_b32 s0, s0, vcc_lo                                   // 0000002E7438: 8B006A00
	s_waitcnt lgkmcnt(0)                                       // 0000002E743C: BF89FC07
	v_add_f32_e32 v4, v2, v1                                   // 0000002E7440: 06080302
	ds_bpermute_b32 v5, v11, v3                                // 0000002E7444: DACC0000 0500030B
	ds_bpermute_b32 v8, v11, v6                                // 0000002E744C: DACC0000 0800060B
	ds_bpermute_b32 v11, v11, v7                               // 0000002E7454: DACC0000 0B00070B
	s_waitcnt lgkmcnt(2)                                       // 0000002E745C: BF89FC27
	v_add_f32_e32 v5, v3, v5                                   // 0000002E7460: 060A0B03
	s_waitcnt lgkmcnt(0)                                       // 0000002E7464: BF89FC07
	v_dual_add_f32 v1, v6, v8 :: v_dual_add_f32 v0, v7, v11    // 0000002E7468: C9081106 01001707
	ds_bpermute_b32 v6, v12, v4                                // 0000002E7470: DACC0000 0600040C
	ds_bpermute_b32 v7, v12, v5                                // 0000002E7478: DACC0000 0700050C
	ds_bpermute_b32 v2, v12, v1                                // 0000002E7480: DACC0000 0200010C
	ds_bpermute_b32 v3, v12, v0                                // 0000002E7488: DACC0000 0300000C
	s_and_saveexec_b32 s1, s0                                  // 0000002E7490: BE812000
	s_cbranch_execz 61                                         // 0000002E7494: BFA5003D <_ZN7halogen12_GLOBAL__N_16k_lq8wILi4ELi32ELi1EEEvPKhPKtPtll+0x98c>
	s_waitcnt lgkmcnt(2)                                       // 0000002E7498: BF89FC27
	v_dual_add_f32 v7, v5, v7 :: v_dual_add_f32 v6, v4, v6     // 0000002E749C: C9080F05 07060D04
	.long 0x7f103880                                           // 0000002E74A4: 7F103880
	.long 0xd73c0004                                           // 0000002E74A8: D73C0004
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 0000002E74AC: 02021281
	s_waitcnt lgkmcnt(0)                                       // 0000002E74B0: BF89FC07
	v_dual_add_f32 v9, v1, v2 :: v_dual_add_f32 v10, v0, v3    // 0000002E74B4: C9080501 090A0700
	.long 0x7e103987                                           // 0000002E74BC: 7E103987
	.long 0x7e163986                                           // 0000002E74C0: 7E163986
	.long 0x7f163988                                           // 0000002E74C4: 7F163988
	.long 0xd7006a03                                           // 0000002E74C8: D7006A03
	v_cndmask_b32_e32 v1, s8, v4, vcc_lo                       // 0000002E74CC: 02020808
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000002E74D0: BF870224
	v_and_b32_e32 v0, 1, v8                                    // 0000002E74D4: 36001081
	v_add_co_ci_u32_e64 v4, null, s9, v5, vcc_lo               // 0000002E74D8: D5207C04 01AA0A09
	v_and_b32_e32 v1, 1, v11                                   // 0000002E74E0: 36021681
	.long 0x7e043989                                           // 0000002E74E4: 7E043989
	s_delay_alu instid0(VALU_DEP_4)                            // 0000002E74E8: BF870004
	v_add3_u32 v11, v7, v0, 0x7fff                             // 0000002E74EC: D655000B 03FE0107 00007FFF
	.long 0x7f043988                                           // 0000002E74F8: 7F043988
	.long 0x7e10398a                                           // 0000002E74FC: 7E10398A
	v_add3_u32 v12, v6, v1, 0x7fff                             // 0000002E7500: D655000C 03FE0306 00007FFF
	v_mad_u64_u32 v[0:1], null, s12, 6, v[3:4]                 // 0000002E750C: D6FE7C00 040D0C0C
	s_lshl_b64 s[0:1], s[12:13], 1                             // 0000002E7514: 8480810C
	v_and_b32_e32 v14, 1, v2                                   // 0000002E7518: 361C0481
	.long 0xd7006a05                                           // 0000002E751C: D7006A05
	v_cndmask_b32_e32 v0, v3, v0, vcc_lo                       // 0000002E7520: 02000103
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000002E7524: BF8700D1
	v_add_co_ci_u32_e64 v6, null, s1, v4, vcc_lo               // 0000002E7528: D5207C06 01AA0801
	s_lshl_b64 s[0:1], s[12:13], 2                             // 0000002E7530: 8480820C
	v_and_b32_e32 v13, 1, v8                                   // 0000002E7534: 361A1081
	v_mad_u64_u32 v[1:2], null, s13, 6, v[1:2]                 // 0000002E7538: D6FE7C01 04050C0D
	.long 0xd7006a07                                           // 0000002E7540: D7006A07
	v_cndmask_b32_e32 v0, v3, v0, vcc_lo                       // 0000002E7544: 02000103
	v_add_co_ci_u32_e64 v8, null, s1, v4, vcc_lo               // 0000002E7548: D5207C08 01AA0801
	v_add3_u32 v2, v9, v14, 0x7fff                             // 0000002E7550: D6550002 03FE1D09 00007FFF
	v_add3_u32 v9, v10, v13, 0x7fff                            // 0000002E755C: D6550009 03FE1B0A 00007FFF
	s_clause 0x3                                               // 0000002E7568: BF850003
	global_store_d16_hi_b16 v[3:4], v12, off                   // 0000002E756C: DC960000 007C0C03
	global_store_d16_hi_b16 v[5:6], v11, off                   // 0000002E7574: DC960000 007C0B05
	global_store_d16_hi_b16 v[7:8], v2, off                    // 0000002E757C: DC960000 007C0207
	global_store_d16_hi_b16 v[0:1], v9, off                    // 0000002E7584: DC960000 007C0900
	s_endpgm                                                   // 0000002E758C: BFB00000
		...

