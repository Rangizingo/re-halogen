0000000000863200 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000863200: F4100100 F8000000
	v_dual_mov_b32 v6, 0 :: v_dual_and_b32 v1, 15, v0          // 000000863208: CA240080 0600008F
	v_lshrrev_b32_e32 v2, 2, v0                                // 000000863210: 32040082
	s_ashr_i32 s3, s2, 31                                      // 000000863214: 86039F02
	v_mov_b32_e32 v5, 0                                        // 000000863218: 7E0A0280
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000086321C: BF870193
	v_dual_mov_b32 v8, 0 :: v_dual_lshlrev_b32 v1, 2, v1       // 000000863220: CA220080 08000282
	v_and_b32_e32 v2, 60, v2                                   // 000000863228: 360404BC
	v_lshrrev_b32_e32 v15, 5, v0                               // 00000086322C: 321E0085
	v_dual_mov_b32 v31, 0 :: v_dual_and_b32 v16, 31, v0        // 000000863230: CA240080 1F10009F
	.long 0x7f263880                                           // 000000863238: 7F263880
	v_dual_mov_b32 v17, 0 :: v_dual_lshlrev_b32 v14, 2, v0     // 00000086323C: CA220080 110E0082
	s_waitcnt lgkmcnt(0)                                       // 000000863244: BF89FC07
	s_clause 0x1                                               // 000000863248: BF850001
	global_load_b32 v11, v1, s[4:5]                            // 00000086324C: DC520000 0B040001
	global_load_b32 v13, v2, s[4:5]                            // 000000863254: DC520000 0D040002
	.long 0xd4510014                                           // 00000086325C: D4510014
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 000000863260: 02001802
	s_and_b32 s20, s20, exec_lo                                // 000000863264: 8B147E14
	s_cselect_b32 s24, s3, 0                                   // 000000863268: 98188003
	s_cselect_b32 s25, s2, 0                                   // 00000086326C: 98198002
	s_add_u32 s14, s4, s14                                     // 000000863270: 800E0E04
	s_addc_u32 s15, s5, s15                                    // 000000863274: 820F0F05
	s_lshr_b32 s20, s11, 31                                    // 000000863278: 85149F0B
	v_mov_b32_e32 v1, s14                                      // 00000086327C: 7E02020E
	s_add_u32 s20, s10, s20                                    // 000000863280: 8014140A
	s_addc_u32 s21, s11, 0                                     // 000000863284: 8215800B
	s_ashr_i32 s22, s11, 31                                    // 000000863288: 86169F0B
	s_ashr_i64 s[20:21], s[20:21], 1                           // 00000086328C: 86948114
	s_lshr_b32 s22, s22, 27                                    // 000000863290: 85169B16
	v_dual_mov_b32 v7, 0 :: v_dual_mov_b32 v2, s15             // 000000863294: CA100080 0702000F
	s_add_u32 s22, s10, s22                                    // 00000086329C: 8016160A
	s_addc_u32 s23, s11, 0                                     // 0000008632A0: 8217800B
	s_mul_i32 s19, s19, s25                                    // 0000008632A4: 96131913
	s_lshr_b64 s[22:23], s[22:23], 5                           // 0000008632A8: 85968516
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000008632AC: BF870499
	s_add_i32 s23, s22, 7                                      // 0000008632B0: 81178716
	s_ashr_i32 s26, s23, 31                                    // 0000008632B4: 861A9F17
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000008632B8: BF870499
	s_lshr_b32 s26, s26, 29                                    // 0000008632BC: 851A9D1A
	s_add_i32 s23, s23, s26                                    // 0000008632C0: 81171A17
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000008632C4: BF8704B9
	s_ashr_i32 s14, s23, 3                                     // 0000008632C8: 860E8317
	s_add_u32 s4, s4, s16                                      // 0000008632CC: 80041004
	s_addc_u32 s5, s5, s17                                     // 0000008632D0: 82051105
	v_dual_mov_b32 v3, s4 :: v_dual_mov_b32 v4, s5             // 0000008632D4: CA100004 03040005
	v_mad_u64_u32 v[9:10], null, s25, s20, v[1:2]              // 0000008632DC: D6FE7C09 04042819
	.long 0xd72c0012                                           // 0000008632E4: D72C0012
	v_cndmask_b32_e32 v1, s14, v15, vcc_lo                     // 0000008632E8: 02021E0E
	s_mul_i32 s4, s24, s20                                     // 0000008632EC: 96041418
	s_waitcnt vmcnt(1)                                         // 0000008632F0: BF8907F7
	v_bfe_u32 v12, v11, 16, 1                                  // 0000008632F4: D610000C 0205210B
	s_waitcnt vmcnt(0)                                         // 0000008632FC: BF8903F7
	v_bfe_u32 v1, v13, 16, 1                                   // 000000863300: D6100001 0205210D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000863308: BF870112
	v_add3_u32 v2, v11, v12, 0x7fff                            // 00000086330C: D6550002 03FE190B 00007FFF
	v_add3_u32 v1, v13, v1, 0x7fff                             // 000000863318: D6550001 03FE030D 00007FFF
	s_delay_alu instid0(VALU_DEP_2)                            // 000000863324: BF870002
	.long 0x7e263982                                           // 000000863328: 7E263982
	v_add_nc_u32_e32 v2, s4, v10                               // 00000086332C: 4A041404
	v_mad_u64_u32 v[11:12], null, s18, s25, v[3:4]             // 000000863330: D6FE7C0B 040C3212
	v_add_nc_u32_e32 v3, s14, v18                              // 000000863338: 4A06240E
	v_add_nc_u32_e32 v10, v18, v16                             // 00000086333C: 4A142112
	s_mul_i32 s25, s25, s21                                    // 000000863340: 96191519
	s_mul_i32 s4, s18, s24                                     // 000000863344: 96041812
	v_and_or_b32 v1, 0xffff0000, v1, v19                       // 000000863348: D6570001 044E02FF FFFF0000
	v_min_i32_e32 v18, s22, v3                                 // 000000863354: 22240616
	v_add_nc_u32_e32 v19, s25, v2                              // 000000863358: 4A260419
	v_add_nc_u32_e32 v3, s19, v12                              // 00000086335C: 4A061813
	ds_store_b32 v14, v1                                       // 000000863360: D8340000 0000010E
	v_cmp_lt_i32_e32 vcc_lo, v10, v18                          // 000000863368: 7C82250A
	v_add_nc_u32_e32 v20, s4, v3                               // 00000086336C: 4A280604
	s_waitcnt lgkmcnt(0)                                       // 000000863370: BF89FC07
	s_barrier                                                  // 000000863374: BFBD0000
	buffer_gl0_inv                                             // 000000863378: E0AC0000 00000000
	s_and_saveexec_b32 s5, vcc_lo                              // 000000863380: BE85206A
	s_cbranch_execz 21                                         // 000000863384: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x1dc>
	v_lshlrev_b32_e32 v1, 1, v10                               // 000000863388: 30021481
	v_lshlrev_b32_e32 v3, 4, v10                               // 00000086338C: 30061484
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000863390: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000863394: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000863398: 3408069F
	.long 0xd7000401                                           // 00000086339C: D7000401
	v_cndmask_b32_e32 v1, v11, v1, vcc_lo                      // 0000008633A0: 0202030B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008633A4: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v20, v2, s4                  // 0000008633A8: D5207C02 00120514
	.long 0xd7000403                                           // 0000008633B0: D7000403
	v_cndmask_b32_e32 v1, v9, v3, vcc_lo                       // 0000008633B4: 02020709
	v_add_co_ci_u32_e64 v4, null, v19, v4, s4                  // 0000008633B8: D5207C04 00120913
	s_clause 0x1                                               // 0000008633C0: BF850001
	global_load_d16_b16 v1, v[1:2], off                        // 0000008633C4: DC820000 017C0001
	global_load_b128 v[5:8], v[3:4], off                       // 0000008633CC: DC5E0000 057C0003
	s_waitcnt vmcnt(1)                                         // 0000008633D4: BF8907F7
	v_cvt_f32_f16_e32 v31, v1                                  // 0000008633D8: 7E3E1701
	s_or_b32 exec_lo, exec_lo, s5                              // 0000008633DC: 8C7E057E
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v23, 0             // 0000008633E0: CA100080 16160080
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v25, 0             // 0000008633E8: CA100080 18180080
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v27, 0             // 0000008633F0: CA100080 1A1A0080
	v_mov_b32_e32 v21, 0                                       // 0000008633F8: 7E2A0280
	s_and_saveexec_b32 s5, vcc_lo                              // 0000008633FC: BE85206A
	s_cbranch_execz 639                                        // 000000863400: BFA5027F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0xc00>
	v_dual_mov_b32 v26, 0 :: v_dual_add_nc_u32 v1, 32, v10     // 000000863404: CA200080 1A0014A0
	v_dual_mov_b32 v21, 0 :: v_dual_lshlrev_b32 v12, 5, v10    // 00000086340C: CA220080 150C1485
	v_dual_mov_b32 v25, 0 :: v_dual_mov_b32 v22, 0             // 000000863414: CA100080 19160080
	s_delay_alu instid0(VALU_DEP_3)                            // 00000086341C: BF870003
	v_dual_mov_b32 v27, 0 :: v_dual_lshlrev_b32 v28, 4, v1     // 000000863420: CA220080 1B1C0284
	v_dual_mov_b32 v24, 0 :: v_dual_lshlrev_b32 v29, 1, v1     // 000000863428: CA220080 181C0281
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v30, v31           // 000000863430: CA100080 171E011F
	v_mov_b32_e32 v17, 0                                       // 000000863438: 7E220280
	s_mul_i32 s4, s11, 6                                       // 00000086343C: 9604860B
	s_mul_hi_u32 s16, s10, 6                                   // 000000863440: 9690860A
	s_lshl_b64 s[14:15], s[10:11], 2                           // 000000863444: 848E820A
	s_add_i32 s16, s16, s4                                     // 000000863448: 81100410
	s_mul_i32 s18, s10, 6                                      // 00000086344C: 9612860A
	s_mov_b32 s17, 0                                           // 000000863450: BE910080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 000000863454: 848A810A
	s_branch 585                                               // 000000863458: BFA00249 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0xb80>
	s_or_b32 exec_lo, exec_lo, s19                             // 00000086345C: 8C7E137E
	v_and_b32_e32 v13, 0xff, v5                                // 000000863460: 361A0AFF 000000FF
	s_and_b32 s4, exec_lo, vcc_lo                              // 000000863468: 8B046A7E
	v_add_nc_u32_e32 v29, 64, v29                              // 00000086346C: 4A3A3AC0
	s_or_b32 s17, s4, s17                                      // 000000863470: 8C111104
	v_add_nc_u32_e32 v28, 0x200, v28                           // 000000863474: 4A3838FF 00000200
	v_lshlrev_b32_e32 v13, 2, v13                              // 00000086347C: 301A1A82
	ds_load_b32 v48, v13                                       // 000000863480: D8D80000 3000000D
	v_lshrrev_b32_e32 v13, 6, v5                               // 000000863488: 321A0A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000086348C: BF870141
	v_and_b32_e32 v13, 0x3fc, v13                              // 000000863490: 361A1AFF 000003FC
	ds_load_b32 v49, v13                                       // 000000863498: D8D80000 3100000D
	v_lshrrev_b32_e32 v13, 14, v5                              // 0000008634A0: 321A0A8E
	v_lshrrev_b32_e32 v5, 22, v5                               // 0000008634A4: 320A0A96
	v_and_b32_e32 v13, 0x3fc, v13                              // 0000008634A8: 361A1AFF 000003FC
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000008634B0: BF870152
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000008634B4: 360A0AFF 000003FC
	ds_load_b32 v50, v13                                       // 0000008634BC: D8D80000 3200000D
	ds_load_b32 v51, v5                                        // 0000008634C4: D8D80000 33000005
	v_and_b32_e32 v5, 0xff, v6                                 // 0000008634CC: 360A0CFF 000000FF
	v_ashrrev_i32_e32 v13, 31, v12                             // 0000008634D4: 341A189F
	v_lshlrev_b32_e32 v5, 2, v5                                // 0000008634D8: 300A0A82
	ds_load_b32 v52, v5                                        // 0000008634DC: D8D80000 34000005
	v_lshrrev_b32_e32 v5, 6, v6                                // 0000008634E4: 320A0C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008634E8: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000008634EC: 360A0AFF 000003FC
	ds_load_b32 v53, v5                                        // 0000008634F4: D8D80000 35000005
	v_lshrrev_b32_e32 v5, 14, v6                               // 0000008634FC: 320A0C8E
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000863500: 360A0AFF 000003FC
	ds_load_b32 v54, v5                                        // 000000863508: D8D80000 36000005
	v_lshrrev_b32_e32 v5, 22, v6                               // 000000863510: 320A0C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000863514: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000863518: 360A0AFF 000003FC
	ds_load_b32 v55, v5                                        // 000000863520: D8D80000 37000005
	v_and_b32_e32 v5, 0xff, v7                                 // 000000863528: 360A0EFF 000000FF
	v_lshlrev_b32_e32 v5, 2, v5                                // 000000863530: 300A0A82
	ds_load_b32 v56, v5                                        // 000000863534: D8D80000 38000005
	v_lshrrev_b32_e32 v5, 6, v7                                // 00000086353C: 320A0E86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000863540: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000863544: 360A0AFF 000003FC
	ds_load_b32 v57, v5                                        // 00000086354C: D8D80000 39000005
	v_lshrrev_b32_e32 v5, 14, v7                               // 000000863554: 320A0E8E
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000863558: 360A0AFF 000003FC
	ds_load_b32 v58, v5                                        // 000000863560: D8D80000 3A000005
	v_lshrrev_b32_e32 v5, 22, v7                               // 000000863568: 320A0E96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000086356C: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000863570: 360A0AFF 000003FC
	ds_load_b32 v59, v5                                        // 000000863578: D8D80000 3B000005
	v_and_b32_e32 v5, 0xff, v8                                 // 000000863580: 360A10FF 000000FF
	v_lshlrev_b32_e32 v5, 2, v5                                // 000000863588: 300A0A82
	ds_load_b32 v60, v5                                        // 00000086358C: D8D80000 3C000005
	v_lshrrev_b32_e32 v5, 6, v8                                // 000000863594: 320A1086
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000863598: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 00000086359C: 360A0AFF 000003FC
	ds_load_b32 v61, v5                                        // 0000008635A4: D8D80000 3D000005
	v_lshrrev_b32_e32 v5, 14, v8                               // 0000008635AC: 320A108E
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000008635B0: 360A0AFF 000003FC
	ds_load_b32 v62, v5                                        // 0000008635B8: D8D80000 3E000005
	v_lshrrev_b32_e32 v5, 22, v8                               // 0000008635C0: 320A1096
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000008635C4: BF870141
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000008635C8: 360A0AFF 000003FC
	ds_load_b32 v63, v5                                        // 0000008635D0: D8D80000 3F000005
	.long 0xd73c0005                                           // 0000008635D8: D73C0005
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 0000008635DC: 02021881
	v_add_nc_u32_e32 v12, 0x400, v12                           // 0000008635E0: 4A1818FF 00000400
	.long 0xd7006a2c                                           // 0000008635E8: D7006A2C
	v_cndmask_b32_e32 v1, s6, v5, vcc_lo                       // 0000008635EC: 02020A06
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008635F0: BF870001
	v_add_co_ci_u32_e64 v45, null, s7, v6, vcc_lo              // 0000008635F4: D5207C2D 01AA0C07
	s_clause 0x3                                               // 0000008635FC: BF850003
	global_load_b128 v[5:8], v[44:45], off                     // 000000863600: DC5E0000 057C002C
	global_load_b128 v[32:35], v[44:45], off offset:16         // 000000863608: DC5E0010 207C002C
	global_load_b128 v[36:39], v[44:45], off offset:32         // 000000863610: DC5E0020 247C002C
	global_load_b128 v[40:43], v[44:45], off offset:48         // 000000863618: DC5E0030 287C002C
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 000000863620: BF890CF7
	v_dot2_f32_bf16 v5, v5, v48, 0                             // 000000863624: CC1A4005 1A026105
	s_waitcnt lgkmcnt(14)                                      // 00000086362C: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000863630: BF8700A1
	v_dot2_f32_bf16 v5, v6, v49, v5                            // 000000863634: CC1A4005 1C166306
	s_waitcnt lgkmcnt(13)                                      // 00000086363C: BF89FCD7
	v_dot2_f32_bf16 v5, v7, v50, v5                            // 000000863640: CC1A4005 1C166507
	s_waitcnt lgkmcnt(12)                                      // 000000863648: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000086364C: BF8700A1
	v_dot2_f32_bf16 v5, v8, v51, v5                            // 000000863650: CC1A4005 1C166708
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 000000863658: BF8908B7
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 00000086365C: CC1A4005 1C166920
	s_waitcnt lgkmcnt(10)                                      // 000000863664: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000863668: BF8700A1
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 00000086366C: CC1A4005 1C166B21
	s_waitcnt lgkmcnt(9)                                       // 000000863674: BF89FC97
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 000000863678: CC1A4005 1C166D22
	s_waitcnt lgkmcnt(8)                                       // 000000863680: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000863684: BF8700A1
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 000000863688: CC1A4005 1C166F23
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 000000863690: BF890477
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 000000863694: CC1A4005 1C167124
	s_waitcnt lgkmcnt(6)                                       // 00000086369C: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008636A0: BF8700A1
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 0000008636A4: CC1A4005 1C167325
	s_waitcnt lgkmcnt(5)                                       // 0000008636AC: BF89FC57
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 0000008636B0: CC1A4005 1C167526
	s_waitcnt lgkmcnt(4)                                       // 0000008636B8: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008636BC: BF8700A1
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 0000008636C0: CC1A4005 1C167727
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 0000008636C8: BF890037
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 0000008636CC: CC1A4005 1C167928
	.long 0xd7006a28                                           // 0000008636D4: D7006A28
	v_cndmask_b32_e32 v0, v44, v10, vcc_lo                     // 0000008636D8: 0200152C
	s_waitcnt lgkmcnt(2)                                       // 0000008636DC: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000008636E0: BF8701C2
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 0000008636E4: CC1A4005 1C167B29
	v_add_co_ci_u32_e64 v41, null, s11, v45, vcc_lo            // 0000008636EC: D5207C29 01AA5A0B
	.long 0xd7006a2e                                           // 0000008636F4: D7006A2E
	v_cndmask_b32_e32 v0, v44, v14, vcc_lo                     // 0000008636F8: 02001D2C
	s_waitcnt lgkmcnt(1)                                       // 0000008636FC: BF89FC17
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 000000863700: CC1A4005 1C167D2A
	v_add_co_ci_u32_e64 v47, null, s15, v45, vcc_lo            // 000000863708: D5207C2F 01AA5A0F
	.long 0xd7006a2c                                           // 000000863710: D7006A2C
	v_cndmask_b32_e32 v0, v44, v18, vcc_lo                     // 000000863714: 0200252C
	s_waitcnt lgkmcnt(0)                                       // 000000863718: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000086371C: BF870123
	v_dot2_f32_bf16 v5, v43, v63, v5                           // 000000863720: CC1A4005 1C167F2B
	v_add_co_ci_u32_e64 v45, null, s16, v45, vcc_lo            // 000000863728: D5207C2D 01AA5A10
	v_fmac_f32_e32 v21, v31, v5                                // 000000863730: 562A0B1F
	s_clause 0x3                                               // 000000863734: BF850003
	global_load_b128 v[5:8], v[40:41], off                     // 000000863738: DC5E0000 057C0028
	global_load_b128 v[32:35], v[40:41], off offset:16         // 000000863740: DC5E0010 207C0028
	global_load_b128 v[36:39], v[40:41], off offset:32         // 000000863748: DC5E0020 247C0028
	global_load_b128 v[40:43], v[40:41], off offset:48         // 000000863750: DC5E0030 287C0028
	s_waitcnt vmcnt(3)                                         // 000000863758: BF890FF7
	v_dot2_f32_bf16 v5, v5, v48, 0                             // 00000086375C: CC1A4005 1A026105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000863764: BF870091
	v_dot2_f32_bf16 v5, v6, v49, v5                            // 000000863768: CC1A4005 1C166306
	v_dot2_f32_bf16 v5, v7, v50, v5                            // 000000863770: CC1A4005 1C166507
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000863778: BF8700A1
	v_dot2_f32_bf16 v5, v8, v51, v5                            // 00000086377C: CC1A4005 1C166708
	s_waitcnt vmcnt(2)                                         // 000000863784: BF890BF7
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 000000863788: CC1A4005 1C166920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000863790: BF870091
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 000000863794: CC1A4005 1C166B21
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 00000086379C: CC1A4005 1C166D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008637A4: BF8700A1
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 0000008637A8: CC1A4005 1C166F23
	s_waitcnt vmcnt(1)                                         // 0000008637B0: BF8907F7
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 0000008637B4: CC1A4005 1C167124
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008637BC: BF870091
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 0000008637C0: CC1A4005 1C167325
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 0000008637C8: CC1A4005 1C167526
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008637D0: BF8700A1
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 0000008637D4: CC1A4005 1C167727
	s_waitcnt vmcnt(0)                                         // 0000008637DC: BF8903F7
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 0000008637E0: CC1A4005 1C167928
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008637E8: BF870091
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 0000008637EC: CC1A4005 1C167B29
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 0000008637F4: CC1A4005 1C167D2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008637FC: BF870091
	v_dot2_f32_bf16 v5, v43, v63, v5                           // 000000863800: CC1A4005 1C167F2B
	v_fmac_f32_e32 v27, v31, v5                                // 000000863808: 56360B1F
	s_clause 0x3                                               // 00000086380C: BF850003
	global_load_b128 v[5:8], v[46:47], off                     // 000000863810: DC5E0000 057C002E
	global_load_b128 v[32:35], v[46:47], off offset:16         // 000000863818: DC5E0010 207C002E
	global_load_b128 v[36:39], v[46:47], off offset:32         // 000000863820: DC5E0020 247C002E
	global_load_b128 v[40:43], v[46:47], off offset:48         // 000000863828: DC5E0030 287C002E
	.long 0xd7006a2e                                           // 000000863830: D7006A2E
	v_cndmask_b32_e32 v0, v46, v14, vcc_lo                     // 000000863834: 02001D2E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000863838: BF8700B1
	v_add_co_ci_u32_e64 v47, null, s15, v47, vcc_lo            // 00000086383C: D5207C2F 01AA5E0F
	s_waitcnt vmcnt(3)                                         // 000000863844: BF890FF7
	v_dot2_f32_bf16 v5, v5, v48, 0                             // 000000863848: CC1A4005 1A026105
	v_dot2_f32_bf16 v5, v6, v49, v5                            // 000000863850: CC1A4005 1C166306
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000863858: BF870091
	v_dot2_f32_bf16 v5, v7, v50, v5                            // 00000086385C: CC1A4005 1C166507
	v_dot2_f32_bf16 v5, v8, v51, v5                            // 000000863864: CC1A4005 1C166708
	s_waitcnt vmcnt(2)                                         // 00000086386C: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000863870: BF870091
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 000000863874: CC1A4005 1C166920
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 00000086387C: CC1A4005 1C166B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000863884: BF870091
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 000000863888: CC1A4005 1C166D22
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 000000863890: CC1A4005 1C166F23
	s_waitcnt vmcnt(1)                                         // 000000863898: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000086389C: BF870091
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 0000008638A0: CC1A4005 1C167124
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 0000008638A8: CC1A4005 1C167325
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008638B0: BF870091
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 0000008638B4: CC1A4005 1C167526
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 0000008638BC: CC1A4005 1C167727
	s_waitcnt vmcnt(0)                                         // 0000008638C4: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008638C8: BF870091
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 0000008638CC: CC1A4005 1C167928
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 0000008638D4: CC1A4005 1C167B29
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008638DC: BF870091
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 0000008638E0: CC1A4005 1C167D2A
	v_dot2_f32_bf16 v5, v43, v63, v5                           // 0000008638E8: CC1A4005 1C167F2B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008638F0: BF870001
	v_fmac_f32_e32 v26, v31, v5                                // 0000008638F4: 56340B1F
	s_clause 0x3                                               // 0000008638F8: BF850003
	global_load_b128 v[5:8], v[44:45], off                     // 0000008638FC: DC5E0000 057C002C
	global_load_b128 v[32:35], v[44:45], off offset:16         // 000000863904: DC5E0010 207C002C
	global_load_b128 v[36:39], v[44:45], off offset:32         // 00000086390C: DC5E0020 247C002C
	global_load_b128 v[40:43], v[44:45], off offset:48         // 000000863914: DC5E0030 287C002C
	.long 0xd7006a2c                                           // 00000086391C: D7006A2C
	v_cndmask_b32_e32 v0, v44, v14, vcc_lo                     // 000000863920: 02001D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000863924: BF8700B1
	v_add_co_ci_u32_e64 v45, null, s15, v45, vcc_lo            // 000000863928: D5207C2D 01AA5A0F
	s_waitcnt vmcnt(3)                                         // 000000863930: BF890FF7
	v_dot2_f32_bf16 v5, v5, v48, 0                             // 000000863934: CC1A4005 1A026105
	v_dot2_f32_bf16 v5, v6, v49, v5                            // 00000086393C: CC1A4005 1C166306
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000863944: BF870091
	v_dot2_f32_bf16 v5, v7, v50, v5                            // 000000863948: CC1A4005 1C166507
	v_dot2_f32_bf16 v5, v8, v51, v5                            // 000000863950: CC1A4005 1C166708
	s_waitcnt vmcnt(2)                                         // 000000863958: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000086395C: BF870091
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 000000863960: CC1A4005 1C166920
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 000000863968: CC1A4005 1C166B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000863970: BF870091
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 000000863974: CC1A4005 1C166D22
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 00000086397C: CC1A4005 1C166F23
	s_waitcnt vmcnt(1)                                         // 000000863984: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000863988: BF870091
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 00000086398C: CC1A4005 1C167124
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 000000863994: CC1A4005 1C167325
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000086399C: BF870091
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 0000008639A0: CC1A4005 1C167526
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 0000008639A8: CC1A4005 1C167727
	s_waitcnt vmcnt(0)                                         // 0000008639B0: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008639B4: BF870091
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 0000008639B8: CC1A4005 1C167928
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 0000008639C0: CC1A4005 1C167B29
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008639C8: BF870091
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 0000008639CC: CC1A4005 1C167D2A
	v_dot2_f32_bf16 v5, v43, v63, v5                           // 0000008639D4: CC1A4005 1C167F2B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008639DC: BF870001
	v_fmac_f32_e32 v25, v31, v5                                // 0000008639E0: 56320B1F
	s_clause 0x3                                               // 0000008639E4: BF850003
	global_load_b128 v[5:8], v[46:47], off                     // 0000008639E8: DC5E0000 057C002E
	global_load_b128 v[32:35], v[46:47], off offset:16         // 0000008639F0: DC5E0010 207C002E
	global_load_b128 v[36:39], v[46:47], off offset:32         // 0000008639F8: DC5E0020 247C002E
	global_load_b128 v[40:43], v[46:47], off offset:48         // 000000863A00: DC5E0030 287C002E
	s_waitcnt vmcnt(3)                                         // 000000863A08: BF890FF7
	v_dot2_f32_bf16 v5, v5, v48, 0                             // 000000863A0C: CC1A4005 1A026105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000863A14: BF870091
	v_dot2_f32_bf16 v5, v6, v49, v5                            // 000000863A18: CC1A4005 1C166306
	v_dot2_f32_bf16 v5, v7, v50, v5                            // 000000863A20: CC1A4005 1C166507
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000863A28: BF8700A1
	v_dot2_f32_bf16 v5, v8, v51, v5                            // 000000863A2C: CC1A4005 1C166708
	s_waitcnt vmcnt(2)                                         // 000000863A34: BF890BF7
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 000000863A38: CC1A4005 1C166920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000863A40: BF870091
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 000000863A44: CC1A4005 1C166B21
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 000000863A4C: CC1A4005 1C166D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000863A54: BF8700A1
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 000000863A58: CC1A4005 1C166F23
	s_waitcnt vmcnt(1)                                         // 000000863A60: BF8907F7
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 000000863A64: CC1A4005 1C167124
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000863A6C: BF870091
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 000000863A70: CC1A4005 1C167325
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 000000863A78: CC1A4005 1C167526
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000863A80: BF8700A1
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 000000863A84: CC1A4005 1C167727
	s_waitcnt vmcnt(0)                                         // 000000863A8C: BF8903F7
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 000000863A90: CC1A4005 1C167928
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000863A98: BF870091
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 000000863A9C: CC1A4005 1C167B29
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 000000863AA4: CC1A4005 1C167D2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000863AAC: BF870091
	v_dot2_f32_bf16 v5, v43, v63, v5                           // 000000863AB0: CC1A4005 1C167F2B
	v_fmac_f32_e32 v24, v31, v5                                // 000000863AB8: 56300B1F
	s_clause 0x3                                               // 000000863ABC: BF850003
	global_load_b128 v[5:8], v[44:45], off                     // 000000863AC0: DC5E0000 057C002C
	global_load_b128 v[32:35], v[44:45], off offset:16         // 000000863AC8: DC5E0010 207C002C
	global_load_b128 v[36:39], v[44:45], off offset:32         // 000000863AD0: DC5E0020 247C002C
	global_load_b128 v[40:43], v[44:45], off offset:48         // 000000863AD8: DC5E0030 287C002C
	s_waitcnt vmcnt(3)                                         // 000000863AE0: BF890FF7
	v_dot2_f32_bf16 v5, v5, v48, 0                             // 000000863AE4: CC1A4005 1A026105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000863AEC: BF870091
	v_dot2_f32_bf16 v5, v6, v49, v5                            // 000000863AF0: CC1A4005 1C166306
	v_dot2_f32_bf16 v5, v7, v50, v5                            // 000000863AF8: CC1A4005 1C166507
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000863B00: BF8700A1
	v_dot2_f32_bf16 v5, v8, v51, v5                            // 000000863B04: CC1A4005 1C166708
	s_waitcnt vmcnt(2)                                         // 000000863B0C: BF890BF7
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 000000863B10: CC1A4005 1C166920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000863B18: BF870091
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 000000863B1C: CC1A4005 1C166B21
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 000000863B24: CC1A4005 1C166D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000863B2C: BF8700A1
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 000000863B30: CC1A4005 1C166F23
	s_waitcnt vmcnt(1)                                         // 000000863B38: BF8907F7
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 000000863B3C: CC1A4005 1C167124
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000863B44: BF870091
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 000000863B48: CC1A4005 1C167325
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 000000863B50: CC1A4005 1C167526
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000863B58: BF8700A1
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 000000863B5C: CC1A4005 1C167727
	s_waitcnt vmcnt(0)                                         // 000000863B64: BF8903F7
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 000000863B68: CC1A4005 1C167928
	.long 0xd7006a28                                           // 000000863B70: D7006A28
	v_cndmask_b32_e32 v0, v46, v14, vcc_lo                     // 000000863B74: 02001D2E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000863B78: BF870122
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 000000863B7C: CC1A4005 1C167B29
	v_add_co_ci_u32_e64 v41, null, s15, v47, vcc_lo            // 000000863B84: D5207C29 01AA5E0F
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 000000863B8C: CC1A4005 1C167D2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000863B94: BF870091
	v_dot2_f32_bf16 v5, v43, v63, v5                           // 000000863B98: CC1A4005 1C167F2B
	v_fmac_f32_e32 v23, v31, v5                                // 000000863BA0: 562E0B1F
	s_clause 0x3                                               // 000000863BA4: BF850003
	global_load_b128 v[5:8], v[40:41], off                     // 000000863BA8: DC5E0000 057C0028
	global_load_b128 v[32:35], v[40:41], off offset:16         // 000000863BB0: DC5E0010 207C0028
	global_load_b128 v[36:39], v[40:41], off offset:32         // 000000863BB8: DC5E0020 247C0028
	global_load_b128 v[40:43], v[40:41], off offset:48         // 000000863BC0: DC5E0030 287C0028
	s_waitcnt vmcnt(3)                                         // 000000863BC8: BF890FF7
	v_dot2_f32_bf16 v5, v5, v48, 0                             // 000000863BCC: CC1A4005 1A026105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000863BD4: BF870091
	v_dot2_f32_bf16 v5, v6, v49, v5                            // 000000863BD8: CC1A4005 1C166306
	v_dot2_f32_bf16 v5, v7, v50, v5                            // 000000863BE0: CC1A4005 1C166507
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000863BE8: BF8700A1
	v_dot2_f32_bf16 v5, v8, v51, v5                            // 000000863BEC: CC1A4005 1C166708
	s_waitcnt vmcnt(2)                                         // 000000863BF4: BF890BF7
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 000000863BF8: CC1A4005 1C166920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000863C00: BF870091
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 000000863C04: CC1A4005 1C166B21
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 000000863C0C: CC1A4005 1C166D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000863C14: BF8700A1
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 000000863C18: CC1A4005 1C166F23
	s_waitcnt vmcnt(1)                                         // 000000863C20: BF8907F7
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 000000863C24: CC1A4005 1C167124
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000863C2C: BF870091
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 000000863C30: CC1A4005 1C167325
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 000000863C38: CC1A4005 1C167526
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000863C40: BF8700A1
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 000000863C44: CC1A4005 1C167727
	s_waitcnt vmcnt(0)                                         // 000000863C4C: BF8903F7
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 000000863C50: CC1A4005 1C167928
	.long 0xd7006a28                                           // 000000863C58: D7006A28
	v_cndmask_b32_e32 v0, v44, v14, vcc_lo                     // 000000863C5C: 02001D2C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000863C60: BF870122
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 000000863C64: CC1A4005 1C167B29
	v_add_co_ci_u32_e64 v41, null, s15, v45, vcc_lo            // 000000863C6C: D5207C29 01AA5A0F
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 000000863C74: CC1A4005 1C167D2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000863C7C: BF870091
	v_dot2_f32_bf16 v5, v43, v63, v5                           // 000000863C80: CC1A4005 1C167F2B
	v_fmac_f32_e32 v22, v31, v5                                // 000000863C88: 562C0B1F
	s_clause 0x3                                               // 000000863C8C: BF850003
	global_load_b128 v[5:8], v[40:41], off                     // 000000863C90: DC5E0000 057C0028
	global_load_b128 v[32:35], v[40:41], off offset:16         // 000000863C98: DC5E0010 207C0028
	global_load_b128 v[36:39], v[40:41], off offset:32         // 000000863CA0: DC5E0020 247C0028
	global_load_b128 v[40:43], v[40:41], off offset:48         // 000000863CA8: DC5E0030 287C0028
	s_waitcnt vmcnt(3)                                         // 000000863CB0: BF890FF7
	v_dot2_f32_bf16 v5, v5, v48, 0                             // 000000863CB4: CC1A4005 1A026105
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000863CBC: BF870121
	v_dot2_f32_bf16 v5, v6, v49, v5                            // 000000863CC0: CC1A4005 1C166306
	v_mov_b32_e32 v6, v2                                       // 000000863CC8: 7E0C0302
	v_dot2_f32_bf16 v5, v7, v50, v5                            // 000000863CCC: CC1A4005 1C166507
	v_mov_b32_e32 v7, v3                                       // 000000863CD4: 7E0E0303
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000863CD8: BF870132
	v_dot2_f32_bf16 v5, v8, v51, v5                            // 000000863CDC: CC1A4005 1C166708
	v_mov_b32_e32 v8, v4                                       // 000000863CE4: 7E100304
	s_waitcnt vmcnt(2)                                         // 000000863CE8: BF890BF7
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 000000863CEC: CC1A4005 1C166920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000863CF4: BF870091
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 000000863CF8: CC1A4005 1C166B21
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 000000863D00: CC1A4005 1C166D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000863D08: BF8700A1
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 000000863D0C: CC1A4005 1C166F23
	s_waitcnt vmcnt(1)                                         // 000000863D14: BF8907F7
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 000000863D18: CC1A4005 1C167124
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000863D20: BF870091
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 000000863D24: CC1A4005 1C167325
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 000000863D2C: CC1A4005 1C167526
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000863D34: BF8700A1
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 000000863D38: CC1A4005 1C167727
	s_waitcnt vmcnt(0)                                         // 000000863D40: BF8903F7
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 000000863D44: CC1A4005 1C167928
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000863D4C: BF870091
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 000000863D50: CC1A4005 1C167B29
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 000000863D58: CC1A4005 1C167D2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000863D60: BF870091
	v_dot2_f32_bf16 v5, v43, v63, v5                           // 000000863D64: CC1A4005 1C167F2B
	v_fmac_f32_e32 v17, v31, v5                                // 000000863D6C: 56220B1F
	v_mov_b32_e32 v5, v1                                       // 000000863D70: 7E0A0301
	v_mov_b32_e32 v31, v30                                     // 000000863D74: 7E3E031E
	s_and_not1_b32 exec_lo, exec_lo, s17                       // 000000863D78: 917E117E
	s_cbranch_execz 31                                         // 000000863D7C: BFA5001F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0xbfc>
	s_waitcnt vmcnt(0)                                         // 000000863D80: BF8903F7
	v_dual_mov_b32 v1, v5 :: v_dual_add_nc_u32 v10, 32, v10    // 000000863D84: CA200105 010A14A0
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v3, v7             // 000000863D8C: CA100106 02020107
	v_mov_b32_e32 v4, v8                                       // 000000863D94: 7E080308
	s_mov_b32 s19, exec_lo                                     // 000000863D98: BE93007E
	s_delay_alu instid0(VALU_DEP_3)                            // 000000863D9C: BF870003
	v_cmp_ge_i32_e32 vcc_lo, v10, v18                          // 000000863DA0: 7C8C250A
	.long 0xd4c1007e                                           // 000000863DA4: D4C1007E
	v_cndmask_b32_e32 v1, v10, v18, vcc_lo                     // 000000863DA8: 0202250A
	s_cbranch_execz 64939                                      // 000000863DAC: BFA5FDAB <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x25c>
	v_ashrrev_i32_e32 v2, 31, v29                              // 000000863DB0: 34043A9F
	v_ashrrev_i32_e32 v4, 31, v28                              // 000000863DB4: 3408389F
	.long 0xd7000401                                           // 000000863DB8: D7000401
	v_cndmask_b32_e32 v1, v11, v29, vcc_lo                     // 000000863DBC: 02023B0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000863DC0: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v20, v2, s4                  // 000000863DC4: D5207C02 00120514
	.long 0xd7000403                                           // 000000863DCC: D7000403
	v_cndmask_b32_e32 v1, v9, v28, vcc_lo                      // 000000863DD0: 02023909
	v_add_co_ci_u32_e64 v4, null, v19, v4, s4                  // 000000863DD4: D5207C04 00120913
	s_clause 0x1                                               // 000000863DDC: BF850001
	global_load_d16_b16 v13, v[1:2], off                       // 000000863DE0: DC820000 0D7C0001
	global_load_b128 v[1:4], v[3:4], off                       // 000000863DE8: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 000000863DF0: BF8907F7
	v_cvt_f32_f16_e32 v30, v13                                 // 000000863DF4: 7E3C170D
	s_branch 64920                                             // 000000863DF8: BFA0FD98 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x25c>
	s_or_b32 exec_lo, exec_lo, s17                             // 000000863DFC: 8C7E117E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000863E00: BF8700B9
	s_or_b32 exec_lo, exec_lo, s5                              // 000000863E04: 8C7E057E
	.long 0xd71f0001                                           // 000000863E08: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000863E0C: 020100C1
	s_mov_b32 s4, exec_lo                                      // 000000863E10: BE84007E
	v_xor_b32_e32 v2, 16, v1                                   // 000000863E14: 3A040290
	v_xor_b32_e32 v10, 8, v1                                   // 000000863E18: 3A140288
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000863E1C: BF8701A2
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 000000863E20: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 000000863E24: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 000000863E28: 7C9814A0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000863E2C: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 000000863E30: 30040482
	ds_bpermute_b32 v3, v2, v21                                // 000000863E34: DACC0000 03001502
	s_waitcnt lgkmcnt(0)                                       // 000000863E3C: BF89FC07
	v_add_f32_e32 v3, v21, v3                                  // 000000863E40: 06060715
	s_waitcnt vmcnt(0)                                         // 000000863E44: BF8903F7
	ds_bpermute_b32 v5, v2, v26                                // 000000863E48: DACC0000 05001A02
	ds_bpermute_b32 v7, v2, v24                                // 000000863E50: DACC0000 07001802
	ds_bpermute_b32 v9, v2, v22                                // 000000863E58: DACC0000 09001602
	ds_bpermute_b32 v4, v2, v27                                // 000000863E60: DACC0000 04001B02
	v_cndmask_b32_e32 v10, v1, v10, vcc_lo                     // 000000863E68: 02141501
	ds_bpermute_b32 v6, v2, v25                                // 000000863E6C: DACC0000 06001902
	ds_bpermute_b32 v8, v2, v23                                // 000000863E74: DACC0000 08001702
	ds_bpermute_b32 v2, v2, v17                                // 000000863E7C: DACC0000 02001102
	v_xor_b32_e32 v21, 4, v1                                   // 000000863E84: 3A2A0284
	s_delay_alu instid0(VALU_DEP_1)                            // 000000863E88: BF870001
	v_cmp_gt_u32_e32 vcc_lo, 32, v21                           // 000000863E8C: 7C982AA0
	v_cndmask_b32_e32 v21, v1, v21, vcc_lo                     // 000000863E90: 022A2B01
	s_waitcnt lgkmcnt(6)                                       // 000000863E94: BF89FC67
	v_add_f32_e32 v5, v26, v5                                  // 000000863E98: 060A0B1A
	s_waitcnt lgkmcnt(5)                                       // 000000863E9C: BF89FC57
	v_dual_add_f32 v7, v24, v7 :: v_dual_lshlrev_b32 v10, 2, v10// 000000863EA0: C9220F18 070A1482
	s_waitcnt lgkmcnt(3)                                       // 000000863EA8: BF89FC37
	v_dual_add_f32 v9, v22, v9 :: v_dual_add_f32 v4, v27, v4   // 000000863EAC: C9081316 0904091B
	s_waitcnt lgkmcnt(2)                                       // 000000863EB4: BF89FC27
	v_dual_add_f32 v6, v25, v6 :: v_dual_lshlrev_b32 v21, 2, v21// 000000863EB8: C9220D19 06142A82
	ds_bpermute_b32 v11, v10, v3                               // 000000863EC0: DACC0000 0B00030A
	ds_bpermute_b32 v13, v10, v5                               // 000000863EC8: DACC0000 0D00050A
	s_waitcnt lgkmcnt(3)                                       // 000000863ED0: BF89FC37
	v_add_f32_e32 v8, v23, v8                                  // 000000863ED4: 06101117
	s_waitcnt lgkmcnt(2)                                       // 000000863ED8: BF89FC27
	v_add_f32_e32 v2, v17, v2                                  // 000000863EDC: 06040511
	ds_bpermute_b32 v12, v10, v4                               // 000000863EE0: DACC0000 0C00040A
	ds_bpermute_b32 v17, v10, v6                               // 000000863EE8: DACC0000 1100060A
	ds_bpermute_b32 v18, v10, v7                               // 000000863EF0: DACC0000 1200070A
	ds_bpermute_b32 v20, v10, v9                               // 000000863EF8: DACC0000 1400090A
	s_waitcnt lgkmcnt(5)                                       // 000000863F00: BF89FC57
	v_add_f32_e32 v3, v3, v11                                  // 000000863F04: 06061703
	s_waitcnt lgkmcnt(4)                                       // 000000863F08: BF89FC47
	v_add_f32_e32 v5, v5, v13                                  // 000000863F0C: 060A1B05
	ds_bpermute_b32 v19, v10, v8                               // 000000863F10: DACC0000 1300080A
	ds_bpermute_b32 v10, v10, v2                               // 000000863F18: DACC0000 0A00020A
	s_waitcnt lgkmcnt(5)                                       // 000000863F20: BF89FC57
	v_add_f32_e32 v4, v4, v12                                  // 000000863F24: 06081904
	s_waitcnt lgkmcnt(3)                                       // 000000863F28: BF89FC37
	v_dual_add_f32 v6, v6, v17 :: v_dual_add_f32 v7, v7, v18   // 000000863F2C: C9082306 06062507
	s_waitcnt lgkmcnt(2)                                       // 000000863F34: BF89FC27
	v_add_f32_e32 v9, v9, v20                                  // 000000863F38: 06122909
	ds_bpermute_b32 v12, v21, v5                               // 000000863F3C: DACC0000 0C000515
	ds_bpermute_b32 v11, v21, v4                               // 000000863F44: DACC0000 0B000415
	ds_bpermute_b32 v13, v21, v6                               // 000000863F4C: DACC0000 0D000615
	ds_bpermute_b32 v17, v21, v7                               // 000000863F54: DACC0000 11000715
	s_waitcnt lgkmcnt(5)                                       // 000000863F5C: BF89FC57
	v_add_f32_e32 v8, v8, v19                                  // 000000863F60: 06102708
	s_waitcnt lgkmcnt(4)                                       // 000000863F64: BF89FC47
	v_add_f32_e32 v2, v2, v10                                  // 000000863F68: 06041502
	ds_bpermute_b32 v10, v21, v3                               // 000000863F6C: DACC0000 0A000315
	ds_bpermute_b32 v19, v21, v9                               // 000000863F74: DACC0000 13000915
	ds_bpermute_b32 v18, v21, v8                               // 000000863F7C: DACC0000 12000815
	ds_bpermute_b32 v20, v21, v2                               // 000000863F84: DACC0000 14000215
	v_xor_b32_e32 v21, 2, v1                                   // 000000863F8C: 3A2A0282
	s_waitcnt lgkmcnt(5)                                       // 000000863F90: BF89FC57
	v_dual_add_f32 v5, v5, v12 :: v_dual_add_f32 v6, v6, v13   // 000000863F94: C9081905 05061B06
	v_add_f32_e32 v4, v4, v11                                  // 000000863F9C: 06081704
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000863FA0: BF870143
	v_cmp_gt_u32_e32 vcc_lo, 32, v21                           // 000000863FA4: 7C982AA0
	v_cndmask_b32_e32 v21, v1, v21, vcc_lo                     // 000000863FA8: 022A2B01
	s_waitcnt lgkmcnt(4)                                       // 000000863FAC: BF89FC47
	v_add_f32_e32 v7, v7, v17                                  // 000000863FB0: 060E2307
	v_lshlrev_b32_e32 v21, 2, v21                              // 000000863FB4: 302A2A82
	s_waitcnt lgkmcnt(3)                                       // 000000863FB8: BF89FC37
	v_add_f32_e32 v3, v3, v10                                  // 000000863FBC: 06061503
	s_waitcnt lgkmcnt(1)                                       // 000000863FC0: BF89FC17
	v_add_f32_e32 v8, v8, v18                                  // 000000863FC4: 06102508
	ds_bpermute_b32 v10, v21, v4                               // 000000863FC8: DACC0000 0A000415
	v_add_f32_e32 v9, v9, v19                                  // 000000863FD0: 06122709
	ds_bpermute_b32 v12, v21, v5                               // 000000863FD4: DACC0000 0C000515
	ds_bpermute_b32 v13, v21, v6                               // 000000863FDC: DACC0000 0D000615
	ds_bpermute_b32 v17, v21, v7                               // 000000863FE4: DACC0000 11000715
	ds_bpermute_b32 v18, v21, v8                               // 000000863FEC: DACC0000 12000815
	ds_bpermute_b32 v19, v21, v9                               // 000000863FF4: DACC0000 13000915
	s_waitcnt lgkmcnt(6)                                       // 000000863FFC: BF89FC67
	v_add_f32_e32 v11, v2, v20                                 // 000000864000: 06162902
	ds_bpermute_b32 v2, v21, v3                                // 000000864004: DACC0000 02000315
	ds_bpermute_b32 v20, v21, v11                              // 00000086400C: DACC0000 14000B15
	v_xor_b32_e32 v21, 1, v1                                   // 000000864014: 3A2A0281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000864018: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v21                           // 00000086401C: 7C982AA0
	v_cndmask_b32_e32 v1, v1, v21, vcc_lo                      // 000000864020: 02022B01
	v_lshlrev_b32_e32 v21, 2, v1                               // 000000864024: 302A0282
	s_waitcnt lgkmcnt(1)                                       // 000000864028: BF89FC17
	v_add_f32_e32 v1, v3, v2                                   // 00000086402C: 06020503
	v_add_f32_e32 v2, v4, v10                                  // 000000864030: 06041504
	v_dual_add_f32 v4, v5, v12 :: v_dual_add_f32 v5, v6, v13   // 000000864034: C9081905 04041B06
	v_add_f32_e32 v3, v7, v17                                  // 00000086403C: 06062307
	v_dual_add_f32 v7, v8, v18 :: v_dual_add_f32 v10, v9, v19  // 000000864040: C9082508 070A2709
	s_waitcnt lgkmcnt(0)                                       // 000000864048: BF89FC07
	v_add_f32_e32 v12, v11, v20                                // 00000086404C: 0618290B
	ds_bpermute_b32 v6, v21, v1                                // 000000864050: DACC0000 06000115
	ds_bpermute_b32 v8, v21, v2                                // 000000864058: DACC0000 08000215
	ds_bpermute_b32 v11, v21, v4                               // 000000864060: DACC0000 0B000415
	ds_bpermute_b32 v13, v21, v5                               // 000000864068: DACC0000 0D000515
	ds_bpermute_b32 v9, v21, v3                                // 000000864070: DACC0000 09000315
	ds_bpermute_b32 v17, v21, v7                               // 000000864078: DACC0000 11000715
	ds_bpermute_b32 v18, v21, v10                              // 000000864080: DACC0000 12000A15
	ds_bpermute_b32 v19, v21, v12                              // 000000864088: DACC0000 13000C15
	v_cmpx_eq_u32_e32 0, v16                                   // 000000864090: 7D942080
	s_cbranch_execz 14                                         // 000000864094: BFA5000E <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0xed0>
	s_waitcnt lgkmcnt(0)                                       // 000000864098: BF89FC07
	v_dual_add_f32 v19, v12, v19 :: v_dual_add_f32 v18, v10, v18// 00000086409C: C908270C 1312250A
	v_dual_add_f32 v17, v7, v17 :: v_dual_add_f32 v12, v4, v11 // 0000008640A4: C9082307 110C1704
	v_add_f32_e32 v13, v5, v13                                 // 0000008640AC: 061A1B05
	v_dual_add_f32 v11, v2, v8 :: v_dual_add_f32 v10, v1, v6   // 0000008640B0: C9081102 0B0A0D01
	v_dual_add_f32 v16, v3, v9 :: v_dual_lshlrev_b32 v1, 5, v15// 0000008640B8: C9221303 10001E85
	ds_store_b128 v1, v[10:13] offset:1024                     // 0000008640C0: DB7C0400 00000A01
	ds_store_b128 v1, v[16:19] offset:1040                     // 0000008640C8: DB7C0410 00001001
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008640D0: 8C7E047E
	.long 0xd4510004                                           // 0000008640D4: D4510004
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 0000008640D8: 02001802
	v_cmp_gt_u32_e32 vcc_lo, 8, v0                             // 0000008640DC: 7C980088
	s_waitcnt lgkmcnt(0)                                       // 0000008640E0: BF89FC07
	s_barrier                                                  // 0000008640E4: BFBD0000
	buffer_gl0_inv                                             // 0000008640E8: E0AC0000 00000000
	s_and_b32 s4, vcc_lo, s4                                   // 0000008640F0: 8B04046A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000008640F4: BF870009
	s_and_saveexec_b32 s5, s4                                  // 0000008640F8: BE852004
	s_cbranch_execz 85                                         // 0000008640FC: BFA50055 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x1054>
	v_add_nc_u32_e32 v7, 0x400, v14                            // 000000864100: 4A0E1CFF 00000400
	s_load_b32 s0, s[0:1], 0x48                                // 000000864108: F4000000 F8000048
	ds_load_2addr_b32 v[1:2], v7 offset1:8                     // 000000864110: D8DC0800 01000007
	ds_load_2addr_b32 v[3:4], v7 offset0:16 offset1:24         // 000000864118: D8DC1810 03000007
	ds_load_2addr_b32 v[5:6], v7 offset0:32 offset1:40         // 000000864120: D8DC2820 05000007
	s_waitcnt lgkmcnt(0)                                       // 000000864128: BF89FC07
	v_add_f32_e32 v1, 0, v1                                    // 00000086412C: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000864130: BF8700B1
	v_add_f32_e32 v8, v1, v2                                   // 000000864134: 06100501
	ds_load_2addr_b32 v[1:2], v7 offset0:48 offset1:56         // 000000864138: D8DC3830 01000007
	v_add_f32_e32 v3, v8, v3                                   // 000000864140: 06060708
	v_add_f32_e32 v3, v3, v4                                   // 000000864144: 06060903
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000864148: BF870091
	v_add_f32_e32 v3, v3, v5                                   // 00000086414C: 06060B03
	v_add_f32_e32 v3, v3, v6                                   // 000000864150: 06060D03
	s_waitcnt lgkmcnt(0)                                       // 000000864154: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000864158: BF870091
	v_add_f32_e32 v1, v3, v1                                   // 00000086415C: 06020303
	v_add_f32_e32 v1, v1, v2                                   // 000000864160: 06020501
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000864164: BF870091
	v_bfe_u32 v2, v1, 16, 1                                    // 000000864168: D6100002 02052101
	v_add3_u32 v1, v1, v2, 0x7fff                              // 000000864170: D6550001 03FE0501 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000086417C: BF870091
	v_and_b32_e32 v1, 0xffff0000, v1                           // 000000864180: 360202FF FFFF0000
	v_mul_f32_e32 v1, s0, v1                                   // 000000864188: 10020200
	s_lshl_b64 s[0:1], s[2:3], 2                               // 00000086418C: 84808202
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000864190: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v1                           // 000000864194: 100202FF BFB8AA3B
	v_exp_f32_e32 v1, v1                                       // 00000086419C: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008641A0: BF870095
	v_add_f32_e32 v4, 1.0, v1                                  // 0000008641A4: 060802F2
	v_div_scale_f32 v5, null, v4, v4, 1.0                      // 0000008641A8: D6FC7C05 03CA0904
	v_div_scale_f32 v7, vcc_lo, 1.0, v4, 1.0                   // 0000008641B0: D6FC6A07 03CA08F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000008641B8: BF870292
	v_rcp_f32_e32 v6, v5                                       // 0000008641BC: 7E0C5505
	v_fma_f32 v1, -v5, v6, 1.0                                 // 0000008641C0: D6130001 23CA0D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008641C8: BF870121
	v_fmac_f32_e32 v6, v1, v6                                  // 0000008641CC: 560C0D01
	v_mad_u64_u32 v[1:2], null, s12, v0, 0                     // 0000008641D0: D6FE7C01 0202000C
	v_mul_f32_e32 v8, v7, v6                                   // 0000008641D8: 10100D07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008641DC: BF870091
	v_fma_f32 v3, -v5, v8, v7                                  // 0000008641E0: D6130003 241E1105
	v_fmac_f32_e32 v8, v3, v6                                  // 0000008641E8: 56100D03
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008641EC: BF870114
	v_mad_u64_u32 v[2:3], null, s13, v0, v[2:3]                // 0000008641F0: D6FE7C02 040A000D
	v_fma_f32 v0, -v5, v8, v7                                  // 0000008641F8: D6130000 241E1105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000864200: BF870191
	v_div_fmas_f32 v3, v0, v6, v8                              // 000000864204: D6370003 04220D00
	.long 0xd73c0000                                           // 00000086420C: D73C0000
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000864210: 02020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000864214: BF870112
	v_div_fixup_f32 v2, v3, v4, 1.0                            // 000000864218: D6270002 03CA0903
	.long 0xd7006a00                                           // 000000864220: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 000000864224: 02020008
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000864228: BF870191
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 00000086422C: D5207C01 01AA0209
	v_add_f32_e32 v2, v2, v2                                   // 000000864234: 06040502
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000864238: BF870093
	.long 0xd7006a00                                           // 00000086423C: D7006A00
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 000000864240: 02000100
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 000000864244: D5207C01 01AA0201
	global_store_b32 v[0:1], v2, off                           // 00000086424C: DC6A0000 007C0200
	s_endpgm                                                   // 000000864254: BFB00000
		...

