00000000004a7500 <_ZN7halogen12_GLOBAL__N_113k_ht_deq_origILi4ELb1ELi16EEEvPKjiPKDF16_S5_Pti>:
; _ZN7halogen12_GLOBAL__N_113k_ht_deq_origILi4ELb1ELi16EEEvPKjiPKDF16_S5_Pti():
	s_clause 0x1                                               // 0000004A7500: BF850001
	s_load_b32 s11, s[0:1], 0x28                               // 0000004A7504: F40002C0 F8000028
	s_load_b32 s10, s[0:1], 0x8                                // 0000004A750C: F4000280 F8000008
	v_lshlrev_b32_e32 v1, 2, v0                                // 0000004A7514: 30020082
	v_lshrrev_b32_e32 v3, 7, v0                                // 0000004A7518: 32060087
	s_clause 0x2                                               // 0000004A751C: BF850002
	s_load_b64 s[12:13], s[0:1], null                          // 0000004A7520: F4040300 F8000000
	s_load_b128 s[4:7], s[0:1], 0x10                           // 0000004A7528: F4080100 F8000010
	s_load_b64 s[8:9], s[0:1], 0x20                            // 0000004A7530: F4040200 F8000020
	v_bfe_u32 v21, v0, 5, 3                                    // 0000004A7538: D6100015 020D0B00
	v_and_b32_e32 v4, 31, v0                                   // 0000004A7540: 3608009F
	v_and_b32_e32 v2, 0x60, v1                                 // 0000004A7544: 360402FF 00000060
	v_and_b32_e32 v1, 28, v1                                   // 0000004A754C: 3602029C
	v_lshrrev_b32_e32 v9, 6, v0                                // 0000004A7550: 32120086
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000004A7554: BF870224
	v_lshlrev_b32_e32 v22, 5, v4                               // 0000004A7558: 302C0885
	v_lshlrev_b32_e32 v15, 2, v4                               // 0000004A755C: 301E0882
	v_or3_b32 v2, v2, v3, v1                                   // 0000004A7560: D6580002 04060702
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000004A7568: BF870134
	v_and_b32_e32 v24, 4, v9                                   // 0000004A756C: 36301284
	v_or_b32_e32 v25, 3, v9                                    // 0000004A7570: 38321283
	v_add_nc_u32_e32 v23, 0x3f0, v22                           // 0000004A7574: 4A2E2CFF 000003F0
	v_lshlrev_b32_e32 v9, 7, v25                               // 0000004A757C: 30123287
	s_waitcnt lgkmcnt(0)                                       // 0000004A7580: BF89FC07
	s_cmp_eq_u32 s11, 0                                        // 0000004A7584: BF06800B
	s_delay_alu instid0(VALU_DEP_2)                            // 0000004A7588: BF870002
	v_lshrrev_b32_e32 v10, 5, v23                              // 0000004A758C: 32142E85
	s_cselect_b32 s0, s3, s2                                   // 0000004A7590: 98000203
	s_cselect_b32 s3, s2, s3                                   // 0000004A7594: 98030302
	s_lshl_b32 s2, s0, 7                                       // 0000004A7598: 84028700
	s_lshl_b32 s1, s3, 7                                       // 0000004A759C: 84018703
	v_or_b32_e32 v1, s2, v2                                    // 0000004A75A0: 38020402
	v_or_b32_e32 v7, s1, v2                                    // 0000004A75A4: 380E0401
	v_lshl_or_b32 v5, s0, 3, v21                               // 0000004A75A8: D6560005 04550600
	s_ashr_i32 s11, s10, 31                                    // 0000004A75B0: 860B9F0A
	s_delay_alu instid0(VALU_DEP_3)                            // 0000004A75B4: BF870003
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000004A75B8: 3404029F
	s_lshr_b32 s0, s11, 28                                     // 0000004A75BC: 85009C0B
	v_ashrrev_i32_e32 v8, 31, v7                               // 0000004A75C0: 34100E9F
	v_ashrrev_i32_e32 v6, 31, v5                               // 0000004A75C4: 340C0A9F
	s_add_i32 s0, s10, s0                                      // 0000004A75C8: 8100000A
	.long 0xd73c0001                                           // 0000004A75CC: D73C0001
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000004A75D0: 02020281
	s_ashr_i32 s0, s0, 4                                       // 0000004A75D4: 86008400
	.long 0xd73c0007                                           // 0000004A75D8: D73C0007
	v_cndmask_b32_e32 v1, 1, v7, vcc_lo                        // 0000004A75DC: 02020E81
	v_mad_i64_i32 v[5:6], null, s3, s0, v[5:6]                 // 0000004A75E0: D6FF7C05 04140003
	s_movk_i32 s3, 0x1eee                                      // 0000004A75E8: B0031EEE
	.long 0xd4490000                                           // 0000004A75EC: D4490000
	v_cndmask_b32_e32 v1, 0x1ff, v0, vcc_lo                    // 0000004A75F0: 020200FF 000001FF
	.long 0xd7006a01                                           // 0000004A75F8: D7006A01
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 0000004A75FC: 02020204
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000004A7600: BF8700A1
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 0000004A7604: D5207C02 01AA0405
	.long 0xd7006a07                                           // 0000004A760C: D7006A07
	v_cndmask_b32_e32 v1, s6, v7, vcc_lo                       // 0000004A7610: 02020E06
	v_add_co_ci_u32_e64 v8, null, s7, v8, vcc_lo               // 0000004A7614: D5207C08 01AA1007
	.long 0xd73c0005                                           // 0000004A761C: D73C0005
	v_cndmask_b32_e32 v1, 10, v5, vcc_lo                       // 0000004A7620: 02020A8A
	global_load_d16_hi_b16 v1, v[1:2], off                     // 0000004A7624: DC8E0000 017C0001
	global_load_d16_b16 v1, v[7:8], off                        // 0000004A762C: DC820000 017C0007
	v_add_nc_u32_e32 v2, 1, v10                                // 0000004A7634: 4A041481
	v_lshlrev_b32_e32 v7, 7, v24                               // 0000004A7638: 300E3087
	v_lshrrev_b32_e32 v8, 3, v23                               // 0000004A763C: 32102E83
	.long 0xd7006a0a                                           // 0000004A7640: D7006A0A
	v_cndmask_b32_e32 v1, s12, v5, vcc_lo                      // 0000004A7644: 02020A0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000004A7648: BF870221
	v_add_co_ci_u32_e64 v11, null, s13, v6, vcc_lo             // 0000004A764C: D5207C0B 01AA0C0D
	v_and_b32_e32 v2, 31, v2                                   // 0000004A7654: 3604049F
	v_and_b32_e32 v12, 0x7c, v8                                // 0000004A7658: 361810FF 0000007C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004A7660: BF870094
	.long 0xd7006a0d                                           // 0000004A7664: D7006A0D
	v_cndmask_b32_e32 v1, v10, v7, vcc_lo                      // 0000004A7668: 02020F0A
	v_add_co_ci_u32_e64 v14, null, 0, v11, vcc_lo              // 0000004A766C: D5207C0E 01AA1680
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004A7674: BF870194
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000004A7678: 30040482
	.long 0xd7006a05                                           // 0000004A767C: D7006A05
	v_cndmask_b32_e32 v1, v13, v12, vcc_lo                     // 0000004A7680: 0202190D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004A7684: BF870191
	v_add_co_ci_u32_e64 v6, null, 0, v14, vcc_lo               // 0000004A7688: D5207C06 01AA1C80
	.long 0xd7006a07                                           // 0000004A7690: D7006A07
	v_cndmask_b32_e32 v1, v13, v2, vcc_lo                      // 0000004A7694: 0202050D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000004A7698: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v14, vcc_lo               // 0000004A769C: D5207C08 01AA1C80
	.long 0xd7006a10                                           // 0000004A76A4: D7006A10
	v_cndmask_b32_e32 v1, v10, v9, vcc_lo                      // 0000004A76A8: 0202130A
	v_add_co_ci_u32_e64 v17, null, 0, v11, vcc_lo              // 0000004A76AC: D5207C11 01AA1680
	.long 0xd7006a09                                           // 0000004A76B4: D7006A09
	v_cndmask_b32_e32 v1, v13, v15, vcc_lo                     // 0000004A76B8: 02021F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004A76BC: BF870211
	v_add_co_ci_u32_e64 v10, null, 0, v14, vcc_lo              // 0000004A76C0: D5207C0A 01AA1C80
	.long 0xd7006a0b                                           // 0000004A76C8: D7006A0B
	v_cndmask_b32_e32 v1, v16, v12, vcc_lo                     // 0000004A76CC: 02021910
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000004A76D0: BF8700A1
	v_add_co_ci_u32_e64 v12, null, 0, v17, vcc_lo              // 0000004A76D4: D5207C0C 01AA2280
	.long 0xd7006a0d                                           // 0000004A76DC: D7006A0D
	v_cndmask_b32_e32 v1, v16, v2, vcc_lo                      // 0000004A76E0: 02020510
	v_add_co_ci_u32_e64 v14, null, 0, v17, vcc_lo              // 0000004A76E4: D5207C0E 01AA2280
	.long 0xd7006a0f                                           // 0000004A76EC: D7006A0F
	v_cndmask_b32_e32 v1, v16, v15, vcc_lo                     // 0000004A76F0: 02021F10
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004A76F4: BF870001
	v_add_co_ci_u32_e64 v16, null, 0, v17, vcc_lo              // 0000004A76F8: D5207C10 01AA2280
	s_clause 0xb                                               // 0000004A7700: BF85000B
	global_load_b32 v18, v[5:6], off                           // 0000004A7704: DC520000 127C0005
	global_load_b32 v17, v[7:8], off                           // 0000004A770C: DC520000 117C0007
	global_load_b32 v26, v[9:10], off                          // 0000004A7714: DC520000 1A7C0009
	global_load_b32 v20, v[5:6], off offset:128                // 0000004A771C: DC520080 147C0005
	global_load_b32 v19, v[7:8], off offset:128                // 0000004A7724: DC520080 137C0007
	global_load_b32 v27, v[9:10], off offset:128               // 0000004A772C: DC520080 1B7C0009
	global_load_b32 v7, v[7:8], off offset:256                 // 0000004A7734: DC520100 077C0007
	global_load_b32 v8, v[5:6], off offset:256                 // 0000004A773C: DC520100 087C0005
	global_load_b32 v28, v[9:10], off offset:256               // 0000004A7744: DC520100 1C7C0009
	global_load_b32 v6, v[11:12], off                          // 0000004A774C: DC520000 067C000B
	global_load_b32 v5, v[13:14], off                          // 0000004A7754: DC520000 057C000D
	global_load_b32 v29, v[15:16], off                         // 0000004A775C: DC520000 1D7C000F
	v_lshrrev_b32_e32 v2, 1, v0                                // 0000004A7764: 32040081
	v_and_b32_e32 v9, 15, v0                                   // 0000004A7768: 3612008F
	v_lshlrev_b32_e32 v12, 4, v24                              // 0000004A776C: 30183084
	v_and_b32_e32 v14, 0x7e0, v23                              // 0000004A7770: 361C2EFF 000007E0
	v_cmp_gt_u32_e32 vcc_lo, 0x200, v0                         // 0000004A7778: 7C9800FF 00000200
	v_and_b32_e32 v10, 8, v2                                   // 0000004A7780: 36140488
	v_lshlrev_b32_e32 v11, 9, v9                               // 0000004A7784: 30161289
	v_lshl_or_b32 v13, v25, 4, v9                              // 0000004A7788: D656000D 04250919
	v_or3_b32 v12, v12, v9, 16                                 // 0000004A7790: D658000C 0242130C
	v_sub_nc_u32_e32 v14, v14, v22                             // 0000004A7798: 4C1C2D0E
	v_lshl_or_b32 v10, v21, 4, v10                             // 0000004A779C: D656000A 04290915
	v_lshl_or_b32 v11, v24, 13, v11                            // 0000004A77A4: D656000B 042D1B18
	v_and_b32_e32 v33, 31, v13                                 // 0000004A77AC: 36421A9F
	v_and_b32_e32 v39, 31, v12                                 // 0000004A77B0: 364E189F
	v_lshlrev_b32_e32 v12, 9, v12                              // 0000004A77B4: 30181889
	v_or_b32_e32 v16, 1, v10                                   // 0000004A77B8: 38201481
	v_or_b32_e32 v21, 2, v10                                   // 0000004A77BC: 382A1482
	v_or_b32_e32 v23, 3, v10                                   // 0000004A77C0: 382E1483
	v_or_b32_e32 v24, 4, v10                                   // 0000004A77C4: 38301484
	v_or_b32_e32 v25, 5, v10                                   // 0000004A77C8: 38321485
	v_or_b32_e32 v30, 6, v10                                   // 0000004A77CC: 383C1486
	v_or_b32_e32 v31, 7, v10                                   // 0000004A77D0: 383E1487
	v_xor_b32_e32 v15, v10, v9                                 // 0000004A77D4: 3A1E130A
	v_xor_b32_e32 v22, v16, v9                                 // 0000004A77D8: 3A2C1310
	v_xor_b32_e32 v34, v21, v9                                 // 0000004A77DC: 3A441315
	v_xor_b32_e32 v35, v23, v9                                 // 0000004A77E0: 3A461317
	v_xor_b32_e32 v36, v24, v9                                 // 0000004A77E4: 3A481318
	v_xor_b32_e32 v37, v25, v9                                 // 0000004A77E8: 3A4A1319
	v_xor_b32_e32 v38, v30, v9                                 // 0000004A77EC: 3A4C131E
	v_xor_b32_e32 v9, v31, v9                                  // 0000004A77F0: 3A12131F
	v_or_b32_e32 v32, 0x4000, v11                              // 0000004A77F4: 384016FF 00004000
	v_lshlrev_b32_e32 v15, 2, v15                              // 0000004A77FC: 301E1E82
	v_xor_b32_e32 v40, v10, v33                                // 0000004A7800: 3A50430A
	v_add_nc_u32_e32 v47, 0xfffffc3c, v14                      // 0000004A7804: 4A5E1CFF FFFFFC3C
	v_add_nc_u32_e32 v48, 0xfffffc38, v14                      // 0000004A780C: 4A601CFF FFFFFC38
	v_add_nc_u32_e32 v49, 0xfffffc34, v14                      // 0000004A7814: 4A621CFF FFFFFC34
	v_add_nc_u32_e32 v50, 0xfffffc30, v14                      // 0000004A781C: 4A641CFF FFFFFC30
	v_lshlrev_b32_e32 v14, 2, v22                              // 0000004A7824: 301C2C82
	v_lshlrev_b32_e32 v22, 2, v34                              // 0000004A7828: 302C4482
	v_lshlrev_b32_e32 v34, 2, v35                              // 0000004A782C: 30444682
	v_lshlrev_b32_e32 v35, 2, v36                              // 0000004A7830: 30464882
	v_lshlrev_b32_e32 v36, 2, v37                              // 0000004A7834: 30484A82
	v_lshlrev_b32_e32 v37, 2, v38                              // 0000004A7838: 304A4C82
	v_lshlrev_b32_e32 v9, 2, v9                                // 0000004A783C: 30121282
	v_xor_b32_e32 v10, v10, v39                                // 0000004A7840: 3A144F0A
	v_lshlrev_b32_e32 v13, 9, v13                              // 0000004A7844: 301A1A89
	v_xor_b32_e32 v41, v16, v33                                // 0000004A7848: 3A524310
	v_xor_b32_e32 v42, v21, v33                                // 0000004A784C: 3A544315
	v_xor_b32_e32 v43, v23, v33                                // 0000004A7850: 3A564317
	v_xor_b32_e32 v44, v24, v33                                // 0000004A7854: 3A584318
	v_xor_b32_e32 v45, v25, v33                                // 0000004A7858: 3A5A4319
	v_xor_b32_e32 v46, v30, v33                                // 0000004A785C: 3A5C431E
	v_xor_b32_e32 v33, v31, v33                                // 0000004A7860: 3A42431F
	v_xor_b32_e32 v16, v16, v39                                // 0000004A7864: 3A204F10
	v_xor_b32_e32 v21, v21, v39                                // 0000004A7868: 3A2A4F15
	v_xor_b32_e32 v23, v23, v39                                // 0000004A786C: 3A2E4F17
	v_xor_b32_e32 v24, v24, v39                                // 0000004A7870: 3A304F18
	v_xor_b32_e32 v25, v25, v39                                // 0000004A7874: 3A324F19
	v_xor_b32_e32 v30, v30, v39                                // 0000004A7878: 3A3C4F1E
	v_xor_b32_e32 v31, v31, v39                                // 0000004A787C: 3A3E4F1F
	v_or_b32_e32 v38, v32, v15                                 // 0000004A7880: 384C1F20
	v_or_b32_e32 v53, v11, v34                                 // 0000004A7884: 386A450B
	v_or_b32_e32 v54, v11, v35                                 // 0000004A7888: 386C470B
	v_or_b32_e32 v55, v11, v36                                 // 0000004A788C: 386E490B
	v_or_b32_e32 v56, v11, v37                                 // 0000004A7890: 38704B0B
	v_or_b32_e32 v57, v11, v9                                  // 0000004A7894: 3872130B
	v_lshl_or_b32 v58, v10, 2, v12                             // 0000004A7898: D656003A 0431050A
	v_or_b32_e32 v62, v32, v14                                 // 0000004A78A0: 387C1D20
	v_or_b32_e32 v63, v32, v22                                 // 0000004A78A4: 387E2D20
	v_or_b32_e32 v34, v32, v34                                 // 0000004A78A8: 38444520
	v_or_b32_e32 v35, v32, v35                                 // 0000004A78AC: 38464720
	v_or_b32_e32 v36, v32, v36                                 // 0000004A78B0: 38484920
	v_or_b32_e32 v37, v32, v37                                 // 0000004A78B4: 384A4B20
	v_or_b32_e32 v32, v32, v9                                  // 0000004A78B8: 38401320
	v_or_b32_e32 v51, v11, v15                                 // 0000004A78BC: 38661F0B
	v_lshl_or_b32 v39, v40, 2, v13                             // 0000004A78C0: D6560027 04350528
	v_lshl_or_b32 v40, v41, 2, v13                             // 0000004A78C8: D6560028 04350529
	v_lshl_or_b32 v41, v42, 2, v13                             // 0000004A78D0: D6560029 0435052A
	v_lshl_or_b32 v42, v43, 2, v13                             // 0000004A78D8: D656002A 0435052B
	v_lshl_or_b32 v43, v44, 2, v13                             // 0000004A78E0: D656002B 0435052C
	v_lshl_or_b32 v44, v45, 2, v13                             // 0000004A78E8: D656002C 0435052D
	v_lshl_or_b32 v45, v46, 2, v13                             // 0000004A78F0: D656002D 0435052E
	v_or_b32_e32 v46, v11, v14                                 // 0000004A78F8: 385C1D0B
	v_or_b32_e32 v52, v11, v22                                 // 0000004A78FC: 38682D0B
	v_lshl_or_b32 v59, v16, 2, v12                             // 0000004A7900: D656003B 04310510
	v_lshl_or_b32 v60, v21, 2, v12                             // 0000004A7908: D656003C 04310515
	v_lshl_or_b32 v61, v23, 2, v12                             // 0000004A7910: D656003D 04310517
	v_lshl_or_b32 v24, v24, 2, v12                             // 0000004A7918: D6560018 04310518
	v_lshl_or_b32 v25, v25, 2, v12                             // 0000004A7920: D6560019 04310519
	v_lshl_or_b32 v30, v30, 2, v12                             // 0000004A7928: D656001E 0431051E
	v_lshl_or_b32 v31, v31, 2, v12                             // 0000004A7930: D656001F 0431051F
	v_lshl_or_b32 v33, v33, 2, v13                             // 0000004A7938: D6560021 04350521
	v_and_b32_e32 v2, 0x7f, v0                                 // 0000004A7940: 360400FF 0000007F
	s_waitcnt vmcnt(10)                                        // 0000004A7948: BF892BF7
	.long 0xd73d0009                                           // 0000004A794C: D73D0009
	v_cndmask_b32_e32 v1, v47, v17, vcc_lo                     // 0000004A7950: 0202232F
	.long 0xd73d000a                                           // 0000004A7954: D73D000A
	v_cndmask_b32_e32 v1, v48, v17, vcc_lo                     // 0000004A7958: 02022330
	.long 0xd73d000b                                           // 0000004A795C: D73D000B
	v_cndmask_b32_e32 v1, v49, v17, vcc_lo                     // 0000004A7960: 02022331
	.long 0xd73d000c                                           // 0000004A7964: D73D000C
	v_cndmask_b32_e32 v1, v50, v17, vcc_lo                     // 0000004A7968: 02022332
	s_waitcnt vmcnt(7)                                         // 0000004A796C: BF891FF7
	.long 0xd73d000d                                           // 0000004A7970: D73D000D
	v_cndmask_b32_e32 v1, v47, v19, vcc_lo                     // 0000004A7974: 0202272F
	.long 0xd73d000e                                           // 0000004A7978: D73D000E
	v_cndmask_b32_e32 v1, v48, v19, vcc_lo                     // 0000004A797C: 02022730
	.long 0xd73d000f                                           // 0000004A7980: D73D000F
	v_cndmask_b32_e32 v1, v49, v19, vcc_lo                     // 0000004A7984: 02022731
	.long 0xd73d0010                                           // 0000004A7988: D73D0010
	v_cndmask_b32_e32 v1, v50, v19, vcc_lo                     // 0000004A798C: 02022732
	s_waitcnt vmcnt(4)                                         // 0000004A7990: BF8913F7
	.long 0xd73d0011                                           // 0000004A7994: D73D0011
	v_cndmask_b32_e32 v1, v47, v7, vcc_lo                      // 0000004A7998: 02020F2F
	.long 0xd73d0012                                           // 0000004A799C: D73D0012
	v_cndmask_b32_e32 v1, v48, v7, vcc_lo                      // 0000004A79A0: 02020F30
	.long 0xd73d0013                                           // 0000004A79A4: D73D0013
	v_cndmask_b32_e32 v1, v49, v7, vcc_lo                      // 0000004A79A8: 02020F31
	s_waitcnt vmcnt(1)                                         // 0000004A79AC: BF8907F7
	.long 0xd73d0014                                           // 0000004A79B0: D73D0014
	v_cndmask_b32_e32 v1, v47, v5, vcc_lo                      // 0000004A79B4: 02020B2F
	.long 0xd73d0015                                           // 0000004A79B8: D73D0015
	v_cndmask_b32_e32 v1, v48, v5, vcc_lo                      // 0000004A79BC: 02020B30
	.long 0xd73d0016                                           // 0000004A79C0: D73D0016
	v_cndmask_b32_e32 v1, v49, v5, vcc_lo                      // 0000004A79C4: 02020B31
	v_and_b32_e32 v9, 0xffff, v9                               // 0000004A79C8: 361212FF 0000FFFF
	v_and_b32_e32 v11, 0xffff, v11                             // 0000004A79D0: 361616FF 0000FFFF
	v_bfe_u32 v64, v26, 12, 16                                 // 0000004A79D8: D6100040 0241191A
	.long 0xd73d0007                                           // 0000004A79E0: D73D0007
	v_cndmask_b32_e32 v1, v50, v7, vcc_lo                      // 0000004A79E4: 02020F32
	.long 0xd73d0005                                           // 0000004A79E8: D73D0005
	v_cndmask_b32_e32 v1, v50, v5, vcc_lo                      // 0000004A79EC: 02020B32
	v_bfe_u32 v65, v26, 8, 16                                  // 0000004A79F0: D6100041 0241111A
	v_bfe_u32 v66, v26, 4, 16                                  // 0000004A79F8: D6100042 0241091A
	v_bfe_u32 v67, v27, 12, 16                                 // 0000004A7A00: D6100043 0241191B
	v_bfe_u32 v68, v27, 8, 16                                  // 0000004A7A08: D6100044 0241111B
	v_bfe_u32 v69, v27, 4, 16                                  // 0000004A7A10: D6100045 0241091B
	v_bfe_u32 v8, v28, 12, 16                                  // 0000004A7A18: D6100008 0241191C
	v_bfe_u32 v71, v28, 4, 16                                  // 0000004A7A20: D6100047 0241091C
	s_waitcnt vmcnt(0)                                         // 0000004A7A28: BF8903F7
	v_bfe_u32 v6, v29, 12, 16                                  // 0000004A7A2C: D6100006 0241191D
	v_bfe_u32 v47, v29, 4, 16                                  // 0000004A7A34: D610002F 0241091D
	v_and_b32_e32 v10, 0xffff, v10                             // 0000004A7A3C: 361414FF 0000FFFF
	v_and_b32_e32 v13, 0xffff, v13                             // 0000004A7A44: 361A1AFF 0000FFFF
	v_and_b32_e32 v15, 0xffff, v15                             // 0000004A7A4C: 361E1EFF 0000FFFF
	v_and_b32_e32 v17, 0xffff, v17                             // 0000004A7A54: 362222FF 0000FFFF
	v_and_b32_e32 v19, 0xffff, v19                             // 0000004A7A5C: 362626FF 0000FFFF
	v_and_b32_e32 v20, 0xffff, v20                             // 0000004A7A64: 362828FF 0000FFFF
	v_and_b32_e32 v22, 0xffff, v22                             // 0000004A7A6C: 362C2CFF 0000FFFF
	.long 0xd72c0009                                           // 0000004A7A74: D72C0009
	v_cndmask_b32_e32 v1, 0x83dcd12d, v9, vcc_lo               // 0000004A7A78: 020212FF 83DCD12D
	v_and_b32_e32 v12, 0xffff, v12                             // 0000004A7A80: 361818FF 0000FFFF
	.long 0xd72c000b                                           // 0000004A7A88: D72C000B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v11, vcc_lo              // 0000004A7A8C: 020216FF 83DCD12D
	.long 0xd72c0030                                           // 0000004A7A94: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 0000004A7A98: 020280FF 83DCD12D
	v_and_b32_e32 v26, 0xffff, v26                             // 0000004A7AA0: 363434FF 0000FFFF
	v_and_b32_e32 v27, 0xffff, v27                             // 0000004A7AA8: 363636FF 0000FFFF
	v_bfe_u32 v70, v28, 8, 16                                  // 0000004A7AB0: D6100046 0241111C
	v_and_b32_e32 v28, 0xffff, v28                             // 0000004A7AB8: 363838FF 0000FFFF
	v_bfe_u32 v23, v29, 8, 16                                  // 0000004A7AC0: D6100017 0241111D
	v_and_b32_e32 v29, 0xffff, v29                             // 0000004A7AC8: 363A3AFF 0000FFFF
	.long 0xd72c0031                                           // 0000004A7AD0: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 0000004A7AD4: 020282FF 83DCD12D
	.long 0xd72c0032                                           // 0000004A7ADC: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 0000004A7AE0: 020284FF 83DCD12D
	.long 0xd72c0040                                           // 0000004A7AE8: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 0000004A7AEC: 020286FF 83DCD12D
	.long 0xd72c0041                                           // 0000004A7AF4: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 0000004A7AF8: 020288FF 83DCD12D
	.long 0xd72c0042                                           // 0000004A7B00: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 0000004A7B04: 02028AFF 83DCD12D
	.long 0xd72c0008                                           // 0000004A7B0C: D72C0008
	v_cndmask_b32_e32 v1, 0x83dcd12d, v8, vcc_lo               // 0000004A7B10: 020210FF 83DCD12D
	.long 0xd72c0044                                           // 0000004A7B18: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 0000004A7B1C: 02028EFF 83DCD12D
	.long 0xd72c0006                                           // 0000004A7B24: D72C0006
	v_cndmask_b32_e32 v1, 0x83dcd12d, v6, vcc_lo               // 0000004A7B28: 02020CFF 83DCD12D
	.long 0xd72c002f                                           // 0000004A7B30: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 0000004A7B34: 02025EFF 83DCD12D
	v_and_b32_e32 v14, 0xffff, v14                             // 0000004A7B3C: 361C1CFF 0000FFFF
	v_and_b32_e32 v16, 0xffff, v16                             // 0000004A7B44: 362020FF 0000FFFF
	v_and_b32_e32 v18, 0xffff, v18                             // 0000004A7B4C: 362424FF 0000FFFF
	v_and_b32_e32 v7, 0xffff, v7                               // 0000004A7B54: 360E0EFF 0000FFFF
	v_and_b32_e32 v21, 0xffff, v21                             // 0000004A7B5C: 362A2AFF 0000FFFF
	v_and_b32_e32 v5, 0xffff, v5                               // 0000004A7B64: 360A0AFF 0000FFFF
	.long 0xd72c000a                                           // 0000004A7B6C: D72C000A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v10, vcc_lo              // 0000004A7B70: 020214FF 83DCD12D
	.long 0xd72c000d                                           // 0000004A7B78: D72C000D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v13, vcc_lo              // 0000004A7B7C: 02021AFF 83DCD12D
	.long 0xd72c000f                                           // 0000004A7B84: D72C000F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v15, vcc_lo              // 0000004A7B88: 02021EFF 83DCD12D
	.long 0xd72c0011                                           // 0000004A7B90: D72C0011
	v_cndmask_b32_e32 v1, 0x83dcd12d, v17, vcc_lo              // 0000004A7B94: 020222FF 83DCD12D
	.long 0xd72c0013                                           // 0000004A7B9C: D72C0013
	v_cndmask_b32_e32 v1, 0x83dcd12d, v19, vcc_lo              // 0000004A7BA0: 020226FF 83DCD12D
	.long 0xd72c0014                                           // 0000004A7BA8: D72C0014
	v_cndmask_b32_e32 v1, 0x83dcd12d, v20, vcc_lo              // 0000004A7BAC: 020228FF 83DCD12D
	.long 0xd72c0016                                           // 0000004A7BB4: D72C0016
	v_cndmask_b32_e32 v1, 0x83dcd12d, v22, vcc_lo              // 0000004A7BB8: 02022CFF 83DCD12D
	.long 0xd72c000c                                           // 0000004A7BC0: D72C000C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v12, vcc_lo              // 0000004A7BC4: 020218FF 83DCD12D
	v_sad_u8 v9, v9, 0, 0x6400                                 // 0000004A7BCC: D6220009 03FD0109 00006400
	.long 0xd72c001a                                           // 0000004A7BD8: D72C001A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v26, vcc_lo              // 0000004A7BDC: 020234FF 83DCD12D
	.long 0xd72c001b                                           // 0000004A7BE4: D72C001B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v27, vcc_lo              // 0000004A7BE8: 020236FF 83DCD12D
	.long 0xd72c0043                                           // 0000004A7BF0: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v70, vcc_lo              // 0000004A7BF4: 02028CFF 83DCD12D
	.long 0xd72c001c                                           // 0000004A7BFC: D72C001C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v28, vcc_lo              // 0000004A7C00: 020238FF 83DCD12D
	.long 0xd72c0017                                           // 0000004A7C08: D72C0017
	v_cndmask_b32_e32 v1, 0x83dcd12d, v23, vcc_lo              // 0000004A7C0C: 02022EFF 83DCD12D
	.long 0xd72c001d                                           // 0000004A7C14: D72C001D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v29, vcc_lo              // 0000004A7C18: 02023AFF 83DCD12D
	.long 0xd72c000e                                           // 0000004A7C20: D72C000E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v14, vcc_lo              // 0000004A7C24: 02021CFF 83DCD12D
	.long 0xd72c0010                                           // 0000004A7C2C: D72C0010
	v_cndmask_b32_e32 v1, 0x83dcd12d, v16, vcc_lo              // 0000004A7C30: 020220FF 83DCD12D
	.long 0xd72c0012                                           // 0000004A7C38: D72C0012
	v_cndmask_b32_e32 v1, 0x83dcd12d, v18, vcc_lo              // 0000004A7C3C: 020224FF 83DCD12D
	.long 0xd72c0007                                           // 0000004A7C44: D72C0007
	v_cndmask_b32_e32 v1, 0x83dcd12d, v7, vcc_lo               // 0000004A7C48: 02020EFF 83DCD12D
	.long 0xd72c0015                                           // 0000004A7C50: D72C0015
	v_cndmask_b32_e32 v1, 0x83dcd12d, v21, vcc_lo              // 0000004A7C54: 02022AFF 83DCD12D
	.long 0xd72c0005                                           // 0000004A7C5C: D72C0005
	v_cndmask_b32_e32 v1, 0x83dcd12d, v5, vcc_lo               // 0000004A7C60: 02020AFF 83DCD12D
	v_sad_u8 v11, v11, 0, 0x6400                               // 0000004A7C68: D622000B 03FD010B 00006400
	v_sad_u8 v48, v48, 0, 0x6400                               // 0000004A7C74: D6220030 03FD0130 00006400
	v_sad_u8 v50, v50, 0, 0x6400                               // 0000004A7C80: D6220032 03FD0132 00006400
	v_sad_u8 v64, v64, 0, 0x6400                               // 0000004A7C8C: D6220040 03FD0140 00006400
	v_sad_u8 v66, v66, 0, 0x6400                               // 0000004A7C98: D6220042 03FD0142 00006400
	v_sad_u8 v8, v8, 0, 0x6400                                 // 0000004A7CA4: D6220008 03FD0108 00006400
	v_sad_u8 v68, v68, 0, 0x6400                               // 0000004A7CB0: D6220044 03FD0144 00006400
	v_sad_u8 v6, v6, 0, 0x6400                                 // 0000004A7CBC: D6220006 03FD0106 00006400
	v_sad_u8 v47, v47, 0, 0x6400                               // 0000004A7CC8: D622002F 03FD012F 00006400
	v_sad_u8 v10, v10, 0, 0x6400                               // 0000004A7CD4: D622000A 03FD010A 00006400
	v_sad_u8 v13, v13, 0, 0x6400                               // 0000004A7CE0: D622000D 03FD010D 00006400
	v_sad_u8 v15, v15, 0, 0x6400                               // 0000004A7CEC: D622000F 03FD010F 00006400
	v_sad_u8 v17, v17, 0, 0x6400                               // 0000004A7CF8: D6220011 03FD0111 00006400
	v_sad_u8 v19, v19, 0, 0x6400                               // 0000004A7D04: D6220013 03FD0113 00006400
	v_sad_u8 v20, v20, 0, 0x6400                               // 0000004A7D10: D6220014 03FD0114 00006400
	v_sad_u8 v22, v22, 0, 0x6400                               // 0000004A7D1C: D6220016 03FD0116 00006400
	v_and_b32_e32 v9, 0xffff, v9                               // 0000004A7D28: 361212FF 0000FFFF
	v_sad_u8 v12, v12, 0, 0x6400                               // 0000004A7D30: D622000C 03FD010C 00006400
	v_and_b32_e32 v11, 0xffff, v11                             // 0000004A7D3C: 361616FF 0000FFFF
	v_sad_u8 v49, v49, 0, 0x6400                               // 0000004A7D44: D6220031 03FD0131 00006400
	v_and_b32_e32 v48, 0xffff, v48                             // 0000004A7D50: 366060FF 0000FFFF
	v_sad_u8 v26, v26, 0, 0x6400                               // 0000004A7D58: D622001A 03FD011A 00006400
	v_sad_u8 v65, v65, 0, 0x6400                               // 0000004A7D64: D6220041 03FD0141 00006400
	v_sad_u8 v27, v27, 0, 0x6400                               // 0000004A7D70: D622001B 03FD011B 00006400
	v_sad_u8 v67, v67, 0, 0x6400                               // 0000004A7D7C: D6220043 03FD0143 00006400
	v_sad_u8 v28, v28, 0, 0x6400                               // 0000004A7D88: D622001C 03FD011C 00006400
	v_sad_u8 v23, v23, 0, 0x6400                               // 0000004A7D94: D6220017 03FD0117 00006400
	v_sad_u8 v29, v29, 0, 0x6400                               // 0000004A7DA0: D622001D 03FD011D 00006400
	v_and_b32_e32 v50, 0xffff, v50                             // 0000004A7DAC: 366464FF 0000FFFF
	v_and_b32_e32 v64, 0xffff, v64                             // 0000004A7DB4: 368080FF 0000FFFF
	v_and_b32_e32 v66, 0xffff, v66                             // 0000004A7DBC: 368484FF 0000FFFF
	v_and_b32_e32 v8, 0xffff, v8                               // 0000004A7DC4: 361010FF 0000FFFF
	v_and_b32_e32 v68, 0xffff, v68                             // 0000004A7DCC: 368888FF 0000FFFF
	v_and_b32_e32 v6, 0xffff, v6                               // 0000004A7DD4: 360C0CFF 0000FFFF
	v_and_b32_e32 v47, 0xffff, v47                             // 0000004A7DDC: 365E5EFF 0000FFFF
	v_sad_u8 v14, v14, 0, 0x6400                               // 0000004A7DE4: D622000E 03FD010E 00006400
	v_sad_u8 v16, v16, 0, 0x6400                               // 0000004A7DF0: D6220010 03FD0110 00006400
	v_sad_u8 v18, v18, 0, 0x6400                               // 0000004A7DFC: D6220012 03FD0112 00006400
	v_sad_u8 v7, v7, 0, 0x6400                                 // 0000004A7E08: D6220007 03FD0107 00006400
	v_sad_u8 v21, v21, 0, 0x6400                               // 0000004A7E14: D6220015 03FD0115 00006400
	v_sad_u8 v5, v5, 0, 0x6400                                 // 0000004A7E20: D6220005 03FD0105 00006400
	v_and_b32_e32 v13, 0xffff, v13                             // 0000004A7E2C: 361A1AFF 0000FFFF
	v_and_b32_e32 v15, 0xffff, v15                             // 0000004A7E34: 361E1EFF 0000FFFF
	v_and_b32_e32 v17, 0xffff, v17                             // 0000004A7E3C: 362222FF 0000FFFF
	v_and_b32_e32 v19, 0xffff, v19                             // 0000004A7E44: 362626FF 0000FFFF
	v_and_b32_e32 v20, 0xffff, v20                             // 0000004A7E4C: 362828FF 0000FFFF
	v_and_b32_e32 v22, 0xffff, v22                             // 0000004A7E54: 362C2CFF 0000FFFF
	v_lshl_or_b32 v9, v10, 16, v9                              // 0000004A7E5C: D6560009 0425210A
	v_lshl_or_b32 v10, v12, 16, v11                            // 0000004A7E64: D656000A 042D210C
	v_lshl_or_b32 v48, v49, 16, v48                            // 0000004A7E6C: D6560030 04C12131
	v_lshl_or_b32 v26, v26, 16, v50                            // 0000004A7E74: D656001A 04C9211A
	v_lshl_or_b32 v49, v65, 16, v64                            // 0000004A7E7C: D6560031 05012141
	v_lshl_or_b32 v27, v27, 16, v66                            // 0000004A7E84: D656001B 0509211B
	v_lshl_or_b32 v8, v67, 16, v8                              // 0000004A7E8C: D6560008 04212143
	v_lshl_or_b32 v28, v28, 16, v68                            // 0000004A7E94: D656001C 0511211C
	v_lshl_or_b32 v6, v23, 16, v6                              // 0000004A7E9C: D6560006 04192117
	v_lshl_or_b32 v23, v29, 16, v47                            // 0000004A7EA4: D6560017 04BD211D
	v_lshl_or_b32 v11, v14, 16, v13                            // 0000004A7EAC: D656000B 0435210E
	v_lshl_or_b32 v12, v16, 16, v15                            // 0000004A7EB4: D656000C 043D2110
	v_lshl_or_b32 v13, v18, 16, v17                            // 0000004A7EBC: D656000D 04452112
	v_lshl_or_b32 v7, v7, 16, v19                              // 0000004A7EC4: D6560007 044D2107
	v_lshl_or_b32 v14, v21, 16, v20                            // 0000004A7ECC: D656000E 04512115
	v_lshl_or_b32 v5, v5, 16, v22                              // 0000004A7ED4: D6560005 04592105
	v_pk_fma_f16 v9, v9, s3, 0xc931 op_sel_hi:[1,0,0]          // 0000004A7EDC: CC0E0009 0BFC0709 0000C931
	v_pk_fma_f16 v10, v10, s3, 0xc931 op_sel_hi:[1,0,0]        // 0000004A7EE8: CC0E000A 0BFC070A 0000C931
	v_pk_fma_f16 v29, v48, s3, 0xc931 op_sel_hi:[1,0,0]        // 0000004A7EF4: CC0E001D 0BFC0730 0000C931
	v_pk_fma_f16 v26, v26, s3, 0xc931 op_sel_hi:[1,0,0]        // 0000004A7F00: CC0E001A 0BFC071A 0000C931
	v_pk_fma_f16 v47, v49, s3, 0xc931 op_sel_hi:[1,0,0]        // 0000004A7F0C: CC0E002F 0BFC0731 0000C931
	v_pk_fma_f16 v27, v27, s3, 0xc931 op_sel_hi:[1,0,0]        // 0000004A7F18: CC0E001B 0BFC071B 0000C931
	v_pk_fma_f16 v8, v8, s3, 0xc931 op_sel_hi:[1,0,0]          // 0000004A7F24: CC0E0008 0BFC0708 0000C931
	v_pk_fma_f16 v28, v28, s3, 0xc931 op_sel_hi:[1,0,0]        // 0000004A7F30: CC0E001C 0BFC071C 0000C931
	v_pk_fma_f16 v6, v6, s3, 0xc931 op_sel_hi:[1,0,0]          // 0000004A7F3C: CC0E0006 0BFC0706 0000C931
	v_pk_fma_f16 v23, v23, s3, 0xc931 op_sel_hi:[1,0,0]        // 0000004A7F48: CC0E0017 0BFC0717 0000C931
	v_pk_fma_f16 v11, v11, s3, 0xc931 op_sel_hi:[1,0,0]        // 0000004A7F54: CC0E000B 0BFC070B 0000C931
	v_pk_fma_f16 v12, v12, s3, 0xc931 op_sel_hi:[1,0,0]        // 0000004A7F60: CC0E000C 0BFC070C 0000C931
	v_pk_fma_f16 v13, v13, s3, 0xc931 op_sel_hi:[1,0,0]        // 0000004A7F6C: CC0E000D 0BFC070D 0000C931
	v_pk_fma_f16 v7, v7, s3, 0xc931 op_sel_hi:[1,0,0]          // 0000004A7F78: CC0E0007 0BFC0707 0000C931
	v_pk_fma_f16 v14, v14, s3, 0xc931 op_sel_hi:[1,0,0]        // 0000004A7F84: CC0E000E 0BFC070E 0000C931
	v_pk_fma_f16 v5, v5, s3, 0xc931 op_sel_hi:[1,0,0]          // 0000004A7F90: CC0E0005 0BFC0705 0000C931
	v_cvt_f32_f16_e32 v48, v137/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004A7F9C: 7E601789
	v_cvt_f32_f16_e32 v9, v9                                   // 0000004A7FA0: 7E121709
	v_cvt_f32_f16_e32 v49, v138/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004A7FA4: 7E62178A
	v_cvt_f32_f16_e32 v10, v10                                 // 0000004A7FA8: 7E14170A
	v_cvt_f32_f16_e32 v16, v29                                 // 0000004A7FAC: 7E20171D
	v_cvt_f32_f16_e32 v15, v157/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004A7FB0: 7E1E179D
	v_cvt_f32_f16_e32 v17, v154/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004A7FB4: 7E22179A
	v_cvt_f32_f16_e32 v18, v26                                 // 0000004A7FB8: 7E24171A
	v_cvt_f32_f16_e32 v19, v175/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004A7FBC: 7E2617AF
	v_cvt_f32_f16_e32 v20, v47                                 // 0000004A7FC0: 7E28172F
	v_cvt_f32_f16_e32 v21, v155/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004A7FC4: 7E2A179B
	v_cvt_f32_f16_e32 v22, v27                                 // 0000004A7FC8: 7E2C171B
	v_cvt_f32_f16_e32 v26, v136/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004A7FCC: 7E341788
	v_cvt_f32_f16_e32 v8, v8                                   // 0000004A7FD0: 7E101708
	v_cvt_f32_f16_e32 v27, v156/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004A7FD4: 7E36179C
	v_cvt_f32_f16_e32 v28, v28                                 // 0000004A7FD8: 7E38171C
	v_cvt_f32_f16_e32 v29, v134/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004A7FDC: 7E3A1786
	v_cvt_f32_f16_e32 v6, v6                                   // 0000004A7FE0: 7E0C1706
	v_cvt_f32_f16_e32 v47, v151/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004A7FE4: 7E5E1797
	v_cvt_f32_f16_e32 v23, v23                                 // 0000004A7FE8: 7E2E1717
	v_cvt_f32_f16_e32 v50, v139/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004A7FEC: 7E64178B
	v_cvt_f32_f16_e32 v11, v11                                 // 0000004A7FF0: 7E16170B
	v_cvt_f32_f16_e32 v64, v140/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004A7FF4: 7E80178C
	v_cvt_f32_f16_e32 v12, v12                                 // 0000004A7FF8: 7E18170C
	v_cvt_f32_f16_e32 v65, v141/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004A7FFC: 7E82178D
	v_cvt_f32_f16_e32 v13, v13                                 // 0000004A8000: 7E1A170D
	v_cvt_f32_f16_e32 v66, v135/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004A8004: 7E841787
	v_cvt_f32_f16_e32 v7, v7                                   // 0000004A8008: 7E0E1707
	v_cvt_f32_f16_e32 v67, v142/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004A800C: 7E86178E
	v_cvt_f32_f16_e32 v14, v14                                 // 0000004A8010: 7E1C170E
	v_cvt_f32_f16_e32 v68, v133/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004A8014: 7E881785
	v_cvt_f32_f16_e32 v5, v5                                   // 0000004A8018: 7E0A1705
	ds_store_b32 v51, v9                                       // 0000004A801C: D8340000 00000933
	ds_store_b32 v46, v48                                      // 0000004A8024: D8340000 0000302E
	ds_store_b32 v52, v10                                      // 0000004A802C: D8340000 00000A34
	ds_store_b32 v53, v49                                      // 0000004A8034: D8340000 00003135
	ds_store_b32 v54, v16                                      // 0000004A803C: D8340000 00001036
	ds_store_b32 v55, v15                                      // 0000004A8044: D8340000 00000F37
	ds_store_b32 v56, v18                                      // 0000004A804C: D8340000 00001238
	ds_store_b32 v57, v17                                      // 0000004A8054: D8340000 00001139
	ds_store_b32 v58, v11                                      // 0000004A805C: D8340000 00000B3A
	ds_store_b32 v59, v50                                      // 0000004A8064: D8340000 0000323B
	ds_store_b32 v60, v12                                      // 0000004A806C: D8340000 00000C3C
	ds_store_b32 v61, v64                                      // 0000004A8074: D8340000 0000403D
	ds_store_b32 v24, v20                                      // 0000004A807C: D8340000 00001418
	ds_store_b32 v25, v19                                      // 0000004A8084: D8340000 00001319
	ds_store_b32 v30, v22                                      // 0000004A808C: D8340000 0000161E
	ds_store_b32 v31, v21                                      // 0000004A8094: D8340000 0000151F
	ds_store_b32 v38, v13                                      // 0000004A809C: D8340000 00000D26
	ds_store_b32 v62, v65                                      // 0000004A80A4: D8340000 0000413E
	ds_store_b32 v63, v7                                       // 0000004A80AC: D8340000 0000073F
	ds_store_b32 v34, v66                                      // 0000004A80B4: D8340000 00004222
	ds_store_b32 v35, v8                                       // 0000004A80BC: D8340000 00000823
	ds_store_b32 v36, v26                                      // 0000004A80C4: D8340000 00001A24
	ds_store_b32 v37, v28                                      // 0000004A80CC: D8340000 00001C25
	ds_store_b32 v32, v27                                      // 0000004A80D4: D8340000 00001B20
	ds_store_b32 v39, v14                                      // 0000004A80DC: D8340000 00000E27
	ds_store_b32 v40, v67                                      // 0000004A80E4: D8340000 00004328
	ds_store_b32 v41, v5                                       // 0000004A80EC: D8340000 00000529
	ds_store_b32 v42, v68                                      // 0000004A80F4: D8340000 0000442A
	ds_store_b32 v43, v6                                       // 0000004A80FC: D8340000 0000062B
	ds_store_b32 v44, v29                                      // 0000004A8104: D8340000 00001D2C
	ds_store_b32 v45, v23                                      // 0000004A810C: D8340000 0000172D
	ds_store_b32 v33, v47                                      // 0000004A8114: D8340000 00002F21
	s_waitcnt lgkmcnt(0)                                       // 0000004A811C: BF89FC07
	s_barrier                                                  // 0000004A8120: BFBD0000
	buffer_gl0_inv                                             // 0000004A8124: E0AC0000 00000000
	s_and_saveexec_b32 s3, s0                                  // 0000004A812C: BE832000
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000004A8130: BF870009
	s_xor_b32 s0, exec_lo, s3                                  // 0000004A8134: 8D00037E
	v_and_b32_e32 v2, 0x7f, v0                                 // 0000004A8138: 360400FF 0000007F
	s_or_saveexec_b32 s0, s0                                   // 0000004A8140: BE802200
	v_lshrrev_b32_e32 v11, 5, v0                               // 0000004A8144: 32160085
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004A8148: BF870001
	v_lshlrev_b32_e32 v12, 3, v11                              // 0000004A814C: 30181683
	s_xor_b32 exec_lo, exec_lo, s0                             // 0000004A8150: 8D7E007E
	s_cbranch_execz 437                                        // 0000004A8154: BFA501B5 <_ZN7halogen12_GLOBAL__N_113k_ht_deq_origILi4ELb1ELi16EEEvPKjiPKDF16_S5_Pti+0x132c>
	v_and_b32_e32 v0, 0x60, v0                                 // 0000004A8158: 360000FF 00000060
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004A8160: BF870112
	v_and_or_b32 v5, 0x60, v12, v4                             // 0000004A8164: D6570005 041218FF 00000060
	v_or_b32_e32 v6, 1, v0                                     // 0000004A8170: 380C0081
	v_or_b32_e32 v7, 2, v0                                     // 0000004A8174: 380E0082
	v_or_b32_e32 v8, 3, v0                                     // 0000004A8178: 38100083
	v_or_b32_e32 v9, 4, v0                                     // 0000004A817C: 38120084
	v_lshlrev_b32_e32 v5, 9, v5                                // 0000004A8180: 300A0A89
	v_or_b32_e32 v10, 5, v0                                    // 0000004A8184: 38140085
	v_or_b32_e32 v14, 6, v0                                    // 0000004A8188: 381C0086
	v_or_b32_e32 v15, 7, v0                                    // 0000004A818C: 381E0087
	v_xor_b32_e32 v6, v6, v4                                   // 0000004A8190: 3A0C0906
	v_xor_b32_e32 v7, v7, v4                                   // 0000004A8194: 3A0E0907
	v_xor_b32_e32 v8, v8, v4                                   // 0000004A8198: 3A100908
	v_xor_b32_e32 v9, v9, v4                                   // 0000004A819C: 3A120909
	v_lshl_or_b32 v13, v2, 2, v5                               // 0000004A81A0: D656000D 04150502
	v_xor_b32_e32 v10, v10, v4                                 // 0000004A81A8: 3A14090A
	v_xor_b32_e32 v14, v14, v4                                 // 0000004A81AC: 3A1C090E
	v_xor_b32_e32 v15, v15, v4                                 // 0000004A81B0: 3A1E090F
	v_lshl_or_b32 v6, v6, 2, v5                                // 0000004A81B4: D6560006 04150506
	v_lshl_or_b32 v7, v7, 2, v5                                // 0000004A81BC: D6560007 04150507
	v_lshl_or_b32 v8, v8, 2, v5                                // 0000004A81C4: D6560008 04150508
	v_lshl_or_b32 v9, v9, 2, v5                                // 0000004A81CC: D6560009 04150509
	v_lshl_or_b32 v10, v10, 2, v5                              // 0000004A81D4: D656000A 0415050A
	v_lshl_or_b32 v14, v14, 2, v5                              // 0000004A81DC: D656000E 0415050E
	v_lshl_or_b32 v15, v15, 2, v5                              // 0000004A81E4: D656000F 0415050F
	ds_load_b32 v20, v13                                       // 0000004A81EC: D8D80000 1400000D
	ds_load_b32 v21, v6                                        // 0000004A81F4: D8D80000 15000006
	ds_load_b32 v22, v7                                        // 0000004A81FC: D8D80000 16000007
	ds_load_b32 v23, v8                                        // 0000004A8204: D8D80000 17000008
	ds_load_b32 v24, v9                                        // 0000004A820C: D8D80000 18000009
	ds_load_b32 v25, v10                                       // 0000004A8214: D8D80000 1900000A
	ds_load_b32 v26, v14                                       // 0000004A821C: D8D80000 1A00000E
	ds_load_b32 v27, v15                                       // 0000004A8224: D8D80000 1B00000F
	s_waitcnt lgkmcnt(6)                                       // 0000004A822C: BF89FC67
	v_add_f32_e32 v70, v20, v21                                // 0000004A8230: 068C2B14
	s_waitcnt lgkmcnt(4)                                       // 0000004A8234: BF89FC47
	v_dual_sub_f32 v20, v20, v21 :: v_dual_add_f32 v21, v22, v23// 0000004A8238: C9482B14 14142F16
	v_or_b32_e32 v16, 8, v0                                    // 0000004A8240: 38200088
	v_or_b32_e32 v32, 16, v0                                   // 0000004A8244: 38400090
	v_or_b32_e32 v48, 24, v0                                   // 0000004A8248: 38600098
	v_or_b32_e32 v17, 9, v0                                    // 0000004A824C: 38220089
	v_or_b32_e32 v33, 17, v0                                   // 0000004A8250: 38420091
	v_or_b32_e32 v49, 25, v0                                   // 0000004A8254: 38620099
	v_or_b32_e32 v18, 10, v0                                   // 0000004A8258: 3824008A
	v_or_b32_e32 v34, 18, v0                                   // 0000004A825C: 38440092
	v_or_b32_e32 v50, 26, v0                                   // 0000004A8260: 3864009A
	v_or_b32_e32 v19, 11, v0                                   // 0000004A8264: 3826008B
	v_or_b32_e32 v43, 19, v0                                   // 0000004A8268: 38560093
	v_or_b32_e32 v59, 27, v0                                   // 0000004A826C: 3876009B
	v_or_b32_e32 v28, 12, v0                                   // 0000004A8270: 3838008C
	v_or_b32_e32 v44, 20, v0                                   // 0000004A8274: 38580094
	v_or_b32_e32 v60, 28, v0                                   // 0000004A8278: 3878009C
	v_xor_b32_e32 v16, v16, v4                                 // 0000004A827C: 3A200910
	v_or_b32_e32 v29, 13, v0                                   // 0000004A8280: 383A008D
	v_or_b32_e32 v30, 14, v0                                   // 0000004A8284: 383C008E
	v_or_b32_e32 v31, 15, v0                                   // 0000004A8288: 383E008F
	v_xor_b32_e32 v32, v32, v4                                 // 0000004A828C: 3A400920
	v_or_b32_e32 v45, 21, v0                                   // 0000004A8290: 385A0095
	v_or_b32_e32 v46, 22, v0                                   // 0000004A8294: 385C0096
	v_or_b32_e32 v47, 23, v0                                   // 0000004A8298: 385E0097
	v_xor_b32_e32 v48, v48, v4                                 // 0000004A829C: 3A600930
	v_or_b32_e32 v61, 29, v0                                   // 0000004A82A0: 387A009D
	v_or_b32_e32 v62, 30, v0                                   // 0000004A82A4: 387C009E
	v_or_b32_e32 v0, 31, v0                                    // 0000004A82A8: 3800009F
	v_xor_b32_e32 v17, v17, v4                                 // 0000004A82AC: 3A220911
	v_xor_b32_e32 v33, v33, v4                                 // 0000004A82B0: 3A420921
	v_xor_b32_e32 v49, v49, v4                                 // 0000004A82B4: 3A620931
	v_xor_b32_e32 v18, v18, v4                                 // 0000004A82B8: 3A240912
	v_xor_b32_e32 v34, v34, v4                                 // 0000004A82BC: 3A440922
	v_xor_b32_e32 v50, v50, v4                                 // 0000004A82C0: 3A640932
	v_xor_b32_e32 v19, v19, v4                                 // 0000004A82C4: 3A260913
	v_xor_b32_e32 v43, v43, v4                                 // 0000004A82C8: 3A56092B
	v_xor_b32_e32 v59, v59, v4                                 // 0000004A82CC: 3A76093B
	v_xor_b32_e32 v28, v28, v4                                 // 0000004A82D0: 3A38091C
	v_xor_b32_e32 v44, v44, v4                                 // 0000004A82D4: 3A58092C
	v_xor_b32_e32 v60, v60, v4                                 // 0000004A82D8: 3A78093C
	v_xor_b32_e32 v29, v29, v4                                 // 0000004A82DC: 3A3A091D
	v_xor_b32_e32 v30, v30, v4                                 // 0000004A82E0: 3A3C091E
	v_xor_b32_e32 v31, v31, v4                                 // 0000004A82E4: 3A3E091F
	v_xor_b32_e32 v45, v45, v4                                 // 0000004A82E8: 3A5A092D
	v_xor_b32_e32 v46, v46, v4                                 // 0000004A82EC: 3A5C092E
	v_xor_b32_e32 v47, v47, v4                                 // 0000004A82F0: 3A5E092F
	v_xor_b32_e32 v61, v61, v4                                 // 0000004A82F4: 3A7A093D
	v_xor_b32_e32 v62, v62, v4                                 // 0000004A82F8: 3A7C093E
	v_xor_b32_e32 v0, v0, v4                                   // 0000004A82FC: 3A000900
	v_sub_f32_e32 v22, v22, v23                                // 0000004A8300: 082C2F16
	v_lshl_or_b32 v16, v16, 2, v5                              // 0000004A8304: D6560010 04150510
	v_lshl_or_b32 v32, v32, 2, v5                              // 0000004A830C: D6560020 04150520
	v_lshl_or_b32 v48, v48, 2, v5                              // 0000004A8314: D6560030 04150530
	v_lshl_or_b32 v17, v17, 2, v5                              // 0000004A831C: D6560011 04150511
	v_lshl_or_b32 v33, v33, 2, v5                              // 0000004A8324: D6560021 04150521
	v_lshl_or_b32 v49, v49, 2, v5                              // 0000004A832C: D6560031 04150531
	v_lshl_or_b32 v18, v18, 2, v5                              // 0000004A8334: D6560012 04150512
	v_lshl_or_b32 v34, v34, 2, v5                              // 0000004A833C: D6560022 04150522
	v_lshl_or_b32 v50, v50, 2, v5                              // 0000004A8344: D6560032 04150532
	v_lshl_or_b32 v19, v19, 2, v5                              // 0000004A834C: D6560013 04150513
	v_lshl_or_b32 v43, v43, 2, v5                              // 0000004A8354: D656002B 0415052B
	v_lshl_or_b32 v59, v59, 2, v5                              // 0000004A835C: D656003B 0415053B
	v_lshl_or_b32 v28, v28, 2, v5                              // 0000004A8364: D656001C 0415051C
	v_lshl_or_b32 v44, v44, 2, v5                              // 0000004A836C: D656002C 0415052C
	v_lshl_or_b32 v60, v60, 2, v5                              // 0000004A8374: D656003C 0415053C
	v_lshl_or_b32 v29, v29, 2, v5                              // 0000004A837C: D656001D 0415051D
	v_lshl_or_b32 v30, v30, 2, v5                              // 0000004A8384: D656001E 0415051E
	v_lshl_or_b32 v31, v31, 2, v5                              // 0000004A838C: D656001F 0415051F
	ds_load_b32 v35, v16                                       // 0000004A8394: D8D80000 23000010
	ds_load_b32 v36, v17                                       // 0000004A839C: D8D80000 24000011
	ds_load_b32 v37, v18                                       // 0000004A83A4: D8D80000 25000012
	ds_load_b32 v38, v19                                       // 0000004A83AC: D8D80000 26000013
	ds_load_b32 v39, v28                                       // 0000004A83B4: D8D80000 2700001C
	ds_load_b32 v40, v29                                       // 0000004A83BC: D8D80000 2800001D
	ds_load_b32 v41, v30                                       // 0000004A83C4: D8D80000 2900001E
	ds_load_b32 v42, v31                                       // 0000004A83CC: D8D80000 2A00001F
	v_lshl_or_b32 v45, v45, 2, v5                              // 0000004A83D4: D656002D 0415052D
	v_lshl_or_b32 v46, v46, 2, v5                              // 0000004A83DC: D656002E 0415052E
	v_lshl_or_b32 v47, v47, 2, v5                              // 0000004A83E4: D656002F 0415052F
	ds_load_b32 v51, v32                                       // 0000004A83EC: D8D80000 33000020
	ds_load_b32 v52, v33                                       // 0000004A83F4: D8D80000 34000021
	ds_load_b32 v53, v34                                       // 0000004A83FC: D8D80000 35000022
	ds_load_b32 v54, v43                                       // 0000004A8404: D8D80000 3600002B
	ds_load_b32 v55, v44                                       // 0000004A840C: D8D80000 3700002C
	ds_load_b32 v56, v45                                       // 0000004A8414: D8D80000 3800002D
	ds_load_b32 v57, v46                                       // 0000004A841C: D8D80000 3900002E
	ds_load_b32 v58, v47                                       // 0000004A8424: D8D80000 3A00002F
	v_lshl_or_b32 v61, v61, 2, v5                              // 0000004A842C: D656003D 0415053D
	v_lshl_or_b32 v62, v62, 2, v5                              // 0000004A8434: D656003E 0415053E
	v_lshl_or_b32 v0, v0, 2, v5                                // 0000004A843C: D6560000 04150500
	ds_load_b32 v5, v48                                        // 0000004A8444: D8D80000 05000030
	ds_load_b32 v63, v49                                       // 0000004A844C: D8D80000 3F000031
	ds_load_b32 v64, v50                                       // 0000004A8454: D8D80000 40000032
	ds_load_b32 v65, v59                                       // 0000004A845C: D8D80000 4100003B
	ds_load_b32 v66, v60                                       // 0000004A8464: D8D80000 4200003C
	ds_load_b32 v67, v61                                       // 0000004A846C: D8D80000 4300003D
	ds_load_b32 v68, v62                                       // 0000004A8474: D8D80000 4400003E
	ds_load_b32 v69, v0                                        // 0000004A847C: D8D80000 45000000
	s_waitcnt lgkmcnt(26)                                      // 0000004A8484: BF89FDA7
	v_add_f32_e32 v23, v24, v25                                // 0000004A8488: 062E3318
	s_waitcnt lgkmcnt(24)                                      // 0000004A848C: BF89FD87
	v_dual_sub_f32 v24, v24, v25 :: v_dual_add_f32 v25, v26, v27// 0000004A8490: C9483318 1818371A
	s_waitcnt lgkmcnt(22)                                      // 0000004A8498: BF89FD67
	v_dual_sub_f32 v26, v26, v27 :: v_dual_add_f32 v27, v35, v36// 0000004A849C: C948371A 1A1A4923
	s_waitcnt lgkmcnt(20)                                      // 0000004A84A4: BF89FD47
	v_dual_sub_f32 v35, v35, v36 :: v_dual_add_f32 v36, v37, v38// 0000004A84A8: C9484923 23244D25
	s_waitcnt lgkmcnt(18)                                      // 0000004A84B0: BF89FD27
	v_dual_sub_f32 v37, v37, v38 :: v_dual_add_f32 v38, v39, v40// 0000004A84B4: C9484D25 25265127
	s_waitcnt lgkmcnt(16)                                      // 0000004A84BC: BF89FD07
	v_dual_sub_f32 v39, v39, v40 :: v_dual_add_f32 v40, v41, v42// 0000004A84C0: C9485127 27285529
	s_waitcnt lgkmcnt(14)                                      // 0000004A84C8: BF89FCE7
	v_dual_sub_f32 v41, v41, v42 :: v_dual_add_f32 v42, v51, v52// 0000004A84CC: C9485529 292A6933
	s_waitcnt lgkmcnt(12)                                      // 0000004A84D4: BF89FCC7
	v_dual_sub_f32 v51, v51, v52 :: v_dual_add_f32 v52, v53, v54// 0000004A84D8: C9486933 33346D35
	s_waitcnt lgkmcnt(10)                                      // 0000004A84E0: BF89FCA7
	v_dual_sub_f32 v53, v53, v54 :: v_dual_add_f32 v54, v55, v56// 0000004A84E4: C9486D35 35367137
	s_waitcnt lgkmcnt(8)                                       // 0000004A84EC: BF89FC87
	v_dual_sub_f32 v55, v55, v56 :: v_dual_add_f32 v56, v57, v58// 0000004A84F0: C9487137 37387539
	v_sub_f32_e32 v57, v57, v58                                // 0000004A84F8: 08727539
	s_waitcnt lgkmcnt(6)                                       // 0000004A84FC: BF89FC67
	v_add_f32_e32 v58, v5, v63                                 // 0000004A8500: 06747F05
	v_sub_f32_e32 v5, v5, v63                                  // 0000004A8504: 080A7F05
	s_waitcnt lgkmcnt(4)                                       // 0000004A8508: BF89FC47
	v_add_f32_e32 v63, v64, v65                                // 0000004A850C: 067E8340
	s_waitcnt lgkmcnt(2)                                       // 0000004A8510: BF89FC27
	v_dual_sub_f32 v64, v64, v65 :: v_dual_add_f32 v65, v66, v67// 0000004A8514: C9488340 40408742
	s_waitcnt lgkmcnt(0)                                       // 0000004A851C: BF89FC07
	v_dual_sub_f32 v66, v66, v67 :: v_dual_add_f32 v67, v68, v69// 0000004A8520: C9488742 42428B44
	v_sub_f32_e32 v68, v68, v69                                // 0000004A8528: 08888B44
	v_add_f32_e32 v69, v70, v21                                // 0000004A852C: 068A2B46
	v_dual_sub_f32 v21, v70, v21 :: v_dual_add_f32 v70, v20, v22// 0000004A8530: C9482B46 15462D14
	v_sub_f32_e32 v20, v20, v22                                // 0000004A8538: 08282D14
	v_add_f32_e32 v22, v23, v25                                // 0000004A853C: 062C3317
	v_sub_f32_e32 v23, v23, v25                                // 0000004A8540: 082E3317
	v_add_f32_e32 v25, v24, v26                                // 0000004A8544: 06323518
	v_sub_f32_e32 v24, v24, v26                                // 0000004A8548: 08303518
	v_add_f32_e32 v26, v27, v36                                // 0000004A854C: 0634491B
	v_sub_f32_e32 v27, v27, v36                                // 0000004A8550: 0836491B
	v_add_f32_e32 v36, v35, v37                                // 0000004A8554: 06484B23
	v_sub_f32_e32 v35, v35, v37                                // 0000004A8558: 08464B23
	v_add_f32_e32 v37, v38, v40                                // 0000004A855C: 064A5126
	v_sub_f32_e32 v38, v38, v40                                // 0000004A8560: 084C5126
	v_add_f32_e32 v40, v39, v41                                // 0000004A8564: 06505327
	v_sub_f32_e32 v39, v39, v41                                // 0000004A8568: 084E5327
	v_add_f32_e32 v41, v42, v52                                // 0000004A856C: 0652692A
	v_sub_f32_e32 v42, v42, v52                                // 0000004A8570: 0854692A
	v_add_f32_e32 v52, v51, v53                                // 0000004A8574: 06686B33
	v_sub_f32_e32 v51, v51, v53                                // 0000004A8578: 08666B33
	v_add_f32_e32 v53, v54, v56                                // 0000004A857C: 066A7136
	v_sub_f32_e32 v54, v54, v56                                // 0000004A8580: 086C7136
	v_add_f32_e32 v56, v55, v57                                // 0000004A8584: 06707337
	v_sub_f32_e32 v55, v55, v57                                // 0000004A8588: 086E7337
	v_add_f32_e32 v57, v58, v63                                // 0000004A858C: 06727F3A
	v_dual_sub_f32 v58, v58, v63 :: v_dual_add_f32 v63, v5, v64// 0000004A8590: C9487F3A 3A3E8105
	v_sub_f32_e32 v5, v5, v64                                  // 0000004A8598: 080A8105
	v_add_f32_e32 v64, v65, v67                                // 0000004A859C: 06808741
	v_sub_f32_e32 v65, v65, v67                                // 0000004A85A0: 08828741
	v_add_f32_e32 v67, v66, v68                                // 0000004A85A4: 06868942
	v_sub_f32_e32 v66, v66, v68                                // 0000004A85A8: 08848942
	v_add_f32_e32 v68, v69, v22                                // 0000004A85AC: 06882D45
	v_dual_sub_f32 v22, v69, v22 :: v_dual_add_f32 v69, v70, v25// 0000004A85B0: C9482D45 16443346
	v_dual_sub_f32 v25, v70, v25 :: v_dual_add_f32 v70, v21, v23// 0000004A85B8: C9483346 19462F15
	v_sub_f32_e32 v21, v21, v23                                // 0000004A85C0: 082A2F15
	v_add_f32_e32 v23, v20, v24                                // 0000004A85C4: 062E3114
	v_sub_f32_e32 v20, v20, v24                                // 0000004A85C8: 08283114
	v_add_f32_e32 v24, v26, v37                                // 0000004A85CC: 06304B1A
	v_dual_sub_f32 v26, v26, v37 :: v_dual_add_f32 v37, v36, v40// 0000004A85D0: C9484B1A 1A245124
	v_sub_f32_e32 v36, v36, v40                                // 0000004A85D8: 08485124
	v_add_f32_e32 v40, v27, v38                                // 0000004A85DC: 06504D1B
	v_sub_f32_e32 v27, v27, v38                                // 0000004A85E0: 08364D1B
	v_add_f32_e32 v38, v35, v39                                // 0000004A85E4: 064C4F23
	v_sub_f32_e32 v35, v35, v39                                // 0000004A85E8: 08464F23
	v_add_f32_e32 v39, v41, v53                                // 0000004A85EC: 064E6B29
	v_sub_f32_e32 v41, v41, v53                                // 0000004A85F0: 08526B29
	v_add_f32_e32 v53, v52, v56                                // 0000004A85F4: 066A7134
	v_sub_f32_e32 v52, v52, v56                                // 0000004A85F8: 08687134
	v_add_f32_e32 v56, v42, v54                                // 0000004A85FC: 06706D2A
	v_sub_f32_e32 v42, v42, v54                                // 0000004A8600: 08546D2A
	v_add_f32_e32 v54, v51, v55                                // 0000004A8604: 066C6F33
	v_sub_f32_e32 v51, v51, v55                                // 0000004A8608: 08666F33
	v_add_f32_e32 v55, v57, v64                                // 0000004A860C: 066E8139
	v_dual_sub_f32 v57, v57, v64 :: v_dual_add_f32 v64, v63, v67// 0000004A8610: C9488139 3940873F
	v_sub_f32_e32 v63, v63, v67                                // 0000004A8618: 087E873F
	v_add_f32_e32 v67, v58, v65                                // 0000004A861C: 0686833A
	v_dual_sub_f32 v58, v58, v65 :: v_dual_add_f32 v65, v5, v66// 0000004A8620: C948833A 3A408505
	v_dual_sub_f32 v5, v5, v66 :: v_dual_add_f32 v66, v68, v24 // 0000004A8628: C9488505 05423144
	v_sub_f32_e32 v24, v68, v24                                // 0000004A8630: 08303144
	v_add_f32_e32 v68, v69, v37                                // 0000004A8634: 06884B45
	v_sub_f32_e32 v37, v69, v37                                // 0000004A8638: 084A4B45
	v_add_f32_e32 v69, v70, v40                                // 0000004A863C: 068A5146
	v_sub_f32_e32 v40, v70, v40                                // 0000004A8640: 08505146
	v_add_f32_e32 v70, v23, v38                                // 0000004A8644: 068C4D17
	v_sub_f32_e32 v23, v23, v38                                // 0000004A8648: 082E4D17
	v_add_f32_e32 v38, v22, v26                                // 0000004A864C: 064C3516
	v_sub_f32_e32 v22, v22, v26                                // 0000004A8650: 082C3516
	v_add_f32_e32 v26, v25, v36                                // 0000004A8654: 06344919
	v_sub_f32_e32 v25, v25, v36                                // 0000004A8658: 08324919
	v_add_f32_e32 v36, v21, v27                                // 0000004A865C: 06483715
	v_sub_f32_e32 v21, v21, v27                                // 0000004A8660: 082A3715
	v_add_f32_e32 v27, v20, v35                                // 0000004A8664: 06364714
	v_sub_f32_e32 v20, v20, v35                                // 0000004A8668: 08284714
	v_add_f32_e32 v35, v39, v55                                // 0000004A866C: 06466F27
	v_sub_f32_e32 v39, v39, v55                                // 0000004A8670: 084E6F27
	v_add_f32_e32 v55, v53, v64                                // 0000004A8674: 066E8135
	v_dual_sub_f32 v53, v53, v64 :: v_dual_add_f32 v64, v56, v67// 0000004A8678: C9488135 35408738
	v_dual_sub_f32 v56, v56, v67 :: v_dual_add_f32 v67, v54, v65// 0000004A8680: C9488738 38428336
	v_sub_f32_e32 v54, v54, v65                                // 0000004A8688: 086C8336
	v_add_f32_e32 v65, v41, v57                                // 0000004A868C: 06827329
	v_sub_f32_e32 v41, v41, v57                                // 0000004A8690: 08527329
	v_add_f32_e32 v57, v52, v63                                // 0000004A8694: 06727F34
	v_dual_sub_f32 v52, v52, v63 :: v_dual_add_f32 v63, v42, v58// 0000004A8698: C9487F34 343E752A
	v_sub_f32_e32 v42, v42, v58                                // 0000004A86A0: 0854752A
	v_add_f32_e32 v58, v51, v5                                 // 0000004A86A4: 06740B33
	v_sub_f32_e32 v5, v51, v5                                  // 0000004A86A8: 080A0B33
	v_add_f32_e32 v51, v66, v35                                // 0000004A86AC: 06664742
	v_sub_f32_e32 v35, v66, v35                                // 0000004A86B0: 08464742
	v_add_f32_e32 v66, v68, v55                                // 0000004A86B4: 06846F44
	v_dual_sub_f32 v55, v68, v55 :: v_dual_add_f32 v68, v69, v64// 0000004A86B8: C9486F44 37448145
	v_dual_sub_f32 v64, v69, v64 :: v_dual_add_f32 v69, v70, v67// 0000004A86C0: C9488145 40448746
	v_sub_f32_e32 v67, v70, v67                                // 0000004A86C8: 08868746
	v_add_f32_e32 v70, v38, v65                                // 0000004A86CC: 068C8326
	v_sub_f32_e32 v38, v38, v65                                // 0000004A86D0: 084C8326
	v_add_f32_e32 v65, v26, v57                                // 0000004A86D4: 0682731A
	v_dual_sub_f32 v26, v26, v57 :: v_dual_add_f32 v57, v36, v63// 0000004A86D8: C948731A 1A387F24
	v_dual_sub_f32 v36, v36, v63 :: v_dual_add_f32 v63, v27, v58// 0000004A86E0: C9487F24 243E751B
	v_dual_sub_f32 v27, v27, v58 :: v_dual_add_f32 v58, v24, v39// 0000004A86E8: C948751B 1B3A4F18
	v_dual_sub_f32 v24, v24, v39 :: v_dual_add_f32 v39, v37, v53// 0000004A86F0: C9484F18 18266B25
	v_sub_f32_e32 v37, v37, v53                                // 0000004A86F8: 084A6B25
	v_add_f32_e32 v53, v40, v56                                // 0000004A86FC: 066A7128
	v_sub_f32_e32 v40, v40, v56                                // 0000004A8700: 08507128
	v_add_f32_e32 v56, v23, v54                                // 0000004A8704: 06706D17
	v_dual_sub_f32 v23, v23, v54 :: v_dual_add_f32 v54, v22, v41// 0000004A8708: C9486D17 17365316
	v_dual_sub_f32 v22, v22, v41 :: v_dual_add_f32 v41, v25, v52// 0000004A8710: C9485316 16286919
	v_sub_f32_e32 v25, v25, v52                                // 0000004A8718: 08326919
	v_add_f32_e32 v52, v21, v42                                // 0000004A871C: 06685515
	v_dual_sub_f32 v21, v21, v42 :: v_dual_add_f32 v42, v20, v5// 0000004A8720: C9485515 152A0B14
	v_sub_f32_e32 v5, v20, v5                                  // 0000004A8728: 080A0B14
	ds_store_b32 v13, v51                                      // 0000004A872C: D8340000 0000330D
	ds_store_b32 v6, v66                                       // 0000004A8734: D8340000 00004206
	ds_store_b32 v7, v68                                       // 0000004A873C: D8340000 00004407
	ds_store_b32 v8, v69                                       // 0000004A8744: D8340000 00004508
	ds_store_b32 v9, v70                                       // 0000004A874C: D8340000 00004609
	ds_store_b32 v10, v65                                      // 0000004A8754: D8340000 0000410A
	ds_store_b32 v14, v57                                      // 0000004A875C: D8340000 0000390E
	ds_store_b32 v15, v63                                      // 0000004A8764: D8340000 00003F0F
	ds_store_b32 v16, v58                                      // 0000004A876C: D8340000 00003A10
	ds_store_b32 v17, v39                                      // 0000004A8774: D8340000 00002711
	ds_store_b32 v18, v53                                      // 0000004A877C: D8340000 00003512
	ds_store_b32 v19, v56                                      // 0000004A8784: D8340000 00003813
	ds_store_b32 v28, v54                                      // 0000004A878C: D8340000 0000361C
	ds_store_b32 v29, v41                                      // 0000004A8794: D8340000 0000291D
	ds_store_b32 v30, v52                                      // 0000004A879C: D8340000 0000341E
	ds_store_b32 v31, v42                                      // 0000004A87A4: D8340000 00002A1F
	ds_store_b32 v32, v35                                      // 0000004A87AC: D8340000 00002320
	ds_store_b32 v33, v55                                      // 0000004A87B4: D8340000 00003721
	ds_store_b32 v34, v64                                      // 0000004A87BC: D8340000 00004022
	ds_store_b32 v43, v67                                      // 0000004A87C4: D8340000 0000432B
	ds_store_b32 v44, v38                                      // 0000004A87CC: D8340000 0000262C
	ds_store_b32 v45, v26                                      // 0000004A87D4: D8340000 00001A2D
	ds_store_b32 v46, v36                                      // 0000004A87DC: D8340000 0000242E
	ds_store_b32 v47, v27                                      // 0000004A87E4: D8340000 00001B2F
	ds_store_b32 v48, v24                                      // 0000004A87EC: D8340000 00001830
	ds_store_b32 v49, v37                                      // 0000004A87F4: D8340000 00002531
	ds_store_b32 v50, v40                                      // 0000004A87FC: D8340000 00002832
	ds_store_b32 v59, v23                                      // 0000004A8804: D8340000 0000173B
	ds_store_b32 v60, v22                                      // 0000004A880C: D8340000 0000163C
	ds_store_b32 v61, v25                                      // 0000004A8814: D8340000 0000193D
	ds_store_b32 v62, v21                                      // 0000004A881C: D8340000 0000153E
	ds_store_b32 v0, v5                                        // 0000004A8824: D8340000 00000500
	s_or_b32 exec_lo, exec_lo, s0                              // 0000004A882C: 8C7E007E
	v_or_b32_e32 v0, 32, v3                                    // 0000004A8830: 380006A0
	v_or_b32_e32 v5, 64, v3                                    // 0000004A8834: 380A06C0
	v_or_b32_e32 v6, 0x60, v3                                  // 0000004A8838: 380C06FF 00000060
	v_lshlrev_b32_e32 v14, 9, v2                               // 0000004A8840: 301C0489
	v_xor_b32_e32 v7, v3, v4                                   // 0000004A8844: 3A0E0903
	v_xor_b32_e32 v0, v0, v4                                   // 0000004A8848: 3A000900
	v_xor_b32_e32 v5, v5, v4                                   // 0000004A884C: 3A0A0905
	v_xor_b32_e32 v6, v6, v4                                   // 0000004A8850: 3A0C0906
	s_waitcnt lgkmcnt(0)                                       // 0000004A8854: BF89FC07
	v_lshl_or_b32 v13, v7, 2, v14                              // 0000004A8858: D656000D 04390507
	v_lshl_or_b32 v0, v0, 2, v14                               // 0000004A8860: D6560000 04390500
	v_lshl_or_b32 v5, v5, 2, v14                               // 0000004A8868: D6560005 04390505
	v_lshl_or_b32 v6, v6, 2, v14                               // 0000004A8870: D6560006 04390506
	s_barrier                                                  // 0000004A8878: BFBD0000
	buffer_gl0_inv                                             // 0000004A887C: E0AC0000 00000000
	ds_load_b32 v7, v13                                        // 0000004A8884: D8D80000 0700000D
	ds_load_b32 v8, v0                                         // 0000004A888C: D8D80000 08000000
	ds_load_b32 v9, v5                                         // 0000004A8894: D8D80000 09000005
	ds_load_b32 v15, v6                                        // 0000004A889C: D8D80000 0F000006
	v_or_b32_e32 v10, 4, v3                                    // 0000004A88A4: 38140684
	v_cvt_f32_f16_e32 v17, v129/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000004A88A8: 7E221781
	v_or_b32_e32 v18, 36, v3                                   // 0000004A88AC: 382406A4
	v_or_b32_e32 v19, 0x44, v3                                 // 0000004A88B0: 382606FF 00000044
	v_or_b32_e32 v20, 0x64, v3                                 // 0000004A88B8: 382806FF 00000064
	v_xor_b32_e32 v16, v10, v4                                 // 0000004A88C0: 3A20090A
	.long 0xd7600000                                           // 0000004A88C4: D7600000
	v_cndmask_b32_e32 v0, v17, v136, vcc_lo                    // 0000004A88C8: 02011111
	.long 0xd7600003                                           // 0000004A88CC: D7600003
	v_cndmask_b32_e32 v0, v17, v144, vcc_lo                    // 0000004A88D0: 02012111
	.long 0xd7600004                                           // 0000004A88D4: D7600004
	v_cndmask_b32_e32 v0, v17, v152, vcc_lo                    // 0000004A88D8: 02013111
	v_xor_b32_e32 v20, v20, v4                                 // 0000004A88DC: 3A280914
	.long 0xd7600005                                           // 0000004A88E0: D7600005
	v_cndmask_b32_e32 v0, v17, v153, vcc_lo                    // 0000004A88E4: 02013311
	.long 0xd7600006                                           // 0000004A88E8: D7600006
	v_cndmask_b32_e32 v0, v17, v159, vcc_lo                    // 0000004A88EC: 02013F11
	s_waitcnt lgkmcnt(2)                                       // 0000004A88F0: BF89FC27
	v_add_f32_e32 v22, v7, v8                                  // 0000004A88F4: 062C1107
	s_waitcnt lgkmcnt(0)                                       // 0000004A88F8: BF89FC07
	v_dual_sub_f32 v7, v7, v8 :: v_dual_sub_f32 v8, v9, v15    // 0000004A88FC: C94A1107 07081F09
	v_lshl_or_b32 v16, v16, 2, v14                             // 0000004A8904: D6560010 04390510
	v_add_f32_e32 v15, v9, v15                                 // 0000004A890C: 061E1F09
	v_lshl_or_b32 v20, v20, 2, v14                             // 0000004A8910: D6560014 04390514
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004A8918: BF870004
	v_add_f32_e32 v9, v7, v8                                   // 0000004A891C: 06121107
	ds_load_b32 v21, v16                                       // 0000004A8920: D8D80000 15000010
	v_sub_f32_e32 v23, v22, v15                                // 0000004A8928: 082E1F16
	v_add_f32_e32 v15, v22, v15                                // 0000004A892C: 061E1F16
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 0000004A8930: 101212FF 3DB504F3
	v_sub_f32_e32 v7, v7, v8                                   // 0000004A8938: 080E1107
	v_xor_b32_e32 v8, v18, v4                                  // 0000004A893C: 3A100912
	v_xor_b32_e32 v18, v19, v4                                 // 0000004A8940: 3A240913
	v_mul_f32_e32 v19, 0x3db504f3, v23                         // 0000004A8944: 10262EFF 3DB504F3
	v_mul_f32_e32 v9, s0, v9                                   // 0000004A894C: 10121200
	v_mul_f32_e32 v7, 0x3db504f3, v7                           // 0000004A8950: 100E0EFF 3DB504F3
	v_lshl_or_b32 v8, v8, 2, v14                               // 0000004A8958: D6560008 04390508
	v_lshl_or_b32 v18, v18, 2, v14                             // 0000004A8960: D6560012 04390512
	v_mul_f32_e32 v19, s3, v19                                 // 0000004A8968: 10262603
	v_or_b32_e32 v23, 0x68, v3                                 // 0000004A896C: 382E06FF 00000068
	v_mul_f32_e32 v7, s4, v7                                   // 0000004A8974: 100E0E04
	ds_store_b32 v0, v9                                        // 0000004A8978: D8340000 00000900
	ds_store_b32 v5, v19                                       // 0000004A8980: D8340000 00001305
	ds_store_b32 v6, v7                                        // 0000004A8988: D8340000 00000706
	ds_load_b32 v0, v8                                         // 0000004A8990: D8D80000 00000008
	ds_load_b32 v5, v18                                        // 0000004A8998: D8D80000 05000012
	ds_load_b32 v6, v20                                        // 0000004A89A0: D8D80000 06000014
	v_or_b32_e32 v9, 8, v3                                     // 0000004A89A8: 38120688
	v_or_b32_e32 v7, 40, v3                                    // 0000004A89AC: 380E06A8
	v_or_b32_e32 v19, 0x48, v3                                 // 0000004A89B0: 382606FF 00000048
	.long 0xd7600000                                           // 0000004A89B8: D7600000
	v_cndmask_b32_e32 v0, v17, v129, vcc_lo                    // 0000004A89BC: 02010311
	.long 0xd7600003                                           // 0000004A89C0: D7600003
	v_cndmask_b32_e32 v0, v17, v137, vcc_lo                    // 0000004A89C4: 02011311
	v_xor_b32_e32 v24, v9, v4                                  // 0000004A89C8: 3A300909
	v_xor_b32_e32 v7, v7, v4                                   // 0000004A89CC: 3A0E0907
	.long 0xd7600004                                           // 0000004A89D0: D7600004
	v_cndmask_b32_e32 v0, v17, v145, vcc_lo                    // 0000004A89D4: 02012311
	v_mul_f32_e32 v15, 0x3db504f3, v15                         // 0000004A89D8: 101E1EFF 3DB504F3
	s_waitcnt lgkmcnt(2)                                       // 0000004A89E0: BF89FC27
	v_add_f32_e32 v25, v21, v0                                 // 0000004A89E4: 06320115
	v_sub_f32_e32 v0, v21, v0                                  // 0000004A89E8: 08000115
	s_waitcnt lgkmcnt(0)                                       // 0000004A89EC: BF89FC07
	v_add_f32_e32 v21, v5, v6                                  // 0000004A89F0: 062A0D05
	v_sub_f32_e32 v5, v5, v6                                   // 0000004A89F4: 080A0D05
	v_xor_b32_e32 v6, v19, v4                                  // 0000004A89F8: 3A0C0913
	v_xor_b32_e32 v19, v23, v4                                 // 0000004A89FC: 3A260917
	v_lshl_or_b32 v23, v24, 2, v14                             // 0000004A8A00: D6560017 04390518
	v_add_f32_e32 v24, v25, v21                                // 0000004A8A08: 06302B19
	v_add_f32_e32 v26, v0, v5                                  // 0000004A8A0C: 06340B00
	v_sub_f32_e32 v21, v25, v21                                // 0000004A8A10: 082A2B19
	v_sub_f32_e32 v0, v0, v5                                   // 0000004A8A14: 08000B00
	v_lshl_or_b32 v5, v7, 2, v14                               // 0000004A8A18: D6560005 04390507
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004A8A20: BF870194
	v_dual_mul_f32 v7, 0x3db504f3, v24 :: v_dual_mul_f32 v24, 0x3db504f3, v26// 0000004A8A24: C8C630FF 071834FF 3DB504F3
	v_dual_mul_f32 v21, 0x3db504f3, v21 :: v_dual_mul_f32 v0, 0x3db504f3, v0// 0000004A8A30: C8C62AFF 150000FF 3DB504F3
	v_lshl_or_b32 v6, v6, 2, v14                               // 0000004A8A3C: D6560006 04390506
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000004A8A44: BF870223
	v_dual_mul_f32 v7, s0, v7 :: v_dual_mul_f32 v24, s3, v24   // 0000004A8A48: C8C60E00 07183003
	v_lshl_or_b32 v19, v19, 2, v14                             // 0000004A8A50: D6560013 04390513
	v_mul_f32_e32 v0, s5, v0                                   // 0000004A8A58: 10000005
	.long 0xd7600005                                           // 0000004A8A5C: D7600005
	v_cndmask_b32_e32 v0, v17, v154, vcc_lo                    // 0000004A8A60: 02013511
	v_mul_f32_e32 v21, s4, v21                                 // 0000004A8A64: 102A2A04
	ds_store_b32 v16, v7                                       // 0000004A8A68: D8340000 00000710
	ds_store_b32 v8, v24                                       // 0000004A8A70: D8340000 00001808
	ds_store_b32 v18, v21                                      // 0000004A8A78: D8340000 00001512
	ds_store_b32 v20, v0                                       // 0000004A8A80: D8340000 00000014
	ds_load_b32 v0, v23                                        // 0000004A8A88: D8D80000 00000017
	ds_load_b32 v7, v5                                         // 0000004A8A90: D8D80000 07000005
	ds_load_b32 v16, v6                                        // 0000004A8A98: D8D80000 10000006
	ds_load_b32 v18, v19                                       // 0000004A8AA0: D8D80000 12000013
	v_or_b32_e32 v8, 12, v3                                    // 0000004A8AA8: 3810068C
	v_or_b32_e32 v20, 44, v3                                   // 0000004A8AAC: 382806AC
	v_or_b32_e32 v21, 0x4c, v3                                 // 0000004A8AB0: 382A06FF 0000004C
	v_or_b32_e32 v24, 0x6c, v3                                 // 0000004A8AB8: 383006FF 0000006C
	.long 0xd7600000                                           // 0000004A8AC0: D7600000
	v_cndmask_b32_e32 v0, v17, v130, vcc_lo                    // 0000004A8AC4: 02010511
	v_xor_b32_e32 v25, v8, v4                                  // 0000004A8AC8: 3A320908
	v_xor_b32_e32 v20, v20, v4                                 // 0000004A8ACC: 3A280914
	.long 0xd7600003                                           // 0000004A8AD0: D7600003
	v_cndmask_b32_e32 v0, v17, v138, vcc_lo                    // 0000004A8AD4: 02011511
	.long 0xd7600004                                           // 0000004A8AD8: D7600004
	v_cndmask_b32_e32 v0, v17, v146, vcc_lo                    // 0000004A8ADC: 02012511
	s_waitcnt lgkmcnt(2)                                       // 0000004A8AE0: BF89FC27
	v_add_f32_e32 v26, v0, v7                                  // 0000004A8AE4: 06340F00
	v_sub_f32_e32 v0, v0, v7                                   // 0000004A8AE8: 08000F00
	s_waitcnt lgkmcnt(0)                                       // 0000004A8AEC: BF89FC07
	v_add_f32_e32 v7, v16, v18                                 // 0000004A8AF0: 060E2510
	v_sub_f32_e32 v16, v16, v18                                // 0000004A8AF4: 08202510
	v_xor_b32_e32 v18, v21, v4                                 // 0000004A8AF8: 3A240915
	v_xor_b32_e32 v21, v24, v4                                 // 0000004A8AFC: 3A2A0918
	v_lshl_or_b32 v24, v25, 2, v14                             // 0000004A8B00: D6560018 04390519
	v_add_f32_e32 v25, v26, v7                                 // 0000004A8B08: 06320F1A
	v_add_f32_e32 v27, v0, v16                                 // 0000004A8B0C: 06362100
	v_dual_sub_f32 v7, v26, v7 :: v_dual_sub_f32 v0, v0, v16   // 0000004A8B10: C94A0F1A 07002100
	v_lshl_or_b32 v16, v20, 2, v14                             // 0000004A8B18: D6560010 04390514
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004A8B20: BF870193
	v_dual_mul_f32 v20, 0x3db504f3, v25 :: v_dual_mul_f32 v25, 0x3db504f3, v27// 0000004A8B24: C8C632FF 141836FF 3DB504F3
	v_dual_mul_f32 v7, 0x3db504f3, v7 :: v_dual_mul_f32 v0, 0x3db504f3, v0// 0000004A8B30: C8C60EFF 070000FF 3DB504F3
	v_lshl_or_b32 v18, v18, 2, v14                             // 0000004A8B3C: D6560012 04390512
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004A8B44: BF870193
	v_dual_mul_f32 v20, s0, v20 :: v_dual_mul_f32 v25, s3, v25 // 0000004A8B48: C8C62800 14183203
	v_dual_mul_f32 v7, s4, v7 :: v_dual_mul_f32 v0, s5, v0     // 0000004A8B50: C8C60E04 07000005
	v_lshl_or_b32 v21, v21, 2, v14                             // 0000004A8B58: D6560015 04390515
	ds_store_b32 v23, v20                                      // 0000004A8B60: D8340000 00001417
	ds_store_b32 v5, v25                                       // 0000004A8B68: D8340000 00001905
	ds_store_b32 v6, v7                                        // 0000004A8B70: D8340000 00000706
	ds_store_b32 v19, v0                                       // 0000004A8B78: D8340000 00000013
	ds_load_b32 v0, v24                                        // 0000004A8B80: D8D80000 00000018
	ds_load_b32 v5, v16                                        // 0000004A8B88: D8D80000 05000010
	ds_load_b32 v6, v18                                        // 0000004A8B90: D8D80000 06000012
	ds_load_b32 v19, v21                                       // 0000004A8B98: D8D80000 13000015
	v_or_b32_e32 v7, 16, v3                                    // 0000004A8BA0: 380E0690
	v_or_b32_e32 v23, 0x50, v3                                 // 0000004A8BA4: 382E06FF 00000050
	v_or_b32_e32 v25, 0x70, v3                                 // 0000004A8BAC: 383206FF 00000070
	.long 0xd7600000                                           // 0000004A8BB4: D7600000
	v_cndmask_b32_e32 v0, v17, v131, vcc_lo                    // 0000004A8BB8: 02010711
	.long 0xd7600003                                           // 0000004A8BBC: D7600003
	v_cndmask_b32_e32 v0, v17, v139, vcc_lo                    // 0000004A8BC0: 02011711
	v_xor_b32_e32 v26, v7, v4                                  // 0000004A8BC4: 3A340907
	v_or_b32_e32 v20, 48, v3                                   // 0000004A8BC8: 382806B0
	.long 0xd7600005                                           // 0000004A8BCC: D7600005
	v_cndmask_b32_e32 v0, v17, v155, vcc_lo                    // 0000004A8BD0: 02013711
	.long 0xd7600004                                           // 0000004A8BD4: D7600004
	v_cndmask_b32_e32 v0, v17, v147, vcc_lo                    // 0000004A8BD8: 02012711
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004A8BDC: BF870093
	v_xor_b32_e32 v20, v20, v4                                 // 0000004A8BE0: 3A280914
	v_lshl_or_b32 v20, v20, 2, v14                             // 0000004A8BE4: D6560014 04390514
	s_waitcnt lgkmcnt(2)                                       // 0000004A8BEC: BF89FC27
	v_add_f32_e32 v27, v0, v5                                  // 0000004A8BF0: 06360B00
	s_waitcnt lgkmcnt(0)                                       // 0000004A8BF4: BF89FC07
	v_dual_sub_f32 v0, v0, v5 :: v_dual_add_f32 v5, v6, v19    // 0000004A8BF8: C9480B00 00042706
	v_sub_f32_e32 v6, v6, v19                                  // 0000004A8C00: 080C2706
	v_xor_b32_e32 v19, v23, v4                                 // 0000004A8C04: 3A260917
	v_xor_b32_e32 v23, v25, v4                                 // 0000004A8C08: 3A2E0919
	v_lshl_or_b32 v25, v26, 2, v14                             // 0000004A8C0C: D6560019 0439051A
	v_add_f32_e32 v26, v27, v5                                 // 0000004A8C14: 06340B1B
	v_add_f32_e32 v28, v0, v6                                  // 0000004A8C18: 06380D00
	v_sub_f32_e32 v0, v0, v6                                   // 0000004A8C1C: 08000D00
	v_lshl_or_b32 v19, v19, 2, v14                             // 0000004A8C20: D6560013 04390513
	v_lshl_or_b32 v23, v23, 2, v14                             // 0000004A8C28: D6560017 04390517
	v_mul_f32_e32 v6, 0x3db504f3, v26                          // 0000004A8C30: 100C34FF 3DB504F3
	v_mul_f32_e32 v26, 0x3db504f3, v28                         // 0000004A8C38: 103438FF 3DB504F3
	v_mul_f32_e32 v0, 0x3db504f3, v0                           // 0000004A8C40: 100000FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004A8C48: BF870193
	v_mul_f32_e32 v6, s0, v6                                   // 0000004A8C4C: 100C0C00
	v_dual_mul_f32 v26, s3, v26 :: v_dual_sub_f32 v5, v27, v5  // 0000004A8C50: C8CA3403 1A040B1B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000004A8C58: BF8700D3
	v_mul_f32_e32 v0, s5, v0                                   // 0000004A8C5C: 10000005
	.long 0xd7600003                                           // 0000004A8C60: D7600003
	v_cndmask_b32_e32 v0, v17, v140, vcc_lo                    // 0000004A8C64: 02011911
	.long 0xd7600005                                           // 0000004A8C68: D7600005
	v_cndmask_b32_e32 v0, v17, v156, vcc_lo                    // 0000004A8C6C: 02013911
	.long 0xd7600000                                           // 0000004A8C70: D7600000
	v_cndmask_b32_e32 v0, v17, v132, vcc_lo                    // 0000004A8C74: 02010911
	v_mul_f32_e32 v5, 0x3db504f3, v5                           // 0000004A8C78: 100A0AFF 3DB504F3
	v_mul_f32_e32 v5, s4, v5                                   // 0000004A8C80: 100A0A04
	ds_store_b32 v24, v6                                       // 0000004A8C84: D8340000 00000618
	ds_store_b32 v16, v26                                      // 0000004A8C8C: D8340000 00001A10
	ds_store_b32 v18, v5                                       // 0000004A8C94: D8340000 00000512
	ds_store_b32 v21, v0                                       // 0000004A8C9C: D8340000 00000015
	ds_load_b32 v0, v25                                        // 0000004A8CA4: D8D80000 00000019
	ds_load_b32 v5, v20                                        // 0000004A8CAC: D8D80000 05000014
	ds_load_b32 v16, v19                                       // 0000004A8CB4: D8D80000 10000013
	ds_load_b32 v18, v23                                       // 0000004A8CBC: D8D80000 12000017
	v_or_b32_e32 v6, 20, v3                                    // 0000004A8CC4: 380C0694
	v_or_b32_e32 v21, 52, v3                                   // 0000004A8CC8: 382A06B4
	v_or_b32_e32 v24, 0x54, v3                                 // 0000004A8CCC: 383006FF 00000054
	v_or_b32_e32 v26, 0x74, v3                                 // 0000004A8CD4: 383406FF 00000074
	.long 0xd7600004                                           // 0000004A8CDC: D7600004
	v_cndmask_b32_e32 v0, v17, v148, vcc_lo                    // 0000004A8CE0: 02012911
	v_xor_b32_e32 v27, v6, v4                                  // 0000004A8CE4: 3A360906
	v_xor_b32_e32 v21, v21, v4                                 // 0000004A8CE8: 3A2A0915
	s_waitcnt lgkmcnt(2)                                       // 0000004A8CEC: BF89FC27
	v_add_f32_e32 v28, v0, v5                                  // 0000004A8CF0: 06380B00
	v_sub_f32_e32 v0, v0, v5                                   // 0000004A8CF4: 08000B00
	s_waitcnt lgkmcnt(0)                                       // 0000004A8CF8: BF89FC07
	v_add_f32_e32 v5, v16, v18                                 // 0000004A8CFC: 060A2510
	v_sub_f32_e32 v16, v16, v18                                // 0000004A8D00: 08202510
	v_xor_b32_e32 v18, v24, v4                                 // 0000004A8D04: 3A240918
	v_xor_b32_e32 v24, v26, v4                                 // 0000004A8D08: 3A30091A
	v_lshl_or_b32 v26, v27, 2, v14                             // 0000004A8D0C: D656001A 0439051B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000004A8D14: BF870254
	v_add_f32_e32 v29, v0, v16                                 // 0000004A8D18: 063A2100
	v_sub_f32_e32 v0, v0, v16                                  // 0000004A8D1C: 08002100
	v_lshl_or_b32 v16, v21, 2, v14                             // 0000004A8D20: D6560010 04390515
	v_lshl_or_b32 v18, v18, 2, v14                             // 0000004A8D28: D6560012 04390512
	v_lshl_or_b32 v24, v24, 2, v14                             // 0000004A8D30: D6560018 04390518
	v_dual_mul_f32 v0, 0x3db504f3, v0 :: v_dual_add_f32 v27, v28, v5// 0000004A8D38: C8C800FF 001A0B1C 3DB504F3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000004A8D44: BF870241
	v_dual_mul_f32 v0, s5, v0 :: v_dual_mul_f32 v21, 0x3db504f3, v27// 0000004A8D48: C8C60005 001436FF 3DB504F3
	v_sub_f32_e32 v5, v28, v5                                  // 0000004A8D54: 080A0B1C
	v_mul_f32_e32 v27, 0x3db504f3, v29                         // 0000004A8D58: 10363AFF 3DB504F3
	.long 0xd7600005                                           // 0000004A8D60: D7600005
	v_cndmask_b32_e32 v0, v17, v157, vcc_lo                    // 0000004A8D64: 02013B11
	v_mul_f32_e32 v21, s0, v21                                 // 0000004A8D68: 102A2A00
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004A8D6C: BF870214
	v_mul_f32_e32 v5, 0x3db504f3, v5                           // 0000004A8D70: 100A0AFF 3DB504F3
	v_mul_f32_e32 v27, s3, v27                                 // 0000004A8D78: 10363603
	.long 0xd7600003                                           // 0000004A8D7C: D7600003
	v_cndmask_b32_e32 v0, v17, v141, vcc_lo                    // 0000004A8D80: 02011B11
	.long 0xd7600000                                           // 0000004A8D84: D7600000
	v_cndmask_b32_e32 v0, v17, v133, vcc_lo                    // 0000004A8D88: 02010B11
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004A8D8C: BF870004
	v_mul_f32_e32 v5, s4, v5                                   // 0000004A8D90: 100A0A04
	ds_store_b32 v25, v21                                      // 0000004A8D94: D8340000 00001519
	ds_store_b32 v20, v27                                      // 0000004A8D9C: D8340000 00001B14
	ds_store_b32 v19, v5                                       // 0000004A8DA4: D8340000 00000513
	ds_store_b32 v23, v0                                       // 0000004A8DAC: D8340000 00000017
	ds_load_b32 v0, v26                                        // 0000004A8DB4: D8D80000 0000001A
	ds_load_b32 v19, v16                                       // 0000004A8DBC: D8D80000 13000010
	ds_load_b32 v20, v18                                       // 0000004A8DC4: D8D80000 14000012
	ds_load_b32 v21, v24                                       // 0000004A8DCC: D8D80000 15000018
	v_or_b32_e32 v5, 24, v3                                    // 0000004A8DD4: 380A0698
	v_or_b32_e32 v23, 56, v3                                   // 0000004A8DD8: 382E06B8
	v_or_b32_e32 v25, 0x58, v3                                 // 0000004A8DDC: 383206FF 00000058
	v_or_b32_e32 v27, 0x78, v3                                 // 0000004A8DE4: 383606FF 00000078
	.long 0xd7600004                                           // 0000004A8DEC: D7600004
	v_cndmask_b32_e32 v0, v17, v149, vcc_lo                    // 0000004A8DF0: 02012B11
	v_xor_b32_e32 v28, v5, v4                                  // 0000004A8DF4: 3A380905
	v_xor_b32_e32 v23, v23, v4                                 // 0000004A8DF8: 3A2E0917
	s_waitcnt lgkmcnt(2)                                       // 0000004A8DFC: BF89FC27
	v_add_f32_e32 v29, v0, v19                                 // 0000004A8E00: 063A2700
	v_sub_f32_e32 v0, v0, v19                                  // 0000004A8E04: 08002700
	s_waitcnt lgkmcnt(0)                                       // 0000004A8E08: BF89FC07
	v_add_f32_e32 v19, v20, v21                                // 0000004A8E0C: 06262B14
	v_sub_f32_e32 v20, v20, v21                                // 0000004A8E10: 08282B14
	v_xor_b32_e32 v21, v25, v4                                 // 0000004A8E14: 3A2A0919
	v_xor_b32_e32 v25, v27, v4                                 // 0000004A8E18: 3A32091B
	v_lshl_or_b32 v27, v28, 2, v14                             // 0000004A8E1C: D656001B 0439051C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000004A8E24: BF870254
	v_add_f32_e32 v30, v0, v20                                 // 0000004A8E28: 063C2900
	v_sub_f32_e32 v0, v0, v20                                  // 0000004A8E2C: 08002900
	v_lshl_or_b32 v20, v23, 2, v14                             // 0000004A8E30: D6560014 04390517
	v_lshl_or_b32 v21, v21, 2, v14                             // 0000004A8E38: D6560015 04390515
	v_lshl_or_b32 v25, v25, 2, v14                             // 0000004A8E40: D6560019 04390519
	v_mul_f32_e32 v0, 0x3db504f3, v0                           // 0000004A8E48: 100000FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000004A8E50: BF870131
	v_mul_f32_e32 v0, s5, v0                                   // 0000004A8E54: 10000005
	v_add_f32_e32 v28, v29, v19                                // 0000004A8E58: 0638271D
	.long 0xd7600005                                           // 0000004A8E5C: D7600005
	v_cndmask_b32_e32 v0, v17, v158, vcc_lo                    // 0000004A8E60: 02013D11
	v_dual_mul_f32 v23, 0x3db504f3, v28 :: v_dual_mul_f32 v28, 0x3db504f3, v30// 0000004A8E64: C8C638FF 171C3CFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000004A8E70: BF8701C1
	v_dual_mul_f32 v23, s0, v23 :: v_dual_mul_f32 v28, s3, v28 // 0000004A8E74: C8C62E00 171C3803
	v_sub_f32_e32 v19, v29, v19                                // 0000004A8E7C: 0826271D
	.long 0xd7600003                                           // 0000004A8E80: D7600003
	v_cndmask_b32_e32 v0, v17, v142, vcc_lo                    // 0000004A8E84: 02011D11
	.long 0xd7600000                                           // 0000004A8E88: D7600000
	v_cndmask_b32_e32 v0, v17, v134, vcc_lo                    // 0000004A8E8C: 02010D11
	v_mul_f32_e32 v19, 0x3db504f3, v19                         // 0000004A8E90: 102626FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004A8E98: BF870001
	v_mul_f32_e32 v19, s4, v19                                 // 0000004A8E9C: 10262604
	ds_store_b32 v26, v23                                      // 0000004A8EA0: D8340000 0000171A
	ds_store_b32 v16, v28                                      // 0000004A8EA8: D8340000 00001C10
	ds_store_b32 v18, v19                                      // 0000004A8EB0: D8340000 00001312
	ds_store_b32 v24, v0                                       // 0000004A8EB8: D8340000 00000018
	ds_load_b32 v16, v27                                       // 0000004A8EC0: D8D80000 1000001B
	ds_load_b32 v18, v20                                       // 0000004A8EC8: D8D80000 12000014
	ds_load_b32 v19, v21                                       // 0000004A8ED0: D8D80000 13000015
	ds_load_b32 v23, v25                                       // 0000004A8ED8: D8D80000 17000019
	v_or_b32_e32 v0, 28, v3                                    // 0000004A8EE0: 3800069C
	v_or_b32_e32 v24, 60, v3                                   // 0000004A8EE4: 383006BC
	v_or_b32_e32 v26, 0x5c, v3                                 // 0000004A8EE8: 383406FF 0000005C
	v_or_b32_e32 v28, 0x7c, v3                                 // 0000004A8EF0: 383806FF 0000007C
	.long 0xd7600004                                           // 0000004A8EF8: D7600004
	v_cndmask_b32_e32 v0, v17, v150, vcc_lo                    // 0000004A8EFC: 02012D11
	v_xor_b32_e32 v29, v0, v4                                  // 0000004A8F00: 3A3A0900
	v_xor_b32_e32 v24, v24, v4                                 // 0000004A8F04: 3A300918
	s_waitcnt lgkmcnt(2)                                       // 0000004A8F08: BF89FC27
	v_add_f32_e32 v30, v16, v18                                // 0000004A8F0C: 063C2510
	v_sub_f32_e32 v16, v16, v18                                // 0000004A8F10: 08202510
	s_waitcnt lgkmcnt(0)                                       // 0000004A8F14: BF89FC07
	v_add_f32_e32 v18, v19, v23                                // 0000004A8F18: 06242F13
	v_sub_f32_e32 v19, v19, v23                                // 0000004A8F1C: 08262F13
	v_xor_b32_e32 v23, v26, v4                                 // 0000004A8F20: 3A2E091A
	v_xor_b32_e32 v26, v28, v4                                 // 0000004A8F24: 3A34091C
	v_lshl_or_b32 v28, v29, 2, v14                             // 0000004A8F28: D656001C 0439051D
	v_add_f32_e32 v29, v30, v18                                // 0000004A8F30: 063A251E
	v_add_f32_e32 v31, v16, v19                                // 0000004A8F34: 063E2710
	v_sub_f32_e32 v16, v16, v19                                // 0000004A8F38: 08202710
	v_lshl_or_b32 v19, v24, 2, v14                             // 0000004A8F3C: D6560013 04390518
	v_lshl_or_b32 v23, v23, 2, v14                             // 0000004A8F44: D6560017 04390517
	v_mul_f32_e32 v24, 0x3db504f3, v29                         // 0000004A8F4C: 10303AFF 3DB504F3
	v_lshl_or_b32 v14, v26, 2, v14                             // 0000004A8F54: D656000E 0439051A
	v_dual_mul_f32 v16, 0x3db504f3, v16 :: v_dual_mul_f32 v29, 0x3db504f3, v31// 0000004A8F5C: C8C620FF 101C3EFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000004A8F68: BF8701A3
	v_mul_f32_e32 v24, s0, v24                                 // 0000004A8F6C: 10303000
	.long 0xd7600000                                           // 0000004A8F70: D7600000
	v_cndmask_b32_e32 v0, v17, v128, vcc_lo                    // 0000004A8F74: 02010111
	v_dual_mul_f32 v16, s5, v16 :: v_dual_mul_f32 v29, s3, v29 // 0000004A8F78: C8C62005 101C3A03
	v_sub_f32_e32 v18, v30, v18                                // 0000004A8F80: 0824251E
	.long 0xd7600003                                           // 0000004A8F84: D7600003
	v_cndmask_b32_e32 v0, v17, v135, vcc_lo                    // 0000004A8F88: 02010F11
	.long 0xd7600005                                           // 0000004A8F8C: D7600005
	v_cndmask_b32_e32 v0, v17, v151, vcc_lo                    // 0000004A8F90: 02012F11
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004A8F94: BF870093
	v_dual_mul_f32 v15, s0, v15 :: v_dual_mul_f32 v18, 0x3db504f3, v18// 0000004A8F98: C8C61E00 0F1224FF 3DB504F3
	v_mul_f32_e32 v18, s4, v18                                 // 0000004A8FA4: 10242404
	ds_store_b32 v27, v24                                      // 0000004A8FA8: D8340000 0000181B
	ds_store_b32 v20, v29                                      // 0000004A8FB0: D8340000 00001D14
	ds_store_b32 v21, v18                                      // 0000004A8FB8: D8340000 00001215
	ds_store_b32 v25, v16                                      // 0000004A8FC0: D8340000 00001019
	ds_load_b32 v16, v28                                       // 0000004A8FC8: D8D80000 1000001C
	ds_load_b32 v18, v19                                       // 0000004A8FD0: D8D80000 12000013
	ds_load_b32 v20, v23                                       // 0000004A8FD8: D8D80000 14000017
	ds_load_b32 v21, v14                                       // 0000004A8FE0: D8D80000 1500000E
	.long 0xd7600004                                           // 0000004A8FE8: D7600004
	v_cndmask_b32_e32 v0, v17, v143, vcc_lo                    // 0000004A8FEC: 02011F11
	s_waitcnt lgkmcnt(2)                                       // 0000004A8FF0: BF89FC27
	v_add_f32_e32 v22, v16, v18                                // 0000004A8FF4: 062C2510
	v_sub_f32_e32 v16, v16, v18                                // 0000004A8FF8: 08202510
	s_waitcnt lgkmcnt(0)                                       // 0000004A8FFC: BF89FC07
	v_add_f32_e32 v18, v20, v21                                // 0000004A9000: 06242B14
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004A9004: BF870091
	v_dual_sub_f32 v20, v20, v21 :: v_dual_add_f32 v21, v22, v18// 0000004A9008: C9482B14 14142516
	v_dual_mul_f32 v17, 0x3db504f3, v21 :: v_dual_add_f32 v24, v16, v20// 0000004A9010: C8C82AFF 11182910 3DB504F3
	v_sub_f32_e32 v18, v22, v18                                // 0000004A901C: 08242516
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004A9020: BF870192
	v_dual_sub_f32 v16, v16, v20 :: v_dual_mul_f32 v17, s3, v17// 0000004A9024: C9462910 10102203
	v_mul_f32_e32 v20, 0x3db504f3, v24                         // 0000004A902C: 102830FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004A9034: BF870193
	v_mul_f32_e32 v18, 0x3db504f3, v18                         // 0000004A9038: 102424FF 3DB504F3
	v_mul_f32_e32 v16, 0x3db504f3, v16                         // 0000004A9040: 102020FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004A9048: BF870193
	v_mul_f32_e32 v20, s4, v20                                 // 0000004A904C: 10282804
	v_mul_f32_e32 v18, s5, v18                                 // 0000004A9050: 10242405
	s_delay_alu instid0(VALU_DEP_3)                            // 0000004A9054: BF870003
	v_mul_f32_e32 v16, s6, v16                                 // 0000004A9058: 10202006
	ds_store_b32 v13, v15                                      // 0000004A905C: D8340000 00000F0D
	ds_store_b32 v28, v17                                      // 0000004A9064: D8340000 0000111C
	ds_store_b32 v19, v20                                      // 0000004A906C: D8340000 00001413
	ds_store_b32 v23, v18                                      // 0000004A9074: D8340000 00001217
	ds_store_b32 v14, v16                                      // 0000004A907C: D8340000 0000100E
	s_waitcnt lgkmcnt(0)                                       // 0000004A9084: BF89FC07
	s_barrier                                                  // 0000004A9088: BFBD0000
	buffer_gl0_inv                                             // 0000004A908C: E0AC0000 00000000
	s_and_saveexec_b32 s0, vcc_lo                              // 0000004A9094: BE80206A
	s_cbranch_execz 406                                        // 0000004A9098: BFA50196 <_ZN7halogen12_GLOBAL__N_113k_ht_deq_origILi4ELb1ELi16EEEvPKjiPKDF16_S5_Pti+0x21f4>
	v_lshlrev_b32_e32 v11, 14, v11                             // 0000004A909C: 3016168E
	v_and_or_b32 v4, 0x60, v12, v4                             // 0000004A90A0: D6570004 041218FF 00000060
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004A90AC: BF870112
	v_and_b32_e32 v11, 0xc000, v11                             // 0000004A90B0: 361616FF 0000C000
	v_xor_b32_e32 v12, 1, v4                                   // 0000004A90B8: 3A180881
	v_xor_b32_e32 v13, 2, v4                                   // 0000004A90BC: 3A1A0882
	v_xor_b32_e32 v14, 3, v4                                   // 0000004A90C0: 3A1C0883
	v_xor_b32_e32 v15, 4, v4                                   // 0000004A90C4: 3A1E0884
	v_xor_b32_e32 v16, 5, v4                                   // 0000004A90C8: 3A200885
	v_lshl_or_b32 v17, v4, 2, v11                              // 0000004A90CC: D6560011 042D0504
	v_xor_b32_e32 v18, 6, v4                                   // 0000004A90D4: 3A240886
	v_xor_b32_e32 v19, 7, v4                                   // 0000004A90D8: 3A260887
	v_lshl_or_b32 v12, v12, 2, v11                             // 0000004A90DC: D656000C 042D050C
	v_lshl_or_b32 v13, v13, 2, v11                             // 0000004A90E4: D656000D 042D050D
	v_lshl_or_b32 v14, v14, 2, v11                             // 0000004A90EC: D656000E 042D050E
	v_lshl_or_b32 v15, v15, 2, v11                             // 0000004A90F4: D656000F 042D050F
	v_lshl_or_b32 v16, v16, 2, v11                             // 0000004A90FC: D6560010 042D0510
	v_lshl_or_b32 v18, v18, 2, v11                             // 0000004A9104: D6560012 042D0512
	v_lshl_or_b32 v19, v19, 2, v11                             // 0000004A910C: D6560013 042D0513
	ds_load_b32 v23, v17                                       // 0000004A9114: D8D80000 17000011
	ds_load_b32 v24, v12 offset:512                            // 0000004A911C: D8D80200 1800000C
	ds_load_b32 v25, v13 offset:1024                           // 0000004A9124: D8D80400 1900000D
	ds_load_b32 v26, v14 offset:1536                           // 0000004A912C: D8D80600 1A00000E
	ds_load_b32 v27, v15 offset:2048                           // 0000004A9134: D8D80800 1B00000F
	ds_load_b32 v28, v16 offset:2560                           // 0000004A913C: D8D80A00 1C000010
	ds_load_b32 v29, v18 offset:3072                           // 0000004A9144: D8D80C00 1D000012
	ds_load_b32 v30, v19 offset:3584                           // 0000004A914C: D8D80E00 1E000013
	v_xor_b32_e32 v20, 8, v4                                   // 0000004A9154: 3A280888
	v_xor_b32_e32 v36, 16, v4                                  // 0000004A9158: 3A480890
	v_xor_b32_e32 v52, 24, v4                                  // 0000004A915C: 3A680898
	v_xor_b32_e32 v21, 9, v4                                   // 0000004A9160: 3A2A0889
	v_xor_b32_e32 v37, 17, v4                                  // 0000004A9164: 3A4A0891
	v_xor_b32_e32 v53, 25, v4                                  // 0000004A9168: 3A6A0899
	v_xor_b32_e32 v22, 10, v4                                  // 0000004A916C: 3A2C088A
	v_xor_b32_e32 v38, 18, v4                                  // 0000004A9170: 3A4C0892
	v_xor_b32_e32 v54, 26, v4                                  // 0000004A9174: 3A6C089A
	v_xor_b32_e32 v31, 11, v4                                  // 0000004A9178: 3A3E088B
	v_xor_b32_e32 v47, 19, v4                                  // 0000004A917C: 3A5E0893
	v_xor_b32_e32 v63, 27, v4                                  // 0000004A9180: 3A7E089B
	v_xor_b32_e32 v32, 12, v4                                  // 0000004A9184: 3A40088C
	v_xor_b32_e32 v48, 20, v4                                  // 0000004A9188: 3A600894
	v_xor_b32_e32 v64, 28, v4                                  // 0000004A918C: 3A80089C
	v_xor_b32_e32 v33, 13, v4                                  // 0000004A9190: 3A42088D
	v_xor_b32_e32 v34, 14, v4                                  // 0000004A9194: 3A44088E
	v_xor_b32_e32 v35, 15, v4                                  // 0000004A9198: 3A46088F
	v_xor_b32_e32 v49, 21, v4                                  // 0000004A919C: 3A620895
	v_xor_b32_e32 v50, 22, v4                                  // 0000004A91A0: 3A640896
	v_xor_b32_e32 v51, 23, v4                                  // 0000004A91A4: 3A660897
	v_xor_b32_e32 v65, 29, v4                                  // 0000004A91A8: 3A82089D
	v_xor_b32_e32 v66, 30, v4                                  // 0000004A91AC: 3A84089E
	v_xor_b32_e32 v4, 31, v4                                   // 0000004A91B0: 3A08089F
	s_waitcnt lgkmcnt(6)                                       // 0000004A91B4: BF89FC67
	v_add_f32_e32 v74, v23, v24                                // 0000004A91B8: 06943117
	s_waitcnt lgkmcnt(4)                                       // 0000004A91BC: BF89FC47
	v_dual_sub_f32 v23, v23, v24 :: v_dual_add_f32 v24, v25, v26// 0000004A91C0: C9483117 17183519
	v_lshl_or_b32 v20, v20, 2, v11                             // 0000004A91C8: D6560014 042D0514
	v_lshl_or_b32 v36, v36, 2, v11                             // 0000004A91D0: D6560024 042D0524
	v_lshl_or_b32 v52, v52, 2, v11                             // 0000004A91D8: D6560034 042D0534
	v_lshl_or_b32 v21, v21, 2, v11                             // 0000004A91E0: D6560015 042D0515
	v_lshl_or_b32 v37, v37, 2, v11                             // 0000004A91E8: D6560025 042D0525
	v_lshl_or_b32 v53, v53, 2, v11                             // 0000004A91F0: D6560035 042D0535
	v_lshl_or_b32 v22, v22, 2, v11                             // 0000004A91F8: D6560016 042D0516
	v_lshl_or_b32 v38, v38, 2, v11                             // 0000004A9200: D6560026 042D0526
	v_lshl_or_b32 v54, v54, 2, v11                             // 0000004A9208: D6560036 042D0536
	v_lshl_or_b32 v31, v31, 2, v11                             // 0000004A9210: D656001F 042D051F
	v_lshl_or_b32 v47, v47, 2, v11                             // 0000004A9218: D656002F 042D052F
	v_lshl_or_b32 v63, v63, 2, v11                             // 0000004A9220: D656003F 042D053F
	v_lshl_or_b32 v32, v32, 2, v11                             // 0000004A9228: D6560020 042D0520
	v_lshl_or_b32 v48, v48, 2, v11                             // 0000004A9230: D6560030 042D0530
	v_lshl_or_b32 v64, v64, 2, v11                             // 0000004A9238: D6560040 042D0540
	v_lshl_or_b32 v33, v33, 2, v11                             // 0000004A9240: D6560021 042D0521
	v_lshl_or_b32 v34, v34, 2, v11                             // 0000004A9248: D6560022 042D0522
	v_lshl_or_b32 v35, v35, 2, v11                             // 0000004A9250: D6560023 042D0523
	ds_load_b32 v39, v20 offset:4096                           // 0000004A9258: D8D81000 27000014
	ds_load_b32 v40, v21 offset:4608                           // 0000004A9260: D8D81200 28000015
	ds_load_b32 v41, v22 offset:5120                           // 0000004A9268: D8D81400 29000016
	ds_load_b32 v42, v31 offset:5632                           // 0000004A9270: D8D81600 2A00001F
	ds_load_b32 v43, v32 offset:6144                           // 0000004A9278: D8D81800 2B000020
	ds_load_b32 v44, v33 offset:6656                           // 0000004A9280: D8D81A00 2C000021
	ds_load_b32 v45, v34 offset:7168                           // 0000004A9288: D8D81C00 2D000022
	ds_load_b32 v46, v35 offset:7680                           // 0000004A9290: D8D81E00 2E000023
	v_lshl_or_b32 v49, v49, 2, v11                             // 0000004A9298: D6560031 042D0531
	v_lshl_or_b32 v50, v50, 2, v11                             // 0000004A92A0: D6560032 042D0532
	v_lshl_or_b32 v51, v51, 2, v11                             // 0000004A92A8: D6560033 042D0533
	ds_load_b32 v55, v36 offset:8192                           // 0000004A92B0: D8D82000 37000024
	ds_load_b32 v56, v37 offset:8704                           // 0000004A92B8: D8D82200 38000025
	ds_load_b32 v57, v38 offset:9216                           // 0000004A92C0: D8D82400 39000026
	ds_load_b32 v58, v47 offset:9728                           // 0000004A92C8: D8D82600 3A00002F
	ds_load_b32 v59, v48 offset:10240                          // 0000004A92D0: D8D82800 3B000030
	ds_load_b32 v60, v49 offset:10752                          // 0000004A92D8: D8D82A00 3C000031
	ds_load_b32 v61, v50 offset:11264                          // 0000004A92E0: D8D82C00 3D000032
	ds_load_b32 v62, v51 offset:11776                          // 0000004A92E8: D8D82E00 3E000033
	v_lshl_or_b32 v65, v65, 2, v11                             // 0000004A92F0: D6560041 042D0541
	v_lshl_or_b32 v66, v66, 2, v11                             // 0000004A92F8: D6560042 042D0542
	v_lshl_or_b32 v4, v4, 2, v11                               // 0000004A9300: D6560004 042D0504
	ds_load_b32 v11, v52 offset:12288                          // 0000004A9308: D8D83000 0B000034
	ds_load_b32 v67, v53 offset:12800                          // 0000004A9310: D8D83200 43000035
	ds_load_b32 v68, v54 offset:13312                          // 0000004A9318: D8D83400 44000036
	ds_load_b32 v69, v63 offset:13824                          // 0000004A9320: D8D83600 4500003F
	ds_load_b32 v70, v64 offset:14336                          // 0000004A9328: D8D83800 46000040
	ds_load_b32 v71, v65 offset:14848                          // 0000004A9330: D8D83A00 47000041
	ds_load_b32 v72, v66 offset:15360                          // 0000004A9338: D8D83C00 48000042
	ds_load_b32 v73, v4 offset:15872                           // 0000004A9340: D8D83E00 49000004
	s_waitcnt lgkmcnt(26)                                      // 0000004A9348: BF89FDA7
	v_dual_sub_f32 v25, v25, v26 :: v_dual_add_f32 v26, v27, v28// 0000004A934C: C9483519 191A391B
	s_waitcnt lgkmcnt(24)                                      // 0000004A9354: BF89FD87
	v_dual_sub_f32 v27, v27, v28 :: v_dual_add_f32 v28, v29, v30// 0000004A9358: C948391B 1B1C3D1D
	s_waitcnt lgkmcnt(22)                                      // 0000004A9360: BF89FD67
	v_dual_sub_f32 v29, v29, v30 :: v_dual_add_f32 v30, v39, v40// 0000004A9364: C9483D1D 1D1E5127
	s_waitcnt lgkmcnt(20)                                      // 0000004A936C: BF89FD47
	v_dual_sub_f32 v39, v39, v40 :: v_dual_add_f32 v40, v41, v42// 0000004A9370: C9485127 27285529
	s_waitcnt lgkmcnt(18)                                      // 0000004A9378: BF89FD27
	v_dual_sub_f32 v41, v41, v42 :: v_dual_add_f32 v42, v43, v44// 0000004A937C: C9485529 292A592B
	s_waitcnt lgkmcnt(16)                                      // 0000004A9384: BF89FD07
	v_dual_sub_f32 v43, v43, v44 :: v_dual_add_f32 v44, v45, v46// 0000004A9388: C948592B 2B2C5D2D
	s_waitcnt lgkmcnt(14)                                      // 0000004A9390: BF89FCE7
	v_dual_sub_f32 v45, v45, v46 :: v_dual_add_f32 v46, v55, v56// 0000004A9394: C9485D2D 2D2E7137
	s_waitcnt lgkmcnt(12)                                      // 0000004A939C: BF89FCC7
	v_dual_sub_f32 v55, v55, v56 :: v_dual_add_f32 v56, v57, v58// 0000004A93A0: C9487137 37387539
	s_waitcnt lgkmcnt(10)                                      // 0000004A93A8: BF89FCA7
	v_dual_sub_f32 v57, v57, v58 :: v_dual_add_f32 v58, v59, v60// 0000004A93AC: C9487539 393A793B
	s_waitcnt lgkmcnt(8)                                       // 0000004A93B4: BF89FC87
	v_dual_sub_f32 v59, v59, v60 :: v_dual_add_f32 v60, v61, v62// 0000004A93B8: C948793B 3B3C7D3D
	s_waitcnt lgkmcnt(6)                                       // 0000004A93C0: BF89FC67
	v_dual_sub_f32 v61, v61, v62 :: v_dual_add_f32 v62, v11, v67// 0000004A93C4: C9487D3D 3D3E870B
	v_sub_f32_e32 v11, v11, v67                                // 0000004A93CC: 0816870B
	s_waitcnt lgkmcnt(4)                                       // 0000004A93D0: BF89FC47
	v_add_f32_e32 v67, v68, v69                                // 0000004A93D4: 06868B44
	s_waitcnt lgkmcnt(2)                                       // 0000004A93D8: BF89FC27
	v_dual_sub_f32 v68, v68, v69 :: v_dual_add_f32 v69, v70, v71// 0000004A93DC: C9488B44 44448F46
	s_waitcnt lgkmcnt(0)                                       // 0000004A93E4: BF89FC07
	v_dual_sub_f32 v70, v70, v71 :: v_dual_add_f32 v71, v72, v73// 0000004A93E8: C9488F46 46469348
	v_dual_sub_f32 v72, v72, v73 :: v_dual_add_f32 v73, v74, v24// 0000004A93F0: C9489348 4848314A
	v_sub_f32_e32 v24, v74, v24                                // 0000004A93F8: 0830314A
	v_add_f32_e32 v74, v23, v25                                // 0000004A93FC: 06943317
	v_sub_f32_e32 v23, v23, v25                                // 0000004A9400: 082E3317
	v_add_f32_e32 v25, v26, v28                                // 0000004A9404: 0632391A
	v_sub_f32_e32 v26, v26, v28                                // 0000004A9408: 0834391A
	v_add_f32_e32 v28, v27, v29                                // 0000004A940C: 06383B1B
	v_sub_f32_e32 v27, v27, v29                                // 0000004A9410: 08363B1B
	v_add_f32_e32 v29, v30, v40                                // 0000004A9414: 063A511E
	v_sub_f32_e32 v30, v30, v40                                // 0000004A9418: 083C511E
	v_add_f32_e32 v40, v39, v41                                // 0000004A941C: 06505327
	v_sub_f32_e32 v39, v39, v41                                // 0000004A9420: 084E5327
	v_add_f32_e32 v41, v42, v44                                // 0000004A9424: 0652592A
	v_sub_f32_e32 v42, v42, v44                                // 0000004A9428: 0854592A
	v_add_f32_e32 v44, v43, v45                                // 0000004A942C: 06585B2B
	v_sub_f32_e32 v43, v43, v45                                // 0000004A9430: 08565B2B
	v_add_f32_e32 v45, v46, v56                                // 0000004A9434: 065A712E
	v_sub_f32_e32 v46, v46, v56                                // 0000004A9438: 085C712E
	v_add_f32_e32 v56, v55, v57                                // 0000004A943C: 06707337
	v_sub_f32_e32 v55, v55, v57                                // 0000004A9440: 086E7337
	v_add_f32_e32 v57, v58, v60                                // 0000004A9444: 0672793A
	v_sub_f32_e32 v58, v58, v60                                // 0000004A9448: 0874793A
	v_add_f32_e32 v60, v59, v61                                // 0000004A944C: 06787B3B
	v_sub_f32_e32 v59, v59, v61                                // 0000004A9450: 08767B3B
	v_add_f32_e32 v61, v62, v67                                // 0000004A9454: 067A873E
	v_dual_sub_f32 v62, v62, v67 :: v_dual_add_f32 v67, v11, v68// 0000004A9458: C948873E 3E42890B
	v_dual_sub_f32 v11, v11, v68 :: v_dual_add_f32 v68, v69, v71// 0000004A9460: C948890B 0B448F45
	v_sub_f32_e32 v69, v69, v71                                // 0000004A9468: 088A8F45
	v_add_f32_e32 v71, v70, v72                                // 0000004A946C: 068E9146
	v_sub_f32_e32 v70, v70, v72                                // 0000004A9470: 088C9146
	v_add_f32_e32 v72, v73, v25                                // 0000004A9474: 06903349
	v_sub_f32_e32 v25, v73, v25                                // 0000004A9478: 08323349
	v_add_f32_e32 v73, v74, v28                                // 0000004A947C: 0692394A
	v_sub_f32_e32 v28, v74, v28                                // 0000004A9480: 0838394A
	v_add_f32_e32 v74, v24, v26                                // 0000004A9484: 06943518
	v_sub_f32_e32 v24, v24, v26                                // 0000004A9488: 08303518
	v_add_f32_e32 v26, v23, v27                                // 0000004A948C: 06343717
	v_sub_f32_e32 v23, v23, v27                                // 0000004A9490: 082E3717
	v_add_f32_e32 v27, v29, v41                                // 0000004A9494: 0636531D
	v_sub_f32_e32 v29, v29, v41                                // 0000004A9498: 083A531D
	v_add_f32_e32 v41, v40, v44                                // 0000004A949C: 06525928
	v_sub_f32_e32 v40, v40, v44                                // 0000004A94A0: 08505928
	v_add_f32_e32 v44, v30, v42                                // 0000004A94A4: 0658551E
	v_sub_f32_e32 v30, v30, v42                                // 0000004A94A8: 083C551E
	v_add_f32_e32 v42, v39, v43                                // 0000004A94AC: 06545727
	v_sub_f32_e32 v39, v39, v43                                // 0000004A94B0: 084E5727
	v_add_f32_e32 v43, v45, v57                                // 0000004A94B4: 0656732D
	v_sub_f32_e32 v45, v45, v57                                // 0000004A94B8: 085A732D
	v_add_f32_e32 v57, v56, v60                                // 0000004A94BC: 06727938
	v_sub_f32_e32 v56, v56, v60                                // 0000004A94C0: 08707938
	v_add_f32_e32 v60, v46, v58                                // 0000004A94C4: 0678752E
	v_sub_f32_e32 v46, v46, v58                                // 0000004A94C8: 085C752E
	v_add_f32_e32 v58, v55, v59                                // 0000004A94CC: 06747737
	v_sub_f32_e32 v55, v55, v59                                // 0000004A94D0: 086E7737
	v_add_f32_e32 v59, v61, v68                                // 0000004A94D4: 0676893D
	v_dual_sub_f32 v61, v61, v68 :: v_dual_add_f32 v68, v67, v71// 0000004A94D8: C948893D 3D448F43
	v_sub_f32_e32 v67, v67, v71                                // 0000004A94E0: 08868F43
	v_add_f32_e32 v71, v62, v69                                // 0000004A94E4: 068E8B3E
	v_dual_sub_f32 v62, v62, v69 :: v_dual_add_f32 v69, v11, v70// 0000004A94E8: C9488B3E 3E448D0B
	v_dual_sub_f32 v11, v11, v70 :: v_dual_add_f32 v70, v72, v27// 0000004A94F0: C9488D0B 0B463748
	v_dual_sub_f32 v27, v72, v27 :: v_dual_add_f32 v72, v73, v41// 0000004A94F8: C9483748 1B485349
	v_sub_f32_e32 v41, v73, v41                                // 0000004A9500: 08525349
	v_add_f32_e32 v73, v74, v44                                // 0000004A9504: 0692594A
	v_sub_f32_e32 v44, v74, v44                                // 0000004A9508: 0858594A
	v_add_f32_e32 v74, v26, v42                                // 0000004A950C: 0694551A
	v_sub_f32_e32 v26, v26, v42                                // 0000004A9510: 0834551A
	v_add_f32_e32 v42, v25, v29                                // 0000004A9514: 06543B19
	v_sub_f32_e32 v25, v25, v29                                // 0000004A9518: 08323B19
	v_add_f32_e32 v29, v28, v40                                // 0000004A951C: 063A511C
	v_sub_f32_e32 v28, v28, v40                                // 0000004A9520: 0838511C
	v_add_f32_e32 v40, v24, v30                                // 0000004A9524: 06503D18
	v_sub_f32_e32 v24, v24, v30                                // 0000004A9528: 08303D18
	v_add_f32_e32 v30, v23, v39                                // 0000004A952C: 063C4F17
	v_sub_f32_e32 v23, v23, v39                                // 0000004A9530: 082E4F17
	v_add_f32_e32 v39, v43, v59                                // 0000004A9534: 064E772B
	v_sub_f32_e32 v43, v43, v59                                // 0000004A9538: 0856772B
	v_add_f32_e32 v59, v57, v68                                // 0000004A953C: 06768939
	v_dual_sub_f32 v57, v57, v68 :: v_dual_add_f32 v68, v60, v71// 0000004A9540: C9488939 39448F3C
	v_dual_sub_f32 v60, v60, v71 :: v_dual_add_f32 v71, v58, v69// 0000004A9548: C9488F3C 3C468B3A
	v_sub_f32_e32 v58, v58, v69                                // 0000004A9550: 08748B3A
	v_add_f32_e32 v69, v45, v61                                // 0000004A9554: 068A7B2D
	v_sub_f32_e32 v45, v45, v61                                // 0000004A9558: 085A7B2D
	v_add_f32_e32 v61, v56, v67                                // 0000004A955C: 067A8738
	v_dual_sub_f32 v56, v56, v67 :: v_dual_add_f32 v67, v46, v62// 0000004A9560: C9488738 38427D2E
	v_sub_f32_e32 v46, v46, v62                                // 0000004A9568: 085C7D2E
	v_add_f32_e32 v62, v55, v11                                // 0000004A956C: 067C1737
	v_sub_f32_e32 v11, v55, v11                                // 0000004A9570: 08161737
	v_add_f32_e32 v55, v70, v39                                // 0000004A9574: 066E4F46
	v_sub_f32_e32 v39, v70, v39                                // 0000004A9578: 084E4F46
	v_add_f32_e32 v70, v72, v59                                // 0000004A957C: 068C7748
	v_dual_sub_f32 v59, v72, v59 :: v_dual_add_f32 v72, v73, v68// 0000004A9580: C9487748 3B488949
	v_dual_sub_f32 v68, v73, v68 :: v_dual_add_f32 v73, v74, v71// 0000004A9588: C9488949 44488F4A
	v_sub_f32_e32 v71, v74, v71                                // 0000004A9590: 088E8F4A
	v_add_f32_e32 v74, v42, v69                                // 0000004A9594: 06948B2A
	v_sub_f32_e32 v42, v42, v69                                // 0000004A9598: 08548B2A
	v_add_f32_e32 v69, v29, v61                                // 0000004A959C: 068A7B1D
	v_sub_f32_e32 v29, v29, v61                                // 0000004A95A0: 083A7B1D
	v_add_f32_e32 v61, v40, v67                                // 0000004A95A4: 067A8728
	v_dual_sub_f32 v40, v40, v67 :: v_dual_add_f32 v67, v30, v62// 0000004A95A8: C9488728 28427D1E
	v_sub_f32_e32 v30, v30, v62                                // 0000004A95B0: 083C7D1E
	v_add_f32_e32 v62, v27, v43                                // 0000004A95B4: 067C571B
	v_sub_f32_e32 v27, v27, v43                                // 0000004A95B8: 0836571B
	v_add_f32_e32 v43, v41, v57                                // 0000004A95BC: 06567329
	v_sub_f32_e32 v41, v41, v57                                // 0000004A95C0: 08527329
	v_add_f32_e32 v57, v44, v60                                // 0000004A95C4: 0672792C
	v_sub_f32_e32 v44, v44, v60                                // 0000004A95C8: 0858792C
	v_add_f32_e32 v60, v26, v58                                // 0000004A95CC: 0678751A
	v_sub_f32_e32 v26, v26, v58                                // 0000004A95D0: 0834751A
	v_add_f32_e32 v58, v25, v45                                // 0000004A95D4: 06745B19
	v_sub_f32_e32 v25, v25, v45                                // 0000004A95D8: 08325B19
	v_add_f32_e32 v45, v28, v56                                // 0000004A95DC: 065A711C
	v_sub_f32_e32 v28, v28, v56                                // 0000004A95E0: 0838711C
	v_add_f32_e32 v56, v24, v46                                // 0000004A95E4: 06705D18
	v_sub_f32_e32 v24, v24, v46                                // 0000004A95E8: 08305D18
	v_add_f32_e32 v46, v23, v11                                // 0000004A95EC: 065C1717
	v_sub_f32_e32 v11, v23, v11                                // 0000004A95F0: 08161717
	ds_store_b32 v17, v55                                      // 0000004A95F4: D8340000 00003711
	ds_store_b32 v12, v70 offset:512                           // 0000004A95FC: D8340200 0000460C
	ds_store_b32 v13, v72 offset:1024                          // 0000004A9604: D8340400 0000480D
	ds_store_b32 v14, v73 offset:1536                          // 0000004A960C: D8340600 0000490E
	ds_store_b32 v15, v74 offset:2048                          // 0000004A9614: D8340800 00004A0F
	ds_store_b32 v16, v69 offset:2560                          // 0000004A961C: D8340A00 00004510
	ds_store_b32 v18, v61 offset:3072                          // 0000004A9624: D8340C00 00003D12
	ds_store_b32 v19, v67 offset:3584                          // 0000004A962C: D8340E00 00004313
	ds_store_b32 v20, v62 offset:4096                          // 0000004A9634: D8341000 00003E14
	ds_store_b32 v21, v43 offset:4608                          // 0000004A963C: D8341200 00002B15
	ds_store_b32 v22, v57 offset:5120                          // 0000004A9644: D8341400 00003916
	ds_store_b32 v31, v60 offset:5632                          // 0000004A964C: D8341600 00003C1F
	ds_store_b32 v32, v58 offset:6144                          // 0000004A9654: D8341800 00003A20
	ds_store_b32 v33, v45 offset:6656                          // 0000004A965C: D8341A00 00002D21
	ds_store_b32 v34, v56 offset:7168                          // 0000004A9664: D8341C00 00003822
	ds_store_b32 v35, v46 offset:7680                          // 0000004A966C: D8341E00 00002E23
	ds_store_b32 v36, v39 offset:8192                          // 0000004A9674: D8342000 00002724
	ds_store_b32 v37, v59 offset:8704                          // 0000004A967C: D8342200 00003B25
	ds_store_b32 v38, v68 offset:9216                          // 0000004A9684: D8342400 00004426
	ds_store_b32 v47, v71 offset:9728                          // 0000004A968C: D8342600 0000472F
	ds_store_b32 v48, v42 offset:10240                         // 0000004A9694: D8342800 00002A30
	ds_store_b32 v49, v29 offset:10752                         // 0000004A969C: D8342A00 00001D31
	ds_store_b32 v50, v40 offset:11264                         // 0000004A96A4: D8342C00 00002832
	ds_store_b32 v51, v30 offset:11776                         // 0000004A96AC: D8342E00 00001E33
	ds_store_b32 v52, v27 offset:12288                         // 0000004A96B4: D8343000 00001B34
	ds_store_b32 v53, v41 offset:12800                         // 0000004A96BC: D8343200 00002935
	ds_store_b32 v54, v44 offset:13312                         // 0000004A96C4: D8343400 00002C36
	ds_store_b32 v63, v26 offset:13824                         // 0000004A96CC: D8343600 00001A3F
	ds_store_b32 v64, v25 offset:14336                         // 0000004A96D4: D8343800 00001940
	ds_store_b32 v65, v28 offset:14848                         // 0000004A96DC: D8343A00 00001C41
	ds_store_b32 v66, v24 offset:15360                         // 0000004A96E4: D8343C00 00001842
	ds_store_b32 v4, v11 offset:15872                          // 0000004A96EC: D8343E00 00000B04
	s_or_b32 exec_lo, exec_lo, s0                              // 0000004A96F4: 8C7E007E
	v_xor_b32_e32 v4, v3, v2                                   // 0000004A96F8: 3A080503
	v_lshlrev_b32_e32 v11, 9, v3                               // 0000004A96FC: 30160689
	s_waitcnt lgkmcnt(0)                                       // 0000004A9700: BF89FC07
	s_barrier                                                  // 0000004A9704: BFBD0000
	buffer_gl0_inv                                             // 0000004A9708: E0AC0000 00000000
	v_or_b32_e32 v23, s1, v3                                   // 0000004A9710: 382E0601
	v_lshl_add_u32 v4, v4, 2, v11                              // 0000004A9714: D6460004 042D0504
	s_ashr_i32 s3, s2, 31                                      // 0000004A971C: 86039F02
	v_cvt_f32_f16_e32 v1, v1                                   // 0000004A9720: 7E021701
	s_lshl_b64 s[2:3], s[2:3], 1                               // 0000004A9724: 84828102
	ds_load_2addr_stride64_b32 v[13:14], v4 offset1:64         // 0000004A9728: D8E04000 0D000004
	ds_load_2addr_stride64_b32 v[15:16], v4 offset0:128 offset1:192// 0000004A9730: D8E0C080 0F000004
	v_mov_b32_e32 v3, 0                                        // 0000004A9738: 7E060280
	v_mad_i64_i32 v[11:12], null, v23, s10, 0                  // 0000004A973C: D6FF7C0B 02001517
	v_or_b32_e32 v17, 32, v23                                  // 0000004A9744: 38222EA0
	v_or_b32_e32 v19, 64, v23                                  // 0000004A9748: 38262EC0
	s_add_u32 s0, s8, s2                                       // 0000004A974C: 80000208
	.long 0xd73c0003                                           // 0000004A9750: D73C0003
	v_cndmask_b32_e32 v1, 1, v2, vcc_lo                        // 0000004A9754: 02020481
	s_addc_u32 s2, s9, s3                                      // 0000004A9758: 82020309
	v_mad_i64_i32 v[17:18], null, v17, s10, 0                  // 0000004A975C: D6FF7C11 02001511
	v_mad_i64_i32 v[19:20], null, v19, s10, 0                  // 0000004A9764: D6FF7C13 02001513
	.long 0xd73c000b                                           // 0000004A976C: D73C000B
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 0000004A9770: 02021681
	.long 0xd7600004                                           // 0000004A9774: D7600004
	v_cndmask_b32_e32 v0, v1, v152, vcc_lo                     // 0000004A9778: 02013101
	.long 0xd7006a03                                           // 0000004A977C: D7006A03
	v_cndmask_b32_e32 v1, s0, v3, vcc_lo                       // 0000004A9780: 02020600
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000004A9784: BF8701A1
	v_add_co_ci_u32_e64 v4, null, s2, v4, vcc_lo               // 0000004A9788: D5207C04 01AA0802
	.long 0xd7600002                                           // 0000004A9790: D7600002
	v_cndmask_b32_e32 v0, v1, v136, vcc_lo                     // 0000004A9794: 02011101
	.long 0xd7006a15                                           // 0000004A9798: D7006A15
	v_cndmask_b32_e32 v1, v3, v11, vcc_lo                      // 0000004A979C: 02021703
	s_waitcnt lgkmcnt(0)                                       // 0000004A97A0: BF89FC07
	v_dual_sub_f32 v24, v13, v14 :: v_dual_sub_f32 v25, v15, v16// 0000004A97A4: C94A1D0D 1818210F
	v_add_co_ci_u32_e64 v22, null, v4, v12, vcc_lo             // 0000004A97AC: D5207C16 01AA1904
	.long 0xd73c000b                                           // 0000004A97B4: D73C000B
	v_cndmask_b32_e32 v1, 1, v17, vcc_lo                       // 0000004A97B8: 02022281
	.long 0xd73c0011                                           // 0000004A97BC: D73C0011
	v_cndmask_b32_e32 v1, 1, v19, vcc_lo                       // 0000004A97C0: 02022681
	v_dual_add_f32 v19, v13, v14 :: v_dual_add_f32 v20, v15, v16// 0000004A97C4: C9081D0D 1314210F
	v_add_f32_e32 v15, v24, v25                                // 0000004A97CC: 061E3318
	.long 0xd7600000                                           // 0000004A97D0: D7600000
	v_cndmask_b32_e32 v0, v1, v128, vcc_lo                     // 0000004A97D4: 02010101
	.long 0xd7006a0d                                           // 0000004A97D8: D7006A0D
	v_cndmask_b32_e32 v1, v3, v11, vcc_lo                      // 0000004A97DC: 02021703
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004A97E0: BF870211
	v_add_co_ci_u32_e64 v14, null, v4, v12, vcc_lo             // 0000004A97E4: D5207C0E 01AA1904
	v_mul_f32_e32 v12, 0x3db504f3, v15                         // 0000004A97EC: 10181EFF 3DB504F3
	.long 0xd7006a0f                                           // 0000004A97F4: D7006A0F
	v_cndmask_b32_e32 v1, v3, v17, vcc_lo                      // 0000004A97F8: 02022303
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004A97FC: BF870191
	v_add_co_ci_u32_e64 v16, null, v4, v18, vcc_lo             // 0000004A9800: D5207C10 01AA2504
	v_dual_mul_f32 v12, s2, v12 :: v_dual_sub_f32 v17, v24, v25// 0000004A9808: C8CA1802 0C103318
	v_sub_f32_e32 v18, v19, v20                                // 0000004A9810: 08242913
	v_add_f32_e32 v11, v19, v20                                // 0000004A9814: 06162913
	.long 0xd7600003                                           // 0000004A9818: D7600003
	v_cndmask_b32_e32 v0, v1, v144, vcc_lo                     // 0000004A981C: 02012101
	.long 0xd7600002                                           // 0000004A9820: D7600002
	v_cndmask_b32_e32 v0, v1, v137, vcc_lo                     // 0000004A9824: 02011301
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004A9828: BF870214
	v_dual_mul_f32 v17, 0x3db504f3, v17 :: v_dual_mul_f32 v18, 0x3db504f3, v18// 0000004A982C: C8C622FF 111224FF 3DB504F3
	v_dual_mul_f32 v11, 0x3db504f3, v11 :: v_dual_lshlrev_b32 v24, 9, v10// 0000004A9838: C8E216FF 0B181489 3DB504F3
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000004A9844: BF8701A2
	v_mul_f32_e32 v26, s4, v17                                 // 0000004A9848: 10342204
	v_or_b32_e32 v17, 0x60, v23                                // 0000004A984C: 38222EFF 00000060
	v_mul_f32_e32 v25, s0, v11                                 // 0000004A9854: 10321600
	.long 0x7f163880                                           // 0000004A9858: 7F163880
	.long 0x7e16398c                                           // 0000004A985C: 7E16398C
	v_xor_b32_e32 v23, v10, v2                                 // 0000004A9860: 3A2E050A
	.long 0xd7600000                                           // 0000004A9864: D7600000
	v_cndmask_b32_e32 v0, v1, v129, vcc_lo                     // 0000004A9868: 02010301
	.long 0x7e263999                                           // 0000004A986C: 7E263999
	.long 0x7f26398b                                           // 0000004A9870: 7F26398B
	v_and_b32_e32 v20, 1, v11                                  // 0000004A9874: 36281681
	v_lshl_add_u32 v23, v23, 2, v24                            // 0000004A9878: D6460017 04610517
	.long 0x7f38398b                                           // 0000004A9880: 7F38398B
	v_mul_f32_e32 v27, s3, v18                                 // 0000004A9884: 10362403
	v_mad_i64_i32 v[17:18], null, v17, s10, 0                  // 0000004A9888: D6FF7C11 02001511
	v_and_b32_e32 v29, 1, v19                                  // 0000004A9890: 363A2681
	v_add3_u32 v12, v12, v20, 0x7fff                           // 0000004A9894: D655000C 03FE290C 00007FFF
	ds_load_2addr_stride64_b32 v[19:20], v23 offset1:64        // 0000004A98A0: D8E04000 13000017
	ds_load_2addr_stride64_b32 v[23:24], v23 offset0:128 offset1:192// 0000004A98A8: D8E0C080 17000017
	.long 0x7e38399b                                           // 0000004A98B0: 7E38399B
	.long 0x7e16399a                                           // 0000004A98B4: 7E16399A
	v_add3_u32 v29, v25, v29, 0x7fff                           // 0000004A98B8: D655001D 03FE3B19 00007FFF
	s_clause 0x1                                               // 0000004A98C4: BF850001
	global_store_d16_hi_b16 v[21:22], v29, off                 // 0000004A98C8: DC960000 007C1D15
	global_store_d16_hi_b16 v[13:14], v12, off                 // 0000004A98D0: DC960000 007C0C0D
	.long 0xd73c0011                                           // 0000004A98D8: D73C0011
	v_cndmask_b32_e32 v1, 1, v17, vcc_lo                       // 0000004A98DC: 02022281
	v_and_b32_e32 v28, 1, v28                                  // 0000004A98E0: 36383881
	v_and_b32_e32 v30, 1, v11                                  // 0000004A98E4: 363C1681
	v_or_b32_e32 v10, s1, v10                                  // 0000004A98E8: 38141401
	.long 0xd7600003                                           // 0000004A98EC: D7600003
	v_cndmask_b32_e32 v0, v1, v145, vcc_lo                     // 0000004A98F0: 02012301
	v_or_b32_e32 v29, s1, v8                                   // 0000004A98F4: 383A1001
	.long 0xd7006a11                                           // 0000004A98F8: D7006A11
	v_cndmask_b32_e32 v1, v3, v17, vcc_lo                      // 0000004A98FC: 02022303
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000004A9900: D655001B 03FE391B 00007FFF
	v_add3_u32 v30, v26, v30, 0x7fff                           // 0000004A990C: D655001E 03FE3D1A 00007FFF
	v_add_co_ci_u32_e64 v18, null, v4, v18, vcc_lo             // 0000004A9918: D5207C12 01AA2504
	s_clause 0x1                                               // 0000004A9920: BF850001
	global_store_d16_hi_b16 v[15:16], v27, off                 // 0000004A9924: DC960000 007C1B0F
	global_store_d16_hi_b16 v[17:18], v30, off                 // 0000004A992C: DC960000 007C1E11
	s_waitcnt lgkmcnt(1)                                       // 0000004A9934: BF89FC17
	v_sub_f32_e32 v18, v19, v20                                // 0000004A9938: 08242913
	v_add_f32_e32 v19, v19, v20                                // 0000004A993C: 06262913
	s_waitcnt lgkmcnt(0)                                       // 0000004A9940: BF89FC07
	v_add_f32_e32 v21, v23, v24                                // 0000004A9944: 062A3117
	v_or_b32_e32 v14, 32, v10                                  // 0000004A9948: 381C14A0
	v_mad_i64_i32 v[25:26], null, v10, s10, 0                  // 0000004A994C: D6FF7C19 0200150A
	v_or_b32_e32 v22, 64, v10                                  // 0000004A9954: 382C14C0
	v_or_b32_e32 v10, 0x60, v10                                // 0000004A9958: 381414FF 00000060
	v_add_f32_e32 v17, v19, v21                                // 0000004A9960: 06222B13
	v_sub_f32_e32 v20, v23, v24                                // 0000004A9964: 08283117
	v_mad_i64_i32 v[14:15], null, v14, s10, 0                  // 0000004A9968: D6FF7C0E 0200150E
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000004A9970: BF8701B3
	v_mul_f32_e32 v17, 0x3db504f3, v17                         // 0000004A9974: 102222FF 3DB504F3
	.long 0xd73c000c                                           // 0000004A997C: D73C000C
	v_cndmask_b32_e32 v1, 1, v25, vcc_lo                       // 0000004A9980: 02023281
	v_lshlrev_b32_e32 v26, 9, v9                               // 0000004A9984: 30341289
	v_mul_f32_e32 v24, s0, v17                                 // 0000004A9988: 10302200
	v_add_f32_e32 v16, v18, v20                                // 0000004A998C: 06202912
	v_sub_f32_e32 v18, v18, v20                                // 0000004A9990: 08242912
	.long 0xd7600000                                           // 0000004A9994: D7600000
	v_cndmask_b32_e32 v0, v1, v153, vcc_lo                     // 0000004A9998: 02013301
	.long 0x7f28398b                                           // 0000004A999C: 7F28398B
	.long 0x7e283998                                           // 0000004A99A0: 7E283998
	.long 0xd73c000e                                           // 0000004A99A4: D73C000E
	v_cndmask_b32_e32 v1, 1, v14, vcc_lo                       // 0000004A99A8: 02021C81
	v_dual_mul_f32 v18, 0x3db504f3, v18 :: v_dual_sub_f32 v19, v19, v21// 0000004A99AC: C8CA24FF 12122B13 3DB504F3
	v_mul_f32_e32 v16, 0x3db504f3, v16                         // 0000004A99B8: 102020FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000004A99C0: BF870224
	v_and_b32_e32 v20, 1, v20                                  // 0000004A99C4: 36282881
	.long 0xd7006a0c                                           // 0000004A99C8: D7006A0C
	v_cndmask_b32_e32 v1, v3, v12, vcc_lo                      // 0000004A99CC: 02021903
	v_mul_f32_e32 v19, 0x3db504f3, v19                         // 0000004A99D0: 102626FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000004A99D8: BF870244
	v_mul_f32_e32 v23, s2, v16                                 // 0000004A99DC: 102E2002
	v_mad_i64_i32 v[16:17], null, v22, s10, 0                  // 0000004A99E0: D6FF7C10 02001516
	v_mul_f32_e32 v22, s0, v18                                 // 0000004A99E8: 102C2400
	v_add_co_ci_u32_e64 v13, null, v4, v13, vcc_lo             // 0000004A99EC: D5207C0D 01AA1B04
	.long 0x7e163997                                           // 0000004A99F4: 7E163997
	.long 0xd7006a0e                                           // 0000004A99F8: D7006A0E
	v_cndmask_b32_e32 v1, v3, v14, vcc_lo                      // 0000004A99FC: 02021D03
	v_mul_f32_e32 v25, s3, v19                                 // 0000004A9A00: 10322603
	v_add3_u32 v20, v24, v20, 0x7fff                           // 0000004A9A04: D6550014 03FE2918 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000004A9A10: BF870244
	v_and_b32_e32 v21, 1, v11                                  // 0000004A9A14: 362A1681
	v_xor_b32_e32 v24, v9, v2                                  // 0000004A9A18: 3A300509
	v_add_co_ci_u32_e64 v15, null, v4, v15, vcc_lo             // 0000004A9A1C: D5207C0F 01AA1F04
	.long 0x7e163996                                           // 0000004A9A24: 7E163996
	v_add3_u32 v21, v23, v21, 0x7fff                           // 0000004A9A28: D6550015 03FE2B17 00007FFF
	.long 0x7e2e3999                                           // 0000004A9A34: 7E2E3999
	.long 0x7f2e398b                                           // 0000004A9A38: 7F2E398B
	s_clause 0x1                                               // 0000004A9A3C: BF850001
	global_store_d16_hi_b16 v[12:13], v20, off                 // 0000004A9A40: DC960000 007C140C
	global_store_d16_hi_b16 v[14:15], v21, off                 // 0000004A9A48: DC960000 007C150E
	v_lshl_add_u32 v14, v24, 2, v26                            // 0000004A9A50: D646000E 04690518
	v_mad_i64_i32 v[18:19], null, v10, s10, 0                  // 0000004A9A58: D6FF7C12 0200150A
	v_and_b32_e32 v10, 1, v11                                  // 0000004A9A60: 36141681
	.long 0xd73c0010                                           // 0000004A9A64: D73C0010
	v_cndmask_b32_e32 v1, 1, v16, vcc_lo                       // 0000004A9A68: 02022081
	v_or_b32_e32 v21, s1, v9                                   // 0000004A9A6C: 382A1201
	ds_load_2addr_stride64_b32 v[12:13], v14 offset1:64        // 0000004A9A70: D8E04000 0C00000E
	v_and_b32_e32 v15, 1, v23                                  // 0000004A9A78: 361E2E81
	v_add3_u32 v20, v22, v10, 0x7fff                           // 0000004A9A7C: D6550014 03FE1516 00007FFF
	.long 0xd7600002                                           // 0000004A9A88: D7600002
	v_cndmask_b32_e32 v0, v1, v138, vcc_lo                     // 0000004A9A8C: 02011501
	.long 0xd73c0009                                           // 0000004A9A90: D73C0009
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 0000004A9A94: 02022481
	.long 0xd7006a10                                           // 0000004A9A98: D7006A10
	v_cndmask_b32_e32 v1, v3, v16, vcc_lo                      // 0000004A9A9C: 02022103
	v_add3_u32 v22, v25, v15, 0x7fff                           // 0000004A9AA0: D6550016 03FE1F19 00007FFF
	ds_load_2addr_stride64_b32 v[14:15], v14 offset0:128 offset1:192// 0000004A9AAC: D8E0C080 0E00000E
	v_add_co_ci_u32_e64 v17, null, v4, v17, vcc_lo             // 0000004A9AB4: D5207C11 01AA2304
	v_mad_i64_i32 v[18:19], null, v21, s10, 0                  // 0000004A9ABC: D6FF7C12 02001515
	.long 0xd7006a09                                           // 0000004A9AC4: D7006A09
	v_cndmask_b32_e32 v1, v3, v9, vcc_lo                       // 0000004A9AC8: 02021303
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004A9ACC: BF870001
	v_add_co_ci_u32_e64 v10, null, v4, v10, vcc_lo             // 0000004A9AD0: D5207C0A 01AA1504
	global_store_d16_hi_b16 v[16:17], v22, off                 // 0000004A9AD8: DC960000 007C1610
	v_or_b32_e32 v22, 32, v21                                  // 0000004A9AE0: 382C2AA0
	v_or_b32_e32 v23, 64, v21                                  // 0000004A9AE4: 382E2AC0
	.long 0xd73c0010                                           // 0000004A9AE8: D73C0010
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 0000004A9AEC: 02022481
	global_store_d16_hi_b16 v[9:10], v20, off                  // 0000004A9AF0: DC960000 007C1409
	s_waitcnt lgkmcnt(1)                                       // 0000004A9AF8: BF89FC17
	v_sub_f32_e32 v20, v12, v13                                // 0000004A9AFC: 08281B0C
	v_mad_i64_i32 v[9:10], null, v22, s10, 0                   // 0000004A9B00: D6FF7C09 02001516
	v_mad_i64_i32 v[18:19], null, v23, s10, 0                  // 0000004A9B08: D6FF7C12 02001517
	v_dual_add_f32 v22, v12, v13 :: v_dual_lshlrev_b32 v25, 9, v8// 0000004A9B10: C9221B0C 16181089
	.long 0xd7600000                                           // 0000004A9B18: D7600000
	v_cndmask_b32_e32 v0, v1, v130, vcc_lo                     // 0000004A9B1C: 02010501
	.long 0xd7600003                                           // 0000004A9B20: D7600003
	v_cndmask_b32_e32 v0, v1, v146, vcc_lo                     // 0000004A9B24: 02012501
	s_waitcnt lgkmcnt(0)                                       // 0000004A9B28: BF89FC07
	v_sub_f32_e32 v23, v14, v15                                // 0000004A9B2C: 082E1F0E
	v_add_f32_e32 v14, v14, v15                                // 0000004A9B30: 061C1F0E
	.long 0xd73c0009                                           // 0000004A9B34: D73C0009
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 0000004A9B38: 02021281
	.long 0xd73c000c                                           // 0000004A9B3C: D73C000C
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 0000004A9B40: 02022481
	.long 0x7f34398b                                           // 0000004A9B44: 7F34398B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000004A9B48: BF8701B4
	v_dual_add_f32 v15, v20, v23 :: v_dual_add_f32 v18, v22, v14// 0000004A9B4C: C9082F14 0F121D16
	v_sub_f32_e32 v14, v22, v14                                // 0000004A9B54: 081C1D16
	.long 0xd7006a10                                           // 0000004A9B58: D7006A10
	v_cndmask_b32_e32 v1, v3, v16, vcc_lo                      // 0000004A9B5C: 02022103
	v_dual_mul_f32 v15, 0x3db504f3, v15 :: v_dual_mul_f32 v18, 0x3db504f3, v18// 0000004A9B60: C8C61EFF 0F1224FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000004A9B6C: BF8701A3
	v_mul_f32_e32 v14, 0x3db504f3, v14                         // 0000004A9B70: 101C1CFF 3DB504F3
	v_add_co_ci_u32_e64 v17, null, v4, v17, vcc_lo             // 0000004A9B78: D5207C11 01AA2304
	v_mul_f32_e32 v19, s2, v15                                 // 0000004A9B80: 10261E02
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000004A9B84: BF870234
	v_dual_sub_f32 v15, v20, v23 :: v_dual_mul_f32 v22, s0, v18// 0000004A9B88: C9462F14 0F162400
	.long 0xd7600000                                           // 0000004A9B90: D7600000
	v_cndmask_b32_e32 v0, v1, v154, vcc_lo                     // 0000004A9B94: 02013501
	v_mul_f32_e32 v24, s3, v14                                 // 0000004A9B98: 10301C03
	.long 0x7e163993                                           // 0000004A9B9C: 7E163993
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004A9BA0: BF870004
	v_mul_f32_e32 v15, 0x3db504f3, v15                         // 0000004A9BA4: 101E1EFF 3DB504F3
	v_or_b32_e32 v14, 0x60, v21                                // 0000004A9BAC: 381C2AFF 00000060
	v_xor_b32_e32 v21, v8, v2                                  // 0000004A9BB4: 3A2A0508
	.long 0x7e243996                                           // 0000004A9BB8: 7E243996
	.long 0x7f24398b                                           // 0000004A9BBC: 7F24398B
	v_mul_f32_e32 v23, s0, v15                                 // 0000004A9BC0: 102E1E00
	v_and_b32_e32 v20, 1, v11                                  // 0000004A9BC4: 36281681
	v_lshl_add_u32 v21, v21, 2, v25                            // 0000004A9BC8: D6460015 04650515
	v_mad_i64_i32 v[14:15], null, v14, s10, 0                  // 0000004A9BD0: D6FF7C0E 0200150E
	v_and_b32_e32 v25, 1, v18                                  // 0000004A9BD8: 36322481
	.long 0x7e343998                                           // 0000004A9BDC: 7E343998
	v_add3_u32 v27, v19, v20, 0x7fff                           // 0000004A9BE0: D655001B 03FE2913 00007FFF
	ds_load_2addr_stride64_b32 v[18:19], v21 offset1:64        // 0000004A9BEC: D8E04000 12000015
	ds_load_2addr_stride64_b32 v[20:21], v21 offset0:128 offset1:192// 0000004A9BF4: D8E0C080 14000015
	.long 0x7e163997                                           // 0000004A9BFC: 7E163997
	.long 0xd7006a09                                           // 0000004A9C00: D7006A09
	v_cndmask_b32_e32 v1, v3, v9, vcc_lo                       // 0000004A9C04: 02021303
	.long 0xd73c000e                                           // 0000004A9C08: D73C000E
	v_cndmask_b32_e32 v1, 1, v14, vcc_lo                       // 0000004A9C0C: 02021C81
	v_and_b32_e32 v26, 1, v26                                  // 0000004A9C10: 36343481
	v_add3_u32 v8, v22, v25, 0x7fff                            // 0000004A9C14: D6550008 03FE3316 00007FFF
	v_add_co_ci_u32_e64 v10, null, v4, v10, vcc_lo             // 0000004A9C20: D5207C0A 01AA1504
	.long 0xd7600003                                           // 0000004A9C28: D7600003
	v_cndmask_b32_e32 v0, v1, v147, vcc_lo                     // 0000004A9C2C: 02012701
	v_and_b32_e32 v28, 1, v11                                  // 0000004A9C30: 36381681
	.long 0xd7006a0c                                           // 0000004A9C34: D7006A0C
	v_cndmask_b32_e32 v1, v3, v12, vcc_lo                      // 0000004A9C38: 02021903
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004A9C3C: BF870001
	v_add_co_ci_u32_e64 v13, null, v4, v13, vcc_lo             // 0000004A9C40: D5207C0D 01AA1B04
	.long 0xd7006a0e                                           // 0000004A9C48: D7006A0E
	v_cndmask_b32_e32 v1, v3, v14, vcc_lo                      // 0000004A9C4C: 02021D03
	v_add3_u32 v24, v24, v26, 0x7fff                           // 0000004A9C50: D6550018 03FE3518 00007FFF
	s_clause 0x1                                               // 0000004A9C5C: BF850001
	global_store_d16_hi_b16 v[16:17], v8, off                  // 0000004A9C60: DC960000 007C0810
	global_store_d16_hi_b16 v[9:10], v27, off                  // 0000004A9C68: DC960000 007C1B09
	v_or_b32_e32 v10, 32, v29                                  // 0000004A9C70: 38143AA0
	v_add3_u32 v25, v23, v28, 0x7fff                           // 0000004A9C74: D6550019 03FE3917 00007FFF
	v_add_co_ci_u32_e64 v15, null, v4, v15, vcc_lo             // 0000004A9C80: D5207C0F 01AA1F04
	s_clause 0x1                                               // 0000004A9C88: BF850001
	global_store_d16_hi_b16 v[12:13], v24, off                 // 0000004A9C8C: DC960000 007C180C
	global_store_d16_hi_b16 v[14:15], v25, off                 // 0000004A9C94: DC960000 007C190E
	v_mad_i64_i32 v[12:13], null, v10, s10, 0                  // 0000004A9C9C: D6FF7C0C 0200150A
	s_waitcnt lgkmcnt(0)                                       // 0000004A9CA4: BF89FC07
	v_dual_sub_f32 v10, v18, v19 :: v_dual_sub_f32 v17, v20, v21// 0000004A9CA8: C94A2712 0A102B14
	.long 0xd7600000                                           // 0000004A9CB0: D7600000
	v_cndmask_b32_e32 v0, v1, v131, vcc_lo                     // 0000004A9CB4: 02010701
	v_mad_i64_i32 v[22:23], null, v29, s10, 0                  // 0000004A9CB8: D6FF7C16 0200151D
	.long 0xd7600002                                           // 0000004A9CC0: D7600002
	v_cndmask_b32_e32 v0, v1, v139, vcc_lo                     // 0000004A9CC4: 02011701
	v_or_b32_e32 v27, s1, v6                                   // 0000004A9CC8: 38360C01
	v_add_f32_e32 v14, v10, v17                                // 0000004A9CCC: 061C230A
	v_sub_f32_e32 v10, v10, v17                                // 0000004A9CD0: 0814230A
	.long 0x7f22398b                                           // 0000004A9CD4: 7F22398B
	v_add_f32_e32 v16, v18, v19                                // 0000004A9CD8: 06202712
	v_add_f32_e32 v18, v20, v21                                // 0000004A9CDC: 06242B14
	.long 0xd73c0008                                           // 0000004A9CE0: D73C0008
	v_cndmask_b32_e32 v1, 1, v22, vcc_lo                       // 0000004A9CE4: 02022C81
	v_dual_mul_f32 v14, 0x3db504f3, v14 :: v_dual_lshlrev_b32 v23, 9, v7// 0000004A9CE8: C8E21CFF 0E160E89 3DB504F3
	v_or_b32_e32 v19, 64, v29                                  // 0000004A9CF4: 38263AC0
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004A9CF8: BF870004
	v_add_f32_e32 v15, v16, v18                                // 0000004A9CFC: 061E2510
	v_mul_f32_e32 v10, 0x3db504f3, v10                         // 0000004A9D00: 101414FF 3DB504F3
	.long 0xd73c000c                                           // 0000004A9D08: D73C000C
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 0000004A9D0C: 02021881
	v_mul_f32_e32 v20, s2, v14                                 // 0000004A9D10: 10281C02
	.long 0xd7600002                                           // 0000004A9D14: D7600002
	v_cndmask_b32_e32 v0, v1, v140, vcc_lo                     // 0000004A9D18: 02011901
	v_mul_f32_e32 v15, 0x3db504f3, v15                         // 0000004A9D1C: 101E1EFF 3DB504F3
	.long 0xd7006a08                                           // 0000004A9D24: D7006A08
	v_cndmask_b32_e32 v1, v3, v8, vcc_lo                       // 0000004A9D28: 02021103
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000004A9D2C: BF870224
	.long 0x7e163994                                           // 0000004A9D30: 7E163994
	v_add_co_ci_u32_e64 v9, null, v4, v9, vcc_lo               // 0000004A9D34: D5207C09 01AA1304
	v_mul_f32_e32 v21, s0, v15                                 // 0000004A9D3C: 102A1E00
	.long 0xd7600000                                           // 0000004A9D40: D7600000
	v_cndmask_b32_e32 v0, v1, v155, vcc_lo                     // 0000004A9D44: 02013701
	v_mad_i64_i32 v[14:15], null, v19, s10, 0                  // 0000004A9D48: D6FF7C0E 02001513
	.long 0xd7006a0c                                           // 0000004A9D50: D7006A0C
	v_cndmask_b32_e32 v1, v3, v12, vcc_lo                      // 0000004A9D54: 02021903
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004A9D58: BF870214
	.long 0x7e223995                                           // 0000004A9D5C: 7E223995
	v_mul_f32_e32 v10, s0, v10                                 // 0000004A9D60: 10141400
	v_xor_b32_e32 v22, v7, v2                                  // 0000004A9D64: 3A2C0507
	v_add_co_ci_u32_e64 v13, null, v4, v13, vcc_lo             // 0000004A9D68: D5207C0D 01AA1B04
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004A9D70: BF870004
	v_dual_sub_f32 v16, v16, v18 :: v_dual_and_b32 v17, 1, v17 // 0000004A9D74: C9642510 10102281
	v_and_b32_e32 v18, 1, v11                                  // 0000004A9D7C: 36241681
	.long 0x7e16398a                                           // 0000004A9D80: 7E16398A
	.long 0xd73c000e                                           // 0000004A9D84: D73C000E
	v_cndmask_b32_e32 v1, 1, v14, vcc_lo                       // 0000004A9D88: 02021C81
	.long 0xd7600000                                           // 0000004A9D8C: D7600000
	v_cndmask_b32_e32 v0, v1, v132, vcc_lo                     // 0000004A9D90: 02010901
	v_mul_f32_e32 v16, 0x3db504f3, v16                         // 0000004A9D94: 102020FF 3DB504F3
	v_add3_u32 v18, v20, v18, 0x7fff                           // 0000004A9D9C: D6550012 03FE2514 00007FFF
	v_add3_u32 v20, v21, v17, 0x7fff                           // 0000004A9DA8: D6550014 03FE2315 00007FFF
	.long 0x7f2a398b                                           // 0000004A9DB4: 7F2A398B
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004A9DB8: BF870004
	v_dual_mul_f32 v19, s3, v16 :: v_dual_and_b32 v24, 1, v11  // 0000004A9DBC: C8E42003 13181681
	v_or_b32_e32 v16, 0x60, v29                                // 0000004A9DC4: 38203AFF 00000060
	s_clause 0x1                                               // 0000004A9DCC: BF850001
	global_store_d16_hi_b16 v[8:9], v20, off                   // 0000004A9DD0: DC960000 007C1408
	global_store_d16_hi_b16 v[12:13], v18, off                 // 0000004A9DD8: DC960000 007C120C
	v_lshl_add_u32 v12, v22, 2, v23                            // 0000004A9DE0: D646000C 045D0516
	v_add3_u32 v18, v10, v24, 0x7fff                           // 0000004A9DE8: D6550012 03FE310A 00007FFF
	.long 0x7e2a3993                                           // 0000004A9DF4: 7E2A3993
	v_mad_i64_i32 v[16:17], null, v16, s10, 0                  // 0000004A9DF8: D6FF7C10 02001510
	v_or_b32_e32 v20, s1, v7                                   // 0000004A9E00: 38280E01
	ds_load_2addr_stride64_b32 v[9:10], v12 offset1:64         // 0000004A9E04: D8E04000 0900000C
	.long 0xd7006a0e                                           // 0000004A9E0C: D7006A0E
	v_cndmask_b32_e32 v1, v3, v14, vcc_lo                      // 0000004A9E10: 02021D03
	v_and_b32_e32 v13, 1, v21                                  // 0000004A9E14: 361A2A81
	v_add_co_ci_u32_e64 v15, null, v4, v15, vcc_lo             // 0000004A9E18: D5207C0F 01AA1F04
	.long 0xd73c0007                                           // 0000004A9E20: D73C0007
	v_cndmask_b32_e32 v1, 1, v16, vcc_lo                       // 0000004A9E24: 02022081
	v_mad_i64_i32 v[16:17], null, v20, s10, 0                  // 0000004A9E28: D6FF7C10 02001514
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000004A9E30: BF8700D4
	v_add3_u32 v19, v19, v13, 0x7fff                           // 0000004A9E34: D6550013 03FE1B13 00007FFF
	ds_load_2addr_stride64_b32 v[12:13], v12 offset0:128 offset1:192// 0000004A9E40: D8E0C080 0C00000C
	v_or_b32_e32 v21, 64, v20                                  // 0000004A9E48: 382A28C0
	.long 0xd7600003                                           // 0000004A9E4C: D7600003
	v_cndmask_b32_e32 v0, v1, v148, vcc_lo                     // 0000004A9E50: 02012901
	.long 0xd7006a07                                           // 0000004A9E54: D7006A07
	v_cndmask_b32_e32 v1, v3, v7, vcc_lo                       // 0000004A9E58: 02020F03
	v_add_co_ci_u32_e64 v8, null, v4, v8, vcc_lo               // 0000004A9E5C: D5207C08 01AA1104
	global_store_d16_hi_b16 v[14:15], v19, off                 // 0000004A9E64: DC960000 007C130E
	v_or_b32_e32 v19, 32, v20                                  // 0000004A9E6C: 382628A0
	.long 0xd73c000e                                           // 0000004A9E70: D73C000E
	v_cndmask_b32_e32 v1, 1, v16, vcc_lo                       // 0000004A9E74: 02022081
	v_mad_i64_i32 v[16:17], null, v21, s10, 0                  // 0000004A9E78: D6FF7C10 02001515
	global_store_d16_hi_b16 v[7:8], v18, off                   // 0000004A9E80: DC960000 007C1207
	s_waitcnt lgkmcnt(1)                                       // 0000004A9E88: BF89FC17
	v_sub_f32_e32 v18, v9, v10                                 // 0000004A9E8C: 08241509
	v_mad_i64_i32 v[7:8], null, v19, s10, 0                    // 0000004A9E90: D6FF7C07 02001513
	v_add_f32_e32 v19, v9, v10                                 // 0000004A9E98: 06261509
	.long 0x7f30398b                                           // 0000004A9E9C: 7F30398B
	.long 0xd7006a0e                                           // 0000004A9EA0: D7006A0E
	v_cndmask_b32_e32 v1, v3, v14, vcc_lo                      // 0000004A9EA4: 02021D03
	.long 0xd73c0009                                           // 0000004A9EA8: D73C0009
	v_cndmask_b32_e32 v1, 1, v16, vcc_lo                       // 0000004A9EAC: 02022081
	v_add_co_ci_u32_e64 v15, null, v4, v15, vcc_lo             // 0000004A9EB0: D5207C0F 01AA1F04
	s_waitcnt lgkmcnt(0)                                       // 0000004A9EB8: BF89FC07
	v_sub_f32_e32 v21, v12, v13                                // 0000004A9EBC: 082A1B0C
	v_add_f32_e32 v12, v12, v13                                // 0000004A9EC0: 06181B0C
	.long 0xd73c0007                                           // 0000004A9EC4: D73C0007
	v_cndmask_b32_e32 v1, 1, v7, vcc_lo                        // 0000004A9EC8: 02020E81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000004A9ECC: BF870232
	v_add_f32_e32 v16, v19, v12                                // 0000004A9ED0: 06201913
	v_sub_f32_e32 v12, v19, v12                                // 0000004A9ED4: 08181913
	v_xor_b32_e32 v19, v6, v2                                  // 0000004A9ED8: 3A260506
	.long 0xd7006a07                                           // 0000004A9EDC: D7006A07
	v_cndmask_b32_e32 v1, v3, v7, vcc_lo                       // 0000004A9EE0: 02020F03
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004A9EE4: BF870214
	v_mul_f32_e32 v16, 0x3db504f3, v16                         // 0000004A9EE8: 102020FF 3DB504F3
	v_mul_f32_e32 v12, 0x3db504f3, v12                         // 0000004A9EF0: 101818FF 3DB504F3
	v_add_co_ci_u32_e64 v8, null, v4, v8, vcc_lo               // 0000004A9EF8: D5207C08 01AA1104
	.long 0xd7006a09                                           // 0000004A9F00: D7006A09
	v_cndmask_b32_e32 v1, v3, v9, vcc_lo                       // 0000004A9F04: 02021303
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000004A9F08: BF870253
	v_mul_f32_e32 v23, s3, v12                                 // 0000004A9F0C: 102E1803
	v_add_f32_e32 v13, v18, v21                                // 0000004A9F10: 061A2B12
	v_or_b32_e32 v12, 0x60, v20                                // 0000004A9F14: 381828FF 00000060
	v_lshlrev_b32_e32 v20, 9, v6                               // 0000004A9F1C: 30280C89
	v_add_co_ci_u32_e64 v10, null, v4, v10, vcc_lo             // 0000004A9F20: D5207C0A 01AA1504
	v_mul_f32_e32 v13, 0x3db504f3, v13                         // 0000004A9F28: 101A1AFF 3DB504F3
	.long 0x7e303997                                           // 0000004A9F30: 7E303997
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000004A9F34: BF870224
	v_lshl_add_u32 v19, v19, 2, v20                            // 0000004A9F38: D6460013 04510513
	.long 0xd7600003                                           // 0000004A9F40: D7600003
	v_cndmask_b32_e32 v0, v1, v149, vcc_lo                     // 0000004A9F44: 02012B01
	v_mul_f32_e32 v17, s2, v13                                 // 0000004A9F48: 10221A02
	v_sub_f32_e32 v13, v18, v21                                // 0000004A9F4C: 081A2B12
	v_mul_f32_e32 v21, s0, v16                                 // 0000004A9F50: 102A2000
	.long 0xd7600000                                           // 0000004A9F54: D7600000
	v_cndmask_b32_e32 v0, v1, v156, vcc_lo                     // 0000004A9F58: 02013901
	.long 0x7f20398b                                           // 0000004A9F5C: 7F20398B
	.long 0x7e163991                                           // 0000004A9F60: 7E163991
	v_mul_f32_e32 v13, 0x3db504f3, v13                         // 0000004A9F64: 101A1AFF 3DB504F3
	.long 0x7e203995                                           // 0000004A9F6C: 7E203995
	v_and_b32_e32 v24, 1, v24                                  // 0000004A9F70: 36303081
	.long 0xd7600002                                           // 0000004A9F74: D7600002
	v_cndmask_b32_e32 v0, v1, v141, vcc_lo                     // 0000004A9F78: 02011B01
	v_and_b32_e32 v18, 1, v11                                  // 0000004A9F7C: 36241681
	v_mul_f32_e32 v22, s0, v13                                 // 0000004A9F80: 102C1A00
	v_mad_i64_i32 v[12:13], null, v12, s10, 0                  // 0000004A9F84: D6FF7C0C 0200150C
	v_and_b32_e32 v20, 1, v16                                  // 0000004A9F8C: 36282081
	v_add3_u32 v23, v23, v24, 0x7fff                           // 0000004A9F90: D6550017 03FE3117 00007FFF
	v_add3_u32 v25, v17, v18, 0x7fff                           // 0000004A9F9C: D6550019 03FE2511 00007FFF
	ds_load_2addr_stride64_b32 v[16:17], v19 offset1:64        // 0000004A9FA8: D8E04000 10000013
	ds_load_2addr_stride64_b32 v[18:19], v19 offset0:128 offset1:192// 0000004A9FB0: D8E0C080 12000013
	.long 0x7e163996                                           // 0000004A9FB8: 7E163996
	v_add3_u32 v6, v21, v20, 0x7fff                            // 0000004A9FBC: D6550006 03FE2915 00007FFF
	s_clause 0x1                                               // 0000004A9FC8: BF850001
	global_store_d16_hi_b16 v[14:15], v6, off                  // 0000004A9FCC: DC960000 007C060E
	global_store_d16_hi_b16 v[7:8], v25, off                   // 0000004A9FD4: DC960000 007C1907
	.long 0xd73c000c                                           // 0000004A9FDC: D73C000C
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 0000004A9FE0: 02021881
	v_and_b32_e32 v26, 1, v11                                  // 0000004A9FE4: 36341681
	v_mad_i64_i32 v[20:21], null, v27, s10, 0                  // 0000004A9FE8: D6FF7C14 0200151B
	.long 0xd7600000                                           // 0000004A9FF0: D7600000
	v_cndmask_b32_e32 v0, v1, v133, vcc_lo                     // 0000004A9FF4: 02010B01
	v_or_b32_e32 v8, 32, v27                                   // 0000004A9FF8: 381036A0
	.long 0xd7006a0c                                           // 0000004A9FFC: D7006A0C
	v_cndmask_b32_e32 v1, v3, v12, vcc_lo                      // 0000004AA000: 02021903
	v_add3_u32 v22, v22, v26, 0x7fff                           // 0000004AA004: D6550016 03FE3516 00007FFF
	v_add_co_ci_u32_e64 v13, null, v4, v13, vcc_lo             // 0000004AA010: D5207C0D 01AA1B04
	s_clause 0x1                                               // 0000004AA018: BF850001
	global_store_d16_hi_b16 v[9:10], v23, off                  // 0000004AA01C: DC960000 007C1709
	global_store_d16_hi_b16 v[12:13], v22, off                 // 0000004AA024: DC960000 007C160C
	s_waitcnt lgkmcnt(1)                                       // 0000004AA02C: BF89FC17
	v_sub_f32_e32 v10, v16, v17                                // 0000004AA030: 08142310
	s_waitcnt lgkmcnt(0)                                       // 0000004AA034: BF89FC07
	v_dual_add_f32 v14, v16, v17 :: v_dual_sub_f32 v15, v18, v19// 0000004AA038: C90A2310 0E0E2712
	v_add_f32_e32 v16, v18, v19                                // 0000004AA040: 06202712
	.long 0xd73c0006                                           // 0000004AA044: D73C0006
	v_cndmask_b32_e32 v1, 1, v20, vcc_lo                       // 0000004AA048: 02022881
	v_or_b32_e32 v12, 64, v27                                  // 0000004AA04C: 381836C0
	v_or_b32_e32 v19, 0x60, v27                                // 0000004AA050: 382636FF 00000060
	v_add_f32_e32 v17, v10, v15                                // 0000004AA058: 06221F0A
	v_add_f32_e32 v18, v14, v16                                // 0000004AA05C: 0624210E
	v_sub_f32_e32 v14, v14, v16                                // 0000004AA060: 081C210E
	v_sub_f32_e32 v10, v10, v15                                // 0000004AA064: 08141F0A
	.long 0x7f1e398b                                           // 0000004AA068: 7F1E398B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004AA06C: BF870214
	v_dual_mul_f32 v17, 0x3db504f3, v17 :: v_dual_mul_f32 v18, 0x3db504f3, v18// 0000004AA070: C8C622FF 111224FF 3DB504F3
	v_mul_f32_e32 v14, 0x3db504f3, v14                         // 0000004AA07C: 101C1CFF 3DB504F3
	v_lshlrev_b32_e32 v16, 9, v5                               // 0000004AA084: 30200A89
	v_mad_i64_i32 v[8:9], null, v8, s10, 0                     // 0000004AA088: D6FF7C08 02001508
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004AA090: BF870214
	v_dual_mul_f32 v20, s2, v17 :: v_dual_mul_f32 v17, s0, v18 // 0000004AA094: C8C62202 14102400
	v_mul_f32_e32 v22, s3, v14                                 // 0000004AA09C: 102C1C03
	.long 0x7f24398b                                           // 0000004AA0A0: 7F24398B
	v_mad_i64_i32 v[12:13], null, v12, s10, 0                  // 0000004AA0A4: D6FF7C0C 0200150C
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004AA0AC: BF870004
	.long 0x7e163994                                           // 0000004AA0B0: 7E163994
	.long 0x7e1e3991                                           // 0000004AA0B4: 7E1E3991
	.long 0x7e243996                                           // 0000004AA0B8: 7E243996
	.long 0xd73c0008                                           // 0000004AA0BC: D73C0008
	v_cndmask_b32_e32 v1, 1, v8, vcc_lo                        // 0000004AA0C0: 02021081
	.long 0xd7600000                                           // 0000004AA0C4: D7600000
	v_cndmask_b32_e32 v0, v1, v157, vcc_lo                     // 0000004AA0C8: 02013B01
	v_mul_f32_e32 v10, 0x3db504f3, v10                         // 0000004AA0CC: 101414FF 3DB504F3
	v_and_b32_e32 v14, 1, v15                                  // 0000004AA0D4: 361C1E81
	v_xor_b32_e32 v15, v5, v2                                  // 0000004AA0D8: 3A1E0505
	v_and_b32_e32 v25, 1, v18                                  // 0000004AA0DC: 36322481
	.long 0xd73c000c                                           // 0000004AA0E0: D73C000C
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 0000004AA0E4: 02021881
	.long 0xd7006a06                                           // 0000004AA0E8: D7006A06
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000004AA0EC: 02020D03
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004AA0F0: BF870004
	v_lshl_add_u32 v23, v15, 2, v16                            // 0000004AA0F4: D6460017 0441050F
	v_add3_u32 v24, v17, v14, 0x7fff                           // 0000004AA0FC: D6550018 03FE1D11 00007FFF
	v_mad_i64_i32 v[14:15], null, v19, s10, 0                  // 0000004AA108: D6FF7C0E 02001513
	ds_load_2addr_stride64_b32 v[16:17], v23 offset1:64        // 0000004AA110: D8E04000 10000017
	ds_load_2addr_stride64_b32 v[18:19], v23 offset0:128 offset1:192// 0000004AA118: D8E0C080 12000017
	v_dual_mul_f32 v10, s0, v10 :: v_dual_and_b32 v21, 1, v11  // 0000004AA120: C8E41400 0A141681
	v_add_co_ci_u32_e64 v7, null, v4, v7, vcc_lo               // 0000004AA128: D5207C07 01AA0F04
	.long 0xd7006a08                                           // 0000004AA130: D7006A08
	v_cndmask_b32_e32 v1, v3, v8, vcc_lo                       // 0000004AA134: 02021103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004AA138: BF870001
	v_add_co_ci_u32_e64 v9, null, v4, v9, vcc_lo               // 0000004AA13C: D5207C09 01AA1304
	.long 0xd7006a0c                                           // 0000004AA144: D7006A0C
	v_cndmask_b32_e32 v1, v3, v12, vcc_lo                      // 0000004AA148: 02021903
	.long 0x7e16398a                                           // 0000004AA14C: 7E16398A
	v_add_co_ci_u32_e64 v13, null, v4, v13, vcc_lo             // 0000004AA150: D5207C0D 01AA1B04
	v_add3_u32 v20, v20, v21, 0x7fff                           // 0000004AA158: D6550014 03FE2B14 00007FFF
	v_add3_u32 v21, v22, v25, 0x7fff                           // 0000004AA164: D6550015 03FE3316 00007FFF
	global_store_d16_hi_b16 v[6:7], v24, off                   // 0000004AA170: DC960000 007C1806
	v_or_b32_e32 v22, s1, v5                                   // 0000004AA178: 382C0A01
	.long 0xd73c0005                                           // 0000004AA17C: D73C0005
	v_cndmask_b32_e32 v1, 1, v14, vcc_lo                       // 0000004AA180: 02021C81
	v_and_b32_e32 v7, 1, v11                                   // 0000004AA184: 360E1681
	s_clause 0x1                                               // 0000004AA188: BF850001
	global_store_d16_hi_b16 v[8:9], v20, off                   // 0000004AA18C: DC960000 007C1408
	global_store_d16_hi_b16 v[12:13], v21, off                 // 0000004AA194: DC960000 007C150C
	s_waitcnt lgkmcnt(1)                                       // 0000004AA19C: BF89FC17
	v_sub_f32_e32 v12, v16, v17                                // 0000004AA1A0: 08182310
	s_waitcnt lgkmcnt(0)                                       // 0000004AA1A4: BF89FC07
	v_dual_add_f32 v13, v16, v17 :: v_dual_add_f32 v16, v18, v19// 0000004AA1A8: C9082310 0D102712
	.long 0xd7006a05                                           // 0000004AA1B0: D7006A05
	v_cndmask_b32_e32 v1, v3, v5, vcc_lo                       // 0000004AA1B4: 02020B03
	v_add3_u32 v14, v10, v7, 0x7fff                            // 0000004AA1B8: D655000E 03FE0F0A 00007FFF
	v_add_co_ci_u32_e64 v6, null, v4, v6, vcc_lo               // 0000004AA1C4: D5207C06 01AA0D04
	v_sub_f32_e32 v15, v18, v19                                // 0000004AA1CC: 081E2712
	v_add_f32_e32 v17, v13, v16                                // 0000004AA1D0: 0622210D
	.long 0xd7600000                                           // 0000004AA1D4: D7600000
	v_cndmask_b32_e32 v0, v1, v134, vcc_lo                     // 0000004AA1D8: 02010D01
	global_store_d16_hi_b16 v[5:6], v14, off                   // 0000004AA1DC: DC960000 007C0E05
	.long 0xd7600002                                           // 0000004AA1E4: D7600002
	v_cndmask_b32_e32 v0, v1, v142, vcc_lo                     // 0000004AA1E8: 02011D01
	v_dual_add_f32 v14, v12, v15 :: v_dual_mul_f32 v17, 0x3db504f3, v17// 0000004AA1EC: C9061F0C 0E1022FF 3DB504F3
	v_sub_f32_e32 v13, v13, v16                                // 0000004AA1F8: 081A210D
	v_or_b32_e32 v9, 32, v22                                   // 0000004AA1FC: 38122CA0
	.long 0x7f24398b                                           // 0000004AA200: 7F24398B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000004AA204: BF8701B4
	v_dual_mul_f32 v14, 0x3db504f3, v14 :: v_dual_mul_f32 v17, s0, v17// 0000004AA208: C8C61CFF 0E102200 3DB504F3
	.long 0xd7600000                                           // 0000004AA214: D7600000
	v_cndmask_b32_e32 v0, v1, v150, vcc_lo                     // 0000004AA218: 02012D01
	v_dual_sub_f32 v12, v12, v15 :: v_dual_mul_f32 v13, 0x3db504f3, v13// 0000004AA21C: C9461F0C 0C0C1AFF 3DB504F3
	v_mul_f32_e32 v14, s2, v14                                 // 0000004AA228: 101C1C02
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004AA22C: BF870004
	.long 0x7e243991                                           // 0000004AA230: 7E243991
	v_mad_i64_i32 v[7:8], null, v22, s10, 0                    // 0000004AA234: D6FF7C07 02001516
	v_mad_i64_i32 v[9:10], null, v9, s10, 0                    // 0000004AA23C: D6FF7C09 02001509
	.long 0xd7600002                                           // 0000004AA244: D7600002
	v_cndmask_b32_e32 v0, v1, v158, vcc_lo                     // 0000004AA248: 02013D01
	.long 0x7e16398e                                           // 0000004AA24C: 7E16398E
	v_and_b32_e32 v16, 1, v18                                  // 0000004AA250: 36202481
	v_mul_f32_e32 v12, 0x3db504f3, v12                         // 0000004AA254: 101818FF 3DB504F3
	v_mul_f32_e32 v18, s0, v13                                 // 0000004AA25C: 10241A00
	v_xor_b32_e32 v2, v0, v2                                   // 0000004AA260: 3A040500
	.long 0xd73c0005                                           // 0000004AA264: D73C0005
	v_cndmask_b32_e32 v1, 1, v7, vcc_lo                        // 0000004AA268: 02020E81
	.long 0xd73c0007                                           // 0000004AA26C: D73C0007
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 0000004AA270: 02021281
	v_or_b32_e32 v9, 64, v22                                   // 0000004AA274: 38122CC0
	v_and_b32_e32 v15, 1, v11                                  // 0000004AA278: 361E1681
	v_mul_f32_e32 v23, s2, v12                                 // 0000004AA27C: 102E1802
	v_lshlrev_b32_e32 v12, 9, v0                               // 0000004AA280: 30180089
	.long 0x7e1a3992                                           // 0000004AA284: 7E1A3992
	.long 0x7f1a398b                                           // 0000004AA288: 7F1A398B
	v_mad_i64_i32 v[9:10], null, v9, s10, 0                    // 0000004AA28C: D6FF7C09 02001509
	v_add3_u32 v20, v14, v15, 0x7fff                           // 0000004AA294: D6550014 03FE1F0E 00007FFF
	v_or_b32_e32 v14, 0x60, v22                                // 0000004AA2A0: 381C2CFF 00000060
	v_lshl_add_u32 v2, v2, 2, v12                              // 0000004AA2A8: D6460002 04310502
	v_or_b32_e32 v22, s1, v0                                   // 0000004AA2B0: 382C0001
	v_and_b32_e32 v0, 1, v13                                   // 0000004AA2B4: 36001A81
	.long 0xd7006a05                                           // 0000004AA2B8: D7006A05
	v_cndmask_b32_e32 v1, v3, v5, vcc_lo                       // 0000004AA2BC: 02020B03
	v_mad_i64_i32 v[12:13], null, v14, s10, 0                  // 0000004AA2C0: D6FF7C0C 0200150E
	ds_load_2addr_stride64_b32 v[14:15], v2 offset1:64         // 0000004AA2C8: D8E04000 0E000002
	v_add3_u32 v0, v18, v0, 0x7fff                             // 0000004AA2D0: D6550000 03FE0112 00007FFF
	ds_load_2addr_stride64_b32 v[18:19], v2 offset0:128 offset1:192// 0000004AA2DC: D8E0C080 12000002
	.long 0xd73c0009                                           // 0000004AA2E4: D73C0009
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 0000004AA2E8: 02021281
	v_add_co_ci_u32_e64 v6, null, v4, v6, vcc_lo               // 0000004AA2EC: D5207C06 01AA0D04
	.long 0xd7006a07                                           // 0000004AA2F4: D7006A07
	v_cndmask_b32_e32 v1, v3, v7, vcc_lo                       // 0000004AA2F8: 02020F03
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004AA2FC: BF870211
	v_add_co_ci_u32_e64 v8, null, v4, v8, vcc_lo               // 0000004AA300: D5207C08 01AA1104
	.long 0xd7006a09                                           // 0000004AA308: D7006A09
	v_cndmask_b32_e32 v1, v3, v9, vcc_lo                       // 0000004AA30C: 02021303
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004AA310: BF870001
	v_add_co_ci_u32_e64 v10, null, v4, v10, vcc_lo             // 0000004AA314: D5207C0A 01AA1504
	v_add3_u32 v21, v17, v16, 0x7fff                           // 0000004AA31C: D6550015 03FE2111 00007FFF
	s_clause 0x2                                               // 0000004AA328: BF850002
	global_store_d16_hi_b16 v[5:6], v21, off                   // 0000004AA32C: DC960000 007C1505
	global_store_d16_hi_b16 v[7:8], v20, off                   // 0000004AA334: DC960000 007C1407
	global_store_d16_hi_b16 v[9:10], v0, off                   // 0000004AA33C: DC960000 007C0009
	v_add_nc_u32_e32 v0, 32, v22                               // 0000004AA344: 4A002CA0
	v_mad_i64_i32 v[16:17], null, v22, s10, 0                  // 0000004AA348: D6FF7C10 02001516
	s_waitcnt lgkmcnt(1)                                       // 0000004AA350: BF89FC17
	v_add_f32_e32 v2, v14, v15                                 // 0000004AA354: 06041F0E
	.long 0xd73c0005                                           // 0000004AA358: D73C0005
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 0000004AA35C: 02021881
	v_or_b32_e32 v12, 64, v22                                  // 0000004AA360: 38182CC0
	v_mad_i64_i32 v[9:10], null, v0, s10, 0                    // 0000004AA364: D6FF7C09 02001500
	v_sub_f32_e32 v0, v14, v15                                 // 0000004AA36C: 08001F0E
	s_waitcnt lgkmcnt(0)                                       // 0000004AA370: BF89FC07
	v_sub_f32_e32 v14, v18, v19                                // 0000004AA374: 081C2712
	v_add_f32_e32 v15, v18, v19                                // 0000004AA378: 061E2712
	.long 0xd73c0007                                           // 0000004AA37C: D73C0007
	v_cndmask_b32_e32 v1, 1, v16, vcc_lo                       // 0000004AA380: 02022081
	v_mad_i64_i32 v[12:13], null, v12, s10, 0                  // 0000004AA384: D6FF7C0C 0200150C
	.long 0xd7600001                                           // 0000004AA38C: D7600001
	v_cndmask_b32_e32 v0, v1, v143, vcc_lo                     // 0000004AA390: 02011F01
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000004AA394: BF870244
	v_dual_add_f32 v16, v0, v14 :: v_dual_add_f32 v17, v2, v15 // 0000004AA398: C9081D00 10101F02
	v_sub_f32_e32 v0, v0, v14                                  // 0000004AA3A0: 08001D00
	v_sub_f32_e32 v2, v2, v15                                  // 0000004AA3A4: 08041F02
	.long 0x7e163997                                           // 0000004AA3A8: 7E163997
	v_mul_f32_e32 v16, 0x3db504f3, v16                         // 0000004AA3AC: 102020FF 3DB504F3
	.long 0xd7600000                                           // 0000004AA3B4: D7600000
	v_cndmask_b32_e32 v0, v1, v135, vcc_lo                     // 0000004AA3B8: 02010F01
	v_mul_f32_e32 v17, 0x3db504f3, v17                         // 0000004AA3BC: 102222FF 3DB504F3
	.long 0xd7600003                                           // 0000004AA3C4: D7600003
	v_cndmask_b32_e32 v0, v1, v159, vcc_lo                     // 0000004AA3C8: 02013F01
	.long 0xd7600002                                           // 0000004AA3CC: D7600002
	v_cndmask_b32_e32 v0, v1, v151, vcc_lo                     // 0000004AA3D0: 02012F01
	v_mul_f32_e32 v14, s1, v16                                 // 0000004AA3D4: 101C2001
	v_mul_f32_e32 v16, 0x3db504f3, v0                          // 0000004AA3D8: 102000FF 3DB504F3
	v_mul_f32_e32 v2, 0x3db504f3, v2                           // 0000004AA3E0: 100404FF 3DB504F3
	.long 0xd73c0000                                           // 0000004AA3E8: D73C0000
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 0000004AA3EC: 02021881
	v_add_nc_u32_e32 v12, 0x60, v22                            // 0000004AA3F0: 4A182CFF 00000060
	v_dual_mul_f32 v15, s0, v17 :: v_dual_and_b32 v24, 1, v11  // 0000004AA3F8: C8E42200 0F181681
	.long 0x7e16398e                                           // 0000004AA400: 7E16398E
	v_mul_f32_e32 v16, s3, v16                                 // 0000004AA404: 10202003
	v_mul_f32_e32 v2, s2, v2                                   // 0000004AA408: 10040402
	v_mad_i64_i32 v[12:13], null, v12, s10, 0                  // 0000004AA40C: D6FF7C0C 0200150C
	.long 0x7e22398f                                           // 0000004AA414: 7E22398F
	.long 0x7f22398b                                           // 0000004AA418: 7F22398B
	v_and_b32_e32 v18, 1, v11                                  // 0000004AA41C: 36241681
	.long 0x7e163990                                           // 0000004AA420: 7E163990
	.long 0xd73c0009                                           // 0000004AA424: D73C0009
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 0000004AA428: 02021281
	.long 0x7e263982                                           // 0000004AA42C: 7E263982
	.long 0x7f26398b                                           // 0000004AA430: 7F26398B
	.long 0xd7006a05                                           // 0000004AA434: D7006A05
	v_cndmask_b32_e32 v1, v3, v5, vcc_lo                       // 0000004AA438: 02020B03
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004AA43C: BF870001
	v_add_co_ci_u32_e64 v6, null, v4, v6, vcc_lo               // 0000004AA440: D5207C06 01AA0D04
	.long 0xd7006a07                                           // 0000004AA448: D7006A07
	v_cndmask_b32_e32 v1, v3, v7, vcc_lo                       // 0000004AA44C: 02020F03
	v_and_b32_e32 v17, 1, v17                                  // 0000004AA450: 36222281
	v_and_b32_e32 v21, 1, v11                                  // 0000004AA454: 362A1681
	.long 0xd73c000b                                           // 0000004AA458: D73C000B
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 0000004AA45C: 02021881
	v_and_b32_e32 v19, 1, v19                                  // 0000004AA460: 36262681
	v_add_co_ci_u32_e64 v8, null, v4, v8, vcc_lo               // 0000004AA464: D5207C08 01AA1104
	.long 0xd7006a09                                           // 0000004AA46C: D7006A09
	v_cndmask_b32_e32 v1, v3, v9, vcc_lo                       // 0000004AA470: 02021303
	v_add3_u32 v20, v23, v24, 0x7fff                           // 0000004AA474: D6550014 03FE3117 00007FFF
	v_add_co_ci_u32_e64 v10, null, v4, v10, vcc_lo             // 0000004AA480: D5207C0A 01AA1504
	.long 0xd7006a00                                           // 0000004AA488: D7006A00
	v_cndmask_b32_e32 v1, v3, v0, vcc_lo                       // 0000004AA48C: 02020103
	v_add3_u32 v13, v14, v18, 0x7fff                           // 0000004AA490: D655000D 03FE250E 00007FFF
	v_add3_u32 v14, v15, v17, 0x7fff                           // 0000004AA49C: D655000E 03FE230F 00007FFF
	v_add_co_ci_u32_e64 v1, null, v4, v1, vcc_lo               // 0000004AA4A8: D5207C01 01AA0304
	v_add3_u32 v15, v16, v21, 0x7fff                           // 0000004AA4B0: D655000F 03FE2B10 00007FFF
	v_add3_u32 v16, v2, v19, 0x7fff                            // 0000004AA4BC: D6550010 03FE2702 00007FFF
	.long 0xd7006a02                                           // 0000004AA4C8: D7006A02
	v_cndmask_b32_e32 v1, v3, v11, vcc_lo                      // 0000004AA4CC: 02021703
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004AA4D0: BF870001
	v_add_co_ci_u32_e64 v3, null, v4, v12, vcc_lo              // 0000004AA4D4: D5207C03 01AA1904
	s_clause 0x4                                               // 0000004AA4DC: BF850004
	global_store_d16_hi_b16 v[5:6], v20, off                   // 0000004AA4E0: DC960000 007C1405
	global_store_d16_hi_b16 v[7:8], v14, off                   // 0000004AA4E8: DC960000 007C0E07
	global_store_d16_hi_b16 v[9:10], v13, off                  // 0000004AA4F0: DC960000 007C0D09
	global_store_d16_hi_b16 v[0:1], v16, off                   // 0000004AA4F8: DC960000 007C1000
	global_store_d16_hi_b16 v[2:3], v15, off                   // 0000004AA500: DC960000 007C0F02
	s_endpgm                                                   // 0000004AA508: BFB00000
		...

