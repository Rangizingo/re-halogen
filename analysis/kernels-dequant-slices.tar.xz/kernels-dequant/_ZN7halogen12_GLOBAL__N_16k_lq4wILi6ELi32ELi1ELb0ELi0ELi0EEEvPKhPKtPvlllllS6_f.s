000000000056d000 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 00000056D000: F4100100 F8000000
	v_dual_mov_b32 v4, 0 :: v_dual_and_b32 v1, 15, v0          // 00000056D008: CA240080 0400008F
	v_lshrrev_b32_e32 v2, 2, v0                                // 00000056D010: 32040082
	s_ashr_i32 s3, s2, 31                                      // 00000056D014: 86039F02
	s_delay_alu instid0(VALU_DEP_2)                            // 00000056D018: BF870002
	v_dual_mov_b32 v16, 0 :: v_dual_lshlrev_b32 v1, 2, v1      // 00000056D01C: CA220080 10000282
	s_lshl_b64 s[0:1], s[2:3], 3                               // 00000056D024: 84808302
	s_delay_alu instid0(VALU_DEP_2) | instid1(SALU_CYCLE_1)    // 00000056D028: BF870482
	v_dual_mov_b32 v9, s1 :: v_dual_and_b32 v2, 60, v2         // 00000056D02C: CA240001 090204BC
	.long 0x7f183880                                           // 00000056D034: 7F183880
	v_dual_mov_b32 v6, 0 :: v_dual_and_b32 v15, 31, v0         // 00000056D038: CA240080 060E009F
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v5, 0              // 00000056D040: CA100080 1A040080
	s_waitcnt lgkmcnt(0)                                       // 00000056D048: BF89FC07
	s_clause 0x1                                               // 00000056D04C: BF850001
	global_load_b32 v3, v1, s[4:5]                             // 00000056D050: DC520000 03040001
	global_load_b32 v7, v2, s[4:5]                             // 00000056D058: DC520000 07040002
	v_lshrrev_b32_e32 v1, 5, v0                                // 00000056D060: 32020085
	s_add_u32 s2, s4, s14                                      // 00000056D064: 80020E04
	s_addc_u32 s3, s5, s15                                     // 00000056D068: 82030F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000056D06C: BF8704A1
	v_or_b32_e32 v8, s0, v1                                    // 00000056D070: 38100200
	s_lshr_b32 s0, s11, 31                                     // 00000056D074: 85009F0B
	s_add_u32 s14, s10, s0                                     // 00000056D078: 800E000A
	s_addc_u32 s15, s11, 0                                     // 00000056D07C: 820F800B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000056D080: BF870001
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[8:9]                  // 00000056D084: 7CA8100C
	s_ashr_i32 s20, s11, 31                                    // 00000056D088: 86149F0B
	v_cndmask_b32_e32 v10, 0, v8, vcc_lo                       // 00000056D08C: 02141080
	v_cndmask_b32_e64 v14, 0, s1, vcc_lo                       // 00000056D090: D501000E 01A80280
	s_ashr_i64 s[0:1], s[14:15], 1                             // 00000056D098: 8680810E
	s_lshr_b32 s14, s20, 27                                    // 00000056D09C: 850E9B14
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 00000056D0A0: BF870151
	.long 0xd72c0013                                           // 00000056D0A4: D72C0013
	v_cndmask_b32_e32 v0, v14, v0, vcc_lo                      // 00000056D0A8: 0200010E
	s_waitcnt vmcnt(1)                                         // 00000056D0AC: BF8907F7
	v_bfe_u32 v11, v3, 16, 1                                   // 00000056D0B0: D610000B 02052103
	s_waitcnt vmcnt(0)                                         // 00000056D0B8: BF8903F7
	v_bfe_u32 v18, v7, 16, 1                                   // 00000056D0BC: D6100012 02052107
	v_add3_u32 v3, v3, v11, 0x7fff                             // 00000056D0C4: D6550003 03FE1703 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000056D0D0: BF870112
	v_add3_u32 v7, v7, v18, 0x7fff                             // 00000056D0D4: D6550007 03FE2507 00007FFF
	.long 0x7e183983                                           // 00000056D0E0: 7E183983
	.long 0xd72c0003                                           // 00000056D0E4: D72C0003
	v_cndmask_b32_e32 v1, s18, v14, vcc_lo                     // 00000056D0E8: 02021C12
	v_lshlrev_b32_e32 v14, 2, v0                               // 00000056D0EC: 301C0082
	s_delay_alu instid0(VALU_DEP_3)                            // 00000056D0F0: BF870003
	v_and_or_b32 v12, 0xffff0000, v7, v12                      // 00000056D0F4: D657000C 04320EFF FFFF0000
	v_mov_b32_e32 v7, 0                                        // 00000056D100: 7E0E0280
	.long 0xd72c000d                                           // 00000056D104: D72C000D
	v_cndmask_b32_e32 v1, s19, v10, vcc_lo                     // 00000056D108: 02021413
	v_mad_u64_u32 v[1:2], null, s18, v10, 0                    // 00000056D10C: D6FE7C01 02021412
	.long 0xd72c0011                                           // 00000056D114: D72C0011
	v_cndmask_b32_e32 v0, v10, v1, vcc_lo                      // 00000056D118: 0200030A
	v_mad_u64_u32 v[10:11], null, v10, s0, s[2:3]              // 00000056D11C: D6FE7C0A 0008010A
	s_add_u32 s2, s10, s14                                     // 00000056D124: 80020E0A
	s_addc_u32 s3, s11, 0                                      // 00000056D128: 8203800B
	ds_store_b32 v14, v12                                      // 00000056D12C: D8340000 00000C0E
	s_lshr_b64 s[2:3], s[2:3], 5                               // 00000056D134: 85828502
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000056D138: BF870009
	.long 0xd4440000                                           // 00000056D13C: D4440000
	v_cndmask_b32_e32 v1, s2, v15, vcc_lo                      // 00000056D140: 02021E02
	v_add3_u32 v0, v2, v3, v13                                 // 00000056D144: D6550000 04360702
	v_add3_u32 v17, v19, v11, v17                              // 00000056D14C: D6550011 04461713
	s_waitcnt lgkmcnt(0)                                       // 00000056D154: BF89FC07
	s_barrier                                                  // 00000056D158: BFBD0000
	buffer_gl0_inv                                             // 00000056D15C: E0AC0000 00000000
	s_and_saveexec_b32 s3, s0                                  // 00000056D164: BE832000
	s_cbranch_execz 26                                         // 00000056D168: BFA5001A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x1d4>
	s_add_u32 s1, s4, s16                                      // 00000056D16C: 80011004
	s_addc_u32 s14, s5, s17                                    // 00000056D170: 820E1105
	v_lshlrev_b32_e32 v2, 1, v15                               // 00000056D174: 30041E81
	.long 0xd7000103                                           // 00000056D178: D7000103
	v_cndmask_b32_e32 v1, s1, v1, vcc_lo                       // 00000056D17C: 02020201
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000056D180: BF8701A1
	v_add_co_ci_u32_e64 v4, null, s14, v0, s1                  // 00000056D184: D5207C04 0006000E
	v_lshlrev_b32_e32 v5, 4, v15                               // 00000056D18C: 300A1E84
	.long 0xd7000102                                           // 00000056D190: D7000102
	v_cndmask_b32_e32 v1, v3, v2, vcc_lo                       // 00000056D194: 02020503
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000056D198: BF870191
	v_add_co_ci_u32_e64 v3, null, 0, v4, s1                    // 00000056D19C: D5207C03 00060880
	.long 0xd7000104                                           // 00000056D1A4: D7000104
	v_cndmask_b32_e32 v1, v10, v5, vcc_lo                      // 00000056D1A8: 02020B0A
	s_delay_alu instid0(VALU_DEP_1)                            // 00000056D1AC: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v17, s1                   // 00000056D1B0: D5207C05 00062280
	s_clause 0x1                                               // 00000056D1B8: BF850001
	global_load_d16_b16 v2, v[2:3], off                        // 00000056D1BC: DC820000 027C0002
	global_load_b128 v[4:7], v[4:5], off                       // 00000056D1C4: DC5E0000 047C0004
	s_waitcnt vmcnt(1)                                         // 00000056D1CC: BF8907F7
	v_cvt_f32_f16_e32 v26, v2                                  // 00000056D1D0: 7E341702
	s_or_b32 exec_lo, exec_lo, s3                              // 00000056D1D4: 8C7E037E
	v_dual_mov_b32 v18, 0 :: v_dual_mov_b32 v19, 0             // 00000056D1D8: CA100080 12120080
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v21, 0             // 00000056D1E0: CA100080 14140080
	v_mov_b32_e32 v22, 0                                       // 00000056D1E8: 7E2C0280
	s_and_saveexec_b32 s3, s0                                  // 00000056D1EC: BE832000
	s_cbranch_execz 537                                        // 00000056D1F0: BFA50219 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0xa58>
	s_mul_i32 s0, s11, 6                                       // 00000056D1F4: 9600860B
	s_mul_hi_u32 s1, s10, 6                                    // 00000056D1F8: 9681860A
	v_dual_mov_b32 v12, 0 :: v_dual_lshlrev_b32 v11, 5, v15    // 00000056D1FC: CA220080 0C0A1E85
	s_add_i32 s18, s1, s0                                      // 00000056D204: 81120001
	v_lshlrev_b32_e32 v2, 1, v15                               // 00000056D208: 30041E81
	.long 0xd7000001                                           // 00000056D20C: D7000001
	v_cndmask_b32_e32 v1, s16, v1, vcc_lo                      // 00000056D210: 02020210
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000056D214: BF8701A1
	v_add_co_ci_u32_e64 v0, null, s17, v0, s0                  // 00000056D218: D5207C00 00020011
	v_mov_b32_e32 v21, v12                                     // 00000056D220: 7E2A030C
	.long 0xd7000001                                           // 00000056D224: D7000001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 00000056D228: 02020501
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000056D22C: BF8701A1
	v_add_co_ci_u32_e64 v0, null, 0, v0, s0                    // 00000056D230: D5207C00 00020080
	v_lshl_or_b32 v23, v15, 4, 0x200                           // 00000056D238: D6560017 03FD090F 00000200
	.long 0xd7000001                                           // 00000056D244: D7000001
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 00000056D248: 02020204
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000056D24C: BF8701A1
	v_add_co_ci_u32_e64 v0, null, s5, v0, s0                   // 00000056D250: D5207C00 00020005
	v_dual_mov_b32 v24, v15 :: v_dual_mov_b32 v19, v12         // 00000056D258: CA10010F 1812010C
	.long 0xd700000d                                           // 00000056D260: D700000D
	v_cndmask_b32_e32 v0, v1, v192, vcc_lo                     // 00000056D264: 02018101
	s_delay_alu instid0(VALU_DEP_1)                            // 00000056D268: BF870001
	v_add_co_ci_u32_e64 v14, null, 0, v0, s0                   // 00000056D26C: D5207C0E 00020080
	v_dual_mov_b32 v22, v12 :: v_dual_mov_b32 v25, v26         // 00000056D274: CA10010C 1618011A
	v_mov_b32_e32 v20, v12                                     // 00000056D27C: 7E28030C
	v_mov_b32_e32 v18, v12                                     // 00000056D280: 7E24030C
	v_mov_b32_e32 v16, v12                                     // 00000056D284: 7E20030C
	s_lshl_b64 s[14:15], s[10:11], 2                           // 00000056D288: 848E820A
	s_mul_i32 s17, s10, 6                                      // 00000056D28C: 9611860A
	s_mov_b32 s16, 0                                           // 00000056D290: BE900080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 00000056D294: 8484810A
	s_branch 469                                               // 00000056D298: BFA001D5 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x9f0>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000056D29C: 8C7E0A7E
	v_and_b32_e32 v27, 0xff, v4                                // 00000056D2A0: 363608FF 000000FF
	s_and_b32 s0, exec_lo, s0                                  // 00000056D2A8: 8B00007E
	v_add_nc_u32_e32 v23, 0x200, v23                           // 00000056D2AC: 4A2E2EFF 00000200
	s_or_b32 s16, s0, s16                                      // 00000056D2B4: 8C101000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000056D2B8: BF8700B2
	v_lshlrev_b32_e32 v27, 2, v27                              // 00000056D2BC: 30363682
	ds_load_b32 v43, v27                                       // 00000056D2C0: D8D80000 2B00001B
	v_lshrrev_b32_e32 v27, 6, v4                               // 00000056D2C8: 32360886
	v_and_b32_e32 v27, 0x3fc, v27                              // 00000056D2CC: 363636FF 000003FC
	ds_load_b32 v44, v27                                       // 00000056D2D4: D8D80000 2C00001B
	v_lshrrev_b32_e32 v27, 14, v4                              // 00000056D2DC: 3236088E
	v_lshrrev_b32_e32 v4, 22, v4                               // 00000056D2E0: 32080896
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000056D2E4: BF870112
	v_and_b32_e32 v27, 0x3fc, v27                              // 00000056D2E8: 363636FF 000003FC
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000056D2F0: 360808FF 000003FC
	ds_load_b32 v45, v27                                       // 00000056D2F8: D8D80000 2D00001B
	ds_load_b32 v46, v4                                        // 00000056D300: D8D80000 2E000004
	v_and_b32_e32 v4, 0xff, v5                                 // 00000056D308: 36080AFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000056D310: BF8700B1
	v_lshlrev_b32_e32 v4, 2, v4                                // 00000056D314: 30080882
	ds_load_b32 v47, v4                                        // 00000056D318: D8D80000 2F000004
	v_lshrrev_b32_e32 v4, 6, v5                                // 00000056D320: 32080A86
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000056D324: 360808FF 000003FC
	ds_load_b32 v48, v4                                        // 00000056D32C: D8D80000 30000004
	v_lshrrev_b32_e32 v4, 14, v5                               // 00000056D334: 32080A8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000056D338: BF8700B1
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000056D33C: 360808FF 000003FC
	ds_load_b32 v49, v4                                        // 00000056D344: D8D80000 31000004
	v_lshrrev_b32_e32 v4, 22, v5                               // 00000056D34C: 32080A96
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000056D350: 360808FF 000003FC
	ds_load_b32 v50, v4                                        // 00000056D358: D8D80000 32000004
	v_and_b32_e32 v4, 0xff, v6                                 // 00000056D360: 36080CFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000056D368: BF8700B1
	v_lshlrev_b32_e32 v4, 2, v4                                // 00000056D36C: 30080882
	ds_load_b32 v51, v4                                        // 00000056D370: D8D80000 33000004
	v_lshrrev_b32_e32 v4, 6, v6                                // 00000056D378: 32080C86
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000056D37C: 360808FF 000003FC
	ds_load_b32 v52, v4                                        // 00000056D384: D8D80000 34000004
	v_lshrrev_b32_e32 v4, 14, v6                               // 00000056D38C: 32080C8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000056D390: BF8700B1
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000056D394: 360808FF 000003FC
	ds_load_b32 v53, v4                                        // 00000056D39C: D8D80000 35000004
	v_lshrrev_b32_e32 v4, 22, v6                               // 00000056D3A4: 32080C96
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000056D3A8: 360808FF 000003FC
	ds_load_b32 v54, v4                                        // 00000056D3B0: D8D80000 36000004
	v_and_b32_e32 v4, 0xff, v7                                 // 00000056D3B8: 36080EFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000056D3C0: BF8700B1
	v_lshlrev_b32_e32 v4, 2, v4                                // 00000056D3C4: 30080882
	ds_load_b32 v55, v4                                        // 00000056D3C8: D8D80000 37000004
	v_lshrrev_b32_e32 v4, 6, v7                                // 00000056D3D0: 32080E86
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000056D3D4: 360808FF 000003FC
	ds_load_b32 v56, v4                                        // 00000056D3DC: D8D80000 38000004
	v_lshrrev_b32_e32 v4, 14, v7                               // 00000056D3E4: 32080E8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000056D3E8: BF8700B1
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000056D3EC: 360808FF 000003FC
	ds_load_b32 v57, v4                                        // 00000056D3F4: D8D80000 39000004
	v_lshrrev_b32_e32 v4, 22, v7                               // 00000056D3FC: 32080E96
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000056D400: 360808FF 000003FC
	ds_load_b32 v58, v4                                        // 00000056D408: D8D80000 3A000004
	.long 0xd73c0004                                           // 00000056D410: D73C0004
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 00000056D414: 02021681
	v_add_nc_u32_e32 v11, 0x400, v11                           // 00000056D418: 4A1616FF 00000400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056D420: BF870092
	.long 0xd7000027                                           // 00000056D424: D7000027
	v_cndmask_b32_e32 v1, s6, v4, vcc_lo                       // 00000056D428: 02020806
	v_add_co_ci_u32_e64 v40, null, s7, v5, s0                  // 00000056D42C: D5207C28 00020A07
	s_clause 0x3                                               // 00000056D434: BF850003
	global_load_b128 v[4:7], v[39:40], off                     // 00000056D438: DC5E0000 047C0027
	global_load_b128 v[27:30], v[39:40], off offset:16         // 00000056D440: DC5E0010 1B7C0027
	global_load_b128 v[31:34], v[39:40], off offset:32         // 00000056D448: DC5E0020 1F7C0027
	global_load_b128 v[35:38], v[39:40], off offset:48         // 00000056D450: DC5E0030 237C0027
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 00000056D458: BF890CF7
	v_dot2_f32_bf16 v4, v4, v43, 0                             // 00000056D45C: CC1A4004 1A025704
	s_waitcnt lgkmcnt(14)                                      // 00000056D464: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056D468: BF8700A1
	v_dot2_f32_bf16 v4, v5, v44, v4                            // 00000056D46C: CC1A4004 1C125905
	s_waitcnt lgkmcnt(13)                                      // 00000056D474: BF89FCD7
	v_dot2_f32_bf16 v4, v6, v45, v4                            // 00000056D478: CC1A4004 1C125B06
	s_waitcnt lgkmcnt(12)                                      // 00000056D480: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056D484: BF8700A1
	v_dot2_f32_bf16 v4, v7, v46, v4                            // 00000056D488: CC1A4004 1C125D07
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 00000056D490: BF8908B7
	v_dot2_f32_bf16 v4, v27, v47, v4                           // 00000056D494: CC1A4004 1C125F1B
	s_waitcnt lgkmcnt(10)                                      // 00000056D49C: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056D4A0: BF8700A1
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 00000056D4A4: CC1A4004 1C12611C
	s_waitcnt lgkmcnt(9)                                       // 00000056D4AC: BF89FC97
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 00000056D4B0: CC1A4004 1C12631D
	s_waitcnt lgkmcnt(8)                                       // 00000056D4B8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056D4BC: BF8700A1
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 00000056D4C0: CC1A4004 1C12651E
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 00000056D4C8: BF890477
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 00000056D4CC: CC1A4004 1C12671F
	s_waitcnt lgkmcnt(6)                                       // 00000056D4D4: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056D4D8: BF8700A1
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 00000056D4DC: CC1A4004 1C126920
	s_waitcnt lgkmcnt(5)                                       // 00000056D4E4: BF89FC57
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 00000056D4E8: CC1A4004 1C126B21
	s_waitcnt lgkmcnt(4)                                       // 00000056D4F0: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056D4F4: BF8700A1
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 00000056D4F8: CC1A4004 1C126D22
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 00000056D500: BF890037
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 00000056D504: CC1A4004 1C126F23
	.long 0xd7000023                                           // 00000056D50C: D7000023
	v_cndmask_b32_e32 v0, v39, v4, vcc_lo                      // 00000056D510: 02000927
	s_waitcnt lgkmcnt(2)                                       // 00000056D514: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000056D518: BF8701C2
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 00000056D51C: CC1A4004 1C127124
	v_add_co_ci_u32_e64 v36, null, s5, v40, s0                 // 00000056D524: D5207C24 00025005
	.long 0xd7000029                                           // 00000056D52C: D7000029
	v_cndmask_b32_e32 v0, v39, v14, vcc_lo                     // 00000056D530: 02001D27
	s_waitcnt lgkmcnt(1)                                       // 00000056D534: BF89FC17
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 00000056D538: CC1A4004 1C127325
	v_add_co_ci_u32_e64 v42, null, s15, v40, s0                // 00000056D540: D5207C2A 0002500F
	.long 0xd7000027                                           // 00000056D548: D7000027
	v_cndmask_b32_e32 v0, v39, v17, vcc_lo                     // 00000056D54C: 02002327
	s_waitcnt lgkmcnt(0)                                       // 00000056D550: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000056D554: BF870123
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 00000056D558: CC1A4004 1C127526
	v_add_co_ci_u32_e64 v40, null, s18, v40, s0                // 00000056D560: D5207C28 00025012
	v_fmac_f32_e32 v21, v26, v4                                // 00000056D568: 562A091A
	s_clause 0x3                                               // 00000056D56C: BF850003
	global_load_b128 v[4:7], v[35:36], off                     // 00000056D570: DC5E0000 047C0023
	global_load_b128 v[27:30], v[35:36], off offset:16         // 00000056D578: DC5E0010 1B7C0023
	global_load_b128 v[31:34], v[35:36], off offset:32         // 00000056D580: DC5E0020 1F7C0023
	global_load_b128 v[35:38], v[35:36], off offset:48         // 00000056D588: DC5E0030 237C0023
	s_waitcnt vmcnt(3)                                         // 00000056D590: BF890FF7
	v_dot2_f32_bf16 v4, v4, v43, 0                             // 00000056D594: CC1A4004 1A025704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056D59C: BF870091
	v_dot2_f32_bf16 v4, v5, v44, v4                            // 00000056D5A0: CC1A4004 1C125905
	v_dot2_f32_bf16 v4, v6, v45, v4                            // 00000056D5A8: CC1A4004 1C125B06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056D5B0: BF8700A1
	v_dot2_f32_bf16 v4, v7, v46, v4                            // 00000056D5B4: CC1A4004 1C125D07
	s_waitcnt vmcnt(2)                                         // 00000056D5BC: BF890BF7
	v_dot2_f32_bf16 v4, v27, v47, v4                           // 00000056D5C0: CC1A4004 1C125F1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056D5C8: BF870091
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 00000056D5CC: CC1A4004 1C12611C
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 00000056D5D4: CC1A4004 1C12631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056D5DC: BF8700A1
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 00000056D5E0: CC1A4004 1C12651E
	s_waitcnt vmcnt(1)                                         // 00000056D5E8: BF8907F7
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 00000056D5EC: CC1A4004 1C12671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056D5F4: BF870091
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 00000056D5F8: CC1A4004 1C126920
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 00000056D600: CC1A4004 1C126B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056D608: BF8700A1
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 00000056D60C: CC1A4004 1C126D22
	s_waitcnt vmcnt(0)                                         // 00000056D614: BF8903F7
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 00000056D618: CC1A4004 1C126F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056D620: BF870091
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 00000056D624: CC1A4004 1C127124
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 00000056D62C: CC1A4004 1C127325
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056D634: BF870091
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 00000056D638: CC1A4004 1C127526
	v_fmac_f32_e32 v22, v26, v4                                // 00000056D640: 562C091A
	s_clause 0x3                                               // 00000056D644: BF850003
	global_load_b128 v[4:7], v[41:42], off                     // 00000056D648: DC5E0000 047C0029
	global_load_b128 v[27:30], v[41:42], off offset:16         // 00000056D650: DC5E0010 1B7C0029
	global_load_b128 v[31:34], v[41:42], off offset:32         // 00000056D658: DC5E0020 1F7C0029
	global_load_b128 v[35:38], v[41:42], off offset:48         // 00000056D660: DC5E0030 237C0029
	s_waitcnt vmcnt(3)                                         // 00000056D668: BF890FF7
	v_dot2_f32_bf16 v4, v4, v43, 0                             // 00000056D66C: CC1A4004 1A025704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056D674: BF870091
	v_dot2_f32_bf16 v4, v5, v44, v4                            // 00000056D678: CC1A4004 1C125905
	v_dot2_f32_bf16 v4, v6, v45, v4                            // 00000056D680: CC1A4004 1C125B06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056D688: BF8700A1
	v_dot2_f32_bf16 v4, v7, v46, v4                            // 00000056D68C: CC1A4004 1C125D07
	s_waitcnt vmcnt(2)                                         // 00000056D694: BF890BF7
	v_dot2_f32_bf16 v4, v27, v47, v4                           // 00000056D698: CC1A4004 1C125F1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056D6A0: BF870091
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 00000056D6A4: CC1A4004 1C12611C
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 00000056D6AC: CC1A4004 1C12631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056D6B4: BF8700A1
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 00000056D6B8: CC1A4004 1C12651E
	s_waitcnt vmcnt(1)                                         // 00000056D6C0: BF8907F7
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 00000056D6C4: CC1A4004 1C12671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056D6CC: BF870091
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 00000056D6D0: CC1A4004 1C126920
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 00000056D6D8: CC1A4004 1C126B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056D6E0: BF8700A1
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 00000056D6E4: CC1A4004 1C126D22
	s_waitcnt vmcnt(0)                                         // 00000056D6EC: BF8903F7
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 00000056D6F0: CC1A4004 1C126F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056D6F8: BF870091
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 00000056D6FC: CC1A4004 1C127124
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 00000056D704: CC1A4004 1C127325
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056D70C: BF870091
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 00000056D710: CC1A4004 1C127526
	v_fmac_f32_e32 v19, v26, v4                                // 00000056D718: 5626091A
	s_clause 0x3                                               // 00000056D71C: BF850003
	global_load_b128 v[4:7], v[39:40], off                     // 00000056D720: DC5E0000 047C0027
	global_load_b128 v[27:30], v[39:40], off offset:16         // 00000056D728: DC5E0010 1B7C0027
	global_load_b128 v[31:34], v[39:40], off offset:32         // 00000056D730: DC5E0020 1F7C0027
	global_load_b128 v[35:38], v[39:40], off offset:48         // 00000056D738: DC5E0030 237C0027
	s_waitcnt vmcnt(3)                                         // 00000056D740: BF890FF7
	v_dot2_f32_bf16 v4, v4, v43, 0                             // 00000056D744: CC1A4004 1A025704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056D74C: BF870091
	v_dot2_f32_bf16 v4, v5, v44, v4                            // 00000056D750: CC1A4004 1C125905
	v_dot2_f32_bf16 v4, v6, v45, v4                            // 00000056D758: CC1A4004 1C125B06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056D760: BF8700A1
	v_dot2_f32_bf16 v4, v7, v46, v4                            // 00000056D764: CC1A4004 1C125D07
	s_waitcnt vmcnt(2)                                         // 00000056D76C: BF890BF7
	v_dot2_f32_bf16 v4, v27, v47, v4                           // 00000056D770: CC1A4004 1C125F1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056D778: BF870091
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 00000056D77C: CC1A4004 1C12611C
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 00000056D784: CC1A4004 1C12631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056D78C: BF8700A1
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 00000056D790: CC1A4004 1C12651E
	s_waitcnt vmcnt(1)                                         // 00000056D798: BF8907F7
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 00000056D79C: CC1A4004 1C12671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056D7A4: BF870091
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 00000056D7A8: CC1A4004 1C126920
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 00000056D7B0: CC1A4004 1C126B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056D7B8: BF8700A1
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 00000056D7BC: CC1A4004 1C126D22
	s_waitcnt vmcnt(0)                                         // 00000056D7C4: BF8903F7
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 00000056D7C8: CC1A4004 1C126F23
	.long 0xd7000023                                           // 00000056D7D0: D7000023
	v_cndmask_b32_e32 v0, v41, v14, vcc_lo                     // 00000056D7D4: 02001D29
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000056D7D8: BF870122
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 00000056D7DC: CC1A4004 1C127124
	v_add_co_ci_u32_e64 v36, null, s15, v42, s0                // 00000056D7E4: D5207C24 0002540F
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 00000056D7EC: CC1A4004 1C127325
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056D7F4: BF870091
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 00000056D7F8: CC1A4004 1C127526
	v_fmac_f32_e32 v20, v26, v4                                // 00000056D800: 5628091A
	s_clause 0x3                                               // 00000056D804: BF850003
	global_load_b128 v[4:7], v[35:36], off                     // 00000056D808: DC5E0000 047C0023
	global_load_b128 v[27:30], v[35:36], off offset:16         // 00000056D810: DC5E0010 1B7C0023
	global_load_b128 v[31:34], v[35:36], off offset:32         // 00000056D818: DC5E0020 1F7C0023
	global_load_b128 v[35:38], v[35:36], off offset:48         // 00000056D820: DC5E0030 237C0023
	s_waitcnt vmcnt(3)                                         // 00000056D828: BF890FF7
	v_dot2_f32_bf16 v4, v4, v43, 0                             // 00000056D82C: CC1A4004 1A025704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056D834: BF870091
	v_dot2_f32_bf16 v4, v5, v44, v4                            // 00000056D838: CC1A4004 1C125905
	v_dot2_f32_bf16 v4, v6, v45, v4                            // 00000056D840: CC1A4004 1C125B06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056D848: BF8700A1
	v_dot2_f32_bf16 v4, v7, v46, v4                            // 00000056D84C: CC1A4004 1C125D07
	s_waitcnt vmcnt(2)                                         // 00000056D854: BF890BF7
	v_dot2_f32_bf16 v4, v27, v47, v4                           // 00000056D858: CC1A4004 1C125F1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056D860: BF870091
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 00000056D864: CC1A4004 1C12611C
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 00000056D86C: CC1A4004 1C12631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056D874: BF8700A1
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 00000056D878: CC1A4004 1C12651E
	s_waitcnt vmcnt(1)                                         // 00000056D880: BF8907F7
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 00000056D884: CC1A4004 1C12671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056D88C: BF870091
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 00000056D890: CC1A4004 1C126920
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 00000056D898: CC1A4004 1C126B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056D8A0: BF8700A1
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 00000056D8A4: CC1A4004 1C126D22
	s_waitcnt vmcnt(0)                                         // 00000056D8AC: BF8903F7
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 00000056D8B0: CC1A4004 1C126F23
	.long 0xd7000023                                           // 00000056D8B8: D7000023
	v_cndmask_b32_e32 v0, v39, v14, vcc_lo                     // 00000056D8BC: 02001D27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000056D8C0: BF8701B2
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 00000056D8C4: CC1A4004 1C127124
	v_add_co_ci_u32_e64 v36, null, s15, v40, s0                // 00000056D8CC: D5207C24 0002500F
	.long 0xd700000d                                           // 00000056D8D4: D700000D
	v_cndmask_b32_e32 v0, v13, v192, vcc_lo                    // 00000056D8D8: 0201810D
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 00000056D8DC: CC1A4004 1C127325
	v_add_co_ci_u32_e64 v14, null, 0, v14, s0                  // 00000056D8E4: D5207C0E 00021C80
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056D8EC: BF870092
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 00000056D8F0: CC1A4004 1C127526
	v_fmac_f32_e32 v18, v26, v4                                // 00000056D8F8: 5624091A
	s_clause 0x3                                               // 00000056D8FC: BF850003
	global_load_b128 v[4:7], v[35:36], off                     // 00000056D900: DC5E0000 047C0023
	global_load_b128 v[27:30], v[35:36], off offset:16         // 00000056D908: DC5E0010 1B7C0023
	global_load_b128 v[31:34], v[35:36], off offset:32         // 00000056D910: DC5E0020 1F7C0023
	global_load_b128 v[35:38], v[35:36], off offset:48         // 00000056D918: DC5E0030 237C0023
	s_waitcnt vmcnt(3)                                         // 00000056D920: BF890FF7
	v_dot2_f32_bf16 v4, v4, v43, 0                             // 00000056D924: CC1A4004 1A025704
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000056D92C: BF870121
	v_dot2_f32_bf16 v4, v5, v44, v4                            // 00000056D930: CC1A4004 1C125905
	v_mov_b32_e32 v5, v1                                       // 00000056D938: 7E0A0301
	v_dot2_f32_bf16 v4, v6, v45, v4                            // 00000056D93C: CC1A4004 1C125B06
	v_mov_b32_e32 v6, v2                                       // 00000056D944: 7E0C0302
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000056D948: BF870132
	v_dot2_f32_bf16 v4, v7, v46, v4                            // 00000056D94C: CC1A4004 1C125D07
	v_mov_b32_e32 v7, v3                                       // 00000056D954: 7E0E0303
	s_waitcnt vmcnt(2)                                         // 00000056D958: BF890BF7
	v_dot2_f32_bf16 v4, v27, v47, v4                           // 00000056D95C: CC1A4004 1C125F1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056D964: BF870091
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 00000056D968: CC1A4004 1C12611C
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 00000056D970: CC1A4004 1C12631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056D978: BF8700A1
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 00000056D97C: CC1A4004 1C12651E
	s_waitcnt vmcnt(1)                                         // 00000056D984: BF8907F7
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 00000056D988: CC1A4004 1C12671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056D990: BF870091
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 00000056D994: CC1A4004 1C126920
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 00000056D99C: CC1A4004 1C126B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056D9A4: BF8700A1
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 00000056D9A8: CC1A4004 1C126D22
	s_waitcnt vmcnt(0)                                         // 00000056D9B0: BF8903F7
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 00000056D9B4: CC1A4004 1C126F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056D9BC: BF870091
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 00000056D9C0: CC1A4004 1C127124
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 00000056D9C8: CC1A4004 1C127325
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056D9D0: BF870091
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 00000056D9D4: CC1A4004 1C127526
	v_fmac_f32_e32 v16, v26, v4                                // 00000056D9DC: 5620091A
	v_mov_b32_e32 v4, v0                                       // 00000056D9E0: 7E080300
	v_mov_b32_e32 v26, v25                                     // 00000056D9E4: 7E340319
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 00000056D9E8: 917E107E
	s_cbranch_execz 25                                         // 00000056D9EC: BFA50019 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0xa54>
	s_waitcnt vmcnt(0)                                         // 00000056D9F0: BF8903F7
	v_dual_mov_b32 v1, v5 :: v_dual_add_nc_u32 v24, 32, v24    // 00000056D9F4: CA200105 011830A0
	v_dual_mov_b32 v0, v4 :: v_dual_mov_b32 v3, v7             // 00000056D9FC: CA100104 00020107
	v_mov_b32_e32 v2, v6                                       // 00000056DA04: 7E040306
	s_delay_alu instid0(VALU_DEP_3)                            // 00000056DA08: BF870003
	.long 0xd4430000                                           // 00000056DA0C: D4430000
	v_cndmask_b32_e32 v1, s2, v24, vcc_lo                      // 00000056DA10: 02023002
	s_mov_b32 s10, exec_lo                                     // 00000056DA14: BE8A007E
	.long 0xd4c4007e                                           // 00000056DA18: D4C4007E
	v_cndmask_b32_e32 v1, s2, v24, vcc_lo                      // 00000056DA1C: 02023002
	s_cbranch_execz 65054                                      // 00000056DA20: BFA5FE1E <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x29c>
	.long 0xd7000100                                           // 00000056DA24: D7000100
	v_cndmask_b32_e32 v1, v10, v23, vcc_lo                     // 00000056DA28: 02022F0A
	s_delay_alu instid0(VALU_DEP_1)                            // 00000056DA2C: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v17, s1                   // 00000056DA30: D5207C01 00062280
	global_load_d16_b16 v25, v[13:14], off                     // 00000056DA38: DC820000 197C000D
	global_load_b128 v[0:3], v[0:1], off                       // 00000056DA40: DC5E0000 007C0000
	s_waitcnt vmcnt(1)                                         // 00000056DA48: BF8907F7
	v_cvt_f32_f16_e32 v25, v25                                 // 00000056DA4C: 7E321719
	s_branch 65042                                             // 00000056DA50: BFA0FE12 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x29c>
	s_or_b32 exec_lo, exec_lo, s16                             // 00000056DA54: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056DA58: BF8700A9
	s_or_b32 exec_lo, exec_lo, s3                              // 00000056DA5C: 8C7E037E
	.long 0xd71f0000                                           // 00000056DA60: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000056DA64: 020100C1
	v_xor_b32_e32 v1, 16, v0                                   // 00000056DA68: 3A020090
	s_waitcnt vmcnt(0)                                         // 00000056DA6C: BF8903F7
	v_xor_b32_e32 v7, 8, v0                                    // 00000056DA70: 3A0E0088
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056DA74: BF870092
	.long 0xd44c0000                                           // 00000056DA78: D44C0000
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 00000056DA7C: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s0                           // 00000056DA80: D5010001 00020300
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000056DA88: BF870113
	.long 0xd44c0000                                           // 00000056DA8C: D44C0000
	v_cndmask_b32_e32 v1, 32, v7, vcc_lo                       // 00000056DA90: 02020EA0
	v_lshlrev_b32_e32 v1, 2, v1                                // 00000056DA94: 30020282
	s_delay_alu instid0(VALU_DEP_2)                            // 00000056DA98: BF870002
	v_cndmask_b32_e64 v7, v0, v7, s0                           // 00000056DA9C: D5010007 00020F00
	ds_bpermute_b32 v2, v1, v22                                // 00000056DAA4: DACC0000 02001601
	s_waitcnt lgkmcnt(0)                                       // 00000056DAAC: BF89FC07
	v_add_f32_e32 v2, v22, v2                                  // 00000056DAB0: 06040516
	ds_bpermute_b32 v4, v1, v20                                // 00000056DAB4: DACC0000 04001401
	ds_bpermute_b32 v3, v1, v21                                // 00000056DABC: DACC0000 03001501
	ds_bpermute_b32 v6, v1, v16                                // 00000056DAC4: DACC0000 06001001
	ds_bpermute_b32 v5, v1, v19                                // 00000056DACC: DACC0000 05001301
	ds_bpermute_b32 v1, v1, v18                                // 00000056DAD4: DACC0000 01001201
	s_waitcnt lgkmcnt(4)                                       // 00000056DADC: BF89FC47
	v_dual_add_f32 v4, v20, v4 :: v_dual_lshlrev_b32 v7, 2, v7 // 00000056DAE0: C9220914 04060E82
	s_waitcnt lgkmcnt(2)                                       // 00000056DAE8: BF89FC27
	v_dual_add_f32 v3, v21, v3 :: v_dual_add_f32 v6, v16, v6   // 00000056DAEC: C9080715 03060D10
	v_xor_b32_e32 v16, 4, v0                                   // 00000056DAF4: 3A200084
	ds_bpermute_b32 v10, v7, v2                                // 00000056DAF8: DACC0000 0A000207
	ds_bpermute_b32 v12, v7, v4                                // 00000056DB00: DACC0000 0C000407
	s_waitcnt lgkmcnt(2)                                       // 00000056DB08: BF89FC27
	v_add_f32_e32 v1, v18, v1                                  // 00000056DB0C: 06020312
	ds_bpermute_b32 v11, v7, v3                                // 00000056DB10: DACC0000 0B000307
	.long 0xd44c0000                                           // 00000056DB18: D44C0000
	v_cndmask_b32_e32 v1, 32, v16, vcc_lo                      // 00000056DB1C: 020220A0
	ds_bpermute_b32 v14, v7, v6                                // 00000056DB20: DACC0000 0E000607
	v_cndmask_b32_e64 v16, v0, v16, s0                         // 00000056DB28: D5010010 00022100
	s_delay_alu instid0(VALU_DEP_1)                            // 00000056DB30: BF870001
	v_dual_add_f32 v5, v19, v5 :: v_dual_lshlrev_b32 v16, 2, v16// 00000056DB34: C9220B13 05102082
	ds_bpermute_b32 v13, v7, v5                                // 00000056DB3C: DACC0000 0D000507
	s_waitcnt lgkmcnt(4)                                       // 00000056DB44: BF89FC47
	v_add_f32_e32 v2, v2, v10                                  // 00000056DB48: 06041502
	s_waitcnt lgkmcnt(3)                                       // 00000056DB4C: BF89FC37
	v_add_f32_e32 v4, v4, v12                                  // 00000056DB50: 06081904
	ds_bpermute_b32 v7, v7, v1                                 // 00000056DB54: DACC0000 07000107
	s_waitcnt lgkmcnt(2)                                       // 00000056DB5C: BF89FC27
	v_dual_add_f32 v3, v3, v11 :: v_dual_add_f32 v6, v6, v14   // 00000056DB60: C9081703 03061D06
	ds_bpermute_b32 v11, v16, v4                               // 00000056DB68: DACC0000 0B000410
	ds_bpermute_b32 v10, v16, v3                               // 00000056DB70: DACC0000 0A000310
	s_waitcnt lgkmcnt(3)                                       // 00000056DB78: BF89FC37
	v_add_f32_e32 v5, v5, v13                                  // 00000056DB7C: 060A1B05
	ds_bpermute_b32 v13, v16, v6                               // 00000056DB80: DACC0000 0D000610
	ds_bpermute_b32 v12, v16, v5                               // 00000056DB88: DACC0000 0C000510
	s_waitcnt lgkmcnt(4)                                       // 00000056DB90: BF89FC47
	v_add_f32_e32 v1, v1, v7                                   // 00000056DB94: 06020F01
	ds_bpermute_b32 v7, v16, v2                                // 00000056DB98: DACC0000 07000210
	s_waitcnt lgkmcnt(4)                                       // 00000056DBA0: BF89FC47
	v_add_f32_e32 v4, v4, v11                                  // 00000056DBA4: 06081704
	ds_bpermute_b32 v14, v16, v1                               // 00000056DBA8: DACC0000 0E000110
	v_xor_b32_e32 v16, 2, v0                                   // 00000056DBB0: 3A200082
	s_waitcnt lgkmcnt(4)                                       // 00000056DBB4: BF89FC47
	v_add_f32_e32 v3, v3, v10                                  // 00000056DBB8: 06061503
	v_xor_b32_e32 v10, 1, v0                                   // 00000056DBBC: 3A140081
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056DBC0: BF870093
	.long 0xd44c0000                                           // 00000056DBC4: D44C0000
	v_cndmask_b32_e32 v1, 32, v16, vcc_lo                      // 00000056DBC8: 020220A0
	v_cndmask_b32_e64 v16, v0, v16, s0                         // 00000056DBCC: D5010010 00022100
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000056DBD4: BF8701B3
	.long 0xd44c0000                                           // 00000056DBD8: D44C0000
	v_cndmask_b32_e32 v1, 32, v10, vcc_lo                      // 00000056DBDC: 020214A0
	s_waitcnt lgkmcnt(2)                                       // 00000056DBE0: BF89FC27
	v_add_f32_e32 v5, v5, v12                                  // 00000056DBE4: 060A1905
	v_lshlrev_b32_e32 v16, 2, v16                              // 00000056DBE8: 30202082
	s_waitcnt lgkmcnt(1)                                       // 00000056DBEC: BF89FC17
	v_add_f32_e32 v2, v2, v7                                   // 00000056DBF0: 06040F02
	v_add_f32_e32 v6, v6, v13                                  // 00000056DBF4: 060C1B06
	v_cndmask_b32_e64 v0, v0, v10, s0                          // 00000056DBF8: D5010000 00021500
	s_waitcnt lgkmcnt(0)                                       // 00000056DC00: BF89FC07
	v_add_f32_e32 v1, v1, v14                                  // 00000056DC04: 06021D01
	ds_bpermute_b32 v11, v16, v3                               // 00000056DC08: DACC0000 0B000310
	ds_bpermute_b32 v7, v16, v2                                // 00000056DC10: DACC0000 07000210
	ds_bpermute_b32 v12, v16, v4                               // 00000056DC18: DACC0000 0C000410
	ds_bpermute_b32 v13, v16, v5                               // 00000056DC20: DACC0000 0D000510
	ds_bpermute_b32 v14, v16, v6                               // 00000056DC28: DACC0000 0E000610
	ds_bpermute_b32 v16, v16, v1                               // 00000056DC30: DACC0000 10000110
	.long 0xd44a0000                                           // 00000056DC38: D44A0000
	v_cndmask_b32_e32 v1, 0, v15, vcc_lo                       // 00000056DC3C: 02021E80
	v_lshlrev_b32_e32 v17, 2, v0                               // 00000056DC40: 30220082
	s_and_b32 s0, s0, vcc_lo                                   // 00000056DC44: 8B006A00
	s_waitcnt lgkmcnt(5)                                       // 00000056DC48: BF89FC57
	v_add_f32_e32 v11, v3, v11                                 // 00000056DC4C: 06161703
	s_waitcnt lgkmcnt(4)                                       // 00000056DC50: BF89FC47
	v_add_f32_e32 v10, v2, v7                                  // 00000056DC54: 06140F02
	s_waitcnt lgkmcnt(2)                                       // 00000056DC58: BF89FC27
	v_dual_add_f32 v4, v4, v12 :: v_dual_add_f32 v5, v5, v13   // 00000056DC5C: C9081904 04041B05
	s_waitcnt lgkmcnt(0)                                       // 00000056DC64: BF89FC07
	v_dual_add_f32 v0, v6, v14 :: v_dual_add_f32 v1, v1, v16   // 00000056DC68: C9081D06 00002101
	ds_bpermute_b32 v13, v17, v11                              // 00000056DC70: DACC0000 0D000B11
	ds_bpermute_b32 v12, v17, v10                              // 00000056DC78: DACC0000 0C000A11
	ds_bpermute_b32 v6, v17, v5                                // 00000056DC80: DACC0000 06000511
	ds_bpermute_b32 v7, v17, v4                                // 00000056DC88: DACC0000 07000411
	ds_bpermute_b32 v2, v17, v1                                // 00000056DC90: DACC0000 02000111
	ds_bpermute_b32 v3, v17, v0                                // 00000056DC98: DACC0000 03000011
	s_and_saveexec_b32 s1, s0                                  // 00000056DCA0: BE812000
	s_cbranch_execz 89                                         // 00000056DCA4: BFA50059 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0xe0c>
	s_waitcnt lgkmcnt(4)                                       // 00000056DCA8: BF89FC47
	v_dual_add_f32 v11, v11, v13 :: v_dual_add_f32 v12, v10, v12// 00000056DCAC: C9081B0B 0B0C190A
	.long 0x7f1a3880                                           // 00000056DCB4: 7F1A3880
	.long 0xd73c0008                                           // 00000056DCB8: D73C0008
	v_cndmask_b32_e32 v1, 1, v8, vcc_lo                        // 00000056DCBC: 02021081
	s_lshl_b64 s[0:1], s[12:13], 1                             // 00000056DCC0: 8480810C
	s_delay_alu instid0(VALU_DEP_3)                            // 00000056DCC4: BF870003
	.long 0x7e14398b                                           // 00000056DCC8: 7E14398B
	.long 0x7e1a398c                                           // 00000056DCCC: 7E1A398C
	.long 0x7f14398d                                           // 00000056DCD0: 7F14398D
	s_waitcnt lgkmcnt(1)                                       // 00000056DCD4: BF89FC17
	v_add_f32_e32 v16, v1, v2                                  // 00000056DCD8: 06200501
	.long 0xd7006a08                                           // 00000056DCDC: D7006A08
	v_cndmask_b32_e32 v1, s8, v8, vcc_lo                       // 00000056DCE0: 02021008
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000056DCE4: BF8701B3
	v_dual_add_f32 v7, v4, v7 :: v_dual_and_b32 v10, 1, v10    // 00000056DCE8: C9240F04 070A1481
	v_add_co_ci_u32_e64 v9, null, s9, v9, vcc_lo               // 00000056DCF0: D5207C09 01AA1209
	v_and_b32_e32 v14, 1, v13                                  // 00000056DCF8: 361C1A81
	.long 0x7e1a3987                                           // 00000056DCFC: 7E1A3987
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056DD00: BF8700A4
	v_add3_u32 v15, v11, v10, 0x7fff                           // 00000056DD04: D655000F 03FE150B 00007FFF
	.long 0xd7006a0a                                           // 00000056DD10: D7006A0A
	v_cndmask_b32_e32 v0, v8, v0, vcc_lo                       // 00000056DD14: 02000108
	v_add_co_ci_u32_e64 v11, null, s1, v9, vcc_lo              // 00000056DD18: D5207C0B 01AA1201
	s_lshl_b64 s[0:1], s[12:13], 2                             // 00000056DD20: 8480820C
	global_store_d16_hi_b16 v[8:9], v15, off                   // 00000056DD24: DC960000 007C0F08
	.long 0xd7006a04                                           // 00000056DD2C: D7006A04
	v_cndmask_b32_e32 v0, v8, v0, vcc_lo                       // 00000056DD30: 02000108
	s_waitcnt lgkmcnt(0)                                       // 00000056DD34: BF89FC07
	v_add_f32_e32 v15, v0, v3                                  // 00000056DD38: 061E0700
	v_mad_u64_u32 v[0:1], null, s12, 6, v[8:9]                 // 00000056DD3C: D6FE7C00 04210C0C
	v_and_b32_e32 v2, 1, v13                                   // 00000056DD44: 36041A81
	.long 0x7e103990                                           // 00000056DD48: 7E103990
	.long 0x7f10398d                                           // 00000056DD4C: 7F10398D
	v_add_f32_e32 v6, v5, v6                                   // 00000056DD50: 060C0D05
	v_add3_u32 v12, v12, v14, 0x7fff                           // 00000056DD54: D655000C 03FE1D0C 00007FFF
	v_add_co_ci_u32_e64 v5, null, s1, v9, vcc_lo               // 00000056DD60: D5207C05 01AA1201
	.long 0x7f1c398d                                           // 00000056DD68: 7F1C398D
	v_add3_u32 v9, v7, v2, 0x7fff                              // 00000056DD6C: D6550009 03FE0507 00007FFF
	v_and_b32_e32 v7, 1, v8                                    // 00000056DD78: 360E1081
	.long 0x7e1c3986                                           // 00000056DD7C: 7E1C3986
	.long 0x7e1a398f                                           // 00000056DD80: 7E1A398F
	v_mad_u64_u32 v[1:2], null, s13, 6, v[1:2]                 // 00000056DD84: D6FE7C01 04050C0D
	.long 0xd7006a02                                           // 00000056DD8C: D7006A02
	v_cndmask_b32_e32 v0, v4, v0, vcc_lo                       // 00000056DD90: 02000104
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056DD94: BF870094
	v_and_b32_e32 v3, 1, v14                                   // 00000056DD98: 36061C81
	v_add3_u32 v14, v6, v3, 0x7fff                             // 00000056DD9C: D655000E 03FE0706 00007FFF
	v_and_b32_e32 v6, 1, v13                                   // 00000056DDA8: 360C1A81
	v_add_co_ci_u32_e64 v3, null, s1, v5, vcc_lo               // 00000056DDAC: D5207C03 01AA0A01
	v_add3_u32 v13, v16, v7, 0x7fff                            // 00000056DDB4: D655000D 03FE0F10 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056DDC0: BF8700A3
	v_add3_u32 v8, v15, v6, 0x7fff                             // 00000056DDC4: D6550008 03FE0D0F 00007FFF
	.long 0xd7006a06                                           // 00000056DDD0: D7006A06
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 00000056DDD4: 02000100
	v_add_co_ci_u32_e64 v7, null, s1, v1, vcc_lo               // 00000056DDD8: D5207C07 01AA0201
	s_clause 0x4                                               // 00000056DDE0: BF850004
	global_store_d16_hi_b16 v[10:11], v12, off                 // 00000056DDE4: DC960000 007C0C0A
	global_store_d16_hi_b16 v[4:5], v14, off                   // 00000056DDEC: DC960000 007C0E04
	global_store_d16_hi_b16 v[0:1], v9, off                    // 00000056DDF4: DC960000 007C0900
	global_store_d16_hi_b16 v[2:3], v13, off                   // 00000056DDFC: DC960000 007C0D02
	global_store_d16_hi_b16 v[6:7], v8, off                    // 00000056DE04: DC960000 007C0806
	s_endpgm                                                   // 00000056DE0C: BFB00000
		...

