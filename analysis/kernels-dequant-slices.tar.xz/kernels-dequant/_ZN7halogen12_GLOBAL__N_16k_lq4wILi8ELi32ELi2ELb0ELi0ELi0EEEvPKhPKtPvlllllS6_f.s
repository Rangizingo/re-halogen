0000000000579f00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000579F00: F4100100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 000000579F08: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 000000579F0C: 32040082
	s_lshl_b64 s[2:3], s[2:3], 2                               // 000000579F10: 84828202
	v_and_b32_e32 v1, 15, v0                                   // 000000579F14: 3602008F
	v_mov_b32_e32 v5, 0                                        // 000000579F18: 7E0A0280
	v_lshrrev_b32_e32 v14, 6, v0                               // 000000579F1C: 321C0086
	v_and_b32_e32 v2, 60, v2                                   // 000000579F20: 360404BC
	s_delay_alu instid0(VALU_DEP_4)                            // 000000579F24: BF870004
	v_dual_mov_b32 v6, 0 :: v_dual_lshlrev_b32 v1, 2, v1       // 000000579F28: CA220080 06000282
	v_bfe_u32 v15, v0, 5, 1                                    // 000000579F30: D610000F 02050B00
	v_dual_mov_b32 v17, 0 :: v_dual_and_b32 v16, 31, v0        // 000000579F38: CA240080 1110009F
	.long 0x7f103880                                           // 000000579F40: 7F103880
	s_waitcnt lgkmcnt(0)                                       // 000000579F44: BF89FC07
	s_clause 0x1                                               // 000000579F48: BF850001
	global_load_b32 v3, v1, s[4:5]                             // 000000579F4C: DC520000 03040001
	global_load_b32 v4, v2, s[4:5]                             // 000000579F54: DC520000 04040002
	v_mov_b32_e32 v2, s3                                       // 000000579F5C: 7E040203
	v_or_b32_e32 v1, s2, v14                                   // 000000579F60: 38021C02
	s_add_u32 s0, s4, s14                                      // 000000579F64: 80000E04
	s_addc_u32 s1, s5, s15                                     // 000000579F68: 82010F05
	s_lshr_b32 s14, s11, 31                                    // 000000579F6C: 850E9F0B
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000579F70: BF870009
	s_add_u32 s14, s10, s14                                    // 000000579F74: 800E0E0A
	s_addc_u32 s15, s11, 0                                     // 000000579F78: 820F800B
	s_ashr_i32 s20, s11, 31                                    // 000000579F7C: 86149F0B
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 000000579F80: 7CA8020C
	s_lshr_b32 s20, s20, 27                                    // 000000579F84: 85149B14
	s_ashr_i64 s[14:15], s[14:15], 1                           // 000000579F88: 868E810E
	s_add_u32 s20, s10, s20                                    // 000000579F8C: 8014140A
	s_addc_u32 s21, s11, 0                                     // 000000579F90: 8215800B
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000579F94: 02020280
	s_lshr_b64 s[20:21], s[20:21], 5                           // 000000579F98: 85948514
	v_cndmask_b32_e64 v7, 0, s3, vcc_lo                        // 000000579F9C: D5010007 01A80680
	s_add_i32 s21, s20, 1                                      // 000000579FA4: 81158114
	s_delay_alu instid0(VALU_DEP_2)                            // 000000579FA8: BF870002
	.long 0xd72c0002                                           // 000000579FAC: D72C0002
	v_cndmask_b32_e32 v1, s19, v1, vcc_lo                      // 000000579FB0: 02020213
	s_lshr_b32 s19, s21, 31                                    // 000000579FB4: 85139F15
	.long 0xd72c000d                                           // 000000579FB8: D72C000D
	v_cndmask_b32_e32 v0, v1, v15, vcc_lo                      // 000000579FBC: 02001F01
	s_add_i32 s21, s21, s19                                    // 000000579FC0: 81151315
	v_mad_u64_u32 v[9:10], null, v1, s14, s[0:1]               // 000000579FC4: D6FE7C09 00001D01
	s_ashr_i32 s15, s21, 1                                     // 000000579FCC: 860F8115
	s_add_u32 s0, s4, s16                                      // 000000579FD0: 80001004
	.long 0xd72c0012                                           // 000000579FD4: D72C0012
	v_cndmask_b32_e32 v1, s15, v15, vcc_lo                     // 000000579FD8: 02021E0F
	s_addc_u32 s1, s5, s17                                     // 000000579FDC: 82011105
	.long 0xd72c0014                                           // 000000579FE0: D72C0014
	v_cndmask_b32_e32 v0, v7, v14, vcc_lo                      // 000000579FE4: 02001D07
	.long 0xd72c0015                                           // 000000579FE8: D72C0015
	v_cndmask_b32_e32 v1, s18, v7, vcc_lo                      // 000000579FEC: 02020E12
	v_mov_b32_e32 v31, 0                                       // 000000579FF0: 7E3E0280
	v_mov_b32_e32 v7, 0                                        // 000000579FF4: 7E0E0280
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000579FF8: BF870154
	v_add3_u32 v10, v20, v10, v13                              // 000000579FFC: D655000A 04361514
	s_waitcnt vmcnt(1)                                         // 00000057A004: BF8907F7
	v_bfe_u32 v11, v3, 16, 1                                   // 00000057A008: D610000B 02052103
	s_waitcnt vmcnt(0)                                         // 00000057A010: BF8903F7
	v_bfe_u32 v19, v4, 16, 1                                   // 00000057A014: D6100013 02052104
	v_add3_u32 v3, v3, v11, 0x7fff                             // 00000057A01C: D6550003 03FE1703 00007FFF
	v_mad_u64_u32 v[11:12], null, s18, v1, s[0:1]              // 00000057A028: D6FE7C0B 00020212
	v_add_nc_u32_e32 v1, s15, v18                              // 00000057A030: 4A02240F
	s_delay_alu instid0(VALU_DEP_4)                            // 00000057A034: BF870004
	v_add3_u32 v4, v4, v19, 0x7fff                             // 00000057A038: D6550004 03FE2704 00007FFF
	v_add_nc_u32_e32 v18, v18, v16                             // 00000057A044: 4A242112
	.long 0x7e103983                                           // 00000057A048: 7E103983
	v_lshlrev_b32_e32 v3, 2, v0                                // 00000057A04C: 30060082
	v_min_i32_e32 v19, s20, v1                                 // 00000057A050: 22260214
	v_add3_u32 v20, v2, v12, v21                               // 00000057A054: D6550014 04561902
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000057A05C: BF870224
	v_and_or_b32 v1, 0xffff0000, v4, v8                        // 00000057A060: D6570001 042208FF FFFF0000
	v_mov_b32_e32 v8, 0                                        // 00000057A06C: 7E100280
	v_cmp_lt_i32_e32 vcc_lo, v18, v19                          // 00000057A070: 7C822712
	ds_store_b32 v3, v1                                        // 00000057A074: D8340000 00000103
	s_waitcnt lgkmcnt(0)                                       // 00000057A07C: BF89FC07
	s_barrier                                                  // 00000057A080: BFBD0000
	buffer_gl0_inv                                             // 00000057A084: E0AC0000 00000000
	s_and_saveexec_b32 s1, vcc_lo                              // 00000057A08C: BE81206A
	s_cbranch_execz 21                                         // 00000057A090: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x1e8>
	v_lshlrev_b32_e32 v1, 1, v18                               // 00000057A094: 30022481
	v_lshlrev_b32_e32 v3, 4, v18                               // 00000057A098: 30062484
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000057A09C: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000057A0A0: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 00000057A0A4: 3408069F
	.long 0xd7000001                                           // 00000057A0A8: D7000001
	v_cndmask_b32_e32 v1, v11, v1, vcc_lo                      // 00000057A0AC: 0202030B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057A0B0: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v20, v2, s0                  // 00000057A0B4: D5207C02 00020514
	.long 0xd7000003                                           // 00000057A0BC: D7000003
	v_cndmask_b32_e32 v1, v9, v3, vcc_lo                       // 00000057A0C0: 02020709
	v_add_co_ci_u32_e64 v4, null, v10, v4, s0                  // 00000057A0C4: D5207C04 0002090A
	s_clause 0x1                                               // 00000057A0CC: BF850001
	global_load_d16_b16 v1, v[1:2], off                        // 00000057A0D0: DC820000 017C0001
	global_load_b128 v[5:8], v[3:4], off                       // 00000057A0D8: DC5E0000 057C0003
	s_waitcnt vmcnt(1)                                         // 00000057A0E0: BF8907F7
	v_cvt_f32_f16_e32 v31, v1                                  // 00000057A0E4: 7E3E1701
	s_or_b32 exec_lo, exec_lo, s1                              // 00000057A0E8: 8C7E017E
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v23, 0             // 00000057A0EC: CA100080 16160080
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v25, 0             // 00000057A0F4: CA100080 18180080
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v27, 0             // 00000057A0FC: CA100080 1A1A0080
	v_mov_b32_e32 v21, 0                                       // 00000057A104: 7E2A0280
	s_and_saveexec_b32 s1, vcc_lo                              // 00000057A108: BE81206A
	s_cbranch_execz 639                                        // 00000057A10C: BFA5027F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0xc0c>
	v_dual_mov_b32 v26, 0 :: v_dual_add_nc_u32 v1, 32, v18     // 00000057A110: CA200080 1A0024A0
	v_dual_mov_b32 v21, 0 :: v_dual_lshlrev_b32 v12, 5, v18    // 00000057A118: CA220080 150C2485
	v_dual_mov_b32 v25, 0 :: v_dual_mov_b32 v22, 0             // 00000057A120: CA100080 19160080
	s_delay_alu instid0(VALU_DEP_3)                            // 00000057A128: BF870003
	v_dual_mov_b32 v27, 0 :: v_dual_lshlrev_b32 v28, 4, v1     // 00000057A12C: CA220080 1B1C0284
	v_dual_mov_b32 v24, 0 :: v_dual_lshlrev_b32 v29, 1, v1     // 00000057A134: CA220080 181C0281
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v30, v31           // 00000057A13C: CA100080 171E011F
	v_mov_b32_e32 v17, 0                                       // 00000057A144: 7E220280
	s_mul_i32 s0, s11, 6                                       // 00000057A148: 9600860B
	s_mul_hi_u32 s14, s10, 6                                   // 00000057A14C: 968E860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 00000057A150: 8484820A
	s_add_i32 s14, s14, s0                                     // 00000057A154: 810E000E
	s_mul_i32 s16, s10, 6                                      // 00000057A158: 9610860A
	s_mov_b32 s15, 0                                           // 00000057A15C: BE8F0080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 00000057A160: 848A810A
	s_branch 585                                               // 00000057A164: BFA00249 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0xb8c>
	s_or_b32 exec_lo, exec_lo, s17                             // 00000057A168: 8C7E117E
	v_and_b32_e32 v13, 0xff, v5                                // 00000057A16C: 361A0AFF 000000FF
	s_and_b32 s0, exec_lo, vcc_lo                              // 00000057A174: 8B006A7E
	v_add_nc_u32_e32 v29, 64, v29                              // 00000057A178: 4A3A3AC0
	s_or_b32 s15, s0, s15                                      // 00000057A17C: 8C0F0F00
	v_add_nc_u32_e32 v28, 0x200, v28                           // 00000057A180: 4A3838FF 00000200
	v_lshlrev_b32_e32 v13, 2, v13                              // 00000057A188: 301A1A82
	ds_load_b32 v48, v13                                       // 00000057A18C: D8D80000 3000000D
	v_lshrrev_b32_e32 v13, 6, v5                               // 00000057A194: 321A0A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000057A198: BF870141
	v_and_b32_e32 v13, 0x3fc, v13                              // 00000057A19C: 361A1AFF 000003FC
	ds_load_b32 v49, v13                                       // 00000057A1A4: D8D80000 3100000D
	v_lshrrev_b32_e32 v13, 14, v5                              // 00000057A1AC: 321A0A8E
	v_lshrrev_b32_e32 v5, 22, v5                               // 00000057A1B0: 320A0A96
	v_and_b32_e32 v13, 0x3fc, v13                              // 00000057A1B4: 361A1AFF 000003FC
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 00000057A1BC: BF870152
	v_and_b32_e32 v5, 0x3fc, v5                                // 00000057A1C0: 360A0AFF 000003FC
	ds_load_b32 v50, v13                                       // 00000057A1C8: D8D80000 3200000D
	ds_load_b32 v51, v5                                        // 00000057A1D0: D8D80000 33000005
	v_and_b32_e32 v5, 0xff, v6                                 // 00000057A1D8: 360A0CFF 000000FF
	v_ashrrev_i32_e32 v13, 31, v12                             // 00000057A1E0: 341A189F
	v_lshlrev_b32_e32 v5, 2, v5                                // 00000057A1E4: 300A0A82
	ds_load_b32 v52, v5                                        // 00000057A1E8: D8D80000 34000005
	v_lshrrev_b32_e32 v5, 6, v6                                // 00000057A1F0: 320A0C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000057A1F4: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 00000057A1F8: 360A0AFF 000003FC
	ds_load_b32 v53, v5                                        // 00000057A200: D8D80000 35000005
	v_lshrrev_b32_e32 v5, 14, v6                               // 00000057A208: 320A0C8E
	v_and_b32_e32 v5, 0x3fc, v5                                // 00000057A20C: 360A0AFF 000003FC
	ds_load_b32 v54, v5                                        // 00000057A214: D8D80000 36000005
	v_lshrrev_b32_e32 v5, 22, v6                               // 00000057A21C: 320A0C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000057A220: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 00000057A224: 360A0AFF 000003FC
	ds_load_b32 v55, v5                                        // 00000057A22C: D8D80000 37000005
	v_and_b32_e32 v5, 0xff, v7                                 // 00000057A234: 360A0EFF 000000FF
	v_lshlrev_b32_e32 v5, 2, v5                                // 00000057A23C: 300A0A82
	ds_load_b32 v56, v5                                        // 00000057A240: D8D80000 38000005
	v_lshrrev_b32_e32 v5, 6, v7                                // 00000057A248: 320A0E86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000057A24C: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 00000057A250: 360A0AFF 000003FC
	ds_load_b32 v57, v5                                        // 00000057A258: D8D80000 39000005
	v_lshrrev_b32_e32 v5, 14, v7                               // 00000057A260: 320A0E8E
	v_and_b32_e32 v5, 0x3fc, v5                                // 00000057A264: 360A0AFF 000003FC
	ds_load_b32 v58, v5                                        // 00000057A26C: D8D80000 3A000005
	v_lshrrev_b32_e32 v5, 22, v7                               // 00000057A274: 320A0E96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000057A278: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 00000057A27C: 360A0AFF 000003FC
	ds_load_b32 v59, v5                                        // 00000057A284: D8D80000 3B000005
	v_and_b32_e32 v5, 0xff, v8                                 // 00000057A28C: 360A10FF 000000FF
	v_lshlrev_b32_e32 v5, 2, v5                                // 00000057A294: 300A0A82
	ds_load_b32 v60, v5                                        // 00000057A298: D8D80000 3C000005
	v_lshrrev_b32_e32 v5, 6, v8                                // 00000057A2A0: 320A1086
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000057A2A4: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 00000057A2A8: 360A0AFF 000003FC
	ds_load_b32 v61, v5                                        // 00000057A2B0: D8D80000 3D000005
	v_lshrrev_b32_e32 v5, 14, v8                               // 00000057A2B8: 320A108E
	v_and_b32_e32 v5, 0x3fc, v5                                // 00000057A2BC: 360A0AFF 000003FC
	ds_load_b32 v62, v5                                        // 00000057A2C4: D8D80000 3E000005
	v_lshrrev_b32_e32 v5, 22, v8                               // 00000057A2CC: 320A1096
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000057A2D0: BF870141
	v_and_b32_e32 v5, 0x3fc, v5                                // 00000057A2D4: 360A0AFF 000003FC
	ds_load_b32 v63, v5                                        // 00000057A2DC: D8D80000 3F000005
	.long 0xd73c0005                                           // 00000057A2E4: D73C0005
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 00000057A2E8: 02021881
	v_add_nc_u32_e32 v12, 0x400, v12                           // 00000057A2EC: 4A1818FF 00000400
	.long 0xd7006a2c                                           // 00000057A2F4: D7006A2C
	v_cndmask_b32_e32 v1, s6, v5, vcc_lo                       // 00000057A2F8: 02020A06
	s_delay_alu instid0(VALU_DEP_1)                            // 00000057A2FC: BF870001
	v_add_co_ci_u32_e64 v45, null, s7, v6, vcc_lo              // 00000057A300: D5207C2D 01AA0C07
	s_clause 0x3                                               // 00000057A308: BF850003
	global_load_b128 v[5:8], v[44:45], off                     // 00000057A30C: DC5E0000 057C002C
	global_load_b128 v[32:35], v[44:45], off offset:16         // 00000057A314: DC5E0010 207C002C
	global_load_b128 v[36:39], v[44:45], off offset:32         // 00000057A31C: DC5E0020 247C002C
	global_load_b128 v[40:43], v[44:45], off offset:48         // 00000057A324: DC5E0030 287C002C
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 00000057A32C: BF890CF7
	v_dot2_f32_bf16 v5, v5, v48, 0                             // 00000057A330: CC1A4005 1A026105
	s_waitcnt lgkmcnt(14)                                      // 00000057A338: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057A33C: BF8700A1
	v_dot2_f32_bf16 v5, v6, v49, v5                            // 00000057A340: CC1A4005 1C166306
	s_waitcnt lgkmcnt(13)                                      // 00000057A348: BF89FCD7
	v_dot2_f32_bf16 v5, v7, v50, v5                            // 00000057A34C: CC1A4005 1C166507
	s_waitcnt lgkmcnt(12)                                      // 00000057A354: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057A358: BF8700A1
	v_dot2_f32_bf16 v5, v8, v51, v5                            // 00000057A35C: CC1A4005 1C166708
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 00000057A364: BF8908B7
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 00000057A368: CC1A4005 1C166920
	s_waitcnt lgkmcnt(10)                                      // 00000057A370: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057A374: BF8700A1
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 00000057A378: CC1A4005 1C166B21
	s_waitcnt lgkmcnt(9)                                       // 00000057A380: BF89FC97
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 00000057A384: CC1A4005 1C166D22
	s_waitcnt lgkmcnt(8)                                       // 00000057A38C: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057A390: BF8700A1
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 00000057A394: CC1A4005 1C166F23
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 00000057A39C: BF890477
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 00000057A3A0: CC1A4005 1C167124
	s_waitcnt lgkmcnt(6)                                       // 00000057A3A8: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057A3AC: BF8700A1
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 00000057A3B0: CC1A4005 1C167325
	s_waitcnt lgkmcnt(5)                                       // 00000057A3B8: BF89FC57
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 00000057A3BC: CC1A4005 1C167526
	s_waitcnt lgkmcnt(4)                                       // 00000057A3C4: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057A3C8: BF8700A1
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 00000057A3CC: CC1A4005 1C167727
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 00000057A3D4: BF890037
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 00000057A3D8: CC1A4005 1C167928
	.long 0xd7006a28                                           // 00000057A3E0: D7006A28
	v_cndmask_b32_e32 v0, v44, v10, vcc_lo                     // 00000057A3E4: 0200152C
	s_waitcnt lgkmcnt(2)                                       // 00000057A3E8: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000057A3EC: BF8701C2
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 00000057A3F0: CC1A4005 1C167B29
	v_add_co_ci_u32_e64 v41, null, s11, v45, vcc_lo            // 00000057A3F8: D5207C29 01AA5A0B
	.long 0xd7006a2e                                           // 00000057A400: D7006A2E
	v_cndmask_b32_e32 v0, v44, v4, vcc_lo                      // 00000057A404: 0200092C
	s_waitcnt lgkmcnt(1)                                       // 00000057A408: BF89FC17
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 00000057A40C: CC1A4005 1C167D2A
	v_add_co_ci_u32_e64 v47, null, s5, v45, vcc_lo             // 00000057A414: D5207C2F 01AA5A05
	.long 0xd7006a2c                                           // 00000057A41C: D7006A2C
	v_cndmask_b32_e32 v0, v44, v16, vcc_lo                     // 00000057A420: 0200212C
	s_waitcnt lgkmcnt(0)                                       // 00000057A424: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000057A428: BF870123
	v_dot2_f32_bf16 v5, v43, v63, v5                           // 00000057A42C: CC1A4005 1C167F2B
	v_add_co_ci_u32_e64 v45, null, s14, v45, vcc_lo            // 00000057A434: D5207C2D 01AA5A0E
	v_fmac_f32_e32 v21, v31, v5                                // 00000057A43C: 562A0B1F
	s_clause 0x3                                               // 00000057A440: BF850003
	global_load_b128 v[5:8], v[40:41], off                     // 00000057A444: DC5E0000 057C0028
	global_load_b128 v[32:35], v[40:41], off offset:16         // 00000057A44C: DC5E0010 207C0028
	global_load_b128 v[36:39], v[40:41], off offset:32         // 00000057A454: DC5E0020 247C0028
	global_load_b128 v[40:43], v[40:41], off offset:48         // 00000057A45C: DC5E0030 287C0028
	s_waitcnt vmcnt(3)                                         // 00000057A464: BF890FF7
	v_dot2_f32_bf16 v5, v5, v48, 0                             // 00000057A468: CC1A4005 1A026105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057A470: BF870091
	v_dot2_f32_bf16 v5, v6, v49, v5                            // 00000057A474: CC1A4005 1C166306
	v_dot2_f32_bf16 v5, v7, v50, v5                            // 00000057A47C: CC1A4005 1C166507
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057A484: BF8700A1
	v_dot2_f32_bf16 v5, v8, v51, v5                            // 00000057A488: CC1A4005 1C166708
	s_waitcnt vmcnt(2)                                         // 00000057A490: BF890BF7
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 00000057A494: CC1A4005 1C166920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057A49C: BF870091
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 00000057A4A0: CC1A4005 1C166B21
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 00000057A4A8: CC1A4005 1C166D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057A4B0: BF8700A1
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 00000057A4B4: CC1A4005 1C166F23
	s_waitcnt vmcnt(1)                                         // 00000057A4BC: BF8907F7
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 00000057A4C0: CC1A4005 1C167124
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057A4C8: BF870091
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 00000057A4CC: CC1A4005 1C167325
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 00000057A4D4: CC1A4005 1C167526
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057A4DC: BF8700A1
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 00000057A4E0: CC1A4005 1C167727
	s_waitcnt vmcnt(0)                                         // 00000057A4E8: BF8903F7
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 00000057A4EC: CC1A4005 1C167928
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057A4F4: BF870091
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 00000057A4F8: CC1A4005 1C167B29
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 00000057A500: CC1A4005 1C167D2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057A508: BF870091
	v_dot2_f32_bf16 v5, v43, v63, v5                           // 00000057A50C: CC1A4005 1C167F2B
	v_fmac_f32_e32 v27, v31, v5                                // 00000057A514: 56360B1F
	s_clause 0x3                                               // 00000057A518: BF850003
	global_load_b128 v[5:8], v[46:47], off                     // 00000057A51C: DC5E0000 057C002E
	global_load_b128 v[32:35], v[46:47], off offset:16         // 00000057A524: DC5E0010 207C002E
	global_load_b128 v[36:39], v[46:47], off offset:32         // 00000057A52C: DC5E0020 247C002E
	global_load_b128 v[40:43], v[46:47], off offset:48         // 00000057A534: DC5E0030 287C002E
	.long 0xd7006a2e                                           // 00000057A53C: D7006A2E
	v_cndmask_b32_e32 v0, v46, v4, vcc_lo                      // 00000057A540: 0200092E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000057A544: BF8700B1
	v_add_co_ci_u32_e64 v47, null, s5, v47, vcc_lo             // 00000057A548: D5207C2F 01AA5E05
	s_waitcnt vmcnt(3)                                         // 00000057A550: BF890FF7
	v_dot2_f32_bf16 v5, v5, v48, 0                             // 00000057A554: CC1A4005 1A026105
	v_dot2_f32_bf16 v5, v6, v49, v5                            // 00000057A55C: CC1A4005 1C166306
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057A564: BF870091
	v_dot2_f32_bf16 v5, v7, v50, v5                            // 00000057A568: CC1A4005 1C166507
	v_dot2_f32_bf16 v5, v8, v51, v5                            // 00000057A570: CC1A4005 1C166708
	s_waitcnt vmcnt(2)                                         // 00000057A578: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057A57C: BF870091
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 00000057A580: CC1A4005 1C166920
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 00000057A588: CC1A4005 1C166B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057A590: BF870091
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 00000057A594: CC1A4005 1C166D22
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 00000057A59C: CC1A4005 1C166F23
	s_waitcnt vmcnt(1)                                         // 00000057A5A4: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057A5A8: BF870091
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 00000057A5AC: CC1A4005 1C167124
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 00000057A5B4: CC1A4005 1C167325
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057A5BC: BF870091
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 00000057A5C0: CC1A4005 1C167526
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 00000057A5C8: CC1A4005 1C167727
	s_waitcnt vmcnt(0)                                         // 00000057A5D0: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057A5D4: BF870091
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 00000057A5D8: CC1A4005 1C167928
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 00000057A5E0: CC1A4005 1C167B29
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057A5E8: BF870091
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 00000057A5EC: CC1A4005 1C167D2A
	v_dot2_f32_bf16 v5, v43, v63, v5                           // 00000057A5F4: CC1A4005 1C167F2B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000057A5FC: BF870001
	v_fmac_f32_e32 v26, v31, v5                                // 00000057A600: 56340B1F
	s_clause 0x3                                               // 00000057A604: BF850003
	global_load_b128 v[5:8], v[44:45], off                     // 00000057A608: DC5E0000 057C002C
	global_load_b128 v[32:35], v[44:45], off offset:16         // 00000057A610: DC5E0010 207C002C
	global_load_b128 v[36:39], v[44:45], off offset:32         // 00000057A618: DC5E0020 247C002C
	global_load_b128 v[40:43], v[44:45], off offset:48         // 00000057A620: DC5E0030 287C002C
	.long 0xd7006a2c                                           // 00000057A628: D7006A2C
	v_cndmask_b32_e32 v0, v44, v4, vcc_lo                      // 00000057A62C: 0200092C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000057A630: BF8700B1
	v_add_co_ci_u32_e64 v45, null, s5, v45, vcc_lo             // 00000057A634: D5207C2D 01AA5A05
	s_waitcnt vmcnt(3)                                         // 00000057A63C: BF890FF7
	v_dot2_f32_bf16 v5, v5, v48, 0                             // 00000057A640: CC1A4005 1A026105
	v_dot2_f32_bf16 v5, v6, v49, v5                            // 00000057A648: CC1A4005 1C166306
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057A650: BF870091
	v_dot2_f32_bf16 v5, v7, v50, v5                            // 00000057A654: CC1A4005 1C166507
	v_dot2_f32_bf16 v5, v8, v51, v5                            // 00000057A65C: CC1A4005 1C166708
	s_waitcnt vmcnt(2)                                         // 00000057A664: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057A668: BF870091
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 00000057A66C: CC1A4005 1C166920
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 00000057A674: CC1A4005 1C166B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057A67C: BF870091
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 00000057A680: CC1A4005 1C166D22
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 00000057A688: CC1A4005 1C166F23
	s_waitcnt vmcnt(1)                                         // 00000057A690: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057A694: BF870091
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 00000057A698: CC1A4005 1C167124
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 00000057A6A0: CC1A4005 1C167325
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057A6A8: BF870091
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 00000057A6AC: CC1A4005 1C167526
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 00000057A6B4: CC1A4005 1C167727
	s_waitcnt vmcnt(0)                                         // 00000057A6BC: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057A6C0: BF870091
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 00000057A6C4: CC1A4005 1C167928
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 00000057A6CC: CC1A4005 1C167B29
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057A6D4: BF870091
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 00000057A6D8: CC1A4005 1C167D2A
	v_dot2_f32_bf16 v5, v43, v63, v5                           // 00000057A6E0: CC1A4005 1C167F2B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000057A6E8: BF870001
	v_fmac_f32_e32 v25, v31, v5                                // 00000057A6EC: 56320B1F
	s_clause 0x3                                               // 00000057A6F0: BF850003
	global_load_b128 v[5:8], v[46:47], off                     // 00000057A6F4: DC5E0000 057C002E
	global_load_b128 v[32:35], v[46:47], off offset:16         // 00000057A6FC: DC5E0010 207C002E
	global_load_b128 v[36:39], v[46:47], off offset:32         // 00000057A704: DC5E0020 247C002E
	global_load_b128 v[40:43], v[46:47], off offset:48         // 00000057A70C: DC5E0030 287C002E
	s_waitcnt vmcnt(3)                                         // 00000057A714: BF890FF7
	v_dot2_f32_bf16 v5, v5, v48, 0                             // 00000057A718: CC1A4005 1A026105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057A720: BF870091
	v_dot2_f32_bf16 v5, v6, v49, v5                            // 00000057A724: CC1A4005 1C166306
	v_dot2_f32_bf16 v5, v7, v50, v5                            // 00000057A72C: CC1A4005 1C166507
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057A734: BF8700A1
	v_dot2_f32_bf16 v5, v8, v51, v5                            // 00000057A738: CC1A4005 1C166708
	s_waitcnt vmcnt(2)                                         // 00000057A740: BF890BF7
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 00000057A744: CC1A4005 1C166920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057A74C: BF870091
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 00000057A750: CC1A4005 1C166B21
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 00000057A758: CC1A4005 1C166D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057A760: BF8700A1
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 00000057A764: CC1A4005 1C166F23
	s_waitcnt vmcnt(1)                                         // 00000057A76C: BF8907F7
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 00000057A770: CC1A4005 1C167124
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057A778: BF870091
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 00000057A77C: CC1A4005 1C167325
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 00000057A784: CC1A4005 1C167526
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057A78C: BF8700A1
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 00000057A790: CC1A4005 1C167727
	s_waitcnt vmcnt(0)                                         // 00000057A798: BF8903F7
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 00000057A79C: CC1A4005 1C167928
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057A7A4: BF870091
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 00000057A7A8: CC1A4005 1C167B29
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 00000057A7B0: CC1A4005 1C167D2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057A7B8: BF870091
	v_dot2_f32_bf16 v5, v43, v63, v5                           // 00000057A7BC: CC1A4005 1C167F2B
	v_fmac_f32_e32 v24, v31, v5                                // 00000057A7C4: 56300B1F
	s_clause 0x3                                               // 00000057A7C8: BF850003
	global_load_b128 v[5:8], v[44:45], off                     // 00000057A7CC: DC5E0000 057C002C
	global_load_b128 v[32:35], v[44:45], off offset:16         // 00000057A7D4: DC5E0010 207C002C
	global_load_b128 v[36:39], v[44:45], off offset:32         // 00000057A7DC: DC5E0020 247C002C
	global_load_b128 v[40:43], v[44:45], off offset:48         // 00000057A7E4: DC5E0030 287C002C
	s_waitcnt vmcnt(3)                                         // 00000057A7EC: BF890FF7
	v_dot2_f32_bf16 v5, v5, v48, 0                             // 00000057A7F0: CC1A4005 1A026105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057A7F8: BF870091
	v_dot2_f32_bf16 v5, v6, v49, v5                            // 00000057A7FC: CC1A4005 1C166306
	v_dot2_f32_bf16 v5, v7, v50, v5                            // 00000057A804: CC1A4005 1C166507
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057A80C: BF8700A1
	v_dot2_f32_bf16 v5, v8, v51, v5                            // 00000057A810: CC1A4005 1C166708
	s_waitcnt vmcnt(2)                                         // 00000057A818: BF890BF7
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 00000057A81C: CC1A4005 1C166920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057A824: BF870091
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 00000057A828: CC1A4005 1C166B21
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 00000057A830: CC1A4005 1C166D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057A838: BF8700A1
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 00000057A83C: CC1A4005 1C166F23
	s_waitcnt vmcnt(1)                                         // 00000057A844: BF8907F7
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 00000057A848: CC1A4005 1C167124
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057A850: BF870091
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 00000057A854: CC1A4005 1C167325
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 00000057A85C: CC1A4005 1C167526
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057A864: BF8700A1
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 00000057A868: CC1A4005 1C167727
	s_waitcnt vmcnt(0)                                         // 00000057A870: BF8903F7
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 00000057A874: CC1A4005 1C167928
	.long 0xd7006a28                                           // 00000057A87C: D7006A28
	v_cndmask_b32_e32 v0, v46, v4, vcc_lo                      // 00000057A880: 0200092E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000057A884: BF870122
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 00000057A888: CC1A4005 1C167B29
	v_add_co_ci_u32_e64 v41, null, s5, v47, vcc_lo             // 00000057A890: D5207C29 01AA5E05
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 00000057A898: CC1A4005 1C167D2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057A8A0: BF870091
	v_dot2_f32_bf16 v5, v43, v63, v5                           // 00000057A8A4: CC1A4005 1C167F2B
	v_fmac_f32_e32 v23, v31, v5                                // 00000057A8AC: 562E0B1F
	s_clause 0x3                                               // 00000057A8B0: BF850003
	global_load_b128 v[5:8], v[40:41], off                     // 00000057A8B4: DC5E0000 057C0028
	global_load_b128 v[32:35], v[40:41], off offset:16         // 00000057A8BC: DC5E0010 207C0028
	global_load_b128 v[36:39], v[40:41], off offset:32         // 00000057A8C4: DC5E0020 247C0028
	global_load_b128 v[40:43], v[40:41], off offset:48         // 00000057A8CC: DC5E0030 287C0028
	s_waitcnt vmcnt(3)                                         // 00000057A8D4: BF890FF7
	v_dot2_f32_bf16 v5, v5, v48, 0                             // 00000057A8D8: CC1A4005 1A026105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057A8E0: BF870091
	v_dot2_f32_bf16 v5, v6, v49, v5                            // 00000057A8E4: CC1A4005 1C166306
	v_dot2_f32_bf16 v5, v7, v50, v5                            // 00000057A8EC: CC1A4005 1C166507
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057A8F4: BF8700A1
	v_dot2_f32_bf16 v5, v8, v51, v5                            // 00000057A8F8: CC1A4005 1C166708
	s_waitcnt vmcnt(2)                                         // 00000057A900: BF890BF7
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 00000057A904: CC1A4005 1C166920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057A90C: BF870091
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 00000057A910: CC1A4005 1C166B21
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 00000057A918: CC1A4005 1C166D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057A920: BF8700A1
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 00000057A924: CC1A4005 1C166F23
	s_waitcnt vmcnt(1)                                         // 00000057A92C: BF8907F7
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 00000057A930: CC1A4005 1C167124
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057A938: BF870091
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 00000057A93C: CC1A4005 1C167325
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 00000057A944: CC1A4005 1C167526
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057A94C: BF8700A1
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 00000057A950: CC1A4005 1C167727
	s_waitcnt vmcnt(0)                                         // 00000057A958: BF8903F7
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 00000057A95C: CC1A4005 1C167928
	.long 0xd7006a28                                           // 00000057A964: D7006A28
	v_cndmask_b32_e32 v0, v44, v4, vcc_lo                      // 00000057A968: 0200092C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000057A96C: BF870122
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 00000057A970: CC1A4005 1C167B29
	v_add_co_ci_u32_e64 v41, null, s5, v45, vcc_lo             // 00000057A978: D5207C29 01AA5A05
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 00000057A980: CC1A4005 1C167D2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057A988: BF870091
	v_dot2_f32_bf16 v5, v43, v63, v5                           // 00000057A98C: CC1A4005 1C167F2B
	v_fmac_f32_e32 v22, v31, v5                                // 00000057A994: 562C0B1F
	s_clause 0x3                                               // 00000057A998: BF850003
	global_load_b128 v[5:8], v[40:41], off                     // 00000057A99C: DC5E0000 057C0028
	global_load_b128 v[32:35], v[40:41], off offset:16         // 00000057A9A4: DC5E0010 207C0028
	global_load_b128 v[36:39], v[40:41], off offset:32         // 00000057A9AC: DC5E0020 247C0028
	global_load_b128 v[40:43], v[40:41], off offset:48         // 00000057A9B4: DC5E0030 287C0028
	s_waitcnt vmcnt(3)                                         // 00000057A9BC: BF890FF7
	v_dot2_f32_bf16 v5, v5, v48, 0                             // 00000057A9C0: CC1A4005 1A026105
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000057A9C8: BF870121
	v_dot2_f32_bf16 v5, v6, v49, v5                            // 00000057A9CC: CC1A4005 1C166306
	v_mov_b32_e32 v6, v2                                       // 00000057A9D4: 7E0C0302
	v_dot2_f32_bf16 v5, v7, v50, v5                            // 00000057A9D8: CC1A4005 1C166507
	v_mov_b32_e32 v7, v3                                       // 00000057A9E0: 7E0E0303
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000057A9E4: BF870132
	v_dot2_f32_bf16 v5, v8, v51, v5                            // 00000057A9E8: CC1A4005 1C166708
	v_mov_b32_e32 v8, v4                                       // 00000057A9F0: 7E100304
	s_waitcnt vmcnt(2)                                         // 00000057A9F4: BF890BF7
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 00000057A9F8: CC1A4005 1C166920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057AA00: BF870091
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 00000057AA04: CC1A4005 1C166B21
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 00000057AA0C: CC1A4005 1C166D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057AA14: BF8700A1
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 00000057AA18: CC1A4005 1C166F23
	s_waitcnt vmcnt(1)                                         // 00000057AA20: BF8907F7
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 00000057AA24: CC1A4005 1C167124
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057AA2C: BF870091
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 00000057AA30: CC1A4005 1C167325
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 00000057AA38: CC1A4005 1C167526
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057AA40: BF8700A1
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 00000057AA44: CC1A4005 1C167727
	s_waitcnt vmcnt(0)                                         // 00000057AA4C: BF8903F7
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 00000057AA50: CC1A4005 1C167928
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057AA58: BF870091
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 00000057AA5C: CC1A4005 1C167B29
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 00000057AA64: CC1A4005 1C167D2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057AA6C: BF870091
	v_dot2_f32_bf16 v5, v43, v63, v5                           // 00000057AA70: CC1A4005 1C167F2B
	v_fmac_f32_e32 v17, v31, v5                                // 00000057AA78: 56220B1F
	v_mov_b32_e32 v5, v1                                       // 00000057AA7C: 7E0A0301
	v_mov_b32_e32 v31, v30                                     // 00000057AA80: 7E3E031E
	s_and_not1_b32 exec_lo, exec_lo, s15                       // 00000057AA84: 917E0F7E
	s_cbranch_execz 31                                         // 00000057AA88: BFA5001F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0xc08>
	s_waitcnt vmcnt(0)                                         // 00000057AA8C: BF8903F7
	v_dual_mov_b32 v1, v5 :: v_dual_add_nc_u32 v18, 32, v18    // 00000057AA90: CA200105 011224A0
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v3, v7             // 00000057AA98: CA100106 02020107
	v_mov_b32_e32 v4, v8                                       // 00000057AAA0: 7E080308
	s_mov_b32 s17, exec_lo                                     // 00000057AAA4: BE91007E
	s_delay_alu instid0(VALU_DEP_3)                            // 00000057AAA8: BF870003
	v_cmp_ge_i32_e32 vcc_lo, v18, v19                          // 00000057AAAC: 7C8C2712
	.long 0xd4c1007e                                           // 00000057AAB0: D4C1007E
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 00000057AAB4: 02022712
	s_cbranch_execz 64939                                      // 00000057AAB8: BFA5FDAB <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x268>
	v_ashrrev_i32_e32 v2, 31, v29                              // 00000057AABC: 34043A9F
	v_ashrrev_i32_e32 v4, 31, v28                              // 00000057AAC0: 3408389F
	.long 0xd7000001                                           // 00000057AAC4: D7000001
	v_cndmask_b32_e32 v1, v11, v29, vcc_lo                     // 00000057AAC8: 02023B0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057AACC: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v20, v2, s0                  // 00000057AAD0: D5207C02 00020514
	.long 0xd7000003                                           // 00000057AAD8: D7000003
	v_cndmask_b32_e32 v1, v9, v28, vcc_lo                      // 00000057AADC: 02023909
	v_add_co_ci_u32_e64 v4, null, v10, v4, s0                  // 00000057AAE0: D5207C04 0002090A
	s_clause 0x1                                               // 00000057AAE8: BF850001
	global_load_d16_b16 v13, v[1:2], off                       // 00000057AAEC: DC820000 0D7C0001
	global_load_b128 v[1:4], v[3:4], off                       // 00000057AAF4: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 00000057AAFC: BF8907F7
	v_cvt_f32_f16_e32 v30, v13                                 // 00000057AB00: 7E3C170D
	s_branch 64920                                             // 00000057AB04: BFA0FD98 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x268>
	s_or_b32 exec_lo, exec_lo, s15                             // 00000057AB08: 8C7E0F7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000057AB0C: BF8700B9
	s_or_b32 exec_lo, exec_lo, s1                              // 00000057AB10: 8C7E017E
	.long 0xd71f0001                                           // 00000057AB14: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000057AB18: 020100C1
	s_mov_b32 s0, exec_lo                                      // 00000057AB1C: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 00000057AB20: 3A040290
	v_xor_b32_e32 v10, 8, v1                                   // 00000057AB24: 3A140288
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000057AB28: BF8701A2
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 00000057AB2C: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 00000057AB30: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 00000057AB34: 7C9814A0
	s_delay_alu instid0(VALU_DEP_2)                            // 00000057AB38: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 00000057AB3C: 30040482
	ds_bpermute_b32 v3, v2, v21                                // 00000057AB40: DACC0000 03001502
	s_waitcnt lgkmcnt(0)                                       // 00000057AB48: BF89FC07
	v_add_f32_e32 v3, v21, v3                                  // 00000057AB4C: 06060715
	s_waitcnt vmcnt(0)                                         // 00000057AB50: BF8903F7
	ds_bpermute_b32 v5, v2, v26                                // 00000057AB54: DACC0000 05001A02
	ds_bpermute_b32 v7, v2, v24                                // 00000057AB5C: DACC0000 07001802
	ds_bpermute_b32 v9, v2, v22                                // 00000057AB64: DACC0000 09001602
	v_cndmask_b32_e32 v10, v1, v10, vcc_lo                     // 00000057AB6C: 02141501
	ds_bpermute_b32 v4, v2, v27                                // 00000057AB70: DACC0000 04001B02
	ds_bpermute_b32 v6, v2, v25                                // 00000057AB78: DACC0000 06001902
	ds_bpermute_b32 v8, v2, v23                                // 00000057AB80: DACC0000 08001702
	ds_bpermute_b32 v2, v2, v17                                // 00000057AB88: DACC0000 02001102
	v_xor_b32_e32 v21, 4, v1                                   // 00000057AB90: 3A2A0284
	s_delay_alu instid0(VALU_DEP_1)                            // 00000057AB94: BF870001
	v_cmp_gt_u32_e32 vcc_lo, 32, v21                           // 00000057AB98: 7C982AA0
	v_cndmask_b32_e32 v21, v1, v21, vcc_lo                     // 00000057AB9C: 022A2B01
	s_waitcnt lgkmcnt(6)                                       // 00000057ABA0: BF89FC67
	v_add_f32_e32 v5, v26, v5                                  // 00000057ABA4: 060A0B1A
	s_waitcnt lgkmcnt(5)                                       // 00000057ABA8: BF89FC57
	v_dual_add_f32 v7, v24, v7 :: v_dual_lshlrev_b32 v10, 2, v10// 00000057ABAC: C9220F18 070A1482
	s_waitcnt lgkmcnt(3)                                       // 00000057ABB4: BF89FC37
	v_dual_add_f32 v9, v22, v9 :: v_dual_add_f32 v4, v27, v4   // 00000057ABB8: C9081316 0904091B
	s_waitcnt lgkmcnt(2)                                       // 00000057ABC0: BF89FC27
	v_dual_add_f32 v6, v25, v6 :: v_dual_lshlrev_b32 v21, 2, v21// 00000057ABC4: C9220D19 06142A82
	ds_bpermute_b32 v11, v10, v3                               // 00000057ABCC: DACC0000 0B00030A
	ds_bpermute_b32 v13, v10, v5                               // 00000057ABD4: DACC0000 0D00050A
	s_waitcnt lgkmcnt(3)                                       // 00000057ABDC: BF89FC37
	v_add_f32_e32 v8, v23, v8                                  // 00000057ABE0: 06101117
	s_waitcnt lgkmcnt(2)                                       // 00000057ABE4: BF89FC27
	v_add_f32_e32 v2, v17, v2                                  // 00000057ABE8: 06040511
	ds_bpermute_b32 v12, v10, v4                               // 00000057ABEC: DACC0000 0C00040A
	ds_bpermute_b32 v17, v10, v6                               // 00000057ABF4: DACC0000 1100060A
	ds_bpermute_b32 v18, v10, v7                               // 00000057ABFC: DACC0000 1200070A
	ds_bpermute_b32 v20, v10, v9                               // 00000057AC04: DACC0000 1400090A
	s_waitcnt lgkmcnt(5)                                       // 00000057AC0C: BF89FC57
	v_add_f32_e32 v3, v3, v11                                  // 00000057AC10: 06061703
	s_waitcnt lgkmcnt(4)                                       // 00000057AC14: BF89FC47
	v_add_f32_e32 v5, v5, v13                                  // 00000057AC18: 060A1B05
	ds_bpermute_b32 v19, v10, v8                               // 00000057AC1C: DACC0000 1300080A
	ds_bpermute_b32 v10, v10, v2                               // 00000057AC24: DACC0000 0A00020A
	s_waitcnt lgkmcnt(5)                                       // 00000057AC2C: BF89FC57
	v_add_f32_e32 v4, v4, v12                                  // 00000057AC30: 06081904
	s_waitcnt lgkmcnt(3)                                       // 00000057AC34: BF89FC37
	v_dual_add_f32 v6, v6, v17 :: v_dual_add_f32 v7, v7, v18   // 00000057AC38: C9082306 06062507
	s_waitcnt lgkmcnt(2)                                       // 00000057AC40: BF89FC27
	v_add_f32_e32 v9, v9, v20                                  // 00000057AC44: 06122909
	ds_bpermute_b32 v12, v21, v5                               // 00000057AC48: DACC0000 0C000515
	ds_bpermute_b32 v11, v21, v4                               // 00000057AC50: DACC0000 0B000415
	ds_bpermute_b32 v13, v21, v6                               // 00000057AC58: DACC0000 0D000615
	ds_bpermute_b32 v17, v21, v7                               // 00000057AC60: DACC0000 11000715
	s_waitcnt lgkmcnt(5)                                       // 00000057AC68: BF89FC57
	v_add_f32_e32 v8, v8, v19                                  // 00000057AC6C: 06102708
	s_waitcnt lgkmcnt(4)                                       // 00000057AC70: BF89FC47
	v_add_f32_e32 v2, v2, v10                                  // 00000057AC74: 06041502
	ds_bpermute_b32 v10, v21, v3                               // 00000057AC78: DACC0000 0A000315
	ds_bpermute_b32 v19, v21, v9                               // 00000057AC80: DACC0000 13000915
	ds_bpermute_b32 v18, v21, v8                               // 00000057AC88: DACC0000 12000815
	ds_bpermute_b32 v20, v21, v2                               // 00000057AC90: DACC0000 14000215
	v_xor_b32_e32 v21, 2, v1                                   // 00000057AC98: 3A2A0282
	s_waitcnt lgkmcnt(5)                                       // 00000057AC9C: BF89FC57
	v_dual_add_f32 v5, v5, v12 :: v_dual_add_f32 v6, v6, v13   // 00000057ACA0: C9081905 05061B06
	v_add_f32_e32 v4, v4, v11                                  // 00000057ACA8: 06081704
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000057ACAC: BF870143
	v_cmp_gt_u32_e32 vcc_lo, 32, v21                           // 00000057ACB0: 7C982AA0
	v_cndmask_b32_e32 v21, v1, v21, vcc_lo                     // 00000057ACB4: 022A2B01
	s_waitcnt lgkmcnt(4)                                       // 00000057ACB8: BF89FC47
	v_add_f32_e32 v7, v7, v17                                  // 00000057ACBC: 060E2307
	v_lshlrev_b32_e32 v21, 2, v21                              // 00000057ACC0: 302A2A82
	s_waitcnt lgkmcnt(3)                                       // 00000057ACC4: BF89FC37
	v_add_f32_e32 v3, v3, v10                                  // 00000057ACC8: 06061503
	s_waitcnt lgkmcnt(1)                                       // 00000057ACCC: BF89FC17
	v_dual_add_f32 v9, v9, v19 :: v_dual_add_f32 v8, v8, v18   // 00000057ACD0: C9082709 09082508
	s_waitcnt lgkmcnt(0)                                       // 00000057ACD8: BF89FC07
	v_add_f32_e32 v10, v2, v20                                 // 00000057ACDC: 06142902
	ds_bpermute_b32 v11, v21, v4                               // 00000057ACE0: DACC0000 0B000415
	ds_bpermute_b32 v2, v21, v3                                // 00000057ACE8: DACC0000 02000315
	ds_bpermute_b32 v12, v21, v5                               // 00000057ACF0: DACC0000 0C000515
	ds_bpermute_b32 v13, v21, v6                               // 00000057ACF8: DACC0000 0D000615
	ds_bpermute_b32 v17, v21, v7                               // 00000057AD00: DACC0000 11000715
	ds_bpermute_b32 v18, v21, v8                               // 00000057AD08: DACC0000 12000815
	ds_bpermute_b32 v19, v21, v9                               // 00000057AD10: DACC0000 13000915
	ds_bpermute_b32 v20, v21, v10                              // 00000057AD18: DACC0000 14000A15
	v_xor_b32_e32 v21, 1, v1                                   // 00000057AD20: 3A2A0281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057AD24: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v21                           // 00000057AD28: 7C982AA0
	v_cndmask_b32_e32 v1, v1, v21, vcc_lo                      // 00000057AD2C: 02022B01
	v_lshlrev_b32_e32 v21, 2, v1                               // 00000057AD30: 302A0282
	s_waitcnt lgkmcnt(6)                                       // 00000057AD34: BF89FC67
	v_dual_add_f32 v1, v3, v2 :: v_dual_add_f32 v2, v4, v11    // 00000057AD38: C9080503 01021704
	s_waitcnt lgkmcnt(4)                                       // 00000057AD40: BF89FC47
	v_dual_add_f32 v4, v5, v12 :: v_dual_add_f32 v5, v6, v13   // 00000057AD44: C9081905 04041B06
	s_waitcnt lgkmcnt(3)                                       // 00000057AD4C: BF89FC37
	v_add_f32_e32 v3, v7, v17                                  // 00000057AD50: 06062307
	s_waitcnt lgkmcnt(1)                                       // 00000057AD54: BF89FC17
	v_dual_add_f32 v11, v8, v18 :: v_dual_add_f32 v12, v9, v19 // 00000057AD58: C9082508 0B0C2709
	s_waitcnt lgkmcnt(0)                                       // 00000057AD60: BF89FC07
	v_add_f32_e32 v13, v10, v20                                // 00000057AD64: 061A290A
	ds_bpermute_b32 v6, v21, v1                                // 00000057AD68: DACC0000 06000115
	ds_bpermute_b32 v7, v21, v2                                // 00000057AD70: DACC0000 07000215
	ds_bpermute_b32 v9, v21, v4                                // 00000057AD78: DACC0000 09000415
	ds_bpermute_b32 v10, v21, v5                               // 00000057AD80: DACC0000 0A000515
	ds_bpermute_b32 v8, v21, v3                                // 00000057AD88: DACC0000 08000315
	ds_bpermute_b32 v17, v21, v11                              // 00000057AD90: DACC0000 11000B15
	ds_bpermute_b32 v18, v21, v12                              // 00000057AD98: DACC0000 12000C15
	ds_bpermute_b32 v19, v21, v13                              // 00000057ADA0: DACC0000 13000D15
	v_cmpx_eq_u32_e32 0, v16                                   // 00000057ADA8: 7D942080
	s_cbranch_execz 17                                         // 00000057ADAC: BFA50011 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0xef4>
	s_waitcnt lgkmcnt(0)                                       // 00000057ADB0: BF89FC07
	v_dual_add_f32 v13, v13, v19 :: v_dual_add_f32 v12, v12, v18// 00000057ADB4: C908270D 0D0C250C
	v_lshlrev_b32_e32 v19, 5, v15                              // 00000057ADBC: 30261E85
	v_dual_add_f32 v11, v11, v17 :: v_dual_add_f32 v18, v5, v10// 00000057ADC0: C908230B 0B121505
	v_dual_add_f32 v17, v4, v9 :: v_dual_add_f32 v16, v2, v7   // 00000057ADC8: C9081304 11100F02
	v_dual_add_f32 v15, v1, v6 :: v_dual_add_f32 v10, v3, v8   // 00000057ADD0: C9080D01 0F0A1103
	s_delay_alu instid0(VALU_DEP_4)                            // 00000057ADD8: BF870004
	v_lshl_or_b32 v1, v14, 6, v19                              // 00000057ADDC: D6560001 044D0D0E
	ds_store_b128 v1, v[15:18] offset:1024                     // 00000057ADE4: DB7C0400 00000F01
	ds_store_b128 v1, v[10:13] offset:1040                     // 00000057ADEC: DB7C0410 00000A01
	s_or_b32 exec_lo, exec_lo, s0                              // 00000057ADF4: 8C7E007E
	v_lshrrev_b32_e32 v3, 3, v0                                // 00000057ADF8: 32060083
	v_mov_b32_e32 v2, s3                                       // 00000057ADFC: 7E040203
	.long 0xd44c0000                                           // 00000057AE00: D44C0000
	v_cndmask_b32_e32 v1, 32, v0, vcc_lo                       // 00000057AE04: 020200A0
	s_waitcnt lgkmcnt(0)                                       // 00000057AE08: BF89FC07
	s_barrier                                                  // 00000057AE0C: BFBD0000
	v_or_b32_e32 v1, s2, v3                                    // 00000057AE10: 38020602
	buffer_gl0_inv                                             // 00000057AE14: E0AC0000 00000000
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 00000057AE1C: 7CA8020C
	s_and_b32 s0, s0, vcc_lo                                   // 00000057AE20: 8B006A00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000057AE24: BF870009
	s_and_saveexec_b32 s1, s0                                  // 00000057AE28: BE812000
	s_cbranch_execz 40                                         // 00000057AE2C: BFA50028 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0xfd0>
	v_and_b32_e32 v0, 7, v0                                    // 00000057AE30: 36000087
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057AE34: BF870091
	v_lshlrev_b32_e32 v4, 2, v0                                // 00000057AE38: 30080082
	v_lshl_or_b32 v3, v3, 6, v4                                // 00000057AE3C: D6560003 04110D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000057AE44: BF8700B1
	v_add_nc_u32_e32 v3, 0x400, v3                             // 00000057AE48: 4A0606FF 00000400
	ds_load_2addr_b32 v[6:7], v3 offset1:8                     // 00000057AE50: D8DC0800 06000003
	v_mad_u64_u32 v[3:4], null, s12, v0, 0                     // 00000057AE58: D6FE7C03 0202000C
	v_mad_u64_u32 v[4:5], null, s13, v0, v[4:5]                // 00000057AE60: D6FE7C04 0412000D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000057AE68: BF870131
	.long 0xd73c0003                                           // 00000057AE6C: D73C0003
	v_cndmask_b32_e32 v1, 1, v3, vcc_lo                        // 00000057AE70: 02020681
	s_waitcnt lgkmcnt(0)                                       // 00000057AE74: BF89FC07
	v_add_f32_e32 v0, 0, v6                                    // 00000057AE78: 06000C80
	.long 0xd7006a03                                           // 00000057AE7C: D7006A03
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 00000057AE80: 02020608
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000057AE84: BF8701B2
	v_add_f32_e32 v5, v0, v7                                   // 00000057AE88: 060A0F00
	.long 0xd73c0000                                           // 00000057AE8C: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000057AE90: 02020281
	v_add_co_ci_u32_e64 v4, null, s9, v4, vcc_lo               // 00000057AE94: D5207C04 01AA0809
	v_bfe_u32 v2, v5, 16, 1                                    // 00000057AE9C: D6100002 02052105
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057AEA4: BF870093
	.long 0xd7006a00                                           // 00000057AEA8: D7006A00
	v_cndmask_b32_e32 v1, v3, v0, vcc_lo                       // 00000057AEAC: 02020103
	v_add_co_ci_u32_e64 v1, null, v4, v1, vcc_lo               // 00000057AEB0: D5207C01 01AA0304
	s_delay_alu instid0(VALU_DEP_3)                            // 00000057AEB8: BF870003
	v_add3_u32 v2, v5, v2, 0x7fff                              // 00000057AEBC: D6550002 03FE0505 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off                    // 00000057AEC8: DC960000 007C0200
	s_endpgm                                                   // 00000057AED0: BFB00000
		...

