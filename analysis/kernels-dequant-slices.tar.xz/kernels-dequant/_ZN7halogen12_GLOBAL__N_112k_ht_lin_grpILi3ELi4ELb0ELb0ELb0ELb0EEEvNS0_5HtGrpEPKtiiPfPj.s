0000000000401400 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj>:
; _ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj():
	s_clause 0x1                                               // 000000401400: BF850001
	s_load_b64 s[4:5], s[0:1], 0x130                           // 000000401404: F4040100 F8000130
	s_load_b128 s[16:19], s[0:1], 0x198                        // 00000040140C: F4080400 F8000198
	s_waitcnt lgkmcnt(0)                                       // 000000401414: BF89FC07
	s_cmp_eq_u64 s[4:5], 0                                     // 000000401418: BF108004
	s_cbranch_scc1 244                                         // 00000040141C: BFA200F4 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3f0>
	s_load_b32 s6, s[0:1], 0x138                               // 000000401420: F4000180 F8000138
	s_waitcnt lgkmcnt(0)                                       // 000000401428: BF89FC07
	s_cmp_lt_i32 s2, s6                                        // 00000040142C: BF040602
	s_cselect_b32 s3, -1, 0                                    // 000000401430: 980380C1
	s_cmp_ge_i32 s2, s6                                        // 000000401434: BF030602
	s_cbranch_scc0 233                                         // 000000401438: BFA100E9 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3e0>
	v_lshrrev_b32_e32 v1, 5, v0                                // 00000040143C: 32020085
	s_sub_i32 s6, s2, s6                                       // 000000401440: 81860602
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000401444: BF870481
	v_lshl_or_b32 v1, s6, 3, v1                                // 000000401448: D6560001 04050606
	s_mul_i32 s6, s18, 20                                      // 000000401450: 96069412
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000401454: BF870481
	v_cmp_gt_i32_e32 vcc_lo, s6, v1                            // 000000401458: 7C880206
	s_and_saveexec_b32 s6, vcc_lo                              // 00000040145C: BE86206A
	s_cbranch_execz 222                                        // 000000401460: BFA500DE <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3dc>
	.long 0xd72e0002                                           // 000000401464: D72E0002
	v_cndmask_b32_e32 v1, 0x66666667, v1, vcc_lo               // 000000401468: 020202FF 66666667
	v_and_b32_e32 v9, 31, v0                                   // 000000401470: 3612009F
	s_load_b64 s[8:9], s[0:1], 0x128                           // 000000401474: F4040200 F8000128
	s_mov_b32 s7, 0x76543210                                   // 00000040147C: BE8700FF 76543210
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000401484: BF8700A2
	v_lshrrev_b32_e32 v3, 31, v2                               // 000000401488: 3206049F
	v_ashrrev_i32_e32 v2, 3, v2                                // 00000040148C: 34040483
	v_add_nc_u32_e32 v8, v2, v3                                // 000000401490: 4A100702
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000401494: BF870121
	.long 0xd72c0002                                           // 000000401498: D72C0002
	v_cndmask_b32_e32 v1, 0xffffffec, v8, vcc_lo               // 00000040149C: 020210FF FFFFFFEC
	v_mad_i64_i32 v[4:5], null, 0x1400, v8, s[16:17]           // 0000004014A4: D6FF7C04 004210FF 00001400
	v_add_lshl_u32 v1, v2, v1, 7                               // 0000004014B0: D6470001 021E0302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004014B8: BF870091
	v_lshl_or_b32 v2, v9, 2, v1                                // 0000004014BC: D6560002 04050509
	v_ashrrev_i32_e32 v3, 31, v2                               // 0000004014C4: 3406049F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004014C8: BF870091
	.long 0xd73c0002                                           // 0000004014CC: D73C0002
	v_cndmask_b32_e32 v1, 1, v2, vcc_lo                        // 0000004014D0: 02020481
	.long 0xd7006a04                                           // 0000004014D4: D7006A04
	v_cndmask_b32_e32 v1, v4, v2, vcc_lo                       // 0000004014D8: 02020504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000004014DC: BF8700B1
	v_add_co_ci_u32_e64 v5, null, v5, v3, vcc_lo               // 0000004014E0: D5207C05 01AA0705
	s_waitcnt lgkmcnt(0)                                       // 0000004014E8: BF89FC07
	.long 0xd7006a02                                           // 0000004014EC: D7006A02
	v_cndmask_b32_e32 v1, s8, v2, vcc_lo                       // 0000004014F0: 02020408
	v_add_co_ci_u32_e64 v3, null, s9, v3, vcc_lo               // 0000004014F4: D5207C03 01AA0609
	global_load_b64 v[4:5], v[4:5], off                        // 0000004014FC: DC560000 047C0004
	s_mov_b32 s8, 0x3db504f3                                   // 000000401504: BE8800FF 3DB504F3
	global_load_b64 v[6:7], v[2:3], off                        // 00000040150C: DC560000 067C0002
	s_waitcnt vmcnt(1)                                         // 000000401514: BF8907F7
	.long 0x7e043904                                           // 000000401518: 7E043904
	v_and_b32_e32 v3, 0xffff0000, v4                           // 00000040151C: 360608FF FFFF0000
	.long 0x7e083905                                           // 000000401524: 7E083905
	v_and_b32_e32 v5, 0xffff0000, v5                           // 000000401528: 360A0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4)                            // 000000401530: BF870004
	v_lshlrev_b32_e32 v14, 16, v2                              // 000000401534: 301C0490
	s_waitcnt vmcnt(0)                                         // 000000401538: BF8903F7
	v_fma_mix_f32 v3, v6, v3, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 00000040153C: CC200803 8A020706
	v_lshlrev_b32_e32 v4, 16, v4                               // 000000401544: 30080890
	v_fma_mix_f32 v5, v7, v5, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000401548: CC200805 8A020B07
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000401550: 3404029F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000401554: BF870224
	v_fma_mix_f32 v15, v6, v14, v3 op_sel_hi:[1,0,0]           // 000000401558: CC20000F 0C0E1D06
	v_fma_mix_f32 v6, v6, v14, -v3 op_sel_hi:[1,0,0]           // 000000401560: CC200006 8C0E1D06
	v_fma_mix_f32 v14, v7, v4, v5 op_sel_hi:[1,0,0]            // 000000401568: CC20000E 0C160907
	v_fma_mix_f32 v5, v7, v4, -v5 op_sel_hi:[1,0,0]            // 000000401570: CC200005 8C160907
	v_and_b32_e32 v10, 1, v0                                   // 000000401578: 36140081
	v_and_b32_e32 v11, 2, v0                                   // 00000040157C: 36160082
	v_and_b32_e32 v13, 8, v0                                   // 000000401580: 361A0088
	.long 0xd73c0001                                           // 000000401584: D73C0001
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 000000401588: 02020281
	v_add_f32_e32 v16, v6, v5                                  // 00000040158C: 06200B06
	v_sub_f32_e32 v5, v6, v5                                   // 000000401590: 080A0B06
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 000000401594: 7C941480
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000401598: BF870193
	v_mov_b32_dpp v10, v16 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000040159C: 7E1402FA FF016110
	v_mov_b32_dpp v17, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004015A4: 7E2202FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 0000004015AC: D5010005 21AA0B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 0000004015B4: BF8701D1
	v_add_f32_e32 v5, v5, v17                                  // 0000004015B8: 060A2305
	v_mad_i64_i32 v[3:4], null, 0x1400, v8, s[4:5]             // 0000004015BC: D6FF7C03 001210FF 00001400
	v_add_f32_e32 v8, v15, v14                                 // 0000004015C8: 06101D0F
	v_sub_f32_e32 v14, v15, v14                                // 0000004015CC: 081C1D0F
	v_cndmask_b32_e64 v15, -v16, v16, vcc_lo                   // 0000004015D0: D501000F 21AA2110
	v_mov_b32_dpp v6, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004015D8: 7E0C02FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 0000004015E0: D5010008 21AA1108
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000004015E8: BF870234
	v_mov_b32_dpp v16, v14 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004015EC: 7E2002FA FF01610E
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 0000004015F4: D501000E 21AA1D0E
	v_cmp_eq_u32_e32 vcc_lo, 0, v11                            // 0000004015FC: 7C941680
	v_dual_add_f32 v6, v8, v6 :: v_dual_lshlrev_b32 v7, 3, v9  // 000000401600: C9220D08 06061283
	v_add_f32_e32 v8, v15, v10                                 // 000000401608: 0610150F
	s_delay_alu instid0(VALU_DEP_4)                            // 00000040160C: BF870004
	v_add_f32_e32 v10, v14, v16                                // 000000401610: 0614210E
	v_mov_b32_dpp v16, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000401614: 7E2002FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 00000040161C: D5010005 21AA0B05
	v_mov_b32_dpp v11, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000401624: 7E1602FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 00000040162C: D5010006 21AA0D06
	v_mov_b32_dpp v15, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000401634: 7E1E02FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 00000040163C: D501000A 21AA150A
	v_add_f32_e32 v5, v5, v16                                  // 000000401644: 060A2105
	v_mov_b32_dpp v14, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000401648: 7E1C02FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000401650: D5010008 21AA1108
	v_add_f32_e32 v6, v6, v11                                  // 000000401658: 060C1706
	v_add_f32_e32 v10, v10, v15                                // 00000040165C: 06141F0A
	v_mov_b32_dpp v15, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000401660: 7E1E02FA FF016405
	v_and_b32_e32 v12, 4, v0                                   // 000000401668: 36180084
	v_add_f32_e32 v8, v8, v14                                  // 00000040166C: 06101D08
	v_mov_b32_dpp v11, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000401670: 7E1602FA FF016406
	v_mov_b32_dpp v14, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000401678: 7E1C02FA FF01640A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000401680: BF8701C4
	v_cmp_eq_u32_e32 vcc_lo, 0, v12                            // 000000401684: 7C941880
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 000000401688: D5010006 21AA0D06
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000401690: D5010005 21AA0B05
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 000000401698: D501000A 21AA150A
	v_add_f32_e32 v6, v6, v11                                  // 0000004016A0: 060C1706
	s_delay_alu instid0(VALU_DEP_3)                            // 0000004016A4: BF870003
	v_add_f32_e32 v5, v5, v15                                  // 0000004016A8: 060A1F05
	v_mov_b32_dpp v12, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000004016AC: 7E1802FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 0000004016B4: D5010008 21AA1108
	v_cmp_eq_u32_e32 vcc_lo, 0, v13                            // 0000004016BC: 7C941A80
	v_add_f32_e32 v10, v10, v14                                // 0000004016C0: 06141D0A
	v_mov_b32_dpp v11, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004016C4: 7E1602FA FF016806
	v_mov_b32_dpp v14, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004016CC: 7E1C02FA FF016805
	v_add_f32_e32 v8, v8, v12                                  // 0000004016D4: 06101908
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 0000004016D8: D5010006 21AA0D06
	v_mov_b32_dpp v13, v10 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004016E0: 7E1A02FA FF01680A
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 0000004016E8: D5010005 21AA0B05
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 0000004016F0: D501000A 21AA150A
	v_mov_b32_dpp v12, v8 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004016F8: 7E1802FA FF016808
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000401700: D5010008 21AA1108
	v_add_f32_e32 v6, v6, v11                                  // 000000401708: 060C1706
	v_cmp_gt_u32_e32 vcc_lo, 16, v9                            // 00000040170C: 7C981290
	v_add_f32_e32 v5, v5, v14                                  // 000000401710: 060A1D05
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000401714: BF870214
	v_dual_add_f32 v9, v10, v13 :: v_dual_add_f32 v8, v8, v12  // 000000401718: C9081B0A 09081908
	v_mov_b32_e32 v10, v6                                      // 000000401720: 7E140306
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 000000401724: D5010006 21AA0D06
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000040172C: BF870214
	v_mov_b32_e32 v13, v5                                      // 000000401730: 7E1A0305
	v_mov_b32_e32 v12, v9                                      // 000000401734: 7E180309
	v_cndmask_b32_e64 v11, -v8, v8, vcc_lo                     // 000000401738: D501000B 21AA1108
	v_permlanex16_b32 v8, v8, s7, 0xfedcba98                   // 000000401740: D65C0008 03FC0F08 FEDCBA98
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 00000040174C: D5010005 21AA0B05
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000401754: D5010009 21AA1309
	v_permlanex16_b32 v10, v10, s7, 0xfedcba98                 // 00000040175C: D65C000A 03FC0F0A FEDCBA98
	v_permlanex16_b32 v12, v12, s7, 0xfedcba98                 // 000000401768: D65C000C 03FC0F0C FEDCBA98
	v_permlanex16_b32 v13, v13, s7, 0xfedcba98                 // 000000401774: D65C000D 03FC0F0D FEDCBA98
	.long 0xd7006a01                                           // 000000401780: D7006A01
	v_cndmask_b32_e32 v1, v3, v1, vcc_lo                       // 000000401784: 02020303
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000401788: BF8700D1
	v_add_co_ci_u32_e64 v2, null, v4, v2, vcc_lo               // 00000040178C: D5207C02 01AA0504
	v_dual_add_f32 v3, v11, v8 :: v_dual_add_f32 v4, v6, v10   // 000000401794: C908110B 03041506
	v_add_f32_e32 v6, v9, v12                                  // 00000040179C: 060C1909
	v_add_f32_e32 v5, v5, v13                                  // 0000004017A0: 060A1B05
	.long 0xd7006a01                                           // 0000004017A4: D7006A01
	v_cndmask_b32_e32 v1, v1, v7, vcc_lo                       // 0000004017A8: 02020F01
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 0000004017AC: D5207C02 01AA0480
	v_fma_mixhi_f16 v3, v3, s8, 0                              // 0000004017B4: CC220003 02001103
	v_fma_mixlo_f16 v3, v4, s8, 0                              // 0000004017BC: CC210003 02001104
	v_fma_mixhi_f16 v4, v5, s8, 0                              // 0000004017C4: CC220004 02001105
	v_fma_mixlo_f16 v4, v6, s8, 0                              // 0000004017CC: CC210004 02001106
	global_store_b64 v[1:2], v[3:4], off                       // 0000004017D4: DC6E0000 007C0301
	s_or_b32 exec_lo, exec_lo, s6                              // 0000004017DC: 8C7E067E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000004017E0: BF870009
	s_and_b32 vcc_lo, exec_lo, s3                              // 0000004017E4: 8B6A037E
	s_cbranch_vccnz 2                                          // 0000004017E8: BFA40002 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3f4>
	s_endpgm                                                   // 0000004017EC: BFB00000
	s_cbranch_execz 65534                                      // 0000004017F0: BFA5FFFE <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	s_clause 0x3                                               // 0000004017F4: BF850003
	s_load_b32 s3, s[0:1], 0x120                               // 0000004017F8: F40000C0 F8000120
	s_load_b32 s4, s[0:1], 0x7c                                // 000000401800: F4000100 F800007C
	s_load_b32 s5, s[0:1], 0xc4                                // 000000401808: F4000140 F80000C4
	s_load_b32 s6, s[0:1], 0x10c                               // 000000401810: F4000180 F800010C
	v_and_b32_e32 v20, 31, v0                                  // 000000401818: 3628009F
	v_lshrrev_b32_e32 v19, 5, v0                               // 00000040181C: 32260085
	s_delay_alu instid0(VALU_DEP_2)                            // 000000401820: BF870002
	v_lshlrev_b32_e32 v2, 3, v20                               // 000000401824: 30042883
	s_waitcnt lgkmcnt(0)                                       // 000000401828: BF89FC07
	s_cmp_gt_i32 s3, 1                                         // 00000040182C: BF028103
	s_cselect_b32 s7, -1, 0                                    // 000000401830: 980780C1
	s_cmp_ge_i32 s2, s4                                        // 000000401834: BF030402
	s_cselect_b32 s4, -1, 0                                    // 000000401838: 980480C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000040183C: BF870009
	s_and_b32 s4, s7, s4                                       // 000000401840: 8B040407
	s_cmp_gt_i32 s3, 2                                         // 000000401844: BF028203
	v_cndmask_b32_e64 v1, 0, 1, s4                             // 000000401848: D5010001 00110280
	s_cselect_b32 s7, -1, 0                                    // 000000401850: 980780C1
	s_cmp_ge_i32 s2, s5                                        // 000000401854: BF030502
	s_cselect_b32 s5, -1, 0                                    // 000000401858: 980580C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000040185C: BF870009
	s_and_b32 s4, s7, s5                                       // 000000401860: 8B040507
	s_cmp_gt_i32 s3, 3                                         // 000000401864: BF028303
	v_readfirstlane_b32 s5, v1                                 // 000000401868: 7E0A0501
	s_cselect_b32 s3, -1, 0                                    // 00000040186C: 980380C1
	s_cmp_ge_i32 s2, s6                                        // 000000401870: BF030602
	s_cselect_b32 s6, -1, 0                                    // 000000401874: 980680C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 000000401878: BF8704D9
	s_and_b32 s3, s3, s6                                       // 00000040187C: 8B030603
	s_and_b32 s4, s4, exec_lo                                  // 000000401880: 8B047E04
	s_cselect_b32 s4, 2, s5                                    // 000000401884: 98040582
	s_and_b32 s3, s3, exec_lo                                  // 000000401888: 8B037E03
	s_cselect_b32 s3, 3, s4                                    // 00000040188C: 98030483
	s_mulk_i32 s3, 0x48                                        // 000000401890: B8030048
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000401894: BF870009
	s_add_u32 s4, s0, s3                                       // 000000401898: 80040300
	s_addc_u32 s5, s1, 0                                       // 00000040189C: 82058001
	s_clause 0x3                                               // 0000004018A0: BF850003
	s_load_b32 s30, s[4:5], 0x38                               // 0000004018A4: F4000782 F8000038
	s_load_b64 s[28:29], s[4:5], 0x40                          // 0000004018AC: F4040702 F8000040
	s_load_b128 s[20:23], s[4:5], 0x28                         // 0000004018B4: F4080502 F8000028
	s_load_b64 s[24:25], s[4:5], 0x20                          // 0000004018BC: F4040602 F8000020
	s_waitcnt lgkmcnt(0)                                       // 0000004018C4: BF89FC07
	s_abs_i32 s3, s21                                          // 0000004018C8: BE831515
	s_sub_i32 s34, s2, s23                                     // 0000004018CC: 81A21702
	s_cvt_f32_u32 s6, s3                                       // 0000004018D0: BE866503
	s_sub_i32 s7, 0, s3                                        // 0000004018D4: 81870380
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000004018D8: BF87029A
	v_rcp_iflag_f32_e32 v1, s6                                 // 0000004018DC: 7E025606
	v_readfirstlane_b32 s6, v1                                 // 0000004018E0: 7E0C0501
	s_mul_f32 s6, s6, 0x4f7ffffe                               // 0000004018E4: A206FF06 4F7FFFFE
	s_delay_alu instid0(SALU_CYCLE_3) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 0000004018EC: BF87059B
	s_cvt_u32_f32 s6, s6                                       // 0000004018F0: BE866706
	s_mul_i32 s7, s7, s6                                       // 0000004018F4: 96070607
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000004018F8: BF8704B9
	s_mul_hi_u32 s2, s6, s7                                    // 0000004018FC: 96820706
	s_abs_i32 s7, s34                                          // 000000401900: BE871522
	s_add_i32 s6, s6, s2                                       // 000000401904: 81060206
	s_mul_hi_u32 s2, s7, s6                                    // 000000401908: 96820607
	s_xor_b32 s6, s34, s21                                     // 00000040190C: 8D061522
	s_mul_i32 s8, s2, s3                                       // 000000401910: 96080302
	s_ashr_i32 s6, s6, 31                                      // 000000401914: 86069F06
	s_sub_i32 s7, s7, s8                                       // 000000401918: 81870807
	s_add_i32 s8, s2, 1                                        // 00000040191C: 81088102
	s_sub_i32 s9, s7, s3                                       // 000000401920: 81890307
	s_cmp_ge_u32 s7, s3                                        // 000000401924: BF090307
	s_cselect_b32 s2, s8, s2                                   // 000000401928: 98020208
	s_cselect_b32 s7, s9, s7                                   // 00000040192C: 98070709
	s_add_i32 s8, s2, 1                                        // 000000401930: 81088102
	s_cmp_ge_u32 s7, s3                                        // 000000401934: BF090307
	s_cselect_b32 s2, s8, s2                                   // 000000401938: 98020208
	s_load_b256 s[8:15], s[4:5], null                          // 00000040193C: F40C0202 F8000000
	s_xor_b32 s2, s2, s6                                       // 000000401944: 8D020602
	s_ashr_i32 s23, s19, 31                                    // 000000401948: 86179F13
	s_sub_i32 s26, s2, s6                                      // 00000040194C: 819A0602
	s_lshr_b32 s2, s23, 25                                     // 000000401950: 85029917
	s_mul_i32 s36, s26, s21                                    // 000000401954: 9624151A
	s_add_i32 s2, s19, s2                                      // 000000401958: 81020213
	s_sub_i32 s3, s34, s36                                     // 00000040195C: 81832422
	s_ashr_i32 s2, s2, 7                                       // 000000401960: 86028702
	s_mul_i32 s27, s22, s3                                     // 000000401964: 961B0316
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000401968: BF870499
	s_add_i32 s3, s27, s22                                     // 00000040196C: 8103161B
	s_min_i32 s2, s2, s3                                       // 000000401970: 89020302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000401974: BF8704B9
	s_sub_i32 s7, s2, s27                                      // 000000401978: 81871B02
	s_mov_b32 s2, exec_lo                                      // 00000040197C: BE82007E
	s_lshl_b32 s22, s7, 2                                      // 000000401980: 84168207
	.long 0xd4c3007e                                           // 000000401984: D4C3007E
	v_cndmask_b32_e32 v1, s22, v19, vcc_lo                     // 000000401988: 02022616
	s_xor_b32 s2, exec_lo, s2                                  // 00000040198C: 8D02027E
	v_lshlrev_b32_e32 v2, 3, v20                               // 000000401990: 30042883
	s_and_not1_saveexec_b32 s31, s2                            // 000000401994: BE9F3002
	s_cbranch_execz 288                                        // 000000401998: BFA50120 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0xa1c>
	s_abs_i32 s33, s7                                          // 00000040199C: BEA11507
	v_lshlrev_b32_e32 v9, 7, v19                               // 0000004019A0: 30122687
	s_cvt_f32_u32 s2, s33                                      // 0000004019A4: BE826521
	v_and_b32_e32 v3, 1, v0                                    // 0000004019A8: 36060081
	v_and_b32_e32 v5, 4, v0                                    // 0000004019AC: 360A0084
	v_lshl_or_b32 v8, v19, 8, v2                               // 0000004019B0: D6560008 04091113
	v_rcp_iflag_f32_e32 v1, s2                                 // 0000004019B8: 7E025602
	s_sub_i32 s2, 0, s33                                       // 0000004019BC: 81822180
	v_lshl_add_u32 v9, s27, 7, v9                              // 0000004019C0: D6460009 04250E1B
	s_ashr_i32 s39, s7, 31                                     // 0000004019C8: 86279F07
	.long 0xd44a0004                                           // 0000004019CC: D44A0004
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 0000004019D0: 02020A80
	s_mul_i32 s41, s39, 0x1400                                 // 0000004019D4: 9629FF27 00001400
	s_lshl_b32 s6, s7, 7                                       // 0000004019DC: 84068707
	s_add_i32 s35, s18, -1                                     // 0000004019E0: 8123C112
	s_mov_b32 s37, s19                                         // 0000004019E4: BEA50013
	s_mov_b32 s38, 0                                           // 0000004019E8: BEA60080
	v_dual_mul_f32 v1, 0x4f7ffffe, v1 :: v_dual_and_b32 v6, 8, v0// 0000004019EC: C8E402FF 01060088 4F7FFFFE
	s_lshl_b32 s40, s7, 8                                      // 0000004019F8: 84288807
	s_mov_b32 s42, 0x76543210                                  // 0000004019FC: BEAA00FF 76543210
	s_mov_b32 s43, 0x3db504f3                                  // 000000401A04: BEAB00FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_1)                            // 000000401A0C: BF870001
	v_cvt_u32_f32_e32 v4, v1                                   // 000000401A10: 7E080F01
	v_and_b32_e32 v1, 2, v0                                    // 000000401A14: 36020082
	.long 0xd44a0005                                           // 000000401A18: D44A0005
	v_cndmask_b32_e32 v1, 0, v6, vcc_lo                        // 000000401A1C: 02020C80
	v_cmp_gt_u32_e32 vcc_lo, 16, v20                           // 000000401A20: 7C982890
	v_mov_b32_e32 v5, v19                                      // 000000401A24: 7E0A0313
	.long 0xd72c0007                                           // 000000401A28: D72C0007
	v_cndmask_b32_e32 v1, s2, v4, vcc_lo                       // 000000401A2C: 02020802
	.long 0xd44a0002                                           // 000000401A30: D44A0002
	v_cndmask_b32_e32 v1, 0, v3, vcc_lo                        // 000000401A34: 02020680
	.long 0xd44a0003                                           // 000000401A38: D44A0003
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000401A3C: 02020280
	v_subrev_nc_u32_e32 v3, s41, v8                            // 000000401A40: 4E061029
	v_lshl_or_b32 v1, v20, 2, v9                               // 000000401A44: D6560001 04250514
	s_sub_i32 s41, 0, s6                                       // 000000401A4C: 81A90680
	.long 0xd72d0007                                           // 000000401A50: D72D0007
	v_cndmask_b32_e32 v1, v4, v7, vcc_lo                       // 000000401A54: 02020F04
	s_delay_alu instid0(VALU_DEP_1)                            // 000000401A58: BF870001
	v_add_nc_u32_e32 v4, v4, v7                                // 000000401A5C: 4A080F04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000401A60: BF870091
	.long 0xd72d0006                                           // 000000401A64: D72D0006
	v_cndmask_b32_e32 v1, v5, v4, vcc_lo                       // 000000401A68: 02020905
	.long 0xd72c0007                                           // 000000401A6C: D72C0007
	v_cndmask_b32_e32 v0, v6, v33, vcc_lo                      // 000000401A70: 02004306
	v_add_nc_u32_e32 v8, 1, v6                                 // 000000401A74: 4A100C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000401A78: BF870092
	v_sub_nc_u32_e32 v7, v5, v7                                // 000000401A7C: 4C0E0F05
	v_subrev_nc_u32_e32 v9, s33, v7                            // 000000401A80: 4E120E21
	.long 0xd44b0006                                           // 000000401A84: D44B0006
	v_cndmask_b32_e32 v1, s33, v7, vcc_lo                      // 000000401A88: 02020E21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000401A8C: BF870191
	v_cndmask_b32_e64 v6, v6, v8, s6                           // 000000401A90: D5010006 001A1106
	v_cndmask_b32_e64 v7, v7, v9, s6                           // 000000401A98: D5010007 001A1307
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000401AA0: BF870112
	v_add_nc_u32_e32 v8, 1, v6                                 // 000000401AA4: 4A100C81
	.long 0xd44b0006                                           // 000000401AA8: D44B0006
	v_cndmask_b32_e32 v1, s33, v7, vcc_lo                      // 000000401AAC: 02020E21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000401AB0: BF870091
	v_cndmask_b32_e64 v6, v6, v8, s6                           // 000000401AB4: D5010006 001A1106
	v_xor_b32_e32 v10, s39, v6                                 // 000000401ABC: 3A140C27
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000401AC0: BF870121
	v_subrev_nc_u32_e32 v11, s39, v10                          // 000000401AC4: 4E161427
	.long 0xd72c000a                                           // 000000401AC8: D72C000A
	v_cndmask_b32_e32 v1, 0x1400, v10, vcc_lo                  // 000000401ACC: 020214FF 00001400
	v_min_i32_e32 v8, s35, v11                                 // 000000401AD4: 22101623
	v_mad_u64_u32 v[6:7], null, s41, v11, v[1:2]               // 000000401AD8: D6FE7C06 04061629
	.long 0xd72c000b                                           // 000000401AE0: D72C000B
	v_cndmask_b32_e32 v1, s40, v11, vcc_lo                     // 000000401AE4: 02021628
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000401AE8: BF870193
	v_mad_i64_i32 v[8:9], null, v8, s37, 0                     // 000000401AEC: D6FF7C08 02004B08
	v_ashrrev_i32_e32 v7, 31, v6                               // 000000401AF4: 340E0C9F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000401AF8: BF870193
	v_sub_nc_u32_e32 v10, v10, v11                             // 000000401AFC: 4C14170A
	.long 0xd73c0008                                           // 000000401B00: D73C0008
	v_cndmask_b32_e32 v1, 1, v8, vcc_lo                        // 000000401B04: 02021081
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000401B08: BF870193
	.long 0xd73c0006                                           // 000000401B0C: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000401B10: 02020C81
	v_add_nc_u32_e32 v10, v3, v10                              // 000000401B14: 4A141503
	v_add_nc_u32_e32 v3, 0x800, v3                             // 000000401B18: 4A0606FF 00000800
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000401B20: BF870094
	.long 0xd700060c                                           // 000000401B24: D700060C
	v_cndmask_b32_e32 v1, s16, v8, vcc_lo                      // 000000401B28: 02021010
	v_add_co_ci_u32_e64 v13, null, s17, v9, s6                 // 000000401B2C: D5207C0D 001A1211
	s_waitcnt lgkmcnt(0)                                       // 000000401B34: BF89FC07
	.long 0xd7000608                                           // 000000401B38: D7000608
	v_cndmask_b32_e32 v1, s10, v6, vcc_lo                      // 000000401B3C: 02020C0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000401B40: BF8700A1
	v_add_co_ci_u32_e64 v9, null, s11, v7, s6                  // 000000401B44: D5207C09 001A0E0B
	.long 0xd7000606                                           // 000000401B4C: D7000606
	v_cndmask_b32_e32 v1, v12, v6, vcc_lo                      // 000000401B50: 02020D0C
	v_add_co_ci_u32_e64 v7, null, v13, v7, s6                  // 000000401B54: D5207C07 001A0F0D
	global_load_b64 v[6:7], v[6:7], off                        // 000000401B5C: DC560000 067C0006
	global_load_b64 v[8:9], v[8:9], off                        // 000000401B64: DC560000 087C0008
	s_waitcnt vmcnt(1)                                         // 000000401B6C: BF8907F7
	.long 0x7e1a3907                                           // 000000401B70: 7E1A3907
	v_and_b32_e32 v7, 0xffff0000, v7                           // 000000401B74: 360E0EFF FFFF0000
	.long 0x7e183906                                           // 000000401B7C: 7E183906
	v_and_b32_e32 v6, 0xffff0000, v6                           // 000000401B80: 360C0CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000401B88: BF8701B4
	v_lshlrev_b32_e32 v13, 16, v13                             // 000000401B8C: 301A1A90
	s_waitcnt vmcnt(0)                                         // 000000401B90: BF8903F7
	v_fma_mix_f32 v7, v9, v7, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000401B94: CC200807 8A020F09
	v_fma_mix_f32 v6, v8, v6, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000401B9C: CC200806 8A020D08
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000401BA4: BF8700B2
	v_fma_mix_f32 v14, v9, v13, v7 op_sel_hi:[1,0,0]           // 000000401BA8: CC20000E 0C1E1B09
	v_fma_mix_f32 v7, v9, v13, -v7 op_sel_hi:[1,0,0]           // 000000401BB0: CC200007 8C1E1B09
	v_lshlrev_b32_e32 v12, 16, v12                             // 000000401BB8: 30181890
	v_fma_mix_f32 v15, v8, v12, v6 op_sel_hi:[1,0,0]           // 000000401BBC: CC20000F 0C1A1908
	v_fma_mix_f32 v6, v8, v12, -v6 op_sel_hi:[1,0,0]           // 000000401BC4: CC200006 8C1A1908
	v_add_nc_u32_e32 v5, 8, v5                                 // 000000401BCC: 4A0A0A88
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000401BD0: BF870223
	v_dual_sub_f32 v12, v15, v14 :: v_dual_add_nc_u32 v1, 0x400, v1// 000000401BD4: C9601D0F 0C0002FF 00000400
	v_add_f32_e32 v8, v15, v14                                 // 000000401BE0: 06101D0F
	v_dual_add_f32 v9, v7, v6 :: v_dual_sub_f32 v6, v6, v7     // 000000401BE4: C90A0D07 09060F06
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000401BEC: BF870214
	.long 0xd4430006                                           // 000000401BF0: D4430006
	v_cndmask_b32_e32 v1, s22, v5, vcc_lo                      // 000000401BF4: 02020A16
	v_mov_b32_dpp v14, v12 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000401BF8: 7E1C02FA FF01610C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000401C00: BF870214
	v_mov_b32_dpp v7, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000401C04: 7E0E02FA FF016108
	v_mov_b32_dpp v13, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000401C0C: 7E1A02FA FF016109
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 000000401C14: D5010008 200A1108
	v_cndmask_b32_e64 v9, -v9, v9, s2                          // 000000401C1C: D5010009 200A1309
	v_mov_b32_dpp v15, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000401C24: 7E1E02FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s2                          // 000000401C2C: D5010006 200A0D06
	v_cndmask_b32_e64 v12, -v12, v12, s2                       // 000000401C34: D501000C 200A190C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000401C3C: BF870124
	v_dual_add_f32 v7, v8, v7 :: v_dual_add_f32 v8, v9, v13    // 000000401C40: C9080F08 07081B09
	s_or_b32 s38, s6, s38                                      // 000000401C48: 8C262606
	v_dual_add_f32 v6, v6, v15 :: v_dual_add_f32 v9, v12, v14  // 000000401C4C: C9081F06 06081D0C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000401C54: BF870192
	v_mov_b32_dpp v12, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000401C58: 7E1802FA FF016207
	v_mov_b32_dpp v13, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000401C60: 7E1A02FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s3                          // 000000401C68: D5010008 200E1108
	v_cndmask_b32_e64 v7, -v7, v7, s3                          // 000000401C70: D5010007 200E0F07
	v_mov_b32_dpp v14, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000401C78: 7E1C02FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 000000401C80: D5010009 200E1309
	v_mov_b32_dpp v15, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000401C88: 7E1E02FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, s3                          // 000000401C90: D5010006 200E0D06
	v_dual_add_f32 v8, v8, v13 :: v_dual_add_f32 v7, v7, v12   // 000000401C98: C9081B08 08061907
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000401CA0: BF870114
	v_add_f32_e32 v9, v9, v14                                  // 000000401CA4: 06121D09
	v_mov_b32_dpp v13, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000401CA8: 7E1A02FA FF016408
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000401CB0: BF870193
	v_mov_b32_dpp v12, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000401CB4: 7E1802FA FF016407
	v_mov_b32_dpp v14, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000401CBC: 7E1C02FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s4                          // 000000401CC4: D5010009 20121309
	v_add_f32_e32 v6, v6, v15                                  // 000000401CCC: 060C1F06
	v_cndmask_b32_e64 v7, -v7, v7, s4                          // 000000401CD0: D5010007 20120F07
	v_cndmask_b32_e64 v8, -v8, v8, s4                          // 000000401CD8: D5010008 20121108
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000401CE0: BF870214
	v_add_f32_e32 v9, v9, v14                                  // 000000401CE4: 06121D09
	v_mov_b32_dpp v15, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000401CE8: 7E1E02FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s4                          // 000000401CF0: D5010006 20120D06
	v_add_f32_e32 v7, v7, v12                                  // 000000401CF8: 060E1907
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000401CFC: BF870224
	v_mov_b32_dpp v14, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000401D00: 7E1C02FA FF016809
	v_cndmask_b32_e64 v9, -v9, v9, s5                          // 000000401D08: D5010009 20161309
	v_add_f32_e32 v6, v6, v15                                  // 000000401D10: 060C1F06
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000401D14: BF870224
	v_mov_b32_dpp v12, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000401D18: 7E1802FA FF016807
	v_cndmask_b32_e64 v7, -v7, v7, s5                          // 000000401D20: D5010007 20160F07
	v_dual_add_f32 v8, v8, v13 :: v_dual_add_f32 v9, v9, v14   // 000000401D28: C9081B08 08081D09
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000401D30: BF870224
	v_mov_b32_dpp v15, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000401D34: 7E1E02FA FF016806
	v_cndmask_b32_e64 v6, -v6, v6, s5                          // 000000401D3C: D5010006 20160D06
	v_add_f32_e32 v7, v7, v12                                  // 000000401D44: 060E1907
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000401D48: BF870224
	v_mov_b32_dpp v13, v8 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000401D4C: 7E1A02FA FF016808
	v_cndmask_b32_e64 v8, -v8, v8, s5                          // 000000401D54: D5010008 20161108
	v_add_f32_e32 v6, v6, v15                                  // 000000401D5C: 060C1F06
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000401D60: BF870091
	v_dual_add_f32 v8, v8, v13 :: v_dual_mov_b32 v15, v6       // 000000401D64: C9101B08 080E0106
	v_mov_b32_e32 v13, v8                                      // 000000401D6C: 7E1A0308
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 000000401D70: D5010006 21AA0D06
	s_delay_alu instid0(VALU_DEP_3)                            // 000000401D78: BF870003
	v_permlanex16_b32 v15, v15, s42, 0xfedcba98                // 000000401D7C: D65C000F 03FC550F FEDCBA98
	v_mov_b32_e32 v12, v7                                      // 000000401D88: 7E180307
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000401D8C: D5010007 21AA0F07
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000401D94: D5010008 21AA1108
	v_permlanex16_b32 v13, v13, s42, 0xfedcba98                // 000000401D9C: D65C000D 03FC550D FEDCBA98
	v_add_f32_e32 v11, v6, v15                                 // 000000401DA8: 06161F06
	v_permlanex16_b32 v12, v12, s42, 0xfedcba98                // 000000401DAC: D65C000C 03FC550C FEDCBA98
	v_mov_b32_e32 v14, v9                                      // 000000401DB8: 7E1C0309
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000401DBC: D5010009 21AA1309
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000401DC4: BF870193
	v_add_f32_e32 v7, v7, v12                                  // 000000401DC8: 060E1907
	v_permlanex16_b32 v14, v14, s42, 0xfedcba98                // 000000401DCC: D65C000E 03FC550E FEDCBA98
	v_add_f32_e32 v8, v8, v13                                  // 000000401DD8: 06101B08
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000401DDC: BF870193
	v_fma_mixlo_f16 v6, v7, s43, 0                             // 000000401DE0: CC210006 02005707
	v_add_f32_e32 v9, v9, v14                                  // 000000401DE8: 06121D09
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000401DEC: BF8701A3
	v_fma_mixhi_f16 v6, v8, s43, 0                             // 000000401DF0: CC220006 02005708
	v_fma_mixhi_f16 v7, v11, s43, 0                            // 000000401DF8: CC220007 0200570B
	v_fma_mixlo_f16 v7, v9, s43, 0                             // 000000401E00: CC210007 02005709
	ds_store_b64 v10, v[6:7]                                   // 000000401E08: D9340000 0000060A
	s_and_not1_b32 exec_lo, exec_lo, s38                       // 000000401E10: 917E267E
	s_cbranch_execnz 65298                                     // 000000401E14: BFA6FF12 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x660>
	s_or_b32 exec_lo, exec_lo, s38                             // 000000401E18: 8C7E267E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000401E1C: BF870009
	s_or_b32 exec_lo, exec_lo, s31                             // 000000401E20: 8C7E1F7E
	s_bfe_i32 s6, s7, 0x1001c                                  // 000000401E24: 9386FF07 0001001C
	s_lshr_b32 s5, s23, 28                                     // 000000401E2C: 85059C17
	s_lshr_b64 s[2:3], s[6:7], 29                              // 000000401E30: 85829D06
	s_add_i32 s5, s19, s5                                      // 000000401E34: 81050513
	s_add_i32 s2, s2, 7                                        // 000000401E38: 81028702
	s_lshl_b32 s4, s7, 3                                       // 000000401E3C: 84048307
	s_ashr_i32 s2, s2, 3                                       // 000000401E40: 86028302
	s_lshl_b32 s3, s27, 3                                      // 000000401E44: 8403831B
	.long 0xd72c0001                                           // 000000401E48: D72C0001
	v_cndmask_b32_e32 v1, s2, v19, vcc_lo                      // 000000401E4C: 02022602
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v56, 0             // 000000401E50: CA100080 17380080
	v_dual_mov_b32 v58, 0 :: v_dual_lshlrev_b32 v21, 2, v20    // 000000401E58: CA220080 3A142882
	v_dual_mov_b32 v55, 0 :: v_dual_mov_b32 v60, 0             // 000000401E60: CA100080 373C0080
	v_mov_b32_e32 v57, 0                                       // 000000401E68: 7E720280
	v_add_nc_u32_e32 v3, s2, v1                                // 000000401E6C: 4A060202
	s_ashr_i32 s2, s5, 4                                       // 000000401E70: 86028405
	s_ashr_i32 s5, s3, 31                                      // 000000401E74: 86059F03
	s_mul_hi_i32 s6, s26, s2                                   // 000000401E78: 9706021A
	s_mul_i32 s2, s26, s2                                      // 000000401E7C: 9602021A
	v_min_i32_e32 v54, s4, v3                                  // 000000401E80: 226C0604
	s_add_u32 s2, s2, s3                                       // 000000401E84: 80020302
	s_addc_u32 s3, s6, s5                                      // 000000401E88: 82030506
	v_mov_b32_e32 v59, 0                                       // 000000401E8C: 7E760280
	s_mul_hi_u32 s4, s2, 0x300                                 // 000000401E90: 9684FF02 00000300
	v_cmp_lt_i32_e32 vcc_lo, v1, v54                           // 000000401E98: 7C826D01
	s_mulk_i32 s3, 0x300                                       // 000000401E9C: B8030300
	s_waitcnt lgkmcnt(0)                                       // 000000401EA0: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 000000401EA4: BC7C0000
	s_add_i32 s5, s4, s3                                       // 000000401EA8: 81050304
	s_mul_i32 s4, s2, 0x300                                    // 000000401EAC: 9604FF02 00000300
	s_barrier                                                  // 000000401EB4: BFBD0000
	buffer_gl0_inv                                             // 000000401EB8: E0AC0000 00000000
	s_and_saveexec_b32 s3, vcc_lo                              // 000000401EC0: BE83206A
	s_cbranch_execz 24                                         // 000000401EC4: BFA50018 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0xb28>
	s_add_u32 s6, s8, s4                                       // 000000401EC8: 80060408
	s_addc_u32 s7, s9, s5                                      // 000000401ECC: 82070509
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000401ED0: BF870099
	v_mad_i64_i32 v[3:4], null, 0x300, v1, s[6:7]              // 000000401ED4: D6FF7C03 001A02FF 00000300
	.long 0xd7000203                                           // 000000401EE0: D7000203
	v_cndmask_b32_e32 v1, v3, v21, vcc_lo                      // 000000401EE4: 02022B03
	s_delay_alu instid0(VALU_DEP_1)                            // 000000401EE8: BF870001
	v_add_co_ci_u32_e64 v4, null, 0, v4, s2                    // 000000401EEC: D5207C04 000A0880
	s_clause 0x5                                               // 000000401EF4: BF850005
	global_load_b32 v55, v[3:4], off                           // 000000401EF8: DC520000 377C0003
	global_load_b32 v56, v[3:4], off offset:128                // 000000401F00: DC520080 387C0003
	global_load_b32 v57, v[3:4], off offset:256                // 000000401F08: DC520100 397C0003
	global_load_b32 v58, v[3:4], off offset:384                // 000000401F10: DC520180 3A7C0003
	global_load_b32 v59, v[3:4], off offset:512                // 000000401F18: DC520200 3B7C0003
	global_load_b32 v60, v[3:4], off offset:640                // 000000401F20: DC520280 3C7C0003
	s_or_b32 exec_lo, exec_lo, s3                              // 000000401F28: 8C7E037E
	v_dual_mov_b32 v53, 0 :: v_dual_mov_b32 v52, 0             // 000000401F2C: CA100080 35340080
	v_dual_mov_b32 v51, 0 :: v_dual_mov_b32 v50, 0             // 000000401F34: CA100080 33320080
	v_dual_mov_b32 v49, 0 :: v_dual_mov_b32 v48, 0             // 000000401F3C: CA100080 31300080
	v_dual_mov_b32 v47, 0 :: v_dual_mov_b32 v46, 0             // 000000401F44: CA100080 2F2E0080
	v_dual_mov_b32 v45, 0 :: v_dual_mov_b32 v44, 0             // 000000401F4C: CA100080 2D2C0080
	v_dual_mov_b32 v43, 0 :: v_dual_mov_b32 v42, 0             // 000000401F54: CA100080 2B2A0080
	v_dual_mov_b32 v41, 0 :: v_dual_mov_b32 v40, 0             // 000000401F5C: CA100080 29280080
	v_dual_mov_b32 v39, 0 :: v_dual_mov_b32 v38, 0             // 000000401F64: CA100080 27260080
	v_dual_mov_b32 v37, 0 :: v_dual_mov_b32 v36, 0             // 000000401F6C: CA100080 25240080
	v_dual_mov_b32 v35, 0 :: v_dual_mov_b32 v34, 0             // 000000401F74: CA100080 23220080
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v32, 0             // 000000401F7C: CA100080 21200080
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v31, 0             // 000000401F84: CA100080 181E0080
	v_dual_mov_b32 v30, 0 :: v_dual_mov_b32 v29, 0             // 000000401F8C: CA100080 1E1C0080
	v_dual_mov_b32 v28, 0 :: v_dual_mov_b32 v25, 0             // 000000401F94: CA100080 1C180080
	v_dual_mov_b32 v27, 0 :: v_dual_mov_b32 v26, 0             // 000000401F9C: CA100080 1B1A0080
	v_mov_b32_e32 v22, 0                                       // 000000401FA4: 7E2C0280
	s_ashr_i32 s27, s26, 31                                    // 000000401FA8: 861B9F1A
	s_and_saveexec_b32 s3, vcc_lo                              // 000000401FAC: BE83206A
	s_cbranch_execz 1197                                       // 000000401FB0: BFA504AD <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1e68>
	v_or_b32_e32 v4, 4, v2                                     // 000000401FB4: 38080484
	v_mad_u32_u24 v7, v20, 24, 0x2f0                           // 000000401FB8: D60B0007 03FD3114 000002F0
	v_mad_i64_i32 v[2:3], null, 0x300, v1, s[4:5]              // 000000401FC4: D6FF7C02 001202FF 00000300
	v_mul_u32_u24_e32 v6, 0x320, v19                           // 000000401FD0: 160C26FF 00000320
	v_mul_i32_i24_e32 v8, 0xffffffe8, v20                      // 000000401FD8: 121028FF FFFFFFE8
	v_mad_u32_u24 v5, v4, 3, 0x2f0                             // 000000401FE0: D60B0005 03FD0704 000002F0
	v_cmp_lt_u32_e32 vcc_lo, 5, v4                             // 000000401FEC: 7C920885
	v_lshrrev_b32_e32 v12, 5, v7                               // 000000401FF0: 32180E85
	v_mul_i32_i24_e32 v13, -3, v4                              // 000000401FF4: 121A08C3
	v_mad_u32_u24 v10, 0x320, v19, v21                         // 000000401FF8: D60B000A 045626FF 00000320
	v_lshrrev_b32_e32 v9, 5, v5                                // 000000402004: 32120A85
	v_dual_mov_b32 v26, 0 :: v_dual_and_b32 v5, 0x7e0, v5      // 000000402008: CA240080 1A040AFF 000007E0
	v_dual_mov_b32 v22, 0 :: v_dual_and_b32 v11, 16, v0        // 000000402014: CA240080 160A0090
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000040201C: BF870223
	v_subrev_nc_u32_e32 v9, 24, v9                             // 000000402020: 4E121298
	v_and_b32_e32 v7, 0x7e0, v7                                // 000000402024: 360E0EFF 000007E0
	v_add3_u32 v62, v13, v5, 0xfffffd34                        // 00000040202C: D655003E 03FE0B0D FFFFFD34
	v_sub_nc_u32_e32 v64, 0, v54                               // 000000402038: 4C806C80
	v_lshl_or_b32 v63, v1, 5, v11                              // 00000040203C: D656003F 042D0B01
	v_cndmask_b32_e32 v4, 23, v9, vcc_lo                       // 000000402044: 02081297
	.long 0xd7006a02                                           // 000000402048: D7006A02
	v_cndmask_b32_e32 v1, v2, v21, vcc_lo                      // 00000040204C: 02022B02
	s_delay_alu instid0(VALU_DEP_1)                            // 000000402050: BF870001
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 000000402054: D5207C03 01AA0680
	v_subrev_nc_u32_e32 v9, 24, v12                            // 00000040205C: 4E121898
	v_cmp_ne_u32_e32 vcc_lo, 0, v20                            // 000000402060: 7C9A2880
	v_add_nc_u32_e32 v12, 1, v4                                // 000000402064: 4A180881
	v_subrev_nc_u32_e32 v14, 23, v4                            // 000000402068: 4E1C0897
	v_add3_u32 v61, v8, v7, 0xfffffd34                         // 00000040206C: D655003D 03FE0F08 FFFFFD34
	v_lshl_add_u32 v4, v4, 2, v6                               // 000000402078: D6460004 04190504
	v_cndmask_b32_e32 v9, 23, v9, vcc_lo                       // 000000402080: 02121297
	v_cmp_gt_u32_e32 vcc_lo, 24, v12                           // 000000402084: 7C981898
	v_dual_mov_b32 v28, 0 :: v_dual_add_nc_u32 v65, 1, v1      // 000000402088: CA200080 1C400281
	v_add_nc_u32_e32 v66, 0x5000, v10                          // 000000402090: 4A8414FF 00005000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000402098: BF870244
	v_lshl_add_u32 v7, v9, 2, v6                               // 00000040209C: D6460007 04190509
	v_cndmask_b32_e32 v5, v14, v12, vcc_lo                     // 0000004020A4: 020A190E
	v_cmp_gt_i32_e32 vcc_lo, 23, v9                            // 0000004020A8: 7C881297
	v_dual_mov_b32 v24, 0 :: v_dual_add_nc_u32 v69, 0x5000, v4 // 0000004020AC: CA200080 184408FF 00005000
	v_dual_mov_b32 v30, 0 :: v_dual_add_nc_u32 v67, 0x5000, v7 // 0000004020B8: CA200080 1E420EFF 00005000
	v_cndmask_b32_e64 v8, 0xffffffa4, 4, vcc_lo                // 0000004020C4: D5010008 01A908FF FFFFFFA4
	.long 0xd7006a02                                           // 0000004020D0: D7006A02
	v_cndmask_b32_e32 v1, s8, v2, vcc_lo                       // 0000004020D4: 02020408
	v_lshl_add_u32 v5, v5, 2, v6                               // 0000004020D8: D6460005 04190505
	v_add_co_ci_u32_e64 v3, null, s9, v3, vcc_lo               // 0000004020E0: D5207C03 01AA0609
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000004020E8: BF8701A3
	.long 0xd7006a11                                           // 0000004020EC: D7006A11
	v_cndmask_b32_e32 v1, 0x300, v2, vcc_lo                    // 0000004020F0: 020204FF 00000300
	v_dual_mov_b32 v27, 0 :: v_dual_add_nc_u32 v2, v7, v8      // 0000004020F8: CA200080 1B021107
	v_add_co_ci_u32_e64 v18, null, 0, v3, vcc_lo               // 000000402100: D5207C12 01AA0680
	v_dual_mov_b32 v29, 0 :: v_dual_add_nc_u32 v70, 0x5000, v5 // 000000402108: CA200080 1D460AFF 00005000
	s_delay_alu instid0(VALU_DEP_3)                            // 000000402114: BF870003
	v_dual_mov_b32 v25, 0 :: v_dual_add_nc_u32 v68, 0x5000, v2 // 000000402118: CA200080 194404FF 00005000
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v32, 0             // 000000402124: CA100080 1F200080
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v34, 0             // 00000040212C: CA100080 21220080
	v_dual_mov_b32 v35, 0 :: v_dual_mov_b32 v36, 0             // 000000402134: CA100080 23240080
	v_dual_mov_b32 v37, 0 :: v_dual_mov_b32 v38, 0             // 00000040213C: CA100080 25260080
	v_dual_mov_b32 v39, 0 :: v_dual_mov_b32 v40, 0             // 000000402144: CA100080 27280080
	v_dual_mov_b32 v41, 0 :: v_dual_mov_b32 v42, 0             // 00000040214C: CA100080 292A0080
	v_dual_mov_b32 v43, 0 :: v_dual_mov_b32 v44, 0             // 000000402154: CA100080 2B2C0080
	v_dual_mov_b32 v45, 0 :: v_dual_mov_b32 v46, 0             // 00000040215C: CA100080 2D2E0080
	v_dual_mov_b32 v47, 0 :: v_dual_mov_b32 v48, 0             // 000000402164: CA100080 2F300080
	v_dual_mov_b32 v49, 0 :: v_dual_mov_b32 v50, 0             // 00000040216C: CA100080 31320080
	v_dual_mov_b32 v51, 0 :: v_dual_mov_b32 v52, 0             // 000000402174: CA100080 33340080
	v_mov_b32_e32 v53, 0                                       // 00000040217C: 7E6A0280
	v_mov_b32_e32 v23, 0                                       // 000000402180: 7E2E0280
	s_mov_b32 s4, 0                                            // 000000402184: BE840080
	s_movk_i32 s5, 0x1eee                                      // 000000402188: B0051EEE
	s_branch 1050                                              // 00000040218C: BFA0041A <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1df8>
	s_or_b32 exec_lo, exec_lo, s2                              // 000000402190: 8C7E027E
	ds_load_2addr_b32 v[71:72], v68 offset1:24                 // 000000402194: D8DC1800 47000044
	ds_load_2addr_b32 v[73:74], v70 offset1:24                 // 00000040219C: D8DC1800 49000046
	ds_load_2addr_b32 v[10:11], v67 offset1:24                 // 0000004021A4: D8DC1800 0A000043
	ds_load_2addr_b32 v[77:78], v69 offset1:24                 // 0000004021AC: D8DC1800 4D000045
	ds_load_b128 v[5:8], v63                                   // 0000004021B4: DBFC0000 0500003F
	ds_load_b128 v[1:4], v63 offset:5120                       // 0000004021BC: DBFC1400 0100003F
	.long 0xd7000211                                           // 0000004021C4: D7000211
	v_cndmask_b32_e32 v1, 0x300, v17, vcc_lo                   // 0000004021C8: 020222FF 00000300
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004021D0: BF870001
	v_add_co_ci_u32_e64 v18, null, 0, v18, s2                  // 0000004021D4: D5207C12 000A2480
	v_add_nc_u32_e32 v65, 1, v65                               // 0000004021DC: 4A828281
	s_waitcnt lgkmcnt(4)                                       // 0000004021E0: BF89FC47
	v_dual_mov_b32 v9, v71 :: v_dual_mov_b32 v76, v73          // 0000004021E4: CA100147 094C0149
	s_waitcnt lgkmcnt(2)                                       // 0000004021EC: BF89FC27
	v_mov_b32_e32 v75, v78                                     // 0000004021F0: 7E96034E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004021F4: BF870192
	.long 0xd73d004e                                           // 0000004021F8: D73D004E
	v_cndmask_b32_e32 v1, v61, v9, vcc_lo                      // 0000004021FC: 0202133D
	.long 0xd73d004c                                           // 000000402200: D73D004C
	v_cndmask_b32_e32 v1, v62, v76, vcc_lo                     // 000000402204: 0202993E
	v_mov_b32_e32 v73, v11                                     // 000000402208: 7E92030B
	ds_load_b128 v[9:12], v63 offset:10240                     // 00000040220C: DBFC2800 0900003F
	ds_load_b128 v[13:16], v63 offset:15360                    // 000000402214: DBFC3C00 0D00003F
	v_add_nc_u32_e32 v63, 32, v63                              // 00000040221C: 4A7E7EA0
	.long 0xd73d0047                                           // 000000402220: D73D0047
	v_cndmask_b32_e32 v1, v61, v72, vcc_lo                     // 000000402224: 0202913D
	.long 0xd73d0048                                           // 000000402228: D73D0048
	v_cndmask_b32_e32 v1, v62, v74, vcc_lo                     // 00000040222C: 0202953E
	v_bfe_u32 v73, v78, 9, 16                                  // 000000402230: D6100049 0241134E
	v_bfe_u32 v74, v78, 6, 16                                  // 000000402238: D610004A 02410D4E
	v_bfe_u32 v75, v78, 3, 16                                  // 000000402240: D610004B 0241074E
	v_bfe_u32 v79, v76, 6, 16                                  // 000000402248: D610004F 02410D4C
	v_bfe_u32 v80, v76, 3, 16                                  // 000000402250: D6100050 0241074C
	.long 0xd72c0049                                           // 000000402258: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 00000040225C: 020292FF 83DCD12D
	.long 0xd72c004a                                           // 000000402264: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000402268: 020294FF 83DCD12D
	.long 0xd72c004b                                           // 000000402270: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000402274: 020296FF 83DCD12D
	.long 0xd72c004f                                           // 00000040227C: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 000000402280: 02029EFF 83DCD12D
	v_bfe_u32 v81, v71, 9, 16                                  // 000000402288: D6100051 02411347
	v_bfe_u32 v82, v71, 6, 16                                  // 000000402290: D6100052 02410D47
	v_bfe_u32 v83, v71, 3, 16                                  // 000000402298: D6100053 02410747
	.long 0xd72c0050                                           // 0000004022A0: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 0000004022A4: 0202A0FF 83DCD12D
	v_sad_u8 v73, v73, 0, 0x6400                               // 0000004022AC: D6220049 03FD0149 00006400
	v_sad_u8 v74, v74, 0, 0x6400                               // 0000004022B8: D622004A 03FD014A 00006400
	v_sad_u8 v75, v75, 0, 0x6400                               // 0000004022C4: D622004B 03FD014B 00006400
	v_sad_u8 v79, v79, 0, 0x6400                               // 0000004022D0: D622004F 03FD014F 00006400
	.long 0xd72c0053                                           // 0000004022DC: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 0000004022E0: 0202A6FF 83DCD12D
	v_and_b32_e32 v73, 0xffff, v73                             // 0000004022E8: 369292FF 0000FFFF
	.long 0xd72c0051                                           // 0000004022F0: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 0000004022F4: 0202A2FF 83DCD12D
	.long 0xd72c0052                                           // 0000004022FC: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000402300: 0202A4FF 83DCD12D
	v_bfe_u32 v84, v72, 9, 16                                  // 000000402308: D6100054 02411348
	v_bfe_u32 v85, v72, 6, 16                                  // 000000402310: D6100055 02410D48
	v_lshl_or_b32 v73, v74, 16, v73                            // 000000402318: D6560049 0525214A
	v_sad_u8 v74, v80, 0, 0x6400                               // 000000402320: D622004A 03FD0150 00006400
	v_bfe_u32 v86, v72, 3, 16                                  // 00000040232C: D6100056 02410748
	v_and_b32_e32 v72, 0xffff, v72                             // 000000402334: 369090FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 00000040233C: BF870004
	v_pk_fma_f16 v73, v73, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000402340: CC0E0049 0BFC0B49 0000C931
	v_and_b32_e32 v77, 0xffff, v78                             // 00000040234C: 369A9CFF 0000FFFF
	v_bfe_u32 v78, v76, 9, 16                                  // 000000402354: D610004E 0241134C
	v_and_b32_e32 v76, 0xffff, v76                             // 00000040235C: 369898FF 0000FFFF
	s_waitcnt lgkmcnt(2)                                       // 000000402364: BF89FC27
	v_dual_dot2acc_f32_f16 v26, v73, v1 :: v_dual_and_b32 v71, 0xffff, v71// 000000402368: CB240349 1A468EFF 0000FFFF
	v_dot2acc_f32_f16 v22, v73, v5                             // 000000402374: 042C0B49
	.long 0xd72c004d                                           // 000000402378: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 00000040237C: 02029AFF 83DCD12D
	.long 0xd72c004e                                           // 000000402384: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000402388: 02029CFF 83DCD12D
	.long 0xd72c004c                                           // 000000402390: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000402394: 020298FF 83DCD12D
	.long 0xd72c0047                                           // 00000040239C: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 0000004023A0: 02028EFF 83DCD12D
	s_waitcnt lgkmcnt(1)                                       // 0000004023A8: BF89FC17
	v_dot2acc_f32_f16 v27, v73, v9                             // 0000004023AC: 04361349
	v_sad_u8 v77, v77, 0, 0x6400                               // 0000004023B0: D622004D 03FD014D 00006400
	v_sad_u8 v78, v78, 0, 0x6400                               // 0000004023BC: D622004E 03FD014E 00006400
	v_sad_u8 v76, v76, 0, 0x6400                               // 0000004023C8: D622004C 03FD014C 00006400
	v_sad_u8 v71, v71, 0, 0x6400                               // 0000004023D4: D6220047 03FD0147 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004023E0: BF870214
	v_lshlrev_b32_e32 v77, 16, v77                             // 0000004023E4: 309A9A90
	v_and_b32_e32 v78, 0xffff, v78                             // 0000004023E8: 369C9CFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004023F0: BF870214
	v_lshlrev_b32_e32 v76, 16, v76                             // 0000004023F4: 30989890
	v_lshlrev_b32_e32 v71, 16, v71                             // 0000004023F8: 308E8E90
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004023FC: BF870214
	v_and_or_b32 v75, 0xffff, v75, v77                         // 000000402400: D657004B 053696FF 0000FFFF
	v_lshl_or_b32 v78, v79, 16, v78                            // 00000040240C: D656004E 0539214F
	s_delay_alu instid0(VALU_DEP_4)                            // 000000402414: BF870004
	v_and_or_b32 v74, 0xffff, v74, v76                         // 000000402418: D657004A 053294FF 0000FFFF
	.long 0xd72c004d                                           // 000000402424: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000402428: 0202A8FF 83DCD12D
	.long 0xd72c004f                                           // 000000402430: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000402434: 020290FF 83DCD12D
	v_pk_fma_f16 v75, v75, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000040243C: CC0E004B 0BFC0B4B 0000C931
	v_pk_fma_f16 v76, v78, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000402448: CC0E004C 0BFC0B4E 0000C931
	v_pk_fma_f16 v78, v74, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000402454: CC0E004E 0BFC0B4A 0000C931
	v_sad_u8 v74, v82, 0, 0x6400                               // 000000402460: D622004A 03FD0152 00006400
	s_waitcnt lgkmcnt(0)                                       // 00000040246C: BF89FC07
	v_dual_dot2acc_f32_f16 v22, v75, v6 :: v_dual_dot2acc_f32_f16 v25, v73, v13// 000000402470: CB180D4B 16181B49
	v_dot2acc_f32_f16 v26, v75, v2                             // 000000402478: 0434054B
	v_dot2acc_f32_f16 v27, v75, v10                            // 00000040247C: 0436154B
	v_sad_u8 v73, v81, 0, 0x6400                               // 000000402480: D6220049 03FD0151 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000040248C: BF8701B4
	v_dual_dot2acc_f32_f16 v22, v76, v7 :: v_dual_dot2acc_f32_f16 v25, v75, v14// 000000402490: CB180F4C 16181D4B
	v_sad_u8 v75, v83, 0, 0x6400                               // 000000402498: D622004B 03FD0153 00006400
	v_dot2acc_f32_f16 v26, v76, v3                             // 0000004024A4: 0434074C
	v_dual_dot2acc_f32_f16 v27, v76, v11 :: v_dual_dot2acc_f32_f16 v22, v78, v8// 0000004024A8: CB18174C 1B16114E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004024B0: BF870214
	v_dot2acc_f32_f16 v25, v76, v15                            // 0000004024B4: 04321F4C
	v_and_or_b32 v80, 0xffff, v75, v71                         // 0000004024B8: D6570050 051E96FF 0000FFFF
	.long 0xd72c004c                                           // 0000004024C4: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 0000004024C8: 0202AAFF 83DCD12D
	v_sad_u8 v77, v77, 0, 0x6400                               // 0000004024D0: D622004D 03FD014D 00006400
	v_dot2acc_f32_f16 v26, v78, v4                             // 0000004024DC: 0434094E
	ds_load_2addr_b32 v[71:72], v68 offset0:48 offset1:72      // 0000004024E0: D8DC4830 47000044
	v_pk_fma_f16 v83, v80, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000004024E8: CC0E0053 0BFC0B50 0000C931
	v_and_b32_e32 v73, 0xffff, v73                             // 0000004024F4: 369292FF 0000FFFF
	.long 0xd72c0051                                           // 0000004024FC: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 000000402500: 0202ACFF 83DCD12D
	v_dot2acc_f32_f16 v25, v78, v16                            // 000000402508: 0432214E
	v_sad_u8 v76, v76, 0, 0x6400                               // 00000040250C: D622004C 03FD014C 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 000000402518: BF870004
	v_lshl_or_b32 v73, v74, 16, v73                            // 00000040251C: D6560049 0525214A
	ds_load_2addr_b32 v[74:75], v67 offset0:48 offset1:72      // 000000402524: D8DC4830 4A000043
	v_sad_u8 v81, v81, 0, 0x6400                               // 00000040252C: D6220051 03FD0151 00006400
	v_pk_fma_f16 v82, v73, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000402538: CC0E0052 0BFC0B49 0000C931
	v_sad_u8 v73, v79, 0, 0x6400                               // 000000402544: D6220049 03FD014F 00006400
	ds_load_2addr_b32 v[79:80], v69 offset0:48 offset1:72      // 000000402550: D8DC4830 4F000045
	v_dot2acc_f32_f16 v28, v82, v5                             // 000000402558: 04380B52
	v_dot2acc_f32_f16 v27, v78, v12                            // 00000040255C: 0436194E
	v_dot2acc_f32_f16 v30, v82, v9                             // 000000402560: 043C1352
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000402564: BF870113
	v_dual_dot2acc_f32_f16 v28, v83, v6 :: v_dual_and_b32 v77, 0xffff, v77// 000000402568: CB240D53 1C4C9AFF 0000FFFF
	v_dot2acc_f32_f16 v30, v83, v10                            // 000000402574: 043C1553
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000402578: BF8700B2
	v_lshl_or_b32 v84, v76, 16, v77                            // 00000040257C: D6560054 0535214C
	ds_load_2addr_b32 v[76:77], v70 offset0:48 offset1:72      // 000000402584: D8DC4830 4C000046
	v_pk_fma_f16 v84, v84, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000040258C: CC0E0054 0BFC0B54 0000C931
	v_dual_dot2acc_f32_f16 v30, v84, v11 :: v_dual_lshlrev_b32 v73, 16, v73// 000000402598: CB221754 1E489290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000004025A0: BF870131
	v_and_or_b32 v81, 0xffff, v81, v73                         // 0000004025A4: D6570051 0526A2FF 0000FFFF
	s_waitcnt lgkmcnt(3)                                       // 0000004025B0: BF89FC37
	v_dual_mov_b32 v73, v71 :: v_dual_dot2acc_f32_f16 v28, v84, v7// 0000004025B4: CA180147 491C0F54
	v_pk_fma_f16 v71, v81, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000004025BC: CC0E0047 0BFC0B51 0000C931
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000004025C8: BF8701C1
	v_dual_dot2acc_f32_f16 v29, v82, v1 :: v_dual_dot2acc_f32_f16 v28, v71, v8// 0000004025CC: CB180352 1D1C1147
	s_waitcnt lgkmcnt(0)                                       // 0000004025D4: BF89FC07
	v_mov_b32_e32 v78, v76                                     // 0000004025D8: 7E9C034C
	.long 0xd73d0049                                           // 0000004025DC: D73D0049
	v_cndmask_b32_e32 v1, v61, v73, vcc_lo                     // 0000004025E0: 0202933D
	v_dot2acc_f32_f16 v29, v83, v2                             // 0000004025E4: 043A0553
	v_dot2acc_f32_f16 v30, v71, v12                            // 0000004025E8: 043C1947
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004025EC: BF870214
	.long 0xd73d004e                                           // 0000004025F0: D73D004E
	v_cndmask_b32_e32 v1, v62, v78, vcc_lo                     // 0000004025F4: 02029D3E
	v_bfe_u32 v74, v73, 9, 16                                  // 0000004025F8: D610004A 02411349
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000402600: BF870234
	v_dual_dot2acc_f32_f16 v29, v84, v3 :: v_dual_and_b32 v76, 0xffff, v73// 000000402604: CB240754 1D4C92FF 0000FFFF
	v_bfe_u32 v79, v73, 6, 16                                  // 000000402610: D610004F 02410D49
	v_bfe_u32 v73, v73, 3, 16                                  // 000000402618: D6100049 02410749
	.long 0xd72c004a                                           // 000000402620: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000402624: 020294FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 00000040262C: BF870004
	.long 0xd72c004c                                           // 000000402630: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000402634: 020298FF 83DCD12D
	v_dot2acc_f32_f16 v29, v71, v4                             // 00000040263C: 043A0947
	v_bfe_u32 v81, v78, 9, 16                                  // 000000402640: D6100051 0241134E
	.long 0xd72c004f                                           // 000000402648: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 00000040264C: 02029EFF 83DCD12D
	.long 0xd72c0049                                           // 000000402654: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000402658: 020292FF 83DCD12D
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000402660: D622004A 03FD014A 00006400
	v_dot2acc_f32_f16 v31, v82, v13                            // 00000040266C: 043E1B52
	v_bfe_u32 v82, v78, 6, 16                                  // 000000402670: D6100052 02410D4E
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000402678: D622004C 03FD014C 00006400
	.long 0xd72c0051                                           // 000000402684: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000402688: 0202A2FF 83DCD12D
	v_and_b32_e32 v74, 0xffff, v74                             // 000000402690: 369494FF 0000FFFF
	v_dot2acc_f32_f16 v31, v83, v14                            // 000000402698: 043E1D53
	v_bfe_u32 v83, v78, 3, 16                                  // 00000040269C: D6100053 0241074E
	v_and_b32_e32 v78, 0xffff, v78                             // 0000004026A4: 369C9CFF 0000FFFF
	v_sad_u8 v79, v79, 0, 0x6400                               // 0000004026AC: D622004F 03FD014F 00006400
	v_sad_u8 v73, v73, 0, 0x6400                               // 0000004026B8: D6220049 03FD0149 00006400
	v_lshlrev_b32_e32 v76, 16, v76                             // 0000004026C4: 30989890
	.long 0xd72c0053                                           // 0000004026C8: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 0000004026CC: 0202A6FF 83DCD12D
	.long 0xd72c004e                                           // 0000004026D4: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 0000004026D8: 02029CFF 83DCD12D
	v_sad_u8 v81, v81, 0, 0x6400                               // 0000004026E0: D6220051 03FD0151 00006400
	v_lshl_or_b32 v74, v79, 16, v74                            // 0000004026EC: D656004A 0529214F
	v_and_or_b32 v73, 0xffff, v73, v76                         // 0000004026F4: D6570049 053292FF 0000FFFF
	v_dot2acc_f32_f16 v31, v84, v15                            // 000000402700: 043E1F54
	.long 0xd72c0052                                           // 000000402704: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000402708: 0202A4FF 83DCD12D
	v_and_b32_e32 v76, 0xffff, v81                             // 000000402710: 3698A2FF 0000FFFF
	v_pk_fma_f16 v74, v74, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000402718: CC0E004A 0BFC0B4A 0000C931
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000402724: D622004E 03FD014E 00006400
	v_pk_fma_f16 v81, v73, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000402730: CC0E0051 0BFC0B49 0000C931
	v_sad_u8 v73, v83, 0, 0x6400                               // 00000040273C: D6220049 03FD0153 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000402748: BF870214
	v_dual_dot2acc_f32_f16 v31, v71, v16 :: v_dual_dot2acc_f32_f16 v24, v74, v5// 00000040274C: CB182147 1F180B4A
	v_lshlrev_b32_e32 v78, 16, v78                             // 000000402754: 309C9C90
	v_sad_u8 v79, v82, 0, 0x6400                               // 000000402758: D622004F 03FD0152 00006400
	v_dot2acc_f32_f16 v33, v74, v9                             // 000000402764: 0442134A
	v_dot2acc_f32_f16 v32, v74, v1                             // 000000402768: 0440034A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000040276C: BF870244
	v_and_or_b32 v71, 0xffff, v73, v78                         // 000000402770: D6570047 053A92FF 0000FFFF
	v_dual_mov_b32 v73, v75 :: v_dual_mov_b32 v78, v80         // 00000040277C: CA10014B 494E0150
	v_dot2acc_f32_f16 v24, v81, v6                             // 000000402784: 04300D51
	v_lshl_or_b32 v76, v79, 16, v76                            // 000000402788: D656004C 0531214F
	v_pk_fma_f16 v82, v71, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000402790: CC0E0052 0BFC0B47 0000C931
	s_delay_alu instid0(VALU_DEP_4)                            // 00000040279C: BF870004
	.long 0xd73d0047                                           // 0000004027A0: D73D0047
	v_cndmask_b32_e32 v1, v61, v72, vcc_lo                     // 0000004027A4: 0202913D
	v_dot2acc_f32_f16 v34, v74, v13                            // 0000004027A8: 04441B4A
	.long 0xd73d0048                                           // 0000004027AC: D73D0048
	v_cndmask_b32_e32 v1, v62, v77, vcc_lo                     // 0000004027B0: 02029B3E
	v_pk_fma_f16 v76, v76, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000004027B4: CC0E004C 0BFC0B4C 0000C931
	v_dot2acc_f32_f16 v33, v81, v10                            // 0000004027C0: 04421551
	v_dot2acc_f32_f16 v32, v81, v2                             // 0000004027C4: 04400551
	v_bfe_u32 v74, v71, 9, 16                                  // 0000004027C8: D610004A 02411347
	v_dual_dot2acc_f32_f16 v34, v81, v14 :: v_dual_and_b32 v75, 0xffff, v71// 0000004027D0: CB241D51 224A8EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000004027DC: BF870224
	v_dot2acc_f32_f16 v33, v76, v11                            // 0000004027E0: 0442174C
	v_dot2acc_f32_f16 v24, v76, v7                             // 0000004027E4: 04300F4C
	.long 0xd72c0049                                           // 0000004027E8: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 0000004027EC: 020294FF 83DCD12D
	v_bfe_u32 v74, v71, 6, 16                                  // 0000004027F4: D610004A 02410D47
	v_bfe_u32 v71, v71, 3, 16                                  // 0000004027FC: D6100047 02410747
	.long 0xd72c004b                                           // 000000402804: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000402808: 020296FF 83DCD12D
	v_dot2acc_f32_f16 v33, v82, v12                            // 000000402810: 04421952
	v_bfe_u32 v77, v72, 6, 16                                  // 000000402814: D610004D 02410D48
	.long 0xd72c004a                                           // 00000040281C: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000402820: 020294FF 83DCD12D
	.long 0xd72c0047                                           // 000000402828: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 00000040282C: 02028EFF 83DCD12D
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000402834: D6220049 03FD0149 00006400
	v_dot2acc_f32_f16 v32, v76, v3                             // 000000402840: 0440074C
	v_bfe_u32 v78, v72, 3, 16                                  // 000000402844: D610004E 02410748
	v_sad_u8 v75, v75, 0, 0x6400                               // 00000040284C: D622004B 03FD014B 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000402858: BF870234
	v_dual_dot2acc_f32_f16 v24, v82, v8 :: v_dual_and_b32 v73, 0xffff, v73// 00000040285C: CB241152 184892FF 0000FFFF
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000402868: D622004A 03FD014A 00006400
	v_sad_u8 v71, v71, 0, 0x6400                               // 000000402874: D6220047 03FD0147 00006400
	v_lshlrev_b32_e32 v75, 16, v75                             // 000000402880: 30969690
	.long 0xd72c004d                                           // 000000402884: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000402888: 02029AFF 83DCD12D
	.long 0xd72c004e                                           // 000000402890: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000402894: 02029CFF 83DCD12D
	v_lshl_or_b32 v73, v74, 16, v73                            // 00000040289C: D6560049 0525214A
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004028A4: BF870004
	v_and_or_b32 v80, 0xffff, v71, v75                         // 0000004028A8: D6570050 052E8EFF 0000FFFF
	ds_load_2addr_b32 v[74:75], v67 offset0:96 offset1:120     // 0000004028B4: D8DC7860 4A000043
	v_pk_fma_f16 v81, v73, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000004028BC: CC0E0051 0BFC0B49 0000C931
	v_dot2acc_f32_f16 v34, v76, v15                            // 0000004028C8: 04441F4C
	v_bfe_u32 v76, v72, 9, 16                                  // 0000004028CC: D610004C 02411348
	v_pk_fma_f16 v83, v80, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000004028D4: CC0E0053 0BFC0B50 0000C931
	v_sad_u8 v77, v77, 0, 0x6400                               // 0000004028E0: D622004D 03FD014D 00006400
	v_dual_dot2acc_f32_f16 v35, v81, v5 :: v_dual_and_b32 v72, 0xffff, v72// 0000004028EC: CB240B51 234890FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000004028F8: BF870234
	.long 0xd72c004c                                           // 0000004028FC: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000402900: 020298FF 83DCD12D
	v_dot2acc_f32_f16 v37, v81, v9                             // 000000402908: 044A1351
	v_sad_u8 v78, v78, 0, 0x6400                               // 00000040290C: D622004E 03FD014E 00006400
	v_dot2acc_f32_f16 v35, v83, v6                             // 000000402918: 04460D53
	.long 0xd72c004f                                           // 00000040291C: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000402920: 020290FF 83DCD12D
	ds_load_2addr_b32 v[71:72], v68 offset0:96 offset1:120     // 000000402928: D8DC7860 47000044
	v_dual_dot2acc_f32_f16 v37, v83, v10 :: v_dual_dot2acc_f32_f16 v38, v81, v13// 000000402930: CB181553 25261B51
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000402938: D622004C 03FD014C 00006400
	v_sad_u8 v73, v79, 0, 0x6400                               // 000000402944: D6220049 03FD014F 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 000000402950: BF870002
	v_and_b32_e32 v76, 0xffff, v76                             // 000000402954: 369898FF 0000FFFF
	v_dot2acc_f32_f16 v32, v82, v4                             // 00000040295C: 04400952
	ds_load_2addr_b32 v[79:80], v69 offset0:96 offset1:120     // 000000402960: D8DC7860 4F000045
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000402968: 30929290
	v_lshl_or_b32 v84, v77, 16, v76                            // 00000040296C: D6560054 0531214D
	ds_load_2addr_b32 v[76:77], v70 offset0:96 offset1:120     // 000000402974: D8DC7860 4C000046
	v_and_or_b32 v78, 0xffff, v78, v73                         // 00000040297C: D657004E 05269CFF 0000FFFF
	v_pk_fma_f16 v84, v84, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000402988: CC0E0054 0BFC0B54 0000C931
	s_waitcnt lgkmcnt(2)                                       // 000000402994: BF89FC27
	v_dual_dot2acc_f32_f16 v36, v81, v1 :: v_dual_mov_b32 v73, v71// 000000402998: CB100351 24480147
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004029A0: BF870113
	v_pk_fma_f16 v71, v78, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000004029A4: CC0E0047 0BFC0B4E 0000C931
	v_dual_dot2acc_f32_f16 v35, v84, v7 :: v_dual_dot2acc_f32_f16 v36, v83, v2// 0000004029B0: CB180F54 23240553
	v_dot2acc_f32_f16 v37, v84, v11                            // 0000004029B8: 044A1754
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004029BC: BF870194
	.long 0xd73d0049                                           // 0000004029C0: D73D0049
	v_cndmask_b32_e32 v1, v61, v73, vcc_lo                     // 0000004029C4: 0202933D
	v_dual_dot2acc_f32_f16 v35, v71, v8 :: v_dual_dot2acc_f32_f16 v36, v84, v3// 0000004029C8: CB181147 23240754
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004029D0: BF870193
	v_dot2acc_f32_f16 v37, v71, v12                            // 0000004029D4: 044A1947
	v_bfe_u32 v74, v73, 9, 16                                  // 0000004029D8: D610004A 02411349
	s_waitcnt lgkmcnt(0)                                       // 0000004029E0: BF89FC07
	v_mov_b32_e32 v78, v76                                     // 0000004029E4: 7E9C034C
	v_and_b32_e32 v76, 0xffff, v73                             // 0000004029E8: 369892FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004029F0: BF870193
	.long 0xd72c004a                                           // 0000004029F4: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 0000004029F8: 020294FF 83DCD12D
	.long 0xd73d004e                                           // 000000402A00: D73D004E
	v_cndmask_b32_e32 v1, v62, v78, vcc_lo                     // 000000402A04: 02029D3E
	v_bfe_u32 v79, v73, 6, 16                                  // 000000402A08: D610004F 02410D49
	v_bfe_u32 v73, v73, 3, 16                                  // 000000402A10: D6100049 02410749
	.long 0xd72c004c                                           // 000000402A18: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000402A1C: 020298FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3)                            // 000000402A24: BF870003
	.long 0xd72c004f                                           // 000000402A28: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 000000402A2C: 02029EFF 83DCD12D
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000402A34: D622004A 03FD014A 00006400
	v_bfe_u32 v81, v78, 9, 16                                  // 000000402A40: D6100051 0241134E
	.long 0xd72c0049                                           // 000000402A48: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000402A4C: 020292FF 83DCD12D
	v_bfe_u32 v85, v78, 3, 16                                  // 000000402A54: D6100055 0241074E
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000402A5C: D622004C 03FD014C 00006400
	v_and_b32_e32 v74, 0xffff, v74                             // 000000402A68: 369494FF 0000FFFF
	.long 0xd72c0051                                           // 000000402A70: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000402A74: 0202A2FF 83DCD12D
	v_sad_u8 v79, v79, 0, 0x6400                               // 000000402A7C: D622004F 03FD014F 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000402A88: BF8701A4
	v_lshlrev_b32_e32 v76, 16, v76                             // 000000402A8C: 30989890
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000402A90: D6220049 03FD0149 00006400
	v_lshl_or_b32 v74, v79, 16, v74                            // 000000402A9C: D656004A 0529214F
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000402AA4: D6220051 03FD0151 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000402AB0: BF870193
	v_and_or_b32 v73, 0xffff, v73, v76                         // 000000402AB4: D6570049 053292FF 0000FFFF
	v_pk_fma_f16 v74, v74, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000402AC0: CC0E004A 0BFC0B4A 0000C931
	v_dot2acc_f32_f16 v36, v71, v4                             // 000000402ACC: 04480947
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000402AD0: BF870214
	v_and_b32_e32 v76, 0xffff, v81                             // 000000402AD4: 3698A2FF 0000FFFF
	v_pk_fma_f16 v81, v73, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000402ADC: CC0E0051 0BFC0B49 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000402AE8: BF870244
	v_dot2acc_f32_f16 v39, v74, v5                             // 000000402AEC: 044E0B4A
	v_dot2acc_f32_f16 v34, v82, v16                            // 000000402AF0: 04442152
	v_bfe_u32 v82, v78, 6, 16                                  // 000000402AF4: D6100052 02410D4E
	v_dual_dot2acc_f32_f16 v41, v74, v9 :: v_dual_and_b32 v78, 0xffff, v78// 000000402AFC: CB24134A 294E9CFF 0000FFFF
	v_dual_dot2acc_f32_f16 v39, v81, v6 :: v_dual_dot2acc_f32_f16 v42, v74, v13// 000000402B08: CB180D51 272A1B4A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000402B10: BF870193
	.long 0xd72c0052                                           // 000000402B14: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000402B18: 0202A4FF 83DCD12D
	.long 0xd72c004e                                           // 000000402B20: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000402B24: 02029CFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000402B2C: BF870214
	v_dot2acc_f32_f16 v41, v81, v10                            // 000000402B30: 04521551
	v_dot2acc_f32_f16 v42, v81, v14                            // 000000402B34: 04541D51
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000402B38: BF870214
	v_sad_u8 v79, v82, 0, 0x6400                               // 000000402B3C: D622004F 03FD0152 00006400
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000402B48: D622004E 03FD014E 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000402B54: BF870112
	v_lshl_or_b32 v76, v79, 16, v76                            // 000000402B58: D656004C 0531214F
	v_lshlrev_b32_e32 v78, 16, v78                             // 000000402B60: 309C9C90
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000402B64: BF870092
	v_pk_fma_f16 v82, v76, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000402B68: CC0E0052 0BFC0B4C 0000C931
	v_dual_dot2acc_f32_f16 v39, v82, v7 :: v_dual_dot2acc_f32_f16 v38, v83, v14// 000000402B74: CB180F52 27261D53
	v_dot2acc_f32_f16 v41, v82, v11                            // 000000402B7C: 04521752
	.long 0xd72c0053                                           // 000000402B80: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 000000402B84: 0202AAFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000402B8C: BF870113
	v_dot2acc_f32_f16 v38, v84, v15                            // 000000402B90: 044C1F54
	v_sad_u8 v73, v83, 0, 0x6400                               // 000000402B94: D6220049 03FD0153 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000402BA0: BF870112
	v_dot2acc_f32_f16 v38, v71, v16                            // 000000402BA4: 044C2147
	v_and_or_b32 v73, 0xffff, v73, v78                         // 000000402BA8: D6570049 053A92FF 0000FFFF
	v_mov_b32_e32 v78, v80                                     // 000000402BB4: 7E9C0350
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000402BB8: BF870122
	v_pk_fma_f16 v83, v73, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000402BBC: CC0E0053 0BFC0B49 0000C931
	v_mov_b32_e32 v73, v75                                     // 000000402BC8: 7E92034B
	v_dot2acc_f32_f16 v39, v83, v8                             // 000000402BCC: 044E1153
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000402BD0: BF870242
	.long 0xd73d0047                                           // 000000402BD4: D73D0047
	v_cndmask_b32_e32 v1, v61, v72, vcc_lo                     // 000000402BD8: 0202913D
	v_dot2acc_f32_f16 v40, v74, v1                             // 000000402BDC: 0450034A
	.long 0xd73d0048                                           // 000000402BE0: D73D0048
	v_cndmask_b32_e32 v1, v62, v77, vcc_lo                     // 000000402BE4: 02029B3E
	v_dot2acc_f32_f16 v41, v83, v12                            // 000000402BE8: 04521953
	v_bfe_u32 v74, v71, 9, 16                                  // 000000402BEC: D610004A 02411347
	v_and_b32_e32 v75, 0xffff, v71                             // 000000402BF4: 36968EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000402BFC: BF870004
	v_bfe_u32 v76, v72, 9, 16                                  // 000000402C00: D610004C 02411348
	v_bfe_u32 v77, v72, 6, 16                                  // 000000402C08: D610004D 02410D48
	v_bfe_u32 v78, v72, 3, 16                                  // 000000402C10: D610004E 02410748
	.long 0xd72c0049                                           // 000000402C18: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000402C1C: 020294FF 83DCD12D
	v_bfe_u32 v74, v71, 6, 16                                  // 000000402C24: D610004A 02410D47
	v_bfe_u32 v71, v71, 3, 16                                  // 000000402C2C: D6100047 02410747
	.long 0xd72c004b                                           // 000000402C34: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000402C38: 020296FF 83DCD12D
	.long 0xd72c004c                                           // 000000402C40: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000402C44: 020298FF 83DCD12D
	v_and_b32_e32 v72, 0xffff, v72                             // 000000402C4C: 369090FF 0000FFFF
	.long 0xd72c004a                                           // 000000402C54: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000402C58: 020294FF 83DCD12D
	.long 0xd72c0047                                           // 000000402C60: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000402C64: 02028EFF 83DCD12D
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000402C6C: D6220049 03FD0149 00006400
	.long 0xd72c004d                                           // 000000402C78: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000402C7C: 02029AFF 83DCD12D
	.long 0xd72c004f                                           // 000000402C84: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000402C88: 020290FF 83DCD12D
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000402C90: D622004B 03FD014B 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000402C9C: BF870234
	v_dual_dot2acc_f32_f16 v40, v81, v2 :: v_dual_and_b32 v73, 0xffff, v73// 000000402CA0: CB240551 284892FF 0000FFFF
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000402CAC: D622004A 03FD014A 00006400
	v_sad_u8 v71, v71, 0, 0x6400                               // 000000402CB8: D6220047 03FD0147 00006400
	v_lshlrev_b32_e32 v75, 16, v75                             // 000000402CC4: 30969690
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000402CC8: D622004C 03FD014C 00006400
	v_sad_u8 v77, v77, 0, 0x6400                               // 000000402CD4: D622004D 03FD014D 00006400
	v_lshl_or_b32 v73, v74, 16, v73                            // 000000402CE0: D6560049 0525214A
	.long 0xd72c004e                                           // 000000402CE8: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000402CEC: 02029CFF 83DCD12D
	v_and_or_b32 v80, 0xffff, v71, v75                         // 000000402CF4: D6570050 052E8EFF 0000FFFF
	ds_load_2addr_b32 v[71:72], v68 offset0:144 offset1:168    // 000000402D00: D8DCA890 47000044
	v_and_b32_e32 v76, 0xffff, v76                             // 000000402D08: 369898FF 0000FFFF
	ds_load_2addr_b32 v[74:75], v67 offset0:144 offset1:168    // 000000402D10: D8DCA890 4A000043
	v_pk_fma_f16 v81, v73, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000402D18: CC0E0051 0BFC0B49 0000C931
	v_sad_u8 v73, v79, 0, 0x6400                               // 000000402D24: D6220049 03FD014F 00006400
	v_dot2acc_f32_f16 v40, v82, v3                             // 000000402D30: 04500752
	v_lshl_or_b32 v85, v77, 16, v76                            // 000000402D34: D6560055 0531214D
	ds_load_2addr_b32 v[76:77], v70 offset0:144 offset1:168    // 000000402D3C: D8DCA890 4C000046
	v_pk_fma_f16 v84, v80, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000402D44: CC0E0054 0BFC0B50 0000C931
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000402D50: D622004E 03FD014E 00006400
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000402D5C: 30929290
	ds_load_2addr_b32 v[79:80], v69 offset0:144 offset1:168    // 000000402D60: D8DCA890 4F000045
	v_dual_dot2acc_f32_f16 v43, v81, v5 :: v_dual_dot2acc_f32_f16 v40, v83, v4// 000000402D68: CB180B51 2B280953
	v_dot2acc_f32_f16 v45, v81, v9                             // 000000402D70: 045A1351
	v_and_or_b32 v78, 0xffff, v78, v73                         // 000000402D74: D657004E 05269CFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000402D80: BF870193
	v_dual_dot2acc_f32_f16 v46, v81, v13 :: v_dual_dot2acc_f32_f16 v43, v84, v6// 000000402D84: CB181B51 2E2A0D54
	v_dot2acc_f32_f16 v45, v84, v10                            // 000000402D8C: 045A1554
	s_waitcnt lgkmcnt(3)                                       // 000000402D90: BF89FC37
	v_mov_b32_e32 v73, v71                                     // 000000402D94: 7E920347
	v_pk_fma_f16 v71, v78, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000402D98: CC0E0047 0BFC0B4E 0000C931
	v_dot2acc_f32_f16 v42, v82, v15                            // 000000402DA4: 04541F52
	v_pk_fma_f16 v82, v85, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000402DA8: CC0E0052 0BFC0B55 0000C931
	s_waitcnt lgkmcnt(2)                                       // 000000402DB4: BF89FC27
	.long 0xd73d0049                                           // 000000402DB8: D73D0049
	v_cndmask_b32_e32 v1, v61, v73, vcc_lo                     // 000000402DBC: 0202933D
	s_waitcnt lgkmcnt(1)                                       // 000000402DC0: BF89FC17
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000402DC4: BF8701A2
	v_dual_mov_b32 v78, v76 :: v_dual_dot2acc_f32_f16 v43, v82, v7// 000000402DC8: CA18014C 4E2A0F52
	v_dual_dot2acc_f32_f16 v44, v81, v1 :: v_dual_dot2acc_f32_f16 v45, v82, v11// 000000402DD0: CB180351 2C2C1752
	v_bfe_u32 v74, v73, 9, 16                                  // 000000402DD8: D610004A 02411349
	s_waitcnt lgkmcnt(0)                                       // 000000402DE0: BF89FC07
	s_delay_alu instid0(VALU_DEP_3)                            // 000000402DE4: BF870003
	.long 0xd73d004e                                           // 000000402DE8: D73D004E
	v_cndmask_b32_e32 v1, v62, v78, vcc_lo                     // 000000402DEC: 02029D3E
	v_and_b32_e32 v76, 0xffff, v73                             // 000000402DF0: 369892FF 0000FFFF
	v_bfe_u32 v79, v73, 6, 16                                  // 000000402DF8: D610004F 02410D49
	v_bfe_u32 v73, v73, 3, 16                                  // 000000402E00: D6100049 02410749
	.long 0xd72c004a                                           // 000000402E08: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000402E0C: 020294FF 83DCD12D
	v_dot2acc_f32_f16 v43, v71, v8                             // 000000402E14: 04561147
	.long 0xd72c004c                                           // 000000402E18: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000402E1C: 020298FF 83DCD12D
	.long 0xd72c004f                                           // 000000402E24: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 000000402E28: 02029EFF 83DCD12D
	v_bfe_u32 v81, v78, 9, 16                                  // 000000402E30: D6100051 0241134E
	.long 0xd72c0049                                           // 000000402E38: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000402E3C: 020292FF 83DCD12D
	v_dot2acc_f32_f16 v45, v71, v12                            // 000000402E44: 045A1947
	v_bfe_u32 v85, v78, 3, 16                                  // 000000402E48: D6100055 0241074E
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000402E50: D622004A 03FD014A 00006400
	.long 0xd72c0051                                           // 000000402E5C: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000402E60: 0202A2FF 83DCD12D
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000402E68: D622004C 03FD014C 00006400
	v_sad_u8 v79, v79, 0, 0x6400                               // 000000402E74: D622004F 03FD014F 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000402E80: BF870224
	v_and_b32_e32 v74, 0xffff, v74                             // 000000402E84: 369494FF 0000FFFF
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000402E8C: D6220049 03FD0149 00006400
	v_lshlrev_b32_e32 v76, 16, v76                             // 000000402E98: 30989890
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000402E9C: D6220051 03FD0151 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000402EA8: BF870194
	v_lshl_or_b32 v74, v79, 16, v74                            // 000000402EAC: D656004A 0529214F
	v_and_or_b32 v73, 0xffff, v73, v76                         // 000000402EB4: D6570049 053292FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000402EC0: BF870193
	v_and_b32_e32 v76, 0xffff, v81                             // 000000402EC4: 3698A2FF 0000FFFF
	v_pk_fma_f16 v74, v74, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000402ECC: CC0E004A 0BFC0B4A 0000C931
	v_dot2acc_f32_f16 v44, v84, v2                             // 000000402ED8: 04580554
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000402EDC: BF870194
	v_pk_fma_f16 v81, v73, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000402EE0: CC0E0051 0BFC0B49 0000C931
	v_dot2acc_f32_f16 v47, v74, v5                             // 000000402EEC: 045E0B4A
	v_dot2acc_f32_f16 v49, v74, v9                             // 000000402EF0: 0462134A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000402EF4: BF870224
	v_dot2acc_f32_f16 v44, v82, v3                             // 000000402EF8: 04580752
	v_dot2acc_f32_f16 v48, v74, v1                             // 000000402EFC: 0460034A
	v_dual_dot2acc_f32_f16 v50, v74, v13 :: v_dual_dot2acc_f32_f16 v47, v81, v6// 000000402F00: CB181B4A 322E0D51
	v_dot2acc_f32_f16 v42, v83, v16                            // 000000402F08: 04542153
	v_bfe_u32 v83, v78, 6, 16                                  // 000000402F0C: D6100053 02410D4E
	v_dual_dot2acc_f32_f16 v44, v71, v4 :: v_dual_dot2acc_f32_f16 v49, v81, v10// 000000402F14: CB180947 2C301551
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000402F1C: BF870092
	.long 0xd72c0053                                           // 000000402F20: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000402F24: 0202A6FF 83DCD12D
	v_sad_u8 v79, v83, 0, 0x6400                               // 000000402F2C: D622004F 03FD0153 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000402F38: BF870091
	v_lshl_or_b32 v76, v79, 16, v76                            // 000000402F3C: D656004C 0531214F
	v_pk_fma_f16 v76, v76, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000402F44: CC0E004C 0BFC0B4C 0000C931
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000402F50: BF870241
	v_dual_dot2acc_f32_f16 v49, v76, v11 :: v_dual_and_b32 v78, 0xffff, v78// 000000402F54: CB24174C 314E9CFF 0000FFFF
	v_dot2acc_f32_f16 v46, v84, v14                            // 000000402F60: 045C1D54
	.long 0xd72c0054                                           // 000000402F64: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 000000402F68: 0202AAFF 83DCD12D
	v_dot2acc_f32_f16 v47, v76, v7                             // 000000402F70: 045E0F4C
	.long 0xd72c004e                                           // 000000402F74: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000402F78: 02029CFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000402F80: BF870214
	v_dot2acc_f32_f16 v46, v82, v15                            // 000000402F84: 045C1F52
	v_sad_u8 v73, v84, 0, 0x6400                               // 000000402F88: D6220049 03FD0154 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000402F94: BF870212
	v_dot2acc_f32_f16 v46, v71, v16                            // 000000402F98: 045C2147
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000402F9C: D622004E 03FD014E 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000402FA8: BF870091
	v_lshlrev_b32_e32 v78, 16, v78                             // 000000402FAC: 309C9C90
	v_and_or_b32 v73, 0xffff, v73, v78                         // 000000402FB0: D6570049 053A92FF 0000FFFF
	v_mov_b32_e32 v78, v80                                     // 000000402FBC: 7E9C0350
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000402FC0: BF870122
	v_pk_fma_f16 v79, v73, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000402FC4: CC0E004F 0BFC0B49 0000C931
	v_mov_b32_e32 v73, v75                                     // 000000402FD0: 7E92034B
	v_dot2acc_f32_f16 v47, v79, v8                             // 000000402FD4: 045E114F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000402FD8: BF8701B2
	.long 0xd73d0047                                           // 000000402FDC: D73D0047
	v_cndmask_b32_e32 v1, v61, v72, vcc_lo                     // 000000402FE0: 0202913D
	.long 0xd73d0048                                           // 000000402FE4: D73D0048
	v_cndmask_b32_e32 v1, v62, v77, vcc_lo                     // 000000402FE8: 02029B3E
	v_dot2acc_f32_f16 v49, v79, v12                            // 000000402FEC: 0462194F
	v_bfe_u32 v74, v71, 9, 16                                  // 000000402FF0: D610004A 02411347
	v_and_b32_e32 v75, 0xffff, v71                             // 000000402FF8: 36968EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000403000: BF870004
	v_bfe_u32 v77, v72, 9, 16                                  // 000000403004: D610004D 02411348
	v_bfe_u32 v78, v72, 6, 16                                  // 00000040300C: D610004E 02410D48
	v_bfe_u32 v80, v72, 3, 16                                  // 000000403014: D6100050 02410748
	.long 0xd72c0049                                           // 00000040301C: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000403020: 020294FF 83DCD12D
	v_bfe_u32 v74, v71, 6, 16                                  // 000000403028: D610004A 02410D47
	v_bfe_u32 v71, v71, 3, 16                                  // 000000403030: D6100047 02410747
	.long 0xd72c004b                                           // 000000403038: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 00000040303C: 020296FF 83DCD12D
	.long 0xd72c004d                                           // 000000403044: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000403048: 02029AFF 83DCD12D
	v_and_b32_e32 v72, 0xffff, v72                             // 000000403050: 369090FF 0000FFFF
	.long 0xd72c004a                                           // 000000403058: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 00000040305C: 020294FF 83DCD12D
	.long 0xd72c0047                                           // 000000403064: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000403068: 02028EFF 83DCD12D
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000403070: D6220049 03FD0149 00006400
	.long 0xd72c004e                                           // 00000040307C: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000403080: 02029CFF 83DCD12D
	.long 0xd72c0048                                           // 000000403088: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 00000040308C: 020290FF 83DCD12D
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000403094: D622004B 03FD014B 00006400
	v_sad_u8 v77, v77, 0, 0x6400                               // 0000004030A0: D622004D 03FD014D 00006400
	v_and_b32_e32 v73, 0xffff, v73                             // 0000004030AC: 369292FF 0000FFFF
	v_sad_u8 v74, v74, 0, 0x6400                               // 0000004030B4: D622004A 03FD014A 00006400
	v_sad_u8 v71, v71, 0, 0x6400                               // 0000004030C0: D6220047 03FD0147 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000004030CC: BF870224
	v_and_b32_e32 v77, 0xffff, v77                             // 0000004030D0: 369A9AFF 0000FFFF
	v_sad_u8 v78, v78, 0, 0x6400                               // 0000004030D8: D622004E 03FD014E 00006400
	v_lshl_or_b32 v73, v74, 16, v73                            // 0000004030E4: D6560049 0525214A
	v_lshlrev_b32_e32 v74, 16, v75                             // 0000004030EC: 30949690
	.long 0xd72c004b                                           // 0000004030F0: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 0000004030F4: 0202A0FF 83DCD12D
	v_sad_u8 v72, v72, 0, 0x6400                               // 0000004030FC: D6220048 03FD0148 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000403108: BF870214
	v_pk_fma_f16 v73, v73, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000040310C: CC0E0049 0BFC0B49 0000C931
	v_and_or_b32 v71, 0xffff, v71, v74                         // 000000403118: D6570047 052A8EFF 0000FFFF
	v_lshl_or_b32 v74, v78, 16, v77                            // 000000403124: D656004A 0535214E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000040312C: BF870193
	v_dual_dot2acc_f32_f16 v53, v73, v9 :: v_dual_lshlrev_b32 v72, 16, v72// 000000403130: CB221349 35489090
	v_pk_fma_f16 v71, v71, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000403138: CC0E0047 0BFC0B47 0000C931
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000403144: D622004B 03FD014B 00006400
	v_dot2acc_f32_f16 v51, v73, v5                             // 000000403150: 04660B49
	v_pk_fma_f16 v74, v74, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000403154: CC0E004A 0BFC0B4A 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000403160: BF870244
	v_dual_dot2acc_f32_f16 v52, v73, v1 :: v_dual_dot2acc_f32_f16 v53, v71, v10// 000000403164: CB180349 34341547
	v_dot2acc_f32_f16 v48, v81, v2                             // 00000040316C: 04600551
	v_and_or_b32 v5, 0xffff, v75, v72                          // 000000403170: D6570005 052296FF 0000FFFF
	v_dot2acc_f32_f16 v51, v71, v6                             // 00000040317C: 04660D47
	v_dual_dot2acc_f32_f16 v23, v73, v13 :: v_dual_dot2acc_f32_f16 v52, v71, v2// 000000403180: CB181B49 17340547
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000403188: BF870214
	v_dot2acc_f32_f16 v48, v76, v3                             // 00000040318C: 0460074C
	v_pk_fma_f16 v1, v5, s5, 0xc931 op_sel_hi:[1,0,0]          // 000000403190: CC0E0001 0BFC0B05 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000040319C: BF870214
	v_dot2acc_f32_f16 v51, v74, v7                             // 0000004031A0: 04660F4A
	v_dual_dot2acc_f32_f16 v23, v71, v14 :: v_dual_add_nc_u32 v2, v64, v65// 0000004031A4: CB201D47 17028340
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004031AC: BF870194
	v_dual_dot2acc_f32_f16 v48, v79, v4 :: v_dual_dot2acc_f32_f16 v53, v74, v11// 0000004031B0: CB18094F 3034174A
	v_dot2acc_f32_f16 v51, v1, v8                              // 0000004031B8: 04661101
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000004031BC: BF8701B3
	v_dual_dot2acc_f32_f16 v50, v81, v14 :: v_dual_dot2acc_f32_f16 v23, v74, v15// 0000004031C0: CB181D51 32161F4A
	v_dot2acc_f32_f16 v52, v74, v3                             // 0000004031C8: 0468074A
	v_cmp_eq_u32_e32 vcc_lo, 1, v2                             // 0000004031CC: 7C940481
	v_dual_dot2acc_f32_f16 v53, v1, v12 :: v_dual_dot2acc_f32_f16 v50, v76, v15// 0000004031D0: CB181901 35321F4C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004031D8: BF870214
	v_dot2acc_f32_f16 v23, v1, v16                             // 0000004031DC: 042E2101
	v_dot2acc_f32_f16 v52, v1, v4                              // 0000004031E0: 04680901
	s_or_b32 s4, vcc_lo, s4                                    // 0000004031E4: 8C04046A
	s_delay_alu instid0(VALU_DEP_3)                            // 0000004031E8: BF870003
	v_dot2acc_f32_f16 v50, v79, v16                            // 0000004031EC: 0464214F
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000004031F0: 917E047E
	s_cbranch_execz 27                                         // 0000004031F4: BFA5001B <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1e64>
	s_mov_b32 s2, exec_lo                                      // 0000004031F8: BE82007E
	s_waitcnt vmcnt(4)                                         // 0000004031FC: BF8913F7
	ds_store_2addr_b32 v66, v55, v56 offset1:32                // 000000403200: D8382000 00383742
	s_waitcnt vmcnt(2)                                         // 000000403208: BF890BF7
	ds_store_2addr_b32 v66, v57, v58 offset0:64 offset1:96     // 00000040320C: D8386040 003A3942
	s_waitcnt vmcnt(0)                                         // 000000403214: BF8903F7
	ds_store_2addr_b32 v66, v59, v60 offset0:128 offset1:160   // 000000403218: D838A080 003C3B42
	.long 0xd4c1007e                                           // 000000403220: D4C1007E
	v_cndmask_b32_e32 v1, v65, v54, vcc_lo                     // 000000403224: 02026D41
	s_cbranch_execz 64473                                      // 000000403228: BFA5FBD9 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0xd90>
	s_clause 0x5                                               // 00000040322C: BF850005
	global_load_b32 v55, v[17:18], off                         // 000000403230: DC520000 377C0011
	global_load_b32 v56, v[17:18], off offset:128              // 000000403238: DC520080 387C0011
	global_load_b32 v57, v[17:18], off offset:256              // 000000403240: DC520100 397C0011
	global_load_b32 v58, v[17:18], off offset:384              // 000000403248: DC520180 3A7C0011
	global_load_b32 v59, v[17:18], off offset:512              // 000000403250: DC520200 3B7C0011
	global_load_b32 v60, v[17:18], off offset:640              // 000000403258: DC520280 3C7C0011
	s_branch 64459                                             // 000000403260: BFA0FBCB <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0xd90>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000403264: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000403268: BF870009
	s_or_b32 exec_lo, exec_lo, s3                              // 00000040326C: 8C7E037E
	v_dual_mov_b32 v1, v22 :: v_dual_mov_b32 v4, v27           // 000000403270: CA100116 0104011B
	v_dual_mov_b32 v2, v26 :: v_dual_mov_b32 v3, v25           // 000000403278: CA10011A 02020119
	v_dual_mov_b32 v5, v28 :: v_dual_mov_b32 v8, v30           // 000000403280: CA10011C 0508011E
	v_dual_mov_b32 v7, v29 :: v_dual_mov_b32 v6, v24           // 000000403288: CA10011D 07060118
	v_dual_mov_b32 v9, v31 :: v_dual_mov_b32 v10, v32          // 000000403290: CA10011F 090A0120
	v_dual_mov_b32 v11, v33 :: v_dual_mov_b32 v12, v34         // 000000403298: CA100121 0B0C0122
	v_dual_mov_b32 v13, v35 :: v_dual_mov_b32 v14, v36         // 0000004032A0: CA100123 0D0E0124
	v_dual_mov_b32 v15, v37 :: v_dual_mov_b32 v16, v38         // 0000004032A8: CA100125 0F100126
	v_dual_mov_b32 v17, v39 :: v_dual_mov_b32 v18, v40         // 0000004032B0: CA100127 11120128
	s_waitcnt vmcnt(5)                                         // 0000004032B8: BF8917F7
	v_dual_mov_b32 v54, v41 :: v_dual_mov_b32 v55, v42         // 0000004032BC: CA100129 3636012A
	s_waitcnt vmcnt(3)                                         // 0000004032C4: BF890FF7
	v_dual_mov_b32 v56, v43 :: v_dual_mov_b32 v57, v44         // 0000004032C8: CA10012B 3838012C
	s_waitcnt vmcnt(1)                                         // 0000004032D0: BF8907F7
	v_dual_mov_b32 v58, v45 :: v_dual_mov_b32 v59, v46         // 0000004032D4: CA10012D 3A3A012E
	s_waitcnt vmcnt(0)                                         // 0000004032DC: BF8903F7
	v_dual_mov_b32 v60, v47 :: v_dual_mov_b32 v61, v48         // 0000004032E0: CA10012F 3C3C0130
	v_dual_mov_b32 v62, v49 :: v_dual_mov_b32 v63, v50         // 0000004032E8: CA100131 3E3E0132
	v_dual_mov_b32 v64, v51 :: v_dual_mov_b32 v65, v52         // 0000004032F0: CA100133 40400134
	v_dual_mov_b32 v66, v53 :: v_dual_mov_b32 v67, v23         // 0000004032F8: CA100135 42420117
	s_mov_b32 s2, 0x76543210                                   // 000000403300: BE8200FF 76543210
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000403308: BF870009
	v_permlanex16_b32 v1, v1, s2, 0xfedcba98                   // 00000040330C: D65C0001 03FC0501 FEDCBA98
	v_permlanex16_b32 v2, v2, s2, 0xfedcba98                   // 000000403318: D65C0002 03FC0502 FEDCBA98
	v_permlanex16_b32 v4, v4, s2, 0xfedcba98                   // 000000403324: D65C0004 03FC0504 FEDCBA98
	v_permlanex16_b32 v3, v3, s2, 0xfedcba98                   // 000000403330: D65C0003 03FC0503 FEDCBA98
	v_permlanex16_b32 v5, v5, s2, 0xfedcba98                   // 00000040333C: D65C0005 03FC0505 FEDCBA98
	v_permlanex16_b32 v7, v7, s2, 0xfedcba98                   // 000000403348: D65C0007 03FC0507 FEDCBA98
	v_permlanex16_b32 v8, v8, s2, 0xfedcba98                   // 000000403354: D65C0008 03FC0508 FEDCBA98
	v_permlanex16_b32 v9, v9, s2, 0xfedcba98                   // 000000403360: D65C0009 03FC0509 FEDCBA98
	v_permlanex16_b32 v6, v6, s2, 0xfedcba98                   // 00000040336C: D65C0006 03FC0506 FEDCBA98
	v_permlanex16_b32 v10, v10, s2, 0xfedcba98                 // 000000403378: D65C000A 03FC050A FEDCBA98
	v_permlanex16_b32 v11, v11, s2, 0xfedcba98                 // 000000403384: D65C000B 03FC050B FEDCBA98
	v_permlanex16_b32 v12, v12, s2, 0xfedcba98                 // 000000403390: D65C000C 03FC050C FEDCBA98
	v_permlanex16_b32 v13, v13, s2, 0xfedcba98                 // 00000040339C: D65C000D 03FC050D FEDCBA98
	v_permlanex16_b32 v14, v14, s2, 0xfedcba98                 // 0000004033A8: D65C000E 03FC050E FEDCBA98
	v_permlanex16_b32 v15, v15, s2, 0xfedcba98                 // 0000004033B4: D65C000F 03FC050F FEDCBA98
	v_permlanex16_b32 v16, v16, s2, 0xfedcba98                 // 0000004033C0: D65C0010 03FC0510 FEDCBA98
	v_permlanex16_b32 v17, v17, s2, 0xfedcba98                 // 0000004033CC: D65C0011 03FC0511 FEDCBA98
	v_permlanex16_b32 v18, v18, s2, 0xfedcba98                 // 0000004033D8: D65C0012 03FC0512 FEDCBA98
	v_permlanex16_b32 v54, v54, s2, 0xfedcba98                 // 0000004033E4: D65C0036 03FC0536 FEDCBA98
	v_permlanex16_b32 v55, v55, s2, 0xfedcba98                 // 0000004033F0: D65C0037 03FC0537 FEDCBA98
	v_permlanex16_b32 v56, v56, s2, 0xfedcba98                 // 0000004033FC: D65C0038 03FC0538 FEDCBA98
	v_permlanex16_b32 v57, v57, s2, 0xfedcba98                 // 000000403408: D65C0039 03FC0539 FEDCBA98
	v_permlanex16_b32 v58, v58, s2, 0xfedcba98                 // 000000403414: D65C003A 03FC053A FEDCBA98
	v_permlanex16_b32 v59, v59, s2, 0xfedcba98                 // 000000403420: D65C003B 03FC053B FEDCBA98
	v_permlanex16_b32 v60, v60, s2, 0xfedcba98                 // 00000040342C: D65C003C 03FC053C FEDCBA98
	v_permlanex16_b32 v61, v61, s2, 0xfedcba98                 // 000000403438: D65C003D 03FC053D FEDCBA98
	v_permlanex16_b32 v62, v62, s2, 0xfedcba98                 // 000000403444: D65C003E 03FC053E FEDCBA98
	v_permlanex16_b32 v63, v63, s2, 0xfedcba98                 // 000000403450: D65C003F 03FC053F FEDCBA98
	v_permlanex16_b32 v64, v64, s2, 0xfedcba98                 // 00000040345C: D65C0040 03FC0540 FEDCBA98
	v_permlanex16_b32 v65, v65, s2, 0xfedcba98                 // 000000403468: D65C0041 03FC0541 FEDCBA98
	v_permlanex16_b32 v66, v66, s2, 0xfedcba98                 // 000000403474: D65C0042 03FC0542 FEDCBA98
	v_permlanex16_b32 v67, v67, s2, 0xfedcba98                 // 000000403480: D65C0043 03FC0543 FEDCBA98
	.long 0xd44c0002                                           // 00000040348C: D44C0002
	v_cndmask_b32_e32 v1, 16, v20, vcc_lo                      // 000000403490: 02022890
	s_barrier                                                  // 000000403494: BFBD0000
	buffer_gl0_inv                                             // 000000403498: E0AC0000 00000000
	s_and_saveexec_b32 s3, s2                                  // 0000004034A0: BE832002
	s_cbranch_execz 68                                         // 0000004034A4: BFA50044 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x21b8>
	v_lshl_or_b32 v21, v19, 11, v21                            // 0000004034A8: D6560015 04551713
	v_dual_add_f32 v5, v28, v5 :: v_dual_add_f32 v4, v27, v4   // 0000004034B0: C9080B1C 0504091B
	v_dual_add_f32 v1, v22, v1 :: v_dual_add_f32 v6, v24, v6   // 0000004034B8: C9080316 01060D18
	v_dual_add_f32 v8, v30, v8 :: v_dual_add_f32 v7, v29, v7   // 0000004034C0: C908111E 08060F1D
	v_dual_add_f32 v2, v26, v2 :: v_dual_add_f32 v3, v25, v3   // 0000004034C8: C908051A 02020719
	v_add_nc_u32_e32 v22, 0x400, v21                           // 0000004034D0: 4A2C2AFF 00000400
	v_dual_add_f32 v10, v32, v10 :: v_dual_add_f32 v9, v31, v9 // 0000004034D8: C9081520 0A08131F
	v_dual_add_f32 v14, v36, v14 :: v_dual_add_f32 v13, v35, v13// 0000004034E0: C9081D24 0E0C1B23
	v_dual_add_f32 v20, v23, v67 :: v_dual_add_f32 v23, v53, v66// 0000004034E8: C9088717 14168535
	v_dual_add_f32 v52, v52, v65 :: v_dual_add_f32 v51, v51, v64// 0000004034F0: C9088334 34328133
	v_dual_add_f32 v50, v50, v63 :: v_dual_add_f32 v49, v49, v62// 0000004034F8: C9087F32 32307D31
	v_dual_add_f32 v48, v48, v61 :: v_dual_add_f32 v47, v47, v60// 000000403500: C9087B30 302E792F
	v_dual_add_f32 v46, v46, v59 :: v_dual_add_f32 v45, v45, v58// 000000403508: C908772E 2E2C752D
	v_dual_add_f32 v44, v44, v57 :: v_dual_add_f32 v43, v43, v56// 000000403510: C908732C 2C2A712B
	v_dual_add_f32 v42, v42, v55 :: v_dual_add_f32 v41, v41, v54// 000000403518: C9086F2A 2A286D29
	v_dual_add_f32 v18, v40, v18 :: v_dual_add_f32 v17, v39, v17// 000000403520: C9082528 12102327
	v_dual_add_f32 v16, v38, v16 :: v_dual_add_f32 v15, v37, v15// 000000403528: C9082126 100E1F25
	v_dual_add_f32 v12, v34, v12 :: v_dual_add_f32 v11, v33, v11// 000000403530: C9081922 0C0A1721
	ds_store_2addr_b32 v21, v1, v5 offset1:16                  // 000000403538: D8381000 00050115
	ds_store_2addr_b32 v21, v2, v7 offset0:128 offset1:144     // 000000403540: D8389080 00070215
	ds_store_2addr_b32 v22, v4, v8 offset1:16                  // 000000403548: D8381000 00080416
	ds_store_2addr_b32 v22, v3, v9 offset0:128 offset1:144     // 000000403550: D8389080 00090316
	ds_store_2addr_b32 v21, v6, v13 offset0:32 offset1:48      // 000000403558: D8383020 000D0615
	ds_store_2addr_b32 v21, v10, v14 offset0:160 offset1:176   // 000000403560: D838B0A0 000E0A15
	ds_store_2addr_b32 v22, v11, v15 offset0:32 offset1:48     // 000000403568: D8383020 000F0B16
	ds_store_2addr_b32 v22, v12, v16 offset0:160 offset1:176   // 000000403570: D838B0A0 00100C16
	ds_store_2addr_b32 v21, v17, v43 offset0:64 offset1:80     // 000000403578: D8385040 002B1115
	ds_store_2addr_b32 v21, v18, v44 offset0:192 offset1:208   // 000000403580: D838D0C0 002C1215
	ds_store_2addr_b32 v22, v41, v45 offset0:64 offset1:80     // 000000403588: D8385040 002D2916
	ds_store_2addr_b32 v22, v42, v46 offset0:192 offset1:208   // 000000403590: D838D0C0 002E2A16
	ds_store_2addr_b32 v21, v47, v51 offset0:96 offset1:112    // 000000403598: D8387060 00332F15
	ds_store_2addr_b32 v21, v48, v52 offset0:224 offset1:240   // 0000004035A0: D838F0E0 00343015
	ds_store_2addr_b32 v22, v49, v23 offset0:96 offset1:112    // 0000004035A8: D8387060 00173116
	ds_store_2addr_b32 v22, v50, v20 offset0:224 offset1:240   // 0000004035B0: D838F0E0 00143216
	s_or_b32 exec_lo, exec_lo, s3                              // 0000004035B8: 8C7E037E
	.long 0xd44c0003                                           // 0000004035BC: D44C0003
	v_cndmask_b32_e32 v1, 0x200, v0, vcc_lo                    // 0000004035C0: 020200FF 00000200
	s_waitcnt lgkmcnt(0)                                       // 0000004035C8: BF89FC07
	s_barrier                                                  // 0000004035CC: BFBD0000
	buffer_gl0_inv                                             // 0000004035D0: E0AC0000 00000000
	s_and_saveexec_b32 s4, s3                                  // 0000004035D8: BE842003
	s_cbranch_execz 43                                         // 0000004035DC: BFA5002B <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x228c>
	v_mov_b32_e32 v1, v0                                       // 0000004035E0: 7E020300
	s_mov_b32 s5, 0                                            // 0000004035E4: BE850080
	s_nop 0                                                    // 0000004035E8: BF800000
	s_nop 0                                                    // 0000004035EC: BF800000
	s_nop 0                                                    // 0000004035F0: BF800000
	s_nop 0                                                    // 0000004035F4: BF800000
	s_nop 0                                                    // 0000004035F8: BF800000
	s_nop 0                                                    // 0000004035FC: BF800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000403600: BF870001
	v_lshlrev_b32_e32 v8, 2, v1                                // 000000403604: 30100282
	v_cmp_lt_u32_e32 vcc_lo, 0xff, v1                          // 000000403608: 7C9202FF 000000FF
	ds_load_2addr_stride64_b32 v[2:3], v8 offset1:8            // 000000403610: D8E00800 02000008
	ds_load_2addr_stride64_b32 v[4:5], v8 offset0:16 offset1:24// 000000403618: D8E01810 04000008
	ds_load_2addr_stride64_b32 v[6:7], v8 offset0:32 offset1:40// 000000403620: D8E02820 06000008
	s_or_b32 s5, vcc_lo, s5                                    // 000000403628: 8C05056A
	s_waitcnt lgkmcnt(2)                                       // 00000040362C: BF89FC27
	v_add_f32_e32 v2, 0, v2                                    // 000000403630: 06040480
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000403634: BF8700C1
	v_add_f32_e32 v9, v2, v3                                   // 000000403638: 06120702
	ds_load_2addr_stride64_b32 v[2:3], v8 offset0:48 offset1:56// 00000040363C: D8E03830 02000008
	s_waitcnt lgkmcnt(2)                                       // 000000403644: BF89FC27
	v_add_f32_e32 v4, v9, v4                                   // 000000403648: 06080909
	v_add_f32_e32 v4, v4, v5                                   // 00000040364C: 06080B04
	s_waitcnt lgkmcnt(1)                                       // 000000403650: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000403654: BF870091
	v_add_f32_e32 v4, v4, v6                                   // 000000403658: 06080D04
	v_add_f32_e32 v4, v4, v7                                   // 00000040365C: 06080F04
	s_waitcnt lgkmcnt(0)                                       // 000000403660: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000403664: BF8700A1
	v_add_f32_e32 v2, v4, v2                                   // 000000403668: 06040504
	v_add_nc_u32_e32 v4, 0x100, v1                             // 00000040366C: 4A0802FF 00000100
	v_dual_add_f32 v2, v2, v3 :: v_dual_mov_b32 v1, v4         // 000000403674: C9100702 02000104
	ds_store_b32 v8, v2 offset:16384                           // 00000040367C: D8344000 00000208
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 000000403684: 917E057E
	s_cbranch_execnz 65501                                     // 000000403688: BFA6FFDD <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2200>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000040368C: 8C7E047E
	s_cmp_lt_i32 s21, 2                                        // 000000403690: BF048215
	s_mov_b32 s4, -1                                           // 000000403694: BE8400C1
	s_cbranch_scc1 243                                         // 000000403698: BFA200F3 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2668>
	s_load_b128 s[4:7], s[0:1], 0x1a8                          // 00000040369C: F4080100 F80001A8
	s_waitcnt lgkmcnt(0)                                       // 0000004036A4: BF89FC07
	s_barrier                                                  // 0000004036A8: BFBD0000
	buffer_gl0_inv                                             // 0000004036AC: E0AC0000 00000000
	s_and_saveexec_b32 s8, s3                                  // 0000004036B4: BE882003
	s_cbranch_execz 85                                         // 0000004036B8: BFA50055 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2410>
	v_lshrrev_b32_e32 v1, 7, v0                                // 0000004036BC: 32020087
	s_ashr_i32 s35, s34, 31                                    // 0000004036C0: 86239F22
	s_ashr_i32 s37, s36, 31                                    // 0000004036C4: 86259F24
	s_lshl_b64 s[0:1], s[34:35], 2                             // 0000004036C8: 84808222
	s_lshl_b32 s10, s26, 7                                     // 0000004036CC: 840A871A
	v_or_b32_e32 v1, s0, v1                                    // 0000004036D0: 38020200
	v_mov_b32_e32 v2, s1                                       // 0000004036D4: 7E040201
	s_lshl_b64 s[0:1], s[36:37], 2                             // 0000004036D8: 84808224
	s_ashr_i32 s11, s10, 31                                    // 0000004036DC: 860B9F0A
	s_lshl_b64 s[16:17], s[28:29], 2                           // 0000004036E0: 8490821C
	.long 0xd7016a01                                           // 0000004036E4: D7016A01
	v_cndmask_b32_e32 v0, v1, v0, vcc_lo                       // 0000004036E8: 02000101
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004036EC: BF870001
	v_subrev_co_ci_u32_e64 v2, null, s1, v2, vcc_lo            // 0000004036F0: D5227C02 01AA0401
	s_ashr_i32 s1, s20, 31                                     // 0000004036F8: 86019F14
	s_lshl_b64 s[10:11], s[10:11], 2                           // 0000004036FC: 848A820A
	.long 0xd72c0004                                           // 000000403700: D72C0004
	v_cndmask_b32_e32 v0, v1, v1, vcc_lo                       // 000000403704: 02000301
	.long 0xd72c0003                                           // 000000403708: D72C0003
	v_cndmask_b32_e32 v0, v2, v20, vcc_lo                      // 00000040370C: 02002902
	v_mad_u64_u32 v[1:2], null, v1, s20, 0                     // 000000403710: D6FE7C01 02002901
	s_add_u32 s9, s10, s16                                     // 000000403718: 8009100A
	s_addc_u32 s10, s11, s17                                   // 00000040371C: 820A110B
	s_mov_b32 s0, s20                                          // 000000403720: BE800014
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000403724: BF870139
	s_lshl_b64 s[0:1], s[0:1], 3                               // 000000403728: 84808300
	v_add3_u32 v2, v2, v4, v3                                  // 00000040372C: D6550002 040E0902
	v_and_b32_e32 v3, 0x7f, v0                                 // 000000403734: 360600FF 0000007F
	.long 0xd73c0001                                           // 00000040373C: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000403740: 02020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000403744: BF8701A2
	v_lshlrev_b32_e32 v4, 2, v3                                // 000000403748: 30080682
	v_lshlrev_b32_e32 v3, 2, v0                                // 00000040374C: 30060082
	.long 0xd7006a01                                           // 000000403750: D7006A01
	v_cndmask_b32_e32 v1, s9, v1, vcc_lo                       // 000000403754: 02020209
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000403758: BF8700B1
	v_add_co_ci_u32_e64 v2, null, s10, v2, vcc_lo              // 00000040375C: D5207C02 01AA040A
	s_mov_b32 s9, 0                                            // 000000403764: BE890080
	.long 0xd7006a01                                           // 000000403768: D7006A01
	v_cndmask_b32_e32 v1, v1, v4, vcc_lo                       // 00000040376C: 02020901
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 000000403770: D5207C02 01AA0480
	v_or_b32_e32 v4, 0xffffff00, v0                            // 000000403778: 380800FF FFFFFF00
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000403780: BF870093
	.long 0xd7006a01                                           // 000000403784: D7006A01
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 000000403788: 02020204
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 00000040378C: D5207C02 01AA0405
	s_nop 0                                                    // 000000403794: BF800000
	s_nop 0                                                    // 000000403798: BF800000
	s_nop 0                                                    // 00000040379C: BF800000
	s_nop 0                                                    // 0000004037A0: BF800000
	s_nop 0                                                    // 0000004037A4: BF800000
	s_nop 0                                                    // 0000004037A8: BF800000
	s_nop 0                                                    // 0000004037AC: BF800000
	s_nop 0                                                    // 0000004037B0: BF800000
	s_nop 0                                                    // 0000004037B4: BF800000
	s_nop 0                                                    // 0000004037B8: BF800000
	s_nop 0                                                    // 0000004037BC: BF800000
	ds_load_b32 v5, v3 offset:16384                            // 0000004037C0: D8D84000 05000003
	.long 0xd7000a04                                           // 0000004037C8: D7000A04
	v_cndmask_b32_e32 v1, 0x100, v4, vcc_lo                    // 0000004037CC: 020208FF 00000100
	s_xor_b32 s10, s10, -1                                     // 0000004037D4: 8D0AC10A
	v_add_nc_u32_e32 v3, 0x400, v3                             // 0000004037D8: 4A0606FF 00000400
	s_and_b32 s10, exec_lo, s10                                // 0000004037E0: 8B0A0A7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000004037E4: BF8700C9
	s_or_b32 s9, s10, s9                                       // 0000004037E8: 8C09090A
	s_waitcnt lgkmcnt(0)                                       // 0000004037EC: BF89FC07
	global_store_b32 v[1:2], v5, off                           // 0000004037F0: DC6A0000 007C0501
	.long 0xd7006a01                                           // 0000004037F8: D7006A01
	v_cndmask_b32_e32 v0, v1, v0, vcc_lo                       // 0000004037FC: 02000101
	v_add_co_ci_u32_e64 v2, null, s1, v2, vcc_lo               // 000000403800: D5207C02 01AA0401
	s_and_not1_b32 exec_lo, exec_lo, s9                        // 000000403808: 917E097E
	s_cbranch_execnz 65516                                     // 00000040380C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x23c0>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000403810: 8C7E087E
	s_ashr_i32 s31, s30, 31                                    // 000000403814: 861F9F1E
	.long 0xd44a0000                                           // 000000403818: D44A0000
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 00000040381C: 02020080
	s_lshl_b64 s[8:9], s[30:31], 2                             // 000000403820: 8488821E
	s_waitcnt_vscnt null, 0x0                                  // 000000403824: BC7C0000
	buffer_gl1_inv                                             // 000000403828: E0B00000 00000000
	buffer_gl0_inv                                             // 000000403830: E0AC0000 00000000
	s_add_u32 s8, s6, s8                                       // 000000403838: 80080806
	s_addc_u32 s9, s7, s9                                      // 00000040383C: 82090907
	s_barrier                                                  // 000000403840: BFBD0000
	buffer_gl0_inv                                             // 000000403844: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 00000040384C: BE812000
	s_cbranch_execz 29                                         // 000000403850: BFA5001D <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x24c8>
	s_mov_b32 s7, exec_lo                                      // 000000403854: BE87007E
	s_mov_b32 s6, exec_lo                                      // 000000403858: BE86007E
	.long 0xd71f0001                                           // 00000040385C: D71F0001
	v_cndmask_b32_e32 v0, s7, v128, vcc_lo                     // 000000403860: 02010007
	s_delay_alu instid0(VALU_DEP_1)                            // 000000403864: BF870001
	v_cmpx_eq_u32_e32 0, v1                                    // 000000403868: 7D940280
	s_cbranch_execz 9                                          // 00000040386C: BFA50009 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2494>
	s_lshl_b64 s[10:11], s[26:27], 2                           // 000000403870: 848A821A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000403874: BF8704B9
	s_add_u32 s10, s8, s10                                     // 000000403878: 800A0A08
	s_addc_u32 s11, s9, s11                                    // 00000040387C: 820B0B09
	s_bcnt1_i32_b32 s7, s7                                     // 000000403880: BE871807
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, s7              // 000000403884: CA100080 02020007
	global_atomic_add_u32 v2, v2, v3, s[10:11] glc             // 00000040388C: DCD64000 020A0302
	s_or_b32 exec_lo, exec_lo, s6                              // 000000403894: 8C7E067E
	s_waitcnt vmcnt(0)                                         // 000000403898: BF8903F7
	v_readfirstlane_b32 s6, v2                                 // 00000040389C: 7E0C0502
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004038A0: BF870001
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s6, v1       // 0000004038A4: CA200080 02000206
	s_add_i32 s6, s21, -1                                      // 0000004038AC: 8106C115
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000004038B0: BF870481
	v_cmp_eq_u32_e32 vcc_lo, s6, v1                            // 0000004038B4: 7C940206
	v_cndmask_b32_e64 v1, 0, 1, vcc_lo                         // 0000004038B8: D5010001 01A90280
	ds_store_b32 v2, v1 offset:26880                           // 0000004038C0: D8346900 00000102
	s_or_b32 exec_lo, exec_lo, s1                              // 0000004038C8: 8C7E017E
	v_mov_b32_e32 v1, 0                                        // 0000004038CC: 7E020280
	s_waitcnt lgkmcnt(0)                                       // 0000004038D0: BF89FC07
	s_barrier                                                  // 0000004038D4: BFBD0000
	buffer_gl0_inv                                             // 0000004038D8: E0AC0000 00000000
	ds_load_b32 v1, v1 offset:26880                            // 0000004038E0: D8D86900 01000001
	s_waitcnt lgkmcnt(0)                                       // 0000004038E8: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 0000004038EC: 7C940280
	s_cbranch_vccnz 928                                        // 0000004038F0: BFA403A0 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3374>
	buffer_gl1_inv                                             // 0000004038F4: E0B00000 00000000
	buffer_gl0_inv                                             // 0000004038FC: E0AC0000 00000000
	s_and_saveexec_b32 s10, s3                                 // 000000403904: BE8A2003
	s_cbranch_execz 76                                         // 000000403908: BFA5004C <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x263c>
	v_lshrrev_b32_e32 v1, 7, v0                                // 00000040390C: 32020087
	s_lshl_b32 s16, s26, 7                                     // 000000403910: 8410871A
	v_and_b32_e32 v3, 0x7f, v0                                 // 000000403914: 360600FF 0000007F
	s_ashr_i32 s17, s16, 31                                    // 00000040391C: 86119F10
	s_lshl_b64 s[22:23], s[28:29], 2                           // 000000403920: 8496821C
	v_mad_i64_i32 v[1:2], null, v1, s20, 0                     // 000000403924: D6FF7C01 02002901
	s_lshl_b64 s[16:17], s[16:17], 2                           // 00000040392C: 84908210
	s_ashr_i32 s7, s20, 31                                     // 000000403930: 86079F14
	s_add_u32 s1, s16, s22                                     // 000000403934: 80011610
	v_lshlrev_b32_e32 v3, 2, v3                                // 000000403938: 30060682
	s_addc_u32 s3, s17, s23                                    // 00000040393C: 82031711
	v_mov_b32_e32 v5, v0                                       // 000000403940: 7E0A0300
	s_mov_b32 s6, s20                                          // 000000403944: BE860014
	.long 0xd73c0001                                           // 000000403948: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000040394C: 02020282
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000403950: BF870091
	.long 0xd7006a01                                           // 000000403954: D7006A01
	v_cndmask_b32_e32 v1, s1, v1, vcc_lo                       // 000000403958: 02020201
	v_add_co_ci_u32_e64 v2, null, s3, v2, vcc_lo               // 00000040395C: D5207C02 01AA0403
	s_mov_b32 s3, 0                                            // 000000403964: BE830080
	.long 0xd7006a01                                           // 000000403968: D7006A01
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 00000040396C: 02020701
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000403970: BF870111
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 000000403974: D5207C02 01AA0480
	.long 0xd7006a01                                           // 00000040397C: D7006A01
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 000000403980: 02020204
	s_delay_alu instid0(VALU_DEP_1)                            // 000000403984: BF870001
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 000000403988: D5207C02 01AA0405
	s_lshl_b64 s[4:5], s[6:7], 3                               // 000000403990: 84848306
	s_lshl_b64 s[6:7], s[6:7], 4                               // 000000403994: 84868406
	s_nop 0                                                    // 000000403998: BF800000
	s_nop 0                                                    // 00000040399C: BF800000
	s_nop 0                                                    // 0000004039A0: BF800000
	s_nop 0                                                    // 0000004039A4: BF800000
	s_nop 0                                                    // 0000004039A8: BF800000
	s_nop 0                                                    // 0000004039AC: BF800000
	s_nop 0                                                    // 0000004039B0: BF800000
	s_nop 0                                                    // 0000004039B4: BF800000
	s_nop 0                                                    // 0000004039B8: BF800000
	s_nop 0                                                    // 0000004039BC: BF800000
	v_dual_mov_b32 v4, v2 :: v_dual_mov_b32 v3, v1             // 0000004039C0: CA100102 04020101
	v_mov_b32_e32 v6, 0                                        // 0000004039C8: 7E0C0280
	s_mov_b32 s1, s21                                          // 0000004039CC: BE810015
	global_load_b32 v7, v[3:4], off glc                        // 0000004039D0: DC524000 077C0003
	.long 0xd7006a03                                           // 0000004039D8: D7006A03
	v_cndmask_b32_e32 v0, v3, v6, vcc_lo                       // 0000004039DC: 02000D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000004039E0: BF8704A1
	v_add_co_ci_u32_e64 v4, null, s7, v4, vcc_lo               // 0000004039E4: D5207C04 01AA0807
	s_add_i32 s1, s1, -1                                       // 0000004039EC: 8101C101
	s_cmp_eq_u32 s1, 0                                         // 0000004039F0: BF068001
	s_waitcnt vmcnt(0)                                         // 0000004039F4: BF8903F7
	v_add_f32_e32 v6, v6, v7                                   // 0000004039F8: 060C0F06
	s_cbranch_scc0 65524                                       // 0000004039FC: BFA1FFF4 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x25d0>
	v_add_nc_u32_e32 v4, 0x100, v5                             // 000000403A00: 4A080AFF 00000100
	v_cmp_lt_u32_e32 vcc_lo, 0xff, v5                          // 000000403A08: 7C920AFF 000000FF
	.long 0xd7000101                                           // 000000403A10: D7000101
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 000000403A14: 02000901
	v_lshlrev_b32_e32 v3, 2, v5                                // 000000403A18: 30060A82
	v_add_co_ci_u32_e64 v2, null, s5, v2, s1                   // 000000403A1C: D5207C02 00060405
	v_mov_b32_e32 v5, v4                                       // 000000403A24: 7E0A0304
	s_or_b32 s3, vcc_lo, s3                                    // 000000403A28: 8C03036A
	ds_store_b32 v3, v6 offset:16384                           // 000000403A2C: D8344000 00000603
	s_and_not1_b32 exec_lo, exec_lo, s3                        // 000000403A34: 917E037E
	s_cbranch_execnz 65505                                     // 000000403A38: BFA6FFE1 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x25c0>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000403A3C: 8C7E0A7E
	s_and_saveexec_b32 s1, s0                                  // 000000403A40: BE812000
	s_cbranch_execz 6                                          // 000000403A44: BFA50006 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2660>
	s_lshl_b64 s[4:5], s[26:27], 2                             // 000000403A48: 8484821A
	v_mov_b32_e32 v1, 0                                        // 000000403A4C: 7E020280
	s_add_u32 s4, s8, s4                                       // 000000403A50: 80040408
	s_addc_u32 s5, s9, s5                                      // 000000403A54: 82050509
	global_store_b32 v1, v1, s[4:5]                            // 000000403A58: DC6A0000 00040101
	s_or_b32 exec_lo, exec_lo, s1                              // 000000403A60: 8C7E017E
	s_mov_b32 s4, -1                                           // 000000403A64: BE8400C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000403A68: BF870009
	s_and_b32 vcc_lo, exec_lo, s4                              // 000000403A6C: 8B6A047E
	s_cbranch_vccz 63326                                       // 000000403A70: BFA3F75E <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	v_cmp_gt_i32_e32 vcc_lo, s18, v19                          // 000000403A74: 7C882612
	.long 0xd44c0000                                           // 000000403A78: D44C0000
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 000000403A7C: 020200FF 00000080
	s_waitcnt lgkmcnt(0)                                       // 000000403A84: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 000000403A88: BC7C0000
	s_barrier                                                  // 000000403A8C: BFBD0000
	buffer_gl0_inv                                             // 000000403A90: E0AC0000 00000000
	s_and_b32 s0, vcc_lo, s0                                   // 000000403A98: 8B00006A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000403A9C: BF870009
	s_and_saveexec_b32 s1, s0                                  // 000000403AA0: BE812000
	s_cbranch_execz 63313                                      // 000000403AA4: BFA5F751 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	v_and_b32_e32 v1, 15, v0                                   // 000000403AA8: 3602008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000403AAC: BF870091
	v_lshlrev_b32_e32 v2, 2, v1                                // 000000403AB0: 30040282
	v_lshl_or_b32 v2, v19, 9, v2                               // 000000403AB4: D6560002 04091313
	s_delay_alu instid0(VALU_DEP_1)                            // 000000403ABC: BF870001
	v_add_nc_u32_e32 v8, 0x4000, v2                            // 000000403AC0: 4A1004FF 00004000
	ds_load_2addr_b32 v[2:3], v8 offset1:16                    // 000000403AC8: D8DC1000 02000008
	ds_load_2addr_b32 v[4:5], v8 offset0:32 offset1:48         // 000000403AD0: D8DC3020 04000008
	ds_load_2addr_b32 v[6:7], v8 offset0:64 offset1:80         // 000000403AD8: D8DC5040 06000008
	ds_load_2addr_b32 v[8:9], v8 offset0:96 offset1:112        // 000000403AE0: D8DC7060 08000008
	v_and_b32_e32 v10, 1, v0                                   // 000000403AE8: 36140081
	v_and_b32_e32 v11, 2, v0                                   // 000000403AEC: 36160082
	s_waitcnt lgkmcnt(3)                                       // 000000403AF0: BF89FC37
	v_dual_add_f32 v13, v2, v3 :: v_dual_and_b32 v12, 4, v0    // 000000403AF4: C9240702 0D0C0084
	s_waitcnt lgkmcnt(2)                                       // 000000403AFC: BF89FC27
	v_dual_sub_f32 v2, v2, v3 :: v_dual_add_f32 v3, v4, v5     // 000000403B00: C9480702 02020B04
	s_waitcnt lgkmcnt(1)                                       // 000000403B08: BF89FC17
	v_dual_sub_f32 v4, v4, v5 :: v_dual_add_f32 v5, v6, v7     // 000000403B0C: C9480B04 04040F06
	s_waitcnt lgkmcnt(0)                                       // 000000403B14: BF89FC07
	v_dual_sub_f32 v6, v6, v7 :: v_dual_add_f32 v7, v8, v9     // 000000403B18: C9480F06 06061308
	v_dual_sub_f32 v8, v8, v9 :: v_dual_add_f32 v9, v13, v3    // 000000403B20: C9481308 0808070D
	v_sub_f32_e32 v3, v13, v3                                  // 000000403B28: 0806070D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000403B2C: BF870243
	v_dual_add_f32 v13, v2, v4 :: v_dual_add_f32 v14, v5, v7   // 000000403B30: C9080902 0D0E0F05
	v_dual_sub_f32 v2, v2, v4 :: v_dual_sub_f32 v5, v5, v7     // 000000403B38: C94A0902 02040F05
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 000000403B40: 7C941480
	.long 0xd44a0000                                           // 000000403B44: D44A0000
	v_cndmask_b32_e32 v1, 0, v12, vcc_lo                       // 000000403B48: 02021880
	v_dual_add_f32 v7, v9, v14 :: v_dual_add_f32 v4, v6, v8    // 000000403B4C: C9081D09 07041106
	v_sub_f32_e32 v6, v6, v8                                   // 000000403B54: 080C1106
	v_sub_f32_e32 v8, v9, v14                                  // 000000403B58: 08101D09
	s_delay_alu instid0(VALU_DEP_3)                            // 000000403B5C: BF870003
	v_add_f32_e32 v9, v13, v4                                  // 000000403B60: 0612090D
	v_dual_sub_f32 v4, v13, v4 :: v_dual_add_f32 v13, v3, v5   // 000000403B64: C948090D 040C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 000000403B6C: 08060B03
	v_add_f32_e32 v5, v2, v6                                   // 000000403B70: 060A0D02
	v_sub_f32_e32 v2, v2, v6                                   // 000000403B74: 08040D02
	v_mov_b32_dpp v6, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000403B78: 7E0C02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000403B80: D5010007 21AA0F07
	v_mov_b32_dpp v10, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000403B88: 7E1402FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000403B90: D5010009 21AA1309
	v_mov_b32_dpp v14, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000403B98: 7E1C02FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 000000403BA0: D501000D 21AA1B0D
	v_mov_b32_dpp v15, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000403BA8: 7E1E02FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000403BB0: D5010005 21AA0B05
	v_mov_b32_dpp v16, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000403BB8: 7E2002FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000403BC0: D5010008 21AA1108
	v_mov_b32_dpp v17, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000403BC8: 7E2202FA FF016104
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000403BD0: D5010004 21AA0904
	v_mov_b32_dpp v18, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000403BD8: 7E2402FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000403BE0: D5010003 21AA0703
	v_mov_b32_dpp v20, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000403BE8: 7E2802FA FF016102
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 000000403BF0: D5010002 21AA0502
	v_dual_add_f32 v6, v7, v6 :: v_dual_add_f32 v5, v5, v15    // 000000403BF8: C9080D07 06041F05
	v_cmp_eq_u32_e32 vcc_lo, 0, v11                            // 000000403C00: 7C941680
	v_dual_add_f32 v7, v9, v10 :: v_dual_add_f32 v8, v8, v16   // 000000403C04: C9081509 07082108
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000403C0C: BF870233
	v_mov_b32_dpp v10, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000403C10: 7E1402FA FF016206
	v_add_f32_e32 v4, v4, v17                                  // 000000403C18: 06082304
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 000000403C1C: D5010006 21AA0D06
	v_mov_b32_dpp v11, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000403C24: 7E1602FA FF016207
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000403C2C: D5010007 21AA0F07
	v_add_f32_e32 v2, v2, v20                                  // 000000403C34: 06042902
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000403C38: BF870092
	v_dual_add_f32 v6, v6, v10 :: v_dual_add_f32 v7, v7, v11   // 000000403C3C: C9081506 06061707
	v_mov_b32_dpp v10, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000403C44: 7E1402FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s0                          // 000000403C4C: D5010006 20020D06
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000403C54: BF8700D3
	v_mov_b32_dpp v11, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000403C58: 7E1602FA FF016407
	v_cndmask_b32_e64 v7, -v7, v7, s0                          // 000000403C60: D5010007 20020F07
	v_add_f32_e32 v9, v13, v14                                 // 000000403C68: 06121D0D
	v_mov_b32_dpp v14, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000403C6C: 7E1C02FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000403C74: D5010005 21AA0B05
	v_dual_add_f32 v15, v5, v14 :: v_dual_add_f32 v14, v7, v11 // 000000403C7C: C9081D05 0F0E1707
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000403C84: BF8701A4
	v_mov_b32_dpp v13, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000403C88: 7E1A02FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000403C90: D5010009 21AA1309
	v_mov_b32_dpp v7, v15 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000403C98: 7E0E02FA FF01640F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000403CA0: BF870194
	v_mov_b32_dpp v24, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000403CA4: 7E3002FA FF01680E
	v_add_f32_e32 v9, v9, v13                                  // 000000403CAC: 06121B09
	v_mov_b32_dpp v13, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000403CB0: 7E1A02FA FF016208
	s_delay_alu instid0(VALU_DEP_2)                            // 000000403CB8: BF870002
	v_mov_b32_dpp v12, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000403CBC: 7E1802FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 000000403CC4: D5010009 20021309
	v_add_f32_e32 v5, v6, v10                                  // 000000403CCC: 060A1506
	v_cndmask_b32_e64 v6, -v8, v8, vcc_lo                      // 000000403CD0: D5010006 21AA1108
	v_add_f32_e32 v3, v3, v18                                  // 000000403CD8: 06062503
	v_mov_b32_dpp v10, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000403CDC: 7E1402FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000403CE4: D5010004 21AA0904
	v_add_f32_e32 v22, v9, v12                                 // 000000403CEC: 062C1909
	v_add_f32_e32 v6, v6, v13                                  // 000000403CF0: 060C1B06
	v_mov_b32_dpp v11, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000403CF4: 7E1602FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000403CFC: D5010003 21AA0703
	v_mov_b32_dpp v12, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000403D04: 7E1802FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 000000403D0C: D5010002 21AA0502
	v_add_f32_e32 v4, v4, v10                                  // 000000403D14: 06081504
	v_cndmask_b32_e64 v9, -v15, v15, s0                        // 000000403D18: D5010009 20021F0F
	v_add_f32_e32 v3, v3, v11                                  // 000000403D20: 06061703
	v_mov_b32_dpp v10, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000403D24: 7E1402FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s0                          // 000000403D2C: D5010006 20020D06
	v_mov_b32_dpp v11, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000403D34: 7E1602FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 000000403D3C: D5010004 20020904
	v_add_f32_e32 v2, v2, v12                                  // 000000403D44: 06041902
	v_mov_b32_dpp v12, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000403D48: 7E1802FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 000000403D50: D5010003 20020703
	v_dual_add_f32 v20, v9, v7 :: v_dual_add_f32 v17, v6, v10  // 000000403D58: C9080F09 14101506
	v_add_f32_e32 v15, v4, v11                                 // 000000403D60: 061E1704
	v_mov_b32_dpp v13, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000403D64: 7E1A02FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 000000403D6C: D5010002 20020502
	v_add_f32_e32 v12, v3, v12                                 // 000000403D74: 06181903
	v_mov_b32_dpp v8, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000403D78: 7E1002FA FF016805
	v_mov_b32_dpp v23, v22 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000403D80: 7E2E02FA FF016816
	v_mov_b32_dpp v21, v20 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000403D88: 7E2A02FA FF016814
	v_add_f32_e32 v9, v2, v13                                  // 000000403D90: 06121B02
	v_mov_b32_dpp v18, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000403D94: 7E2402FA FF016811
	v_mov_b32_dpp v16, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000403D9C: 7E2002FA FF01680F
	v_mov_b32_dpp v13, v12 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000403DA4: 7E1A02FA FF01680C
	s_delay_alu instid0(VALU_DEP_4)                            // 000000403DAC: BF870004
	v_mov_b32_dpp v10, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000403DB0: 7E1402FA FF016809
	s_and_b32 exec_lo, exec_lo, s2                             // 000000403DB8: 8B7E027E
	s_cbranch_execz 63115                                      // 000000403DBC: BFA5F68B <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	v_lshl_or_b32 v3, s26, 7, v1                               // 000000403DC0: D6560003 04050E1A
	v_and_b32_e32 v0, 8, v0                                    // 000000403DC8: 36000088
	s_cmp_lg_u64 s[24:25], 0                                   // 000000403DCC: BF118018
	s_cselect_b32 s1, -1, 0                                    // 000000403DD0: 980180C1
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000403DD4: BF870112
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000403DD8: 3408069F
	.long 0xd44a0000                                           // 000000403DDC: D44A0000
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 000000403DE0: 02020080
	s_lshr_b32 s2, s20, 31                                     // 000000403DE4: 85029F14
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000403DE8: BF870009
	s_add_i32 s2, s20, s2                                      // 000000403DEC: 81020214
	.long 0xd73c0001                                           // 000000403DF0: D73C0001
	v_cndmask_b32_e32 v1, 1, v3, vcc_lo                        // 000000403DF4: 02020681
	v_cndmask_b32_e64 v0, -v5, v5, s0                          // 000000403DF8: D5010000 20020B05
	v_mad_i64_i32 v[4:5], null, s20, v19, 0                    // 000000403E00: D6FF7C04 02022614
	s_ashr_i32 s2, s2, 1                                       // 000000403E08: 86028102
	s_cmp_eq_u64 s[24:25], 0                                   // 000000403E0C: BF108018
	v_mad_i64_i32 v[25:26], null, s2, v19, 0                   // 000000403E10: D6FF7C19 02022602
	.long 0xd7006a06                                           // 000000403E18: D7006A06
	v_cndmask_b32_e32 v1, s12, v1, vcc_lo                      // 000000403E1C: 0202020C
	s_delay_alu instid0(VALU_DEP_1)                            // 000000403E20: BF870001
	v_add_co_ci_u32_e64 v7, null, s13, v2, vcc_lo              // 000000403E24: D5207C07 01AA040D
	v_add_f32_e32 v0, v0, v8                                   // 000000403E2C: 06001100
	.long 0xd73c0004                                           // 000000403E30: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 000000403E34: 02020881
	global_load_d16_b16 v11, v[6:7], off                       // 000000403E38: DC820000 0B7C0006
	v_mul_f32_e32 v0, 0x3db504f3, v0                           // 000000403E40: 100000FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000403E48: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000403E4C: BF8700A1
	v_fma_mix_f32 v27, v11, v0, neg(0) op_sel_hi:[1,0,0]       // 000000403E50: CC20001B 8A02010B
	.long 0xd7006a00                                           // 000000403E58: D7006A00
	v_cndmask_b32_e32 v1, s14, v4, vcc_lo                      // 000000403E5C: 0202080E
	v_add_co_ci_u32_e64 v8, null, s15, v5, vcc_lo              // 000000403E60: D5207C08 01AA0A0F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000403E68: BF8701B3
	v_bfe_u32 v19, v27, 16, 1                                  // 000000403E6C: D6100013 0205211B
	.long 0xd73c0004                                           // 000000403E74: D73C0004
	v_cndmask_b32_e32 v1, 1, v25, vcc_lo                       // 000000403E78: 02023281
	v_ashrrev_i32_e32 v11, 31, v3                              // 000000403E7C: 3416069F
	v_add3_u32 v19, v27, v19, 0x7fff                           // 000000403E80: D6550013 03FE271B 00007FFF
	s_cbranch_scc1 570                                         // 000000403E8C: BFA2023A <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3378>
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000403E90: BF870122
	v_lshrrev_b32_e32 v25, 23, v11                             // 000000403E94: 32321697
	v_mov_b32_e32 v29, s14                                     // 000000403E98: 7E3A020E
	v_add_nc_u32_e32 v25, v3, v25                              // 000000403E9C: 4A323303
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000403EA0: BF870091
	v_and_b32_e32 v26, 0xfffffe00, v25                         // 000000403EA4: 363432FF FFFFFE00
	v_sub_nc_u32_e32 v27, v3, v26                              // 000000403EAC: 4C363503
	v_mov_b32_e32 v26, s15                                     // 000000403EB0: 7E34020F
	v_ashrrev_i32_e32 v25, 9, v25                              // 000000403EB4: 34323289
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000403EB8: BF8701A3
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v27                        // 000000403EBC: 7C8836FF 00000100
	v_add_nc_u32_e32 v28, 0xffffff00, v27                      // 000000403EC4: 4A3836FF FFFFFF00
	v_dual_cndmask_b32 v30, s25, v26 :: v_dual_lshlrev_b32 v25, 8, v25// 000000403ECC: CA623419 1E183288
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000403ED4: BF870112
	v_cndmask_b32_e32 v27, v28, v27, vcc_lo                    // 000000403ED8: 0236371C
	v_ashrrev_i32_e32 v26, 31, v25                             // 000000403EDC: 3434329F
	v_cndmask_b32_e32 v29, s24, v29, vcc_lo                    // 000000403EE0: 023A3A18
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000403EE4: BF870193
	v_ashrrev_i32_e32 v28, 31, v27                             // 000000403EE8: 3438369F
	.long 0xd73c0019                                           // 000000403EEC: D73C0019
	v_cndmask_b32_e32 v1, 1, v25, vcc_lo                       // 000000403EF0: 02023281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000403EF4: BF870093
	.long 0xd7006a1d                                           // 000000403EF8: D7006A1D
	v_cndmask_b32_e32 v1, v29, v4, vcc_lo                      // 000000403EFC: 0202091D
	v_add_co_ci_u32_e64 v30, null, v30, v5, vcc_lo             // 000000403F00: D5207C1E 01AA0B1E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000403F08: BF870194
	.long 0xd73c001b                                           // 000000403F0C: D73C001B
	v_cndmask_b32_e32 v1, 1, v27, vcc_lo                       // 000000403F10: 02023681
	.long 0xd7006a19                                           // 000000403F14: D7006A19
	v_cndmask_b32_e32 v1, v29, v25, vcc_lo                     // 000000403F18: 0202331D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000403F1C: BF870111
	v_add_co_ci_u32_e64 v26, null, v30, v26, vcc_lo            // 000000403F20: D5207C1A 01AA351E
	.long 0xd7006a19                                           // 000000403F28: D7006A19
	v_cndmask_b32_e32 v1, v25, v27, vcc_lo                     // 000000403F2C: 02023719
	s_delay_alu instid0(VALU_DEP_1)                            // 000000403F30: BF870001
	v_add_co_ci_u32_e64 v26, null, v26, v28, vcc_lo            // 000000403F34: D5207C1A 01AA391A
	global_store_d16_hi_b16 v[25:26], v19, off                 // 000000403F3C: DC960000 007C1319
	s_cbranch_execnz 7                                         // 000000403F44: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2b64>
	.long 0xd7006a19                                           // 000000403F48: D7006A19
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 000000403F4C: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 000000403F50: BF870001
	v_add_co_ci_u32_e64 v26, null, v8, v2, vcc_lo              // 000000403F54: D5207C1A 01AA0508
	global_store_d16_hi_b16 v[25:26], v19, off                 // 000000403F5C: DC960000 007C1319
	global_load_d16_b16 v19, v[6:7], off offset:32             // 000000403F64: DC820020 137C0006
	v_cndmask_b32_e64 v14, -v14, v14, s0                       // 000000403F6C: D501000E 20021D0E
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 000000403F74: 916A017E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000403F78: BF870091
	v_add_f32_e32 v14, v14, v24                                // 000000403F7C: 061C310E
	v_mul_f32_e32 v14, 0x3db504f3, v14                         // 000000403F80: 101C1CFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000403F88: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000403F8C: BF870121
	v_fma_mix_f32 v19, v19, v14, neg(0) op_sel_hi:[1,0,0]      // 000000403F90: CC200013 8A021D13
	v_cndmask_b32_e64 v14, 0, 1, s1                            // 000000403F98: D501000E 00050280
	v_bfe_u32 v24, v19, 16, 1                                  // 000000403FA0: D6100018 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 000000403FA8: BF870001
	v_add3_u32 v19, v19, v24, 0x7fff                           // 000000403FAC: D6550013 03FE3113 00007FFF
	s_cbranch_vccnz 496                                        // 000000403FB8: BFA401F0 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x337c>
	v_or_b32_e32 v24, 16, v3                                   // 000000403FBC: 38300690
	v_lshrrev_b32_e32 v25, 23, v11                             // 000000403FC0: 32321697
	v_mov_b32_e32 v27, s15                                     // 000000403FC4: 7E36020F
	v_mov_b32_e32 v29, s14                                     // 000000403FC8: 7E3A020E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000403FCC: BF870093
	v_add_nc_u32_e32 v25, v24, v25                             // 000000403FD0: 4A323318
	v_and_b32_e32 v26, 0xfffffe00, v25                         // 000000403FD4: 363432FF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000403FDC: BF870091
	v_sub_nc_u32_e32 v26, v24, v26                             // 000000403FE0: 4C343518
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v26                        // 000000403FE4: 7C8834FF 00000100
	v_add_nc_u32_e32 v28, 0xffffff00, v26                      // 000000403FEC: 4A3834FF FFFFFF00
	v_cndmask_b32_e32 v30, s25, v27, vcc_lo                    // 000000403FF4: 023C3619
	v_ashrrev_i32_e32 v25, 9, v25                              // 000000403FF8: 34323289
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000403FFC: BF8701A3
	v_cndmask_b32_e32 v26, v28, v26, vcc_lo                    // 000000404000: 0234351C
	v_cndmask_b32_e32 v28, s24, v29, vcc_lo                    // 000000404004: 02383A18
	v_lshlrev_b32_e32 v24, 8, v25                              // 000000404008: 30303288
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000040400C: BF870193
	v_ashrrev_i32_e32 v27, 31, v26                             // 000000404010: 3436349F
	.long 0xd7006a1c                                           // 000000404014: D7006A1C
	v_cndmask_b32_e32 v1, v28, v4, vcc_lo                      // 000000404018: 0202091C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000040401C: BF870211
	v_add_co_ci_u32_e64 v29, null, v30, v5, vcc_lo             // 000000404020: D5207C1D 01AA0B1E
	v_ashrrev_i32_e32 v25, 31, v24                             // 000000404028: 3432309F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000040402C: BF870114
	.long 0xd73c001a                                           // 000000404030: D73C001A
	v_cndmask_b32_e32 v1, 1, v26, vcc_lo                       // 000000404034: 02023481
	.long 0xd73c0018                                           // 000000404038: D73C0018
	v_cndmask_b32_e32 v1, 1, v24, vcc_lo                       // 00000040403C: 02023081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000404040: BF870091
	.long 0xd7006a18                                           // 000000404044: D7006A18
	v_cndmask_b32_e32 v1, v28, v24, vcc_lo                     // 000000404048: 0202311C
	v_add_co_ci_u32_e64 v25, null, v29, v25, vcc_lo            // 00000040404C: D5207C19 01AA331D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000404054: BF870092
	.long 0xd7006a18                                           // 000000404058: D7006A18
	v_cndmask_b32_e32 v1, v24, v26, vcc_lo                     // 00000040405C: 02023518
	v_add_co_ci_u32_e64 v25, null, v25, v27, vcc_lo            // 000000404060: D5207C19 01AA3719
	global_store_d16_hi_b16 v[24:25], v19, off                 // 000000404068: DC960000 007C1318
	s_cbranch_execnz 7                                         // 000000404070: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2c90>
	.long 0xd7006a18                                           // 000000404074: D7006A18
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 000000404078: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 00000040407C: BF870001
	v_add_co_ci_u32_e64 v25, null, v8, v2, vcc_lo              // 000000404080: D5207C19 01AA0508
	global_store_d16_hi_b16 v[24:25], v19, off offset:32       // 000000404088: DC960020 007C1318
	global_load_d16_b16 v19, v[6:7], off offset:64             // 000000404090: DC820040 137C0006
	v_cndmask_b32_e64 v22, -v22, v22, s0                       // 000000404098: D5010016 20022D16
	v_cmp_ne_u32_e32 vcc_lo, 1, v14                            // 0000004040A0: 7C9A1C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000004040A4: BF8700A2
	v_add_f32_e32 v22, v22, v23                                // 0000004040A8: 062C2F16
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 0000004040AC: 8B6A6A7E
	v_mul_f32_e32 v22, 0x3db504f3, v22                         // 0000004040B0: 102C2CFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 0000004040B8: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004040BC: BF870091
	v_fma_mix_f32 v19, v19, v22, neg(0) op_sel_hi:[1,0,0]      // 0000004040C0: CC200013 8A022D13
	v_bfe_u32 v22, v19, 16, 1                                  // 0000004040C8: D6100016 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004040D0: BF870001
	v_add3_u32 v19, v19, v22, 0x7fff                           // 0000004040D4: D6550013 03FE2D13 00007FFF
	s_cbranch_vccnz 423                                        // 0000004040E0: BFA401A7 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3380>
	v_or_b32_e32 v22, 32, v3                                   // 0000004040E4: 382C06A0
	v_lshrrev_b32_e32 v23, 23, v11                             // 0000004040E8: 322E1697
	v_mov_b32_e32 v25, s15                                     // 0000004040EC: 7E32020F
	v_mov_b32_e32 v27, s14                                     // 0000004040F0: 7E36020E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004040F4: BF870093
	v_add_nc_u32_e32 v23, v22, v23                             // 0000004040F8: 4A2E2F16
	v_and_b32_e32 v24, 0xfffffe00, v23                         // 0000004040FC: 36302EFF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000404104: BF870091
	v_sub_nc_u32_e32 v24, v22, v24                             // 000000404108: 4C303116
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v24                        // 00000040410C: 7C8830FF 00000100
	v_add_nc_u32_e32 v26, 0xffffff00, v24                      // 000000404114: 4A3430FF FFFFFF00
	v_cndmask_b32_e32 v28, s25, v25, vcc_lo                    // 00000040411C: 02383219
	v_ashrrev_i32_e32 v23, 9, v23                              // 000000404120: 342E2E89
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000404124: BF8701A3
	v_cndmask_b32_e32 v24, v26, v24, vcc_lo                    // 000000404128: 0230311A
	v_cndmask_b32_e32 v26, s24, v27, vcc_lo                    // 00000040412C: 02343618
	v_lshlrev_b32_e32 v22, 8, v23                              // 000000404130: 302C2E88
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000404134: BF870193
	v_ashrrev_i32_e32 v25, 31, v24                             // 000000404138: 3432309F
	.long 0xd7006a1a                                           // 00000040413C: D7006A1A
	v_cndmask_b32_e32 v1, v26, v4, vcc_lo                      // 000000404140: 0202091A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000404144: BF870211
	v_add_co_ci_u32_e64 v27, null, v28, v5, vcc_lo             // 000000404148: D5207C1B 01AA0B1C
	v_ashrrev_i32_e32 v23, 31, v22                             // 000000404150: 342E2C9F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000404154: BF870114
	.long 0xd73c0018                                           // 000000404158: D73C0018
	v_cndmask_b32_e32 v1, 1, v24, vcc_lo                       // 00000040415C: 02023081
	.long 0xd73c0016                                           // 000000404160: D73C0016
	v_cndmask_b32_e32 v1, 1, v22, vcc_lo                       // 000000404164: 02022C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000404168: BF870091
	.long 0xd7006a16                                           // 00000040416C: D7006A16
	v_cndmask_b32_e32 v1, v26, v22, vcc_lo                     // 000000404170: 02022D1A
	v_add_co_ci_u32_e64 v23, null, v27, v23, vcc_lo            // 000000404174: D5207C17 01AA2F1B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000040417C: BF870092
	.long 0xd7006a16                                           // 000000404180: D7006A16
	v_cndmask_b32_e32 v1, v22, v24, vcc_lo                     // 000000404184: 02023116
	v_add_co_ci_u32_e64 v23, null, v23, v25, vcc_lo            // 000000404188: D5207C17 01AA3317
	global_store_d16_hi_b16 v[22:23], v19, off                 // 000000404190: DC960000 007C1316
	s_cbranch_execnz 7                                         // 000000404198: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2db8>
	.long 0xd7006a16                                           // 00000040419C: D7006A16
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 0000004041A0: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004041A4: BF870001
	v_add_co_ci_u32_e64 v23, null, v8, v2, vcc_lo              // 0000004041A8: D5207C17 01AA0508
	global_store_d16_hi_b16 v[22:23], v19, off offset:64       // 0000004041B0: DC960040 007C1316
	global_load_d16_b16 v19, v[6:7], off offset:96             // 0000004041B8: DC820060 137C0006
	v_cndmask_b32_e64 v20, -v20, v20, s0                       // 0000004041C0: D5010014 20022914
	v_cmp_ne_u32_e32 vcc_lo, 1, v14                            // 0000004041C8: 7C9A1C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000004041CC: BF8700A2
	v_add_f32_e32 v20, v20, v21                                // 0000004041D0: 06282B14
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 0000004041D4: 8B6A6A7E
	v_mul_f32_e32 v20, 0x3db504f3, v20                         // 0000004041D8: 102828FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 0000004041E0: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004041E4: BF870091
	v_fma_mix_f32 v19, v19, v20, neg(0) op_sel_hi:[1,0,0]      // 0000004041E8: CC200013 8A022913
	v_bfe_u32 v20, v19, 16, 1                                  // 0000004041F0: D6100014 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004041F8: BF870001
	v_add3_u32 v19, v19, v20, 0x7fff                           // 0000004041FC: D6550013 03FE2913 00007FFF
	s_cbranch_vccnz 350                                        // 000000404208: BFA4015E <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3384>
	v_or_b32_e32 v20, 48, v3                                   // 00000040420C: 382806B0
	v_lshrrev_b32_e32 v21, 23, v11                             // 000000404210: 322A1697
	v_mov_b32_e32 v23, s15                                     // 000000404214: 7E2E020F
	v_mov_b32_e32 v25, s14                                     // 000000404218: 7E32020E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000040421C: BF870093
	v_add_nc_u32_e32 v21, v20, v21                             // 000000404220: 4A2A2B14
	v_and_b32_e32 v22, 0xfffffe00, v21                         // 000000404224: 362C2AFF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000040422C: BF870091
	v_sub_nc_u32_e32 v22, v20, v22                             // 000000404230: 4C2C2D14
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v22                        // 000000404234: 7C882CFF 00000100
	v_add_nc_u32_e32 v24, 0xffffff00, v22                      // 00000040423C: 4A302CFF FFFFFF00
	v_cndmask_b32_e32 v26, s25, v23, vcc_lo                    // 000000404244: 02342E19
	v_ashrrev_i32_e32 v21, 9, v21                              // 000000404248: 342A2A89
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000040424C: BF8701A3
	v_cndmask_b32_e32 v22, v24, v22, vcc_lo                    // 000000404250: 022C2D18
	v_cndmask_b32_e32 v24, s24, v25, vcc_lo                    // 000000404254: 02303218
	v_lshlrev_b32_e32 v20, 8, v21                              // 000000404258: 30282A88
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000040425C: BF870193
	v_ashrrev_i32_e32 v23, 31, v22                             // 000000404260: 342E2C9F
	.long 0xd7006a18                                           // 000000404264: D7006A18
	v_cndmask_b32_e32 v1, v24, v4, vcc_lo                      // 000000404268: 02020918
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000040426C: BF870211
	v_add_co_ci_u32_e64 v25, null, v26, v5, vcc_lo             // 000000404270: D5207C19 01AA0B1A
	v_ashrrev_i32_e32 v21, 31, v20                             // 000000404278: 342A289F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000040427C: BF870114
	.long 0xd73c0016                                           // 000000404280: D73C0016
	v_cndmask_b32_e32 v1, 1, v22, vcc_lo                       // 000000404284: 02022C81
	.long 0xd73c0014                                           // 000000404288: D73C0014
	v_cndmask_b32_e32 v1, 1, v20, vcc_lo                       // 00000040428C: 02022881
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000404290: BF870091
	.long 0xd7006a14                                           // 000000404294: D7006A14
	v_cndmask_b32_e32 v1, v24, v20, vcc_lo                     // 000000404298: 02022918
	v_add_co_ci_u32_e64 v21, null, v25, v21, vcc_lo            // 00000040429C: D5207C15 01AA2B19
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004042A4: BF870092
	.long 0xd7006a14                                           // 0000004042A8: D7006A14
	v_cndmask_b32_e32 v1, v20, v22, vcc_lo                     // 0000004042AC: 02022D14
	v_add_co_ci_u32_e64 v21, null, v21, v23, vcc_lo            // 0000004042B0: D5207C15 01AA2F15
	global_store_d16_hi_b16 v[20:21], v19, off                 // 0000004042B8: DC960000 007C1314
	s_cbranch_execnz 7                                         // 0000004042C0: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2ee0>
	.long 0xd7006a14                                           // 0000004042C4: D7006A14
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 0000004042C8: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004042CC: BF870001
	v_add_co_ci_u32_e64 v21, null, v8, v2, vcc_lo              // 0000004042D0: D5207C15 01AA0508
	global_store_d16_hi_b16 v[20:21], v19, off offset:96       // 0000004042D8: DC960060 007C1314
	global_load_d16_b16 v19, v[6:7], off offset:128            // 0000004042E0: DC820080 137C0006
	v_cndmask_b32_e64 v17, -v17, v17, s0                       // 0000004042E8: D5010011 20022311
	v_cmp_ne_u32_e32 vcc_lo, 1, v14                            // 0000004042F0: 7C9A1C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000004042F4: BF8700A2
	v_add_f32_e32 v17, v17, v18                                // 0000004042F8: 06222511
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 0000004042FC: 8B6A6A7E
	v_mul_f32_e32 v17, 0x3db504f3, v17                         // 000000404300: 102222FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000404308: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000040430C: BF870091
	v_fma_mix_f32 v17, v19, v17, neg(0) op_sel_hi:[1,0,0]      // 000000404310: CC200011 8A022313
	v_bfe_u32 v18, v17, 16, 1                                  // 000000404318: D6100012 02052111
	s_delay_alu instid0(VALU_DEP_1)                            // 000000404320: BF870001
	v_add3_u32 v17, v17, v18, 0x7fff                           // 000000404324: D6550011 03FE2511 00007FFF
	s_cbranch_vccnz 277                                        // 000000404330: BFA40115 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3388>
	v_or_b32_e32 v18, 64, v3                                   // 000000404334: 382406C0
	v_lshrrev_b32_e32 v19, 23, v11                             // 000000404338: 32261697
	v_mov_b32_e32 v21, s15                                     // 00000040433C: 7E2A020F
	v_mov_b32_e32 v23, s14                                     // 000000404340: 7E2E020E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000404344: BF870093
	v_add_nc_u32_e32 v19, v18, v19                             // 000000404348: 4A262712
	v_and_b32_e32 v20, 0xfffffe00, v19                         // 00000040434C: 362826FF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000404354: BF870091
	v_sub_nc_u32_e32 v20, v18, v20                             // 000000404358: 4C282912
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v20                        // 00000040435C: 7C8828FF 00000100
	v_add_nc_u32_e32 v22, 0xffffff00, v20                      // 000000404364: 4A2C28FF FFFFFF00
	v_cndmask_b32_e32 v24, s25, v21, vcc_lo                    // 00000040436C: 02302A19
	v_ashrrev_i32_e32 v19, 9, v19                              // 000000404370: 34262689
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000404374: BF8701A3
	v_cndmask_b32_e32 v20, v22, v20, vcc_lo                    // 000000404378: 02282916
	v_cndmask_b32_e32 v22, s24, v23, vcc_lo                    // 00000040437C: 022C2E18
	v_lshlrev_b32_e32 v18, 8, v19                              // 000000404380: 30242688
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000404384: BF870193
	v_ashrrev_i32_e32 v21, 31, v20                             // 000000404388: 342A289F
	.long 0xd7006a16                                           // 00000040438C: D7006A16
	v_cndmask_b32_e32 v1, v22, v4, vcc_lo                      // 000000404390: 02020916
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000404394: BF870211
	v_add_co_ci_u32_e64 v23, null, v24, v5, vcc_lo             // 000000404398: D5207C17 01AA0B18
	v_ashrrev_i32_e32 v19, 31, v18                             // 0000004043A0: 3426249F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004043A4: BF870114
	.long 0xd73c0014                                           // 0000004043A8: D73C0014
	v_cndmask_b32_e32 v1, 1, v20, vcc_lo                       // 0000004043AC: 02022881
	.long 0xd73c0012                                           // 0000004043B0: D73C0012
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 0000004043B4: 02022481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004043B8: BF870091
	.long 0xd7006a12                                           // 0000004043BC: D7006A12
	v_cndmask_b32_e32 v1, v22, v18, vcc_lo                     // 0000004043C0: 02022516
	v_add_co_ci_u32_e64 v19, null, v23, v19, vcc_lo            // 0000004043C4: D5207C13 01AA2717
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004043CC: BF870092
	.long 0xd7006a12                                           // 0000004043D0: D7006A12
	v_cndmask_b32_e32 v1, v18, v20, vcc_lo                     // 0000004043D4: 02022912
	v_add_co_ci_u32_e64 v19, null, v19, v21, vcc_lo            // 0000004043D8: D5207C13 01AA2B13
	global_store_d16_hi_b16 v[18:19], v17, off                 // 0000004043E0: DC960000 007C1112
	s_cbranch_execnz 7                                         // 0000004043E8: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3008>
	.long 0xd7006a12                                           // 0000004043EC: D7006A12
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 0000004043F0: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004043F4: BF870001
	v_add_co_ci_u32_e64 v19, null, v8, v2, vcc_lo              // 0000004043F8: D5207C13 01AA0508
	global_store_d16_hi_b16 v[18:19], v17, off offset:128      // 000000404400: DC960080 007C1112
	global_load_d16_b16 v17, v[6:7], off offset:160            // 000000404408: DC8200A0 117C0006
	v_cndmask_b32_e64 v15, -v15, v15, s0                       // 000000404410: D501000F 20021F0F
	v_cmp_ne_u32_e32 vcc_lo, 1, v14                            // 000000404418: 7C9A1C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000040441C: BF8700A2
	v_add_f32_e32 v15, v15, v16                                // 000000404420: 061E210F
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 000000404424: 8B6A6A7E
	v_mul_f32_e32 v15, 0x3db504f3, v15                         // 000000404428: 101E1EFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000404430: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000404434: BF870091
	v_fma_mix_f32 v15, v17, v15, neg(0) op_sel_hi:[1,0,0]      // 000000404438: CC20000F 8A021F11
	v_bfe_u32 v16, v15, 16, 1                                  // 000000404440: D6100010 0205210F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000404448: BF870001
	v_add3_u32 v15, v15, v16, 0x7fff                           // 00000040444C: D655000F 03FE210F 00007FFF
	s_cbranch_vccnz 204                                        // 000000404458: BFA400CC <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x338c>
	v_or_b32_e32 v16, 0x50, v3                                 // 00000040445C: 382006FF 00000050
	v_lshrrev_b32_e32 v17, 23, v11                             // 000000404464: 32221697
	v_mov_b32_e32 v19, s15                                     // 000000404468: 7E26020F
	v_mov_b32_e32 v21, s14                                     // 00000040446C: 7E2A020E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000404470: BF870093
	v_add_nc_u32_e32 v17, v16, v17                             // 000000404474: 4A222310
	v_and_b32_e32 v18, 0xfffffe00, v17                         // 000000404478: 362422FF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000404480: BF870091
	v_sub_nc_u32_e32 v18, v16, v18                             // 000000404484: 4C242510
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v18                        // 000000404488: 7C8824FF 00000100
	v_add_nc_u32_e32 v20, 0xffffff00, v18                      // 000000404490: 4A2824FF FFFFFF00
	v_cndmask_b32_e32 v22, s25, v19, vcc_lo                    // 000000404498: 022C2619
	v_ashrrev_i32_e32 v17, 9, v17                              // 00000040449C: 34222289
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000004044A0: BF8701A3
	v_cndmask_b32_e32 v18, v20, v18, vcc_lo                    // 0000004044A4: 02242514
	v_cndmask_b32_e32 v20, s24, v21, vcc_lo                    // 0000004044A8: 02282A18
	v_lshlrev_b32_e32 v16, 8, v17                              // 0000004044AC: 30202288
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004044B0: BF870193
	v_ashrrev_i32_e32 v19, 31, v18                             // 0000004044B4: 3426249F
	.long 0xd7006a14                                           // 0000004044B8: D7006A14
	v_cndmask_b32_e32 v1, v20, v4, vcc_lo                      // 0000004044BC: 02020914
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004044C0: BF870211
	v_add_co_ci_u32_e64 v21, null, v22, v5, vcc_lo             // 0000004044C4: D5207C15 01AA0B16
	v_ashrrev_i32_e32 v17, 31, v16                             // 0000004044CC: 3422209F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004044D0: BF870114
	.long 0xd73c0012                                           // 0000004044D4: D73C0012
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 0000004044D8: 02022481
	.long 0xd73c0010                                           // 0000004044DC: D73C0010
	v_cndmask_b32_e32 v1, 1, v16, vcc_lo                       // 0000004044E0: 02022081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004044E4: BF870091
	.long 0xd7006a10                                           // 0000004044E8: D7006A10
	v_cndmask_b32_e32 v1, v20, v16, vcc_lo                     // 0000004044EC: 02022114
	v_add_co_ci_u32_e64 v17, null, v21, v17, vcc_lo            // 0000004044F0: D5207C11 01AA2315
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004044F8: BF870092
	.long 0xd7006a10                                           // 0000004044FC: D7006A10
	v_cndmask_b32_e32 v1, v16, v18, vcc_lo                     // 000000404500: 02022510
	v_add_co_ci_u32_e64 v17, null, v17, v19, vcc_lo            // 000000404504: D5207C11 01AA2711
	global_store_d16_hi_b16 v[16:17], v15, off                 // 00000040450C: DC960000 007C0F10
	s_cbranch_execnz 7                                         // 000000404514: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3134>
	.long 0xd7006a10                                           // 000000404518: D7006A10
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 00000040451C: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 000000404520: BF870001
	v_add_co_ci_u32_e64 v17, null, v8, v2, vcc_lo              // 000000404524: D5207C11 01AA0508
	global_store_d16_hi_b16 v[16:17], v15, off offset:160      // 00000040452C: DC9600A0 007C0F10
	global_load_d16_b16 v15, v[6:7], off offset:192            // 000000404534: DC8200C0 0F7C0006
	v_cndmask_b32_e64 v12, -v12, v12, s0                       // 00000040453C: D501000C 2002190C
	v_cmp_ne_u32_e32 vcc_lo, 1, v14                            // 000000404544: 7C9A1C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000404548: BF8700A2
	v_add_f32_e32 v12, v12, v13                                // 00000040454C: 06181B0C
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 000000404550: 8B6A6A7E
	v_mul_f32_e32 v12, 0x3db504f3, v12                         // 000000404554: 101818FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 00000040455C: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000404560: BF870091
	v_fma_mix_f32 v12, v15, v12, neg(0) op_sel_hi:[1,0,0]      // 000000404564: CC20000C 8A02190F
	v_bfe_u32 v13, v12, 16, 1                                  // 00000040456C: D610000D 0205210C
	s_delay_alu instid0(VALU_DEP_1)                            // 000000404574: BF870001
	v_add3_u32 v12, v12, v13, 0x7fff                           // 000000404578: D655000C 03FE1B0C 00007FFF
	s_cbranch_vccnz 130                                        // 000000404584: BFA40082 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3390>
	v_or_b32_e32 v13, 0x60, v3                                 // 000000404588: 381A06FF 00000060
	v_lshrrev_b32_e32 v15, 23, v11                             // 000000404590: 321E1697
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000404594: BF870091
	v_dual_mov_b32 v18, s14 :: v_dual_add_nc_u32 v15, v13, v15 // 000000404598: CA20000E 120E1F0D
	v_and_b32_e32 v16, 0xfffffe00, v15                         // 0000004045A0: 36201EFF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000004045A8: BF8701B1
	v_sub_nc_u32_e32 v13, v13, v16                             // 0000004045AC: 4C1A210D
	v_mov_b32_e32 v16, s15                                     // 0000004045B0: 7E20020F
	v_ashrrev_i32_e32 v15, 9, v15                              // 0000004045B4: 341E1E89
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v13                        // 0000004045B8: 7C881AFF 00000100
	v_add_nc_u32_e32 v17, 0xffffff00, v13                      // 0000004045C0: 4A221AFF FFFFFF00
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000004045C8: BF8701A3
	v_lshlrev_b32_e32 v15, 8, v15                              // 0000004045CC: 301E1E88
	v_cndmask_b32_e32 v19, s25, v16, vcc_lo                    // 0000004045D0: 02262019
	v_cndmask_b32_e32 v17, v17, v13, vcc_lo                    // 0000004045D4: 02221B11
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000004045D8: BF8701A3
	v_ashrrev_i32_e32 v16, 31, v15                             // 0000004045DC: 34201E9F
	v_cndmask_b32_e32 v13, s24, v18, vcc_lo                    // 0000004045E0: 021A2418
	v_ashrrev_i32_e32 v18, 31, v17                             // 0000004045E4: 3424229F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004045E8: BF870193
	.long 0xd73c000f                                           // 0000004045EC: D73C000F
	v_cndmask_b32_e32 v1, 1, v15, vcc_lo                       // 0000004045F0: 02021E81
	.long 0xd7006a0d                                           // 0000004045F4: D7006A0D
	v_cndmask_b32_e32 v1, v13, v4, vcc_lo                      // 0000004045F8: 0202090D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004045FC: BF870211
	v_add_co_ci_u32_e64 v19, null, v19, v5, vcc_lo             // 000000404600: D5207C13 01AA0B13
	.long 0xd73c0011                                           // 000000404608: D73C0011
	v_cndmask_b32_e32 v1, 1, v17, vcc_lo                       // 00000040460C: 02022281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000404610: BF870093
	.long 0xd7006a0d                                           // 000000404614: D7006A0D
	v_cndmask_b32_e32 v1, v13, v15, vcc_lo                     // 000000404618: 02021F0D
	v_add_co_ci_u32_e64 v16, null, v19, v16, vcc_lo            // 00000040461C: D5207C10 01AA2113
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000404624: BF870092
	.long 0xd7006a0f                                           // 000000404628: D7006A0F
	v_cndmask_b32_e32 v1, v13, v17, vcc_lo                     // 00000040462C: 0202230D
	v_add_co_ci_u32_e64 v16, null, v16, v18, vcc_lo            // 000000404630: D5207C10 01AA2510
	global_store_d16_hi_b16 v[15:16], v12, off                 // 000000404638: DC960000 007C0C0F
	s_cbranch_execnz 7                                         // 000000404640: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3260>
	.long 0xd7006a0f                                           // 000000404644: D7006A0F
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 000000404648: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 00000040464C: BF870001
	v_add_co_ci_u32_e64 v16, null, v8, v2, vcc_lo              // 000000404650: D5207C10 01AA0508
	global_store_d16_hi_b16 v[15:16], v12, off offset:192      // 000000404658: DC9600C0 007C0C0F
	global_load_d16_b16 v6, v[6:7], off offset:224             // 000000404660: DC8200E0 067C0006
	v_cndmask_b32_e64 v7, -v9, v9, s0                          // 000000404668: D5010007 20021309
	v_cmp_ne_u32_e32 vcc_lo, 1, v14                            // 000000404670: 7C9A1C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000404674: BF8700A2
	v_add_f32_e32 v7, v7, v10                                  // 000000404678: 060E1507
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 00000040467C: 8B6A6A7E
	v_mul_f32_e32 v7, 0x3db504f3, v7                           // 000000404680: 100E0EFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000404688: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000040468C: BF870091
	v_fma_mix_f32 v6, v6, v7, neg(0) op_sel_hi:[1,0,0]         // 000000404690: CC200006 8A020F06
	v_bfe_u32 v7, v6, 16, 1                                    // 000000404698: D6100007 02052106
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004046A0: BF870001
	v_add3_u32 v6, v6, v7, 0x7fff                              // 0000004046A4: D6550006 03FE0F06 00007FFF
	s_cbranch_vccnz 56                                         // 0000004046B0: BFA40038 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3394>
	v_or_b32_e32 v3, 0x70, v3                                  // 0000004046B4: 380606FF 00000070
	v_lshrrev_b32_e32 v7, 23, v11                              // 0000004046BC: 320E1697
	v_mov_b32_e32 v10, s15                                     // 0000004046C0: 7E14020F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004046C4: BF870092
	v_dual_mov_b32 v12, s14 :: v_dual_add_nc_u32 v7, v3, v7    // 0000004046C8: CA20000E 0C060F03
	v_and_b32_e32 v9, 0xfffffe00, v7                           // 0000004046D0: 36120EFF FFFFFE00
	v_ashrrev_i32_e32 v7, 9, v7                                // 0000004046D8: 340E0E89
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004046DC: BF870112
	v_sub_nc_u32_e32 v3, v3, v9                                // 0000004046E0: 4C061303
	v_lshlrev_b32_e32 v9, 8, v7                                // 0000004046E4: 30120E88
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000004046E8: BF870232
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v3                         // 0000004046EC: 7C8806FF 00000100
	v_add_nc_u32_e32 v7, 0xffffff00, v3                        // 0000004046F4: 4A0E06FF FFFFFF00
	v_cndmask_b32_e32 v13, s25, v10, vcc_lo                    // 0000004046FC: 021A1419
	v_ashrrev_i32_e32 v10, 31, v9                              // 000000404700: 3414129F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000404704: BF8701A3
	v_cndmask_b32_e32 v11, v7, v3, vcc_lo                      // 000000404708: 02160707
	v_cndmask_b32_e32 v3, s24, v12, vcc_lo                     // 00000040470C: 02061818
	.long 0xd73c0009                                           // 000000404710: D73C0009
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 000000404714: 02021281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000404718: BF870193
	v_ashrrev_i32_e32 v12, 31, v11                             // 00000040471C: 3418169F
	.long 0xd7006a07                                           // 000000404720: D7006A07
	v_cndmask_b32_e32 v1, v3, v4, vcc_lo                       // 000000404724: 02020903
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000404728: BF870191
	v_add_co_ci_u32_e64 v5, null, v13, v5, vcc_lo              // 00000040472C: D5207C05 01AA0B0D
	.long 0xd73c0003                                           // 000000404734: D73C0003
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 000000404738: 02021681
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000040473C: BF870093
	.long 0xd7006a07                                           // 000000404740: D7006A07
	v_cndmask_b32_e32 v1, v7, v9, vcc_lo                       // 000000404744: 02021307
	v_add_co_ci_u32_e64 v5, null, v5, v10, vcc_lo              // 000000404748: D5207C05 01AA1505
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000404750: BF870092
	.long 0xd7006a03                                           // 000000404754: D7006A03
	v_cndmask_b32_e32 v1, v7, v3, vcc_lo                       // 000000404758: 02020707
	v_add_co_ci_u32_e64 v4, null, v5, v4, vcc_lo               // 00000040475C: D5207C04 01AA0905
	global_store_d16_hi_b16 v[3:4], v6, off                    // 000000404764: DC960000 007C0603
	s_cbranch_execnz 62495                                     // 00000040476C: BFA6F41F <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	s_branch 8                                                 // 000000404770: BFA00008 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3394>
	s_branch 62493                                             // 000000404774: BFA0F41D <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	s_branch 65011                                             // 000000404778: BFA0FDF3 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2b48>
	s_branch 65085                                             // 00000040477C: BFA0FE3D <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2c74>
	s_branch 65158                                             // 000000404780: BFA0FE86 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2d9c>
	s_branch 65231                                             // 000000404784: BFA0FECF <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2ec4>
	s_branch 65304                                             // 000000404788: BFA0FF18 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2fec>
	s_branch 65378                                             // 00000040478C: BFA0FF62 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3118>
	s_branch 65452                                             // 000000404790: BFA0FFAC <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi4ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3244>
	.long 0xd7006a00                                           // 000000404794: D7006A00
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 000000404798: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 00000040479C: BF870001
	v_add_co_ci_u32_e64 v1, null, v8, v2, vcc_lo               // 0000004047A0: D5207C01 01AA0508
	global_store_d16_hi_b16 v[0:1], v6, off offset:224         // 0000004047A8: DC9600E0 007C0600
	s_endpgm                                                   // 0000004047B0: BFB00000
		...

