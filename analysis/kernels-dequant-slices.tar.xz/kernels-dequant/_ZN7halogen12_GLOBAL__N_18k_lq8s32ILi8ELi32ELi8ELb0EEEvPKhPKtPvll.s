0000000000592700 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi8ELi32ELi8ELb0EEEvPKhPKtPvll>:
; _ZN7halogen12_GLOBAL__N_18k_lq8s32ILi8ELi32ELi8ELb0EEEvPKhPKtPvll():
	s_clause 0x1                                               // 000000592700: BF850001
	s_load_b256 s[4:11], s[0:1], null                          // 000000592704: F40C0100 F8000000
	s_load_b64 s[12:13], s[0:1], 0x20                          // 00000059270C: F4040300 F8000020
	s_mov_b32 s3, 0                                            // 000000592714: BE830080
	v_lshrrev_b32_e32 v14, 5, v0                               // 000000592718: 321C0085
	v_dual_mov_b32 v6, 0 :: v_dual_and_b32 v15, 31, v0         // 00000059271C: CA240080 060E009F
	v_dual_mov_b32 v16, 0 :: v_dual_mov_b32 v5, 0              // 000000592724: CA100080 10040080
	.long 0x7e1a3880                                           // 00000059272C: 7E1A3880
	v_mov_b32_e32 v8, 0                                        // 000000592730: 7E100280
	s_waitcnt lgkmcnt(0)                                       // 000000592734: BF89FC07
	s_ashr_i32 s0, s11, 31                                     // 000000592738: 86009F0B
	.long 0xd451000e                                           // 00000059273C: D451000E
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 000000592740: 02001802
	s_lshr_b32 s0, s0, 28                                      // 000000592744: 85009C00
	v_dual_mov_b32 v1, s4 :: v_dual_mov_b32 v2, s5             // 000000592748: CA100004 01020005
	s_add_u32 s0, s10, s0                                      // 000000592750: 8000000A
	s_addc_u32 s1, s11, 0                                      // 000000592754: 8201800B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000592758: BF870499
	s_ashr_i64 s[0:1], s[0:1], 4                               // 00000059275C: 86808400
	s_add_u32 s15, s10, s0                                     // 000000592760: 800F000A
	s_addc_u32 s1, s11, s1                                     // 000000592764: 8201010B
	s_add_u32 s15, s15, 15                                     // 000000592768: 800F8F0F
	s_addc_u32 s1, s1, 0                                       // 00000059276C: 82018001
	s_and_b32 s15, s15, -16                                    // 000000592770: 8B0FD00F
	s_and_b32 s14, s14, exec_lo                                // 000000592774: 8B0E7E0E
	s_cselect_b32 s14, s2, 0                                   // 000000592778: 980E8002
	s_add_i32 s16, s0, 7                                       // 00000059277C: 81108700
	v_mad_u64_u32 v[10:11], null, s14, s15, v[1:2]             // 000000592780: D6FE7C0A 04041E0E
	s_ashr_i32 s17, s16, 31                                    // 000000592788: 86119F10
	s_mul_i32 s14, s14, s1                                     // 00000059278C: 960E010E
	s_lshr_b32 s17, s17, 29                                    // 000000592790: 85119D11
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000592794: BF870499
	s_add_i32 s16, s16, s17                                    // 000000592798: 81101110
	s_ashr_i32 s4, s16, 3                                      // 00000059279C: 86048310
	v_add_nc_u32_e32 v11, s14, v11                             // 0000005927A0: 4A16160E
	.long 0xd72c0003                                           // 0000005927A4: D72C0003
	v_cndmask_b32_e32 v1, s4, v14, vcc_lo                      // 0000005927A8: 02021C04
	.long 0xd7006a13                                           // 0000005927AC: D7006A13
	v_cndmask_b32_e32 v0, v10, v10, vcc_lo                     // 0000005927B0: 0200150A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000005927B4: BF870191
	v_add_co_ci_u32_e64 v20, null, s11, v11, vcc_lo            // 0000005927B8: D5207C14 01AA160B
	v_add_nc_u32_e32 v1, s4, v3                                // 0000005927C0: 4A020604
	v_add_nc_u32_e32 v17, v3, v15                              // 0000005927C4: 4A221F03
	v_mov_b32_e32 v7, 0                                        // 0000005927C8: 7E0E0280
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000005927CC: BF870193
	v_min_i32_e32 v18, s0, v1                                  // 0000005927D0: 22240200
	v_lshlrev_b32_e32 v12, 4, v17                              // 0000005927D4: 30182284
	s_delay_alu instid0(VALU_DEP_2)                            // 0000005927D8: BF870002
	v_cmp_lt_i32_e32 vcc_lo, v17, v18                          // 0000005927DC: 7C822511
	s_and_saveexec_b32 s1, vcc_lo                              // 0000005927E0: BE81206A
	s_cbranch_execz 19                                         // 0000005927E4: BFA50013 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi8ELi32ELi8ELb0EEEvPKhPKtPvll+0x134>
	v_lshlrev_b32_e32 v1, 4, v17                               // 0000005927E8: 30022284
	v_and_b32_e32 v3, -2, v17                                  // 0000005927EC: 360622C2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000005927F0: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000005927F4: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000005927F8: 3408069F
	.long 0xd7000001                                           // 0000005927FC: D7000001
	v_cndmask_b32_e32 v1, v10, v1, vcc_lo                      // 000000592800: 0202030A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000592804: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v11, v2, s0                  // 000000592808: D5207C02 0002050B
	.long 0xd7000003                                           // 000000592810: D7000003
	v_cndmask_b32_e32 v1, v19, v3, vcc_lo                      // 000000592814: 02020713
	v_add_co_ci_u32_e64 v4, null, v20, v4, s0                  // 000000592818: D5207C04 00020914
	s_clause 0x1                                               // 000000592820: BF850001
	global_load_b128 v[5:8], v[1:2], off                       // 000000592824: DC5E0000 057C0001
	global_load_d16_b16 v13, v[3:4], off                       // 00000059282C: DC820000 0D7C0003
	s_or_b32 exec_lo, exec_lo, s1                              // 000000592834: 8C7E017E
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v23, 0             // 000000592838: CA100080 16160080
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v25, 0             // 000000592840: CA100080 18180080
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v27, 0             // 000000592848: CA100080 1A1A0080
	v_mov_b32_e32 v21, 0                                       // 000000592850: 7E2A0280
	s_and_saveexec_b32 s1, vcc_lo                              // 000000592854: BE81206A
	s_cbranch_execz 559                                        // 000000592858: BFA5022F <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi8ELi32ELi8ELb0EEEvPKhPKtPvll+0xa18>
	v_dual_mov_b32 v21, 0 :: v_dual_add_nc_u32 v28, 0x200, v12 // 00000059285C: CA200080 151C18FF 00000200
	v_dual_mov_b32 v27, 0 :: v_dual_mov_b32 v26, 0             // 000000592868: CA100080 1B1A0080
	v_dual_mov_b32 v25, 0 :: v_dual_mov_b32 v24, 0             // 000000592870: CA100080 19180080
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v22, 0             // 000000592878: CA100080 17160080
	v_mov_b32_e32 v16, 0                                       // 000000592880: 7E200280
	s_mul_i32 s0, s11, 6                                       // 000000592884: 9600860B
	s_mul_hi_u32 s14, s10, 6                                   // 000000592888: 968E860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 00000059288C: 8484820A
	s_add_i32 s14, s14, s0                                     // 000000592890: 810E000E
	s_mul_i32 s16, s10, 6                                      // 000000592894: 9610860A
	s_mov_b32 s15, 0                                           // 000000592898: BE8F0080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 00000059289C: 848A810A
	s_branch 508                                               // 0000005928A0: BFA001FC <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi8ELi32ELi8ELb0EEEvPKhPKtPvll+0x994>
	s_or_b32 exec_lo, exec_lo, s17                             // 0000005928A4: 8C7E117E
	v_bfe_i32 v29, v5, 0, 8                                    // 0000005928A8: D611001D 02210105
	s_and_b32 s0, exec_lo, vcc_lo                              // 0000005928B0: 8B006A7E
	v_add_nc_u32_e32 v28, 0x200, v28                           // 0000005928B4: 4A3838FF 00000200
	s_or_b32 s15, s0, s15                                      // 0000005928BC: 8C0F0F00
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005928C0: BF870092
	v_cvt_f32_i32_e32 v29, v29                                 // 0000005928C4: 7E3A0B1D
	v_fma_mix_f32 v29, v13, v29, neg(0) op_sel_hi:[1,0,0]      // 0000005928C8: CC20001D 8A023B0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005928D0: BF870091
	v_bfe_u32 v30, v29, 16, 1                                  // 0000005928D4: D610001E 0205211D
	v_add3_u32 v29, v29, v30, 0x7fff                           // 0000005928DC: D655001D 03FE3D1D 00007FFF
	.long 0x7f3c3880                                           // 0000005928E8: 7F3C3880
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005928EC: BF8700A2
	.long 0x7e3c399d                                           // 0000005928F0: 7E3C399D
	v_bfe_i32 v29, v5, 8, 8                                    // 0000005928F4: D611001D 02211105
	v_cvt_f32_i32_e32 v29, v29                                 // 0000005928FC: 7E3A0B1D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000592900: BF870091
	v_fma_mix_f32 v29, v13, v29, neg(0) op_sel_hi:[1,0,0]      // 000000592904: CC20001D 8A023B0D
	v_bfe_u32 v31, v29, 16, 1                                  // 00000059290C: D610001F 0205211D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000592914: BF8701B1
	v_add3_u32 v29, v29, v31, 0x7fff                           // 000000592918: D655001D 03FE3F1D 00007FFF
	v_bfe_i32 v31, v5, 16, 8                                   // 000000592924: D611001F 02212105
	v_ashrrev_i32_e32 v5, 24, v5                               // 00000059292C: 340A0A98
	v_and_or_b32 v37, 0xffff0000, v29, v30                     // 000000592930: D6570025 047A3AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000059293C: BF870193
	v_cvt_f32_i32_e32 v31, v31                                 // 000000592940: 7E3E0B1F
	v_cvt_f32_i32_e32 v5, v5                                   // 000000592944: 7E0A0B05
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000592948: BF870112
	v_fma_mix_f32 v31, v13, v31, neg(0) op_sel_hi:[1,0,0]      // 00000059294C: CC20001F 8A023F0D
	v_fma_mix_f32 v5, v13, v5, neg(0) op_sel_hi:[1,0,0]        // 000000592954: CC200005 8A020B0D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000059295C: BF870092
	v_bfe_u32 v32, v31, 16, 1                                  // 000000592960: D6100020 0205211F
	v_add3_u32 v31, v31, v32, 0x7fff                           // 000000592968: D655001F 03FE411F 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000592974: BF870113
	v_bfe_u32 v32, v5, 16, 1                                   // 000000592978: D6100020 02052105
	.long 0x7e3e399f                                           // 000000592980: 7E3E399F
	.long 0x7f3e399e                                           // 000000592984: 7F3E399E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000592988: BF870093
	v_add3_u32 v5, v5, v32, 0x7fff                             // 00000059298C: D6550005 03FE4105 00007FFF
	v_and_or_b32 v38, 0xffff0000, v5, v31                      // 000000592998: D6570026 047E0AFF FFFF0000
	v_bfe_i32 v5, v6, 0, 8                                     // 0000005929A4: D6110005 02210106
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005929AC: BF870091
	v_cvt_f32_i32_e32 v5, v5                                   // 0000005929B0: 7E0A0B05
	v_fma_mix_f32 v5, v13, v5, neg(0) op_sel_hi:[1,0,0]        // 0000005929B4: CC200005 8A020B0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005929BC: BF870091
	v_bfe_u32 v29, v5, 16, 1                                   // 0000005929C0: D610001D 02052105
	v_add3_u32 v5, v5, v29, 0x7fff                             // 0000005929C8: D6550005 03FE3B05 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005929D4: BF8700A1
	.long 0x7e3c3985                                           // 0000005929D8: 7E3C3985
	v_bfe_i32 v5, v6, 8, 8                                     // 0000005929DC: D6110005 02211106
	v_cvt_f32_i32_e32 v5, v5                                   // 0000005929E4: 7E0A0B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005929E8: BF870091
	v_fma_mix_f32 v5, v13, v5, neg(0) op_sel_hi:[1,0,0]        // 0000005929EC: CC200005 8A020B0D
	v_bfe_u32 v29, v5, 16, 1                                   // 0000005929F4: D610001D 02052105
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000005929FC: BF8701B1
	v_add3_u32 v5, v5, v29, 0x7fff                             // 000000592A00: D6550005 03FE3B05 00007FFF
	v_bfe_i32 v29, v6, 16, 8                                   // 000000592A0C: D611001D 02212106
	v_ashrrev_i32_e32 v6, 24, v6                               // 000000592A14: 340C0C98
	v_and_or_b32 v39, 0xffff0000, v5, v30                      // 000000592A18: D6570027 047A0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000592A24: BF870193
	v_cvt_f32_i32_e32 v29, v29                                 // 000000592A28: 7E3A0B1D
	v_cvt_f32_i32_e32 v6, v6                                   // 000000592A2C: 7E0C0B06
	v_bfe_i32 v5, v7, 0, 8                                     // 000000592A30: D6110005 02210107
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000592A38: BF870193
	v_fma_mix_f32 v29, v13, v29, neg(0) op_sel_hi:[1,0,0]      // 000000592A3C: CC20001D 8A023B0D
	v_fma_mix_f32 v6, v13, v6, neg(0) op_sel_hi:[1,0,0]        // 000000592A44: CC200006 8A020D0D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000592A4C: BF870193
	v_cvt_f32_i32_e32 v5, v5                                   // 000000592A50: 7E0A0B05
	v_bfe_u32 v31, v29, 16, 1                                  // 000000592A54: D610001F 0205211D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000592A5C: BF870112
	v_fma_mix_f32 v5, v13, v5, neg(0) op_sel_hi:[1,0,0]        // 000000592A60: CC200005 8A020B0D
	v_add3_u32 v29, v29, v31, 0x7fff                           // 000000592A68: D655001D 03FE3F1D 00007FFF
	v_bfe_u32 v31, v6, 16, 1                                   // 000000592A74: D610001F 02052106
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000592A7C: BF8701A2
	.long 0x7e3a399d                                           // 000000592A80: 7E3A399D
	.long 0x7f3a399e                                           // 000000592A84: 7F3A399E
	v_add3_u32 v6, v6, v31, 0x7fff                             // 000000592A88: D6550006 03FE3F06 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000592A94: BF8700A1
	v_and_or_b32 v40, 0xffff0000, v6, v29                      // 000000592A98: D6570028 04760CFF FFFF0000
	v_bfe_u32 v6, v5, 16, 1                                    // 000000592AA4: D6100006 02052105
	v_add3_u32 v5, v5, v6, 0x7fff                              // 000000592AAC: D6550005 03FE0D05 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000592AB8: BF8700A1
	.long 0x7e3c3985                                           // 000000592ABC: 7E3C3985
	v_bfe_i32 v5, v7, 8, 8                                     // 000000592AC0: D6110005 02211107
	v_cvt_f32_i32_e32 v5, v5                                   // 000000592AC8: 7E0A0B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000592ACC: BF870091
	v_fma_mix_f32 v5, v13, v5, neg(0) op_sel_hi:[1,0,0]        // 000000592AD0: CC200005 8A020B0D
	v_bfe_u32 v6, v5, 16, 1                                    // 000000592AD8: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000592AE0: BF8701B1
	v_add3_u32 v5, v5, v6, 0x7fff                              // 000000592AE4: D6550005 03FE0D05 00007FFF
	v_bfe_i32 v6, v7, 16, 8                                    // 000000592AF0: D6110006 02212107
	v_ashrrev_i32_e32 v7, 24, v7                               // 000000592AF8: 340E0E98
	v_and_or_b32 v41, 0xffff0000, v5, v30                      // 000000592AFC: D6570029 047A0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000592B08: BF870193
	v_cvt_f32_i32_e32 v6, v6                                   // 000000592B0C: 7E0C0B06
	v_cvt_f32_i32_e32 v7, v7                                   // 000000592B10: 7E0E0B07
	v_bfe_i32 v5, v8, 0, 8                                     // 000000592B14: D6110005 02210108
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000592B1C: BF870193
	v_fma_mix_f32 v6, v13, v6, neg(0) op_sel_hi:[1,0,0]        // 000000592B20: CC200006 8A020D0D
	v_fma_mix_f32 v7, v13, v7, neg(0) op_sel_hi:[1,0,0]        // 000000592B28: CC200007 8A020F0D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000592B30: BF870193
	v_cvt_f32_i32_e32 v5, v5                                   // 000000592B34: 7E0A0B05
	v_bfe_u32 v29, v6, 16, 1                                   // 000000592B38: D610001D 02052106
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000592B40: BF870112
	v_fma_mix_f32 v5, v13, v5, neg(0) op_sel_hi:[1,0,0]        // 000000592B44: CC200005 8A020B0D
	v_add3_u32 v6, v6, v29, 0x7fff                             // 000000592B4C: D6550006 03FE3B06 00007FFF
	v_bfe_u32 v29, v7, 16, 1                                   // 000000592B58: D610001D 02052107
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000592B60: BF8701A2
	.long 0x7e0c3986                                           // 000000592B64: 7E0C3986
	.long 0x7f0c399e                                           // 000000592B68: 7F0C399E
	v_add3_u32 v7, v7, v29, 0x7fff                             // 000000592B6C: D6550007 03FE3B07 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000592B78: BF8700A1
	v_and_or_b32 v42, 0xffff0000, v7, v6                       // 000000592B7C: D657002A 041A0EFF FFFF0000
	v_bfe_u32 v6, v5, 16, 1                                    // 000000592B88: D6100006 02052105
	v_add3_u32 v5, v5, v6, 0x7fff                              // 000000592B90: D6550005 03FE0D05 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000592B9C: BF8700A1
	.long 0x7e3c3985                                           // 000000592BA0: 7E3C3985
	v_bfe_i32 v5, v8, 8, 8                                     // 000000592BA4: D6110005 02211108
	v_cvt_f32_i32_e32 v5, v5                                   // 000000592BAC: 7E0A0B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000592BB0: BF870091
	v_fma_mix_f32 v5, v13, v5, neg(0) op_sel_hi:[1,0,0]        // 000000592BB4: CC200005 8A020B0D
	v_bfe_u32 v6, v5, 16, 1                                    // 000000592BBC: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000592BC4: BF870121
	v_add3_u32 v5, v5, v6, 0x7fff                              // 000000592BC8: D6550005 03FE0D05 00007FFF
	v_bfe_i32 v6, v8, 16, 8                                    // 000000592BD4: D6110006 02212108
	v_and_or_b32 v43, 0xffff0000, v5, v30                      // 000000592BDC: D657002B 047A0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000592BE8: BF870092
	v_cvt_f32_i32_e32 v6, v6                                   // 000000592BEC: 7E0C0B06
	v_fma_mix_f32 v6, v13, v6, neg(0) op_sel_hi:[1,0,0]        // 000000592BF0: CC200006 8A020D0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000592BF8: BF870091
	v_bfe_u32 v7, v6, 16, 1                                    // 000000592BFC: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 000000592C04: D6550006 03FE0F06 00007FFF
	v_ashrrev_i32_e32 v7, 24, v8                               // 000000592C10: 340E1098
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000592C14: BF870112
	.long 0x7e0c3986                                           // 000000592C18: 7E0C3986
	v_cvt_f32_i32_e32 v7, v7                                   // 000000592C1C: 7E0E0B07
	.long 0x7f0c399e                                           // 000000592C20: 7F0C399E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000592C24: BF870122
	v_fma_mix_f32 v7, v13, v7, neg(0) op_sel_hi:[1,0,0]        // 000000592C28: CC200007 8A020F0D
	v_ashrrev_i32_e32 v13, 31, v12                             // 000000592C30: 341A189F
	v_bfe_u32 v8, v7, 16, 1                                    // 000000592C34: D6100008 02052107
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000592C3C: BF870091
	v_add3_u32 v7, v7, v8, 0x7fff                              // 000000592C40: D6550007 03FE1107 00007FFF
	v_and_or_b32 v44, 0xffff0000, v7, v6                       // 000000592C4C: D657002C 041A0EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000592C58: BF8701C4
	.long 0xd73c0005                                           // 000000592C5C: D73C0005
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 000000592C60: 02021881
	s_waitcnt vmcnt(0)                                         // 000000592C64: BF8903F7
	.long 0x7e1a3909                                           // 000000592C68: 7E1A3909
	v_add_nc_u32_e32 v12, 0x200, v12                           // 000000592C6C: 4A1818FF 00000200
	.long 0xd7006a21                                           // 000000592C74: D7006A21
	v_cndmask_b32_e32 v1, s6, v5, vcc_lo                       // 000000592C78: 02020A06
	s_delay_alu instid0(VALU_DEP_1)                            // 000000592C7C: BF870001
	v_add_co_ci_u32_e64 v34, null, s7, v6, vcc_lo              // 000000592C80: D5207C22 01AA0C07
	s_clause 0x1                                               // 000000592C88: BF850001
	global_load_b128 v[5:8], v[33:34], off                     // 000000592C8C: DC5E0000 057C0021
	global_load_b128 v[29:32], v[33:34], off offset:16         // 000000592C94: DC5E0010 1D7C0021
	s_waitcnt vmcnt(1)                                         // 000000592C9C: BF8907F7
	v_dot2_f32_bf16 v5, v5, v37, 0                             // 000000592CA0: CC1A4005 1A024B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000592CA8: BF870091
	v_dot2_f32_bf16 v5, v6, v38, v5                            // 000000592CAC: CC1A4005 1C164D06
	v_dot2_f32_bf16 v5, v7, v39, v5                            // 000000592CB4: CC1A4005 1C164F07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000592CBC: BF8700A1
	v_dot2_f32_bf16 v5, v8, v40, v5                            // 000000592CC0: CC1A4005 1C165108
	s_waitcnt vmcnt(0)                                         // 000000592CC8: BF8903F7
	v_dot2_f32_bf16 v5, v29, v41, v5                           // 000000592CCC: CC1A4005 1C16531D
	.long 0xd7006a1d                                           // 000000592CD4: D7006A1D
	v_cndmask_b32_e32 v0, v33, v10, vcc_lo                     // 000000592CD8: 02001521
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000592CDC: BF8701B2
	v_dot2_f32_bf16 v5, v30, v42, v5                           // 000000592CE0: CC1A4005 1C16551E
	v_add_co_ci_u32_e64 v30, null, s11, v34, vcc_lo            // 000000592CE8: D5207C1E 01AA440B
	.long 0xd7006a23                                           // 000000592CF0: D7006A23
	v_cndmask_b32_e32 v0, v33, v4, vcc_lo                      // 000000592CF4: 02000921
	v_dot2_f32_bf16 v5, v31, v43, v5                           // 000000592CF8: CC1A4005 1C16571F
	v_add_co_ci_u32_e64 v36, null, s5, v34, vcc_lo             // 000000592D00: D5207C24 01AA4405
	.long 0xd7006a21                                           // 000000592D08: D7006A21
	v_cndmask_b32_e32 v0, v33, v16, vcc_lo                     // 000000592D0C: 02002121
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000592D10: BF870123
	v_dot2_f32_bf16 v5, v32, v44, v5                           // 000000592D14: CC1A4005 1C165920
	v_add_co_ci_u32_e64 v34, null, s14, v34, vcc_lo            // 000000592D1C: D5207C22 01AA440E
	v_add_f32_e32 v21, v21, v5                                 // 000000592D24: 062A0B15
	s_clause 0x1                                               // 000000592D28: BF850001
	global_load_b128 v[5:8], v[29:30], off                     // 000000592D2C: DC5E0000 057C001D
	global_load_b128 v[29:32], v[29:30], off offset:16         // 000000592D34: DC5E0010 1D7C001D
	s_waitcnt vmcnt(1)                                         // 000000592D3C: BF8907F7
	v_dot2_f32_bf16 v5, v5, v37, 0                             // 000000592D40: CC1A4005 1A024B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000592D48: BF870091
	v_dot2_f32_bf16 v5, v6, v38, v5                            // 000000592D4C: CC1A4005 1C164D06
	v_dot2_f32_bf16 v5, v7, v39, v5                            // 000000592D54: CC1A4005 1C164F07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000592D5C: BF8700A1
	v_dot2_f32_bf16 v5, v8, v40, v5                            // 000000592D60: CC1A4005 1C165108
	s_waitcnt vmcnt(0)                                         // 000000592D68: BF8903F7
	v_dot2_f32_bf16 v5, v29, v41, v5                           // 000000592D6C: CC1A4005 1C16531D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000592D74: BF870091
	v_dot2_f32_bf16 v5, v30, v42, v5                           // 000000592D78: CC1A4005 1C16551E
	v_dot2_f32_bf16 v5, v31, v43, v5                           // 000000592D80: CC1A4005 1C16571F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000592D88: BF870091
	v_dot2_f32_bf16 v5, v32, v44, v5                           // 000000592D8C: CC1A4005 1C165920
	v_add_f32_e32 v27, v27, v5                                 // 000000592D94: 06360B1B
	s_clause 0x1                                               // 000000592D98: BF850001
	global_load_b128 v[5:8], v[35:36], off                     // 000000592D9C: DC5E0000 057C0023
	global_load_b128 v[29:32], v[35:36], off offset:16         // 000000592DA4: DC5E0010 1D7C0023
	.long 0xd7006a23                                           // 000000592DAC: D7006A23
	v_cndmask_b32_e32 v0, v35, v4, vcc_lo                      // 000000592DB0: 02000923
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000592DB4: BF8700B1
	v_add_co_ci_u32_e64 v36, null, s5, v36, vcc_lo             // 000000592DB8: D5207C24 01AA4805
	s_waitcnt vmcnt(1)                                         // 000000592DC0: BF8907F7
	v_dot2_f32_bf16 v5, v5, v37, 0                             // 000000592DC4: CC1A4005 1A024B05
	v_dot2_f32_bf16 v5, v6, v38, v5                            // 000000592DCC: CC1A4005 1C164D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000592DD4: BF870091
	v_dot2_f32_bf16 v5, v7, v39, v5                            // 000000592DD8: CC1A4005 1C164F07
	v_dot2_f32_bf16 v5, v8, v40, v5                            // 000000592DE0: CC1A4005 1C165108
	s_waitcnt vmcnt(0)                                         // 000000592DE8: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000592DEC: BF870091
	v_dot2_f32_bf16 v5, v29, v41, v5                           // 000000592DF0: CC1A4005 1C16531D
	v_dot2_f32_bf16 v5, v30, v42, v5                           // 000000592DF8: CC1A4005 1C16551E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000592E00: BF870091
	v_dot2_f32_bf16 v5, v31, v43, v5                           // 000000592E04: CC1A4005 1C16571F
	v_dot2_f32_bf16 v5, v32, v44, v5                           // 000000592E0C: CC1A4005 1C165920
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000592E14: BF8700D1
	v_add_f32_e32 v26, v26, v5                                 // 000000592E18: 06340B1A
	s_clause 0x1                                               // 000000592E1C: BF850001
	global_load_b128 v[5:8], v[33:34], off                     // 000000592E20: DC5E0000 057C0021
	global_load_b128 v[29:32], v[33:34], off offset:16         // 000000592E28: DC5E0010 1D7C0021
	.long 0xd7006a21                                           // 000000592E30: D7006A21
	v_cndmask_b32_e32 v0, v33, v4, vcc_lo                      // 000000592E34: 02000921
	v_add_co_ci_u32_e64 v34, null, s5, v34, vcc_lo             // 000000592E38: D5207C22 01AA4405
	s_waitcnt vmcnt(1)                                         // 000000592E40: BF8907F7
	v_dot2_f32_bf16 v5, v5, v37, 0                             // 000000592E44: CC1A4005 1A024B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000592E4C: BF870091
	v_dot2_f32_bf16 v5, v6, v38, v5                            // 000000592E50: CC1A4005 1C164D06
	v_dot2_f32_bf16 v5, v7, v39, v5                            // 000000592E58: CC1A4005 1C164F07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000592E60: BF8700A1
	v_dot2_f32_bf16 v5, v8, v40, v5                            // 000000592E64: CC1A4005 1C165108
	s_waitcnt vmcnt(0)                                         // 000000592E6C: BF8903F7
	v_dot2_f32_bf16 v5, v29, v41, v5                           // 000000592E70: CC1A4005 1C16531D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000592E78: BF870091
	v_dot2_f32_bf16 v5, v30, v42, v5                           // 000000592E7C: CC1A4005 1C16551E
	v_dot2_f32_bf16 v5, v31, v43, v5                           // 000000592E84: CC1A4005 1C16571F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000592E8C: BF870091
	v_dot2_f32_bf16 v5, v32, v44, v5                           // 000000592E90: CC1A4005 1C165920
	v_add_f32_e32 v25, v25, v5                                 // 000000592E98: 06320B19
	s_clause 0x1                                               // 000000592E9C: BF850001
	global_load_b128 v[5:8], v[35:36], off                     // 000000592EA0: DC5E0000 057C0023
	global_load_b128 v[29:32], v[35:36], off offset:16         // 000000592EA8: DC5E0010 1D7C0023
	s_waitcnt vmcnt(1)                                         // 000000592EB0: BF8907F7
	v_dot2_f32_bf16 v5, v5, v37, 0                             // 000000592EB4: CC1A4005 1A024B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000592EBC: BF870091
	v_dot2_f32_bf16 v5, v6, v38, v5                            // 000000592EC0: CC1A4005 1C164D06
	v_dot2_f32_bf16 v5, v7, v39, v5                            // 000000592EC8: CC1A4005 1C164F07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000592ED0: BF8700A1
	v_dot2_f32_bf16 v5, v8, v40, v5                            // 000000592ED4: CC1A4005 1C165108
	s_waitcnt vmcnt(0)                                         // 000000592EDC: BF8903F7
	v_dot2_f32_bf16 v5, v29, v41, v5                           // 000000592EE0: CC1A4005 1C16531D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000592EE8: BF870091
	v_dot2_f32_bf16 v5, v30, v42, v5                           // 000000592EEC: CC1A4005 1C16551E
	v_dot2_f32_bf16 v5, v31, v43, v5                           // 000000592EF4: CC1A4005 1C16571F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000592EFC: BF870091
	v_dot2_f32_bf16 v5, v32, v44, v5                           // 000000592F00: CC1A4005 1C165920
	v_add_f32_e32 v24, v24, v5                                 // 000000592F08: 06300B18
	s_clause 0x1                                               // 000000592F0C: BF850001
	global_load_b128 v[5:8], v[33:34], off                     // 000000592F10: DC5E0000 057C0021
	global_load_b128 v[29:32], v[33:34], off offset:16         // 000000592F18: DC5E0010 1D7C0021
	s_waitcnt vmcnt(1)                                         // 000000592F20: BF8907F7
	v_dot2_f32_bf16 v5, v5, v37, 0                             // 000000592F24: CC1A4005 1A024B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000592F2C: BF870091
	v_dot2_f32_bf16 v5, v6, v38, v5                            // 000000592F30: CC1A4005 1C164D06
	v_dot2_f32_bf16 v5, v7, v39, v5                            // 000000592F38: CC1A4005 1C164F07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000592F40: BF8700A1
	v_dot2_f32_bf16 v5, v8, v40, v5                            // 000000592F44: CC1A4005 1C165108
	s_waitcnt vmcnt(0)                                         // 000000592F4C: BF8903F7
	v_dot2_f32_bf16 v5, v29, v41, v5                           // 000000592F50: CC1A4005 1C16531D
	.long 0xd7006a1d                                           // 000000592F58: D7006A1D
	v_cndmask_b32_e32 v0, v35, v4, vcc_lo                      // 000000592F5C: 02000923
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000592F60: BF870122
	v_dot2_f32_bf16 v5, v30, v42, v5                           // 000000592F64: CC1A4005 1C16551E
	v_add_co_ci_u32_e64 v30, null, s5, v36, vcc_lo             // 000000592F6C: D5207C1E 01AA4805
	v_dot2_f32_bf16 v5, v31, v43, v5                           // 000000592F74: CC1A4005 1C16571F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000592F7C: BF870091
	v_dot2_f32_bf16 v5, v32, v44, v5                           // 000000592F80: CC1A4005 1C165920
	v_add_f32_e32 v23, v23, v5                                 // 000000592F88: 062E0B17
	s_clause 0x1                                               // 000000592F8C: BF850001
	global_load_b128 v[5:8], v[29:30], off                     // 000000592F90: DC5E0000 057C001D
	global_load_b128 v[29:32], v[29:30], off offset:16         // 000000592F98: DC5E0010 1D7C001D
	s_waitcnt vmcnt(1)                                         // 000000592FA0: BF8907F7
	v_dot2_f32_bf16 v5, v5, v37, 0                             // 000000592FA4: CC1A4005 1A024B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000592FAC: BF870091
	v_dot2_f32_bf16 v5, v6, v38, v5                            // 000000592FB0: CC1A4005 1C164D06
	v_dot2_f32_bf16 v5, v7, v39, v5                            // 000000592FB8: CC1A4005 1C164F07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000592FC0: BF8700A1
	v_dot2_f32_bf16 v5, v8, v40, v5                            // 000000592FC4: CC1A4005 1C165108
	s_waitcnt vmcnt(0)                                         // 000000592FCC: BF8903F7
	v_dot2_f32_bf16 v5, v29, v41, v5                           // 000000592FD0: CC1A4005 1C16531D
	.long 0xd7006a1d                                           // 000000592FD8: D7006A1D
	v_cndmask_b32_e32 v0, v33, v4, vcc_lo                      // 000000592FDC: 02000921
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000592FE0: BF870122
	v_dot2_f32_bf16 v5, v30, v42, v5                           // 000000592FE4: CC1A4005 1C16551E
	v_add_co_ci_u32_e64 v30, null, s5, v34, vcc_lo             // 000000592FEC: D5207C1E 01AA4405
	v_dot2_f32_bf16 v5, v31, v43, v5                           // 000000592FF4: CC1A4005 1C16571F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000592FFC: BF870091
	v_dot2_f32_bf16 v5, v32, v44, v5                           // 000000593000: CC1A4005 1C165920
	v_add_f32_e32 v22, v22, v5                                 // 000000593008: 062C0B16
	s_clause 0x1                                               // 00000059300C: BF850001
	global_load_b128 v[5:8], v[29:30], off                     // 000000593010: DC5E0000 057C001D
	global_load_b128 v[29:32], v[29:30], off offset:16         // 000000593018: DC5E0010 1D7C001D
	s_waitcnt vmcnt(1)                                         // 000000593020: BF8907F7
	v_dot2_f32_bf16 v5, v5, v37, 0                             // 000000593024: CC1A4005 1A024B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000059302C: BF870121
	v_dot2_f32_bf16 v5, v6, v38, v5                            // 000000593030: CC1A4005 1C164D06
	v_mov_b32_e32 v6, v2                                       // 000000593038: 7E0C0302
	v_dot2_f32_bf16 v5, v7, v39, v5                            // 00000059303C: CC1A4005 1C164F07
	v_mov_b32_e32 v7, v3                                       // 000000593044: 7E0E0303
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000593048: BF870132
	v_dot2_f32_bf16 v5, v8, v40, v5                            // 00000059304C: CC1A4005 1C165108
	v_mov_b32_e32 v8, v4                                       // 000000593054: 7E100304
	s_waitcnt vmcnt(0)                                         // 000000593058: BF8903F7
	v_dot2_f32_bf16 v5, v29, v41, v5                           // 00000059305C: CC1A4005 1C16531D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000593064: BF870091
	v_dot2_f32_bf16 v5, v30, v42, v5                           // 000000593068: CC1A4005 1C16551E
	v_dot2_f32_bf16 v5, v31, v43, v5                           // 000000593070: CC1A4005 1C16571F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000593078: BF870091
	v_dot2_f32_bf16 v5, v32, v44, v5                           // 00000059307C: CC1A4005 1C165920
	v_dual_add_f32 v16, v16, v5 :: v_dual_mov_b32 v5, v1       // 000000593084: C9100B10 10040101
	s_and_not1_b32 exec_lo, exec_lo, s15                       // 00000059308C: 917E0F7E
	s_cbranch_execz 32                                         // 000000593090: BFA50020 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi8ELi32ELi8ELb0EEEvPKhPKtPvll+0xa14>
	s_waitcnt vmcnt(1)                                         // 000000593094: BF8907F7
	v_dual_mov_b32 v2, v6 :: v_dual_add_nc_u32 v17, 32, v17    // 000000593098: CA200106 021022A0
	s_waitcnt vmcnt(0)                                         // 0000005930A0: BF8903F7
	.long 0x7e12390d                                           // 0000005930A4: 7E12390D
	v_dual_mov_b32 v1, v5 :: v_dual_mov_b32 v4, v8             // 0000005930A8: CA100105 01040108
	v_mov_b32_e32 v3, v7                                       // 0000005930B0: 7E060307
	s_mov_b32 s17, exec_lo                                     // 0000005930B4: BE91007E
	v_cmp_ge_i32_e32 vcc_lo, v17, v18                          // 0000005930B8: 7C8C2511
	.long 0xd4c1007e                                           // 0000005930BC: D4C1007E
	v_cndmask_b32_e32 v1, v17, v18, vcc_lo                     // 0000005930C0: 02022511
	s_cbranch_execz 65015                                      // 0000005930C4: BFA5FDF7 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi8ELi32ELi8ELb0EEEvPKhPKtPvll+0x1a4>
	v_and_b32_e32 v3, -2, v17                                  // 0000005930C8: 360622C2
	v_ashrrev_i32_e32 v2, 31, v28                              // 0000005930CC: 3404389F
	.long 0xd7000001                                           // 0000005930D0: D7000001
	v_cndmask_b32_e32 v1, v10, v28, vcc_lo                     // 0000005930D4: 0202390A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000005930D8: BF870193
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000005930DC: 3408069F
	v_add_co_ci_u32_e64 v2, null, v11, v2, s0                  // 0000005930E0: D5207C02 0002050B
	.long 0xd700001d                                           // 0000005930E8: D700001D
	v_cndmask_b32_e32 v1, v19, v3, vcc_lo                      // 0000005930EC: 02020713
	s_delay_alu instid0(VALU_DEP_1)                            // 0000005930F0: BF870001
	v_add_co_ci_u32_e64 v30, null, v20, v4, s0                 // 0000005930F4: D5207C1E 00020914
	s_clause 0x1                                               // 0000005930FC: BF850001
	global_load_b128 v[1:4], v[1:2], off                       // 000000593100: DC5E0000 017C0001
	global_load_d16_b16 v9, v[29:30], off                      // 000000593108: DC820000 097C001D
	s_branch 64996                                             // 000000593110: BFA0FDE4 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi8ELi32ELi8ELb0EEEvPKhPKtPvll+0x1a4>
	s_or_b32 exec_lo, exec_lo, s15                             // 000000593114: 8C7E0F7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000593118: BF8700B9
	s_or_b32 exec_lo, exec_lo, s1                              // 00000059311C: 8C7E017E
	.long 0xd71f0001                                           // 000000593120: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000593124: 020100C1
	s_mov_b32 s0, exec_lo                                      // 000000593128: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 00000059312C: 3A040290
	v_xor_b32_e32 v10, 8, v1                                   // 000000593130: 3A140288
	v_xor_b32_e32 v20, 4, v1                                   // 000000593134: 3A280284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000593138: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 00000059313C: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 000000593140: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 000000593144: 7C9814A0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000593148: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 00000059314C: 30040482
	ds_bpermute_b32 v3, v2, v21                                // 000000593150: DACC0000 03001502
	s_waitcnt lgkmcnt(0)                                       // 000000593158: BF89FC07
	v_add_f32_e32 v3, v21, v3                                  // 00000059315C: 06060715
	s_waitcnt vmcnt(1)                                         // 000000593160: BF8907F7
	ds_bpermute_b32 v7, v2, v24                                // 000000593164: DACC0000 07001802
	ds_bpermute_b32 v9, v2, v22                                // 00000059316C: DACC0000 09001602
	v_cndmask_b32_e32 v10, v1, v10, vcc_lo                     // 000000593174: 02141501
	ds_bpermute_b32 v5, v2, v26                                // 000000593178: DACC0000 05001A02
	ds_bpermute_b32 v8, v2, v23                                // 000000593180: DACC0000 08001702
	ds_bpermute_b32 v6, v2, v25                                // 000000593188: DACC0000 06001902
	ds_bpermute_b32 v4, v2, v27                                // 000000593190: DACC0000 04001B02
	ds_bpermute_b32 v2, v2, v16                                // 000000593198: DACC0000 02001002
	v_cmp_gt_u32_e32 vcc_lo, 32, v20                           // 0000005931A0: 7C9828A0
	s_waitcnt lgkmcnt(6)                                       // 0000005931A4: BF89FC67
	v_dual_add_f32 v7, v24, v7 :: v_dual_lshlrev_b32 v10, 2, v10// 0000005931A8: C9220F18 070A1482
	s_waitcnt lgkmcnt(5)                                       // 0000005931B0: BF89FC57
	v_add_f32_e32 v9, v22, v9                                  // 0000005931B4: 06121316
	s_waitcnt lgkmcnt(4)                                       // 0000005931B8: BF89FC47
	v_add_f32_e32 v5, v26, v5                                  // 0000005931BC: 060A0B1A
	ds_bpermute_b32 v11, v10, v3                               // 0000005931C0: DACC0000 0B00030A
	ds_bpermute_b32 v19, v10, v9                               // 0000005931C8: DACC0000 1300090A
	s_waitcnt lgkmcnt(5)                                       // 0000005931D0: BF89FC57
	v_add_f32_e32 v8, v23, v8                                  // 0000005931D4: 06101117
	s_waitcnt vmcnt(0)                                         // 0000005931D8: BF8903F7
	ds_bpermute_b32 v13, v10, v5                               // 0000005931DC: DACC0000 0D00050A
	ds_bpermute_b32 v17, v10, v7                               // 0000005931E4: DACC0000 1100070A
	s_waitcnt lgkmcnt(6)                                       // 0000005931EC: BF89FC67
	v_add_f32_e32 v6, v25, v6                                  // 0000005931F0: 060C0D19
	s_waitcnt lgkmcnt(5)                                       // 0000005931F4: BF89FC57
	v_add_f32_e32 v4, v27, v4                                  // 0000005931F8: 0608091B
	s_waitcnt lgkmcnt(3)                                       // 0000005931FC: BF89FC37
	v_dual_add_f32 v2, v16, v2 :: v_dual_add_f32 v3, v3, v11   // 000000593200: C9080510 02021703
	s_waitcnt lgkmcnt(2)                                       // 000000593208: BF89FC27
	v_add_f32_e32 v9, v9, v19                                  // 00000059320C: 06122709
	ds_bpermute_b32 v18, v10, v8                               // 000000593210: DACC0000 1200080A
	v_cndmask_b32_e32 v20, v1, v20, vcc_lo                     // 000000593218: 02282901
	ds_bpermute_b32 v16, v10, v6                               // 00000059321C: DACC0000 1000060A
	s_waitcnt lgkmcnt(3)                                       // 000000593224: BF89FC37
	v_add_f32_e32 v5, v5, v13                                  // 000000593228: 060A1B05
	ds_bpermute_b32 v12, v10, v4                               // 00000059322C: DACC0000 0C00040A
	s_waitcnt lgkmcnt(3)                                       // 000000593234: BF89FC37
	v_dual_add_f32 v7, v7, v17 :: v_dual_lshlrev_b32 v20, 2, v20// 000000593238: C9222307 07142882
	ds_bpermute_b32 v10, v10, v2                               // 000000593240: DACC0000 0A00020A
	s_waitcnt lgkmcnt(3)                                       // 000000593248: BF89FC37
	v_add_f32_e32 v8, v8, v18                                  // 00000059324C: 06102508
	ds_bpermute_b32 v18, v20, v9                               // 000000593250: DACC0000 12000914
	s_waitcnt lgkmcnt(1)                                       // 000000593258: BF89FC17
	v_add_f32_e32 v2, v2, v10                                  // 00000059325C: 06041502
	s_waitcnt lgkmcnt(0)                                       // 000000593260: BF89FC07
	v_add_f32_e32 v9, v9, v18                                  // 000000593264: 06122509
	ds_bpermute_b32 v10, v20, v3                               // 000000593268: DACC0000 0A000314
	s_waitcnt lgkmcnt(0)                                       // 000000593270: BF89FC07
	v_dual_add_f32 v3, v3, v10 :: v_dual_add_f32 v6, v6, v16   // 000000593274: C9081503 03062106
	ds_bpermute_b32 v16, v20, v7                               // 00000059327C: DACC0000 10000714
	ds_bpermute_b32 v13, v20, v6                               // 000000593284: DACC0000 0D000614
	s_waitcnt lgkmcnt(1)                                       // 00000059328C: BF89FC17
	v_add_f32_e32 v7, v7, v16                                  // 000000593290: 060E2107
	ds_bpermute_b32 v19, v20, v2                               // 000000593294: DACC0000 13000214
	v_add_f32_e32 v4, v4, v12                                  // 00000059329C: 06081904
	ds_bpermute_b32 v12, v20, v5                               // 0000005932A0: DACC0000 0C000514
	s_waitcnt lgkmcnt(2)                                       // 0000005932A8: BF89FC27
	v_add_f32_e32 v6, v6, v13                                  // 0000005932AC: 060C1B06
	ds_bpermute_b32 v11, v20, v4                               // 0000005932B0: DACC0000 0B000414
	s_waitcnt lgkmcnt(1)                                       // 0000005932B8: BF89FC17
	v_add_f32_e32 v5, v5, v12                                  // 0000005932BC: 060A1905
	ds_bpermute_b32 v17, v20, v8                               // 0000005932C0: DACC0000 11000814
	v_xor_b32_e32 v20, 2, v1                                   // 0000005932C8: 3A280282
	s_waitcnt lgkmcnt(1)                                       // 0000005932CC: BF89FC17
	v_add_f32_e32 v4, v4, v11                                  // 0000005932D0: 06081704
	v_add_f32_e32 v11, v2, v19                                 // 0000005932D4: 06162702
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000005932D8: BF870143
	v_cmp_gt_u32_e32 vcc_lo, 32, v20                           // 0000005932DC: 7C9828A0
	v_cndmask_b32_e32 v20, v1, v20, vcc_lo                     // 0000005932E0: 02282901
	s_waitcnt lgkmcnt(0)                                       // 0000005932E4: BF89FC07
	v_add_f32_e32 v8, v8, v17                                  // 0000005932E8: 06102308
	v_lshlrev_b32_e32 v20, 2, v20                              // 0000005932EC: 30282882
	ds_bpermute_b32 v2, v20, v3                                // 0000005932F0: DACC0000 02000314
	ds_bpermute_b32 v10, v20, v4                               // 0000005932F8: DACC0000 0A000414
	ds_bpermute_b32 v12, v20, v5                               // 000000593300: DACC0000 0C000514
	ds_bpermute_b32 v13, v20, v6                               // 000000593308: DACC0000 0D000614
	ds_bpermute_b32 v16, v20, v7                               // 000000593310: DACC0000 10000714
	ds_bpermute_b32 v17, v20, v8                               // 000000593318: DACC0000 11000814
	ds_bpermute_b32 v18, v20, v9                               // 000000593320: DACC0000 12000914
	ds_bpermute_b32 v19, v20, v11                              // 000000593328: DACC0000 13000B14
	v_xor_b32_e32 v20, 1, v1                                   // 000000593330: 3A280281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000593334: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v20                           // 000000593338: 7C9828A0
	v_cndmask_b32_e32 v1, v1, v20, vcc_lo                      // 00000059333C: 02022901
	s_waitcnt lgkmcnt(7)                                       // 000000593340: BF89FC77
	v_dual_add_f32 v1, v3, v2 :: v_dual_lshlrev_b32 v20, 2, v1 // 000000593344: C9220503 01140282
	s_waitcnt lgkmcnt(6)                                       // 00000059334C: BF89FC67
	v_add_f32_e32 v2, v4, v10                                  // 000000593350: 06041504
	s_waitcnt lgkmcnt(5)                                       // 000000593354: BF89FC57
	v_add_f32_e32 v4, v5, v12                                  // 000000593358: 06081905
	s_waitcnt lgkmcnt(3)                                       // 00000059335C: BF89FC37
	v_add_f32_e32 v3, v7, v16                                  // 000000593360: 06062107
	v_add_f32_e32 v5, v6, v13                                  // 000000593364: 060A1B06
	s_waitcnt lgkmcnt(1)                                       // 000000593368: BF89FC17
	v_dual_add_f32 v7, v8, v17 :: v_dual_add_f32 v10, v9, v18  // 00000059336C: C9082308 070A2509
	s_waitcnt lgkmcnt(0)                                       // 000000593374: BF89FC07
	v_add_f32_e32 v12, v11, v19                                // 000000593378: 0618270B
	ds_bpermute_b32 v6, v20, v1                                // 00000059337C: DACC0000 06000114
	ds_bpermute_b32 v8, v20, v2                                // 000000593384: DACC0000 08000214
	ds_bpermute_b32 v11, v20, v4                               // 00000059338C: DACC0000 0B000414
	ds_bpermute_b32 v13, v20, v5                               // 000000593394: DACC0000 0D000514
	ds_bpermute_b32 v9, v20, v3                                // 00000059339C: DACC0000 09000314
	ds_bpermute_b32 v16, v20, v7                               // 0000005933A4: DACC0000 10000714
	ds_bpermute_b32 v17, v20, v10                              // 0000005933AC: DACC0000 11000A14
	ds_bpermute_b32 v18, v20, v12                              // 0000005933B4: DACC0000 12000C14
	v_cmpx_eq_u32_e32 0, v15                                   // 0000005933BC: 7D941E80
	s_cbranch_execz 14                                         // 0000005933C0: BFA5000E <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi8ELi32ELi8ELb0EEEvPKhPKtPvll+0xcfc>
	s_waitcnt lgkmcnt(0)                                       // 0000005933C4: BF89FC07
	v_dual_add_f32 v18, v12, v18 :: v_dual_add_f32 v17, v10, v17// 0000005933C8: C908250C 1210230A
	v_dual_add_f32 v16, v7, v16 :: v_dual_add_f32 v13, v5, v13 // 0000005933D0: C9082107 100C1B05
	v_dual_add_f32 v12, v4, v11 :: v_dual_add_f32 v11, v2, v8  // 0000005933D8: C9081704 0C0A1102
	v_dual_add_f32 v10, v1, v6 :: v_dual_add_f32 v15, v3, v9   // 0000005933E0: C9080D01 0A0E1303
	v_lshlrev_b32_e32 v1, 5, v14                               // 0000005933E8: 30021C85
	ds_store_b128 v1, v[10:13]                                 // 0000005933EC: DB7C0000 00000A01
	ds_store_b128 v1, v[15:18] offset:16                       // 0000005933F4: DB7C0010 00000F01
	s_or_b32 exec_lo, exec_lo, s0                              // 0000005933FC: 8C7E007E
	.long 0xd4510000                                           // 000000593400: D4510000
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 000000593404: 02001802
	v_cmp_gt_u32_e32 vcc_lo, 8, v0                             // 000000593408: 7C980088
	s_waitcnt lgkmcnt(0)                                       // 00000059340C: BF89FC07
	s_barrier                                                  // 000000593410: BFBD0000
	buffer_gl0_inv                                             // 000000593414: E0AC0000 00000000
	s_and_b32 s0, vcc_lo, s0                                   // 00000059341C: 8B00006A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000593420: BF870009
	s_and_saveexec_b32 s1, s0                                  // 000000593424: BE812000
	s_cbranch_execz 50                                         // 000000593428: BFA50032 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi8ELi32ELi8ELb0EEEvPKhPKtPvll+0xdf4>
	v_lshlrev_b32_e32 v7, 2, v0                                // 00000059342C: 300E0082
	s_lshl_b64 s[0:1], s[2:3], 1                               // 000000593430: 84808102
	ds_load_2addr_b32 v[1:2], v7 offset1:8                     // 000000593434: D8DC0800 01000007
	ds_load_2addr_b32 v[3:4], v7 offset0:16 offset1:24         // 00000059343C: D8DC1810 03000007
	ds_load_2addr_b32 v[5:6], v7 offset0:32 offset1:40         // 000000593444: D8DC2820 05000007
	s_waitcnt lgkmcnt(2)                                       // 00000059344C: BF89FC27
	v_add_f32_e32 v1, 0, v1                                    // 000000593450: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000593454: BF8700A1
	v_add_f32_e32 v1, v1, v2                                   // 000000593458: 06020501
	s_waitcnt lgkmcnt(1)                                       // 00000059345C: BF89FC17
	v_add_f32_e32 v1, v1, v3                                   // 000000593460: 06020701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000593464: BF870131
	v_add_f32_e32 v3, v1, v4                                   // 000000593468: 06060901
	v_mad_u64_u32 v[1:2], null, s12, v0, 0                     // 00000059346C: D6FE7C01 0202000C
	s_waitcnt lgkmcnt(0)                                       // 000000593474: BF89FC07
	v_add_f32_e32 v3, v3, v5                                   // 000000593478: 06060B03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000059347C: BF8700D1
	v_add_f32_e32 v4, v3, v6                                   // 000000593480: 06080D03
	ds_load_2addr_b32 v[7:8], v7 offset0:48 offset1:56         // 000000593484: D8DC3830 07000007
	v_mad_u64_u32 v[2:3], null, s13, v0, v[2:3]                // 00000059348C: D6FE7C02 040A000D
	s_waitcnt lgkmcnt(0)                                       // 000000593494: BF89FC07
	v_add_f32_e32 v0, v4, v7                                   // 000000593498: 06000F04
	v_add_f32_e32 v3, v0, v8                                   // 00000059349C: 06061100
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000005934A0: BF870113
	.long 0xd73c0000                                           // 0000005934A4: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000005934A8: 02020281
	v_bfe_u32 v2, v3, 16, 1                                    // 0000005934AC: D6100002 02052103
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005934B4: BF870092
	.long 0xd7006a00                                           // 0000005934B8: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 0000005934BC: 02020008
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 0000005934C0: D5207C01 01AA0209
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000005934C8: BF870193
	v_add3_u32 v2, v3, v2, 0x7fff                              // 0000005934CC: D6550002 03FE0503 00007FFF
	.long 0xd7006a00                                           // 0000005934D8: D7006A00
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 0000005934DC: 02000100
	s_delay_alu instid0(VALU_DEP_1)                            // 0000005934E0: BF870001
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 0000005934E4: D5207C01 01AA0201
	global_store_d16_hi_b16 v[0:1], v2, off                    // 0000005934EC: DC960000 007C0200
	s_endpgm                                                   // 0000005934F4: BFB00000
		...

