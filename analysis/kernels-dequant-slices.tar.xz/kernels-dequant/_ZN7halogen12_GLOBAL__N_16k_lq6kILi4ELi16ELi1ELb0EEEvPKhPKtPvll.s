000000000059e300 <_ZN7halogen12_GLOBAL__N_16k_lq6kILi4ELi16ELi1ELb0EEEvPKhPKtPvll>:
; _ZN7halogen12_GLOBAL__N_16k_lq6kILi4ELi16ELi1ELb0EEEvPKhPKtPvll():
	s_clause 0x1                                               // 00000059E300: BF850001
	s_load_b256 s[4:11], s[0:1], null                          // 00000059E304: F40C0100 F8000000
	s_load_b64 s[12:13], s[0:1], 0x20                          // 00000059E30C: F4040300 F8000020
	s_mov_b32 s3, 0                                            // 00000059E314: BE830080
	v_lshrrev_b32_e32 v1, 4, v0                                // 00000059E318: 32020084
	s_lshl_b64 s[0:1], s[2:3], 4                               // 00000059E31C: 84808402
	v_dual_mov_b32 v8, 0 :: v_dual_mov_b32 v9, 0               // 00000059E320: CA100080 08080080
	v_dual_mov_b32 v2, s1 :: v_dual_and_b32 v7, 15, v0         // 00000059E328: CA240001 0206008F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000059E330: BF870143
	v_or_b32_e32 v1, s0, v1                                    // 00000059E334: 38020200
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v11, 0             // 00000059E338: CA100080 0A0A0080
	s_waitcnt lgkmcnt(0)                                       // 00000059E340: BF89FC07
	s_ashr_i32 s1, s11, 31                                     // 00000059E344: 86019F0B
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 00000059E348: 7CA8020C
	s_lshr_b32 s1, s1, 28                                      // 00000059E34C: 85019C01
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000059E350: BF8704A9
	s_add_u32 s0, s10, s1                                      // 00000059E354: 8000010A
	s_addc_u32 s1, s11, 0                                      // 00000059E358: 8201800B
	s_lshr_b64 s[14:15], s[0:1], 4                             // 00000059E35C: 858E8400
	s_mov_b32 s1, exec_lo                                      // 00000059E360: BE81007E
	.long 0xd4c4007e                                           // 00000059E364: D4C4007E
	v_cndmask_b32_e32 v1, s14, v7, vcc_lo                      // 00000059E368: 02020E0E
	s_cbranch_execz 457                                        // 00000059E36C: BFA501C9 <_ZN7halogen12_GLOBAL__N_16k_lq6kILi4ELi16ELi1ELb0EEEvPKhPKtPvll+0x794>
	s_ashr_i32 s0, s11, 31                                     // 00000059E370: 86009F0B
	v_dual_cndmask_b32 v3, 0, v2 :: v_dual_and_b32 v12, 4, v0  // 00000059E374: CA640480 030C0084
	s_lshr_b32 s0, s0, 24                                      // 00000059E37C: 85009800
	v_dual_cndmask_b32 v5, 0, v1 :: v_dual_and_b32 v0, 6, v0   // 00000059E380: CA640280 05000086
	s_add_u32 s16, s10, s0                                     // 00000059E388: 8010000A
	s_addc_u32 s17, s11, 0                                     // 00000059E38C: 8211800B
	v_lshrrev_b32_e32 v9, 3, v7                                // 00000059E390: 32120E83
	s_ashr_i64 s[16:17], s[16:17], 8                           // 00000059E394: 86908810
	v_mov_b32_e32 v6, 0                                        // 00000059E398: 7E0C0280
	s_mul_i32 s0, s17, 0xd2                                    // 00000059E39C: 9600FF11 000000D2
	s_mul_hi_u32 s2, s16, 0xd2                                 // 00000059E3A4: 9682FF10 000000D2
	s_mul_i32 s15, s16, 0xd2                                   // 00000059E3AC: 960FFF10 000000D2
	s_add_i32 s2, s2, s0                                       // 00000059E3B4: 81020002
	.long 0xd72c0008                                           // 00000059E3B8: D72C0008
	v_cndmask_b32_e32 v1, s15, v3, vcc_lo                      // 00000059E3BC: 0202060F
	v_mad_u64_u32 v[3:4], null, s15, v5, s[4:5]                // 00000059E3C0: D6FE7C03 00120A0F
	.long 0xd72c0005                                           // 00000059E3C8: D72C0005
	v_cndmask_b32_e32 v1, s2, v5, vcc_lo                       // 00000059E3CC: 02020A02
	v_lshlrev_b32_e32 v13, 6, v9                               // 00000059E3D0: 301A1286
	v_dual_mov_b32 v21, 0 :: v_dual_lshlrev_b32 v14, 5, v9     // 00000059E3D4: CA220080 150E1285
	v_or_b32_e32 v15, 8, v12                                   // 00000059E3DC: 381E1888
	v_or_b32_e32 v16, 8, v0                                    // 00000059E3E0: 38200088
	v_or_b32_e32 v17, 16, v12                                  // 00000059E3E4: 38221890
	v_or_b32_e32 v18, 16, v0                                   // 00000059E3E8: 38240090
	v_add3_u32 v4, v5, v4, v8                                  // 00000059E3EC: D6550004 04220905
	v_or_b32_e32 v19, 24, v12                                  // 00000059E3F4: 38261898
	v_or_b32_e32 v20, 24, v0                                   // 00000059E3F8: 38280098
	v_dual_mov_b32 v22, v7 :: v_dual_lshlrev_b32 v5, 4, v7     // 00000059E3FC: CA220107 16040E84
	v_mov_b32_e32 v11, v6                                      // 00000059E404: 7E160306
	v_mov_b32_e32 v10, v6                                      // 00000059E408: 7E140306
	v_mov_b32_e32 v9, v6                                       // 00000059E40C: 7E120306
	v_mov_b32_e32 v8, v6                                       // 00000059E410: 7E100306
	s_mul_i32 s0, s11, 6                                       // 00000059E414: 9600860B
	s_mul_hi_u32 s2, s10, 6                                    // 00000059E418: 9682860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 00000059E41C: 8484820A
	s_add_i32 s2, s2, s0                                       // 00000059E420: 81020002
	s_mul_i32 s15, s10, 6                                      // 00000059E424: 960F860A
	s_lshl_b64 s[10:11], s[10:11], 1                           // 00000059E428: 848A810A
	.long 0xd700001f                                           // 00000059E42C: D700001F
	v_cndmask_b32_e32 v1, v3, v21, vcc_lo                      // 00000059E430: 02022B03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000059E434: BF8701A1
	v_add_co_ci_u32_e64 v32, null, 0, v4, s0                   // 00000059E438: D5207C20 00020880
	v_and_b32_e32 v27, 16, v5                                  // 00000059E440: 36360A90
	.long 0xd700001d                                           // 00000059E444: D700001D
	v_cndmask_b32_e32 v1, v31, v13, vcc_lo                     // 00000059E448: 02021B1F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000059E44C: BF8700D1
	v_add_co_ci_u32_e64 v30, null, 0, v32, s0                  // 00000059E450: D5207C1E 00024080
	.long 0xd7000019                                           // 00000059E458: D7000019
	v_cndmask_b32_e32 v1, v31, v14, vcc_lo                     // 00000059E45C: 02021D1F
	v_and_b32_e32 v28, 32, v5                                  // 00000059E460: 36380AA0
	v_add_co_ci_u32_e64 v26, null, 0, v32, s0                  // 00000059E464: D5207C1A 00024080
	.long 0xd7000017                                           // 00000059E46C: D7000017
	v_cndmask_b32_e32 v1, v31, v7, vcc_lo                      // 00000059E470: 02020F1F
	v_add_co_ci_u32_e64 v24, null, 0, v32, s0                  // 00000059E474: D5207C18 00024080
	.long 0xd7000019                                           // 00000059E47C: D7000019
	v_cndmask_b32_e32 v1, v25, v27, vcc_lo                     // 00000059E480: 02023719
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000059E484: BF8700A1
	v_add_co_ci_u32_e64 v26, null, 0, v26, s0                  // 00000059E488: D5207C1A 00023480
	.long 0xd700001c                                           // 00000059E490: D700001C
	v_cndmask_b32_e32 v1, v29, v28, vcc_lo                     // 00000059E494: 0202391D
	v_add_co_ci_u32_e64 v29, null, 0, v30, s0                  // 00000059E498: D5207C1D 00023C80
	s_clause 0x1                                               // 00000059E4A0: BF850001
	global_load_i8 v63, v[23:24], off offset:192               // 00000059E4A4: DC4600C0 3F7C0017
	global_load_b128 v[23:26], v[25:26], off offset:128        // 00000059E4AC: DC5E0080 177C0019
	.long 0xd700001b                                           // 00000059E4B4: D700001B
	v_cndmask_b32_e32 v1, v28, v27, vcc_lo                     // 00000059E4B8: 0202371C
	s_delay_alu instid0(VALU_DEP_1)                            // 00000059E4BC: BF870001
	v_add_co_ci_u32_e64 v28, null, 0, v29, s0                  // 00000059E4C0: D5207C1C 00023A80
	s_clause 0x1                                               // 00000059E4C8: BF850001
	global_load_b128 v[27:30], v[27:28], off                   // 00000059E4CC: DC5E0000 1B7C001B
	global_load_d16_b16 v64, v[31:32], off offset:208          // 00000059E4D4: DC8200D0 407C001F
	.long 0xd73c001f                                           // 00000059E4DC: D73C001F
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 00000059E4E0: 02020A81
	v_add_nc_u32_e32 v21, 0xd2, v21                            // 00000059E4E4: 4A2A2AFF 000000D2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000059E4EC: BF870092
	.long 0xd700002f                                           // 00000059E4F0: D700002F
	v_cndmask_b32_e32 v1, s6, v31, vcc_lo                      // 00000059E4F4: 02023E06
	v_add_co_ci_u32_e64 v48, null, s7, v32, s0                 // 00000059E4F8: D5207C30 00024007
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000059E500: BF870092
	.long 0xd7000033                                           // 00000059E504: D7000033
	v_cndmask_b32_e32 v0, v47, v10, vcc_lo                     // 00000059E508: 0200152F
	v_add_co_ci_u32_e64 v52, null, s11, v48, s0                // 00000059E50C: D5207C34 0002600B
	.long 0xd7000037                                           // 00000059E514: D7000037
	v_cndmask_b32_e32 v0, v47, v4, vcc_lo                      // 00000059E518: 0200092F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000059E51C: BF8700A1
	v_add_co_ci_u32_e64 v56, null, s5, v48, s0                 // 00000059E520: D5207C38 00026005
	.long 0xd700003b                                           // 00000059E528: D700003B
	v_cndmask_b32_e32 v0, v47, v15, vcc_lo                     // 00000059E52C: 02001F2F
	v_add_co_ci_u32_e64 v60, null, s2, v48, s0                 // 00000059E530: D5207C3C 00026002
	s_clause 0x7                                               // 00000059E538: BF850007
	global_load_b128 v[31:34], v[47:48], off                   // 00000059E53C: DC5E0000 1F7C002F
	global_load_b128 v[35:38], v[51:52], off                   // 00000059E544: DC5E0000 237C0033
	global_load_b128 v[39:42], v[55:56], off                   // 00000059E54C: DC5E0000 277C0037
	global_load_b128 v[43:46], v[59:60], off                   // 00000059E554: DC5E0000 2B7C003B
	global_load_b128 v[47:50], v[47:48], off offset:16         // 00000059E55C: DC5E0010 2F7C002F
	global_load_b128 v[51:54], v[51:52], off offset:16         // 00000059E564: DC5E0010 337C0033
	global_load_b128 v[55:58], v[55:56], off offset:16         // 00000059E56C: DC5E0010 377C0037
	global_load_b128 v[59:62], v[59:60], off offset:16         // 00000059E574: DC5E0010 3B7C003B
	s_waitcnt vmcnt(11)                                        // 00000059E57C: BF892FF7
	v_cvt_f32_i32_e32 v63, v63                                 // 00000059E580: 7E7E0B3F
	s_waitcnt vmcnt(10)                                        // 00000059E584: BF892BF7
	v_lshrrev_b32_e32 v71, v0, v25                             // 00000059E588: 328E3300
	v_lshrrev_b32_e32 v72, v16, v25                            // 00000059E58C: 32903310
	v_lshrrev_b32_e32 v73, v18, v25                            // 00000059E590: 32923312
	v_lshrrev_b32_e32 v25, v20, v25                            // 00000059E594: 32323314
	v_lshrrev_b32_e32 v68, v0, v24                             // 00000059E598: 32883100
	v_lshrrev_b32_e32 v69, v16, v24                            // 00000059E59C: 328A3110
	v_lshrrev_b32_e32 v70, v18, v24                            // 00000059E5A0: 328C3112
	s_waitcnt vmcnt(9)                                         // 00000059E5A4: BF8927F7
	v_bfe_u32 v82, v29, v12, 4                                 // 00000059E5A8: D6100052 0212191D
	v_bfe_u32 v83, v29, v15, 4                                 // 00000059E5B0: D6100053 02121F1D
	v_bfe_u32 v84, v29, v17, 4                                 // 00000059E5B8: D6100054 0212231D
	v_bfe_u32 v29, v29, v19, 4                                 // 00000059E5C0: D610001D 0212271D
	v_lshlrev_b32_e32 v25, 4, v25                              // 00000059E5C8: 30323284
	v_lshrrev_b32_e32 v24, v20, v24                            // 00000059E5CC: 32303114
	s_waitcnt vmcnt(8)                                         // 00000059E5D0: BF8923F7
	v_fma_mix_f32 v63, v64, v63, neg(0) op_sel_hi:[1,0,0]      // 00000059E5D4: CC20003F 8A027F40
	v_bfe_u32 v79, v28, v12, 4                                 // 00000059E5DC: D610004F 0212191C
	v_bfe_u32 v80, v28, v15, 4                                 // 00000059E5E4: D6100050 02121F1C
	v_and_or_b32 v25, v25, 48, v29                             // 00000059E5EC: D6570019 04756119
	v_bfe_u32 v81, v28, v17, 4                                 // 00000059E5F4: D6100051 0212231C
	v_bfe_u32 v28, v28, v19, 4                                 // 00000059E5FC: D610001C 0212271C
	v_lshlrev_b32_e32 v71, 4, v71                              // 00000059E604: 308E8E84
	v_lshrrev_b32_e32 v65, v0, v23                             // 00000059E608: 32822F00
	v_subrev_nc_u32_e32 v25, 32, v25                           // 00000059E60C: 4E3232A0
	v_lshrrev_b32_e32 v66, v16, v23                            // 00000059E610: 32842F10
	v_lshrrev_b32_e32 v67, v18, v23                            // 00000059E614: 32862F12
	v_lshrrev_b32_e32 v23, v20, v23                            // 00000059E618: 322E2F14
	v_lshrrev_b32_e32 v74, v0, v26                             // 00000059E61C: 32943500
	v_cvt_f32_i32_e32 v25, v25                                 // 00000059E620: 7E320B19
	v_lshlrev_b32_e32 v24, 4, v24                              // 00000059E624: 30303084
	v_lshrrev_b32_e32 v75, v16, v26                            // 00000059E628: 32963510
	v_lshrrev_b32_e32 v76, v18, v26                            // 00000059E62C: 32983512
	v_lshrrev_b32_e32 v26, v20, v26                            // 00000059E630: 32343514
	v_mul_f32_e32 v25, v63, v25                                // 00000059E634: 1032333F
	v_and_or_b32 v24, v24, 48, v28                             // 00000059E638: D6570018 04716118
	v_and_or_b32 v28, v71, 48, v82                             // 00000059E640: D657001C 05496147
	v_bfe_u32 v64, v27, v12, 4                                 // 00000059E648: D6100040 0212191B
	v_bfe_u32 v77, v27, v15, 4                                 // 00000059E650: D610004D 02121F1B
	v_bfe_u32 v78, v27, v17, 4                                 // 00000059E658: D610004E 0212231B
	v_bfe_u32 v27, v27, v19, 4                                 // 00000059E660: D610001B 0212271B
	v_subrev_nc_u32_e32 v28, 32, v28                           // 00000059E668: 4E3838A0
	v_lshlrev_b32_e32 v68, 4, v68                              // 00000059E66C: 30888884
	v_bfe_u32 v85, v30, v12, 4                                 // 00000059E670: D6100055 0212191E
	v_lshlrev_b32_e32 v74, 4, v74                              // 00000059E678: 30949484
	v_bfe_u32 v86, v30, v15, 4                                 // 00000059E67C: D6100056 02121F1E
	v_cvt_f32_i32_e32 v28, v28                                 // 00000059E684: 7E380B1C
	v_lshlrev_b32_e32 v23, 4, v23                              // 00000059E688: 302E2E84
	v_bfe_u32 v87, v30, v17, 4                                 // 00000059E68C: D6100057 0212231E
	v_bfe_u32 v30, v30, v19, 4                                 // 00000059E694: D610001E 0212271E
	v_lshlrev_b32_e32 v26, 4, v26                              // 00000059E69C: 30343484
	v_mul_f32_e32 v28, v63, v28                                // 00000059E6A0: 1038393F
	v_and_or_b32 v23, v23, 48, v27                             // 00000059E6A4: D6570017 046D6117
	v_and_or_b32 v27, v68, 48, v79                             // 00000059E6AC: D657001B 053D6144
	v_and_or_b32 v29, v74, 48, v85                             // 00000059E6B4: D657001D 0555614A
	v_and_or_b32 v26, v26, 48, v30                             // 00000059E6BC: D657001A 0479611A
	v_lshlrev_b32_e32 v65, 4, v65                              // 00000059E6C4: 30828284
	v_subrev_nc_u32_e32 v24, 32, v24                           // 00000059E6C8: 4E3030A0
	v_subrev_nc_u32_e32 v27, 32, v27                           // 00000059E6CC: 4E3636A0
	v_subrev_nc_u32_e32 v29, 32, v29                           // 00000059E6D0: 4E3A3AA0
	v_subrev_nc_u32_e32 v26, 32, v26                           // 00000059E6D4: 4E3434A0
	v_lshlrev_b32_e32 v69, 4, v69                              // 00000059E6D8: 308A8A84
	v_lshlrev_b32_e32 v70, 4, v70                              // 00000059E6DC: 308C8C84
	v_cvt_f32_i32_e32 v27, v27                                 // 00000059E6E0: 7E360B1B
	v_lshlrev_b32_e32 v66, 4, v66                              // 00000059E6E4: 30848484
	v_lshlrev_b32_e32 v75, 4, v75                              // 00000059E6E8: 30969684
	v_lshlrev_b32_e32 v76, 4, v76                              // 00000059E6EC: 30989884
	v_and_or_b32 v64, v65, 48, v64                             // 00000059E6F0: D6570040 05016141
	v_cvt_f32_i32_e32 v24, v24                                 // 00000059E6F8: 7E300B18
	v_lshlrev_b32_e32 v67, 4, v67                              // 00000059E6FC: 30868684
	v_cvt_f32_i32_e32 v29, v29                                 // 00000059E700: 7E3A0B1D
	v_lshlrev_b32_e32 v72, 4, v72                              // 00000059E704: 30909084
	v_cvt_f32_i32_e32 v26, v26                                 // 00000059E708: 7E340B1A
	v_lshlrev_b32_e32 v73, 4, v73                              // 00000059E70C: 30929284
	v_mul_f32_e32 v27, v63, v27                                // 00000059E710: 1036373F
	v_and_or_b32 v65, v66, 48, v77                             // 00000059E714: D6570041 05356142
	v_and_or_b32 v68, v70, 48, v81                             // 00000059E71C: D6570044 05456146
	v_and_or_b32 v71, v75, 48, v86                             // 00000059E724: D6570047 0559614B
	v_subrev_nc_u32_e32 v30, 32, v64                           // 00000059E72C: 4E3C80A0
	v_mul_f32_e32 v24, v63, v24                                // 00000059E730: 1030313F
	v_and_or_b32 v66, v67, 48, v78                             // 00000059E734: D6570042 05396143
	v_and_or_b32 v67, v69, 48, v80                             // 00000059E73C: D6570043 05416145
	v_mul_f32_e32 v29, v63, v29                                // 00000059E744: 103A3B3F
	v_and_or_b32 v69, v72, 48, v83                             // 00000059E748: D6570045 054D6148
	v_and_or_b32 v72, v76, 48, v87                             // 00000059E750: D6570048 055D614C
	v_mul_f32_e32 v26, v63, v26                                // 00000059E758: 1034353F
	v_and_or_b32 v70, v73, 48, v84                             // 00000059E75C: D6570046 05516149
	v_subrev_nc_u32_e32 v64, 32, v65                           // 00000059E764: 4E8082A0
	v_subrev_nc_u32_e32 v65, 32, v66                           // 00000059E768: 4E8284A0
	v_subrev_nc_u32_e32 v23, 32, v23                           // 00000059E76C: 4E2E2EA0
	v_subrev_nc_u32_e32 v66, 32, v67                           // 00000059E770: 4E8486A0
	v_subrev_nc_u32_e32 v67, 32, v68                           // 00000059E774: 4E8688A0
	v_subrev_nc_u32_e32 v68, 32, v69                           // 00000059E778: 4E888AA0
	v_subrev_nc_u32_e32 v69, 32, v70                           // 00000059E77C: 4E8A8CA0
	v_subrev_nc_u32_e32 v70, 32, v71                           // 00000059E780: 4E8C8EA0
	v_subrev_nc_u32_e32 v71, 32, v72                           // 00000059E784: 4E8E90A0
	v_cvt_f32_i32_e32 v30, v30                                 // 00000059E788: 7E3C0B1E
	v_cvt_f32_i32_e32 v64, v64                                 // 00000059E78C: 7E800B40
	v_cvt_f32_i32_e32 v65, v65                                 // 00000059E790: 7E820B41
	v_cvt_f32_i32_e32 v23, v23                                 // 00000059E794: 7E2E0B17
	v_cvt_f32_i32_e32 v66, v66                                 // 00000059E798: 7E840B42
	v_cvt_f32_i32_e32 v67, v67                                 // 00000059E79C: 7E860B43
	v_cvt_f32_i32_e32 v68, v68                                 // 00000059E7A0: 7E880B44
	v_cvt_f32_i32_e32 v69, v69                                 // 00000059E7A4: 7E8A0B45
	v_cvt_f32_i32_e32 v70, v70                                 // 00000059E7A8: 7E8C0B46
	v_cvt_f32_i32_e32 v71, v71                                 // 00000059E7AC: 7E8E0B47
	v_dual_mul_f32 v30, v63, v30 :: v_dual_add_nc_u32 v5, 0x100, v5// 00000059E7B0: C8E03D3F 1E040AFF 00000100
	v_mul_f32_e32 v64, v63, v64                                // 00000059E7BC: 1080813F
	v_dual_mul_f32 v65, v63, v65 :: v_dual_add_nc_u32 v22, 16, v22// 00000059E7C0: C8E0833F 41162C90
	v_mul_f32_e32 v23, v63, v23                                // 00000059E7C8: 102E2F3F
	v_mul_f32_e32 v66, v63, v66                                // 00000059E7CC: 1084853F
	v_mul_f32_e32 v67, v63, v67                                // 00000059E7D0: 1086873F
	v_mul_f32_e32 v68, v63, v68                                // 00000059E7D4: 1088893F
	v_mul_f32_e32 v69, v63, v69                                // 00000059E7D8: 108A8B3F
	v_mul_f32_e32 v70, v63, v70                                // 00000059E7DC: 108C8D3F
	v_mul_f32_e32 v71, v63, v71                                // 00000059E7E0: 108E8F3F
	v_bfe_u32 v63, v30, 16, 1                                  // 00000059E7E4: D610003F 0205211E
	v_bfe_u32 v72, v64, 16, 1                                  // 00000059E7EC: D6100048 02052140
	v_bfe_u32 v73, v65, 16, 1                                  // 00000059E7F4: D6100049 02052141
	v_bfe_u32 v74, v23, 16, 1                                  // 00000059E7FC: D610004A 02052117
	v_bfe_u32 v75, v27, 16, 1                                  // 00000059E804: D610004B 0205211B
	v_add3_u32 v30, v30, v63, 0x7fff                           // 00000059E80C: D655001E 03FE7F1E 00007FFF
	v_add3_u32 v63, v64, v72, 0x7fff                           // 00000059E818: D655003F 03FE9140 00007FFF
	v_add3_u32 v64, v65, v73, 0x7fff                           // 00000059E824: D6550040 03FE9341 00007FFF
	v_bfe_u32 v76, v66, 16, 1                                  // 00000059E830: D610004C 02052142
	v_add3_u32 v23, v23, v74, 0x7fff                           // 00000059E838: D6550017 03FE9517 00007FFF
	.long 0x7e7e399e                                           // 00000059E844: 7E7E399E
	v_bfe_u32 v77, v67, 16, 1                                  // 00000059E848: D610004D 02052143
	v_add3_u32 v27, v27, v75, 0x7fff                           // 00000059E850: D655001B 03FE971B 00007FFF
	.long 0x7e2e39c0                                           // 00000059E85C: 7E2E39C0
	v_bfe_u32 v78, v24, 16, 1                                  // 00000059E860: D610004E 02052118
	s_waitcnt vmcnt(7)                                         // 00000059E868: BF891FF7
	v_dot2_f32_bf16 v30, v31, v63, 0                           // 00000059E86C: CC1A401E 1A027F1F
	s_waitcnt vmcnt(6)                                         // 00000059E874: BF891BF7
	v_dot2_f32_bf16 v31, v35, v63, 0                           // 00000059E878: CC1A401F 1A027F23
	s_waitcnt vmcnt(5)                                         // 00000059E880: BF8917F7
	v_dot2_f32_bf16 v35, v39, v63, 0                           // 00000059E884: CC1A4023 1A027F27
	s_waitcnt vmcnt(4)                                         // 00000059E88C: BF8913F7
	v_dot2_f32_bf16 v39, v43, v63, 0                           // 00000059E890: CC1A4027 1A027F2B
	v_add3_u32 v65, v66, v76, 0x7fff                           // 00000059E898: D6550041 03FE9942 00007FFF
	v_bfe_u32 v79, v28, 16, 1                                  // 00000059E8A4: D610004F 0205211C
	v_add3_u32 v66, v67, v77, 0x7fff                           // 00000059E8AC: D6550042 03FE9B43 00007FFF
	.long 0x7e82399b                                           // 00000059E8B8: 7E82399B
	v_dot2_f32_bf16 v27, v32, v23, v30                         // 00000059E8BC: CC1A401B 1C7A2F20
	v_dot2_f32_bf16 v30, v36, v23, v31                         // 00000059E8C4: CC1A401E 1C7E2F24
	v_dot2_f32_bf16 v31, v40, v23, v35                         // 00000059E8CC: CC1A401F 1C8E2F28
	v_dot2_f32_bf16 v23, v44, v23, v39                         // 00000059E8D4: CC1A4017 1C9E2F2C
	v_bfe_u32 v80, v68, 16, 1                                  // 00000059E8DC: D6100050 02052144
	v_add3_u32 v24, v24, v78, 0x7fff                           // 00000059E8E4: D6550018 03FE9D18 00007FFF
	v_bfe_u32 v81, v69, 16, 1                                  // 00000059E8F0: D6100051 02052145
	v_add3_u32 v28, v28, v79, 0x7fff                           // 00000059E8F8: D655001C 03FE9F1C 00007FFF
	.long 0x7e3039c2                                           // 00000059E904: 7E3039C2
	v_dot2_f32_bf16 v27, v33, v65, v27                         // 00000059E908: CC1A401B 1C6E8321
	v_dot2_f32_bf16 v30, v37, v65, v30                         // 00000059E910: CC1A401E 1C7A8325
	v_dot2_f32_bf16 v31, v41, v65, v31                         // 00000059E918: CC1A401F 1C7E8329
	v_dot2_f32_bf16 v23, v45, v65, v23                         // 00000059E920: CC1A4017 1C5E832D
	v_bfe_u32 v82, v25, 16, 1                                  // 00000059E928: D6100052 02052119
	v_add3_u32 v67, v68, v80, 0x7fff                           // 00000059E930: D6550043 03FEA144 00007FFF
	v_bfe_u32 v83, v29, 16, 1                                  // 00000059E93C: D6100053 0205211D
	v_add3_u32 v68, v69, v81, 0x7fff                           // 00000059E944: D6550044 03FEA345 00007FFF
	.long 0x7e86399c                                           // 00000059E950: 7E86399C
	v_dot2_f32_bf16 v27, v34, v24, v27                         // 00000059E954: CC1A401B 1C6E3122
	v_dot2_f32_bf16 v28, v38, v24, v30                         // 00000059E95C: CC1A401C 1C7A3126
	v_dot2_f32_bf16 v30, v42, v24, v31                         // 00000059E964: CC1A401E 1C7E312A
	v_dot2_f32_bf16 v23, v46, v24, v23                         // 00000059E96C: CC1A4017 1C5E312E
	v_bfe_u32 v84, v70, 16, 1                                  // 00000059E974: D6100054 02052146
	v_add3_u32 v25, v25, v82, 0x7fff                           // 00000059E97C: D6550019 03FEA519 00007FFF
	v_bfe_u32 v85, v71, 16, 1                                  // 00000059E988: D6100055 02052147
	v_add3_u32 v29, v29, v83, 0x7fff                           // 00000059E990: D655001D 03FEA71D 00007FFF
	.long 0x7e3239c4                                           // 00000059E99C: 7E3239C4
	s_waitcnt vmcnt(3)                                         // 00000059E9A0: BF890FF7
	v_dot2_f32_bf16 v24, v47, v67, v27                         // 00000059E9A4: CC1A4018 1C6E872F
	s_waitcnt vmcnt(2)                                         // 00000059E9AC: BF890BF7
	v_dot2_f32_bf16 v27, v51, v67, v28                         // 00000059E9B0: CC1A401B 1C728733
	s_waitcnt vmcnt(1)                                         // 00000059E9B8: BF8907F7
	v_dot2_f32_bf16 v28, v55, v67, v30                         // 00000059E9BC: CC1A401C 1C7A8737
	s_waitcnt vmcnt(0)                                         // 00000059E9C4: BF8903F7
	v_dot2_f32_bf16 v23, v59, v67, v23                         // 00000059E9C8: CC1A4017 1C5E873B
	v_bfe_u32 v86, v26, 16, 1                                  // 00000059E9D0: D6100056 0205211A
	v_add3_u32 v69, v70, v84, 0x7fff                           // 00000059E9D8: D6550045 03FEA946 00007FFF
	v_add3_u32 v70, v71, v85, 0x7fff                           // 00000059E9E4: D6550046 03FEAB47 00007FFF
	.long 0x7e8a399d                                           // 00000059E9F0: 7E8A399D
	v_dot2_f32_bf16 v24, v48, v25, v24                         // 00000059E9F4: CC1A4018 1C623330
	v_dot2_f32_bf16 v27, v52, v25, v27                         // 00000059E9FC: CC1A401B 1C6E3334
	v_dot2_f32_bf16 v28, v56, v25, v28                         // 00000059EA04: CC1A401C 1C723338
	v_dot2_f32_bf16 v23, v60, v25, v23                         // 00000059EA0C: CC1A4017 1C5E333C
	v_add3_u32 v26, v26, v86, 0x7fff                           // 00000059EA14: D655001A 03FEAD1A 00007FFF
	.long 0x7e3439c6                                           // 00000059EA20: 7E3439C6
	v_dot2_f32_bf16 v24, v49, v69, v24                         // 00000059EA24: CC1A4018 1C628B31
	v_dot2_f32_bf16 v25, v53, v69, v27                         // 00000059EA2C: CC1A4019 1C6E8B35
	v_dot2_f32_bf16 v27, v57, v69, v28                         // 00000059EA34: CC1A401B 1C728B39
	v_dot2_f32_bf16 v23, v61, v69, v23                         // 00000059EA3C: CC1A4017 1C5E8B3D
	.long 0xd4430000                                           // 00000059EA44: D4430000
	v_cndmask_b32_e32 v1, s14, v22, vcc_lo                     // 00000059EA48: 02022C0E
	v_dot2_f32_bf16 v24, v50, v26, v24                         // 00000059EA4C: CC1A4018 1C623532
	v_dot2_f32_bf16 v25, v54, v26, v25                         // 00000059EA54: CC1A4019 1C663536
	v_dot2_f32_bf16 v27, v58, v26, v27                         // 00000059EA5C: CC1A401B 1C6E353A
	v_dot2_f32_bf16 v23, v62, v26, v23                         // 00000059EA64: CC1A4017 1C5E353E
	s_or_b32 s3, s0, s3                                        // 00000059EA6C: 8C030300
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000059EA70: BF870193
	v_dual_add_f32 v11, v11, v24 :: v_dual_add_f32 v10, v10, v25// 00000059EA74: C908310B 0B0A330A
	v_add_f32_e32 v9, v9, v27                                  // 00000059EA7C: 06123709
	s_delay_alu instid0(VALU_DEP_3)                            // 00000059EA80: BF870003
	v_add_f32_e32 v8, v8, v23                                  // 00000059EA84: 06102F08
	s_and_not1_b32 exec_lo, exec_lo, s3                        // 00000059EA88: 917E037E
	s_cbranch_execnz 65127                                     // 00000059EA8C: BFA6FE67 <_ZN7halogen12_GLOBAL__N_16k_lq6kILi4ELi16ELi1ELb0EEEvPKhPKtPvll+0x12c>
	s_or_b32 exec_lo, exec_lo, s3                              // 00000059EA90: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000059EA94: BF8700A9
	s_or_b32 exec_lo, exec_lo, s1                              // 00000059EA98: 8C7E017E
	.long 0xd71f0000                                           // 00000059EA9C: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000059EAA0: 020100C1
	v_xor_b32_e32 v3, 8, v0                                    // 00000059EAA4: 3A060088
	v_xor_b32_e32 v12, 4, v0                                   // 00000059EAA8: 3A180084
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000059EAAC: BF870092
	.long 0xd44c0000                                           // 00000059EAB0: D44C0000
	v_cndmask_b32_e32 v1, 32, v3, vcc_lo                       // 00000059EAB4: 020206A0
	v_cndmask_b32_e64 v3, v0, v3, s0                           // 00000059EAB8: D5010003 00020700
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000059EAC0: BF870113
	.long 0xd44c0000                                           // 00000059EAC4: D44C0000
	v_cndmask_b32_e32 v1, 32, v12, vcc_lo                      // 00000059EAC8: 020218A0
	v_lshlrev_b32_e32 v3, 2, v3                                // 00000059EACC: 30060682
	s_delay_alu instid0(VALU_DEP_2)                            // 00000059EAD0: BF870002
	v_cndmask_b32_e64 v12, v0, v12, s0                         // 00000059EAD4: D501000C 00021900
	ds_bpermute_b32 v4, v3, v11                                // 00000059EADC: DACC0000 04000B03
	s_waitcnt lgkmcnt(0)                                       // 00000059EAE4: BF89FC07
	v_add_f32_e32 v4, v11, v4                                  // 00000059EAE8: 0608090B
	ds_bpermute_b32 v5, v3, v10                                // 00000059EAEC: DACC0000 05000A03
	ds_bpermute_b32 v6, v3, v9                                 // 00000059EAF4: DACC0000 06000903
	ds_bpermute_b32 v3, v3, v8                                 // 00000059EAFC: DACC0000 03000803
	s_waitcnt lgkmcnt(2)                                       // 00000059EB04: BF89FC27
	v_dual_add_f32 v5, v10, v5 :: v_dual_lshlrev_b32 v12, 2, v12// 00000059EB08: C9220B0A 050C1882
	s_waitcnt lgkmcnt(0)                                       // 00000059EB10: BF89FC07
	v_dual_add_f32 v6, v9, v6 :: v_dual_add_f32 v3, v8, v3     // 00000059EB14: C9080D09 06020708
	ds_bpermute_b32 v8, v12, v4                                // 00000059EB1C: DACC0000 0800040C
	ds_bpermute_b32 v9, v12, v5                                // 00000059EB24: DACC0000 0900050C
	ds_bpermute_b32 v10, v12, v6                               // 00000059EB2C: DACC0000 0A00060C
	ds_bpermute_b32 v11, v12, v3                               // 00000059EB34: DACC0000 0B00030C
	v_xor_b32_e32 v12, 2, v0                                   // 00000059EB3C: 3A180082
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000059EB40: BF870091
	.long 0xd44c0000                                           // 00000059EB44: D44C0000
	v_cndmask_b32_e32 v1, 32, v12, vcc_lo                      // 00000059EB48: 020218A0
	v_cndmask_b32_e64 v12, v0, v12, s0                         // 00000059EB4C: D501000C 00021900
	s_delay_alu instid0(VALU_DEP_1)                            // 00000059EB54: BF870001
	v_lshlrev_b32_e32 v12, 2, v12                              // 00000059EB58: 30181882
	s_waitcnt lgkmcnt(2)                                       // 00000059EB5C: BF89FC27
	v_dual_add_f32 v4, v4, v8 :: v_dual_add_f32 v5, v5, v9     // 00000059EB60: C9081104 04041305
	s_waitcnt lgkmcnt(1)                                       // 00000059EB68: BF89FC17
	v_add_f32_e32 v9, v6, v10                                  // 00000059EB6C: 06121506
	v_xor_b32_e32 v6, 1, v0                                    // 00000059EB70: 3A0C0081
	ds_bpermute_b32 v8, v12, v5                                // 00000059EB74: DACC0000 0800050C
	.long 0xd44c0000                                           // 00000059EB7C: D44C0000
	v_cndmask_b32_e32 v1, 32, v6, vcc_lo                       // 00000059EB80: 02020CA0
	s_delay_alu instid0(VALU_DEP_1)                            // 00000059EB84: BF870001
	v_cndmask_b32_e64 v0, v0, v6, s0                           // 00000059EB88: D5010000 00020D00
	s_waitcnt lgkmcnt(1)                                       // 00000059EB90: BF89FC17
	v_add_f32_e32 v10, v3, v11                                 // 00000059EB94: 06141703
	ds_bpermute_b32 v3, v12, v4                                // 00000059EB98: DACC0000 0300040C
	ds_bpermute_b32 v11, v12, v9                               // 00000059EBA0: DACC0000 0B00090C
	.long 0xd44a0000                                           // 00000059EBA8: D44A0000
	v_cndmask_b32_e32 v1, 0, v7, vcc_lo                        // 00000059EBAC: 02020E80
	v_lshlrev_b32_e32 v13, 2, v0                               // 00000059EBB0: 301A0082
	ds_bpermute_b32 v12, v12, v10                              // 00000059EBB4: DACC0000 0C000A0C
	s_and_b32 s0, s0, vcc_lo                                   // 00000059EBBC: 8B006A00
	s_waitcnt lgkmcnt(3)                                       // 00000059EBC0: BF89FC37
	v_add_f32_e32 v8, v5, v8                                   // 00000059EBC4: 06101105
	s_waitcnt lgkmcnt(2)                                       // 00000059EBC8: BF89FC27
	v_add_f32_e32 v6, v4, v3                                   // 00000059EBCC: 060C0704
	s_waitcnt lgkmcnt(0)                                       // 00000059EBD0: BF89FC07
	v_dual_add_f32 v3, v9, v11 :: v_dual_add_f32 v0, v10, v12  // 00000059EBD4: C9081709 0300190A
	ds_bpermute_b32 v9, v13, v6                                // 00000059EBDC: DACC0000 0900060D
	ds_bpermute_b32 v10, v13, v8                               // 00000059EBE4: DACC0000 0A00080D
	ds_bpermute_b32 v4, v13, v3                                // 00000059EBEC: DACC0000 0400030D
	ds_bpermute_b32 v5, v13, v0                                // 00000059EBF4: DACC0000 0500000D
	s_and_saveexec_b32 s1, s0                                  // 00000059EBFC: BE812000
	s_cbranch_execz 61                                         // 00000059EC00: BFA5003D <_ZN7halogen12_GLOBAL__N_16k_lq6kILi4ELi16ELi1ELb0EEEvPKhPKtPvll+0x9f8>
	s_waitcnt lgkmcnt(2)                                       // 00000059EC04: BF89FC27
	v_dual_add_f32 v7, v8, v10 :: v_dual_add_f32 v6, v6, v9    // 00000059EC08: C9081508 07061306
	.long 0xd73c0001                                           // 00000059EC10: D73C0001
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000059EC14: 02020281
	.long 0x7f103880                                           // 00000059EC18: 7F103880
	s_waitcnt lgkmcnt(0)                                       // 00000059EC1C: BF89FC07
	v_dual_add_f32 v10, v3, v4 :: v_dual_add_f32 v11, v0, v5   // 00000059EC20: C9080903 0A0A0B00
	.long 0x7e103987                                           // 00000059EC28: 7E103987
	.long 0x7e123986                                           // 00000059EC2C: 7E123986
	.long 0xd7006a03                                           // 00000059EC30: D7006A03
	v_cndmask_b32_e32 v1, s8, v1, vcc_lo                       // 00000059EC34: 02020208
	.long 0x7f123988                                           // 00000059EC38: 7F123988
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000059EC3C: BF870234
	v_and_b32_e32 v0, 1, v8                                    // 00000059EC40: 36001081
	v_add_co_ci_u32_e64 v4, null, s9, v2, vcc_lo               // 00000059EC44: D5207C04 01AA0409
	.long 0x7e04398a                                           // 00000059EC4C: 7E04398A
	v_and_b32_e32 v5, 1, v9                                    // 00000059EC50: 360A1281
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000059EC54: BF870214
	v_add3_u32 v9, v7, v0, 0x7fff                              // 00000059EC58: D6550009 03FE0107 00007FFF
	v_mad_u64_u32 v[0:1], null, s12, 6, v[3:4]                 // 00000059EC64: D6FE7C00 040D0C0C
	.long 0x7f043988                                           // 00000059EC6C: 7F043988
	.long 0x7e10398b                                           // 00000059EC70: 7E10398B
	s_lshl_b64 s[0:1], s[12:13], 1                             // 00000059EC74: 8480810C
	v_add3_u32 v12, v6, v5, 0x7fff                             // 00000059EC78: D655000C 03FE0B06 00007FFF
	.long 0xd7006a05                                           // 00000059EC84: D7006A05
	v_cndmask_b32_e32 v0, v3, v0, vcc_lo                       // 00000059EC88: 02000103
	v_and_b32_e32 v14, 1, v2                                   // 00000059EC8C: 361C0481
	v_add_co_ci_u32_e64 v6, null, s1, v4, vcc_lo               // 00000059EC90: D5207C06 01AA0801
	s_lshl_b64 s[0:1], s[12:13], 2                             // 00000059EC98: 8480820C
	v_and_b32_e32 v13, 1, v8                                   // 00000059EC9C: 361A1081
	v_mad_u64_u32 v[1:2], null, s13, 6, v[1:2]                 // 00000059ECA0: D6FE7C01 04050C0D
	.long 0xd7006a07                                           // 00000059ECA8: D7006A07
	v_cndmask_b32_e32 v0, v3, v0, vcc_lo                       // 00000059ECAC: 02000103
	s_delay_alu instid0(VALU_DEP_1)                            // 00000059ECB0: BF870001
	v_add_co_ci_u32_e64 v8, null, s1, v4, vcc_lo               // 00000059ECB4: D5207C08 01AA0801
	v_add3_u32 v2, v10, v14, 0x7fff                            // 00000059ECBC: D6550002 03FE1D0A 00007FFF
	v_add3_u32 v10, v11, v13, 0x7fff                           // 00000059ECC8: D655000A 03FE1B0B 00007FFF
	s_clause 0x3                                               // 00000059ECD4: BF850003
	global_store_d16_hi_b16 v[3:4], v12, off                   // 00000059ECD8: DC960000 007C0C03
	global_store_d16_hi_b16 v[5:6], v9, off                    // 00000059ECE0: DC960000 007C0905
	global_store_d16_hi_b16 v[7:8], v2, off                    // 00000059ECE8: DC960000 007C0207
	global_store_d16_hi_b16 v[0:1], v10, off                   // 00000059ECF0: DC960000 007C0A00
	s_endpgm                                                   // 00000059ECF8: BFB00000
	v_illegal                                                  // 00000059ECFC: 00000000

