0000000000448500 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi1ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_>:
; _ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi1ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_():
	s_clause 0x2                                               // 000000448500: BF850002
	s_load_b128 s[24:27], s[0:1], 0x10                         // 000000448504: F4080600 F8000010
	s_load_b256 s[12:19], s[0:1], 0x20                         // 00000044850C: F40C0300 F8000020
	s_load_b128 s[20:23], s[0:1], 0x40                         // 000000448514: F4080500 F8000040
	s_mov_b32 s4, s3                                           // 00000044851C: BE840003
	v_and_b32_e32 v41, 31, v0                                  // 000000448520: 3652009F
	v_lshrrev_b32_e32 v40, 5, v0                               // 000000448524: 32500085
	s_delay_alu instid0(VALU_DEP_2)                            // 000000448528: BF870002
	v_lshlrev_b32_e32 v10, 3, v41                              // 00000044852C: 30145283
	s_waitcnt lgkmcnt(0)                                       // 000000448530: BF89FC07
	s_ashr_i32 s35, s25, 31                                    // 000000448534: 86239F19
	s_mul_i32 s34, s27, s4                                     // 000000448538: 9622041B
	s_lshr_b32 s3, s35, 25                                     // 00000044853C: 85039923
	s_add_i32 s5, s34, s27                                     // 000000448540: 81051B22
	s_add_i32 s3, s25, s3                                      // 000000448544: 81030319
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000448548: BF870499
	s_ashr_i32 s3, s3, 7                                       // 00000044854C: 86038703
	s_min_i32 s3, s3, s5                                       // 000000448550: 89030503
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000448554: BF870009
	s_sub_i32 s11, s3, s34                                     // 000000448558: 818B2203
	s_mov_b32 s3, exec_lo                                      // 00000044855C: BE83007E
	.long 0xd4c3007e                                           // 000000448560: D4C3007E
	v_cndmask_b32_e32 v1, s11, v40, vcc_lo                     // 000000448564: 0202500B
	s_xor_b32 s3, exec_lo, s3                                  // 000000448568: 8D03037E
	v_lshlrev_b32_e32 v10, 3, v41                              // 00000044856C: 30145283
	s_or_saveexec_b32 s10, s3                                  // 000000448570: BE8A2203
	s_clause 0x1                                               // 000000448574: BF850001
	s_load_b32 s33, s[0:1], 0x54                               // 000000448578: F4000840 F8000054
	s_load_b128 s[28:31], s[0:1], null                         // 000000448580: F4080700 F8000000
	v_lshlrev_b32_e32 v42, 2, v41                              // 000000448588: 30545282
	s_xor_b32 exec_lo, exec_lo, s10                            // 00000044858C: 8D7E0A7E
	s_cbranch_execz 501                                        // 000000448590: BFA501F5 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi1ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x868>
	s_add_i32 s27, s24, -1                                     // 000000448594: 811BC118
	s_cmp_lg_u64 s[22:23], 0                                   // 000000448598: BF118016
	v_dual_mov_b32 v8, v40 :: v_dual_and_b32 v1, 1, v0         // 00000044859C: CA240128 08000081
	s_cselect_b32 s36, -1, 0                                   // 0000004485A4: 982480C1
	s_abs_i32 s37, s11                                         // 0000004485A8: BEA5150B
	v_and_b32_e32 v3, 2, v0                                    // 0000004485AC: 36060082
	s_cvt_f32_u32 s0, s37                                      // 0000004485B0: BE806525
	v_and_b32_e32 v4, 4, v0                                    // 0000004485B4: 36080084
	v_and_b32_e32 v5, 8, v0                                    // 0000004485B8: 360A0088
	v_lshl_or_b32 v6, v40, 8, v10                              // 0000004485BC: D6560006 04291128
	v_rcp_iflag_f32_e32 v2, s0                                 // 0000004485C4: 7E045600
	v_add_nc_u32_e32 v7, s34, v40                              // 0000004485C8: 4A0E5022
	s_ashr_i32 s41, s11, 31                                    // 0000004485CC: 86299F0B
	s_sub_i32 s9, 0, s37                                       // 0000004485D0: 81892580
	s_mul_i32 s43, s41, 0x1400                                 // 0000004485D4: 962BFF29 00001400
	.long 0xd44c0000                                           // 0000004485DC: D44C0000
	v_cndmask_b32_e32 v1, 16, v41, vcc_lo                      // 0000004485E0: 02025290
	.long 0xd44a0001                                           // 0000004485E4: D44A0001
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000004485E8: 02020280
	.long 0xd44a0005                                           // 0000004485EC: D44A0005
	v_cndmask_b32_e32 v1, 0, v4, vcc_lo                        // 0000004485F0: 02020880
	.long 0xd44a0006                                           // 0000004485F4: D44A0006
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 0000004485F8: 02020A80
	v_lshl_or_b32 v1, v7, 7, v42                               // 0000004485FC: D6560001 04A90F07
	v_readfirstlane_b32 s3, v2                                 // 000000448604: 7E060502
	v_subrev_nc_u32_e32 v9, s43, v6                            // 000000448608: 4E120C2B
	s_lshl_b32 s7, s11, 7                                      // 00000044860C: 8407870B
	s_mov_b32 s38, s25                                         // 000000448610: BEA60019
	s_mov_b32 s39, 0                                           // 000000448614: BEA70080
	s_mul_f32 s8, s3, 0x4f7ffffe                               // 000000448618: A208FF03 4F7FFFFE
	.long 0xd44a0003                                           // 000000448620: D44A0003
	v_cndmask_b32_e32 v1, 0, v3, vcc_lo                        // 000000448624: 02020680
	s_mov_b32 s40, 0x76543210                                  // 000000448628: BEA800FF 76543210
	s_lshl_b32 s42, s11, 8                                     // 000000448630: 842A880B
	s_cvt_u32_f32 s8, s8                                       // 000000448634: BE886708
	s_sub_i32 s43, 0, s7                                       // 000000448638: 81AB0780
	s_mov_b32 s45, 0x3db504f3                                  // 00000044863C: BEAD00FF 3DB504F3
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000448644: BF870499
	s_mul_i32 s9, s9, s8                                       // 000000448648: 96090809
	s_mul_hi_u32 s9, s8, s9                                    // 00000044864C: 96890908
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000448650: BF870009
	s_add_i32 s44, s8, s9                                      // 000000448654: 812C0908
	s_branch 161                                               // 000000448658: BFA000A1 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi1ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x3e0>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000044865C: BF870091
	.long 0xd7006a02                                           // 000000448660: D7006A02
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 000000448664: 0202040C
	v_add_co_ci_u32_e64 v3, null, s13, v3, vcc_lo              // 000000448668: D5207C03 01AA060D
	v_add_nc_u32_e32 v1, 0x400, v1                             // 000000448670: 4A0202FF 00000400
	global_load_d16_b16 v2, v[2:3], off offset:6               // 000000448678: DC820006 027C0002
	v_add_f32_e32 v3, v16, v14                                 // 000000448680: 06061D10
	s_waitcnt vmcnt(0)                                         // 000000448684: BF8903F7
	v_fma_mix_f32 v5, v15, v2, v13 op_sel_hi:[0,1,0]           // 000000448688: CC200005 1436050F
	v_sub_f32_e32 v4, v16, v14                                 // 000000448690: 08081D10
	v_fma_mix_f32 v2, -v15, v2, v13 op_sel_hi:[0,1,0]          // 000000448694: CC200002 3436050F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000044869C: BF870121
	v_dual_add_f32 v6, v3, v5 :: v_dual_add_f32 v7, v4, v2     // 0000004486A0: C9080B03 06060504
	v_sub_f32_e32 v2, v4, v2                                   // 0000004486A8: 08040504
	v_mov_b32_dpp v4, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004486AC: 7E0802FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 0000004486B4: D5010006 20060D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000004486BC: BF870241
	v_dual_add_f32 v4, v6, v4 :: v_dual_sub_f32 v3, v3, v5     // 0000004486C0: C90A0906 04020B03
	v_mov_b32_dpp v5, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004486C8: 7E0A02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 0000004486D0: D5010007 20060F07
	.long 0xd72c0006                                           // 0000004486D8: D72C0006
	v_cndmask_b32_e32 v1, 0x1400, v12, vcc_lo                  // 0000004486DC: 020218FF 00001400
	v_mov_b32_dpp v13, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004486E4: 7E1A02FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 0000004486EC: D5010003 20060703
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004486F4: BF870004
	v_add_f32_e32 v5, v7, v5                                   // 0000004486F8: 060A0B07
	v_mov_b32_dpp v14, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004486FC: 7E1C02FA FF016102
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 000000448704: D5010002 20060502
	v_mov_b32_dpp v7, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000044870C: 7E0E02FA FF016204
	v_add_f32_e32 v3, v3, v13                                  // 000000448714: 06061B03
	v_mov_b32_dpp v12, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000448718: 7E1802FA FF016205
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000448720: D5010004 200E0904
	v_add_f32_e32 v2, v2, v14                                  // 000000448728: 06041D02
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 00000044872C: D5010005 200E0B05
	v_mov_b32_dpp v13, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000448734: 7E1A02FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 00000044873C: D5010003 200E0703
	v_add_f32_e32 v4, v4, v7                                   // 000000448744: 06080F04
	v_mov_b32_dpp v14, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000448748: 7E1C02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 000000448750: D5010002 200E0502
	v_add_f32_e32 v5, v5, v12                                  // 000000448758: 060A1905
	.long 0xd72c0007                                           // 00000044875C: D72C0007
	v_cndmask_b32_e32 v1, s42, v11, vcc_lo                     // 000000448760: 0202162A
	v_add_f32_e32 v3, v3, v13                                  // 000000448764: 06061B03
	v_mov_b32_dpp v11, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000448768: 7E1602FA FF016404
	v_add_f32_e32 v2, v2, v14                                  // 000000448770: 06041D02
	v_mov_b32_dpp v12, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000448774: 7E1802FA FF016405
	v_cndmask_b32_e64 v4, -v4, v4, s5                          // 00000044877C: D5010004 20160904
	v_cndmask_b32_e64 v5, -v5, v5, s5                          // 000000448784: D5010005 20160B05
	v_mov_b32_dpp v13, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000044878C: 7E1A02FA FF016403
	v_mov_b32_dpp v14, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000448794: 7E1C02FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s5                          // 00000044879C: D5010002 20160502
	v_cndmask_b32_e64 v3, -v3, v3, s5                          // 0000004487A4: D5010003 20160703
	v_dual_add_f32 v4, v4, v11 :: v_dual_add_f32 v5, v5, v12   // 0000004487AC: C9081704 04041905
	v_add_nc_u32_e32 v8, 8, v8                                 // 0000004487B4: 4A101088
	v_sub_nc_u32_e32 v6, v6, v7                                // 0000004487B8: 4C0C0F06
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004487BC: BF870214
	v_add_f32_e32 v3, v3, v13                                  // 0000004487C0: 06061B03
	v_mov_b32_dpp v11, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004487C4: 7E1602FA FF016804
	v_mov_b32_dpp v12, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004487CC: 7E1802FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s6                          // 0000004487D4: D5010005 201A0B05
	v_add_f32_e32 v2, v2, v14                                  // 0000004487DC: 06041D02
	v_cndmask_b32_e64 v4, -v4, v4, s6                          // 0000004487E0: D5010004 201A0904
	v_mov_b32_dpp v13, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004487E8: 7E1A02FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s6                          // 0000004487F0: D5010003 201A0703
	v_add_f32_e32 v5, v5, v12                                  // 0000004487F8: 060A1905
	v_mov_b32_dpp v14, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004487FC: 7E1C02FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s6                          // 000000448804: D5010002 201A0502
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000044880C: BF870214
	v_dual_add_f32 v4, v4, v11 :: v_dual_add_f32 v3, v3, v13   // 000000448810: C9081704 04021B03
	v_mov_b32_e32 v12, v5                                      // 000000448818: 7E180305
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 00000044881C: D5010005 20020B05
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000448824: BF870213
	v_dual_add_f32 v2, v2, v14 :: v_dual_mov_b32 v11, v4       // 000000448828: C9101D02 020A0104
	v_mov_b32_e32 v13, v3                                      // 000000448830: 7E1A0303
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000448834: BF870224
	v_permlanex16_b32 v12, v12, s40, 0xfedcba98                // 000000448838: D65C000C 03FC510C FEDCBA98
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 000000448844: D5010004 20020904
	v_mov_b32_e32 v14, v2                                      // 00000044884C: 7E1C0302
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 000000448850: D5010002 20020502
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 000000448858: D5010003 20020703
	v_permlanex16_b32 v11, v11, s40, 0xfedcba98                // 000000448860: D65C000B 03FC510B FEDCBA98
	v_permlanex16_b32 v13, v13, s40, 0xfedcba98                // 00000044886C: D65C000D 03FC510D FEDCBA98
	v_add_f32_e32 v5, v5, v12                                  // 000000448878: 060A1905
	v_permlanex16_b32 v14, v14, s40, 0xfedcba98                // 00000044887C: D65C000E 03FC510E FEDCBA98
	v_cmp_le_i32_e32 vcc_lo, s11, v8                           // 000000448888: 7C86100B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000044888C: BF870224
	v_dual_add_f32 v4, v4, v11 :: v_dual_add_f32 v11, v3, v13  // 000000448890: C9081704 040A1B03
	v_add_nc_u32_e32 v6, v9, v6                                // 000000448898: 4A0C0D09
	v_add_f32_e32 v7, v2, v14                                  // 00000044889C: 060E1D02
	v_fma_mixhi_f16 v2, v5, s45, 0                             // 0000004488A0: CC220002 02005B05
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004488A8: BF870004
	v_fma_mixlo_f16 v2, v4, s45, 0                             // 0000004488AC: CC210002 02005B04
	v_fma_mixlo_f16 v3, v11, s45, 0                            // 0000004488B4: CC210003 02005B0B
	v_add_nc_u32_e32 v9, 0x800, v9                             // 0000004488BC: 4A1212FF 00000800
	v_fma_mixhi_f16 v3, v7, s45, 0                             // 0000004488C4: CC220003 02005B07
	s_or_b32 s39, vcc_lo, s39                                  // 0000004488CC: 8C27276A
	ds_store_b64 v6, v[2:3]                                    // 0000004488D0: D9340000 00000206
	s_and_not1_b32 exec_lo, exec_lo, s39                       // 0000004488D8: 917E277E
	s_cbranch_execz 289                                        // 0000004488DC: BFA50121 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi1ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x864>
	.long 0xd72d0002                                           // 0000004488E0: D72D0002
	v_cndmask_b32_e32 v0, v8, v44, vcc_lo                      // 0000004488E4: 02005908
	s_mov_b32 s7, -1                                           // 0000004488E8: BE8700C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004488EC: BF870091
	.long 0xd72c0003                                           // 0000004488F0: D72C0003
	v_cndmask_b32_e32 v0, v2, v37, vcc_lo                      // 0000004488F4: 02004B02
	v_sub_nc_u32_e32 v3, v8, v3                                // 0000004488F8: 4C060708
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000004488FC: BF870121
	v_subrev_nc_u32_e32 v5, s37, v3                            // 000000448900: 4E0A0625
	v_cmp_le_u32_e32 vcc_lo, s37, v3                           // 000000448904: 7C960625
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_add_nc_u32 v4, 1, v2// 000000448908: CA600B03 03040481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000448910: BF870111
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000448914: 02040902
	v_cmp_le_u32_e32 vcc_lo, s37, v3                           // 000000448918: 7C960625
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000044891C: BF870092
	v_add_nc_u32_e32 v4, 1, v2                                 // 000000448920: 4A080481
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000448924: 02040902
	s_and_not1_b32 vcc_lo, exec_lo, s36                        // 000000448928: 916A247E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000044892C: BF870091
	v_xor_b32_e32 v12, s41, v2                                 // 000000448930: 3A180429
	v_subrev_nc_u32_e32 v11, s41, v12                          // 000000448934: 4E161829
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000448938: BF8700A1
	v_mad_u64_u32 v[6:7], null, s43, v11, v[1:2]               // 00000044893C: D6FE7C06 0406162B
	v_min_i32_e32 v2, s27, v11                                 // 000000448944: 2204161B
	v_mad_i64_i32 v[4:5], null, v2, s38, 0                     // 000000448948: D6FF7C04 02004D02
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000448950: BF870093
	v_ashrrev_i32_e32 v7, 31, v6                               // 000000448954: 340E0C9F
	.long 0xd73c0002                                           // 000000448958: D73C0002
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 00000044895C: 02020C81
	s_cbranch_vccnz 211                                        // 000000448960: BFA400D3 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi1ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x7b0>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000448964: BF870093
	.long 0xd7006a06                                           // 000000448968: D7006A06
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 00000044896C: 02020D04
	v_add_co_ci_u32_e64 v7, null, v5, v7, vcc_lo               // 000000448970: D5207C07 01AA0F05
	.long 0x7f3a3880                                           // 000000448978: 7F3A3880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000044897C: BF870112
	.long 0xd73c0006                                           // 000000448980: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000448984: 02020C81
	.long 0x7f40399d                                           // 000000448988: 7F40399D
	s_waitcnt lgkmcnt(0)                                       // 00000044898C: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000448990: BF870092
	.long 0xd7006a0d                                           // 000000448994: D7006A0D
	v_cndmask_b32_e32 v1, s30, v6, vcc_lo                      // 000000448998: 02020C1E
	v_add_co_ci_u32_e64 v14, null, s31, v7, vcc_lo             // 00000044899C: D5207C0E 01AA0E1F
	.long 0xd7006a06                                           // 0000004489A4: D7006A06
	v_cndmask_b32_e32 v1, s22, v6, vcc_lo                      // 0000004489A8: 02020C16
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004489AC: BF870001
	v_add_co_ci_u32_e64 v7, null, s23, v7, vcc_lo              // 0000004489B0: D5207C07 01AA0E17
	global_load_b64 v[13:14], v[13:14], off                    // 0000004489B8: DC560000 0D7C000D
	.long 0xd7006a0f                                           // 0000004489C0: D7006A0F
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 0000004489C4: 0202040C
	global_load_b64 v[6:7], v[6:7], off                        // 0000004489C8: DC560000 067C0006
	v_add_co_ci_u32_e64 v16, null, s13, v3, vcc_lo             // 0000004489D0: D5207C10 01AA060D
	s_clause 0x1                                               // 0000004489D8: BF850001
	global_load_b32 v17, v[15:16], off                         // 0000004489DC: DC520000 117C000F
	global_load_d16_b16 v15, v[15:16], off offset:4            // 0000004489E4: DC820004 0F7C000F
	s_waitcnt vmcnt(3)                                         // 0000004489EC: BF890FF7
	.long 0x7e20390d                                           // 0000004489F0: 7E20390D
	s_waitcnt vmcnt(2)                                         // 0000004489F4: BF890BF7
	v_and_b32_e32 v39, 0xffff0000, v6                          // 0000004489F8: 364E0CFF FFFF0000
	v_lshlrev_b32_e32 v6, 16, v6                               // 000000448A00: 300C0C90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000448A04: BF870093
	v_lshlrev_b32_e32 v16, 16, v16                             // 000000448A08: 30202090
	v_mul_f32_e32 v20, 0xbfb8aa3b, v16                         // 000000448A0C: 102820FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000448A14: BF870291
	v_exp_f32_e32 v20, v20                                     // 000000448A18: 7E284B14
	v_dual_add_f32 v20, 1.0, v20 :: v_dual_and_b32 v13, 0xffff0000, v13// 000000448A1C: C92428F2 140C1AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000448A28: BF870111
	v_mul_f32_e32 v19, 0xbfb8aa3b, v13                         // 000000448A2C: 10261AFF BFB8AA3B
	v_div_scale_f32 v24, null, v20, v20, v16                   // 000000448A34: D6FC7C18 04422914
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000448A3C: BF8701B2
	v_exp_f32_e32 v19, v19                                     // 000000448A40: 7E264B13
	v_lshlrev_b32_e32 v18, 16, v14                             // 000000448A44: 30241C90
	v_div_scale_f32 v37, s8, v16, v20, v16                     // 000000448A48: D6FC0825 04422910
	v_rcp_f32_e32 v28, v24                                     // 000000448A50: 7E385518
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000448A54: BF870196
	v_add_f32_e32 v19, 1.0, v19                                // 000000448A58: 062626F2
	v_mul_f32_e32 v21, 0xbfb8aa3b, v18                         // 000000448A5C: 102A24FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000448A64: BF870195
	v_fma_f32 v36, -v24, v28, 1.0                              // 000000448A68: D6130024 23CA3918
	v_div_scale_f32 v23, null, v19, v19, v13                   // 000000448A70: D6FC7C17 04362713
	s_delay_alu instid0(VALU_DEP_3)                            // 000000448A78: BF870003
	v_exp_f32_e32 v21, v21                                     // 000000448A7C: 7E2A4B15
	v_and_b32_e32 v14, 0xffff0000, v14                         // 000000448A80: 361C1CFF FFFF0000
	v_div_scale_f32 v33, vcc_lo, v13, v19, v13                 // 000000448A88: D6FC6A21 0436270D
	v_fmac_f32_e32 v28, v36, v28                               // 000000448A90: 56383924
	v_rcp_f32_e32 v26, v23                                     // 000000448A94: 7E345517
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_3)   // 000000448A98: BF870186
	v_dual_add_f32 v21, 1.0, v21 :: v_dual_mul_f32 v22, 0xbfb8aa3b, v14// 000000448A9C: C9062AF2 15161CFF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000448AA8: BF870115
	v_fma_f32 v34, -v23, v26, 1.0                              // 000000448AAC: D6130022 23CA3517
	v_div_scale_f32 v25, null, v21, v21, v18                   // 000000448AB4: D6FC7C19 044A2B15
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000448ABC: BF8701A3
	v_exp_f32_e32 v22, v22                                     // 000000448AC0: 7E2C4B16
	v_div_scale_f32 v35, s7, v18, v21, v18                     // 000000448AC4: D6FC0723 044A2B12
	v_fmac_f32_e32 v26, v34, v26                               // 000000448ACC: 56343522
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000448AD0: BF870313
	v_rcp_f32_e32 v30, v25                                     // 000000448AD4: 7E3C5519
	v_add_f32_e32 v22, 1.0, v22                                // 000000448AD8: 062C2CF2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000448ADC: BF870115
	v_fma_f32 v38, -v25, v30, 1.0                              // 000000448AE0: D6130026 23CA3D19
	v_div_scale_f32 v27, null, v22, v22, v14                   // 000000448AE8: D6FC7C1B 043A2D16
	v_div_scale_f32 v36, s9, v14, v22, v14                     // 000000448AF0: D6FC0924 043A2D0E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000448AF8: BF870193
	v_fmac_f32_e32 v30, v38, v30                               // 000000448AFC: 563C3D26
	v_rcp_f32_e32 v31, v27                                     // 000000448B00: 7E3E551B
	v_mul_f32_e32 v38, v33, v26                                // 000000448B04: 104C3521
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000448B08: BF870291
	v_fma_f32 v44, -v23, v38, v33                              // 000000448B0C: D613002C 24864D17
	v_fma_f32 v34, -v27, v31, 1.0                              // 000000448B14: D6130022 23CA3F1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000448B1C: BF870091
	v_dual_fmac_f32 v38, v44, v26 :: v_dual_fmac_f32 v31, v34, v31// 000000448B20: C800352C 261E3F22
	v_fma_f32 v23, -v23, v38, v33                              // 000000448B28: D6130017 24864D17
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000448B30: BF870092
	v_mul_f32_e32 v45, v36, v31                                // 000000448B34: 105A3F24
	v_fma_f32 v44, -v27, v45, v36                              // 000000448B38: D613002C 24925B1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000448B40: BF870211
	v_fmac_f32_e32 v45, v44, v31                               // 000000448B44: 565A3F2C
	v_div_fmas_f32 v23, v23, v26, v38                          // 000000448B48: D6370017 049A3517
	s_mov_b32 vcc_lo, s8                                       // 000000448B50: BEEA0008
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000448B54: BF870191
	v_div_fixup_f32 v13, v23, v19, v13                         // 000000448B58: D627000D 04362717
	v_fma_f32 v23, -v27, v45, v36                              // 000000448B60: D6130017 24925B1B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000448B68: BF870122
	v_mul_f32_e32 v13, v13, v39                                // 000000448B6C: 101A4F0D
	v_dual_mul_f32 v34, v37, v28 :: v_dual_mul_f32 v43, v35, v30// 000000448B70: C8C63925 222A3D23
	.long 0x7e3a398d                                           // 000000448B78: 7E3A398D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000448B7C: BF870192
	v_fma_f32 v46, -v24, v34, v37                              // 000000448B80: D613002E 24964518
	v_fma_f32 v47, -v25, v43, v35                              // 000000448B88: D613002F 248E5719
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000448B90: BF870091
	v_dual_fmac_f32 v34, v46, v28 :: v_dual_fmac_f32 v43, v47, v30// 000000448B94: C800392E 222A3D2F
	v_fma_f32 v24, -v24, v34, v37                              // 000000448B9C: D6130018 24964518
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000448BA4: BF870112
	v_fma_f32 v25, -v25, v43, v35                              // 000000448BA8: D6130019 248E5719
	v_div_fmas_f32 v24, v24, v28, v34                          // 000000448BB0: D6370018 048A3918
	s_mov_b32 vcc_lo, s7                                       // 000000448BB8: BEEA0007
	s_mov_b32 s7, 0                                            // 000000448BBC: BE870080
	s_delay_alu instid0(VALU_DEP_2)                            // 000000448BC0: BF870002
	v_div_fmas_f32 v19, v25, v30, v43                          // 000000448BC4: D6370013 04AE3D19
	s_mov_b32 vcc_lo, s9                                       // 000000448BCC: BEEA0009
	v_div_fixup_f32 v16, v24, v20, v16                         // 000000448BD0: D6270010 04422918
	v_lshlrev_b32_e32 v20, 16, v7                              // 000000448BD8: 30280E90
	v_and_b32_e32 v7, 0xffff0000, v7                           // 000000448BDC: 360E0EFF FFFF0000
	v_div_fixup_f32 v18, v19, v21, v18                         // 000000448BE4: D6270012 044A2B13
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000448BEC: BF8700A4
	v_mul_f32_e32 v6, v16, v6                                  // 000000448BF0: 100C0D10
	v_div_fmas_f32 v16, v23, v31, v45                          // 000000448BF4: D6370010 04B63F17
	v_div_fixup_f32 v14, v16, v22, v14                         // 000000448BFC: D627000E 043A2D10
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000448C04: BF870091
	v_dual_mul_f32 v7, v14, v7 :: v_dual_and_b32 v16, 1, v29   // 000000448C08: C8E40F0E 07103A81
	v_add3_u32 v13, v13, v16, 0x7fff                           // 000000448C10: D655000D 03FE210D 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000448C1C: BF870112
	v_bfe_u32 v16, v7, 16, 1                                   // 000000448C20: D6100010 02052107
	v_and_b32_e32 v13, 0xffff0000, v13                         // 000000448C28: 361A1AFF FFFF0000
	.long 0x7e403986                                           // 000000448C30: 7E403986
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000448C34: BF8701A3
	v_add3_u32 v7, v7, v16, 0x7fff                             // 000000448C38: D6550007 03FE2107 00007FFF
	v_mul_f32_e32 v18, v18, v20                                // 000000448C44: 10242912
	v_and_b32_e32 v20, 1, v32                                  // 000000448C48: 36284081
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000448C4C: BF870112
	v_bfe_u32 v19, v18, 16, 1                                  // 000000448C50: D6100013 02052112
	v_add3_u32 v6, v6, v20, 0x7fff                             // 000000448C58: D6550006 03FE2906 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000448C64: BF870112
	v_add3_u32 v14, v18, v19, 0x7fff                           // 000000448C68: D655000E 03FE2712 00007FFF
	v_and_b32_e32 v6, 0xffff0000, v6                           // 000000448C74: 360C0CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000448C7C: BF8701B2
	v_and_b32_e32 v18, 0xffff0000, v14                         // 000000448C80: 36241CFF FFFF0000
	s_waitcnt vmcnt(1)                                         // 000000448C88: BF8907F7
	v_fma_mix_f32 v14, v17, v13, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000448C8C: CC20080E 8A021B11
	v_fma_mix_f32 v16, v17, v6, neg(0) op_sel_hi:[1,0,0]       // 000000448C94: CC200010 8A020D11
	s_waitcnt vmcnt(0)                                         // 000000448C9C: BF8903F7
	v_fma_mix_f32 v13, v15, v18, neg(0) op_sel_hi:[1,0,0]      // 000000448CA0: CC20000D 8A02250F
	v_and_b32_e32 v15, 0xffff0000, v7                          // 000000448CA8: 361E0EFF FFFF0000
	s_and_not1_b32 vcc_lo, exec_lo, s7                         // 000000448CB0: 916A077E
	s_cbranch_vccnz 65129                                      // 000000448CB4: BFA4FE69 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi1ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x15c>
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000448CB8: BF8700A3
	.long 0xd73c0004                                           // 000000448CBC: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 000000448CC0: 02020881
	s_waitcnt lgkmcnt(0)                                       // 000000448CC4: BF89FC07
	.long 0xd7006a04                                           // 000000448CC8: D7006A04
	v_cndmask_b32_e32 v1, s30, v4, vcc_lo                      // 000000448CCC: 0202081E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000448CD0: BF870111
	v_add_co_ci_u32_e64 v5, null, s31, v5, vcc_lo              // 000000448CD4: D5207C05 01AA0A1F
	.long 0xd7006a04                                           // 000000448CDC: D7006A04
	v_cndmask_b32_e32 v1, v4, v2, vcc_lo                       // 000000448CE0: 02020504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000448CE4: BF8700A1
	v_add_co_ci_u32_e64 v5, null, v5, v3, vcc_lo               // 000000448CE8: D5207C05 01AA0705
	.long 0xd7006a06                                           // 000000448CF0: D7006A06
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 000000448CF4: 0202040C
	v_add_co_ci_u32_e64 v7, null, s13, v3, vcc_lo              // 000000448CF8: D5207C07 01AA060D
	global_load_b64 v[4:5], v[4:5], off                        // 000000448D00: DC560000 047C0004
	s_clause 0x1                                               // 000000448D08: BF850001
	global_load_b32 v15, v[6:7], off                           // 000000448D0C: DC520000 0F7C0006
	global_load_d16_b16 v6, v[6:7], off offset:4               // 000000448D14: DC820004 067C0006
	s_waitcnt vmcnt(2)                                         // 000000448D1C: BF890BF7
	.long 0x7e0e3904                                           // 000000448D20: 7E0E3904
	v_and_b32_e32 v4, 0xffff0000, v4                           // 000000448D24: 360808FF FFFF0000
	v_lshlrev_b32_e32 v13, 16, v5                              // 000000448D2C: 301A0A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000448D30: BF8701A3
	v_lshlrev_b32_e32 v7, 16, v7                               // 000000448D34: 300E0E90
	s_waitcnt vmcnt(1)                                         // 000000448D38: BF8907F7
	v_fma_mix_f32 v14, v15, v4, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000448D3C: CC20080E 8A02090F
	s_waitcnt vmcnt(0)                                         // 000000448D44: BF8903F7
	v_fma_mix_f32 v13, v6, v13, neg(0) op_sel_hi:[1,0,0]       // 000000448D48: CC20000D 8A021B06
	v_fma_mix_f32 v16, v15, v7, neg(0) op_sel_hi:[1,0,0]       // 000000448D50: CC200010 8A020F0F
	v_and_b32_e32 v15, 0xffff0000, v5                          // 000000448D58: 361E0AFF FFFF0000
	s_branch 65086                                             // 000000448D60: BFA0FE3E <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi1ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x15c>
	s_or_b32 exec_lo, exec_lo, s39                             // 000000448D64: 8C7E277E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000448D68: BF870009
	s_or_b32 exec_lo, exec_lo, s10                             // 000000448D6C: 8C7E0A7E
	s_bfe_i32 s10, s11, 0x1001c                                // 000000448D70: 938AFF0B 0001001C
	v_mad_u32_u24 v4, v41, 24, 0x2f0                           // 000000448D78: D60B0004 03FD3129 000002F0
	s_lshr_b64 s[0:1], s[10:11], 29                            // 000000448D84: 85809D0A
	s_lshr_b32 s1, s35, 28                                     // 000000448D88: 85019C23
	s_add_i32 s0, s0, 7                                        // 000000448D8C: 81008700
	s_add_i32 s1, s25, s1                                      // 000000448D90: 81010119
	s_ashr_i32 s0, s0, 3                                       // 000000448D94: 86008300
	v_lshrrev_b32_e32 v1, 5, v4                                // 000000448D98: 32020885
	.long 0xd72c0003                                           // 000000448D9C: D72C0003
	v_cndmask_b32_e32 v1, s0, v40, vcc_lo                      // 000000448DA0: 02025000
	s_ashr_i32 s1, s1, 4                                       // 000000448DA4: 86018401
	s_lshl_b32 s3, s11, 3                                      // 000000448DA8: 8403830B
	s_lshl_b32 s5, s34, 3                                      // 000000448DAC: 84058322
	s_mul_i32 s7, s1, s2                                       // 000000448DB0: 96070201
	s_ashr_i32 s6, s5, 31                                      // 000000448DB4: 86069F05
	v_subrev_nc_u32_e32 v1, 24, v1                             // 000000448DB8: 4E020298
	v_cmp_eq_u32_e32 vcc_lo, 0, v41                            // 000000448DBC: 7C945280
	v_add_nc_u32_e32 v2, s0, v3                                // 000000448DC0: 4A040600
	s_mul_hi_i32 s0, s1, s2                                    // 000000448DC4: 97000201
	s_add_u32 s1, s7, s5                                       // 000000448DC8: 80010507
	s_addc_u32 s0, s0, s6                                      // 000000448DCC: 82000600
	s_mul_hi_u32 s5, s1, 0x300                                 // 000000448DD0: 9685FF01 00000300
	v_min_i32_e32 v43, s3, v2                                  // 000000448DD8: 22560403
	s_mul_i32 s3, s0, 0x300                                    // 000000448DDC: 9603FF00 00000300
	s_mulk_i32 s1, 0x300                                       // 000000448DE4: B8010300
	v_cndmask_b32_e64 v12, v1, 23, vcc_lo                      // 000000448DE8: D501000C 01A92F01
	v_add_nc_u32_e32 v11, 8, v4                                // 000000448DF0: 4A160888
	.long 0xd4410000                                           // 000000448DF4: D4410000
	v_cndmask_b32_e32 v1, v3, v43, vcc_lo                      // 000000448DF8: 02025703
	s_add_i32 s5, s5, s3                                       // 000000448DFC: 81050305
	s_waitcnt lgkmcnt(0)                                       // 000000448E00: BF89FC07
	s_add_u32 s6, s28, s1                                      // 000000448E04: 8006011C
	s_addc_u32 s7, s29, s5                                     // 000000448E08: 8207051D
	s_barrier                                                  // 000000448E0C: BFBD0000
	buffer_gl0_inv                                             // 000000448E10: E0AC0000 00000000
	s_and_saveexec_b32 s3, s0                                  // 000000448E18: BE832000
	s_cbranch_execz 121                                        // 000000448E1C: BFA50079 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi1ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xb04>
	v_lshrrev_b32_e32 v1, 5, v11                               // 000000448E20: 32021685
	.long 0xd4440001                                           // 000000448E24: D4440001
	v_cndmask_b32_e32 v1, 23, v12, vcc_lo                      // 000000448E28: 02021897
	v_mov_b32_e32 v13, 0                                       // 000000448E2C: 7E1A0280
	v_mad_i64_i32 v[5:6], null, 0x300, v3, s[6:7]              // 000000448E30: D6FF7C05 001A06FF 00000300
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000448E3C: BF870214
	v_subrev_nc_u32_e32 v1, 24, v1                             // 000000448E40: 4E020298
	v_cndmask_b32_e64 v2, 0xe9, 1, s1                          // 000000448E44: D5010002 000502FF 000000E9
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000448E50: BF870112
	v_cndmask_b32_e64 v1, v1, 23, vcc_lo                       // 000000448E54: D5010001 01A92F01
	v_dual_mov_b32 v2, v13 :: v_dual_add_nc_u32 v9, v2, v12    // 000000448E5C: CA20010D 02081902
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000448E64: BF870112
	.long 0xd4440001                                           // 000000448E68: D4440001
	v_cndmask_b32_e32 v1, 23, v1, vcc_lo                       // 000000448E6C: 02020297
	v_lshlrev_b32_e32 v14, 24, v9                              // 000000448E70: 301C1298
	.long 0xd73c0007                                           // 000000448E74: D73C0007
	v_cndmask_b32_e32 v1, 2, v12, vcc_lo                       // 000000448E78: 02021882
	v_bfe_i32 v9, v9, 7, 1                                     // 000000448E7C: D6110009 02050F09
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000448E84: BF870214
	v_cndmask_b32_e64 v15, 0xe9, 1, s1                         // 000000448E88: D501000F 000502FF 000000E9
	v_ashrrev_i32_e32 v13, 22, v14                             // 000000448E94: 341A1C96
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000448E98: BF870194
	.long 0xd7000107                                           // 000000448E9C: D7000107
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 000000448EA0: 02020F05
	v_add_nc_u32_e32 v14, v15, v1                              // 000000448EA4: 4A1C030F
	.long 0xd73c0001                                           // 000000448EA8: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000448EAC: 02020282
	v_add_co_ci_u32_e64 v8, null, v6, v8, s1                   // 000000448EB0: D5207C08 00061106
	.long 0xd7000110                                           // 000000448EB8: D7000110
	v_cndmask_b32_e32 v1, v5, v13, vcc_lo                      // 000000448EBC: 02021B05
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000448EC0: BF870244
	v_lshlrev_b32_e32 v15, 24, v14                             // 000000448EC4: 301E1C98
	v_add_co_ci_u32_e64 v17, null, v6, v9, s1                  // 000000448EC8: D5207C11 00061306
	v_bfe_i32 v9, v14, 7, 1                                    // 000000448ED0: D6110009 02050F0E
	.long 0xd700012c                                           // 000000448ED8: D700012C
	v_cndmask_b32_e32 v1, v5, v1, vcc_lo                       // 000000448EDC: 02020305
	v_ashrrev_i32_e32 v13, 22, v15                             // 000000448EE0: 341A1E96
	v_add_co_ci_u32_e64 v45, null, v6, v2, s1                  // 000000448EE4: D5207C2D 00060506
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000448EEC: BF870092
	.long 0xd700012e                                           // 000000448EF0: D700012E
	v_cndmask_b32_e32 v1, v5, v13, vcc_lo                      // 000000448EF4: 02021B05
	v_add_co_ci_u32_e64 v47, null, v6, v9, s1                  // 000000448EF8: D5207C2F 00061306
	s_clause 0x1f                                              // 000000448F00: BF85001F
	global_load_b32 v2, v[7:8], off                            // 000000448F04: DC520000 027C0007
	global_load_b32 v35, v[7:8], off offset:96                 // 000000448F0C: DC520060 237C0007
	global_load_b32 v31, v[7:8], off offset:192                // 000000448F14: DC5200C0 1F7C0007
	global_load_b32 v27, v[7:8], off offset:288                // 000000448F1C: DC520120 1B7C0007
	global_load_b32 v23, v[7:8], off offset:384                // 000000448F24: DC520180 177C0007
	global_load_b32 v19, v[7:8], off offset:480                // 000000448F2C: DC5201E0 137C0007
	global_load_b32 v15, v[7:8], off offset:576                // 000000448F34: DC520240 0F7C0007
	global_load_b32 v7, v[7:8], off offset:672                 // 000000448F3C: DC5202A0 077C0007
	global_load_b32 v1, v[16:17], off                          // 000000448F44: DC520000 017C0010
	global_load_b32 v34, v[16:17], off offset:96               // 000000448F4C: DC520060 227C0010
	global_load_b32 v30, v[16:17], off offset:192              // 000000448F54: DC5200C0 1E7C0010
	global_load_b32 v26, v[16:17], off offset:288              // 000000448F5C: DC520120 1A7C0010
	global_load_b32 v22, v[16:17], off offset:384              // 000000448F64: DC520180 167C0010
	global_load_b32 v18, v[16:17], off offset:480              // 000000448F6C: DC5201E0 127C0010
	global_load_b32 v14, v[16:17], off offset:576              // 000000448F74: DC520240 0E7C0010
	global_load_b32 v6, v[16:17], off offset:672               // 000000448F7C: DC5202A0 067C0010
	global_load_b32 v39, v[44:45], off                         // 000000448F84: DC520000 277C002C
	global_load_b32 v37, v[44:45], off offset:96               // 000000448F8C: DC520060 257C002C
	global_load_b32 v33, v[44:45], off offset:192              // 000000448F94: DC5200C0 217C002C
	global_load_b32 v29, v[44:45], off offset:288              // 000000448F9C: DC520120 1D7C002C
	global_load_b32 v25, v[44:45], off offset:384              // 000000448FA4: DC520180 197C002C
	global_load_b32 v21, v[44:45], off offset:480              // 000000448FAC: DC5201E0 157C002C
	global_load_b32 v17, v[44:45], off offset:576              // 000000448FB4: DC520240 117C002C
	global_load_b32 v9, v[44:45], off offset:672               // 000000448FBC: DC5202A0 097C002C
	global_load_b32 v38, v[46:47], off                         // 000000448FC4: DC520000 267C002E
	global_load_b32 v36, v[46:47], off offset:96               // 000000448FCC: DC520060 247C002E
	global_load_b32 v32, v[46:47], off offset:192              // 000000448FD4: DC5200C0 207C002E
	global_load_b32 v28, v[46:47], off offset:288              // 000000448FDC: DC520120 1C7C002E
	global_load_b32 v24, v[46:47], off offset:384              // 000000448FE4: DC520180 187C002E
	global_load_b32 v20, v[46:47], off offset:480              // 000000448FEC: DC5201E0 147C002E
	global_load_b32 v16, v[46:47], off offset:576              // 000000448FF4: DC520240 107C002E
	global_load_b32 v8, v[46:47], off offset:672               // 000000448FFC: DC5202A0 087C002E
	s_or_b32 exec_lo, exec_lo, s3                              // 000000449004: 8C7E037E
	v_dual_mov_b32 v5, 0 :: v_dual_mov_b32 v44, 0              // 000000449008: CA100080 052C0080
	v_dual_mov_b32 v45, 0 :: v_dual_mov_b32 v46, 0             // 000000449010: CA100080 2D2E0080
	v_dual_mov_b32 v47, 0 :: v_dual_mov_b32 v48, 0             // 000000449018: CA100080 2F300080
	v_dual_mov_b32 v49, 0 :: v_dual_mov_b32 v50, 0             // 000000449020: CA100080 31320080
	s_ashr_i32 s3, s2, 31                                      // 000000449028: 86039F02
	s_and_saveexec_b32 s1, s0                                  // 00000044902C: BE812000
	s_cbranch_execz 1113                                       // 000000449030: BFA50459 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi1ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1c98>
	v_lshrrev_b32_e32 v5, 5, v11                               // 000000449034: 320A1685
	v_dual_mov_b32 v45, 23 :: v_dual_and_b32 v44, 0x7e0, v4    // 000000449038: CA240097 2D2C08FF 000007E0
	v_mul_i32_i24_e32 v11, 0xffffffe8, v41                     // 000000449044: 121652FF FFFFFFE8
	.long 0xd703002f                                           // 00000044904C: D703002F
	v_cndmask_b32_e32 v0, v12, v129, vcc_lo                    // 000000449050: 0201030C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000449054: BF870224
	v_subrev_nc_u32_e32 v4, 24, v5                             // 000000449058: 4E080A98
	v_dual_mov_b32 v5, 0 :: v_dual_and_b32 v46, 16, v0         // 00000044905C: CA240080 052E0090
	v_add3_u32 v53, v11, v44, 0xfffffd34                       // 000000449064: D6550035 03FE590B FFFFFD34
	.long 0x7e58392d                                           // 000000449070: 7E58392D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000449074: BF870004
	v_cndmask_b32_e64 v4, v4, 23, vcc_lo                       // 000000449078: D5010004 01A92F04
	.long 0xd762402c                                           // 000000449080: D762402C
	v_cndmask_b32_e32 v1, 0xff, v47, vcc_lo                    // 000000449084: 02025EFF 000000FF
	v_or_b32_e32 v10, 4, v10                                   // 00000044908C: 38141484
	v_ashrrev_i32_e32 v13, 31, v12                             // 000000449090: 341A189F
	v_add_nc_u32_e32 v51, 1, v3                                // 000000449094: 4A660681
	.long 0xd703402f                                           // 000000449098: D703402F
	v_cndmask_b32_e32 v0, v4, v129, vcc_lo                     // 00000044909C: 02010304
	v_lshl_or_b32 v54, v3, 5, v46                              // 0000004490A0: D6560036 04B90B03
	.long 0xd7040003                                           // 0000004490A8: D7040003
	v_cndmask_b32_e32 v1, v12, v44, vcc_lo                     // 0000004490AC: 0202590C
	v_cmp_gt_u16_e32 vcc_lo, 24, v172/*Invalid register, operand has 'VGPR_32_Lo128' register class*/// 0000004490B0: 7C795898
	v_mad_u32_u24 v48, v10, 3, 0x2f0                           // 0000004490B4: D60B0030 03FD070A 000002F0
	.long 0xd762102d                                           // 0000004490C0: D762102D
	v_cndmask_b32_e32 v1, 0xff, v47, vcc_lo                    // 0000004490C4: 02025EFF 000000FF
	v_mul_i32_i24_e32 v50, -3, v10                             // 0000004490CC: 126414C3
	.long 0xd73c000a                                           // 0000004490D0: D73C000A
	v_cndmask_b32_e32 v1, 2, v12, vcc_lo                       // 0000004490D4: 02021882
	v_cndmask_b16 v3, v3, v47, vcc_lo                          // 0000004490D8: D65D0003 01AA5F03
	v_dual_mov_b32 v46, v5 :: v_dual_and_b32 v13, 0x7e0, v48   // 0000004490E0: CA240105 2E0C60FF 000007E0
	.long 0xd43d0000                                           // 0000004490EC: D43D0000
	v_cndmask_b32_e32 v1, 24, v45, vcc_lo                      // 0000004490F0: 02025A98
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000004490F4: BF870223
	v_dual_mov_b32 v48, v5 :: v_dual_and_b32 v3, 0xff, v3      // 0000004490F8: CA240105 300206FF 000000FF
	v_sub_nc_u32_e32 v52, 0, v43                               // 000000449104: 4C685680
	v_add3_u32 v55, v50, v13, 0xfffffd34                       // 000000449108: D6550037 03FE1B32 FFFFFD34
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000449114: BF870244
	v_cndmask_b16 v12, 0, v47, s0                              // 000000449118: D65D100C 00025E80
	v_mov_b32_e32 v44, v5                                      // 000000449120: 7E580305
	v_dual_mov_b32 v45, v5 :: v_dual_lshlrev_b32 v56, 2, v3    // 000000449124: CA220105 2D380682
	v_mov_b32_e32 v47, v5                                      // 00000044912C: 7E5E0305
	v_dual_mov_b32 v50, v5 :: v_dual_and_b32 v57, 0xff, v12    // 000000449130: CA240105 323818FF 000000FF
	.long 0xd73c000c                                           // 00000044913C: D73C000C
	v_cndmask_b32_e32 v1, 2, v4, vcc_lo                        // 000000449140: 02020882
	v_mov_b32_e32 v49, v5                                      // 000000449144: 7E620305
	s_mov_b32 s5, 0                                            // 000000449148: BE850080
	s_delay_alu instid0(VALU_DEP_3)                            // 00000044914C: BF870003
	v_lshlrev_b32_e32 v57, 2, v57                              // 000000449150: 30727282
	s_mov_b32 s0, 0xdcd12d                                     // 000000449154: BE8000FF 00DCD12D
	s_movk_i32 s8, 0x83                                        // 00000044915C: B0080083
	s_movk_i32 s9, 0x1eee                                      // 000000449160: B0091EEE
	s_branch 943                                               // 000000449164: BFA003AF <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi1ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1b24>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000449168: 8C7E0A7E
	s_waitcnt vmcnt(23)                                        // 00000044916C: BF895FF7
	.long 0xd73d005a                                           // 000000449170: D73D005A
	v_cndmask_b32_e32 v1, v53, v1, vcc_lo                      // 000000449174: 02020335
	s_waitcnt vmcnt(7)                                         // 000000449178: BF891FF7
	.long 0xd73d0026                                           // 00000044917C: D73D0026
	v_cndmask_b32_e32 v1, v55, v38, vcc_lo                     // 000000449180: 02024D37
	ds_load_b128 v[1:4], v54                                   // 000000449184: DBFC0000 01000036
	.long 0xd73d0022                                           // 00000044918C: D73D0022
	v_cndmask_b32_e32 v1, v53, v34, vcc_lo                     // 000000449190: 02024535
	s_waitcnt vmcnt(6)                                         // 000000449194: BF891BF7
	.long 0xd73d0023                                           // 000000449198: D73D0023
	v_cndmask_b32_e32 v1, v55, v36, vcc_lo                     // 00000044919C: 02024937
	.long 0xd73d001e                                           // 0000004491A0: D73D001E
	v_cndmask_b32_e32 v1, v53, v30, vcc_lo                     // 0000004491A4: 02023D35
	v_bfe_u32 v39, v90, 9, 16                                  // 0000004491A8: D6100027 0241135A
	v_bfe_u32 v91, v90, 6, 16                                  // 0000004491B0: D610005B 02410D5A
	v_mul_u32_u24_e32 v96, s0, v39                             // 0000004491B8: 16C04E00
	v_mul_u32_u24_e32 v39, s8, v39                             // 0000004491BC: 164E4E08
	v_bfe_u32 v92, v90, 3, 16                                  // 0000004491C0: D610005C 0241075A
	v_lshl_add_u32 v39, v39, 24, v96                           // 0000004491C8: D6460027 05813127
	v_mul_u32_u24_e32 v96, s0, v91                             // 0000004491D0: 16C0B600
	v_mul_u32_u24_e32 v91, s8, v91                             // 0000004491D4: 16B6B608
	v_lshl_add_u32 v91, v91, 24, v96                           // 0000004491D8: D646005B 0581315B
	v_mul_u32_u24_e32 v96, s0, v92                             // 0000004491E0: 16C0B800
	v_mul_u32_u24_e32 v92, s8, v92                             // 0000004491E4: 16B8B808
	v_lshl_add_u32 v92, v92, 24, v96                           // 0000004491E8: D646005C 0581315C
	v_bfe_u32 v93, v38, 9, 16                                  // 0000004491F0: D610005D 02411326
	v_and_b32_e32 v90, 0xffff, v90                             // 0000004491F8: 36B4B4FF 0000FFFF
	v_mul_u32_u24_e32 v96, s0, v93                             // 000000449200: 16C0BA00
	v_mul_u32_u24_e32 v93, s8, v93                             // 000000449204: 16BABA08
	s_delay_alu instid0(VALU_DEP_2)                            // 000000449208: BF870002
	v_lshl_add_u32 v93, v93, 24, v96                           // 00000044920C: D646005D 0581315D
	v_mul_u32_u24_e32 v96, s0, v90                             // 000000449214: 16C0B400
	v_mul_u32_u24_e32 v90, s8, v90                             // 000000449218: 16B4B408
	v_sad_u8 v92, v92, 0, 0x6400                               // 00000044921C: D622005C 03FD015C 00006400
	v_lshl_add_u32 v90, v90, 24, v96                           // 000000449228: D646005A 0581315A
	v_sad_u8 v39, v39, 0, 0x6400                               // 000000449230: D6220027 03FD0127 00006400
	v_bfe_u32 v94, v38, 6, 16                                  // 00000044923C: D610005E 02410D26
	v_bfe_u32 v95, v38, 3, 16                                  // 000000449244: D610005F 02410726
	v_and_b32_e32 v92, 0xffff, v92                             // 00000044924C: 36B8B8FF 0000FFFF
	v_sad_u8 v90, v90, 0, 0x6400                               // 000000449254: D622005A 03FD015A 00006400
	v_sad_u8 v91, v91, 0, 0x6400                               // 000000449260: D622005B 03FD015B 00006400
	v_mul_u32_u24_e32 v96, s0, v94                             // 00000044926C: 16C0BC00
	v_mul_u32_u24_e32 v94, s8, v94                             // 000000449270: 16BCBC08
	v_lshl_add_u32 v94, v94, 24, v96                           // 000000449274: D646005E 0581315E
	v_lshl_or_b32 v90, v90, 16, v92                            // 00000044927C: D656005A 0571215A
	v_mul_u32_u24_e32 v96, s0, v95                             // 000000449284: 16C0BE00
	v_mul_u32_u24_e32 v95, s8, v95                             // 000000449288: 16BEBE08
	v_lshl_add_u32 v95, v95, 24, v96                           // 00000044928C: D646005F 0581315F
	v_bfe_u32 v36, v34, 9, 16                                  // 000000449294: D6100024 02411322
	v_pk_fma_f16 v90, v90, s9, 0xc931 op_sel_hi:[1,0,0]        // 00000044929C: CC0E005A 0BFC135A 0000C931
	v_and_b32_e32 v39, 0xffff, v39                             // 0000004492A8: 364E4EFF 0000FFFF
	v_bfe_u32 v37, v34, 6, 16                                  // 0000004492B0: D6100025 02410D22
	v_sad_u8 v95, v95, 0, 0x6400                               // 0000004492B8: D622005F 03FD015F 00006400
	v_sad_u8 v93, v93, 0, 0x6400                               // 0000004492C4: D622005D 03FD015D 00006400
	v_sad_u8 v94, v94, 0, 0x6400                               // 0000004492D0: D622005E 03FD015E 00006400
	v_lshl_or_b32 v39, v91, 16, v39                            // 0000004492DC: D6560027 049D215B
	.long 0xd73d001a                                           // 0000004492E4: D73D001A
	v_cndmask_b32_e32 v1, v53, v26, vcc_lo                     // 0000004492E8: 02023535
	v_and_b32_e32 v92, 0xffff, v95                             // 0000004492EC: 36B8BEFF 0000FFFF
	v_mul_u32_u24_e32 v95, s0, v36                             // 0000004492F4: 16BE4800
	v_mul_u32_u24_e32 v36, s8, v36                             // 0000004492F8: 16484808
	v_pk_fma_f16 v39, v39, s9, 0xc931 op_sel_hi:[1,0,0]        // 0000004492FC: CC0E0027 0BFC1327 0000C931
	v_lshl_add_u32 v36, v36, 24, v95                           // 000000449308: D6460024 057D3124
	s_waitcnt vmcnt(4)                                         // 000000449310: BF8913F7
	.long 0xd73d001b                                           // 000000449314: D73D001B
	v_cndmask_b32_e32 v1, v55, v28, vcc_lo                     // 000000449318: 02023937
	v_bfe_u32 v28, v26, 9, 16                                  // 00000044931C: D610001C 0241131A
	v_bfe_u32 v29, v26, 6, 16                                  // 000000449324: D610001D 02410D1A
	s_waitcnt lgkmcnt(0)                                       // 00000044932C: BF89FC07
	v_dot2acc_f32_f16 v50, v39, v1                             // 000000449330: 04640327
	v_bfe_u32 v39, v34, 3, 16                                  // 000000449334: D6100027 02410722
	v_mul_u32_u24_e32 v95, s0, v39                             // 00000044933C: 16BE4E00
	v_mul_u32_u24_e32 v39, s8, v39                             // 000000449340: 164E4E08
	s_delay_alu instid0(VALU_DEP_1)                            // 000000449344: BF870001
	v_lshl_add_u32 v39, v39, 24, v95                           // 000000449348: D6460027 057D3127
	v_mul_u32_u24_e32 v95, s0, v37                             // 000000449350: 16BE4A00
	v_mul_u32_u24_e32 v37, s8, v37                             // 000000449354: 164A4A08
	v_sad_u8 v36, v36, 0, 0x6400                               // 000000449358: D6220024 03FD0124 00006400
	v_lshl_add_u32 v37, v37, 24, v95                           // 000000449364: D6460025 057D3125
	v_and_b32_e32 v34, 0xffff, v34                             // 00000044936C: 364444FF 0000FFFF
	v_mul_u32_u24_e32 v95, s0, v34                             // 000000449374: 16BE4400
	v_mul_u32_u24_e32 v34, s8, v34                             // 000000449378: 16444408
	v_sad_u8 v39, v39, 0, 0x6400                               // 00000044937C: D6220027 03FD0127 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000449388: BF870232
	v_lshl_add_u32 v34, v34, 24, v95                           // 00000044938C: D6460022 057D3122
	v_and_b32_e32 v36, 0xffff, v36                             // 000000449394: 364848FF 0000FFFF
	v_sad_u8 v37, v37, 0, 0x6400                               // 00000044939C: D6220025 03FD0125 00006400
	v_dual_dot2acc_f32_f16 v50, v90, v2 :: v_dual_and_b32 v39, 0xffff, v39// 0000004493A8: CB24055A 32264EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000004493B4: BF870224
	v_sad_u8 v34, v34, 0, 0x6400                               // 0000004493B8: D6220022 03FD0122 00006400
	v_and_b32_e32 v93, 0xffff, v93                             // 0000004493C4: 36BABAFF 0000FFFF
	v_lshl_or_b32 v36, v37, 16, v36                            // 0000004493CC: D6560024 04912125
	.long 0xd73d0016                                           // 0000004493D4: D73D0016
	v_cndmask_b32_e32 v1, v53, v22, vcc_lo                     // 0000004493D8: 02022D35
	.long 0xd73d0012                                           // 0000004493DC: D73D0012
	v_cndmask_b32_e32 v1, v53, v18, vcc_lo                     // 0000004493E0: 02022535
	v_lshl_or_b32 v34, v34, 16, v39                            // 0000004493E4: D6560022 049D2122
	v_lshl_or_b32 v91, v94, 16, v93                            // 0000004493EC: D656005B 0575215E
	v_pk_fma_f16 v36, v36, s9, 0xc931 op_sel_hi:[1,0,0]        // 0000004493F4: CC0E0024 0BFC1324 0000C931
	v_bfe_u32 v93, v35, 6, 16                                  // 000000449400: D610005D 02410D23
	v_bfe_u32 v94, v35, 3, 16                                  // 000000449408: D610005E 02410723
	v_pk_fma_f16 v34, v34, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000449410: CC0E0022 0BFC1322 0000C931
	v_pk_fma_f16 v91, v91, s9, 0xc931 op_sel_hi:[1,0,0]        // 00000044941C: CC0E005B 0BFC135B 0000C931
	v_dot2acc_f32_f16 v49, v36, v1                             // 000000449428: 04620324
	v_bfe_u32 v36, v30, 9, 16                                  // 00000044942C: D6100024 0241131E
	s_waitcnt vmcnt(2)                                         // 000000449434: BF890BF7
	.long 0xd73d0013                                           // 000000449438: D73D0013
	v_cndmask_b32_e32 v1, v55, v20, vcc_lo                     // 00000044943C: 02022937
	v_bfe_u32 v20, v18, 9, 16                                  // 000000449440: D6100014 02411312
	v_dual_dot2acc_f32_f16 v50, v91, v3 :: v_dual_dot2acc_f32_f16 v49, v34, v2// 000000449448: CB18075B 32300522
	v_and_b32_e32 v38, 0xffff, v38                             // 000000449450: 364C4CFF 0000FFFF
	v_mul_u32_u24_e32 v96, s0, v38                             // 000000449458: 16C04C00
	v_mul_u32_u24_e32 v38, s8, v38                             // 00000044945C: 164C4C08
	s_delay_alu instid0(VALU_DEP_1)                            // 000000449460: BF870001
	v_lshl_add_u32 v38, v38, 24, v96                           // 000000449464: D6460026 05813126
	v_bfe_u32 v21, v18, 6, 16                                  // 00000044946C: D6100015 02410D12
	.long 0xd73d000e                                           // 000000449474: D73D000E
	v_cndmask_b32_e32 v1, v53, v14, vcc_lo                     // 000000449478: 02021D35
	.long 0xd73d0006                                           // 00000044947C: D73D0006
	v_cndmask_b32_e32 v1, v53, v6, vcc_lo                      // 000000449480: 02020D35
	s_waitcnt vmcnt(0)                                         // 000000449484: BF8903F7
	.long 0xd73d0007                                           // 000000449488: D73D0007
	v_cndmask_b32_e32 v1, v55, v8, vcc_lo                      // 00000044948C: 02021137
	v_sad_u8 v38, v38, 0, 0x6400                               // 000000449490: D6220026 03FD0126 00006400
	v_add_nc_u32_e32 v51, 1, v51                               // 00000044949C: 4A666681
	v_add_nc_u32_e32 v54, 32, v54                              // 0000004494A0: 4A6C6CA0
	v_bfe_u32 v8, v6, 9, 16                                    // 0000004494A4: D6100008 02411306
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000004494AC: BF8700C4
	v_lshl_or_b32 v38, v38, 16, v92                            // 0000004494B0: D6560026 05712126
	v_bfe_u32 v92, v35, 9, 16                                  // 0000004494B8: D610005C 02411323
	v_mul_u32_u24_e32 v95, s0, v92                             // 0000004494C0: 16BEB800
	v_mul_u32_u24_e32 v92, s8, v92                             // 0000004494C4: 16B8B808
	v_lshl_add_u32 v92, v92, 24, v95                           // 0000004494C8: D646005C 057D315C
	v_mul_u32_u24_e32 v95, s0, v93                             // 0000004494D0: 16BEBA00
	v_mul_u32_u24_e32 v93, s8, v93                             // 0000004494D4: 16BABA08
	v_lshl_add_u32 v93, v93, 24, v95                           // 0000004494D8: D646005D 057D315D
	v_pk_fma_f16 v34, v38, s9, 0xc931 op_sel_hi:[1,0,0]        // 0000004494E0: CC0E0022 0BFC1326 0000C931
	v_sad_u8 v92, v92, 0, 0x6400                               // 0000004494EC: D622005C 03FD015C 00006400
	v_mul_u32_u24_e32 v95, s0, v94                             // 0000004494F8: 16BEBC00
	v_mul_u32_u24_e32 v94, s8, v94                             // 0000004494FC: 16BCBC08
	v_sad_u8 v39, v93, 0, 0x6400                               // 000000449500: D6220027 03FD015D 00006400
	v_lshl_add_u32 v94, v94, 24, v95                           // 00000044950C: D646005E 057D315E
	v_and_b32_e32 v37, 0xffff, v92                             // 000000449514: 364AB8FF 0000FFFF
	v_and_b32_e32 v35, 0xffff, v35                             // 00000044951C: 364646FF 0000FFFF
	v_mul_u32_u24_e32 v93, s0, v35                             // 000000449524: 16BA4600
	v_mul_u32_u24_e32 v35, s8, v35                             // 000000449528: 16464608
	v_sad_u8 v92, v94, 0, 0x6400                               // 00000044952C: D622005C 03FD015E 00006400
	v_lshl_or_b32 v37, v39, 16, v37                            // 000000449538: D6560025 04952127
	v_dot2acc_f32_f16 v50, v34, v4                             // 000000449540: 04640922
	v_lshl_add_u32 v35, v35, 24, v93                           // 000000449544: D6460023 05753123
	v_bfe_u32 v9, v6, 6, 16                                    // 00000044954C: D6100009 02410D06
	v_mov_b32_e32 v34, v78                                     // 000000449554: 7E44034E
	v_pk_fma_f16 v31, v37, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000449558: CC0E001F 0BFC1325 0000C931
	v_bfe_u32 v37, v30, 6, 16                                  // 000000449564: D6100025 02410D1E
	v_mul_u32_u24_e32 v90, s0, v37                             // 00000044956C: 16B44A00
	v_mul_u32_u24_e32 v37, s8, v37                             // 000000449570: 164A4A08
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000449574: BF8700D1
	v_lshl_add_u32 v37, v37, 24, v90                           // 000000449578: D6460025 05693125
	v_dot2acc_f32_f16 v49, v31, v3                             // 000000449580: 0462071F
	.long 0xd73d001f                                           // 000000449584: D73D001F
	v_cndmask_b32_e32 v1, v55, v32, vcc_lo                     // 000000449588: 02024137
	v_mul_u32_u24_e32 v32, s0, v36                             // 00000044958C: 16404800
	v_mul_u32_u24_e32 v33, s8, v36                             // 000000449590: 16424808
	v_lshl_add_u32 v32, v33, 24, v32                           // 000000449594: D6460020 04813121
	v_bfe_u32 v33, v30, 3, 16                                  // 00000044959C: D6100021 0241071E
	v_mul_u32_u24_e32 v90, s0, v33                             // 0000004495A4: 16B44200
	v_mul_u32_u24_e32 v33, s8, v33                             // 0000004495A8: 16424208
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004495AC: BF870001
	v_lshl_add_u32 v33, v33, 24, v90                           // 0000004495B0: D6460021 05693121
	v_sad_u8 v32, v32, 0, 0x6400                               // 0000004495B8: D6220020 03FD0120 00006400
	v_bfe_u32 v36, v31, 9, 16                                  // 0000004495C4: D6100024 0241131F
	v_and_b32_e32 v30, 0xffff, v30                             // 0000004495CC: 363C3CFF 0000FFFF
	v_mul_u32_u24_e32 v90, s0, v36                             // 0000004495D4: 16B44800
	v_mul_u32_u24_e32 v36, s8, v36                             // 0000004495D8: 16484808
	s_delay_alu instid0(VALU_DEP_2)                            // 0000004495DC: BF870002
	v_lshl_add_u32 v36, v36, 24, v90                           // 0000004495E0: D6460024 05693124
	v_mul_u32_u24_e32 v90, s0, v30                             // 0000004495E8: 16B43C00
	v_mul_u32_u24_e32 v30, s8, v30                             // 0000004495EC: 163C3C08
	v_and_b32_e32 v32, 0xffff, v32                             // 0000004495F0: 364040FF 0000FFFF
	v_sad_u8 v37, v37, 0, 0x6400                               // 0000004495F8: D6220025 03FD0125 00006400
	v_sad_u8 v33, v33, 0, 0x6400                               // 000000449604: D6220021 03FD0121 00006400
	v_lshl_add_u32 v30, v30, 24, v90                           // 000000449610: D646001E 0569311E
	v_bfe_u32 v38, v31, 6, 16                                  // 000000449618: D6100026 02410D1F
	v_mul_u32_u24_e32 v90, s0, v38                             // 000000449620: 16B44C00
	v_mul_u32_u24_e32 v38, s8, v38                             // 000000449624: 164C4C08
	v_sad_u8 v36, v36, 0, 0x6400                               // 000000449628: D6220024 03FD0124 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 000000449634: BF870002
	v_lshl_add_u32 v38, v38, 24, v90                           // 000000449638: D6460026 05693126
	v_lshl_or_b32 v32, v37, 16, v32                            // 000000449640: D6560020 04812125
	v_and_b32_e32 v33, 0xffff, v33                             // 000000449648: 364242FF 0000FFFF
	v_sad_u8 v30, v30, 0, 0x6400                               // 000000449650: D622001E 03FD011E 00006400
	v_and_b32_e32 v36, 0xffff, v36                             // 00000044965C: 364848FF 0000FFFF
	v_sad_u8 v37, v38, 0, 0x6400                               // 000000449664: D6220025 03FD0126 00006400
	v_pk_fma_f16 v32, v32, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000449670: CC0E0020 0BFC1320 0000C931
	v_mul_u32_u24_e32 v90, s0, v28                             // 00000044967C: 16B43800
	v_lshl_or_b32 v30, v30, 16, v33                            // 000000449680: D656001E 0485211E
	v_mul_u32_u24_e32 v28, s8, v28                             // 000000449688: 16383808
	v_lshl_or_b32 v33, v37, 16, v36                            // 00000044968C: D6560021 04912125
	v_dot2acc_f32_f16 v48, v32, v1                             // 000000449694: 04600320
	v_lshl_add_u32 v28, v28, 24, v90                           // 000000449698: D646001C 0569311C
	v_pk_fma_f16 v30, v30, s9, 0xc931 op_sel_hi:[1,0,0]        // 0000004496A0: CC0E001E 0BFC131E 0000C931
	v_sad_u8 v35, v35, 0, 0x6400                               // 0000004496AC: D6220023 03FD0123 00006400
	v_pk_fma_f16 v33, v33, s9, 0xc931 op_sel_hi:[1,0,0]        // 0000004496B8: CC0E0021 0BFC1321 0000C931
	v_bfe_u32 v32, v26, 3, 16                                  // 0000004496C4: D6100020 0241071A
	v_mul_u32_u24_e32 v90, s0, v32                             // 0000004496CC: 16B44000
	v_dual_dot2acc_f32_f16 v48, v30, v2 :: v_dual_and_b32 v39, 0xffff, v92// 0000004496D0: CB24051E 3026B8FF 0000FFFF
	v_mul_u32_u24_e32 v32, s8, v32                             // 0000004496DC: 16404008
	s_delay_alu instid0(VALU_DEP_2)                            // 0000004496E0: BF870002
	v_lshl_add_u32 v32, v32, 24, v90                           // 0000004496E4: D6460020 05693120
	v_mul_u32_u24_e32 v90, s0, v29                             // 0000004496EC: 16B43A00
	v_mul_u32_u24_e32 v29, s8, v29                             // 0000004496F0: 163A3A08
	v_sad_u8 v28, v28, 0, 0x6400                               // 0000004496F4: D622001C 03FD011C 00006400
	v_lshl_add_u32 v29, v29, 24, v90                           // 000000449700: D646001D 0569311D
	v_dot2acc_f32_f16 v48, v33, v3                             // 000000449708: 04600721
	v_lshl_or_b32 v35, v35, 16, v39                            // 00000044970C: D6560023 049D2123
	v_bfe_u32 v39, v31, 3, 16                                  // 000000449714: D6100027 0241071F
	v_mul_u32_u24_e32 v38, s0, v39                             // 00000044971C: 164C4E00
	v_and_b32_e32 v31, 0xffff, v31                             // 000000449720: 363E3EFF 0000FFFF
	v_mul_u32_u24_e32 v39, s8, v39                             // 000000449728: 164E4E08
	s_delay_alu instid0(VALU_DEP_2)                            // 00000044972C: BF870002
	v_lshl_add_u32 v38, v39, 24, v38                           // 000000449730: D6460026 04993127
	v_mul_u32_u24_e32 v37, s0, v31                             // 000000449738: 164A3E00
	v_mul_u32_u24_e32 v31, s8, v31                             // 00000044973C: 163E3E08
	v_and_b32_e32 v26, 0xffff, v26                             // 000000449740: 363434FF 0000FFFF
	v_lshl_add_u32 v31, v31, 24, v37                           // 000000449748: D646001F 0495311F
	v_bfe_u32 v37, v27, 9, 16                                  // 000000449750: D6100025 0241131B
	v_mul_u32_u24_e32 v90, s0, v26                             // 000000449758: 16B43400
	v_mul_u32_u24_e32 v26, s8, v26                             // 00000044975C: 16343408
	v_sad_u8 v32, v32, 0, 0x6400                               // 000000449760: D6220020 03FD0120 00006400
	v_lshl_add_u32 v26, v26, 24, v90                           // 00000044976C: D646001A 0569311A
	v_mul_u32_u24_e32 v90, s0, v37                             // 000000449774: 16B44A00
	v_mul_u32_u24_e32 v37, s8, v37                             // 000000449778: 164A4A08
	v_lshl_add_u32 v37, v37, 24, v90                           // 00000044977C: D6460025 05693125
	v_and_b32_e32 v28, 0xffff, v28                             // 000000449784: 363838FF 0000FFFF
	v_sad_u8 v29, v29, 0, 0x6400                               // 00000044978C: D622001D 03FD011D 00006400
	v_sad_u8 v36, v38, 0, 0x6400                               // 000000449798: D6220024 03FD0126 00006400
	v_bfe_u32 v38, v27, 6, 16                                  // 0000004497A4: D6100026 02410D1B
	v_bfe_u32 v39, v27, 3, 16                                  // 0000004497AC: D6100027 0241071B
	v_mul_u32_u24_e32 v90, s0, v38                             // 0000004497B4: 16B44C00
	v_mul_u32_u24_e32 v38, s8, v38                             // 0000004497B8: 164C4C08
	v_and_b32_e32 v32, 0xffff, v32                             // 0000004497BC: 364040FF 0000FFFF
	v_sad_u8 v26, v26, 0, 0x6400                               // 0000004497C4: D622001A 03FD011A 00006400
	v_lshl_add_u32 v38, v38, 24, v90                           // 0000004497D0: D6460026 05693126
	v_mul_u32_u24_e32 v90, s0, v39                             // 0000004497D8: 16B44E00
	v_mul_u32_u24_e32 v39, s8, v39                             // 0000004497DC: 164E4E08
	v_sad_u8 v37, v37, 0, 0x6400                               // 0000004497E0: D6220025 03FD0125 00006400
	v_lshl_add_u32 v39, v39, 24, v90                           // 0000004497EC: D6460027 05693127
	v_lshl_or_b32 v28, v29, 16, v28                            // 0000004497F4: D656001C 0471211D
	v_and_b32_e32 v27, 0xffff, v27                             // 0000004497FC: 363636FF 0000FFFF
	v_lshl_or_b32 v26, v26, 16, v32                            // 000000449804: D656001A 0481211A
	v_sad_u8 v32, v38, 0, 0x6400                               // 00000044980C: D6220020 03FD0126 00006400
	v_mul_u32_u24_e32 v38, s0, v27                             // 000000449818: 164C3600
	v_mul_u32_u24_e32 v27, s8, v27                             // 00000044981C: 16363608
	v_and_b32_e32 v29, 0xffff, v37                             // 000000449820: 363A4AFF 0000FFFF
	v_sad_u8 v37, v39, 0, 0x6400                               // 000000449828: D6220025 03FD0127 00006400
	v_lshl_add_u32 v27, v27, 24, v38                           // 000000449834: D646001B 0499311B
	v_pk_fma_f16 v28, v28, s9, 0xc931 op_sel_hi:[1,0,0]        // 00000044983C: CC0E001C 0BFC131C 0000C931
	v_pk_fma_f16 v26, v26, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000449848: CC0E001A 0BFC131A 0000C931
	v_lshl_or_b32 v29, v32, 16, v29                            // 000000449854: D656001D 04752120
	v_and_b32_e32 v32, 0xffff, v37                             // 00000044985C: 36404AFF 0000FFFF
	v_sad_u8 v27, v27, 0, 0x6400                               // 000000449864: D622001B 03FD011B 00006400
	v_dual_dot2acc_f32_f16 v47, v28, v1 :: v_dual_and_b32 v36, 0xffff, v36// 000000449870: CB24031C 2F2448FF 0000FFFF
	v_sad_u8 v31, v31, 0, 0x6400                               // 00000044987C: D622001F 03FD011F 00006400
	v_pk_fma_f16 v29, v29, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000449888: CC0E001D 0BFC131D 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000449894: BF870214
	v_lshl_or_b32 v27, v27, 16, v32                            // 000000449898: D656001B 0481211B
	v_dot2acc_f32_f16 v47, v26, v2                             // 0000004498A0: 045E051A
	v_pk_fma_f16 v35, v35, s9, 0xc931 op_sel_hi:[1,0,0]        // 0000004498A4: CC0E0023 0BFC1323 0000C931
	v_lshl_or_b32 v28, v31, 16, v36                            // 0000004498B0: D656001C 0491211F
	v_mov_b32_e32 v32, v87                                     // 0000004498B8: 7E400357
	v_pk_fma_f16 v23, v27, s9, 0xc931 op_sel_hi:[1,0,0]        // 0000004498BC: CC0E0017 0BFC131B 0000C931
	v_dot2acc_f32_f16 v47, v29, v3                             // 0000004498C8: 045E071D
	v_bfe_u32 v27, v22, 6, 16                                  // 0000004498CC: D610001B 02410D16
	v_pk_fma_f16 v26, v28, s9, 0xc931 op_sel_hi:[1,0,0]        // 0000004498D4: CC0E001A 0BFC131C 0000C931
	v_mul_u32_u24_e32 v30, s0, v27                             // 0000004498E0: 163C3600
	v_mul_u32_u24_e32 v27, s8, v27                             // 0000004498E4: 16363608
	v_dot2acc_f32_f16 v47, v23, v4                             // 0000004498E8: 045E0917
	.long 0xd73d0017                                           // 0000004498EC: D73D0017
	v_cndmask_b32_e32 v1, v55, v24, vcc_lo                     // 0000004498F0: 02023137
	v_dot2acc_f32_f16 v48, v26, v4                             // 0000004498F4: 0460091A
	v_bfe_u32 v26, v22, 9, 16                                  // 0000004498F8: D610001A 02411316
	v_bfe_u32 v24, v22, 3, 16                                  // 000000449900: D6100018 02410716
	v_mul_u32_u24_e32 v25, s0, v26                             // 000000449908: 16323400
	v_mul_u32_u24_e32 v26, s8, v26                             // 00000044990C: 16343408
	s_delay_alu instid0(VALU_DEP_2)                            // 000000449910: BF870002
	v_lshl_add_u32 v25, v26, 24, v25                           // 000000449914: D6460019 0465311A
	v_bfe_u32 v26, v23, 9, 16                                  // 00000044991C: D610001A 02411317
	v_lshl_add_u32 v27, v27, 24, v30                           // 000000449924: D646001B 0479311B
	v_mul_u32_u24_e32 v30, s0, v24                             // 00000044992C: 163C3000
	v_mul_u32_u24_e32 v24, s8, v24                             // 000000449930: 16303008
	v_lshl_add_u32 v24, v24, 24, v30                           // 000000449934: D6460018 04793118
	v_mul_u32_u24_e32 v30, s0, v26                             // 00000044993C: 163C3400
	v_mul_u32_u24_e32 v26, s8, v26                             // 000000449940: 16343408
	v_lshl_add_u32 v26, v26, 24, v30                           // 000000449944: D646001A 0479311A
	v_and_b32_e32 v22, 0xffff, v22                             // 00000044994C: 362C2CFF 0000FFFF
	v_bfe_u32 v28, v23, 6, 16                                  // 000000449954: D610001C 02410D17
	v_mul_u32_u24_e32 v30, s0, v22                             // 00000044995C: 163C2C00
	v_mul_u32_u24_e32 v22, s8, v22                             // 000000449960: 162C2C08
	s_delay_alu instid0(VALU_DEP_2)                            // 000000449964: BF870002
	v_lshl_add_u32 v22, v22, 24, v30                           // 000000449968: D6460016 04793116
	v_mul_u32_u24_e32 v30, s0, v28                             // 000000449970: 163C3800
	v_mul_u32_u24_e32 v28, s8, v28                             // 000000449974: 16383808
	v_sad_u8 v24, v24, 0, 0x6400                               // 000000449978: D6220018 03FD0118 00006400
	v_sad_u8 v26, v26, 0, 0x6400                               // 000000449984: D622001A 03FD011A 00006400
	v_lshl_add_u32 v28, v28, 24, v30                           // 000000449990: D646001C 0479311C
	v_sad_u8 v22, v22, 0, 0x6400                               // 000000449998: D6220016 03FD0116 00006400
	v_sad_u8 v25, v25, 0, 0x6400                               // 0000004499A4: D6220019 03FD0119 00006400
	v_and_b32_e32 v24, 0xffff, v24                             // 0000004499B0: 363030FF 0000FFFF
	v_and_b32_e32 v26, 0xffff, v26                             // 0000004499B8: 363434FF 0000FFFF
	v_sad_u8 v28, v28, 0, 0x6400                               // 0000004499C0: D622001C 03FD011C 00006400
	v_bfe_u32 v29, v23, 3, 16                                  // 0000004499CC: D610001D 02410717
	v_sad_u8 v27, v27, 0, 0x6400                               // 0000004499D4: D622001B 03FD011B 00006400
	v_lshl_or_b32 v22, v22, 16, v24                            // 0000004499E0: D6560016 04612116
	v_mul_u32_u24_e32 v30, s0, v29                             // 0000004499E8: 163C3A00
	v_lshl_or_b32 v24, v28, 16, v26                            // 0000004499EC: D6560018 0469211C
	v_mul_u32_u24_e32 v29, s8, v29                             // 0000004499F4: 163A3A08
	v_lshl_add_u32 v29, v29, 24, v30                           // 0000004499F8: D646001D 0479311D
	v_and_b32_e32 v23, 0xffff, v23                             // 000000449A00: 362E2EFF 0000FFFF
	v_mul_u32_u24_e32 v30, s0, v23                             // 000000449A08: 163C2E00
	v_pk_fma_f16 v24, v24, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000449A0C: CC0E0018 0BFC1318 0000C931
	v_and_b32_e32 v25, 0xffff, v25                             // 000000449A18: 363232FF 0000FFFF
	v_sad_u8 v29, v29, 0, 0x6400                               // 000000449A20: D622001D 03FD011D 00006400
	v_mul_u32_u24_e32 v23, s8, v23                             // 000000449A2C: 162E2E08
	v_lshl_add_u32 v23, v23, 24, v30                           // 000000449A30: D6460017 04793117
	v_pk_fma_f16 v22, v22, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000449A38: CC0E0016 0BFC1316 0000C931
	v_lshl_or_b32 v25, v27, 16, v25                            // 000000449A44: D6560019 0465211B
	v_and_b32_e32 v26, 0xffff, v29                             // 000000449A4C: 36343AFF 0000FFFF
	v_mul_u32_u24_e32 v29, s0, v20                             // 000000449A54: 163A2800
	v_mul_u32_u24_e32 v20, s8, v20                             // 000000449A58: 16282808
	v_lshl_add_u32 v20, v20, 24, v29                           // 000000449A5C: D6460014 04753114
	v_pk_fma_f16 v25, v25, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000449A64: CC0E0019 0BFC1319 0000C931
	v_sad_u8 v23, v23, 0, 0x6400                               // 000000449A70: D6220017 03FD0117 00006400
	v_bfe_u32 v27, v19, 6, 16                                  // 000000449A7C: D610001B 02410D13
	v_bfe_u32 v28, v19, 3, 16                                  // 000000449A84: D610001C 02410713
	v_sad_u8 v20, v20, 0, 0x6400                               // 000000449A8C: D6220014 03FD0114 00006400
	v_dot2acc_f32_f16 v46, v25, v1                             // 000000449A98: 045C0319
	v_bfe_u32 v25, v18, 3, 16                                  // 000000449A9C: D6100019 02410712
	v_mul_u32_u24_e32 v29, s0, v25                             // 000000449AA4: 163A3200
	v_mul_u32_u24_e32 v25, s8, v25                             // 000000449AA8: 16323208
	s_delay_alu instid0(VALU_DEP_1)                            // 000000449AAC: BF870001
	v_lshl_add_u32 v25, v25, 24, v29                           // 000000449AB0: D6460019 04753119
	v_mul_u32_u24_e32 v29, s0, v21                             // 000000449AB8: 163A2A00
	v_mul_u32_u24_e32 v21, s8, v21                             // 000000449ABC: 162A2A08
	v_lshl_add_u32 v21, v21, 24, v29                           // 000000449AC0: D6460015 04753115
	v_and_b32_e32 v18, 0xffff, v18                             // 000000449AC8: 362424FF 0000FFFF
	v_mul_u32_u24_e32 v29, s0, v18                             // 000000449AD0: 163A2400
	v_mul_u32_u24_e32 v18, s8, v18                             // 000000449AD4: 16242408
	v_sad_u8 v25, v25, 0, 0x6400                               // 000000449AD8: D6220019 03FD0119 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 000000449AE4: BF870002
	v_lshl_add_u32 v18, v18, 24, v29                           // 000000449AE8: D6460012 04753112
	v_and_b32_e32 v20, 0xffff, v20                             // 000000449AF0: 362828FF 0000FFFF
	v_sad_u8 v21, v21, 0, 0x6400                               // 000000449AF8: D6220015 03FD0115 00006400
	v_lshl_or_b32 v23, v23, 16, v26                            // 000000449B04: D6560017 04692117
	v_and_b32_e32 v25, 0xffff, v25                             // 000000449B0C: 363232FF 0000FFFF
	v_sad_u8 v18, v18, 0, 0x6400                               // 000000449B14: D6220012 03FD0112 00006400
	v_bfe_u32 v26, v19, 9, 16                                  // 000000449B20: D610001A 02411313
	v_lshl_or_b32 v20, v21, 16, v20                            // 000000449B28: D6560014 04512115
	v_mul_u32_u24_e32 v29, s0, v26                             // 000000449B30: 163A3400
	v_mul_u32_u24_e32 v26, s8, v26                             // 000000449B34: 16343408
	s_delay_alu instid0(VALU_DEP_2)                            // 000000449B38: BF870002
	v_lshl_add_u32 v26, v26, 24, v29                           // 000000449B3C: D646001A 0475311A
	v_lshl_or_b32 v18, v18, 16, v25                            // 000000449B44: D6560012 04652112
	v_pk_fma_f16 v20, v20, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000449B4C: CC0E0014 0BFC1314 0000C931
	v_mul_u32_u24_e32 v29, s0, v27                             // 000000449B58: 163A3600
	v_mul_u32_u24_e32 v27, s8, v27                             // 000000449B5C: 16363608
	v_sad_u8 v26, v26, 0, 0x6400                               // 000000449B60: D622001A 03FD011A 00006400
	v_lshl_add_u32 v27, v27, 24, v29                           // 000000449B6C: D646001B 0475311B
	v_pk_fma_f16 v18, v18, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000449B74: CC0E0012 0BFC1312 0000C931
	v_dual_dot2acc_f32_f16 v45, v20, v1 :: v_dual_dot2acc_f32_f16 v46, v22, v2// 000000449B80: CB180314 2D2E0516
	v_bfe_u32 v20, v14, 9, 16                                  // 000000449B88: D6100014 0241130E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000449B90: BF8701A4
	v_sad_u8 v25, v27, 0, 0x6400                               // 000000449B94: D6220019 03FD011B 00006400
	v_mul_u32_u24_e32 v29, s0, v28                             // 000000449BA0: 163A3800
	v_dot2acc_f32_f16 v45, v18, v2                             // 000000449BA4: 045A0512
	v_pk_fma_f16 v18, v23, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000449BA8: CC0E0012 0BFC1317 0000C931
	v_dual_dot2acc_f32_f16 v46, v24, v3 :: v_dual_and_b32 v21, 0xffff, v26// 000000449BB4: CB240718 2E1434FF 0000FFFF
	v_mul_u32_u24_e32 v28, s8, v28                             // 000000449BC0: 16383808
	v_lshl_add_u32 v28, v28, 24, v29                           // 000000449BC4: D646001C 0475311C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000449BCC: BF870192
	v_dual_mov_b32 v29, v79 :: v_dual_dot2acc_f32_f16 v46, v18, v4// 000000449BD0: CA18014F 1D2E0912
	v_lshl_or_b32 v21, v25, 16, v21                            // 000000449BD8: D6560015 04552119
	v_mov_b32_e32 v33, v82                                     // 000000449BE0: 7E420352
	s_delay_alu instid0(VALU_DEP_4)                            // 000000449BE4: BF870004
	v_sad_u8 v26, v28, 0, 0x6400                               // 000000449BE8: D622001A 03FD011C 00006400
	v_mov_b32_e32 v31, v63                                     // 000000449BF4: 7E3E033F
	v_dot2acc_f32_f16 v49, v35, v4                             // 000000449BF8: 04620923
	v_pk_fma_f16 v15, v21, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000449BFC: CC0E000F 0BFC1315 0000C931
	v_bfe_u32 v21, v14, 6, 16                                  // 000000449C08: D6100015 02410D0E
	v_mul_u32_u24_e32 v24, s0, v21                             // 000000449C10: 16302A00
	v_mul_u32_u24_e32 v21, s8, v21                             // 000000449C14: 162A2A08
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000449C18: BF8700D1
	v_lshl_add_u32 v21, v21, 24, v24                           // 000000449C1C: D6460015 04613115
	v_dot2acc_f32_f16 v45, v15, v3                             // 000000449C24: 045A070F
	.long 0xd73d000f                                           // 000000449C28: D73D000F
	v_cndmask_b32_e32 v1, v55, v16, vcc_lo                     // 000000449C2C: 02022137
	v_mul_u32_u24_e32 v16, s0, v20                             // 000000449C30: 16202800
	v_mul_u32_u24_e32 v17, s8, v20                             // 000000449C34: 16222808
	v_lshl_add_u32 v16, v17, 24, v16                           // 000000449C38: D6460010 04413111
	v_bfe_u32 v17, v14, 3, 16                                  // 000000449C40: D6100011 0241070E
	v_sad_u8 v21, v21, 0, 0x6400                               // 000000449C48: D6220015 03FD0115 00006400
	v_mul_u32_u24_e32 v24, s0, v17                             // 000000449C54: 16302200
	v_mul_u32_u24_e32 v17, s8, v17                             // 000000449C58: 16222208
	v_sad_u8 v16, v16, 0, 0x6400                               // 000000449C5C: D6220010 03FD0110 00006400
	v_lshl_add_u32 v17, v17, 24, v24                           // 000000449C68: D6460011 04613111
	v_bfe_u32 v20, v15, 9, 16                                  // 000000449C70: D6100014 0241130F
	v_and_b32_e32 v14, 0xffff, v14                             // 000000449C78: 361C1CFF 0000FFFF
	v_mul_u32_u24_e32 v24, s0, v20                             // 000000449C80: 16302800
	v_and_b32_e32 v16, 0xffff, v16                             // 000000449C84: 362020FF 0000FFFF
	v_mul_u32_u24_e32 v20, s8, v20                             // 000000449C8C: 16282808
	v_lshl_add_u32 v20, v20, 24, v24                           // 000000449C90: D6460014 04613114
	v_mul_u32_u24_e32 v24, s0, v14                             // 000000449C98: 16301C00
	v_mul_u32_u24_e32 v14, s8, v14                             // 000000449C9C: 161C1C08
	v_lshl_or_b32 v16, v21, 16, v16                            // 000000449CA0: D6560010 04412115
	v_sad_u8 v17, v17, 0, 0x6400                               // 000000449CA8: D6220011 03FD0111 00006400
	v_lshl_add_u32 v14, v14, 24, v24                           // 000000449CB4: D646000E 0461310E
	v_bfe_u32 v22, v15, 6, 16                                  // 000000449CBC: D6100016 02410D0F
	v_mul_u32_u24_e32 v24, s0, v22                             // 000000449CC4: 16302C00
	v_pk_fma_f16 v16, v16, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000449CC8: CC0E0010 0BFC1310 0000C931
	v_mul_u32_u24_e32 v22, s8, v22                             // 000000449CD4: 162C2C08
	s_delay_alu instid0(VALU_DEP_2)                            // 000000449CD8: BF870002
	v_lshl_add_u32 v22, v22, 24, v24                           // 000000449CDC: D6460016 04613116
	v_and_b32_e32 v17, 0xffff, v17                             // 000000449CE4: 362222FF 0000FFFF
	v_sad_u8 v14, v14, 0, 0x6400                               // 000000449CEC: D622000E 03FD010E 00006400
	v_mul_u32_u24_e32 v24, s0, v8                              // 000000449CF8: 16301000
	v_mul_u32_u24_e32 v8, s8, v8                               // 000000449CFC: 16101008
	v_lshl_add_u32 v8, v8, 24, v24                             // 000000449D00: D6460008 04613108
	v_dot2acc_f32_f16 v44, v16, v1                             // 000000449D08: 04580310
	v_bfe_u32 v16, v6, 3, 16                                   // 000000449D0C: D6100010 02410706
	v_mul_u32_u24_e32 v24, s0, v16                             // 000000449D14: 16302000
	v_mul_u32_u24_e32 v16, s8, v16                             // 000000449D18: 16202008
	v_lshl_or_b32 v14, v14, 16, v17                            // 000000449D1C: D656000E 0445210E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000449D24: BF870002
	v_lshl_add_u32 v16, v16, 24, v24                           // 000000449D28: D6460010 04613110
	v_mul_u32_u24_e32 v24, s0, v9                              // 000000449D30: 16301200
	v_mul_u32_u24_e32 v9, s8, v9                               // 000000449D34: 16121208
	v_sad_u8 v8, v8, 0, 0x6400                                 // 000000449D38: D6220008 03FD0108 00006400
	v_lshl_add_u32 v9, v9, 24, v24                             // 000000449D44: D6460009 04613109
	v_and_b32_e32 v6, 0xffff, v6                               // 000000449D4C: 360C0CFF 0000FFFF
	v_pk_fma_f16 v14, v14, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000449D54: CC0E000E 0BFC130E 0000C931
	v_mul_u32_u24_e32 v24, s0, v6                              // 000000449D60: 16300C00
	v_mul_u32_u24_e32 v6, s8, v6                               // 000000449D64: 160C0C08
	v_sad_u8 v16, v16, 0, 0x6400                               // 000000449D68: D6220010 03FD0110 00006400
	v_lshl_add_u32 v6, v6, 24, v24                             // 000000449D74: D6460006 04613106
	v_and_b32_e32 v8, 0xffff, v8                               // 000000449D7C: 361010FF 0000FFFF
	v_sad_u8 v9, v9, 0, 0x6400                                 // 000000449D84: D6220009 03FD0109 00006400
	v_dual_dot2acc_f32_f16 v44, v14, v2 :: v_dual_and_b32 v19, 0xffff, v19// 000000449D90: CB24050E 2C1226FF 0000FFFF
	v_mul_u32_u24_e32 v27, s0, v19                             // 000000449D9C: 16362600
	v_mul_u32_u24_e32 v19, s8, v19                             // 000000449DA0: 16262608
	s_delay_alu instid0(VALU_DEP_1)                            // 000000449DA4: BF870001
	v_lshl_add_u32 v19, v19, 24, v27                           // 000000449DA8: D6460013 046D3113
	v_and_b32_e32 v16, 0xffff, v16                             // 000000449DB0: 362020FF 0000FFFF
	v_sad_u8 v6, v6, 0, 0x6400                                 // 000000449DB8: D6220006 03FD0106 00006400
	v_mov_b32_e32 v27, v62                                     // 000000449DC4: 7E36033E
	v_lshl_or_b32 v8, v9, 16, v8                               // 000000449DC8: D6560008 04212109
	v_sad_u8 v20, v20, 0, 0x6400                               // 000000449DD0: D6220014 03FD0114 00006400
	v_sad_u8 v21, v22, 0, 0x6400                               // 000000449DDC: D6220015 03FD0116 00006400
	v_lshl_or_b32 v6, v6, 16, v16                              // 000000449DE8: D6560006 04412106
	v_bfe_u32 v23, v15, 3, 16                                  // 000000449DF0: D6100017 0241070F
	v_pk_fma_f16 v8, v8, s9, 0xc931 op_sel_hi:[1,0,0]          // 000000449DF8: CC0E0008 0BFC1308 0000C931
	v_and_b32_e32 v20, 0xffff, v20                             // 000000449E04: 362828FF 0000FFFF
	v_mul_u32_u24_e32 v22, s0, v23                             // 000000449E0C: 162C2E00
	v_pk_fma_f16 v6, v6, s9, 0xc931 op_sel_hi:[1,0,0]          // 000000449E10: CC0E0006 0BFC1306 0000C931
	v_and_b32_e32 v15, 0xffff, v15                             // 000000449E1C: 361E1EFF 0000FFFF
	v_dot2acc_f32_f16 v5, v8, v1                               // 000000449E24: 040A0308
	v_mul_u32_u24_e32 v23, s8, v23                             // 000000449E28: 162E2E08
	v_lshl_add_u32 v22, v23, 24, v22                           // 000000449E2C: D6460016 04593117
	v_lshl_or_b32 v17, v21, 16, v20                            // 000000449E34: D6560011 04512115
	v_bfe_u32 v23, v7, 3, 16                                   // 000000449E3C: D6100017 02410707
	v_dot2acc_f32_f16 v5, v6, v2                               // 000000449E44: 040A0506
	v_mov_b32_e32 v6, v66                                      // 000000449E48: 7E0C0342
	v_mul_u32_u24_e32 v21, s0, v15                             // 000000449E4C: 162A1E00
	v_mul_u32_u24_e32 v15, s8, v15                             // 000000449E50: 161E1E08
	v_lshl_add_u32 v15, v15, 24, v21                           // 000000449E54: D646000F 0455310F
	v_bfe_u32 v21, v7, 9, 16                                   // 000000449E5C: D6100015 02411307
	v_mul_u32_u24_e32 v24, s0, v21                             // 000000449E64: 16302A00
	v_mul_u32_u24_e32 v21, s8, v21                             // 000000449E68: 162A2A08
	s_delay_alu instid0(VALU_DEP_1)                            // 000000449E6C: BF870001
	v_lshl_add_u32 v21, v21, 24, v24                           // 000000449E70: D6460015 04613115
	v_sad_u8 v20, v22, 0, 0x6400                               // 000000449E78: D6220014 03FD0116 00006400
	v_bfe_u32 v22, v7, 6, 16                                   // 000000449E84: D6100016 02410D07
	v_mul_u32_u24_e32 v24, s0, v22                             // 000000449E8C: 16302C00
	v_mul_u32_u24_e32 v22, s8, v22                             // 000000449E90: 162C2C08
	v_sad_u8 v21, v21, 0, 0x6400                               // 000000449E94: D6220015 03FD0115 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 000000449EA0: BF870002
	v_lshl_add_u32 v22, v22, 24, v24                           // 000000449EA4: D6460016 04613116
	v_mul_u32_u24_e32 v24, s0, v23                             // 000000449EAC: 16302E00
	v_mul_u32_u24_e32 v23, s8, v23                             // 000000449EB0: 162E2E08
	v_and_b32_e32 v20, 0xffff, v20                             // 000000449EB4: 362828FF 0000FFFF
	v_sad_u8 v15, v15, 0, 0x6400                               // 000000449EBC: D622000F 03FD010F 00006400
	v_lshl_add_u32 v23, v23, 24, v24                           // 000000449EC8: D6460017 04613117
	v_and_b32_e32 v7, 0xffff, v7                               // 000000449ED0: 360E0EFF 0000FFFF
	v_dual_mov_b32 v14, v67 :: v_dual_and_b32 v9, 0xffff, v21  // 000000449ED8: CA240143 0E082AFF 0000FFFF
	v_sad_u8 v16, v22, 0, 0x6400                               // 000000449EE4: D6220010 03FD0116 00006400
	v_mul_u32_u24_e32 v22, s0, v7                              // 000000449EF0: 162C0E00
	v_mul_u32_u24_e32 v7, s8, v7                               // 000000449EF4: 160E0E08
	v_pk_fma_f16 v17, v17, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000449EF8: CC0E0011 0BFC1311 0000C931
	v_sad_u8 v21, v23, 0, 0x6400                               // 000000449F04: D6220015 03FD0117 00006400
	v_lshl_add_u32 v7, v7, 24, v22                             // 000000449F10: D6460007 04593107
	v_mov_b32_e32 v23, v61                                     // 000000449F18: 7E2E033D
	v_lshl_or_b32 v1, v15, 16, v20                             // 000000449F1C: D6560001 0451210F
	v_lshl_or_b32 v9, v16, 16, v9                              // 000000449F24: D6560009 04252110
	v_sad_u8 v19, v19, 0, 0x6400                               // 000000449F2C: D6220013 03FD0113 00006400
	v_and_b32_e32 v16, 0xffff, v21                             // 000000449F38: 36202AFF 0000FFFF
	v_sad_u8 v7, v7, 0, 0x6400                                 // 000000449F40: D6220007 03FD0107 00006400
	v_pk_fma_f16 v1, v1, s9, 0xc931 op_sel_hi:[1,0,0]          // 000000449F4C: CC0E0001 0BFC1301 0000C931
	v_dual_dot2acc_f32_f16 v44, v17, v3 :: v_dual_and_b32 v25, 0xffff, v26// 000000449F58: CB240711 2C1834FF 0000FFFF
	v_pk_fma_f16 v8, v9, s9, 0xc931 op_sel_hi:[1,0,0]          // 000000449F64: CC0E0008 0BFC1309 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000449F70: BF870224
	v_lshl_or_b32 v7, v7, 16, v16                              // 000000449F74: D6560007 04412107
	v_mov_b32_e32 v20, v80                                     // 000000449F7C: 7E280350
	v_dot2acc_f32_f16 v44, v1, v4                              // 000000449F80: 04580901
	v_lshl_or_b32 v19, v19, 16, v25                            // 000000449F84: D6560013 04652113
	v_dot2acc_f32_f16 v5, v8, v3                               // 000000449F8C: 040A0708
	v_dual_mov_b32 v24, v83 :: v_dual_add_nc_u32 v3, v52, v51  // 000000449F90: CA200153 18026734
	v_pk_fma_f16 v2, v7, s9, 0xc931 op_sel_hi:[1,0,0]          // 000000449F98: CC0E0002 0BFC1307 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000449FA4: BF870224
	v_pk_fma_f16 v19, v19, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000449FA8: CC0E0013 0BFC1313 0000C931
	v_mov_b32_e32 v8, v74                                      // 000000449FB4: 7E10034A
	v_cmp_eq_u32_e32 vcc_lo, 1, v3                             // 000000449FB8: 7C940681
	v_mov_b32_e32 v9, v69                                      // 000000449FBC: 7E120345
	v_dot2acc_f32_f16 v5, v2, v4                               // 000000449FC0: 040A0902
	v_dot2acc_f32_f16 v45, v19, v4                             // 000000449FC4: 045A0913
	v_dual_mov_b32 v7, v58 :: v_dual_mov_b32 v16, v77          // 000000449FC8: CA10013A 0710014D
	v_mov_b32_e32 v17, v71                                     // 000000449FD0: 7E220347
	v_mov_b32_e32 v15, v59                                     // 000000449FD4: 7E1E033B
	v_dual_mov_b32 v21, v73 :: v_dual_mov_b32 v18, v68         // 000000449FD8: CA100149 15120144
	v_mov_b32_e32 v39, v86                                     // 000000449FE0: 7E4E0356
	v_mov_b32_e32 v19, v60                                     // 000000449FE4: 7E26033C
	v_dual_mov_b32 v25, v76 :: v_dual_mov_b32 v22, v70         // 000000449FE8: CA10014C 19160146
	v_dual_mov_b32 v35, v64 :: v_dual_mov_b32 v28, v85         // 000000449FF0: CA100140 231C0155
	v_dual_mov_b32 v26, v72 :: v_dual_mov_b32 v1, v81          // 000000449FF8: CA100148 1A000151
	v_mov_b32_e32 v30, v75                                     // 00000044A000: 7E3C034B
	v_mov_b32_e32 v36, v88                                     // 00000044A004: 7E480358
	v_dual_mov_b32 v37, v84 :: v_dual_mov_b32 v38, v89         // 00000044A008: CA100154 25260159
	v_mov_b32_e32 v2, v65                                      // 00000044A010: 7E040341
	s_or_b32 s5, vcc_lo, s5                                    // 00000044A014: 8C05056A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000044A018: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 00000044A01C: 917E057E
	s_cbranch_execz 92                                         // 00000044A020: BFA5005C <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi1ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1c94>
	s_mov_b32 s10, exec_lo                                     // 00000044A024: BE8A007E
	.long 0xd4c1007e                                           // 00000044A028: D4C1007E
	v_cndmask_b32_e32 v1, v51, v43, vcc_lo                     // 00000044A02C: 02025733
	s_cbranch_execz 64589                                      // 00000044A030: BFA5FC4D <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi1ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xc68>
	v_mad_i64_i32 v[3:4], null, 0x300, v51, s[6:7]             // 00000044A034: D6FF7C03 001A66FF 00000300
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000044A040: BF870091
	.long 0xd7006a42                                           // 00000044A044: D7006A42
	v_cndmask_b32_e32 v1, v3, v10, vcc_lo                      // 00000044A048: 02021503
	v_add_co_ci_u32_e64 v67, null, v4, v11, vcc_lo             // 00000044A04C: D5207C43 01AA1704
	.long 0xd7006a49                                           // 00000044A054: D7006A49
	v_cndmask_b32_e32 v1, v3, v56, vcc_lo                      // 00000044A058: 02027103
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000044A05C: BF8700A1
	v_add_co_ci_u32_e64 v74, null, 0, v4, vcc_lo               // 00000044A060: D5207C4A 01AA0880
	.long 0xd7006a57                                           // 00000044A068: D7006A57
	v_cndmask_b32_e32 v1, v3, v12, vcc_lo                      // 00000044A06C: 02021903
	v_add_co_ci_u32_e64 v88, null, v4, v13, vcc_lo             // 00000044A070: D5207C58 01AA1B04
	.long 0xd7006a03                                           // 00000044A078: D7006A03
	v_cndmask_b32_e32 v1, v3, v57, vcc_lo                      // 00000044A07C: 02027303
	s_delay_alu instid0(VALU_DEP_1)                            // 00000044A080: BF870001
	v_add_co_ci_u32_e64 v4, null, 0, v4, vcc_lo                // 00000044A084: D5207C04 01AA0880
	s_clause 0x1f                                              // 00000044A08C: BF85001F
	global_load_b32 v65, v[66:67], off                         // 00000044A090: DC520000 417C0042
	global_load_b32 v64, v[66:67], off offset:96               // 00000044A098: DC520060 407C0042
	global_load_b32 v63, v[66:67], off offset:192              // 00000044A0A0: DC5200C0 3F7C0042
	global_load_b32 v62, v[66:67], off offset:288              // 00000044A0A8: DC520120 3E7C0042
	global_load_b32 v61, v[66:67], off offset:384              // 00000044A0B0: DC520180 3D7C0042
	global_load_b32 v60, v[66:67], off offset:480              // 00000044A0B8: DC5201E0 3C7C0042
	global_load_b32 v59, v[66:67], off offset:576              // 00000044A0C0: DC520240 3B7C0042
	global_load_b32 v58, v[66:67], off offset:672              // 00000044A0C8: DC5202A0 3A7C0042
	global_load_b32 v81, v[73:74], off                         // 00000044A0D0: DC520000 517C0049
	global_load_b32 v78, v[73:74], off offset:96               // 00000044A0D8: DC520060 4E7C0049
	global_load_b32 v75, v[73:74], off offset:192              // 00000044A0E0: DC5200C0 4B7C0049
	global_load_b32 v72, v[73:74], off offset:288              // 00000044A0E8: DC520120 487C0049
	global_load_b32 v70, v[73:74], off offset:384              // 00000044A0F0: DC520180 467C0049
	global_load_b32 v68, v[73:74], off offset:480              // 00000044A0F8: DC5201E0 447C0049
	global_load_b32 v67, v[73:74], off offset:576              // 00000044A100: DC520240 437C0049
	global_load_b32 v66, v[73:74], off offset:672              // 00000044A108: DC5202A0 427C0049
	global_load_b32 v86, v[87:88], off                         // 00000044A110: DC520000 567C0057
	global_load_b32 v84, v[87:88], off offset:96               // 00000044A118: DC520060 547C0057
	global_load_b32 v82, v[87:88], off offset:192              // 00000044A120: DC5200C0 527C0057
	global_load_b32 v79, v[87:88], off offset:288              // 00000044A128: DC520120 4F7C0057
	global_load_b32 v76, v[87:88], off offset:384              // 00000044A130: DC520180 4C7C0057
	global_load_b32 v73, v[87:88], off offset:480              // 00000044A138: DC5201E0 497C0057
	global_load_b32 v71, v[87:88], off offset:576              // 00000044A140: DC520240 477C0057
	global_load_b32 v69, v[87:88], off offset:672              // 00000044A148: DC5202A0 457C0057
	global_load_b32 v89, v[3:4], off                           // 00000044A150: DC520000 597C0003
	global_load_b32 v88, v[3:4], off offset:96                 // 00000044A158: DC520060 587C0003
	global_load_b32 v87, v[3:4], off offset:192                // 00000044A160: DC5200C0 577C0003
	global_load_b32 v85, v[3:4], off offset:288                // 00000044A168: DC520120 557C0003
	global_load_b32 v83, v[3:4], off offset:384                // 00000044A170: DC520180 537C0003
	global_load_b32 v80, v[3:4], off offset:480                // 00000044A178: DC5201E0 507C0003
	global_load_b32 v77, v[3:4], off offset:576                // 00000044A180: DC520240 4D7C0003
	global_load_b32 v74, v[3:4], off offset:672                // 00000044A188: DC5202A0 4A7C0003
	s_branch 64501                                             // 00000044A190: BFA0FBF5 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi1ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xc68>
	s_or_b32 exec_lo, exec_lo, s5                              // 00000044A194: 8C7E057E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000044A198: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 00000044A19C: 8C7E017E
	s_waitcnt vmcnt(23)                                        // 00000044A1A0: BF895FF7
	v_dual_mov_b32 v1, v50 :: v_dual_mov_b32 v2, v49           // 00000044A1A4: CA100132 01020131
	s_waitcnt vmcnt(0)                                         // 00000044A1AC: BF8903F7
	v_dual_mov_b32 v3, v48 :: v_dual_mov_b32 v8, v47           // 00000044A1B0: CA100130 0308012F
	v_dual_mov_b32 v4, v46 :: v_dual_mov_b32 v7, v44           // 00000044A1B8: CA10012E 0406012C
	v_mov_b32_e32 v6, v45                                      // 00000044A1C0: 7E0C032D
	v_mov_b32_e32 v9, v5                                       // 00000044A1C4: 7E120305
	s_mov_b32 s0, 0x76543210                                   // 00000044A1C8: BE8000FF 76543210
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000044A1D0: BF870009
	v_permlanex16_b32 v1, v1, s0, 0xfedcba98                   // 00000044A1D4: D65C0001 03FC0101 FEDCBA98
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 00000044A1E0: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 00000044A1EC: D65C0003 03FC0103 FEDCBA98
	v_permlanex16_b32 v8, v8, s0, 0xfedcba98                   // 00000044A1F8: D65C0008 03FC0108 FEDCBA98
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 00000044A204: D65C0004 03FC0104 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 00000044A210: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v7, v7, s0, 0xfedcba98                   // 00000044A21C: D65C0007 03FC0107 FEDCBA98
	v_permlanex16_b32 v9, v9, s0, 0xfedcba98                   // 00000044A228: D65C0009 03FC0109 FEDCBA98
	.long 0xd44c0000                                           // 00000044A234: D44C0000
	v_cndmask_b32_e32 v1, 16, v41, vcc_lo                      // 00000044A238: 02025290
	s_barrier                                                  // 00000044A23C: BFBD0000
	buffer_gl0_inv                                             // 00000044A240: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 00000044A248: BE812000
	s_cbranch_execz 18                                         // 00000044A24C: BFA50012 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi1ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1d98>
	v_dual_add_f32 v5, v5, v9 :: v_dual_add_f32 v8, v47, v8    // 00000044A250: C9081305 0508112F
	v_dual_add_f32 v1, v50, v1 :: v_dual_add_f32 v2, v49, v2   // 00000044A258: C9080332 01020531
	v_lshl_or_b32 v9, v40, 9, v42                              // 00000044A260: D6560009 04A91328
	v_dual_add_f32 v3, v48, v3 :: v_dual_add_f32 v4, v46, v4   // 00000044A268: C9080730 0304092E
	v_dual_add_f32 v6, v45, v6 :: v_dual_add_f32 v7, v44, v7   // 00000044A270: C9080D2D 06060F2C
	ds_store_2addr_b32 v9, v1, v2 offset1:16                   // 00000044A278: D8381000 00020109
	ds_store_2addr_b32 v9, v3, v8 offset0:32 offset1:48        // 00000044A280: D8383020 00080309
	ds_store_2addr_b32 v9, v4, v6 offset0:64 offset1:80        // 00000044A288: D8385040 00060409
	ds_store_2addr_b32 v9, v7, v5 offset0:96 offset1:112       // 00000044A290: D8387060 00050709
	s_or_b32 exec_lo, exec_lo, s1                              // 00000044A298: 8C7E017E
	.long 0xd44c0001                                           // 00000044A29C: D44C0001
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 00000044A2A0: 020200FF 00000080
	s_waitcnt lgkmcnt(0)                                       // 00000044A2A8: BF89FC07
	s_barrier                                                  // 00000044A2AC: BFBD0000
	buffer_gl0_inv                                             // 00000044A2B0: E0AC0000 00000000
	s_and_saveexec_b32 s5, s1                                  // 00000044A2B8: BE852001
	s_cbranch_execnz 9                                         // 00000044A2BC: BFA60009 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi1ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1de4>
	s_or_b32 exec_lo, exec_lo, s5                              // 00000044A2C0: 8C7E057E
	s_cmp_lt_i32 s33, 2                                        // 00000044A2C4: BF048221
	s_mov_b32 s5, -1                                           // 00000044A2C8: BE8500C1
	s_cbranch_scc0 35                                          // 00000044A2CC: BFA10023 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi1ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1e5c>
	s_and_b32 vcc_lo, exec_lo, s5                              // 00000044A2D0: 8B6A057E
	s_cbranch_vccnz 156                                        // 00000044A2D4: BFA4009C <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi1ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2048>
	s_nop 0                                                    // 00000044A2D8: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 00000044A2DC: BFB60003
	s_endpgm                                                   // 00000044A2E0: BFB00000
	v_lshlrev_b32_e32 v7, 2, v0                                // 00000044A2E4: 300E0082
	ds_load_2addr_stride64_b32 v[1:2], v7 offset1:2            // 00000044A2E8: D8E00200 01000007
	ds_load_2addr_stride64_b32 v[3:4], v7 offset0:4 offset1:6  // 00000044A2F0: D8E00604 03000007
	ds_load_2addr_stride64_b32 v[5:6], v7 offset0:8 offset1:10 // 00000044A2F8: D8E00A08 05000007
	s_waitcnt lgkmcnt(2)                                       // 00000044A300: BF89FC27
	v_add_f32_e32 v1, 0, v1                                    // 00000044A304: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000044A308: BF8700A1
	v_add_f32_e32 v1, v1, v2                                   // 00000044A30C: 06020501
	s_waitcnt lgkmcnt(1)                                       // 00000044A310: BF89FC17
	v_add_f32_e32 v3, v1, v3                                   // 00000044A314: 06060701
	ds_load_2addr_stride64_b32 v[1:2], v7 offset0:12 offset1:14// 00000044A318: D8E00E0C 01000007
	v_add_f32_e32 v3, v3, v4                                   // 00000044A320: 06060903
	s_waitcnt lgkmcnt(1)                                       // 00000044A324: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000044A328: BF870091
	v_add_f32_e32 v3, v3, v5                                   // 00000044A32C: 06060B03
	v_add_f32_e32 v3, v3, v6                                   // 00000044A330: 06060D03
	s_waitcnt lgkmcnt(0)                                       // 00000044A334: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000044A338: BF870091
	v_add_f32_e32 v1, v3, v1                                   // 00000044A33C: 06020303
	v_add_f32_e32 v1, v1, v2                                   // 00000044A340: 06020501
	ds_store_b32 v7, v1 offset:4096                            // 00000044A344: D8341000 00000107
	s_or_b32 exec_lo, exec_lo, s5                              // 00000044A34C: 8C7E057E
	s_cmp_lt_i32 s33, 2                                        // 00000044A350: BF048221
	s_mov_b32 s5, -1                                           // 00000044A354: BE8500C1
	s_cbranch_scc1 65501                                       // 00000044A358: BFA2FFDD <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi1ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1dd0>
	s_waitcnt lgkmcnt(0)                                       // 00000044A35C: BF89FC07
	s_barrier                                                  // 00000044A360: BFBD0000
	buffer_gl0_inv                                             // 00000044A364: E0AC0000 00000000
	s_and_saveexec_b32 s5, s1                                  // 00000044A36C: BE852001
	s_cbranch_execz 17                                         // 00000044A370: BFA50011 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi1ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1eb8>
	v_lshlrev_b32_e32 v1, 2, v0                                // 00000044A374: 30020082
	s_mul_hi_i32 s7, s26, s4                                   // 00000044A378: 9707041A
	s_mul_i32 s6, s26, s4                                      // 00000044A37C: 9606041A
	s_lshl_b32 s8, s2, 7                                       // 00000044A380: 84088702
	s_lshl_b64 s[6:7], s[6:7], 2                               // 00000044A384: 84868206
	ds_load_b32 v2, v1 offset:4096                             // 00000044A388: D8D81000 02000001
	s_ashr_i32 s9, s8, 31                                      // 00000044A390: 86099F08
	s_add_u32 s4, s16, s6                                      // 00000044A394: 80040610
	s_addc_u32 s10, s17, s7                                    // 00000044A398: 820A0711
	s_lshl_b64 s[6:7], s[8:9], 2                               // 00000044A39C: 84868208
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000044A3A0: BF870009
	s_add_u32 s6, s4, s6                                       // 00000044A3A4: 80060604
	s_addc_u32 s7, s10, s7                                     // 00000044A3A8: 8207070A
	s_waitcnt lgkmcnt(0)                                       // 00000044A3AC: BF89FC07
	global_store_b32 v1, v2, s[6:7]                            // 00000044A3B0: DC6A0000 00060201
	s_or_b32 exec_lo, exec_lo, s5                              // 00000044A3B8: 8C7E057E
	.long 0xd44a0004                                           // 00000044A3BC: D44A0004
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 00000044A3C0: 02020080
	s_waitcnt_vscnt null, 0x0                                  // 00000044A3C4: BC7C0000
	buffer_gl1_inv                                             // 00000044A3C8: E0B00000 00000000
	buffer_gl0_inv                                             // 00000044A3D0: E0AC0000 00000000
	s_barrier                                                  // 00000044A3D8: BFBD0000
	buffer_gl0_inv                                             // 00000044A3DC: E0AC0000 00000000
	s_and_saveexec_b32 s5, s4                                  // 00000044A3E4: BE852004
	s_cbranch_execz 29                                         // 00000044A3E8: BFA5001D <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi1ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1f60>
	s_mov_b32 s7, exec_lo                                      // 00000044A3EC: BE87007E
	s_mov_b32 s6, exec_lo                                      // 00000044A3F0: BE86007E
	.long 0xd71f0001                                           // 00000044A3F4: D71F0001
	v_cndmask_b32_e32 v0, s7, v128, vcc_lo                     // 00000044A3F8: 02010007
	s_delay_alu instid0(VALU_DEP_1)                            // 00000044A3FC: BF870001
	v_cmpx_eq_u32_e32 0, v1                                    // 00000044A400: 7D940280
	s_cbranch_execz 9                                          // 00000044A404: BFA50009 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi1ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1f2c>
	s_lshl_b64 s[8:9], s[2:3], 2                               // 00000044A408: 84888202
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000044A40C: BF8704B9
	s_add_u32 s8, s18, s8                                      // 00000044A410: 80080812
	s_addc_u32 s9, s19, s9                                     // 00000044A414: 82090913
	s_bcnt1_i32_b32 s7, s7                                     // 00000044A418: BE871807
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, s7              // 00000044A41C: CA100080 02020007
	global_atomic_add_u32 v2, v2, v3, s[8:9] glc               // 00000044A424: DCD64000 02080302
	s_or_b32 exec_lo, exec_lo, s6                              // 00000044A42C: 8C7E067E
	s_waitcnt vmcnt(0)                                         // 00000044A430: BF8903F7
	v_readfirstlane_b32 s6, v2                                 // 00000044A434: 7E0C0502
	s_delay_alu instid0(VALU_DEP_1)                            // 00000044A438: BF870001
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s6, v1       // 00000044A43C: CA200080 02000206
	s_add_i32 s6, s33, -1                                      // 00000044A444: 8106C121
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000044A448: BF870481
	v_cmp_eq_u32_e32 vcc_lo, s6, v1                            // 00000044A44C: 7C940206
	v_cndmask_b32_e64 v1, 0, 1, vcc_lo                         // 00000044A450: D5010001 01A90280
	ds_store_b32 v2, v1 offset:5120                            // 00000044A458: D8341400 00000102
	s_or_b32 exec_lo, exec_lo, s5                              // 00000044A460: 8C7E057E
	v_mov_b32_e32 v1, 0                                        // 00000044A464: 7E020280
	s_waitcnt lgkmcnt(0)                                       // 00000044A468: BF89FC07
	s_barrier                                                  // 00000044A46C: BFBD0000
	buffer_gl0_inv                                             // 00000044A470: E0AC0000 00000000
	ds_load_b32 v1, v1 offset:5120                             // 00000044A478: D8D81400 01000001
	s_waitcnt lgkmcnt(0)                                       // 00000044A480: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 00000044A484: 7C940280
	s_cbranch_vccnz 46                                         // 00000044A488: BFA4002E <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi1ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2044>
	buffer_gl1_inv                                             // 00000044A48C: E0B00000 00000000
	buffer_gl0_inv                                             // 00000044A494: E0AC0000 00000000
	s_and_saveexec_b32 s5, s1                                  // 00000044A49C: BE852001
	s_cbranch_execz 28                                         // 00000044A4A0: BFA5001C <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi1ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2014>
	s_lshl_b32 s6, s2, 7                                       // 00000044A4A4: 84068702
	v_dual_mov_b32 v4, 0 :: v_dual_lshlrev_b32 v3, 2, v0       // 00000044A4A8: CA220080 04020082
	s_ashr_i32 s7, s6, 31                                      // 00000044A4B0: 86079F06
	s_ashr_i32 s27, s26, 31                                    // 00000044A4B4: 861B9F1A
	s_lshl_b64 s[6:7], s[6:7], 2                               // 00000044A4B8: 84868206
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000044A4BC: BF8700B9
	s_add_u32 s1, s16, s6                                      // 00000044A4C0: 80010610
	s_addc_u32 s6, s17, s7                                     // 00000044A4C4: 82060711
	.long 0xd7000101                                           // 00000044A4C8: D7000101
	v_cndmask_b32_e32 v1, s1, v3, vcc_lo                       // 00000044A4CC: 02020601
	v_add_co_ci_u32_e64 v2, null, s6, 0, s1                    // 00000044A4D0: D5207C02 00050006
	s_lshl_b64 s[6:7], s[26:27], 2                             // 00000044A4D8: 8486821A
	global_load_b32 v5, v[1:2], off glc                        // 00000044A4DC: DC524000 057C0001
	.long 0xd7006a01                                           // 00000044A4E4: D7006A01
	v_cndmask_b32_e32 v0, v1, v6, vcc_lo                       // 00000044A4E8: 02000D01
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000044A4EC: BF8704A1
	v_add_co_ci_u32_e64 v2, null, s7, v2, vcc_lo               // 00000044A4F0: D5207C02 01AA0407
	s_add_i32 s33, s33, -1                                     // 00000044A4F8: 8121C121
	s_cmp_eq_u32 s33, 0                                        // 00000044A4FC: BF068021
	s_waitcnt vmcnt(0)                                         // 00000044A500: BF8903F7
	v_add_f32_e32 v4, v4, v5                                   // 00000044A504: 06080B04
	s_cbranch_scc0 65524                                       // 00000044A508: BFA1FFF4 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi1ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1fdc>
	ds_store_b32 v3, v4 offset:4096                            // 00000044A50C: D8341000 00000403
	s_or_b32 exec_lo, exec_lo, s5                              // 00000044A514: 8C7E057E
	s_and_saveexec_b32 s1, s4                                  // 00000044A518: BE812004
	s_cbranch_execz 6                                          // 00000044A51C: BFA50006 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi1ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2038>
	s_lshl_b64 s[4:5], s[2:3], 2                               // 00000044A520: 84848202
	v_mov_b32_e32 v1, 0                                        // 00000044A524: 7E020280
	s_add_u32 s4, s18, s4                                      // 00000044A528: 80040412
	s_addc_u32 s5, s19, s5                                     // 00000044A52C: 82050513
	global_store_b32 v1, v1, s[4:5]                            // 00000044A530: DC6A0000 00040101
	s_or_b32 exec_lo, exec_lo, s1                              // 00000044A538: 8C7E017E
	s_cbranch_execz 65382                                      // 00000044A53C: BFA5FF66 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi1ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1dd8>
	s_branch 1                                                 // 00000044A540: BFA00001 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi1ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2048>
	s_branch 65380                                             // 00000044A544: BFA0FF64 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi1ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1dd8>
	v_cmp_eq_u32_e32 vcc_lo, 0, v40                            // 00000044A548: 7C945080
	s_cmp_gt_i32 s24, 0                                        // 00000044A54C: BF028018
	s_waitcnt lgkmcnt(0)                                       // 00000044A550: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 00000044A554: BC7C0000
	s_cselect_b32 s1, -1, 0                                    // 00000044A558: 980180C1
	s_barrier                                                  // 00000044A55C: BFBD0000
	s_and_b32 s1, vcc_lo, s1                                   // 00000044A560: 8B01016A
	buffer_gl0_inv                                             // 00000044A564: E0AC0000 00000000
	s_and_saveexec_b32 s3, s1                                  // 00000044A56C: BE832001
	s_cbranch_execz 65369                                      // 00000044A570: BFA5FF59 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi1ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1dd8>
	v_and_b32_e32 v1, 15, v0                                   // 00000044A574: 3602008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000044A578: BF870091
	v_lshlrev_b32_e32 v2, 2, v1                                // 00000044A57C: 30040282
	v_add_nc_u32_e32 v8, 0x1000, v2                            // 00000044A580: 4A1004FF 00001000
	ds_load_2addr_b32 v[2:3], v8 offset1:16                    // 00000044A588: D8DC1000 02000008
	ds_load_2addr_b32 v[4:5], v8 offset0:32 offset1:48         // 00000044A590: D8DC3020 04000008
	ds_load_2addr_b32 v[6:7], v8 offset0:64 offset1:80         // 00000044A598: D8DC5040 06000008
	ds_load_2addr_b32 v[8:9], v8 offset0:96 offset1:112        // 00000044A5A0: D8DC7060 08000008
	v_and_b32_e32 v10, 1, v0                                   // 00000044A5A8: 36140081
	v_and_b32_e32 v11, 2, v0                                   // 00000044A5AC: 36160082
	s_waitcnt lgkmcnt(3)                                       // 00000044A5B0: BF89FC37
	v_dual_add_f32 v13, v2, v3 :: v_dual_and_b32 v12, 4, v0    // 00000044A5B4: C9240702 0D0C0084
	s_waitcnt lgkmcnt(2)                                       // 00000044A5BC: BF89FC27
	v_dual_sub_f32 v2, v2, v3 :: v_dual_add_f32 v3, v4, v5     // 00000044A5C0: C9480702 02020B04
	s_waitcnt lgkmcnt(1)                                       // 00000044A5C8: BF89FC17
	v_dual_sub_f32 v4, v4, v5 :: v_dual_add_f32 v5, v6, v7     // 00000044A5CC: C9480B04 04040F06
	s_waitcnt lgkmcnt(0)                                       // 00000044A5D4: BF89FC07
	v_dual_sub_f32 v6, v6, v7 :: v_dual_add_f32 v7, v8, v9     // 00000044A5D8: C9480F06 06061308
	v_dual_sub_f32 v8, v8, v9 :: v_dual_add_f32 v9, v13, v3    // 00000044A5E0: C9481308 0808070D
	v_sub_f32_e32 v3, v13, v3                                  // 00000044A5E8: 0806070D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000044A5EC: BF870243
	v_dual_add_f32 v13, v2, v4 :: v_dual_add_f32 v14, v5, v7   // 00000044A5F0: C9080902 0D0E0F05
	v_dual_sub_f32 v2, v2, v4 :: v_dual_sub_f32 v5, v5, v7     // 00000044A5F8: C94A0902 02040F05
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 00000044A600: 7C941480
	.long 0xd44a0001                                           // 00000044A604: D44A0001
	v_cndmask_b32_e32 v1, 0, v11, vcc_lo                       // 00000044A608: 02021680
	v_dual_add_f32 v7, v9, v14 :: v_dual_add_f32 v4, v6, v8    // 00000044A60C: C9081D09 07041106
	v_sub_f32_e32 v6, v6, v8                                   // 00000044A614: 080C1106
	v_sub_f32_e32 v8, v9, v14                                  // 00000044A618: 08101D09
	.long 0xd44a0003                                           // 00000044A61C: D44A0003
	v_cndmask_b32_e32 v1, 0, v12, vcc_lo                       // 00000044A620: 02021880
	s_delay_alu instid0(VALU_DEP_3)                            // 00000044A624: BF870003
	v_dual_add_f32 v9, v13, v4 :: v_dual_sub_f32 v10, v2, v6   // 00000044A628: C90A090D 090A0D02
	v_dual_sub_f32 v4, v13, v4 :: v_dual_add_f32 v13, v3, v5   // 00000044A630: C948090D 040C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 00000044A638: 08060B03
	v_add_f32_e32 v5, v2, v6                                   // 00000044A63C: 060A0D02
	v_mov_b32_dpp v2, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000044A640: 7E0402FA FF016107
	v_cndmask_b32_e64 v6, -v7, v7, vcc_lo                      // 00000044A648: D5010006 21AA0F07
	v_mov_b32_dpp v7, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000044A650: 7E0E02FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 00000044A658: D5010009 21AA1309
	v_mov_b32_dpp v15, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000044A660: 7E1E02FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 00000044A668: D5010005 21AA0B05
	v_mov_b32_dpp v14, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000044A670: 7E1C02FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 00000044A678: D501000D 21AA1B0D
	v_mov_b32_dpp v16, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000044A680: 7E2002FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 00000044A688: D5010008 21AA1108
	v_mov_b32_dpp v17, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000044A690: 7E2202FA FF016104
	v_cndmask_b32_e64 v18, -v4, v4, vcc_lo                     // 00000044A698: D5010012 21AA0904
	v_mov_b32_dpp v19, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000044A6A0: 7E2602FA FF016103
	v_cndmask_b32_e64 v20, -v3, v3, vcc_lo                     // 00000044A6A8: D5010014 21AA0703
	v_dual_add_f32 v3, v9, v7 :: v_dual_add_f32 v2, v6, v2     // 00000044A6B0: C9080F09 03020506
	v_dual_add_f32 v4, v5, v15 :: v_dual_add_f32 v7, v8, v16   // 00000044A6B8: C9081F05 04062108
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000044A6C0: BF870192
	v_cndmask_b32_e64 v8, -v3, v3, s1                          // 00000044A6C4: D5010008 20060703
	v_mov_b32_dpp v6, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000044A6CC: 7E0C02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 00000044A6D4: D5010002 20060502
	v_mov_b32_dpp v3, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000044A6DC: 7E0602FA FF016203
	v_mov_b32_dpp v11, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000044A6E4: 7E1602FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 00000044A6EC: D5010004 20060904
	v_add_f32_e32 v5, v13, v14                                 // 00000044A6F4: 060A1D0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000044A6F8: BF870224
	v_dual_add_f32 v2, v2, v6 :: v_dual_add_f32 v3, v8, v3     // 00000044A6FC: C9080D02 02020708
	v_mov_b32_dpp v13, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000044A704: 7E1A02FA FF016207
	v_add_f32_e32 v4, v4, v11                                  // 00000044A70C: 06081704
	s_delay_alu instid0(VALU_DEP_4)                            // 00000044A710: BF870004
	v_mov_b32_dpp v9, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000044A714: 7E1202FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s1                          // 00000044A71C: D5010005 20060B05
	v_mov_b32_dpp v6, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000044A724: 7E0C02FA FF016402
	v_cndmask_b32_e64 v8, -v3, v3, s3                          // 00000044A72C: D5010008 200E0703
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 00000044A734: D5010002 200E0502
	v_mov_b32_dpp v11, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000044A73C: 7E1602FA FF016403
	v_add_f32_e32 v5, v5, v9                                   // 00000044A744: 060A1305
	v_mov_b32_dpp v9, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000044A748: 7E1202FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 00000044A750: D5010004 200E0904
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000044A758: BF870214
	v_dual_add_f32 v3, v2, v6 :: v_dual_add_f32 v6, v8, v11    // 00000044A75C: C9080D02 03061708
	v_mov_b32_dpp v8, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000044A764: 7E1002FA FF016405
	v_cndmask_b32_e64 v11, -v5, v5, s3                         // 00000044A76C: D501000B 200E0B05
	s_delay_alu instid0(VALU_DEP_4)                            // 00000044A774: BF870004
	v_add_f32_e32 v4, v4, v9                                   // 00000044A778: 06081304
	v_mov_b32_dpp v9, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000044A77C: 7E1202FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 00000044A784: D501000A 21AA150A
	v_add_f32_e32 v12, v18, v17                                // 00000044A78C: 06182312
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 00000044A790: D5010007 20060F07
	v_add_f32_e32 v14, v20, v19                                // 00000044A798: 061C2714
	v_mov_b32_dpp v2, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000044A79C: 7E0402FA FF016803
	v_add_f32_e32 v9, v10, v9                                  // 00000044A7A4: 0612130A
	v_mov_b32_dpp v5, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000044A7A8: 7E0A02FA FF016806
	v_add_f32_e32 v13, v7, v13                                 // 00000044A7B0: 061A1B07
	v_mov_b32_dpp v15, v14 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000044A7B4: 7E1E02FA FF01620E
	v_cndmask_b32_e64 v14, -v14, v14, s1                       // 00000044A7BC: D501000E 20061D0E
	v_mov_b32_dpp v16, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000044A7C4: 7E2002FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 00000044A7CC: D5010009 20061309
	v_add_f32_e32 v7, v11, v8                                  // 00000044A7D4: 060E110B
	v_mov_b32_dpp v10, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000044A7D8: 7E1402FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 00000044A7E0: D501000C 2006190C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000044A7E8: BF870114
	v_dual_add_f32 v8, v14, v15 :: v_dual_add_f32 v9, v9, v16  // 00000044A7EC: C9081F0E 08082109
	v_add_f32_e32 v10, v12, v10                                // 00000044A7F4: 0614150C
	v_mov_b32_dpp v11, v13 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000044A7F8: 7E1602FA FF01640D
	v_cndmask_b32_e64 v13, -v13, v13, s3                       // 00000044A800: D501000D 200E1B0D
	s_delay_alu instid0(VALU_DEP_4)                            // 00000044A808: BF870004
	v_mov_b32_dpp v15, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000044A80C: 7E1E02FA FF016408
	v_mov_b32_dpp v17, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000044A814: 7E2202FA FF016409
	v_mov_b32_dpp v12, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000044A81C: 7E1802FA FF01640A
	v_cndmask_b32_e64 v10, -v10, v10, s3                       // 00000044A824: D501000A 200E150A
	v_cndmask_b32_e64 v18, -v8, v8, s3                         // 00000044A82C: D5010012 200E1108
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 00000044A834: D5010009 200E1309
	v_add_f32_e32 v14, v13, v11                                // 00000044A83C: 061C170D
	v_mov_b32_dpp v8, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000044A840: 7E1002FA FF016807
	v_add_f32_e32 v16, v10, v12                                // 00000044A848: 0620190A
	v_add_f32_e32 v15, v18, v15                                // 00000044A84C: 061E1F12
	v_add_f32_e32 v17, v9, v17                                 // 00000044A850: 06222309
	v_mov_b32_dpp v9, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000044A854: 7E1202FA FF016804
	v_mov_b32_dpp v10, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000044A85C: 7E1402FA FF01680E
	v_mov_b32_dpp v11, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000044A864: 7E1602FA FF016810
	v_mov_b32_dpp v12, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000044A86C: 7E1802FA FF01680F
	v_mov_b32_dpp v13, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000044A874: 7E1A02FA FF016811
	s_and_b32 exec_lo, exec_lo, s0                             // 00000044A87C: 8B7E007E
	s_cbranch_execz 65173                                      // 00000044A880: BFA5FE95 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi1ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1dd8>
	v_lshl_or_b32 v18, s2, 7, v1                               // 00000044A884: D6560012 04050E02
	v_and_b32_e32 v0, 8, v0                                    // 00000044A88C: 36000088
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000044A890: BF870092
	v_ashrrev_i32_e32 v19, 31, v18                             // 00000044A894: 3426249F
	.long 0xd73c0012                                           // 00000044A898: D73C0012
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 00000044A89C: 02022481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000044A8A0: BF870091
	.long 0xd7006a14                                           // 00000044A8A4: D7006A14
	v_cndmask_b32_e32 v1, s14, v18, vcc_lo                     // 00000044A8A8: 0202240E
	v_add_co_ci_u32_e64 v21, null, s15, v19, vcc_lo            // 00000044A8AC: D5207C15 01AA260F
	v_cmp_eq_u32_e32 vcc_lo, 0, v0                             // 00000044A8B4: 7C940080
	s_clause 0x7                                               // 00000044A8B8: BF850007
	global_load_d16_b16 v22, v[20:21], off offset:32           // 00000044A8BC: DC820020 167C0014
	global_load_d16_b16 v23, v[20:21], off                     // 00000044A8C4: DC820000 177C0014
	global_load_d16_b16 v24, v[20:21], off offset:64           // 00000044A8CC: DC820040 187C0014
	global_load_d16_b16 v25, v[20:21], off offset:96           // 00000044A8D4: DC820060 197C0014
	global_load_d16_b16 v26, v[20:21], off offset:128          // 00000044A8DC: DC820080 1A7C0014
	global_load_d16_b16 v27, v[20:21], off offset:160          // 00000044A8E4: DC8200A0 1B7C0014
	global_load_d16_b16 v28, v[20:21], off offset:192          // 00000044A8EC: DC8200C0 1C7C0014
	global_load_d16_b16 v20, v[20:21], off offset:224          // 00000044A8F4: DC8200E0 147C0014
	.long 0x7f2a3880                                           // 00000044A8FC: 7F2A3880
	v_cndmask_b32_e64 v0, -v6, v6, vcc_lo                      // 00000044A900: D5010000 21AA0D06
	v_cndmask_b32_e64 v1, -v3, v3, vcc_lo                      // 00000044A908: D5010001 21AA0703
	v_cndmask_b32_e64 v3, -v4, v4, vcc_lo                      // 00000044A910: D5010003 21AA0904
	v_cndmask_b32_e64 v4, -v7, v7, vcc_lo                      // 00000044A918: D5010004 21AA0F07
	v_cndmask_b32_e64 v7, -v14, v14, vcc_lo                    // 00000044A920: D5010007 21AA1D0E
	v_add_f32_e32 v0, v0, v5                                   // 00000044A928: 06000B00
	v_cndmask_b32_e64 v5, -v16, v16, vcc_lo                    // 00000044A92C: D5010005 21AA2110
	v_add_f32_e32 v3, v3, v9                                   // 00000044A934: 06061303
	s_waitcnt vmcnt(7)                                         // 00000044A938: BF891FF7
	.long 0x7f2c3995                                           // 00000044A93C: 7F2C3995
	v_dual_add_f32 v7, v7, v10 :: v_dual_mul_f32 v16, 0x3db504f3, v0// 00000044A940: C9061507 071000FF 3DB504F3
	v_add_f32_e32 v5, v5, v11                                  // 00000044A94C: 060A1705
	v_cndmask_b32_e64 v14, -v17, v17, vcc_lo                   // 00000044A950: D501000E 21AA2311
	v_cndmask_b32_e64 v15, -v15, v15, vcc_lo                   // 00000044A958: D501000F 21AA1F0F
	v_add_f32_e32 v2, v1, v2                                   // 00000044A960: 06040501
	v_dual_add_f32 v4, v4, v8 :: v_dual_mul_f32 v3, 0x3db504f3, v3// 00000044A964: C9061104 040206FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000044A970: BF870193
	v_dual_add_f32 v9, v14, v13 :: v_dual_add_f32 v8, v15, v12 // 00000044A974: C9081B0E 0908190F
	v_dual_mul_f32 v5, 0x3db504f3, v5 :: v_dual_mul_f32 v2, 0x3db504f3, v2// 00000044A97C: C8C60AFF 050204FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000044A988: BF870193
	v_dual_mul_f32 v7, 0x3db504f3, v7 :: v_dual_mul_f32 v4, 0x3db504f3, v4// 00000044A98C: C8C60EFF 070408FF 3DB504F3
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 00000044A998: 101212FF 3DB504F3
	s_waitcnt vmcnt(6)                                         // 00000044A9A0: BF891BF7
	.long 0x7f2e3995                                           // 00000044A9A4: 7F2E3995
	.long 0x7f0c3995                                           // 00000044A9A8: 7F0C3995
	s_waitcnt vmcnt(0)                                         // 00000044A9AC: BF8903F7
	.long 0x7f283995                                           // 00000044A9B0: 7F283995
	.long 0xd7006a00                                           // 00000044A9B4: D7006A00
	v_cndmask_b32_e32 v1, s20, v18, vcc_lo                     // 00000044A9B8: 02022414
	s_delay_alu instid0(VALU_DEP_1)                            // 00000044A9BC: BF870001
	v_add_co_ci_u32_e64 v1, null, s21, v19, vcc_lo             // 00000044A9C0: D5207C01 01AA2615
	v_fma_mix_f32 v10, v22, v16, neg(0) op_sel_hi:[1,0,0]      // 00000044A9C8: CC20000A 8A022116
	v_fma_mix_f32 v2, v23, v2, neg(0) op_sel_hi:[1,0,0]        // 00000044A9D0: CC200002 8A020517
	v_fma_mix_f32 v4, v24, v4, neg(0) op_sel_hi:[1,0,0]        // 00000044A9D8: CC200004 8A020918
	v_fma_mix_f32 v3, v25, v3, neg(0) op_sel_hi:[1,0,0]        // 00000044A9E0: CC200003 8A020719
	v_fma_mix_f32 v7, v26, v7, neg(0) op_sel_hi:[1,0,0]        // 00000044A9E8: CC200007 8A020F1A
	.long 0x7e2a398a                                           // 00000044A9F0: 7E2A398A
	v_mul_f32_e32 v8, 0x3db504f3, v8                           // 00000044A9F4: 101010FF 3DB504F3
	v_fma_mix_f32 v5, v27, v5, neg(0) op_sel_hi:[1,0,0]        // 00000044A9FC: CC200005 8A020B1B
	v_fma_mix_f32 v9, v20, v9, neg(0) op_sel_hi:[1,0,0]        // 00000044AA04: CC200009 8A021314
	.long 0x7e0c3982                                           // 00000044AA0C: 7E0C3982
	v_and_b32_e32 v11, 1, v21                                  // 00000044AA10: 36162A81
	.long 0x7e2a3983                                           // 00000044AA14: 7E2A3983
	v_fma_mix_f32 v8, v28, v8, neg(0) op_sel_hi:[1,0,0]        // 00000044AA18: CC200008 8A02111C
	.long 0x7e283984                                           // 00000044AA20: 7E283984
	.long 0x7e2c3987                                           // 00000044AA24: 7E2C3987
	v_and_b32_e32 v6, 1, v6                                    // 00000044AA28: 360C0C81
	v_and_b32_e32 v12, 1, v21                                  // 00000044AA2C: 36182A81
	.long 0x7e2a3985                                           // 00000044AA30: 7E2A3985
	.long 0x7e2e3988                                           // 00000044AA34: 7E2E3988
	v_and_b32_e32 v13, 1, v20                                  // 00000044AA38: 361A2881
	v_and_b32_e32 v14, 1, v22                                  // 00000044AA3C: 361C2C81
	v_add3_u32 v2, v2, v6, 0x7fff                              // 00000044AA40: D6550002 03FE0D02 00007FFF
	v_and_b32_e32 v15, 1, v21                                  // 00000044AA4C: 361E2A81
	.long 0x7e2a3989                                           // 00000044AA50: 7E2A3989
	v_and_b32_e32 v16, 1, v23                                  // 00000044AA54: 36202E81
	v_add3_u32 v10, v10, v11, 0x7fff                           // 00000044AA58: D655000A 03FE170A 00007FFF
	v_add3_u32 v4, v4, v13, 0x7fff                             // 00000044AA64: D6550004 03FE1B04 00007FFF
	v_add3_u32 v3, v3, v12, 0x7fff                             // 00000044AA70: D6550003 03FE1903 00007FFF
	v_and_b32_e32 v6, 1, v21                                   // 00000044AA7C: 360C2A81
	v_add3_u32 v7, v7, v14, 0x7fff                             // 00000044AA80: D6550007 03FE1D07 00007FFF
	v_add3_u32 v8, v8, v16, 0x7fff                             // 00000044AA8C: D6550008 03FE2108 00007FFF
	v_add3_u32 v5, v5, v15, 0x7fff                             // 00000044AA98: D6550005 03FE1F05 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 00000044AAA4: BF870004
	v_add3_u32 v6, v9, v6, 0x7fff                              // 00000044AAA8: D6550006 03FE0D09 00007FFF
	s_clause 0x7                                               // 00000044AAB4: BF850007
	global_store_d16_hi_b16 v[0:1], v2, off                    // 00000044AAB8: DC960000 007C0200
	global_store_d16_hi_b16 v[0:1], v10, off offset:32         // 00000044AAC0: DC960020 007C0A00
	global_store_d16_hi_b16 v[0:1], v4, off offset:64          // 00000044AAC8: DC960040 007C0400
	global_store_d16_hi_b16 v[0:1], v3, off offset:96          // 00000044AAD0: DC960060 007C0300
	global_store_d16_hi_b16 v[0:1], v7, off offset:128         // 00000044AAD8: DC960080 007C0700
	global_store_d16_hi_b16 v[0:1], v5, off offset:160         // 00000044AAE0: DC9600A0 007C0500
	global_store_d16_hi_b16 v[0:1], v8, off offset:192         // 00000044AAE8: DC9600C0 007C0800
	global_store_d16_hi_b16 v[0:1], v6, off offset:224         // 00000044AAF0: DC9600E0 007C0600
	s_nop 0                                                    // 00000044AAF8: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 00000044AAFC: BFB60003
	s_endpgm                                                   // 00000044AB00: BFB00000
		...

