0000000000749100 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000749100: F4100100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 000000749108: 86039F02
	v_lshrrev_b32_e32 v21, 2, v0                               // 00000074910C: 322A0082
	s_lshl_b64 s[2:3], s[2:3], 2                               // 000000749110: 84828202
	v_and_b32_e32 v1, 15, v0                                   // 000000749114: 3602008F
	v_lshrrev_b32_e32 v22, 6, v0                               // 000000749118: 322C0086
	v_bfe_u32 v23, v0, 5, 1                                    // 00000074911C: D6100017 02050B00
	v_and_b32_e32 v2, 60, v21                                  // 000000749124: 36042ABC
	.long 0x7f0a3880                                           // 000000749128: 7F0A3880
	v_lshlrev_b32_e32 v1, 2, v1                                // 00000074912C: 30020282
	s_waitcnt lgkmcnt(0)                                       // 000000749130: BF89FC07
	s_clause 0x1                                               // 000000749134: BF850001
	global_load_b32 v3, v1, s[4:5]                             // 000000749138: DC520000 03040001
	global_load_b32 v4, v2, s[4:5]                             // 000000749140: DC520000 04040002
	s_add_u32 s0, s4, s16                                      // 000000749148: 80001004
	s_addc_u32 s1, s5, s17                                     // 00000074914C: 82011105
	s_ashr_i32 s16, s11, 31                                    // 000000749150: 86109F0B
	v_mov_b32_e32 v2, s3                                       // 000000749154: 7E040203
	s_lshr_b32 s16, s16, 27                                    // 000000749158: 85109B10
	v_or_b32_e32 v1, s2, v22                                   // 00000074915C: 38022C02
	s_add_u32 s16, s10, s16                                    // 000000749160: 8010100A
	s_addc_u32 s17, s11, 0                                     // 000000749164: 8211800B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000749168: BF870099
	s_lshr_b64 s[16:17], s[16:17], 5                           // 00000074916C: 85908510
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 000000749170: 7CA8020C
	s_add_i32 s17, s16, 1                                      // 000000749174: 81118110
	v_and_b32_e32 v24, 31, v0                                  // 000000749178: 3630009F
	s_lshr_b32 s20, s17, 31                                    // 00000074917C: 85149F11
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000749180: BF870009
	s_add_i32 s17, s17, s20                                    // 000000749184: 81111411
	v_cndmask_b32_e32 v9, 0, v1, vcc_lo                        // 000000749188: 02120280
	s_ashr_i32 s17, s17, 1                                     // 00000074918C: 86118111
	v_cndmask_b32_e64 v10, 0, s3, vcc_lo                       // 000000749190: D501000A 01A80680
	.long 0xd72c0002                                           // 000000749198: D72C0002
	v_cndmask_b32_e32 v1, s17, v23, vcc_lo                     // 00000074919C: 02022E11
	s_cmpk_lt_i32 s16, 0x201                                   // 0000007491A0: B3900201
	.long 0xd72c0007                                           // 0000007491A4: D72C0007
	v_cndmask_b32_e32 v1, s19, v9, vcc_lo                      // 0000007491A8: 02021213
	v_mad_u64_u32 v[17:18], null, s18, v9, s[0:1]              // 0000007491AC: D6FE7C11 00021212
	s_cselect_b32 s0, -1, 0                                    // 0000007491B4: 980080C1
	s_cmpk_gt_i32 s16, 0x200                                   // 0000007491B8: B2900200
	v_lshlrev_b32_e32 v1, 2, v0                                // 0000007491BC: 30020082
	v_add_nc_u32_e32 v11, s17, v2                              // 0000007491C0: 4A160411
	v_add_nc_u32_e32 v25, v2, v24                              // 0000007491C4: 4A323102
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000007491C8: BF8704A2
	v_min_i32_e32 v26, s16, v11                                // 0000007491CC: 22341610
	s_cselect_b32 s16, -1, 0                                   // 0000007491D0: 981080C1
	s_and_b32 vcc_lo, exec_lo, s16                             // 0000007491D4: 8B6A107E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000007491D8: BF870151
	.long 0xd4410001                                           // 0000007491DC: D4410001
	v_cndmask_b32_e32 v1, v25, v26, vcc_lo                     // 0000007491E0: 02023519
	s_waitcnt vmcnt(1)                                         // 0000007491E4: BF8907F7
	v_bfe_u32 v6, v3, 16, 1                                    // 0000007491E8: D6100006 02052103
	s_waitcnt vmcnt(0)                                         // 0000007491F0: BF8903F7
	v_bfe_u32 v8, v4, 16, 1                                    // 0000007491F4: D6100008 02052104
	v_add3_u32 v3, v3, v6, 0x7fff                              // 0000007491FC: D6550003 03FE0D03 00007FFF
	.long 0xd72c0006                                           // 000000749208: D72C0006
	v_cndmask_b32_e32 v1, s18, v10, vcc_lo                     // 00000074920C: 02021412
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000749210: BF870193
	v_add3_u32 v4, v4, v8, 0x7fff                              // 000000749214: D6550004 03FE1104 00007FFF
	.long 0x7e0a3983                                           // 000000749220: 7E0A3983
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000749224: BF870113
	v_add3_u32 v27, v7, v18, v6                                // 000000749228: D655001B 041A2507
	v_and_or_b32 v2, 0xffff0000, v4, v5                        // 000000749230: D6570002 041608FF FFFF0000
	ds_store_b32 v1, v2                                        // 00000074923C: D8340000 00000201
	s_waitcnt lgkmcnt(0)                                       // 000000749244: BF89FC07
	s_barrier                                                  // 000000749248: BFBD0000
	buffer_gl0_inv                                             // 00000074924C: E0AC0000 00000000
	s_cbranch_vccnz 154                                        // 000000749254: BFA4009A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x3c0>
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v1, 0               // 000000749258: CA100080 02000080
	s_and_saveexec_b32 s17, s1                                 // 000000749260: BE912001
	s_cbranch_execz 11                                         // 000000749264: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x194>
	v_lshlrev_b32_e32 v1, 1, v25                               // 000000749268: 30023281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000074926C: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v1                               // 000000749270: 3408029F
	.long 0xd7006a03                                           // 000000749274: D7006A03
	v_cndmask_b32_e32 v1, v17, v1, vcc_lo                      // 000000749278: 02020311
	v_add_co_ci_u32_e64 v4, null, v27, v4, vcc_lo              // 00000074927C: D5207C04 01AA091B
	global_load_d16_b16 v1, v[3:4], off                        // 000000749284: DC820000 017C0003
	s_waitcnt vmcnt(0)                                         // 00000074928C: BF8903F7
	v_cvt_f32_f16_e32 v1, v1                                   // 000000749290: 7E021701
	s_or_b32 exec_lo, exec_lo, s17                             // 000000749294: 8C7E117E
	v_add_nc_u32_e32 v3, 32, v25                               // 000000749298: 4A0632A0
	s_mov_b32 s1, exec_lo                                      // 00000074929C: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007492A0: BF870001
	.long 0xd4c1007e                                           // 0000007492A4: D4C1007E
	v_cndmask_b32_e32 v1, v3, v26, vcc_lo                      // 0000007492A8: 02023503
	s_cbranch_execz 11                                         // 0000007492AC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x1dc>
	v_lshlrev_b32_e32 v2, 1, v3                                // 0000007492B0: 30040681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007492B4: BF8700A1
	v_ashrrev_i32_e32 v3, 31, v2                               // 0000007492B8: 3406049F
	.long 0xd7006a02                                           // 0000007492BC: D7006A02
	v_cndmask_b32_e32 v1, v17, v2, vcc_lo                      // 0000007492C0: 02020511
	v_add_co_ci_u32_e64 v3, null, v27, v3, vcc_lo              // 0000007492C4: D5207C03 01AA071B
	global_load_d16_b16 v2, v[2:3], off                        // 0000007492CC: DC820000 027C0002
	s_waitcnt vmcnt(0)                                         // 0000007492D4: BF8903F7
	v_cvt_f32_f16_e32 v2, v2                                   // 0000007492D8: 7E041702
	s_or_b32 exec_lo, exec_lo, s1                              // 0000007492DC: 8C7E017E
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v5, 64, v25      // 0000007492E0: CA200080 040432C0
	v_mov_b32_e32 v3, 0                                        // 0000007492E8: 7E060280
	s_mov_b32 s1, exec_lo                                      // 0000007492EC: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007492F0: BF870002
	.long 0xd4c1007e                                           // 0000007492F4: D4C1007E
	v_cndmask_b32_e32 v1, v5, v26, vcc_lo                      // 0000007492F8: 02023505
	s_cbranch_execz 11                                         // 0000007492FC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x22c>
	v_lshlrev_b32_e32 v3, 1, v5                                // 000000749300: 30060A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000749304: BF8700A1
	v_ashrrev_i32_e32 v6, 31, v3                               // 000000749308: 340C069F
	.long 0xd7006a05                                           // 00000074930C: D7006A05
	v_cndmask_b32_e32 v1, v17, v3, vcc_lo                      // 000000749310: 02020711
	v_add_co_ci_u32_e64 v6, null, v27, v6, vcc_lo              // 000000749314: D5207C06 01AA0D1B
	global_load_d16_b16 v3, v[5:6], off                        // 00000074931C: DC820000 037C0005
	s_waitcnt vmcnt(0)                                         // 000000749324: BF8903F7
	v_cvt_f32_f16_e32 v3, v3                                   // 000000749328: 7E061703
	s_or_b32 exec_lo, exec_lo, s1                              // 00000074932C: 8C7E017E
	v_add_nc_u32_e32 v5, 0x60, v25                             // 000000749330: 4A0A32FF 00000060
	s_mov_b32 s1, exec_lo                                      // 000000749338: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000074933C: BF870001
	.long 0xd4c1007e                                           // 000000749340: D4C1007E
	v_cndmask_b32_e32 v1, v5, v26, vcc_lo                      // 000000749344: 02023505
	s_cbranch_execz 11                                         // 000000749348: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x278>
	v_lshlrev_b32_e32 v4, 1, v5                                // 00000074934C: 30080A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000749350: BF8700A1
	v_ashrrev_i32_e32 v5, 31, v4                               // 000000749354: 340A089F
	.long 0xd7006a04                                           // 000000749358: D7006A04
	v_cndmask_b32_e32 v1, v17, v4, vcc_lo                      // 00000074935C: 02020911
	v_add_co_ci_u32_e64 v5, null, v27, v5, vcc_lo              // 000000749360: D5207C05 01AA0B1B
	global_load_d16_b16 v4, v[4:5], off                        // 000000749368: DC820000 047C0004
	s_waitcnt vmcnt(0)                                         // 000000749370: BF8903F7
	v_cvt_f32_f16_e32 v4, v4                                   // 000000749374: 7E081704
	s_or_b32 exec_lo, exec_lo, s1                              // 000000749378: 8C7E017E
	v_dual_mov_b32 v6, 0 :: v_dual_add_nc_u32 v7, 0x80, v25    // 00000074937C: CA200080 060632FF 00000080
	v_mov_b32_e32 v5, 0                                        // 000000749388: 7E0A0280
	s_mov_b32 s1, exec_lo                                      // 00000074938C: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000749390: BF870002
	.long 0xd4c1007e                                           // 000000749394: D4C1007E
	v_cndmask_b32_e32 v1, v7, v26, vcc_lo                      // 000000749398: 02023507
	s_cbranch_execz 11                                         // 00000074939C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x2cc>
	v_lshlrev_b32_e32 v5, 1, v7                                // 0000007493A0: 300A0E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007493A4: BF8700A1
	v_ashrrev_i32_e32 v8, 31, v5                               // 0000007493A8: 34100A9F
	.long 0xd7006a07                                           // 0000007493AC: D7006A07
	v_cndmask_b32_e32 v1, v17, v5, vcc_lo                      // 0000007493B0: 02020B11
	v_add_co_ci_u32_e64 v8, null, v27, v8, vcc_lo              // 0000007493B4: D5207C08 01AA111B
	global_load_d16_b16 v5, v[7:8], off                        // 0000007493BC: DC820000 057C0007
	s_waitcnt vmcnt(0)                                         // 0000007493C4: BF8903F7
	v_cvt_f32_f16_e32 v5, v5                                   // 0000007493C8: 7E0A1705
	s_or_b32 exec_lo, exec_lo, s1                              // 0000007493CC: 8C7E017E
	v_add_nc_u32_e32 v7, 0xa0, v25                             // 0000007493D0: 4A0E32FF 000000A0
	s_mov_b32 s1, exec_lo                                      // 0000007493D8: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007493DC: BF870001
	.long 0xd4c1007e                                           // 0000007493E0: D4C1007E
	v_cndmask_b32_e32 v1, v7, v26, vcc_lo                      // 0000007493E4: 02023507
	s_cbranch_execz 11                                         // 0000007493E8: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x318>
	v_lshlrev_b32_e32 v6, 1, v7                                // 0000007493EC: 300C0E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007493F0: BF8700A1
	v_ashrrev_i32_e32 v7, 31, v6                               // 0000007493F4: 340E0C9F
	.long 0xd7006a06                                           // 0000007493F8: D7006A06
	v_cndmask_b32_e32 v1, v17, v6, vcc_lo                      // 0000007493FC: 02020D11
	v_add_co_ci_u32_e64 v7, null, v27, v7, vcc_lo              // 000000749400: D5207C07 01AA0F1B
	global_load_d16_b16 v6, v[6:7], off                        // 000000749408: DC820000 067C0006
	s_waitcnt vmcnt(0)                                         // 000000749410: BF8903F7
	v_cvt_f32_f16_e32 v6, v6                                   // 000000749414: 7E0C1706
	s_or_b32 exec_lo, exec_lo, s1                              // 000000749418: 8C7E017E
	v_dual_mov_b32 v8, 0 :: v_dual_add_nc_u32 v11, 0xc0, v25   // 00000074941C: CA200080 080A32FF 000000C0
	v_mov_b32_e32 v7, 0                                        // 000000749428: 7E0E0280
	s_mov_b32 s1, exec_lo                                      // 00000074942C: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000749430: BF870002
	.long 0xd4c1007e                                           // 000000749434: D4C1007E
	v_cndmask_b32_e32 v1, v11, v26, vcc_lo                     // 000000749438: 0202350B
	s_cbranch_execz 11                                         // 00000074943C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x36c>
	v_lshlrev_b32_e32 v7, 1, v11                               // 000000749440: 300E1681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000749444: BF8700A1
	v_ashrrev_i32_e32 v12, 31, v7                              // 000000749448: 34180E9F
	.long 0xd7006a0b                                           // 00000074944C: D7006A0B
	v_cndmask_b32_e32 v1, v17, v7, vcc_lo                      // 000000749450: 02020F11
	v_add_co_ci_u32_e64 v12, null, v27, v12, vcc_lo            // 000000749454: D5207C0C 01AA191B
	global_load_d16_b16 v7, v[11:12], off                      // 00000074945C: DC820000 077C000B
	s_waitcnt vmcnt(0)                                         // 000000749464: BF8903F7
	v_cvt_f32_f16_e32 v7, v7                                   // 000000749468: 7E0E1707
	s_or_b32 exec_lo, exec_lo, s1                              // 00000074946C: 8C7E017E
	v_add_nc_u32_e32 v11, 0xe0, v25                            // 000000749470: 4A1632FF 000000E0
	s_mov_b32 s1, exec_lo                                      // 000000749478: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000074947C: BF870001
	.long 0xd4c1007e                                           // 000000749480: D4C1007E
	v_cndmask_b32_e32 v1, v11, v26, vcc_lo                     // 000000749484: 0202350B
	s_cbranch_execz 11                                         // 000000749488: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x3b8>
	v_lshlrev_b32_e32 v8, 1, v11                               // 00000074948C: 30101681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000749490: BF8700A1
	v_ashrrev_i32_e32 v12, 31, v8                              // 000000749494: 3418109F
	.long 0xd7006a0b                                           // 000000749498: D7006A0B
	v_cndmask_b32_e32 v1, v17, v8, vcc_lo                      // 00000074949C: 02021111
	v_add_co_ci_u32_e64 v12, null, v27, v12, vcc_lo            // 0000007494A0: D5207C0C 01AA191B
	global_load_d16_b16 v8, v[11:12], off                      // 0000007494A8: DC820000 087C000B
	s_waitcnt vmcnt(0)                                         // 0000007494B0: BF8903F7
	v_cvt_f32_f16_e32 v8, v8                                   // 0000007494B4: 7E101708
	s_or_b32 exec_lo, exec_lo, s1                              // 0000007494B8: 8C7E017E
	s_branch 9                                                 // 0000007494BC: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x3e4>
	v_mov_b32_e32 v1, 0                                        // 0000007494C0: 7E020280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007494C4: BF870001
	v_mov_b32_e32 v2, v1                                       // 0000007494C8: 7E040301
	v_mov_b32_e32 v3, v1                                       // 0000007494CC: 7E060301
	v_mov_b32_e32 v4, v1                                       // 0000007494D0: 7E080301
	v_mov_b32_e32 v5, v1                                       // 0000007494D4: 7E0A0301
	v_mov_b32_e32 v6, v1                                       // 0000007494D8: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 0000007494DC: 7E0E0301
	v_mov_b32_e32 v8, v1                                       // 0000007494E0: 7E100301
	s_add_u32 s4, s4, s14                                      // 0000007494E4: 80040E04
	s_addc_u32 s5, s5, s15                                     // 0000007494E8: 82050F05
	s_lshr_b32 s1, s11, 31                                     // 0000007494EC: 85019F0B
	v_dual_mov_b32 v13, 0 :: v_dual_mov_b32 v28, 0             // 0000007494F0: CA100080 0D1C0080
	s_add_u32 s14, s10, s1                                     // 0000007494F8: 800E010A
	s_addc_u32 s15, s11, 0                                     // 0000007494FC: 820F800B
	.long 0xd4410001                                           // 000000749500: D4410001
	v_cndmask_b32_e32 v1, v25, v26, vcc_lo                     // 000000749504: 02023519
	s_ashr_i64 s[14:15], s[14:15], 1                           // 000000749508: 868E810E
	v_cndmask_b32_e64 v29, 0, 1, s16                           // 00000074950C: D501001D 00410280
	v_mad_u64_u32 v[18:19], null, v9, s14, s[4:5]              // 000000749514: D6FE7C12 00101D09
	.long 0xd72c0009                                           // 00000074951C: D72C0009
	v_cndmask_b32_e32 v0, v9, v15, vcc_lo                      // 000000749520: 02001F09
	.long 0xd72c000a                                           // 000000749524: D72C000A
	v_cndmask_b32_e32 v0, v10, v14, vcc_lo                     // 000000749528: 02001D0A
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v15, 0             // 00000074952C: CA100080 140E0080
	v_mov_b32_e32 v14, 0                                       // 000000749534: 7E1C0280
	v_mov_b32_e32 v16, 0                                       // 000000749538: 7E200280
	s_delay_alu instid0(VALU_DEP_4)                            // 00000074953C: BF870004
	v_add3_u32 v30, v10, v19, v9                               // 000000749540: D655001E 0426270A
	s_and_saveexec_b32 s4, s1                                  // 000000749548: BE842001
	s_cbranch_execz 22                                         // 00000074954C: BFA50016 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x4a8>
	v_dual_mov_b32 v20, 0 :: v_dual_lshlrev_b32 v9, 4, v25     // 000000749550: CA220080 14083284
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000749558: BF8700A1
	v_ashrrev_i32_e32 v10, 31, v9                              // 00000074955C: 3414129F
	.long 0xd7006a09                                           // 000000749560: D7006A09
	v_cndmask_b32_e32 v1, v18, v9, vcc_lo                      // 000000749564: 02021312
	v_add_co_ci_u32_e64 v10, null, v30, v10, vcc_lo            // 000000749568: D5207C0A 01AA151E
	s_and_not1_b32 vcc_lo, exec_lo, s16                        // 000000749570: 916A107E
	global_load_b128 v[13:16], v[9:10], off                    // 000000749574: DC5E0000 0D7C0009
	s_cbranch_vccnz 10                                         // 00000074957C: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x4a8>
	v_lshlrev_b32_e32 v9, 1, v25                               // 000000749580: 30123281
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000749584: BF870091
	.long 0xd7006a09                                           // 000000749588: D7006A09
	v_cndmask_b32_e32 v1, v17, v9, vcc_lo                      // 00000074958C: 02021311
	v_add_co_ci_u32_e64 v10, null, 0, v27, vcc_lo              // 000000749590: D5207C0A 01AA3680
	global_load_d16_b16 v9, v[9:10], off                       // 000000749598: DC820000 097C0009
	s_waitcnt vmcnt(0)                                         // 0000007495A0: BF8903F7
	v_cvt_f32_f16_e32 v20, v9                                  // 0000007495A4: 7E281709
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007495A8: 8C7E047E
	v_dual_mov_b32 v32, 0 :: v_dual_mov_b32 v33, 0             // 0000007495AC: CA100080 20200080
	v_mov_b32_e32 v31, 0                                       // 0000007495B4: 7E3E0280
	s_and_saveexec_b32 s14, s1                                 // 0000007495B8: BE8E2001
	s_cbranch_execz 430                                        // 0000007495BC: BFA501AE <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xb78>
	v_dual_mov_b32 v32, 0 :: v_dual_add_nc_u32 v9, 32, v25     // 0000007495C0: CA200080 200832A0
	v_dual_mov_b32 v28, 0 :: v_dual_lshlrev_b32 v19, 5, v25    // 0000007495C8: CA220080 1C123285
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007495D0: BF870002
	v_dual_mov_b32 v33, 0 :: v_dual_lshlrev_b32 v34, 4, v9     // 0000007495D4: CA220080 21221284
	v_mov_b32_e32 v31, 0                                       // 0000007495DC: 7E3E0280
	v_dual_mov_b32 v36, v20 :: v_dual_lshlrev_b32 v35, 1, v9   // 0000007495E0: CA220114 24221281
	s_mul_i32 s1, s11, 6                                       // 0000007495E8: 9601860B
	s_mul_hi_u32 s15, s10, 6                                   // 0000007495EC: 968F860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 0000007495F0: 8484820A
	s_add_i32 s15, s15, s1                                     // 0000007495F4: 810F010F
	s_mul_i32 s17, s10, 6                                      // 0000007495F8: 9611860A
	s_mov_b32 s16, 0                                           // 0000007495FC: BE900080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 000000749600: 848A810A
	s_branch 376                                               // 000000749604: BFA00178 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xae8>
	s_or_b32 exec_lo, exec_lo, s18                             // 000000749608: 8C7E127E
	v_cndmask_b32_e64 v51, v20, v1, s0                         // 00000074960C: D5010033 00020314
	v_cndmask_b32_e64 v37, v1, v2, s0                          // 000000749614: D5010025 00020501
	v_dual_mov_b32 v44, v8 :: v_dual_and_b32 v1, 0xff, v13     // 00000074961C: CA240108 2C001AFF 000000FF
	v_cndmask_b32_e64 v43, v7, v8, s0                          // 000000749628: D501002B 00021107
	v_cndmask_b32_e64 v42, v6, v7, s0                          // 000000749630: D501002A 00020F06
	v_cndmask_b32_e64 v41, v5, v6, s0                          // 000000749638: D5010029 00020D05
	v_cndmask_b32_e64 v40, v4, v5, s0                          // 000000749640: D5010028 00020B04
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000749648: 30020282
	v_cndmask_b32_e64 v39, v3, v4, s0                          // 00000074964C: D5010027 00020903
	v_cndmask_b32_e64 v38, v2, v3, s0                          // 000000749654: D5010026 00020702
	v_ashrrev_i32_e32 v20, 31, v19                             // 00000074965C: 3428269F
	s_and_b32 s1, exec_lo, s1                                  // 000000749660: 8B01017E
	ds_load_b32 v52, v1                                        // 000000749664: D8D80000 34000001
	v_lshrrev_b32_e32 v1, 6, v13                               // 00000074966C: 32021A86
	s_or_b32 s16, s1, s16                                      // 000000749670: 8C101001
	v_add_nc_u32_e32 v34, 0x200, v34                           // 000000749674: 4A4444FF 00000200
	v_add_nc_u32_e32 v35, 64, v35                              // 00000074967C: 4A4646C0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000749680: BF8700B3
	v_and_b32_e32 v1, 0x3fc, v1                                // 000000749684: 360202FF 000003FC
	ds_load_b32 v53, v1                                        // 00000074968C: D8D80000 35000001
	v_lshrrev_b32_e32 v1, 14, v13                              // 000000749694: 32021A8E
	v_and_b32_e32 v1, 0x3fc, v1                                // 000000749698: 360202FF 000003FC
	ds_load_b32 v54, v1                                        // 0000007496A0: D8D80000 36000001
	v_lshrrev_b32_e32 v1, 22, v13                              // 0000007496A8: 32021A96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007496AC: BF8700B1
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000007496B0: 360202FF 000003FC
	ds_load_b32 v55, v1                                        // 0000007496B8: D8D80000 37000001
	v_and_b32_e32 v1, 0xff, v14                                // 0000007496C0: 36021CFF 000000FF
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000007496C8: 30020282
	ds_load_b32 v56, v1                                        // 0000007496CC: D8D80000 38000001
	v_lshrrev_b32_e32 v1, 6, v14                               // 0000007496D4: 32021C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007496D8: BF8700B1
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000007496DC: 360202FF 000003FC
	ds_load_b32 v57, v1                                        // 0000007496E4: D8D80000 39000001
	v_lshrrev_b32_e32 v1, 14, v14                              // 0000007496EC: 32021C8E
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000007496F0: 360202FF 000003FC
	ds_load_b32 v58, v1                                        // 0000007496F8: D8D80000 3A000001
	v_lshrrev_b32_e32 v1, 22, v14                              // 000000749700: 32021C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000749704: BF8700B1
	v_and_b32_e32 v1, 0x3fc, v1                                // 000000749708: 360202FF 000003FC
	ds_load_b32 v59, v1                                        // 000000749710: D8D80000 3B000001
	v_and_b32_e32 v1, 0xff, v15                                // 000000749718: 36021EFF 000000FF
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000749720: 30020282
	ds_load_b32 v60, v1                                        // 000000749724: D8D80000 3C000001
	v_lshrrev_b32_e32 v1, 6, v15                               // 00000074972C: 32021E86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000749730: BF8700B1
	v_and_b32_e32 v1, 0x3fc, v1                                // 000000749734: 360202FF 000003FC
	ds_load_b32 v61, v1                                        // 00000074973C: D8D80000 3D000001
	v_lshrrev_b32_e32 v1, 14, v15                              // 000000749744: 32021E8E
	v_and_b32_e32 v1, 0x3fc, v1                                // 000000749748: 360202FF 000003FC
	ds_load_b32 v62, v1                                        // 000000749750: D8D80000 3E000001
	v_lshrrev_b32_e32 v1, 22, v15                              // 000000749758: 32021E96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000074975C: BF8700B1
	v_and_b32_e32 v1, 0x3fc, v1                                // 000000749760: 360202FF 000003FC
	ds_load_b32 v63, v1                                        // 000000749768: D8D80000 3F000001
	v_and_b32_e32 v1, 0xff, v16                                // 000000749770: 360220FF 000000FF
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000749778: 30020282
	ds_load_b32 v64, v1                                        // 00000074977C: D8D80000 40000001
	v_lshrrev_b32_e32 v1, 6, v16                               // 000000749784: 32022086
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000749788: BF8700B1
	v_and_b32_e32 v1, 0x3fc, v1                                // 00000074978C: 360202FF 000003FC
	ds_load_b32 v65, v1                                        // 000000749794: D8D80000 41000001
	v_lshrrev_b32_e32 v1, 14, v16                              // 00000074979C: 3202208E
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000007497A0: 360202FF 000003FC
	ds_load_b32 v66, v1                                        // 0000007497A8: D8D80000 42000001
	v_lshrrev_b32_e32 v1, 22, v16                              // 0000007497B0: 32022096
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000007497B4: BF870141
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000007497B8: 360202FF 000003FC
	ds_load_b32 v67, v1                                        // 0000007497C0: D8D80000 43000001
	.long 0xd73c0001                                           // 0000007497C8: D73C0001
	v_cndmask_b32_e32 v1, 1, v19, vcc_lo                       // 0000007497CC: 02022681
	v_dual_mov_b32 v20, v36 :: v_dual_add_nc_u32 v19, 0x400, v19// 0000007497D0: CA200124 141226FF 00000400
	.long 0xd7006a31                                           // 0000007497DC: D7006A31
	v_cndmask_b32_e32 v1, s6, v1, vcc_lo                       // 0000007497E0: 02020206
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007497E4: BF870001
	v_add_co_ci_u32_e64 v50, null, s7, v2, vcc_lo              // 0000007497E8: D5207C32 01AA0407
	s_clause 0x3                                               // 0000007497F0: BF850003
	global_load_b128 v[1:4], v[49:50], off                     // 0000007497F4: DC5E0000 017C0031
	global_load_b128 v[5:8], v[49:50], off offset:16           // 0000007497FC: DC5E0010 057C0031
	global_load_b128 v[13:16], v[49:50], off offset:32         // 000000749804: DC5E0020 0D7C0031
	global_load_b128 v[45:48], v[49:50], off offset:48         // 00000074980C: DC5E0030 2D7C0031
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 000000749814: BF890CF7
	v_dot2_f32_bf16 v1, v1, v52, 0                             // 000000749818: CC1A4001 1A026901
	s_waitcnt lgkmcnt(14)                                      // 000000749820: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000749824: BF8700A1
	v_dot2_f32_bf16 v1, v2, v53, v1                            // 000000749828: CC1A4001 1C066B02
	s_waitcnt lgkmcnt(13)                                      // 000000749830: BF89FCD7
	v_dot2_f32_bf16 v1, v3, v54, v1                            // 000000749834: CC1A4001 1C066D03
	s_waitcnt lgkmcnt(12)                                      // 00000074983C: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000749840: BF8700A1
	v_dot2_f32_bf16 v1, v4, v55, v1                            // 000000749844: CC1A4001 1C066F04
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 00000074984C: BF8908B7
	v_dot2_f32_bf16 v1, v5, v56, v1                            // 000000749850: CC1A4001 1C067105
	s_waitcnt lgkmcnt(10)                                      // 000000749858: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000074985C: BF8700A1
	v_dot2_f32_bf16 v1, v6, v57, v1                            // 000000749860: CC1A4001 1C067306
	s_waitcnt lgkmcnt(9)                                       // 000000749868: BF89FC97
	v_dot2_f32_bf16 v1, v7, v58, v1                            // 00000074986C: CC1A4001 1C067507
	s_waitcnt lgkmcnt(8)                                       // 000000749874: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000749878: BF8700A1
	v_dot2_f32_bf16 v1, v8, v59, v1                            // 00000074987C: CC1A4001 1C067708
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 000000749884: BF890477
	v_dot2_f32_bf16 v1, v13, v60, v1                           // 000000749888: CC1A4001 1C06790D
	s_waitcnt lgkmcnt(6)                                       // 000000749890: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000749894: BF8700A1
	v_dot2_f32_bf16 v1, v14, v61, v1                           // 000000749898: CC1A4001 1C067B0E
	s_waitcnt lgkmcnt(5)                                       // 0000007498A0: BF89FC57
	v_dot2_f32_bf16 v1, v15, v62, v1                           // 0000007498A4: CC1A4001 1C067D0F
	s_waitcnt lgkmcnt(4)                                       // 0000007498AC: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007498B0: BF8700A1
	v_dot2_f32_bf16 v1, v16, v63, v1                           // 0000007498B4: CC1A4001 1C067F10
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 0000007498BC: BF890037
	v_dot2_f32_bf16 v1, v45, v64, v1                           // 0000007498C0: CC1A4001 1C06812D
	.long 0xd7006a2d                                           // 0000007498C8: D7006A2D
	v_cndmask_b32_e32 v0, v49, v10, vcc_lo                     // 0000007498CC: 02001531
	s_waitcnt lgkmcnt(2)                                       // 0000007498D0: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000007498D4: BF870132
	v_dot2_f32_bf16 v1, v46, v65, v1                           // 0000007498D8: CC1A4001 1C06832E
	v_add_co_ci_u32_e64 v46, null, s11, v50, vcc_lo            // 0000007498E0: D5207C2E 01AA640B
	s_waitcnt lgkmcnt(1)                                       // 0000007498E8: BF89FC17
	v_dot2_f32_bf16 v1, v47, v66, v1                           // 0000007498EC: CC1A4001 1C06852F
	s_waitcnt lgkmcnt(0)                                       // 0000007498F4: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007498F8: BF870091
	v_dot2_f32_bf16 v1, v48, v67, v1                           // 0000007498FC: CC1A4001 1C068730
	v_fmac_f32_e32 v31, v51, v1                                // 000000749904: 563E0333
	s_clause 0x3                                               // 000000749908: BF850003
	global_load_b128 v[1:4], v[45:46], off                     // 00000074990C: DC5E0000 017C002D
	global_load_b128 v[5:8], v[45:46], off offset:16           // 000000749914: DC5E0010 057C002D
	global_load_b128 v[13:16], v[45:46], off offset:32         // 00000074991C: DC5E0020 0D7C002D
	global_load_b128 v[45:48], v[45:46], off offset:48         // 000000749924: DC5E0030 2D7C002D
	s_waitcnt vmcnt(3)                                         // 00000074992C: BF890FF7
	v_dot2_f32_bf16 v1, v1, v52, 0                             // 000000749930: CC1A4001 1A026901
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000749938: BF870091
	v_dot2_f32_bf16 v1, v2, v53, v1                            // 00000074993C: CC1A4001 1C066B02
	v_dot2_f32_bf16 v1, v3, v54, v1                            // 000000749944: CC1A4001 1C066D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000074994C: BF8700A1
	v_dot2_f32_bf16 v1, v4, v55, v1                            // 000000749950: CC1A4001 1C066F04
	s_waitcnt vmcnt(2)                                         // 000000749958: BF890BF7
	v_dot2_f32_bf16 v1, v5, v56, v1                            // 00000074995C: CC1A4001 1C067105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000749964: BF870091
	v_dot2_f32_bf16 v1, v6, v57, v1                            // 000000749968: CC1A4001 1C067306
	v_dot2_f32_bf16 v1, v7, v58, v1                            // 000000749970: CC1A4001 1C067507
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000749978: BF8700A1
	v_dot2_f32_bf16 v1, v8, v59, v1                            // 00000074997C: CC1A4001 1C067708
	s_waitcnt vmcnt(1)                                         // 000000749984: BF8907F7
	v_dot2_f32_bf16 v1, v13, v60, v1                           // 000000749988: CC1A4001 1C06790D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000749990: BF870091
	v_dot2_f32_bf16 v1, v14, v61, v1                           // 000000749994: CC1A4001 1C067B0E
	v_dot2_f32_bf16 v1, v15, v62, v1                           // 00000074999C: CC1A4001 1C067D0F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007499A4: BF8700A1
	v_dot2_f32_bf16 v1, v16, v63, v1                           // 0000007499A8: CC1A4001 1C067F10
	s_waitcnt vmcnt(0)                                         // 0000007499B0: BF8903F7
	v_dot2_f32_bf16 v1, v45, v64, v1                           // 0000007499B4: CC1A4001 1C06812D
	.long 0xd7006a2d                                           // 0000007499BC: D7006A2D
	v_cndmask_b32_e32 v0, v49, v4, vcc_lo                      // 0000007499C0: 02000931
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007499C4: BF870122
	v_dot2_f32_bf16 v1, v46, v65, v1                           // 0000007499C8: CC1A4001 1C06832E
	v_add_co_ci_u32_e64 v46, null, s5, v50, vcc_lo             // 0000007499D0: D5207C2E 01AA6405
	v_dot2_f32_bf16 v1, v47, v66, v1                           // 0000007499D8: CC1A4001 1C06852F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007499E0: BF870091
	v_dot2_f32_bf16 v1, v48, v67, v1                           // 0000007499E4: CC1A4001 1C068730
	v_fmac_f32_e32 v33, v51, v1                                // 0000007499EC: 56420333
	s_clause 0x3                                               // 0000007499F0: BF850003
	global_load_b128 v[1:4], v[45:46], off                     // 0000007499F4: DC5E0000 017C002D
	global_load_b128 v[5:8], v[45:46], off offset:16           // 0000007499FC: DC5E0010 057C002D
	global_load_b128 v[13:16], v[45:46], off offset:32         // 000000749A04: DC5E0020 0D7C002D
	global_load_b128 v[45:48], v[45:46], off offset:48         // 000000749A0C: DC5E0030 2D7C002D
	s_waitcnt vmcnt(3)                                         // 000000749A14: BF890FF7
	v_dot2_f32_bf16 v1, v1, v52, 0                             // 000000749A18: CC1A4001 1A026901
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000749A20: BF870091
	v_dot2_f32_bf16 v1, v2, v53, v1                            // 000000749A24: CC1A4001 1C066B02
	v_dot2_f32_bf16 v1, v3, v54, v1                            // 000000749A2C: CC1A4001 1C066D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000749A34: BF8700A1
	v_dot2_f32_bf16 v1, v4, v55, v1                            // 000000749A38: CC1A4001 1C066F04
	s_waitcnt vmcnt(2)                                         // 000000749A40: BF890BF7
	v_dot2_f32_bf16 v1, v5, v56, v1                            // 000000749A44: CC1A4001 1C067105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000749A4C: BF870091
	v_dot2_f32_bf16 v1, v6, v57, v1                            // 000000749A50: CC1A4001 1C067306
	v_dot2_f32_bf16 v1, v7, v58, v1                            // 000000749A58: CC1A4001 1C067507
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000749A60: BF8700A1
	v_dot2_f32_bf16 v1, v8, v59, v1                            // 000000749A64: CC1A4001 1C067708
	s_waitcnt vmcnt(1)                                         // 000000749A6C: BF8907F7
	v_dot2_f32_bf16 v1, v13, v60, v1                           // 000000749A70: CC1A4001 1C06790D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000749A78: BF870091
	v_dot2_f32_bf16 v1, v14, v61, v1                           // 000000749A7C: CC1A4001 1C067B0E
	v_dot2_f32_bf16 v1, v15, v62, v1                           // 000000749A84: CC1A4001 1C067D0F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000749A8C: BF8700A1
	v_dot2_f32_bf16 v1, v16, v63, v1                           // 000000749A90: CC1A4001 1C067F10
	s_waitcnt vmcnt(0)                                         // 000000749A98: BF8903F7
	v_dot2_f32_bf16 v1, v45, v64, v1                           // 000000749A9C: CC1A4001 1C06812D
	.long 0xd7006a2d                                           // 000000749AA4: D7006A2D
	v_cndmask_b32_e32 v0, v49, v17, vcc_lo                     // 000000749AA8: 02002331
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000749AAC: BF870122
	v_dot2_f32_bf16 v1, v46, v65, v1                           // 000000749AB0: CC1A4001 1C06832E
	v_add_co_ci_u32_e64 v46, null, s15, v50, vcc_lo            // 000000749AB8: D5207C2E 01AA640F
	v_dot2_f32_bf16 v1, v47, v66, v1                           // 000000749AC0: CC1A4001 1C06852F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000749AC8: BF870091
	v_dot2_f32_bf16 v1, v48, v67, v1                           // 000000749ACC: CC1A4001 1C068730
	v_fmac_f32_e32 v32, v51, v1                                // 000000749AD4: 56400333
	s_clause 0x3                                               // 000000749AD8: BF850003
	global_load_b128 v[1:4], v[45:46], off                     // 000000749ADC: DC5E0000 017C002D
	global_load_b128 v[5:8], v[45:46], off offset:16           // 000000749AE4: DC5E0010 057C002D
	global_load_b128 v[13:16], v[45:46], off offset:32         // 000000749AEC: DC5E0020 0D7C002D
	global_load_b128 v[45:48], v[45:46], off offset:48         // 000000749AF4: DC5E0030 2D7C002D
	s_waitcnt vmcnt(3)                                         // 000000749AFC: BF890FF7
	v_dot2_f32_bf16 v1, v1, v52, 0                             // 000000749B00: CC1A4001 1A026901
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000749B08: BF870091
	v_dot2_f32_bf16 v1, v2, v53, v1                            // 000000749B0C: CC1A4001 1C066B02
	v_dot2_f32_bf16 v1, v3, v54, v1                            // 000000749B14: CC1A4001 1C066D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000749B1C: BF8700A1
	v_dot2_f32_bf16 v1, v4, v55, v1                            // 000000749B20: CC1A4001 1C066F04
	s_waitcnt vmcnt(2)                                         // 000000749B28: BF890BF7
	v_dot2_f32_bf16 v1, v5, v56, v1                            // 000000749B2C: CC1A4001 1C067105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000749B34: BF870091
	v_dot2_f32_bf16 v1, v6, v57, v1                            // 000000749B38: CC1A4001 1C067306
	v_dot2_f32_bf16 v1, v7, v58, v1                            // 000000749B40: CC1A4001 1C067507
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000749B48: BF8700A1
	v_dot2_f32_bf16 v1, v8, v59, v1                            // 000000749B4C: CC1A4001 1C067708
	s_waitcnt vmcnt(1)                                         // 000000749B54: BF8907F7
	v_dot2_f32_bf16 v1, v13, v60, v1                           // 000000749B58: CC1A4001 1C06790D
	v_mov_b32_e32 v13, v9                                      // 000000749B60: 7E1A0309
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000749B64: BF870122
	v_dot2_f32_bf16 v1, v14, v61, v1                           // 000000749B68: CC1A4001 1C067B0E
	v_mov_b32_e32 v14, v10                                     // 000000749B70: 7E1C030A
	v_dot2_f32_bf16 v1, v15, v62, v1                           // 000000749B74: CC1A4001 1C067D0F
	v_mov_b32_e32 v15, v11                                     // 000000749B7C: 7E1E030B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000749B80: BF870132
	v_dot2_f32_bf16 v1, v16, v63, v1                           // 000000749B84: CC1A4001 1C067F10
	v_mov_b32_e32 v16, v12                                     // 000000749B8C: 7E20030C
	s_waitcnt vmcnt(0)                                         // 000000749B90: BF8903F7
	v_dot2_f32_bf16 v1, v45, v64, v1                           // 000000749B94: CC1A4001 1C06812D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000749B9C: BF870091
	v_dot2_f32_bf16 v1, v46, v65, v1                           // 000000749BA0: CC1A4001 1C06832E
	v_dot2_f32_bf16 v1, v47, v66, v1                           // 000000749BA8: CC1A4001 1C06852F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000749BB0: BF870091
	v_dot2_f32_bf16 v1, v48, v67, v1                           // 000000749BB4: CC1A4001 1C068730
	v_dual_fmac_f32 v28, v51, v1 :: v_dual_mov_b32 v1, v37     // 000000749BBC: C8100333 1C000125
	v_dual_mov_b32 v2, v38 :: v_dual_mov_b32 v3, v39           // 000000749BC4: CA100126 02020127
	v_dual_mov_b32 v4, v40 :: v_dual_mov_b32 v5, v41           // 000000749BCC: CA100128 04040129
	v_dual_mov_b32 v6, v42 :: v_dual_mov_b32 v7, v43           // 000000749BD4: CA10012A 0606012B
	v_mov_b32_e32 v8, v44                                      // 000000749BDC: 7E10032C
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 000000749BE0: 917E107E
	s_cbranch_execz 35                                         // 000000749BE4: BFA50023 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xb74>
	s_waitcnt vmcnt(0)                                         // 000000749BE8: BF8903F7
	v_dual_mov_b32 v10, v14 :: v_dual_add_nc_u32 v25, 32, v25  // 000000749BEC: CA20010E 0A1832A0
	v_dual_mov_b32 v9, v13 :: v_dual_mov_b32 v12, v16          // 000000749BF4: CA10010D 090C0110
	v_mov_b32_e32 v11, v15                                     // 000000749BFC: 7E16030F
	s_delay_alu instid0(VALU_DEP_3)                            // 000000749C00: BF870003
	.long 0xd4460001                                           // 000000749C04: D4460001
	v_cndmask_b32_e32 v1, v25, v26, vcc_lo                     // 000000749C08: 02023519
	s_mov_b32 s18, exec_lo                                     // 000000749C0C: BE92007E
	.long 0xd4c1007e                                           // 000000749C10: D4C1007E
	v_cndmask_b32_e32 v1, v25, v26, vcc_lo                     // 000000749C14: 02023519
	s_cbranch_execz 65147                                      // 000000749C18: BFA5FE7B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x508>
	v_ashrrev_i32_e32 v10, 31, v34                             // 000000749C1C: 3414449F
	.long 0xd7006a09                                           // 000000749C20: D7006A09
	v_cndmask_b32_e32 v1, v18, v34, vcc_lo                     // 000000749C24: 02024512
	v_mov_b32_e32 v36, v20                                     // 000000749C28: 7E480314
	s_delay_alu instid0(VALU_DEP_3)                            // 000000749C2C: BF870003
	v_add_co_ci_u32_e64 v10, null, v30, v10, vcc_lo            // 000000749C30: D5207C0A 01AA151E
	v_cmp_ne_u32_e32 vcc_lo, 1, v29                            // 000000749C38: 7C9A3A81
	global_load_b128 v[9:12], v[9:10], off                     // 000000749C3C: DC5E0000 097C0009
	s_cbranch_vccnz 65136                                      // 000000749C44: BFA4FE70 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x508>
	v_ashrrev_i32_e32 v37, 31, v35                             // 000000749C48: 344A469F
	.long 0xd7006a24                                           // 000000749C4C: D7006A24
	v_cndmask_b32_e32 v1, v17, v35, vcc_lo                     // 000000749C50: 02024711
	s_delay_alu instid0(VALU_DEP_1)                            // 000000749C54: BF870001
	v_add_co_ci_u32_e64 v37, null, v27, v37, vcc_lo            // 000000749C58: D5207C25 01AA4B1B
	global_load_d16_b16 v36, v[36:37], off                     // 000000749C60: DC820000 247C0024
	s_waitcnt vmcnt(0)                                         // 000000749C68: BF8903F7
	v_cvt_f32_f16_e32 v36, v36                                 // 000000749C6C: 7E481724
	s_branch 65125                                             // 000000749C70: BFA0FE65 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x508>
	s_or_b32 exec_lo, exec_lo, s16                             // 000000749C74: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000749C78: BF8700B9
	s_or_b32 exec_lo, exec_lo, s14                             // 000000749C7C: 8C7E0E7E
	.long 0xd71f0001                                           // 000000749C80: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000749C84: 020100C1
	s_mov_b32 s0, exec_lo                                      // 000000749C88: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 000000749C8C: 3A040290
	v_xor_b32_e32 v6, 8, v1                                    // 000000749C90: 3A0C0288
	v_xor_b32_e32 v10, 4, v1                                   // 000000749C94: 3A140284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000749C98: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 000000749C9C: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 000000749CA0: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 000000749CA4: 7C980CA0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000749CA8: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 000000749CAC: 30040482
	ds_bpermute_b32 v5, v2, v32                                // 000000749CB0: DACC0000 05002002
	s_waitcnt lgkmcnt(0)                                       // 000000749CB8: BF89FC07
	v_add_f32_e32 v5, v32, v5                                  // 000000749CBC: 060A0B20
	ds_bpermute_b32 v3, v2, v31                                // 000000749CC0: DACC0000 03001F02
	ds_bpermute_b32 v4, v2, v33                                // 000000749CC8: DACC0000 04002102
	ds_bpermute_b32 v2, v2, v28                                // 000000749CD0: DACC0000 02001C02
	s_waitcnt lgkmcnt(2)                                       // 000000749CD8: BF89FC27
	v_dual_add_f32 v3, v31, v3 :: v_dual_cndmask_b32 v6, v1, v6// 000000749CDC: C912071F 03060D01
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 000000749CE4: 7C9814A0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000749CE8: BF870002
	v_lshlrev_b32_e32 v6, 2, v6                                // 000000749CEC: 300C0C82
	v_cndmask_b32_e32 v10, v1, v10, vcc_lo                     // 000000749CF0: 02141501
	ds_bpermute_b32 v9, v6, v5                                 // 000000749CF4: DACC0000 09000506
	s_waitcnt lgkmcnt(0)                                       // 000000749CFC: BF89FC07
	v_dual_add_f32 v5, v5, v9 :: v_dual_lshlrev_b32 v10, 2, v10// 000000749D00: C9221305 050A1482
	ds_bpermute_b32 v7, v6, v3                                 // 000000749D08: DACC0000 07000306
	s_waitcnt lgkmcnt(0)                                       // 000000749D10: BF89FC07
	v_dual_add_f32 v2, v28, v2 :: v_dual_add_f32 v3, v3, v7    // 000000749D14: C908051C 02020F03
	v_add_f32_e32 v4, v33, v4                                  // 000000749D1C: 06080921
	ds_bpermute_b32 v8, v6, v4                                 // 000000749D20: DACC0000 08000406
	ds_bpermute_b32 v6, v6, v2                                 // 000000749D28: DACC0000 06000206
	s_waitcnt lgkmcnt(0)                                       // 000000749D30: BF89FC07
	v_add_f32_e32 v2, v2, v6                                   // 000000749D34: 06040D02
	ds_bpermute_b32 v6, v10, v3                                // 000000749D38: DACC0000 0600030A
	ds_bpermute_b32 v9, v10, v2                                // 000000749D40: DACC0000 0900020A
	s_waitcnt lgkmcnt(1)                                       // 000000749D48: BF89FC17
	v_dual_add_f32 v3, v3, v6 :: v_dual_add_f32 v4, v4, v8     // 000000749D4C: C9080D03 03041104
	ds_bpermute_b32 v8, v10, v5                                // 000000749D54: DACC0000 0800050A
	s_waitcnt lgkmcnt(1)                                       // 000000749D5C: BF89FC17
	v_add_f32_e32 v6, v2, v9                                   // 000000749D60: 060C1302
	ds_bpermute_b32 v7, v10, v4                                // 000000749D64: DACC0000 0700040A
	v_xor_b32_e32 v10, 2, v1                                   // 000000749D6C: 3A140282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000749D70: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 000000749D74: 7C9814A0
	v_cndmask_b32_e32 v10, v1, v10, vcc_lo                     // 000000749D78: 02141501
	s_waitcnt lgkmcnt(1)                                       // 000000749D7C: BF89FC17
	v_dual_add_f32 v5, v5, v8 :: v_dual_lshlrev_b32 v10, 2, v10// 000000749D80: C9221105 050A1482
	ds_bpermute_b32 v2, v10, v3                                // 000000749D88: DACC0000 0200030A
	s_waitcnt lgkmcnt(1)                                       // 000000749D90: BF89FC17
	v_add_f32_e32 v4, v4, v7                                   // 000000749D94: 06080F04
	ds_bpermute_b32 v8, v10, v5                                // 000000749D98: DACC0000 0800050A
	ds_bpermute_b32 v9, v10, v6                                // 000000749DA0: DACC0000 0900060A
	ds_bpermute_b32 v7, v10, v4                                // 000000749DA8: DACC0000 0700040A
	v_xor_b32_e32 v10, 1, v1                                   // 000000749DB0: 3A140281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000749DB4: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 000000749DB8: 7C9814A0
	v_cndmask_b32_e32 v1, v1, v10, vcc_lo                      // 000000749DBC: 02021501
	s_waitcnt lgkmcnt(3)                                       // 000000749DC0: BF89FC37
	v_dual_add_f32 v1, v3, v2 :: v_dual_lshlrev_b32 v10, 2, v1 // 000000749DC4: C9220503 010A0282
	s_waitcnt lgkmcnt(2)                                       // 000000749DCC: BF89FC27
	v_add_f32_e32 v3, v5, v8                                   // 000000749DD0: 06061105
	s_waitcnt lgkmcnt(0)                                       // 000000749DD4: BF89FC07
	v_dual_add_f32 v5, v6, v9 :: v_dual_add_f32 v2, v4, v7     // 000000749DD8: C9081306 05020F04
	ds_bpermute_b32 v4, v10, v1                                // 000000749DE0: DACC0000 0400010A
	ds_bpermute_b32 v7, v10, v3                                // 000000749DE8: DACC0000 0700030A
	ds_bpermute_b32 v8, v10, v5                                // 000000749DF0: DACC0000 0800050A
	ds_bpermute_b32 v6, v10, v2                                // 000000749DF8: DACC0000 0600020A
	v_cmpx_eq_u32_e32 0, v24                                   // 000000749E00: 7D943080
	s_cbranch_execz 12                                         // 000000749E04: BFA5000C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xd38>
	s_waitcnt lgkmcnt(1)                                       // 000000749E08: BF89FC17
	v_dual_add_f32 v8, v5, v8 :: v_dual_lshlrev_b32 v9, 4, v23 // 000000749E0C: C9221105 08082E84
	s_waitcnt lgkmcnt(0)                                       // 000000749E14: BF89FC07
	v_dual_add_f32 v7, v3, v7 :: v_dual_add_f32 v6, v2, v6     // 000000749E18: C9080F03 07060D02
	v_add_f32_e32 v5, v1, v4                                   // 000000749E20: 060A0901
	s_delay_alu instid0(VALU_DEP_3)                            // 000000749E24: BF870003
	v_lshl_or_b32 v1, v22, 5, v9                               // 000000749E28: D6560001 04250B16
	ds_store_b128 v1, v[5:8] offset:1024                       // 000000749E30: DB7C0400 00000501
	s_or_b32 exec_lo, exec_lo, s0                              // 000000749E38: 8C7E007E
	v_or_b32_e32 v1, s2, v21                                   // 000000749E3C: 38022A02
	v_mov_b32_e32 v2, s3                                       // 000000749E40: 7E040203
	.long 0xd44c0000                                           // 000000749E44: D44C0000
	v_cndmask_b32_e32 v1, 16, v0, vcc_lo                       // 000000749E48: 02020090
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000749E4C: BF890007
	s_barrier                                                  // 000000749E50: BFBD0000
	buffer_gl0_inv                                             // 000000749E54: E0AC0000 00000000
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 000000749E5C: 7CA8020C
	s_and_b32 s0, s0, vcc_lo                                   // 000000749E60: 8B006A00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000749E64: BF870009
	s_and_saveexec_b32 s1, s0                                  // 000000749E68: BE812000
	s_cbranch_execz 34                                         // 000000749E6C: BFA50022 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xdf8>
	v_and_b32_e32 v0, 3, v0                                    // 000000749E70: 36000083
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000749E74: BF870091
	v_lshlrev_b32_e32 v3, 2, v0                                // 000000749E78: 30060082
	v_lshl_or_b32 v3, v21, 5, v3                               // 000000749E7C: D6560003 040D0B15
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000749E84: BF870151
	v_add_nc_u32_e32 v5, 0x400, v3                             // 000000749E88: 4A0A06FF 00000400
	v_mad_u64_u32 v[3:4], null, s12, v0, 0                     // 000000749E90: D6FE7C03 0202000C
	ds_load_2addr_b32 v[6:7], v5 offset1:4                     // 000000749E98: D8DC0400 06000005
	v_mad_u64_u32 v[4:5], null, s13, v0, v[4:5]                // 000000749EA0: D6FE7C04 0412000D
	.long 0xd73c0000                                           // 000000749EA8: D73C0000
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000749EAC: 02020282
	.long 0xd73c0003                                           // 000000749EB0: D73C0003
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 000000749EB4: 02020682
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000749EB8: BF8701B1
	.long 0xd7006a03                                           // 000000749EBC: D7006A03
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 000000749EC0: 02020608
	s_waitcnt lgkmcnt(0)                                       // 000000749EC4: BF89FC07
	v_add_f32_e32 v2, 0, v6                                    // 000000749EC8: 06040C80
	v_add_co_ci_u32_e64 v4, null, s9, v4, vcc_lo               // 000000749ECC: D5207C04 01AA0809
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000749ED4: BF870193
	.long 0xd7006a00                                           // 000000749ED8: D7006A00
	v_cndmask_b32_e32 v1, v3, v0, vcc_lo                       // 000000749EDC: 02020103
	v_add_f32_e32 v2, v2, v7                                   // 000000749EE0: 06040F02
	s_delay_alu instid0(VALU_DEP_3)                            // 000000749EE4: BF870003
	v_add_co_ci_u32_e64 v1, null, v4, v1, vcc_lo               // 000000749EE8: D5207C01 01AA0304
	global_store_b32 v[0:1], v2, off                           // 000000749EF0: DC6A0000 007C0200
	s_endpgm                                                   // 000000749EF8: BFB00000
	v_illegal                                                  // 000000749EFC: 00000000

