000000000075e800 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 00000075E800: F4100100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 00000075E808: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 00000075E80C: 32040082
	s_lshl_b64 s[2:3], s[2:3], 2                               // 00000075E810: 84828202
	v_and_b32_e32 v1, 15, v0                                   // 00000075E814: 3602008F
	v_lshrrev_b32_e32 v28, 6, v0                               // 00000075E818: 32380086
	v_bfe_u32 v29, v0, 5, 1                                    // 00000075E81C: D610001D 02050B00
	v_and_b32_e32 v2, 60, v2                                   // 00000075E824: 360404BC
	v_and_b32_e32 v30, 31, v0                                  // 00000075E828: 363C009F
	v_lshlrev_b32_e32 v1, 2, v1                                // 00000075E82C: 30020282
	.long 0x7f0a3880                                           // 00000075E830: 7F0A3880
	v_lshlrev_b32_e32 v6, 2, v0                                // 00000075E834: 300C0082
	s_waitcnt lgkmcnt(0)                                       // 00000075E838: BF89FC07
	s_clause 0x1                                               // 00000075E83C: BF850001
	global_load_b32 v3, v1, s[4:5]                             // 00000075E840: DC520000 03040001
	global_load_b32 v4, v2, s[4:5]                             // 00000075E848: DC520000 04040002
	s_add_u32 s0, s4, s16                                      // 00000075E850: 80001004
	s_addc_u32 s1, s5, s17                                     // 00000075E854: 82011105
	s_ashr_i32 s16, s11, 31                                    // 00000075E858: 86109F0B
	v_mov_b32_e32 v2, s3                                       // 00000075E85C: 7E040203
	s_lshr_b32 s16, s16, 27                                    // 00000075E860: 85109B10
	v_or_b32_e32 v1, s2, v28                                   // 00000075E864: 38023802
	s_add_u32 s16, s10, s16                                    // 00000075E868: 8010100A
	s_addc_u32 s17, s11, 0                                     // 00000075E86C: 8211800B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075E870: BF870099
	s_lshr_b64 s[16:17], s[16:17], 5                           // 00000075E874: 85908510
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 00000075E878: 7CA8020C
	s_add_i32 s17, s16, 1                                      // 00000075E87C: 81118110
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000075E880: BF870499
	s_lshr_b32 s20, s17, 31                                    // 00000075E884: 85149F11
	s_add_i32 s17, s17, s20                                    // 00000075E888: 81111411
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000075E88C: 02020280
	s_ashr_i32 s17, s17, 1                                     // 00000075E890: 86118111
	v_cndmask_b32_e64 v2, 0, s3, vcc_lo                        // 00000075E894: D5010002 01A80680
	.long 0xd72c0007                                           // 00000075E89C: D72C0007
	v_cndmask_b32_e32 v1, s17, v29, vcc_lo                     // 00000075E8A0: 02023A11
	s_cmpk_lt_i32 s16, 0x201                                   // 00000075E8A4: B3900201
	.long 0xd72c0009                                           // 00000075E8A8: D72C0009
	v_cndmask_b32_e32 v1, s19, v1, vcc_lo                      // 00000075E8AC: 02020213
	v_mad_u64_u32 v[24:25], null, s18, v1, s[0:1]              // 00000075E8B0: D6FE7C18 00020212
	s_cselect_b32 s0, -1, 0                                    // 00000075E8B8: 980080C1
	s_cmpk_gt_i32 s16, 0x200                                   // 00000075E8BC: B2900200
	v_add_nc_u32_e32 v11, s17, v7                              // 00000075E8C0: 4A160E11
	v_add_nc_u32_e32 v31, v7, v30                              // 00000075E8C4: 4A3E3D07
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000075E8C8: BF8704A2
	v_min_i32_e32 v32, s16, v11                                // 00000075E8CC: 22401610
	s_cselect_b32 s16, -1, 0                                   // 00000075E8D0: 981080C1
	s_and_b32 vcc_lo, exec_lo, s16                             // 00000075E8D4: 8B6A107E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 00000075E8D8: BF870151
	.long 0xd4410001                                           // 00000075E8DC: D4410001
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 00000075E8E0: 0202411F
	s_waitcnt vmcnt(1)                                         // 00000075E8E4: BF8907F7
	v_bfe_u32 v8, v3, 16, 1                                    // 00000075E8E8: D6100008 02052103
	s_waitcnt vmcnt(0)                                         // 00000075E8F0: BF8903F7
	v_bfe_u32 v10, v4, 16, 1                                   // 00000075E8F4: D610000A 02052104
	v_add3_u32 v3, v3, v8, 0x7fff                              // 00000075E8FC: D6550003 03FE1103 00007FFF
	.long 0xd72c0008                                           // 00000075E908: D72C0008
	v_cndmask_b32_e32 v1, s18, v2, vcc_lo                      // 00000075E90C: 02020412
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000075E910: BF870193
	v_add3_u32 v4, v4, v10, 0x7fff                             // 00000075E914: D6550004 03FE1504 00007FFF
	.long 0x7e0a3983                                           // 00000075E920: 7E0A3983
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000075E924: BF870113
	v_add3_u32 v33, v9, v25, v8                                // 00000075E928: D6550021 04223309
	v_and_or_b32 v3, 0xffff0000, v4, v5                        // 00000075E930: D6570003 041608FF FFFF0000
	ds_store_b32 v6, v3                                        // 00000075E93C: D8340000 00000306
	s_waitcnt lgkmcnt(0)                                       // 00000075E944: BF89FC07
	s_barrier                                                  // 00000075E948: BFBD0000
	buffer_gl0_inv                                             // 00000075E94C: E0AC0000 00000000
	s_cbranch_vccnz 154                                        // 00000075E954: BFA4009A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x3c0>
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v8, 0               // 00000075E958: CA100080 09080080
	s_and_saveexec_b32 s17, s1                                 // 00000075E960: BE912001
	s_cbranch_execz 11                                         // 00000075E964: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x194>
	v_lshlrev_b32_e32 v3, 1, v31                               // 00000075E968: 30063E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000075E96C: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 00000075E970: 3408069F
	.long 0xd7006a03                                           // 00000075E974: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 00000075E978: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 00000075E97C: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 00000075E984: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 00000075E98C: BF8903F7
	v_cvt_f32_f16_e32 v8, v3                                   // 00000075E990: 7E101703
	s_or_b32 exec_lo, exec_lo, s17                             // 00000075E994: 8C7E117E
	v_add_nc_u32_e32 v3, 32, v31                               // 00000075E998: 4A063EA0
	s_mov_b32 s1, exec_lo                                      // 00000075E99C: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000075E9A0: BF870001
	.long 0xd4c1007e                                           // 00000075E9A4: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 00000075E9A8: 02024103
	s_cbranch_execz 11                                         // 00000075E9AC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x1dc>
	v_lshlrev_b32_e32 v3, 1, v3                                // 00000075E9B0: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000075E9B4: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 00000075E9B8: 3408069F
	.long 0xd7006a03                                           // 00000075E9BC: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 00000075E9C0: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 00000075E9C4: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 00000075E9CC: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 00000075E9D4: BF8903F7
	v_cvt_f32_f16_e32 v9, v3                                   // 00000075E9D8: 7E121703
	s_or_b32 exec_lo, exec_lo, s1                              // 00000075E9DC: 8C7E017E
	v_dual_mov_b32 v10, 0 :: v_dual_add_nc_u32 v3, 64, v31     // 00000075E9E0: CA200080 0A023EC0
	v_mov_b32_e32 v11, 0                                       // 00000075E9E8: 7E160280
	s_mov_b32 s1, exec_lo                                      // 00000075E9EC: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000075E9F0: BF870002
	.long 0xd4c1007e                                           // 00000075E9F4: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 00000075E9F8: 02024103
	s_cbranch_execz 11                                         // 00000075E9FC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x22c>
	v_lshlrev_b32_e32 v3, 1, v3                                // 00000075EA00: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000075EA04: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 00000075EA08: 3408069F
	.long 0xd7006a03                                           // 00000075EA0C: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 00000075EA10: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 00000075EA14: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 00000075EA1C: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 00000075EA24: BF8903F7
	v_cvt_f32_f16_e32 v10, v3                                  // 00000075EA28: 7E141703
	s_or_b32 exec_lo, exec_lo, s1                              // 00000075EA2C: 8C7E017E
	v_add_nc_u32_e32 v3, 0x60, v31                             // 00000075EA30: 4A063EFF 00000060
	s_mov_b32 s1, exec_lo                                      // 00000075EA38: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000075EA3C: BF870001
	.long 0xd4c1007e                                           // 00000075EA40: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 00000075EA44: 02024103
	s_cbranch_execz 11                                         // 00000075EA48: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x278>
	v_lshlrev_b32_e32 v3, 1, v3                                // 00000075EA4C: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000075EA50: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 00000075EA54: 3408069F
	.long 0xd7006a03                                           // 00000075EA58: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 00000075EA5C: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 00000075EA60: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 00000075EA68: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 00000075EA70: BF8903F7
	v_cvt_f32_f16_e32 v11, v3                                  // 00000075EA74: 7E161703
	s_or_b32 exec_lo, exec_lo, s1                              // 00000075EA78: 8C7E017E
	v_dual_mov_b32 v12, 0 :: v_dual_add_nc_u32 v3, 0x80, v31   // 00000075EA7C: CA200080 0C023EFF 00000080
	v_mov_b32_e32 v13, 0                                       // 00000075EA88: 7E1A0280
	s_mov_b32 s1, exec_lo                                      // 00000075EA8C: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000075EA90: BF870002
	.long 0xd4c1007e                                           // 00000075EA94: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 00000075EA98: 02024103
	s_cbranch_execz 11                                         // 00000075EA9C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x2cc>
	v_lshlrev_b32_e32 v3, 1, v3                                // 00000075EAA0: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000075EAA4: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 00000075EAA8: 3408069F
	.long 0xd7006a03                                           // 00000075EAAC: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 00000075EAB0: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 00000075EAB4: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 00000075EABC: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 00000075EAC4: BF8903F7
	v_cvt_f32_f16_e32 v12, v3                                  // 00000075EAC8: 7E181703
	s_or_b32 exec_lo, exec_lo, s1                              // 00000075EACC: 8C7E017E
	v_add_nc_u32_e32 v3, 0xa0, v31                             // 00000075EAD0: 4A063EFF 000000A0
	s_mov_b32 s1, exec_lo                                      // 00000075EAD8: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000075EADC: BF870001
	.long 0xd4c1007e                                           // 00000075EAE0: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 00000075EAE4: 02024103
	s_cbranch_execz 11                                         // 00000075EAE8: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x318>
	v_lshlrev_b32_e32 v3, 1, v3                                // 00000075EAEC: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000075EAF0: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 00000075EAF4: 3408069F
	.long 0xd7006a03                                           // 00000075EAF8: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 00000075EAFC: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 00000075EB00: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 00000075EB08: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 00000075EB10: BF8903F7
	v_cvt_f32_f16_e32 v13, v3                                  // 00000075EB14: 7E1A1703
	s_or_b32 exec_lo, exec_lo, s1                              // 00000075EB18: 8C7E017E
	v_dual_mov_b32 v14, 0 :: v_dual_add_nc_u32 v3, 0xc0, v31   // 00000075EB1C: CA200080 0E023EFF 000000C0
	v_mov_b32_e32 v15, 0                                       // 00000075EB28: 7E1E0280
	s_mov_b32 s1, exec_lo                                      // 00000075EB2C: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000075EB30: BF870002
	.long 0xd4c1007e                                           // 00000075EB34: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 00000075EB38: 02024103
	s_cbranch_execz 11                                         // 00000075EB3C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x36c>
	v_lshlrev_b32_e32 v3, 1, v3                                // 00000075EB40: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000075EB44: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 00000075EB48: 3408069F
	.long 0xd7006a03                                           // 00000075EB4C: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 00000075EB50: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 00000075EB54: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 00000075EB5C: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 00000075EB64: BF8903F7
	v_cvt_f32_f16_e32 v14, v3                                  // 00000075EB68: 7E1C1703
	s_or_b32 exec_lo, exec_lo, s1                              // 00000075EB6C: 8C7E017E
	v_add_nc_u32_e32 v3, 0xe0, v31                             // 00000075EB70: 4A063EFF 000000E0
	s_mov_b32 s1, exec_lo                                      // 00000075EB78: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000075EB7C: BF870001
	.long 0xd4c1007e                                           // 00000075EB80: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 00000075EB84: 02024103
	s_cbranch_execz 11                                         // 00000075EB88: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x3b8>
	v_lshlrev_b32_e32 v3, 1, v3                                // 00000075EB8C: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000075EB90: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 00000075EB94: 3408069F
	.long 0xd7006a03                                           // 00000075EB98: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 00000075EB9C: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 00000075EBA0: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 00000075EBA8: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 00000075EBB0: BF8903F7
	v_cvt_f32_f16_e32 v15, v3                                  // 00000075EBB4: 7E1E1703
	s_or_b32 exec_lo, exec_lo, s1                              // 00000075EBB8: 8C7E017E
	s_branch 9                                                 // 00000075EBBC: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x3e4>
	v_mov_b32_e32 v8, 0                                        // 00000075EBC0: 7E100280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000075EBC4: BF870001
	v_mov_b32_e32 v9, v8                                       // 00000075EBC8: 7E120308
	v_mov_b32_e32 v10, v8                                      // 00000075EBCC: 7E140308
	v_mov_b32_e32 v11, v8                                      // 00000075EBD0: 7E160308
	v_mov_b32_e32 v12, v8                                      // 00000075EBD4: 7E180308
	v_mov_b32_e32 v13, v8                                      // 00000075EBD8: 7E1A0308
	v_mov_b32_e32 v14, v8                                      // 00000075EBDC: 7E1C0308
	v_mov_b32_e32 v15, v8                                      // 00000075EBE0: 7E1E0308
	s_add_u32 s4, s4, s14                                      // 00000075EBE4: 80040E04
	s_addc_u32 s5, s5, s15                                     // 00000075EBE8: 82050F05
	s_lshr_b32 s1, s11, 31                                     // 00000075EBEC: 85019F0B
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v27, 0             // 00000075EBF0: CA100080 141A0080
	s_add_u32 s14, s10, s1                                     // 00000075EBF8: 800E010A
	s_addc_u32 s15, s11, 0                                     // 00000075EBFC: 820F800B
	.long 0xd4410001                                           // 00000075EC00: D4410001
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 00000075EC04: 0202411F
	s_ashr_i64 s[14:15], s[14:15], 1                           // 00000075EC08: 868E810E
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v21, 0             // 00000075EC0C: CA100080 22140080
	v_mad_u64_u32 v[25:26], null, v1, s14, s[4:5]              // 00000075EC14: D6FE7C19 00101D01
	.long 0xd72c0001                                           // 00000075EC1C: D72C0001
	v_cndmask_b32_e32 v0, v1, v15, vcc_lo                      // 00000075EC20: 02001F01
	.long 0xd72c0002                                           // 00000075EC24: D72C0002
	v_cndmask_b32_e32 v0, v2, v14, vcc_lo                      // 00000075EC28: 02001D02
	v_cndmask_b32_e64 v35, 0, 1, s16                           // 00000075EC2C: D5010023 00410280
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v23, 0             // 00000075EC34: CA100080 16160080
	s_delay_alu instid0(VALU_DEP_3)                            // 00000075EC3C: BF870003
	v_add3_u32 v36, v2, v26, v1                                // 00000075EC40: D6550024 04063502
	s_and_saveexec_b32 s4, s1                                  // 00000075EC48: BE842001
	s_cbranch_execz 22                                         // 00000075EC4C: BFA50016 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x4a8>
	v_lshlrev_b32_e32 v1, 4, v31                               // 00000075EC50: 30023E84
	v_mov_b32_e32 v27, 0                                       // 00000075EC54: 7E360280
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000075EC58: BF8700A2
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000075EC5C: 3404029F
	.long 0xd7006a01                                           // 00000075EC60: D7006A01
	v_cndmask_b32_e32 v1, v25, v1, vcc_lo                      // 00000075EC64: 02020319
	v_add_co_ci_u32_e64 v2, null, v36, v2, vcc_lo              // 00000075EC68: D5207C02 01AA0524
	s_and_not1_b32 vcc_lo, exec_lo, s16                        // 00000075EC70: 916A107E
	global_load_b128 v[20:23], v[1:2], off                     // 00000075EC74: DC5E0000 147C0001
	s_cbranch_vccnz 10                                         // 00000075EC7C: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x4a8>
	v_lshlrev_b32_e32 v1, 1, v31                               // 00000075EC80: 30023E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075EC84: BF870091
	.long 0xd7006a01                                           // 00000075EC88: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 00000075EC8C: 02020318
	v_add_co_ci_u32_e64 v2, null, 0, v33, vcc_lo               // 00000075EC90: D5207C02 01AA4280
	global_load_d16_b16 v1, v[1:2], off                        // 00000075EC98: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 00000075ECA0: BF8903F7
	v_cvt_f32_f16_e32 v27, v1                                  // 00000075ECA4: 7E361701
	s_or_b32 exec_lo, exec_lo, s4                              // 00000075ECA8: 8C7E047E
	v_dual_mov_b32 v38, 0 :: v_dual_mov_b32 v39, 0             // 00000075ECAC: CA100080 26260080
	v_dual_mov_b32 v40, 0 :: v_dual_mov_b32 v41, 0             // 00000075ECB4: CA100080 28280080
	v_dual_mov_b32 v42, 0 :: v_dual_mov_b32 v37, 0             // 00000075ECBC: CA100080 2A240080
	s_and_saveexec_b32 s14, s1                                 // 00000075ECC4: BE8E2001
	s_cbranch_execz 610                                        // 00000075ECC8: BFA50262 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xe54>
	v_dual_mov_b32 v42, 0 :: v_dual_add_nc_u32 v1, 32, v31     // 00000075ECCC: CA200080 2A003EA0
	v_dual_mov_b32 v37, 0 :: v_dual_lshlrev_b32 v26, 5, v31    // 00000075ECD4: CA220080 251A3E85
	v_dual_mov_b32 v39, 0 :: v_dual_mov_b32 v38, 0             // 00000075ECDC: CA100080 27260080
	s_delay_alu instid0(VALU_DEP_3)                            // 00000075ECE4: BF870003
	v_dual_mov_b32 v40, 0 :: v_dual_lshlrev_b32 v43, 4, v1     // 00000075ECE8: CA220080 282A0284
	v_dual_mov_b32 v41, 0 :: v_dual_lshlrev_b32 v44, 1, v1     // 00000075ECF0: CA220080 292C0281
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v45, v27           // 00000075ECF8: CA100080 222C011B
	s_mul_i32 s1, s11, 6                                       // 00000075ED00: 9601860B
	s_mul_hi_u32 s15, s10, 6                                   // 00000075ED04: 968F860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 00000075ED08: 8484820A
	s_add_i32 s15, s15, s1                                     // 00000075ED0C: 810F010F
	s_mul_i32 s17, s10, 6                                      // 00000075ED10: 9611860A
	s_mov_b32 s16, 0                                           // 00000075ED14: BE900080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 00000075ED18: 848A810A
	s_branch 553                                               // 00000075ED1C: BFA00229 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xdc4>
	s_or_b32 exec_lo, exec_lo, s18                             // 00000075ED20: 8C7E127E
	v_cndmask_b32_e64 v56, v27, v8, s0                         // 00000075ED24: D5010038 0002111B
	v_cndmask_b32_e64 v2, v9, v10, s0                          // 00000075ED2C: D5010002 00021509
	v_cndmask_b32_e64 v1, v8, v9, s0                           // 00000075ED34: D5010001 00021308
	v_dual_mov_b32 v8, v15 :: v_dual_and_b32 v9, 0xff, v20     // 00000075ED3C: CA24010F 080828FF 000000FF
	v_cndmask_b32_e64 v7, v14, v15, s0                         // 00000075ED48: D5010007 00021F0E
	v_cndmask_b32_e64 v6, v13, v14, s0                         // 00000075ED50: D5010006 00021D0D
	v_cndmask_b32_e64 v5, v12, v13, s0                         // 00000075ED58: D5010005 00021B0C
	v_cndmask_b32_e64 v4, v11, v12, s0                         // 00000075ED60: D5010004 0002190B
	v_lshlrev_b32_e32 v9, 2, v9                                // 00000075ED68: 30121282
	v_cndmask_b32_e64 v3, v10, v11, s0                         // 00000075ED6C: D5010003 0002170A
	v_ashrrev_i32_e32 v27, 31, v26                             // 00000075ED74: 3436349F
	s_and_b32 s1, exec_lo, s1                                  // 00000075ED78: 8B01017E
	v_add_nc_u32_e32 v43, 0x200, v43                           // 00000075ED7C: 4A5656FF 00000200
	ds_load_b32 v15, v9                                        // 00000075ED84: D8D80000 0F000009
	v_lshrrev_b32_e32 v9, 6, v20                               // 00000075ED8C: 32122886
	s_or_b32 s16, s1, s16                                      // 00000075ED90: 8C101001
	v_add_nc_u32_e32 v44, 64, v44                              // 00000075ED94: 4A5858C0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000075ED98: BF8700B2
	v_and_b32_e32 v9, 0x3fc, v9                                // 00000075ED9C: 361212FF 000003FC
	ds_load_b32 v57, v9                                        // 00000075EDA4: D8D80000 39000009
	v_lshrrev_b32_e32 v9, 14, v20                              // 00000075EDAC: 3212288E
	v_and_b32_e32 v9, 0x3fc, v9                                // 00000075EDB0: 361212FF 000003FC
	ds_load_b32 v58, v9                                        // 00000075EDB8: D8D80000 3A000009
	v_lshrrev_b32_e32 v9, 22, v20                              // 00000075EDC0: 32122896
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000075EDC4: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 00000075EDC8: 361212FF 000003FC
	ds_load_b32 v59, v9                                        // 00000075EDD0: D8D80000 3B000009
	v_and_b32_e32 v9, 0xff, v21                                // 00000075EDD8: 36122AFF 000000FF
	v_lshlrev_b32_e32 v9, 2, v9                                // 00000075EDE0: 30121282
	ds_load_b32 v60, v9                                        // 00000075EDE4: D8D80000 3C000009
	v_lshrrev_b32_e32 v9, 6, v21                               // 00000075EDEC: 32122A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000075EDF0: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 00000075EDF4: 361212FF 000003FC
	ds_load_b32 v61, v9                                        // 00000075EDFC: D8D80000 3D000009
	v_lshrrev_b32_e32 v9, 14, v21                              // 00000075EE04: 32122A8E
	v_and_b32_e32 v9, 0x3fc, v9                                // 00000075EE08: 361212FF 000003FC
	ds_load_b32 v62, v9                                        // 00000075EE10: D8D80000 3E000009
	v_lshrrev_b32_e32 v9, 22, v21                              // 00000075EE18: 32122A96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000075EE1C: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 00000075EE20: 361212FF 000003FC
	ds_load_b32 v63, v9                                        // 00000075EE28: D8D80000 3F000009
	v_and_b32_e32 v9, 0xff, v22                                // 00000075EE30: 36122CFF 000000FF
	v_lshlrev_b32_e32 v9, 2, v9                                // 00000075EE38: 30121282
	ds_load_b32 v64, v9                                        // 00000075EE3C: D8D80000 40000009
	v_lshrrev_b32_e32 v9, 6, v22                               // 00000075EE44: 32122C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000075EE48: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 00000075EE4C: 361212FF 000003FC
	ds_load_b32 v65, v9                                        // 00000075EE54: D8D80000 41000009
	v_lshrrev_b32_e32 v9, 14, v22                              // 00000075EE5C: 32122C8E
	v_and_b32_e32 v9, 0x3fc, v9                                // 00000075EE60: 361212FF 000003FC
	ds_load_b32 v66, v9                                        // 00000075EE68: D8D80000 42000009
	v_lshrrev_b32_e32 v9, 22, v22                              // 00000075EE70: 32122C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000075EE74: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 00000075EE78: 361212FF 000003FC
	ds_load_b32 v67, v9                                        // 00000075EE80: D8D80000 43000009
	v_and_b32_e32 v9, 0xff, v23                                // 00000075EE88: 36122EFF 000000FF
	v_lshlrev_b32_e32 v9, 2, v9                                // 00000075EE90: 30121282
	ds_load_b32 v68, v9                                        // 00000075EE94: D8D80000 44000009
	v_lshrrev_b32_e32 v9, 6, v23                               // 00000075EE9C: 32122E86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000075EEA0: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 00000075EEA4: 361212FF 000003FC
	ds_load_b32 v69, v9                                        // 00000075EEAC: D8D80000 45000009
	v_lshrrev_b32_e32 v9, 14, v23                              // 00000075EEB4: 32122E8E
	v_and_b32_e32 v9, 0x3fc, v9                                // 00000075EEB8: 361212FF 000003FC
	ds_load_b32 v70, v9                                        // 00000075EEC0: D8D80000 46000009
	v_lshrrev_b32_e32 v9, 22, v23                              // 00000075EEC8: 32122E96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000075EECC: BF870141
	v_and_b32_e32 v9, 0x3fc, v9                                // 00000075EED0: 361212FF 000003FC
	ds_load_b32 v71, v9                                        // 00000075EED8: D8D80000 47000009
	.long 0xd73c0009                                           // 00000075EEE0: D73C0009
	v_cndmask_b32_e32 v1, 1, v26, vcc_lo                       // 00000075EEE4: 02023481
	v_dual_mov_b32 v27, v45 :: v_dual_add_nc_u32 v26, 0x400, v26// 00000075EEE8: CA20012D 1B1A34FF 00000400
	.long 0xd7006a0d                                           // 00000075EEF4: D7006A0D
	v_cndmask_b32_e32 v1, s6, v9, vcc_lo                       // 00000075EEF8: 02021206
	s_delay_alu instid0(VALU_DEP_1)                            // 00000075EEFC: BF870001
	v_add_co_ci_u32_e64 v14, null, s7, v10, vcc_lo             // 00000075EF00: D5207C0E 01AA1407
	s_clause 0x3                                               // 00000075EF08: BF850003
	global_load_b128 v[9:12], v[13:14], off                    // 00000075EF0C: DC5E0000 097C000D
	global_load_b128 v[20:23], v[13:14], off offset:16         // 00000075EF14: DC5E0010 147C000D
	global_load_b128 v[46:49], v[13:14], off offset:32         // 00000075EF1C: DC5E0020 2E7C000D
	global_load_b128 v[50:53], v[13:14], off offset:48         // 00000075EF24: DC5E0030 327C000D
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 00000075EF2C: BF890CF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 00000075EF30: CC1A4009 1A021F09
	s_waitcnt lgkmcnt(14)                                      // 00000075EF38: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000075EF3C: BF8700A1
	v_dot2_f32_bf16 v9, v10, v57, v9                           // 00000075EF40: CC1A4009 1C26730A
	s_waitcnt lgkmcnt(13)                                      // 00000075EF48: BF89FCD7
	v_dot2_f32_bf16 v9, v11, v58, v9                           // 00000075EF4C: CC1A4009 1C26750B
	s_waitcnt lgkmcnt(12)                                      // 00000075EF54: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000075EF58: BF8700A1
	v_dot2_f32_bf16 v9, v12, v59, v9                           // 00000075EF5C: CC1A4009 1C26770C
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 00000075EF64: BF8908B7
	v_dot2_f32_bf16 v9, v20, v60, v9                           // 00000075EF68: CC1A4009 1C267914
	s_waitcnt lgkmcnt(10)                                      // 00000075EF70: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000075EF74: BF8700A1
	v_dot2_f32_bf16 v9, v21, v61, v9                           // 00000075EF78: CC1A4009 1C267B15
	s_waitcnt lgkmcnt(9)                                       // 00000075EF80: BF89FC97
	v_dot2_f32_bf16 v9, v22, v62, v9                           // 00000075EF84: CC1A4009 1C267D16
	s_waitcnt lgkmcnt(8)                                       // 00000075EF8C: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000075EF90: BF8700A1
	v_dot2_f32_bf16 v9, v23, v63, v9                           // 00000075EF94: CC1A4009 1C267F17
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 00000075EF9C: BF890477
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 00000075EFA0: CC1A4009 1C26812E
	s_waitcnt lgkmcnt(6)                                       // 00000075EFA8: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000075EFAC: BF8700A1
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 00000075EFB0: CC1A4009 1C26832F
	s_waitcnt lgkmcnt(5)                                       // 00000075EFB8: BF89FC57
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 00000075EFBC: CC1A4009 1C268530
	s_waitcnt lgkmcnt(4)                                       // 00000075EFC4: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000075EFC8: BF8700A1
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 00000075EFCC: CC1A4009 1C268731
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 00000075EFD4: BF890037
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 00000075EFD8: CC1A4009 1C268932
	.long 0xd7006a32                                           // 00000075EFE0: D7006A32
	v_cndmask_b32_e32 v0, v13, v10, vcc_lo                     // 00000075EFE4: 0200150D
	s_waitcnt lgkmcnt(2)                                       // 00000075EFE8: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000075EFEC: BF8701C2
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 00000075EFF0: CC1A4009 1C268B33
	v_add_co_ci_u32_e64 v51, null, s11, v14, vcc_lo            // 00000075EFF8: D5207C33 01AA1C0B
	.long 0xd7006a36                                           // 00000075F000: D7006A36
	v_cndmask_b32_e32 v0, v13, v4, vcc_lo                      // 00000075F004: 0200090D
	s_waitcnt lgkmcnt(1)                                       // 00000075F008: BF89FC17
	v_dot2_f32_bf16 v9, v52, v70, v9                           // 00000075F00C: CC1A4009 1C268D34
	v_add_co_ci_u32_e64 v55, null, s5, v14, vcc_lo             // 00000075F014: D5207C37 01AA1C05
	.long 0xd7006a0d                                           // 00000075F01C: D7006A0D
	v_cndmask_b32_e32 v0, v13, v17, vcc_lo                     // 00000075F020: 0200230D
	s_waitcnt lgkmcnt(0)                                       // 00000075F024: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000075F028: BF870123
	v_dot2_f32_bf16 v9, v53, v71, v9                           // 00000075F02C: CC1A4009 1C268F35
	v_add_co_ci_u32_e64 v14, null, s15, v14, vcc_lo            // 00000075F034: D5207C0E 01AA1C0F
	v_fmac_f32_e32 v37, v56, v9                                // 00000075F03C: 564A1338
	s_clause 0x3                                               // 00000075F040: BF850003
	global_load_b128 v[9:12], v[50:51], off                    // 00000075F044: DC5E0000 097C0032
	global_load_b128 v[20:23], v[50:51], off offset:16         // 00000075F04C: DC5E0010 147C0032
	global_load_b128 v[46:49], v[50:51], off offset:32         // 00000075F054: DC5E0020 2E7C0032
	global_load_b128 v[50:53], v[50:51], off offset:48         // 00000075F05C: DC5E0030 327C0032
	s_waitcnt vmcnt(3)                                         // 00000075F064: BF890FF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 00000075F068: CC1A4009 1A021F09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075F070: BF870091
	v_dot2_f32_bf16 v9, v10, v57, v9                           // 00000075F074: CC1A4009 1C26730A
	v_dot2_f32_bf16 v9, v11, v58, v9                           // 00000075F07C: CC1A4009 1C26750B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000075F084: BF8700A1
	v_dot2_f32_bf16 v9, v12, v59, v9                           // 00000075F088: CC1A4009 1C26770C
	s_waitcnt vmcnt(2)                                         // 00000075F090: BF890BF7
	v_dot2_f32_bf16 v9, v20, v60, v9                           // 00000075F094: CC1A4009 1C267914
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075F09C: BF870091
	v_dot2_f32_bf16 v9, v21, v61, v9                           // 00000075F0A0: CC1A4009 1C267B15
	v_dot2_f32_bf16 v9, v22, v62, v9                           // 00000075F0A8: CC1A4009 1C267D16
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000075F0B0: BF8700A1
	v_dot2_f32_bf16 v9, v23, v63, v9                           // 00000075F0B4: CC1A4009 1C267F17
	s_waitcnt vmcnt(1)                                         // 00000075F0BC: BF8907F7
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 00000075F0C0: CC1A4009 1C26812E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075F0C8: BF870091
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 00000075F0CC: CC1A4009 1C26832F
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 00000075F0D4: CC1A4009 1C268530
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000075F0DC: BF8700A1
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 00000075F0E0: CC1A4009 1C268731
	s_waitcnt vmcnt(0)                                         // 00000075F0E8: BF8903F7
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 00000075F0EC: CC1A4009 1C268932
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075F0F4: BF870091
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 00000075F0F8: CC1A4009 1C268B33
	v_dot2_f32_bf16 v9, v52, v70, v9                           // 00000075F100: CC1A4009 1C268D34
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075F108: BF870091
	v_dot2_f32_bf16 v9, v53, v71, v9                           // 00000075F10C: CC1A4009 1C268F35
	v_fmac_f32_e32 v42, v56, v9                                // 00000075F114: 56541338
	s_clause 0x3                                               // 00000075F118: BF850003
	global_load_b128 v[9:12], v[54:55], off                    // 00000075F11C: DC5E0000 097C0036
	global_load_b128 v[20:23], v[54:55], off offset:16         // 00000075F124: DC5E0010 147C0036
	global_load_b128 v[46:49], v[54:55], off offset:32         // 00000075F12C: DC5E0020 2E7C0036
	global_load_b128 v[50:53], v[54:55], off offset:48         // 00000075F134: DC5E0030 327C0036
	.long 0xd7006a36                                           // 00000075F13C: D7006A36
	v_cndmask_b32_e32 v0, v54, v4, vcc_lo                      // 00000075F140: 02000936
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000075F144: BF8700B1
	v_add_co_ci_u32_e64 v55, null, s5, v55, vcc_lo             // 00000075F148: D5207C37 01AA6E05
	s_waitcnt vmcnt(3)                                         // 00000075F150: BF890FF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 00000075F154: CC1A4009 1A021F09
	v_dot2_f32_bf16 v9, v10, v57, v9                           // 00000075F15C: CC1A4009 1C26730A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075F164: BF870091
	v_dot2_f32_bf16 v9, v11, v58, v9                           // 00000075F168: CC1A4009 1C26750B
	v_dot2_f32_bf16 v9, v12, v59, v9                           // 00000075F170: CC1A4009 1C26770C
	s_waitcnt vmcnt(2)                                         // 00000075F178: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075F17C: BF870091
	v_dot2_f32_bf16 v9, v20, v60, v9                           // 00000075F180: CC1A4009 1C267914
	v_dot2_f32_bf16 v9, v21, v61, v9                           // 00000075F188: CC1A4009 1C267B15
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075F190: BF870091
	v_dot2_f32_bf16 v9, v22, v62, v9                           // 00000075F194: CC1A4009 1C267D16
	v_dot2_f32_bf16 v9, v23, v63, v9                           // 00000075F19C: CC1A4009 1C267F17
	s_waitcnt vmcnt(1)                                         // 00000075F1A4: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075F1A8: BF870091
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 00000075F1AC: CC1A4009 1C26812E
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 00000075F1B4: CC1A4009 1C26832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075F1BC: BF870091
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 00000075F1C0: CC1A4009 1C268530
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 00000075F1C8: CC1A4009 1C268731
	s_waitcnt vmcnt(0)                                         // 00000075F1D0: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075F1D4: BF870091
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 00000075F1D8: CC1A4009 1C268932
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 00000075F1E0: CC1A4009 1C268B33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075F1E8: BF870091
	v_dot2_f32_bf16 v9, v52, v70, v9                           // 00000075F1EC: CC1A4009 1C268D34
	v_dot2_f32_bf16 v9, v53, v71, v9                           // 00000075F1F4: CC1A4009 1C268F35
	s_delay_alu instid0(VALU_DEP_1)                            // 00000075F1FC: BF870001
	v_fmac_f32_e32 v41, v56, v9                                // 00000075F200: 56521338
	s_clause 0x3                                               // 00000075F204: BF850003
	global_load_b128 v[9:12], v[13:14], off                    // 00000075F208: DC5E0000 097C000D
	global_load_b128 v[20:23], v[13:14], off offset:16         // 00000075F210: DC5E0010 147C000D
	global_load_b128 v[46:49], v[13:14], off offset:32         // 00000075F218: DC5E0020 2E7C000D
	global_load_b128 v[50:53], v[13:14], off offset:48         // 00000075F220: DC5E0030 327C000D
	.long 0xd7006a0d                                           // 00000075F228: D7006A0D
	v_cndmask_b32_e32 v0, v13, v4, vcc_lo                      // 00000075F22C: 0200090D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000075F230: BF8700B1
	v_add_co_ci_u32_e64 v14, null, s5, v14, vcc_lo             // 00000075F234: D5207C0E 01AA1C05
	s_waitcnt vmcnt(3)                                         // 00000075F23C: BF890FF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 00000075F240: CC1A4009 1A021F09
	v_dot2_f32_bf16 v9, v10, v57, v9                           // 00000075F248: CC1A4009 1C26730A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075F250: BF870091
	v_dot2_f32_bf16 v9, v11, v58, v9                           // 00000075F254: CC1A4009 1C26750B
	v_dot2_f32_bf16 v9, v12, v59, v9                           // 00000075F25C: CC1A4009 1C26770C
	s_waitcnt vmcnt(2)                                         // 00000075F264: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075F268: BF870091
	v_dot2_f32_bf16 v9, v20, v60, v9                           // 00000075F26C: CC1A4009 1C267914
	v_dot2_f32_bf16 v9, v21, v61, v9                           // 00000075F274: CC1A4009 1C267B15
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075F27C: BF870091
	v_dot2_f32_bf16 v9, v22, v62, v9                           // 00000075F280: CC1A4009 1C267D16
	v_dot2_f32_bf16 v9, v23, v63, v9                           // 00000075F288: CC1A4009 1C267F17
	s_waitcnt vmcnt(1)                                         // 00000075F290: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075F294: BF870091
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 00000075F298: CC1A4009 1C26812E
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 00000075F2A0: CC1A4009 1C26832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075F2A8: BF870091
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 00000075F2AC: CC1A4009 1C268530
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 00000075F2B4: CC1A4009 1C268731
	s_waitcnt vmcnt(0)                                         // 00000075F2BC: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075F2C0: BF870091
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 00000075F2C4: CC1A4009 1C268932
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 00000075F2CC: CC1A4009 1C268B33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075F2D4: BF870091
	v_dot2_f32_bf16 v9, v52, v70, v9                           // 00000075F2D8: CC1A4009 1C268D34
	v_dot2_f32_bf16 v9, v53, v71, v9                           // 00000075F2E0: CC1A4009 1C268F35
	s_delay_alu instid0(VALU_DEP_1)                            // 00000075F2E8: BF870001
	v_fmac_f32_e32 v40, v56, v9                                // 00000075F2EC: 56501338
	s_clause 0x3                                               // 00000075F2F0: BF850003
	global_load_b128 v[9:12], v[54:55], off                    // 00000075F2F4: DC5E0000 097C0036
	global_load_b128 v[20:23], v[54:55], off offset:16         // 00000075F2FC: DC5E0010 147C0036
	global_load_b128 v[46:49], v[54:55], off offset:32         // 00000075F304: DC5E0020 2E7C0036
	global_load_b128 v[50:53], v[54:55], off offset:48         // 00000075F30C: DC5E0030 327C0036
	s_waitcnt vmcnt(3)                                         // 00000075F314: BF890FF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 00000075F318: CC1A4009 1A021F09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075F320: BF870091
	v_dot2_f32_bf16 v9, v10, v57, v9                           // 00000075F324: CC1A4009 1C26730A
	v_dot2_f32_bf16 v9, v11, v58, v9                           // 00000075F32C: CC1A4009 1C26750B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000075F334: BF8700A1
	v_dot2_f32_bf16 v9, v12, v59, v9                           // 00000075F338: CC1A4009 1C26770C
	s_waitcnt vmcnt(2)                                         // 00000075F340: BF890BF7
	v_dot2_f32_bf16 v9, v20, v60, v9                           // 00000075F344: CC1A4009 1C267914
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075F34C: BF870091
	v_dot2_f32_bf16 v9, v21, v61, v9                           // 00000075F350: CC1A4009 1C267B15
	v_dot2_f32_bf16 v9, v22, v62, v9                           // 00000075F358: CC1A4009 1C267D16
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000075F360: BF8700A1
	v_dot2_f32_bf16 v9, v23, v63, v9                           // 00000075F364: CC1A4009 1C267F17
	s_waitcnt vmcnt(1)                                         // 00000075F36C: BF8907F7
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 00000075F370: CC1A4009 1C26812E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075F378: BF870091
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 00000075F37C: CC1A4009 1C26832F
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 00000075F384: CC1A4009 1C268530
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000075F38C: BF8700A1
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 00000075F390: CC1A4009 1C268731
	s_waitcnt vmcnt(0)                                         // 00000075F398: BF8903F7
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 00000075F39C: CC1A4009 1C268932
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075F3A4: BF870091
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 00000075F3A8: CC1A4009 1C268B33
	v_dot2_f32_bf16 v9, v52, v70, v9                           // 00000075F3B0: CC1A4009 1C268D34
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075F3B8: BF870091
	v_dot2_f32_bf16 v9, v53, v71, v9                           // 00000075F3BC: CC1A4009 1C268F35
	v_fmac_f32_e32 v39, v56, v9                                // 00000075F3C4: 564E1338
	s_clause 0x3                                               // 00000075F3C8: BF850003
	global_load_b128 v[9:12], v[13:14], off                    // 00000075F3CC: DC5E0000 097C000D
	global_load_b128 v[20:23], v[13:14], off offset:16         // 00000075F3D4: DC5E0010 147C000D
	global_load_b128 v[46:49], v[13:14], off offset:32         // 00000075F3DC: DC5E0020 2E7C000D
	global_load_b128 v[50:53], v[13:14], off offset:48         // 00000075F3E4: DC5E0030 327C000D
	.long 0xd7006a0d                                           // 00000075F3EC: D7006A0D
	v_cndmask_b32_e32 v0, v54, v4, vcc_lo                      // 00000075F3F0: 02000936
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000075F3F4: BF8700B1
	v_add_co_ci_u32_e64 v14, null, s5, v55, vcc_lo             // 00000075F3F8: D5207C0E 01AA6E05
	s_waitcnt vmcnt(3)                                         // 00000075F400: BF890FF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 00000075F404: CC1A4009 1A021F09
	v_dot2_f32_bf16 v9, v10, v57, v9                           // 00000075F40C: CC1A4009 1C26730A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075F414: BF870091
	v_dot2_f32_bf16 v9, v11, v58, v9                           // 00000075F418: CC1A4009 1C26750B
	v_dot2_f32_bf16 v9, v12, v59, v9                           // 00000075F420: CC1A4009 1C26770C
	s_waitcnt vmcnt(2)                                         // 00000075F428: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075F42C: BF870091
	v_dot2_f32_bf16 v9, v20, v60, v9                           // 00000075F430: CC1A4009 1C267914
	v_dot2_f32_bf16 v9, v21, v61, v9                           // 00000075F438: CC1A4009 1C267B15
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075F440: BF870091
	v_dot2_f32_bf16 v9, v22, v62, v9                           // 00000075F444: CC1A4009 1C267D16
	v_dot2_f32_bf16 v9, v23, v63, v9                           // 00000075F44C: CC1A4009 1C267F17
	s_waitcnt vmcnt(1)                                         // 00000075F454: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075F458: BF870091
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 00000075F45C: CC1A4009 1C26812E
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 00000075F464: CC1A4009 1C26832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075F46C: BF870091
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 00000075F470: CC1A4009 1C268530
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 00000075F478: CC1A4009 1C268731
	s_waitcnt vmcnt(0)                                         // 00000075F480: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075F484: BF870091
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 00000075F488: CC1A4009 1C268932
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 00000075F490: CC1A4009 1C268B33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075F498: BF870091
	v_dot2_f32_bf16 v9, v52, v70, v9                           // 00000075F49C: CC1A4009 1C268D34
	v_dot2_f32_bf16 v9, v53, v71, v9                           // 00000075F4A4: CC1A4009 1C268F35
	s_delay_alu instid0(VALU_DEP_1)                            // 00000075F4AC: BF870001
	v_fmac_f32_e32 v38, v56, v9                                // 00000075F4B0: 564C1338
	s_clause 0x3                                               // 00000075F4B4: BF850003
	global_load_b128 v[9:12], v[13:14], off                    // 00000075F4B8: DC5E0000 097C000D
	global_load_b128 v[20:23], v[13:14], off offset:16         // 00000075F4C0: DC5E0010 147C000D
	global_load_b128 v[46:49], v[13:14], off offset:32         // 00000075F4C8: DC5E0020 2E7C000D
	global_load_b128 v[50:53], v[13:14], off offset:48         // 00000075F4D0: DC5E0030 327C000D
	s_waitcnt vmcnt(3)                                         // 00000075F4D8: BF890FF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 00000075F4DC: CC1A4009 1A021F09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075F4E4: BF870091
	v_dot2_f32_bf16 v9, v10, v57, v9                           // 00000075F4E8: CC1A4009 1C26730A
	v_dot2_f32_bf16 v9, v11, v58, v9                           // 00000075F4F0: CC1A4009 1C26750B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000075F4F8: BF8700A1
	v_dot2_f32_bf16 v9, v12, v59, v9                           // 00000075F4FC: CC1A4009 1C26770C
	s_waitcnt vmcnt(2)                                         // 00000075F504: BF890BF7
	v_dot2_f32_bf16 v9, v20, v60, v9                           // 00000075F508: CC1A4009 1C267914
	v_mov_b32_e32 v20, v16                                     // 00000075F510: 7E280310
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000075F514: BF870122
	v_dot2_f32_bf16 v9, v21, v61, v9                           // 00000075F518: CC1A4009 1C267B15
	v_mov_b32_e32 v21, v17                                     // 00000075F520: 7E2A0311
	v_dot2_f32_bf16 v9, v22, v62, v9                           // 00000075F524: CC1A4009 1C267D16
	v_mov_b32_e32 v22, v18                                     // 00000075F52C: 7E2C0312
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000075F530: BF870132
	v_dot2_f32_bf16 v9, v23, v63, v9                           // 00000075F534: CC1A4009 1C267F17
	v_mov_b32_e32 v23, v19                                     // 00000075F53C: 7E2E0313
	s_waitcnt vmcnt(1)                                         // 00000075F540: BF8907F7
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 00000075F544: CC1A4009 1C26812E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075F54C: BF870091
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 00000075F550: CC1A4009 1C26832F
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 00000075F558: CC1A4009 1C268530
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000075F560: BF8700A1
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 00000075F564: CC1A4009 1C268731
	s_waitcnt vmcnt(0)                                         // 00000075F56C: BF8903F7
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 00000075F570: CC1A4009 1C268932
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075F578: BF870091
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 00000075F57C: CC1A4009 1C268B33
	v_dot2_f32_bf16 v9, v52, v70, v9                           // 00000075F584: CC1A4009 1C268D34
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075F58C: BF870091
	v_dot2_f32_bf16 v9, v53, v71, v9                           // 00000075F590: CC1A4009 1C268F35
	v_fmac_f32_e32 v34, v56, v9                                // 00000075F598: 56441338
	v_mov_b32_e32 v15, v8                                      // 00000075F59C: 7E1E0308
	v_dual_mov_b32 v14, v7 :: v_dual_mov_b32 v13, v6           // 00000075F5A0: CA100107 0E0C0106
	v_dual_mov_b32 v12, v5 :: v_dual_mov_b32 v11, v4           // 00000075F5A8: CA100105 0C0A0104
	v_dual_mov_b32 v10, v3 :: v_dual_mov_b32 v9, v2            // 00000075F5B0: CA100103 0A080102
	v_mov_b32_e32 v8, v1                                       // 00000075F5B8: 7E100301
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 00000075F5BC: 917E107E
	s_cbranch_execz 35                                         // 00000075F5C0: BFA50023 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xe50>
	s_waitcnt vmcnt(0)                                         // 00000075F5C4: BF8903F7
	v_dual_mov_b32 v16, v20 :: v_dual_add_nc_u32 v31, 32, v31  // 00000075F5C8: CA200114 101E3EA0
	v_dual_mov_b32 v17, v21 :: v_dual_mov_b32 v18, v22         // 00000075F5D0: CA100115 11120116
	v_mov_b32_e32 v19, v23                                     // 00000075F5D8: 7E260317
	s_delay_alu instid0(VALU_DEP_3)                            // 00000075F5DC: BF870003
	.long 0xd4460001                                           // 00000075F5E0: D4460001
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 00000075F5E4: 0202411F
	s_mov_b32 s18, exec_lo                                     // 00000075F5E8: BE92007E
	.long 0xd4c1007e                                           // 00000075F5EC: D4C1007E
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 00000075F5F0: 0202411F
	s_cbranch_execz 64970                                      // 00000075F5F4: BFA5FDCA <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x520>
	v_ashrrev_i32_e32 v2, 31, v43                              // 00000075F5F8: 3404569F
	.long 0xd7006a01                                           // 00000075F5FC: D7006A01
	v_cndmask_b32_e32 v1, v25, v43, vcc_lo                     // 00000075F600: 02025719
	v_mov_b32_e32 v45, v27                                     // 00000075F604: 7E5A031B
	s_delay_alu instid0(VALU_DEP_3)                            // 00000075F608: BF870003
	v_add_co_ci_u32_e64 v2, null, v36, v2, vcc_lo              // 00000075F60C: D5207C02 01AA0524
	v_cmp_ne_u32_e32 vcc_lo, 1, v35                            // 00000075F614: 7C9A4681
	global_load_b128 v[16:19], v[1:2], off                     // 00000075F618: DC5E0000 107C0001
	s_cbranch_vccnz 64959                                      // 00000075F620: BFA4FDBF <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x520>
	v_ashrrev_i32_e32 v2, 31, v44                              // 00000075F624: 3404589F
	.long 0xd7006a01                                           // 00000075F628: D7006A01
	v_cndmask_b32_e32 v1, v24, v44, vcc_lo                     // 00000075F62C: 02025918
	s_delay_alu instid0(VALU_DEP_1)                            // 00000075F630: BF870001
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 00000075F634: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 00000075F63C: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 00000075F644: BF8903F7
	v_cvt_f32_f16_e32 v45, v1                                  // 00000075F648: 7E5A1701
	s_branch 64948                                             // 00000075F64C: BFA0FDB4 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x520>
	s_or_b32 exec_lo, exec_lo, s16                             // 00000075F650: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000075F654: BF8700B9
	s_or_b32 exec_lo, exec_lo, s14                             // 00000075F658: 8C7E0E7E
	.long 0xd71f0001                                           // 00000075F65C: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000075F660: 020100C1
	s_mov_b32 s0, exec_lo                                      // 00000075F664: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 00000075F668: 3A040290
	v_xor_b32_e32 v9, 8, v1                                    // 00000075F66C: 3A120288
	v_xor_b32_e32 v16, 4, v1                                   // 00000075F670: 3A200284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000075F674: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 00000075F678: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 00000075F67C: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v9                            // 00000075F680: 7C9812A0
	v_cndmask_b32_e32 v9, v1, v9, vcc_lo                       // 00000075F684: 02121301
	v_cmp_gt_u32_e32 vcc_lo, 32, v16                           // 00000075F688: 7C9820A0
	s_delay_alu instid0(VALU_DEP_2)                            // 00000075F68C: BF870002
	v_lshlrev_b32_e32 v9, 2, v9                                // 00000075F690: 30121282
	v_lshlrev_b32_e32 v2, 2, v2                                // 00000075F694: 30040482
	ds_bpermute_b32 v3, v2, v37                                // 00000075F698: DACC0000 03002502
	s_waitcnt lgkmcnt(0)                                       // 00000075F6A0: BF89FC07
	v_add_f32_e32 v3, v37, v3                                  // 00000075F6A4: 06060725
	ds_bpermute_b32 v5, v2, v41                                // 00000075F6A8: DACC0000 05002902
	ds_bpermute_b32 v6, v2, v40                                // 00000075F6B0: DACC0000 06002802
	ds_bpermute_b32 v7, v2, v39                                // 00000075F6B8: DACC0000 07002702
	ds_bpermute_b32 v4, v2, v42                                // 00000075F6C0: DACC0000 04002A02
	ds_bpermute_b32 v8, v2, v38                                // 00000075F6C8: DACC0000 08002602
	ds_bpermute_b32 v2, v2, v34                                // 00000075F6D0: DACC0000 02002202
	ds_bpermute_b32 v10, v9, v3                                // 00000075F6D8: DACC0000 0A000309
	v_cndmask_b32_e32 v16, v1, v16, vcc_lo                     // 00000075F6E0: 02202101
	s_waitcnt lgkmcnt(5)                                       // 00000075F6E4: BF89FC57
	v_dual_add_f32 v5, v41, v5 :: v_dual_add_f32 v6, v40, v6   // 00000075F6E8: C9080B29 05060D28
	s_waitcnt lgkmcnt(3)                                       // 00000075F6F0: BF89FC37
	v_dual_add_f32 v7, v39, v7 :: v_dual_add_f32 v4, v42, v4   // 00000075F6F4: C9080F27 0704092A
	s_waitcnt lgkmcnt(2)                                       // 00000075F6FC: BF89FC27
	v_add_f32_e32 v8, v38, v8                                  // 00000075F700: 06101126
	ds_bpermute_b32 v12, v9, v5                                // 00000075F704: DACC0000 0C000509
	s_waitcnt lgkmcnt(2)                                       // 00000075F70C: BF89FC27
	v_add_f32_e32 v2, v34, v2                                  // 00000075F710: 06040522
	ds_bpermute_b32 v14, v9, v7                                // 00000075F714: DACC0000 0E000709
	ds_bpermute_b32 v11, v9, v4                                // 00000075F71C: DACC0000 0B000409
	ds_bpermute_b32 v13, v9, v6                                // 00000075F724: DACC0000 0D000609
	ds_bpermute_b32 v15, v9, v8                                // 00000075F72C: DACC0000 0F000809
	s_waitcnt lgkmcnt(5)                                       // 00000075F734: BF89FC57
	v_dual_add_f32 v3, v3, v10 :: v_dual_lshlrev_b32 v16, 2, v16// 00000075F738: C9221503 03102082
	s_waitcnt lgkmcnt(4)                                       // 00000075F740: BF89FC47
	v_add_f32_e32 v5, v5, v12                                  // 00000075F744: 060A1905
	ds_bpermute_b32 v9, v9, v2                                 // 00000075F748: DACC0000 09000209
	s_waitcnt lgkmcnt(0)                                       // 00000075F750: BF89FC07
	v_dual_add_f32 v7, v7, v14 :: v_dual_add_f32 v2, v2, v9    // 00000075F754: C9081D07 07021302
	ds_bpermute_b32 v9, v16, v3                                // 00000075F75C: DACC0000 09000310
	v_add_f32_e32 v4, v4, v11                                  // 00000075F764: 06081704
	ds_bpermute_b32 v11, v16, v5                               // 00000075F768: DACC0000 0B000510
	v_add_f32_e32 v6, v6, v13                                  // 00000075F770: 060C1B06
	ds_bpermute_b32 v13, v16, v7                               // 00000075F774: DACC0000 0D000710
	s_waitcnt lgkmcnt(2)                                       // 00000075F77C: BF89FC27
	v_dual_add_f32 v8, v8, v15 :: v_dual_add_f32 v3, v3, v9    // 00000075F780: C9081F08 08021303
	ds_bpermute_b32 v10, v16, v4                               // 00000075F788: DACC0000 0A000410
	s_waitcnt lgkmcnt(2)                                       // 00000075F790: BF89FC27
	v_add_f32_e32 v5, v5, v11                                  // 00000075F794: 060A1705
	ds_bpermute_b32 v12, v16, v6                               // 00000075F798: DACC0000 0C000610
	s_waitcnt lgkmcnt(2)                                       // 00000075F7A0: BF89FC27
	v_add_f32_e32 v7, v7, v13                                  // 00000075F7A4: 060E1B07
	ds_bpermute_b32 v14, v16, v8                               // 00000075F7A8: DACC0000 0E000810
	s_waitcnt lgkmcnt(2)                                       // 00000075F7B0: BF89FC27
	v_add_f32_e32 v4, v4, v10                                  // 00000075F7B4: 06081504
	s_waitcnt lgkmcnt(0)                                       // 00000075F7B8: BF89FC07
	v_dual_add_f32 v6, v6, v12 :: v_dual_add_f32 v9, v8, v14   // 00000075F7BC: C9081906 06081D08
	ds_bpermute_b32 v15, v16, v2                               // 00000075F7C4: DACC0000 0F000210
	v_xor_b32_e32 v16, 2, v1                                   // 00000075F7CC: 3A200282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000075F7D0: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v16                           // 00000075F7D4: 7C9820A0
	v_cndmask_b32_e32 v16, v1, v16, vcc_lo                     // 00000075F7D8: 02202101
	v_lshlrev_b32_e32 v16, 2, v16                              // 00000075F7DC: 30202082
	ds_bpermute_b32 v8, v16, v3                                // 00000075F7E0: DACC0000 08000310
	s_waitcnt lgkmcnt(1)                                       // 00000075F7E8: BF89FC17
	v_add_f32_e32 v2, v2, v15                                  // 00000075F7EC: 06041F02
	ds_bpermute_b32 v10, v16, v4                               // 00000075F7F0: DACC0000 0A000410
	ds_bpermute_b32 v11, v16, v5                               // 00000075F7F8: DACC0000 0B000510
	ds_bpermute_b32 v12, v16, v6                               // 00000075F800: DACC0000 0C000610
	ds_bpermute_b32 v13, v16, v7                               // 00000075F808: DACC0000 0D000710
	ds_bpermute_b32 v14, v16, v9                               // 00000075F810: DACC0000 0E000910
	ds_bpermute_b32 v15, v16, v2                               // 00000075F818: DACC0000 0F000210
	v_xor_b32_e32 v16, 1, v1                                   // 00000075F820: 3A200281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000075F824: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v16                           // 00000075F828: 7C9820A0
	v_cndmask_b32_e32 v1, v1, v16, vcc_lo                      // 00000075F82C: 02022101
	s_waitcnt lgkmcnt(6)                                       // 00000075F830: BF89FC67
	v_dual_add_f32 v1, v3, v8 :: v_dual_lshlrev_b32 v16, 2, v1 // 00000075F834: C9221103 01100282
	s_waitcnt lgkmcnt(4)                                       // 00000075F83C: BF89FC47
	v_dual_add_f32 v3, v4, v10 :: v_dual_add_f32 v4, v5, v11   // 00000075F840: C9081504 03041705
	s_waitcnt lgkmcnt(2)                                       // 00000075F848: BF89FC27
	v_dual_add_f32 v5, v6, v12 :: v_dual_add_f32 v8, v7, v13   // 00000075F84C: C9081906 05081B07
	s_waitcnt lgkmcnt(1)                                       // 00000075F854: BF89FC17
	v_add_f32_e32 v10, v9, v14                                 // 00000075F858: 06141D09
	s_waitcnt lgkmcnt(0)                                       // 00000075F85C: BF89FC07
	v_add_f32_e32 v2, v2, v15                                  // 00000075F860: 06041F02
	ds_bpermute_b32 v6, v16, v1                                // 00000075F864: DACC0000 06000110
	ds_bpermute_b32 v9, v16, v3                                // 00000075F86C: DACC0000 09000310
	ds_bpermute_b32 v11, v16, v4                               // 00000075F874: DACC0000 0B000410
	ds_bpermute_b32 v12, v16, v5                               // 00000075F87C: DACC0000 0C000510
	ds_bpermute_b32 v13, v16, v8                               // 00000075F884: DACC0000 0D000810
	ds_bpermute_b32 v14, v16, v10                              // 00000075F88C: DACC0000 0E000A10
	ds_bpermute_b32 v7, v16, v2                                // 00000075F894: DACC0000 07000210
	v_cmpx_eq_u32_e32 0, v30                                   // 00000075F89C: 7D943C80
	s_cbranch_execz 29                                         // 00000075F8A0: BFA5001D <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x1118>
	.long 0xd72c000f                                           // 00000075F8A4: D72C000F
	v_cndmask_b32_e32 v0, v28, v184, vcc_lo                    // 00000075F8A8: 0201711C
	s_waitcnt lgkmcnt(2)                                       // 00000075F8AC: BF89FC27
	v_dual_add_f32 v8, v8, v13 :: v_dual_add_f32 v1, v1, v6    // 00000075F8B0: C9081B08 08000D01
	v_dual_add_f32 v4, v4, v11 :: v_dual_add_f32 v3, v3, v9    // 00000075F8B8: C9081704 04021303
	s_waitcnt lgkmcnt(1)                                       // 00000075F8C0: BF89FC17
	v_dual_add_f32 v10, v10, v14 :: v_dual_add_f32 v5, v5, v12 // 00000075F8C4: C9081D0A 0A041905
	s_waitcnt lgkmcnt(0)                                       // 00000075F8CC: BF89FC07
	v_add_f32_e32 v2, v2, v7                                   // 00000075F8D0: 06040F02
	v_mad_u32_u24 v13, v29, 28, v15                            // 00000075F8D4: D60B000D 043D391D
	s_delay_alu instid0(VALU_DEP_1)                            // 00000075F8DC: BF870001
	v_add_nc_u32_e32 v6, 0x400, v13                            // 00000075F8E0: 4A0C1AFF 00000400
	v_add_nc_u32_e32 v9, 0x408, v13                            // 00000075F8E8: 4A121AFF 00000408
	v_add_nc_u32_e32 v11, 0x410, v13                           // 00000075F8F0: 4A161AFF 00000410
	ds_store_2addr_b32 v6, v1, v3 offset1:1                    // 00000075F8F8: D8380100 00030106
	ds_store_2addr_b32 v9, v4, v5 offset1:1                    // 00000075F900: D8380100 00050409
	ds_store_2addr_b32 v11, v8, v10 offset1:1                  // 00000075F908: D8380100 000A080B
	ds_store_b32 v13, v2 offset:1048                           // 00000075F910: D8340418 0000020D
	s_or_b32 exec_lo, exec_lo, s0                              // 00000075F918: 8C7E007E
	.long 0xd7050001                                           // 00000075F91C: D7050001
	v_cndmask_b32_e32 v0, v0, v165, vcc_lo                     // 00000075F920: 02014B00
	.long 0x7f063880                                           // 00000075F924: 7F063880
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000075F928: BF890007
	s_barrier                                                  // 00000075F92C: BFBD0000
	buffer_gl0_inv                                             // 00000075F930: E0AC0000 00000000
	.long 0xd7390001                                           // 00000075F938: D7390001
	v_cndmask_b32_e32 v1, 8, v1, vcc_lo                        // 00000075F93C: 02020288
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075F940: BF870091
	.long 0xd7044001                                           // 00000075F944: D7044001
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 00000075F948: 02020300
	.long 0xd7395001                                           // 00000075F94C: D7395001
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000075F950: 02020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075F954: BF870091
	.long 0xd7625001                                           // 00000075F958: D7625001
	v_cndmask_b32_e32 v1, 0x7f, v1, vcc_lo                     // 00000075F95C: 020202FF 0000007F
	.long 0xd7030801                                           // 00000075F964: D7030801
	v_cndmask_b32_e32 v1, v1, v1, vcc_lo                       // 00000075F968: 02020301
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075F96C: BF870091
	.long 0xd7390003                                           // 00000075F970: D7390003
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000075F974: 02020282
	.long 0xd7000001                                           // 00000075F978: D7000001
	v_cndmask_b32_e32 v1, s2, v3, vcc_lo                       // 00000075F97C: 02020602
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000075F980: BF870121
	v_add_co_ci_u32_e64 v2, null, s3, 0, s0                    // 00000075F984: D5207C02 00010003
	.long 0xd44c0000                                           // 00000075F98C: D44C0000
	v_cndmask_b32_e32 v1, 28, v0, vcc_lo                       // 00000075F990: 0202009C
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 00000075F994: 7CA8020C
	s_and_b32 s0, s0, vcc_lo                                   // 00000075F998: 8B006A00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000075F99C: BF870009
	s_and_saveexec_b32 s1, s0                                  // 00000075F9A0: BE812000
	s_cbranch_execz 39                                         // 00000075F9A4: BFA50027 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x1244>
	.long 0xd7054000                                           // 00000075F9A8: D7054000
	v_cndmask_b32_e32 v0, v3, v135, vcc_lo                     // 00000075F9AC: 02010F03
	v_mul_u32_u24_e32 v3, 56, v3                               // 00000075F9B0: 160606B8
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075F9B4: BF870092
	.long 0xd7041000                                           // 00000075F9B8: D7041000
	v_cndmask_b32_e32 v1, v0, v0, vcc_lo                       // 00000075F9BC: 02020100
	v_and_b32_e32 v0, 0xff, v0                                 // 00000075F9C0: 360000FF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075F9C8: BF870091
	v_lshl_add_u32 v3, v0, 2, v3                               // 00000075F9CC: D6460003 040D0500
	v_add_nc_u32_e32 v5, 0x400, v3                             // 00000075F9D4: 4A0A06FF 00000400
	v_mad_u64_u32 v[3:4], null, s12, v0, 0                     // 00000075F9DC: D6FE7C03 0202000C
	ds_load_2addr_b32 v[6:7], v5 offset1:7                     // 00000075F9E4: D8DC0700 06000005
	v_mad_u64_u32 v[4:5], null, s13, v0, v[4:5]                // 00000075F9EC: D6FE7C04 0412000D
	.long 0xd73c0000                                           // 00000075F9F4: D73C0000
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000075F9F8: 02020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075F9FC: BF870092
	.long 0xd73c0003                                           // 00000075FA00: D73C0003
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 00000075FA04: 02020682
	.long 0xd7006a03                                           // 00000075FA08: D7006A03
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 00000075FA0C: 02020608
	s_waitcnt lgkmcnt(0)                                       // 00000075FA10: BF89FC07
	v_add_f32_e32 v2, 0, v6                                    // 00000075FA14: 06040C80
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000075FA18: BF870193
	v_add_co_ci_u32_e64 v4, null, s9, v4, vcc_lo               // 00000075FA1C: D5207C04 01AA0809
	.long 0xd7006a00                                           // 00000075FA24: D7006A00
	v_cndmask_b32_e32 v1, v3, v0, vcc_lo                       // 00000075FA28: 02020103
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000075FA2C: BF870193
	v_add_f32_e32 v2, v2, v7                                   // 00000075FA30: 06040F02
	v_add_co_ci_u32_e64 v1, null, v4, v1, vcc_lo               // 00000075FA34: D5207C01 01AA0304
	global_store_b32 v[0:1], v2, off                           // 00000075FA3C: DC6A0000 007C0200
	s_endpgm                                                   // 00000075FA44: BFB00000
		...

