000000000040fe00 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi8ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj>:
; _ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi8ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj():
	s_clause 0x1                                               // 00000040FE00: BF850001
	s_load_b64 s[4:5], s[0:1], 0x130                           // 00000040FE04: F4040100 F8000130
	s_load_b128 s[16:19], s[0:1], 0x198                        // 00000040FE0C: F4080400 F8000198
	s_waitcnt lgkmcnt(0)                                       // 00000040FE14: BF89FC07
	s_cmp_eq_u64 s[4:5], 0                                     // 00000040FE18: BF108004
	s_cbranch_scc1 246                                         // 00000040FE1C: BFA200F6 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi8ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3f8>
	s_load_b32 s6, s[0:1], 0x138                               // 00000040FE20: F4000180 F8000138
	s_waitcnt lgkmcnt(0)                                       // 00000040FE28: BF89FC07
	s_cmp_lt_i32 s2, s6                                        // 00000040FE2C: BF040602
	s_cselect_b32 s3, -1, 0                                    // 00000040FE30: 980380C1
	s_cmp_ge_i32 s2, s6                                        // 00000040FE34: BF030602
	s_cbranch_scc0 233                                         // 00000040FE38: BFA100E9 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi8ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3e0>
	v_lshrrev_b32_e32 v1, 5, v0                                // 00000040FE3C: 32020085
	s_sub_i32 s6, s2, s6                                       // 00000040FE40: 81860602
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000040FE44: BF870481
	v_lshl_or_b32 v1, s6, 3, v1                                // 00000040FE48: D6560001 04050606
	s_mul_i32 s6, s18, 20                                      // 00000040FE50: 96069412
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000040FE54: BF870481
	v_cmp_gt_i32_e32 vcc_lo, s6, v1                            // 00000040FE58: 7C880206
	s_and_saveexec_b32 s6, vcc_lo                              // 00000040FE5C: BE86206A
	s_cbranch_execz 222                                        // 00000040FE60: BFA500DE <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi8ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3dc>
	.long 0xd72e0002                                           // 00000040FE64: D72E0002
	v_cndmask_b32_e32 v1, 0x66666667, v1, vcc_lo               // 00000040FE68: 020202FF 66666667
	v_and_b32_e32 v9, 31, v0                                   // 00000040FE70: 3612009F
	s_load_b64 s[8:9], s[0:1], 0x128                           // 00000040FE74: F4040200 F8000128
	s_mov_b32 s7, 0x76543210                                   // 00000040FE7C: BE8700FF 76543210
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000040FE84: BF8700A2
	v_lshrrev_b32_e32 v3, 31, v2                               // 00000040FE88: 3206049F
	v_ashrrev_i32_e32 v2, 3, v2                                // 00000040FE8C: 34040483
	v_add_nc_u32_e32 v8, v2, v3                                // 00000040FE90: 4A100702
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000040FE94: BF870121
	.long 0xd72c0002                                           // 00000040FE98: D72C0002
	v_cndmask_b32_e32 v1, 0xffffffec, v8, vcc_lo               // 00000040FE9C: 020210FF FFFFFFEC
	v_mad_i64_i32 v[4:5], null, 0x1400, v8, s[16:17]           // 00000040FEA4: D6FF7C04 004210FF 00001400
	v_add_lshl_u32 v1, v2, v1, 7                               // 00000040FEB0: D6470001 021E0302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000040FEB8: BF870091
	v_lshl_or_b32 v2, v9, 2, v1                                // 00000040FEBC: D6560002 04050509
	v_ashrrev_i32_e32 v3, 31, v2                               // 00000040FEC4: 3406049F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000040FEC8: BF870091
	.long 0xd73c0002                                           // 00000040FECC: D73C0002
	v_cndmask_b32_e32 v1, 1, v2, vcc_lo                        // 00000040FED0: 02020481
	.long 0xd7006a04                                           // 00000040FED4: D7006A04
	v_cndmask_b32_e32 v1, v4, v2, vcc_lo                       // 00000040FED8: 02020504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000040FEDC: BF8700B1
	v_add_co_ci_u32_e64 v5, null, v5, v3, vcc_lo               // 00000040FEE0: D5207C05 01AA0705
	s_waitcnt lgkmcnt(0)                                       // 00000040FEE8: BF89FC07
	.long 0xd7006a02                                           // 00000040FEEC: D7006A02
	v_cndmask_b32_e32 v1, s8, v2, vcc_lo                       // 00000040FEF0: 02020408
	v_add_co_ci_u32_e64 v3, null, s9, v3, vcc_lo               // 00000040FEF4: D5207C03 01AA0609
	global_load_b64 v[4:5], v[4:5], off                        // 00000040FEFC: DC560000 047C0004
	s_mov_b32 s8, 0x3db504f3                                   // 00000040FF04: BE8800FF 3DB504F3
	global_load_b64 v[6:7], v[2:3], off                        // 00000040FF0C: DC560000 067C0002
	s_waitcnt vmcnt(1)                                         // 00000040FF14: BF8907F7
	.long 0x7e043904                                           // 00000040FF18: 7E043904
	v_and_b32_e32 v3, 0xffff0000, v4                           // 00000040FF1C: 360608FF FFFF0000
	.long 0x7e083905                                           // 00000040FF24: 7E083905
	v_and_b32_e32 v5, 0xffff0000, v5                           // 00000040FF28: 360A0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4)                            // 00000040FF30: BF870004
	v_lshlrev_b32_e32 v14, 16, v2                              // 00000040FF34: 301C0490
	s_waitcnt vmcnt(0)                                         // 00000040FF38: BF8903F7
	v_fma_mix_f32 v3, v6, v3, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 00000040FF3C: CC200803 8A020706
	v_lshlrev_b32_e32 v4, 16, v4                               // 00000040FF44: 30080890
	v_fma_mix_f32 v5, v7, v5, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 00000040FF48: CC200805 8A020B07
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000040FF50: 3404029F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000040FF54: BF870224
	v_fma_mix_f32 v15, v6, v14, v3 op_sel_hi:[1,0,0]           // 00000040FF58: CC20000F 0C0E1D06
	v_fma_mix_f32 v6, v6, v14, -v3 op_sel_hi:[1,0,0]           // 00000040FF60: CC200006 8C0E1D06
	v_fma_mix_f32 v14, v7, v4, v5 op_sel_hi:[1,0,0]            // 00000040FF68: CC20000E 0C160907
	v_fma_mix_f32 v5, v7, v4, -v5 op_sel_hi:[1,0,0]            // 00000040FF70: CC200005 8C160907
	v_and_b32_e32 v10, 1, v0                                   // 00000040FF78: 36140081
	v_and_b32_e32 v11, 2, v0                                   // 00000040FF7C: 36160082
	v_and_b32_e32 v13, 8, v0                                   // 00000040FF80: 361A0088
	.long 0xd73c0001                                           // 00000040FF84: D73C0001
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000040FF88: 02020281
	v_add_f32_e32 v16, v6, v5                                  // 00000040FF8C: 06200B06
	v_sub_f32_e32 v5, v6, v5                                   // 00000040FF90: 080A0B06
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 00000040FF94: 7C941480
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000040FF98: BF870193
	v_mov_b32_dpp v10, v16 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000040FF9C: 7E1402FA FF016110
	v_mov_b32_dpp v17, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000040FFA4: 7E2202FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 00000040FFAC: D5010005 21AA0B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 00000040FFB4: BF8701D1
	v_add_f32_e32 v5, v5, v17                                  // 00000040FFB8: 060A2305
	v_mad_i64_i32 v[3:4], null, 0x1400, v8, s[4:5]             // 00000040FFBC: D6FF7C03 001210FF 00001400
	v_add_f32_e32 v8, v15, v14                                 // 00000040FFC8: 06101D0F
	v_sub_f32_e32 v14, v15, v14                                // 00000040FFCC: 081C1D0F
	v_cndmask_b32_e64 v15, -v16, v16, vcc_lo                   // 00000040FFD0: D501000F 21AA2110
	v_mov_b32_dpp v6, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000040FFD8: 7E0C02FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 00000040FFE0: D5010008 21AA1108
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000040FFE8: BF870234
	v_mov_b32_dpp v16, v14 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000040FFEC: 7E2002FA FF01610E
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 00000040FFF4: D501000E 21AA1D0E
	v_cmp_eq_u32_e32 vcc_lo, 0, v11                            // 00000040FFFC: 7C941680
	v_dual_add_f32 v6, v8, v6 :: v_dual_lshlrev_b32 v7, 3, v9  // 000000410000: C9220D08 06061283
	v_add_f32_e32 v8, v15, v10                                 // 000000410008: 0610150F
	s_delay_alu instid0(VALU_DEP_4)                            // 00000041000C: BF870004
	v_add_f32_e32 v10, v14, v16                                // 000000410010: 0614210E
	v_mov_b32_dpp v16, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000410014: 7E2002FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 00000041001C: D5010005 21AA0B05
	v_mov_b32_dpp v11, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000410024: 7E1602FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 00000041002C: D5010006 21AA0D06
	v_mov_b32_dpp v15, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000410034: 7E1E02FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 00000041003C: D501000A 21AA150A
	v_add_f32_e32 v5, v5, v16                                  // 000000410044: 060A2105
	v_mov_b32_dpp v14, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000410048: 7E1C02FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000410050: D5010008 21AA1108
	v_add_f32_e32 v6, v6, v11                                  // 000000410058: 060C1706
	v_add_f32_e32 v10, v10, v15                                // 00000041005C: 06141F0A
	v_mov_b32_dpp v15, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000410060: 7E1E02FA FF016405
	v_and_b32_e32 v12, 4, v0                                   // 000000410068: 36180084
	v_add_f32_e32 v8, v8, v14                                  // 00000041006C: 06101D08
	v_mov_b32_dpp v11, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000410070: 7E1602FA FF016406
	v_mov_b32_dpp v14, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000410078: 7E1C02FA FF01640A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000410080: BF8701C4
	v_cmp_eq_u32_e32 vcc_lo, 0, v12                            // 000000410084: 7C941880
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 000000410088: D5010006 21AA0D06
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000410090: D5010005 21AA0B05
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 000000410098: D501000A 21AA150A
	v_add_f32_e32 v6, v6, v11                                  // 0000004100A0: 060C1706
	s_delay_alu instid0(VALU_DEP_3)                            // 0000004100A4: BF870003
	v_add_f32_e32 v5, v5, v15                                  // 0000004100A8: 060A1F05
	v_mov_b32_dpp v12, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000004100AC: 7E1802FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 0000004100B4: D5010008 21AA1108
	v_cmp_eq_u32_e32 vcc_lo, 0, v13                            // 0000004100BC: 7C941A80
	v_add_f32_e32 v10, v10, v14                                // 0000004100C0: 06141D0A
	v_mov_b32_dpp v11, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004100C4: 7E1602FA FF016806
	v_mov_b32_dpp v14, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004100CC: 7E1C02FA FF016805
	v_add_f32_e32 v8, v8, v12                                  // 0000004100D4: 06101908
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 0000004100D8: D5010006 21AA0D06
	v_mov_b32_dpp v13, v10 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004100E0: 7E1A02FA FF01680A
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 0000004100E8: D5010005 21AA0B05
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 0000004100F0: D501000A 21AA150A
	v_mov_b32_dpp v12, v8 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004100F8: 7E1802FA FF016808
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000410100: D5010008 21AA1108
	v_add_f32_e32 v6, v6, v11                                  // 000000410108: 060C1706
	v_cmp_gt_u32_e32 vcc_lo, 16, v9                            // 00000041010C: 7C981290
	v_add_f32_e32 v5, v5, v14                                  // 000000410110: 060A1D05
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000410114: BF870214
	v_dual_add_f32 v9, v10, v13 :: v_dual_add_f32 v8, v8, v12  // 000000410118: C9081B0A 09081908
	v_mov_b32_e32 v10, v6                                      // 000000410120: 7E140306
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 000000410124: D5010006 21AA0D06
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000041012C: BF870214
	v_mov_b32_e32 v13, v5                                      // 000000410130: 7E1A0305
	v_mov_b32_e32 v12, v9                                      // 000000410134: 7E180309
	v_cndmask_b32_e64 v11, -v8, v8, vcc_lo                     // 000000410138: D501000B 21AA1108
	v_permlanex16_b32 v8, v8, s7, 0xfedcba98                   // 000000410140: D65C0008 03FC0F08 FEDCBA98
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 00000041014C: D5010005 21AA0B05
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000410154: D5010009 21AA1309
	v_permlanex16_b32 v10, v10, s7, 0xfedcba98                 // 00000041015C: D65C000A 03FC0F0A FEDCBA98
	v_permlanex16_b32 v12, v12, s7, 0xfedcba98                 // 000000410168: D65C000C 03FC0F0C FEDCBA98
	v_permlanex16_b32 v13, v13, s7, 0xfedcba98                 // 000000410174: D65C000D 03FC0F0D FEDCBA98
	.long 0xd7006a01                                           // 000000410180: D7006A01
	v_cndmask_b32_e32 v1, v3, v1, vcc_lo                       // 000000410184: 02020303
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000410188: BF8700D1
	v_add_co_ci_u32_e64 v2, null, v4, v2, vcc_lo               // 00000041018C: D5207C02 01AA0504
	v_dual_add_f32 v3, v11, v8 :: v_dual_add_f32 v4, v6, v10   // 000000410194: C908110B 03041506
	v_add_f32_e32 v6, v9, v12                                  // 00000041019C: 060C1909
	v_add_f32_e32 v5, v5, v13                                  // 0000004101A0: 060A1B05
	.long 0xd7006a01                                           // 0000004101A4: D7006A01
	v_cndmask_b32_e32 v1, v1, v7, vcc_lo                       // 0000004101A8: 02020F01
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 0000004101AC: D5207C02 01AA0480
	v_fma_mixhi_f16 v3, v3, s8, 0                              // 0000004101B4: CC220003 02001103
	v_fma_mixlo_f16 v3, v4, s8, 0                              // 0000004101BC: CC210003 02001104
	v_fma_mixhi_f16 v4, v5, s8, 0                              // 0000004101C4: CC220004 02001105
	v_fma_mixlo_f16 v4, v6, s8, 0                              // 0000004101CC: CC210004 02001106
	global_store_b64 v[1:2], v[3:4], off                       // 0000004101D4: DC6E0000 007C0301
	s_or_b32 exec_lo, exec_lo, s6                              // 0000004101DC: 8C7E067E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000004101E0: BF870009
	s_and_b32 vcc_lo, exec_lo, s3                              // 0000004101E4: 8B6A037E
	s_cbranch_vccnz 4                                          // 0000004101E8: BFA40004 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi8ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3fc>
	s_nop 0                                                    // 0000004101EC: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000004101F0: BFB60003
	s_endpgm                                                   // 0000004101F4: BFB00000
	s_cbranch_execz 65532                                      // 0000004101F8: BFA5FFFC <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi8ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	s_clause 0x3                                               // 0000004101FC: BF850003
	s_load_b32 s3, s[0:1], 0x120                               // 000000410200: F40000C0 F8000120
	s_load_b32 s4, s[0:1], 0x7c                                // 000000410208: F4000100 F800007C
	s_load_b32 s5, s[0:1], 0xc4                                // 000000410210: F4000140 F80000C4
	s_load_b32 s6, s[0:1], 0x10c                               // 000000410218: F4000180 F800010C
	v_lshrrev_b32_e32 v35, 5, v0                               // 000000410220: 32460085
	v_and_b32_e32 v36, 31, v0                                  // 000000410224: 3648009F
	s_waitcnt lgkmcnt(0)                                       // 000000410228: BF89FC07
	s_cmp_gt_i32 s3, 1                                         // 00000041022C: BF028103
	s_cselect_b32 s7, -1, 0                                    // 000000410230: 980780C1
	s_cmp_ge_i32 s2, s4                                        // 000000410234: BF030402
	s_cselect_b32 s4, -1, 0                                    // 000000410238: 980480C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000041023C: BF870009
	s_and_b32 s4, s7, s4                                       // 000000410240: 8B040407
	s_cmp_gt_i32 s3, 2                                         // 000000410244: BF028203
	v_cndmask_b32_e64 v1, 0, 1, s4                             // 000000410248: D5010001 00110280
	s_cselect_b32 s7, -1, 0                                    // 000000410250: 980780C1
	s_cmp_ge_i32 s2, s5                                        // 000000410254: BF030502
	s_cselect_b32 s5, -1, 0                                    // 000000410258: 980580C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000041025C: BF870009
	s_and_b32 s4, s7, s5                                       // 000000410260: 8B040507
	s_cmp_gt_i32 s3, 3                                         // 000000410264: BF028303
	v_readfirstlane_b32 s5, v1                                 // 000000410268: 7E0A0501
	s_cselect_b32 s3, -1, 0                                    // 00000041026C: 980380C1
	s_cmp_ge_i32 s2, s6                                        // 000000410270: BF030602
	s_cselect_b32 s6, -1, 0                                    // 000000410274: 980680C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 000000410278: BF8704D9
	s_and_b32 s3, s3, s6                                       // 00000041027C: 8B030603
	s_and_b32 s4, s4, exec_lo                                  // 000000410280: 8B047E04
	s_cselect_b32 s4, 2, s5                                    // 000000410284: 98040582
	s_and_b32 s3, s3, exec_lo                                  // 000000410288: 8B037E03
	s_cselect_b32 s3, 3, s4                                    // 00000041028C: 98030483
	s_mulk_i32 s3, 0x48                                        // 000000410290: B8030048
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000410294: BF870009
	s_add_u32 s4, s0, s3                                       // 000000410298: 80040300
	s_addc_u32 s5, s1, 0                                       // 00000041029C: 82058001
	s_clause 0x3                                               // 0000004102A0: BF850003
	s_load_b32 s28, s[4:5], 0x38                               // 0000004102A4: F4000702 F8000038
	s_load_b64 s[34:35], s[4:5], 0x40                          // 0000004102AC: F4040882 F8000040
	s_load_b128 s[20:23], s[4:5], 0x28                         // 0000004102B4: F4080502 F8000028
	s_load_b64 s[24:25], s[4:5], 0x20                          // 0000004102BC: F4040602 F8000020
	s_waitcnt lgkmcnt(0)                                       // 0000004102C4: BF89FC07
	s_abs_i32 s3, s21                                          // 0000004102C8: BE831515
	s_sub_i32 s2, s2, s23                                      // 0000004102CC: 81821702
	s_cvt_f32_u32 s6, s3                                       // 0000004102D0: BE866503
	s_sub_i32 s7, 0, s3                                        // 0000004102D4: 81870380
	s_abs_i32 s8, s2                                           // 0000004102D8: BE881502
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000004102DC: BF870299
	v_rcp_iflag_f32_e32 v1, s6                                 // 0000004102E0: 7E025606
	v_readfirstlane_b32 s6, v1                                 // 0000004102E4: 7E0C0501
	s_mul_f32 s6, s6, 0x4f7ffffe                               // 0000004102E8: A206FF06 4F7FFFFE
	s_delay_alu instid0(SALU_CYCLE_3) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 0000004102F0: BF87059B
	s_cvt_u32_f32 s6, s6                                       // 0000004102F4: BE866706
	s_mul_i32 s7, s7, s6                                       // 0000004102F8: 96070607
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000004102FC: BF870499
	s_mul_hi_u32 s7, s6, s7                                    // 000000410300: 96870706
	s_add_i32 s6, s6, s7                                       // 000000410304: 81060706
	s_xor_b32 s7, s2, s21                                      // 000000410308: 8D071502
	s_mul_hi_u32 s6, s8, s6                                    // 00000041030C: 96860608
	s_ashr_i32 s7, s7, 31                                      // 000000410310: 86079F07
	s_mul_i32 s9, s6, s3                                       // 000000410314: 96090306
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000410318: BF870009
	s_sub_i32 s8, s8, s9                                       // 00000041031C: 81880908
	s_add_i32 s9, s6, 1                                        // 000000410320: 81098106
	s_sub_i32 s10, s8, s3                                      // 000000410324: 818A0308
	s_cmp_ge_u32 s8, s3                                        // 000000410328: BF090308
	s_cselect_b32 s6, s9, s6                                   // 00000041032C: 98060609
	s_cselect_b32 s8, s10, s8                                  // 000000410330: 9808080A
	s_add_i32 s9, s6, 1                                        // 000000410334: 81098106
	s_cmp_ge_u32 s8, s3                                        // 000000410338: BF090308
	s_cselect_b32 s3, s9, s6                                   // 00000041033C: 98030609
	s_load_b256 s[8:15], s[4:5], null                          // 000000410340: F40C0202 F8000000
	s_xor_b32 s3, s3, s7                                       // 000000410348: 8D030703
	s_ashr_i32 s23, s19, 31                                    // 00000041034C: 86179F13
	s_sub_i32 s26, s3, s7                                      // 000000410350: 819A0703
	s_lshr_b32 s4, s23, 25                                     // 000000410354: 85049917
	s_mul_i32 s3, s26, s21                                     // 000000410358: 9603151A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 00000041035C: BF8704D9
	s_sub_i32 s30, s2, s3                                      // 000000410360: 819E0302
	s_add_i32 s2, s19, s4                                      // 000000410364: 81020413
	s_mul_i32 s27, s22, s30                                    // 000000410368: 961B1E16
	s_ashr_i32 s2, s2, 7                                       // 00000041036C: 86028702
	s_add_i32 s3, s27, s22                                     // 000000410370: 8103161B
	s_min_i32 s2, s2, s3                                       // 000000410374: 89020302
	s_mov_b32 s3, exec_lo                                      // 000000410378: BE83007E
	s_sub_i32 s2, s2, s27                                      // 00000041037C: 81821B02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000410380: BF870499
	s_lshl_b32 s7, s2, 3                                       // 000000410384: 84078302
	.long 0xd4c3007e                                           // 000000410388: D4C3007E
	v_cndmask_b32_e32 v1, s7, v35, vcc_lo                      // 00000041038C: 02024607
	s_xor_b32 s3, exec_lo, s3                                  // 000000410390: 8D03037E
	v_lshlrev_b32_e32 v2, 3, v36                               // 000000410394: 30044883
	s_and_not1_saveexec_b32 s22, s3                            // 000000410398: BE963003
	s_cbranch_execz 289                                        // 00000041039C: BFA50121 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi8ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0xa24>
	s_abs_i32 s29, s2                                          // 0000004103A0: BE9D1502
	v_and_b32_e32 v3, 1, v0                                    // 0000004103A4: 36060081
	s_cvt_f32_u32 s3, s29                                      // 0000004103A8: BE83651D
	v_lshlrev_b32_e32 v2, 3, v36                               // 0000004103AC: 30044883
	v_lshlrev_b32_e32 v8, 7, v35                               // 0000004103B0: 30104687
	v_and_b32_e32 v6, 8, v0                                    // 0000004103B4: 360C0088
	v_rcp_iflag_f32_e32 v1, s3                                 // 0000004103B8: 7E025603
	s_sub_i32 s3, 0, s29                                       // 0000004103BC: 81831D80
	s_ashr_i32 s37, s2, 31                                     // 0000004103C0: 86259F02
	s_lshl_b32 s38, s2, 8                                      // 0000004103C4: 84268802
	s_lshl_b32 s6, s2, 7                                       // 0000004103C8: 84068702
	.long 0xd44a0002                                           // 0000004103CC: D44A0002
	v_cndmask_b32_e32 v1, 0, v3, vcc_lo                        // 0000004103D0: 02020680
	v_lshl_or_b32 v3, v35, 8, v2                               // 0000004103D4: D6560003 04091123
	v_lshl_add_u32 v8, s27, 7, v8                              // 0000004103DC: D6460008 04210E1B
	s_mul_i32 s39, s37, 0x1400                                 // 0000004103E4: 9627FF25 00001400
	s_add_i32 s31, s18, -1                                     // 0000004103EC: 811FC112
	v_dual_mul_f32 v1, 0x4f7ffffe, v1 :: v_dual_and_b32 v4, 2, v0// 0000004103F0: C8E402FF 01040082 4F7FFFFE
	v_subrev_nc_u32_e32 v3, s39, v3                            // 0000004103FC: 4E060627
	s_mov_b32 s33, s19                                         // 000000410400: BEA10013
	s_mov_b32 s36, 0                                           // 000000410404: BEA40080
	s_delay_alu instid0(VALU_DEP_2)                            // 000000410408: BF870002
	v_cvt_u32_f32_e32 v5, v1                                   // 00000041040C: 7E0A0F01
	v_and_b32_e32 v1, 4, v0                                    // 000000410410: 36020084
	s_sub_i32 s39, 0, s6                                       // 000000410414: 81A70680
	s_mov_b32 s40, 0x76543210                                  // 000000410418: BEA800FF 76543210
	s_mov_b32 s41, 0x3db504f3                                  // 000000410420: BEA900FF 3DB504F3
	.long 0xd72c0007                                           // 000000410428: D72C0007
	v_cndmask_b32_e32 v1, s3, v5, vcc_lo                       // 00000041042C: 02020A03
	.long 0xd44a0003                                           // 000000410430: D44A0003
	v_cndmask_b32_e32 v1, 0, v4, vcc_lo                        // 000000410434: 02020880
	.long 0xd44a0004                                           // 000000410438: D44A0004
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000041043C: 02020280
	v_lshl_or_b32 v1, v36, 2, v8                               // 000000410440: D6560001 04210524
	v_cmp_gt_u32_e32 vcc_lo, 16, v36                           // 000000410448: 7C984890
	.long 0xd72d0007                                           // 00000041044C: D72D0007
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 000000410450: 02020F05
	s_delay_alu instid0(VALU_DEP_1)                            // 000000410454: BF870001
	v_dual_mov_b32 v5, v35 :: v_dual_add_nc_u32 v4, v5, v7     // 000000410458: CA200123 05040F05
	.long 0xd44a0005                                           // 000000410460: D44A0005
	v_cndmask_b32_e32 v1, 0, v6, vcc_lo                        // 000000410464: 02020C80
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000410468: BF870092
	.long 0xd72d0006                                           // 00000041046C: D72D0006
	v_cndmask_b32_e32 v1, v5, v4, vcc_lo                       // 000000410470: 02020905
	.long 0xd72c0007                                           // 000000410474: D72C0007
	v_cndmask_b32_e32 v0, v6, v29, vcc_lo                      // 000000410478: 02003B06
	v_add_nc_u32_e32 v8, 1, v6                                 // 00000041047C: 4A100C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000410480: BF870092
	v_sub_nc_u32_e32 v7, v5, v7                                // 000000410484: 4C0E0F05
	v_subrev_nc_u32_e32 v9, s29, v7                            // 000000410488: 4E120E1D
	.long 0xd44b0006                                           // 00000041048C: D44B0006
	v_cndmask_b32_e32 v1, s29, v7, vcc_lo                      // 000000410490: 02020E1D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000410494: BF870191
	v_cndmask_b32_e64 v6, v6, v8, s6                           // 000000410498: D5010006 001A1106
	v_cndmask_b32_e64 v7, v7, v9, s6                           // 0000004104A0: D5010007 001A1307
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004104A8: BF870112
	v_add_nc_u32_e32 v8, 1, v6                                 // 0000004104AC: 4A100C81
	.long 0xd44b0006                                           // 0000004104B0: D44B0006
	v_cndmask_b32_e32 v1, s29, v7, vcc_lo                      // 0000004104B4: 02020E1D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004104B8: BF870091
	v_cndmask_b32_e64 v6, v6, v8, s6                           // 0000004104BC: D5010006 001A1106
	v_xor_b32_e32 v10, s37, v6                                 // 0000004104C4: 3A140C25
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000004104C8: BF870121
	v_subrev_nc_u32_e32 v11, s37, v10                          // 0000004104CC: 4E161425
	.long 0xd72c000a                                           // 0000004104D0: D72C000A
	v_cndmask_b32_e32 v1, 0x1400, v10, vcc_lo                  // 0000004104D4: 020214FF 00001400
	v_min_i32_e32 v8, s31, v11                                 // 0000004104DC: 2210161F
	v_mad_u64_u32 v[6:7], null, s39, v11, v[1:2]               // 0000004104E0: D6FE7C06 04061627
	.long 0xd72c000b                                           // 0000004104E8: D72C000B
	v_cndmask_b32_e32 v1, s38, v11, vcc_lo                     // 0000004104EC: 02021626
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004104F0: BF870193
	v_mad_i64_i32 v[8:9], null, v8, s33, 0                     // 0000004104F4: D6FF7C08 02004308
	v_ashrrev_i32_e32 v7, 31, v6                               // 0000004104FC: 340E0C9F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000410500: BF870193
	v_sub_nc_u32_e32 v10, v10, v11                             // 000000410504: 4C14170A
	.long 0xd73c0008                                           // 000000410508: D73C0008
	v_cndmask_b32_e32 v1, 1, v8, vcc_lo                        // 00000041050C: 02021081
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000410510: BF870193
	.long 0xd73c0006                                           // 000000410514: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000410518: 02020C81
	v_add_nc_u32_e32 v10, v3, v10                              // 00000041051C: 4A141503
	v_add_nc_u32_e32 v3, 0x800, v3                             // 000000410520: 4A0606FF 00000800
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000410528: BF870094
	.long 0xd700060c                                           // 00000041052C: D700060C
	v_cndmask_b32_e32 v1, s16, v8, vcc_lo                      // 000000410530: 02021010
	v_add_co_ci_u32_e64 v13, null, s17, v9, s6                 // 000000410534: D5207C0D 001A1211
	s_waitcnt lgkmcnt(0)                                       // 00000041053C: BF89FC07
	.long 0xd7000608                                           // 000000410540: D7000608
	v_cndmask_b32_e32 v1, s10, v6, vcc_lo                      // 000000410544: 02020C0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000410548: BF8700A1
	v_add_co_ci_u32_e64 v9, null, s11, v7, s6                  // 00000041054C: D5207C09 001A0E0B
	.long 0xd7000606                                           // 000000410554: D7000606
	v_cndmask_b32_e32 v1, v12, v6, vcc_lo                      // 000000410558: 02020D0C
	v_add_co_ci_u32_e64 v7, null, v13, v7, s6                  // 00000041055C: D5207C07 001A0F0D
	global_load_b64 v[6:7], v[6:7], off                        // 000000410564: DC560000 067C0006
	global_load_b64 v[8:9], v[8:9], off                        // 00000041056C: DC560000 087C0008
	s_waitcnt vmcnt(1)                                         // 000000410574: BF8907F7
	.long 0x7e1a3907                                           // 000000410578: 7E1A3907
	v_and_b32_e32 v7, 0xffff0000, v7                           // 00000041057C: 360E0EFF FFFF0000
	.long 0x7e183906                                           // 000000410584: 7E183906
	v_and_b32_e32 v6, 0xffff0000, v6                           // 000000410588: 360C0CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000410590: BF8701B4
	v_lshlrev_b32_e32 v13, 16, v13                             // 000000410594: 301A1A90
	s_waitcnt vmcnt(0)                                         // 000000410598: BF8903F7
	v_fma_mix_f32 v7, v9, v7, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 00000041059C: CC200807 8A020F09
	v_fma_mix_f32 v6, v8, v6, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 0000004105A4: CC200806 8A020D08
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000004105AC: BF8700B2
	v_fma_mix_f32 v14, v9, v13, v7 op_sel_hi:[1,0,0]           // 0000004105B0: CC20000E 0C1E1B09
	v_fma_mix_f32 v7, v9, v13, -v7 op_sel_hi:[1,0,0]           // 0000004105B8: CC200007 8C1E1B09
	v_lshlrev_b32_e32 v12, 16, v12                             // 0000004105C0: 30181890
	v_fma_mix_f32 v15, v8, v12, v6 op_sel_hi:[1,0,0]           // 0000004105C4: CC20000F 0C1A1908
	v_fma_mix_f32 v6, v8, v12, -v6 op_sel_hi:[1,0,0]           // 0000004105CC: CC200006 8C1A1908
	v_add_nc_u32_e32 v5, 8, v5                                 // 0000004105D4: 4A0A0A88
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000004105D8: BF870223
	v_dual_sub_f32 v12, v15, v14 :: v_dual_add_nc_u32 v1, 0x400, v1// 0000004105DC: C9601D0F 0C0002FF 00000400
	v_add_f32_e32 v8, v15, v14                                 // 0000004105E8: 06101D0F
	v_dual_add_f32 v9, v7, v6 :: v_dual_sub_f32 v6, v6, v7     // 0000004105EC: C90A0D07 09060F06
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004105F4: BF870214
	.long 0xd4430006                                           // 0000004105F8: D4430006
	v_cndmask_b32_e32 v1, s7, v5, vcc_lo                       // 0000004105FC: 02020A07
	v_mov_b32_dpp v14, v12 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000410600: 7E1C02FA FF01610C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000410608: BF870214
	v_mov_b32_dpp v7, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000041060C: 7E0E02FA FF016108
	v_mov_b32_dpp v13, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000410614: 7E1A02FA FF016109
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 00000041061C: D5010008 200A1108
	v_cndmask_b32_e64 v9, -v9, v9, s2                          // 000000410624: D5010009 200A1309
	v_mov_b32_dpp v15, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000041062C: 7E1E02FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s2                          // 000000410634: D5010006 200A0D06
	v_cndmask_b32_e64 v12, -v12, v12, s2                       // 00000041063C: D501000C 200A190C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000410644: BF870124
	v_dual_add_f32 v7, v8, v7 :: v_dual_add_f32 v8, v9, v13    // 000000410648: C9080F08 07081B09
	s_or_b32 s36, s6, s36                                      // 000000410650: 8C242406
	v_dual_add_f32 v6, v6, v15 :: v_dual_add_f32 v9, v12, v14  // 000000410654: C9081F06 06081D0C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000041065C: BF870192
	v_mov_b32_dpp v12, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000410660: 7E1802FA FF016207
	v_mov_b32_dpp v13, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000410668: 7E1A02FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s3                          // 000000410670: D5010008 200E1108
	v_cndmask_b32_e64 v7, -v7, v7, s3                          // 000000410678: D5010007 200E0F07
	v_mov_b32_dpp v14, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000410680: 7E1C02FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 000000410688: D5010009 200E1309
	v_mov_b32_dpp v15, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000410690: 7E1E02FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, s3                          // 000000410698: D5010006 200E0D06
	v_dual_add_f32 v8, v8, v13 :: v_dual_add_f32 v7, v7, v12   // 0000004106A0: C9081B08 08061907
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004106A8: BF870114
	v_add_f32_e32 v9, v9, v14                                  // 0000004106AC: 06121D09
	v_mov_b32_dpp v13, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000004106B0: 7E1A02FA FF016408
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004106B8: BF870193
	v_mov_b32_dpp v12, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000004106BC: 7E1802FA FF016407
	v_mov_b32_dpp v14, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000004106C4: 7E1C02FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s4                          // 0000004106CC: D5010009 20121309
	v_add_f32_e32 v6, v6, v15                                  // 0000004106D4: 060C1F06
	v_cndmask_b32_e64 v7, -v7, v7, s4                          // 0000004106D8: D5010007 20120F07
	v_cndmask_b32_e64 v8, -v8, v8, s4                          // 0000004106E0: D5010008 20121108
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004106E8: BF870214
	v_add_f32_e32 v9, v9, v14                                  // 0000004106EC: 06121D09
	v_mov_b32_dpp v15, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000004106F0: 7E1E02FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s4                          // 0000004106F8: D5010006 20120D06
	v_add_f32_e32 v7, v7, v12                                  // 000000410700: 060E1907
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000410704: BF870224
	v_mov_b32_dpp v14, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000410708: 7E1C02FA FF016809
	v_cndmask_b32_e64 v9, -v9, v9, s5                          // 000000410710: D5010009 20161309
	v_add_f32_e32 v6, v6, v15                                  // 000000410718: 060C1F06
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000041071C: BF870224
	v_mov_b32_dpp v12, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000410720: 7E1802FA FF016807
	v_cndmask_b32_e64 v7, -v7, v7, s5                          // 000000410728: D5010007 20160F07
	v_dual_add_f32 v8, v8, v13 :: v_dual_add_f32 v9, v9, v14   // 000000410730: C9081B08 08081D09
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000410738: BF870224
	v_mov_b32_dpp v15, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000041073C: 7E1E02FA FF016806
	v_cndmask_b32_e64 v6, -v6, v6, s5                          // 000000410744: D5010006 20160D06
	v_add_f32_e32 v7, v7, v12                                  // 00000041074C: 060E1907
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000410750: BF870224
	v_mov_b32_dpp v13, v8 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000410754: 7E1A02FA FF016808
	v_cndmask_b32_e64 v8, -v8, v8, s5                          // 00000041075C: D5010008 20161108
	v_add_f32_e32 v6, v6, v15                                  // 000000410764: 060C1F06
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000410768: BF870091
	v_dual_add_f32 v8, v8, v13 :: v_dual_mov_b32 v15, v6       // 00000041076C: C9101B08 080E0106
	v_mov_b32_e32 v13, v8                                      // 000000410774: 7E1A0308
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 000000410778: D5010006 21AA0D06
	s_delay_alu instid0(VALU_DEP_3)                            // 000000410780: BF870003
	v_permlanex16_b32 v15, v15, s40, 0xfedcba98                // 000000410784: D65C000F 03FC510F FEDCBA98
	v_mov_b32_e32 v12, v7                                      // 000000410790: 7E180307
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000410794: D5010007 21AA0F07
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 00000041079C: D5010008 21AA1108
	v_permlanex16_b32 v13, v13, s40, 0xfedcba98                // 0000004107A4: D65C000D 03FC510D FEDCBA98
	v_add_f32_e32 v11, v6, v15                                 // 0000004107B0: 06161F06
	v_permlanex16_b32 v12, v12, s40, 0xfedcba98                // 0000004107B4: D65C000C 03FC510C FEDCBA98
	v_mov_b32_e32 v14, v9                                      // 0000004107C0: 7E1C0309
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 0000004107C4: D5010009 21AA1309
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004107CC: BF870193
	v_add_f32_e32 v7, v7, v12                                  // 0000004107D0: 060E1907
	v_permlanex16_b32 v14, v14, s40, 0xfedcba98                // 0000004107D4: D65C000E 03FC510E FEDCBA98
	v_add_f32_e32 v8, v8, v13                                  // 0000004107E0: 06101B08
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004107E4: BF870193
	v_fma_mixlo_f16 v6, v7, s41, 0                             // 0000004107E8: CC210006 02005307
	v_add_f32_e32 v9, v9, v14                                  // 0000004107F0: 06121D09
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000004107F4: BF8701A3
	v_fma_mixhi_f16 v6, v8, s41, 0                             // 0000004107F8: CC220006 02005308
	v_fma_mixhi_f16 v7, v11, s41, 0                            // 000000410800: CC220007 0200530B
	v_fma_mixlo_f16 v7, v9, s41, 0                             // 000000410808: CC210007 02005309
	ds_store_b64 v10, v[6:7]                                   // 000000410810: D9340000 0000060A
	s_and_not1_b32 exec_lo, exec_lo, s36                       // 000000410818: 917E247E
	s_cbranch_execnz 65298                                     // 00000041081C: BFA6FF12 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi8ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x668>
	s_or_b32 exec_lo, exec_lo, s36                             // 000000410820: 8C7E247E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000410824: BF870009
	s_or_b32 exec_lo, exec_lo, s22                             // 000000410828: 8C7E167E
	s_ashr_i32 s2, s7, 31                                      // 00000041082C: 86029F07
	s_lshr_b32 s4, s23, 28                                     // 000000410830: 85049C17
	s_lshr_b32 s2, s2, 29                                      // 000000410834: 85029D02
	s_add_i32 s4, s19, s4                                      // 000000410838: 81040413
	s_add_i32 s2, s2, s7                                       // 00000041083C: 81020702
	s_lshl_b32 s3, s27, 3                                      // 000000410840: 8403831B
	s_add_i32 s2, s2, 7                                        // 000000410844: 81028702
	v_dual_mov_b32 v45, 0 :: v_dual_mov_b32 v102, 0            // 000000410848: CA100080 2D660080
	s_ashr_i32 s2, s2, 3                                       // 000000410850: 86028302
	v_dual_mov_b32 v103, 0 :: v_dual_mov_b32 v104, 0           // 000000410854: CA100080 67680080
	.long 0xd72c0001                                           // 00000041085C: D72C0001
	v_cndmask_b32_e32 v1, s2, v35, vcc_lo                      // 000000410860: 02024602
	v_dual_mov_b32 v105, 0 :: v_dual_mov_b32 v106, 0           // 000000410864: CA100080 696A0080
	v_mov_b32_e32 v107, 0                                      // 00000041086C: 7ED60280
	s_waitcnt lgkmcnt(0)                                       // 000000410870: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 000000410874: BC7C0000
	s_barrier                                                  // 000000410878: BFBD0000
	buffer_gl0_inv                                             // 00000041087C: E0AC0000 00000000
	v_add_nc_u32_e32 v3, s2, v1                                // 000000410884: 4A060202
	s_ashr_i32 s2, s4, 4                                       // 000000410888: 86028404
	s_ashr_i32 s4, s3, 31                                      // 00000041088C: 86049F03
	s_mul_hi_i32 s5, s26, s2                                   // 000000410890: 9705021A
	s_mul_i32 s2, s26, s2                                      // 000000410894: 9602021A
	v_min_i32_e32 v101, s7, v3                                 // 000000410898: 22CA0607
	s_add_u32 s2, s2, s3                                       // 00000041089C: 80020302
	s_addc_u32 s3, s5, s4                                      // 0000004108A0: 82030405
	s_mul_hi_u32 s4, s2, 0x300                                 // 0000004108A4: 9684FF02 00000300
	s_mulk_i32 s3, 0x300                                       // 0000004108AC: B8030300
	v_cmp_lt_i32_e32 vcc_lo, v1, v101                          // 0000004108B0: 7C82CB01
	s_add_i32 s5, s4, s3                                       // 0000004108B4: 81050304
	s_mul_i32 s4, s2, 0x300                                    // 0000004108B8: 9604FF02 00000300
	s_and_saveexec_b32 s3, vcc_lo                              // 0000004108C0: BE83206A
	s_cbranch_execz 24                                         // 0000004108C4: BFA50018 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi8ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0xb28>
	s_add_u32 s6, s8, s4                                       // 0000004108C8: 80060408
	s_addc_u32 s7, s9, s5                                      // 0000004108CC: 82070509
	v_lshlrev_b32_e32 v5, 2, v36                               // 0000004108D0: 300A4882
	v_mad_i64_i32 v[3:4], null, 0x300, v1, s[6:7]              // 0000004108D4: D6FF7C03 001A02FF 00000300
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004108E0: BF870091
	.long 0xd7000203                                           // 0000004108E4: D7000203
	v_cndmask_b32_e32 v1, v3, v5, vcc_lo                       // 0000004108E8: 02020B03
	v_add_co_ci_u32_e64 v4, null, 0, v4, s2                    // 0000004108EC: D5207C04 000A0880
	s_clause 0x5                                               // 0000004108F4: BF850005
	global_load_b32 v102, v[3:4], off                          // 0000004108F8: DC520000 667C0003
	global_load_b32 v103, v[3:4], off offset:128               // 000000410900: DC520080 677C0003
	global_load_b32 v104, v[3:4], off offset:256               // 000000410908: DC520100 687C0003
	global_load_b32 v105, v[3:4], off offset:384               // 000000410910: DC520180 697C0003
	global_load_b32 v106, v[3:4], off offset:512               // 000000410918: DC520200 6A7C0003
	global_load_b32 v107, v[3:4], off offset:640               // 000000410920: DC520280 6B7C0003
	s_or_b32 exec_lo, exec_lo, s3                              // 000000410928: 8C7E037E
	v_dual_mov_b32 v100, 0 :: v_dual_mov_b32 v99, 0            // 00000041092C: CA100080 64620080
	v_dual_mov_b32 v98, 0 :: v_dual_mov_b32 v97, 0             // 000000410934: CA100080 62600080
	v_dual_mov_b32 v96, 0 :: v_dual_mov_b32 v95, 0             // 00000041093C: CA100080 605E0080
	v_dual_mov_b32 v94, 0 :: v_dual_mov_b32 v93, 0             // 000000410944: CA100080 5E5C0080
	v_dual_mov_b32 v92, 0 :: v_dual_mov_b32 v91, 0             // 00000041094C: CA100080 5C5A0080
	v_dual_mov_b32 v90, 0 :: v_dual_mov_b32 v89, 0             // 000000410954: CA100080 5A580080
	v_dual_mov_b32 v88, 0 :: v_dual_mov_b32 v87, 0             // 00000041095C: CA100080 58560080
	v_dual_mov_b32 v86, 0 :: v_dual_mov_b32 v85, 0             // 000000410964: CA100080 56540080
	v_dual_mov_b32 v84, 0 :: v_dual_mov_b32 v83, 0             // 00000041096C: CA100080 54520080
	v_dual_mov_b32 v82, 0 :: v_dual_mov_b32 v81, 0             // 000000410974: CA100080 52500080
	v_dual_mov_b32 v80, 0 :: v_dual_mov_b32 v79, 0             // 00000041097C: CA100080 504E0080
	v_dual_mov_b32 v78, 0 :: v_dual_mov_b32 v77, 0             // 000000410984: CA100080 4E4C0080
	v_dual_mov_b32 v76, 0 :: v_dual_mov_b32 v75, 0             // 00000041098C: CA100080 4C4A0080
	v_dual_mov_b32 v74, 0 :: v_dual_mov_b32 v73, 0             // 000000410994: CA100080 4A480080
	v_dual_mov_b32 v72, 0 :: v_dual_mov_b32 v71, 0             // 00000041099C: CA100080 48460080
	v_dual_mov_b32 v70, 0 :: v_dual_mov_b32 v69, 0             // 0000004109A4: CA100080 46440080
	v_dual_mov_b32 v68, 0 :: v_dual_mov_b32 v67, 0             // 0000004109AC: CA100080 44420080
	v_dual_mov_b32 v66, 0 :: v_dual_mov_b32 v65, 0             // 0000004109B4: CA100080 42400080
	v_dual_mov_b32 v64, 0 :: v_dual_mov_b32 v63, 0             // 0000004109BC: CA100080 403E0080
	v_dual_mov_b32 v62, 0 :: v_dual_mov_b32 v61, 0             // 0000004109C4: CA100080 3E3C0080
	v_dual_mov_b32 v60, 0 :: v_dual_mov_b32 v59, 0             // 0000004109CC: CA100080 3C3A0080
	v_dual_mov_b32 v58, 0 :: v_dual_mov_b32 v57, 0             // 0000004109D4: CA100080 3A380080
	v_dual_mov_b32 v56, 0 :: v_dual_mov_b32 v55, 0             // 0000004109DC: CA100080 38360080
	v_dual_mov_b32 v54, 0 :: v_dual_mov_b32 v53, 0             // 0000004109E4: CA100080 36340080
	v_dual_mov_b32 v52, 0 :: v_dual_mov_b32 v51, 0             // 0000004109EC: CA100080 34320080
	v_dual_mov_b32 v50, 0 :: v_dual_mov_b32 v49, 0             // 0000004109F4: CA100080 32300080
	v_dual_mov_b32 v48, 0 :: v_dual_mov_b32 v47, 0             // 0000004109FC: CA100080 302E0080
	v_dual_mov_b32 v46, 0 :: v_dual_mov_b32 v43, 0             // 000000410A04: CA100080 2E2A0080
	v_dual_mov_b32 v44, 0 :: v_dual_mov_b32 v41, 0             // 000000410A0C: CA100080 2C280080
	v_dual_mov_b32 v42, 0 :: v_dual_mov_b32 v39, 0             // 000000410A14: CA100080 2A260080
	v_dual_mov_b32 v40, 0 :: v_dual_mov_b32 v37, 0             // 000000410A1C: CA100080 28240080
	v_mov_b32_e32 v38, 0                                       // 000000410A24: 7E4C0280
	s_ashr_i32 s27, s26, 31                                    // 000000410A28: 861B9F1A
	s_and_saveexec_b32 s3, vcc_lo                              // 000000410A2C: BE83206A
	s_cbranch_execz 1358                                       // 000000410A30: BFA5054E <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi8ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x216c>
	v_or_b32_e32 v4, 4, v2                                     // 000000410A34: 38080484
	v_mad_u32_u24 v7, v36, 24, 0x2f0                           // 000000410A38: D60B0007 03FD3124 000002F0
	v_mad_i64_i32 v[2:3], null, 0x300, v1, s[4:5]              // 000000410A44: D6FF7C02 001202FF 00000300
	v_mul_u32_u24_e32 v6, 0x320, v35                           // 000000410A50: 160C46FF 00000320
	v_mul_i32_i24_e32 v8, 0xffffffe8, v36                      // 000000410A58: 121048FF FFFFFFE8
	v_mad_u32_u24 v5, v4, 3, 0x2f0                             // 000000410A60: D60B0005 03FD0704 000002F0
	v_cmp_lt_u32_e32 vcc_lo, 5, v4                             // 000000410A6C: 7C920885
	v_lshrrev_b32_e32 v12, 5, v7                               // 000000410A70: 32180E85
	v_mul_i32_i24_e32 v13, -3, v4                              // 000000410A74: 121A08C3
	v_dual_mov_b32 v40, 0 :: v_dual_and_b32 v7, 0x7e0, v7      // 000000410A78: CA240080 28060EFF 000007E0
	v_lshrrev_b32_e32 v10, 5, v5                               // 000000410A84: 32140A85
	v_dual_mov_b32 v42, 0 :: v_dual_and_b32 v5, 0x7e0, v5      // 000000410A88: CA240080 2A040AFF 000007E0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000410A94: BF870223
	v_add3_u32 v108, v8, v7, 0xfffffd34                        // 000000410A98: D655006C 03FE0F08 FFFFFD34
	v_dual_mov_b32 v38, 0 :: v_dual_and_b32 v11, 16, v0        // 000000410AA4: CA240080 260A0090
	v_subrev_nc_u32_e32 v10, 24, v10                           // 000000410AAC: 4E141498
	v_lshlrev_b32_e32 v9, 2, v36                               // 000000410AB0: 30124882
	v_add3_u32 v109, v13, v5, 0xfffffd34                       // 000000410AB4: D655006D 03FE0B0D FFFFFD34
	s_delay_alu instid0(VALU_DEP_4)                            // 000000410AC0: BF870004
	v_lshl_or_b32 v110, v1, 5, v11                             // 000000410AC4: D656006E 042D0B01
	v_sub_nc_u32_e32 v111, 0, v101                             // 000000410ACC: 4CDECA80
	v_cndmask_b32_e32 v4, 23, v10, vcc_lo                      // 000000410AD0: 02081497
	.long 0xd7006a02                                           // 000000410AD4: D7006A02
	v_cndmask_b32_e32 v1, v2, v9, vcc_lo                       // 000000410AD8: 02021302
	v_mov_b32_e32 v37, 0                                       // 000000410ADC: 7E4A0280
	v_mad_u32_u24 v14, 0x320, v35, v9                          // 000000410AE0: D60B000E 042646FF 00000320
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 000000410AEC: D5207C03 01AA0680
	v_subrev_nc_u32_e32 v9, 24, v12                            // 000000410AF4: 4E121898
	v_add_nc_u32_e32 v10, 1, v4                                // 000000410AF8: 4A140881
	v_cmp_ne_u32_e32 vcc_lo, 0, v36                            // 000000410AFC: 7C9A4880
	v_subrev_nc_u32_e32 v12, 23, v4                            // 000000410B00: 4E180897
	v_lshl_add_u32 v4, v4, 2, v6                               // 000000410B04: D6460004 04190504
	v_dual_mov_b32 v44, 0 :: v_dual_add_nc_u32 v113, 0xa000, v14// 000000410B0C: CA200080 2C701CFF 0000A000
	v_cndmask_b32_e32 v9, 23, v9, vcc_lo                       // 000000410B18: 02121297
	v_cmp_gt_u32_e32 vcc_lo, 24, v10                           // 000000410B1C: 7C981498
	v_add_nc_u32_e32 v112, 1, v1                               // 000000410B20: 4AE00281
	v_dual_mov_b32 v41, 0 :: v_dual_add_nc_u32 v116, 0xa000, v4// 000000410B24: CA200080 297408FF 0000A000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000410B30: BF870254
	v_lshl_add_u32 v7, v9, 2, v6                               // 000000410B34: D6460007 04190509
	v_cndmask_b32_e32 v5, v12, v10, vcc_lo                     // 000000410B3C: 020A150C
	v_cmp_gt_i32_e32 vcc_lo, 23, v9                            // 000000410B40: 7C881297
	v_mov_b32_e32 v39, 0                                       // 000000410B44: 7E4E0280
	v_dual_mov_b32 v43, 0 :: v_dual_mov_b32 v50, 0             // 000000410B48: CA100080 2B320080
	v_lshl_add_u32 v5, v5, 2, v6                               // 000000410B50: D6460005 04190505
	v_cndmask_b32_e64 v8, 0xffffffa4, 4, vcc_lo                // 000000410B58: D5010008 01A908FF FFFFFFA4
	.long 0xd7006a02                                           // 000000410B64: D7006A02
	v_cndmask_b32_e32 v1, s8, v2, vcc_lo                       // 000000410B68: 02020408
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000410B6C: BF8701A1
	v_add_co_ci_u32_e64 v3, null, s9, v3, vcc_lo               // 000000410B70: D5207C03 01AA0609
	v_add_nc_u32_e32 v114, 0xa000, v7                          // 000000410B78: 4AE40EFF 0000A000
	.long 0xd7006a21                                           // 000000410B80: D7006A21
	v_cndmask_b32_e32 v1, 0x300, v2, vcc_lo                    // 000000410B84: 020204FF 00000300
	v_add_nc_u32_e32 v2, v7, v8                                // 000000410B8C: 4A041107
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000410B90: BF8701A4
	v_add_co_ci_u32_e64 v34, null, 0, v3, vcc_lo               // 000000410B94: D5207C22 01AA0680
	v_dual_mov_b32 v48, 0 :: v_dual_add_nc_u32 v117, 0xa000, v5// 000000410B9C: CA200080 30740AFF 0000A000
	v_dual_mov_b32 v46, 0 :: v_dual_add_nc_u32 v115, 0xa000, v2// 000000410BA8: CA200080 2E7204FF 0000A000
	v_dual_mov_b32 v47, 0 :: v_dual_mov_b32 v52, 0             // 000000410BB4: CA100080 2F340080
	v_dual_mov_b32 v49, 0 :: v_dual_mov_b32 v54, 0             // 000000410BBC: CA100080 31360080
	v_dual_mov_b32 v51, 0 :: v_dual_mov_b32 v56, 0             // 000000410BC4: CA100080 33380080
	v_dual_mov_b32 v53, 0 :: v_dual_mov_b32 v58, 0             // 000000410BCC: CA100080 353A0080
	v_dual_mov_b32 v55, 0 :: v_dual_mov_b32 v60, 0             // 000000410BD4: CA100080 373C0080
	v_dual_mov_b32 v57, 0 :: v_dual_mov_b32 v62, 0             // 000000410BDC: CA100080 393E0080
	v_dual_mov_b32 v59, 0 :: v_dual_mov_b32 v64, 0             // 000000410BE4: CA100080 3B400080
	v_dual_mov_b32 v61, 0 :: v_dual_mov_b32 v66, 0             // 000000410BEC: CA100080 3D420080
	v_dual_mov_b32 v63, 0 :: v_dual_mov_b32 v68, 0             // 000000410BF4: CA100080 3F440080
	v_dual_mov_b32 v65, 0 :: v_dual_mov_b32 v70, 0             // 000000410BFC: CA100080 41460080
	v_dual_mov_b32 v67, 0 :: v_dual_mov_b32 v72, 0             // 000000410C04: CA100080 43480080
	v_dual_mov_b32 v69, 0 :: v_dual_mov_b32 v74, 0             // 000000410C0C: CA100080 454A0080
	v_dual_mov_b32 v71, 0 :: v_dual_mov_b32 v76, 0             // 000000410C14: CA100080 474C0080
	v_dual_mov_b32 v73, 0 :: v_dual_mov_b32 v78, 0             // 000000410C1C: CA100080 494E0080
	v_dual_mov_b32 v75, 0 :: v_dual_mov_b32 v80, 0             // 000000410C24: CA100080 4B500080
	v_dual_mov_b32 v77, 0 :: v_dual_mov_b32 v82, 0             // 000000410C2C: CA100080 4D520080
	v_dual_mov_b32 v79, 0 :: v_dual_mov_b32 v84, 0             // 000000410C34: CA100080 4F540080
	v_dual_mov_b32 v81, 0 :: v_dual_mov_b32 v86, 0             // 000000410C3C: CA100080 51560080
	v_dual_mov_b32 v83, 0 :: v_dual_mov_b32 v88, 0             // 000000410C44: CA100080 53580080
	v_dual_mov_b32 v85, 0 :: v_dual_mov_b32 v90, 0             // 000000410C4C: CA100080 555A0080
	v_dual_mov_b32 v87, 0 :: v_dual_mov_b32 v92, 0             // 000000410C54: CA100080 575C0080
	v_dual_mov_b32 v89, 0 :: v_dual_mov_b32 v94, 0             // 000000410C5C: CA100080 595E0080
	v_dual_mov_b32 v91, 0 :: v_dual_mov_b32 v96, 0             // 000000410C64: CA100080 5B600080
	v_dual_mov_b32 v93, 0 :: v_dual_mov_b32 v98, 0             // 000000410C6C: CA100080 5D620080
	v_dual_mov_b32 v95, 0 :: v_dual_mov_b32 v100, 0            // 000000410C74: CA100080 5F640080
	v_mov_b32_e32 v97, 0                                       // 000000410C7C: 7EC20280
	v_mov_b32_e32 v99, 0                                       // 000000410C80: 7EC60280
	v_mov_b32_e32 v45, 0                                       // 000000410C84: 7E5A0280
	s_mov_b32 s4, 0                                            // 000000410C88: BE840080
	s_movk_i32 s5, 0x1eee                                      // 000000410C8C: B0051EEE
	s_branch 1178                                              // 000000410C90: BFA0049A <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi8ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x20fc>
	s_or_b32 exec_lo, exec_lo, s2                              // 000000410C94: 8C7E027E
	ds_load_2addr_b32 v[118:119], v115 offset1:24              // 000000410C98: D8DC1800 76000073
	ds_load_2addr_b32 v[120:121], v117 offset1:24              // 000000410CA0: D8DC1800 78000075
	ds_load_2addr_b32 v[18:19], v114 offset1:24                // 000000410CA8: D8DC1800 12000072
	ds_load_2addr_b32 v[123:124], v116 offset1:24              // 000000410CB0: D8DC1800 7B000074
	ds_load_b128 v[9:12], v110 offset:5120                     // 000000410CB8: DBFC1400 0900006E
	ds_load_b128 v[13:16], v110 offset:10240                   // 000000410CC0: DBFC2800 0D00006E
	ds_load_b128 v[5:8], v110 offset:15360                     // 000000410CC8: DBFC3C00 0500006E
	ds_load_b128 v[1:4], v110 offset:20480                     // 000000410CD0: DBFC5000 0100006E
	.long 0xd7000221                                           // 000000410CD8: D7000221
	v_cndmask_b32_e32 v1, 0x300, v33, vcc_lo                   // 000000410CDC: 020242FF 00000300
	s_delay_alu instid0(VALU_DEP_1)                            // 000000410CE4: BF870001
	v_add_co_ci_u32_e64 v34, null, 0, v34, s2                  // 000000410CE8: D5207C22 000A4480
	s_waitcnt lgkmcnt(7)                                       // 000000410CF0: BF89FC77
	v_dual_mov_b32 v17, v118 :: v_dual_add_nc_u32 v112, 1, v112// 000000410CF4: CA200176 1170E081
	s_waitcnt lgkmcnt(6)                                       // 000000410CFC: BF89FC67
	v_mov_b32_e32 v122, v120                                   // 000000410D00: 7EF40378
	s_waitcnt lgkmcnt(5)                                       // 000000410D04: BF89FC57
	s_delay_alu instid0(VALU_DEP_2)                            // 000000410D08: BF870002
	.long 0xd73d007d                                           // 000000410D0C: D73D007D
	v_cndmask_b32_e32 v1, v108, v17, vcc_lo                    // 000000410D10: 0202236C
	v_mov_b32_e32 v120, v19                                    // 000000410D14: 7EF00313
	s_waitcnt lgkmcnt(4)                                       // 000000410D18: BF89FC47
	.long 0xd73d007a                                           // 000000410D1C: D73D007A
	v_cndmask_b32_e32 v1, v109, v122, vcc_lo                   // 000000410D20: 0202F56D
	ds_load_b128 v[17:20], v110 offset:25600                   // 000000410D24: DBFC6400 1100006E
	ds_load_b128 v[21:24], v110 offset:30720                   // 000000410D2C: DBFC7800 1500006E
	ds_load_b128 v[29:32], v110                                // 000000410D34: DBFC0000 1D00006E
	ds_load_b128 v[25:28], v110 offset:35840                   // 000000410D3C: DBFC8C00 1900006E
	v_add_nc_u32_e32 v110, 32, v110                            // 000000410D44: 4ADCDCA0
	.long 0xd73d0076                                           // 000000410D48: D73D0076
	v_cndmask_b32_e32 v1, v108, v119, vcc_lo                   // 000000410D4C: 0202EF6C
	v_bfe_u32 v119, v125, 9, 16                                // 000000410D50: D6100077 0241137D
	v_bfe_u32 v120, v125, 6, 16                                // 000000410D58: D6100078 02410D7D
	v_bfe_u32 v123, v125, 3, 16                                // 000000410D60: D610007B 0241077D
	v_and_b32_e32 v125, 0xffff, v125                           // 000000410D68: 36FAFAFF 0000FFFF
	v_bfe_u32 v126, v122, 9, 16                                // 000000410D70: D610007E 0241137A
	.long 0xd72c0077                                           // 000000410D78: D72C0077
	v_cndmask_b32_e32 v1, 0x83dcd12d, v119, vcc_lo             // 000000410D7C: 0202EEFF 83DCD12D
	.long 0xd72c0078                                           // 000000410D84: D72C0078
	v_cndmask_b32_e32 v1, 0x83dcd12d, v120, vcc_lo             // 000000410D88: 0202F0FF 83DCD12D
	.long 0xd72c007b                                           // 000000410D90: D72C007B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v123, vcc_lo             // 000000410D94: 0202F6FF 83DCD12D
	.long 0xd72c007d                                           // 000000410D9C: D72C007D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v125, vcc_lo             // 000000410DA0: 0202FAFF 83DCD12D
	v_bfe_u32 v127, v122, 6, 16                                // 000000410DA8: D610007F 02410D7A
	v_bfe_u32 v128, v122, 3, 16                                // 000000410DB0: D6100080 0241077A
	.long 0xd72c007e                                           // 000000410DB8: D72C007E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v126, vcc_lo             // 000000410DBC: 0202FCFF 83DCD12D
	v_sad_u8 v119, v119, 0, 0x6400                             // 000000410DC4: D6220077 03FD0177 00006400
	v_sad_u8 v120, v120, 0, 0x6400                             // 000000410DD0: D6220078 03FD0178 00006400
	v_sad_u8 v123, v123, 0, 0x6400                             // 000000410DDC: D622007B 03FD017B 00006400
	v_sad_u8 v125, v125, 0, 0x6400                             // 000000410DE8: D622007D 03FD017D 00006400
	.long 0xd72c007f                                           // 000000410DF4: D72C007F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v127, vcc_lo             // 000000410DF8: 0202FEFF 83DCD12D
	v_and_b32_e32 v119, 0xffff, v119                           // 000000410E00: 36EEEEFF 0000FFFF
	v_sad_u8 v126, v126, 0, 0x6400                             // 000000410E08: D622007E 03FD017E 00006400
	.long 0xd72c0080                                           // 000000410E14: D72C0080
	v_cndmask_b32_e32 v1, 0x83dcd12d, v128, vcc_lo             // 000000410E18: 020300FF 83DCD12D
	v_lshlrev_b32_e32 v125, 16, v125                           // 000000410E20: 30FAFA90
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000410E24: BF8701A4
	v_lshl_or_b32 v119, v120, 16, v119                         // 000000410E28: D6560077 05DD2178
	v_sad_u8 v127, v127, 0, 0x6400                             // 000000410E30: D622007F 03FD017F 00006400
	v_and_or_b32 v120, 0xffff, v123, v125                      // 000000410E3C: D6570078 05F6F6FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3)                            // 000000410E48: BF870003
	v_pk_fma_f16 v125, v119, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000410E4C: CC0E007D 0BFC0B77 0000C931
	v_and_b32_e32 v122, 0xffff, v122                           // 000000410E58: 36F4F4FF 0000FFFF
	v_and_b32_e32 v126, 0xffff, v126                           // 000000410E60: 36FCFCFF 0000FFFF
	v_sad_u8 v128, v128, 0, 0x6400                             // 000000410E68: D6220080 03FD0180 00006400
	s_waitcnt lgkmcnt(1)                                       // 000000410E74: BF89FC17
	v_dot2acc_f32_f16 v37, v125, v29                           // 000000410E78: 044A3B7D
	.long 0xd72c007a                                           // 000000410E7C: D72C007A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v122, vcc_lo             // 000000410E80: 0202F4FF 83DCD12D
	v_dot2acc_f32_f16 v39, v125, v9                            // 000000410E88: 044E137D
	v_lshl_or_b32 v123, v127, 16, v126                         // 000000410E8C: D656007B 05F9217F
	v_pk_fma_f16 v127, v120, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000410E94: CC0E007F 0BFC0B78 0000C931
	v_dot2acc_f32_f16 v42, v125, v17                           // 000000410EA0: 0454237D
	v_dot2acc_f32_f16 v38, v125, v13                           // 000000410EA4: 044C1B7D
	v_dot2acc_f32_f16 v40, v125, v5                            // 000000410EA8: 04500B7D
	v_pk_fma_f16 v123, v123, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000410EAC: CC0E007B 0BFC0B7B 0000C931
	v_sad_u8 v122, v122, 0, 0x6400                             // 000000410EB8: D622007A 03FD017A 00006400
	v_dot2acc_f32_f16 v39, v127, v10                           // 000000410EC4: 044E157F
	v_dual_dot2acc_f32_f16 v43, v125, v21 :: v_dual_dot2acc_f32_f16 v42, v127, v18// 000000410EC8: CB182B7D 2B2A257F
	v_dot2acc_f32_f16 v37, v127, v30                           // 000000410ED0: 044A3D7F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000410ED4: BF8701B4
	v_dual_mov_b32 v122, v124 :: v_dual_lshlrev_b32 v129, 16, v122// 000000410ED8: CA22017C 7A80F490
	v_dual_dot2acc_f32_f16 v41, v125, v1 :: v_dual_dot2acc_f32_f16 v40, v127, v6// 000000410EE0: CB18037D 29280D7F
	v_dot2acc_f32_f16 v38, v127, v14                           // 000000410EE8: 044C1D7F
	v_and_or_b32 v124, 0xffff, v128, v129                      // 000000410EEC: D657007C 060700FF 0000FFFF
	v_bfe_u32 v126, v118, 9, 16                                // 000000410EF8: D610007E 02411376
	.long 0xd73d0077                                           // 000000410F00: D73D0077
	v_cndmask_b32_e32 v1, v109, v121, vcc_lo                   // 000000410F04: 0202F36D
	v_and_b32_e32 v128, 0xffff, v118                           // 000000410F08: 3700ECFF 0000FFFF
	v_bfe_u32 v121, v118, 6, 16                                // 000000410F10: D6100079 02410D76
	v_pk_fma_f16 v124, v124, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000410F18: CC0E007C 0BFC0B7C 0000C931
	v_dot2acc_f32_f16 v42, v123, v19                           // 000000410F24: 0454277B
	v_dot2acc_f32_f16 v39, v123, v11                           // 000000410F28: 044E177B
	.long 0xd72c0078                                           // 000000410F2C: D72C0078
	v_cndmask_b32_e32 v1, 0x83dcd12d, v126, vcc_lo             // 000000410F30: 0202FCFF 83DCD12D
	v_bfe_u32 v118, v118, 3, 16                                // 000000410F38: D6100076 02410776
	.long 0xd72c007a                                           // 000000410F40: D72C007A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v128, vcc_lo             // 000000410F44: 020300FF 83DCD12D
	v_dot2acc_f32_f16 v42, v124, v20                           // 000000410F4C: 0454297C
	v_dual_dot2acc_f32_f16 v40, v123, v7 :: v_dual_dot2acc_f32_f16 v39, v124, v12// 000000410F50: CB180F7B 2826197C
	v_dot2acc_f32_f16 v37, v123, v31                           // 000000410F58: 044A3F7B
	v_bfe_u32 v126, v119, 9, 16                                // 000000410F5C: D610007E 02411377
	.long 0xd72c0079                                           // 000000410F64: D72C0079
	v_cndmask_b32_e32 v1, 0x83dcd12d, v121, vcc_lo             // 000000410F68: 0202F2FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000410F70: BF870214
	v_dot2acc_f32_f16 v40, v124, v8                            // 000000410F74: 0450117C
	v_dual_dot2acc_f32_f16 v38, v123, v15 :: v_dual_dot2acc_f32_f16 v37, v124, v32// 000000410F78: CB181F7B 2624417C
	v_dot2acc_f32_f16 v41, v127, v2                            // 000000410F80: 0452057F
	v_sad_u8 v120, v120, 0, 0x6400                             // 000000410F84: D6220078 03FD0178 00006400
	v_bfe_u32 v128, v119, 6, 16                                // 000000410F90: D6100080 02410D77
	s_delay_alu instid0(VALU_DEP_4)                            // 000000410F98: BF870004
	v_dot2acc_f32_f16 v38, v124, v16                           // 000000410F9C: 044C217C
	.long 0xd72c0076                                           // 000000410FA0: D72C0076
	v_cndmask_b32_e32 v1, 0x83dcd12d, v118, vcc_lo             // 000000410FA4: 0202ECFF 83DCD12D
	v_dot2acc_f32_f16 v41, v123, v3                            // 000000410FAC: 0452077B
	v_bfe_u32 v129, v119, 3, 16                                // 000000410FB0: D6100081 02410777
	.long 0xd72c007e                                           // 000000410FB8: D72C007E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v126, vcc_lo             // 000000410FBC: 0202FCFF 83DCD12D
	s_waitcnt lgkmcnt(0)                                       // 000000410FC4: BF89FC07
	v_dual_dot2acc_f32_f16 v44, v125, v25 :: v_dual_and_b32 v119, 0xffff, v119// 000000410FC8: CB24337D 2C76EEFF 0000FFFF
	v_dual_dot2acc_f32_f16 v43, v127, v22 :: v_dual_and_b32 v120, 0xffff, v120// 000000410FD4: CB242D7F 2B78F0FF 0000FFFF
	v_sad_u8 v122, v122, 0, 0x6400                             // 000000410FE0: D622007A 03FD017A 00006400
	v_sad_u8 v121, v121, 0, 0x6400                             // 000000410FEC: D6220079 03FD0179 00006400
	.long 0xd72c0080                                           // 000000410FF8: D72C0080
	v_cndmask_b32_e32 v1, 0x83dcd12d, v128, vcc_lo             // 000000410FFC: 020300FF 83DCD12D
	.long 0xd72c0077                                           // 000000411004: D72C0077
	v_cndmask_b32_e32 v1, 0x83dcd12d, v119, vcc_lo             // 000000411008: 0202EEFF 83DCD12D
	v_sad_u8 v118, v118, 0, 0x6400                             // 000000411010: D6220076 03FD0176 00006400
	v_dual_dot2acc_f32_f16 v43, v123, v23 :: v_dual_lshlrev_b32 v122, 16, v122// 00000041101C: CB222F7B 2B7AF490
	v_sad_u8 v126, v126, 0, 0x6400                             // 000000411024: D622007E 03FD017E 00006400
	v_lshl_or_b32 v120, v121, 16, v120                         // 000000411030: D6560078 05E12179
	.long 0xd72c0079                                           // 000000411038: D72C0079
	v_cndmask_b32_e32 v1, 0x83dcd12d, v129, vcc_lo             // 00000041103C: 020302FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000411044: BF870004
	v_and_or_b32 v118, 0xffff, v118, v122                      // 000000411048: D6570076 05EAECFF 0000FFFF
	v_sad_u8 v119, v119, 0, 0x6400                             // 000000411054: D6220077 03FD0177 00006400
	v_dual_dot2acc_f32_f16 v43, v124, v24 :: v_dual_and_b32 v122, 0xffff, v126// 000000411060: CB24317C 2B7AFCFF 0000FFFF
	v_sad_u8 v126, v128, 0, 0x6400                             // 00000041106C: D622007E 03FD0180 00006400
	v_pk_fma_f16 v128, v120, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000411078: CC0E0080 0BFC0B78 0000C931
	v_pk_fma_f16 v129, v118, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000411084: CC0E0081 0BFC0B76 0000C931
	v_dual_dot2acc_f32_f16 v44, v127, v26 :: v_dual_lshlrev_b32 v119, 16, v119// 000000411090: CB22357F 2C76EE90
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000411098: BF870214
	v_lshl_or_b32 v118, v126, 16, v122                         // 00000041109C: D6560076 05E9217E
	v_dot2acc_f32_f16 v46, v128, v29                           // 0000004110A4: 045C3B80
	v_dot2acc_f32_f16 v47, v128, v9                            // 0000004110A8: 045E1380
	v_sad_u8 v120, v121, 0, 0x6400                             // 0000004110AC: D6220078 03FD0179 00006400
	v_dot2acc_f32_f16 v44, v123, v27                           // 0000004110B8: 0458377B
	v_pk_fma_f16 v130, v118, s5, 0xc931 op_sel_hi:[1,0,0]      // 0000004110BC: CC0E0082 0BFC0B76 0000C931
	v_dot2acc_f32_f16 v41, v124, v4                            // 0000004110C8: 0452097C
	v_dot2acc_f32_f16 v47, v129, v10                           // 0000004110CC: 045E1581
	v_dot2acc_f32_f16 v46, v129, v30                           // 0000004110D0: 045C3D81
	v_and_or_b32 v120, 0xffff, v120, v119                      // 0000004110D4: D6570078 05DEF0FF 0000FFFF
	ds_load_2addr_b32 v[118:119], v115 offset0:48 offset1:72   // 0000004110E0: D8DC4830 76000073
	v_dot2acc_f32_f16 v49, v128, v5                            // 0000004110E8: 04620B80
	v_dot2acc_f32_f16 v44, v124, v28                           // 0000004110EC: 0458397C
	ds_load_2addr_b32 v[123:124], v117 offset0:48 offset1:72   // 0000004110F0: D8DC4830 7B000075
	v_dot2acc_f32_f16 v47, v130, v11                           // 0000004110F8: 045E1782
	v_dot2acc_f32_f16 v46, v130, v31                           // 0000004110FC: 045C3F82
	v_pk_fma_f16 v131, v120, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000411100: CC0E0083 0BFC0B78 0000C931
	ds_load_2addr_b32 v[121:122], v114 offset0:48 offset1:72   // 00000041110C: D8DC4830 79000072
	v_dot2acc_f32_f16 v48, v128, v13                           // 000000411114: 04601B80
	ds_load_2addr_b32 v[126:127], v116 offset0:48 offset1:72   // 000000411118: D8DC4830 7E000074
	v_dual_dot2acc_f32_f16 v49, v129, v6 :: v_dual_dot2acc_f32_f16 v46, v131, v32// 000000411120: CB180D81 312E4183
	v_dot2acc_f32_f16 v51, v128, v17                           // 000000411128: 04662380
	v_dual_dot2acc_f32_f16 v47, v131, v12 :: v_dual_dot2acc_f32_f16 v48, v129, v14// 00000041112C: CB181983 2F301D81
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000411134: BF870193
	v_dual_dot2acc_f32_f16 v49, v130, v7 :: v_dual_dot2acc_f32_f16 v50, v128, v1// 000000411138: CB180F82 31320380
	v_dot2acc_f32_f16 v51, v129, v18                           // 000000411140: 04662581
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000411144: BF870193
	v_dual_dot2acc_f32_f16 v53, v128, v25 :: v_dual_dot2acc_f32_f16 v48, v130, v15// 000000411148: CB183380 35301F82
	v_dual_dot2acc_f32_f16 v49, v131, v8 :: v_dual_dot2acc_f32_f16 v50, v129, v2// 000000411150: CB181183 31320581
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000411158: BF8701C3
	v_dot2acc_f32_f16 v51, v130, v19                           // 00000041115C: 04662782
	s_waitcnt lgkmcnt(2)                                       // 000000411160: BF89FC27
	v_dual_mov_b32 v120, v118 :: v_dual_mov_b32 v125, v123     // 000000411164: CA100176 787C017B
	v_dual_dot2acc_f32_f16 v48, v131, v16 :: v_dual_dot2acc_f32_f16 v53, v129, v26// 00000041116C: CB182183 30343581
	v_dot2acc_f32_f16 v51, v131, v20                           // 000000411174: 04662983
	s_waitcnt lgkmcnt(1)                                       // 000000411178: BF89FC17
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 00000041117C: BF870253
	.long 0xd73d0078                                           // 000000411180: D73D0078
	v_cndmask_b32_e32 v1, v108, v120, vcc_lo                   // 000000411184: 0202F16C
	s_waitcnt lgkmcnt(0)                                       // 000000411188: BF89FC07
	.long 0xd73d007d                                           // 00000041118C: D73D007D
	v_cndmask_b32_e32 v1, v109, v125, vcc_lo                   // 000000411190: 0202FB6D
	v_dot2acc_f32_f16 v50, v130, v3                            // 000000411194: 04640782
	v_dot2acc_f32_f16 v53, v130, v27                           // 000000411198: 046A3782
	v_bfe_u32 v118, v120, 9, 16                                // 00000041119C: D6100076 02411378
	v_and_b32_e32 v121, 0xffff, v120                           // 0000004111A4: 36F2F0FF 0000FFFF
	v_bfe_u32 v123, v120, 6, 16                                // 0000004111AC: D610007B 02410D78
	v_bfe_u32 v126, v125, 9, 16                                // 0000004111B4: D610007E 0241137D
	v_bfe_u32 v120, v120, 3, 16                                // 0000004111BC: D6100078 02410778
	.long 0xd72c0076                                           // 0000004111C4: D72C0076
	v_cndmask_b32_e32 v1, 0x83dcd12d, v118, vcc_lo             // 0000004111C8: 0202ECFF 83DCD12D
	.long 0xd72c0079                                           // 0000004111D0: D72C0079
	v_cndmask_b32_e32 v1, 0x83dcd12d, v121, vcc_lo             // 0000004111D4: 0202F2FF 83DCD12D
	.long 0xd72c007b                                           // 0000004111DC: D72C007B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v123, vcc_lo             // 0000004111E0: 0202F6FF 83DCD12D
	.long 0xd72c007e                                           // 0000004111E8: D72C007E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v126, vcc_lo             // 0000004111EC: 0202FCFF 83DCD12D
	.long 0xd72c0078                                           // 0000004111F4: D72C0078
	v_cndmask_b32_e32 v1, 0x83dcd12d, v120, vcc_lo             // 0000004111F8: 0202F0FF 83DCD12D
	v_bfe_u32 v132, v125, 6, 16                                // 000000411200: D6100084 02410D7D
	v_dot2acc_f32_f16 v50, v131, v4                            // 000000411208: 04640983
	v_bfe_u32 v133, v125, 3, 16                                // 00000041120C: D6100085 0241077D
	v_sad_u8 v118, v118, 0, 0x6400                             // 000000411214: D6220076 03FD0176 00006400
	v_sad_u8 v121, v121, 0, 0x6400                             // 000000411220: D6220079 03FD0179 00006400
	v_sad_u8 v123, v123, 0, 0x6400                             // 00000041122C: D622007B 03FD017B 00006400
	v_sad_u8 v126, v126, 0, 0x6400                             // 000000411238: D622007E 03FD017E 00006400
	v_dot2acc_f32_f16 v52, v128, v21                           // 000000411244: 04682B80
	v_and_b32_e32 v118, 0xffff, v118                           // 000000411248: 36ECECFF 0000FFFF
	v_sad_u8 v120, v120, 0, 0x6400                             // 000000411250: D6220078 03FD0178 00006400
	v_lshlrev_b32_e32 v121, 16, v121                           // 00000041125C: 30F2F290
	v_and_b32_e32 v125, 0xffff, v125                           // 000000411260: 36FAFAFF 0000FFFF
	.long 0xd72c0084                                           // 000000411268: D72C0084
	v_cndmask_b32_e32 v1, 0x83dcd12d, v132, vcc_lo             // 00000041126C: 020308FF 83DCD12D
	v_lshl_or_b32 v118, v123, 16, v118                         // 000000411274: D6560076 05D9217B
	v_and_b32_e32 v123, 0xffff, v126                           // 00000041127C: 36F6FCFF 0000FFFF
	v_dot2acc_f32_f16 v52, v129, v22                           // 000000411284: 04682D81
	v_and_or_b32 v120, 0xffff, v120, v121                      // 000000411288: D6570078 05E6F0FF 0000FFFF
	.long 0xd72c007d                                           // 000000411294: D72C007D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v125, vcc_lo             // 000000411298: 0202FAFF 83DCD12D
	v_pk_fma_f16 v128, v118, s5, 0xc931 op_sel_hi:[1,0,0]      // 0000004112A0: CC0E0080 0BFC0B76 0000C931
	.long 0xd72c0079                                           // 0000004112AC: D72C0079
	v_cndmask_b32_e32 v1, 0x83dcd12d, v133, vcc_lo             // 0000004112B0: 02030AFF 83DCD12D
	v_sad_u8 v126, v132, 0, 0x6400                             // 0000004112B8: D622007E 03FD0184 00006400
	v_pk_fma_f16 v132, v120, s5, 0xc931 op_sel_hi:[1,0,0]      // 0000004112C4: CC0E0084 0BFC0B78 0000C931
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004112D0: BF870004
	v_dual_dot2acc_f32_f16 v53, v131, v28 :: v_dual_dot2acc_f32_f16 v56, v128, v13// 0000004112D4: CB183983 35381B80
	v_dot2acc_f32_f16 v54, v128, v29                           // 0000004112DC: 046C3B80
	v_sad_u8 v125, v125, 0, 0x6400                             // 0000004112E0: D622007D 03FD017D 00006400
	v_dot2acc_f32_f16 v52, v130, v23                           // 0000004112EC: 04682F82
	v_lshl_or_b32 v118, v126, 16, v123                         // 0000004112F0: D6560076 05ED217E
	v_sad_u8 v120, v121, 0, 0x6400                             // 0000004112F8: D6220078 03FD0179 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000411304: BF870214
	v_dual_dot2acc_f32_f16 v54, v132, v30 :: v_dual_lshlrev_b32 v121, 16, v125// 000000411308: CB223D84 3678FA90
	v_dual_dot2acc_f32_f16 v55, v128, v9 :: v_dual_dot2acc_f32_f16 v52, v131, v24// 000000411310: CB181380 37343183
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000411318: BF870224
	v_pk_fma_f16 v123, v118, s5, 0xc931 op_sel_hi:[1,0,0]      // 00000041131C: CC0E007B 0BFC0B76 0000C931
	v_dot2acc_f32_f16 v56, v132, v14                           // 000000411328: 04701D84
	v_and_or_b32 v118, 0xffff, v120, v121                      // 00000041132C: D6570076 05E6F0FF 0000FFFF
	v_dot2acc_f32_f16 v57, v128, v5                            // 000000411338: 04720B80
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000041133C: BF870214
	v_dual_dot2acc_f32_f16 v55, v132, v10 :: v_dual_dot2acc_f32_f16 v54, v123, v31// 000000411340: CB181584 37363F7B
	v_dot2acc_f32_f16 v56, v123, v15                           // 000000411348: 04701F7B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000041134C: BF870214
	v_pk_fma_f16 v126, v118, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000411350: CC0E007E 0BFC0B76 0000C931
	v_dual_dot2acc_f32_f16 v57, v132, v6 :: v_dual_mov_b32 v120, v122// 00000041135C: CB100D84 3978017A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000411364: BF870224
	v_dot2acc_f32_f16 v55, v123, v11                           // 000000411368: 046E177B
	v_dual_mov_b32 v125, v127 :: v_dual_dot2acc_f32_f16 v60, v128, v21// 00000041136C: CA18017F 7D3C2B80
	v_dot2acc_f32_f16 v54, v126, v32                           // 000000411374: 046C417E
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000411378: BF870243
	v_dual_dot2acc_f32_f16 v58, v128, v1 :: v_dual_dot2acc_f32_f16 v55, v126, v12// 00000041137C: CB180380 3A36197E
	v_dot2acc_f32_f16 v57, v123, v7                            // 000000411384: 04720F7B
	.long 0xd73d0076                                           // 000000411388: D73D0076
	v_cndmask_b32_e32 v1, v108, v119, vcc_lo                   // 00000041138C: 0202EF6C
	.long 0xd73d0077                                           // 000000411390: D73D0077
	v_cndmask_b32_e32 v1, v109, v124, vcc_lo                   // 000000411394: 0202F96D
	v_dot2acc_f32_f16 v58, v132, v2                            // 000000411398: 04740584
	v_dot2acc_f32_f16 v56, v126, v16                           // 00000041139C: 0470217E
	v_dot2acc_f32_f16 v57, v126, v8                            // 0000004113A0: 0472117E
	v_dot2acc_f32_f16 v59, v128, v17                           // 0000004113A4: 04762380
	v_bfe_u32 v121, v118, 9, 16                                // 0000004113A8: D6100079 02411376
	v_dot2acc_f32_f16 v58, v123, v3                            // 0000004113B0: 0474077B
	v_and_b32_e32 v122, 0xffff, v118                           // 0000004113B4: 36F4ECFF 0000FFFF
	v_bfe_u32 v124, v119, 9, 16                                // 0000004113BC: D610007C 02411377
	v_dot2acc_f32_f16 v59, v132, v18                           // 0000004113C4: 04762584
	.long 0xd72c0078                                           // 0000004113C8: D72C0078
	v_cndmask_b32_e32 v1, 0x83dcd12d, v121, vcc_lo             // 0000004113CC: 0202F2FF 83DCD12D
	v_bfe_u32 v121, v118, 6, 16                                // 0000004113D4: D6100079 02410D76
	v_dot2acc_f32_f16 v58, v126, v4                            // 0000004113DC: 0474097E
	v_bfe_u32 v118, v118, 3, 16                                // 0000004113E0: D6100076 02410776
	v_dot2acc_f32_f16 v59, v123, v19                           // 0000004113E8: 0476277B
	.long 0xd72c007a                                           // 0000004113EC: D72C007A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v122, vcc_lo             // 0000004113F0: 0202F4FF 83DCD12D
	.long 0xd72c0079                                           // 0000004113F8: D72C0079
	v_cndmask_b32_e32 v1, 0x83dcd12d, v121, vcc_lo             // 0000004113FC: 0202F2FF 83DCD12D
	v_dot2acc_f32_f16 v60, v132, v22                           // 000000411404: 04782D84
	v_sad_u8 v120, v120, 0, 0x6400                             // 000000411408: D6220078 03FD0178 00006400
	v_dot2acc_f32_f16 v59, v126, v20                           // 000000411414: 0476297E
	v_bfe_u32 v125, v119, 6, 16                                // 000000411418: D610007D 02410D77
	.long 0xd72c0076                                           // 000000411420: D72C0076
	v_cndmask_b32_e32 v1, 0x83dcd12d, v118, vcc_lo             // 000000411424: 0202ECFF 83DCD12D
	v_bfe_u32 v127, v119, 3, 16                                // 00000041142C: D610007F 02410777
	v_dual_dot2acc_f32_f16 v61, v128, v25 :: v_dual_and_b32 v120, 0xffff, v120// 000000411434: CB243380 3D78F0FF 0000FFFF
	v_sad_u8 v121, v121, 0, 0x6400                             // 000000411440: D6220079 03FD0179 00006400
	.long 0xd72c007c                                           // 00000041144C: D72C007C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v124, vcc_lo             // 000000411450: 0202F8FF 83DCD12D
	v_and_b32_e32 v119, 0xffff, v119                           // 000000411458: 36EEEEFF 0000FFFF
	v_sad_u8 v122, v122, 0, 0x6400                             // 000000411460: D622007A 03FD017A 00006400
	.long 0xd72c007d                                           // 00000041146C: D72C007D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v125, vcc_lo             // 000000411470: 0202FAFF 83DCD12D
	v_lshl_or_b32 v120, v121, 16, v120                         // 000000411478: D6560078 05E12179
	v_sad_u8 v118, v118, 0, 0x6400                             // 000000411480: D6220076 03FD0176 00006400
	.long 0xd72c0077                                           // 00000041148C: D72C0077
	v_cndmask_b32_e32 v1, 0x83dcd12d, v119, vcc_lo             // 000000411490: 0202EEFF 83DCD12D
	.long 0xd72c0079                                           // 000000411498: D72C0079
	v_cndmask_b32_e32 v1, 0x83dcd12d, v127, vcc_lo             // 00000041149C: 0202FEFF 83DCD12D
	v_sad_u8 v124, v124, 0, 0x6400                             // 0000004114A4: D622007C 03FD017C 00006400
	v_pk_fma_f16 v128, v120, s5, 0xc931 op_sel_hi:[1,0,0]      // 0000004114B0: CC0E0080 0BFC0B78 0000C931
	v_lshlrev_b32_e32 v122, 16, v122                           // 0000004114BC: 30F4F490
	v_dual_dot2acc_f32_f16 v60, v123, v23 :: v_dual_dot2acc_f32_f16 v61, v132, v26// 0000004114C0: CB182F7B 3C3C3584
	v_sad_u8 v119, v119, 0, 0x6400                             // 0000004114C8: D6220077 03FD0177 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004114D4: BF870214
	v_dot2acc_f32_f16 v63, v128, v9                            // 0000004114D8: 047E1380
	v_and_or_b32 v118, 0xffff, v118, v122                      // 0000004114DC: D6570076 05EAECFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000004114E8: BF870234
	v_dual_dot2acc_f32_f16 v61, v123, v27 :: v_dual_and_b32 v122, 0xffff, v124// 0000004114EC: CB24377B 3D7AF8FF 0000FFFF
	v_sad_u8 v124, v125, 0, 0x6400                             // 0000004114F8: D622007C 03FD017D 00006400
	v_sad_u8 v120, v121, 0, 0x6400                             // 000000411504: D6220078 03FD0179 00006400
	v_pk_fma_f16 v129, v118, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000411510: CC0E0081 0BFC0B76 0000C931
	v_dual_dot2acc_f32_f16 v62, v128, v29 :: v_dual_lshlrev_b32 v119, 16, v119// 00000041151C: CB223B80 3E76EE90
	s_delay_alu instid0(VALU_DEP_4)                            // 000000411524: BF870004
	v_lshl_or_b32 v118, v124, 16, v122                         // 000000411528: D6560076 05E9217C
	ds_load_2addr_b32 v[121:122], v114 offset0:96 offset1:120  // 000000411530: D8DC7860 79000072
	v_dot2acc_f32_f16 v61, v126, v28                           // 000000411538: 047A397E
	v_and_or_b32 v120, 0xffff, v120, v119                      // 00000041153C: D6570078 05DEF0FF 0000FFFF
	v_dot2acc_f32_f16 v62, v129, v30                           // 000000411548: 047C3D81
	v_pk_fma_f16 v130, v118, s5, 0xc931 op_sel_hi:[1,0,0]      // 00000041154C: CC0E0082 0BFC0B76 0000C931
	ds_load_2addr_b32 v[118:119], v115 offset0:96 offset1:120  // 000000411558: D8DC7860 76000073
	v_dot2acc_f32_f16 v65, v128, v5                            // 000000411560: 04820B80
	v_pk_fma_f16 v131, v120, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000411564: CC0E0083 0BFC0B78 0000C931
	ds_load_2addr_b32 v[123:124], v117 offset0:96 offset1:120  // 000000411570: D8DC7860 7B000075
	v_dot2acc_f32_f16 v62, v130, v31                           // 000000411578: 047C3F82
	v_dual_dot2acc_f32_f16 v60, v126, v24 :: v_dual_dot2acc_f32_f16 v63, v129, v10// 00000041157C: CB18317E 3C3E1581
	v_dual_dot2acc_f32_f16 v64, v128, v13 :: v_dual_dot2acc_f32_f16 v65, v129, v6// 000000411584: CB181B80 40400D81
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 00000041158C: BF8701D3
	v_dot2acc_f32_f16 v62, v131, v32                           // 000000411590: 047C4183
	ds_load_2addr_b32 v[126:127], v116 offset0:96 offset1:120  // 000000411594: D8DC7860 7E000074
	v_dual_dot2acc_f32_f16 v63, v130, v11 :: v_dual_dot2acc_f32_f16 v64, v129, v14// 00000041159C: CB181782 3F401D81
	v_dual_dot2acc_f32_f16 v66, v128, v1 :: v_dual_dot2acc_f32_f16 v65, v130, v7// 0000004115A4: CB180380 42400F82
	v_dot2acc_f32_f16 v67, v128, v17                           // 0000004115AC: 04862380
	v_dot2acc_f32_f16 v63, v131, v12                           // 0000004115B0: 047E1983
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004115B4: BF870193
	v_dual_dot2acc_f32_f16 v69, v128, v25 :: v_dual_dot2acc_f32_f16 v66, v129, v2// 0000004115B8: CB183380 45420581
	v_dual_dot2acc_f32_f16 v64, v130, v15 :: v_dual_dot2acc_f32_f16 v67, v129, v18// 0000004115C0: CB181F82 40422581
	s_waitcnt lgkmcnt(2)                                       // 0000004115C8: BF89FC27
	v_dual_mov_b32 v120, v118 :: v_dual_dot2acc_f32_f16 v65, v131, v8// 0000004115CC: CA180176 78401183
	s_waitcnt lgkmcnt(1)                                       // 0000004115D4: BF89FC17
	v_dual_dot2acc_f32_f16 v66, v130, v3 :: v_dual_mov_b32 v125, v123// 0000004115D8: CB100782 427C017B
	v_dual_dot2acc_f32_f16 v64, v131, v16 :: v_dual_dot2acc_f32_f16 v67, v130, v19// 0000004115E0: CB182183 40422782
	s_delay_alu instid0(VALU_DEP_3)                            // 0000004115E8: BF870003
	.long 0xd73d0078                                           // 0000004115EC: D73D0078
	v_cndmask_b32_e32 v1, v108, v120, vcc_lo                   // 0000004115F0: 0202F16C
	v_dot2acc_f32_f16 v68, v128, v21                           // 0000004115F4: 04882B80
	s_waitcnt lgkmcnt(0)                                       // 0000004115F8: BF89FC07
	.long 0xd73d007d                                           // 0000004115FC: D73D007D
	v_cndmask_b32_e32 v1, v109, v125, vcc_lo                   // 000000411600: 0202FB6D
	v_dot2acc_f32_f16 v67, v131, v20                           // 000000411604: 04862983
	v_dot2acc_f32_f16 v66, v131, v4                            // 000000411608: 04840983
	v_bfe_u32 v118, v120, 9, 16                                // 00000041160C: D6100076 02411378
	v_dual_dot2acc_f32_f16 v68, v129, v22 :: v_dual_and_b32 v121, 0xffff, v120// 000000411614: CB242D81 4478F0FF 0000FFFF
	v_bfe_u32 v123, v120, 6, 16                                // 000000411620: D610007B 02410D78
	v_bfe_u32 v120, v120, 3, 16                                // 000000411628: D6100078 02410778
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000411630: BF870214
	.long 0xd72c0076                                           // 000000411634: D72C0076
	v_cndmask_b32_e32 v1, 0x83dcd12d, v118, vcc_lo             // 000000411638: 0202ECFF 83DCD12D
	.long 0xd72c0079                                           // 000000411640: D72C0079
	v_cndmask_b32_e32 v1, 0x83dcd12d, v121, vcc_lo             // 000000411644: 0202F2FF 83DCD12D
	v_bfe_u32 v126, v125, 9, 16                                // 00000041164C: D610007E 0241137D
	.long 0xd72c007b                                           // 000000411654: D72C007B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v123, vcc_lo             // 000000411658: 0202F6FF 83DCD12D
	.long 0xd72c0078                                           // 000000411660: D72C0078
	v_cndmask_b32_e32 v1, 0x83dcd12d, v120, vcc_lo             // 000000411664: 0202F0FF 83DCD12D
	v_bfe_u32 v132, v125, 6, 16                                // 00000041166C: D6100084 02410D7D
	v_bfe_u32 v133, v125, 3, 16                                // 000000411674: D6100085 0241077D
	.long 0xd72c007e                                           // 00000041167C: D72C007E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v126, vcc_lo             // 000000411680: 0202FCFF 83DCD12D
	v_sad_u8 v118, v118, 0, 0x6400                             // 000000411688: D6220076 03FD0176 00006400
	v_sad_u8 v121, v121, 0, 0x6400                             // 000000411694: D6220079 03FD0179 00006400
	v_and_b32_e32 v125, 0xffff, v125                           // 0000004116A0: 36FAFAFF 0000FFFF
	v_sad_u8 v123, v123, 0, 0x6400                             // 0000004116A8: D622007B 03FD017B 00006400
	v_sad_u8 v120, v120, 0, 0x6400                             // 0000004116B4: D6220078 03FD0178 00006400
	v_and_b32_e32 v118, 0xffff, v118                           // 0000004116C0: 36ECECFF 0000FFFF
	v_dual_dot2acc_f32_f16 v68, v130, v23 :: v_dual_lshlrev_b32 v121, 16, v121// 0000004116C8: CB222F82 4478F290
	.long 0xd72c0084                                           // 0000004116D0: D72C0084
	v_cndmask_b32_e32 v1, 0x83dcd12d, v132, vcc_lo             // 0000004116D4: 020308FF 83DCD12D
	.long 0xd72c007d                                           // 0000004116DC: D72C007D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v125, vcc_lo             // 0000004116E0: 0202FAFF 83DCD12D
	v_sad_u8 v126, v126, 0, 0x6400                             // 0000004116E8: D622007E 03FD017E 00006400
	v_lshl_or_b32 v118, v123, 16, v118                         // 0000004116F4: D6560076 05D9217B
	v_and_or_b32 v120, 0xffff, v120, v121                      // 0000004116FC: D6570078 05E6F0FF 0000FFFF
	.long 0xd72c0079                                           // 000000411708: D72C0079
	v_cndmask_b32_e32 v1, 0x83dcd12d, v133, vcc_lo             // 00000041170C: 02030AFF 83DCD12D
	v_dual_dot2acc_f32_f16 v69, v129, v26 :: v_dual_dot2acc_f32_f16 v68, v131, v24// 000000411714: CB183581 45443183
	s_delay_alu instid0(VALU_DEP_4)                            // 00000041171C: BF870004
	v_pk_fma_f16 v128, v118, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000411720: CC0E0080 0BFC0B76 0000C931
	v_and_b32_e32 v123, 0xffff, v126                           // 00000041172C: 36F6FCFF 0000FFFF
	v_sad_u8 v126, v132, 0, 0x6400                             // 000000411734: D622007E 03FD0184 00006400
	v_sad_u8 v125, v125, 0, 0x6400                             // 000000411740: D622007D 03FD017D 00006400
	v_pk_fma_f16 v132, v120, s5, 0xc931 op_sel_hi:[1,0,0]      // 00000041174C: CC0E0084 0BFC0B78 0000C931
	v_sad_u8 v120, v121, 0, 0x6400                             // 000000411758: D6220078 03FD0179 00006400
	v_dot2acc_f32_f16 v70, v128, v29                           // 000000411764: 048C3B80
	v_lshl_or_b32 v118, v126, 16, v123                         // 000000411768: D6560076 05ED217E
	v_lshlrev_b32_e32 v121, 16, v125                           // 000000411770: 30F2FA90
	v_dual_dot2acc_f32_f16 v69, v130, v27 :: v_dual_dot2acc_f32_f16 v72, v128, v13// 000000411774: CB183782 45481B80
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000041177C: BF870214
	v_dot2acc_f32_f16 v70, v132, v30                           // 000000411780: 048C3D84
	v_pk_fma_f16 v123, v118, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000411784: CC0E007B 0BFC0B76 0000C931
	v_dot2acc_f32_f16 v71, v128, v9                            // 000000411790: 048E1380
	v_and_or_b32 v118, 0xffff, v120, v121                      // 000000411794: D6570076 05E6F0FF 0000FFFF
	v_dot2acc_f32_f16 v72, v132, v14                           // 0000004117A0: 04901D84
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000004117A4: BF870224
	v_dual_dot2acc_f32_f16 v73, v128, v5 :: v_dual_dot2acc_f32_f16 v70, v123, v31// 0000004117A8: CB180B80 49463F7B
	v_mov_b32_e32 v120, v122                                   // 0000004117B0: 7EF0037A
	v_pk_fma_f16 v126, v118, s5, 0xc931 op_sel_hi:[1,0,0]      // 0000004117B4: CC0E007E 0BFC0B76 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004117C0: BF870214
	v_dual_dot2acc_f32_f16 v71, v132, v10 :: v_dual_dot2acc_f32_f16 v72, v123, v15// 0000004117C4: CB181584 47481F7B
	v_dot2acc_f32_f16 v73, v132, v6                            // 0000004117CC: 04920D84
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004117D0: BF870194
	.long 0xd73d0076                                           // 0000004117D4: D73D0076
	v_cndmask_b32_e32 v1, v108, v119, vcc_lo                   // 0000004117D8: 0202EF6C
	v_dual_dot2acc_f32_f16 v70, v126, v32 :: v_dual_dot2acc_f32_f16 v71, v123, v11// 0000004117DC: CB18417E 4646177B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000004117E4: BF870223
	v_dual_dot2acc_f32_f16 v72, v126, v16 :: v_dual_dot2acc_f32_f16 v73, v123, v7// 0000004117E8: CB18217E 48480F7B
	v_dual_dot2acc_f32_f16 v76, v128, v21 :: v_dual_mov_b32 v125, v127// 0000004117F0: CB102B80 4C7C017F
	v_bfe_u32 v121, v118, 9, 16                                // 0000004117F8: D6100079 02411376
	v_dual_dot2acc_f32_f16 v69, v131, v28 :: v_dual_dot2acc_f32_f16 v74, v128, v1// 000000411800: CB183983 454A0380
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000411808: BF870213
	v_dual_dot2acc_f32_f16 v73, v126, v8 :: v_dual_dot2acc_f32_f16 v76, v132, v22// 00000041180C: CB18117E 494C2D84
	.long 0xd73d0077                                           // 000000411814: D73D0077
	v_cndmask_b32_e32 v1, v109, v124, vcc_lo                   // 000000411818: 0202F96D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000041181C: BF8701C4
	.long 0xd72c0078                                           // 000000411820: D72C0078
	v_cndmask_b32_e32 v1, 0x83dcd12d, v121, vcc_lo             // 000000411824: 0202F2FF 83DCD12D
	v_bfe_u32 v121, v118, 6, 16                                // 00000041182C: D6100079 02410D76
	v_dual_dot2acc_f32_f16 v71, v126, v12 :: v_dual_dot2acc_f32_f16 v74, v132, v2// 000000411834: CB18197E 474A0584
	v_dual_dot2acc_f32_f16 v75, v128, v17 :: v_dual_and_b32 v122, 0xffff, v118// 00000041183C: CB242380 4B7AECFF 0000FFFF
	.long 0xd72c0079                                           // 000000411848: D72C0079
	v_cndmask_b32_e32 v1, 0x83dcd12d, v121, vcc_lo             // 00000041184C: 0202F2FF 83DCD12D
	v_bfe_u32 v118, v118, 3, 16                                // 000000411854: D6100076 02410776
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000041185C: BF870243
	v_dual_dot2acc_f32_f16 v74, v123, v3 :: v_dual_dot2acc_f32_f16 v75, v132, v18// 000000411860: CB18077B 4A4A2584
	v_sad_u8 v120, v120, 0, 0x6400                             // 000000411868: D6220078 03FD0178 00006400
	.long 0xd72c007a                                           // 000000411874: D72C007A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v122, vcc_lo             // 000000411878: 0202F4FF 83DCD12D
	v_bfe_u32 v124, v119, 9, 16                                // 000000411880: D610007C 02411377
	v_dual_dot2acc_f32_f16 v74, v126, v4 :: v_dual_dot2acc_f32_f16 v75, v123, v19// 000000411888: CB18097E 4A4A277B
	s_delay_alu instid0(VALU_DEP_4)                            // 000000411890: BF870004
	v_dual_dot2acc_f32_f16 v77, v128, v25 :: v_dual_and_b32 v120, 0xffff, v120// 000000411894: CB243380 4D78F0FF 0000FFFF
	v_sad_u8 v121, v121, 0, 0x6400                             // 0000004118A0: D6220079 03FD0179 00006400
	v_bfe_u32 v125, v119, 6, 16                                // 0000004118AC: D610007D 02410D77
	.long 0xd72c0076                                           // 0000004118B4: D72C0076
	v_cndmask_b32_e32 v1, 0x83dcd12d, v118, vcc_lo             // 0000004118B8: 0202ECFF 83DCD12D
	v_bfe_u32 v127, v119, 3, 16                                // 0000004118C0: D610007F 02410777
	.long 0xd72c007c                                           // 0000004118C8: D72C007C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v124, vcc_lo             // 0000004118CC: 0202F8FF 83DCD12D
	v_lshl_or_b32 v120, v121, 16, v120                         // 0000004118D4: D6560078 05E12179
	v_sad_u8 v122, v122, 0, 0x6400                             // 0000004118DC: D622007A 03FD017A 00006400
	.long 0xd72c007d                                           // 0000004118E8: D72C007D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v125, vcc_lo             // 0000004118EC: 0202FAFF 83DCD12D
	v_dot2acc_f32_f16 v75, v126, v20                           // 0000004118F4: 0496297E
	.long 0xd72c0079                                           // 0000004118F8: D72C0079
	v_cndmask_b32_e32 v1, 0x83dcd12d, v127, vcc_lo             // 0000004118FC: 0202FEFF 83DCD12D
	v_pk_fma_f16 v128, v120, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000411904: CC0E0080 0BFC0B78 0000C931
	v_and_b32_e32 v119, 0xffff, v119                           // 000000411910: 36EEEEFF 0000FFFF
	v_sad_u8 v118, v118, 0, 0x6400                             // 000000411918: D6220076 03FD0176 00006400
	v_lshlrev_b32_e32 v122, 16, v122                           // 000000411924: 30F4F490
	v_sad_u8 v124, v124, 0, 0x6400                             // 000000411928: D622007C 03FD017C 00006400
	v_dot2acc_f32_f16 v78, v128, v29                           // 000000411934: 049C3B80
	.long 0xd72c0077                                           // 000000411938: D72C0077
	v_cndmask_b32_e32 v1, 0x83dcd12d, v119, vcc_lo             // 00000041193C: 0202EEFF 83DCD12D
	v_dual_dot2acc_f32_f16 v76, v123, v23 :: v_dual_dot2acc_f32_f16 v77, v132, v26// 000000411944: CB182F7B 4C4C3584
	v_and_or_b32 v118, 0xffff, v118, v122                      // 00000041194C: D6570076 05EAECFF 0000FFFF
	v_dual_dot2acc_f32_f16 v79, v128, v9 :: v_dual_and_b32 v122, 0xffff, v124// 000000411958: CB241380 4F7AF8FF 0000FFFF
	v_sad_u8 v124, v125, 0, 0x6400                             // 000000411964: D622007C 03FD017D 00006400
	v_sad_u8 v120, v121, 0, 0x6400                             // 000000411970: D6220078 03FD0179 00006400
	v_sad_u8 v119, v119, 0, 0x6400                             // 00000041197C: D6220077 03FD0177 00006400
	v_pk_fma_f16 v129, v118, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000411988: CC0E0081 0BFC0B76 0000C931
	v_dot2acc_f32_f16 v76, v126, v24                           // 000000411994: 0498317E
	v_lshl_or_b32 v118, v124, 16, v122                         // 000000411998: D6560076 05E9217C
	ds_load_2addr_b32 v[121:122], v114 offset0:144 offset1:168 // 0000004119A0: D8DCA890 79000072
	v_dual_dot2acc_f32_f16 v78, v129, v30 :: v_dual_lshlrev_b32 v119, 16, v119// 0000004119A8: CB223D81 4E76EE90
	v_dot2acc_f32_f16 v77, v123, v27                           // 0000004119B0: 049A377B
	v_pk_fma_f16 v130, v118, s5, 0xc931 op_sel_hi:[1,0,0]      // 0000004119B4: CC0E0082 0BFC0B76 0000C931
	v_dot2acc_f32_f16 v79, v129, v10                           // 0000004119C0: 049E1581
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004119C4: BF870004
	v_and_or_b32 v120, 0xffff, v120, v119                      // 0000004119C8: D6570078 05DEF0FF 0000FFFF
	ds_load_2addr_b32 v[118:119], v115 offset0:144 offset1:168 // 0000004119D4: D8DCA890 76000073
	ds_load_2addr_b32 v[123:124], v117 offset0:144 offset1:168 // 0000004119DC: D8DCA890 7B000075
	v_dot2acc_f32_f16 v78, v130, v31                           // 0000004119E4: 049C3F82
	v_dual_dot2acc_f32_f16 v77, v126, v28 :: v_dual_dot2acc_f32_f16 v80, v128, v13// 0000004119E8: CB18397E 4D501B80
	v_pk_fma_f16 v131, v120, s5, 0xc931 op_sel_hi:[1,0,0]      // 0000004119F0: CC0E0083 0BFC0B78 0000C931
	v_dual_dot2acc_f32_f16 v79, v130, v11 :: v_dual_dot2acc_f32_f16 v82, v128, v1// 0000004119FC: CB181782 4F520380
	ds_load_2addr_b32 v[126:127], v116 offset0:144 offset1:168 // 000000411A04: D8DCA890 7E000074
	v_dual_dot2acc_f32_f16 v81, v128, v5 :: v_dual_dot2acc_f32_f16 v80, v129, v14// 000000411A0C: CB180B80 51501D81
	v_dot2acc_f32_f16 v78, v131, v32                           // 000000411A14: 049C4183
	v_dot2acc_f32_f16 v79, v131, v12                           // 000000411A18: 049E1983
	v_dual_dot2acc_f32_f16 v83, v128, v17 :: v_dual_dot2acc_f32_f16 v82, v129, v2// 000000411A1C: CB182380 53520581
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000411A24: BF870114
	v_dual_dot2acc_f32_f16 v84, v128, v21 :: v_dual_dot2acc_f32_f16 v81, v129, v6// 000000411A28: CB182B80 54500D81
	v_dual_dot2acc_f32_f16 v80, v130, v15 :: v_dual_dot2acc_f32_f16 v83, v129, v18// 000000411A30: CB181F82 50522581
	s_waitcnt lgkmcnt(2)                                       // 000000411A38: BF89FC27
	v_dual_dot2acc_f32_f16 v85, v128, v25 :: v_dual_mov_b32 v120, v118// 000000411A3C: CB103380 55780176
	s_waitcnt lgkmcnt(1)                                       // 000000411A44: BF89FC17
	v_mov_b32_e32 v125, v123                                   // 000000411A48: 7EFA037B
	v_dual_dot2acc_f32_f16 v81, v130, v7 :: v_dual_dot2acc_f32_f16 v80, v131, v16// 000000411A4C: CB180F82 51502183
	v_dot2acc_f32_f16 v82, v130, v3                            // 000000411A54: 04A40782
	.long 0xd73d0078                                           // 000000411A58: D73D0078
	v_cndmask_b32_e32 v1, v108, v120, vcc_lo                   // 000000411A5C: 0202F16C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000411A60: BF870243
	v_dual_dot2acc_f32_f16 v84, v129, v22 :: v_dual_dot2acc_f32_f16 v81, v131, v8// 000000411A64: CB182D81 54501183
	s_waitcnt lgkmcnt(0)                                       // 000000411A6C: BF89FC07
	.long 0xd73d007d                                           // 000000411A70: D73D007D
	v_cndmask_b32_e32 v1, v109, v125, vcc_lo                   // 000000411A74: 0202FB6D
	v_dual_dot2acc_f32_f16 v83, v130, v19 :: v_dual_dot2acc_f32_f16 v82, v131, v4// 000000411A78: CB182782 53520983
	v_bfe_u32 v118, v120, 9, 16                                // 000000411A80: D6100076 02411378
	v_bfe_u32 v123, v120, 6, 16                                // 000000411A88: D610007B 02410D78
	v_dual_dot2acc_f32_f16 v84, v130, v23 :: v_dual_and_b32 v121, 0xffff, v120// 000000411A90: CB242F82 5478F0FF 0000FFFF
	v_bfe_u32 v126, v125, 9, 16                                // 000000411A9C: D610007E 0241137D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000411AA4: BF870214
	.long 0xd72c0076                                           // 000000411AA8: D72C0076
	v_cndmask_b32_e32 v1, 0x83dcd12d, v118, vcc_lo             // 000000411AAC: 0202ECFF 83DCD12D
	.long 0xd72c007b                                           // 000000411AB4: D72C007B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v123, vcc_lo             // 000000411AB8: 0202F6FF 83DCD12D
	v_bfe_u32 v132, v125, 6, 16                                // 000000411AC0: D6100084 02410D7D
	v_dot2acc_f32_f16 v83, v131, v20                           // 000000411AC8: 04A62983
	.long 0xd72c007e                                           // 000000411ACC: D72C007E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v126, vcc_lo             // 000000411AD0: 0202FCFF 83DCD12D
	v_bfe_u32 v120, v120, 3, 16                                // 000000411AD8: D6100078 02410778
	.long 0xd72c0079                                           // 000000411AE0: D72C0079
	v_cndmask_b32_e32 v1, 0x83dcd12d, v121, vcc_lo             // 000000411AE4: 0202F2FF 83DCD12D
	.long 0xd72c0084                                           // 000000411AEC: D72C0084
	v_cndmask_b32_e32 v1, 0x83dcd12d, v132, vcc_lo             // 000000411AF0: 020308FF 83DCD12D
	v_sad_u8 v118, v118, 0, 0x6400                             // 000000411AF8: D6220076 03FD0176 00006400
	v_sad_u8 v123, v123, 0, 0x6400                             // 000000411B04: D622007B 03FD017B 00006400
	.long 0xd72c0078                                           // 000000411B10: D72C0078
	v_cndmask_b32_e32 v1, 0x83dcd12d, v120, vcc_lo             // 000000411B14: 0202F0FF 83DCD12D
	v_bfe_u32 v133, v125, 3, 16                                // 000000411B1C: D6100085 0241077D
	v_sad_u8 v126, v126, 0, 0x6400                             // 000000411B24: D622007E 03FD017E 00006400
	v_and_b32_e32 v118, 0xffff, v118                           // 000000411B30: 36ECECFF 0000FFFF
	v_sad_u8 v121, v121, 0, 0x6400                             // 000000411B38: D6220079 03FD0179 00006400
	v_dot2acc_f32_f16 v84, v131, v24                           // 000000411B44: 04A83183
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000411B48: BF870123
	v_lshl_or_b32 v118, v123, 16, v118                         // 000000411B4C: D6560076 05D9217B
	v_sad_u8 v120, v120, 0, 0x6400                             // 000000411B54: D6220078 03FD0178 00006400
	v_pk_fma_f16 v128, v118, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000411B60: CC0E0080 0BFC0B76 0000C931
	v_and_b32_e32 v123, 0xffff, v126                           // 000000411B6C: 36F6FCFF 0000FFFF
	v_sad_u8 v126, v132, 0, 0x6400                             // 000000411B74: D622007E 03FD0184 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000411B80: BF8701A3
	v_dual_dot2acc_f32_f16 v85, v129, v26 :: v_dual_dot2acc_f32_f16 v88, v128, v13// 000000411B84: CB183581 55581B80
	v_dot2acc_f32_f16 v86, v128, v29                           // 000000411B8C: 04AC3B80
	v_lshl_or_b32 v118, v126, 16, v123                         // 000000411B90: D6560076 05ED217E
	v_dot2acc_f32_f16 v87, v128, v9                            // 000000411B98: 04AE1380
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000411B9C: BF870224
	v_dual_dot2acc_f32_f16 v85, v130, v27 :: v_dual_dot2acc_f32_f16 v90, v128, v1// 000000411BA0: CB183782 555A0380
	v_dot2acc_f32_f16 v91, v128, v17                           // 000000411BA8: 04B62380
	v_pk_fma_f16 v123, v118, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000411BAC: CC0E007B 0BFC0B76 0000C931
	v_lshlrev_b32_e32 v121, 16, v121                           // 000000411BB8: 30F2F290
	v_dot2acc_f32_f16 v92, v128, v21                           // 000000411BBC: 04B82B80
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000411BC0: BF870122
	v_and_or_b32 v120, 0xffff, v120, v121                      // 000000411BC4: D6570078 05E6F0FF 0000FFFF
	.long 0xd72c0079                                           // 000000411BD0: D72C0079
	v_cndmask_b32_e32 v1, 0x83dcd12d, v133, vcc_lo             // 000000411BD4: 02030AFF 83DCD12D
	v_pk_fma_f16 v132, v120, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000411BDC: CC0E0084 0BFC0B78 0000C931
	v_and_b32_e32 v125, 0xffff, v125                           // 000000411BE8: 36FAFAFF 0000FFFF
	v_dot2acc_f32_f16 v85, v131, v28                           // 000000411BF0: 04AA3983
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000411BF4: BF870214
	v_sad_u8 v120, v121, 0, 0x6400                             // 000000411BF8: D6220078 03FD0179 00006400
	v_dot2acc_f32_f16 v86, v132, v30                           // 000000411C04: 04AC3D84
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000411C08: BF870234
	.long 0xd72c007d                                           // 000000411C0C: D72C007D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v125, vcc_lo             // 000000411C10: 0202FAFF 83DCD12D
	v_dot2acc_f32_f16 v88, v132, v14                           // 000000411C18: 04B01D84
	v_dot2acc_f32_f16 v90, v132, v2                            // 000000411C1C: 04B40584
	v_dot2acc_f32_f16 v86, v123, v31                           // 000000411C20: 04AC3F7B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000411C24: BF870193
	v_dot2acc_f32_f16 v88, v123, v15                           // 000000411C28: 04B01F7B
	v_dot2acc_f32_f16 v90, v123, v3                            // 000000411C2C: 04B4077B
	v_sad_u8 v125, v125, 0, 0x6400                             // 000000411C30: D622007D 03FD017D 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000411C3C: BF870091
	v_lshlrev_b32_e32 v121, 16, v125                           // 000000411C40: 30F2FA90
	v_and_or_b32 v118, 0xffff, v120, v121                      // 000000411C44: D6570076 05E6F0FF 0000FFFF
	v_mov_b32_e32 v120, v122                                   // 000000411C50: 7EF0037A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000411C54: BF870232
	v_pk_fma_f16 v121, v118, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000411C58: CC0E0079 0BFC0B76 0000C931
	v_dot2acc_f32_f16 v87, v132, v10                           // 000000411C64: 04AE1584
	v_dot2acc_f32_f16 v89, v128, v5                            // 000000411C68: 04B20B80
	.long 0xd73d0076                                           // 000000411C6C: D73D0076
	v_cndmask_b32_e32 v1, v108, v119, vcc_lo                   // 000000411C70: 0202EF6C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000411C74: BF870193
	v_dual_dot2acc_f32_f16 v86, v121, v32 :: v_dual_dot2acc_f32_f16 v87, v123, v11// 000000411C78: CB184179 5656177B
	v_dual_dot2acc_f32_f16 v88, v121, v16 :: v_dual_dot2acc_f32_f16 v89, v132, v6// 000000411C80: CB182179 58580D84
	v_dot2acc_f32_f16 v92, v132, v22                           // 000000411C88: 04B82D84
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000411C8C: BF870214
	v_bfe_u32 v122, v118, 9, 16                                // 000000411C90: D610007A 02411376
	v_dual_dot2acc_f32_f16 v87, v121, v12 :: v_dual_and_b32 v126, 0xffff, v118// 000000411C98: CB241979 577EECFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000411CA4: BF870214
	v_dot2acc_f32_f16 v89, v123, v7                            // 000000411CA8: 04B20F7B
	v_dual_dot2acc_f32_f16 v91, v132, v18 :: v_dual_dot2acc_f32_f16 v92, v123, v23// 000000411CAC: CB182584 5B5C2F7B
	v_mov_b32_e32 v125, v127                                   // 000000411CB4: 7EFA037F
	.long 0xd72c007a                                           // 000000411CB8: D72C007A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v122, vcc_lo             // 000000411CBC: 0202F4FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000411CC4: BF870214
	v_dot2acc_f32_f16 v89, v121, v8                            // 000000411CC8: 04B21179
	v_dual_dot2acc_f32_f16 v91, v123, v19 :: v_dual_dot2acc_f32_f16 v90, v121, v4// 000000411CCC: CB18277B 5B5A0979
	v_dot2acc_f32_f16 v92, v121, v24                           // 000000411CD4: 04B83179
	.long 0xd73d0077                                           // 000000411CD8: D73D0077
	v_cndmask_b32_e32 v1, v109, v124, vcc_lo                   // 000000411CDC: 0202F96D
	v_bfe_u32 v120, v118, 6, 16                                // 000000411CE0: D6100078 02410D76
	.long 0xd72c007c                                           // 000000411CE8: D72C007C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v126, vcc_lo             // 000000411CEC: 0202FCFF 83DCD12D
	v_sad_u8 v122, v122, 0, 0x6400                             // 000000411CF4: D622007A 03FD017A 00006400
	v_dot2acc_f32_f16 v91, v121, v20                           // 000000411D00: 04B62979
	v_bfe_u32 v118, v118, 3, 16                                // 000000411D04: D6100076 02410776
	.long 0xd72c0078                                           // 000000411D0C: D72C0078
	v_cndmask_b32_e32 v1, 0x83dcd12d, v120, vcc_lo             // 000000411D10: 0202F0FF 83DCD12D
	v_bfe_u32 v125, v119, 9, 16                                // 000000411D18: D610007D 02411377
	v_and_b32_e32 v122, 0xffff, v122                           // 000000411D20: 36F4F4FF 0000FFFF
	v_bfe_u32 v126, v119, 6, 16                                // 000000411D28: D610007E 02410D77
	.long 0xd72c0076                                           // 000000411D30: D72C0076
	v_cndmask_b32_e32 v1, 0x83dcd12d, v118, vcc_lo             // 000000411D34: 0202ECFF 83DCD12D
	v_bfe_u32 v127, v119, 3, 16                                // 000000411D3C: D610007F 02410777
	.long 0xd72c007d                                           // 000000411D44: D72C007D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v125, vcc_lo             // 000000411D48: 0202FAFF 83DCD12D
	v_sad_u8 v124, v124, 0, 0x6400                             // 000000411D50: D622007C 03FD017C 00006400
	v_sad_u8 v120, v120, 0, 0x6400                             // 000000411D5C: D6220078 03FD0178 00006400
	v_dot2acc_f32_f16 v93, v128, v25                           // 000000411D68: 04BA3380
	.long 0xd72c007e                                           // 000000411D6C: D72C007E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v126, vcc_lo             // 000000411D70: 0202FCFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000411D78: BF870214
	v_lshlrev_b32_e32 v124, 16, v124                           // 000000411D7C: 30F8F890
	v_lshl_or_b32 v120, v120, 16, v122                         // 000000411D80: D6560078 05E92178
	v_sad_u8 v125, v125, 0, 0x6400                             // 000000411D88: D622007D 03FD017D 00006400
	v_dot2acc_f32_f16 v93, v132, v26                           // 000000411D94: 04BA3584
	v_sad_u8 v118, v118, 0, 0x6400                             // 000000411D98: D6220076 03FD0176 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000411DA4: BF870224
	v_pk_fma_f16 v120, v120, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000411DA8: CC0E0078 0BFC0B78 0000C931
	v_and_b32_e32 v119, 0xffff, v119                           // 000000411DB4: 36EEEEFF 0000FFFF
	v_dual_dot2acc_f32_f16 v93, v123, v27 :: v_dual_and_b32 v122, 0xffff, v125// 000000411DBC: CB24377B 5D7AFAFF 0000FFFF
	.long 0xd72c007b                                           // 000000411DC8: D72C007B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v127, vcc_lo             // 000000411DCC: 0202FEFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000411DD4: BF870214
	v_dot2acc_f32_f16 v94, v120, v29                           // 000000411DD8: 04BC3B78
	.long 0xd72c0077                                           // 000000411DDC: D72C0077
	v_cndmask_b32_e32 v1, 0x83dcd12d, v119, vcc_lo             // 000000411DE0: 0202EEFF 83DCD12D
	v_and_or_b32 v118, 0xffff, v118, v124                      // 000000411DE8: D6570076 05F2ECFF 0000FFFF
	v_sad_u8 v124, v126, 0, 0x6400                             // 000000411DF4: D622007C 03FD017E 00006400
	v_dot2acc_f32_f16 v96, v120, v13                           // 000000411E00: 04C01B78
	v_dot2acc_f32_f16 v98, v120, v1                            // 000000411E04: 04C40378
	v_dot2acc_f32_f16 v99, v120, v17                           // 000000411E08: 04C62378
	v_pk_fma_f16 v118, v118, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000411E0C: CC0E0076 0BFC0B76 0000C931
	v_sad_u8 v123, v123, 0, 0x6400                             // 000000411E18: D622007B 03FD017B 00006400
	v_sad_u8 v119, v119, 0, 0x6400                             // 000000411E24: D6220077 03FD0177 00006400
	v_lshl_or_b32 v122, v124, 16, v122                         // 000000411E30: D656007A 05E9217C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000411E38: BF870194
	v_dual_dot2acc_f32_f16 v95, v120, v9 :: v_dual_dot2acc_f32_f16 v96, v118, v14// 000000411E3C: CB181378 5F601D76
	v_dual_dot2acc_f32_f16 v94, v118, v30 :: v_dual_lshlrev_b32 v119, 16, v119// 000000411E44: CB223D76 5E76EE90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000411E4C: BF870193
	v_pk_fma_f16 v13, v122, s5, 0xc931 op_sel_hi:[1,0,0]       // 000000411E50: CC0E000D 0BFC0B7A 0000C931
	v_dot2acc_f32_f16 v95, v118, v10                           // 000000411E5C: 04BE1576
	v_dot2acc_f32_f16 v97, v120, v5                            // 000000411E60: 04C20B78
	v_dual_dot2acc_f32_f16 v93, v121, v28 :: v_dual_dot2acc_f32_f16 v100, v120, v21// 000000411E64: CB183979 5D642B78
	v_and_or_b32 v9, 0xffff, v123, v119                        // 000000411E6C: D6570009 05DEF6FF 0000FFFF
	v_dot2acc_f32_f16 v96, v13, v15                            // 000000411E78: 04C01F0D
	v_dot2acc_f32_f16 v94, v13, v31                            // 000000411E7C: 04BC3F0D
	v_dual_dot2acc_f32_f16 v95, v13, v11 :: v_dual_dot2acc_f32_f16 v98, v118, v2// 000000411E80: CB18170D 5F620576
	s_delay_alu instid0(VALU_DEP_4)                            // 000000411E88: BF870004
	v_pk_fma_f16 v9, v9, s5, 0xc931 op_sel_hi:[1,0,0]          // 000000411E8C: CC0E0009 0BFC0B09 0000C931
	v_dot2acc_f32_f16 v97, v118, v6                            // 000000411E98: 04C20D76
	v_dot2acc_f32_f16 v45, v120, v25                           // 000000411E9C: 045A3378
	v_dot2acc_f32_f16 v99, v118, v18                           // 000000411EA0: 04C62576
	v_dot2acc_f32_f16 v100, v118, v22                          // 000000411EA4: 04C82D76
	v_dot2acc_f32_f16 v96, v9, v16                             // 000000411EA8: 04C02109
	v_dot2acc_f32_f16 v95, v9, v12                             // 000000411EAC: 04BE1909
	v_dot2acc_f32_f16 v94, v9, v32                             // 000000411EB0: 04BC4109
	v_dot2acc_f32_f16 v97, v13, v7                             // 000000411EB4: 04C20F0D
	v_dual_dot2acc_f32_f16 v98, v13, v3 :: v_dual_dot2acc_f32_f16 v45, v118, v26// 000000411EB8: CB18070D 622C3576
	v_dual_dot2acc_f32_f16 v100, v13, v23 :: v_dual_add_nc_u32 v1, v111, v112// 000000411EC0: CB202F0D 6400E16F
	v_dot2acc_f32_f16 v99, v13, v19                            // 000000411EC8: 04C6270D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000411ECC: BF870214
	v_dot2acc_f32_f16 v97, v9, v8                              // 000000411ED0: 04C21109
	v_dot2acc_f32_f16 v45, v13, v27                            // 000000411ED4: 045A370D
	v_dot2acc_f32_f16 v98, v9, v4                              // 000000411ED8: 04C40909
	v_cmp_eq_u32_e32 vcc_lo, 1, v1                             // 000000411EDC: 7C940281
	v_dot2acc_f32_f16 v99, v9, v20                             // 000000411EE0: 04C62909
	v_dot2acc_f32_f16 v100, v9, v24                            // 000000411EE4: 04C83109
	v_dot2acc_f32_f16 v45, v9, v28                             // 000000411EE8: 045A3909
	s_or_b32 s4, vcc_lo, s4                                    // 000000411EEC: 8C04046A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000411EF0: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000411EF4: 917E047E
	s_cbranch_execz 27                                         // 000000411EF8: BFA5001B <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi8ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2168>
	s_mov_b32 s2, exec_lo                                      // 000000411EFC: BE82007E
	s_waitcnt vmcnt(4)                                         // 000000411F00: BF8913F7
	ds_store_2addr_b32 v113, v102, v103 offset1:32             // 000000411F04: D8382000 00676671
	s_waitcnt vmcnt(2)                                         // 000000411F0C: BF890BF7
	ds_store_2addr_b32 v113, v104, v105 offset0:64 offset1:96  // 000000411F10: D8386040 00696871
	s_waitcnt vmcnt(0)                                         // 000000411F18: BF8903F7
	ds_store_2addr_b32 v113, v106, v107 offset0:128 offset1:160// 000000411F1C: D838A080 006B6A71
	.long 0xd4c1007e                                           // 000000411F24: D4C1007E
	v_cndmask_b32_e32 v1, v112, v101, vcc_lo                   // 000000411F28: 0202CB70
	s_cbranch_execz 64345                                      // 000000411F2C: BFA5FB59 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi8ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0xe94>
	s_clause 0x5                                               // 000000411F30: BF850005
	global_load_b32 v102, v[33:34], off                        // 000000411F34: DC520000 667C0021
	global_load_b32 v103, v[33:34], off offset:128             // 000000411F3C: DC520080 677C0021
	global_load_b32 v104, v[33:34], off offset:256             // 000000411F44: DC520100 687C0021
	global_load_b32 v105, v[33:34], off offset:384             // 000000411F4C: DC520180 697C0021
	global_load_b32 v106, v[33:34], off offset:512             // 000000411F54: DC520200 6A7C0021
	global_load_b32 v107, v[33:34], off offset:640             // 000000411F5C: DC520280 6B7C0021
	s_branch 64331                                             // 000000411F64: BFA0FB4B <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi8ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0xe94>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000411F68: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000411F6C: BF870009
	s_or_b32 exec_lo, exec_lo, s3                              // 000000411F70: 8C7E037E
	v_dual_mov_b32 v1, v37 :: v_dual_mov_b32 v2, v39           // 000000411F74: CA100125 01020127
	v_dual_mov_b32 v3, v38 :: v_dual_mov_b32 v4, v40           // 000000411F7C: CA100126 03040128
	v_dual_mov_b32 v5, v41 :: v_dual_mov_b32 v6, v42           // 000000411F84: CA100129 0506012A
	v_dual_mov_b32 v7, v43 :: v_dual_mov_b32 v8, v44           // 000000411F8C: CA10012B 0708012C
	v_dual_mov_b32 v9, v46 :: v_dual_mov_b32 v10, v47          // 000000411F94: CA10012E 090A012F
	v_dual_mov_b32 v11, v48 :: v_dual_mov_b32 v12, v49         // 000000411F9C: CA100130 0B0C0131
	v_dual_mov_b32 v13, v50 :: v_dual_mov_b32 v14, v51         // 000000411FA4: CA100132 0D0E0133
	v_dual_mov_b32 v15, v52 :: v_dual_mov_b32 v16, v53         // 000000411FAC: CA100134 0F100135
	v_dual_mov_b32 v17, v54 :: v_dual_mov_b32 v18, v55         // 000000411FB4: CA100136 11120137
	v_dual_mov_b32 v19, v56 :: v_dual_mov_b32 v20, v57         // 000000411FBC: CA100138 13140139
	v_dual_mov_b32 v21, v58 :: v_dual_mov_b32 v22, v59         // 000000411FC4: CA10013A 1516013B
	v_dual_mov_b32 v23, v60 :: v_dual_mov_b32 v24, v61         // 000000411FCC: CA10013C 1718013D
	v_dual_mov_b32 v25, v62 :: v_dual_mov_b32 v26, v63         // 000000411FD4: CA10013E 191A013F
	v_dual_mov_b32 v27, v64 :: v_dual_mov_b32 v28, v65         // 000000411FDC: CA100140 1B1C0141
	v_dual_mov_b32 v29, v66 :: v_dual_mov_b32 v30, v67         // 000000411FE4: CA100142 1D1E0143
	v_dual_mov_b32 v31, v68 :: v_dual_mov_b32 v32, v69         // 000000411FEC: CA100144 1F200145
	v_dual_mov_b32 v33, v70 :: v_dual_mov_b32 v34, v71         // 000000411FF4: CA100146 21220147
	s_waitcnt vmcnt(5)                                         // 000000411FFC: BF8917F7
	v_dual_mov_b32 v101, v72 :: v_dual_mov_b32 v102, v73       // 000000412000: CA100148 65660149
	s_waitcnt vmcnt(3)                                         // 000000412008: BF890FF7
	v_dual_mov_b32 v103, v74 :: v_dual_mov_b32 v104, v75       // 00000041200C: CA10014A 6768014B
	s_waitcnt vmcnt(1)                                         // 000000412014: BF8907F7
	v_dual_mov_b32 v105, v76 :: v_dual_mov_b32 v106, v77       // 000000412018: CA10014C 696A014D
	s_waitcnt vmcnt(0)                                         // 000000412020: BF8903F7
	v_dual_mov_b32 v107, v78 :: v_dual_mov_b32 v108, v79       // 000000412024: CA10014E 6B6C014F
	v_dual_mov_b32 v109, v80 :: v_dual_mov_b32 v110, v81       // 00000041202C: CA100150 6D6E0151
	v_dual_mov_b32 v111, v82 :: v_dual_mov_b32 v112, v83       // 000000412034: CA100152 6F700153
	v_dual_mov_b32 v113, v84 :: v_dual_mov_b32 v114, v85       // 00000041203C: CA100154 71720155
	v_dual_mov_b32 v115, v86 :: v_dual_mov_b32 v116, v87       // 000000412044: CA100156 73740157
	v_dual_mov_b32 v117, v88 :: v_dual_mov_b32 v118, v89       // 00000041204C: CA100158 75760159
	v_dual_mov_b32 v119, v90 :: v_dual_mov_b32 v120, v91       // 000000412054: CA10015A 7778015B
	v_dual_mov_b32 v121, v92 :: v_dual_mov_b32 v122, v93       // 00000041205C: CA10015C 797A015D
	v_dual_mov_b32 v123, v94 :: v_dual_mov_b32 v124, v95       // 000000412064: CA10015E 7B7C015F
	v_dual_mov_b32 v125, v96 :: v_dual_mov_b32 v126, v97       // 00000041206C: CA100160 7D7E0161
	v_dual_mov_b32 v127, v98 :: v_dual_mov_b32 v128, v99       // 000000412074: CA100162 7F800163
	v_dual_mov_b32 v129, v100 :: v_dual_mov_b32 v130, v45      // 00000041207C: CA100164 8182012D
	s_mov_b32 s2, 0x76543210                                   // 000000412084: BE8200FF 76543210
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000041208C: BF870009
	v_permlanex16_b32 v1, v1, s2, 0xfedcba98                   // 000000412090: D65C0001 03FC0501 FEDCBA98
	v_permlanex16_b32 v2, v2, s2, 0xfedcba98                   // 00000041209C: D65C0002 03FC0502 FEDCBA98
	v_permlanex16_b32 v3, v3, s2, 0xfedcba98                   // 0000004120A8: D65C0003 03FC0503 FEDCBA98
	v_permlanex16_b32 v4, v4, s2, 0xfedcba98                   // 0000004120B4: D65C0004 03FC0504 FEDCBA98
	v_permlanex16_b32 v5, v5, s2, 0xfedcba98                   // 0000004120C0: D65C0005 03FC0505 FEDCBA98
	v_permlanex16_b32 v6, v6, s2, 0xfedcba98                   // 0000004120CC: D65C0006 03FC0506 FEDCBA98
	v_permlanex16_b32 v7, v7, s2, 0xfedcba98                   // 0000004120D8: D65C0007 03FC0507 FEDCBA98
	v_permlanex16_b32 v8, v8, s2, 0xfedcba98                   // 0000004120E4: D65C0008 03FC0508 FEDCBA98
	v_permlanex16_b32 v9, v9, s2, 0xfedcba98                   // 0000004120F0: D65C0009 03FC0509 FEDCBA98
	v_permlanex16_b32 v10, v10, s2, 0xfedcba98                 // 0000004120FC: D65C000A 03FC050A FEDCBA98
	v_permlanex16_b32 v11, v11, s2, 0xfedcba98                 // 000000412108: D65C000B 03FC050B FEDCBA98
	v_permlanex16_b32 v12, v12, s2, 0xfedcba98                 // 000000412114: D65C000C 03FC050C FEDCBA98
	v_permlanex16_b32 v13, v13, s2, 0xfedcba98                 // 000000412120: D65C000D 03FC050D FEDCBA98
	v_permlanex16_b32 v14, v14, s2, 0xfedcba98                 // 00000041212C: D65C000E 03FC050E FEDCBA98
	v_permlanex16_b32 v15, v15, s2, 0xfedcba98                 // 000000412138: D65C000F 03FC050F FEDCBA98
	v_permlanex16_b32 v16, v16, s2, 0xfedcba98                 // 000000412144: D65C0010 03FC0510 FEDCBA98
	v_permlanex16_b32 v17, v17, s2, 0xfedcba98                 // 000000412150: D65C0011 03FC0511 FEDCBA98
	v_permlanex16_b32 v18, v18, s2, 0xfedcba98                 // 00000041215C: D65C0012 03FC0512 FEDCBA98
	v_permlanex16_b32 v19, v19, s2, 0xfedcba98                 // 000000412168: D65C0013 03FC0513 FEDCBA98
	v_permlanex16_b32 v20, v20, s2, 0xfedcba98                 // 000000412174: D65C0014 03FC0514 FEDCBA98
	v_permlanex16_b32 v21, v21, s2, 0xfedcba98                 // 000000412180: D65C0015 03FC0515 FEDCBA98
	v_permlanex16_b32 v22, v22, s2, 0xfedcba98                 // 00000041218C: D65C0016 03FC0516 FEDCBA98
	v_permlanex16_b32 v23, v23, s2, 0xfedcba98                 // 000000412198: D65C0017 03FC0517 FEDCBA98
	v_permlanex16_b32 v24, v24, s2, 0xfedcba98                 // 0000004121A4: D65C0018 03FC0518 FEDCBA98
	v_permlanex16_b32 v25, v25, s2, 0xfedcba98                 // 0000004121B0: D65C0019 03FC0519 FEDCBA98
	v_permlanex16_b32 v26, v26, s2, 0xfedcba98                 // 0000004121BC: D65C001A 03FC051A FEDCBA98
	v_permlanex16_b32 v27, v27, s2, 0xfedcba98                 // 0000004121C8: D65C001B 03FC051B FEDCBA98
	v_permlanex16_b32 v28, v28, s2, 0xfedcba98                 // 0000004121D4: D65C001C 03FC051C FEDCBA98
	v_permlanex16_b32 v29, v29, s2, 0xfedcba98                 // 0000004121E0: D65C001D 03FC051D FEDCBA98
	v_permlanex16_b32 v30, v30, s2, 0xfedcba98                 // 0000004121EC: D65C001E 03FC051E FEDCBA98
	v_permlanex16_b32 v31, v31, s2, 0xfedcba98                 // 0000004121F8: D65C001F 03FC051F FEDCBA98
	v_permlanex16_b32 v32, v32, s2, 0xfedcba98                 // 000000412204: D65C0020 03FC0520 FEDCBA98
	v_permlanex16_b32 v33, v33, s2, 0xfedcba98                 // 000000412210: D65C0021 03FC0521 FEDCBA98
	v_permlanex16_b32 v34, v34, s2, 0xfedcba98                 // 00000041221C: D65C0022 03FC0522 FEDCBA98
	v_permlanex16_b32 v101, v101, s2, 0xfedcba98               // 000000412228: D65C0065 03FC0565 FEDCBA98
	v_permlanex16_b32 v102, v102, s2, 0xfedcba98               // 000000412234: D65C0066 03FC0566 FEDCBA98
	v_permlanex16_b32 v103, v103, s2, 0xfedcba98               // 000000412240: D65C0067 03FC0567 FEDCBA98
	v_permlanex16_b32 v104, v104, s2, 0xfedcba98               // 00000041224C: D65C0068 03FC0568 FEDCBA98
	v_permlanex16_b32 v105, v105, s2, 0xfedcba98               // 000000412258: D65C0069 03FC0569 FEDCBA98
	v_permlanex16_b32 v106, v106, s2, 0xfedcba98               // 000000412264: D65C006A 03FC056A FEDCBA98
	v_permlanex16_b32 v107, v107, s2, 0xfedcba98               // 000000412270: D65C006B 03FC056B FEDCBA98
	v_permlanex16_b32 v108, v108, s2, 0xfedcba98               // 00000041227C: D65C006C 03FC056C FEDCBA98
	v_permlanex16_b32 v109, v109, s2, 0xfedcba98               // 000000412288: D65C006D 03FC056D FEDCBA98
	v_permlanex16_b32 v110, v110, s2, 0xfedcba98               // 000000412294: D65C006E 03FC056E FEDCBA98
	v_permlanex16_b32 v111, v111, s2, 0xfedcba98               // 0000004122A0: D65C006F 03FC056F FEDCBA98
	v_permlanex16_b32 v112, v112, s2, 0xfedcba98               // 0000004122AC: D65C0070 03FC0570 FEDCBA98
	v_permlanex16_b32 v113, v113, s2, 0xfedcba98               // 0000004122B8: D65C0071 03FC0571 FEDCBA98
	v_permlanex16_b32 v114, v114, s2, 0xfedcba98               // 0000004122C4: D65C0072 03FC0572 FEDCBA98
	v_permlanex16_b32 v115, v115, s2, 0xfedcba98               // 0000004122D0: D65C0073 03FC0573 FEDCBA98
	v_permlanex16_b32 v116, v116, s2, 0xfedcba98               // 0000004122DC: D65C0074 03FC0574 FEDCBA98
	v_permlanex16_b32 v117, v117, s2, 0xfedcba98               // 0000004122E8: D65C0075 03FC0575 FEDCBA98
	v_permlanex16_b32 v118, v118, s2, 0xfedcba98               // 0000004122F4: D65C0076 03FC0576 FEDCBA98
	v_permlanex16_b32 v119, v119, s2, 0xfedcba98               // 000000412300: D65C0077 03FC0577 FEDCBA98
	v_permlanex16_b32 v120, v120, s2, 0xfedcba98               // 00000041230C: D65C0078 03FC0578 FEDCBA98
	v_permlanex16_b32 v121, v121, s2, 0xfedcba98               // 000000412318: D65C0079 03FC0579 FEDCBA98
	v_permlanex16_b32 v122, v122, s2, 0xfedcba98               // 000000412324: D65C007A 03FC057A FEDCBA98
	v_permlanex16_b32 v123, v123, s2, 0xfedcba98               // 000000412330: D65C007B 03FC057B FEDCBA98
	v_permlanex16_b32 v124, v124, s2, 0xfedcba98               // 00000041233C: D65C007C 03FC057C FEDCBA98
	v_permlanex16_b32 v125, v125, s2, 0xfedcba98               // 000000412348: D65C007D 03FC057D FEDCBA98
	v_permlanex16_b32 v126, v126, s2, 0xfedcba98               // 000000412354: D65C007E 03FC057E FEDCBA98
	v_permlanex16_b32 v127, v127, s2, 0xfedcba98               // 000000412360: D65C007F 03FC057F FEDCBA98
	v_permlanex16_b32 v128, v128, s2, 0xfedcba98               // 00000041236C: D65C0080 03FC0580 FEDCBA98
	v_permlanex16_b32 v129, v129, s2, 0xfedcba98               // 000000412378: D65C0081 03FC0581 FEDCBA98
	v_permlanex16_b32 v130, v130, s2, 0xfedcba98               // 000000412384: D65C0082 03FC0582 FEDCBA98
	.long 0xd44c0002                                           // 000000412390: D44C0002
	v_cndmask_b32_e32 v1, 16, v36, vcc_lo                      // 000000412394: 02024890
	s_barrier                                                  // 000000412398: BFBD0000
	buffer_gl0_inv                                             // 00000041239C: E0AC0000 00000000
	s_and_saveexec_b32 s3, s2                                  // 0000004123A4: BE832002
	s_cbranch_execz 138                                        // 0000004123A8: BFA5008A <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi8ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x27d4>
	v_dual_add_f32 v7, v43, v7 :: v_dual_lshlrev_b32 v36, 2, v36// 0000004123AC: C9220F2B 07244882
	v_dual_add_f32 v10, v47, v10 :: v_dual_add_f32 v9, v46, v9 // 0000004123B4: C908152F 0A08132E
	v_dual_add_f32 v6, v42, v6 :: v_dual_add_f32 v1, v37, v1   // 0000004123BC: C9080D2A 06000325
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000004123C4: BF870243
	v_lshl_or_b32 v36, v35, 12, v36                            // 0000004123C8: D6560024 04911923
	v_add_f32_e32 v2, v39, v2                                  // 0000004123D0: 06040527
	v_dual_add_f32 v12, v49, v12 :: v_dual_add_f32 v11, v48, v11// 0000004123D4: C9081931 0C0A1730
	v_dual_add_f32 v4, v40, v4 :: v_dual_add_f32 v3, v38, v3   // 0000004123DC: C9080928 04020726
	v_dual_add_f32 v14, v51, v14 :: v_dual_add_nc_u32 v37, 0x400, v36// 0000004123E4: C9201D33 0E2448FF 00000400
	v_dual_add_f32 v13, v50, v13 :: v_dual_add_f32 v8, v44, v8 // 0000004123F0: C9081B32 0D08112C
	v_add_f32_e32 v5, v41, v5                                  // 0000004123F8: 060A0B29
	ds_store_2addr_b32 v36, v1, v9 offset1:16                  // 0000004123FC: D8381000 00090124
	v_add_nc_u32_e32 v1, 0x800, v36                            // 000000412404: 4A0248FF 00000800
	v_dual_add_f32 v16, v53, v16 :: v_dual_add_f32 v15, v52, v15// 00000041240C: C9082135 100E1F34
	ds_store_2addr_b32 v36, v2, v10 offset0:128 offset1:144    // 000000412414: D8389080 000A0224
	v_dual_add_f32 v45, v45, v130 :: v_dual_add_nc_u32 v2, 0xc00, v36// 00000041241C: C921052D 2D0248FF 00000C00
	v_dual_add_f32 v100, v100, v129 :: v_dual_add_f32 v99, v99, v128// 000000412428: C9090364 64630163
	v_dual_add_f32 v98, v98, v127 :: v_dual_add_f32 v97, v97, v126// 000000412430: C908FF62 6260FD61
	v_dual_add_f32 v96, v96, v125 :: v_dual_add_f32 v95, v95, v124// 000000412438: C908FB60 605EF95F
	v_dual_add_f32 v94, v94, v123 :: v_dual_add_f32 v93, v93, v122// 000000412440: C908F75E 5E5CF55D
	v_dual_add_f32 v92, v92, v121 :: v_dual_add_f32 v91, v91, v120// 000000412448: C908F35C 5C5AF15B
	v_dual_add_f32 v90, v90, v119 :: v_dual_add_f32 v89, v89, v118// 000000412450: C908EF5A 5A58ED59
	v_dual_add_f32 v88, v88, v117 :: v_dual_add_f32 v87, v87, v116// 000000412458: C908EB58 5856E957
	v_dual_add_f32 v86, v86, v115 :: v_dual_add_f32 v85, v85, v114// 000000412460: C908E756 5654E555
	v_dual_add_f32 v84, v84, v113 :: v_dual_add_f32 v83, v83, v112// 000000412468: C908E354 5452E153
	v_dual_add_f32 v82, v82, v111 :: v_dual_add_f32 v81, v81, v110// 000000412470: C908DF52 5250DD51
	v_dual_add_f32 v80, v80, v109 :: v_dual_add_f32 v79, v79, v108// 000000412478: C908DB50 504ED94F
	v_dual_add_f32 v78, v78, v107 :: v_dual_add_f32 v77, v77, v106// 000000412480: C908D74E 4E4CD54D
	v_dual_add_f32 v76, v76, v105 :: v_dual_add_f32 v75, v75, v104// 000000412488: C908D34C 4C4AD14B
	v_dual_add_f32 v74, v74, v103 :: v_dual_add_f32 v73, v73, v102// 000000412490: C908CF4A 4A48CD49
	v_add_f32_e32 v72, v72, v101                               // 000000412498: 0690CB48
	v_dual_add_f32 v34, v71, v34 :: v_dual_add_f32 v33, v70, v33// 00000041249C: C9084547 22204346
	v_dual_add_f32 v32, v69, v32 :: v_dual_add_f32 v31, v68, v31// 0000004124A4: C9084145 201E3F44
	v_dual_add_f32 v30, v67, v30 :: v_dual_add_f32 v29, v66, v29// 0000004124AC: C9083D43 1E1C3B42
	v_dual_add_f32 v28, v65, v28 :: v_dual_add_f32 v27, v64, v27// 0000004124B4: C9083941 1C1A3740
	v_dual_add_f32 v26, v63, v26 :: v_dual_add_f32 v25, v62, v25// 0000004124BC: C908353F 1A18333E
	v_dual_add_f32 v24, v61, v24 :: v_dual_add_f32 v23, v60, v23// 0000004124C4: C908313D 18162F3C
	v_dual_add_f32 v22, v59, v22 :: v_dual_add_f32 v21, v58, v21// 0000004124CC: C9082D3B 16142B3A
	v_dual_add_f32 v20, v57, v20 :: v_dual_add_f32 v19, v56, v19// 0000004124D4: C9082939 14122738
	v_dual_add_f32 v18, v55, v18 :: v_dual_add_f32 v17, v54, v17// 0000004124DC: C9082537 12102336
	ds_store_2addr_b32 v37, v3, v11 offset1:16                 // 0000004124E4: D8381000 000B0325
	ds_store_2addr_b32 v37, v4, v12 offset0:128 offset1:144    // 0000004124EC: D8389080 000C0425
	ds_store_2addr_b32 v1, v5, v13 offset1:16                  // 0000004124F4: D8381000 000D0501
	ds_store_2addr_b32 v1, v6, v14 offset0:128 offset1:144     // 0000004124FC: D8389080 000E0601
	ds_store_2addr_b32 v2, v7, v15 offset1:16                  // 000000412504: D8381000 000F0702
	ds_store_2addr_b32 v2, v8, v16 offset0:128 offset1:144     // 00000041250C: D8389080 00100802
	ds_store_2addr_b32 v36, v17, v25 offset0:32 offset1:48     // 000000412514: D8383020 00191124
	ds_store_2addr_b32 v36, v18, v26 offset0:160 offset1:176   // 00000041251C: D838B0A0 001A1224
	ds_store_2addr_b32 v37, v19, v27 offset0:32 offset1:48     // 000000412524: D8383020 001B1325
	ds_store_2addr_b32 v37, v20, v28 offset0:160 offset1:176   // 00000041252C: D838B0A0 001C1425
	ds_store_2addr_b32 v1, v21, v29 offset0:32 offset1:48      // 000000412534: D8383020 001D1501
	ds_store_2addr_b32 v1, v22, v30 offset0:160 offset1:176    // 00000041253C: D838B0A0 001E1601
	ds_store_2addr_b32 v2, v23, v31 offset0:32 offset1:48      // 000000412544: D8383020 001F1702
	ds_store_2addr_b32 v2, v24, v32 offset0:160 offset1:176    // 00000041254C: D838B0A0 00201802
	ds_store_2addr_b32 v36, v33, v78 offset0:64 offset1:80     // 000000412554: D8385040 004E2124
	ds_store_2addr_b32 v36, v34, v79 offset0:192 offset1:208   // 00000041255C: D838D0C0 004F2224
	ds_store_2addr_b32 v37, v72, v80 offset0:64 offset1:80     // 000000412564: D8385040 00504825
	ds_store_2addr_b32 v37, v73, v81 offset0:192 offset1:208   // 00000041256C: D838D0C0 00514925
	ds_store_2addr_b32 v1, v74, v82 offset0:64 offset1:80      // 000000412574: D8385040 00524A01
	ds_store_2addr_b32 v1, v75, v83 offset0:192 offset1:208    // 00000041257C: D838D0C0 00534B01
	ds_store_2addr_b32 v2, v76, v84 offset0:64 offset1:80      // 000000412584: D8385040 00544C02
	ds_store_2addr_b32 v2, v77, v85 offset0:192 offset1:208    // 00000041258C: D838D0C0 00554D02
	ds_store_2addr_b32 v36, v86, v94 offset0:96 offset1:112    // 000000412594: D8387060 005E5624
	ds_store_2addr_b32 v36, v87, v95 offset0:224 offset1:240   // 00000041259C: D838F0E0 005F5724
	ds_store_2addr_b32 v37, v88, v96 offset0:96 offset1:112    // 0000004125A4: D8387060 00605825
	ds_store_2addr_b32 v37, v89, v97 offset0:224 offset1:240   // 0000004125AC: D838F0E0 00615925
	ds_store_2addr_b32 v1, v90, v98 offset0:96 offset1:112     // 0000004125B4: D8387060 00625A01
	ds_store_2addr_b32 v1, v91, v99 offset0:224 offset1:240    // 0000004125BC: D838F0E0 00635B01
	ds_store_2addr_b32 v2, v92, v100 offset0:96 offset1:112    // 0000004125C4: D8387060 00645C02
	ds_store_2addr_b32 v2, v93, v45 offset0:224 offset1:240    // 0000004125CC: D838F0E0 002D5D02
	s_or_b32 exec_lo, exec_lo, s3                              // 0000004125D4: 8C7E037E
	v_mov_b32_e32 v1, v0                                       // 0000004125D8: 7E020300
	s_mov_b32 s3, 0                                            // 0000004125DC: BE830080
	s_waitcnt lgkmcnt(0)                                       // 0000004125E0: BF89FC07
	s_barrier                                                  // 0000004125E4: BFBD0000
	buffer_gl0_inv                                             // 0000004125E8: E0AC0000 00000000
	s_nop 0                                                    // 0000004125F0: BF800000
	s_nop 0                                                    // 0000004125F4: BF800000
	s_nop 0                                                    // 0000004125F8: BF800000
	s_nop 0                                                    // 0000004125FC: BF800000
	v_lshlrev_b32_e32 v8, 2, v1                                // 000000412600: 30100282
	v_cmp_lt_u32_e32 vcc_lo, 0x2ff, v1                         // 000000412604: 7C9202FF 000002FF
	ds_load_2addr_stride64_b32 v[2:3], v8 offset1:16           // 00000041260C: D8E01000 02000008
	ds_load_2addr_stride64_b32 v[4:5], v8 offset0:32 offset1:48// 000000412614: D8E03020 04000008
	ds_load_2addr_stride64_b32 v[6:7], v8 offset0:64 offset1:80// 00000041261C: D8E05040 06000008
	s_or_b32 s3, vcc_lo, s3                                    // 000000412624: 8C03036A
	s_waitcnt lgkmcnt(2)                                       // 000000412628: BF89FC27
	v_add_f32_e32 v2, 0, v2                                    // 00000041262C: 06040480
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000412630: BF8700C1
	v_add_f32_e32 v9, v2, v3                                   // 000000412634: 06120702
	ds_load_2addr_stride64_b32 v[2:3], v8 offset0:96 offset1:112// 000000412638: D8E07060 02000008
	s_waitcnt lgkmcnt(2)                                       // 000000412640: BF89FC27
	v_add_f32_e32 v4, v9, v4                                   // 000000412644: 06080909
	v_add_f32_e32 v4, v4, v5                                   // 000000412648: 06080B04
	s_waitcnt lgkmcnt(1)                                       // 00000041264C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000412650: BF870091
	v_add_f32_e32 v4, v4, v6                                   // 000000412654: 06080D04
	v_add_f32_e32 v4, v4, v7                                   // 000000412658: 06080F04
	s_waitcnt lgkmcnt(0)                                       // 00000041265C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000412660: BF8700A1
	v_add_f32_e32 v2, v4, v2                                   // 000000412664: 06040504
	v_add_nc_u32_e32 v4, 0x100, v1                             // 000000412668: 4A0802FF 00000100
	v_dual_add_f32 v2, v2, v3 :: v_dual_mov_b32 v1, v4         // 000000412670: C9100702 02000104
	ds_store_b32 v8, v2 offset:32768                           // 000000412678: D8348000 00000208
	s_and_not1_b32 exec_lo, exec_lo, s3                        // 000000412680: 917E037E
	s_cbranch_execnz 65502                                     // 000000412684: BFA6FFDE <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi8ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2800>
	s_or_b32 exec_lo, exec_lo, s3                              // 000000412688: 8C7E037E
	s_cmp_lt_i32 s21, 2                                        // 00000041268C: BF048215
	s_mov_b32 s3, -1                                           // 000000412690: BE8300C1
	s_cbranch_scc1 212                                         // 000000412694: BFA200D4 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi8ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2be8>
	s_load_b128 s[4:7], s[0:1], 0x1a8                          // 000000412698: F4080100 F80001A8
	s_lshl_b64 s[10:11], s[34:35], 2                           // 0000004126A0: 848A8222
	v_dual_mov_b32 v4, v0 :: v_dual_and_b32 v1, 0x7f, v0       // 0000004126A4: CA240100 040000FF 0000007F
	s_waitcnt lgkmcnt(0)                                       // 0000004126B0: BF89FC07
	s_barrier                                                  // 0000004126B4: BFBD0000
	buffer_gl0_inv                                             // 0000004126B8: E0AC0000 00000000
	v_lshlrev_b32_e32 v2, 2, v1                                // 0000004126C0: 30040282
	s_add_u32 s3, s4, s10                                      // 0000004126C4: 80030A04
	s_addc_u32 s8, s5, s11                                     // 0000004126C8: 82080B05
	s_lshl_b32 s0, s26, 7                                      // 0000004126CC: 8400871A
	s_ashr_i32 s31, s30, 31                                    // 0000004126D0: 861F9F1E
	s_ashr_i32 s1, s0, 31                                      // 0000004126D4: 86019F00
	s_ashr_i32 s9, s20, 31                                     // 0000004126D8: 86099F14
	s_lshl_b64 s[16:17], s[0:1], 2                             // 0000004126DC: 84908200
	s_lshl_b64 s[22:23], s[30:31], 3                           // 0000004126E0: 8496831E
	s_add_u32 s0, s3, s16                                      // 0000004126E4: 80001003
	s_addc_u32 s1, s8, s17                                     // 0000004126E8: 82011108
	.long 0xd7000002                                           // 0000004126EC: D7000002
	v_cndmask_b32_e32 v1, s0, v2, vcc_lo                       // 0000004126F0: 02020400
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004126F4: BF870001
	v_add_co_ci_u32_e64 v3, null, s1, 0, s0                    // 0000004126F8: D5207C03 00010001
	s_mov_b32 s8, s20                                          // 000000412700: BE880014
	s_mov_b32 s1, 0                                            // 000000412704: BE810080
	s_nop 0                                                    // 000000412708: BF800000
	s_nop 0                                                    // 00000041270C: BF800000
	s_nop 0                                                    // 000000412710: BF800000
	s_nop 0                                                    // 000000412714: BF800000
	s_nop 0                                                    // 000000412718: BF800000
	s_nop 0                                                    // 00000041271C: BF800000
	s_nop 0                                                    // 000000412720: BF800000
	s_nop 0                                                    // 000000412724: BF800000
	s_nop 0                                                    // 000000412728: BF800000
	s_nop 0                                                    // 00000041272C: BF800000
	s_nop 0                                                    // 000000412730: BF800000
	s_nop 0                                                    // 000000412734: BF800000
	s_nop 0                                                    // 000000412738: BF800000
	s_nop 0                                                    // 00000041273C: BF800000
	v_lshrrev_b32_e32 v5, 7, v4                                // 000000412740: 320A0887
	v_cmp_lt_u32_e32 vcc_lo, 0x2ff, v4                         // 000000412744: 7C9208FF 000002FF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041274C: BF870092
	.long 0xd7000005                                           // 000000412750: D7000005
	v_cndmask_b32_e32 v1, s22, v5, vcc_lo                      // 000000412754: 02020A16
	v_add_co_ci_u32_e64 v6, null, s23, 0, s0                   // 000000412758: D5207C06 00010017
	s_or_b32 s1, vcc_lo, s1                                    // 000000412760: 8C01016A
	.long 0xd72c0009                                           // 000000412764: D72C0009
	v_cndmask_b32_e32 v0, v5, v9, vcc_lo                       // 000000412768: 02001305
	.long 0xd72c0008                                           // 00000041276C: D72C0008
	v_cndmask_b32_e32 v0, v6, v8, vcc_lo                       // 000000412770: 02001106
	v_mad_u64_u32 v[5:6], null, v5, s8, 0                      // 000000412774: D6FE7C05 02001105
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000041277C: BF8701B1
	v_add3_u32 v6, v6, v9, v8                                  // 000000412780: D6550006 04221306
	v_add_nc_u32_e32 v8, 0x100, v4                             // 000000412788: 4A1008FF 00000100
	v_lshlrev_b32_e32 v7, 2, v4                                // 000000412790: 300E0882
	.long 0xd73c0005                                           // 000000412794: D73C0005
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 000000412798: 02020A82
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000041279C: BF8700B3
	v_mov_b32_e32 v4, v8                                       // 0000004127A0: 7E080308
	ds_load_b32 v7, v7 offset:32768                            // 0000004127A4: D8D88000 07000007
	.long 0xd7000005                                           // 0000004127AC: D7000005
	v_cndmask_b32_e32 v1, v2, v5, vcc_lo                       // 0000004127B0: 02020B02
	v_add_co_ci_u32_e64 v6, null, v3, v6, s0                   // 0000004127B4: D5207C06 00020D03
	s_waitcnt lgkmcnt(0)                                       // 0000004127BC: BF89FC07
	global_store_b32 v[5:6], v7, off                           // 0000004127C0: DC6A0000 007C0705
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000004127C8: 917E017E
	s_cbranch_execnz 65500                                     // 0000004127CC: BFA6FFDC <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi8ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2940>
	s_or_b32 exec_lo, exec_lo, s1                              // 0000004127D0: 8C7E017E
	s_ashr_i32 s29, s28, 31                                    // 0000004127D4: 861D9F1C
	.long 0xd44a0000                                           // 0000004127D8: D44A0000
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 0000004127DC: 02020080
	s_lshl_b64 s[22:23], s[28:29], 2                           // 0000004127E0: 8496821C
	s_waitcnt_vscnt null, 0x0                                  // 0000004127E4: BC7C0000
	buffer_gl1_inv                                             // 0000004127E8: E0B00000 00000000
	buffer_gl0_inv                                             // 0000004127F0: E0AC0000 00000000
	s_add_u32 s3, s6, s22                                      // 0000004127F8: 80031606
	s_addc_u32 s19, s7, s23                                    // 0000004127FC: 82131707
	s_barrier                                                  // 000000412800: BFBD0000
	buffer_gl0_inv                                             // 000000412804: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 00000041280C: BE812000
	s_cbranch_execz 29                                         // 000000412810: BFA5001D <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi8ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2a88>
	s_mov_b32 s7, exec_lo                                      // 000000412814: BE87007E
	s_mov_b32 s6, exec_lo                                      // 000000412818: BE86007E
	.long 0xd71f0002                                           // 00000041281C: D71F0002
	v_cndmask_b32_e32 v0, s7, v128, vcc_lo                     // 000000412820: 02010007
	s_delay_alu instid0(VALU_DEP_1)                            // 000000412824: BF870001
	v_cmpx_eq_u32_e32 0, v2                                    // 000000412828: 7D940480
	s_cbranch_execz 9                                          // 00000041282C: BFA50009 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi8ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2a54>
	s_lshl_b64 s[22:23], s[26:27], 2                           // 000000412830: 8496821A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000412834: BF8704B9
	s_add_u32 s22, s3, s22                                     // 000000412838: 80161603
	s_addc_u32 s23, s19, s23                                   // 00000041283C: 82171713
	s_bcnt1_i32_b32 s7, s7                                     // 000000412840: BE871807
	v_dual_mov_b32 v3, 0 :: v_dual_mov_b32 v4, s7              // 000000412844: CA100080 03040007
	global_atomic_add_u32 v3, v3, v4, s[22:23] glc             // 00000041284C: DCD64000 03160403
	s_or_b32 exec_lo, exec_lo, s6                              // 000000412854: 8C7E067E
	s_waitcnt vmcnt(0)                                         // 000000412858: BF8903F7
	v_readfirstlane_b32 s6, v3                                 // 00000041285C: 7E0C0503
	s_delay_alu instid0(VALU_DEP_1)                            // 000000412860: BF870001
	v_dual_mov_b32 v3, 0 :: v_dual_add_nc_u32 v2, s6, v2       // 000000412864: CA200080 03020406
	s_add_i32 s6, s21, -1                                      // 00000041286C: 8106C115
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000412870: BF870481
	v_cmp_eq_u32_e32 vcc_lo, s6, v2                            // 000000412874: 7C940406
	v_cndmask_b32_e64 v2, 0, 1, vcc_lo                         // 000000412878: D5010002 01A90280
	ds_store_b32 v3, v2 offset:47360                           // 000000412880: D834B900 00000203
	s_or_b32 exec_lo, exec_lo, s1                              // 000000412888: 8C7E017E
	v_mov_b32_e32 v2, 0                                        // 00000041288C: 7E040280
	s_waitcnt lgkmcnt(0)                                       // 000000412890: BF89FC07
	s_barrier                                                  // 000000412894: BFBD0000
	buffer_gl0_inv                                             // 000000412898: E0AC0000 00000000
	s_mov_b32 s22, 0                                           // 0000004128A0: BE960080
	ds_load_b32 v2, v2 offset:47360                            // 0000004128A4: D8D8B900 02000002
	s_waitcnt lgkmcnt(0)                                       // 0000004128AC: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v2                             // 0000004128B0: 7C940480
	s_cbranch_vccnz 915                                        // 0000004128B4: BFA40393 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi8ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3904>
	v_lshrrev_b32_e32 v2, 7, v0                                // 0000004128B8: 32040087
	s_add_u32 s1, s16, s10                                     // 0000004128BC: 80010A10
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000004128C0: 30020282
	s_addc_u32 s6, s17, s11                                    // 0000004128C4: 82060B11
	v_mov_b32_e32 v5, v0                                       // 0000004128C8: 7E0A0300
	v_mad_i64_i32 v[2:3], null, v2, s8, 0                      // 0000004128CC: D6FF7C02 02001102
	buffer_gl1_inv                                             // 0000004128D4: E0B00000 00000000
	buffer_gl0_inv                                             // 0000004128DC: E0AC0000 00000000
	.long 0xd73c0002                                           // 0000004128E4: D73C0002
	v_cndmask_b32_e32 v1, 2, v2, vcc_lo                        // 0000004128E8: 02020482
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004128EC: BF870091
	.long 0xd7006a02                                           // 0000004128F0: D7006A02
	v_cndmask_b32_e32 v1, s1, v2, vcc_lo                       // 0000004128F4: 02020401
	v_add_co_ci_u32_e64 v3, null, s6, v3, vcc_lo               // 0000004128F8: D5207C03 01AA0606
	s_lshl_b64 s[6:7], s[8:9], 5                               // 000000412900: 84868508
	.long 0xd7006a01                                           // 000000412904: D7006A01
	v_cndmask_b32_e32 v1, v2, v1, vcc_lo                       // 000000412908: 02020302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000041290C: BF870111
	v_add_co_ci_u32_e64 v2, null, 0, v3, vcc_lo                // 000000412910: D5207C02 01AA0680
	.long 0xd7006a01                                           // 000000412918: D7006A01
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 00000041291C: 02020204
	s_delay_alu instid0(VALU_DEP_1)                            // 000000412920: BF870001
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 000000412924: D5207C02 01AA0405
	s_lshl_b64 s[4:5], s[8:9], 3                               // 00000041292C: 84848308
	s_nop 0                                                    // 000000412930: BF800000
	s_nop 0                                                    // 000000412934: BF800000
	s_nop 0                                                    // 000000412938: BF800000
	s_nop 0                                                    // 00000041293C: BF800000
	v_mov_b32_e32 v4, v2                                       // 000000412940: 7E080302
	v_dual_mov_b32 v6, 0 :: v_dual_mov_b32 v3, v1              // 000000412944: CA100080 06020101
	s_mov_b32 s1, s21                                          // 00000041294C: BE810015
	global_load_b32 v7, v[3:4], off glc                        // 000000412950: DC524000 077C0003
	.long 0xd7006a03                                           // 000000412958: D7006A03
	v_cndmask_b32_e32 v0, v3, v6, vcc_lo                       // 00000041295C: 02000D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000412960: BF8704A1
	v_add_co_ci_u32_e64 v4, null, s7, v4, vcc_lo               // 000000412964: D5207C04 01AA0807
	s_add_i32 s1, s1, -1                                       // 00000041296C: 8101C101
	s_cmp_eq_u32 s1, 0                                         // 000000412970: BF068001
	s_waitcnt vmcnt(0)                                         // 000000412974: BF8903F7
	v_add_f32_e32 v6, v6, v7                                   // 000000412978: 060C0F06
	s_cbranch_scc0 65524                                       // 00000041297C: BFA1FFF4 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi8ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2b50>
	v_add_nc_u32_e32 v4, 0x100, v5                             // 000000412980: 4A080AFF 00000100
	v_cmp_lt_u32_e32 vcc_lo, 0x2ff, v5                         // 000000412988: 7C920AFF 000002FF
	.long 0xd7000101                                           // 000000412990: D7000101
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 000000412994: 02000901
	v_lshlrev_b32_e32 v3, 2, v5                                // 000000412998: 30060A82
	v_add_co_ci_u32_e64 v2, null, s5, v2, s1                   // 00000041299C: D5207C02 00060405
	v_mov_b32_e32 v5, v4                                       // 0000004129A4: 7E0A0304
	s_or_b32 s22, vcc_lo, s22                                  // 0000004129A8: 8C16166A
	ds_store_b32 v3, v6 offset:32768                           // 0000004129AC: D8348000 00000603
	s_and_not1_b32 exec_lo, exec_lo, s22                       // 0000004129B4: 917E167E
	s_cbranch_execnz 65505                                     // 0000004129B8: BFA6FFE1 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi8ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2b40>
	s_or_b32 exec_lo, exec_lo, s22                             // 0000004129BC: 8C7E167E
	s_and_saveexec_b32 s1, s0                                  // 0000004129C0: BE812000
	s_cbranch_execz 6                                          // 0000004129C4: BFA50006 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi8ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2be0>
	s_lshl_b64 s[4:5], s[26:27], 2                             // 0000004129C8: 8484821A
	v_mov_b32_e32 v1, 0                                        // 0000004129CC: 7E020280
	s_add_u32 s4, s3, s4                                       // 0000004129D0: 80040403
	s_addc_u32 s5, s19, s5                                     // 0000004129D4: 82050513
	global_store_b32 v1, v1, s[4:5]                            // 0000004129D8: DC6A0000 00040101
	s_or_b32 exec_lo, exec_lo, s1                              // 0000004129E0: 8C7E017E
	s_mov_b32 s3, -1                                           // 0000004129E4: BE8300C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000004129E8: BF870009
	s_and_b32 vcc_lo, exec_lo, s3                              // 0000004129EC: 8B6A037E
	s_cbranch_vccz 62974                                       // 0000004129F0: BFA3F5FE <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi8ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	v_cmp_gt_i32_e32 vcc_lo, s18, v35                          // 0000004129F4: 7C884612
	.long 0xd44c0000                                           // 0000004129F8: D44C0000
	v_cndmask_b32_e32 v1, 0x100, v0, vcc_lo                    // 0000004129FC: 020200FF 00000100
	s_waitcnt lgkmcnt(0)                                       // 000000412A04: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 000000412A08: BC7C0000
	s_barrier                                                  // 000000412A0C: BFBD0000
	buffer_gl0_inv                                             // 000000412A10: E0AC0000 00000000
	s_and_b32 s0, vcc_lo, s0                                   // 000000412A18: 8B00006A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000412A1C: BF870009
	s_and_saveexec_b32 s1, s0                                  // 000000412A20: BE812000
	s_cbranch_execz 62961                                      // 000000412A24: BFA5F5F1 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi8ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	v_and_b32_e32 v1, 15, v0                                   // 000000412A28: 3602008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000412A2C: BF870091
	v_lshlrev_b32_e32 v2, 2, v1                                // 000000412A30: 30040282
	v_lshl_or_b32 v2, v35, 9, v2                               // 000000412A34: D6560002 04091323
	s_delay_alu instid0(VALU_DEP_1)                            // 000000412A3C: BF870001
	v_add_nc_u32_e32 v8, 0x8000, v2                            // 000000412A40: 4A1004FF 00008000
	ds_load_2addr_b32 v[2:3], v8 offset1:16                    // 000000412A48: D8DC1000 02000008
	ds_load_2addr_b32 v[4:5], v8 offset0:32 offset1:48         // 000000412A50: D8DC3020 04000008
	ds_load_2addr_b32 v[6:7], v8 offset0:64 offset1:80         // 000000412A58: D8DC5040 06000008
	ds_load_2addr_b32 v[8:9], v8 offset0:96 offset1:112        // 000000412A60: D8DC7060 08000008
	v_and_b32_e32 v10, 1, v0                                   // 000000412A68: 36140081
	v_and_b32_e32 v11, 2, v0                                   // 000000412A6C: 36160082
	s_waitcnt lgkmcnt(3)                                       // 000000412A70: BF89FC37
	v_dual_add_f32 v13, v2, v3 :: v_dual_and_b32 v12, 4, v0    // 000000412A74: C9240702 0D0C0084
	s_waitcnt lgkmcnt(2)                                       // 000000412A7C: BF89FC27
	v_dual_sub_f32 v2, v2, v3 :: v_dual_add_f32 v3, v4, v5     // 000000412A80: C9480702 02020B04
	s_waitcnt lgkmcnt(1)                                       // 000000412A88: BF89FC17
	v_dual_sub_f32 v4, v4, v5 :: v_dual_add_f32 v5, v6, v7     // 000000412A8C: C9480B04 04040F06
	s_waitcnt lgkmcnt(0)                                       // 000000412A94: BF89FC07
	v_dual_sub_f32 v6, v6, v7 :: v_dual_add_f32 v7, v8, v9     // 000000412A98: C9480F06 06061308
	v_dual_sub_f32 v8, v8, v9 :: v_dual_add_f32 v9, v13, v3    // 000000412AA0: C9481308 0808070D
	v_sub_f32_e32 v3, v13, v3                                  // 000000412AA8: 0806070D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000412AAC: BF870243
	v_dual_add_f32 v13, v2, v4 :: v_dual_add_f32 v14, v5, v7   // 000000412AB0: C9080902 0D0E0F05
	v_dual_sub_f32 v2, v2, v4 :: v_dual_sub_f32 v5, v5, v7     // 000000412AB8: C94A0902 02040F05
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 000000412AC0: 7C941480
	.long 0xd44a0000                                           // 000000412AC4: D44A0000
	v_cndmask_b32_e32 v1, 0, v12, vcc_lo                       // 000000412AC8: 02021880
	v_dual_add_f32 v7, v9, v14 :: v_dual_add_f32 v4, v6, v8    // 000000412ACC: C9081D09 07041106
	v_sub_f32_e32 v6, v6, v8                                   // 000000412AD4: 080C1106
	v_sub_f32_e32 v8, v9, v14                                  // 000000412AD8: 08101D09
	s_delay_alu instid0(VALU_DEP_3)                            // 000000412ADC: BF870003
	v_add_f32_e32 v9, v13, v4                                  // 000000412AE0: 0612090D
	v_dual_sub_f32 v4, v13, v4 :: v_dual_add_f32 v13, v3, v5   // 000000412AE4: C948090D 040C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 000000412AEC: 08060B03
	v_add_f32_e32 v5, v2, v6                                   // 000000412AF0: 060A0D02
	v_sub_f32_e32 v2, v2, v6                                   // 000000412AF4: 08040D02
	v_mov_b32_dpp v6, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000412AF8: 7E0C02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000412B00: D5010007 21AA0F07
	v_mov_b32_dpp v10, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000412B08: 7E1402FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000412B10: D5010009 21AA1309
	v_mov_b32_dpp v14, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000412B18: 7E1C02FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 000000412B20: D501000D 21AA1B0D
	v_mov_b32_dpp v15, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000412B28: 7E1E02FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000412B30: D5010005 21AA0B05
	v_mov_b32_dpp v16, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000412B38: 7E2002FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000412B40: D5010008 21AA1108
	v_mov_b32_dpp v17, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000412B48: 7E2202FA FF016104
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000412B50: D5010004 21AA0904
	v_mov_b32_dpp v18, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000412B58: 7E2402FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000412B60: D5010003 21AA0703
	v_mov_b32_dpp v19, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000412B68: 7E2602FA FF016102
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 000000412B70: D5010002 21AA0502
	v_dual_add_f32 v6, v7, v6 :: v_dual_add_f32 v5, v5, v15    // 000000412B78: C9080D07 06041F05
	v_cmp_eq_u32_e32 vcc_lo, 0, v11                            // 000000412B80: 7C941680
	v_dual_add_f32 v7, v9, v10 :: v_dual_add_f32 v8, v8, v16   // 000000412B84: C9081509 07082108
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000412B8C: BF870233
	v_mov_b32_dpp v10, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000412B90: 7E1402FA FF016206
	v_add_f32_e32 v4, v4, v17                                  // 000000412B98: 06082304
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 000000412B9C: D5010006 21AA0D06
	v_mov_b32_dpp v11, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000412BA4: 7E1602FA FF016207
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000412BAC: D5010007 21AA0F07
	v_add_f32_e32 v2, v2, v19                                  // 000000412BB4: 06042702
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000412BB8: BF870092
	v_dual_add_f32 v6, v6, v10 :: v_dual_add_f32 v7, v7, v11   // 000000412BBC: C9081506 06061707
	v_mov_b32_dpp v10, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000412BC4: 7E1402FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s0                          // 000000412BCC: D5010006 20020D06
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000412BD4: BF8700D3
	v_mov_b32_dpp v11, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000412BD8: 7E1602FA FF016407
	v_cndmask_b32_e64 v7, -v7, v7, s0                          // 000000412BE0: D5010007 20020F07
	v_add_f32_e32 v9, v13, v14                                 // 000000412BE8: 06121D0D
	v_mov_b32_dpp v14, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000412BEC: 7E1C02FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000412BF4: D5010005 21AA0B05
	v_dual_add_f32 v15, v5, v14 :: v_dual_add_f32 v14, v7, v11 // 000000412BFC: C9081D05 0F0E1707
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000412C04: BF8701A4
	v_mov_b32_dpp v13, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000412C08: 7E1A02FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000412C10: D5010009 21AA1309
	v_mov_b32_dpp v7, v15 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000412C18: 7E0E02FA FF01640F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000412C20: BF870194
	v_mov_b32_dpp v23, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000412C24: 7E2E02FA FF01680E
	v_add_f32_e32 v9, v9, v13                                  // 000000412C2C: 06121B09
	v_mov_b32_dpp v13, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000412C30: 7E1A02FA FF016208
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000412C38: BF8700A2
	v_mov_b32_dpp v12, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000412C3C: 7E1802FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 000000412C44: D5010009 20021309
	v_add_f32_e32 v21, v9, v12                                 // 000000412C4C: 062A1909
	v_mov_b32_dpp v12, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000412C50: 7E1802FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 000000412C58: D5010002 21AA0502
	v_add_f32_e32 v3, v3, v18                                  // 000000412C60: 06062503
	v_cndmask_b32_e64 v9, -v15, v15, s0                        // 000000412C64: D5010009 20021F0F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000412C6C: BF870193
	v_add_f32_e32 v2, v2, v12                                  // 000000412C70: 06041902
	v_mov_b32_dpp v11, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000412C74: 7E1602FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000412C7C: D5010003 21AA0703
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000412C84: BF870114
	v_add_f32_e32 v19, v9, v7                                  // 000000412C88: 06260F09
	v_add_f32_e32 v3, v3, v11                                  // 000000412C8C: 06061703
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000412C90: BF870112
	v_mov_b32_dpp v20, v19 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000412C94: 7E2802FA FF016813
	v_mov_b32_dpp v12, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000412C9C: 7E1802FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 000000412CA4: D5010003 20020703
	v_add_f32_e32 v5, v6, v10                                  // 000000412CAC: 060A1506
	v_cndmask_b32_e64 v6, -v8, v8, vcc_lo                      // 000000412CB0: D5010006 21AA1108
	v_mov_b32_dpp v10, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000412CB8: 7E1402FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000412CC0: D5010004 21AA0904
	v_add_f32_e32 v12, v3, v12                                 // 000000412CC8: 06181903
	v_mov_b32_dpp v8, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000412CCC: 7E1002FA FF016805
	v_add_f32_e32 v6, v6, v13                                  // 000000412CD4: 060C1B06
	v_mov_b32_dpp v13, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000412CD8: 7E1A02FA FF016402
	v_add_f32_e32 v4, v4, v10                                  // 000000412CE0: 06081504
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 000000412CE4: D5010002 20020502
	v_mov_b32_dpp v22, v21 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000412CEC: 7E2C02FA FF016815
	v_mov_b32_dpp v10, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000412CF4: 7E1402FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s0                          // 000000412CFC: D5010006 20020D06
	v_mov_b32_dpp v11, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000412D04: 7E1602FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 000000412D0C: D5010004 20020904
	v_add_f32_e32 v9, v2, v13                                  // 000000412D14: 06121B02
	v_mov_b32_dpp v13, v12 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000412D18: 7E1A02FA FF01680C
	v_add_f32_e32 v17, v6, v10                                 // 000000412D20: 06221506
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000412D24: BF870214
	v_add_f32_e32 v15, v4, v11                                 // 000000412D28: 061E1704
	v_mov_b32_dpp v10, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000412D2C: 7E1402FA FF016809
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000412D34: BF870193
	v_mov_b32_dpp v18, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000412D38: 7E2402FA FF016811
	v_mov_b32_dpp v16, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000412D40: 7E2002FA FF01680F
	s_and_b32 exec_lo, exec_lo, s2                             // 000000412D48: 8B7E027E
	s_cbranch_execz 62759                                      // 000000412D4C: BFA5F527 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi8ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	v_lshl_or_b32 v3, s26, 7, v1                               // 000000412D50: D6560003 04050E1A
	v_and_b32_e32 v0, 8, v0                                    // 000000412D58: 36000088
	s_cmp_lg_u64 s[24:25], 0                                   // 000000412D5C: BF118018
	s_cselect_b32 s1, -1, 0                                    // 000000412D60: 980180C1
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000412D64: BF870112
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000412D68: 3408069F
	.long 0xd44a0000                                           // 000000412D6C: D44A0000
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 000000412D70: 02020080
	s_lshr_b32 s2, s20, 31                                     // 000000412D74: 85029F14
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000412D78: BF870009
	s_add_i32 s2, s20, s2                                      // 000000412D7C: 81020214
	.long 0xd73c0001                                           // 000000412D80: D73C0001
	v_cndmask_b32_e32 v1, 1, v3, vcc_lo                        // 000000412D84: 02020681
	v_cndmask_b32_e64 v0, -v5, v5, s0                          // 000000412D88: D5010000 20020B05
	v_mad_i64_i32 v[4:5], null, s20, v35, 0                    // 000000412D90: D6FF7C04 02024614
	s_ashr_i32 s2, s2, 1                                       // 000000412D98: 86028102
	s_cmp_eq_u64 s[24:25], 0                                   // 000000412D9C: BF108018
	v_mad_i64_i32 v[24:25], null, s2, v35, 0                   // 000000412DA0: D6FF7C18 02024602
	.long 0xd7006a06                                           // 000000412DA8: D7006A06
	v_cndmask_b32_e32 v1, s12, v1, vcc_lo                      // 000000412DAC: 0202020C
	s_delay_alu instid0(VALU_DEP_1)                            // 000000412DB0: BF870001
	v_add_co_ci_u32_e64 v7, null, s13, v2, vcc_lo              // 000000412DB4: D5207C07 01AA040D
	v_add_f32_e32 v0, v0, v8                                   // 000000412DBC: 06001100
	.long 0xd73c0004                                           // 000000412DC0: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 000000412DC4: 02020881
	global_load_d16_b16 v11, v[6:7], off                       // 000000412DC8: DC820000 0B7C0006
	v_mul_f32_e32 v0, 0x3db504f3, v0                           // 000000412DD0: 100000FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000412DD8: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000412DDC: BF8700A1
	v_fma_mix_f32 v26, v11, v0, neg(0) op_sel_hi:[1,0,0]       // 000000412DE0: CC20001A 8A02010B
	.long 0xd7006a00                                           // 000000412DE8: D7006A00
	v_cndmask_b32_e32 v1, s14, v4, vcc_lo                      // 000000412DEC: 0202080E
	v_add_co_ci_u32_e64 v8, null, s15, v5, vcc_lo              // 000000412DF0: D5207C08 01AA0A0F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000412DF8: BF8701B3
	v_bfe_u32 v27, v26, 16, 1                                  // 000000412DFC: D610001B 0205211A
	.long 0xd73c0004                                           // 000000412E04: D73C0004
	v_cndmask_b32_e32 v1, 1, v24, vcc_lo                       // 000000412E08: 02023081
	v_ashrrev_i32_e32 v11, 31, v3                              // 000000412E0C: 3416069F
	v_add3_u32 v24, v26, v27, 0x7fff                           // 000000412E10: D6550018 03FE371A 00007FFF
	s_cbranch_scc1 570                                         // 000000412E1C: BFA2023A <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi8ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3908>
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000412E20: BF870122
	v_lshrrev_b32_e32 v25, 23, v11                             // 000000412E24: 32321697
	v_mov_b32_e32 v29, s14                                     // 000000412E28: 7E3A020E
	v_add_nc_u32_e32 v25, v3, v25                              // 000000412E2C: 4A323303
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000412E30: BF870091
	v_and_b32_e32 v26, 0xfffffe00, v25                         // 000000412E34: 363432FF FFFFFE00
	v_sub_nc_u32_e32 v27, v3, v26                              // 000000412E3C: 4C363503
	v_mov_b32_e32 v26, s15                                     // 000000412E40: 7E34020F
	v_ashrrev_i32_e32 v25, 9, v25                              // 000000412E44: 34323289
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000412E48: BF8701A3
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v27                        // 000000412E4C: 7C8836FF 00000100
	v_add_nc_u32_e32 v28, 0xffffff00, v27                      // 000000412E54: 4A3836FF FFFFFF00
	v_dual_cndmask_b32 v30, s25, v26 :: v_dual_lshlrev_b32 v25, 8, v25// 000000412E5C: CA623419 1E183288
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000412E64: BF870112
	v_cndmask_b32_e32 v27, v28, v27, vcc_lo                    // 000000412E68: 0236371C
	v_ashrrev_i32_e32 v26, 31, v25                             // 000000412E6C: 3434329F
	v_cndmask_b32_e32 v29, s24, v29, vcc_lo                    // 000000412E70: 023A3A18
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000412E74: BF870193
	v_ashrrev_i32_e32 v28, 31, v27                             // 000000412E78: 3438369F
	.long 0xd73c0019                                           // 000000412E7C: D73C0019
	v_cndmask_b32_e32 v1, 1, v25, vcc_lo                       // 000000412E80: 02023281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000412E84: BF870093
	.long 0xd7006a1d                                           // 000000412E88: D7006A1D
	v_cndmask_b32_e32 v1, v29, v4, vcc_lo                      // 000000412E8C: 0202091D
	v_add_co_ci_u32_e64 v30, null, v30, v5, vcc_lo             // 000000412E90: D5207C1E 01AA0B1E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000412E98: BF870194
	.long 0xd73c001b                                           // 000000412E9C: D73C001B
	v_cndmask_b32_e32 v1, 1, v27, vcc_lo                       // 000000412EA0: 02023681
	.long 0xd7006a19                                           // 000000412EA4: D7006A19
	v_cndmask_b32_e32 v1, v29, v25, vcc_lo                     // 000000412EA8: 0202331D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000412EAC: BF870111
	v_add_co_ci_u32_e64 v26, null, v30, v26, vcc_lo            // 000000412EB0: D5207C1A 01AA351E
	.long 0xd7006a19                                           // 000000412EB8: D7006A19
	v_cndmask_b32_e32 v1, v25, v27, vcc_lo                     // 000000412EBC: 02023719
	s_delay_alu instid0(VALU_DEP_1)                            // 000000412EC0: BF870001
	v_add_co_ci_u32_e64 v26, null, v26, v28, vcc_lo            // 000000412EC4: D5207C1A 01AA391A
	global_store_d16_hi_b16 v[25:26], v24, off                 // 000000412ECC: DC960000 007C1819
	s_cbranch_execnz 7                                         // 000000412ED4: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi8ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x30f4>
	.long 0xd7006a19                                           // 000000412ED8: D7006A19
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 000000412EDC: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 000000412EE0: BF870001
	v_add_co_ci_u32_e64 v26, null, v8, v2, vcc_lo              // 000000412EE4: D5207C1A 01AA0508
	global_store_d16_hi_b16 v[25:26], v24, off                 // 000000412EEC: DC960000 007C1819
	global_load_d16_b16 v24, v[6:7], off offset:32             // 000000412EF4: DC820020 187C0006
	v_cndmask_b32_e64 v14, -v14, v14, s0                       // 000000412EFC: D501000E 20021D0E
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 000000412F04: 916A017E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000412F08: BF870091
	v_add_f32_e32 v14, v14, v23                                // 000000412F0C: 061C2F0E
	v_mul_f32_e32 v14, 0x3db504f3, v14                         // 000000412F10: 101C1CFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000412F18: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000412F1C: BF870121
	v_fma_mix_f32 v23, v24, v14, neg(0) op_sel_hi:[1,0,0]      // 000000412F20: CC200017 8A021D18
	v_cndmask_b32_e64 v14, 0, 1, s1                            // 000000412F28: D501000E 00050280
	v_bfe_u32 v24, v23, 16, 1                                  // 000000412F30: D6100018 02052117
	s_delay_alu instid0(VALU_DEP_1)                            // 000000412F38: BF870001
	v_add3_u32 v23, v23, v24, 0x7fff                           // 000000412F3C: D6550017 03FE3117 00007FFF
	s_cbranch_vccnz 496                                        // 000000412F48: BFA401F0 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi8ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x390c>
	v_or_b32_e32 v24, 16, v3                                   // 000000412F4C: 38300690
	v_lshrrev_b32_e32 v25, 23, v11                             // 000000412F50: 32321697
	v_mov_b32_e32 v27, s15                                     // 000000412F54: 7E36020F
	v_mov_b32_e32 v29, s14                                     // 000000412F58: 7E3A020E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000412F5C: BF870093
	v_add_nc_u32_e32 v25, v24, v25                             // 000000412F60: 4A323318
	v_and_b32_e32 v26, 0xfffffe00, v25                         // 000000412F64: 363432FF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000412F6C: BF870091
	v_sub_nc_u32_e32 v26, v24, v26                             // 000000412F70: 4C343518
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v26                        // 000000412F74: 7C8834FF 00000100
	v_add_nc_u32_e32 v28, 0xffffff00, v26                      // 000000412F7C: 4A3834FF FFFFFF00
	v_cndmask_b32_e32 v30, s25, v27, vcc_lo                    // 000000412F84: 023C3619
	v_ashrrev_i32_e32 v25, 9, v25                              // 000000412F88: 34323289
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000412F8C: BF8701A3
	v_cndmask_b32_e32 v26, v28, v26, vcc_lo                    // 000000412F90: 0234351C
	v_cndmask_b32_e32 v28, s24, v29, vcc_lo                    // 000000412F94: 02383A18
	v_lshlrev_b32_e32 v24, 8, v25                              // 000000412F98: 30303288
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000412F9C: BF870193
	v_ashrrev_i32_e32 v27, 31, v26                             // 000000412FA0: 3436349F
	.long 0xd7006a1c                                           // 000000412FA4: D7006A1C
	v_cndmask_b32_e32 v1, v28, v4, vcc_lo                      // 000000412FA8: 0202091C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000412FAC: BF870211
	v_add_co_ci_u32_e64 v29, null, v30, v5, vcc_lo             // 000000412FB0: D5207C1D 01AA0B1E
	v_ashrrev_i32_e32 v25, 31, v24                             // 000000412FB8: 3432309F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000412FBC: BF870114
	.long 0xd73c001a                                           // 000000412FC0: D73C001A
	v_cndmask_b32_e32 v1, 1, v26, vcc_lo                       // 000000412FC4: 02023481
	.long 0xd73c0018                                           // 000000412FC8: D73C0018
	v_cndmask_b32_e32 v1, 1, v24, vcc_lo                       // 000000412FCC: 02023081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000412FD0: BF870091
	.long 0xd7006a18                                           // 000000412FD4: D7006A18
	v_cndmask_b32_e32 v1, v28, v24, vcc_lo                     // 000000412FD8: 0202311C
	v_add_co_ci_u32_e64 v25, null, v29, v25, vcc_lo            // 000000412FDC: D5207C19 01AA331D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000412FE4: BF870092
	.long 0xd7006a18                                           // 000000412FE8: D7006A18
	v_cndmask_b32_e32 v1, v24, v26, vcc_lo                     // 000000412FEC: 02023518
	v_add_co_ci_u32_e64 v25, null, v25, v27, vcc_lo            // 000000412FF0: D5207C19 01AA3719
	global_store_d16_hi_b16 v[24:25], v23, off                 // 000000412FF8: DC960000 007C1718
	s_cbranch_execnz 7                                         // 000000413000: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi8ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3220>
	.long 0xd7006a18                                           // 000000413004: D7006A18
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 000000413008: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 00000041300C: BF870001
	v_add_co_ci_u32_e64 v25, null, v8, v2, vcc_lo              // 000000413010: D5207C19 01AA0508
	global_store_d16_hi_b16 v[24:25], v23, off offset:32       // 000000413018: DC960020 007C1718
	global_load_d16_b16 v23, v[6:7], off offset:64             // 000000413020: DC820040 177C0006
	v_cndmask_b32_e64 v21, -v21, v21, s0                       // 000000413028: D5010015 20022B15
	v_cmp_ne_u32_e32 vcc_lo, 1, v14                            // 000000413030: 7C9A1C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000413034: BF8700A2
	v_add_f32_e32 v21, v21, v22                                // 000000413038: 062A2D15
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 00000041303C: 8B6A6A7E
	v_mul_f32_e32 v21, 0x3db504f3, v21                         // 000000413040: 102A2AFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000413048: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041304C: BF870091
	v_fma_mix_f32 v21, v23, v21, neg(0) op_sel_hi:[1,0,0]      // 000000413050: CC200015 8A022B17
	v_bfe_u32 v22, v21, 16, 1                                  // 000000413058: D6100016 02052115
	s_delay_alu instid0(VALU_DEP_1)                            // 000000413060: BF870001
	v_add3_u32 v21, v21, v22, 0x7fff                           // 000000413064: D6550015 03FE2D15 00007FFF
	s_cbranch_vccnz 423                                        // 000000413070: BFA401A7 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi8ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3910>
	v_or_b32_e32 v22, 32, v3                                   // 000000413074: 382C06A0
	v_lshrrev_b32_e32 v23, 23, v11                             // 000000413078: 322E1697
	v_mov_b32_e32 v25, s15                                     // 00000041307C: 7E32020F
	v_mov_b32_e32 v27, s14                                     // 000000413080: 7E36020E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000413084: BF870093
	v_add_nc_u32_e32 v23, v22, v23                             // 000000413088: 4A2E2F16
	v_and_b32_e32 v24, 0xfffffe00, v23                         // 00000041308C: 36302EFF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000413094: BF870091
	v_sub_nc_u32_e32 v24, v22, v24                             // 000000413098: 4C303116
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v24                        // 00000041309C: 7C8830FF 00000100
	v_add_nc_u32_e32 v26, 0xffffff00, v24                      // 0000004130A4: 4A3430FF FFFFFF00
	v_cndmask_b32_e32 v28, s25, v25, vcc_lo                    // 0000004130AC: 02383219
	v_ashrrev_i32_e32 v23, 9, v23                              // 0000004130B0: 342E2E89
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000004130B4: BF8701A3
	v_cndmask_b32_e32 v24, v26, v24, vcc_lo                    // 0000004130B8: 0230311A
	v_cndmask_b32_e32 v26, s24, v27, vcc_lo                    // 0000004130BC: 02343618
	v_lshlrev_b32_e32 v22, 8, v23                              // 0000004130C0: 302C2E88
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004130C4: BF870193
	v_ashrrev_i32_e32 v25, 31, v24                             // 0000004130C8: 3432309F
	.long 0xd7006a1a                                           // 0000004130CC: D7006A1A
	v_cndmask_b32_e32 v1, v26, v4, vcc_lo                      // 0000004130D0: 0202091A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004130D4: BF870211
	v_add_co_ci_u32_e64 v27, null, v28, v5, vcc_lo             // 0000004130D8: D5207C1B 01AA0B1C
	v_ashrrev_i32_e32 v23, 31, v22                             // 0000004130E0: 342E2C9F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004130E4: BF870114
	.long 0xd73c0018                                           // 0000004130E8: D73C0018
	v_cndmask_b32_e32 v1, 1, v24, vcc_lo                       // 0000004130EC: 02023081
	.long 0xd73c0016                                           // 0000004130F0: D73C0016
	v_cndmask_b32_e32 v1, 1, v22, vcc_lo                       // 0000004130F4: 02022C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004130F8: BF870091
	.long 0xd7006a16                                           // 0000004130FC: D7006A16
	v_cndmask_b32_e32 v1, v26, v22, vcc_lo                     // 000000413100: 02022D1A
	v_add_co_ci_u32_e64 v23, null, v27, v23, vcc_lo            // 000000413104: D5207C17 01AA2F1B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041310C: BF870092
	.long 0xd7006a16                                           // 000000413110: D7006A16
	v_cndmask_b32_e32 v1, v22, v24, vcc_lo                     // 000000413114: 02023116
	v_add_co_ci_u32_e64 v23, null, v23, v25, vcc_lo            // 000000413118: D5207C17 01AA3317
	global_store_d16_hi_b16 v[22:23], v21, off                 // 000000413120: DC960000 007C1516
	s_cbranch_execnz 7                                         // 000000413128: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi8ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3348>
	.long 0xd7006a16                                           // 00000041312C: D7006A16
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 000000413130: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 000000413134: BF870001
	v_add_co_ci_u32_e64 v23, null, v8, v2, vcc_lo              // 000000413138: D5207C17 01AA0508
	global_store_d16_hi_b16 v[22:23], v21, off offset:64       // 000000413140: DC960040 007C1516
	global_load_d16_b16 v21, v[6:7], off offset:96             // 000000413148: DC820060 157C0006
	v_cndmask_b32_e64 v19, -v19, v19, s0                       // 000000413150: D5010013 20022713
	v_cmp_ne_u32_e32 vcc_lo, 1, v14                            // 000000413158: 7C9A1C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000041315C: BF8700A2
	v_add_f32_e32 v19, v19, v20                                // 000000413160: 06262913
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 000000413164: 8B6A6A7E
	v_mul_f32_e32 v19, 0x3db504f3, v19                         // 000000413168: 102626FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000413170: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000413174: BF870091
	v_fma_mix_f32 v19, v21, v19, neg(0) op_sel_hi:[1,0,0]      // 000000413178: CC200013 8A022715
	v_bfe_u32 v20, v19, 16, 1                                  // 000000413180: D6100014 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 000000413188: BF870001
	v_add3_u32 v19, v19, v20, 0x7fff                           // 00000041318C: D6550013 03FE2913 00007FFF
	s_cbranch_vccnz 350                                        // 000000413198: BFA4015E <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi8ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3914>
	v_or_b32_e32 v20, 48, v3                                   // 00000041319C: 382806B0
	v_lshrrev_b32_e32 v21, 23, v11                             // 0000004131A0: 322A1697
	v_mov_b32_e32 v23, s15                                     // 0000004131A4: 7E2E020F
	v_mov_b32_e32 v25, s14                                     // 0000004131A8: 7E32020E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004131AC: BF870093
	v_add_nc_u32_e32 v21, v20, v21                             // 0000004131B0: 4A2A2B14
	v_and_b32_e32 v22, 0xfffffe00, v21                         // 0000004131B4: 362C2AFF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004131BC: BF870091
	v_sub_nc_u32_e32 v22, v20, v22                             // 0000004131C0: 4C2C2D14
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v22                        // 0000004131C4: 7C882CFF 00000100
	v_add_nc_u32_e32 v24, 0xffffff00, v22                      // 0000004131CC: 4A302CFF FFFFFF00
	v_cndmask_b32_e32 v26, s25, v23, vcc_lo                    // 0000004131D4: 02342E19
	v_ashrrev_i32_e32 v21, 9, v21                              // 0000004131D8: 342A2A89
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000004131DC: BF8701A3
	v_cndmask_b32_e32 v22, v24, v22, vcc_lo                    // 0000004131E0: 022C2D18
	v_cndmask_b32_e32 v24, s24, v25, vcc_lo                    // 0000004131E4: 02303218
	v_lshlrev_b32_e32 v20, 8, v21                              // 0000004131E8: 30282A88
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004131EC: BF870193
	v_ashrrev_i32_e32 v23, 31, v22                             // 0000004131F0: 342E2C9F
	.long 0xd7006a18                                           // 0000004131F4: D7006A18
	v_cndmask_b32_e32 v1, v24, v4, vcc_lo                      // 0000004131F8: 02020918
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004131FC: BF870211
	v_add_co_ci_u32_e64 v25, null, v26, v5, vcc_lo             // 000000413200: D5207C19 01AA0B1A
	v_ashrrev_i32_e32 v21, 31, v20                             // 000000413208: 342A289F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000041320C: BF870114
	.long 0xd73c0016                                           // 000000413210: D73C0016
	v_cndmask_b32_e32 v1, 1, v22, vcc_lo                       // 000000413214: 02022C81
	.long 0xd73c0014                                           // 000000413218: D73C0014
	v_cndmask_b32_e32 v1, 1, v20, vcc_lo                       // 00000041321C: 02022881
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000413220: BF870091
	.long 0xd7006a14                                           // 000000413224: D7006A14
	v_cndmask_b32_e32 v1, v24, v20, vcc_lo                     // 000000413228: 02022918
	v_add_co_ci_u32_e64 v21, null, v25, v21, vcc_lo            // 00000041322C: D5207C15 01AA2B19
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000413234: BF870092
	.long 0xd7006a14                                           // 000000413238: D7006A14
	v_cndmask_b32_e32 v1, v20, v22, vcc_lo                     // 00000041323C: 02022D14
	v_add_co_ci_u32_e64 v21, null, v21, v23, vcc_lo            // 000000413240: D5207C15 01AA2F15
	global_store_d16_hi_b16 v[20:21], v19, off                 // 000000413248: DC960000 007C1314
	s_cbranch_execnz 7                                         // 000000413250: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi8ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3470>
	.long 0xd7006a14                                           // 000000413254: D7006A14
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 000000413258: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 00000041325C: BF870001
	v_add_co_ci_u32_e64 v21, null, v8, v2, vcc_lo              // 000000413260: D5207C15 01AA0508
	global_store_d16_hi_b16 v[20:21], v19, off offset:96       // 000000413268: DC960060 007C1314
	global_load_d16_b16 v19, v[6:7], off offset:128            // 000000413270: DC820080 137C0006
	v_cndmask_b32_e64 v17, -v17, v17, s0                       // 000000413278: D5010011 20022311
	v_cmp_ne_u32_e32 vcc_lo, 1, v14                            // 000000413280: 7C9A1C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000413284: BF8700A2
	v_add_f32_e32 v17, v17, v18                                // 000000413288: 06222511
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 00000041328C: 8B6A6A7E
	v_mul_f32_e32 v17, 0x3db504f3, v17                         // 000000413290: 102222FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000413298: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041329C: BF870091
	v_fma_mix_f32 v17, v19, v17, neg(0) op_sel_hi:[1,0,0]      // 0000004132A0: CC200011 8A022313
	v_bfe_u32 v18, v17, 16, 1                                  // 0000004132A8: D6100012 02052111
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004132B0: BF870001
	v_add3_u32 v17, v17, v18, 0x7fff                           // 0000004132B4: D6550011 03FE2511 00007FFF
	s_cbranch_vccnz 277                                        // 0000004132C0: BFA40115 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi8ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3918>
	v_or_b32_e32 v18, 64, v3                                   // 0000004132C4: 382406C0
	v_lshrrev_b32_e32 v19, 23, v11                             // 0000004132C8: 32261697
	v_mov_b32_e32 v21, s15                                     // 0000004132CC: 7E2A020F
	v_mov_b32_e32 v23, s14                                     // 0000004132D0: 7E2E020E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004132D4: BF870093
	v_add_nc_u32_e32 v19, v18, v19                             // 0000004132D8: 4A262712
	v_and_b32_e32 v20, 0xfffffe00, v19                         // 0000004132DC: 362826FF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004132E4: BF870091
	v_sub_nc_u32_e32 v20, v18, v20                             // 0000004132E8: 4C282912
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v20                        // 0000004132EC: 7C8828FF 00000100
	v_add_nc_u32_e32 v22, 0xffffff00, v20                      // 0000004132F4: 4A2C28FF FFFFFF00
	v_cndmask_b32_e32 v24, s25, v21, vcc_lo                    // 0000004132FC: 02302A19
	v_ashrrev_i32_e32 v19, 9, v19                              // 000000413300: 34262689
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000413304: BF8701A3
	v_cndmask_b32_e32 v20, v22, v20, vcc_lo                    // 000000413308: 02282916
	v_cndmask_b32_e32 v22, s24, v23, vcc_lo                    // 00000041330C: 022C2E18
	v_lshlrev_b32_e32 v18, 8, v19                              // 000000413310: 30242688
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000413314: BF870193
	v_ashrrev_i32_e32 v21, 31, v20                             // 000000413318: 342A289F
	.long 0xd7006a16                                           // 00000041331C: D7006A16
	v_cndmask_b32_e32 v1, v22, v4, vcc_lo                      // 000000413320: 02020916
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000413324: BF870211
	v_add_co_ci_u32_e64 v23, null, v24, v5, vcc_lo             // 000000413328: D5207C17 01AA0B18
	v_ashrrev_i32_e32 v19, 31, v18                             // 000000413330: 3426249F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000413334: BF870114
	.long 0xd73c0014                                           // 000000413338: D73C0014
	v_cndmask_b32_e32 v1, 1, v20, vcc_lo                       // 00000041333C: 02022881
	.long 0xd73c0012                                           // 000000413340: D73C0012
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 000000413344: 02022481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000413348: BF870091
	.long 0xd7006a12                                           // 00000041334C: D7006A12
	v_cndmask_b32_e32 v1, v22, v18, vcc_lo                     // 000000413350: 02022516
	v_add_co_ci_u32_e64 v19, null, v23, v19, vcc_lo            // 000000413354: D5207C13 01AA2717
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041335C: BF870092
	.long 0xd7006a12                                           // 000000413360: D7006A12
	v_cndmask_b32_e32 v1, v18, v20, vcc_lo                     // 000000413364: 02022912
	v_add_co_ci_u32_e64 v19, null, v19, v21, vcc_lo            // 000000413368: D5207C13 01AA2B13
	global_store_d16_hi_b16 v[18:19], v17, off                 // 000000413370: DC960000 007C1112
	s_cbranch_execnz 7                                         // 000000413378: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi8ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3598>
	.long 0xd7006a12                                           // 00000041337C: D7006A12
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 000000413380: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 000000413384: BF870001
	v_add_co_ci_u32_e64 v19, null, v8, v2, vcc_lo              // 000000413388: D5207C13 01AA0508
	global_store_d16_hi_b16 v[18:19], v17, off offset:128      // 000000413390: DC960080 007C1112
	global_load_d16_b16 v17, v[6:7], off offset:160            // 000000413398: DC8200A0 117C0006
	v_cndmask_b32_e64 v15, -v15, v15, s0                       // 0000004133A0: D501000F 20021F0F
	v_cmp_ne_u32_e32 vcc_lo, 1, v14                            // 0000004133A8: 7C9A1C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000004133AC: BF8700A2
	v_add_f32_e32 v15, v15, v16                                // 0000004133B0: 061E210F
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 0000004133B4: 8B6A6A7E
	v_mul_f32_e32 v15, 0x3db504f3, v15                         // 0000004133B8: 101E1EFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 0000004133C0: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004133C4: BF870091
	v_fma_mix_f32 v15, v17, v15, neg(0) op_sel_hi:[1,0,0]      // 0000004133C8: CC20000F 8A021F11
	v_bfe_u32 v16, v15, 16, 1                                  // 0000004133D0: D6100010 0205210F
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004133D8: BF870001
	v_add3_u32 v15, v15, v16, 0x7fff                           // 0000004133DC: D655000F 03FE210F 00007FFF
	s_cbranch_vccnz 204                                        // 0000004133E8: BFA400CC <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi8ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x391c>
	v_or_b32_e32 v16, 0x50, v3                                 // 0000004133EC: 382006FF 00000050
	v_lshrrev_b32_e32 v17, 23, v11                             // 0000004133F4: 32221697
	v_mov_b32_e32 v19, s15                                     // 0000004133F8: 7E26020F
	v_mov_b32_e32 v21, s14                                     // 0000004133FC: 7E2A020E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000413400: BF870093
	v_add_nc_u32_e32 v17, v16, v17                             // 000000413404: 4A222310
	v_and_b32_e32 v18, 0xfffffe00, v17                         // 000000413408: 362422FF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000413410: BF870091
	v_sub_nc_u32_e32 v18, v16, v18                             // 000000413414: 4C242510
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v18                        // 000000413418: 7C8824FF 00000100
	v_add_nc_u32_e32 v20, 0xffffff00, v18                      // 000000413420: 4A2824FF FFFFFF00
	v_cndmask_b32_e32 v22, s25, v19, vcc_lo                    // 000000413428: 022C2619
	v_ashrrev_i32_e32 v17, 9, v17                              // 00000041342C: 34222289
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000413430: BF8701A3
	v_cndmask_b32_e32 v18, v20, v18, vcc_lo                    // 000000413434: 02242514
	v_cndmask_b32_e32 v20, s24, v21, vcc_lo                    // 000000413438: 02282A18
	v_lshlrev_b32_e32 v16, 8, v17                              // 00000041343C: 30202288
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000413440: BF870193
	v_ashrrev_i32_e32 v19, 31, v18                             // 000000413444: 3426249F
	.long 0xd7006a14                                           // 000000413448: D7006A14
	v_cndmask_b32_e32 v1, v20, v4, vcc_lo                      // 00000041344C: 02020914
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000413450: BF870211
	v_add_co_ci_u32_e64 v21, null, v22, v5, vcc_lo             // 000000413454: D5207C15 01AA0B16
	v_ashrrev_i32_e32 v17, 31, v16                             // 00000041345C: 3422209F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000413460: BF870114
	.long 0xd73c0012                                           // 000000413464: D73C0012
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 000000413468: 02022481
	.long 0xd73c0010                                           // 00000041346C: D73C0010
	v_cndmask_b32_e32 v1, 1, v16, vcc_lo                       // 000000413470: 02022081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000413474: BF870091
	.long 0xd7006a10                                           // 000000413478: D7006A10
	v_cndmask_b32_e32 v1, v20, v16, vcc_lo                     // 00000041347C: 02022114
	v_add_co_ci_u32_e64 v17, null, v21, v17, vcc_lo            // 000000413480: D5207C11 01AA2315
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000413488: BF870092
	.long 0xd7006a10                                           // 00000041348C: D7006A10
	v_cndmask_b32_e32 v1, v16, v18, vcc_lo                     // 000000413490: 02022510
	v_add_co_ci_u32_e64 v17, null, v17, v19, vcc_lo            // 000000413494: D5207C11 01AA2711
	global_store_d16_hi_b16 v[16:17], v15, off                 // 00000041349C: DC960000 007C0F10
	s_cbranch_execnz 7                                         // 0000004134A4: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi8ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x36c4>
	.long 0xd7006a10                                           // 0000004134A8: D7006A10
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 0000004134AC: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004134B0: BF870001
	v_add_co_ci_u32_e64 v17, null, v8, v2, vcc_lo              // 0000004134B4: D5207C11 01AA0508
	global_store_d16_hi_b16 v[16:17], v15, off offset:160      // 0000004134BC: DC9600A0 007C0F10
	global_load_d16_b16 v15, v[6:7], off offset:192            // 0000004134C4: DC8200C0 0F7C0006
	v_cndmask_b32_e64 v12, -v12, v12, s0                       // 0000004134CC: D501000C 2002190C
	v_cmp_ne_u32_e32 vcc_lo, 1, v14                            // 0000004134D4: 7C9A1C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000004134D8: BF8700A2
	v_add_f32_e32 v12, v12, v13                                // 0000004134DC: 06181B0C
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 0000004134E0: 8B6A6A7E
	v_mul_f32_e32 v12, 0x3db504f3, v12                         // 0000004134E4: 101818FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 0000004134EC: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004134F0: BF870091
	v_fma_mix_f32 v12, v15, v12, neg(0) op_sel_hi:[1,0,0]      // 0000004134F4: CC20000C 8A02190F
	v_bfe_u32 v13, v12, 16, 1                                  // 0000004134FC: D610000D 0205210C
	s_delay_alu instid0(VALU_DEP_1)                            // 000000413504: BF870001
	v_add3_u32 v12, v12, v13, 0x7fff                           // 000000413508: D655000C 03FE1B0C 00007FFF
	s_cbranch_vccnz 130                                        // 000000413514: BFA40082 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi8ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3920>
	v_or_b32_e32 v13, 0x60, v3                                 // 000000413518: 381A06FF 00000060
	v_lshrrev_b32_e32 v15, 23, v11                             // 000000413520: 321E1697
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000413524: BF870091
	v_dual_mov_b32 v18, s14 :: v_dual_add_nc_u32 v15, v13, v15 // 000000413528: CA20000E 120E1F0D
	v_and_b32_e32 v16, 0xfffffe00, v15                         // 000000413530: 36201EFF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000413538: BF8701B1
	v_sub_nc_u32_e32 v13, v13, v16                             // 00000041353C: 4C1A210D
	v_mov_b32_e32 v16, s15                                     // 000000413540: 7E20020F
	v_ashrrev_i32_e32 v15, 9, v15                              // 000000413544: 341E1E89
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v13                        // 000000413548: 7C881AFF 00000100
	v_add_nc_u32_e32 v17, 0xffffff00, v13                      // 000000413550: 4A221AFF FFFFFF00
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000413558: BF8701A3
	v_lshlrev_b32_e32 v15, 8, v15                              // 00000041355C: 301E1E88
	v_cndmask_b32_e32 v19, s25, v16, vcc_lo                    // 000000413560: 02262019
	v_cndmask_b32_e32 v17, v17, v13, vcc_lo                    // 000000413564: 02221B11
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000413568: BF8701A3
	v_ashrrev_i32_e32 v16, 31, v15                             // 00000041356C: 34201E9F
	v_cndmask_b32_e32 v13, s24, v18, vcc_lo                    // 000000413570: 021A2418
	v_ashrrev_i32_e32 v18, 31, v17                             // 000000413574: 3424229F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000413578: BF870193
	.long 0xd73c000f                                           // 00000041357C: D73C000F
	v_cndmask_b32_e32 v1, 1, v15, vcc_lo                       // 000000413580: 02021E81
	.long 0xd7006a0d                                           // 000000413584: D7006A0D
	v_cndmask_b32_e32 v1, v13, v4, vcc_lo                      // 000000413588: 0202090D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000041358C: BF870211
	v_add_co_ci_u32_e64 v19, null, v19, v5, vcc_lo             // 000000413590: D5207C13 01AA0B13
	.long 0xd73c0011                                           // 000000413598: D73C0011
	v_cndmask_b32_e32 v1, 1, v17, vcc_lo                       // 00000041359C: 02022281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004135A0: BF870093
	.long 0xd7006a0d                                           // 0000004135A4: D7006A0D
	v_cndmask_b32_e32 v1, v13, v15, vcc_lo                     // 0000004135A8: 02021F0D
	v_add_co_ci_u32_e64 v16, null, v19, v16, vcc_lo            // 0000004135AC: D5207C10 01AA2113
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004135B4: BF870092
	.long 0xd7006a0f                                           // 0000004135B8: D7006A0F
	v_cndmask_b32_e32 v1, v13, v17, vcc_lo                     // 0000004135BC: 0202230D
	v_add_co_ci_u32_e64 v16, null, v16, v18, vcc_lo            // 0000004135C0: D5207C10 01AA2510
	global_store_d16_hi_b16 v[15:16], v12, off                 // 0000004135C8: DC960000 007C0C0F
	s_cbranch_execnz 7                                         // 0000004135D0: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi8ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x37f0>
	.long 0xd7006a0f                                           // 0000004135D4: D7006A0F
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 0000004135D8: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004135DC: BF870001
	v_add_co_ci_u32_e64 v16, null, v8, v2, vcc_lo              // 0000004135E0: D5207C10 01AA0508
	global_store_d16_hi_b16 v[15:16], v12, off offset:192      // 0000004135E8: DC9600C0 007C0C0F
	global_load_d16_b16 v6, v[6:7], off offset:224             // 0000004135F0: DC8200E0 067C0006
	v_cndmask_b32_e64 v7, -v9, v9, s0                          // 0000004135F8: D5010007 20021309
	v_cmp_ne_u32_e32 vcc_lo, 1, v14                            // 000000413600: 7C9A1C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000413604: BF8700A2
	v_add_f32_e32 v7, v7, v10                                  // 000000413608: 060E1507
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 00000041360C: 8B6A6A7E
	v_mul_f32_e32 v7, 0x3db504f3, v7                           // 000000413610: 100E0EFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000413618: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041361C: BF870091
	v_fma_mix_f32 v6, v6, v7, neg(0) op_sel_hi:[1,0,0]         // 000000413620: CC200006 8A020F06
	v_bfe_u32 v7, v6, 16, 1                                    // 000000413628: D6100007 02052106
	s_delay_alu instid0(VALU_DEP_1)                            // 000000413630: BF870001
	v_add3_u32 v6, v6, v7, 0x7fff                              // 000000413634: D6550006 03FE0F06 00007FFF
	s_cbranch_vccnz 56                                         // 000000413640: BFA40038 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi8ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3924>
	v_or_b32_e32 v3, 0x70, v3                                  // 000000413644: 380606FF 00000070
	v_lshrrev_b32_e32 v7, 23, v11                              // 00000041364C: 320E1697
	v_mov_b32_e32 v10, s15                                     // 000000413650: 7E14020F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000413654: BF870092
	v_dual_mov_b32 v12, s14 :: v_dual_add_nc_u32 v7, v3, v7    // 000000413658: CA20000E 0C060F03
	v_and_b32_e32 v9, 0xfffffe00, v7                           // 000000413660: 36120EFF FFFFFE00
	v_ashrrev_i32_e32 v7, 9, v7                                // 000000413668: 340E0E89
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000041366C: BF870112
	v_sub_nc_u32_e32 v3, v3, v9                                // 000000413670: 4C061303
	v_lshlrev_b32_e32 v9, 8, v7                                // 000000413674: 30120E88
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000413678: BF870232
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v3                         // 00000041367C: 7C8806FF 00000100
	v_add_nc_u32_e32 v7, 0xffffff00, v3                        // 000000413684: 4A0E06FF FFFFFF00
	v_cndmask_b32_e32 v13, s25, v10, vcc_lo                    // 00000041368C: 021A1419
	v_ashrrev_i32_e32 v10, 31, v9                              // 000000413690: 3414129F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000413694: BF8701A3
	v_cndmask_b32_e32 v11, v7, v3, vcc_lo                      // 000000413698: 02160707
	v_cndmask_b32_e32 v3, s24, v12, vcc_lo                     // 00000041369C: 02061818
	.long 0xd73c0009                                           // 0000004136A0: D73C0009
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 0000004136A4: 02021281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004136A8: BF870193
	v_ashrrev_i32_e32 v12, 31, v11                             // 0000004136AC: 3418169F
	.long 0xd7006a07                                           // 0000004136B0: D7006A07
	v_cndmask_b32_e32 v1, v3, v4, vcc_lo                       // 0000004136B4: 02020903
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004136B8: BF870191
	v_add_co_ci_u32_e64 v5, null, v13, v5, vcc_lo              // 0000004136BC: D5207C05 01AA0B0D
	.long 0xd73c0003                                           // 0000004136C4: D73C0003
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 0000004136C8: 02021681
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004136CC: BF870093
	.long 0xd7006a07                                           // 0000004136D0: D7006A07
	v_cndmask_b32_e32 v1, v7, v9, vcc_lo                       // 0000004136D4: 02021307
	v_add_co_ci_u32_e64 v5, null, v5, v10, vcc_lo              // 0000004136D8: D5207C05 01AA1505
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004136E0: BF870092
	.long 0xd7006a03                                           // 0000004136E4: D7006A03
	v_cndmask_b32_e32 v1, v7, v3, vcc_lo                       // 0000004136E8: 02020707
	v_add_co_ci_u32_e64 v4, null, v5, v4, vcc_lo               // 0000004136EC: D5207C04 01AA0905
	global_store_d16_hi_b16 v[3:4], v6, off                    // 0000004136F4: DC960000 007C0603
	s_cbranch_execnz 62139                                     // 0000004136FC: BFA6F2BB <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi8ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	s_branch 8                                                 // 000000413700: BFA00008 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi8ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3924>
	s_branch 62137                                             // 000000413704: BFA0F2B9 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi8ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	s_branch 65011                                             // 000000413708: BFA0FDF3 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi8ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x30d8>
	s_branch 65085                                             // 00000041370C: BFA0FE3D <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi8ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3204>
	s_branch 65158                                             // 000000413710: BFA0FE86 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi8ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x332c>
	s_branch 65231                                             // 000000413714: BFA0FECF <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi8ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3454>
	s_branch 65304                                             // 000000413718: BFA0FF18 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi8ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x357c>
	s_branch 65378                                             // 00000041371C: BFA0FF62 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi8ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x36a8>
	s_branch 65452                                             // 000000413720: BFA0FFAC <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi8ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x37d4>
	.long 0xd7006a00                                           // 000000413724: D7006A00
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 000000413728: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 00000041372C: BF870001
	v_add_co_ci_u32_e64 v1, null, v8, v2, vcc_lo               // 000000413730: D5207C01 01AA0508
	global_store_d16_hi_b16 v[0:1], v6, off offset:224         // 000000413738: DC9600E0 007C0600
	s_nop 0                                                    // 000000413740: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000413744: BFB60003
	s_endpgm                                                   // 000000413748: BFB00000
		...

