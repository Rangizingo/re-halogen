00000000003ede00 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb1ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj>:
; _ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb1ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj():
	s_clause 0x1                                               // 0000003EDE00: BF850001
	s_load_b64 s[4:5], s[0:1], 0x130                           // 0000003EDE04: F4040100 F8000130
	s_load_b128 s[16:19], s[0:1], 0x198                        // 0000003EDE0C: F4080400 F8000198
	s_waitcnt lgkmcnt(0)                                       // 0000003EDE14: BF89FC07
	s_cmp_eq_u64 s[4:5], 0                                     // 0000003EDE18: BF108004
	s_cbranch_scc1 246                                         // 0000003EDE1C: BFA200F6 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb1ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3f8>
	s_load_b32 s6, s[0:1], 0x138                               // 0000003EDE20: F4000180 F8000138
	s_waitcnt lgkmcnt(0)                                       // 0000003EDE28: BF89FC07
	s_cmp_lt_i32 s2, s6                                        // 0000003EDE2C: BF040602
	s_cselect_b32 s3, -1, 0                                    // 0000003EDE30: 980380C1
	s_cmp_ge_i32 s2, s6                                        // 0000003EDE34: BF030602
	s_cbranch_scc0 233                                         // 0000003EDE38: BFA100E9 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb1ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3e0>
	v_lshrrev_b32_e32 v1, 5, v0                                // 0000003EDE3C: 32020085
	s_sub_i32 s6, s2, s6                                       // 0000003EDE40: 81860602
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000003EDE44: BF870481
	v_lshl_or_b32 v1, s6, 3, v1                                // 0000003EDE48: D6560001 04050606
	s_mul_i32 s6, s18, 20                                      // 0000003EDE50: 96069412
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000003EDE54: BF870481
	v_cmp_gt_i32_e32 vcc_lo, s6, v1                            // 0000003EDE58: 7C880206
	s_and_saveexec_b32 s6, vcc_lo                              // 0000003EDE5C: BE86206A
	s_cbranch_execz 222                                        // 0000003EDE60: BFA500DE <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb1ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3dc>
	.long 0xd72e0002                                           // 0000003EDE64: D72E0002
	v_cndmask_b32_e32 v1, 0x66666667, v1, vcc_lo               // 0000003EDE68: 020202FF 66666667
	v_and_b32_e32 v9, 31, v0                                   // 0000003EDE70: 3612009F
	s_load_b64 s[8:9], s[0:1], 0x128                           // 0000003EDE74: F4040200 F8000128
	s_mov_b32 s7, 0x76543210                                   // 0000003EDE7C: BE8700FF 76543210
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003EDE84: BF8700A2
	v_lshrrev_b32_e32 v3, 31, v2                               // 0000003EDE88: 3206049F
	v_ashrrev_i32_e32 v2, 3, v2                                // 0000003EDE8C: 34040483
	v_add_nc_u32_e32 v8, v2, v3                                // 0000003EDE90: 4A100702
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003EDE94: BF870121
	.long 0xd72c0002                                           // 0000003EDE98: D72C0002
	v_cndmask_b32_e32 v1, 0xffffffec, v8, vcc_lo               // 0000003EDE9C: 020210FF FFFFFFEC
	v_mad_i64_i32 v[4:5], null, 0x1400, v8, s[16:17]           // 0000003EDEA4: D6FF7C04 004210FF 00001400
	v_add_lshl_u32 v1, v2, v1, 7                               // 0000003EDEB0: D6470001 021E0302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003EDEB8: BF870091
	v_lshl_or_b32 v2, v9, 2, v1                                // 0000003EDEBC: D6560002 04050509
	v_ashrrev_i32_e32 v3, 31, v2                               // 0000003EDEC4: 3406049F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003EDEC8: BF870091
	.long 0xd73c0002                                           // 0000003EDECC: D73C0002
	v_cndmask_b32_e32 v1, 1, v2, vcc_lo                        // 0000003EDED0: 02020481
	.long 0xd7006a04                                           // 0000003EDED4: D7006A04
	v_cndmask_b32_e32 v1, v4, v2, vcc_lo                       // 0000003EDED8: 02020504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000003EDEDC: BF8700B1
	v_add_co_ci_u32_e64 v5, null, v5, v3, vcc_lo               // 0000003EDEE0: D5207C05 01AA0705
	s_waitcnt lgkmcnt(0)                                       // 0000003EDEE8: BF89FC07
	.long 0xd7006a02                                           // 0000003EDEEC: D7006A02
	v_cndmask_b32_e32 v1, s8, v2, vcc_lo                       // 0000003EDEF0: 02020408
	v_add_co_ci_u32_e64 v3, null, s9, v3, vcc_lo               // 0000003EDEF4: D5207C03 01AA0609
	global_load_b64 v[4:5], v[4:5], off                        // 0000003EDEFC: DC560000 047C0004
	s_mov_b32 s8, 0x3db504f3                                   // 0000003EDF04: BE8800FF 3DB504F3
	global_load_b64 v[6:7], v[2:3], off                        // 0000003EDF0C: DC560000 067C0002
	s_waitcnt vmcnt(1)                                         // 0000003EDF14: BF8907F7
	.long 0x7e043904                                           // 0000003EDF18: 7E043904
	v_and_b32_e32 v3, 0xffff0000, v4                           // 0000003EDF1C: 360608FF FFFF0000
	.long 0x7e083905                                           // 0000003EDF24: 7E083905
	v_and_b32_e32 v5, 0xffff0000, v5                           // 0000003EDF28: 360A0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003EDF30: BF870004
	v_lshlrev_b32_e32 v14, 16, v2                              // 0000003EDF34: 301C0490
	s_waitcnt vmcnt(0)                                         // 0000003EDF38: BF8903F7
	v_fma_mix_f32 v3, v6, v3, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 0000003EDF3C: CC200803 8A020706
	v_lshlrev_b32_e32 v4, 16, v4                               // 0000003EDF44: 30080890
	v_fma_mix_f32 v5, v7, v5, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 0000003EDF48: CC200805 8A020B07
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000003EDF50: 3404029F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000003EDF54: BF870224
	v_fma_mix_f32 v15, v6, v14, v3 op_sel_hi:[1,0,0]           // 0000003EDF58: CC20000F 0C0E1D06
	v_fma_mix_f32 v6, v6, v14, -v3 op_sel_hi:[1,0,0]           // 0000003EDF60: CC200006 8C0E1D06
	v_fma_mix_f32 v14, v7, v4, v5 op_sel_hi:[1,0,0]            // 0000003EDF68: CC20000E 0C160907
	v_fma_mix_f32 v5, v7, v4, -v5 op_sel_hi:[1,0,0]            // 0000003EDF70: CC200005 8C160907
	v_and_b32_e32 v10, 1, v0                                   // 0000003EDF78: 36140081
	v_and_b32_e32 v11, 2, v0                                   // 0000003EDF7C: 36160082
	v_and_b32_e32 v13, 8, v0                                   // 0000003EDF80: 361A0088
	.long 0xd73c0001                                           // 0000003EDF84: D73C0001
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000003EDF88: 02020281
	v_add_f32_e32 v16, v6, v5                                  // 0000003EDF8C: 06200B06
	v_sub_f32_e32 v5, v6, v5                                   // 0000003EDF90: 080A0B06
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 0000003EDF94: 7C941480
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003EDF98: BF870193
	v_mov_b32_dpp v10, v16 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003EDF9C: 7E1402FA FF016110
	v_mov_b32_dpp v17, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003EDFA4: 7E2202FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 0000003EDFAC: D5010005 21AA0B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 0000003EDFB4: BF8701D1
	v_add_f32_e32 v5, v5, v17                                  // 0000003EDFB8: 060A2305
	v_mad_i64_i32 v[3:4], null, 0x1400, v8, s[4:5]             // 0000003EDFBC: D6FF7C03 001210FF 00001400
	v_add_f32_e32 v8, v15, v14                                 // 0000003EDFC8: 06101D0F
	v_sub_f32_e32 v14, v15, v14                                // 0000003EDFCC: 081C1D0F
	v_cndmask_b32_e64 v15, -v16, v16, vcc_lo                   // 0000003EDFD0: D501000F 21AA2110
	v_mov_b32_dpp v6, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003EDFD8: 7E0C02FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 0000003EDFE0: D5010008 21AA1108
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000003EDFE8: BF870234
	v_mov_b32_dpp v16, v14 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003EDFEC: 7E2002FA FF01610E
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 0000003EDFF4: D501000E 21AA1D0E
	v_cmp_eq_u32_e32 vcc_lo, 0, v11                            // 0000003EDFFC: 7C941680
	v_dual_add_f32 v6, v8, v6 :: v_dual_lshlrev_b32 v7, 3, v9  // 0000003EE000: C9220D08 06061283
	v_add_f32_e32 v8, v15, v10                                 // 0000003EE008: 0610150F
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003EE00C: BF870004
	v_add_f32_e32 v10, v14, v16                                // 0000003EE010: 0614210E
	v_mov_b32_dpp v16, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003EE014: 7E2002FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 0000003EE01C: D5010005 21AA0B05
	v_mov_b32_dpp v11, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003EE024: 7E1602FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 0000003EE02C: D5010006 21AA0D06
	v_mov_b32_dpp v15, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003EE034: 7E1E02FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 0000003EE03C: D501000A 21AA150A
	v_add_f32_e32 v5, v5, v16                                  // 0000003EE044: 060A2105
	v_mov_b32_dpp v14, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003EE048: 7E1C02FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 0000003EE050: D5010008 21AA1108
	v_add_f32_e32 v6, v6, v11                                  // 0000003EE058: 060C1706
	v_add_f32_e32 v10, v10, v15                                // 0000003EE05C: 06141F0A
	v_mov_b32_dpp v15, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003EE060: 7E1E02FA FF016405
	v_and_b32_e32 v12, 4, v0                                   // 0000003EE068: 36180084
	v_add_f32_e32 v8, v8, v14                                  // 0000003EE06C: 06101D08
	v_mov_b32_dpp v11, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003EE070: 7E1602FA FF016406
	v_mov_b32_dpp v14, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003EE078: 7E1C02FA FF01640A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000003EE080: BF8701C4
	v_cmp_eq_u32_e32 vcc_lo, 0, v12                            // 0000003EE084: 7C941880
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 0000003EE088: D5010006 21AA0D06
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 0000003EE090: D5010005 21AA0B05
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 0000003EE098: D501000A 21AA150A
	v_add_f32_e32 v6, v6, v11                                  // 0000003EE0A0: 060C1706
	s_delay_alu instid0(VALU_DEP_3)                            // 0000003EE0A4: BF870003
	v_add_f32_e32 v5, v5, v15                                  // 0000003EE0A8: 060A1F05
	v_mov_b32_dpp v12, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003EE0AC: 7E1802FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 0000003EE0B4: D5010008 21AA1108
	v_cmp_eq_u32_e32 vcc_lo, 0, v13                            // 0000003EE0BC: 7C941A80
	v_add_f32_e32 v10, v10, v14                                // 0000003EE0C0: 06141D0A
	v_mov_b32_dpp v11, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003EE0C4: 7E1602FA FF016806
	v_mov_b32_dpp v14, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003EE0CC: 7E1C02FA FF016805
	v_add_f32_e32 v8, v8, v12                                  // 0000003EE0D4: 06101908
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 0000003EE0D8: D5010006 21AA0D06
	v_mov_b32_dpp v13, v10 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003EE0E0: 7E1A02FA FF01680A
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 0000003EE0E8: D5010005 21AA0B05
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 0000003EE0F0: D501000A 21AA150A
	v_mov_b32_dpp v12, v8 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003EE0F8: 7E1802FA FF016808
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 0000003EE100: D5010008 21AA1108
	v_add_f32_e32 v6, v6, v11                                  // 0000003EE108: 060C1706
	v_cmp_gt_u32_e32 vcc_lo, 16, v9                            // 0000003EE10C: 7C981290
	v_add_f32_e32 v5, v5, v14                                  // 0000003EE110: 060A1D05
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003EE114: BF870214
	v_dual_add_f32 v9, v10, v13 :: v_dual_add_f32 v8, v8, v12  // 0000003EE118: C9081B0A 09081908
	v_mov_b32_e32 v10, v6                                      // 0000003EE120: 7E140306
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 0000003EE124: D5010006 21AA0D06
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003EE12C: BF870214
	v_mov_b32_e32 v13, v5                                      // 0000003EE130: 7E1A0305
	v_mov_b32_e32 v12, v9                                      // 0000003EE134: 7E180309
	v_cndmask_b32_e64 v11, -v8, v8, vcc_lo                     // 0000003EE138: D501000B 21AA1108
	v_permlanex16_b32 v8, v8, s7, 0xfedcba98                   // 0000003EE140: D65C0008 03FC0F08 FEDCBA98
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 0000003EE14C: D5010005 21AA0B05
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 0000003EE154: D5010009 21AA1309
	v_permlanex16_b32 v10, v10, s7, 0xfedcba98                 // 0000003EE15C: D65C000A 03FC0F0A FEDCBA98
	v_permlanex16_b32 v12, v12, s7, 0xfedcba98                 // 0000003EE168: D65C000C 03FC0F0C FEDCBA98
	v_permlanex16_b32 v13, v13, s7, 0xfedcba98                 // 0000003EE174: D65C000D 03FC0F0D FEDCBA98
	.long 0xd7006a01                                           // 0000003EE180: D7006A01
	v_cndmask_b32_e32 v1, v3, v1, vcc_lo                       // 0000003EE184: 02020303
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000003EE188: BF8700D1
	v_add_co_ci_u32_e64 v2, null, v4, v2, vcc_lo               // 0000003EE18C: D5207C02 01AA0504
	v_dual_add_f32 v3, v11, v8 :: v_dual_add_f32 v4, v6, v10   // 0000003EE194: C908110B 03041506
	v_add_f32_e32 v6, v9, v12                                  // 0000003EE19C: 060C1909
	v_add_f32_e32 v5, v5, v13                                  // 0000003EE1A0: 060A1B05
	.long 0xd7006a01                                           // 0000003EE1A4: D7006A01
	v_cndmask_b32_e32 v1, v1, v7, vcc_lo                       // 0000003EE1A8: 02020F01
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 0000003EE1AC: D5207C02 01AA0480
	v_fma_mixhi_f16 v3, v3, s8, 0                              // 0000003EE1B4: CC220003 02001103
	v_fma_mixlo_f16 v3, v4, s8, 0                              // 0000003EE1BC: CC210003 02001104
	v_fma_mixhi_f16 v4, v5, s8, 0                              // 0000003EE1C4: CC220004 02001105
	v_fma_mixlo_f16 v4, v6, s8, 0                              // 0000003EE1CC: CC210004 02001106
	global_store_b64 v[1:2], v[3:4], off                       // 0000003EE1D4: DC6E0000 007C0301
	s_or_b32 exec_lo, exec_lo, s6                              // 0000003EE1DC: 8C7E067E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003EE1E0: BF870009
	s_and_b32 vcc_lo, exec_lo, s3                              // 0000003EE1E4: 8B6A037E
	s_cbranch_vccnz 4                                          // 0000003EE1E8: BFA40004 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb1ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3fc>
	s_nop 0                                                    // 0000003EE1EC: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000003EE1F0: BFB60003
	s_endpgm                                                   // 0000003EE1F4: BFB00000
	s_cbranch_execz 65532                                      // 0000003EE1F8: BFA5FFFC <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb1ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	s_clause 0x3                                               // 0000003EE1FC: BF850003
	s_load_b32 s3, s[0:1], 0x120                               // 0000003EE200: F40000C0 F8000120
	s_load_b32 s4, s[0:1], 0x7c                                // 0000003EE208: F4000100 F800007C
	s_load_b32 s5, s[0:1], 0xc4                                // 0000003EE210: F4000140 F80000C4
	s_load_b32 s6, s[0:1], 0x10c                               // 0000003EE218: F4000180 F800010C
	v_and_b32_e32 v43, 31, v0                                  // 0000003EE220: 3656009F
	v_lshrrev_b32_e32 v42, 5, v0                               // 0000003EE224: 32540085
	s_delay_alu instid0(VALU_DEP_2)                            // 0000003EE228: BF870002
	v_lshlrev_b32_e32 v7, 3, v43                               // 0000003EE22C: 300E5683
	s_waitcnt lgkmcnt(0)                                       // 0000003EE230: BF89FC07
	s_cmp_gt_i32 s3, 1                                         // 0000003EE234: BF028103
	s_cselect_b32 s7, -1, 0                                    // 0000003EE238: 980780C1
	s_cmp_ge_i32 s2, s4                                        // 0000003EE23C: BF030402
	s_cselect_b32 s4, -1, 0                                    // 0000003EE240: 980480C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003EE244: BF870009
	s_and_b32 s4, s7, s4                                       // 0000003EE248: 8B040407
	s_cmp_gt_i32 s3, 2                                         // 0000003EE24C: BF028203
	v_cndmask_b32_e64 v1, 0, 1, s4                             // 0000003EE250: D5010001 00110280
	s_cselect_b32 s7, -1, 0                                    // 0000003EE258: 980780C1
	s_cmp_ge_i32 s2, s5                                        // 0000003EE25C: BF030502
	s_cselect_b32 s5, -1, 0                                    // 0000003EE260: 980580C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003EE264: BF870009
	s_and_b32 s4, s7, s5                                       // 0000003EE268: 8B040507
	s_cmp_gt_i32 s3, 3                                         // 0000003EE26C: BF028303
	v_readfirstlane_b32 s5, v1                                 // 0000003EE270: 7E0A0501
	s_cselect_b32 s3, -1, 0                                    // 0000003EE274: 980380C1
	s_cmp_ge_i32 s2, s6                                        // 0000003EE278: BF030602
	s_cselect_b32 s6, -1, 0                                    // 0000003EE27C: 980680C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 0000003EE280: BF8704D9
	s_and_b32 s3, s3, s6                                       // 0000003EE284: 8B030603
	s_and_b32 s4, s4, exec_lo                                  // 0000003EE288: 8B047E04
	s_cselect_b32 s4, 2, s5                                    // 0000003EE28C: 98040582
	s_and_b32 s3, s3, exec_lo                                  // 0000003EE290: 8B037E03
	s_cselect_b32 s3, 3, s4                                    // 0000003EE294: 98030483
	s_mulk_i32 s3, 0x48                                        // 0000003EE298: B8030048
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003EE29C: BF870009
	s_add_u32 s4, s0, s3                                       // 0000003EE2A0: 80040300
	s_addc_u32 s5, s1, 0                                       // 0000003EE2A4: 82058001
	s_clause 0x3                                               // 0000003EE2A8: BF850003
	s_load_b32 s28, s[4:5], 0x38                               // 0000003EE2AC: F4000702 F8000038
	s_load_b64 s[30:31], s[4:5], 0x40                          // 0000003EE2B4: F4040782 F8000040
	s_load_b128 s[20:23], s[4:5], 0x28                         // 0000003EE2BC: F4080502 F8000028
	s_load_b64 s[24:25], s[4:5], 0x20                          // 0000003EE2C4: F4040602 F8000020
	s_waitcnt lgkmcnt(0)                                       // 0000003EE2CC: BF89FC07
	s_abs_i32 s3, s21                                          // 0000003EE2D0: BE831515
	s_sub_i32 s2, s2, s23                                      // 0000003EE2D4: 81821702
	s_cvt_f32_u32 s6, s3                                       // 0000003EE2D8: BE866503
	s_sub_i32 s7, 0, s3                                        // 0000003EE2DC: 81870380
	s_abs_i32 s8, s2                                           // 0000003EE2E0: BE881502
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000003EE2E4: BF870299
	v_rcp_iflag_f32_e32 v1, s6                                 // 0000003EE2E8: 7E025606
	v_readfirstlane_b32 s6, v1                                 // 0000003EE2EC: 7E0C0501
	s_mul_f32 s6, s6, 0x4f7ffffe                               // 0000003EE2F0: A206FF06 4F7FFFFE
	s_delay_alu instid0(SALU_CYCLE_3) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 0000003EE2F8: BF87059B
	s_cvt_u32_f32 s6, s6                                       // 0000003EE2FC: BE866706
	s_mul_i32 s7, s7, s6                                       // 0000003EE300: 96070607
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000003EE304: BF870499
	s_mul_hi_u32 s7, s6, s7                                    // 0000003EE308: 96870706
	s_add_i32 s6, s6, s7                                       // 0000003EE30C: 81060706
	s_xor_b32 s7, s2, s21                                      // 0000003EE310: 8D071502
	s_mul_hi_u32 s6, s8, s6                                    // 0000003EE314: 96860608
	s_ashr_i32 s7, s7, 31                                      // 0000003EE318: 86079F07
	s_mul_i32 s9, s6, s3                                       // 0000003EE31C: 96090306
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003EE320: BF870009
	s_sub_i32 s8, s8, s9                                       // 0000003EE324: 81880908
	s_add_i32 s9, s6, 1                                        // 0000003EE328: 81098106
	s_sub_i32 s10, s8, s3                                      // 0000003EE32C: 818A0308
	s_cmp_ge_u32 s8, s3                                        // 0000003EE330: BF090308
	s_cselect_b32 s6, s9, s6                                   // 0000003EE334: 98060609
	s_cselect_b32 s8, s10, s8                                  // 0000003EE338: 9808080A
	s_add_i32 s9, s6, 1                                        // 0000003EE33C: 81098106
	s_cmp_ge_u32 s8, s3                                        // 0000003EE340: BF090308
	s_cselect_b32 s3, s9, s6                                   // 0000003EE344: 98030609
	s_load_b256 s[8:15], s[4:5], null                          // 0000003EE348: F40C0202 F8000000
	s_xor_b32 s3, s3, s7                                       // 0000003EE350: 8D030703
	s_ashr_i32 s29, s19, 31                                    // 0000003EE354: 861D9F13
	s_sub_i32 s26, s3, s7                                      // 0000003EE358: 819A0703
	s_lshr_b32 s4, s29, 25                                     // 0000003EE35C: 8504991D
	s_mul_i32 s3, s26, s21                                     // 0000003EE360: 9603151A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 0000003EE364: BF8704D9
	s_sub_i32 s23, s2, s3                                      // 0000003EE368: 81970302
	s_add_i32 s2, s19, s4                                      // 0000003EE36C: 81020413
	s_mul_i32 s27, s22, s23                                    // 0000003EE370: 961B1716
	s_ashr_i32 s2, s2, 7                                       // 0000003EE374: 86028702
	s_add_i32 s3, s27, s22                                     // 0000003EE378: 8103161B
	s_min_i32 s2, s2, s3                                       // 0000003EE37C: 89020302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000003EE380: BF8704B9
	s_sub_i32 s7, s2, s27                                      // 0000003EE384: 81871B02
	s_mov_b32 s2, exec_lo                                      // 0000003EE388: BE82007E
	s_lshl_b32 s22, s7, 1                                      // 0000003EE38C: 84168107
	.long 0xd4c3007e                                           // 0000003EE390: D4C3007E
	v_cndmask_b32_e32 v1, s22, v42, vcc_lo                     // 0000003EE394: 02025416
	s_xor_b32 s2, exec_lo, s2                                  // 0000003EE398: 8D02027E
	v_lshlrev_b32_e32 v7, 3, v43                               // 0000003EE39C: 300E5683
	s_and_not1_saveexec_b32 s33, s2                            // 0000003EE3A0: BEA13002
	s_cbranch_execz 286                                        // 0000003EE3A4: BFA5011E <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb1ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0xa20>
	s_abs_i32 s34, s7                                          // 0000003EE3A8: BEA21507
	v_lshlrev_b32_e32 v9, 7, v42                               // 0000003EE3AC: 30125487
	s_cvt_f32_u32 s2, s34                                      // 0000003EE3B0: BE826522
	v_and_b32_e32 v4, 4, v0                                    // 0000003EE3B4: 36080084
	v_and_b32_e32 v5, 8, v0                                    // 0000003EE3B8: 360A0088
	v_lshl_or_b32 v8, v42, 8, v7                               // 0000003EE3BC: D6560008 041D112A
	v_rcp_iflag_f32_e32 v1, s2                                 // 0000003EE3C4: 7E025602
	s_sub_i32 s2, 0, s34                                       // 0000003EE3C8: 81822280
	v_lshl_add_u32 v9, s27, 7, v9                              // 0000003EE3CC: D6460009 04250E1B
	s_ashr_i32 s38, s7, 31                                     // 0000003EE3D4: 86269F07
	.long 0xd44a0004                                           // 0000003EE3D8: D44A0004
	v_cndmask_b32_e32 v1, 0, v4, vcc_lo                        // 0000003EE3DC: 02020880
	s_mul_i32 s40, s38, 0x1400                                 // 0000003EE3E0: 9628FF26 00001400
	.long 0xd44a0005                                           // 0000003EE3E8: D44A0005
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 0000003EE3EC: 02020A80
	s_lshl_b32 s6, s7, 7                                       // 0000003EE3F0: 84068707
	s_add_i32 s35, s18, -1                                     // 0000003EE3F4: 8123C112
	s_mov_b32 s36, s19                                         // 0000003EE3F8: BEA40013
	v_dual_mul_f32 v1, 0x4f7ffffe, v1 :: v_dual_and_b32 v2, 1, v0// 0000003EE3FC: C8E402FF 01020081 4F7FFFFE
	s_mov_b32 s37, 0                                           // 0000003EE408: BEA50080
	s_lshl_b32 s39, s7, 8                                      // 0000003EE40C: 84278807
	s_mov_b32 s41, 0x76543210                                  // 0000003EE410: BEA900FF 76543210
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000003EE418: BF8701C1
	v_cvt_u32_f32_e32 v3, v1                                   // 0000003EE41C: 7E060F01
	v_dual_mov_b32 v4, v42 :: v_dual_and_b32 v1, 2, v0         // 0000003EE420: CA24012A 04000082
	s_mov_b32 s42, 0x3db504f3                                  // 0000003EE428: BEAA00FF 3DB504F3
	v_cmp_gt_u32_e32 vcc_lo, 16, v43                           // 0000003EE430: 7C985690
	.long 0xd72c0006                                           // 0000003EE434: D72C0006
	v_cndmask_b32_e32 v1, s2, v3, vcc_lo                       // 0000003EE438: 02020602
	.long 0xd44a0002                                           // 0000003EE43C: D44A0002
	v_cndmask_b32_e32 v1, 0, v2, vcc_lo                        // 0000003EE440: 02020480
	.long 0xd44a0003                                           // 0000003EE444: D44A0003
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000003EE448: 02020280
	v_subrev_nc_u32_e32 v2, s40, v8                            // 0000003EE44C: 4E041028
	v_lshl_or_b32 v1, v43, 2, v9                               // 0000003EE450: D6560001 0425052B
	s_sub_i32 s40, 0, s6                                       // 0000003EE458: 81A80680
	.long 0xd72d0006                                           // 0000003EE45C: D72D0006
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000003EE460: 02020D03
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003EE464: BF870001
	v_add_nc_u32_e32 v3, v3, v6                                // 0000003EE468: 4A060D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003EE46C: BF870091
	.long 0xd72d0005                                           // 0000003EE470: D72D0005
	v_cndmask_b32_e32 v1, v4, v3, vcc_lo                       // 0000003EE474: 02020704
	.long 0xd72c0006                                           // 0000003EE478: D72C0006
	v_cndmask_b32_e32 v0, v5, v34, vcc_lo                      // 0000003EE47C: 02004505
	v_add_nc_u32_e32 v8, 1, v5                                 // 0000003EE480: 4A100A81
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003EE484: BF870092
	v_sub_nc_u32_e32 v6, v4, v6                                // 0000003EE488: 4C0C0D04
	v_subrev_nc_u32_e32 v9, s34, v6                            // 0000003EE48C: 4E120C22
	.long 0xd44b0006                                           // 0000003EE490: D44B0006
	v_cndmask_b32_e32 v1, s34, v6, vcc_lo                      // 0000003EE494: 02020C22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003EE498: BF870191
	v_cndmask_b32_e64 v5, v5, v8, s6                           // 0000003EE49C: D5010005 001A1105
	v_cndmask_b32_e64 v6, v6, v9, s6                           // 0000003EE4A4: D5010006 001A1306
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003EE4AC: BF870112
	v_add_nc_u32_e32 v8, 1, v5                                 // 0000003EE4B0: 4A100A81
	.long 0xd44b0006                                           // 0000003EE4B4: D44B0006
	v_cndmask_b32_e32 v1, s34, v6, vcc_lo                      // 0000003EE4B8: 02020C22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003EE4BC: BF870091
	v_cndmask_b32_e64 v5, v5, v8, s6                           // 0000003EE4C0: D5010005 001A1105
	v_xor_b32_e32 v10, s38, v5                                 // 0000003EE4C8: 3A140A26
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003EE4CC: BF870121
	v_subrev_nc_u32_e32 v11, s38, v10                          // 0000003EE4D0: 4E161426
	.long 0xd72c000a                                           // 0000003EE4D4: D72C000A
	v_cndmask_b32_e32 v1, 0x1400, v10, vcc_lo                  // 0000003EE4D8: 020214FF 00001400
	v_min_i32_e32 v8, s35, v11                                 // 0000003EE4E0: 22101623
	v_mad_u64_u32 v[5:6], null, s40, v11, v[1:2]               // 0000003EE4E4: D6FE7C05 04061628
	.long 0xd72c000b                                           // 0000003EE4EC: D72C000B
	v_cndmask_b32_e32 v1, s39, v11, vcc_lo                     // 0000003EE4F0: 02021627
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003EE4F4: BF870193
	v_mad_i64_i32 v[8:9], null, v8, s36, 0                     // 0000003EE4F8: D6FF7C08 02004908
	v_ashrrev_i32_e32 v6, 31, v5                               // 0000003EE500: 340C0A9F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003EE504: BF870193
	v_sub_nc_u32_e32 v10, v10, v11                             // 0000003EE508: 4C14170A
	.long 0xd73c0008                                           // 0000003EE50C: D73C0008
	v_cndmask_b32_e32 v1, 1, v8, vcc_lo                        // 0000003EE510: 02021081
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003EE514: BF870193
	.long 0xd73c0005                                           // 0000003EE518: D73C0005
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 0000003EE51C: 02020A81
	v_add_nc_u32_e32 v10, v2, v10                              // 0000003EE520: 4A141502
	v_add_nc_u32_e32 v2, 0x800, v2                             // 0000003EE524: 4A0404FF 00000800
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003EE52C: BF870094
	.long 0xd700060c                                           // 0000003EE530: D700060C
	v_cndmask_b32_e32 v1, s16, v8, vcc_lo                      // 0000003EE534: 02021010
	v_add_co_ci_u32_e64 v13, null, s17, v9, s6                 // 0000003EE538: D5207C0D 001A1211
	s_waitcnt lgkmcnt(0)                                       // 0000003EE540: BF89FC07
	.long 0xd7000608                                           // 0000003EE544: D7000608
	v_cndmask_b32_e32 v1, s10, v5, vcc_lo                      // 0000003EE548: 02020A0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003EE54C: BF8700A1
	v_add_co_ci_u32_e64 v9, null, s11, v6, s6                  // 0000003EE550: D5207C09 001A0C0B
	.long 0xd7000605                                           // 0000003EE558: D7000605
	v_cndmask_b32_e32 v1, v12, v5, vcc_lo                      // 0000003EE55C: 02020B0C
	v_add_co_ci_u32_e64 v6, null, v13, v6, s6                  // 0000003EE560: D5207C06 001A0D0D
	global_load_b64 v[5:6], v[5:6], off                        // 0000003EE568: DC560000 057C0005
	global_load_b64 v[8:9], v[8:9], off                        // 0000003EE570: DC560000 087C0008
	s_waitcnt vmcnt(1)                                         // 0000003EE578: BF8907F7
	.long 0x7e1a3906                                           // 0000003EE57C: 7E1A3906
	v_and_b32_e32 v6, 0xffff0000, v6                           // 0000003EE580: 360C0CFF FFFF0000
	.long 0x7e183905                                           // 0000003EE588: 7E183905
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003EE58C: BF8701A3
	v_lshlrev_b32_e32 v13, 16, v13                             // 0000003EE590: 301A1A90
	s_waitcnt vmcnt(0)                                         // 0000003EE594: BF8903F7
	v_fma_mix_f32 v6, v9, v6, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 0000003EE598: CC200806 8A020D09
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003EE5A0: BF870113
	v_lshlrev_b32_e32 v12, 16, v12                             // 0000003EE5A4: 30181890
	v_fma_mix_f32 v14, v9, v13, v6 op_sel_hi:[1,0,0]           // 0000003EE5A8: CC20000E 0C1A1B09
	v_and_b32_e32 v5, 0xffff0000, v5                           // 0000003EE5B0: 360A0AFF FFFF0000
	v_fma_mix_f32 v6, v9, v13, -v6 op_sel_hi:[1,0,0]           // 0000003EE5B8: CC200006 8C1A1B09
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003EE5C0: BF870092
	v_fma_mix_f32 v5, v8, v5, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 0000003EE5C4: CC200805 8A020B08
	v_fma_mix_f32 v15, v8, v12, v5 op_sel_hi:[1,0,0]           // 0000003EE5CC: CC20000F 0C161908
	v_add_nc_u32_e32 v1, 0x400, v1                             // 0000003EE5D4: 4A0202FF 00000400
	v_fma_mix_f32 v5, v8, v12, -v5 op_sel_hi:[1,0,0]           // 0000003EE5DC: CC200005 8C161908
	v_add_nc_u32_e32 v4, 8, v4                                 // 0000003EE5E4: 4A080888
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003EE5E8: BF870194
	v_add_f32_e32 v8, v15, v14                                 // 0000003EE5EC: 06101D0F
	v_dual_sub_f32 v12, v15, v14 :: v_dual_add_f32 v9, v6, v5  // 0000003EE5F0: C9481D0F 0C080B06
	v_sub_f32_e32 v5, v5, v6                                   // 0000003EE5F8: 080A0D05
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003EE5FC: BF870214
	.long 0xd4430006                                           // 0000003EE600: D4430006
	v_cndmask_b32_e32 v1, s22, v4, vcc_lo                      // 0000003EE604: 02020816
	v_mov_b32_dpp v6, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003EE608: 7E0C02FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 0000003EE610: D5010008 200A1108
	v_mov_b32_dpp v14, v12 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003EE618: 7E1C02FA FF01610C
	v_mov_b32_dpp v15, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003EE620: 7E1E02FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, s2                          // 0000003EE628: D5010005 200A0B05
	v_cndmask_b32_e64 v12, -v12, v12, s2                       // 0000003EE630: D501000C 200A190C
	v_add_f32_e32 v6, v8, v6                                   // 0000003EE638: 060C0D08
	v_mov_b32_dpp v13, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003EE63C: 7E1A02FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s2                          // 0000003EE644: D5010009 200A1309
	v_add_f32_e32 v5, v5, v15                                  // 0000003EE64C: 060A1F05
	s_or_b32 s37, s6, s37                                      // 0000003EE650: 8C252506
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003EE654: BF870112
	v_dual_add_f32 v8, v9, v13 :: v_dual_add_f32 v9, v12, v14  // 0000003EE658: C9081B09 08081D0C
	v_mov_b32_dpp v15, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003EE660: 7E1E02FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 0000003EE668: D5010005 200E0B05
	v_mov_b32_dpp v12, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003EE670: 7E1802FA FF016206
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003EE678: BF870004
	v_mov_b32_dpp v13, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003EE67C: 7E1A02FA FF016208
	v_mov_b32_dpp v14, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003EE684: 7E1C02FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 0000003EE68C: D5010009 200E1309
	v_cndmask_b32_e64 v6, -v6, v6, s3                          // 0000003EE694: D5010006 200E0D06
	v_cndmask_b32_e64 v8, -v8, v8, s3                          // 0000003EE69C: D5010008 200E1108
	v_add_f32_e32 v5, v5, v15                                  // 0000003EE6A4: 060A1F05
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003EE6A8: BF870114
	v_add_f32_e32 v9, v9, v14                                  // 0000003EE6AC: 06121D09
	v_mov_b32_dpp v15, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003EE6B0: 7E1E02FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s4                          // 0000003EE6B8: D5010005 20120B05
	v_add_f32_e32 v6, v6, v12                                  // 0000003EE6C0: 060C1906
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000003EE6C4: BF870224
	v_mov_b32_dpp v14, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003EE6C8: 7E1C02FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s4                          // 0000003EE6D0: D5010009 20121309
	v_dual_add_f32 v8, v8, v13 :: v_dual_add_f32 v5, v5, v15   // 0000003EE6D8: C9081B08 08041F05
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000003EE6E0: BF870224
	v_mov_b32_dpp v12, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003EE6E4: 7E1802FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s4                          // 0000003EE6EC: D5010006 20120D06
	v_add_f32_e32 v9, v9, v14                                  // 0000003EE6F4: 06121D09
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003EE6F8: BF870004
	v_mov_b32_dpp v13, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003EE6FC: 7E1A02FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, s4                          // 0000003EE704: D5010008 20121108
	v_mov_b32_dpp v15, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003EE70C: 7E1E02FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s5                          // 0000003EE714: D5010005 20160B05
	v_add_f32_e32 v6, v6, v12                                  // 0000003EE71C: 060C1906
	v_mov_b32_dpp v14, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003EE720: 7E1C02FA FF016809
	v_cndmask_b32_e64 v9, -v9, v9, s5                          // 0000003EE728: D5010009 20161309
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003EE730: BF870214
	v_dual_add_f32 v8, v8, v13 :: v_dual_add_f32 v5, v5, v15   // 0000003EE734: C9081B08 08041F05
	v_mov_b32_dpp v12, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003EE73C: 7E1802FA FF016806
	v_cndmask_b32_e64 v6, -v6, v6, s5                          // 0000003EE744: D5010006 20160D06
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003EE74C: BF870214
	v_add_f32_e32 v9, v9, v14                                  // 0000003EE750: 06121D09
	v_mov_b32_dpp v13, v8 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003EE754: 7E1A02FA FF016808
	v_cndmask_b32_e64 v8, -v8, v8, s5                          // 0000003EE75C: D5010008 20161108
	v_mov_b32_e32 v15, v5                                      // 0000003EE764: 7E1E0305
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 0000003EE768: D5010005 21AA0B05
	v_mov_b32_e32 v14, v9                                      // 0000003EE770: 7E1C0309
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 0000003EE774: D5010009 21AA1309
	v_add_f32_e32 v8, v8, v13                                  // 0000003EE77C: 06101B08
	v_add_f32_e32 v6, v6, v12                                  // 0000003EE780: 060C1906
	v_permlanex16_b32 v15, v15, s41, 0xfedcba98                // 0000003EE784: D65C000F 03FC530F FEDCBA98
	v_permlanex16_b32 v14, v14, s41, 0xfedcba98                // 0000003EE790: D65C000E 03FC530E FEDCBA98
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003EE79C: BF870193
	v_dual_mov_b32 v13, v8 :: v_dual_mov_b32 v12, v6           // 0000003EE7A0: CA100108 0D0C0106
	v_add_f32_e32 v11, v5, v15                                 // 0000003EE7A8: 06161F05
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 0000003EE7AC: D5010008 21AA1108
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 0000003EE7B4: D5010006 21AA0D06
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003EE7BC: BF870124
	v_permlanex16_b32 v13, v13, s41, 0xfedcba98                // 0000003EE7C0: D65C000D 03FC530D FEDCBA98
	v_permlanex16_b32 v12, v12, s41, 0xfedcba98                // 0000003EE7CC: D65C000C 03FC530C FEDCBA98
	v_dual_add_f32 v9, v9, v14 :: v_dual_add_f32 v8, v8, v13   // 0000003EE7D8: C9081D09 09081B08
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003EE7E0: BF870112
	v_add_f32_e32 v6, v6, v12                                  // 0000003EE7E4: 060C1906
	v_fma_mixhi_f16 v5, v8, s42, 0                             // 0000003EE7E8: CC220005 02005508
	s_delay_alu instid0(VALU_DEP_2)                            // 0000003EE7F0: BF870002
	v_fma_mixlo_f16 v5, v6, s42, 0                             // 0000003EE7F4: CC210005 02005506
	v_fma_mixhi_f16 v6, v11, s42, 0                            // 0000003EE7FC: CC220006 0200550B
	v_fma_mixlo_f16 v6, v9, s42, 0                             // 0000003EE804: CC210006 02005509
	ds_store_b64 v10, v[5:6]                                   // 0000003EE80C: D9340000 0000050A
	s_and_not1_b32 exec_lo, exec_lo, s37                       // 0000003EE814: 917E257E
	s_cbranch_execnz 65300                                     // 0000003EE818: BFA6FF14 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb1ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x66c>
	s_or_b32 exec_lo, exec_lo, s37                             // 0000003EE81C: 8C7E257E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003EE820: BF870009
	s_or_b32 exec_lo, exec_lo, s33                             // 0000003EE824: 8C7E217E
	s_bfe_i32 s6, s7, 0x1001c                                  // 0000003EE828: 9386FF07 0001001C
	v_mad_u32_u24 v8, v43, 24, 0x2f0                           // 0000003EE830: D60B0008 03FD312B 000002F0
	s_lshr_b64 s[2:3], s[6:7], 29                              // 0000003EE83C: 85829D06
	s_lshr_b32 s3, s29, 28                                     // 0000003EE840: 85039C1D
	s_add_i32 s2, s2, 7                                        // 0000003EE844: 81028702
	s_add_i32 s3, s19, s3                                      // 0000003EE848: 81030313
	s_ashr_i32 s2, s2, 3                                       // 0000003EE84C: 86028302
	v_lshrrev_b32_e32 v1, 5, v8                                // 0000003EE850: 32021085
	.long 0xd72c000a                                           // 0000003EE854: D72C000A
	v_cndmask_b32_e32 v1, s2, v42, vcc_lo                      // 0000003EE858: 02025402
	s_ashr_i32 s3, s3, 4                                       // 0000003EE85C: 86038403
	s_lshl_b32 s4, s7, 3                                       // 0000003EE860: 84048307
	s_lshl_b32 s5, s27, 3                                      // 0000003EE864: 8405831B
	s_mul_i32 s7, s26, s3                                      // 0000003EE868: 9607031A
	s_ashr_i32 s6, s5, 31                                      // 0000003EE86C: 86069F05
	v_subrev_nc_u32_e32 v1, 24, v1                             // 0000003EE870: 4E020298
	v_cmp_eq_u32_e32 vcc_lo, 0, v43                            // 0000003EE874: 7C945680
	v_add_nc_u32_e32 v2, s2, v10                               // 0000003EE878: 4A041402
	s_mul_hi_i32 s2, s26, s3                                   // 0000003EE87C: 9702031A
	s_add_u32 s3, s7, s5                                       // 0000003EE880: 80030507
	s_addc_u32 s2, s2, s6                                      // 0000003EE884: 82020602
	s_mul_hi_u32 s5, s3, 0x300                                 // 0000003EE888: 9685FF03 00000300
	v_min_i32_e32 v44, s4, v2                                  // 0000003EE890: 22580404
	s_mul_i32 s4, s2, 0x300                                    // 0000003EE894: 9604FF02 00000300
	s_mulk_i32 s3, 0x300                                       // 0000003EE89C: B8030300
	v_cndmask_b32_e64 v5, v1, 23, vcc_lo                       // 0000003EE8A0: D5010005 01A92F01
	v_add_nc_u32_e32 v11, 8, v8                                // 0000003EE8A8: 4A161088
	.long 0xd4410002                                           // 0000003EE8AC: D4410002
	v_cndmask_b32_e32 v1, v10, v44, vcc_lo                     // 0000003EE8B0: 0202590A
	s_add_i32 s5, s5, s4                                       // 0000003EE8B4: 81050405
	s_waitcnt lgkmcnt(0)                                       // 0000003EE8B8: BF89FC07
	s_add_u32 s4, s8, s3                                       // 0000003EE8BC: 80040308
	s_addc_u32 s5, s9, s5                                      // 0000003EE8C0: 82050509
	s_waitcnt_vscnt null, 0x0                                  // 0000003EE8C4: BC7C0000
	s_barrier                                                  // 0000003EE8C8: BFBD0000
	buffer_gl0_inv                                             // 0000003EE8CC: E0AC0000 00000000
	s_and_saveexec_b32 s6, s2                                  // 0000003EE8D4: BE862002
	s_cbranch_execz 122                                        // 0000003EE8D8: BFA5007A <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb1ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0xcc4>
	v_lshrrev_b32_e32 v1, 5, v11                               // 0000003EE8DC: 32021685
	.long 0xd4440003                                           // 0000003EE8E0: D4440003
	v_cndmask_b32_e32 v1, 23, v5, vcc_lo                       // 0000003EE8E4: 02020A97
	v_mad_i64_i32 v[3:4], null, 0x300, v10, s[4:5]             // 0000003EE8E8: D6FF7C03 001214FF 00000300
	v_mov_b32_e32 v6, 0                                        // 0000003EE8F4: 7E0C0280
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003EE8F8: BF870214
	v_subrev_nc_u32_e32 v1, 24, v1                             // 0000003EE8FC: 4E020298
	v_cndmask_b32_e64 v2, 0xe9, 1, s3                          // 0000003EE900: D5010002 000D02FF 000000E9
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003EE90C: BF870193
	.long 0xd73c000c                                           // 0000003EE910: D73C000C
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 0000003EE914: 02020A82
	v_cndmask_b32_e64 v1, v1, 23, vcc_lo                       // 0000003EE918: D5010001 01A92F01
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003EE920: BF870113
	v_add_nc_u32_e32 v9, v2, v5                                // 0000003EE924: 4A120B02
	.long 0xd4440003                                           // 0000003EE928: D4440003
	v_cndmask_b32_e32 v1, 23, v1, vcc_lo                       // 0000003EE92C: 02020297
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003EE930: BF870112
	v_lshlrev_b32_e32 v14, 24, v9                              // 0000003EE934: 301C1298
	v_cndmask_b32_e64 v15, 0xe9, 1, s3                         // 0000003EE938: D501000F 000D02FF 000000E9
	.long 0xd700030c                                           // 0000003EE944: D700030C
	v_cndmask_b32_e32 v1, v3, v12, vcc_lo                      // 0000003EE948: 02021903
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003EE94C: BF870191
	v_add_co_ci_u32_e64 v13, null, v4, v13, s3                 // 0000003EE950: D5207C0D 000E1B04
	v_add_nc_u32_e32 v16, v15, v1                              // 0000003EE958: 4A20030F
	v_mov_b32_e32 v2, v6                                       // 0000003EE95C: 7E040306
	v_bfe_i32 v6, v9, 7, 1                                     // 0000003EE960: D6110006 02050F09
	v_ashrrev_i32_e32 v9, 22, v14                              // 0000003EE968: 34121C96
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003EE96C: BF870214
	v_lshlrev_b32_e32 v17, 24, v16                             // 0000003EE970: 30222098
	.long 0xd73c0001                                           // 0000003EE974: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000003EE978: 02020282
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003EE97C: BF870193
	.long 0xd700030e                                           // 0000003EE980: D700030E
	v_cndmask_b32_e32 v1, v3, v9, vcc_lo                       // 0000003EE984: 02021303
	v_ashrrev_i32_e32 v9, 22, v17                              // 0000003EE988: 34122296
	v_add_co_ci_u32_e64 v15, null, v4, v6, s3                  // 0000003EE98C: D5207C0F 000E0D04
	v_bfe_i32 v6, v16, 7, 1                                    // 0000003EE994: D6110006 02050F10
	.long 0xd7000310                                           // 0000003EE99C: D7000310
	v_cndmask_b32_e32 v1, v3, v1, vcc_lo                       // 0000003EE9A0: 02020303
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003EE9A4: BF8700A1
	v_add_co_ci_u32_e64 v17, null, v4, v2, s3                  // 0000003EE9A8: D5207C11 000E0504
	.long 0xd700032d                                           // 0000003EE9B0: D700032D
	v_cndmask_b32_e32 v1, v3, v9, vcc_lo                       // 0000003EE9B4: 02021303
	v_add_co_ci_u32_e64 v46, null, v4, v6, s3                  // 0000003EE9B8: D5207C2E 000E0D04
	s_clause 0x1f                                              // 0000003EE9C0: BF85001F
	global_load_b32 v2, v[12:13], off                          // 0000003EE9C4: DC520000 027C000C
	global_load_b32 v39, v[12:13], off offset:96               // 0000003EE9CC: DC520060 277C000C
	global_load_b32 v35, v[12:13], off offset:192              // 0000003EE9D4: DC5200C0 237C000C
	global_load_b32 v31, v[12:13], off offset:288              // 0000003EE9DC: DC520120 1F7C000C
	global_load_b32 v27, v[12:13], off offset:384              // 0000003EE9E4: DC520180 1B7C000C
	global_load_b32 v23, v[12:13], off offset:480              // 0000003EE9EC: DC5201E0 177C000C
	global_load_b32 v19, v[12:13], off offset:576              // 0000003EE9F4: DC520240 137C000C
	global_load_b32 v13, v[12:13], off offset:672              // 0000003EE9FC: DC5202A0 0D7C000C
	global_load_b32 v1, v[14:15], off                          // 0000003EEA04: DC520000 017C000E
	global_load_b32 v38, v[14:15], off offset:96               // 0000003EEA0C: DC520060 267C000E
	global_load_b32 v34, v[14:15], off offset:192              // 0000003EEA14: DC5200C0 227C000E
	global_load_b32 v30, v[14:15], off offset:288              // 0000003EEA1C: DC520120 1E7C000E
	global_load_b32 v26, v[14:15], off offset:384              // 0000003EEA24: DC520180 1A7C000E
	global_load_b32 v22, v[14:15], off offset:480              // 0000003EEA2C: DC5201E0 167C000E
	global_load_b32 v18, v[14:15], off offset:576              // 0000003EEA34: DC520240 127C000E
	global_load_b32 v12, v[14:15], off offset:672              // 0000003EEA3C: DC5202A0 0C7C000E
	global_load_b32 v4, v[16:17], off                          // 0000003EEA44: DC520000 047C0010
	global_load_b32 v41, v[16:17], off offset:96               // 0000003EEA4C: DC520060 297C0010
	global_load_b32 v37, v[16:17], off offset:192              // 0000003EEA54: DC5200C0 257C0010
	global_load_b32 v33, v[16:17], off offset:288              // 0000003EEA5C: DC520120 217C0010
	global_load_b32 v29, v[16:17], off offset:384              // 0000003EEA64: DC520180 1D7C0010
	global_load_b32 v25, v[16:17], off offset:480              // 0000003EEA6C: DC5201E0 197C0010
	global_load_b32 v21, v[16:17], off offset:576              // 0000003EEA74: DC520240 157C0010
	global_load_b32 v17, v[16:17], off offset:672              // 0000003EEA7C: DC5202A0 117C0010
	global_load_b32 v3, v[45:46], off                          // 0000003EEA84: DC520000 037C002D
	global_load_b32 v40, v[45:46], off offset:96               // 0000003EEA8C: DC520060 287C002D
	global_load_b32 v36, v[45:46], off offset:192              // 0000003EEA94: DC5200C0 247C002D
	global_load_b32 v32, v[45:46], off offset:288              // 0000003EEA9C: DC520120 207C002D
	global_load_b32 v28, v[45:46], off offset:384              // 0000003EEAA4: DC520180 1C7C002D
	global_load_b32 v24, v[45:46], off offset:480              // 0000003EEAAC: DC5201E0 187C002D
	global_load_b32 v20, v[45:46], off offset:576              // 0000003EEAB4: DC520240 147C002D
	global_load_b32 v16, v[45:46], off offset:672              // 0000003EEABC: DC5202A0 107C002D
	s_or_b32 exec_lo, exec_lo, s6                              // 0000003EEAC4: 8C7E067E
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v46, 0              // 0000003EEAC8: CA100080 092E0080
	v_dual_mov_b32 v47, 0 :: v_dual_mov_b32 v48, 0             // 0000003EEAD0: CA100080 2F300080
	v_dual_mov_b32 v49, 0 :: v_dual_mov_b32 v50, 0             // 0000003EEAD8: CA100080 31320080
	v_dual_mov_b32 v51, 0 :: v_dual_mov_b32 v54, 0             // 0000003EEAE0: CA100080 33360080
	v_dual_mov_b32 v45, 0 :: v_dual_mov_b32 v52, 0             // 0000003EEAE8: CA100080 2D340080
	v_dual_mov_b32 v53, 0 :: v_dual_mov_b32 v56, 0             // 0000003EEAF0: CA100080 35380080
	v_dual_mov_b32 v55, 0 :: v_dual_mov_b32 v58, 0             // 0000003EEAF8: CA100080 373A0080
	v_mov_b32_e32 v57, 0                                       // 0000003EEB00: 7E720280
	v_mov_b32_e32 v59, 0                                       // 0000003EEB04: 7E760280
	s_ashr_i32 s27, s26, 31                                    // 0000003EEB08: 861B9F1A
	s_and_saveexec_b32 s3, s2                                  // 0000003EEB0C: BE832002
	s_cbranch_execz 1149                                       // 0000003EEB10: BFA5047D <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb1ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1f08>
	v_lshrrev_b32_e32 v6, 5, v11                               // 0000003EEB14: 320C1685
	v_or_b32_e32 v15, 4, v7                                    // 0000003EEB18: 381E0E84
	v_dual_mov_b32 v9, 0 :: v_dual_and_b32 v14, 0x7e0, v8      // 0000003EEB1C: CA240080 090E10FF 000007E0
	.long 0xd4440002                                           // 0000003EEB28: D4440002
	v_cndmask_b32_e32 v1, 23, v5, vcc_lo                       // 0000003EEB2C: 02020A97
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000003EEB30: BF870244
	v_subrev_nc_u32_e32 v7, 24, v6                             // 0000003EEB34: 4E0E0C98
	v_mul_i32_i24_e32 v11, 0xffffffe8, v43                     // 0000003EEB38: 121656FF FFFFFFE8
	v_ashrrev_i32_e32 v6, 31, v5                               // 0000003EEB40: 340C0A9F
	v_dual_mov_b32 v47, v9 :: v_dual_and_b32 v46, 16, v0       // 0000003EEB44: CA240109 2F2E0090
	v_cndmask_b32_e64 v8, v7, 23, vcc_lo                       // 0000003EEB4C: D5010008 01A92F07
	v_cndmask_b32_e64 v45, 0xe9, 1, s2                         // 0000003EEB54: D501002D 000902FF 000000E9
	v_add3_u32 v62, v11, v14, 0xfffffd34                       // 0000003EEB60: D655003E 03FE1D0B FFFFFD34
	v_mad_u32_u24 v14, v15, 3, 0x2f0                           // 0000003EEB6C: D60B000E 03FD070F 000002F0
	v_dual_mov_b32 v49, v9 :: v_dual_add_nc_u32 v60, 1, v10    // 0000003EEB78: CA200109 313C1481
	.long 0xd7030007                                           // 0000003EEB80: D7030007
	v_cndmask_b32_e32 v0, v8, v129, vcc_lo                     // 0000003EEB84: 02010308
	v_add_nc_u32_e32 v52, v45, v5                              // 0000003EEB88: 4A680B2D
	v_lshl_or_b32 v63, v10, 5, v46                             // 0000003EEB8C: D656003F 04B90B0A
	.long 0xd73c000a                                           // 0000003EEB94: D73C000A
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 0000003EEB98: 02020A82
	v_mul_i32_i24_e32 v15, -3, v15                             // 0000003EEB9C: 121E1EC3
	.long 0xd7624007                                           // 0000003EEBA0: D7624007
	v_cndmask_b32_e32 v1, 0xff, v7, vcc_lo                     // 0000003EEBA4: 02020EFF 000000FF
	v_dual_mov_b32 v51, v9 :: v_dual_and_b32 v6, 0x7e0, v14    // 0000003EEBAC: CA240109 33061CFF 000007E0
	v_mov_b32_e32 v46, v9                                      // 0000003EEBB8: 7E5C0309
	v_sub_nc_u32_e32 v61, 0, v44                               // 0000003EEBBC: 4C7A5880
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003EEBC0: BF870004
	v_cmp_ne_u16_e32 vcc_lo, 24, v135/*Invalid register, operand has 'VGPR_32_Lo128' register class*/// 0000003EEBC4: 7C7B0E98
	v_mov_b32_e32 v54, v9                                      // 0000003EEBC8: 7E6C0309
	v_add3_u32 v64, v15, v6, 0xfffffd34                        // 0000003EEBCC: D6550040 03FE0D0F FFFFFD34
	.long 0xd73c000e                                           // 0000003EEBD8: D73C000E
	v_cndmask_b32_e32 v1, 2, v8, vcc_lo                        // 0000003EEBDC: 02021082
	v_mov_b32_e32 v53, v9                                      // 0000003EEBE0: 7E6A0309
	v_cndmask_b16 v5, 0, v7, vcc_lo                            // 0000003EEBE4: D65D0005 01AA0E80
	v_dual_mov_b32 v48, v9 :: v_dual_and_b32 v7, 0xff, v52     // 0000003EEBEC: CA240109 300668FF 000000FF
	v_mov_b32_e32 v50, v9                                      // 0000003EEBF8: 7E640309
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000003EEBFC: BF870223
	v_dual_mov_b32 v52, v9 :: v_dual_and_b32 v5, 0xff, v5      // 0000003EEC00: CA240109 34040AFF 000000FF
	v_mov_b32_e32 v45, v9                                      // 0000003EEC0C: 7E5A0309
	v_lshlrev_b32_e32 v65, 2, v7                               // 0000003EEC10: 30820E82
	v_mov_b32_e32 v55, v9                                      // 0000003EEC14: 7E6E0309
	v_mov_b32_e32 v56, v9                                      // 0000003EEC18: 7E700309
	v_lshlrev_b32_e32 v66, 2, v5                               // 0000003EEC1C: 30840A82
	v_mov_b32_e32 v58, v9                                      // 0000003EEC20: 7E740309
	v_mov_b32_e32 v57, v9                                      // 0000003EEC24: 7E720309
	v_mov_b32_e32 v59, v9                                      // 0000003EEC28: 7E760309
	s_mov_b32 s2, 0                                            // 0000003EEC2C: BE820080
	s_mov_b32 s6, 0xdcd12d                                     // 0000003EEC30: BE8600FF 00DCD12D
	s_movk_i32 s7, 0x83                                        // 0000003EEC38: B0070083
	s_movk_i32 s8, 0x1eee                                      // 0000003EEC3C: B0081EEE
	s_branch 980                                               // 0000003EEC40: BFA003D4 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb1ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1d94>
	s_or_b32 exec_lo, exec_lo, s9                              // 0000003EEC44: 8C7E097E
	s_waitcnt vmcnt(23)                                        // 0000003EEC48: BF895FF7
	.long 0xd73d0063                                           // 0000003EEC4C: D73D0063
	v_cndmask_b32_e32 v1, v62, v1, vcc_lo                      // 0000003EEC50: 0202033E
	s_waitcnt vmcnt(7)                                         // 0000003EEC54: BF891FF7
	.long 0xd73d0064                                           // 0000003EEC58: D73D0064
	v_cndmask_b32_e32 v1, v64, v3, vcc_lo                      // 0000003EEC5C: 02020740
	ds_load_b128 v[1:4], v63                                   // 0000003EEC60: DBFC0000 0100003F
	ds_load_b128 v[5:8], v63 offset:5120                       // 0000003EEC68: DBFC1400 0500003F
	.long 0xd73d0026                                           // 0000003EEC70: D73D0026
	v_cndmask_b32_e32 v1, v62, v38, vcc_lo                     // 0000003EEC74: 02024D3E
	s_waitcnt vmcnt(6)                                         // 0000003EEC78: BF891BF7
	.long 0xd73d0027                                           // 0000003EEC7C: D73D0027
	v_cndmask_b32_e32 v1, v64, v40, vcc_lo                     // 0000003EEC80: 02025140
	.long 0xd73d0022                                           // 0000003EEC84: D73D0022
	v_cndmask_b32_e32 v1, v62, v34, vcc_lo                     // 0000003EEC88: 0202453E
	v_bfe_u32 v101, v99, 9, 16                                 // 0000003EEC8C: D6100065 02411363
	v_mul_u32_u24_e32 v107, s6, v101                           // 0000003EEC94: 16D6CA06
	v_mul_u32_u24_e32 v101, s7, v101                           // 0000003EEC98: 16CACA07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000003EEC9C: BF870151
	v_lshl_add_u32 v101, v101, 24, v107                        // 0000003EECA0: D6460065 05AD3165
	v_bfe_u32 v103, v99, 3, 16                                 // 0000003EECA8: D6100067 02410763
	v_bfe_u32 v102, v99, 6, 16                                 // 0000003EECB0: D6100066 02410D63
	v_mul_u32_u24_e32 v107, s6, v103                           // 0000003EECB8: 16D6CE06
	v_mul_u32_u24_e32 v103, s7, v103                           // 0000003EECBC: 16CECE07
	v_lshl_add_u32 v103, v103, 24, v107                        // 0000003EECC0: D6460067 05AD3167
	v_mul_u32_u24_e32 v107, s6, v102                           // 0000003EECC8: 16D6CC06
	v_mul_u32_u24_e32 v102, s7, v102                           // 0000003EECCC: 16CCCC07
	v_sad_u8 v101, v101, 0, 0x6400                             // 0000003EECD0: D6220065 03FD0165 00006400
	v_lshl_add_u32 v102, v102, 24, v107                        // 0000003EECDC: D6460066 05AD3166
	v_and_b32_e32 v99, 0xffff, v99                             // 0000003EECE4: 36C6C6FF 0000FFFF
	v_mul_u32_u24_e32 v107, s6, v99                            // 0000003EECEC: 16D6C606
	v_mul_u32_u24_e32 v99, s7, v99                             // 0000003EECF0: 16C6C607
	v_sad_u8 v103, v103, 0, 0x6400                             // 0000003EECF4: D6220067 03FD0167 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 0000003EED00: BF870002
	v_lshl_add_u32 v99, v99, 24, v107                          // 0000003EED04: D6460063 05AD3163
	v_and_b32_e32 v101, 0xffff, v101                           // 0000003EED0C: 36CACAFF 0000FFFF
	v_sad_u8 v102, v102, 0, 0x6400                             // 0000003EED14: D6220066 03FD0166 00006400
	v_bfe_u32 v104, v100, 9, 16                                // 0000003EED20: D6100068 02411364
	v_mul_u32_u24_e32 v107, s6, v104                           // 0000003EED28: 16D6D006
	v_mul_u32_u24_e32 v104, s7, v104                           // 0000003EED2C: 16D0D007
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003EED30: BF870001
	v_lshl_add_u32 v104, v104, 24, v107                        // 0000003EED34: D6460068 05AD3168
	v_and_b32_e32 v103, 0xffff, v103                           // 0000003EED3C: 36CECEFF 0000FFFF
	v_sad_u8 v99, v99, 0, 0x6400                               // 0000003EED44: D6220063 03FD0163 00006400
	v_lshl_or_b32 v101, v102, 16, v101                         // 0000003EED50: D6560065 05952166
	v_bfe_u32 v105, v100, 6, 16                                // 0000003EED58: D6100069 02410D64
	v_mul_u32_u24_e32 v107, s6, v105                           // 0000003EED60: 16D6D206
	v_mul_u32_u24_e32 v105, s7, v105                           // 0000003EED64: 16D2D207
	v_sad_u8 v104, v104, 0, 0x6400                             // 0000003EED68: D6220068 03FD0168 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 0000003EED74: BF870002
	v_lshl_add_u32 v105, v105, 24, v107                        // 0000003EED78: D6460069 05AD3169
	v_lshl_or_b32 v99, v99, 16, v103                           // 0000003EED80: D6560063 059D2163
	v_pk_fma_f16 v101, v101, s8, 0xc931 op_sel_hi:[1,0,0]      // 0000003EED88: CC0E0065 0BFC1165 0000C931
	v_bfe_u32 v106, v100, 3, 16                                // 0000003EED94: D610006A 02410764
	v_and_b32_e32 v100, 0xffff, v100                           // 0000003EED9C: 36C8C8FF 0000FFFF
	v_sad_u8 v103, v105, 0, 0x6400                             // 0000003EEDA4: D6220067 03FD0169 00006400
	v_pk_fma_f16 v99, v99, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000003EEDB0: CC0E0063 0BFC1163 0000C931
	s_waitcnt lgkmcnt(1)                                       // 0000003EEDBC: BF89FC17
	v_dual_dot2acc_f32_f16 v59, v101, v1 :: v_dual_and_b32 v102, 0xffff, v104// 0000003EEDC0: CB240365 3B66D0FF 0000FFFF
	v_mul_u32_u24_e32 v107, s6, v106                           // 0000003EEDCC: 16D6D406
	v_mul_u32_u24_e32 v106, s7, v106                           // 0000003EEDD0: 16D4D407
	v_lshl_add_u32 v106, v106, 24, v107                        // 0000003EEDD4: D646006A 05AD316A
	s_delay_alu instid0(VALU_DEP_2)                            // 0000003EEDDC: BF870002
	v_dot2acc_f32_f16 v59, v99, v2                             // 0000003EEDE0: 04760563
	v_lshl_or_b32 v102, v103, 16, v102                         // 0000003EEDE4: D6560066 05992167
	s_waitcnt lgkmcnt(0)                                       // 0000003EEDEC: BF89FC07
	v_dot2acc_f32_f16 v57, v101, v5                            // 0000003EEDF0: 04720B65
	v_mul_u32_u24_e32 v105, s6, v100                           // 0000003EEDF4: 16D2C806
	v_mul_u32_u24_e32 v100, s7, v100                           // 0000003EEDF8: 16C8C807
	v_sad_u8 v104, v106, 0, 0x6400                             // 0000003EEDFC: D6220068 03FD016A 00006400
	v_lshl_add_u32 v100, v100, 24, v105                        // 0000003EEE08: D6460064 05A53164
	v_pk_fma_f16 v102, v102, s8, 0xc931 op_sel_hi:[1,0,0]      // 0000003EEE10: CC0E0066 0BFC1166 0000C931
	v_dot2acc_f32_f16 v57, v99, v6                             // 0000003EEE1C: 04720D63
	v_bfe_u32 v40, v38, 9, 16                                  // 0000003EEE20: D6100028 02411326
	v_and_b32_e32 v103, 0xffff, v104                           // 0000003EEE28: 36CED0FF 0000FFFF
	v_sad_u8 v100, v100, 0, 0x6400                             // 0000003EEE30: D6220064 03FD0164 00006400
	v_dot2acc_f32_f16 v59, v102, v3                            // 0000003EEE3C: 04760766
	v_dot2acc_f32_f16 v57, v102, v7                            // 0000003EEE40: 04720F66
	v_mul_u32_u24_e32 v102, s6, v40                            // 0000003EEE44: 16CC5006
	v_mul_u32_u24_e32 v40, s7, v40                             // 0000003EEE48: 16505007
	v_lshl_add_u32 v40, v40, 24, v102                          // 0000003EEE4C: D6460028 05993128
	v_bfe_u32 v99, v38, 3, 16                                  // 0000003EEE54: D6100063 02410726
	v_lshl_or_b32 v100, v100, 16, v103                         // 0000003EEE5C: D6560064 059D2164
	v_bfe_u32 v41, v38, 6, 16                                  // 0000003EEE64: D6100029 02410D26
	v_mul_u32_u24_e32 v103, s6, v99                            // 0000003EEE6C: 16CEC606
	v_mul_u32_u24_e32 v99, s7, v99                             // 0000003EEE70: 16C6C607
	v_lshl_add_u32 v99, v99, 24, v103                          // 0000003EEE74: D6460063 059D3163
	v_mul_u32_u24_e32 v103, s6, v41                            // 0000003EEE7C: 16CE5206
	v_mul_u32_u24_e32 v41, s7, v41                             // 0000003EEE80: 16525207
	v_bfe_u32 v101, v39, 9, 16                                 // 0000003EEE84: D6100065 02411327
	v_sad_u8 v40, v40, 0, 0x6400                               // 0000003EEE8C: D6220028 03FD0128 00006400
	v_lshl_add_u32 v41, v41, 24, v103                          // 0000003EEE98: D6460029 059D3129
	v_mul_u32_u24_e32 v105, s6, v101                           // 0000003EEEA0: 16D2CA06
	v_mul_u32_u24_e32 v101, s7, v101                           // 0000003EEEA4: 16CACA07
	v_lshl_add_u32 v101, v101, 24, v105                        // 0000003EEEA8: D6460065 05A53165
	v_and_b32_e32 v38, 0xffff, v38                             // 0000003EEEB0: 364C4CFF 0000FFFF
	v_bfe_u32 v103, v39, 3, 16                                 // 0000003EEEB8: D6100067 02410727
	v_mul_u32_u24_e32 v104, s6, v38                            // 0000003EEEC0: 16D04C06
	v_mul_u32_u24_e32 v38, s7, v38                             // 0000003EEEC4: 164C4C07
	v_bfe_u32 v102, v39, 6, 16                                 // 0000003EEEC8: D6100066 02410D27
	v_and_b32_e32 v40, 0xffff, v40                             // 0000003EEED0: 365050FF 0000FFFF
	v_sad_u8 v41, v41, 0, 0x6400                               // 0000003EEED8: D6220029 03FD0129 00006400
	v_lshl_add_u32 v38, v38, 24, v104                          // 0000003EEEE4: D6460026 05A13126
	v_mul_u32_u24_e32 v104, s6, v103                           // 0000003EEEEC: 16D0CE06
	v_mul_u32_u24_e32 v103, s7, v103                           // 0000003EEEF0: 16CECE07
	v_lshl_add_u32 v103, v103, 24, v104                        // 0000003EEEF4: D6460067 05A13167
	v_mul_u32_u24_e32 v104, s6, v102                           // 0000003EEEFC: 16D0CC06
	v_mul_u32_u24_e32 v102, s7, v102                           // 0000003EEF00: 16CCCC07
	v_sad_u8 v101, v101, 0, 0x6400                             // 0000003EEF04: D6220065 03FD0165 00006400
	v_lshl_add_u32 v102, v102, 24, v104                        // 0000003EEF10: D6460066 05A13166
	v_lshl_or_b32 v40, v41, 16, v40                            // 0000003EEF18: D6560028 04A12129
	s_waitcnt vmcnt(5)                                         // 0000003EEF20: BF8917F7
	.long 0xd73d0023                                           // 0000003EEF24: D73D0023
	v_cndmask_b32_e32 v1, v64, v36, vcc_lo                     // 0000003EEF28: 02024940
	v_bfe_u32 v36, v34, 9, 16                                  // 0000003EEF2C: D6100024 02411322
	v_and_b32_e32 v101, 0xffff, v101                           // 0000003EEF34: 36CACAFF 0000FFFF
	v_sad_u8 v102, v102, 0, 0x6400                             // 0000003EEF3C: D6220066 03FD0166 00006400
	v_pk_fma_f16 v40, v40, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000003EEF48: CC0E0028 0BFC1128 0000C931
	v_pk_fma_f16 v100, v100, s8, 0xc931 op_sel_hi:[1,0,0]      // 0000003EEF54: CC0E0064 0BFC1164 0000C931
	v_bfe_u32 v37, v34, 6, 16                                  // 0000003EEF60: D6100025 02410D22
	v_sad_u8 v99, v99, 0, 0x6400                               // 0000003EEF68: D6220063 03FD0163 00006400
	v_lshl_or_b32 v41, v102, 16, v101                          // 0000003EEF74: D6560029 05952166
	v_mul_u32_u24_e32 v102, s6, v36                            // 0000003EEF7C: 16CC4806
	v_mul_u32_u24_e32 v36, s7, v36                             // 0000003EEF80: 16484807
	v_lshl_add_u32 v36, v36, 24, v102                          // 0000003EEF84: D6460024 05993124
	v_dot2acc_f32_f16 v58, v40, v1                             // 0000003EEF8C: 04740328
	v_dot2acc_f32_f16 v56, v40, v5                             // 0000003EEF90: 04700B28
	v_bfe_u32 v40, v34, 3, 16                                  // 0000003EEF94: D6100028 02410722
	v_mul_u32_u24_e32 v102, s6, v40                            // 0000003EEF9C: 16CC5006
	v_mul_u32_u24_e32 v40, s7, v40                             // 0000003EEFA0: 16505007
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003EEFA4: BF870001
	v_lshl_add_u32 v40, v40, 24, v102                          // 0000003EEFA8: D6460028 05993128
	v_mul_u32_u24_e32 v102, s6, v37                            // 0000003EEFB0: 16CC4A06
	v_mul_u32_u24_e32 v37, s7, v37                             // 0000003EEFB4: 164A4A07
	v_sad_u8 v36, v36, 0, 0x6400                               // 0000003EEFB8: D6220024 03FD0124 00006400
	v_lshl_add_u32 v37, v37, 24, v102                          // 0000003EEFC4: D6460025 05993125
	v_dual_dot2acc_f32_f16 v59, v100, v4 :: v_dual_and_b32 v34, 0xffff, v34// 0000003EEFCC: CB240964 3B2244FF 0000FFFF
	v_mul_u32_u24_e32 v102, s6, v34                            // 0000003EEFD8: 16CC4406
	v_mul_u32_u24_e32 v34, s7, v34                             // 0000003EEFDC: 16444407
	v_sad_u8 v40, v40, 0, 0x6400                               // 0000003EEFE0: D6220028 03FD0128 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 0000003EEFEC: BF870002
	v_lshl_add_u32 v34, v34, 24, v102                          // 0000003EEFF0: D6460022 05993122
	v_and_b32_e32 v36, 0xffff, v36                             // 0000003EEFF8: 364848FF 0000FFFF
	v_sad_u8 v37, v37, 0, 0x6400                               // 0000003EF000: D6220025 03FD0125 00006400
	v_sad_u8 v38, v38, 0, 0x6400                               // 0000003EF00C: D6220026 03FD0126 00006400
	v_and_b32_e32 v40, 0xffff, v40                             // 0000003EF018: 365050FF 0000FFFF
	v_sad_u8 v34, v34, 0, 0x6400                               // 0000003EF020: D6220022 03FD0122 00006400
	v_dot2acc_f32_f16 v57, v100, v8                            // 0000003EF02C: 04721164
	v_lshl_or_b32 v36, v37, 16, v36                            // 0000003EF030: D6560024 04912125
	v_bfe_u32 v100, v35, 6, 16                                 // 0000003EF038: D6100064 02410D23
	v_sad_u8 v103, v103, 0, 0x6400                             // 0000003EF040: D6220067 03FD0167 00006400
	v_lshl_or_b32 v34, v34, 16, v40                            // 0000003EF04C: D6560022 04A12122
	v_pk_fma_f16 v41, v41, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000003EF054: CC0E0029 0BFC1129 0000C931
	v_pk_fma_f16 v36, v36, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000003EF060: CC0E0024 0BFC1124 0000C931
	v_and_b32_e32 v39, 0xffff, v39                             // 0000003EF06C: 364E4EFF 0000FFFF
	v_bfe_u32 v101, v35, 3, 16                                 // 0000003EF074: D6100065 02410723
	v_pk_fma_f16 v34, v34, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000003EF07C: CC0E0022 0BFC1122 0000C931
	.long 0xd73d001e                                           // 0000003EF088: D73D001E
	v_cndmask_b32_e32 v1, v62, v30, vcc_lo                     // 0000003EF08C: 02023D3E
	v_dual_dot2acc_f32_f16 v52, v36, v5 :: v_dual_and_b32 v99, 0xffff, v99// 0000003EF090: CB240B24 3462C6FF 0000FFFF
	v_mul_u32_u24_e32 v104, s6, v39                            // 0000003EF09C: 16D04E06
	v_mul_u32_u24_e32 v39, s7, v39                             // 0000003EF0A0: 164E4E07
	v_lshl_add_u32 v39, v39, 24, v104                          // 0000003EF0A4: D6460027 05A13127
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000003EF0AC: BF8700D2
	v_dot2acc_f32_f16 v52, v34, v6                             // 0000003EF0B0: 04680D22
	v_lshl_or_b32 v38, v38, 16, v99                            // 0000003EF0B4: D6560026 058D2126
	v_bfe_u32 v99, v35, 9, 16                                  // 0000003EF0BC: D6100063 02411323
	v_mul_u32_u24_e32 v102, s6, v99                            // 0000003EF0C4: 16CCC606
	v_mul_u32_u24_e32 v99, s7, v99                             // 0000003EF0C8: 16C6C607
	v_lshl_add_u32 v99, v99, 24, v102                          // 0000003EF0CC: D6460063 05993163
	v_pk_fma_f16 v38, v38, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000003EF0D4: CC0E0026 0BFC1126 0000C931
	v_mul_u32_u24_e32 v102, s6, v100                           // 0000003EF0E0: 16CCC806
	v_mul_u32_u24_e32 v100, s7, v100                           // 0000003EF0E4: 16C8C807
	v_lshl_add_u32 v100, v100, 24, v102                        // 0000003EF0E8: D6460064 05993164
	v_sad_u8 v99, v99, 0, 0x6400                               // 0000003EF0F0: D6220063 03FD0163 00006400
	v_dot2acc_f32_f16 v58, v38, v2                             // 0000003EF0FC: 04740526
	v_sad_u8 v39, v39, 0, 0x6400                               // 0000003EF100: D6220027 03FD0127 00006400
	v_dot2acc_f32_f16 v56, v38, v6                             // 0000003EF10C: 04700D26
	v_sad_u8 v40, v100, 0, 0x6400                              // 0000003EF110: D6220028 03FD0164 00006400
	v_and_b32_e32 v37, 0xffff, v99                             // 0000003EF11C: 364AC6FF 0000FFFF
	v_dot2acc_f32_f16 v58, v41, v3                             // 0000003EF124: 04740729
	v_and_b32_e32 v103, 0xffff, v103                           // 0000003EF128: 36CECEFF 0000FFFF
	v_dual_dot2acc_f32_f16 v55, v36, v1 :: v_dual_dot2acc_f32_f16 v56, v41, v7// 0000003EF130: CB180324 37380F29
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003EF138: BF8701A4
	v_lshl_or_b32 v37, v40, 16, v37                            // 0000003EF13C: D6560025 04952128
	v_mul_u32_u24_e32 v102, s6, v101                           // 0000003EF144: 16CCCA06
	v_lshl_or_b32 v39, v39, 16, v103                           // 0000003EF148: D6560027 059D2127
	v_mul_u32_u24_e32 v101, s7, v101                           // 0000003EF150: 16CACA07
	v_lshl_add_u32 v101, v101, 24, v102                        // 0000003EF154: D6460065 05993165
	v_pk_fma_f16 v37, v37, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000003EF15C: CC0E0025 0BFC1125 0000C931
	v_dot2acc_f32_f16 v55, v34, v2                             // 0000003EF168: 046E0522
	v_pk_fma_f16 v39, v39, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000003EF16C: CC0E0027 0BFC1127 0000C931
	v_and_b32_e32 v35, 0xffff, v35                             // 0000003EF178: 364646FF 0000FFFF
	s_waitcnt vmcnt(4)                                         // 0000003EF180: BF8913F7
	.long 0xd73d001f                                           // 0000003EF184: D73D001F
	v_cndmask_b32_e32 v1, v64, v32, vcc_lo                     // 0000003EF188: 02024140
	v_bfe_u32 v32, v30, 9, 16                                  // 0000003EF18C: D6100020 0241131E
	v_sad_u8 v99, v101, 0, 0x6400                              // 0000003EF194: D6220063 03FD0165 00006400
	v_dot2acc_f32_f16 v56, v39, v8                             // 0000003EF1A0: 04701127
	v_mul_u32_u24_e32 v100, s6, v35                            // 0000003EF1A4: 16C84606
	v_mul_u32_u24_e32 v35, s7, v35                             // 0000003EF1A8: 16464607
	v_lshl_add_u32 v35, v35, 24, v100                          // 0000003EF1AC: D6460023 05913123
	v_dot2acc_f32_f16 v52, v37, v7                             // 0000003EF1B4: 04680F25
	v_dot2acc_f32_f16 v55, v37, v3                             // 0000003EF1B8: 046E0725
	v_mul_u32_u24_e32 v37, s6, v32                             // 0000003EF1BC: 164A4006
	v_mul_u32_u24_e32 v32, s7, v32                             // 0000003EF1C0: 16404007
	v_lshl_add_u32 v32, v32, 24, v37                           // 0000003EF1C4: D6460020 04953120
	v_bfe_u32 v34, v30, 3, 16                                  // 0000003EF1CC: D6100022 0241071E
	v_bfe_u32 v33, v30, 6, 16                                  // 0000003EF1D4: D6100021 02410D1E
	v_mul_u32_u24_e32 v38, s6, v34                             // 0000003EF1DC: 164C4406
	v_mul_u32_u24_e32 v34, s7, v34                             // 0000003EF1E0: 16444407
	v_and_b32_e32 v40, 0xffff, v99                             // 0000003EF1E4: 3650C6FF 0000FFFF
	v_sad_u8 v35, v35, 0, 0x6400                               // 0000003EF1EC: D6220023 03FD0123 00006400
	v_lshl_add_u32 v34, v34, 24, v38                           // 0000003EF1F8: D6460022 04993122
	v_mul_u32_u24_e32 v38, s6, v33                             // 0000003EF200: 164C4206
	v_mul_u32_u24_e32 v33, s7, v33                             // 0000003EF204: 16424207
	v_sad_u8 v32, v32, 0, 0x6400                               // 0000003EF208: D6220020 03FD0120 00006400
	v_lshl_add_u32 v33, v33, 24, v38                           // 0000003EF214: D6460021 04993121
	v_bfe_u32 v36, v31, 9, 16                                  // 0000003EF21C: D6100024 0241131F
	v_lshl_or_b32 v35, v35, 16, v40                            // 0000003EF224: D6560023 04A12123
	v_mul_u32_u24_e32 v40, s6, v36                             // 0000003EF22C: 16504806
	v_mul_u32_u24_e32 v36, s7, v36                             // 0000003EF230: 16484807
	v_and_b32_e32 v32, 0xffff, v32                             // 0000003EF234: 364040FF 0000FFFF
	v_sad_u8 v33, v33, 0, 0x6400                               // 0000003EF23C: D6220021 03FD0121 00006400
	v_lshl_add_u32 v36, v36, 24, v40                           // 0000003EF248: D6460024 04A13124
	v_and_b32_e32 v30, 0xffff, v30                             // 0000003EF250: 363C3CFF 0000FFFF
	v_dot2acc_f32_f16 v58, v39, v4                             // 0000003EF258: 04740927
	v_bfe_u32 v38, v31, 3, 16                                  // 0000003EF25C: D6100026 0241071F
	v_mul_u32_u24_e32 v39, s6, v30                             // 0000003EF264: 164E3C06
	v_mul_u32_u24_e32 v30, s7, v30                             // 0000003EF268: 163C3C07
	v_bfe_u32 v37, v31, 6, 16                                  // 0000003EF26C: D6100025 02410D1F
	v_lshl_add_u32 v30, v30, 24, v39                           // 0000003EF274: D646001E 049D311E
	v_mul_u32_u24_e32 v39, s6, v38                             // 0000003EF27C: 164E4C06
	v_mul_u32_u24_e32 v38, s7, v38                             // 0000003EF280: 164C4C07
	v_lshl_add_u32 v38, v38, 24, v39                           // 0000003EF284: D6460026 049D3126
	v_mul_u32_u24_e32 v39, s6, v37                             // 0000003EF28C: 164E4A06
	v_mul_u32_u24_e32 v37, s7, v37                             // 0000003EF290: 164A4A07
	v_sad_u8 v36, v36, 0, 0x6400                               // 0000003EF294: D6220024 03FD0124 00006400
	v_lshl_add_u32 v37, v37, 24, v39                           // 0000003EF2A0: D6460025 049D3125
	v_lshl_or_b32 v32, v33, 16, v32                            // 0000003EF2A8: D6560020 04812121
	.long 0xd73d001a                                           // 0000003EF2B0: D73D001A
	v_cndmask_b32_e32 v1, v62, v26, vcc_lo                     // 0000003EF2B4: 0202353E
	v_pk_fma_f16 v35, v35, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000003EF2B8: CC0E0023 0BFC1123 0000C931
	v_sad_u8 v34, v34, 0, 0x6400                               // 0000003EF2C4: D6220022 03FD0122 00006400
	v_sad_u8 v37, v37, 0, 0x6400                               // 0000003EF2D0: D6220025 03FD0125 00006400
	v_pk_fma_f16 v32, v32, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000003EF2DC: CC0E0020 0BFC1120 0000C931
	v_and_b32_e32 v36, 0xffff, v36                             // 0000003EF2E8: 364848FF 0000FFFF
	s_waitcnt vmcnt(3)                                         // 0000003EF2F0: BF890FF7
	.long 0xd73d001b                                           // 0000003EF2F4: D73D001B
	v_cndmask_b32_e32 v1, v64, v28, vcc_lo                     // 0000003EF2F8: 02023940
	v_bfe_u32 v28, v26, 9, 16                                  // 0000003EF2FC: D610001C 0241131A
	v_dual_dot2acc_f32_f16 v55, v35, v4 :: v_dual_and_b32 v34, 0xffff, v34// 0000003EF304: CB240923 372244FF 0000FFFF
	v_dot2acc_f32_f16 v53, v32, v1                             // 0000003EF310: 046A0320
	v_lshl_or_b32 v33, v37, 16, v36                            // 0000003EF314: D6560021 04912125
	v_mul_u32_u24_e32 v37, s6, v28                             // 0000003EF31C: 164A3806
	v_mul_u32_u24_e32 v28, s7, v28                             // 0000003EF320: 16383807
	v_sad_u8 v30, v30, 0, 0x6400                               // 0000003EF324: D622001E 03FD011E 00006400
	v_lshl_add_u32 v28, v28, 24, v37                           // 0000003EF330: D646001C 0495311C
	v_dual_dot2acc_f32_f16 v54, v32, v5 :: v_dual_and_b32 v31, 0xffff, v31// 0000003EF338: CB240B20 361E3EFF 0000FFFF
	v_bfe_u32 v32, v26, 3, 16                                  // 0000003EF344: D6100020 0241071A
	v_bfe_u32 v29, v26, 6, 16                                  // 0000003EF34C: D610001D 02410D1A
	v_mul_u32_u24_e32 v37, s6, v32                             // 0000003EF354: 164A4006
	v_mul_u32_u24_e32 v32, s7, v32                             // 0000003EF358: 16404007
	s_delay_alu instid0(VALU_DEP_2)                            // 0000003EF35C: BF870002
	v_lshl_add_u32 v32, v32, 24, v37                           // 0000003EF360: D6460020 04953120
	v_mul_u32_u24_e32 v37, s6, v29                             // 0000003EF368: 164A3A06
	v_mul_u32_u24_e32 v29, s7, v29                             // 0000003EF36C: 163A3A07
	v_lshl_or_b32 v30, v30, 16, v34                            // 0000003EF370: D656001E 0489211E
	v_sad_u8 v28, v28, 0, 0x6400                               // 0000003EF378: D622001C 03FD011C 00006400
	v_lshl_add_u32 v29, v29, 24, v37                           // 0000003EF384: D646001D 0495311D
	v_and_b32_e32 v26, 0xffff, v26                             // 0000003EF38C: 363434FF 0000FFFF
	v_bfe_u32 v34, v27, 9, 16                                  // 0000003EF394: D6100022 0241131B
	v_pk_fma_f16 v30, v30, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000003EF39C: CC0E001E 0BFC111E 0000C931
	v_and_b32_e32 v28, 0xffff, v28                             // 0000003EF3A8: 363838FF 0000FFFF
	v_sad_u8 v29, v29, 0, 0x6400                               // 0000003EF3B0: D622001D 03FD011D 00006400
	v_mul_u32_u24_e32 v37, s6, v26                             // 0000003EF3BC: 164A3406
	v_mul_u32_u24_e32 v26, s7, v26                             // 0000003EF3C0: 16343407
	v_dot2acc_f32_f16 v53, v30, v2                             // 0000003EF3C4: 046A051E
	v_mul_u32_u24_e32 v39, s6, v31                             // 0000003EF3C8: 164E3E06
	v_lshl_or_b32 v28, v29, 16, v28                            // 0000003EF3CC: D656001C 0471211D
	v_mul_u32_u24_e32 v31, s7, v31                             // 0000003EF3D4: 163E3E07
	v_lshl_add_u32 v26, v26, 24, v37                           // 0000003EF3D8: D646001A 0495311A
	v_mul_u32_u24_e32 v37, s6, v34                             // 0000003EF3E0: 164A4406
	v_mul_u32_u24_e32 v34, s7, v34                             // 0000003EF3E4: 16444407
	v_sad_u8 v38, v38, 0, 0x6400                               // 0000003EF3E8: D6220026 03FD0126 00006400
	v_lshl_add_u32 v31, v31, 24, v39                           // 0000003EF3F4: D646001F 049D311F
	v_sad_u8 v32, v32, 0, 0x6400                               // 0000003EF3FC: D6220020 03FD0120 00006400
	v_lshl_add_u32 v34, v34, 24, v37                           // 0000003EF408: D6460022 04953122
	v_pk_fma_f16 v28, v28, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000003EF410: CC0E001C 0BFC111C 0000C931
	v_dot2acc_f32_f16 v52, v35, v8                             // 0000003EF41C: 04681123
	v_bfe_u32 v35, v27, 6, 16                                  // 0000003EF420: D6100023 02410D1B
	v_bfe_u32 v36, v27, 3, 16                                  // 0000003EF428: D6100024 0241071B
	v_mul_u32_u24_e32 v37, s6, v35                             // 0000003EF430: 164A4606
	v_mul_u32_u24_e32 v35, s7, v35                             // 0000003EF434: 16464607
	s_delay_alu instid0(VALU_DEP_2)                            // 0000003EF438: BF870002
	v_lshl_add_u32 v35, v35, 24, v37                           // 0000003EF43C: D6460023 04953123
	v_mul_u32_u24_e32 v37, s6, v36                             // 0000003EF444: 164A4806
	v_mul_u32_u24_e32 v36, s7, v36                             // 0000003EF448: 16484807
	v_sad_u8 v31, v31, 0, 0x6400                               // 0000003EF44C: D622001F 03FD011F 00006400
	v_pk_fma_f16 v33, v33, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000003EF458: CC0E0021 0BFC1121 0000C931
	v_and_b32_e32 v38, 0xffff, v38                             // 0000003EF464: 364C4CFF 0000FFFF
	v_sad_u8 v26, v26, 0, 0x6400                               // 0000003EF46C: D622001A 03FD011A 00006400
	v_sad_u8 v34, v34, 0, 0x6400                               // 0000003EF478: D6220022 03FD0122 00006400
	v_lshl_add_u32 v36, v36, 24, v37                           // 0000003EF484: D6460024 04953124
	v_dual_dot2acc_f32_f16 v45, v28, v1 :: v_dual_and_b32 v32, 0xffff, v32// 0000003EF48C: CB24031C 2D2040FF 0000FFFF
	v_dual_dot2acc_f32_f16 v54, v30, v6 :: v_dual_and_b32 v27, 0xffff, v27// 0000003EF498: CB240D1E 361A36FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003EF4A4: BF870214
	v_and_b32_e32 v29, 0xffff, v34                             // 0000003EF4A8: 363A44FF 0000FFFF
	v_sad_u8 v34, v36, 0, 0x6400                               // 0000003EF4B0: D6220022 03FD0124 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003EF4BC: BF870004
	v_lshl_or_b32 v26, v26, 16, v32                            // 0000003EF4C0: D656001A 0481211A
	v_sad_u8 v32, v35, 0, 0x6400                               // 0000003EF4C8: D6220020 03FD0123 00006400
	v_dot2acc_f32_f16 v53, v33, v3                             // 0000003EF4D4: 046A0721
	v_lshl_or_b32 v31, v31, 16, v38                            // 0000003EF4D8: D656001F 0499211F
	.long 0xd73d0016                                           // 0000003EF4E0: D73D0016
	v_cndmask_b32_e32 v1, v62, v22, vcc_lo                     // 0000003EF4E4: 02022D3E
	v_pk_fma_f16 v26, v26, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000003EF4E8: CC0E001A 0BFC111A 0000C931
	v_dot2acc_f32_f16 v54, v33, v7                             // 0000003EF4F4: 046C0F21
	v_lshl_or_b32 v29, v32, 16, v29                            // 0000003EF4F8: D656001D 04752120
	v_pk_fma_f16 v31, v31, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000003EF500: CC0E001F 0BFC111F 0000C931
	v_dual_dot2acc_f32_f16 v51, v28, v5 :: v_dual_and_b32 v32, 0xffff, v34// 0000003EF50C: CB240B1C 332044FF 0000FFFF
	s_waitcnt vmcnt(2)                                         // 0000003EF518: BF890BF7
	.long 0xd73d0017                                           // 0000003EF51C: D73D0017
	v_cndmask_b32_e32 v1, v64, v24, vcc_lo                     // 0000003EF520: 02023140
	v_bfe_u32 v28, v22, 9, 16                                  // 0000003EF524: D610001C 02411316
	v_mul_u32_u24_e32 v24, s6, v28                             // 0000003EF52C: 16303806
	v_pk_fma_f16 v29, v29, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000003EF530: CC0E001D 0BFC111D 0000C931
	v_dual_dot2acc_f32_f16 v45, v26, v2 :: v_dual_dot2acc_f32_f16 v54, v31, v8// 0000003EF53C: CB18051A 2D36111F
	v_dot2acc_f32_f16 v51, v26, v6                             // 0000003EF544: 04660D1A
	v_mul_u32_u24_e32 v25, s7, v28                             // 0000003EF548: 16323807
	v_lshl_add_u32 v24, v25, 24, v24                           // 0000003EF54C: D6460018 04613119
	v_bfe_u32 v25, v22, 6, 16                                  // 0000003EF554: D6100019 02410D16
	v_dot2acc_f32_f16 v45, v29, v3                             // 0000003EF55C: 045A071D
	v_bfe_u32 v26, v22, 3, 16                                  // 0000003EF560: D610001A 02410716
	v_mul_u32_u24_e32 v35, s6, v27                             // 0000003EF568: 16463606
	v_sad_u8 v24, v24, 0, 0x6400                               // 0000003EF56C: D6220018 03FD0118 00006400
	v_dot2acc_f32_f16 v51, v29, v7                             // 0000003EF578: 04660F1D
	v_mul_u32_u24_e32 v29, s6, v25                             // 0000003EF57C: 163A3206
	v_mul_u32_u24_e32 v25, s7, v25                             // 0000003EF580: 16323207
	v_lshl_add_u32 v25, v25, 24, v29                           // 0000003EF584: D6460019 04753119
	v_mul_u32_u24_e32 v27, s7, v27                             // 0000003EF58C: 16363607
	v_and_b32_e32 v24, 0xffff, v24                             // 0000003EF590: 363030FF 0000FFFF
	v_mul_u32_u24_e32 v29, s6, v26                             // 0000003EF598: 163A3406
	v_mul_u32_u24_e32 v26, s7, v26                             // 0000003EF59C: 16343407
	v_sad_u8 v25, v25, 0, 0x6400                               // 0000003EF5A0: D6220019 03FD0119 00006400
	v_lshl_add_u32 v27, v27, 24, v35                           // 0000003EF5AC: D646001B 048D311B
	v_lshl_add_u32 v26, v26, 24, v29                           // 0000003EF5B4: D646001A 0475311A
	v_dual_dot2acc_f32_f16 v53, v31, v4 :: v_dual_and_b32 v22, 0xffff, v22// 0000003EF5BC: CB24091F 35162CFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003EF5C8: BF870004
	v_lshl_or_b32 v24, v25, 16, v24                            // 0000003EF5CC: D6560018 04612119
	v_mul_u32_u24_e32 v25, s6, v22                             // 0000003EF5D4: 16322C06
	v_mul_u32_u24_e32 v22, s7, v22                             // 0000003EF5D8: 162C2C07
	v_sad_u8 v27, v27, 0, 0x6400                               // 0000003EF5DC: D622001B 03FD011B 00006400
	v_sad_u8 v26, v26, 0, 0x6400                               // 0000003EF5E8: D622001A 03FD011A 00006400
	v_lshl_add_u32 v22, v22, 24, v25                           // 0000003EF5F4: D6460016 04653116
	v_pk_fma_f16 v24, v24, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000003EF5FC: CC0E0018 0BFC1118 0000C931
	v_bfe_u32 v28, v23, 9, 16                                  // 0000003EF608: D610001C 02411317
	v_lshl_or_b32 v27, v27, 16, v32                            // 0000003EF610: D656001B 0481211B
	v_and_b32_e32 v25, 0xffff, v26                             // 0000003EF618: 363234FF 0000FFFF
	v_sad_u8 v22, v22, 0, 0x6400                               // 0000003EF620: D6220016 03FD0116 00006400
	v_mul_u32_u24_e32 v26, s6, v28                             // 0000003EF62C: 16343806
	v_mul_u32_u24_e32 v28, s7, v28                             // 0000003EF630: 16383807
	v_pk_fma_f16 v27, v27, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000003EF634: CC0E001B 0BFC111B 0000C931
	v_bfe_u32 v30, v23, 3, 16                                  // 0000003EF640: D610001E 02410717
	v_lshl_or_b32 v22, v22, 16, v25                            // 0000003EF648: D6560016 04652116
	v_lshl_add_u32 v26, v28, 24, v26                           // 0000003EF650: D646001A 0469311C
	v_mul_u32_u24_e32 v28, s6, v30                             // 0000003EF658: 16383C06
	v_dual_dot2acc_f32_f16 v45, v27, v4 :: v_dual_dot2acc_f32_f16 v50, v24, v1// 0000003EF65C: CB18091B 2D320318
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000003EF664: BF8701C3
	v_pk_fma_f16 v22, v22, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000003EF668: CC0E0016 0BFC1116 0000C931
	v_mul_u32_u24_e32 v30, s7, v30                             // 0000003EF674: 163C3C07
	v_lshl_add_u32 v28, v30, 24, v28                           // 0000003EF678: D646001C 0471311E
	v_bfe_u32 v29, v23, 6, 16                                  // 0000003EF680: D610001D 02410D17
	v_dual_dot2acc_f32_f16 v50, v22, v2 :: v_dual_and_b32 v23, 0xffff, v23// 0000003EF688: CB240516 32162EFF 0000FFFF
	v_mul_u32_u24_e32 v30, s6, v29                             // 0000003EF694: 163C3A06
	v_mul_u32_u24_e32 v29, s7, v29                             // 0000003EF698: 163A3A07
	s_delay_alu instid0(VALU_DEP_2)                            // 0000003EF69C: BF870002
	v_lshl_add_u32 v29, v29, 24, v30                           // 0000003EF6A0: D646001D 0479311D
	v_mul_u32_u24_e32 v30, s6, v23                             // 0000003EF6A8: 163C2E06
	v_mul_u32_u24_e32 v23, s7, v23                             // 0000003EF6AC: 162E2E07
	v_sad_u8 v28, v28, 0, 0x6400                               // 0000003EF6B0: D622001C 03FD011C 00006400
	v_lshl_add_u32 v23, v23, 24, v30                           // 0000003EF6BC: D6460017 04793117
	.long 0xd73d0012                                           // 0000003EF6C4: D73D0012
	v_cndmask_b32_e32 v1, v62, v18, vcc_lo                     // 0000003EF6C8: 0202253E
	s_waitcnt vmcnt(1)                                         // 0000003EF6CC: BF8907F7
	.long 0xd73d0013                                           // 0000003EF6D0: D73D0013
	v_cndmask_b32_e32 v1, v64, v20, vcc_lo                     // 0000003EF6D4: 02022940
	v_dual_dot2acc_f32_f16 v49, v24, v5 :: v_dual_and_b32 v28, 0xffff, v28// 0000003EF6D8: CB240B18 311C38FF 0000FFFF
	v_sad_u8 v23, v23, 0, 0x6400                               // 0000003EF6E4: D6220017 03FD0117 00006400
	v_sad_u8 v26, v26, 0, 0x6400                               // 0000003EF6F0: D622001A 03FD011A 00006400
	v_bfe_u32 v20, v18, 9, 16                                  // 0000003EF6FC: D6100014 02411312
	v_bfe_u32 v21, v18, 6, 16                                  // 0000003EF704: D6100015 02410D12
	v_dot2acc_f32_f16 v51, v27, v8                             // 0000003EF70C: 0466111B
	v_lshl_or_b32 v23, v23, 16, v28                            // 0000003EF710: D6560017 04712117
	v_mul_u32_u24_e32 v28, s6, v20                             // 0000003EF718: 16382806
	v_mul_u32_u24_e32 v20, s7, v20                             // 0000003EF71C: 16282807
	v_lshl_add_u32 v20, v20, 24, v28                           // 0000003EF720: D6460014 04713114
	v_and_b32_e32 v25, 0xffff, v26                             // 0000003EF728: 363234FF 0000FFFF
	v_sad_u8 v26, v29, 0, 0x6400                               // 0000003EF730: D622001A 03FD011D 00006400
	v_bfe_u32 v27, v19, 3, 16                                  // 0000003EF73C: D610001B 02410713
	v_pk_fma_f16 v23, v23, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000003EF744: CC0E0017 0BFC1117 0000C931
	v_sad_u8 v20, v20, 0, 0x6400                               // 0000003EF750: D6220014 03FD0114 00006400
	v_dot2acc_f32_f16 v49, v22, v6                             // 0000003EF75C: 04620D16
	v_bfe_u32 v22, v18, 3, 16                                  // 0000003EF760: D6100016 02410712
	v_mul_u32_u24_e32 v28, s6, v22                             // 0000003EF768: 16382C06
	v_mul_u32_u24_e32 v22, s7, v22                             // 0000003EF76C: 162C2C07
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003EF770: BF870001
	v_lshl_add_u32 v22, v22, 24, v28                           // 0000003EF774: D6460016 04713116
	v_mul_u32_u24_e32 v28, s6, v21                             // 0000003EF77C: 16382A06
	v_mul_u32_u24_e32 v21, s7, v21                             // 0000003EF780: 162A2A07
	v_lshl_add_u32 v21, v21, 24, v28                           // 0000003EF784: D6460015 04713115
	v_and_b32_e32 v18, 0xffff, v18                             // 0000003EF78C: 362424FF 0000FFFF
	v_mul_u32_u24_e32 v28, s6, v18                             // 0000003EF794: 16382406
	v_mul_u32_u24_e32 v18, s7, v18                             // 0000003EF798: 16242407
	v_lshl_or_b32 v25, v26, 16, v25                            // 0000003EF79C: D6560019 0465211A
	v_sad_u8 v22, v22, 0, 0x6400                               // 0000003EF7A4: D6220016 03FD0116 00006400
	v_lshl_add_u32 v18, v18, 24, v28                           // 0000003EF7B0: D6460012 04713112
	v_and_b32_e32 v20, 0xffff, v20                             // 0000003EF7B8: 362828FF 0000FFFF
	v_sad_u8 v21, v21, 0, 0x6400                               // 0000003EF7C0: D6220015 03FD0115 00006400
	v_pk_fma_f16 v24, v25, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000003EF7CC: CC0E0018 0BFC1119 0000C931
	v_and_b32_e32 v22, 0xffff, v22                             // 0000003EF7D8: 362C2CFF 0000FFFF
	v_sad_u8 v18, v18, 0, 0x6400                               // 0000003EF7E0: D6220012 03FD0112 00006400
	v_bfe_u32 v25, v19, 9, 16                                  // 0000003EF7EC: D6100019 02411313
	v_lshl_or_b32 v20, v21, 16, v20                            // 0000003EF7F4: D6560014 04512115
	v_mul_u32_u24_e32 v28, s6, v25                             // 0000003EF7FC: 16383206
	v_mul_u32_u24_e32 v25, s7, v25                             // 0000003EF800: 16323207
	s_delay_alu instid0(VALU_DEP_2)                            // 0000003EF804: BF870002
	v_lshl_add_u32 v25, v25, 24, v28                           // 0000003EF808: D6460019 04713119
	v_dot2acc_f32_f16 v49, v24, v7                             // 0000003EF810: 04620F18
	v_lshl_or_b32 v18, v18, 16, v22                            // 0000003EF814: D6560012 04592112
	v_pk_fma_f16 v20, v20, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000003EF81C: CC0E0014 0BFC1114 0000C931
	v_bfe_u32 v26, v19, 6, 16                                  // 0000003EF828: D610001A 02410D13
	v_mul_u32_u24_e32 v28, s6, v26                             // 0000003EF830: 16383406
	v_mul_u32_u24_e32 v26, s7, v26                             // 0000003EF834: 16343407
	v_sad_u8 v25, v25, 0, 0x6400                               // 0000003EF838: D6220019 03FD0119 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 0000003EF844: BF870002
	v_lshl_add_u32 v26, v26, 24, v28                           // 0000003EF848: D646001A 0471311A
	v_mul_u32_u24_e32 v28, s6, v27                             // 0000003EF850: 16383606
	v_mul_u32_u24_e32 v27, s7, v27                             // 0000003EF854: 16363607
	v_pk_fma_f16 v18, v18, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000003EF858: CC0E0012 0BFC1112 0000C931
	v_dot2acc_f32_f16 v48, v20, v1                             // 0000003EF864: 04600314
	v_lshl_add_u32 v27, v27, 24, v28                           // 0000003EF868: D646001B 0471311B
	v_and_b32_e32 v19, 0xffff, v19                             // 0000003EF870: 362626FF 0000FFFF
	v_sad_u8 v22, v26, 0, 0x6400                               // 0000003EF878: D6220016 03FD011A 00006400
	v_dual_dot2acc_f32_f16 v50, v24, v3 :: v_dual_and_b32 v21, 0xffff, v25// 0000003EF884: CB240718 321432FF 0000FFFF
	v_dot2acc_f32_f16 v48, v18, v2                             // 0000003EF890: 04600512
	v_mul_u32_u24_e32 v26, s6, v19                             // 0000003EF894: 16342606
	v_mul_u32_u24_e32 v19, s7, v19                             // 0000003EF898: 16262607
	v_sad_u8 v25, v27, 0, 0x6400                               // 0000003EF89C: D6220019 03FD011B 00006400
	v_lshl_add_u32 v19, v19, 24, v26                           // 0000003EF8A8: D6460013 04693113
	v_dot2acc_f32_f16 v50, v23, v4                             // 0000003EF8B0: 04640917
	v_lshl_or_b32 v21, v22, 16, v21                            // 0000003EF8B4: D6560015 04552116
	.long 0xd73d000c                                           // 0000003EF8BC: D73D000C
	v_cndmask_b32_e32 v1, v62, v12, vcc_lo                     // 0000003EF8C0: 0202193E
	v_dual_dot2acc_f32_f16 v49, v23, v8 :: v_dual_and_b32 v22, 0xffff, v25// 0000003EF8C4: CB241117 311632FF 0000FFFF
	v_sad_u8 v19, v19, 0, 0x6400                               // 0000003EF8D0: D6220013 03FD0113 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003EF8DC: BF870004
	v_pk_fma_f16 v21, v21, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000003EF8E0: CC0E0015 0BFC1115 0000C931
	s_waitcnt vmcnt(0)                                         // 0000003EF8EC: BF8903F7
	.long 0xd73d0010                                           // 0000003EF8F0: D73D0010
	v_cndmask_b32_e32 v1, v64, v16, vcc_lo                     // 0000003EF8F4: 02022140
	v_bfe_u32 v17, v12, 9, 16                                  // 0000003EF8F8: D6100011 0241130C
	v_mul_u32_u24_e32 v25, s6, v17                             // 0000003EF900: 16322206
	v_lshl_or_b32 v19, v19, 16, v22                            // 0000003EF904: D6560013 04592113
	v_mul_u32_u24_e32 v17, s7, v17                             // 0000003EF90C: 16222207
	s_delay_alu instid0(VALU_DEP_2)                            // 0000003EF910: BF870002
	v_lshl_add_u32 v17, v17, 24, v25                           // 0000003EF914: D6460011 04653111
	v_dual_dot2acc_f32_f16 v48, v21, v3 :: v_dual_dot2acc_f32_f16 v47, v20, v5// 0000003EF91C: CB180715 302E0B14
	v_bfe_u32 v20, v12, 3, 16                                  // 0000003EF924: D6100014 0241070C
	v_pk_fma_f16 v13, v19, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000003EF92C: CC0E000D 0BFC1113 0000C931
	v_bfe_u32 v19, v12, 6, 16                                  // 0000003EF938: D6100013 02410D0C
	v_mul_u32_u24_e32 v25, s6, v20                             // 0000003EF940: 16322806
	v_mul_u32_u24_e32 v20, s7, v20                             // 0000003EF944: 16282807
	v_lshl_add_u32 v20, v20, 24, v25                           // 0000003EF948: D6460014 04653114
	v_mul_u32_u24_e32 v25, s6, v19                             // 0000003EF950: 16322606
	v_mul_u32_u24_e32 v19, s7, v19                             // 0000003EF954: 16262607
	v_sad_u8 v17, v17, 0, 0x6400                               // 0000003EF958: D6220011 03FD0111 00006400
	v_lshl_add_u32 v19, v19, 24, v25                           // 0000003EF964: D6460013 04653113
	v_bfe_u32 v22, v16, 9, 16                                  // 0000003EF96C: D6100016 02411310
	v_sad_u8 v20, v20, 0, 0x6400                               // 0000003EF974: D6220014 03FD0114 00006400
	v_bfe_u32 v23, v16, 6, 16                                  // 0000003EF980: D6100017 02410D10
	v_and_b32_e32 v17, 0xffff, v17                             // 0000003EF988: 362222FF 0000FFFF
	v_sad_u8 v19, v19, 0, 0x6400                               // 0000003EF990: D6220013 03FD0113 00006400
	v_bfe_u32 v24, v16, 3, 16                                  // 0000003EF99C: D6100018 02410710
	v_dual_dot2acc_f32_f16 v47, v18, v6 :: v_dual_and_b32 v16, 0xffff, v16// 0000003EF9A4: CB240D12 2F1020FF 0000FFFF
	v_mov_b32_e32 v28, v92                                     // 0000003EF9B0: 7E38035C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000003EF9B4: BF870224
	v_lshl_or_b32 v17, v19, 16, v17                            // 0000003EF9B8: D6560011 04452113
	v_dual_dot2acc_f32_f16 v48, v13, v4 :: v_dual_add_nc_u32 v63, 32, v63// 0000003EF9C0: CB20090D 303E7EA0
	v_dot2acc_f32_f16 v47, v21, v7                             // 0000003EF9C8: 045E0F15
	v_dual_mov_b32 v29, v85 :: v_dual_mov_b32 v32, v94         // 0000003EF9CC: CA100155 1D20015E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000003EF9D4: BF870224
	v_pk_fma_f16 v17, v17, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000003EF9D8: CC0E0011 0BFC1111 0000C931
	v_and_b32_e32 v12, 0xffff, v12                             // 0000003EF9E4: 361818FF 0000FFFF
	v_dual_dot2acc_f32_f16 v47, v13, v8 :: v_dual_mov_b32 v26, v79// 0000003EF9EC: CB10110D 2F1A014F
	v_mov_b32_e32 v27, v70                                     // 0000003EF9F4: 7E360346
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003EF9F8: BF870004
	v_dot2acc_f32_f16 v9, v17, v5                              // 0000003EF9FC: 04120B11
	v_mul_u32_u24_e32 v25, s6, v12                             // 0000003EFA00: 16321806
	v_mul_u32_u24_e32 v12, s7, v12                             // 0000003EFA04: 16181807
	v_lshl_add_u32 v12, v12, 24, v25                           // 0000003EFA08: D646000C 0465310C
	v_mul_u32_u24_e32 v25, s6, v22                             // 0000003EFA10: 16322C06
	v_mul_u32_u24_e32 v22, s7, v22                             // 0000003EFA14: 162C2C07
	v_lshl_add_u32 v22, v22, 24, v25                           // 0000003EFA18: D6460016 04653116
	v_mul_u32_u24_e32 v25, s6, v23                             // 0000003EFA20: 16322E06
	v_mul_u32_u24_e32 v23, s7, v23                             // 0000003EFA24: 162E2E07
	v_and_b32_e32 v20, 0xffff, v20                             // 0000003EFA28: 362828FF 0000FFFF
	v_sad_u8 v12, v12, 0, 0x6400                               // 0000003EFA30: D622000C 03FD010C 00006400
	v_lshl_add_u32 v23, v23, 24, v25                           // 0000003EFA3C: D6460017 04653117
	v_mul_u32_u24_e32 v25, s6, v24                             // 0000003EFA44: 16323006
	v_mul_u32_u24_e32 v24, s7, v24                             // 0000003EFA48: 16303007
	v_sad_u8 v22, v22, 0, 0x6400                               // 0000003EFA4C: D6220016 03FD0116 00006400
	v_lshl_add_u32 v24, v24, 24, v25                           // 0000003EFA58: D6460018 04653118
	v_lshl_or_b32 v12, v12, 16, v20                            // 0000003EFA60: D656000C 0451210C
	v_sad_u8 v20, v23, 0, 0x6400                               // 0000003EFA68: D6220014 03FD0117 00006400
	v_mul_u32_u24_e32 v23, s6, v16                             // 0000003EFA74: 162E2006
	v_mul_u32_u24_e32 v16, s7, v16                             // 0000003EFA78: 16202007
	v_dual_dot2acc_f32_f16 v46, v17, v1 :: v_dual_and_b32 v19, 0xffff, v22// 0000003EFA7C: CB240311 2E122CFF 0000FFFF
	v_sad_u8 v22, v24, 0, 0x6400                               // 0000003EFA88: D6220016 03FD0118 00006400
	v_lshl_add_u32 v16, v16, 24, v23                           // 0000003EFA94: D6460010 045D3110
	v_pk_fma_f16 v12, v12, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000003EFA9C: CC0E000C 0BFC110C 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000003EFAA8: BF870244
	v_lshl_or_b32 v19, v20, 16, v19                            // 0000003EFAAC: D6560013 044D2114
	v_dual_mov_b32 v24, v89 :: v_dual_mov_b32 v25, v82         // 0000003EFAB4: CA100159 18180152
	v_and_b32_e32 v20, 0xffff, v22                             // 0000003EFABC: 36282CFF 0000FFFF
	v_sad_u8 v16, v16, 0, 0x6400                               // 0000003EFAC4: D6220010 03FD0110 00006400
	v_pk_fma_f16 v1, v19, s8, 0xc931 op_sel_hi:[1,0,0]         // 0000003EFAD0: CC0E0001 0BFC1113 0000C931
	v_dot2acc_f32_f16 v46, v12, v2                             // 0000003EFADC: 045C050C
	v_dual_dot2acc_f32_f16 v9, v12, v6 :: v_dual_add_nc_u32 v60, 1, v60// 0000003EFAE0: CB200D0C 093C7881
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000003EFAE8: BF870234
	v_lshl_or_b32 v5, v16, 16, v20                             // 0000003EFAEC: D6560005 04512110
	v_mov_b32_e32 v22, v77                                     // 0000003EFAF4: 7E2C034D
	v_mov_b32_e32 v23, v69                                     // 0000003EFAF8: 7E2E0345
	v_dot2acc_f32_f16 v9, v1, v7                               // 0000003EFAFC: 04120F01
	v_dual_mov_b32 v33, v88 :: v_dual_mov_b32 v30, v81         // 0000003EFB00: CA100158 211E0151
	v_pk_fma_f16 v2, v5, s8, 0xc931 op_sel_hi:[1,0,0]          // 0000003EFB08: CC0E0002 0BFC1105 0000C931
	v_dot2acc_f32_f16 v46, v1, v3                              // 0000003EFB14: 045C0701
	v_add_nc_u32_e32 v1, v61, v60                              // 0000003EFB18: 4A02793D
	v_dual_mov_b32 v31, v71 :: v_dual_mov_b32 v36, v96         // 0000003EFB1C: CA100147 1F240160
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003EFB24: BF870214
	v_dot2acc_f32_f16 v9, v2, v8                               // 0000003EFB28: 04121102
	v_dot2acc_f32_f16 v46, v2, v4                              // 0000003EFB2C: 045C0902
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003EFB30: BF870004
	v_cmp_eq_u32_e32 vcc_lo, 1, v1                             // 0000003EFB34: 7C940281
	v_dual_mov_b32 v37, v91 :: v_dual_mov_b32 v34, v84         // 0000003EFB38: CA10015B 25220154
	v_dual_mov_b32 v35, v72 :: v_dual_mov_b32 v40, v97         // 0000003EFB40: CA100148 23280161
	v_dual_mov_b32 v41, v93 :: v_dual_mov_b32 v38, v87         // 0000003EFB48: CA10015D 29260157
	v_dual_mov_b32 v39, v73 :: v_dual_mov_b32 v4, v95          // 0000003EFB50: CA100149 2704015F
	v_dual_mov_b32 v3, v98 :: v_dual_mov_b32 v18, v76          // 0000003EFB58: CA100162 0312014C
	v_dual_mov_b32 v1, v90 :: v_dual_mov_b32 v12, v75          // 0000003EFB60: CA10015A 010C014B
	v_dual_mov_b32 v2, v74 :: v_dual_mov_b32 v19, v68          // 0000003EFB68: CA10014A 02120144
	v_dual_mov_b32 v21, v80 :: v_dual_mov_b32 v20, v86         // 0000003EFB70: CA100150 15140156
	v_mov_b32_e32 v13, v67                                     // 0000003EFB78: 7E1A0343
	v_dual_mov_b32 v17, v78 :: v_dual_mov_b32 v16, v83         // 0000003EFB7C: CA10014E 11100153
	s_or_b32 s2, vcc_lo, s2                                    // 0000003EFB84: 8C02026A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003EFB88: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s2                        // 0000003EFB8C: 917E027E
	s_cbranch_execz 92                                         // 0000003EFB90: BFA5005C <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb1ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1f04>
	s_mov_b32 s9, exec_lo                                      // 0000003EFB94: BE89007E
	.long 0xd4c1007e                                           // 0000003EFB98: D4C1007E
	v_cndmask_b32_e32 v1, v60, v44, vcc_lo                     // 0000003EFB9C: 0202593C
	s_cbranch_execz 64552                                      // 0000003EFBA0: BFA5FC28 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb1ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0xe44>
	v_mad_i64_i32 v[5:6], null, 0x300, v60, s[4:5]             // 0000003EFBA4: D6FF7C05 001278FF 00000300
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003EFBB0: BF870091
	.long 0xd7006a07                                           // 0000003EFBB4: D7006A07
	v_cndmask_b32_e32 v1, v5, v10, vcc_lo                      // 0000003EFBB8: 02021505
	v_add_co_ci_u32_e64 v8, null, v6, v11, vcc_lo              // 0000003EFBBC: D5207C08 01AA1706
	.long 0xd7006a52                                           // 0000003EFBC4: D7006A52
	v_cndmask_b32_e32 v1, v5, v65, vcc_lo                      // 0000003EFBC8: 02028305
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003EFBCC: BF8700A1
	v_add_co_ci_u32_e64 v83, null, 0, v6, vcc_lo               // 0000003EFBD0: D5207C53 01AA0C80
	.long 0xd7006a60                                           // 0000003EFBD8: D7006A60
	v_cndmask_b32_e32 v1, v5, v14, vcc_lo                      // 0000003EFBDC: 02021D05
	v_add_co_ci_u32_e64 v97, null, v6, v15, vcc_lo             // 0000003EFBE0: D5207C61 01AA1F06
	.long 0xd7006a05                                           // 0000003EFBE8: D7006A05
	v_cndmask_b32_e32 v1, v5, v66, vcc_lo                      // 0000003EFBEC: 02028505
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003EFBF0: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v6, vcc_lo                // 0000003EFBF4: D5207C06 01AA0C80
	s_clause 0x1f                                              // 0000003EFBFC: BF85001F
	global_load_b32 v74, v[7:8], off                           // 0000003EFC00: DC520000 4A7C0007
	global_load_b32 v73, v[7:8], off offset:96                 // 0000003EFC08: DC520060 497C0007
	global_load_b32 v72, v[7:8], off offset:192                // 0000003EFC10: DC5200C0 487C0007
	global_load_b32 v71, v[7:8], off offset:288                // 0000003EFC18: DC520120 477C0007
	global_load_b32 v70, v[7:8], off offset:384                // 0000003EFC20: DC520180 467C0007
	global_load_b32 v69, v[7:8], off offset:480                // 0000003EFC28: DC5201E0 457C0007
	global_load_b32 v68, v[7:8], off offset:576                // 0000003EFC30: DC520240 447C0007
	global_load_b32 v67, v[7:8], off offset:672                // 0000003EFC38: DC5202A0 437C0007
	global_load_b32 v90, v[82:83], off                         // 0000003EFC40: DC520000 5A7C0052
	global_load_b32 v87, v[82:83], off offset:96               // 0000003EFC48: DC520060 577C0052
	global_load_b32 v84, v[82:83], off offset:192              // 0000003EFC50: DC5200C0 547C0052
	global_load_b32 v81, v[82:83], off offset:288              // 0000003EFC58: DC520120 517C0052
	global_load_b32 v79, v[82:83], off offset:384              // 0000003EFC60: DC520180 4F7C0052
	global_load_b32 v77, v[82:83], off offset:480              // 0000003EFC68: DC5201E0 4D7C0052
	global_load_b32 v76, v[82:83], off offset:576              // 0000003EFC70: DC520240 4C7C0052
	global_load_b32 v75, v[82:83], off offset:672              // 0000003EFC78: DC5202A0 4B7C0052
	global_load_b32 v95, v[96:97], off                         // 0000003EFC80: DC520000 5F7C0060
	global_load_b32 v93, v[96:97], off offset:96               // 0000003EFC88: DC520060 5D7C0060
	global_load_b32 v91, v[96:97], off offset:192              // 0000003EFC90: DC5200C0 5B7C0060
	global_load_b32 v88, v[96:97], off offset:288              // 0000003EFC98: DC520120 587C0060
	global_load_b32 v85, v[96:97], off offset:384              // 0000003EFCA0: DC520180 557C0060
	global_load_b32 v82, v[96:97], off offset:480              // 0000003EFCA8: DC5201E0 527C0060
	global_load_b32 v80, v[96:97], off offset:576              // 0000003EFCB0: DC520240 507C0060
	global_load_b32 v78, v[96:97], off offset:672              // 0000003EFCB8: DC5202A0 4E7C0060
	global_load_b32 v98, v[5:6], off                           // 0000003EFCC0: DC520000 627C0005
	global_load_b32 v97, v[5:6], off offset:96                 // 0000003EFCC8: DC520060 617C0005
	global_load_b32 v96, v[5:6], off offset:192                // 0000003EFCD0: DC5200C0 607C0005
	global_load_b32 v94, v[5:6], off offset:288                // 0000003EFCD8: DC520120 5E7C0005
	global_load_b32 v92, v[5:6], off offset:384                // 0000003EFCE0: DC520180 5C7C0005
	global_load_b32 v89, v[5:6], off offset:480                // 0000003EFCE8: DC5201E0 597C0005
	global_load_b32 v86, v[5:6], off offset:576                // 0000003EFCF0: DC520240 567C0005
	global_load_b32 v83, v[5:6], off offset:672                // 0000003EFCF8: DC5202A0 537C0005
	s_branch 64464                                             // 0000003EFD00: BFA0FBD0 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb1ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0xe44>
	s_or_b32 exec_lo, exec_lo, s2                              // 0000003EFD04: 8C7E027E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003EFD08: BF870009
	s_or_b32 exec_lo, exec_lo, s3                              // 0000003EFD0C: 8C7E037E
	s_waitcnt vmcnt(23)                                        // 0000003EFD10: BF895FF7
	v_dual_mov_b32 v1, v59 :: v_dual_mov_b32 v2, v57           // 0000003EFD14: CA10013B 01020139
	s_waitcnt vmcnt(7)                                         // 0000003EFD1C: BF891FF7
	v_dual_mov_b32 v3, v58 :: v_dual_mov_b32 v6, v56           // 0000003EFD20: CA10013A 03060138
	v_dual_mov_b32 v4, v55 :: v_dual_mov_b32 v5, v52           // 0000003EFD28: CA100137 04040134
	v_dual_mov_b32 v8, v53 :: v_dual_mov_b32 v11, v51          // 0000003EFD30: CA100135 080A0133
	v_dual_mov_b32 v10, v54 :: v_dual_mov_b32 v7, v45          // 0000003EFD38: CA100136 0A06012D
	v_dual_mov_b32 v12, v50 :: v_dual_mov_b32 v13, v49         // 0000003EFD40: CA100132 0C0C0131
	v_dual_mov_b32 v14, v48 :: v_dual_mov_b32 v15, v47         // 0000003EFD48: CA100130 0E0E012F
	s_waitcnt vmcnt(0)                                         // 0000003EFD50: BF8903F7
	v_dual_mov_b32 v16, v46 :: v_dual_mov_b32 v17, v9          // 0000003EFD54: CA10012E 10100109
	s_mov_b32 s2, 0x76543210                                   // 0000003EFD5C: BE8200FF 76543210
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003EFD64: BF870009
	v_permlanex16_b32 v1, v1, s2, 0xfedcba98                   // 0000003EFD68: D65C0001 03FC0501 FEDCBA98
	v_permlanex16_b32 v2, v2, s2, 0xfedcba98                   // 0000003EFD74: D65C0002 03FC0502 FEDCBA98
	v_permlanex16_b32 v3, v3, s2, 0xfedcba98                   // 0000003EFD80: D65C0003 03FC0503 FEDCBA98
	v_permlanex16_b32 v6, v6, s2, 0xfedcba98                   // 0000003EFD8C: D65C0006 03FC0506 FEDCBA98
	v_permlanex16_b32 v4, v4, s2, 0xfedcba98                   // 0000003EFD98: D65C0004 03FC0504 FEDCBA98
	v_permlanex16_b32 v5, v5, s2, 0xfedcba98                   // 0000003EFDA4: D65C0005 03FC0505 FEDCBA98
	v_permlanex16_b32 v8, v8, s2, 0xfedcba98                   // 0000003EFDB0: D65C0008 03FC0508 FEDCBA98
	v_permlanex16_b32 v10, v10, s2, 0xfedcba98                 // 0000003EFDBC: D65C000A 03FC050A FEDCBA98
	v_permlanex16_b32 v7, v7, s2, 0xfedcba98                   // 0000003EFDC8: D65C0007 03FC0507 FEDCBA98
	v_permlanex16_b32 v11, v11, s2, 0xfedcba98                 // 0000003EFDD4: D65C000B 03FC050B FEDCBA98
	v_permlanex16_b32 v12, v12, s2, 0xfedcba98                 // 0000003EFDE0: D65C000C 03FC050C FEDCBA98
	v_permlanex16_b32 v13, v13, s2, 0xfedcba98                 // 0000003EFDEC: D65C000D 03FC050D FEDCBA98
	v_permlanex16_b32 v14, v14, s2, 0xfedcba98                 // 0000003EFDF8: D65C000E 03FC050E FEDCBA98
	v_permlanex16_b32 v15, v15, s2, 0xfedcba98                 // 0000003EFE04: D65C000F 03FC050F FEDCBA98
	v_permlanex16_b32 v16, v16, s2, 0xfedcba98                 // 0000003EFE10: D65C0010 03FC0510 FEDCBA98
	v_permlanex16_b32 v17, v17, s2, 0xfedcba98                 // 0000003EFE1C: D65C0011 03FC0511 FEDCBA98
	.long 0xd44c0002                                           // 0000003EFE28: D44C0002
	v_cndmask_b32_e32 v1, 16, v43, vcc_lo                      // 0000003EFE2C: 02025690
	s_barrier                                                  // 0000003EFE30: BFBD0000
	buffer_gl0_inv                                             // 0000003EFE34: E0AC0000 00000000
	s_and_saveexec_b32 s3, s2                                  // 0000003EFE3C: BE832002
	s_cbranch_execz 36                                         // 0000003EFE40: BFA50024 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb1ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x20d4>
	v_dual_add_f32 v9, v9, v17 :: v_dual_add_f32 v16, v46, v16 // 0000003EFE44: C9082309 0910212E
	v_dual_add_f32 v8, v53, v8 :: v_dual_lshlrev_b32 v17, 2, v43// 0000003EFE4C: C9221135 08105682
	v_dual_add_f32 v6, v56, v6 :: v_dual_add_f32 v3, v58, v3   // 0000003EFE54: C9080D38 0602073A
	v_dual_add_f32 v1, v59, v1 :: v_dual_add_f32 v2, v57, v2   // 0000003EFE5C: C908033B 01020539
	s_delay_alu instid0(VALU_DEP_3)                            // 0000003EFE64: BF870003
	v_lshl_or_b32 v17, v42, 10, v17                            // 0000003EFE68: D6560011 0445152A
	v_dual_add_f32 v4, v55, v4 :: v_dual_add_f32 v5, v52, v5   // 0000003EFE70: C9080937 04040B34
	v_dual_add_f32 v11, v51, v11 :: v_dual_add_f32 v10, v54, v10// 0000003EFE78: C9081733 0B0A1536
	v_dual_add_f32 v13, v49, v13 :: v_dual_add_f32 v12, v50, v12// 0000003EFE80: C9081B31 0D0C1932
	v_add_f32_e32 v7, v45, v7                                  // 0000003EFE88: 060E0F2D
	v_dual_add_f32 v15, v47, v15 :: v_dual_add_f32 v14, v48, v14// 0000003EFE8C: C9081F2F 0F0E1D30
	ds_store_2addr_b32 v17, v1, v3 offset1:16                  // 0000003EFE94: D8381000 00030111
	ds_store_2addr_b32 v17, v2, v6 offset0:128 offset1:144     // 0000003EFE9C: D8389080 00060211
	ds_store_2addr_b32 v17, v4, v8 offset0:32 offset1:48       // 0000003EFEA4: D8383020 00080411
	ds_store_2addr_b32 v17, v5, v10 offset0:160 offset1:176    // 0000003EFEAC: D838B0A0 000A0511
	ds_store_2addr_b32 v17, v7, v12 offset0:64 offset1:80      // 0000003EFEB4: D8385040 000C0711
	ds_store_2addr_b32 v17, v11, v13 offset0:192 offset1:208   // 0000003EFEBC: D838D0C0 000D0B11
	ds_store_2addr_b32 v17, v14, v16 offset0:96 offset1:112    // 0000003EFEC4: D8387060 00100E11
	ds_store_2addr_b32 v17, v15, v9 offset0:224 offset1:240    // 0000003EFECC: D838F0E0 00090F11
	s_or_b32 exec_lo, exec_lo, s3                              // 0000003EFED4: 8C7E037E
	.long 0xd44c0003                                           // 0000003EFED8: D44C0003
	v_cndmask_b32_e32 v1, 0x100, v0, vcc_lo                    // 0000003EFEDC: 020200FF 00000100
	s_waitcnt lgkmcnt(0)                                       // 0000003EFEE4: BF89FC07
	s_barrier                                                  // 0000003EFEE8: BFBD0000
	buffer_gl0_inv                                             // 0000003EFEEC: E0AC0000 00000000
	s_and_saveexec_b32 s4, s3                                  // 0000003EFEF4: BE842003
	s_cbranch_execnz 7                                         // 0000003EFEF8: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb1ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2118>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000003EFEFC: 8C7E047E
	s_cmp_lt_i32 s21, 2                                        // 0000003EFF00: BF048215
	s_mov_b32 s4, -1                                           // 0000003EFF04: BE8400C1
	s_cbranch_scc0 33                                          // 0000003EFF08: BFA10021 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb1ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2190>
	s_and_b32 vcc_lo, exec_lo, s4                              // 0000003EFF0C: 8B6A047E
	s_cbranch_vccz 63670                                       // 0000003EFF10: BFA3F8B6 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb1ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	s_branch 207                                               // 0000003EFF14: BFA000CF <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb1ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2454>
	v_lshlrev_b32_e32 v7, 2, v0                                // 0000003EFF18: 300E0082
	ds_load_2addr_stride64_b32 v[1:2], v7 offset1:4            // 0000003EFF1C: D8E00400 01000007
	ds_load_2addr_stride64_b32 v[3:4], v7 offset0:8 offset1:12 // 0000003EFF24: D8E00C08 03000007
	ds_load_2addr_stride64_b32 v[5:6], v7 offset0:16 offset1:20// 0000003EFF2C: D8E01410 05000007
	s_waitcnt lgkmcnt(2)                                       // 0000003EFF34: BF89FC27
	v_add_f32_e32 v1, 0, v1                                    // 0000003EFF38: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003EFF3C: BF8700A1
	v_add_f32_e32 v1, v1, v2                                   // 0000003EFF40: 06020501
	s_waitcnt lgkmcnt(1)                                       // 0000003EFF44: BF89FC17
	v_add_f32_e32 v3, v1, v3                                   // 0000003EFF48: 06060701
	ds_load_2addr_stride64_b32 v[1:2], v7 offset0:24 offset1:28// 0000003EFF4C: D8E01C18 01000007
	v_add_f32_e32 v3, v3, v4                                   // 0000003EFF54: 06060903
	s_waitcnt lgkmcnt(1)                                       // 0000003EFF58: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003EFF5C: BF870091
	v_add_f32_e32 v3, v3, v5                                   // 0000003EFF60: 06060B03
	v_add_f32_e32 v3, v3, v6                                   // 0000003EFF64: 06060D03
	s_waitcnt lgkmcnt(0)                                       // 0000003EFF68: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003EFF6C: BF870091
	v_add_f32_e32 v1, v3, v1                                   // 0000003EFF70: 06020303
	v_add_f32_e32 v1, v1, v2                                   // 0000003EFF74: 06020501
	ds_store_b32 v7, v1 offset:8192                            // 0000003EFF78: D8342000 00000107
	s_or_b32 exec_lo, exec_lo, s4                              // 0000003EFF80: 8C7E047E
	s_cmp_lt_i32 s21, 2                                        // 0000003EFF84: BF048215
	s_mov_b32 s4, -1                                           // 0000003EFF88: BE8400C1
	s_cbranch_scc1 65503                                       // 0000003EFF8C: BFA2FFDF <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb1ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x210c>
	s_load_b128 s[4:7], s[0:1], 0x1a8                          // 0000003EFF90: F4080100 F80001A8
	s_lshl_b64 s[8:9], s[30:31], 2                             // 0000003EFF98: 8488821E
	s_waitcnt lgkmcnt(0)                                       // 0000003EFF9C: BF89FC07
	s_barrier                                                  // 0000003EFFA0: BFBD0000
	buffer_gl0_inv                                             // 0000003EFFA4: E0AC0000 00000000
	s_add_u32 s1, s4, s8                                       // 0000003EFFAC: 80010804
	s_addc_u32 s4, s5, s9                                      // 0000003EFFB0: 82040905
	s_and_saveexec_b32 s0, s3                                  // 0000003EFFB4: BE802003
	s_cbranch_execz 41                                         // 0000003EFFB8: BFA50029 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb1ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2260>
	v_lshrrev_b32_e32 v1, 7, v0                                // 0000003EFFBC: 32020087
	s_ashr_i32 s5, s20, 31                                     // 0000003EFFC0: 86059F14
	v_lshlrev_b32_e32 v4, 2, v0                                // 0000003EFFC4: 30080082
	s_lshl_b32 s8, s26, 7                                      // 0000003EFFC8: 8408871A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003EFFCC: BF870009
	s_ashr_i32 s9, s8, 31                                      // 0000003EFFD0: 86099F08
	v_lshl_or_b32 v1, s23, 1, v1                               // 0000003EFFD4: D6560001 04050217
	ds_load_b32 v4, v4 offset:8192                             // 0000003EFFDC: D8D82000 04000004
	s_lshl_b64 s[8:9], s[8:9], 2                               // 0000003EFFE4: 84888208
	.long 0xd72c0003                                           // 0000003EFFE8: D72C0003
	v_cndmask_b32_e32 v0, v1, v5, vcc_lo                       // 0000003EFFEC: 02000B01
	v_mad_u64_u32 v[1:2], null, v1, s20, 0                     // 0000003EFFF0: D6FE7C01 02002901
	s_ashr_i32 s5, s23, 31                                     // 0000003EFFF8: 86059F17
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000003EFFFC: BF870499
	s_mul_i32 s5, s5, s20                                      // 0000003F0000: 96051405
	v_add3_u32 v2, v2, v3, s5                                  // 0000003F0004: D6550002 00160702
	v_and_b32_e32 v3, 0x7f, v0                                 // 0000003F000C: 360600FF 0000007F
	s_add_u32 s5, s1, s8                                       // 0000003F0014: 80050801
	s_addc_u32 s8, s4, s9                                      // 0000003F0018: 82080904
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003F001C: BF870112
	.long 0xd73c0001                                           // 0000003F0020: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000003F0024: 02020282
	v_lshlrev_b32_e32 v3, 2, v3                                // 0000003F0028: 30060682
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F002C: BF870092
	.long 0xd7006a01                                           // 0000003F0030: D7006A01
	v_cndmask_b32_e32 v1, s5, v1, vcc_lo                       // 0000003F0034: 02020205
	v_add_co_ci_u32_e64 v2, null, s8, v2, vcc_lo               // 0000003F0038: D5207C02 01AA0408
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F0040: BF870092
	.long 0xd7006a01                                           // 0000003F0044: D7006A01
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 0000003F0048: 02020701
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 0000003F004C: D5207C02 01AA0480
	s_waitcnt lgkmcnt(0)                                       // 0000003F0054: BF89FC07
	global_store_b32 v[1:2], v4, off                           // 0000003F0058: DC6A0000 007C0401
	s_or_b32 exec_lo, exec_lo, s0                              // 0000003F0060: 8C7E007E
	s_ashr_i32 s29, s28, 31                                    // 0000003F0064: 861D9F1C
	.long 0xd44a0000                                           // 0000003F0068: D44A0000
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 0000003F006C: 02020080
	s_lshl_b64 s[8:9], s[28:29], 2                             // 0000003F0070: 8488821C
	s_waitcnt_vscnt null, 0x0                                  // 0000003F0074: BC7C0000
	buffer_gl1_inv                                             // 0000003F0078: E0B00000 00000000
	buffer_gl0_inv                                             // 0000003F0080: E0AC0000 00000000
	s_add_u32 s5, s6, s8                                       // 0000003F0088: 80050806
	s_addc_u32 s6, s7, s9                                      // 0000003F008C: 82060907
	s_barrier                                                  // 0000003F0090: BFBD0000
	buffer_gl0_inv                                             // 0000003F0094: E0AC0000 00000000
	s_and_saveexec_b32 s7, s0                                  // 0000003F009C: BE872000
	s_cbranch_execz 29                                         // 0000003F00A0: BFA5001D <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb1ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2318>
	s_mov_b32 s9, exec_lo                                      // 0000003F00A4: BE89007E
	s_mov_b32 s8, exec_lo                                      // 0000003F00A8: BE88007E
	.long 0xd71f0001                                           // 0000003F00AC: D71F0001
	v_cndmask_b32_e32 v0, s9, v128, vcc_lo                     // 0000003F00B0: 02010009
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003F00B4: BF870001
	v_cmpx_eq_u32_e32 0, v1                                    // 0000003F00B8: 7D940280
	s_cbranch_execz 9                                          // 0000003F00BC: BFA50009 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb1ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x22e4>
	s_lshl_b64 s[10:11], s[26:27], 2                           // 0000003F00C0: 848A821A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000003F00C4: BF8704B9
	s_add_u32 s10, s5, s10                                     // 0000003F00C8: 800A0A05
	s_addc_u32 s11, s6, s11                                    // 0000003F00CC: 820B0B06
	s_bcnt1_i32_b32 s9, s9                                     // 0000003F00D0: BE891809
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, s9              // 0000003F00D4: CA100080 02020009
	global_atomic_add_u32 v2, v2, v3, s[10:11] glc             // 0000003F00DC: DCD64000 020A0302
	s_or_b32 exec_lo, exec_lo, s8                              // 0000003F00E4: 8C7E087E
	s_waitcnt vmcnt(0)                                         // 0000003F00E8: BF8903F7
	v_readfirstlane_b32 s8, v2                                 // 0000003F00EC: 7E100502
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003F00F0: BF870001
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s8, v1       // 0000003F00F4: CA200080 02000208
	s_add_i32 s8, s21, -1                                      // 0000003F00FC: 8108C115
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000003F0100: BF870481
	v_cmp_eq_u32_e32 vcc_lo, s8, v1                            // 0000003F0104: 7C940208
	v_cndmask_b32_e64 v1, 0, 1, vcc_lo                         // 0000003F0108: D5010001 01A90280
	ds_store_b32 v2, v1 offset:10240                           // 0000003F0110: D8342800 00000102
	s_or_b32 exec_lo, exec_lo, s7                              // 0000003F0118: 8C7E077E
	v_mov_b32_e32 v1, 0                                        // 0000003F011C: 7E020280
	s_waitcnt lgkmcnt(0)                                       // 0000003F0120: BF89FC07
	s_barrier                                                  // 0000003F0124: BFBD0000
	buffer_gl0_inv                                             // 0000003F0128: E0AC0000 00000000
	ds_load_b32 v1, v1 offset:10240                            // 0000003F0130: D8D82800 01000001
	s_waitcnt lgkmcnt(0)                                       // 0000003F0138: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 0000003F013C: 7C940280
	s_cbranch_vccnz 67                                         // 0000003F0140: BFA40043 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb1ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2450>
	buffer_gl1_inv                                             // 0000003F0144: E0B00000 00000000
	buffer_gl0_inv                                             // 0000003F014C: E0AC0000 00000000
	s_and_saveexec_b32 s7, s3                                  // 0000003F0154: BE872003
	s_cbranch_execz 49                                         // 0000003F0158: BFA50031 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb1ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2420>
	v_and_b32_e32 v2, 0x7f, v0                                 // 0000003F015C: 360400FF 0000007F
	s_lshl_b32 s8, s26, 7                                      // 0000003F0164: 8408871A
	s_ashr_i32 s3, s20, 31                                     // 0000003F0168: 86039F14
	s_ashr_i32 s9, s8, 31                                      // 0000003F016C: 86099F08
	v_lshrrev_b32_e32 v1, 7, v0                                // 0000003F0170: 32020087
	v_dual_mov_b32 v2, 0 :: v_dual_lshlrev_b32 v3, 2, v2       // 0000003F0174: CA220080 02020482
	s_lshl_b64 s[8:9], s[8:9], 2                               // 0000003F017C: 84888208
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003F0180: BF8700A9
	s_add_u32 s1, s1, s8                                       // 0000003F0184: 80010801
	s_addc_u32 s4, s4, s9                                      // 0000003F0188: 82040904
	.long 0xd7000103                                           // 0000003F018C: D7000103
	v_cndmask_b32_e32 v1, s1, v3, vcc_lo                       // 0000003F0190: 02020601
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003F0194: BF870001
	v_add_co_ci_u32_e64 v4, null, s4, 0, s1                    // 0000003F0198: D5207C04 00050004
	s_mov_b32 s1, s20                                          // 0000003F01A0: BE810014
	s_nop 0                                                    // 0000003F01A4: BF800000
	s_nop 0                                                    // 0000003F01A8: BF800000
	s_nop 0                                                    // 0000003F01AC: BF800000
	s_nop 0                                                    // 0000003F01B0: BF800000
	s_nop 0                                                    // 0000003F01B4: BF800000
	s_nop 0                                                    // 0000003F01B8: BF800000
	s_nop 0                                                    // 0000003F01BC: BF800000
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000003F01C0: BF8704A9
	v_mad_u64_u32 v[5:6], null, v1, s1, 0                      // 0000003F01C4: D6FE7C05 02000301
	s_add_i32 s21, s21, -1                                     // 0000003F01CC: 8115C115
	s_cmp_eq_u32 s21, 0                                        // 0000003F01D0: BF068015
	v_mad_u64_u32 v[6:7], null, v1, s3, v[6:7]                 // 0000003F01D4: D6FE7C06 04180701
	v_add_nc_u32_e32 v1, 2, v1                                 // 0000003F01DC: 4A020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F01E0: BF870092
	.long 0xd73c0005                                           // 0000003F01E4: D73C0005
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 0000003F01E8: 02020A82
	.long 0xd7006a05                                           // 0000003F01EC: D7006A05
	v_cndmask_b32_e32 v1, v3, v5, vcc_lo                       // 0000003F01F0: 02020B03
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003F01F4: BF870001
	v_add_co_ci_u32_e64 v6, null, v4, v6, vcc_lo               // 0000003F01F8: D5207C06 01AA0D04
	global_load_b32 v5, v[5:6], off glc                        // 0000003F0200: DC524000 057C0005
	s_waitcnt vmcnt(0)                                         // 0000003F0208: BF8903F7
	v_add_f32_e32 v2, v2, v5                                   // 0000003F020C: 06040B02
	s_cbranch_scc0 65515                                       // 0000003F0210: BFA1FFEB <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb1ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x23c0>
	v_lshlrev_b32_e32 v1, 2, v0                                // 0000003F0214: 30020082
	ds_store_b32 v1, v2 offset:8192                            // 0000003F0218: D8342000 00000201
	s_or_b32 exec_lo, exec_lo, s7                              // 0000003F0220: 8C7E077E
	s_and_saveexec_b32 s1, s0                                  // 0000003F0224: BE812000
	s_cbranch_execz 6                                          // 0000003F0228: BFA50006 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb1ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2444>
	s_lshl_b64 s[8:9], s[26:27], 2                             // 0000003F022C: 8488821A
	v_mov_b32_e32 v1, 0                                        // 0000003F0230: 7E020280
	s_add_u32 s4, s5, s8                                       // 0000003F0234: 80040805
	s_addc_u32 s5, s6, s9                                      // 0000003F0238: 82050906
	global_store_b32 v1, v1, s[4:5]                            // 0000003F023C: DC6A0000 00040101
	s_or_b32 exec_lo, exec_lo, s1                              // 0000003F0244: 8C7E017E
	s_cbranch_execz 63464                                      // 0000003F0248: BFA5F7E8 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb1ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	s_branch 1                                                 // 0000003F024C: BFA00001 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb1ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2454>
	s_branch 63462                                             // 0000003F0250: BFA0F7E6 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb1ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	v_cmp_gt_i32_e32 vcc_lo, s18, v42                          // 0000003F0254: 7C885412
	.long 0xd44c0000                                           // 0000003F0258: D44C0000
	v_cndmask_b32_e32 v1, 64, v0, vcc_lo                       // 0000003F025C: 020200C0
	s_waitcnt lgkmcnt(0)                                       // 0000003F0260: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 0000003F0264: BC7C0000
	s_barrier                                                  // 0000003F0268: BFBD0000
	buffer_gl0_inv                                             // 0000003F026C: E0AC0000 00000000
	s_and_b32 s0, vcc_lo, s0                                   // 0000003F0274: 8B00006A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003F0278: BF870009
	s_and_saveexec_b32 s1, s0                                  // 0000003F027C: BE812000
	s_cbranch_execz 63450                                      // 0000003F0280: BFA5F7DA <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb1ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	v_and_b32_e32 v1, 15, v0                                   // 0000003F0284: 3602008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F0288: BF870091
	v_lshlrev_b32_e32 v2, 2, v1                                // 0000003F028C: 30040282
	v_lshl_or_b32 v2, v42, 9, v2                               // 0000003F0290: D6560002 0409132A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003F0298: BF870001
	v_add_nc_u32_e32 v8, 0x2000, v2                            // 0000003F029C: 4A1004FF 00002000
	ds_load_2addr_b32 v[2:3], v8 offset1:16                    // 0000003F02A4: D8DC1000 02000008
	ds_load_2addr_b32 v[4:5], v8 offset0:32 offset1:48         // 0000003F02AC: D8DC3020 04000008
	ds_load_2addr_b32 v[6:7], v8 offset0:64 offset1:80         // 0000003F02B4: D8DC5040 06000008
	ds_load_2addr_b32 v[8:9], v8 offset0:96 offset1:112        // 0000003F02BC: D8DC7060 08000008
	v_and_b32_e32 v10, 1, v0                                   // 0000003F02C4: 36140081
	v_and_b32_e32 v11, 2, v0                                   // 0000003F02C8: 36160082
	s_waitcnt lgkmcnt(3)                                       // 0000003F02CC: BF89FC37
	v_dual_add_f32 v13, v2, v3 :: v_dual_and_b32 v12, 4, v0    // 0000003F02D0: C9240702 0D0C0084
	s_waitcnt lgkmcnt(2)                                       // 0000003F02D8: BF89FC27
	v_dual_sub_f32 v2, v2, v3 :: v_dual_add_f32 v3, v4, v5     // 0000003F02DC: C9480702 02020B04
	s_waitcnt lgkmcnt(1)                                       // 0000003F02E4: BF89FC17
	v_dual_sub_f32 v4, v4, v5 :: v_dual_add_f32 v5, v6, v7     // 0000003F02E8: C9480B04 04040F06
	s_waitcnt lgkmcnt(0)                                       // 0000003F02F0: BF89FC07
	v_dual_sub_f32 v6, v6, v7 :: v_dual_add_f32 v7, v8, v9     // 0000003F02F4: C9480F06 06061308
	v_dual_sub_f32 v8, v8, v9 :: v_dual_add_f32 v9, v13, v3    // 0000003F02FC: C9481308 0808070D
	v_sub_f32_e32 v3, v13, v3                                  // 0000003F0304: 0806070D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000003F0308: BF870243
	v_dual_add_f32 v13, v2, v4 :: v_dual_add_f32 v14, v5, v7   // 0000003F030C: C9080902 0D0E0F05
	v_dual_sub_f32 v2, v2, v4 :: v_dual_sub_f32 v5, v5, v7     // 0000003F0314: C94A0902 02040F05
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 0000003F031C: 7C941480
	.long 0xd44a0000                                           // 0000003F0320: D44A0000
	v_cndmask_b32_e32 v1, 0, v12, vcc_lo                       // 0000003F0324: 02021880
	v_dual_add_f32 v7, v9, v14 :: v_dual_add_f32 v4, v6, v8    // 0000003F0328: C9081D09 07041106
	v_sub_f32_e32 v6, v6, v8                                   // 0000003F0330: 080C1106
	v_sub_f32_e32 v8, v9, v14                                  // 0000003F0334: 08101D09
	s_delay_alu instid0(VALU_DEP_3)                            // 0000003F0338: BF870003
	v_add_f32_e32 v9, v13, v4                                  // 0000003F033C: 0612090D
	v_dual_sub_f32 v4, v13, v4 :: v_dual_add_f32 v13, v3, v5   // 0000003F0340: C948090D 040C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 0000003F0348: 08060B03
	v_add_f32_e32 v5, v2, v6                                   // 0000003F034C: 060A0D02
	v_sub_f32_e32 v2, v2, v6                                   // 0000003F0350: 08040D02
	v_mov_b32_dpp v6, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003F0354: 7E0C02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 0000003F035C: D5010007 21AA0F07
	v_mov_b32_dpp v10, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003F0364: 7E1402FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 0000003F036C: D5010009 21AA1309
	v_mov_b32_dpp v14, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003F0374: 7E1C02FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 0000003F037C: D501000D 21AA1B0D
	v_mov_b32_dpp v15, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003F0384: 7E1E02FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 0000003F038C: D5010005 21AA0B05
	v_mov_b32_dpp v16, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003F0394: 7E2002FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 0000003F039C: D5010008 21AA1108
	v_mov_b32_dpp v17, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003F03A4: 7E2202FA FF016104
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 0000003F03AC: D5010004 21AA0904
	v_mov_b32_dpp v18, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003F03B4: 7E2402FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 0000003F03BC: D5010003 21AA0703
	v_mov_b32_dpp v19, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003F03C4: 7E2602FA FF016102
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 0000003F03CC: D5010002 21AA0502
	v_dual_add_f32 v6, v7, v6 :: v_dual_add_f32 v5, v5, v15    // 0000003F03D4: C9080D07 06041F05
	v_cmp_eq_u32_e32 vcc_lo, 0, v11                            // 0000003F03DC: 7C941680
	v_dual_add_f32 v7, v9, v10 :: v_dual_add_f32 v8, v8, v16   // 0000003F03E0: C9081509 07082108
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000003F03E8: BF870233
	v_mov_b32_dpp v10, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003F03EC: 7E1402FA FF016206
	v_add_f32_e32 v4, v4, v17                                  // 0000003F03F4: 06082304
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 0000003F03F8: D5010006 21AA0D06
	v_mov_b32_dpp v11, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003F0400: 7E1602FA FF016207
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 0000003F0408: D5010007 21AA0F07
	v_add_f32_e32 v2, v2, v19                                  // 0000003F0410: 06042702
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F0414: BF870092
	v_dual_add_f32 v6, v6, v10 :: v_dual_add_f32 v7, v7, v11   // 0000003F0418: C9081506 06061707
	v_mov_b32_dpp v10, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003F0420: 7E1402FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s0                          // 0000003F0428: D5010006 20020D06
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000003F0430: BF8700D3
	v_mov_b32_dpp v11, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003F0434: 7E1602FA FF016407
	v_cndmask_b32_e64 v7, -v7, v7, s0                          // 0000003F043C: D5010007 20020F07
	v_add_f32_e32 v9, v13, v14                                 // 0000003F0444: 06121D0D
	v_mov_b32_dpp v14, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003F0448: 7E1C02FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 0000003F0450: D5010005 21AA0B05
	v_dual_add_f32 v15, v5, v14 :: v_dual_add_f32 v14, v7, v11 // 0000003F0458: C9081D05 0F0E1707
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003F0460: BF8701A4
	v_mov_b32_dpp v13, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003F0464: 7E1A02FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 0000003F046C: D5010009 21AA1309
	v_mov_b32_dpp v7, v15 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003F0474: 7E0E02FA FF01640F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003F047C: BF870194
	v_mov_b32_dpp v23, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003F0480: 7E2E02FA FF01680E
	v_add_f32_e32 v9, v9, v13                                  // 0000003F0488: 06121B09
	v_mov_b32_dpp v13, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003F048C: 7E1A02FA FF016208
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003F0494: BF8700A2
	v_mov_b32_dpp v12, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003F0498: 7E1802FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 0000003F04A0: D5010009 20021309
	v_add_f32_e32 v21, v9, v12                                 // 0000003F04A8: 062A1909
	v_mov_b32_dpp v12, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003F04AC: 7E1802FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 0000003F04B4: D5010002 21AA0502
	v_add_f32_e32 v3, v3, v18                                  // 0000003F04BC: 06062503
	v_cndmask_b32_e64 v9, -v15, v15, s0                        // 0000003F04C0: D5010009 20021F0F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003F04C8: BF870193
	v_add_f32_e32 v2, v2, v12                                  // 0000003F04CC: 06041902
	v_mov_b32_dpp v11, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003F04D0: 7E1602FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 0000003F04D8: D5010003 21AA0703
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003F04E0: BF870114
	v_add_f32_e32 v19, v9, v7                                  // 0000003F04E4: 06260F09
	v_add_f32_e32 v3, v3, v11                                  // 0000003F04E8: 06061703
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003F04EC: BF870112
	v_mov_b32_dpp v20, v19 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003F04F0: 7E2802FA FF016813
	v_mov_b32_dpp v12, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003F04F8: 7E1802FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 0000003F0500: D5010003 20020703
	v_add_f32_e32 v5, v6, v10                                  // 0000003F0508: 060A1506
	v_cndmask_b32_e64 v6, -v8, v8, vcc_lo                      // 0000003F050C: D5010006 21AA1108
	v_mov_b32_dpp v10, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003F0514: 7E1402FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 0000003F051C: D5010004 21AA0904
	v_add_f32_e32 v12, v3, v12                                 // 0000003F0524: 06181903
	v_mov_b32_dpp v8, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003F0528: 7E1002FA FF016805
	v_add_f32_e32 v6, v6, v13                                  // 0000003F0530: 060C1B06
	v_mov_b32_dpp v13, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003F0534: 7E1A02FA FF016402
	v_add_f32_e32 v4, v4, v10                                  // 0000003F053C: 06081504
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 0000003F0540: D5010002 20020502
	v_mov_b32_dpp v22, v21 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003F0548: 7E2C02FA FF016815
	v_mov_b32_dpp v10, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003F0550: 7E1402FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s0                          // 0000003F0558: D5010006 20020D06
	v_mov_b32_dpp v11, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003F0560: 7E1602FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 0000003F0568: D5010004 20020904
	v_add_f32_e32 v9, v2, v13                                  // 0000003F0570: 06121B02
	v_mov_b32_dpp v13, v12 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003F0574: 7E1A02FA FF01680C
	v_add_f32_e32 v17, v6, v10                                 // 0000003F057C: 06221506
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003F0580: BF870214
	v_add_f32_e32 v15, v4, v11                                 // 0000003F0584: 061E1704
	v_mov_b32_dpp v10, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003F0588: 7E1402FA FF016809
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003F0590: BF870193
	v_mov_b32_dpp v18, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003F0594: 7E2402FA FF016811
	v_mov_b32_dpp v16, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003F059C: 7E2002FA FF01680F
	s_and_b32 exec_lo, exec_lo, s2                             // 0000003F05A4: 8B7E027E
	s_cbranch_execz 63248                                      // 0000003F05A8: BFA5F710 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb1ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	v_lshl_or_b32 v3, s26, 7, v1                               // 0000003F05AC: D6560003 04050E1A
	v_and_b32_e32 v0, 8, v0                                    // 0000003F05B4: 36000088
	s_cmp_lg_u64 s[24:25], 0                                   // 0000003F05B8: BF118018
	s_cselect_b32 s1, -1, 0                                    // 0000003F05BC: 980180C1
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003F05C0: BF870112
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000003F05C4: 3408069F
	.long 0xd44a0000                                           // 0000003F05C8: D44A0000
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 0000003F05CC: 02020080
	s_lshr_b32 s2, s20, 31                                     // 0000003F05D0: 85029F14
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003F05D4: BF870009
	s_add_i32 s2, s20, s2                                      // 0000003F05D8: 81020214
	.long 0xd73c0001                                           // 0000003F05DC: D73C0001
	v_cndmask_b32_e32 v1, 1, v3, vcc_lo                        // 0000003F05E0: 02020681
	v_cndmask_b32_e64 v0, -v5, v5, s0                          // 0000003F05E4: D5010000 20020B05
	v_mad_i64_i32 v[4:5], null, s20, v42, 0                    // 0000003F05EC: D6FF7C04 02025414
	s_ashr_i32 s2, s2, 1                                       // 0000003F05F4: 86028102
	s_cmp_eq_u64 s[24:25], 0                                   // 0000003F05F8: BF108018
	v_mad_i64_i32 v[24:25], null, s2, v42, 0                   // 0000003F05FC: D6FF7C18 02025402
	.long 0xd7006a06                                           // 0000003F0604: D7006A06
	v_cndmask_b32_e32 v1, s12, v1, vcc_lo                      // 0000003F0608: 0202020C
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003F060C: BF870001
	v_add_co_ci_u32_e64 v7, null, s13, v2, vcc_lo              // 0000003F0610: D5207C07 01AA040D
	v_add_f32_e32 v0, v0, v8                                   // 0000003F0618: 06001100
	.long 0xd73c0004                                           // 0000003F061C: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 0000003F0620: 02020881
	global_load_d16_b16 v11, v[6:7], off                       // 0000003F0624: DC820000 0B7C0006
	v_mul_f32_e32 v0, 0x3db504f3, v0                           // 0000003F062C: 100000FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 0000003F0634: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003F0638: BF8700A1
	v_fma_mix_f32 v26, v11, v0, neg(0) op_sel_hi:[1,0,0]       // 0000003F063C: CC20001A 8A02010B
	.long 0xd7006a00                                           // 0000003F0644: D7006A00
	v_cndmask_b32_e32 v1, s14, v4, vcc_lo                      // 0000003F0648: 0202080E
	v_add_co_ci_u32_e64 v8, null, s15, v5, vcc_lo              // 0000003F064C: D5207C08 01AA0A0F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000003F0654: BF8701B3
	v_bfe_u32 v27, v26, 16, 1                                  // 0000003F0658: D610001B 0205211A
	.long 0xd73c0004                                           // 0000003F0660: D73C0004
	v_cndmask_b32_e32 v1, 1, v24, vcc_lo                       // 0000003F0664: 02023081
	v_ashrrev_i32_e32 v11, 31, v3                              // 0000003F0668: 3416069F
	v_add3_u32 v24, v26, v27, 0x7fff                           // 0000003F066C: D6550018 03FE371A 00007FFF
	s_cbranch_scc1 569                                         // 0000003F0678: BFA20239 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb1ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3160>
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003F067C: BF870122
	v_lshrrev_b32_e32 v25, 23, v11                             // 0000003F0680: 32321697
	v_mov_b32_e32 v29, s14                                     // 0000003F0684: 7E3A020E
	v_add_nc_u32_e32 v25, v3, v25                              // 0000003F0688: 4A323303
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F068C: BF870091
	v_and_b32_e32 v26, 0xfffffe00, v25                         // 0000003F0690: 363432FF FFFFFE00
	v_sub_nc_u32_e32 v27, v3, v26                              // 0000003F0698: 4C363503
	v_mov_b32_e32 v26, s15                                     // 0000003F069C: 7E34020F
	v_ashrrev_i32_e32 v25, 9, v25                              // 0000003F06A0: 34323289
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003F06A4: BF8701A3
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v27                        // 0000003F06A8: 7C8836FF 00000100
	v_add_nc_u32_e32 v28, 0xffffff00, v27                      // 0000003F06B0: 4A3836FF FFFFFF00
	v_dual_cndmask_b32 v30, s25, v26 :: v_dual_lshlrev_b32 v25, 8, v25// 0000003F06B8: CA623419 1E183288
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003F06C0: BF870112
	v_cndmask_b32_e32 v27, v28, v27, vcc_lo                    // 0000003F06C4: 0236371C
	v_ashrrev_i32_e32 v26, 31, v25                             // 0000003F06C8: 3434329F
	v_cndmask_b32_e32 v29, s24, v29, vcc_lo                    // 0000003F06CC: 023A3A18
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003F06D0: BF870193
	v_ashrrev_i32_e32 v28, 31, v27                             // 0000003F06D4: 3438369F
	.long 0xd73c0019                                           // 0000003F06D8: D73C0019
	v_cndmask_b32_e32 v1, 1, v25, vcc_lo                       // 0000003F06DC: 02023281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F06E0: BF870093
	.long 0xd7006a1d                                           // 0000003F06E4: D7006A1D
	v_cndmask_b32_e32 v1, v29, v4, vcc_lo                      // 0000003F06E8: 0202091D
	v_add_co_ci_u32_e64 v30, null, v30, v5, vcc_lo             // 0000003F06EC: D5207C1E 01AA0B1E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003F06F4: BF870194
	.long 0xd73c001b                                           // 0000003F06F8: D73C001B
	v_cndmask_b32_e32 v1, 1, v27, vcc_lo                       // 0000003F06FC: 02023681
	.long 0xd7006a19                                           // 0000003F0700: D7006A19
	v_cndmask_b32_e32 v1, v29, v25, vcc_lo                     // 0000003F0704: 0202331D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003F0708: BF870111
	v_add_co_ci_u32_e64 v26, null, v30, v26, vcc_lo            // 0000003F070C: D5207C1A 01AA351E
	.long 0xd7006a19                                           // 0000003F0714: D7006A19
	v_cndmask_b32_e32 v1, v25, v27, vcc_lo                     // 0000003F0718: 02023719
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003F071C: BF870001
	v_add_co_ci_u32_e64 v26, null, v26, v28, vcc_lo            // 0000003F0720: D5207C1A 01AA391A
	global_store_d16_hi_b16 v[25:26], v24, off                 // 0000003F0728: DC960000 007C1819
	s_cbranch_execnz 7                                         // 0000003F0730: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb1ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2950>
	.long 0xd7006a19                                           // 0000003F0734: D7006A19
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 0000003F0738: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003F073C: BF870001
	v_add_co_ci_u32_e64 v26, null, v8, v2, vcc_lo              // 0000003F0740: D5207C1A 01AA0508
	global_store_d16_hi_b16 v[25:26], v24, off                 // 0000003F0748: DC960000 007C1819
	global_load_d16_b16 v24, v[6:7], off offset:32             // 0000003F0750: DC820020 187C0006
	v_cndmask_b32_e64 v14, -v14, v14, s0                       // 0000003F0758: D501000E 20021D0E
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000003F0760: 916A017E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F0764: BF870091
	v_add_f32_e32 v14, v14, v23                                // 0000003F0768: 061C2F0E
	v_mul_f32_e32 v14, 0x3db504f3, v14                         // 0000003F076C: 101C1CFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 0000003F0774: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003F0778: BF870121
	v_fma_mix_f32 v23, v24, v14, neg(0) op_sel_hi:[1,0,0]      // 0000003F077C: CC200017 8A021D18
	v_cndmask_b32_e64 v14, 0, 1, s1                            // 0000003F0784: D501000E 00050280
	v_bfe_u32 v24, v23, 16, 1                                  // 0000003F078C: D6100018 02052117
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003F0794: BF870001
	v_add3_u32 v23, v23, v24, 0x7fff                           // 0000003F0798: D6550017 03FE3117 00007FFF
	s_cbranch_vccnz 495                                        // 0000003F07A4: BFA401EF <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb1ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3164>
	v_or_b32_e32 v24, 16, v3                                   // 0000003F07A8: 38300690
	v_lshrrev_b32_e32 v25, 23, v11                             // 0000003F07AC: 32321697
	v_mov_b32_e32 v27, s15                                     // 0000003F07B0: 7E36020F
	v_mov_b32_e32 v29, s14                                     // 0000003F07B4: 7E3A020E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F07B8: BF870093
	v_add_nc_u32_e32 v25, v24, v25                             // 0000003F07BC: 4A323318
	v_and_b32_e32 v26, 0xfffffe00, v25                         // 0000003F07C0: 363432FF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F07C8: BF870091
	v_sub_nc_u32_e32 v26, v24, v26                             // 0000003F07CC: 4C343518
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v26                        // 0000003F07D0: 7C8834FF 00000100
	v_add_nc_u32_e32 v28, 0xffffff00, v26                      // 0000003F07D8: 4A3834FF FFFFFF00
	v_cndmask_b32_e32 v30, s25, v27, vcc_lo                    // 0000003F07E0: 023C3619
	v_ashrrev_i32_e32 v25, 9, v25                              // 0000003F07E4: 34323289
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003F07E8: BF8701A3
	v_cndmask_b32_e32 v26, v28, v26, vcc_lo                    // 0000003F07EC: 0234351C
	v_cndmask_b32_e32 v28, s24, v29, vcc_lo                    // 0000003F07F0: 02383A18
	v_lshlrev_b32_e32 v24, 8, v25                              // 0000003F07F4: 30303288
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003F07F8: BF870193
	v_ashrrev_i32_e32 v27, 31, v26                             // 0000003F07FC: 3436349F
	.long 0xd7006a1c                                           // 0000003F0800: D7006A1C
	v_cndmask_b32_e32 v1, v28, v4, vcc_lo                      // 0000003F0804: 0202091C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003F0808: BF870211
	v_add_co_ci_u32_e64 v29, null, v30, v5, vcc_lo             // 0000003F080C: D5207C1D 01AA0B1E
	v_ashrrev_i32_e32 v25, 31, v24                             // 0000003F0814: 3432309F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003F0818: BF870114
	.long 0xd73c001a                                           // 0000003F081C: D73C001A
	v_cndmask_b32_e32 v1, 1, v26, vcc_lo                       // 0000003F0820: 02023481
	.long 0xd73c0018                                           // 0000003F0824: D73C0018
	v_cndmask_b32_e32 v1, 1, v24, vcc_lo                       // 0000003F0828: 02023081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F082C: BF870091
	.long 0xd7006a18                                           // 0000003F0830: D7006A18
	v_cndmask_b32_e32 v1, v28, v24, vcc_lo                     // 0000003F0834: 0202311C
	v_add_co_ci_u32_e64 v25, null, v29, v25, vcc_lo            // 0000003F0838: D5207C19 01AA331D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F0840: BF870092
	.long 0xd7006a18                                           // 0000003F0844: D7006A18
	v_cndmask_b32_e32 v1, v24, v26, vcc_lo                     // 0000003F0848: 02023518
	v_add_co_ci_u32_e64 v25, null, v25, v27, vcc_lo            // 0000003F084C: D5207C19 01AA3719
	global_store_d16_hi_b16 v[24:25], v23, off                 // 0000003F0854: DC960000 007C1718
	s_cbranch_execnz 7                                         // 0000003F085C: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb1ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2a7c>
	.long 0xd7006a18                                           // 0000003F0860: D7006A18
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 0000003F0864: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003F0868: BF870001
	v_add_co_ci_u32_e64 v25, null, v8, v2, vcc_lo              // 0000003F086C: D5207C19 01AA0508
	global_store_d16_hi_b16 v[24:25], v23, off offset:32       // 0000003F0874: DC960020 007C1718
	global_load_d16_b16 v23, v[6:7], off offset:64             // 0000003F087C: DC820040 177C0006
	v_cndmask_b32_e64 v21, -v21, v21, s0                       // 0000003F0884: D5010015 20022B15
	v_cmp_ne_u32_e32 vcc_lo, 1, v14                            // 0000003F088C: 7C9A1C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003F0890: BF8700A2
	v_add_f32_e32 v21, v21, v22                                // 0000003F0894: 062A2D15
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 0000003F0898: 8B6A6A7E
	v_mul_f32_e32 v21, 0x3db504f3, v21                         // 0000003F089C: 102A2AFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 0000003F08A4: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F08A8: BF870091
	v_fma_mix_f32 v21, v23, v21, neg(0) op_sel_hi:[1,0,0]      // 0000003F08AC: CC200015 8A022B17
	v_bfe_u32 v22, v21, 16, 1                                  // 0000003F08B4: D6100016 02052115
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003F08BC: BF870001
	v_add3_u32 v21, v21, v22, 0x7fff                           // 0000003F08C0: D6550015 03FE2D15 00007FFF
	s_cbranch_vccnz 422                                        // 0000003F08CC: BFA401A6 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb1ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3168>
	v_or_b32_e32 v22, 32, v3                                   // 0000003F08D0: 382C06A0
	v_lshrrev_b32_e32 v23, 23, v11                             // 0000003F08D4: 322E1697
	v_mov_b32_e32 v25, s15                                     // 0000003F08D8: 7E32020F
	v_mov_b32_e32 v27, s14                                     // 0000003F08DC: 7E36020E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F08E0: BF870093
	v_add_nc_u32_e32 v23, v22, v23                             // 0000003F08E4: 4A2E2F16
	v_and_b32_e32 v24, 0xfffffe00, v23                         // 0000003F08E8: 36302EFF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F08F0: BF870091
	v_sub_nc_u32_e32 v24, v22, v24                             // 0000003F08F4: 4C303116
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v24                        // 0000003F08F8: 7C8830FF 00000100
	v_add_nc_u32_e32 v26, 0xffffff00, v24                      // 0000003F0900: 4A3430FF FFFFFF00
	v_cndmask_b32_e32 v28, s25, v25, vcc_lo                    // 0000003F0908: 02383219
	v_ashrrev_i32_e32 v23, 9, v23                              // 0000003F090C: 342E2E89
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003F0910: BF8701A3
	v_cndmask_b32_e32 v24, v26, v24, vcc_lo                    // 0000003F0914: 0230311A
	v_cndmask_b32_e32 v26, s24, v27, vcc_lo                    // 0000003F0918: 02343618
	v_lshlrev_b32_e32 v22, 8, v23                              // 0000003F091C: 302C2E88
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003F0920: BF870193
	v_ashrrev_i32_e32 v25, 31, v24                             // 0000003F0924: 3432309F
	.long 0xd7006a1a                                           // 0000003F0928: D7006A1A
	v_cndmask_b32_e32 v1, v26, v4, vcc_lo                      // 0000003F092C: 0202091A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003F0930: BF870211
	v_add_co_ci_u32_e64 v27, null, v28, v5, vcc_lo             // 0000003F0934: D5207C1B 01AA0B1C
	v_ashrrev_i32_e32 v23, 31, v22                             // 0000003F093C: 342E2C9F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003F0940: BF870114
	.long 0xd73c0018                                           // 0000003F0944: D73C0018
	v_cndmask_b32_e32 v1, 1, v24, vcc_lo                       // 0000003F0948: 02023081
	.long 0xd73c0016                                           // 0000003F094C: D73C0016
	v_cndmask_b32_e32 v1, 1, v22, vcc_lo                       // 0000003F0950: 02022C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F0954: BF870091
	.long 0xd7006a16                                           // 0000003F0958: D7006A16
	v_cndmask_b32_e32 v1, v26, v22, vcc_lo                     // 0000003F095C: 02022D1A
	v_add_co_ci_u32_e64 v23, null, v27, v23, vcc_lo            // 0000003F0960: D5207C17 01AA2F1B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F0968: BF870092
	.long 0xd7006a16                                           // 0000003F096C: D7006A16
	v_cndmask_b32_e32 v1, v22, v24, vcc_lo                     // 0000003F0970: 02023116
	v_add_co_ci_u32_e64 v23, null, v23, v25, vcc_lo            // 0000003F0974: D5207C17 01AA3317
	global_store_d16_hi_b16 v[22:23], v21, off                 // 0000003F097C: DC960000 007C1516
	s_cbranch_execnz 7                                         // 0000003F0984: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb1ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2ba4>
	.long 0xd7006a16                                           // 0000003F0988: D7006A16
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 0000003F098C: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003F0990: BF870001
	v_add_co_ci_u32_e64 v23, null, v8, v2, vcc_lo              // 0000003F0994: D5207C17 01AA0508
	global_store_d16_hi_b16 v[22:23], v21, off offset:64       // 0000003F099C: DC960040 007C1516
	global_load_d16_b16 v21, v[6:7], off offset:96             // 0000003F09A4: DC820060 157C0006
	v_cndmask_b32_e64 v19, -v19, v19, s0                       // 0000003F09AC: D5010013 20022713
	v_cmp_ne_u32_e32 vcc_lo, 1, v14                            // 0000003F09B4: 7C9A1C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003F09B8: BF8700A2
	v_add_f32_e32 v19, v19, v20                                // 0000003F09BC: 06262913
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 0000003F09C0: 8B6A6A7E
	v_mul_f32_e32 v19, 0x3db504f3, v19                         // 0000003F09C4: 102626FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 0000003F09CC: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F09D0: BF870091
	v_fma_mix_f32 v19, v21, v19, neg(0) op_sel_hi:[1,0,0]      // 0000003F09D4: CC200013 8A022715
	v_bfe_u32 v20, v19, 16, 1                                  // 0000003F09DC: D6100014 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003F09E4: BF870001
	v_add3_u32 v19, v19, v20, 0x7fff                           // 0000003F09E8: D6550013 03FE2913 00007FFF
	s_cbranch_vccnz 349                                        // 0000003F09F4: BFA4015D <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb1ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x316c>
	v_or_b32_e32 v20, 48, v3                                   // 0000003F09F8: 382806B0
	v_lshrrev_b32_e32 v21, 23, v11                             // 0000003F09FC: 322A1697
	v_mov_b32_e32 v23, s15                                     // 0000003F0A00: 7E2E020F
	v_mov_b32_e32 v25, s14                                     // 0000003F0A04: 7E32020E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F0A08: BF870093
	v_add_nc_u32_e32 v21, v20, v21                             // 0000003F0A0C: 4A2A2B14
	v_and_b32_e32 v22, 0xfffffe00, v21                         // 0000003F0A10: 362C2AFF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F0A18: BF870091
	v_sub_nc_u32_e32 v22, v20, v22                             // 0000003F0A1C: 4C2C2D14
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v22                        // 0000003F0A20: 7C882CFF 00000100
	v_add_nc_u32_e32 v24, 0xffffff00, v22                      // 0000003F0A28: 4A302CFF FFFFFF00
	v_cndmask_b32_e32 v26, s25, v23, vcc_lo                    // 0000003F0A30: 02342E19
	v_ashrrev_i32_e32 v21, 9, v21                              // 0000003F0A34: 342A2A89
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003F0A38: BF8701A3
	v_cndmask_b32_e32 v22, v24, v22, vcc_lo                    // 0000003F0A3C: 022C2D18
	v_cndmask_b32_e32 v24, s24, v25, vcc_lo                    // 0000003F0A40: 02303218
	v_lshlrev_b32_e32 v20, 8, v21                              // 0000003F0A44: 30282A88
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003F0A48: BF870193
	v_ashrrev_i32_e32 v23, 31, v22                             // 0000003F0A4C: 342E2C9F
	.long 0xd7006a18                                           // 0000003F0A50: D7006A18
	v_cndmask_b32_e32 v1, v24, v4, vcc_lo                      // 0000003F0A54: 02020918
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003F0A58: BF870211
	v_add_co_ci_u32_e64 v25, null, v26, v5, vcc_lo             // 0000003F0A5C: D5207C19 01AA0B1A
	v_ashrrev_i32_e32 v21, 31, v20                             // 0000003F0A64: 342A289F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003F0A68: BF870114
	.long 0xd73c0016                                           // 0000003F0A6C: D73C0016
	v_cndmask_b32_e32 v1, 1, v22, vcc_lo                       // 0000003F0A70: 02022C81
	.long 0xd73c0014                                           // 0000003F0A74: D73C0014
	v_cndmask_b32_e32 v1, 1, v20, vcc_lo                       // 0000003F0A78: 02022881
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F0A7C: BF870091
	.long 0xd7006a14                                           // 0000003F0A80: D7006A14
	v_cndmask_b32_e32 v1, v24, v20, vcc_lo                     // 0000003F0A84: 02022918
	v_add_co_ci_u32_e64 v21, null, v25, v21, vcc_lo            // 0000003F0A88: D5207C15 01AA2B19
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F0A90: BF870092
	.long 0xd7006a14                                           // 0000003F0A94: D7006A14
	v_cndmask_b32_e32 v1, v20, v22, vcc_lo                     // 0000003F0A98: 02022D14
	v_add_co_ci_u32_e64 v21, null, v21, v23, vcc_lo            // 0000003F0A9C: D5207C15 01AA2F15
	global_store_d16_hi_b16 v[20:21], v19, off                 // 0000003F0AA4: DC960000 007C1314
	s_cbranch_execnz 7                                         // 0000003F0AAC: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb1ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2ccc>
	.long 0xd7006a14                                           // 0000003F0AB0: D7006A14
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 0000003F0AB4: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003F0AB8: BF870001
	v_add_co_ci_u32_e64 v21, null, v8, v2, vcc_lo              // 0000003F0ABC: D5207C15 01AA0508
	global_store_d16_hi_b16 v[20:21], v19, off offset:96       // 0000003F0AC4: DC960060 007C1314
	global_load_d16_b16 v19, v[6:7], off offset:128            // 0000003F0ACC: DC820080 137C0006
	v_cndmask_b32_e64 v17, -v17, v17, s0                       // 0000003F0AD4: D5010011 20022311
	v_cmp_ne_u32_e32 vcc_lo, 1, v14                            // 0000003F0ADC: 7C9A1C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003F0AE0: BF8700A2
	v_add_f32_e32 v17, v17, v18                                // 0000003F0AE4: 06222511
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 0000003F0AE8: 8B6A6A7E
	v_mul_f32_e32 v17, 0x3db504f3, v17                         // 0000003F0AEC: 102222FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 0000003F0AF4: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F0AF8: BF870091
	v_fma_mix_f32 v17, v19, v17, neg(0) op_sel_hi:[1,0,0]      // 0000003F0AFC: CC200011 8A022313
	v_bfe_u32 v18, v17, 16, 1                                  // 0000003F0B04: D6100012 02052111
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003F0B0C: BF870001
	v_add3_u32 v17, v17, v18, 0x7fff                           // 0000003F0B10: D6550011 03FE2511 00007FFF
	s_cbranch_vccnz 276                                        // 0000003F0B1C: BFA40114 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb1ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3170>
	v_or_b32_e32 v18, 64, v3                                   // 0000003F0B20: 382406C0
	v_lshrrev_b32_e32 v19, 23, v11                             // 0000003F0B24: 32261697
	v_mov_b32_e32 v21, s15                                     // 0000003F0B28: 7E2A020F
	v_mov_b32_e32 v23, s14                                     // 0000003F0B2C: 7E2E020E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F0B30: BF870093
	v_add_nc_u32_e32 v19, v18, v19                             // 0000003F0B34: 4A262712
	v_and_b32_e32 v20, 0xfffffe00, v19                         // 0000003F0B38: 362826FF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F0B40: BF870091
	v_sub_nc_u32_e32 v20, v18, v20                             // 0000003F0B44: 4C282912
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v20                        // 0000003F0B48: 7C8828FF 00000100
	v_add_nc_u32_e32 v22, 0xffffff00, v20                      // 0000003F0B50: 4A2C28FF FFFFFF00
	v_cndmask_b32_e32 v24, s25, v21, vcc_lo                    // 0000003F0B58: 02302A19
	v_ashrrev_i32_e32 v19, 9, v19                              // 0000003F0B5C: 34262689
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003F0B60: BF8701A3
	v_cndmask_b32_e32 v20, v22, v20, vcc_lo                    // 0000003F0B64: 02282916
	v_cndmask_b32_e32 v22, s24, v23, vcc_lo                    // 0000003F0B68: 022C2E18
	v_lshlrev_b32_e32 v18, 8, v19                              // 0000003F0B6C: 30242688
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003F0B70: BF870193
	v_ashrrev_i32_e32 v21, 31, v20                             // 0000003F0B74: 342A289F
	.long 0xd7006a16                                           // 0000003F0B78: D7006A16
	v_cndmask_b32_e32 v1, v22, v4, vcc_lo                      // 0000003F0B7C: 02020916
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003F0B80: BF870211
	v_add_co_ci_u32_e64 v23, null, v24, v5, vcc_lo             // 0000003F0B84: D5207C17 01AA0B18
	v_ashrrev_i32_e32 v19, 31, v18                             // 0000003F0B8C: 3426249F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003F0B90: BF870114
	.long 0xd73c0014                                           // 0000003F0B94: D73C0014
	v_cndmask_b32_e32 v1, 1, v20, vcc_lo                       // 0000003F0B98: 02022881
	.long 0xd73c0012                                           // 0000003F0B9C: D73C0012
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 0000003F0BA0: 02022481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F0BA4: BF870091
	.long 0xd7006a12                                           // 0000003F0BA8: D7006A12
	v_cndmask_b32_e32 v1, v22, v18, vcc_lo                     // 0000003F0BAC: 02022516
	v_add_co_ci_u32_e64 v19, null, v23, v19, vcc_lo            // 0000003F0BB0: D5207C13 01AA2717
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F0BB8: BF870092
	.long 0xd7006a12                                           // 0000003F0BBC: D7006A12
	v_cndmask_b32_e32 v1, v18, v20, vcc_lo                     // 0000003F0BC0: 02022912
	v_add_co_ci_u32_e64 v19, null, v19, v21, vcc_lo            // 0000003F0BC4: D5207C13 01AA2B13
	global_store_d16_hi_b16 v[18:19], v17, off                 // 0000003F0BCC: DC960000 007C1112
	s_cbranch_execnz 7                                         // 0000003F0BD4: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb1ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2df4>
	.long 0xd7006a12                                           // 0000003F0BD8: D7006A12
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 0000003F0BDC: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003F0BE0: BF870001
	v_add_co_ci_u32_e64 v19, null, v8, v2, vcc_lo              // 0000003F0BE4: D5207C13 01AA0508
	global_store_d16_hi_b16 v[18:19], v17, off offset:128      // 0000003F0BEC: DC960080 007C1112
	global_load_d16_b16 v17, v[6:7], off offset:160            // 0000003F0BF4: DC8200A0 117C0006
	v_cndmask_b32_e64 v15, -v15, v15, s0                       // 0000003F0BFC: D501000F 20021F0F
	v_cmp_ne_u32_e32 vcc_lo, 1, v14                            // 0000003F0C04: 7C9A1C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003F0C08: BF8700A2
	v_add_f32_e32 v15, v15, v16                                // 0000003F0C0C: 061E210F
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 0000003F0C10: 8B6A6A7E
	v_mul_f32_e32 v15, 0x3db504f3, v15                         // 0000003F0C14: 101E1EFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 0000003F0C1C: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F0C20: BF870091
	v_fma_mix_f32 v15, v17, v15, neg(0) op_sel_hi:[1,0,0]      // 0000003F0C24: CC20000F 8A021F11
	v_bfe_u32 v16, v15, 16, 1                                  // 0000003F0C2C: D6100010 0205210F
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003F0C34: BF870001
	v_add3_u32 v15, v15, v16, 0x7fff                           // 0000003F0C38: D655000F 03FE210F 00007FFF
	s_cbranch_vccnz 203                                        // 0000003F0C44: BFA400CB <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb1ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3174>
	v_or_b32_e32 v16, 0x50, v3                                 // 0000003F0C48: 382006FF 00000050
	v_lshrrev_b32_e32 v17, 23, v11                             // 0000003F0C50: 32221697
	v_mov_b32_e32 v19, s15                                     // 0000003F0C54: 7E26020F
	v_mov_b32_e32 v21, s14                                     // 0000003F0C58: 7E2A020E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F0C5C: BF870093
	v_add_nc_u32_e32 v17, v16, v17                             // 0000003F0C60: 4A222310
	v_and_b32_e32 v18, 0xfffffe00, v17                         // 0000003F0C64: 362422FF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F0C6C: BF870091
	v_sub_nc_u32_e32 v18, v16, v18                             // 0000003F0C70: 4C242510
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v18                        // 0000003F0C74: 7C8824FF 00000100
	v_add_nc_u32_e32 v20, 0xffffff00, v18                      // 0000003F0C7C: 4A2824FF FFFFFF00
	v_cndmask_b32_e32 v22, s25, v19, vcc_lo                    // 0000003F0C84: 022C2619
	v_ashrrev_i32_e32 v17, 9, v17                              // 0000003F0C88: 34222289
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003F0C8C: BF8701A3
	v_cndmask_b32_e32 v18, v20, v18, vcc_lo                    // 0000003F0C90: 02242514
	v_cndmask_b32_e32 v20, s24, v21, vcc_lo                    // 0000003F0C94: 02282A18
	v_lshlrev_b32_e32 v16, 8, v17                              // 0000003F0C98: 30202288
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003F0C9C: BF870193
	v_ashrrev_i32_e32 v19, 31, v18                             // 0000003F0CA0: 3426249F
	.long 0xd7006a14                                           // 0000003F0CA4: D7006A14
	v_cndmask_b32_e32 v1, v20, v4, vcc_lo                      // 0000003F0CA8: 02020914
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003F0CAC: BF870211
	v_add_co_ci_u32_e64 v21, null, v22, v5, vcc_lo             // 0000003F0CB0: D5207C15 01AA0B16
	v_ashrrev_i32_e32 v17, 31, v16                             // 0000003F0CB8: 3422209F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003F0CBC: BF870114
	.long 0xd73c0012                                           // 0000003F0CC0: D73C0012
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 0000003F0CC4: 02022481
	.long 0xd73c0010                                           // 0000003F0CC8: D73C0010
	v_cndmask_b32_e32 v1, 1, v16, vcc_lo                       // 0000003F0CCC: 02022081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F0CD0: BF870091
	.long 0xd7006a10                                           // 0000003F0CD4: D7006A10
	v_cndmask_b32_e32 v1, v20, v16, vcc_lo                     // 0000003F0CD8: 02022114
	v_add_co_ci_u32_e64 v17, null, v21, v17, vcc_lo            // 0000003F0CDC: D5207C11 01AA2315
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F0CE4: BF870092
	.long 0xd7006a10                                           // 0000003F0CE8: D7006A10
	v_cndmask_b32_e32 v1, v16, v18, vcc_lo                     // 0000003F0CEC: 02022510
	v_add_co_ci_u32_e64 v17, null, v17, v19, vcc_lo            // 0000003F0CF0: D5207C11 01AA2711
	global_store_d16_hi_b16 v[16:17], v15, off                 // 0000003F0CF8: DC960000 007C0F10
	s_cbranch_execnz 7                                         // 0000003F0D00: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb1ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2f20>
	.long 0xd7006a10                                           // 0000003F0D04: D7006A10
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 0000003F0D08: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003F0D0C: BF870001
	v_add_co_ci_u32_e64 v17, null, v8, v2, vcc_lo              // 0000003F0D10: D5207C11 01AA0508
	global_store_d16_hi_b16 v[16:17], v15, off offset:160      // 0000003F0D18: DC9600A0 007C0F10
	global_load_d16_b16 v15, v[6:7], off offset:192            // 0000003F0D20: DC8200C0 0F7C0006
	v_cndmask_b32_e64 v12, -v12, v12, s0                       // 0000003F0D28: D501000C 2002190C
	v_cmp_ne_u32_e32 vcc_lo, 1, v14                            // 0000003F0D30: 7C9A1C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003F0D34: BF8700A2
	v_add_f32_e32 v12, v12, v13                                // 0000003F0D38: 06181B0C
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 0000003F0D3C: 8B6A6A7E
	v_mul_f32_e32 v12, 0x3db504f3, v12                         // 0000003F0D40: 101818FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 0000003F0D48: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F0D4C: BF870091
	v_fma_mix_f32 v12, v15, v12, neg(0) op_sel_hi:[1,0,0]      // 0000003F0D50: CC20000C 8A02190F
	v_bfe_u32 v13, v12, 16, 1                                  // 0000003F0D58: D610000D 0205210C
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003F0D60: BF870001
	v_add3_u32 v12, v12, v13, 0x7fff                           // 0000003F0D64: D655000C 03FE1B0C 00007FFF
	s_cbranch_vccnz 129                                        // 0000003F0D70: BFA40081 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb1ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3178>
	v_or_b32_e32 v13, 0x60, v3                                 // 0000003F0D74: 381A06FF 00000060
	v_lshrrev_b32_e32 v15, 23, v11                             // 0000003F0D7C: 321E1697
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F0D80: BF870091
	v_dual_mov_b32 v18, s14 :: v_dual_add_nc_u32 v15, v13, v15 // 0000003F0D84: CA20000E 120E1F0D
	v_and_b32_e32 v16, 0xfffffe00, v15                         // 0000003F0D8C: 36201EFF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000003F0D94: BF8701B1
	v_sub_nc_u32_e32 v13, v13, v16                             // 0000003F0D98: 4C1A210D
	v_mov_b32_e32 v16, s15                                     // 0000003F0D9C: 7E20020F
	v_ashrrev_i32_e32 v15, 9, v15                              // 0000003F0DA0: 341E1E89
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v13                        // 0000003F0DA4: 7C881AFF 00000100
	v_add_nc_u32_e32 v17, 0xffffff00, v13                      // 0000003F0DAC: 4A221AFF FFFFFF00
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003F0DB4: BF8701A3
	v_lshlrev_b32_e32 v15, 8, v15                              // 0000003F0DB8: 301E1E88
	v_cndmask_b32_e32 v19, s25, v16, vcc_lo                    // 0000003F0DBC: 02262019
	v_cndmask_b32_e32 v17, v17, v13, vcc_lo                    // 0000003F0DC0: 02221B11
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003F0DC4: BF8701A3
	v_ashrrev_i32_e32 v16, 31, v15                             // 0000003F0DC8: 34201E9F
	v_cndmask_b32_e32 v13, s24, v18, vcc_lo                    // 0000003F0DCC: 021A2418
	v_ashrrev_i32_e32 v18, 31, v17                             // 0000003F0DD0: 3424229F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003F0DD4: BF870193
	.long 0xd73c000f                                           // 0000003F0DD8: D73C000F
	v_cndmask_b32_e32 v1, 1, v15, vcc_lo                       // 0000003F0DDC: 02021E81
	.long 0xd7006a0d                                           // 0000003F0DE0: D7006A0D
	v_cndmask_b32_e32 v1, v13, v4, vcc_lo                      // 0000003F0DE4: 0202090D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003F0DE8: BF870211
	v_add_co_ci_u32_e64 v19, null, v19, v5, vcc_lo             // 0000003F0DEC: D5207C13 01AA0B13
	.long 0xd73c0011                                           // 0000003F0DF4: D73C0011
	v_cndmask_b32_e32 v1, 1, v17, vcc_lo                       // 0000003F0DF8: 02022281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F0DFC: BF870093
	.long 0xd7006a0d                                           // 0000003F0E00: D7006A0D
	v_cndmask_b32_e32 v1, v13, v15, vcc_lo                     // 0000003F0E04: 02021F0D
	v_add_co_ci_u32_e64 v16, null, v19, v16, vcc_lo            // 0000003F0E08: D5207C10 01AA2113
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F0E10: BF870092
	.long 0xd7006a0f                                           // 0000003F0E14: D7006A0F
	v_cndmask_b32_e32 v1, v13, v17, vcc_lo                     // 0000003F0E18: 0202230D
	v_add_co_ci_u32_e64 v16, null, v16, v18, vcc_lo            // 0000003F0E1C: D5207C10 01AA2510
	global_store_d16_hi_b16 v[15:16], v12, off                 // 0000003F0E24: DC960000 007C0C0F
	s_cbranch_execnz 7                                         // 0000003F0E2C: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb1ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x304c>
	.long 0xd7006a0f                                           // 0000003F0E30: D7006A0F
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 0000003F0E34: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003F0E38: BF870001
	v_add_co_ci_u32_e64 v16, null, v8, v2, vcc_lo              // 0000003F0E3C: D5207C10 01AA0508
	global_store_d16_hi_b16 v[15:16], v12, off offset:192      // 0000003F0E44: DC9600C0 007C0C0F
	global_load_d16_b16 v6, v[6:7], off offset:224             // 0000003F0E4C: DC8200E0 067C0006
	v_cndmask_b32_e64 v7, -v9, v9, s0                          // 0000003F0E54: D5010007 20021309
	v_cmp_ne_u32_e32 vcc_lo, 1, v14                            // 0000003F0E5C: 7C9A1C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003F0E60: BF8700A2
	v_add_f32_e32 v7, v7, v10                                  // 0000003F0E64: 060E1507
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 0000003F0E68: 8B6A6A7E
	v_mul_f32_e32 v7, 0x3db504f3, v7                           // 0000003F0E6C: 100E0EFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 0000003F0E74: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F0E78: BF870091
	v_fma_mix_f32 v6, v6, v7, neg(0) op_sel_hi:[1,0,0]         // 0000003F0E7C: CC200006 8A020F06
	v_bfe_u32 v7, v6, 16, 1                                    // 0000003F0E84: D6100007 02052106
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003F0E8C: BF870001
	v_add3_u32 v6, v6, v7, 0x7fff                              // 0000003F0E90: D6550006 03FE0F06 00007FFF
	s_cbranch_vccnz 55                                         // 0000003F0E9C: BFA40037 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb1ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x317c>
	v_or_b32_e32 v3, 0x70, v3                                  // 0000003F0EA0: 380606FF 00000070
	v_lshrrev_b32_e32 v7, 23, v11                              // 0000003F0EA8: 320E1697
	v_mov_b32_e32 v10, s15                                     // 0000003F0EAC: 7E14020F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F0EB0: BF870092
	v_dual_mov_b32 v12, s14 :: v_dual_add_nc_u32 v7, v3, v7    // 0000003F0EB4: CA20000E 0C060F03
	v_and_b32_e32 v9, 0xfffffe00, v7                           // 0000003F0EBC: 36120EFF FFFFFE00
	v_ashrrev_i32_e32 v7, 9, v7                                // 0000003F0EC4: 340E0E89
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003F0EC8: BF870112
	v_sub_nc_u32_e32 v3, v3, v9                                // 0000003F0ECC: 4C061303
	v_lshlrev_b32_e32 v9, 8, v7                                // 0000003F0ED0: 30120E88
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000003F0ED4: BF870232
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v3                         // 0000003F0ED8: 7C8806FF 00000100
	v_add_nc_u32_e32 v7, 0xffffff00, v3                        // 0000003F0EE0: 4A0E06FF FFFFFF00
	v_cndmask_b32_e32 v13, s25, v10, vcc_lo                    // 0000003F0EE8: 021A1419
	v_ashrrev_i32_e32 v10, 31, v9                              // 0000003F0EEC: 3414129F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003F0EF0: BF8701A3
	v_cndmask_b32_e32 v11, v7, v3, vcc_lo                      // 0000003F0EF4: 02160707
	v_cndmask_b32_e32 v3, s24, v12, vcc_lo                     // 0000003F0EF8: 02061818
	.long 0xd73c0009                                           // 0000003F0EFC: D73C0009
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 0000003F0F00: 02021281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003F0F04: BF870193
	v_ashrrev_i32_e32 v12, 31, v11                             // 0000003F0F08: 3418169F
	.long 0xd7006a07                                           // 0000003F0F0C: D7006A07
	v_cndmask_b32_e32 v1, v3, v4, vcc_lo                       // 0000003F0F10: 02020903
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003F0F14: BF870191
	v_add_co_ci_u32_e64 v5, null, v13, v5, vcc_lo              // 0000003F0F18: D5207C05 01AA0B0D
	.long 0xd73c0003                                           // 0000003F0F20: D73C0003
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 0000003F0F24: 02021681
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F0F28: BF870093
	.long 0xd7006a07                                           // 0000003F0F2C: D7006A07
	v_cndmask_b32_e32 v1, v7, v9, vcc_lo                       // 0000003F0F30: 02021307
	v_add_co_ci_u32_e64 v5, null, v5, v10, vcc_lo              // 0000003F0F34: D5207C05 01AA1505
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003F0F3C: BF870092
	.long 0xd7006a03                                           // 0000003F0F40: D7006A03
	v_cndmask_b32_e32 v1, v7, v3, vcc_lo                       // 0000003F0F44: 02020707
	v_add_co_ci_u32_e64 v4, null, v5, v4, vcc_lo               // 0000003F0F48: D5207C04 01AA0905
	global_store_d16_hi_b16 v[3:4], v6, off                    // 0000003F0F50: DC960000 007C0603
	s_cbranch_execnz 62628                                     // 0000003F0F58: BFA6F4A4 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb1ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	s_branch 7                                                 // 0000003F0F5C: BFA00007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb1ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x317c>
	s_branch 65012                                             // 0000003F0F60: BFA0FDF4 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb1ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2934>
	s_branch 65086                                             // 0000003F0F64: BFA0FE3E <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb1ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2a60>
	s_branch 65159                                             // 0000003F0F68: BFA0FE87 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb1ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2b88>
	s_branch 65232                                             // 0000003F0F6C: BFA0FED0 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb1ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2cb0>
	s_branch 65305                                             // 0000003F0F70: BFA0FF19 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb1ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2dd8>
	s_branch 65379                                             // 0000003F0F74: BFA0FF63 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb1ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2f04>
	s_branch 65453                                             // 0000003F0F78: BFA0FFAD <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb1ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3030>
	.long 0xd7006a00                                           // 0000003F0F7C: D7006A00
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 0000003F0F80: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003F0F84: BF870001
	v_add_co_ci_u32_e64 v1, null, v8, v2, vcc_lo               // 0000003F0F88: D5207C01 01AA0508
	global_store_d16_hi_b16 v[0:1], v6, off offset:224         // 0000003F0F90: DC9600E0 007C0600
	s_nop 0                                                    // 0000003F0F98: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000003F0F9C: BFB60003
	s_endpgm                                                   // 0000003F0FA0: BFB00000
		...

