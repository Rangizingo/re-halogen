00000000008c8000 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[8:23], s[0:1], null                          // 0000008C8000: F4100200 F8000000
	s_ashr_i32 s3, s2, 31                                      // 0000008C8008: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 0000008C800C: 32040082
	v_lshrrev_b32_e32 v29, 5, v0                               // 0000008C8010: 323A0085
	v_and_b32_e32 v30, 31, v0                                  // 0000008C8014: 363C009F
	.long 0x7f0a3880                                           // 0000008C8018: 7F0A3880
	v_lshlrev_b32_e32 v28, 2, v0                               // 0000008C801C: 30380082
	s_waitcnt lgkmcnt(0)                                       // 0000008C8020: BF89FC07
	.long 0xd4510004                                           // 0000008C8024: D4510004
	v_cndmask_b32_e32 v0, s2, v16, vcc_lo                      // 0000008C8028: 02002002
	s_and_b32 s4, s4, exec_lo                                  // 0000008C802C: 8B047E04
	s_cselect_b32 s6, s3, 0                                    // 0000008C8030: 98068003
	s_cselect_b32 s7, s2, 0                                    // 0000008C8034: 98078002
	s_add_u32 s4, s8, s20                                      // 0000008C8038: 80041408
	s_addc_u32 s5, s9, s21                                     // 0000008C803C: 82051509
	v_and_b32_e32 v1, 15, v0                                   // 0000008C8040: 3602008F
	v_and_b32_e32 v2, 60, v2                                   // 0000008C8044: 360404BC
	s_ashr_i32 s20, s15, 31                                    // 0000008C8048: 86149F0F
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008C804C: BF870119
	s_lshr_b32 s20, s20, 27                                    // 0000008C8050: 85149B14
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000008C8054: 30020282
	s_add_u32 s20, s14, s20                                    // 0000008C8058: 8014140E
	s_clause 0x1                                               // 0000008C805C: BF850001
	global_load_b32 v3, v1, s[8:9]                             // 0000008C8060: DC520000 03080001
	global_load_b32 v4, v2, s[8:9]                             // 0000008C8068: DC520000 04080002
	s_addc_u32 s21, s15, 0                                     // 0000008C8070: 8215800F
	v_mov_b32_e32 v1, s4                                       // 0000008C8074: 7E020204
	s_lshr_b64 s[20:21], s[20:21], 5                           // 0000008C8078: 85948514
	v_mov_b32_e32 v2, s5                                       // 0000008C807C: 7E040205
	s_add_i32 s21, s20, 7                                      // 0000008C8080: 81158714
	s_mul_i32 s5, s23, s7                                      // 0000008C8084: 96050717
	s_ashr_i32 s24, s21, 31                                    // 0000008C8088: 86189F15
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000008C808C: BF8704B9
	s_lshr_b32 s4, s24, 29                                     // 0000008C8090: 85049D18
	v_mad_u64_u32 v[24:25], null, s22, s7, v[1:2]              // 0000008C8094: D6FE7C18 04040E16
	s_add_i32 s21, s21, s4                                     // 0000008C809C: 81150415
	s_ashr_i32 s4, s21, 3                                      // 0000008C80A0: 86048315
	s_cmpk_lt_i32 s20, 0x801                                   // 0000008C80A4: B3940801
	.long 0xd72c0001                                           // 0000008C80A8: D72C0001
	v_cndmask_b32_e32 v1, s4, v29, vcc_lo                      // 0000008C80AC: 02023A04
	s_mul_i32 s21, s22, s6                                     // 0000008C80B0: 96150616
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000008C80B4: BF870141
	v_add_nc_u32_e32 v7, s4, v1                                // 0000008C80B8: 4A0E0204
	v_add_nc_u32_e32 v31, v1, v30                              // 0000008C80BC: 4A3E3D01
	s_cselect_b32 s4, -1, 0                                    // 0000008C80C0: 980480C1
	s_cmpk_gt_i32 s20, 0x800                                   // 0000008C80C4: B2940800
	v_min_i32_e32 v32, s20, v7                                 // 0000008C80C8: 22400E14
	s_cselect_b32 s20, -1, 0                                   // 0000008C80CC: 981480C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000008C80D0: BF870159
	s_and_b32 vcc_lo, exec_lo, s20                             // 0000008C80D4: 8B6A147E
	s_waitcnt vmcnt(1)                                         // 0000008C80D8: BF8907F7
	v_bfe_u32 v2, v3, 16, 1                                    // 0000008C80DC: D6100002 02052103
	s_waitcnt vmcnt(0)                                         // 0000008C80E4: BF8903F7
	v_bfe_u32 v6, v4, 16, 1                                    // 0000008C80E8: D6100006 02052104
	v_add3_u32 v2, v3, v2, 0x7fff                              // 0000008C80F0: D6550002 03FE0503 00007FFF
	v_add_nc_u32_e32 v3, s5, v25                               // 0000008C80FC: 4A063205
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000008C8100: BF870223
	v_add3_u32 v4, v4, v6, 0x7fff                              // 0000008C8104: D6550004 03FE0D04 00007FFF
	.long 0xd4410005                                           // 0000008C8110: D4410005
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 0000008C8114: 0202411F
	.long 0x7e0a3982                                           // 0000008C8118: 7E0A3982
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008C811C: BF870114
	v_add_nc_u32_e32 v33, s21, v3                              // 0000008C8120: 4A420615
	v_and_or_b32 v1, 0xffff0000, v4, v5                        // 0000008C8124: D6570001 041608FF FFFF0000
	ds_store_b32 v28, v1                                       // 0000008C8130: D8340000 0000011C
	s_waitcnt lgkmcnt(0)                                       // 0000008C8138: BF89FC07
	s_barrier                                                  // 0000008C813C: BFBD0000
	buffer_gl0_inv                                             // 0000008C8140: E0AC0000 00000000
	s_cbranch_vccnz 154                                        // 0000008C8148: BFA4009A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x3b4>
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v8, 0               // 0000008C814C: CA100080 09080080
	s_and_saveexec_b32 s21, s5                                 // 0000008C8154: BE952005
	s_cbranch_execz 11                                         // 0000008C8158: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x188>
	v_lshlrev_b32_e32 v1, 1, v31                               // 0000008C815C: 30023E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C8160: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000008C8164: 3404029F
	.long 0xd7006a01                                           // 0000008C8168: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 0000008C816C: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 0000008C8170: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 0000008C8178: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000008C8180: BF8903F7
	v_cvt_f32_f16_e32 v8, v1                                   // 0000008C8184: 7E101701
	s_or_b32 exec_lo, exec_lo, s21                             // 0000008C8188: 8C7E157E
	v_add_nc_u32_e32 v1, 32, v31                               // 0000008C818C: 4A023EA0
	s_mov_b32 s5, exec_lo                                      // 0000008C8190: BE85007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008C8194: BF870001
	.long 0xd4c1007e                                           // 0000008C8198: D4C1007E
	v_cndmask_b32_e32 v1, v1, v32, vcc_lo                      // 0000008C819C: 02024101
	s_cbranch_execz 11                                         // 0000008C81A0: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x1d0>
	v_lshlrev_b32_e32 v1, 1, v1                                // 0000008C81A4: 30020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C81A8: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000008C81AC: 3404029F
	.long 0xd7006a01                                           // 0000008C81B0: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 0000008C81B4: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 0000008C81B8: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 0000008C81C0: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000008C81C8: BF8903F7
	v_cvt_f32_f16_e32 v9, v1                                   // 0000008C81CC: 7E121701
	s_or_b32 exec_lo, exec_lo, s5                              // 0000008C81D0: 8C7E057E
	v_dual_mov_b32 v10, 0 :: v_dual_add_nc_u32 v1, 64, v31     // 0000008C81D4: CA200080 0A003EC0
	v_mov_b32_e32 v11, 0                                       // 0000008C81DC: 7E160280
	s_mov_b32 s5, exec_lo                                      // 0000008C81E0: BE85007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008C81E4: BF870002
	.long 0xd4c1007e                                           // 0000008C81E8: D4C1007E
	v_cndmask_b32_e32 v1, v1, v32, vcc_lo                      // 0000008C81EC: 02024101
	s_cbranch_execz 11                                         // 0000008C81F0: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x220>
	v_lshlrev_b32_e32 v1, 1, v1                                // 0000008C81F4: 30020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C81F8: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000008C81FC: 3404029F
	.long 0xd7006a01                                           // 0000008C8200: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 0000008C8204: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 0000008C8208: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 0000008C8210: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000008C8218: BF8903F7
	v_cvt_f32_f16_e32 v10, v1                                  // 0000008C821C: 7E141701
	s_or_b32 exec_lo, exec_lo, s5                              // 0000008C8220: 8C7E057E
	v_add_nc_u32_e32 v1, 0x60, v31                             // 0000008C8224: 4A023EFF 00000060
	s_mov_b32 s5, exec_lo                                      // 0000008C822C: BE85007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008C8230: BF870001
	.long 0xd4c1007e                                           // 0000008C8234: D4C1007E
	v_cndmask_b32_e32 v1, v1, v32, vcc_lo                      // 0000008C8238: 02024101
	s_cbranch_execz 11                                         // 0000008C823C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x26c>
	v_lshlrev_b32_e32 v1, 1, v1                                // 0000008C8240: 30020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C8244: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000008C8248: 3404029F
	.long 0xd7006a01                                           // 0000008C824C: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 0000008C8250: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 0000008C8254: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 0000008C825C: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000008C8264: BF8903F7
	v_cvt_f32_f16_e32 v11, v1                                  // 0000008C8268: 7E161701
	s_or_b32 exec_lo, exec_lo, s5                              // 0000008C826C: 8C7E057E
	v_dual_mov_b32 v12, 0 :: v_dual_add_nc_u32 v1, 0x80, v31   // 0000008C8270: CA200080 0C003EFF 00000080
	v_mov_b32_e32 v13, 0                                       // 0000008C827C: 7E1A0280
	s_mov_b32 s5, exec_lo                                      // 0000008C8280: BE85007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008C8284: BF870002
	.long 0xd4c1007e                                           // 0000008C8288: D4C1007E
	v_cndmask_b32_e32 v1, v1, v32, vcc_lo                      // 0000008C828C: 02024101
	s_cbranch_execz 11                                         // 0000008C8290: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x2c0>
	v_lshlrev_b32_e32 v1, 1, v1                                // 0000008C8294: 30020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C8298: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000008C829C: 3404029F
	.long 0xd7006a01                                           // 0000008C82A0: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 0000008C82A4: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 0000008C82A8: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 0000008C82B0: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000008C82B8: BF8903F7
	v_cvt_f32_f16_e32 v12, v1                                  // 0000008C82BC: 7E181701
	s_or_b32 exec_lo, exec_lo, s5                              // 0000008C82C0: 8C7E057E
	v_add_nc_u32_e32 v1, 0xa0, v31                             // 0000008C82C4: 4A023EFF 000000A0
	s_mov_b32 s5, exec_lo                                      // 0000008C82CC: BE85007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008C82D0: BF870001
	.long 0xd4c1007e                                           // 0000008C82D4: D4C1007E
	v_cndmask_b32_e32 v1, v1, v32, vcc_lo                      // 0000008C82D8: 02024101
	s_cbranch_execz 11                                         // 0000008C82DC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x30c>
	v_lshlrev_b32_e32 v1, 1, v1                                // 0000008C82E0: 30020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C82E4: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000008C82E8: 3404029F
	.long 0xd7006a01                                           // 0000008C82EC: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 0000008C82F0: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 0000008C82F4: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 0000008C82FC: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000008C8304: BF8903F7
	v_cvt_f32_f16_e32 v13, v1                                  // 0000008C8308: 7E1A1701
	s_or_b32 exec_lo, exec_lo, s5                              // 0000008C830C: 8C7E057E
	v_dual_mov_b32 v14, 0 :: v_dual_add_nc_u32 v1, 0xc0, v31   // 0000008C8310: CA200080 0E003EFF 000000C0
	v_mov_b32_e32 v15, 0                                       // 0000008C831C: 7E1E0280
	s_mov_b32 s5, exec_lo                                      // 0000008C8320: BE85007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008C8324: BF870002
	.long 0xd4c1007e                                           // 0000008C8328: D4C1007E
	v_cndmask_b32_e32 v1, v1, v32, vcc_lo                      // 0000008C832C: 02024101
	s_cbranch_execz 11                                         // 0000008C8330: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x360>
	v_lshlrev_b32_e32 v1, 1, v1                                // 0000008C8334: 30020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C8338: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000008C833C: 3404029F
	.long 0xd7006a01                                           // 0000008C8340: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 0000008C8344: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 0000008C8348: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 0000008C8350: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000008C8358: BF8903F7
	v_cvt_f32_f16_e32 v14, v1                                  // 0000008C835C: 7E1C1701
	s_or_b32 exec_lo, exec_lo, s5                              // 0000008C8360: 8C7E057E
	v_add_nc_u32_e32 v1, 0xe0, v31                             // 0000008C8364: 4A023EFF 000000E0
	s_mov_b32 s5, exec_lo                                      // 0000008C836C: BE85007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008C8370: BF870001
	.long 0xd4c1007e                                           // 0000008C8374: D4C1007E
	v_cndmask_b32_e32 v1, v1, v32, vcc_lo                      // 0000008C8378: 02024101
	s_cbranch_execz 11                                         // 0000008C837C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x3ac>
	v_lshlrev_b32_e32 v1, 1, v1                                // 0000008C8380: 30020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C8384: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000008C8388: 3404029F
	.long 0xd7006a01                                           // 0000008C838C: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 0000008C8390: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 0000008C8394: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 0000008C839C: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000008C83A4: BF8903F7
	v_cvt_f32_f16_e32 v15, v1                                  // 0000008C83A8: 7E1E1701
	s_or_b32 exec_lo, exec_lo, s5                              // 0000008C83AC: 8C7E057E
	s_branch 9                                                 // 0000008C83B0: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x3d8>
	v_mov_b32_e32 v8, 0                                        // 0000008C83B4: 7E100280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008C83B8: BF870001
	v_mov_b32_e32 v9, v8                                       // 0000008C83BC: 7E120308
	v_mov_b32_e32 v10, v8                                      // 0000008C83C0: 7E140308
	v_mov_b32_e32 v11, v8                                      // 0000008C83C4: 7E160308
	v_mov_b32_e32 v12, v8                                      // 0000008C83C8: 7E180308
	v_mov_b32_e32 v13, v8                                      // 0000008C83CC: 7E1A0308
	v_mov_b32_e32 v14, v8                                      // 0000008C83D0: 7E1C0308
	v_mov_b32_e32 v15, v8                                      // 0000008C83D4: 7E1E0308
	s_add_u32 s8, s8, s18                                      // 0000008C83D8: 80081208
	s_addc_u32 s9, s9, s19                                     // 0000008C83DC: 82091309
	s_lshr_b32 s5, s15, 31                                     // 0000008C83E0: 85059F0F
	v_dual_mov_b32 v1, s7 :: v_dual_mov_b32 v20, 0             // 0000008C83E4: CA100007 01140080
	s_add_u32 s18, s14, s5                                     // 0000008C83EC: 8012050E
	s_addc_u32 s19, s15, 0                                     // 0000008C83F0: 8213800F
	.long 0xd4410005                                           // 0000008C83F4: D4410005
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 0000008C83F8: 0202411F
	s_ashr_i64 s[18:19], s[18:19], 1                           // 0000008C83FC: 86928112
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v27, 0             // 0000008C8400: CA100080 221A0080
	v_mad_u64_u32 v[25:26], null, v1, s18, s[8:9]              // 0000008C8408: D6FE7C19 00202501
	.long 0xd72c0001                                           // 0000008C8410: D72C0001
	v_cndmask_b32_e32 v0, s7, v19, vcc_lo                      // 0000008C8414: 02002607
	.long 0xd72c0002                                           // 0000008C8418: D72C0002
	v_cndmask_b32_e32 v0, s6, v18, vcc_lo                      // 0000008C841C: 02002406
	v_cndmask_b32_e64 v35, 0, 1, s20                           // 0000008C8420: D5010023 00510280
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v22, 0             // 0000008C8428: CA100080 15160080
	v_mov_b32_e32 v23, 0                                       // 0000008C8430: 7E2E0280
	s_delay_alu instid0(VALU_DEP_4)                            // 0000008C8434: BF870004
	v_add3_u32 v36, v2, v26, v1                                // 0000008C8438: D6550024 04063502
	s_and_saveexec_b32 s6, s5                                  // 0000008C8440: BE862005
	s_cbranch_execz 22                                         // 0000008C8444: BFA50016 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x4a0>
	v_lshlrev_b32_e32 v1, 4, v31                               // 0000008C8448: 30023E84
	v_mov_b32_e32 v27, 0                                       // 0000008C844C: 7E360280
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C8450: BF8700A2
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000008C8454: 3404029F
	.long 0xd7006a01                                           // 0000008C8458: D7006A01
	v_cndmask_b32_e32 v1, v25, v1, vcc_lo                      // 0000008C845C: 02020319
	v_add_co_ci_u32_e64 v2, null, v36, v2, vcc_lo              // 0000008C8460: D5207C02 01AA0524
	s_and_not1_b32 vcc_lo, exec_lo, s20                        // 0000008C8468: 916A147E
	global_load_b128 v[20:23], v[1:2], off                     // 0000008C846C: DC5E0000 147C0001
	s_cbranch_vccnz 10                                         // 0000008C8474: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x4a0>
	v_lshlrev_b32_e32 v1, 1, v31                               // 0000008C8478: 30023E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C847C: BF870091
	.long 0xd7006a01                                           // 0000008C8480: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 0000008C8484: 02020318
	v_add_co_ci_u32_e64 v2, null, 0, v33, vcc_lo               // 0000008C8488: D5207C02 01AA4280
	global_load_d16_b16 v1, v[1:2], off                        // 0000008C8490: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000008C8498: BF8903F7
	v_cvt_f32_f16_e32 v27, v1                                  // 0000008C849C: 7E361701
	s_or_b32 exec_lo, exec_lo, s6                              // 0000008C84A0: 8C7E067E
	v_dual_mov_b32 v38, 0 :: v_dual_mov_b32 v39, 0             // 0000008C84A4: CA100080 26260080
	v_dual_mov_b32 v40, 0 :: v_dual_mov_b32 v37, 0             // 0000008C84AC: CA100080 28240080
	s_and_saveexec_b32 s18, s5                                 // 0000008C84B4: BE922005
	s_cbranch_execz 490                                        // 0000008C84B8: BFA501EA <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0xc64>
	v_dual_mov_b32 v40, 0 :: v_dual_add_nc_u32 v1, 32, v31     // 0000008C84BC: CA200080 28003EA0
	v_dual_mov_b32 v37, 0 :: v_dual_lshlrev_b32 v26, 5, v31    // 0000008C84C4: CA220080 251A3E85
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v43, v27           // 0000008C84CC: CA100080 222A011B
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008C84D4: BF870003
	v_dual_mov_b32 v38, 0 :: v_dual_lshlrev_b32 v41, 4, v1     // 0000008C84D8: CA220080 26280284
	v_dual_mov_b32 v39, 0 :: v_dual_lshlrev_b32 v42, 1, v1     // 0000008C84E0: CA220080 272A0281
	s_mul_i32 s5, s15, 6                                       // 0000008C84E8: 9605860F
	s_mul_hi_u32 s8, s14, 6                                    // 0000008C84EC: 9688860E
	s_lshl_b64 s[6:7], s[14:15], 2                             // 0000008C84F0: 8486820E
	s_add_i32 s19, s8, s5                                      // 0000008C84F4: 81130508
	s_mul_i32 s21, s14, 6                                      // 0000008C84F8: 9615860E
	s_mov_b32 s20, 0                                           // 0000008C84FC: BE940080
	s_lshl_b64 s[8:9], s[14:15], 1                             // 0000008C8500: 8488810E
	s_branch 435                                               // 0000008C8504: BFA001B3 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0xbd4>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000008C8508: 8C7E0E7E
	v_cndmask_b32_e64 v54, v27, v8, s4                         // 0000008C850C: D5010036 0012111B
	v_cndmask_b32_e64 v2, v9, v10, s4                          // 0000008C8514: D5010002 00121509
	v_cndmask_b32_e64 v1, v8, v9, s4                           // 0000008C851C: D5010001 00121308
	v_dual_mov_b32 v8, v15 :: v_dual_and_b32 v9, 0xff, v20     // 0000008C8524: CA24010F 080828FF 000000FF
	v_cndmask_b32_e64 v7, v14, v15, s4                         // 0000008C8530: D5010007 00121F0E
	v_cndmask_b32_e64 v6, v13, v14, s4                         // 0000008C8538: D5010006 00121D0D
	v_cndmask_b32_e64 v5, v12, v13, s4                         // 0000008C8540: D5010005 00121B0C
	v_cndmask_b32_e64 v4, v11, v12, s4                         // 0000008C8548: D5010004 0012190B
	v_lshlrev_b32_e32 v9, 2, v9                                // 0000008C8550: 30121282
	v_cndmask_b32_e64 v3, v10, v11, s4                         // 0000008C8554: D5010003 0012170A
	v_ashrrev_i32_e32 v27, 31, v26                             // 0000008C855C: 3436349F
	v_add_nc_u32_e32 v41, 0x200, v41                           // 0000008C8560: 4A5252FF 00000200
	s_and_b32 s5, exec_lo, s5                                  // 0000008C8568: 8B05057E
	ds_load_b32 v15, v9                                        // 0000008C856C: D8D80000 0F000009
	v_lshrrev_b32_e32 v9, 6, v20                               // 0000008C8574: 32122886
	s_or_b32 s20, s5, s20                                      // 0000008C8578: 8C141405
	v_add_nc_u32_e32 v42, 64, v42                              // 0000008C857C: 4A5454C0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008C8580: BF8700B2
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000008C8584: 361212FF 000003FC
	ds_load_b32 v55, v9                                        // 0000008C858C: D8D80000 37000009
	v_lshrrev_b32_e32 v9, 14, v20                              // 0000008C8594: 3212288E
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000008C8598: 361212FF 000003FC
	ds_load_b32 v56, v9                                        // 0000008C85A0: D8D80000 38000009
	v_lshrrev_b32_e32 v9, 22, v20                              // 0000008C85A8: 32122896
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008C85AC: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000008C85B0: 361212FF 000003FC
	ds_load_b32 v57, v9                                        // 0000008C85B8: D8D80000 39000009
	v_and_b32_e32 v9, 0xff, v21                                // 0000008C85C0: 36122AFF 000000FF
	v_lshlrev_b32_e32 v9, 2, v9                                // 0000008C85C8: 30121282
	ds_load_b32 v58, v9                                        // 0000008C85CC: D8D80000 3A000009
	v_lshrrev_b32_e32 v9, 6, v21                               // 0000008C85D4: 32122A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008C85D8: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000008C85DC: 361212FF 000003FC
	ds_load_b32 v59, v9                                        // 0000008C85E4: D8D80000 3B000009
	v_lshrrev_b32_e32 v9, 14, v21                              // 0000008C85EC: 32122A8E
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000008C85F0: 361212FF 000003FC
	ds_load_b32 v60, v9                                        // 0000008C85F8: D8D80000 3C000009
	v_lshrrev_b32_e32 v9, 22, v21                              // 0000008C8600: 32122A96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008C8604: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000008C8608: 361212FF 000003FC
	ds_load_b32 v61, v9                                        // 0000008C8610: D8D80000 3D000009
	v_and_b32_e32 v9, 0xff, v22                                // 0000008C8618: 36122CFF 000000FF
	v_lshlrev_b32_e32 v9, 2, v9                                // 0000008C8620: 30121282
	ds_load_b32 v62, v9                                        // 0000008C8624: D8D80000 3E000009
	v_lshrrev_b32_e32 v9, 6, v22                               // 0000008C862C: 32122C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008C8630: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000008C8634: 361212FF 000003FC
	ds_load_b32 v63, v9                                        // 0000008C863C: D8D80000 3F000009
	v_lshrrev_b32_e32 v9, 14, v22                              // 0000008C8644: 32122C8E
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000008C8648: 361212FF 000003FC
	ds_load_b32 v64, v9                                        // 0000008C8650: D8D80000 40000009
	v_lshrrev_b32_e32 v9, 22, v22                              // 0000008C8658: 32122C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008C865C: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000008C8660: 361212FF 000003FC
	ds_load_b32 v65, v9                                        // 0000008C8668: D8D80000 41000009
	v_and_b32_e32 v9, 0xff, v23                                // 0000008C8670: 36122EFF 000000FF
	v_lshlrev_b32_e32 v9, 2, v9                                // 0000008C8678: 30121282
	ds_load_b32 v66, v9                                        // 0000008C867C: D8D80000 42000009
	v_lshrrev_b32_e32 v9, 6, v23                               // 0000008C8684: 32122E86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008C8688: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000008C868C: 361212FF 000003FC
	ds_load_b32 v67, v9                                        // 0000008C8694: D8D80000 43000009
	v_lshrrev_b32_e32 v9, 14, v23                              // 0000008C869C: 32122E8E
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000008C86A0: 361212FF 000003FC
	ds_load_b32 v68, v9                                        // 0000008C86A8: D8D80000 44000009
	v_lshrrev_b32_e32 v9, 22, v23                              // 0000008C86B0: 32122E96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000008C86B4: BF870141
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000008C86B8: 361212FF 000003FC
	ds_load_b32 v69, v9                                        // 0000008C86C0: D8D80000 45000009
	.long 0xd73c0009                                           // 0000008C86C8: D73C0009
	v_cndmask_b32_e32 v1, 1, v26, vcc_lo                       // 0000008C86CC: 02023481
	v_dual_mov_b32 v27, v43 :: v_dual_add_nc_u32 v26, 0x400, v26// 0000008C86D0: CA20012B 1B1A34FF 00000400
	.long 0xd7006a0d                                           // 0000008C86DC: D7006A0D
	v_cndmask_b32_e32 v1, s10, v9, vcc_lo                      // 0000008C86E0: 0202120A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008C86E4: BF870001
	v_add_co_ci_u32_e64 v14, null, s11, v10, vcc_lo            // 0000008C86E8: D5207C0E 01AA140B
	s_clause 0x3                                               // 0000008C86F0: BF850003
	global_load_b128 v[9:12], v[13:14], off                    // 0000008C86F4: DC5E0000 097C000D
	global_load_b128 v[20:23], v[13:14], off offset:16         // 0000008C86FC: DC5E0010 147C000D
	global_load_b128 v[44:47], v[13:14], off offset:32         // 0000008C8704: DC5E0020 2C7C000D
	global_load_b128 v[48:51], v[13:14], off offset:48         // 0000008C870C: DC5E0030 307C000D
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 0000008C8714: BF890CF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 0000008C8718: CC1A4009 1A021F09
	s_waitcnt lgkmcnt(14)                                      // 0000008C8720: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C8724: BF8700A1
	v_dot2_f32_bf16 v9, v10, v55, v9                           // 0000008C8728: CC1A4009 1C266F0A
	s_waitcnt lgkmcnt(13)                                      // 0000008C8730: BF89FCD7
	v_dot2_f32_bf16 v9, v11, v56, v9                           // 0000008C8734: CC1A4009 1C26710B
	s_waitcnt lgkmcnt(12)                                      // 0000008C873C: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C8740: BF8700A1
	v_dot2_f32_bf16 v9, v12, v57, v9                           // 0000008C8744: CC1A4009 1C26730C
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 0000008C874C: BF8908B7
	v_dot2_f32_bf16 v9, v20, v58, v9                           // 0000008C8750: CC1A4009 1C267514
	s_waitcnt lgkmcnt(10)                                      // 0000008C8758: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C875C: BF8700A1
	v_dot2_f32_bf16 v9, v21, v59, v9                           // 0000008C8760: CC1A4009 1C267715
	s_waitcnt lgkmcnt(9)                                       // 0000008C8768: BF89FC97
	v_dot2_f32_bf16 v9, v22, v60, v9                           // 0000008C876C: CC1A4009 1C267916
	s_waitcnt lgkmcnt(8)                                       // 0000008C8774: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C8778: BF8700A1
	v_dot2_f32_bf16 v9, v23, v61, v9                           // 0000008C877C: CC1A4009 1C267B17
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 0000008C8784: BF890477
	v_dot2_f32_bf16 v9, v44, v62, v9                           // 0000008C8788: CC1A4009 1C267D2C
	s_waitcnt lgkmcnt(6)                                       // 0000008C8790: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C8794: BF8700A1
	v_dot2_f32_bf16 v9, v45, v63, v9                           // 0000008C8798: CC1A4009 1C267F2D
	s_waitcnt lgkmcnt(5)                                       // 0000008C87A0: BF89FC57
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 0000008C87A4: CC1A4009 1C26812E
	s_waitcnt lgkmcnt(4)                                       // 0000008C87AC: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C87B0: BF8700A1
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 0000008C87B4: CC1A4009 1C26832F
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 0000008C87BC: BF890037
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 0000008C87C0: CC1A4009 1C268530
	.long 0xd7006a30                                           // 0000008C87C8: D7006A30
	v_cndmask_b32_e32 v0, v13, v8, vcc_lo                      // 0000008C87CC: 0200110D
	s_waitcnt lgkmcnt(2)                                       // 0000008C87D0: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000008C87D4: BF8701C2
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 0000008C87D8: CC1A4009 1C268731
	v_add_co_ci_u32_e64 v49, null, s9, v14, vcc_lo             // 0000008C87E0: D5207C31 01AA1C09
	.long 0xd7006a34                                           // 0000008C87E8: D7006A34
	v_cndmask_b32_e32 v0, v13, v6, vcc_lo                      // 0000008C87EC: 02000D0D
	s_waitcnt lgkmcnt(1)                                       // 0000008C87F0: BF89FC17
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 0000008C87F4: CC1A4009 1C268932
	v_add_co_ci_u32_e64 v53, null, s7, v14, vcc_lo             // 0000008C87FC: D5207C35 01AA1C07
	.long 0xd7006a0d                                           // 0000008C8804: D7006A0D
	v_cndmask_b32_e32 v0, v13, v21, vcc_lo                     // 0000008C8808: 02002B0D
	s_waitcnt lgkmcnt(0)                                       // 0000008C880C: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008C8810: BF870123
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 0000008C8814: CC1A4009 1C268B33
	v_add_co_ci_u32_e64 v14, null, s19, v14, vcc_lo            // 0000008C881C: D5207C0E 01AA1C13
	v_fmac_f32_e32 v37, v54, v9                                // 0000008C8824: 564A1336
	s_clause 0x3                                               // 0000008C8828: BF850003
	global_load_b128 v[9:12], v[48:49], off                    // 0000008C882C: DC5E0000 097C0030
	global_load_b128 v[20:23], v[48:49], off offset:16         // 0000008C8834: DC5E0010 147C0030
	global_load_b128 v[44:47], v[48:49], off offset:32         // 0000008C883C: DC5E0020 2C7C0030
	global_load_b128 v[48:51], v[48:49], off offset:48         // 0000008C8844: DC5E0030 307C0030
	s_waitcnt vmcnt(3)                                         // 0000008C884C: BF890FF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 0000008C8850: CC1A4009 1A021F09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C8858: BF870091
	v_dot2_f32_bf16 v9, v10, v55, v9                           // 0000008C885C: CC1A4009 1C266F0A
	v_dot2_f32_bf16 v9, v11, v56, v9                           // 0000008C8864: CC1A4009 1C26710B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C886C: BF8700A1
	v_dot2_f32_bf16 v9, v12, v57, v9                           // 0000008C8870: CC1A4009 1C26730C
	s_waitcnt vmcnt(2)                                         // 0000008C8878: BF890BF7
	v_dot2_f32_bf16 v9, v20, v58, v9                           // 0000008C887C: CC1A4009 1C267514
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C8884: BF870091
	v_dot2_f32_bf16 v9, v21, v59, v9                           // 0000008C8888: CC1A4009 1C267715
	v_dot2_f32_bf16 v9, v22, v60, v9                           // 0000008C8890: CC1A4009 1C267916
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C8898: BF8700A1
	v_dot2_f32_bf16 v9, v23, v61, v9                           // 0000008C889C: CC1A4009 1C267B17
	s_waitcnt vmcnt(1)                                         // 0000008C88A4: BF8907F7
	v_dot2_f32_bf16 v9, v44, v62, v9                           // 0000008C88A8: CC1A4009 1C267D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C88B0: BF870091
	v_dot2_f32_bf16 v9, v45, v63, v9                           // 0000008C88B4: CC1A4009 1C267F2D
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 0000008C88BC: CC1A4009 1C26812E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C88C4: BF8700A1
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 0000008C88C8: CC1A4009 1C26832F
	s_waitcnt vmcnt(0)                                         // 0000008C88D0: BF8903F7
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 0000008C88D4: CC1A4009 1C268530
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C88DC: BF870091
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 0000008C88E0: CC1A4009 1C268731
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 0000008C88E8: CC1A4009 1C268932
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C88F0: BF870091
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 0000008C88F4: CC1A4009 1C268B33
	v_fmac_f32_e32 v40, v54, v9                                // 0000008C88FC: 56501336
	s_clause 0x3                                               // 0000008C8900: BF850003
	global_load_b128 v[9:12], v[52:53], off                    // 0000008C8904: DC5E0000 097C0034
	global_load_b128 v[20:23], v[52:53], off offset:16         // 0000008C890C: DC5E0010 147C0034
	global_load_b128 v[44:47], v[52:53], off offset:32         // 0000008C8914: DC5E0020 2C7C0034
	global_load_b128 v[48:51], v[52:53], off offset:48         // 0000008C891C: DC5E0030 307C0034
	s_waitcnt vmcnt(3)                                         // 0000008C8924: BF890FF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 0000008C8928: CC1A4009 1A021F09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C8930: BF870091
	v_dot2_f32_bf16 v9, v10, v55, v9                           // 0000008C8934: CC1A4009 1C266F0A
	v_dot2_f32_bf16 v9, v11, v56, v9                           // 0000008C893C: CC1A4009 1C26710B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C8944: BF8700A1
	v_dot2_f32_bf16 v9, v12, v57, v9                           // 0000008C8948: CC1A4009 1C26730C
	s_waitcnt vmcnt(2)                                         // 0000008C8950: BF890BF7
	v_dot2_f32_bf16 v9, v20, v58, v9                           // 0000008C8954: CC1A4009 1C267514
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C895C: BF870091
	v_dot2_f32_bf16 v9, v21, v59, v9                           // 0000008C8960: CC1A4009 1C267715
	v_dot2_f32_bf16 v9, v22, v60, v9                           // 0000008C8968: CC1A4009 1C267916
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C8970: BF8700A1
	v_dot2_f32_bf16 v9, v23, v61, v9                           // 0000008C8974: CC1A4009 1C267B17
	s_waitcnt vmcnt(1)                                         // 0000008C897C: BF8907F7
	v_dot2_f32_bf16 v9, v44, v62, v9                           // 0000008C8980: CC1A4009 1C267D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C8988: BF870091
	v_dot2_f32_bf16 v9, v45, v63, v9                           // 0000008C898C: CC1A4009 1C267F2D
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 0000008C8994: CC1A4009 1C26812E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C899C: BF8700A1
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 0000008C89A0: CC1A4009 1C26832F
	s_waitcnt vmcnt(0)                                         // 0000008C89A8: BF8903F7
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 0000008C89AC: CC1A4009 1C268530
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C89B4: BF870091
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 0000008C89B8: CC1A4009 1C268731
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 0000008C89C0: CC1A4009 1C268932
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C89C8: BF870091
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 0000008C89CC: CC1A4009 1C268B33
	v_fmac_f32_e32 v39, v54, v9                                // 0000008C89D4: 564E1336
	s_clause 0x3                                               // 0000008C89D8: BF850003
	global_load_b128 v[9:12], v[13:14], off                    // 0000008C89DC: DC5E0000 097C000D
	global_load_b128 v[20:23], v[13:14], off offset:16         // 0000008C89E4: DC5E0010 147C000D
	global_load_b128 v[44:47], v[13:14], off offset:32         // 0000008C89EC: DC5E0020 2C7C000D
	global_load_b128 v[48:51], v[13:14], off offset:48         // 0000008C89F4: DC5E0030 307C000D
	.long 0xd7006a0d                                           // 0000008C89FC: D7006A0D
	v_cndmask_b32_e32 v0, v52, v6, vcc_lo                      // 0000008C8A00: 02000D34
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008C8A04: BF8700B1
	v_add_co_ci_u32_e64 v14, null, s7, v53, vcc_lo             // 0000008C8A08: D5207C0E 01AA6A07
	s_waitcnt vmcnt(3)                                         // 0000008C8A10: BF890FF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 0000008C8A14: CC1A4009 1A021F09
	v_dot2_f32_bf16 v9, v10, v55, v9                           // 0000008C8A1C: CC1A4009 1C266F0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C8A24: BF870091
	v_dot2_f32_bf16 v9, v11, v56, v9                           // 0000008C8A28: CC1A4009 1C26710B
	v_dot2_f32_bf16 v9, v12, v57, v9                           // 0000008C8A30: CC1A4009 1C26730C
	s_waitcnt vmcnt(2)                                         // 0000008C8A38: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C8A3C: BF870091
	v_dot2_f32_bf16 v9, v20, v58, v9                           // 0000008C8A40: CC1A4009 1C267514
	v_dot2_f32_bf16 v9, v21, v59, v9                           // 0000008C8A48: CC1A4009 1C267715
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C8A50: BF870091
	v_dot2_f32_bf16 v9, v22, v60, v9                           // 0000008C8A54: CC1A4009 1C267916
	v_dot2_f32_bf16 v9, v23, v61, v9                           // 0000008C8A5C: CC1A4009 1C267B17
	s_waitcnt vmcnt(1)                                         // 0000008C8A64: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C8A68: BF870091
	v_dot2_f32_bf16 v9, v44, v62, v9                           // 0000008C8A6C: CC1A4009 1C267D2C
	v_dot2_f32_bf16 v9, v45, v63, v9                           // 0000008C8A74: CC1A4009 1C267F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C8A7C: BF870091
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 0000008C8A80: CC1A4009 1C26812E
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 0000008C8A88: CC1A4009 1C26832F
	s_waitcnt vmcnt(0)                                         // 0000008C8A90: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C8A94: BF870091
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 0000008C8A98: CC1A4009 1C268530
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 0000008C8AA0: CC1A4009 1C268731
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C8AA8: BF870091
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 0000008C8AAC: CC1A4009 1C268932
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 0000008C8AB4: CC1A4009 1C268B33
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008C8ABC: BF870001
	v_fmac_f32_e32 v38, v54, v9                                // 0000008C8AC0: 564C1336
	s_clause 0x3                                               // 0000008C8AC4: BF850003
	global_load_b128 v[9:12], v[13:14], off                    // 0000008C8AC8: DC5E0000 097C000D
	global_load_b128 v[20:23], v[13:14], off offset:16         // 0000008C8AD0: DC5E0010 147C000D
	global_load_b128 v[44:47], v[13:14], off offset:32         // 0000008C8AD8: DC5E0020 2C7C000D
	global_load_b128 v[48:51], v[13:14], off offset:48         // 0000008C8AE0: DC5E0030 307C000D
	s_waitcnt vmcnt(3)                                         // 0000008C8AE8: BF890FF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 0000008C8AEC: CC1A4009 1A021F09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C8AF4: BF870091
	v_dot2_f32_bf16 v9, v10, v55, v9                           // 0000008C8AF8: CC1A4009 1C266F0A
	v_dot2_f32_bf16 v9, v11, v56, v9                           // 0000008C8B00: CC1A4009 1C26710B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C8B08: BF8700A1
	v_dot2_f32_bf16 v9, v12, v57, v9                           // 0000008C8B0C: CC1A4009 1C26730C
	s_waitcnt vmcnt(2)                                         // 0000008C8B14: BF890BF7
	v_dot2_f32_bf16 v9, v20, v58, v9                           // 0000008C8B18: CC1A4009 1C267514
	v_mov_b32_e32 v20, v16                                     // 0000008C8B20: 7E280310
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008C8B24: BF870122
	v_dot2_f32_bf16 v9, v21, v59, v9                           // 0000008C8B28: CC1A4009 1C267715
	v_mov_b32_e32 v21, v17                                     // 0000008C8B30: 7E2A0311
	v_dot2_f32_bf16 v9, v22, v60, v9                           // 0000008C8B34: CC1A4009 1C267916
	v_mov_b32_e32 v22, v18                                     // 0000008C8B3C: 7E2C0312
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000008C8B40: BF870132
	v_dot2_f32_bf16 v9, v23, v61, v9                           // 0000008C8B44: CC1A4009 1C267B17
	v_mov_b32_e32 v23, v19                                     // 0000008C8B4C: 7E2E0313
	s_waitcnt vmcnt(1)                                         // 0000008C8B50: BF8907F7
	v_dot2_f32_bf16 v9, v44, v62, v9                           // 0000008C8B54: CC1A4009 1C267D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C8B5C: BF870091
	v_dot2_f32_bf16 v9, v45, v63, v9                           // 0000008C8B60: CC1A4009 1C267F2D
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 0000008C8B68: CC1A4009 1C26812E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C8B70: BF8700A1
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 0000008C8B74: CC1A4009 1C26832F
	s_waitcnt vmcnt(0)                                         // 0000008C8B7C: BF8903F7
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 0000008C8B80: CC1A4009 1C268530
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C8B88: BF870091
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 0000008C8B8C: CC1A4009 1C268731
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 0000008C8B94: CC1A4009 1C268932
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C8B9C: BF870091
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 0000008C8BA0: CC1A4009 1C268B33
	v_dual_fmac_f32 v34, v54, v9 :: v_dual_mov_b32 v15, v8     // 0000008C8BA8: C8101336 220E0108
	v_dual_mov_b32 v14, v7 :: v_dual_mov_b32 v13, v6           // 0000008C8BB0: CA100107 0E0C0106
	v_dual_mov_b32 v12, v5 :: v_dual_mov_b32 v11, v4           // 0000008C8BB8: CA100105 0C0A0104
	v_dual_mov_b32 v10, v3 :: v_dual_mov_b32 v9, v2            // 0000008C8BC0: CA100103 0A080102
	v_mov_b32_e32 v8, v1                                       // 0000008C8BC8: 7E100301
	s_and_not1_b32 exec_lo, exec_lo, s20                       // 0000008C8BCC: 917E147E
	s_cbranch_execz 35                                         // 0000008C8BD0: BFA50023 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0xc60>
	s_waitcnt vmcnt(0)                                         // 0000008C8BD4: BF8903F7
	v_dual_mov_b32 v16, v20 :: v_dual_add_nc_u32 v31, 32, v31  // 0000008C8BD8: CA200114 101E3EA0
	v_dual_mov_b32 v17, v21 :: v_dual_mov_b32 v18, v22         // 0000008C8BE0: CA100115 11120116
	v_mov_b32_e32 v19, v23                                     // 0000008C8BE8: 7E260317
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008C8BEC: BF870003
	.long 0xd4460005                                           // 0000008C8BF0: D4460005
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 0000008C8BF4: 0202411F
	s_mov_b32 s14, exec_lo                                     // 0000008C8BF8: BE8E007E
	.long 0xd4c1007e                                           // 0000008C8BFC: D4C1007E
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 0000008C8C00: 0202411F
	s_cbranch_execz 65088                                      // 0000008C8C04: BFA5FE40 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x508>
	v_ashrrev_i32_e32 v2, 31, v41                              // 0000008C8C08: 3404529F
	.long 0xd7006a01                                           // 0000008C8C0C: D7006A01
	v_cndmask_b32_e32 v1, v25, v41, vcc_lo                     // 0000008C8C10: 02025319
	v_mov_b32_e32 v43, v27                                     // 0000008C8C14: 7E56031B
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008C8C18: BF870003
	v_add_co_ci_u32_e64 v2, null, v36, v2, vcc_lo              // 0000008C8C1C: D5207C02 01AA0524
	v_cmp_ne_u32_e32 vcc_lo, 1, v35                            // 0000008C8C24: 7C9A4681
	global_load_b128 v[16:19], v[1:2], off                     // 0000008C8C28: DC5E0000 107C0001
	s_cbranch_vccnz 65077                                      // 0000008C8C30: BFA4FE35 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x508>
	v_ashrrev_i32_e32 v2, 31, v42                              // 0000008C8C34: 3404549F
	.long 0xd7006a01                                           // 0000008C8C38: D7006A01
	v_cndmask_b32_e32 v1, v24, v42, vcc_lo                     // 0000008C8C3C: 02025518
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008C8C40: BF870001
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 0000008C8C44: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 0000008C8C4C: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000008C8C54: BF8903F7
	v_cvt_f32_f16_e32 v43, v1                                  // 0000008C8C58: 7E561701
	s_branch 65066                                             // 0000008C8C5C: BFA0FE2A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x508>
	s_or_b32 exec_lo, exec_lo, s20                             // 0000008C8C60: 8C7E147E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008C8C64: BF8700B9
	s_or_b32 exec_lo, exec_lo, s18                             // 0000008C8C68: 8C7E127E
	.long 0xd71f0001                                           // 0000008C8C6C: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000008C8C70: 020100C1
	s_mov_b32 s4, exec_lo                                      // 0000008C8C74: BE84007E
	v_xor_b32_e32 v2, 16, v1                                   // 0000008C8C78: 3A040290
	v_xor_b32_e32 v7, 8, v1                                    // 0000008C8C7C: 3A0E0288
	v_xor_b32_e32 v12, 4, v1                                   // 0000008C8C80: 3A180284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000008C8C84: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000008C8C88: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 0000008C8C8C: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v7                            // 0000008C8C90: 7C980EA0
	v_cndmask_b32_e32 v7, v1, v7, vcc_lo                       // 0000008C8C94: 020E0F01
	v_cmp_gt_u32_e32 vcc_lo, 32, v12                           // 0000008C8C98: 7C9818A0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008C8C9C: BF870002
	v_lshlrev_b32_e32 v7, 2, v7                                // 0000008C8CA0: 300E0E82
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000008C8CA4: 30040482
	ds_bpermute_b32 v3, v2, v37                                // 0000008C8CA8: DACC0000 03002502
	s_waitcnt lgkmcnt(0)                                       // 0000008C8CB0: BF89FC07
	v_add_f32_e32 v3, v37, v3                                  // 0000008C8CB4: 06060725
	ds_bpermute_b32 v4, v2, v40                                // 0000008C8CB8: DACC0000 04002802
	ds_bpermute_b32 v5, v2, v39                                // 0000008C8CC0: DACC0000 05002702
	ds_bpermute_b32 v6, v2, v38                                // 0000008C8CC8: DACC0000 06002602
	ds_bpermute_b32 v2, v2, v34                                // 0000008C8CD0: DACC0000 02002202
	ds_bpermute_b32 v8, v7, v3                                 // 0000008C8CD8: DACC0000 08000307
	s_waitcnt lgkmcnt(3)                                       // 0000008C8CE0: BF89FC37
	v_dual_add_f32 v4, v40, v4 :: v_dual_add_f32 v5, v39, v5   // 0000008C8CE4: C9080928 04040B27
	s_waitcnt lgkmcnt(2)                                       // 0000008C8CEC: BF89FC27
	v_add_f32_e32 v6, v38, v6                                  // 0000008C8CF0: 060C0D26
	s_waitcnt lgkmcnt(0)                                       // 0000008C8CF4: BF89FC07
	v_dual_add_f32 v2, v34, v2 :: v_dual_add_f32 v3, v3, v8    // 0000008C8CF8: C9080522 02021103
	ds_bpermute_b32 v9, v7, v4                                 // 0000008C8D00: DACC0000 09000407
	ds_bpermute_b32 v10, v7, v5                                // 0000008C8D08: DACC0000 0A000507
	v_cndmask_b32_e32 v12, v1, v12, vcc_lo                     // 0000008C8D10: 02181901
	ds_bpermute_b32 v11, v7, v6                                // 0000008C8D14: DACC0000 0B000607
	ds_bpermute_b32 v7, v7, v2                                 // 0000008C8D1C: DACC0000 07000207
	v_lshlrev_b32_e32 v12, 2, v12                              // 0000008C8D24: 30181882
	s_waitcnt lgkmcnt(2)                                       // 0000008C8D28: BF89FC27
	v_dual_add_f32 v4, v4, v9 :: v_dual_add_f32 v5, v5, v10    // 0000008C8D2C: C9081304 04041505
	ds_bpermute_b32 v8, v12, v4                                // 0000008C8D34: DACC0000 0800040C
	ds_bpermute_b32 v9, v12, v5                                // 0000008C8D3C: DACC0000 0900050C
	s_waitcnt lgkmcnt(3)                                       // 0000008C8D44: BF89FC37
	v_add_f32_e32 v6, v6, v11                                  // 0000008C8D48: 060C1706
	s_waitcnt lgkmcnt(1)                                       // 0000008C8D4C: BF89FC17
	v_add_f32_e32 v4, v4, v8                                   // 0000008C8D50: 06081104
	v_add_f32_e32 v2, v2, v7                                   // 0000008C8D54: 06040F02
	ds_bpermute_b32 v7, v12, v3                                // 0000008C8D58: DACC0000 0700030C
	s_waitcnt lgkmcnt(1)                                       // 0000008C8D60: BF89FC17
	v_add_f32_e32 v5, v5, v9                                   // 0000008C8D64: 060A1305
	ds_bpermute_b32 v10, v12, v6                               // 0000008C8D68: DACC0000 0A00060C
	ds_bpermute_b32 v11, v12, v2                               // 0000008C8D70: DACC0000 0B00020C
	v_xor_b32_e32 v12, 2, v1                                   // 0000008C8D78: 3A180282
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008C8D7C: BF870001
	v_cmp_gt_u32_e32 vcc_lo, 32, v12                           // 0000008C8D80: 7C9818A0
	s_waitcnt lgkmcnt(2)                                       // 0000008C8D84: BF89FC27
	v_dual_add_f32 v3, v3, v7 :: v_dual_cndmask_b32 v12, v1, v12// 0000008C8D88: C9120F03 030C1901
	s_waitcnt lgkmcnt(1)                                       // 0000008C8D90: BF89FC17
	v_add_f32_e32 v6, v6, v10                                  // 0000008C8D94: 060C1506
	s_waitcnt lgkmcnt(0)                                       // 0000008C8D98: BF89FC07
	v_add_f32_e32 v2, v2, v11                                  // 0000008C8D9C: 06041702
	v_lshlrev_b32_e32 v12, 2, v12                              // 0000008C8DA0: 30181882
	ds_bpermute_b32 v7, v12, v3                                // 0000008C8DA4: DACC0000 0700030C
	ds_bpermute_b32 v8, v12, v4                                // 0000008C8DAC: DACC0000 0800040C
	ds_bpermute_b32 v9, v12, v5                                // 0000008C8DB4: DACC0000 0900050C
	ds_bpermute_b32 v10, v12, v6                               // 0000008C8DBC: DACC0000 0A00060C
	ds_bpermute_b32 v11, v12, v2                               // 0000008C8DC4: DACC0000 0B00020C
	v_xor_b32_e32 v12, 1, v1                                   // 0000008C8DCC: 3A180281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008C8DD0: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v12                           // 0000008C8DD4: 7C9818A0
	v_cndmask_b32_e32 v1, v1, v12, vcc_lo                      // 0000008C8DD8: 02021901
	s_waitcnt lgkmcnt(4)                                       // 0000008C8DDC: BF89FC47
	v_dual_add_f32 v1, v3, v7 :: v_dual_lshlrev_b32 v12, 2, v1 // 0000008C8DE0: C9220F03 010C0282
	s_waitcnt lgkmcnt(2)                                       // 0000008C8DE8: BF89FC27
	v_dual_add_f32 v3, v4, v8 :: v_dual_add_f32 v4, v5, v9     // 0000008C8DEC: C9081104 03041305
	s_waitcnt lgkmcnt(1)                                       // 0000008C8DF4: BF89FC17
	v_add_f32_e32 v7, v6, v10                                  // 0000008C8DF8: 060E1506
	s_waitcnt lgkmcnt(0)                                       // 0000008C8DFC: BF89FC07
	v_add_f32_e32 v2, v2, v11                                  // 0000008C8E00: 06041702
	ds_bpermute_b32 v5, v12, v1                                // 0000008C8E04: DACC0000 0500010C
	ds_bpermute_b32 v8, v12, v3                                // 0000008C8E0C: DACC0000 0800030C
	ds_bpermute_b32 v9, v12, v4                                // 0000008C8E14: DACC0000 0900040C
	ds_bpermute_b32 v10, v12, v7                               // 0000008C8E1C: DACC0000 0A00070C
	ds_bpermute_b32 v6, v12, v2                                // 0000008C8E24: DACC0000 0600020C
	v_cmpx_eq_u32_e32 0, v30                                   // 0000008C8E2C: 7D943C80
	s_cbranch_execz 18                                         // 0000008C8E30: BFA50012 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0xe7c>
	v_mul_u32_u24_e32 v11, 20, v29                             // 0000008C8E34: 16163A94
	s_waitcnt lgkmcnt(0)                                       // 0000008C8E38: BF89FC07
	v_dual_add_f32 v3, v3, v8 :: v_dual_add_f32 v2, v2, v6     // 0000008C8E3C: C9081103 03020D02
	v_add_f32_e32 v1, v1, v5                                   // 0000008C8E44: 06020B01
	v_dual_add_f32 v7, v7, v10 :: v_dual_add_f32 v4, v4, v9    // 0000008C8E48: C9081507 07041304
	v_or_b32_e32 v5, 0x400, v11                                // 0000008C8E50: 380A16FF 00000400
	v_mad_u32_u24 v8, v29, 20, 0x408                           // 0000008C8E58: D60B0008 03FD291D 00000408
	ds_store_2addr_b32 v5, v1, v3 offset1:1                    // 0000008C8E64: D8380100 00030105
	ds_store_2addr_b32 v8, v4, v7 offset1:1                    // 0000008C8E6C: D8380100 00070408
	ds_store_b32 v11, v2 offset:1040                           // 0000008C8E74: D8340410 0000020B
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008C8E7C: 8C7E047E
	.long 0xd4510004                                           // 0000008C8E80: D4510004
	v_cndmask_b32_e32 v0, s2, v16, vcc_lo                      // 0000008C8E84: 02002002
	v_cmp_gt_u32_e32 vcc_lo, 5, v0                             // 0000008C8E88: 7C980085
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000008C8E8C: BF890007
	s_barrier                                                  // 0000008C8E90: BFBD0000
	buffer_gl0_inv                                             // 0000008C8E94: E0AC0000 00000000
	s_and_b32 s4, vcc_lo, s4                                   // 0000008C8E9C: 8B04046A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000008C8EA0: BF870009
	s_and_saveexec_b32 s5, s4                                  // 0000008C8EA4: BE852004
	s_cbranch_execz 79                                         // 0000008C8EA8: BFA5004F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0xfe8>
	v_add_nc_u32_e32 v7, 0x400, v28                            // 0000008C8EAC: 4A0E38FF 00000400
	s_lshr_b32 s4, s17, 31                                     // 0000008C8EB4: 85049F11
	s_load_b64 s[0:1], s[0:1], 0x40                            // 0000008C8EB8: F4040000 F8000040
	s_add_u32 s4, s16, s4                                      // 0000008C8EC0: 80040410
	s_addc_u32 s5, s17, 0                                      // 0000008C8EC4: 82058011
	ds_load_2addr_b32 v[1:2], v7 offset1:5                     // 0000008C8EC8: D8DC0500 01000007
	ds_load_2addr_b32 v[3:4], v7 offset0:10 offset1:15         // 0000008C8ED0: D8DC0F0A 03000007
	ds_load_2addr_b32 v[5:6], v7 offset0:20 offset1:25         // 0000008C8ED8: D8DC1914 05000007
	s_ashr_i64 s[4:5], s[4:5], 1                               // 0000008C8EE0: 86848104
	s_lshr_b32 s6, s3, 23                                      // 0000008C8EE4: 85069703
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000008C8EE8: BF8704B9
	s_add_u32 s6, s2, s6                                       // 0000008C8EEC: 80060602
	s_addc_u32 s7, s3, 0                                       // 0000008C8EF0: 82078003
	s_and_b32 s6, s6, 0xfffffe00                               // 0000008C8EF4: 8B06FF06 FFFFFE00
	s_sub_u32 s2, s2, s6                                       // 0000008C8EFC: 80820602
	s_subb_u32 s3, s3, s7                                      // 0000008C8F00: 82830703
	s_waitcnt lgkmcnt(0)                                       // 0000008C8F04: BF89FC07
	v_add_f32_e32 v1, 0, v1                                    // 0000008C8F08: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C8F0C: BF870091
	v_add_f32_e32 v1, v1, v2                                   // 0000008C8F10: 06020501
	v_add_f32_e32 v3, v1, v3                                   // 0000008C8F14: 06060701
	v_mad_u64_u32 v[1:2], null, s4, v0, 0                      // 0000008C8F18: D6FE7C01 02020004
	.long 0xd4540004                                           // 0000008C8F20: D4540004
	v_cndmask_b32_e32 v0, 0x100, v2, vcc_lo                    // 0000008C8F24: 020004FF 00000100
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C8F2C: BF870093
	v_add_f32_e32 v3, v3, v4                                   // 0000008C8F30: 06060903
	v_add_f32_e32 v4, v3, v5                                   // 0000008C8F34: 06080B03
	ds_load_2addr_b32 v[7:8], v7 offset0:30 offset1:35         // 0000008C8F38: D8DC231E 07000007
	v_mad_u64_u32 v[2:3], null, s5, v0, v[2:3]                 // 0000008C8F40: D6FE7C02 040A0005
	s_and_b32 s5, s4, exec_lo                                  // 0000008C8F48: 8B057E04
	s_cselect_b32 s8, s12, s0                                  // 0000008C8F4C: 9808000C
	v_add_f32_e32 v0, v4, v6                                   // 0000008C8F50: 06000D04
	s_cselect_b32 s5, s13, s1                                  // 0000008C8F54: 9805010D
	s_add_u32 s0, s2, 0xffffff00                               // 0000008C8F58: 8000FF02 FFFFFF00
	s_addc_u32 s1, s3, -1                                      // 0000008C8F60: 8201C103
	s_and_b32 s4, s4, exec_lo                                  // 0000008C8F64: 8B047E04
	s_cselect_b32 s1, s3, s1                                   // 0000008C8F68: 98010103
	s_cselect_b32 s0, s2, s0                                   // 0000008C8F6C: 98000002
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000008C8F70: BF870149
	s_lshl_b64 s[0:1], s[0:1], 1                               // 0000008C8F74: 84808100
	s_waitcnt lgkmcnt(0)                                       // 0000008C8F78: BF89FC07
	v_add_f32_e32 v3, v0, v7                                   // 0000008C8F7C: 06060F00
	.long 0xd73c0000                                           // 0000008C8F80: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000008C8F84: 02020281
	v_add_f32_e32 v2, v3, v8                                   // 0000008C8F88: 06041103
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C8F8C: BF870092
	.long 0xd7006a00                                           // 0000008C8F90: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 0000008C8F94: 02020008
	v_add_co_ci_u32_e64 v1, null, s5, v1, vcc_lo               // 0000008C8F98: D5207C01 01AA0205
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008C8FA0: BF870193
	v_bfe_u32 v3, v2, 16, 1                                    // 0000008C8FA4: D6100003 02052102
	.long 0xd7006a00                                           // 0000008C8FAC: D7006A00
	v_cndmask_b32_e32 v0, v0, v6, vcc_lo                       // 0000008C8FB0: 02000D00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008C8FB4: BF870191
	v_add_co_ci_u32_e64 v1, null, s7, v1, vcc_lo               // 0000008C8FB8: D5207C01 01AA0207
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000008C8FC0: D6550002 03FE0702 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C8FCC: BF870093
	.long 0xd7006a00                                           // 0000008C8FD0: D7006A00
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 0000008C8FD4: 02000100
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 0000008C8FD8: D5207C01 01AA0201
	global_store_d16_hi_b16 v[0:1], v2, off                    // 0000008C8FE0: DC960000 007C0200
	s_endpgm                                                   // 0000008C8FE8: BFB00000
		...

