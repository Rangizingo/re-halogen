000000000035ef00 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi7ELi32ELi8EEEvNS0_5LqGrpEPKtl>:
; _ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi7ELi32ELi8EEEvNS0_5LqGrpEPKtl():
	s_clause 0x3                                               // 00000035EF00: BF850003
	s_load_b32 s3, s[0:1], 0x120                               // 00000035EF04: F40000C0 F8000120
	s_load_b32 s4, s[0:1], 0x88                                // 00000035EF0C: F4000100 F8000088
	s_load_b32 s5, s[0:1], 0xd0                                // 00000035EF14: F4000140 F80000D0
	s_load_b32 s6, s[0:1], 0x118                               // 00000035EF1C: F4000180 F8000118
	v_lshrrev_b32_e32 v70, 5, v0                               // 00000035EF24: 328C0085
	v_dual_mov_b32 v2, 0 :: v_dual_and_b32 v71, 31, v0         // 00000035EF28: CA240080 0246009F
	v_dual_mov_b32 v72, 0 :: v_dual_mov_b32 v3, 0              // 00000035EF30: CA100080 48020080
	v_dual_mov_b32 v54, 0 :: v_dual_mov_b32 v55, 0             // 00000035EF38: CA100080 36360080
	v_mov_b32_e32 v90, 0                                       // 00000035EF40: 7EB40280
	s_waitcnt lgkmcnt(0)                                       // 00000035EF44: BF89FC07
	s_cmp_gt_i32 s3, 1                                         // 00000035EF48: BF028103
	s_cselect_b32 s7, -1, 0                                    // 00000035EF4C: 980780C1
	s_cmp_ge_i32 s2, s4                                        // 00000035EF50: BF030402
	s_cselect_b32 s4, -1, 0                                    // 00000035EF54: 980480C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000035EF58: BF870009
	s_and_b32 s4, s7, s4                                       // 00000035EF5C: 8B040407
	s_cmp_gt_i32 s3, 2                                         // 00000035EF60: BF028203
	v_cndmask_b32_e64 v1, 0, 1, s4                             // 00000035EF64: D5010001 00110280
	s_cselect_b32 s7, -1, 0                                    // 00000035EF6C: 980780C1
	s_cmp_ge_i32 s2, s5                                        // 00000035EF70: BF030502
	s_cselect_b32 s5, -1, 0                                    // 00000035EF74: 980580C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000035EF78: BF870009
	s_and_b32 s4, s7, s5                                       // 00000035EF7C: 8B040507
	s_cmp_gt_i32 s3, 3                                         // 00000035EF80: BF028303
	v_readfirstlane_b32 s5, v1                                 // 00000035EF84: 7E0A0501
	s_cselect_b32 s3, -1, 0                                    // 00000035EF88: 980380C1
	s_cmp_ge_i32 s2, s6                                        // 00000035EF8C: BF030602
	v_mov_b32_e32 v1, 0                                        // 00000035EF90: 7E020280
	s_cselect_b32 s6, -1, 0                                    // 00000035EF94: 980680C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000035EF98: BF870009
	s_and_b32 s3, s3, s6                                       // 00000035EF9C: 8B030603
	s_and_b32 s4, s4, exec_lo                                  // 00000035EFA0: 8B047E04
	s_cselect_b32 s4, 2, s5                                    // 00000035EFA4: 98040582
	s_and_b32 s3, s3, exec_lo                                  // 00000035EFA8: 8B037E03
	s_cselect_b32 s3, 3, s4                                    // 00000035EFAC: 98030483
	s_load_b128 s[4:7], s[0:1], 0x128                          // 00000035EFB0: F4080100 F8000128
	s_mulk_i32 s3, 0x48                                        // 00000035EFB8: B8030048
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000035EFBC: BF870009
	s_add_u32 s10, s0, s3                                      // 00000035EFC0: 800A0300
	s_addc_u32 s11, s1, 0                                      // 00000035EFC4: 820B8001
	s_clause 0x2                                               // 00000035EFC8: BF850002
	s_load_b32 s12, s[10:11], 0x40                             // 00000035EFCC: F4000305 F8000040
	s_load_b64 s[0:1], s[10:11], null                          // 00000035EFD4: F4040005 F8000000
	s_load_b64 s[8:9], s[10:11], 0x30                          // 00000035EFDC: F4040205 F8000030
	s_mov_b32 s3, 0                                            // 00000035EFE4: BE830080
	s_waitcnt lgkmcnt(0)                                       // 00000035EFE8: BF89FC07
	s_ashr_i32 s18, s7, 31                                     // 00000035EFEC: 86129F07
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000035EFF0: BF870009
	s_lshr_b32 s13, s18, 27                                    // 00000035EFF4: 850D9B12
	s_sub_i32 s2, s2, s12                                      // 00000035EFF8: 81820C02
	s_add_u32 s12, s6, s13                                     // 00000035EFFC: 800C0D06
	s_addc_u32 s13, s7, 0                                      // 00000035F000: 820D8007
	v_dual_mov_b32 v5, s1 :: v_dual_mov_b32 v4, s0             // 00000035F004: CA100001 05040000
	s_lshr_b64 s[16:17], s[12:13], 5                           // 00000035F00C: 8590850C
	.long 0xd4510001                                           // 00000035F010: D4510001
	v_cndmask_b32_e32 v0, s2, v8, vcc_lo                       // 00000035F014: 02001002
	s_add_i32 s12, s16, 7                                      // 00000035F018: 810C8710
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000035F01C: BF870499
	s_ashr_i32 s13, s12, 31                                    // 00000035F020: 860D9F0C
	s_lshr_b32 s13, s13, 29                                    // 00000035F024: 850D9D0D
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000035F028: BF870009
	s_add_i32 s12, s12, s13                                    // 00000035F02C: 810C0D0C
	s_lshr_b32 s13, s7, 31                                     // 00000035F030: 850D9F07
	s_ashr_i32 s17, s12, 3                                     // 00000035F034: 8611830C
	s_add_u32 s12, s6, s13                                     // 00000035F038: 800C0D06
	s_addc_u32 s13, s7, 0                                      // 00000035F03C: 820D8007
	s_lshr_b32 s14, s18, 30                                    // 00000035F040: 850E9E12
	s_ashr_i64 s[12:13], s[12:13], 1                           // 00000035F044: 868C810C
	s_add_u32 s14, s6, s14                                     // 00000035F048: 800E0E06
	s_addc_u32 s15, s7, 0                                      // 00000035F04C: 820F8007
	s_lshr_b32 s18, s18, 28                                    // 00000035F050: 85129C12
	s_ashr_i64 s[14:15], s[14:15], 2                           // 00000035F054: 868E820E
	s_add_u32 s18, s6, s18                                     // 00000035F058: 80121206
	s_addc_u32 s19, s7, 0                                      // 00000035F05C: 82138007
	.long 0xd72c0006                                           // 00000035F060: D72C0006
	v_cndmask_b32_e32 v1, s17, v70, vcc_lo                     // 00000035F064: 02028C11
	s_ashr_i64 s[18:19], s[18:19], 4                           // 00000035F068: 86928412
	s_add_u32 s20, s14, s12                                    // 00000035F06C: 80140C0E
	s_addc_u32 s21, s15, s13                                   // 00000035F070: 82150D0F
	s_add_u32 s18, s20, s18                                    // 00000035F074: 80121214
	s_addc_u32 s19, s21, s19                                   // 00000035F078: 82131315
	s_add_u32 s18, s18, 15                                     // 00000035F07C: 80128F12
	s_addc_u32 s19, s19, 0                                     // 00000035F080: 82138013
	v_add_nc_u32_e32 v7, s17, v6                               // 00000035F084: 4A0E0C11
	s_ashr_i32 s0, s19, 31                                     // 00000035F088: 86009F13
	v_add_nc_u32_e32 v73, v6, v71                              // 00000035F08C: 4A928F06
	s_lshr_b32 s0, s0, 28                                      // 00000035F090: 85009C00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 00000035F094: BF8704D9
	s_add_u32 s0, s18, s0                                      // 00000035F098: 80000012
	s_addc_u32 s17, s19, 0                                     // 00000035F09C: 82118013
	s_and_b32 s0, s0, -16                                      // 00000035F0A0: 8B00D000
	s_and_b32 s1, s1, exec_lo                                  // 00000035F0A4: 8B017E01
	s_cselect_b32 s1, s2, 0                                    // 00000035F0A8: 98018002
	v_mad_u64_u32 v[49:50], null, s0, s1, v[4:5]               // 00000035F0AC: D6FE7C31 04100200
	v_mov_b32_e32 v4, 0                                        // 00000035F0B4: 7E080280
	v_min_i32_e32 v74, s16, v7                                 // 00000035F0B8: 22940E10
	s_mul_i32 s17, s17, s1                                     // 00000035F0BC: 96110111
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000035F0C0: BF870211
	v_cmp_lt_i32_e32 vcc_lo, v73, v74                          // 00000035F0C4: 7C829549
	v_add_nc_u32_e32 v75, s17, v50                             // 00000035F0C8: 4A966411
	s_and_saveexec_b32 s1, vcc_lo                              // 00000035F0CC: BE81206A
	s_cbranch_execz 39                                         // 00000035F0D0: BFA50027 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi7ELi32ELi8EEEvNS0_5LqGrpEPKtl+0x270>
	v_lshlrev_b32_e32 v1, 4, v73                               // 00000035F0D4: 30029284
	v_lshlrev_b32_e32 v4, 1, v73                               // 00000035F0D8: 30089281
	v_lshlrev_b32_e32 v3, 3, v73                               // 00000035F0DC: 30069283
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000035F0E0: BF870223
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000035F0E4: 3404029F
	.long 0xd7000001                                           // 00000035F0E8: D7000001
	v_cndmask_b32_e32 v1, v49, v1, vcc_lo                      // 00000035F0EC: 02020331
	v_and_b32_e32 v4, -4, v4                                   // 00000035F0F0: 360808C4
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000035F0F4: BF870214
	v_ashrrev_i32_e32 v7, 31, v3                               // 00000035F0F8: 340E069F
	v_add_co_ci_u32_e64 v2, null, v75, v2, s0                  // 00000035F0FC: D5207C02 0002054B
	.long 0xd7000005                                           // 00000035F104: D7000005
	v_cndmask_b32_e32 v0, v49, v12, vcc_lo                     // 00000035F108: 02001931
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000035F10C: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s13, v75, s0                 // 00000035F110: D5207C06 0002960D
	v_ashrrev_i32_e32 v10, 31, v4                              // 00000035F118: 3414089F
	.long 0xd7000008                                           // 00000035F11C: D7000008
	v_cndmask_b32_e32 v0, v5, v14, vcc_lo                      // 00000035F120: 02001D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000035F124: BF8700A1
	v_add_co_ci_u32_e64 v9, null, s15, v6, s0                  // 00000035F128: D5207C09 00020C0F
	.long 0xd7000005                                           // 00000035F130: D7000005
	v_cndmask_b32_e32 v1, v5, v3, vcc_lo                       // 00000035F134: 02020705
	v_add_co_ci_u32_e64 v6, null, v6, v7, s0                   // 00000035F138: D5207C06 00020F06
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000035F140: BF870094
	.long 0xd7000007                                           // 00000035F144: D7000007
	v_cndmask_b32_e32 v1, v8, v4, vcc_lo                       // 00000035F148: 02020908
	v_add_co_ci_u32_e64 v8, null, v9, v10, s0                  // 00000035F14C: D5207C08 00021509
	s_clause 0x2                                               // 00000035F154: BF850002
	global_load_b128 v[1:4], v[1:2], off                       // 00000035F158: DC5E0000 017C0001
	global_load_b64 v[54:55], v[5:6], off                      // 00000035F160: DC560000 367C0005
	global_load_b32 v90, v[7:8], off                           // 00000035F168: DC520000 5A7C0007
	s_or_b32 exec_lo, exec_lo, s1                              // 00000035F170: 8C7E017E
	v_dual_mov_b32 v76, 0 :: v_dual_mov_b32 v77, 0             // 00000035F174: CA100080 4C4C0080
	v_dual_mov_b32 v78, 0 :: v_dual_mov_b32 v79, 0             // 00000035F17C: CA100080 4E4E0080
	v_dual_mov_b32 v80, 0 :: v_dual_mov_b32 v81, 0             // 00000035F184: CA100080 50500080
	s_and_saveexec_b32 s1, vcc_lo                              // 00000035F18C: BE81206A
	s_cbranch_execz 932                                        // 00000035F190: BFA503A4 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi7ELi32ELi8EEEvNS0_5LqGrpEPKtl+0x1124>
	.long 0xd7006a52                                           // 00000035F194: D7006A52
	v_cndmask_b32_e32 v0, v49, v12, vcc_lo                     // 00000035F198: 02001931
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000035F19C: BF8701A1
	v_add_co_ci_u32_e64 v83, null, s13, v75, vcc_lo            // 00000035F1A0: D5207C53 01AA960D
	v_dual_mov_b32 v72, 0 :: v_dual_add_nc_u32 v5, 32, v73     // 00000035F1A8: CA200080 480492A0
	.long 0xd7006a54                                           // 00000035F1B0: D7006A54
	v_cndmask_b32_e32 v0, v82, v14, vcc_lo                     // 00000035F1B4: 02001D52
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000035F1B8: BF870221
	v_add_co_ci_u32_e64 v85, null, s15, v83, vcc_lo            // 00000035F1BC: D5207C55 01AAA60F
	v_dual_mov_b32 v77, 0 :: v_dual_lshlrev_b32 v50, 5, v73    // 00000035F1C4: CA220080 4D329285
	v_dual_mov_b32 v79, 0 :: v_dual_lshlrev_b32 v86, 4, v5     // 00000035F1CC: CA220080 4F560A84
	v_dual_mov_b32 v76, 0 :: v_dual_lshlrev_b32 v87, 3, v5     // 00000035F1D4: CA220080 4C560A83
	v_dual_mov_b32 v81, 0 :: v_dual_lshlrev_b32 v88, 1, v5     // 00000035F1DC: CA220080 51580A81
	s_waitcnt vmcnt(0)                                         // 00000035F1E4: BF8903F7
	v_dual_mov_b32 v78, 0 :: v_dual_mov_b32 v89, v90           // 00000035F1E8: CA100080 4E58015A
	v_mov_b32_e32 v80, 0                                       // 00000035F1F0: 7EA00280
	s_mul_i32 s0, s7, 6                                        // 00000035F1F4: 96008607
	s_mul_hi_u32 s14, s6, 6                                    // 00000035F1F8: 968E8606
	s_lshl_b64 s[12:13], s[6:7], 2                             // 00000035F1FC: 848C8206
	s_add_i32 s14, s14, s0                                     // 00000035F200: 810E000E
	s_mul_i32 s16, s6, 6                                       // 00000035F204: 96108606
	s_mov_b32 s15, 0                                           // 00000035F208: BE8F0080
	s_lshl_b64 s[6:7], s[6:7], 1                               // 00000035F20C: 84868106
	s_branch 860                                               // 00000035F210: BFA0035C <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi7ELi32ELi8EEEvNS0_5LqGrpEPKtl+0x1084>
	s_or_b32 exec_lo, exec_lo, s17                             // 00000035F214: 8C7E117E
	v_ashrrev_i32_e32 v51, 31, v50                             // 00000035F218: 3466649F
	v_lshlrev_b32_e32 v91, 2, v54                              // 00000035F21C: 30B66C82
	v_lshrrev_b32_e32 v92, 4, v1                               // 00000035F220: 32B80284
	v_lshrrev_b32_e32 v93, 8, v1                               // 00000035F224: 32BA0288
	v_lshrrev_b32_e32 v94, 2, v54                              // 00000035F228: 32BC6C82
	.long 0xd73c0009                                           // 00000035F22C: D73C0009
	v_cndmask_b32_e32 v1, 1, v50, vcc_lo                       // 00000035F230: 02026481
	v_lshlrev_b32_e32 v51, 4, v54                              // 00000035F234: 30666C84
	v_and_b32_e32 v91, 48, v91                                 // 00000035F238: 36B6B6B0
	v_and_b32_e32 v95, 48, v54                                 // 00000035F23C: 36BE6CB0
	v_lshrrev_b32_e32 v96, 12, v1                              // 00000035F240: 32C0028C
	v_and_b32_e32 v94, 48, v94                                 // 00000035F244: 36BCBCB0
	.long 0xd7000040                                           // 00000035F248: D7000040
	v_cndmask_b32_e32 v1, s4, v9, vcc_lo                       // 00000035F24C: 02021204
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000035F250: BF8701A1
	v_add_co_ci_u32_e64 v65, null, s5, v10, s0                 // 00000035F254: D5207C41 00021405
	v_and_b32_e32 v51, 48, v51                                 // 00000035F25C: 366666B0
	.long 0xd700003c                                           // 00000035F260: D700003C
	v_cndmask_b32_e32 v0, v64, v6, vcc_lo                      // 00000035F264: 02000D40
	global_load_b128 v[9:12], v[64:65], off                    // 00000035F268: DC5E0000 097C0040
	v_add_co_ci_u32_e64 v61, null, s7, v65, s0                 // 00000035F270: D5207C3D 00028207
	.long 0xd7000038                                           // 00000035F278: D7000038
	v_cndmask_b32_e32 v0, v64, v12, vcc_lo                     // 00000035F27C: 02001940
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000035F280: BF8700B1
	v_add_co_ci_u32_e64 v57, null, s13, v65, s0                // 00000035F284: D5207C39 0002820D
	global_load_b128 v[13:16], v[60:61], off                   // 00000035F28C: DC5E0000 0D7C003C
	.long 0xd700003a                                           // 00000035F294: D700003A
	v_cndmask_b32_e32 v0, v64, v16, vcc_lo                     // 00000035F298: 02002140
	v_add_co_ci_u32_e64 v59, null, s14, v65, s0                // 00000035F29C: D5207C3B 0002820E
	.long 0xd700003e                                           // 00000035F2A4: D700003E
	v_cndmask_b32_e32 v0, v56, v12, vcc_lo                     // 00000035F2A8: 02001938
	s_delay_alu instid0(VALU_DEP_1)                            // 00000035F2AC: BF870001
	v_add_co_ci_u32_e64 v63, null, s13, v57, s0                // 00000035F2B0: D5207C3F 0002720D
	s_clause 0x2                                               // 00000035F2B8: BF850002
	global_load_b128 v[17:20], v[56:57], off                   // 00000035F2BC: DC5E0000 117C0038
	global_load_b128 v[25:28], v[58:59], off                   // 00000035F2C4: DC5E0000 197C003A
	global_load_b128 v[21:24], v[62:63], off                   // 00000035F2CC: DC5E0000 157C003E
	.long 0xd7000042                                           // 00000035F2D4: D7000042
	v_cndmask_b32_e32 v0, v58, v12, vcc_lo                     // 00000035F2D8: 0200193A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000035F2DC: BF8700A1
	v_add_co_ci_u32_e64 v67, null, s13, v59, s0                // 00000035F2E0: D5207C43 0002760D
	.long 0xd7000044                                           // 00000035F2E8: D7000044
	v_cndmask_b32_e32 v0, v62, v12, vcc_lo                     // 00000035F2EC: 0200193E
	v_add_co_ci_u32_e64 v69, null, s13, v63, s0                // 00000035F2F0: D5207C45 00027E0D
	s_clause 0x4                                               // 00000035F2F8: BF850004
	global_load_b128 v[33:36], v[66:67], off                   // 00000035F2FC: DC5E0000 217C0042
	global_load_b128 v[45:48], v[68:69], off                   // 00000035F304: DC5E0000 2D7C0044
	global_load_b128 v[37:40], v[64:65], off offset:16         // 00000035F30C: DC5E0010 257C0040
	global_load_b128 v[29:32], v[60:61], off offset:16         // 00000035F314: DC5E0010 1D7C003C
	global_load_b128 v[41:44], v[56:57], off offset:16         // 00000035F31C: DC5E0010 297C0038
	v_and_or_b32 v51, v1, 15, v51                              // 00000035F324: D6570033 04CD1F01
	v_and_or_b32 v91, v92, 15, v91                             // 00000035F32C: D657005B 056D1F5C
	v_and_or_b32 v92, v93, 15, v95                             // 00000035F334: D657005C 057D1F5D
	v_and_or_b32 v93, v96, 15, v94                             // 00000035F33C: D657005D 05791F60
	v_lshrrev_b32_e32 v98, 10, v54                             // 00000035F344: 32C46C8A
	v_cvt_f32_ubyte0_e32 v51, v51                              // 00000035F348: 7E662333
	v_cvt_f32_ubyte0_e32 v91, v91                              // 00000035F34C: 7EB6235B
	v_cvt_f32_ubyte0_e32 v92, v92                              // 00000035F350: 7EB8235C
	v_cvt_f32_ubyte0_e32 v93, v93                              // 00000035F354: 7EBA235D
	v_lshrrev_b32_e32 v99, 8, v2                               // 00000035F358: 32C60488
	v_fma_mix_f32 v51, v51, v90, v90 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035F35C: CC206033 156AB533
	v_fma_mix_f32 v91, v91, v90, v90 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035F364: CC20605B 156AB55B
	v_fma_mix_f32 v92, v92, v90, v90 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035F36C: CC20605C 156AB55C
	v_fma_mix_f32 v93, v93, v90, v90 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035F374: CC20605D 156AB55D
	v_lshrrev_b32_e32 v100, 18, v54                            // 00000035F37C: 32C86C92
	v_bfe_u32 v94, v51, 16, 1                                  // 00000035F380: D610005E 02052133
	v_bfe_u32 v95, v91, 16, 1                                  // 00000035F388: D610005F 0205215B
	v_bfe_u32 v96, v92, 16, 1                                  // 00000035F390: D6100060 0205215C
	v_bfe_u32 v97, v93, 16, 1                                  // 00000035F398: D6100061 0205215D
	v_and_b32_e32 v100, 48, v100                               // 00000035F3A0: 36C8C8B0
	v_add3_u32 v94, v51, v94, 0x7fff                           // 00000035F3A4: D655005E 03FEBD33 00007FFF
	.long 0x7f663880                                           // 00000035F3B0: 7F663880
	v_add3_u32 v91, v91, v95, 0x7fff                           // 00000035F3B4: D655005B 03FEBF5B 00007FFF
	v_add3_u32 v92, v92, v96, 0x7fff                           // 00000035F3C0: D655005C 03FEC15C 00007FFF
	v_add3_u32 v93, v93, v97, 0x7fff                           // 00000035F3CC: D655005D 03FEC35D 00007FFF
	.long 0x7e6639de                                           // 00000035F3D8: 7E6639DE
	v_lshrrev_b32_e32 v94, 4, v54                              // 00000035F3DC: 32BC6C84
	v_lshrrev_b32_e32 v95, 8, v54                              // 00000035F3E0: 32BE6C88
	v_lshrrev_b32_e32 v96, 6, v54                              // 00000035F3E4: 32C06C86
	v_lshrrev_b32_e32 v97, 24, v1                              // 00000035F3E8: 32C20298
	v_and_or_b32 v91, 0xffff0000, v91, v51                     // 00000035F3EC: D657005B 04CEB6FF FFFF0000
	.long 0x7e6639dc                                           // 00000035F3F8: 7E6639DC
	v_and_b32_e32 v94, 48, v94                                 // 00000035F3FC: 36BCBCB0
	v_and_b32_e32 v96, 48, v96                                 // 00000035F400: 36C0C0B0
	v_and_b32_e32 v95, 48, v95                                 // 00000035F404: 36BEBEB0
	v_lshrrev_b32_e32 v102, 24, v54                            // 00000035F408: 32CC6C98
	v_and_or_b32 v92, 0xffff0000, v93, v51                     // 00000035F40C: D657005C 04CEBAFF FFFF0000
	.long 0x7e663981                                           // 00000035F418: 7E663981
	v_lshrrev_b32_e32 v93, 20, v1                              // 00000035F41C: 32BA0294
	v_lshrrev_b32_e32 v1, 28, v1                               // 00000035F420: 3202029C
	v_and_or_b32 v95, v97, 15, v95                             // 00000035F424: D657005F 057D1F61
	v_lshrrev_b32_e32 v97, 12, v2                              // 00000035F42C: 32C2048C
	v_and_or_b32 v94, v51, 15, v94                             // 00000035F430: D657005E 05791F33
	v_and_or_b32 v93, v93, 15, v96                             // 00000035F438: D657005D 05811F5D
	v_and_or_b32 v1, v98, 48, v1                               // 00000035F440: D6570001 04056162
	v_cvt_f32_ubyte0_e32 v95, v95                              // 00000035F448: 7EBE235F
	v_and_or_b32 v97, v97, 15, v100                            // 00000035F44C: D6570061 05911F61
	v_cvt_f32_ubyte0_e32 v94, v94                              // 00000035F454: 7EBC235E
	v_cvt_f32_ubyte0_e32 v93, v93                              // 00000035F458: 7EBA235D
	v_cvt_f32_ubyte0_e32 v1, v1                                // 00000035F45C: 7E022301
	v_fma_mix_f32 v95, v95, v90, v90 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035F460: CC20605F 156AB55F
	v_cvt_f32_ubyte0_e32 v97, v97                              // 00000035F468: 7EC22361
	v_fma_mix_f32 v94, v94, v90, v90 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035F46C: CC20605E 156AB55E
	v_fma_mix_f32 v93, v93, v90, v90 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035F474: CC20605D 156AB55D
	v_fma_mix_f32 v1, v1, v90, v90 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035F47C: CC206001 156AB501
	v_lshrrev_b32_e32 v96, 20, v54                             // 00000035F484: 32C06C94
	v_fma_mix_f32 v97, v97, v90, v90 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035F488: CC206061 156AB561
	v_bfe_u32 v98, v94, 16, 1                                  // 00000035F490: D6100062 0205215E
	v_bfe_u32 v101, v93, 16, 1                                 // 00000035F498: D6100065 0205215D
	v_bfe_u32 v103, v1, 16, 1                                  // 00000035F4A0: D6100067 02052101
	v_and_b32_e32 v96, 48, v96                                 // 00000035F4A8: 36C0C0B0
	v_bfe_u32 v123, v97, 16, 1                                 // 00000035F4AC: D610007B 02052161
	v_add3_u32 v94, v94, v98, 0x7fff                           // 00000035F4B4: D655005E 03FEC55E 00007FFF
	v_bfe_u32 v98, v95, 16, 1                                  // 00000035F4C0: D6100062 0205215F
	v_add3_u32 v93, v93, v101, 0x7fff                          // 00000035F4C8: D655005D 03FECB5D 00007FFF
	v_add3_u32 v1, v1, v103, 0x7fff                            // 00000035F4D4: D6550001 03FECF01 00007FFF
	v_add3_u32 v97, v97, v123, 0x7fff                          // 00000035F4E0: D6550061 03FEF761 00007FFF
	.long 0x7e6639de                                           // 00000035F4EC: 7E6639DE
	v_add3_u32 v94, v95, v98, 0x7fff                           // 00000035F4F0: D655005E 03FEC55F 00007FFF
	v_lshrrev_b32_e32 v98, 22, v54                             // 00000035F4FC: 32C46C96
	v_lshrrev_b32_e32 v95, 20, v2                              // 00000035F500: 32BE0494
	v_lshlrev_b32_e32 v104, 4, v55                             // 00000035F504: 30D06E84
	v_and_or_b32 v93, 0xffff0000, v93, v51                     // 00000035F508: D657005D 04CEBAFF FFFF0000
	.long 0x7e6639de                                           // 00000035F514: 7E6639DE
	v_and_b32_e32 v98, 48, v98                                 // 00000035F518: 36C4C4B0
	v_lshrrev_b32_e32 v94, 24, v2                              // 00000035F51C: 32BC0498
	v_lshrrev_b32_e32 v101, 28, v2                             // 00000035F520: 32CA049C
	v_lshrrev_b32_e32 v103, 26, v54                            // 00000035F524: 32CE6C9A
	v_and_or_b32 v1, 0xffff0000, v1, v51                       // 00000035F528: D6570001 04CE02FF FFFF0000
	.long 0x7e6639b6                                           // 00000035F534: 7E6639B6
	v_and_or_b32 v95, v95, 15, v98                             // 00000035F538: D657005F 05891F5F
	v_lshlrev_b32_e32 v108, 2, v55                             // 00000035F540: 30D86E82
	v_lshrrev_b32_e32 v105, 8, v3                              // 00000035F544: 32D20688
	v_and_b32_e32 v106, 48, v55                                // 00000035F548: 36D46EB0
	v_and_b32_e32 v109, 48, v51                                // 00000035F54C: 36DA66B0
	v_cvt_f32_ubyte0_e32 v95, v95                              // 00000035F550: 7EBE235F
	v_lshrrev_b32_e32 v107, 4, v3                              // 00000035F554: 32D60684
	v_lshrrev_b32_e32 v111, 2, v55                             // 00000035F558: 32DE6E82
	v_and_or_b32 v101, v103, 48, v101                          // 00000035F55C: D6570065 05956167
	v_and_or_b32 v99, v99, 15, v109                            // 00000035F564: D6570063 05B51F63
	v_and_b32_e32 v98, 48, v108                                // 00000035F56C: 36C4D8B0
	v_fma_mix_f32 v95, v95, v90, v90 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035F570: CC20605F 156AB55F
	v_lshrrev_b32_e32 v110, 12, v3                             // 00000035F578: 32DC068C
	v_cvt_f32_ubyte0_e32 v101, v101                            // 00000035F57C: 7ECA2365
	v_cvt_f32_ubyte0_e32 v99, v99                              // 00000035F580: 7EC62363
	v_and_or_b32 v98, v107, 15, v98                            // 00000035F584: D6570062 05891F6B
	v_lshrrev_b32_e32 v113, 4, v55                             // 00000035F58C: 32E26E84
	v_lshrrev_b32_e32 v114, 8, v55                             // 00000035F590: 32E46E88
	v_fma_mix_f32 v101, v101, v90, v90 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035F594: CC206065 156AB565
	v_fma_mix_f32 v99, v99, v90, v90 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035F59C: CC206063 156AB563
	v_cvt_f32_ubyte0_e32 v98, v98                              // 00000035F5A4: 7EC42362
	v_lshrrev_b32_e32 v100, 6, v55                             // 00000035F5A8: 32C86E86
	v_lshrrev_b32_e32 v112, 12, v54                            // 00000035F5AC: 32E06C8C
	v_lshrrev_b32_e32 v115, 20, v3                             // 00000035F5B0: 32E60694
	v_bfe_u32 v119, v99, 16, 1                                 // 00000035F5B4: D6100077 02052163
	v_fma_mix_f32 v98, v98, v90, v90 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035F5BC: CC206062 156AB562
	v_lshrrev_b32_e32 v116, 24, v3                             // 00000035F5C4: 32E80698
	v_lshrrev_b32_e32 v117, 28, v3                             // 00000035F5C8: 32EA069C
	v_lshrrev_b32_e32 v118, 10, v55                            // 00000035F5CC: 32EC6E8A
	v_add3_u32 v99, v99, v119, 0x7fff                          // 00000035F5D0: D6550063 03FEEF63 00007FFF
	v_lshrrev_b32_e32 v109, 4, v2                              // 00000035F5DC: 32DA0484
	v_lshrrev_b32_e32 v54, 14, v54                             // 00000035F5E0: 326C6C8E
	v_lshrrev_b32_e32 v122, 18, v55                            // 00000035F5E4: 32F46E92
	v_lshrrev_b32_e32 v119, 8, v4                              // 00000035F5E8: 32EE0888
	.long 0x7e6639e3                                           // 00000035F5EC: 7E6639E3
	v_and_or_b32 v99, v105, 15, v106                           // 00000035F5F0: D6570063 05A91F69
	v_and_b32_e32 v54, 48, v54                                 // 00000035F5F8: 366C6CB0
	v_lshrrev_b32_e32 v120, 12, v55                            // 00000035F5FC: 32F06E8C
	v_lshrrev_b32_e32 v121, 12, v4                             // 00000035F600: 32F2088C
	v_and_or_b32 v127, 0xffff0000, v97, v51                    // 00000035F604: D657007F 04CEC2FF FFFF0000
	.long 0x7e663982                                           // 00000035F610: 7E663982
	v_and_b32_e32 v97, 48, v102                                // 00000035F614: 36C2CCB0
	v_and_b32_e32 v102, 48, v104                               // 00000035F618: 36CCD0B0
	v_cvt_f32_ubyte0_e32 v99, v99                              // 00000035F61C: 7EC62363
	v_and_or_b32 v54, v109, 15, v54                            // 00000035F620: D6570036 04D91F6D
	v_and_or_b32 v96, v51, 15, v96                             // 00000035F628: D6570060 05811F33
	v_and_or_b32 v94, v94, 15, v97                             // 00000035F630: D657005E 05851F5E
	v_and_or_b32 v102, v3, 15, v102                            // 00000035F638: D6570066 05991F03
	v_and_b32_e32 v97, 48, v111                                // 00000035F640: 36C2DEB0
	v_fma_mix_f32 v99, v99, v90, v90 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035F644: CC206063 156AB563
	v_cvt_f32_ubyte0_e32 v96, v96                              // 00000035F64C: 7EC02360
	v_cvt_f32_ubyte0_e32 v94, v94                              // 00000035F650: 7EBC235E
	v_cvt_f32_ubyte0_e32 v102, v102                            // 00000035F654: 7ECC2366
	v_and_or_b32 v97, v110, 15, v97                            // 00000035F658: D6570061 05851F6E
	v_cvt_f32_ubyte0_e32 v54, v54                              // 00000035F660: 7E6C2336
	v_fma_mix_f32 v96, v96, v90, v90 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035F664: CC206060 156AB560
	v_fma_mix_f32 v94, v94, v90, v90 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035F66C: CC20605E 156AB55E
	v_fma_mix_f32 v102, v102, v90, v90 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035F674: CC206066 156AB566
	v_cvt_f32_ubyte0_e32 v97, v97                              // 00000035F67C: 7EC22361
	v_fma_mix_f32 v54, v54, v90, v90 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035F680: CC206036 156AB536
	v_bfe_u32 v103, v96, 16, 1                                 // 00000035F688: D6100067 02052160
	v_lshrrev_b32_e32 v124, 14, v55                            // 00000035F690: 32F86E8E
	v_lshrrev_b32_e32 v123, 20, v55                            // 00000035F694: 32F66E94
	v_fma_mix_f32 v97, v97, v90, v90 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035F698: CC206061 156AB561
	v_lshrrev_b32_e32 v125, 24, v55                            // 00000035F6A0: 32FA6E98
	v_add3_u32 v96, v96, v103, 0x7fff                          // 00000035F6A4: D6550060 03FECF60 00007FFF
	v_bfe_u32 v103, v95, 16, 1                                 // 00000035F6B0: D6100067 0205215F
	v_lshrrev_b32_e32 v126, 22, v55                            // 00000035F6B8: 32FC6E96
	v_lshrrev_b32_e32 v106, 26, v55                            // 00000035F6BC: 32D46E9A
	v_and_b32_e32 v108, 15, v4                                 // 00000035F6C0: 36D8088F
	.long 0x7e6639e0                                           // 00000035F6C4: 7E6639E0
	v_add3_u32 v95, v95, v103, 0x7fff                          // 00000035F6C8: D655005F 03FECF5F 00007FFF
	v_bfe_u32 v103, v94, 16, 1                                 // 00000035F6D4: D6100067 0205215E
	v_bfe_u32 v96, v101, 16, 1                                 // 00000035F6DC: D6100060 02052165
	v_lshrrev_b32_e32 v107, 28, v4                             // 00000035F6E4: 32D6089C
	v_lshrrev_b32_e32 v128, 4, v4                              // 00000035F6E8: 33000884
	v_and_or_b32 v110, 0xffff0000, v95, v51                    // 00000035F6EC: D657006E 04CEBEFF FFFF0000
	v_add3_u32 v94, v94, v103, 0x7fff                          // 00000035F6F8: D655005E 03FECF5E 00007FFF
	v_bfe_u32 v103, v102, 16, 1                                // 00000035F704: D6100067 02052166
	v_add3_u32 v96, v101, v96, 0x7fff                          // 00000035F70C: D6550060 03FEC165 00007FFF
	v_bfe_u32 v101, v98, 16, 1                                 // 00000035F718: D6100065 02052162
	v_bfe_u32 v95, v99, 16, 1                                  // 00000035F720: D610005F 02052163
	.long 0x7e6639de                                           // 00000035F728: 7E6639DE
	v_add3_u32 v94, v102, v103, 0x7fff                         // 00000035F72C: D655005E 03FECF66 00007FFF
	v_bfe_u32 v102, v97, 16, 1                                 // 00000035F738: D6100066 02052161
	v_add3_u32 v98, v98, v101, 0x7fff                          // 00000035F740: D6550062 03FECB62 00007FFF
	v_lshrrev_b32_e32 v129, 20, v4                             // 00000035F74C: 33020894
	v_and_or_b32 v111, 0xffff0000, v96, v51                    // 00000035F750: D657006F 04CEC0FF FFFF0000
	.long 0x7e6639de                                           // 00000035F75C: 7E6639DE
	v_add3_u32 v94, v99, v95, 0x7fff                           // 00000035F760: D655005E 03FEBF63 00007FFF
	v_add3_u32 v95, v97, v102, 0x7fff                          // 00000035F76C: D655005F 03FECD61 00007FFF
	v_and_b32_e32 v96, 48, v100                                // 00000035F778: 36C0C8B0
	v_and_or_b32 v97, v118, 48, v117                           // 00000035F77C: D6570061 05D56176
	v_and_or_b32 v130, 0xffff0000, v98, v51                    // 00000035F784: D6570082 04CEC4FF FFFF0000
	.long 0x7e6639de                                           // 00000035F790: 7E6639DE
	v_and_b32_e32 v94, 48, v113                                // 00000035F794: 36BCE2B0
	v_and_or_b32 v96, v115, 15, v96                            // 00000035F798: D6570060 05811F73
	v_cvt_f32_ubyte0_e32 v97, v97                              // 00000035F7A0: 7EC22361
	v_and_b32_e32 v98, 48, v122                                // 00000035F7A4: 36C4F4B0
	v_and_or_b32 v113, 0xffff0000, v95, v51                    // 00000035F7A8: D6570071 04CEBEFF FFFF0000
	.long 0x7e663983                                           // 00000035F7B4: 7E663983
	v_and_b32_e32 v3, 48, v114                                 // 00000035F7B8: 3606E4B0
	v_and_b32_e32 v95, 48, v112                                // 00000035F7BC: 36BEE0B0
	v_fma_mix_f32 v100, v97, v90, v90 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035F7C0: CC206064 156AB561
	v_and_or_b32 v98, v121, 15, v98                            // 00000035F7C8: D6570062 05891F79
	v_and_or_b32 v94, v51, 15, v94                             // 00000035F7D0: D657005E 05791F33
	v_and_or_b32 v3, v116, 15, v3                              // 00000035F7D8: D6570003 040D1F74
	v_and_or_b32 v2, v2, 15, v95                               // 00000035F7E0: D6570002 057D1F02
	v_cvt_f32_ubyte0_e32 v95, v96                              // 00000035F7E8: 7EBE2360
	v_lshrrev_b32_e32 v131, 24, v4                             // 00000035F7EC: 33060898
	v_cvt_f32_ubyte0_e32 v94, v94                              // 00000035F7F0: 7EBC235E
	v_cvt_f32_ubyte0_e32 v3, v3                                // 00000035F7F4: 7E062303
	v_cvt_f32_ubyte0_e32 v2, v2                                // 00000035F7F8: 7E042302
	v_fma_mix_f32 v101, v95, v90, v90 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035F7FC: CC206065 156AB55F
	v_add_nc_u32_e32 v50, 0x400, v50                           // 00000035F804: 4A6464FF 00000400
	v_fma_mix_f32 v99, v94, v90, v90 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035F80C: CC206063 156AB55E
	v_fma_mix_f32 v3, v3, v90, v90 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035F814: CC206003 156AB503
	v_fma_mix_f32 v2, v2, v90, v90 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035F81C: CC206002 156AB502
	v_bfe_u32 v103, v101, 16, 1                                // 00000035F824: D6100067 02052165
	global_load_b128 v[94:97], v[64:65], off offset:32         // 00000035F82C: DC5E0020 5E7C0040
	v_bfe_u32 v102, v99, 16, 1                                 // 00000035F834: D6100066 02052163
	v_add_nc_u32_e32 v86, 0x200, v86                           // 00000035F83C: 4AACACFF 00000200
	v_add_nc_u32_e32 v87, 0x100, v87                           // 00000035F844: 4AAEAEFF 00000100
	v_add3_u32 v101, v101, v103, 0x7fff                        // 00000035F84C: D6550065 03FECF65 00007FFF
	v_add_nc_u32_e32 v88, 64, v88                              // 00000035F858: 4AB0B0C0
	v_add3_u32 v99, v99, v102, 0x7fff                          // 00000035F85C: D6550063 03FECD63 00007FFF
	v_bfe_u32 v102, v100, 16, 1                                // 00000035F868: D6100066 02052164
	s_and_b32 s0, exec_lo, vcc_lo                              // 00000035F870: 8B006A7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000035F874: BF870119
	s_or_b32 s15, s0, s15                                      // 00000035F878: 8C0F0F00
	.long 0x7e6639e3                                           // 00000035F87C: 7E6639E3
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000035F880: BF8701A2
	v_add3_u32 v99, v100, v102, 0x7fff                         // 00000035F884: D6550063 03FECD64 00007FFF
	v_bfe_u32 v100, v2, 16, 1                                  // 00000035F890: D6100064 02052102
	v_and_or_b32 v112, 0xffff0000, v101, v51                   // 00000035F898: D6570070 04CECAFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000035F8A4: BF8700B2
	v_add3_u32 v2, v2, v100, 0x7fff                            // 00000035F8A8: D6550002 03FEC902 00007FFF
	s_waitcnt vmcnt(10)                                        // 00000035F8B4: BF892BF7
	v_dot2_f32_bf16 v9, v9, v91, 0                             // 00000035F8B8: CC1A4009 1A02B709
	v_dot2_f32_bf16 v9, v10, v92, v9                           // 00000035F8C0: CC1A4009 1C26B90A
	s_waitcnt vmcnt(9)                                         // 00000035F8C8: BF8927F7
	v_dot2_f32_bf16 v10, v13, v91, 0                           // 00000035F8CC: CC1A400A 1A02B70D
	v_bfe_u32 v13, v3, 16, 1                                   // 00000035F8D4: D610000D 02052103
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000035F8DC: BF870193
	v_dot2_f32_bf16 v9, v11, v93, v9                           // 00000035F8E0: CC1A4009 1C26BB0B
	v_dot2_f32_bf16 v14, v14, v92, v10                         // 00000035F8E8: CC1A400E 1C2AB90E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000035F8F0: BF870193
	v_add3_u32 v3, v3, v13, 0x7fff                             // 00000035F8F4: D6550003 03FE1B03 00007FFF
	v_dot2_f32_bf16 v103, v12, v1, v9                          // 00000035F900: CC1A4067 1C26030C
	global_load_b128 v[9:12], v[58:59], off offset:16          // 00000035F908: DC5E0010 097C003A
	v_dot2_f32_bf16 v13, v15, v93, v14                         // 00000035F910: CC1A400D 1C3ABB0F
	.long 0x7e663983                                           // 00000035F918: 7E663983
	s_waitcnt vmcnt(9)                                         // 00000035F91C: BF8927F7
	v_dot2_f32_bf16 v3, v17, v91, 0                            // 00000035F920: CC1A4003 1A02B711
	s_waitcnt vmcnt(8)                                         // 00000035F928: BF8923F7
	v_dot2_f32_bf16 v17, v25, v91, 0                           // 00000035F92C: CC1A4011 1A02B719
	v_dot2_f32_bf16 v114, v16, v1, v13                         // 00000035F934: CC1A4072 1C360310
	v_and_or_b32 v115, 0xffff0000, v99, v51                    // 00000035F93C: D6570073 04CEC6FF FFFF0000
	v_dot2_f32_bf16 v3, v18, v92, v3                           // 00000035F948: CC1A4003 1C0EB912
	.long 0x7e6639b7                                           // 00000035F950: 7E6639B7
	s_waitcnt vmcnt(7)                                         // 00000035F954: BF891FF7
	v_dot2_f32_bf16 v18, v21, v91, 0                           // 00000035F958: CC1A4012 1A02B715
	v_dot2_f32_bf16 v17, v26, v92, v17                         // 00000035F960: CC1A4011 1C46B91A
	v_bfe_u32 v55, v54, 16, 1                                  // 00000035F968: D6100037 02052136
	v_dot2_f32_bf16 v3, v19, v93, v3                           // 00000035F970: CC1A4003 1C0EBB13
	v_and_b32_e32 v99, 48, v51                                 // 00000035F978: 36C666B0
	v_dot2_f32_bf16 v21, v22, v92, v18                         // 00000035F97C: CC1A4015 1C4AB916
	v_dot2_f32_bf16 v22, v27, v93, v17                         // 00000035F984: CC1A4016 1C46BB1B
	global_load_b128 v[13:16], v[62:63], off offset:16         // 00000035F98C: DC5E0010 0D7C003E
	v_dot2_f32_bf16 v116, v20, v1, v3                          // 00000035F994: CC1A4074 1C0E0314
	v_and_or_b32 v99, v119, 15, v99                            // 00000035F99C: D6570063 058D1F77
	v_dot2_f32_bf16 v3, v23, v93, v21                          // 00000035F9A4: CC1A4003 1C56BB17
	v_dot2_f32_bf16 v117, v28, v1, v22                         // 00000035F9AC: CC1A4075 1C5A031C
	global_load_b128 v[25:28], v[68:69], off offset:16         // 00000035F9B4: DC5E0010 197C0044
	s_waitcnt vmcnt(8)                                         // 00000035F9BC: BF8923F7
	v_dot2_f32_bf16 v33, v33, v91, 0                           // 00000035F9C0: CC1A4021 1A02B721
	global_load_b128 v[17:20], v[66:67], off offset:16         // 00000035F9C8: DC5E0010 117C0042
	v_dot2_f32_bf16 v118, v24, v1, v3                          // 00000035F9D0: CC1A4076 1C0E0318
	v_add3_u32 v3, v54, v55, 0x7fff                            // 00000035F9D8: D6550003 03FE6F36 00007FFF
	.long 0x7f6c39b3                                           // 00000035F9E4: 7F6C39B3
	v_cvt_f32_ubyte0_e32 v55, v99                              // 00000035F9E8: 7E6E2363
	v_dot2_f32_bf16 v33, v34, v92, v33                         // 00000035F9EC: CC1A4021 1C86B922
	s_waitcnt vmcnt(8)                                         // 00000035F9F4: BF8923F7
	v_dot2_f32_bf16 v34, v45, v91, 0                           // 00000035F9F8: CC1A4022 1A02B72D
	.long 0x7e6c3982                                           // 00000035FA00: 7E6C3982
	v_cvt_f32_ubyte0_e32 v45, v98                              // 00000035FA04: 7E5A2362
	v_fma_mix_f32 v2, v55, v90, v90 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035FA08: CC206002 156AB537
	v_dot2_f32_bf16 v33, v35, v93, v33                         // 00000035FA10: CC1A4021 1C86BB23
	v_dot2_f32_bf16 v34, v46, v92, v34                         // 00000035FA18: CC1A4022 1C8AB92E
	v_and_or_b32 v91, 0xffff0000, v3, v54                      // 00000035FA20: D657005B 04DA06FF FFFF0000
	v_fma_mix_f32 v55, v45, v90, v90 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035FA2C: CC206037 156AB52D
	v_bfe_u32 v3, v2, 16, 1                                    // 00000035FA34: D6100003 02052102
	v_dot2_f32_bf16 v92, v36, v1, v33                          // 00000035FA3C: CC1A405C 1C860324
	v_dot2_f32_bf16 v45, v47, v93, v34                         // 00000035FA44: CC1A402D 1C8ABB2F
	s_waitcnt vmcnt(7)                                         // 00000035FA4C: BF891FF7
	v_dot2_f32_bf16 v37, v37, v91, v103                        // 00000035FA50: CC1A4025 1D9EB725
	v_bfe_u32 v54, v55, 16, 1                                  // 00000035FA58: D6100036 02052137
	v_add3_u32 v2, v2, v3, 0x7fff                              // 00000035FA60: D6550002 03FE0702 00007FFF
	global_load_b128 v[21:24], v[60:61], off offset:32         // 00000035FA6C: DC5E0020 157C003C
	v_dot2_f32_bf16 v93, v48, v1, v45                          // 00000035FA74: CC1A405D 1CB60330
	v_dot2_f32_bf16 v1, v38, v127, v37                         // 00000035FA7C: CC1A4001 1C96FF26
	v_add3_u32 v3, v55, v54, 0x7fff                            // 00000035FA84: D6550003 03FE6D37 00007FFF
	.long 0x7e663982                                           // 00000035FA90: 7E663982
	s_clause 0x1                                               // 00000035FA94: BF850001
	global_load_b128 v[45:48], v[56:57], off offset:32         // 00000035FA98: DC5E0020 2D7C0038
	global_load_b128 v[102:105], v[58:59], off offset:32       // 00000035FAA0: DC5E0020 667C003A
	v_and_or_b32 v119, v120, 48, v108                          // 00000035FAA8: D6570077 05B16178
	v_dot2_f32_bf16 v37, v39, v110, v1                         // 00000035FAB0: CC1A4025 1C06DD27
	v_and_or_b32 v120, v106, 48, v107                          // 00000035FAB8: D6570078 05AD616A
	global_load_b128 v[106:109], v[62:63], off offset:32       // 00000035FAC0: DC5E0020 6A7C003E
	v_and_or_b32 v121, 0xffff0000, v3, v51                     // 00000035FAC8: D6570079 04CE06FF FFFF0000
	.long 0x7e663984                                           // 00000035FAD4: 7E663984
	global_load_b128 v[1:4], v[66:67], off offset:32           // 00000035FAD8: DC5E0020 017C0042
	v_dot2_f32_bf16 v122, v40, v111, v37                       // 00000035FAE0: CC1A407A 1C96DF28
	global_load_b128 v[37:40], v[68:69], off offset:32         // 00000035FAE8: DC5E0020 257C0044
	s_waitcnt vmcnt(12)                                        // 00000035FAF0: BF8933F7
	v_dot2_f32_bf16 v29, v29, v91, v114                        // 00000035FAF4: CC1A401D 1DCAB71D
	s_waitcnt vmcnt(11)                                        // 00000035FAFC: BF892FF7
	v_dot2_f32_bf16 v41, v41, v91, v116                        // 00000035FB00: CC1A4029 1DD2B729
	v_and_b32_e32 v54, 48, v126                                // 00000035FB08: 366CFCB0
	s_clause 0x1                                               // 00000035FB0C: BF850001
	global_load_b128 v[98:101], v[64:65], off offset:48        // 00000035FB10: DC5E0030 627C0040
	global_load_b128 v[33:36], v[60:61], off offset:48         // 00000035FB18: DC5E0030 217C003C
	v_dot2_f32_bf16 v29, v30, v127, v29                        // 00000035FB20: CC1A401D 1C76FF1E
	v_dot2_f32_bf16 v41, v42, v127, v41                        // 00000035FB28: CC1A4029 1CA6FF2A
	v_and_b32_e32 v30, 48, v124                                // 00000035FB30: 363CF8B0
	v_and_or_b32 v116, v129, 15, v54                           // 00000035FB34: D6570074 04D91F81
	global_load_b128 v[54:57], v[56:57], off offset:48         // 00000035FB3C: DC5E0030 367C0038
	v_dot2_f32_bf16 v29, v31, v110, v29                        // 00000035FB44: CC1A401D 1C76DD1F
	v_dot2_f32_bf16 v41, v43, v110, v41                        // 00000035FB4C: CC1A4029 1CA6DD2B
	v_and_or_b32 v114, v128, 15, v30                           // 00000035FB54: D6570072 04791F80
	v_cvt_f32_ubyte0_e32 v116, v116                            // 00000035FB5C: 7EE82374
	s_delay_alu instid0(VALU_DEP_4)                            // 00000035FB60: BF870004
	v_dot2_f32_bf16 v124, v32, v111, v29                       // 00000035FB64: CC1A407C 1C76DF20
	s_clause 0x1                                               // 00000035FB6C: BF850001
	global_load_b128 v[29:32], v[58:59], off offset:48         // 00000035FB70: DC5E0030 1D7C003A
	global_load_b128 v[58:61], v[62:63], off offset:48         // 00000035FB78: DC5E0030 3A7C003E
	v_dot2_f32_bf16 v126, v44, v111, v41                       // 00000035FB80: CC1A407E 1CA6DF2C
	s_clause 0x1                                               // 00000035FB88: BF850001
	global_load_b128 v[41:44], v[66:67], off offset:48         // 00000035FB8C: DC5E0030 297C0042
	global_load_b128 v[62:65], v[68:69], off offset:48         // 00000035FB94: DC5E0030 3E7C0044
	v_and_b32_e32 v67, 48, v123                                // 00000035FB9C: 3686F6B0
	v_cvt_f32_ubyte0_e32 v66, v119                             // 00000035FBA0: 7E842377
	v_and_b32_e32 v68, 48, v125                                // 00000035FBA4: 3688FAB0
	v_cvt_f32_ubyte0_e32 v69, v114                             // 00000035FBA8: 7E8A2372
	v_cvt_f32_ubyte0_e32 v114, v120                            // 00000035FBAC: 7EE42378
	v_and_or_b32 v67, v51, 15, v67                             // 00000035FBB0: D6570043 050D1F33
	v_fma_mix_f32 v66, v66, v90, v90 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035FBB8: CC206042 156AB542
	v_and_or_b32 v68, v131, 15, v68                            // 00000035FBC0: D6570044 05111F83
	v_fma_mix_f32 v69, v69, v90, v90 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035FBC8: CC206045 156AB545
	v_fma_mix_f32 v116, v116, v90, v90 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035FBD0: CC206074 156AB574
	v_cvt_f32_ubyte0_e32 v67, v67                              // 00000035FBD8: 7E862343
	v_bfe_u32 v119, v66, 16, 1                                 // 00000035FBDC: D6100077 02052142
	v_cvt_f32_ubyte0_e32 v68, v68                              // 00000035FBE4: 7E882344
	v_fma_mix_f32 v114, v114, v90, v90 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035FBE8: CC206072 156AB572
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000035FBF0: BF870214
	v_fma_mix_f32 v67, v67, v90, v90 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035FBF4: CC206043 156AB543
	v_add3_u32 v66, v66, v119, 0x7fff                          // 00000035FBFC: D6550042 03FEEF42 00007FFF
	v_bfe_u32 v119, v69, 16, 1                                 // 00000035FC08: D6100077 02052145
	v_fma_mix_f32 v68, v68, v90, v90 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035FC10: CC206044 156AB544
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000035FC18: BF870214
	v_bfe_u32 v90, v67, 16, 1                                  // 00000035FC1C: D610005A 02052143
	.long 0x7e8439c2                                           // 00000035FC24: 7E8439C2
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 00000035FC28: BF870254
	v_add3_u32 v69, v69, v119, 0x7fff                          // 00000035FC2C: D6550045 03FEEF45 00007FFF
	v_bfe_u32 v119, v116, 16, 1                                // 00000035FC38: D6100077 02052174
	.long 0x7f8439b3                                           // 00000035FC40: 7F8439B3
	v_add3_u32 v67, v67, v90, 0x7fff                           // 00000035FC44: D6550043 03FEB543 00007FFF
	v_bfe_u32 v90, v114, 16, 1                                 // 00000035FC50: D610005A 02052172
	v_add3_u32 v116, v116, v119, 0x7fff                        // 00000035FC58: D6550074 03FEEF74 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000035FC64: BF8700B3
	.long 0x7e6639c3                                           // 00000035FC68: 7E6639C3
	s_waitcnt vmcnt(16)                                        // 00000035FC6C: BF8943F7
	v_dot2_f32_bf16 v9, v9, v91, v117                          // 00000035FC70: CC1A4009 1DD6B709
	v_dot2_f32_bf16 v9, v10, v127, v9                          // 00000035FC78: CC1A4009 1C26FF0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000035FC80: BF870091
	v_dot2_f32_bf16 v9, v11, v110, v9                          // 00000035FC84: CC1A4009 1C26DD0B
	v_dot2_f32_bf16 v9, v12, v111, v9                          // 00000035FC8C: CC1A4009 1C26DF0C
	s_waitcnt vmcnt(15)                                        // 00000035FC94: BF893FF7
	v_dot2_f32_bf16 v10, v13, v91, v118                        // 00000035FC98: CC1A400A 1DDAB70D
	v_bfe_u32 v13, v68, 16, 1                                  // 00000035FCA0: D610000D 02052144
	s_waitcnt vmcnt(14)                                        // 00000035FCA8: BF893BF7
	v_dot2_f32_bf16 v11, v25, v91, v93                         // 00000035FCAC: CC1A400B 1D76B719
	s_delay_alu instid0(VALU_DEP_3)                            // 00000035FCB4: BF870003
	v_dot2_f32_bf16 v10, v14, v127, v10                        // 00000035FCB8: CC1A400A 1C2AFF0E
	s_waitcnt vmcnt(13)                                        // 00000035FCC0: BF8937F7
	v_dot2_f32_bf16 v17, v17, v91, v92                         // 00000035FCC4: CC1A4011 1D72B711
	v_add3_u32 v13, v68, v13, 0x7fff                           // 00000035FCCC: D655000D 03FE1B44 00007FFF
	v_dot2_f32_bf16 v14, v94, v130, v122                       // 00000035FCD8: CC1A400E 1DEB055E
	v_dot2_f32_bf16 v11, v26, v127, v11                        // 00000035FCE0: CC1A400B 1C2EFF1A
	v_dot2_f32_bf16 v10, v15, v110, v10                        // 00000035FCE8: CC1A400A 1C2ADD0F
	v_dot2_f32_bf16 v17, v18, v127, v17                        // 00000035FCF0: CC1A4011 1C46FF12
	v_and_or_b32 v18, 0xffff0000, v116, v51                    // 00000035FCF8: D6570012 04CEE8FF FFFF0000
	.long 0x7e66398d                                           // 00000035FD04: 7E66398D
	v_dot2_f32_bf16 v11, v27, v110, v11                        // 00000035FD08: CC1A400B 1C2EDD1B
	v_dot2_f32_bf16 v10, v16, v111, v10                        // 00000035FD10: CC1A400A 1C2ADF10
	v_dot2_f32_bf16 v15, v19, v110, v17                        // 00000035FD18: CC1A400F 1C46DD13
	v_dot2_f32_bf16 v12, v95, v113, v14                        // 00000035FD20: CC1A400C 1C3AE35F
	v_and_or_b32 v16, 0xffff0000, v69, v66                     // 00000035FD28: D6570010 050A8AFF FFFF0000
	v_dot2_f32_bf16 v11, v28, v111, v11                        // 00000035FD34: CC1A400B 1C2EDF1C
	v_add3_u32 v17, v114, v90, 0x7fff                          // 00000035FD3C: D6550011 03FEB572 00007FFF
	v_dot2_f32_bf16 v15, v20, v111, v15                        // 00000035FD48: CC1A400F 1C3EDF14
	v_dot2_f32_bf16 v12, v96, v112, v12                        // 00000035FD50: CC1A400C 1C32E160
	v_mov_b32_e32 v90, v89                                     // 00000035FD58: 7EB40359
	s_delay_alu instid0(VALU_DEP_4)                            // 00000035FD5C: BF870004
	v_and_or_b32 v17, 0xffff0000, v17, v51                     // 00000035FD60: D6570011 04CE22FF FFFF0000
	s_waitcnt vmcnt(12)                                        // 00000035FD6C: BF8933F7
	v_dot2_f32_bf16 v21, v21, v130, v124                       // 00000035FD70: CC1A4015 1DF30515
	v_dot2_f32_bf16 v12, v97, v115, v12                        // 00000035FD78: CC1A400C 1C32E761
	s_waitcnt vmcnt(11)                                        // 00000035FD80: BF892FF7
	v_dot2_f32_bf16 v13, v45, v130, v126                       // 00000035FD84: CC1A400D 1DFB052D
	s_waitcnt vmcnt(10)                                        // 00000035FD8C: BF892BF7
	v_dot2_f32_bf16 v9, v102, v130, v9                         // 00000035FD90: CC1A4009 1C270566
	v_dot2_f32_bf16 v14, v22, v113, v21                        // 00000035FD98: CC1A400E 1C56E316
	s_waitcnt vmcnt(9)                                         // 00000035FDA0: BF8927F7
	v_dot2_f32_bf16 v10, v106, v130, v10                       // 00000035FDA4: CC1A400A 1C2B056A
	v_dot2_f32_bf16 v13, v46, v113, v13                        // 00000035FDAC: CC1A400D 1C36E32E
	v_dot2_f32_bf16 v9, v103, v113, v9                         // 00000035FDB4: CC1A4009 1C26E367
	s_waitcnt vmcnt(8)                                         // 00000035FDBC: BF8923F7
	v_dot2_f32_bf16 v1, v1, v130, v15                          // 00000035FDC0: CC1A4001 1C3F0501
	v_dot2_f32_bf16 v14, v23, v112, v14                        // 00000035FDC8: CC1A400E 1C3AE117
	s_waitcnt vmcnt(7)                                         // 00000035FDD0: BF891FF7
	v_dot2_f32_bf16 v11, v37, v130, v11                        // 00000035FDD4: CC1A400B 1C2F0525
	v_dot2_f32_bf16 v10, v107, v113, v10                       // 00000035FDDC: CC1A400A 1C2AE36B
	v_dot2_f32_bf16 v9, v104, v112, v9                         // 00000035FDE4: CC1A4009 1C26E168
	v_dot2_f32_bf16 v1, v2, v113, v1                           // 00000035FDEC: CC1A4001 1C06E302
	v_dot2_f32_bf16 v14, v24, v115, v14                        // 00000035FDF4: CC1A400E 1C3AE718
	v_dot2_f32_bf16 v2, v38, v113, v11                         // 00000035FDFC: CC1A4002 1C2EE326
	v_dot2_f32_bf16 v11, v47, v112, v13                        // 00000035FE04: CC1A400B 1C36E12F
	v_dot2_f32_bf16 v10, v108, v112, v10                       // 00000035FE0C: CC1A400A 1C2AE16C
	v_dot2_f32_bf16 v1, v3, v112, v1                           // 00000035FE14: CC1A4001 1C06E103
	v_dot2_f32_bf16 v9, v105, v115, v9                         // 00000035FE1C: CC1A4009 1C26E769
	v_dot2_f32_bf16 v2, v39, v112, v2                          // 00000035FE24: CC1A4002 1C0AE127
	v_dot2_f32_bf16 v3, v48, v115, v11                         // 00000035FE2C: CC1A4003 1C2EE730
	v_dot2_f32_bf16 v10, v109, v115, v10                       // 00000035FE34: CC1A400A 1C2AE76D
	v_dot2_f32_bf16 v1, v4, v115, v1                           // 00000035FE3C: CC1A4001 1C06E704
	s_waitcnt vmcnt(6)                                         // 00000035FE44: BF891BF7
	v_dot2_f32_bf16 v12, v98, v16, v12                         // 00000035FE48: CC1A400C 1C322162
	v_dot2_f32_bf16 v2, v40, v115, v2                          // 00000035FE50: CC1A4002 1C0AE728
	s_waitcnt vmcnt(5)                                         // 00000035FE58: BF8917F7
	v_dot2_f32_bf16 v14, v33, v16, v14                         // 00000035FE5C: CC1A400E 1C3A2121
	s_waitcnt vmcnt(4)                                         // 00000035FE64: BF8913F7
	v_dot2_f32_bf16 v3, v54, v16, v3                           // 00000035FE68: CC1A4003 1C0E2136
	s_waitcnt vmcnt(3)                                         // 00000035FE70: BF890FF7
	v_dot2_f32_bf16 v4, v29, v16, v9                           // 00000035FE74: CC1A4004 1C26211D
	s_waitcnt vmcnt(2)                                         // 00000035FE7C: BF890BF7
	v_dot2_f32_bf16 v9, v58, v16, v10                          // 00000035FE80: CC1A4009 1C2A213A
	s_waitcnt vmcnt(1)                                         // 00000035FE88: BF8907F7
	v_dot2_f32_bf16 v1, v41, v16, v1                           // 00000035FE8C: CC1A4001 1C062129
	s_waitcnt vmcnt(0)                                         // 00000035FE94: BF8903F7
	v_dot2_f32_bf16 v2, v62, v16, v2                           // 00000035FE98: CC1A4002 1C0A213E
	v_dot2_f32_bf16 v12, v99, v121, v12                        // 00000035FEA0: CC1A400C 1C32F363
	v_dot2_f32_bf16 v14, v34, v121, v14                        // 00000035FEA8: CC1A400E 1C3AF322
	v_dot2_f32_bf16 v3, v55, v121, v3                          // 00000035FEB0: CC1A4003 1C0EF337
	v_dot2_f32_bf16 v4, v30, v121, v4                          // 00000035FEB8: CC1A4004 1C12F31E
	v_dot2_f32_bf16 v9, v59, v121, v9                          // 00000035FEC0: CC1A4009 1C26F33B
	v_dot2_f32_bf16 v1, v42, v121, v1                          // 00000035FEC8: CC1A4001 1C06F32A
	v_dot2_f32_bf16 v2, v63, v121, v2                          // 00000035FED0: CC1A4002 1C0AF33F
	v_dot2_f32_bf16 v12, v100, v18, v12                        // 00000035FED8: CC1A400C 1C322564
	v_dot2_f32_bf16 v14, v35, v18, v14                         // 00000035FEE0: CC1A400E 1C3A2523
	v_dot2_f32_bf16 v3, v56, v18, v3                           // 00000035FEE8: CC1A4003 1C0E2538
	v_dot2_f32_bf16 v4, v31, v18, v4                           // 00000035FEF0: CC1A4004 1C12251F
	v_dot2_f32_bf16 v9, v60, v18, v9                           // 00000035FEF8: CC1A4009 1C26253C
	v_dot2_f32_bf16 v1, v43, v18, v1                           // 00000035FF00: CC1A4001 1C06252B
	v_dot2_f32_bf16 v2, v64, v18, v2                           // 00000035FF08: CC1A4002 1C0A2540
	v_dot2_f32_bf16 v12, v101, v17, v12                        // 00000035FF10: CC1A400C 1C322365
	v_dot2_f32_bf16 v14, v36, v17, v14                         // 00000035FF18: CC1A400E 1C3A2324
	v_dot2_f32_bf16 v3, v57, v17, v3                           // 00000035FF20: CC1A4003 1C0E2339
	v_dot2_f32_bf16 v4, v32, v17, v4                           // 00000035FF28: CC1A4004 1C122320
	v_dot2_f32_bf16 v9, v61, v17, v9                           // 00000035FF30: CC1A4009 1C26233D
	v_dot2_f32_bf16 v1, v44, v17, v1                           // 00000035FF38: CC1A4001 1C06232C
	v_dot2_f32_bf16 v2, v65, v17, v2                           // 00000035FF40: CC1A4002 1C0A2341
	v_dual_add_f32 v81, v81, v12 :: v_dual_add_f32 v80, v80, v14// 00000035FF48: C9081951 51501D50
	v_dual_add_f32 v79, v79, v3 :: v_dual_add_f32 v78, v78, v4 // 00000035FF50: C908074F 4F4E094E
	v_add_f32_e32 v77, v77, v9                                 // 00000035FF58: 069A134D
	v_add_f32_e32 v76, v76, v1                                 // 00000035FF5C: 0698034C
	v_dual_add_f32 v72, v72, v2 :: v_dual_mov_b32 v55, v53     // 00000035FF60: C9100548 48360135
	v_mov_b32_e32 v54, v52                                     // 00000035FF68: 7E6C0334
	v_dual_mov_b32 v4, v8 :: v_dual_mov_b32 v3, v7             // 00000035FF6C: CA100108 04020107
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v1, v5             // 00000035FF74: CA100106 02000105
	s_and_not1_b32 exec_lo, exec_lo, s15                       // 00000035FF7C: 917E0F7E
	s_cbranch_execz 39                                         // 00000035FF80: BFA50027 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi7ELi32ELi8EEEvNS0_5LqGrpEPKtl+0x1120>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000035FF84: BF870111
	v_dual_mov_b32 v6, v2 :: v_dual_add_nc_u32 v73, 32, v73    // 00000035FF88: CA200102 064892A0
	v_dual_mov_b32 v5, v1 :: v_dual_mov_b32 v8, v4             // 00000035FF90: CA100101 05080104
	v_dual_mov_b32 v7, v3 :: v_dual_mov_b32 v52, v54           // 00000035FF98: CA100103 07340136
	v_mov_b32_e32 v53, v55                                     // 00000035FFA0: 7E6A0337
	s_mov_b32 s17, exec_lo                                     // 00000035FFA4: BE91007E
	v_cmp_ge_i32_e32 vcc_lo, v73, v74                          // 00000035FFA8: 7C8C9549
	.long 0xd4c1007e                                           // 00000035FFAC: D4C1007E
	v_cndmask_b32_e32 v1, v73, v74, vcc_lo                     // 00000035FFB0: 02029549
	s_cbranch_execz 64663                                      // 00000035FFB4: BFA5FC97 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi7ELi32ELi8EEEvNS0_5LqGrpEPKtl+0x314>
	v_and_b32_e32 v7, -4, v88                                  // 00000035FFB8: 360EB0C4
	v_ashrrev_i32_e32 v6, 31, v86                              // 00000035FFBC: 340CAC9F
	v_ashrrev_i32_e32 v8, 31, v87                              // 00000035FFC0: 3410AE9F
	.long 0xd7000005                                           // 00000035FFC4: D7000005
	v_cndmask_b32_e32 v1, v49, v86, vcc_lo                     // 00000035FFC8: 0202AD31
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000035FFCC: BF870214
	v_ashrrev_i32_e32 v12, 31, v7                              // 00000035FFD0: 34180E9F
	v_add_co_ci_u32_e64 v6, null, v75, v6, s0                  // 00000035FFD4: D5207C06 00020D4B
	.long 0xd7000009                                           // 00000035FFDC: D7000009
	v_cndmask_b32_e32 v1, v82, v87, vcc_lo                     // 00000035FFE0: 0202AF52
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000035FFE4: BF8700A1
	v_add_co_ci_u32_e64 v10, null, v83, v8, s0                 // 00000035FFE8: D5207C0A 00021153
	.long 0xd700000b                                           // 00000035FFF0: D700000B
	v_cndmask_b32_e32 v1, v84, v7, vcc_lo                      // 00000035FFF4: 02020F54
	v_add_co_ci_u32_e64 v12, null, v85, v12, s0                // 00000035FFF8: D5207C0C 00021955
	s_clause 0x2                                               // 000000360000: BF850002
	global_load_b128 v[5:8], v[5:6], off                       // 000000360004: DC5E0000 057C0005
	global_load_b64 v[52:53], v[9:10], off                     // 00000036000C: DC560000 347C0009
	global_load_b32 v89, v[11:12], off                         // 000000360014: DC520000 597C000B
	s_branch 64637                                             // 00000036001C: BFA0FC7D <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi7ELi32ELi8EEEvNS0_5LqGrpEPKtl+0x314>
	s_or_b32 exec_lo, exec_lo, s15                             // 000000360020: 8C7E0F7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000360024: BF8700C9
	s_or_b32 exec_lo, exec_lo, s1                              // 000000360028: 8C7E017E
	s_waitcnt vmcnt(2)                                         // 00000036002C: BF890BF7
	.long 0xd71f0001                                           // 000000360030: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000360034: 020100C1
	s_mov_b32 s0, exec_lo                                      // 000000360038: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 00000036003C: 3A040290
	v_xor_b32_e32 v9, 8, v1                                    // 000000360040: 3A120288
	v_xor_b32_e32 v16, 4, v1                                   // 000000360044: 3A200284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000360048: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 00000036004C: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 000000360050: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v9                            // 000000360054: 7C9812A0
	v_cndmask_b32_e32 v9, v1, v9, vcc_lo                       // 000000360058: 02121301
	v_cmp_gt_u32_e32 vcc_lo, 32, v16                           // 00000036005C: 7C9820A0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000360060: BF870002
	v_lshlrev_b32_e32 v9, 2, v9                                // 000000360064: 30121282
	v_lshlrev_b32_e32 v2, 2, v2                                // 000000360068: 30040482
	ds_bpermute_b32 v3, v2, v81                                // 00000036006C: DACC0000 03005102
	s_waitcnt lgkmcnt(0)                                       // 000000360074: BF89FC07
	v_add_f32_e32 v3, v81, v3                                  // 000000360078: 06060751
	ds_bpermute_b32 v5, v2, v79                                // 00000036007C: DACC0000 05004F02
	ds_bpermute_b32 v6, v2, v78                                // 000000360084: DACC0000 06004E02
	ds_bpermute_b32 v7, v2, v77                                // 00000036008C: DACC0000 07004D02
	ds_bpermute_b32 v4, v2, v80                                // 000000360094: DACC0000 04005002
	ds_bpermute_b32 v8, v2, v76                                // 00000036009C: DACC0000 08004C02
	ds_bpermute_b32 v2, v2, v72                                // 0000003600A4: DACC0000 02004802
	ds_bpermute_b32 v10, v9, v3                                // 0000003600AC: DACC0000 0A000309
	s_waitcnt lgkmcnt(6)                                       // 0000003600B4: BF89FC67
	v_dual_cndmask_b32 v16, v1, v16 :: v_dual_add_f32 v5, v79, v5// 0000003600B8: CA482101 10040B4F
	s_waitcnt lgkmcnt(4)                                       // 0000003600C0: BF89FC47
	v_dual_add_f32 v6, v78, v6 :: v_dual_add_f32 v7, v77, v7   // 0000003600C4: C9080D4E 06060F4D
	s_waitcnt lgkmcnt(3)                                       // 0000003600CC: BF89FC37
	v_add_f32_e32 v4, v80, v4                                  // 0000003600D0: 06080950
	s_waitcnt lgkmcnt(2)                                       // 0000003600D4: BF89FC27
	v_add_f32_e32 v8, v76, v8                                  // 0000003600D8: 0610114C
	ds_bpermute_b32 v12, v9, v5                                // 0000003600DC: DACC0000 0C000509
	s_waitcnt lgkmcnt(2)                                       // 0000003600E4: BF89FC27
	v_add_f32_e32 v2, v72, v2                                  // 0000003600E8: 06040548
	ds_bpermute_b32 v14, v9, v7                                // 0000003600EC: DACC0000 0E000709
	ds_bpermute_b32 v11, v9, v4                                // 0000003600F4: DACC0000 0B000409
	ds_bpermute_b32 v13, v9, v6                                // 0000003600FC: DACC0000 0D000609
	ds_bpermute_b32 v15, v9, v8                                // 000000360104: DACC0000 0F000809
	s_waitcnt lgkmcnt(5)                                       // 00000036010C: BF89FC57
	v_dual_add_f32 v3, v3, v10 :: v_dual_lshlrev_b32 v16, 2, v16// 000000360110: C9221503 03102082
	s_waitcnt lgkmcnt(4)                                       // 000000360118: BF89FC47
	v_add_f32_e32 v5, v5, v12                                  // 00000036011C: 060A1905
	ds_bpermute_b32 v9, v9, v2                                 // 000000360120: DACC0000 09000209
	s_waitcnt lgkmcnt(0)                                       // 000000360128: BF89FC07
	v_dual_add_f32 v7, v7, v14 :: v_dual_add_f32 v2, v2, v9    // 00000036012C: C9081D07 07021302
	ds_bpermute_b32 v9, v16, v3                                // 000000360134: DACC0000 09000310
	v_add_f32_e32 v4, v4, v11                                  // 00000036013C: 06081704
	ds_bpermute_b32 v11, v16, v5                               // 000000360140: DACC0000 0B000510
	v_add_f32_e32 v6, v6, v13                                  // 000000360148: 060C1B06
	ds_bpermute_b32 v13, v16, v7                               // 00000036014C: DACC0000 0D000710
	v_add_f32_e32 v8, v8, v15                                  // 000000360154: 06101F08
	ds_bpermute_b32 v15, v16, v2                               // 000000360158: DACC0000 0F000210
	s_waitcnt lgkmcnt(3)                                       // 000000360160: BF89FC37
	v_add_f32_e32 v3, v3, v9                                   // 000000360164: 06061303
	ds_bpermute_b32 v10, v16, v4                               // 000000360168: DACC0000 0A000410
	s_waitcnt lgkmcnt(3)                                       // 000000360170: BF89FC37
	v_add_f32_e32 v5, v5, v11                                  // 000000360174: 060A1705
	ds_bpermute_b32 v12, v16, v6                               // 000000360178: DACC0000 0C000610
	s_waitcnt lgkmcnt(3)                                       // 000000360180: BF89FC37
	v_add_f32_e32 v7, v7, v13                                  // 000000360184: 060E1B07
	ds_bpermute_b32 v14, v16, v8                               // 000000360188: DACC0000 0E000810
	v_xor_b32_e32 v16, 2, v1                                   // 000000360190: 3A200282
	s_waitcnt lgkmcnt(3)                                       // 000000360194: BF89FC37
	v_add_f32_e32 v9, v2, v15                                  // 000000360198: 06121F02
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000036019C: BF8700A2
	v_cmp_gt_u32_e32 vcc_lo, 32, v16                           // 0000003601A0: 7C9820A0
	v_cndmask_b32_e32 v16, v1, v16, vcc_lo                     // 0000003601A4: 02202101
	v_lshlrev_b32_e32 v16, 2, v16                              // 0000003601A8: 30202082
	s_waitcnt lgkmcnt(0)                                       // 0000003601AC: BF89FC07
	v_add_f32_e32 v8, v8, v14                                  // 0000003601B0: 06101D08
	ds_bpermute_b32 v13, v16, v7                               // 0000003601B4: DACC0000 0D000710
	v_add_f32_e32 v4, v4, v10                                  // 0000003601BC: 06081504
	ds_bpermute_b32 v15, v16, v9                               // 0000003601C0: DACC0000 0F000910
	v_add_f32_e32 v6, v6, v12                                  // 0000003601C8: 060C1906
	ds_bpermute_b32 v2, v16, v3                                // 0000003601CC: DACC0000 02000310
	ds_bpermute_b32 v11, v16, v5                               // 0000003601D4: DACC0000 0B000510
	ds_bpermute_b32 v10, v16, v4                               // 0000003601DC: DACC0000 0A000410
	ds_bpermute_b32 v14, v16, v8                               // 0000003601E4: DACC0000 0E000810
	ds_bpermute_b32 v12, v16, v6                               // 0000003601EC: DACC0000 0C000610
	v_xor_b32_e32 v16, 1, v1                                   // 0000003601F4: 3A200281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000003601F8: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v16                           // 0000003601FC: 7C9820A0
	v_cndmask_b32_e32 v1, v1, v16, vcc_lo                      // 000000360200: 02022101
	s_waitcnt lgkmcnt(4)                                       // 000000360204: BF89FC47
	v_dual_add_f32 v1, v3, v2 :: v_dual_lshlrev_b32 v16, 2, v1 // 000000360208: C9220503 01100282
	s_waitcnt lgkmcnt(3)                                       // 000000360210: BF89FC37
	v_dual_add_f32 v2, v5, v11 :: v_dual_add_f32 v3, v7, v13   // 000000360214: C9081705 02021B07
	s_waitcnt lgkmcnt(2)                                       // 00000036021C: BF89FC27
	v_dual_add_f32 v4, v4, v10 :: v_dual_add_f32 v5, v9, v15   // 000000360220: C9081504 04041F09
	s_waitcnt lgkmcnt(0)                                       // 000000360228: BF89FC07
	v_add_f32_e32 v6, v6, v12                                  // 00000036022C: 060C1906
	v_add_f32_e32 v12, v8, v14                                 // 000000360230: 06181D08
	ds_bpermute_b32 v7, v16, v1                                // 000000360234: DACC0000 07000110
	ds_bpermute_b32 v10, v16, v4                               // 00000036023C: DACC0000 0A000410
	ds_bpermute_b32 v8, v16, v2                                // 000000360244: DACC0000 08000210
	ds_bpermute_b32 v13, v16, v6                               // 00000036024C: DACC0000 0D000610
	ds_bpermute_b32 v9, v16, v3                                // 000000360254: DACC0000 09000310
	ds_bpermute_b32 v14, v16, v12                              // 00000036025C: DACC0000 0E000C10
	ds_bpermute_b32 v11, v16, v5                               // 000000360264: DACC0000 0B000510
	v_cmpx_eq_u32_e32 0, v71                                   // 00000036026C: 7D948E80
	s_cbranch_execz 18                                         // 000000360270: BFA50012 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi7ELi32ELi8EEEvNS0_5LqGrpEPKtl+0x13bc>
	s_waitcnt lgkmcnt(1)                                       // 000000360274: BF89FC17
	v_dual_add_f32 v12, v12, v14 :: v_dual_add_f32 v1, v1, v7  // 000000360278: C9081D0C 0C000F01
	v_dual_add_f32 v4, v4, v10 :: v_dual_add_f32 v3, v3, v9    // 000000360280: C9081504 04021303
	v_mul_u32_u24_e32 v7, 28, v70                              // 000000360288: 160E8C9C
	s_waitcnt lgkmcnt(0)                                       // 00000036028C: BF89FC07
	v_dual_add_f32 v6, v6, v13 :: v_dual_add_f32 v5, v5, v11   // 000000360290: C9081B06 06041705
	v_add_f32_e32 v2, v2, v8                                   // 000000360298: 06041102
	ds_store_2addr_b32 v7, v1, v4 offset1:1                    // 00000036029C: D8380100 00040107
	ds_store_2addr_b32 v7, v2, v6 offset0:2 offset1:3          // 0000003602A4: D8380302 00060207
	ds_store_2addr_b32 v7, v3, v12 offset0:4 offset1:5         // 0000003602AC: D8380504 000C0307
	ds_store_b32 v7, v5 offset:24                              // 0000003602B4: D8340018 00000507
	s_or_b32 exec_lo, exec_lo, s0                              // 0000003602BC: 8C7E007E
	.long 0xd4510000                                           // 0000003602C0: D4510000
	v_cndmask_b32_e32 v0, s2, v8, vcc_lo                       // 0000003602C4: 02001002
	v_cmp_gt_u32_e32 vcc_lo, 7, v0                             // 0000003602C8: 7C980087
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000003602CC: BF890007
	s_barrier                                                  // 0000003602D0: BFBD0000
	buffer_gl0_inv                                             // 0000003602D4: E0AC0000 00000000
	s_and_b32 s0, vcc_lo, s0                                   // 0000003602DC: 8B00006A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003602E0: BF870009
	s_and_saveexec_b32 s1, s0                                  // 0000003602E4: BE812000
	s_cbranch_execz 371                                        // 0000003602E8: BFA50173 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi7ELi32ELi8EEEvNS0_5LqGrpEPKtl+0x19b8>
	v_lshlrev_b32_e32 v7, 2, v0                                // 0000003602EC: 300E0082
	s_clause 0x1                                               // 0000003602F0: BF850001
	s_load_b64 s[4:5], s[10:11], 0x38                          // 0000003602F4: F4040105 F8000038
	s_load_b64 s[0:1], s[10:11], 0x8                           // 0000003602FC: F4040005 F8000008
	s_mov_b32 s12, 0                                           // 000000360304: BE8C0080
	s_mov_b32 s6, -1                                           // 000000360308: BE8600C1
	s_mov_b32 s7, 0                                            // 00000036030C: BE870080
	ds_load_2addr_b32 v[1:2], v7 offset1:7                     // 000000360310: D8DC0700 01000007
	ds_load_2addr_b32 v[3:4], v7 offset0:14 offset1:21         // 000000360318: D8DC150E 03000007
	ds_load_2addr_b32 v[5:6], v7 offset0:28 offset1:35         // 000000360320: D8DC231C 05000007
	s_waitcnt lgkmcnt(0)                                       // 000000360328: BF89FC07
	s_cmp_lt_i32 s5, 3                                         // 00000036032C: BF048305
	v_add_f32_e32 v1, 0, v1                                    // 000000360330: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000360334: BF870091
	v_add_f32_e32 v1, v1, v2                                   // 000000360338: 06020501
	v_add_f32_e32 v3, v1, v3                                   // 00000036033C: 06060701
	ds_load_2addr_b32 v[1:2], v7 offset0:42 offset1:49         // 000000360340: D8DC312A 01000007
	v_add_f32_e32 v3, v3, v4                                   // 000000360348: 06060903
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000036034C: BF870091
	v_add_f32_e32 v3, v3, v5                                   // 000000360350: 06060B03
	v_add_f32_e32 v3, v3, v6                                   // 000000360354: 06060D03
	s_waitcnt lgkmcnt(0)                                       // 000000360358: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000036035C: BF870091
	v_add_f32_e32 v1, v3, v1                                   // 000000360360: 06020303
	v_add_f32_e32 v1, v1, v2                                   // 000000360364: 06020501
	s_cbranch_scc1 176                                         // 000000360368: BFA200B0 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi7ELi32ELi8EEEvNS0_5LqGrpEPKtl+0x172c>
	s_cmp_gt_i32 s5, 3                                         // 00000036036C: BF028305
	s_cbranch_scc0 110                                         // 000000360370: BFA1006E <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi7ELi32ELi8EEEvNS0_5LqGrpEPKtl+0x162c>
	s_cmp_gt_i32 s5, 4                                         // 000000360374: BF028405
	s_cbranch_scc0 56                                          // 000000360378: BFA10038 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi7ELi32ELi8EEEvNS0_5LqGrpEPKtl+0x155c>
	s_cmp_eq_u32 s5, 5                                         // 00000036037C: BF068505
	s_mov_b32 s7, -1                                           // 000000360380: BE8700C1
	s_cbranch_scc0 52                                          // 000000360384: BFA10034 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi7ELi32ELi8EEEvNS0_5LqGrpEPKtl+0x1558>
	s_load_b64 s[10:11], s[10:11], 0x10                        // 000000360388: F4040285 F8000010
	s_mov_b32 s7, 0                                            // 000000360390: BE870080
	s_and_b32 s6, s2, 0x1ff                                    // 000000360394: 8B06FF02 000001FF
	s_lshr_b64 s[14:15], s[8:9], 1                             // 00000036039C: 858E8108
	.long 0xd45c000d                                           // 0000003603A0: D45C000D
	v_cndmask_b32_e32 v0, 0x100, v6, vcc_lo                    // 0000003603A4: 02000CFF 00000100
	v_mad_u64_u32 v[2:3], null, s14, v0, 0                     // 0000003603AC: D6FE7C02 0202000E
	s_and_b32 s14, s2, 0xfffffe00                              // 0000003603B4: 8B0EFF02 FFFFFE00
	s_and_b32 s15, s13, exec_lo                                // 0000003603BC: 8B0F7E0D
	s_waitcnt lgkmcnt(0)                                       // 0000003603C0: BF89FC07
	s_cselect_b32 s11, s1, s11                                 // 0000003603C4: 980B0B01
	s_cselect_b32 s15, s0, s10                                 // 0000003603C8: 980F0A00
	s_lshr_b32 s10, s9, 1                                      // 0000003603CC: 850A8109
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003603D0: BF870009
	v_mad_u64_u32 v[3:4], null, s10, v0, v[3:4]                // 0000003603D4: D6FE7C03 040E000A
	s_add_u32 s10, s6, 0xffffff00                              // 0000003603DC: 800AFF06 FFFFFF00
	s_addc_u32 s16, 0, -1                                      // 0000003603E4: 8210C180
	s_and_b32 s13, s13, exec_lo                                // 0000003603E8: 8B0D7E0D
	s_cselect_b32 s10, s6, s10                                 // 0000003603EC: 980A0A06
	v_bfe_u32 v4, v1, 16, 1                                    // 0000003603F0: D6100004 02052101
	.long 0xd73c0002                                           // 0000003603F8: D73C0002
	v_cndmask_b32_e32 v1, 1, v2, vcc_lo                        // 0000003603FC: 02020481
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000360400: BF870112
	v_add3_u32 v4, v1, v4, 0x7fff                              // 000000360404: D6550004 03FE0901 00007FFF
	.long 0xd7006a02                                           // 000000360410: D7006A02
	v_cndmask_b32_e32 v1, s15, v2, vcc_lo                      // 000000360414: 0202040F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000360418: BF8700B1
	v_add_co_ci_u32_e64 v3, null, s11, v3, vcc_lo              // 00000036041C: D5207C03 01AA060B
	s_cselect_b32 s11, 0, s16                                  // 000000360424: 980B1080
	.long 0xd7006a02                                           // 000000360428: D7006A02
	v_cndmask_b32_e32 v0, v2, v14, vcc_lo                      // 00000036042C: 02001D02
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 000000360430: D5207C03 01AA0680
	s_lshl_b64 s[10:11], s[10:11], 1                           // 000000360438: 848A810A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000036043C: BF870099
	.long 0xd7006a02                                           // 000000360440: D7006A02
	v_cndmask_b32_e32 v0, v2, v10, vcc_lo                      // 000000360444: 02001502
	v_add_co_ci_u32_e64 v3, null, s11, v3, vcc_lo              // 000000360448: D5207C03 01AA060B
	global_store_d16_hi_b16 v[2:3], v4, off                    // 000000360450: DC960000 007C0402
	s_mov_b32 s6, 0                                            // 000000360458: BE860080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000036045C: BF870009
	s_and_b32 vcc_lo, exec_lo, s6                              // 000000360460: 8B6A067E
	s_cbranch_vccz 48                                          // 000000360464: BFA30030 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi7ELi32ELi8EEEvNS0_5LqGrpEPKtl+0x1628>
	v_mul_f32_e32 v2, 0xbfb8aa3b, v1                           // 000000360468: 100402FF BFB8AA3B
	s_lshl_b64 s[10:11], s[2:3], 2                             // 000000360470: 848A8202
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000360474: BF870291
	v_exp_f32_e32 v2, v2                                       // 000000360478: 7E044B02
	v_add_f32_e32 v5, 1.0, v2                                  // 00000036047C: 060A04F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000360480: BF870121
	v_div_scale_f32 v6, null, v5, v5, 1.0                      // 000000360484: D6FC7C06 03CA0B05
	v_div_scale_f32 v8, vcc_lo, 1.0, v5, 1.0                   // 00000036048C: D6FC6A08 03CA0AF2
	v_rcp_f32_e32 v7, v6                                       // 000000360494: 7E0E5506
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000360498: BF870095
	v_fma_f32 v2, -v6, v7, 1.0                                 // 00000036049C: D6130002 23CA0F06
	v_fmac_f32_e32 v7, v2, v7                                  // 0000003604A4: 560E0F02
	v_mad_u64_u32 v[2:3], null, s8, v0, 0                      // 0000003604A8: D6FE7C02 02020008
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003604B0: BF870112
	v_mul_f32_e32 v9, v8, v7                                   // 0000003604B4: 10120F08
	v_mad_u64_u32 v[3:4], null, s9, v0, v[3:4]                 // 0000003604B8: D6FE7C03 040E0009
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003604C0: BF870092
	v_fma_f32 v10, -v6, v9, v8                                 // 0000003604C4: D613000A 24221306
	v_fmac_f32_e32 v9, v10, v7                                 // 0000003604CC: 56120F0A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003604D0: BF870113
	.long 0xd73c0002                                           // 0000003604D4: D73C0002
	v_cndmask_b32_e32 v1, 2, v2, vcc_lo                        // 0000003604D8: 02020482
	v_fma_f32 v4, -v6, v9, v8                                  // 0000003604DC: D6130004 24221306
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003604E4: BF870191
	v_div_fmas_f32 v4, v4, v7, v9                              // 0000003604E8: D6370004 04260F04
	.long 0xd7006a02                                           // 0000003604F0: D7006A02
	v_cndmask_b32_e32 v1, s0, v2, vcc_lo                       // 0000003604F4: 02020400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003604F8: BF870191
	v_add_co_ci_u32_e64 v3, null, s1, v3, vcc_lo               // 0000003604FC: D5207C03 01AA0601
	v_div_fixup_f32 v4, v4, v5, 1.0                            // 000000360504: D6270004 03CA0B04
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000036050C: BF870093
	.long 0xd7006a02                                           // 000000360510: D7006A02
	v_cndmask_b32_e32 v0, v2, v10, vcc_lo                      // 000000360514: 02001502
	v_add_co_ci_u32_e64 v3, null, s11, v3, vcc_lo              // 000000360518: D5207C03 01AA060B
	global_store_b32 v[2:3], v4, off                           // 000000360520: DC6A0000 007C0402
	s_mov_b32 s6, 0                                            // 000000360528: BE860080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000036052C: BF870009
	s_and_b32 vcc_lo, exec_lo, s6                              // 000000360530: 8B6A067E
	s_cbranch_vccz 60                                          // 000000360534: BFA3003C <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi7ELi32ELi8EEEvNS0_5LqGrpEPKtl+0x1728>
	v_bfe_u32 v2, v1, 16, 1                                    // 000000360538: D6100002 02052101
	s_lshl_b64 s[10:11], s[2:3], 2                             // 000000360540: 848A8202
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000360544: BF870091
	v_add3_u32 v2, v1, v2, 0x7fff                              // 000000360548: D6550002 03FE0501 00007FFF
	v_and_b32_e32 v2, 0xffff0000, v2                           // 000000360554: 360404FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000036055C: BF870091
	v_mul_f32_e32 v2, s4, v2                                   // 000000360560: 10040404
	v_mul_f32_e32 v2, 0xbfb8aa3b, v2                           // 000000360564: 100404FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000036056C: BF870291
	v_exp_f32_e32 v2, v2                                       // 000000360570: 7E044B02
	v_add_f32_e32 v5, 1.0, v2                                  // 000000360574: 060A04F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000360578: BF870121
	v_div_scale_f32 v6, null, v5, v5, 1.0                      // 00000036057C: D6FC7C06 03CA0B05
	v_div_scale_f32 v8, vcc_lo, 1.0, v5, 1.0                   // 000000360584: D6FC6A08 03CA0AF2
	v_rcp_f32_e32 v7, v6                                       // 00000036058C: 7E0E5506
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000360590: BF870095
	v_fma_f32 v2, -v6, v7, 1.0                                 // 000000360594: D6130002 23CA0F06
	v_fmac_f32_e32 v7, v2, v7                                  // 00000036059C: 560E0F02
	v_mad_u64_u32 v[2:3], null, s8, v0, 0                      // 0000003605A0: D6FE7C02 02020008
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003605A8: BF870092
	v_mul_f32_e32 v9, v8, v7                                   // 0000003605AC: 10120F08
	v_fma_f32 v4, -v6, v9, v8                                  // 0000003605B0: D6130004 24221306
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003605B8: BF870211
	v_fmac_f32_e32 v9, v4, v7                                  // 0000003605BC: 56120F04
	v_mad_u64_u32 v[3:4], null, s9, v0, v[3:4]                 // 0000003605C0: D6FE7C03 040E0009
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003605C8: BF870112
	v_fma_f32 v4, -v6, v9, v8                                  // 0000003605CC: D6130004 24221306
	.long 0xd73c0002                                           // 0000003605D4: D73C0002
	v_cndmask_b32_e32 v1, 2, v2, vcc_lo                        // 0000003605D8: 02020482
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003605DC: BF870112
	v_div_fmas_f32 v4, v4, v7, v9                              // 0000003605E0: D6370004 04260F04
	.long 0xd7006a02                                           // 0000003605E8: D7006A02
	v_cndmask_b32_e32 v1, s0, v2, vcc_lo                       // 0000003605EC: 02020400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003605F0: BF870212
	v_div_fixup_f32 v4, v4, v5, 1.0                            // 0000003605F4: D6270004 03CA0B04
	v_add_co_ci_u32_e64 v3, null, s1, v3, vcc_lo               // 0000003605FC: D5207C03 01AA0601
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000360604: BF870193
	.long 0xd7006a02                                           // 000000360608: D7006A02
	v_cndmask_b32_e32 v0, v2, v10, vcc_lo                      // 00000036060C: 02001502
	v_add_f32_e32 v4, v4, v4                                   // 000000360610: 06080904
	s_delay_alu instid0(VALU_DEP_3)                            // 000000360614: BF870003
	v_add_co_ci_u32_e64 v3, null, s11, v3, vcc_lo              // 000000360618: D5207C03 01AA060B
	global_store_b32 v[2:3], v4, off                           // 000000360620: DC6A0000 007C0402
	s_mov_b32 s6, 0                                            // 000000360628: BE860080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000036062C: BF870009
	s_and_b32 vcc_lo, exec_lo, s6                              // 000000360630: 8B6A067E
	s_cbranch_vccz 71                                          // 000000360634: BFA30047 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi7ELi32ELi8EEEvNS0_5LqGrpEPKtl+0x1854>
	s_cmp_gt_i32 s5, 1                                         // 000000360638: BF028105
	s_mov_b32 s6, -1                                           // 00000036063C: BE8600C1
	s_cbranch_scc0 63                                          // 000000360640: BFA1003F <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi7ELi32ELi8EEEvNS0_5LqGrpEPKtl+0x1840>
	v_bfe_u32 v2, v1, 16, 1                                    // 000000360644: D6100002 02052101
	s_lshl_b64 s[10:11], s[2:3], 1                             // 00000036064C: 848A8102
	s_mov_b32 s6, 0                                            // 000000360650: BE860080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000360654: BF870091
	v_add3_u32 v2, v1, v2, 0x7fff                              // 000000360658: D6550002 03FE0501 00007FFF
	v_and_b32_e32 v2, 0xffff0000, v2                           // 000000360664: 360404FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000036066C: BF870091
	v_mul_f32_e32 v2, 0xbfb8aa3b, v2                           // 000000360670: 100404FF BFB8AA3B
	v_exp_f32_e32 v2, v2                                       // 000000360678: 7E044B02
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000036067C: BF870095
	v_add_f32_e32 v5, 1.0, v2                                  // 000000360680: 060A04F2
	v_div_scale_f32 v4, null, v5, v5, 1.0                      // 000000360684: D6FC7C04 03CA0B05
	v_div_scale_f32 v7, vcc_lo, 1.0, v5, 1.0                   // 00000036068C: D6FC6A07 03CA0AF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000360694: BF870292
	v_rcp_f32_e32 v6, v4                                       // 000000360698: 7E0C5504
	v_fma_f32 v2, -v4, v6, 1.0                                 // 00000036069C: D6130002 23CA0D04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003606A4: BF870121
	v_fmac_f32_e32 v6, v2, v6                                  // 0000003606A8: 560C0D02
	v_mad_u64_u32 v[2:3], null, s8, v0, 0                      // 0000003606AC: D6FE7C02 02020008
	v_mul_f32_e32 v8, v7, v6                                   // 0000003606B4: 10100D07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003606B8: BF870091
	v_fma_f32 v9, -v4, v8, v7                                  // 0000003606BC: D6130009 241E1104
	v_fmac_f32_e32 v8, v9, v6                                  // 0000003606C4: 56100D09
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003606C8: BF870121
	v_fma_f32 v7, -v4, v8, v7                                  // 0000003606CC: D6130007 241E1104
	v_mad_u64_u32 v[3:4], null, s9, v0, v[3:4]                 // 0000003606D4: D6FE7C03 040E0009
	v_div_fmas_f32 v4, v7, v6, v8                              // 0000003606DC: D6370004 04220D07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003606E4: BF870112
	.long 0xd73c0002                                           // 0000003606E8: D73C0002
	v_cndmask_b32_e32 v1, 1, v2, vcc_lo                        // 0000003606EC: 02020481
	v_div_fixup_f32 v4, v4, v5, 1.0                            // 0000003606F0: D6270004 03CA0B04
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003606F8: BF870112
	.long 0xd7006a02                                           // 0000003606FC: D7006A02
	v_cndmask_b32_e32 v1, s0, v2, vcc_lo                       // 000000360700: 02020400
	v_bfe_u32 v5, v4, 16, 1                                    // 000000360704: D6100005 02052104
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000036070C: BF870194
	v_add_co_ci_u32_e64 v3, null, s1, v3, vcc_lo               // 000000360710: D5207C03 01AA0601
	.long 0xd7006a02                                           // 000000360718: D7006A02
	v_cndmask_b32_e32 v0, v2, v10, vcc_lo                      // 00000036071C: 02001502
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000360720: BF870193
	v_add3_u32 v4, v4, v5, 0x7fff                              // 000000360724: D6550004 03FE0B04 00007FFF
	v_add_co_ci_u32_e64 v3, null, s11, v3, vcc_lo              // 000000360730: D5207C03 01AA060B
	global_store_d16_hi_b16 v[2:3], v4, off                    // 000000360738: DC960000 007C0402
	s_and_not1_b32 vcc_lo, exec_lo, s6                         // 000000360740: 916A067E
	s_cbranch_vccnz 3                                          // 000000360744: BFA40003 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi7ELi32ELi8EEEvNS0_5LqGrpEPKtl+0x1854>
	s_cmp_lg_u32 s5, 1                                         // 000000360748: BF078105
	s_mov_b32 s12, -1                                          // 00000036074C: BE8C00C1
	s_cselect_b32 s7, -1, 0                                    // 000000360750: 980780C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000360754: BF8700A1
	v_bfe_u32 v2, v1, 16, 1                                    // 000000360758: D6100002 02052101
	s_and_b32 vcc_lo, exec_lo, s7                              // 000000360760: 8B6A077E
	v_add3_u32 v1, v1, v2, 0x7fff                              // 000000360764: D6550001 03FE0501 00007FFF
	s_cbranch_vccz 21                                          // 000000360770: BFA30015 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi7ELi32ELi8EEEvNS0_5LqGrpEPKtl+0x18c8>
	v_mad_u64_u32 v[2:3], null, s8, v0, 0                      // 000000360774: D6FE7C02 02020008
	s_lshl_b64 s[6:7], s[2:3], 1                               // 00000036077C: 84868102
	s_mov_b32 s12, 0                                           // 000000360780: BE8C0080
	v_mad_u64_u32 v[3:4], null, s9, v0, v[3:4]                 // 000000360784: D6FE7C03 040E0009
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000036078C: BF870091
	.long 0xd73c0002                                           // 000000360790: D73C0002
	v_cndmask_b32_e32 v1, 1, v2, vcc_lo                        // 000000360794: 02020481
	.long 0xd7006a02                                           // 000000360798: D7006A02
	v_cndmask_b32_e32 v1, s0, v2, vcc_lo                       // 00000036079C: 02020400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003607A0: BF870111
	v_add_co_ci_u32_e64 v3, null, s1, v3, vcc_lo               // 0000003607A4: D5207C03 01AA0601
	.long 0xd7006a02                                           // 0000003607AC: D7006A02
	v_cndmask_b32_e32 v0, v2, v6, vcc_lo                       // 0000003607B0: 02000D02
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003607B4: BF870001
	v_add_co_ci_u32_e64 v3, null, s7, v3, vcc_lo               // 0000003607B8: D5207C03 01AA0607
	global_store_d16_hi_b16 v[2:3], v1, off                    // 0000003607C0: DC960000 007C0102
	s_and_not1_b32 vcc_lo, exec_lo, s12                        // 0000003607C8: 916A0C7E
	s_cbranch_vccnz 58                                         // 0000003607CC: BFA4003A <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi7ELi32ELi8EEEvNS0_5LqGrpEPKtl+0x19b8>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003607D0: BF8700A1
	v_and_b32_e32 v1, 0xffff0000, v1                           // 0000003607D4: 360202FF FFFF0000
	s_lshl_b64 s[2:3], s[2:3], 1                               // 0000003607DC: 84828102
	v_mul_f32_e32 v4, s4, v1                                   // 0000003607E0: 10080204
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003607E4: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v4                           // 0000003607E8: 100208FF BFB8AA3B
	v_exp_f32_e32 v1, v1                                       // 0000003607F0: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003607F4: BF870095
	v_add_f32_e32 v5, 1.0, v1                                  // 0000003607F8: 060A02F2
	v_div_scale_f32 v3, null, v5, v5, v4                       // 0000003607FC: D6FC7C03 04120B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000360804: BF870291
	v_rcp_f32_e32 v6, v3                                       // 000000360808: 7E0C5503
	v_fma_f32 v1, -v3, v6, 1.0                                 // 00000036080C: D6130001 23CA0D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000360814: BF870131
	v_fmac_f32_e32 v6, v1, v6                                  // 000000360818: 560C0D01
	v_div_scale_f32 v7, vcc_lo, v4, v5, v4                     // 00000036081C: D6FC6A07 04120B04
	v_mad_u64_u32 v[1:2], null, s8, v0, 0                      // 000000360824: D6FE7C01 02020008
	v_mul_f32_e32 v8, v7, v6                                   // 00000036082C: 10100D07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000360830: BF870091
	v_fma_f32 v9, -v3, v8, v7                                  // 000000360834: D6130009 241E1103
	v_fmac_f32_e32 v8, v9, v6                                  // 00000036083C: 56100D09
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000360840: BF870121
	v_fma_f32 v7, -v3, v8, v7                                  // 000000360844: D6130007 241E1103
	v_mad_u64_u32 v[2:3], null, s9, v0, v[2:3]                 // 00000036084C: D6FE7C02 040A0009
	v_div_fmas_f32 v0, v7, v6, v8                              // 000000360854: D6370000 04220D07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000036085C: BF870191
	v_div_fixup_f32 v3, v0, v5, v4                             // 000000360860: D6270003 04120B00
	.long 0xd73c0000                                           // 000000360868: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000036086C: 02020281
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000360870: BF870112
	v_bfe_u32 v2, v3, 16, 1                                    // 000000360874: D6100002 02052103
	.long 0xd7006a00                                           // 00000036087C: D7006A00
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 000000360880: 02020000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000360884: BF870191
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 000000360888: D5207C01 01AA0201
	v_add3_u32 v2, v3, v2, 0x7fff                              // 000000360890: D6550002 03FE0503 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000036089C: BF870093
	.long 0xd7006a00                                           // 0000003608A0: D7006A00
	v_cndmask_b32_e32 v0, v0, v2, vcc_lo                       // 0000003608A4: 02000500
	v_add_co_ci_u32_e64 v1, null, s3, v1, vcc_lo               // 0000003608A8: D5207C01 01AA0203
	global_store_d16_hi_b16 v[0:1], v2, off                    // 0000003608B0: DC960000 007C0200
	s_nop 0                                                    // 0000003608B8: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000003608BC: BFB60003
	s_endpgm                                                   // 0000003608C0: BFB00000
		...

