00000000008fa600 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_gsILi3ELi8ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiSA_S5_S5_PDF16_PfPj>:
; _ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_gsILi3ELi8ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiSA_S5_S5_PDF16_PfPj():
	s_load_b512 s[4:19], s[0:1], null                          // 0000008FA600: F4100100 F8000000
	s_waitcnt lgkmcnt(0)                                       // 0000008FA608: BF89FC07
	s_load_b32 s3, s[10:11], null                              // 0000008FA60C: F40000C5 F8000000
	s_ashr_i32 s10, s2, 31                                     // 0000008FA614: 860A9F02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000008FA618: BF870499
	s_lshr_b32 s10, s10, 29                                    // 0000008FA61C: 850A9D0A
	s_add_i32 s10, s2, s10                                     // 0000008FA620: 810A0A02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000008FA624: BF8704B9
	s_ashr_i32 s24, s10, 3                                     // 0000008FA628: 8618830A
	s_waitcnt lgkmcnt(0)                                       // 0000008FA62C: BF89FC07
	s_mul_i32 s3, s3, 5                                        // 0000008FA630: 96038503
	s_cmp_ge_i32 s24, s3                                       // 0000008FA634: BF030318
	s_cbranch_scc1 4174                                        // 0000008FA638: BFA2104E <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_gsILi3ELi8ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiSA_S5_S5_PDF16_PfPj+0x4174>
	s_ashr_i32 s25, s24, 31                                    // 0000008FA63C: 86199F18
	s_mov_b32 s3, exec_lo                                      // 0000008FA640: BE83007E
	s_lshl_b64 s[10:11], s[24:25], 4                           // 0000008FA644: 848A8418
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000008FA648: BF870009
	s_add_u32 s8, s8, s10                                      // 0000008FA64C: 80080A08
	s_addc_u32 s9, s9, s11                                     // 0000008FA650: 82090B09
	s_load_b128 s[8:11], s[8:9], null                          // 0000008FA654: F4080204 F8000000
	v_cmpx_gt_u32_e32 0x280, v0                                // 0000008FA65C: 7D9800FF 00000280
	s_cbranch_execz 68                                         // 0000008FA664: BFA50044 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_gsILi3ELi8ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiSA_S5_S5_PDF16_PfPj+0x178>
	v_dual_mov_b32 v2, 0 :: v_dual_lshlrev_b32 v3, 4, v0       // 0000008FA668: CA220080 02020084
	v_mov_b32_e32 v4, v0                                       // 0000008FA670: 7E080300
	s_waitcnt lgkmcnt(0)                                       // 0000008FA674: BF89FC07
	s_add_i32 s20, s11, -1                                     // 0000008FA678: 8114C10B
	s_mov_b32 s21, 0                                           // 0000008FA67C: BE950080
	s_set_inst_prefetch_distance 0x1                           // 0000008FA680: BF840001
	s_nop 0                                                    // 0000008FA684: BF800000
	s_nop 0                                                    // 0000008FA688: BF800000
	s_nop 0                                                    // 0000008FA68C: BF800000
	s_nop 0                                                    // 0000008FA690: BF800000
	s_nop 0                                                    // 0000008FA694: BF800000
	s_nop 0                                                    // 0000008FA698: BF800000
	s_nop 0                                                    // 0000008FA69C: BF800000
	s_nop 0                                                    // 0000008FA6A0: BF800000
	s_nop 0                                                    // 0000008FA6A4: BF800000
	s_nop 0                                                    // 0000008FA6A8: BF800000
	s_nop 0                                                    // 0000008FA6AC: BF800000
	s_nop 0                                                    // 0000008FA6B0: BF800000
	s_nop 0                                                    // 0000008FA6B4: BF800000
	s_nop 0                                                    // 0000008FA6B8: BF800000
	s_nop 0                                                    // 0000008FA6BC: BF800000
	v_cmp_lt_u32_e32 vcc_lo, 0x13f, v4                         // 0000008FA6C0: 7C9208FF 0000013F
	v_add_co_ci_u32_e64 v1, null, s10, 0, vcc_lo               // 0000008FA6C8: D5207C01 01A9000A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008FA6D0: BF870091
	v_min_i32_e32 v5, s20, v1                                  // 0000008FA6D4: 220A0214
	v_ashrrev_i32_e32 v6, 31, v5                               // 0000008FA6D8: 340C0A9F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008FA6DC: BF870091
	.long 0xd73c0005                                           // 0000008FA6E0: D73C0005
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 0000008FA6E4: 02020A82
	.long 0xd7006a05                                           // 0000008FA6E8: D7006A05
	v_cndmask_b32_e32 v1, s12, v5, vcc_lo                      // 0000008FA6EC: 02020A0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000008FA6F0: BF8700C1
	v_add_co_ci_u32_e64 v6, null, s13, v6, vcc_lo              // 0000008FA6F4: D5207C06 01AA0C0D
	.long 0xd7026a01                                           // 0000008FA6FC: D7026A01
	v_cndmask_b32_e32 v1, 0x140, v4, vcc_lo                    // 0000008FA700: 020208FF 00000140
	global_load_b32 v5, v[5:6], off                            // 0000008FA708: DC520000 057C0005
	v_cndmask_b32_e32 v1, v1, v4, vcc_lo                       // 0000008FA710: 02020901
	.long 0xd73c0007                                           // 0000008FA714: D73C0007
	v_cndmask_b32_e32 v1, 4, v1, vcc_lo                        // 0000008FA718: 02020284
	v_add_nc_u32_e32 v1, 32, v4                                // 0000008FA71C: 4A0208A0
	s_waitcnt vmcnt(0)                                         // 0000008FA720: BF8903F7
	v_mad_i64_i32 v[5:6], null, 0x1400, v5, s[6:7]             // 0000008FA724: D6FF7C05 001A0AFF 00001400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008FA730: BF870091
	.long 0xd7006a05                                           // 0000008FA734: D7006A05
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 0000008FA738: 02020F05
	v_add_co_ci_u32_e64 v6, null, v6, v8, vcc_lo               // 0000008FA73C: D5207C06 01AA1106
	v_cmp_lt_u32_e32 vcc_lo, 0x25f, v4                         // 0000008FA744: 7C9208FF 0000025F
	v_mov_b32_e32 v4, v1                                       // 0000008FA74C: 7E080301
	global_load_b128 v[5:8], v[5:6], off                       // 0000008FA750: DC5E0000 057C0005
	s_or_b32 s21, vcc_lo, s21                                  // 0000008FA758: 8C15156A
	s_waitcnt vmcnt(0)                                         // 0000008FA75C: BF8903F7
	ds_store_b128 v3, v[5:8]                                   // 0000008FA760: DB7C0000 00000503
	v_add_nc_u32_e32 v3, 0x200, v3                             // 0000008FA768: 4A0606FF 00000200
	s_and_not1_b32 exec_lo, exec_lo, s21                       // 0000008FA770: 917E157E
	s_cbranch_execnz 65490                                     // 0000008FA774: BFA6FFD2 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_gsILi3ELi8ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiSA_S5_S5_PDF16_PfPj+0xc0>
	s_set_inst_prefetch_distance 0x2                           // 0000008FA778: BF840002
	s_or_b32 exec_lo, exec_lo, s3                              // 0000008FA77C: 8C7E037E
	s_lshl_b32 s3, s24, 3                                      // 0000008FA780: 84038318
	s_waitcnt lgkmcnt(0)                                       // 0000008FA784: BF89FC07
	s_ashr_i32 s7, s9, 31                                      // 0000008FA788: 86079F09
	s_sub_i32 s12, s2, s3                                      // 0000008FA78C: 818C0302
	s_mov_b32 s6, s9                                           // 0000008FA790: BE860009
	s_mul_i32 s3, s12, 20                                      // 0000008FA794: 9603940C
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000008FA798: BF8700C9
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v14, s3             // 0000008FA79C: CA100080 010E0003
	s_min_i32 s21, s3, 0x8c                                    // 0000008FA7A4: 8915FF03 0000008C
	s_mul_hi_i32 s22, s8, 0x12c000                             // 0000008FA7AC: 9716FF08 0012C000
	s_add_i32 s13, s21, 20                                     // 0000008FA7B4: 810D9415
	v_mov_b32_e32 v12, v1                                      // 0000008FA7B8: 7E180301
	v_dual_mov_b32 v2, v1 :: v_dual_lshlrev_b32 v25, 2, v0     // 0000008FA7BC: CA220101 02180082
	v_mov_b32_e32 v3, v1                                       // 0000008FA7C4: 7E060301
	v_mov_b32_e32 v4, v1                                       // 0000008FA7C8: 7E080301
	v_mov_b32_e32 v5, v1                                       // 0000008FA7CC: 7E0A0301
	v_mov_b32_e32 v6, v1                                       // 0000008FA7D0: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 0000008FA7D4: 7E0E0301
	v_mov_b32_e32 v8, v1                                       // 0000008FA7D8: 7E100301
	v_mov_b32_e32 v9, v1                                       // 0000008FA7DC: 7E120301
	v_mov_b32_e32 v10, v1                                      // 0000008FA7E0: 7E140301
	v_mov_b32_e32 v11, v1                                      // 0000008FA7E4: 7E160301
	v_mov_b32_e32 v13, v12                                     // 0000008FA7E8: 7E1A030C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000008FA7EC: BF870212
	v_mov_b32_e32 v12, v11                                     // 0000008FA7F0: 7E18030B
	v_mov_b32_e32 v11, v10                                     // 0000008FA7F4: 7E16030A
	v_mov_b32_e32 v10, v9                                      // 0000008FA7F8: 7E140309
	v_mov_b32_e32 v9, v8                                       // 0000008FA7FC: 7E120308
	v_mov_b32_e32 v8, v7                                       // 0000008FA800: 7E100307
	v_mov_b32_e32 v7, v6                                       // 0000008FA804: 7E0E0306
	v_mov_b32_e32 v6, v5                                       // 0000008FA808: 7E0C0305
	v_mov_b32_e32 v5, v4                                       // 0000008FA80C: 7E0A0304
	v_mov_b32_e32 v4, v3                                       // 0000008FA810: 7E080303
	v_mov_b32_e32 v3, v2                                       // 0000008FA814: 7E060302
	v_mov_b32_e32 v2, v1                                       // 0000008FA818: 7E040301
	s_cmp_lt_i32 s3, s13                                       // 0000008FA81C: BF040D03
	s_mul_i32 s23, s8, 0x12c000                                // 0000008FA820: 9617FF08 0012C000
	s_mul_hi_i32 s26, s9, 0x3c000                              // 0000008FA828: 971AFF09 0003C000
	s_mul_i32 s27, s9, 0x3c000                                 // 0000008FA830: 961BFF09 0003C000
	s_cselect_b32 s28, -1, 0                                   // 0000008FA838: 981C80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000008FA83C: BF870009
	s_and_saveexec_b32 s2, s28                                 // 0000008FA840: BE82201C
	s_cbranch_execz 38                                         // 0000008FA844: BFA50026 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_gsILi3ELi8ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiSA_S5_S5_PDF16_PfPj+0x2e0>
	s_add_u32 s20, s4, s23                                     // 0000008FA848: 80141704
	s_addc_u32 s29, s5, s22                                    // 0000008FA84C: 821D1605
	s_add_u32 s30, s20, s27                                    // 0000008FA850: 801E1B14
	s_addc_u32 s31, s29, s26                                   // 0000008FA854: 821F1A1D
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008FA858: BF870099
	v_mad_i64_i32 v[2:3], null, 0x600, v14, s[30:31]           // 0000008FA85C: D6FF7C02 007A1CFF 00000600
	.long 0xd7006a0f                                           // 0000008FA868: D7006A0F
	v_cndmask_b32_e32 v1, v2, v25, vcc_lo                      // 0000008FA86C: 02023302
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008FA870: BF870001
	v_add_co_ci_u32_e64 v16, null, 0, v3, vcc_lo               // 0000008FA874: D5207C10 01AA0680
	s_clause 0xb                                               // 0000008FA87C: BF85000B
	global_load_b32 v2, v[15:16], off                          // 0000008FA880: DC520000 027C000F
	global_load_b32 v3, v[15:16], off offset:128               // 0000008FA888: DC520080 037C000F
	global_load_b32 v4, v[15:16], off offset:256               // 0000008FA890: DC520100 047C000F
	global_load_b32 v5, v[15:16], off offset:384               // 0000008FA898: DC520180 057C000F
	global_load_b32 v6, v[15:16], off offset:512               // 0000008FA8A0: DC520200 067C000F
	global_load_b32 v7, v[15:16], off offset:640               // 0000008FA8A8: DC520280 077C000F
	global_load_b32 v8, v[15:16], off offset:768               // 0000008FA8B0: DC520300 087C000F
	global_load_b32 v9, v[15:16], off offset:896               // 0000008FA8B8: DC520380 097C000F
	global_load_b32 v10, v[15:16], off offset:1024             // 0000008FA8C0: DC520400 0A7C000F
	global_load_b32 v11, v[15:16], off offset:1152             // 0000008FA8C8: DC520480 0B7C000F
	global_load_b32 v12, v[15:16], off offset:1280             // 0000008FA8D0: DC520500 0C7C000F
	global_load_b32 v13, v[15:16], off offset:1408             // 0000008FA8D8: DC520580 0D7C000F
	s_or_b32 exec_lo, exec_lo, s2                              // 0000008FA8E0: 8C7E027E
	v_dual_mov_b32 v22, s12 :: v_dual_mov_b32 v43, 0           // 0000008FA8E4: CA10000C 162A0080
	.long 0xd44a0002                                           // 0000008FA8EC: D44A0002
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 0000008FA8F0: 02020080
	v_dual_mov_b32 v42, 0 :: v_dual_mov_b32 v27, 0             // 0000008FA8F4: CA100080 2A1A0080
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v45, 0             // 0000008FA8FC: CA100080 1A2C0080
	v_dual_mov_b32 v44, 0 :: v_dual_mov_b32 v29, 0             // 0000008FA904: CA100080 2C1C0080
	v_dual_mov_b32 v28, 0 :: v_dual_mov_b32 v47, 0             // 0000008FA90C: CA100080 1C2E0080
	v_dual_mov_b32 v46, 0 :: v_dual_mov_b32 v31, 0             // 0000008FA914: CA100080 2E1E0080
	v_dual_mov_b32 v30, 0 :: v_dual_mov_b32 v49, 0             // 0000008FA91C: CA100080 1E300080
	v_dual_mov_b32 v48, 0 :: v_dual_mov_b32 v33, 0             // 0000008FA924: CA100080 30200080
	v_dual_mov_b32 v32, 0 :: v_dual_mov_b32 v51, 0             // 0000008FA92C: CA100080 20320080
	v_dual_mov_b32 v50, 0 :: v_dual_mov_b32 v35, 0             // 0000008FA934: CA100080 32220080
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v53, 0             // 0000008FA93C: CA100080 22340080
	v_dual_mov_b32 v52, 0 :: v_dual_mov_b32 v37, 0             // 0000008FA944: CA100080 34240080
	v_dual_mov_b32 v36, 0 :: v_dual_mov_b32 v55, 0             // 0000008FA94C: CA100080 24360080
	v_dual_mov_b32 v54, 0 :: v_dual_mov_b32 v39, 0             // 0000008FA954: CA100080 36260080
	v_dual_mov_b32 v38, 0 :: v_dual_mov_b32 v41, 0             // 0000008FA95C: CA100080 26280080
	v_mov_b32_e32 v56, 0                                       // 0000008FA964: 7E700280
	v_mov_b32_e32 v40, 0                                       // 0000008FA968: 7E500280
	s_and_saveexec_b32 s20, s28                                // 0000008FA96C: BE94201C
	s_cbranch_execz 2084                                       // 0000008FA970: BFA50824 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_gsILi3ELi8ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiSA_S5_S5_PDF16_PfPj+0x2404>
	v_lshl_or_b32 v1, v0, 3, 4                                 // 0000008FA974: D6560001 02110700
	v_mad_u32_u24 v18, v0, 24, 0x2f0                           // 0000008FA97C: D60B0012 03FD3100 000002F0
	s_add_u32 s28, s23, s27                                    // 0000008FA988: 801C1B17
	s_addc_u32 s29, s22, s26                                   // 0000008FA98C: 821D1A16
	v_mul_i32_i24_e32 v19, 0xffffffe8, v0                      // 0000008FA990: 122600FF FFFFFFE8
	v_mad_u32_u24 v17, v1, 3, 0x2f0                            // 0000008FA998: D60B0011 03FD0701 000002F0
	v_cmp_lt_u32_e32 vcc_lo, 5, v1                             // 0000008FA9A4: 7C920285
	v_lshrrev_b32_e32 v23, 5, v18                              // 0000008FA9A8: 322E2485
	v_mad_i64_i32 v[14:15], null, 0x600, v14, s[28:29]         // 0000008FA9AC: D6FF7C0E 00721CFF 00000600
	v_mul_i32_i24_e32 v24, -3, v1                              // 0000008FA9B8: 123002C3
	v_lshrrev_b32_e32 v21, 5, v17                              // 0000008FA9BC: 322A2285
	v_and_b32_e32 v18, 0x7e0, v18                              // 0000008FA9C0: 362424FF 000007E0
	v_subrev_nc_u32_e32 v23, 24, v23                           // 0000008FA9C8: 4E2E2E98
	v_dual_mov_b32 v56, 0 :: v_dual_and_b32 v17, 0x7e0, v17    // 0000008FA9CC: CA240080 381022FF 000007E0
	s_delay_alu instid0(VALU_DEP_4)                            // 0000008FA9D8: BF870004
	v_subrev_nc_u32_e32 v21, 24, v21                           // 0000008FA9DC: 4E2A2A98
	v_mov_b32_e32 v40, 0                                       // 0000008FA9E0: 7E500280
	v_add3_u32 v57, v19, v18, 0xfffffd34                       // 0000008FA9E4: D6550039 03FE2513 FFFFFD34
	v_cndmask_b32_e64 v18, v23, 23, s2                         // 0000008FA9F0: D5010012 00092F17
	.long 0xd50b0010                                           // 0000008FA9F8: D50B0010
	v_cndmask_b32_e32 v0, 0x640, v128, vcc_lo                  // 0000008FA9FC: 020100FF 00000640
	v_cndmask_b32_e32 v1, 23, v21, vcc_lo                      // 0000008FAA04: 02022A97
	.long 0xd7006a0e                                           // 0000008FAA08: D7006A0E
	v_cndmask_b32_e32 v1, v14, v25, vcc_lo                     // 0000008FAA0C: 0202330E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008FAA10: BF870191
	v_add_co_ci_u32_e64 v15, null, 0, v15, vcc_lo              // 0000008FAA14: D5207C0F 01AA1E80
	v_dual_mov_b32 v38, 0 :: v_dual_add_nc_u32 v19, 1, v1      // 0000008FAA1C: CA200080 26120281
	v_subrev_nc_u32_e32 v23, 23, v1                            // 0000008FAA24: 4E2E0297
	v_add3_u32 v58, v24, v17, 0xfffffd34                       // 0000008FAA28: D655003A 03FE2318 FFFFFD34
	.long 0xd72c0014                                           // 0000008FAA34: D72C0014
	v_cndmask_b32_e32 v0, 0x280, v12, vcc_lo                   // 0000008FAA38: 020018FF 00000280
	s_delay_alu instid0(VALU_DEP_4)                            // 0000008FAA40: BF870004
	v_cmp_gt_u32_e32 vcc_lo, 24, v19                           // 0000008FAA44: 7C982698
	v_or_b32_e32 v21, v16, v25                                 // 0000008FAA48: 382A3310
	v_lshl_or_b32 v1, v1, 2, v16                               // 0000008FAA4C: D6560001 04410501
	.long 0xd526003c                                           // 0000008FAA54: D526003C
	v_cndmask_b32_e32 v0, 0, v21, vcc_lo                       // 0000008FAA58: 02002A80
	.long 0xd525003d                                           // 0000008FAA5C: D525003D
	v_cndmask_b32_e32 v0, s3, v129, vcc_lo                     // 0000008FAA60: 02010203
	v_cndmask_b32_e32 v17, v23, v19, vcc_lo                    // 0000008FAA64: 02222717
	v_cmp_gt_i32_e32 vcc_lo, 23, v18                           // 0000008FAA68: 7C882497
	v_lshl_or_b32 v19, v18, 2, v16                             // 0000008FAA6C: D6560013 04410512
	v_and_or_b32 v59, v0, 16, v20                              // 0000008FAA74: D657003B 04512100
	v_dual_mov_b32 v39, 0 :: v_dual_add_nc_u32 v62, 0x2800, v21// 0000008FAA7C: CA200080 273E2AFF 00002800
	v_cndmask_b32_e64 v18, 0xffffffa4, 4, vcc_lo               // 0000008FAA88: D5010012 01A908FF FFFFFFA4
	.long 0xd7006a0e                                           // 0000008FAA94: D7006A0E
	v_cndmask_b32_e32 v1, s4, v14, vcc_lo                      // 0000008FAA98: 02021C04
	v_lshl_or_b32 v16, v17, 2, v16                             // 0000008FAA9C: D6560010 04410511
	v_add_co_ci_u32_e64 v15, null, s5, v15, vcc_lo             // 0000008FAAA4: D5207C0F 01AA1E05
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008FAAAC: BF8701A3
	.long 0xd7006a17                                           // 0000008FAAB0: D7006A17
	v_cndmask_b32_e32 v1, 0x600, v14, vcc_lo                   // 0000008FAAB4: 02021CFF 00000600
	v_dual_mov_b32 v41, 0 :: v_dual_add_nc_u32 v14, v19, v18   // 0000008FAABC: CA200080 290E2513
	v_add_co_ci_u32_e64 v24, null, 0, v15, vcc_lo              // 0000008FAAC4: D5207C18 01AA1E80
	v_dual_mov_b32 v54, 0 :: v_dual_add_nc_u32 v63, 0x2c00, v21// 0000008FAACC: CA200080 363E2AFF 00002C00
	v_dual_mov_b32 v55, 0 :: v_dual_add_nc_u32 v64, 0x2800, v19// 0000008FAAD8: CA200080 374026FF 00002800
	s_delay_alu instid0(VALU_DEP_4)                            // 0000008FAAE4: BF870004
	v_dual_mov_b32 v36, 0 :: v_dual_add_nc_u32 v65, 0x2800, v14// 0000008FAAE8: CA200080 24401CFF 00002800
	v_dual_mov_b32 v37, 0 :: v_dual_add_nc_u32 v66, 0x2800, v1 // 0000008FAAF4: CA200080 254202FF 00002800
	v_dual_mov_b32 v52, 0 :: v_dual_add_nc_u32 v67, 0x2800, v16// 0000008FAB00: CA200080 344220FF 00002800
	v_dual_mov_b32 v53, 0 :: v_dual_add_nc_u32 v68, 0x2a00, v19// 0000008FAB0C: CA200080 354426FF 00002A00
	v_dual_mov_b32 v34, 0 :: v_dual_add_nc_u32 v69, 0x2a00, v14// 0000008FAB18: CA200080 22441CFF 00002A00
	v_dual_mov_b32 v35, 0 :: v_dual_add_nc_u32 v70, 0x2a00, v1 // 0000008FAB24: CA200080 234602FF 00002A00
	v_dual_mov_b32 v50, 0 :: v_dual_add_nc_u32 v71, 0x2a00, v16// 0000008FAB30: CA200080 324620FF 00002A00
	v_dual_mov_b32 v51, 0 :: v_dual_add_nc_u32 v72, 0x2c00, v19// 0000008FAB3C: CA200080 334826FF 00002C00
	v_dual_mov_b32 v32, 0 :: v_dual_add_nc_u32 v73, 0x2c00, v14// 0000008FAB48: CA200080 20481CFF 00002C00
	v_dual_mov_b32 v33, 0 :: v_dual_add_nc_u32 v74, 0x2c00, v1 // 0000008FAB54: CA200080 214A02FF 00002C00
	v_dual_mov_b32 v48, 0 :: v_dual_add_nc_u32 v75, 0x2c00, v16// 0000008FAB60: CA200080 304A20FF 00002C00
	v_dual_mov_b32 v49, 0 :: v_dual_mov_b32 v30, 0             // 0000008FAB6C: CA100080 311E0080
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v46, 0             // 0000008FAB74: CA100080 1F2E0080
	v_dual_mov_b32 v47, 0 :: v_dual_mov_b32 v28, 0             // 0000008FAB7C: CA100080 2F1C0080
	v_dual_mov_b32 v29, 0 :: v_dual_mov_b32 v44, 0             // 0000008FAB84: CA100080 1D2C0080
	v_dual_mov_b32 v45, 0 :: v_dual_mov_b32 v26, 0             // 0000008FAB8C: CA100080 2D1A0080
	v_dual_mov_b32 v27, 0 :: v_dual_mov_b32 v42, 0             // 0000008FAB94: CA100080 1B2A0080
	v_mov_b32_e32 v43, 0                                       // 0000008FAB9C: 7E560280
	v_mov_b32_e32 v1, 0                                        // 0000008FABA0: 7E020280
	s_mov_b32 s4, 0                                            // 0000008FABA4: BE840080
	s_movk_i32 s5, 0x1eee                                      // 0000008FABA8: B0051EEE
	s_branch 1892                                              // 0000008FABAC: BFA00764 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_gsILi3ELi8ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiSA_S5_S5_PDF16_PfPj+0x2340>
	s_or_b32 exec_lo, exec_lo, s3                              // 0000008FABB0: 8C7E037E
	ds_load_2addr_b32 v[76:77], v65 offset1:24                 // 0000008FABB4: D8DC1800 4C000041
	ds_load_2addr_b32 v[78:79], v67 offset1:24                 // 0000008FABBC: D8DC1800 4E000043
	ds_load_2addr_b32 v[82:83], v64 offset1:24                 // 0000008FABC4: D8DC1800 52000040
	ds_load_2addr_b32 v[85:86], v66 offset1:24                 // 0000008FABCC: D8DC1800 55000042
	ds_load_b128 v[14:17], v59                                 // 0000008FABD4: DBFC0000 0E00003B
	ds_load_b128 v[18:21], v59 offset:5120                     // 0000008FABDC: DBFC1400 1200003B
	.long 0xd7000317                                           // 0000008FABE4: D7000317
	v_cndmask_b32_e32 v1, 0x600, v23, vcc_lo                   // 0000008FABE8: 02022EFF 00000600
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008FABF0: BF870001
	v_add_co_ci_u32_e64 v24, null, 0, v24, s3                  // 0000008FABF4: D5207C18 000E3080
	v_add_nc_u32_e32 v61, 1, v61                               // 0000008FABFC: 4A7A7A81
	v_add_nc_u32_e32 v59, 32, v59                              // 0000008FAC00: 4A7676A0
	s_waitcnt lgkmcnt(4)                                       // 0000008FAC04: BF89FC47
	v_dual_mov_b32 v81, v76 :: v_dual_mov_b32 v84, v78         // 0000008FAC08: CA10014C 5154014E
	s_waitcnt lgkmcnt(3)                                       // 0000008FAC10: BF89FC37
	v_mov_b32_e32 v78, v83                                     // 0000008FAC14: 7E9C0353
	s_waitcnt lgkmcnt(2)                                       // 0000008FAC18: BF89FC27
	v_mov_b32_e32 v80, v86                                     // 0000008FAC1C: 7EA00356
	.long 0xd73d0058                                           // 0000008FAC20: D73D0058
	v_cndmask_b32_e32 v1, v57, v81, vcc_lo                     // 0000008FAC24: 0202A339
	.long 0xd73d0053                                           // 0000008FAC28: D73D0053
	v_cndmask_b32_e32 v1, v58, v84, vcc_lo                     // 0000008FAC2C: 0202A93A
	.long 0xd73d004c                                           // 0000008FAC30: D73D004C
	v_cndmask_b32_e32 v1, v57, v77, vcc_lo                     // 0000008FAC34: 02029B39
	s_delay_alu instid0(VALU_DEP_4)                            // 0000008FAC38: BF870004
	.long 0xd73d004d                                           // 0000008FAC3C: D73D004D
	v_cndmask_b32_e32 v1, v58, v79, vcc_lo                     // 0000008FAC40: 02029F3A
	ds_load_2addr_b32 v[81:82], v64 offset0:48 offset1:72      // 0000008FAC44: D8DC4830 51000040
	ds_load_2addr_b32 v[86:87], v65 offset0:48 offset1:72      // 0000008FAC4C: D8DC4830 56000041
	v_bfe_u32 v78, v88, 9, 16                                  // 0000008FAC54: D610004E 02411358
	v_bfe_u32 v79, v88, 6, 16                                  // 0000008FAC5C: D610004F 02410D58
	v_bfe_u32 v80, v88, 3, 16                                  // 0000008FAC64: D6100050 02410758
	v_bfe_u32 v85, v83, 9, 16                                  // 0000008FAC6C: D6100055 02411353
	v_bfe_u32 v89, v83, 3, 16                                  // 0000008FAC74: D6100059 02410753
	.long 0xd72c004e                                           // 0000008FAC7C: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 0000008FAC80: 02029CFF 83DCD12D
	.long 0xd72c004f                                           // 0000008FAC88: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 0000008FAC8C: 02029EFF 83DCD12D
	v_bfe_u32 v90, v76, 9, 16                                  // 0000008FAC94: D610005A 0241134C
	.long 0xd72c0050                                           // 0000008FAC9C: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 0000008FACA0: 0202A0FF 83DCD12D
	.long 0xd72c0059                                           // 0000008FACA8: D72C0059
	v_cndmask_b32_e32 v1, 0x83dcd12d, v89, vcc_lo              // 0000008FACAC: 0202B2FF 83DCD12D
	.long 0xd72c0055                                           // 0000008FACB4: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 0000008FACB8: 0202AAFF 83DCD12D
	v_bfe_u32 v91, v76, 6, 16                                  // 0000008FACC0: D610005B 02410D4C
	.long 0xd72c005a                                           // 0000008FACC8: D72C005A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v90, vcc_lo              // 0000008FACCC: 0202B4FF 83DCD12D
	v_sad_u8 v78, v78, 0, 0x6400                               // 0000008FACD4: D622004E 03FD014E 00006400
	v_sad_u8 v79, v79, 0, 0x6400                               // 0000008FACE0: D622004F 03FD014F 00006400
	v_bfe_u32 v92, v76, 3, 16                                  // 0000008FACEC: D610005C 0241074C
	v_sad_u8 v80, v80, 0, 0x6400                               // 0000008FACF4: D6220050 03FD0150 00006400
	v_sad_u8 v89, v89, 0, 0x6400                               // 0000008FAD00: D6220059 03FD0159 00006400
	v_and_b32_e32 v78, 0xffff, v78                             // 0000008FAD0C: 369C9CFF 0000FFFF
	v_sad_u8 v85, v85, 0, 0x6400                               // 0000008FAD14: D6220055 03FD0155 00006400
	.long 0xd72c005c                                           // 0000008FAD20: D72C005C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v92, vcc_lo              // 0000008FAD24: 0202B8FF 83DCD12D
	v_bfe_u32 v93, v77, 9, 16                                  // 0000008FAD2C: D610005D 0241134D
	.long 0xd72c005b                                           // 0000008FAD34: D72C005B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v91, vcc_lo              // 0000008FAD38: 0202B6FF 83DCD12D
	v_lshl_or_b32 v78, v79, 16, v78                            // 0000008FAD40: D656004E 0539214F
	v_bfe_u32 v94, v77, 6, 16                                  // 0000008FAD48: D610005E 02410D4D
	v_and_b32_e32 v95, 0xffff, v77                             // 0000008FAD50: 36BE9AFF 0000FFFF
	.long 0xd72c005d                                           // 0000008FAD58: D72C005D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v93, vcc_lo              // 0000008FAD5C: 0202BAFF 83DCD12D
	v_bfe_u32 v77, v77, 3, 16                                  // 0000008FAD64: D610004D 0241074D
	v_pk_fma_f16 v78, v78, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000008FAD6C: CC0E004E 0BFC0B4E 0000C931
	v_and_b32_e32 v84, 0xffff, v88                             // 0000008FAD78: 36A8B0FF 0000FFFF
	v_bfe_u32 v88, v83, 6, 16                                  // 0000008FAD80: D6100058 02410D53
	v_and_b32_e32 v83, 0xffff, v83                             // 0000008FAD88: 36A6A6FF 0000FFFF
	s_waitcnt lgkmcnt(3)                                       // 0000008FAD90: BF89FC37
	v_dual_dot2acc_f32_f16 v40, v78, v14 :: v_dual_and_b32 v85, 0xffff, v85// 0000008FAD94: CB241D4E 2854AAFF 0000FFFF
	s_waitcnt lgkmcnt(2)                                       // 0000008FADA0: BF89FC27
	v_dot2acc_f32_f16 v41, v78, v18                            // 0000008FADA4: 0452254E
	.long 0xd72c0054                                           // 0000008FADA8: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 0000008FADAC: 0202A8FF 83DCD12D
	.long 0xd72c0053                                           // 0000008FADB4: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 0000008FADB8: 0202A6FF 83DCD12D
	.long 0xd72c0058                                           // 0000008FADC0: D72C0058
	v_cndmask_b32_e32 v1, 0x83dcd12d, v88, vcc_lo              // 0000008FADC4: 0202B0FF 83DCD12D
	.long 0xd72c005e                                           // 0000008FADCC: D72C005E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v94, vcc_lo              // 0000008FADD0: 0202BCFF 83DCD12D
	v_sad_u8 v78, v93, 0, 0x6400                               // 0000008FADD8: D622004E 03FD015D 00006400
	v_sad_u8 v84, v84, 0, 0x6400                               // 0000008FADE4: D6220054 03FD0154 00006400
	v_sad_u8 v79, v83, 0, 0x6400                               // 0000008FADF0: D622004F 03FD0153 00006400
	v_sad_u8 v83, v90, 0, 0x6400                               // 0000008FADFC: D6220053 03FD015A 00006400
	v_sad_u8 v88, v88, 0, 0x6400                               // 0000008FAE08: D6220058 03FD0158 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008FAE14: BF870193
	v_lshlrev_b32_e32 v79, 16, v79                             // 0000008FAE18: 309E9E90
	v_and_b32_e32 v83, 0xffff, v83                             // 0000008FAE1C: 36A6A6FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008FAE24: BF870193
	v_lshl_or_b32 v85, v88, 16, v85                            // 0000008FAE28: D6560055 05552158
	v_and_or_b32 v79, 0xffff, v89, v79                         // 0000008FAE30: D657004F 053EB2FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008FAE3C: BF870112
	v_pk_fma_f16 v89, v85, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000008FAE40: CC0E0059 0BFC0B55 0000C931
	v_pk_fma_f16 v90, v79, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000008FAE4C: CC0E005A 0BFC0B4F 0000C931
	v_lshlrev_b32_e32 v84, 16, v84                             // 0000008FAE58: 30A8A890
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000008FAE5C: BF8701B1
	v_and_or_b32 v80, 0xffff, v80, v84                         // 0000008FAE60: D6570050 0552A0FF 0000FFFF
	v_sad_u8 v84, v91, 0, 0x6400                               // 0000008FAE6C: D6220054 03FD015B 00006400
	.long 0xd72c005b                                           // 0000008FAE78: D72C005B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 0000008FAE7C: 02029AFF 83DCD12D
	v_pk_fma_f16 v88, v80, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000008FAE84: CC0E0058 0BFC0B50 0000C931
	v_and_b32_e32 v76, 0xffff, v76                             // 0000008FAE90: 369898FF 0000FFFF
	v_sad_u8 v80, v92, 0, 0x6400                               // 0000008FAE98: D6220050 03FD015C 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008FAEA4: BF870193
	v_dot2acc_f32_f16 v41, v88, v19                            // 0000008FAEA8: 04522758
	.long 0xd72c004c                                           // 0000008FAEAC: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 0000008FAEB0: 020298FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008FAEB8: BF870112
	v_dot2acc_f32_f16 v41, v89, v20                            // 0000008FAEBC: 04522959
	v_sad_u8 v76, v76, 0, 0x6400                               // 0000008FAEC0: D622004C 03FD014C 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008FAECC: BF870091
	v_dual_dot2acc_f32_f16 v41, v90, v21 :: v_dual_lshlrev_b32 v76, 16, v76// 0000008FAED0: CB222B5A 294C9890
	v_and_or_b32 v80, 0xffff, v80, v76                         // 0000008FAED8: D6570050 0532A0FF 0000FFFF
	ds_load_2addr_b32 v[76:77], v67 offset0:48 offset1:72      // 0000008FAEE4: D8DC4830 4C000043
	v_and_b32_e32 v78, 0xffff, v78                             // 0000008FAEEC: 369C9CFF 0000FFFF
	v_pk_fma_f16 v93, v80, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000008FAEF4: CC0E005D 0BFC0B50 0000C931
	s_waitcnt lgkmcnt(1)                                       // 0000008FAF00: BF89FC17
	v_mov_b32_e32 v80, v86                                     // 0000008FAF04: 7EA00356
	v_lshl_or_b32 v79, v84, 16, v83                            // 0000008FAF08: D656004F 054D2154
	.long 0xd72c0053                                           // 0000008FAF10: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v95, vcc_lo              // 0000008FAF14: 0202BEFF 83DCD12D
	v_sad_u8 v84, v94, 0, 0x6400                               // 0000008FAF1C: D6220054 03FD015E 00006400
	v_sad_u8 v86, v91, 0, 0x6400                               // 0000008FAF28: D6220056 03FD015B 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000008FAF34: BF870214
	v_pk_fma_f16 v92, v79, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000008FAF38: CC0E005C 0BFC0B4F 0000C931
	v_sad_u8 v79, v83, 0, 0x6400                               // 0000008FAF44: D622004F 03FD0153 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 0000008FAF50: BF870004
	v_lshl_or_b32 v83, v84, 16, v78                            // 0000008FAF54: D6560053 05392154
	ds_load_2addr_b32 v[84:85], v66 offset0:48 offset1:72      // 0000008FAF5C: D8DC4830 54000042
	v_dot2acc_f32_f16 v56, v92, v14                            // 0000008FAF64: 04701D5C
	v_dot2acc_f32_f16 v39, v92, v18                            // 0000008FAF68: 044E255C
	v_lshlrev_b32_e32 v91, 16, v79                             // 0000008FAF6C: 30B69E90
	.long 0xd73d004e                                           // 0000008FAF70: D73D004E
	v_cndmask_b32_e32 v1, v57, v80, vcc_lo                     // 0000008FAF74: 0202A139
	v_pk_fma_f16 v81, v83, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000008FAF78: CC0E0051 0BFC0B53 0000C931
	s_waitcnt lgkmcnt(1)                                       // 0000008FAF84: BF89FC17
	v_mov_b32_e32 v83, v76                                     // 0000008FAF88: 7EA6034C
	v_dot2acc_f32_f16 v40, v88, v15                            // 0000008FAF8C: 04501F58
	v_and_or_b32 v79, 0xffff, v86, v91                         // 0000008FAF90: D657004F 056EACFF 0000FFFF
	v_dot2acc_f32_f16 v39, v93, v19                            // 0000008FAF9C: 044E275D
	v_bfe_u32 v80, v78, 9, 16                                  // 0000008FAFA0: D6100050 0241134E
	v_bfe_u32 v88, v78, 6, 16                                  // 0000008FAFA8: D6100058 02410D4E
	v_dot2acc_f32_f16 v40, v89, v16                            // 0000008FAFB0: 04502159
	v_pk_fma_f16 v86, v79, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000008FAFB4: CC0E0056 0BFC0B4F 0000C931
	v_and_b32_e32 v89, 0xffff, v78                             // 0000008FAFC0: 36B29CFF 0000FFFF
	.long 0xd72c004c                                           // 0000008FAFC8: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 0000008FAFCC: 0202A0FF 83DCD12D
	v_bfe_u32 v78, v78, 3, 16                                  // 0000008FAFD4: D610004E 0241074E
	v_dot2acc_f32_f16 v39, v81, v20                            // 0000008FAFDC: 044E2951
	s_waitcnt lgkmcnt(0)                                       // 0000008FAFE0: BF89FC07
	.long 0xd73d004f                                           // 0000008FAFE4: D73D004F
	v_cndmask_b32_e32 v1, v58, v83, vcc_lo                     // 0000008FAFE8: 0202A73A
	.long 0xd72c0050                                           // 0000008FAFEC: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v88, vcc_lo              // 0000008FAFF0: 0202B0FF 83DCD12D
	.long 0xd72c0053                                           // 0000008FAFF8: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v89, vcc_lo              // 0000008FAFFC: 0202B2FF 83DCD12D
	v_sad_u8 v76, v76, 0, 0x6400                               // 0000008FB004: D622004C 03FD014C 00006400
	v_dot2acc_f32_f16 v40, v90, v17                            // 0000008FB010: 0450235A
	.long 0xd72c004e                                           // 0000008FB014: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 0000008FB018: 02029CFF 83DCD12D
	v_bfe_u32 v84, v79, 9, 16                                  // 0000008FB020: D6100054 0241134F
	v_and_b32_e32 v89, 0xffff, v79                             // 0000008FB028: 36B29EFF 0000FFFF
	v_and_b32_e32 v76, 0xffff, v76                             // 0000008FB030: 369898FF 0000FFFF
	v_sad_u8 v80, v80, 0, 0x6400                               // 0000008FB038: D6220050 03FD0150 00006400
	v_sad_u8 v83, v83, 0, 0x6400                               // 0000008FB044: D6220053 03FD0153 00006400
	.long 0xd72c0054                                           // 0000008FB050: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 0000008FB054: 0202A8FF 83DCD12D
	v_bfe_u32 v88, v79, 6, 16                                  // 0000008FB05C: D6100058 02410D4F
	v_bfe_u32 v79, v79, 3, 16                                  // 0000008FB064: D610004F 0241074F
	v_lshl_or_b32 v76, v80, 16, v76                            // 0000008FB06C: D656004C 05312150
	.long 0xd72c0050                                           // 0000008FB074: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v89, vcc_lo              // 0000008FB078: 0202B2FF 83DCD12D
	v_sad_u8 v78, v78, 0, 0x6400                               // 0000008FB080: D622004E 03FD014E 00006400
	v_lshlrev_b32_e32 v83, 16, v83                             // 0000008FB08C: 30A6A690
	.long 0xd72c0058                                           // 0000008FB090: D72C0058
	v_cndmask_b32_e32 v1, 0x83dcd12d, v88, vcc_lo              // 0000008FB094: 0202B0FF 83DCD12D
	v_sad_u8 v84, v84, 0, 0x6400                               // 0000008FB09C: D6220054 03FD0154 00006400
	v_dot2acc_f32_f16 v56, v93, v15                            // 0000008FB0A8: 04701F5D
	.long 0xd72c004f                                           // 0000008FB0AC: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 0000008FB0B0: 02029EFF 83DCD12D
	v_and_or_b32 v78, 0xffff, v78, v83                         // 0000008FB0B8: D657004E 054E9CFF 0000FFFF
	v_pk_fma_f16 v76, v76, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000008FB0C4: CC0E004C 0BFC0B4C 0000C931
	v_sad_u8 v80, v80, 0, 0x6400                               // 0000008FB0D0: D6220050 03FD0150 00006400
	v_and_b32_e32 v83, 0xffff, v84                             // 0000008FB0DC: 36A6A8FF 0000FFFF
	v_dot2acc_f32_f16 v56, v81, v16                            // 0000008FB0E4: 04702151
	v_sad_u8 v84, v88, 0, 0x6400                               // 0000008FB0E8: D6220054 03FD0158 00006400
	v_pk_fma_f16 v89, v78, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000008FB0F4: CC0E0059 0BFC0B4E 0000C931
	v_sad_u8 v78, v79, 0, 0x6400                               // 0000008FB100: D622004E 03FD014F 00006400
	v_dual_mov_b32 v88, v82 :: v_dual_lshlrev_b32 v79, 16, v80 // 0000008FB10C: CA220152 584EA090
	v_dual_dot2acc_f32_f16 v55, v76, v14 :: v_dual_dot2acc_f32_f16 v56, v86, v17// 0000008FB114: CB181D4C 37382356
	v_lshl_or_b32 v82, v84, 16, v83                            // 0000008FB11C: D6560052 054D2154
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000008FB124: BF870213
	v_and_or_b32 v81, 0xffff, v78, v79                         // 0000008FB128: D6570051 053E9CFF 0000FFFF
	.long 0xd73d004f                                           // 0000008FB134: D73D004F
	v_cndmask_b32_e32 v1, v57, v87, vcc_lo                     // 0000008FB138: 0202AF39
	v_mov_b32_e32 v78, v85                                     // 0000008FB13C: 7E9C0355
	v_dot2acc_f32_f16 v38, v76, v18                            // 0000008FB140: 044C254C
	v_pk_fma_f16 v83, v82, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000008FB144: CC0E0053 0BFC0B52 0000C931
	v_dot2acc_f32_f16 v55, v89, v15                            // 0000008FB150: 046E1F59
	v_dual_dot2acc_f32_f16 v39, v86, v21 :: v_dual_and_b32 v84, 0xffff, v79// 0000008FB154: CB242B56 27549EFF 0000FFFF
	v_pk_fma_f16 v86, v81, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000008FB160: CC0E0056 0BFC0B51 0000C931
	.long 0xd73d0051                                           // 0000008FB16C: D73D0051
	v_cndmask_b32_e32 v1, v58, v77, vcc_lo                     // 0000008FB170: 02029B3A
	v_bfe_u32 v80, v79, 9, 16                                  // 0000008FB174: D6100050 0241134F
	v_bfe_u32 v77, v79, 6, 16                                  // 0000008FB17C: D610004D 02410D4F
	v_bfe_u32 v79, v79, 3, 16                                  // 0000008FB184: D610004F 0241074F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000008FB18C: BF870214
	v_bfe_u32 v76, v81, 9, 16                                  // 0000008FB190: D610004C 02411351
	.long 0xd72c004e                                           // 0000008FB198: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 0000008FB19C: 0202A0FF 83DCD12D
	.long 0xd72c0050                                           // 0000008FB1A4: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 0000008FB1A8: 0202A8FF 83DCD12D
	.long 0xd72c0054                                           // 0000008FB1B0: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 0000008FB1B4: 02029AFF 83DCD12D
	v_bfe_u32 v82, v81, 6, 16                                  // 0000008FB1BC: D6100052 02410D51
	.long 0xd72c0057                                           // 0000008FB1C4: D72C0057
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 0000008FB1C8: 020298FF 83DCD12D
	ds_load_2addr_b32 v[76:77], v65 offset0:96 offset1:120     // 0000008FB1D0: D8DC7860 4C000041
	.long 0xd72c004f                                           // 0000008FB1D8: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 0000008FB1DC: 02029EFF 83DCD12D
	v_and_b32_e32 v85, 0xffff, v81                             // 0000008FB1E4: 36AAA2FF 0000FFFF
	v_sad_u8 v78, v78, 0, 0x6400                               // 0000008FB1EC: D622004E 03FD014E 00006400
	v_dot2acc_f32_f16 v55, v83, v16                            // 0000008FB1F8: 046E2153
	v_sad_u8 v84, v84, 0, 0x6400                               // 0000008FB1FC: D6220054 03FD0154 00006400
	v_sad_u8 v80, v80, 0, 0x6400                               // 0000008FB208: D6220050 03FD0150 00006400
	.long 0xd72c0052                                           // 0000008FB214: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 0000008FB218: 0202A4FF 83DCD12D
	v_and_b32_e32 v78, 0xffff, v78                             // 0000008FB220: 369C9CFF 0000FFFF
	v_sad_u8 v88, v79, 0, 0x6400                               // 0000008FB228: D6220058 03FD014F 00006400
	v_bfe_u32 v81, v81, 3, 16                                  // 0000008FB234: D6100051 02410751
	v_dual_dot2acc_f32_f16 v55, v86, v17 :: v_dual_lshlrev_b32 v90, 16, v80// 0000008FB23C: CB222356 375AA090
	s_delay_alu instid0(VALU_DEP_4)                            // 0000008FB244: BF870004
	v_lshl_or_b32 v78, v84, 16, v78                            // 0000008FB248: D656004E 05392154
	ds_load_2addr_b32 v[79:80], v64 offset0:96 offset1:120     // 0000008FB250: D8DC7860 4F000040
	v_sad_u8 v87, v87, 0, 0x6400                               // 0000008FB258: D6220057 03FD0157 00006400
	v_pk_fma_f16 v91, v78, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000008FB264: CC0E005B 0BFC0B4E 0000C931
	v_dot2acc_f32_f16 v38, v89, v19                            // 0000008FB270: 044C2759
	s_waitcnt lgkmcnt(1)                                       // 0000008FB274: BF89FC17
	v_mov_b32_e32 v78, v76                                     // 0000008FB278: 7E9C034C
	.long 0xd72c0054                                           // 0000008FB27C: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 0000008FB280: 0202AAFF 83DCD12D
	v_and_or_b32 v85, 0xffff, v88, v90                         // 0000008FB288: D6570055 056AB0FF 0000FFFF
	v_sad_u8 v88, v82, 0, 0x6400                               // 0000008FB294: D6220058 03FD0152 00006400
	.long 0xd72c005a                                           // 0000008FB2A0: D72C005A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 0000008FB2A4: 0202A2FF 83DCD12D
	ds_load_2addr_b32 v[81:82], v67 offset0:96 offset1:120     // 0000008FB2AC: D8DC7860 51000043
	v_dual_dot2acc_f32_f16 v54, v91, v14 :: v_dual_and_b32 v87, 0xffff, v87// 0000008FB2B4: CB241D5B 3656AEFF 0000FFFF
	v_pk_fma_f16 v92, v85, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000008FB2C0: CC0E005C 0BFC0B55 0000C931
	v_sad_u8 v93, v84, 0, 0x6400                               // 0000008FB2CC: D622005D 03FD0154 00006400
	ds_load_2addr_b32 v[84:85], v66 offset0:96 offset1:120     // 0000008FB2D8: D8DC7860 54000042
	v_lshl_or_b32 v87, v88, 16, v87                            // 0000008FB2E0: D6560057 055D2158
	v_dot2acc_f32_f16 v37, v91, v18                            // 0000008FB2E8: 044A255B
	v_dot2acc_f32_f16 v38, v83, v20                            // 0000008FB2EC: 044C2953
	v_lshlrev_b32_e32 v88, 16, v93                             // 0000008FB2F0: 30B0BA90
	s_waitcnt lgkmcnt(2)                                       // 0000008FB2F4: BF89FC27
	.long 0xd73d004e                                           // 0000008FB2F8: D73D004E
	v_cndmask_b32_e32 v1, v57, v78, vcc_lo                     // 0000008FB2FC: 02029D39
	v_sad_u8 v76, v90, 0, 0x6400                               // 0000008FB300: D622004C 03FD015A 00006400
	v_pk_fma_f16 v79, v87, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000008FB30C: CC0E004F 0BFC0B57 0000C931
	v_dot2acc_f32_f16 v37, v92, v19                            // 0000008FB318: 044A275C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008FB31C: BF870114
	v_bfe_u32 v87, v78, 9, 16                                  // 0000008FB320: D6100057 0241134E
	v_dot2acc_f32_f16 v37, v79, v20                            // 0000008FB328: 044A294F
	s_waitcnt lgkmcnt(1)                                       // 0000008FB32C: BF89FC17
	v_mov_b32_e32 v83, v81                                     // 0000008FB330: 7EA60351
	v_and_or_b32 v76, 0xffff, v76, v88                         // 0000008FB334: D657004C 056298FF 0000FFFF
	v_bfe_u32 v81, v78, 6, 16                                  // 0000008FB340: D6100051 02410D4E
	s_waitcnt lgkmcnt(0)                                       // 0000008FB348: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008FB34C: BF870193
	.long 0xd73d0053                                           // 0000008FB350: D73D0053
	v_cndmask_b32_e32 v1, v58, v83, vcc_lo                     // 0000008FB354: 0202A73A
	v_pk_fma_f16 v88, v76, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000008FB358: CC0E0058 0BFC0B4C 0000C931
	.long 0xd72c004c                                           // 0000008FB364: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v87, vcc_lo              // 0000008FB368: 0202AEFF 83DCD12D
	.long 0xd72c0051                                           // 0000008FB370: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 0000008FB374: 0202A2FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 0000008FB37C: BF870004
	v_dual_dot2acc_f32_f16 v38, v86, v21 :: v_dual_and_b32 v89, 0xffff, v83// 0000008FB380: CB242B56 2658A6FF 0000FFFF
	v_and_b32_e32 v86, 0xffff, v78                             // 0000008FB38C: 36AC9CFF 0000FFFF
	v_bfe_u32 v78, v78, 3, 16                                  // 0000008FB394: D610004E 0241074E
	v_sad_u8 v76, v76, 0, 0x6400                               // 0000008FB39C: D622004C 03FD014C 00006400
	v_sad_u8 v81, v81, 0, 0x6400                               // 0000008FB3A8: D6220051 03FD0151 00006400
	v_bfe_u32 v87, v83, 6, 16                                  // 0000008FB3B4: D6100057 02410D53
	.long 0xd72c0054                                           // 0000008FB3BC: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 0000008FB3C0: 0202ACFF 83DCD12D
	v_bfe_u32 v86, v83, 9, 16                                  // 0000008FB3C8: D6100056 02411353
	.long 0xd72c004e                                           // 0000008FB3D0: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 0000008FB3D4: 02029CFF 83DCD12D
	v_dual_dot2acc_f32_f16 v37, v88, v21 :: v_dual_and_b32 v76, 0xffff, v76// 0000008FB3DC: CB242B58 254C98FF 0000FFFF
	.long 0xd72c0057                                           // 0000008FB3E8: D72C0057
	v_cndmask_b32_e32 v1, 0x83dcd12d, v87, vcc_lo              // 0000008FB3EC: 0202AEFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 0000008FB3F4: BF870004
	.long 0xd72c0056                                           // 0000008FB3F8: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 0000008FB3FC: 0202ACFF 83DCD12D
	v_bfe_u32 v83, v83, 3, 16                                  // 0000008FB404: D6100053 02410753
	v_sad_u8 v84, v84, 0, 0x6400                               // 0000008FB40C: D6220054 03FD0154 00006400
	v_lshl_or_b32 v76, v81, 16, v76                            // 0000008FB418: D656004C 05312151
	v_sad_u8 v78, v78, 0, 0x6400                               // 0000008FB420: D622004E 03FD014E 00006400
	.long 0xd72c0051                                           // 0000008FB42C: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v89, vcc_lo              // 0000008FB430: 0202B2FF 83DCD12D
	.long 0xd72c0053                                           // 0000008FB438: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 0000008FB43C: 0202A6FF 83DCD12D
	v_lshlrev_b32_e32 v84, 16, v84                             // 0000008FB444: 30A8A890
	v_sad_u8 v86, v86, 0, 0x6400                               // 0000008FB448: D6220056 03FD0156 00006400
	v_dot2acc_f32_f16 v54, v92, v15                            // 0000008FB454: 046C1F5C
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008FB458: BF870003
	v_and_or_b32 v78, 0xffff, v78, v84                         // 0000008FB45C: D657004E 05529CFF 0000FFFF
	v_pk_fma_f16 v84, v76, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000008FB468: CC0E0054 0BFC0B4C 0000C931
	v_sad_u8 v76, v81, 0, 0x6400                               // 0000008FB474: D622004C 03FD0151 00006400
	v_and_b32_e32 v81, 0xffff, v86                             // 0000008FB480: 36A2ACFF 0000FFFF
	v_sad_u8 v86, v87, 0, 0x6400                               // 0000008FB488: D6220056 03FD0157 00006400
	v_pk_fma_f16 v87, v78, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000008FB494: CC0E0057 0BFC0B4E 0000C931
	v_dual_dot2acc_f32_f16 v53, v84, v14 :: v_dual_dot2acc_f32_f16 v54, v79, v16// 0000008FB4A0: CB181D54 3536214F
	v_sad_u8 v83, v83, 0, 0x6400                               // 0000008FB4A8: D6220053 03FD0153 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000008FB4B4: BF870222
	v_dual_dot2acc_f32_f16 v53, v87, v15 :: v_dual_mov_b32 v78, v80// 0000008FB4B8: CB101F57 354E0150
	v_lshl_or_b32 v80, v86, 16, v81                            // 0000008FB4C0: D6560050 05452156
	v_dot2acc_f32_f16 v54, v88, v17                            // 0000008FB4C8: 046C2358
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008FB4CC: BF870092
	v_pk_fma_f16 v86, v80, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000008FB4D0: CC0E0056 0BFC0B50 0000C931
	v_dot2acc_f32_f16 v53, v86, v16                            // 0000008FB4DC: 046A2156
	v_lshlrev_b32_e32 v76, 16, v76                             // 0000008FB4E0: 30989890
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000008FB4E4: BF8701B1
	v_and_or_b32 v79, 0xffff, v83, v76                         // 0000008FB4E8: D657004F 0532A6FF 0000FFFF
	v_mov_b32_e32 v83, v85                                     // 0000008FB4F4: 7EA60355
	.long 0xd73d004c                                           // 0000008FB4F8: D73D004C
	v_cndmask_b32_e32 v1, v57, v77, vcc_lo                     // 0000008FB4FC: 02029B39
	v_pk_fma_f16 v88, v79, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000008FB500: CC0E0058 0BFC0B4F 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008FB50C: BF870193
	.long 0xd73d004e                                           // 0000008FB510: D73D004E
	v_cndmask_b32_e32 v1, v58, v82, vcc_lo                     // 0000008FB514: 0202A53A
	v_bfe_u32 v77, v76, 9, 16                                  // 0000008FB518: D610004D 0241134C
	v_bfe_u32 v79, v76, 6, 16                                  // 0000008FB520: D610004F 02410D4C
	v_and_b32_e32 v80, 0xffff, v76                             // 0000008FB528: 36A098FF 0000FFFF
	v_bfe_u32 v76, v76, 3, 16                                  // 0000008FB530: D610004C 0241074C
	v_bfe_u32 v81, v78, 9, 16                                  // 0000008FB538: D6100051 0241134E
	.long 0xd72c004d                                           // 0000008FB540: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 0000008FB544: 02029AFF 83DCD12D
	.long 0xd72c004f                                           // 0000008FB54C: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 0000008FB550: 02029EFF 83DCD12D
	.long 0xd72c0050                                           // 0000008FB558: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 0000008FB55C: 0202A0FF 83DCD12D
	.long 0xd72c0053                                           // 0000008FB564: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 0000008FB568: 020298FF 83DCD12D
	.long 0xd72c0051                                           // 0000008FB570: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 0000008FB574: 0202A2FF 83DCD12D
	v_bfe_u32 v82, v78, 6, 16                                  // 0000008FB57C: D6100052 02410D4E
	v_dot2acc_f32_f16 v53, v88, v17                            // 0000008FB584: 046A2358
	v_sad_u8 v89, v79, 0, 0x6400                               // 0000008FB588: D6220059 03FD014F 00006400
	v_sad_u8 v80, v80, 0, 0x6400                               // 0000008FB594: D6220050 03FD0150 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 0000008FB5A0: BF870004
	.long 0xd72c0052                                           // 0000008FB5A4: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 0000008FB5A8: 0202A4FF 83DCD12D
	v_sad_u8 v81, v81, 0, 0x6400                               // 0000008FB5B0: D6220051 03FD0151 00006400
	v_dot2acc_f32_f16 v36, v84, v18                            // 0000008FB5BC: 04482554
	v_sad_u8 v84, v77, 0, 0x6400                               // 0000008FB5C0: D6220054 03FD014D 00006400
	ds_load_2addr_b32 v[76:77], v65 offset0:144 offset1:168    // 0000008FB5CC: D8DCA890 4C000041
	v_and_b32_e32 v85, 0xffff, v78                             // 0000008FB5D4: 36AA9CFF 0000FFFF
	v_bfe_u32 v78, v78, 3, 16                                  // 0000008FB5DC: D610004E 0241074E
	v_sad_u8 v83, v83, 0, 0x6400                               // 0000008FB5E4: D6220053 03FD0153 00006400
	v_and_b32_e32 v84, 0xffff, v84                             // 0000008FB5F0: 36A8A8FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008FB5F8: BF870113
	.long 0xd72c005b                                           // 0000008FB5FC: D72C005B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 0000008FB600: 02029CFF 83DCD12D
	v_lshl_or_b32 v84, v89, 16, v84                            // 0000008FB608: D6560054 05512159
	v_dual_dot2acc_f32_f16 v36, v87, v19 :: v_dual_and_b32 v89, 0xffff, v81// 0000008FB610: CB242757 2458A2FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008FB61C: BF870092
	v_pk_fma_f16 v92, v84, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000008FB620: CC0E005C 0BFC0B54 0000C931
	v_dual_dot2acc_f32_f16 v35, v92, v18 :: v_dual_lshlrev_b32 v90, 16, v80// 0000008FB62C: CB22255C 235AA090
	s_waitcnt lgkmcnt(0)                                       // 0000008FB634: BF89FC07
	v_mov_b32_e32 v78, v76                                     // 0000008FB638: 7E9C034C
	.long 0xd72c0055                                           // 0000008FB63C: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 0000008FB640: 0202AAFF 83DCD12D
	ds_load_2addr_b32 v[79:80], v64 offset0:144 offset1:168    // 0000008FB648: D8DCA890 4F000040
	v_sad_u8 v76, v91, 0, 0x6400                               // 0000008FB650: D622004C 03FD015B 00006400
	v_and_or_b32 v83, 0xffff, v83, v90                         // 0000008FB65C: D6570053 056AA6FF 0000FFFF
	v_sad_u8 v90, v82, 0, 0x6400                               // 0000008FB668: D622005A 03FD0152 00006400
	ds_load_2addr_b32 v[81:82], v67 offset0:144 offset1:168    // 0000008FB674: D8DCA890 51000043
	v_dot2acc_f32_f16 v52, v92, v14                            // 0000008FB67C: 04681D5C
	v_pk_fma_f16 v93, v83, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000008FB680: CC0E005D 0BFC0B53 0000C931
	v_sad_u8 v83, v85, 0, 0x6400                               // 0000008FB68C: D6220053 03FD0155 00006400
	ds_load_2addr_b32 v[84:85], v66 offset0:144 offset1:168    // 0000008FB698: D8DCA890 54000042
	v_lshl_or_b32 v89, v90, 16, v89                            // 0000008FB6A0: D6560059 0565215A
	v_dot2acc_f32_f16 v35, v93, v19                            // 0000008FB6A8: 0446275D
	v_lshlrev_b32_e32 v83, 16, v83                             // 0000008FB6AC: 30A6A690
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000008FB6B0: BF8701C1
	v_and_or_b32 v76, 0xffff, v76, v83                         // 0000008FB6B4: D657004C 054E98FF 0000FFFF
	s_waitcnt lgkmcnt(2)                                       // 0000008FB6C0: BF89FC27
	.long 0xd73d004e                                           // 0000008FB6C4: D73D004E
	v_cndmask_b32_e32 v1, v57, v78, vcc_lo                     // 0000008FB6C8: 02029D39
	v_pk_fma_f16 v79, v89, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000008FB6CC: CC0E004F 0BFC0B59 0000C931
	v_pk_fma_f16 v87, v76, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000008FB6D8: CC0E0057 0BFC0B4C 0000C931
	s_waitcnt lgkmcnt(1)                                       // 0000008FB6E4: BF89FC17
	v_mov_b32_e32 v83, v81                                     // 0000008FB6E8: 7EA60351
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000008FB6EC: BF8701B4
	v_bfe_u32 v81, v78, 6, 16                                  // 0000008FB6F0: D6100051 02410D4E
	v_dot2acc_f32_f16 v35, v79, v20                            // 0000008FB6F8: 0446294F
	s_waitcnt lgkmcnt(0)                                       // 0000008FB6FC: BF89FC07
	.long 0xd73d0053                                           // 0000008FB700: D73D0053
	v_cndmask_b32_e32 v1, v58, v83, vcc_lo                     // 0000008FB704: 0202A73A
	v_dot2acc_f32_f16 v36, v86, v20                            // 0000008FB708: 04482956
	v_bfe_u32 v86, v78, 9, 16                                  // 0000008FB70C: D6100056 0241134E
	.long 0xd72c0051                                           // 0000008FB714: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 0000008FB718: 0202A2FF 83DCD12D
	v_dot2acc_f32_f16 v35, v87, v21                            // 0000008FB720: 04462B57
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000008FB724: BF870214
	v_dual_dot2acc_f32_f16 v36, v88, v21 :: v_dual_and_b32 v89, 0xffff, v83// 0000008FB728: CB242B58 2458A6FF 0000FFFF
	.long 0xd72c004c                                           // 0000008FB734: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 0000008FB738: 0202ACFF 83DCD12D
	v_and_b32_e32 v86, 0xffff, v78                             // 0000008FB740: 36AC9CFF 0000FFFF
	v_bfe_u32 v78, v78, 3, 16                                  // 0000008FB748: D610004E 0241074E
	v_sad_u8 v81, v81, 0, 0x6400                               // 0000008FB750: D6220051 03FD0151 00006400
	v_bfe_u32 v88, v83, 6, 16                                  // 0000008FB75C: D6100058 02410D53
	s_delay_alu instid0(VALU_DEP_4)                            // 0000008FB764: BF870004
	.long 0xd72c0054                                           // 0000008FB768: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 0000008FB76C: 0202ACFF 83DCD12D
	v_bfe_u32 v86, v83, 9, 16                                  // 0000008FB774: D6100056 02411353
	v_sad_u8 v76, v76, 0, 0x6400                               // 0000008FB77C: D622004C 03FD014C 00006400
	.long 0xd72c004e                                           // 0000008FB788: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 0000008FB78C: 02029CFF 83DCD12D
	v_bfe_u32 v83, v83, 3, 16                                  // 0000008FB794: D6100053 02410753
	.long 0xd72c0058                                           // 0000008FB79C: D72C0058
	v_cndmask_b32_e32 v1, 0x83dcd12d, v88, vcc_lo              // 0000008FB7A0: 0202B0FF 83DCD12D
	.long 0xd72c0056                                           // 0000008FB7A8: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 0000008FB7AC: 0202ACFF 83DCD12D
	v_and_b32_e32 v76, 0xffff, v76                             // 0000008FB7B4: 369898FF 0000FFFF
	v_sad_u8 v84, v84, 0, 0x6400                               // 0000008FB7BC: D6220054 03FD0154 00006400
	.long 0xd72c0053                                           // 0000008FB7C8: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 0000008FB7CC: 0202A6FF 83DCD12D
	v_sad_u8 v78, v78, 0, 0x6400                               // 0000008FB7D4: D622004E 03FD014E 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000008FB7E0: BF870214
	v_lshl_or_b32 v76, v81, 16, v76                            // 0000008FB7E4: D656004C 05312151
	v_lshlrev_b32_e32 v84, 16, v84                             // 0000008FB7EC: 30A8A890
	.long 0xd72c0051                                           // 0000008FB7F0: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v89, vcc_lo              // 0000008FB7F4: 0202B2FF 83DCD12D
	v_sad_u8 v86, v86, 0, 0x6400                               // 0000008FB7FC: D6220056 03FD0156 00006400
	v_sad_u8 v83, v83, 0, 0x6400                               // 0000008FB808: D6220053 03FD0153 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 0000008FB814: BF870004
	v_and_or_b32 v78, 0xffff, v78, v84                         // 0000008FB818: D657004E 05529CFF 0000FFFF
	v_pk_fma_f16 v84, v76, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000008FB824: CC0E0054 0BFC0B4C 0000C931
	v_dot2acc_f32_f16 v52, v93, v15                            // 0000008FB830: 04681F5D
	v_sad_u8 v76, v81, 0, 0x6400                               // 0000008FB834: D622004C 03FD0151 00006400
	v_and_b32_e32 v81, 0xffff, v86                             // 0000008FB840: 36A2ACFF 0000FFFF
	v_sad_u8 v86, v88, 0, 0x6400                               // 0000008FB848: D6220056 03FD0158 00006400
	v_pk_fma_f16 v88, v78, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000008FB854: CC0E0058 0BFC0B4E 0000C931
	v_dual_dot2acc_f32_f16 v51, v84, v14 :: v_dual_dot2acc_f32_f16 v52, v79, v16// 0000008FB860: CB181D54 3334214F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000008FB868: BF870231
	v_dual_dot2acc_f32_f16 v51, v88, v15 :: v_dual_lshlrev_b32 v76, 16, v76// 0000008FB86C: CB221F58 334C9890
	v_mov_b32_e32 v78, v80                                     // 0000008FB874: 7E9C0350
	v_lshl_or_b32 v80, v86, 16, v81                            // 0000008FB878: D6560050 05452156
	v_dot2acc_f32_f16 v52, v87, v17                            // 0000008FB880: 04682357
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000008FB884: BF870224
	v_and_or_b32 v79, 0xffff, v83, v76                         // 0000008FB888: D657004F 0532A6FF 0000FFFF
	v_mov_b32_e32 v83, v85                                     // 0000008FB894: 7EA60355
	v_pk_fma_f16 v86, v80, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000008FB898: CC0E0056 0BFC0B50 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008FB8A4: BF870113
	v_pk_fma_f16 v87, v79, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000008FB8A8: CC0E0057 0BFC0B4F 0000C931
	v_dot2acc_f32_f16 v51, v86, v16                            // 0000008FB8B4: 04662156
	.long 0xd73d004c                                           // 0000008FB8B8: D73D004C
	v_cndmask_b32_e32 v1, v57, v77, vcc_lo                     // 0000008FB8BC: 02029B39
	.long 0xd73d004e                                           // 0000008FB8C0: D73D004E
	v_cndmask_b32_e32 v1, v58, v82, vcc_lo                     // 0000008FB8C4: 0202A53A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008FB8C8: BF870193
	v_dot2acc_f32_f16 v51, v87, v17                            // 0000008FB8CC: 04662357
	v_bfe_u32 v77, v76, 9, 16                                  // 0000008FB8D0: D610004D 0241134C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000008FB8D8: BF870233
	v_bfe_u32 v81, v78, 9, 16                                  // 0000008FB8DC: D6100051 0241134E
	v_bfe_u32 v79, v76, 6, 16                                  // 0000008FB8E4: D610004F 02410D4C
	v_bfe_u32 v82, v78, 6, 16                                  // 0000008FB8EC: D6100052 02410D4E
	.long 0xd72c004d                                           // 0000008FB8F4: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 0000008FB8F8: 02029AFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000008FB900: BF870214
	.long 0xd72c0051                                           // 0000008FB904: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 0000008FB908: 0202A2FF 83DCD12D
	.long 0xd72c004f                                           // 0000008FB910: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 0000008FB914: 02029EFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008FB91C: BF870194
	.long 0xd72c0052                                           // 0000008FB920: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 0000008FB924: 0202A4FF 83DCD12D
	v_sad_u8 v81, v81, 0, 0x6400                               // 0000008FB92C: D6220051 03FD0151 00006400
	v_dot2acc_f32_f16 v34, v84, v18                            // 0000008FB938: 04442554
	v_sad_u8 v84, v77, 0, 0x6400                               // 0000008FB93C: D6220054 03FD014D 00006400
	v_sad_u8 v89, v79, 0, 0x6400                               // 0000008FB948: D6220059 03FD014F 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008FB954: BF870092
	v_and_b32_e32 v84, 0xffff, v84                             // 0000008FB958: 36A8A8FF 0000FFFF
	v_lshl_or_b32 v84, v89, 16, v84                            // 0000008FB960: D6560054 05512159
	v_dual_dot2acc_f32_f16 v34, v88, v19 :: v_dual_and_b32 v89, 0xffff, v81// 0000008FB968: CB242758 2258A2FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008FB974: BF870092
	v_pk_fma_f16 v92, v84, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000008FB978: CC0E005C 0BFC0B54 0000C931
	v_dual_dot2acc_f32_f16 v33, v92, v18 :: v_dual_and_b32 v80, 0xffff, v76// 0000008FB984: CB24255C 215098FF 0000FFFF
	v_bfe_u32 v76, v76, 3, 16                                  // 0000008FB990: D610004C 0241074C
	v_dot2acc_f32_f16 v50, v92, v14                            // 0000008FB998: 04641D5C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008FB99C: BF870193
	.long 0xd72c0050                                           // 0000008FB9A0: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 0000008FB9A4: 0202A0FF 83DCD12D
	.long 0xd72c0053                                           // 0000008FB9AC: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 0000008FB9B0: 020298FF 83DCD12D
	ds_load_2addr_b32 v[76:77], v65 offset0:192 offset1:216    // 0000008FB9B8: D8DCD8C0 4C000041
	v_and_b32_e32 v85, 0xffff, v78                             // 0000008FB9C0: 36AA9CFF 0000FFFF
	v_bfe_u32 v78, v78, 3, 16                                  // 0000008FB9C8: D610004E 0241074E
	v_sad_u8 v80, v80, 0, 0x6400                               // 0000008FB9D0: D6220050 03FD0150 00006400
	v_sad_u8 v83, v83, 0, 0x6400                               // 0000008FB9DC: D6220053 03FD0153 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008FB9E8: BF870193
	.long 0xd72c005b                                           // 0000008FB9EC: D72C005B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 0000008FB9F0: 02029CFF 83DCD12D
	v_lshlrev_b32_e32 v90, 16, v80                             // 0000008FB9F8: 30B4A090
	ds_load_2addr_b32 v[79:80], v64 offset0:192 offset1:216    // 0000008FB9FC: D8DCD8C0 4F000040
	v_and_or_b32 v83, 0xffff, v83, v90                         // 0000008FBA04: D6570053 056AA6FF 0000FFFF
	v_sad_u8 v90, v82, 0, 0x6400                               // 0000008FBA10: D622005A 03FD0152 00006400
	ds_load_2addr_b32 v[81:82], v67 offset0:192 offset1:216    // 0000008FBA1C: D8DCD8C0 51000043
	s_waitcnt lgkmcnt(2)                                       // 0000008FBA24: BF89FC27
	v_mov_b32_e32 v78, v76                                     // 0000008FBA28: 7E9C034C
	.long 0xd72c0055                                           // 0000008FBA2C: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 0000008FBA30: 0202AAFF 83DCD12D
	v_pk_fma_f16 v93, v83, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000008FBA38: CC0E005D 0BFC0B53 0000C931
	v_sad_u8 v76, v91, 0, 0x6400                               // 0000008FBA44: D622004C 03FD015B 00006400
	v_lshl_or_b32 v89, v90, 16, v89                            // 0000008FBA50: D6560059 0565215A
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008FBA58: BF870003
	v_dot2acc_f32_f16 v33, v93, v19                            // 0000008FBA5C: 0442275D
	v_sad_u8 v83, v85, 0, 0x6400                               // 0000008FBA60: D6220053 03FD0155 00006400
	ds_load_2addr_b32 v[84:85], v66 offset0:192 offset1:216    // 0000008FBA6C: D8DCD8C0 54000042
	s_waitcnt lgkmcnt(2)                                       // 0000008FBA74: BF89FC27
	.long 0xd73d004e                                           // 0000008FBA78: D73D004E
	v_cndmask_b32_e32 v1, v57, v78, vcc_lo                     // 0000008FBA7C: 02029D39
	v_pk_fma_f16 v79, v89, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000008FBA80: CC0E004F 0BFC0B59 0000C931
	v_lshlrev_b32_e32 v83, 16, v83                             // 0000008FBA8C: 30A6A690
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008FBA90: BF870112
	v_dual_dot2acc_f32_f16 v50, v93, v15 :: v_dual_dot2acc_f32_f16 v33, v79, v20// 0000008FBA94: CB181F5D 3220294F
	v_and_or_b32 v76, 0xffff, v76, v83                         // 0000008FBA9C: D657004C 054E98FF 0000FFFF
	s_waitcnt lgkmcnt(1)                                       // 0000008FBAA8: BF89FC17
	v_mov_b32_e32 v83, v81                                     // 0000008FBAAC: 7EA60351
	v_bfe_u32 v81, v78, 6, 16                                  // 0000008FBAB0: D6100051 02410D4E
	v_dot2acc_f32_f16 v50, v79, v16                            // 0000008FBAB8: 0464214F
	v_pk_fma_f16 v88, v76, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000008FBABC: CC0E0058 0BFC0B4C 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008FBAC8: BF870113
	.long 0xd72c0051                                           // 0000008FBACC: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 0000008FBAD0: 0202A2FF 83DCD12D
	v_dot2acc_f32_f16 v33, v88, v21                            // 0000008FBAD8: 04422B58
	s_waitcnt lgkmcnt(0)                                       // 0000008FBADC: BF89FC07
	.long 0xd73d0053                                           // 0000008FBAE0: D73D0053
	v_cndmask_b32_e32 v1, v58, v83, vcc_lo                     // 0000008FBAE4: 0202A73A
	v_dot2acc_f32_f16 v34, v86, v20                            // 0000008FBAE8: 04442956
	v_bfe_u32 v86, v78, 9, 16                                  // 0000008FBAEC: D6100056 0241134E
	v_sad_u8 v81, v81, 0, 0x6400                               // 0000008FBAF4: D6220051 03FD0151 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008FBB00: BF870194
	v_and_b32_e32 v89, 0xffff, v83                             // 0000008FBB04: 36B2A6FF 0000FFFF
	.long 0xd72c004c                                           // 0000008FBB0C: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 0000008FBB10: 0202ACFF 83DCD12D
	v_and_b32_e32 v86, 0xffff, v78                             // 0000008FBB18: 36AC9CFF 0000FFFF
	v_bfe_u32 v78, v78, 3, 16                                  // 0000008FBB20: D610004E 0241074E
	v_dot2acc_f32_f16 v34, v87, v21                            // 0000008FBB28: 04442B57
	v_bfe_u32 v87, v83, 6, 16                                  // 0000008FBB2C: D6100057 02410D53
	s_delay_alu instid0(VALU_DEP_4)                            // 0000008FBB34: BF870004
	.long 0xd72c0054                                           // 0000008FBB38: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 0000008FBB3C: 0202ACFF 83DCD12D
	v_bfe_u32 v86, v83, 9, 16                                  // 0000008FBB44: D6100056 02411353
	v_sad_u8 v76, v76, 0, 0x6400                               // 0000008FBB4C: D622004C 03FD014C 00006400
	.long 0xd72c004e                                           // 0000008FBB58: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 0000008FBB5C: 02029CFF 83DCD12D
	v_bfe_u32 v83, v83, 3, 16                                  // 0000008FBB64: D6100053 02410753
	.long 0xd72c0057                                           // 0000008FBB6C: D72C0057
	v_cndmask_b32_e32 v1, 0x83dcd12d, v87, vcc_lo              // 0000008FBB70: 0202AEFF 83DCD12D
	.long 0xd72c0056                                           // 0000008FBB78: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 0000008FBB7C: 0202ACFF 83DCD12D
	v_and_b32_e32 v76, 0xffff, v76                             // 0000008FBB84: 369898FF 0000FFFF
	v_sad_u8 v84, v84, 0, 0x6400                               // 0000008FBB8C: D6220054 03FD0154 00006400
	.long 0xd72c0053                                           // 0000008FBB98: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 0000008FBB9C: 0202A6FF 83DCD12D
	v_sad_u8 v78, v78, 0, 0x6400                               // 0000008FBBA4: D622004E 03FD014E 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 0000008FBBB0: BF8701D4
	v_lshl_or_b32 v76, v81, 16, v76                            // 0000008FBBB4: D656004C 05312151
	.long 0xd72c0051                                           // 0000008FBBBC: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v89, vcc_lo              // 0000008FBBC0: 0202B2FF 83DCD12D
	v_lshlrev_b32_e32 v84, 16, v84                             // 0000008FBBC8: 30A8A890
	v_sad_u8 v86, v86, 0, 0x6400                               // 0000008FBBCC: D6220056 03FD0156 00006400
	v_sad_u8 v83, v83, 0, 0x6400                               // 0000008FBBD8: D6220053 03FD0153 00006400
	v_and_or_b32 v78, 0xffff, v78, v84                         // 0000008FBBE4: D657004E 05529CFF 0000FFFF
	v_pk_fma_f16 v84, v76, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000008FBBF0: CC0E0054 0BFC0B4C 0000C931
	v_sad_u8 v76, v81, 0, 0x6400                               // 0000008FBBFC: D622004C 03FD0151 00006400
	v_and_b32_e32 v81, 0xffff, v86                             // 0000008FBC08: 36A2ACFF 0000FFFF
	v_sad_u8 v86, v87, 0, 0x6400                               // 0000008FBC10: D6220056 03FD0157 00006400
	v_pk_fma_f16 v87, v78, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000008FBC1C: CC0E0057 0BFC0B4E 0000C931
	v_mov_b32_e32 v78, v80                                     // 0000008FBC28: 7E9C0350
	v_dual_dot2acc_f32_f16 v49, v84, v14 :: v_dual_lshlrev_b32 v76, 16, v76// 0000008FBC2C: CB221D54 314C9890
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008FBC34: BF8701A4
	v_lshl_or_b32 v80, v86, 16, v81                            // 0000008FBC38: D6560050 05452156
	v_dot2acc_f32_f16 v32, v84, v18                            // 0000008FBC40: 04402554
	v_and_or_b32 v79, 0xffff, v83, v76                         // 0000008FBC44: D657004F 0532A6FF 0000FFFF
	.long 0xd73d004c                                           // 0000008FBC50: D73D004C
	v_cndmask_b32_e32 v1, v57, v77, vcc_lo                     // 0000008FBC54: 02029B39
	v_dual_mov_b32 v83, v85 :: v_dual_dot2acc_f32_f16 v50, v88, v17// 0000008FBC58: CA180155 53322358
	v_pk_fma_f16 v86, v80, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000008FBC60: CC0E0056 0BFC0B50 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000008FBC6C: BF870254
	v_pk_fma_f16 v88, v79, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000008FBC70: CC0E0058 0BFC0B4F 0000C931
	v_dot2acc_f32_f16 v49, v87, v15                            // 0000008FBC7C: 04621F57
	v_bfe_u32 v79, v76, 9, 16                                  // 0000008FBC80: D610004F 0241134C
	.long 0xd73d004d                                           // 0000008FBC88: D73D004D
	v_cndmask_b32_e32 v1, v58, v82, vcc_lo                     // 0000008FBC8C: 0202A53A
	v_bfe_u32 v80, v76, 6, 16                                  // 0000008FBC90: D6100050 02410D4C
	v_dual_dot2acc_f32_f16 v32, v87, v19 :: v_dual_dot2acc_f32_f16 v49, v86, v16// 0000008FBC98: CB182757 20302156
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000008FBCA0: BF870214
	.long 0xd72c004f                                           // 0000008FBCA4: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 0000008FBCA8: 02029EFF 83DCD12D
	v_bfe_u32 v81, v77, 9, 16                                  // 0000008FBCB0: D6100051 0241134D
	s_delay_alu instid0(VALU_DEP_4)                            // 0000008FBCB8: BF870004
	.long 0xd72c0050                                           // 0000008FBCBC: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 0000008FBCC0: 0202A0FF 83DCD12D
	v_bfe_u32 v82, v77, 6, 16                                  // 0000008FBCC8: D6100052 02410D4D
	v_and_b32_e32 v84, 0xffff, v77                             // 0000008FBCD0: 36A89AFF 0000FFFF
	v_bfe_u32 v83, v77, 3, 16                                  // 0000008FBCD8: D6100053 0241074D
	.long 0xd72c0051                                           // 0000008FBCE0: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 0000008FBCE4: 0202A2FF 83DCD12D
	v_sad_u8 v79, v79, 0, 0x6400                               // 0000008FBCEC: D622004F 03FD014F 00006400
	.long 0xd72c005c                                           // 0000008FBCF8: D72C005C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 0000008FBCFC: 0202A4FF 83DCD12D
	.long 0xd72c0054                                           // 0000008FBD04: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 0000008FBD08: 0202A8FF 83DCD12D
	v_sad_u8 v89, v80, 0, 0x6400                               // 0000008FBD10: D6220059 03FD0150 00006400
	.long 0xd72c0053                                           // 0000008FBD1C: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 0000008FBD20: 0202A6FF 83DCD12D
	v_dual_dot2acc_f32_f16 v32, v86, v20 :: v_dual_and_b32 v85, 0xffff, v79// 0000008FBD28: CB242956 20549EFF 0000FFFF
	v_sad_u8 v91, v81, 0, 0x6400                               // 0000008FBD34: D622005B 03FD0151 00006400
	ds_load_2addr_b32 v[81:82], v71 offset0:112 offset1:136    // 0000008FBD40: D8DC8870 51000047
	ds_load_2addr_b32 v[79:80], v68 offset0:112 offset1:136    // 0000008FBD48: D8DC8870 4F000044
	v_lshl_or_b32 v85, v89, 16, v85                            // 0000008FBD50: D6560055 05552159
	v_dot2acc_f32_f16 v49, v88, v17                            // 0000008FBD58: 04622358
	v_and_b32_e32 v89, 0xffff, v91                             // 0000008FBD5C: 36B2B6FF 0000FFFF
	v_sad_u8 v83, v83, 0, 0x6400                               // 0000008FBD64: D6220053 03FD0153 00006400
	v_dot2acc_f32_f16 v32, v88, v21                            // 0000008FBD70: 04402B58
	v_pk_fma_f16 v91, v85, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000008FBD74: CC0E005B 0BFC0B55 0000C931
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008FBD80: BF870121
	v_dual_dot2acc_f32_f16 v31, v91, v18 :: v_dual_and_b32 v78, 0xffff, v76// 0000008FBD84: CB24255B 1F4E98FF 0000FFFF
	v_bfe_u32 v76, v76, 3, 16                                  // 0000008FBD90: D610004C 0241074C
	.long 0xd72c004e                                           // 0000008FBD98: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 0000008FBD9C: 02029CFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008FBDA4: BF870112
	.long 0xd72c004c                                           // 0000008FBDA8: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 0000008FBDAC: 020298FF 83DCD12D
	v_sad_u8 v78, v78, 0, 0x6400                               // 0000008FBDB4: D622004E 03FD014E 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008FBDC0: BF8700B2
	v_sad_u8 v90, v76, 0, 0x6400                               // 0000008FBDC4: D622005A 03FD014C 00006400
	ds_load_2addr_b32 v[76:77], v69 offset0:112 offset1:136    // 0000008FBDD0: D8DC8870 4C000045
	v_lshlrev_b32_e32 v78, 16, v78                             // 0000008FBDD8: 309C9C90
	v_and_or_b32 v78, 0xffff, v90, v78                         // 0000008FBDDC: D657004E 053AB4FF 0000FFFF
	v_sad_u8 v90, v92, 0, 0x6400                               // 0000008FBDE8: D622005A 03FD015C 00006400
	v_sad_u8 v92, v84, 0, 0x6400                               // 0000008FBDF4: D622005C 03FD0154 00006400
	ds_load_2addr_b32 v[84:85], v70 offset0:112 offset1:136    // 0000008FBE00: D8DC8870 54000046
	v_pk_fma_f16 v93, v78, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000008FBE08: CC0E005D 0BFC0B4E 0000C931
	v_lshl_or_b32 v89, v90, 16, v89                            // 0000008FBE14: D6560059 0565215A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008FBE1C: BF870112
	v_dual_dot2acc_f32_f16 v31, v93, v19 :: v_dual_lshlrev_b32 v90, 16, v92// 0000008FBE20: CB22275D 1F5AB890
	v_pk_fma_f16 v87, v89, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000008FBE28: CC0E0057 0BFC0B59 0000C931
	s_waitcnt lgkmcnt(1)                                       // 0000008FBE34: BF89FC17
	v_mov_b32_e32 v78, v76                                     // 0000008FBE38: 7E9C034C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000008FBE3C: BF870143
	v_and_or_b32 v76, 0xffff, v83, v90                         // 0000008FBE40: D657004C 056AA6FF 0000FFFF
	v_mov_b32_e32 v83, v81                                     // 0000008FBE4C: 7EA60351
	v_dot2acc_f32_f16 v31, v87, v20                            // 0000008FBE50: 043E2957
	s_waitcnt lgkmcnt(0)                                       // 0000008FBE54: BF89FC07
	.long 0xd73d0053                                           // 0000008FBE58: D73D0053
	v_cndmask_b32_e32 v1, v58, v83, vcc_lo                     // 0000008FBE5C: 0202A73A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000008FBE60: BF870241
	v_bfe_u32 v86, v83, 9, 16                                  // 0000008FBE64: D6100056 02411353
	v_bfe_u32 v88, v83, 6, 16                                  // 0000008FBE6C: D6100058 02410D53
	v_bfe_u32 v89, v83, 3, 16                                  // 0000008FBE74: D6100059 02410753
	v_and_b32_e32 v83, 0xffff, v83                             // 0000008FBE7C: 36A6A6FF 0000FFFF
	.long 0xd72c0056                                           // 0000008FBE84: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 0000008FBE88: 0202ACFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008FBE90: BF870194
	.long 0xd72c0058                                           // 0000008FBE94: D72C0058
	v_cndmask_b32_e32 v1, 0x83dcd12d, v88, vcc_lo              // 0000008FBE98: 0202B0FF 83DCD12D
	.long 0xd72c0053                                           // 0000008FBEA0: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 0000008FBEA4: 0202A6FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008FBEAC: BF870113
	v_sad_u8 v86, v86, 0, 0x6400                               // 0000008FBEB0: D6220056 03FD0156 00006400
	v_sad_u8 v83, v83, 0, 0x6400                               // 0000008FBEBC: D6220053 03FD0153 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000008FBEC8: BF870131
	v_lshlrev_b32_e32 v83, 16, v83                             // 0000008FBECC: 30A6A690
	.long 0xd73d004e                                           // 0000008FBED0: D73D004E
	v_cndmask_b32_e32 v1, v57, v78, vcc_lo                     // 0000008FBED4: 02029D39
	v_pk_fma_f16 v79, v76, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000008FBED8: CC0E004F 0BFC0B4C 0000C931
	v_bfe_u32 v76, v78, 9, 16                                  // 0000008FBEE4: D610004C 0241134E
	v_and_b32_e32 v81, 0xffff, v78                             // 0000008FBEEC: 36A29CFF 0000FFFF
	v_bfe_u32 v84, v78, 6, 16                                  // 0000008FBEF4: D6100054 02410D4E
	v_bfe_u32 v78, v78, 3, 16                                  // 0000008FBEFC: D610004E 0241074E
	v_dot2acc_f32_f16 v31, v79, v21                            // 0000008FBF04: 043E2B4F
	.long 0xd72c004c                                           // 0000008FBF08: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 0000008FBF0C: 020298FF 83DCD12D
	.long 0xd72c0051                                           // 0000008FBF14: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 0000008FBF18: 0202A2FF 83DCD12D
	.long 0xd72c0054                                           // 0000008FBF20: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 0000008FBF24: 0202A8FF 83DCD12D
	.long 0xd72c004e                                           // 0000008FBF2C: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 0000008FBF30: 02029CFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000008FBF38: BF870214
	v_sad_u8 v76, v76, 0, 0x6400                               // 0000008FBF3C: D622004C 03FD014C 00006400
	v_sad_u8 v81, v81, 0, 0x6400                               // 0000008FBF48: D6220051 03FD0151 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000008FBF54: BF8701C4
	v_sad_u8 v84, v84, 0, 0x6400                               // 0000008FBF58: D6220054 03FD0154 00006400
	v_dot2acc_f32_f16 v48, v91, v14                            // 0000008FBF64: 04601D5B
	v_sad_u8 v78, v78, 0, 0x6400                               // 0000008FBF68: D622004E 03FD014E 00006400
	v_and_b32_e32 v76, 0xffff, v76                             // 0000008FBF74: 369898FF 0000FFFF
	v_dual_dot2acc_f32_f16 v48, v93, v15 :: v_dual_lshlrev_b32 v81, 16, v81// 0000008FBF7C: CB221F5D 3050A290
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008FBF84: BF870112
	v_lshl_or_b32 v76, v84, 16, v76                            // 0000008FBF88: D656004C 05312154
	v_and_or_b32 v78, 0xffff, v78, v81                         // 0000008FBF90: D657004E 05469CFF 0000FFFF
	.long 0xd72c0051                                           // 0000008FBF9C: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v89, vcc_lo              // 0000008FBFA0: 0202B2FF 83DCD12D
	v_and_b32_e32 v84, 0xffff, v86                             // 0000008FBFA8: 36A8ACFF 0000FFFF
	v_sad_u8 v86, v88, 0, 0x6400                               // 0000008FBFB0: D6220056 03FD0158 00006400
	v_pk_fma_f16 v76, v76, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000008FBFBC: CC0E004C 0BFC0B4C 0000C931
	v_pk_fma_f16 v88, v78, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000008FBFC8: CC0E0058 0BFC0B4E 0000C931
	v_mov_b32_e32 v78, v80                                     // 0000008FBFD4: 7E9C0350
	s_delay_alu instid0(VALU_DEP_4)                            // 0000008FBFD8: BF870004
	v_lshl_or_b32 v84, v86, 16, v84                            // 0000008FBFDC: D6560054 05512156
	v_sad_u8 v81, v81, 0, 0x6400                               // 0000008FBFE4: D6220051 03FD0151 00006400
	v_dot2acc_f32_f16 v47, v76, v14                            // 0000008FBFF0: 045E1D4C
	v_dot2acc_f32_f16 v30, v76, v18                            // 0000008FBFF4: 043C254C
	.long 0xd73d004c                                           // 0000008FBFF8: D73D004C
	v_cndmask_b32_e32 v1, v57, v77, vcc_lo                     // 0000008FBFFC: 02029B39
	v_pk_fma_f16 v80, v84, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000008FC000: CC0E0050 0BFC0B54 0000C931
	v_and_or_b32 v81, 0xffff, v81, v83                         // 0000008FC00C: D6570051 054EA2FF 0000FFFF
	v_dot2acc_f32_f16 v47, v88, v15                            // 0000008FC018: 045E1F58
	v_dual_mov_b32 v83, v85 :: v_dual_dot2acc_f32_f16 v30, v88, v19// 0000008FC01C: CA180155 531E2758
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008FC024: BF870193
	v_pk_fma_f16 v77, v81, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000008FC028: CC0E004D 0BFC0B51 0000C931
	v_dot2acc_f32_f16 v47, v80, v16                            // 0000008FC034: 045E2150
	v_dot2acc_f32_f16 v48, v87, v16                            // 0000008FC038: 04602157
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000008FC03C: BF870224
	v_dot2acc_f32_f16 v30, v80, v20                            // 0000008FC040: 043C2950
	v_bfe_u32 v80, v76, 9, 16                                  // 0000008FC044: D6100050 0241134C
	v_dot2acc_f32_f16 v47, v77, v17                            // 0000008FC04C: 045E234D
	s_delay_alu instid0(VALU_DEP_4)                            // 0000008FC050: BF870004
	v_dot2acc_f32_f16 v48, v79, v17                            // 0000008FC054: 0460234F
	.long 0xd73d004e                                           // 0000008FC058: D73D004E
	v_cndmask_b32_e32 v1, v58, v82, vcc_lo                     // 0000008FC05C: 0202A53A
	v_dot2acc_f32_f16 v30, v77, v21                            // 0000008FC060: 043C2B4D
	.long 0xd72c004d                                           // 0000008FC064: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 0000008FC068: 0202A0FF 83DCD12D
	v_bfe_u32 v79, v76, 6, 16                                  // 0000008FC070: D610004F 02410D4C
	v_bfe_u32 v80, v76, 3, 16                                  // 0000008FC078: D6100050 0241074C
	v_and_b32_e32 v76, 0xffff, v76                             // 0000008FC080: 369898FF 0000FFFF
	v_bfe_u32 v81, v78, 9, 16                                  // 0000008FC088: D6100051 0241134E
	v_bfe_u32 v83, v78, 6, 16                                  // 0000008FC090: D6100053 02410D4E
	.long 0xd72c004f                                           // 0000008FC098: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 0000008FC09C: 02029EFF 83DCD12D
	.long 0xd72c0055                                           // 0000008FC0A4: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 0000008FC0A8: 0202A0FF 83DCD12D
	.long 0xd72c0056                                           // 0000008FC0B0: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 0000008FC0B4: 020298FF 83DCD12D
	.long 0xd72c0058                                           // 0000008FC0BC: D72C0058
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 0000008FC0C0: 0202A2FF 83DCD12D
	.long 0xd72c0053                                           // 0000008FC0C8: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 0000008FC0CC: 0202A6FF 83DCD12D
	v_sad_u8 v82, v77, 0, 0x6400                               // 0000008FC0D4: D6220052 03FD014D 00006400
	ds_load_2addr_b32 v[76:77], v73 offset0:32 offset1:56      // 0000008FC0E0: D8DC3820 4C000049
	v_bfe_u32 v84, v78, 3, 16                                  // 0000008FC0E8: D6100054 0241074E
	v_and_b32_e32 v78, 0xffff, v78                             // 0000008FC0F0: 369C9CFF 0000FFFF
	v_sad_u8 v90, v85, 0, 0x6400                               // 0000008FC0F8: D622005A 03FD0155 00006400
	v_sad_u8 v85, v86, 0, 0x6400                               // 0000008FC104: D6220055 03FD0156 00006400
	v_sad_u8 v86, v88, 0, 0x6400                               // 0000008FC110: D6220056 03FD0158 00006400
	v_and_b32_e32 v87, 0xffff, v82                             // 0000008FC11C: 36AEA4FF 0000FFFF
	v_sad_u8 v89, v79, 0, 0x6400                               // 0000008FC124: D6220059 03FD014F 00006400
	v_sad_u8 v83, v83, 0, 0x6400                               // 0000008FC130: D6220053 03FD0153 00006400
	ds_load_2addr_b32 v[79:80], v72 offset0:32 offset1:56      // 0000008FC13C: D8DC3820 4F000048
	v_and_b32_e32 v86, 0xffff, v86                             // 0000008FC144: 36ACACFF 0000FFFF
	.long 0xd72c004e                                           // 0000008FC14C: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 0000008FC150: 02029CFF 83DCD12D
	ds_load_2addr_b32 v[81:82], v75 offset0:32 offset1:56      // 0000008FC158: D8DC3820 5100004B
	v_lshl_or_b32 v87, v89, 16, v87                            // 0000008FC160: D6560057 055D2159
	.long 0xd72c005b                                           // 0000008FC168: D72C005B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 0000008FC16C: 0202A8FF 83DCD12D
	v_lshl_or_b32 v83, v83, 16, v86                            // 0000008FC174: D6560053 05592153
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008FC17C: BF8701A3
	v_pk_fma_f16 v86, v87, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000008FC180: CC0E0056 0BFC0B57 0000C931
	v_sad_u8 v89, v78, 0, 0x6400                               // 0000008FC18C: D6220059 03FD014E 00006400
	v_pk_fma_f16 v87, v83, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000008FC198: CC0E0057 0BFC0B53 0000C931
	v_lshlrev_b32_e32 v88, 16, v85                             // 0000008FC1A4: 30B0AA90
	ds_load_2addr_b32 v[84:85], v74 offset0:32 offset1:56      // 0000008FC1A8: D8DC3820 5400004A
	s_waitcnt lgkmcnt(3)                                       // 0000008FC1B0: BF89FC37
	v_mov_b32_e32 v78, v76                                     // 0000008FC1B4: 7E9C034C
	v_sad_u8 v76, v91, 0, 0x6400                               // 0000008FC1B8: D622004C 03FD015B 00006400
	v_lshlrev_b32_e32 v89, 16, v89                             // 0000008FC1C4: 30B2B290
	v_and_or_b32 v88, 0xffff, v90, v88                         // 0000008FC1C8: D6570058 0562B4FF 0000FFFF
	v_dot2acc_f32_f16 v29, v86, v18                            // 0000008FC1D4: 043A2556
	s_waitcnt lgkmcnt(2)                                       // 0000008FC1D8: BF89FC27
	.long 0xd73d004e                                           // 0000008FC1DC: D73D004E
	v_cndmask_b32_e32 v1, v57, v78, vcc_lo                     // 0000008FC1E0: 02029D39
	v_and_or_b32 v76, 0xffff, v76, v89                         // 0000008FC1E4: D657004C 056698FF 0000FFFF
	v_pk_fma_f16 v79, v88, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000008FC1F0: CC0E004F 0BFC0B58 0000C931
	s_waitcnt lgkmcnt(1)                                       // 0000008FC1FC: BF89FC17
	v_mov_b32_e32 v83, v81                                     // 0000008FC200: 7EA60351
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000008FC204: BF8701C3
	v_pk_fma_f16 v88, v76, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000008FC208: CC0E0058 0BFC0B4C 0000C931
	v_and_b32_e32 v76, 0xffff, v78                             // 0000008FC214: 36989CFF 0000FFFF
	v_bfe_u32 v81, v78, 9, 16                                  // 0000008FC21C: D6100051 0241134E
	v_dot2acc_f32_f16 v29, v79, v19                            // 0000008FC224: 043A274F
	.long 0xd72c004c                                           // 0000008FC228: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 0000008FC22C: 020298FF 83DCD12D
	s_waitcnt lgkmcnt(0)                                       // 0000008FC234: BF89FC07
	.long 0xd73d0053                                           // 0000008FC238: D73D0053
	v_cndmask_b32_e32 v1, v58, v83, vcc_lo                     // 0000008FC23C: 0202A73A
	v_bfe_u32 v84, v78, 6, 16                                  // 0000008FC240: D6100054 02410D4E
	v_bfe_u32 v78, v78, 3, 16                                  // 0000008FC248: D610004E 0241074E
	.long 0xd72c0051                                           // 0000008FC250: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 0000008FC254: 0202A2FF 83DCD12D
	v_dual_dot2acc_f32_f16 v29, v87, v20 :: v_dual_dot2acc_f32_f16 v46, v86, v14// 0000008FC25C: CB182957 1D2E1D56
	v_bfe_u32 v89, v83, 9, 16                                  // 0000008FC264: D6100059 02411353
	s_delay_alu instid0(VALU_DEP_4)                            // 0000008FC26C: BF870004
	.long 0xd72c004e                                           // 0000008FC270: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 0000008FC274: 02029CFF 83DCD12D
	v_bfe_u32 v90, v83, 6, 16                                  // 0000008FC27C: D610005A 02410D53
	.long 0xd72c0054                                           // 0000008FC284: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 0000008FC288: 0202A8FF 83DCD12D
	v_sad_u8 v76, v76, 0, 0x6400                               // 0000008FC290: D622004C 03FD014C 00006400
	.long 0xd72c0059                                           // 0000008FC29C: D72C0059
	v_cndmask_b32_e32 v1, 0x83dcd12d, v89, vcc_lo              // 0000008FC2A0: 0202B2FF 83DCD12D
	v_bfe_u32 v91, v83, 3, 16                                  // 0000008FC2A8: D610005B 02410753
	v_and_b32_e32 v83, 0xffff, v83                             // 0000008FC2B0: 36A6A6FF 0000FFFF
	v_sad_u8 v81, v81, 0, 0x6400                               // 0000008FC2B8: D6220051 03FD0151 00006400
	v_sad_u8 v78, v78, 0, 0x6400                               // 0000008FC2C4: D622004E 03FD014E 00006400
	v_lshlrev_b32_e32 v76, 16, v76                             // 0000008FC2D0: 30989890
	.long 0xd72c005a                                           // 0000008FC2D4: D72C005A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v90, vcc_lo              // 0000008FC2D8: 0202B4FF 83DCD12D
	.long 0xd72c0053                                           // 0000008FC2E0: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 0000008FC2E4: 0202A6FF 83DCD12D
	v_and_b32_e32 v81, 0xffff, v81                             // 0000008FC2EC: 36A2A2FF 0000FFFF
	v_sad_u8 v84, v84, 0, 0x6400                               // 0000008FC2F4: D6220054 03FD0154 00006400
	v_sad_u8 v89, v89, 0, 0x6400                               // 0000008FC300: D6220059 03FD0159 00006400
	v_and_or_b32 v76, 0xffff, v78, v76                         // 0000008FC30C: D657004C 05329CFF 0000FFFF
	.long 0xd72c004e                                           // 0000008FC318: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v91, vcc_lo              // 0000008FC31C: 0202B6FF 83DCD12D
	v_dot2acc_f32_f16 v29, v88, v21                            // 0000008FC324: 043A2B58
	v_lshl_or_b32 v81, v84, 16, v81                            // 0000008FC328: D6560051 05452154
	v_and_b32_e32 v84, 0xffff, v89                             // 0000008FC330: 36A8B2FF 0000FFFF
	v_sad_u8 v89, v90, 0, 0x6400                               // 0000008FC338: D6220059 03FD015A 00006400
	v_sad_u8 v83, v83, 0, 0x6400                               // 0000008FC344: D6220053 03FD0153 00006400
	v_pk_fma_f16 v86, v76, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000008FC350: CC0E0056 0BFC0B4C 0000C931
	v_dot2acc_f32_f16 v46, v79, v15                            // 0000008FC35C: 045C1F4F
	v_pk_fma_f16 v81, v81, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000008FC360: CC0E0051 0BFC0B51 0000C931
	v_lshl_or_b32 v76, v89, 16, v84                            // 0000008FC36C: D656004C 05512159
	v_sad_u8 v84, v78, 0, 0x6400                               // 0000008FC374: D6220054 03FD014E 00006400
	v_dual_mov_b32 v78, v80 :: v_dual_lshlrev_b32 v83, 16, v83 // 0000008FC380: CA220150 4E52A690
	v_dot2acc_f32_f16 v46, v87, v16                            // 0000008FC388: 045C2157
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000008FC38C: BF870224
	v_pk_fma_f16 v89, v76, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000008FC390: CC0E0059 0BFC0B4C 0000C931
	v_dot2acc_f32_f16 v45, v81, v14                            // 0000008FC39C: 045A1D51
	.long 0xd73d004c                                           // 0000008FC3A0: D73D004C
	v_cndmask_b32_e32 v1, v57, v77, vcc_lo                     // 0000008FC3A4: 02029B39
	v_and_or_b32 v79, 0xffff, v84, v83                         // 0000008FC3A8: D657004F 054EA8FF 0000FFFF
	v_mov_b32_e32 v83, v85                                     // 0000008FC3B4: 7EA60355
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008FC3B8: BF870194
	v_dual_dot2acc_f32_f16 v28, v81, v18 :: v_dual_dot2acc_f32_f16 v45, v86, v15// 0000008FC3BC: CB182551 1C2C1F56
	v_pk_fma_f16 v87, v79, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000008FC3C4: CC0E0057 0BFC0B4F 0000C931
	v_bfe_u32 v79, v76, 9, 16                                  // 0000008FC3D0: D610004F 0241134C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000008FC3D8: BF870234
	.long 0xd73d004d                                           // 0000008FC3DC: D73D004D
	v_cndmask_b32_e32 v1, v58, v82, vcc_lo                     // 0000008FC3E0: 0202A53A
	v_and_b32_e32 v80, 0xffff, v76                             // 0000008FC3E4: 36A098FF 0000FFFF
	v_dual_dot2acc_f32_f16 v28, v86, v19 :: v_dual_dot2acc_f32_f16 v45, v89, v16// 0000008FC3EC: CB182756 1C2C2159
	.long 0xd72c004e                                           // 0000008FC3F4: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 0000008FC3F8: 02029EFF 83DCD12D
	v_bfe_u32 v79, v76, 6, 16                                  // 0000008FC400: D610004F 02410D4C
	v_bfe_u32 v76, v76, 3, 16                                  // 0000008FC408: D610004C 0241074C
	.long 0xd72c0050                                           // 0000008FC410: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 0000008FC414: 0202A0FF 83DCD12D
	v_bfe_u32 v81, v77, 9, 16                                  // 0000008FC41C: D6100051 0241134D
	v_bfe_u32 v82, v77, 6, 16                                  // 0000008FC424: D6100052 02410D4D
	.long 0xd72c004f                                           // 0000008FC42C: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 0000008FC430: 02029EFF 83DCD12D
	.long 0xd72c004c                                           // 0000008FC438: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 0000008FC43C: 020298FF 83DCD12D
	v_sad_u8 v78, v78, 0, 0x6400                               // 0000008FC444: D622004E 03FD014E 00006400
	v_bfe_u32 v83, v77, 3, 16                                  // 0000008FC450: D6100053 0241074D
	v_and_b32_e32 v84, 0xffff, v77                             // 0000008FC458: 36A89AFF 0000FFFF
	v_sad_u8 v80, v80, 0, 0x6400                               // 0000008FC460: D6220050 03FD0150 00006400
	.long 0xd72c0051                                           // 0000008FC46C: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 0000008FC470: 0202A2FF 83DCD12D
	v_and_b32_e32 v78, 0xffff, v78                             // 0000008FC478: 369C9CFF 0000FFFF
	v_sad_u8 v79, v79, 0, 0x6400                               // 0000008FC480: D622004F 03FD014F 00006400
	v_sad_u8 v85, v76, 0, 0x6400                               // 0000008FC48C: D6220055 03FD014C 00006400
	ds_load_2addr_b32 v[76:77], v73 offset0:80 offset1:104     // 0000008FC498: D8DC6850 4C000049
	v_lshlrev_b32_e32 v86, 16, v80                             // 0000008FC4A0: 30ACA090
	.long 0xd72c0054                                           // 0000008FC4A4: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 0000008FC4A8: 0202A8FF 83DCD12D
	v_lshl_or_b32 v78, v79, 16, v78                            // 0000008FC4B0: D656004E 0539214F
	ds_load_2addr_b32 v[79:80], v72 offset0:80 offset1:104     // 0000008FC4B8: D8DC6850 4F000048
	v_sad_u8 v81, v81, 0, 0x6400                               // 0000008FC4C0: D6220051 03FD0151 00006400
	v_and_or_b32 v85, 0xffff, v85, v86                         // 0000008FC4CC: D6570055 055AAAFF 0000FFFF
	.long 0xd72c0053                                           // 0000008FC4D8: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 0000008FC4DC: 0202A6FF 83DCD12D
	v_pk_fma_f16 v78, v78, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000008FC4E4: CC0E004E 0BFC0B4E 0000C931
	v_dot2acc_f32_f16 v45, v87, v17                            // 0000008FC4F0: 045A2357
	v_and_b32_e32 v86, 0xffff, v81                             // 0000008FC4F4: 36ACA2FF 0000FFFF
	v_sad_u8 v90, v84, 0, 0x6400                               // 0000008FC4FC: D622005A 03FD0154 00006400
	v_pk_fma_f16 v91, v85, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000008FC508: CC0E005B 0BFC0B55 0000C931
	v_dot2acc_f32_f16 v44, v78, v14                            // 0000008FC514: 04581D4E
	v_dot2acc_f32_f16 v27, v78, v18                            // 0000008FC518: 0436254E
	v_sad_u8 v83, v83, 0, 0x6400                               // 0000008FC51C: D6220053 03FD0153 00006400
	ds_load_2addr_b32 v[84:85], v74 offset0:80 offset1:104     // 0000008FC528: D8DC6850 5400004A
	v_dot2acc_f32_f16 v44, v91, v15                            // 0000008FC530: 04581F5B
	s_waitcnt lgkmcnt(2)                                       // 0000008FC534: BF89FC27
	v_dual_dot2acc_f32_f16 v27, v91, v19 :: v_dual_mov_b32 v78, v76// 0000008FC538: CB10275B 1B4E014C
	s_waitcnt lgkmcnt(1)                                       // 0000008FC540: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000008FC544: BF8700D1
	.long 0xd73d004e                                           // 0000008FC548: D73D004E
	v_cndmask_b32_e32 v1, v57, v78, vcc_lo                     // 0000008FC54C: 02029D39
	v_dot2acc_f32_f16 v46, v88, v17                            // 0000008FC550: 045C2358
	.long 0xd72c0058                                           // 0000008FC554: D72C0058
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 0000008FC558: 0202A4FF 83DCD12D
	ds_load_2addr_b32 v[81:82], v75 offset0:80 offset1:104     // 0000008FC560: D8DC6850 5100004B
	v_sad_u8 v88, v88, 0, 0x6400                               // 0000008FC568: D6220058 03FD0158 00006400
	v_lshl_or_b32 v86, v88, 16, v86                            // 0000008FC574: D6560056 05592158
	v_lshlrev_b32_e32 v88, 16, v90                             // 0000008FC57C: 30B0B490
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008FC580: BF870112
	v_pk_fma_f16 v76, v86, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000008FC584: CC0E004C 0BFC0B56 0000C931
	v_and_or_b32 v83, 0xffff, v83, v88                         // 0000008FC590: D6570053 0562A6FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008FC59C: BF870112
	v_dot2acc_f32_f16 v44, v76, v16                            // 0000008FC5A0: 0458214C
	v_pk_fma_f16 v79, v83, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000008FC5A4: CC0E004F 0BFC0B53 0000C931
	s_waitcnt lgkmcnt(0)                                       // 0000008FC5B0: BF89FC07
	v_mov_b32_e32 v83, v81                                     // 0000008FC5B4: 7EA60351
	v_and_b32_e32 v81, 0xffff, v78                             // 0000008FC5B8: 36A29CFF 0000FFFF
	v_dot2acc_f32_f16 v27, v76, v20                            // 0000008FC5C0: 0436294C
	v_bfe_u32 v76, v78, 9, 16                                  // 0000008FC5C4: D610004C 0241134E
	v_dot2acc_f32_f16 v44, v79, v17                            // 0000008FC5CC: 0458234F
	.long 0xd73d0053                                           // 0000008FC5D0: D73D0053
	v_cndmask_b32_e32 v1, v58, v83, vcc_lo                     // 0000008FC5D4: 0202A73A
	.long 0xd72c0051                                           // 0000008FC5D8: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 0000008FC5DC: 0202A2FF 83DCD12D
	v_dot2acc_f32_f16 v27, v79, v21                            // 0000008FC5E4: 04362B4F
	.long 0xd72c004c                                           // 0000008FC5E8: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 0000008FC5EC: 020298FF 83DCD12D
	v_bfe_u32 v79, v78, 6, 16                                  // 0000008FC5F4: D610004F 02410D4E
	v_bfe_u32 v78, v78, 3, 16                                  // 0000008FC5FC: D610004E 0241074E
	v_bfe_u32 v84, v83, 9, 16                                  // 0000008FC604: D6100054 02411353
	v_bfe_u32 v86, v83, 6, 16                                  // 0000008FC60C: D6100056 02410D53
	v_sad_u8 v81, v81, 0, 0x6400                               // 0000008FC614: D6220051 03FD0151 00006400
	.long 0xd72c004f                                           // 0000008FC620: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 0000008FC624: 02029EFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 0000008FC62C: BF8701D4
	.long 0xd72c0054                                           // 0000008FC630: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 0000008FC634: 0202A8FF 83DCD12D
	.long 0xd72c004e                                           // 0000008FC63C: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 0000008FC640: 02029CFF 83DCD12D
	v_sad_u8 v76, v76, 0, 0x6400                               // 0000008FC648: D622004C 03FD014C 00006400
	v_dual_dot2acc_f32_f16 v28, v89, v20 :: v_dual_lshlrev_b32 v81, 16, v81// 0000008FC654: CB222959 1C50A290
	.long 0xd72c0056                                           // 0000008FC65C: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 0000008FC660: 0202ACFF 83DCD12D
	v_and_b32_e32 v76, 0xffff, v76                             // 0000008FC668: 369898FF 0000FFFF
	v_sad_u8 v79, v79, 0, 0x6400                               // 0000008FC670: D622004F 03FD014F 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 0000008FC67C: BF870004
	v_dual_dot2acc_f32_f16 v28, v87, v21 :: v_dual_and_b32 v87, 0xffff, v83// 0000008FC680: CB242B57 1C56A6FF 0000FFFF
	v_bfe_u32 v83, v83, 3, 16                                  // 0000008FC68C: D6100053 02410753
	v_sad_u8 v84, v84, 0, 0x6400                               // 0000008FC694: D6220054 03FD0154 00006400
	v_sad_u8 v78, v78, 0, 0x6400                               // 0000008FC6A0: D622004E 03FD014E 00006400
	v_lshl_or_b32 v76, v79, 16, v76                            // 0000008FC6AC: D656004C 0531214F
	.long 0xd72c0057                                           // 0000008FC6B4: D72C0057
	v_cndmask_b32_e32 v1, 0x83dcd12d, v87, vcc_lo              // 0000008FC6B8: 0202AEFF 83DCD12D
	.long 0xd72c0053                                           // 0000008FC6C0: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 0000008FC6C4: 0202A6FF 83DCD12D
	v_and_b32_e32 v79, 0xffff, v84                             // 0000008FC6CC: 369EA8FF 0000FFFF
	v_and_or_b32 v81, 0xffff, v78, v81                         // 0000008FC6D4: D6570051 05469CFF 0000FFFF
	v_mov_b32_e32 v78, v80                                     // 0000008FC6E0: 7E9C0350
	v_sad_u8 v86, v86, 0, 0x6400                               // 0000008FC6E4: D6220056 03FD0156 00006400
	v_sad_u8 v84, v87, 0, 0x6400                               // 0000008FC6F0: D6220054 03FD0157 00006400
	v_sad_u8 v80, v83, 0, 0x6400                               // 0000008FC6FC: D6220050 03FD0153 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000008FC708: BF870223
	v_lshl_or_b32 v79, v86, 16, v79                            // 0000008FC70C: D656004F 053D2156
	v_pk_fma_f16 v81, v81, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000008FC714: CC0E0051 0BFC0B51 0000C931
	v_lshlrev_b32_e32 v83, 16, v84                             // 0000008FC720: 30A6A890
	v_pk_fma_f16 v84, v76, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000008FC724: CC0E0054 0BFC0B4C 0000C931
	.long 0xd73d004c                                           // 0000008FC730: D73D004C
	v_cndmask_b32_e32 v1, v57, v77, vcc_lo                     // 0000008FC734: 02029B39
	v_pk_fma_f16 v79, v79, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000008FC738: CC0E004F 0BFC0B4F 0000C931
	s_delay_alu instid0(VALU_DEP_4)                            // 0000008FC744: BF870004
	v_and_or_b32 v77, 0xffff, v80, v83                         // 0000008FC748: D657004D 054EA0FF 0000FFFF
	v_mov_b32_e32 v83, v85                                     // 0000008FC754: 7EA60355
	v_dot2acc_f32_f16 v43, v84, v14                            // 0000008FC758: 04561D54
	v_bfe_u32 v80, v76, 9, 16                                  // 0000008FC75C: D6100050 0241134C
	v_and_b32_e32 v86, 0xffff, v76                             // 0000008FC764: 36AC98FF 0000FFFF
	v_pk_fma_f16 v85, v77, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000008FC76C: CC0E0055 0BFC0B4D 0000C931
	.long 0xd73d004d                                           // 0000008FC778: D73D004D
	v_cndmask_b32_e32 v1, v58, v82, vcc_lo                     // 0000008FC77C: 0202A53A
	v_dot2acc_f32_f16 v26, v84, v18                            // 0000008FC780: 04342554
	.long 0xd72c004e                                           // 0000008FC784: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 0000008FC788: 0202A0FF 83DCD12D
	v_bfe_u32 v80, v76, 6, 16                                  // 0000008FC790: D6100050 02410D4C
	v_bfe_u32 v76, v76, 3, 16                                  // 0000008FC798: D610004C 0241074C
	.long 0xd72c0052                                           // 0000008FC7A0: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 0000008FC7A4: 0202ACFF 83DCD12D
	v_bfe_u32 v83, v77, 9, 16                                  // 0000008FC7AC: D6100053 0241134D
	v_bfe_u32 v86, v77, 6, 16                                  // 0000008FC7B4: D6100056 02410D4D
	.long 0xd72c0050                                           // 0000008FC7BC: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 0000008FC7C0: 0202A0FF 83DCD12D
	.long 0xd72c004c                                           // 0000008FC7C8: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 0000008FC7CC: 020298FF 83DCD12D
	v_sad_u8 v78, v78, 0, 0x6400                               // 0000008FC7D4: D622004E 03FD014E 00006400
	.long 0xd72c0053                                           // 0000008FC7E0: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 0000008FC7E4: 0202A6FF 83DCD12D
	v_bfe_u32 v87, v77, 3, 16                                  // 0000008FC7EC: D6100057 0241074D
	v_and_b32_e32 v77, 0xffff, v77                             // 0000008FC7F4: 369A9AFF 0000FFFF
	v_sad_u8 v82, v82, 0, 0x6400                               // 0000008FC7FC: D6220052 03FD0152 00006400
	v_and_b32_e32 v78, 0xffff, v78                             // 0000008FC808: 369C9CFF 0000FFFF
	v_sad_u8 v80, v80, 0, 0x6400                               // 0000008FC810: D6220050 03FD0150 00006400
	.long 0xd72c0056                                           // 0000008FC81C: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 0000008FC820: 0202ACFF 83DCD12D
	.long 0xd72c004d                                           // 0000008FC828: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 0000008FC82C: 02029AFF 83DCD12D
	v_sad_u8 v76, v76, 0, 0x6400                               // 0000008FC834: D622004C 03FD014C 00006400
	v_lshlrev_b32_e32 v82, 16, v82                             // 0000008FC840: 30A4A490
	v_sad_u8 v83, v83, 0, 0x6400                               // 0000008FC844: D6220053 03FD0153 00006400
	v_lshl_or_b32 v78, v80, 16, v78                            // 0000008FC850: D656004E 05392150
	.long 0xd72c0050                                           // 0000008FC858: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v87, vcc_lo              // 0000008FC85C: 0202AEFF 83DCD12D
	v_dot2acc_f32_f16 v43, v81, v15                            // 0000008FC864: 04561F51
	v_and_or_b32 v76, 0xffff, v76, v82                         // 0000008FC868: D657004C 054A98FF 0000FFFF
	v_and_b32_e32 v82, 0xffff, v83                             // 0000008FC874: 36A4A6FF 0000FFFF
	v_sad_u8 v83, v86, 0, 0x6400                               // 0000008FC87C: D6220053 03FD0156 00006400
	v_pk_fma_f16 v78, v78, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000008FC888: CC0E004E 0BFC0B4E 0000C931
	v_sad_u8 v77, v77, 0, 0x6400                               // 0000008FC894: D622004D 03FD014D 00006400
	v_pk_fma_f16 v76, v76, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000008FC8A0: CC0E004C 0BFC0B4C 0000C931
	v_sad_u8 v80, v80, 0, 0x6400                               // 0000008FC8AC: D6220050 03FD0150 00006400
	v_lshl_or_b32 v82, v83, 16, v82                            // 0000008FC8B8: D6560052 05492153
	v_dot2acc_f32_f16 v42, v78, v14                            // 0000008FC8C0: 04541D4E
	v_dot2acc_f32_f16 v1, v78, v18                             // 0000008FC8C4: 0402254E
	v_dual_dot2acc_f32_f16 v26, v81, v19 :: v_dual_lshlrev_b32 v77, 16, v77// 0000008FC8C8: CB222751 1A4C9A90
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000008FC8D0: BF870214
	v_pk_fma_f16 v14, v82, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000008FC8D4: CC0E000E 0BFC0B52 0000C931
	v_dot2acc_f32_f16 v42, v76, v15                            // 0000008FC8E0: 04541F4C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000008FC8E4: BF870214
	v_dot2acc_f32_f16 v1, v76, v19                             // 0000008FC8E8: 0402274C
	v_and_or_b32 v18, 0xffff, v80, v77                         // 0000008FC8EC: D6570012 0536A0FF 0000FFFF
	v_dot2acc_f32_f16 v43, v79, v16                            // 0000008FC8F8: 0456214F
	v_dot2acc_f32_f16 v26, v79, v20                            // 0000008FC8FC: 0434294F
	v_dot2acc_f32_f16 v42, v14, v16                            // 0000008FC900: 0454210E
	v_dual_dot2acc_f32_f16 v1, v14, v20 :: v_dual_add_nc_u32 v14, v60, v61// 0000008FC904: CB20290E 010E7B3C
	v_pk_fma_f16 v15, v18, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000008FC90C: CC0E000F 0BFC0B12 0000C931
	v_dot2acc_f32_f16 v43, v85, v17                            // 0000008FC918: 04562355
	v_dot2acc_f32_f16 v26, v85, v21                            // 0000008FC91C: 04342B55
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000008FC920: BF870214
	v_cmp_eq_u32_e32 vcc_lo, 21, v14                           // 0000008FC924: 7C941C95
	v_dot2acc_f32_f16 v42, v15, v17                            // 0000008FC928: 0454230F
	v_dot2acc_f32_f16 v1, v15, v21                             // 0000008FC92C: 04022B0F
	s_or_b32 s4, vcc_lo, s4                                    // 0000008FC930: 8C04046A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000008FC934: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000008FC938: 917E047E
	s_cbranch_execz 48                                         // 0000008FC93C: BFA50030 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_gsILi3ELi8ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiSA_S5_S5_PDF16_PfPj+0x2400>
	s_mov_b32 s3, exec_lo                                      // 0000008FC940: BE83007E
	s_waitcnt vmcnt(10)                                        // 0000008FC944: BF892BF7
	ds_store_2addr_b32 v62, v2, v3 offset1:32                  // 0000008FC948: D8382000 0003023E
	s_waitcnt vmcnt(8)                                         // 0000008FC950: BF8923F7
	ds_store_2addr_b32 v62, v4, v5 offset0:64 offset1:96       // 0000008FC954: D8386040 0005043E
	s_waitcnt vmcnt(6)                                         // 0000008FC95C: BF891BF7
	ds_store_2addr_b32 v62, v6, v7 offset0:128 offset1:160     // 0000008FC960: D838A080 0007063E
	s_waitcnt vmcnt(4)                                         // 0000008FC968: BF8913F7
	ds_store_2addr_b32 v62, v8, v9 offset0:192 offset1:224     // 0000008FC96C: D838E0C0 0009083E
	s_waitcnt vmcnt(2)                                         // 0000008FC974: BF890BF7
	ds_store_2addr_b32 v63, v10, v11 offset1:32                // 0000008FC978: D8382000 000B0A3F
	s_waitcnt vmcnt(0)                                         // 0000008FC980: BF8903F7
	ds_store_2addr_b32 v63, v12, v13 offset0:64 offset1:96     // 0000008FC984: D8386040 000D0C3F
	.long 0xd4c4007e                                           // 0000008FC98C: D4C4007E
	v_cndmask_b32_e32 v1, s13, v61, vcc_lo                     // 0000008FC990: 02027A0D
	s_cbranch_execz 63622                                      // 0000008FC994: BFA5F886 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_gsILi3ELi8ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiSA_S5_S5_PDF16_PfPj+0x5b0>
	s_clause 0xb                                               // 0000008FC998: BF85000B
	global_load_b32 v2, v[23:24], off                          // 0000008FC99C: DC520000 027C0017
	global_load_b32 v3, v[23:24], off offset:128               // 0000008FC9A4: DC520080 037C0017
	global_load_b32 v4, v[23:24], off offset:256               // 0000008FC9AC: DC520100 047C0017
	global_load_b32 v5, v[23:24], off offset:384               // 0000008FC9B4: DC520180 057C0017
	global_load_b32 v6, v[23:24], off offset:512               // 0000008FC9BC: DC520200 067C0017
	global_load_b32 v7, v[23:24], off offset:640               // 0000008FC9C4: DC520280 077C0017
	global_load_b32 v8, v[23:24], off offset:768               // 0000008FC9CC: DC520300 087C0017
	global_load_b32 v9, v[23:24], off offset:896               // 0000008FC9D4: DC520380 097C0017
	global_load_b32 v10, v[23:24], off offset:1024             // 0000008FC9DC: DC520400 0A7C0017
	global_load_b32 v11, v[23:24], off offset:1152             // 0000008FC9E4: DC520480 0B7C0017
	global_load_b32 v12, v[23:24], off offset:1280             // 0000008FC9EC: DC520500 0C7C0017
	global_load_b32 v13, v[23:24], off offset:1408             // 0000008FC9F4: DC520580 0D7C0017
	s_branch 63596                                             // 0000008FC9FC: BFA0F86C <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_gsILi3ELi8ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiSA_S5_S5_PDF16_PfPj+0x5b0>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008FCA00: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000008FCA04: BF870009
	s_or_b32 exec_lo, exec_lo, s20                             // 0000008FCA08: 8C7E147E
	s_load_b128 s[20:23], s[0:1], 0x40                         // 0000008FCA0C: F4080500 F8000040
	s_waitcnt vmcnt(5)                                         // 0000008FCA14: BF8917F7
	v_dual_mov_b32 v57, v40 :: v_dual_mov_b32 v8, v41          // 0000008FCA18: CA100128 39080129
	v_dual_mov_b32 v58, v56 :: v_dual_mov_b32 v21, v53         // 0000008FCA20: CA100138 3A140135
	s_waitcnt vmcnt(3)                                         // 0000008FCA28: BF890FF7
	v_dual_mov_b32 v10, v39 :: v_dual_mov_b32 v5, v36          // 0000008FCA2C: CA100127 0A040124
	v_dual_mov_b32 v60, v55 :: v_dual_mov_b32 v9, v34          // 0000008FCA34: CA100137 3C080122
	v_dual_mov_b32 v4, v38 :: v_dual_mov_b32 v7, v35           // 0000008FCA3C: CA100126 04060123
	v_dual_mov_b32 v20, v54 :: v_dual_mov_b32 v59, v51         // 0000008FCA44: CA100136 143A0133
	v_dual_mov_b32 v6, v37 :: v_dual_mov_b32 v61, v50          // 0000008FCA4C: CA100125 063C0132
	s_waitcnt vmcnt(2)                                         // 0000008FCA54: BF890BF7
	v_dual_mov_b32 v24, v52 :: v_dual_mov_b32 v11, v33         // 0000008FCA58: CA100134 180A0121
	v_dual_mov_b32 v62, v49 :: v_dual_mov_b32 v63, v48         // 0000008FCA60: CA100131 3E3E0130
	s_waitcnt vmcnt(0)                                         // 0000008FCA68: BF8903F7
	v_dual_mov_b32 v12, v32 :: v_dual_mov_b32 v13, v31         // 0000008FCA6C: CA100120 0C0C011F
	v_dual_mov_b32 v64, v47 :: v_dual_mov_b32 v65, v46         // 0000008FCA74: CA10012F 4040012E
	v_dual_mov_b32 v14, v30 :: v_dual_mov_b32 v15, v29         // 0000008FCA7C: CA10011E 0E0E011D
	v_dual_mov_b32 v66, v45 :: v_dual_mov_b32 v67, v44         // 0000008FCA84: CA10012D 4242012C
	v_dual_mov_b32 v16, v28 :: v_dual_mov_b32 v17, v27         // 0000008FCA8C: CA10011C 1010011B
	v_dual_mov_b32 v68, v43 :: v_dual_mov_b32 v69, v42         // 0000008FCA94: CA10012B 4444012A
	v_dual_mov_b32 v18, v26 :: v_dual_mov_b32 v19, v1          // 0000008FCA9C: CA10011A 12120101
	s_mov_b32 s3, 0x76543210                                   // 0000008FCAA4: BE8300FF 76543210
	.long 0xd44c0000                                           // 0000008FCAAC: D44C0000
	v_cndmask_b32_e32 v1, 16, v0, vcc_lo                       // 0000008FCAB0: 02020090
	v_permlanex16_b32 v57, v57, s3, 0xfedcba98                 // 0000008FCAB4: D65C0039 03FC0739 FEDCBA98
	v_permlanex16_b32 v8, v8, s3, 0xfedcba98                   // 0000008FCAC0: D65C0008 03FC0708 FEDCBA98
	v_permlanex16_b32 v58, v58, s3, 0xfedcba98                 // 0000008FCACC: D65C003A 03FC073A FEDCBA98
	v_permlanex16_b32 v10, v10, s3, 0xfedcba98                 // 0000008FCAD8: D65C000A 03FC070A FEDCBA98
	v_permlanex16_b32 v60, v60, s3, 0xfedcba98                 // 0000008FCAE4: D65C003C 03FC073C FEDCBA98
	v_permlanex16_b32 v4, v4, s3, 0xfedcba98                   // 0000008FCAF0: D65C0004 03FC0704 FEDCBA98
	v_permlanex16_b32 v20, v20, s3, 0xfedcba98                 // 0000008FCAFC: D65C0014 03FC0714 FEDCBA98
	v_permlanex16_b32 v6, v6, s3, 0xfedcba98                   // 0000008FCB08: D65C0006 03FC0706 FEDCBA98
	v_permlanex16_b32 v21, v21, s3, 0xfedcba98                 // 0000008FCB14: D65C0015 03FC0715 FEDCBA98
	v_permlanex16_b32 v5, v5, s3, 0xfedcba98                   // 0000008FCB20: D65C0005 03FC0705 FEDCBA98
	v_permlanex16_b32 v24, v24, s3, 0xfedcba98                 // 0000008FCB2C: D65C0018 03FC0718 FEDCBA98
	v_permlanex16_b32 v7, v7, s3, 0xfedcba98                   // 0000008FCB38: D65C0007 03FC0707 FEDCBA98
	v_permlanex16_b32 v59, v59, s3, 0xfedcba98                 // 0000008FCB44: D65C003B 03FC073B FEDCBA98
	v_permlanex16_b32 v9, v9, s3, 0xfedcba98                   // 0000008FCB50: D65C0009 03FC0709 FEDCBA98
	v_permlanex16_b32 v61, v61, s3, 0xfedcba98                 // 0000008FCB5C: D65C003D 03FC073D FEDCBA98
	v_permlanex16_b32 v11, v11, s3, 0xfedcba98                 // 0000008FCB68: D65C000B 03FC070B FEDCBA98
	v_permlanex16_b32 v62, v62, s3, 0xfedcba98                 // 0000008FCB74: D65C003E 03FC073E FEDCBA98
	v_permlanex16_b32 v12, v12, s3, 0xfedcba98                 // 0000008FCB80: D65C000C 03FC070C FEDCBA98
	v_permlanex16_b32 v63, v63, s3, 0xfedcba98                 // 0000008FCB8C: D65C003F 03FC073F FEDCBA98
	v_permlanex16_b32 v13, v13, s3, 0xfedcba98                 // 0000008FCB98: D65C000D 03FC070D FEDCBA98
	v_permlanex16_b32 v64, v64, s3, 0xfedcba98                 // 0000008FCBA4: D65C0040 03FC0740 FEDCBA98
	v_permlanex16_b32 v14, v14, s3, 0xfedcba98                 // 0000008FCBB0: D65C000E 03FC070E FEDCBA98
	v_permlanex16_b32 v65, v65, s3, 0xfedcba98                 // 0000008FCBBC: D65C0041 03FC0741 FEDCBA98
	v_permlanex16_b32 v15, v15, s3, 0xfedcba98                 // 0000008FCBC8: D65C000F 03FC070F FEDCBA98
	v_permlanex16_b32 v66, v66, s3, 0xfedcba98                 // 0000008FCBD4: D65C0042 03FC0742 FEDCBA98
	v_permlanex16_b32 v16, v16, s3, 0xfedcba98                 // 0000008FCBE0: D65C0010 03FC0710 FEDCBA98
	v_permlanex16_b32 v67, v67, s3, 0xfedcba98                 // 0000008FCBEC: D65C0043 03FC0743 FEDCBA98
	v_permlanex16_b32 v17, v17, s3, 0xfedcba98                 // 0000008FCBF8: D65C0011 03FC0711 FEDCBA98
	v_permlanex16_b32 v68, v68, s3, 0xfedcba98                 // 0000008FCC04: D65C0044 03FC0744 FEDCBA98
	v_permlanex16_b32 v18, v18, s3, 0xfedcba98                 // 0000008FCC10: D65C0012 03FC0712 FEDCBA98
	v_permlanex16_b32 v69, v69, s3, 0xfedcba98                 // 0000008FCC1C: D65C0045 03FC0745 FEDCBA98
	v_permlanex16_b32 v19, v19, s3, 0xfedcba98                 // 0000008FCC28: D65C0013 03FC0713 FEDCBA98
	s_sub_i32 s1, s11, s10                                     // 0000008FCC34: 81810A0B
	s_and_saveexec_b32 s3, s0                                  // 0000008FCC38: BE832000
	s_cbranch_execz 147                                        // 0000008FCC3C: BFA50093 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_gsILi3ELi8ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiSA_S5_S5_PDF16_PfPj+0x288c>
	.long 0xd51a0017                                           // 0000008FCC40: D51A0017
	v_cndmask_b32_e32 v0, 31, v12, vcc_lo                      // 0000008FCC44: 0200189F
	s_cmp_lt_i32 s1, 1                                         // 0000008FCC48: BF048101
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008FCC4C: BF8700B1
	.long 0xd73c0002                                           // 0000008FCC50: D73C0002
	v_cndmask_b32_e32 v1, 4, v22, vcc_lo                       // 0000008FCC54: 02022C84
	s_waitcnt lgkmcnt(0)                                       // 0000008FCC58: BF89FC07
	.long 0xd7000416                                           // 0000008FCC5C: D7000416
	v_cndmask_b32_e32 v1, s20, v25, vcc_lo                     // 0000008FCC60: 02023214
	v_add_co_ci_u32_e64 v23, null, s21, 0, s4                  // 0000008FCC64: D5207C17 00110015
	s_cbranch_scc1 66                                          // 0000008FCC6C: BFA20042 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_gsILi3ELi8ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiSA_S5_S5_PDF16_PfPj+0x2778>
	s_mul_i32 s4, s10, 5                                       // 0000008FCC70: 9604850A
	s_mul_hi_i32 s5, s10, 5                                    // 0000008FCC74: 9705850A
	s_add_u32 s4, s4, s6                                       // 0000008FCC78: 80040604
	s_addc_u32 s5, s5, s7                                      // 0000008FCC7C: 82050705
	v_add_f32_e32 v25, v40, v57                                // 0000008FCC80: 06327328
	s_lshl_b64 s[4:5], s[4:5], 7                               // 0000008FCC84: 84848704
	v_dual_add_f32 v40, v56, v58 :: v_dual_add_f32 v57, v54, v20// 0000008FCC88: C9087538 28382936
	.long 0xd7006a36                                           // 0000008FCC90: D7006A36
	v_cndmask_b32_e32 v1, s4, v2, vcc_lo                       // 0000008FCC94: 02020404
	v_add_f32_e32 v56, v55, v60                                // 0000008FCC98: 06707937
	v_add_co_ci_u32_e64 v55, null, s5, v3, vcc_lo              // 0000008FCC9C: D5207C37 01AA0605
	v_dual_add_f32 v53, v53, v21 :: v_dual_add_f32 v24, v52, v24// 0000008FCCA4: C9082B35 35183134
	v_dual_add_f32 v51, v51, v59 :: v_dual_add_f32 v50, v50, v61// 0000008FCCAC: C9087733 33327B32
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000008FCCB4: BF870243
	.long 0xd73c0014                                           // 0000008FCCB8: D73C0014
	v_cndmask_b32_e32 v1, 6, v54, vcc_lo                       // 0000008FCCBC: 02026C86
	v_dual_add_f32 v49, v49, v62 :: v_dual_add_f32 v48, v48, v63// 0000008FCCC0: C9087D31 31307F30
	v_dual_add_f32 v47, v47, v64 :: v_dual_add_f32 v46, v46, v65// 0000008FCCC8: C908812F 2F2E832E
	v_dual_add_f32 v45, v45, v66 :: v_dual_add_f32 v44, v44, v67// 0000008FCCD0: C908852D 2D2C872C
	.long 0xd7006a14                                           // 0000008FCCD8: D7006A14
	v_cndmask_b32_e32 v1, v22, v20, vcc_lo                     // 0000008FCCDC: 02022916
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008FCCE0: BF870001
	v_add_co_ci_u32_e64 v21, null, v23, v21, vcc_lo            // 0000008FCCE4: D5207C15 01AA2B17
	v_dual_add_f32 v43, v43, v68 :: v_dual_add_f32 v42, v42, v69// 0000008FCCEC: C908892B 2B2A8B2A
	s_clause 0xf                                               // 0000008FCCF4: BF85000F
	global_store_b32 v[20:21], v25, off                        // 0000008FCCF8: DC6A0000 007C1914
	global_store_b32 v[20:21], v40, off offset:64              // 0000008FCD00: DC6A0040 007C2814
	global_store_b32 v[20:21], v56, off offset:128             // 0000008FCD08: DC6A0080 007C3814
	global_store_b32 v[20:21], v57, off offset:192             // 0000008FCD10: DC6A00C0 007C3914
	global_store_b32 v[20:21], v53, off offset:256             // 0000008FCD18: DC6A0100 007C3514
	global_store_b32 v[20:21], v24, off offset:320             // 0000008FCD20: DC6A0140 007C1814
	global_store_b32 v[20:21], v51, off offset:384             // 0000008FCD28: DC6A0180 007C3314
	global_store_b32 v[20:21], v50, off offset:448             // 0000008FCD30: DC6A01C0 007C3214
	global_store_b32 v[20:21], v49, off offset:512             // 0000008FCD38: DC6A0200 007C3114
	global_store_b32 v[20:21], v48, off offset:576             // 0000008FCD40: DC6A0240 007C3014
	global_store_b32 v[20:21], v47, off offset:640             // 0000008FCD48: DC6A0280 007C2F14
	global_store_b32 v[20:21], v46, off offset:704             // 0000008FCD50: DC6A02C0 007C2E14
	global_store_b32 v[20:21], v45, off offset:768             // 0000008FCD58: DC6A0300 007C2D14
	global_store_b32 v[20:21], v44, off offset:832             // 0000008FCD60: DC6A0340 007C2C14
	global_store_b32 v[20:21], v43, off offset:896             // 0000008FCD68: DC6A0380 007C2B14
	global_store_b32 v[20:21], v42, off offset:960             // 0000008FCD70: DC6A03C0 007C2A14
	s_cmp_lt_i32 s1, 2                                         // 0000008FCD78: BF048201
	s_cbranch_scc1 67                                          // 0000008FCD7C: BFA20043 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_gsILi3ELi8ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiSA_S5_S5_PDF16_PfPj+0x288c>
	s_add_i32 s4, s10, 1                                       // 0000008FCD80: 8104810A
	v_dual_add_f32 v8, v41, v8 :: v_dual_add_f32 v5, v36, v5   // 0000008FCD84: C9081129 08040B24
	s_mul_i32 s5, s4, 5                                        // 0000008FCD8C: 96058504
	s_mul_hi_i32 s11, s4, 5                                    // 0000008FCD90: 970B8504
	s_add_u32 s4, s5, s6                                       // 0000008FCD94: 80040605
	s_addc_u32 s5, s11, s7                                     // 0000008FCD98: 8205070B
	v_dual_add_f32 v10, v39, v10 :: v_dual_add_f32 v9, v34, v9 // 0000008FCD9C: C9081527 0A081322
	s_lshl_b64 s[4:5], s[4:5], 7                               // 0000008FCDA4: 84848704
	v_dual_add_f32 v4, v38, v4 :: v_dual_add_f32 v7, v35, v7   // 0000008FCDA8: C9080926 04060F23
	.long 0xd7006a02                                           // 0000008FCDB0: D7006A02
	v_cndmask_b32_e32 v1, s4, v2, vcc_lo                       // 0000008FCDB4: 02020404
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000008FCDB8: BF8701B1
	v_add_co_ci_u32_e64 v3, null, s5, v3, vcc_lo               // 0000008FCDBC: D5207C03 01AA0605
	v_dual_add_f32 v6, v37, v6 :: v_dual_add_f32 v13, v31, v13 // 0000008FCDC4: C9080D25 060C1B1F
	v_dual_add_f32 v11, v33, v11 :: v_dual_add_f32 v12, v32, v12// 0000008FCDCC: C9081721 0B0C1920
	.long 0xd73c0002                                           // 0000008FCDD4: D73C0002
	v_cndmask_b32_e32 v1, 6, v2, vcc_lo                        // 0000008FCDD8: 02020486
	v_dual_add_f32 v14, v30, v14 :: v_dual_add_f32 v15, v29, v15// 0000008FCDDC: C9081D1E 0E0E1F1D
	v_dual_add_f32 v16, v28, v16 :: v_dual_add_f32 v17, v27, v17// 0000008FCDE4: C908211C 1010231B
	v_dual_add_f32 v18, v26, v18 :: v_dual_add_f32 v1, v1, v19 // 0000008FCDEC: C908251A 12002701
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008FCDF4: BF870094
	.long 0xd7006a02                                           // 0000008FCDF8: D7006A02
	v_cndmask_b32_e32 v1, v22, v2, vcc_lo                      // 0000008FCDFC: 02020516
	v_add_co_ci_u32_e64 v3, null, v23, v3, vcc_lo              // 0000008FCE00: D5207C03 01AA0717
	s_clause 0xf                                               // 0000008FCE08: BF85000F
	global_store_b32 v[2:3], v8, off                           // 0000008FCE0C: DC6A0000 007C0802
	global_store_b32 v[2:3], v10, off offset:64                // 0000008FCE14: DC6A0040 007C0A02
	global_store_b32 v[2:3], v4, off offset:128                // 0000008FCE1C: DC6A0080 007C0402
	global_store_b32 v[2:3], v6, off offset:192                // 0000008FCE24: DC6A00C0 007C0602
	global_store_b32 v[2:3], v5, off offset:256                // 0000008FCE2C: DC6A0100 007C0502
	global_store_b32 v[2:3], v7, off offset:320                // 0000008FCE34: DC6A0140 007C0702
	global_store_b32 v[2:3], v9, off offset:384                // 0000008FCE3C: DC6A0180 007C0902
	global_store_b32 v[2:3], v11, off offset:448               // 0000008FCE44: DC6A01C0 007C0B02
	global_store_b32 v[2:3], v12, off offset:512               // 0000008FCE4C: DC6A0200 007C0C02
	global_store_b32 v[2:3], v13, off offset:576               // 0000008FCE54: DC6A0240 007C0D02
	global_store_b32 v[2:3], v14, off offset:640               // 0000008FCE5C: DC6A0280 007C0E02
	global_store_b32 v[2:3], v15, off offset:704               // 0000008FCE64: DC6A02C0 007C0F02
	global_store_b32 v[2:3], v16, off offset:768               // 0000008FCE6C: DC6A0300 007C1002
	global_store_b32 v[2:3], v17, off offset:832               // 0000008FCE74: DC6A0340 007C1102
	global_store_b32 v[2:3], v18, off offset:896               // 0000008FCE7C: DC6A0380 007C1202
	global_store_b32 v[2:3], v1, off offset:960                // 0000008FCE84: DC6A03C0 007C0102
	s_or_b32 exec_lo, exec_lo, s3                              // 0000008FCE8C: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000008FCE90: BF870009
	s_mov_b32 s3, exec_lo                                      // 0000008FCE94: BE83007E
	s_waitcnt lgkmcnt(0)                                       // 0000008FCE98: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 0000008FCE9C: BC7C0000
	buffer_gl1_inv                                             // 0000008FCEA0: E0B00000 00000000
	buffer_gl0_inv                                             // 0000008FCEA8: E0AC0000 00000000
	v_cmpx_eq_u32_e32 0, v0                                    // 0000008FCEB0: 7D940080
	s_cbranch_execz 27                                         // 0000008FCEB4: BFA5001B <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_gsILi3ELi8ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiSA_S5_S5_PDF16_PfPj+0x2924>
	s_mov_b32 s5, exec_lo                                      // 0000008FCEB8: BE85007E
	s_mov_b32 s4, exec_lo                                      // 0000008FCEBC: BE84007E
	.long 0xd71f0001                                           // 0000008FCEC0: D71F0001
	v_cndmask_b32_e32 v0, s5, v128, vcc_lo                     // 0000008FCEC4: 02010005
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008FCEC8: BF870001
	v_cmpx_eq_u32_e32 0, v1                                    // 0000008FCECC: 7D940280
	s_cbranch_execz 9                                          // 0000008FCED0: BFA50009 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_gsILi3ELi8ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiSA_S5_S5_PDF16_PfPj+0x28f8>
	s_lshl_b64 s[12:13], s[24:25], 2                           // 0000008FCED4: 848C8218
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000008FCED8: BF8704B9
	s_add_u32 s12, s22, s12                                    // 0000008FCEDC: 800C0C16
	s_addc_u32 s13, s23, s13                                   // 0000008FCEE0: 820D0D17
	s_bcnt1_i32_b32 s5, s5                                     // 0000008FCEE4: BE851805
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, s5              // 0000008FCEE8: CA100080 02020005
	global_atomic_add_u32 v2, v2, v3, s[12:13] glc             // 0000008FCEF0: DCD64000 020C0302
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008FCEF8: 8C7E047E
	s_waitcnt vmcnt(0)                                         // 0000008FCEFC: BF8903F7
	v_readfirstlane_b32 s4, v2                                 // 0000008FCF00: 7E080502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008FCF04: BF870091
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s4, v1       // 0000008FCF08: CA200080 02000204
	v_cmp_eq_u32_e32 vcc_lo, 7, v1                             // 0000008FCF10: 7C940287
	v_cndmask_b32_e64 v1, 0, 1, vcc_lo                         // 0000008FCF14: D5010001 01A90280
	ds_store_b32 v2, v1 offset:11840                           // 0000008FCF1C: D8342E40 00000102
	s_or_b32 exec_lo, exec_lo, s3                              // 0000008FCF24: 8C7E037E
	v_mov_b32_e32 v1, 0                                        // 0000008FCF28: 7E020280
	ds_load_b32 v1, v1 offset:11840                            // 0000008FCF2C: D8D82E40 01000001
	s_waitcnt lgkmcnt(0)                                       // 0000008FCF34: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 0000008FCF38: 7C940280
	s_cbranch_vccnz 1549                                       // 0000008FCF3C: BFA4060D <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_gsILi3ELi8ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiSA_S5_S5_PDF16_PfPj+0x4174>
	s_mov_b32 s3, -1                                           // 0000008FCF40: BE8300C1
	buffer_gl1_inv                                             // 0000008FCF44: E0B00000 00000000
	buffer_gl0_inv                                             // 0000008FCF4C: E0AC0000 00000000
	s_and_saveexec_b32 s4, s3                                  // 0000008FCF54: BE842003
	s_cbranch_execz 1542                                       // 0000008FCF58: BFA50606 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_gsILi3ELi8ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiSA_S5_S5_PDF16_PfPj+0x4174>
	s_cmp_lt_i32 s1, 1                                         // 0000008FCF5C: BF048101
	s_cbranch_scc1 1532                                        // 0000008FCF60: BFA205FC <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_gsILi3ELi8ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiSA_S5_S5_PDF16_PfPj+0x4154>
	s_min_i32 s11, s1, 2                                       // 0000008FCF64: 890B8201
	s_mul_i32 s1, s8, 0x500                                    // 0000008FCF68: 9601FF08 00000500
	s_mul_hi_i32 s3, s8, 0x500                                 // 0000008FCF70: 9703FF08 00000500
	s_add_u32 s1, s16, s1                                      // 0000008FCF78: 80010110
	s_addc_u32 s3, s17, s3                                     // 0000008FCF7C: 82030311
	s_lshl_b32 s4, s9, 7                                       // 0000008FCF80: 84048709
	v_and_b32_e32 v1, 15, v0                                   // 0000008FCF84: 3602008F
	s_ashr_i32 s5, s4, 31                                      // 0000008FCF88: 86059F04
	s_mul_i32 s9, s8, 0xa00                                    // 0000008FCF8C: 9609FF08 00000A00
	s_lshl_b64 s[12:13], s[4:5], 1                             // 0000008FCF94: 848C8104
	v_lshlrev_b32_e32 v2, 1, v0                                // 0000008FCF98: 30040081
	s_add_u32 s4, s1, s12                                      // 0000008FCF9C: 80040C01
	v_lshlrev_b32_e32 v28, 1, v1                               // 0000008FCFA0: 30380281
	s_addc_u32 s5, s3, s13                                     // 0000008FCFA4: 82050D03
	s_mul_hi_i32 s1, s8, 0xa00                                 // 0000008FCFA8: 9701FF08 00000A00
	s_add_u32 s3, s14, s9                                      // 0000008FCFB0: 8003090E
	s_addc_u32 s1, s15, s1                                     // 0000008FCFB4: 8201010F
	s_add_u32 s8, s3, s12                                      // 0000008FCFB8: 80080C03
	s_addc_u32 s9, s1, s13                                     // 0000008FCFBC: 82090D01
	v_or_b32_e32 v4, 32, v2                                    // 0000008FCFC0: 380804A0
	v_or_b32_e32 v5, 0x60, v2                                  // 0000008FCFC4: 380A04FF 00000060
	v_or_b32_e32 v6, 0xa0, v2                                  // 0000008FCFCC: 380C04FF 000000A0
	v_or_b32_e32 v7, 0xe0, v2                                  // 0000008FCFD4: 380E04FF 000000E0
	s_clause 0x8                                               // 0000008FCFDC: BF850008
	global_load_d16_b16 v2, v28, s[4:5]                        // 0000008FCFE0: DC820000 0204001C
	global_load_d16_hi_b16 v2, v28, s[4:5] offset:128          // 0000008FCFE8: DC8E0080 0204001C
	global_load_d16_b16 v3, v28, s[4:5] offset:64              // 0000008FCFF0: DC820040 0304001C
	global_load_d16_hi_b16 v3, v28, s[8:9] offset:128          // 0000008FCFF8: DC8E0080 0308001C
	global_load_d16_b16 v8, v28, s[8:9] offset:192             // 0000008FD000: DC8200C0 0808001C
	global_load_d16_b16 v9, v28, s[8:9] offset:1408            // 0000008FD008: DC820580 0908001C
	global_load_d16_b16 v10, v28, s[8:9] offset:1472           // 0000008FD010: DC8205C0 0A08001C
	global_load_d16_b16 v18, v28, s[8:9] offset:64             // 0000008FD018: DC820040 1208001C
	global_load_d16_b16 v11, v28, s[4:5] offset:192            // 0000008FD020: DC8200C0 0B04001C
	s_clause 0x3                                               // 0000008FD028: BF850003
	global_load_d16_b16 v12, v6, s[8:9]                        // 0000008FD02C: DC820000 0C080006
	global_load_d16_b16 v13, v7, s[8:9]                        // 0000008FD034: DC820000 0D080007
	global_load_d16_b16 v14, v6, s[8:9] offset:1280            // 0000008FD03C: DC820500 0E080006
	global_load_d16_b16 v15, v7, s[8:9] offset:1280            // 0000008FD044: DC820500 0F080007
	s_clause 0x1                                               // 0000008FD04C: BF850001
	global_load_d16_b16 v16, v6, s[4:5]                        // 0000008FD050: DC820000 10040006
	global_load_d16_b16 v17, v7, s[4:5]                        // 0000008FD058: DC820000 11040007
	s_clause 0x6                                               // 0000008FD060: BF850006
	global_load_d16_b16 v19, v28, s[8:9]                       // 0000008FD064: DC820000 1308001C
	global_load_d16_b16 v20, v5, s[8:9]                        // 0000008FD06C: DC820000 14080005
	global_load_d16_b16 v21, v4, s[8:9]                        // 0000008FD074: DC820000 15080004
	global_load_d16_b16 v22, v28, s[8:9] offset:1344           // 0000008FD07C: DC820540 1608001C
	global_load_d16_b16 v23, v28, s[8:9] offset:1280           // 0000008FD084: DC820500 1708001C
	global_load_d16_b16 v24, v5, s[8:9] offset:1280            // 0000008FD08C: DC820500 18080005
	global_load_d16_b16 v25, v4, s[8:9] offset:1280            // 0000008FD094: DC820500 19080004
	s_clause 0x1                                               // 0000008FD09C: BF850001
	global_load_d16_b16 v26, v5, s[4:5]                        // 0000008FD0A0: DC820000 1A040005
	global_load_d16_b16 v27, v4, s[4:5]                        // 0000008FD0A8: DC820000 1B040004
	v_and_b32_e32 v4, 1, v0                                    // 0000008FD0B0: 36080081
	v_and_b32_e32 v5, 2, v0                                    // 0000008FD0B4: 360A0082
	v_and_b32_e32 v6, 4, v0                                    // 0000008FD0B8: 360C0084
	v_and_b32_e32 v0, 8, v0                                    // 0000008FD0BC: 36000088
	s_mul_i32 s9, s10, 0xa000                                  // 0000008FD0C0: 9609FF0A 0000A000
	s_lshl_b64 s[6:7], s[6:7], 13                              // 0000008FD0C8: 84868D06
	s_mul_hi_i32 s8, s10, 0xa000                               // 0000008FD0CC: 9708FF0A 0000A000
	s_add_u32 s6, s9, s6                                       // 0000008FD0D4: 80060609
	.long 0xd44a0005                                           // 0000008FD0D8: D44A0005
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 0000008FD0DC: 02020080
	v_lshlrev_b32_e32 v0, 2, v1                                // 0000008FD0E0: 30000282
	s_addc_u32 s7, s8, s7                                      // 0000008FD0E4: 82070708
	s_add_u32 s6, s20, s6                                      // 0000008FD0E8: 80060614
	s_mul_hi_i32 s14, s10, 0x500                               // 0000008FD0EC: 970EFF0A 00000500
	s_mulk_i32 s10, 0x500                                      // 0000008FD0F4: B80A0500
	s_addc_u32 s7, s21, s7                                     // 0000008FD0F8: 82070715
	.long 0xd7000600                                           // 0000008FD0FC: D7000600
	v_cndmask_b32_e32 v1, s6, v0, vcc_lo                       // 0000008FD100: 02020006
	s_add_u32 s8, s10, s12                                     // 0000008FD104: 80080C0A
	v_add_co_ci_u32_e64 v1, null, s7, 0, s6                    // 0000008FD108: D5207C01 00190007
	s_addc_u32 s6, s14, s13                                    // 0000008FD110: 82060D0E
	s_add_u32 s7, s18, s8                                      // 0000008FD114: 80070812
	.long 0xd44a0001                                           // 0000008FD118: D44A0001
	v_cndmask_b32_e32 v1, 0, v4, vcc_lo                        // 0000008FD11C: 02020880
	.long 0xd44a0004                                           // 0000008FD120: D44A0004
	v_cndmask_b32_e32 v1, 0, v6, vcc_lo                        // 0000008FD124: 02020C80
	s_addc_u32 s6, s19, s6                                     // 0000008FD128: 82060613
	.long 0xd7006a00                                           // 0000008FD12C: D7006A00
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 0000008FD130: 020200FF 00001000
	.long 0xd44a0003                                           // 0000008FD138: D44A0003
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 0000008FD13C: 02020A80
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 0000008FD140: D5207C01 01AA0280
	s_mov_b32 s9, 0x3db504f3                                   // 0000008FD148: BE8900FF 3DB504F3
	s_waitcnt vmcnt(22)                                        // 0000008FD150: BF895BF7
	v_cvt_f32_f16_e32 v6, v2                                   // 0000008FD154: 7E0C1702
	v_cvt_f32_f16_e32 v4, v130/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000008FD158: 7E081782
	.long 0xd7000702                                           // 0000008FD15C: D7000702
	v_cndmask_b32_e32 v1, s7, v28, vcc_lo                      // 0000008FD160: 02023807
	s_waitcnt vmcnt(20)                                        // 0000008FD164: BF8953F7
	v_cvt_f32_f16_e32 v5, v3                                   // 0000008FD168: 7E0A1703
	v_cvt_f32_f16_e32 v7, v131/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000008FD16C: 7E0E1783
	s_waitcnt vmcnt(19)                                        // 0000008FD170: BF894FF7
	v_cvt_f32_f16_e32 v8, v8                                   // 0000008FD174: 7E101708
	s_waitcnt vmcnt(18)                                        // 0000008FD178: BF894BF7
	v_cvt_f32_f16_e32 v9, v9                                   // 0000008FD17C: 7E121709
	s_waitcnt vmcnt(17)                                        // 0000008FD180: BF8947F7
	v_cvt_f32_f16_e32 v10, v10                                 // 0000008FD184: 7E14170A
	s_waitcnt vmcnt(15)                                        // 0000008FD188: BF893FF7
	v_cvt_f32_f16_e32 v11, v11                                 // 0000008FD18C: 7E16170B
	s_waitcnt vmcnt(14)                                        // 0000008FD190: BF893BF7
	v_cvt_f32_f16_e32 v12, v12                                 // 0000008FD194: 7E18170C
	s_waitcnt vmcnt(13)                                        // 0000008FD198: BF8937F7
	v_cvt_f32_f16_e32 v13, v13                                 // 0000008FD19C: 7E1A170D
	s_waitcnt vmcnt(12)                                        // 0000008FD1A0: BF8933F7
	v_cvt_f32_f16_e32 v14, v14                                 // 0000008FD1A4: 7E1C170E
	s_waitcnt vmcnt(11)                                        // 0000008FD1A8: BF892FF7
	v_cvt_f32_f16_e32 v15, v15                                 // 0000008FD1AC: 7E1E170F
	s_waitcnt vmcnt(10)                                        // 0000008FD1B0: BF892BF7
	v_cvt_f32_f16_e32 v16, v16                                 // 0000008FD1B4: 7E201710
	s_waitcnt vmcnt(9)                                         // 0000008FD1B8: BF8927F7
	v_cvt_f32_f16_e32 v17, v17                                 // 0000008FD1BC: 7E221711
	v_cvt_f32_f16_e32 v18, v18                                 // 0000008FD1C0: 7E241712
	s_waitcnt vmcnt(8)                                         // 0000008FD1C4: BF8923F7
	v_cvt_f32_f16_e32 v19, v19                                 // 0000008FD1C8: 7E261713
	s_waitcnt vmcnt(7)                                         // 0000008FD1CC: BF891FF7
	v_cvt_f32_f16_e32 v20, v20                                 // 0000008FD1D0: 7E281714
	s_waitcnt vmcnt(6)                                         // 0000008FD1D4: BF891BF7
	v_cvt_f32_f16_e32 v21, v21                                 // 0000008FD1D8: 7E2A1715
	s_waitcnt vmcnt(5)                                         // 0000008FD1DC: BF8917F7
	v_cvt_f32_f16_e32 v22, v22                                 // 0000008FD1E0: 7E2C1716
	s_waitcnt vmcnt(4)                                         // 0000008FD1E4: BF8913F7
	v_cvt_f32_f16_e32 v23, v23                                 // 0000008FD1E8: 7E2E1717
	s_waitcnt vmcnt(3)                                         // 0000008FD1EC: BF890FF7
	v_cvt_f32_f16_e32 v24, v24                                 // 0000008FD1F0: 7E301718
	s_waitcnt vmcnt(2)                                         // 0000008FD1F4: BF890BF7
	v_cvt_f32_f16_e32 v25, v25                                 // 0000008FD1F8: 7E321719
	s_waitcnt vmcnt(1)                                         // 0000008FD1FC: BF8907F7
	v_cvt_f32_f16_e32 v26, v26                                 // 0000008FD200: 7E34171A
	s_waitcnt vmcnt(0)                                         // 0000008FD204: BF8903F7
	v_cvt_f32_f16_e32 v27, v27                                 // 0000008FD208: 7E36171B
	v_add_co_ci_u32_e64 v3, null, s6, 0, s7                    // 0000008FD20C: D5207C03 001D0006
	s_branch 16                                                // 0000008FD214: BFA00010 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_gsILi3ELi8ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiSA_S5_S5_PDF16_PfPj+0x2c58>
	s_or_b32 exec_lo, exec_lo, s6                              // 0000008FD218: 8C7E067E
	.long 0xd7006a00                                           // 0000008FD21C: D7006A00
	v_cndmask_b32_e32 v1, 0xa000, v0, vcc_lo                   // 0000008FD220: 020200FF 0000A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008FD228: BF8700A1
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 0000008FD22C: D5207C01 01AA0280
	.long 0xd7006a02                                           // 0000008FD234: D7006A02
	v_cndmask_b32_e32 v1, 0x500, v2, vcc_lo                    // 0000008FD238: 020204FF 00000500
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 0000008FD240: D5207C03 01AA0680
	s_add_i32 s11, s11, -1                                     // 0000008FD248: 810BC10B
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000008FD24C: BF870009
	s_cmp_eq_u32 s11, 0                                        // 0000008FD250: BF06800B
	s_cbranch_scc1 1343                                        // 0000008FD254: BFA2053F <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_gsILi3ELi8ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiSA_S5_S5_PDF16_PfPj+0x4154>
	s_clause 0x1f                                              // 0000008FD258: BF85001F
	global_load_b32 v28, v[0:1], off offset:-4096 glc          // 0000008FD25C: DC525000 1C7C0000
	global_load_b32 v29, v[0:1], off offset:-3584 glc          // 0000008FD264: DC525200 1D7C0000
	global_load_b32 v30, v[0:1], off offset:-3072 glc          // 0000008FD26C: DC525400 1E7C0000
	global_load_b32 v31, v[0:1], off offset:-2560 glc          // 0000008FD274: DC525600 1F7C0000
	global_load_b32 v32, v[0:1], off offset:-2048 glc          // 0000008FD27C: DC525800 207C0000
	global_load_b32 v33, v[0:1], off offset:-1536 glc          // 0000008FD284: DC525A00 217C0000
	global_load_b32 v34, v[0:1], off offset:-1024 glc          // 0000008FD28C: DC525C00 227C0000
	global_load_b32 v35, v[0:1], off offset:-512 glc           // 0000008FD294: DC525E00 237C0000
	global_load_b32 v36, v[0:1], off glc                       // 0000008FD29C: DC524000 247C0000
	global_load_b32 v37, v[0:1], off offset:512 glc            // 0000008FD2A4: DC524200 257C0000
	global_load_b32 v38, v[0:1], off offset:1024 glc           // 0000008FD2AC: DC524400 267C0000
	global_load_b32 v39, v[0:1], off offset:1536 glc           // 0000008FD2B4: DC524600 277C0000
	global_load_b32 v40, v[0:1], off offset:2048 glc           // 0000008FD2BC: DC524800 287C0000
	global_load_b32 v41, v[0:1], off offset:2560 glc           // 0000008FD2C4: DC524A00 297C0000
	global_load_b32 v42, v[0:1], off offset:3072 glc           // 0000008FD2CC: DC524C00 2A7C0000
	global_load_b32 v43, v[0:1], off offset:3584 glc           // 0000008FD2D4: DC524E00 2B7C0000
	global_load_b32 v44, v[0:1], off offset:-4032 glc          // 0000008FD2DC: DC525040 2C7C0000
	global_load_b32 v45, v[0:1], off offset:-3520 glc          // 0000008FD2E4: DC525240 2D7C0000
	global_load_b32 v46, v[0:1], off offset:-3008 glc          // 0000008FD2EC: DC525440 2E7C0000
	global_load_b32 v47, v[0:1], off offset:-2496 glc          // 0000008FD2F4: DC525640 2F7C0000
	global_load_b32 v48, v[0:1], off offset:-1984 glc          // 0000008FD2FC: DC525840 307C0000
	global_load_b32 v49, v[0:1], off offset:-1472 glc          // 0000008FD304: DC525A40 317C0000
	global_load_b32 v50, v[0:1], off offset:-960 glc           // 0000008FD30C: DC525C40 327C0000
	global_load_b32 v51, v[0:1], off offset:-448 glc           // 0000008FD314: DC525E40 337C0000
	global_load_b32 v52, v[0:1], off offset:64 glc             // 0000008FD31C: DC524040 347C0000
	global_load_b32 v53, v[0:1], off offset:576 glc            // 0000008FD324: DC524240 357C0000
	global_load_b32 v54, v[0:1], off offset:1088 glc           // 0000008FD32C: DC524440 367C0000
	global_load_b32 v55, v[0:1], off offset:1600 glc           // 0000008FD334: DC524640 377C0000
	global_load_b32 v56, v[0:1], off offset:2112 glc           // 0000008FD33C: DC524840 387C0000
	global_load_b32 v57, v[0:1], off offset:2624 glc           // 0000008FD344: DC524A40 397C0000
	global_load_b32 v58, v[0:1], off offset:3136 glc           // 0000008FD34C: DC524C40 3A7C0000
	global_load_b32 v59, v[0:1], off offset:3648 glc           // 0000008FD354: DC524E40 3B7C0000
	s_clause 0x1f                                              // 0000008FD35C: BF85001F
	global_load_b32 v60, v[0:1], off offset:-3968 glc          // 0000008FD360: DC525080 3C7C0000
	global_load_b32 v61, v[0:1], off offset:-3456 glc          // 0000008FD368: DC525280 3D7C0000
	global_load_b32 v62, v[0:1], off offset:-2944 glc          // 0000008FD370: DC525480 3E7C0000
	global_load_b32 v63, v[0:1], off offset:-2432 glc          // 0000008FD378: DC525680 3F7C0000
	global_load_b32 v64, v[0:1], off offset:-1920 glc          // 0000008FD380: DC525880 407C0000
	global_load_b32 v65, v[0:1], off offset:-1408 glc          // 0000008FD388: DC525A80 417C0000
	global_load_b32 v66, v[0:1], off offset:-896 glc           // 0000008FD390: DC525C80 427C0000
	global_load_b32 v67, v[0:1], off offset:-384 glc           // 0000008FD398: DC525E80 437C0000
	global_load_b32 v68, v[0:1], off offset:128 glc            // 0000008FD3A0: DC524080 447C0000
	global_load_b32 v69, v[0:1], off offset:640 glc            // 0000008FD3A8: DC524280 457C0000
	global_load_b32 v70, v[0:1], off offset:1152 glc           // 0000008FD3B0: DC524480 467C0000
	global_load_b32 v71, v[0:1], off offset:1664 glc           // 0000008FD3B8: DC524680 477C0000
	global_load_b32 v72, v[0:1], off offset:2176 glc           // 0000008FD3C0: DC524880 487C0000
	global_load_b32 v73, v[0:1], off offset:2688 glc           // 0000008FD3C8: DC524A80 497C0000
	global_load_b32 v74, v[0:1], off offset:3200 glc           // 0000008FD3D0: DC524C80 4A7C0000
	global_load_b32 v75, v[0:1], off offset:3712 glc           // 0000008FD3D8: DC524E80 4B7C0000
	global_load_b32 v76, v[0:1], off offset:-3904 glc          // 0000008FD3E0: DC5250C0 4C7C0000
	global_load_b32 v77, v[0:1], off offset:-3392 glc          // 0000008FD3E8: DC5252C0 4D7C0000
	global_load_b32 v78, v[0:1], off offset:-2880 glc          // 0000008FD3F0: DC5254C0 4E7C0000
	global_load_b32 v79, v[0:1], off offset:-2368 glc          // 0000008FD3F8: DC5256C0 4F7C0000
	global_load_b32 v80, v[0:1], off offset:-1856 glc          // 0000008FD400: DC5258C0 507C0000
	global_load_b32 v81, v[0:1], off offset:-1344 glc          // 0000008FD408: DC525AC0 517C0000
	global_load_b32 v82, v[0:1], off offset:-832 glc           // 0000008FD410: DC525CC0 527C0000
	global_load_b32 v83, v[0:1], off offset:-320 glc           // 0000008FD418: DC525EC0 537C0000
	global_load_b32 v84, v[0:1], off offset:192 glc            // 0000008FD420: DC5240C0 547C0000
	global_load_b32 v85, v[0:1], off offset:704 glc            // 0000008FD428: DC5242C0 557C0000
	global_load_b32 v86, v[0:1], off offset:1216 glc           // 0000008FD430: DC5244C0 567C0000
	global_load_b32 v87, v[0:1], off offset:1728 glc           // 0000008FD438: DC5246C0 577C0000
	global_load_b32 v88, v[0:1], off offset:2240 glc           // 0000008FD440: DC5248C0 587C0000
	global_load_b32 v89, v[0:1], off offset:2752 glc           // 0000008FD448: DC524AC0 597C0000
	global_load_b32 v90, v[0:1], off offset:3264 glc           // 0000008FD450: DC524CC0 5A7C0000
	global_load_b32 v91, v[0:1], off offset:3776 glc           // 0000008FD458: DC524EC0 5B7C0000
	s_clause 0x1f                                              // 0000008FD460: BF85001F
	global_load_b32 v92, v[0:1], off offset:-3840 glc          // 0000008FD464: DC525100 5C7C0000
	global_load_b32 v93, v[0:1], off offset:-3328 glc          // 0000008FD46C: DC525300 5D7C0000
	global_load_b32 v94, v[0:1], off offset:-2816 glc          // 0000008FD474: DC525500 5E7C0000
	global_load_b32 v95, v[0:1], off offset:-2304 glc          // 0000008FD47C: DC525700 5F7C0000
	global_load_b32 v96, v[0:1], off offset:-1792 glc          // 0000008FD484: DC525900 607C0000
	global_load_b32 v97, v[0:1], off offset:-1280 glc          // 0000008FD48C: DC525B00 617C0000
	global_load_b32 v98, v[0:1], off offset:-768 glc           // 0000008FD494: DC525D00 627C0000
	global_load_b32 v99, v[0:1], off offset:-256 glc           // 0000008FD49C: DC525F00 637C0000
	global_load_b32 v100, v[0:1], off offset:256 glc           // 0000008FD4A4: DC524100 647C0000
	global_load_b32 v101, v[0:1], off offset:768 glc           // 0000008FD4AC: DC524300 657C0000
	global_load_b32 v102, v[0:1], off offset:1280 glc          // 0000008FD4B4: DC524500 667C0000
	global_load_b32 v103, v[0:1], off offset:1792 glc          // 0000008FD4BC: DC524700 677C0000
	global_load_b32 v104, v[0:1], off offset:2304 glc          // 0000008FD4C4: DC524900 687C0000
	global_load_b32 v105, v[0:1], off offset:2816 glc          // 0000008FD4CC: DC524B00 697C0000
	global_load_b32 v106, v[0:1], off offset:3328 glc          // 0000008FD4D4: DC524D00 6A7C0000
	global_load_b32 v107, v[0:1], off offset:3840 glc          // 0000008FD4DC: DC524F00 6B7C0000
	global_load_b32 v108, v[0:1], off offset:-3776 glc         // 0000008FD4E4: DC525140 6C7C0000
	global_load_b32 v109, v[0:1], off offset:-3264 glc         // 0000008FD4EC: DC525340 6D7C0000
	global_load_b32 v110, v[0:1], off offset:-2752 glc         // 0000008FD4F4: DC525540 6E7C0000
	global_load_b32 v111, v[0:1], off offset:-2240 glc         // 0000008FD4FC: DC525740 6F7C0000
	global_load_b32 v112, v[0:1], off offset:-1728 glc         // 0000008FD504: DC525940 707C0000
	global_load_b32 v113, v[0:1], off offset:-1216 glc         // 0000008FD50C: DC525B40 717C0000
	global_load_b32 v114, v[0:1], off offset:-704 glc          // 0000008FD514: DC525D40 727C0000
	global_load_b32 v115, v[0:1], off offset:-192 glc          // 0000008FD51C: DC525F40 737C0000
	global_load_b32 v116, v[0:1], off offset:320 glc           // 0000008FD524: DC524140 747C0000
	global_load_b32 v117, v[0:1], off offset:832 glc           // 0000008FD52C: DC524340 757C0000
	global_load_b32 v118, v[0:1], off offset:1344 glc          // 0000008FD534: DC524540 767C0000
	global_load_b32 v119, v[0:1], off offset:1856 glc          // 0000008FD53C: DC524740 777C0000
	global_load_b32 v120, v[0:1], off offset:2368 glc          // 0000008FD544: DC524940 787C0000
	global_load_b32 v121, v[0:1], off offset:2880 glc          // 0000008FD54C: DC524B40 797C0000
	global_load_b32 v122, v[0:1], off offset:3392 glc          // 0000008FD554: DC524D40 7A7C0000
	global_load_b32 v123, v[0:1], off offset:3904 glc          // 0000008FD55C: DC524F40 7B7C0000
	s_clause 0x1f                                              // 0000008FD564: BF85001F
	global_load_b32 v124, v[0:1], off offset:-3712 glc         // 0000008FD568: DC525180 7C7C0000
	global_load_b32 v125, v[0:1], off offset:-3200 glc         // 0000008FD570: DC525380 7D7C0000
	global_load_b32 v126, v[0:1], off offset:-2688 glc         // 0000008FD578: DC525580 7E7C0000
	global_load_b32 v127, v[0:1], off offset:-2176 glc         // 0000008FD580: DC525780 7F7C0000
	global_load_b32 v128, v[0:1], off offset:-1664 glc         // 0000008FD588: DC525980 807C0000
	global_load_b32 v129, v[0:1], off offset:-1152 glc         // 0000008FD590: DC525B80 817C0000
	global_load_b32 v130, v[0:1], off offset:-640 glc          // 0000008FD598: DC525D80 827C0000
	global_load_b32 v131, v[0:1], off offset:-128 glc          // 0000008FD5A0: DC525F80 837C0000
	global_load_b32 v132, v[0:1], off offset:384 glc           // 0000008FD5A8: DC524180 847C0000
	global_load_b32 v133, v[0:1], off offset:896 glc           // 0000008FD5B0: DC524380 857C0000
	global_load_b32 v134, v[0:1], off offset:1408 glc          // 0000008FD5B8: DC524580 867C0000
	global_load_b32 v135, v[0:1], off offset:1920 glc          // 0000008FD5C0: DC524780 877C0000
	global_load_b32 v136, v[0:1], off offset:2432 glc          // 0000008FD5C8: DC524980 887C0000
	global_load_b32 v137, v[0:1], off offset:2944 glc          // 0000008FD5D0: DC524B80 897C0000
	global_load_b32 v138, v[0:1], off offset:3456 glc          // 0000008FD5D8: DC524D80 8A7C0000
	global_load_b32 v139, v[0:1], off offset:3968 glc          // 0000008FD5E0: DC524F80 8B7C0000
	global_load_b32 v140, v[0:1], off offset:-3648 glc         // 0000008FD5E8: DC5251C0 8C7C0000
	global_load_b32 v141, v[0:1], off offset:-3136 glc         // 0000008FD5F0: DC5253C0 8D7C0000
	global_load_b32 v142, v[0:1], off offset:-2624 glc         // 0000008FD5F8: DC5255C0 8E7C0000
	global_load_b32 v143, v[0:1], off offset:-2112 glc         // 0000008FD600: DC5257C0 8F7C0000
	global_load_b32 v144, v[0:1], off offset:-1600 glc         // 0000008FD608: DC5259C0 907C0000
	global_load_b32 v145, v[0:1], off offset:-1088 glc         // 0000008FD610: DC525BC0 917C0000
	global_load_b32 v146, v[0:1], off offset:-576 glc          // 0000008FD618: DC525DC0 927C0000
	global_load_b32 v147, v[0:1], off offset:-64 glc           // 0000008FD620: DC525FC0 937C0000
	global_load_b32 v148, v[0:1], off offset:448 glc           // 0000008FD628: DC5241C0 947C0000
	global_load_b32 v149, v[0:1], off offset:960 glc           // 0000008FD630: DC5243C0 957C0000
	global_load_b32 v150, v[0:1], off offset:1472 glc          // 0000008FD638: DC5245C0 967C0000
	global_load_b32 v151, v[0:1], off offset:1984 glc          // 0000008FD640: DC5247C0 977C0000
	global_load_b32 v152, v[0:1], off offset:2496 glc          // 0000008FD648: DC5249C0 987C0000
	global_load_b32 v153, v[0:1], off offset:3008 glc          // 0000008FD650: DC524BC0 997C0000
	global_load_b32 v154, v[0:1], off offset:3520 glc          // 0000008FD658: DC524DC0 9A7C0000
	global_load_b32 v155, v[0:1], off offset:4032 glc          // 0000008FD660: DC524FC0 9B7C0000
	s_waitcnt vmcnt(62)                                        // 0000008FD668: BF89FBF7
	v_dual_add_f32 v28, 0, v28 :: v_dual_add_f32 v29, 0, v29   // 0000008FD66C: C9083880 1C1C3A80
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008FD674: BF870091
	v_dual_add_f32 v28, v28, v30 :: v_dual_add_f32 v29, v29, v31// 0000008FD678: C9083D1C 1C1C3F1D
	v_dual_add_f32 v28, v28, v32 :: v_dual_add_f32 v29, v29, v33// 0000008FD680: C908411C 1C1C431D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008FD688: BF870121
	v_dual_add_f32 v28, v28, v34 :: v_dual_add_f32 v29, v29, v35// 0000008FD68C: C908451C 1C1C471D
	v_dual_add_f32 v44, 0, v44 :: v_dual_add_f32 v45, 0, v45   // 0000008FD694: C9085880 2C2C5A80
	v_dual_add_f32 v28, v28, v36 :: v_dual_add_f32 v29, v29, v37// 0000008FD69C: C908491C 1C1C4B1D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008FD6A4: BF870112
	v_dual_add_f32 v30, v44, v46 :: v_dual_add_f32 v31, v45, v47// 0000008FD6A8: C9085D2C 1E1E5F2D
	v_dual_add_f32 v28, v28, v38 :: v_dual_add_f32 v29, v29, v39// 0000008FD6B0: C9084D1C 1C1C4F1D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008FD6B8: BF870112
	v_dual_add_f32 v30, v30, v48 :: v_dual_add_f32 v31, v31, v49// 0000008FD6BC: C908611E 1E1E631F
	v_dual_add_f32 v28, v28, v40 :: v_dual_add_f32 v29, v29, v41// 0000008FD6C4: C908511C 1C1C531D
	v_dual_add_f32 v60, 0, v60 :: v_dual_add_f32 v61, 0, v61   // 0000008FD6CC: C9087880 3C3C7A80
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008FD6D4: BF870193
	v_dual_add_f32 v30, v30, v50 :: v_dual_add_f32 v31, v31, v51// 0000008FD6D8: C908651E 1E1E671F
	v_dual_add_f32 v28, v28, v42 :: v_dual_add_f32 v29, v29, v43// 0000008FD6E0: C908551C 1C1C571D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008FD6E8: BF870193
	v_dual_add_f32 v44, v60, v62 :: v_dual_add_f32 v45, v61, v63// 0000008FD6EC: C9087D3C 2C2C7F3D
	v_dual_add_f32 v30, v30, v52 :: v_dual_add_f32 v31, v31, v53// 0000008FD6F4: C908691E 1E1E6B1F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008FD6FC: BF870112
	v_dual_add_f32 v32, v44, v64 :: v_dual_add_f32 v33, v45, v65// 0000008FD700: C908812C 2020832D
	v_dual_add_f32 v30, v30, v54 :: v_dual_add_f32 v31, v31, v55// 0000008FD708: C9086D1E 1E1E6F1F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008FD710: BF8701A2
	v_dual_add_f32 v32, v32, v66 :: v_dual_add_f32 v33, v33, v67// 0000008FD714: C9088520 20208721
	v_dual_add_f32 v76, 0, v76 :: v_dual_add_f32 v77, 0, v77   // 0000008FD71C: C9089880 4C4C9A80
	v_dual_add_f32 v30, v30, v56 :: v_dual_add_f32 v31, v31, v57// 0000008FD724: C908711E 1E1E731F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008FD72C: BF870193
	v_dual_add_f32 v32, v32, v68 :: v_dual_add_f32 v33, v33, v69// 0000008FD730: C9088920 20208B21
	v_dual_add_f32 v46, v76, v78 :: v_dual_add_f32 v47, v77, v79// 0000008FD738: C9089D4C 2E2E9F4D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008FD740: BF870193
	v_dual_add_f32 v30, v30, v58 :: v_dual_add_f32 v31, v31, v59// 0000008FD744: C908751E 1E1E771F
	v_dual_add_f32 v32, v32, v70 :: v_dual_add_f32 v33, v33, v71// 0000008FD74C: C9088D20 20208F21
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008FD754: BF8701A3
	v_dual_add_f32 v44, v46, v80 :: v_dual_add_f32 v45, v47, v81// 0000008FD758: C908A12E 2C2CA32F
	v_dual_add_f32 v92, 0, v92 :: v_dual_add_f32 v93, 0, v93   // 0000008FD760: C908B880 5C5CBA80
	v_dual_add_f32 v32, v32, v72 :: v_dual_add_f32 v33, v33, v73// 0000008FD768: C9089120 20209321
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008FD770: BF8701A3
	v_dual_add_f32 v34, v44, v82 :: v_dual_add_f32 v35, v45, v83// 0000008FD774: C908A52C 2222A72D
	s_waitcnt vmcnt(60)                                        // 0000008FD77C: BF89F3F7
	v_dual_add_f32 v60, v92, v94 :: v_dual_add_f32 v61, v93, v95// 0000008FD780: C908BD5C 3C3CBF5D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008FD788: BF870193
	v_dual_add_f32 v32, v32, v74 :: v_dual_add_f32 v33, v33, v75// 0000008FD78C: C9089520 20209721
	v_dual_add_f32 v34, v34, v84 :: v_dual_add_f32 v35, v35, v85// 0000008FD794: C908A922 2222AB23
	s_waitcnt vmcnt(58)                                        // 0000008FD79C: BF89EBF7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008FD7A0: BF870113
	v_dual_add_f32 v46, v60, v96 :: v_dual_add_f32 v47, v61, v97// 0000008FD7A4: C908C13C 2E2EC33D
	v_dual_add_f32 v34, v34, v86 :: v_dual_add_f32 v35, v35, v87// 0000008FD7AC: C908AD22 2222AF23
	s_waitcnt vmcnt(46)                                        // 0000008FD7B4: BF89BBF7
	v_dual_add_f32 v108, 0, v108 :: v_dual_add_f32 v109, 0, v109// 0000008FD7B8: C908D880 6C6CDA80
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008FD7C0: BF870193
	v_dual_add_f32 v44, v46, v98 :: v_dual_add_f32 v45, v47, v99// 0000008FD7C4: C908C52E 2C2CC72F
	v_dual_add_f32 v34, v34, v88 :: v_dual_add_f32 v35, v35, v89// 0000008FD7CC: C908B122 2222B323
	s_waitcnt vmcnt(44)                                        // 0000008FD7D4: BF89B3F7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008FD7D8: BF870193
	v_dual_add_f32 v62, v108, v110 :: v_dual_add_f32 v63, v109, v111// 0000008FD7DC: C908DD6C 3E3EDF6D
	v_dual_add_f32 v36, v44, v100 :: v_dual_add_f32 v37, v45, v101// 0000008FD7E4: C908C92C 2424CB2D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008FD7EC: BF8701A3
	v_dual_add_f32 v34, v34, v90 :: v_dual_add_f32 v35, v35, v91// 0000008FD7F0: C908B522 2222B723
	s_waitcnt vmcnt(42)                                        // 0000008FD7F8: BF89ABF7
	v_dual_add_f32 v48, v62, v112 :: v_dual_add_f32 v49, v63, v113// 0000008FD7FC: C908E13E 3030E33F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000008FD804: BF8701B3
	v_dual_add_f32 v36, v36, v102 :: v_dual_add_f32 v37, v37, v103// 0000008FD808: C908CD24 2424CF25
	s_waitcnt vmcnt(30)                                        // 0000008FD810: BF897BF7
	v_dual_add_f32 v124, 0, v124 :: v_dual_add_f32 v125, 0, v125// 0000008FD814: C908F880 7C7CFA80
	v_dual_add_f32 v46, v48, v114 :: v_dual_add_f32 v47, v49, v115// 0000008FD81C: C908E530 2E2EE731
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008FD824: BF8701A3
	v_dual_add_f32 v36, v36, v104 :: v_dual_add_f32 v37, v37, v105// 0000008FD828: C908D124 2424D325
	s_waitcnt vmcnt(28)                                        // 0000008FD830: BF8973F7
	v_dual_add_f32 v76, v124, v126 :: v_dual_add_f32 v77, v125, v127// 0000008FD834: C908FD7C 4C4CFF7D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008FD83C: BF870193
	v_dual_add_f32 v44, v46, v116 :: v_dual_add_f32 v45, v47, v117// 0000008FD840: C908E92E 2C2CEB2F
	v_dual_add_f32 v36, v36, v106 :: v_dual_add_f32 v37, v37, v107// 0000008FD848: C908D524 2424D725
	s_waitcnt vmcnt(26)                                        // 0000008FD850: BF896BF7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008FD854: BF870193
	v_dual_add_f32 v60, v76, v128 :: v_dual_add_f32 v61, v77, v129// 0000008FD858: C909014C 3C3D034D
	v_dual_add_f32 v38, v44, v118 :: v_dual_add_f32 v39, v45, v119// 0000008FD860: C908ED2C 2626EF2D
	s_waitcnt vmcnt(14)                                        // 0000008FD868: BF893BF7
	v_dual_add_f32 v140, 0, v140 :: v_dual_add_f32 v141, 0, v141// 0000008FD86C: C9091880 8C8D1A80
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008FD874: BF870193
	v_dual_add_f32 v48, v60, v130 :: v_dual_add_f32 v49, v61, v131// 0000008FD878: C909053C 3031073D
	v_dual_add_f32 v38, v38, v120 :: v_dual_add_f32 v39, v39, v121// 0000008FD880: C908F126 2626F327
	s_waitcnt vmcnt(12)                                        // 0000008FD888: BF8933F7
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008FD88C: BF870193
	v_dual_add_f32 v78, v140, v142 :: v_dual_add_f32 v79, v141, v143// 0000008FD890: C9091D8C 4E4F1F8D
	v_dual_add_f32 v46, v48, v132 :: v_dual_add_f32 v47, v49, v133// 0000008FD898: C9090930 2E2F0B31
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008FD8A0: BF8701A3
	v_dual_add_f32 v38, v38, v122 :: v_dual_add_f32 v39, v39, v123// 0000008FD8A4: C908F526 2626F727
	s_waitcnt vmcnt(10)                                        // 0000008FD8AC: BF892BF7
	v_dual_add_f32 v62, v78, v144 :: v_dual_add_f32 v63, v79, v145// 0000008FD8B0: C909214E 3E3F234F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008FD8B8: BF870123
	v_dual_add_f32 v44, v46, v134 :: v_dual_add_f32 v45, v47, v135// 0000008FD8BC: C9090D2E 2C2D0F2F
	s_waitcnt vmcnt(8)                                         // 0000008FD8C4: BF8923F7
	v_dual_add_f32 v50, v62, v146 :: v_dual_add_f32 v51, v63, v147// 0000008FD8C8: C909253E 3233273F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008FD8D0: BF870122
	v_dual_add_f32 v40, v44, v136 :: v_dual_add_f32 v41, v45, v137// 0000008FD8D4: C909112C 2829132D
	s_waitcnt vmcnt(6)                                         // 0000008FD8DC: BF891BF7
	v_dual_add_f32 v48, v50, v148 :: v_dual_add_f32 v49, v51, v149// 0000008FD8E0: C9092932 30312B33
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008FD8E8: BF870122
	v_dual_add_f32 v40, v40, v138 :: v_dual_add_f32 v41, v41, v139// 0000008FD8EC: C9091528 28291729
	s_waitcnt vmcnt(4)                                         // 0000008FD8F4: BF8913F7
	v_dual_add_f32 v46, v48, v150 :: v_dual_add_f32 v47, v49, v151// 0000008FD8F8: C9092D30 2E2F2F31
	s_waitcnt vmcnt(2)                                         // 0000008FD900: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008FD904: BF8700A1
	v_dual_add_f32 v44, v46, v152 :: v_dual_add_f32 v45, v47, v153// 0000008FD908: C909312E 2C2D332F
	s_waitcnt vmcnt(0)                                         // 0000008FD910: BF8903F7
	v_dual_add_f32 v42, v44, v154 :: v_dual_add_f32 v43, v45, v155// 0000008FD914: C909352C 2A2B372D
	v_add_f32_e32 v44, v28, v30                                // 0000008FD91C: 06583D1C
	v_sub_f32_e32 v28, v28, v30                                // 0000008FD920: 08383D1C
	v_add_f32_e32 v30, v32, v34                                // 0000008FD924: 063C4520
	v_sub_f32_e32 v32, v32, v34                                // 0000008FD928: 08404520
	v_add_f32_e32 v34, v36, v38                                // 0000008FD92C: 06444D24
	v_sub_f32_e32 v36, v36, v38                                // 0000008FD930: 08484D24
	v_add_f32_e32 v38, v40, v42                                // 0000008FD934: 064C5528
	v_sub_f32_e32 v40, v40, v42                                // 0000008FD938: 08505528
	v_add_f32_e32 v42, v29, v31                                // 0000008FD93C: 06543F1D
	v_sub_f32_e32 v29, v29, v31                                // 0000008FD940: 083A3F1D
	v_add_f32_e32 v31, v33, v35                                // 0000008FD944: 063E4721
	v_sub_f32_e32 v33, v33, v35                                // 0000008FD948: 08424721
	v_add_f32_e32 v35, v37, v39                                // 0000008FD94C: 06464F25
	v_sub_f32_e32 v37, v37, v39                                // 0000008FD950: 084A4F25
	v_add_f32_e32 v39, v41, v43                                // 0000008FD954: 064E5729
	v_sub_f32_e32 v41, v41, v43                                // 0000008FD958: 08525729
	v_add_f32_e32 v43, v44, v30                                // 0000008FD95C: 06563D2C
	v_sub_f32_e32 v30, v44, v30                                // 0000008FD960: 083C3D2C
	v_add_f32_e32 v44, v28, v32                                // 0000008FD964: 0658411C
	v_sub_f32_e32 v28, v28, v32                                // 0000008FD968: 0838411C
	v_add_f32_e32 v32, v34, v38                                // 0000008FD96C: 06404D22
	v_sub_f32_e32 v34, v34, v38                                // 0000008FD970: 08444D22
	v_add_f32_e32 v38, v36, v40                                // 0000008FD974: 064C5124
	v_sub_f32_e32 v36, v36, v40                                // 0000008FD978: 08485124
	v_add_f32_e32 v40, v42, v31                                // 0000008FD97C: 06503F2A
	v_dual_sub_f32 v31, v42, v31 :: v_dual_add_f32 v42, v29, v33// 0000008FD980: C9483F2A 1F2A431D
	v_sub_f32_e32 v29, v29, v33                                // 0000008FD988: 083A431D
	v_add_f32_e32 v33, v35, v39                                // 0000008FD98C: 06424F23
	v_sub_f32_e32 v35, v35, v39                                // 0000008FD990: 08464F23
	v_add_f32_e32 v39, v37, v41                                // 0000008FD994: 064E5325
	v_sub_f32_e32 v37, v37, v41                                // 0000008FD998: 084A5325
	v_add_f32_e32 v41, v43, v32                                // 0000008FD99C: 0652412B
	v_dual_sub_f32 v32, v43, v32 :: v_dual_add_f32 v43, v44, v38// 0000008FD9A0: C948412B 202A4D2C
	v_sub_f32_e32 v38, v44, v38                                // 0000008FD9A8: 084C4D2C
	v_add_f32_e32 v44, v30, v34                                // 0000008FD9AC: 0658451E
	v_sub_f32_e32 v30, v30, v34                                // 0000008FD9B0: 083C451E
	s_delay_alu instid0(VALU_DEP_4)                            // 0000008FD9B4: BF870004
	v_mov_b32_dpp v45, v43 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000008FD9B8: 7E5A02FA FF01612B
	v_cndmask_b32_e64 v43, -v43, v43, s1                       // 0000008FD9C0: D501002B 2006572B
	v_add_f32_e32 v34, v28, v36                                // 0000008FD9C8: 0644491C
	v_sub_f32_e32 v28, v28, v36                                // 0000008FD9CC: 0838491C
	v_add_f32_e32 v36, v40, v33                                // 0000008FD9D0: 06484328
	v_dual_sub_f32 v33, v40, v33 :: v_dual_add_f32 v40, v42, v39// 0000008FD9D4: C9484328 21284F2A
	v_sub_f32_e32 v39, v42, v39                                // 0000008FD9DC: 084E4F2A
	v_mov_b32_dpp v48, v32 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000008FD9E0: 7E6002FA FF016120
	v_cndmask_b32_e64 v32, -v32, v32, s1                       // 0000008FD9E8: D5010020 20064120
	s_delay_alu instid0(VALU_DEP_4)                            // 0000008FD9F0: BF870004
	v_mov_b32_dpp v56, v33 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000008FD9F4: 7E7002FA FF016121
	v_cndmask_b32_e64 v33, -v33, v33, s1                       // 0000008FD9FC: D5010021 20064321
	v_add_f32_e32 v42, v31, v35                                // 0000008FDA04: 0654471F
	v_sub_f32_e32 v31, v31, v35                                // 0000008FDA08: 083E471F
	v_add_f32_e32 v35, v29, v37                                // 0000008FDA0C: 06464B1D
	v_sub_f32_e32 v29, v29, v37                                // 0000008FDA10: 083A4B1D
	v_mov_b32_dpp v37, v41 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000008FDA14: 7E4A02FA FF016129
	v_cndmask_b32_e64 v41, -v41, v41, s1                       // 0000008FDA1C: D5010029 20065329
	v_mov_b32_dpp v58, v31 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000008FDA24: 7E7402FA FF01611F
	v_cndmask_b32_e64 v31, -v31, v31, s1                       // 0000008FDA2C: D501001F 20063F1F
	v_mov_b32_dpp v59, v29 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000008FDA34: 7E7602FA FF01611D
	v_cndmask_b32_e64 v29, -v29, v29, s1                       // 0000008FDA3C: D501001D 20063B1D
	v_mov_b32_dpp v57, v39 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000008FDA44: 7E7202FA FF016127
	v_cndmask_b32_e64 v39, -v39, v39, s1                       // 0000008FDA4C: D5010027 20064F27
	v_add_f32_e32 v37, v41, v37                                // 0000008FDA54: 064A4B29
	v_mov_b32_dpp v50, v30 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000008FDA58: 7E6402FA FF01611E
	v_cndmask_b32_e64 v30, -v30, v30, s1                       // 0000008FDA60: D501001E 20063D1E
	v_add_f32_e32 v41, v43, v45                                // 0000008FDA68: 06525B2B
	v_mov_b32_dpp v47, v34 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000008FDA6C: 7E5E02FA FF016122
	v_cndmask_b32_e64 v34, -v34, v34, s1                       // 0000008FDA74: D5010022 20064522
	v_dual_add_f32 v32, v32, v48 :: v_dual_add_f32 v29, v29, v59// 0000008FDA7C: C9086120 201C771D
	v_add_f32_e32 v31, v31, v58                                // 0000008FDA84: 063E751F
	v_add_f32_e32 v33, v33, v56                                // 0000008FDA88: 06427121
	v_mov_b32_dpp v49, v38 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000008FDA8C: 7E6202FA FF016126
	v_cndmask_b32_e64 v38, -v38, v38, s1                       // 0000008FDA94: D5010026 20064D26
	v_mov_b32_dpp v52, v36 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000008FDA9C: 7E6802FA FF016124
	v_cndmask_b32_e64 v36, -v36, v36, s1                       // 0000008FDAA4: D5010024 20064924
	v_mov_b32_dpp v55, v35 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000008FDAAC: 7E6E02FA FF016123
	v_cndmask_b32_e64 v35, -v35, v35, s1                       // 0000008FDAB4: D5010023 20064723
	v_dual_add_f32 v34, v34, v47 :: v_dual_add_f32 v39, v39, v57// 0000008FDABC: C9085F22 22267327
	v_mov_b32_dpp v56, v33 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000008FDAC4: 7E7002FA FF016221
	v_mov_b32_dpp v57, v31 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000008FDACC: 7E7202FA FF01621F
	v_cndmask_b32_e64 v33, -v33, v33, s3                       // 0000008FDAD4: D5010021 200E4321
	v_cndmask_b32_e64 v31, -v31, v31, s3                       // 0000008FDADC: D501001F 200E3F1F
	v_add_f32_e32 v30, v30, v50                                // 0000008FDAE4: 063C651E
	v_mov_b32_dpp v59, v29 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000008FDAE8: 7E7602FA FF01621D
	v_cndmask_b32_e64 v29, -v29, v29, s3                       // 0000008FDAF0: D501001D 200E3B1D
	v_dual_add_f32 v38, v38, v49 :: v_dual_add_f32 v33, v33, v56// 0000008FDAF8: C9086326 26207121
	v_dual_add_f32 v36, v36, v52 :: v_dual_add_f32 v35, v35, v55// 0000008FDB00: C9086924 24226F23
	v_mov_b32_dpp v51, v28 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000008FDB08: 7E6602FA FF01611C
	v_cndmask_b32_e64 v28, -v28, v28, s1                       // 0000008FDB10: D501001C 2006391C
	v_add_f32_e32 v31, v31, v57                                // 0000008FDB18: 063E731F
	v_mov_b32_dpp v50, v30 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000008FDB1C: 7E6402FA FF01621E
	v_cndmask_b32_e64 v30, -v30, v30, s3                       // 0000008FDB24: D501001E 200E3D1E
	v_add_f32_e32 v29, v29, v59                                // 0000008FDB2C: 063A771D
	v_mov_b32_dpp v48, v32 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000008FDB30: 7E6002FA FF016220
	v_mov_b32_dpp v49, v38 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000008FDB38: 7E6202FA FF016226
	v_cndmask_b32_e64 v32, -v32, v32, s3                       // 0000008FDB40: D5010020 200E4120
	v_cndmask_b32_e64 v38, -v38, v38, s3                       // 0000008FDB48: D5010026 200E4D26
	v_mov_b32_dpp v58, v39 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000008FDB50: 7E7402FA FF016227
	v_cndmask_b32_e64 v39, -v39, v39, s3                       // 0000008FDB58: D5010027 200E4F27
	v_add_f32_e32 v28, v28, v51                                // 0000008FDB60: 0638671C
	v_mov_b32_dpp v59, v29 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000008FDB64: 7E7602FA FF01641D
	v_cndmask_b32_e64 v29, -v29, v29, s4                       // 0000008FDB6C: D501001D 20123B1D
	v_add_f32_e32 v30, v30, v50                                // 0000008FDB74: 063C651E
	v_mov_b32_dpp v50, v33 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000008FDB78: 7E6402FA FF016421
	v_cndmask_b32_e64 v33, -v33, v33, s4                       // 0000008FDB80: D5010021 20124321
	v_add_f32_e32 v32, v32, v48                                // 0000008FDB88: 06406120
	v_dual_add_f32 v38, v38, v49 :: v_dual_add_f32 v39, v39, v58// 0000008FDB8C: C9086326 26267527
	v_mov_b32_dpp v51, v28 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000008FDB94: 7E6602FA FF01621C
	v_cndmask_b32_e64 v28, -v28, v28, s3                       // 0000008FDB9C: D501001C 200E391C
	v_add_f32_e32 v33, v33, v50                                // 0000008FDBA4: 06426521
	v_add_f32_e32 v29, v29, v59                                // 0000008FDBA8: 063A771D
	v_mov_b32_dpp v49, v30 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000008FDBAC: 7E6202FA FF01641E
	v_cndmask_b32_e64 v30, -v30, v30, s4                       // 0000008FDBB4: D501001E 20123D1E
	v_mov_b32_dpp v48, v32 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000008FDBBC: 7E6002FA FF016420
	v_cndmask_b32_e64 v32, -v32, v32, s4                       // 0000008FDBC4: D5010020 20124120
	v_mov_b32_dpp v56, v38 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000008FDBCC: 7E7002FA FF016426
	v_cndmask_b32_e64 v38, -v38, v38, s4                       // 0000008FDBD4: D5010026 20124D26
	v_mov_b32_dpp v58, v39 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000008FDBDC: 7E7402FA FF016427
	v_cndmask_b32_e64 v39, -v39, v39, s4                       // 0000008FDBE4: D5010027 20124F27
	v_add_f32_e32 v28, v28, v51                                // 0000008FDBEC: 0638671C
	v_mov_b32_dpp v50, v33 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000008FDBF0: 7E6402FA FF016821
	v_cndmask_b32_e64 v33, -v33, v33, s5                       // 0000008FDBF8: D5010021 20164321
	v_add_f32_e32 v30, v30, v49                                // 0000008FDC00: 063C631E
	v_mov_b32_dpp v54, v42 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000008FDC04: 7E6C02FA FF01612A
	v_cndmask_b32_e64 v42, -v42, v42, s1                       // 0000008FDC0C: D501002A 2006552A
	v_mov_b32_dpp v51, v31 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000008FDC14: 7E6602FA FF01641F
	v_cndmask_b32_e64 v31, -v31, v31, s4                       // 0000008FDC1C: D501001F 20123F1F
	v_add_f32_e32 v32, v32, v48                                // 0000008FDC24: 06406120
	v_dual_add_f32 v38, v38, v56 :: v_dual_add_f32 v39, v39, v58// 0000008FDC28: C9087126 26267527
	v_mov_b32_dpp v48, v28 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000008FDC30: 7E6002FA FF01641C
	v_cndmask_b32_e64 v28, -v28, v28, s4                       // 0000008FDC38: D501001C 2012391C
	v_add_f32_e32 v33, v33, v50                                // 0000008FDC40: 06426521
	v_mov_b32_dpp v57, v30 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000008FDC44: 7E7202FA FF01681E
	v_cndmask_b32_e64 v30, -v30, v30, s5                       // 0000008FDC4C: D501001E 20163D1E
	v_dual_add_f32 v42, v42, v54 :: v_dual_add_f32 v31, v31, v51// 0000008FDC54: C9086D2A 2A1E671F
	v_add_f32_e32 v28, v28, v48                                // 0000008FDC5C: 0638611C
	v_mov_b32_dpp v48, v38 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000008FDC60: 7E6002FA FF016826
	v_cndmask_b32_e64 v38, -v38, v38, s5                       // 0000008FDC68: D5010026 20164D26
	v_mov_b32_dpp v60, v39 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000008FDC70: 7E7802FA FF016827
	v_cndmask_b32_e64 v39, -v39, v39, s5                       // 0000008FDC78: D5010027 20164F27
	v_add_f32_e32 v30, v30, v57                                // 0000008FDC80: 063C731E
	v_mov_b32_dpp v57, v31 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000008FDC84: 7E7202FA FF01681F
	v_add_f32_e32 v38, v38, v48                                // 0000008FDC8C: 064C6126
	v_cndmask_b32_e64 v31, -v31, v31, s5                       // 0000008FDC90: D501001F 20163F1F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000008FDC98: BF870234
	v_dual_add_f32 v39, v39, v60 :: v_dual_mul_f32 v30, 0x3db504f3, v30// 0000008FDC9C: C9067927 271E3CFF 3DB504F3
	v_mov_b32_dpp v45, v41 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000008FDCA8: 7E5A02FA FF016229
	v_cndmask_b32_e64 v41, -v41, v41, s3                       // 0000008FDCB0: D5010029 200E5329
	v_dual_add_f32 v31, v31, v57 :: v_dual_mul_f32 v38, 0x3db504f3, v38// 0000008FDCB8: C906731F 1F264CFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000008FDCC4: BF870234
	v_mul_f32_e32 v30, v30, v8                                 // 0000008FDCC8: 103C111E
	v_mov_b32_dpp v63, v29 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000008FDCCC: 7E7E02FA FF01681D
	v_cndmask_b32_e64 v29, -v29, v29, s5                       // 0000008FDCD4: D501001D 20163B1D
	v_dual_mul_f32 v31, 0x3db504f3, v31 :: v_dual_mul_f32 v38, v38, v12// 0000008FDCDC: C8C63EFF 1F261926 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008FDCE8: BF8701A4
	v_dual_mul_f32 v48, 0xbfb8aa3b, v30 :: v_dual_add_f32 v41, v41, v45// 0000008FDCEC: C8C83CFF 30285B29 BFB8AA3B
	v_mov_b32_dpp v46, v44 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000008FDCF8: 7E5C02FA FF01612C
	v_mul_f32_e32 v31, v31, v10                                // 0000008FDD00: 103E151F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000008FDD04: BF870214
	v_mul_f32_e32 v51, 0xbfb8aa3b, v38                         // 0000008FDD08: 10664CFF BFB8AA3B
	v_exp_f32_e32 v48, v48                                     // 0000008FDD10: 7E604B30
	v_mov_b32_dpp v49, v32 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000008FDD14: 7E6202FA FF016820
	v_cndmask_b32_e64 v32, -v32, v32, s5                       // 0000008FDD1C: D5010020 20164120
	v_cndmask_b32_e64 v44, -v44, v44, s1                       // 0000008FDD24: D501002C 2006592C
	v_exp_f32_e32 v51, v51                                     // 0000008FDD2C: 7E664B33
	v_add_f32_e32 v29, v29, v63                                // 0000008FDD30: 063A7F1D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008FDD34: BF870193
	v_dual_mul_f32 v39, 0x3db504f3, v39 :: v_dual_add_f32 v32, v32, v49// 0000008FDD38: C8C84EFF 27206320 3DB504F3
	v_add_f32_e32 v43, v44, v46                                // 0000008FDD44: 06565D2C
	v_mov_b32_dpp v53, v40 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000008FDD48: 7E6A02FA FF016128
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_4)   // 0000008FDD50: BF870206
	v_dual_add_f32 v48, 1.0, v48 :: v_dual_mul_f32 v29, 0x3db504f3, v29// 0000008FDD54: C90660F2 301C3AFF 3DB504F3
	v_cndmask_b32_e64 v40, -v40, v40, s1                       // 0000008FDD60: D5010028 20065128
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000008FDD68: BF870294
	v_mov_b32_dpp v46, v43 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000008FDD6C: 7E5C02FA FF01622B
	v_add_f32_e32 v51, 1.0, v51                                // 0000008FDD74: 066666F2
	s_delay_alu instid0(VALU_DEP_4)                            // 0000008FDD78: BF870004
	v_div_scale_f32 v58, null, v48, v48, v30                   // 0000008FDD7C: D6FC7C3A 047A6130
	v_cndmask_b32_e64 v43, -v43, v43, s3                       // 0000008FDD84: D501002B 200E572B
	v_mul_f32_e32 v29, v29, v15                                // 0000008FDD8C: 103A1F1D
	v_mul_f32_e32 v33, 0x3db504f3, v33                         // 0000008FDD90: 104242FF 3DB504F3
	v_div_scale_f32 v65, null, v51, v51, v38                   // 0000008FDD98: D6FC7C41 049A6733
	v_rcp_f32_e32 v61, v58                                     // 0000008FDDA0: 7E7A553A
	v_div_scale_f32 v60, s7, v38, v51, v38                     // 0000008FDDA4: D6FC073C 049A6726
	v_mov_b32_dpp v44, v37 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000008FDDAC: 7E5802FA FF016225
	v_cndmask_b32_e64 v37, -v37, v37, s3                       // 0000008FDDB4: D5010025 200E4B25
	v_rcp_f32_e32 v70, v65                                     // 0000008FDDBC: 7E8C5541
	v_mul_f32_e32 v33, v33, v9                                 // 0000008FDDC0: 10421321
	v_mov_b32_dpp v47, v34 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000008FDDC4: 7E5E02FA FF016222
	v_cndmask_b32_e64 v34, -v34, v34, s3                       // 0000008FDDCC: D5010022 200E4522
	v_mov_b32_dpp v54, v42 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000008FDDD4: 7E6C02FA FF01622A
	v_cndmask_b32_e64 v42, -v42, v42, s3                       // 0000008FDDDC: D501002A 200E552A
	v_fma_f32 v67, -v58, v61, 1.0                              // 0000008FDDE4: D6130043 23CA7B3A
	v_mov_b32_dpp v52, v36 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000008FDDEC: 7E6802FA FF016224
	v_cndmask_b32_e64 v36, -v36, v36, s3                       // 0000008FDDF4: D5010024 200E4924
	v_mov_b32_dpp v55, v35 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000008FDDFC: 7E6E02FA FF016223
	v_cndmask_b32_e64 v35, -v35, v35, s3                       // 0000008FDE04: D5010023 200E4723
	v_fmac_f32_e32 v61, v67, v61                               // 0000008FDE0C: 567A7B43
	v_fma_f32 v67, -v65, v70, 1.0                              // 0000008FDE10: D6130043 23CA8D41
	v_mov_b32_dpp v49, v28 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000008FDE18: 7E6202FA FF01681C
	v_cndmask_b32_e64 v28, -v28, v28, s5                       // 0000008FDE20: D501001C 2016391C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008FDE28: BF870113
	v_dual_add_f32 v37, v37, v44 :: v_dual_fmac_f32 v70, v67, v70// 0000008FDE2C: C9005925 25468D43
	v_add_f32_e32 v28, v28, v49                                // 0000008FDE34: 0638631C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008FDE38: BF870092
	v_mul_f32_e32 v67, v60, v70                                // 0000008FDE3C: 10868D3C
	v_fma_f32 v63, -v65, v67, v60                              // 0000008FDE40: D613003F 24F28741
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008FDE48: BF870091
	v_dual_mul_f32 v28, 0x3db504f3, v28 :: v_dual_fmac_f32 v67, v63, v70// 0000008FDE4C: C8C038FF 1C428D3F 3DB504F3
	v_mul_f32_e32 v28, v28, v13                                // 0000008FDE58: 10381B1C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008FDE5C: BF870091
	v_mul_f32_e32 v56, 0xbfb8aa3b, v28                         // 0000008FDE60: 107038FF BFB8AA3B
	v_exp_f32_e32 v56, v56                                     // 0000008FDE68: 7E704B38
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008FDE6C: BF870095
	v_add_f32_e32 v56, 1.0, v56                                // 0000008FDE70: 067070F2
	v_div_scale_f32 v66, null, v56, v56, v28                   // 0000008FDE74: D6FC7C42 04727138
	v_div_scale_f32 v74, s8, v28, v56, v28                     // 0000008FDE7C: D6FC084A 0472711C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008FDE84: BF8700A2
	v_rcp_f32_e32 v71, v66                                     // 0000008FDE88: 7E8E5542
	v_mul_f32_e32 v32, 0x3db504f3, v32                         // 0000008FDE8C: 104040FF 3DB504F3
	v_mul_f32_e32 v32, v32, v7                                 // 0000008FDE94: 10400F20
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008FDE98: BF870091
	v_dual_add_f32 v40, v40, v53 :: v_dual_mul_f32 v49, 0xbfb8aa3b, v32// 0000008FDE9C: C9066B28 283040FF BFB8AA3B
	v_mov_b32_dpp v53, v40 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000008FDEA8: 7E6A02FA FF016228
	v_cndmask_b32_e64 v40, -v40, v40, s3                       // 0000008FDEB0: D5010028 200E5128
	v_add_f32_e32 v35, v35, v55                                // 0000008FDEB8: 06466F23
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008FDEBC: BF870114
	v_exp_f32_e32 v49, v49                                     // 0000008FDEC0: 7E624B31
	v_add_f32_e32 v40, v40, v53                                // 0000008FDEC4: 06506B28
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008FDEC8: BF870095
	v_add_f32_e32 v49, 1.0, v49                                // 0000008FDECC: 066262F2
	v_div_scale_f32 v59, null, v49, v49, v32                   // 0000008FDED0: D6FC7C3B 04826331
	v_div_scale_f32 v69, s6, v32, v49, v32                     // 0000008FDED8: D6FC0645 04826320
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000008FDEE0: BF870292
	v_rcp_f32_e32 v62, v59                                     // 0000008FDEE4: 7E7C553B
	v_fma_f32 v68, -v59, v62, 1.0                              // 0000008FDEE8: D6130044 23CA7D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008FDEF0: BF870121
	v_fmac_f32_e32 v62, v68, v62                               // 0000008FDEF4: 567C7D44
	v_fma_f32 v68, -v66, v71, 1.0                              // 0000008FDEF8: D6130044 23CA8F42
	v_mul_f32_e32 v57, v69, v62                                // 0000008FDF00: 10727D45
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008FDF04: BF870112
	v_fmac_f32_e32 v71, v68, v71                               // 0000008FDF08: 568E8F44
	v_fma_f32 v73, -v59, v57, v69                              // 0000008FDF0C: D6130049 2516733B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008FDF14: BF870121
	v_fmac_f32_e32 v57, v73, v62                               // 0000008FDF18: 56727D49
	v_div_scale_f32 v64, vcc_lo, v30, v48, v30                 // 0000008FDF1C: D6FC6A40 047A611E
	v_fma_f32 v59, -v59, v57, v69                              // 0000008FDF24: D613003B 2516733B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008FDF2C: BF870092
	v_mul_f32_e32 v50, v64, v61                                // 0000008FDF30: 10647B40
	v_fma_f32 v72, -v58, v50, v64                              // 0000008FDF34: D6130048 2502653A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008FDF3C: BF870091
	v_fmac_f32_e32 v50, v72, v61                               // 0000008FDF40: 56647B48
	v_fma_f32 v58, -v58, v50, v64                              // 0000008FDF44: D613003A 2502653A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000008FDF4C: BF870141
	v_div_fmas_f32 v50, v58, v61, v50                          // 0000008FDF50: D6370032 04CA7B3A
	s_mov_b32 vcc_lo, s6                                       // 0000008FDF58: BEEA0006
	v_div_fmas_f32 v57, v59, v62, v57                          // 0000008FDF5C: D6370039 04E67D3B
	s_mov_b32 vcc_lo, s7                                       // 0000008FDF64: BEEA0007
	v_div_fixup_f32 v30, v50, v48, v30                         // 0000008FDF68: D627001E 047A6132
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008FDF70: BF8701A2
	v_div_fixup_f32 v32, v57, v49, v32                         // 0000008FDF74: D6270020 04826339
	v_fma_f32 v49, -v65, v67, v60                              // 0000008FDF7C: D6130031 24F28741
	v_mul_f32_e32 v30, v31, v30                                // 0000008FDF84: 103C3D1F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008FDF88: BF870193
	v_mul_f32_e32 v32, v33, v32                                // 0000008FDF8C: 10404121
	v_div_fmas_f32 v33, v49, v70, v67                          // 0000008FDF90: D6370021 050E8D31
	s_mov_b32 vcc_lo, s8                                       // 0000008FDF98: BEEA0008
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008FDF9C: BF870001
	v_div_fixup_f32 v33, v33, v51, v38                         // 0000008FDFA0: D6270021 049A6721
	v_mul_f32_e32 v38, v39, v14                                // 0000008FDFA8: 104C1D27
	v_add_f32_e32 v39, v43, v46                                // 0000008FDFAC: 064E5D2B
	v_mov_b32_dpp v43, v37 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000008FDFB0: 7E5602FA FF016425
	v_cndmask_b32_e64 v37, -v37, v37, s4                       // 0000008FDFB8: D5010025 20124B25
	v_mov_b32_dpp v46, v35 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000008FDFC0: 7E5C02FA FF016423
	v_cndmask_b32_e64 v35, -v35, v35, s4                       // 0000008FDFC8: D5010023 20124723
	v_mov_b32_dpp v44, v39 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000008FDFD0: 7E5802FA FF016427
	v_cndmask_b32_e64 v39, -v39, v39, s4                       // 0000008FDFD8: D5010027 20124F27
	v_add_f32_e32 v37, v37, v43                                // 0000008FDFE0: 064A5725
	v_mov_b32_dpp v43, v41 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000008FDFE4: 7E5602FA FF016429
	v_cndmask_b32_e64 v41, -v41, v41, s4                       // 0000008FDFEC: D5010029 20125329
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000008FDFF4: BF870214
	v_add_f32_e32 v39, v39, v44                                // 0000008FDFF8: 064E5927
	v_mov_b32_dpp v44, v37 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000008FDFFC: 7E5802FA FF016825
	v_cndmask_b32_e64 v37, -v37, v37, s5                       // 0000008FE004: D5010025 20164B25
	v_mul_f32_e32 v68, v74, v71                                // 0000008FE00C: 10888F4A
	v_add_f32_e32 v41, v41, v43                                // 0000008FE010: 06525729
	v_mov_b32_dpp v43, v39 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000008FE014: 7E5602FA FF016827
	v_cndmask_b32_e64 v39, -v39, v39, s5                       // 0000008FE01C: D5010027 20164F27
	v_add_f32_e32 v37, v37, v44                                // 0000008FE024: 064A5925
	v_fma_f32 v64, -v66, v68, v74                              // 0000008FE028: D6130040 252A8942
	v_mov_b32_dpp v44, v40 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000008FE030: 7E5802FA FF016428
	v_cndmask_b32_e64 v40, -v40, v40, s4                       // 0000008FE038: D5010028 20125128
	v_add_f32_e32 v39, v39, v43                                // 0000008FE040: 064E5727
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008FE044: BF870114
	v_dual_mul_f32 v37, 0x3db504f3, v37 :: v_dual_fmac_f32 v68, v64, v71// 0000008FE048: C8C04AFF 25448F40 3DB504F3
	v_dual_add_f32 v40, v40, v44 :: v_dual_mul_f32 v39, 0x3db504f3, v39// 0000008FE054: C9065928 28264EFF 3DB504F3
	v_add_f32_e32 v36, v36, v52                                // 0000008FE060: 06486924
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008FE064: BF870193
	v_fma_f32 v57, -v66, v68, v74                              // 0000008FE068: D6130039 252A8942
	v_mov_b32_dpp v53, v40 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000008FE070: 7E6A02FA FF016828
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000008FE078: BF870224
	v_mul_f32_e32 v39, v39, v18                                // 0000008FE07C: 104E2527
	v_cndmask_b32_e64 v40, -v40, v40, s5                       // 0000008FE080: D5010028 20165128
	v_div_fmas_f32 v48, v57, v71, v68                          // 0000008FE088: D6370030 05128F39
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008FE090: BF870112
	v_add_f32_e32 v40, v40, v53                                // 0000008FE094: 06506B28
	v_div_fixup_f32 v28, v48, v56, v28                         // 0000008FE098: D627001C 04727130
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008FE0A0: BF870112
	v_mul_f32_e32 v40, 0x3db504f3, v40                         // 0000008FE0A4: 105050FF 3DB504F3
	v_mul_f32_e32 v28, v29, v28                                // 0000008FE0AC: 1038391D
	v_mov_b32_dpp v29, v41 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000008FE0B0: 7E3A02FA FF016829
	v_cndmask_b32_e64 v41, -v41, v41, s5                       // 0000008FE0B8: D5010029 20165329
	v_add_f32_e32 v34, v34, v47                                // 0000008FE0C0: 06445F22
	v_mul_f32_e32 v40, v40, v25                                // 0000008FE0C4: 10503328
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008FE0C8: BF870193
	v_add_f32_e32 v29, v41, v29                                // 0000008FE0CC: 063A3B29
	v_mov_b32_dpp v45, v34 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000008FE0D0: 7E5A02FA FF016422
	v_cndmask_b32_e64 v34, -v34, v34, s4                       // 0000008FE0D8: D5010022 20124522
	v_add_f32_e32 v41, v42, v54                                // 0000008FE0E0: 06526D2A
	v_mov_b32_dpp v42, v36 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000008FE0E4: 7E5402FA FF016424
	v_mul_f32_e32 v29, 0x3db504f3, v29                         // 0000008FE0EC: 103A3AFF 3DB504F3
	v_cndmask_b32_e64 v36, -v36, v36, s4                       // 0000008FE0F4: D5010024 20124924
	v_add_f32_e32 v34, v34, v45                                // 0000008FE0FC: 06445B22
	v_mul_f32_e32 v28, v28, v17                                // 0000008FE100: 1038231C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008FE104: BF870193
	v_add_f32_e32 v36, v36, v42                                // 0000008FE108: 06485524
	v_mov_b32_dpp v43, v34 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000008FE10C: 7E5602FA FF016822
	v_cndmask_b32_e64 v34, -v34, v34, s5                       // 0000008FE114: D5010022 20164522
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008FE11C: BF8700B1
	v_add_f32_e32 v34, v34, v43                                // 0000008FE120: 06445722
	v_mov_b32_dpp v43, v41 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000008FE124: 7E5602FA FF016429
	v_cndmask_b32_e64 v41, -v41, v41, s4                       // 0000008FE12C: D5010029 20125329
	v_dual_mul_f32 v34, 0x3db504f3, v34 :: v_dual_add_f32 v41, v41, v43// 0000008FE134: C8C844FF 22285729 3DB504F3
	v_mul_f32_e32 v43, 0xbfb8aa3b, v39                         // 0000008FE140: 10564EFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008FE148: BF870192
	v_dual_mul_f32 v37, v37, v19 :: v_dual_mul_f32 v34, v34, v20// 0000008FE14C: C8C62725 25222922
	v_mov_b32_dpp v49, v41 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000008FE154: 7E6202FA FF016829
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008FE15C: BF870113
	v_exp_f32_e32 v42, v43                                     // 0000008FE160: 7E544B2B
	v_dual_mul_f32 v45, 0xbfb8aa3b, v37 :: v_dual_mul_f32 v48, 0xbfb8aa3b, v34// 0000008FE164: C8C64AFF 2D3044FF BFB8AA3B
	v_mul_f32_e32 v29, v29, v21                                // 0000008FE170: 103A2B1D
	v_mov_b32_dpp v43, v36 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000008FE174: 7E5602FA FF016824
	v_cndmask_b32_e64 v36, -v36, v36, s5                       // 0000008FE17C: D5010024 20164924
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(TRANS32_DEP_3)// 0000008FE184: BF8703C4
	v_exp_f32_e32 v45, v45                                     // 0000008FE188: 7E5A4B2D
	v_add_f32_e32 v35, v35, v46                                // 0000008FE18C: 06465D23
	v_exp_f32_e32 v48, v48                                     // 0000008FE190: 7E604B30
	v_cndmask_b32_e64 v41, -v41, v41, s5                       // 0000008FE194: D5010029 20165329
	v_dual_add_f32 v42, 1.0, v42 :: v_dual_mul_f32 v47, 0xbfb8aa3b, v29// 0000008FE19C: C90654F2 2A2E3AFF BFB8AA3B
	v_add_f32_e32 v36, v36, v43                                // 0000008FE1A8: 06485724
	v_mov_b32_dpp v57, v35 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000008FE1AC: 7E7202FA FF016823
	v_cndmask_b32_e64 v35, -v35, v35, s5                       // 0000008FE1B4: D5010023 20164723
	s_delay_alu instid0(VALU_DEP_4)                            // 0000008FE1BC: BF870004
	v_div_scale_f32 v46, null, v42, v42, v39                   // 0000008FE1C0: D6FC7C2E 049E552A
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_4)   // 0000008FE1C8: BF870206
	v_dual_add_f32 v45, 1.0, v45 :: v_dual_mul_f32 v36, 0x3db504f3, v36// 0000008FE1CC: C9065AF2 2D2448FF 3DB504F3
	v_exp_f32_e32 v47, v47                                     // 0000008FE1D8: 7E5E4B2F
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008FE1DC: BF870196
	v_add_f32_e32 v43, 1.0, v48                                // 0000008FE1E0: 065660F2
	v_rcp_f32_e32 v50, v46                                     // 0000008FE1E4: 7E64552E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008FE1E8: BF8701A2
	v_div_scale_f32 v44, null, v45, v45, v37                   // 0000008FE1EC: D6FC7C2C 04965B2D
	v_dual_add_f32 v35, v35, v57 :: v_dual_mul_f32 v36, v36, v23// 0000008FE1F4: C9067323 23242F24
	v_div_scale_f32 v54, null, v43, v43, v34                   // 0000008FE1FC: D6FC7C36 048A572B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008FE204: BF870113
	v_rcp_f32_e32 v48, v44                                     // 0000008FE208: 7E60552C
	v_mul_f32_e32 v35, 0x3db504f3, v35                         // 0000008FE20C: 104646FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_3)// 0000008FE214: BF870392
	v_rcp_f32_e32 v55, v54                                     // 0000008FE218: 7E6E5536
	v_fma_f32 v51, -v46, v50, 1.0                              // 0000008FE21C: D6130033 23CA652E
	v_add_f32_e32 v47, 1.0, v47                                // 0000008FE224: 065E5EF2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008FE228: BF870193
	v_mul_f32_e32 v35, v35, v24                                // 0000008FE22C: 10463123
	v_fmac_f32_e32 v50, v51, v50                               // 0000008FE230: 56646533
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(SKIP_3) | instid1(TRANS32_DEP_1)// 0000008FE234: BF8702C6
	v_fma_f32 v56, -v44, v48, 1.0                              // 0000008FE238: D6130038 23CA612C
	v_add_f32_e32 v41, v41, v49                                // 0000008FE240: 06526329
	v_div_scale_f32 v49, null, v47, v47, v29                   // 0000008FE244: D6FC7C31 04765F2F
	v_div_scale_f32 v51, vcc_lo, v39, v42, v39                 // 0000008FE24C: D6FC6A33 049E5527
	v_fma_f32 v60, -v54, v55, 1.0                              // 0000008FE254: D613003C 23CA6F36
	v_fmac_f32_e32 v48, v56, v48                               // 0000008FE25C: 56606138
	v_div_scale_f32 v56, s6, v37, v45, v37                     // 0000008FE260: D6FC0638 04965B25
	v_rcp_f32_e32 v52, v49                                     // 0000008FE268: 7E685531
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008FE26C: BF870091
	v_dual_mul_f32 v59, v51, v50 :: v_dual_mul_f32 v62, v56, v48// 0000008FE270: C8C66533 3B3E6138
	v_fma_f32 v61, -v46, v59, v51                              // 0000008FE278: D613003D 24CE772E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000008FE280: BF870292
	v_fma_f32 v53, -v44, v62, v56                              // 0000008FE284: D6130035 24E27D2C
	v_fma_f32 v58, -v49, v52, 1.0                              // 0000008FE28C: D613003A 23CA6931
	v_mul_f32_e32 v41, 0x3db504f3, v41                         // 0000008FE294: 105252FF 3DB504F3
	v_fmac_f32_e32 v55, v60, v55                               // 0000008FE29C: 566E6F3C
	v_div_scale_f32 v60, s8, v34, v43, v34                     // 0000008FE2A0: D6FC083C 048A5722
	v_fmac_f32_e32 v62, v53, v48                               // 0000008FE2A8: 567C6135
	v_fmac_f32_e32 v52, v58, v52                               // 0000008FE2AC: 5668693A
	v_div_scale_f32 v58, s7, v29, v47, v29                     // 0000008FE2B0: D6FC073A 04765F1D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000008FE2B8: BF870234
	v_dual_mul_f32 v41, v41, v22 :: v_dual_mul_f32 v64, v60, v55// 0000008FE2BC: C8C62D29 29406F3C
	v_fmac_f32_e32 v59, v61, v50                               // 0000008FE2C4: 5676653D
	v_fma_f32 v44, -v44, v62, v56                              // 0000008FE2C8: D613002C 24E27D2C
	v_mul_f32_e32 v63, v58, v52                                // 0000008FE2D0: 107E693A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008FE2D4: BF8701A3
	v_fma_f32 v46, -v46, v59, v51                              // 0000008FE2D8: D613002E 24CE772E
	v_fma_f32 v51, -v54, v64, v60                              // 0000008FE2E0: D6130033 24F28136
	v_fma_f32 v61, -v49, v63, v58                              // 0000008FE2E8: D613003D 24EA7F31
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000008FE2F0: BF870211
	v_dual_fmac_f32 v64, v51, v55 :: v_dual_fmac_f32 v63, v61, v52// 0000008FE2F4: C8006F33 403E693D
	v_div_fmas_f32 v46, v46, v50, v59                          // 0000008FE2FC: D637002E 04EE652E
	s_mov_b32 vcc_lo, s6                                       // 0000008FE304: BEEA0006
	v_div_fmas_f32 v44, v44, v48, v62                          // 0000008FE308: D637002C 04FA612C
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008FE310: BF870003
	v_fma_f32 v49, -v49, v63, v58                              // 0000008FE314: D6130031 24EA7F31
	v_fma_f32 v48, -v54, v64, v60                              // 0000008FE31C: D6130030 24F28136
	s_mov_b32 vcc_lo, s7                                       // 0000008FE324: BEEA0007
	v_div_fixup_f32 v39, v46, v42, v39                         // 0000008FE328: D6270027 049E552E
	v_div_fixup_f32 v37, v44, v45, v37                         // 0000008FE330: D6270025 04965B2C
	v_div_fmas_f32 v49, v49, v52, v63                          // 0000008FE338: D6370031 04FE6931
	s_mov_b32 vcc_lo, s8                                       // 0000008FE340: BEEA0008
	v_mul_f32_e32 v33, v38, v33                                // 0000008FE344: 10424326
	v_div_fmas_f32 v48, v48, v55, v64                          // 0000008FE348: D6370030 05026F30
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008FE350: BF870113
	v_div_fixup_f32 v29, v49, v47, v29                         // 0000008FE354: D627001D 04765F31
	v_div_fixup_f32 v34, v48, v43, v34                         // 0000008FE35C: D6270022 048A5730
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008FE364: BF870121
	v_dual_mul_f32 v29, v40, v29 :: v_dual_mul_f32 v34, v35, v34// 0000008FE368: C8C63B28 1D224523
	v_dual_mul_f32 v35, v36, v37 :: v_dual_mul_f32 v36, v41, v39// 0000008FE370: C8C64B24 23244F29
	v_dual_mul_f32 v29, v29, v27 :: v_dual_mul_f32 v34, v34, v26// 0000008FE378: C8C6371D 1D223522
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000008FE380: BF870231
	v_fma_f32 v37, v35, v6, v29                                // 0000008FE384: D6130025 04760D23
	v_fma_f32 v29, v35, v6, -v29                               // 0000008FE38C: D613001D 84760D23
	v_mul_f32_e32 v31, v33, v16                                // 0000008FE394: 103E2121
	v_fma_f32 v33, v36, v5, v34                                // 0000008FE398: D6130021 048A0B24
	v_fma_f32 v34, v36, v5, -v34                               // 0000008FE3A0: D6130022 848A0B24
	v_fma_f32 v35, v30, v11, v28                               // 0000008FE3A8: D6130023 0472171E
	v_fma_f32 v28, v30, v11, -v28                              // 0000008FE3B0: D613001C 8472171E
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000008FE3B8: BF870143
	v_add_f32_e32 v30, v34, v29                                // 0000008FE3BC: 063C3B22
	v_fma_f32 v36, v32, v4, -v31                               // 0000008FE3C0: D6130024 847E0920
	v_dual_fmac_f32 v31, v32, v4 :: v_dual_add_f32 v32, v37, v33// 0000008FE3C8: C8080920 1F204325
	v_sub_f32_e32 v29, v29, v34                                // 0000008FE3D0: 083A451D
	v_dual_add_f32 v39, v28, v36 :: v_dual_add_f32 v38, v31, v35// 0000008FE3D4: C908491C 2726471F
	v_dual_sub_f32 v33, v37, v33 :: v_dual_sub_f32 v28, v36, v28// 0000008FE3DC: C94A4325 211C3924
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008FE3E4: BF870122
	v_dual_add_f32 v41, v30, v39 :: v_dual_add_f32 v40, v32, v38// 0000008FE3E8: C9084F1E 29284D20
	v_sub_f32_e32 v32, v32, v38                                // 0000008FE3F0: 08404D20
	v_mov_b32_dpp v34, v40 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000008FE3F4: 7E4402FA FF016128
	v_cndmask_b32_e64 v37, -v40, v40, s1                       // 0000008FE3FC: D5010025 20065128
	v_sub_f32_e32 v31, v31, v35                                // 0000008FE404: 083E471F
	v_mov_b32_dpp v35, v41 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000008FE408: 7E4602FA FF016129
	v_cndmask_b32_e64 v40, -v41, v41, s1                       // 0000008FE410: D5010028 20065329
	v_mov_b32_dpp v41, v32 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000008FE418: 7E5202FA FF016120
	v_add_f32_e32 v34, v37, v34                                // 0000008FE420: 06444525
	v_cndmask_b32_e64 v42, -v32, v32, s1                       // 0000008FE424: D501002A 20064120
	v_add_f32_e32 v36, v33, v31                                // 0000008FE42C: 06483F21
	v_sub_f32_e32 v37, v30, v39                                // 0000008FE430: 084A4F1E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000008FE434: BF870254
	v_mov_b32_dpp v38, v34 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000008FE438: 7E4C02FA FF016222
	v_cndmask_b32_e64 v34, -v34, v34, s3                       // 0000008FE440: D5010022 200E4522
	v_add_f32_e32 v35, v40, v35                                // 0000008FE448: 06464728
	v_mov_b32_dpp v30, v36 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000008FE44C: 7E3C02FA FF016124
	v_cndmask_b32_e64 v36, -v36, v36, s1                       // 0000008FE454: D5010024 20064924
	v_add_f32_e32 v34, v34, v38                                // 0000008FE45C: 06444D22
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000008FE460: BF870224
	v_mov_b32_dpp v39, v35 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000008FE464: 7E4E02FA FF016223
	v_cndmask_b32_e64 v35, -v35, v35, s3                       // 0000008FE46C: D5010023 200E4723
	v_add_f32_e32 v30, v36, v30                                // 0000008FE474: 063C3D24
	v_sub_f32_e32 v36, v33, v31                                // 0000008FE478: 08483F21
	v_add_f32_e32 v31, v29, v28                                // 0000008FE47C: 063E391D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000008FE480: BF870214
	v_add_f32_e32 v33, v35, v39                                // 0000008FE484: 06424F23
	v_mov_b32_dpp v35, v30 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000008FE488: 7E4602FA FF01621E
	v_cndmask_b32_e64 v30, -v30, v30, s3                       // 0000008FE490: D501001E 200E3D1E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000008FE498: BF8701C4
	v_mov_b32_dpp v38, v31 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000008FE49C: 7E4C02FA FF01611F
	v_cndmask_b32_e64 v31, -v31, v31, s1                       // 0000008FE4A4: D501001F 20063F1F
	v_sub_f32_e32 v39, v29, v28                                // 0000008FE4AC: 084E391D
	v_mov_b32_dpp v28, v34 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000008FE4B0: 7E3802FA FF016422
	v_dual_add_f32 v29, v30, v35 :: v_dual_add_f32 v30, v31, v38// 0000008FE4B8: C908471E 1D1E4D1F
	v_cndmask_b32_e64 v31, -v34, v34, s4                       // 0000008FE4C0: D501001F 20124522
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008FE4C8: BF870194
	v_mov_b32_dpp v43, v39 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000008FE4CC: 7E5602FA FF016127
	v_mov_b32_dpp v34, v29 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000008FE4D4: 7E4402FA FF01641D
	v_cndmask_b32_e64 v29, -v29, v29, s4                       // 0000008FE4DC: D501001D 20123B1D
	v_mov_b32_dpp v38, v30 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000008FE4E4: 7E4C02FA FF01621E
	v_cndmask_b32_e64 v40, -v30, v30, s3                       // 0000008FE4EC: D5010028 200E3D1E
	v_cndmask_b32_e64 v39, -v39, v39, s1                       // 0000008FE4F4: D5010027 20064F27
	v_add_f32_e32 v30, v31, v28                                // 0000008FE4FC: 063C391F
	v_add_f32_e32 v32, v29, v34                                // 0000008FE500: 0640451D
	v_mov_b32_dpp v35, v33 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000008FE504: 7E4602FA FF016421
	v_cndmask_b32_e64 v33, -v33, v33, s4                       // 0000008FE50C: D5010021 20124321
	v_dual_add_f32 v34, v40, v38 :: v_dual_add_f32 v39, v39, v43// 0000008FE514: C9084D28 22265727
	v_mov_b32_dpp v28, v30 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000008FE51C: 7E3802FA FF01681E
	v_mov_b32_dpp v29, v32 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000008FE524: 7E3A02FA FF016820
	s_delay_alu instid0(VALU_DEP_4)                            // 0000008FE52C: BF870004
	v_add_f32_e32 v33, v33, v35                                // 0000008FE530: 06424721
	v_add_f32_e32 v35, v42, v41                                // 0000008FE534: 0646532A
	v_mov_b32_dpp v41, v37 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000008FE538: 7E5202FA FF016125
	v_cndmask_b32_e64 v37, -v37, v37, s1                       // 0000008FE540: D5010025 20064B25
	v_mov_b32_dpp v38, v34 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000008FE548: 7E4C02FA FF016422
	v_cndmask_b32_e64 v34, -v34, v34, s4                       // 0000008FE550: D5010022 20124522
	v_mov_b32_dpp v40, v35 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000008FE558: 7E5002FA FF016223
	v_cndmask_b32_e64 v35, -v35, v35, s3                       // 0000008FE560: D5010023 200E4723
	v_add_f32_e32 v37, v37, v41                                // 0000008FE568: 064A5325
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008FE56C: BF8700B2
	v_add_f32_e32 v35, v35, v40                                // 0000008FE570: 06465123
	v_mov_b32_dpp v42, v36 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000008FE574: 7E5402FA FF016124
	v_cndmask_b32_e64 v36, -v36, v36, s1                       // 0000008FE57C: D5010024 20064924
	v_add_f32_e32 v36, v36, v42                                // 0000008FE584: 06485524
	v_mov_b32_dpp v42, v39 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000008FE588: 7E5402FA FF016227
	v_cndmask_b32_e64 v39, -v39, v39, s3                       // 0000008FE590: D5010027 200E4F27
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008FE598: BF8700A3
	v_mov_b32_dpp v41, v36 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000008FE59C: 7E5202FA FF016224
	v_cndmask_b32_e64 v36, -v36, v36, s3                       // 0000008FE5A4: D5010024 200E4924
	v_dual_add_f32 v39, v39, v42 :: v_dual_add_f32 v36, v36, v41// 0000008FE5AC: C9085527 27245324
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000008FE5B4: BF870231
	v_mov_b32_dpp v45, v39 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000008FE5B8: 7E5A02FA FF016427
	v_cndmask_b32_e64 v39, -v39, v39, s4                       // 0000008FE5C0: D5010027 20124F27
	v_mov_b32_dpp v31, v33 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000008FE5C8: 7E3E02FA FF016821
	v_mov_b32_dpp v43, v36 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000008FE5D0: 7E5602FA FF016424
	v_cndmask_b32_e64 v44, -v36, v36, s4                       // 0000008FE5D8: D501002C 20124924
	v_add_f32_e32 v36, v34, v38                                // 0000008FE5E0: 06484D22
	v_mov_b32_dpp v40, v37 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000008FE5E4: 7E5002FA FF016225
	v_cndmask_b32_e64 v37, -v37, v37, s3                       // 0000008FE5EC: D5010025 200E4B25
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008FE5F4: BF870113
	v_mov_b32_dpp v34, v36 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000008FE5F8: 7E4402FA FF016824
	v_add_f32_e32 v37, v37, v40                                // 0000008FE600: 064A5125
	v_mov_b32_dpp v40, v35 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000008FE604: 7E5002FA FF016423
	v_cndmask_b32_e64 v35, -v35, v35, s4                       // 0000008FE60C: D5010023 20124723
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008FE614: BF8701A3
	v_mov_b32_dpp v41, v37 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000008FE618: 7E5202FA FF016425
	v_cndmask_b32_e64 v42, -v37, v37, s4                       // 0000008FE620: D501002A 20124B25
	v_dual_add_f32 v37, v35, v40 :: v_dual_add_f32 v40, v44, v43// 0000008FE628: C9085123 2528572C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008FE630: BF8701A2
	v_add_f32_e32 v38, v42, v41                                // 0000008FE634: 064C532A
	v_add_f32_e32 v42, v39, v45                                // 0000008FE638: 06545B27
	v_mov_b32_dpp v35, v37 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000008FE63C: 7E4602FA FF016825
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000008FE644: BF870214
	v_mov_b32_dpp v41, v40 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000008FE648: 7E5202FA FF016828
	v_mov_b32_dpp v39, v38 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000008FE650: 7E4E02FA FF016826
	s_delay_alu instid0(VALU_DEP_4)                            // 0000008FE658: BF870004
	v_mov_b32_dpp v43, v42 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000008FE65C: 7E5602FA FF01682A
	s_and_saveexec_b32 s6, s0                                  // 0000008FE664: BE862000
	s_cbranch_execz 64235                                      // 0000008FE668: BFA5FAEB <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_gsILi3ELi8ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiSA_S5_S5_PDF16_PfPj+0x2c18>
	v_cndmask_b32_e64 v30, -v30, v30, s5                       // 0000008FE66C: D501001E 20163D1E
	v_cndmask_b32_e64 v40, -v40, v40, s5                       // 0000008FE674: D5010028 20165128
	v_cndmask_b32_e64 v33, -v33, v33, s5                       // 0000008FE67C: D5010021 20164321
	v_cndmask_b32_e64 v42, -v42, v42, s5                       // 0000008FE684: D501002A 2016552A
	v_cndmask_b32_e64 v32, -v32, v32, s5                       // 0000008FE68C: D5010020 20164120
	v_cndmask_b32_e64 v36, -v36, v36, s5                       // 0000008FE694: D5010024 20164924
	v_cndmask_b32_e64 v37, -v37, v37, s5                       // 0000008FE69C: D5010025 20164B25
	v_cndmask_b32_e64 v38, -v38, v38, s5                       // 0000008FE6A4: D5010026 20164D26
	v_add_f32_e32 v30, v30, v28                                // 0000008FE6AC: 063C391E
	v_dual_add_f32 v40, v40, v41 :: v_dual_add_f32 v31, v33, v31// 0000008FE6B0: C9085328 281E3F21
	v_dual_add_f32 v42, v42, v43 :: v_dual_add_f32 v29, v32, v29// 0000008FE6B8: C908572A 2A1C3B20
	v_dual_add_f32 v32, v36, v34 :: v_dual_add_f32 v33, v37, v35// 0000008FE6C0: C9084524 20204725
	v_add_f32_e32 v38, v38, v39                                // 0000008FE6C8: 064C4F26
	v_fma_mixhi_f16 v28, v30, s9, 0                            // 0000008FE6CC: CC22001C 0200131E
	v_fma_mixlo_f16 v28, v31, s9, 0                            // 0000008FE6D4: CC21001C 0200131F
	v_fma_mixlo_f16 v29, v29, s9, 0                            // 0000008FE6DC: CC21001D 0200131D
	v_fma_mixhi_f16 v29, v32, s9, 0                            // 0000008FE6E4: CC22001D 02001320
	v_fma_mixlo_f16 v30, v33, s9, 0                            // 0000008FE6EC: CC21001E 02001321
	v_fma_mixhi_f16 v30, v38, s9, 0                            // 0000008FE6F4: CC22001E 02001326
	v_fma_mixlo_f16 v31, v40, s9, 0                            // 0000008FE6FC: CC21001F 02001328
	v_fma_mixhi_f16 v31, v42, s9, 0                            // 0000008FE704: CC22001F 0200132A
	s_clause 0x7                                               // 0000008FE70C: BF850007
	global_store_d16_hi_b16 v[2:3], v28, off                   // 0000008FE710: DC960000 007C1C02
	global_store_b16 v[2:3], v28, off offset:32                // 0000008FE718: DC660020 007C1C02
	global_store_b16 v[2:3], v29, off offset:64                // 0000008FE720: DC660040 007C1D02
	global_store_d16_hi_b16 v[2:3], v29, off offset:96         // 0000008FE728: DC960060 007C1D02
	global_store_b16 v[2:3], v30, off offset:128               // 0000008FE730: DC660080 007C1E02
	global_store_d16_hi_b16 v[2:3], v30, off offset:160        // 0000008FE738: DC9600A0 007C1E02
	global_store_b16 v[2:3], v31, off offset:192               // 0000008FE740: DC6600C0 007C1F02
	global_store_d16_hi_b16 v[2:3], v31, off offset:224        // 0000008FE748: DC9600E0 007C1F02
	s_branch 64177                                             // 0000008FE750: BFA0FAB1 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_gsILi3ELi8ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiSA_S5_S5_PDF16_PfPj+0x2c18>
	s_and_b32 exec_lo, exec_lo, s2                             // 0000008FE754: 8B7E027E
	s_cbranch_execz 6                                          // 0000008FE758: BFA50006 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_gu_gsILi3ELi8ELi2EEEvPKjPKDF16_PKNS0_6HtItemEPKiSA_S5_S5_PDF16_PfPj+0x4174>
	s_lshl_b64 s[0:1], s[24:25], 2                             // 0000008FE75C: 84808218
	v_mov_b32_e32 v0, 0                                        // 0000008FE760: 7E000280
	s_add_u32 s0, s22, s0                                      // 0000008FE764: 80000016
	s_addc_u32 s1, s23, s1                                     // 0000008FE768: 82010117
	global_store_b32 v0, v0, s[0:1]                            // 0000008FE76C: DC6A0000 00000000
	s_nop 0                                                    // 0000008FE774: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000008FE778: BFB60003
	s_endpgm                                                   // 0000008FE77C: BFB00000
		...

