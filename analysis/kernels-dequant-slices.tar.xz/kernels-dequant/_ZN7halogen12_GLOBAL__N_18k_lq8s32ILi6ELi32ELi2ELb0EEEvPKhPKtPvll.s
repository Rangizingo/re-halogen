000000000058c800 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi6ELi32ELi2ELb0EEEvPKhPKtPvll>:
; _ZN7halogen12_GLOBAL__N_18k_lq8s32ILi6ELi32ELi2ELb0EEEvPKhPKtPvll():
	s_clause 0x1                                               // 00000058C800: BF850001
	s_load_b256 s[4:11], s[0:1], null                          // 00000058C804: F40C0100 F8000000
	s_load_b64 s[12:13], s[0:1], 0x20                          // 00000058C80C: F4040300 F8000020
	s_mov_b32 s3, 0                                            // 00000058C814: BE830080
	v_lshrrev_b32_e32 v14, 6, v0                               // 00000058C818: 321C0086
	s_lshl_b64 s[2:3], s[2:3], 2                               // 00000058C81C: 84828202
	v_bfe_u32 v15, v0, 5, 1                                    // 00000058C820: D610000F 02050B00
	v_dual_mov_b32 v17, 0 :: v_dual_and_b32 v16, 31, v0        // 00000058C828: CA240080 1110009F
	s_delay_alu instid0(VALU_DEP_3)                            // 00000058C830: BF870003
	v_or_b32_e32 v1, s2, v14                                   // 00000058C834: 38021C02
	v_mov_b32_e32 v2, s3                                       // 00000058C838: 7E040203
	.long 0x7e1a3880                                           // 00000058C83C: 7E1A3880
	v_dual_mov_b32 v5, 0 :: v_dual_mov_b32 v6, 0               // 00000058C840: CA100080 05060080
	v_mov_b32_e32 v8, 0                                        // 00000058C848: 7E100280
	s_waitcnt lgkmcnt(0)                                       // 00000058C84C: BF89FC07
	s_ashr_i32 s0, s11, 31                                     // 00000058C850: 86009F0B
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 00000058C854: 7CA8020C
	s_lshr_b32 s0, s0, 28                                      // 00000058C858: 85009C00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000058C85C: BF8704A9
	s_add_u32 s0, s10, s0                                      // 00000058C860: 8000000A
	s_addc_u32 s1, s11, 0                                      // 00000058C864: 8201800B
	s_ashr_i64 s[0:1], s[0:1], 4                               // 00000058C868: 86808400
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000058C86C: 02020280
	s_add_u32 s14, s10, s0                                     // 00000058C870: 800E000A
	s_addc_u32 s1, s11, s1                                     // 00000058C874: 8201010B
	s_add_u32 s14, s14, 15                                     // 00000058C878: 800E8F0E
	s_addc_u32 s1, s1, 0                                       // 00000058C87C: 82018001
	s_add_i32 s15, s0, 1                                       // 00000058C880: 810F8100
	v_cndmask_b32_e64 v2, 0, s3, vcc_lo                        // 00000058C884: D5010002 01A80680
	s_lshr_b32 s16, s15, 31                                    // 00000058C88C: 85109F0F
	s_and_b32 s14, s14, -16                                    // 00000058C890: 8B0ED00E
	s_add_i32 s15, s15, s16                                    // 00000058C894: 810F100F
	.long 0xd72c0004                                           // 00000058C898: D72C0004
	v_cndmask_b32_e32 v0, v1, v1, vcc_lo                       // 00000058C89C: 02000301
	s_ashr_i32 s15, s15, 1                                     // 00000058C8A0: 860F810F
	.long 0xd72c0002                                           // 00000058C8A4: D72C0002
	v_cndmask_b32_e32 v0, v2, v14, vcc_lo                      // 00000058C8A8: 02001D02
	.long 0xd72c0003                                           // 00000058C8AC: D72C0003
	v_cndmask_b32_e32 v1, s15, v15, vcc_lo                     // 00000058C8B0: 02021E0F
	v_mad_u64_u32 v[10:11], null, v1, s14, s[4:5]              // 00000058C8B4: D6FE7C0A 00101D01
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000058C8BC: BF8701A2
	v_dual_mov_b32 v7, 0 :: v_dual_add_nc_u32 v18, v3, v16     // 00000058C8C0: CA200080 07122103
	v_add_nc_u32_e32 v1, s15, v3                               // 00000058C8C8: 4A02060F
	v_add3_u32 v11, v2, v11, v4                                // 00000058C8CC: D655000B 04121702
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000058C8D4: BF870214
	.long 0xd7006a14                                           // 00000058C8D8: D7006A14
	v_cndmask_b32_e32 v0, v10, v10, vcc_lo                     // 00000058C8DC: 0200150A
	v_lshlrev_b32_e32 v12, 4, v18                              // 00000058C8E0: 30182484
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000058C8E4: BF870214
	v_min_i32_e32 v19, s0, v1                                  // 00000058C8E8: 22260200
	v_add_co_ci_u32_e64 v21, null, s11, v11, vcc_lo            // 00000058C8EC: D5207C15 01AA160B
	s_delay_alu instid0(VALU_DEP_2)                            // 00000058C8F4: BF870002
	v_cmp_lt_i32_e32 vcc_lo, v18, v19                          // 00000058C8F8: 7C822712
	s_and_saveexec_b32 s1, vcc_lo                              // 00000058C8FC: BE81206A
	s_cbranch_execz 19                                         // 00000058C900: BFA50013 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi6ELi32ELi2ELb0EEEvPKhPKtPvll+0x150>
	v_lshlrev_b32_e32 v1, 4, v18                               // 00000058C904: 30022484
	v_and_b32_e32 v3, -2, v18                                  // 00000058C908: 360624C2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000058C90C: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000058C910: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 00000058C914: 3408069F
	.long 0xd7000001                                           // 00000058C918: D7000001
	v_cndmask_b32_e32 v1, v10, v1, vcc_lo                      // 00000058C91C: 0202030A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000058C920: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v11, v2, s0                  // 00000058C924: D5207C02 0002050B
	.long 0xd7000003                                           // 00000058C92C: D7000003
	v_cndmask_b32_e32 v1, v20, v3, vcc_lo                      // 00000058C930: 02020714
	v_add_co_ci_u32_e64 v4, null, v21, v4, s0                  // 00000058C934: D5207C04 00020915
	s_clause 0x1                                               // 00000058C93C: BF850001
	global_load_b128 v[5:8], v[1:2], off                       // 00000058C940: DC5E0000 057C0001
	global_load_d16_b16 v13, v[3:4], off                       // 00000058C948: DC820000 0D7C0003
	s_or_b32 exec_lo, exec_lo, s1                              // 00000058C950: 8C7E017E
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v24, 0             // 00000058C954: CA100080 17180080
	v_dual_mov_b32 v25, 0 :: v_dual_mov_b32 v26, 0             // 00000058C95C: CA100080 191A0080
	v_mov_b32_e32 v22, 0                                       // 00000058C964: 7E2C0280
	s_and_saveexec_b32 s1, vcc_lo                              // 00000058C968: BE81206A
	s_cbranch_execz 493                                        // 00000058C96C: BFA501ED <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi6ELi32ELi2ELb0EEEvPKhPKtPvll+0x924>
	v_dual_mov_b32 v22, 0 :: v_dual_add_nc_u32 v27, 0x200, v12 // 00000058C970: CA200080 161A18FF 00000200
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v25, 0             // 00000058C97C: CA100080 1A180080
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v23, 0             // 00000058C984: CA100080 18160080
	v_mov_b32_e32 v17, 0                                       // 00000058C98C: 7E220280
	s_mul_i32 s0, s11, 6                                       // 00000058C990: 9600860B
	s_mul_hi_u32 s14, s10, 6                                   // 00000058C994: 968E860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 00000058C998: 8484820A
	s_add_i32 s14, s14, s0                                     // 00000058C99C: 810E000E
	s_mul_i32 s16, s10, 6                                      // 00000058C9A0: 9610860A
	s_mov_b32 s15, 0                                           // 00000058C9A4: BE8F0080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 00000058C9A8: 848A810A
	s_branch 443                                               // 00000058C9AC: BFA001BB <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi6ELi32ELi2ELb0EEEvPKhPKtPvll+0x89c>
	s_or_b32 exec_lo, exec_lo, s17                             // 00000058C9B0: 8C7E117E
	v_bfe_i32 v28, v5, 0, 8                                    // 00000058C9B4: D611001C 02210105
	s_and_b32 s0, exec_lo, vcc_lo                              // 00000058C9BC: 8B006A7E
	v_add_nc_u32_e32 v27, 0x200, v27                           // 00000058C9C0: 4A3636FF 00000200
	s_or_b32 s15, s0, s15                                      // 00000058C9C8: 8C0F0F00
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058C9CC: BF870092
	v_cvt_f32_i32_e32 v28, v28                                 // 00000058C9D0: 7E380B1C
	v_fma_mix_f32 v28, v13, v28, neg(0) op_sel_hi:[1,0,0]      // 00000058C9D4: CC20001C 8A02390D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058C9DC: BF870091
	v_bfe_u32 v29, v28, 16, 1                                  // 00000058C9E0: D610001D 0205211C
	v_add3_u32 v28, v28, v29, 0x7fff                           // 00000058C9E8: D655001C 03FE3B1C 00007FFF
	.long 0x7f3a3880                                           // 00000058C9F4: 7F3A3880
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000058C9F8: BF8700A2
	.long 0x7e3a399c                                           // 00000058C9FC: 7E3A399C
	v_bfe_i32 v28, v5, 8, 8                                    // 00000058CA00: D611001C 02211105
	v_cvt_f32_i32_e32 v28, v28                                 // 00000058CA08: 7E380B1C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058CA0C: BF870091
	v_fma_mix_f32 v28, v13, v28, neg(0) op_sel_hi:[1,0,0]      // 00000058CA10: CC20001C 8A02390D
	v_bfe_u32 v30, v28, 16, 1                                  // 00000058CA18: D610001E 0205211C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000058CA20: BF8701B1
	v_add3_u32 v28, v28, v30, 0x7fff                           // 00000058CA24: D655001C 03FE3D1C 00007FFF
	v_bfe_i32 v30, v5, 16, 8                                   // 00000058CA30: D611001E 02212105
	v_ashrrev_i32_e32 v5, 24, v5                               // 00000058CA38: 340A0A98
	v_and_or_b32 v36, 0xffff0000, v28, v29                     // 00000058CA3C: D6570024 047638FF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000058CA48: BF870193
	v_cvt_f32_i32_e32 v30, v30                                 // 00000058CA4C: 7E3C0B1E
	v_cvt_f32_i32_e32 v5, v5                                   // 00000058CA50: 7E0A0B05
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000058CA54: BF870112
	v_fma_mix_f32 v30, v13, v30, neg(0) op_sel_hi:[1,0,0]      // 00000058CA58: CC20001E 8A023D0D
	v_fma_mix_f32 v5, v13, v5, neg(0) op_sel_hi:[1,0,0]        // 00000058CA60: CC200005 8A020B0D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058CA68: BF870092
	v_bfe_u32 v31, v30, 16, 1                                  // 00000058CA6C: D610001F 0205211E
	v_add3_u32 v30, v30, v31, 0x7fff                           // 00000058CA74: D655001E 03FE3F1E 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000058CA80: BF870113
	v_bfe_u32 v31, v5, 16, 1                                   // 00000058CA84: D610001F 02052105
	.long 0x7e3c399e                                           // 00000058CA8C: 7E3C399E
	.long 0x7f3c399d                                           // 00000058CA90: 7F3C399D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058CA94: BF870093
	v_add3_u32 v5, v5, v31, 0x7fff                             // 00000058CA98: D6550005 03FE3F05 00007FFF
	v_and_or_b32 v37, 0xffff0000, v5, v30                      // 00000058CAA4: D6570025 047A0AFF FFFF0000
	v_bfe_i32 v5, v6, 0, 8                                     // 00000058CAB0: D6110005 02210106
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058CAB8: BF870091
	v_cvt_f32_i32_e32 v5, v5                                   // 00000058CABC: 7E0A0B05
	v_fma_mix_f32 v5, v13, v5, neg(0) op_sel_hi:[1,0,0]        // 00000058CAC0: CC200005 8A020B0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058CAC8: BF870091
	v_bfe_u32 v28, v5, 16, 1                                   // 00000058CACC: D610001C 02052105
	v_add3_u32 v5, v5, v28, 0x7fff                             // 00000058CAD4: D6550005 03FE3905 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000058CAE0: BF8700A1
	.long 0x7e3a3985                                           // 00000058CAE4: 7E3A3985
	v_bfe_i32 v5, v6, 8, 8                                     // 00000058CAE8: D6110005 02211106
	v_cvt_f32_i32_e32 v5, v5                                   // 00000058CAF0: 7E0A0B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058CAF4: BF870091
	v_fma_mix_f32 v5, v13, v5, neg(0) op_sel_hi:[1,0,0]        // 00000058CAF8: CC200005 8A020B0D
	v_bfe_u32 v28, v5, 16, 1                                   // 00000058CB00: D610001C 02052105
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000058CB08: BF8701B1
	v_add3_u32 v5, v5, v28, 0x7fff                             // 00000058CB0C: D6550005 03FE3905 00007FFF
	v_bfe_i32 v28, v6, 16, 8                                   // 00000058CB18: D611001C 02212106
	v_ashrrev_i32_e32 v6, 24, v6                               // 00000058CB20: 340C0C98
	v_and_or_b32 v38, 0xffff0000, v5, v29                      // 00000058CB24: D6570026 04760AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000058CB30: BF870193
	v_cvt_f32_i32_e32 v28, v28                                 // 00000058CB34: 7E380B1C
	v_cvt_f32_i32_e32 v6, v6                                   // 00000058CB38: 7E0C0B06
	v_bfe_i32 v5, v7, 0, 8                                     // 00000058CB3C: D6110005 02210107
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000058CB44: BF870193
	v_fma_mix_f32 v28, v13, v28, neg(0) op_sel_hi:[1,0,0]      // 00000058CB48: CC20001C 8A02390D
	v_fma_mix_f32 v6, v13, v6, neg(0) op_sel_hi:[1,0,0]        // 00000058CB50: CC200006 8A020D0D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000058CB58: BF870193
	v_cvt_f32_i32_e32 v5, v5                                   // 00000058CB5C: 7E0A0B05
	v_bfe_u32 v30, v28, 16, 1                                  // 00000058CB60: D610001E 0205211C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000058CB68: BF870112
	v_fma_mix_f32 v5, v13, v5, neg(0) op_sel_hi:[1,0,0]        // 00000058CB6C: CC200005 8A020B0D
	v_add3_u32 v28, v28, v30, 0x7fff                           // 00000058CB74: D655001C 03FE3D1C 00007FFF
	v_bfe_u32 v30, v6, 16, 1                                   // 00000058CB80: D610001E 02052106
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000058CB88: BF8701A2
	.long 0x7e38399c                                           // 00000058CB8C: 7E38399C
	.long 0x7f38399d                                           // 00000058CB90: 7F38399D
	v_add3_u32 v6, v6, v30, 0x7fff                             // 00000058CB94: D6550006 03FE3D06 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000058CBA0: BF8700A1
	v_and_or_b32 v39, 0xffff0000, v6, v28                      // 00000058CBA4: D6570027 04720CFF FFFF0000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000058CBB0: D6100006 02052105
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000058CBB8: D6550005 03FE0D05 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000058CBC4: BF8700A1
	.long 0x7e3a3985                                           // 00000058CBC8: 7E3A3985
	v_bfe_i32 v5, v7, 8, 8                                     // 00000058CBCC: D6110005 02211107
	v_cvt_f32_i32_e32 v5, v5                                   // 00000058CBD4: 7E0A0B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058CBD8: BF870091
	v_fma_mix_f32 v5, v13, v5, neg(0) op_sel_hi:[1,0,0]        // 00000058CBDC: CC200005 8A020B0D
	v_bfe_u32 v6, v5, 16, 1                                    // 00000058CBE4: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000058CBEC: BF8701B1
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000058CBF0: D6550005 03FE0D05 00007FFF
	v_bfe_i32 v6, v7, 16, 8                                    // 00000058CBFC: D6110006 02212107
	v_ashrrev_i32_e32 v7, 24, v7                               // 00000058CC04: 340E0E98
	v_and_or_b32 v40, 0xffff0000, v5, v29                      // 00000058CC08: D6570028 04760AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000058CC14: BF870193
	v_cvt_f32_i32_e32 v6, v6                                   // 00000058CC18: 7E0C0B06
	v_cvt_f32_i32_e32 v7, v7                                   // 00000058CC1C: 7E0E0B07
	v_bfe_i32 v5, v8, 0, 8                                     // 00000058CC20: D6110005 02210108
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000058CC28: BF870193
	v_fma_mix_f32 v6, v13, v6, neg(0) op_sel_hi:[1,0,0]        // 00000058CC2C: CC200006 8A020D0D
	v_fma_mix_f32 v7, v13, v7, neg(0) op_sel_hi:[1,0,0]        // 00000058CC34: CC200007 8A020F0D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000058CC3C: BF870193
	v_cvt_f32_i32_e32 v5, v5                                   // 00000058CC40: 7E0A0B05
	v_bfe_u32 v28, v6, 16, 1                                   // 00000058CC44: D610001C 02052106
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000058CC4C: BF870112
	v_fma_mix_f32 v5, v13, v5, neg(0) op_sel_hi:[1,0,0]        // 00000058CC50: CC200005 8A020B0D
	v_add3_u32 v6, v6, v28, 0x7fff                             // 00000058CC58: D6550006 03FE3906 00007FFF
	v_bfe_u32 v28, v7, 16, 1                                   // 00000058CC64: D610001C 02052107
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000058CC6C: BF8701A2
	.long 0x7e0c3986                                           // 00000058CC70: 7E0C3986
	.long 0x7f0c399d                                           // 00000058CC74: 7F0C399D
	v_add3_u32 v7, v7, v28, 0x7fff                             // 00000058CC78: D6550007 03FE3907 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000058CC84: BF8700A1
	v_and_or_b32 v41, 0xffff0000, v7, v6                       // 00000058CC88: D6570029 041A0EFF FFFF0000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000058CC94: D6100006 02052105
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000058CC9C: D6550005 03FE0D05 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000058CCA8: BF8700A1
	.long 0x7e3a3985                                           // 00000058CCAC: 7E3A3985
	v_bfe_i32 v5, v8, 8, 8                                     // 00000058CCB0: D6110005 02211108
	v_cvt_f32_i32_e32 v5, v5                                   // 00000058CCB8: 7E0A0B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058CCBC: BF870091
	v_fma_mix_f32 v5, v13, v5, neg(0) op_sel_hi:[1,0,0]        // 00000058CCC0: CC200005 8A020B0D
	v_bfe_u32 v6, v5, 16, 1                                    // 00000058CCC8: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000058CCD0: BF870121
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000058CCD4: D6550005 03FE0D05 00007FFF
	v_bfe_i32 v6, v8, 16, 8                                    // 00000058CCE0: D6110006 02212108
	v_and_or_b32 v42, 0xffff0000, v5, v29                      // 00000058CCE8: D657002A 04760AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058CCF4: BF870092
	v_cvt_f32_i32_e32 v6, v6                                   // 00000058CCF8: 7E0C0B06
	v_fma_mix_f32 v6, v13, v6, neg(0) op_sel_hi:[1,0,0]        // 00000058CCFC: CC200006 8A020D0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058CD04: BF870091
	v_bfe_u32 v7, v6, 16, 1                                    // 00000058CD08: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 00000058CD10: D6550006 03FE0F06 00007FFF
	v_ashrrev_i32_e32 v7, 24, v8                               // 00000058CD1C: 340E1098
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000058CD20: BF870112
	.long 0x7e0c3986                                           // 00000058CD24: 7E0C3986
	v_cvt_f32_i32_e32 v7, v7                                   // 00000058CD28: 7E0E0B07
	.long 0x7f0c399d                                           // 00000058CD2C: 7F0C399D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000058CD30: BF870122
	v_fma_mix_f32 v7, v13, v7, neg(0) op_sel_hi:[1,0,0]        // 00000058CD34: CC200007 8A020F0D
	v_ashrrev_i32_e32 v13, 31, v12                             // 00000058CD3C: 341A189F
	v_bfe_u32 v8, v7, 16, 1                                    // 00000058CD40: D6100008 02052107
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058CD48: BF870091
	v_add3_u32 v7, v7, v8, 0x7fff                              // 00000058CD4C: D6550007 03FE1107 00007FFF
	v_and_or_b32 v43, 0xffff0000, v7, v6                       // 00000058CD58: D657002B 041A0EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000058CD64: BF8701C4
	.long 0xd73c0005                                           // 00000058CD68: D73C0005
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 00000058CD6C: 02021881
	s_waitcnt vmcnt(0)                                         // 00000058CD70: BF8903F7
	.long 0x7e1a3909                                           // 00000058CD74: 7E1A3909
	v_add_nc_u32_e32 v12, 0x200, v12                           // 00000058CD78: 4A1818FF 00000200
	.long 0xd7006a20                                           // 00000058CD80: D7006A20
	v_cndmask_b32_e32 v1, s6, v5, vcc_lo                       // 00000058CD84: 02020A06
	s_delay_alu instid0(VALU_DEP_1)                            // 00000058CD88: BF870001
	v_add_co_ci_u32_e64 v33, null, s7, v6, vcc_lo              // 00000058CD8C: D5207C21 01AA0C07
	s_clause 0x1                                               // 00000058CD94: BF850001
	global_load_b128 v[5:8], v[32:33], off                     // 00000058CD98: DC5E0000 057C0020
	global_load_b128 v[28:31], v[32:33], off offset:16         // 00000058CDA0: DC5E0010 1C7C0020
	s_waitcnt vmcnt(1)                                         // 00000058CDA8: BF8907F7
	v_dot2_f32_bf16 v5, v5, v36, 0                             // 00000058CDAC: CC1A4005 1A024905
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058CDB4: BF870091
	v_dot2_f32_bf16 v5, v6, v37, v5                            // 00000058CDB8: CC1A4005 1C164B06
	v_dot2_f32_bf16 v5, v7, v38, v5                            // 00000058CDC0: CC1A4005 1C164D07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000058CDC8: BF8700A1
	v_dot2_f32_bf16 v5, v8, v39, v5                            // 00000058CDCC: CC1A4005 1C164F08
	s_waitcnt vmcnt(0)                                         // 00000058CDD4: BF8903F7
	v_dot2_f32_bf16 v5, v28, v40, v5                           // 00000058CDD8: CC1A4005 1C16511C
	.long 0xd7006a1c                                           // 00000058CDE0: D7006A1C
	v_cndmask_b32_e32 v0, v32, v10, vcc_lo                     // 00000058CDE4: 02001520
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000058CDE8: BF8701B2
	v_dot2_f32_bf16 v5, v29, v41, v5                           // 00000058CDEC: CC1A4005 1C16531D
	v_add_co_ci_u32_e64 v29, null, s11, v33, vcc_lo            // 00000058CDF4: D5207C1D 01AA420B
	.long 0xd7006a22                                           // 00000058CDFC: D7006A22
	v_cndmask_b32_e32 v0, v32, v4, vcc_lo                      // 00000058CE00: 02000920
	v_dot2_f32_bf16 v5, v30, v42, v5                           // 00000058CE04: CC1A4005 1C16551E
	v_add_co_ci_u32_e64 v35, null, s5, v33, vcc_lo             // 00000058CE0C: D5207C23 01AA4205
	.long 0xd7006a20                                           // 00000058CE14: D7006A20
	v_cndmask_b32_e32 v0, v32, v16, vcc_lo                     // 00000058CE18: 02002120
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000058CE1C: BF870123
	v_dot2_f32_bf16 v5, v31, v43, v5                           // 00000058CE20: CC1A4005 1C16571F
	v_add_co_ci_u32_e64 v33, null, s14, v33, vcc_lo            // 00000058CE28: D5207C21 01AA420E
	v_add_f32_e32 v22, v22, v5                                 // 00000058CE30: 062C0B16
	s_clause 0x1                                               // 00000058CE34: BF850001
	global_load_b128 v[5:8], v[28:29], off                     // 00000058CE38: DC5E0000 057C001C
	global_load_b128 v[28:31], v[28:29], off offset:16         // 00000058CE40: DC5E0010 1C7C001C
	s_waitcnt vmcnt(1)                                         // 00000058CE48: BF8907F7
	v_dot2_f32_bf16 v5, v5, v36, 0                             // 00000058CE4C: CC1A4005 1A024905
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058CE54: BF870091
	v_dot2_f32_bf16 v5, v6, v37, v5                            // 00000058CE58: CC1A4005 1C164B06
	v_dot2_f32_bf16 v5, v7, v38, v5                            // 00000058CE60: CC1A4005 1C164D07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000058CE68: BF8700A1
	v_dot2_f32_bf16 v5, v8, v39, v5                            // 00000058CE6C: CC1A4005 1C164F08
	s_waitcnt vmcnt(0)                                         // 00000058CE74: BF8903F7
	v_dot2_f32_bf16 v5, v28, v40, v5                           // 00000058CE78: CC1A4005 1C16511C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058CE80: BF870091
	v_dot2_f32_bf16 v5, v29, v41, v5                           // 00000058CE84: CC1A4005 1C16531D
	v_dot2_f32_bf16 v5, v30, v42, v5                           // 00000058CE8C: CC1A4005 1C16551E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058CE94: BF870091
	v_dot2_f32_bf16 v5, v31, v43, v5                           // 00000058CE98: CC1A4005 1C16571F
	v_add_f32_e32 v26, v26, v5                                 // 00000058CEA0: 06340B1A
	s_clause 0x1                                               // 00000058CEA4: BF850001
	global_load_b128 v[5:8], v[34:35], off                     // 00000058CEA8: DC5E0000 057C0022
	global_load_b128 v[28:31], v[34:35], off offset:16         // 00000058CEB0: DC5E0010 1C7C0022
	s_waitcnt vmcnt(1)                                         // 00000058CEB8: BF8907F7
	v_dot2_f32_bf16 v5, v5, v36, 0                             // 00000058CEBC: CC1A4005 1A024905
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058CEC4: BF870091
	v_dot2_f32_bf16 v5, v6, v37, v5                            // 00000058CEC8: CC1A4005 1C164B06
	v_dot2_f32_bf16 v5, v7, v38, v5                            // 00000058CED0: CC1A4005 1C164D07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000058CED8: BF8700A1
	v_dot2_f32_bf16 v5, v8, v39, v5                            // 00000058CEDC: CC1A4005 1C164F08
	s_waitcnt vmcnt(0)                                         // 00000058CEE4: BF8903F7
	v_dot2_f32_bf16 v5, v28, v40, v5                           // 00000058CEE8: CC1A4005 1C16511C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058CEF0: BF870091
	v_dot2_f32_bf16 v5, v29, v41, v5                           // 00000058CEF4: CC1A4005 1C16531D
	v_dot2_f32_bf16 v5, v30, v42, v5                           // 00000058CEFC: CC1A4005 1C16551E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058CF04: BF870091
	v_dot2_f32_bf16 v5, v31, v43, v5                           // 00000058CF08: CC1A4005 1C16571F
	v_add_f32_e32 v25, v25, v5                                 // 00000058CF10: 06320B19
	s_clause 0x1                                               // 00000058CF14: BF850001
	global_load_b128 v[5:8], v[32:33], off                     // 00000058CF18: DC5E0000 057C0020
	global_load_b128 v[28:31], v[32:33], off offset:16         // 00000058CF20: DC5E0010 1C7C0020
	s_waitcnt vmcnt(1)                                         // 00000058CF28: BF8907F7
	v_dot2_f32_bf16 v5, v5, v36, 0                             // 00000058CF2C: CC1A4005 1A024905
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058CF34: BF870091
	v_dot2_f32_bf16 v5, v6, v37, v5                            // 00000058CF38: CC1A4005 1C164B06
	v_dot2_f32_bf16 v5, v7, v38, v5                            // 00000058CF40: CC1A4005 1C164D07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000058CF48: BF8700A1
	v_dot2_f32_bf16 v5, v8, v39, v5                            // 00000058CF4C: CC1A4005 1C164F08
	s_waitcnt vmcnt(0)                                         // 00000058CF54: BF8903F7
	v_dot2_f32_bf16 v5, v28, v40, v5                           // 00000058CF58: CC1A4005 1C16511C
	.long 0xd7006a1c                                           // 00000058CF60: D7006A1C
	v_cndmask_b32_e32 v0, v34, v4, vcc_lo                      // 00000058CF64: 02000922
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000058CF68: BF870122
	v_dot2_f32_bf16 v5, v29, v41, v5                           // 00000058CF6C: CC1A4005 1C16531D
	v_add_co_ci_u32_e64 v29, null, s5, v35, vcc_lo             // 00000058CF74: D5207C1D 01AA4605
	v_dot2_f32_bf16 v5, v30, v42, v5                           // 00000058CF7C: CC1A4005 1C16551E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058CF84: BF870091
	v_dot2_f32_bf16 v5, v31, v43, v5                           // 00000058CF88: CC1A4005 1C16571F
	v_add_f32_e32 v24, v24, v5                                 // 00000058CF90: 06300B18
	s_clause 0x1                                               // 00000058CF94: BF850001
	global_load_b128 v[5:8], v[28:29], off                     // 00000058CF98: DC5E0000 057C001C
	global_load_b128 v[28:31], v[28:29], off offset:16         // 00000058CFA0: DC5E0010 1C7C001C
	s_waitcnt vmcnt(1)                                         // 00000058CFA8: BF8907F7
	v_dot2_f32_bf16 v5, v5, v36, 0                             // 00000058CFAC: CC1A4005 1A024905
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058CFB4: BF870091
	v_dot2_f32_bf16 v5, v6, v37, v5                            // 00000058CFB8: CC1A4005 1C164B06
	v_dot2_f32_bf16 v5, v7, v38, v5                            // 00000058CFC0: CC1A4005 1C164D07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000058CFC8: BF8700A1
	v_dot2_f32_bf16 v5, v8, v39, v5                            // 00000058CFCC: CC1A4005 1C164F08
	s_waitcnt vmcnt(0)                                         // 00000058CFD4: BF8903F7
	v_dot2_f32_bf16 v5, v28, v40, v5                           // 00000058CFD8: CC1A4005 1C16511C
	.long 0xd7006a1c                                           // 00000058CFE0: D7006A1C
	v_cndmask_b32_e32 v0, v32, v4, vcc_lo                      // 00000058CFE4: 02000920
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000058CFE8: BF870122
	v_dot2_f32_bf16 v5, v29, v41, v5                           // 00000058CFEC: CC1A4005 1C16531D
	v_add_co_ci_u32_e64 v29, null, s5, v33, vcc_lo             // 00000058CFF4: D5207C1D 01AA4205
	v_dot2_f32_bf16 v5, v30, v42, v5                           // 00000058CFFC: CC1A4005 1C16551E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058D004: BF870091
	v_dot2_f32_bf16 v5, v31, v43, v5                           // 00000058D008: CC1A4005 1C16571F
	v_add_f32_e32 v23, v23, v5                                 // 00000058D010: 062E0B17
	s_clause 0x1                                               // 00000058D014: BF850001
	global_load_b128 v[5:8], v[28:29], off                     // 00000058D018: DC5E0000 057C001C
	global_load_b128 v[28:31], v[28:29], off offset:16         // 00000058D020: DC5E0010 1C7C001C
	s_waitcnt vmcnt(1)                                         // 00000058D028: BF8907F7
	v_dot2_f32_bf16 v5, v5, v36, 0                             // 00000058D02C: CC1A4005 1A024905
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000058D034: BF870121
	v_dot2_f32_bf16 v5, v6, v37, v5                            // 00000058D038: CC1A4005 1C164B06
	v_mov_b32_e32 v6, v2                                       // 00000058D040: 7E0C0302
	v_dot2_f32_bf16 v5, v7, v38, v5                            // 00000058D044: CC1A4005 1C164D07
	v_mov_b32_e32 v7, v3                                       // 00000058D04C: 7E0E0303
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000058D050: BF870132
	v_dot2_f32_bf16 v5, v8, v39, v5                            // 00000058D054: CC1A4005 1C164F08
	v_mov_b32_e32 v8, v4                                       // 00000058D05C: 7E100304
	s_waitcnt vmcnt(0)                                         // 00000058D060: BF8903F7
	v_dot2_f32_bf16 v5, v28, v40, v5                           // 00000058D064: CC1A4005 1C16511C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058D06C: BF870091
	v_dot2_f32_bf16 v5, v29, v41, v5                           // 00000058D070: CC1A4005 1C16531D
	v_dot2_f32_bf16 v5, v30, v42, v5                           // 00000058D078: CC1A4005 1C16551E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058D080: BF870091
	v_dot2_f32_bf16 v5, v31, v43, v5                           // 00000058D084: CC1A4005 1C16571F
	v_add_f32_e32 v17, v17, v5                                 // 00000058D08C: 06220B11
	v_mov_b32_e32 v5, v1                                       // 00000058D090: 7E0A0301
	s_and_not1_b32 exec_lo, exec_lo, s15                       // 00000058D094: 917E0F7E
	s_cbranch_execz 33                                         // 00000058D098: BFA50021 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi6ELi32ELi2ELb0EEEvPKhPKtPvll+0x920>
	s_waitcnt vmcnt(1)                                         // 00000058D09C: BF8907F7
	s_delay_alu instid0(VALU_DEP_1)                            // 00000058D0A0: BF870001
	v_dual_mov_b32 v1, v5 :: v_dual_add_nc_u32 v18, 32, v18    // 00000058D0A4: CA200105 011224A0
	s_waitcnt vmcnt(0)                                         // 00000058D0AC: BF8903F7
	.long 0x7e12390d                                           // 00000058D0B0: 7E12390D
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v3, v7             // 00000058D0B4: CA100106 02020107
	v_mov_b32_e32 v4, v8                                       // 00000058D0BC: 7E080308
	s_mov_b32 s17, exec_lo                                     // 00000058D0C0: BE91007E
	v_cmp_ge_i32_e32 vcc_lo, v18, v19                          // 00000058D0C4: 7C8C2712
	.long 0xd4c1007e                                           // 00000058D0C8: D4C1007E
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 00000058D0CC: 02022712
	s_cbranch_execz 65079                                      // 00000058D0D0: BFA5FE37 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi6ELi32ELi2ELb0EEEvPKhPKtPvll+0x1b0>
	v_and_b32_e32 v3, -2, v18                                  // 00000058D0D4: 360624C2
	v_ashrrev_i32_e32 v2, 31, v27                              // 00000058D0D8: 3404369F
	.long 0xd7000001                                           // 00000058D0DC: D7000001
	v_cndmask_b32_e32 v1, v10, v27, vcc_lo                     // 00000058D0E0: 0202370A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000058D0E4: BF870193
	v_ashrrev_i32_e32 v4, 31, v3                               // 00000058D0E8: 3408069F
	v_add_co_ci_u32_e64 v2, null, v11, v2, s0                  // 00000058D0EC: D5207C02 0002050B
	.long 0xd700001c                                           // 00000058D0F4: D700001C
	v_cndmask_b32_e32 v1, v20, v3, vcc_lo                      // 00000058D0F8: 02020714
	s_delay_alu instid0(VALU_DEP_1)                            // 00000058D0FC: BF870001
	v_add_co_ci_u32_e64 v29, null, v21, v4, s0                 // 00000058D100: D5207C1D 00020915
	s_clause 0x1                                               // 00000058D108: BF850001
	global_load_b128 v[1:4], v[1:2], off                       // 00000058D10C: DC5E0000 017C0001
	global_load_d16_b16 v9, v[28:29], off                      // 00000058D114: DC820000 097C001C
	s_branch 65060                                             // 00000058D11C: BFA0FE24 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi6ELi32ELi2ELb0EEEvPKhPKtPvll+0x1b0>
	s_or_b32 exec_lo, exec_lo, s15                             // 00000058D120: 8C7E0F7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000058D124: BF8700B9
	s_or_b32 exec_lo, exec_lo, s1                              // 00000058D128: 8C7E017E
	.long 0xd71f0001                                           // 00000058D12C: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000058D130: 020100C1
	s_mov_b32 s0, exec_lo                                      // 00000058D134: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 00000058D138: 3A040290
	s_waitcnt vmcnt(1)                                         // 00000058D13C: BF8907F7
	v_xor_b32_e32 v8, 8, v1                                    // 00000058D140: 3A100288
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000058D144: BF8701A2
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 00000058D148: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 00000058D14C: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 00000058D150: 7C9810A0
	s_delay_alu instid0(VALU_DEP_2)                            // 00000058D154: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 00000058D158: 30040482
	ds_bpermute_b32 v5, v2, v25                                // 00000058D15C: DACC0000 05001902
	s_waitcnt lgkmcnt(0)                                       // 00000058D164: BF89FC07
	v_add_f32_e32 v5, v25, v5                                  // 00000058D168: 060A0B19
	ds_bpermute_b32 v3, v2, v22                                // 00000058D16C: DACC0000 03001602
	ds_bpermute_b32 v4, v2, v26                                // 00000058D174: DACC0000 04001A02
	ds_bpermute_b32 v6, v2, v24                                // 00000058D17C: DACC0000 06001802
	ds_bpermute_b32 v7, v2, v23                                // 00000058D184: DACC0000 07001702
	ds_bpermute_b32 v2, v2, v17                                // 00000058D18C: DACC0000 02001102
	s_waitcnt lgkmcnt(4)                                       // 00000058D194: BF89FC47
	v_dual_cndmask_b32 v8, v1, v8 :: v_dual_add_f32 v3, v22, v3// 00000058D198: CA481101 08020716
	s_waitcnt lgkmcnt(0)                                       // 00000058D1A0: BF89FC07
	v_dual_add_f32 v7, v23, v7 :: v_dual_add_f32 v2, v17, v2   // 00000058D1A4: C9080F17 07020511
	v_xor_b32_e32 v17, 4, v1                                   // 00000058D1AC: 3A220284
	s_delay_alu instid0(VALU_DEP_1)                            // 00000058D1B0: BF870001
	v_cmp_gt_u32_e32 vcc_lo, 32, v17                           // 00000058D1B4: 7C9822A0
	v_dual_cndmask_b32 v17, v1, v17 :: v_dual_lshlrev_b32 v8, 2, v8// 00000058D1B8: CA622301 11081082
	ds_bpermute_b32 v9, v8, v3                                 // 00000058D1C0: DACC0000 09000308
	s_waitcnt vmcnt(0)                                         // 00000058D1C8: BF8903F7
	ds_bpermute_b32 v13, v8, v7                                // 00000058D1CC: DACC0000 0D000708
	v_add_f32_e32 v4, v26, v4                                  // 00000058D1D4: 0608091A
	v_add_f32_e32 v6, v24, v6                                  // 00000058D1D8: 060C0D18
	ds_bpermute_b32 v11, v8, v5                                // 00000058D1DC: DACC0000 0B000508
	v_lshlrev_b32_e32 v17, 2, v17                              // 00000058D1E4: 30222282
	ds_bpermute_b32 v10, v8, v4                                // 00000058D1E8: DACC0000 0A000408
	s_waitcnt lgkmcnt(3)                                       // 00000058D1F0: BF89FC37
	v_add_f32_e32 v3, v3, v9                                   // 00000058D1F4: 06061303
	ds_bpermute_b32 v12, v8, v6                                // 00000058D1F8: DACC0000 0C000608
	s_waitcnt lgkmcnt(3)                                       // 00000058D200: BF89FC37
	v_add_f32_e32 v7, v7, v13                                  // 00000058D204: 060E1B07
	ds_bpermute_b32 v8, v8, v2                                 // 00000058D208: DACC0000 08000208
	s_waitcnt lgkmcnt(2)                                       // 00000058D210: BF89FC27
	v_dual_add_f32 v5, v5, v11 :: v_dual_add_f32 v4, v4, v10   // 00000058D214: C9081705 05041504
	ds_bpermute_b32 v10, v17, v5                               // 00000058D21C: DACC0000 0A000511
	ds_bpermute_b32 v9, v17, v4                                // 00000058D224: DACC0000 09000411
	s_waitcnt lgkmcnt(3)                                       // 00000058D22C: BF89FC37
	v_add_f32_e32 v6, v6, v12                                  // 00000058D230: 060C1906
	ds_bpermute_b32 v12, v17, v7                               // 00000058D234: DACC0000 0C000711
	s_waitcnt lgkmcnt(3)                                       // 00000058D23C: BF89FC37
	v_add_f32_e32 v2, v2, v8                                   // 00000058D240: 06041102
	ds_bpermute_b32 v8, v17, v3                                // 00000058D244: DACC0000 08000311
	ds_bpermute_b32 v11, v17, v6                               // 00000058D24C: DACC0000 0B000611
	ds_bpermute_b32 v13, v17, v2                               // 00000058D254: DACC0000 0D000211
	v_xor_b32_e32 v17, 2, v1                                   // 00000058D25C: 3A220282
	s_waitcnt lgkmcnt(4)                                       // 00000058D260: BF89FC47
	v_add_f32_e32 v4, v4, v9                                   // 00000058D264: 06081304
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000058D268: BF870132
	v_cmp_gt_u32_e32 vcc_lo, 32, v17                           // 00000058D26C: 7C9822A0
	v_cndmask_b32_e32 v17, v1, v17, vcc_lo                     // 00000058D270: 02222301
	v_add_f32_e32 v5, v5, v10                                  // 00000058D274: 060A1505
	v_lshlrev_b32_e32 v17, 2, v17                              // 00000058D278: 30222282
	s_waitcnt lgkmcnt(1)                                       // 00000058D27C: BF89FC17
	v_dual_add_f32 v3, v3, v8 :: v_dual_add_f32 v6, v6, v11    // 00000058D280: C9081103 03061706
	s_waitcnt lgkmcnt(0)                                       // 00000058D288: BF89FC07
	v_dual_add_f32 v7, v7, v12 :: v_dual_add_f32 v8, v2, v13   // 00000058D28C: C9081907 07081B02
	ds_bpermute_b32 v9, v17, v4                                // 00000058D294: DACC0000 09000411
	ds_bpermute_b32 v2, v17, v3                                // 00000058D29C: DACC0000 02000311
	ds_bpermute_b32 v10, v17, v5                               // 00000058D2A4: DACC0000 0A000511
	ds_bpermute_b32 v11, v17, v6                               // 00000058D2AC: DACC0000 0B000611
	ds_bpermute_b32 v12, v17, v7                               // 00000058D2B4: DACC0000 0C000711
	ds_bpermute_b32 v13, v17, v8                               // 00000058D2BC: DACC0000 0D000811
	v_xor_b32_e32 v17, 1, v1                                   // 00000058D2C4: 3A220281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000058D2C8: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v17                           // 00000058D2CC: 7C9822A0
	v_cndmask_b32_e32 v1, v1, v17, vcc_lo                      // 00000058D2D0: 02022301
	v_lshlrev_b32_e32 v17, 2, v1                               // 00000058D2D4: 30220282
	s_waitcnt lgkmcnt(4)                                       // 00000058D2D8: BF89FC47
	v_dual_add_f32 v1, v3, v2 :: v_dual_add_f32 v2, v4, v9     // 00000058D2DC: C9080503 01021304
	s_waitcnt lgkmcnt(2)                                       // 00000058D2E4: BF89FC27
	v_dual_add_f32 v4, v5, v10 :: v_dual_add_f32 v5, v6, v11   // 00000058D2E8: C9081505 04041706
	s_waitcnt lgkmcnt(1)                                       // 00000058D2F0: BF89FC17
	v_add_f32_e32 v3, v7, v12                                  // 00000058D2F4: 06061907
	s_waitcnt lgkmcnt(0)                                       // 00000058D2F8: BF89FC07
	v_add_f32_e32 v9, v8, v13                                  // 00000058D2FC: 06121B08
	ds_bpermute_b32 v6, v17, v1                                // 00000058D300: DACC0000 06000111
	ds_bpermute_b32 v7, v17, v2                                // 00000058D308: DACC0000 07000211
	ds_bpermute_b32 v10, v17, v4                               // 00000058D310: DACC0000 0A000411
	ds_bpermute_b32 v11, v17, v5                               // 00000058D318: DACC0000 0B000511
	ds_bpermute_b32 v8, v17, v3                                // 00000058D320: DACC0000 08000311
	ds_bpermute_b32 v12, v17, v9                               // 00000058D328: DACC0000 0C000911
	v_cmpx_eq_u32_e32 0, v16                                   // 00000058D330: 7D942080
	s_cbranch_execz 16                                         // 00000058D334: BFA50010 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi6ELi32ELi2ELb0EEEvPKhPKtPvll+0xb78>
	.long 0xd72c000d                                           // 00000058D338: D72C000D
	v_cndmask_b32_e32 v0, v14, v176, vcc_lo                    // 00000058D33C: 0201610E
	s_waitcnt lgkmcnt(0)                                       // 00000058D340: BF89FC07
	v_dual_add_f32 v9, v9, v12 :: v_dual_add_f32 v4, v4, v10   // 00000058D344: C9081909 09041504
	v_dual_add_f32 v5, v5, v11 :: v_dual_add_f32 v8, v3, v8    // 00000058D34C: C9081705 05081103
	v_dual_add_f32 v2, v2, v7 :: v_dual_add_f32 v1, v1, v6     // 00000058D354: C9080F02 02000D01
	s_delay_alu instid0(VALU_DEP_4)                            // 00000058D35C: BF870004
	v_mad_u32_u24 v6, v15, 24, v13                             // 00000058D360: D60B0006 0435310F
	ds_store_2addr_b64 v6, v[1:2], v[4:5] offset1:1            // 00000058D368: D9380100 00040106
	ds_store_b64 v6, v[8:9] offset:16                          // 00000058D370: D9340010 00000806
	s_or_b32 exec_lo, exec_lo, s0                              // 00000058D378: 8C7E007E
	.long 0xd7050001                                           // 00000058D37C: D7050001
	v_cndmask_b32_e32 v1, 0xab, v0, vcc_lo                     // 00000058D380: 020200FF 000000AB
	.long 0x7f063880                                           // 00000058D388: 7F063880
	s_waitcnt lgkmcnt(0)                                       // 00000058D38C: BF89FC07
	s_barrier                                                  // 00000058D390: BFBD0000
	buffer_gl0_inv                                             // 00000058D394: E0AC0000 00000000
	.long 0xd7390003                                           // 00000058D39C: D7390003
	v_cndmask_b32_e32 v1, 10, v1, vcc_lo                       // 00000058D3A0: 0202028A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058D3A4: BF870091
	.long 0xd7000001                                           // 00000058D3A8: D7000001
	v_cndmask_b32_e32 v1, s2, v3, vcc_lo                       // 00000058D3AC: 02020602
	v_add_co_ci_u32_e64 v2, null, s3, 0, s0                    // 00000058D3B0: D5207C02 00010003
	.long 0xd44c0000                                           // 00000058D3B8: D44C0000
	v_cndmask_b32_e32 v1, 24, v0, vcc_lo                       // 00000058D3BC: 02020098
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000058D3C0: BF8704A2
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 00000058D3C4: 7CA8020C
	s_and_b32 s0, s0, vcc_lo                                   // 00000058D3C8: 8B006A00
	s_and_saveexec_b32 s1, s0                                  // 00000058D3CC: BE812000
	s_cbranch_execz 43                                         // 00000058D3D0: BFA5002B <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi6ELi32ELi2ELb0EEEvPKhPKtPvll+0xc80>
	.long 0xd7054000                                           // 00000058D3D4: D7054000
	v_cndmask_b32_e32 v0, v3, v134, vcc_lo                     // 00000058D3D8: 02010D03
	v_mul_u32_u24_e32 v3, 48, v3                               // 00000058D3DC: 160606B0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058D3E0: BF870092
	.long 0xd7041000                                           // 00000058D3E4: D7041000
	v_cndmask_b32_e32 v1, v0, v0, vcc_lo                       // 00000058D3E8: 02020100
	v_and_b32_e32 v0, 0xff, v0                                 // 00000058D3EC: 360000FF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000058D3F4: BF8700B1
	v_lshl_add_u32 v3, v0, 2, v3                               // 00000058D3F8: D6460003 040D0500
	ds_load_2addr_b32 v[6:7], v3 offset1:6                     // 00000058D400: D8DC0600 06000003
	v_mad_u64_u32 v[3:4], null, s12, v0, 0                     // 00000058D408: D6FE7C03 0202000C
	v_mad_u64_u32 v[4:5], null, s13, v0, v[4:5]                // 00000058D410: D6FE7C04 0412000D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000058D418: BF870131
	.long 0xd73c0003                                           // 00000058D41C: D73C0003
	v_cndmask_b32_e32 v1, 1, v3, vcc_lo                        // 00000058D420: 02020681
	s_waitcnt lgkmcnt(0)                                       // 00000058D424: BF89FC07
	v_add_f32_e32 v0, 0, v6                                    // 00000058D428: 06000C80
	.long 0xd7006a03                                           // 00000058D42C: D7006A03
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 00000058D430: 02020608
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000058D434: BF8701B2
	v_add_f32_e32 v5, v0, v7                                   // 00000058D438: 060A0F00
	.long 0xd73c0000                                           // 00000058D43C: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000058D440: 02020281
	v_add_co_ci_u32_e64 v4, null, s9, v4, vcc_lo               // 00000058D444: D5207C04 01AA0809
	v_bfe_u32 v2, v5, 16, 1                                    // 00000058D44C: D6100002 02052105
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058D454: BF870093
	.long 0xd7006a00                                           // 00000058D458: D7006A00
	v_cndmask_b32_e32 v1, v3, v0, vcc_lo                       // 00000058D45C: 02020103
	v_add_co_ci_u32_e64 v1, null, v4, v1, vcc_lo               // 00000058D460: D5207C01 01AA0304
	s_delay_alu instid0(VALU_DEP_3)                            // 00000058D468: BF870003
	v_add3_u32 v2, v5, v2, 0x7fff                              // 00000058D46C: D6550002 03FE0505 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off                    // 00000058D478: DC960000 007C0200
	s_endpgm                                                   // 00000058D480: BFB00000
		...

