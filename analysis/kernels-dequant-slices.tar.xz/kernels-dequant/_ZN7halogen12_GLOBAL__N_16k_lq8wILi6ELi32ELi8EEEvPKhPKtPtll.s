00000000002ea400 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi6ELi32ELi8EEEvPKhPKtPtll>:
; _ZN7halogen12_GLOBAL__N_16k_lq8wILi6ELi32ELi8EEEvPKhPKtPtll():
	s_clause 0x1                                               // 0000002EA400: BF850001
	s_load_b256 s[4:11], s[0:1], null                          // 0000002EA404: F40C0100 F8000000
	s_load_b64 s[12:13], s[0:1], 0x20                          // 0000002EA40C: F4040300 F8000020
	s_mov_b32 s3, 0                                            // 0000002EA414: BE830080
	v_lshrrev_b32_e32 v13, 5, v0                               // 0000002EA418: 321A0085
	v_dual_mov_b32 v7, 0 :: v_dual_and_b32 v14, 31, v0         // 0000002EA41C: CA240080 070E009F
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v12, 0             // 0000002EA424: CA100080 0F0C0080
	v_dual_mov_b32 v5, 0 :: v_dual_mov_b32 v6, 0               // 0000002EA42C: CA100080 05060080
	v_mov_b32_e32 v8, 0                                        // 0000002EA434: 7E100280
	s_waitcnt lgkmcnt(0)                                       // 0000002EA438: BF89FC07
	s_ashr_i32 s0, s11, 31                                     // 0000002EA43C: 86009F0B
	.long 0xd451000e                                           // 0000002EA440: D451000E
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 0000002EA444: 02001802
	s_lshr_b32 s0, s0, 28                                      // 0000002EA448: 85009C00
	v_dual_mov_b32 v1, s4 :: v_dual_mov_b32 v2, s5             // 0000002EA44C: CA100004 01020005
	s_add_u32 s0, s10, s0                                      // 0000002EA454: 8000000A
	s_addc_u32 s1, s11, 0                                      // 0000002EA458: 8201800B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000002EA45C: BF870499
	s_ashr_i64 s[0:1], s[0:1], 4                               // 0000002EA460: 86808400
	s_add_u32 s15, s0, s10                                     // 0000002EA464: 800F0A00
	s_addc_u32 s1, s1, s11                                     // 0000002EA468: 82010B01
	s_and_b32 s14, s14, exec_lo                                // 0000002EA46C: 8B0E7E0E
	s_cselect_b32 s14, s2, 0                                   // 0000002EA470: 980E8002
	s_add_i32 s16, s0, 7                                       // 0000002EA474: 81108700
	v_mad_u64_u32 v[9:10], null, s14, s15, v[1:2]              // 0000002EA478: D6FE7C09 04041E0E
	s_ashr_i32 s17, s16, 31                                    // 0000002EA480: 86119F10
	s_mul_i32 s14, s14, s1                                     // 0000002EA484: 960E010E
	s_lshr_b32 s17, s17, 29                                    // 0000002EA488: 85119D11
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000002EA48C: BF870499
	s_add_i32 s16, s16, s17                                    // 0000002EA490: 81101110
	s_ashr_i32 s4, s16, 3                                      // 0000002EA494: 86048310
	v_add_nc_u32_e32 v10, s14, v10                             // 0000002EA498: 4A14140E
	.long 0xd72c0003                                           // 0000002EA49C: D72C0003
	v_cndmask_b32_e32 v1, s4, v13, vcc_lo                      // 0000002EA4A0: 02021A04
	.long 0xd7006a12                                           // 0000002EA4A4: D7006A12
	v_cndmask_b32_e32 v0, v9, v10, vcc_lo                      // 0000002EA4A8: 02001509
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002EA4AC: BF870191
	v_add_co_ci_u32_e64 v19, null, s11, v10, vcc_lo            // 0000002EA4B0: D5207C13 01AA140B
	v_add_nc_u32_e32 v1, s4, v3                                // 0000002EA4B8: 4A020604
	v_add_nc_u32_e32 v16, v3, v14                              // 0000002EA4BC: 4A201D03
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002EA4C0: BF870112
	v_min_i32_e32 v17, s0, v1                                  // 0000002EA4C4: 22220200
	v_lshlrev_b32_e32 v11, 4, v16                              // 0000002EA4C8: 30162084
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002EA4CC: BF870002
	v_cmp_lt_i32_e32 vcc_lo, v16, v17                          // 0000002EA4D0: 7C822310
	s_and_saveexec_b32 s1, vcc_lo                              // 0000002EA4D4: BE81206A
	s_cbranch_execz 19                                         // 0000002EA4D8: BFA50013 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi6ELi32ELi8EEEvPKhPKtPtll+0x128>
	v_lshlrev_b32_e32 v1, 4, v16                               // 0000002EA4DC: 30022084
	v_and_b32_e32 v3, -4, v16                                  // 0000002EA4E0: 360620C4
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002EA4E4: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000002EA4E8: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000002EA4EC: 3408069F
	.long 0xd7000001                                           // 0000002EA4F0: D7000001
	v_cndmask_b32_e32 v1, v9, v1, vcc_lo                       // 0000002EA4F4: 02020309
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002EA4F8: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v10, v2, s0                  // 0000002EA4FC: D5207C02 0002050A
	.long 0xd7000003                                           // 0000002EA504: D7000003
	v_cndmask_b32_e32 v1, v18, v3, vcc_lo                      // 0000002EA508: 02020712
	v_add_co_ci_u32_e64 v4, null, v19, v4, s0                  // 0000002EA50C: D5207C04 00020913
	s_clause 0x1                                               // 0000002EA514: BF850001
	global_load_b128 v[5:8], v[1:2], off                       // 0000002EA518: DC5E0000 057C0001
	global_load_b32 v12, v[3:4], off                           // 0000002EA520: DC520000 0C7C0003
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002EA528: 8C7E017E
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v22, 0             // 0000002EA52C: CA100080 15160080
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v24, 0             // 0000002EA534: CA100080 17180080
	v_mov_b32_e32 v20, 0                                       // 0000002EA53C: 7E280280
	s_and_saveexec_b32 s1, vcc_lo                              // 0000002EA540: BE81206A
	s_cbranch_execz 456                                        // 0000002EA544: BFA501C8 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi6ELi32ELi8EEEvPKhPKtPtll+0x868>
	v_dual_mov_b32 v20, 0 :: v_dual_add_nc_u32 v25, 0x200, v11 // 0000002EA548: CA200080 141816FF 00000200
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v23, 0             // 0000002EA554: CA100080 18160080
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v21, 0             // 0000002EA55C: CA100080 16140080
	s_waitcnt vmcnt(0)                                         // 0000002EA564: BF8903F7
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v26, v12           // 0000002EA568: CA100080 0F1A010C
	s_mul_i32 s0, s11, 6                                       // 0000002EA570: 9600860B
	s_mul_hi_u32 s14, s10, 6                                   // 0000002EA574: 968E860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 0000002EA578: 8484820A
	s_add_i32 s14, s14, s0                                     // 0000002EA57C: 810E000E
	s_mul_i32 s16, s10, 6                                      // 0000002EA580: 9610860A
	s_mov_b32 s15, 0                                           // 0000002EA584: BE8F0080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 0000002EA588: 848A810A
	s_branch 407                                               // 0000002EA58C: BFA00197 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi6ELi32ELi8EEEvPKhPKtPtll+0x7ec>
	s_or_b32 exec_lo, exec_lo, s17                             // 0000002EA590: 8C7E117E
	v_cvt_f32_ubyte0_e32 v27, v5                               // 0000002EA594: 7E362305
	s_and_b32 s0, exec_lo, vcc_lo                              // 0000002EA598: 8B006A7E
	v_add_nc_u32_e32 v25, 0x200, v25                           // 0000002EA59C: 4A3232FF 00000200
	s_or_b32 s15, s0, s15                                      // 0000002EA5A4: 8C0F0F00
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EA5A8: BF870092
	v_fma_mix_f32 v27, v27, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002EA5AC: CC20601B 1432191B
	v_bfe_u32 v28, v27, 16, 1                                  // 0000002EA5B4: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002EA5BC: BF870121
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000002EA5C0: D655001B 03FE391B 00007FFF
	.long 0x7f383880                                           // 0000002EA5CC: 7F383880
	.long 0x7e38399b                                           // 0000002EA5D0: 7E38399B
	v_cvt_f32_ubyte1_e32 v27, v5                               // 0000002EA5D4: 7E362505
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EA5D8: BF870091
	v_fma_mix_f32 v27, v27, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002EA5DC: CC20601B 1432191B
	v_bfe_u32 v29, v27, 16, 1                                  // 0000002EA5E4: D610001D 0205211B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000002EA5EC: BF8701B1
	v_add3_u32 v27, v27, v29, 0x7fff                           // 0000002EA5F0: D655001B 03FE3B1B 00007FFF
	v_cvt_f32_ubyte2_e32 v29, v5                               // 0000002EA5FC: 7E3A2705
	v_cvt_f32_ubyte3_e32 v5, v5                                // 0000002EA600: 7E0A2905
	v_and_or_b32 v35, 0xffff0000, v27, v28                     // 0000002EA604: D6570023 047236FF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002EA610: BF870193
	v_fma_mix_f32 v29, v29, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002EA614: CC20601D 1432191D
	v_fma_mix_f32 v5, v5, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002EA61C: CC206005 14321905
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EA624: BF870092
	v_bfe_u32 v30, v29, 16, 1                                  // 0000002EA628: D610001E 0205211D
	v_add3_u32 v29, v29, v30, 0x7fff                           // 0000002EA630: D655001D 03FE3D1D 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002EA63C: BF870113
	v_bfe_u32 v30, v5, 16, 1                                   // 0000002EA640: D610001E 02052105
	.long 0x7e3a399d                                           // 0000002EA648: 7E3A399D
	.long 0x7f3a399c                                           // 0000002EA64C: 7F3A399C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EA650: BF870093
	v_add3_u32 v5, v5, v30, 0x7fff                             // 0000002EA654: D6550005 03FE3D05 00007FFF
	v_and_or_b32 v36, 0xffff0000, v5, v29                      // 0000002EA660: D6570024 04760AFF FFFF0000
	v_cvt_f32_ubyte0_e32 v5, v6                                // 0000002EA66C: 7E0A2306
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EA670: BF870091
	v_fma_mix_f32 v5, v5, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002EA674: CC206005 14321905
	v_bfe_u32 v27, v5, 16, 1                                   // 0000002EA67C: D610001B 02052105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EA684: BF870091
	v_add3_u32 v5, v5, v27, 0x7fff                             // 0000002EA688: D6550005 03FE3705 00007FFF
	.long 0x7e383985                                           // 0000002EA694: 7E383985
	v_cvt_f32_ubyte1_e32 v5, v6                                // 0000002EA698: 7E0A2506
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EA69C: BF870091
	v_fma_mix_f32 v5, v5, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002EA6A0: CC206005 14321905
	v_bfe_u32 v27, v5, 16, 1                                   // 0000002EA6A8: D610001B 02052105
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000002EA6B0: BF8701B1
	v_add3_u32 v5, v5, v27, 0x7fff                             // 0000002EA6B4: D6550005 03FE3705 00007FFF
	v_cvt_f32_ubyte2_e32 v27, v6                               // 0000002EA6C0: 7E362706
	v_cvt_f32_ubyte3_e32 v6, v6                                // 0000002EA6C4: 7E0C2906
	v_and_or_b32 v37, 0xffff0000, v5, v28                      // 0000002EA6C8: D6570025 04720AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002EA6D4: BF870193
	v_fma_mix_f32 v27, v27, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002EA6D8: CC20601B 1432191B
	v_fma_mix_f32 v6, v6, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002EA6E0: CC206006 14321906
	v_cvt_f32_ubyte0_e32 v5, v7                                // 0000002EA6E8: 7E0A2307
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002EA6EC: BF870113
	v_bfe_u32 v29, v27, 16, 1                                  // 0000002EA6F0: D610001D 0205211B
	v_fma_mix_f32 v5, v5, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002EA6F8: CC206005 14321905
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002EA700: BF870122
	v_add3_u32 v27, v27, v29, 0x7fff                           // 0000002EA704: D655001B 03FE3B1B 00007FFF
	v_bfe_u32 v29, v6, 16, 1                                   // 0000002EA710: D610001D 02052106
	.long 0x7e36399b                                           // 0000002EA718: 7E36399B
	.long 0x7f36399c                                           // 0000002EA71C: 7F36399C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EA720: BF870093
	v_add3_u32 v6, v6, v29, 0x7fff                             // 0000002EA724: D6550006 03FE3B06 00007FFF
	v_and_or_b32 v38, 0xffff0000, v6, v27                      // 0000002EA730: D6570026 046E0CFF FFFF0000
	v_bfe_u32 v6, v5, 16, 1                                    // 0000002EA73C: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EA744: BF870091
	v_add3_u32 v5, v5, v6, 0x7fff                              // 0000002EA748: D6550005 03FE0D05 00007FFF
	.long 0x7e383985                                           // 0000002EA754: 7E383985
	v_cvt_f32_ubyte1_e32 v5, v7                                // 0000002EA758: 7E0A2507
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EA75C: BF870091
	v_fma_mix_f32 v5, v5, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002EA760: CC206005 14321905
	v_bfe_u32 v6, v5, 16, 1                                    // 0000002EA768: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000002EA770: BF8701B1
	v_add3_u32 v5, v5, v6, 0x7fff                              // 0000002EA774: D6550005 03FE0D05 00007FFF
	v_cvt_f32_ubyte2_e32 v6, v7                                // 0000002EA780: 7E0C2707
	v_cvt_f32_ubyte3_e32 v7, v7                                // 0000002EA784: 7E0E2907
	v_and_or_b32 v39, 0xffff0000, v5, v28                      // 0000002EA788: D6570027 04720AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002EA794: BF870193
	v_fma_mix_f32 v6, v6, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002EA798: CC206006 14321906
	v_fma_mix_f32 v7, v7, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002EA7A0: CC206007 14321907
	v_cvt_f32_ubyte0_e32 v5, v8                                // 0000002EA7A8: 7E0A2308
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002EA7AC: BF870113
	v_bfe_u32 v27, v6, 16, 1                                   // 0000002EA7B0: D610001B 02052106
	v_fma_mix_f32 v5, v5, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002EA7B8: CC206005 14321905
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002EA7C0: BF870122
	v_add3_u32 v6, v6, v27, 0x7fff                             // 0000002EA7C4: D6550006 03FE3706 00007FFF
	v_bfe_u32 v27, v7, 16, 1                                   // 0000002EA7D0: D610001B 02052107
	.long 0x7e0c3986                                           // 0000002EA7D8: 7E0C3986
	.long 0x7f0c399c                                           // 0000002EA7DC: 7F0C399C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EA7E0: BF870093
	v_add3_u32 v7, v7, v27, 0x7fff                             // 0000002EA7E4: D6550007 03FE3707 00007FFF
	v_and_or_b32 v40, 0xffff0000, v7, v6                       // 0000002EA7F0: D6570028 041A0EFF FFFF0000
	v_bfe_u32 v6, v5, 16, 1                                    // 0000002EA7FC: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EA804: BF870091
	v_add3_u32 v5, v5, v6, 0x7fff                              // 0000002EA808: D6550005 03FE0D05 00007FFF
	.long 0x7e383985                                           // 0000002EA814: 7E383985
	v_cvt_f32_ubyte1_e32 v5, v8                                // 0000002EA818: 7E0A2508
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EA81C: BF870091
	v_fma_mix_f32 v5, v5, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002EA820: CC206005 14321905
	v_bfe_u32 v6, v5, 16, 1                                    // 0000002EA828: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002EA830: BF870121
	v_add3_u32 v5, v5, v6, 0x7fff                              // 0000002EA834: D6550005 03FE0D05 00007FFF
	v_cvt_f32_ubyte2_e32 v6, v8                                // 0000002EA840: 7E0C2708
	v_and_or_b32 v41, 0xffff0000, v5, v28                      // 0000002EA844: D6570029 04720AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EA850: BF870092
	v_fma_mix_f32 v6, v6, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002EA854: CC206006 14321906
	v_bfe_u32 v7, v6, 16, 1                                    // 0000002EA85C: D6100007 02052106
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002EA864: BF870121
	v_add3_u32 v6, v6, v7, 0x7fff                              // 0000002EA868: D6550006 03FE0F06 00007FFF
	v_cvt_f32_ubyte3_e32 v7, v8                                // 0000002EA874: 7E0E2908
	.long 0x7e0c3986                                           // 0000002EA878: 7E0C3986
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000002EA87C: BF8701B2
	v_fma_mix_f32 v7, v7, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002EA880: CC206007 14321907
	.long 0x7f0c399c                                           // 0000002EA888: 7F0C399C
	v_ashrrev_i32_e32 v12, 31, v11                             // 0000002EA88C: 3418169F
	v_bfe_u32 v8, v7, 16, 1                                    // 0000002EA890: D6100008 02052107
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EA898: BF870091
	v_add3_u32 v7, v7, v8, 0x7fff                              // 0000002EA89C: D6550007 03FE1107 00007FFF
	v_and_or_b32 v42, 0xffff0000, v7, v6                       // 0000002EA8A8: D657002A 041A0EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000002EA8B4: BF870134
	.long 0xd73c0005                                           // 0000002EA8B8: D73C0005
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 0000002EA8BC: 02021681
	s_waitcnt vmcnt(0)                                         // 0000002EA8C0: BF8903F7
	v_dual_mov_b32 v12, v26 :: v_dual_add_nc_u32 v11, 0x200, v11// 0000002EA8C4: CA20011A 0C0A16FF 00000200
	.long 0xd7006a1f                                           // 0000002EA8D0: D7006A1F
	v_cndmask_b32_e32 v1, s6, v5, vcc_lo                       // 0000002EA8D4: 02020A06
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002EA8D8: BF870001
	v_add_co_ci_u32_e64 v32, null, s7, v6, vcc_lo              // 0000002EA8DC: D5207C20 01AA0C07
	s_clause 0x1                                               // 0000002EA8E4: BF850001
	global_load_b128 v[5:8], v[31:32], off                     // 0000002EA8E8: DC5E0000 057C001F
	global_load_b128 v[27:30], v[31:32], off offset:16         // 0000002EA8F0: DC5E0010 1B7C001F
	s_waitcnt vmcnt(1)                                         // 0000002EA8F8: BF8907F7
	v_dot2_f32_bf16 v5, v5, v35, 0                             // 0000002EA8FC: CC1A4005 1A024705
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EA904: BF870091
	v_dot2_f32_bf16 v5, v6, v36, v5                            // 0000002EA908: CC1A4005 1C164906
	v_dot2_f32_bf16 v5, v7, v37, v5                            // 0000002EA910: CC1A4005 1C164B07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002EA918: BF8700A1
	v_dot2_f32_bf16 v5, v8, v38, v5                            // 0000002EA91C: CC1A4005 1C164D08
	s_waitcnt vmcnt(0)                                         // 0000002EA924: BF8903F7
	v_dot2_f32_bf16 v5, v27, v39, v5                           // 0000002EA928: CC1A4005 1C164F1B
	.long 0xd7006a1b                                           // 0000002EA930: D7006A1B
	v_cndmask_b32_e32 v0, v31, v10, vcc_lo                     // 0000002EA934: 0200151F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000002EA938: BF8701B2
	v_dot2_f32_bf16 v5, v28, v40, v5                           // 0000002EA93C: CC1A4005 1C16511C
	v_add_co_ci_u32_e64 v28, null, s11, v32, vcc_lo            // 0000002EA944: D5207C1C 01AA400B
	.long 0xd7006a21                                           // 0000002EA94C: D7006A21
	v_cndmask_b32_e32 v0, v31, v4, vcc_lo                      // 0000002EA950: 0200091F
	v_dot2_f32_bf16 v5, v29, v41, v5                           // 0000002EA954: CC1A4005 1C16531D
	v_add_co_ci_u32_e64 v34, null, s5, v32, vcc_lo             // 0000002EA95C: D5207C22 01AA4005
	.long 0xd7006a1f                                           // 0000002EA964: D7006A1F
	v_cndmask_b32_e32 v0, v31, v16, vcc_lo                     // 0000002EA968: 0200211F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002EA96C: BF870123
	v_dot2_f32_bf16 v5, v30, v42, v5                           // 0000002EA970: CC1A4005 1C16551E
	v_add_co_ci_u32_e64 v32, null, s14, v32, vcc_lo            // 0000002EA978: D5207C20 01AA400E
	v_add_f32_e32 v20, v20, v5                                 // 0000002EA980: 06280B14
	s_clause 0x1                                               // 0000002EA984: BF850001
	global_load_b128 v[5:8], v[27:28], off                     // 0000002EA988: DC5E0000 057C001B
	global_load_b128 v[27:30], v[27:28], off offset:16         // 0000002EA990: DC5E0010 1B7C001B
	s_waitcnt vmcnt(1)                                         // 0000002EA998: BF8907F7
	v_dot2_f32_bf16 v5, v5, v35, 0                             // 0000002EA99C: CC1A4005 1A024705
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EA9A4: BF870091
	v_dot2_f32_bf16 v5, v6, v36, v5                            // 0000002EA9A8: CC1A4005 1C164906
	v_dot2_f32_bf16 v5, v7, v37, v5                            // 0000002EA9B0: CC1A4005 1C164B07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002EA9B8: BF8700A1
	v_dot2_f32_bf16 v5, v8, v38, v5                            // 0000002EA9BC: CC1A4005 1C164D08
	s_waitcnt vmcnt(0)                                         // 0000002EA9C4: BF8903F7
	v_dot2_f32_bf16 v5, v27, v39, v5                           // 0000002EA9C8: CC1A4005 1C164F1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EA9D0: BF870091
	v_dot2_f32_bf16 v5, v28, v40, v5                           // 0000002EA9D4: CC1A4005 1C16511C
	v_dot2_f32_bf16 v5, v29, v41, v5                           // 0000002EA9DC: CC1A4005 1C16531D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EA9E4: BF870091
	v_dot2_f32_bf16 v5, v30, v42, v5                           // 0000002EA9E8: CC1A4005 1C16551E
	v_add_f32_e32 v24, v24, v5                                 // 0000002EA9F0: 06300B18
	s_clause 0x1                                               // 0000002EA9F4: BF850001
	global_load_b128 v[5:8], v[33:34], off                     // 0000002EA9F8: DC5E0000 057C0021
	global_load_b128 v[27:30], v[33:34], off offset:16         // 0000002EAA00: DC5E0010 1B7C0021
	s_waitcnt vmcnt(1)                                         // 0000002EAA08: BF8907F7
	v_dot2_f32_bf16 v5, v5, v35, 0                             // 0000002EAA0C: CC1A4005 1A024705
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EAA14: BF870091
	v_dot2_f32_bf16 v5, v6, v36, v5                            // 0000002EAA18: CC1A4005 1C164906
	v_dot2_f32_bf16 v5, v7, v37, v5                            // 0000002EAA20: CC1A4005 1C164B07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002EAA28: BF8700A1
	v_dot2_f32_bf16 v5, v8, v38, v5                            // 0000002EAA2C: CC1A4005 1C164D08
	s_waitcnt vmcnt(0)                                         // 0000002EAA34: BF8903F7
	v_dot2_f32_bf16 v5, v27, v39, v5                           // 0000002EAA38: CC1A4005 1C164F1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EAA40: BF870091
	v_dot2_f32_bf16 v5, v28, v40, v5                           // 0000002EAA44: CC1A4005 1C16511C
	v_dot2_f32_bf16 v5, v29, v41, v5                           // 0000002EAA4C: CC1A4005 1C16531D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EAA54: BF870091
	v_dot2_f32_bf16 v5, v30, v42, v5                           // 0000002EAA58: CC1A4005 1C16551E
	v_add_f32_e32 v23, v23, v5                                 // 0000002EAA60: 062E0B17
	s_clause 0x1                                               // 0000002EAA64: BF850001
	global_load_b128 v[5:8], v[31:32], off                     // 0000002EAA68: DC5E0000 057C001F
	global_load_b128 v[27:30], v[31:32], off offset:16         // 0000002EAA70: DC5E0010 1B7C001F
	s_waitcnt vmcnt(1)                                         // 0000002EAA78: BF8907F7
	v_dot2_f32_bf16 v5, v5, v35, 0                             // 0000002EAA7C: CC1A4005 1A024705
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EAA84: BF870091
	v_dot2_f32_bf16 v5, v6, v36, v5                            // 0000002EAA88: CC1A4005 1C164906
	v_dot2_f32_bf16 v5, v7, v37, v5                            // 0000002EAA90: CC1A4005 1C164B07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002EAA98: BF8700A1
	v_dot2_f32_bf16 v5, v8, v38, v5                            // 0000002EAA9C: CC1A4005 1C164D08
	s_waitcnt vmcnt(0)                                         // 0000002EAAA4: BF8903F7
	v_dot2_f32_bf16 v5, v27, v39, v5                           // 0000002EAAA8: CC1A4005 1C164F1B
	.long 0xd7006a1b                                           // 0000002EAAB0: D7006A1B
	v_cndmask_b32_e32 v0, v33, v4, vcc_lo                      // 0000002EAAB4: 02000921
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002EAAB8: BF870122
	v_dot2_f32_bf16 v5, v28, v40, v5                           // 0000002EAABC: CC1A4005 1C16511C
	v_add_co_ci_u32_e64 v28, null, s5, v34, vcc_lo             // 0000002EAAC4: D5207C1C 01AA4405
	v_dot2_f32_bf16 v5, v29, v41, v5                           // 0000002EAACC: CC1A4005 1C16531D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EAAD4: BF870091
	v_dot2_f32_bf16 v5, v30, v42, v5                           // 0000002EAAD8: CC1A4005 1C16551E
	v_add_f32_e32 v22, v22, v5                                 // 0000002EAAE0: 062C0B16
	s_clause 0x1                                               // 0000002EAAE4: BF850001
	global_load_b128 v[5:8], v[27:28], off                     // 0000002EAAE8: DC5E0000 057C001B
	global_load_b128 v[27:30], v[27:28], off offset:16         // 0000002EAAF0: DC5E0010 1B7C001B
	s_waitcnt vmcnt(1)                                         // 0000002EAAF8: BF8907F7
	v_dot2_f32_bf16 v5, v5, v35, 0                             // 0000002EAAFC: CC1A4005 1A024705
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EAB04: BF870091
	v_dot2_f32_bf16 v5, v6, v36, v5                            // 0000002EAB08: CC1A4005 1C164906
	v_dot2_f32_bf16 v5, v7, v37, v5                            // 0000002EAB10: CC1A4005 1C164B07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002EAB18: BF8700A1
	v_dot2_f32_bf16 v5, v8, v38, v5                            // 0000002EAB1C: CC1A4005 1C164D08
	s_waitcnt vmcnt(0)                                         // 0000002EAB24: BF8903F7
	v_dot2_f32_bf16 v5, v27, v39, v5                           // 0000002EAB28: CC1A4005 1C164F1B
	.long 0xd7006a1b                                           // 0000002EAB30: D7006A1B
	v_cndmask_b32_e32 v0, v31, v4, vcc_lo                      // 0000002EAB34: 0200091F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002EAB38: BF870122
	v_dot2_f32_bf16 v5, v28, v40, v5                           // 0000002EAB3C: CC1A4005 1C16511C
	v_add_co_ci_u32_e64 v28, null, s5, v32, vcc_lo             // 0000002EAB44: D5207C1C 01AA4005
	v_dot2_f32_bf16 v5, v29, v41, v5                           // 0000002EAB4C: CC1A4005 1C16531D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EAB54: BF870091
	v_dot2_f32_bf16 v5, v30, v42, v5                           // 0000002EAB58: CC1A4005 1C16551E
	v_add_f32_e32 v21, v21, v5                                 // 0000002EAB60: 062A0B15
	s_clause 0x1                                               // 0000002EAB64: BF850001
	global_load_b128 v[5:8], v[27:28], off                     // 0000002EAB68: DC5E0000 057C001B
	global_load_b128 v[27:30], v[27:28], off offset:16         // 0000002EAB70: DC5E0010 1B7C001B
	s_waitcnt vmcnt(1)                                         // 0000002EAB78: BF8907F7
	v_dot2_f32_bf16 v5, v5, v35, 0                             // 0000002EAB7C: CC1A4005 1A024705
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002EAB84: BF870121
	v_dot2_f32_bf16 v5, v6, v36, v5                            // 0000002EAB88: CC1A4005 1C164906
	v_mov_b32_e32 v6, v2                                       // 0000002EAB90: 7E0C0302
	v_dot2_f32_bf16 v5, v7, v37, v5                            // 0000002EAB94: CC1A4005 1C164B07
	v_mov_b32_e32 v7, v3                                       // 0000002EAB9C: 7E0E0303
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000002EABA0: BF870132
	v_dot2_f32_bf16 v5, v8, v38, v5                            // 0000002EABA4: CC1A4005 1C164D08
	v_mov_b32_e32 v8, v4                                       // 0000002EABAC: 7E100304
	s_waitcnt vmcnt(0)                                         // 0000002EABB0: BF8903F7
	v_dot2_f32_bf16 v5, v27, v39, v5                           // 0000002EABB4: CC1A4005 1C164F1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EABBC: BF870091
	v_dot2_f32_bf16 v5, v28, v40, v5                           // 0000002EABC0: CC1A4005 1C16511C
	v_dot2_f32_bf16 v5, v29, v41, v5                           // 0000002EABC8: CC1A4005 1C16531D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EABD0: BF870091
	v_dot2_f32_bf16 v5, v30, v42, v5                           // 0000002EABD4: CC1A4005 1C16551E
	v_add_f32_e32 v15, v15, v5                                 // 0000002EABDC: 061E0B0F
	v_mov_b32_e32 v5, v1                                       // 0000002EABE0: 7E0A0301
	s_and_not1_b32 exec_lo, exec_lo, s15                       // 0000002EABE4: 917E0F7E
	s_cbranch_execz 30                                         // 0000002EABE8: BFA5001E <_ZN7halogen12_GLOBAL__N_16k_lq8wILi6ELi32ELi8EEEvPKhPKtPtll+0x864>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000002EABEC: BF8701C1
	v_dual_mov_b32 v1, v5 :: v_dual_add_nc_u32 v16, 32, v16    // 0000002EABF0: CA200105 011020A0
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v3, v7             // 0000002EABF8: CA100106 02020107
	v_mov_b32_e32 v4, v8                                       // 0000002EAC00: 7E080308
	s_mov_b32 s17, exec_lo                                     // 0000002EAC04: BE91007E
	v_cmp_ge_i32_e32 vcc_lo, v16, v17                          // 0000002EAC08: 7C8C2310
	.long 0xd4c1007e                                           // 0000002EAC0C: D4C1007E
	v_cndmask_b32_e32 v1, v16, v17, vcc_lo                     // 0000002EAC10: 02022310
	s_cbranch_execz 65118                                      // 0000002EAC14: BFA5FE5E <_ZN7halogen12_GLOBAL__N_16k_lq8wILi6ELi32ELi8EEEvPKhPKtPtll+0x190>
	v_and_b32_e32 v3, -4, v16                                  // 0000002EAC18: 360620C4
	v_ashrrev_i32_e32 v2, 31, v25                              // 0000002EAC1C: 3404329F
	.long 0xd7000001                                           // 0000002EAC20: D7000001
	v_cndmask_b32_e32 v1, v9, v25, vcc_lo                      // 0000002EAC24: 02023309
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002EAC28: BF870193
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000002EAC2C: 3408069F
	v_add_co_ci_u32_e64 v2, null, v10, v2, s0                  // 0000002EAC30: D5207C02 0002050A
	.long 0xd700001a                                           // 0000002EAC38: D700001A
	v_cndmask_b32_e32 v1, v18, v3, vcc_lo                      // 0000002EAC3C: 02020712
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002EAC40: BF870001
	v_add_co_ci_u32_e64 v27, null, v19, v4, s0                 // 0000002EAC44: D5207C1B 00020913
	s_clause 0x1                                               // 0000002EAC4C: BF850001
	global_load_b128 v[1:4], v[1:2], off                       // 0000002EAC50: DC5E0000 017C0001
	global_load_b32 v26, v[26:27], off                         // 0000002EAC58: DC520000 1A7C001A
	s_branch 65099                                             // 0000002EAC60: BFA0FE4B <_ZN7halogen12_GLOBAL__N_16k_lq8wILi6ELi32ELi8EEEvPKhPKtPtll+0x190>
	s_or_b32 exec_lo, exec_lo, s15                             // 0000002EAC64: 8C7E0F7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002EAC68: BF8700B9
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002EAC6C: 8C7E017E
	.long 0xd71f0001                                           // 0000002EAC70: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000002EAC74: 020100C1
	s_mov_b32 s0, exec_lo                                      // 0000002EAC78: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 0000002EAC7C: 3A040290
	s_waitcnt vmcnt(1)                                         // 0000002EAC80: BF8907F7
	v_xor_b32_e32 v8, 8, v1                                    // 0000002EAC84: 3A100288
	v_xor_b32_e32 v16, 4, v1                                   // 0000002EAC88: 3A200284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000002EAC8C: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000002EAC90: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 0000002EAC94: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 0000002EAC98: 7C9810A0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002EAC9C: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000002EACA0: 30040482
	ds_bpermute_b32 v5, v2, v23                                // 0000002EACA4: DACC0000 05001702
	s_waitcnt lgkmcnt(0)                                       // 0000002EACAC: BF89FC07
	v_add_f32_e32 v5, v23, v5                                  // 0000002EACB0: 060A0B17
	ds_bpermute_b32 v3, v2, v20                                // 0000002EACB4: DACC0000 03001402
	ds_bpermute_b32 v7, v2, v21                                // 0000002EACBC: DACC0000 07001502
	ds_bpermute_b32 v4, v2, v24                                // 0000002EACC4: DACC0000 04001802
	ds_bpermute_b32 v6, v2, v22                                // 0000002EACCC: DACC0000 06001602
	ds_bpermute_b32 v2, v2, v15                                // 0000002EACD4: DACC0000 02000F02
	s_waitcnt lgkmcnt(4)                                       // 0000002EACDC: BF89FC47
	v_dual_add_f32 v3, v20, v3 :: v_dual_cndmask_b32 v8, v1, v8// 0000002EACE0: C9120714 03081101
	v_cmp_gt_u32_e32 vcc_lo, 32, v16                           // 0000002EACE8: 7C9820A0
	s_waitcnt lgkmcnt(0)                                       // 0000002EACEC: BF89FC07
	v_dual_add_f32 v7, v21, v7 :: v_dual_add_f32 v2, v15, v2   // 0000002EACF0: C9080F15 0702050F
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002EACF8: BF870003
	v_lshlrev_b32_e32 v8, 2, v8                                // 0000002EACFC: 30101082
	v_cndmask_b32_e32 v16, v1, v16, vcc_lo                     // 0000002EAD00: 02202101
	ds_bpermute_b32 v11, v8, v5                                // 0000002EAD04: DACC0000 0B000508
	v_add_f32_e32 v4, v24, v4                                  // 0000002EAD0C: 06080918
	ds_bpermute_b32 v15, v8, v7                                // 0000002EAD10: DACC0000 0F000708
	ds_bpermute_b32 v9, v8, v3                                 // 0000002EAD18: DACC0000 09000308
	s_waitcnt lgkmcnt(2)                                       // 0000002EAD20: BF89FC27
	v_dual_add_f32 v6, v22, v6 :: v_dual_add_f32 v5, v5, v11   // 0000002EAD24: C9080D16 06041705
	ds_bpermute_b32 v10, v8, v4                                // 0000002EAD2C: DACC0000 0A000408
	s_waitcnt lgkmcnt(2)                                       // 0000002EAD34: BF89FC27
	v_dual_add_f32 v7, v7, v15 :: v_dual_lshlrev_b32 v16, 2, v16// 0000002EAD38: C9221F07 07102082
	s_waitcnt vmcnt(0)                                         // 0000002EAD40: BF8903F7
	ds_bpermute_b32 v12, v8, v6                                // 0000002EAD44: DACC0000 0C000608
	ds_bpermute_b32 v8, v8, v2                                 // 0000002EAD4C: DACC0000 08000208
	s_waitcnt lgkmcnt(2)                                       // 0000002EAD54: BF89FC27
	v_dual_add_f32 v3, v3, v9 :: v_dual_add_f32 v4, v4, v10    // 0000002EAD58: C9081303 03041504
	ds_bpermute_b32 v10, v16, v5                               // 0000002EAD60: DACC0000 0A000510
	s_waitcnt lgkmcnt(0)                                       // 0000002EAD68: BF89FC07
	v_dual_add_f32 v2, v2, v8 :: v_dual_add_f32 v5, v5, v10    // 0000002EAD6C: C9081102 02041505
	ds_bpermute_b32 v8, v16, v3                                // 0000002EAD74: DACC0000 08000310
	ds_bpermute_b32 v15, v16, v2                               // 0000002EAD7C: DACC0000 0F000210
	s_waitcnt lgkmcnt(0)                                       // 0000002EAD84: BF89FC07
	v_dual_add_f32 v3, v3, v8 :: v_dual_add_f32 v8, v2, v15    // 0000002EAD88: C9081103 03081F02
	v_add_f32_e32 v6, v6, v12                                  // 0000002EAD90: 060C1906
	ds_bpermute_b32 v9, v16, v4                                // 0000002EAD94: DACC0000 09000410
	ds_bpermute_b32 v12, v16, v7                               // 0000002EAD9C: DACC0000 0C000710
	ds_bpermute_b32 v11, v16, v6                               // 0000002EADA4: DACC0000 0B000610
	v_xor_b32_e32 v16, 2, v1                                   // 0000002EADAC: 3A200282
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002EADB0: BF870001
	v_cmp_gt_u32_e32 vcc_lo, 32, v16                           // 0000002EADB4: 7C9820A0
	s_waitcnt lgkmcnt(1)                                       // 0000002EADB8: BF89FC17
	v_dual_add_f32 v4, v4, v9 :: v_dual_add_f32 v7, v7, v12    // 0000002EADBC: C9081304 04061907
	s_waitcnt lgkmcnt(0)                                       // 0000002EADC4: BF89FC07
	v_add_f32_e32 v6, v6, v11                                  // 0000002EADC8: 060C1706
	v_cndmask_b32_e32 v16, v1, v16, vcc_lo                     // 0000002EADCC: 02202101
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002EADD0: BF870001
	v_lshlrev_b32_e32 v16, 2, v16                              // 0000002EADD4: 30202082
	ds_bpermute_b32 v2, v16, v3                                // 0000002EADD8: DACC0000 02000310
	ds_bpermute_b32 v9, v16, v4                                // 0000002EADE0: DACC0000 09000410
	ds_bpermute_b32 v10, v16, v5                               // 0000002EADE8: DACC0000 0A000510
	ds_bpermute_b32 v11, v16, v6                               // 0000002EADF0: DACC0000 0B000610
	ds_bpermute_b32 v12, v16, v7                               // 0000002EADF8: DACC0000 0C000710
	ds_bpermute_b32 v15, v16, v8                               // 0000002EAE00: DACC0000 0F000810
	v_xor_b32_e32 v16, 1, v1                                   // 0000002EAE08: 3A200281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002EAE0C: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v16                           // 0000002EAE10: 7C9820A0
	v_cndmask_b32_e32 v1, v1, v16, vcc_lo                      // 0000002EAE14: 02022101
	s_waitcnt lgkmcnt(5)                                       // 0000002EAE18: BF89FC57
	v_dual_add_f32 v1, v3, v2 :: v_dual_lshlrev_b32 v16, 2, v1 // 0000002EAE1C: C9220503 01100282
	s_waitcnt lgkmcnt(4)                                       // 0000002EAE24: BF89FC47
	v_add_f32_e32 v2, v4, v9                                   // 0000002EAE28: 06041304
	s_waitcnt lgkmcnt(1)                                       // 0000002EAE2C: BF89FC17
	v_dual_add_f32 v4, v5, v10 :: v_dual_add_f32 v3, v7, v12   // 0000002EAE30: C9081505 04021907
	v_add_f32_e32 v5, v6, v11                                  // 0000002EAE38: 060A1706
	s_waitcnt lgkmcnt(0)                                       // 0000002EAE3C: BF89FC07
	v_add_f32_e32 v9, v8, v15                                  // 0000002EAE40: 06121F08
	ds_bpermute_b32 v6, v16, v1                                // 0000002EAE44: DACC0000 06000110
	ds_bpermute_b32 v7, v16, v2                                // 0000002EAE4C: DACC0000 07000210
	ds_bpermute_b32 v10, v16, v4                               // 0000002EAE54: DACC0000 0A000410
	ds_bpermute_b32 v11, v16, v5                               // 0000002EAE5C: DACC0000 0B000510
	ds_bpermute_b32 v8, v16, v3                                // 0000002EAE64: DACC0000 08000310
	ds_bpermute_b32 v12, v16, v9                               // 0000002EAE6C: DACC0000 0C000910
	v_cmpx_eq_u32_e32 0, v14                                   // 0000002EAE74: 7D941C80
	s_cbranch_execz 12                                         // 0000002EAE78: BFA5000C <_ZN7halogen12_GLOBAL__N_16k_lq8wILi6ELi32ELi8EEEvPKhPKtPtll+0xaac>
	s_waitcnt lgkmcnt(0)                                       // 0000002EAE7C: BF89FC07
	v_dual_add_f32 v9, v9, v12 :: v_dual_add_f32 v4, v4, v10   // 0000002EAE80: C9081909 09041504
	v_dual_add_f32 v5, v5, v11 :: v_dual_add_f32 v8, v3, v8    // 0000002EAE88: C9081705 05081103
	v_dual_add_f32 v2, v2, v7 :: v_dual_add_f32 v1, v1, v6     // 0000002EAE90: C9080F02 02000D01
	v_mul_u32_u24_e32 v6, 24, v13                              // 0000002EAE98: 160C1A98
	ds_store_2addr_b64 v6, v[1:2], v[4:5] offset1:1            // 0000002EAE9C: D9380100 00040106
	ds_store_b64 v6, v[8:9] offset:16                          // 0000002EAEA4: D9340010 00000806
	s_or_b32 exec_lo, exec_lo, s0                              // 0000002EAEAC: 8C7E007E
	.long 0xd4510000                                           // 0000002EAEB0: D4510000
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 0000002EAEB4: 02001802
	v_cmp_gt_u32_e32 vcc_lo, 6, v0                             // 0000002EAEB8: 7C980086
	s_waitcnt lgkmcnt(0)                                       // 0000002EAEBC: BF89FC07
	s_barrier                                                  // 0000002EAEC0: BFBD0000
	buffer_gl0_inv                                             // 0000002EAEC4: E0AC0000 00000000
	s_and_b32 s0, vcc_lo, s0                                   // 0000002EAECC: 8B00006A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002EAED0: BF870009
	s_and_saveexec_b32 s1, s0                                  // 0000002EAED4: BE812000
	s_cbranch_execz 50                                         // 0000002EAED8: BFA50032 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi6ELi32ELi8EEEvPKhPKtPtll+0xba4>
	v_lshlrev_b32_e32 v7, 2, v0                                // 0000002EAEDC: 300E0082
	s_lshl_b64 s[0:1], s[2:3], 1                               // 0000002EAEE0: 84808102
	ds_load_2addr_b32 v[1:2], v7 offset1:6                     // 0000002EAEE4: D8DC0600 01000007
	ds_load_2addr_b32 v[3:4], v7 offset0:12 offset1:18         // 0000002EAEEC: D8DC120C 03000007
	ds_load_2addr_b32 v[5:6], v7 offset0:24 offset1:30         // 0000002EAEF4: D8DC1E18 05000007
	s_waitcnt lgkmcnt(2)                                       // 0000002EAEFC: BF89FC27
	v_add_f32_e32 v1, 0, v1                                    // 0000002EAF00: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002EAF04: BF8700A1
	v_add_f32_e32 v1, v1, v2                                   // 0000002EAF08: 06020501
	s_waitcnt lgkmcnt(1)                                       // 0000002EAF0C: BF89FC17
	v_add_f32_e32 v1, v1, v3                                   // 0000002EAF10: 06020701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000002EAF14: BF870131
	v_add_f32_e32 v3, v1, v4                                   // 0000002EAF18: 06060901
	v_mad_u64_u32 v[1:2], null, s12, v0, 0                     // 0000002EAF1C: D6FE7C01 0202000C
	s_waitcnt lgkmcnt(0)                                       // 0000002EAF24: BF89FC07
	v_add_f32_e32 v3, v3, v5                                   // 0000002EAF28: 06060B03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000002EAF2C: BF8700D1
	v_add_f32_e32 v4, v3, v6                                   // 0000002EAF30: 06080D03
	ds_load_2addr_b32 v[7:8], v7 offset0:36 offset1:42         // 0000002EAF34: D8DC2A24 07000007
	v_mad_u64_u32 v[2:3], null, s13, v0, v[2:3]                // 0000002EAF3C: D6FE7C02 040A000D
	s_waitcnt lgkmcnt(0)                                       // 0000002EAF44: BF89FC07
	v_add_f32_e32 v0, v4, v7                                   // 0000002EAF48: 06000F04
	v_add_f32_e32 v3, v0, v8                                   // 0000002EAF4C: 06061100
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002EAF50: BF870113
	.long 0xd73c0000                                           // 0000002EAF54: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000002EAF58: 02020281
	v_bfe_u32 v2, v3, 16, 1                                    // 0000002EAF5C: D6100002 02052103
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002EAF64: BF870092
	.long 0xd7006a00                                           // 0000002EAF68: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 0000002EAF6C: 02020008
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 0000002EAF70: D5207C01 01AA0209
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002EAF78: BF870193
	v_add3_u32 v2, v3, v2, 0x7fff                              // 0000002EAF7C: D6550002 03FE0503 00007FFF
	.long 0xd7006a00                                           // 0000002EAF88: D7006A00
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 0000002EAF8C: 02000100
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002EAF90: BF870001
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 0000002EAF94: D5207C01 01AA0201
	global_store_d16_hi_b16 v[0:1], v2, off                    // 0000002EAF9C: DC960000 007C0200
	s_endpgm                                                   // 0000002EAFA4: BFB00000
		...

