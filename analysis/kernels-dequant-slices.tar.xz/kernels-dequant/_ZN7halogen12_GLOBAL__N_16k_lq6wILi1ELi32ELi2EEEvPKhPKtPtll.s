0000000000330b00 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi1ELi32ELi2EEEvPKhPKtPtll>:
; _ZN7halogen12_GLOBAL__N_16k_lq6wILi1ELi32ELi2EEEvPKhPKtPtll():
	s_load_b256 s[4:11], s[0:1], null                          // 000000330B00: F40C0100 F8000000
	s_mov_b32 s3, 0                                            // 000000330B08: BE830080
	s_load_b64 s[12:13], s[0:1], 0x20                          // 000000330B0C: F4040300 F8000020
	s_lshl_b64 s[2:3], s[2:3], 2                               // 000000330B14: 84828202
	v_lshrrev_b32_e32 v16, 6, v0                               // 000000330B18: 32200086
	v_mov_b32_e32 v4, s3                                       // 000000330B1C: 7E080203
	v_bfe_u32 v17, v0, 5, 1                                    // 000000330B20: D6100011 02050B00
	v_dual_mov_b32 v2, 0 :: v_dual_and_b32 v19, 31, v0         // 000000330B28: CA240080 0212009F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000330B30: BF870244
	v_or_b32_e32 v3, s2, v16                                   // 000000330B34: 38062002
	v_dual_mov_b32 v18, 0 :: v_dual_mov_b32 v1, 0              // 000000330B38: CA100080 12000080
	v_mov_b32_e32 v12, 0                                       // 000000330B40: 7E180280
	v_mov_b32_e32 v30, 0                                       // 000000330B44: 7E3C0280
	.long 0xd73c0005                                           // 000000330B48: D73C0005
	v_cndmask_b32_e32 v1, 4, v3, vcc_lo                        // 000000330B4C: 02020684
	v_mov_b32_e32 v13, 0                                       // 000000330B50: 7E1A0280
	s_waitcnt lgkmcnt(0)                                       // 000000330B54: BF89FC07
	s_ashr_i32 s18, s11, 31                                    // 000000330B58: 86129F0B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 000000330B5C: BF8704C9
	s_lshr_b32 s0, s18, 27                                     // 000000330B60: 85009B12
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[3:4]                  // 000000330B64: 7CA8060C
	s_add_u32 s0, s10, s0                                      // 000000330B68: 8000000A
	s_addc_u32 s1, s11, 0                                      // 000000330B6C: 8201800B
	s_lshr_b64 s[0:1], s[0:1], 5                               // 000000330B70: 85808500
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000330B74: BF870009
	s_add_i32 s1, s0, 1                                        // 000000330B78: 81018100
	v_cndmask_b32_e32 v4, 0, v6, vcc_lo                        // 000000330B7C: 02080C80
	s_lshr_b32 s14, s1, 31                                     // 000000330B80: 850E9F01
	v_cndmask_b32_e32 v5, 0, v5, vcc_lo                        // 000000330B84: 020A0A80
	s_add_i32 s1, s1, s14                                      // 000000330B88: 81010E01
	s_lshr_b32 s14, s11, 31                                    // 000000330B8C: 850E9F0B
	s_ashr_i32 s1, s1, 1                                       // 000000330B90: 86018101
	s_add_u32 s14, s10, s14                                    // 000000330B94: 800E0E0A
	s_addc_u32 s15, s11, 0                                     // 000000330B98: 820F800B
	s_lshr_b32 s19, s18, 30                                    // 000000330B9C: 85139E12
	s_ashr_i64 s[16:17], s[14:15], 1                           // 000000330BA0: 8690810E
	s_add_u32 s14, s10, s19                                    // 000000330BA4: 800E130A
	s_addc_u32 s15, s11, 0                                     // 000000330BA8: 820F800B
	s_lshr_b32 s18, s18, 28                                    // 000000330BAC: 85129C12
	s_ashr_i64 s[14:15], s[14:15], 2                           // 000000330BB0: 868E820E
	s_add_u32 s10, s10, s18                                    // 000000330BB4: 800A120A
	s_addc_u32 s11, s11, 0                                     // 000000330BB8: 820B800B
	.long 0xd72c0003                                           // 000000330BBC: D72C0003
	v_cndmask_b32_e32 v1, s1, v17, vcc_lo                      // 000000330BC0: 02022201
	s_ashr_i64 s[10:11], s[10:11], 4                           // 000000330BC4: 868A840A
	s_add_u32 s18, s14, s16                                    // 000000330BC8: 8012100E
	s_addc_u32 s19, s15, s17                                   // 000000330BCC: 8213110F
	s_add_u32 s10, s18, s10                                    // 000000330BD0: 800A0A12
	s_addc_u32 s11, s19, s11                                   // 000000330BD4: 820B0B13
	s_add_u32 s10, s10, 15                                     // 000000330BD8: 800A8F0A
	s_addc_u32 s11, s11, 0                                     // 000000330BDC: 820B800B
	v_add_nc_u32_e32 v6, s1, v3                                // 000000330BE0: 4A0C0601
	s_ashr_i32 s18, s11, 31                                    // 000000330BE4: 86129F0B
	v_add_nc_u32_e32 v20, v3, v19                              // 000000330BE8: 4A282703
	s_lshr_b32 s18, s18, 28                                    // 000000330BEC: 85129C12
	v_mov_b32_e32 v3, 0                                        // 000000330BF0: 7E060280
	s_add_u32 s10, s10, s18                                    // 000000330BF4: 800A120A
	s_addc_u32 s11, s11, 0                                     // 000000330BF8: 820B800B
	v_min_i32_e32 v21, s0, v6                                  // 000000330BFC: 222A0C00
	s_ashr_i64 s[10:11], s[10:11], 4                           // 000000330C00: 868A840A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 000000330C04: BF8701D9
	.long 0xd72c0007                                           // 000000330C08: D72C0007
	v_cndmask_b32_e32 v0, v5, v11, vcc_lo                      // 000000330C0C: 02001705
	.long 0xd72c0008                                           // 000000330C10: D72C0008
	v_cndmask_b32_e32 v0, v4, v10, vcc_lo                      // 000000330C14: 02001504
	v_mad_u64_u32 v[9:10], null, v5, s10, s[4:5]               // 000000330C18: D6FE7C09 00101505
	v_mov_b32_e32 v4, 0                                        // 000000330C20: 7E080280
	v_cmp_lt_i32_e32 vcc_lo, v20, v21                          // 000000330C24: 7C822B14
	v_add3_u32 v22, v8, v10, v7                                // 000000330C28: D6550016 041E1508
	s_and_saveexec_b32 s1, vcc_lo                              // 000000330C30: BE81206A
	s_cbranch_execz 39                                         // 000000330C34: BFA50027 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi1ELi32ELi2EEEvPKhPKtPtll+0x1d4>
	v_lshlrev_b32_e32 v1, 4, v20                               // 000000330C38: 30022884
	v_lshlrev_b32_e32 v4, 1, v20                               // 000000330C3C: 30082881
	v_lshlrev_b32_e32 v3, 3, v20                               // 000000330C40: 30062883
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000330C44: BF870223
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000330C48: 3404029F
	.long 0xd7000001                                           // 000000330C4C: D7000001
	v_cndmask_b32_e32 v1, v9, v1, vcc_lo                       // 000000330C50: 02020309
	v_and_b32_e32 v4, -4, v4                                   // 000000330C54: 360808C4
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000330C58: BF870214
	v_ashrrev_i32_e32 v7, 31, v3                               // 000000330C5C: 340E069F
	v_add_co_ci_u32_e64 v2, null, v22, v2, s0                  // 000000330C60: D5207C02 00020516
	.long 0xd7000005                                           // 000000330C68: D7000005
	v_cndmask_b32_e32 v0, v9, v16, vcc_lo                      // 000000330C6C: 02002109
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000330C70: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s17, v22, s0                 // 000000330C74: D5207C06 00022C11
	v_ashrrev_i32_e32 v11, 31, v4                              // 000000330C7C: 3416089F
	.long 0xd7000008                                           // 000000330C80: D7000008
	v_cndmask_b32_e32 v0, v5, v14, vcc_lo                      // 000000330C84: 02001D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000330C88: BF8700A1
	v_add_co_ci_u32_e64 v10, null, s15, v6, s0                 // 000000330C8C: D5207C0A 00020C0F
	.long 0xd7000005                                           // 000000330C94: D7000005
	v_cndmask_b32_e32 v1, v5, v3, vcc_lo                       // 000000330C98: 02020705
	v_add_co_ci_u32_e64 v6, null, v6, v7, s0                   // 000000330C9C: D5207C06 00020F06
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000330CA4: BF870094
	.long 0xd7000007                                           // 000000330CA8: D7000007
	v_cndmask_b32_e32 v1, v8, v4, vcc_lo                       // 000000330CAC: 02020908
	v_add_co_ci_u32_e64 v8, null, v10, v11, s0                 // 000000330CB0: D5207C08 0002170A
	s_clause 0x2                                               // 000000330CB8: BF850002
	global_load_b128 v[1:4], v[1:2], off                       // 000000330CBC: DC5E0000 017C0001
	global_load_b64 v[12:13], v[5:6], off                      // 000000330CC4: DC560000 0C7C0005
	global_load_b32 v30, v[7:8], off                           // 000000330CCC: DC520000 1E7C0007
	s_or_b32 exec_lo, exec_lo, s1                              // 000000330CD4: 8C7E017E
	s_and_saveexec_b32 s1, vcc_lo                              // 000000330CD8: BE81206A
	s_cbranch_execz 618                                        // 000000330CDC: BFA5026A <_ZN7halogen12_GLOBAL__N_16k_lq6wILi1ELi32ELi2EEEvPKhPKtPtll+0xb88>
	.long 0xd7006a17                                           // 000000330CE0: D7006A17
	v_cndmask_b32_e32 v0, v9, v16, vcc_lo                      // 000000330CE4: 02002109
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000330CE8: BF8701A1
	v_add_co_ci_u32_e64 v24, null, s17, v22, vcc_lo            // 000000330CEC: D5207C18 01AA2C11
	v_dual_mov_b32 v18, 0 :: v_dual_add_nc_u32 v5, 32, v20     // 000000330CF4: CA200080 120428A0
	.long 0xd7006a19                                           // 000000330CFC: D7006A19
	v_cndmask_b32_e32 v0, v23, v14, vcc_lo                     // 000000330D00: 02001D17
	s_delay_alu instid0(VALU_DEP_1)                            // 000000330D04: BF870001
	v_add_co_ci_u32_e64 v26, null, s15, v24, vcc_lo            // 000000330D08: D5207C1A 01AA300F
	s_waitcnt vmcnt(0)                                         // 000000330D10: BF8903F7
	v_dual_mov_b32 v31, v30 :: v_dual_lshlrev_b32 v10, 5, v20  // 000000330D14: CA22011E 1F0A2885
	v_lshlrev_b32_e32 v27, 4, v5                               // 000000330D1C: 30360A84
	v_lshlrev_b32_e32 v28, 3, v5                               // 000000330D20: 30380A83
	v_lshlrev_b32_e32 v29, 1, v5                               // 000000330D24: 303A0A81
	s_mov_b32 s4, 0                                            // 000000330D28: BE840080
	s_branch 558                                               // 000000330D2C: BFA0022E <_ZN7halogen12_GLOBAL__N_16k_lq6wILi1ELi32ELi2EEEvPKhPKtPtll+0xae8>
	s_or_b32 exec_lo, exec_lo, s5                              // 000000330D30: 8C7E057E
	v_ashrrev_i32_e32 v11, 31, v10                             // 000000330D34: 3416149F
	v_lshlrev_b32_e32 v48, 2, v12                              // 000000330D38: 30601882
	v_lshrrev_b32_e32 v49, 4, v1                               // 000000330D3C: 32620284
	v_lshrrev_b32_e32 v50, 8, v1                               // 000000330D40: 32640288
	v_lshrrev_b32_e32 v51, 2, v12                              // 000000330D44: 32661882
	.long 0xd73c0020                                           // 000000330D48: D73C0020
	v_cndmask_b32_e32 v1, 1, v10, vcc_lo                       // 000000330D4C: 02021481
	v_lshlrev_b32_e32 v11, 4, v12                              // 000000330D50: 30161884
	v_and_b32_e32 v48, 48, v48                                 // 000000330D54: 366060B0
	v_and_b32_e32 v52, 48, v12                                 // 000000330D58: 366818B0
	v_lshrrev_b32_e32 v53, 12, v1                              // 000000330D5C: 326A028C
	v_and_b32_e32 v51, 48, v51                                 // 000000330D60: 366666B0
	.long 0xd700002c                                           // 000000330D64: D700002C
	v_cndmask_b32_e32 v1, s6, v32, vcc_lo                      // 000000330D68: 02024006
	s_delay_alu instid0(VALU_DEP_1)                            // 000000330D6C: BF870001
	v_add_co_ci_u32_e64 v45, null, s7, v33, s0                 // 000000330D70: D5207C2D 00024207
	v_and_b32_e32 v11, 48, v11                                 // 000000330D78: 361616B0
	v_and_or_b32 v48, v49, 15, v48                             // 000000330D7C: D6570030 04C11F31
	v_and_or_b32 v49, v50, 15, v52                             // 000000330D84: D6570031 04D11F32
	s_clause 0x3                                               // 000000330D8C: BF850003
	global_load_b128 v[32:35], v[44:45], off                   // 000000330D90: DC5E0000 207C002C
	global_load_b128 v[36:39], v[44:45], off offset:16         // 000000330D98: DC5E0010 247C002C
	global_load_b128 v[40:43], v[44:45], off offset:32         // 000000330DA0: DC5E0020 287C002C
	global_load_b128 v[44:47], v[44:45], off offset:48         // 000000330DA8: DC5E0030 2C7C002C
	v_and_or_b32 v50, v53, 15, v51                             // 000000330DB0: D6570032 04CD1F35
	v_and_or_b32 v11, v1, 15, v11                              // 000000330DB8: D657000B 042D1F01
	v_cvt_f32_ubyte0_e32 v48, v48                              // 000000330DC0: 7E602330
	v_cvt_f32_ubyte0_e32 v49, v49                              // 000000330DC4: 7E622331
	.long 0x7f6a3880                                           // 000000330DC8: 7F6A3880
	v_cvt_f32_ubyte0_e32 v50, v50                              // 000000330DCC: 7E642332
	v_cvt_f32_ubyte0_e32 v11, v11                              // 000000330DD0: 7E16230B
	v_fma_mix_f32 v48, v48, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000330DD4: CC206030 147A3D30
	v_fma_mix_f32 v49, v49, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000330DDC: CC206031 147A3D31
	v_lshrrev_b32_e32 v55, 10, v12                             // 000000330DE4: 326E188A
	v_fma_mix_f32 v50, v50, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000330DE8: CC206032 147A3D32
	v_fma_mix_f32 v11, v11, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000330DF0: CC20600B 147A3D0B
	v_bfe_u32 v52, v48, 16, 1                                  // 000000330DF8: D6100034 02052130
	v_lshrrev_b32_e32 v60, 22, v12                             // 000000330E00: 32781896
	v_lshrrev_b32_e32 v59, 20, v2                              // 000000330E04: 32760494
	v_bfe_u32 v54, v50, 16, 1                                  // 000000330E08: D6100036 02052132
	v_bfe_u32 v51, v11, 16, 1                                  // 000000330E10: D6100033 0205210B
	v_add3_u32 v48, v48, v52, 0x7fff                           // 000000330E18: D6550030 03FE6930 00007FFF
	v_lshrrev_b32_e32 v52, 20, v1                              // 000000330E24: 32680294
	v_lshrrev_b32_e32 v61, 24, v2                              // 000000330E28: 327A0498
	v_add3_u32 v50, v50, v54, 0x7fff                           // 000000330E2C: D6550032 03FE6D32 00007FFF
	v_add3_u32 v11, v11, v51, 0x7fff                           // 000000330E38: D655000B 03FE670B 00007FFF
	v_bfe_u32 v51, v49, 16, 1                                  // 000000330E44: D6100033 02052131
	v_lshrrev_b32_e32 v54, 24, v1                              // 000000330E4C: 326C0298
	v_lshlrev_b32_e32 v64, 4, v13                              // 000000330E50: 30801A84
	v_and_b32_e32 v60, 48, v60                                 // 000000330E54: 367878B0
	.long 0x7e6a398b                                           // 000000330E58: 7E6A398B
	v_add3_u32 v11, v49, v51, 0x7fff                           // 000000330E5C: D655000B 03FE6731 00007FFF
	v_lshrrev_b32_e32 v49, 4, v12                              // 000000330E68: 32621884
	v_lshrrev_b32_e32 v51, 8, v12                              // 000000330E6C: 32661888
	v_lshrrev_b32_e32 v57, 14, v12                             // 000000330E70: 3272188E
	v_and_or_b32 v48, 0xffff0000, v48, v53                     // 000000330E74: D6570030 04D660FF FFFF0000
	.long 0x7e6a398b                                           // 000000330E80: 7E6A398B
	v_lshrrev_b32_e32 v11, 6, v12                              // 000000330E84: 32161886
	v_and_b32_e32 v49, 48, v49                                 // 000000330E88: 366262B0
	v_and_b32_e32 v51, 48, v51                                 // 000000330E8C: 366666B0
	v_lshrrev_b32_e32 v62, 28, v2                              // 000000330E90: 327C049C
	v_and_or_b32 v50, 0xffff0000, v50, v53                     // 000000330E94: D6570032 04D664FF FFFF0000
	.long 0x7e6a3981                                           // 000000330EA0: 7E6A3981
	v_and_b32_e32 v11, 48, v11                                 // 000000330EA4: 361616B0
	v_lshrrev_b32_e32 v1, 28, v1                               // 000000330EA8: 3202029C
	v_and_or_b32 v51, v54, 15, v51                             // 000000330EAC: D6570033 04CD1F36
	v_lshlrev_b32_e32 v66, 2, v13                              // 000000330EB4: 30841A82
	v_and_or_b32 v49, v53, 15, v49                             // 000000330EB8: D6570031 04C51F35
	v_and_or_b32 v11, v52, 15, v11                             // 000000330EC0: D657000B 042D1F34
	v_and_or_b32 v1, v55, 48, v1                               // 000000330EC8: D6570001 04056137
	v_cvt_f32_ubyte0_e32 v51, v51                              // 000000330ED0: 7E662333
	v_lshrrev_b32_e32 v52, 12, v12                             // 000000330ED4: 3268188C
	v_cvt_f32_ubyte0_e32 v49, v49                              // 000000330ED8: 7E622331
	v_cvt_f32_ubyte0_e32 v11, v11                              // 000000330EDC: 7E16230B
	v_cvt_f32_ubyte0_e32 v1, v1                                // 000000330EE0: 7E022301
	v_fma_mix_f32 v51, v51, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000330EE4: CC206033 147A3D33
	v_and_or_b32 v59, v59, 15, v60                             // 000000330EEC: D657003B 04F11F3B
	v_fma_mix_f32 v49, v49, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000330EF4: CC206031 147A3D31
	v_fma_mix_f32 v11, v11, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000330EFC: CC20600B 147A3D0B
	v_fma_mix_f32 v1, v1, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000330F04: CC206001 147A3D01
	v_lshrrev_b32_e32 v65, 4, v3                               // 000000330F0C: 32820684
	v_and_b32_e32 v67, 48, v13                                 // 000000330F10: 36861AB0
	v_bfe_u32 v54, v49, 16, 1                                  // 000000330F14: D6100036 02052131
	v_bfe_u32 v56, v11, 16, 1                                  // 000000330F1C: D6100038 0205210B
	v_bfe_u32 v58, v1, 16, 1                                   // 000000330F24: D610003A 02052101
	v_cvt_f32_ubyte0_e32 v59, v59                              // 000000330F2C: 7E76233B
	v_lshrrev_b32_e32 v68, 12, v3                              // 000000330F30: 3288068C
	v_add3_u32 v49, v49, v54, 0x7fff                           // 000000330F34: D6550031 03FE6D31 00007FFF
	v_bfe_u32 v54, v51, 16, 1                                  // 000000330F40: D6100036 02052133
	v_add3_u32 v11, v11, v56, 0x7fff                           // 000000330F48: D655000B 03FE710B 00007FFF
	v_add3_u32 v1, v1, v58, 0x7fff                             // 000000330F54: D6550001 03FE7501 00007FFF
	v_lshrrev_b32_e32 v56, 18, v12                             // 000000330F60: 32701892
	.long 0x7e6a39b1                                           // 000000330F64: 7E6A39B1
	v_add3_u32 v49, v51, v54, 0x7fff                           // 000000330F68: D6550031 03FE6D33 00007FFF
	v_lshrrev_b32_e32 v51, 8, v2                               // 000000330F74: 32660488
	v_lshrrev_b32_e32 v54, 20, v12                             // 000000330F78: 326C1894
	v_and_b32_e32 v56, 48, v56                                 // 000000330F7C: 367070B0
	v_and_or_b32 v11, 0xffff0000, v11, v53                     // 000000330F80: D657000B 04D616FF FFFF0000
	.long 0x7e6a39b1                                           // 000000330F8C: 7E6A39B1
	v_lshrrev_b32_e32 v49, 12, v2                              // 000000330F90: 3262048C
	v_lshrrev_b32_e32 v58, 24, v12                             // 000000330F94: 32741898
	v_and_b32_e32 v54, 48, v54                                 // 000000330F98: 366C6CB0
	v_fma_mix_f32 v59, v59, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000330F9C: CC20603B 147A3D3B
	v_and_or_b32 v1, 0xffff0000, v1, v53                       // 000000330FA4: D6570001 04D602FF FFFF0000
	.long 0x7e6a398c                                           // 000000330FB0: 7E6A398C
	v_and_or_b32 v49, v49, 15, v56                             // 000000330FB4: D6570031 04E11F31
	v_and_b32_e32 v58, 48, v58                                 // 000000330FBC: 367474B0
	v_lshrrev_b32_e32 v12, 26, v12                             // 000000330FC0: 3218189A
	v_lshrrev_b32_e32 v56, 2, v13                              // 000000330FC4: 32701A82
	v_and_b32_e32 v63, 48, v53                                 // 000000330FC8: 367E6AB0
	v_cvt_f32_ubyte0_e32 v49, v49                              // 000000330FCC: 7E622331
	v_and_or_b32 v58, v61, 15, v58                             // 000000330FD0: D657003A 04E91F3D
	v_and_or_b32 v12, v12, 48, v62                             // 000000330FD8: D657000C 04F9610C
	v_and_b32_e32 v62, 48, v66                                 // 000000330FE0: 367C84B0
	v_and_or_b32 v51, v51, 15, v63                             // 000000330FE4: D6570033 04FD1F33
	v_fma_mix_f32 v49, v49, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000330FEC: CC206031 147A3D31
	v_lshrrev_b32_e32 v63, 8, v3                               // 000000330FF4: 327E0688
	v_cvt_f32_ubyte0_e32 v58, v58                              // 000000330FF8: 7E74233A
	v_and_b32_e32 v56, 48, v56                                 // 000000330FFC: 367070B0
	v_cvt_f32_ubyte0_e32 v51, v51                              // 000000331000: 7E662333
	v_bfe_u32 v78, v49, 16, 1                                  // 000000331004: D610004E 02052131
	v_and_or_b32 v63, v63, 15, v67                             // 00000033100C: D657003F 050D1F3F
	v_cvt_f32_ubyte0_e32 v12, v12                              // 000000331014: 7E18230C
	v_and_or_b32 v60, v65, 15, v62                             // 000000331018: D657003C 04F91F41
	v_fma_mix_f32 v51, v51, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000331020: CC206033 147A3D33
	v_add3_u32 v49, v49, v78, 0x7fff                           // 000000331028: D6550031 03FE9D31 00007FFF
	v_fma_mix_f32 v58, v58, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000331034: CC20603A 147A3D3A
	v_and_or_b32 v56, v68, 15, v56                             // 00000033103C: D6570038 04E11F44
	v_cvt_f32_ubyte0_e32 v61, v63                              // 000000331044: 7E7A233F
	v_bfe_u32 v74, v51, 16, 1                                  // 000000331048: D610004A 02052133
	v_fma_mix_f32 v12, v12, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000331050: CC20600C 147A3D0C
	v_cvt_f32_ubyte0_e32 v60, v60                              // 000000331058: 7E78233C
	v_cvt_f32_ubyte0_e32 v56, v56                              // 00000033105C: 7E702338
	v_fma_mix_f32 v61, v61, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000331060: CC20603D 147A3D3D
	v_add3_u32 v51, v51, v74, 0x7fff                           // 000000331068: D6550033 03FE9533 00007FFF
	v_bfe_u32 v63, v12, 16, 1                                  // 000000331074: D610003F 0205210C
	v_fma_mix_f32 v60, v60, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000033107C: CC20603C 147A3D3C
	v_fma_mix_f32 v56, v56, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000331084: CC206038 147A3D38
	v_lshrrev_b32_e32 v70, 4, v13                              // 00000033108C: 328C1A84
	.long 0x7e6a39b3                                           // 000000331090: 7E6A39B3
	v_and_b32_e32 v51, 48, v64                                 // 000000331094: 366680B0
	v_bfe_u32 v64, v59, 16, 1                                  // 000000331098: D6100040 0205213B
	v_add3_u32 v12, v12, v63, 0x7fff                           // 0000003310A0: D655000C 03FE7F0C 00007FFF
	v_lshrrev_b32_e32 v69, 8, v13                              // 0000003310AC: 328A1A88
	v_and_or_b32 v49, 0xffff0000, v49, v53                     // 0000003310B0: D6570031 04D662FF FFFF0000
	.long 0x7e6a3982                                           // 0000003310BC: 7E6A3982
	v_and_or_b32 v51, v3, 15, v51                              // 0000003310C0: D6570033 04CD1F03
	v_add3_u32 v59, v59, v64, 0x7fff                           // 0000003310C8: D655003B 03FE813B 00007FFF
	v_lshrrev_b32_e32 v72, 6, v13                              // 0000003310D4: 32901A86
	v_and_b32_e32 v63, 48, v70                                 // 0000003310D8: 367E8CB0
	v_and_or_b32 v54, v53, 15, v54                             // 0000003310DC: D6570036 04D91F35
	v_cvt_f32_ubyte0_e32 v51, v51                              // 0000003310E4: 7E662333
	v_lshrrev_b32_e32 v71, 20, v3                              // 0000003310E8: 328E0694
	v_lshrrev_b32_e32 v73, 24, v3                              // 0000003310EC: 32920698
	v_and_b32_e32 v66, 48, v72                                 // 0000003310F0: 368490B0
	v_cvt_f32_ubyte0_e32 v54, v54                              // 0000003310F4: 7E6C2336
	v_fma_mix_f32 v51, v51, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003310F8: CC206033 147A3D33
	v_and_b32_e32 v67, 48, v69                                 // 000000331100: 36868AB0
	v_lshrrev_b32_e32 v76, 28, v3                              // 000000331104: 3298069C
	v_lshrrev_b32_e32 v77, 10, v13                             // 000000331108: 329A1A8A
	v_fma_mix_f32 v54, v54, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000033110C: CC206036 147A3D36
	v_and_or_b32 v66, v71, 15, v66                             // 000000331114: D6570042 05091F47
	v_and_or_b32 v67, v73, 15, v67                             // 00000033111C: D6570043 050D1F49
	v_and_b32_e32 v52, 48, v52                                 // 000000331124: 366868B0
	v_and_or_b32 v71, v77, 48, v76                             // 000000331128: D6570047 0531614D
	v_bfe_u32 v62, v54, 16, 1                                  // 000000331130: D610003E 02052136
	v_cvt_f32_ubyte0_e32 v66, v66                              // 000000331138: 7E842342
	v_cvt_f32_ubyte0_e32 v67, v67                              // 00000033113C: 7E862343
	v_lshrrev_b32_e32 v55, 4, v2                               // 000000331140: 326E0484
	v_cvt_f32_ubyte0_e32 v71, v71                              // 000000331144: 7E8E2347
	v_add3_u32 v54, v54, v62, 0x7fff                           // 000000331148: D6550036 03FE7D36 00007FFF
	v_bfe_u32 v62, v58, 16, 1                                  // 000000331154: D610003E 0205213A
	v_fma_mix_f32 v66, v66, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000033115C: CC206042 147A3D42
	v_fma_mix_f32 v67, v67, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000331164: CC206043 147A3D43
	v_fma_mix_f32 v71, v71, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000033116C: CC206047 147A3D47
	.long 0x7e6a39b6                                           // 000000331174: 7E6A39B6
	v_add3_u32 v54, v58, v62, 0x7fff                           // 000000331178: D6550036 03FE7D3A 00007FFF
	v_bfe_u32 v58, v51, 16, 1                                  // 000000331184: D610003A 02052133
	v_bfe_u32 v62, v60, 16, 1                                  // 00000033118C: D610003E 0205213C
	v_bfe_u32 v76, v66, 16, 1                                  // 000000331194: D610004C 02052142
	v_and_or_b32 v59, 0xffff0000, v59, v53                     // 00000033119C: D657003B 04D676FF FFFF0000
	.long 0x7e6a39b6                                           // 0000003311A8: 7E6A39B6
	v_add3_u32 v51, v51, v58, 0x7fff                           // 0000003311AC: D6550033 03FE7533 00007FFF
	v_bfe_u32 v54, v61, 16, 1                                  // 0000003311B8: D6100036 0205213D
	v_bfe_u32 v58, v56, 16, 1                                  // 0000003311C0: D610003A 02052138
	v_add3_u32 v60, v60, v62, 0x7fff                           // 0000003311C8: D655003C 03FE7D3C 00007FFF
	v_and_or_b32 v12, 0xffff0000, v12, v53                     // 0000003311D4: D657000C 04D618FF FFFF0000
	.long 0x7e6a39b3                                           // 0000003311E0: 7E6A39B3
	v_add3_u32 v51, v61, v54, 0x7fff                           // 0000003311E4: D6550033 03FE6D3D 00007FFF
	v_add3_u32 v56, v56, v58, 0x7fff                           // 0000003311F0: D6550038 03FE7538 00007FFF
	v_bfe_u32 v77, v71, 16, 1                                  // 0000003311FC: D610004D 02052147
	v_add3_u32 v66, v66, v76, 0x7fff                           // 000000331204: D6550042 03FE9942 00007FFF
	v_and_or_b32 v58, 0xffff0000, v60, v53                     // 000000331210: D657003A 04D678FF FFFF0000
	.long 0x7e6a39b3                                           // 00000033121C: 7E6A39B3
	v_and_b32_e32 v57, 48, v57                                 // 000000331220: 367272B0
	v_add3_u32 v71, v71, v77, 0x7fff                           // 000000331224: D6550047 03FE9B47 00007FFF
	v_and_or_b32 v2, v2, 15, v52                               // 000000331230: D6570002 04D11F02
	v_lshrrev_b32_e32 v75, 12, v13                             // 000000331238: 32961A8C
	v_and_or_b32 v56, 0xffff0000, v56, v53                     // 00000033123C: D6570038 04D670FF FFFF0000
	.long 0x7e6a3983                                           // 000000331248: 7E6A3983
	v_lshrrev_b32_e32 v51, 14, v13                             // 00000033124C: 32661A8E
	v_lshrrev_b32_e32 v62, 20, v13                             // 000000331250: 327C1A94
	v_lshrrev_b32_e32 v64, 18, v13                             // 000000331254: 32801A92
	v_lshrrev_b32_e32 v65, 24, v13                             // 000000331258: 32821A98
	v_and_or_b32 v63, v53, 15, v63                             // 00000033125C: D657003F 04FD1F35
	v_lshrrev_b32_e32 v69, 22, v13                             // 000000331264: 328A1A96
	v_lshrrev_b32_e32 v74, 26, v13                             // 000000331268: 32941A9A
	v_cvt_f32_ubyte0_e32 v2, v2                                // 00000033126C: 7E042302
	v_lshrrev_b32_e32 v60, 8, v4                               // 000000331270: 32780888
	v_cvt_f32_ubyte0_e32 v63, v63                              // 000000331274: 7E7E233F
	v_lshrrev_b32_e32 v3, 12, v4                               // 000000331278: 3206088C
	v_and_b32_e32 v54, 15, v4                                  // 00000033127C: 366C088F
	v_fma_mix_f32 v2, v2, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000331280: CC206002 147A3D02
	v_lshrrev_b32_e32 v61, 4, v4                               // 000000331288: 327A0884
	v_fma_mix_f32 v63, v63, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000033128C: CC20603F 147A3D3F
	v_lshrrev_b32_e32 v72, 28, v4                              // 000000331294: 3290089C
	v_and_or_b32 v54, v75, 48, v54                             // 000000331298: D6570036 04D9614B
	v_and_b32_e32 v51, 48, v51                                 // 0000003312A0: 366666B0
	v_lshrrev_b32_e32 v68, 20, v4                              // 0000003312A4: 32880894
	v_bfe_u32 v73, v63, 16, 1                                  // 0000003312A8: D6100049 0205213F
	v_lshrrev_b32_e32 v70, 24, v4                              // 0000003312B0: 328C0898
	v_and_b32_e32 v65, 48, v65                                 // 0000003312B4: 368282B0
	.long 0x7f6839b5                                           // 0000003312B8: 7F6839B5
	v_add_nc_u32_e32 v27, 0x200, v27                           // 0000003312BC: 4A3636FF 00000200
	v_add3_u32 v63, v63, v73, 0x7fff                           // 0000003312C4: D655003F 03FE933F 00007FFF
	v_bfe_u32 v73, v67, 16, 1                                  // 0000003312D0: D6100049 02052143
	v_add_nc_u32_e32 v28, 0x100, v28                           // 0000003312D8: 4A3838FF 00000100
	v_add_nc_u32_e32 v29, 64, v29                              // 0000003312E0: 4A3A3AC0
	v_add_nc_u32_e32 v10, 0x400, v10                           // 0000003312E4: 4A1414FF 00000400
	.long 0x7e6a39bf                                           // 0000003312EC: 7E6A39BF
	v_add3_u32 v63, v67, v73, 0x7fff                           // 0000003312F0: D655003F 03FE9343 00007FFF
	.long 0x7f8639b5                                           // 0000003312FC: 7F8639B5
	s_and_b32 s0, exec_lo, vcc_lo                              // 000000331300: 8B006A7E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000331304: BF870193
	v_and_or_b32 v66, 0xffff0000, v66, v53                     // 000000331308: D6570042 04D684FF FFFF0000
	.long 0x7e6a39bf                                           // 000000331314: 7E6A39BF
	s_or_b32 s4, s0, s4                                        // 000000331318: 8C040400
	s_delay_alu instid0(VALU_DEP_1)                            // 00000033131C: BF870001
	v_and_or_b32 v63, 0xffff0000, v71, v53                     // 000000331320: D657003F 04D68EFF FFFF0000
	.long 0x7e6a398d                                           // 00000033132C: 7E6A398D
	v_and_or_b32 v13, v55, 15, v57                             // 000000331330: D657000D 04E51F37
	v_and_b32_e32 v57, 48, v62                                 // 000000331338: 36727CB0
	v_and_b32_e32 v55, 48, v64                                 // 00000033133C: 366E80B0
	v_and_b32_e32 v64, 48, v69                                 // 000000331340: 36808AB0
	v_and_b32_e32 v62, 48, v53                                 // 000000331344: 367C6AB0
	v_cvt_f32_ubyte0_e32 v13, v13                              // 000000331348: 7E1A230D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000033134C: BF870194
	v_and_or_b32 v3, v3, 15, v55                               // 000000331350: D6570003 04DD1F03
	v_and_or_b32 v60, v60, 15, v62                             // 000000331358: D657003C 04F91F3C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000331360: BF870223
	v_fma_mix_f32 v13, v13, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000331364: CC20600D 147A3D0D
	v_bfe_u32 v62, v2, 16, 1                                   // 00000033136C: D610003E 02052102
	v_cvt_f32_ubyte0_e32 v3, v3                                // 000000331374: 7E062303
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000331378: BF870193
	v_bfe_u32 v55, v13, 16, 1                                  // 00000033137C: D6100037 0205210D
	v_add3_u32 v2, v2, v62, 0x7fff                             // 000000331384: D6550002 03FE7D02 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000331390: BF870193
	v_fma_mix_f32 v3, v3, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000331394: CC206003 147A3D03
	v_add3_u32 v13, v13, v55, 0x7fff                           // 00000033139C: D655000D 03FE6F0D 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003313A8: BF870093
	.long 0x7e863982                                           // 0000003313AC: 7E863982
	v_and_or_b32 v13, 0xffff0000, v13, v67                     // 0000003313B0: D657000D 050E1AFF FFFF0000
	s_waitcnt vmcnt(3)                                         // 0000003313BC: BF890FF7
	v_dot2_f32_bf16 v32, v32, v48, 0                           // 0000003313C0: CC1A4020 1A026120
	v_cvt_f32_ubyte0_e32 v48, v60                              // 0000003313C8: 7E60233C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003313CC: BF870112
	v_dot2_f32_bf16 v32, v33, v50, v32                         // 0000003313D0: CC1A4020 1C826521
	v_fma_mix_f32 v33, v48, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003313D8: CC206021 147A3D30
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003313E0: BF870112
	v_dot2_f32_bf16 v2, v34, v11, v32                          // 0000003313E4: CC1A4002 1C821722
	v_bfe_u32 v11, v33, 16, 1                                  // 0000003313EC: D610000B 02052121
	v_and_or_b32 v32, v74, 48, v72                             // 0000003313F4: D6570020 0521614A
	v_cvt_f32_ubyte0_e32 v34, v54                              // 0000003313FC: 7E442336
	s_delay_alu instid0(VALU_DEP_4)                            // 000000331400: BF870004
	v_dot2_f32_bf16 v1, v35, v1, v2                            // 000000331404: CC1A4001 1C0A0323
	v_bfe_u32 v2, v3, 16, 1                                    // 00000033140C: D6100002 02052103
	v_add3_u32 v11, v33, v11, 0x7fff                           // 000000331414: D655000B 03FE1721 00007FFF
	v_and_or_b32 v33, v61, 15, v51                             // 000000331420: D6570021 04CD1F3D
	s_waitcnt vmcnt(2)                                         // 000000331428: BF890BF7
	v_dot2_f32_bf16 v1, v36, v13, v1                           // 00000033142C: CC1A4001 1C061B24
	v_add3_u32 v2, v3, v2, 0x7fff                              // 000000331434: D6550002 03FE0503 00007FFF
	.long 0x7e6a398b                                           // 000000331440: 7E6A398B
	v_cvt_f32_ubyte0_e32 v13, v32                              // 000000331444: 7E1A2320
	v_cvt_f32_ubyte0_e32 v32, v33                              // 000000331448: 7E402321
	v_dot2_f32_bf16 v1, v37, v49, v1                           // 00000033144C: CC1A4001 1C066325
	v_and_or_b32 v3, v68, 15, v64                              // 000000331454: D6570003 05011F44
	v_and_or_b32 v2, 0xffff0000, v2, v53                       // 00000033145C: D6570002 04D604FF FFFF0000
	.long 0x7e6a3984                                           // 000000331468: 7E6A3984
	v_fma_mix_f32 v4, v34, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000033146C: CC206004 147A3D22
	v_dot2_f32_bf16 v1, v38, v59, v1                           // 000000331474: CC1A4001 1C067726
	v_and_or_b32 v11, v70, 15, v65                             // 00000033147C: D657000B 05051F46
	v_fma_mix_f32 v32, v32, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000331484: CC206020 147A3D20
	v_and_or_b32 v33, v53, 15, v57                             // 00000033148C: D6570021 04E51F35
	v_cvt_f32_ubyte0_e32 v3, v3                                // 000000331494: 7E062303
	v_dot2_f32_bf16 v1, v39, v12, v1                           // 000000331498: CC1A4001 1C061927
	v_fma_mix_f32 v12, v13, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003314A0: CC20600C 147A3D0D
	v_bfe_u32 v13, v4, 16, 1                                   // 0000003314A8: D610000D 02052104
	v_cvt_f32_ubyte0_e32 v33, v33                              // 0000003314B0: 7E422321
	v_cvt_f32_ubyte0_e32 v11, v11                              // 0000003314B4: 7E16230B
	s_waitcnt vmcnt(1)                                         // 0000003314B8: BF8907F7
	v_dot2_f32_bf16 v1, v40, v58, v1                           // 0000003314BC: CC1A4001 1C067528
	v_fma_mix_f32 v3, v3, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003314C4: CC206003 147A3D03
	v_add3_u32 v4, v4, v13, 0x7fff                             // 0000003314CC: D6550004 03FE1B04 00007FFF
	v_fma_mix_f32 v13, v33, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003314D8: CC20600D 147A3D21
	v_bfe_u32 v33, v32, 16, 1                                  // 0000003314E0: D6100021 02052120
	v_dot2_f32_bf16 v1, v41, v56, v1                           // 0000003314E8: CC1A4001 1C067129
	v_fma_mix_f32 v11, v11, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003314F0: CC20600B 147A3D0B
	.long 0x7e683984                                           // 0000003314F8: 7E683984
	v_bfe_u32 v4, v13, 16, 1                                   // 0000003314FC: D6100004 0205210D
	v_add3_u32 v30, v32, v33, 0x7fff                           // 000000331504: D655001E 03FE4320 00007FFF
	v_dot2_f32_bf16 v1, v42, v66, v1                           // 000000331510: CC1A4001 1C06852A
	v_bfe_u32 v32, v3, 16, 1                                   // 000000331518: D6100020 02052103
	v_bfe_u32 v33, v11, 16, 1                                  // 000000331520: D6100021 0205210B
	v_add3_u32 v4, v13, v4, 0x7fff                             // 000000331528: D6550004 03FE090D 00007FFF
	v_and_or_b32 v13, 0xffff0000, v30, v52                     // 000000331534: D657000D 04D23CFF FFFF0000
	v_dot2_f32_bf16 v1, v43, v63, v1                           // 000000331540: CC1A4001 1C067F2B
	v_bfe_u32 v30, v12, 16, 1                                  // 000000331548: D610001E 0205210C
	v_add3_u32 v3, v3, v32, 0x7fff                             // 000000331550: D6550003 03FE4103 00007FFF
	.long 0x7e6a3984                                           // 00000033155C: 7E6A3984
	v_add3_u32 v4, v11, v33, 0x7fff                            // 000000331560: D6550004 03FE430B 00007FFF
	s_waitcnt vmcnt(0)                                         // 00000033156C: BF8903F7
	v_dot2_f32_bf16 v1, v44, v13, v1                           // 000000331570: CC1A4001 1C061B2C
	v_add3_u32 v11, v12, v30, 0x7fff                           // 000000331578: D655000B 03FE3D0C 00007FFF
	v_mov_b32_e32 v12, v14                                     // 000000331584: 7E18030E
	v_and_or_b32 v3, 0xffff0000, v3, v53                       // 000000331588: D6570003 04D606FF FFFF0000
	.long 0x7e6a3984                                           // 000000331594: 7E6A3984
	v_dot2_f32_bf16 v1, v45, v2, v1                            // 000000331598: CC1A4001 1C06052D
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v13, v15           // 0000003315A0: CA100106 020C010F
	v_mov_b32_e32 v30, v31                                     // 0000003315A8: 7E3C031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003315AC: BF870214
	v_and_or_b32 v4, 0xffff0000, v11, v53                      // 0000003315B0: D6570004 04D616FF FFFF0000
	v_dot2_f32_bf16 v1, v46, v3, v1                            // 0000003315BC: CC1A4001 1C06072E
	v_mov_b32_e32 v3, v7                                       // 0000003315C4: 7E060307
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003315C8: BF870122
	v_dot2_f32_bf16 v1, v47, v4, v1                            // 0000003315CC: CC1A4001 1C06092F
	v_mov_b32_e32 v4, v8                                       // 0000003315D4: 7E080308
	v_dual_add_f32 v18, v18, v1 :: v_dual_mov_b32 v1, v5       // 0000003315D8: C9100312 12000105
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000003315E0: 917E047E
	s_cbranch_execz 39                                         // 0000003315E4: BFA50027 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi1ELi32ELi2EEEvPKhPKtPtll+0xb84>
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003315E8: BF870001
	v_dual_mov_b32 v5, v1 :: v_dual_add_nc_u32 v20, 32, v20    // 0000003315EC: CA200101 051428A0
	v_dual_mov_b32 v6, v2 :: v_dual_mov_b32 v7, v3             // 0000003315F4: CA100102 06060103
	v_dual_mov_b32 v8, v4 :: v_dual_mov_b32 v15, v13           // 0000003315FC: CA100104 080E010D
	v_mov_b32_e32 v14, v12                                     // 000000331604: 7E1C030C
	s_mov_b32 s5, exec_lo                                      // 000000331608: BE85007E
	v_cmp_ge_i32_e32 vcc_lo, v20, v21                          // 00000033160C: 7C8C2B14
	.long 0xd4c1007e                                           // 000000331610: D4C1007E
	v_cndmask_b32_e32 v1, v20, v21, vcc_lo                     // 000000331614: 02022B14
	s_cbranch_execz 64965                                      // 000000331618: BFA5FDC5 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi1ELi32ELi2EEEvPKhPKtPtll+0x230>
	v_and_b32_e32 v7, -4, v29                                  // 00000033161C: 360E3AC4
	v_ashrrev_i32_e32 v6, 31, v27                              // 000000331620: 340C369F
	v_ashrrev_i32_e32 v8, 31, v28                              // 000000331624: 3410389F
	.long 0xd7000005                                           // 000000331628: D7000005
	v_cndmask_b32_e32 v1, v9, v27, vcc_lo                      // 00000033162C: 02023709
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000331630: BF870214
	v_ashrrev_i32_e32 v11, 31, v7                              // 000000331634: 34160E9F
	v_add_co_ci_u32_e64 v6, null, v22, v6, s0                  // 000000331638: D5207C06 00020D16
	.long 0xd700000e                                           // 000000331640: D700000E
	v_cndmask_b32_e32 v1, v23, v28, vcc_lo                     // 000000331644: 02023917
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000331648: BF8700A1
	v_add_co_ci_u32_e64 v15, null, v24, v8, s0                 // 00000033164C: D5207C0F 00021118
	.long 0xd700001f                                           // 000000331654: D700001F
	v_cndmask_b32_e32 v1, v25, v7, vcc_lo                      // 000000331658: 02020F19
	v_add_co_ci_u32_e64 v32, null, v26, v11, s0                // 00000033165C: D5207C20 0002171A
	s_clause 0x2                                               // 000000331664: BF850002
	global_load_b128 v[5:8], v[5:6], off                       // 000000331668: DC5E0000 057C0005
	global_load_b64 v[14:15], v[14:15], off                    // 000000331670: DC560000 0E7C000E
	global_load_b32 v31, v[31:32], off                         // 000000331678: DC520000 1F7C001F
	s_branch 64939                                             // 000000331680: BFA0FDAB <_ZN7halogen12_GLOBAL__N_16k_lq6wILi1ELi32ELi2EEEvPKhPKtPtll+0x230>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000331684: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000331688: BF8700C9
	s_or_b32 exec_lo, exec_lo, s1                              // 00000033168C: 8C7E017E
	s_waitcnt vmcnt(2)                                         // 000000331690: BF890BF7
	.long 0xd71f0001                                           // 000000331694: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000331698: 020100C1
	s_mov_b32 s0, exec_lo                                      // 00000033169C: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 0000003316A0: 3A040290
	v_xor_b32_e32 v3, 8, v1                                    // 0000003316A4: 3A060288
	v_xor_b32_e32 v4, 4, v1                                    // 0000003316A8: 3A080284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000003316AC: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000003316B0: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 0000003316B4: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v3                            // 0000003316B8: 7C9806A0
	v_cndmask_b32_e32 v3, v1, v3, vcc_lo                       // 0000003316BC: 02060701
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 0000003316C0: 7C9808A0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000003316C4: BF870002
	v_lshlrev_b32_e32 v3, 2, v3                                // 0000003316C8: 30060682
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000003316CC: 30040482
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo                       // 0000003316D0: 02080901
	ds_bpermute_b32 v2, v2, v18                                // 0000003316D4: DACC0000 02001202
	v_lshlrev_b32_e32 v4, 2, v4                                // 0000003316DC: 30080882
	s_waitcnt lgkmcnt(0)                                       // 0000003316E0: BF89FC07
	v_add_f32_e32 v2, v18, v2                                  // 0000003316E4: 06040512
	ds_bpermute_b32 v3, v3, v2                                 // 0000003316E8: DACC0000 03000203
	s_waitcnt lgkmcnt(0)                                       // 0000003316F0: BF89FC07
	v_add_f32_e32 v2, v2, v3                                   // 0000003316F4: 06040702
	ds_bpermute_b32 v3, v4, v2                                 // 0000003316F8: DACC0000 03000204
	v_xor_b32_e32 v4, 2, v1                                    // 000000331700: 3A080282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000331704: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 000000331708: 7C9808A0
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo                       // 00000033170C: 02080901
	v_lshlrev_b32_e32 v4, 2, v4                                // 000000331710: 30080882
	s_waitcnt lgkmcnt(0)                                       // 000000331714: BF89FC07
	v_add_f32_e32 v2, v2, v3                                   // 000000331718: 06040702
	ds_bpermute_b32 v3, v4, v2                                 // 00000033171C: DACC0000 03000204
	v_xor_b32_e32 v4, 1, v1                                    // 000000331724: 3A080281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000331728: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 00000033172C: 7C9808A0
	s_waitcnt lgkmcnt(0)                                       // 000000331730: BF89FC07
	v_dual_cndmask_b32 v4, v1, v4 :: v_dual_add_f32 v1, v2, v3 // 000000331734: CA480901 04000702
	v_lshlrev_b32_e32 v2, 2, v4                                // 00000033173C: 30040882
	ds_bpermute_b32 v2, v2, v1                                 // 000000331740: DACC0000 02000102
	v_cmpx_eq_u32_e32 0, v19                                   // 000000331748: 7D942680
	s_cbranch_execz 8                                          // 00000033174C: BFA50008 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi1ELi32ELi2EEEvPKhPKtPtll+0xc70>
	v_lshlrev_b32_e32 v3, 3, v16                               // 000000331750: 30062083
	s_waitcnt lgkmcnt(0)                                       // 000000331754: BF89FC07
	v_add_f32_e32 v1, v1, v2                                   // 000000331758: 06020501
	s_delay_alu instid0(VALU_DEP_2)                            // 00000033175C: BF870002
	v_lshl_or_b32 v2, v17, 2, v3                               // 000000331760: D6560002 040D0511
	ds_store_b32 v2, v1                                        // 000000331768: D8340000 00000102
	s_or_b32 exec_lo, exec_lo, s0                              // 000000331770: 8C7E007E
	v_or_b32_e32 v1, s2, v0                                    // 000000331774: 38020002
	s_waitcnt lgkmcnt(0)                                       // 000000331778: BF89FC07
	v_mov_b32_e32 v2, s3                                       // 00000033177C: 7E040203
	.long 0xd44c0000                                           // 000000331780: D44C0000
	v_cndmask_b32_e32 v1, 4, v0, vcc_lo                        // 000000331784: 02020084
	s_waitcnt vmcnt(0)                                         // 000000331788: BF8903F7
	s_barrier                                                  // 00000033178C: BFBD0000
	buffer_gl0_inv                                             // 000000331790: E0AC0000 00000000
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 000000331798: 7CA8020C
	s_and_b32 s0, s0, vcc_lo                                   // 00000033179C: 8B006A00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003317A0: BF870009
	s_and_saveexec_b32 s1, s0                                  // 0000003317A4: BE812000
	s_cbranch_execz 22                                         // 0000003317A8: BFA50016 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi1ELi32ELi2EEEvPKhPKtPtll+0xd04>
	v_lshlrev_b32_e32 v0, 3, v0                                // 0000003317AC: 30000083
	ds_load_b64 v[3:4], v0                                     // 0000003317B0: D9D80000 03000000
	s_waitcnt lgkmcnt(0)                                       // 0000003317B8: BF89FC07
	v_add_f32_e32 v0, 0, v3                                    // 0000003317BC: 06000680
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003317C0: BF870121
	v_add_f32_e32 v3, v0, v4                                   // 0000003317C4: 06060900
	.long 0xd73c0000                                           // 0000003317C8: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000003317CC: 02020281
	v_bfe_u32 v4, v3, 16, 1                                    // 0000003317D0: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003317D8: BF870092
	.long 0xd7006a00                                           // 0000003317DC: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 0000003317E0: 02020008
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 0000003317E4: D5207C01 01AA0209
	s_delay_alu instid0(VALU_DEP_3)                            // 0000003317EC: BF870003
	v_add3_u32 v2, v3, v4, 0x7fff                              // 0000003317F0: D6550002 03FE0903 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off                    // 0000003317FC: DC960000 007C0200
	s_endpgm                                                   // 000000331804: BFB00000
		...

