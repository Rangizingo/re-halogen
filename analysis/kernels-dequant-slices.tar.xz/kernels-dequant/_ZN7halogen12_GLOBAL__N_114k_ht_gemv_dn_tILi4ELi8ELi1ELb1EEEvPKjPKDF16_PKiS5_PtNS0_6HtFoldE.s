0000000000982500 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi4ELi8ELi1ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE>:
; _ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi4ELi8ELi1ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE():
	s_load_b512 s[4:19], s[0:1], null                          // 000000982500: F4100100 F8000000
	s_mul_hi_i32 s3, s2, 0x66666667                            // 000000982508: 9703FF02 66666667
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000982510: BF8704A9
	s_lshr_b32 s20, s3, 31                                     // 000000982514: 85149F03
	s_ashr_i32 s3, s3, 3                                       // 000000982518: 86038303
	s_add_i32 s20, s3, s20                                     // 00000098251C: 81141403
	s_mov_b32 s3, exec_lo                                      // 000000982520: BE83007E
	s_ashr_i32 s21, s20, 31                                    // 000000982524: 86159F14
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000982528: BF870009
	s_lshl_b64 s[22:23], s[20:21], 2                           // 00000098252C: 84968214
	s_waitcnt lgkmcnt(0)                                       // 000000982530: BF89FC07
	s_add_u32 s8, s8, s22                                      // 000000982534: 80081608
	s_addc_u32 s9, s9, s23                                     // 000000982538: 82091709
	s_load_b32 s8, s[8:9], null                                // 00000098253C: F4000204 F8000000
	v_cmpx_gt_u32_e32 0x50, v0                                 // 000000982544: 7D9800FF 00000050
	s_cbranch_execz 12                                         // 00000098254C: BFA5000C <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi4ELi8ELi1ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x80>
	s_mul_i32 s9, s20, 0x500                                   // 000000982550: 9609FF14 00000500
	v_lshlrev_b32_e32 v5, 4, v0                                // 000000982558: 300A0084
	s_mul_hi_i32 s21, s20, 0x500                               // 00000098255C: 9715FF14 00000500
	s_add_u32 s6, s6, s9                                       // 000000982564: 80060906
	s_addc_u32 s7, s7, s21                                     // 000000982568: 82071507
	global_load_b128 v[1:4], v5, s[6:7]                        // 00000098256C: DC5E0000 01060005
	s_waitcnt vmcnt(0)                                         // 000000982574: BF8903F7
	ds_store_b128 v5, v[1:4]                                   // 000000982578: DB7C0000 00000105
	s_or_b32 exec_lo, exec_lo, s3                              // 000000982580: 8C7E037E
	v_lshrrev_b32_e32 v7, 5, v0                                // 000000982584: 320E0085
	v_and_b32_e32 v9, 31, v0                                   // 000000982588: 3612009F
	s_mul_i32 s9, s20, 0xffffffec                              // 00000098258C: 9609FF14 FFFFFFEC
	s_waitcnt lgkmcnt(0)                                       // 000000982594: BF89FC07
	s_mul_i32 s6, s8, 0xc8000                                  // 000000982598: 9606FF08 000C8000
	s_mul_hi_i32 s3, s8, 0xc8000                               // 0000009825A0: 9703FF08 000C8000
	v_mul_u32_u24_e32 v1, 5, v7                                // 0000009825A8: 16020E85
	s_add_i32 s9, s9, s2                                       // 0000009825AC: 81090209
	s_add_u32 s4, s4, s6                                       // 0000009825B0: 80040604
	s_addc_u32 s3, s5, s3                                      // 0000009825B4: 82030305
	s_mul_i32 s5, s9, 0xa000                                   // 0000009825B8: 9605FF09 0000A000
	v_min_u32_e32 v2, 35, v1                                   // 0000009825C0: 260402A3
	v_lshlrev_b32_e32 v8, 2, v9                                // 0000009825C4: 30101282
	s_mul_hi_i32 s6, s9, 0xa000                                // 0000009825C8: 9706FF09 0000A000
	s_add_u32 s4, s4, s5                                       // 0000009825D0: 80040504
	s_addc_u32 s5, s3, s6                                      // 0000009825D4: 82050603
	v_add_nc_u32_e32 v10, 5, v2                                // 0000009825D8: 4A140485
	s_barrier                                                  // 0000009825DC: BFBD0000
	buffer_gl0_inv                                             // 0000009825E0: E0AC0000 00000000
	v_cmp_lt_u32_e32 vcc_lo, v1, v10                           // 0000009825E8: 7C921501
	s_and_saveexec_b32 s6, vcc_lo                              // 0000009825EC: BE86206A
	s_cbranch_execz 91                                         // 0000009825F0: BFA5005B <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi4ELi8ELi1ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x260>
	.long 0xd7010302                                           // 0000009825F4: D7010302
	v_cndmask_b32_e32 v0, v9, v129, vcc_lo                     // 0000009825F8: 02010309
	v_mul_u32_u24_e32 v5, 0x1400, v7                           // 0000009825FC: 160A0EFF 00001400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000982604: BF870092
	v_cndmask_b32_e64 v2, v2, 31, s3                           // 000000982608: D5010002 000D3F02
	.long 0xd44c0003                                           // 000000982610: D44C0003
	v_cndmask_b32_e32 v1, 31, v2, vcc_lo                       // 000000982614: 0202049F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000982618: BF8700B1
	v_cndmask_b32_e64 v4, 0xe1, 1, s3                          // 00000098261C: D5010004 000D02FF 000000E1
	v_mov_b32_e32 v3, 0                                        // 000000982628: 7E060280
	.long 0xd700030d                                           // 00000098262C: D700030D
	v_cndmask_b32_e32 v1, s4, v5, vcc_lo                       // 000000982630: 02020A04
	v_add_co_ci_u32_e64 v14, null, s5, 0, s3                   // 000000982634: D5207C0E 000D0005
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000098263C: BF870214
	v_add_nc_u32_e32 v4, v4, v2                                // 000000982640: 4A080504
	.long 0xd73c0002                                           // 000000982644: D73C0002
	v_cndmask_b32_e32 v1, 2, v2, vcc_lo                        // 000000982648: 02020482
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000098264C: BF8701A2
	v_lshlrev_b32_e32 v6, 24, v4                               // 000000982650: 300C0898
	v_bfe_i32 v12, v4, 7, 1                                    // 000000982654: D611000C 02050F04
	.long 0xd7000304                                           // 00000098265C: D7000304
	v_cndmask_b32_e32 v1, v13, v2, vcc_lo                      // 000000982660: 0202050D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000982664: BF870211
	v_add_co_ci_u32_e64 v5, null, v14, v3, s3                  // 000000982668: D5207C05 000E070E
	v_ashrrev_i32_e32 v6, 22, v6                               // 000000982670: 340C0C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000982674: BF870091
	.long 0xd700030b                                           // 000000982678: D700030B
	v_cndmask_b32_e32 v1, v13, v6, vcc_lo                      // 00000098267C: 02020D0D
	v_add_co_ci_u32_e64 v12, null, v14, v12, s3                // 000000982680: D5207C0C 000E190E
	.long 0xd700030d                                           // 000000982688: D700030D
	v_cndmask_b32_e32 v1, v13, v8, vcc_lo                      // 00000098268C: 0202110D
	s_delay_alu instid0(VALU_DEP_1)                            // 000000982690: BF870001
	v_add_co_ci_u32_e64 v14, null, 0, v14, s3                  // 000000982694: D5207C0E 000E1C80
	s_clause 0x17                                              // 00000098269C: BF850017
	global_load_b32 v2, v[4:5], off                            // 0000009826A0: DC520000 027C0004
	global_load_b32 v57, v[4:5], off offset:128                // 0000009826A8: DC520080 397C0004
	global_load_b32 v54, v[4:5], off offset:256                // 0000009826B0: DC520100 367C0004
	global_load_b32 v51, v[4:5], off offset:384                // 0000009826B8: DC520180 337C0004
	global_load_b32 v48, v[4:5], off offset:512                // 0000009826C0: DC520200 307C0004
	global_load_b32 v45, v[4:5], off offset:640                // 0000009826C8: DC520280 2D7C0004
	global_load_b32 v26, v[4:5], off offset:768                // 0000009826D0: DC520300 1A7C0004
	global_load_b32 v20, v[4:5], off offset:896                // 0000009826D8: DC520380 147C0004
	global_load_b32 v4, v[11:12], off                          // 0000009826E0: DC520000 047C000B
	global_load_b32 v58, v[11:12], off offset:128              // 0000009826E8: DC520080 3A7C000B
	global_load_b32 v55, v[11:12], off offset:256              // 0000009826F0: DC520100 377C000B
	global_load_b32 v52, v[11:12], off offset:384              // 0000009826F8: DC520180 347C000B
	global_load_b32 v49, v[11:12], off offset:512              // 000000982700: DC520200 317C000B
	global_load_b32 v46, v[11:12], off offset:640              // 000000982708: DC520280 2E7C000B
	global_load_b32 v27, v[11:12], off offset:768              // 000000982710: DC520300 1B7C000B
	global_load_b32 v21, v[11:12], off offset:896              // 000000982718: DC520380 157C000B
	global_load_b32 v3, v[13:14], off                          // 000000982720: DC520000 037C000D
	global_load_b32 v56, v[13:14], off offset:128              // 000000982728: DC520080 387C000D
	global_load_b32 v53, v[13:14], off offset:256              // 000000982730: DC520100 357C000D
	global_load_b32 v50, v[13:14], off offset:384              // 000000982738: DC520180 327C000D
	global_load_b32 v47, v[13:14], off offset:512              // 000000982740: DC520200 2F7C000D
	global_load_b32 v44, v[13:14], off offset:640              // 000000982748: DC520280 2C7C000D
	global_load_b32 v25, v[13:14], off offset:768              // 000000982750: DC520300 197C000D
	global_load_b32 v19, v[13:14], off offset:896              // 000000982758: DC520380 137C000D
	s_or_b32 exec_lo, exec_lo, s6                              // 000000982760: 8C7E067E
	v_dual_mov_b32 v14, 0 :: v_dual_mov_b32 v11, 0             // 000000982764: CA100080 0E0A0080
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v13, 0             // 00000098276C: CA100080 0C0C0080
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v16, 0             // 000000982774: CA100080 0F100080
	v_dual_mov_b32 v17, 0 :: v_dual_mov_b32 v18, 0             // 00000098277C: CA100080 11120080
	s_and_saveexec_b32 s3, vcc_lo                              // 000000982784: BE83206A
	s_cbranch_execz 962                                        // 000000982788: BFA503C2 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi4ELi8ELi1ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x1194>
	v_dual_mov_b32 v6, 0 :: v_dual_add_nc_u32 v5, -1, v0       // 00000098278C: CA200080 060400C1
	v_dual_mov_b32 v11, 0 :: v_dual_and_b32 v22, 16, v0        // 000000982794: CA240080 0B160090
	v_dual_mov_b32 v14, 0 :: v_dual_lshlrev_b32 v23, 2, v9     // 00000098279C: CA220080 0E161282
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000009827A4: BF8701B3
	v_dual_mov_b32 v12, 0 :: v_dual_and_b32 v5, 31, v5         // 0000009827A8: CA240080 0C040A9F
	v_mov_b32_e32 v13, 0                                       // 0000009827B0: 7E1A0280
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v16, 0             // 0000009827B4: CA100080 0F100080
	v_dual_mov_b32 v17, 0 :: v_dual_lshlrev_b32 v24, 2, v5     // 0000009827BC: CA220080 11180A82
	v_mov_b32_e32 v18, 0                                       // 0000009827C4: 7E240280
	s_mov_b32 s6, 0                                            // 0000009827C8: BE860080
	s_movk_i32 s7, 0x1eee                                      // 0000009827CC: B0071EEE
	s_branch 886                                               // 0000009827D0: BFA00376 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi4ELi8ELi1ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x10ac>
	s_or_b32 exec_lo, exec_lo, s21                             // 0000009827D4: 8C7E157E
	s_waitcnt vmcnt(7)                                         // 0000009827D8: BF891FF7
	v_and_b32_e32 v64, 0xffff, v3                              // 0000009827DC: 368006FF 0000FFFF
	v_bfe_u32 v62, v3, 4, 16                                   // 0000009827E4: D610003E 02410903
	v_lshl_or_b32 v1, v1, 5, v22                               // 0000009827EC: D6560001 04590B01
	v_alignbit_b32 v59, v2, v4, 16                             // 0000009827F4: D616003B 02420902
	v_bfe_u32 v60, v3, 12, 16                                  // 0000009827FC: D610003C 02411903
	.long 0xd72c0040                                           // 000000982804: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000982808: 020280FF 83DCD12D
	.long 0xd72c003e                                           // 000000982810: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000982814: 02027CFF 83DCD12D
	v_bfe_u32 v61, v3, 8, 16                                   // 00000098281C: D610003D 02411103
	ds_load_b128 v[1:4], v1                                    // 000000982824: DBFC0000 01000001
	v_alignbit_b32 v57, v57, v58, 16                           // 00000098282C: D6160039 02427539
	v_bfe_u32 v63, v59, 12, 16                                 // 000000982834: D610003F 0241193B
	v_bfe_u32 v66, v59, 8, 16                                  // 00000098283C: D6100042 0241113B
	.long 0xd72c003c                                           // 000000982844: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000982848: 020278FF 83DCD12D
	v_sad_u8 v64, v64, 0, 0x6400                               // 000000982850: D6220040 03FD0140 00006400
	v_sad_u8 v62, v62, 0, 0x6400                               // 00000098285C: D622003E 03FD013E 00006400
	.long 0xd72c003f                                           // 000000982868: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 00000098286C: 02027EFF 83DCD12D
	.long 0xd72c0042                                           // 000000982874: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 000000982878: 020284FF 83DCD12D
	.long 0xd72c003d                                           // 000000982880: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000982884: 02027AFF 83DCD12D
	v_lshlrev_b32_e32 v64, 16, v64                             // 00000098288C: 30808090
	v_alignbit_b32 v54, v54, v55, 16                           // 000000982890: D6160036 02426F36
	v_sad_u8 v60, v60, 0, 0x6400                               // 000000982898: D622003C 03FD013C 00006400
	v_alignbit_b32 v51, v51, v52, 16                           // 0000009828A4: D6160033 02426933
	v_alignbit_b32 v48, v48, v49, 16                           // 0000009828AC: D6160030 02426330
	v_and_or_b32 v58, 0xffff, v62, v64                         // 0000009828B4: D657003A 05027CFF 0000FFFF
	v_bfe_u32 v62, v57, 12, 16                                 // 0000009828C0: D610003E 02411939
	v_bfe_u32 v64, v57, 8, 16                                  // 0000009828C8: D6100040 02411139
	v_sad_u8 v63, v63, 0, 0x6400                               // 0000009828D0: D622003F 03FD013F 00006400
	v_sad_u8 v66, v66, 0, 0x6400                               // 0000009828DC: D6220042 03FD0142 00006400
	v_sad_u8 v61, v61, 0, 0x6400                               // 0000009828E8: D622003D 03FD013D 00006400
	.long 0xd72c003e                                           // 0000009828F4: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 0000009828F8: 02027CFF 83DCD12D
	.long 0xd72c0040                                           // 000000982900: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000982904: 020280FF 83DCD12D
	v_and_b32_e32 v63, 0xffff, v63                             // 00000098290C: 367E7EFF 0000FFFF
	v_pk_fma_f16 v58, v58, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000982914: CC0E003A 0BFC0F3A 0000C931
	v_bfe_u32 v52, v51, 12, 16                                 // 000000982920: D6100034 02411933
	v_alignbit_b32 v26, v26, v27, 16                           // 000000982928: D616001A 0242371A
	v_alignbit_b32 v45, v45, v46, 16                           // 000000982930: D616002D 02425D2D
	v_lshl_or_b32 v63, v66, 16, v63                            // 000000982938: D656003F 04FD2142
	v_sad_u8 v62, v62, 0, 0x6400                               // 000000982940: D622003E 03FD013E 00006400
	v_sad_u8 v64, v64, 0, 0x6400                               // 00000098294C: D6220040 03FD0140 00006400
	s_waitcnt vmcnt(5)                                         // 000000982958: BF8917F7
	v_bfe_u32 v66, v53, 4, 16                                  // 00000098295C: D6100042 02410935
	.long 0xd72c0034                                           // 000000982964: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 000000982968: 020268FF 83DCD12D
	v_alignbit_b32 v20, v20, v21, 16                           // 000000982970: D6160014 02422B14
	v_and_b32_e32 v62, 0xffff, v62                             // 000000982978: 367C7CFF 0000FFFF
	v_cmp_eq_u32_e32 vcc_lo, v5, v10                           // 000000982980: 7C941505
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000982984: BF8701C2
	v_lshl_or_b32 v62, v64, 16, v62                            // 000000982988: D656003E 04F92140
	v_bfe_u32 v64, v53, 12, 16                                 // 000000982990: D6100040 02411935
	v_sad_u8 v52, v52, 0, 0x6400                               // 000000982998: D6220034 03FD0134 00006400
	s_or_b32 s6, vcc_lo, s6                                    // 0000009829A4: 8C06066A
	v_pk_fma_f16 v55, v62, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000009829A8: CC0E0037 0BFC0F3E 0000C931
	v_and_b32_e32 v62, 0xffff, v54                             // 0000009829B4: 367C6CFF 0000FFFF
	.long 0xd72c0040                                           // 0000009829BC: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 0000009829C0: 020280FF 83DCD12D
	s_waitcnt lgkmcnt(0)                                       // 0000009829C8: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000009829CC: BF870253
	v_dual_dot2acc_f32_f16 v17, v55, v1 :: v_dual_and_b32 v52, 0xffff, v52// 0000009829D0: CB240337 113468FF 0000FFFF
	v_and_b32_e32 v60, 0xffff, v60                             // 0000009829DC: 367878FF 0000FFFF
	.long 0xd72c003e                                           // 0000009829E4: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 0000009829E8: 02027CFF 83DCD12D
	.long 0xd72c0037                                           // 0000009829F0: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 0000009829F4: 020284FF 83DCD12D
	v_sad_u8 v64, v64, 0, 0x6400                               // 0000009829FC: D6220040 03FD0140 00006400
	v_lshl_or_b32 v60, v61, 16, v60                            // 000000982A08: D656003C 04F1213D
	v_pk_fma_f16 v61, v63, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000982A10: CC0E003D 0BFC0F3F 0000C931
	v_and_b32_e32 v65, 0xffff, v59                             // 000000982A1C: 368276FF 0000FFFF
	v_bfe_u32 v59, v59, 4, 16                                  // 000000982A24: D610003B 0241093B
	v_bfe_u32 v63, v56, 12, 16                                 // 000000982A2C: D610003F 02411938
	v_pk_fma_f16 v60, v60, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000982A34: CC0E003C 0BFC0F3C 0000C931
	v_dot2acc_f32_f16 v18, v61, v1                             // 000000982A40: 0424033D
	.long 0xd72c0041                                           // 000000982A44: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000982A48: 020282FF 83DCD12D
	.long 0xd72c003b                                           // 000000982A50: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000982A54: 020276FF 83DCD12D
	.long 0xd72c003f                                           // 000000982A5C: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000982A60: 02027EFF 83DCD12D
	v_sad_u8 v62, v62, 0, 0x6400                               // 000000982A68: D622003E 03FD013E 00006400
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000982A74: D6220037 03FD0137 00006400
	v_sad_u8 v65, v65, 0, 0x6400                               // 000000982A80: D6220041 03FD0141 00006400
	v_sad_u8 v59, v59, 0, 0x6400                               // 000000982A8C: D622003B 03FD013B 00006400
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000982A98: D622003F 03FD013F 00006400
	v_lshlrev_b32_e32 v62, 16, v62                             // 000000982AA4: 307C7C90
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000982AA8: BF870194
	v_lshlrev_b32_e32 v65, 16, v65                             // 000000982AAC: 30828290
	v_and_b32_e32 v63, 0xffff, v63                             // 000000982AB0: 367E7EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000982AB8: BF870122
	v_and_or_b32 v59, 0xffff, v59, v65                         // 000000982ABC: D657003B 050676FF 0000FFFF
	v_bfe_u32 v65, v56, 8, 16                                  // 000000982AC8: D6100041 02411138
	v_pk_fma_f16 v59, v59, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000982AD0: CC0E003B 0BFC0F3B 0000C931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000982ADC: BF870191
	v_dot2acc_f32_f16 v18, v59, v2                             // 000000982AE0: 0424053B
	.long 0xd72c003b                                           // 000000982AE4: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000982AE8: 020282FF 83DCD12D
	v_bfe_u32 v65, v56, 4, 16                                  // 000000982AF0: D6100041 02410938
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000982AF8: BF870223
	v_dot2acc_f32_f16 v18, v60, v3                             // 000000982AFC: 0424073C
	v_bfe_u32 v60, v54, 12, 16                                 // 000000982B00: D610003C 02411936
	v_sad_u8 v59, v59, 0, 0x6400                               // 000000982B08: D622003B 03FD013B 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000982B14: BF870193
	v_dot2acc_f32_f16 v18, v58, v4                             // 000000982B18: 0424093A
	.long 0xd72c003c                                           // 000000982B1C: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000982B20: 020278FF 83DCD12D
	s_waitcnt vmcnt(3)                                         // 000000982B28: BF890FF7
	v_bfe_u32 v58, v47, 8, 16                                  // 000000982B2C: D610003A 0241112F
	v_lshl_or_b32 v59, v59, 16, v63                            // 000000982B34: D656003B 04FD213B
	v_bfe_u32 v63, v54, 8, 16                                  // 000000982B3C: D610003F 02411136
	v_bfe_u32 v54, v54, 4, 16                                  // 000000982B44: D6100036 02410936
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000982B4C: BF870224
	.long 0xd72c003a                                           // 000000982B50: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000982B54: 020274FF 83DCD12D
	v_sad_u8 v60, v60, 0, 0x6400                               // 000000982B5C: D622003C 03FD013C 00006400
	.long 0xd72c003f                                           // 000000982B68: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000982B6C: 02027EFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000982B74: BF870224
	.long 0xd72c0036                                           // 000000982B78: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 000000982B7C: 02026CFF 83DCD12D
	v_pk_fma_f16 v59, v59, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000982B84: CC0E003B 0BFC0F3B 0000C931
	v_and_b32_e32 v60, 0xffff, v60                             // 000000982B90: 367878FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000982B98: BF870214
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000982B9C: D622003F 03FD013F 00006400
	v_sad_u8 v54, v54, 0, 0x6400                               // 000000982BA8: D6220036 03FD0136 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000982BB4: BF870112
	v_lshl_or_b32 v60, v63, 16, v60                            // 000000982BB8: D656003C 04F1213F
	v_and_or_b32 v54, 0xffff, v54, v62                         // 000000982BC0: D6570036 04FA6CFF 0000FFFF
	v_and_b32_e32 v62, 0xffff, v64                             // 000000982BCC: 367C80FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000982BD4: BF870193
	v_pk_fma_f16 v60, v60, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000982BD8: CC0E003C 0BFC0F3C 0000C931
	v_pk_fma_f16 v54, v54, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000982BE4: CC0E0036 0BFC0F36 0000C931
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000982BF0: BF8701B2
	v_dot2acc_f32_f16 v16, v60, v1                             // 000000982BF4: 0420033C
	v_and_b32_e32 v61, 0xffff, v57                             // 000000982BF8: 367A72FF 0000FFFF
	v_bfe_u32 v57, v57, 4, 16                                  // 000000982C00: D6100039 02410939
	v_dot2acc_f32_f16 v16, v54, v2                             // 000000982C08: 04200536
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000982C0C: BF870193
	.long 0xd72c003d                                           // 000000982C10: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000982C14: 02027AFF 83DCD12D
	.long 0xd72c0039                                           // 000000982C1C: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 000000982C20: 020272FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000982C28: BF870112
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000982C2C: D622003D 03FD013D 00006400
	v_sad_u8 v57, v57, 0, 0x6400                               // 000000982C38: D6220039 03FD0139 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000982C44: BF870092
	v_lshlrev_b32_e32 v61, 16, v61                             // 000000982C48: 307A7A90
	v_and_or_b32 v57, 0xffff, v57, v61                         // 000000982C4C: D6570039 04F672FF 0000FFFF
	.long 0xd72c003d                                           // 000000982C58: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000982C5C: 020282FF 83DCD12D
	v_bfe_u32 v65, v53, 8, 16                                  // 000000982C64: D6100041 02411135
	v_and_b32_e32 v53, 0xffff, v53                             // 000000982C6C: 366A6AFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000982C74: BF870194
	v_pk_fma_f16 v57, v57, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000982C78: CC0E0039 0BFC0F39 0000C931
	.long 0xd72c0041                                           // 000000982C84: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000982C88: 020282FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000982C90: BF870223
	.long 0xd72c0035                                           // 000000982C94: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000982C98: 02026AFF 83DCD12D
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000982CA0: D622003D 03FD013D 00006400
	v_dot2acc_f32_f16 v17, v57, v2                             // 000000982CAC: 04220539
	v_bfe_u32 v57, v50, 4, 16                                  // 000000982CB0: D6100039 02410932
	v_sad_u8 v63, v65, 0, 0x6400                               // 000000982CB8: D622003F 03FD0141 00006400
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000982CC4: D6220035 03FD0135 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000982CD0: BF870224
	v_dot2acc_f32_f16 v17, v59, v3                             // 000000982CD4: 0422073B
	v_bfe_u32 v59, v47, 4, 16                                  // 000000982CD8: D610003B 0241092F
	v_lshl_or_b32 v62, v63, 16, v62                            // 000000982CE0: D656003E 04F9213F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000982CE8: BF870094
	v_lshlrev_b32_e32 v53, 16, v53                             // 000000982CEC: 306A6A90
	v_and_or_b32 v53, 0xffff, v55, v53                         // 000000982CF0: D6570035 04D66EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000982CFC: BF870113
	v_pk_fma_f16 v55, v62, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000982D00: CC0E0037 0BFC0F3E 0000C931
	v_pk_fma_f16 v53, v53, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000982D0C: CC0E0035 0BFC0F35 0000C931
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000982D18: BF8700A2
	v_dot2acc_f32_f16 v16, v55, v3                             // 000000982D1C: 04200737
	v_bfe_u32 v55, v50, 12, 16                                 // 000000982D20: D6100037 02411932
	.long 0xd72c0037                                           // 000000982D28: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000982D2C: 02026EFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000982D34: BF870211
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000982D38: D6220037 03FD0137 00006400
	v_dot2acc_f32_f16 v16, v53, v4                             // 000000982D44: 04200935
	v_bfe_u32 v53, v51, 8, 16                                  // 000000982D48: D6100035 02411133
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000982D50: BF870113
	v_and_b32_e32 v55, 0xffff, v55                             // 000000982D54: 366E6EFF 0000FFFF
	.long 0xd72c0035                                           // 000000982D5C: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000982D60: 02026AFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000982D68: BF870091
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000982D6C: D6220035 03FD0135 00006400
	v_lshl_or_b32 v52, v53, 16, v52                            // 000000982D78: D6560034 04D12135
	.long 0xd72c0035                                           // 000000982D80: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 000000982D84: 020272FF 83DCD12D
	v_bfe_u32 v57, v47, 12, 16                                 // 000000982D8C: D6100039 0241192F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000982D94: BF8701A3
	v_pk_fma_f16 v52, v52, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000982D98: CC0E0034 0BFC0F34 0000C931
	v_and_b32_e32 v56, 0xffff, v56                             // 000000982DA4: 367070FF 0000FFFF
	.long 0xd72c0039                                           // 000000982DAC: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 000000982DB0: 020272FF 83DCD12D
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000982DB8: D6220035 03FD0135 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000982DC4: BF870214
	v_dot2acc_f32_f16 v15, v52, v1                             // 000000982DC8: 041E0334
	.long 0xd72c0038                                           // 000000982DCC: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000982DD0: 020270FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000982DD8: BF870114
	v_sad_u8 v57, v57, 0, 0x6400                               // 000000982DDC: D6220039 03FD0139 00006400
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000982DE8: D6220038 03FD0138 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000982DF4: BF870091
	v_lshlrev_b32_e32 v56, 16, v56                             // 000000982DF8: 30707090
	v_and_or_b32 v56, 0xffff, v61, v56                         // 000000982DFC: D6570038 04E27AFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000982E08: BF870121
	v_pk_fma_f16 v54, v56, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000982E0C: CC0E0036 0BFC0F38 0000C931
	v_bfe_u32 v56, v50, 8, 16                                  // 000000982E18: D6100038 02411132
	v_dual_dot2acc_f32_f16 v17, v54, v4 :: v_dual_and_b32 v50, 0xffff, v50// 000000982E20: CB240936 113264FF 0000FFFF
	v_and_b32_e32 v54, 0xffff, v51                             // 000000982E2C: 366C66FF 0000FFFF
	v_bfe_u32 v51, v51, 4, 16                                  // 000000982E34: D6100033 02410933
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000982E3C: BF870214
	.long 0xd72c0038                                           // 000000982E40: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000982E44: 020270FF 83DCD12D
	.long 0xd72c0032                                           // 000000982E4C: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 000000982E50: 020264FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000982E58: BF870214
	.long 0xd72c0036                                           // 000000982E5C: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 000000982E60: 02026CFF 83DCD12D
	.long 0xd72c0033                                           // 000000982E68: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 000000982E6C: 020266FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000982E74: BF870214
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000982E78: D6220038 03FD0138 00006400
	v_sad_u8 v50, v50, 0, 0x6400                               // 000000982E84: D6220032 03FD0132 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000982E90: BF870214
	v_sad_u8 v54, v54, 0, 0x6400                               // 000000982E94: D6220036 03FD0136 00006400
	v_sad_u8 v51, v51, 0, 0x6400                               // 000000982EA0: D6220033 03FD0133 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 000000982EAC: BF870004
	v_lshl_or_b32 v49, v56, 16, v55                            // 000000982EB0: D6560031 04DD2138
	v_bfe_u32 v56, v48, 8, 16                                  // 000000982EB8: D6100038 02411130
	v_lshlrev_b32_e32 v50, 16, v50                             // 000000982EC0: 30646490
	v_lshlrev_b32_e32 v54, 16, v54                             // 000000982EC4: 306C6C90
	v_and_b32_e32 v55, 0xffff, v48                             // 000000982EC8: 366E60FF 0000FFFF
	v_pk_fma_f16 v49, v49, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000982ED0: CC0E0031 0BFC0F31 0000C931
	.long 0xd72c0038                                           // 000000982EDC: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000982EE0: 020270FF 83DCD12D
	v_and_or_b32 v50, 0xffff, v53, v50                         // 000000982EE8: D6570032 04CA6AFF 0000FFFF
	v_and_or_b32 v51, 0xffff, v51, v54                         // 000000982EF4: D6570033 04DA66FF 0000FFFF
	v_bfe_u32 v54, v48, 12, 16                                 // 000000982F00: D6100036 02411930
	v_bfe_u32 v48, v48, 4, 16                                  // 000000982F08: D6100030 02410930
	.long 0xd72c0037                                           // 000000982F10: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000982F14: 02026EFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000982F1C: BF870214
	v_pk_fma_f16 v51, v51, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000982F20: CC0E0033 0BFC0F33 0000C931
	.long 0xd72c0036                                           // 000000982F2C: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 000000982F30: 02026CFF 83DCD12D
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000982F38: D6220038 03FD0138 00006400
	.long 0xd72c0030                                           // 000000982F44: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 000000982F48: 020260FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000982F50: BF870004
	v_dot2acc_f32_f16 v15, v51, v2                             // 000000982F54: 041E0533
	s_waitcnt vmcnt(2)                                         // 000000982F58: BF890BF7
	v_bfe_u32 v51, v44, 12, 16                                 // 000000982F5C: D6100033 0241192C
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000982F64: D6220037 03FD0137 00006400
	v_sad_u8 v54, v54, 0, 0x6400                               // 000000982F70: D6220036 03FD0136 00006400
	v_dot2acc_f32_f16 v15, v49, v3                             // 000000982F7C: 041E0731
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000982F80: BF870144
	.long 0xd72c0033                                           // 000000982F84: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 000000982F88: 020266FF 83DCD12D
	v_sad_u8 v48, v48, 0, 0x6400                               // 000000982F90: D6220030 03FD0130 00006400
	v_lshlrev_b32_e32 v55, 16, v55                             // 000000982F9C: 306E6E90
	v_and_b32_e32 v54, 0xffff, v54                             // 000000982FA0: 366C6CFF 0000FFFF
	v_and_or_b32 v48, 0xffff, v48, v55                         // 000000982FA8: D6570030 04DE60FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2)                            // 000000982FB4: BF870002
	v_lshl_or_b32 v53, v56, 16, v54                            // 000000982FB8: D6560035 04D92138
	v_sad_u8 v51, v51, 0, 0x6400                               // 000000982FC0: D6220033 03FD0133 00006400
	v_sad_u8 v56, v58, 0, 0x6400                               // 000000982FCC: D6220038 03FD013A 00006400
	.long 0xd72c0036                                           // 000000982FD8: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000982FDC: 020276FF 83DCD12D
	v_pk_fma_f16 v48, v48, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000982FE4: CC0E0030 0BFC0F30 0000C931
	v_pk_fma_f16 v52, v53, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000982FF0: CC0E0034 0BFC0F35 0000C931
	v_dual_mov_b32 v58, v42 :: v_dual_and_b32 v51, 0xffff, v51 // 000000982FFC: CA24012A 3A3266FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000983008: BF8701B2
	v_dot2acc_f32_f16 v13, v52, v1                             // 00000098300C: 041A0334
	v_bfe_u32 v52, v44, 8, 16                                  // 000000983010: D6100034 0241112C
	v_sad_u8 v54, v54, 0, 0x6400                               // 000000983018: D6220036 03FD0136 00006400
	v_dot2acc_f32_f16 v13, v48, v2                             // 000000983024: 041A0530
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000983028: BF870133
	.long 0xd72c0034                                           // 00000098302C: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 000000983030: 020268FF 83DCD12D
	v_pk_fma_f16 v48, v50, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000983038: CC0E0030 0BFC0F32 0000C931
	v_bfe_u32 v50, v45, 12, 16                                 // 000000983044: D6100032 0241192D
	v_dot2acc_f32_f16 v15, v48, v4                             // 00000098304C: 041E0930
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000983050: BF8701C2
	.long 0xd72c0031                                           // 000000983054: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 000000983058: 020264FF 83DCD12D
	v_sad_u8 v52, v52, 0, 0x6400                               // 000000983060: D6220034 03FD0134 00006400
	v_and_b32_e32 v50, 0xffff, v45                             // 00000098306C: 36645AFF 0000FFFF
	v_mov_b32_e32 v48, v31                                     // 000000983074: 7E60031F
	v_lshl_or_b32 v27, v52, 16, v51                            // 000000983078: D656001B 04CD2134
	s_delay_alu instid0(VALU_DEP_3)                            // 000000983080: BF870003
	.long 0xd72c0032                                           // 000000983084: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 000000983088: 020264FF 83DCD12D
	v_sad_u8 v49, v49, 0, 0x6400                               // 000000983090: D6220031 03FD0131 00006400
	s_waitcnt vmcnt(1)                                         // 00000098309C: BF8907F7
	v_bfe_u32 v51, v25, 12, 16                                 // 0000009830A0: D6100033 02411919
	v_bfe_u32 v52, v26, 8, 16                                  // 0000009830A8: D6100034 0241111A
	v_pk_fma_f16 v27, v27, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000009830B0: CC0E001B 0BFC0F1B 0000C931
	v_and_b32_e32 v55, 0xffff, v57                             // 0000009830BC: 366E72FF 0000FFFF
	v_and_b32_e32 v49, 0xffff, v49                             // 0000009830C4: 366262FF 0000FFFF
	.long 0xd72c0033                                           // 0000009830CC: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 0000009830D0: 020266FF 83DCD12D
	v_sad_u8 v50, v50, 0, 0x6400                               // 0000009830D8: D6220032 03FD0132 00006400
	.long 0xd72c0034                                           // 0000009830E4: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 0000009830E8: 020268FF 83DCD12D
	v_lshl_or_b32 v53, v56, 16, v55                            // 0000009830F0: D6560035 04DD2138
	v_mov_b32_e32 v55, v41                                     // 0000009830F8: 7E6E0329
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000009830FC: BF870224
	v_dual_mov_b32 v57, v36 :: v_dual_lshlrev_b32 v50, 16, v50 // 000000983100: CA220124 39326490
	v_mov_b32_e32 v56, v42                                     // 000000983108: 7E70032A
	v_pk_fma_f16 v46, v53, s7, 0xc931 op_sel_hi:[1,0,0]        // 00000098310C: CC0E002E 0BFC0F35 0000C931
	v_bfe_u32 v53, v44, 4, 16                                  // 000000983118: D6100035 0241092C
	v_and_b32_e32 v44, 0xffff, v44                             // 000000983120: 365858FF 0000FFFF
	v_sad_u8 v51, v51, 0, 0x6400                               // 000000983128: D6220033 03FD0133 00006400
	v_sad_u8 v52, v52, 0, 0x6400                               // 000000983134: D6220034 03FD0134 00006400
	v_dot2acc_f32_f16 v13, v46, v3                             // 000000983140: 041A072E
	v_bfe_u32 v46, v45, 8, 16                                  // 000000983144: D610002E 0241112D
	v_bfe_u32 v45, v45, 4, 16                                  // 00000098314C: D610002D 0241092D
	.long 0xd72c002c                                           // 000000983154: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v44, vcc_lo              // 000000983158: 020258FF 83DCD12D
	.long 0xd72c0035                                           // 000000983160: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000983164: 02026AFF 83DCD12D
	v_and_b32_e32 v51, 0xffff, v51                             // 00000098316C: 366666FF 0000FFFF
	.long 0xd72c002e                                           // 000000983174: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 000000983178: 02025CFF 83DCD12D
	.long 0xd72c002d                                           // 000000983180: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v45, vcc_lo              // 000000983184: 02025AFF 83DCD12D
	v_sad_u8 v44, v44, 0, 0x6400                               // 00000098318C: D622002C 03FD012C 00006400
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000983198: D6220035 03FD0135 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009831A4: BF870214
	v_sad_u8 v46, v46, 0, 0x6400                               // 0000009831A8: D622002E 03FD012E 00006400
	v_sad_u8 v45, v45, 0, 0x6400                               // 0000009831B4: D622002D 03FD012D 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009831C0: BF870194
	v_lshlrev_b32_e32 v44, 16, v44                             // 0000009831C4: 30585890
	v_lshl_or_b32 v46, v46, 16, v49                            // 0000009831C8: D656002E 04C5212E
	s_delay_alu instid0(VALU_DEP_3)                            // 0000009831D0: BF870003
	v_and_or_b32 v45, 0xffff, v45, v50                         // 0000009831D4: D657002D 04CA5AFF 0000FFFF
	v_bfe_u32 v49, v26, 12, 16                                 // 0000009831E0: D6100031 0241191A
	v_and_b32_e32 v50, 0xffff, v26                             // 0000009831E8: 366434FF 0000FFFF
	v_bfe_u32 v26, v26, 4, 16                                  // 0000009831F0: D610001A 0241091A
	v_pk_fma_f16 v46, v46, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000009831F8: CC0E002E 0BFC0F2E 0000C931
	v_pk_fma_f16 v45, v45, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000983204: CC0E002D 0BFC0F2D 0000C931
	.long 0xd72c0031                                           // 000000983210: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 000000983214: 020262FF 83DCD12D
	.long 0xd72c0032                                           // 00000098321C: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 000000983220: 020264FF 83DCD12D
	.long 0xd72c001a                                           // 000000983228: D72C001A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v26, vcc_lo              // 00000098322C: 020234FF 83DCD12D
	v_dot2acc_f32_f16 v12, v46, v1                             // 000000983234: 0418032E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000983238: BF870001
	v_dot2acc_f32_f16 v12, v45, v2                             // 00000098323C: 0418052D
	v_bfe_u32 v45, v20, 12, 16                                 // 000000983240: D610002D 02411914
	v_sad_u8 v49, v49, 0, 0x6400                               // 000000983248: D6220031 03FD0131 00006400
	v_sad_u8 v50, v50, 0, 0x6400                               // 000000983254: D6220032 03FD0132 00006400
	v_sad_u8 v26, v26, 0, 0x6400                               // 000000983260: D622001A 03FD011A 00006400
	v_dual_dot2acc_f32_f16 v12, v27, v3 :: v_dual_mov_b32 v27, v37// 00000098326C: CB10071B 0C1A0125
	v_and_or_b32 v44, 0xffff, v53, v44                         // 000000983274: D657002C 04B26AFF 0000FFFF
	v_bfe_u32 v53, v25, 8, 16                                  // 000000983280: D6100035 02411119
	.long 0xd72c002d                                           // 000000983288: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v45, vcc_lo              // 00000098328C: 02025AFF 83DCD12D
	v_and_b32_e32 v49, 0xffff, v49                             // 000000983294: 366262FF 0000FFFF
	v_lshlrev_b32_e32 v50, 16, v50                             // 00000098329C: 30646490
	v_pk_fma_f16 v44, v44, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000009832A0: CC0E002C 0BFC0F2C 0000C931
	.long 0xd72c002e                                           // 0000009832AC: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 0000009832B0: 02026AFF 83DCD12D
	v_bfe_u32 v53, v25, 4, 16                                  // 0000009832B8: D6100035 02410919
	v_and_b32_e32 v25, 0xffff, v25                             // 0000009832C0: 363232FF 0000FFFF
	v_lshl_or_b32 v49, v52, 16, v49                            // 0000009832C8: D6560031 04C52134
	v_sad_u8 v45, v45, 0, 0x6400                               // 0000009832D0: D622002D 03FD012D 00006400
	v_dot2acc_f32_f16 v12, v44, v4                             // 0000009832DC: 0418092C
	s_waitcnt vmcnt(0)                                         // 0000009832E0: BF8903F7
	v_bfe_u32 v52, v19, 12, 16                                 // 0000009832E4: D6100034 02411913
	.long 0xd72c0015                                           // 0000009832EC: D72C0015
	v_cndmask_b32_e32 v1, 0x83dcd12d, v25, vcc_lo              // 0000009832F0: 020232FF 83DCD12D
	v_sad_u8 v46, v46, 0, 0x6400                               // 0000009832F8: D622002E 03FD012E 00006400
	v_and_b32_e32 v45, 0xffff, v45                             // 000000983304: 365A5AFF 0000FFFF
	v_pk_fma_f16 v25, v49, s7, 0xc931 op_sel_hi:[1,0,0]        // 00000098330C: CC0E0019 0BFC0F31 0000C931
	.long 0xd72c0034                                           // 000000983318: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 00000098331C: 020268FF 83DCD12D
	v_mov_b32_e32 v44, v38                                     // 000000983324: 7E580326
	v_lshl_or_b32 v46, v46, 16, v51                            // 000000983328: D656002E 04CD212E
	v_bfe_u32 v51, v20, 8, 16                                  // 000000983330: D6100033 02411114
	v_dot2acc_f32_f16 v11, v25, v1                             // 000000983338: 04160319
	v_sad_u8 v21, v21, 0, 0x6400                               // 00000098333C: D6220015 03FD0115 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000983348: BF870214
	v_pk_fma_f16 v46, v46, s7, 0xc931 op_sel_hi:[1,0,0]        // 00000098334C: CC0E002E 0BFC0F2E 0000C931
	.long 0xd72c0033                                           // 000000983358: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 00000098335C: 020266FF 83DCD12D
	v_sad_u8 v52, v52, 0, 0x6400                               // 000000983364: D6220034 03FD0134 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000983370: BF870194
	v_lshlrev_b32_e32 v21, 16, v21                             // 000000983374: 302A2A90
	v_sad_u8 v51, v51, 0, 0x6400                               // 000000983378: D6220033 03FD0133 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000983384: BF870211
	v_lshl_or_b32 v45, v51, 16, v45                            // 000000983388: D656002D 04B52133
	v_and_b32_e32 v51, 0xffff, v52                             // 000000983390: 366668FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000983398: BF870092
	v_pk_fma_f16 v25, v45, s7, 0xc931 op_sel_hi:[1,0,0]        // 00000098339C: CC0E0019 0BFC0F2D 0000C931
	v_dual_dot2acc_f32_f16 v14, v25, v1 :: v_dual_and_b32 v47, 0xffff, v47// 0000009833A8: CB240319 0E2E5EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000009833B4: BF870121
	.long 0xd72c002f                                           // 0000009833B8: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 0000009833BC: 02025EFF 83DCD12D
	v_mov_b32_e32 v25, v37                                     // 0000009833C4: 7E320325
	v_sad_u8 v47, v47, 0, 0x6400                               // 0000009833C8: D622002F 03FD012F 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009833D4: BF870091
	v_lshlrev_b32_e32 v47, 16, v47                             // 0000009833D8: 305E5E90
	v_and_or_b32 v47, 0xffff, v54, v47                         // 0000009833DC: D657002F 04BE6CFF 0000FFFF
	v_bfe_u32 v54, v19, 4, 16                                  // 0000009833E8: D6100036 02410913
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009833F0: BF870092
	v_pk_fma_f16 v47, v47, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000009833F4: CC0E002F 0BFC0F2F 0000C931
	v_dot2acc_f32_f16 v13, v47, v4                             // 000000983400: 041A092F
	v_mov_b32_e32 v47, v39                                     // 000000983404: 7E5E0327
	v_and_or_b32 v26, 0xffff, v26, v50                         // 000000983408: D657001A 04CA34FF 0000FFFF
	.long 0xd72c0032                                           // 000000983414: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000983418: 02026AFF 83DCD12D
	v_bfe_u32 v53, v19, 8, 16                                  // 000000983420: D6100035 02411113
	v_and_b32_e32 v19, 0xffff, v19                             // 000000983428: 362626FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000983430: BF870194
	v_pk_fma_f16 v26, v26, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000983434: CC0E001A 0BFC0F1A 0000C931
	.long 0xd72c0035                                           // 000000983440: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000983444: 02026AFF 83DCD12D
	v_sad_u8 v49, v50, 0, 0x6400                               // 00000098344C: D6220031 03FD0132 00006400
	v_and_b32_e32 v50, 0xffff, v20                             // 000000983458: 366428FF 0000FFFF
	v_bfe_u32 v20, v20, 4, 16                                  // 000000983460: D6100014 02410914
	v_dual_dot2acc_f32_f16 v11, v26, v2 :: v_dual_mov_b32 v26, v29// 000000983468: CB10051A 0B1A011D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000983470: BF870004
	v_and_or_b32 v1, 0xffff, v49, v21                          // 000000983474: D6570001 045662FF 0000FFFF
	v_mov_b32_e32 v49, v39                                     // 000000983480: 7E620327
	.long 0xd72c0032                                           // 000000983484: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 000000983488: 020264FF 83DCD12D
	.long 0xd72c0014                                           // 000000983490: D72C0014
	v_cndmask_b32_e32 v1, 0x83dcd12d, v20, vcc_lo              // 000000983494: 020228FF 83DCD12D
	v_sad_u8 v52, v53, 0, 0x6400                               // 00000098349C: D6220034 03FD0135 00006400
	v_dot2acc_f32_f16 v11, v46, v3                             // 0000009834A8: 0416072E
	v_mov_b32_e32 v46, v38                                     // 0000009834AC: 7E5C0326
	.long 0xd72c0013                                           // 0000009834B0: D72C0013
	v_cndmask_b32_e32 v1, 0x83dcd12d, v19, vcc_lo              // 0000009834B4: 020226FF 83DCD12D
	v_pk_fma_f16 v1, v1, s7, 0xc931 op_sel_hi:[1,0,0]          // 0000009834BC: CC0E0001 0BFC0F01 0000C931
	v_lshl_or_b32 v45, v52, 16, v51                            // 0000009834C8: D656002D 04CD2134
	v_sad_u8 v50, v50, 0, 0x6400                               // 0000009834D0: D6220032 03FD0132 00006400
	v_sad_u8 v20, v20, 0, 0x6400                               // 0000009834DC: D6220014 03FD0114 00006400
	v_mov_b32_e32 v51, v32                                     // 0000009834E8: 7E660320
	v_dot2acc_f32_f16 v11, v1, v4                              // 0000009834EC: 04160901
	v_pk_fma_f16 v21, v45, s7, 0xc931 op_sel_hi:[1,0,0]        // 0000009834F0: CC0E0015 0BFC0F2D 0000C931
	v_lshlrev_b32_e32 v50, 16, v50                             // 0000009834FC: 30646490
	v_sad_u8 v19, v19, 0, 0x6400                               // 000000983500: D6220013 03FD0113 00006400
	v_dual_mov_b32 v45, v30 :: v_dual_mov_b32 v52, v40         // 00000098350C: CA10011E 2D340128
	v_mov_b32_e32 v53, v41                                     // 000000983514: 7E6A0329
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000983518: BF870244
	v_and_or_b32 v20, 0xffff, v20, v50                         // 00000098351C: D6570014 04CA28FF 0000FFFF
	.long 0xd72c0032                                           // 000000983528: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 00000098352C: 02026CFF 83DCD12D
	v_dual_mov_b32 v54, v33 :: v_dual_lshlrev_b32 v19, 16, v19 // 000000983534: CA220121 36122690
	v_mov_b32_e32 v1, v5                                       // 00000098353C: 7E020305
	v_pk_fma_f16 v20, v20, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000983540: CC0E0014 0BFC0F14 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000098354C: BF870114
	v_sad_u8 v50, v50, 0, 0x6400                               // 000000983550: D6220032 03FD0132 00006400
	v_dot2acc_f32_f16 v14, v20, v2                             // 00000098355C: 041C0514
	v_mov_b32_e32 v20, v28                                     // 000000983560: 7E28031C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000983564: BF870193
	v_and_or_b32 v19, 0xffff, v50, v19                         // 000000983568: D6570013 044E64FF 0000FFFF
	v_dual_dot2acc_f32_f16 v14, v21, v3 :: v_dual_mov_b32 v21, v35// 000000983574: CB100715 0E140123
	v_dual_mov_b32 v50, v40 :: v_dual_mov_b32 v3, v43          // 00000098357C: CA100128 3202012B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000983584: BF870093
	v_pk_fma_f16 v2, v19, s7, 0xc931 op_sel_hi:[1,0,0]         // 000000983588: CC0E0002 0BFC0F13 0000C931
	v_dual_mov_b32 v19, v35 :: v_dual_dot2acc_f32_f16 v14, v2, v4// 000000983594: CA180123 130E0902
	v_mov_b32_e32 v4, v43                                      // 00000098359C: 7E08032B
	v_mov_b32_e32 v2, v34                                      // 0000009835A0: 7E040322
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 0000009835A4: 917E067E
	s_cbranch_execz 57                                         // 0000009835A8: BFA50039 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi4ELi8ELi1ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x1190>
	v_add_nc_u32_e32 v5, 1, v1                                 // 0000009835AC: 4A0A0281
	s_mov_b32 s21, exec_lo                                     // 0000009835B0: BE95007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009835B4: BF870001
	.long 0xd4c9007e                                           // 0000009835B8: D4C9007E
	v_cndmask_b32_e32 v1, v5, v10, vcc_lo                      // 0000009835BC: 02021505
	s_cbranch_execz 64644                                      // 0000009835C0: BFA5FC84 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi4ELi8ELi1ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x2d4>
	.long 0xd73c001c                                           // 0000009835C4: D73C001C
	v_cndmask_b32_e32 v1, 10, v5, vcc_lo                       // 0000009835C8: 02020A8A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009835CC: BF870091
	.long 0xd7006a1c                                           // 0000009835D0: D7006A1C
	v_cndmask_b32_e32 v1, s4, v28, vcc_lo                      // 0000009835D4: 02023804
	v_add_co_ci_u32_e64 v29, null, s5, v29, vcc_lo             // 0000009835D8: D5207C1D 01AA3A05
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009835E0: BF870092
	.long 0xd7006a25                                           // 0000009835E4: D7006A25
	v_cndmask_b32_e32 v1, v28, v24, vcc_lo                     // 0000009835E8: 0202311C
	v_add_co_ci_u32_e64 v38, null, 0, v29, vcc_lo              // 0000009835EC: D5207C26 01AA3A80
	.long 0xd7006a3b                                           // 0000009835F4: D7006A3B
	v_cndmask_b32_e32 v1, v28, v23, vcc_lo                     // 0000009835F8: 02022F1C
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009835FC: BF870001
	v_add_co_ci_u32_e64 v60, null, 0, v29, vcc_lo              // 000000983600: D5207C3C 01AA3A80
	s_clause 0xf                                               // 000000983608: BF85000F
	global_load_b32 v34, v[37:38], off                         // 00000098360C: DC520000 227C0025
	global_load_b32 v36, v[37:38], off offset:128              // 000000983614: DC520080 247C0025
	global_load_b32 v33, v[37:38], off offset:256              // 00000098361C: DC520100 217C0025
	global_load_b32 v32, v[37:38], off offset:384              // 000000983624: DC520180 207C0025
	global_load_b32 v31, v[37:38], off offset:512              // 00000098362C: DC520200 1F7C0025
	global_load_b32 v30, v[37:38], off offset:640              // 000000983634: DC520280 1E7C0025
	global_load_b32 v29, v[37:38], off offset:768              // 00000098363C: DC520300 1D7C0025
	global_load_b32 v28, v[37:38], off offset:896              // 000000983644: DC520380 1C7C0025
	global_load_b32 v43, v[59:60], off                         // 00000098364C: DC520000 2B7C003B
	global_load_b32 v42, v[59:60], off offset:128              // 000000983654: DC520080 2A7C003B
	global_load_b32 v41, v[59:60], off offset:256              // 00000098365C: DC520100 297C003B
	global_load_b32 v40, v[59:60], off offset:384              // 000000983664: DC520180 287C003B
	global_load_b32 v39, v[59:60], off offset:512              // 00000098366C: DC520200 277C003B
	global_load_b32 v38, v[59:60], off offset:640              // 000000983674: DC520280 267C003B
	global_load_b32 v37, v[59:60], off offset:768              // 00000098367C: DC520300 257C003B
	global_load_b32 v35, v[59:60], off offset:896              // 000000983684: DC520380 237C003B
	s_branch 64593                                             // 00000098368C: BFA0FC51 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi4ELi8ELi1ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x2d4>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000983690: 8C7E067E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000983694: BF870009
	s_or_b32 exec_lo, exec_lo, s3                              // 000000983698: 8C7E037E
	s_load_b128 s[4:7], s[0:1], 0x40                           // 00000098369C: F4080100 F8000040
	s_waitcnt vmcnt(23)                                        // 0000009836A4: BF895FF7
	v_dual_mov_b32 v1, v18 :: v_dual_mov_b32 v2, v17           // 0000009836A8: CA100112 01020111
	s_waitcnt vmcnt(7)                                         // 0000009836B0: BF891FF7
	v_dual_mov_b32 v3, v16 :: v_dual_mov_b32 v10, v15          // 0000009836B4: CA100110 030A010F
	v_dual_mov_b32 v4, v13 :: v_dual_mov_b32 v5, v12           // 0000009836BC: CA10010D 0404010C
	s_waitcnt vmcnt(0)                                         // 0000009836C4: BF8903F7
	v_dual_mov_b32 v6, v11 :: v_dual_mov_b32 v19, v14          // 0000009836C8: CA10010B 0612010E
	s_mov_b32 s0, 0x76543210                                   // 0000009836D0: BE8000FF 76543210
	v_cmp_gt_u32_e32 vcc_lo, 16, v9                            // 0000009836D8: 7C981290
	v_permlanex16_b32 v1, v1, s0, 0xfedcba98                   // 0000009836DC: D65C0001 03FC0101 FEDCBA98
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 0000009836E8: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 0000009836F4: D65C0003 03FC0103 FEDCBA98
	v_permlanex16_b32 v10, v10, s0, 0xfedcba98                 // 000000983700: D65C000A 03FC010A FEDCBA98
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 00000098370C: D65C0004 03FC0104 FEDCBA98
	v_permlanex16_b32 v5, v5, s0, 0xfedcba98                   // 000000983718: D65C0005 03FC0105 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 000000983724: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v19, v19, s0, 0xfedcba98                 // 000000983730: D65C0013 03FC0113 FEDCBA98
	s_waitcnt lgkmcnt(0)                                       // 00000098373C: BF89FC07
	s_barrier                                                  // 000000983740: BFBD0000
	buffer_gl0_inv                                             // 000000983744: E0AC0000 00000000
	s_and_saveexec_b32 s0, vcc_lo                              // 00000098374C: BE80206A
	s_cbranch_execz 18                                         // 000000983750: BFA50012 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi4ELi8ELi1ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x129c>
	v_dual_add_f32 v9, v14, v19 :: v_dual_add_f32 v2, v17, v2  // 000000983754: C908270E 09020511
	v_dual_add_f32 v1, v18, v1 :: v_dual_add_f32 v10, v15, v10 // 00000098375C: C9080312 010A150F
	v_lshl_or_b32 v8, v7, 9, v8                                // 000000983764: D6560008 04211307
	v_dual_add_f32 v3, v16, v3 :: v_dual_add_f32 v4, v13, v4   // 00000098376C: C9080710 0304090D
	v_dual_add_f32 v5, v12, v5 :: v_dual_add_f32 v6, v11, v6   // 000000983774: C9080B0C 05060D0B
	ds_store_2addr_b32 v8, v1, v2 offset1:16                   // 00000098377C: D8381000 00020108
	ds_store_2addr_b32 v8, v3, v10 offset0:32 offset1:48       // 000000983784: D8383020 000A0308
	ds_store_2addr_b32 v8, v4, v5 offset0:64 offset1:80        // 00000098378C: D8385040 00050408
	ds_store_2addr_b32 v8, v6, v9 offset0:96 offset1:112       // 000000983794: D8387060 00090608
	s_or_b32 exec_lo, exec_lo, s0                              // 00000098379C: 8C7E007E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000009837A0: BF870009
	s_mov_b32 s21, exec_lo                                     // 0000009837A4: BE95007E
	s_waitcnt lgkmcnt(0)                                       // 0000009837A8: BF89FC07
	s_barrier                                                  // 0000009837AC: BFBD0000
	buffer_gl0_inv                                             // 0000009837B0: E0AC0000 00000000
	v_cmpx_eq_u32_e32 0, v7                                    // 0000009837B8: 7D940E80
	s_cbranch_execz 513                                        // 0000009837BC: BFA50201 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi4ELi8ELi1ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x1ac4>
	v_and_b32_e32 v1, 15, v0                                   // 0000009837C0: 3602008F
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009837C4: BF870001
	v_lshlrev_b32_e32 v16, 2, v1                               // 0000009837C8: 30200282
	ds_load_2addr_b32 v[2:3], v16 offset1:16                   // 0000009837CC: D8DC1000 02000010
	ds_load_2addr_b32 v[4:5], v16 offset0:128 offset1:144      // 0000009837D4: D8DC9080 04000010
	s_waitcnt lgkmcnt(1)                                       // 0000009837DC: BF89FC17
	v_dual_add_f32 v53, 0, v3 :: v_dual_add_f32 v52, 0, v2     // 0000009837E0: C9080680 35340480
	v_add_nc_u32_e32 v48, 0x400, v16                           // 0000009837E8: 4A6020FF 00000400
	v_add_nc_u32_e32 v50, 0x800, v16                           // 0000009837F0: 4A6420FF 00000800
	v_add_nc_u32_e32 v51, 0xc00, v16                           // 0000009837F8: 4A6620FF 00000C00
	s_waitcnt lgkmcnt(0)                                       // 000000983800: BF89FC07
	v_add_f32_e32 v53, v53, v5                                 // 000000983804: 066A0B35
	ds_load_2addr_b32 v[6:7], v16 offset0:32 offset1:48        // 000000983808: D8DC3020 06000010
	ds_load_2addr_b32 v[8:9], v16 offset0:160 offset1:176      // 000000983810: D8DCB0A0 08000010
	ds_load_2addr_b32 v[10:11], v16 offset0:64 offset1:80      // 000000983818: D8DC5040 0A000010
	ds_load_2addr_b32 v[12:13], v16 offset0:192 offset1:208    // 000000983820: D8DCD0C0 0C000010
	ds_load_2addr_b32 v[14:15], v16 offset0:96 offset1:112     // 000000983828: D8DC7060 0E000010
	ds_load_2addr_b32 v[16:17], v16 offset0:224 offset1:240    // 000000983830: D8DCF0E0 10000010
	ds_load_2addr_b32 v[18:19], v48 offset1:16                 // 000000983838: D8DC1000 12000030
	ds_load_2addr_b32 v[20:21], v48 offset0:128 offset1:144    // 000000983840: D8DC9080 14000030
	ds_load_2addr_b32 v[22:23], v50 offset1:16                 // 000000983848: D8DC1000 16000032
	ds_load_2addr_b32 v[24:25], v50 offset0:128 offset1:144    // 000000983850: D8DC9080 18000032
	ds_load_2addr_b32 v[26:27], v51 offset1:16                 // 000000983858: D8DC1000 1A000033
	ds_load_2addr_b32 v[28:29], v51 offset0:128 offset1:144    // 000000983860: D8DC9080 1C000033
	ds_load_2addr_b32 v[30:31], v48 offset0:32 offset1:48      // 000000983868: D8DC3020 1E000030
	ds_load_2addr_b32 v[32:33], v48 offset0:160 offset1:176    // 000000983870: D8DCB0A0 20000030
	ds_load_2addr_b32 v[34:35], v50 offset0:32 offset1:48      // 000000983878: D8DC3020 22000032
	ds_load_2addr_b32 v[36:37], v50 offset0:160 offset1:176    // 000000983880: D8DCB0A0 24000032
	ds_load_2addr_b32 v[38:39], v51 offset0:32 offset1:48      // 000000983888: D8DC3020 26000033
	ds_load_2addr_b32 v[40:41], v51 offset0:160 offset1:176    // 000000983890: D8DCB0A0 28000033
	ds_load_2addr_b32 v[42:43], v48 offset0:64 offset1:80      // 000000983898: D8DC5040 2A000030
	ds_load_2addr_b32 v[44:45], v48 offset0:192 offset1:208    // 0000009838A0: D8DCD0C0 2C000030
	ds_load_2addr_b32 v[46:47], v50 offset0:64 offset1:80      // 0000009838A8: D8DC5040 2E000032
	s_waitcnt lgkmcnt(20)                                      // 0000009838B0: BF89FD47
	v_add_f32_e32 v6, 0, v6                                    // 0000009838B4: 060C0C80
	s_waitcnt lgkmcnt(18)                                      // 0000009838B8: BF89FD27
	v_dual_add_f32 v52, v52, v4 :: v_dual_add_f32 v11, 0, v11  // 0000009838BC: C9080934 340A1680
	ds_load_2addr_b32 v[2:3], v48 offset0:96 offset1:112       // 0000009838C4: D8DC7060 02000030
	ds_load_2addr_b32 v[48:49], v48 offset0:224 offset1:240    // 0000009838CC: D8DCF0E0 30000030
	v_dual_add_f32 v7, 0, v7 :: v_dual_add_f32 v6, v6, v8      // 0000009838D4: C9080E80 07061106
	s_waitcnt lgkmcnt(16)                                      // 0000009838DC: BF89FD07
	v_dual_add_f32 v15, 0, v15 :: v_dual_add_f32 v8, v52, v18  // 0000009838E0: C9081E80 0F082534
	v_add_f32_e32 v10, 0, v10                                  // 0000009838E8: 06141480
	ds_load_2addr_b32 v[4:5], v50 offset0:96 offset1:112       // 0000009838EC: D8DC7060 04000032
	v_add_f32_e32 v18, v53, v19                                // 0000009838F4: 06242735
	v_dual_add_f32 v14, 0, v14 :: v_dual_add_f32 v7, v7, v9    // 0000009838F8: C9081C80 0E061307
	s_waitcnt lgkmcnt(11)                                      // 000000983900: BF89FCB7
	v_add_f32_e32 v6, v6, v30                                  // 000000983904: 060C3D06
	v_add_f32_e32 v9, v10, v12                                 // 000000983908: 0612190A
	v_add_f32_e32 v8, v8, v20                                  // 00000098390C: 06102908
	v_add_f32_e32 v12, v11, v13                                // 000000983910: 06181B0B
	v_dual_add_f32 v18, v18, v21 :: v_dual_add_f32 v7, v7, v31 // 000000983914: C9082B12 12063F07
	s_waitcnt lgkmcnt(5)                                       // 00000098391C: BF89FC57
	v_add_f32_e32 v9, v9, v42                                  // 000000983920: 06125509
	v_dual_add_f32 v8, v8, v22 :: v_dual_add_f32 v13, v14, v16 // 000000983924: C9082D08 080C210E
	v_dual_add_f32 v14, v15, v17 :: v_dual_add_f32 v15, v12, v43// 00000098392C: C908230F 0E0E570C
	v_add_f32_e32 v6, v6, v32                                  // 000000983934: 060C4106
	s_delay_alu instid0(VALU_DEP_3)                            // 000000983938: BF870003
	v_add_f32_e32 v8, v8, v24                                  // 00000098393C: 06103108
	s_waitcnt lgkmcnt(4)                                       // 000000983940: BF89FC47
	v_add_f32_e32 v19, v9, v44                                 // 000000983944: 06265909
	s_waitcnt lgkmcnt(2)                                       // 000000983948: BF89FC27
	v_add_f32_e32 v17, v14, v3                                 // 00000098394C: 0622070E
	v_dual_add_f32 v18, v18, v23 :: v_dual_add_f32 v23, v15, v45// 000000983950: C9082F12 12165B0F
	v_add_f32_e32 v6, v6, v34                                  // 000000983958: 060C4506
	v_add_f32_e32 v16, v13, v2                                 // 00000098395C: 0620050D
	s_waitcnt lgkmcnt(1)                                       // 000000983960: BF89FC17
	v_add_f32_e32 v17, v17, v49                                // 000000983964: 06226311
	v_dual_add_f32 v10, v18, v25 :: v_dual_add_f32 v19, v19, v46// 000000983968: C9083312 0A125D13
	v_dual_add_f32 v23, v23, v47 :: v_dual_add_f32 v6, v6, v36 // 000000983970: C9085F17 17064906
	s_waitcnt lgkmcnt(0)                                       // 000000983978: BF89FC07
	s_delay_alu instid0(VALU_DEP_3)                            // 00000098397C: BF870003
	v_add_f32_e32 v5, v17, v5                                  // 000000983980: 060A0B11
	ds_load_2addr_b32 v[2:3], v51 offset0:192 offset1:208      // 000000983984: D8DCD0C0 02000033
	ds_load_2addr_b32 v[14:15], v51 offset0:224 offset1:240    // 00000098398C: D8DCF0E0 0E000033
	v_add_f32_e32 v18, v7, v33                                 // 000000983994: 06244307
	v_add_f32_e32 v6, v6, v38                                  // 000000983998: 060C4D06
	ds_load_2addr_b32 v[12:13], v51 offset0:96 offset1:112     // 00000098399C: D8DC7060 0C000033
	v_add_f32_e32 v22, v6, v40                                 // 0000009839A4: 062C5106
	ds_load_2addr_b32 v[6:7], v50 offset0:192 offset1:208      // 0000009839A8: D8DCD0C0 06000032
	s_waitcnt lgkmcnt(0)                                       // 0000009839B0: BF89FC07
	v_dual_add_f32 v8, v8, v26 :: v_dual_add_f32 v7, v23, v7   // 0000009839B4: C9083508 08060F17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000009839BC: BF8700C1
	v_add_f32_e32 v20, v8, v28                                 // 0000009839C0: 06283908
	ds_load_2addr_b32 v[8:9], v50 offset0:224 offset1:240      // 0000009839C4: D8DCF0E0 08000032
	s_waitcnt lgkmcnt(0)                                       // 0000009839CC: BF89FC07
	v_dual_add_f32 v10, v10, v27 :: v_dual_add_f32 v5, v5, v9  // 0000009839D0: C908370A 0A041305
	v_add_f32_e32 v21, v10, v29                                // 0000009839D8: 062A3B0A
	ds_load_2addr_b32 v[10:11], v51 offset0:64 offset1:80      // 0000009839DC: D8DC5040 0A000033
	v_add_f32_e32 v5, v5, v13                                  // 0000009839E4: 060A1B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000009839E8: BF8700A1
	v_dual_add_f32 v5, v5, v15 :: v_dual_add_f32 v6, v19, v6   // 0000009839EC: C9081F05 05060D13
	s_waitcnt lgkmcnt(0)                                       // 0000009839F4: BF89FC07
	v_dual_add_f32 v6, v6, v10 :: v_dual_add_f32 v7, v7, v11   // 0000009839F8: C9081506 06061707
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000983A00: BF8701B1
	v_dual_add_f32 v2, v6, v2 :: v_dual_add_f32 v3, v7, v3     // 000000983A04: C9080506 02020707
	v_sub_f32_e32 v7, v20, v21                                 // 000000983A0C: 080E2B14
	v_add_f32_e32 v6, v20, v21                                 // 000000983A10: 060C2B14
	v_add_f32_e32 v10, v2, v3                                  // 000000983A14: 06140702
	v_sub_f32_e32 v2, v2, v3                                   // 000000983A18: 08040702
	v_add_f32_e32 v16, v16, v48                                // 000000983A1C: 06206110
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000983A20: BF870091
	v_add_f32_e32 v4, v16, v4                                  // 000000983A24: 06080910
	v_add_f32_e32 v4, v4, v8                                   // 000000983A28: 06081104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000983A2C: BF870091
	v_add_f32_e32 v4, v4, v12                                  // 000000983A30: 06081904
	v_add_f32_e32 v4, v4, v14                                  // 000000983A34: 06081D04
	v_add_f32_e32 v18, v18, v35                                // 000000983A38: 06244712
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000983A3C: BF870112
	v_dual_add_f32 v11, v4, v5 :: v_dual_and_b32 v14, 1, v0    // 000000983A40: C9240B04 0B0E0081
	v_add_f32_e32 v16, v18, v37                                // 000000983A48: 06204B12
	v_sub_f32_e32 v3, v4, v5                                   // 000000983A4C: 08060B04
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000983A50: BF870213
	.long 0xd44a0000                                           // 000000983A54: D44A0000
	v_cndmask_b32_e32 v1, 0, v14, vcc_lo                       // 000000983A58: 02021C80
	v_add_f32_e32 v5, v10, v11                                 // 000000983A5C: 060A170A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000983A60: BF870214
	v_add_f32_e32 v8, v16, v39                                 // 000000983A64: 06104F10
	v_add_f32_e32 v13, v2, v3                                  // 000000983A68: 061A0702
	v_dual_sub_f32 v2, v2, v3 :: v_dual_and_b32 v3, 2, v0      // 000000983A6C: C9640702 02020082
	v_sub_f32_e32 v10, v10, v11                                // 000000983A74: 0814170A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000983A78: BF870194
	v_add_f32_e32 v8, v8, v41                                  // 000000983A7C: 06105308
	.long 0xd44a0001                                           // 000000983A80: D44A0001
	v_cndmask_b32_e32 v1, 0, v3, vcc_lo                        // 000000983A84: 02020680
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000983A88: BF870122
	v_add_f32_e32 v9, v22, v8                                  // 000000983A8C: 06121116
	v_sub_f32_e32 v8, v22, v8                                  // 000000983A90: 08101116
	v_add_f32_e32 v4, v6, v9                                   // 000000983A94: 06081306
	v_sub_f32_e32 v6, v6, v9                                   // 000000983A98: 080C1306
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000983A9C: BF8701A2
	v_dual_add_f32 v12, v7, v8 :: v_dual_add_f32 v9, v4, v5    // 000000983AA0: C9081107 0C080B04
	v_sub_f32_e32 v5, v4, v5                                   // 000000983AA8: 080A0B04
	v_add_f32_e32 v3, v6, v10                                  // 000000983AAC: 06061506
	v_sub_f32_e32 v10, v6, v10                                 // 000000983AB0: 08141506
	v_and_b32_e32 v6, 4, v0                                    // 000000983AB4: 360C0084
	v_mov_b32_dpp v11, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000983AB8: 7E1602FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 000000983AC0: D5010009 20021309
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000983AC8: BF870113
	.long 0xd44a0003                                           // 000000983ACC: D44A0003
	v_cndmask_b32_e32 v1, 0, v6, vcc_lo                        // 000000983AD0: 02020C80
	v_dual_add_f32 v4, v9, v11 :: v_dual_sub_f32 v9, v12, v13  // 000000983AD4: C90A1709 04081B0C
	v_dual_sub_f32 v7, v7, v8 :: v_dual_add_f32 v8, v12, v13   // 000000983ADC: C9481107 07081B0C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000983AE4: BF8701A2
	v_mov_b32_dpp v11, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000983AE8: 7E1602FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000983AF0: D5010004 20060904
	v_add_f32_e32 v13, v7, v2                                  // 000000983AF8: 061A0507
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000983AFC: BF870224
	v_mov_b32_dpp v14, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000983B00: 7E1C02FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, s0                          // 000000983B08: D5010008 20021108
	v_dual_sub_f32 v7, v7, v2 :: v_dual_add_f32 v4, v4, v11    // 000000983B10: C9480507 07041704
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000983B18: BF870194
	v_mov_b32_dpp v11, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000983B1C: 7E1602FA FF01610D
	v_add_f32_e32 v8, v8, v14                                  // 000000983B24: 06101D08
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000983B28: BF8701A3
	v_mov_b32_dpp v6, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000983B2C: 7E0C02FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000983B34: D5010004 200E0904
	v_mov_b32_dpp v12, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000983B3C: 7E1802FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s1                          // 000000983B44: D5010008 20061108
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000983B4C: BF8701C1
	v_add_f32_e32 v8, v8, v12                                  // 000000983B50: 06101908
	v_cndmask_b32_e64 v12, -v13, v13, s0                       // 000000983B54: D501000C 20021B0D
	v_mov_b32_dpp v13, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000983B5C: 7E1A02FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 000000983B64: D5010003 20020703
	v_add_f32_e32 v11, v12, v11                                // 000000983B6C: 0616170C
	v_mov_b32_dpp v12, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000983B70: 7E1802FA FF016408
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000983B78: BF870223
	v_add_f32_e32 v3, v3, v13                                  // 000000983B7C: 06061B03
	v_cndmask_b32_e64 v8, -v8, v8, s3                          // 000000983B80: D5010008 200E1108
	v_mov_b32_dpp v13, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000983B88: 7E1A02FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 000000983B90: D501000B 2006170B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000983B98: BF870254
	v_mov_b32_dpp v14, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000983B9C: 7E1C02FA FF016203
	v_cndmask_b32_e64 v15, -v3, v3, s1                         // 000000983BA4: D501000F 20060703
	v_add_f32_e32 v3, v4, v6                                   // 000000983BAC: 06060D04
	v_add_f32_e32 v6, v8, v12                                  // 000000983BB0: 060C1908
	v_add_f32_e32 v8, v11, v13                                 // 000000983BB4: 06101B0B
	v_add_f32_e32 v11, v15, v14                                // 000000983BB8: 06161D0F
	v_mov_b32_dpp v14, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000983BBC: 7E1C02FA FF016105
	v_cndmask_b32_e64 v15, -v5, v5, s0                         // 000000983BC4: D501000F 20020B05
	s_delay_alu instid0(VALU_DEP_4)                            // 000000983BCC: BF870004
	v_mov_b32_dpp v12, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000983BD0: 7E1802FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, s3                          // 000000983BD8: D5010008 200E1108
	v_mov_b32_dpp v13, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000983BE0: 7E1A02FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s3                       // 000000983BE8: D501000B 200E170B
	v_mov_b32_dpp v2, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000983BF0: 7E0402FA FF016803
	v_mov_b32_dpp v4, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000983BF8: 7E0802FA FF016806
	v_add_f32_e32 v5, v8, v12                                  // 000000983C00: 060A1908
	v_mov_b32_dpp v8, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000983C04: 7E1002FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 000000983C0C: D5010009 20021309
	v_add_f32_e32 v12, v15, v14                                // 000000983C14: 06181D0F
	v_mov_b32_dpp v14, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000983C18: 7E1C02FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, s0                       // 000000983C20: D501000A 2002150A
	v_mov_b32_dpp v15, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000983C28: 7E1E02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s0                          // 000000983C30: D5010007 20020F07
	v_add_f32_e32 v8, v9, v8                                   // 000000983C38: 06101109
	v_mov_b32_dpp v9, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000983C3C: 7E1202FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 000000983C44: D501000C 2006190C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000983C4C: BF870214
	v_dual_add_f32 v10, v10, v14 :: v_dual_add_f32 v7, v7, v15 // 000000983C50: C9081D0A 0A061F07
	v_mov_b32_dpp v14, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000983C58: 7E1C02FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s1                          // 000000983C60: D5010008 20061108
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000983C68: BF870214
	v_add_f32_e32 v9, v12, v9                                  // 000000983C6C: 0612130C
	v_mov_b32_dpp v12, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000983C70: 7E1802FA FF01620A
	v_mov_b32_dpp v15, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000983C78: 7E1E02FA FF016207
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 000000983C80: D501000A 2006150A
	v_cndmask_b32_e64 v16, -v7, v7, s1                         // 000000983C88: D5010010 20060F07
	v_dual_add_f32 v8, v8, v14 :: v_dual_add_f32 v7, v11, v13  // 000000983C90: C9081D08 08061B0B
	v_mov_b32_dpp v11, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000983C98: 7E1602FA FF016409
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000983CA0: BF870214
	v_add_f32_e32 v10, v10, v12                                // 000000983CA4: 0614190A
	v_add_f32_e32 v12, v16, v15                                // 000000983CA8: 06181F10
	s_delay_alu instid0(VALU_DEP_4)                            // 000000983CAC: BF870004
	v_mov_b32_dpp v13, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000983CB0: 7E1A02FA FF016408
	v_cndmask_b32_e64 v15, -v8, v8, s3                         // 000000983CB8: D501000F 200E1108
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 000000983CC0: D5010009 200E1309
	v_mov_b32_dpp v17, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000983CC8: 7E2202FA FF01640A
	v_mov_b32_dpp v18, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000983CD0: 7E2402FA FF01640C
	v_cndmask_b32_e64 v10, -v10, v10, s3                       // 000000983CD8: D501000A 200E150A
	v_cndmask_b32_e64 v12, -v12, v12, s3                       // 000000983CE0: D501000C 200E190C
	v_add_f32_e32 v14, v9, v11                                 // 000000983CE8: 061C1709
	v_add_f32_e32 v16, v15, v13                                // 000000983CEC: 06201B0F
	v_mov_b32_dpp v8, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000983CF0: 7E1002FA FF016807
	v_add_f32_e32 v15, v10, v17                                // 000000983CF8: 061E230A
	v_add_f32_e32 v17, v12, v18                                // 000000983CFC: 0622250C
	v_mov_b32_dpp v9, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000983D00: 7E1202FA FF016805
	v_mov_b32_dpp v10, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000983D08: 7E1402FA FF01680E
	v_mov_b32_dpp v11, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000983D10: 7E1602FA FF016810
	v_mov_b32_dpp v12, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000983D18: 7E1802FA FF01680F
	v_mov_b32_dpp v13, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000983D20: 7E1A02FA FF016811
	s_and_b32 exec_lo, exec_lo, vcc_lo                         // 000000983D28: 8B7E6A7E
	s_cbranch_execz 165                                        // 000000983D2C: BFA500A5 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi4ELi8ELi1ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x1ac4>
	v_and_b32_e32 v26, 8, v0                                   // 000000983D30: 36340088
	s_mul_i32 s0, s8, 0x1400                                   // 000000983D34: 9600FF08 00001400
	s_mul_hi_i32 s1, s8, 0x1400                                // 000000983D3C: 9701FF08 00001400
	s_add_u32 s3, s10, s0                                      // 000000983D44: 8003000A
	s_addc_u32 s8, s11, s1                                     // 000000983D48: 8208010B
	v_cmp_eq_u32_e32 vcc_lo, 0, v26                            // 000000983D4C: 7C943480
	s_lshl_b32 s0, s9, 7                                       // 000000983D50: 84008709
	.long 0x7f243880                                           // 000000983D54: 7F243880
	s_ashr_i32 s1, s0, 31                                      // 000000983D58: 86019F00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000983D5C: BF870009
	s_lshl_b64 s[0:1], s[0:1], 1                               // 000000983D60: 84808100
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 000000983D64: D5010006 21AA0D06
	v_lshlrev_b32_e32 v1, 1, v1                                // 000000983D6C: 30020281
	s_add_u32 s10, s3, s0                                      // 000000983D70: 800A0003
	s_addc_u32 s11, s8, s1                                     // 000000983D74: 820B0108
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000983D78: D5010003 21AA0703
	v_add_f32_e32 v4, v6, v4                                   // 000000983D80: 06080906
	s_clause 0x7                                               // 000000983D84: BF850007
	global_load_d16_b16 v18, v1, s[10:11] offset:32            // 000000983D88: DC820020 120A0001
	global_load_d16_b16 v19, v1, s[10:11]                      // 000000983D90: DC820000 130A0001
	global_load_d16_b16 v20, v1, s[10:11] offset:64            // 000000983D98: DC820040 140A0001
	global_load_d16_b16 v21, v1, s[10:11] offset:96            // 000000983DA0: DC820060 150A0001
	global_load_d16_b16 v22, v1, s[10:11] offset:128           // 000000983DA8: DC820080 160A0001
	global_load_d16_b16 v23, v1, s[10:11] offset:160           // 000000983DB0: DC8200A0 170A0001
	global_load_d16_b16 v24, v1, s[10:11] offset:192           // 000000983DB8: DC8200C0 180A0001
	global_load_d16_b16 v25, v1, s[10:11] offset:224           // 000000983DC0: DC8200E0 190A0001
	v_cndmask_b32_e64 v6, -v7, v7, vcc_lo                      // 000000983DC8: D5010006 21AA0F07
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000983DD0: D5010005 21AA0B05
	v_cndmask_b32_e64 v7, -v16, v16, vcc_lo                    // 000000983DD8: D5010007 21AA2110
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 000000983DE0: D501000E 21AA1D0E
	v_cndmask_b32_e64 v16, -v17, v17, vcc_lo                   // 000000983DE8: D5010010 21AA2311
	v_dual_add_f32 v2, v3, v2 :: v_dual_mul_f32 v3, 0x3db504f3, v4// 000000983DF0: C9060503 020208FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000983DFC: BF8701B4
	v_dual_add_f32 v4, v6, v8 :: v_dual_add_f32 v7, v7, v11    // 000000983E00: C9081106 04061707
	v_cndmask_b32_e64 v15, -v15, v15, vcc_lo                   // 000000983E08: D501000F 21AA1F0F
	v_dual_add_f32 v5, v5, v9 :: v_dual_add_f32 v6, v14, v10   // 000000983E10: C9081305 0506150E
	v_dual_add_f32 v9, v16, v13 :: v_dual_mul_f32 v4, 0x3db504f3, v4// 000000983E18: C9061B10 090408FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000983E24: BF8701B2
	v_dual_add_f32 v8, v15, v12 :: v_dual_mul_f32 v5, 0x3db504f3, v5// 000000983E28: C906190F 08040AFF 3DB504F3
	s_waitcnt vmcnt(5)                                         // 000000983E34: BF8917F7
	.long 0x7f283992                                           // 000000983E38: 7F283992
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 000000983E3C: 101212FF 3DB504F3
	s_waitcnt vmcnt(4)                                         // 000000983E44: BF8913F7
	.long 0x7f2a3992                                           // 000000983E48: 7F2A3992
	v_dual_mul_f32 v2, 0x3db504f3, v2 :: v_dual_mul_f32 v7, 0x3db504f3, v7// 000000983E4C: C8C604FF 02060EFF 3DB504F3
	.long 0x7f263992                                           // 000000983E58: 7F263992
	s_waitcnt vmcnt(3)                                         // 000000983E5C: BF890FF7
	.long 0x7f2c3992                                           // 000000983E60: 7F2C3992
	s_mul_i32 s8, s20, 0x1400                                  // 000000983E64: 9608FF14 00001400
	s_mul_hi_i32 s3, s20, 0x1400                               // 000000983E6C: 9703FF14 00001400
	s_add_u32 s8, s12, s8                                      // 000000983E74: 8008080C
	s_addc_u32 s3, s13, s3                                     // 000000983E78: 8203030D
	s_add_u32 s0, s8, s0                                       // 000000983E7C: 80000008
	s_addc_u32 s1, s3, s1                                      // 000000983E80: 82010103
	v_fma_mix_f32 v3, v18, v3, neg(0) op_sel_hi:[1,0,0]        // 000000983E84: CC200003 8A020712
	v_fma_mix_f32 v2, v19, v2, neg(0) op_sel_hi:[1,0,0]        // 000000983E8C: CC200002 8A020513
	v_fma_mix_f32 v4, v20, v4, neg(0) op_sel_hi:[1,0,0]        // 000000983E94: CC200004 8A020914
	v_fma_mix_f32 v5, v21, v5, neg(0) op_sel_hi:[1,0,0]        // 000000983E9C: CC200005 8A020B15
	s_delay_alu instid0(VALU_DEP_4)                            // 000000983EA4: BF870004
	.long 0x7e243983                                           // 000000983EA8: 7E243983
	s_waitcnt vmcnt(2)                                         // 000000983EAC: BF890BF7
	v_fma_mix_f32 v7, v23, v7, neg(0) op_sel_hi:[1,0,0]        // 000000983EB0: CC200007 8A020F17
	.long 0x7e283984                                           // 000000983EB8: 7E283984
	v_mul_f32_e32 v6, 0x3db504f3, v6                           // 000000983EBC: 100C0CFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000983EC4: BF8903F7
	v_fma_mix_f32 v9, v25, v9, neg(0) op_sel_hi:[1,0,0]        // 000000983EC8: CC200009 8A021319
	v_and_b32_e32 v10, 1, v18                                  // 000000983ED0: 36142481
	.long 0x7e243985                                           // 000000983ED4: 7E243985
	v_mul_f32_e32 v8, 0x3db504f3, v8                           // 000000983ED8: 101010FF 3DB504F3
	v_and_b32_e32 v13, 1, v20                                  // 000000983EE0: 361A2881
	v_fma_mix_f32 v6, v22, v6, neg(0) op_sel_hi:[1,0,0]        // 000000983EE4: CC200006 8A020D16
	.long 0x7e263982                                           // 000000983EEC: 7E263982
	v_and_b32_e32 v11, 1, v18                                  // 000000983EF0: 36162481
	v_fma_mix_f32 v8, v24, v8, neg(0) op_sel_hi:[1,0,0]        // 000000983EF4: CC200008 8A021118
	.long 0x7e243987                                           // 000000983EFC: 7E243987
	.long 0x7e2a3986                                           // 000000983F00: 7E2A3986
	v_and_b32_e32 v12, 1, v19                                  // 000000983F04: 36182681
	v_add3_u32 v3, v3, v10, 0x7fff                             // 000000983F08: D6550003 03FE1503 00007FFF
	.long 0x7e2c3988                                           // 000000983F14: 7E2C3988
	v_and_b32_e32 v15, 1, v18                                  // 000000983F18: 361E2481
	.long 0x7e243989                                           // 000000983F1C: 7E243989
	v_and_b32_e32 v14, 1, v21                                  // 000000983F20: 361C2A81
	v_add3_u32 v2, v2, v12, 0x7fff                             // 000000983F24: D6550002 03FE1902 00007FFF
	v_and_b32_e32 v16, 1, v22                                  // 000000983F30: 36202C81
	v_add3_u32 v4, v4, v13, 0x7fff                             // 000000983F34: D6550004 03FE1B04 00007FFF
	v_and_b32_e32 v10, 1, v18                                  // 000000983F40: 36142481
	v_add3_u32 v5, v5, v11, 0x7fff                             // 000000983F44: D6550005 03FE1705 00007FFF
	v_add3_u32 v6, v6, v14, 0x7fff                             // 000000983F50: D6550006 03FE1D06 00007FFF
	v_add3_u32 v8, v8, v16, 0x7fff                             // 000000983F5C: D6550008 03FE2108 00007FFF
	v_add3_u32 v7, v7, v15, 0x7fff                             // 000000983F68: D6550007 03FE1F07 00007FFF
	v_add3_u32 v9, v9, v10, 0x7fff                             // 000000983F74: D6550009 03FE1509 00007FFF
	s_clause 0x7                                               // 000000983F80: BF850007
	global_store_d16_hi_b16 v1, v2, s[0:1]                     // 000000983F84: DC960000 00000201
	global_store_d16_hi_b16 v1, v3, s[0:1] offset:32           // 000000983F8C: DC960020 00000301
	global_store_d16_hi_b16 v1, v4, s[0:1] offset:64           // 000000983F94: DC960040 00000401
	global_store_d16_hi_b16 v1, v5, s[0:1] offset:96           // 000000983F9C: DC960060 00000501
	global_store_d16_hi_b16 v1, v6, s[0:1] offset:128          // 000000983FA4: DC960080 00000601
	global_store_d16_hi_b16 v1, v7, s[0:1] offset:160          // 000000983FAC: DC9600A0 00000701
	global_store_d16_hi_b16 v1, v8, s[0:1] offset:192          // 000000983FB4: DC9600C0 00000801
	global_store_d16_hi_b16 v1, v9, s[0:1] offset:224          // 000000983FBC: DC9600E0 00000901
	s_or_b32 exec_lo, exec_lo, s21                             // 000000983FC4: 8C7E157E
	s_mul_hi_i32 s0, s2, 0x51eb851f                            // 000000983FC8: 9700FF02 51EB851F
	s_waitcnt_vscnt null, 0x0                                  // 000000983FD0: BC7C0000
	buffer_gl1_inv                                             // 000000983FD4: E0B00000 00000000
	buffer_gl0_inv                                             // 000000983FDC: E0AC0000 00000000
	s_lshr_b32 s1, s0, 31                                      // 000000983FE4: 85019F00
	s_ashr_i32 s0, s0, 6                                       // 000000983FE8: 86008600
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000983FEC: BF870009
	s_add_i32 s8, s0, s1                                       // 000000983FF0: 81080100
	.long 0xd44a0000                                           // 000000983FF4: D44A0000
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 000000983FF8: 02020080
	s_mul_i32 s1, s8, 20                                       // 000000983FFC: 96019408
	s_barrier                                                  // 000000984000: BFBD0000
	s_add_i32 s2, s9, s1                                       // 000000984004: 81020109
	buffer_gl0_inv                                             // 000000984008: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 000000984010: BE812000
	s_cbranch_execz 29                                         // 000000984014: BFA5001D <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi4ELi8ELi1ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x1b8c>
	s_mov_b32 s11, exec_lo                                     // 000000984018: BE8B007E
	s_mov_b32 s10, exec_lo                                     // 00000098401C: BE8A007E
	.long 0xd71f0001                                           // 000000984020: D71F0001
	v_cndmask_b32_e32 v0, s11, v128, vcc_lo                    // 000000984024: 0201000B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000984028: BF870001
	v_cmpx_eq_u32_e32 0, v1                                    // 00000098402C: 7D940280
	s_cbranch_execz 11                                         // 000000984030: BFA5000B <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi4ELi8ELi1ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x1b60>
	s_ashr_i32 s3, s2, 31                                      // 000000984034: 86039F02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000984038: BF870499
	s_lshl_b64 s[20:21], s[2:3], 2                             // 00000098403C: 84948202
	s_add_u32 s20, s6, s20                                     // 000000984040: 80141406
	s_addc_u32 s21, s7, s21                                    // 000000984044: 82151507
	s_bcnt1_i32_b32 s3, s11                                    // 000000984048: BE83180B
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000098404C: BF870009
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, s3              // 000000984050: CA100080 02020003
	global_atomic_add_u32 v2, v2, v3, s[20:21] glc             // 000000984058: DCD64000 02140302
	s_or_b32 exec_lo, exec_lo, s10                             // 000000984060: 8C7E0A7E
	s_waitcnt vmcnt(0)                                         // 000000984064: BF8903F7
	v_readfirstlane_b32 s3, v2                                 // 000000984068: 7E060502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000098406C: BF870091
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s3, v1       // 000000984070: CA200080 02000203
	v_cmp_eq_u32_e32 vcc_lo, 9, v1                             // 000000984078: 7C940289
	v_cndmask_b32_e64 v1, 0, 1, vcc_lo                         // 00000098407C: D5010001 01A90280
	ds_store_b32 v2, v1 offset:4096                            // 000000984084: D8341000 00000102
	s_or_b32 exec_lo, exec_lo, s1                              // 00000098408C: 8C7E017E
	v_mov_b32_e32 v1, 0                                        // 000000984090: 7E020280
	s_waitcnt lgkmcnt(0)                                       // 000000984094: BF89FC07
	s_barrier                                                  // 000000984098: BFBD0000
	buffer_gl0_inv                                             // 00000098409C: E0AC0000 00000000
	ds_load_b32 v1, v1 offset:4096                             // 0000009840A4: D8D81000 01000001
	s_waitcnt lgkmcnt(0)                                       // 0000009840AC: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 0000009840B0: 7C940280
	s_cbranch_vccnz 287                                        // 0000009840B4: BFA4011F <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi4ELi8ELi1ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x2034>
	s_mov_b32 s1, exec_lo                                      // 0000009840B8: BE81007E
	buffer_gl1_inv                                             // 0000009840BC: E0B00000 00000000
	buffer_gl0_inv                                             // 0000009840C4: E0AC0000 00000000
	v_cmpx_gt_u32_e32 64, v0                                   // 0000009840CC: 7D9800C0
	s_cbranch_execz 269                                        // 0000009840D0: BFA5010D <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi4ELi8ELi1ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x2008>
	v_lshlrev_b32_e32 v0, 1, v0                                // 0000009840D4: 30000081
	s_mul_i32 s10, s8, 10                                      // 0000009840D8: 960A8A08
	v_mov_b32_e32 v6, 0                                        // 0000009840DC: 7E0C0280
	s_ashr_i32 s11, s10, 31                                    // 0000009840E0: 860B9F0A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009840E4: BF870092
	v_lshl_or_b32 v0, s9, 7, v0                                // 0000009840E8: D6560000 04010E09
	v_ashrrev_i32_e32 v1, 31, v0                               // 0000009840F0: 3402009F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000009840F4: BF870121
	.long 0xd73c0002                                           // 0000009840F8: D73C0002
	v_cndmask_b32_e32 v1, 1, v0, vcc_lo                        // 0000009840FC: 02020081
	v_mad_i64_i32 v[0:1], null, 0xa00, s8, v[0:1]              // 000000984100: D6FF7C00 040010FF 00000A00
	.long 0xd7006a02                                           // 00000098410C: D7006A02
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 000000984110: 0202040C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000984114: BF870191
	v_add_co_ci_u32_e64 v3, null, s13, v3, vcc_lo              // 000000984118: D5207C03 01AA060D
	.long 0xd73c0000                                           // 000000984120: D73C0000
	v_cndmask_b32_e32 v1, 1, v0, vcc_lo                        // 000000984124: 02020081
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000984128: BF8704A2
	v_mad_i64_i32 v[2:3], null, 0x1400, s10, v[2:3]            // 00000098412C: D6FF7C02 040814FF 00001400
	s_lshl_b64 s[10:11], s[10:11], 2                           // 000000984138: 848A820A
	s_add_u32 s10, s14, s10                                    // 00000098413C: 800A0A0E
	s_addc_u32 s11, s15, s11                                   // 000000984140: 820B0B0F
	s_ashr_i32 s9, s8, 31                                      // 000000984144: 86099F08
	global_load_b32 v7, v6, s[10:11]                           // 000000984148: DC520000 070A0006
	global_load_b32 v4, v[2:3], off glc                        // 000000984150: DC524000 047C0002
	s_lshl_b64 s[8:9], s[8:9], 2                               // 000000984158: 84888208
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000098415C: BF870009
	s_add_u32 s8, s18, s8                                      // 000000984160: 80080812
	s_addc_u32 s9, s19, s9                                     // 000000984164: 82090913
	s_waitcnt vmcnt(0)                                         // 000000984168: BF8903F7
	v_lshlrev_b32_e32 v8, 16, v4                               // 00000098416C: 30100890
	v_and_b32_e32 v9, 0xffff0000, v4                           // 000000984170: 361208FF FFFF0000
	.long 0xd7006a04                                           // 000000984178: D7006A04
	v_cndmask_b32_e32 v1, 0x1000, v2, vcc_lo                   // 00000098417C: 020204FF 00001000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000984184: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v3, vcc_lo                // 000000984188: D5207C05 01AA0680
	v_mul_f32_e32 v8, v7, v8                                   // 000000984190: 10101107
	v_mul_f32_e32 v7, v7, v9                                   // 000000984194: 100E1307
	global_load_b32 v9, v6, s[10:11] offset:4                  // 000000984198: DC520004 090A0006
	global_load_b32 v4, v[4:5], off offset:1024 glc            // 0000009841A0: DC524400 047C0004
	s_waitcnt vmcnt(0)                                         // 0000009841A8: BF8903F7
	v_dual_add_f32 v7, 0, v7 :: v_dual_lshlrev_b32 v10, 16, v4 // 0000009841AC: C9220E80 070A0890
	v_mul_f32_e32 v10, v9, v10                                 // 0000009841B4: 10141509
	v_and_b32_e32 v11, 0xffff0000, v4                          // 0000009841B8: 361608FF FFFF0000
	.long 0xd7006a04                                           // 0000009841C0: D7006A04
	v_cndmask_b32_e32 v1, 0x2000, v2, vcc_lo                   // 0000009841C4: 020204FF 00002000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009841CC: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v3, vcc_lo                // 0000009841D0: D5207C05 01AA0680
	v_mul_f32_e32 v9, v9, v11                                  // 0000009841D8: 10121709
	global_load_b32 v11, v6, s[10:11] offset:8                 // 0000009841DC: DC520008 0B0A0006
	global_load_b32 v4, v[4:5], off offset:2048 glc            // 0000009841E4: DC524800 047C0004
	s_waitcnt vmcnt(0)                                         // 0000009841EC: BF8903F7
	v_dual_add_f32 v7, v7, v9 :: v_dual_lshlrev_b32 v12, 16, v4// 0000009841F0: C9221307 070C0890
	v_and_b32_e32 v13, 0xffff0000, v4                          // 0000009841F8: 361A08FF FFFF0000
	.long 0xd7006a04                                           // 000000984200: D7006A04
	v_cndmask_b32_e32 v1, 0x3000, v2, vcc_lo                   // 000000984204: 020204FF 00003000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000098420C: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v3, vcc_lo                // 000000984210: D5207C05 01AA0680
	v_mul_f32_e32 v12, v11, v12                                // 000000984218: 1018190B
	v_mul_f32_e32 v11, v11, v13                                // 00000098421C: 10161B0B
	global_load_b32 v13, v6, s[10:11] offset:12                // 000000984220: DC52000C 0D0A0006
	global_load_b32 v4, v[4:5], off offset:3072 glc            // 000000984228: DC524C00 047C0004
	s_waitcnt vmcnt(0)                                         // 000000984230: BF8903F7
	v_dual_add_f32 v7, v7, v11 :: v_dual_lshlrev_b32 v14, 16, v4// 000000984234: C9221707 070E0890
	v_and_b32_e32 v15, 0xffff0000, v4                          // 00000098423C: 361E08FF FFFF0000
	.long 0xd7006a04                                           // 000000984244: D7006A04
	v_cndmask_b32_e32 v1, 0x5000, v2, vcc_lo                   // 000000984248: 020204FF 00005000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000984250: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v3, vcc_lo                // 000000984254: D5207C05 01AA0680
	v_mul_f32_e32 v14, v13, v14                                // 00000098425C: 101C1D0D
	v_mul_f32_e32 v13, v13, v15                                // 000000984260: 101A1F0D
	global_load_b32 v15, v6, s[10:11] offset:16                // 000000984264: DC520010 0F0A0006
	global_load_b32 v4, v[4:5], off glc                        // 00000098426C: DC524000 047C0004
	s_waitcnt vmcnt(0)                                         // 000000984274: BF8903F7
	v_dual_add_f32 v7, v7, v13 :: v_dual_lshlrev_b32 v16, 16, v4// 000000984278: C9221B07 07100890
	v_and_b32_e32 v17, 0xffff0000, v4                          // 000000984280: 362208FF FFFF0000
	.long 0xd7006a04                                           // 000000984288: D7006A04
	v_cndmask_b32_e32 v1, 0x6000, v2, vcc_lo                   // 00000098428C: 020204FF 00006000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000984294: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v3, vcc_lo                // 000000984298: D5207C05 01AA0680
	v_mul_f32_e32 v16, v15, v16                                // 0000009842A0: 1020210F
	v_mul_f32_e32 v15, v15, v17                                // 0000009842A4: 101E230F
	global_load_b32 v17, v6, s[10:11] offset:20                // 0000009842A8: DC520014 110A0006
	global_load_b32 v4, v[4:5], off offset:1024 glc            // 0000009842B0: DC524400 047C0004
	s_waitcnt vmcnt(0)                                         // 0000009842B8: BF8903F7
	v_dual_add_f32 v7, v7, v15 :: v_dual_lshlrev_b32 v18, 16, v4// 0000009842BC: C9221F07 07120890
	v_and_b32_e32 v19, 0xffff0000, v4                          // 0000009842C4: 362608FF FFFF0000
	.long 0xd7006a04                                           // 0000009842CC: D7006A04
	v_cndmask_b32_e32 v1, 0x7000, v2, vcc_lo                   // 0000009842D0: 020204FF 00007000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009842D8: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v3, vcc_lo                // 0000009842DC: D5207C05 01AA0680
	v_mul_f32_e32 v18, v17, v18                                // 0000009842E4: 10242511
	v_mul_f32_e32 v17, v17, v19                                // 0000009842E8: 10222711
	global_load_b32 v19, v6, s[10:11] offset:24                // 0000009842EC: DC520018 130A0006
	global_load_b32 v4, v[4:5], off offset:2048 glc            // 0000009842F4: DC524800 047C0004
	s_waitcnt vmcnt(0)                                         // 0000009842FC: BF8903F7
	v_dual_add_f32 v7, v7, v17 :: v_dual_lshlrev_b32 v20, 16, v4// 000000984300: C9222307 07140890
	v_and_b32_e32 v21, 0xffff0000, v4                          // 000000984308: 362A08FF FFFF0000
	.long 0xd7006a04                                           // 000000984310: D7006A04
	v_cndmask_b32_e32 v1, 0x8000, v2, vcc_lo                   // 000000984314: 020204FF 00008000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000098431C: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v3, vcc_lo                // 000000984320: D5207C05 01AA0680
	v_mul_f32_e32 v20, v19, v20                                // 000000984328: 10282913
	v_mul_f32_e32 v19, v19, v21                                // 00000098432C: 10262B13
	global_load_b32 v21, v6, s[10:11] offset:28                // 000000984330: DC52001C 150A0006
	global_load_b32 v4, v[4:5], off offset:3072 glc            // 000000984338: DC524C00 047C0004
	s_waitcnt vmcnt(0)                                         // 000000984340: BF8903F7
	v_dual_add_f32 v7, v7, v19 :: v_dual_lshlrev_b32 v22, 16, v4// 000000984344: C9222707 07160890
	v_and_b32_e32 v23, 0xffff0000, v4                          // 00000098434C: 362E08FF FFFF0000
	.long 0xd7006a04                                           // 000000984354: D7006A04
	v_cndmask_b32_e32 v1, 0xa000, v2, vcc_lo                   // 000000984358: 020204FF 0000A000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000984360: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v3, vcc_lo                // 000000984364: D5207C05 01AA0680
	v_mul_f32_e32 v22, v21, v22                                // 00000098436C: 102C2D15
	v_mul_f32_e32 v21, v21, v23                                // 000000984370: 102A2F15
	global_load_b32 v23, v6, s[10:11] offset:32                // 000000984374: DC520020 170A0006
	global_load_b32 v4, v[4:5], off glc                        // 00000098437C: DC524000 047C0004
	.long 0xd7006a02                                           // 000000984384: D7006A02
	v_cndmask_b32_e32 v1, 0xb000, v2, vcc_lo                   // 000000984388: 020204FF 0000B000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000984390: BF870001
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 000000984394: D5207C03 01AA0680
	v_add_f32_e32 v7, v7, v21                                  // 00000098439C: 060E2B07
	s_waitcnt vmcnt(0)                                         // 0000009843A0: BF8903F7
	v_lshlrev_b32_e32 v5, 16, v4                               // 0000009843A4: 300A0890
	v_and_b32_e32 v4, 0xffff0000, v4                           // 0000009843A8: 360808FF FFFF0000
	v_mul_f32_e32 v5, v23, v5                                  // 0000009843B0: 100A0B17
	v_mul_f32_e32 v4, v23, v4                                  // 0000009843B4: 10080917
	global_load_b32 v23, v6, s[10:11] offset:36                // 0000009843B8: DC520024 170A0006
	global_load_b32 v2, v[2:3], off offset:1024 glc            // 0000009843C0: DC524400 027C0002
	v_add_f32_e32 v4, v7, v4                                   // 0000009843C8: 06080907
	s_waitcnt vmcnt(0)                                         // 0000009843CC: BF8903F7
	v_lshlrev_b32_e32 v24, 16, v2                              // 0000009843D0: 30300490
	v_and_b32_e32 v25, 0xffff0000, v2                          // 0000009843D4: 363204FF FFFF0000
	.long 0xd7006a02                                           // 0000009843DC: D7006A02
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 0000009843E0: 02020010
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009843E4: BF870001
	v_add_co_ci_u32_e64 v3, null, s17, v1, vcc_lo              // 0000009843E8: D5207C03 01AA0211
	v_mul_f32_e32 v24, v23, v24                                // 0000009843F0: 10303117
	v_mul_f32_e32 v23, v23, v25                                // 0000009843F4: 102E3317
	v_add_f32_e32 v4, v4, v23                                  // 0000009843F8: 06082F04
	global_load_b32 v2, v[2:3], off                            // 0000009843FC: DC520000 027C0002
	global_load_b32 v3, v6, s[8:9]                             // 000000984404: DC520000 03080006
	v_add_f32_e32 v6, 0, v8                                    // 00000098440C: 060C1080
	.long 0xd7006a00                                           // 000000984410: D7006A00
	v_cndmask_b32_e32 v1, s4, v0, vcc_lo                       // 000000984414: 02020004
	v_bfe_u32 v7, v4, 16, 1                                    // 000000984418: D6100007 02052104
	v_add_co_ci_u32_e64 v1, null, s5, v1, vcc_lo               // 000000984420: D5207C01 01AA0205
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000984428: BF870194
	v_add_f32_e32 v6, v6, v10                                  // 00000098442C: 060C1506
	v_add3_u32 v4, v4, v7, 0x7fff                              // 000000984430: D6550004 03FE0F04 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000098443C: BF870112
	v_add_f32_e32 v6, v6, v12                                  // 000000984440: 060C1906
	v_and_b32_e32 v4, 0xffff0000, v4                           // 000000984444: 360808FF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000098444C: BF870092
	v_add_f32_e32 v6, v6, v14                                  // 000000984450: 060C1D06
	v_add_f32_e32 v6, v6, v16                                  // 000000984454: 060C2106
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000984458: BF870091
	v_add_f32_e32 v6, v6, v18                                  // 00000098445C: 060C2506
	v_add_f32_e32 v6, v6, v20                                  // 000000984460: 060C2906
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000984464: BF870091
	v_add_f32_e32 v6, v6, v22                                  // 000000984468: 060C2D06
	v_add_f32_e32 v5, v6, v5                                   // 00000098446C: 060A0B06
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000984470: BF870091
	v_add_f32_e32 v5, v5, v24                                  // 000000984474: 060A3105
	v_bfe_u32 v6, v5, 16, 1                                    // 000000984478: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000984480: BF870091
	v_add3_u32 v5, v5, v6, 0x7fff                              // 000000984484: D6550005 03FE0D05 00007FFF
	v_and_b32_e32 v5, 0xffff0000, v5                           // 000000984490: 360A0AFF FFFF0000
	s_waitcnt vmcnt(1)                                         // 000000984498: BF8907F7
	v_lshlrev_b32_e32 v6, 16, v2                               // 00000098449C: 300C0490
	v_and_b32_e32 v2, 0xffff0000, v2                           // 0000009844A0: 360404FF FFFF0000
	s_waitcnt vmcnt(0)                                         // 0000009844A8: BF8903F7
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009844AC: BF870112
	v_fmac_f32_e32 v5, v3, v6                                  // 0000009844B0: 560A0D03
	v_fmac_f32_e32 v4, v3, v2                                  // 0000009844B4: 56080503
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009844B8: BF870112
	v_bfe_u32 v2, v5, 16, 1                                    // 0000009844BC: D6100002 02052105
	v_bfe_u32 v3, v4, 16, 1                                    // 0000009844C4: D6100003 02052104
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000009844CC: BF8701A2
	v_add3_u32 v2, v5, v2, 0x7fff                              // 0000009844D0: D6550002 03FE0505 00007FFF
	.long 0x7f0a3880                                           // 0000009844DC: 7F0A3880
	v_add3_u32 v3, v4, v3, 0x7fff                              // 0000009844E0: D6550003 03FE0704 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009844EC: BF870093
	.long 0x7e0a3982                                           // 0000009844F0: 7E0A3982
	v_and_or_b32 v2, 0xffff0000, v3, v5                        // 0000009844F4: D6570002 041606FF FFFF0000
	global_store_b32 v[0:1], v2, off                           // 000000984500: DC6A0000 007C0200
	s_or_b32 exec_lo, exec_lo, s1                              // 000000984508: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000098450C: BE812000
	s_cbranch_execz 8                                          // 000000984510: BFA50008 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi4ELi8ELi1ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x2034>
	s_ashr_i32 s3, s2, 31                                      // 000000984514: 86039F02
	v_mov_b32_e32 v0, 0                                        // 000000984518: 7E000280
	s_lshl_b64 s[0:1], s[2:3], 2                               // 00000098451C: 84808202
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000984520: BF870009
	s_add_u32 s0, s6, s0                                       // 000000984524: 80000006
	s_addc_u32 s1, s7, s1                                      // 000000984528: 82010107
	global_store_b32 v0, v0, s[0:1]                            // 00000098452C: DC6A0000 00000000
	s_endpgm                                                   // 000000984534: BFB00000
		...

