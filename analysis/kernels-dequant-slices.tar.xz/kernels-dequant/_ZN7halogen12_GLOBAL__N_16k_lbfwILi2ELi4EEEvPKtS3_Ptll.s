00000000002d7e00 <_ZN7halogen12_GLOBAL__N_16k_lbfwILi2ELi4EEEvPKtS3_Ptll>:
; _ZN7halogen12_GLOBAL__N_16k_lbfwILi2ELi4EEEvPKtS3_Ptll():
	s_load_b64 s[8:9], s[0:1], 0x20                            // 0000002D7E00: F4040200 F8000020
	v_lshrrev_b32_e32 v1, 5, v0                                // 0000002D7E08: 32020085
	s_mov_b32 s3, 0                                            // 0000002D7E0C: BE830080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002D7E10: BF870009
	s_lshl_b64 s[2:3], s[2:3], 3                               // 0000002D7E14: 84828302
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000002D7E18: BF870481
	v_or_b32_e32 v1, s2, v1                                    // 0000002D7E1C: 38020202
	v_mov_b32_e32 v2, s3                                       // 0000002D7E20: 7E040203
	s_mov_b32 s2, exec_lo                                      // 0000002D7E24: BE82007E
	s_waitcnt lgkmcnt(0)                                       // 0000002D7E28: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002D7E2C: BF870001
	.long 0xd4d4007e                                           // 0000002D7E30: D4D4007E
	v_cndmask_b32_e32 v1, s8, v1, vcc_lo                       // 0000002D7E34: 02020208
	s_cbranch_execz 277                                        // 0000002D7E38: BFA50115 <_ZN7halogen12_GLOBAL__N_16k_lbfwILi2ELi4EEEvPKtS3_Ptll+0x490>
	s_load_b256 s[0:7], s[0:1], null                           // 0000002D7E3C: F40C0000 F8000000
	v_and_b32_e32 v0, 31, v0                                   // 0000002D7E44: 3600009F
	s_waitcnt lgkmcnt(0)                                       // 0000002D7E48: BF89FC07
	.long 0xd451000a                                           // 0000002D7E4C: D451000A
	v_cndmask_b32_e32 v0, s6, v129, vcc_lo                     // 0000002D7E50: 02010206
	s_and_b32 vcc_lo, exec_lo, s10                             // 0000002D7E54: 8B6A0A7E
	s_cbranch_vccnz 166                                        // 0000002D7E58: BFA400A6 <_ZN7halogen12_GLOBAL__N_16k_lbfwILi2ELi4EEEvPKtS3_Ptll+0x2f4>
	.long 0xd72c0005                                           // 0000002D7E5C: D72C0005
	v_cndmask_b32_e32 v1, s7, v1, vcc_lo                       // 0000002D7E60: 02020207
	.long 0xd72c0006                                           // 0000002D7E64: D72C0006
	v_cndmask_b32_e32 v1, s6, v2, vcc_lo                       // 0000002D7E68: 02020406
	v_mad_u64_u32 v[3:4], null, s6, v1, 0                      // 0000002D7E6C: D6FE7C03 02020206
	s_lshl_b64 s[10:11], s[6:7], 1                             // 0000002D7E74: 848A8106
	v_mov_b32_e32 v7, 0                                        // 0000002D7E78: 7E0E0280
	s_add_u32 s10, s2, s10                                     // 0000002D7E7C: 800A0A02
	s_addc_u32 s11, s3, s11                                    // 0000002D7E80: 820B0B03
	v_add3_u32 v4, v4, v6, v5                                  // 0000002D7E84: D6550004 04160D04
	v_mov_b32_e32 v6, 0                                        // 0000002D7E8C: 7E0C0280
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002D7E90: BF870122
	.long 0xd73c0004                                           // 0000002D7E94: D73C0004
	v_cndmask_b32_e32 v1, 1, v3, vcc_lo                        // 0000002D7E98: 02020681
	v_lshlrev_b32_e32 v3, 4, v0                                // 0000002D7E9C: 30060084
	.long 0xd7006a04                                           // 0000002D7EA0: D7006A04
	v_cndmask_b32_e32 v1, s0, v4, vcc_lo                       // 0000002D7EA4: 02020800
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002D7EA8: BF870001
	v_add_co_ci_u32_e64 v5, null, s1, v5, vcc_lo               // 0000002D7EAC: D5207C05 01AA0A01
	s_mov_b64 s[0:1], 0                                        // 0000002D7EB4: BE800180
	.long 0xd7006a2c                                           // 0000002D7EB8: D7006A2C
	v_cndmask_b32_e32 v1, v4, v3, vcc_lo                       // 0000002D7EBC: 02020704
	.long 0xd7000c30                                           // 0000002D7EC0: D7000C30
	v_cndmask_b32_e32 v1, s2, v3, vcc_lo                       // 0000002D7EC4: 02020602
	v_add_co_ci_u32_e64 v45, null, 0, v5, vcc_lo               // 0000002D7EC8: D5207C2D 01AA0A80
	v_add_co_ci_u32_e64 v49, null, s3, 0, s12                  // 0000002D7ED0: D5207C31 00310003
	.long 0xd7000c34                                           // 0000002D7ED8: D7000C34
	v_cndmask_b32_e32 v1, s10, v3, vcc_lo                      // 0000002D7EDC: 0202060A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002D7EE0: BF870001
	v_add_co_ci_u32_e64 v53, null, s11, 0, s12                 // 0000002D7EE4: D5207C35 0031000B
	global_load_b128 v[8:11], v[44:45], off                    // 0000002D7EEC: DC5E0000 087C002C
	global_load_b128 v[12:15], v[48:49], off                   // 0000002D7EF4: DC5E0000 0C7C0030
	global_load_b128 v[16:19], v[52:53], off                   // 0000002D7EFC: DC5E0000 107C0034
	global_load_b128 v[20:23], v[44:45], off offset:512        // 0000002D7F04: DC5E0200 147C002C
	global_load_b128 v[24:27], v[48:49], off offset:512        // 0000002D7F0C: DC5E0200 187C0030
	global_load_b128 v[28:31], v[52:53], off offset:512        // 0000002D7F14: DC5E0200 1C7C0034
	global_load_b128 v[32:35], v[44:45], off offset:1024       // 0000002D7F1C: DC5E0400 207C002C
	global_load_b128 v[36:39], v[48:49], off offset:1024       // 0000002D7F24: DC5E0400 247C0030
	global_load_b128 v[40:43], v[52:53], off offset:1024       // 0000002D7F2C: DC5E0400 287C0034
	global_load_b128 v[44:47], v[44:45], off offset:1536       // 0000002D7F34: DC5E0600 2C7C002C
	global_load_b128 v[48:51], v[48:49], off offset:1536       // 0000002D7F3C: DC5E0600 307C0030
	global_load_b128 v[52:55], v[52:53], off offset:1536       // 0000002D7F44: DC5E0600 347C0034
	s_add_u32 s0, s0, 0x400                                    // 0000002D7F4C: 8000FF00 00000400
	s_addc_u32 s1, s1, 0                                       // 0000002D7F54: 82018001
	.long 0xd7006a04                                           // 0000002D7F58: D7006A04
	v_cndmask_b32_e32 v1, 0x800, v4, vcc_lo                    // 0000002D7F5C: 020208FF 00000800
	.long 0xd456000c                                           // 0000002D7F64: D456000C
	v_cndmask_b32_e32 v0, s0, v6, vcc_lo                       // 0000002D7F68: 02000C00
	v_add_co_ci_u32_e64 v5, null, 0, v5, vcc_lo                // 0000002D7F6C: D5207C05 01AA0A80
	s_add_u32 s10, s10, 0x800                                  // 0000002D7F74: 800AFF0A 00000800
	s_addc_u32 s11, s11, 0                                     // 0000002D7F7C: 820B800B
	s_add_u32 s2, s2, 0x800                                    // 0000002D7F80: 8002FF02 00000800
	s_addc_u32 s3, s3, 0                                       // 0000002D7F88: 82038003
	s_and_b32 vcc_lo, exec_lo, s12                             // 0000002D7F8C: 8B6A0C7E
	s_waitcnt vmcnt(10)                                        // 0000002D7F90: BF892BF7
	v_dot2_f32_bf16 v6, v12, v8, v6                            // 0000002D7F94: CC1A4006 1C1A110C
	s_waitcnt vmcnt(9)                                         // 0000002D7F9C: BF8927F7
	v_dot2_f32_bf16 v7, v16, v8, v7                            // 0000002D7FA0: CC1A4007 1C1E1110
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002D7FA8: BF870112
	v_dot2_f32_bf16 v6, v13, v9, v6                            // 0000002D7FAC: CC1A4006 1C1A130D
	v_dot2_f32_bf16 v7, v17, v9, v7                            // 0000002D7FB4: CC1A4007 1C1E1311
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002D7FBC: BF870112
	v_dot2_f32_bf16 v6, v14, v10, v6                           // 0000002D7FC0: CC1A4006 1C1A150E
	v_dot2_f32_bf16 v7, v18, v10, v7                           // 0000002D7FC8: CC1A4007 1C1E1512
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002D7FD0: BF870112
	v_dot2_f32_bf16 v6, v15, v11, v6                           // 0000002D7FD4: CC1A4006 1C1A170F
	v_dot2_f32_bf16 v7, v19, v11, v7                           // 0000002D7FDC: CC1A4007 1C1E1713
	s_waitcnt vmcnt(7)                                         // 0000002D7FE4: BF891FF7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002D7FE8: BF870122
	v_dot2_f32_bf16 v6, v24, v20, v6                           // 0000002D7FEC: CC1A4006 1C1A2918
	s_waitcnt vmcnt(6)                                         // 0000002D7FF4: BF891BF7
	v_dot2_f32_bf16 v7, v28, v20, v7                           // 0000002D7FF8: CC1A4007 1C1E291C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002D8000: BF870112
	v_dot2_f32_bf16 v6, v25, v21, v6                           // 0000002D8004: CC1A4006 1C1A2B19
	v_dot2_f32_bf16 v7, v29, v21, v7                           // 0000002D800C: CC1A4007 1C1E2B1D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002D8014: BF870112
	v_dot2_f32_bf16 v6, v26, v22, v6                           // 0000002D8018: CC1A4006 1C1A2D1A
	v_dot2_f32_bf16 v7, v30, v22, v7                           // 0000002D8020: CC1A4007 1C1E2D1E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002D8028: BF870112
	v_dot2_f32_bf16 v6, v27, v23, v6                           // 0000002D802C: CC1A4006 1C1A2F1B
	v_dot2_f32_bf16 v7, v31, v23, v7                           // 0000002D8034: CC1A4007 1C1E2F1F
	s_waitcnt vmcnt(4)                                         // 0000002D803C: BF8913F7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002D8040: BF870122
	v_dot2_f32_bf16 v6, v36, v32, v6                           // 0000002D8044: CC1A4006 1C1A4124
	s_waitcnt vmcnt(3)                                         // 0000002D804C: BF890FF7
	v_dot2_f32_bf16 v7, v40, v32, v7                           // 0000002D8050: CC1A4007 1C1E4128
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002D8058: BF870112
	v_dot2_f32_bf16 v6, v37, v33, v6                           // 0000002D805C: CC1A4006 1C1A4325
	v_dot2_f32_bf16 v7, v41, v33, v7                           // 0000002D8064: CC1A4007 1C1E4329
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002D806C: BF870112
	v_dot2_f32_bf16 v6, v38, v34, v6                           // 0000002D8070: CC1A4006 1C1A4526
	v_dot2_f32_bf16 v7, v42, v34, v7                           // 0000002D8078: CC1A4007 1C1E452A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002D8080: BF870112
	v_dot2_f32_bf16 v6, v39, v35, v6                           // 0000002D8084: CC1A4006 1C1A4727
	v_dot2_f32_bf16 v7, v43, v35, v7                           // 0000002D808C: CC1A4007 1C1E472B
	s_waitcnt vmcnt(1)                                         // 0000002D8094: BF8907F7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002D8098: BF870122
	v_dot2_f32_bf16 v6, v48, v44, v6                           // 0000002D809C: CC1A4006 1C1A5930
	s_waitcnt vmcnt(0)                                         // 0000002D80A4: BF8903F7
	v_dot2_f32_bf16 v7, v52, v44, v7                           // 0000002D80A8: CC1A4007 1C1E5934
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002D80B0: BF870112
	v_dot2_f32_bf16 v6, v49, v45, v6                           // 0000002D80B4: CC1A4006 1C1A5B31
	v_dot2_f32_bf16 v7, v53, v45, v7                           // 0000002D80BC: CC1A4007 1C1E5B35
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002D80C4: BF870112
	v_dot2_f32_bf16 v6, v50, v46, v6                           // 0000002D80C8: CC1A4006 1C1A5D32
	v_dot2_f32_bf16 v7, v54, v46, v7                           // 0000002D80D0: CC1A4007 1C1E5D36
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002D80D8: BF870112
	v_dot2_f32_bf16 v6, v51, v47, v6                           // 0000002D80DC: CC1A4006 1C1A5F33
	v_dot2_f32_bf16 v7, v55, v47, v7                           // 0000002D80E4: CC1A4007 1C1E5F37
	s_cbranch_vccz 65394                                       // 0000002D80EC: BFA3FF72 <_ZN7halogen12_GLOBAL__N_16k_lbfwILi2ELi4EEEvPKtS3_Ptll+0xb8>
	s_branch 2                                                 // 0000002D80F0: BFA00002 <_ZN7halogen12_GLOBAL__N_16k_lbfwILi2ELi4EEEvPKtS3_Ptll+0x2fc>
	v_dual_mov_b32 v7, 0 :: v_dual_mov_b32 v6, 0               // 0000002D80F4: CA100080 07060080
	.long 0xd71f0003                                           // 0000002D80FC: D71F0003
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000002D8100: 020100C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002D8104: BF870121
	v_xor_b32_e32 v4, 16, v3                                   // 0000002D8108: 3A080690
	v_xor_b32_e32 v8, 8, v3                                    // 0000002D810C: 3A100688
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 0000002D8110: 7C9808A0
	v_cndmask_b32_e32 v4, v3, v4, vcc_lo                       // 0000002D8114: 02080903
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002D8118: BF870113
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 0000002D811C: 7C9810A0
	v_lshlrev_b32_e32 v4, 2, v4                                // 0000002D8120: 30080882
	v_cndmask_b32_e32 v8, v3, v8, vcc_lo                       // 0000002D8124: 02101103
	ds_bpermute_b32 v5, v4, v6                                 // 0000002D8128: DACC0000 05000604
	s_waitcnt lgkmcnt(0)                                       // 0000002D8130: BF89FC07
	v_dual_add_f32 v5, v6, v5 :: v_dual_lshlrev_b32 v8, 2, v8  // 0000002D8134: C9220B06 05081082
	ds_bpermute_b32 v6, v8, v5                                 // 0000002D813C: DACC0000 06000508
	s_waitcnt lgkmcnt(0)                                       // 0000002D8144: BF89FC07
	v_add_f32_e32 v5, v5, v6                                   // 0000002D8148: 060A0D05
	ds_bpermute_b32 v4, v4, v7                                 // 0000002D814C: DACC0000 04000704
	s_waitcnt lgkmcnt(0)                                       // 0000002D8154: BF89FC07
	v_add_f32_e32 v4, v7, v4                                   // 0000002D8158: 06080907
	ds_bpermute_b32 v7, v8, v4                                 // 0000002D815C: DACC0000 07000408
	v_xor_b32_e32 v8, 4, v3                                    // 0000002D8164: 3A100684
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002D8168: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 0000002D816C: 7C9810A0
	v_cndmask_b32_e32 v8, v3, v8, vcc_lo                       // 0000002D8170: 02101103
	v_lshlrev_b32_e32 v8, 2, v8                                // 0000002D8174: 30101082
	s_waitcnt lgkmcnt(0)                                       // 0000002D8178: BF89FC07
	v_add_f32_e32 v4, v4, v7                                   // 0000002D817C: 06080F04
	ds_bpermute_b32 v6, v8, v5                                 // 0000002D8180: DACC0000 06000508
	ds_bpermute_b32 v7, v8, v4                                 // 0000002D8188: DACC0000 07000408
	v_xor_b32_e32 v8, 2, v3                                    // 0000002D8190: 3A100682
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002D8194: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 0000002D8198: 7C9810A0
	v_cndmask_b32_e32 v8, v3, v8, vcc_lo                       // 0000002D819C: 02101103
	s_waitcnt lgkmcnt(1)                                       // 0000002D81A0: BF89FC17
	v_dual_add_f32 v5, v5, v6 :: v_dual_lshlrev_b32 v8, 2, v8  // 0000002D81A4: C9220D05 05081082
	s_waitcnt lgkmcnt(0)                                       // 0000002D81AC: BF89FC07
	v_add_f32_e32 v4, v4, v7                                   // 0000002D81B0: 06080F04
	ds_bpermute_b32 v6, v8, v5                                 // 0000002D81B4: DACC0000 06000508
	ds_bpermute_b32 v7, v8, v4                                 // 0000002D81BC: DACC0000 07000408
	v_xor_b32_e32 v8, 1, v3                                    // 0000002D81C4: 3A100681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000002D81C8: BF870141
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 0000002D81CC: 7C9810A0
	v_cndmask_b32_e32 v3, v3, v8, vcc_lo                       // 0000002D81D0: 02061103
	v_cmp_eq_u32_e32 vcc_lo, 0, v0                             // 0000002D81D4: 7C940080
	s_waitcnt lgkmcnt(1)                                       // 0000002D81D8: BF89FC17
	v_dual_add_f32 v5, v5, v6 :: v_dual_lshlrev_b32 v8, 2, v3  // 0000002D81DC: C9220D05 05080682
	s_waitcnt lgkmcnt(0)                                       // 0000002D81E4: BF89FC07
	v_add_f32_e32 v3, v4, v7                                   // 0000002D81E8: 06060F04
	ds_bpermute_b32 v6, v8, v5                                 // 0000002D81EC: DACC0000 06000508
	ds_bpermute_b32 v4, v8, v3                                 // 0000002D81F4: DACC0000 04000308
	s_and_b32 exec_lo, exec_lo, vcc_lo                         // 0000002D81FC: 8B7E6A7E
	s_cbranch_execz 35                                         // 0000002D8200: BFA50023 <_ZN7halogen12_GLOBAL__N_16k_lbfwILi2ELi4EEEvPKtS3_Ptll+0x490>
	s_waitcnt lgkmcnt(0)                                       // 0000002D8204: BF89FC07
	v_dual_add_f32 v5, v5, v6 :: v_dual_add_f32 v4, v3, v4     // 0000002D8208: C9080D05 05040903
	.long 0x7f0c3880                                           // 0000002D8210: 7F0C3880
	.long 0xd73c0000                                           // 0000002D8214: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000002D8218: 02020281
	s_lshl_b64 s[0:1], s[8:9], 1                               // 0000002D821C: 84808108
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000002D8220: BF870233
	.long 0x7e063985                                           // 0000002D8224: 7E063985
	.long 0x7e0c3984                                           // 0000002D8228: 7E0C3984
	.long 0x7f063986                                           // 0000002D822C: 7F063986
	.long 0xd7006a00                                           // 0000002D8230: D7006A00
	v_cndmask_b32_e32 v1, s4, v0, vcc_lo                       // 0000002D8234: 02020004
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002D8238: BF870191
	v_add_co_ci_u32_e64 v1, null, s5, v1, vcc_lo               // 0000002D823C: D5207C01 01AA0205
	v_and_b32_e32 v2, 1, v3                                    // 0000002D8244: 36040681
	v_and_b32_e32 v6, 1, v6                                    // 0000002D8248: 360C0C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002D824C: BF8700A2
	v_add3_u32 v5, v5, v2, 0x7fff                              // 0000002D8250: D6550005 03FE0505 00007FFF
	.long 0xd7006a02                                           // 0000002D825C: D7006A02
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 0000002D8260: 02000100
	v_add_co_ci_u32_e64 v3, null, s1, v1, vcc_lo               // 0000002D8264: D5207C03 01AA0201
	s_delay_alu instid0(VALU_DEP_4)                            // 0000002D826C: BF870004
	v_add3_u32 v4, v4, v6, 0x7fff                              // 0000002D8270: D6550004 03FE0D04 00007FFF
	s_clause 0x1                                               // 0000002D827C: BF850001
	global_store_d16_hi_b16 v[0:1], v5, off                    // 0000002D8280: DC960000 007C0500
	global_store_d16_hi_b16 v[2:3], v4, off                    // 0000002D8288: DC960000 007C0402
	s_endpgm                                                   // 0000002D8290: BFB00000
		...

