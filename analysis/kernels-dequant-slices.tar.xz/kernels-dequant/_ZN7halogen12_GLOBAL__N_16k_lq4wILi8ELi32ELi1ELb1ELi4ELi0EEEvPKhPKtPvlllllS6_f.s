0000000000fb7b00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000FB7B00: F4100100 F8000000
	v_dual_mov_b32 v4, 0 :: v_dual_and_b32 v1, 15, v0          // 000000FB7B08: CA240080 0400008F
	v_lshrrev_b32_e32 v2, 2, v0                                // 000000FB7B10: 32040082
	s_ashr_i32 s3, s2, 31                                      // 000000FB7B14: 86039F02
	s_delay_alu instid0(VALU_DEP_2)                            // 000000FB7B18: BF870002
	v_dual_mov_b32 v16, 0 :: v_dual_lshlrev_b32 v1, 2, v1      // 000000FB7B1C: CA220080 10000282
	s_lshl_b64 s[0:1], s[2:3], 3                               // 000000FB7B24: 84808302
	s_delay_alu instid0(VALU_DEP_2) | instid1(SALU_CYCLE_1)    // 000000FB7B28: BF870482
	v_dual_mov_b32 v9, s1 :: v_dual_and_b32 v2, 60, v2         // 000000FB7B2C: CA240001 090204BC
	.long 0x7f183880                                           // 000000FB7B34: 7F183880
	v_dual_mov_b32 v6, 0 :: v_dual_and_b32 v15, 31, v0         // 000000FB7B38: CA240080 060E009F
	v_dual_mov_b32 v28, 0 :: v_dual_mov_b32 v5, 0              // 000000FB7B40: CA100080 1C040080
	s_waitcnt lgkmcnt(0)                                       // 000000FB7B48: BF89FC07
	s_clause 0x1                                               // 000000FB7B4C: BF850001
	global_load_b32 v3, v1, s[4:5]                             // 000000FB7B50: DC520000 03040001
	global_load_b32 v7, v2, s[4:5]                             // 000000FB7B58: DC520000 07040002
	v_lshrrev_b32_e32 v1, 5, v0                                // 000000FB7B60: 32020085
	s_add_u32 s2, s4, s14                                      // 000000FB7B64: 80020E04
	s_addc_u32 s3, s5, s15                                     // 000000FB7B68: 82030F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000FB7B6C: BF8704A1
	v_or_b32_e32 v8, s0, v1                                    // 000000FB7B70: 38100200
	s_lshr_b32 s0, s11, 31                                     // 000000FB7B74: 85009F0B
	s_add_u32 s14, s10, s0                                     // 000000FB7B78: 800E000A
	s_addc_u32 s15, s11, 0                                     // 000000FB7B7C: 820F800B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000FB7B80: BF870001
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[8:9]                  // 000000FB7B84: 7CA8100C
	s_ashr_i32 s20, s11, 31                                    // 000000FB7B88: 86149F0B
	v_cndmask_b32_e32 v10, 0, v8, vcc_lo                       // 000000FB7B8C: 02141080
	v_cndmask_b32_e64 v14, 0, s1, vcc_lo                       // 000000FB7B90: D501000E 01A80280
	s_ashr_i64 s[0:1], s[14:15], 1                             // 000000FB7B98: 8680810E
	s_lshr_b32 s14, s20, 27                                    // 000000FB7B9C: 850E9B14
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000FB7BA0: BF870151
	.long 0xd72c0013                                           // 000000FB7BA4: D72C0013
	v_cndmask_b32_e32 v0, v14, v0, vcc_lo                      // 000000FB7BA8: 0200010E
	s_waitcnt vmcnt(1)                                         // 000000FB7BAC: BF8907F7
	v_bfe_u32 v11, v3, 16, 1                                   // 000000FB7BB0: D610000B 02052103
	s_waitcnt vmcnt(0)                                         // 000000FB7BB8: BF8903F7
	v_bfe_u32 v18, v7, 16, 1                                   // 000000FB7BBC: D6100012 02052107
	v_add3_u32 v3, v3, v11, 0x7fff                             // 000000FB7BC4: D6550003 03FE1703 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000FB7BD0: BF870112
	v_add3_u32 v7, v7, v18, 0x7fff                             // 000000FB7BD4: D6550007 03FE2507 00007FFF
	.long 0x7e183983                                           // 000000FB7BE0: 7E183983
	.long 0xd72c0003                                           // 000000FB7BE4: D72C0003
	v_cndmask_b32_e32 v1, s18, v14, vcc_lo                     // 000000FB7BE8: 02021C12
	v_lshlrev_b32_e32 v14, 2, v0                               // 000000FB7BEC: 301C0082
	s_delay_alu instid0(VALU_DEP_3)                            // 000000FB7BF0: BF870003
	v_and_or_b32 v12, 0xffff0000, v7, v12                      // 000000FB7BF4: D657000C 04320EFF FFFF0000
	v_mov_b32_e32 v7, 0                                        // 000000FB7C00: 7E0E0280
	.long 0xd72c000d                                           // 000000FB7C04: D72C000D
	v_cndmask_b32_e32 v1, s19, v10, vcc_lo                     // 000000FB7C08: 02021413
	v_mad_u64_u32 v[1:2], null, s18, v10, 0                    // 000000FB7C0C: D6FE7C01 02021412
	.long 0xd72c0011                                           // 000000FB7C14: D72C0011
	v_cndmask_b32_e32 v0, v10, v1, vcc_lo                      // 000000FB7C18: 0200030A
	v_mad_u64_u32 v[10:11], null, v10, s0, s[2:3]              // 000000FB7C1C: D6FE7C0A 0008010A
	s_add_u32 s2, s10, s14                                     // 000000FB7C24: 80020E0A
	s_addc_u32 s3, s11, 0                                      // 000000FB7C28: 8203800B
	ds_store_b32 v14, v12                                      // 000000FB7C2C: D8340000 00000C0E
	s_lshr_b64 s[2:3], s[2:3], 5                               // 000000FB7C34: 85828502
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000FB7C38: BF870009
	.long 0xd4440000                                           // 000000FB7C3C: D4440000
	v_cndmask_b32_e32 v1, s2, v15, vcc_lo                      // 000000FB7C40: 02021E02
	v_add3_u32 v0, v2, v3, v13                                 // 000000FB7C44: D6550000 04360702
	v_add3_u32 v17, v19, v11, v17                              // 000000FB7C4C: D6550011 04461713
	s_waitcnt lgkmcnt(0)                                       // 000000FB7C54: BF89FC07
	s_barrier                                                  // 000000FB7C58: BFBD0000
	buffer_gl0_inv                                             // 000000FB7C5C: E0AC0000 00000000
	s_and_saveexec_b32 s3, s0                                  // 000000FB7C64: BE832000
	s_cbranch_execz 26                                         // 000000FB7C68: BFA5001A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f+0x1d4>
	s_add_u32 s1, s4, s16                                      // 000000FB7C6C: 80011004
	s_addc_u32 s14, s5, s17                                    // 000000FB7C70: 820E1105
	v_lshlrev_b32_e32 v2, 1, v15                               // 000000FB7C74: 30041E81
	.long 0xd7000103                                           // 000000FB7C78: D7000103
	v_cndmask_b32_e32 v1, s1, v1, vcc_lo                       // 000000FB7C7C: 02020201
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000FB7C80: BF8701A1
	v_add_co_ci_u32_e64 v4, null, s14, v0, s1                  // 000000FB7C84: D5207C04 0006000E
	v_lshlrev_b32_e32 v5, 4, v15                               // 000000FB7C8C: 300A1E84
	.long 0xd7000102                                           // 000000FB7C90: D7000102
	v_cndmask_b32_e32 v1, v3, v2, vcc_lo                       // 000000FB7C94: 02020503
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000FB7C98: BF870191
	v_add_co_ci_u32_e64 v3, null, 0, v4, s1                    // 000000FB7C9C: D5207C03 00060880
	.long 0xd7000104                                           // 000000FB7CA4: D7000104
	v_cndmask_b32_e32 v1, v10, v5, vcc_lo                      // 000000FB7CA8: 02020B0A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000FB7CAC: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v17, s1                   // 000000FB7CB0: D5207C05 00062280
	s_clause 0x1                                               // 000000FB7CB8: BF850001
	global_load_d16_b16 v2, v[2:3], off                        // 000000FB7CBC: DC820000 027C0002
	global_load_b128 v[4:7], v[4:5], off                       // 000000FB7CC4: DC5E0000 047C0004
	s_waitcnt vmcnt(1)                                         // 000000FB7CCC: BF8907F7
	v_cvt_f32_f16_e32 v28, v2                                  // 000000FB7CD0: 7E381702
	s_or_b32 exec_lo, exec_lo, s3                              // 000000FB7CD4: 8C7E037E
	v_dual_mov_b32 v18, 0 :: v_dual_mov_b32 v19, 0             // 000000FB7CD8: CA100080 12120080
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v21, 0             // 000000FB7CE0: CA100080 14140080
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v23, 0             // 000000FB7CE8: CA100080 16160080
	v_mov_b32_e32 v24, 0                                       // 000000FB7CF0: 7E300280
	s_and_saveexec_b32 s3, s0                                  // 000000FB7CF4: BE832000
	s_cbranch_execz 657                                        // 000000FB7CF8: BFA50291 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f+0xc40>
	s_mul_i32 s0, s11, 6                                       // 000000FB7CFC: 9600860B
	s_mul_hi_u32 s1, s10, 6                                    // 000000FB7D00: 9681860A
	v_dual_mov_b32 v12, 0 :: v_dual_lshlrev_b32 v11, 5, v15    // 000000FB7D04: CA220080 0C0A1E85
	s_add_i32 s18, s1, s0                                      // 000000FB7D0C: 81120001
	v_lshlrev_b32_e32 v2, 1, v15                               // 000000FB7D10: 30041E81
	.long 0xd7000001                                           // 000000FB7D14: D7000001
	v_cndmask_b32_e32 v1, s16, v1, vcc_lo                      // 000000FB7D18: 02020210
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000FB7D1C: BF8701A1
	v_add_co_ci_u32_e64 v0, null, s17, v0, s0                  // 000000FB7D20: D5207C00 00020011
	v_mov_b32_e32 v23, v12                                     // 000000FB7D28: 7E2E030C
	.long 0xd7000001                                           // 000000FB7D2C: D7000001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 000000FB7D30: 02020501
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000FB7D34: BF8701A1
	v_add_co_ci_u32_e64 v0, null, 0, v0, s0                    // 000000FB7D38: D5207C00 00020080
	v_lshl_or_b32 v25, v15, 4, 0x200                           // 000000FB7D40: D6560019 03FD090F 00000200
	.long 0xd7000001                                           // 000000FB7D4C: D7000001
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 000000FB7D50: 02020204
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000FB7D54: BF8701A1
	v_add_co_ci_u32_e64 v0, null, s5, v0, s0                   // 000000FB7D58: D5207C00 00020005
	v_dual_mov_b32 v26, v15 :: v_dual_mov_b32 v21, v12         // 000000FB7D60: CA10010F 1A14010C
	.long 0xd700000d                                           // 000000FB7D68: D700000D
	v_cndmask_b32_e32 v0, v1, v192, vcc_lo                     // 000000FB7D6C: 02018101
	s_delay_alu instid0(VALU_DEP_1)                            // 000000FB7D70: BF870001
	v_add_co_ci_u32_e64 v14, null, 0, v0, s0                   // 000000FB7D74: D5207C0E 00020080
	v_mov_b32_e32 v24, v12                                     // 000000FB7D7C: 7E30030C
	v_mov_b32_e32 v22, v12                                     // 000000FB7D80: 7E2C030C
	v_mov_b32_e32 v20, v12                                     // 000000FB7D84: 7E28030C
	v_mov_b32_e32 v19, v12                                     // 000000FB7D88: 7E26030C
	v_mov_b32_e32 v18, v12                                     // 000000FB7D8C: 7E24030C
	v_mov_b32_e32 v16, v12                                     // 000000FB7D90: 7E20030C
	v_mov_b32_e32 v27, v28                                     // 000000FB7D94: 7E36031C
	s_lshl_b64 s[14:15], s[10:11], 2                           // 000000FB7D98: 848E820A
	s_mul_i32 s17, s10, 6                                      // 000000FB7D9C: 9611860A
	s_mov_b32 s16, 0                                           // 000000FB7DA0: BE900080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 000000FB7DA4: 8484810A
	s_branch 587                                               // 000000FB7DA8: BFA0024B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f+0xbd8>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000FB7DAC: 8C7E0A7E
	v_and_b32_e32 v29, 0xff, v4                                // 000000FB7DB0: 363A08FF 000000FF
	s_and_b32 s0, exec_lo, s0                                  // 000000FB7DB8: 8B00007E
	v_add_nc_u32_e32 v25, 0x200, v25                           // 000000FB7DBC: 4A3232FF 00000200
	s_or_b32 s16, s0, s16                                      // 000000FB7DC4: 8C101000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000FB7DC8: BF8700B2
	v_lshlrev_b32_e32 v29, 2, v29                              // 000000FB7DCC: 303A3A82
	ds_load_b32 v45, v29                                       // 000000FB7DD0: D8D80000 2D00001D
	v_lshrrev_b32_e32 v29, 6, v4                               // 000000FB7DD8: 323A0886
	v_and_b32_e32 v29, 0x3fc, v29                              // 000000FB7DDC: 363A3AFF 000003FC
	ds_load_b32 v46, v29                                       // 000000FB7DE4: D8D80000 2E00001D
	v_lshrrev_b32_e32 v29, 14, v4                              // 000000FB7DEC: 323A088E
	v_lshrrev_b32_e32 v4, 22, v4                               // 000000FB7DF0: 32080896
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000FB7DF4: BF870112
	v_and_b32_e32 v29, 0x3fc, v29                              // 000000FB7DF8: 363A3AFF 000003FC
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000FB7E00: 360808FF 000003FC
	ds_load_b32 v47, v29                                       // 000000FB7E08: D8D80000 2F00001D
	ds_load_b32 v48, v4                                        // 000000FB7E10: D8D80000 30000004
	v_and_b32_e32 v4, 0xff, v5                                 // 000000FB7E18: 36080AFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000FB7E20: BF8700B1
	v_lshlrev_b32_e32 v4, 2, v4                                // 000000FB7E24: 30080882
	ds_load_b32 v49, v4                                        // 000000FB7E28: D8D80000 31000004
	v_lshrrev_b32_e32 v4, 6, v5                                // 000000FB7E30: 32080A86
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000FB7E34: 360808FF 000003FC
	ds_load_b32 v50, v4                                        // 000000FB7E3C: D8D80000 32000004
	v_lshrrev_b32_e32 v4, 14, v5                               // 000000FB7E44: 32080A8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000FB7E48: BF8700B1
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000FB7E4C: 360808FF 000003FC
	ds_load_b32 v51, v4                                        // 000000FB7E54: D8D80000 33000004
	v_lshrrev_b32_e32 v4, 22, v5                               // 000000FB7E5C: 32080A96
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000FB7E60: 360808FF 000003FC
	ds_load_b32 v52, v4                                        // 000000FB7E68: D8D80000 34000004
	v_and_b32_e32 v4, 0xff, v6                                 // 000000FB7E70: 36080CFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000FB7E78: BF8700B1
	v_lshlrev_b32_e32 v4, 2, v4                                // 000000FB7E7C: 30080882
	ds_load_b32 v53, v4                                        // 000000FB7E80: D8D80000 35000004
	v_lshrrev_b32_e32 v4, 6, v6                                // 000000FB7E88: 32080C86
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000FB7E8C: 360808FF 000003FC
	ds_load_b32 v54, v4                                        // 000000FB7E94: D8D80000 36000004
	v_lshrrev_b32_e32 v4, 14, v6                               // 000000FB7E9C: 32080C8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000FB7EA0: BF8700B1
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000FB7EA4: 360808FF 000003FC
	ds_load_b32 v55, v4                                        // 000000FB7EAC: D8D80000 37000004
	v_lshrrev_b32_e32 v4, 22, v6                               // 000000FB7EB4: 32080C96
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000FB7EB8: 360808FF 000003FC
	ds_load_b32 v56, v4                                        // 000000FB7EC0: D8D80000 38000004
	v_and_b32_e32 v4, 0xff, v7                                 // 000000FB7EC8: 36080EFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000FB7ED0: BF8700B1
	v_lshlrev_b32_e32 v4, 2, v4                                // 000000FB7ED4: 30080882
	ds_load_b32 v57, v4                                        // 000000FB7ED8: D8D80000 39000004
	v_lshrrev_b32_e32 v4, 6, v7                                // 000000FB7EE0: 32080E86
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000FB7EE4: 360808FF 000003FC
	ds_load_b32 v58, v4                                        // 000000FB7EEC: D8D80000 3A000004
	v_lshrrev_b32_e32 v4, 14, v7                               // 000000FB7EF4: 32080E8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000FB7EF8: BF8700B1
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000FB7EFC: 360808FF 000003FC
	ds_load_b32 v59, v4                                        // 000000FB7F04: D8D80000 3B000004
	v_lshrrev_b32_e32 v4, 22, v7                               // 000000FB7F0C: 32080E96
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000FB7F10: 360808FF 000003FC
	ds_load_b32 v60, v4                                        // 000000FB7F18: D8D80000 3C000004
	.long 0xd73c0004                                           // 000000FB7F20: D73C0004
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 000000FB7F24: 02021681
	v_add_nc_u32_e32 v11, 0x400, v11                           // 000000FB7F28: 4A1616FF 00000400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB7F30: BF870092
	.long 0xd7000029                                           // 000000FB7F34: D7000029
	v_cndmask_b32_e32 v1, s6, v4, vcc_lo                       // 000000FB7F38: 02020806
	v_add_co_ci_u32_e64 v42, null, s7, v5, s0                  // 000000FB7F3C: D5207C2A 00020A07
	s_clause 0x3                                               // 000000FB7F44: BF850003
	global_load_b128 v[4:7], v[41:42], off                     // 000000FB7F48: DC5E0000 047C0029
	global_load_b128 v[29:32], v[41:42], off offset:16         // 000000FB7F50: DC5E0010 1D7C0029
	global_load_b128 v[33:36], v[41:42], off offset:32         // 000000FB7F58: DC5E0020 217C0029
	global_load_b128 v[37:40], v[41:42], off offset:48         // 000000FB7F60: DC5E0030 257C0029
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 000000FB7F68: BF890CF7
	v_dot2_f32_bf16 v4, v4, v45, 0                             // 000000FB7F6C: CC1A4004 1A025B04
	s_waitcnt lgkmcnt(14)                                      // 000000FB7F74: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FB7F78: BF8700A1
	v_dot2_f32_bf16 v4, v5, v46, v4                            // 000000FB7F7C: CC1A4004 1C125D05
	s_waitcnt lgkmcnt(13)                                      // 000000FB7F84: BF89FCD7
	v_dot2_f32_bf16 v4, v6, v47, v4                            // 000000FB7F88: CC1A4004 1C125F06
	s_waitcnt lgkmcnt(12)                                      // 000000FB7F90: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FB7F94: BF8700A1
	v_dot2_f32_bf16 v4, v7, v48, v4                            // 000000FB7F98: CC1A4004 1C126107
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 000000FB7FA0: BF8908B7
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 000000FB7FA4: CC1A4004 1C12631D
	s_waitcnt lgkmcnt(10)                                      // 000000FB7FAC: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FB7FB0: BF8700A1
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 000000FB7FB4: CC1A4004 1C12651E
	s_waitcnt lgkmcnt(9)                                       // 000000FB7FBC: BF89FC97
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 000000FB7FC0: CC1A4004 1C12671F
	s_waitcnt lgkmcnt(8)                                       // 000000FB7FC8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FB7FCC: BF8700A1
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 000000FB7FD0: CC1A4004 1C126920
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 000000FB7FD8: BF890477
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 000000FB7FDC: CC1A4004 1C126B21
	s_waitcnt lgkmcnt(6)                                       // 000000FB7FE4: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FB7FE8: BF8700A1
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 000000FB7FEC: CC1A4004 1C126D22
	s_waitcnt lgkmcnt(5)                                       // 000000FB7FF4: BF89FC57
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 000000FB7FF8: CC1A4004 1C126F23
	s_waitcnt lgkmcnt(4)                                       // 000000FB8000: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FB8004: BF8700A1
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 000000FB8008: CC1A4004 1C127124
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 000000FB8010: BF890037
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 000000FB8014: CC1A4004 1C127325
	.long 0xd7000025                                           // 000000FB801C: D7000025
	v_cndmask_b32_e32 v0, v41, v4, vcc_lo                      // 000000FB8020: 02000929
	s_waitcnt lgkmcnt(2)                                       // 000000FB8024: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000FB8028: BF8701C2
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 000000FB802C: CC1A4004 1C127526
	v_add_co_ci_u32_e64 v38, null, s5, v42, s0                 // 000000FB8034: D5207C26 00025405
	.long 0xd700002b                                           // 000000FB803C: D700002B
	v_cndmask_b32_e32 v0, v41, v14, vcc_lo                     // 000000FB8040: 02001D29
	s_waitcnt lgkmcnt(1)                                       // 000000FB8044: BF89FC17
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 000000FB8048: CC1A4004 1C127727
	v_add_co_ci_u32_e64 v44, null, s15, v42, s0                // 000000FB8050: D5207C2C 0002540F
	.long 0xd7000029                                           // 000000FB8058: D7000029
	v_cndmask_b32_e32 v0, v41, v17, vcc_lo                     // 000000FB805C: 02002329
	s_waitcnt lgkmcnt(0)                                       // 000000FB8060: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000FB8064: BF870123
	v_dot2_f32_bf16 v4, v40, v60, v4                           // 000000FB8068: CC1A4004 1C127928
	v_add_co_ci_u32_e64 v42, null, s18, v42, s0                // 000000FB8070: D5207C2A 00025412
	v_fmac_f32_e32 v24, v28, v4                                // 000000FB8078: 5630091C
	s_clause 0x3                                               // 000000FB807C: BF850003
	global_load_b128 v[4:7], v[37:38], off                     // 000000FB8080: DC5E0000 047C0025
	global_load_b128 v[29:32], v[37:38], off offset:16         // 000000FB8088: DC5E0010 1D7C0025
	global_load_b128 v[33:36], v[37:38], off offset:32         // 000000FB8090: DC5E0020 217C0025
	global_load_b128 v[37:40], v[37:38], off offset:48         // 000000FB8098: DC5E0030 257C0025
	s_waitcnt vmcnt(3)                                         // 000000FB80A0: BF890FF7
	v_dot2_f32_bf16 v4, v4, v45, 0                             // 000000FB80A4: CC1A4004 1A025B04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB80AC: BF870091
	v_dot2_f32_bf16 v4, v5, v46, v4                            // 000000FB80B0: CC1A4004 1C125D05
	v_dot2_f32_bf16 v4, v6, v47, v4                            // 000000FB80B8: CC1A4004 1C125F06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FB80C0: BF8700A1
	v_dot2_f32_bf16 v4, v7, v48, v4                            // 000000FB80C4: CC1A4004 1C126107
	s_waitcnt vmcnt(2)                                         // 000000FB80CC: BF890BF7
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 000000FB80D0: CC1A4004 1C12631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB80D8: BF870091
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 000000FB80DC: CC1A4004 1C12651E
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 000000FB80E4: CC1A4004 1C12671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FB80EC: BF8700A1
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 000000FB80F0: CC1A4004 1C126920
	s_waitcnt vmcnt(1)                                         // 000000FB80F8: BF8907F7
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 000000FB80FC: CC1A4004 1C126B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB8104: BF870091
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 000000FB8108: CC1A4004 1C126D22
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 000000FB8110: CC1A4004 1C126F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FB8118: BF8700A1
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 000000FB811C: CC1A4004 1C127124
	s_waitcnt vmcnt(0)                                         // 000000FB8124: BF8903F7
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 000000FB8128: CC1A4004 1C127325
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB8130: BF870091
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 000000FB8134: CC1A4004 1C127526
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 000000FB813C: CC1A4004 1C127727
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB8144: BF870091
	v_dot2_f32_bf16 v4, v40, v60, v4                           // 000000FB8148: CC1A4004 1C127928
	v_fmac_f32_e32 v23, v28, v4                                // 000000FB8150: 562E091C
	s_clause 0x3                                               // 000000FB8154: BF850003
	global_load_b128 v[4:7], v[43:44], off                     // 000000FB8158: DC5E0000 047C002B
	global_load_b128 v[29:32], v[43:44], off offset:16         // 000000FB8160: DC5E0010 1D7C002B
	global_load_b128 v[33:36], v[43:44], off offset:32         // 000000FB8168: DC5E0020 217C002B
	global_load_b128 v[37:40], v[43:44], off offset:48         // 000000FB8170: DC5E0030 257C002B
	.long 0xd700002b                                           // 000000FB8178: D700002B
	v_cndmask_b32_e32 v0, v43, v14, vcc_lo                     // 000000FB817C: 02001D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000FB8180: BF8700B1
	v_add_co_ci_u32_e64 v44, null, s15, v44, s0                // 000000FB8184: D5207C2C 0002580F
	s_waitcnt vmcnt(3)                                         // 000000FB818C: BF890FF7
	v_dot2_f32_bf16 v4, v4, v45, 0                             // 000000FB8190: CC1A4004 1A025B04
	v_dot2_f32_bf16 v4, v5, v46, v4                            // 000000FB8198: CC1A4004 1C125D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB81A0: BF870091
	v_dot2_f32_bf16 v4, v6, v47, v4                            // 000000FB81A4: CC1A4004 1C125F06
	v_dot2_f32_bf16 v4, v7, v48, v4                            // 000000FB81AC: CC1A4004 1C126107
	s_waitcnt vmcnt(2)                                         // 000000FB81B4: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB81B8: BF870091
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 000000FB81BC: CC1A4004 1C12631D
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 000000FB81C4: CC1A4004 1C12651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB81CC: BF870091
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 000000FB81D0: CC1A4004 1C12671F
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 000000FB81D8: CC1A4004 1C126920
	s_waitcnt vmcnt(1)                                         // 000000FB81E0: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB81E4: BF870091
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 000000FB81E8: CC1A4004 1C126B21
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 000000FB81F0: CC1A4004 1C126D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB81F8: BF870091
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 000000FB81FC: CC1A4004 1C126F23
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 000000FB8204: CC1A4004 1C127124
	s_waitcnt vmcnt(0)                                         // 000000FB820C: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB8210: BF870091
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 000000FB8214: CC1A4004 1C127325
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 000000FB821C: CC1A4004 1C127526
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB8224: BF870091
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 000000FB8228: CC1A4004 1C127727
	v_dot2_f32_bf16 v4, v40, v60, v4                           // 000000FB8230: CC1A4004 1C127928
	s_delay_alu instid0(VALU_DEP_1)                            // 000000FB8238: BF870001
	v_fmac_f32_e32 v22, v28, v4                                // 000000FB823C: 562C091C
	s_clause 0x3                                               // 000000FB8240: BF850003
	global_load_b128 v[4:7], v[41:42], off                     // 000000FB8244: DC5E0000 047C0029
	global_load_b128 v[29:32], v[41:42], off offset:16         // 000000FB824C: DC5E0010 1D7C0029
	global_load_b128 v[33:36], v[41:42], off offset:32         // 000000FB8254: DC5E0020 217C0029
	global_load_b128 v[37:40], v[41:42], off offset:48         // 000000FB825C: DC5E0030 257C0029
	.long 0xd7000029                                           // 000000FB8264: D7000029
	v_cndmask_b32_e32 v0, v41, v14, vcc_lo                     // 000000FB8268: 02001D29
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000FB826C: BF8700B1
	v_add_co_ci_u32_e64 v42, null, s15, v42, s0                // 000000FB8270: D5207C2A 0002540F
	s_waitcnt vmcnt(3)                                         // 000000FB8278: BF890FF7
	v_dot2_f32_bf16 v4, v4, v45, 0                             // 000000FB827C: CC1A4004 1A025B04
	v_dot2_f32_bf16 v4, v5, v46, v4                            // 000000FB8284: CC1A4004 1C125D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB828C: BF870091
	v_dot2_f32_bf16 v4, v6, v47, v4                            // 000000FB8290: CC1A4004 1C125F06
	v_dot2_f32_bf16 v4, v7, v48, v4                            // 000000FB8298: CC1A4004 1C126107
	s_waitcnt vmcnt(2)                                         // 000000FB82A0: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB82A4: BF870091
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 000000FB82A8: CC1A4004 1C12631D
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 000000FB82B0: CC1A4004 1C12651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB82B8: BF870091
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 000000FB82BC: CC1A4004 1C12671F
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 000000FB82C4: CC1A4004 1C126920
	s_waitcnt vmcnt(1)                                         // 000000FB82CC: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB82D0: BF870091
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 000000FB82D4: CC1A4004 1C126B21
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 000000FB82DC: CC1A4004 1C126D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB82E4: BF870091
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 000000FB82E8: CC1A4004 1C126F23
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 000000FB82F0: CC1A4004 1C127124
	s_waitcnt vmcnt(0)                                         // 000000FB82F8: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB82FC: BF870091
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 000000FB8300: CC1A4004 1C127325
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 000000FB8308: CC1A4004 1C127526
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB8310: BF870091
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 000000FB8314: CC1A4004 1C127727
	v_dot2_f32_bf16 v4, v40, v60, v4                           // 000000FB831C: CC1A4004 1C127928
	s_delay_alu instid0(VALU_DEP_1)                            // 000000FB8324: BF870001
	v_fmac_f32_e32 v21, v28, v4                                // 000000FB8328: 562A091C
	s_clause 0x3                                               // 000000FB832C: BF850003
	global_load_b128 v[4:7], v[43:44], off                     // 000000FB8330: DC5E0000 047C002B
	global_load_b128 v[29:32], v[43:44], off offset:16         // 000000FB8338: DC5E0010 1D7C002B
	global_load_b128 v[33:36], v[43:44], off offset:32         // 000000FB8340: DC5E0020 217C002B
	global_load_b128 v[37:40], v[43:44], off offset:48         // 000000FB8348: DC5E0030 257C002B
	s_waitcnt vmcnt(3)                                         // 000000FB8350: BF890FF7
	v_dot2_f32_bf16 v4, v4, v45, 0                             // 000000FB8354: CC1A4004 1A025B04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB835C: BF870091
	v_dot2_f32_bf16 v4, v5, v46, v4                            // 000000FB8360: CC1A4004 1C125D05
	v_dot2_f32_bf16 v4, v6, v47, v4                            // 000000FB8368: CC1A4004 1C125F06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FB8370: BF8700A1
	v_dot2_f32_bf16 v4, v7, v48, v4                            // 000000FB8374: CC1A4004 1C126107
	s_waitcnt vmcnt(2)                                         // 000000FB837C: BF890BF7
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 000000FB8380: CC1A4004 1C12631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB8388: BF870091
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 000000FB838C: CC1A4004 1C12651E
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 000000FB8394: CC1A4004 1C12671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FB839C: BF8700A1
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 000000FB83A0: CC1A4004 1C126920
	s_waitcnt vmcnt(1)                                         // 000000FB83A8: BF8907F7
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 000000FB83AC: CC1A4004 1C126B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB83B4: BF870091
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 000000FB83B8: CC1A4004 1C126D22
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 000000FB83C0: CC1A4004 1C126F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FB83C8: BF8700A1
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 000000FB83CC: CC1A4004 1C127124
	s_waitcnt vmcnt(0)                                         // 000000FB83D4: BF8903F7
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 000000FB83D8: CC1A4004 1C127325
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB83E0: BF870091
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 000000FB83E4: CC1A4004 1C127526
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 000000FB83EC: CC1A4004 1C127727
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB83F4: BF870091
	v_dot2_f32_bf16 v4, v40, v60, v4                           // 000000FB83F8: CC1A4004 1C127928
	v_fmac_f32_e32 v20, v28, v4                                // 000000FB8400: 5628091C
	s_clause 0x3                                               // 000000FB8404: BF850003
	global_load_b128 v[4:7], v[41:42], off                     // 000000FB8408: DC5E0000 047C0029
	global_load_b128 v[29:32], v[41:42], off offset:16         // 000000FB8410: DC5E0010 1D7C0029
	global_load_b128 v[33:36], v[41:42], off offset:32         // 000000FB8418: DC5E0020 217C0029
	global_load_b128 v[37:40], v[41:42], off offset:48         // 000000FB8420: DC5E0030 257C0029
	s_waitcnt vmcnt(3)                                         // 000000FB8428: BF890FF7
	v_dot2_f32_bf16 v4, v4, v45, 0                             // 000000FB842C: CC1A4004 1A025B04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB8434: BF870091
	v_dot2_f32_bf16 v4, v5, v46, v4                            // 000000FB8438: CC1A4004 1C125D05
	v_dot2_f32_bf16 v4, v6, v47, v4                            // 000000FB8440: CC1A4004 1C125F06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FB8448: BF8700A1
	v_dot2_f32_bf16 v4, v7, v48, v4                            // 000000FB844C: CC1A4004 1C126107
	s_waitcnt vmcnt(2)                                         // 000000FB8454: BF890BF7
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 000000FB8458: CC1A4004 1C12631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB8460: BF870091
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 000000FB8464: CC1A4004 1C12651E
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 000000FB846C: CC1A4004 1C12671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FB8474: BF8700A1
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 000000FB8478: CC1A4004 1C126920
	s_waitcnt vmcnt(1)                                         // 000000FB8480: BF8907F7
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 000000FB8484: CC1A4004 1C126B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB848C: BF870091
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 000000FB8490: CC1A4004 1C126D22
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 000000FB8498: CC1A4004 1C126F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FB84A0: BF8700A1
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 000000FB84A4: CC1A4004 1C127124
	s_waitcnt vmcnt(0)                                         // 000000FB84AC: BF8903F7
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 000000FB84B0: CC1A4004 1C127325
	.long 0xd7000025                                           // 000000FB84B8: D7000025
	v_cndmask_b32_e32 v0, v43, v14, vcc_lo                     // 000000FB84BC: 02001D2B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000FB84C0: BF870122
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 000000FB84C4: CC1A4004 1C127526
	v_add_co_ci_u32_e64 v38, null, s15, v44, s0                // 000000FB84CC: D5207C26 0002580F
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 000000FB84D4: CC1A4004 1C127727
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB84DC: BF870091
	v_dot2_f32_bf16 v4, v40, v60, v4                           // 000000FB84E0: CC1A4004 1C127928
	v_fmac_f32_e32 v19, v28, v4                                // 000000FB84E8: 5626091C
	s_clause 0x3                                               // 000000FB84EC: BF850003
	global_load_b128 v[4:7], v[37:38], off                     // 000000FB84F0: DC5E0000 047C0025
	global_load_b128 v[29:32], v[37:38], off offset:16         // 000000FB84F8: DC5E0010 1D7C0025
	global_load_b128 v[33:36], v[37:38], off offset:32         // 000000FB8500: DC5E0020 217C0025
	global_load_b128 v[37:40], v[37:38], off offset:48         // 000000FB8508: DC5E0030 257C0025
	s_waitcnt vmcnt(3)                                         // 000000FB8510: BF890FF7
	v_dot2_f32_bf16 v4, v4, v45, 0                             // 000000FB8514: CC1A4004 1A025B04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB851C: BF870091
	v_dot2_f32_bf16 v4, v5, v46, v4                            // 000000FB8520: CC1A4004 1C125D05
	v_dot2_f32_bf16 v4, v6, v47, v4                            // 000000FB8528: CC1A4004 1C125F06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FB8530: BF8700A1
	v_dot2_f32_bf16 v4, v7, v48, v4                            // 000000FB8534: CC1A4004 1C126107
	s_waitcnt vmcnt(2)                                         // 000000FB853C: BF890BF7
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 000000FB8540: CC1A4004 1C12631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB8548: BF870091
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 000000FB854C: CC1A4004 1C12651E
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 000000FB8554: CC1A4004 1C12671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FB855C: BF8700A1
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 000000FB8560: CC1A4004 1C126920
	s_waitcnt vmcnt(1)                                         // 000000FB8568: BF8907F7
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 000000FB856C: CC1A4004 1C126B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB8574: BF870091
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 000000FB8578: CC1A4004 1C126D22
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 000000FB8580: CC1A4004 1C126F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FB8588: BF8700A1
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 000000FB858C: CC1A4004 1C127124
	s_waitcnt vmcnt(0)                                         // 000000FB8594: BF8903F7
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 000000FB8598: CC1A4004 1C127325
	.long 0xd7000025                                           // 000000FB85A0: D7000025
	v_cndmask_b32_e32 v0, v41, v14, vcc_lo                     // 000000FB85A4: 02001D29
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000FB85A8: BF8701B2
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 000000FB85AC: CC1A4004 1C127526
	v_add_co_ci_u32_e64 v38, null, s15, v42, s0                // 000000FB85B4: D5207C26 0002540F
	.long 0xd700000d                                           // 000000FB85BC: D700000D
	v_cndmask_b32_e32 v0, v13, v192, vcc_lo                    // 000000FB85C0: 0201810D
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 000000FB85C4: CC1A4004 1C127727
	v_add_co_ci_u32_e64 v14, null, 0, v14, s0                  // 000000FB85CC: D5207C0E 00021C80
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB85D4: BF870092
	v_dot2_f32_bf16 v4, v40, v60, v4                           // 000000FB85D8: CC1A4004 1C127928
	v_fmac_f32_e32 v18, v28, v4                                // 000000FB85E0: 5624091C
	s_clause 0x3                                               // 000000FB85E4: BF850003
	global_load_b128 v[4:7], v[37:38], off                     // 000000FB85E8: DC5E0000 047C0025
	global_load_b128 v[29:32], v[37:38], off offset:16         // 000000FB85F0: DC5E0010 1D7C0025
	global_load_b128 v[33:36], v[37:38], off offset:32         // 000000FB85F8: DC5E0020 217C0025
	global_load_b128 v[37:40], v[37:38], off offset:48         // 000000FB8600: DC5E0030 257C0025
	s_waitcnt vmcnt(3)                                         // 000000FB8608: BF890FF7
	v_dot2_f32_bf16 v4, v4, v45, 0                             // 000000FB860C: CC1A4004 1A025B04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000FB8614: BF870121
	v_dot2_f32_bf16 v4, v5, v46, v4                            // 000000FB8618: CC1A4004 1C125D05
	v_mov_b32_e32 v5, v1                                       // 000000FB8620: 7E0A0301
	v_dot2_f32_bf16 v4, v6, v47, v4                            // 000000FB8624: CC1A4004 1C125F06
	v_mov_b32_e32 v6, v2                                       // 000000FB862C: 7E0C0302
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000FB8630: BF870132
	v_dot2_f32_bf16 v4, v7, v48, v4                            // 000000FB8634: CC1A4004 1C126107
	v_mov_b32_e32 v7, v3                                       // 000000FB863C: 7E0E0303
	s_waitcnt vmcnt(2)                                         // 000000FB8640: BF890BF7
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 000000FB8644: CC1A4004 1C12631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB864C: BF870091
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 000000FB8650: CC1A4004 1C12651E
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 000000FB8658: CC1A4004 1C12671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FB8660: BF8700A1
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 000000FB8664: CC1A4004 1C126920
	s_waitcnt vmcnt(1)                                         // 000000FB866C: BF8907F7
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 000000FB8670: CC1A4004 1C126B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB8678: BF870091
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 000000FB867C: CC1A4004 1C126D22
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 000000FB8684: CC1A4004 1C126F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FB868C: BF8700A1
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 000000FB8690: CC1A4004 1C127124
	s_waitcnt vmcnt(0)                                         // 000000FB8698: BF8903F7
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 000000FB869C: CC1A4004 1C127325
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB86A4: BF870091
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 000000FB86A8: CC1A4004 1C127526
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 000000FB86B0: CC1A4004 1C127727
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB86B8: BF870091
	v_dot2_f32_bf16 v4, v40, v60, v4                           // 000000FB86BC: CC1A4004 1C127928
	v_fmac_f32_e32 v16, v28, v4                                // 000000FB86C4: 5620091C
	v_mov_b32_e32 v4, v0                                       // 000000FB86C8: 7E080300
	v_mov_b32_e32 v28, v27                                     // 000000FB86CC: 7E38031B
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 000000FB86D0: 917E107E
	s_cbranch_execz 25                                         // 000000FB86D4: BFA50019 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f+0xc3c>
	s_waitcnt vmcnt(0)                                         // 000000FB86D8: BF8903F7
	v_dual_mov_b32 v1, v5 :: v_dual_add_nc_u32 v26, 32, v26    // 000000FB86DC: CA200105 011A34A0
	v_dual_mov_b32 v0, v4 :: v_dual_mov_b32 v3, v7             // 000000FB86E4: CA100104 00020107
	v_mov_b32_e32 v2, v6                                       // 000000FB86EC: 7E040306
	s_delay_alu instid0(VALU_DEP_3)                            // 000000FB86F0: BF870003
	.long 0xd4430000                                           // 000000FB86F4: D4430000
	v_cndmask_b32_e32 v1, s2, v26, vcc_lo                      // 000000FB86F8: 02023402
	s_mov_b32 s10, exec_lo                                     // 000000FB86FC: BE8A007E
	.long 0xd4c4007e                                           // 000000FB8700: D4C4007E
	v_cndmask_b32_e32 v1, s2, v26, vcc_lo                      // 000000FB8704: 02023402
	s_cbranch_execz 64936                                      // 000000FB8708: BFA5FDA8 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f+0x2ac>
	.long 0xd7000100                                           // 000000FB870C: D7000100
	v_cndmask_b32_e32 v1, v10, v25, vcc_lo                     // 000000FB8710: 0202330A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000FB8714: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v17, s1                   // 000000FB8718: D5207C01 00062280
	global_load_d16_b16 v27, v[13:14], off                     // 000000FB8720: DC820000 1B7C000D
	global_load_b128 v[0:3], v[0:1], off                       // 000000FB8728: DC5E0000 007C0000
	s_waitcnt vmcnt(1)                                         // 000000FB8730: BF8907F7
	v_cvt_f32_f16_e32 v27, v27                                 // 000000FB8734: 7E36171B
	s_branch 64924                                             // 000000FB8738: BFA0FD9C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f+0x2ac>
	s_or_b32 exec_lo, exec_lo, s16                             // 000000FB873C: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FB8740: BF8700A9
	s_or_b32 exec_lo, exec_lo, s3                              // 000000FB8744: 8C7E037E
	.long 0xd71f0000                                           // 000000FB8748: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000FB874C: 020100C1
	v_xor_b32_e32 v1, 16, v0                                   // 000000FB8750: 3A020090
	v_xor_b32_e32 v11, 8, v0                                   // 000000FB8754: 3A160088
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB8758: BF870092
	.long 0xd44c0000                                           // 000000FB875C: D44C0000
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 000000FB8760: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s0                           // 000000FB8764: D5010001 00020300
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000FB876C: BF870113
	.long 0xd44c0000                                           // 000000FB8770: D44C0000
	v_cndmask_b32_e32 v1, 32, v11, vcc_lo                      // 000000FB8774: 020216A0
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000FB8778: 30020282
	s_delay_alu instid0(VALU_DEP_2)                            // 000000FB877C: BF870002
	v_cndmask_b32_e64 v11, v0, v11, s0                         // 000000FB8780: D501000B 00021700
	ds_bpermute_b32 v2, v1, v24                                // 000000FB8788: DACC0000 02001801
	s_waitcnt lgkmcnt(0)                                       // 000000FB8790: BF89FC07
	v_add_f32_e32 v2, v24, v2                                  // 000000FB8794: 06040518
	s_waitcnt vmcnt(0)                                         // 000000FB8798: BF8903F7
	ds_bpermute_b32 v4, v1, v22                                // 000000FB879C: DACC0000 04001601
	ds_bpermute_b32 v3, v1, v23                                // 000000FB87A4: DACC0000 03001701
	ds_bpermute_b32 v6, v1, v20                                // 000000FB87AC: DACC0000 06001401
	ds_bpermute_b32 v5, v1, v21                                // 000000FB87B4: DACC0000 05001501
	ds_bpermute_b32 v7, v1, v19                                // 000000FB87BC: DACC0000 07001301
	ds_bpermute_b32 v10, v1, v18                               // 000000FB87C4: DACC0000 0A001201
	ds_bpermute_b32 v1, v1, v16                                // 000000FB87CC: DACC0000 01001001
	s_waitcnt lgkmcnt(6)                                       // 000000FB87D4: BF89FC67
	v_dual_add_f32 v4, v22, v4 :: v_dual_lshlrev_b32 v11, 2, v11// 000000FB87D8: C9220916 040A1682
	ds_bpermute_b32 v12, v11, v2                               // 000000FB87E0: DACC0000 0C00020B
	s_waitcnt lgkmcnt(5)                                       // 000000FB87E8: BF89FC57
	v_dual_add_f32 v3, v23, v3 :: v_dual_add_f32 v6, v20, v6   // 000000FB87EC: C9080717 03060D14
	v_xor_b32_e32 v20, 4, v0                                   // 000000FB87F4: 3A280084
	s_waitcnt lgkmcnt(2)                                       // 000000FB87F8: BF89FC27
	v_dual_add_f32 v5, v21, v5 :: v_dual_add_f32 v10, v18, v10 // 000000FB87FC: C9080B15 050A1512
	s_waitcnt lgkmcnt(1)                                       // 000000FB8804: BF89FC17
	v_add_f32_e32 v1, v16, v1                                  // 000000FB8808: 06020310
	ds_bpermute_b32 v13, v11, v3                               // 000000FB880C: DACC0000 0D00030B
	.long 0xd44c0000                                           // 000000FB8814: D44C0000
	v_cndmask_b32_e32 v1, 32, v20, vcc_lo                      // 000000FB8818: 020228A0
	ds_bpermute_b32 v14, v11, v4                               // 000000FB881C: DACC0000 0E00040B
	ds_bpermute_b32 v16, v11, v5                               // 000000FB8824: DACC0000 1000050B
	ds_bpermute_b32 v17, v11, v6                               // 000000FB882C: DACC0000 1100060B
	v_cndmask_b32_e64 v20, v0, v20, s0                         // 000000FB8834: D5010014 00022900
	v_add_f32_e32 v7, v19, v7                                  // 000000FB883C: 060E0F13
	ds_bpermute_b32 v19, v11, v10                              // 000000FB8840: DACC0000 13000A0B
	v_lshlrev_b32_e32 v20, 2, v20                              // 000000FB8848: 30282882
	ds_bpermute_b32 v18, v11, v7                               // 000000FB884C: DACC0000 1200070B
	s_waitcnt lgkmcnt(6)                                       // 000000FB8854: BF89FC67
	v_add_f32_e32 v2, v2, v12                                  // 000000FB8858: 06041902
	ds_bpermute_b32 v11, v11, v1                               // 000000FB885C: DACC0000 0B00010B
	s_waitcnt lgkmcnt(5)                                       // 000000FB8864: BF89FC57
	v_dual_add_f32 v3, v3, v13 :: v_dual_add_f32 v4, v4, v14   // 000000FB8868: C9081B03 03041D04
	s_waitcnt lgkmcnt(3)                                       // 000000FB8870: BF89FC37
	v_dual_add_f32 v5, v5, v16 :: v_dual_add_f32 v6, v6, v17   // 000000FB8874: C9082105 05062306
	ds_bpermute_b32 v12, v20, v3                               // 000000FB887C: DACC0000 0C000314
	ds_bpermute_b32 v13, v20, v4                               // 000000FB8884: DACC0000 0D000414
	s_waitcnt lgkmcnt(4)                                       // 000000FB888C: BF89FC47
	v_add_f32_e32 v10, v10, v19                                // 000000FB8890: 0614270A
	ds_bpermute_b32 v14, v20, v5                               // 000000FB8894: DACC0000 0E000514
	ds_bpermute_b32 v16, v20, v6                               // 000000FB889C: DACC0000 10000614
	s_waitcnt lgkmcnt(5)                                       // 000000FB88A4: BF89FC57
	v_add_f32_e32 v7, v7, v18                                  // 000000FB88A8: 060E2507
	ds_bpermute_b32 v18, v20, v10                              // 000000FB88AC: DACC0000 12000A14
	s_waitcnt lgkmcnt(5)                                       // 000000FB88B4: BF89FC57
	v_add_f32_e32 v1, v1, v11                                  // 000000FB88B8: 06021701
	ds_bpermute_b32 v11, v20, v2                               // 000000FB88BC: DACC0000 0B000214
	ds_bpermute_b32 v17, v20, v7                               // 000000FB88C4: DACC0000 11000714
	ds_bpermute_b32 v19, v20, v1                               // 000000FB88CC: DACC0000 13000114
	v_xor_b32_e32 v20, 2, v0                                   // 000000FB88D4: 3A280082
	s_delay_alu instid0(VALU_DEP_1)                            // 000000FB88D8: BF870001
	.long 0xd44c0000                                           // 000000FB88DC: D44C0000
	v_cndmask_b32_e32 v1, 32, v20, vcc_lo                      // 000000FB88E0: 020228A0
	s_waitcnt lgkmcnt(6)                                       // 000000FB88E4: BF89FC67
	v_dual_add_f32 v3, v3, v12 :: v_dual_add_f32 v4, v4, v13   // 000000FB88E8: C9081903 03041B04
	v_xor_b32_e32 v12, 1, v0                                   // 000000FB88F0: 3A180081
	s_waitcnt lgkmcnt(5)                                       // 000000FB88F4: BF89FC57
	v_add_f32_e32 v5, v5, v14                                  // 000000FB88F8: 060A1D05
	v_cndmask_b32_e64 v20, v0, v20, s0                         // 000000FB88FC: D5010014 00022900
	s_waitcnt lgkmcnt(4)                                       // 000000FB8904: BF89FC47
	v_add_f32_e32 v6, v6, v16                                  // 000000FB8908: 060C2106
	.long 0xd44c0000                                           // 000000FB890C: D44C0000
	v_cndmask_b32_e32 v1, 32, v12, vcc_lo                      // 000000FB8910: 020218A0
	s_delay_alu instid0(VALU_DEP_3)                            // 000000FB8914: BF870003
	v_lshlrev_b32_e32 v20, 2, v20                              // 000000FB8918: 30282882
	s_waitcnt lgkmcnt(1)                                       // 000000FB891C: BF89FC17
	v_dual_add_f32 v2, v2, v11 :: v_dual_add_f32 v7, v7, v17   // 000000FB8920: C9081702 02062307
	s_waitcnt lgkmcnt(0)                                       // 000000FB8928: BF89FC07
	v_dual_add_f32 v10, v10, v18 :: v_dual_add_f32 v11, v1, v19// 000000FB892C: C908250A 0A0A2701
	ds_bpermute_b32 v13, v20, v3                               // 000000FB8934: DACC0000 0D000314
	ds_bpermute_b32 v1, v20, v2                                // 000000FB893C: DACC0000 01000214
	ds_bpermute_b32 v14, v20, v4                               // 000000FB8944: DACC0000 0E000414
	ds_bpermute_b32 v16, v20, v5                               // 000000FB894C: DACC0000 10000514
	ds_bpermute_b32 v17, v20, v6                               // 000000FB8954: DACC0000 11000614
	ds_bpermute_b32 v18, v20, v7                               // 000000FB895C: DACC0000 12000714
	ds_bpermute_b32 v19, v20, v10                              // 000000FB8964: DACC0000 13000A14
	ds_bpermute_b32 v20, v20, v11                              // 000000FB896C: DACC0000 14000B14
	v_cndmask_b32_e64 v0, v0, v12, s0                          // 000000FB8974: D5010000 00021900
	.long 0xd44a0000                                           // 000000FB897C: D44A0000
	v_cndmask_b32_e32 v1, 0, v15, vcc_lo                       // 000000FB8980: 02021E80
	s_delay_alu instid0(VALU_DEP_2)                            // 000000FB8984: BF870002
	v_lshlrev_b32_e32 v21, 2, v0                               // 000000FB8988: 302A0082
	s_and_b32 s0, s0, vcc_lo                                   // 000000FB898C: 8B006A00
	s_waitcnt lgkmcnt(7)                                       // 000000FB8990: BF89FC77
	v_add_f32_e32 v13, v3, v13                                 // 000000FB8994: 061A1B03
	s_waitcnt lgkmcnt(6)                                       // 000000FB8998: BF89FC67
	v_add_f32_e32 v12, v2, v1                                  // 000000FB899C: 06180302
	s_waitcnt lgkmcnt(5)                                       // 000000FB89A0: BF89FC57
	v_add_f32_e32 v14, v4, v14                                 // 000000FB89A4: 061C1D04
	s_waitcnt lgkmcnt(3)                                       // 000000FB89A8: BF89FC37
	v_dual_add_f32 v0, v5, v16 :: v_dual_add_f32 v1, v6, v17   // 000000FB89AC: C9082105 00002306
	s_waitcnt lgkmcnt(1)                                       // 000000FB89B4: BF89FC17
	v_dual_add_f32 v2, v7, v18 :: v_dual_add_f32 v3, v10, v19  // 000000FB89B8: C9082507 0202270A
	s_waitcnt lgkmcnt(0)                                       // 000000FB89C0: BF89FC07
	v_add_f32_e32 v4, v11, v20                                 // 000000FB89C4: 0608290B
	ds_bpermute_b32 v16, v21, v12                              // 000000FB89C8: DACC0000 10000C15
	ds_bpermute_b32 v17, v21, v13                              // 000000FB89D0: DACC0000 11000D15
	ds_bpermute_b32 v18, v21, v14                              // 000000FB89D8: DACC0000 12000E15
	ds_bpermute_b32 v5, v21, v0                                // 000000FB89E0: DACC0000 05000015
	ds_bpermute_b32 v6, v21, v1                                // 000000FB89E8: DACC0000 06000115
	ds_bpermute_b32 v7, v21, v2                                // 000000FB89F0: DACC0000 07000215
	ds_bpermute_b32 v10, v21, v3                               // 000000FB89F8: DACC0000 0A000315
	ds_bpermute_b32 v11, v21, v4                               // 000000FB8A00: DACC0000 0B000415
	s_and_saveexec_b32 s1, s0                                  // 000000FB8A08: BE812000
	s_cbranch_execz 273                                        // 000000FB8A0C: BFA50111 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi1ELb1ELi4ELi0EEEvPKhPKtPvlllllS6_f+0x1354>
	s_waitcnt lgkmcnt(6)                                       // 000000FB8A10: BF89FC67
	v_dual_add_f32 v12, v12, v16 :: v_dual_add_f32 v13, v13, v17// 000000FB8A14: C908210C 0C0C230D
	s_waitcnt lgkmcnt(5)                                       // 000000FB8A1C: BF89FC57
	v_add_f32_e32 v14, v14, v18                                // 000000FB8A20: 061C250E
	s_waitcnt lgkmcnt(2)                                       // 000000FB8A24: BF89FC27
	v_add_f32_e32 v2, v2, v7                                   // 000000FB8A28: 06040F02
	s_lshl_b64 s[2:3], s[12:13], 2                             // 000000FB8A2C: 8482820C
	v_dual_mul_f32 v12, 0xbfb8aa3b, v12 :: v_dual_mul_f32 v13, 0xbfb8aa3b, v13// 000000FB8A30: C8C618FF 0C0C1AFF BFB8AA3B
	v_dual_mul_f32 v14, 0xbfb8aa3b, v14 :: v_dual_add_f32 v5, v0, v5// 000000FB8A3C: C8C81CFF 0E040B00 BFB8AA3B
	s_waitcnt lgkmcnt(1)                                       // 000000FB8A48: BF89FC17
	v_add_f32_e32 v10, v3, v10                                 // 000000FB8A4C: 06141503
	v_add_f32_e32 v3, v1, v6                                   // 000000FB8A50: 06060D01
	v_exp_f32_e32 v12, v12                                     // 000000FB8A54: 7E184B0C
	v_exp_f32_e32 v14, v14                                     // 000000FB8A58: 7E1C4B0E
	v_exp_f32_e32 v13, v13                                     // 000000FB8A5C: 7E1A4B0D
	.long 0xd73c0000                                           // 000000FB8A60: D73C0000
	v_cndmask_b32_e32 v1, 2, v8, vcc_lo                        // 000000FB8A64: 02021082
	s_waitcnt lgkmcnt(0)                                       // 000000FB8A68: BF89FC07
	v_dual_add_f32 v4, v4, v11 :: v_dual_mul_f32 v5, 0xbfb8aa3b, v5// 000000FB8A6C: C9061704 04040AFF BFB8AA3B
	s_lshl_b64 s[4:5], s[12:13], 3                             // 000000FB8A78: 8484830C
	v_mul_f32_e32 v3, 0xbfb8aa3b, v3                           // 000000FB8A7C: 100606FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000FB8A84: BF870313
	.long 0xd7006a00                                           // 000000FB8A88: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 000000FB8A8C: 02020008
	v_add_f32_e32 v8, 1.0, v14                                 // 000000FB8A90: 06101CF2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000FB8A94: BF8701B5
	v_dual_add_f32 v6, 1.0, v12 :: v_dual_add_f32 v7, 1.0, v13 // 000000FB8A98: C90818F2 06061AF2
	v_exp_f32_e32 v5, v5                                       // 000000FB8AA0: 7E0A4B05
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 000000FB8AA4: D5207C01 01AA0209
	v_div_scale_f32 v12, null, v8, v8, 1.0                     // 000000FB8AAC: D6FC7C0C 03CA1108
	s_delay_alu instid0(VALU_DEP_3)                            // 000000FB8AB4: BF870003
	v_div_scale_f32 v9, null, v6, v6, 1.0                      // 000000FB8AB8: D6FC7C09 03CA0D06
	v_div_scale_f32 v11, null, v7, v7, 1.0                     // 000000FB8AC0: D6FC7C0B 03CA0F07
	v_div_scale_f32 v20, s0, 1.0, v7, 1.0                      // 000000FB8AC8: D6FC0014 03CA0EF2
	v_exp_f32_e32 v3, v3                                       // 000000FB8AD0: 7E064B03
	v_rcp_f32_e32 v15, v12                                     // 000000FB8AD4: 7E1E550C
	v_rcp_f32_e32 v13, v9                                      // 000000FB8AD8: 7E1A5509
	v_rcp_f32_e32 v14, v11                                     // 000000FB8ADC: 7E1C550B
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000FB8AE0: BF870317
	v_fma_f32 v19, -v12, v15, 1.0                              // 000000FB8AE4: D6130013 23CA1F0C
	v_fma_f32 v17, -v9, v13, 1.0                               // 000000FB8AEC: D6130011 23CA1B09
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000FB8AF4: BF870195
	v_fma_f32 v18, -v11, v14, 1.0                              // 000000FB8AF8: D6130012 23CA1D0B
	v_fmac_f32_e32 v15, v19, v15                               // 000000FB8B00: 561E1F13
	v_div_scale_f32 v21, s1, 1.0, v8, 1.0                      // 000000FB8B04: D6FC0115 03CA10F2
	v_add_f32_e32 v16, 1.0, v5                                 // 000000FB8B0C: 06200AF2
	v_div_scale_f32 v5, vcc_lo, 1.0, v6, 1.0                   // 000000FB8B10: D6FC6A05 03CA0CF2
	v_dual_fmac_f32 v13, v17, v13 :: v_dual_mul_f32 v2, 0xbfb8aa3b, v2// 000000FB8B18: C8061B11 0D0204FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000FB8B24: BF870114
	v_mul_f32_e32 v23, v21, v15                                // 000000FB8B28: 102E1F15
	v_mul_f32_e32 v19, v5, v13                                 // 000000FB8B2C: 10261B05
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000FB8B30: BF870113
	v_exp_f32_e32 v17, v2                                      // 000000FB8B34: 7E224B02
	v_fma_f32 v28, -v12, v23, v21                              // 000000FB8B38: D613001C 24562F0C
	v_fmac_f32_e32 v14, v18, v14                               // 000000FB8B40: 561C1D12
	v_div_scale_f32 v18, null, v16, v16, 1.0                   // 000000FB8B44: D6FC7C12 03CA2110
	v_fma_f32 v26, -v9, v19, v5                                // 000000FB8B4C: D613001A 24162709
	v_add_f32_e32 v24, 1.0, v3                                 // 000000FB8B54: 063006F2
	v_fmac_f32_e32 v23, v28, v15                               // 000000FB8B58: 562E1F1C
	v_mul_f32_e32 v22, v20, v14                                // 000000FB8B5C: 102C1D14
	v_rcp_f32_e32 v25, v18                                     // 000000FB8B60: 7E325512
	v_fmac_f32_e32 v19, v26, v13                               // 000000FB8B64: 56261B1A
	v_add_f32_e32 v17, 1.0, v17                                // 000000FB8B68: 062222F2
	.long 0xd7000202                                           // 000000FB8B6C: D7000202
	v_cndmask_b32_e32 v0, v0, v2, vcc_lo                       // 000000FB8B70: 02000500
	v_fma_f32 v27, -v11, v22, v20                              // 000000FB8B74: D613001B 24522D0B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000FB8B7C: BF870234
	v_fma_f32 v5, -v9, v19, v5                                 // 000000FB8B80: D6130005 24162709
	v_add_co_ci_u32_e64 v3, null, s3, v1, s2                   // 000000FB8B88: D5207C03 000A0203
	v_div_scale_f32 v26, null, v24, v24, 1.0                   // 000000FB8B90: D6FC7C1A 03CA3118
	v_fmac_f32_e32 v22, v27, v14                               // 000000FB8B98: 562C1D1B
	s_delay_alu instid0(TRANS32_DEP_1)                         // 000000FB8B9C: BF870005
	v_fma_f32 v27, -v18, v25, 1.0                              // 000000FB8BA0: D613001B 23CA3312
	v_div_fmas_f32 v5, v5, v13, v19                            // 000000FB8BA8: D6370005 044E1B05
	s_mov_b32 vcc_lo, s0                                       // 000000FB8BB0: BEEA0000
	v_mul_f32_e32 v10, 0xbfb8aa3b, v10                         // 000000FB8BB4: 101414FF BFB8AA3B
	v_fma_f32 v9, -v11, v22, v20                               // 000000FB8BBC: D6130009 24522D0B
	v_fma_f32 v11, -v12, v23, v21                              // 000000FB8BC4: D613000B 24562F0C
	v_div_fixup_f32 v5, v5, v6, 1.0                            // 000000FB8BCC: D6270005 03CA0D05
	v_fmac_f32_e32 v25, v27, v25                               // 000000FB8BD4: 5632331B
	v_div_scale_f32 v13, null, v17, v17, 1.0                   // 000000FB8BD8: D6FC7C0D 03CA2311
	v_div_fmas_f32 v9, v9, v14, v22                            // 000000FB8BE0: D6370009 045A1D09
	s_mov_b32 vcc_lo, s1                                       // 000000FB8BE8: BEEA0001
	v_exp_f32_e32 v10, v10                                     // 000000FB8BEC: 7E144B0A
	v_div_fmas_f32 v11, v11, v15, v23                          // 000000FB8BF0: D637000B 045E1F0B
	v_div_scale_f32 v6, vcc_lo, 1.0, v16, 1.0                  // 000000FB8BF8: D6FC6A06 03CA20F2
	v_div_fixup_f32 v7, v9, v7, 1.0                            // 000000FB8C00: D6270007 03CA0F09
	v_rcp_f32_e32 v19, v13                                     // 000000FB8C08: 7E26550D
	global_store_b32 v[0:1], v5, off                           // 000000FB8C0C: DC6A0000 007C0500
	v_div_fixup_f32 v8, v11, v8, 1.0                           // 000000FB8C14: D6270008 03CA110B
	v_mul_f32_e32 v9, v6, v25                                  // 000000FB8C1C: 10123306
	v_rcp_f32_e32 v12, v26                                     // 000000FB8C20: 7E18551A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000FB8C24: BF8700B1
	v_fma_f32 v15, -v18, v9, v6                                // 000000FB8C28: D613000F 241A1312
	v_mul_f32_e32 v14, 0xbfb8aa3b, v4                          // 000000FB8C30: 101C08FF BFB8AA3B
	.long 0xd7000004                                           // 000000FB8C38: D7000004
	v_cndmask_b32_e32 v0, v0, v4, vcc_lo                       // 000000FB8C3C: 02000900
	v_add_co_ci_u32_e64 v5, null, s5, v1, s0                   // 000000FB8C40: D5207C05 00020205
	s_clause 0x1                                               // 000000FB8C48: BF850001
	global_store_b32 v[2:3], v7, off                           // 000000FB8C4C: DC6A0000 007C0702
	global_store_b32 v[4:5], v8, off                           // 000000FB8C54: DC6A0000 007C0804
	v_fma_f32 v3, -v13, v19, 1.0                               // 000000FB8C5C: D6130003 23CA270D
	v_dual_add_f32 v10, 1.0, v10 :: v_dual_fmac_f32 v9, v15, v25// 000000FB8C64: C90014F2 0A08330F
	v_exp_f32_e32 v14, v14                                     // 000000FB8C6C: 7E1C4B0E
	v_fma_f32 v11, -v26, v12, 1.0                              // 000000FB8C70: D613000B 23CA191A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000FB8C78: BF870193
	v_fmac_f32_e32 v19, v3, v19                                // 000000FB8C7C: 56262703
	v_div_scale_f32 v7, null, v10, v10, 1.0                    // 000000FB8C80: D6FC7C07 03CA150A
	v_fma_f32 v6, -v18, v9, v6                                 // 000000FB8C88: D6130006 241A1312
	v_div_scale_f32 v3, s1, 1.0, v17, 1.0                      // 000000FB8C90: D6FC0103 03CA22F2
	v_mad_u64_u32 v[0:1], null, s12, 12, v[0:1]                // 000000FB8C98: D6FE7C00 0401180C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000FB8CA0: BF870194
	v_rcp_f32_e32 v15, v7                                      // 000000FB8CA4: 7E1E5507
	v_div_fmas_f32 v6, v6, v25, v9                             // 000000FB8CA8: D6370006 04263306
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000FB8CB0: BF870116
	v_add_f32_e32 v8, 1.0, v14                                 // 000000FB8CB4: 06101CF2
	v_div_fixup_f32 v16, v6, v16, 1.0                          // 000000FB8CB8: D6270010 03CA2106
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000FB8CC0: BF870292
	v_div_scale_f32 v18, null, v8, v8, 1.0                     // 000000FB8CC4: D6FC7C12 03CA1108
	v_fma_f32 v20, -v7, v15, 1.0                               // 000000FB8CCC: D6130014 23CA1F07
	v_fmac_f32_e32 v12, v11, v12                               // 000000FB8CD4: 5618190B
	v_div_scale_f32 v11, s0, 1.0, v24, 1.0                     // 000000FB8CD8: D6FC000B 03CA30F2
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000FB8CE0: BF8700D4
	v_rcp_f32_e32 v9, v18                                      // 000000FB8CE4: 7E125512
	s_mov_b32 vcc_lo, s0                                       // 000000FB8CE8: BEEA0000
	v_fmac_f32_e32 v15, v20, v15                               // 000000FB8CEC: 561E1F14
	v_div_scale_f32 v20, s2, 1.0, v10, 1.0                     // 000000FB8CF0: D6FC0214 03CA14F2
	v_mul_f32_e32 v2, v11, v12                                 // 000000FB8CF8: 1004190B
	v_fma_f32 v14, -v26, v2, v11                               // 000000FB8CFC: D613000E 242E051A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000FB8D04: BF870115
	v_fma_f32 v21, -v18, v9, 1.0                               // 000000FB8D08: D6130015 23CA1312
	v_fmac_f32_e32 v2, v14, v12                                // 000000FB8D10: 5604190E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000FB8D14: BF870112
	v_dual_mul_f32 v14, v3, v19 :: v_dual_fmac_f32 v9, v21, v9 // 000000FB8D18: C8C02703 0E081315
	v_fma_f32 v6, -v26, v2, v11                                // 000000FB8D20: D6130006 242E051A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000FB8D28: BF870112
	v_fma_f32 v11, -v13, v14, v3                               // 000000FB8D2C: D613000B 240E1D0D
	v_div_fmas_f32 v6, v6, v12, v2                             // 000000FB8D34: D6370006 040A1906
	s_delay_alu instid0(VALU_DEP_2)                            // 000000FB8D3C: BF870002
	v_fmac_f32_e32 v14, v11, v19                               // 000000FB8D40: 561C270B
	v_mul_f32_e32 v11, v20, v15                                // 000000FB8D44: 10161F14
	v_div_scale_f32 v12, s0, 1.0, v8, 1.0                      // 000000FB8D48: D6FC000C 03CA10F2
	v_mad_u64_u32 v[1:2], null, s13, 12, v[1:2]                // 000000FB8D50: D6FE7C01 0405180D
	v_div_fixup_f32 v21, v6, v24, 1.0                          // 000000FB8D58: D6270015 03CA3106
	v_fma_f32 v2, -v13, v14, v3                                // 000000FB8D60: D6130002 240E1D0D
	v_fma_f32 v3, -v7, v11, v20                                // 000000FB8D68: D6130003 24521707
	v_mul_f32_e32 v6, v12, v9                                  // 000000FB8D70: 100C130C
	s_mov_b32 vcc_lo, s1                                       // 000000FB8D74: BEEA0001
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000FB8D78: BF870193
	v_div_fmas_f32 v13, v2, v19, v14                           // 000000FB8D7C: D637000D 043A2702
	v_fmac_f32_e32 v11, v3, v15                                // 000000FB8D84: 56161F03
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FB8D88: BF8700A3
	v_fma_f32 v14, -v18, v6, v12                               // 000000FB8D8C: D613000E 24320D12
	.long 0xd7006a02                                           // 000000FB8D94: D7006A02
	v_cndmask_b32_e32 v0, v4, v4, vcc_lo                       // 000000FB8D98: 02000904
	v_add_co_ci_u32_e64 v3, null, s5, v5, vcc_lo               // 000000FB8D9C: D5207C03 01AA0A05
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000FB8DA4: BF870214
	v_fma_f32 v4, -v7, v11, v20                                // 000000FB8DA8: D6130004 24521707
	v_fmac_f32_e32 v6, v14, v9                                 // 000000FB8DB0: 560C130E
	s_mov_b32 vcc_lo, s2                                       // 000000FB8DB4: BEEA0002
	v_div_fixup_f32 v13, v13, v17, 1.0                         // 000000FB8DB8: D627000D 03CA230D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000FB8DC0: BF870193
	v_div_fmas_f32 v7, v4, v15, v11                            // 000000FB8DC4: D6370007 042E1F04
	v_fma_f32 v11, -v18, v6, v12                               // 000000FB8DCC: D613000B 24320D12
	.long 0xd7006a04                                           // 000000FB8DD4: D7006A04
	v_cndmask_b32_e32 v0, v0, v4, vcc_lo                       // 000000FB8DD8: 02000900
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000FB8DDC: BF8700D1
	v_add_co_ci_u32_e64 v5, null, s5, v1, vcc_lo               // 000000FB8DE0: D5207C05 01AA0205
	s_mov_b32 vcc_lo, s0                                       // 000000FB8DE8: BEEA0000
	v_div_fixup_f32 v10, v7, v10, 1.0                          // 000000FB8DEC: D627000A 03CA1507
	v_div_fmas_f32 v9, v11, v9, v6                             // 000000FB8DF4: D6370009 041A130B
	.long 0xd7006a06                                           // 000000FB8DFC: D7006A06
	v_cndmask_b32_e32 v0, v2, v4, vcc_lo                       // 000000FB8E00: 02000902
	v_add_co_ci_u32_e64 v7, null, s5, v3, vcc_lo               // 000000FB8E04: D5207C07 01AA0605
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FB8E0C: BF8700A3
	v_div_fixup_f32 v11, v9, v8, 1.0                           // 000000FB8E10: D627000B 03CA1109
	.long 0xd7006a08                                           // 000000FB8E18: D7006A08
	v_cndmask_b32_e32 v0, v4, v4, vcc_lo                       // 000000FB8E1C: 02000904
	v_add_co_ci_u32_e64 v9, null, s5, v5, vcc_lo               // 000000FB8E20: D5207C09 01AA0A05
	s_clause 0x4                                               // 000000FB8E28: BF850004
	global_store_b32 v[0:1], v16, off                          // 000000FB8E2C: DC6A0000 007C1000
	global_store_b32 v[2:3], v21, off                          // 000000FB8E34: DC6A0000 007C1502
	global_store_b32 v[4:5], v13, off                          // 000000FB8E3C: DC6A0000 007C0D04
	global_store_b32 v[6:7], v10, off                          // 000000FB8E44: DC6A0000 007C0A06
	global_store_b32 v[8:9], v11, off                          // 000000FB8E4C: DC6A0000 007C0B08
	s_endpgm                                                   // 000000FB8E54: BFB00000
		...

