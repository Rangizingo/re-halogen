000000000084eb00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 00000084EB00: F4100100 F8000000
	v_dual_mov_b32 v4, 0 :: v_dual_and_b32 v1, 15, v0          // 00000084EB08: CA240080 0400008F
	v_lshrrev_b32_e32 v2, 2, v0                                // 00000084EB10: 32040082
	s_ashr_i32 s3, s2, 31                                      // 00000084EB14: 86039F02
	s_delay_alu instid0(VALU_DEP_2)                            // 00000084EB18: BF870002
	v_dual_mov_b32 v16, 0 :: v_dual_lshlrev_b32 v1, 2, v1      // 00000084EB1C: CA220080 10000282
	s_lshl_b64 s[2:3], s[2:3], 3                               // 00000084EB24: 84828302
	s_delay_alu instid0(VALU_DEP_2) | instid1(SALU_CYCLE_1)    // 00000084EB28: BF870482
	v_dual_mov_b32 v9, s3 :: v_dual_and_b32 v2, 60, v2         // 00000084EB2C: CA240003 090204BC
	.long 0x7f183880                                           // 00000084EB34: 7F183880
	v_and_b32_e32 v15, 31, v0                                  // 00000084EB38: 361E009F
	v_dual_mov_b32 v25, 0 :: v_dual_mov_b32 v6, 0              // 00000084EB3C: CA100080 19060080
	s_waitcnt lgkmcnt(0)                                       // 00000084EB44: BF89FC07
	s_clause 0x1                                               // 00000084EB48: BF850001
	global_load_b32 v3, v1, s[4:5]                             // 00000084EB4C: DC520000 03040001
	global_load_b32 v7, v2, s[4:5]                             // 00000084EB54: DC520000 07040002
	v_lshrrev_b32_e32 v1, 5, v0                                // 00000084EB5C: 32020085
	s_add_u32 s14, s4, s14                                     // 00000084EB60: 800E0E04
	s_addc_u32 s15, s5, s15                                    // 00000084EB64: 820F0F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000084EB68: BF8704A1
	v_or_b32_e32 v8, s2, v1                                    // 00000084EB6C: 38100202
	s_lshr_b32 s2, s11, 31                                     // 00000084EB70: 85029F0B
	s_add_u32 s20, s10, s2                                     // 00000084EB74: 8014020A
	s_addc_u32 s21, s11, 0                                     // 00000084EB78: 8215800B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000084EB7C: BF870001
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[8:9]                  // 00000084EB80: 7CA8100C
	v_mov_b32_e32 v5, 0                                        // 00000084EB84: 7E0A0280
	s_ashr_i32 s22, s11, 31                                    // 00000084EB88: 86169F0B
	v_cndmask_b32_e32 v10, 0, v8, vcc_lo                       // 00000084EB8C: 02141080
	v_cndmask_b32_e64 v14, 0, s3, vcc_lo                       // 00000084EB90: D501000E 01A80680
	s_ashr_i64 s[2:3], s[20:21], 1                             // 00000084EB98: 86828114
	s_delay_alu instid0(VALU_DEP_2)                            // 00000084EB9C: BF870002
	.long 0xd72c000d                                           // 00000084EBA0: D72C000D
	v_cndmask_b32_e32 v1, s19, v10, vcc_lo                     // 00000084EBA4: 02021413
	v_mad_u64_u32 v[1:2], null, s18, v10, 0                    // 00000084EBA8: D6FE7C01 02021412
	.long 0xd72c0011                                           // 00000084EBB0: D72C0011
	v_cndmask_b32_e32 v0, v10, v3, vcc_lo                      // 00000084EBB4: 0200070A
	.long 0xd72c0013                                           // 00000084EBB8: D72C0013
	v_cndmask_b32_e32 v0, v14, v2, vcc_lo                      // 00000084EBBC: 0200050E
	s_lshr_b32 s19, s22, 27                                    // 00000084EBC0: 85139B16
	s_waitcnt vmcnt(1)                                         // 00000084EBC4: BF8907F7
	v_bfe_u32 v11, v3, 16, 1                                   // 00000084EBC8: D610000B 02052103
	s_waitcnt vmcnt(0)                                         // 00000084EBD0: BF8903F7
	v_bfe_u32 v18, v7, 16, 1                                   // 00000084EBD4: D6100012 02052107
	s_delay_alu instid0(VALU_DEP_2)                            // 00000084EBDC: BF870002
	v_add3_u32 v3, v3, v11, 0x7fff                             // 00000084EBE0: D6550003 03FE1703 00007FFF
	v_mad_u64_u32 v[10:11], null, v10, s2, s[14:15]            // 00000084EBEC: D6FE7C0A 0038050A
	s_add_u32 s14, s10, s19                                    // 00000084EBF4: 800E130A
	v_add3_u32 v7, v7, v18, 0x7fff                             // 00000084EBF8: D6550007 03FE2507 00007FFF
	s_addc_u32 s15, s11, 0                                     // 00000084EC04: 820F800B
	.long 0x7e183983                                           // 00000084EC08: 7E183983
	.long 0xd72c0003                                           // 00000084EC0C: D72C0003
	v_cndmask_b32_e32 v1, s18, v14, vcc_lo                     // 00000084EC10: 02021C12
	s_lshr_b64 s[14:15], s[14:15], 5                           // 00000084EC14: 858E850E
	v_lshlrev_b32_e32 v14, 2, v0                               // 00000084EC18: 301C0082
	.long 0xd4440002                                           // 00000084EC1C: D4440002
	v_cndmask_b32_e32 v1, s14, v15, vcc_lo                     // 00000084EC20: 02021E0E
	v_and_or_b32 v12, 0xffff0000, v7, v12                      // 00000084EC24: D657000C 04320EFF FFFF0000
	v_mov_b32_e32 v7, 0                                        // 00000084EC30: 7E0E0280
	v_add3_u32 v17, v19, v11, v17                              // 00000084EC34: D6550011 04461713
	v_add3_u32 v0, v2, v3, v13                                 // 00000084EC3C: D6550000 04360702
	ds_store_b32 v14, v12                                      // 00000084EC44: D8340000 00000C0E
	s_waitcnt lgkmcnt(0)                                       // 00000084EC4C: BF89FC07
	s_barrier                                                  // 00000084EC50: BFBD0000
	buffer_gl0_inv                                             // 00000084EC54: E0AC0000 00000000
	s_and_saveexec_b32 s15, s2                                 // 00000084EC5C: BE8F2002
	s_cbranch_execz 26                                         // 00000084EC60: BFA5001A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x1cc>
	s_add_u32 s3, s4, s16                                      // 00000084EC64: 80031004
	s_addc_u32 s18, s5, s17                                    // 00000084EC68: 82121105
	v_lshlrev_b32_e32 v2, 1, v15                               // 00000084EC6C: 30041E81
	.long 0xd7000303                                           // 00000084EC70: D7000303
	v_cndmask_b32_e32 v1, s3, v1, vcc_lo                       // 00000084EC74: 02020203
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000084EC78: BF8701A1
	v_add_co_ci_u32_e64 v4, null, s18, v0, s3                  // 00000084EC7C: D5207C04 000E0012
	v_lshlrev_b32_e32 v5, 4, v15                               // 00000084EC84: 300A1E84
	.long 0xd7000302                                           // 00000084EC88: D7000302
	v_cndmask_b32_e32 v1, v3, v2, vcc_lo                       // 00000084EC8C: 02020503
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000084EC90: BF870191
	v_add_co_ci_u32_e64 v3, null, 0, v4, s3                    // 00000084EC94: D5207C03 000E0880
	.long 0xd7000304                                           // 00000084EC9C: D7000304
	v_cndmask_b32_e32 v1, v10, v5, vcc_lo                      // 00000084ECA0: 02020B0A
	s_delay_alu instid0(VALU_DEP_1)                            // 00000084ECA4: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v17, s3                   // 00000084ECA8: D5207C05 000E2280
	s_clause 0x1                                               // 00000084ECB0: BF850001
	global_load_d16_b16 v2, v[2:3], off                        // 00000084ECB4: DC820000 027C0002
	global_load_b128 v[4:7], v[4:5], off                       // 00000084ECBC: DC5E0000 047C0004
	s_waitcnt vmcnt(1)                                         // 00000084ECC4: BF8907F7
	v_cvt_f32_f16_e32 v25, v2                                  // 00000084ECC8: 7E321702
	s_or_b32 exec_lo, exec_lo, s15                             // 00000084ECCC: 8C7E0F7E
	v_dual_mov_b32 v18, 0 :: v_dual_mov_b32 v19, 0             // 00000084ECD0: CA100080 12120080
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v21, 0             // 00000084ECD8: CA100080 14140080
	s_and_saveexec_b32 s15, s2                                 // 00000084ECE0: BE8F2002
	s_cbranch_execz 478                                        // 00000084ECE4: BFA501DE <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x960>
	s_mul_i32 s2, s11, 6                                       // 00000084ECE8: 9602860B
	s_mul_hi_u32 s3, s10, 6                                    // 00000084ECEC: 9683860A
	v_dual_mov_b32 v23, v15 :: v_dual_lshlrev_b32 v2, 1, v15   // 00000084ECF0: CA22010F 17021E81
	s_add_i32 s20, s3, s2                                      // 00000084ECF8: 81140203
	.long 0xd7000201                                           // 00000084ECFC: D7000201
	v_cndmask_b32_e32 v1, s16, v1, vcc_lo                      // 00000084ED00: 02020210
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000084ED04: BF8701A1
	v_add_co_ci_u32_e64 v0, null, s17, v0, s2                  // 00000084ED08: D5207C00 000A0011
	v_dual_mov_b32 v12, 0 :: v_dual_lshlrev_b32 v11, 5, v15    // 00000084ED10: CA220080 0C0A1E85
	.long 0xd7000201                                           // 00000084ED18: D7000201
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 00000084ED1C: 02020501
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000084ED20: BF8701A1
	v_add_co_ci_u32_e64 v0, null, 0, v0, s2                    // 00000084ED24: D5207C00 000A0080
	v_lshl_or_b32 v22, v15, 4, 0x200                           // 00000084ED2C: D6560016 03FD090F 00000200
	.long 0xd7000201                                           // 00000084ED38: D7000201
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 00000084ED3C: 02020204
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000084ED40: BF8701A1
	v_add_co_ci_u32_e64 v0, null, s5, v0, s2                   // 00000084ED44: D5207C00 000A0005
	v_dual_mov_b32 v21, v12 :: v_dual_mov_b32 v24, v25         // 00000084ED4C: CA10010C 15180119
	.long 0xd700020d                                           // 00000084ED54: D700020D
	v_cndmask_b32_e32 v0, v1, v192, vcc_lo                     // 00000084ED58: 02018101
	s_delay_alu instid0(VALU_DEP_1)                            // 00000084ED5C: BF870001
	v_add_co_ci_u32_e64 v14, null, 0, v0, s2                   // 00000084ED60: D5207C0E 000A0080
	v_mov_b32_e32 v20, v12                                     // 00000084ED68: 7E28030C
	v_mov_b32_e32 v19, v12                                     // 00000084ED6C: 7E26030C
	v_mov_b32_e32 v18, v12                                     // 00000084ED70: 7E24030C
	v_mov_b32_e32 v16, v12                                     // 00000084ED74: 7E20030C
	s_lshl_b64 s[18:19], s[10:11], 2                           // 00000084ED78: 8492820A
	s_mul_i32 s17, s10, 6                                      // 00000084ED7C: 9611860A
	s_mov_b32 s16, 0                                           // 00000084ED80: BE900080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 00000084ED84: 8484810A
	s_branch 411                                               // 00000084ED88: BFA0019B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x8f8>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000084ED8C: 8C7E0A7E
	v_and_b32_e32 v26, 0xff, v4                                // 00000084ED90: 363408FF 000000FF
	s_and_b32 s2, exec_lo, s2                                  // 00000084ED98: 8B02027E
	v_add_nc_u32_e32 v22, 0x200, v22                           // 00000084ED9C: 4A2C2CFF 00000200
	s_or_b32 s16, s2, s16                                      // 00000084EDA4: 8C101002
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000084EDA8: BF8700B2
	v_lshlrev_b32_e32 v26, 2, v26                              // 00000084EDAC: 30343482
	ds_load_b32 v42, v26                                       // 00000084EDB0: D8D80000 2A00001A
	v_lshrrev_b32_e32 v26, 6, v4                               // 00000084EDB8: 32340886
	v_and_b32_e32 v26, 0x3fc, v26                              // 00000084EDBC: 363434FF 000003FC
	ds_load_b32 v43, v26                                       // 00000084EDC4: D8D80000 2B00001A
	v_lshrrev_b32_e32 v26, 14, v4                              // 00000084EDCC: 3234088E
	v_lshrrev_b32_e32 v4, 22, v4                               // 00000084EDD0: 32080896
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000084EDD4: BF870112
	v_and_b32_e32 v26, 0x3fc, v26                              // 00000084EDD8: 363434FF 000003FC
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000084EDE0: 360808FF 000003FC
	ds_load_b32 v44, v26                                       // 00000084EDE8: D8D80000 2C00001A
	ds_load_b32 v45, v4                                        // 00000084EDF0: D8D80000 2D000004
	v_and_b32_e32 v4, 0xff, v5                                 // 00000084EDF8: 36080AFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000084EE00: BF8700B1
	v_lshlrev_b32_e32 v4, 2, v4                                // 00000084EE04: 30080882
	ds_load_b32 v46, v4                                        // 00000084EE08: D8D80000 2E000004
	v_lshrrev_b32_e32 v4, 6, v5                                // 00000084EE10: 32080A86
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000084EE14: 360808FF 000003FC
	ds_load_b32 v47, v4                                        // 00000084EE1C: D8D80000 2F000004
	v_lshrrev_b32_e32 v4, 14, v5                               // 00000084EE24: 32080A8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000084EE28: BF8700B1
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000084EE2C: 360808FF 000003FC
	ds_load_b32 v48, v4                                        // 00000084EE34: D8D80000 30000004
	v_lshrrev_b32_e32 v4, 22, v5                               // 00000084EE3C: 32080A96
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000084EE40: 360808FF 000003FC
	ds_load_b32 v49, v4                                        // 00000084EE48: D8D80000 31000004
	v_and_b32_e32 v4, 0xff, v6                                 // 00000084EE50: 36080CFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000084EE58: BF8700B1
	v_lshlrev_b32_e32 v4, 2, v4                                // 00000084EE5C: 30080882
	ds_load_b32 v50, v4                                        // 00000084EE60: D8D80000 32000004
	v_lshrrev_b32_e32 v4, 6, v6                                // 00000084EE68: 32080C86
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000084EE6C: 360808FF 000003FC
	ds_load_b32 v51, v4                                        // 00000084EE74: D8D80000 33000004
	v_lshrrev_b32_e32 v4, 14, v6                               // 00000084EE7C: 32080C8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000084EE80: BF8700B1
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000084EE84: 360808FF 000003FC
	ds_load_b32 v52, v4                                        // 00000084EE8C: D8D80000 34000004
	v_lshrrev_b32_e32 v4, 22, v6                               // 00000084EE94: 32080C96
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000084EE98: 360808FF 000003FC
	ds_load_b32 v53, v4                                        // 00000084EEA0: D8D80000 35000004
	v_and_b32_e32 v4, 0xff, v7                                 // 00000084EEA8: 36080EFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000084EEB0: BF8700B1
	v_lshlrev_b32_e32 v4, 2, v4                                // 00000084EEB4: 30080882
	ds_load_b32 v54, v4                                        // 00000084EEB8: D8D80000 36000004
	v_lshrrev_b32_e32 v4, 6, v7                                // 00000084EEC0: 32080E86
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000084EEC4: 360808FF 000003FC
	ds_load_b32 v55, v4                                        // 00000084EECC: D8D80000 37000004
	v_lshrrev_b32_e32 v4, 14, v7                               // 00000084EED4: 32080E8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000084EED8: BF8700B1
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000084EEDC: 360808FF 000003FC
	ds_load_b32 v56, v4                                        // 00000084EEE4: D8D80000 38000004
	v_lshrrev_b32_e32 v4, 22, v7                               // 00000084EEEC: 32080E96
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000084EEF0: 360808FF 000003FC
	ds_load_b32 v57, v4                                        // 00000084EEF8: D8D80000 39000004
	.long 0xd73c0004                                           // 00000084EF00: D73C0004
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 00000084EF04: 02021681
	v_add_nc_u32_e32 v11, 0x400, v11                           // 00000084EF08: 4A1616FF 00000400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084EF10: BF870092
	.long 0xd7000226                                           // 00000084EF14: D7000226
	v_cndmask_b32_e32 v1, s6, v4, vcc_lo                       // 00000084EF18: 02020806
	v_add_co_ci_u32_e64 v39, null, s7, v5, s2                  // 00000084EF1C: D5207C27 000A0A07
	s_clause 0x3                                               // 00000084EF24: BF850003
	global_load_b128 v[4:7], v[38:39], off                     // 00000084EF28: DC5E0000 047C0026
	global_load_b128 v[26:29], v[38:39], off offset:16         // 00000084EF30: DC5E0010 1A7C0026
	global_load_b128 v[30:33], v[38:39], off offset:32         // 00000084EF38: DC5E0020 1E7C0026
	global_load_b128 v[34:37], v[38:39], off offset:48         // 00000084EF40: DC5E0030 227C0026
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 00000084EF48: BF890CF7
	v_dot2_f32_bf16 v4, v4, v42, 0                             // 00000084EF4C: CC1A4004 1A025504
	s_waitcnt lgkmcnt(14)                                      // 00000084EF54: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084EF58: BF8700A1
	v_dot2_f32_bf16 v4, v5, v43, v4                            // 00000084EF5C: CC1A4004 1C125705
	s_waitcnt lgkmcnt(13)                                      // 00000084EF64: BF89FCD7
	v_dot2_f32_bf16 v4, v6, v44, v4                            // 00000084EF68: CC1A4004 1C125906
	s_waitcnt lgkmcnt(12)                                      // 00000084EF70: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084EF74: BF8700A1
	v_dot2_f32_bf16 v4, v7, v45, v4                            // 00000084EF78: CC1A4004 1C125B07
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 00000084EF80: BF8908B7
	v_dot2_f32_bf16 v4, v26, v46, v4                           // 00000084EF84: CC1A4004 1C125D1A
	s_waitcnt lgkmcnt(10)                                      // 00000084EF8C: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084EF90: BF8700A1
	v_dot2_f32_bf16 v4, v27, v47, v4                           // 00000084EF94: CC1A4004 1C125F1B
	s_waitcnt lgkmcnt(9)                                       // 00000084EF9C: BF89FC97
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 00000084EFA0: CC1A4004 1C12611C
	s_waitcnt lgkmcnt(8)                                       // 00000084EFA8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084EFAC: BF8700A1
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 00000084EFB0: CC1A4004 1C12631D
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 00000084EFB8: BF890477
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 00000084EFBC: CC1A4004 1C12651E
	s_waitcnt lgkmcnt(6)                                       // 00000084EFC4: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084EFC8: BF8700A1
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 00000084EFCC: CC1A4004 1C12671F
	s_waitcnt lgkmcnt(5)                                       // 00000084EFD4: BF89FC57
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 00000084EFD8: CC1A4004 1C126920
	s_waitcnt lgkmcnt(4)                                       // 00000084EFE0: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084EFE4: BF8700A1
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 00000084EFE8: CC1A4004 1C126B21
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 00000084EFF0: BF890037
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 00000084EFF4: CC1A4004 1C126D22
	.long 0xd7000222                                           // 00000084EFFC: D7000222
	v_cndmask_b32_e32 v0, v38, v4, vcc_lo                      // 00000084F000: 02000926
	s_waitcnt lgkmcnt(2)                                       // 00000084F004: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000084F008: BF8701C2
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 00000084F00C: CC1A4004 1C126F23
	v_add_co_ci_u32_e64 v35, null, s5, v39, s2                 // 00000084F014: D5207C23 000A4E05
	.long 0xd7000228                                           // 00000084F01C: D7000228
	v_cndmask_b32_e32 v0, v38, v18, vcc_lo                     // 00000084F020: 02002526
	s_waitcnt lgkmcnt(1)                                       // 00000084F024: BF89FC17
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 00000084F028: CC1A4004 1C127124
	v_add_co_ci_u32_e64 v41, null, s19, v39, s2                // 00000084F030: D5207C29 000A4E13
	s_waitcnt lgkmcnt(0)                                       // 00000084F038: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084F03C: BF870092
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 00000084F040: CC1A4004 1C127325
	v_fmac_f32_e32 v21, v25, v4                                // 00000084F048: 562A0919
	s_clause 0x3                                               // 00000084F04C: BF850003
	global_load_b128 v[4:7], v[34:35], off                     // 00000084F050: DC5E0000 047C0022
	global_load_b128 v[26:29], v[34:35], off offset:16         // 00000084F058: DC5E0010 1A7C0022
	global_load_b128 v[30:33], v[34:35], off offset:32         // 00000084F060: DC5E0020 1E7C0022
	global_load_b128 v[34:37], v[34:35], off offset:48         // 00000084F068: DC5E0030 227C0022
	s_waitcnt vmcnt(3)                                         // 00000084F070: BF890FF7
	v_dot2_f32_bf16 v4, v4, v42, 0                             // 00000084F074: CC1A4004 1A025504
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084F07C: BF870091
	v_dot2_f32_bf16 v4, v5, v43, v4                            // 00000084F080: CC1A4004 1C125705
	v_dot2_f32_bf16 v4, v6, v44, v4                            // 00000084F088: CC1A4004 1C125906
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084F090: BF8700A1
	v_dot2_f32_bf16 v4, v7, v45, v4                            // 00000084F094: CC1A4004 1C125B07
	s_waitcnt vmcnt(2)                                         // 00000084F09C: BF890BF7
	v_dot2_f32_bf16 v4, v26, v46, v4                           // 00000084F0A0: CC1A4004 1C125D1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084F0A8: BF870091
	v_dot2_f32_bf16 v4, v27, v47, v4                           // 00000084F0AC: CC1A4004 1C125F1B
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 00000084F0B4: CC1A4004 1C12611C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084F0BC: BF8700A1
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 00000084F0C0: CC1A4004 1C12631D
	s_waitcnt vmcnt(1)                                         // 00000084F0C8: BF8907F7
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 00000084F0CC: CC1A4004 1C12651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084F0D4: BF870091
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 00000084F0D8: CC1A4004 1C12671F
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 00000084F0E0: CC1A4004 1C126920
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084F0E8: BF8700A1
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 00000084F0EC: CC1A4004 1C126B21
	s_waitcnt vmcnt(0)                                         // 00000084F0F4: BF8903F7
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 00000084F0F8: CC1A4004 1C126D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084F100: BF870091
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 00000084F104: CC1A4004 1C126F23
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 00000084F10C: CC1A4004 1C127124
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084F114: BF870091
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 00000084F118: CC1A4004 1C127325
	v_fmac_f32_e32 v20, v25, v4                                // 00000084F120: 56280919
	s_clause 0x3                                               // 00000084F124: BF850003
	global_load_b128 v[4:7], v[40:41], off                     // 00000084F128: DC5E0000 047C0028
	global_load_b128 v[26:29], v[40:41], off offset:16         // 00000084F130: DC5E0010 1A7C0028
	global_load_b128 v[30:33], v[40:41], off offset:32         // 00000084F138: DC5E0020 1E7C0028
	global_load_b128 v[34:37], v[40:41], off offset:48         // 00000084F140: DC5E0030 227C0028
	s_waitcnt vmcnt(3)                                         // 00000084F148: BF890FF7
	v_dot2_f32_bf16 v4, v4, v42, 0                             // 00000084F14C: CC1A4004 1A025504
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084F154: BF870091
	v_dot2_f32_bf16 v4, v5, v43, v4                            // 00000084F158: CC1A4004 1C125705
	v_dot2_f32_bf16 v4, v6, v44, v4                            // 00000084F160: CC1A4004 1C125906
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084F168: BF8700A1
	v_dot2_f32_bf16 v4, v7, v45, v4                            // 00000084F16C: CC1A4004 1C125B07
	s_waitcnt vmcnt(2)                                         // 00000084F174: BF890BF7
	v_dot2_f32_bf16 v4, v26, v46, v4                           // 00000084F178: CC1A4004 1C125D1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084F180: BF870091
	v_dot2_f32_bf16 v4, v27, v47, v4                           // 00000084F184: CC1A4004 1C125F1B
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 00000084F18C: CC1A4004 1C12611C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084F194: BF8700A1
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 00000084F198: CC1A4004 1C12631D
	s_waitcnt vmcnt(1)                                         // 00000084F1A0: BF8907F7
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 00000084F1A4: CC1A4004 1C12651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084F1AC: BF870091
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 00000084F1B0: CC1A4004 1C12671F
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 00000084F1B8: CC1A4004 1C126920
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084F1C0: BF8700A1
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 00000084F1C4: CC1A4004 1C126B21
	s_waitcnt vmcnt(0)                                         // 00000084F1CC: BF8903F7
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 00000084F1D0: CC1A4004 1C126D22
	.long 0xd7000222                                           // 00000084F1D8: D7000222
	v_cndmask_b32_e32 v0, v38, v17, vcc_lo                     // 00000084F1DC: 02002326
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000084F1E0: BF870122
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 00000084F1E4: CC1A4004 1C126F23
	v_add_co_ci_u32_e64 v35, null, s20, v39, s2                // 00000084F1EC: D5207C23 000A4E14
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 00000084F1F4: CC1A4004 1C127124
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084F1FC: BF870091
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 00000084F200: CC1A4004 1C127325
	v_fmac_f32_e32 v19, v25, v4                                // 00000084F208: 56260919
	s_clause 0x3                                               // 00000084F20C: BF850003
	global_load_b128 v[4:7], v[34:35], off                     // 00000084F210: DC5E0000 047C0022
	global_load_b128 v[26:29], v[34:35], off offset:16         // 00000084F218: DC5E0010 1A7C0022
	global_load_b128 v[30:33], v[34:35], off offset:32         // 00000084F220: DC5E0020 1E7C0022
	global_load_b128 v[34:37], v[34:35], off offset:48         // 00000084F228: DC5E0030 227C0022
	s_waitcnt vmcnt(3)                                         // 00000084F230: BF890FF7
	v_dot2_f32_bf16 v4, v4, v42, 0                             // 00000084F234: CC1A4004 1A025504
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084F23C: BF870091
	v_dot2_f32_bf16 v4, v5, v43, v4                            // 00000084F240: CC1A4004 1C125705
	v_dot2_f32_bf16 v4, v6, v44, v4                            // 00000084F248: CC1A4004 1C125906
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084F250: BF8700A1
	v_dot2_f32_bf16 v4, v7, v45, v4                            // 00000084F254: CC1A4004 1C125B07
	s_waitcnt vmcnt(2)                                         // 00000084F25C: BF890BF7
	v_dot2_f32_bf16 v4, v26, v46, v4                           // 00000084F260: CC1A4004 1C125D1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084F268: BF870091
	v_dot2_f32_bf16 v4, v27, v47, v4                           // 00000084F26C: CC1A4004 1C125F1B
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 00000084F274: CC1A4004 1C12611C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084F27C: BF8700A1
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 00000084F280: CC1A4004 1C12631D
	s_waitcnt vmcnt(1)                                         // 00000084F288: BF8907F7
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 00000084F28C: CC1A4004 1C12651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084F294: BF870091
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 00000084F298: CC1A4004 1C12671F
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 00000084F2A0: CC1A4004 1C126920
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084F2A8: BF8700A1
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 00000084F2AC: CC1A4004 1C126B21
	s_waitcnt vmcnt(0)                                         // 00000084F2B4: BF8903F7
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 00000084F2B8: CC1A4004 1C126D22
	.long 0xd7000222                                           // 00000084F2C0: D7000222
	v_cndmask_b32_e32 v0, v40, v18, vcc_lo                     // 00000084F2C4: 02002528
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000084F2C8: BF8701B2
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 00000084F2CC: CC1A4004 1C126F23
	v_add_co_ci_u32_e64 v35, null, s19, v41, s2                // 00000084F2D4: D5207C23 000A5213
	.long 0xd700020d                                           // 00000084F2DC: D700020D
	v_cndmask_b32_e32 v0, v13, v192, vcc_lo                    // 00000084F2E0: 0201810D
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 00000084F2E4: CC1A4004 1C127124
	v_add_co_ci_u32_e64 v14, null, 0, v14, s2                  // 00000084F2EC: D5207C0E 000A1C80
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084F2F4: BF870092
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 00000084F2F8: CC1A4004 1C127325
	v_fmac_f32_e32 v18, v25, v4                                // 00000084F300: 56240919
	s_clause 0x3                                               // 00000084F304: BF850003
	global_load_b128 v[4:7], v[34:35], off                     // 00000084F308: DC5E0000 047C0022
	global_load_b128 v[26:29], v[34:35], off offset:16         // 00000084F310: DC5E0010 1A7C0022
	global_load_b128 v[30:33], v[34:35], off offset:32         // 00000084F318: DC5E0020 1E7C0022
	global_load_b128 v[34:37], v[34:35], off offset:48         // 00000084F320: DC5E0030 227C0022
	s_waitcnt vmcnt(3)                                         // 00000084F328: BF890FF7
	v_dot2_f32_bf16 v4, v4, v42, 0                             // 00000084F32C: CC1A4004 1A025504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000084F334: BF870121
	v_dot2_f32_bf16 v4, v5, v43, v4                            // 00000084F338: CC1A4004 1C125705
	v_mov_b32_e32 v5, v1                                       // 00000084F340: 7E0A0301
	v_dot2_f32_bf16 v4, v6, v44, v4                            // 00000084F344: CC1A4004 1C125906
	v_mov_b32_e32 v6, v2                                       // 00000084F34C: 7E0C0302
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000084F350: BF870132
	v_dot2_f32_bf16 v4, v7, v45, v4                            // 00000084F354: CC1A4004 1C125B07
	v_mov_b32_e32 v7, v3                                       // 00000084F35C: 7E0E0303
	s_waitcnt vmcnt(2)                                         // 00000084F360: BF890BF7
	v_dot2_f32_bf16 v4, v26, v46, v4                           // 00000084F364: CC1A4004 1C125D1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084F36C: BF870091
	v_dot2_f32_bf16 v4, v27, v47, v4                           // 00000084F370: CC1A4004 1C125F1B
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 00000084F378: CC1A4004 1C12611C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084F380: BF8700A1
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 00000084F384: CC1A4004 1C12631D
	s_waitcnt vmcnt(1)                                         // 00000084F38C: BF8907F7
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 00000084F390: CC1A4004 1C12651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084F398: BF870091
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 00000084F39C: CC1A4004 1C12671F
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 00000084F3A4: CC1A4004 1C126920
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084F3AC: BF8700A1
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 00000084F3B0: CC1A4004 1C126B21
	s_waitcnt vmcnt(0)                                         // 00000084F3B8: BF8903F7
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 00000084F3BC: CC1A4004 1C126D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084F3C4: BF870091
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 00000084F3C8: CC1A4004 1C126F23
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 00000084F3D0: CC1A4004 1C127124
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084F3D8: BF870091
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 00000084F3DC: CC1A4004 1C127325
	v_fmac_f32_e32 v16, v25, v4                                // 00000084F3E4: 56200919
	v_mov_b32_e32 v4, v0                                       // 00000084F3E8: 7E080300
	v_mov_b32_e32 v25, v24                                     // 00000084F3EC: 7E320318
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 00000084F3F0: 917E107E
	s_cbranch_execz 25                                         // 00000084F3F4: BFA50019 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x95c>
	s_waitcnt vmcnt(0)                                         // 00000084F3F8: BF8903F7
	v_dual_mov_b32 v0, v4 :: v_dual_add_nc_u32 v23, 32, v23    // 00000084F3FC: CA200104 00162EA0
	v_dual_mov_b32 v1, v5 :: v_dual_mov_b32 v2, v6             // 00000084F404: CA100105 01020106
	v_mov_b32_e32 v3, v7                                       // 00000084F40C: 7E060307
	s_delay_alu instid0(VALU_DEP_3)                            // 00000084F410: BF870003
	.long 0xd4430002                                           // 00000084F414: D4430002
	v_cndmask_b32_e32 v1, s14, v23, vcc_lo                     // 00000084F418: 02022E0E
	s_mov_b32 s10, exec_lo                                     // 00000084F41C: BE8A007E
	.long 0xd4c4007e                                           // 00000084F420: D4C4007E
	v_cndmask_b32_e32 v1, s14, v23, vcc_lo                     // 00000084F424: 02022E0E
	s_cbranch_execz 65112                                      // 00000084F428: BFA5FE58 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x28c>
	.long 0xd7000300                                           // 00000084F42C: D7000300
	v_cndmask_b32_e32 v1, v10, v22, vcc_lo                     // 00000084F430: 02022D0A
	s_delay_alu instid0(VALU_DEP_1)                            // 00000084F434: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v17, s3                   // 00000084F438: D5207C01 000E2280
	global_load_d16_b16 v24, v[13:14], off                     // 00000084F440: DC820000 187C000D
	global_load_b128 v[0:3], v[0:1], off                       // 00000084F448: DC5E0000 007C0000
	s_waitcnt vmcnt(1)                                         // 00000084F450: BF8907F7
	v_cvt_f32_f16_e32 v24, v24                                 // 00000084F454: 7E301718
	s_branch 65100                                             // 00000084F458: BFA0FE4C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x28c>
	s_or_b32 exec_lo, exec_lo, s16                             // 00000084F45C: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084F460: BF8700A9
	s_or_b32 exec_lo, exec_lo, s15                             // 00000084F464: 8C7E0F7E
	.long 0xd71f0000                                           // 00000084F468: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000084F46C: 020100C1
	v_xor_b32_e32 v1, 16, v0                                   // 00000084F470: 3A020090
	s_waitcnt vmcnt(0)                                         // 00000084F474: BF8903F7
	v_xor_b32_e32 v6, 8, v0                                    // 00000084F478: 3A0C0088
	v_xor_b32_e32 v13, 4, v0                                   // 00000084F47C: 3A1A0084
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084F480: BF870093
	.long 0xd44c0002                                           // 00000084F484: D44C0002
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 00000084F488: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s2                           // 00000084F48C: D5010001 000A0300
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000084F494: BF870114
	.long 0xd44c0002                                           // 00000084F498: D44C0002
	v_cndmask_b32_e32 v1, 32, v6, vcc_lo                       // 00000084F49C: 02020CA0
	v_lshlrev_b32_e32 v1, 2, v1                                // 00000084F4A0: 30020282
	s_delay_alu instid0(VALU_DEP_2)                            // 00000084F4A4: BF870002
	v_cndmask_b32_e64 v6, v0, v6, s2                           // 00000084F4A8: D5010006 000A0D00
	.long 0xd44c0002                                           // 00000084F4B0: D44C0002
	v_cndmask_b32_e32 v1, 32, v13, vcc_lo                      // 00000084F4B4: 02021AA0
	ds_bpermute_b32 v2, v1, v21                                // 00000084F4B8: DACC0000 02001501
	v_cndmask_b32_e64 v13, v0, v13, s2                         // 00000084F4C0: D501000D 000A1B00
	s_waitcnt lgkmcnt(0)                                       // 00000084F4C8: BF89FC07
	v_add_f32_e32 v2, v21, v2                                  // 00000084F4CC: 06040515
	ds_bpermute_b32 v3, v1, v20                                // 00000084F4D0: DACC0000 03001401
	ds_bpermute_b32 v4, v1, v19                                // 00000084F4D8: DACC0000 04001301
	ds_bpermute_b32 v5, v1, v18                                // 00000084F4E0: DACC0000 05001201
	ds_bpermute_b32 v1, v1, v16                                // 00000084F4E8: DACC0000 01001001
	s_waitcnt lgkmcnt(3)                                       // 00000084F4F0: BF89FC37
	v_dual_add_f32 v3, v20, v3 :: v_dual_lshlrev_b32 v6, 2, v6 // 00000084F4F4: C9220714 03060C82
	ds_bpermute_b32 v7, v6, v2                                 // 00000084F4FC: DACC0000 07000206
	s_waitcnt lgkmcnt(2)                                       // 00000084F504: BF89FC27
	v_dual_add_f32 v4, v19, v4 :: v_dual_add_f32 v5, v18, v5   // 00000084F508: C9080913 04040B12
	s_waitcnt lgkmcnt(1)                                       // 00000084F510: BF89FC17
	v_add_f32_e32 v1, v16, v1                                  // 00000084F514: 06020310
	ds_bpermute_b32 v10, v6, v3                                // 00000084F518: DACC0000 0A000306
	ds_bpermute_b32 v11, v6, v4                                // 00000084F520: DACC0000 0B000406
	ds_bpermute_b32 v12, v6, v5                                // 00000084F528: DACC0000 0C000506
	s_waitcnt lgkmcnt(3)                                       // 00000084F530: BF89FC37
	v_dual_add_f32 v2, v2, v7 :: v_dual_lshlrev_b32 v13, 2, v13// 00000084F534: C9220F02 020C1A82
	ds_bpermute_b32 v6, v6, v1                                 // 00000084F53C: DACC0000 06000106
	s_waitcnt lgkmcnt(0)                                       // 00000084F544: BF89FC07
	v_dual_add_f32 v4, v4, v11 :: v_dual_add_f32 v1, v1, v6    // 00000084F548: C9081704 04000D01
	ds_bpermute_b32 v6, v13, v2                                // 00000084F550: DACC0000 0600020D
	v_add_f32_e32 v5, v5, v12                                  // 00000084F558: 060A1905
	ds_bpermute_b32 v12, v13, v1                               // 00000084F55C: DACC0000 0C00010D
	v_add_f32_e32 v3, v3, v10                                  // 00000084F564: 06061503
	ds_bpermute_b32 v10, v13, v4                               // 00000084F568: DACC0000 0A00040D
	s_waitcnt lgkmcnt(2)                                       // 00000084F570: BF89FC27
	v_add_f32_e32 v2, v2, v6                                   // 00000084F574: 06040D02
	ds_bpermute_b32 v11, v13, v5                               // 00000084F578: DACC0000 0B00050D
	v_xor_b32_e32 v6, 1, v0                                    // 00000084F580: 3A0C0081
	s_waitcnt lgkmcnt(1)                                       // 00000084F584: BF89FC17
	v_add_f32_e32 v4, v4, v10                                  // 00000084F588: 06081504
	v_add_f32_e32 v10, v1, v12                                 // 00000084F58C: 06141901
	ds_bpermute_b32 v7, v13, v3                                // 00000084F590: DACC0000 0700030D
	v_xor_b32_e32 v13, 2, v0                                   // 00000084F598: 3A1A0082
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084F59C: BF870091
	.long 0xd44c0002                                           // 00000084F5A0: D44C0002
	v_cndmask_b32_e32 v1, 32, v13, vcc_lo                      // 00000084F5A4: 02021AA0
	v_cndmask_b32_e64 v13, v0, v13, s2                         // 00000084F5A8: D501000D 000A1B00
	.long 0xd44c0002                                           // 00000084F5B0: D44C0002
	v_cndmask_b32_e32 v1, 32, v6, vcc_lo                       // 00000084F5B4: 02020CA0
	s_waitcnt lgkmcnt(1)                                       // 00000084F5B8: BF89FC17
	v_add_f32_e32 v5, v5, v11                                  // 00000084F5BC: 060A1705
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000084F5C0: BF870193
	v_lshlrev_b32_e32 v13, 2, v13                              // 00000084F5C4: 301A1A82
	v_cndmask_b32_e64 v0, v0, v6, s2                           // 00000084F5C8: D5010000 000A0D00
	.long 0xd44a0002                                           // 00000084F5D0: D44A0002
	v_cndmask_b32_e32 v1, 0, v15, vcc_lo                       // 00000084F5D4: 02021E80
	ds_bpermute_b32 v11, v13, v4                               // 00000084F5D8: DACC0000 0B00040D
	v_lshlrev_b32_e32 v14, 2, v0                               // 00000084F5E0: 301C0082
	s_and_b32 s2, s2, vcc_lo                                   // 00000084F5E4: 8B026A02
	s_waitcnt lgkmcnt(0)                                       // 00000084F5E8: BF89FC07
	v_add_f32_e32 v0, v4, v11                                  // 00000084F5EC: 06001704
	ds_bpermute_b32 v1, v13, v2                                // 00000084F5F0: DACC0000 0100020D
	v_add_f32_e32 v3, v3, v7                                   // 00000084F5F8: 06060F03
	ds_bpermute_b32 v12, v13, v5                               // 00000084F5FC: DACC0000 0C00050D
	s_waitcnt lgkmcnt(1)                                       // 00000084F604: BF89FC17
	v_add_f32_e32 v6, v2, v1                                   // 00000084F608: 060C0302
	ds_bpermute_b32 v7, v13, v3                                // 00000084F60C: DACC0000 0700030D
	ds_bpermute_b32 v13, v13, v10                              // 00000084F614: DACC0000 0D000A0D
	s_waitcnt lgkmcnt(2)                                       // 00000084F61C: BF89FC27
	v_add_f32_e32 v1, v5, v12                                  // 00000084F620: 06021905
	ds_bpermute_b32 v4, v14, v1                                // 00000084F624: DACC0000 0400010E
	s_waitcnt lgkmcnt(1)                                       // 00000084F62C: BF89FC17
	v_dual_add_f32 v7, v3, v7 :: v_dual_add_f32 v2, v10, v13   // 00000084F630: C9080F03 07021B0A
	ds_bpermute_b32 v10, v14, v6                               // 00000084F638: DACC0000 0A00060E
	ds_bpermute_b32 v3, v14, v0                                // 00000084F640: DACC0000 0300000E
	ds_bpermute_b32 v11, v14, v7                               // 00000084F648: DACC0000 0B00070E
	ds_bpermute_b32 v5, v14, v2                                // 00000084F650: DACC0000 0500020E
	s_and_saveexec_b32 s3, s2                                  // 00000084F658: BE832002
	s_cbranch_execz 228                                        // 00000084F65C: BFA500E4 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi1ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0xef0>
	s_load_b32 s0, s[0:1], 0x48                                // 00000084F660: F4000000 F8000048
	s_waitcnt lgkmcnt(0)                                       // 00000084F668: BF89FC07
	v_dual_add_f32 v6, v6, v10 :: v_dual_add_f32 v7, v7, v11   // 00000084F66C: C9081506 06061707
	v_dual_add_f32 v0, v0, v3 :: v_dual_add_f32 v1, v1, v4     // 00000084F674: C9080700 00000901
	s_lshl_b64 s[4:5], s[12:13], 2                             // 00000084F67C: 8484820C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000084F680: BF870192
	v_bfe_u32 v10, v6, 16, 1                                   // 00000084F684: D610000A 02052106
	v_bfe_u32 v11, v7, 16, 1                                   // 00000084F68C: D610000B 02052107
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000084F694: BF8701A2
	v_add3_u32 v3, v6, v10, 0x7fff                             // 00000084F698: D6550003 03FE1506 00007FFF
	v_add_f32_e32 v2, v2, v5                                   // 00000084F6A4: 06040B02
	v_add3_u32 v4, v7, v11, 0x7fff                             // 00000084F6A8: D6550004 03FE1707 00007FFF
	v_bfe_u32 v6, v1, 16, 1                                    // 00000084F6B4: D6100006 02052101
	v_bfe_u32 v5, v0, 16, 1                                    // 00000084F6BC: D6100005 02052100
	v_and_b32_e32 v3, 0xffff0000, v3                           // 00000084F6C4: 360606FF FFFF0000
	v_bfe_u32 v7, v2, 16, 1                                    // 00000084F6CC: D6100007 02052102
	v_and_b32_e32 v4, 0xffff0000, v4                           // 00000084F6D4: 360808FF FFFF0000
	v_add3_u32 v1, v1, v6, 0x7fff                              // 00000084F6DC: D6550001 03FE0D01 00007FFF
	v_add3_u32 v0, v0, v5, 0x7fff                              // 00000084F6E8: D6550000 03FE0B00 00007FFF
	v_mul_f32_e32 v3, s0, v3                                   // 00000084F6F4: 10060600
	v_add3_u32 v2, v2, v7, 0x7fff                              // 00000084F6F8: D6550002 03FE0F02 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000084F704: BF870214
	v_dual_mul_f32 v4, s0, v4 :: v_dual_and_b32 v1, 0xffff0000, v1// 00000084F708: C8E40800 040002FF FFFF0000
	v_and_b32_e32 v0, 0xffff0000, v0                           // 00000084F714: 360000FF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000084F71C: BF870112
	v_dual_mul_f32 v3, 0xbfb8aa3b, v3 :: v_dual_mul_f32 v4, 0xbfb8aa3b, v4// 00000084F720: C8C606FF 030408FF BFB8AA3B
	v_dual_mul_f32 v1, s0, v1 :: v_dual_mul_f32 v0, s0, v0     // 00000084F72C: C8C60200 01000000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000084F734: BF8701A2
	v_exp_f32_e32 v3, v3                                       // 00000084F738: 7E064B03
	v_and_b32_e32 v2, 0xffff0000, v2                           // 00000084F73C: 360404FF FFFF0000
	v_exp_f32_e32 v4, v4                                       // 00000084F744: 7E084B04
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000084F748: BF870122
	v_dual_mul_f32 v6, 0xbfb8aa3b, v1 :: v_dual_mul_f32 v5, 0xbfb8aa3b, v0// 00000084F74C: C8C602FF 060400FF BFB8AA3B
	.long 0xd73c0000                                           // 00000084F758: D73C0000
	v_cndmask_b32_e32 v1, 2, v8, vcc_lo                        // 00000084F75C: 02021082
	v_exp_f32_e32 v5, v5                                       // 00000084F760: 7E0A4B05
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 00000084F764: BF870317
	v_dual_add_f32 v7, 1.0, v3 :: v_dual_mul_f32 v2, s0, v2    // 00000084F768: C90606F2 07020400
	v_add_f32_e32 v8, 1.0, v4                                  // 00000084F770: 061008F2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000084F774: BF870193
	.long 0xd7006a03                                           // 00000084F778: D7006A03
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 00000084F77C: 02020008
	v_div_scale_f32 v0, null, v7, v7, 1.0                      // 00000084F780: D6FC7C00 03CA0F07
	v_add_co_ci_u32_e64 v4, null, s9, v1, vcc_lo               // 00000084F788: D5207C04 01AA0209
	v_div_scale_f32 v14, vcc_lo, 1.0, v7, 1.0                  // 00000084F790: D6FC6A0E 03CA0EF2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000084F798: BF870125
	v_add_f32_e32 v1, 1.0, v5                                  // 00000084F79C: 06020AF2
	v_div_scale_f32 v5, null, v8, v8, 1.0                      // 00000084F7A0: D6FC7C05 03CA1108
	v_div_scale_f32 v10, null, v1, v1, 1.0                     // 00000084F7A8: D6FC7C0A 03CA0301
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000084F7B0: BF870122
	v_rcp_f32_e32 v11, v5                                      // 00000084F7B4: 7E165505
	v_div_scale_f32 v20, s1, 1.0, v1, 1.0                      // 00000084F7B8: D6FC0114 03CA02F2
	v_rcp_f32_e32 v15, v10                                     // 00000084F7C0: 7E1E550A
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084F7C4: BF870096
	v_fma_f32 v21, -v5, v11, 1.0                               // 00000084F7C8: D6130015 23CA1705
	v_fmac_f32_e32 v11, v21, v11                               // 00000084F7D0: 56161715
	v_exp_f32_e32 v6, v6                                       // 00000084F7D4: 7E0C4B06
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000084F7D8: BF870135
	v_add_f32_e32 v9, 1.0, v6                                  // 00000084F7DC: 06120CF2
	v_rcp_f32_e32 v6, v0                                       // 00000084F7E0: 7E0C5500
	v_div_scale_f32 v16, s0, 1.0, v8, 1.0                      // 00000084F7E4: D6FC0010 03CA10F2
	v_div_scale_f32 v12, null, v9, v9, 1.0                     // 00000084F7EC: D6FC7C0C 03CA1309
	v_div_scale_f32 v22, s2, 1.0, v9, 1.0                      // 00000084F7F4: D6FC0216 03CA12F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 00000084F7FC: BF870312
	v_rcp_f32_e32 v17, v12                                     // 00000084F800: 7E22550C
	v_fma_f32 v19, -v0, v6, 1.0                                // 00000084F804: D6130013 23CA0D00
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000084F80C: BF870115
	v_fma_f32 v21, -v12, v17, 1.0                              // 00000084F810: D6130015 23CA230C
	v_fmac_f32_e32 v6, v19, v6                                 // 00000084F818: 560C0D13
	v_fma_f32 v19, -v10, v15, 1.0                              // 00000084F81C: D6130013 23CA1F0A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000084F824: BF870113
	v_dual_mul_f32 v2, 0xbfb8aa3b, v2 :: v_dual_fmac_f32 v17, v21, v17// 00000084F828: C8C004FF 02102315 BFB8AA3B
	v_fmac_f32_e32 v15, v19, v15                               // 00000084F834: 561E1F13
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000084F838: BF870142
	v_exp_f32_e32 v2, v2                                       // 00000084F83C: 7E044B02
	v_mul_f32_e32 v25, v14, v6                                 // 00000084F840: 10320D0E
	v_mul_f32_e32 v19, v16, v11                                // 00000084F844: 10261710
	v_mul_f32_e32 v27, v22, v17                                // 00000084F848: 10362316
	v_fma_f32 v26, -v5, v19, v16                               // 00000084F84C: D613001A 24422705
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_1)   // 00000084F854: BF870085
	v_dual_add_f32 v2, 1.0, v2 :: v_dual_fmac_f32 v19, v26, v11// 00000084F858: C90004F2 0212171A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000084F860: BF870113
	v_fma_f32 v26, -v12, v27, v22                              // 00000084F864: D613001A 245A370C
	v_div_scale_f32 v13, null, v2, v2, 1.0                     // 00000084F86C: D6FC7C0D 03CA0502
	v_div_scale_f32 v23, s3, 1.0, v2, 1.0                      // 00000084F874: D6FC0317 03CA04F2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000084F87C: BF870214
	v_fma_f32 v5, -v5, v19, v16                                // 00000084F880: D6130005 24422705
	v_fmac_f32_e32 v27, v26, v17                               // 00000084F888: 5636231A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000084F88C: BF870294
	v_rcp_f32_e32 v18, v13                                     // 00000084F890: 7E24550D
	v_fma_f32 v24, -v13, v18, 1.0                              // 00000084F894: D6130018 23CA250D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000084F89C: BF8701B1
	v_fmac_f32_e32 v18, v24, v18                               // 00000084F8A0: 56242518
	v_mul_f32_e32 v24, v20, v15                                // 00000084F8A4: 10301F14
	v_fma_f32 v21, -v0, v25, v14                               // 00000084F8A8: D6130015 243A3300
	v_mul_f32_e32 v28, v23, v18                                // 00000084F8B0: 10382517
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000084F8B4: BF870212
	v_fmac_f32_e32 v25, v21, v6                                // 00000084F8B8: 56320D15
	v_fma_f32 v21, -v10, v24, v20                              // 00000084F8BC: D6130015 2452310A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000084F8C4: BF870193
	v_fma_f32 v29, -v13, v28, v23                              // 00000084F8C8: D613001D 245E390D
	v_fma_f32 v0, -v0, v25, v14                                // 00000084F8D0: D6130000 243A3300
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000084F8D8: BF870113
	v_fmac_f32_e32 v24, v21, v15                               // 00000084F8DC: 56301F15
	v_div_fmas_f32 v0, v0, v6, v25                             // 00000084F8E0: D6370000 04660D00
	s_mov_b32 vcc_lo, s0                                       // 00000084F8E8: BEEA0000
	s_delay_alu instid0(VALU_DEP_2)                            // 00000084F8EC: BF870002
	v_fma_f32 v6, -v10, v24, v20                               // 00000084F8F0: D6130006 2452310A
	v_div_fmas_f32 v5, v5, v11, v19                            // 00000084F8F8: D6370005 044E1705
	s_mov_b32 vcc_lo, s1                                       // 00000084F900: BEEA0001
	v_div_fixup_f32 v0, v0, v7, 1.0                            // 00000084F904: D6270000 03CA0F00
	v_fmac_f32_e32 v28, v29, v18                               // 00000084F90C: 5638251D
	v_div_fmas_f32 v7, v6, v15, v24                            // 00000084F910: D6370007 04621F06
	v_div_fixup_f32 v5, v5, v8, 1.0                            // 00000084F918: D6270005 03CA1105
	s_lshl_b64 s[0:1], s[12:13], 3                             // 00000084F920: 8480830C
	v_add_f32_e32 v11, v0, v0                                  // 00000084F924: 06160100
	v_fma_f32 v0, -v12, v27, v22                               // 00000084F928: D6130000 245A370C
	v_div_fixup_f32 v1, v7, v1, 1.0                            // 00000084F930: D6270001 03CA0307
	v_add_f32_e32 v14, v5, v5                                  // 00000084F938: 061C0B05
	.long 0xd7006a05                                           // 00000084F93C: D7006A05
	v_cndmask_b32_e32 v0, v3, v4, vcc_lo                       // 00000084F940: 02000903
	v_fma_f32 v7, -v13, v28, v23                               // 00000084F944: D6130007 245E390D
	v_add_co_ci_u32_e64 v6, null, s5, v4, vcc_lo               // 00000084F94C: D5207C06 01AA0805
	s_mov_b32 vcc_lo, s2                                       // 00000084F954: BEEA0002
	v_add_f32_e32 v12, v1, v1                                  // 00000084F958: 06180301
	v_div_fmas_f32 v8, v0, v17, v27                            // 00000084F95C: D6370008 046E2300
	s_mov_b32 vcc_lo, s3                                       // 00000084F964: BEEA0003
	v_mad_u64_u32 v[0:1], null, s12, 12, v[3:4]                // 00000084F968: D6FE7C00 040D180C
	v_div_fmas_f32 v7, v7, v18, v28                            // 00000084F970: D6370007 04722507
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000084F978: BF870113
	v_div_fixup_f32 v9, v8, v9, 1.0                            // 00000084F97C: D6270009 03CA1308
	v_div_fixup_f32 v10, v7, v2, 1.0                           // 00000084F984: D627000A 03CA0507
	.long 0xd7006a07                                           // 00000084F98C: D7006A07
	v_cndmask_b32_e32 v0, v3, v0, vcc_lo                       // 00000084F990: 02000103
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000084F994: BF870221
	v_add_co_ci_u32_e64 v8, null, s1, v4, vcc_lo               // 00000084F998: D5207C08 01AA0801
	v_mad_u64_u32 v[1:2], null, s13, 12, v[1:2]                // 00000084F9A0: D6FE7C01 0405180D
	v_dual_add_f32 v13, v9, v9 :: v_dual_add_f32 v2, v10, v10  // 00000084F9A8: C9081309 0D02150A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084F9B0: BF870094
	.long 0xd7006a09                                           // 00000084F9B4: D7006A09
	v_cndmask_b32_e32 v0, v7, v0, vcc_lo                       // 00000084F9B8: 02000107
	v_add_co_ci_u32_e64 v10, null, s1, v8, vcc_lo              // 00000084F9BC: D5207C0A 01AA1001
	s_clause 0x4                                               // 00000084F9C4: BF850004
	global_store_b32 v[3:4], v11, off                          // 00000084F9C8: DC6A0000 007C0B03
	global_store_b32 v[5:6], v14, off                          // 00000084F9D0: DC6A0000 007C0E05
	global_store_b32 v[7:8], v12, off                          // 00000084F9D8: DC6A0000 007C0C07
	global_store_b32 v[0:1], v13, off                          // 00000084F9E0: DC6A0000 007C0D00
	global_store_b32 v[9:10], v2, off                          // 00000084F9E8: DC6A0000 007C0209
	s_endpgm                                                   // 00000084F9F0: BFB00000
		...

