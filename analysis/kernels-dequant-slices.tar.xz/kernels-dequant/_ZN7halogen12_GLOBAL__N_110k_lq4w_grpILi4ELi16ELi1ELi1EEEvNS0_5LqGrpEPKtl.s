00000000002a1600 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl>:
; _ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl():
	s_clause 0x3                                               // 0000002A1600: BF850003
	s_load_b32 s3, s[0:1], 0x120                               // 0000002A1604: F40000C0 F8000120
	s_load_b32 s4, s[0:1], 0x88                                // 0000002A160C: F4000100 F8000088
	s_load_b32 s5, s[0:1], 0xd0                                // 0000002A1614: F4000140 F80000D0
	s_load_b32 s6, s[0:1], 0x118                               // 0000002A161C: F4000180 F8000118
	v_and_b32_e32 v24, 15, v0                                  // 0000002A1624: 3630008F
	v_lshlrev_b32_e32 v23, 2, v0                               // 0000002A1628: 302E0082
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002A162C: BF870002
	v_lshlrev_b32_e32 v2, 2, v24                               // 0000002A1630: 30043082
	s_waitcnt lgkmcnt(0)                                       // 0000002A1634: BF89FC07
	s_cmp_gt_i32 s3, 1                                         // 0000002A1638: BF028103
	s_cselect_b32 s7, -1, 0                                    // 0000002A163C: 980780C1
	s_cmp_ge_i32 s2, s4                                        // 0000002A1640: BF030402
	s_cselect_b32 s4, -1, 0                                    // 0000002A1644: 980480C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002A1648: BF870009
	s_and_b32 s4, s7, s4                                       // 0000002A164C: 8B040407
	s_cmp_gt_i32 s3, 2                                         // 0000002A1650: BF028203
	v_cndmask_b32_e64 v1, 0, 1, s4                             // 0000002A1654: D5010001 00110280
	s_cselect_b32 s7, -1, 0                                    // 0000002A165C: 980780C1
	s_cmp_ge_i32 s2, s5                                        // 0000002A1660: BF030502
	s_cselect_b32 s5, -1, 0                                    // 0000002A1664: 980580C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002A1668: BF870009
	s_and_b32 s4, s7, s5                                       // 0000002A166C: 8B040507
	s_cmp_gt_i32 s3, 3                                         // 0000002A1670: BF028303
	v_readfirstlane_b32 s5, v1                                 // 0000002A1674: 7E0A0501
	s_cselect_b32 s3, -1, 0                                    // 0000002A1678: 980380C1
	s_cmp_ge_i32 s2, s6                                        // 0000002A167C: BF030602
	v_lshrrev_b32_e32 v1, 4, v0                                // 0000002A1680: 32020084
	s_cselect_b32 s6, -1, 0                                    // 0000002A1684: 980680C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002A1688: BF870009
	s_and_b32 s3, s3, s6                                       // 0000002A168C: 8B030603
	s_and_b32 s4, s4, exec_lo                                  // 0000002A1690: 8B047E04
	s_cselect_b32 s4, 2, s5                                    // 0000002A1694: 98040582
	s_and_b32 s3, s3, exec_lo                                  // 0000002A1698: 8B037E03
	s_cselect_b32 s3, 3, s4                                    // 0000002A169C: 98030483
	v_lshlrev_b32_e32 v3, 2, v1                                // 0000002A16A0: 30060282
	s_mulk_i32 s3, 0x48                                        // 0000002A16A4: B8030048
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002A16A8: BF870009
	s_add_u32 s16, s0, s3                                      // 0000002A16AC: 80100300
	s_addc_u32 s17, s1, 0                                      // 0000002A16B0: 82118001
	s_clause 0x1                                               // 0000002A16B4: BF850001
	s_load_b256 s[4:11], s[16:17], 0x18                        // 0000002A16B8: F40C0108 F8000018
	s_load_b64 s[18:19], s[16:17], null                        // 0000002A16C0: F4040488 F8000000
	s_waitcnt lgkmcnt(0)                                       // 0000002A16C8: BF89FC07
	.long 0xd4540003                                           // 0000002A16CC: D4540003
	v_cndmask_b32_e32 v0, s10, v136, vcc_lo                    // 0000002A16D0: 0201100A
	s_and_b32 s12, s3, exec_lo                                 // 0000002A16D4: 8B0C7E03
	s_load_b128 s[12:15], s[0:1], 0x128                        // 0000002A16D8: F4080300 F8000128
	s_clause 0x1                                               // 0000002A16E0: BF850001
	global_load_b32 v2, v2, s[18:19]                           // 0000002A16E4: DC520000 02120002
	global_load_b32 v3, v3, s[18:19]                           // 0000002A16EC: DC520000 03120003
	s_cselect_b32 s22, 1, 16                                   // 0000002A16F4: 98169081
	s_cselect_b32 s23, 0, 4                                    // 0000002A16F8: 98178480
	s_add_i32 s24, s22, -1                                     // 0000002A16FC: 8118C116
	v_lshrrev_b32_e32 v25, s23, v1                             // 0000002A1700: 32320217
	v_and_b32_e32 v26, s24, v1                                 // 0000002A1704: 36340218
	s_waitcnt vmcnt(1)                                         // 0000002A1708: BF8907F7
	v_bfe_u32 v4, v2, 16, 1                                    // 0000002A170C: D6100004 02052102
	s_waitcnt vmcnt(0)                                         // 0000002A1714: BF8903F7
	v_bfe_u32 v5, v3, 16, 1                                    // 0000002A1718: D6100005 02052103
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002A1720: BF8701A2
	v_add3_u32 v2, v2, v4, 0x7fff                              // 0000002A1724: D6550002 03FE0902 00007FFF
	.long 0x7f083880                                           // 0000002A1730: 7F083880
	v_add3_u32 v3, v3, v5, 0x7fff                              // 0000002A1734: D6550003 03FE0B03 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A1740: BF870093
	.long 0x7e083982                                           // 0000002A1744: 7E083982
	v_and_or_b32 v2, 0xffff0000, v3, v4                        // 0000002A1748: D6570002 041206FF FFFF0000
	ds_store_b32 v23, v2                                       // 0000002A1754: D8340000 00000217
	v_cvt_f32_ubyte0_e32 v2, s22                               // 0000002A175C: 7E042216
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002A1760: BF870291
	v_rcp_iflag_f32_e32 v2, v2                                 // 0000002A1764: 7E045702
	v_readfirstlane_b32 s21, v2                                // 0000002A1768: 7E2A0502
	s_waitcnt lgkmcnt(0)                                       // 0000002A176C: BF89FC07
	s_barrier                                                  // 0000002A1770: BFBD0000
	buffer_gl0_inv                                             // 0000002A1774: E0AC0000 00000000
	s_load_b32 s20, s[16:17], 0x40                             // 0000002A177C: F4000508 F8000040
	s_waitcnt lgkmcnt(0)                                       // 0000002A1784: BF89FC07
	s_sub_i32 s0, s2, s20                                      // 0000002A1788: 81801402
	s_mul_f32 s20, s21, 0x4f7ffffe                             // 0000002A178C: A214FF15 4F7FFFFE
	s_ashr_i32 s1, s0, 31                                      // 0000002A1794: 86019F00
	s_and_b32 s3, s3, exec_lo                                  // 0000002A1798: 8B037E03
	s_cselect_b32 s3, 4, 0                                     // 0000002A179C: 98038084
	s_cvt_u32_f32 s25, s20                                     // 0000002A17A0: BE996714
	s_lshl_b64 s[0:1], s[0:1], s3                              // 0000002A17A4: 84800300
	s_add_u32 s6, s18, s6                                      // 0000002A17A8: 80060612
	s_addc_u32 s7, s19, s7                                     // 0000002A17AC: 82070713
	s_ashr_i32 s3, s15, 31                                     // 0000002A17B0: 86039F0F
	.long 0xd7000011                                           // 0000002A17B4: D7000011
	v_cndmask_b32_e32 v1, s0, v25, vcc_lo                      // 0000002A17B8: 02023200
	s_lshr_b32 s3, s3, 27                                      // 0000002A17BC: 85039B03
	v_add_co_ci_u32_e64 v18, null, s1, 0, s0                   // 0000002A17C0: D5207C12 00010001
	s_add_u32 s20, s14, s3                                     // 0000002A17C8: 8014030E
	s_addc_u32 s21, s15, 0                                     // 0000002A17CC: 8215800F
	s_sub_i32 s3, 0, s22                                       // 0000002A17D0: 81831680
	s_lshr_b64 s[20:21], s[20:21], 5                           // 0000002A17D4: 85948514
	s_mul_i32 s3, s3, s25                                      // 0000002A17D8: 96031903
	s_add_i32 s21, s24, s20                                    // 0000002A17DC: 81151418
	s_mul_hi_u32 s3, s25, s3                                   // 0000002A17E0: 96830319
	s_abs_i32 s26, s21                                         // 0000002A17E4: BE9A1515
	s_add_i32 s25, s25, s3                                     // 0000002A17E8: 81190319
	s_ashr_i32 s21, s21, 31                                    // 0000002A17EC: 86159F15
	s_mul_hi_u32 s3, s26, s25                                  // 0000002A17F0: 9683191A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000002A17F4: BF8704B9
	s_mul_i32 s23, s3, s22                                     // 0000002A17F8: 96171603
	s_add_i32 s25, s3, 1                                       // 0000002A17FC: 81198103
	s_sub_i32 s23, s26, s23                                    // 0000002A1800: 8197171A
	s_sub_i32 s26, s23, s22                                    // 0000002A1804: 819A1617
	s_cmp_ge_u32 s23, s22                                      // 0000002A1808: BF091617
	s_cselect_b32 s0, s25, s3                                  // 0000002A180C: 98000319
	s_cselect_b32 s1, s26, s23                                 // 0000002A1810: 9801171A
	s_add_i32 s3, s0, 1                                        // 0000002A1814: 81038100
	s_cmp_ge_u32 s1, s22                                       // 0000002A1818: BF091601
	s_cselect_b32 s1, s3, s0                                   // 0000002A181C: 98010003
	.long 0xd4540000                                           // 0000002A1820: D4540000
	v_cndmask_b32_e32 v1, s10, v17, vcc_lo                     // 0000002A1824: 0202220A
	s_xor_b32 s1, s1, s21                                      // 0000002A1828: 8D011501
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000002A182C: BF870499
	s_sub_i32 s3, s1, s21                                      // 0000002A1830: 81831501
	.long 0xd72c0009                                           // 0000002A1834: D72C0009
	v_cndmask_b32_e32 v1, s3, v26, vcc_lo                      // 0000002A1838: 02023403
	v_cndmask_b32_e64 v10, 0, v18, s0                          // 0000002A183C: D501000A 00022480
	v_cndmask_b32_e64 v11, 0, v17, s0                          // 0000002A1844: D501000B 00022280
	s_cmpk_lt_i32 s3, 0x81                                     // 0000002A184C: B3830081
	s_cselect_b32 s1, -1, 0                                    // 0000002A1850: 980180C1
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002A1854: BF870112
	.long 0xd72c0002                                           // 0000002A1858: D72C0002
	v_cndmask_b32_e32 v0, v10, v8, vcc_lo                      // 0000002A185C: 0200110A
	.long 0xd72c0003                                           // 0000002A1860: D72C0003
	v_cndmask_b32_e32 v0, v11, v9, vcc_lo                      // 0000002A1864: 0200130B
	v_add_nc_u32_e32 v1, s3, v9                                // 0000002A1868: 4A021203
	v_mad_u64_u32 v[19:20], null, v11, s8, s[6:7]              // 0000002A186C: D6FE7C13 0018110B
	.long 0xd4510008                                           // 0000002A1874: D4510008
	v_cndmask_b32_e32 v0, s10, v137, vcc_lo                    // 0000002A1878: 0201120A
	s_cmpk_gt_i32 s3, 0x80                                     // 0000002A187C: B2830080
	v_min_i32_e32 v27, s20, v1                                 // 0000002A1880: 22360214
	v_dual_mov_b32 v1, 0 :: v_dual_add_nc_u32 v28, v9, v24     // 0000002A1884: CA200080 011C3109
	s_cselect_b32 s6, -1, 0                                    // 0000002A188C: 980680C1
	v_add3_u32 v29, v2, v20, v3                                // 0000002A1890: D655001D 040E2902
	s_and_b32 vcc_lo, exec_lo, s6                              // 0000002A1898: 8B6A067E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002A189C: BF870002
	.long 0xd4410003                                           // 0000002A18A0: D4410003
	v_cndmask_b32_e32 v1, v28, v27, vcc_lo                     // 0000002A18A4: 0202371C
	s_cbranch_vccnz 151                                        // 0000002A18A8: BFA40097 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x508>
	s_and_saveexec_b32 s7, s3                                  // 0000002A18AC: BE872003
	s_cbranch_execz 11                                         // 0000002A18B0: BFA5000B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x2e0>
	v_lshlrev_b32_e32 v1, 1, v28                               // 0000002A18B4: 30023881
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002A18B8: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000002A18BC: 3404029F
	.long 0xd7006a01                                           // 0000002A18C0: D7006A01
	v_cndmask_b32_e32 v1, v19, v1, vcc_lo                      // 0000002A18C4: 02020313
	v_add_co_ci_u32_e64 v2, null, v29, v2, vcc_lo              // 0000002A18C8: D5207C02 01AA051D
	global_load_d16_b16 v1, v[1:2], off                        // 0000002A18D0: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000002A18D8: BF8903F7
	v_cvt_f32_f16_e32 v1, v1                                   // 0000002A18DC: 7E021701
	s_or_b32 exec_lo, exec_lo, s7                              // 0000002A18E0: 8C7E077E
	v_dual_mov_b32 v3, 0 :: v_dual_add_nc_u32 v4, 16, v28      // 0000002A18E4: CA200080 03043890
	v_mov_b32_e32 v2, 0                                        // 0000002A18EC: 7E040280
	s_mov_b32 s3, exec_lo                                      // 0000002A18F0: BE83007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002A18F4: BF870002
	.long 0xd4c1007e                                           // 0000002A18F8: D4C1007E
	v_cndmask_b32_e32 v1, v4, v27, vcc_lo                      // 0000002A18FC: 02023704
	s_cbranch_execz 11                                         // 0000002A1900: BFA5000B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x330>
	v_lshlrev_b32_e32 v2, 1, v4                                // 0000002A1904: 30040881
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002A1908: BF8700A1
	v_ashrrev_i32_e32 v5, 31, v2                               // 0000002A190C: 340A049F
	.long 0xd7006a04                                           // 0000002A1910: D7006A04
	v_cndmask_b32_e32 v1, v19, v2, vcc_lo                      // 0000002A1914: 02020513
	v_add_co_ci_u32_e64 v5, null, v29, v5, vcc_lo              // 0000002A1918: D5207C05 01AA0B1D
	global_load_d16_b16 v2, v[4:5], off                        // 0000002A1920: DC820000 027C0004
	s_waitcnt vmcnt(0)                                         // 0000002A1928: BF8903F7
	v_cvt_f32_f16_e32 v2, v2                                   // 0000002A192C: 7E041702
	s_or_b32 exec_lo, exec_lo, s3                              // 0000002A1930: 8C7E037E
	v_add_nc_u32_e32 v4, 32, v28                               // 0000002A1934: 4A0838A0
	s_mov_b32 s3, exec_lo                                      // 0000002A1938: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002A193C: BF870001
	.long 0xd4c1007e                                           // 0000002A1940: D4C1007E
	v_cndmask_b32_e32 v1, v4, v27, vcc_lo                      // 0000002A1944: 02023704
	s_cbranch_execz 11                                         // 0000002A1948: BFA5000B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x378>
	v_lshlrev_b32_e32 v3, 1, v4                                // 0000002A194C: 30060881
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002A1950: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000002A1954: 3408069F
	.long 0xd7006a03                                           // 0000002A1958: D7006A03
	v_cndmask_b32_e32 v1, v19, v3, vcc_lo                      // 0000002A195C: 02020713
	v_add_co_ci_u32_e64 v4, null, v29, v4, vcc_lo              // 0000002A1960: D5207C04 01AA091D
	global_load_d16_b16 v3, v[3:4], off                        // 0000002A1968: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 0000002A1970: BF8903F7
	v_cvt_f32_f16_e32 v3, v3                                   // 0000002A1974: 7E061703
	s_or_b32 exec_lo, exec_lo, s3                              // 0000002A1978: 8C7E037E
	v_dual_mov_b32 v5, 0 :: v_dual_add_nc_u32 v6, 48, v28      // 0000002A197C: CA200080 050638B0
	v_mov_b32_e32 v4, 0                                        // 0000002A1984: 7E080280
	s_mov_b32 s3, exec_lo                                      // 0000002A1988: BE83007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002A198C: BF870002
	.long 0xd4c1007e                                           // 0000002A1990: D4C1007E
	v_cndmask_b32_e32 v1, v6, v27, vcc_lo                      // 0000002A1994: 02023706
	s_cbranch_execz 11                                         // 0000002A1998: BFA5000B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x3c8>
	v_lshlrev_b32_e32 v4, 1, v6                                // 0000002A199C: 30080C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002A19A0: BF8700A1
	v_ashrrev_i32_e32 v7, 31, v4                               // 0000002A19A4: 340E089F
	.long 0xd7006a06                                           // 0000002A19A8: D7006A06
	v_cndmask_b32_e32 v1, v19, v4, vcc_lo                      // 0000002A19AC: 02020913
	v_add_co_ci_u32_e64 v7, null, v29, v7, vcc_lo              // 0000002A19B0: D5207C07 01AA0F1D
	global_load_d16_b16 v4, v[6:7], off                        // 0000002A19B8: DC820000 047C0006
	s_waitcnt vmcnt(0)                                         // 0000002A19C0: BF8903F7
	v_cvt_f32_f16_e32 v4, v4                                   // 0000002A19C4: 7E081704
	s_or_b32 exec_lo, exec_lo, s3                              // 0000002A19C8: 8C7E037E
	v_add_nc_u32_e32 v6, 64, v28                               // 0000002A19CC: 4A0C38C0
	s_mov_b32 s3, exec_lo                                      // 0000002A19D0: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002A19D4: BF870001
	.long 0xd4c1007e                                           // 0000002A19D8: D4C1007E
	v_cndmask_b32_e32 v1, v6, v27, vcc_lo                      // 0000002A19DC: 02023706
	s_cbranch_execz 11                                         // 0000002A19E0: BFA5000B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x410>
	v_lshlrev_b32_e32 v5, 1, v6                                // 0000002A19E4: 300A0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002A19E8: BF8700A1
	v_ashrrev_i32_e32 v6, 31, v5                               // 0000002A19EC: 340C0A9F
	.long 0xd7006a05                                           // 0000002A19F0: D7006A05
	v_cndmask_b32_e32 v1, v19, v5, vcc_lo                      // 0000002A19F4: 02020B13
	v_add_co_ci_u32_e64 v6, null, v29, v6, vcc_lo              // 0000002A19F8: D5207C06 01AA0D1D
	global_load_d16_b16 v5, v[5:6], off                        // 0000002A1A00: DC820000 057C0005
	s_waitcnt vmcnt(0)                                         // 0000002A1A08: BF8903F7
	v_cvt_f32_f16_e32 v5, v5                                   // 0000002A1A0C: 7E0A1705
	s_or_b32 exec_lo, exec_lo, s3                              // 0000002A1A10: 8C7E037E
	v_dual_mov_b32 v7, 0 :: v_dual_add_nc_u32 v8, 0x50, v28    // 0000002A1A14: CA200080 070838FF 00000050
	v_mov_b32_e32 v6, 0                                        // 0000002A1A20: 7E0C0280
	s_mov_b32 s3, exec_lo                                      // 0000002A1A24: BE83007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002A1A28: BF870002
	.long 0xd4c1007e                                           // 0000002A1A2C: D4C1007E
	v_cndmask_b32_e32 v1, v8, v27, vcc_lo                      // 0000002A1A30: 02023708
	s_cbranch_execz 11                                         // 0000002A1A34: BFA5000B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x464>
	v_lshlrev_b32_e32 v6, 1, v8                                // 0000002A1A38: 300C1081
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002A1A3C: BF8700A1
	v_ashrrev_i32_e32 v8, 31, v6                               // 0000002A1A40: 34100C9F
	.long 0xd7006a0c                                           // 0000002A1A44: D7006A0C
	v_cndmask_b32_e32 v1, v19, v6, vcc_lo                      // 0000002A1A48: 02020D13
	v_add_co_ci_u32_e64 v13, null, v29, v8, vcc_lo             // 0000002A1A4C: D5207C0D 01AA111D
	global_load_d16_b16 v6, v[12:13], off                      // 0000002A1A54: DC820000 067C000C
	s_waitcnt vmcnt(0)                                         // 0000002A1A5C: BF8903F7
	v_cvt_f32_f16_e32 v6, v6                                   // 0000002A1A60: 7E0C1706
	s_or_b32 exec_lo, exec_lo, s3                              // 0000002A1A64: 8C7E037E
	v_add_nc_u32_e32 v8, 0x60, v28                             // 0000002A1A68: 4A1038FF 00000060
	s_mov_b32 s3, exec_lo                                      // 0000002A1A70: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002A1A74: BF870001
	.long 0xd4c1007e                                           // 0000002A1A78: D4C1007E
	v_cndmask_b32_e32 v1, v8, v27, vcc_lo                      // 0000002A1A7C: 02023708
	s_cbranch_execz 11                                         // 0000002A1A80: BFA5000B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x4b0>
	v_lshlrev_b32_e32 v7, 1, v8                                // 0000002A1A84: 300E1081
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002A1A88: BF8700A1
	v_ashrrev_i32_e32 v8, 31, v7                               // 0000002A1A8C: 34100E9F
	.long 0xd7006a07                                           // 0000002A1A90: D7006A07
	v_cndmask_b32_e32 v1, v19, v7, vcc_lo                      // 0000002A1A94: 02020F13
	v_add_co_ci_u32_e64 v8, null, v29, v8, vcc_lo              // 0000002A1A98: D5207C08 01AA111D
	global_load_d16_b16 v7, v[7:8], off                        // 0000002A1AA0: DC820000 077C0007
	s_waitcnt vmcnt(0)                                         // 0000002A1AA8: BF8903F7
	v_cvt_f32_f16_e32 v7, v7                                   // 0000002A1AAC: 7E0E1707
	s_or_b32 exec_lo, exec_lo, s3                              // 0000002A1AB0: 8C7E037E
	v_add_nc_u32_e32 v12, 0x70, v28                            // 0000002A1AB4: 4A1838FF 00000070
	v_mov_b32_e32 v8, 0                                        // 0000002A1ABC: 7E100280
	s_mov_b32 s3, exec_lo                                      // 0000002A1AC0: BE83007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002A1AC4: BF870002
	.long 0xd4c1007e                                           // 0000002A1AC8: D4C1007E
	v_cndmask_b32_e32 v1, v12, v27, vcc_lo                     // 0000002A1ACC: 0202370C
	s_cbranch_execz 11                                         // 0000002A1AD0: BFA5000B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x500>
	v_lshlrev_b32_e32 v8, 1, v12                               // 0000002A1AD4: 30101881
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002A1AD8: BF8700A1
	v_ashrrev_i32_e32 v13, 31, v8                              // 0000002A1ADC: 341A109F
	.long 0xd7006a0c                                           // 0000002A1AE0: D7006A0C
	v_cndmask_b32_e32 v1, v19, v8, vcc_lo                      // 0000002A1AE4: 02021113
	v_add_co_ci_u32_e64 v13, null, v29, v13, vcc_lo            // 0000002A1AE8: D5207C0D 01AA1B1D
	global_load_d16_b16 v8, v[12:13], off                      // 0000002A1AF0: DC820000 087C000C
	s_waitcnt vmcnt(0)                                         // 0000002A1AF8: BF8903F7
	v_cvt_f32_f16_e32 v8, v8                                   // 0000002A1AFC: 7E101708
	s_or_b32 exec_lo, exec_lo, s3                              // 0000002A1B00: 8C7E037E
	s_branch 9                                                 // 0000002A1B04: BFA00009 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x52c>
	v_mov_b32_e32 v1, 0                                        // 0000002A1B08: 7E020280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002A1B0C: BF870001
	v_mov_b32_e32 v2, v1                                       // 0000002A1B10: 7E040301
	v_mov_b32_e32 v3, v1                                       // 0000002A1B14: 7E060301
	v_mov_b32_e32 v4, v1                                       // 0000002A1B18: 7E080301
	v_mov_b32_e32 v5, v1                                       // 0000002A1B1C: 7E0A0301
	v_mov_b32_e32 v6, v1                                       // 0000002A1B20: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 0000002A1B24: 7E0E0301
	v_mov_b32_e32 v8, v1                                       // 0000002A1B28: 7E100301
	s_add_u32 s4, s18, s4                                      // 0000002A1B2C: 80040412
	s_addc_u32 s5, s19, s5                                     // 0000002A1B30: 82050513
	s_lshr_b32 s3, s15, 31                                     // 0000002A1B34: 85039F0F
	v_dual_mov_b32 v13, 0 :: v_dual_mov_b32 v30, 0             // 0000002A1B38: CA100080 0D1E0080
	s_add_u32 s18, s14, s3                                     // 0000002A1B40: 8012030E
	s_addc_u32 s19, s15, 0                                     // 0000002A1B44: 8213800F
	.long 0xd4410003                                           // 0000002A1B48: D4410003
	v_cndmask_b32_e32 v1, v28, v27, vcc_lo                     // 0000002A1B4C: 0202371C
	s_ashr_i64 s[18:19], s[18:19], 1                           // 0000002A1B50: 86928112
	v_cndmask_b32_e64 v31, 0, 1, s6                            // 0000002A1B54: D501001F 00190280
	v_mad_u64_u32 v[20:21], null, v11, s18, s[4:5]             // 0000002A1B5C: D6FE7C14 0010250B
	.long 0xd72c000b                                           // 0000002A1B64: D72C000B
	v_cndmask_b32_e32 v0, v11, v19, vcc_lo                     // 0000002A1B68: 0200270B
	.long 0xd72c000a                                           // 0000002A1B6C: D72C000A
	v_cndmask_b32_e32 v0, v10, v18, vcc_lo                     // 0000002A1B70: 0200250A
	v_dual_mov_b32 v39, 0 :: v_dual_mov_b32 v14, 0             // 0000002A1B74: CA100080 270E0080
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v16, 0             // 0000002A1B7C: CA100080 0F100080
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002A1B84: BF870003
	v_add3_u32 v32, v10, v21, v11                              // 0000002A1B88: D6550020 042E2B0A
	s_and_saveexec_b32 s4, s3                                  // 0000002A1B90: BE842003
	s_cbranch_execz 22                                         // 0000002A1B94: BFA50016 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x5f0>
	v_dual_mov_b32 v39, 0 :: v_dual_lshlrev_b32 v10, 4, v28    // 0000002A1B98: CA220080 270A3884
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002A1BA0: BF8700A1
	v_ashrrev_i32_e32 v11, 31, v10                             // 0000002A1BA4: 3416149F
	.long 0xd7006a0a                                           // 0000002A1BA8: D7006A0A
	v_cndmask_b32_e32 v1, v20, v10, vcc_lo                     // 0000002A1BAC: 02021514
	v_add_co_ci_u32_e64 v11, null, v32, v11, vcc_lo            // 0000002A1BB0: D5207C0B 01AA1720
	s_and_not1_b32 vcc_lo, exec_lo, s6                         // 0000002A1BB8: 916A067E
	global_load_b128 v[13:16], v[10:11], off                   // 0000002A1BBC: DC5E0000 0D7C000A
	s_cbranch_vccnz 10                                         // 0000002A1BC4: BFA4000A <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x5f0>
	v_lshlrev_b32_e32 v10, 1, v28                              // 0000002A1BC8: 30143881
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A1BCC: BF870091
	.long 0xd7006a0a                                           // 0000002A1BD0: D7006A0A
	v_cndmask_b32_e32 v1, v19, v10, vcc_lo                     // 0000002A1BD4: 02021513
	v_add_co_ci_u32_e64 v11, null, 0, v29, vcc_lo              // 0000002A1BD8: D5207C0B 01AA3A80
	global_load_d16_b16 v10, v[10:11], off                     // 0000002A1BE0: DC820000 0A7C000A
	s_waitcnt vmcnt(0)                                         // 0000002A1BE8: BF8903F7
	v_cvt_f32_f16_e32 v39, v10                                 // 0000002A1BEC: 7E4E170A
	s_or_b32 exec_lo, exec_lo, s4                              // 0000002A1BF0: 8C7E047E
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v35, 0             // 0000002A1BF4: CA100080 22220080
	v_mov_b32_e32 v33, 0                                       // 0000002A1BFC: 7E420280
	s_and_saveexec_b32 s9, s3                                  // 0000002A1C00: BE892003
	s_cbranch_execz 394                                        // 0000002A1C04: BFA5018A <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0xc30>
	v_dual_mov_b32 v33, 0 :: v_dual_lshlrev_b32 v10, 5, v24    // 0000002A1C08: CA220080 210A3085
	v_dual_mov_b32 v34, 0 :: v_dual_add_nc_u32 v11, 16, v28    // 0000002A1C10: CA200080 220A3890
	v_mov_b32_e32 v38, v39                                     // 0000002A1C18: 7E4C0327
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002A1C1C: BF870193
	v_lshl_add_u32 v21, v9, 5, v10                             // 0000002A1C20: D6460015 04290B09
	v_dual_mov_b32 v35, 0 :: v_dual_lshlrev_b32 v36, 4, v11    // 0000002A1C28: CA220080 23241684
	v_dual_mov_b32 v30, 0 :: v_dual_lshlrev_b32 v37, 1, v11    // 0000002A1C30: CA220080 1E241681
	s_mul_i32 s3, s15, 6                                       // 0000002A1C38: 9603860F
	s_mul_hi_u32 s6, s14, 6                                    // 0000002A1C3C: 9686860E
	s_lshl_b64 s[4:5], s[14:15], 2                             // 0000002A1C40: 8484820E
	s_add_i32 s18, s6, s3                                      // 0000002A1C44: 81120306
	s_mul_i32 s20, s14, 6                                      // 0000002A1C48: 9614860E
	s_mov_b32 s19, 0                                           // 0000002A1C4C: BE930080
	s_lshl_b64 s[6:7], s[14:15], 1                             // 0000002A1C50: 8486810E
	s_branch 338                                               // 0000002A1C54: BFA00152 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0xba0>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000002A1C58: 8C7E0E7E
	v_ashrrev_i32_e32 v22, 31, v21                             // 0000002A1C5C: 342C2A9F
	v_cndmask_b32_e64 v112, v39, v1, s1                        // 0000002A1C60: D5010070 00060327
	v_lshrrev_b32_e32 v39, 6, v13                              // 0000002A1C68: 324E1A86
	v_and_b32_e32 v113, 0xff, v14                              // 0000002A1C6C: 36E21CFF 000000FF
	v_lshrrev_b32_e32 v114, 6, v14                             // 0000002A1C74: 32E41C86
	.long 0xd73c0028                                           // 0000002A1C78: D73C0028
	v_cndmask_b32_e32 v1, 1, v21, vcc_lo                       // 0000002A1C7C: 02022A81
	v_and_b32_e32 v22, 0xff, v13                               // 0000002A1C80: 362C1AFF 000000FF
	v_lshrrev_b32_e32 v115, 14, v14                            // 0000002A1C88: 32E61C8E
	v_lshrrev_b32_e32 v14, 22, v14                             // 0000002A1C8C: 321C1C96
	v_add_nc_u32_e32 v37, 32, v37                              // 0000002A1C90: 4A4A4AA0
	v_add_nc_u32_e32 v21, 0x200, v21                           // 0000002A1C94: 4A2A2AFF 00000200
	.long 0xd7006a28                                           // 0000002A1C9C: D7006A28
	v_cndmask_b32_e32 v1, s12, v40, vcc_lo                     // 0000002A1CA0: 0202500C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002A1CA4: BF8701A1
	v_add_co_ci_u32_e64 v41, null, s13, v41, vcc_lo            // 0000002A1CA8: D5207C29 01AA520D
	v_and_b32_e32 v14, 0x3fc, v14                              // 0000002A1CB0: 361C1CFF 000003FC
	.long 0xd7006a2a                                           // 0000002A1CB8: D7006A2A
	v_cndmask_b32_e32 v0, v40, v6, vcc_lo                      // 0000002A1CBC: 02000D28
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002A1CC0: BF8700A1
	v_add_co_ci_u32_e64 v43, null, s7, v41, vcc_lo             // 0000002A1CC4: D5207C2B 01AA5207
	.long 0xd7006a2c                                           // 0000002A1CCC: D7006A2C
	v_cndmask_b32_e32 v0, v40, v4, vcc_lo                      // 0000002A1CD0: 02000928
	v_add_co_ci_u32_e64 v45, null, s5, v41, vcc_lo             // 0000002A1CD4: D5207C2D 01AA5205
	.long 0xd7006a2e                                           // 0000002A1CDC: D7006A2E
	v_cndmask_b32_e32 v0, v40, v20, vcc_lo                     // 0000002A1CE0: 02002928
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002A1CE4: BF870001
	v_add_co_ci_u32_e64 v47, null, s18, v41, vcc_lo            // 0000002A1CE8: D5207C2F 01AA5212
	s_clause 0xf                                               // 0000002A1CF0: BF85000F
	global_load_b128 v[48:51], v[40:41], off                   // 0000002A1CF4: DC5E0000 307C0028
	global_load_b128 v[52:55], v[42:43], off                   // 0000002A1CFC: DC5E0000 347C002A
	global_load_b128 v[56:59], v[44:45], off                   // 0000002A1D04: DC5E0000 387C002C
	global_load_b128 v[60:63], v[46:47], off                   // 0000002A1D0C: DC5E0000 3C7C002E
	global_load_b128 v[64:67], v[40:41], off offset:16         // 0000002A1D14: DC5E0010 407C0028
	global_load_b128 v[68:71], v[42:43], off offset:16         // 0000002A1D1C: DC5E0010 447C002A
	global_load_b128 v[72:75], v[44:45], off offset:16         // 0000002A1D24: DC5E0010 487C002C
	global_load_b128 v[76:79], v[46:47], off offset:16         // 0000002A1D2C: DC5E0010 4C7C002E
	global_load_b128 v[80:83], v[40:41], off offset:32         // 0000002A1D34: DC5E0020 507C0028
	global_load_b128 v[84:87], v[42:43], off offset:32         // 0000002A1D3C: DC5E0020 547C002A
	global_load_b128 v[88:91], v[44:45], off offset:32         // 0000002A1D44: DC5E0020 587C002C
	global_load_b128 v[92:95], v[46:47], off offset:32         // 0000002A1D4C: DC5E0020 5C7C002E
	global_load_b128 v[96:99], v[40:41], off offset:48         // 0000002A1D54: DC5E0030 607C0028
	global_load_b128 v[100:103], v[42:43], off offset:48       // 0000002A1D5C: DC5E0030 647C002A
	global_load_b128 v[104:107], v[44:45], off offset:48       // 0000002A1D64: DC5E0030 687C002C
	global_load_b128 v[108:111], v[46:47], off offset:48       // 0000002A1D6C: DC5E0030 6C7C002E
	v_cndmask_b32_e64 v44, v5, v6, s1                          // 0000002A1D74: D501002C 00060D05
	v_cndmask_b32_e64 v43, v4, v5, s1                          // 0000002A1D7C: D501002B 00060B04
	v_mov_b32_e32 v47, v8                                      // 0000002A1D84: 7E5E0308
	v_lshlrev_b32_e32 v5, 2, v22                               // 0000002A1D88: 300A2C82
	v_cndmask_b32_e64 v46, v7, v8, s1                          // 0000002A1D8C: D501002E 00061107
	v_cndmask_b32_e64 v45, v6, v7, s1                          // 0000002A1D94: D501002D 00060F06
	v_lshrrev_b32_e32 v7, 14, v13                              // 0000002A1D9C: 320E1A8E
	v_and_b32_e32 v22, 0x3fc, v39                              // 0000002A1DA0: 362C4EFF 000003FC
	ds_load_b32 v5, v5                                         // 0000002A1DA8: D8D80000 05000005
	v_lshrrev_b32_e32 v13, 22, v13                             // 0000002A1DB0: 321A1A96
	v_cndmask_b32_e64 v42, v3, v4, s1                          // 0000002A1DB4: D501002A 00060903
	v_and_b32_e32 v7, 0x3fc, v7                                // 0000002A1DBC: 360E0EFF 000003FC
	ds_load_b32 v22, v22                                       // 0000002A1DC4: D8D80000 16000016
	v_cndmask_b32_e64 v41, v2, v3, s1                          // 0000002A1DCC: D5010029 00060702
	v_cndmask_b32_e64 v40, v1, v2, s1                          // 0000002A1DD4: D5010028 00060501
	v_and_b32_e32 v1, 0xff, v15                                // 0000002A1DDC: 36021EFF 000000FF
	v_lshrrev_b32_e32 v2, 6, v15                               // 0000002A1DE4: 32041E86
	v_lshrrev_b32_e32 v3, 14, v15                              // 0000002A1DE8: 32061E8E
	ds_load_b32 v7, v7                                         // 0000002A1DEC: D8D80000 07000007
	v_and_b32_e32 v13, 0x3fc, v13                              // 0000002A1DF4: 361A1AFF 000003FC
	v_lshlrev_b32_e32 v39, 2, v113                             // 0000002A1DFC: 304EE282
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000002A1E00: 30020282
	v_and_b32_e32 v2, 0x3fc, v2                                // 0000002A1E04: 360404FF 000003FC
	v_and_b32_e32 v3, 0x3fc, v3                                // 0000002A1E0C: 360606FF 000003FC
	v_and_b32_e32 v113, 0x3fc, v114                            // 0000002A1E14: 36E2E4FF 000003FC
	v_and_b32_e32 v114, 0x3fc, v115                            // 0000002A1E1C: 36E4E6FF 000003FC
	ds_load_b32 v13, v13                                       // 0000002A1E24: D8D80000 0D00000D
	ds_load_b32 v39, v39                                       // 0000002A1E2C: D8D80000 27000027
	ds_load_b32 v113, v113                                     // 0000002A1E34: D8D80000 71000071
	ds_load_b32 v114, v114                                     // 0000002A1E3C: D8D80000 72000072
	ds_load_b32 v14, v14                                       // 0000002A1E44: D8D80000 0E00000E
	ds_load_b32 v1, v1                                         // 0000002A1E4C: D8D80000 01000001
	ds_load_b32 v2, v2                                         // 0000002A1E54: D8D80000 02000002
	ds_load_b32 v3, v3                                         // 0000002A1E5C: D8D80000 03000003
	v_lshrrev_b32_e32 v4, 22, v15                              // 0000002A1E64: 32081E96
	v_lshrrev_b32_e32 v15, 14, v16                             // 0000002A1E68: 321E208E
	v_and_b32_e32 v6, 0xff, v16                                // 0000002A1E6C: 360C20FF 000000FF
	v_lshrrev_b32_e32 v8, 6, v16                               // 0000002A1E74: 32102086
	v_lshrrev_b32_e32 v16, 22, v16                             // 0000002A1E78: 32202096
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000002A1E7C: 360808FF 000003FC
	v_add_nc_u32_e32 v36, 0x100, v36                           // 0000002A1E84: 4A4848FF 00000100
	v_lshlrev_b32_e32 v6, 2, v6                                // 0000002A1E8C: 300C0C82
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000002A1E90: 361010FF 000003FC
	s_and_b32 s3, exec_lo, s3                                  // 0000002A1E98: 8B03037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002A1E9C: BF870009
	s_or_b32 s19, s3, s19                                      // 0000002A1EA0: 8C131303
	s_waitcnt vmcnt(15) lgkmcnt(10)                            // 0000002A1EA4: BF893CA7
	v_dot2_f32_bf16 v48, v48, v5, 0                            // 0000002A1EA8: CC1A4030 1A020B30
	s_waitcnt vmcnt(14)                                        // 0000002A1EB0: BF893BF7
	v_dot2_f32_bf16 v52, v52, v5, 0                            // 0000002A1EB4: CC1A4034 1A020B34
	s_waitcnt vmcnt(13)                                        // 0000002A1EBC: BF8937F7
	v_dot2_f32_bf16 v56, v56, v5, 0                            // 0000002A1EC0: CC1A4038 1A020B38
	s_waitcnt vmcnt(12)                                        // 0000002A1EC8: BF8933F7
	v_dot2_f32_bf16 v5, v60, v5, 0                             // 0000002A1ECC: CC1A4005 1A020B3C
	s_waitcnt lgkmcnt(9)                                       // 0000002A1ED4: BF89FC97
	v_dot2_f32_bf16 v48, v49, v22, v48                         // 0000002A1ED8: CC1A4030 1CC22D31
	v_dot2_f32_bf16 v49, v53, v22, v52                         // 0000002A1EE0: CC1A4031 1CD22D35
	v_dot2_f32_bf16 v52, v57, v22, v56                         // 0000002A1EE8: CC1A4034 1CE22D39
	v_dot2_f32_bf16 v5, v61, v22, v5                           // 0000002A1EF0: CC1A4005 1C162D3D
	s_waitcnt lgkmcnt(8)                                       // 0000002A1EF8: BF89FC87
	v_dot2_f32_bf16 v22, v50, v7, v48                          // 0000002A1EFC: CC1A4016 1CC20F32
	v_dot2_f32_bf16 v48, v54, v7, v49                          // 0000002A1F04: CC1A4030 1CC60F36
	v_dot2_f32_bf16 v49, v58, v7, v52                          // 0000002A1F0C: CC1A4031 1CD20F3A
	v_dot2_f32_bf16 v5, v62, v7, v5                            // 0000002A1F14: CC1A4005 1C160F3E
	v_and_b32_e32 v7, 0x3fc, v15                               // 0000002A1F1C: 360E1EFF 000003FC
	s_waitcnt lgkmcnt(7)                                       // 0000002A1F24: BF89FC77
	v_dot2_f32_bf16 v15, v51, v13, v22                         // 0000002A1F28: CC1A400F 1C5A1B33
	v_dot2_f32_bf16 v22, v55, v13, v48                         // 0000002A1F30: CC1A4016 1CC21B37
	v_dot2_f32_bf16 v48, v59, v13, v49                         // 0000002A1F38: CC1A4030 1CC61B3B
	v_dot2_f32_bf16 v5, v63, v13, v5                           // 0000002A1F40: CC1A4005 1C161B3F
	v_and_b32_e32 v13, 0x3fc, v16                              // 0000002A1F48: 361A20FF 000003FC
	s_waitcnt vmcnt(11) lgkmcnt(6)                             // 0000002A1F50: BF892C67
	v_dot2_f32_bf16 v15, v64, v39, v15                         // 0000002A1F54: CC1A400F 1C3E4F40
	s_waitcnt vmcnt(10)                                        // 0000002A1F5C: BF892BF7
	v_dot2_f32_bf16 v16, v68, v39, v22                         // 0000002A1F60: CC1A4010 1C5A4F44
	s_waitcnt vmcnt(9)                                         // 0000002A1F68: BF8927F7
	v_dot2_f32_bf16 v22, v72, v39, v48                         // 0000002A1F6C: CC1A4016 1CC24F48
	s_waitcnt vmcnt(8)                                         // 0000002A1F74: BF8923F7
	v_dot2_f32_bf16 v5, v76, v39, v5                           // 0000002A1F78: CC1A4005 1C164F4C
	ds_load_b32 v4, v4                                         // 0000002A1F80: D8D80000 04000004
	ds_load_b32 v6, v6                                         // 0000002A1F88: D8D80000 06000006
	ds_load_b32 v8, v8                                         // 0000002A1F90: D8D80000 08000008
	ds_load_b32 v7, v7                                         // 0000002A1F98: D8D80000 07000007
	ds_load_b32 v48, v13                                       // 0000002A1FA0: D8D80000 3000000D
	s_waitcnt lgkmcnt(10)                                      // 0000002A1FA8: BF89FCA7
	v_dot2_f32_bf16 v15, v65, v113, v15                        // 0000002A1FAC: CC1A400F 1C3EE341
	v_dot2_f32_bf16 v16, v69, v113, v16                        // 0000002A1FB4: CC1A4010 1C42E345
	v_dot2_f32_bf16 v22, v73, v113, v22                        // 0000002A1FBC: CC1A4016 1C5AE349
	v_dot2_f32_bf16 v5, v77, v113, v5                          // 0000002A1FC4: CC1A4005 1C16E34D
	v_mov_b32_e32 v39, v38                                     // 0000002A1FCC: 7E4E0326
	s_waitcnt lgkmcnt(9)                                       // 0000002A1FD0: BF89FC97
	v_dot2_f32_bf16 v15, v66, v114, v15                        // 0000002A1FD4: CC1A400F 1C3EE542
	v_dot2_f32_bf16 v16, v70, v114, v16                        // 0000002A1FDC: CC1A4010 1C42E546
	v_dot2_f32_bf16 v22, v74, v114, v22                        // 0000002A1FE4: CC1A4016 1C5AE54A
	v_dot2_f32_bf16 v5, v78, v114, v5                          // 0000002A1FEC: CC1A4005 1C16E54E
	s_waitcnt lgkmcnt(8)                                       // 0000002A1FF4: BF89FC87
	v_dot2_f32_bf16 v15, v67, v14, v15                         // 0000002A1FF8: CC1A400F 1C3E1D43
	v_dot2_f32_bf16 v16, v71, v14, v16                         // 0000002A2000: CC1A4010 1C421D47
	v_dot2_f32_bf16 v22, v75, v14, v22                         // 0000002A2008: CC1A4016 1C5A1D4B
	v_dot2_f32_bf16 v5, v79, v14, v5                           // 0000002A2010: CC1A4005 1C161D4F
	s_waitcnt vmcnt(7) lgkmcnt(7)                              // 0000002A2018: BF891C77
	v_dot2_f32_bf16 v13, v80, v1, v15                          // 0000002A201C: CC1A400D 1C3E0350
	s_waitcnt vmcnt(6)                                         // 0000002A2024: BF891BF7
	v_dot2_f32_bf16 v14, v84, v1, v16                          // 0000002A2028: CC1A400E 1C420354
	s_waitcnt vmcnt(5)                                         // 0000002A2030: BF8917F7
	v_dot2_f32_bf16 v15, v88, v1, v22                          // 0000002A2034: CC1A400F 1C5A0358
	s_waitcnt vmcnt(4)                                         // 0000002A203C: BF8913F7
	v_dot2_f32_bf16 v1, v92, v1, v5                            // 0000002A2040: CC1A4001 1C16035C
	v_mov_b32_e32 v16, v12                                     // 0000002A2048: 7E20030C
	s_waitcnt lgkmcnt(6)                                       // 0000002A204C: BF89FC67
	v_dot2_f32_bf16 v5, v81, v2, v13                           // 0000002A2050: CC1A4005 1C360551
	v_dot2_f32_bf16 v13, v85, v2, v14                          // 0000002A2058: CC1A400D 1C3A0555
	v_dot2_f32_bf16 v14, v89, v2, v15                          // 0000002A2060: CC1A400E 1C3E0559
	v_dot2_f32_bf16 v1, v93, v2, v1                            // 0000002A2068: CC1A4001 1C06055D
	v_mov_b32_e32 v15, v11                                     // 0000002A2070: 7E1E030B
	s_waitcnt lgkmcnt(5)                                       // 0000002A2074: BF89FC57
	v_dot2_f32_bf16 v2, v82, v3, v5                            // 0000002A2078: CC1A4002 1C160752
	v_dot2_f32_bf16 v5, v86, v3, v13                           // 0000002A2080: CC1A4005 1C360756
	v_dot2_f32_bf16 v13, v90, v3, v14                          // 0000002A2088: CC1A400D 1C3A075A
	v_dot2_f32_bf16 v1, v94, v3, v1                            // 0000002A2090: CC1A4001 1C06075E
	v_mov_b32_e32 v14, v10                                     // 0000002A2098: 7E1C030A
	s_waitcnt lgkmcnt(4)                                       // 0000002A209C: BF89FC47
	v_dot2_f32_bf16 v2, v83, v4, v2                            // 0000002A20A0: CC1A4002 1C0A0953
	v_dot2_f32_bf16 v3, v87, v4, v5                            // 0000002A20A8: CC1A4003 1C160957
	v_dot2_f32_bf16 v5, v91, v4, v13                           // 0000002A20B0: CC1A4005 1C36095B
	v_dot2_f32_bf16 v1, v95, v4, v1                            // 0000002A20B8: CC1A4001 1C06095F
	v_mov_b32_e32 v13, v9                                      // 0000002A20C0: 7E1A0309
	s_waitcnt vmcnt(3) lgkmcnt(3)                              // 0000002A20C4: BF890C37
	v_dot2_f32_bf16 v2, v96, v6, v2                            // 0000002A20C8: CC1A4002 1C0A0D60
	s_waitcnt vmcnt(2)                                         // 0000002A20D0: BF890BF7
	v_dot2_f32_bf16 v3, v100, v6, v3                           // 0000002A20D4: CC1A4003 1C0E0D64
	s_waitcnt vmcnt(1)                                         // 0000002A20DC: BF8907F7
	v_dot2_f32_bf16 v4, v104, v6, v5                           // 0000002A20E0: CC1A4004 1C160D68
	s_waitcnt vmcnt(0)                                         // 0000002A20E8: BF8903F7
	v_dot2_f32_bf16 v1, v108, v6, v1                           // 0000002A20EC: CC1A4001 1C060D6C
	s_waitcnt lgkmcnt(2)                                       // 0000002A20F4: BF89FC27
	v_dot2_f32_bf16 v2, v97, v8, v2                            // 0000002A20F8: CC1A4002 1C0A1161
	v_dot2_f32_bf16 v3, v101, v8, v3                           // 0000002A2100: CC1A4003 1C0E1165
	v_dot2_f32_bf16 v4, v105, v8, v4                           // 0000002A2108: CC1A4004 1C121169
	v_dot2_f32_bf16 v1, v109, v8, v1                           // 0000002A2110: CC1A4001 1C06116D
	s_waitcnt lgkmcnt(1)                                       // 0000002A2118: BF89FC17
	v_dot2_f32_bf16 v2, v98, v7, v2                            // 0000002A211C: CC1A4002 1C0A0F62
	v_dot2_f32_bf16 v3, v102, v7, v3                           // 0000002A2124: CC1A4003 1C0E0F66
	v_dot2_f32_bf16 v4, v106, v7, v4                           // 0000002A212C: CC1A4004 1C120F6A
	v_dot2_f32_bf16 v1, v110, v7, v1                           // 0000002A2134: CC1A4001 1C060F6E
	s_waitcnt lgkmcnt(0)                                       // 0000002A213C: BF89FC07
	v_dot2_f32_bf16 v2, v99, v48, v2                           // 0000002A2140: CC1A4002 1C0A6163
	v_dot2_f32_bf16 v3, v103, v48, v3                          // 0000002A2148: CC1A4003 1C0E6167
	v_dot2_f32_bf16 v4, v107, v48, v4                          // 0000002A2150: CC1A4004 1C12616B
	v_dot2_f32_bf16 v1, v111, v48, v1                          // 0000002A2158: CC1A4001 1C06616F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002A2160: BF870214
	v_fmac_f32_e32 v33, v112, v2                               // 0000002A2164: 56420570
	v_fmac_f32_e32 v35, v112, v3                               // 0000002A2168: 56460770
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002A216C: BF870214
	v_fmac_f32_e32 v34, v112, v4                               // 0000002A2170: 56440970
	v_fmac_f32_e32 v30, v112, v1                               // 0000002A2174: 563C0370
	v_dual_mov_b32 v1, v40 :: v_dual_mov_b32 v2, v41           // 0000002A2178: CA100128 01020129
	v_dual_mov_b32 v3, v42 :: v_dual_mov_b32 v4, v43           // 0000002A2180: CA10012A 0304012B
	v_dual_mov_b32 v5, v44 :: v_dual_mov_b32 v6, v45           // 0000002A2188: CA10012C 0506012D
	v_dual_mov_b32 v7, v46 :: v_dual_mov_b32 v8, v47           // 0000002A2190: CA10012E 0708012F
	s_and_not1_b32 exec_lo, exec_lo, s19                       // 0000002A2198: 917E137E
	s_cbranch_execz 35                                         // 0000002A219C: BFA50023 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0xc2c>
	s_waitcnt vmcnt(0)                                         // 0000002A21A0: BF8903F7
	v_dual_mov_b32 v9, v13 :: v_dual_add_nc_u32 v28, 16, v28   // 0000002A21A4: CA20010D 091C3890
	v_dual_mov_b32 v10, v14 :: v_dual_mov_b32 v11, v15         // 0000002A21AC: CA10010E 0A0A010F
	v_mov_b32_e32 v12, v16                                     // 0000002A21B4: 7E180310
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002A21B8: BF870003
	.long 0xd4460003                                           // 0000002A21BC: D4460003
	v_cndmask_b32_e32 v1, v28, v27, vcc_lo                     // 0000002A21C0: 0202371C
	s_mov_b32 s14, exec_lo                                     // 0000002A21C4: BE8E007E
	.long 0xd4c1007e                                           // 0000002A21C8: D4C1007E
	v_cndmask_b32_e32 v1, v28, v27, vcc_lo                     // 0000002A21CC: 0202371C
	s_cbranch_execz 65185                                      // 0000002A21D0: BFA5FEA1 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x658>
	v_ashrrev_i32_e32 v10, 31, v36                             // 0000002A21D4: 3414489F
	.long 0xd7006a09                                           // 0000002A21D8: D7006A09
	v_cndmask_b32_e32 v1, v20, v36, vcc_lo                     // 0000002A21DC: 02024914
	v_mov_b32_e32 v38, v39                                     // 0000002A21E0: 7E4C0327
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002A21E4: BF870003
	v_add_co_ci_u32_e64 v10, null, v32, v10, vcc_lo            // 0000002A21E8: D5207C0A 01AA1520
	v_cmp_ne_u32_e32 vcc_lo, 1, v31                            // 0000002A21F0: 7C9A3E81
	global_load_b128 v[9:12], v[9:10], off                     // 0000002A21F4: DC5E0000 097C0009
	s_cbranch_vccnz 65174                                      // 0000002A21FC: BFA4FE96 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x658>
	v_ashrrev_i32_e32 v22, 31, v37                             // 0000002A2200: 342C4A9F
	.long 0xd7006a28                                           // 0000002A2204: D7006A28
	v_cndmask_b32_e32 v1, v19, v37, vcc_lo                     // 0000002A2208: 02024B13
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002A220C: BF870001
	v_add_co_ci_u32_e64 v41, null, v29, v22, vcc_lo            // 0000002A2210: D5207C29 01AA2D1D
	global_load_d16_b16 v22, v[40:41], off                     // 0000002A2218: DC820000 167C0028
	s_waitcnt vmcnt(0)                                         // 0000002A2220: BF8903F7
	v_cvt_f32_f16_e32 v38, v22                                 // 0000002A2224: 7E4C1716
	s_branch 65163                                             // 0000002A2228: BFA0FE8B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x658>
	s_or_b32 exec_lo, exec_lo, s19                             // 0000002A222C: 8C7E137E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002A2230: BF870009
	s_or_b32 exec_lo, exec_lo, s9                              // 0000002A2234: 8C7E097E
	.long 0xd71f0001                                           // 0000002A2238: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000002A223C: 020100C1
	.long 0xd44a0001                                           // 0000002A2240: D44A0001
	v_cndmask_b32_e32 v1, 0, v24, vcc_lo                       // 0000002A2244: 02023080
	s_mov_b32 s3, -1                                           // 0000002A2248: BE8300C1
	v_xor_b32_e32 v2, 8, v1                                    // 0000002A224C: 3A040288
	v_xor_b32_e32 v6, 4, v1                                    // 0000002A2250: 3A0C0284
	v_xor_b32_e32 v10, 2, v1                                   // 0000002A2254: 3A140282
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000002A2258: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000002A225C: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 0000002A2260: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 0000002A2264: 7C980CA0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002A2268: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000002A226C: 30040482
	ds_bpermute_b32 v3, v2, v33                                // 0000002A2270: DACC0000 03002102
	s_waitcnt lgkmcnt(0)                                       // 0000002A2278: BF89FC07
	v_add_f32_e32 v3, v33, v3                                  // 0000002A227C: 06060721
	ds_bpermute_b32 v5, v2, v34                                // 0000002A2280: DACC0000 05002202
	v_cndmask_b32_e32 v6, v1, v6, vcc_lo                       // 0000002A2288: 020C0D01
	ds_bpermute_b32 v4, v2, v35                                // 0000002A228C: DACC0000 04002302
	ds_bpermute_b32 v2, v2, v30                                // 0000002A2294: DACC0000 02001E02
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 0000002A229C: 7C9814A0
	s_waitcnt lgkmcnt(2)                                       // 0000002A22A0: BF89FC27
	v_dual_cndmask_b32 v10, v1, v10 :: v_dual_add_f32 v5, v34, v5// 0000002A22A4: CA481501 0A040B22
	v_lshlrev_b32_e32 v6, 2, v6                                // 0000002A22AC: 300C0C82
	s_waitcnt lgkmcnt(1)                                       // 0000002A22B0: BF89FC17
	v_add_f32_e32 v4, v35, v4                                  // 0000002A22B4: 06080923
	s_waitcnt lgkmcnt(0)                                       // 0000002A22B8: BF89FC07
	v_add_f32_e32 v2, v30, v2                                  // 0000002A22BC: 0604051E
	ds_bpermute_b32 v9, v6, v5                                 // 0000002A22C0: DACC0000 09000506
	s_waitcnt lgkmcnt(0)                                       // 0000002A22C8: BF89FC07
	v_add_f32_e32 v5, v5, v9                                   // 0000002A22CC: 060A1305
	ds_bpermute_b32 v7, v6, v3                                 // 0000002A22D0: DACC0000 07000306
	ds_bpermute_b32 v8, v6, v4                                 // 0000002A22D8: DACC0000 08000406
	v_lshlrev_b32_e32 v10, 2, v10                              // 0000002A22E0: 30141482
	ds_bpermute_b32 v6, v6, v2                                 // 0000002A22E4: DACC0000 06000206
	s_waitcnt lgkmcnt(1)                                       // 0000002A22EC: BF89FC17
	v_dual_add_f32 v3, v3, v7 :: v_dual_add_f32 v4, v4, v8     // 0000002A22F0: C9080F03 03041104
	ds_bpermute_b32 v8, v10, v5                                // 0000002A22F8: DACC0000 0800050A
	s_waitcnt lgkmcnt(0)                                       // 0000002A2300: BF89FC07
	v_dual_add_f32 v5, v5, v8 :: v_dual_add_f32 v2, v2, v6     // 0000002A2304: C9081105 05020D02
	ds_bpermute_b32 v6, v10, v3                                // 0000002A230C: DACC0000 0600030A
	ds_bpermute_b32 v9, v10, v2                                // 0000002A2314: DACC0000 0900020A
	s_waitcnt lgkmcnt(1)                                       // 0000002A231C: BF89FC17
	v_add_f32_e32 v3, v3, v6                                   // 0000002A2320: 06060D03
	ds_bpermute_b32 v7, v10, v4                                // 0000002A2324: DACC0000 0700040A
	v_xor_b32_e32 v10, 1, v1                                   // 0000002A232C: 3A140281
	s_waitcnt lgkmcnt(1)                                       // 0000002A2330: BF89FC17
	v_add_f32_e32 v6, v2, v9                                   // 0000002A2334: 060C1302
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002A2338: BF8700B2
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 0000002A233C: 7C9814A0
	v_cndmask_b32_e32 v1, v1, v10, vcc_lo                      // 0000002A2340: 02021501
	s_and_b32 vcc_lo, exec_lo, s8                              // 0000002A2344: 8B6A087E
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000002A2348: 30020282
	ds_bpermute_b32 v2, v1, v3                                 // 0000002A234C: DACC0000 02000301
	s_waitcnt lgkmcnt(1)                                       // 0000002A2354: BF89FC17
	v_add_f32_e32 v4, v4, v7                                   // 0000002A2358: 06080F04
	ds_bpermute_b32 v8, v1, v5                                 // 0000002A235C: DACC0000 08000501
	ds_bpermute_b32 v9, v1, v6                                 // 0000002A2364: DACC0000 09000601
	ds_bpermute_b32 v7, v1, v4                                 // 0000002A236C: DACC0000 07000401
	s_waitcnt lgkmcnt(3)                                       // 0000002A2374: BF89FC37
	v_add_f32_e32 v1, v3, v2                                   // 0000002A2378: 06020503
	s_waitcnt lgkmcnt(0)                                       // 0000002A237C: BF89FC07
	v_dual_add_f32 v3, v5, v8 :: v_dual_add_f32 v2, v4, v7     // 0000002A2380: C9081105 03020F04
	v_add_f32_e32 v4, v6, v9                                   // 0000002A2388: 06081306
	s_cbranch_vccz 425                                         // 0000002A238C: BFA301A9 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1434>
	s_and_saveexec_b32 s3, s1                                  // 0000002A2390: BE832001
	v_lshlrev_b32_e32 v5, 4, v26                               // 0000002A2394: 300A3484
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002A2398: BF870001
	v_lshl_or_b32 v5, v25, 8, v5                               // 0000002A239C: D6560005 04151119
	ds_store_b128 v5, v[1:4] offset:1024                       // 0000002A23A4: DB7C0400 00000105
	s_or_b32 exec_lo, exec_lo, s3                              // 0000002A23AC: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002A23B0: BF870009
	s_mov_b32 s8, exec_lo                                      // 0000002A23B4: BE88007E
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000002A23B8: BF890007
	s_barrier                                                  // 0000002A23BC: BFBD0000
	buffer_gl0_inv                                             // 0000002A23C0: E0AC0000 00000000
	v_cmpx_gt_u32_e32 4, v0                                    // 0000002A23C8: 7D980084
	s_cbranch_execz 407                                        // 0000002A23CC: BFA50197 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x142c>
	s_load_b32 s3, s[16:17], 0x40                              // 0000002A23D0: F40000C8 F8000040
	s_waitcnt lgkmcnt(0)                                       // 0000002A23D8: BF89FC07
	s_sub_i32 s2, s2, s3                                       // 0000002A23DC: 81820302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000002A23E0: BF870499
	s_ashr_i32 s3, s2, 31                                      // 0000002A23E4: 86039F02
	.long 0xd4530004                                           // 0000002A23E8: D4530004
	v_cndmask_b32_e32 v0, s10, v2, vcc_lo                      // 0000002A23EC: 0200040A
	s_and_b32 vcc_lo, exec_lo, s4                              // 0000002A23F0: 8B6A047E
	s_cbranch_vccnz 397                                        // 0000002A23F4: BFA4018D <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x142c>
	v_add_nc_u32_e32 v11, 0x400, v23                           // 0000002A23F8: 4A162EFF 00000400
	s_clause 0x1                                               // 0000002A2400: BF850001
	s_load_b64 s[6:7], s[16:17], 0x38                          // 0000002A2404: F4040188 F8000038
	s_load_b64 s[4:5], s[16:17], 0x8                           // 0000002A240C: F4040108 F8000008
	s_mov_b32 s9, 0                                            // 0000002A2414: BE890080
	s_mov_b32 s13, -1                                          // 0000002A2418: BE8D00C1
	s_mov_b32 s12, 0                                           // 0000002A241C: BE8C0080
	ds_load_2addr_b32 v[5:6], v11 offset1:4                    // 0000002A2420: D8DC0400 0500000B
	ds_load_2addr_b32 v[7:8], v11 offset0:8 offset1:12         // 0000002A2428: D8DC0C08 0700000B
	ds_load_2addr_b32 v[9:10], v11 offset0:16 offset1:20       // 0000002A2430: D8DC1410 0900000B
	s_waitcnt lgkmcnt(0)                                       // 0000002A2438: BF89FC07
	s_cmp_lt_i32 s7, 3                                         // 0000002A243C: BF048307
	v_add_f32_e32 v5, 0, v5                                    // 0000002A2440: 060A0A80
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002A2444: BF8700B1
	v_add_f32_e32 v12, v5, v6                                  // 0000002A2448: 06180D05
	ds_load_2addr_b32 v[5:6], v11 offset0:24 offset1:28        // 0000002A244C: D8DC1C18 0500000B
	v_add_f32_e32 v7, v12, v7                                  // 0000002A2454: 060E0F0C
	v_add_f32_e32 v12, v7, v8                                  // 0000002A2458: 06181107
	ds_load_2addr_b32 v[7:8], v11 offset0:32 offset1:36        // 0000002A245C: D8DC2420 0700000B
	v_add_f32_e32 v9, v12, v9                                  // 0000002A2464: 0612130C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000002A2468: BF8700C1
	v_add_f32_e32 v12, v9, v10                                 // 0000002A246C: 06181509
	ds_load_2addr_b32 v[9:10], v11 offset0:40 offset1:44       // 0000002A2470: D8DC2C28 0900000B
	s_waitcnt lgkmcnt(2)                                       // 0000002A2478: BF89FC27
	v_add_f32_e32 v5, v12, v5                                  // 0000002A247C: 060A0B0C
	v_add_f32_e32 v5, v5, v6                                   // 0000002A2480: 060A0D05
	s_waitcnt lgkmcnt(1)                                       // 0000002A2484: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000002A2488: BF8700C1
	v_add_f32_e32 v7, v5, v7                                   // 0000002A248C: 060E0F05
	ds_load_2addr_b32 v[5:6], v11 offset0:48 offset1:52        // 0000002A2490: D8DC3430 0500000B
	v_add_f32_e32 v7, v7, v8                                   // 0000002A2498: 060E1107
	s_waitcnt lgkmcnt(1)                                       // 0000002A249C: BF89FC17
	v_add_f32_e32 v9, v7, v9                                   // 0000002A24A0: 06121307
	ds_load_2addr_b32 v[7:8], v11 offset0:56 offset1:60        // 0000002A24A4: D8DC3C38 0700000B
	v_add_f32_e32 v9, v9, v10                                  // 0000002A24AC: 06121509
	s_waitcnt lgkmcnt(1)                                       // 0000002A24B0: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A24B4: BF870091
	v_add_f32_e32 v5, v9, v5                                   // 0000002A24B8: 060A0B09
	v_add_f32_e32 v5, v5, v6                                   // 0000002A24BC: 060A0D05
	s_waitcnt lgkmcnt(0)                                       // 0000002A24C0: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A24C4: BF870091
	v_add_f32_e32 v5, v5, v7                                   // 0000002A24C8: 060A0F05
	v_add_f32_e32 v5, v5, v8                                   // 0000002A24CC: 060A1105
	s_cbranch_scc1 178                                         // 0000002A24D0: BFA200B2 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x119c>
	s_cmp_gt_i32 s7, 3                                         // 0000002A24D4: BF028307
	s_cbranch_scc0 112                                         // 0000002A24D8: BFA10070 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x109c>
	s_cmp_gt_i32 s7, 4                                         // 0000002A24DC: BF028407
	s_cbranch_scc0 58                                          // 0000002A24E0: BFA1003A <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0xfcc>
	s_cmp_eq_u32 s7, 5                                         // 0000002A24E4: BF068507
	s_mov_b32 s12, -1                                          // 0000002A24E8: BE8C00C1
	s_cbranch_scc0 54                                          // 0000002A24EC: BFA10036 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0xfc8>
	s_ashr_i32 s14, s2, 31                                     // 0000002A24F0: 860E9F02
	s_load_b64 s[12:13], s[16:17], 0x10                        // 0000002A24F4: F4040308 F8000010
	s_lshr_b32 s14, s14, 23                                    // 0000002A24FC: 850E970E
	s_lshr_b32 s15, s10, 31                                    // 0000002A2500: 850F9F0A
	s_add_i32 s14, s2, s14                                     // 0000002A2504: 810E0E02
	s_add_i32 s18, s10, s15                                    // 0000002A2508: 81120F0A
	s_ashr_i32 s14, s14, 9                                     // 0000002A250C: 860E890E
	s_ashr_i32 s18, s18, 1                                     // 0000002A2510: 86128112
	s_ashr_i32 s15, s14, 31                                    // 0000002A2514: 860F9F0E
	v_mad_i64_i32 v[6:7], null, s18, v0, 0                     // 0000002A2518: D6FF7C06 02020012
	s_lshl_b64 s[14:15], s[14:15], 9                           // 0000002A2520: 848E890E
	v_bfe_u32 v8, v5, 16, 1                                    // 0000002A2524: D6100008 02052105
	s_sub_u32 s18, s2, s14                                     // 0000002A252C: 80920E02
	s_subb_u32 s19, s3, s15                                    // 0000002A2530: 82930F03
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002A2534: BF870119
	.long 0xd4540014                                           // 0000002A2538: D4540014
	v_cndmask_b32_e32 v0, 0x100, v18, vcc_lo                   // 0000002A253C: 020024FF 00000100
	v_add3_u32 v8, v5, v8, 0x7fff                              // 0000002A2544: D6550008 03FE1105 00007FFF
	.long 0xd73c0006                                           // 0000002A2550: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 0000002A2554: 02020C81
	s_and_b32 s21, s20, exec_lo                                // 0000002A2558: 8B157E14
	s_waitcnt lgkmcnt(0)                                       // 0000002A255C: BF89FC07
	s_cselect_b32 s12, s4, s12                                 // 0000002A2560: 980C0C04
	s_cselect_b32 s21, s5, s13                                 // 0000002A2564: 98150D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A2568: BF870091
	.long 0xd7006a06                                           // 0000002A256C: D7006A06
	v_cndmask_b32_e32 v1, s12, v6, vcc_lo                      // 0000002A2570: 02020C0C
	v_add_co_ci_u32_e64 v7, null, s21, v7, vcc_lo              // 0000002A2574: D5207C07 01AA0E15
	s_add_u32 s22, s18, 0xffffff00                             // 0000002A257C: 8016FF12 FFFFFF00
	s_addc_u32 s13, s19, -1                                    // 0000002A2584: 820DC113
	s_and_b32 s20, s20, exec_lo                                // 0000002A2588: 8B147E14
	.long 0xd7006a06                                           // 0000002A258C: D7006A06
	v_cndmask_b32_e32 v0, v6, v14, vcc_lo                      // 0000002A2590: 02001D06
	s_cselect_b32 s13, s19, s13                                // 0000002A2594: 980D0D13
	s_cselect_b32 s12, s18, s22                                // 0000002A2598: 980C1612
	v_add_co_ci_u32_e64 v7, null, s15, v7, vcc_lo              // 0000002A259C: D5207C07 01AA0E0F
	s_lshl_b64 s[12:13], s[12:13], 1                           // 0000002A25A4: 848C810C
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A25A8: BF870099
	.long 0xd7006a06                                           // 0000002A25AC: D7006A06
	v_cndmask_b32_e32 v0, v6, v12, vcc_lo                      // 0000002A25B0: 02001906
	v_add_co_ci_u32_e64 v7, null, s13, v7, vcc_lo              // 0000002A25B4: D5207C07 01AA0E0D
	s_mov_b32 s12, 0                                           // 0000002A25BC: BE8C0080
	global_store_d16_hi_b16 v[6:7], v8, off                    // 0000002A25C0: DC960000 007C0806
	s_mov_b32 s13, 0                                           // 0000002A25C8: BE8D0080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002A25CC: BF870009
	s_and_b32 vcc_lo, exec_lo, s13                             // 0000002A25D0: 8B6A0D7E
	s_cbranch_vccz 48                                          // 0000002A25D4: BFA30030 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1098>
	v_mul_f32_e32 v6, 0xbfb8aa3b, v5                           // 0000002A25D8: 100C0AFF BFB8AA3B
	s_lshl_b64 s[14:15], s[2:3], 2                             // 0000002A25E0: 848E8202
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002A25E4: BF870291
	v_exp_f32_e32 v6, v6                                       // 0000002A25E8: 7E0C4B06
	v_add_f32_e32 v9, 1.0, v6                                  // 0000002A25EC: 06120CF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002A25F0: BF870121
	v_div_scale_f32 v10, null, v9, v9, 1.0                     // 0000002A25F4: D6FC7C0A 03CA1309
	v_div_scale_f32 v12, vcc_lo, 1.0, v9, 1.0                  // 0000002A25FC: D6FC6A0C 03CA12F2
	v_rcp_f32_e32 v11, v10                                     // 0000002A2604: 7E16550A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A2608: BF870095
	v_fma_f32 v6, -v10, v11, 1.0                               // 0000002A260C: D6130006 23CA170A
	v_fmac_f32_e32 v11, v6, v11                                // 0000002A2614: 56161706
	v_mad_u64_u32 v[6:7], null, s10, v0, 0                     // 0000002A2618: D6FE7C06 0202000A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002A2620: BF870112
	v_mul_f32_e32 v13, v12, v11                                // 0000002A2624: 101A170C
	v_mad_u64_u32 v[7:8], null, s11, v0, v[7:8]                // 0000002A2628: D6FE7C07 041E000B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A2630: BF870092
	v_fma_f32 v14, -v10, v13, v12                              // 0000002A2634: D613000E 24321B0A
	v_fmac_f32_e32 v13, v14, v11                               // 0000002A263C: 561A170E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002A2640: BF870113
	.long 0xd73c0006                                           // 0000002A2644: D73C0006
	v_cndmask_b32_e32 v1, 2, v6, vcc_lo                        // 0000002A2648: 02020C82
	v_fma_f32 v8, -v10, v13, v12                               // 0000002A264C: D6130008 24321B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002A2654: BF870191
	v_div_fmas_f32 v8, v8, v11, v13                            // 0000002A2658: D6370008 04361708
	.long 0xd7006a06                                           // 0000002A2660: D7006A06
	v_cndmask_b32_e32 v1, s4, v6, vcc_lo                       // 0000002A2664: 02020C04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002A2668: BF870191
	v_add_co_ci_u32_e64 v7, null, s5, v7, vcc_lo               // 0000002A266C: D5207C07 01AA0E05
	v_div_fixup_f32 v8, v8, v9, 1.0                            // 0000002A2674: D6270008 03CA1308
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A267C: BF870093
	.long 0xd7006a06                                           // 0000002A2680: D7006A06
	v_cndmask_b32_e32 v0, v6, v14, vcc_lo                      // 0000002A2684: 02001D06
	v_add_co_ci_u32_e64 v7, null, s15, v7, vcc_lo              // 0000002A2688: D5207C07 01AA0E0F
	global_store_b32 v[6:7], v8, off                           // 0000002A2690: DC6A0000 007C0806
	s_mov_b32 s13, 0                                           // 0000002A2698: BE8D0080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002A269C: BF870009
	s_and_b32 vcc_lo, exec_lo, s13                             // 0000002A26A0: 8B6A0D7E
	s_cbranch_vccz 60                                          // 0000002A26A4: BFA3003C <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1198>
	v_bfe_u32 v6, v5, 16, 1                                    // 0000002A26A8: D6100006 02052105
	s_lshl_b64 s[14:15], s[2:3], 2                             // 0000002A26B0: 848E8202
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A26B4: BF870091
	v_add3_u32 v6, v5, v6, 0x7fff                              // 0000002A26B8: D6550006 03FE0D05 00007FFF
	v_and_b32_e32 v6, 0xffff0000, v6                           // 0000002A26C4: 360C0CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A26CC: BF870091
	v_mul_f32_e32 v6, s6, v6                                   // 0000002A26D0: 100C0C06
	v_mul_f32_e32 v6, 0xbfb8aa3b, v6                           // 0000002A26D4: 100C0CFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002A26DC: BF870291
	v_exp_f32_e32 v6, v6                                       // 0000002A26E0: 7E0C4B06
	v_add_f32_e32 v9, 1.0, v6                                  // 0000002A26E4: 06120CF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002A26E8: BF870121
	v_div_scale_f32 v10, null, v9, v9, 1.0                     // 0000002A26EC: D6FC7C0A 03CA1309
	v_div_scale_f32 v12, vcc_lo, 1.0, v9, 1.0                  // 0000002A26F4: D6FC6A0C 03CA12F2
	v_rcp_f32_e32 v11, v10                                     // 0000002A26FC: 7E16550A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A2700: BF870095
	v_fma_f32 v6, -v10, v11, 1.0                               // 0000002A2704: D6130006 23CA170A
	v_fmac_f32_e32 v11, v6, v11                                // 0000002A270C: 56161706
	v_mad_u64_u32 v[6:7], null, s10, v0, 0                     // 0000002A2710: D6FE7C06 0202000A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A2718: BF870092
	v_mul_f32_e32 v13, v12, v11                                // 0000002A271C: 101A170C
	v_fma_f32 v8, -v10, v13, v12                               // 0000002A2720: D6130008 24321B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002A2728: BF870211
	v_fmac_f32_e32 v13, v8, v11                                // 0000002A272C: 561A1708
	v_mad_u64_u32 v[7:8], null, s11, v0, v[7:8]                // 0000002A2730: D6FE7C07 041E000B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002A2738: BF870112
	v_fma_f32 v8, -v10, v13, v12                               // 0000002A273C: D6130008 24321B0A
	.long 0xd73c0006                                           // 0000002A2744: D73C0006
	v_cndmask_b32_e32 v1, 2, v6, vcc_lo                        // 0000002A2748: 02020C82
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002A274C: BF870112
	v_div_fmas_f32 v8, v8, v11, v13                            // 0000002A2750: D6370008 04361708
	.long 0xd7006a06                                           // 0000002A2758: D7006A06
	v_cndmask_b32_e32 v1, s4, v6, vcc_lo                       // 0000002A275C: 02020C04
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002A2760: BF870212
	v_div_fixup_f32 v8, v8, v9, 1.0                            // 0000002A2764: D6270008 03CA1308
	v_add_co_ci_u32_e64 v7, null, s5, v7, vcc_lo               // 0000002A276C: D5207C07 01AA0E05
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002A2774: BF870193
	.long 0xd7006a06                                           // 0000002A2778: D7006A06
	v_cndmask_b32_e32 v0, v6, v14, vcc_lo                      // 0000002A277C: 02001D06
	v_add_f32_e32 v8, v8, v8                                   // 0000002A2780: 06101108
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002A2784: BF870003
	v_add_co_ci_u32_e64 v7, null, s15, v7, vcc_lo              // 0000002A2788: D5207C07 01AA0E0F
	global_store_b32 v[6:7], v8, off                           // 0000002A2790: DC6A0000 007C0806
	s_mov_b32 s13, 0                                           // 0000002A2798: BE8D0080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002A279C: BF870009
	s_and_b32 vcc_lo, exec_lo, s13                             // 0000002A27A0: 8B6A0D7E
	s_cbranch_vccz 72                                          // 0000002A27A4: BFA30048 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x12c8>
	s_cmp_gt_i32 s7, 1                                         // 0000002A27A8: BF028107
	s_mov_b32 s9, -1                                           // 0000002A27AC: BE8900C1
	s_cbranch_scc0 63                                          // 0000002A27B0: BFA1003F <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x12b0>
	v_bfe_u32 v6, v5, 16, 1                                    // 0000002A27B4: D6100006 02052105
	s_lshl_b64 s[14:15], s[2:3], 1                             // 0000002A27BC: 848E8102
	s_mov_b32 s9, 0                                            // 0000002A27C0: BE890080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A27C4: BF870091
	v_add3_u32 v6, v5, v6, 0x7fff                              // 0000002A27C8: D6550006 03FE0D05 00007FFF
	v_and_b32_e32 v6, 0xffff0000, v6                           // 0000002A27D4: 360C0CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A27DC: BF870091
	v_mul_f32_e32 v6, 0xbfb8aa3b, v6                           // 0000002A27E0: 100C0CFF BFB8AA3B
	v_exp_f32_e32 v6, v6                                       // 0000002A27E8: 7E0C4B06
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A27EC: BF870095
	v_add_f32_e32 v9, 1.0, v6                                  // 0000002A27F0: 06120CF2
	v_div_scale_f32 v8, null, v9, v9, 1.0                      // 0000002A27F4: D6FC7C08 03CA1309
	v_div_scale_f32 v11, vcc_lo, 1.0, v9, 1.0                  // 0000002A27FC: D6FC6A0B 03CA12F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002A2804: BF870292
	v_rcp_f32_e32 v10, v8                                      // 0000002A2808: 7E145508
	v_fma_f32 v6, -v8, v10, 1.0                                // 0000002A280C: D6130006 23CA1508
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002A2814: BF870121
	v_fmac_f32_e32 v10, v6, v10                                // 0000002A2818: 56141506
	v_mad_u64_u32 v[6:7], null, s10, v0, 0                     // 0000002A281C: D6FE7C06 0202000A
	v_mul_f32_e32 v12, v11, v10                                // 0000002A2824: 1018150B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A2828: BF870091
	v_fma_f32 v13, -v8, v12, v11                               // 0000002A282C: D613000D 242E1908
	v_fmac_f32_e32 v12, v13, v10                               // 0000002A2834: 5618150D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002A2838: BF870121
	v_fma_f32 v11, -v8, v12, v11                               // 0000002A283C: D613000B 242E1908
	v_mad_u64_u32 v[7:8], null, s11, v0, v[7:8]                // 0000002A2844: D6FE7C07 041E000B
	v_div_fmas_f32 v8, v11, v10, v12                           // 0000002A284C: D6370008 0432150B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002A2854: BF870112
	.long 0xd73c0006                                           // 0000002A2858: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 0000002A285C: 02020C81
	v_div_fixup_f32 v8, v8, v9, 1.0                            // 0000002A2860: D6270008 03CA1308
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002A2868: BF870112
	.long 0xd7006a06                                           // 0000002A286C: D7006A06
	v_cndmask_b32_e32 v1, s4, v6, vcc_lo                       // 0000002A2870: 02020C04
	v_bfe_u32 v9, v8, 16, 1                                    // 0000002A2874: D6100009 02052108
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002A287C: BF870194
	v_add_co_ci_u32_e64 v7, null, s5, v7, vcc_lo               // 0000002A2880: D5207C07 01AA0E05
	.long 0xd7006a06                                           // 0000002A2888: D7006A06
	v_cndmask_b32_e32 v0, v6, v14, vcc_lo                      // 0000002A288C: 02001D06
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002A2890: BF870193
	v_add3_u32 v8, v8, v9, 0x7fff                              // 0000002A2894: D6550008 03FE1308 00007FFF
	v_add_co_ci_u32_e64 v7, null, s15, v7, vcc_lo              // 0000002A28A0: D5207C07 01AA0E0F
	global_store_d16_hi_b16 v[6:7], v8, off                    // 0000002A28A8: DC960000 007C0806
	s_and_not1_b32 vcc_lo, exec_lo, s9                         // 0000002A28B0: 916A097E
	s_mov_b32 s9, 0                                            // 0000002A28B4: BE890080
	s_cbranch_vccnz 3                                          // 0000002A28B8: BFA40003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x12c8>
	s_cmp_lg_u32 s7, 1                                         // 0000002A28BC: BF078107
	s_mov_b32 s9, -1                                           // 0000002A28C0: BE8900C1
	s_cselect_b32 s12, -1, 0                                   // 0000002A28C4: 980C80C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002A28C8: BF8700A1
	v_bfe_u32 v6, v5, 16, 1                                    // 0000002A28CC: D6100006 02052105
	s_and_b32 vcc_lo, exec_lo, s12                             // 0000002A28D4: 8B6A0C7E
	v_add3_u32 v5, v5, v6, 0x7fff                              // 0000002A28D8: D6550005 03FE0D05 00007FFF
	s_cbranch_vccz 21                                          // 0000002A28E4: BFA30015 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x133c>
	v_mad_u64_u32 v[6:7], null, s10, v0, 0                     // 0000002A28E8: D6FE7C06 0202000A
	s_lshl_b64 s[12:13], s[2:3], 1                             // 0000002A28F0: 848C8102
	s_mov_b32 s9, 0                                            // 0000002A28F4: BE890080
	v_mad_u64_u32 v[7:8], null, s11, v0, v[7:8]                // 0000002A28F8: D6FE7C07 041E000B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A2900: BF870091
	.long 0xd73c0006                                           // 0000002A2904: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 0000002A2908: 02020C81
	.long 0xd7006a06                                           // 0000002A290C: D7006A06
	v_cndmask_b32_e32 v1, s4, v6, vcc_lo                       // 0000002A2910: 02020C04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002A2914: BF870111
	v_add_co_ci_u32_e64 v7, null, s5, v7, vcc_lo               // 0000002A2918: D5207C07 01AA0E05
	.long 0xd7006a06                                           // 0000002A2920: D7006A06
	v_cndmask_b32_e32 v0, v6, v12, vcc_lo                      // 0000002A2924: 02001906
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002A2928: BF870001
	v_add_co_ci_u32_e64 v7, null, s13, v7, vcc_lo              // 0000002A292C: D5207C07 01AA0E0D
	global_store_d16_hi_b16 v[6:7], v5, off                    // 0000002A2934: DC960000 007C0506
	s_and_not1_b32 vcc_lo, exec_lo, s9                         // 0000002A293C: 916A097E
	s_cbranch_vccnz 58                                         // 0000002A2940: BFA4003A <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x142c>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002A2944: BF8700A1
	v_and_b32_e32 v5, 0xffff0000, v5                           // 0000002A2948: 360A0AFF FFFF0000
	s_lshl_b64 s[2:3], s[2:3], 1                               // 0000002A2950: 84828102
	v_mul_f32_e32 v8, s6, v5                                   // 0000002A2954: 10100A06
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A2958: BF870091
	v_mul_f32_e32 v5, 0xbfb8aa3b, v8                           // 0000002A295C: 100A10FF BFB8AA3B
	v_exp_f32_e32 v5, v5                                       // 0000002A2964: 7E0A4B05
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A2968: BF870095
	v_add_f32_e32 v9, 1.0, v5                                  // 0000002A296C: 06120AF2
	v_div_scale_f32 v7, null, v9, v9, v8                       // 0000002A2970: D6FC7C07 04221309
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002A2978: BF870291
	v_rcp_f32_e32 v10, v7                                      // 0000002A297C: 7E145507
	v_fma_f32 v5, -v7, v10, 1.0                                // 0000002A2980: D6130005 23CA1507
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000002A2988: BF870131
	v_fmac_f32_e32 v10, v5, v10                                // 0000002A298C: 56141505
	v_div_scale_f32 v11, vcc_lo, v8, v9, v8                    // 0000002A2990: D6FC6A0B 04221308
	v_mad_u64_u32 v[5:6], null, s10, v0, 0                     // 0000002A2998: D6FE7C05 0202000A
	v_mul_f32_e32 v12, v11, v10                                // 0000002A29A0: 1018150B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A29A4: BF870091
	v_fma_f32 v13, -v7, v12, v11                               // 0000002A29A8: D613000D 242E1907
	v_fmac_f32_e32 v12, v13, v10                               // 0000002A29B0: 5618150D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002A29B4: BF870121
	v_fma_f32 v11, -v7, v12, v11                               // 0000002A29B8: D613000B 242E1907
	v_mad_u64_u32 v[6:7], null, s11, v0, v[6:7]                // 0000002A29C0: D6FE7C06 041A000B
	v_div_fmas_f32 v0, v11, v10, v12                           // 0000002A29C8: D6370000 0432150B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002A29D0: BF870112
	.long 0xd73c0005                                           // 0000002A29D4: D73C0005
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 0000002A29D8: 02020A81
	v_div_fixup_f32 v0, v0, v9, v8                             // 0000002A29DC: D6270000 04221300
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002A29E4: BF870112
	.long 0xd7006a05                                           // 0000002A29E8: D7006A05
	v_cndmask_b32_e32 v1, s4, v5, vcc_lo                       // 0000002A29EC: 02020A04
	v_bfe_u32 v7, v0, 16, 1                                    // 0000002A29F0: D6100007 02052100
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002A29F8: BF870194
	v_add_co_ci_u32_e64 v6, null, s5, v6, vcc_lo               // 0000002A29FC: D5207C06 01AA0C05
	.long 0xd7006a05                                           // 0000002A2A04: D7006A05
	v_cndmask_b32_e32 v0, v5, v2, vcc_lo                       // 0000002A2A08: 02000505
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002A2A0C: BF870193
	v_add3_u32 v0, v0, v7, 0x7fff                              // 0000002A2A10: D6550000 03FE0F00 00007FFF
	v_add_co_ci_u32_e64 v6, null, s3, v6, vcc_lo               // 0000002A2A1C: D5207C06 01AA0C03
	global_store_d16_hi_b16 v[5:6], v0, off                    // 0000002A2A24: DC960000 007C0005
	s_or_b32 exec_lo, exec_lo, s8                              // 0000002A2A2C: 8C7E087E
	s_mov_b32 s3, 0                                            // 0000002A2A30: BE830080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002A2A34: BF870009
	s_and_b32 vcc_lo, exec_lo, s3                              // 0000002A2A38: 8B6A037E
	s_cbranch_vccz 1092                                        // 0000002A2A3C: BFA30444 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x2550>
	s_and_b32 s0, s1, s0                                       // 0000002A2A40: 8B000001
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002A2A44: BF870009
	s_and_saveexec_b32 s1, s0                                  // 0000002A2A48: BE812000
	s_cbranch_execz 1088                                       // 0000002A2A4C: BFA50440 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x2550>
	v_ashrrev_i32_e32 v0, 31, v18                              // 0000002A2A50: 3400249F
	s_clause 0x1                                               // 0000002A2A54: BF850001
	s_load_b64 s[4:5], s[16:17], 0x8                           // 0000002A2A58: F4040108 F8000008
	s_load_b64 s[2:3], s[16:17], 0x38                          // 0000002A2A60: F4040088 F8000038
	.long 0xd73c0005                                           // 0000002A2A68: D73C0005
	v_cndmask_b32_e32 v1, 1, v17, vcc_lo                       // 0000002A2A6C: 02022281
	.long 0xd73c0007                                           // 0000002A2A70: D73C0007
	v_cndmask_b32_e32 v1, 2, v17, vcc_lo                       // 0000002A2A74: 02022282
	s_mov_b32 s7, -1                                           // 0000002A2A78: BE8700C1
	v_lshrrev_b32_e32 v0, 23, v0                               // 0000002A2A7C: 32000097
	s_mov_b32 s1, 0                                            // 0000002A2A80: BE810080
	s_mov_b32 s6, 0                                            // 0000002A2A84: BE860080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A2A88: BF870091
	.long 0xd7006a09                                           // 0000002A2A8C: D7006A09
	v_cndmask_b32_e32 v1, v17, v0, vcc_lo                      // 0000002A2A90: 02020111
	v_add_co_ci_u32_e64 v0, null, 0, v18, vcc_lo               // 0000002A2A94: D5207C00 01AA2480
	.long 0xd7016a05                                           // 0000002A2A9C: D7016A05
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 0000002A2AA0: 02020A80
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002A2AA4: BF870123
	v_and_b32_e32 v11, 0xfffffe00, v9                          // 0000002A2AA8: 361612FF FFFFFE00
	v_sub_co_ci_u32_e64 v6, null, 0, v6, vcc_lo                // 0000002A2AB0: D5217C06 01AA0C80
	.long 0xd7016a09                                           // 0000002A2AB8: D7016A09
	v_cndmask_b32_e32 v1, v17, v11, vcc_lo                     // 0000002A2ABC: 02021711
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002A2AC0: BF8700B1
	v_sub_co_ci_u32_e64 v10, null, v18, v0, vcc_lo             // 0000002A2AC4: D5217C0A 01AA0112
	s_waitcnt lgkmcnt(0)                                       // 0000002A2ACC: BF89FC07
	.long 0xd7006a07                                           // 0000002A2AD0: D7006A07
	v_cndmask_b32_e32 v1, s4, v7, vcc_lo                       // 0000002A2AD4: 02020E04
	v_add_co_ci_u32_e64 v8, null, s5, v8, vcc_lo               // 0000002A2AD8: D5207C08 01AA1005
	.long 0xd7006a0c                                           // 0000002A2AE0: D7006A0C
	v_cndmask_b32_e32 v1, 0xffffff00, v9, vcc_lo               // 0000002A2AE4: 020212FF FFFFFF00
	.long 0xd4540000                                           // 0000002A2AEC: D4540000
	v_cndmask_b32_e32 v1, 0x100, v9, vcc_lo                    // 0000002A2AF0: 020212FF 00000100
	s_waitcnt vmcnt(0)                                         // 0000002A2AF8: BF8903F7
	v_add_co_ci_u32_e64 v13, null, -1, v10, vcc_lo             // 0000002A2AFC: D5207C0D 01AA14C1
	.long 0xd7006a05                                           // 0000002A2B04: D7006A05
	v_cndmask_b32_e32 v1, v7, v5, vcc_lo                       // 0000002A2B08: 02020B07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002A2B0C: BF870191
	v_add_co_ci_u32_e64 v6, null, v8, v6, vcc_lo               // 0000002A2B10: D5207C06 01AA0D08
	v_cndmask_b32_e64 v10, v13, v10, s0                        // 0000002A2B18: D501000A 0002150D
	v_cndmask_b32_e64 v9, v12, v9, s0                          // 0000002A2B20: D5010009 0002130C
	s_cmp_lt_i32 s3, 3                                         // 0000002A2B28: BF048303
	s_cbranch_scc1 118                                         // 0000002A2B2C: BFA20076 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1708>
	s_cmp_gt_i32 s3, 3                                         // 0000002A2B30: BF028303
	s_cbranch_scc0 70                                          // 0000002A2B34: BFA10046 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1650>
	s_cmp_gt_i32 s3, 4                                         // 0000002A2B38: BF028403
	s_cbranch_scc0 34                                          // 0000002A2B3C: BFA10022 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x15c8>
	s_cmp_eq_u32 s3, 5                                         // 0000002A2B40: BF068503
	s_mov_b32 s6, -1                                           // 0000002A2B44: BE8600C1
	s_cbranch_scc0 30                                          // 0000002A2B48: BFA1001E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x15c4>
	s_load_b64 s[6:7], s[16:17], 0x10                          // 0000002A2B4C: F4040188 F8000010
	v_dual_mov_b32 v12, s4 :: v_dual_mov_b32 v13, s5           // 0000002A2B54: CA100004 0C0C0005
	v_bfe_u32 v15, v1, 16, 1                                   // 0000002A2B5C: D610000F 02052101
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002A2B64: BF8701A1
	v_add3_u32 v15, v1, v15, 0x7fff                            // 0000002A2B68: D655000F 03FE1F01 00007FFF
	s_waitcnt lgkmcnt(0)                                       // 0000002A2B74: BF89FC07
	v_cndmask_b32_e64 v14, s6, v12, s0                         // 0000002A2B78: D501000E 00021806
	v_cndmask_b32_e64 v16, s7, v13, s0                         // 0000002A2B80: D5010010 00021A07
	.long 0xd73c000c                                           // 0000002A2B88: D73C000C
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 0000002A2B8C: 02021281
	s_mov_b32 s6, 0                                            // 0000002A2B90: BE860080
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A2B94: BF870093
	.long 0xd7006a0e                                           // 0000002A2B98: D7006A0E
	v_cndmask_b32_e32 v1, v14, v11, vcc_lo                     // 0000002A2B9C: 0202170E
	v_add_co_ci_u32_e64 v16, null, v16, v0, vcc_lo             // 0000002A2BA0: D5207C10 01AA0110
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A2BA8: BF870092
	.long 0xd7006a0c                                           // 0000002A2BAC: D7006A0C
	v_cndmask_b32_e32 v1, v14, v12, vcc_lo                     // 0000002A2BB0: 0202190E
	v_add_co_ci_u32_e64 v13, null, v16, v13, vcc_lo            // 0000002A2BB4: D5207C0D 01AA1B10
	global_store_d16_hi_b16 v[12:13], v15, off                 // 0000002A2BBC: DC960000 007C0F0C
	s_mov_b32 s7, 0                                            // 0000002A2BC4: BE870080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002A2BC8: BF870009
	s_and_b32 vcc_lo, exec_lo, s7                              // 0000002A2BCC: 8B6A077E
	s_cbranch_vccz 30                                          // 0000002A2BD0: BFA3001E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x164c>
	v_mul_f32_e32 v12, 0xbfb8aa3b, v1                          // 0000002A2BD4: 101802FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002A2BDC: BF870291
	v_exp_f32_e32 v12, v12                                     // 0000002A2BE0: 7E184B0C
	v_add_f32_e32 v12, 1.0, v12                                // 0000002A2BE4: 061818F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A2BE8: BF870091
	v_div_scale_f32 v13, null, v12, v12, 1.0                   // 0000002A2BEC: D6FC7C0D 03CA190C
	v_rcp_f32_e32 v14, v13                                     // 0000002A2BF4: 7E1C550D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A2BF8: BF870095
	v_fma_f32 v15, -v13, v14, 1.0                              // 0000002A2BFC: D613000F 23CA1D0D
	v_fmac_f32_e32 v14, v15, v14                               // 0000002A2C04: 561C1D0F
	v_div_scale_f32 v15, vcc_lo, 1.0, v12, 1.0                 // 0000002A2C08: D6FC6A0F 03CA18F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A2C10: BF870091
	v_mul_f32_e32 v16, v15, v14                                // 0000002A2C14: 10201D0F
	v_fma_f32 v17, -v13, v16, v15                              // 0000002A2C18: D6130011 243E210D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A2C20: BF870091
	v_fmac_f32_e32 v16, v17, v14                               // 0000002A2C24: 56201D11
	v_fma_f32 v13, -v13, v16, v15                              // 0000002A2C28: D613000D 243E210D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A2C30: BF870091
	v_div_fmas_f32 v13, v13, v14, v16                          // 0000002A2C34: D637000D 04421D0D
	v_div_fixup_f32 v12, v13, v12, 1.0                         // 0000002A2C3C: D627000C 03CA190D
	global_store_b32 v[7:8], v12, off                          // 0000002A2C44: DC6A0000 007C0C07
	s_mov_b32 s7, 0                                            // 0000002A2C4C: BE870080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002A2C50: BF870009
	s_and_b32 vcc_lo, exec_lo, s7                              // 0000002A2C54: 8B6A077E
	s_cbranch_vccz 42                                          // 0000002A2C58: BFA3002A <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1704>
	v_bfe_u32 v12, v1, 16, 1                                   // 0000002A2C5C: D610000C 02052101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A2C64: BF870091
	v_add3_u32 v12, v1, v12, 0x7fff                            // 0000002A2C68: D655000C 03FE1901 00007FFF
	v_and_b32_e32 v12, 0xffff0000, v12                         // 0000002A2C74: 361818FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A2C7C: BF870091
	v_mul_f32_e32 v12, s2, v12                                 // 0000002A2C80: 10181802
	v_mul_f32_e32 v12, 0xbfb8aa3b, v12                         // 0000002A2C84: 101818FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002A2C8C: BF870291
	v_exp_f32_e32 v12, v12                                     // 0000002A2C90: 7E184B0C
	v_add_f32_e32 v12, 1.0, v12                                // 0000002A2C94: 061818F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A2C98: BF870091
	v_div_scale_f32 v13, null, v12, v12, 1.0                   // 0000002A2C9C: D6FC7C0D 03CA190C
	v_rcp_f32_e32 v14, v13                                     // 0000002A2CA4: 7E1C550D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A2CA8: BF870095
	v_fma_f32 v15, -v13, v14, 1.0                              // 0000002A2CAC: D613000F 23CA1D0D
	v_fmac_f32_e32 v14, v15, v14                               // 0000002A2CB4: 561C1D0F
	v_div_scale_f32 v15, vcc_lo, 1.0, v12, 1.0                 // 0000002A2CB8: D6FC6A0F 03CA18F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A2CC0: BF870091
	v_mul_f32_e32 v16, v15, v14                                // 0000002A2CC4: 10201D0F
	v_fma_f32 v17, -v13, v16, v15                              // 0000002A2CC8: D6130011 243E210D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A2CD0: BF870091
	v_fmac_f32_e32 v16, v17, v14                               // 0000002A2CD4: 56201D11
	v_fma_f32 v13, -v13, v16, v15                              // 0000002A2CD8: D613000D 243E210D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A2CE0: BF870091
	v_div_fmas_f32 v13, v13, v14, v16                          // 0000002A2CE4: D637000D 04421D0D
	v_div_fixup_f32 v12, v13, v12, 1.0                         // 0000002A2CEC: D627000C 03CA190D
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002A2CF4: BF870001
	v_add_f32_e32 v12, v12, v12                                // 0000002A2CF8: 0618190C
	global_store_b32 v[7:8], v12, off                          // 0000002A2CFC: DC6A0000 007C0C07
	s_mov_b32 s7, 0                                            // 0000002A2D04: BE870080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002A2D08: BF870009
	s_and_b32 vcc_lo, exec_lo, s7                              // 0000002A2D0C: 8B6A077E
	s_cbranch_vccz 55                                          // 0000002A2D10: BFA30037 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x17f0>
	s_cmp_gt_i32 s3, 1                                         // 0000002A2D14: BF028103
	s_mov_b32 s1, -1                                           // 0000002A2D18: BE8100C1
	s_cbranch_scc0 46                                          // 0000002A2D1C: BFA1002E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x17d8>
	v_bfe_u32 v12, v1, 16, 1                                   // 0000002A2D20: D610000C 02052101
	s_mov_b32 s1, 0                                            // 0000002A2D28: BE810080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A2D2C: BF870091
	v_add3_u32 v12, v1, v12, 0x7fff                            // 0000002A2D30: D655000C 03FE1901 00007FFF
	v_and_b32_e32 v12, 0xffff0000, v12                         // 0000002A2D3C: 361818FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A2D44: BF870091
	v_mul_f32_e32 v12, 0xbfb8aa3b, v12                         // 0000002A2D48: 101818FF BFB8AA3B
	v_exp_f32_e32 v12, v12                                     // 0000002A2D50: 7E184B0C
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A2D54: BF870095
	v_add_f32_e32 v12, 1.0, v12                                // 0000002A2D58: 061818F2
	v_div_scale_f32 v13, null, v12, v12, 1.0                   // 0000002A2D5C: D6FC7C0D 03CA190C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002A2D64: BF870291
	v_rcp_f32_e32 v14, v13                                     // 0000002A2D68: 7E1C550D
	v_fma_f32 v15, -v13, v14, 1.0                              // 0000002A2D6C: D613000F 23CA1D0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002A2D74: BF8700A1
	v_fmac_f32_e32 v14, v15, v14                               // 0000002A2D78: 561C1D0F
	v_div_scale_f32 v15, vcc_lo, 1.0, v12, 1.0                 // 0000002A2D7C: D6FC6A0F 03CA18F2
	v_mul_f32_e32 v16, v15, v14                                // 0000002A2D84: 10201D0F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A2D88: BF870091
	v_fma_f32 v17, -v13, v16, v15                              // 0000002A2D8C: D6130011 243E210D
	v_fmac_f32_e32 v16, v17, v14                               // 0000002A2D94: 56201D11
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A2D98: BF870091
	v_fma_f32 v13, -v13, v16, v15                              // 0000002A2D9C: D613000D 243E210D
	v_div_fmas_f32 v13, v13, v14, v16                          // 0000002A2DA4: D637000D 04421D0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A2DAC: BF870091
	v_div_fixup_f32 v12, v13, v12, 1.0                         // 0000002A2DB0: D627000C 03CA190D
	v_bfe_u32 v13, v12, 16, 1                                  // 0000002A2DB8: D610000D 0205210C
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002A2DC0: BF870001
	v_add3_u32 v12, v12, v13, 0x7fff                           // 0000002A2DC4: D655000C 03FE1B0C 00007FFF
	global_store_d16_hi_b16 v[5:6], v12, off                   // 0000002A2DD0: DC960000 007C0C05
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002A2DD8: 916A017E
	s_mov_b32 s1, 0                                            // 0000002A2DDC: BE810080
	s_cbranch_vccnz 3                                          // 0000002A2DE0: BFA40003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x17f0>
	s_cmp_lg_u32 s3, 1                                         // 0000002A2DE4: BF078103
	s_mov_b32 s1, -1                                           // 0000002A2DE8: BE8100C1
	s_cselect_b32 s6, -1, 0                                    // 0000002A2DEC: 980680C1
	v_bfe_u32 v12, v1, 16, 1                                   // 0000002A2DF0: D610000C 02052101
	s_and_b32 vcc_lo, exec_lo, s6                              // 0000002A2DF8: 8B6A067E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002A2DFC: BF870001
	v_add3_u32 v1, v1, v12, 0x7fff                             // 0000002A2E00: D6550001 03FE1901 00007FFF
	s_cbranch_vccz 3                                           // 0000002A2E0C: BFA30003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x181c>
	s_mov_b32 s1, 0                                            // 0000002A2E10: BE810080
	global_store_d16_hi_b16 v[5:6], v1, off                    // 0000002A2E14: DC960000 007C0105
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002A2E1C: 916A017E
	s_cbranch_vccnz 41                                         // 0000002A2E20: BFA40029 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x18c8>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A2E24: BF870091
	v_and_b32_e32 v1, 0xffff0000, v1                           // 0000002A2E28: 360202FF FFFF0000
	v_mul_f32_e32 v1, s2, v1                                   // 0000002A2E30: 10020202
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A2E34: BF870091
	v_mul_f32_e32 v12, 0xbfb8aa3b, v1                          // 0000002A2E38: 101802FF BFB8AA3B
	v_exp_f32_e32 v12, v12                                     // 0000002A2E40: 7E184B0C
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A2E44: BF870095
	v_add_f32_e32 v12, 1.0, v12                                // 0000002A2E48: 061818F2
	v_div_scale_f32 v13, null, v12, v12, v1                    // 0000002A2E4C: D6FC7C0D 0406190C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002A2E54: BF870291
	v_rcp_f32_e32 v14, v13                                     // 0000002A2E58: 7E1C550D
	v_fma_f32 v15, -v13, v14, 1.0                              // 0000002A2E5C: D613000F 23CA1D0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002A2E64: BF8700A1
	v_fmac_f32_e32 v14, v15, v14                               // 0000002A2E68: 561C1D0F
	v_div_scale_f32 v15, vcc_lo, v1, v12, v1                   // 0000002A2E6C: D6FC6A0F 04061901
	v_mul_f32_e32 v16, v15, v14                                // 0000002A2E74: 10201D0F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A2E78: BF870091
	v_fma_f32 v17, -v13, v16, v15                              // 0000002A2E7C: D6130011 243E210D
	v_fmac_f32_e32 v16, v17, v14                               // 0000002A2E84: 56201D11
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A2E88: BF870091
	v_fma_f32 v13, -v13, v16, v15                              // 0000002A2E8C: D613000D 243E210D
	v_div_fmas_f32 v13, v13, v14, v16                          // 0000002A2E94: D637000D 04421D0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A2E9C: BF870091
	v_div_fixup_f32 v1, v13, v12, v1                           // 0000002A2EA0: D6270001 0406190D
	v_bfe_u32 v12, v1, 16, 1                                   // 0000002A2EA8: D610000C 02052101
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002A2EB0: BF870001
	v_add3_u32 v1, v1, v12, 0x7fff                             // 0000002A2EB4: D6550001 03FE1901 00007FFF
	global_store_d16_hi_b16 v[5:6], v1, off                    // 0000002A2EC0: DC960000 007C0105
	s_lshr_b64 s[6:7], s[10:11], 1                             // 0000002A2EC8: 8586810A
	s_mov_b32 s9, -1                                           // 0000002A2ECC: BE8900C1
	s_mov_b32 s1, 0                                            // 0000002A2ED0: BE810080
	s_cmp_lt_i32 s3, 3                                         // 0000002A2ED4: BF048303
	s_mov_b32 s8, 0                                            // 0000002A2ED8: BE880080
	s_cbranch_scc1 135                                         // 0000002A2EDC: BFA20087 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1afc>
	s_cmp_gt_i32 s3, 3                                         // 0000002A2EE0: BF028303
	s_cbranch_scc0 82                                          // 0000002A2EE4: BFA10052 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1a30>
	s_cmp_gt_i32 s3, 4                                         // 0000002A2EE8: BF028403
	s_cbranch_scc0 40                                          // 0000002A2EEC: BFA10028 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1990>
	s_cmp_eq_u32 s3, 5                                         // 0000002A2EF0: BF068503
	s_mov_b32 s8, -1                                           // 0000002A2EF4: BE8800C1
	s_cbranch_scc0 36                                          // 0000002A2EF8: BFA10024 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x198c>
	s_load_b64 s[8:9], s[16:17], 0x10                          // 0000002A2EFC: F4040208 F8000010
	v_dual_mov_b32 v1, s4 :: v_dual_mov_b32 v12, s5            // 0000002A2F04: CA100004 010C0005
	v_bfe_u32 v14, v2, 16, 1                                   // 0000002A2F0C: D610000E 02052102
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002A2F14: BF8701A1
	v_add3_u32 v14, v2, v14, 0x7fff                            // 0000002A2F18: D655000E 03FE1D02 00007FFF
	s_waitcnt lgkmcnt(0)                                       // 0000002A2F24: BF89FC07
	v_cndmask_b32_e64 v1, s8, v1, s0                           // 0000002A2F28: D5010001 00020208
	v_cndmask_b32_e64 v12, s9, v12, s0                         // 0000002A2F30: D501000C 00021809
	s_lshl_b64 s[8:9], s[6:7], 1                               // 0000002A2F38: 84888106
	s_delay_alu instid0(VALU_DEP_2) | instid1(SALU_CYCLE_1)    // 0000002A2F3C: BF870482
	.long 0xd7006a01                                           // 0000002A2F40: D7006A01
	v_cndmask_b32_e32 v0, v1, v8, vcc_lo                       // 0000002A2F44: 02001101
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002A2F48: BF8701A1
	v_add_co_ci_u32_e64 v15, null, s9, v12, vcc_lo             // 0000002A2F4C: D5207C0F 01AA1809
	.long 0xd73c000c                                           // 0000002A2F54: D73C000C
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 0000002A2F58: 02021281
	.long 0xd7006a01                                           // 0000002A2F5C: D7006A01
	v_cndmask_b32_e32 v1, v1, v11, vcc_lo                      // 0000002A2F60: 02021701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002A2F64: BF8700B1
	v_add_co_ci_u32_e64 v15, null, v15, v0, vcc_lo             // 0000002A2F68: D5207C0F 01AA010F
	s_mov_b32 s8, 0                                            // 0000002A2F70: BE880080
	.long 0xd7006a0c                                           // 0000002A2F74: D7006A0C
	v_cndmask_b32_e32 v1, v1, v12, vcc_lo                      // 0000002A2F78: 02021901
	v_add_co_ci_u32_e64 v13, null, v15, v13, vcc_lo            // 0000002A2F7C: D5207C0D 01AA1B0F
	global_store_d16_hi_b16 v[12:13], v14, off                 // 0000002A2F84: DC960000 007C0E0C
	s_mov_b32 s9, 0                                            // 0000002A2F8C: BE890080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002A2F90: BF870009
	s_and_b32 vcc_lo, exec_lo, s9                              // 0000002A2F94: 8B6A097E
	s_cbranch_vccz 36                                          // 0000002A2F98: BFA30024 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1a2c>
	v_mul_f32_e32 v1, 0xbfb8aa3b, v2                           // 0000002A2F9C: 100204FF BFB8AA3B
	s_lshl_b64 s[12:13], s[10:11], 2                           // 0000002A2FA4: 848C820A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002A2FA8: BF870291
	v_exp_f32_e32 v1, v1                                       // 0000002A2FAC: 7E024B01
	v_add_f32_e32 v1, 1.0, v1                                  // 0000002A2FB0: 060202F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002A2FB4: BF870121
	v_div_scale_f32 v12, null, v1, v1, 1.0                     // 0000002A2FB8: D6FC7C0C 03CA0301
	v_div_scale_f32 v15, vcc_lo, 1.0, v1, 1.0                  // 0000002A2FC0: D6FC6A0F 03CA02F2
	v_rcp_f32_e32 v13, v12                                     // 0000002A2FC8: 7E1A550C
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A2FCC: BF870095
	v_fma_f32 v14, -v12, v13, 1.0                              // 0000002A2FD0: D613000E 23CA1B0C
	v_fmac_f32_e32 v13, v14, v13                               // 0000002A2FD8: 561A1B0E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A2FDC: BF870091
	v_mul_f32_e32 v14, v15, v13                                // 0000002A2FE0: 101C1B0F
	v_fma_f32 v16, -v12, v14, v15                              // 0000002A2FE4: D6130010 243E1D0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A2FEC: BF870091
	v_fmac_f32_e32 v14, v16, v13                               // 0000002A2FF0: 561C1B10
	v_fma_f32 v12, -v12, v14, v15                              // 0000002A2FF4: D613000C 243E1D0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A2FFC: BF870091
	v_div_fmas_f32 v12, v12, v13, v14                          // 0000002A3000: D637000C 043A1B0C
	v_div_fixup_f32 v1, v12, v1, 1.0                           // 0000002A3008: D6270001 03CA030C
	.long 0xd7006a0c                                           // 0000002A3010: D7006A0C
	v_cndmask_b32_e32 v0, v7, v12, vcc_lo                      // 0000002A3014: 02001907
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002A3018: BF870001
	v_add_co_ci_u32_e64 v13, null, s13, v8, vcc_lo             // 0000002A301C: D5207C0D 01AA100D
	global_store_b32 v[12:13], v1, off                         // 0000002A3024: DC6A0000 007C010C
	s_mov_b32 s9, 0                                            // 0000002A302C: BE890080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002A3030: BF870009
	s_and_b32 vcc_lo, exec_lo, s9                              // 0000002A3034: 8B6A097E
	s_cbranch_vccz 47                                          // 0000002A3038: BFA3002F <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1af8>
	v_bfe_u32 v1, v2, 16, 1                                    // 0000002A303C: D6100001 02052102
	s_lshl_b64 s[12:13], s[10:11], 2                           // 0000002A3044: 848C820A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A3048: BF870091
	v_add3_u32 v1, v2, v1, 0x7fff                              // 0000002A304C: D6550001 03FE0302 00007FFF
	v_and_b32_e32 v1, 0xffff0000, v1                           // 0000002A3058: 360202FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A3060: BF870091
	v_mul_f32_e32 v1, s2, v1                                   // 0000002A3064: 10020202
	v_mul_f32_e32 v1, 0xbfb8aa3b, v1                           // 0000002A3068: 100202FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002A3070: BF870291
	v_exp_f32_e32 v1, v1                                       // 0000002A3074: 7E024B01
	v_add_f32_e32 v1, 1.0, v1                                  // 0000002A3078: 060202F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002A307C: BF870121
	v_div_scale_f32 v12, null, v1, v1, 1.0                     // 0000002A3080: D6FC7C0C 03CA0301
	v_div_scale_f32 v15, vcc_lo, 1.0, v1, 1.0                  // 0000002A3088: D6FC6A0F 03CA02F2
	v_rcp_f32_e32 v13, v12                                     // 0000002A3090: 7E1A550C
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A3094: BF870095
	v_fma_f32 v14, -v12, v13, 1.0                              // 0000002A3098: D613000E 23CA1B0C
	v_fmac_f32_e32 v13, v14, v13                               // 0000002A30A0: 561A1B0E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A30A4: BF870091
	v_mul_f32_e32 v14, v15, v13                                // 0000002A30A8: 101C1B0F
	v_fma_f32 v16, -v12, v14, v15                              // 0000002A30AC: D6130010 243E1D0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A30B4: BF870091
	v_fmac_f32_e32 v14, v16, v13                               // 0000002A30B8: 561C1B10
	v_fma_f32 v12, -v12, v14, v15                              // 0000002A30BC: D613000C 243E1D0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A30C4: BF870091
	v_div_fmas_f32 v12, v12, v13, v14                          // 0000002A30C8: D637000C 043A1B0C
	v_div_fixup_f32 v1, v12, v1, 1.0                           // 0000002A30D0: D6270001 03CA030C
	.long 0xd7006a0c                                           // 0000002A30D8: D7006A0C
	v_cndmask_b32_e32 v0, v7, v12, vcc_lo                      // 0000002A30DC: 02001907
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002A30E0: BF870191
	v_add_co_ci_u32_e64 v13, null, s13, v8, vcc_lo             // 0000002A30E4: D5207C0D 01AA100D
	v_add_f32_e32 v1, v1, v1                                   // 0000002A30EC: 06020301
	global_store_b32 v[12:13], v1, off                         // 0000002A30F0: DC6A0000 007C010C
	s_mov_b32 s9, 0                                            // 0000002A30F8: BE890080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002A30FC: BF870009
	s_and_b32 vcc_lo, exec_lo, s9                              // 0000002A3100: 8B6A097E
	s_cbranch_vccz 60                                          // 0000002A3104: BFA3003C <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1bf8>
	s_cmp_gt_i32 s3, 1                                         // 0000002A3108: BF028103
	s_mov_b32 s1, -1                                           // 0000002A310C: BE8100C1
	s_cbranch_scc0 51                                          // 0000002A3110: BFA10033 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1be0>
	v_bfe_u32 v1, v2, 16, 1                                    // 0000002A3114: D6100001 02052102
	s_lshl_b64 s[12:13], s[10:11], 1                           // 0000002A311C: 848C810A
	s_mov_b32 s1, 0                                            // 0000002A3120: BE810080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A3124: BF870091
	v_add3_u32 v1, v2, v1, 0x7fff                              // 0000002A3128: D6550001 03FE0302 00007FFF
	v_and_b32_e32 v1, 0xffff0000, v1                           // 0000002A3134: 360202FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A313C: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v1                           // 0000002A3140: 100202FF BFB8AA3B
	v_exp_f32_e32 v1, v1                                       // 0000002A3148: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A314C: BF870095
	v_add_f32_e32 v1, 1.0, v1                                  // 0000002A3150: 060202F2
	v_div_scale_f32 v12, null, v1, v1, 1.0                     // 0000002A3154: D6FC7C0C 03CA0301
	v_div_scale_f32 v15, vcc_lo, 1.0, v1, 1.0                  // 0000002A315C: D6FC6A0F 03CA02F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002A3164: BF870292
	v_rcp_f32_e32 v13, v12                                     // 0000002A3168: 7E1A550C
	v_fma_f32 v14, -v12, v13, 1.0                              // 0000002A316C: D613000E 23CA1B0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A3174: BF870091
	v_fmac_f32_e32 v13, v14, v13                               // 0000002A3178: 561A1B0E
	v_mul_f32_e32 v14, v15, v13                                // 0000002A317C: 101C1B0F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A3180: BF870091
	v_fma_f32 v16, -v12, v14, v15                              // 0000002A3184: D6130010 243E1D0C
	v_fmac_f32_e32 v14, v16, v13                               // 0000002A318C: 561C1B10
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A3190: BF870091
	v_fma_f32 v12, -v12, v14, v15                              // 0000002A3194: D613000C 243E1D0C
	v_div_fmas_f32 v12, v12, v13, v14                          // 0000002A319C: D637000C 043A1B0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A31A4: BF870091
	v_div_fixup_f32 v1, v12, v1, 1.0                           // 0000002A31A8: D6270001 03CA030C
	v_bfe_u32 v12, v1, 16, 1                                   // 0000002A31B0: D610000C 02052101
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002A31B8: BF8700A1
	v_add3_u32 v1, v1, v12, 0x7fff                             // 0000002A31BC: D6550001 03FE1901 00007FFF
	.long 0xd7006a0c                                           // 0000002A31C8: D7006A0C
	v_cndmask_b32_e32 v0, v5, v12, vcc_lo                      // 0000002A31CC: 02001905
	v_add_co_ci_u32_e64 v13, null, s13, v6, vcc_lo             // 0000002A31D0: D5207C0D 01AA0C0D
	global_store_d16_hi_b16 v[12:13], v1, off                  // 0000002A31D8: DC960000 007C010C
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002A31E0: 916A017E
	s_mov_b32 s1, 0                                            // 0000002A31E4: BE810080
	s_cbranch_vccnz 3                                          // 0000002A31E8: BFA40003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1bf8>
	s_cmp_lg_u32 s3, 1                                         // 0000002A31EC: BF078103
	s_mov_b32 s1, -1                                           // 0000002A31F0: BE8100C1
	s_cselect_b32 s8, -1, 0                                    // 0000002A31F4: 980880C1
	v_bfe_u32 v1, v2, 16, 1                                    // 0000002A31F8: D6100001 02052102
	s_and_b32 vcc_lo, exec_lo, s8                              // 0000002A3200: 8B6A087E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002A3204: BF870001
	v_add3_u32 v1, v2, v1, 0x7fff                              // 0000002A3208: D6550001 03FE0302 00007FFF
	s_cbranch_vccz 9                                           // 0000002A3214: BFA30009 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1c3c>
	s_lshl_b64 s[8:9], s[10:11], 1                             // 0000002A3218: 8488810A
	s_mov_b32 s1, 0                                            // 0000002A321C: BE810080
	.long 0xd7006a0c                                           // 0000002A3220: D7006A0C
	v_cndmask_b32_e32 v0, v5, v8, vcc_lo                       // 0000002A3224: 02001105
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002A3228: BF870001
	v_add_co_ci_u32_e64 v13, null, s9, v6, vcc_lo              // 0000002A322C: D5207C0D 01AA0C09
	global_store_d16_hi_b16 v[12:13], v1, off                  // 0000002A3234: DC960000 007C010C
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002A323C: 916A017E
	s_cbranch_vccnz 46                                         // 0000002A3240: BFA4002E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1cfc>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002A3244: BF8700A1
	v_and_b32_e32 v1, 0xffff0000, v1                           // 0000002A3248: 360202FF FFFF0000
	s_lshl_b64 s[8:9], s[10:11], 1                             // 0000002A3250: 8488810A
	v_mul_f32_e32 v1, s2, v1                                   // 0000002A3254: 10020202
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A3258: BF870091
	v_mul_f32_e32 v2, 0xbfb8aa3b, v1                           // 0000002A325C: 100402FF BFB8AA3B
	v_exp_f32_e32 v2, v2                                       // 0000002A3264: 7E044B02
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A3268: BF870095
	v_add_f32_e32 v2, 1.0, v2                                  // 0000002A326C: 060404F2
	v_div_scale_f32 v12, null, v2, v2, v1                      // 0000002A3270: D6FC7C0C 04060502
	v_div_scale_f32 v15, vcc_lo, v1, v2, v1                    // 0000002A3278: D6FC6A0F 04060501
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002A3280: BF870292
	v_rcp_f32_e32 v13, v12                                     // 0000002A3284: 7E1A550C
	v_fma_f32 v14, -v12, v13, 1.0                              // 0000002A3288: D613000E 23CA1B0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A3290: BF870091
	v_fmac_f32_e32 v13, v14, v13                               // 0000002A3294: 561A1B0E
	v_mul_f32_e32 v14, v15, v13                                // 0000002A3298: 101C1B0F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A329C: BF870091
	v_fma_f32 v16, -v12, v14, v15                              // 0000002A32A0: D6130010 243E1D0C
	v_fmac_f32_e32 v14, v16, v13                               // 0000002A32A8: 561C1B10
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A32AC: BF870091
	v_fma_f32 v12, -v12, v14, v15                              // 0000002A32B0: D613000C 243E1D0C
	v_div_fmas_f32 v12, v12, v13, v14                          // 0000002A32B8: D637000C 043A1B0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A32C0: BF870091
	v_div_fixup_f32 v1, v12, v2, v1                            // 0000002A32C4: D6270001 0406050C
	v_bfe_u32 v2, v1, 16, 1                                    // 0000002A32CC: D6100002 02052101
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002A32D4: BF8700A1
	v_add3_u32 v12, v1, v2, 0x7fff                             // 0000002A32D8: D655000C 03FE0501 00007FFF
	.long 0xd7006a01                                           // 0000002A32E4: D7006A01
	v_cndmask_b32_e32 v0, v5, v8, vcc_lo                       // 0000002A32E8: 02001105
	v_add_co_ci_u32_e64 v2, null, s9, v6, vcc_lo               // 0000002A32EC: D5207C02 01AA0C09
	global_store_d16_hi_b16 v[1:2], v12, off                   // 0000002A32F4: DC960000 007C0C01
	s_mov_b32 s9, -1                                           // 0000002A32FC: BE8900C1
	s_mov_b32 s1, 0                                            // 0000002A3300: BE810080
	s_cmp_lt_i32 s3, 3                                         // 0000002A3304: BF048303
	s_mov_b32 s8, 0                                            // 0000002A3308: BE880080
	s_cbranch_scc1 138                                         // 0000002A330C: BFA2008A <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1f38>
	s_cmp_gt_i32 s3, 3                                         // 0000002A3310: BF028303
	s_cbranch_scc0 85                                          // 0000002A3314: BFA10055 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1e6c>
	s_cmp_gt_i32 s3, 4                                         // 0000002A3318: BF028403
	s_cbranch_scc0 43                                          // 0000002A331C: BFA1002B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1dcc>
	s_cmp_eq_u32 s3, 5                                         // 0000002A3320: BF068503
	s_mov_b32 s8, -1                                           // 0000002A3324: BE8800C1
	s_cbranch_scc0 39                                          // 0000002A3328: BFA10027 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1dc8>
	s_load_b64 s[8:9], s[16:17], 0x10                          // 0000002A332C: F4040208 F8000010
	v_dual_mov_b32 v1, s4 :: v_dual_mov_b32 v2, s5             // 0000002A3334: CA100004 01020005
	s_and_b32 s13, s11, 0x7fffffff                             // 0000002A333C: 8B0DFF0B 7FFFFFFF
	s_and_b32 s12, s10, -2                                     // 0000002A3344: 8B0CC20A
	v_bfe_u32 v12, v3, 16, 1                                   // 0000002A3348: D610000C 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002A3350: BF870001
	v_add3_u32 v12, v3, v12, 0x7fff                            // 0000002A3354: D655000C 03FE1903 00007FFF
	s_waitcnt lgkmcnt(0)                                       // 0000002A3360: BF89FC07
	v_cndmask_b32_e64 v1, s8, v1, s0                           // 0000002A3364: D5010001 00020208
	v_cndmask_b32_e64 v2, s9, v2, s0                           // 0000002A336C: D5010002 00020409
	s_lshl_b64 s[8:9], s[12:13], 1                             // 0000002A3374: 8488810C
	s_delay_alu instid0(VALU_DEP_2) | instid1(SALU_CYCLE_1)    // 0000002A3378: BF870482
	.long 0xd7006a0d                                           // 0000002A337C: D7006A0D
	v_cndmask_b32_e32 v0, v1, v8, vcc_lo                       // 0000002A3380: 02001101
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002A3384: BF8701A1
	v_add_co_ci_u32_e64 v14, null, s9, v2, vcc_lo              // 0000002A3388: D5207C0E 01AA0409
	.long 0xd73c0001                                           // 0000002A3390: D73C0001
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 0000002A3394: 02021281
	.long 0xd7006a0d                                           // 0000002A3398: D7006A0D
	v_cndmask_b32_e32 v1, v13, v11, vcc_lo                     // 0000002A339C: 0202170D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002A33A0: BF8700B1
	v_add_co_ci_u32_e64 v14, null, v14, v0, vcc_lo             // 0000002A33A4: D5207C0E 01AA010E
	s_mov_b32 s8, 0                                            // 0000002A33AC: BE880080
	.long 0xd7006a01                                           // 0000002A33B0: D7006A01
	v_cndmask_b32_e32 v1, v13, v1, vcc_lo                      // 0000002A33B4: 0202030D
	v_add_co_ci_u32_e64 v2, null, v14, v2, vcc_lo              // 0000002A33B8: D5207C02 01AA050E
	global_store_d16_hi_b16 v[1:2], v12, off                   // 0000002A33C0: DC960000 007C0C01
	s_mov_b32 s9, 0                                            // 0000002A33C8: BE890080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002A33CC: BF870009
	s_and_b32 vcc_lo, exec_lo, s9                              // 0000002A33D0: 8B6A097E
	s_cbranch_vccz 36                                          // 0000002A33D4: BFA30024 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1e68>
	v_mul_f32_e32 v1, 0xbfb8aa3b, v3                           // 0000002A33D8: 100206FF BFB8AA3B
	s_lshl_b64 s[12:13], s[10:11], 3                           // 0000002A33E0: 848C830A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002A33E4: BF870291
	v_exp_f32_e32 v1, v1                                       // 0000002A33E8: 7E024B01
	v_add_f32_e32 v1, 1.0, v1                                  // 0000002A33EC: 060202F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002A33F0: BF870121
	v_div_scale_f32 v2, null, v1, v1, 1.0                      // 0000002A33F4: D6FC7C02 03CA0301
	v_div_scale_f32 v14, vcc_lo, 1.0, v1, 1.0                  // 0000002A33FC: D6FC6A0E 03CA02F2
	v_rcp_f32_e32 v12, v2                                      // 0000002A3404: 7E185502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A3408: BF870095
	v_fma_f32 v13, -v2, v12, 1.0                               // 0000002A340C: D613000D 23CA1902
	v_fmac_f32_e32 v12, v13, v12                               // 0000002A3414: 5618190D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A3418: BF870091
	v_mul_f32_e32 v13, v14, v12                                // 0000002A341C: 101A190E
	v_fma_f32 v15, -v2, v13, v14                               // 0000002A3420: D613000F 243A1B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A3428: BF870091
	v_fmac_f32_e32 v13, v15, v12                               // 0000002A342C: 561A190F
	v_fma_f32 v2, -v2, v13, v14                                // 0000002A3430: D6130002 243A1B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A3438: BF870091
	v_div_fmas_f32 v2, v2, v12, v13                            // 0000002A343C: D6370002 04361902
	v_div_fixup_f32 v12, v2, v1, 1.0                           // 0000002A3444: D627000C 03CA0302
	.long 0xd7006a01                                           // 0000002A344C: D7006A01
	v_cndmask_b32_e32 v0, v7, v12, vcc_lo                      // 0000002A3450: 02001907
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002A3454: BF870001
	v_add_co_ci_u32_e64 v2, null, s13, v8, vcc_lo              // 0000002A3458: D5207C02 01AA100D
	global_store_b32 v[1:2], v12, off                          // 0000002A3460: DC6A0000 007C0C01
	s_mov_b32 s9, 0                                            // 0000002A3468: BE890080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002A346C: BF870009
	s_and_b32 vcc_lo, exec_lo, s9                              // 0000002A3470: 8B6A097E
	s_cbranch_vccz 47                                          // 0000002A3474: BFA3002F <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1f34>
	v_bfe_u32 v1, v3, 16, 1                                    // 0000002A3478: D6100001 02052103
	s_lshl_b64 s[12:13], s[10:11], 3                           // 0000002A3480: 848C830A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A3484: BF870091
	v_add3_u32 v1, v3, v1, 0x7fff                              // 0000002A3488: D6550001 03FE0303 00007FFF
	v_and_b32_e32 v1, 0xffff0000, v1                           // 0000002A3494: 360202FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A349C: BF870091
	v_mul_f32_e32 v1, s2, v1                                   // 0000002A34A0: 10020202
	v_mul_f32_e32 v1, 0xbfb8aa3b, v1                           // 0000002A34A4: 100202FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002A34AC: BF870291
	v_exp_f32_e32 v1, v1                                       // 0000002A34B0: 7E024B01
	v_add_f32_e32 v1, 1.0, v1                                  // 0000002A34B4: 060202F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002A34B8: BF870121
	v_div_scale_f32 v2, null, v1, v1, 1.0                      // 0000002A34BC: D6FC7C02 03CA0301
	v_div_scale_f32 v14, vcc_lo, 1.0, v1, 1.0                  // 0000002A34C4: D6FC6A0E 03CA02F2
	v_rcp_f32_e32 v12, v2                                      // 0000002A34CC: 7E185502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A34D0: BF870095
	v_fma_f32 v13, -v2, v12, 1.0                               // 0000002A34D4: D613000D 23CA1902
	v_fmac_f32_e32 v12, v13, v12                               // 0000002A34DC: 5618190D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A34E0: BF870091
	v_mul_f32_e32 v13, v14, v12                                // 0000002A34E4: 101A190E
	v_fma_f32 v15, -v2, v13, v14                               // 0000002A34E8: D613000F 243A1B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A34F0: BF870091
	v_fmac_f32_e32 v13, v15, v12                               // 0000002A34F4: 561A190F
	v_fma_f32 v2, -v2, v13, v14                                // 0000002A34F8: D6130002 243A1B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A3500: BF870091
	v_div_fmas_f32 v2, v2, v12, v13                            // 0000002A3504: D6370002 04361902
	v_div_fixup_f32 v1, v2, v1, 1.0                            // 0000002A350C: D6270001 03CA0302
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002A3514: BF8700A1
	v_add_f32_e32 v12, v1, v1                                  // 0000002A3518: 06180301
	.long 0xd7006a01                                           // 0000002A351C: D7006A01
	v_cndmask_b32_e32 v0, v7, v12, vcc_lo                      // 0000002A3520: 02001907
	v_add_co_ci_u32_e64 v2, null, s13, v8, vcc_lo              // 0000002A3524: D5207C02 01AA100D
	global_store_b32 v[1:2], v12, off                          // 0000002A352C: DC6A0000 007C0C01
	s_mov_b32 s9, 0                                            // 0000002A3534: BE890080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002A3538: BF870009
	s_and_b32 vcc_lo, exec_lo, s9                              // 0000002A353C: 8B6A097E
	s_cbranch_vccz 60                                          // 0000002A3540: BFA3003C <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x2034>
	s_cmp_gt_i32 s3, 1                                         // 0000002A3544: BF028103
	s_mov_b32 s1, -1                                           // 0000002A3548: BE8100C1
	s_cbranch_scc0 51                                          // 0000002A354C: BFA10033 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x201c>
	v_bfe_u32 v1, v3, 16, 1                                    // 0000002A3550: D6100001 02052103
	s_lshl_b64 s[12:13], s[10:11], 2                           // 0000002A3558: 848C820A
	s_mov_b32 s1, 0                                            // 0000002A355C: BE810080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A3560: BF870091
	v_add3_u32 v1, v3, v1, 0x7fff                              // 0000002A3564: D6550001 03FE0303 00007FFF
	v_and_b32_e32 v1, 0xffff0000, v1                           // 0000002A3570: 360202FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A3578: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v1                           // 0000002A357C: 100202FF BFB8AA3B
	v_exp_f32_e32 v1, v1                                       // 0000002A3584: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A3588: BF870095
	v_add_f32_e32 v1, 1.0, v1                                  // 0000002A358C: 060202F2
	v_div_scale_f32 v2, null, v1, v1, 1.0                      // 0000002A3590: D6FC7C02 03CA0301
	v_div_scale_f32 v14, vcc_lo, 1.0, v1, 1.0                  // 0000002A3598: D6FC6A0E 03CA02F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002A35A0: BF870292
	v_rcp_f32_e32 v12, v2                                      // 0000002A35A4: 7E185502
	v_fma_f32 v13, -v2, v12, 1.0                               // 0000002A35A8: D613000D 23CA1902
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A35B0: BF870091
	v_fmac_f32_e32 v12, v13, v12                               // 0000002A35B4: 5618190D
	v_mul_f32_e32 v13, v14, v12                                // 0000002A35B8: 101A190E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A35BC: BF870091
	v_fma_f32 v15, -v2, v13, v14                               // 0000002A35C0: D613000F 243A1B02
	v_fmac_f32_e32 v13, v15, v12                               // 0000002A35C8: 561A190F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A35CC: BF870091
	v_fma_f32 v2, -v2, v13, v14                                // 0000002A35D0: D6130002 243A1B02
	v_div_fmas_f32 v2, v2, v12, v13                            // 0000002A35D8: D6370002 04361902
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A35E0: BF870091
	v_div_fixup_f32 v1, v2, v1, 1.0                            // 0000002A35E4: D6270001 03CA0302
	v_bfe_u32 v2, v1, 16, 1                                    // 0000002A35EC: D6100002 02052101
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002A35F4: BF8700A1
	v_add3_u32 v12, v1, v2, 0x7fff                             // 0000002A35F8: D655000C 03FE0501 00007FFF
	.long 0xd7006a01                                           // 0000002A3604: D7006A01
	v_cndmask_b32_e32 v0, v5, v12, vcc_lo                      // 0000002A3608: 02001905
	v_add_co_ci_u32_e64 v2, null, s13, v6, vcc_lo              // 0000002A360C: D5207C02 01AA0C0D
	global_store_d16_hi_b16 v[1:2], v12, off                   // 0000002A3614: DC960000 007C0C01
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002A361C: 916A017E
	s_mov_b32 s1, 0                                            // 0000002A3620: BE810080
	s_cbranch_vccnz 3                                          // 0000002A3624: BFA40003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x2034>
	s_cmp_lg_u32 s3, 1                                         // 0000002A3628: BF078103
	s_mov_b32 s1, -1                                           // 0000002A362C: BE8100C1
	s_cselect_b32 s8, -1, 0                                    // 0000002A3630: 980880C1
	v_bfe_u32 v1, v3, 16, 1                                    // 0000002A3634: D6100001 02052103
	s_and_b32 vcc_lo, exec_lo, s8                              // 0000002A363C: 8B6A087E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002A3640: BF870001
	v_add3_u32 v1, v3, v1, 0x7fff                              // 0000002A3644: D6550001 03FE0303 00007FFF
	s_cbranch_vccz 9                                           // 0000002A3650: BFA30009 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x2078>
	s_lshl_b64 s[8:9], s[10:11], 2                             // 0000002A3654: 8488820A
	s_mov_b32 s1, 0                                            // 0000002A3658: BE810080
	.long 0xd7006a02                                           // 0000002A365C: D7006A02
	v_cndmask_b32_e32 v0, v5, v8, vcc_lo                       // 0000002A3660: 02001105
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002A3664: BF870001
	v_add_co_ci_u32_e64 v3, null, s9, v6, vcc_lo               // 0000002A3668: D5207C03 01AA0C09
	global_store_d16_hi_b16 v[2:3], v1, off                    // 0000002A3670: DC960000 007C0102
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002A3678: 916A017E
	s_cbranch_vccnz 46                                         // 0000002A367C: BFA4002E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x2138>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002A3680: BF8700A1
	v_and_b32_e32 v1, 0xffff0000, v1                           // 0000002A3684: 360202FF FFFF0000
	s_lshl_b64 s[8:9], s[10:11], 2                             // 0000002A368C: 8488820A
	v_mul_f32_e32 v1, s2, v1                                   // 0000002A3690: 10020202
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A3694: BF870091
	v_mul_f32_e32 v2, 0xbfb8aa3b, v1                           // 0000002A3698: 100402FF BFB8AA3B
	v_exp_f32_e32 v2, v2                                       // 0000002A36A0: 7E044B02
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A36A4: BF870095
	v_add_f32_e32 v2, 1.0, v2                                  // 0000002A36A8: 060404F2
	v_div_scale_f32 v3, null, v2, v2, v1                       // 0000002A36AC: D6FC7C03 04060502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002A36B4: BF870291
	v_rcp_f32_e32 v12, v3                                      // 0000002A36B8: 7E185503
	v_fma_f32 v13, -v3, v12, 1.0                               // 0000002A36BC: D613000D 23CA1903
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002A36C4: BF8700A1
	v_fmac_f32_e32 v12, v13, v12                               // 0000002A36C8: 5618190D
	v_div_scale_f32 v14, vcc_lo, v1, v2, v1                    // 0000002A36CC: D6FC6A0E 04060501
	v_mul_f32_e32 v13, v14, v12                                // 0000002A36D4: 101A190E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A36D8: BF870091
	v_fma_f32 v15, -v3, v13, v14                               // 0000002A36DC: D613000F 243A1B03
	v_fmac_f32_e32 v13, v15, v12                               // 0000002A36E4: 561A190F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A36E8: BF870091
	v_fma_f32 v3, -v3, v13, v14                                // 0000002A36EC: D6130003 243A1B03
	v_div_fmas_f32 v3, v3, v12, v13                            // 0000002A36F4: D6370003 04361903
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A36FC: BF870091
	v_div_fixup_f32 v1, v3, v2, v1                             // 0000002A3700: D6270001 04060503
	v_bfe_u32 v2, v1, 16, 1                                    // 0000002A3708: D6100002 02052101
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002A3710: BF8700A1
	v_add3_u32 v3, v1, v2, 0x7fff                              // 0000002A3714: D6550003 03FE0501 00007FFF
	.long 0xd7006a01                                           // 0000002A3720: D7006A01
	v_cndmask_b32_e32 v0, v5, v8, vcc_lo                       // 0000002A3724: 02001105
	v_add_co_ci_u32_e64 v2, null, s9, v6, vcc_lo               // 0000002A3728: D5207C02 01AA0C09
	global_store_d16_hi_b16 v[1:2], v3, off                    // 0000002A3730: DC960000 007C0301
	s_mov_b32 s9, -1                                           // 0000002A3738: BE8900C1
	s_mov_b32 s1, 0                                            // 0000002A373C: BE810080
	s_cmp_lt_i32 s3, 3                                         // 0000002A3740: BF048303
	s_mov_b32 s8, 0                                            // 0000002A3744: BE880080
	s_cbranch_scc1 134                                         // 0000002A3748: BFA20086 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x2364>
	s_cmp_gt_i32 s3, 3                                         // 0000002A374C: BF028303
	s_cbranch_scc0 43                                          // 0000002A3750: BFA1002B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x2200>
	s_cmp_gt_i32 s3, 4                                         // 0000002A3754: BF028403
	s_cbranch_scc0 43                                          // 0000002A3758: BFA1002B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x2208>
	s_cmp_eq_u32 s3, 5                                         // 0000002A375C: BF068503
	s_mov_b32 s8, -1                                           // 0000002A3760: BE8800C1
	s_cbranch_scc0 36                                          // 0000002A3764: BFA10024 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x21f8>
	s_load_b64 s[8:9], s[16:17], 0x10                          // 0000002A3768: F4040208 F8000010
	v_mov_b32_e32 v1, s5                                       // 0000002A3770: 7E020205
	v_mov_b32_e32 v3, s4                                       // 0000002A3774: 7E060204
	.long 0xd73c0009                                           // 0000002A3778: D73C0009
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 0000002A377C: 02021281
	s_waitcnt lgkmcnt(0)                                       // 0000002A3780: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002A3784: BF870193
	v_cndmask_b32_e64 v2, s9, v1, s0                           // 0000002A3788: D5010002 00020209
	v_cndmask_b32_e64 v1, s8, v3, s0                           // 0000002A3790: D5010001 00020608
	s_mov_b32 s8, 0                                            // 0000002A3798: BE880080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A379C: BF870091
	v_mad_u64_u32 v[1:2], null, s6, 6, v[1:2]                  // 0000002A37A0: D6FE7C01 04050C06
	v_mad_u64_u32 v[2:3], null, s7, 6, v[2:3]                  // 0000002A37A8: D6FE7C02 04090C07
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002A37B0: BF8700A2
	.long 0xd7006a01                                           // 0000002A37B4: D7006A01
	v_cndmask_b32_e32 v1, v1, v11, vcc_lo                      // 0000002A37B8: 02021701
	v_bfe_u32 v3, v4, 16, 1                                    // 0000002A37BC: D6100003 02052104
	v_add3_u32 v3, v4, v3, 0x7fff                              // 0000002A37C4: D6550003 03FE0704 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002A37D0: BF870214
	v_add_co_ci_u32_e64 v2, null, v2, v0, vcc_lo               // 0000002A37D4: D5207C02 01AA0102
	.long 0xd7006a00                                           // 0000002A37DC: D7006A00
	v_cndmask_b32_e32 v1, v1, v9, vcc_lo                       // 0000002A37E0: 02021301
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002A37E4: BF870001
	v_add_co_ci_u32_e64 v1, null, v2, v10, vcc_lo              // 0000002A37E8: D5207C01 01AA1502
	global_store_d16_hi_b16 v[0:1], v3, off                    // 0000002A37F0: DC960000 007C0300
	s_mov_b32 s0, 0                                            // 0000002A37F8: BE800080
	s_branch 3                                                 // 0000002A37FC: BFA00003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x220c>
	s_cbranch_execnz 41                                        // 0000002A3800: BFA60029 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x22a8>
	s_branch 86                                                // 0000002A3804: BFA00056 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x2360>
	s_mov_b32 s0, -1                                           // 0000002A3808: BE8000C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002A380C: BF870009
	s_and_b32 vcc_lo, exec_lo, s0                              // 0000002A3810: 8B6A007E
	s_cbranch_vccz 35                                          // 0000002A3814: BFA30023 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x22a4>
	v_mul_f32_e32 v0, 0xbfb8aa3b, v4                           // 0000002A3818: 100008FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002A3820: BF870291
	v_exp_f32_e32 v0, v0                                       // 0000002A3824: 7E004B00
	v_add_f32_e32 v3, 1.0, v0                                  // 0000002A3828: 060600F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002A382C: BF870121
	v_div_scale_f32 v2, null, v3, v3, 1.0                      // 0000002A3830: D6FC7C02 03CA0703
	v_div_scale_f32 v10, vcc_lo, 1.0, v3, 1.0                  // 0000002A3838: D6FC6A0A 03CA06F2
	v_rcp_f32_e32 v9, v2                                       // 0000002A3840: 7E125502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A3844: BF870095
	v_fma_f32 v0, -v2, v9, 1.0                                 // 0000002A3848: D6130000 23CA1302
	v_fmac_f32_e32 v9, v0, v9                                  // 0000002A3850: 56121300
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A3854: BF870091
	v_mul_f32_e32 v11, v10, v9                                 // 0000002A3858: 1016130A
	v_fma_f32 v0, -v2, v11, v10                                // 0000002A385C: D6130000 242A1702
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002A3864: BF870121
	v_fmac_f32_e32 v11, v0, v9                                 // 0000002A3868: 56161300
	v_mad_u64_u32 v[0:1], null, s10, 12, v[7:8]                // 0000002A386C: D6FE7C00 041D180A
	v_fma_f32 v2, -v2, v11, v10                                // 0000002A3874: D6130002 242A1702
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002A387C: BF870191
	v_div_fmas_f32 v9, v2, v9, v11                             // 0000002A3880: D6370009 042E1302
	v_mad_u64_u32 v[1:2], null, s11, 12, v[1:2]                // 0000002A3888: D6FE7C01 0405180B
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002A3890: BF870002
	v_div_fixup_f32 v2, v9, v3, 1.0                            // 0000002A3894: D6270002 03CA0709
	global_store_b32 v[0:1], v2, off                           // 0000002A389C: DC6A0000 007C0200
	s_branch 46                                                // 0000002A38A4: BFA0002E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x2360>
	v_bfe_u32 v0, v4, 16, 1                                    // 0000002A38A8: D6100000 02052104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A38B0: BF870091
	v_add3_u32 v0, v4, v0, 0x7fff                              // 0000002A38B4: D6550000 03FE0104 00007FFF
	v_and_b32_e32 v0, 0xffff0000, v0                           // 0000002A38C0: 360000FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A38C8: BF870091
	v_mul_f32_e32 v0, s2, v0                                   // 0000002A38CC: 10000002
	v_mul_f32_e32 v0, 0xbfb8aa3b, v0                           // 0000002A38D0: 100000FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002A38D8: BF870291
	v_exp_f32_e32 v0, v0                                       // 0000002A38DC: 7E004B00
	v_add_f32_e32 v2, 1.0, v0                                  // 0000002A38E0: 060400F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A38E4: BF870091
	v_div_scale_f32 v0, null, v2, v2, 1.0                      // 0000002A38E8: D6FC7C00 03CA0502
	v_rcp_f32_e32 v3, v0                                       // 0000002A38F0: 7E065500
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A38F4: BF870095
	v_fma_f32 v1, -v0, v3, 1.0                                 // 0000002A38F8: D6130001 23CA0700
	v_fmac_f32_e32 v3, v1, v3                                  // 0000002A3900: 56060701
	v_div_scale_f32 v1, vcc_lo, 1.0, v2, 1.0                   // 0000002A3904: D6FC6A01 03CA04F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A390C: BF870091
	v_mul_f32_e32 v9, v1, v3                                   // 0000002A3910: 10120701
	v_fma_f32 v10, -v0, v9, v1                                 // 0000002A3914: D613000A 24061300
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A391C: BF870091
	v_fmac_f32_e32 v9, v10, v3                                 // 0000002A3920: 5612070A
	v_fma_f32 v10, -v0, v9, v1                                 // 0000002A3924: D613000A 24061300
	v_mad_u64_u32 v[0:1], null, s10, 12, v[7:8]                // 0000002A392C: D6FE7C00 041D180A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A3934: BF870092
	v_div_fmas_f32 v3, v10, v3, v9                             // 0000002A3938: D6370003 0426070A
	v_div_fixup_f32 v3, v3, v2, 1.0                            // 0000002A3940: D6270003 03CA0503
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002A3948: BF870113
	v_mad_u64_u32 v[1:2], null, s11, 12, v[1:2]                // 0000002A394C: D6FE7C01 0405180B
	v_add_f32_e32 v2, v3, v3                                   // 0000002A3954: 06040703
	global_store_b32 v[0:1], v2, off                           // 0000002A3958: DC6A0000 007C0200
	s_mov_b32 s9, 0                                            // 0000002A3960: BE890080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002A3964: BF870009
	s_and_b32 vcc_lo, exec_lo, s9                              // 0000002A3968: 8B6A097E
	s_cbranch_vccz 58                                          // 0000002A396C: BFA3003A <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x2458>
	s_cmp_gt_i32 s3, 1                                         // 0000002A3970: BF028103
	s_mov_b32 s0, -1                                           // 0000002A3974: BE8000C1
	s_cbranch_scc0 50                                          // 0000002A3978: BFA10032 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x2444>
	v_bfe_u32 v0, v4, 16, 1                                    // 0000002A397C: D6100000 02052104
	s_mov_b32 s0, 0                                            // 0000002A3984: BE800080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A3988: BF870091
	v_add3_u32 v0, v4, v0, 0x7fff                              // 0000002A398C: D6550000 03FE0104 00007FFF
	v_and_b32_e32 v0, 0xffff0000, v0                           // 0000002A3998: 360000FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A39A0: BF870091
	v_mul_f32_e32 v0, 0xbfb8aa3b, v0                           // 0000002A39A4: 100000FF BFB8AA3B
	v_exp_f32_e32 v0, v0                                       // 0000002A39AC: 7E004B00
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A39B0: BF870095
	v_add_f32_e32 v2, 1.0, v0                                  // 0000002A39B4: 060400F2
	v_div_scale_f32 v0, null, v2, v2, 1.0                      // 0000002A39B8: D6FC7C00 03CA0502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002A39C0: BF870291
	v_rcp_f32_e32 v1, v0                                       // 0000002A39C4: 7E025500
	v_fma_f32 v3, -v0, v1, 1.0                                 // 0000002A39C8: D6130003 23CA0300
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002A39D0: BF8700A1
	v_fmac_f32_e32 v1, v3, v1                                  // 0000002A39D4: 56020303
	v_div_scale_f32 v3, vcc_lo, 1.0, v2, 1.0                   // 0000002A39D8: D6FC6A03 03CA04F2
	v_mul_f32_e32 v7, v3, v1                                   // 0000002A39E0: 100E0303
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A39E4: BF870091
	v_fma_f32 v8, -v0, v7, v3                                  // 0000002A39E8: D6130008 240E0F00
	v_fmac_f32_e32 v7, v8, v1                                  // 0000002A39F0: 560E0308
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A39F4: BF870091
	v_fma_f32 v0, -v0, v7, v3                                  // 0000002A39F8: D6130000 240E0F00
	v_div_fmas_f32 v3, v0, v1, v7                              // 0000002A3A00: D6370003 041E0300
	v_mad_u64_u32 v[0:1], null, s10, 6, v[5:6]                 // 0000002A3A08: D6FE7C00 04150C0A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002A3A10: BF870112
	v_div_fixup_f32 v3, v3, v2, 1.0                            // 0000002A3A14: D6270003 03CA0503
	v_mad_u64_u32 v[1:2], null, s11, 6, v[1:2]                 // 0000002A3A1C: D6FE7C01 04050C0B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A3A24: BF870092
	v_bfe_u32 v7, v3, 16, 1                                    // 0000002A3A28: D6100007 02052103
	v_add3_u32 v2, v3, v7, 0x7fff                              // 0000002A3A30: D6550002 03FE0F03 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off                    // 0000002A3A3C: DC960000 007C0200
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 0000002A3A44: 916A007E
	s_cbranch_vccnz 3                                          // 0000002A3A48: BFA40003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x2458>
	s_cmp_lg_u32 s3, 1                                         // 0000002A3A4C: BF078103
	s_mov_b32 s1, -1                                           // 0000002A3A50: BE8100C1
	s_cselect_b32 s8, -1, 0                                    // 0000002A3A54: 980880C1
	v_bfe_u32 v0, v4, 16, 1                                    // 0000002A3A58: D6100000 02052104
	s_and_b32 vcc_lo, exec_lo, s8                              // 0000002A3A60: 8B6A087E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002A3A64: BF870001
	v_add3_u32 v0, v4, v0, 0x7fff                              // 0000002A3A68: D6550000 03FE0104 00007FFF
	s_cbranch_vccz 7                                           // 0000002A3A74: BFA30007 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x2494>
	v_mad_u64_u32 v[1:2], null, s10, 6, v[5:6]                 // 0000002A3A78: D6FE7C01 04150C0A
	s_mov_b32 s1, 0                                            // 0000002A3A80: BE810080
	v_mad_u64_u32 v[2:3], null, s11, 6, v[2:3]                 // 0000002A3A84: D6FE7C02 04090C0B
	global_store_d16_hi_b16 v[1:2], v0, off                    // 0000002A3A8C: DC960000 007C0001
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002A3A94: 916A017E
	s_cbranch_vccnz 45                                         // 0000002A3A98: BFA4002D <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi4ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x2550>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A3A9C: BF870091
	v_and_b32_e32 v0, 0xffff0000, v0                           // 0000002A3AA0: 360000FF FFFF0000
	v_mul_f32_e32 v2, s2, v0                                   // 0000002A3AA8: 10040002
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A3AAC: BF870091
	v_mul_f32_e32 v0, 0xbfb8aa3b, v2                           // 0000002A3AB0: 100004FF BFB8AA3B
	v_exp_f32_e32 v0, v0                                       // 0000002A3AB8: 7E004B00
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A3ABC: BF870095
	v_add_f32_e32 v3, 1.0, v0                                  // 0000002A3AC0: 060600F2
	v_div_scale_f32 v0, null, v3, v3, v2                       // 0000002A3AC4: D6FC7C00 040A0703
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002A3ACC: BF870291
	v_rcp_f32_e32 v1, v0                                       // 0000002A3AD0: 7E025500
	v_fma_f32 v4, -v0, v1, 1.0                                 // 0000002A3AD4: D6130004 23CA0300
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002A3ADC: BF8700A1
	v_fmac_f32_e32 v1, v4, v1                                  // 0000002A3AE0: 56020304
	v_div_scale_f32 v4, vcc_lo, v2, v3, v2                     // 0000002A3AE4: D6FC6A04 040A0702
	v_mul_f32_e32 v7, v4, v1                                   // 0000002A3AEC: 100E0304
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A3AF0: BF870091
	v_fma_f32 v8, -v0, v7, v4                                  // 0000002A3AF4: D6130008 24120F00
	v_fmac_f32_e32 v7, v8, v1                                  // 0000002A3AFC: 560E0308
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A3B00: BF870091
	v_fma_f32 v0, -v0, v7, v4                                  // 0000002A3B04: D6130000 24120F00
	v_div_fmas_f32 v4, v0, v1, v7                              // 0000002A3B0C: D6370004 041E0300
	v_mad_u64_u32 v[0:1], null, s10, 6, v[5:6]                 // 0000002A3B14: D6FE7C00 04150C0A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002A3B1C: BF870112
	v_div_fixup_f32 v3, v4, v3, v2                             // 0000002A3B20: D6270003 040A0704
	v_mad_u64_u32 v[1:2], null, s11, 6, v[1:2]                 // 0000002A3B28: D6FE7C01 04050C0B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A3B30: BF870092
	v_bfe_u32 v4, v3, 16, 1                                    // 0000002A3B34: D6100004 02052103
	v_add3_u32 v2, v3, v4, 0x7fff                              // 0000002A3B3C: D6550002 03FE0903 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off                    // 0000002A3B48: DC960000 007C0200
	s_nop 0                                                    // 0000002A3B50: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000002A3B54: BFB60003
	s_endpgm                                                   // 0000002A3B58: BFB00000
		...

