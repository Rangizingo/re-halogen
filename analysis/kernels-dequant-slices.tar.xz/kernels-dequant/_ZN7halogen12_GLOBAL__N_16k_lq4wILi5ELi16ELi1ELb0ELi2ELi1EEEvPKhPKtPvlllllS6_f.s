000000000080fb00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 00000080FB00: F4100100 F8000000
	v_and_b32_e32 v30, 15, v0                                  // 00000080FB08: 363C008F
	v_lshrrev_b32_e32 v1, 4, v0                                // 00000080FB0C: 32020084
	s_ashr_i32 s3, s2, 31                                      // 00000080FB10: 86039F02
	v_lshlrev_b32_e32 v7, 2, v0                                // 00000080FB14: 300E0082
	s_lshl_b64 s[0:1], s[2:3], 4                               // 00000080FB18: 84808402
	v_lshlrev_b32_e32 v2, 2, v30                               // 00000080FB1C: 30043C82
	v_dual_mov_b32 v24, s1 :: v_dual_lshlrev_b32 v3, 2, v1     // 00000080FB20: CA220001 18020282
	v_or_b32_e32 v23, s0, v1                                   // 00000080FB28: 382E0200
	.long 0x7f0c3880                                           // 00000080FB2C: 7F0C3880
	s_waitcnt lgkmcnt(0)                                       // 00000080FB30: BF89FC07
	s_clause 0x1                                               // 00000080FB34: BF850001
	global_load_b32 v4, v2, s[4:5]                             // 00000080FB38: DC520000 04040002
	global_load_b32 v3, v3, s[4:5]                             // 00000080FB40: DC520000 03040003
	.long 0xd4540000                                           // 00000080FB48: D4540000
	v_cndmask_b32_e32 v1, s12, v23, vcc_lo                     // 00000080FB4C: 02022E0C
	s_add_u32 s22, s4, s16                                     // 00000080FB50: 80161004
	s_addc_u32 s23, s5, s17                                    // 00000080FB54: 82171105
	s_ashr_i32 s2, s11, 31                                     // 00000080FB58: 86029F0B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 00000080FB5C: BF870159
	s_lshr_b32 s2, s2, 27                                      // 00000080FB60: 85029B02
	v_cndmask_b32_e64 v2, 0, v23, s0                           // 00000080FB64: D5010002 00022E80
	v_cndmask_b32_e64 v5, 0, s1, s0                            // 00000080FB6C: D5010005 00000280
	s_add_u32 s2, s10, s2                                      // 00000080FB74: 8002020A
	s_addc_u32 s3, s11, 0                                      // 00000080FB78: 8203800B
	.long 0xd72c0008                                           // 00000080FB7C: D72C0008
	v_cndmask_b32_e32 v1, s19, v2, vcc_lo                      // 00000080FB80: 02020413
	v_mad_u64_u32 v[0:1], null, s18, v2, 0                     // 00000080FB84: D6FE7C00 02020412
	s_lshr_b64 s[20:21], s[2:3], 5                             // 00000080FB8C: 85948502
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000080FB90: BF870009
	s_cmpk_lt_i32 s20, 0x81                                    // 00000080FB94: B3940081
	.long 0xd4440002                                           // 00000080FB98: D4440002
	v_cndmask_b32_e32 v1, s20, v30, vcc_lo                     // 00000080FB9C: 02023C14
	s_cselect_b32 s1, -1, 0                                    // 00000080FBA0: 980180C1
	s_cmpk_gt_i32 s20, 0x80                                    // 00000080FBA4: B2940080
	s_waitcnt vmcnt(1)                                         // 00000080FBA8: BF8907F7
	v_bfe_u32 v9, v4, 16, 1                                    // 00000080FBAC: D6100009 02052104
	s_waitcnt vmcnt(0)                                         // 00000080FBB4: BF8903F7
	v_bfe_u32 v10, v3, 16, 1                                   // 00000080FBB8: D610000A 02052103
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000080FBC0: BF8701A2
	v_add3_u32 v4, v4, v9, 0x7fff                              // 00000080FBC4: D6550004 03FE1304 00007FFF
	.long 0xd72c0009                                           // 00000080FBD0: D72C0009
	v_cndmask_b32_e32 v1, s18, v5, vcc_lo                      // 00000080FBD4: 02020A12
	v_add3_u32 v3, v3, v10, 0x7fff                             // 00000080FBD8: D6550003 03FE1503 00007FFF
	s_cselect_b32 s18, -1, 0                                   // 00000080FBE4: 981280C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000080FBE8: BF8701A9
	s_and_b32 vcc_lo, exec_lo, s18                             // 00000080FBEC: 8B6A127E
	.long 0x7e0c3984                                           // 00000080FBF0: 7E0C3984
	v_add3_u32 v1, v1, v9, v8                                  // 00000080FBF4: D6550001 04221301
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000080FBFC: BF8700A2
	v_and_or_b32 v6, 0xffff0000, v3, v6                        // 00000080FC00: D6570006 041A06FF FFFF0000
	.long 0xd7000303                                           // 00000080FC0C: D7000303
	v_cndmask_b32_e32 v1, s22, v0, vcc_lo                      // 00000080FC10: 02020016
	v_add_co_ci_u32_e64 v4, null, s23, v1, s3                  // 00000080FC14: D5207C04 000E0217
	ds_store_b32 v7, v6                                        // 00000080FC1C: D8340000 00000607
	s_waitcnt lgkmcnt(0)                                       // 00000080FC24: BF89FC07
	s_barrier                                                  // 00000080FC28: BFBD0000
	buffer_gl0_inv                                             // 00000080FC2C: E0AC0000 00000000
	s_cbranch_vccnz 144                                        // 00000080FC34: BFA40090 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x378>
	v_dual_mov_b32 v8, 0 :: v_dual_mov_b32 v7, 0               // 00000080FC38: CA100080 08060080
	s_and_saveexec_b32 s3, s2                                  // 00000080FC40: BE832002
	s_cbranch_execz 10                                         // 00000080FC44: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x170>
	v_lshlrev_b32_e32 v6, 1, v30                               // 00000080FC48: 300C3C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000080FC4C: BF870091
	.long 0xd7006a06                                           // 00000080FC50: D7006A06
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000080FC54: 02020D03
	v_add_co_ci_u32_e64 v7, null, 0, v4, vcc_lo                // 00000080FC58: D5207C07 01AA0880
	global_load_d16_b16 v6, v[6:7], off                        // 00000080FC60: DC820000 067C0006
	s_waitcnt vmcnt(0)                                         // 00000080FC68: BF8903F7
	v_cvt_f32_f16_e32 v7, v6                                   // 00000080FC6C: 7E0E1706
	s_or_b32 exec_lo, exec_lo, s3                              // 00000080FC70: 8C7E037E
	v_or_b32_e32 v6, 16, v30                                   // 00000080FC74: 380C3C90
	s_mov_b32 s2, exec_lo                                      // 00000080FC78: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000080FC7C: BF870001
	.long 0xd4c4007e                                           // 00000080FC80: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 00000080FC84: 02020C14
	s_cbranch_execz 10                                         // 00000080FC88: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x1b4>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000080FC8C: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000080FC90: BF870091
	.long 0xd7006a08                                           // 00000080FC94: D7006A08
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000080FC98: 02020D03
	v_add_co_ci_u32_e64 v9, null, 0, v4, vcc_lo                // 00000080FC9C: D5207C09 01AA0880
	global_load_d16_b16 v6, v[8:9], off                        // 00000080FCA4: DC820000 067C0008
	s_waitcnt vmcnt(0)                                         // 00000080FCAC: BF8903F7
	v_cvt_f32_f16_e32 v8, v6                                   // 00000080FCB0: 7E101706
	s_or_b32 exec_lo, exec_lo, s2                              // 00000080FCB4: 8C7E027E
	v_or_b32_e32 v6, 32, v30                                   // 00000080FCB8: 380C3CA0
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v9, 0              // 00000080FCBC: CA100080 0A080080
	s_mov_b32 s2, exec_lo                                      // 00000080FCC4: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000080FCC8: BF870002
	.long 0xd4c4007e                                           // 00000080FCCC: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 00000080FCD0: 02020C14
	s_cbranch_execz 10                                         // 00000080FCD4: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x200>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000080FCD8: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000080FCDC: BF870091
	.long 0xd7006a0b                                           // 00000080FCE0: D7006A0B
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000080FCE4: 02020D03
	v_add_co_ci_u32_e64 v12, null, 0, v4, vcc_lo               // 00000080FCE8: D5207C0C 01AA0880
	global_load_d16_b16 v6, v[11:12], off                      // 00000080FCF0: DC820000 067C000B
	s_waitcnt vmcnt(0)                                         // 00000080FCF8: BF8903F7
	v_cvt_f32_f16_e32 v9, v6                                   // 00000080FCFC: 7E121706
	s_or_b32 exec_lo, exec_lo, s2                              // 00000080FD00: 8C7E027E
	v_or_b32_e32 v6, 48, v30                                   // 00000080FD04: 380C3CB0
	s_mov_b32 s2, exec_lo                                      // 00000080FD08: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000080FD0C: BF870001
	.long 0xd4c4007e                                           // 00000080FD10: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 00000080FD14: 02020C14
	s_cbranch_execz 10                                         // 00000080FD18: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x244>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000080FD1C: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000080FD20: BF870091
	.long 0xd7006a0a                                           // 00000080FD24: D7006A0A
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000080FD28: 02020D03
	v_add_co_ci_u32_e64 v11, null, 0, v4, vcc_lo               // 00000080FD2C: D5207C0B 01AA0880
	global_load_d16_b16 v6, v[10:11], off                      // 00000080FD34: DC820000 067C000A
	s_waitcnt vmcnt(0)                                         // 00000080FD3C: BF8903F7
	v_cvt_f32_f16_e32 v10, v6                                  // 00000080FD40: 7E141706
	s_or_b32 exec_lo, exec_lo, s2                              // 00000080FD44: 8C7E027E
	v_or_b32_e32 v6, 64, v30                                   // 00000080FD48: 380C3CC0
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v11, 0             // 00000080FD4C: CA100080 0C0A0080
	s_mov_b32 s2, exec_lo                                      // 00000080FD54: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000080FD58: BF870002
	.long 0xd4c4007e                                           // 00000080FD5C: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 00000080FD60: 02020C14
	s_cbranch_execz 10                                         // 00000080FD64: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x290>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000080FD68: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000080FD6C: BF870091
	.long 0xd7006a0d                                           // 00000080FD70: D7006A0D
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000080FD74: 02020D03
	v_add_co_ci_u32_e64 v14, null, 0, v4, vcc_lo               // 00000080FD78: D5207C0E 01AA0880
	global_load_d16_b16 v6, v[13:14], off                      // 00000080FD80: DC820000 067C000D
	s_waitcnt vmcnt(0)                                         // 00000080FD88: BF8903F7
	v_cvt_f32_f16_e32 v11, v6                                  // 00000080FD8C: 7E161706
	s_or_b32 exec_lo, exec_lo, s2                              // 00000080FD90: 8C7E027E
	v_or_b32_e32 v6, 0x50, v30                                 // 00000080FD94: 380C3CFF 00000050
	s_mov_b32 s2, exec_lo                                      // 00000080FD9C: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000080FDA0: BF870001
	.long 0xd4c4007e                                           // 00000080FDA4: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 00000080FDA8: 02020C14
	s_cbranch_execz 10                                         // 00000080FDAC: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x2d8>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000080FDB0: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000080FDB4: BF870091
	.long 0xd7006a0c                                           // 00000080FDB8: D7006A0C
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000080FDBC: 02020D03
	v_add_co_ci_u32_e64 v13, null, 0, v4, vcc_lo               // 00000080FDC0: D5207C0D 01AA0880
	global_load_d16_b16 v6, v[12:13], off                      // 00000080FDC8: DC820000 067C000C
	s_waitcnt vmcnt(0)                                         // 00000080FDD0: BF8903F7
	v_cvt_f32_f16_e32 v12, v6                                  // 00000080FDD4: 7E181706
	s_or_b32 exec_lo, exec_lo, s2                              // 00000080FDD8: 8C7E027E
	v_or_b32_e32 v6, 0x60, v30                                 // 00000080FDDC: 380C3CFF 00000060
	v_dual_mov_b32 v14, 0 :: v_dual_mov_b32 v13, 0             // 00000080FDE4: CA100080 0E0C0080
	s_mov_b32 s2, exec_lo                                      // 00000080FDEC: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000080FDF0: BF870002
	.long 0xd4c4007e                                           // 00000080FDF4: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 00000080FDF8: 02020C14
	s_cbranch_execz 10                                         // 00000080FDFC: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x328>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000080FE00: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000080FE04: BF870091
	.long 0xd7006a0f                                           // 00000080FE08: D7006A0F
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000080FE0C: 02020D03
	v_add_co_ci_u32_e64 v16, null, 0, v4, vcc_lo               // 00000080FE10: D5207C10 01AA0880
	global_load_d16_b16 v6, v[15:16], off                      // 00000080FE18: DC820000 067C000F
	s_waitcnt vmcnt(0)                                         // 00000080FE20: BF8903F7
	v_cvt_f32_f16_e32 v13, v6                                  // 00000080FE24: 7E1A1706
	s_or_b32 exec_lo, exec_lo, s2                              // 00000080FE28: 8C7E027E
	v_or_b32_e32 v6, 0x70, v30                                 // 00000080FE2C: 380C3CFF 00000070
	s_mov_b32 s2, exec_lo                                      // 00000080FE34: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000080FE38: BF870001
	.long 0xd4c4007e                                           // 00000080FE3C: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 00000080FE40: 02020C14
	s_cbranch_execz 10                                         // 00000080FE44: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x370>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000080FE48: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000080FE4C: BF870091
	.long 0xd7006a0e                                           // 00000080FE50: D7006A0E
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000080FE54: 02020D03
	v_add_co_ci_u32_e64 v15, null, 0, v4, vcc_lo               // 00000080FE58: D5207C0F 01AA0880
	global_load_d16_b16 v6, v[14:15], off                      // 00000080FE60: DC820000 067C000E
	s_waitcnt vmcnt(0)                                         // 00000080FE68: BF8903F7
	v_cvt_f32_f16_e32 v14, v6                                  // 00000080FE6C: 7E1C1706
	s_or_b32 exec_lo, exec_lo, s2                              // 00000080FE70: 8C7E027E
	s_branch 9                                                 // 00000080FE74: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x39c>
	v_mov_b32_e32 v7, 0                                        // 00000080FE78: 7E0E0280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000080FE7C: BF870001
	v_mov_b32_e32 v8, v7                                       // 00000080FE80: 7E100307
	v_mov_b32_e32 v9, v7                                       // 00000080FE84: 7E120307
	v_mov_b32_e32 v10, v7                                      // 00000080FE88: 7E140307
	v_mov_b32_e32 v11, v7                                      // 00000080FE8C: 7E160307
	v_mov_b32_e32 v12, v7                                      // 00000080FE90: 7E180307
	v_mov_b32_e32 v13, v7                                      // 00000080FE94: 7E1A0307
	v_mov_b32_e32 v14, v7                                      // 00000080FE98: 7E1C0307
	s_add_u32 s2, s4, s14                                      // 00000080FE9C: 80020E04
	s_addc_u32 s3, s5, s15                                     // 00000080FEA0: 82030F05
	s_lshr_b32 s14, s11, 31                                    // 00000080FEA4: 850E9F0B
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v20, 0             // 00000080FEA8: CA100080 13140080
	s_add_u32 s14, s10, s14                                    // 00000080FEB0: 800E0E0A
	s_addc_u32 s15, s11, 0                                     // 00000080FEB4: 820F800B
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v22, 0             // 00000080FEB8: CA100080 21160080
	s_ashr_i64 s[14:15], s[14:15], 1                           // 00000080FEC0: 868E810E
	v_cndmask_b32_e64 v31, 0, 1, s18                           // 00000080FEC4: D501001F 00490280
	v_mad_u64_u32 v[25:26], null, v2, s14, s[2:3]              // 00000080FECC: D6FE7C19 00081D02
	.long 0xd72c0002                                           // 00000080FED4: D72C0002
	v_cndmask_b32_e32 v0, v2, v15, vcc_lo                      // 00000080FED8: 02001F02
	.long 0xd72c0005                                           // 00000080FEDC: D72C0005
	v_cndmask_b32_e32 v0, v5, v14, vcc_lo                      // 00000080FEE0: 02001D05
	.long 0xd4440002                                           // 00000080FEE4: D4440002
	v_cndmask_b32_e32 v1, s20, v30, vcc_lo                     // 00000080FEE8: 02023C14
	v_mov_b32_e32 v41, 0                                       // 00000080FEEC: 7E520280
	v_mov_b32_e32 v21, 0                                       // 00000080FEF0: 7E2A0280
	s_delay_alu instid0(VALU_DEP_4)                            // 00000080FEF4: BF870004
	v_add3_u32 v32, v5, v26, v2                                // 00000080FEF8: D6550020 040A3505
	s_and_saveexec_b32 s3, s2                                  // 00000080FF00: BE832002
	s_cbranch_execz 21                                         // 00000080FF04: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x45c>
	v_dual_mov_b32 v41, 0 :: v_dual_lshlrev_b32 v2, 4, v30     // 00000080FF08: CA220080 29023C84
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000080FF10: BF870091
	.long 0xd7006a05                                           // 00000080FF14: D7006A05
	v_cndmask_b32_e32 v1, v25, v2, vcc_lo                      // 00000080FF18: 02020519
	v_add_co_ci_u32_e64 v6, null, 0, v32, vcc_lo               // 00000080FF1C: D5207C06 01AA4080
	s_and_not1_b32 vcc_lo, exec_lo, s18                        // 00000080FF24: 916A127E
	global_load_b128 v[19:22], v[5:6], off                     // 00000080FF28: DC5E0000 137C0005
	s_cbranch_vccnz 10                                         // 00000080FF30: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x45c>
	v_lshlrev_b32_e32 v2, 1, v30                               // 00000080FF34: 30043C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000080FF38: BF870091
	.long 0xd7006a02                                           // 00000080FF3C: D7006A02
	v_cndmask_b32_e32 v1, v3, v2, vcc_lo                       // 00000080FF40: 02020503
	v_add_co_ci_u32_e64 v3, null, 0, v4, vcc_lo                // 00000080FF44: D5207C03 01AA0880
	global_load_d16_b16 v2, v[2:3], off                        // 00000080FF4C: DC820000 027C0002
	s_waitcnt vmcnt(0)                                         // 00000080FF54: BF8903F7
	v_cvt_f32_f16_e32 v41, v2                                  // 00000080FF58: 7E521702
	s_or_b32 exec_lo, exec_lo, s3                              // 00000080FF5C: 8C7E037E
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v35, 0             // 00000080FF60: CA100080 22220080
	v_dual_mov_b32 v36, 0 :: v_dual_mov_b32 v37, 0             // 00000080FF68: CA100080 24240080
	s_and_saveexec_b32 s3, s2                                  // 00000080FF70: BE832002
	s_cbranch_execz 507                                        // 00000080FF74: BFA501FB <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0xc64>
	v_dual_mov_b32 v27, 0 :: v_dual_lshlrev_b32 v2, 1, v30     // 00000080FF78: CA220080 1B023C81
	.long 0xd7006a00                                           // 00000080FF80: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 00000080FF84: 02020010
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000080FF88: BF8701A1
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 00000080FF8C: D5207C01 01AA0211
	v_dual_mov_b32 v39, v30 :: v_dual_lshlrev_b32 v26, 5, v30  // 00000080FF94: CA22011E 271A3C85
	.long 0xd7006a00                                           // 00000080FF9C: D7006A00
	v_cndmask_b32_e32 v1, v0, v2, vcc_lo                       // 00000080FFA0: 02020500
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000080FFA4: BF8701A1
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 00000080FFA8: D5207C01 01AA0280
	v_lshl_or_b32 v38, v30, 4, 0x100                           // 00000080FFB0: D6560026 03FD091E 00000100
	.long 0xd7006a00                                           // 00000080FFBC: D7006A00
	v_cndmask_b32_e32 v1, s4, v0, vcc_lo                       // 00000080FFC0: 02020004
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000080FFC4: BF8701A1
	v_add_co_ci_u32_e64 v1, null, s5, v1, vcc_lo               // 00000080FFC8: D5207C01 01AA0205
	v_dual_mov_b32 v37, v27 :: v_dual_mov_b32 v40, v41         // 00000080FFD0: CA10011B 25280129
	.long 0xd7006a1c                                           // 00000080FFD8: D7006A1C
	v_cndmask_b32_e32 v0, v0, v160, vcc_lo                     // 00000080FFDC: 02014100
	s_delay_alu instid0(VALU_DEP_1)                            // 00000080FFE0: BF870001
	v_add_co_ci_u32_e64 v29, null, 0, v1, vcc_lo               // 00000080FFE4: D5207C1D 01AA0280
	v_mov_b32_e32 v36, v27                                     // 00000080FFEC: 7E48031B
	v_mov_b32_e32 v35, v27                                     // 00000080FFF0: 7E46031B
	v_mov_b32_e32 v34, v27                                     // 00000080FFF4: 7E44031B
	v_mov_b32_e32 v33, v27                                     // 00000080FFF8: 7E42031B
	s_mul_i32 s2, s11, 6                                       // 00000080FFFC: 9602860B
	s_mul_hi_u32 s18, s10, 6                                   // 000000810000: 9692860A
	s_lshl_b64 s[14:15], s[10:11], 2                           // 000000810004: 848E820A
	s_add_i32 s18, s18, s2                                     // 000000810008: 81120212
	s_mul_i32 s17, s10, 6                                      // 00000081000C: 9611860A
	s_mov_b32 s16, 0                                           // 000000810010: BE900080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 000000810014: 8484810A
	s_branch 437                                               // 000000810018: BFA001B5 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0xbf0>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000081001C: 8C7E0A7E
	v_cndmask_b32_e64 v51, v41, v7, s1                         // 000000810020: D5010033 00060F29
	v_cndmask_b32_e64 v1, v8, v9, s1                           // 000000810028: D5010001 00061308
	v_cndmask_b32_e64 v0, v7, v8, s1                           // 000000810030: D5010000 00061107
	v_dual_mov_b32 v7, v14 :: v_dual_and_b32 v8, 0xff, v19     // 000000810038: CA24010E 070826FF 000000FF
	v_cndmask_b32_e64 v6, v13, v14, s1                         // 000000810044: D5010006 00061D0D
	v_cndmask_b32_e64 v5, v12, v13, s1                         // 00000081004C: D5010005 00061B0C
	v_cndmask_b32_e64 v4, v11, v12, s1                         // 000000810054: D5010004 0006190B
	v_cndmask_b32_e64 v3, v10, v11, s1                         // 00000081005C: D5010003 0006170A
	v_lshlrev_b32_e32 v8, 2, v8                                // 000000810064: 30101082
	v_cndmask_b32_e64 v2, v9, v10, s1                          // 000000810068: D5010002 00061509
	s_and_b32 s2, exec_lo, s2                                  // 000000810070: 8B02027E
	v_add_nc_u32_e32 v38, 0x100, v38                           // 000000810074: 4A4C4CFF 00000100
	s_or_b32 s16, s2, s16                                      // 00000081007C: 8C101002
	ds_load_b32 v14, v8                                        // 000000810080: D8D80000 0E000008
	v_lshrrev_b32_e32 v8, 6, v19                               // 000000810088: 32102686
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000081008C: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000810090: 361010FF 000003FC
	ds_load_b32 v52, v8                                        // 000000810098: D8D80000 34000008
	v_lshrrev_b32_e32 v8, 14, v19                              // 0000008100A0: 3210268E
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008100A4: 361010FF 000003FC
	ds_load_b32 v53, v8                                        // 0000008100AC: D8D80000 35000008
	v_lshrrev_b32_e32 v8, 22, v19                              // 0000008100B4: 32102696
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008100B8: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008100BC: 361010FF 000003FC
	ds_load_b32 v54, v8                                        // 0000008100C4: D8D80000 36000008
	v_and_b32_e32 v8, 0xff, v20                                // 0000008100CC: 361028FF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 0000008100D4: 30101082
	ds_load_b32 v55, v8                                        // 0000008100D8: D8D80000 37000008
	v_lshrrev_b32_e32 v8, 6, v20                               // 0000008100E0: 32102886
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008100E4: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008100E8: 361010FF 000003FC
	ds_load_b32 v56, v8                                        // 0000008100F0: D8D80000 38000008
	v_lshrrev_b32_e32 v8, 14, v20                              // 0000008100F8: 3210288E
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008100FC: 361010FF 000003FC
	ds_load_b32 v57, v8                                        // 000000810104: D8D80000 39000008
	v_lshrrev_b32_e32 v8, 22, v20                              // 00000081010C: 32102896
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000810110: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000810114: 361010FF 000003FC
	ds_load_b32 v58, v8                                        // 00000081011C: D8D80000 3A000008
	v_and_b32_e32 v8, 0xff, v21                                // 000000810124: 36102AFF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 00000081012C: 30101082
	ds_load_b32 v59, v8                                        // 000000810130: D8D80000 3B000008
	v_lshrrev_b32_e32 v8, 6, v21                               // 000000810138: 32102A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000081013C: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000810140: 361010FF 000003FC
	ds_load_b32 v60, v8                                        // 000000810148: D8D80000 3C000008
	v_lshrrev_b32_e32 v8, 14, v21                              // 000000810150: 32102A8E
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000810154: 361010FF 000003FC
	ds_load_b32 v61, v8                                        // 00000081015C: D8D80000 3D000008
	v_lshrrev_b32_e32 v8, 22, v21                              // 000000810164: 32102A96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000810168: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000081016C: 361010FF 000003FC
	ds_load_b32 v62, v8                                        // 000000810174: D8D80000 3E000008
	v_and_b32_e32 v8, 0xff, v22                                // 00000081017C: 36102CFF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 000000810184: 30101082
	ds_load_b32 v63, v8                                        // 000000810188: D8D80000 3F000008
	v_lshrrev_b32_e32 v8, 6, v22                               // 000000810190: 32102C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000810194: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000810198: 361010FF 000003FC
	ds_load_b32 v64, v8                                        // 0000008101A0: D8D80000 40000008
	v_lshrrev_b32_e32 v8, 14, v22                              // 0000008101A8: 32102C8E
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008101AC: 361010FF 000003FC
	ds_load_b32 v65, v8                                        // 0000008101B4: D8D80000 41000008
	v_lshrrev_b32_e32 v8, 22, v22                              // 0000008101BC: 32102C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000008101C0: BF870141
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008101C4: 361010FF 000003FC
	ds_load_b32 v66, v8                                        // 0000008101CC: D8D80000 42000008
	.long 0xd73c0008                                           // 0000008101D4: D73C0008
	v_cndmask_b32_e32 v1, 1, v26, vcc_lo                       // 0000008101D8: 02023481
	v_add_nc_u32_e32 v26, 0x200, v26                           // 0000008101DC: 4A3434FF 00000200
	.long 0xd7006a0c                                           // 0000008101E4: D7006A0C
	v_cndmask_b32_e32 v1, s6, v8, vcc_lo                       // 0000008101E8: 02021006
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008101EC: BF870001
	v_add_co_ci_u32_e64 v13, null, s7, v9, vcc_lo              // 0000008101F0: D5207C0D 01AA1207
	s_clause 0x3                                               // 0000008101F8: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 0000008101FC: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 000000810204: DC5E0010 137C000C
	global_load_b128 v[41:44], v[12:13], off offset:32         // 00000081020C: DC5E0020 297C000C
	global_load_b128 v[45:48], v[12:13], off offset:48         // 000000810214: DC5E0030 2D7C000C
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 00000081021C: BF890CF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 000000810220: CC1A4008 1A021D08
	s_waitcnt lgkmcnt(14)                                      // 000000810228: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000081022C: BF8700A1
	v_dot2_f32_bf16 v8, v9, v52, v8                            // 000000810230: CC1A4008 1C226909
	s_waitcnt lgkmcnt(13)                                      // 000000810238: BF89FCD7
	v_dot2_f32_bf16 v8, v10, v53, v8                           // 00000081023C: CC1A4008 1C226B0A
	s_waitcnt lgkmcnt(12)                                      // 000000810244: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000810248: BF8700A1
	v_dot2_f32_bf16 v8, v11, v54, v8                           // 00000081024C: CC1A4008 1C226D0B
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 000000810254: BF8908B7
	v_dot2_f32_bf16 v8, v19, v55, v8                           // 000000810258: CC1A4008 1C226F13
	s_waitcnt lgkmcnt(10)                                      // 000000810260: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000810264: BF8700A1
	v_dot2_f32_bf16 v8, v20, v56, v8                           // 000000810268: CC1A4008 1C227114
	s_waitcnt lgkmcnt(9)                                       // 000000810270: BF89FC97
	v_dot2_f32_bf16 v8, v21, v57, v8                           // 000000810274: CC1A4008 1C227315
	s_waitcnt lgkmcnt(8)                                       // 00000081027C: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000810280: BF8700A1
	v_dot2_f32_bf16 v8, v22, v58, v8                           // 000000810284: CC1A4008 1C227516
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 00000081028C: BF890477
	v_dot2_f32_bf16 v8, v41, v59, v8                           // 000000810290: CC1A4008 1C227729
	s_waitcnt lgkmcnt(6)                                       // 000000810298: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000081029C: BF8700A1
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 0000008102A0: CC1A4008 1C22792A
	s_waitcnt lgkmcnt(5)                                       // 0000008102A8: BF89FC57
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 0000008102AC: CC1A4008 1C227B2B
	s_waitcnt lgkmcnt(4)                                       // 0000008102B4: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008102B8: BF8700A1
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 0000008102BC: CC1A4008 1C227D2C
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 0000008102C4: BF890037
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 0000008102C8: CC1A4008 1C227F2D
	.long 0xd7006a2d                                           // 0000008102D0: D7006A2D
	v_cndmask_b32_e32 v0, v12, v4, vcc_lo                      // 0000008102D4: 0200090C
	s_waitcnt lgkmcnt(2)                                       // 0000008102D8: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000008102DC: BF8701C2
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 0000008102E0: CC1A4008 1C22812E
	v_add_co_ci_u32_e64 v46, null, s5, v13, vcc_lo             // 0000008102E8: D5207C2E 01AA1A05
	.long 0xd7006a31                                           // 0000008102F0: D7006A31
	v_cndmask_b32_e32 v0, v12, v14, vcc_lo                     // 0000008102F4: 02001D0C
	s_waitcnt lgkmcnt(1)                                       // 0000008102F8: BF89FC17
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 0000008102FC: CC1A4008 1C22832F
	v_add_co_ci_u32_e64 v50, null, s15, v13, vcc_lo            // 000000810304: D5207C32 01AA1A0F
	.long 0xd7006a0c                                           // 00000081030C: D7006A0C
	v_cndmask_b32_e32 v0, v12, v17, vcc_lo                     // 000000810310: 0200230C
	s_waitcnt lgkmcnt(0)                                       // 000000810314: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000810318: BF870123
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 00000081031C: CC1A4008 1C228530
	v_add_co_ci_u32_e64 v13, null, s18, v13, vcc_lo            // 000000810324: D5207C0D 01AA1A12
	v_fmac_f32_e32 v37, v51, v8                                // 00000081032C: 564A1133
	s_clause 0x3                                               // 000000810330: BF850003
	global_load_b128 v[8:11], v[45:46], off                    // 000000810334: DC5E0000 087C002D
	global_load_b128 v[19:22], v[45:46], off offset:16         // 00000081033C: DC5E0010 137C002D
	global_load_b128 v[41:44], v[45:46], off offset:32         // 000000810344: DC5E0020 297C002D
	global_load_b128 v[45:48], v[45:46], off offset:48         // 00000081034C: DC5E0030 2D7C002D
	s_waitcnt vmcnt(3)                                         // 000000810354: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 000000810358: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000810360: BF870091
	v_dot2_f32_bf16 v8, v9, v52, v8                            // 000000810364: CC1A4008 1C226909
	v_dot2_f32_bf16 v8, v10, v53, v8                           // 00000081036C: CC1A4008 1C226B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000810374: BF8700A1
	v_dot2_f32_bf16 v8, v11, v54, v8                           // 000000810378: CC1A4008 1C226D0B
	s_waitcnt vmcnt(2)                                         // 000000810380: BF890BF7
	v_dot2_f32_bf16 v8, v19, v55, v8                           // 000000810384: CC1A4008 1C226F13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081038C: BF870091
	v_dot2_f32_bf16 v8, v20, v56, v8                           // 000000810390: CC1A4008 1C227114
	v_dot2_f32_bf16 v8, v21, v57, v8                           // 000000810398: CC1A4008 1C227315
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008103A0: BF8700A1
	v_dot2_f32_bf16 v8, v22, v58, v8                           // 0000008103A4: CC1A4008 1C227516
	s_waitcnt vmcnt(1)                                         // 0000008103AC: BF8907F7
	v_dot2_f32_bf16 v8, v41, v59, v8                           // 0000008103B0: CC1A4008 1C227729
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008103B8: BF870091
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 0000008103BC: CC1A4008 1C22792A
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 0000008103C4: CC1A4008 1C227B2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008103CC: BF8700A1
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 0000008103D0: CC1A4008 1C227D2C
	s_waitcnt vmcnt(0)                                         // 0000008103D8: BF8903F7
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 0000008103DC: CC1A4008 1C227F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008103E4: BF870091
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 0000008103E8: CC1A4008 1C22812E
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 0000008103F0: CC1A4008 1C22832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008103F8: BF870091
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 0000008103FC: CC1A4008 1C228530
	v_fmac_f32_e32 v36, v51, v8                                // 000000810404: 56481133
	s_clause 0x3                                               // 000000810408: BF850003
	global_load_b128 v[8:11], v[49:50], off                    // 00000081040C: DC5E0000 087C0031
	global_load_b128 v[19:22], v[49:50], off offset:16         // 000000810414: DC5E0010 137C0031
	global_load_b128 v[41:44], v[49:50], off offset:32         // 00000081041C: DC5E0020 297C0031
	global_load_b128 v[45:48], v[49:50], off offset:48         // 000000810424: DC5E0030 2D7C0031
	s_waitcnt vmcnt(3)                                         // 00000081042C: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 000000810430: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000810438: BF870091
	v_dot2_f32_bf16 v8, v9, v52, v8                            // 00000081043C: CC1A4008 1C226909
	v_dot2_f32_bf16 v8, v10, v53, v8                           // 000000810444: CC1A4008 1C226B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000081044C: BF8700A1
	v_dot2_f32_bf16 v8, v11, v54, v8                           // 000000810450: CC1A4008 1C226D0B
	s_waitcnt vmcnt(2)                                         // 000000810458: BF890BF7
	v_dot2_f32_bf16 v8, v19, v55, v8                           // 00000081045C: CC1A4008 1C226F13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000810464: BF870091
	v_dot2_f32_bf16 v8, v20, v56, v8                           // 000000810468: CC1A4008 1C227114
	v_dot2_f32_bf16 v8, v21, v57, v8                           // 000000810470: CC1A4008 1C227315
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000810478: BF8700A1
	v_dot2_f32_bf16 v8, v22, v58, v8                           // 00000081047C: CC1A4008 1C227516
	s_waitcnt vmcnt(1)                                         // 000000810484: BF8907F7
	v_dot2_f32_bf16 v8, v41, v59, v8                           // 000000810488: CC1A4008 1C227729
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000810490: BF870091
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 000000810494: CC1A4008 1C22792A
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 00000081049C: CC1A4008 1C227B2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008104A4: BF8700A1
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 0000008104A8: CC1A4008 1C227D2C
	s_waitcnt vmcnt(0)                                         // 0000008104B0: BF8903F7
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 0000008104B4: CC1A4008 1C227F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008104BC: BF870091
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 0000008104C0: CC1A4008 1C22812E
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 0000008104C8: CC1A4008 1C22832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008104D0: BF870091
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 0000008104D4: CC1A4008 1C228530
	v_fmac_f32_e32 v35, v51, v8                                // 0000008104DC: 56461133
	s_clause 0x3                                               // 0000008104E0: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 0000008104E4: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 0000008104EC: DC5E0010 137C000C
	global_load_b128 v[41:44], v[12:13], off offset:32         // 0000008104F4: DC5E0020 297C000C
	global_load_b128 v[45:48], v[12:13], off offset:48         // 0000008104FC: DC5E0030 2D7C000C
	.long 0xd7006a0c                                           // 000000810504: D7006A0C
	v_cndmask_b32_e32 v0, v49, v14, vcc_lo                     // 000000810508: 02001D31
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000081050C: BF8700A1
	v_add_co_ci_u32_e64 v13, null, s15, v50, vcc_lo            // 000000810510: D5207C0D 01AA640F
	.long 0xd7006a1c                                           // 000000810518: D7006A1C
	v_cndmask_b32_e32 v0, v28, v160, vcc_lo                    // 00000081051C: 0201411C
	v_add_co_ci_u32_e64 v29, null, 0, v29, vcc_lo              // 000000810520: D5207C1D 01AA3A80
	s_waitcnt vmcnt(3)                                         // 000000810528: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000081052C: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000810534: BF870091
	v_dot2_f32_bf16 v8, v9, v52, v8                            // 000000810538: CC1A4008 1C226909
	v_dot2_f32_bf16 v8, v10, v53, v8                           // 000000810540: CC1A4008 1C226B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000810548: BF8700A1
	v_dot2_f32_bf16 v8, v11, v54, v8                           // 00000081054C: CC1A4008 1C226D0B
	s_waitcnt vmcnt(2)                                         // 000000810554: BF890BF7
	v_dot2_f32_bf16 v8, v19, v55, v8                           // 000000810558: CC1A4008 1C226F13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000810560: BF870091
	v_dot2_f32_bf16 v8, v20, v56, v8                           // 000000810564: CC1A4008 1C227114
	v_dot2_f32_bf16 v8, v21, v57, v8                           // 00000081056C: CC1A4008 1C227315
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000810574: BF8700A1
	v_dot2_f32_bf16 v8, v22, v58, v8                           // 000000810578: CC1A4008 1C227516
	s_waitcnt vmcnt(1)                                         // 000000810580: BF8907F7
	v_dot2_f32_bf16 v8, v41, v59, v8                           // 000000810584: CC1A4008 1C227729
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081058C: BF870091
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 000000810590: CC1A4008 1C22792A
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 000000810598: CC1A4008 1C227B2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008105A0: BF8700A1
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 0000008105A4: CC1A4008 1C227D2C
	s_waitcnt vmcnt(0)                                         // 0000008105AC: BF8903F7
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 0000008105B0: CC1A4008 1C227F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008105B8: BF870091
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 0000008105BC: CC1A4008 1C22812E
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 0000008105C4: CC1A4008 1C22832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008105CC: BF870091
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 0000008105D0: CC1A4008 1C228530
	v_fmac_f32_e32 v34, v51, v8                                // 0000008105D8: 56441133
	s_clause 0x3                                               // 0000008105DC: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 0000008105E0: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 0000008105E8: DC5E0010 137C000C
	global_load_b128 v[41:44], v[12:13], off offset:32         // 0000008105F0: DC5E0020 297C000C
	global_load_b128 v[45:48], v[12:13], off offset:48         // 0000008105F8: DC5E0030 2D7C000C
	s_waitcnt vmcnt(3)                                         // 000000810600: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 000000810604: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081060C: BF870091
	v_dot2_f32_bf16 v8, v9, v52, v8                            // 000000810610: CC1A4008 1C226909
	v_dot2_f32_bf16 v8, v10, v53, v8                           // 000000810618: CC1A4008 1C226B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000810620: BF8700A1
	v_dot2_f32_bf16 v8, v11, v54, v8                           // 000000810624: CC1A4008 1C226D0B
	s_waitcnt vmcnt(2)                                         // 00000081062C: BF890BF7
	v_dot2_f32_bf16 v8, v19, v55, v8                           // 000000810630: CC1A4008 1C226F13
	v_mov_b32_e32 v19, v15                                     // 000000810638: 7E26030F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000081063C: BF870122
	v_dot2_f32_bf16 v8, v20, v56, v8                           // 000000810640: CC1A4008 1C227114
	v_mov_b32_e32 v20, v16                                     // 000000810648: 7E280310
	v_dot2_f32_bf16 v8, v21, v57, v8                           // 00000081064C: CC1A4008 1C227315
	v_mov_b32_e32 v21, v17                                     // 000000810654: 7E2A0311
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000810658: BF870132
	v_dot2_f32_bf16 v8, v22, v58, v8                           // 00000081065C: CC1A4008 1C227516
	v_mov_b32_e32 v22, v18                                     // 000000810664: 7E2C0312
	s_waitcnt vmcnt(1)                                         // 000000810668: BF8907F7
	v_dot2_f32_bf16 v8, v41, v59, v8                           // 00000081066C: CC1A4008 1C227729
	v_mov_b32_e32 v41, v40                                     // 000000810674: 7E520328
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000810678: BF870092
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 00000081067C: CC1A4008 1C22792A
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 000000810684: CC1A4008 1C227B2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000081068C: BF8700A1
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 000000810690: CC1A4008 1C227D2C
	s_waitcnt vmcnt(0)                                         // 000000810698: BF8903F7
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 00000081069C: CC1A4008 1C227F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008106A4: BF870091
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 0000008106A8: CC1A4008 1C22812E
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 0000008106B0: CC1A4008 1C22832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008106B8: BF870091
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 0000008106BC: CC1A4008 1C228530
	v_fmac_f32_e32 v33, v51, v8                                // 0000008106C4: 56421133
	v_mov_b32_e32 v14, v7                                      // 0000008106C8: 7E1C0307
	v_dual_mov_b32 v13, v6 :: v_dual_mov_b32 v12, v5           // 0000008106CC: CA100106 0D0C0105
	v_dual_mov_b32 v11, v4 :: v_dual_mov_b32 v10, v3           // 0000008106D4: CA100104 0B0A0103
	v_dual_mov_b32 v9, v2 :: v_dual_mov_b32 v8, v1             // 0000008106DC: CA100102 09080101
	v_mov_b32_e32 v7, v0                                       // 0000008106E4: 7E0E0300
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 0000008106E8: 917E107E
	s_cbranch_execz 28                                         // 0000008106EC: BFA5001C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0xc60>
	s_waitcnt vmcnt(0)                                         // 0000008106F0: BF8903F7
	v_dual_mov_b32 v16, v20 :: v_dual_add_nc_u32 v39, 16, v39  // 0000008106F4: CA200114 10264E90
	v_dual_mov_b32 v15, v19 :: v_dual_mov_b32 v18, v22         // 0000008106FC: CA100113 0F120116
	v_mov_b32_e32 v17, v21                                     // 000000810704: 7E220315
	s_delay_alu instid0(VALU_DEP_3)                            // 000000810708: BF870003
	.long 0xd4430002                                           // 00000081070C: D4430002
	v_cndmask_b32_e32 v1, s20, v39, vcc_lo                     // 000000810710: 02024E14
	s_mov_b32 s10, exec_lo                                     // 000000810714: BE8A007E
	.long 0xd4c4007e                                           // 000000810718: D4C4007E
	v_cndmask_b32_e32 v1, s20, v39, vcc_lo                     // 00000081071C: 02024E14
	s_cbranch_execz 65086                                      // 000000810720: BFA5FE3E <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x51c>
	.long 0xd7006a00                                           // 000000810724: D7006A00
	v_cndmask_b32_e32 v1, v25, v38, vcc_lo                     // 000000810728: 02024D19
	s_delay_alu instid0(VALU_DEP_1)                            // 00000081072C: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v32, vcc_lo               // 000000810730: D5207C01 01AA4080
	v_cmp_ne_u32_e32 vcc_lo, 1, v31                            // 000000810738: 7C9A3E81
	v_mov_b32_e32 v40, v41                                     // 00000081073C: 7E500329
	global_load_b128 v[15:18], v[0:1], off                     // 000000810740: DC5E0000 0F7C0000
	s_cbranch_vccnz 65076                                      // 000000810748: BFA4FE34 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x51c>
	global_load_d16_b16 v0, v[28:29], off                      // 00000081074C: DC820000 007C001C
	s_waitcnt vmcnt(0)                                         // 000000810754: BF8903F7
	v_cvt_f32_f16_e32 v40, v0                                  // 000000810758: 7E501700
	s_branch 65071                                             // 00000081075C: BFA0FE2F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x51c>
	s_or_b32 exec_lo, exec_lo, s16                             // 000000810760: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000810764: BF8700A9
	s_or_b32 exec_lo, exec_lo, s3                              // 000000810768: 8C7E037E
	.long 0xd71f0000                                           // 00000081076C: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000810770: 020100C1
	v_xor_b32_e32 v1, 8, v0                                    // 000000810774: 3A020088
	v_xor_b32_e32 v6, 4, v0                                    // 000000810778: 3A0C0084
	v_xor_b32_e32 v11, 2, v0                                   // 00000081077C: 3A160082
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000810780: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v1                            // 000000810784: 7C9802A0
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 000000810788: 02020300
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 00000081078C: 7C980CA0
	v_cndmask_b32_e32 v6, v0, v6, vcc_lo                       // 000000810790: 020C0D00
	v_cmp_gt_u32_e32 vcc_lo, 32, v11                           // 000000810794: 7C9816A0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000810798: BF870002
	v_lshlrev_b32_e32 v6, 2, v6                                // 00000081079C: 300C0C82
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000008107A0: 30020282
	ds_bpermute_b32 v2, v1, v37                                // 0000008107A4: DACC0000 02002501
	s_waitcnt lgkmcnt(0)                                       // 0000008107AC: BF89FC07
	v_add_f32_e32 v2, v37, v2                                  // 0000008107B0: 06040525
	ds_bpermute_b32 v3, v1, v36                                // 0000008107B4: DACC0000 03002401
	ds_bpermute_b32 v4, v1, v35                                // 0000008107BC: DACC0000 04002301
	ds_bpermute_b32 v5, v1, v34                                // 0000008107C4: DACC0000 05002201
	ds_bpermute_b32 v1, v1, v33                                // 0000008107CC: DACC0000 01002101
	ds_bpermute_b32 v7, v6, v2                                 // 0000008107D4: DACC0000 07000206
	s_waitcnt lgkmcnt(3)                                       // 0000008107DC: BF89FC37
	v_dual_add_f32 v3, v36, v3 :: v_dual_add_f32 v4, v35, v4   // 0000008107E0: C9080724 03040923
	s_waitcnt lgkmcnt(2)                                       // 0000008107E8: BF89FC27
	v_add_f32_e32 v5, v34, v5                                  // 0000008107EC: 060A0B22
	s_waitcnt lgkmcnt(0)                                       // 0000008107F0: BF89FC07
	v_dual_add_f32 v1, v33, v1 :: v_dual_add_f32 v2, v2, v7    // 0000008107F4: C9080321 01020F02
	ds_bpermute_b32 v8, v6, v3                                 // 0000008107FC: DACC0000 08000306
	ds_bpermute_b32 v9, v6, v4                                 // 000000810804: DACC0000 09000406
	v_cndmask_b32_e32 v11, v0, v11, vcc_lo                     // 00000081080C: 02161700
	ds_bpermute_b32 v10, v6, v5                                // 000000810810: DACC0000 0A000506
	ds_bpermute_b32 v6, v6, v1                                 // 000000810818: DACC0000 06000106
	v_lshlrev_b32_e32 v11, 2, v11                              // 000000810820: 30161682
	s_waitcnt lgkmcnt(2)                                       // 000000810824: BF89FC27
	v_dual_add_f32 v3, v3, v8 :: v_dual_add_f32 v4, v4, v9     // 000000810828: C9081103 03041304
	s_waitcnt lgkmcnt(0)                                       // 000000810830: BF89FC07
	v_add_f32_e32 v1, v1, v6                                   // 000000810834: 06020D01
	ds_bpermute_b32 v6, v11, v2                                // 000000810838: DACC0000 0600020B
	ds_bpermute_b32 v8, v11, v4                                // 000000810840: DACC0000 0800040B
	v_add_f32_e32 v5, v5, v10                                  // 000000810848: 060A1505
	ds_bpermute_b32 v7, v11, v3                                // 00000081084C: DACC0000 0700030B
	ds_bpermute_b32 v10, v11, v1                               // 000000810854: DACC0000 0A00010B
	s_waitcnt lgkmcnt(3)                                       // 00000081085C: BF89FC37
	v_add_f32_e32 v2, v2, v6                                   // 000000810860: 06040D02
	s_waitcnt lgkmcnt(2)                                       // 000000810864: BF89FC27
	v_add_f32_e32 v4, v4, v8                                   // 000000810868: 06081104
	ds_bpermute_b32 v9, v11, v5                                // 00000081086C: DACC0000 0900050B
	v_xor_b32_e32 v11, 1, v0                                   // 000000810874: 3A160081
	s_delay_alu instid0(VALU_DEP_1)                            // 000000810878: BF870001
	v_cmp_gt_u32_e32 vcc_lo, 32, v11                           // 00000081087C: 7C9816A0
	v_cndmask_b32_e32 v0, v0, v11, vcc_lo                      // 000000810880: 02001700
	s_waitcnt lgkmcnt(2)                                       // 000000810884: BF89FC27
	v_add_f32_e32 v3, v3, v7                                   // 000000810888: 06060F03
	v_cmp_eq_u32_e32 vcc_lo, 0, v30                            // 00000081088C: 7C943C80
	s_waitcnt lgkmcnt(1)                                       // 000000810890: BF89FC17
	v_dual_add_f32 v0, v1, v10 :: v_dual_lshlrev_b32 v11, 2, v0// 000000810894: C9221501 000A0082
	s_and_b32 s0, vcc_lo, s0                                   // 00000081089C: 8B00006A
	s_waitcnt lgkmcnt(0)                                       // 0000008108A0: BF89FC07
	v_add_f32_e32 v5, v5, v9                                   // 0000008108A4: 060A1305
	ds_bpermute_b32 v6, v11, v2                                // 0000008108A8: DACC0000 0600020B
	ds_bpermute_b32 v7, v11, v3                                // 0000008108B0: DACC0000 0700030B
	ds_bpermute_b32 v8, v11, v4                                // 0000008108B8: DACC0000 0800040B
	ds_bpermute_b32 v1, v11, v0                                // 0000008108C0: DACC0000 0100000B
	ds_bpermute_b32 v9, v11, v5                                // 0000008108C8: DACC0000 0900050B
	s_and_saveexec_b32 s1, s0                                  // 0000008108D0: BE812000
	s_cbranch_execz 253                                        // 0000008108D4: BFA500FD <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x11cc>
	s_waitcnt lgkmcnt(3)                                       // 0000008108D8: BF89FC37
	v_dual_add_f32 v2, v2, v6 :: v_dual_add_f32 v3, v3, v7     // 0000008108DC: C9080D02 02020F03
	s_waitcnt lgkmcnt(0)                                       // 0000008108E4: BF89FC07
	v_dual_add_f32 v4, v4, v8 :: v_dual_add_f32 v5, v5, v9     // 0000008108E8: C9081104 04041305
	.long 0x7f183880                                           // 0000008108F0: 7F183880
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000008108F4: BF870223
	v_bfe_u32 v6, v2, 16, 1                                    // 0000008108F8: D6100006 02052102
	v_bfe_u32 v7, v3, 16, 1                                    // 000000810900: D6100007 02052103
	v_bfe_u32 v8, v4, 16, 1                                    // 000000810908: D6100008 02052104
	v_bfe_u32 v9, v5, 16, 1                                    // 000000810910: D6100009 02052105
	.long 0x7f22398c                                           // 000000810918: 7F22398C
	v_add3_u32 v2, v2, v6, 0x7fff                              // 00000081091C: D6550002 03FE0D02 00007FFF
	v_add3_u32 v3, v3, v7, 0x7fff                              // 000000810928: D6550003 03FE0F03 00007FFF
	v_add3_u32 v4, v4, v8, 0x7fff                              // 000000810934: D6550004 03FE1104 00007FFF
	v_add3_u32 v5, v5, v9, 0x7fff                              // 000000810940: D6550005 03FE1305 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000081094C: BF870214
	v_dual_add_f32 v0, v0, v1 :: v_dual_and_b32 v1, 0xffff0000, v2// 000000810950: C9240300 000004FF FFFF0000
	v_and_b32_e32 v2, 0xffff0000, v3                           // 00000081095C: 360406FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000810964: BF870214
	v_and_b32_e32 v3, 0xffff0000, v4                           // 000000810968: 360608FF FFFF0000
	v_and_b32_e32 v4, 0xffff0000, v5                           // 000000810970: 36080AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000810978: BF870134
	v_bfe_u32 v5, v0, 16, 1                                    // 00000081097C: D6100005 02052100
	v_mul_f32_e32 v1, 0xbfb8aa3b, v1                           // 000000810984: 100202FF BFB8AA3B
	s_lshl_b64 s[4:5], s[12:13], 1                             // 00000081098C: 8484810C
	v_add3_u32 v0, v0, v5, 0x7fff                              // 000000810990: D6550000 03FE0B00 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081099C: BF870092
	v_exp_f32_e32 v5, v1                                       // 0000008109A0: 7E0A4B01
	v_and_b32_e32 v6, 0xffff0000, v0                           // 0000008109A4: 360C00FF FFFF0000
	.long 0xd73c0000                                           // 0000008109AC: D73C0000
	v_cndmask_b32_e32 v1, 1, v23, vcc_lo                       // 0000008109B0: 02022E81
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008109B4: BF8700A5
	v_dual_add_f32 v5, 1.0, v5 :: v_dual_mul_f32 v2, 0xbfb8aa3b, v2// 0000008109B8: C9060AF2 050204FF BFB8AA3B
	s_waitcnt vmcnt(0)                                         // 0000008109C4: BF8903F7
	v_div_scale_f32 v19, vcc_lo, 1.0, v5, 1.0                  // 0000008109C8: D6FC6A13 03CA0AF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000008109D0: BF870292
	v_exp_f32_e32 v2, v2                                       // 0000008109D4: 7E044B02
	v_dual_add_f32 v2, 1.0, v2 :: v_dual_mul_f32 v3, 0xbfb8aa3b, v3// 0000008109D8: C90604F2 020206FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008109E4: BF870111
	v_div_scale_f32 v20, s0, 1.0, v2, 1.0                      // 0000008109E8: D6FC0014 03CA04F2
	v_exp_f32_e32 v3, v3                                       // 0000008109F0: 7E064B03
	v_div_scale_f32 v9, null, v2, v2, 1.0                      // 0000008109F4: D6FC7C09 03CA0502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000008109FC: BF870311
	v_rcp_f32_e32 v14, v9                                      // 000000810A00: 7E1C5509
	v_dual_add_f32 v7, 1.0, v3 :: v_dual_mul_f32 v4, 0xbfb8aa3b, v4// 000000810A04: C90606F2 070408FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000810A10: BF870111
	v_div_scale_f32 v10, null, v7, v7, 1.0                     // 000000810A14: D6FC7C0A 03CA0F07
	v_exp_f32_e32 v4, v4                                       // 000000810A1C: 7E084B04
	v_div_scale_f32 v21, s1, 1.0, v7, 1.0                      // 000000810A20: D6FC0115 03CA0EF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000810A28: BF870292
	v_rcp_f32_e32 v15, v10                                     // 000000810A2C: 7E1E550A
	v_fma_f32 v22, -v10, v15, 1.0                              // 000000810A30: D6130016 23CA1F0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000810A38: BF870091
	v_dual_mul_f32 v6, 0xbfb8aa3b, v6 :: v_dual_fmac_f32 v15, v22, v15// 000000810A3C: C8C00CFF 060E1F16 BFB8AA3B
	v_exp_f32_e32 v3, v6                                       // 000000810A48: 7E064B06
	v_div_scale_f32 v6, null, v5, v5, 1.0                      // 000000810A4C: D6FC7C06 03CA0B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000810A54: BF870311
	v_rcp_f32_e32 v13, v6                                      // 000000810A58: 7E1A5506
	v_add_f32_e32 v18, 1.0, v3                                 // 000000810A5C: 062406F2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000810A60: BF870095
	v_fma_f32 v3, -v6, v13, 1.0                                // 000000810A64: D6130003 23CA1B06
	v_dual_fmac_f32 v13, v3, v13 :: v_dual_add_f32 v8, 1.0, v4 // 000000810A6C: C8081B03 0D0808F2
	v_fma_f32 v4, -v9, v14, 1.0                                // 000000810A74: D6130004 23CA1D09
	.long 0xd7000303                                           // 000000810A7C: D7000303
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 000000810A80: 02020008
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000810A84: BF870093
	v_div_scale_f32 v11, null, v8, v8, 1.0                     // 000000810A88: D6FC7C0B 03CA1108
	v_rcp_f32_e32 v16, v11                                     // 000000810A90: 7E20550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000810A94: BF870095
	v_fma_f32 v23, -v11, v16, 1.0                              // 000000810A98: D6130017 23CA210B
	v_fmac_f32_e32 v16, v23, v16                               // 000000810AA0: 56202117
	v_mul_f32_e32 v23, v19, v13                                // 000000810AA4: 102E1B13
	v_div_scale_f32 v24, s2, 1.0, v8, 1.0                      // 000000810AA8: D6FC0218 03CA10F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000810AB0: BF8701B2
	v_fma_f32 v29, -v6, v23, v19                               // 000000810AB4: D613001D 244E2F06
	v_fmac_f32_e32 v14, v4, v14                                // 000000810ABC: 561C1D04
	v_add_co_ci_u32_e64 v4, null, s9, v1, s3                   // 000000810AC0: D5207C04 000E0209
	v_fmac_f32_e32 v23, v29, v13                               // 000000810AC8: 562E1B1D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000810ACC: BF8701A3
	v_mul_f32_e32 v25, v20, v14                                // 000000810AD0: 10321D14
	v_div_scale_f32 v22, null, v18, v18, 1.0                   // 000000810AD4: D6FC7C16 03CA2512
	v_fma_f32 v1, -v6, v23, v19                                // 000000810ADC: D6130001 244E2F06
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000810AE4: BF870193
	v_fma_f32 v30, -v9, v25, v20                               // 000000810AE8: D613001E 24523309
	v_rcp_f32_e32 v28, v22                                     // 000000810AF0: 7E385516
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000810AF4: BF870112
	v_div_fmas_f32 v1, v1, v13, v23                            // 000000810AF8: D6370001 045E1B01
	v_dual_fmac_f32 v25, v30, v14 :: v_dual_mul_f32 v26, v21, v15// 000000810B00: C8061D1E 191A1F15
	v_mul_f32_e32 v27, v24, v16                                // 000000810B08: 10362118
	s_mov_b32 vcc_lo, s0                                       // 000000810B0C: BEEA0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000810B10: BF870193
	v_div_fixup_f32 v1, v1, v5, 1.0                            // 000000810B14: D6270001 03CA0B01
	v_fma_f32 v6, -v9, v25, v20                                // 000000810B1C: D6130006 24523309
	v_fma_f32 v31, -v10, v26, v21                              // 000000810B24: D613001F 2456350A
	v_fma_f32 v32, -v11, v27, v24                              // 000000810B2C: D6130020 2462370B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000810B34: BF870235
	v_fma_f32 v0, -v22, v28, 1.0                               // 000000810B38: D6130000 23CA3916
	.long 0x7e223981                                           // 000000810B40: 7E223981
	v_div_fmas_f32 v6, v6, v14, v25                            // 000000810B44: D6370006 04661D06
	v_dual_fmac_f32 v26, v31, v15 :: v_dual_fmac_f32 v27, v32, v16// 000000810B4C: C8001F1F 1A1A2120
	s_mov_b32 vcc_lo, s1                                       // 000000810B54: BEEA0001
	v_fmac_f32_e32 v28, v0, v28                                // 000000810B58: 56383900
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000810B5C: BF870193
	v_div_fixup_f32 v2, v6, v2, 1.0                            // 000000810B60: D6270002 03CA0506
	v_fma_f32 v9, -v10, v26, v21                               // 000000810B68: D6130009 2456350A
	v_fma_f32 v10, -v11, v27, v24                              // 000000810B70: D613000A 2462370B
	v_div_scale_f32 v0, s3, 1.0, v18, 1.0                      // 000000810B78: D6FC0300 03CA24F2
	s_lshl_b64 s[0:1], s[12:13], 2                             // 000000810B80: 8480820C
	.long 0x7e183982                                           // 000000810B84: 7E183982
	v_div_fmas_f32 v9, v9, v15, v26                            // 000000810B88: D6370009 046A1F09
	s_mov_b32 vcc_lo, s2                                       // 000000810B90: BEEA0002
	v_div_fmas_f32 v6, v10, v16, v27                           // 000000810B94: D6370006 046E210A
	s_mov_b32 vcc_lo, s3                                       // 000000810B9C: BEEA0003
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000810BA0: BF8701A2
	v_div_fixup_f32 v9, v9, v7, 1.0                            // 000000810BA4: D6270009 03CA0F09
	.long 0x7f0e398c                                           // 000000810BAC: 7F0E398C
	v_div_fixup_f32 v10, v6, v8, 1.0                           // 000000810BB0: D627000A 03CA1106
	v_and_b32_e32 v6, 1, v12                                   // 000000810BB8: 360C1881
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000810BBC: BF870224
	.long 0x7e0e3989                                           // 000000810BC0: 7E0E3989
	v_mul_f32_e32 v11, v0, v28                                 // 000000810BC4: 10163900
	.long 0x7e18398a                                           // 000000810BC8: 7E18398A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000810BCC: BF870114
	v_add3_u32 v14, v2, v6, 0x7fff                             // 000000810BD0: D655000E 03FE0D02 00007FFF
	v_and_b32_e32 v2, 1, v12                                   // 000000810BDC: 36041881
	v_and_b32_e32 v12, 1, v7                                   // 000000810BE0: 36180E81
	v_fma_f32 v5, -v22, v11, v0                                // 000000810BE4: D6130005 24021716
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000810BEC: BF870193
	v_add3_u32 v16, v10, v2, 0x7fff                            // 000000810BF0: D6550010 03FE050A 00007FFF
	v_add3_u32 v12, v9, v12, 0x7fff                            // 000000810BFC: D655000C 03FE1909 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000810C08: BF870123
	v_fmac_f32_e32 v11, v5, v28                                // 000000810C0C: 56163905
	v_and_b32_e32 v5, 1, v17                                   // 000000810C10: 360A2281
	v_fma_f32 v0, -v22, v11, v0                                // 000000810C14: D6130000 24021716
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000810C1C: BF870112
	v_add3_u32 v13, v1, v5, 0x7fff                             // 000000810C20: D655000D 03FE0B01 00007FFF
	v_div_fmas_f32 v0, v0, v28, v11                            // 000000810C2C: D6370000 042E3900
	.long 0xd7006a05                                           // 000000810C34: D7006A05
	v_cndmask_b32_e32 v0, v3, v4, vcc_lo                       // 000000810C38: 02000903
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000810C3C: BF870191
	v_add_co_ci_u32_e64 v6, null, s5, v4, vcc_lo               // 000000810C40: D5207C06 01AA0805
	v_div_fixup_f32 v11, v0, v18, 1.0                          // 000000810C48: D627000B 03CA2500
	v_mad_u64_u32 v[0:1], null, s12, 6, v[3:4]                 // 000000810C50: D6FE7C00 040D0C0C
	.long 0xd7006a07                                           // 000000810C58: D7006A07
	v_cndmask_b32_e32 v0, v3, v0, vcc_lo                       // 000000810C5C: 02000103
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000810C60: BF870211
	v_add_co_ci_u32_e64 v8, null, s1, v4, vcc_lo               // 000000810C64: D5207C08 01AA0801
	v_bfe_u32 v15, v11, 16, 1                                  // 000000810C6C: D610000F 0205210B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000810C74: BF870223
	.long 0xd7006a09                                           // 000000810C78: D7006A09
	v_cndmask_b32_e32 v0, v7, v0, vcc_lo                       // 000000810C7C: 02000107
	v_mad_u64_u32 v[1:2], null, s13, 6, v[1:2]                 // 000000810C80: D6FE7C01 04050C0D
	v_add_co_ci_u32_e64 v10, null, s1, v8, vcc_lo              // 000000810C88: D5207C0A 01AA1001
	s_delay_alu instid0(VALU_DEP_4)                            // 000000810C90: BF870004
	v_add3_u32 v2, v11, v15, 0x7fff                            // 000000810C94: D6550002 03FE1F0B 00007FFF
	s_clause 0x4                                               // 000000810CA0: BF850004
	global_store_d16_hi_b16 v[3:4], v13, off                   // 000000810CA4: DC960000 007C0D03
	global_store_d16_hi_b16 v[5:6], v14, off                   // 000000810CAC: DC960000 007C0E05
	global_store_d16_hi_b16 v[7:8], v12, off                   // 000000810CB4: DC960000 007C0C07
	global_store_d16_hi_b16 v[0:1], v16, off                   // 000000810CBC: DC960000 007C1000
	global_store_d16_hi_b16 v[9:10], v2, off                   // 000000810CC4: DC960000 007C0209
	s_endpgm                                                   // 000000810CCC: BFB00000
		...

