0000000000764d00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000764D00: F4100100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 000000764D08: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 000000764D0C: 32040082
	v_lshrrev_b32_e32 v29, 5, v0                               // 000000764D10: 323A0085
	v_and_b32_e32 v30, 31, v0                                  // 000000764D14: 363C009F
	.long 0x7f0a3880                                           // 000000764D18: 7F0A3880
	v_lshlrev_b32_e32 v28, 2, v0                               // 000000764D1C: 30380082
	s_waitcnt lgkmcnt(0)                                       // 000000764D20: BF89FC07
	.long 0xd4510000                                           // 000000764D24: D4510000
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 000000764D28: 02001802
	s_and_b32 s0, s0, exec_lo                                  // 000000764D2C: 8B007E00
	s_cselect_b32 s20, s3, 0                                   // 000000764D30: 98148003
	s_cselect_b32 s21, s2, 0                                   // 000000764D34: 98158002
	s_add_u32 s0, s4, s16                                      // 000000764D38: 80001004
	s_addc_u32 s1, s5, s17                                     // 000000764D3C: 82011105
	v_and_b32_e32 v1, 15, v0                                   // 000000764D40: 3602008F
	v_and_b32_e32 v2, 60, v2                                   // 000000764D44: 360404BC
	s_ashr_i32 s16, s11, 31                                    // 000000764D48: 86109F0B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000764D4C: BF870119
	s_lshr_b32 s16, s16, 27                                    // 000000764D50: 85109B10
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000764D54: 30020282
	s_add_u32 s16, s10, s16                                    // 000000764D58: 8010100A
	s_clause 0x1                                               // 000000764D5C: BF850001
	global_load_b32 v3, v1, s[4:5]                             // 000000764D60: DC520000 03040001
	global_load_b32 v4, v2, s[4:5]                             // 000000764D68: DC520000 04040002
	s_addc_u32 s17, s11, 0                                     // 000000764D70: 8211800B
	v_mov_b32_e32 v2, s1                                       // 000000764D74: 7E040201
	s_lshr_b64 s[16:17], s[16:17], 5                           // 000000764D78: 85908510
	v_mov_b32_e32 v1, s0                                       // 000000764D7C: 7E020200
	s_add_i32 s17, s16, 7                                      // 000000764D80: 81118710
	s_mul_i32 s1, s19, s21                                     // 000000764D84: 96011513
	s_ashr_i32 s22, s17, 31                                    // 000000764D88: 86169F11
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000764D8C: BF8704B9
	s_lshr_b32 s0, s22, 29                                     // 000000764D90: 85009D16
	v_mad_u64_u32 v[24:25], null, s18, s21, v[1:2]             // 000000764D94: D6FE7C18 04042A12
	s_add_i32 s17, s17, s0                                     // 000000764D9C: 81110011
	s_ashr_i32 s0, s17, 3                                      // 000000764DA0: 86008311
	s_cmpk_lt_i32 s16, 0x801                                   // 000000764DA4: B3900801
	.long 0xd72c0001                                           // 000000764DA8: D72C0001
	v_cndmask_b32_e32 v1, s0, v29, vcc_lo                      // 000000764DAC: 02023A00
	s_mul_i32 s17, s18, s20                                    // 000000764DB0: 96111412
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000764DB4: BF870141
	v_add_nc_u32_e32 v7, s0, v1                                // 000000764DB8: 4A0E0200
	v_add_nc_u32_e32 v31, v1, v30                              // 000000764DBC: 4A3E3D01
	s_cselect_b32 s0, -1, 0                                    // 000000764DC0: 980080C1
	s_cmpk_gt_i32 s16, 0x800                                   // 000000764DC4: B2900800
	v_min_i32_e32 v32, s16, v7                                 // 000000764DC8: 22400E10
	s_cselect_b32 s16, -1, 0                                   // 000000764DCC: 981080C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000764DD0: BF870159
	s_and_b32 vcc_lo, exec_lo, s16                             // 000000764DD4: 8B6A107E
	s_waitcnt vmcnt(1)                                         // 000000764DD8: BF8907F7
	v_bfe_u32 v2, v3, 16, 1                                    // 000000764DDC: D6100002 02052103
	s_waitcnt vmcnt(0)                                         // 000000764DE4: BF8903F7
	v_bfe_u32 v6, v4, 16, 1                                    // 000000764DE8: D6100006 02052104
	v_add3_u32 v2, v3, v2, 0x7fff                              // 000000764DF0: D6550002 03FE0503 00007FFF
	v_add_nc_u32_e32 v3, s1, v25                               // 000000764DFC: 4A063201
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000764E00: BF870223
	v_add3_u32 v4, v4, v6, 0x7fff                              // 000000764E04: D6550004 03FE0D04 00007FFF
	.long 0xd4410001                                           // 000000764E10: D4410001
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 000000764E14: 0202411F
	.long 0x7e0a3982                                           // 000000764E18: 7E0A3982
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000764E1C: BF870114
	v_add_nc_u32_e32 v33, s17, v3                              // 000000764E20: 4A420611
	v_and_or_b32 v1, 0xffff0000, v4, v5                        // 000000764E24: D6570001 041608FF FFFF0000
	ds_store_b32 v28, v1                                       // 000000764E30: D8340000 0000011C
	s_waitcnt lgkmcnt(0)                                       // 000000764E38: BF89FC07
	s_barrier                                                  // 000000764E3C: BFBD0000
	buffer_gl0_inv                                             // 000000764E40: E0AC0000 00000000
	s_cbranch_vccnz 154                                        // 000000764E48: BFA4009A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x3b4>
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v8, 0               // 000000764E4C: CA100080 09080080
	s_and_saveexec_b32 s17, s1                                 // 000000764E54: BE912001
	s_cbranch_execz 11                                         // 000000764E58: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x188>
	v_lshlrev_b32_e32 v1, 1, v31                               // 000000764E5C: 30023E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000764E60: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000764E64: 3404029F
	.long 0xd7006a01                                           // 000000764E68: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 000000764E6C: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 000000764E70: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 000000764E78: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000764E80: BF8903F7
	v_cvt_f32_f16_e32 v8, v1                                   // 000000764E84: 7E101701
	s_or_b32 exec_lo, exec_lo, s17                             // 000000764E88: 8C7E117E
	v_add_nc_u32_e32 v1, 32, v31                               // 000000764E8C: 4A023EA0
	s_mov_b32 s1, exec_lo                                      // 000000764E90: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000764E94: BF870001
	.long 0xd4c1007e                                           // 000000764E98: D4C1007E
	v_cndmask_b32_e32 v1, v1, v32, vcc_lo                      // 000000764E9C: 02024101
	s_cbranch_execz 11                                         // 000000764EA0: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x1d0>
	v_lshlrev_b32_e32 v1, 1, v1                                // 000000764EA4: 30020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000764EA8: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000764EAC: 3404029F
	.long 0xd7006a01                                           // 000000764EB0: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 000000764EB4: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 000000764EB8: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 000000764EC0: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000764EC8: BF8903F7
	v_cvt_f32_f16_e32 v9, v1                                   // 000000764ECC: 7E121701
	s_or_b32 exec_lo, exec_lo, s1                              // 000000764ED0: 8C7E017E
	v_dual_mov_b32 v10, 0 :: v_dual_add_nc_u32 v1, 64, v31     // 000000764ED4: CA200080 0A003EC0
	v_mov_b32_e32 v11, 0                                       // 000000764EDC: 7E160280
	s_mov_b32 s1, exec_lo                                      // 000000764EE0: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000764EE4: BF870002
	.long 0xd4c1007e                                           // 000000764EE8: D4C1007E
	v_cndmask_b32_e32 v1, v1, v32, vcc_lo                      // 000000764EEC: 02024101
	s_cbranch_execz 11                                         // 000000764EF0: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x220>
	v_lshlrev_b32_e32 v1, 1, v1                                // 000000764EF4: 30020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000764EF8: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000764EFC: 3404029F
	.long 0xd7006a01                                           // 000000764F00: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 000000764F04: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 000000764F08: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 000000764F10: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000764F18: BF8903F7
	v_cvt_f32_f16_e32 v10, v1                                  // 000000764F1C: 7E141701
	s_or_b32 exec_lo, exec_lo, s1                              // 000000764F20: 8C7E017E
	v_add_nc_u32_e32 v1, 0x60, v31                             // 000000764F24: 4A023EFF 00000060
	s_mov_b32 s1, exec_lo                                      // 000000764F2C: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000764F30: BF870001
	.long 0xd4c1007e                                           // 000000764F34: D4C1007E
	v_cndmask_b32_e32 v1, v1, v32, vcc_lo                      // 000000764F38: 02024101
	s_cbranch_execz 11                                         // 000000764F3C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x26c>
	v_lshlrev_b32_e32 v1, 1, v1                                // 000000764F40: 30020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000764F44: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000764F48: 3404029F
	.long 0xd7006a01                                           // 000000764F4C: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 000000764F50: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 000000764F54: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 000000764F5C: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000764F64: BF8903F7
	v_cvt_f32_f16_e32 v11, v1                                  // 000000764F68: 7E161701
	s_or_b32 exec_lo, exec_lo, s1                              // 000000764F6C: 8C7E017E
	v_dual_mov_b32 v12, 0 :: v_dual_add_nc_u32 v1, 0x80, v31   // 000000764F70: CA200080 0C003EFF 00000080
	v_mov_b32_e32 v13, 0                                       // 000000764F7C: 7E1A0280
	s_mov_b32 s1, exec_lo                                      // 000000764F80: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000764F84: BF870002
	.long 0xd4c1007e                                           // 000000764F88: D4C1007E
	v_cndmask_b32_e32 v1, v1, v32, vcc_lo                      // 000000764F8C: 02024101
	s_cbranch_execz 11                                         // 000000764F90: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x2c0>
	v_lshlrev_b32_e32 v1, 1, v1                                // 000000764F94: 30020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000764F98: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000764F9C: 3404029F
	.long 0xd7006a01                                           // 000000764FA0: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 000000764FA4: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 000000764FA8: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 000000764FB0: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000764FB8: BF8903F7
	v_cvt_f32_f16_e32 v12, v1                                  // 000000764FBC: 7E181701
	s_or_b32 exec_lo, exec_lo, s1                              // 000000764FC0: 8C7E017E
	v_add_nc_u32_e32 v1, 0xa0, v31                             // 000000764FC4: 4A023EFF 000000A0
	s_mov_b32 s1, exec_lo                                      // 000000764FCC: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000764FD0: BF870001
	.long 0xd4c1007e                                           // 000000764FD4: D4C1007E
	v_cndmask_b32_e32 v1, v1, v32, vcc_lo                      // 000000764FD8: 02024101
	s_cbranch_execz 11                                         // 000000764FDC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x30c>
	v_lshlrev_b32_e32 v1, 1, v1                                // 000000764FE0: 30020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000764FE4: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000764FE8: 3404029F
	.long 0xd7006a01                                           // 000000764FEC: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 000000764FF0: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 000000764FF4: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 000000764FFC: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000765004: BF8903F7
	v_cvt_f32_f16_e32 v13, v1                                  // 000000765008: 7E1A1701
	s_or_b32 exec_lo, exec_lo, s1                              // 00000076500C: 8C7E017E
	v_dual_mov_b32 v14, 0 :: v_dual_add_nc_u32 v1, 0xc0, v31   // 000000765010: CA200080 0E003EFF 000000C0
	v_mov_b32_e32 v15, 0                                       // 00000076501C: 7E1E0280
	s_mov_b32 s1, exec_lo                                      // 000000765020: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000765024: BF870002
	.long 0xd4c1007e                                           // 000000765028: D4C1007E
	v_cndmask_b32_e32 v1, v1, v32, vcc_lo                      // 00000076502C: 02024101
	s_cbranch_execz 11                                         // 000000765030: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x360>
	v_lshlrev_b32_e32 v1, 1, v1                                // 000000765034: 30020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000765038: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000076503C: 3404029F
	.long 0xd7006a01                                           // 000000765040: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 000000765044: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 000000765048: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 000000765050: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000765058: BF8903F7
	v_cvt_f32_f16_e32 v14, v1                                  // 00000076505C: 7E1C1701
	s_or_b32 exec_lo, exec_lo, s1                              // 000000765060: 8C7E017E
	v_add_nc_u32_e32 v1, 0xe0, v31                             // 000000765064: 4A023EFF 000000E0
	s_mov_b32 s1, exec_lo                                      // 00000076506C: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000765070: BF870001
	.long 0xd4c1007e                                           // 000000765074: D4C1007E
	v_cndmask_b32_e32 v1, v1, v32, vcc_lo                      // 000000765078: 02024101
	s_cbranch_execz 11                                         // 00000076507C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x3ac>
	v_lshlrev_b32_e32 v1, 1, v1                                // 000000765080: 30020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000765084: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000765088: 3404029F
	.long 0xd7006a01                                           // 00000076508C: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 000000765090: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 000000765094: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 00000076509C: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000007650A4: BF8903F7
	v_cvt_f32_f16_e32 v15, v1                                  // 0000007650A8: 7E1E1701
	s_or_b32 exec_lo, exec_lo, s1                              // 0000007650AC: 8C7E017E
	s_branch 9                                                 // 0000007650B0: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x3d8>
	v_mov_b32_e32 v8, 0                                        // 0000007650B4: 7E100280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007650B8: BF870001
	v_mov_b32_e32 v9, v8                                       // 0000007650BC: 7E120308
	v_mov_b32_e32 v10, v8                                      // 0000007650C0: 7E140308
	v_mov_b32_e32 v11, v8                                      // 0000007650C4: 7E160308
	v_mov_b32_e32 v12, v8                                      // 0000007650C8: 7E180308
	v_mov_b32_e32 v13, v8                                      // 0000007650CC: 7E1A0308
	v_mov_b32_e32 v14, v8                                      // 0000007650D0: 7E1C0308
	v_mov_b32_e32 v15, v8                                      // 0000007650D4: 7E1E0308
	s_add_u32 s4, s4, s14                                      // 0000007650D8: 80040E04
	s_addc_u32 s5, s5, s15                                     // 0000007650DC: 82050F05
	s_lshr_b32 s1, s11, 31                                     // 0000007650E0: 85019F0B
	v_dual_mov_b32 v1, s21 :: v_dual_mov_b32 v20, 0            // 0000007650E4: CA100015 01140080
	s_add_u32 s14, s10, s1                                     // 0000007650EC: 800E010A
	s_addc_u32 s15, s11, 0                                     // 0000007650F0: 820F800B
	.long 0xd4410001                                           // 0000007650F4: D4410001
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 0000007650F8: 0202411F
	s_ashr_i64 s[14:15], s[14:15], 1                           // 0000007650FC: 868E810E
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v27, 0             // 000000765100: CA100080 221A0080
	v_mad_u64_u32 v[25:26], null, v1, s14, s[4:5]              // 000000765108: D6FE7C19 00101D01
	.long 0xd72c0001                                           // 000000765110: D72C0001
	v_cndmask_b32_e32 v0, s21, v15, vcc_lo                     // 000000765114: 02001E15
	.long 0xd72c0002                                           // 000000765118: D72C0002
	v_cndmask_b32_e32 v0, s20, v14, vcc_lo                     // 00000076511C: 02001C14
	v_cndmask_b32_e64 v35, 0, 1, s16                           // 000000765120: D5010023 00410280
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v22, 0             // 000000765128: CA100080 15160080
	v_mov_b32_e32 v23, 0                                       // 000000765130: 7E2E0280
	s_delay_alu instid0(VALU_DEP_4)                            // 000000765134: BF870004
	v_add3_u32 v36, v2, v26, v1                                // 000000765138: D6550024 04063502
	s_and_saveexec_b32 s4, s1                                  // 000000765140: BE842001
	s_cbranch_execz 22                                         // 000000765144: BFA50016 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x4a0>
	v_lshlrev_b32_e32 v1, 4, v31                               // 000000765148: 30023E84
	v_mov_b32_e32 v27, 0                                       // 00000076514C: 7E360280
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000765150: BF8700A2
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000765154: 3404029F
	.long 0xd7006a01                                           // 000000765158: D7006A01
	v_cndmask_b32_e32 v1, v25, v1, vcc_lo                      // 00000076515C: 02020319
	v_add_co_ci_u32_e64 v2, null, v36, v2, vcc_lo              // 000000765160: D5207C02 01AA0524
	s_and_not1_b32 vcc_lo, exec_lo, s16                        // 000000765168: 916A107E
	global_load_b128 v[20:23], v[1:2], off                     // 00000076516C: DC5E0000 147C0001
	s_cbranch_vccnz 10                                         // 000000765174: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x4a0>
	v_lshlrev_b32_e32 v1, 1, v31                               // 000000765178: 30023E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076517C: BF870091
	.long 0xd7006a01                                           // 000000765180: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 000000765184: 02020318
	v_add_co_ci_u32_e64 v2, null, 0, v33, vcc_lo               // 000000765188: D5207C02 01AA4280
	global_load_d16_b16 v1, v[1:2], off                        // 000000765190: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000765198: BF8903F7
	v_cvt_f32_f16_e32 v27, v1                                  // 00000076519C: 7E361701
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007651A0: 8C7E047E
	v_dual_mov_b32 v38, 0 :: v_dual_mov_b32 v39, 0             // 0000007651A4: CA100080 26260080
	v_dual_mov_b32 v40, 0 :: v_dual_mov_b32 v41, 0             // 0000007651AC: CA100080 28280080
	v_dual_mov_b32 v42, 0 :: v_dual_mov_b32 v43, 0             // 0000007651B4: CA100080 2A2A0080
	v_mov_b32_e32 v37, 0                                       // 0000007651BC: 7E4A0280
	s_and_saveexec_b32 s14, s1                                 // 0000007651C0: BE8E2001
	s_cbranch_execz 666                                        // 0000007651C4: BFA5029A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xf30>
	v_dual_mov_b32 v42, 0 :: v_dual_add_nc_u32 v1, 32, v31     // 0000007651C8: CA200080 2A003EA0
	v_dual_mov_b32 v37, 0 :: v_dual_lshlrev_b32 v26, 5, v31    // 0000007651D0: CA220080 251A3E85
	v_dual_mov_b32 v41, 0 :: v_dual_mov_b32 v38, 0             // 0000007651D8: CA100080 29260080
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007651E0: BF870003
	v_dual_mov_b32 v43, 0 :: v_dual_lshlrev_b32 v44, 4, v1     // 0000007651E4: CA220080 2B2C0284
	v_dual_mov_b32 v40, 0 :: v_dual_lshlrev_b32 v45, 1, v1     // 0000007651EC: CA220080 282C0281
	v_dual_mov_b32 v39, 0 :: v_dual_mov_b32 v34, 0             // 0000007651F4: CA100080 27220080
	v_mov_b32_e32 v46, v27                                     // 0000007651FC: 7E5C031B
	s_mul_i32 s1, s11, 6                                       // 000000765200: 9601860B
	s_mul_hi_u32 s15, s10, 6                                   // 000000765204: 968F860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 000000765208: 8484820A
	s_add_i32 s15, s15, s1                                     // 00000076520C: 810F010F
	s_mul_i32 s17, s10, 6                                      // 000000765210: 9611860A
	s_mov_b32 s16, 0                                           // 000000765214: BE900080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 000000765218: 848A810A
	s_branch 608                                               // 00000076521C: BFA00260 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xea0>
	s_or_b32 exec_lo, exec_lo, s18                             // 000000765220: 8C7E127E
	v_cndmask_b32_e64 v47, v27, v8, s0                         // 000000765224: D501002F 0002111B
	v_cndmask_b32_e64 v4, v11, v12, s0                         // 00000076522C: D5010004 0002190B
	v_cndmask_b32_e64 v3, v10, v11, s0                         // 000000765234: D5010003 0002170A
	v_cndmask_b32_e64 v2, v9, v10, s0                          // 00000076523C: D5010002 00021509
	v_cndmask_b32_e64 v1, v8, v9, s0                           // 000000765244: D5010001 00021308
	v_dual_mov_b32 v8, v15 :: v_dual_and_b32 v9, 0xff, v20     // 00000076524C: CA24010F 080828FF 000000FF
	v_lshrrev_b32_e32 v10, 6, v20                              // 000000765258: 32142886
	v_lshrrev_b32_e32 v11, 14, v20                             // 00000076525C: 3216288E
	v_cndmask_b32_e64 v7, v14, v15, s0                         // 000000765260: D5010007 00021F0E
	v_cndmask_b32_e64 v6, v13, v14, s0                         // 000000765268: D5010006 00021D0D
	v_lshlrev_b32_e32 v9, 2, v9                                // 000000765270: 30121282
	v_and_b32_e32 v10, 0x3fc, v10                              // 000000765274: 361414FF 000003FC
	v_and_b32_e32 v11, 0x3fc, v11                              // 00000076527C: 361616FF 000003FC
	v_cndmask_b32_e64 v5, v12, v13, s0                         // 000000765284: D5010005 00021B0C
	v_ashrrev_i32_e32 v27, 31, v26                             // 00000076528C: 3436349F
	ds_load_b32 v9, v9                                         // 000000765290: D8D80000 09000009
	ds_load_b32 v10, v10                                       // 000000765298: D8D80000 0A00000A
	ds_load_b32 v15, v11                                       // 0000007652A0: D8D80000 0F00000B
	v_lshrrev_b32_e32 v11, 22, v20                             // 0000007652A8: 32162896
	s_and_b32 s1, exec_lo, s1                                  // 0000007652AC: 8B01017E
	v_add_nc_u32_e32 v44, 0x200, v44                           // 0000007652B0: 4A5858FF 00000200
	s_or_b32 s16, s1, s16                                      // 0000007652B8: 8C101001
	v_add_nc_u32_e32 v45, 64, v45                              // 0000007652BC: 4A5A5AC0
	v_and_b32_e32 v11, 0x3fc, v11                              // 0000007652C0: 361616FF 000003FC
	ds_load_b32 v60, v11                                       // 0000007652C8: D8D80000 3C00000B
	v_and_b32_e32 v11, 0xff, v21                               // 0000007652D0: 36162AFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007652D8: BF8700B1
	v_lshlrev_b32_e32 v11, 2, v11                              // 0000007652DC: 30161682
	ds_load_b32 v61, v11                                       // 0000007652E0: D8D80000 3D00000B
	v_lshrrev_b32_e32 v11, 6, v21                              // 0000007652E8: 32162A86
	v_and_b32_e32 v11, 0x3fc, v11                              // 0000007652EC: 361616FF 000003FC
	ds_load_b32 v62, v11                                       // 0000007652F4: D8D80000 3E00000B
	v_lshrrev_b32_e32 v11, 14, v21                             // 0000007652FC: 32162A8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000765300: BF8700B1
	v_and_b32_e32 v11, 0x3fc, v11                              // 000000765304: 361616FF 000003FC
	ds_load_b32 v63, v11                                       // 00000076530C: D8D80000 3F00000B
	v_lshrrev_b32_e32 v11, 22, v21                             // 000000765314: 32162A96
	v_and_b32_e32 v11, 0x3fc, v11                              // 000000765318: 361616FF 000003FC
	ds_load_b32 v64, v11                                       // 000000765320: D8D80000 4000000B
	v_and_b32_e32 v11, 0xff, v22                               // 000000765328: 36162CFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000765330: BF8700B1
	v_lshlrev_b32_e32 v11, 2, v11                              // 000000765334: 30161682
	ds_load_b32 v65, v11                                       // 000000765338: D8D80000 4100000B
	v_lshrrev_b32_e32 v11, 6, v22                              // 000000765340: 32162C86
	v_and_b32_e32 v11, 0x3fc, v11                              // 000000765344: 361616FF 000003FC
	ds_load_b32 v66, v11                                       // 00000076534C: D8D80000 4200000B
	v_lshrrev_b32_e32 v11, 14, v22                             // 000000765354: 32162C8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000765358: BF8700B1
	v_and_b32_e32 v11, 0x3fc, v11                              // 00000076535C: 361616FF 000003FC
	ds_load_b32 v67, v11                                       // 000000765364: D8D80000 4300000B
	v_lshrrev_b32_e32 v11, 22, v22                             // 00000076536C: 32162C96
	v_and_b32_e32 v11, 0x3fc, v11                              // 000000765370: 361616FF 000003FC
	ds_load_b32 v68, v11                                       // 000000765378: D8D80000 4400000B
	v_and_b32_e32 v11, 0xff, v23                               // 000000765380: 36162EFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000765388: BF8700B1
	v_lshlrev_b32_e32 v11, 2, v11                              // 00000076538C: 30161682
	ds_load_b32 v69, v11                                       // 000000765390: D8D80000 4500000B
	v_lshrrev_b32_e32 v11, 6, v23                              // 000000765398: 32162E86
	v_and_b32_e32 v11, 0x3fc, v11                              // 00000076539C: 361616FF 000003FC
	ds_load_b32 v70, v11                                       // 0000007653A4: D8D80000 4600000B
	v_lshrrev_b32_e32 v11, 14, v23                             // 0000007653AC: 32162E8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007653B0: BF8700B1
	v_and_b32_e32 v11, 0x3fc, v11                              // 0000007653B4: 361616FF 000003FC
	ds_load_b32 v71, v11                                       // 0000007653BC: D8D80000 4700000B
	v_lshrrev_b32_e32 v11, 22, v23                             // 0000007653C4: 32162E96
	v_and_b32_e32 v11, 0x3fc, v11                              // 0000007653C8: 361616FF 000003FC
	ds_load_b32 v72, v11                                       // 0000007653D0: D8D80000 4800000B
	.long 0xd73c000b                                           // 0000007653D8: D73C000B
	v_cndmask_b32_e32 v1, 1, v26, vcc_lo                       // 0000007653DC: 02023481
	v_dual_mov_b32 v27, v46 :: v_dual_add_nc_u32 v26, 0x400, v26// 0000007653E0: CA20012E 1B1A34FF 00000400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007653EC: BF870092
	.long 0xd7006a38                                           // 0000007653F0: D7006A38
	v_cndmask_b32_e32 v1, s6, v11, vcc_lo                      // 0000007653F4: 02021606
	v_add_co_ci_u32_e64 v57, null, s7, v12, vcc_lo             // 0000007653F8: D5207C39 01AA1807
	s_clause 0x3                                               // 000000765400: BF850003
	global_load_b128 v[11:14], v[56:57], off                   // 000000765404: DC5E0000 0B7C0038
	global_load_b128 v[20:23], v[56:57], off offset:16         // 00000076540C: DC5E0010 147C0038
	global_load_b128 v[48:51], v[56:57], off offset:32         // 000000765414: DC5E0020 307C0038
	global_load_b128 v[52:55], v[56:57], off offset:48         // 00000076541C: DC5E0030 347C0038
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 000000765424: BF890CF7
	v_dot2_f32_bf16 v11, v11, v9, 0                            // 000000765428: CC1A400B 1A02130B
	s_waitcnt lgkmcnt(14)                                      // 000000765430: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000765434: BF8700A1
	v_dot2_f32_bf16 v11, v12, v10, v11                         // 000000765438: CC1A400B 1C2E150C
	s_waitcnt lgkmcnt(13)                                      // 000000765440: BF89FCD7
	v_dot2_f32_bf16 v11, v13, v15, v11                         // 000000765444: CC1A400B 1C2E1F0D
	s_waitcnt lgkmcnt(12)                                      // 00000076544C: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000765450: BF8700A1
	v_dot2_f32_bf16 v11, v14, v60, v11                         // 000000765454: CC1A400B 1C2E790E
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 00000076545C: BF8908B7
	v_dot2_f32_bf16 v11, v20, v61, v11                         // 000000765460: CC1A400B 1C2E7B14
	s_waitcnt lgkmcnt(10)                                      // 000000765468: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000076546C: BF8700A1
	v_dot2_f32_bf16 v11, v21, v62, v11                         // 000000765470: CC1A400B 1C2E7D15
	s_waitcnt lgkmcnt(9)                                       // 000000765478: BF89FC97
	v_dot2_f32_bf16 v11, v22, v63, v11                         // 00000076547C: CC1A400B 1C2E7F16
	s_waitcnt lgkmcnt(8)                                       // 000000765484: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000765488: BF8700A1
	v_dot2_f32_bf16 v11, v23, v64, v11                         // 00000076548C: CC1A400B 1C2E8117
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 000000765494: BF890477
	v_dot2_f32_bf16 v11, v48, v65, v11                         // 000000765498: CC1A400B 1C2E8330
	s_waitcnt lgkmcnt(6)                                       // 0000007654A0: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007654A4: BF8700A1
	v_dot2_f32_bf16 v11, v49, v66, v11                         // 0000007654A8: CC1A400B 1C2E8531
	s_waitcnt lgkmcnt(5)                                       // 0000007654B0: BF89FC57
	v_dot2_f32_bf16 v11, v50, v67, v11                         // 0000007654B4: CC1A400B 1C2E8732
	s_waitcnt lgkmcnt(4)                                       // 0000007654BC: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007654C0: BF8700A1
	v_dot2_f32_bf16 v11, v51, v68, v11                         // 0000007654C4: CC1A400B 1C2E8933
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 0000007654CC: BF890037
	v_dot2_f32_bf16 v11, v52, v69, v11                         // 0000007654D0: CC1A400B 1C2E8B34
	.long 0xd7006a34                                           // 0000007654D8: D7006A34
	v_cndmask_b32_e32 v0, v56, v10, vcc_lo                     // 0000007654DC: 02001538
	s_waitcnt lgkmcnt(2)                                       // 0000007654E0: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000007654E4: BF8701C2
	v_dot2_f32_bf16 v11, v53, v70, v11                         // 0000007654E8: CC1A400B 1C2E8D35
	v_add_co_ci_u32_e64 v53, null, s11, v57, vcc_lo            // 0000007654F0: D5207C35 01AA720B
	.long 0xd7006a3a                                           // 0000007654F8: D7006A3A
	v_cndmask_b32_e32 v0, v56, v4, vcc_lo                      // 0000007654FC: 02000938
	s_waitcnt lgkmcnt(1)                                       // 000000765500: BF89FC17
	v_dot2_f32_bf16 v11, v54, v71, v11                         // 000000765504: CC1A400B 1C2E8F36
	v_add_co_ci_u32_e64 v59, null, s5, v57, vcc_lo             // 00000076550C: D5207C3B 01AA7205
	.long 0xd7006a38                                           // 000000765514: D7006A38
	v_cndmask_b32_e32 v0, v56, v17, vcc_lo                     // 000000765518: 02002338
	s_waitcnt lgkmcnt(0)                                       // 00000076551C: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000765520: BF870123
	v_dot2_f32_bf16 v11, v55, v72, v11                         // 000000765524: CC1A400B 1C2E9137
	v_add_co_ci_u32_e64 v57, null, s15, v57, vcc_lo            // 00000076552C: D5207C39 01AA720F
	v_fmac_f32_e32 v37, v47, v11                               // 000000765534: 564A172F
	s_clause 0x3                                               // 000000765538: BF850003
	global_load_b128 v[11:14], v[52:53], off                   // 00000076553C: DC5E0000 0B7C0034
	global_load_b128 v[20:23], v[52:53], off offset:16         // 000000765544: DC5E0010 147C0034
	global_load_b128 v[48:51], v[52:53], off offset:32         // 00000076554C: DC5E0020 307C0034
	global_load_b128 v[52:55], v[52:53], off offset:48         // 000000765554: DC5E0030 347C0034
	s_waitcnt vmcnt(3)                                         // 00000076555C: BF890FF7
	v_dot2_f32_bf16 v11, v11, v9, 0                            // 000000765560: CC1A400B 1A02130B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000765568: BF870091
	v_dot2_f32_bf16 v11, v12, v10, v11                         // 00000076556C: CC1A400B 1C2E150C
	v_dot2_f32_bf16 v11, v13, v15, v11                         // 000000765574: CC1A400B 1C2E1F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000076557C: BF8700A1
	v_dot2_f32_bf16 v11, v14, v60, v11                         // 000000765580: CC1A400B 1C2E790E
	s_waitcnt vmcnt(2)                                         // 000000765588: BF890BF7
	v_dot2_f32_bf16 v11, v20, v61, v11                         // 00000076558C: CC1A400B 1C2E7B14
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000765594: BF870091
	v_dot2_f32_bf16 v11, v21, v62, v11                         // 000000765598: CC1A400B 1C2E7D15
	v_dot2_f32_bf16 v11, v22, v63, v11                         // 0000007655A0: CC1A400B 1C2E7F16
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007655A8: BF8700A1
	v_dot2_f32_bf16 v11, v23, v64, v11                         // 0000007655AC: CC1A400B 1C2E8117
	s_waitcnt vmcnt(1)                                         // 0000007655B4: BF8907F7
	v_dot2_f32_bf16 v11, v48, v65, v11                         // 0000007655B8: CC1A400B 1C2E8330
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007655C0: BF870091
	v_dot2_f32_bf16 v11, v49, v66, v11                         // 0000007655C4: CC1A400B 1C2E8531
	v_dot2_f32_bf16 v11, v50, v67, v11                         // 0000007655CC: CC1A400B 1C2E8732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007655D4: BF8700A1
	v_dot2_f32_bf16 v11, v51, v68, v11                         // 0000007655D8: CC1A400B 1C2E8933
	s_waitcnt vmcnt(0)                                         // 0000007655E0: BF8903F7
	v_dot2_f32_bf16 v11, v52, v69, v11                         // 0000007655E4: CC1A400B 1C2E8B34
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007655EC: BF870091
	v_dot2_f32_bf16 v11, v53, v70, v11                         // 0000007655F0: CC1A400B 1C2E8D35
	v_dot2_f32_bf16 v11, v54, v71, v11                         // 0000007655F8: CC1A400B 1C2E8F36
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000765600: BF870091
	v_dot2_f32_bf16 v11, v55, v72, v11                         // 000000765604: CC1A400B 1C2E9137
	v_fmac_f32_e32 v43, v47, v11                               // 00000076560C: 5656172F
	s_clause 0x3                                               // 000000765610: BF850003
	global_load_b128 v[11:14], v[58:59], off                   // 000000765614: DC5E0000 0B7C003A
	global_load_b128 v[20:23], v[58:59], off offset:16         // 00000076561C: DC5E0010 147C003A
	global_load_b128 v[48:51], v[58:59], off offset:32         // 000000765624: DC5E0020 307C003A
	global_load_b128 v[52:55], v[58:59], off offset:48         // 00000076562C: DC5E0030 347C003A
	.long 0xd7006a3a                                           // 000000765634: D7006A3A
	v_cndmask_b32_e32 v0, v58, v4, vcc_lo                      // 000000765638: 0200093A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000076563C: BF8700B1
	v_add_co_ci_u32_e64 v59, null, s5, v59, vcc_lo             // 000000765640: D5207C3B 01AA7605
	s_waitcnt vmcnt(3)                                         // 000000765648: BF890FF7
	v_dot2_f32_bf16 v11, v11, v9, 0                            // 00000076564C: CC1A400B 1A02130B
	v_dot2_f32_bf16 v11, v12, v10, v11                         // 000000765654: CC1A400B 1C2E150C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076565C: BF870091
	v_dot2_f32_bf16 v11, v13, v15, v11                         // 000000765660: CC1A400B 1C2E1F0D
	v_dot2_f32_bf16 v11, v14, v60, v11                         // 000000765668: CC1A400B 1C2E790E
	s_waitcnt vmcnt(2)                                         // 000000765670: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000765674: BF870091
	v_dot2_f32_bf16 v11, v20, v61, v11                         // 000000765678: CC1A400B 1C2E7B14
	v_dot2_f32_bf16 v11, v21, v62, v11                         // 000000765680: CC1A400B 1C2E7D15
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000765688: BF870091
	v_dot2_f32_bf16 v11, v22, v63, v11                         // 00000076568C: CC1A400B 1C2E7F16
	v_dot2_f32_bf16 v11, v23, v64, v11                         // 000000765694: CC1A400B 1C2E8117
	s_waitcnt vmcnt(1)                                         // 00000076569C: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007656A0: BF870091
	v_dot2_f32_bf16 v11, v48, v65, v11                         // 0000007656A4: CC1A400B 1C2E8330
	v_dot2_f32_bf16 v11, v49, v66, v11                         // 0000007656AC: CC1A400B 1C2E8531
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007656B4: BF870091
	v_dot2_f32_bf16 v11, v50, v67, v11                         // 0000007656B8: CC1A400B 1C2E8732
	v_dot2_f32_bf16 v11, v51, v68, v11                         // 0000007656C0: CC1A400B 1C2E8933
	s_waitcnt vmcnt(0)                                         // 0000007656C8: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007656CC: BF870091
	v_dot2_f32_bf16 v11, v52, v69, v11                         // 0000007656D0: CC1A400B 1C2E8B34
	v_dot2_f32_bf16 v11, v53, v70, v11                         // 0000007656D8: CC1A400B 1C2E8D35
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007656E0: BF870091
	v_dot2_f32_bf16 v11, v54, v71, v11                         // 0000007656E4: CC1A400B 1C2E8F36
	v_dot2_f32_bf16 v11, v55, v72, v11                         // 0000007656EC: CC1A400B 1C2E9137
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007656F4: BF870001
	v_fmac_f32_e32 v42, v47, v11                               // 0000007656F8: 5654172F
	s_clause 0x3                                               // 0000007656FC: BF850003
	global_load_b128 v[11:14], v[56:57], off                   // 000000765700: DC5E0000 0B7C0038
	global_load_b128 v[20:23], v[56:57], off offset:16         // 000000765708: DC5E0010 147C0038
	global_load_b128 v[48:51], v[56:57], off offset:32         // 000000765710: DC5E0020 307C0038
	global_load_b128 v[52:55], v[56:57], off offset:48         // 000000765718: DC5E0030 347C0038
	.long 0xd7006a38                                           // 000000765720: D7006A38
	v_cndmask_b32_e32 v0, v56, v4, vcc_lo                      // 000000765724: 02000938
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000765728: BF8700B1
	v_add_co_ci_u32_e64 v57, null, s5, v57, vcc_lo             // 00000076572C: D5207C39 01AA7205
	s_waitcnt vmcnt(3)                                         // 000000765734: BF890FF7
	v_dot2_f32_bf16 v11, v11, v9, 0                            // 000000765738: CC1A400B 1A02130B
	v_dot2_f32_bf16 v11, v12, v10, v11                         // 000000765740: CC1A400B 1C2E150C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000765748: BF870091
	v_dot2_f32_bf16 v11, v13, v15, v11                         // 00000076574C: CC1A400B 1C2E1F0D
	v_dot2_f32_bf16 v11, v14, v60, v11                         // 000000765754: CC1A400B 1C2E790E
	s_waitcnt vmcnt(2)                                         // 00000076575C: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000765760: BF870091
	v_dot2_f32_bf16 v11, v20, v61, v11                         // 000000765764: CC1A400B 1C2E7B14
	v_dot2_f32_bf16 v11, v21, v62, v11                         // 00000076576C: CC1A400B 1C2E7D15
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000765774: BF870091
	v_dot2_f32_bf16 v11, v22, v63, v11                         // 000000765778: CC1A400B 1C2E7F16
	v_dot2_f32_bf16 v11, v23, v64, v11                         // 000000765780: CC1A400B 1C2E8117
	s_waitcnt vmcnt(1)                                         // 000000765788: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076578C: BF870091
	v_dot2_f32_bf16 v11, v48, v65, v11                         // 000000765790: CC1A400B 1C2E8330
	v_dot2_f32_bf16 v11, v49, v66, v11                         // 000000765798: CC1A400B 1C2E8531
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007657A0: BF870091
	v_dot2_f32_bf16 v11, v50, v67, v11                         // 0000007657A4: CC1A400B 1C2E8732
	v_dot2_f32_bf16 v11, v51, v68, v11                         // 0000007657AC: CC1A400B 1C2E8933
	s_waitcnt vmcnt(0)                                         // 0000007657B4: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007657B8: BF870091
	v_dot2_f32_bf16 v11, v52, v69, v11                         // 0000007657BC: CC1A400B 1C2E8B34
	v_dot2_f32_bf16 v11, v53, v70, v11                         // 0000007657C4: CC1A400B 1C2E8D35
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007657CC: BF870091
	v_dot2_f32_bf16 v11, v54, v71, v11                         // 0000007657D0: CC1A400B 1C2E8F36
	v_dot2_f32_bf16 v11, v55, v72, v11                         // 0000007657D8: CC1A400B 1C2E9137
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007657E0: BF870001
	v_fmac_f32_e32 v41, v47, v11                               // 0000007657E4: 5652172F
	s_clause 0x3                                               // 0000007657E8: BF850003
	global_load_b128 v[11:14], v[58:59], off                   // 0000007657EC: DC5E0000 0B7C003A
	global_load_b128 v[20:23], v[58:59], off offset:16         // 0000007657F4: DC5E0010 147C003A
	global_load_b128 v[48:51], v[58:59], off offset:32         // 0000007657FC: DC5E0020 307C003A
	global_load_b128 v[52:55], v[58:59], off offset:48         // 000000765804: DC5E0030 347C003A
	s_waitcnt vmcnt(3)                                         // 00000076580C: BF890FF7
	v_dot2_f32_bf16 v11, v11, v9, 0                            // 000000765810: CC1A400B 1A02130B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000765818: BF870091
	v_dot2_f32_bf16 v11, v12, v10, v11                         // 00000076581C: CC1A400B 1C2E150C
	v_dot2_f32_bf16 v11, v13, v15, v11                         // 000000765824: CC1A400B 1C2E1F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000076582C: BF8700A1
	v_dot2_f32_bf16 v11, v14, v60, v11                         // 000000765830: CC1A400B 1C2E790E
	s_waitcnt vmcnt(2)                                         // 000000765838: BF890BF7
	v_dot2_f32_bf16 v11, v20, v61, v11                         // 00000076583C: CC1A400B 1C2E7B14
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000765844: BF870091
	v_dot2_f32_bf16 v11, v21, v62, v11                         // 000000765848: CC1A400B 1C2E7D15
	v_dot2_f32_bf16 v11, v22, v63, v11                         // 000000765850: CC1A400B 1C2E7F16
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000765858: BF8700A1
	v_dot2_f32_bf16 v11, v23, v64, v11                         // 00000076585C: CC1A400B 1C2E8117
	s_waitcnt vmcnt(1)                                         // 000000765864: BF8907F7
	v_dot2_f32_bf16 v11, v48, v65, v11                         // 000000765868: CC1A400B 1C2E8330
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000765870: BF870091
	v_dot2_f32_bf16 v11, v49, v66, v11                         // 000000765874: CC1A400B 1C2E8531
	v_dot2_f32_bf16 v11, v50, v67, v11                         // 00000076587C: CC1A400B 1C2E8732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000765884: BF8700A1
	v_dot2_f32_bf16 v11, v51, v68, v11                         // 000000765888: CC1A400B 1C2E8933
	s_waitcnt vmcnt(0)                                         // 000000765890: BF8903F7
	v_dot2_f32_bf16 v11, v52, v69, v11                         // 000000765894: CC1A400B 1C2E8B34
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076589C: BF870091
	v_dot2_f32_bf16 v11, v53, v70, v11                         // 0000007658A0: CC1A400B 1C2E8D35
	v_dot2_f32_bf16 v11, v54, v71, v11                         // 0000007658A8: CC1A400B 1C2E8F36
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007658B0: BF870091
	v_dot2_f32_bf16 v11, v55, v72, v11                         // 0000007658B4: CC1A400B 1C2E9137
	v_fmac_f32_e32 v40, v47, v11                               // 0000007658BC: 5650172F
	s_clause 0x3                                               // 0000007658C0: BF850003
	global_load_b128 v[11:14], v[56:57], off                   // 0000007658C4: DC5E0000 0B7C0038
	global_load_b128 v[20:23], v[56:57], off offset:16         // 0000007658CC: DC5E0010 147C0038
	global_load_b128 v[48:51], v[56:57], off offset:32         // 0000007658D4: DC5E0020 307C0038
	global_load_b128 v[52:55], v[56:57], off offset:48         // 0000007658DC: DC5E0030 347C0038
	s_waitcnt vmcnt(3)                                         // 0000007658E4: BF890FF7
	v_dot2_f32_bf16 v11, v11, v9, 0                            // 0000007658E8: CC1A400B 1A02130B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007658F0: BF870091
	v_dot2_f32_bf16 v11, v12, v10, v11                         // 0000007658F4: CC1A400B 1C2E150C
	v_dot2_f32_bf16 v11, v13, v15, v11                         // 0000007658FC: CC1A400B 1C2E1F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000765904: BF8700A1
	v_dot2_f32_bf16 v11, v14, v60, v11                         // 000000765908: CC1A400B 1C2E790E
	s_waitcnt vmcnt(2)                                         // 000000765910: BF890BF7
	v_dot2_f32_bf16 v11, v20, v61, v11                         // 000000765914: CC1A400B 1C2E7B14
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076591C: BF870091
	v_dot2_f32_bf16 v11, v21, v62, v11                         // 000000765920: CC1A400B 1C2E7D15
	v_dot2_f32_bf16 v11, v22, v63, v11                         // 000000765928: CC1A400B 1C2E7F16
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000765930: BF8700A1
	v_dot2_f32_bf16 v11, v23, v64, v11                         // 000000765934: CC1A400B 1C2E8117
	s_waitcnt vmcnt(1)                                         // 00000076593C: BF8907F7
	v_dot2_f32_bf16 v11, v48, v65, v11                         // 000000765940: CC1A400B 1C2E8330
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000765948: BF870091
	v_dot2_f32_bf16 v11, v49, v66, v11                         // 00000076594C: CC1A400B 1C2E8531
	v_dot2_f32_bf16 v11, v50, v67, v11                         // 000000765954: CC1A400B 1C2E8732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000076595C: BF8700A1
	v_dot2_f32_bf16 v11, v51, v68, v11                         // 000000765960: CC1A400B 1C2E8933
	s_waitcnt vmcnt(0)                                         // 000000765968: BF8903F7
	v_dot2_f32_bf16 v11, v52, v69, v11                         // 00000076596C: CC1A400B 1C2E8B34
	.long 0xd7006a34                                           // 000000765974: D7006A34
	v_cndmask_b32_e32 v0, v58, v4, vcc_lo                      // 000000765978: 0200093A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000076597C: BF870122
	v_dot2_f32_bf16 v11, v53, v70, v11                         // 000000765980: CC1A400B 1C2E8D35
	v_add_co_ci_u32_e64 v53, null, s5, v59, vcc_lo             // 000000765988: D5207C35 01AA7605
	v_dot2_f32_bf16 v11, v54, v71, v11                         // 000000765990: CC1A400B 1C2E8F36
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000765998: BF870091
	v_dot2_f32_bf16 v11, v55, v72, v11                         // 00000076599C: CC1A400B 1C2E9137
	v_fmac_f32_e32 v39, v47, v11                               // 0000007659A4: 564E172F
	s_clause 0x3                                               // 0000007659A8: BF850003
	global_load_b128 v[11:14], v[52:53], off                   // 0000007659AC: DC5E0000 0B7C0034
	global_load_b128 v[20:23], v[52:53], off offset:16         // 0000007659B4: DC5E0010 147C0034
	global_load_b128 v[48:51], v[52:53], off offset:32         // 0000007659BC: DC5E0020 307C0034
	global_load_b128 v[52:55], v[52:53], off offset:48         // 0000007659C4: DC5E0030 347C0034
	s_waitcnt vmcnt(3)                                         // 0000007659CC: BF890FF7
	v_dot2_f32_bf16 v11, v11, v9, 0                            // 0000007659D0: CC1A400B 1A02130B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007659D8: BF870091
	v_dot2_f32_bf16 v11, v12, v10, v11                         // 0000007659DC: CC1A400B 1C2E150C
	v_dot2_f32_bf16 v11, v13, v15, v11                         // 0000007659E4: CC1A400B 1C2E1F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007659EC: BF8700A1
	v_dot2_f32_bf16 v11, v14, v60, v11                         // 0000007659F0: CC1A400B 1C2E790E
	s_waitcnt vmcnt(2)                                         // 0000007659F8: BF890BF7
	v_dot2_f32_bf16 v11, v20, v61, v11                         // 0000007659FC: CC1A400B 1C2E7B14
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000765A04: BF870091
	v_dot2_f32_bf16 v11, v21, v62, v11                         // 000000765A08: CC1A400B 1C2E7D15
	v_dot2_f32_bf16 v11, v22, v63, v11                         // 000000765A10: CC1A400B 1C2E7F16
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000765A18: BF8700A1
	v_dot2_f32_bf16 v11, v23, v64, v11                         // 000000765A1C: CC1A400B 1C2E8117
	s_waitcnt vmcnt(1)                                         // 000000765A24: BF8907F7
	v_dot2_f32_bf16 v11, v48, v65, v11                         // 000000765A28: CC1A400B 1C2E8330
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000765A30: BF870091
	v_dot2_f32_bf16 v11, v49, v66, v11                         // 000000765A34: CC1A400B 1C2E8531
	v_dot2_f32_bf16 v11, v50, v67, v11                         // 000000765A3C: CC1A400B 1C2E8732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000765A44: BF8700A1
	v_dot2_f32_bf16 v11, v51, v68, v11                         // 000000765A48: CC1A400B 1C2E8933
	s_waitcnt vmcnt(0)                                         // 000000765A50: BF8903F7
	v_dot2_f32_bf16 v11, v52, v69, v11                         // 000000765A54: CC1A400B 1C2E8B34
	.long 0xd7006a34                                           // 000000765A5C: D7006A34
	v_cndmask_b32_e32 v0, v56, v4, vcc_lo                      // 000000765A60: 02000938
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000765A64: BF870122
	v_dot2_f32_bf16 v11, v53, v70, v11                         // 000000765A68: CC1A400B 1C2E8D35
	v_add_co_ci_u32_e64 v53, null, s5, v57, vcc_lo             // 000000765A70: D5207C35 01AA7205
	v_dot2_f32_bf16 v11, v54, v71, v11                         // 000000765A78: CC1A400B 1C2E8F36
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000765A80: BF870091
	v_dot2_f32_bf16 v11, v55, v72, v11                         // 000000765A84: CC1A400B 1C2E9137
	v_fmac_f32_e32 v38, v47, v11                               // 000000765A8C: 564C172F
	s_clause 0x3                                               // 000000765A90: BF850003
	global_load_b128 v[11:14], v[52:53], off                   // 000000765A94: DC5E0000 0B7C0034
	global_load_b128 v[20:23], v[52:53], off offset:16         // 000000765A9C: DC5E0010 147C0034
	global_load_b128 v[48:51], v[52:53], off offset:32         // 000000765AA4: DC5E0020 307C0034
	global_load_b128 v[52:55], v[52:53], off offset:48         // 000000765AAC: DC5E0030 347C0034
	s_waitcnt vmcnt(3)                                         // 000000765AB4: BF890FF7
	v_dot2_f32_bf16 v9, v11, v9, 0                             // 000000765AB8: CC1A4009 1A02130B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000765AC0: BF870091
	v_dot2_f32_bf16 v9, v12, v10, v9                           // 000000765AC4: CC1A4009 1C26150C
	v_dot2_f32_bf16 v9, v13, v15, v9                           // 000000765ACC: CC1A4009 1C261F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000765AD4: BF8700A1
	v_dot2_f32_bf16 v9, v14, v60, v9                           // 000000765AD8: CC1A4009 1C26790E
	s_waitcnt vmcnt(2)                                         // 000000765AE0: BF890BF7
	v_dot2_f32_bf16 v9, v20, v61, v9                           // 000000765AE4: CC1A4009 1C267B14
	v_mov_b32_e32 v20, v16                                     // 000000765AEC: 7E280310
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000765AF0: BF870122
	v_dot2_f32_bf16 v9, v21, v62, v9                           // 000000765AF4: CC1A4009 1C267D15
	v_mov_b32_e32 v21, v17                                     // 000000765AFC: 7E2A0311
	v_dot2_f32_bf16 v9, v22, v63, v9                           // 000000765B00: CC1A4009 1C267F16
	v_mov_b32_e32 v22, v18                                     // 000000765B08: 7E2C0312
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000765B0C: BF870132
	v_dot2_f32_bf16 v9, v23, v64, v9                           // 000000765B10: CC1A4009 1C268117
	v_mov_b32_e32 v23, v19                                     // 000000765B18: 7E2E0313
	s_waitcnt vmcnt(1)                                         // 000000765B1C: BF8907F7
	v_dot2_f32_bf16 v9, v48, v65, v9                           // 000000765B20: CC1A4009 1C268330
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000765B28: BF870091
	v_dot2_f32_bf16 v9, v49, v66, v9                           // 000000765B2C: CC1A4009 1C268531
	v_dot2_f32_bf16 v9, v50, v67, v9                           // 000000765B34: CC1A4009 1C268732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000765B3C: BF8700A1
	v_dot2_f32_bf16 v9, v51, v68, v9                           // 000000765B40: CC1A4009 1C268933
	s_waitcnt vmcnt(0)                                         // 000000765B48: BF8903F7
	v_dot2_f32_bf16 v9, v52, v69, v9                           // 000000765B4C: CC1A4009 1C268B34
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000765B54: BF870091
	v_dot2_f32_bf16 v9, v53, v70, v9                           // 000000765B58: CC1A4009 1C268D35
	v_dot2_f32_bf16 v9, v54, v71, v9                           // 000000765B60: CC1A4009 1C268F36
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000765B68: BF870091
	v_dot2_f32_bf16 v9, v55, v72, v9                           // 000000765B6C: CC1A4009 1C269137
	v_dual_fmac_f32 v34, v47, v9 :: v_dual_mov_b32 v15, v8     // 000000765B74: C810132F 220E0108
	v_dual_mov_b32 v14, v7 :: v_dual_mov_b32 v13, v6           // 000000765B7C: CA100107 0E0C0106
	v_dual_mov_b32 v12, v5 :: v_dual_mov_b32 v11, v4           // 000000765B84: CA100105 0C0A0104
	v_dual_mov_b32 v10, v3 :: v_dual_mov_b32 v9, v2            // 000000765B8C: CA100103 0A080102
	v_mov_b32_e32 v8, v1                                       // 000000765B94: 7E100301
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 000000765B98: 917E107E
	s_cbranch_execz 35                                         // 000000765B9C: BFA50023 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xf2c>
	s_waitcnt vmcnt(0)                                         // 000000765BA0: BF8903F7
	v_dual_mov_b32 v16, v20 :: v_dual_add_nc_u32 v31, 32, v31  // 000000765BA4: CA200114 101E3EA0
	v_dual_mov_b32 v17, v21 :: v_dual_mov_b32 v18, v22         // 000000765BAC: CA100115 11120116
	v_mov_b32_e32 v19, v23                                     // 000000765BB4: 7E260317
	s_delay_alu instid0(VALU_DEP_3)                            // 000000765BB8: BF870003
	.long 0xd4460001                                           // 000000765BBC: D4460001
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 000000765BC0: 0202411F
	s_mov_b32 s18, exec_lo                                     // 000000765BC4: BE92007E
	.long 0xd4c1007e                                           // 000000765BC8: D4C1007E
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 000000765BCC: 0202411F
	s_cbranch_execz 64915                                      // 000000765BD0: BFA5FD93 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x520>
	v_ashrrev_i32_e32 v2, 31, v44                              // 000000765BD4: 3404589F
	.long 0xd7006a01                                           // 000000765BD8: D7006A01
	v_cndmask_b32_e32 v1, v25, v44, vcc_lo                     // 000000765BDC: 02025919
	v_mov_b32_e32 v46, v27                                     // 000000765BE0: 7E5C031B
	s_delay_alu instid0(VALU_DEP_3)                            // 000000765BE4: BF870003
	v_add_co_ci_u32_e64 v2, null, v36, v2, vcc_lo              // 000000765BE8: D5207C02 01AA0524
	v_cmp_ne_u32_e32 vcc_lo, 1, v35                            // 000000765BF0: 7C9A4681
	global_load_b128 v[16:19], v[1:2], off                     // 000000765BF4: DC5E0000 107C0001
	s_cbranch_vccnz 64904                                      // 000000765BFC: BFA4FD88 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x520>
	v_ashrrev_i32_e32 v2, 31, v45                              // 000000765C00: 34045A9F
	.long 0xd7006a01                                           // 000000765C04: D7006A01
	v_cndmask_b32_e32 v1, v24, v45, vcc_lo                     // 000000765C08: 02025B18
	s_delay_alu instid0(VALU_DEP_1)                            // 000000765C0C: BF870001
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 000000765C10: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 000000765C18: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000765C20: BF8903F7
	v_cvt_f32_f16_e32 v46, v1                                  // 000000765C24: 7E5C1701
	s_branch 64893                                             // 000000765C28: BFA0FD7D <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x520>
	s_or_b32 exec_lo, exec_lo, s16                             // 000000765C2C: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000765C30: BF8700B9
	s_or_b32 exec_lo, exec_lo, s14                             // 000000765C34: 8C7E0E7E
	.long 0xd71f0001                                           // 000000765C38: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000765C3C: 020100C1
	s_mov_b32 s0, exec_lo                                      // 000000765C40: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 000000765C44: 3A040290
	v_xor_b32_e32 v10, 8, v1                                   // 000000765C48: 3A140288
	v_xor_b32_e32 v18, 4, v1                                   // 000000765C4C: 3A240284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000765C50: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 000000765C54: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 000000765C58: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 000000765C5C: 7C9814A0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000765C60: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 000000765C64: 30040482
	ds_bpermute_b32 v3, v2, v37                                // 000000765C68: DACC0000 03002502
	s_waitcnt lgkmcnt(0)                                       // 000000765C70: BF89FC07
	v_add_f32_e32 v3, v37, v3                                  // 000000765C74: 06060725
	ds_bpermute_b32 v5, v2, v42                                // 000000765C78: DACC0000 05002A02
	ds_bpermute_b32 v7, v2, v40                                // 000000765C80: DACC0000 07002802
	ds_bpermute_b32 v9, v2, v38                                // 000000765C88: DACC0000 09002602
	v_cndmask_b32_e32 v10, v1, v10, vcc_lo                     // 000000765C90: 02141501
	ds_bpermute_b32 v4, v2, v43                                // 000000765C94: DACC0000 04002B02
	ds_bpermute_b32 v6, v2, v41                                // 000000765C9C: DACC0000 06002902
	ds_bpermute_b32 v8, v2, v39                                // 000000765CA4: DACC0000 08002702
	ds_bpermute_b32 v2, v2, v34                                // 000000765CAC: DACC0000 02002202
	v_cmp_gt_u32_e32 vcc_lo, 32, v18                           // 000000765CB4: 7C9824A0
	s_waitcnt lgkmcnt(6)                                       // 000000765CB8: BF89FC67
	v_add_f32_e32 v5, v42, v5                                  // 000000765CBC: 060A0B2A
	s_waitcnt lgkmcnt(5)                                       // 000000765CC0: BF89FC57
	v_dual_add_f32 v7, v40, v7 :: v_dual_lshlrev_b32 v10, 2, v10// 000000765CC4: C9220F28 070A1482
	s_waitcnt lgkmcnt(4)                                       // 000000765CCC: BF89FC47
	v_add_f32_e32 v9, v38, v9                                  // 000000765CD0: 06121326
	ds_bpermute_b32 v11, v10, v3                               // 000000765CD4: DACC0000 0B00030A
	ds_bpermute_b32 v13, v10, v5                               // 000000765CDC: DACC0000 0D00050A
	ds_bpermute_b32 v15, v10, v7                               // 000000765CE4: DACC0000 0F00070A
	ds_bpermute_b32 v17, v10, v9                               // 000000765CEC: DACC0000 1100090A
	s_waitcnt lgkmcnt(7)                                       // 000000765CF4: BF89FC77
	v_add_f32_e32 v4, v43, v4                                  // 000000765CF8: 0608092B
	s_waitcnt lgkmcnt(6)                                       // 000000765CFC: BF89FC67
	v_add_f32_e32 v6, v41, v6                                  // 000000765D00: 060C0D29
	s_waitcnt lgkmcnt(5)                                       // 000000765D04: BF89FC57
	v_add_f32_e32 v8, v39, v8                                  // 000000765D08: 06101127
	s_waitcnt lgkmcnt(3)                                       // 000000765D0C: BF89FC37
	v_dual_add_f32 v2, v34, v2 :: v_dual_add_f32 v3, v3, v11   // 000000765D10: C9080522 02021703
	ds_bpermute_b32 v14, v10, v6                               // 000000765D18: DACC0000 0E00060A
	s_waitcnt lgkmcnt(3)                                       // 000000765D20: BF89FC37
	v_add_f32_e32 v5, v5, v13                                  // 000000765D24: 060A1B05
	ds_bpermute_b32 v12, v10, v4                               // 000000765D28: DACC0000 0C00040A
	s_waitcnt lgkmcnt(3)                                       // 000000765D30: BF89FC37
	v_add_f32_e32 v7, v7, v15                                  // 000000765D34: 060E1F07
	s_waitcnt lgkmcnt(2)                                       // 000000765D38: BF89FC27
	v_add_f32_e32 v9, v9, v17                                  // 000000765D3C: 06122309
	ds_bpermute_b32 v16, v10, v8                               // 000000765D40: DACC0000 1000080A
	ds_bpermute_b32 v10, v10, v2                               // 000000765D48: DACC0000 0A00020A
	s_waitcnt lgkmcnt(2)                                       // 000000765D50: BF89FC27
	v_add_f32_e32 v4, v4, v12                                  // 000000765D54: 06081904
	s_waitcnt lgkmcnt(1)                                       // 000000765D58: BF89FC17
	v_add_f32_e32 v8, v8, v16                                  // 000000765D5C: 06102108
	s_waitcnt lgkmcnt(0)                                       // 000000765D60: BF89FC07
	v_add_f32_e32 v2, v2, v10                                  // 000000765D64: 06041502
	v_cndmask_b32_e32 v18, v1, v18, vcc_lo                     // 000000765D68: 02242501
	s_delay_alu instid0(VALU_DEP_1)                            // 000000765D6C: BF870001
	v_lshlrev_b32_e32 v18, 2, v18                              // 000000765D70: 30242482
	ds_bpermute_b32 v12, v18, v5                               // 000000765D74: DACC0000 0C000512
	s_waitcnt lgkmcnt(0)                                       // 000000765D7C: BF89FC07
	v_add_f32_e32 v5, v5, v12                                  // 000000765D80: 060A1905
	ds_bpermute_b32 v16, v18, v9                               // 000000765D84: DACC0000 10000912
	v_add_f32_e32 v6, v6, v14                                  // 000000765D8C: 060C1D06
	ds_bpermute_b32 v10, v18, v3                               // 000000765D90: DACC0000 0A000312
	ds_bpermute_b32 v14, v18, v7                               // 000000765D98: DACC0000 0E000712
	ds_bpermute_b32 v17, v18, v2                               // 000000765DA0: DACC0000 11000212
	s_waitcnt lgkmcnt(3)                                       // 000000765DA8: BF89FC37
	v_add_f32_e32 v9, v9, v16                                  // 000000765DAC: 06122109
	ds_bpermute_b32 v13, v18, v6                               // 000000765DB0: DACC0000 0D000612
	s_waitcnt lgkmcnt(3)                                       // 000000765DB8: BF89FC37
	v_add_f32_e32 v3, v3, v10                                  // 000000765DBC: 06061503
	ds_bpermute_b32 v11, v18, v4                               // 000000765DC0: DACC0000 0B000412
	s_waitcnt lgkmcnt(3)                                       // 000000765DC8: BF89FC37
	v_add_f32_e32 v7, v7, v14                                  // 000000765DCC: 060E1D07
	ds_bpermute_b32 v15, v18, v8                               // 000000765DD0: DACC0000 0F000812
	v_xor_b32_e32 v18, 2, v1                                   // 000000765DD8: 3A240282
	s_delay_alu instid0(VALU_DEP_1)                            // 000000765DDC: BF870001
	v_cmp_gt_u32_e32 vcc_lo, 32, v18                           // 000000765DE0: 7C9824A0
	s_waitcnt lgkmcnt(2)                                       // 000000765DE4: BF89FC27
	v_add_f32_e32 v6, v6, v13                                  // 000000765DE8: 060C1B06
	v_cndmask_b32_e32 v18, v1, v18, vcc_lo                     // 000000765DEC: 02242501
	s_waitcnt lgkmcnt(1)                                       // 000000765DF0: BF89FC17
	v_dual_add_f32 v4, v4, v11 :: v_dual_add_f32 v11, v2, v17  // 000000765DF4: C9081704 040A2302
	s_delay_alu instid0(VALU_DEP_2)                            // 000000765DFC: BF870002
	v_lshlrev_b32_e32 v18, 2, v18                              // 000000765E00: 30242482
	ds_bpermute_b32 v14, v18, v7                               // 000000765E04: DACC0000 0E000712
	s_waitcnt lgkmcnt(1)                                       // 000000765E0C: BF89FC17
	v_add_f32_e32 v8, v8, v15                                  // 000000765E10: 06101F08
	ds_bpermute_b32 v2, v18, v3                                // 000000765E14: DACC0000 02000312
	ds_bpermute_b32 v10, v18, v4                               // 000000765E1C: DACC0000 0A000412
	ds_bpermute_b32 v12, v18, v5                               // 000000765E24: DACC0000 0C000512
	ds_bpermute_b32 v13, v18, v6                               // 000000765E2C: DACC0000 0D000612
	ds_bpermute_b32 v15, v18, v8                               // 000000765E34: DACC0000 0F000812
	ds_bpermute_b32 v16, v18, v9                               // 000000765E3C: DACC0000 10000912
	ds_bpermute_b32 v17, v18, v11                              // 000000765E44: DACC0000 11000B12
	v_xor_b32_e32 v18, 1, v1                                   // 000000765E4C: 3A240281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000765E50: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v18                           // 000000765E54: 7C9824A0
	v_cndmask_b32_e32 v1, v1, v18, vcc_lo                      // 000000765E58: 02022501
	s_waitcnt lgkmcnt(6)                                       // 000000765E5C: BF89FC67
	v_dual_add_f32 v1, v3, v2 :: v_dual_lshlrev_b32 v18, 2, v1 // 000000765E60: C9220503 01120282
	s_waitcnt lgkmcnt(5)                                       // 000000765E68: BF89FC57
	v_add_f32_e32 v2, v4, v10                                  // 000000765E6C: 06041504
	s_waitcnt lgkmcnt(3)                                       // 000000765E70: BF89FC37
	v_dual_add_f32 v4, v5, v12 :: v_dual_add_f32 v5, v6, v13   // 000000765E74: C9081905 04041B06
	v_add_f32_e32 v3, v7, v14                                  // 000000765E7C: 06061D07
	s_waitcnt lgkmcnt(1)                                       // 000000765E80: BF89FC17
	v_dual_add_f32 v7, v8, v15 :: v_dual_add_f32 v10, v9, v16  // 000000765E84: C9081F08 070A2109
	s_waitcnt lgkmcnt(0)                                       // 000000765E8C: BF89FC07
	v_add_f32_e32 v12, v11, v17                                // 000000765E90: 0618230B
	ds_bpermute_b32 v6, v18, v1                                // 000000765E94: DACC0000 06000112
	ds_bpermute_b32 v8, v18, v2                                // 000000765E9C: DACC0000 08000212
	ds_bpermute_b32 v11, v18, v4                               // 000000765EA4: DACC0000 0B000412
	ds_bpermute_b32 v13, v18, v5                               // 000000765EAC: DACC0000 0D000512
	ds_bpermute_b32 v9, v18, v3                                // 000000765EB4: DACC0000 09000312
	ds_bpermute_b32 v14, v18, v7                               // 000000765EBC: DACC0000 0E000712
	ds_bpermute_b32 v15, v18, v10                              // 000000765EC4: DACC0000 0F000A12
	ds_bpermute_b32 v16, v18, v12                              // 000000765ECC: DACC0000 10000C12
	v_cmpx_eq_u32_e32 0, v30                                   // 000000765ED4: 7D943C80
	s_cbranch_execz 16                                         // 000000765ED8: BFA50010 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x121c>
	s_waitcnt lgkmcnt(2)                                       // 000000765EDC: BF89FC27
	v_dual_add_f32 v14, v7, v14 :: v_dual_add_f32 v19, v4, v11 // 000000765EE0: C9081D07 0E121704
	s_waitcnt vmcnt(0)                                         // 000000765EE8: BF8903F7
	v_add_f32_e32 v20, v5, v13                                 // 000000765EEC: 06281B05
	v_dual_add_f32 v18, v2, v8 :: v_dual_add_f32 v17, v1, v6   // 000000765EF0: C9081102 12100D01
	s_waitcnt lgkmcnt(0)                                       // 000000765EF8: BF89FC07
	v_dual_add_f32 v16, v12, v16 :: v_dual_lshlrev_b32 v1, 5, v29// 000000765EFC: C922210C 10003A85
	v_add_f32_e32 v15, v10, v15                                // 000000765F04: 061E1F0A
	v_add_f32_e32 v13, v3, v9                                  // 000000765F08: 061A1303
	ds_store_b128 v1, v[17:20] offset:1024                     // 000000765F0C: DB7C0400 00001101
	ds_store_b128 v1, v[13:16] offset:1040                     // 000000765F14: DB7C0410 00000D01
	s_or_b32 exec_lo, exec_lo, s0                              // 000000765F1C: 8C7E007E
	.long 0xd4510000                                           // 000000765F20: D4510000
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 000000765F24: 02001802
	v_cmp_gt_u32_e32 vcc_lo, 8, v0                             // 000000765F28: 7C980088
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000765F2C: BF890007
	s_barrier                                                  // 000000765F30: BFBD0000
	buffer_gl0_inv                                             // 000000765F34: E0AC0000 00000000
	s_and_b32 s0, vcc_lo, s0                                   // 000000765F3C: 8B00006A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000765F40: BF870009
	s_and_saveexec_b32 s1, s0                                  // 000000765F44: BE812000
	s_cbranch_execz 44                                         // 000000765F48: BFA5002C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x12fc>
	v_add_nc_u32_e32 v7, 0x400, v28                            // 000000765F4C: 4A0E38FF 00000400
	s_lshl_b64 s[0:1], s[2:3], 2                               // 000000765F54: 84808202
	ds_load_2addr_b32 v[1:2], v7 offset1:8                     // 000000765F58: D8DC0800 01000007
	ds_load_2addr_b32 v[3:4], v7 offset0:16 offset1:24         // 000000765F60: D8DC1810 03000007
	ds_load_2addr_b32 v[5:6], v7 offset0:32 offset1:40         // 000000765F68: D8DC2820 05000007
	s_waitcnt lgkmcnt(2)                                       // 000000765F70: BF89FC27
	v_add_f32_e32 v1, 0, v1                                    // 000000765F74: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000765F78: BF870131
	v_add_f32_e32 v9, v1, v2                                   // 000000765F7C: 06120501
	v_mad_u64_u32 v[1:2], null, s12, v0, 0                     // 000000765F80: D6FE7C01 0202000C
	s_waitcnt lgkmcnt(1)                                       // 000000765F88: BF89FC17
	v_add_f32_e32 v3, v9, v3                                   // 000000765F8C: 06060709
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000765F90: BF870191
	v_add_f32_e32 v4, v3, v4                                   // 000000765F94: 06080903
	v_mad_u64_u32 v[2:3], null, s13, v0, v[2:3]                // 000000765F98: D6FE7C02 040A000D
	s_waitcnt lgkmcnt(0)                                       // 000000765FA0: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000765FA4: BF8700C2
	v_add_f32_e32 v0, v4, v5                                   // 000000765FA8: 06000B04
	ds_load_2addr_b32 v[7:8], v7 offset0:48 offset1:56         // 000000765FAC: D8DC3830 07000007
	v_add_f32_e32 v3, v0, v6                                   // 000000765FB4: 06060D00
	.long 0xd73c0000                                           // 000000765FB8: D73C0000
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000765FBC: 02020282
	.long 0xd7006a00                                           // 000000765FC0: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 000000765FC4: 02020008
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000765FC8: BF870111
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 000000765FCC: D5207C01 01AA0209
	.long 0xd7006a00                                           // 000000765FD4: D7006A00
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 000000765FD8: 02000100
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000765FDC: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 000000765FE0: D5207C01 01AA0201
	s_waitcnt lgkmcnt(0)                                       // 000000765FE8: BF89FC07
	v_add_f32_e32 v2, v3, v7                                   // 000000765FEC: 06040F03
	v_add_f32_e32 v2, v2, v8                                   // 000000765FF0: 06041102
	global_store_b32 v[0:1], v2, off                           // 000000765FF4: DC6A0000 007C0200
	s_endpgm                                                   // 000000765FFC: BFB00000

