000000000054fe00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 00000054FE00: F4100100 F8000000
	v_dual_mov_b32 v18, 0 :: v_dual_and_b32 v1, 15, v0         // 00000054FE08: CA240080 1200008F
	v_lshrrev_b32_e32 v2, 2, v0                                // 00000054FE10: 32040082
	s_ashr_i32 s3, s2, 31                                      // 00000054FE14: 86039F02
	v_lshrrev_b32_e32 v14, 6, v0                               // 00000054FE18: 321C0086
	s_lshl_b64 s[2:3], s[2:3], 2                               // 00000054FE1C: 84828202
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000054FE20: BF8701A9
	v_dual_mov_b32 v4, s3 :: v_dual_lshlrev_b32 v1, 2, v1      // 00000054FE24: CA220003 04000282
	v_and_b32_e32 v2, 60, v2                                   // 00000054FE2C: 360404BC
	v_or_b32_e32 v3, s2, v14                                   // 00000054FE30: 38061C02
	v_bfe_u32 v15, v0, 5, 1                                    // 00000054FE34: D610000F 02050B00
	.long 0x7f0e3880                                           // 00000054FE3C: 7F0E3880
	v_mov_b32_e32 v17, 0                                       // 00000054FE40: 7E220280
	s_waitcnt lgkmcnt(0)                                       // 00000054FE44: BF89FC07
	s_clause 0x1                                               // 00000054FE48: BF850001
	global_load_b32 v5, v1, s[4:5]                             // 00000054FE4C: DC520000 05040001
	global_load_b32 v6, v2, s[4:5]                             // 00000054FE54: DC520000 06040002
	s_add_u32 s0, s4, s14                                      // 00000054FE5C: 80000E04
	s_addc_u32 s1, s5, s15                                     // 00000054FE60: 82010F05
	s_lshr_b32 s14, s11, 31                                    // 00000054FE64: 850E9F0B
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[3:4]                  // 00000054FE68: 7CA8060C
	s_add_u32 s14, s10, s14                                    // 00000054FE6C: 800E0E0A
	s_addc_u32 s15, s11, 0                                     // 00000054FE70: 820F800B
	s_ashr_i32 s20, s11, 31                                    // 00000054FE74: 86149F0B
	s_ashr_i64 s[14:15], s[14:15], 1                           // 00000054FE78: 868E810E
	s_lshr_b32 s20, s20, 27                                    // 00000054FE7C: 85149B14
	v_dual_cndmask_b32 v3, 0, v3 :: v_dual_and_b32 v16, 31, v0 // 00000054FE80: CA640680 0310009F
	s_add_u32 s20, s10, s20                                    // 00000054FE88: 8014140A
	s_addc_u32 s21, s11, 0                                     // 00000054FE8C: 8215800B
	v_cndmask_b32_e64 v4, 0, s3, vcc_lo                        // 00000054FE90: D5010004 01A80680
	s_lshr_b64 s[20:21], s[20:21], 5                           // 00000054FE98: 85948514
	.long 0xd72c0008                                           // 00000054FE9C: D72C0008
	v_cndmask_b32_e32 v1, s19, v3, vcc_lo                      // 00000054FEA0: 02020613
	s_add_i32 s21, s20, 1                                      // 00000054FEA4: 81158114
	.long 0xd72c000d                                           // 00000054FEA8: D72C000D
	v_cndmask_b32_e32 v0, v3, v15, vcc_lo                      // 00000054FEAC: 02001F03
	s_lshr_b32 s19, s21, 31                                    // 00000054FEB0: 85139F15
	v_mad_u64_u32 v[9:10], null, v3, s14, s[0:1]               // 00000054FEB4: D6FE7C09 00001D03
	s_add_i32 s21, s21, s19                                    // 00000054FEBC: 81151315
	.long 0xd72c0015                                           // 00000054FEC0: D72C0015
	v_cndmask_b32_e32 v0, v4, v14, vcc_lo                      // 00000054FEC4: 02001D04
	s_ashr_i32 s15, s21, 1                                     // 00000054FEC8: 860F8115
	s_add_u32 s0, s4, s16                                      // 00000054FECC: 80001004
	.long 0xd72c0013                                           // 00000054FED0: D72C0013
	v_cndmask_b32_e32 v1, s15, v15, vcc_lo                     // 00000054FED4: 02021E0F
	s_addc_u32 s1, s5, s17                                     // 00000054FED8: 82011105
	.long 0xd72c0016                                           // 00000054FEDC: D72C0016
	v_cndmask_b32_e32 v1, s18, v4, vcc_lo                      // 00000054FEE0: 02020812
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v2, 0               // 00000054FEE4: CA100080 01020080
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000054FEEC: BF870214
	v_add3_u32 v10, v21, v10, v13                              // 00000054FEF0: D655000A 04361515
	v_add_nc_u32_e32 v4, s15, v19                              // 00000054FEF8: 4A08260F
	v_add_nc_u32_e32 v19, v19, v16                             // 00000054FEFC: 4A262113
	s_waitcnt vmcnt(1)                                         // 00000054FF00: BF8907F7
	v_bfe_u32 v11, v5, 16, 1                                   // 00000054FF04: D610000B 02052105
	s_waitcnt vmcnt(0)                                         // 00000054FF0C: BF8903F7
	v_bfe_u32 v20, v6, 16, 1                                   // 00000054FF10: D6100014 02052106
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000054FF18: BF8701A2
	v_add3_u32 v5, v5, v11, 0x7fff                             // 00000054FF1C: D6550005 03FE1705 00007FFF
	v_mad_u64_u32 v[11:12], null, s18, v3, s[0:1]              // 00000054FF28: D6FE7C0B 00020612
	v_add3_u32 v6, v6, v20, 0x7fff                             // 00000054FF30: D6550006 03FE2906 00007FFF
	v_mov_b32_e32 v3, 0                                        // 00000054FF3C: 7E060280
	v_min_i32_e32 v20, s20, v4                                 // 00000054FF40: 22280814
	.long 0x7e0e3985                                           // 00000054FF44: 7E0E3985
	v_dual_mov_b32 v4, 0 :: v_dual_lshlrev_b32 v5, 2, v0       // 00000054FF48: CA220080 04040082
	v_add3_u32 v21, v8, v12, v22                               // 00000054FF50: D6550015 045A1908
	s_delay_alu instid0(VALU_DEP_3)                            // 00000054FF58: BF870003
	v_and_or_b32 v6, 0xffff0000, v6, v7                        // 00000054FF5C: D6570006 041E0CFF FFFF0000
	v_cmp_lt_i32_e32 vcc_lo, v19, v20                          // 00000054FF68: 7C822913
	ds_store_b32 v5, v6                                        // 00000054FF6C: D8340000 00000605
	s_waitcnt lgkmcnt(0)                                       // 00000054FF74: BF89FC07
	s_barrier                                                  // 00000054FF78: BFBD0000
	buffer_gl0_inv                                             // 00000054FF7C: E0AC0000 00000000
	s_and_saveexec_b32 s1, vcc_lo                              // 00000054FF84: BE81206A
	s_cbranch_execz 21                                         // 00000054FF88: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x1e0>
	v_lshlrev_b32_e32 v1, 1, v19                               // 00000054FF8C: 30022681
	v_lshlrev_b32_e32 v3, 4, v19                               // 00000054FF90: 30062684
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000054FF94: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000054FF98: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 00000054FF9C: 3408069F
	.long 0xd7000001                                           // 00000054FFA0: D7000001
	v_cndmask_b32_e32 v1, v11, v1, vcc_lo                      // 00000054FFA4: 0202030B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000054FFA8: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v21, v2, s0                  // 00000054FFAC: D5207C02 00020515
	.long 0xd7000003                                           // 00000054FFB4: D7000003
	v_cndmask_b32_e32 v1, v9, v3, vcc_lo                       // 00000054FFB8: 02020709
	v_add_co_ci_u32_e64 v4, null, v10, v4, s0                  // 00000054FFBC: D5207C04 0002090A
	s_clause 0x1                                               // 00000054FFC4: BF850001
	global_load_d16_b16 v5, v[1:2], off                        // 00000054FFC8: DC820000 057C0001
	global_load_b128 v[1:4], v[3:4], off                       // 00000054FFD0: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 00000054FFD8: BF8907F7
	v_cvt_f32_f16_e32 v18, v5                                  // 00000054FFDC: 7E241705
	s_or_b32 exec_lo, exec_lo, s1                              // 00000054FFE0: 8C7E017E
	v_mov_b32_e32 v22, 0                                       // 00000054FFE4: 7E2C0280
	s_and_saveexec_b32 s1, vcc_lo                              // 00000054FFE8: BE81206A
	s_cbranch_execz 264                                        // 00000054FFEC: BFA50108 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x610>
	v_dual_mov_b32 v22, 0 :: v_dual_add_nc_u32 v5, 32, v19     // 00000054FFF0: CA200080 160426A0
	v_dual_mov_b32 v17, 0 :: v_dual_lshlrev_b32 v12, 5, v19    // 00000054FFF8: CA220080 110C2685
	s_mov_b32 s14, 0                                           // 000000550000: BE8E0080
	s_delay_alu instid0(VALU_DEP_2)                            // 000000550004: BF870002
	v_lshlrev_b32_e32 v23, 4, v5                               // 000000550008: 302E0A84
	v_dual_mov_b32 v25, v18 :: v_dual_lshlrev_b32 v24, 1, v5   // 00000055000C: CA220112 19180A81
	s_lshl_b64 s[4:5], s[10:11], 1                             // 000000550014: 8484810A
	s_branch 221                                               // 000000550018: BFA000DD <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x590>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000055001C: 8C7E0A7E
	v_ashrrev_i32_e32 v13, 31, v12                             // 000000550020: 341A189F
	v_lshrrev_b32_e32 v58, 6, v1                               // 000000550024: 32740286
	v_lshrrev_b32_e32 v59, 14, v1                              // 000000550028: 3276028E
	v_and_b32_e32 v60, 0xff, v2                                // 00000055002C: 367804FF 000000FF
	v_lshrrev_b32_e32 v61, 6, v2                               // 000000550034: 327A0486
	.long 0xd73c001a                                           // 000000550038: D73C001A
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 00000055003C: 02021881
	v_and_b32_e32 v13, 0xff, v1                                // 000000550040: 361A02FF 000000FF
	v_and_b32_e32 v58, 0x3fc, v58                              // 000000550048: 367474FF 000003FC
	v_and_b32_e32 v59, 0x3fc, v59                              // 000000550050: 367676FF 000003FC
	v_lshrrev_b32_e32 v1, 22, v1                               // 000000550058: 32020296
	v_lshrrev_b32_e32 v62, 14, v2                              // 00000055005C: 327C048E
	.long 0xd7000032                                           // 000000550060: D7000032
	v_cndmask_b32_e32 v1, s6, v26, vcc_lo                      // 000000550064: 02023406
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000550068: BF8701A1
	v_add_co_ci_u32_e64 v51, null, s7, v27, s0                 // 00000055006C: D5207C33 00023607
	v_lshlrev_b32_e32 v13, 2, v13                              // 000000550074: 301A1A82
	.long 0xd7000036                                           // 000000550078: D7000036
	v_cndmask_b32_e32 v0, v50, v4, vcc_lo                      // 00000055007C: 02000932
	s_delay_alu instid0(VALU_DEP_1)                            // 000000550080: BF870001
	v_add_co_ci_u32_e64 v55, null, s5, v51, s0                 // 000000550084: D5207C37 00026605
	ds_load_b32 v13, v13                                       // 00000055008C: D8D80000 0D00000D
	ds_load_b32 v58, v58                                       // 000000550094: D8D80000 3A00003A
	ds_load_b32 v59, v59                                       // 00000055009C: D8D80000 3B00003B
	s_clause 0x7                                               // 0000005500A4: BF850007
	global_load_b128 v[26:29], v[50:51], off                   // 0000005500A8: DC5E0000 1A7C0032
	global_load_b128 v[30:33], v[54:55], off                   // 0000005500B0: DC5E0000 1E7C0036
	global_load_b128 v[34:37], v[50:51], off offset:16         // 0000005500B8: DC5E0010 227C0032
	global_load_b128 v[38:41], v[54:55], off offset:16         // 0000005500C0: DC5E0010 267C0036
	global_load_b128 v[42:45], v[50:51], off offset:32         // 0000005500C8: DC5E0020 2A7C0032
	global_load_b128 v[46:49], v[54:55], off offset:32         // 0000005500D0: DC5E0020 2E7C0036
	global_load_b128 v[50:53], v[50:51], off offset:48         // 0000005500D8: DC5E0030 327C0032
	global_load_b128 v[54:57], v[54:55], off offset:48         // 0000005500E0: DC5E0030 367C0036
	v_lshrrev_b32_e32 v2, 22, v2                               // 0000005500E8: 32040496
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000005500EC: 360202FF 000003FC
	v_lshlrev_b32_e32 v60, 2, v60                              // 0000005500F4: 30787882
	v_and_b32_e32 v61, 0x3fc, v61                              // 0000005500F8: 367A7AFF 000003FC
	v_and_b32_e32 v62, 0x3fc, v62                              // 000000550100: 367C7CFF 000003FC
	v_and_b32_e32 v2, 0x3fc, v2                                // 000000550108: 360404FF 000003FC
	ds_load_b32 v1, v1                                         // 000000550110: D8D80000 01000001
	ds_load_b32 v60, v60                                       // 000000550118: D8D80000 3C00003C
	ds_load_b32 v61, v61                                       // 000000550120: D8D80000 3D00003D
	ds_load_b32 v62, v62                                       // 000000550128: D8D80000 3E00003E
	ds_load_b32 v2, v2                                         // 000000550130: D8D80000 02000002
	v_add_nc_u32_e32 v23, 0x200, v23                           // 000000550138: 4A2E2EFF 00000200
	v_add_nc_u32_e32 v24, 64, v24                              // 000000550140: 4A3030C0
	v_add_nc_u32_e32 v12, 0x400, v12                           // 000000550144: 4A1818FF 00000400
	s_and_b32 s0, exec_lo, vcc_lo                              // 00000055014C: 8B006A7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000550150: BF870009
	s_or_b32 s14, s0, s14                                      // 000000550154: 8C0E0E00
	s_waitcnt vmcnt(7) lgkmcnt(7)                              // 000000550158: BF891C77
	v_dot2_f32_bf16 v26, v26, v13, 0                           // 00000055015C: CC1A401A 1A021B1A
	s_waitcnt vmcnt(6)                                         // 000000550164: BF891BF7
	v_dot2_f32_bf16 v13, v30, v13, 0                           // 000000550168: CC1A400D 1A021B1E
	v_and_b32_e32 v30, 0xff, v3                                // 000000550170: 363C06FF 000000FF
	s_waitcnt lgkmcnt(6)                                       // 000000550178: BF89FC67
	v_dot2_f32_bf16 v26, v27, v58, v26                         // 00000055017C: CC1A401A 1C6A751B
	s_delay_alu instid0(VALU_DEP_3)                            // 000000550184: BF870003
	v_dot2_f32_bf16 v13, v31, v58, v13                         // 000000550188: CC1A400D 1C36751F
	v_lshrrev_b32_e32 v27, 6, v3                               // 000000550190: 32360686
	v_lshrrev_b32_e32 v31, 14, v3                              // 000000550194: 323E068E
	v_lshrrev_b32_e32 v3, 22, v3                               // 000000550198: 32060696
	s_waitcnt lgkmcnt(5)                                       // 00000055019C: BF89FC57
	v_dot2_f32_bf16 v26, v28, v59, v26                         // 0000005501A0: CC1A401A 1C6A771C
	v_dot2_f32_bf16 v13, v32, v59, v13                         // 0000005501A8: CC1A400D 1C367720
	v_and_b32_e32 v27, 0x3fc, v27                              // 0000005501B0: 363636FF 000003FC
	v_and_b32_e32 v28, 0xff, v4                                // 0000005501B8: 363808FF 000000FF
	v_lshrrev_b32_e32 v32, 6, v4                               // 0000005501C0: 32400886
	s_waitcnt lgkmcnt(4)                                       // 0000005501C4: BF89FC47
	v_dot2_f32_bf16 v26, v29, v1, v26                          // 0000005501C8: CC1A401A 1C6A031D
	v_dot2_f32_bf16 v1, v33, v1, v13                           // 0000005501D0: CC1A4001 1C360321
	v_lshlrev_b32_e32 v13, 2, v30                              // 0000005501D8: 301A3C82
	v_and_b32_e32 v29, 0x3fc, v31                              // 0000005501DC: 363A3EFF 000003FC
	v_lshrrev_b32_e32 v58, 14, v4                              // 0000005501E4: 3274088E
	s_waitcnt vmcnt(5) lgkmcnt(3)                              // 0000005501E8: BF891437
	v_dot2_f32_bf16 v26, v34, v60, v26                         // 0000005501EC: CC1A401A 1C6A7922
	s_waitcnt vmcnt(4)                                         // 0000005501F4: BF8913F7
	v_dot2_f32_bf16 v1, v38, v60, v1                           // 0000005501F8: CC1A4001 1C067926
	ds_load_b32 v13, v13                                       // 000000550200: D8D80000 0D00000D
	ds_load_b32 v27, v27                                       // 000000550208: D8D80000 1B00001B
	ds_load_b32 v29, v29                                       // 000000550210: D8D80000 1D00001D
	s_waitcnt lgkmcnt(5)                                       // 000000550218: BF89FC57
	v_dot2_f32_bf16 v26, v35, v61, v26                         // 00000055021C: CC1A401A 1C6A7B23
	v_dot2_f32_bf16 v1, v39, v61, v1                           // 000000550224: CC1A4001 1C067B27
	v_lshrrev_b32_e32 v4, 22, v4                               // 00000055022C: 32080896
	v_and_b32_e32 v3, 0x3fc, v3                                // 000000550230: 360606FF 000003FC
	v_lshlrev_b32_e32 v28, 2, v28                              // 000000550238: 30383882
	s_waitcnt lgkmcnt(4)                                       // 00000055023C: BF89FC47
	v_dot2_f32_bf16 v26, v36, v62, v26                         // 000000550240: CC1A401A 1C6A7D24
	v_dot2_f32_bf16 v1, v40, v62, v1                           // 000000550248: CC1A4001 1C067D28
	v_and_b32_e32 v30, 0x3fc, v32                              // 000000550250: 363C40FF 000003FC
	v_and_b32_e32 v31, 0x3fc, v58                              // 000000550258: 363E74FF 000003FC
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000550260: 360808FF 000003FC
	s_waitcnt lgkmcnt(3)                                       // 000000550268: BF89FC37
	v_dot2_f32_bf16 v26, v37, v2, v26                          // 00000055026C: CC1A401A 1C6A0525
	v_dot2_f32_bf16 v1, v41, v2, v1                            // 000000550274: CC1A4001 1C060529
	ds_load_b32 v2, v3                                         // 00000055027C: D8D80000 02000003
	ds_load_b32 v3, v28                                        // 000000550284: D8D80000 0300001C
	ds_load_b32 v28, v30                                       // 00000055028C: D8D80000 1C00001E
	ds_load_b32 v30, v31                                       // 000000550294: D8D80000 1E00001F
	ds_load_b32 v31, v4                                        // 00000055029C: D8D80000 1F000004
	s_waitcnt vmcnt(3) lgkmcnt(7)                              // 0000005502A4: BF890C77
	v_dot2_f32_bf16 v4, v42, v13, v26                          // 0000005502A8: CC1A4004 1C6A1B2A
	s_waitcnt vmcnt(2)                                         // 0000005502B0: BF890BF7
	v_dot2_f32_bf16 v1, v46, v13, v1                           // 0000005502B4: CC1A4001 1C061B2E
	s_waitcnt lgkmcnt(6)                                       // 0000005502BC: BF89FC67
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000005502C0: BF870112
	v_dot2_f32_bf16 v4, v43, v27, v4                           // 0000005502C4: CC1A4004 1C12372B
	v_dot2_f32_bf16 v1, v47, v27, v1                           // 0000005502CC: CC1A4001 1C06372F
	s_waitcnt lgkmcnt(5)                                       // 0000005502D4: BF89FC57
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000005502D8: BF870112
	v_dot2_f32_bf16 v4, v44, v29, v4                           // 0000005502DC: CC1A4004 1C123B2C
	v_dot2_f32_bf16 v1, v48, v29, v1                           // 0000005502E4: CC1A4001 1C063B30
	s_waitcnt lgkmcnt(4)                                       // 0000005502EC: BF89FC47
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000005502F0: BF870112
	v_dot2_f32_bf16 v4, v45, v2, v4                            // 0000005502F4: CC1A4004 1C12052D
	v_dot2_f32_bf16 v1, v49, v2, v1                            // 0000005502FC: CC1A4001 1C060531
	s_waitcnt vmcnt(1) lgkmcnt(3)                              // 000000550304: BF890437
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000550308: BF870122
	v_dot2_f32_bf16 v2, v50, v3, v4                            // 00000055030C: CC1A4002 1C120732
	s_waitcnt vmcnt(0)                                         // 000000550314: BF8903F7
	v_dot2_f32_bf16 v1, v54, v3, v1                            // 000000550318: CC1A4001 1C060736
	v_dual_mov_b32 v4, v8 :: v_dual_mov_b32 v3, v7             // 000000550320: CA100108 04020107
	s_waitcnt lgkmcnt(2)                                       // 000000550328: BF89FC27
	v_dot2_f32_bf16 v2, v51, v28, v2                           // 00000055032C: CC1A4002 1C0A3933
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000550334: BF870123
	v_dot2_f32_bf16 v1, v55, v28, v1                           // 000000550338: CC1A4001 1C063937
	s_waitcnt lgkmcnt(1)                                       // 000000550340: BF89FC17
	v_dot2_f32_bf16 v2, v52, v30, v2                           // 000000550344: CC1A4002 1C0A3D34
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000055034C: BF870122
	v_dot2_f32_bf16 v1, v56, v30, v1                           // 000000550350: CC1A4001 1C063D38
	s_waitcnt lgkmcnt(0)                                       // 000000550358: BF89FC07
	v_dot2_f32_bf16 v7, v53, v31, v2                           // 00000055035C: CC1A4007 1C0A3F35
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000550364: BF8701A2
	v_dot2_f32_bf16 v8, v57, v31, v1                           // 000000550368: CC1A4008 1C063F39
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v1, v5             // 000000550370: CA100106 02000105
	v_fmac_f32_e32 v22, v18, v7                                // 000000550378: 562C0F12
	s_delay_alu instid0(VALU_DEP_3)                            // 00000055037C: BF870003
	v_dual_fmac_f32 v17, v18, v8 :: v_dual_mov_b32 v18, v25    // 000000550380: C8101112 11120119
	s_and_not1_b32 exec_lo, exec_lo, s14                       // 000000550388: 917E0E7E
	s_cbranch_execz 31                                         // 00000055038C: BFA5001F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x60c>
	s_waitcnt vmcnt(0)                                         // 000000550390: BF8903F7
	v_dual_mov_b32 v6, v2 :: v_dual_add_nc_u32 v19, 32, v19    // 000000550394: CA200102 061226A0
	v_dual_mov_b32 v5, v1 :: v_dual_mov_b32 v8, v4             // 00000055039C: CA100101 05080104
	v_mov_b32_e32 v7, v3                                       // 0000005503A4: 7E0E0303
	s_mov_b32 s10, exec_lo                                     // 0000005503A8: BE8A007E
	s_delay_alu instid0(VALU_DEP_3)                            // 0000005503AC: BF870003
	v_cmp_ge_i32_e32 vcc_lo, v19, v20                          // 0000005503B0: 7C8C2913
	.long 0xd4c1007e                                           // 0000005503B4: D4C1007E
	v_cndmask_b32_e32 v1, v19, v20, vcc_lo                     // 0000005503B8: 02022913
	s_cbranch_execz 65303                                      // 0000005503BC: BFA5FF17 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x21c>
	v_ashrrev_i32_e32 v6, 31, v24                              // 0000005503C0: 340C309F
	v_ashrrev_i32_e32 v8, 31, v23                              // 0000005503C4: 34102E9F
	.long 0xd7000005                                           // 0000005503C8: D7000005
	v_cndmask_b32_e32 v1, v11, v24, vcc_lo                     // 0000005503CC: 0202310B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005503D0: BF8700A1
	v_add_co_ci_u32_e64 v6, null, v21, v6, s0                  // 0000005503D4: D5207C06 00020D15
	.long 0xd7000007                                           // 0000005503DC: D7000007
	v_cndmask_b32_e32 v1, v9, v23, vcc_lo                      // 0000005503E0: 02022F09
	v_add_co_ci_u32_e64 v8, null, v10, v8, s0                  // 0000005503E4: D5207C08 0002110A
	s_clause 0x1                                               // 0000005503EC: BF850001
	global_load_d16_b16 v13, v[5:6], off                       // 0000005503F0: DC820000 0D7C0005
	global_load_b128 v[5:8], v[7:8], off                       // 0000005503F8: DC5E0000 057C0007
	s_waitcnt vmcnt(1)                                         // 000000550400: BF8907F7
	v_cvt_f32_f16_e32 v25, v13                                 // 000000550404: 7E32170D
	s_branch 65284                                             // 000000550408: BFA0FF04 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x21c>
	s_or_b32 exec_lo, exec_lo, s14                             // 00000055040C: 8C7E0E7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000550410: BF8700C9
	s_or_b32 exec_lo, exec_lo, s1                              // 000000550414: 8C7E017E
	s_waitcnt vmcnt(0)                                         // 000000550418: BF8903F7
	.long 0xd71f0001                                           // 00000055041C: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000550420: 020100C1
	s_mov_b32 s0, exec_lo                                      // 000000550424: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 000000550428: 3A040290
	v_xor_b32_e32 v4, 8, v1                                    // 00000055042C: 3A080288
	v_xor_b32_e32 v6, 4, v1                                    // 000000550430: 3A0C0284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000550434: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 000000550438: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 00000055043C: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 000000550440: 7C9808A0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000550444: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 000000550448: 30040482
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo                       // 00000055044C: 02080901
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 000000550450: 7C980CA0
	ds_bpermute_b32 v3, v2, v22                                // 000000550454: DACC0000 03001602
	v_lshlrev_b32_e32 v4, 2, v4                                // 00000055045C: 30080882
	v_cndmask_b32_e32 v6, v1, v6, vcc_lo                       // 000000550460: 020C0D01
	s_waitcnt lgkmcnt(0)                                       // 000000550464: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 000000550468: BF870001
	v_dual_add_f32 v3, v22, v3 :: v_dual_lshlrev_b32 v6, 2, v6 // 00000055046C: C9220716 03060C82
	ds_bpermute_b32 v5, v4, v3                                 // 000000550474: DACC0000 05000304
	s_waitcnt lgkmcnt(0)                                       // 00000055047C: BF89FC07
	v_add_f32_e32 v3, v3, v5                                   // 000000550480: 06060B03
	ds_bpermute_b32 v2, v2, v17                                // 000000550484: DACC0000 02001102
	s_waitcnt lgkmcnt(0)                                       // 00000055048C: BF89FC07
	v_add_f32_e32 v2, v17, v2                                  // 000000550490: 06040511
	ds_bpermute_b32 v4, v4, v2                                 // 000000550494: DACC0000 04000204
	s_waitcnt lgkmcnt(0)                                       // 00000055049C: BF89FC07
	v_add_f32_e32 v2, v2, v4                                   // 0000005504A0: 06040902
	ds_bpermute_b32 v4, v6, v3                                 // 0000005504A4: DACC0000 04000306
	ds_bpermute_b32 v5, v6, v2                                 // 0000005504AC: DACC0000 05000206
	v_xor_b32_e32 v6, 2, v1                                    // 0000005504B4: 3A0C0282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000005504B8: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 0000005504BC: 7C980CA0
	v_cndmask_b32_e32 v6, v1, v6, vcc_lo                       // 0000005504C0: 020C0D01
	s_waitcnt lgkmcnt(1)                                       // 0000005504C4: BF89FC17
	v_dual_add_f32 v3, v3, v4 :: v_dual_lshlrev_b32 v6, 2, v6  // 0000005504C8: C9220903 03060C82
	s_waitcnt lgkmcnt(0)                                       // 0000005504D0: BF89FC07
	v_add_f32_e32 v4, v2, v5                                   // 0000005504D4: 06080B02
	ds_bpermute_b32 v2, v6, v3                                 // 0000005504D8: DACC0000 02000306
	ds_bpermute_b32 v5, v6, v4                                 // 0000005504E0: DACC0000 05000406
	v_xor_b32_e32 v6, 1, v1                                    // 0000005504E8: 3A0C0281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005504EC: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 0000005504F0: 7C980CA0
	v_cndmask_b32_e32 v1, v1, v6, vcc_lo                       // 0000005504F4: 02020D01
	v_lshlrev_b32_e32 v6, 2, v1                                // 0000005504F8: 300C0282
	s_waitcnt lgkmcnt(0)                                       // 0000005504FC: BF89FC07
	v_dual_add_f32 v2, v3, v2 :: v_dual_add_f32 v1, v4, v5     // 000000550500: C9080503 02000B04
	ds_bpermute_b32 v4, v6, v2                                 // 000000550508: DACC0000 04000206
	ds_bpermute_b32 v3, v6, v1                                 // 000000550510: DACC0000 03000106
	v_cmpx_eq_u32_e32 0, v16                                   // 000000550518: 7D942080
	s_cbranch_execz 10                                         // 00000055051C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x748>
	s_waitcnt lgkmcnt(1)                                       // 000000550520: BF89FC17
	v_dual_add_f32 v2, v2, v4 :: v_dual_lshlrev_b32 v5, 3, v15 // 000000550524: C9220902 02041E83
	s_waitcnt lgkmcnt(0)                                       // 00000055052C: BF89FC07
	v_add_f32_e32 v3, v1, v3                                   // 000000550530: 06060701
	s_delay_alu instid0(VALU_DEP_2)                            // 000000550534: BF870002
	v_lshl_or_b32 v4, v14, 4, v5                               // 000000550538: D6560004 0415090E
	ds_store_b64 v4, v[2:3] offset:1024                        // 000000550540: D9340400 00000204
	s_or_b32 exec_lo, exec_lo, s0                              // 000000550548: 8C7E007E
	s_waitcnt lgkmcnt(0)                                       // 00000055054C: BF89FC07
	v_lshrrev_b32_e32 v3, 1, v0                                // 000000550550: 32060081
	v_mov_b32_e32 v2, s3                                       // 000000550554: 7E040203
	.long 0xd44c0000                                           // 000000550558: D44C0000
	v_cndmask_b32_e32 v1, 8, v0, vcc_lo                        // 00000055055C: 02020088
	s_barrier                                                  // 000000550560: BFBD0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 000000550564: BF8704C3
	v_or_b32_e32 v1, s2, v3                                    // 000000550568: 38020602
	buffer_gl0_inv                                             // 00000055056C: E0AC0000 00000000
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 000000550574: 7CA8020C
	s_and_b32 s0, s0, vcc_lo                                   // 000000550578: 8B006A00
	s_and_saveexec_b32 s1, s0                                  // 00000055057C: BE812000
	s_cbranch_execz 39                                         // 000000550580: BFA50027 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x820>
	v_and_b32_e32 v0, 1, v0                                    // 000000550584: 36000081
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000550588: BF8701B1
	v_lshlrev_b32_e32 v4, 2, v0                                // 00000055058C: 30080082
	.long 0xd72c0006                                           // 000000550590: D72C0006
	v_cndmask_b32_e32 v1, s13, v0, vcc_lo                      // 000000550594: 0202000D
	.long 0xd72c0005                                           // 000000550598: D72C0005
	v_cndmask_b32_e32 v1, s12, v0, vcc_lo                      // 00000055059C: 0202000C
	v_lshl_or_b32 v3, v3, 4, v4                                // 0000005505A0: D6560003 04110903
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000005505A8: BF8700C1
	v_add_nc_u32_e32 v3, 0x400, v3                             // 0000005505AC: 4A0606FF 00000400
	ds_load_2addr_b32 v[3:4], v3 offset1:2                     // 0000005505B4: D8DC0200 03000003
	s_waitcnt lgkmcnt(0)                                       // 0000005505BC: BF89FC07
	v_add_f32_e32 v0, 0, v3                                    // 0000005505C0: 06000680
	v_add_f32_e32 v7, v0, v4                                   // 0000005505C4: 060E0900
	.long 0xd73c0003                                           // 0000005505C8: D73C0003
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 0000005505CC: 02020A81
	.long 0xd73c0000                                           // 0000005505D0: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000005505D4: 02020281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000005505D8: BF870193
	v_bfe_u32 v2, v7, 16, 1                                    // 0000005505DC: D6100002 02052107
	.long 0xd7006a03                                           // 0000005505E4: D7006A03
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 0000005505E8: 02020608
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000005505EC: BF870191
	v_add_co_ci_u32_e64 v4, null, s9, v4, vcc_lo               // 0000005505F0: D5207C04 01AA0809
	v_add3_u32 v2, v7, v2, 0x7fff                              // 0000005505F8: D6550002 03FE0507 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000550604: BF870093
	.long 0xd7006a00                                           // 000000550608: D7006A00
	v_cndmask_b32_e32 v1, v3, v0, vcc_lo                       // 00000055060C: 02020103
	v_add_co_ci_u32_e64 v1, null, v4, v1, vcc_lo               // 000000550610: D5207C01 01AA0304
	global_store_d16_hi_b16 v[0:1], v2, off                    // 000000550618: DC960000 007C0200
	s_endpgm                                                   // 000000550620: BFB00000
		...

