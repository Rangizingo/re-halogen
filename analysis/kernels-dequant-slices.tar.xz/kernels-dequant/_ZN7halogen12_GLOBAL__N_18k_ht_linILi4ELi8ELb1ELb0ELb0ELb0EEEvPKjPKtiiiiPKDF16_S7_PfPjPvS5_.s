0000000000545800 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_>:
; _ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_():
	s_clause 0x3                                               // 000000545800: BF850003
	s_load_b256 s[12:19], s[0:1], null                         // 000000545804: F40C0300 F8000000
	s_load_b256 s[20:27], s[0:1], 0x20                         // 00000054580C: F40C0500 F8000020
	s_load_b128 s[28:31], s[0:1], 0x40                         // 000000545814: F4080700 F8000040
	s_load_b32 s33, s[0:1], 0x54                               // 00000054581C: F4000840 F8000054
	v_lshrrev_b32_e32 v35, 5, v0                               // 000000545824: 32460085
	v_and_b32_e32 v36, 31, v0                                  // 000000545828: 3648009F
	s_mov_b32 s10, s3                                          // 00000054582C: BE8A0003
	s_waitcnt lgkmcnt(0)                                       // 000000545830: BF89FC07
	s_ashr_i32 s11, s17, 31                                    // 000000545834: 860B9F11
	s_mul_i32 s34, s19, s3                                     // 000000545838: 96220313
	s_lshr_b32 s0, s11, 25                                     // 00000054583C: 8500990B
	s_add_i32 s1, s34, s19                                     // 000000545840: 81011322
	s_add_i32 s0, s17, s0                                      // 000000545844: 81000011
	s_mov_b32 s19, exec_lo                                     // 000000545848: BE93007E
	s_ashr_i32 s0, s0, 7                                       // 00000054584C: 86008700
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000545850: BF870499
	s_min_i32 s0, s0, s1                                       // 000000545854: 89000100
	s_sub_i32 s1, s0, s34                                      // 000000545858: 81812200
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000054585C: BF870499
	s_lshl_b32 s9, s1, 3                                       // 000000545860: 84098301
	.long 0xd4c4007e                                           // 000000545864: D4C4007E
	v_cndmask_b32_e32 v1, s9, v35, vcc_lo                      // 000000545868: 02024609
	s_cbranch_execz 504                                        // 00000054586C: BFA501F8 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x850>
	s_add_i32 s35, s16, -1                                     // 000000545870: 8123C110
	s_cmp_lg_u64 s[30:31], 0                                   // 000000545874: BF11801E
	v_and_b32_e32 v2, 1, v0                                    // 000000545878: 36040081
	s_cselect_b32 s36, -1, 0                                   // 00000054587C: 982480C1
	s_abs_i32 s37, s1                                          // 000000545880: BEA51501
	v_lshlrev_b32_e32 v7, 3, v36                               // 000000545884: 300E4883
	s_cvt_f32_u32 s0, s37                                      // 000000545888: BE806525
	v_dual_mov_b32 v8, v35 :: v_dual_lshlrev_b32 v1, 2, v36    // 00000054588C: CA220123 08004882
	v_and_b32_e32 v4, 2, v0                                    // 000000545894: 36080082
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000545898: BF870009
	v_rcp_iflag_f32_e32 v3, s0                                 // 00000054589C: 7E065600
	v_and_b32_e32 v5, 4, v0                                    // 0000005458A0: 360A0084
	v_and_b32_e32 v6, 8, v0                                    // 0000005458A4: 360C0088
	v_add_nc_u32_e32 v9, s34, v35                              // 0000005458A8: 4A124622
	s_ashr_i32 s40, s1, 31                                     // 0000005458AC: 86289F01
	s_lshl_b32 s41, s1, 8                                      // 0000005458B0: 84298801
	s_lshl_b32 s6, s1, 7                                       // 0000005458B4: 84068701
	.long 0xd44a0001                                           // 0000005458B8: D44A0001
	v_cndmask_b32_e32 v1, 0, v2, vcc_lo                        // 0000005458BC: 02020480
	v_lshl_or_b32 v2, v35, 8, v7                               // 0000005458C0: D6560002 041D1123
	s_sub_i32 s8, 0, s37                                       // 0000005458C8: 81882580
	v_readfirstlane_b32 s4, v3                                 // 0000005458CC: 7E080503
	s_mul_i32 s43, s40, 0x1400                                 // 0000005458D0: 962BFF28 00001400
	.long 0xd44c0000                                           // 0000005458D8: D44C0000
	v_cndmask_b32_e32 v1, 16, v36, vcc_lo                      // 0000005458DC: 02024890
	.long 0xd44a0003                                           // 0000005458E0: D44A0003
	v_cndmask_b32_e32 v1, 0, v4, vcc_lo                        // 0000005458E4: 02020880
	.long 0xd44a0005                                           // 0000005458E8: D44A0005
	v_cndmask_b32_e32 v1, 0, v6, vcc_lo                        // 0000005458EC: 02020C80
	s_mul_f32 s7, s4, 0x4f7ffffe                               // 0000005458F0: A207FF04 4F7FFFFE
	.long 0xd44a0004                                           // 0000005458F8: D44A0004
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 0000005458FC: 02020A80
	v_lshl_or_b32 v1, v9, 7, v1                                // 000000545900: D6560001 04050F09
	v_subrev_nc_u32_e32 v9, s43, v2                            // 000000545908: 4E12042B
	s_cvt_u32_f32 s7, s7                                       // 00000054590C: BE876707
	s_sub_i32 s42, 0, s6                                       // 000000545910: 81AA0680
	s_mov_b32 s38, s17                                         // 000000545914: BEA60011
	s_mov_b32 s39, 0                                           // 000000545918: BEA70080
	s_mul_i32 s8, s8, s7                                       // 00000054591C: 96080708
	s_mov_b32 s44, 0x76543210                                  // 000000545920: BEAC00FF 76543210
	s_mul_hi_u32 s6, s7, s8                                    // 000000545928: 96860807
	s_mov_b32 s45, 0x3db504f3                                  // 00000054592C: BEAD00FF 3DB504F3
	s_add_i32 s43, s7, s6                                      // 000000545934: 812B0607
	s_branch 164                                               // 000000545938: BFA000A4 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x3cc>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000054593C: BF870091
	.long 0xd7006a02                                           // 000000545940: D7006A02
	v_cndmask_b32_e32 v1, s20, v2, vcc_lo                      // 000000545944: 02020414
	v_add_co_ci_u32_e64 v3, null, s21, v3, vcc_lo              // 000000545948: D5207C03 01AA0615
	v_sub_f32_e32 v4, v15, v13                                 // 000000545950: 08081B0F
	v_add_nc_u32_e32 v1, 0x400, v1                             // 000000545954: 4A0202FF 00000400
	global_load_d16_b16 v2, v[2:3], off offset:6               // 00000054595C: DC820006 027C0002
	s_waitcnt vmcnt(0)                                         // 000000545964: BF8903F7
	v_fma_mix_f32 v5, v14, v2, v12 op_sel_hi:[0,1,0]           // 000000545968: CC200005 1432050E
	v_fma_mix_f32 v2, -v14, v2, v12 op_sel_hi:[0,1,0]          // 000000545970: CC200002 3432050E
	v_add_f32_e32 v3, v15, v13                                 // 000000545978: 06061B0F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000054597C: BF8701A2
	v_add_f32_e32 v7, v4, v2                                   // 000000545980: 060E0504
	v_sub_f32_e32 v2, v4, v2                                   // 000000545984: 08040504
	v_add_f32_e32 v6, v3, v5                                   // 000000545988: 060C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 00000054598C: 08060B03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000545990: BF870193
	v_mov_b32_dpp v13, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000545994: 7E1A02FA FF016102
	v_mov_b32_dpp v4, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000054599C: 7E0802FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 0000005459A4: D5010006 20060D06
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 0000005459AC: D5010002 20060502
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000005459B4: BF870142
	v_add_f32_e32 v4, v6, v4                                   // 0000005459B8: 06080906
	v_mov_b32_dpp v5, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000005459BC: 7E0A02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 0000005459C4: D5010007 20060F07
	.long 0xd72c0006                                           // 0000005459CC: D72C0006
	v_cndmask_b32_e32 v1, 0x1400, v11, vcc_lo                  // 0000005459D0: 020216FF 00001400
	v_add_f32_e32 v5, v7, v5                                   // 0000005459D8: 060A0B07
	v_mov_b32_dpp v7, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000005459DC: 7E0E02FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 0000005459E4: D5010004 200E0904
	s_delay_alu instid0(VALU_DEP_1)                            // 0000005459EC: BF870001
	v_add_f32_e32 v4, v4, v7                                   // 0000005459F0: 06080F04
	v_mov_b32_dpp v12, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000005459F4: 7E1802FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 0000005459FC: D5010003 20060703
	.long 0xd72c0007                                           // 000000545A04: D72C0007
	v_cndmask_b32_e32 v1, s41, v10, vcc_lo                     // 000000545A08: 02021429
	v_add_f32_e32 v2, v2, v13                                  // 000000545A0C: 06041B02
	v_mov_b32_dpp v10, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000545A10: 7E1402FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s4                          // 000000545A18: D5010004 20120904
	v_add_f32_e32 v3, v3, v12                                  // 000000545A20: 06061903
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000545A24: BF870224
	v_mov_b32_dpp v13, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000545A28: 7E1A02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 000000545A30: D5010002 200E0502
	v_add_f32_e32 v4, v4, v10                                  // 000000545A38: 06081504
	v_mov_b32_dpp v11, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000545A3C: 7E1602FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 000000545A44: D5010005 200E0B05
	v_mov_b32_dpp v12, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000545A4C: 7E1802FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 000000545A54: D5010003 200E0703
	v_add_f32_e32 v2, v2, v13                                  // 000000545A5C: 06041B02
	v_mov_b32_dpp v10, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000545A60: 7E1402FA FF016804
	v_add_f32_e32 v5, v5, v11                                  // 000000545A68: 060A1705
	v_cndmask_b32_e64 v4, -v4, v4, s5                          // 000000545A6C: D5010004 20160904
	v_add_f32_e32 v3, v3, v12                                  // 000000545A74: 06061903
	v_mov_b32_dpp v13, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000545A78: 7E1A02FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s4                          // 000000545A80: D5010002 20120502
	v_mov_b32_dpp v11, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000545A88: 7E1602FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s4                          // 000000545A90: D5010005 20120B05
	v_mov_b32_dpp v12, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000545A98: 7E1802FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s4                          // 000000545AA0: D5010003 20120703
	v_add_f32_e32 v2, v2, v13                                  // 000000545AA8: 06041B02
	v_sub_nc_u32_e32 v6, v6, v7                                // 000000545AAC: 4C0C0F06
	v_add_f32_e32 v5, v5, v11                                  // 000000545AB0: 060A1705
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000545AB4: BF870214
	v_add_f32_e32 v3, v3, v12                                  // 000000545AB8: 06061903
	v_mov_b32_dpp v13, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000545ABC: 7E1A02FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s5                          // 000000545AC4: D5010002 20160502
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000545ACC: BF870254
	v_mov_b32_dpp v11, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000545AD0: 7E1602FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s5                          // 000000545AD8: D5010005 20160B05
	v_add_nc_u32_e32 v8, 8, v8                                 // 000000545AE0: 4A101088
	v_mov_b32_dpp v12, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000545AE4: 7E1802FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s5                          // 000000545AEC: D5010003 20160703
	v_dual_add_f32 v4, v4, v10 :: v_dual_add_f32 v5, v5, v11   // 000000545AF4: C9081504 04041705
	v_add_f32_e32 v2, v2, v13                                  // 000000545AFC: 06041B02
	v_cmp_le_i32_e32 vcc_lo, s9, v8                            // 000000545B00: 7C861009
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000545B04: BF870214
	v_dual_add_f32 v3, v3, v12 :: v_dual_add_nc_u32 v6, v9, v6 // 000000545B08: C9201903 03060D09
	v_dual_mov_b32 v11, v5 :: v_dual_mov_b32 v10, v4           // 000000545B10: CA100105 0B0A0104
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000545B18: BF870234
	v_mov_b32_e32 v13, v2                                      // 000000545B1C: 7E1A0302
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 000000545B20: D5010005 20020B05
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 000000545B28: D5010004 20020904
	v_permlanex16_b32 v11, v11, s44, 0xfedcba98                // 000000545B30: D65C000B 03FC590B FEDCBA98
	v_mov_b32_e32 v12, v3                                      // 000000545B3C: 7E180303
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 000000545B40: D5010002 20020502
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 000000545B48: D5010003 20020703
	v_permlanex16_b32 v10, v10, s44, 0xfedcba98                // 000000545B50: D65C000A 03FC590A FEDCBA98
	v_permlanex16_b32 v13, v13, s44, 0xfedcba98                // 000000545B5C: D65C000D 03FC590D FEDCBA98
	v_add_f32_e32 v5, v5, v11                                  // 000000545B68: 060A1705
	v_permlanex16_b32 v12, v12, s44, 0xfedcba98                // 000000545B6C: D65C000C 03FC590C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000545B78: BF870214
	v_dual_add_f32 v4, v4, v10 :: v_dual_add_nc_u32 v9, 0x800, v9// 000000545B7C: C9201504 040812FF 00000800
	v_add_f32_e32 v7, v2, v13                                  // 000000545B88: 060E1B02
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000545B8C: BF870214
	v_fma_mixhi_f16 v2, v5, s45, 0                             // 000000545B90: CC220002 02005B05
	v_add_f32_e32 v10, v3, v12                                 // 000000545B98: 06141903
	s_or_b32 s39, vcc_lo, s39                                  // 000000545B9C: 8C27276A
	v_fma_mixlo_f16 v2, v4, s45, 0                             // 000000545BA0: CC210002 02005B04
	v_fma_mixhi_f16 v3, v7, s45, 0                             // 000000545BA8: CC220003 02005B07
	s_delay_alu instid0(VALU_DEP_3)                            // 000000545BB0: BF870003
	v_fma_mixlo_f16 v3, v10, s45, 0                            // 000000545BB4: CC210003 02005B0A
	ds_store_b64 v6, v[2:3]                                    // 000000545BBC: D9340000 00000206
	s_and_not1_b32 exec_lo, exec_lo, s39                       // 000000545BC4: 917E277E
	s_cbranch_execz 289                                        // 000000545BC8: BFA50121 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x850>
	.long 0xd72d0002                                           // 000000545BCC: D72D0002
	v_cndmask_b32_e32 v0, v8, v43, vcc_lo                      // 000000545BD0: 02005708
	s_mov_b32 s6, -1                                           // 000000545BD4: BE8600C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000545BD8: BF870091
	.long 0xd72c0003                                           // 000000545BDC: D72C0003
	v_cndmask_b32_e32 v0, v2, v37, vcc_lo                      // 000000545BE0: 02004B02
	v_sub_nc_u32_e32 v3, v8, v3                                // 000000545BE4: 4C060708
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000545BE8: BF870121
	v_subrev_nc_u32_e32 v5, s37, v3                            // 000000545BEC: 4E0A0625
	v_cmp_le_u32_e32 vcc_lo, s37, v3                           // 000000545BF0: 7C960625
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_add_nc_u32 v4, 1, v2// 000000545BF4: CA600B03 03040481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000545BFC: BF870111
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000545C00: 02040902
	v_cmp_le_u32_e32 vcc_lo, s37, v3                           // 000000545C04: 7C960625
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000545C08: BF870092
	v_add_nc_u32_e32 v4, 1, v2                                 // 000000545C0C: 4A080481
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000545C10: 02040902
	s_and_not1_b32 vcc_lo, exec_lo, s36                        // 000000545C14: 916A247E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000545C18: BF870091
	v_xor_b32_e32 v11, s40, v2                                 // 000000545C1C: 3A160428
	v_subrev_nc_u32_e32 v10, s40, v11                          // 000000545C20: 4E141628
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000545C24: BF8700A1
	v_mad_u64_u32 v[6:7], null, s42, v10, v[1:2]               // 000000545C28: D6FE7C06 0406142A
	v_min_i32_e32 v2, s35, v10                                 // 000000545C30: 22041423
	v_mad_i64_i32 v[4:5], null, v2, s38, 0                     // 000000545C34: D6FF7C04 02004D02
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000545C3C: BF870093
	v_ashrrev_i32_e32 v7, 31, v6                               // 000000545C40: 340E0C9F
	.long 0xd73c0002                                           // 000000545C44: D73C0002
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000545C48: 02020C81
	s_cbranch_vccnz 212                                        // 000000545C4C: BFA400D4 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x7a0>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000545C50: BF870093
	.long 0xd7006a06                                           // 000000545C54: D7006A06
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 000000545C58: 02020D04
	v_add_co_ci_u32_e64 v7, null, v5, v7, vcc_lo               // 000000545C5C: D5207C07 01AA0F05
	.long 0x7f383880                                           // 000000545C64: 7F383880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000545C68: BF870112
	.long 0xd73c0006                                           // 000000545C6C: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000545C70: 02020C81
	.long 0x7f3e399c                                           // 000000545C74: 7F3E399C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000545C78: BF870092
	.long 0xd7006a0c                                           // 000000545C7C: D7006A0C
	v_cndmask_b32_e32 v1, s14, v6, vcc_lo                      // 000000545C80: 02020C0E
	v_add_co_ci_u32_e64 v13, null, s15, v7, vcc_lo             // 000000545C84: D5207C0D 01AA0E0F
	.long 0xd7006a06                                           // 000000545C8C: D7006A06
	v_cndmask_b32_e32 v1, s30, v6, vcc_lo                      // 000000545C90: 02020C1E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000545C94: BF870001
	v_add_co_ci_u32_e64 v7, null, s31, v7, vcc_lo              // 000000545C98: D5207C07 01AA0E1F
	global_load_b64 v[12:13], v[12:13], off                    // 000000545CA0: DC560000 0C7C000C
	.long 0xd7006a0e                                           // 000000545CA8: D7006A0E
	v_cndmask_b32_e32 v1, s20, v2, vcc_lo                      // 000000545CAC: 02020414
	global_load_b64 v[6:7], v[6:7], off                        // 000000545CB0: DC560000 067C0006
	v_add_co_ci_u32_e64 v15, null, s21, v3, vcc_lo             // 000000545CB8: D5207C0F 01AA0615
	s_clause 0x1                                               // 000000545CC0: BF850001
	global_load_b32 v16, v[14:15], off                         // 000000545CC4: DC520000 107C000E
	global_load_d16_b16 v14, v[14:15], off offset:4            // 000000545CCC: DC820004 0E7C000E
	s_waitcnt vmcnt(3)                                         // 000000545CD4: BF890FF7
	.long 0x7e1e390c                                           // 000000545CD8: 7E1E390C
	s_waitcnt vmcnt(2)                                         // 000000545CDC: BF890BF7
	v_and_b32_e32 v40, 0xffff0000, v6                          // 000000545CE0: 36500CFF FFFF0000
	v_lshlrev_b32_e32 v6, 16, v6                               // 000000545CE8: 300C0C90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000545CEC: BF870093
	v_lshlrev_b32_e32 v15, 16, v15                             // 000000545CF0: 301E1E90
	v_mul_f32_e32 v19, 0xbfb8aa3b, v15                         // 000000545CF4: 10261EFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000545CFC: BF870291
	v_exp_f32_e32 v19, v19                                     // 000000545D00: 7E264B13
	v_dual_add_f32 v19, 1.0, v19 :: v_dual_and_b32 v12, 0xffff0000, v12// 000000545D04: C92426F2 130C18FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000545D10: BF870111
	v_mul_f32_e32 v18, 0xbfb8aa3b, v12                         // 000000545D14: 102418FF BFB8AA3B
	v_div_scale_f32 v23, null, v19, v19, v15                   // 000000545D1C: D6FC7C17 043E2713
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000545D24: BF8701B2
	v_exp_f32_e32 v18, v18                                     // 000000545D28: 7E244B12
	v_lshlrev_b32_e32 v17, 16, v13                             // 000000545D2C: 30221A90
	v_div_scale_f32 v38, s7, v15, v19, v15                     // 000000545D30: D6FC0726 043E270F
	v_rcp_f32_e32 v27, v23                                     // 000000545D38: 7E365517
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000545D3C: BF870196
	v_add_f32_e32 v18, 1.0, v18                                // 000000545D40: 062424F2
	v_mul_f32_e32 v20, 0xbfb8aa3b, v17                         // 000000545D44: 102822FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000545D4C: BF870195
	v_fma_f32 v37, -v23, v27, 1.0                              // 000000545D50: D6130025 23CA3717
	v_div_scale_f32 v22, null, v18, v18, v12                   // 000000545D58: D6FC7C16 04322512
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000545D60: BF8701B3
	v_exp_f32_e32 v20, v20                                     // 000000545D64: 7E284B14
	v_and_b32_e32 v13, 0xffff0000, v13                         // 000000545D68: 361A1AFF FFFF0000
	v_div_scale_f32 v32, vcc_lo, v12, v18, v12                 // 000000545D70: D6FC6A20 0432250C
	v_rcp_f32_e32 v25, v22                                     // 000000545D78: 7E325516
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_2)   // 000000545D7C: BF870106
	v_dual_add_f32 v20, 1.0, v20 :: v_dual_mul_f32 v21, 0xbfb8aa3b, v13// 000000545D80: C90628F2 14141AFF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000545D8C: BF870115
	v_fma_f32 v33, -v22, v25, 1.0                              // 000000545D90: D6130021 23CA3316
	v_div_scale_f32 v24, null, v20, v20, v17                   // 000000545D98: D6FC7C18 04462914
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000545DA0: BF8701A3
	v_exp_f32_e32 v21, v21                                     // 000000545DA4: 7E2A4B15
	v_div_scale_f32 v34, s6, v17, v20, v17                     // 000000545DA8: D6FC0622 04462911
	v_fmac_f32_e32 v25, v33, v25                               // 000000545DB0: 56323321
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000545DB4: BF870313
	v_rcp_f32_e32 v29, v24                                     // 000000545DB8: 7E3A5518
	v_add_f32_e32 v21, 1.0, v21                                // 000000545DBC: 062A2AF2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000545DC0: BF870115
	v_fma_f32 v39, -v24, v29, 1.0                              // 000000545DC4: D6130027 23CA3B18
	v_div_scale_f32 v26, null, v21, v21, v13                   // 000000545DCC: D6FC7C1A 04362B15
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000545DD4: BF8701A2
	v_fmac_f32_e32 v29, v39, v29                               // 000000545DD8: 563A3B27
	v_mul_f32_e32 v39, v32, v25                                // 000000545DDC: 104E3320
	v_rcp_f32_e32 v30, v26                                     // 000000545DE0: 7E3C551A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000545DE4: BF870112
	v_mul_f32_e32 v41, v34, v29                                // 000000545DE8: 10523B22
	v_fma_f32 v42, -v22, v39, v32                              // 000000545DEC: D613002A 24824F16
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000545DF4: BF870112
	v_fma_f32 v45, -v24, v41, v34                              // 000000545DF8: D613002D 248A5318
	v_fmac_f32_e32 v39, v42, v25                               // 000000545E00: 564E332A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000545E04: BF870195
	v_fma_f32 v33, -v26, v30, 1.0                              // 000000545E08: D6130021 23CA3D1A
	v_fmac_f32_e32 v41, v45, v29                               // 000000545E10: 56523B2D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000545E14: BF870193
	v_fma_f32 v22, -v22, v39, v32                              // 000000545E18: D6130016 24824F16
	v_fmac_f32_e32 v30, v33, v30                               // 000000545E20: 563C3D21
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000545E24: BF870193
	v_fma_f32 v24, -v24, v41, v34                              // 000000545E28: D6130018 248A5318
	v_div_fmas_f32 v22, v22, v25, v39                          // 000000545E30: D6370016 049E3316
	s_mov_b32 vcc_lo, s7                                       // 000000545E38: BEEA0007
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000545E3C: BF870131
	v_div_fixup_f32 v12, v22, v18, v12                         // 000000545E40: D627000C 04322516
	v_fmac_f32_e32 v27, v37, v27                               // 000000545E48: 56363725
	v_div_scale_f32 v37, s8, v13, v21, v13                     // 000000545E4C: D6FC0825 04362B0D
	v_dual_mul_f32 v12, v12, v40 :: v_dual_mul_f32 v33, v38, v27// 000000545E54: C8C6510C 0C203726
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000545E5C: BF870112
	v_mul_f32_e32 v43, v37, v30                                // 000000545E60: 10563D25
	.long 0x7e38398c                                           // 000000545E64: 7E38398C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000545E68: BF870193
	v_fma_f32 v44, -v23, v33, v38                              // 000000545E6C: D613002C 249A4317
	v_fma_f32 v42, -v26, v43, v37                              // 000000545E74: D613002A 2496571A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000545E7C: BF870112
	v_fmac_f32_e32 v33, v44, v27                               // 000000545E80: 5642372C
	v_fmac_f32_e32 v43, v42, v30                               // 000000545E84: 56563D2A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000545E88: BF870112
	v_fma_f32 v23, -v23, v33, v38                              // 000000545E8C: D6130017 249A4317
	v_fma_f32 v22, -v26, v43, v37                              // 000000545E94: D6130016 2496571A
	s_delay_alu instid0(VALU_DEP_2)                            // 000000545E9C: BF870002
	v_div_fmas_f32 v23, v23, v27, v33                          // 000000545EA0: D6370017 04863717
	s_mov_b32 vcc_lo, s6                                       // 000000545EA8: BEEA0006
	s_mov_b32 s6, 0                                            // 000000545EAC: BE860080
	v_div_fmas_f32 v18, v24, v29, v41                          // 000000545EB0: D6370012 04A63B18
	s_mov_b32 vcc_lo, s8                                       // 000000545EB8: BEEA0008
	v_div_fixup_f32 v15, v23, v19, v15                         // 000000545EBC: D627000F 043E2717
	v_lshlrev_b32_e32 v19, 16, v7                              // 000000545EC4: 30260E90
	v_and_b32_e32 v7, 0xffff0000, v7                           // 000000545EC8: 360E0EFF FFFF0000
	v_div_fixup_f32 v17, v18, v20, v17                         // 000000545ED0: D6270011 04462912
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000545ED8: BF8701A4
	v_mul_f32_e32 v6, v15, v6                                  // 000000545EDC: 100C0D0F
	v_div_fmas_f32 v15, v22, v30, v43                          // 000000545EE0: D637000F 04AE3D16
	v_mul_f32_e32 v17, v17, v19                                // 000000545EE8: 10222711
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000545EEC: BF870193
	.long 0x7e3e3986                                           // 000000545EF0: 7E3E3986
	v_div_fixup_f32 v13, v15, v21, v13                         // 000000545EF4: D627000D 04362B0F
	v_and_b32_e32 v15, 1, v28                                  // 000000545EFC: 361E3881
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000545F00: BF870214
	v_bfe_u32 v18, v17, 16, 1                                  // 000000545F04: D6100012 02052111
	v_and_b32_e32 v19, 1, v31                                  // 000000545F0C: 36263E81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000545F10: BF870214
	v_mul_f32_e32 v7, v13, v7                                  // 000000545F14: 100E0F0D
	v_add3_u32 v12, v12, v15, 0x7fff                           // 000000545F18: D655000C 03FE1F0C 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000545F24: BF870214
	v_add3_u32 v13, v17, v18, 0x7fff                           // 000000545F28: D655000D 03FE2511 00007FFF
	v_add3_u32 v6, v6, v19, 0x7fff                             // 000000545F34: D6550006 03FE2706 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000545F40: BF870214
	v_bfe_u32 v15, v7, 16, 1                                   // 000000545F44: D610000F 02052107
	v_and_b32_e32 v12, 0xffff0000, v12                         // 000000545F4C: 361818FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000545F54: BF870214
	v_and_b32_e32 v17, 0xffff0000, v13                         // 000000545F58: 36221AFF FFFF0000
	v_and_b32_e32 v6, 0xffff0000, v6                           // 000000545F60: 360C0CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4)                            // 000000545F68: BF870004
	v_add3_u32 v7, v7, v15, 0x7fff                             // 000000545F6C: D6550007 03FE1F07 00007FFF
	s_waitcnt vmcnt(1)                                         // 000000545F78: BF8907F7
	v_fma_mix_f32 v13, v16, v12, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000545F7C: CC20080D 8A021910
	s_waitcnt vmcnt(0)                                         // 000000545F84: BF8903F7
	v_fma_mix_f32 v12, v14, v17, neg(0) op_sel_hi:[1,0,0]      // 000000545F88: CC20000C 8A02230E
	v_fma_mix_f32 v15, v16, v6, neg(0) op_sel_hi:[1,0,0]       // 000000545F90: CC20000F 8A020D10
	v_and_b32_e32 v14, 0xffff0000, v7                          // 000000545F98: 361C0EFF FFFF0000
	s_and_not1_b32 vcc_lo, exec_lo, s6                         // 000000545FA0: 916A067E
	s_cbranch_vccnz 65125                                      // 000000545FA4: BFA4FE65 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x13c>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000545FA8: BF870093
	.long 0xd73c0004                                           // 000000545FAC: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 000000545FB0: 02020881
	.long 0xd7006a04                                           // 000000545FB4: D7006A04
	v_cndmask_b32_e32 v1, s14, v4, vcc_lo                      // 000000545FB8: 0202080E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000545FBC: BF870111
	v_add_co_ci_u32_e64 v5, null, s15, v5, vcc_lo              // 000000545FC0: D5207C05 01AA0A0F
	.long 0xd7006a04                                           // 000000545FC8: D7006A04
	v_cndmask_b32_e32 v1, v4, v2, vcc_lo                       // 000000545FCC: 02020504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000545FD0: BF8700A1
	v_add_co_ci_u32_e64 v5, null, v5, v3, vcc_lo               // 000000545FD4: D5207C05 01AA0705
	.long 0xd7006a06                                           // 000000545FDC: D7006A06
	v_cndmask_b32_e32 v1, s20, v2, vcc_lo                      // 000000545FE0: 02020414
	v_add_co_ci_u32_e64 v7, null, s21, v3, vcc_lo              // 000000545FE4: D5207C07 01AA0615
	global_load_b64 v[4:5], v[4:5], off                        // 000000545FEC: DC560000 047C0004
	s_clause 0x1                                               // 000000545FF4: BF850001
	global_load_b32 v14, v[6:7], off                           // 000000545FF8: DC520000 0E7C0006
	global_load_d16_b16 v6, v[6:7], off offset:4               // 000000546000: DC820004 067C0006
	s_waitcnt vmcnt(2)                                         // 000000546008: BF890BF7
	.long 0x7e0e3904                                           // 00000054600C: 7E0E3904
	v_and_b32_e32 v4, 0xffff0000, v4                           // 000000546010: 360808FF FFFF0000
	v_lshlrev_b32_e32 v12, 16, v5                              // 000000546018: 30180A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000054601C: BF8701A3
	v_lshlrev_b32_e32 v7, 16, v7                               // 000000546020: 300E0E90
	s_waitcnt vmcnt(1)                                         // 000000546024: BF8907F7
	v_fma_mix_f32 v13, v14, v4, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000546028: CC20080D 8A02090E
	s_waitcnt vmcnt(0)                                         // 000000546030: BF8903F7
	v_fma_mix_f32 v12, v6, v12, neg(0) op_sel_hi:[1,0,0]       // 000000546034: CC20000C 8A021906
	v_fma_mix_f32 v15, v14, v7, neg(0) op_sel_hi:[1,0,0]       // 00000054603C: CC20000F 8A020F0E
	v_and_b32_e32 v14, 0xffff0000, v5                          // 000000546044: 361C0AFF FFFF0000
	s_branch 65083                                             // 00000054604C: BFA0FE3B <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x13c>
	s_or_b32 exec_lo, exec_lo, s19                             // 000000546050: 8C7E137E
	s_ashr_i32 s0, s9, 31                                      // 000000546054: 86009F09
	s_lshr_b32 s3, s11, 28                                     // 000000546058: 85039C0B
	s_lshr_b32 s0, s0, 29                                      // 00000054605C: 85009D00
	s_lshl_b32 s1, s34, 3                                      // 000000546060: 84018322
	s_add_i32 s0, s0, s9                                       // 000000546064: 81000900
	v_dual_mov_b32 v40, 0 :: v_dual_mov_b32 v103, 0            // 000000546068: CA100080 28660080
	s_add_i32 s0, s0, 7                                        // 000000546070: 81008700
	v_dual_mov_b32 v102, 0 :: v_dual_mov_b32 v105, 0           // 000000546074: CA100080 66680080
	s_ashr_i32 s0, s0, 3                                       // 00000054607C: 86008300
	v_dual_mov_b32 v104, 0 :: v_dual_mov_b32 v107, 0           // 000000546080: CA100080 686A0080
	.long 0xd72c0001                                           // 000000546088: D72C0001
	v_cndmask_b32_e32 v1, s0, v35, vcc_lo                      // 00000054608C: 02024600
	v_dual_mov_b32 v106, 0 :: v_dual_mov_b32 v109, 0           // 000000546090: CA100080 6A6C0080
	v_mov_b32_e32 v108, 0                                      // 000000546098: 7ED80280
	s_waitcnt lgkmcnt(0)                                       // 00000054609C: BF89FC07
	s_barrier                                                  // 0000005460A0: BFBD0000
	buffer_gl0_inv                                             // 0000005460A4: E0AC0000 00000000
	v_add_nc_u32_e32 v2, s0, v1                                // 0000005460AC: 4A040200
	s_add_i32 s0, s17, s3                                      // 0000005460B0: 81000311
	s_ashr_i32 s3, s1, 31                                      // 0000005460B4: 86039F01
	s_ashr_i32 s0, s0, 4                                       // 0000005460B8: 86008400
	s_delay_alu instid0(VALU_DEP_1)                            // 0000005460BC: BF870001
	v_min_i32_e32 v101, s9, v2                                 // 0000005460C0: 22CA0409
	s_mul_i32 s4, s0, s2                                       // 0000005460C4: 96040200
	s_mul_hi_i32 s5, s0, s2                                    // 0000005460C8: 97050200
	s_add_u32 s0, s4, s1                                       // 0000005460CC: 80000104
	s_addc_u32 s1, s5, s3                                      // 0000005460D0: 82010305
	v_cmp_lt_i32_e32 vcc_lo, v1, v101                          // 0000005460D4: 7C82CB01
	s_lshl_b64 s[4:5], s[0:1], 10                              // 0000005460D8: 84848A00
	s_and_saveexec_b32 s1, vcc_lo                              // 0000005460DC: BE81206A
	s_cbranch_execz 34                                         // 0000005460E0: BFA50022 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x96c>
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000005460E4: 3404029F
	s_add_u32 s0, s12, s4                                      // 0000005460E8: 8000040C
	v_lshlrev_b32_e32 v4, 2, v36                               // 0000005460EC: 30084882
	s_addc_u32 s3, s13, s5                                     // 0000005460F0: 8203050D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005460F4: BF870092
	.long 0xd73c0002                                           // 0000005460F8: D73C0002
	v_cndmask_b32_e32 v1, 10, v1, vcc_lo                       // 0000005460FC: 0202028A
	.long 0xd7000002                                           // 000000546100: D7000002
	v_cndmask_b32_e32 v1, s0, v2, vcc_lo                       // 000000546104: 02020400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000546108: BF870111
	v_add_co_ci_u32_e64 v3, null, s3, v3, s0                   // 00000054610C: D5207C03 00020603
	.long 0xd7000002                                           // 000000546114: D7000002
	v_cndmask_b32_e32 v1, v2, v4, vcc_lo                       // 000000546118: 02020902
	s_delay_alu instid0(VALU_DEP_1)                            // 00000054611C: BF870001
	v_add_co_ci_u32_e64 v3, null, 0, v3, s0                    // 000000546120: D5207C03 00020680
	s_clause 0x7                                               // 000000546128: BF850007
	global_load_b32 v102, v[2:3], off                          // 00000054612C: DC520000 667C0002
	global_load_b32 v103, v[2:3], off offset:128               // 000000546134: DC520080 677C0002
	global_load_b32 v104, v[2:3], off offset:256               // 00000054613C: DC520100 687C0002
	global_load_b32 v105, v[2:3], off offset:384               // 000000546144: DC520180 697C0002
	global_load_b32 v106, v[2:3], off offset:512               // 00000054614C: DC520200 6A7C0002
	global_load_b32 v107, v[2:3], off offset:640               // 000000546154: DC520280 6B7C0002
	global_load_b32 v108, v[2:3], off offset:768               // 00000054615C: DC520300 6C7C0002
	global_load_b32 v109, v[2:3], off offset:896               // 000000546164: DC520380 6D7C0002
	s_or_b32 exec_lo, exec_lo, s1                              // 00000054616C: 8C7E017E
	v_dual_mov_b32 v100, 0 :: v_dual_mov_b32 v99, 0            // 000000546170: CA100080 64620080
	v_dual_mov_b32 v98, 0 :: v_dual_mov_b32 v97, 0             // 000000546178: CA100080 62600080
	v_dual_mov_b32 v96, 0 :: v_dual_mov_b32 v95, 0             // 000000546180: CA100080 605E0080
	v_dual_mov_b32 v94, 0 :: v_dual_mov_b32 v93, 0             // 000000546188: CA100080 5E5C0080
	v_dual_mov_b32 v92, 0 :: v_dual_mov_b32 v91, 0             // 000000546190: CA100080 5C5A0080
	v_dual_mov_b32 v90, 0 :: v_dual_mov_b32 v89, 0             // 000000546198: CA100080 5A580080
	v_dual_mov_b32 v88, 0 :: v_dual_mov_b32 v87, 0             // 0000005461A0: CA100080 58560080
	v_dual_mov_b32 v86, 0 :: v_dual_mov_b32 v85, 0             // 0000005461A8: CA100080 56540080
	v_dual_mov_b32 v84, 0 :: v_dual_mov_b32 v83, 0             // 0000005461B0: CA100080 54520080
	v_dual_mov_b32 v82, 0 :: v_dual_mov_b32 v81, 0             // 0000005461B8: CA100080 52500080
	v_dual_mov_b32 v80, 0 :: v_dual_mov_b32 v79, 0             // 0000005461C0: CA100080 504E0080
	v_dual_mov_b32 v78, 0 :: v_dual_mov_b32 v77, 0             // 0000005461C8: CA100080 4E4C0080
	v_dual_mov_b32 v76, 0 :: v_dual_mov_b32 v75, 0             // 0000005461D0: CA100080 4C4A0080
	v_dual_mov_b32 v74, 0 :: v_dual_mov_b32 v73, 0             // 0000005461D8: CA100080 4A480080
	v_dual_mov_b32 v72, 0 :: v_dual_mov_b32 v71, 0             // 0000005461E0: CA100080 48460080
	v_dual_mov_b32 v70, 0 :: v_dual_mov_b32 v69, 0             // 0000005461E8: CA100080 46440080
	v_dual_mov_b32 v68, 0 :: v_dual_mov_b32 v67, 0             // 0000005461F0: CA100080 44420080
	v_dual_mov_b32 v66, 0 :: v_dual_mov_b32 v65, 0             // 0000005461F8: CA100080 42400080
	v_dual_mov_b32 v64, 0 :: v_dual_mov_b32 v63, 0             // 000000546200: CA100080 403E0080
	v_dual_mov_b32 v62, 0 :: v_dual_mov_b32 v61, 0             // 000000546208: CA100080 3E3C0080
	v_dual_mov_b32 v60, 0 :: v_dual_mov_b32 v59, 0             // 000000546210: CA100080 3C3A0080
	v_dual_mov_b32 v58, 0 :: v_dual_mov_b32 v57, 0             // 000000546218: CA100080 3A380080
	v_dual_mov_b32 v56, 0 :: v_dual_mov_b32 v55, 0             // 000000546220: CA100080 38360080
	v_dual_mov_b32 v54, 0 :: v_dual_mov_b32 v53, 0             // 000000546228: CA100080 36340080
	v_dual_mov_b32 v52, 0 :: v_dual_mov_b32 v51, 0             // 000000546230: CA100080 34320080
	v_dual_mov_b32 v50, 0 :: v_dual_mov_b32 v49, 0             // 000000546238: CA100080 32300080
	v_dual_mov_b32 v48, 0 :: v_dual_mov_b32 v47, 0             // 000000546240: CA100080 302E0080
	v_dual_mov_b32 v46, 0 :: v_dual_mov_b32 v45, 0             // 000000546248: CA100080 2E2C0080
	v_dual_mov_b32 v44, 0 :: v_dual_mov_b32 v43, 0             // 000000546250: CA100080 2C2A0080
	v_dual_mov_b32 v42, 0 :: v_dual_mov_b32 v41, 0             // 000000546258: CA100080 2A280080
	v_dual_mov_b32 v38, 0 :: v_dual_mov_b32 v39, 0             // 000000546260: CA100080 26260080
	v_mov_b32_e32 v37, 0                                       // 000000546268: 7E4A0280
	s_ashr_i32 s3, s2, 31                                      // 00000054626C: 86039F02
	s_and_saveexec_b32 s1, vcc_lo                              // 000000546270: BE81206A
	s_cbranch_execz 1312                                       // 000000546274: BFA50520 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1ef8>
	v_dual_mov_b32 v37, 0 :: v_dual_lshlrev_b32 v4, 5, v36     // 000000546278: CA220080 25044885
	v_cmp_ne_u32_e32 vcc_lo, 0, v36                            // 000000546280: 7C9A4880
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000546284: 3404029F
	v_dual_mov_b32 v39, 0 :: v_dual_and_b32 v8, 16, v0         // 000000546288: CA240080 27080090
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000546290: BF8701A4
	v_add_nc_u32_e32 v5, 0x3f0, v4                             // 000000546294: 4A0A08FF 000003F0
	v_dual_mov_b32 v38, 0 :: v_dual_lshlrev_b32 v7, 2, v36     // 00000054629C: CA220080 26064882
	v_lshl_or_b32 v110, v1, 5, v8                              // 0000005462A4: D656006E 04210B01
	v_mul_u32_u24_e32 v6, 0x420, v35                           // 0000005462AC: 160C46FF 00000420
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000005462B4: BF870214
	v_lshrrev_b32_e32 v3, 5, v5                                // 0000005462B8: 32060A85
	v_mad_u32_u24 v9, 0x420, v35, v7                           // 0000005462BC: D60B0009 041E46FF 00000420
	v_sub_nc_u32_e32 v112, 0, v101                             // 0000005462C8: 4CE0CA80
	v_dual_mov_b32 v48, 0 :: v_dual_add_nc_u32 v113, 1, v1     // 0000005462CC: CA200080 30700281
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000005462D4: BF870244
	v_subrev_nc_u32_e32 v10, 32, v3                            // 0000005462D8: 4E1406A0
	.long 0xd73c0002                                           // 0000005462DC: D73C0002
	v_cndmask_b32_e32 v1, 10, v1, vcc_lo                       // 0000005462E0: 0202028A
	v_dual_mov_b32 v43, 0 :: v_dual_add_nc_u32 v114, 0xa000, v9// 0000005462E4: CA200080 2B7212FF 0000A000
	v_mov_b32_e32 v42, 0                                       // 0000005462F0: 7E540280
	v_dual_cndmask_b32 v8, 31, v10 :: v_dual_and_b32 v5, 0x7e0, v5// 0000005462F4: CA64149F 08040AFF 000007E0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000546300: BF870094
	.long 0xd7006a02                                           // 000000546304: D7006A02
	v_cndmask_b32_e32 v1, s4, v2, vcc_lo                       // 000000546308: 02020404
	v_add_co_ci_u32_e64 v3, null, s5, v3, vcc_lo               // 00000054630C: D5207C03 01AA0605
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000546314: BF870213
	v_sub_nc_u32_e32 v4, v5, v4                                // 000000546318: 4C080905
	v_dual_mov_b32 v44, 0 :: v_dual_add_nc_u32 v5, 1, v8       // 00000054631C: CA200080 2C041081
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000546324: BF870094
	.long 0xd7006a02                                           // 000000546328: D7006A02
	v_cndmask_b32_e32 v1, v2, v7, vcc_lo                       // 00000054632C: 02020F02
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 000000546330: D5207C03 01AA0680
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000546338: BF870214
	v_dual_mov_b32 v46, 0 :: v_dual_add_nc_u32 v111, 0xfffffc30, v4// 00000054633C: CA200080 2E6E08FF FFFFFC30
	v_dual_mov_b32 v41, 0 :: v_dual_and_b32 v4, 31, v5         // 000000546348: CA240080 29040A9F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000546350: BF870094
	.long 0xd7006a02                                           // 000000546354: D7006A02
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 000000546358: 0202040C
	v_add_co_ci_u32_e64 v3, null, s13, v3, vcc_lo              // 00000054635C: D5207C03 01AA060D
	v_lshl_add_u32 v5, v8, 2, v6                               // 000000546364: D6460005 04190508
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000054636C: BF870214
	v_lshl_add_u32 v4, v4, 2, v6                               // 000000546370: D6460004 04190504
	.long 0xd7006a21                                           // 000000546378: D7006A21
	v_cndmask_b32_e32 v1, 0x400, v2, vcc_lo                    // 00000054637C: 020204FF 00000400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000546384: BF870211
	v_add_co_ci_u32_e64 v34, null, 0, v3, vcc_lo               // 000000546388: D5207C22 01AA0680
	v_dual_mov_b32 v50, 0 :: v_dual_add_nc_u32 v115, 0xa000, v5// 000000546390: CA200080 32720AFF 0000A000
	s_delay_alu instid0(VALU_DEP_4)                            // 00000054639C: BF870004
	v_dual_mov_b32 v45, 0 :: v_dual_add_nc_u32 v116, 0xa000, v4// 0000005463A0: CA200080 2D7408FF 0000A000
	v_dual_mov_b32 v47, 0 :: v_dual_mov_b32 v52, 0             // 0000005463AC: CA100080 2F340080
	v_dual_mov_b32 v49, 0 :: v_dual_mov_b32 v54, 0             // 0000005463B4: CA100080 31360080
	v_dual_mov_b32 v51, 0 :: v_dual_mov_b32 v56, 0             // 0000005463BC: CA100080 33380080
	v_dual_mov_b32 v53, 0 :: v_dual_mov_b32 v58, 0             // 0000005463C4: CA100080 353A0080
	v_dual_mov_b32 v55, 0 :: v_dual_mov_b32 v60, 0             // 0000005463CC: CA100080 373C0080
	v_dual_mov_b32 v57, 0 :: v_dual_mov_b32 v62, 0             // 0000005463D4: CA100080 393E0080
	v_dual_mov_b32 v59, 0 :: v_dual_mov_b32 v64, 0             // 0000005463DC: CA100080 3B400080
	v_dual_mov_b32 v61, 0 :: v_dual_mov_b32 v66, 0             // 0000005463E4: CA100080 3D420080
	v_dual_mov_b32 v63, 0 :: v_dual_mov_b32 v68, 0             // 0000005463EC: CA100080 3F440080
	v_dual_mov_b32 v65, 0 :: v_dual_mov_b32 v70, 0             // 0000005463F4: CA100080 41460080
	v_dual_mov_b32 v67, 0 :: v_dual_mov_b32 v72, 0             // 0000005463FC: CA100080 43480080
	v_dual_mov_b32 v69, 0 :: v_dual_mov_b32 v74, 0             // 000000546404: CA100080 454A0080
	v_dual_mov_b32 v71, 0 :: v_dual_mov_b32 v76, 0             // 00000054640C: CA100080 474C0080
	v_dual_mov_b32 v73, 0 :: v_dual_mov_b32 v78, 0             // 000000546414: CA100080 494E0080
	v_dual_mov_b32 v75, 0 :: v_dual_mov_b32 v80, 0             // 00000054641C: CA100080 4B500080
	v_dual_mov_b32 v77, 0 :: v_dual_mov_b32 v82, 0             // 000000546424: CA100080 4D520080
	v_dual_mov_b32 v79, 0 :: v_dual_mov_b32 v84, 0             // 00000054642C: CA100080 4F540080
	v_dual_mov_b32 v81, 0 :: v_dual_mov_b32 v86, 0             // 000000546434: CA100080 51560080
	v_dual_mov_b32 v83, 0 :: v_dual_mov_b32 v88, 0             // 00000054643C: CA100080 53580080
	v_dual_mov_b32 v85, 0 :: v_dual_mov_b32 v90, 0             // 000000546444: CA100080 555A0080
	v_dual_mov_b32 v87, 0 :: v_dual_mov_b32 v92, 0             // 00000054644C: CA100080 575C0080
	v_dual_mov_b32 v89, 0 :: v_dual_mov_b32 v94, 0             // 000000546454: CA100080 595E0080
	v_dual_mov_b32 v91, 0 :: v_dual_mov_b32 v96, 0             // 00000054645C: CA100080 5B600080
	v_dual_mov_b32 v93, 0 :: v_dual_mov_b32 v98, 0             // 000000546464: CA100080 5D620080
	v_dual_mov_b32 v95, 0 :: v_dual_mov_b32 v100, 0            // 00000054646C: CA100080 5F640080
	v_dual_mov_b32 v97, 0 :: v_dual_mov_b32 v40, 0             // 000000546474: CA100080 61280080
	v_mov_b32_e32 v99, 0                                       // 00000054647C: 7EC60280
	s_mov_b32 s4, 0                                            // 000000546480: BE840080
	s_movk_i32 s5, 0x1eee                                      // 000000546484: B0051EEE
	s_branch 1144                                              // 000000546488: BFA00478 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1e6c>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000054648C: 8C7E007E
	ds_load_2addr_b32 v[117:118], v116 offset1:32              // 000000546490: D8DC2000 75000074
	ds_load_2addr_b32 v[122:123], v114 offset1:32              // 000000546498: D8DC2000 7A000072
	ds_load_2addr_b32 v[120:121], v115 offset1:32              // 0000005464A0: D8DC2000 78000073
	ds_load_b128 v[21:24], v110 offset:5120                    // 0000005464A8: DBFC1400 1500006E
	ds_load_b128 v[25:28], v110 offset:10240                   // 0000005464B0: DBFC2800 1900006E
	ds_load_b128 v[17:20], v110 offset:15360                   // 0000005464B8: DBFC3C00 1100006E
	ds_load_b128 v[9:12], v110 offset:20480                    // 0000005464C0: DBFC5000 0900006E
	ds_load_b128 v[1:4], v110 offset:25600                     // 0000005464C8: DBFC6400 0100006E
	ds_load_b128 v[5:8], v110 offset:30720                     // 0000005464D0: DBFC7800 0500006E
	ds_load_b128 v[29:32], v110                                // 0000005464D8: DBFC0000 1D00006E
	ds_load_b128 v[13:16], v110 offset:35840                   // 0000005464E0: DBFC8C00 0D00006E
	.long 0xd7000021                                           // 0000005464E8: D7000021
	v_cndmask_b32_e32 v1, 0x400, v33, vcc_lo                   // 0000005464EC: 020242FF 00000400
	s_delay_alu instid0(VALU_DEP_1)                            // 0000005464F4: BF870001
	v_add_co_ci_u32_e64 v34, null, 0, v34, s0                  // 0000005464F8: D5207C22 00024480
	s_waitcnt lgkmcnt(10)                                      // 000000546500: BF89FCA7
	v_dual_mov_b32 v119, v117 :: v_dual_add_nc_u32 v110, 32, v110// 000000546504: CA200175 776EDCA0
	s_waitcnt lgkmcnt(9)                                       // 00000054650C: BF89FC97
	v_bfe_u32 v117, v122, 12, 16                               // 000000546510: D6100075 0241197A
	v_bfe_u32 v126, v122, 8, 16                                // 000000546518: D610007E 0241117A
	s_waitcnt lgkmcnt(8)                                       // 000000546520: BF89FC87
	.long 0xd73d007c                                           // 000000546524: D73D007C
	v_cndmask_b32_e32 v1, v111, v119, vcc_lo                   // 000000546528: 0202EF6F
	v_mov_b32_e32 v119, v121                                   // 00000054652C: 7EEE0379
	.long 0xd72c0079                                           // 000000546530: D72C0079
	v_cndmask_b32_e32 v1, 0x83dcd12d, v117, vcc_lo             // 000000546534: 0202EAFF 83DCD12D
	.long 0xd72c007d                                           // 00000054653C: D72C007D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v126, vcc_lo             // 000000546540: 0202FCFF 83DCD12D
	v_bfe_u32 v120, v122, 4, 16                                // 000000546548: D6100078 0241097A
	v_and_b32_e32 v122, 0xffff, v122                           // 000000546550: 36F4F4FF 0000FFFF
	v_bfe_u32 v117, v124, 12, 16                               // 000000546558: D6100075 0241197C
	v_bfe_u32 v126, v124, 8, 16                                // 000000546560: D610007E 0241117C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000546568: BF870214
	.long 0xd72c0078                                           // 00000054656C: D72C0078
	v_cndmask_b32_e32 v1, 0x83dcd12d, v120, vcc_lo             // 000000546570: 0202F0FF 83DCD12D
	.long 0xd72c007a                                           // 000000546578: D72C007A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v122, vcc_lo             // 00000054657C: 0202F4FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000546584: BF870004
	.long 0xd72c0080                                           // 000000546588: D72C0080
	v_cndmask_b32_e32 v1, 0x83dcd12d, v117, vcc_lo             // 00000054658C: 0202EAFF 83DCD12D
	.long 0xd73d0075                                           // 000000546594: D73D0075
	v_cndmask_b32_e32 v1, v111, v118, vcc_lo                   // 000000546598: 0202ED6F
	.long 0xd72c0077                                           // 00000054659C: D72C0077
	v_cndmask_b32_e32 v1, 0x83dcd12d, v126, vcc_lo             // 0000005465A0: 0202FCFF 83DCD12D
	v_bfe_u32 v118, v124, 4, 16                                // 0000005465A8: D6100076 0241097C
	v_sad_u8 v121, v121, 0, 0x6400                             // 0000005465B0: D6220079 03FD0179 00006400
	v_sad_u8 v125, v125, 0, 0x6400                             // 0000005465BC: D622007D 03FD017D 00006400
	v_sad_u8 v120, v120, 0, 0x6400                             // 0000005465C8: D6220078 03FD0178 00006400
	v_sad_u8 v122, v122, 0, 0x6400                             // 0000005465D4: D622007A 03FD017A 00006400
	v_sad_u8 v126, v128, 0, 0x6400                             // 0000005465E0: D622007E 03FD0180 00006400
	.long 0xd72c0076                                           // 0000005465EC: D72C0076
	v_cndmask_b32_e32 v1, 0x83dcd12d, v118, vcc_lo             // 0000005465F0: 0202ECFF 83DCD12D
	v_sad_u8 v119, v119, 0, 0x6400                             // 0000005465F8: D6220077 03FD0177 00006400
	v_bfe_u32 v128, v123, 4, 16                                // 000000546604: D6100080 0241097B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000054660C: BF870214
	v_and_b32_e32 v126, 0xffff, v126                           // 000000546610: 36FCFCFF 0000FFFF
	v_sad_u8 v118, v118, 0, 0x6400                             // 000000546618: D6220076 03FD0176 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000546624: BF870122
	v_lshl_or_b32 v119, v119, 16, v126                         // 000000546628: D6560077 05F92177
	v_bfe_u32 v126, v117, 12, 16                               // 000000546630: D610007E 02411975
	v_pk_fma_f16 v119, v119, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000546638: CC0E0077 0BFC0B77 0000C931
	v_and_b32_e32 v127, 0xffff, v124                           // 000000546644: 36FEF8FF 0000FFFF
	s_waitcnt lgkmcnt(1)                                       // 00000054664C: BF89FC17
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000546650: BF8701A2
	v_dual_dot2acc_f32_f16 v37, v119, v29 :: v_dual_lshlrev_b32 v122, 16, v122// 000000546654: CB223B77 257AF490
	v_dot2acc_f32_f16 v38, v119, v25                           // 00000054665C: 044C3377
	.long 0xd72c007c                                           // 000000546660: D72C007C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v127, vcc_lo             // 000000546664: 0202FEFF 83DCD12D
	v_and_b32_e32 v121, 0xffff, v121                           // 00000054666C: 36F2F2FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000546674: BF870234
	v_and_or_b32 v120, 0xffff, v120, v122                      // 000000546678: D6570078 05EAF0FF 0000FFFF
	v_dot2acc_f32_f16 v39, v119, v21                           // 000000546684: 044E2B77
	v_bfe_u32 v127, v123, 8, 16                                // 000000546688: D610007F 0241117B
	v_lshl_or_b32 v121, v125, 16, v121                         // 000000546690: D6560079 05E5217D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000546698: BF870224
	v_pk_fma_f16 v125, v120, s5, 0xc931 op_sel_hi:[1,0,0]      // 00000054669C: CC0E007D 0BFC0B78 0000C931
	v_sad_u8 v124, v124, 0, 0x6400                             // 0000005466A8: D622007C 03FD017C 00006400
	.long 0xd72c007f                                           // 0000005466B4: D72C007F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v127, vcc_lo             // 0000005466B8: 0202FEFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005466C0: BF870092
	v_lshlrev_b32_e32 v124, 16, v124                           // 0000005466C4: 30F8F890
	v_and_or_b32 v118, 0xffff, v118, v124                      // 0000005466C8: D6570076 05F2ECFF 0000FFFF
	v_pk_fma_f16 v124, v121, s5, 0xc931 op_sel_hi:[1,0,0]      // 0000005466D4: CC0E007C 0BFC0B79 0000C931
	v_bfe_u32 v121, v117, 8, 16                                // 0000005466E0: D6100079 02411175
	s_delay_alu instid0(VALU_DEP_3)                            // 0000005466E8: BF870003
	v_pk_fma_f16 v120, v118, s5, 0xc931 op_sel_hi:[1,0,0]      // 0000005466EC: CC0E0078 0BFC0B76 0000C931
	.long 0xd72c0076                                           // 0000005466F8: D72C0076
	v_cndmask_b32_e32 v1, 0x83dcd12d, v126, vcc_lo             // 0000005466FC: 0202FCFF 83DCD12D
	v_dot2acc_f32_f16 v42, v119, v9                            // 000000546704: 04541377
	v_and_b32_e32 v122, 0xffff, v117                           // 000000546708: 36F4EAFF 0000FFFF
	v_bfe_u32 v117, v117, 4, 16                                // 000000546710: D6100075 02410975
	v_dot2acc_f32_f16 v39, v120, v22                           // 000000546718: 044E2D78
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000054671C: BF870234
	v_dual_dot2acc_f32_f16 v41, v119, v17 :: v_dual_dot2acc_f32_f16 v42, v120, v10// 000000546720: CB182377 292A1578
	v_dot2acc_f32_f16 v37, v120, v30                           // 000000546728: 044A3D78
	v_sad_u8 v118, v118, 0, 0x6400                             // 00000054672C: D6220076 03FD0176 00006400
	v_dot2acc_f32_f16 v39, v124, v23                           // 000000546738: 044E2F7C
	.long 0xd72c007a                                           // 00000054673C: D72C007A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v122, vcc_lo             // 000000546740: 0202F4FF 83DCD12D
	v_bfe_u32 v126, v123, 12, 16                               // 000000546748: D610007E 0241197B
	.long 0xd72c0079                                           // 000000546750: D72C0079
	v_cndmask_b32_e32 v1, 0x83dcd12d, v121, vcc_lo             // 000000546754: 0202F2FF 83DCD12D
	v_dual_dot2acc_f32_f16 v44, v119, v5 :: v_dual_dot2acc_f32_f16 v41, v120, v18// 00000054675C: CB180B77 2C282578
	v_dual_dot2acc_f32_f16 v43, v119, v1 :: v_dual_dot2acc_f32_f16 v38, v120, v26// 000000546764: CB180377 2B263578
	v_and_b32_e32 v118, 0xffff, v118                           // 00000054676C: 36ECECFF 0000FFFF
	v_dual_dot2acc_f32_f16 v42, v124, v11 :: v_dual_dot2acc_f32_f16 v39, v125, v24// 000000546774: CB18177C 2A26317D
	v_dot2acc_f32_f16 v37, v124, v31                           // 00000054677C: 044A3F7C
	.long 0xd72c0075                                           // 000000546780: D72C0075
	v_cndmask_b32_e32 v1, 0x83dcd12d, v117, vcc_lo             // 000000546784: 0202EAFF 83DCD12D
	.long 0xd72c007e                                           // 00000054678C: D72C007E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v126, vcc_lo             // 000000546790: 0202FCFF 83DCD12D
	v_dot2acc_f32_f16 v44, v120, v6                            // 000000546798: 04580D78
	v_dot2acc_f32_f16 v42, v125, v12                           // 00000054679C: 0454197D
	v_dual_dot2acc_f32_f16 v38, v124, v27 :: v_dual_dot2acc_f32_f16 v37, v125, v32// 0000005467A0: CB18377C 2624417D
	v_dot2acc_f32_f16 v43, v120, v2                            // 0000005467A8: 04560578
	v_sad_u8 v122, v122, 0, 0x6400                             // 0000005467AC: D622007A 03FD017A 00006400
	v_dot2acc_f32_f16 v41, v124, v19                           // 0000005467B8: 0452277C
	v_sad_u8 v121, v121, 0, 0x6400                             // 0000005467BC: D6220079 03FD0179 00006400
	v_dot2acc_f32_f16 v38, v125, v28                           // 0000005467C8: 044C397D
	v_sad_u8 v117, v117, 0, 0x6400                             // 0000005467CC: D6220075 03FD0175 00006400
	v_lshlrev_b32_e32 v122, 16, v122                           // 0000005467D8: 30F4F490
	v_dual_dot2acc_f32_f16 v44, v124, v7 :: v_dual_dot2acc_f32_f16 v41, v125, v20// 0000005467DC: CB180F7C 2C28297D
	v_dot2acc_f32_f16 v43, v124, v3                            // 0000005467E4: 0456077C
	v_sad_u8 v126, v126, 0, 0x6400                             // 0000005467E8: D622007E 03FD017E 00006400
	v_lshl_or_b32 v118, v121, 16, v118                         // 0000005467F4: D6560076 05D92179
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000005467FC: BF870224
	v_dot2acc_f32_f16 v44, v125, v8                            // 000000546800: 0458117D
	v_and_or_b32 v117, 0xffff, v117, v122                      // 000000546804: D6570075 05EAEAFF 0000FFFF
	v_dual_dot2acc_f32_f16 v43, v125, v4 :: v_dual_and_b32 v122, 0xffff, v126// 000000546810: CB24097D 2B7AFCFF 0000FFFF
	v_sad_u8 v126, v127, 0, 0x6400                             // 00000054681C: D622007E 03FD017F 00006400
	v_pk_fma_f16 v127, v118, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000546828: CC0E007F 0BFC0B76 0000C931
	v_and_b32_e32 v123, 0xffff, v123                           // 000000546834: 36F6F6FF 0000FFFF
	.long 0xd72c0079                                           // 00000054683C: D72C0079
	v_cndmask_b32_e32 v1, 0x83dcd12d, v128, vcc_lo             // 000000546840: 020300FF 83DCD12D
	v_pk_fma_f16 v128, v117, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000546848: CC0E0080 0BFC0B75 0000C931
	v_lshl_or_b32 v122, v126, 16, v122                         // 000000546854: D656007A 05E9217E
	v_dot2acc_f32_f16 v46, v127, v29                           // 00000054685C: 045C3B7F
	.long 0xd72c007b                                           // 000000546860: D72C007B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v123, vcc_lo             // 000000546864: 0202F6FF 83DCD12D
	s_waitcnt lgkmcnt(0)                                       // 00000054686C: BF89FC07
	v_dot2acc_f32_f16 v45, v119, v13                           // 000000546870: 045A1B77
	ds_load_2addr_b32 v[117:118], v116 offset0:64 offset1:96   // 000000546874: D8DC6040 75000074
	v_pk_fma_f16 v126, v122, s5, 0xc931 op_sel_hi:[1,0,0]      // 00000054687C: CC0E007E 0BFC0B7A 0000C931
	v_sad_u8 v121, v121, 0, 0x6400                             // 000000546888: D6220079 03FD0179 00006400
	v_dual_dot2acc_f32_f16 v46, v128, v30 :: v_dual_dot2acc_f32_f16 v47, v127, v21// 000000546894: CB183D80 2E2E2B7F
	v_dual_dot2acc_f32_f16 v45, v120, v14 :: v_dual_dot2acc_f32_f16 v50, v127, v9// 00000054689C: CB181D78 2D32137F
	v_sad_u8 v119, v123, 0, 0x6400                             // 0000005468A4: D6220077 03FD017B 00006400
	v_dot2acc_f32_f16 v48, v127, v25                           // 0000005468B0: 0460337F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000005468B4: BF870214
	v_dot2acc_f32_f16 v46, v126, v31                           // 0000005468B8: 045C3F7E
	v_dual_dot2acc_f32_f16 v45, v124, v15 :: v_dual_dot2acc_f32_f16 v52, v127, v5// 0000005468BC: CB181F7C 2D340B7F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000005468C4: BF870214
	v_lshlrev_b32_e32 v119, 16, v119                           // 0000005468C8: 30EEEE90
	v_dual_dot2acc_f32_f16 v49, v127, v17 :: v_dual_dot2acc_f32_f16 v48, v128, v26// 0000005468CC: CB18237F 31303580
	v_dot2acc_f32_f16 v47, v128, v22                           // 0000005468D4: 045E2D80
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000005468D8: BF870214
	v_dual_dot2acc_f32_f16 v45, v125, v16 :: v_dual_dot2acc_f32_f16 v50, v128, v10// 0000005468DC: CB18217D 2D321580
	v_and_or_b32 v119, 0xffff, v121, v119                      // 0000005468E4: D6570077 05DEF2FF 0000FFFF
	ds_load_2addr_b32 v[120:121], v115 offset0:64 offset1:96   // 0000005468F0: D8DC6040 78000073
	v_dot2acc_f32_f16 v48, v126, v27                           // 0000005468F8: 0460377E
	ds_load_2addr_b32 v[122:123], v114 offset0:64 offset1:96   // 0000005468FC: D8DC6040 7A000072
	v_dot2acc_f32_f16 v50, v126, v11                           // 000000546904: 0464177E
	v_pk_fma_f16 v124, v119, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000546908: CC0E007C 0BFC0B77 0000C931
	v_dot2acc_f32_f16 v47, v126, v23                           // 000000546914: 045E2F7E
	s_waitcnt lgkmcnt(2)                                       // 000000546918: BF89FC27
	v_mov_b32_e32 v119, v117                                   // 00000054691C: 7EEE0375
	v_dual_dot2acc_f32_f16 v51, v127, v1 :: v_dual_dot2acc_f32_f16 v52, v128, v6// 000000546920: CB18037F 33340D80
	v_dot2acc_f32_f16 v46, v124, v32                           // 000000546928: 045C417C
	v_dot2acc_f32_f16 v47, v124, v24                           // 00000054692C: 045E317C
	v_dot2acc_f32_f16 v50, v124, v12                           // 000000546930: 0464197C
	v_dot2acc_f32_f16 v48, v124, v28                           // 000000546934: 0460397C
	v_dual_dot2acc_f32_f16 v52, v126, v7 :: v_dual_dot2acc_f32_f16 v53, v127, v13// 000000546938: CB180F7E 34341B7F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000546940: BF870001
	v_dot2acc_f32_f16 v52, v124, v8                            // 000000546944: 0468117C
	s_waitcnt lgkmcnt(1)                                       // 000000546948: BF89FC17
	.long 0xd73d0077                                           // 00000054694C: D73D0077
	v_cndmask_b32_e32 v1, v111, v119, vcc_lo                   // 000000546950: 0202EF6F
	v_dot2acc_f32_f16 v49, v128, v18                           // 000000546954: 04622580
	s_waitcnt lgkmcnt(0)                                       // 000000546958: BF89FC07
	v_bfe_u32 v129, v122, 12, 16                               // 00000054695C: D6100081 0241197A
	v_bfe_u32 v130, v122, 8, 16                                // 000000546964: D6100082 0241117A
	v_bfe_u32 v131, v122, 4, 16                                // 00000054696C: D6100083 0241097A
	v_and_b32_e32 v122, 0xffff, v122                           // 000000546974: 36F4F4FF 0000FFFF
	v_and_b32_e32 v120, 0xffff, v119                           // 00000054697C: 36F0EEFF 0000FFFF
	v_bfe_u32 v117, v119, 12, 16                               // 000000546984: D6100075 02411977
	v_bfe_u32 v125, v119, 8, 16                                // 00000054698C: D610007D 02411177
	v_bfe_u32 v119, v119, 4, 16                                // 000000546994: D6100077 02410977
	.long 0xd72c0081                                           // 00000054699C: D72C0081
	v_cndmask_b32_e32 v1, 0x83dcd12d, v129, vcc_lo             // 0000005469A0: 020302FF 83DCD12D
	.long 0xd72c0078                                           // 0000005469A8: D72C0078
	v_cndmask_b32_e32 v1, 0x83dcd12d, v120, vcc_lo             // 0000005469AC: 0202F0FF 83DCD12D
	.long 0xd72c0075                                           // 0000005469B4: D72C0075
	v_cndmask_b32_e32 v1, 0x83dcd12d, v117, vcc_lo             // 0000005469B8: 0202EAFF 83DCD12D
	.long 0xd72c007d                                           // 0000005469C0: D72C007D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v125, vcc_lo             // 0000005469C4: 0202FAFF 83DCD12D
	.long 0xd72c0077                                           // 0000005469CC: D72C0077
	v_cndmask_b32_e32 v1, 0x83dcd12d, v119, vcc_lo             // 0000005469D0: 0202EEFF 83DCD12D
	.long 0xd72c0082                                           // 0000005469D8: D72C0082
	v_cndmask_b32_e32 v1, 0x83dcd12d, v130, vcc_lo             // 0000005469DC: 020304FF 83DCD12D
	.long 0xd72c007a                                           // 0000005469E4: D72C007A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v122, vcc_lo             // 0000005469E8: 0202F4FF 83DCD12D
	v_dot2acc_f32_f16 v49, v126, v19                           // 0000005469F0: 0462277E
	v_sad_u8 v129, v129, 0, 0x6400                             // 0000005469F4: D6220081 03FD0181 00006400
	v_sad_u8 v120, v120, 0, 0x6400                             // 000000546A00: D6220078 03FD0178 00006400
	v_dot2acc_f32_f16 v51, v128, v2                            // 000000546A0C: 04660580
	v_sad_u8 v117, v117, 0, 0x6400                             // 000000546A10: D6220075 03FD0175 00006400
	v_sad_u8 v125, v125, 0, 0x6400                             // 000000546A1C: D622007D 03FD017D 00006400
	v_sad_u8 v119, v119, 0, 0x6400                             // 000000546A28: D6220077 03FD0177 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000546A34: BF870214
	v_dual_dot2acc_f32_f16 v51, v126, v3 :: v_dual_lshlrev_b32 v120, 16, v120// 000000546A38: CB22077E 3378F090
	v_and_b32_e32 v117, 0xffff, v117                           // 000000546A40: 36EAEAFF 0000FFFF
	v_dot2acc_f32_f16 v49, v124, v20                           // 000000546A48: 0462297C
	v_sad_u8 v122, v122, 0, 0x6400                             // 000000546A4C: D622007A 03FD017A 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 000000546A58: BF870004
	v_and_or_b32 v119, 0xffff, v119, v120                      // 000000546A5C: D6570077 05E2EEFF 0000FFFF
	.long 0xd72c0078                                           // 000000546A68: D72C0078
	v_cndmask_b32_e32 v1, 0x83dcd12d, v131, vcc_lo             // 000000546A6C: 020306FF 83DCD12D
	v_lshl_or_b32 v117, v125, 16, v117                         // 000000546A74: D6560075 05D5217D
	v_and_b32_e32 v125, 0xffff, v129                           // 000000546A7C: 36FB02FF 0000FFFF
	v_sad_u8 v129, v130, 0, 0x6400                             // 000000546A84: D6220081 03FD0182 00006400
	v_dot2acc_f32_f16 v51, v124, v4                            // 000000546A90: 0466097C
	v_pk_fma_f16 v130, v119, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000546A94: CC0E0082 0BFC0B77 0000C931
	v_pk_fma_f16 v127, v117, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000546AA0: CC0E007F 0BFC0B75 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000546AAC: BF870234
	v_lshl_or_b32 v117, v129, 16, v125                         // 000000546AB0: D6560075 05F52181
	v_sad_u8 v119, v120, 0, 0x6400                             // 000000546AB8: D6220077 03FD0178 00006400
	v_lshlrev_b32_e32 v120, 16, v122                           // 000000546AC4: 30F0F490
	v_dot2acc_f32_f16 v54, v127, v29                           // 000000546AC8: 046C3B7F
	v_dot2acc_f32_f16 v56, v127, v25                           // 000000546ACC: 0470337F
	v_pk_fma_f16 v122, v117, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000546AD0: CC0E007A 0BFC0B75 0000C931
	v_dot2acc_f32_f16 v60, v127, v5                            // 000000546ADC: 04780B7F
	v_and_or_b32 v117, 0xffff, v119, v120                      // 000000546AE0: D6570075 05E2EEFF 0000FFFF
	v_dual_dot2acc_f32_f16 v54, v130, v30 :: v_dual_mov_b32 v119, v121// 000000546AEC: CB103D82 36760179
	v_dual_dot2acc_f32_f16 v57, v127, v17 :: v_dual_dot2acc_f32_f16 v56, v130, v26// 000000546AF4: CB18237F 39383582
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000546AFC: BF870193
	v_pk_fma_f16 v125, v117, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000546B00: CC0E007D 0BFC0B75 0000C931
	v_dual_dot2acc_f32_f16 v54, v122, v31 :: v_dual_dot2acc_f32_f16 v55, v127, v21// 000000546B0C: CB183F7A 36362B7F
	v_dot2acc_f32_f16 v53, v128, v14                           // 000000546B14: 046A1D80
	v_dot2acc_f32_f16 v60, v130, v6                            // 000000546B18: 04780D82
	.long 0xd73d0075                                           // 000000546B1C: D73D0075
	v_cndmask_b32_e32 v1, v111, v118, vcc_lo                   // 000000546B20: 0202ED6F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000546B24: BF870214
	v_dual_dot2acc_f32_f16 v54, v125, v32 :: v_dual_dot2acc_f32_f16 v55, v130, v22// 000000546B28: CB18417D 36362D82
	v_dual_dot2acc_f32_f16 v53, v126, v15 :: v_dual_dot2acc_f32_f16 v58, v127, v9// 000000546B30: CB181F7E 353A137F
	v_dot2acc_f32_f16 v56, v122, v27                           // 000000546B38: 0470377A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000546B3C: BF870214
	v_bfe_u32 v118, v117, 12, 16                               // 000000546B40: D6100076 02411975
	v_dot2acc_f32_f16 v55, v122, v23                           // 000000546B48: 046E2F7A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000546B4C: BF870214
	v_dot2acc_f32_f16 v53, v124, v16                           // 000000546B50: 046A217C
	v_dual_dot2acc_f32_f16 v57, v130, v18 :: v_dual_dot2acc_f32_f16 v56, v125, v28// 000000546B54: CB182582 3938397D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000546B5C: BF8701B3
	v_dual_dot2acc_f32_f16 v58, v130, v10 :: v_dual_dot2acc_f32_f16 v55, v125, v24// 000000546B60: CB181582 3A36317D
	.long 0xd72c0076                                           // 000000546B68: D72C0076
	v_cndmask_b32_e32 v1, 0x83dcd12d, v118, vcc_lo             // 000000546B6C: 0202ECFF 83DCD12D
	v_bfe_u32 v120, v117, 8, 16                                // 000000546B74: D6100078 02411175
	v_dual_dot2acc_f32_f16 v59, v127, v1 :: v_dual_dot2acc_f32_f16 v58, v122, v11// 000000546B7C: CB18037F 3B3A177A
	v_dot2acc_f32_f16 v57, v122, v19                           // 000000546B84: 0472277A
	v_bfe_u32 v121, v123, 12, 16                               // 000000546B88: D6100079 0241197B
	s_delay_alu instid0(VALU_DEP_4)                            // 000000546B90: BF870004
	.long 0xd72c0078                                           // 000000546B94: D72C0078
	v_cndmask_b32_e32 v1, 0x83dcd12d, v120, vcc_lo             // 000000546B98: 0202F0FF 83DCD12D
	v_dot2acc_f32_f16 v60, v122, v7                            // 000000546BA0: 04780F7A
	v_dual_dot2acc_f32_f16 v59, v130, v2 :: v_dual_dot2acc_f32_f16 v58, v125, v12// 000000546BA4: CB180582 3B3A197D
	v_dot2acc_f32_f16 v57, v125, v20                           // 000000546BAC: 0472297D
	v_sad_u8 v118, v118, 0, 0x6400                             // 000000546BB0: D6220076 03FD0176 00006400
	v_bfe_u32 v124, v123, 8, 16                                // 000000546BBC: D610007C 0241117B
	.long 0xd72c0079                                           // 000000546BC4: D72C0079
	v_cndmask_b32_e32 v1, 0x83dcd12d, v121, vcc_lo             // 000000546BC8: 0202F2FF 83DCD12D
	v_sad_u8 v120, v120, 0, 0x6400                             // 000000546BD0: D6220078 03FD0178 00006400
	v_dual_dot2acc_f32_f16 v60, v125, v8 :: v_dual_dot2acc_f32_f16 v59, v122, v3// 000000546BDC: CB18117D 3C3A077A
	v_and_b32_e32 v118, 0xffff, v118                           // 000000546BE4: 36ECECFF 0000FFFF
	.long 0xd72c007c                                           // 000000546BEC: D72C007C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v124, vcc_lo             // 000000546BF0: 0202F8FF 83DCD12D
	v_bfe_u32 v126, v123, 4, 16                                // 000000546BF8: D610007E 0241097B
	v_sad_u8 v121, v121, 0, 0x6400                             // 000000546C00: D6220079 03FD0179 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000546C0C: BF870114
	v_lshl_or_b32 v118, v120, 16, v118                         // 000000546C10: D6560076 05D92178
	v_dual_dot2acc_f32_f16 v59, v125, v4 :: v_dual_and_b32 v120, 0xffff, v121// 000000546C18: CB24097D 3B78F2FF 0000FFFF
	v_sad_u8 v121, v124, 0, 0x6400                             // 000000546C24: D6220079 03FD017C 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000546C30: BF8701A3
	v_pk_fma_f16 v124, v118, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000546C34: CC0E007C 0BFC0B76 0000C931
	v_and_b32_e32 v123, 0xffff, v123                           // 000000546C40: 36F6F6FF 0000FFFF
	v_lshl_or_b32 v120, v121, 16, v120                         // 000000546C48: D6560078 05E12179
	s_delay_alu instid0(VALU_DEP_3)                            // 000000546C50: BF870003
	v_dot2acc_f32_f16 v62, v124, v29                           // 000000546C54: 047C3B7C
	v_and_b32_e32 v119, 0xffff, v117                           // 000000546C58: 36EEEAFF 0000FFFF
	v_bfe_u32 v117, v117, 4, 16                                // 000000546C60: D6100075 02410975
	.long 0xd72c007b                                           // 000000546C68: D72C007B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v123, vcc_lo             // 000000546C6C: 0202F6FF 83DCD12D
	v_dot2acc_f32_f16 v64, v124, v25                           // 000000546C74: 0480337C
	v_dot2acc_f32_f16 v66, v124, v9                            // 000000546C78: 0484137C
	.long 0xd72c0077                                           // 000000546C7C: D72C0077
	v_cndmask_b32_e32 v1, 0x83dcd12d, v119, vcc_lo             // 000000546C80: 0202EEFF 83DCD12D
	.long 0xd72c0075                                           // 000000546C88: D72C0075
	v_cndmask_b32_e32 v1, 0x83dcd12d, v117, vcc_lo             // 000000546C8C: 0202EAFF 83DCD12D
	v_dot2acc_f32_f16 v68, v124, v5                            // 000000546C94: 04880B7C
	v_dot2acc_f32_f16 v69, v124, v13                           // 000000546C98: 048A1B7C
	v_sad_u8 v123, v123, 0, 0x6400                             // 000000546C9C: D622007B 03FD017B 00006400
	v_sad_u8 v119, v119, 0, 0x6400                             // 000000546CA8: D6220077 03FD0177 00006400
	v_sad_u8 v117, v117, 0, 0x6400                             // 000000546CB4: D6220075 03FD0175 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000546CC0: BF870092
	v_lshlrev_b32_e32 v119, 16, v119                           // 000000546CC4: 30EEEE90
	v_and_or_b32 v117, 0xffff, v117, v119                      // 000000546CC8: D6570075 05DEEAFF 0000FFFF
	.long 0xd72c0077                                           // 000000546CD4: D72C0077
	v_cndmask_b32_e32 v1, 0x83dcd12d, v126, vcc_lo             // 000000546CD8: 0202FCFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2)                            // 000000546CE0: BF870002
	v_pk_fma_f16 v126, v117, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000546CE4: CC0E007E 0BFC0B75 0000C931
	v_lshlrev_b32_e32 v121, 16, v123                           // 000000546CF0: 30F2F690
	ds_load_2addr_b32 v[117:118], v116 offset0:128 offset1:160 // 000000546CF4: D8DCA080 75000074
	v_dot2acc_f32_f16 v67, v124, v1                            // 000000546CFC: 0486037C
	v_sad_u8 v119, v119, 0, 0x6400                             // 000000546D00: D6220077 03FD0177 00006400
	v_dot2acc_f32_f16 v64, v126, v26                           // 000000546D0C: 0480357E
	v_dot2acc_f32_f16 v62, v126, v30                           // 000000546D10: 047C3D7E
	v_dot2acc_f32_f16 v66, v126, v10                           // 000000546D14: 0484157E
	v_dot2acc_f32_f16 v68, v126, v6                            // 000000546D18: 04880D7E
	v_and_or_b32 v119, 0xffff, v119, v121                      // 000000546D1C: D6570077 05E6EEFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1)                            // 000000546D28: BF870001
	v_pk_fma_f16 v128, v119, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000546D2C: CC0E0080 0BFC0B77 0000C931
	v_dot2acc_f32_f16 v61, v127, v13                           // 000000546D38: 047A1B7F
	v_pk_fma_f16 v127, v120, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000546D3C: CC0E007F 0BFC0B78 0000C931
	v_dot2acc_f32_f16 v63, v124, v21                           // 000000546D48: 047E2B7C
	ds_load_2addr_b32 v[120:121], v115 offset0:128 offset1:160 // 000000546D4C: D8DCA080 78000073
	v_dual_dot2acc_f32_f16 v65, v124, v17 :: v_dual_dot2acc_f32_f16 v66, v127, v11// 000000546D54: CB18237C 4142177F
	v_dual_dot2acc_f32_f16 v62, v127, v31 :: v_dual_dot2acc_f32_f16 v63, v126, v22// 000000546D5C: CB183F7F 3E3E2D7E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000546D64: BF870192
	v_dual_dot2acc_f32_f16 v64, v127, v27 :: v_dual_dot2acc_f32_f16 v65, v126, v18// 000000546D68: CB18377F 4040257E
	v_dot2acc_f32_f16 v66, v128, v12                           // 000000546D70: 04841980
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000546D74: BF870193
	v_dual_dot2acc_f32_f16 v62, v128, v32 :: v_dual_dot2acc_f32_f16 v61, v130, v14// 000000546D78: CB184180 3E3C1D82
	v_dual_dot2acc_f32_f16 v63, v127, v23 :: v_dual_dot2acc_f32_f16 v64, v128, v28// 000000546D80: CB182F7F 3F403980
	v_dot2acc_f32_f16 v68, v127, v7                            // 000000546D88: 04880F7F
	s_delay_alu instid0(VALU_DEP_3)                            // 000000546D8C: BF870003
	v_dot2acc_f32_f16 v61, v122, v15                           // 000000546D90: 047A1F7A
	ds_load_2addr_b32 v[122:123], v114 offset0:128 offset1:160 // 000000546D94: D8DCA080 7A000072
	s_waitcnt lgkmcnt(2)                                       // 000000546D9C: BF89FC27
	v_dual_mov_b32 v119, v117 :: v_dual_dot2acc_f32_f16 v68, v128, v8// 000000546DA0: CA180175 77441180
	v_dot2acc_f32_f16 v61, v125, v16                           // 000000546DA8: 047A217D
	s_waitcnt lgkmcnt(0)                                       // 000000546DAC: BF89FC07
	v_bfe_u32 v129, v122, 12, 16                               // 000000546DB0: D6100081 0241197A
	v_bfe_u32 v130, v122, 8, 16                                // 000000546DB8: D6100082 0241117A
	v_bfe_u32 v131, v122, 4, 16                                // 000000546DC0: D6100083 0241097A
	v_and_b32_e32 v122, 0xffff, v122                           // 000000546DC8: 36F4F4FF 0000FFFF
	.long 0xd73d0077                                           // 000000546DD0: D73D0077
	v_cndmask_b32_e32 v1, v111, v119, vcc_lo                   // 000000546DD4: 0202EF6F
	v_dot2acc_f32_f16 v63, v128, v24                           // 000000546DD8: 047E3180
	.long 0xd72c0081                                           // 000000546DDC: D72C0081
	v_cndmask_b32_e32 v1, 0x83dcd12d, v129, vcc_lo             // 000000546DE0: 020302FF 83DCD12D
	.long 0xd72c0082                                           // 000000546DE8: D72C0082
	v_cndmask_b32_e32 v1, 0x83dcd12d, v130, vcc_lo             // 000000546DEC: 020304FF 83DCD12D
	.long 0xd72c007a                                           // 000000546DF4: D72C007A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v122, vcc_lo             // 000000546DF8: 0202F4FF 83DCD12D
	v_bfe_u32 v117, v119, 12, 16                               // 000000546E00: D6100075 02411977
	v_and_b32_e32 v120, 0xffff, v119                           // 000000546E08: 36F0EEFF 0000FFFF
	v_bfe_u32 v125, v119, 8, 16                                // 000000546E10: D610007D 02411177
	v_bfe_u32 v119, v119, 4, 16                                // 000000546E18: D6100077 02410977
	v_sad_u8 v129, v129, 0, 0x6400                             // 000000546E20: D6220081 03FD0181 00006400
	.long 0xd72c0075                                           // 000000546E2C: D72C0075
	v_cndmask_b32_e32 v1, 0x83dcd12d, v117, vcc_lo             // 000000546E30: 0202EAFF 83DCD12D
	.long 0xd72c0078                                           // 000000546E38: D72C0078
	v_cndmask_b32_e32 v1, 0x83dcd12d, v120, vcc_lo             // 000000546E3C: 0202F0FF 83DCD12D
	.long 0xd72c007d                                           // 000000546E44: D72C007D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v125, vcc_lo             // 000000546E48: 0202FAFF 83DCD12D
	.long 0xd72c0077                                           // 000000546E50: D72C0077
	v_cndmask_b32_e32 v1, 0x83dcd12d, v119, vcc_lo             // 000000546E54: 0202EEFF 83DCD12D
	v_sad_u8 v122, v122, 0, 0x6400                             // 000000546E5C: D622007A 03FD017A 00006400
	v_dot2acc_f32_f16 v65, v127, v19                           // 000000546E68: 0482277F
	v_sad_u8 v117, v117, 0, 0x6400                             // 000000546E6C: D6220075 03FD0175 00006400
	v_sad_u8 v120, v120, 0, 0x6400                             // 000000546E78: D6220078 03FD0178 00006400
	v_sad_u8 v125, v125, 0, 0x6400                             // 000000546E84: D622007D 03FD017D 00006400
	v_dot2acc_f32_f16 v67, v126, v2                            // 000000546E90: 0486057E
	v_sad_u8 v119, v119, 0, 0x6400                             // 000000546E94: D6220077 03FD0177 00006400
	v_and_b32_e32 v117, 0xffff, v117                           // 000000546EA0: 36EAEAFF 0000FFFF
	v_lshlrev_b32_e32 v120, 16, v120                           // 000000546EA8: 30F0F090
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000546EAC: BF870112
	v_lshl_or_b32 v117, v125, 16, v117                         // 000000546EB0: D6560075 05D5217D
	v_and_or_b32 v119, 0xffff, v119, v120                      // 000000546EB8: D6570077 05E2EEFF 0000FFFF
	.long 0xd72c0078                                           // 000000546EC4: D72C0078
	v_cndmask_b32_e32 v1, 0x83dcd12d, v131, vcc_lo             // 000000546EC8: 020306FF 83DCD12D
	v_and_b32_e32 v125, 0xffff, v129                           // 000000546ED0: 36FB02FF 0000FFFF
	v_sad_u8 v129, v130, 0, 0x6400                             // 000000546ED8: D6220081 03FD0182 00006400
	v_pk_fma_f16 v124, v117, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000546EE4: CC0E007C 0BFC0B75 0000C931
	v_dot2acc_f32_f16 v67, v127, v3                            // 000000546EF0: 0486077F
	v_pk_fma_f16 v130, v119, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000546EF4: CC0E0082 0BFC0B77 0000C931
	s_delay_alu instid0(VALU_DEP_4)                            // 000000546F00: BF870004
	v_lshl_or_b32 v117, v129, 16, v125                         // 000000546F04: D6560075 05F52181
	v_sad_u8 v119, v120, 0, 0x6400                             // 000000546F0C: D6220077 03FD0178 00006400
	v_lshlrev_b32_e32 v120, 16, v122                           // 000000546F18: 30F0F490
	v_dot2acc_f32_f16 v70, v124, v29                           // 000000546F1C: 048C3B7C
	v_dot2acc_f32_f16 v67, v128, v4                            // 000000546F20: 04860980
	v_pk_fma_f16 v122, v117, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000546F24: CC0E007A 0BFC0B75 0000C931
	v_dot2acc_f32_f16 v72, v124, v25                           // 000000546F30: 0490337C
	v_and_or_b32 v117, 0xffff, v119, v120                      // 000000546F34: D6570075 05E2EEFF 0000FFFF
	v_dual_dot2acc_f32_f16 v70, v130, v30 :: v_dual_dot2acc_f32_f16 v71, v124, v21// 000000546F40: CB183D82 46462B7C
	v_dot2acc_f32_f16 v74, v124, v9                            // 000000546F48: 0494137C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000546F4C: BF870214
	v_dot2acc_f32_f16 v72, v130, v26                           // 000000546F50: 04903582
	v_pk_fma_f16 v125, v117, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000546F54: CC0E007D 0BFC0B75 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000546F60: BF870224
	v_dot2acc_f32_f16 v70, v122, v31                           // 000000546F64: 048C3F7A
	v_dual_dot2acc_f32_f16 v71, v130, v22 :: v_dual_dot2acc_f32_f16 v76, v124, v5// 000000546F68: CB182D82 474C0B7C
	v_dual_dot2acc_f32_f16 v73, v124, v17 :: v_dual_dot2acc_f32_f16 v72, v122, v27// 000000546F70: CB18237C 4948377A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000546F78: BF870193
	v_dual_dot2acc_f32_f16 v70, v125, v32 :: v_dual_dot2acc_f32_f16 v69, v126, v14// 000000546F7C: CB18417D 46441D7E
	v_dot2acc_f32_f16 v71, v122, v23                           // 000000546F84: 048E2F7A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000546F88: BF870224
	v_dual_dot2acc_f32_f16 v76, v130, v6 :: v_dual_mov_b32 v119, v121// 000000546F8C: CB100D82 4C760179
	v_bfe_u32 v121, v123, 12, 16                               // 000000546F94: D6100079 0241197B
	v_dual_dot2acc_f32_f16 v69, v127, v15 :: v_dual_dot2acc_f32_f16 v74, v130, v10// 000000546F9C: CB181F7F 454A1582
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000546FA4: BF870213
	v_dual_dot2acc_f32_f16 v71, v125, v24 :: v_dual_dot2acc_f32_f16 v76, v122, v7// 000000546FA8: CB18317D 474C0F7A
	.long 0xd73d0075                                           // 000000546FB0: D73D0075
	v_cndmask_b32_e32 v1, v111, v118, vcc_lo                   // 000000546FB4: 0202ED6F
	v_dual_dot2acc_f32_f16 v73, v130, v18 :: v_dual_dot2acc_f32_f16 v72, v125, v28// 000000546FB8: CB182582 4948397D
	v_bfe_u32 v126, v123, 8, 16                                // 000000546FC0: D610007E 0241117B
	.long 0xd72c0079                                           // 000000546FC8: D72C0079
	v_cndmask_b32_e32 v1, 0x83dcd12d, v121, vcc_lo             // 000000546FCC: 0202F2FF 83DCD12D
	v_dual_dot2acc_f32_f16 v69, v128, v16 :: v_dual_dot2acc_f32_f16 v74, v122, v11// 000000546FD4: CB182180 454A177A
	v_bfe_u32 v118, v117, 12, 16                               // 000000546FDC: D6100076 02411975
	v_and_b32_e32 v119, 0xffff, v117                           // 000000546FE4: 36EEEAFF 0000FFFF
	v_bfe_u32 v120, v117, 8, 16                                // 000000546FEC: D6100078 02411175
	v_bfe_u32 v117, v117, 4, 16                                // 000000546FF4: D6100075 02410975
	v_dual_dot2acc_f32_f16 v75, v124, v1 :: v_dual_dot2acc_f32_f16 v74, v125, v12// 000000546FFC: CB18037C 4B4A197D
	.long 0xd72c0076                                           // 000000547004: D72C0076
	v_cndmask_b32_e32 v1, 0x83dcd12d, v118, vcc_lo             // 000000547008: 0202ECFF 83DCD12D
	.long 0xd72c0077                                           // 000000547010: D72C0077
	v_cndmask_b32_e32 v1, 0x83dcd12d, v119, vcc_lo             // 000000547014: 0202EEFF 83DCD12D
	.long 0xd72c0078                                           // 00000054701C: D72C0078
	v_cndmask_b32_e32 v1, 0x83dcd12d, v120, vcc_lo             // 000000547020: 0202F0FF 83DCD12D
	.long 0xd72c0075                                           // 000000547028: D72C0075
	v_cndmask_b32_e32 v1, 0x83dcd12d, v117, vcc_lo             // 00000054702C: 0202EAFF 83DCD12D
	.long 0xd72c007e                                           // 000000547034: D72C007E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v126, vcc_lo             // 000000547038: 0202FCFF 83DCD12D
	v_dual_dot2acc_f32_f16 v75, v130, v2 :: v_dual_dot2acc_f32_f16 v76, v125, v8// 000000547040: CB180582 4B4C117D
	v_sad_u8 v121, v121, 0, 0x6400                             // 000000547048: D6220079 03FD0179 00006400
	v_sad_u8 v118, v118, 0, 0x6400                             // 000000547054: D6220076 03FD0176 00006400
	v_sad_u8 v119, v119, 0, 0x6400                             // 000000547060: D6220077 03FD0177 00006400
	v_dot2acc_f32_f16 v73, v122, v19                           // 00000054706C: 0492277A
	v_sad_u8 v120, v120, 0, 0x6400                             // 000000547070: D6220078 03FD0178 00006400
	v_sad_u8 v117, v117, 0, 0x6400                             // 00000054707C: D6220075 03FD0175 00006400
	v_and_b32_e32 v118, 0xffff, v118                           // 000000547088: 36ECECFF 0000FFFF
	v_lshlrev_b32_e32 v119, 16, v119                           // 000000547090: 30EEEE90
	v_dot2acc_f32_f16 v65, v128, v20                           // 000000547094: 04822980
	v_dot2acc_f32_f16 v75, v122, v3                            // 000000547098: 0496077A
	v_bfe_u32 v127, v123, 4, 16                                // 00000054709C: D610007F 0241097B
	v_lshl_or_b32 v118, v120, 16, v118                         // 0000005470A4: D6560076 05D92178
	v_and_or_b32 v117, 0xffff, v117, v119                      // 0000005470AC: D6570075 05DEEAFF 0000FFFF
	v_and_b32_e32 v120, 0xffff, v121                           // 0000005470B8: 36F0F2FF 0000FFFF
	v_sad_u8 v121, v126, 0, 0x6400                             // 0000005470C0: D6220079 03FD017E 00006400
	.long 0xd72c0077                                           // 0000005470CC: D72C0077
	v_cndmask_b32_e32 v1, 0x83dcd12d, v127, vcc_lo             // 0000005470D0: 0202FEFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 0000005470D8: BF870004
	v_pk_fma_f16 v126, v117, s5, 0xc931 op_sel_hi:[1,0,0]      // 0000005470DC: CC0E007E 0BFC0B75 0000C931
	v_dot2acc_f32_f16 v77, v124, v13                           // 0000005470E8: 049A1B7C
	v_pk_fma_f16 v124, v118, s5, 0xc931 op_sel_hi:[1,0,0]      // 0000005470EC: CC0E007C 0BFC0B76 0000C931
	v_and_b32_e32 v123, 0xffff, v123                           // 0000005470F8: 36F6F6FF 0000FFFF
	v_lshl_or_b32 v120, v121, 16, v120                         // 000000547100: D6560078 05E12179
	ds_load_2addr_b32 v[117:118], v116 offset0:192 offset1:224 // 000000547108: D8DCE0C0 75000074
	v_sad_u8 v119, v119, 0, 0x6400                             // 000000547110: D6220077 03FD0177 00006400
	v_dot2acc_f32_f16 v80, v124, v25                           // 00000054711C: 04A0337C
	.long 0xd72c007b                                           // 000000547120: D72C007B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v123, vcc_lo             // 000000547124: 0202F6FF 83DCD12D
	v_pk_fma_f16 v127, v120, s5, 0xc931 op_sel_hi:[1,0,0]      // 00000054712C: CC0E007F 0BFC0B78 0000C931
	v_dot2acc_f32_f16 v82, v124, v9                            // 000000547138: 04A4137C
	v_dot2acc_f32_f16 v84, v124, v5                            // 00000054713C: 04A80B7C
	v_dot2acc_f32_f16 v80, v126, v26                           // 000000547140: 04A0357E
	v_dot2acc_f32_f16 v77, v130, v14                           // 000000547144: 049A1D82
	v_dual_dot2acc_f32_f16 v73, v125, v20 :: v_dual_dot2acc_f32_f16 v78, v124, v29// 000000547148: CB18297D 494E3B7C
	v_sad_u8 v123, v123, 0, 0x6400                             // 000000547150: D622007B 03FD017B 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000054715C: BF8701A4
	v_dot2acc_f32_f16 v80, v127, v27                           // 000000547160: 04A0377F
	v_dual_dot2acc_f32_f16 v84, v126, v6 :: v_dual_dot2acc_f32_f16 v75, v125, v4// 000000547164: CB180D7E 544A097D
	v_dual_dot2acc_f32_f16 v78, v126, v30 :: v_dual_lshlrev_b32 v121, 16, v123// 00000054716C: CB223D7E 4E78F690
	v_dual_dot2acc_f32_f16 v79, v124, v21 :: v_dual_dot2acc_f32_f16 v82, v126, v10// 000000547174: CB182B7C 4F52157E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000054717C: BF870193
	v_dot2acc_f32_f16 v84, v127, v7                            // 000000547180: 04A80F7F
	v_dot2acc_f32_f16 v78, v127, v31                           // 000000547184: 049C3F7F
	s_delay_alu instid0(VALU_DEP_4)                            // 000000547188: BF870004
	v_and_or_b32 v119, 0xffff, v119, v121                      // 00000054718C: D6570077 05E6EEFF 0000FFFF
	ds_load_2addr_b32 v[120:121], v115 offset0:192 offset1:224 // 000000547198: D8DCE0C0 78000073
	v_dual_dot2acc_f32_f16 v79, v126, v22 :: v_dual_dot2acc_f32_f16 v82, v127, v11// 0000005471A0: CB182D7E 4F52177F
	v_pk_fma_f16 v128, v119, s5, 0xc931 op_sel_hi:[1,0,0]      // 0000005471A8: CC0E0080 0BFC0B77 0000C931
	v_dot2acc_f32_f16 v77, v122, v15                           // 0000005471B4: 049A1F7A
	ds_load_2addr_b32 v[122:123], v114 offset0:192 offset1:224 // 0000005471B8: D8DCE0C0 7A000072
	s_waitcnt lgkmcnt(2)                                       // 0000005471C0: BF89FC27
	v_mov_b32_e32 v119, v117                                   // 0000005471C4: 7EEE0375
	v_dot2acc_f32_f16 v83, v124, v1                            // 0000005471C8: 04A6037C
	v_dot2acc_f32_f16 v80, v128, v28                           // 0000005471CC: 04A03980
	v_dot2acc_f32_f16 v77, v125, v16                           // 0000005471D0: 049A217D
	v_dual_dot2acc_f32_f16 v79, v127, v23 :: v_dual_dot2acc_f32_f16 v82, v128, v12// 0000005471D4: CB182F7F 4F521980
	v_dot2acc_f32_f16 v78, v128, v32                           // 0000005471DC: 049C4180
	v_dot2acc_f32_f16 v84, v128, v8                            // 0000005471E0: 04A81180
	s_waitcnt lgkmcnt(1)                                       // 0000005471E4: BF89FC17
	.long 0xd73d0077                                           // 0000005471E8: D73D0077
	v_cndmask_b32_e32 v1, v111, v119, vcc_lo                   // 0000005471EC: 0202EF6F
	s_delay_alu instid0(VALU_DEP_1)                            // 0000005471F0: BF870001
	v_dual_dot2acc_f32_f16 v81, v124, v17 :: v_dual_and_b32 v120, 0xffff, v119// 0000005471F4: CB24237C 5178EEFF 0000FFFF
	v_bfe_u32 v117, v119, 12, 16                               // 000000547200: D6100075 02411977
	v_bfe_u32 v125, v119, 8, 16                                // 000000547208: D610007D 02411177
	v_bfe_u32 v119, v119, 4, 16                                // 000000547210: D6100077 02410977
	s_waitcnt lgkmcnt(0)                                       // 000000547218: BF89FC07
	v_bfe_u32 v129, v122, 12, 16                               // 00000054721C: D6100081 0241197A
	.long 0xd72c0078                                           // 000000547224: D72C0078
	v_cndmask_b32_e32 v1, 0x83dcd12d, v120, vcc_lo             // 000000547228: 0202F0FF 83DCD12D
	.long 0xd72c0075                                           // 000000547230: D72C0075
	v_cndmask_b32_e32 v1, 0x83dcd12d, v117, vcc_lo             // 000000547234: 0202EAFF 83DCD12D
	v_bfe_u32 v130, v122, 8, 16                                // 00000054723C: D6100082 0241117A
	.long 0xd72c0077                                           // 000000547244: D72C0077
	v_cndmask_b32_e32 v1, 0x83dcd12d, v119, vcc_lo             // 000000547248: 0202EEFF 83DCD12D
	.long 0xd72c007d                                           // 000000547250: D72C007D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v125, vcc_lo             // 000000547254: 0202FAFF 83DCD12D
	v_bfe_u32 v131, v122, 4, 16                                // 00000054725C: D6100083 0241097A
	.long 0xd72c0081                                           // 000000547264: D72C0081
	v_cndmask_b32_e32 v1, 0x83dcd12d, v129, vcc_lo             // 000000547268: 020302FF 83DCD12D
	v_and_b32_e32 v122, 0xffff, v122                           // 000000547270: 36F4F4FF 0000FFFF
	v_sad_u8 v120, v120, 0, 0x6400                             // 000000547278: D6220078 03FD0178 00006400
	v_sad_u8 v117, v117, 0, 0x6400                             // 000000547284: D6220075 03FD0175 00006400
	v_dot2acc_f32_f16 v81, v126, v18                           // 000000547290: 04A2257E
	v_sad_u8 v119, v119, 0, 0x6400                             // 000000547294: D6220077 03FD0177 00006400
	.long 0xd72c0082                                           // 0000005472A0: D72C0082
	v_cndmask_b32_e32 v1, 0x83dcd12d, v130, vcc_lo             // 0000005472A4: 020304FF 83DCD12D
	v_lshlrev_b32_e32 v120, 16, v120                           // 0000005472AC: 30F0F090
	.long 0xd72c007a                                           // 0000005472B0: D72C007A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v122, vcc_lo             // 0000005472B4: 0202F4FF 83DCD12D
	v_and_b32_e32 v117, 0xffff, v117                           // 0000005472BC: 36EAEAFF 0000FFFF
	v_sad_u8 v125, v125, 0, 0x6400                             // 0000005472C4: D622007D 03FD017D 00006400
	v_sad_u8 v129, v129, 0, 0x6400                             // 0000005472D0: D6220081 03FD0181 00006400
	v_and_or_b32 v119, 0xffff, v119, v120                      // 0000005472DC: D6570077 05E2EEFF 0000FFFF
	.long 0xd72c0078                                           // 0000005472E8: D72C0078
	v_cndmask_b32_e32 v1, 0x83dcd12d, v131, vcc_lo             // 0000005472EC: 020306FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000005472F4: BF870214
	v_lshl_or_b32 v117, v125, 16, v117                         // 0000005472F8: D6560075 05D5217D
	v_and_b32_e32 v125, 0xffff, v129                           // 000000547300: 36FB02FF 0000FFFF
	v_sad_u8 v129, v130, 0, 0x6400                             // 000000547308: D6220081 03FD0182 00006400
	v_sad_u8 v122, v122, 0, 0x6400                             // 000000547314: D622007A 03FD017A 00006400
	v_dot2acc_f32_f16 v81, v127, v19                           // 000000547320: 04A2277F
	v_pk_fma_f16 v130, v119, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000547324: CC0E0082 0BFC0B77 0000C931
	v_dot2acc_f32_f16 v85, v124, v13                           // 000000547330: 04AA1B7C
	v_pk_fma_f16 v124, v117, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000547334: CC0E007C 0BFC0B75 0000C931
	v_lshl_or_b32 v117, v129, 16, v125                         // 000000547340: D6560075 05F52181
	v_sad_u8 v119, v120, 0, 0x6400                             // 000000547348: D6220077 03FD0178 00006400
	v_lshlrev_b32_e32 v120, 16, v122                           // 000000547354: 30F0F490
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000547358: BF870214
	v_dual_dot2acc_f32_f16 v83, v126, v2 :: v_dual_dot2acc_f32_f16 v86, v124, v29// 00000054735C: CB18057E 53563B7C
	v_pk_fma_f16 v122, v117, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000547364: CC0E007A 0BFC0B75 0000C931
	v_dot2acc_f32_f16 v88, v124, v25                           // 000000547370: 04B0337C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000547374: BF870234
	v_and_or_b32 v117, 0xffff, v119, v120                      // 000000547378: D6570075 05E2EEFF 0000FFFF
	v_mov_b32_e32 v119, v121                                   // 000000547384: 7EEE0379
	v_dual_dot2acc_f32_f16 v83, v127, v3 :: v_dual_dot2acc_f32_f16 v90, v124, v9// 000000547388: CB18077F 535A137C
	v_dot2acc_f32_f16 v88, v130, v26                           // 000000547390: 04B03582
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000547394: BF870214
	v_pk_fma_f16 v120, v117, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000547398: CC0E0078 0BFC0B75 0000C931
	.long 0xd73d0075                                           // 0000005473A4: D73D0075
	v_cndmask_b32_e32 v1, v111, v118, vcc_lo                   // 0000005473A8: 0202ED6F
	v_dot2acc_f32_f16 v85, v126, v14                           // 0000005473AC: 04AA1D7E
	s_delay_alu instid0(VALU_DEP_4)                            // 0000005473B0: BF870004
	v_dual_dot2acc_f32_f16 v87, v124, v21 :: v_dual_dot2acc_f32_f16 v88, v122, v27// 0000005473B4: CB182B7C 5758377A
	v_dot2acc_f32_f16 v92, v124, v5                            // 0000005473BC: 04B80B7C
	v_dot2acc_f32_f16 v89, v124, v17                           // 0000005473C0: 04B2237C
	v_bfe_u32 v118, v117, 12, 16                               // 0000005473C4: D6100076 02411975
	v_bfe_u32 v121, v117, 8, 16                                // 0000005473CC: D6100079 02411175
	v_dot2acc_f32_f16 v85, v127, v15                           // 0000005473D4: 04AA1F7F
	v_dual_dot2acc_f32_f16 v90, v130, v10 :: v_dual_and_b32 v119, 0xffff, v117// 0000005473D8: CB241582 5A76EAFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000005473E4: BF870214
	.long 0xd72c0076                                           // 0000005473E8: D72C0076
	v_cndmask_b32_e32 v1, 0x83dcd12d, v118, vcc_lo             // 0000005473EC: 0202ECFF 83DCD12D
	.long 0xd72c0079                                           // 0000005473F4: D72C0079
	v_cndmask_b32_e32 v1, 0x83dcd12d, v121, vcc_lo             // 0000005473F8: 0202F2FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000547400: BF870214
	v_dot2acc_f32_f16 v85, v128, v16                           // 000000547404: 04AA2180
	v_dual_dot2acc_f32_f16 v91, v124, v1 :: v_dual_dot2acc_f32_f16 v90, v122, v11// 000000547408: CB18037C 5B5A177A
	v_dot2acc_f32_f16 v93, v124, v13                           // 000000547410: 04BA1B7C
	v_bfe_u32 v117, v117, 4, 16                                // 000000547414: D6100075 02410975
	.long 0xd72c0077                                           // 00000054741C: D72C0077
	v_cndmask_b32_e32 v1, 0x83dcd12d, v119, vcc_lo             // 000000547420: 0202EEFF 83DCD12D
	v_sad_u8 v118, v118, 0, 0x6400                             // 000000547428: D6220076 03FD0176 00006400
	v_sad_u8 v121, v121, 0, 0x6400                             // 000000547434: D6220079 03FD0179 00006400
	v_bfe_u32 v124, v123, 12, 16                               // 000000547440: D610007C 0241197B
	v_bfe_u32 v125, v123, 8, 16                                // 000000547448: D610007D 0241117B
	.long 0xd72c0075                                           // 000000547450: D72C0075
	v_cndmask_b32_e32 v1, 0x83dcd12d, v117, vcc_lo             // 000000547454: 0202EAFF 83DCD12D
	v_and_b32_e32 v118, 0xffff, v118                           // 00000054745C: 36ECECFF 0000FFFF
	v_bfe_u32 v126, v123, 4, 16                                // 000000547464: D610007E 0241097B
	.long 0xd72c007c                                           // 00000054746C: D72C007C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v124, vcc_lo             // 000000547470: 0202F8FF 83DCD12D
	v_dual_dot2acc_f32_f16 v87, v130, v22 :: v_dual_dot2acc_f32_f16 v88, v120, v28// 000000547478: CB182D82 57583978
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000547480: BF870234
	v_lshl_or_b32 v118, v121, 16, v118                         // 000000547484: D6560076 05D92179
	v_sad_u8 v119, v119, 0, 0x6400                             // 00000054748C: D6220077 03FD0177 00006400
	.long 0xd72c007d                                           // 000000547498: D72C007D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v125, vcc_lo             // 00000054749C: 0202FAFF 83DCD12D
	v_dual_dot2acc_f32_f16 v87, v122, v23 :: v_dual_dot2acc_f32_f16 v90, v120, v12// 0000005474A4: CB182F7A 575A1978
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000005474AC: BF8701B4
	v_pk_fma_f16 v118, v118, s5, 0xc931 op_sel_hi:[1,0,0]      // 0000005474B0: CC0E0076 0BFC0B76 0000C931
	v_dual_dot2acc_f32_f16 v92, v130, v6 :: v_dual_and_b32 v123, 0xffff, v123// 0000005474BC: CB240D82 5C7AF6FF 0000FFFF
	v_sad_u8 v117, v117, 0, 0x6400                             // 0000005474C8: D6220075 03FD0175 00006400
	v_dual_dot2acc_f32_f16 v98, v118, v9 :: v_dual_lshlrev_b32 v119, 16, v119// 0000005474D4: CB221376 6276EE90
	v_dot2acc_f32_f16 v94, v118, v29                           // 0000005474DC: 04BC3B76
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000005474E0: BF870254
	.long 0xd72c007b                                           // 0000005474E4: D72C007B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v123, vcc_lo             // 0000005474E8: 0202F6FF 83DCD12D
	v_sad_u8 v124, v124, 0, 0x6400                             // 0000005474F0: D622007C 03FD017C 00006400
	v_dual_dot2acc_f32_f16 v87, v120, v24 :: v_dual_dot2acc_f32_f16 v92, v122, v7// 0000005474FC: CB183178 575C0F7A
	v_dot2acc_f32_f16 v89, v130, v18                           // 000000547504: 04B22582
	v_and_or_b32 v117, 0xffff, v117, v119                      // 000000547508: D6570075 05DEEAFF 0000FFFF
	v_dual_dot2acc_f32_f16 v100, v118, v5 :: v_dual_and_b32 v119, 0xffff, v124// 000000547514: CB240B76 6476F8FF 0000FFFF
	v_sad_u8 v121, v123, 0, 0x6400                             // 000000547520: D6220079 03FD017B 00006400
	v_sad_u8 v123, v125, 0, 0x6400                             // 00000054752C: D622007B 03FD017D 00006400
	v_dot2acc_f32_f16 v92, v120, v8                            // 000000547538: 04B81178
	v_pk_fma_f16 v117, v117, s5, 0xc931 op_sel_hi:[1,0,0]      // 00000054753C: CC0E0075 0BFC0B75 0000C931
	v_dot2acc_f32_f16 v89, v122, v19                           // 000000547548: 04B2277A
	v_dual_dot2acc_f32_f16 v79, v128, v24 :: v_dual_dot2acc_f32_f16 v86, v130, v30// 00000054754C: CB183180 4F563D82
	v_lshl_or_b32 v119, v123, 16, v119                         // 000000547554: D6560077 05DD217B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000054755C: BF870234
	v_dual_dot2acc_f32_f16 v98, v117, v10 :: v_dual_lshlrev_b32 v121, 16, v121// 000000547560: CB221575 6278F290
	v_dot2acc_f32_f16 v96, v118, v25                           // 000000547568: 04C03376
	v_dual_dot2acc_f32_f16 v94, v117, v30 :: v_dual_dot2acc_f32_f16 v89, v120, v20// 00000054756C: CB183D75 5E582978
	v_pk_fma_f16 v25, v119, s5, 0xc931 op_sel_hi:[1,0,0]       // 000000547574: CC0E0019 0BFC0B77 0000C931
	v_dot2acc_f32_f16 v91, v130, v2                            // 000000547580: 04B60582
	v_dot2acc_f32_f16 v93, v130, v14                           // 000000547584: 04BA1D82
	v_dual_dot2acc_f32_f16 v83, v128, v4 :: v_dual_dot2acc_f32_f16 v86, v122, v31// 000000547588: CB180980 53563F7A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000547590: BF870214
	v_dot2acc_f32_f16 v94, v25, v31                            // 000000547594: 04BC3F19
	v_dual_dot2acc_f32_f16 v91, v122, v3 :: v_dual_dot2acc_f32_f16 v96, v117, v26// 000000547598: CB18077A 5B603575
	v_dot2acc_f32_f16 v98, v25, v11                            // 0000005475A0: 04C41719
	v_dual_dot2acc_f32_f16 v93, v122, v15 :: v_dual_dot2acc_f32_f16 v100, v117, v6// 0000005475A4: CB181F7A 5D640D75
	.long 0xd72c007a                                           // 0000005475AC: D72C007A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v126, vcc_lo             // 0000005475B0: 0202FCFF 83DCD12D
	v_dot2acc_f32_f16 v40, v118, v13                           // 0000005475B8: 04501B76
	v_dot2acc_f32_f16 v95, v118, v21                           // 0000005475BC: 04BE2B76
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000005475C0: BF870224
	v_dot2acc_f32_f16 v93, v120, v16                           // 0000005475C4: 04BA2178
	v_dual_dot2acc_f32_f16 v97, v118, v17 :: v_dual_dot2acc_f32_f16 v100, v25, v7// 0000005475C8: CB182376 61640F19
	v_dual_dot2acc_f32_f16 v40, v117, v14 :: v_dual_dot2acc_f32_f16 v99, v118, v1// 0000005475D0: CB181D75 28620376
	v_sad_u8 v122, v122, 0, 0x6400                             // 0000005475D8: D622007A 03FD017A 00006400
	v_dot2acc_f32_f16 v95, v117, v22                           // 0000005475E4: 04BE2D75
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000005475E8: BF870214
	v_dot2acc_f32_f16 v97, v117, v18                           // 0000005475EC: 04C22575
	v_dot2acc_f32_f16 v40, v25, v15                            // 0000005475F0: 04501F19
	v_dot2acc_f32_f16 v99, v117, v2                            // 0000005475F4: 04C60575
	v_and_or_b32 v21, 0xffff, v122, v121                       // 0000005475F8: D6570015 05E6F4FF 0000FFFF
	v_dot2acc_f32_f16 v81, v128, v20                           // 000000547604: 04A22980
	v_dual_dot2acc_f32_f16 v91, v120, v4 :: v_dual_dot2acc_f32_f16 v96, v25, v27// 000000547608: CB180978 5B603719
	v_dot2acc_f32_f16 v95, v25, v23                            // 000000547610: 04BE2F19
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000547614: BF8701C4
	v_pk_fma_f16 v21, v21, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000547618: CC0E0015 0BFC0B15 0000C931
	v_add_nc_u32_e32 v113, 1, v113                             // 000000547624: 4AE2E281
	v_dot2acc_f32_f16 v97, v25, v19                            // 000000547628: 04C22719
	v_dual_dot2acc_f32_f16 v99, v25, v3 :: v_dual_dot2acc_f32_f16 v86, v120, v32// 00000054762C: CB180719 63564178
	v_dual_dot2acc_f32_f16 v98, v21, v12 :: v_dual_add_nc_u32 v1, v112, v113// 000000547634: CB201915 6200E370
	v_dot2acc_f32_f16 v100, v21, v8                            // 00000054763C: 04C81115
	v_dot2acc_f32_f16 v94, v21, v32                            // 000000547640: 04BC4115
	v_dot2acc_f32_f16 v95, v21, v24                            // 000000547644: 04BE3115
	v_dot2acc_f32_f16 v96, v21, v28                            // 000000547648: 04C03915
	v_cmp_eq_u32_e32 vcc_lo, 1, v1                             // 00000054764C: 7C940281
	v_dot2acc_f32_f16 v97, v21, v20                            // 000000547650: 04C22915
	v_dot2acc_f32_f16 v99, v21, v4                             // 000000547654: 04C60915
	v_dot2acc_f32_f16 v40, v21, v16                            // 000000547658: 04502115
	s_or_b32 s4, vcc_lo, s4                                    // 00000054765C: 8C04046A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000547660: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000547664: 917E047E
	s_cbranch_execz 34                                         // 000000547668: BFA50022 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1ef4>
	s_mov_b32 s0, exec_lo                                      // 00000054766C: BE80007E
	s_waitcnt vmcnt(6)                                         // 000000547670: BF891BF7
	ds_store_2addr_b32 v114, v102, v103 offset1:32             // 000000547674: D8382000 00676672
	s_waitcnt vmcnt(4)                                         // 00000054767C: BF8913F7
	ds_store_2addr_b32 v114, v104, v105 offset0:64 offset1:96  // 000000547680: D8386040 00696872
	s_waitcnt vmcnt(2)                                         // 000000547688: BF890BF7
	ds_store_2addr_b32 v114, v106, v107 offset0:128 offset1:160// 00000054768C: D838A080 006B6A72
	s_waitcnt vmcnt(0)                                         // 000000547694: BF8903F7
	ds_store_2addr_b32 v114, v108, v109 offset0:192 offset1:224// 000000547698: D838E0C0 006D6C72
	.long 0xd4c1007e                                           // 0000005476A0: D4C1007E
	v_cndmask_b32_e32 v1, v113, v101, vcc_lo                   // 0000005476A4: 0202CB71
	s_cbranch_execz 64376                                      // 0000005476A8: BFA5FB78 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xc8c>
	s_clause 0x7                                               // 0000005476AC: BF850007
	global_load_b32 v102, v[33:34], off                        // 0000005476B0: DC520000 667C0021
	global_load_b32 v103, v[33:34], off offset:128             // 0000005476B8: DC520080 677C0021
	global_load_b32 v104, v[33:34], off offset:256             // 0000005476C0: DC520100 687C0021
	global_load_b32 v105, v[33:34], off offset:384             // 0000005476C8: DC520180 697C0021
	global_load_b32 v106, v[33:34], off offset:512             // 0000005476D0: DC520200 6A7C0021
	global_load_b32 v107, v[33:34], off offset:640             // 0000005476D8: DC520280 6B7C0021
	global_load_b32 v108, v[33:34], off offset:768             // 0000005476E0: DC520300 6C7C0021
	global_load_b32 v109, v[33:34], off offset:896             // 0000005476E8: DC520380 6D7C0021
	s_branch 64358                                             // 0000005476F0: BFA0FB66 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xc8c>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000005476F4: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000005476F8: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 0000005476FC: 8C7E017E
	v_dual_mov_b32 v1, v37 :: v_dual_mov_b32 v2, v39           // 000000547700: CA100125 01020127
	v_dual_mov_b32 v3, v38 :: v_dual_mov_b32 v4, v41           // 000000547708: CA100126 03040129
	v_dual_mov_b32 v5, v42 :: v_dual_mov_b32 v6, v43           // 000000547710: CA10012A 0506012B
	v_dual_mov_b32 v7, v44 :: v_dual_mov_b32 v8, v45           // 000000547718: CA10012C 0708012D
	v_dual_mov_b32 v9, v46 :: v_dual_mov_b32 v10, v47          // 000000547720: CA10012E 090A012F
	v_dual_mov_b32 v11, v48 :: v_dual_mov_b32 v12, v49         // 000000547728: CA100130 0B0C0131
	v_dual_mov_b32 v13, v50 :: v_dual_mov_b32 v14, v51         // 000000547730: CA100132 0D0E0133
	v_dual_mov_b32 v15, v52 :: v_dual_mov_b32 v16, v53         // 000000547738: CA100134 0F100135
	v_dual_mov_b32 v17, v54 :: v_dual_mov_b32 v18, v55         // 000000547740: CA100136 11120137
	v_dual_mov_b32 v19, v56 :: v_dual_mov_b32 v20, v57         // 000000547748: CA100138 13140139
	v_dual_mov_b32 v21, v58 :: v_dual_mov_b32 v22, v59         // 000000547750: CA10013A 1516013B
	v_dual_mov_b32 v23, v60 :: v_dual_mov_b32 v24, v61         // 000000547758: CA10013C 1718013D
	v_dual_mov_b32 v25, v62 :: v_dual_mov_b32 v26, v63         // 000000547760: CA10013E 191A013F
	v_dual_mov_b32 v27, v64 :: v_dual_mov_b32 v28, v65         // 000000547768: CA100140 1B1C0141
	v_dual_mov_b32 v29, v66 :: v_dual_mov_b32 v30, v67         // 000000547770: CA100142 1D1E0143
	v_dual_mov_b32 v31, v68 :: v_dual_mov_b32 v32, v69         // 000000547778: CA100144 1F200145
	v_dual_mov_b32 v33, v70 :: v_dual_mov_b32 v34, v71         // 000000547780: CA100146 21220147
	s_waitcnt vmcnt(7)                                         // 000000547788: BF891FF7
	v_dual_mov_b32 v101, v72 :: v_dual_mov_b32 v102, v73       // 00000054778C: CA100148 65660149
	s_waitcnt vmcnt(5)                                         // 000000547794: BF8917F7
	v_dual_mov_b32 v103, v74 :: v_dual_mov_b32 v104, v75       // 000000547798: CA10014A 6768014B
	s_waitcnt vmcnt(3)                                         // 0000005477A0: BF890FF7
	v_dual_mov_b32 v105, v76 :: v_dual_mov_b32 v106, v77       // 0000005477A4: CA10014C 696A014D
	s_waitcnt vmcnt(1)                                         // 0000005477AC: BF8907F7
	v_dual_mov_b32 v107, v78 :: v_dual_mov_b32 v108, v79       // 0000005477B0: CA10014E 6B6C014F
	s_waitcnt vmcnt(0)                                         // 0000005477B8: BF8903F7
	v_dual_mov_b32 v109, v80 :: v_dual_mov_b32 v110, v81       // 0000005477BC: CA100150 6D6E0151
	v_dual_mov_b32 v111, v82 :: v_dual_mov_b32 v112, v83       // 0000005477C4: CA100152 6F700153
	v_dual_mov_b32 v113, v84 :: v_dual_mov_b32 v114, v85       // 0000005477CC: CA100154 71720155
	v_dual_mov_b32 v115, v86 :: v_dual_mov_b32 v116, v87       // 0000005477D4: CA100156 73740157
	v_dual_mov_b32 v117, v88 :: v_dual_mov_b32 v118, v89       // 0000005477DC: CA100158 75760159
	v_dual_mov_b32 v119, v90 :: v_dual_mov_b32 v120, v91       // 0000005477E4: CA10015A 7778015B
	v_dual_mov_b32 v121, v92 :: v_dual_mov_b32 v122, v93       // 0000005477EC: CA10015C 797A015D
	v_dual_mov_b32 v123, v94 :: v_dual_mov_b32 v124, v95       // 0000005477F4: CA10015E 7B7C015F
	v_dual_mov_b32 v125, v96 :: v_dual_mov_b32 v126, v97       // 0000005477FC: CA100160 7D7E0161
	v_dual_mov_b32 v127, v98 :: v_dual_mov_b32 v128, v99       // 000000547804: CA100162 7F800163
	v_mov_b32_e32 v129, v100                                   // 00000054780C: 7F020364
	v_mov_b32_e32 v130, v40                                    // 000000547810: 7F040328
	s_mov_b32 s0, 0x76543210                                   // 000000547814: BE8000FF 76543210
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000054781C: BF870009
	v_permlanex16_b32 v1, v1, s0, 0xfedcba98                   // 000000547820: D65C0001 03FC0101 FEDCBA98
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 00000054782C: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 000000547838: D65C0003 03FC0103 FEDCBA98
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 000000547844: D65C0004 03FC0104 FEDCBA98
	v_permlanex16_b32 v5, v5, s0, 0xfedcba98                   // 000000547850: D65C0005 03FC0105 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 00000054785C: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v7, v7, s0, 0xfedcba98                   // 000000547868: D65C0007 03FC0107 FEDCBA98
	v_permlanex16_b32 v8, v8, s0, 0xfedcba98                   // 000000547874: D65C0008 03FC0108 FEDCBA98
	v_permlanex16_b32 v9, v9, s0, 0xfedcba98                   // 000000547880: D65C0009 03FC0109 FEDCBA98
	v_permlanex16_b32 v10, v10, s0, 0xfedcba98                 // 00000054788C: D65C000A 03FC010A FEDCBA98
	v_permlanex16_b32 v11, v11, s0, 0xfedcba98                 // 000000547898: D65C000B 03FC010B FEDCBA98
	v_permlanex16_b32 v12, v12, s0, 0xfedcba98                 // 0000005478A4: D65C000C 03FC010C FEDCBA98
	v_permlanex16_b32 v13, v13, s0, 0xfedcba98                 // 0000005478B0: D65C000D 03FC010D FEDCBA98
	v_permlanex16_b32 v14, v14, s0, 0xfedcba98                 // 0000005478BC: D65C000E 03FC010E FEDCBA98
	v_permlanex16_b32 v15, v15, s0, 0xfedcba98                 // 0000005478C8: D65C000F 03FC010F FEDCBA98
	v_permlanex16_b32 v16, v16, s0, 0xfedcba98                 // 0000005478D4: D65C0010 03FC0110 FEDCBA98
	v_permlanex16_b32 v17, v17, s0, 0xfedcba98                 // 0000005478E0: D65C0011 03FC0111 FEDCBA98
	v_permlanex16_b32 v18, v18, s0, 0xfedcba98                 // 0000005478EC: D65C0012 03FC0112 FEDCBA98
	v_permlanex16_b32 v19, v19, s0, 0xfedcba98                 // 0000005478F8: D65C0013 03FC0113 FEDCBA98
	v_permlanex16_b32 v20, v20, s0, 0xfedcba98                 // 000000547904: D65C0014 03FC0114 FEDCBA98
	v_permlanex16_b32 v21, v21, s0, 0xfedcba98                 // 000000547910: D65C0015 03FC0115 FEDCBA98
	v_permlanex16_b32 v22, v22, s0, 0xfedcba98                 // 00000054791C: D65C0016 03FC0116 FEDCBA98
	v_permlanex16_b32 v23, v23, s0, 0xfedcba98                 // 000000547928: D65C0017 03FC0117 FEDCBA98
	v_permlanex16_b32 v24, v24, s0, 0xfedcba98                 // 000000547934: D65C0018 03FC0118 FEDCBA98
	v_permlanex16_b32 v25, v25, s0, 0xfedcba98                 // 000000547940: D65C0019 03FC0119 FEDCBA98
	v_permlanex16_b32 v26, v26, s0, 0xfedcba98                 // 00000054794C: D65C001A 03FC011A FEDCBA98
	v_permlanex16_b32 v27, v27, s0, 0xfedcba98                 // 000000547958: D65C001B 03FC011B FEDCBA98
	v_permlanex16_b32 v28, v28, s0, 0xfedcba98                 // 000000547964: D65C001C 03FC011C FEDCBA98
	v_permlanex16_b32 v29, v29, s0, 0xfedcba98                 // 000000547970: D65C001D 03FC011D FEDCBA98
	v_permlanex16_b32 v30, v30, s0, 0xfedcba98                 // 00000054797C: D65C001E 03FC011E FEDCBA98
	v_permlanex16_b32 v31, v31, s0, 0xfedcba98                 // 000000547988: D65C001F 03FC011F FEDCBA98
	v_permlanex16_b32 v32, v32, s0, 0xfedcba98                 // 000000547994: D65C0020 03FC0120 FEDCBA98
	v_permlanex16_b32 v33, v33, s0, 0xfedcba98                 // 0000005479A0: D65C0021 03FC0121 FEDCBA98
	v_permlanex16_b32 v34, v34, s0, 0xfedcba98                 // 0000005479AC: D65C0022 03FC0122 FEDCBA98
	v_permlanex16_b32 v101, v101, s0, 0xfedcba98               // 0000005479B8: D65C0065 03FC0165 FEDCBA98
	v_permlanex16_b32 v102, v102, s0, 0xfedcba98               // 0000005479C4: D65C0066 03FC0166 FEDCBA98
	v_permlanex16_b32 v103, v103, s0, 0xfedcba98               // 0000005479D0: D65C0067 03FC0167 FEDCBA98
	v_permlanex16_b32 v104, v104, s0, 0xfedcba98               // 0000005479DC: D65C0068 03FC0168 FEDCBA98
	v_permlanex16_b32 v105, v105, s0, 0xfedcba98               // 0000005479E8: D65C0069 03FC0169 FEDCBA98
	v_permlanex16_b32 v106, v106, s0, 0xfedcba98               // 0000005479F4: D65C006A 03FC016A FEDCBA98
	v_permlanex16_b32 v107, v107, s0, 0xfedcba98               // 000000547A00: D65C006B 03FC016B FEDCBA98
	v_permlanex16_b32 v108, v108, s0, 0xfedcba98               // 000000547A0C: D65C006C 03FC016C FEDCBA98
	v_permlanex16_b32 v109, v109, s0, 0xfedcba98               // 000000547A18: D65C006D 03FC016D FEDCBA98
	v_permlanex16_b32 v110, v110, s0, 0xfedcba98               // 000000547A24: D65C006E 03FC016E FEDCBA98
	v_permlanex16_b32 v111, v111, s0, 0xfedcba98               // 000000547A30: D65C006F 03FC016F FEDCBA98
	v_permlanex16_b32 v112, v112, s0, 0xfedcba98               // 000000547A3C: D65C0070 03FC0170 FEDCBA98
	v_permlanex16_b32 v113, v113, s0, 0xfedcba98               // 000000547A48: D65C0071 03FC0171 FEDCBA98
	v_permlanex16_b32 v114, v114, s0, 0xfedcba98               // 000000547A54: D65C0072 03FC0172 FEDCBA98
	v_permlanex16_b32 v115, v115, s0, 0xfedcba98               // 000000547A60: D65C0073 03FC0173 FEDCBA98
	v_permlanex16_b32 v116, v116, s0, 0xfedcba98               // 000000547A6C: D65C0074 03FC0174 FEDCBA98
	v_permlanex16_b32 v117, v117, s0, 0xfedcba98               // 000000547A78: D65C0075 03FC0175 FEDCBA98
	v_permlanex16_b32 v118, v118, s0, 0xfedcba98               // 000000547A84: D65C0076 03FC0176 FEDCBA98
	v_permlanex16_b32 v119, v119, s0, 0xfedcba98               // 000000547A90: D65C0077 03FC0177 FEDCBA98
	v_permlanex16_b32 v120, v120, s0, 0xfedcba98               // 000000547A9C: D65C0078 03FC0178 FEDCBA98
	v_permlanex16_b32 v121, v121, s0, 0xfedcba98               // 000000547AA8: D65C0079 03FC0179 FEDCBA98
	v_permlanex16_b32 v122, v122, s0, 0xfedcba98               // 000000547AB4: D65C007A 03FC017A FEDCBA98
	v_permlanex16_b32 v123, v123, s0, 0xfedcba98               // 000000547AC0: D65C007B 03FC017B FEDCBA98
	v_permlanex16_b32 v124, v124, s0, 0xfedcba98               // 000000547ACC: D65C007C 03FC017C FEDCBA98
	v_permlanex16_b32 v125, v125, s0, 0xfedcba98               // 000000547AD8: D65C007D 03FC017D FEDCBA98
	v_permlanex16_b32 v126, v126, s0, 0xfedcba98               // 000000547AE4: D65C007E 03FC017E FEDCBA98
	v_permlanex16_b32 v127, v127, s0, 0xfedcba98               // 000000547AF0: D65C007F 03FC017F FEDCBA98
	v_permlanex16_b32 v128, v128, s0, 0xfedcba98               // 000000547AFC: D65C0080 03FC0180 FEDCBA98
	v_permlanex16_b32 v129, v129, s0, 0xfedcba98               // 000000547B08: D65C0081 03FC0181 FEDCBA98
	v_permlanex16_b32 v130, v130, s0, 0xfedcba98               // 000000547B14: D65C0082 03FC0182 FEDCBA98
	.long 0xd44c0000                                           // 000000547B20: D44C0000
	v_cndmask_b32_e32 v1, 16, v36, vcc_lo                      // 000000547B24: 02024890
	s_barrier                                                  // 000000547B28: BFBD0000
	buffer_gl0_inv                                             // 000000547B2C: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 000000547B34: BE812000
	s_cbranch_execz 138                                        // 000000547B38: BFA5008A <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2564>
	v_dual_add_f32 v7, v44, v7 :: v_dual_lshlrev_b32 v36, 2, v36// 000000547B3C: C9220F2C 07244882
	v_dual_add_f32 v74, v74, v103 :: v_dual_add_f32 v1, v37, v1// 000000547B44: C908CF4A 4A000325
	v_dual_add_f32 v10, v47, v10 :: v_dual_add_f32 v9, v46, v9 // 000000547B4C: C908152F 0A08132E
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000547B54: BF870243
	v_lshl_or_b32 v36, v35, 12, v36                            // 000000547B58: D6560024 04911923
	v_add_f32_e32 v2, v39, v2                                  // 000000547B60: 06040527
	v_dual_add_f32 v72, v72, v101 :: v_dual_add_f32 v3, v38, v3// 000000547B64: C908CB48 48020726
	v_dual_add_f32 v12, v49, v12 :: v_dual_add_f32 v11, v48, v11// 000000547B6C: C9081931 0C0A1730
	v_dual_add_f32 v6, v43, v6 :: v_dual_add_nc_u32 v37, 0x400, v36// 000000547B74: C9200D2B 062448FF 00000400
	v_add_f32_e32 v4, v41, v4                                  // 000000547B80: 06080929
	v_dual_add_f32 v14, v51, v14 :: v_dual_add_f32 v13, v50, v13// 000000547B84: C9081D33 0E0C1B32
	v_dual_add_f32 v8, v45, v8 :: v_dual_add_f32 v5, v42, v5   // 000000547B8C: C908112D 08040B2A
	ds_store_2addr_b32 v36, v1, v9 offset1:16                  // 000000547B94: D8381000 00090124
	v_add_nc_u32_e32 v1, 0x800, v36                            // 000000547B9C: 4A0248FF 00000800
	v_dual_add_f32 v16, v53, v16 :: v_dual_add_f32 v15, v52, v15// 000000547BA4: C9082135 100E1F34
	ds_store_2addr_b32 v36, v2, v10 offset0:128 offset1:144    // 000000547BAC: D8389080 000A0224
	v_add_nc_u32_e32 v2, 0xc00, v36                            // 000000547BB4: 4A0448FF 00000C00
	v_dual_add_f32 v40, v40, v130 :: v_dual_add_f32 v99, v99, v128// 000000547BBC: C9090528 28630163
	v_dual_add_f32 v100, v100, v129 :: v_dual_add_f32 v97, v97, v126// 000000547BC4: C9090364 6460FD61
	v_dual_add_f32 v98, v98, v127 :: v_dual_add_f32 v95, v95, v124// 000000547BCC: C908FF62 625EF95F
	v_dual_add_f32 v96, v96, v125 :: v_dual_add_f32 v93, v93, v122// 000000547BD4: C908FB60 605CF55D
	v_dual_add_f32 v94, v94, v123 :: v_dual_add_f32 v91, v91, v120// 000000547BDC: C908F75E 5E5AF15B
	v_dual_add_f32 v92, v92, v121 :: v_dual_add_f32 v89, v89, v118// 000000547BE4: C908F35C 5C58ED59
	v_dual_add_f32 v90, v90, v119 :: v_dual_add_f32 v87, v87, v116// 000000547BEC: C908EF5A 5A56E957
	v_dual_add_f32 v88, v88, v117 :: v_dual_add_f32 v85, v85, v114// 000000547BF4: C908EB58 5854E555
	v_dual_add_f32 v86, v86, v115 :: v_dual_add_f32 v83, v83, v112// 000000547BFC: C908E756 5652E153
	v_dual_add_f32 v84, v84, v113 :: v_dual_add_f32 v81, v81, v110// 000000547C04: C908E354 5450DD51
	v_dual_add_f32 v82, v82, v111 :: v_dual_add_f32 v79, v79, v108// 000000547C0C: C908DF52 524ED94F
	v_dual_add_f32 v80, v80, v109 :: v_dual_add_f32 v77, v77, v106// 000000547C14: C908DB50 504CD54D
	v_dual_add_f32 v78, v78, v107 :: v_dual_add_f32 v75, v75, v104// 000000547C1C: C908D74E 4E4AD14B
	v_dual_add_f32 v76, v76, v105 :: v_dual_add_f32 v73, v73, v102// 000000547C24: C908D34C 4C48CD49
	v_dual_add_f32 v34, v71, v34 :: v_dual_add_f32 v33, v70, v33// 000000547C2C: C9084547 22204346
	v_dual_add_f32 v32, v69, v32 :: v_dual_add_f32 v31, v68, v31// 000000547C34: C9084145 201E3F44
	v_dual_add_f32 v30, v67, v30 :: v_dual_add_f32 v29, v66, v29// 000000547C3C: C9083D43 1E1C3B42
	v_dual_add_f32 v28, v65, v28 :: v_dual_add_f32 v27, v64, v27// 000000547C44: C9083941 1C1A3740
	v_dual_add_f32 v26, v63, v26 :: v_dual_add_f32 v25, v62, v25// 000000547C4C: C908353F 1A18333E
	v_dual_add_f32 v24, v61, v24 :: v_dual_add_f32 v23, v60, v23// 000000547C54: C908313D 18162F3C
	v_dual_add_f32 v22, v59, v22 :: v_dual_add_f32 v21, v58, v21// 000000547C5C: C9082D3B 16142B3A
	v_dual_add_f32 v20, v57, v20 :: v_dual_add_f32 v19, v56, v19// 000000547C64: C9082939 14122738
	v_dual_add_f32 v18, v55, v18 :: v_dual_add_f32 v17, v54, v17// 000000547C6C: C9082537 12102336
	ds_store_2addr_b32 v37, v3, v11 offset1:16                 // 000000547C74: D8381000 000B0325
	ds_store_2addr_b32 v37, v4, v12 offset0:128 offset1:144    // 000000547C7C: D8389080 000C0425
	ds_store_2addr_b32 v1, v5, v13 offset1:16                  // 000000547C84: D8381000 000D0501
	ds_store_2addr_b32 v1, v6, v14 offset0:128 offset1:144     // 000000547C8C: D8389080 000E0601
	ds_store_2addr_b32 v2, v7, v15 offset1:16                  // 000000547C94: D8381000 000F0702
	ds_store_2addr_b32 v2, v8, v16 offset0:128 offset1:144     // 000000547C9C: D8389080 00100802
	ds_store_2addr_b32 v36, v17, v25 offset0:32 offset1:48     // 000000547CA4: D8383020 00191124
	ds_store_2addr_b32 v36, v18, v26 offset0:160 offset1:176   // 000000547CAC: D838B0A0 001A1224
	ds_store_2addr_b32 v37, v19, v27 offset0:32 offset1:48     // 000000547CB4: D8383020 001B1325
	ds_store_2addr_b32 v37, v20, v28 offset0:160 offset1:176   // 000000547CBC: D838B0A0 001C1425
	ds_store_2addr_b32 v1, v21, v29 offset0:32 offset1:48      // 000000547CC4: D8383020 001D1501
	ds_store_2addr_b32 v1, v22, v30 offset0:160 offset1:176    // 000000547CCC: D838B0A0 001E1601
	ds_store_2addr_b32 v2, v23, v31 offset0:32 offset1:48      // 000000547CD4: D8383020 001F1702
	ds_store_2addr_b32 v2, v24, v32 offset0:160 offset1:176    // 000000547CDC: D838B0A0 00201802
	ds_store_2addr_b32 v36, v33, v78 offset0:64 offset1:80     // 000000547CE4: D8385040 004E2124
	ds_store_2addr_b32 v36, v34, v79 offset0:192 offset1:208   // 000000547CEC: D838D0C0 004F2224
	ds_store_2addr_b32 v37, v72, v80 offset0:64 offset1:80     // 000000547CF4: D8385040 00504825
	ds_store_2addr_b32 v37, v73, v81 offset0:192 offset1:208   // 000000547CFC: D838D0C0 00514925
	ds_store_2addr_b32 v1, v74, v82 offset0:64 offset1:80      // 000000547D04: D8385040 00524A01
	ds_store_2addr_b32 v1, v75, v83 offset0:192 offset1:208    // 000000547D0C: D838D0C0 00534B01
	ds_store_2addr_b32 v2, v76, v84 offset0:64 offset1:80      // 000000547D14: D8385040 00544C02
	ds_store_2addr_b32 v2, v77, v85 offset0:192 offset1:208    // 000000547D1C: D838D0C0 00554D02
	ds_store_2addr_b32 v36, v86, v94 offset0:96 offset1:112    // 000000547D24: D8387060 005E5624
	ds_store_2addr_b32 v36, v87, v95 offset0:224 offset1:240   // 000000547D2C: D838F0E0 005F5724
	ds_store_2addr_b32 v37, v88, v96 offset0:96 offset1:112    // 000000547D34: D8387060 00605825
	ds_store_2addr_b32 v37, v89, v97 offset0:224 offset1:240   // 000000547D3C: D838F0E0 00615925
	ds_store_2addr_b32 v1, v90, v98 offset0:96 offset1:112     // 000000547D44: D8387060 00625A01
	ds_store_2addr_b32 v1, v91, v99 offset0:224 offset1:240    // 000000547D4C: D838F0E0 00635B01
	ds_store_2addr_b32 v2, v92, v100 offset0:96 offset1:112    // 000000547D54: D8387060 00645C02
	ds_store_2addr_b32 v2, v93, v40 offset0:224 offset1:240    // 000000547D5C: D838F0E0 00285D02
	s_or_b32 exec_lo, exec_lo, s1                              // 000000547D64: 8C7E017E
	v_mov_b32_e32 v1, v0                                       // 000000547D68: 7E020300
	s_mov_b32 s1, 0                                            // 000000547D6C: BE810080
	s_waitcnt lgkmcnt(0)                                       // 000000547D70: BF89FC07
	s_barrier                                                  // 000000547D74: BFBD0000
	buffer_gl0_inv                                             // 000000547D78: E0AC0000 00000000
	v_lshlrev_b32_e32 v8, 2, v1                                // 000000547D80: 30100282
	v_cmp_lt_u32_e32 vcc_lo, 0x2ff, v1                         // 000000547D84: 7C9202FF 000002FF
	ds_load_2addr_stride64_b32 v[2:3], v8 offset1:16           // 000000547D8C: D8E01000 02000008
	ds_load_2addr_stride64_b32 v[4:5], v8 offset0:32 offset1:48// 000000547D94: D8E03020 04000008
	ds_load_2addr_stride64_b32 v[6:7], v8 offset0:64 offset1:80// 000000547D9C: D8E05040 06000008
	s_or_b32 s1, vcc_lo, s1                                    // 000000547DA4: 8C01016A
	s_waitcnt lgkmcnt(2)                                       // 000000547DA8: BF89FC27
	v_add_f32_e32 v2, 0, v2                                    // 000000547DAC: 06040480
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000547DB0: BF8700C1
	v_add_f32_e32 v9, v2, v3                                   // 000000547DB4: 06120702
	ds_load_2addr_stride64_b32 v[2:3], v8 offset0:96 offset1:112// 000000547DB8: D8E07060 02000008
	s_waitcnt lgkmcnt(2)                                       // 000000547DC0: BF89FC27
	v_add_f32_e32 v4, v9, v4                                   // 000000547DC4: 06080909
	v_add_f32_e32 v4, v4, v5                                   // 000000547DC8: 06080B04
	s_waitcnt lgkmcnt(1)                                       // 000000547DCC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000547DD0: BF870091
	v_add_f32_e32 v4, v4, v6                                   // 000000547DD4: 06080D04
	v_add_f32_e32 v4, v4, v7                                   // 000000547DD8: 06080F04
	s_waitcnt lgkmcnt(0)                                       // 000000547DDC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000547DE0: BF8700A1
	v_add_f32_e32 v2, v4, v2                                   // 000000547DE4: 06040504
	v_add_nc_u32_e32 v4, 0x100, v1                             // 000000547DE8: 4A0802FF 00000100
	v_dual_add_f32 v2, v2, v3 :: v_dual_mov_b32 v1, v4         // 000000547DF0: C9100702 02000104
	ds_store_b32 v8, v2 offset:32768                           // 000000547DF8: D8348000 00000208
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 000000547E00: 917E017E
	s_cbranch_execnz 65502                                     // 000000547E04: BFA6FFDE <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2580>
	s_or_b32 exec_lo, exec_lo, s1                              // 000000547E08: 8C7E017E
	s_cmp_lt_i32 s33, 2                                        // 000000547E0C: BF048221
	s_mov_b32 s1, -1                                           // 000000547E10: BE8100C1
	s_cbranch_scc1 197                                         // 000000547E14: BFA200C5 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x292c>
	v_dual_mov_b32 v4, v0 :: v_dual_and_b32 v1, 0x7f, v0       // 000000547E18: CA240100 040000FF 0000007F
	s_lshl_b32 s4, s2, 7                                       // 000000547E24: 84048702
	s_ashr_i32 s11, s10, 31                                    // 000000547E28: 860B9F0A
	s_ashr_i32 s5, s4, 31                                      // 000000547E2C: 86059F04
	s_delay_alu instid0(VALU_DEP_1)                            // 000000547E30: BF870001
	v_lshlrev_b32_e32 v2, 2, v1                                // 000000547E34: 30040282
	s_lshl_b64 s[4:5], s[4:5], 2                               // 000000547E38: 84848204
	s_lshl_b64 s[6:7], s[10:11], 3                             // 000000547E3C: 8486830A
	s_ashr_i32 s19, s18, 31                                    // 000000547E40: 86139F12
	s_add_u32 s1, s24, s4                                      // 000000547E44: 80010418
	s_addc_u32 s8, s25, s5                                     // 000000547E48: 82080519
	.long 0xd7000102                                           // 000000547E4C: D7000102
	v_cndmask_b32_e32 v1, s1, v2, vcc_lo                       // 000000547E50: 02020401
	s_delay_alu instid0(VALU_DEP_1)                            // 000000547E54: BF870001
	v_add_co_ci_u32_e64 v3, null, s8, 0, s1                    // 000000547E58: D5207C03 00050008
	s_mov_b32 s8, 0                                            // 000000547E60: BE880080
	s_waitcnt lgkmcnt(0)                                       // 000000547E64: BF89FC07
	s_barrier                                                  // 000000547E68: BFBD0000
	buffer_gl0_inv                                             // 000000547E6C: E0AC0000 00000000
	s_nop 0                                                    // 000000547E74: BF800000
	s_nop 0                                                    // 000000547E78: BF800000
	s_nop 0                                                    // 000000547E7C: BF800000
	v_lshrrev_b32_e32 v5, 7, v4                                // 000000547E80: 320A0887
	v_cmp_lt_u32_e32 vcc_lo, 0x2ff, v4                         // 000000547E84: 7C9208FF 000002FF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000547E8C: BF870092
	.long 0xd7000105                                           // 000000547E90: D7000105
	v_cndmask_b32_e32 v1, s6, v5, vcc_lo                       // 000000547E94: 02020A06
	v_add_co_ci_u32_e64 v6, null, s7, 0, s1                    // 000000547E98: D5207C06 00050007
	s_or_b32 s8, vcc_lo, s8                                    // 000000547EA0: 8C08086A
	.long 0xd72c0009                                           // 000000547EA4: D72C0009
	v_cndmask_b32_e32 v0, v5, v19, vcc_lo                      // 000000547EA8: 02002705
	.long 0xd72c0008                                           // 000000547EAC: D72C0008
	v_cndmask_b32_e32 v0, v6, v18, vcc_lo                      // 000000547EB0: 02002506
	v_mad_u64_u32 v[5:6], null, v5, s18, 0                     // 000000547EB4: D6FE7C05 02002505
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000547EBC: BF8701B1
	v_add3_u32 v6, v6, v9, v8                                  // 000000547EC0: D6550006 04221306
	v_add_nc_u32_e32 v8, 0x100, v4                             // 000000547EC8: 4A1008FF 00000100
	v_lshlrev_b32_e32 v7, 2, v4                                // 000000547ED0: 300E0882
	.long 0xd73c0005                                           // 000000547ED4: D73C0005
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 000000547ED8: 02020A82
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000547EDC: BF8700B3
	v_mov_b32_e32 v4, v8                                       // 000000547EE0: 7E080308
	ds_load_b32 v7, v7 offset:32768                            // 000000547EE4: D8D88000 07000007
	.long 0xd7000105                                           // 000000547EEC: D7000105
	v_cndmask_b32_e32 v1, v2, v5, vcc_lo                       // 000000547EF0: 02020B02
	v_add_co_ci_u32_e64 v6, null, v3, v6, s1                   // 000000547EF4: D5207C06 00060D03
	s_waitcnt lgkmcnt(0)                                       // 000000547EFC: BF89FC07
	global_store_b32 v[5:6], v7, off                           // 000000547F00: DC6A0000 007C0705
	s_and_not1_b32 exec_lo, exec_lo, s8                        // 000000547F08: 917E087E
	s_cbranch_execnz 65500                                     // 000000547F0C: BFA6FFDC <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2680>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000547F10: 8C7E087E
	.long 0xd44a0001                                           // 000000547F14: D44A0001
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 000000547F18: 02020080
	s_waitcnt_vscnt null, 0x0                                  // 000000547F1C: BC7C0000
	buffer_gl1_inv                                             // 000000547F20: E0B00000 00000000
	buffer_gl0_inv                                             // 000000547F28: E0AC0000 00000000
	s_barrier                                                  // 000000547F30: BFBD0000
	buffer_gl0_inv                                             // 000000547F34: E0AC0000 00000000
	s_and_saveexec_b32 s6, s1                                  // 000000547F3C: BE862001
	s_cbranch_execz 29                                         // 000000547F40: BFA5001D <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x27b8>
	s_mov_b32 s8, exec_lo                                      // 000000547F44: BE88007E
	s_mov_b32 s7, exec_lo                                      // 000000547F48: BE87007E
	.long 0xd71f0002                                           // 000000547F4C: D71F0002
	v_cndmask_b32_e32 v0, s8, v128, vcc_lo                     // 000000547F50: 02010008
	s_delay_alu instid0(VALU_DEP_1)                            // 000000547F54: BF870001
	v_cmpx_eq_u32_e32 0, v2                                    // 000000547F58: 7D940480
	s_cbranch_execz 9                                          // 000000547F5C: BFA50009 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2784>
	s_lshl_b64 s[10:11], s[2:3], 2                             // 000000547F60: 848A8202
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000547F64: BF8704B9
	s_add_u32 s10, s26, s10                                    // 000000547F68: 800A0A1A
	s_addc_u32 s11, s27, s11                                   // 000000547F6C: 820B0B1B
	s_bcnt1_i32_b32 s8, s8                                     // 000000547F70: BE881808
	v_dual_mov_b32 v3, 0 :: v_dual_mov_b32 v4, s8              // 000000547F74: CA100080 03040008
	global_atomic_add_u32 v3, v3, v4, s[10:11] glc             // 000000547F7C: DCD64000 030A0403
	s_or_b32 exec_lo, exec_lo, s7                              // 000000547F84: 8C7E077E
	s_waitcnt vmcnt(0)                                         // 000000547F88: BF8903F7
	v_readfirstlane_b32 s7, v3                                 // 000000547F8C: 7E0E0503
	s_delay_alu instid0(VALU_DEP_1)                            // 000000547F90: BF870001
	v_dual_mov_b32 v3, 0 :: v_dual_add_nc_u32 v2, s7, v2       // 000000547F94: CA200080 03020407
	s_add_i32 s7, s33, -1                                      // 000000547F9C: 8107C121
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000547FA0: BF870481
	v_cmp_eq_u32_e32 vcc_lo, s7, v2                            // 000000547FA4: 7C940407
	v_cndmask_b32_e64 v2, 0, 1, vcc_lo                         // 000000547FA8: D5010002 01A90280
	ds_store_b32 v3, v2 offset:49408                           // 000000547FB0: D834C100 00000203
	s_or_b32 exec_lo, exec_lo, s6                              // 000000547FB8: 8C7E067E
	v_mov_b32_e32 v2, 0                                        // 000000547FBC: 7E040280
	s_waitcnt lgkmcnt(0)                                       // 000000547FC0: BF89FC07
	s_barrier                                                  // 000000547FC4: BFBD0000
	buffer_gl0_inv                                             // 000000547FC8: E0AC0000 00000000
	s_mov_b32 s10, 0                                           // 000000547FD0: BE8A0080
	ds_load_b32 v2, v2 offset:49408                            // 000000547FD4: D8D8C100 02000002
	s_waitcnt lgkmcnt(0)                                       // 000000547FDC: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v2                             // 000000547FE0: 7C940480
	s_cbranch_vccnz 423                                        // 000000547FE4: BFA401A7 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2e84>
	v_lshrrev_b32_e32 v2, 7, v0                                // 000000547FE8: 32040087
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000547FEC: 30020282
	v_mov_b32_e32 v5, v0                                       // 000000547FF0: 7E0A0300
	s_lshl_b64 s[6:7], s[18:19], 3                             // 000000547FF4: 84868312
	s_lshl_b64 s[8:9], s[18:19], 5                             // 000000547FF8: 84888512
	v_mad_i64_i32 v[2:3], null, v2, s18, 0                     // 000000547FFC: D6FF7C02 02002502
	buffer_gl1_inv                                             // 000000548004: E0B00000 00000000
	buffer_gl0_inv                                             // 00000054800C: E0AC0000 00000000
	.long 0xd73c0002                                           // 000000548014: D73C0002
	v_cndmask_b32_e32 v1, 2, v2, vcc_lo                        // 000000548018: 02020482
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000054801C: BF870091
	.long 0xd7006a02                                           // 000000548020: D7006A02
	v_cndmask_b32_e32 v0, v2, v4, vcc_lo                       // 000000548024: 02000902
	v_add_co_ci_u32_e64 v3, null, s5, v3, vcc_lo               // 000000548028: D5207C03 01AA0605
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000548030: BF870092
	.long 0xd7006a01                                           // 000000548034: D7006A01
	v_cndmask_b32_e32 v1, v2, v1, vcc_lo                       // 000000548038: 02020302
	v_add_co_ci_u32_e64 v2, null, 0, v3, vcc_lo                // 00000054803C: D5207C02 01AA0680
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000548044: BF870092
	.long 0xd7006a01                                           // 000000548048: D7006A01
	v_cndmask_b32_e32 v1, s24, v1, vcc_lo                      // 00000054804C: 02020218
	v_add_co_ci_u32_e64 v2, null, s25, v2, vcc_lo              // 000000548050: D5207C02 01AA0419
	s_nop 0                                                    // 000000548058: BF800000
	s_nop 0                                                    // 00000054805C: BF800000
	s_nop 0                                                    // 000000548060: BF800000
	s_nop 0                                                    // 000000548064: BF800000
	s_nop 0                                                    // 000000548068: BF800000
	s_nop 0                                                    // 00000054806C: BF800000
	s_nop 0                                                    // 000000548070: BF800000
	s_nop 0                                                    // 000000548074: BF800000
	s_nop 0                                                    // 000000548078: BF800000
	s_nop 0                                                    // 00000054807C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000548080: BF870191
	v_mov_b32_e32 v4, v2                                       // 000000548084: 7E080302
	v_dual_mov_b32 v6, 0 :: v_dual_mov_b32 v3, v1              // 000000548088: CA100080 06020101
	s_mov_b32 s4, s33                                          // 000000548090: BE840021
	global_load_b32 v7, v[3:4], off glc                        // 000000548094: DC524000 077C0003
	.long 0xd7006a03                                           // 00000054809C: D7006A03
	v_cndmask_b32_e32 v0, v3, v8, vcc_lo                       // 0000005480A0: 02001103
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000005480A4: BF8704A1
	v_add_co_ci_u32_e64 v4, null, s9, v4, vcc_lo               // 0000005480A8: D5207C04 01AA0809
	s_add_i32 s4, s4, -1                                       // 0000005480B0: 8104C104
	s_cmp_eq_u32 s4, 0                                         // 0000005480B4: BF068004
	s_waitcnt vmcnt(0)                                         // 0000005480B8: BF8903F7
	v_add_f32_e32 v6, v6, v7                                   // 0000005480BC: 060C0F06
	s_cbranch_scc0 65524                                       // 0000005480C0: BFA1FFF4 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2894>
	v_add_nc_u32_e32 v4, 0x100, v5                             // 0000005480C4: 4A080AFF 00000100
	v_cmp_lt_u32_e32 vcc_lo, 0x2ff, v5                         // 0000005480CC: 7C920AFF 000002FF
	.long 0xd7000401                                           // 0000005480D4: D7000401
	v_cndmask_b32_e32 v0, v1, v6, vcc_lo                       // 0000005480D8: 02000D01
	v_lshlrev_b32_e32 v3, 2, v5                                // 0000005480DC: 30060A82
	v_add_co_ci_u32_e64 v2, null, s7, v2, s4                   // 0000005480E0: D5207C02 00120407
	v_mov_b32_e32 v5, v4                                       // 0000005480E8: 7E0A0304
	s_or_b32 s10, vcc_lo, s10                                  // 0000005480EC: 8C0A0A6A
	ds_store_b32 v3, v6 offset:32768                           // 0000005480F0: D8348000 00000603
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000005480F8: 917E0A7E
	s_cbranch_execnz 65504                                     // 0000005480FC: BFA6FFE0 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2880>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000548100: 8C7E0A7E
	s_and_saveexec_b32 s4, s1                                  // 000000548104: BE842001
	s_cbranch_execz 6                                          // 000000548108: BFA50006 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2924>
	s_lshl_b64 s[6:7], s[2:3], 2                               // 00000054810C: 84868202
	v_mov_b32_e32 v1, 0                                        // 000000548110: 7E020280
	s_add_u32 s6, s26, s6                                      // 000000548114: 8006061A
	s_addc_u32 s7, s27, s7                                     // 000000548118: 8207071B
	global_store_b32 v1, v1, s[6:7]                            // 00000054811C: DC6A0000 00060101
	s_or_b32 exec_lo, exec_lo, s4                              // 000000548124: 8C7E047E
	s_mov_b32 s1, -1                                           // 000000548128: BE8100C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000054812C: BF870009
	s_and_b32 vcc_lo, exec_lo, s1                              // 000000548130: 8B6A017E
	s_cbranch_vccz 339                                         // 000000548134: BFA30153 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2e84>
	v_cmp_gt_i32_e32 vcc_lo, s16, v35                          // 000000548138: 7C884610
	.long 0xd44c0001                                           // 00000054813C: D44C0001
	v_cndmask_b32_e32 v1, 0x100, v0, vcc_lo                    // 000000548140: 020200FF 00000100
	s_waitcnt lgkmcnt(0)                                       // 000000548148: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 00000054814C: BC7C0000
	s_barrier                                                  // 000000548150: BFBD0000
	buffer_gl0_inv                                             // 000000548154: E0AC0000 00000000
	s_and_b32 s1, vcc_lo, s1                                   // 00000054815C: 8B01016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000548160: BF870009
	s_and_saveexec_b32 s3, s1                                  // 000000548164: BE832001
	s_cbranch_execz 326                                        // 000000548168: BFA50146 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2e84>
	v_and_b32_e32 v1, 15, v0                                   // 00000054816C: 3602008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000548170: BF870091
	v_lshlrev_b32_e32 v2, 2, v1                                // 000000548174: 30040282
	v_lshl_or_b32 v2, v35, 9, v2                               // 000000548178: D6560002 04091323
	s_delay_alu instid0(VALU_DEP_1)                            // 000000548180: BF870001
	v_add_nc_u32_e32 v8, 0x8000, v2                            // 000000548184: 4A1004FF 00008000
	ds_load_2addr_b32 v[2:3], v8 offset1:16                    // 00000054818C: D8DC1000 02000008
	ds_load_2addr_b32 v[4:5], v8 offset0:32 offset1:48         // 000000548194: D8DC3020 04000008
	ds_load_2addr_b32 v[6:7], v8 offset0:64 offset1:80         // 00000054819C: D8DC5040 06000008
	ds_load_2addr_b32 v[8:9], v8 offset0:96 offset1:112        // 0000005481A4: D8DC7060 08000008
	v_and_b32_e32 v10, 1, v0                                   // 0000005481AC: 36140081
	s_waitcnt lgkmcnt(3)                                       // 0000005481B0: BF89FC37
	v_dual_add_f32 v12, v2, v3 :: v_dual_and_b32 v11, 2, v0    // 0000005481B4: C9240702 0C0A0082
	s_waitcnt lgkmcnt(2)                                       // 0000005481BC: BF89FC27
	v_dual_sub_f32 v2, v2, v3 :: v_dual_add_f32 v3, v4, v5     // 0000005481C0: C9480702 02020B04
	s_waitcnt lgkmcnt(1)                                       // 0000005481C8: BF89FC17
	v_dual_sub_f32 v4, v4, v5 :: v_dual_add_f32 v5, v6, v7     // 0000005481CC: C9480B04 04040F06
	s_waitcnt lgkmcnt(0)                                       // 0000005481D4: BF89FC07
	v_dual_sub_f32 v6, v6, v7 :: v_dual_sub_f32 v7, v8, v9     // 0000005481D8: C94A0F06 06061308
	v_dual_add_f32 v8, v8, v9 :: v_dual_and_b32 v9, 4, v0      // 0000005481E0: C9241308 08080084
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000005481E8: BF8701A3
	v_add_f32_e32 v13, v2, v4                                  // 0000005481EC: 061A0902
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 0000005481F0: 7C941480
	v_add_f32_e32 v16, v5, v8                                  // 0000005481F4: 06201105
	v_dual_sub_f32 v5, v5, v8 :: v_dual_add_f32 v14, v12, v3   // 0000005481F8: C9481105 050E070C
	v_add_f32_e32 v15, v6, v7                                  // 000000548200: 061E0F06
	v_dual_sub_f32 v3, v12, v3 :: v_dual_sub_f32 v2, v2, v4    // 000000548204: C94A070C 03020902
	v_sub_f32_e32 v4, v6, v7                                   // 00000054820C: 08080F06
	.long 0xd44a0001                                           // 000000548210: D44A0001
	v_cndmask_b32_e32 v1, 0, v9, vcc_lo                        // 000000548214: 02021280
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000548218: BF870214
	v_add_f32_e32 v6, v13, v15                                 // 00000054821C: 060C1F0D
	v_dual_sub_f32 v8, v13, v15 :: v_dual_add_f32 v13, v3, v5  // 000000548220: C9481F0D 080C0B03
	v_add_f32_e32 v7, v14, v16                                 // 000000548228: 060E210E
	v_dual_sub_f32 v3, v3, v5 :: v_dual_add_f32 v12, v2, v4    // 00000054822C: C9480B03 030C0902
	v_sub_f32_e32 v2, v2, v4                                   // 000000548234: 08040902
	v_mov_b32_dpp v5, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000548238: 7E0A02FA FF016106
	s_delay_alu instid0(VALU_DEP_4)                            // 000000548240: BF870004
	v_mov_b32_dpp v4, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000548244: 7E0802FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 00000054824C: D5010007 21AA0F07
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 000000548254: D5010006 21AA0D06
	v_mov_b32_dpp v18, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000054825C: 7E2402FA FF016103
	v_cndmask_b32_e64 v21, -v3, v3, vcc_lo                     // 000000548264: D5010015 21AA0703
	v_mov_b32_dpp v19, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000054826C: 7E2602FA FF016102
	v_add_f32_e32 v3, v7, v4                                   // 000000548274: 06060907
	v_mov_b32_dpp v15, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000548278: 7E1E02FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000548280: D5010008 21AA1108
	v_cndmask_b32_e64 v20, -v2, v2, vcc_lo                     // 000000548288: D5010014 21AA0502
	v_add_f32_e32 v2, v6, v5                                   // 000000548290: 06040B06
	v_mov_b32_dpp v6, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000548294: 7E0C02FA FF016203
	v_sub_f32_e32 v10, v14, v16                                // 00000054829C: 0814210E
	v_mov_b32_dpp v16, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000005482A0: 7E2002FA FF01610D
	v_mov_b32_dpp v17, v12 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000005482A8: 7E2202FA FF01610C
	v_cndmask_b32_e64 v12, -v12, v12, vcc_lo                   // 0000005482B0: D501000C 21AA190C
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 0000005482B8: D501000D 21AA1B0D
	v_mov_b32_dpp v14, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000005482C0: 7E1C02FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 0000005482C8: D501000A 21AA150A
	v_cmp_eq_u32_e32 vcc_lo, 0, v11                            // 0000005482D0: 7C941680
	v_add_f32_e32 v4, v8, v15                                  // 0000005482D4: 06081F08
	v_dual_add_f32 v7, v12, v17 :: v_dual_add_f32 v8, v13, v16 // 0000005482D8: C908230C 0708210D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000005482E0: BF870224
	v_add_f32_e32 v5, v10, v14                                 // 0000005482E4: 060A1D0A
	v_add_f32_e32 v13, v20, v19                                // 0000005482E8: 061A2714
	v_mov_b32_dpp v12, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000005482EC: 7E1802FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 0000005482F4: D5010004 21AA0904
	v_mov_b32_dpp v10, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000005482FC: 7E1402FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 000000548304: D5010002 21AA0502
	v_mov_b32_dpp v9, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000054830C: 7E1202FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000548314: D5010008 21AA1108
	v_add_f32_e32 v4, v4, v12                                  // 00000054831C: 06081904
	v_mov_b32_dpp v11, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000548320: 7E1602FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000548328: D5010005 21AA0B05
	v_mov_b32_dpp v15, v13 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000548330: 7E1E02FA FF01620D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 000000548338: D501000D 21AA1B0D
	v_mov_b32_dpp v12, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000548340: 7E1802FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000548348: D5010004 20060904
	v_dual_add_f32 v8, v8, v9 :: v_dual_add_f32 v11, v5, v11   // 000000548350: C9081308 080A1705
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000548358: D5010003 21AA0703
	v_mov_b32_dpp v14, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000548360: 7E1C02FA FF016207
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000548368: BF8701C4
	v_add_f32_e32 v4, v4, v12                                  // 00000054836C: 06081904
	v_add_f32_e32 v12, v21, v18                                // 000000548370: 06182515
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000548374: D5010007 21AA0F07
	v_add_f32_e32 v3, v3, v6                                   // 00000054837C: 06060D03
	v_mov_b32_dpp v9, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000548380: 7E1202FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, vcc_lo                   // 000000548388: D501000C 21AA190C
	v_add_f32_e32 v2, v2, v10                                  // 000000548390: 06041502
	v_add_f32_e32 v14, v7, v14                                 // 000000548394: 061C1D07
	v_mov_b32_dpp v6, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000548398: 7E0C02FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 0000005483A0: D5010003 20060703
	v_add_f32_e32 v9, v12, v9                                  // 0000005483A8: 0612130C
	v_cndmask_b32_e64 v10, -v2, v2, s1                         // 0000005483AC: D501000A 20060502
	v_mov_b32_dpp v2, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000005483B4: 7E0402FA FF016402
	v_mov_b32_dpp v12, v14 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000005483BC: 7E1802FA FF01640E
	v_add_f32_e32 v3, v3, v6                                   // 0000005483C4: 06060D03
	v_mov_b32_dpp v16, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000005483C8: 7E2002FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 0000005483D0: D5010009 20061309
	v_add_f32_e32 v5, v10, v2                                  // 0000005483D8: 060A050A
	v_mov_b32_dpp v10, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000005483DC: 7E1402FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 0000005483E4: D501000B 2006170B
	v_mov_b32_dpp v2, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000005483EC: 7E0402FA FF016803
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000005483F4: BF870194
	v_mov_b32_dpp v6, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000005483F8: 7E0C02FA FF016805
	v_add_f32_e32 v7, v11, v10                                 // 000000548400: 060E150B
	v_add_f32_e32 v11, v13, v15                                // 000000548404: 06161F0D
	v_mov_b32_dpp v10, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000548408: 7E1402FA FF016408
	v_cndmask_b32_e64 v13, -v14, v14, s1                       // 000000548410: D501000D 20061D0E
	v_cndmask_b32_e64 v14, -v8, v8, s1                         // 000000548418: D501000E 20061108
	v_mov_b32_dpp v8, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000548420: 7E1002FA FF016807
	v_mov_b32_dpp v18, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000548428: 7E2402FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 000000548430: D501000B 2006170B
	v_add_f32_e32 v17, v13, v12                                // 000000548438: 0622190D
	v_dual_add_f32 v15, v14, v10 :: v_dual_add_f32 v14, v9, v16// 00000054843C: C908150E 0F0E2109
	v_mov_b32_dpp v9, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000548444: 7E1202FA FF016804
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000054844C: BF870214
	v_add_f32_e32 v16, v11, v18                                // 000000548450: 0620250B
	v_mov_b32_dpp v13, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000548454: 7E1A02FA FF016811
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000054845C: BF870224
	v_mov_b32_dpp v11, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000548460: 7E1602FA FF01680F
	v_mov_b32_dpp v10, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000548468: 7E1402FA FF01680E
	v_mov_b32_dpp v12, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000548470: 7E1802FA FF016810
	s_and_b32 exec_lo, exec_lo, s0                             // 000000548478: 8B7E007E
	s_cbranch_execz 129                                        // 00000054847C: BFA50081 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2e84>
	v_lshl_or_b32 v18, s2, 7, v1                               // 000000548480: D6560012 04050E02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000548488: BF870091
	v_ashrrev_i32_e32 v19, 31, v18                             // 00000054848C: 3426249F
	.long 0xd73c0014                                           // 000000548490: D73C0014
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 000000548494: 02022481
	.long 0xd73c0012                                           // 000000548498: D73C0012
	v_cndmask_b32_e32 v1, 2, v18, vcc_lo                       // 00000054849C: 02022482
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005484A0: BF870092
	.long 0xd7006a14                                           // 0000005484A4: D7006A14
	v_cndmask_b32_e32 v1, s22, v20, vcc_lo                     // 0000005484A8: 02022816
	v_add_co_ci_u32_e64 v21, null, s23, v21, vcc_lo            // 0000005484AC: D5207C15 01AA2A17
	s_clause 0x7                                               // 0000005484B4: BF850007
	global_load_d16_b16 v22, v[20:21], off offset:32           // 0000005484B8: DC820020 167C0014
	global_load_d16_b16 v23, v[20:21], off                     // 0000005484C0: DC820000 177C0014
	global_load_d16_b16 v24, v[20:21], off offset:96           // 0000005484C8: DC820060 187C0014
	global_load_d16_b16 v25, v[20:21], off offset:64           // 0000005484D0: DC820040 197C0014
	global_load_d16_b16 v26, v[20:21], off offset:160          // 0000005484D8: DC8200A0 1A7C0014
	global_load_d16_b16 v27, v[20:21], off offset:128          // 0000005484E0: DC820080 1B7C0014
	global_load_d16_b16 v28, v[20:21], off offset:224          // 0000005484E8: DC8200E0 1C7C0014
	global_load_d16_b16 v20, v[20:21], off offset:192          // 0000005484F0: DC8200C0 147C0014
	v_and_b32_e32 v21, 8, v0                                   // 0000005484F8: 362A0088
	v_mad_i64_i32 v[0:1], null, s18, v35, 0                    // 0000005484FC: D6FF7C00 02024612
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000548504: BF870112
	v_cmp_eq_u32_e32 vcc_lo, 0, v21                            // 000000548508: 7C942A80
	.long 0xd73c0000                                           // 00000054850C: D73C0000
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 000000548510: 02020082
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000548514: D5010005 21AA0B05
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 00000054851C: D5010003 21AA0703
	v_cndmask_b32_e64 v15, -v15, v15, vcc_lo                   // 000000548524: D501000F 21AA1F0F
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 00000054852C: D5010004 21AA0904
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000548534: D5010007 21AA0F07
	v_add_f32_e32 v5, v5, v6                                   // 00000054853C: 060A0D05
	v_cndmask_b32_e64 v6, -v17, v17, vcc_lo                    // 000000548540: D5010006 21AA2311
	v_cndmask_b32_e64 v16, -v16, v16, vcc_lo                   // 000000548548: D5010010 21AA2110
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 000000548550: D501000E 21AA1D0E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000548558: BF870214
	v_dual_add_f32 v2, v3, v2 :: v_dual_mul_f32 v3, 0x3db504f3, v5// 00000054855C: C9060503 02020AFF 3DB504F3
	v_dual_add_f32 v5, v6, v13 :: v_dual_add_f32 v6, v15, v11  // 000000548568: C9081B06 0506170F
	.long 0xd7006a00                                           // 000000548570: D7006A00
	v_cndmask_b32_e32 v1, s28, v0, vcc_lo                      // 000000548574: 0202001C
	v_dual_add_f32 v4, v4, v9 :: v_dual_add_f32 v7, v7, v8     // 000000548578: C9081304 04061107
	v_add_co_ci_u32_e64 v1, null, s29, v1, vcc_lo              // 000000548580: D5207C01 01AA021D
	v_dual_add_f32 v8, v16, v12 :: v_dual_add_f32 v9, v14, v10 // 000000548588: C9081910 0808150E
	s_delay_alu instid0(VALU_DEP_3)                            // 000000548590: BF870003
	v_mul_f32_e32 v4, 0x3db504f3, v4                           // 000000548594: 100808FF 3DB504F3
	v_mul_f32_e32 v2, 0x3db504f3, v2                           // 00000054859C: 100404FF 3DB504F3
	v_dual_mul_f32 v6, 0x3db504f3, v6 :: v_dual_mul_f32 v5, 0x3db504f3, v5// 0000005485A4: C8C60CFF 06040AFF 3DB504F3
	.long 0xd7006a00                                           // 0000005485B0: D7006A00
	v_cndmask_b32_e32 v1, v0, v18, vcc_lo                      // 0000005485B4: 02022500
	v_dual_mul_f32 v7, 0x3db504f3, v7 :: v_dual_mul_f32 v8, 0x3db504f3, v8// 0000005485B8: C8C60EFF 070810FF 3DB504F3
	v_add_co_ci_u32_e64 v1, null, v1, v19, vcc_lo              // 0000005485C4: D5207C01 01AA2701
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 0000005485CC: 101212FF 3DB504F3
	s_waitcnt vmcnt(7)                                         // 0000005485D4: BF891FF7
	v_fma_mix_f32 v3, v22, v3, neg(0) op_sel_hi:[1,0,0]        // 0000005485D8: CC200003 8A020716
	s_waitcnt vmcnt(6)                                         // 0000005485E0: BF891BF7
	v_fma_mix_f32 v2, v23, v2, neg(0) op_sel_hi:[1,0,0]        // 0000005485E4: CC200002 8A020517
	s_waitcnt vmcnt(5)                                         // 0000005485EC: BF8917F7
	v_fma_mix_f32 v5, v24, v5, neg(0) op_sel_hi:[1,0,0]        // 0000005485F0: CC200005 8A020B18
	s_waitcnt vmcnt(4)                                         // 0000005485F8: BF8913F7
	v_fma_mix_f32 v6, v25, v6, neg(0) op_sel_hi:[1,0,0]        // 0000005485FC: CC200006 8A020D19
	s_waitcnt vmcnt(3)                                         // 000000548604: BF890FF7
	v_fma_mix_f32 v4, v26, v4, neg(0) op_sel_hi:[1,0,0]        // 000000548608: CC200004 8A02091A
	s_waitcnt vmcnt(2)                                         // 000000548610: BF890BF7
	v_fma_mix_f32 v7, v27, v7, neg(0) op_sel_hi:[1,0,0]        // 000000548614: CC200007 8A020F1B
	s_waitcnt vmcnt(1)                                         // 00000054861C: BF8907F7
	v_fma_mix_f32 v8, v28, v8, neg(0) op_sel_hi:[1,0,0]        // 000000548620: CC200008 8A02111C
	s_waitcnt vmcnt(0)                                         // 000000548628: BF8903F7
	v_fma_mix_f32 v9, v20, v9, neg(0) op_sel_hi:[1,0,0]        // 00000054862C: CC200009 8A021314
	s_clause 0x7                                               // 000000548634: BF850007
	global_store_b32 v[0:1], v2, off                           // 000000548638: DC6A0000 007C0200
	global_store_b32 v[0:1], v3, off offset:64                 // 000000548640: DC6A0040 007C0300
	global_store_b32 v[0:1], v6, off offset:128                // 000000548648: DC6A0080 007C0600
	global_store_b32 v[0:1], v5, off offset:192                // 000000548650: DC6A00C0 007C0500
	global_store_b32 v[0:1], v7, off offset:256                // 000000548658: DC6A0100 007C0700
	global_store_b32 v[0:1], v4, off offset:320                // 000000548660: DC6A0140 007C0400
	global_store_b32 v[0:1], v9, off offset:384                // 000000548668: DC6A0180 007C0900
	global_store_b32 v[0:1], v8, off offset:448                // 000000548670: DC6A01C0 007C0800
	s_nop 0                                                    // 000000548678: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 00000054867C: BFB60003
	s_endpgm                                                   // 000000548680: BFB00000
	s_nop 0                                                    // 000000548684: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000548688: BFB60003
	s_endpgm                                                   // 00000054868C: BFB00000
		...

