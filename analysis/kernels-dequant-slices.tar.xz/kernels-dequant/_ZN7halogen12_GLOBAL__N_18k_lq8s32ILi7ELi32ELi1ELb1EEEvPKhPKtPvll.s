0000000000734300 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi7ELi32ELi1ELb1EEEvPKhPKtPvll>:
; _ZN7halogen12_GLOBAL__N_18k_lq8s32ILi7ELi32ELi1ELb1EEEvPKhPKtPvll():
	s_clause 0x1                                               // 000000734300: BF850001
	s_load_b256 s[4:11], s[0:1], null                          // 000000734304: F40C0100 F8000000
	s_load_b64 s[12:13], s[0:1], 0x20                          // 00000073430C: F4040300 F8000020
	v_lshrrev_b32_e32 v1, 5, v0                                // 000000734314: 32020085
	s_mov_b32 s3, 0                                            // 000000734318: BE830080
	v_dual_mov_b32 v16, 0 :: v_dual_and_b32 v15, 31, v0        // 00000073431C: CA240080 100E009F
	s_lshl_b64 s[0:1], s[2:3], 3                               // 000000734324: 84808302
	.long 0x7e363880                                           // 000000734328: 7E363880
	v_or_b32_e32 v9, s0, v1                                    // 00000073432C: 38120200
	v_mov_b32_e32 v10, s1                                      // 000000734330: 7E140201
	v_dual_mov_b32 v4, 0 :: v_dual_mov_b32 v5, 0               // 000000734334: CA100080 04040080
	v_dual_mov_b32 v6, 0 :: v_dual_lshlrev_b32 v11, 4, v15     // 00000073433C: CA220080 060A1E84
	s_waitcnt lgkmcnt(0)                                       // 000000734344: BF89FC07
	s_ashr_i32 s0, s11, 31                                     // 000000734348: 86009F0B
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[9:10]                 // 00000073434C: 7CA8120C
	s_lshr_b32 s0, s0, 28                                      // 000000734350: 85009C00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000734354: BF8704A9
	s_add_u32 s2, s10, s0                                      // 000000734358: 8002000A
	s_addc_u32 s3, s11, 0                                      // 00000073435C: 8203800B
	s_ashr_i64 s[2:3], s[2:3], 4                               // 000000734360: 86828402
	v_cndmask_b32_e32 v1, 0, v9, vcc_lo                        // 000000734364: 02021280
	s_add_u32 s0, s10, s2                                      // 000000734368: 8000020A
	v_cndmask_b32_e64 v2, 0, s1, vcc_lo                        // 00000073436C: D5010002 01A80280
	s_addc_u32 s1, s11, s3                                     // 000000734374: 8201030B
	s_add_u32 s0, s0, 15                                       // 000000734378: 80008F00
	s_addc_u32 s1, s1, 0                                       // 00000073437C: 82018001
	s_and_b32 s0, s0, -16                                      // 000000734380: 8B00D000
	.long 0xd72c0003                                           // 000000734384: D72C0003
	v_cndmask_b32_e32 v0, v1, v1, vcc_lo                       // 000000734388: 02000301
	.long 0xd72c0007                                           // 00000073438C: D72C0007
	v_cndmask_b32_e32 v0, v2, v0, vcc_lo                       // 000000734390: 02000102
	v_mad_u64_u32 v[1:2], null, v1, s0, 0                      // 000000734394: D6FE7C01 02000101
	.long 0xd4440000                                           // 00000073439C: D4440000
	v_cndmask_b32_e32 v1, s2, v15, vcc_lo                      // 0000007343A0: 02021E02
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007343A4: BF870192
	v_add3_u32 v2, v2, v3, v7                                  // 0000007343A8: D6550002 041E0702
	.long 0xd7000111                                           // 0000007343B0: D7000111
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 0000007343B4: 02020204
	v_mov_b32_e32 v7, 0                                        // 0000007343B8: 7E0E0280
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007343BC: BF870003
	v_add_co_ci_u32_e64 v18, null, s5, v2, s1                  // 0000007343C0: D5207C12 00060405
	s_and_saveexec_b32 s3, s0                                  // 0000007343C8: BE832000
	s_cbranch_execz 21                                         // 0000007343CC: BFA50015 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi7ELi32ELi1ELb1EEEvPKhPKtPvll+0x124>
	v_lshlrev_b32_e32 v3, 4, v15                               // 0000007343D0: 30061E84
	.long 0xd7000105                                           // 0000007343D4: D7000105
	v_cndmask_b32_e32 v0, v17, v10, vcc_lo                     // 0000007343D8: 02001511
	v_and_b32_e32 v7, 30, v0                                   // 0000007343DC: 360E009E
	v_add_co_ci_u32_e64 v6, null, s11, v18, s1                 // 0000007343E0: D5207C06 0006240B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007343E8: BF870094
	.long 0xd7000103                                           // 0000007343EC: D7000103
	v_cndmask_b32_e32 v1, v17, v3, vcc_lo                      // 0000007343F0: 02020711
	v_add_co_ci_u32_e64 v4, null, 0, v18, s1                   // 0000007343F4: D5207C04 00062480
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007343FC: BF870094
	.long 0xd700010c                                           // 000000734400: D700010C
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 000000734404: 02020F05
	v_add_co_ci_u32_e64 v13, null, 0, v6, s1                   // 000000734408: D5207C0D 00060C80
	s_clause 0x1                                               // 000000734410: BF850001
	global_load_b128 v[4:7], v[3:4], off                       // 000000734414: DC5E0000 047C0003
	global_load_d16_b16 v27, v[12:13], off                     // 00000073441C: DC820000 1B7C000C
	s_or_b32 exec_lo, exec_lo, s3                              // 000000734424: 8C7E037E
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v20, 0             // 000000734428: CA100080 13140080
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v22, 0             // 000000734430: CA100080 15160080
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v24, 0             // 000000734438: CA100080 17180080
	s_and_saveexec_b32 s3, s0                                  // 000000734440: BE832000
	s_cbranch_execz 539                                        // 000000734444: BFA5021B <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi7ELi32ELi1ELb1EEEvPKhPKtPvll+0x9b4>
	v_and_or_b32 v0, v0, 30, 32                                // 000000734448: D6570000 02813D00
	.long 0xd7000001                                           // 000000734450: D7000001
	v_cndmask_b32_e32 v1, s10, v1, vcc_lo                      // 000000734454: 0202020A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000734458: BF8701A1
	v_add_co_ci_u32_e64 v2, null, s11, v2, s0                  // 00000073445C: D5207C02 0002040B
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v25, v15           // 000000734464: CA100080 0C18010F
	.long 0xd7000000                                           // 00000073446C: D7000000
	v_cndmask_b32_e32 v1, v1, v0, vcc_lo                       // 000000734470: 02020101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000734474: BF870191
	v_add_co_ci_u32_e64 v1, null, 0, v2, s0                    // 000000734478: D5207C01 00020480
	v_mov_b32_e32 v24, v12                                     // 000000734480: 7E30030C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000734484: BF870093
	.long 0xd700000d                                           // 000000734488: D700000D
	v_cndmask_b32_e32 v1, s4, v0, vcc_lo                       // 00000073448C: 02020004
	v_add_co_ci_u32_e64 v14, null, s5, v1, s0                  // 000000734490: D5207C0E 00020205
	v_mov_b32_e32 v23, v12                                     // 000000734498: 7E2E030C
	v_mov_b32_e32 v22, v12                                     // 00000073449C: 7E2C030C
	v_mov_b32_e32 v21, v12                                     // 0000007344A0: 7E2A030C
	v_mov_b32_e32 v20, v12                                     // 0000007344A4: 7E28030C
	v_mov_b32_e32 v19, v12                                     // 0000007344A8: 7E26030C
	v_mov_b32_e32 v16, v12                                     // 0000007344AC: 7E20030C
	s_mul_i32 s1, s11, 6                                       // 0000007344B0: 9601860B
	s_mul_hi_u32 s16, s10, 6                                   // 0000007344B4: 9690860A
	s_lshl_b64 s[14:15], s[10:11], 2                           // 0000007344B8: 848E820A
	s_add_i32 s16, s16, s1                                     // 0000007344BC: 81100110
	s_mul_i32 s18, s10, 6                                      // 0000007344C0: 9612860A
	s_mov_b32 s17, 0                                           // 0000007344C4: BE910080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 0000007344C8: 8484810A
	s_branch 475                                               // 0000007344CC: BFA001DB <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi7ELi32ELi1ELb1EEEvPKhPKtPvll+0x93c>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000007344D0: 8C7E0A7E
	v_bfe_i32 v28, v4, 0, 8                                    // 0000007344D4: D611001C 02210104
	s_and_b32 s0, exec_lo, s0                                  // 0000007344DC: 8B00007E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007344E0: BF870099
	s_or_b32 s17, s0, s17                                      // 0000007344E4: 8C111100
	v_cvt_f32_i32_e32 v28, v28                                 // 0000007344E8: 7E380B1C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007344EC: BF870091
	v_fma_mix_f32 v28, v27, v28, neg(0) op_sel_hi:[1,0,0]      // 0000007344F0: CC20001C 8A02391B
	v_bfe_u32 v29, v28, 16, 1                                  // 0000007344F8: D610001D 0205211C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000734500: BF870121
	v_add3_u32 v28, v28, v29, 0x7fff                           // 000000734504: D655001C 03FE3B1C 00007FFF
	.long 0x7f3a3880                                           // 000000734510: 7F3A3880
	.long 0x7e3a399c                                           // 000000734514: 7E3A399C
	v_bfe_i32 v28, v4, 8, 8                                    // 000000734518: D611001C 02211104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000734520: BF870091
	v_cvt_f32_i32_e32 v28, v28                                 // 000000734524: 7E380B1C
	v_fma_mix_f32 v28, v27, v28, neg(0) op_sel_hi:[1,0,0]      // 000000734528: CC20001C 8A02391B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000734530: BF870091
	v_bfe_u32 v30, v28, 16, 1                                  // 000000734534: D610001E 0205211C
	v_add3_u32 v28, v28, v30, 0x7fff                           // 00000073453C: D655001C 03FE3D1C 00007FFF
	v_bfe_i32 v30, v4, 16, 8                                   // 000000734548: D611001E 02212104
	v_ashrrev_i32_e32 v4, 24, v4                               // 000000734550: 34080898
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000734554: BF870193
	v_and_or_b32 v35, 0xffff0000, v28, v29                     // 000000734558: D6570023 047638FF FFFF0000
	v_cvt_f32_i32_e32 v30, v30                                 // 000000734564: 7E3C0B1E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000734568: BF870113
	v_cvt_f32_i32_e32 v4, v4                                   // 00000073456C: 7E080B04
	v_fma_mix_f32 v30, v27, v30, neg(0) op_sel_hi:[1,0,0]      // 000000734570: CC20001E 8A023D1B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000734578: BF870112
	v_fma_mix_f32 v4, v27, v4, neg(0) op_sel_hi:[1,0,0]        // 00000073457C: CC200004 8A02091B
	v_bfe_u32 v31, v30, 16, 1                                  // 000000734584: D610001F 0205211E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000073458C: BF870191
	v_add3_u32 v30, v30, v31, 0x7fff                           // 000000734590: D655001E 03FE3F1E 00007FFF
	v_bfe_u32 v31, v4, 16, 1                                   // 00000073459C: D610001F 02052104
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007345A4: BF8701A2
	.long 0x7e3c399e                                           // 0000007345A8: 7E3C399E
	.long 0x7f3c399d                                           // 0000007345AC: 7F3C399D
	v_add3_u32 v4, v4, v31, 0x7fff                             // 0000007345B0: D6550004 03FE3F04 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007345BC: BF8700A1
	v_and_or_b32 v36, 0xffff0000, v4, v30                      // 0000007345C0: D6570024 047A08FF FFFF0000
	v_bfe_i32 v4, v5, 0, 8                                     // 0000007345CC: D6110004 02210105
	v_cvt_f32_i32_e32 v4, v4                                   // 0000007345D4: 7E080B04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007345D8: BF870091
	v_fma_mix_f32 v4, v27, v4, neg(0) op_sel_hi:[1,0,0]        // 0000007345DC: CC200004 8A02091B
	v_bfe_u32 v28, v4, 16, 1                                   // 0000007345E4: D610001C 02052104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007345EC: BF870091
	v_add3_u32 v4, v4, v28, 0x7fff                             // 0000007345F0: D6550004 03FE3904 00007FFF
	.long 0x7e3a3984                                           // 0000007345FC: 7E3A3984
	v_bfe_i32 v4, v5, 8, 8                                     // 000000734600: D6110004 02211105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000734608: BF870091
	v_cvt_f32_i32_e32 v4, v4                                   // 00000073460C: 7E080B04
	v_fma_mix_f32 v4, v27, v4, neg(0) op_sel_hi:[1,0,0]        // 000000734610: CC200004 8A02091B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000734618: BF870091
	v_bfe_u32 v28, v4, 16, 1                                   // 00000073461C: D610001C 02052104
	v_add3_u32 v4, v4, v28, 0x7fff                             // 000000734624: D6550004 03FE3904 00007FFF
	v_bfe_i32 v28, v5, 16, 8                                   // 000000734630: D611001C 02212105
	v_ashrrev_i32_e32 v5, 24, v5                               // 000000734638: 340A0A98
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000073463C: BF870193
	v_and_or_b32 v37, 0xffff0000, v4, v29                      // 000000734640: D6570025 047608FF FFFF0000
	v_cvt_f32_i32_e32 v28, v28                                 // 00000073464C: 7E380B1C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000734650: BF8701A3
	v_cvt_f32_i32_e32 v5, v5                                   // 000000734654: 7E0A0B05
	v_bfe_i32 v4, v6, 0, 8                                     // 000000734658: D6110004 02210106
	v_fma_mix_f32 v28, v27, v28, neg(0) op_sel_hi:[1,0,0]      // 000000734660: CC20001C 8A02391B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000734668: BF870193
	v_fma_mix_f32 v5, v27, v5, neg(0) op_sel_hi:[1,0,0]        // 00000073466C: CC200005 8A020B1B
	v_cvt_f32_i32_e32 v4, v4                                   // 000000734674: 7E080B04
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000734678: BF870113
	v_bfe_u32 v30, v28, 16, 1                                  // 00000073467C: D610001E 0205211C
	v_fma_mix_f32 v4, v27, v4, neg(0) op_sel_hi:[1,0,0]        // 000000734684: CC200004 8A02091B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000073468C: BF870122
	v_add3_u32 v28, v28, v30, 0x7fff                           // 000000734690: D655001C 03FE3D1C 00007FFF
	v_bfe_u32 v30, v5, 16, 1                                   // 00000073469C: D610001E 02052105
	.long 0x7e38399c                                           // 0000007346A4: 7E38399C
	.long 0x7f38399d                                           // 0000007346A8: 7F38399D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007346AC: BF870093
	v_add3_u32 v5, v5, v30, 0x7fff                             // 0000007346B0: D6550005 03FE3D05 00007FFF
	v_and_or_b32 v38, 0xffff0000, v5, v28                      // 0000007346BC: D6570026 04720AFF FFFF0000
	v_bfe_u32 v5, v4, 16, 1                                    // 0000007346C8: D6100005 02052104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007346D0: BF870091
	v_add3_u32 v4, v4, v5, 0x7fff                              // 0000007346D4: D6550004 03FE0B04 00007FFF
	.long 0x7e3a3984                                           // 0000007346E0: 7E3A3984
	v_bfe_i32 v4, v6, 8, 8                                     // 0000007346E4: D6110004 02211106
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007346EC: BF870091
	v_cvt_f32_i32_e32 v4, v4                                   // 0000007346F0: 7E080B04
	v_fma_mix_f32 v4, v27, v4, neg(0) op_sel_hi:[1,0,0]        // 0000007346F4: CC200004 8A02091B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007346FC: BF870091
	v_bfe_u32 v5, v4, 16, 1                                    // 000000734700: D6100005 02052104
	v_add3_u32 v4, v4, v5, 0x7fff                              // 000000734708: D6550004 03FE0B04 00007FFF
	v_bfe_i32 v5, v6, 16, 8                                    // 000000734714: D6110005 02212106
	v_ashrrev_i32_e32 v6, 24, v6                               // 00000073471C: 340C0C98
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000734720: BF870193
	v_and_or_b32 v39, 0xffff0000, v4, v29                      // 000000734724: D6570027 047608FF FFFF0000
	v_cvt_f32_i32_e32 v5, v5                                   // 000000734730: 7E0A0B05
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000734734: BF8701A3
	v_cvt_f32_i32_e32 v6, v6                                   // 000000734738: 7E0C0B06
	v_bfe_i32 v4, v7, 0, 8                                     // 00000073473C: D6110004 02210107
	v_fma_mix_f32 v5, v27, v5, neg(0) op_sel_hi:[1,0,0]        // 000000734744: CC200005 8A020B1B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000073474C: BF870193
	v_fma_mix_f32 v6, v27, v6, neg(0) op_sel_hi:[1,0,0]        // 000000734750: CC200006 8A020D1B
	v_cvt_f32_i32_e32 v4, v4                                   // 000000734758: 7E080B04
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000073475C: BF870113
	v_bfe_u32 v28, v5, 16, 1                                   // 000000734760: D610001C 02052105
	v_fma_mix_f32 v4, v27, v4, neg(0) op_sel_hi:[1,0,0]        // 000000734768: CC200004 8A02091B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000734770: BF870122
	v_add3_u32 v5, v5, v28, 0x7fff                             // 000000734774: D6550005 03FE3905 00007FFF
	v_bfe_u32 v28, v6, 16, 1                                   // 000000734780: D610001C 02052106
	.long 0x7e0a3985                                           // 000000734788: 7E0A3985
	.long 0x7f0a399d                                           // 00000073478C: 7F0A399D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000734790: BF870093
	v_add3_u32 v6, v6, v28, 0x7fff                             // 000000734794: D6550006 03FE3906 00007FFF
	v_and_or_b32 v40, 0xffff0000, v6, v5                       // 0000007347A0: D6570028 04160CFF FFFF0000
	v_bfe_u32 v5, v4, 16, 1                                    // 0000007347AC: D6100005 02052104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007347B4: BF870091
	v_add3_u32 v4, v4, v5, 0x7fff                              // 0000007347B8: D6550004 03FE0B04 00007FFF
	.long 0x7e3a3984                                           // 0000007347C4: 7E3A3984
	v_bfe_i32 v4, v7, 8, 8                                     // 0000007347C8: D6110004 02211107
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007347D0: BF870091
	v_cvt_f32_i32_e32 v4, v4                                   // 0000007347D4: 7E080B04
	v_fma_mix_f32 v4, v27, v4, neg(0) op_sel_hi:[1,0,0]        // 0000007347D8: CC200004 8A02091B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007347E0: BF870091
	v_bfe_u32 v5, v4, 16, 1                                    // 0000007347E4: D6100005 02052104
	v_add3_u32 v4, v4, v5, 0x7fff                              // 0000007347EC: D6550004 03FE0B04 00007FFF
	v_bfe_i32 v5, v7, 16, 8                                    // 0000007347F8: D6110005 02212107
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000734800: BF870112
	v_and_or_b32 v41, 0xffff0000, v4, v29                      // 000000734804: D6570029 047608FF FFFF0000
	v_cvt_f32_i32_e32 v5, v5                                   // 000000734810: 7E0A0B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000734814: BF870091
	v_fma_mix_f32 v5, v27, v5, neg(0) op_sel_hi:[1,0,0]        // 000000734818: CC200005 8A020B1B
	v_bfe_u32 v6, v5, 16, 1                                    // 000000734820: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000734828: BF870121
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000073482C: D6550005 03FE0D05 00007FFF
	v_ashrrev_i32_e32 v6, 24, v7                               // 000000734838: 340C0E98
	.long 0x7e0a3985                                           // 00000073483C: 7E0A3985
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000734840: BF870122
	v_cvt_f32_i32_e32 v6, v6                                   // 000000734844: 7E0C0B06
	.long 0x7f0a399d                                           // 000000734848: 7F0A399D
	v_fma_mix_f32 v6, v27, v6, neg(0) op_sel_hi:[1,0,0]        // 00000073484C: CC200006 8A020D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000734854: BF870091
	v_bfe_u32 v7, v6, 16, 1                                    // 000000734858: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 000000734860: D6550006 03FE0F06 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000073486C: BF870131
	v_and_or_b32 v42, 0xffff0000, v6, v5                       // 000000734870: D657002A 04160CFF FFFF0000
	.long 0xd73c0004                                           // 00000073487C: D73C0004
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 000000734880: 02021681
	v_mov_b32_e32 v11, v26                                     // 000000734884: 7E16031A
	.long 0xd700001f                                           // 000000734888: D700001F
	v_cndmask_b32_e32 v1, s6, v4, vcc_lo                       // 00000073488C: 02020806
	s_delay_alu instid0(VALU_DEP_1)                            // 000000734890: BF870001
	v_add_co_ci_u32_e64 v32, null, s7, v5, s0                  // 000000734894: D5207C20 00020A07
	s_clause 0x1                                               // 00000073489C: BF850001
	global_load_b128 v[4:7], v[31:32], off                     // 0000007348A0: DC5E0000 047C001F
	global_load_b128 v[27:30], v[31:32], off offset:16         // 0000007348A8: DC5E0010 1B7C001F
	s_waitcnt vmcnt(1)                                         // 0000007348B0: BF8907F7
	v_dot2_f32_bf16 v4, v4, v35, 0                             // 0000007348B4: CC1A4004 1A024704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007348BC: BF870091
	v_dot2_f32_bf16 v4, v5, v36, v4                            // 0000007348C0: CC1A4004 1C124905
	v_dot2_f32_bf16 v4, v6, v37, v4                            // 0000007348C8: CC1A4004 1C124B06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007348D0: BF8700A1
	v_dot2_f32_bf16 v4, v7, v38, v4                            // 0000007348D4: CC1A4004 1C124D07
	s_waitcnt vmcnt(0)                                         // 0000007348DC: BF8903F7
	v_dot2_f32_bf16 v4, v27, v39, v4                           // 0000007348E0: CC1A4004 1C124F1B
	.long 0xd700001b                                           // 0000007348E8: D700001B
	v_cndmask_b32_e32 v0, v31, v4, vcc_lo                      // 0000007348EC: 0200091F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000007348F0: BF8701B2
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 0000007348F4: CC1A4004 1C12511C
	v_add_co_ci_u32_e64 v28, null, s5, v32, s0                 // 0000007348FC: D5207C1C 00024005
	.long 0xd7000021                                           // 000000734904: D7000021
	v_cndmask_b32_e32 v0, v31, v14, vcc_lo                     // 000000734908: 02001D1F
	v_dot2_f32_bf16 v4, v29, v41, v4                           // 00000073490C: CC1A4004 1C12531D
	v_add_co_ci_u32_e64 v34, null, s15, v32, s0                // 000000734914: D5207C22 0002400F
	.long 0xd700001f                                           // 00000073491C: D700001F
	v_cndmask_b32_e32 v0, v31, v18, vcc_lo                     // 000000734920: 0200251F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000734924: BF870123
	v_dot2_f32_bf16 v4, v30, v42, v4                           // 000000734928: CC1A4004 1C12551E
	v_add_co_ci_u32_e64 v32, null, s16, v32, s0                // 000000734930: D5207C20 00024010
	v_add_f32_e32 v24, v24, v4                                 // 000000734938: 06300918
	s_clause 0x1                                               // 00000073493C: BF850001
	global_load_b128 v[4:7], v[27:28], off                     // 000000734940: DC5E0000 047C001B
	global_load_b128 v[27:30], v[27:28], off offset:16         // 000000734948: DC5E0010 1B7C001B
	s_waitcnt vmcnt(1)                                         // 000000734950: BF8907F7
	v_dot2_f32_bf16 v4, v4, v35, 0                             // 000000734954: CC1A4004 1A024704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000073495C: BF870091
	v_dot2_f32_bf16 v4, v5, v36, v4                            // 000000734960: CC1A4004 1C124905
	v_dot2_f32_bf16 v4, v6, v37, v4                            // 000000734968: CC1A4004 1C124B06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000734970: BF8700A1
	v_dot2_f32_bf16 v4, v7, v38, v4                            // 000000734974: CC1A4004 1C124D07
	s_waitcnt vmcnt(0)                                         // 00000073497C: BF8903F7
	v_dot2_f32_bf16 v4, v27, v39, v4                           // 000000734980: CC1A4004 1C124F1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000734988: BF870091
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 00000073498C: CC1A4004 1C12511C
	v_dot2_f32_bf16 v4, v29, v41, v4                           // 000000734994: CC1A4004 1C12531D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000073499C: BF870091
	v_dot2_f32_bf16 v4, v30, v42, v4                           // 0000007349A0: CC1A4004 1C12551E
	v_add_f32_e32 v23, v23, v4                                 // 0000007349A8: 062E0917
	s_clause 0x1                                               // 0000007349AC: BF850001
	global_load_b128 v[4:7], v[33:34], off                     // 0000007349B0: DC5E0000 047C0021
	global_load_b128 v[27:30], v[33:34], off offset:16         // 0000007349B8: DC5E0010 1B7C0021
	.long 0xd7000021                                           // 0000007349C0: D7000021
	v_cndmask_b32_e32 v0, v33, v14, vcc_lo                     // 0000007349C4: 02001D21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007349C8: BF8700B1
	v_add_co_ci_u32_e64 v34, null, s15, v34, s0                // 0000007349CC: D5207C22 0002440F
	s_waitcnt vmcnt(1)                                         // 0000007349D4: BF8907F7
	v_dot2_f32_bf16 v4, v4, v35, 0                             // 0000007349D8: CC1A4004 1A024704
	v_dot2_f32_bf16 v4, v5, v36, v4                            // 0000007349E0: CC1A4004 1C124905
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007349E8: BF870091
	v_dot2_f32_bf16 v4, v6, v37, v4                            // 0000007349EC: CC1A4004 1C124B06
	v_dot2_f32_bf16 v4, v7, v38, v4                            // 0000007349F4: CC1A4004 1C124D07
	s_waitcnt vmcnt(0)                                         // 0000007349FC: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000734A00: BF870091
	v_dot2_f32_bf16 v4, v27, v39, v4                           // 000000734A04: CC1A4004 1C124F1B
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 000000734A0C: CC1A4004 1C12511C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000734A14: BF870091
	v_dot2_f32_bf16 v4, v29, v41, v4                           // 000000734A18: CC1A4004 1C12531D
	v_dot2_f32_bf16 v4, v30, v42, v4                           // 000000734A20: CC1A4004 1C12551E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000734A28: BF870001
	v_add_f32_e32 v22, v22, v4                                 // 000000734A2C: 062C0916
	s_clause 0x1                                               // 000000734A30: BF850001
	global_load_b128 v[4:7], v[31:32], off                     // 000000734A34: DC5E0000 047C001F
	global_load_b128 v[27:30], v[31:32], off offset:16         // 000000734A3C: DC5E0010 1B7C001F
	s_waitcnt vmcnt(1)                                         // 000000734A44: BF8907F7
	v_dot2_f32_bf16 v4, v4, v35, 0                             // 000000734A48: CC1A4004 1A024704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000734A50: BF870091
	v_dot2_f32_bf16 v4, v5, v36, v4                            // 000000734A54: CC1A4004 1C124905
	v_dot2_f32_bf16 v4, v6, v37, v4                            // 000000734A5C: CC1A4004 1C124B06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000734A64: BF8700A1
	v_dot2_f32_bf16 v4, v7, v38, v4                            // 000000734A68: CC1A4004 1C124D07
	s_waitcnt vmcnt(0)                                         // 000000734A70: BF8903F7
	v_dot2_f32_bf16 v4, v27, v39, v4                           // 000000734A74: CC1A4004 1C124F1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000734A7C: BF870091
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 000000734A80: CC1A4004 1C12511C
	v_dot2_f32_bf16 v4, v29, v41, v4                           // 000000734A88: CC1A4004 1C12531D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000734A90: BF870091
	v_dot2_f32_bf16 v4, v30, v42, v4                           // 000000734A94: CC1A4004 1C12551E
	v_add_f32_e32 v21, v21, v4                                 // 000000734A9C: 062A0915
	s_clause 0x1                                               // 000000734AA0: BF850001
	global_load_b128 v[4:7], v[33:34], off                     // 000000734AA4: DC5E0000 047C0021
	global_load_b128 v[27:30], v[33:34], off offset:16         // 000000734AAC: DC5E0010 1B7C0021
	s_waitcnt vmcnt(1)                                         // 000000734AB4: BF8907F7
	v_dot2_f32_bf16 v4, v4, v35, 0                             // 000000734AB8: CC1A4004 1A024704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000734AC0: BF870091
	v_dot2_f32_bf16 v4, v5, v36, v4                            // 000000734AC4: CC1A4004 1C124905
	v_dot2_f32_bf16 v4, v6, v37, v4                            // 000000734ACC: CC1A4004 1C124B06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000734AD4: BF8700A1
	v_dot2_f32_bf16 v4, v7, v38, v4                            // 000000734AD8: CC1A4004 1C124D07
	s_waitcnt vmcnt(0)                                         // 000000734AE0: BF8903F7
	v_dot2_f32_bf16 v4, v27, v39, v4                           // 000000734AE4: CC1A4004 1C124F1B
	.long 0xd700001b                                           // 000000734AEC: D700001B
	v_cndmask_b32_e32 v0, v31, v14, vcc_lo                     // 000000734AF0: 02001D1F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000734AF4: BF870122
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 000000734AF8: CC1A4004 1C12511C
	v_add_co_ci_u32_e64 v28, null, s15, v32, s0                // 000000734B00: D5207C1C 0002400F
	v_dot2_f32_bf16 v4, v29, v41, v4                           // 000000734B08: CC1A4004 1C12531D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000734B10: BF870091
	v_dot2_f32_bf16 v4, v30, v42, v4                           // 000000734B14: CC1A4004 1C12551E
	v_add_f32_e32 v20, v20, v4                                 // 000000734B1C: 06280914
	s_clause 0x1                                               // 000000734B20: BF850001
	global_load_b128 v[4:7], v[27:28], off                     // 000000734B24: DC5E0000 047C001B
	global_load_b128 v[27:30], v[27:28], off offset:16         // 000000734B2C: DC5E0010 1B7C001B
	s_waitcnt vmcnt(1)                                         // 000000734B34: BF8907F7
	v_dot2_f32_bf16 v4, v4, v35, 0                             // 000000734B38: CC1A4004 1A024704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000734B40: BF870091
	v_dot2_f32_bf16 v4, v5, v36, v4                            // 000000734B44: CC1A4004 1C124905
	v_dot2_f32_bf16 v4, v6, v37, v4                            // 000000734B4C: CC1A4004 1C124B06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000734B54: BF8700A1
	v_dot2_f32_bf16 v4, v7, v38, v4                            // 000000734B58: CC1A4004 1C124D07
	s_waitcnt vmcnt(0)                                         // 000000734B60: BF8903F7
	v_dot2_f32_bf16 v4, v27, v39, v4                           // 000000734B64: CC1A4004 1C124F1B
	.long 0xd700001b                                           // 000000734B6C: D700001B
	v_cndmask_b32_e32 v0, v33, v14, vcc_lo                     // 000000734B70: 02001D21
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000734B74: BF8701B2
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 000000734B78: CC1A4004 1C12511C
	v_add_co_ci_u32_e64 v28, null, s15, v34, s0                // 000000734B80: D5207C1C 0002440F
	.long 0xd700000d                                           // 000000734B88: D700000D
	v_cndmask_b32_e32 v0, v13, v160, vcc_lo                    // 000000734B8C: 0201410D
	v_dot2_f32_bf16 v4, v29, v41, v4                           // 000000734B90: CC1A4004 1C12531D
	v_add_co_ci_u32_e64 v14, null, 0, v14, s0                  // 000000734B98: D5207C0E 00021C80
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000734BA0: BF870092
	v_dot2_f32_bf16 v4, v30, v42, v4                           // 000000734BA4: CC1A4004 1C12551E
	v_add_f32_e32 v19, v19, v4                                 // 000000734BAC: 06260913
	s_clause 0x1                                               // 000000734BB0: BF850001
	global_load_b128 v[4:7], v[27:28], off                     // 000000734BB4: DC5E0000 047C001B
	global_load_b128 v[27:30], v[27:28], off offset:16         // 000000734BBC: DC5E0010 1B7C001B
	s_waitcnt vmcnt(1)                                         // 000000734BC4: BF8907F7
	v_dot2_f32_bf16 v4, v4, v35, 0                             // 000000734BC8: CC1A4004 1A024704
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000734BD0: BF870121
	v_dot2_f32_bf16 v4, v5, v36, v4                            // 000000734BD4: CC1A4004 1C124905
	v_mov_b32_e32 v5, v1                                       // 000000734BDC: 7E0A0301
	v_dot2_f32_bf16 v4, v6, v37, v4                            // 000000734BE0: CC1A4004 1C124B06
	v_mov_b32_e32 v6, v2                                       // 000000734BE8: 7E0C0302
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000734BEC: BF870132
	v_dot2_f32_bf16 v4, v7, v38, v4                            // 000000734BF0: CC1A4004 1C124D07
	v_mov_b32_e32 v7, v3                                       // 000000734BF8: 7E0E0303
	s_waitcnt vmcnt(0)                                         // 000000734BFC: BF8903F7
	v_dot2_f32_bf16 v4, v27, v39, v4                           // 000000734C00: CC1A4004 1C124F1B
	.long 0x7e363908                                           // 000000734C08: 7E363908
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000734C0C: BF870092
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 000000734C10: CC1A4004 1C12511C
	v_dot2_f32_bf16 v4, v29, v41, v4                           // 000000734C18: CC1A4004 1C12531D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000734C20: BF870091
	v_dot2_f32_bf16 v4, v30, v42, v4                           // 000000734C24: CC1A4004 1C12551E
	v_add_f32_e32 v16, v16, v4                                 // 000000734C2C: 06200910
	v_mov_b32_e32 v4, v0                                       // 000000734C30: 7E080300
	s_and_not1_b32 exec_lo, exec_lo, s17                       // 000000734C34: 917E117E
	s_cbranch_execz 29                                         // 000000734C38: BFA5001D <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi7ELi32ELi1ELb1EEEvPKhPKtPvll+0x9b0>
	v_add_nc_u32_e32 v25, 32, v25                              // 000000734C3C: 4A3232A0
	v_add_nc_u32_e32 v26, 0x200, v11                           // 000000734C40: 4A3416FF 00000200
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000734C48: BF8704A2
	.long 0xd4430000                                           // 000000734C4C: D4430000
	v_cndmask_b32_e32 v1, s2, v25, vcc_lo                      // 000000734C50: 02023202
	s_and_saveexec_b32 s1, s0                                  // 000000734C54: BE812000
	s_xor_b32 s1, exec_lo, s1                                  // 000000734C58: 8D01017E
	v_add_nc_u32_e32 v26, 0x200, v11                           // 000000734C5C: 4A3416FF 00000200
	s_or_saveexec_b32 s10, s1                                  // 000000734C64: BE8A2201
	s_waitcnt vmcnt(0)                                         // 000000734C68: BF8903F7
	.long 0x7e10391b                                           // 000000734C6C: 7E10391B
	v_dual_mov_b32 v0, v4 :: v_dual_mov_b32 v1, v5             // 000000734C70: CA100104 00000105
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v3, v7             // 000000734C78: CA100106 02020107
	s_xor_b32 exec_lo, exec_lo, s10                            // 000000734C80: 8D7E0A7E
	s_cbranch_execz 65042                                      // 000000734C84: BFA5FE12 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi7ELi32ELi1ELb1EEEvPKhPKtPvll+0x1d0>
	.long 0xd7000100                                           // 000000734C88: D7000100
	v_cndmask_b32_e32 v1, v17, v26, vcc_lo                     // 000000734C8C: 02023511
	s_delay_alu instid0(VALU_DEP_1)                            // 000000734C90: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v18, s1                   // 000000734C94: D5207C01 00062480
	global_load_b128 v[0:3], v[0:1], off                       // 000000734C9C: DC5E0000 007C0000
	global_load_d16_b16 v8, v[13:14], off                      // 000000734CA4: DC820000 087C000D
	s_branch 65032                                             // 000000734CAC: BFA0FE08 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi7ELi32ELi1ELb1EEEvPKhPKtPvll+0x1d0>
	s_or_b32 exec_lo, exec_lo, s17                             // 000000734CB0: 8C7E117E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000734CB4: BF8700A9
	s_or_b32 exec_lo, exec_lo, s3                              // 000000734CB8: 8C7E037E
	.long 0xd71f0000                                           // 000000734CBC: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000734CC0: 020100C1
	v_xor_b32_e32 v1, 16, v0                                   // 000000734CC4: 3A020090
	v_xor_b32_e32 v8, 8, v0                                    // 000000734CC8: 3A100088
	v_xor_b32_e32 v18, 4, v0                                   // 000000734CCC: 3A240084
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000734CD0: BF870093
	.long 0xd44c0000                                           // 000000734CD4: D44C0000
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 000000734CD8: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s0                           // 000000734CDC: D5010001 00020300
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000734CE4: BF870114
	.long 0xd44c0000                                           // 000000734CE8: D44C0000
	v_cndmask_b32_e32 v1, 32, v8, vcc_lo                       // 000000734CEC: 020210A0
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000734CF0: 30020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000734CF4: BF8700C2
	v_cndmask_b32_e64 v8, v0, v8, s0                           // 000000734CF8: D5010008 00021100
	.long 0xd44c0000                                           // 000000734D00: D44C0000
	v_cndmask_b32_e32 v1, 32, v18, vcc_lo                      // 000000734D04: 020224A0
	ds_bpermute_b32 v2, v1, v24                                // 000000734D08: DACC0000 02001801
	v_cndmask_b32_e64 v18, v0, v18, s0                         // 000000734D10: D5010012 00022500
	v_lshlrev_b32_e32 v18, 2, v18                              // 000000734D18: 30242482
	s_waitcnt lgkmcnt(0)                                       // 000000734D1C: BF89FC07
	v_add_f32_e32 v2, v24, v2                                  // 000000734D20: 06040518
	ds_bpermute_b32 v3, v1, v23                                // 000000734D24: DACC0000 03001701
	s_waitcnt vmcnt(1)                                         // 000000734D2C: BF8907F7
	ds_bpermute_b32 v4, v1, v22                                // 000000734D30: DACC0000 04001601
	ds_bpermute_b32 v5, v1, v21                                // 000000734D38: DACC0000 05001501
	ds_bpermute_b32 v6, v1, v20                                // 000000734D40: DACC0000 06001401
	ds_bpermute_b32 v7, v1, v19                                // 000000734D48: DACC0000 07001301
	ds_bpermute_b32 v1, v1, v16                                // 000000734D50: DACC0000 01001001
	s_waitcnt lgkmcnt(5)                                       // 000000734D58: BF89FC57
	v_dual_add_f32 v3, v23, v3 :: v_dual_lshlrev_b32 v8, 2, v8 // 000000734D5C: C9220717 03081082
	s_waitcnt lgkmcnt(3)                                       // 000000734D64: BF89FC37
	v_dual_add_f32 v4, v22, v4 :: v_dual_add_f32 v5, v21, v5   // 000000734D68: C9080916 04040B15
	s_waitcnt lgkmcnt(1)                                       // 000000734D70: BF89FC17
	v_dual_add_f32 v6, v20, v6 :: v_dual_add_f32 v7, v19, v7   // 000000734D74: C9080D14 06060F13
	s_waitcnt lgkmcnt(0)                                       // 000000734D7C: BF89FC07
	v_add_f32_e32 v1, v16, v1                                  // 000000734D80: 06020310
	ds_bpermute_b32 v11, v8, v2                                // 000000734D84: DACC0000 0B000208
	ds_bpermute_b32 v12, v8, v3                                // 000000734D8C: DACC0000 0C000308
	ds_bpermute_b32 v13, v8, v4                                // 000000734D94: DACC0000 0D000408
	ds_bpermute_b32 v14, v8, v5                                // 000000734D9C: DACC0000 0E000508
	ds_bpermute_b32 v16, v8, v6                                // 000000734DA4: DACC0000 10000608
	ds_bpermute_b32 v17, v8, v7                                // 000000734DAC: DACC0000 11000708
	ds_bpermute_b32 v8, v8, v1                                 // 000000734DB4: DACC0000 08000108
	s_waitcnt lgkmcnt(5)                                       // 000000734DBC: BF89FC57
	v_dual_add_f32 v2, v2, v11 :: v_dual_add_f32 v3, v3, v12   // 000000734DC0: C9081702 02021903
	s_waitcnt lgkmcnt(3)                                       // 000000734DC8: BF89FC37
	v_dual_add_f32 v4, v4, v13 :: v_dual_add_f32 v5, v5, v14   // 000000734DCC: C9081B04 04041D05
	s_waitcnt lgkmcnt(1)                                       // 000000734DD4: BF89FC17
	v_dual_add_f32 v6, v6, v16 :: v_dual_add_f32 v7, v7, v17   // 000000734DD8: C9082106 06062307
	s_waitcnt lgkmcnt(0)                                       // 000000734DE0: BF89FC07
	v_add_f32_e32 v1, v1, v8                                   // 000000734DE4: 06021101
	ds_bpermute_b32 v8, v18, v2                                // 000000734DE8: DACC0000 08000212
	ds_bpermute_b32 v11, v18, v3                               // 000000734DF0: DACC0000 0B000312
	ds_bpermute_b32 v13, v18, v5                               // 000000734DF8: DACC0000 0D000512
	ds_bpermute_b32 v12, v18, v4                               // 000000734E00: DACC0000 0C000412
	ds_bpermute_b32 v14, v18, v6                               // 000000734E08: DACC0000 0E000612
	ds_bpermute_b32 v16, v18, v7                               // 000000734E10: DACC0000 10000712
	ds_bpermute_b32 v17, v18, v1                               // 000000734E18: DACC0000 11000112
	v_xor_b32_e32 v18, 2, v0                                   // 000000734E20: 3A240082
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000734E24: BF870091
	.long 0xd44c0000                                           // 000000734E28: D44C0000
	v_cndmask_b32_e32 v1, 32, v18, vcc_lo                      // 000000734E2C: 020224A0
	v_cndmask_b32_e64 v18, v0, v18, s0                         // 000000734E30: D5010012 00022500
	s_waitcnt lgkmcnt(6)                                       // 000000734E38: BF89FC67
	v_add_f32_e32 v2, v2, v8                                   // 000000734E3C: 06041102
	s_waitcnt lgkmcnt(5)                                       // 000000734E40: BF89FC57
	v_add_f32_e32 v8, v3, v11                                  // 000000734E44: 06101703
	s_waitcnt lgkmcnt(4)                                       // 000000734E48: BF89FC47
	v_dual_add_f32 v11, v5, v13 :: v_dual_lshlrev_b32 v18, 2, v18// 000000734E4C: C9221B05 0B122482
	s_waitcnt lgkmcnt(3)                                       // 000000734E54: BF89FC37
	v_add_f32_e32 v4, v4, v12                                  // 000000734E58: 06081904
	s_waitcnt lgkmcnt(1)                                       // 000000734E5C: BF89FC17
	v_dual_add_f32 v6, v6, v14 :: v_dual_add_f32 v7, v7, v16   // 000000734E60: C9081D06 06062107
	v_xor_b32_e32 v3, 1, v0                                    // 000000734E68: 3A060081
	ds_bpermute_b32 v14, v18, v11                              // 000000734E6C: DACC0000 0E000B12
	s_waitcnt lgkmcnt(1)                                       // 000000734E74: BF89FC17
	v_add_f32_e32 v12, v1, v17                                 // 000000734E78: 06182301
	ds_bpermute_b32 v1, v18, v2                                // 000000734E7C: DACC0000 01000212
	ds_bpermute_b32 v16, v18, v6                               // 000000734E84: DACC0000 10000612
	.long 0xd44c0000                                           // 000000734E8C: D44C0000
	v_cndmask_b32_e32 v1, 32, v3, vcc_lo                       // 000000734E90: 020206A0
	ds_bpermute_b32 v17, v18, v7                               // 000000734E94: DACC0000 11000712
	v_cndmask_b32_e64 v0, v0, v3, s0                           // 000000734E9C: D5010000 00020700
	.long 0xd44a0000                                           // 000000734EA4: D44A0000
	v_cndmask_b32_e32 v1, 0, v15, vcc_lo                       // 000000734EA8: 02021E80
	s_delay_alu instid0(VALU_DEP_2)                            // 000000734EAC: BF870002
	v_lshlrev_b32_e32 v19, 2, v0                               // 000000734EB0: 30260082
	ds_bpermute_b32 v5, v18, v8                                // 000000734EB4: DACC0000 05000812
	s_and_b32 s0, s0, vcc_lo                                   // 000000734EBC: 8B006A00
	s_waitcnt lgkmcnt(3)                                       // 000000734EC0: BF89FC37
	v_add_f32_e32 v3, v2, v1                                   // 000000734EC4: 06060302
	ds_bpermute_b32 v13, v18, v4                               // 000000734EC8: DACC0000 0D000412
	v_add_f32_e32 v1, v11, v14                                 // 000000734ED0: 06021D0B
	ds_bpermute_b32 v18, v18, v12                              // 000000734ED4: DACC0000 12000C12
	s_waitcnt lgkmcnt(2)                                       // 000000734EDC: BF89FC27
	v_dual_add_f32 v6, v6, v16 :: v_dual_add_f32 v5, v8, v5    // 000000734EE0: C9082106 06040B08
	v_add_f32_e32 v8, v7, v17                                  // 000000734EE8: 06102307
	ds_bpermute_b32 v7, v19, v3                                // 000000734EEC: DACC0000 07000313
	ds_bpermute_b32 v11, v19, v5                               // 000000734EF4: DACC0000 0B000513
	s_waitcnt lgkmcnt(3)                                       // 000000734EFC: BF89FC37
	v_add_f32_e32 v0, v4, v13                                  // 000000734F00: 06001B04
	ds_bpermute_b32 v4, v19, v1                                // 000000734F04: DACC0000 04000113
	s_waitcnt lgkmcnt(3)                                       // 000000734F0C: BF89FC37
	v_add_f32_e32 v14, v12, v18                                // 000000734F10: 061C250C
	ds_bpermute_b32 v12, v19, v6                               // 000000734F14: DACC0000 0C000613
	ds_bpermute_b32 v13, v19, v8                               // 000000734F1C: DACC0000 0D000813
	ds_bpermute_b32 v2, v19, v0                                // 000000734F24: DACC0000 02000013
	ds_bpermute_b32 v16, v19, v14                              // 000000734F2C: DACC0000 10000E13
	s_and_saveexec_b32 s1, s0                                  // 000000734F34: BE812000
	s_cbranch_execz 62                                         // 000000734F38: BFA5003E <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi7ELi32ELi1ELb1EEEvPKhPKtPvll+0xd34>
	.long 0xd73c0009                                           // 000000734F3C: D73C0009
	v_cndmask_b32_e32 v1, 2, v9, vcc_lo                        // 000000734F40: 02021282
	s_waitcnt lgkmcnt(3)                                       // 000000734F44: BF89FC37
	v_dual_add_f32 v12, v6, v12 :: v_dual_add_f32 v11, v5, v11 // 000000734F48: C9081906 0C0A1705
	s_lshl_b64 s[0:1], s[12:13], 2                             // 000000734F50: 8480820C
	s_waitcnt lgkmcnt(0)                                       // 000000734F54: BF89FC07
	v_dual_add_f32 v14, v14, v16 :: v_dual_add_f32 v13, v8, v13// 000000734F58: C908210E 0E0C1B08
	.long 0xd7006a05                                           // 000000734F60: D7006A05
	v_cndmask_b32_e32 v1, s8, v9, vcc_lo                       // 000000734F64: 02021208
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000734F68: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s9, v10, vcc_lo              // 000000734F6C: D5207C06 01AA1409
	v_dual_add_f32 v3, v3, v7 :: v_dual_add_f32 v16, v0, v2    // 000000734F74: C9080F03 03100500
	.long 0xd7006a07                                           // 000000734F7C: D7006A07
	v_cndmask_b32_e32 v0, v5, v0, vcc_lo                       // 000000734F80: 02000105
	v_add_f32_e32 v15, v1, v4                                  // 000000734F84: 061E0901
	s_delay_alu instid0(VALU_DEP_4)                            // 000000734F88: BF870004
	v_mad_u64_u32 v[0:1], null, s12, 12, v[5:6]                // 000000734F8C: D6FE7C00 0415180C
	v_add_co_ci_u32_e64 v8, null, s1, v6, vcc_lo               // 000000734F94: D5207C08 01AA0C01
	s_lshl_b64 s[0:1], s[12:13], 3                             // 000000734F9C: 8480830C
	s_clause 0x1                                               // 000000734FA0: BF850001
	global_store_b32 v[5:6], v3, off                           // 000000734FA4: DC6A0000 007C0305
	global_store_b32 v[7:8], v11, off                          // 000000734FAC: DC6A0000 007C0B07
	.long 0xd7006a03                                           // 000000734FB4: D7006A03
	v_cndmask_b32_e32 v0, v5, v0, vcc_lo                       // 000000734FB8: 02000105
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000734FBC: BF8701A1
	v_add_co_ci_u32_e64 v4, null, s1, v6, vcc_lo               // 000000734FC0: D5207C04 01AA0C01
	v_mad_u64_u32 v[1:2], null, s13, 12, v[1:2]                // 000000734FC8: D6FE7C01 0405180D
	.long 0xd7006a05                                           // 000000734FD0: D7006A05
	v_cndmask_b32_e32 v0, v3, v0, vcc_lo                       // 000000734FD4: 02000103
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000734FD8: BF8700A1
	v_add_co_ci_u32_e64 v6, null, s1, v4, vcc_lo               // 000000734FDC: D5207C06 01AA0801
	.long 0xd7006a07                                           // 000000734FE4: D7006A07
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 000000734FE8: 02000100
	v_add_co_ci_u32_e64 v8, null, s1, v1, vcc_lo               // 000000734FEC: D5207C08 01AA0201
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000734FF4: BF870094
	.long 0xd7006a09                                           // 000000734FF8: D7006A09
	v_cndmask_b32_e32 v0, v5, v0, vcc_lo                       // 000000734FFC: 02000105
	v_add_co_ci_u32_e64 v10, null, s1, v6, vcc_lo              // 000000735000: D5207C0A 01AA0C01
	s_clause 0x4                                               // 000000735008: BF850004
	global_store_b32 v[3:4], v16, off                          // 00000073500C: DC6A0000 007C1003
	global_store_b32 v[0:1], v15, off                          // 000000735014: DC6A0000 007C0F00
	global_store_b32 v[5:6], v12, off                          // 00000073501C: DC6A0000 007C0C05
	global_store_b32 v[7:8], v13, off                          // 000000735024: DC6A0000 007C0D07
	global_store_b32 v[9:10], v14, off                         // 00000073502C: DC6A0000 007C0E09
	s_endpgm                                                   // 000000735034: BFB00000
		...

