0000000000a7fb00 <_ZN7halogen12_GLOBAL__N_112k_ht_gemv_guILi4ELi8ELi1EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_S5_PDF16_>:
; _ZN7halogen12_GLOBAL__N_112k_ht_gemv_guILi4ELi8ELi1EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_S5_PDF16_():
	s_load_b256 s[16:23], s[0:1], null                         // 000000A7FB00: F40C0400 F8000000
	s_mov_b32 s3, 0                                            // 000000A7FB08: BE830080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A7FB0C: BF870009
	s_lshl_b64 s[4:5], s[2:3], 4                               // 000000A7FB10: 84848402
	s_waitcnt lgkmcnt(0)                                       // 000000A7FB14: BF89FC07
	s_add_u32 s4, s20, s4                                      // 000000A7FB18: 80040414
	s_addc_u32 s5, s21, s5                                     // 000000A7FB1C: 82050515
	s_load_b256 s[8:15], s[0:1], 0x20                          // 000000A7FB20: F40C0200 F8000020
	s_load_b128 s[24:27], s[4:5], null                         // 000000A7FB28: F4080602 F8000000
	s_mov_b32 s1, exec_lo                                      // 000000A7FB30: BE81007E
	v_cmpx_gt_u32_e32 0x140, v0                                // 000000A7FB34: 7D9800FF 00000140
	s_cbranch_execz 52                                         // 000000A7FB3C: BFA50034 <_ZN7halogen12_GLOBAL__N_112k_ht_gemv_guILi4ELi8ELi1EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_S5_PDF16_+0x110>
	s_waitcnt lgkmcnt(0)                                       // 000000A7FB40: BF89FC07
	s_add_i32 s0, s27, -1                                      // 000000A7FB44: 8100C11B
	v_lshlrev_b32_e32 v4, 4, v0                                // 000000A7FB48: 30080084
	s_min_i32 s4, s26, s0                                      // 000000A7FB4C: 8904001A
	v_or_b32_e32 v3, 0xffffff00, v0                            // 000000A7FB50: 380600FF FFFFFF00
	s_ashr_i32 s5, s4, 31                                      // 000000A7FB58: 86059F04
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000A7FB5C: BF870499
	s_lshl_b64 s[4:5], s[4:5], 2                               // 000000A7FB60: 84848204
	s_add_u32 s4, s22, s4                                      // 000000A7FB64: 80040416
	s_addc_u32 s5, s23, s5                                     // 000000A7FB68: 82050517
	s_load_b32 s0, s[4:5], null                                // 000000A7FB6C: F4000002 F8000000
	s_waitcnt lgkmcnt(0)                                       // 000000A7FB74: BF89FC07
	s_mul_i32 s2, s0, 0x1400                                   // 000000A7FB78: 9602FF00 00001400
	s_mul_hi_i32 s0, s0, 0x1400                                // 000000A7FB80: 9700FF00 00001400
	s_add_u32 s2, s18, s2                                      // 000000A7FB88: 80020212
	s_addc_u32 s0, s19, s0                                     // 000000A7FB8C: 82000013
	.long 0xd7000201                                           // 000000A7FB90: D7000201
	v_cndmask_b32_e32 v1, s2, v4, vcc_lo                       // 000000A7FB94: 02020802
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A7FB98: BF870001
	v_add_co_ci_u32_e64 v2, null, s0, 0, s2                    // 000000A7FB9C: D5207C02 00090000
	s_nop 0                                                    // 000000A7FBA4: BF800000
	s_nop 0                                                    // 000000A7FBA8: BF800000
	s_nop 0                                                    // 000000A7FBAC: BF800000
	s_nop 0                                                    // 000000A7FBB0: BF800000
	s_nop 0                                                    // 000000A7FBB4: BF800000
	s_nop 0                                                    // 000000A7FBB8: BF800000
	s_nop 0                                                    // 000000A7FBBC: BF800000
	global_load_b128 v[5:8], v[1:2], off                       // 000000A7FBC0: DC5E0000 057C0001
	v_add_nc_u32_e32 v3, 0x100, v3                             // 000000A7FBC8: 4A0606FF 00000100
	.long 0xd7006a01                                           // 000000A7FBD0: D7006A01
	v_cndmask_b32_e32 v1, 0x1000, v1, vcc_lo                   // 000000A7FBD4: 020202FF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A7FBDC: BF870191
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 000000A7FBE0: D5207C02 01AA0480
	.long 0xd4490000                                           // 000000A7FBE8: D4490000
	v_cndmask_b32_e32 v1, 63, v3, vcc_lo                       // 000000A7FBEC: 020206BF
	s_or_b32 s3, s0, s3                                        // 000000A7FBF0: 8C030300
	s_waitcnt vmcnt(0)                                         // 000000A7FBF4: BF8903F7
	ds_store_b128 v4, v[5:8]                                   // 000000A7FBF8: DB7C0000 00000504
	v_add_nc_u32_e32 v4, 0x1000, v4                            // 000000A7FC00: 4A0808FF 00001000
	s_and_not1_b32 exec_lo, exec_lo, s3                        // 000000A7FC08: 917E037E
	s_cbranch_execnz 65516                                     // 000000A7FC0C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_112k_ht_gemv_guILi4ELi8ELi1EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_S5_PDF16_+0xc0>
	s_or_b32 exec_lo, exec_lo, s1                              // 000000A7FC10: 8C7E017E
	v_lshrrev_b32_e32 v24, 5, v0                               // 000000A7FC14: 32300085
	v_and_b32_e32 v25, 31, v0                                  // 000000A7FC18: 3632009F
	v_mov_b32_e32 v1, 0                                        // 000000A7FC1C: 7E020280
	s_waitcnt lgkmcnt(0)                                       // 000000A7FC20: BF89FC07
	s_mul_hi_i32 s2, s24, 0x190000                             // 000000A7FC24: 9702FF18 00190000
	s_mul_i32 s4, s24, 0x190000                                // 000000A7FC2C: 9604FF18 00190000
	v_mul_u32_u24_e32 v18, 20, v24                             // 000000A7FC34: 16243094
	v_lshlrev_b32_e32 v26, 2, v25                              // 000000A7FC38: 30343282
	v_mov_b32_e32 v16, v1                                      // 000000A7FC3C: 7E200301
	v_mov_b32_e32 v2, v1                                       // 000000A7FC40: 7E040301
	v_mov_b32_e32 v3, v1                                       // 000000A7FC44: 7E060301
	v_min_u32_e32 v19, 0x8c, v18                               // 000000A7FC48: 262624FF 0000008C
	v_mov_b32_e32 v4, v1                                       // 000000A7FC50: 7E080301
	v_mov_b32_e32 v5, v1                                       // 000000A7FC54: 7E0A0301
	v_mov_b32_e32 v6, v1                                       // 000000A7FC58: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 000000A7FC5C: 7E0E0301
	v_dual_mov_b32 v8, v1 :: v_dual_add_nc_u32 v27, 20, v19    // 000000A7FC60: CA200101 081A2694
	v_mov_b32_e32 v9, v1                                       // 000000A7FC68: 7E120301
	v_mov_b32_e32 v10, v1                                      // 000000A7FC6C: 7E140301
	v_mov_b32_e32 v11, v1                                      // 000000A7FC70: 7E160301
	v_mov_b32_e32 v12, v1                                      // 000000A7FC74: 7E180301
	v_mov_b32_e32 v13, v1                                      // 000000A7FC78: 7E1A0301
	v_mov_b32_e32 v14, v1                                      // 000000A7FC7C: 7E1C0301
	v_mov_b32_e32 v15, v1                                      // 000000A7FC80: 7E1E0301
	v_mov_b32_e32 v17, v16                                     // 000000A7FC84: 7E220310
	v_cmp_lt_u32_e32 vcc_lo, v18, v27                          // 000000A7FC88: 7C923712
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A7FC8C: BF870003
	v_mov_b32_e32 v16, v15                                     // 000000A7FC90: 7E20030F
	v_mov_b32_e32 v15, v14                                     // 000000A7FC94: 7E1E030E
	v_mov_b32_e32 v14, v13                                     // 000000A7FC98: 7E1C030D
	v_mov_b32_e32 v13, v12                                     // 000000A7FC9C: 7E1A030C
	v_mov_b32_e32 v12, v11                                     // 000000A7FCA0: 7E18030B
	v_mov_b32_e32 v11, v10                                     // 000000A7FCA4: 7E16030A
	v_mov_b32_e32 v10, v9                                      // 000000A7FCA8: 7E140309
	v_mov_b32_e32 v9, v8                                       // 000000A7FCAC: 7E120308
	v_mov_b32_e32 v8, v7                                       // 000000A7FCB0: 7E100307
	v_mov_b32_e32 v7, v6                                       // 000000A7FCB4: 7E0E0306
	v_mov_b32_e32 v6, v5                                       // 000000A7FCB8: 7E0C0305
	v_mov_b32_e32 v5, v4                                       // 000000A7FCBC: 7E0A0304
	v_mov_b32_e32 v4, v3                                       // 000000A7FCC0: 7E080303
	v_mov_b32_e32 v3, v2                                       // 000000A7FCC4: 7E060302
	v_mov_b32_e32 v2, v1                                       // 000000A7FCC8: 7E040301
	s_mul_hi_i32 s3, s25, 0x50000                              // 000000A7FCCC: 9703FF19 00050000
	s_mul_i32 s5, s25, 0x50000                                 // 000000A7FCD4: 9605FF19 00050000
	s_barrier                                                  // 000000A7FCDC: BFBD0000
	buffer_gl0_inv                                             // 000000A7FCE0: E0AC0000 00000000
	s_and_saveexec_b32 s1, vcc_lo                              // 000000A7FCE8: BE81206A
	s_cbranch_execz 49                                         // 000000A7FCEC: BFA50031 <_ZN7halogen12_GLOBAL__N_112k_ht_gemv_guILi4ELi8ELi1EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_S5_PDF16_+0x2b4>
	v_mul_u32_u24_e32 v2, 0xa000, v24                          // 000000A7FCF0: 160430FF 0000A000
	s_add_u32 s0, s16, s4                                      // 000000A7FCF8: 80000410
	s_addc_u32 s6, s17, s2                                     // 000000A7FCFC: 82060211
	s_add_u32 s0, s0, s5                                       // 000000A7FD00: 80000500
	s_addc_u32 s6, s6, s3                                      // 000000A7FD04: 82060306
	.long 0xd7000002                                           // 000000A7FD08: D7000002
	v_cndmask_b32_e32 v1, s0, v2, vcc_lo                       // 000000A7FD0C: 02020400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A7FD10: BF870111
	v_add_co_ci_u32_e64 v3, null, s6, 0, s0                    // 000000A7FD14: D5207C03 00010006
	.long 0xd7000014                                           // 000000A7FD1C: D7000014
	v_cndmask_b32_e32 v1, v2, v26, vcc_lo                      // 000000A7FD20: 02023502
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A7FD24: BF870001
	v_add_co_ci_u32_e64 v21, null, 0, v3, s0                   // 000000A7FD28: D5207C15 00020680
	s_clause 0xf                                               // 000000A7FD30: BF85000F
	global_load_b32 v2, v[20:21], off                          // 000000A7FD34: DC520000 027C0014
	global_load_b32 v3, v[20:21], off offset:128               // 000000A7FD3C: DC520080 037C0014
	global_load_b32 v4, v[20:21], off offset:256               // 000000A7FD44: DC520100 047C0014
	global_load_b32 v5, v[20:21], off offset:384               // 000000A7FD4C: DC520180 057C0014
	global_load_b32 v6, v[20:21], off offset:512               // 000000A7FD54: DC520200 067C0014
	global_load_b32 v7, v[20:21], off offset:640               // 000000A7FD5C: DC520280 077C0014
	global_load_b32 v8, v[20:21], off offset:768               // 000000A7FD64: DC520300 087C0014
	global_load_b32 v9, v[20:21], off offset:896               // 000000A7FD6C: DC520380 097C0014
	global_load_b32 v10, v[20:21], off offset:1024             // 000000A7FD74: DC520400 0A7C0014
	global_load_b32 v11, v[20:21], off offset:1152             // 000000A7FD7C: DC520480 0B7C0014
	global_load_b32 v12, v[20:21], off offset:1280             // 000000A7FD84: DC520500 0C7C0014
	global_load_b32 v13, v[20:21], off offset:1408             // 000000A7FD8C: DC520580 0D7C0014
	global_load_b32 v14, v[20:21], off offset:1536             // 000000A7FD94: DC520600 0E7C0014
	global_load_b32 v15, v[20:21], off offset:1664             // 000000A7FD9C: DC520680 0F7C0014
	global_load_b32 v16, v[20:21], off offset:1792             // 000000A7FDA4: DC520700 107C0014
	global_load_b32 v17, v[20:21], off offset:1920             // 000000A7FDAC: DC520780 117C0014
	s_or_b32 exec_lo, exec_lo, s1                              // 000000A7FDB4: 8C7E017E
	v_dual_mov_b32 v29, 0 :: v_dual_mov_b32 v30, 0             // 000000A7FDB8: CA100080 1D1E0080
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v32, 0             // 000000A7FDC0: CA100080 1F200080
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v34, 0             // 000000A7FDC8: CA100080 21220080
	v_dual_mov_b32 v35, 0 :: v_dual_mov_b32 v36, 0             // 000000A7FDD0: CA100080 23240080
	v_dual_mov_b32 v37, 0 :: v_dual_mov_b32 v38, 0             // 000000A7FDD8: CA100080 25260080
	v_dual_mov_b32 v39, 0 :: v_dual_mov_b32 v40, 0             // 000000A7FDE0: CA100080 27280080
	v_dual_mov_b32 v41, 0 :: v_dual_mov_b32 v42, 0             // 000000A7FDE8: CA100080 292A0080
	v_mov_b32_e32 v28, 0                                       // 000000A7FDF0: 7E380280
	s_and_saveexec_b32 s1, vcc_lo                              // 000000A7FDF4: BE81206A
	s_cbranch_execz 1871                                       // 000000A7FDF8: BFA5074F <_ZN7halogen12_GLOBAL__N_112k_ht_gemv_guILi4ELi8ELi1EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_S5_PDF16_+0x2038>
	v_dual_mov_b32 v28, 0 :: v_dual_lshlrev_b32 v1, 5, v25     // 000000A7FDFC: CA220080 1C003285
	v_cmp_ne_u32_e32 vcc_lo, 0, v25                            // 000000A7FE04: 7C9A3280
	v_dual_mov_b32 v39, 0 :: v_dual_lshlrev_b32 v30, 11, v18   // 000000A7FE08: CA220080 271E248B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000A7FE10: BF870143
	v_dual_mov_b32 v41, 0 :: v_dual_add_nc_u32 v20, 0x3f0, v1  // 000000A7FE14: CA200080 291402FF 000003F0
	s_add_u32 s0, s4, s5                                       // 000000A7FE20: 80000504
	s_addc_u32 s2, s2, s3                                      // 000000A7FE24: 82020302
	v_mul_u32_u24_e32 v21, 0x840, v24                          // 000000A7FE28: 162A30FF 00000840
	v_lshrrev_b32_e32 v22, 5, v20                              // 000000A7FE30: 322C2885
	v_dual_mov_b32 v37, 0 :: v_dual_and_b32 v20, 0x7e0, v20    // 000000A7FE34: CA240080 251428FF 000007E0
	v_mad_u32_u24 v29, 0x840, v24, v26                         // 000000A7FE40: D60B001D 046A30FF 00000840
	v_sub_nc_u32_e32 v45, 0, v19                               // 000000A7FE4C: 4C5A2680
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A7FE50: BF870004
	v_subrev_nc_u32_e32 v22, 32, v22                           // 000000A7FE54: 4E2C2CA0
	v_and_b32_e32 v23, 16, v0                                  // 000000A7FE58: 362E0090
	v_sub_nc_u32_e32 v1, v20, v1                               // 000000A7FE5C: 4C020314
	v_add_nc_u32_e32 v46, 1, v18                               // 000000A7FE60: 4A5C2481
	v_dual_mov_b32 v40, 0 :: v_dual_add_nc_u32 v47, 0x1400, v29// 000000A7FE64: CA200080 282E3AFF 00001400
	v_cndmask_b32_e32 v22, 31, v22, vcc_lo                     // 000000A7FE70: 022C2C9F
	v_lshl_or_b32 v43, v18, 5, v23                             // 000000A7FE74: D656002B 045D0B12
	.long 0xd7000017                                           // 000000A7FE7C: D7000017
	v_cndmask_b32_e32 v1, s0, v30, vcc_lo                      // 000000A7FE80: 02023C00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A7FE84: BF870211
	v_add_co_ci_u32_e64 v30, null, s2, 0, s0                   // 000000A7FE88: D5207C1E 00010002
	v_dual_mov_b32 v42, 0 :: v_dual_add_nc_u32 v31, 1, v22     // 000000A7FE90: CA200080 2A1E2C81
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A7FE98: BF870093
	.long 0xd7006a17                                           // 000000A7FE9C: D7006A17
	v_cndmask_b32_e32 v1, v23, v26, vcc_lo                     // 000000A7FEA0: 02023517
	v_add_co_ci_u32_e64 v30, null, 0, v30, vcc_lo              // 000000A7FEA4: D5207C1E 01AA3C80
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A7FEAC: BF870193
	v_dual_mov_b32 v35, 0 :: v_dual_and_b32 v20, 31, v31       // 000000A7FEB0: CA240080 23143E9F
	.long 0xd7006a17                                           // 000000A7FEB8: D7006A17
	v_cndmask_b32_e32 v1, s16, v23, vcc_lo                     // 000000A7FEBC: 02022E10
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000A7FEC0: BF8700D1
	v_add_co_ci_u32_e64 v30, null, s17, v30, vcc_lo            // 000000A7FEC4: D5207C1E 01AA3C11
	v_dual_mov_b32 v33, 0 :: v_dual_add_nc_u32 v44, 0xfffffc30, v1// 000000A7FECC: CA200080 212C02FF FFFFFC30
	v_lshl_add_u32 v1, v22, 2, v21                             // 000000A7FED8: D6460001 04550516
	v_lshl_add_u32 v20, v20, 2, v21                            // 000000A7FEE0: D6460014 04550514
	.long 0xd7006a16                                           // 000000A7FEE8: D7006A16
	v_cndmask_b32_e32 v1, 0x800, v23, vcc_lo                   // 000000A7FEEC: 02022EFF 00000800
	v_add_co_ci_u32_e64 v23, null, 0, v30, vcc_lo              // 000000A7FEF4: D5207C17 01AA3C80
	v_dual_mov_b32 v29, 0 :: v_dual_add_nc_u32 v48, 0x1800, v29// 000000A7FEFC: CA200080 1D303AFF 00001800
	v_dual_mov_b32 v38, 0 :: v_dual_add_nc_u32 v49, 0x1400, v1 // 000000A7FF08: CA200080 263002FF 00001400
	v_add_nc_u32_e32 v50, 0x1400, v20                          // 000000A7FF14: 4A6428FF 00001400
	v_dual_mov_b32 v36, 0 :: v_dual_add_nc_u32 v51, 0x1800, v1 // 000000A7FF1C: CA200080 243202FF 00001800
	v_add_nc_u32_e32 v52, 0x1800, v20                          // 000000A7FF28: 4A6828FF 00001800
	v_mov_b32_e32 v34, 0                                       // 000000A7FF30: 7E440280
	v_dual_mov_b32 v32, 0 :: v_dual_mov_b32 v31, 0             // 000000A7FF34: CA100080 201E0080
	v_dual_mov_b32 v30, 0 :: v_dual_mov_b32 v1, 0              // 000000A7FF3C: CA100080 1E000080
	s_mov_b32 s2, 0                                            // 000000A7FF44: BE820080
	s_movk_i32 s3, 0x1eee                                      // 000000A7FF48: B0031EEE
	s_branch 1723                                              // 000000A7FF4C: BFA006BB <_ZN7halogen12_GLOBAL__N_112k_ht_gemv_guILi4ELi8ELi1EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_S5_PDF16_+0x1f3c>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A7FF50: 8C7E007E
	ds_load_2addr_b32 v[53:54], v50 offset1:32                 // 000000A7FF54: D8DC2000 35000032
	ds_load_2addr_b32 v[63:64], v47 offset1:32                 // 000000A7FF5C: D8DC2000 3F00002F
	ds_load_2addr_b32 v[57:58], v49 offset1:32                 // 000000A7FF64: D8DC2000 39000031
	ds_load_b128 v[18:21], v43                                 // 000000A7FF6C: DBFC0000 1200002B
	ds_load_2addr_b32 v[59:60], v49 offset0:64 offset1:96      // 000000A7FF74: D8DC6040 3B000031
	ds_load_2addr_b32 v[61:62], v50 offset0:64 offset1:96      // 000000A7FF7C: D8DC6040 3D000032
	.long 0xd7000016                                           // 000000A7FF84: D7000016
	v_cndmask_b32_e32 v1, 0x800, v22, vcc_lo                   // 000000A7FF88: 02022CFF 00000800
	v_add_nc_u32_e32 v43, 32, v43                              // 000000A7FF90: 4A5656A0
	v_add_co_ci_u32_e64 v23, null, 0, v23, s0                  // 000000A7FF94: D5207C17 00022E80
	s_waitcnt lgkmcnt(5)                                       // 000000A7FF9C: BF89FC57
	v_mov_b32_e32 v56, v53                                     // 000000A7FFA0: 7E700335
	s_waitcnt lgkmcnt(4)                                       // 000000A7FFA4: BF89FC47
	v_bfe_u32 v53, v63, 12, 16                                 // 000000A7FFA8: D6100035 0241193F
	v_bfe_u32 v65, v63, 8, 16                                  // 000000A7FFB0: D6100041 0241113F
	v_bfe_u32 v66, v63, 4, 16                                  // 000000A7FFB8: D6100042 0241093F
	v_and_b32_e32 v63, 0xffff, v63                             // 000000A7FFC0: 367E7EFF 0000FFFF
	s_waitcnt lgkmcnt(3)                                       // 000000A7FFC8: BF89FC37
	.long 0xd73d0038                                           // 000000A7FFCC: D73D0038
	v_cndmask_b32_e32 v1, v44, v56, vcc_lo                     // 000000A7FFD0: 0202712C
	v_mov_b32_e32 v55, v58                                     // 000000A7FFD4: 7E6E033A
	v_bfe_u32 v58, v64, 12, 16                                 // 000000A7FFD8: D610003A 02411940
	v_bfe_u32 v67, v64, 8, 16                                  // 000000A7FFE0: D6100043 02411140
	v_bfe_u32 v68, v64, 4, 16                                  // 000000A7FFE8: D6100044 02410940
	v_and_b32_e32 v64, 0xffff, v64                             // 000000A7FFF0: 368080FF 0000FFFF
	.long 0xd72c0039                                           // 000000A7FFF8: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000A7FFFC: 02026AFF 83DCD12D
	.long 0xd73d0035                                           // 000000A80004: D73D0035
	v_cndmask_b32_e32 v1, v44, v54, vcc_lo                     // 000000A80008: 02026D2C
	v_bfe_u32 v55, v56, 12, 16                                 // 000000A8000C: D6100037 02411938
	.long 0xd72c0036                                           // 000000A80014: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A80018: 020274FF 83DCD12D
	v_bfe_u32 v58, v56, 8, 16                                  // 000000A80020: D610003A 02411138
	v_bfe_u32 v69, v56, 4, 16                                  // 000000A80028: D6100045 02410938
	v_and_b32_e32 v56, 0xffff, v56                             // 000000A80030: 367070FF 0000FFFF
	.long 0xd72c0037                                           // 000000A80038: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000A8003C: 02026EFF 83DCD12D
	.long 0xd72c0041                                           // 000000A80044: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000A80048: 020282FF 83DCD12D
	.long 0xd72c003a                                           // 000000A80050: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A80054: 020274FF 83DCD12D
	v_sad_u8 v57, v57, 0, 0x6400                               // 000000A8005C: D6220039 03FD0139 00006400
	.long 0xd72c0038                                           // 000000A80068: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000A8006C: 020270FF 83DCD12D
	.long 0xd72c0045                                           // 000000A80074: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 000000A80078: 02028AFF 83DCD12D
	v_bfe_u32 v70, v53, 12, 16                                 // 000000A80080: D6100046 02411935
	v_bfe_u32 v71, v53, 8, 16                                  // 000000A80088: D6100047 02411135
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000A80090: D6220037 03FD0137 00006400
	v_bfe_u32 v72, v53, 4, 16                                  // 000000A8009C: D6100048 02410935
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000A800A4: D622003A 03FD013A 00006400
	v_sad_u8 v65, v65, 0, 0x6400                               // 000000A800B0: D6220041 03FD0141 00006400
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000A800BC: D6220038 03FD0138 00006400
	v_and_b32_e32 v55, 0xffff, v55                             // 000000A800C8: 366E6EFF 0000FFFF
	.long 0xd72c003f                                           // 000000A800D0: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000A800D4: 02027EFF 83DCD12D
	.long 0xd72c0042                                           // 000000A800DC: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 000000A800E0: 020284FF 83DCD12D
	.long 0xd72c0046                                           // 000000A800E8: D72C0046
	v_cndmask_b32_e32 v1, 0x83dcd12d, v70, vcc_lo              // 000000A800EC: 02028CFF 83DCD12D
	v_lshlrev_b32_e32 v56, 16, v56                             // 000000A800F4: 30707090
	v_lshl_or_b32 v55, v58, 16, v55                            // 000000A800F8: D6560037 04DD213A
	.long 0xd72c0047                                           // 000000A80100: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000A80104: 02028EFF 83DCD12D
	.long 0xd72c0043                                           // 000000A8010C: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000A80110: 020286FF 83DCD12D
	v_sad_u8 v54, v54, 0, 0x6400                               // 000000A80118: D6220036 03FD0136 00006400
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000A80124: D622003F 03FD013F 00006400
	v_pk_fma_f16 v55, v55, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A80130: CC0E0037 0BFC0737 0000C931
	v_and_b32_e32 v53, 0xffff, v53                             // 000000A8013C: 366A6AFF 0000FFFF
	v_sad_u8 v66, v66, 0, 0x6400                               // 000000A80144: D6220042 03FD0142 00006400
	.long 0xd72c0048                                           // 000000A80150: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000A80154: 020290FF 83DCD12D
	.long 0xd72c0040                                           // 000000A8015C: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000A80160: 020280FF 83DCD12D
	s_waitcnt lgkmcnt(2)                                       // 000000A80168: BF89FC27
	v_dual_dot2acc_f32_f16 v28, v55, v18 :: v_dual_and_b32 v57, 0xffff, v57// 000000A8016C: CB242537 1C3872FF 0000FFFF
	.long 0xd72c0035                                           // 000000A80178: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000A8017C: 02026AFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A80184: BF8701A2
	v_lshl_or_b32 v57, v65, 16, v57                            // 000000A80188: D6560039 04E52141
	v_sad_u8 v65, v69, 0, 0x6400                               // 000000A80190: D6220041 03FD0145 00006400
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000A8019C: D6220035 03FD0135 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A801A8: BF870193
	v_pk_fma_f16 v69, v57, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A801AC: CC0E0045 0BFC0739 0000C931
	v_and_or_b32 v56, 0xffff, v65, v56                         // 000000A801B8: D6570038 04E282FF 0000FFFF
	v_sad_u8 v65, v72, 0, 0x6400                               // 000000A801C4: D6220041 03FD0148 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A801D0: BF870092
	v_pk_fma_f16 v56, v56, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A801D4: CC0E0038 0BFC0738 0000C931
	v_dot2acc_f32_f16 v28, v56, v19                            // 000000A801E0: 04382738
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A801E4: BF870091
	v_dual_dot2acc_f32_f16 v28, v69, v20 :: v_dual_lshlrev_b32 v63, 16, v63// 000000A801E8: CB222945 1C3E7E90
	v_and_or_b32 v58, 0xffff, v66, v63                         // 000000A801F0: D657003A 04FE84FF 0000FFFF
	v_sad_u8 v63, v70, 0, 0x6400                               // 000000A801FC: D622003F 03FD0146 00006400
	v_sad_u8 v66, v71, 0, 0x6400                               // 000000A80208: D6220042 03FD0147 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A80214: BF8701A3
	v_pk_fma_f16 v70, v58, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A80218: CC0E0046 0BFC073A 0000C931
	s_waitcnt lgkmcnt(0)                                       // 000000A80224: BF89FC07
	v_dual_mov_b32 v58, v61 :: v_dual_and_b32 v63, 0xffff, v63 // 000000A80228: CA24013D 3A3E7EFF 0000FFFF
	v_sad_u8 v61, v67, 0, 0x6400                               // 000000A80234: D622003D 03FD0143 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A80240: BF870193
	v_dot2acc_f32_f16 v28, v70, v21                            // 000000A80244: 04382B46
	v_lshl_or_b32 v63, v66, 16, v63                            // 000000A80248: D656003F 04FD2142
	v_and_b32_e32 v66, 0xffff, v54                             // 000000A80250: 36846CFF 0000FFFF
	.long 0xd73d0038                                           // 000000A80258: D73D0038
	v_cndmask_b32_e32 v1, v44, v58, vcc_lo                     // 000000A8025C: 0202752C
	v_sad_u8 v59, v64, 0, 0x6400                               // 000000A80260: D622003B 03FD0140 00006400
	ds_load_2addr_b32 v[54:55], v47 offset0:64 offset1:96      // 000000A8026C: D8DC6040 3600002F
	v_pk_fma_f16 v58, v63, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A80274: CC0E003A 0BFC073F 0000C931
	v_lshl_or_b32 v57, v61, 16, v66                            // 000000A80280: D6560039 0509213D
	v_bfe_u32 v61, v56, 12, 16                                 // 000000A80288: D610003D 02411938
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A80290: BF870193
	v_dual_dot2acc_f32_f16 v42, v58, v18 :: v_dual_lshlrev_b32 v59, 16, v59// 000000A80294: CB22253A 2A3A7690
	v_pk_fma_f16 v64, v57, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A8029C: CC0E0040 0BFC0739 0000C931
	v_lshlrev_b32_e32 v53, 16, v53                             // 000000A802A8: 306A6A90
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A802AC: BF870114
	.long 0xd72c003d                                           // 000000A802B0: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000A802B4: 02027AFF 83DCD12D
	v_and_or_b32 v53, 0xffff, v65, v53                         // 000000A802BC: D6570035 04D682FF 0000FFFF
	.long 0xd72c0041                                           // 000000A802C8: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 000000A802CC: 020288FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A802D4: BF870193
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000A802D8: D622003D 03FD013D 00006400
	v_pk_fma_f16 v53, v53, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A802E4: CC0E0035 0BFC0735 0000C931
	v_and_b32_e32 v63, 0xffff, v56                             // 000000A802F0: 367E70FF 0000FFFF
	s_waitcnt lgkmcnt(0)                                       // 000000A802F8: BF89FC07
	v_bfe_u32 v66, v54, 12, 16                                 // 000000A802FC: D6100042 02411936
	v_bfe_u32 v67, v54, 8, 16                                  // 000000A80304: D6100043 02411136
	v_sad_u8 v57, v65, 0, 0x6400                               // 000000A8030C: D6220039 03FD0141 00006400
	v_bfe_u32 v65, v56, 8, 16                                  // 000000A80318: D6100041 02411138
	v_and_b32_e32 v61, 0xffff, v61                             // 000000A80320: 367A7AFF 0000FFFF
	v_bfe_u32 v56, v56, 4, 16                                  // 000000A80328: D6100038 02410938
	v_dot2acc_f32_f16 v42, v53, v19                            // 000000A80330: 04542735
	.long 0xd72c003f                                           // 000000A80334: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000A80338: 02027EFF 83DCD12D
	.long 0xd72c0041                                           // 000000A80340: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000A80344: 020282FF 83DCD12D
	v_and_or_b32 v57, 0xffff, v57, v59                         // 000000A8034C: D6570039 04EE72FF 0000FFFF
	.long 0xd72c0038                                           // 000000A80358: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000A8035C: 020270FF 83DCD12D
	.long 0xd72c0042                                           // 000000A80364: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 000000A80368: 020284FF 83DCD12D
	.long 0xd72c0043                                           // 000000A80370: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000A80374: 020286FF 83DCD12D
	v_dot2acc_f32_f16 v42, v64, v20                            // 000000A8037C: 04542940
	v_bfe_u32 v68, v54, 4, 16                                  // 000000A80380: D6100044 02410936
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000A80388: D622003F 03FD013F 00006400
	v_sad_u8 v65, v65, 0, 0x6400                               // 000000A80394: D6220041 03FD0141 00006400
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000A803A0: D6220038 03FD0138 00006400
	v_sad_u8 v66, v66, 0, 0x6400                               // 000000A803AC: D6220042 03FD0142 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A803B8: BF8701B3
	v_lshl_or_b32 v59, v65, 16, v61                            // 000000A803BC: D656003B 04F52141
	v_sad_u8 v65, v67, 0, 0x6400                               // 000000A803C4: D6220041 03FD0143 00006400
	.long 0xd72c003d                                           // 000000A803D0: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 000000A803D4: 020288FF 83DCD12D
	v_pk_fma_f16 v58, v59, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A803DC: CC0E003A 0BFC073B 0000C931
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000A803E8: BF8701C1
	v_dot2acc_f32_f16 v41, v58, v18                            // 000000A803EC: 0452253A
	v_pk_fma_f16 v58, v57, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A803F0: CC0E003A 0BFC0739 0000C931
	v_lshlrev_b32_e32 v63, 16, v63                             // 000000A803FC: 307E7E90
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000A80400: D622003D 03FD013D 00006400
	v_dot2acc_f32_f16 v42, v58, v21                            // 000000A8040C: 04542B3A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000A80410: BF870123
	v_and_or_b32 v56, 0xffff, v56, v63                         // 000000A80414: D6570038 04FE70FF 0000FFFF
	v_and_b32_e32 v63, 0xffff, v66                             // 000000A80420: 367E84FF 0000FFFF
	v_pk_fma_f16 v56, v56, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A80428: CC0E0038 0BFC0738 0000C931
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A80434: BF8701A2
	v_lshl_or_b32 v59, v65, 16, v63                            // 000000A80438: D656003B 04FD2141
	v_mov_b32_e32 v63, v60                                     // 000000A80440: 7E7E033C
	v_dot2acc_f32_f16 v41, v56, v19                            // 000000A80444: 04522738
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A80448: BF870223
	v_pk_fma_f16 v53, v59, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A8044C: CC0E0035 0BFC073B 0000C931
	v_and_b32_e32 v54, 0xffff, v54                             // 000000A80458: 366C6CFF 0000FFFF
	.long 0xd73d0038                                           // 000000A80460: D73D0038
	v_cndmask_b32_e32 v1, v44, v62, vcc_lo                     // 000000A80464: 02027D2C
	v_bfe_u32 v62, v55, 8, 16                                  // 000000A80468: D610003E 02411137
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A80470: BF870214
	v_dot2acc_f32_f16 v41, v53, v20                            // 000000A80474: 04522935
	.long 0xd72c0036                                           // 000000A80478: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 000000A8047C: 02026CFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000A80484: BF870244
	v_bfe_u32 v53, v56, 12, 16                                 // 000000A80488: D6100035 02411938
	v_bfe_u32 v57, v56, 8, 16                                  // 000000A80490: D6100039 02411138
	v_bfe_u32 v58, v56, 4, 16                                  // 000000A80498: D610003A 02410938
	v_and_b32_e32 v60, 0xffff, v56                             // 000000A804A0: 367870FF 0000FFFF
	.long 0xd72c003b                                           // 000000A804A8: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000A804AC: 02026AFF 83DCD12D
	v_sad_u8 v54, v54, 0, 0x6400                               // 000000A804B4: D6220036 03FD0136 00006400
	.long 0xd72c003f                                           // 000000A804C0: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 000000A804C4: 020272FF 83DCD12D
	ds_load_2addr_b32 v[56:57], v49 offset0:128 offset1:160    // 000000A804CC: D8DCA080 38000031
	v_and_b32_e32 v64, 0xffff, v55                             // 000000A804D4: 36806EFF 0000FFFF
	.long 0xd72c003a                                           // 000000A804DC: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A804E0: 020274FF 83DCD12D
	v_lshlrev_b32_e32 v54, 16, v54                             // 000000A804E8: 306C6C90
	.long 0xd72c003c                                           // 000000A804EC: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000A804F0: 020278FF 83DCD12D
	v_sad_u8 v59, v59, 0, 0x6400                               // 000000A804F8: D622003B 03FD013B 00006400
	.long 0xd72c0040                                           // 000000A80504: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000A80508: 020280FF 83DCD12D
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000A80510: D622003F 03FD013F 00006400
	v_and_or_b32 v54, 0xffff, v61, v54                         // 000000A8051C: D6570036 04DA7AFF 0000FFFF
	v_bfe_u32 v61, v55, 12, 16                                 // 000000A80528: D610003D 02411937
	v_bfe_u32 v55, v55, 4, 16                                  // 000000A80530: D6100037 02410937
	v_sad_u8 v66, v58, 0, 0x6400                               // 000000A80538: D6220042 03FD013A 00006400
	v_and_b32_e32 v65, 0xffff, v59                             // 000000A80544: 368276FF 0000FFFF
	v_pk_fma_f16 v54, v54, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A8054C: CC0E0036 0BFC0736 0000C931
	.long 0xd72c003d                                           // 000000A80558: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000A8055C: 02027AFF 83DCD12D
	v_sad_u8 v58, v60, 0, 0x6400                               // 000000A80564: D622003A 03FD013C 00006400
	v_sad_u8 v64, v64, 0, 0x6400                               // 000000A80570: D6220040 03FD0140 00006400
	v_lshl_or_b32 v63, v63, 16, v65                            // 000000A8057C: D656003F 0505213F
	v_dot2acc_f32_f16 v41, v54, v21                            // 000000A80584: 04522B36
	ds_load_2addr_b32 v[53:54], v50 offset0:128 offset1:160    // 000000A80588: D8DCA080 35000032
	v_sad_u8 v60, v61, 0, 0x6400                               // 000000A80590: D622003C 03FD013D 00006400
	.long 0xd72c003d                                           // 000000A8059C: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000A805A0: 02027CFF 83DCD12D
	.long 0xd72c003e                                           // 000000A805A8: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000A805AC: 02026EFF 83DCD12D
	s_waitcnt lgkmcnt(0)                                       // 000000A805B4: BF89FC07
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A805B8: BF870003
	v_dual_mov_b32 v55, v53 :: v_dual_and_b32 v60, 0xffff, v60 // 000000A805BC: CA240135 373C78FF 0000FFFF
	v_lshlrev_b32_e32 v53, 16, v58                             // 000000A805C8: 306A7490
	ds_load_2addr_b32 v[58:59], v47 offset0:128 offset1:160    // 000000A805CC: D8DCA080 3A00002F
	.long 0xd73d0037                                           // 000000A805D4: D73D0037
	v_cndmask_b32_e32 v1, v44, v55, vcc_lo                     // 000000A805D8: 02026F2C
	v_sad_u8 v56, v61, 0, 0x6400                               // 000000A805DC: D6220038 03FD013D 00006400
	v_sad_u8 v61, v62, 0, 0x6400                               // 000000A805E8: D622003D 03FD013E 00006400
	v_lshlrev_b32_e32 v62, 16, v64                             // 000000A805F4: 307C8090
	v_and_or_b32 v53, 0xffff, v66, v53                         // 000000A805F8: D6570035 04D684FF 0000FFFF
	v_bfe_u32 v64, v55, 12, 16                                 // 000000A80604: D6100040 02411937
	v_lshl_or_b32 v56, v56, 16, v60                            // 000000A8060C: D6560038 04F12138
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A80614: BF870004
	v_and_or_b32 v60, 0xffff, v61, v62                         // 000000A80618: D657003C 04FA7AFF 0000FFFF
	v_pk_fma_f16 v61, v63, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A80624: CC0E003D 0BFC073F 0000C931
	v_pk_fma_f16 v53, v53, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A80630: CC0E0035 0BFC0735 0000C931
	.long 0xd72c003e                                           // 000000A8063C: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000A80640: 020280FF 83DCD12D
	v_and_b32_e32 v63, 0xffff, v55                             // 000000A80648: 367E6EFF 0000FFFF
	v_pk_fma_f16 v56, v56, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A80650: CC0E0038 0BFC0738 0000C931
	v_dot2acc_f32_f16 v40, v61, v18                            // 000000A8065C: 0450253D
	v_bfe_u32 v61, v55, 8, 16                                  // 000000A80660: D610003D 02411137
	v_bfe_u32 v55, v55, 4, 16                                  // 000000A80668: D6100037 02410937
	s_waitcnt lgkmcnt(0)                                       // 000000A80670: BF89FC07
	v_bfe_u32 v64, v58, 12, 16                                 // 000000A80674: D6100040 0241193A
	.long 0xd72c003f                                           // 000000A8067C: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000A80680: 02027EFF 83DCD12D
	v_sad_u8 v62, v62, 0, 0x6400                               // 000000A80688: D622003E 03FD013E 00006400
	.long 0xd72c003d                                           // 000000A80694: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000A80698: 02027AFF 83DCD12D
	v_dot2acc_f32_f16 v40, v53, v19                            // 000000A806A0: 04502735
	v_bfe_u32 v53, v58, 8, 16                                  // 000000A806A4: D6100035 0241113A
	.long 0xd72c0037                                           // 000000A806AC: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000A806B0: 02026EFF 83DCD12D
	v_and_b32_e32 v62, 0xffff, v62                             // 000000A806B8: 367C7CFF 0000FFFF
	.long 0xd72c0040                                           // 000000A806C0: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000A806C4: 020280FF 83DCD12D
	v_bfe_u32 v65, v58, 4, 16                                  // 000000A806CC: D6100041 0241093A
	.long 0xd72c0035                                           // 000000A806D4: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000A806D8: 02026AFF 83DCD12D
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000A806E0: D622003D 03FD013D 00006400
	v_and_b32_e32 v58, 0xffff, v58                             // 000000A806EC: 367474FF 0000FFFF
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000A806F4: D622003F 03FD013F 00006400
	v_dot2acc_f32_f16 v40, v56, v20                            // 000000A80700: 04502938
	v_pk_fma_f16 v60, v60, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A80704: CC0E003C 0BFC073C 0000C931
	v_lshl_or_b32 v61, v61, 16, v62                            // 000000A80710: D656003D 04F9213D
	v_sad_u8 v62, v55, 0, 0x6400                               // 000000A80718: D622003E 03FD0137 00006400
	v_mov_b32_e32 v55, v57                                     // 000000A80724: 7E6E0339
	.long 0xd72c0039                                           // 000000A80728: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A8072C: 020274FF 83DCD12D
	v_sad_u8 v64, v64, 0, 0x6400                               // 000000A80734: D6220040 03FD0140 00006400
	v_sad_u8 v58, v53, 0, 0x6400                               // 000000A80740: D622003A 03FD0135 00006400
	v_lshlrev_b32_e32 v63, 16, v63                             // 000000A8074C: 307E7E90
	.long 0xd73d0035                                           // 000000A80750: D73D0035
	v_cndmask_b32_e32 v1, v44, v54, vcc_lo                     // 000000A80754: 02026D2C
	v_pk_fma_f16 v55, v61, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A80758: CC0E0037 0BFC073D 0000C931
	v_and_b32_e32 v64, 0xffff, v64                             // 000000A80764: 368080FF 0000FFFF
	v_bfe_u32 v67, v59, 4, 16                                  // 000000A8076C: D6100043 0241093B
	v_sad_u8 v56, v57, 0, 0x6400                               // 000000A80774: D6220038 03FD0139 00006400
	v_and_or_b32 v62, 0xffff, v62, v63                         // 000000A80780: D657003E 04FE7CFF 0000FFFF
	v_bfe_u32 v57, v53, 12, 16                                 // 000000A8078C: D6100039 02411935
	v_lshl_or_b32 v54, v58, 16, v64                            // 000000A80794: D6560036 0501213A
	v_bfe_u32 v58, v59, 12, 16                                 // 000000A8079C: D610003A 0241193B
	v_lshlrev_b32_e32 v64, 16, v56                             // 000000A807A4: 30807090
	v_pk_fma_f16 v61, v62, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A807A8: CC0E003D 0BFC073E 0000C931
	.long 0xd72c0038                                           // 000000A807B4: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 000000A807B8: 020272FF 83DCD12D
	v_bfe_u32 v57, v53, 8, 16                                  // 000000A807C0: D6100039 02411135
	v_pk_fma_f16 v62, v54, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A807C8: CC0E003E 0BFC0736 0000C931
	v_and_b32_e32 v54, 0xffff, v53                             // 000000A807D4: 366C6AFF 0000FFFF
	v_bfe_u32 v53, v53, 4, 16                                  // 000000A807DC: D6100035 02410935
	.long 0xd72c003f                                           // 000000A807E4: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000A807E8: 020282FF 83DCD12D
	.long 0xd72c0039                                           // 000000A807F0: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 000000A807F4: 020272FF 83DCD12D
	v_bfe_u32 v65, v59, 8, 16                                  // 000000A807FC: D6100041 0241113B
	.long 0xd72c0042                                           // 000000A80804: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 000000A80808: 02026CFF 83DCD12D
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000A80810: D6220038 03FD0138 00006400
	.long 0xd72c0044                                           // 000000A8081C: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000A80820: 02026AFF 83DCD12D
	ds_load_2addr_b32 v[53:54], v50 offset0:192 offset1:224    // 000000A80828: D8DCE0C0 35000032
	v_dual_dot2acc_f32_f16 v40, v60, v21 :: v_dual_and_b32 v59, 0xffff, v59// 000000A80830: CB242B3C 283A76FF 0000FFFF
	.long 0xd72c003a                                           // 000000A8083C: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A80840: 020274FF 83DCD12D
	v_and_b32_e32 v69, 0xffff, v56                             // 000000A80848: 368A70FF 0000FFFF
	v_sad_u8 v70, v57, 0, 0x6400                               // 000000A80850: D6220046 03FD0139 00006400
	ds_load_2addr_b32 v[56:57], v49 offset0:192 offset1:224    // 000000A8085C: D8DCE0C0 38000031
	.long 0xd72c0041                                           // 000000A80864: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000A80868: 020282FF 83DCD12D
	.long 0xd72c003b                                           // 000000A80870: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000A80874: 020276FF 83DCD12D
	v_sad_u8 v66, v66, 0, 0x6400                               // 000000A8087C: D6220042 03FD0142 00006400
	.long 0xd72c0043                                           // 000000A80888: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000A8088C: 020286FF 83DCD12D
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000A80894: D622003A 03FD013A 00006400
	v_sad_u8 v68, v68, 0, 0x6400                               // 000000A808A0: D6220044 03FD0144 00006400
	v_dot2acc_f32_f16 v39, v55, v18                            // 000000A808AC: 044E2537
	v_lshlrev_b32_e32 v66, 16, v66                             // 000000A808B0: 30848490
	v_lshl_or_b32 v55, v70, 16, v69                            // 000000A808B4: D6560037 05152146
	v_and_b32_e32 v58, 0xffff, v58                             // 000000A808BC: 367474FF 0000FFFF
	v_sad_u8 v65, v65, 0, 0x6400                               // 000000A808C4: D6220041 03FD0141 00006400
	v_sad_u8 v59, v59, 0, 0x6400                               // 000000A808D0: D622003B 03FD013B 00006400
	v_and_or_b32 v66, 0xffff, v68, v66                         // 000000A808DC: D6570042 050A88FF 0000FFFF
	v_pk_fma_f16 v68, v55, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A808E8: CC0E0044 0BFC0737 0000C931
	s_waitcnt lgkmcnt(1)                                       // 000000A808F4: BF89FC17
	v_mov_b32_e32 v55, v53                                     // 000000A808F8: 7E6E0335
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000A808FC: D622003F 03FD013F 00006400
	v_lshl_or_b32 v53, v65, 16, v58                            // 000000A80908: D6560035 04E92141
	v_sad_u8 v65, v67, 0, 0x6400                               // 000000A80910: D6220041 03FD0143 00006400
	v_lshlrev_b32_e32 v67, 16, v59                             // 000000A8091C: 30867690
	ds_load_2addr_b32 v[58:59], v47 offset0:192 offset1:224    // 000000A80920: D8DCE0C0 3A00002F
	s_waitcnt lgkmcnt(1)                                       // 000000A80928: BF89FC17
	.long 0xd73d0037                                           // 000000A8092C: D73D0037
	v_cndmask_b32_e32 v1, v44, v55, vcc_lo                     // 000000A80930: 02026F2C
	v_pk_fma_f16 v66, v66, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A80934: CC0E0042 0BFC0742 0000C931
	v_dot2acc_f32_f16 v38, v68, v18                            // 000000A80940: 044C2544
	v_and_or_b32 v56, 0xffff, v63, v64                         // 000000A80944: D6570038 05027EFF 0000FFFF
	v_dot2acc_f32_f16 v39, v61, v19                            // 000000A80950: 044E273D
	v_pk_fma_f16 v53, v53, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A80954: CC0E0035 0BFC0735 0000C931
	v_bfe_u32 v63, v55, 12, 16                                 // 000000A80960: D610003F 02411937
	v_dot2acc_f32_f16 v38, v66, v19                            // 000000A80968: 044C2742
	v_pk_fma_f16 v56, v56, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A8096C: CC0E0038 0BFC0738 0000C931
	v_dot2acc_f32_f16 v39, v62, v20                            // 000000A80978: 044E293E
	v_and_or_b32 v61, 0xffff, v65, v67                         // 000000A8097C: D657003D 050E82FF 0000FFFF
	v_bfe_u32 v62, v55, 8, 16                                  // 000000A80988: D610003E 02411137
	v_dot2acc_f32_f16 v38, v53, v20                            // 000000A80990: 044C2935
	.long 0xd72c0035                                           // 000000A80994: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000A80998: 02027EFF 83DCD12D
	v_dot2acc_f32_f16 v39, v56, v21                            // 000000A809A0: 044E2B38
	v_bfe_u32 v56, v55, 4, 16                                  // 000000A809A4: D6100038 02410937
	v_and_b32_e32 v55, 0xffff, v55                             // 000000A809AC: 366E6EFF 0000FFFF
	v_pk_fma_f16 v61, v61, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A809B4: CC0E003D 0BFC073D 0000C931
	.long 0xd72c003c                                           // 000000A809C0: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000A809C4: 02027CFF 83DCD12D
	s_waitcnt lgkmcnt(0)                                       // 000000A809CC: BF89FC07
	v_and_b32_e32 v63, 0xffff, v58                             // 000000A809D0: 367E74FF 0000FFFF
	v_bfe_u32 v62, v58, 8, 16                                  // 000000A809D8: D610003E 0241113A
	.long 0xd72c0037                                           // 000000A809E0: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000A809E4: 02026EFF 83DCD12D
	v_dot2acc_f32_f16 v38, v61, v21                            // 000000A809EC: 044C2B3D
	v_bfe_u32 v61, v58, 12, 16                                 // 000000A809F0: D610003D 0241193A
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000A809F8: D6220035 03FD0135 00006400
	v_bfe_u32 v58, v58, 4, 16                                  // 000000A80A04: D610003A 0241093A
	.long 0xd72c0038                                           // 000000A80A0C: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000A80A10: 020270FF 83DCD12D
	.long 0xd72c003f                                           // 000000A80A18: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000A80A1C: 02027EFF 83DCD12D
	.long 0xd72c003d                                           // 000000A80A24: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000A80A28: 02027AFF 83DCD12D
	v_and_b32_e32 v53, 0xffff, v53                             // 000000A80A30: 366A6AFF 0000FFFF
	v_sad_u8 v60, v60, 0, 0x6400                               // 000000A80A38: D622003C 03FD013C 00006400
	v_sad_u8 v64, v55, 0, 0x6400                               // 000000A80A44: D6220040 03FD0137 00006400
	v_mov_b32_e32 v55, v57                                     // 000000A80A50: 7E6E0339
	.long 0xd72c003e                                           // 000000A80A54: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000A80A58: 02027CFF 83DCD12D
	.long 0xd72c0039                                           // 000000A80A60: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A80A64: 020274FF 83DCD12D
	v_lshl_or_b32 v60, v60, 16, v53                            // 000000A80A6C: D656003C 04D5213C
	v_sad_u8 v58, v61, 0, 0x6400                               // 000000A80A74: D622003A 03FD013D 00006400
	.long 0xd73d0035                                           // 000000A80A80: D73D0035
	v_cndmask_b32_e32 v1, v44, v54, vcc_lo                     // 000000A80A84: 02026D2C
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000A80A88: D6220038 03FD0138 00006400
	v_sad_u8 v61, v63, 0, 0x6400                               // 000000A80A94: D622003D 03FD013F 00006400
	v_lshlrev_b32_e32 v54, 16, v64                             // 000000A80AA0: 306C8090
	v_and_b32_e32 v55, 0xffff, v58                             // 000000A80AA4: 366E74FF 0000FFFF
	v_sad_u8 v58, v62, 0, 0x6400                               // 000000A80AAC: D622003A 03FD013E 00006400
	v_sad_u8 v57, v57, 0, 0x6400                               // 000000A80AB8: D6220039 03FD0139 00006400
	v_lshlrev_b32_e32 v61, 16, v61                             // 000000A80AC4: 307A7A90
	v_pk_fma_f16 v60, v60, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A80AC8: CC0E003C 0BFC073C 0000C931
	v_and_or_b32 v54, 0xffff, v56, v54                         // 000000A80AD4: D6570036 04DA70FF 0000FFFF
	v_bfe_u32 v62, v53, 12, 16                                 // 000000A80AE0: D610003E 02411935
	v_lshl_or_b32 v55, v58, 16, v55                            // 000000A80AE8: D6560037 04DD213A
	v_and_or_b32 v56, 0xffff, v57, v61                         // 000000A80AF0: D6570038 04F672FF 0000FFFF
	v_dot2acc_f32_f16 v37, v60, v18                            // 000000A80AFC: 044A253C
	v_pk_fma_f16 v61, v54, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A80B00: CC0E003D 0BFC0736 0000C931
	.long 0xd72c0039                                           // 000000A80B0C: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000A80B10: 02027CFF 83DCD12D
	v_pk_fma_f16 v62, v55, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A80B18: CC0E003E 0BFC0737 0000C931
	v_bfe_u32 v58, v53, 8, 16                                  // 000000A80B24: D610003A 02411135
	v_pk_fma_f16 v63, v56, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A80B2C: CC0E003F 0BFC0738 0000C931
	v_dual_dot2acc_f32_f16 v37, v61, v19 :: v_dual_and_b32 v54, 0xffff, v53// 000000A80B38: CB24273D 25366AFF 0000FFFF
	v_bfe_u32 v65, v59, 8, 16                                  // 000000A80B44: D6100041 0241113B
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A80B4C: BF870004
	.long 0xd72c0037                                           // 000000A80B50: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A80B54: 020274FF 83DCD12D
	v_sad_u8 v56, v57, 0, 0x6400                               // 000000A80B5C: D6220038 03FD0139 00006400
	v_bfe_u32 v57, v53, 4, 16                                  // 000000A80B68: D6100039 02410935
	v_dot2acc_f32_f16 v37, v62, v20                            // 000000A80B70: 044A293E
	.long 0xd72c003c                                           // 000000A80B74: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 000000A80B78: 02026CFF 83DCD12D
	ds_load_2addr_b32 v[53:54], v52 offset1:32                 // 000000A80B80: D8DC2000 35000034
	v_and_b32_e32 v64, 0xffff, v56                             // 000000A80B88: 368070FF 0000FFFF
	.long 0xd72c0042                                           // 000000A80B90: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 000000A80B94: 020272FF 83DCD12D
	ds_load_2addr_b32 v[56:57], v51 offset1:32                 // 000000A80B9C: D8DC2000 38000033
	v_bfe_u32 v58, v59, 12, 16                                 // 000000A80BA4: D610003A 0241193B
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000A80BAC: D6220037 03FD0137 00006400
	v_and_b32_e32 v67, 0xffff, v59                             // 000000A80BB8: 368676FF 0000FFFF
	v_sad_u8 v60, v60, 0, 0x6400                               // 000000A80BC0: D622003C 03FD013C 00006400
	v_bfe_u32 v59, v59, 4, 16                                  // 000000A80BCC: D610003B 0241093B
	.long 0xd72c003a                                           // 000000A80BD4: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A80BD8: 020274FF 83DCD12D
	v_lshl_or_b32 v55, v55, 16, v64                            // 000000A80BE0: D6560037 05012137
	.long 0xd72c0041                                           // 000000A80BE8: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000A80BEC: 020282FF 83DCD12D
	.long 0xd72c0040                                           // 000000A80BF4: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000A80BF8: 020286FF 83DCD12D
	v_sad_u8 v66, v66, 0, 0x6400                               // 000000A80C00: D6220042 03FD0142 00006400
	v_lshlrev_b32_e32 v60, 16, v60                             // 000000A80C0C: 30787890
	v_pk_fma_f16 v67, v55, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A80C10: CC0E0043 0BFC0737 0000C931
	.long 0xd72c0044                                           // 000000A80C1C: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000A80C20: 020276FF 83DCD12D
	v_sad_u8 v69, v58, 0, 0x6400                               // 000000A80C28: D6220045 03FD013A 00006400
	ds_load_2addr_b32 v[58:59], v48 offset1:32                 // 000000A80C34: D8DC2000 3A000030
	v_and_or_b32 v60, 0xffff, v66, v60                         // 000000A80C3C: D657003C 04F284FF 0000FFFF
	s_waitcnt lgkmcnt(2)                                       // 000000A80C48: BF89FC27
	v_mov_b32_e32 v55, v53                                     // 000000A80C4C: 7E6E0335
	v_sad_u8 v65, v65, 0, 0x6400                               // 000000A80C50: D6220041 03FD0141 00006400
	v_and_b32_e32 v53, 0xffff, v69                             // 000000A80C5C: 366A8AFF 0000FFFF
	v_sad_u8 v64, v64, 0, 0x6400                               // 000000A80C64: D6220040 03FD0140 00006400
	v_dot2acc_f32_f16 v36, v67, v18                            // 000000A80C70: 04482543
	s_waitcnt lgkmcnt(1)                                       // 000000A80C74: BF89FC17
	.long 0xd73d0037                                           // 000000A80C78: D73D0037
	v_cndmask_b32_e32 v1, v44, v55, vcc_lo                     // 000000A80C7C: 02026F2C
	v_pk_fma_f16 v56, v60, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A80C80: CC0E0038 0BFC073C 0000C931
	v_lshl_or_b32 v53, v65, 16, v53                            // 000000A80C8C: D6560035 04D52141
	v_sad_u8 v66, v68, 0, 0x6400                               // 000000A80C94: D6220042 03FD0144 00006400
	v_dual_dot2acc_f32_f16 v37, v63, v21 :: v_dual_lshlrev_b32 v64, 16, v64// 000000A80CA0: CB222B3F 25408090
	v_bfe_u32 v61, v55, 12, 16                                 // 000000A80CA8: D610003D 02411937
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A80CB0: BF870004
	v_pk_fma_f16 v62, v53, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A80CB4: CC0E003E 0BFC0735 0000C931
	v_dot2acc_f32_f16 v36, v56, v19                            // 000000A80CC0: 04482738
	v_bfe_u32 v56, v55, 8, 16                                  // 000000A80CC4: D6100038 02411137
	v_and_or_b32 v60, 0xffff, v66, v64                         // 000000A80CCC: D657003C 050284FF 0000FFFF
	.long 0xd72c0035                                           // 000000A80CD8: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000A80CDC: 02027AFF 83DCD12D
	v_and_b32_e32 v61, 0xffff, v55                             // 000000A80CE4: 367A6EFF 0000FFFF
	v_bfe_u32 v55, v55, 4, 16                                  // 000000A80CEC: D6100037 02410937
	s_waitcnt lgkmcnt(0)                                       // 000000A80CF4: BF89FC07
	v_bfe_u32 v64, v58, 12, 16                                 // 000000A80CF8: D6100040 0241193A
	.long 0xd72c0038                                           // 000000A80D00: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000A80D04: 020270FF 83DCD12D
	v_bfe_u32 v65, v58, 8, 16                                  // 000000A80D0C: D6100041 0241113A
	.long 0xd72c003d                                           // 000000A80D14: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000A80D18: 02027AFF 83DCD12D
	.long 0xd72c0037                                           // 000000A80D20: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000A80D24: 02026EFF 83DCD12D
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000A80D2C: D6220035 03FD0135 00006400
	.long 0xd72c0040                                           // 000000A80D38: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000A80D3C: 020280FF 83DCD12D
	.long 0xd72c0041                                           // 000000A80D44: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000A80D48: 020282FF 83DCD12D
	v_bfe_u32 v66, v58, 4, 16                                  // 000000A80D50: D6100042 0241093A
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000A80D58: D6220038 03FD0138 00006400
	v_and_b32_e32 v53, 0xffff, v53                             // 000000A80D64: 366A6AFF 0000FFFF
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000A80D6C: D622003D 03FD013D 00006400
	v_sad_u8 v67, v55, 0, 0x6400                               // 000000A80D78: D6220043 03FD0137 00006400
	v_mov_b32_e32 v55, v57                                     // 000000A80D84: 7E6E0339
	v_sad_u8 v64, v64, 0, 0x6400                               // 000000A80D88: D6220040 03FD0140 00006400
	v_lshl_or_b32 v56, v56, 16, v53                            // 000000A80D94: D6560038 04D52138
	v_lshlrev_b32_e32 v61, 16, v61                             // 000000A80D9C: 307A7A90
	.long 0xd72c0042                                           // 000000A80DA0: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 000000A80DA4: 020284FF 83DCD12D
	.long 0xd73d0035                                           // 000000A80DAC: D73D0035
	v_cndmask_b32_e32 v1, v44, v54, vcc_lo                     // 000000A80DB0: 02026D2C
	v_and_b32_e32 v57, 0xffff, v64                             // 000000A80DB4: 367280FF 0000FFFF
	v_sad_u8 v64, v65, 0, 0x6400                               // 000000A80DBC: D6220040 03FD0141 00006400
	v_and_or_b32 v54, 0xffff, v67, v61                         // 000000A80DC8: D6570036 04F686FF 0000FFFF
	v_pk_fma_f16 v61, v56, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A80DD4: CC0E003D 0BFC0738 0000C931
	v_bfe_u32 v67, v59, 4, 16                                  // 000000A80DE0: D6100043 0241093B
	v_bfe_u32 v56, v53, 12, 16                                 // 000000A80DE8: D6100038 02411935
	v_lshl_or_b32 v55, v64, 16, v57                            // 000000A80DF0: D6560037 04E52140
	v_pk_fma_f16 v64, v54, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A80DF8: CC0E0040 0BFC0736 0000C931
	v_dot2acc_f32_f16 v35, v61, v18                            // 000000A80E04: 0446253D
	v_and_b32_e32 v58, 0xffff, v58                             // 000000A80E08: 367474FF 0000FFFF
	v_sad_u8 v57, v66, 0, 0x6400                               // 000000A80E10: D6220039 03FD0142 00006400
	v_pk_fma_f16 v65, v55, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A80E1C: CC0E0041 0BFC0737 0000C931
	.long 0xd72c0037                                           // 000000A80E28: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000A80E2C: 020270FF 83DCD12D
	v_dot2acc_f32_f16 v35, v64, v19                            // 000000A80E34: 04462740
	.long 0xd72c003a                                           // 000000A80E38: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A80E3C: 020274FF 83DCD12D
	v_bfe_u32 v56, v53, 8, 16                                  // 000000A80E44: D6100038 02411135
	.long 0xd72c0043                                           // 000000A80E4C: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000A80E50: 020286FF 83DCD12D
	v_pk_fma_f16 v60, v60, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A80E58: CC0E003C 0BFC073C 0000C931
	v_dot2acc_f32_f16 v35, v65, v20                            // 000000A80E64: 04462941
	v_dot2acc_f32_f16 v36, v62, v20                            // 000000A80E68: 0448293E
	.long 0xd72c0038                                           // 000000A80E6C: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000A80E70: 020270FF 83DCD12D
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000A80E78: D6220037 03FD0137 00006400
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000A80E84: D622003A 03FD013A 00006400
	v_sad_u8 v67, v67, 0, 0x6400                               // 000000A80E90: D6220043 03FD0143 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A80E9C: BF870193
	v_dual_dot2acc_f32_f16 v36, v60, v21 :: v_dual_and_b32 v55, 0xffff, v55// 000000A80EA0: CB242B3C 24366EFF 0000FFFF
	v_lshlrev_b32_e32 v58, 16, v58                             // 000000A80EAC: 30747490
	v_sad_u8 v69, v56, 0, 0x6400                               // 000000A80EB0: D6220045 03FD0138 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A80EBC: BF8701A2
	v_and_or_b32 v66, 0xffff, v57, v58                         // 000000A80EC0: D6570042 04EA72FF 0000FFFF
	v_bfe_u32 v57, v59, 12, 16                                 // 000000A80ECC: D6100039 0241193B
	v_lshl_or_b32 v55, v69, 16, v55                            // 000000A80ED4: D6560037 04DD2145
	v_bfe_u32 v58, v59, 8, 16                                  // 000000A80EDC: D610003A 0241113B
	v_and_b32_e32 v59, 0xffff, v59                             // 000000A80EE4: 367676FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A80EEC: BF870214
	.long 0xd72c0039                                           // 000000A80EF0: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 000000A80EF4: 020272FF 83DCD12D
	v_pk_fma_f16 v55, v55, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A80EFC: CC0E0037 0BFC0737 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A80F08: BF870214
	.long 0xd72c003a                                           // 000000A80F0C: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A80F10: 020274FF 83DCD12D
	.long 0xd72c003b                                           // 000000A80F18: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000A80F1C: 020276FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A80F24: BF870003
	v_dot2acc_f32_f16 v34, v55, v18                            // 000000A80F28: 04442537
	v_sad_u8 v71, v57, 0, 0x6400                               // 000000A80F2C: D6220047 03FD0139 00006400
	ds_load_2addr_b32 v[56:57], v51 offset0:64 offset1:96      // 000000A80F38: D8DC6040 38000033
	v_and_b32_e32 v54, 0xffff, v53                             // 000000A80F40: 366C6AFF 0000FFFF
	v_bfe_u32 v53, v53, 4, 16                                  // 000000A80F48: D6100035 02410935
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000A80F50: D622003A 03FD013A 00006400
	v_and_b32_e32 v69, 0xffff, v71                             // 000000A80F5C: 368A8EFF 0000FFFF
	v_sad_u8 v59, v59, 0, 0x6400                               // 000000A80F64: D622003B 03FD013B 00006400
	.long 0xd72c0036                                           // 000000A80F70: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 000000A80F74: 02026CFF 83DCD12D
	.long 0xd72c0035                                           // 000000A80F7C: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000A80F80: 02026AFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A80F88: BF870112
	v_sad_u8 v68, v54, 0, 0x6400                               // 000000A80F8C: D6220044 03FD0136 00006400
	v_sad_u8 v70, v53, 0, 0x6400                               // 000000A80F98: D6220046 03FD0135 00006400
	ds_load_2addr_b32 v[53:54], v52 offset0:64 offset1:96      // 000000A80FA4: D8DC6040 35000034
	s_waitcnt lgkmcnt(0)                                       // 000000A80FAC: BF89FC07
	v_mov_b32_e32 v55, v53                                     // 000000A80FB0: 7E6E0335
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A80FB4: BF8700A1
	.long 0xd73d0037                                           // 000000A80FB8: D73D0037
	v_cndmask_b32_e32 v1, v44, v55, vcc_lo                     // 000000A80FBC: 02026F2C
	v_pk_fma_f16 v56, v66, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A80FC0: CC0E0038 0BFC0742 0000C931
	v_dual_dot2acc_f32_f16 v35, v56, v21 :: v_dual_lshlrev_b32 v68, 16, v68// 000000A80FCC: CB222B38 23448890
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A80FD4: BF870211
	v_and_or_b32 v68, 0xffff, v70, v68                         // 000000A80FD8: D6570044 05128CFF 0000FFFF
	v_and_b32_e32 v56, 0xffff, v55                             // 000000A80FE4: 36706EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2)                            // 000000A80FEC: BF870002
	v_pk_fma_f16 v61, v68, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A80FF0: CC0E003D 0BFC0744 0000C931
	v_lshl_or_b32 v68, v58, 16, v69                            // 000000A80FFC: D6560044 0515213A
	v_lshlrev_b32_e32 v69, 16, v59                             // 000000A81004: 308A7690
	ds_load_2addr_b32 v[58:59], v48 offset0:64 offset1:96      // 000000A81008: D8DC6040 3A000030
	v_dot2acc_f32_f16 v34, v61, v19                            // 000000A81010: 0444273D
	v_pk_fma_f16 v53, v68, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A81014: CC0E0035 0BFC0744 0000C931
	v_and_or_b32 v64, 0xffff, v67, v69                         // 000000A81020: D6570040 051686FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A8102C: BF870112
	v_dot2acc_f32_f16 v34, v53, v20                            // 000000A81030: 04442935
	v_pk_fma_f16 v61, v64, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A81034: CC0E003D 0BFC0740 0000C931
	v_bfe_u32 v53, v55, 12, 16                                 // 000000A81040: D6100035 02411937
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A81048: BF870112
	v_dot2acc_f32_f16 v34, v61, v21                            // 000000A8104C: 04442B3D
	.long 0xd72c0035                                           // 000000A81050: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000A81054: 02026AFF 83DCD12D
	v_bfe_u32 v61, v55, 8, 16                                  // 000000A8105C: D610003D 02411137
	v_bfe_u32 v55, v55, 4, 16                                  // 000000A81064: D6100037 02410937
	s_waitcnt lgkmcnt(0)                                       // 000000A8106C: BF89FC07
	v_bfe_u32 v60, v58, 12, 16                                 // 000000A81070: D610003C 0241193A
	v_bfe_u32 v62, v58, 8, 16                                  // 000000A81078: D610003E 0241113A
	.long 0xd72c003d                                           // 000000A81080: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000A81084: 02027AFF 83DCD12D
	v_bfe_u32 v63, v58, 4, 16                                  // 000000A8108C: D610003F 0241093A
	v_and_b32_e32 v58, 0xffff, v58                             // 000000A81094: 367474FF 0000FFFF
	.long 0xd72c003c                                           // 000000A8109C: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000A810A0: 020278FF 83DCD12D
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000A810A8: D6220035 03FD0135 00006400
	.long 0xd72c0037                                           // 000000A810B4: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000A810B8: 02026EFF 83DCD12D
	.long 0xd72c003e                                           // 000000A810C0: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000A810C4: 02027CFF 83DCD12D
	.long 0xd72c003a                                           // 000000A810CC: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A810D0: 020274FF 83DCD12D
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000A810D8: D622003D 03FD013D 00006400
	v_and_b32_e32 v53, 0xffff, v53                             // 000000A810E4: 366A6AFF 0000FFFF
	.long 0xd72c003f                                           // 000000A810EC: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000A810F0: 02027EFF 83DCD12D
	v_sad_u8 v60, v60, 0, 0x6400                               // 000000A810F8: D622003C 03FD013C 00006400
	v_bfe_u32 v66, v59, 4, 16                                  // 000000A81104: D6100042 0241093B
	v_sad_u8 v64, v55, 0, 0x6400                               // 000000A8110C: D6220040 03FD0137 00006400
	v_mov_b32_e32 v55, v57                                     // 000000A81118: 7E6E0339
	v_sad_u8 v57, v62, 0, 0x6400                               // 000000A8111C: D6220039 03FD013E 00006400
	v_and_b32_e32 v60, 0xffff, v60                             // 000000A81128: 367878FF 0000FFFF
	v_lshl_or_b32 v61, v61, 16, v53                            // 000000A81130: D656003D 04D5213D
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000A81138: D622003A 03FD013A 00006400
	.long 0xd73d0035                                           // 000000A81144: D73D0035
	v_cndmask_b32_e32 v1, v44, v54, vcc_lo                     // 000000A81148: 02026D2C
	v_sad_u8 v55, v63, 0, 0x6400                               // 000000A8114C: D6220037 03FD013F 00006400
	v_lshl_or_b32 v54, v57, 16, v60                            // 000000A81158: D6560036 04F12139
	v_bfe_u32 v63, v59, 12, 16                                 // 000000A81160: D610003F 0241193B
	v_lshlrev_b32_e32 v57, 16, v58                             // 000000A81168: 30727490
	v_pk_fma_f16 v58, v61, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A8116C: CC0E003A 0BFC073D 0000C931
	v_bfe_u32 v60, v53, 12, 16                                 // 000000A81178: D610003C 02411935
	v_pk_fma_f16 v61, v54, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A81180: CC0E003D 0BFC0736 0000C931
	.long 0xd72c003f                                           // 000000A8118C: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000A81190: 02027EFF 83DCD12D
	v_and_or_b32 v54, 0xffff, v55, v57                         // 000000A81198: D6570036 04E66EFF 0000FFFF
	v_dot2acc_f32_f16 v33, v58, v18                            // 000000A811A4: 0442253A
	.long 0xd72c0038                                           // 000000A811A8: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000A811AC: 020270FF 83DCD12D
	v_bfe_u32 v55, v53, 8, 16                                  // 000000A811B4: D6100037 02411135
	.long 0xd72c0039                                           // 000000A811BC: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000A811C0: 020278FF 83DCD12D
	v_pk_fma_f16 v60, v54, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A811C8: CC0E003C 0BFC0736 0000C931
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000A811D4: D622003F 03FD013F 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A811E0: BF870234
	.long 0xd72c0037                                           // 000000A811E4: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000A811E8: 02026EFF 83DCD12D
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000A811F0: D6220038 03FD0138 00006400
	v_sad_u8 v62, v57, 0, 0x6400                               // 000000A811FC: D622003E 03FD0139 00006400
	v_and_b32_e32 v63, 0xffff, v63                             // 000000A81208: 367E7EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000A81210: BF870123
	v_lshlrev_b32_e32 v56, 16, v56                             // 000000A81214: 30707090
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000A81218: D6220037 03FD0137 00006400
	v_and_or_b32 v56, 0xffff, v64, v56                         // 000000A81224: D6570038 04E280FF 0000FFFF
	v_bfe_u32 v64, v59, 8, 16                                  // 000000A81230: D6100040 0241113B
	v_and_b32_e32 v59, 0xffff, v59                             // 000000A81238: 367676FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A81240: BF870193
	v_pk_fma_f16 v56, v56, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A81244: CC0E0038 0BFC0738 0000C931
	.long 0xd72c0040                                           // 000000A81250: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000A81254: 020280FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A8125C: BF870193
	.long 0xd72c003b                                           // 000000A81260: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000A81264: 020276FF 83DCD12D
	v_dual_dot2acc_f32_f16 v33, v56, v19 :: v_dual_and_b32 v58, 0xffff, v53// 000000A8126C: CB242738 213A6AFF 0000FFFF
	v_bfe_u32 v56, v53, 4, 16                                  // 000000A81278: D6100038 02410935
	ds_load_2addr_b32 v[53:54], v52 offset0:128 offset1:160    // 000000A81280: D8DCA080 35000034
	v_sad_u8 v64, v64, 0, 0x6400                               // 000000A81288: D6220040 03FD0140 00006400
	v_dot2acc_f32_f16 v33, v61, v20                            // 000000A81294: 0442293D
	.long 0xd72c003a                                           // 000000A81298: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A8129C: 020274FF 83DCD12D
	.long 0xd72c0041                                           // 000000A812A4: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000A812A8: 020270FF 83DCD12D
	ds_load_2addr_b32 v[56:57], v51 offset0:128 offset1:160    // 000000A812B0: D8DCA080 38000033
	v_dual_dot2acc_f32_f16 v33, v60, v21 :: v_dual_and_b32 v62, 0xffff, v62// 000000A812B8: CB242B3C 213E7CFF 0000FFFF
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000A812C4: D622003A 03FD013A 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A812D0: BF8701A2
	v_lshl_or_b32 v55, v55, 16, v62                            // 000000A812D4: D6560037 04F92137
	v_sad_u8 v62, v65, 0, 0x6400                               // 000000A812DC: D622003E 03FD0141 00006400
	v_lshlrev_b32_e32 v58, 16, v58                             // 000000A812E8: 30747490
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A812EC: BF870003
	v_pk_fma_f16 v65, v55, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A812F0: CC0E0041 0BFC0737 0000C931
	s_waitcnt lgkmcnt(1)                                       // 000000A812FC: BF89FC17
	v_mov_b32_e32 v55, v53                                     // 000000A81300: 7E6E0335
	.long 0xd72c0035                                           // 000000A81304: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 000000A81308: 020284FF 83DCD12D
	v_and_or_b32 v62, 0xffff, v62, v58                         // 000000A81310: D657003E 04EA7CFF 0000FFFF
	v_sad_u8 v66, v59, 0, 0x6400                               // 000000A8131C: D6220042 03FD013B 00006400
	ds_load_2addr_b32 v[58:59], v48 offset0:128 offset1:160    // 000000A81328: D8DCA080 3A000030
	s_waitcnt lgkmcnt(1)                                       // 000000A81330: BF89FC17
	.long 0xd73d0037                                           // 000000A81334: D73D0037
	v_cndmask_b32_e32 v1, v44, v55, vcc_lo                     // 000000A81338: 02026F2C
	v_dot2acc_f32_f16 v32, v65, v18                            // 000000A8133C: 04402541
	v_pk_fma_f16 v56, v62, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A81340: CC0E0038 0BFC073E 0000C931
	v_lshl_or_b32 v62, v64, 16, v63                            // 000000A8134C: D656003E 04FD2140
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000A81354: D6220035 03FD0135 00006400
	v_lshlrev_b32_e32 v63, 16, v66                             // 000000A81360: 307E8490
	v_bfe_u32 v64, v55, 12, 16                                 // 000000A81364: D6100040 02411937
	v_dot2acc_f32_f16 v32, v56, v19                            // 000000A8136C: 04402738
	v_pk_fma_f16 v61, v62, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A81370: CC0E003D 0BFC073E 0000C931
	v_bfe_u32 v62, v55, 8, 16                                  // 000000A8137C: D610003E 02411137
	v_and_or_b32 v53, 0xffff, v53, v63                         // 000000A81384: D6570035 04FE6AFF 0000FFFF
	.long 0xd72c0038                                           // 000000A81390: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000A81394: 020280FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A8139C: BF870214
	v_dot2acc_f32_f16 v32, v61, v20                            // 000000A813A0: 0440293D
	.long 0xd72c003d                                           // 000000A813A4: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000A813A8: 02027CFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A813B0: BF870004
	v_pk_fma_f16 v60, v53, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A813B4: CC0E003C 0BFC0735 0000C931
	v_bfe_u32 v53, v55, 4, 16                                  // 000000A813C0: D6100035 02410937
	v_and_b32_e32 v55, 0xffff, v55                             // 000000A813C8: 366E6EFF 0000FFFF
	s_waitcnt lgkmcnt(0)                                       // 000000A813D0: BF89FC07
	v_bfe_u32 v62, v58, 12, 16                                 // 000000A813D4: D610003E 0241193A
	v_and_b32_e32 v64, 0xffff, v58                             // 000000A813DC: 368074FF 0000FFFF
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000A813E4: D6220038 03FD0138 00006400
	.long 0xd72c0037                                           // 000000A813F0: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000A813F4: 02026EFF 83DCD12D
	.long 0xd72c0035                                           // 000000A813FC: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000A81400: 02026AFF 83DCD12D
	.long 0xd72c003e                                           // 000000A81408: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000A8140C: 02027CFF 83DCD12D
	.long 0xd72c0040                                           // 000000A81414: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000A81418: 020280FF 83DCD12D
	v_bfe_u32 v63, v58, 8, 16                                  // 000000A81420: D610003F 0241113A
	v_and_b32_e32 v56, 0xffff, v56                             // 000000A81428: 367070FF 0000FFFF
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000A81430: D622003D 03FD013D 00006400
	v_bfe_u32 v58, v58, 4, 16                                  // 000000A8143C: D610003A 0241093A
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000A81444: D6220037 03FD0137 00006400
	v_dot2acc_f32_f16 v32, v60, v21                            // 000000A81450: 04402B3C
	v_sad_u8 v62, v62, 0, 0x6400                               // 000000A81454: D622003E 03FD013E 00006400
	v_lshl_or_b32 v56, v61, 16, v56                            // 000000A81460: D6560038 04E1213D
	.long 0xd72c003d                                           // 000000A81468: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000A8146C: 02027EFF 83DCD12D
	v_sad_u8 v63, v53, 0, 0x6400                               // 000000A81474: D622003F 03FD0135 00006400
	v_lshlrev_b32_e32 v65, 16, v55                             // 000000A81480: 30826E90
	v_sad_u8 v53, v64, 0, 0x6400                               // 000000A81484: D6220035 03FD0140 00006400
	v_mov_b32_e32 v55, v57                                     // 000000A81490: 7E6E0339
	v_and_b32_e32 v57, 0xffff, v62                             // 000000A81494: 36727CFF 0000FFFF
	.long 0xd72c003a                                           // 000000A8149C: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A814A0: 020274FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A814A8: BF870214
	v_lshlrev_b32_e32 v62, 16, v53                             // 000000A814AC: 307C6A90
	.long 0xd73d0035                                           // 000000A814B0: D73D0035
	v_cndmask_b32_e32 v1, v44, v54, vcc_lo                     // 000000A814B4: 02026D2C
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000A814B8: D622003D 03FD013D 00006400
	v_and_or_b32 v54, 0xffff, v63, v65                         // 000000A814C4: D6570036 05067EFF 0000FFFF
	v_pk_fma_f16 v55, v56, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A814D0: CC0E0037 0BFC0738 0000C931
	v_bfe_u32 v63, v59, 4, 16                                  // 000000A814DC: D610003F 0241093B
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000A814E4: D622003A 03FD013A 00006400
	v_lshl_or_b32 v56, v61, 16, v57                            // 000000A814F0: D6560038 04E5213D
	v_pk_fma_f16 v54, v54, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A814F8: CC0E0036 0BFC0736 0000C931
	v_dot2acc_f32_f16 v31, v55, v18                            // 000000A81504: 043E2537
	.long 0xd72c003f                                           // 000000A81508: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000A8150C: 02027EFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A81514: BF870224
	v_pk_fma_f16 v60, v56, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A81518: CC0E003C 0BFC0738 0000C931
	v_bfe_u32 v56, v53, 8, 16                                  // 000000A81524: D6100038 02411135
	v_dot2acc_f32_f16 v31, v54, v19                            // 000000A8152C: 043E2736
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A81530: BF870112
	.long 0xd72c0038                                           // 000000A81534: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000A81538: 020270FF 83DCD12D
	v_dot2acc_f32_f16 v31, v60, v20                            // 000000A81540: 043E293C
	v_and_or_b32 v57, 0xffff, v58, v62                         // 000000A81544: D6570039 04FA74FF 0000FFFF
	v_bfe_u32 v58, v53, 12, 16                                 // 000000A81550: D610003A 02411935
	v_bfe_u32 v62, v59, 8, 16                                  // 000000A81558: D610003E 0241113B
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000A81560: D622003F 03FD013F 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A8156C: BF870214
	v_pk_fma_f16 v61, v57, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A81570: CC0E003D 0BFC0739 0000C931
	.long 0xd72c0037                                           // 000000A8157C: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A81580: 020274FF 83DCD12D
	v_bfe_u32 v57, v53, 4, 16                                  // 000000A81588: D6100039 02410935
	v_and_b32_e32 v53, 0xffff, v53                             // 000000A81590: 366A6AFF 0000FFFF
	v_bfe_u32 v58, v59, 12, 16                                 // 000000A81598: D610003A 0241193B
	v_and_b32_e32 v59, 0xffff, v59                             // 000000A815A0: 367676FF 0000FFFF
	v_sad_u8 v65, v56, 0, 0x6400                               // 000000A815A8: D6220041 03FD0138 00006400
	.long 0xd72c0042                                           // 000000A815B4: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 000000A815B8: 020272FF 83DCD12D
	.long 0xd72c0040                                           // 000000A815C0: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000A815C4: 02026AFF 83DCD12D
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000A815CC: D6220037 03FD0137 00006400
	ds_load_2addr_b32 v[53:54], v52 offset0:192 offset1:224    // 000000A815D8: D8DCE0C0 35000034
	ds_load_2addr_b32 v[56:57], v51 offset0:192 offset1:224    // 000000A815E0: D8DCE0C0 38000033
	.long 0xd72c003b                                           // 000000A815E8: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000A815EC: 020276FF 83DCD12D
	.long 0xd72c003a                                           // 000000A815F4: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A815F8: 020274FF 83DCD12D
	v_and_b32_e32 v55, 0xffff, v55                             // 000000A81600: 366E6EFF 0000FFFF
	.long 0xd72c003e                                           // 000000A81608: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000A8160C: 02027CFF 83DCD12D
	v_sad_u8 v66, v66, 0, 0x6400                               // 000000A81614: D6220042 03FD0142 00006400
	v_dot2acc_f32_f16 v31, v61, v21                            // 000000A81620: 043E2B3D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000A81624: BF870244
	v_lshl_or_b32 v65, v65, 16, v55                            // 000000A81628: D6560041 04DD2141
	v_sad_u8 v55, v64, 0, 0x6400                               // 000000A81630: D6220037 03FD0140 00006400
	v_sad_u8 v64, v58, 0, 0x6400                               // 000000A8163C: D6220040 03FD013A 00006400
	v_sad_u8 v62, v62, 0, 0x6400                               // 000000A81648: D622003E 03FD013E 00006400
	v_pk_fma_f16 v65, v65, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A81654: CC0E0041 0BFC0741 0000C931
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A81660: BF870004
	v_lshlrev_b32_e32 v67, 16, v55                             // 000000A81664: 30866E90
	v_sad_u8 v55, v59, 0, 0x6400                               // 000000A81668: D6220037 03FD013B 00006400
	ds_load_2addr_b32 v[58:59], v48 offset0:192 offset1:224    // 000000A81674: D8DCE0C0 3A000030
	v_and_b32_e32 v64, 0xffff, v64                             // 000000A8167C: 368080FF 0000FFFF
	v_dot2acc_f32_f16 v30, v65, v18                            // 000000A81684: 043C2541
	s_waitcnt lgkmcnt(2)                                       // 000000A81688: BF89FC27
	v_dual_mov_b32 v55, v53 :: v_dual_lshlrev_b32 v68, 16, v55 // 000000A8168C: CA220135 37446E90
	v_and_or_b32 v53, 0xffff, v66, v67                         // 000000A81694: D6570035 050E84FF 0000FFFF
	v_lshl_or_b32 v62, v62, 16, v64                            // 000000A816A0: D656003E 0501213E
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A816A8: BF870003
	v_and_or_b32 v63, 0xffff, v63, v68                         // 000000A816AC: D657003F 05127EFF 0000FFFF
	s_waitcnt lgkmcnt(1)                                       // 000000A816B8: BF89FC17
	.long 0xd73d0037                                           // 000000A816BC: D73D0037
	v_cndmask_b32_e32 v1, v44, v55, vcc_lo                     // 000000A816C0: 02026F2C
	v_pk_fma_f16 v53, v53, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A816C4: CC0E0035 0BFC0735 0000C931
	v_pk_fma_f16 v56, v62, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A816D0: CC0E0038 0BFC073E 0000C931
	v_pk_fma_f16 v60, v63, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A816DC: CC0E003C 0BFC073F 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A816E8: BF870214
	v_bfe_u32 v62, v55, 12, 16                                 // 000000A816EC: D610003E 02411937
	v_dot2acc_f32_f16 v30, v53, v19                            // 000000A816F4: 043C2735
	v_and_b32_e32 v53, 0xffff, v55                             // 000000A816F8: 366A6EFF 0000FFFF
	v_bfe_u32 v63, v55, 8, 16                                  // 000000A81700: D610003F 02411137
	s_waitcnt lgkmcnt(0)                                       // 000000A81708: BF89FC07
	v_bfe_u32 v64, v58, 12, 16                                 // 000000A8170C: D6100040 0241193A
	.long 0xd72c003e                                           // 000000A81714: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000A81718: 02027CFF 83DCD12D
	v_bfe_u32 v55, v55, 4, 16                                  // 000000A81720: D6100037 02410937
	.long 0xd72c0035                                           // 000000A81728: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000A8172C: 02026AFF 83DCD12D
	.long 0xd72c003f                                           // 000000A81734: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000A81738: 02027EFF 83DCD12D
	v_bfe_u32 v65, v58, 8, 16                                  // 000000A81740: D6100041 0241113A
	.long 0xd72c0040                                           // 000000A81748: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000A8174C: 020280FF 83DCD12D
	.long 0xd72c0037                                           // 000000A81754: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000A81758: 02026EFF 83DCD12D
	v_dot2acc_f32_f16 v30, v56, v20                            // 000000A81760: 043C2938
	v_sad_u8 v62, v62, 0, 0x6400                               // 000000A81764: D622003E 03FD013E 00006400
	.long 0xd72c0041                                           // 000000A81770: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000A81774: 020282FF 83DCD12D
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000A8177C: D6220035 03FD0135 00006400
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000A81788: D622003F 03FD013F 00006400
	v_bfe_u32 v66, v58, 4, 16                                  // 000000A81794: D6100042 0241093A
	v_and_b32_e32 v62, 0xffff, v62                             // 000000A8179C: 367C7CFF 0000FFFF
	v_sad_u8 v64, v64, 0, 0x6400                               // 000000A817A4: D6220040 03FD0140 00006400
	v_sad_u8 v67, v55, 0, 0x6400                               // 000000A817B0: D6220043 03FD0137 00006400
	v_lshlrev_b32_e32 v53, 16, v53                             // 000000A817BC: 306A6A90
	v_mov_b32_e32 v55, v57                                     // 000000A817C0: 7E6E0339
	v_lshl_or_b32 v62, v63, 16, v62                            // 000000A817C4: D656003E 04F9213F
	v_and_b32_e32 v64, 0xffff, v64                             // 000000A817CC: 368080FF 0000FFFF
	v_sad_u8 v57, v65, 0, 0x6400                               // 000000A817D4: D6220039 03FD0141 00006400
	v_and_or_b32 v63, 0xffff, v67, v53                         // 000000A817E0: D657003F 04D686FF 0000FFFF
	.long 0xd73d0035                                           // 000000A817EC: D73D0035
	v_cndmask_b32_e32 v1, v44, v54, vcc_lo                     // 000000A817F0: 02026D2C
	v_pk_fma_f16 v56, v62, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A817F4: CC0E0038 0BFC073E 0000C931
	.long 0xd72c0041                                           // 000000A81800: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 000000A81804: 020284FF 83DCD12D
	v_lshl_or_b32 v54, v57, 16, v64                            // 000000A8180C: D6560036 05012139
	v_pk_fma_f16 v57, v63, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A81814: CC0E0039 0BFC073F 0000C931
	v_bfe_u32 v66, v59, 8, 16                                  // 000000A81820: D6100042 0241113B
	v_dot2acc_f32_f16 v29, v56, v18                            // 000000A81828: 043A2538
	v_and_b32_e32 v58, 0xffff, v58                             // 000000A8182C: 367474FF 0000FFFF
	v_and_b32_e32 v63, 0xffff, v53                             // 000000A81834: 367E6AFF 0000FFFF
	v_bfe_u32 v64, v53, 8, 16                                  // 000000A8183C: D6100040 02411135
	v_pk_fma_f16 v54, v54, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A81844: CC0E0036 0BFC0736 0000C931
	v_dot2acc_f32_f16 v29, v57, v19                            // 000000A81850: 043A2739
	.long 0xd72c0037                                           // 000000A81854: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A81858: 020274FF 83DCD12D
	v_bfe_u32 v58, v53, 12, 16                                 // 000000A81860: D610003A 02411935
	v_bfe_u32 v53, v53, 4, 16                                  // 000000A81868: D6100035 02410935
	.long 0xd72c003f                                           // 000000A81870: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000A81874: 02027EFF 83DCD12D
	.long 0xd72c0040                                           // 000000A8187C: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000A81880: 020280FF 83DCD12D
	v_sad_u8 v62, v65, 0, 0x6400                               // 000000A81888: D622003E 03FD0141 00006400
	.long 0xd72c003a                                           // 000000A81894: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000A81898: 020274FF 83DCD12D
	.long 0xd72c0035                                           // 000000A818A0: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000A818A4: 02026AFF 83DCD12D
	v_bfe_u32 v65, v59, 12, 16                                 // 000000A818AC: D6100041 0241193B
	v_dot2acc_f32_f16 v29, v54, v20                            // 000000A818B4: 043A2936
	v_bfe_u32 v67, v59, 4, 16                                  // 000000A818B8: D6100043 0241093B
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000A818C0: D622003F 03FD013F 00006400
	v_sad_u8 v64, v64, 0, 0x6400                               // 000000A818CC: D6220040 03FD0140 00006400
	.long 0xd72c0041                                           // 000000A818D8: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000A818DC: 020282FF 83DCD12D
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000A818E4: D622003A 03FD013A 00006400
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000A818F0: D6220035 03FD0135 00006400
	v_lshlrev_b32_e32 v63, 16, v63                             // 000000A818FC: 307E7E90
	v_and_b32_e32 v59, 0xffff, v59                             // 000000A81900: 367676FF 0000FFFF
	.long 0xd72c0042                                           // 000000A81908: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 000000A8190C: 020284FF 83DCD12D
	v_and_b32_e32 v58, 0xffff, v58                             // 000000A81914: 367474FF 0000FFFF
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000A8191C: D6220037 03FD0137 00006400
	v_and_or_b32 v53, 0xffff, v53, v63                         // 000000A81928: D6570035 04FE6AFF 0000FFFF
	.long 0xd72c003b                                           // 000000A81934: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000A81938: 020276FF 83DCD12D
	v_sad_u8 v65, v65, 0, 0x6400                               // 000000A81940: D6220041 03FD0141 00006400
	v_lshl_or_b32 v58, v64, 16, v58                            // 000000A8194C: D656003A 04E92140
	.long 0xd72c003f                                           // 000000A81954: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000A81958: 020286FF 83DCD12D
	v_pk_fma_f16 v53, v53, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A81960: CC0E0035 0BFC0735 0000C931
	v_dual_dot2acc_f32_f16 v30, v60, v21 :: v_dual_lshlrev_b32 v55, 16, v55// 000000A8196C: CB222B3C 1E366E90
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000A81974: BF870134
	v_pk_fma_f16 v58, v58, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A81978: CC0E003A 0BFC073A 0000C931
	v_sad_u8 v56, v59, 0, 0x6400                               // 000000A81984: D6220038 03FD013B 00006400
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000A81990: D622003F 03FD013F 00006400
	v_dual_dot2acc_f32_f16 v1, v58, v18 :: v_dual_lshlrev_b32 v56, 16, v56// 000000A8199C: CB22253A 01387090
	v_and_or_b32 v18, 0xffff, v62, v55                         // 000000A819A4: D6570012 04DE7CFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A819B0: BF870222
	v_dual_dot2acc_f32_f16 v1, v53, v19 :: v_dual_and_b32 v64, 0xffff, v65// 000000A819B4: CB242735 014082FF 0000FFFF
	v_sad_u8 v65, v66, 0, 0x6400                               // 000000A819C0: D6220041 03FD0142 00006400
	v_and_or_b32 v56, 0xffff, v63, v56                         // 000000A819CC: D6570038 04E27EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A819D8: BF870224
	v_pk_fma_f16 v18, v18, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A819DC: CC0E0012 0BFC0712 0000C931
	v_add_nc_u32_e32 v46, 1, v46                               // 000000A819E8: 4A5C5C81
	v_lshl_or_b32 v59, v65, 16, v64                            // 000000A819EC: D656003B 05012141
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A819F4: BF870214
	v_pk_fma_f16 v19, v56, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A819F8: CC0E0013 0BFC0738 0000C931
	v_dot2acc_f32_f16 v29, v18, v21                            // 000000A81A04: 043A2B12
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A81A08: BF870093
	v_pk_fma_f16 v55, v59, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A81A0C: CC0E0037 0BFC073B 0000C931
	v_dual_dot2acc_f32_f16 v1, v55, v20 :: v_dual_add_nc_u32 v20, v45, v46// 000000A81A18: CB202937 01145D2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A81A20: BF870111
	v_dot2acc_f32_f16 v1, v19, v21                             // 000000A81A24: 04022B13
	v_cmp_eq_u32_e32 vcc_lo, 21, v20                           // 000000A81A28: 7C942895
	s_or_b32 s2, vcc_lo, s2                                    // 000000A81A2C: 8C02026A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A81A30: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s2                        // 000000A81A34: 917E027E
	s_cbranch_execz 62                                         // 000000A81A38: BFA5003E <_ZN7halogen12_GLOBAL__N_112k_ht_gemv_guILi4ELi8ELi1EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_S5_PDF16_+0x2034>
	s_mov_b32 s0, exec_lo                                      // 000000A81A3C: BE80007E
	s_waitcnt vmcnt(14)                                        // 000000A81A40: BF893BF7
	ds_store_2addr_b32 v47, v2, v3 offset1:32                  // 000000A81A44: D8382000 0003022F
	s_waitcnt vmcnt(12)                                        // 000000A81A4C: BF8933F7
	ds_store_2addr_b32 v47, v4, v5 offset0:64 offset1:96       // 000000A81A50: D8386040 0005042F
	s_waitcnt vmcnt(10)                                        // 000000A81A58: BF892BF7
	ds_store_2addr_b32 v47, v6, v7 offset0:128 offset1:160     // 000000A81A5C: D838A080 0007062F
	s_waitcnt vmcnt(8)                                         // 000000A81A64: BF8923F7
	ds_store_2addr_b32 v47, v8, v9 offset0:192 offset1:224     // 000000A81A68: D838E0C0 0009082F
	s_waitcnt vmcnt(6)                                         // 000000A81A70: BF891BF7
	ds_store_2addr_b32 v48, v10, v11 offset1:32                // 000000A81A74: D8382000 000B0A30
	s_waitcnt vmcnt(4)                                         // 000000A81A7C: BF8913F7
	ds_store_2addr_b32 v48, v12, v13 offset0:64 offset1:96     // 000000A81A80: D8386040 000D0C30
	s_waitcnt vmcnt(2)                                         // 000000A81A88: BF890BF7
	ds_store_2addr_b32 v48, v14, v15 offset0:128 offset1:160   // 000000A81A8C: D838A080 000F0E30
	s_waitcnt vmcnt(0)                                         // 000000A81A94: BF8903F7
	ds_store_2addr_b32 v48, v16, v17 offset0:192 offset1:224   // 000000A81A98: D838E0C0 00111030
	.long 0xd4c9007e                                           // 000000A81AA0: D4C9007E
	v_cndmask_b32_e32 v1, v46, v27, vcc_lo                     // 000000A81AA4: 0202372E
	s_cbranch_execz 63785                                      // 000000A81AA8: BFA5F929 <_ZN7halogen12_GLOBAL__N_112k_ht_gemv_guILi4ELi8ELi1EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_S5_PDF16_+0x450>
	s_clause 0xf                                               // 000000A81AAC: BF85000F
	global_load_b32 v2, v[22:23], off                          // 000000A81AB0: DC520000 027C0016
	global_load_b32 v3, v[22:23], off offset:128               // 000000A81AB8: DC520080 037C0016
	global_load_b32 v4, v[22:23], off offset:256               // 000000A81AC0: DC520100 047C0016
	global_load_b32 v5, v[22:23], off offset:384               // 000000A81AC8: DC520180 057C0016
	global_load_b32 v6, v[22:23], off offset:512               // 000000A81AD0: DC520200 067C0016
	global_load_b32 v7, v[22:23], off offset:640               // 000000A81AD8: DC520280 077C0016
	global_load_b32 v8, v[22:23], off offset:768               // 000000A81AE0: DC520300 087C0016
	global_load_b32 v9, v[22:23], off offset:896               // 000000A81AE8: DC520380 097C0016
	global_load_b32 v10, v[22:23], off offset:1024             // 000000A81AF0: DC520400 0A7C0016
	global_load_b32 v11, v[22:23], off offset:1152             // 000000A81AF8: DC520480 0B7C0016
	global_load_b32 v12, v[22:23], off offset:1280             // 000000A81B00: DC520500 0C7C0016
	global_load_b32 v13, v[22:23], off offset:1408             // 000000A81B08: DC520580 0D7C0016
	global_load_b32 v14, v[22:23], off offset:1536             // 000000A81B10: DC520600 0E7C0016
	global_load_b32 v15, v[22:23], off offset:1664             // 000000A81B18: DC520680 0F7C0016
	global_load_b32 v16, v[22:23], off offset:1792             // 000000A81B20: DC520700 107C0016
	global_load_b32 v17, v[22:23], off offset:1920             // 000000A81B28: DC520780 117C0016
	s_branch 63751                                             // 000000A81B30: BFA0F907 <_ZN7halogen12_GLOBAL__N_112k_ht_gemv_guILi4ELi8ELi1EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_S5_PDF16_+0x450>
	s_or_b32 exec_lo, exec_lo, s2                              // 000000A81B34: 8C7E027E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A81B38: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 000000A81B3C: 8C7E017E
	s_waitcnt vmcnt(14)                                        // 000000A81B40: BF893BF7
	v_dual_mov_b32 v2, v28 :: v_dual_mov_b32 v3, v42           // 000000A81B44: CA10011C 0202012A
	s_waitcnt vmcnt(12)                                        // 000000A81B4C: BF8933F7
	v_dual_mov_b32 v4, v41 :: v_dual_mov_b32 v5, v40           // 000000A81B50: CA100129 04040128
	s_waitcnt vmcnt(10)                                        // 000000A81B58: BF892BF7
	v_dual_mov_b32 v6, v39 :: v_dual_mov_b32 v7, v38           // 000000A81B5C: CA100127 06060126
	s_waitcnt vmcnt(8)                                         // 000000A81B64: BF8923F7
	v_dual_mov_b32 v8, v37 :: v_dual_mov_b32 v9, v36           // 000000A81B68: CA100125 08080124
	s_waitcnt vmcnt(6)                                         // 000000A81B70: BF891BF7
	v_dual_mov_b32 v10, v35 :: v_dual_mov_b32 v11, v34         // 000000A81B74: CA100123 0A0A0122
	s_waitcnt vmcnt(4)                                         // 000000A81B7C: BF8913F7
	v_dual_mov_b32 v12, v33 :: v_dual_mov_b32 v13, v32         // 000000A81B80: CA100121 0C0C0120
	s_waitcnt vmcnt(2)                                         // 000000A81B88: BF890BF7
	v_dual_mov_b32 v14, v31 :: v_dual_mov_b32 v15, v30         // 000000A81B8C: CA10011F 0E0E011E
	s_waitcnt vmcnt(1)                                         // 000000A81B94: BF8907F7
	v_mov_b32_e32 v16, v29                                     // 000000A81B98: 7E20031D
	s_waitcnt vmcnt(0)                                         // 000000A81B9C: BF8903F7
	v_mov_b32_e32 v17, v1                                      // 000000A81BA0: 7E220301
	s_mov_b32 s0, 0x76543210                                   // 000000A81BA4: BE8000FF 76543210
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A81BAC: BF870009
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 000000A81BB0: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 000000A81BBC: D65C0003 03FC0103 FEDCBA98
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 000000A81BC8: D65C0004 03FC0104 FEDCBA98
	v_permlanex16_b32 v5, v5, s0, 0xfedcba98                   // 000000A81BD4: D65C0005 03FC0105 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 000000A81BE0: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v7, v7, s0, 0xfedcba98                   // 000000A81BEC: D65C0007 03FC0107 FEDCBA98
	v_permlanex16_b32 v8, v8, s0, 0xfedcba98                   // 000000A81BF8: D65C0008 03FC0108 FEDCBA98
	v_permlanex16_b32 v9, v9, s0, 0xfedcba98                   // 000000A81C04: D65C0009 03FC0109 FEDCBA98
	v_permlanex16_b32 v10, v10, s0, 0xfedcba98                 // 000000A81C10: D65C000A 03FC010A FEDCBA98
	v_permlanex16_b32 v11, v11, s0, 0xfedcba98                 // 000000A81C1C: D65C000B 03FC010B FEDCBA98
	v_permlanex16_b32 v12, v12, s0, 0xfedcba98                 // 000000A81C28: D65C000C 03FC010C FEDCBA98
	v_permlanex16_b32 v13, v13, s0, 0xfedcba98                 // 000000A81C34: D65C000D 03FC010D FEDCBA98
	v_permlanex16_b32 v14, v14, s0, 0xfedcba98                 // 000000A81C40: D65C000E 03FC010E FEDCBA98
	v_permlanex16_b32 v15, v15, s0, 0xfedcba98                 // 000000A81C4C: D65C000F 03FC010F FEDCBA98
	v_permlanex16_b32 v16, v16, s0, 0xfedcba98                 // 000000A81C58: D65C0010 03FC0110 FEDCBA98
	v_permlanex16_b32 v17, v17, s0, 0xfedcba98                 // 000000A81C64: D65C0011 03FC0111 FEDCBA98
	.long 0xd44c0000                                           // 000000A81C70: D44C0000
	v_cndmask_b32_e32 v1, 16, v25, vcc_lo                      // 000000A81C74: 02023290
	s_barrier                                                  // 000000A81C78: BFBD0000
	buffer_gl0_inv                                             // 000000A81C7C: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 000000A81C84: BE812000
	s_cbranch_execz 34                                         // 000000A81C88: BFA50022 <_ZN7halogen12_GLOBAL__N_112k_ht_gemv_guILi4ELi8ELi1EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_S5_PDF16_+0x2214>
	v_dual_add_f32 v1, v1, v17 :: v_dual_add_f32 v2, v28, v2   // 000000A81C8C: C9082301 0102051C
	v_dual_add_f32 v3, v42, v3 :: v_dual_add_f32 v4, v41, v4   // 000000A81C94: C908072A 03040929
	v_lshl_or_b32 v17, v24, 10, v26                            // 000000A81C9C: D6560011 04691518
	v_dual_add_f32 v5, v40, v5 :: v_dual_add_f32 v6, v39, v6   // 000000A81CA4: C9080B28 05060D27
	v_dual_add_f32 v7, v38, v7 :: v_dual_add_f32 v8, v37, v8   // 000000A81CAC: C9080F26 07081125
	v_dual_add_f32 v9, v36, v9 :: v_dual_add_f32 v10, v35, v10 // 000000A81CB4: C9081324 090A1523
	v_dual_add_f32 v11, v34, v11 :: v_dual_add_f32 v12, v33, v12// 000000A81CBC: C9081722 0B0C1921
	v_dual_add_f32 v13, v32, v13 :: v_dual_add_f32 v14, v31, v14// 000000A81CC4: C9081B20 0D0E1D1F
	v_dual_add_f32 v15, v30, v15 :: v_dual_add_f32 v16, v29, v16// 000000A81CCC: C9081F1E 0F10211D
	ds_store_2addr_b32 v17, v2, v3 offset1:16                  // 000000A81CD4: D8381000 00030211
	ds_store_2addr_b32 v17, v4, v5 offset0:32 offset1:48       // 000000A81CDC: D8383020 00050411
	ds_store_2addr_b32 v17, v6, v7 offset0:64 offset1:80       // 000000A81CE4: D8385040 00070611
	ds_store_2addr_b32 v17, v8, v9 offset0:96 offset1:112      // 000000A81CEC: D8387060 00090811
	ds_store_2addr_b32 v17, v10, v11 offset0:128 offset1:144   // 000000A81CF4: D8389080 000B0A11
	ds_store_2addr_b32 v17, v12, v13 offset0:160 offset1:176   // 000000A81CFC: D838B0A0 000D0C11
	ds_store_2addr_b32 v17, v14, v15 offset0:192 offset1:208   // 000000A81D04: D838D0C0 000F0E11
	ds_store_2addr_b32 v17, v16, v1 offset0:224 offset1:240    // 000000A81D0C: D838F0E0 00011011
	s_or_b32 exec_lo, exec_lo, s1                              // 000000A81D14: 8C7E017E
	s_sub_i32 s1, s27, s26                                     // 000000A81D18: 81811A1B
	s_waitcnt lgkmcnt(0)                                       // 000000A81D1C: BF89FC07
	s_min_i32 s1, s1, 1                                        // 000000A81D20: 89018101
	s_barrier                                                  // 000000A81D24: BFBD0000
	v_cmp_gt_i32_e32 vcc_lo, s1, v24                           // 000000A81D28: 7C883001
	buffer_gl0_inv                                             // 000000A81D2C: E0AC0000 00000000
	s_and_saveexec_b32 s1, vcc_lo                              // 000000A81D34: BE81206A
	s_cbranch_execz 1364                                       // 000000A81D38: BFA50554 <_ZN7halogen12_GLOBAL__N_112k_ht_gemv_guILi4ELi8ELi1EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_S5_PDF16_+0x378c>
	v_and_b32_e32 v47, 15, v0                                  // 000000A81D3C: 365E008F
	s_mul_i32 s1, s24, 0xa00                                   // 000000A81D40: 9601FF18 00000A00
	s_mul_hi_i32 s2, s24, 0xa00                                // 000000A81D48: 9702FF18 00000A00
	s_add_u32 s1, s8, s1                                       // 000000A81D50: 80010108
	s_addc_u32 s4, s9, s2                                      // 000000A81D54: 82040209
	v_lshlrev_b32_e32 v48, 2, v47                              // 000000A81D58: 30605E82
	s_lshl_b32 s2, s25, 7                                      // 000000A81D5C: 84028719
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000A81D60: BF870499
	s_ashr_i32 s3, s2, 31                                      // 000000A81D64: 86039F02
	s_lshl_b64 s[14:15], s[2:3], 1                             // 000000A81D68: 848E8102
	ds_load_2addr_b32 v[1:2], v48 offset1:16                   // 000000A81D6C: D8DC1000 01000030
	s_add_u32 s6, s1, s14                                      // 000000A81D74: 80060E01
	s_addc_u32 s7, s4, s15                                     // 000000A81D78: 82070F04
	s_mul_i32 s1, s24, 0x500                                   // 000000A81D7C: 9601FF18 00000500
	s_mul_hi_i32 s2, s24, 0x500                                // 000000A81D84: 9702FF18 00000500
	s_add_u32 s1, s10, s1                                      // 000000A81D8C: 8001010A
	s_addc_u32 s2, s11, s2                                     // 000000A81D90: 8202020B
	s_add_u32 s8, s1, s14                                      // 000000A81D94: 80080E01
	s_addc_u32 s9, s2, s15                                     // 000000A81D98: 82090F02
	s_waitcnt lgkmcnt(0)                                       // 000000A81D9C: BF89FC07
	v_dual_add_f32 v1, 0, v1 :: v_dual_add_f32 v2, 0, v2       // 000000A81DA0: C9080280 01020480
	v_add_nc_u32_e32 v49, 0x400, v48                           // 000000A81DA8: 4A6260FF 00000400
	ds_load_2addr_b32 v[3:4], v48 offset0:128 offset1:144      // 000000A81DB0: D8DC9080 03000030
	v_add_nc_u32_e32 v50, 0x800, v48                           // 000000A81DB8: 4A6460FF 00000800
	v_add_nc_u32_e32 v53, 0x1400, v48                          // 000000A81DC0: 4A6A60FF 00001400
	ds_load_2addr_b32 v[5:6], v49 offset1:16                   // 000000A81DC8: D8DC1000 05000031
	s_waitcnt lgkmcnt(1)                                       // 000000A81DD0: BF89FC17
	v_dual_add_f32 v3, 0, v3 :: v_dual_add_nc_u32 v52, 0x1000, v48// 000000A81DD4: C9200680 033460FF 00001000
	ds_load_2addr_b32 v[41:42], v50 offset0:32 offset1:48      // 000000A81DE0: D8DC3020 29000032
	ds_load_2addr_b32 v[43:44], v50 offset0:160 offset1:176    // 000000A81DE8: D8DCB0A0 2B000032
	s_waitcnt lgkmcnt(2)                                       // 000000A81DF0: BF89FC27
	v_dual_add_f32 v1, v1, v5 :: v_dual_add_f32 v2, v2, v6     // 000000A81DF4: C9080B01 01020D02
	v_add_nc_u32_e32 v51, 0xc00, v48                           // 000000A81DFC: 4A6660FF 00000C00
	ds_load_2addr_b32 v[7:8], v49 offset0:128 offset1:144      // 000000A81E04: D8DC9080 07000031
	ds_load_2addr_b32 v[9:10], v50 offset1:16                  // 000000A81E0C: D8DC1000 09000032
	ds_load_2addr_b32 v[11:12], v48 offset0:32 offset1:48      // 000000A81E14: D8DC3020 0B000030
	ds_load_2addr_b32 v[13:14], v48 offset0:160 offset1:176    // 000000A81E1C: D8DCB0A0 0D000030
	ds_load_2addr_b32 v[15:16], v50 offset0:128 offset1:144    // 000000A81E24: D8DC9080 0F000032
	ds_load_2addr_b32 v[17:18], v51 offset1:16                 // 000000A81E2C: D8DC1000 11000033
	ds_load_2addr_b32 v[19:20], v51 offset0:128 offset1:144    // 000000A81E34: D8DC9080 13000033
	ds_load_2addr_b32 v[21:22], v52 offset1:16                 // 000000A81E3C: D8DC1000 15000034
	ds_load_2addr_b32 v[23:24], v52 offset0:128 offset1:144    // 000000A81E44: D8DC9080 17000034
	ds_load_2addr_b32 v[25:26], v53 offset1:16                 // 000000A81E4C: D8DC1000 19000035
	ds_load_2addr_b32 v[27:28], v53 offset0:128 offset1:144    // 000000A81E54: D8DC9080 1B000035
	s_waitcnt lgkmcnt(10)                                      // 000000A81E5C: BF89FCA7
	v_dual_add_f32 v3, v3, v7 :: v_dual_add_nc_u32 v54, 0x1800, v48// 000000A81E60: C9200F03 033660FF 00001800
	s_waitcnt lgkmcnt(9)                                       // 000000A81E6C: BF89FC97
	v_dual_add_f32 v2, v2, v10 :: v_dual_add_nc_u32 v55, 0x1c00, v48// 000000A81E70: C9201502 023660FF 00001C00
	s_waitcnt lgkmcnt(7)                                       // 000000A81E7C: BF89FC77
	v_dual_add_f32 v10, 0, v11 :: v_dual_add_f32 v11, 0, v13   // 000000A81E80: C9081680 0A0A1A80
	ds_load_2addr_b32 v[45:46], v51 offset0:32 offset1:48      // 000000A81E88: D8DC3020 2D000033
	s_waitcnt lgkmcnt(6)                                       // 000000A81E90: BF89FC67
	v_add_f32_e32 v2, v2, v18                                  // 000000A81E94: 06042502
	ds_load_2addr_b32 v[35:36], v55 offset0:128 offset1:144    // 000000A81E98: D8DC9080 23000037
	ds_load_2addr_b32 v[37:38], v49 offset0:32 offset1:48      // 000000A81EA0: D8DC3020 25000031
	ds_load_2addr_b32 v[39:40], v49 offset0:160 offset1:176    // 000000A81EA8: D8DCB0A0 27000031
	ds_load_2addr_b32 v[29:30], v54 offset1:16                 // 000000A81EB0: D8DC1000 1D000036
	ds_load_2addr_b32 v[31:32], v54 offset0:128 offset1:144    // 000000A81EB8: D8DC9080 1F000036
	ds_load_2addr_b32 v[33:34], v55 offset1:16                 // 000000A81EC0: D8DC1000 21000037
	v_add_f32_e32 v7, 0, v4                                    // 000000A81EC8: 060E0880
	v_add_f32_e32 v1, v1, v9                                   // 000000A81ECC: 06021301
	ds_load_2addr_b32 v[4:5], v51 offset0:160 offset1:176      // 000000A81ED0: D8DCB0A0 04000033
	v_add_f32_e32 v6, v7, v8                                   // 000000A81ED8: 060C1107
	v_add_f32_e32 v3, v3, v15                                  // 000000A81EDC: 06061F03
	ds_load_2addr_b32 v[8:9], v52 offset0:160 offset1:176      // 000000A81EE0: D8DCB0A0 08000034
	v_add_f32_e32 v1, v1, v17                                  // 000000A81EE8: 06022301
	s_waitcnt lgkmcnt(12)                                      // 000000A81EEC: BF89FCC7
	v_add_f32_e32 v17, v2, v22                                 // 000000A81EF0: 06222D02
	v_dual_add_f32 v6, v6, v16 :: v_dual_add_f32 v3, v3, v19   // 000000A81EF4: C9082106 06022703
	ds_load_2addr_b32 v[15:16], v53 offset0:160 offset1:176    // 000000A81EFC: D8DCB0A0 0F000035
	s_waitcnt lgkmcnt(11)                                      // 000000A81F04: BF89FCB7
	v_dual_add_f32 v22, v17, v26 :: v_dual_add_f32 v13, v6, v20// 000000A81F08: C9083511 160C2906
	ds_load_2addr_b32 v[6:7], v52 offset0:32 offset1:48        // 000000A81F10: D8DC3020 06000034
	s_waitcnt lgkmcnt(7)                                       // 000000A81F18: BF89FC77
	v_dual_add_f32 v18, v11, v39 :: v_dual_add_f32 v1, v1, v21 // 000000A81F1C: C9084F0B 12002B01
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A81F24: BF870001
	v_dual_add_f32 v13, v13, v24 :: v_dual_add_f32 v24, v18, v43// 000000A81F28: C908310D 0D185712
	v_add_f32_e32 v3, v3, v23                                  // 000000A81F30: 06062F03
	ds_load_2addr_b32 v[17:18], v54 offset0:32 offset1:48      // 000000A81F34: D8DC3020 11000036
	ds_load_2addr_b32 v[19:20], v54 offset0:160 offset1:176    // 000000A81F3C: D8DCB0A0 13000036
	s_waitcnt lgkmcnt(5)                                       // 000000A81F44: BF89FC57
	v_dual_add_f32 v1, v1, v25 :: v_dual_add_f32 v4, v24, v4   // 000000A81F48: C9083301 01040918
	v_dual_add_f32 v3, v3, v27 :: v_dual_add_f32 v24, v22, v30 // 000000A81F50: C9083703 03183D16
	s_waitcnt lgkmcnt(4)                                       // 000000A81F58: BF89FC47
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A81F5C: BF870001
	v_dual_add_f32 v4, v4, v8 :: v_dual_add_f32 v21, v3, v31   // 000000A81F60: C9081104 04143F03
	v_dual_add_f32 v8, 0, v12 :: v_dual_add_f32 v3, v10, v37   // 000000A81F68: C9081880 08024B0A
	ds_load_2addr_b32 v[10:11], v53 offset0:32 offset1:48      // 000000A81F70: D8DC3020 0A000035
	s_waitcnt lgkmcnt(4)                                       // 000000A81F78: BF89FC47
	v_dual_add_f32 v4, v4, v15 :: v_dual_add_f32 v23, v3, v41  // 000000A81F7C: C9081F04 04165303
	v_add_f32_e32 v41, v24, v34                                // 000000A81F84: 06524518
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A81F88: BF8700A2
	v_add_f32_e32 v23, v23, v45                                // 000000A81F8C: 062E5B17
	s_waitcnt lgkmcnt(3)                                       // 000000A81F90: BF89FC37
	v_dual_add_f32 v1, v1, v29 :: v_dual_add_f32 v6, v23, v6   // 000000A81F94: C9083B01 01060D17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000A81F9C: BF870151
	v_add_f32_e32 v56, v1, v33                                 // 000000A81FA0: 06704301
	ds_load_2addr_b32 v[23:24], v48 offset0:64 offset1:80      // 000000A81FA4: D8DC5040 17000030
	s_waitcnt lgkmcnt(1)                                       // 000000A81FAC: BF89FC17
	v_dual_add_f32 v6, v6, v10 :: v_dual_lshlrev_b32 v1, 1, v47// 000000A81FB0: C9221506 06005E81
	v_add_f32_e32 v10, 0, v14                                  // 000000A81FB8: 06141C80
	v_dual_add_f32 v6, v6, v17 :: v_dual_add_f32 v17, v4, v19  // 000000A81FBC: C9082306 06102704
	v_add_f32_e32 v4, v8, v38                                  // 000000A81FC4: 06084D08
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A81FC8: BF870003
	v_add_f32_e32 v8, v10, v40                                 // 000000A81FCC: 0610510A
	s_clause 0x1                                               // 000000A81FD0: BF850001
	global_load_d16_b16 v2, v1, s[6:7]                         // 000000A81FD4: DC820000 02060001
	global_load_d16_b16 v3, v1, s[6:7] offset:32               // 000000A81FDC: DC820020 03060001
	v_dual_add_f32 v4, v4, v42 :: v_dual_add_f32 v39, v21, v35 // 000000A81FE4: C9085504 04264715
	ds_load_2addr_b32 v[21:22], v55 offset0:32 offset1:48      // 000000A81FEC: D8DC3020 15000037
	v_add_f32_e32 v13, v13, v28                                // 000000A81FF4: 061A390D
	v_add_f32_e32 v8, v8, v44                                  // 000000A81FF8: 06105908
	s_waitcnt lgkmcnt(1)                                       // 000000A81FFC: BF89FC17
	v_add_f32_e32 v10, 0, v23                                  // 000000A82000: 06142E80
	ds_load_2addr_b32 v[25:26], v49 offset0:192 offset1:208    // 000000A82004: D8DCD0C0 19000031
	ds_load_2addr_b32 v[27:28], v50 offset0:64 offset1:80      // 000000A8200C: D8DC5040 1B000032
	ds_load_2addr_b32 v[29:30], v55 offset0:160 offset1:176    // 000000A82014: D8DCB0A0 1D000037
	v_add_f32_e32 v8, v8, v5                                   // 000000A8201C: 06100B08
	s_waitcnt lgkmcnt(3)                                       // 000000A82020: BF89FC37
	v_dual_add_f32 v40, v6, v21 :: v_dual_add_f32 v13, v13, v32// 000000A82024: C9082B06 280C410D
	ds_load_2addr_b32 v[31:32], v50 offset0:192 offset1:208    // 000000A8202C: D8DCD0C0 1F000032
	ds_load_2addr_b32 v[33:34], v51 offset0:64 offset1:80      // 000000A82034: D8DC5040 21000033
	v_dual_add_f32 v6, v4, v46 :: v_dual_add_f32 v43, v13, v36 // 000000A8203C: C9085D04 062A490D
	ds_load_2addr_b32 v[12:13], v48 offset0:192 offset1:208    // 000000A82044: D8DCD0C0 0C000030
	ds_load_2addr_b32 v[14:15], v49 offset0:64 offset1:80      // 000000A8204C: D8DC5040 0E000031
	ds_load_2addr_b32 v[4:5], v51 offset0:192 offset1:208      // 000000A82054: D8DCD0C0 04000033
	ds_load_2addr_b32 v[35:36], v52 offset0:64 offset1:80      // 000000A8205C: D8DC5040 23000034
	v_add_f32_e32 v19, v6, v7                                  // 000000A82064: 06260F06
	ds_load_2addr_b32 v[6:7], v52 offset0:192 offset1:208      // 000000A82068: D8DCD0C0 06000034
	s_waitcnt lgkmcnt(4)                                       // 000000A82070: BF89FC47
	v_add_f32_e32 v12, 0, v12                                  // 000000A82074: 06181880
	s_waitcnt lgkmcnt(3)                                       // 000000A82078: BF89FC37
	v_add_f32_e32 v10, v10, v14                                // 000000A8207C: 06141D0A
	v_add_f32_e32 v14, v8, v9                                  // 000000A82080: 061C1308
	ds_load_2addr_b32 v[8:9], v53 offset0:64 offset1:80        // 000000A82084: D8DC5040 08000035
	v_dual_add_f32 v19, v19, v11 :: v_dual_add_f32 v12, v12, v25// 000000A8208C: C9081713 130C330C
	v_dual_add_f32 v21, v10, v27 :: v_dual_add_f32 v42, v17, v29// 000000A82094: C908370A 152A3B11
	ds_load_2addr_b32 v[10:11], v53 offset0:192 offset1:208    // 000000A8209C: D8DCD0C0 0A000035
	v_dual_add_f32 v14, v14, v16 :: v_dual_add_f32 v25, v19, v18// 000000A820A4: C908210E 0E182513
	v_dual_add_f32 v12, v12, v31 :: v_dual_add_f32 v21, v21, v33// 000000A820AC: C9083F0C 0C144315
	ds_load_2addr_b32 v[16:17], v54 offset0:64 offset1:80      // 000000A820B4: D8DC5040 10000036
	ds_load_2addr_b32 v[18:19], v54 offset0:192 offset1:208    // 000000A820BC: D8DCD0C0 12000036
	v_add_f32_e32 v27, v14, v20                                // 000000A820C4: 0636290E
	v_dual_add_f32 v14, 0, v24 :: v_dual_add_f32 v33, v25, v22 // 000000A820C8: C9083080 0E202D19
	s_waitcnt lgkmcnt(6)                                       // 000000A820D0: BF89FC67
	v_dual_add_f32 v4, v12, v4 :: v_dual_add_f32 v23, 0, v13   // 000000A820D4: C908090C 04161A80
	s_waitcnt lgkmcnt(5)                                       // 000000A820DC: BF89FC57
	v_add_f32_e32 v12, v21, v35                                // 000000A820E0: 06184715
	v_add_f32_e32 v24, v14, v15                                // 000000A820E4: 06301F0E
	ds_load_2addr_b32 v[20:21], v55 offset0:64 offset1:80      // 000000A820E8: D8DC5040 14000037
	ds_load_2addr_b32 v[37:38], v55 offset0:192 offset1:208    // 000000A820F0: D8DCD0C0 25000037
	ds_load_2addr_b32 v[14:15], v48 offset0:224 offset1:240    // 000000A820F8: D8DCF0E0 0E000030
	s_waitcnt lgkmcnt(6)                                       // 000000A82100: BF89FC67
	v_add_f32_e32 v8, v12, v8                                  // 000000A82104: 0610110C
	ds_load_2addr_b32 v[12:13], v48 offset0:96 offset1:112     // 000000A82108: D8DC7060 0C000030
	v_add_f32_e32 v6, v4, v6                                   // 000000A82110: 060C0D04
	global_load_d16_b16 v4, v1, s[6:7] offset:64               // 000000A82114: DC820040 04060001
	s_waitcnt lgkmcnt(6)                                       // 000000A8211C: BF89FC67
	v_add_f32_e32 v6, v6, v10                                  // 000000A82120: 060C1506
	v_add_f32_e32 v10, v23, v26                                // 000000A82124: 06143517
	v_add_f32_e32 v26, v24, v28                                // 000000A82128: 06343918
	s_waitcnt lgkmcnt(5)                                       // 000000A8212C: BF89FC57
	v_add_f32_e32 v8, v8, v16                                  // 000000A82130: 06102108
	ds_load_2addr_b32 v[23:24], v49 offset0:96 offset1:112     // 000000A82134: D8DC7060 17000031
	s_waitcnt lgkmcnt(5)                                       // 000000A8213C: BF89FC57
	v_add_f32_e32 v6, v6, v18                                  // 000000A82140: 060C2506
	v_add_f32_e32 v18, v27, v30                                // 000000A82144: 06243D1B
	v_add_f32_e32 v16, v26, v34                                // 000000A82148: 0620451A
	ds_load_2addr_b32 v[25:26], v49 offset0:224 offset1:240    // 000000A8214C: D8DCF0E0 19000031
	ds_load_2addr_b32 v[27:28], v50 offset0:96 offset1:112     // 000000A82154: D8DC7060 1B000032
	s_waitcnt lgkmcnt(4)                                       // 000000A8215C: BF89FC47
	v_dual_add_f32 v34, v6, v37 :: v_dual_add_f32 v37, 0, v15  // 000000A82160: C9084B06 22241E80
	v_add_f32_e32 v14, 0, v14                                  // 000000A82168: 061C1C80
	s_waitcnt lgkmcnt(1)                                       // 000000A8216C: BF89FC17
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000A82170: BF870142
	v_dual_add_f32 v12, 0, v12 :: v_dual_add_f32 v37, v37, v26 // 000000A82174: C9081880 0C243525
	v_add_f32_e32 v20, v8, v20                                 // 000000A8217C: 06282908
	v_add_f32_e32 v8, v16, v36                                 // 000000A82180: 06104910
	v_add_f32_e32 v14, v14, v25                                // 000000A82184: 061C330E
	v_add_f32_e32 v35, v8, v9                                  // 000000A82188: 06461308
	global_load_d16_b16 v8, v1, s[6:7] offset:96               // 000000A8218C: DC820060 08060001
	v_dual_add_f32 v17, v35, v17 :: v_dual_add_f32 v12, v12, v23// 000000A82194: C9082323 110C2F0C
	ds_load_2addr_b32 v[22:23], v51 offset0:96 offset1:112     // 000000A8219C: D8DC7060 16000033
	ds_load_2addr_b32 v[29:30], v51 offset0:224 offset1:240    // 000000A821A4: D8DCF0E0 1D000033
	v_and_b32_e32 v35, 4, v0                                   // 000000A821AC: 36460084
	s_waitcnt lgkmcnt(2)                                       // 000000A821B0: BF89FC27
	v_add_f32_e32 v25, v12, v27                                // 000000A821B4: 0632370C
	v_add_f32_e32 v27, 0, v13                                  // 000000A821B8: 06361A80
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A821BC: BF870113
	.long 0xd44a0004                                           // 000000A821C0: D44A0004
	v_cndmask_b32_e32 v1, 0, v35, vcc_lo                       // 000000A821C4: 02024680
	v_add_f32_e32 v44, v27, v24                                // 000000A821C8: 0658311B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A821CC: BF870001
	v_add_f32_e32 v44, v44, v28                                // 000000A821D0: 0658392C
	v_add_f32_e32 v10, v10, v32                                // 000000A821D4: 0614410A
	s_waitcnt lgkmcnt(1)                                       // 000000A821D8: BF89FC17
	v_add_f32_e32 v22, v25, v22                                // 000000A821DC: 062C2D19
	ds_load_2addr_b32 v[24:25], v54 offset0:96 offset1:112     // 000000A821E0: D8DC7060 18000036
	ds_load_2addr_b32 v[26:27], v54 offset0:224 offset1:240    // 000000A821E8: D8DCF0E0 1A000036
	v_dual_add_f32 v23, v44, v23 :: v_dual_add_f32 v6, v10, v5 // 000000A821F0: C9082F2C 17060B0A
	ds_load_2addr_b32 v[9:10], v50 offset0:224 offset1:240     // 000000A821F8: D8DCF0E0 09000032
	global_load_d16_b16 v5, v1, s[6:7] offset:1280             // 000000A82200: DC820500 05060001
	v_add_f32_e32 v7, v6, v7                                   // 000000A82208: 060E0F06
	global_load_d16_b16 v6, v1, s[6:7] offset:1312             // 000000A8220C: DC820520 06060001
	v_add_f32_e32 v36, v7, v11                                 // 000000A82214: 06481707
	ds_load_2addr_b32 v[11:12], v52 offset0:96 offset1:112     // 000000A82218: D8DC7060 0B000034
	ds_load_2addr_b32 v[31:32], v52 offset0:224 offset1:240    // 000000A82220: D8DCF0E0 1F000034
	global_load_d16_b16 v7, v1, s[8:9] offset:32               // 000000A82228: DC820020 07080001
	s_waitcnt lgkmcnt(2)                                       // 000000A82230: BF89FC27
	v_add_f32_e32 v9, v14, v9                                  // 000000A82234: 0612130E
	ds_load_2addr_b32 v[13:14], v53 offset0:96 offset1:112     // 000000A82238: D8DC7060 0D000035
	ds_load_2addr_b32 v[15:16], v53 offset0:224 offset1:240    // 000000A82240: D8DCF0E0 0F000035
	v_add_f32_e32 v37, v37, v10                                // 000000A82248: 064A1525
	v_add_f32_e32 v45, v9, v29                                 // 000000A8224C: 065A3B09
	ds_load_2addr_b32 v[9:10], v55 offset0:96 offset1:112      // 000000A82250: D8DC7060 09000037
	ds_load_2addr_b32 v[28:29], v55 offset0:224 offset1:240    // 000000A82258: D8DCF0E0 1C000037
	s_waitcnt lgkmcnt(5)                                       // 000000A82260: BF89FC57
	v_dual_add_f32 v30, v37, v30 :: v_dual_add_f32 v11, v22, v11// 000000A82264: C9083D25 1E0A1716
	s_waitcnt lgkmcnt(4)                                       // 000000A8226C: BF89FC47
	v_add_f32_e32 v22, v45, v31                                // 000000A82270: 062C3F2D
	global_load_d16_b16 v31, v1, s[6:7] offset:224             // 000000A82274: DC8200E0 1F060001
	s_waitcnt lgkmcnt(3)                                       // 000000A8227C: BF89FC37
	v_add_f32_e32 v11, v11, v13                                // 000000A82280: 06161B0B
	s_waitcnt lgkmcnt(2)                                       // 000000A82284: BF89FC27
	v_add_f32_e32 v13, v22, v15                                // 000000A82288: 061A1F16
	v_dual_add_f32 v15, v17, v21 :: v_dual_add_f32 v12, v23, v12// 000000A8228C: C9082B11 0F0C1917
	v_add_f32_e32 v17, v40, v33                                // 000000A82294: 06224328
	v_add_f32_e32 v11, v11, v24                                // 000000A82298: 0616310B
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A8229C: BF870004
	v_add_f32_e32 v13, v13, v26                                // 000000A822A0: 061A350D
	v_add_f32_e32 v23, v30, v32                                // 000000A822A4: 062E411E
	v_add_f32_e32 v19, v36, v19                                // 000000A822A8: 06262724
	v_add_f32_e32 v21, v20, v15                                // 000000A822AC: 062A1F14
	s_waitcnt lgkmcnt(1)                                       // 000000A822B0: BF89FC17
	v_add_f32_e32 v9, v11, v9                                  // 000000A822B4: 0612130B
	s_waitcnt lgkmcnt(0)                                       // 000000A822B8: BF89FC07
	v_add_f32_e32 v11, v13, v28                                // 000000A822BC: 0616390D
	v_add_f32_e32 v13, v56, v41                                // 000000A822C0: 061A5338
	v_add_f32_e32 v12, v12, v14                                // 000000A822C4: 06181D0C
	v_dual_add_f32 v14, v23, v16 :: v_dual_sub_f32 v15, v20, v15// 000000A822C8: C90A2117 0E0E1F14
	v_dual_add_f32 v16, v19, v38 :: v_dual_sub_f32 v19, v40, v33// 000000A822D0: C90A4D13 10124328
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A822D8: BF870004
	v_dual_add_f32 v22, v13, v17 :: v_dual_add_f32 v23, v42, v18// 000000A822DC: C908230D 1616252A
	v_sub_f32_e32 v13, v13, v17                                // 000000A822E4: 081A230D
	v_dual_add_f32 v12, v12, v25 :: v_dual_and_b32 v33, 2, v0  // 000000A822E8: C924330C 0C200082
	s_clause 0x1                                               // 000000A822F0: BF850001
	global_load_d16_b16 v24, v1, s[6:7] offset:160             // 000000A822F4: DC8200A0 18060001
	global_load_d16_b16 v28, v1, s[6:7] offset:192             // 000000A822FC: DC8200C0 1C060001
	v_add_f32_e32 v10, v12, v10                                // 000000A82304: 0614150C
	.long 0xd44a0003                                           // 000000A82308: D44A0003
	v_cndmask_b32_e32 v1, 0, v33, vcc_lo                       // 000000A8230C: 02024280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A82310: BF870092
	v_add_f32_e32 v20, v9, v10                                 // 000000A82314: 06281509
	v_dual_add_f32 v14, v14, v27 :: v_dual_add_f32 v27, v21, v20// 000000A82318: C908370E 0E1A2915
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A82320: BF8700A1
	v_add_f32_e32 v12, v14, v29                                // 000000A82324: 06183B0E
	v_sub_f32_e32 v14, v56, v41                                // 000000A82328: 081C5338
	v_add_f32_e32 v17, v14, v19                                // 000000A8232C: 0622270E
	v_sub_f32_e32 v14, v14, v19                                // 000000A82330: 081C270E
	v_add_f32_e32 v19, v39, v43                                // 000000A82334: 06265727
	v_sub_f32_e32 v9, v9, v10                                  // 000000A82338: 08121509
	global_load_d16_b16 v10, v1, s[6:7] offset:128             // 000000A8233C: DC820080 0A060001
	v_add_f32_e32 v30, v15, v9                                 // 000000A82344: 063C130F
	v_dual_sub_f32 v9, v15, v9 :: v_dual_sub_f32 v20, v21, v20 // 000000A82348: C94A130F 09142915
	v_add_f32_e32 v21, v19, v23                                // 000000A82350: 062A2F13
	v_and_b32_e32 v15, 1, v0                                   // 000000A82354: 361E0081
	v_dual_add_f32 v25, v34, v16 :: v_dual_sub_f32 v36, v39, v43// 000000A82358: C90A2122 19245727
	v_sub_f32_e32 v18, v42, v18                                // 000000A82360: 0824252A
	v_add_f32_e32 v26, v11, v12                                // 000000A82364: 0634190B
	v_sub_f32_e32 v11, v11, v12                                // 000000A82368: 0816190B
	v_sub_f32_e32 v12, v19, v23                                // 000000A8236C: 08182F13
	.long 0xd44a0002                                           // 000000A82370: D44A0002
	v_cndmask_b32_e32 v1, 0, v15, vcc_lo                       // 000000A82374: 02021E80
	v_add_f32_e32 v19, v36, v18                                // 000000A82378: 06262524
	v_dual_add_f32 v29, v25, v26 :: v_dual_and_b32 v0, 8, v0   // 000000A8237C: C9243519 1D000088
	v_sub_f32_e32 v23, v25, v26                                // 000000A82384: 082E3519
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A82388: BF870222
	v_add_f32_e32 v32, v21, v29                                // 000000A8238C: 06403B15
	v_sub_f32_e32 v21, v21, v29                                // 000000A82390: 082A3B15
	.long 0xd44a0001                                           // 000000A82394: D44A0001
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 000000A82398: 02020080
	global_load_d16_b16 v29, v1, s[6:7] offset:1344            // 000000A8239C: DC820540 1D060001
	v_mov_b32_dpp v37, v32 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A823A4: 7E4A02FA FF016120
	v_cndmask_b32_e64 v15, -v32, v32, s2                       // 000000A823AC: D501000F 200A4120
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A823B4: BF870001
	v_add_f32_e32 v15, v15, v37                                // 000000A823B8: 061E4B0F
	s_clause 0x6                                               // 000000A823BC: BF850006
	global_load_d16_b16 v37, v1, s[8:9]                        // 000000A823C0: DC820000 25080001
	global_load_d16_b16 v38, v1, s[8:9] offset:64              // 000000A823C8: DC820040 26080001
	global_load_d16_b16 v39, v1, s[8:9] offset:96              // 000000A823D0: DC820060 27080001
	global_load_d16_b16 v40, v1, s[8:9] offset:128             // 000000A823D8: DC820080 28080001
	global_load_d16_b16 v41, v1, s[8:9] offset:160             // 000000A823E0: DC8200A0 29080001
	global_load_d16_b16 v42, v1, s[8:9] offset:192             // 000000A823E8: DC8200C0 2A080001
	global_load_d16_b16 v43, v1, s[8:9] offset:224             // 000000A823F0: DC8200E0 2B080001
	v_mov_b32_dpp v26, v15 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A823F8: 7E3402FA FF01620F
	v_cndmask_b32_e64 v15, -v15, v15, s3                       // 000000A82400: D501000F 200E1F0F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A82408: BF870091
	v_dual_sub_f32 v16, v34, v16 :: v_dual_add_f32 v15, v15, v26// 000000A8240C: C9482122 100E350F
	v_add_f32_e32 v25, v16, v11                                // 000000A82414: 06321710
	v_sub_f32_e32 v11, v16, v11                                // 000000A82418: 08161710
	v_sub_f32_e32 v18, v36, v18                                // 000000A8241C: 08242524
	v_add_f32_e32 v36, v22, v27                                // 000000A82420: 06483716
	v_mov_b32_dpp v32, v15 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A82424: 7E4002FA FF01640F
	v_add_f32_e32 v16, v19, v25                                // 000000A8242C: 06203313
	v_sub_f32_e32 v19, v19, v25                                // 000000A82430: 08263313
	v_cndmask_b32_e64 v15, -v15, v15, s4                       // 000000A82434: D501000F 20121F0F
	v_add_f32_e32 v26, v12, v23                                // 000000A8243C: 06342F0C
	v_sub_f32_e32 v22, v22, v27                                // 000000A82440: 082C3716
	v_mov_b32_dpp v25, v16 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A82444: 7E3202FA FF016110
	v_cndmask_b32_e64 v16, -v16, v16, s2                       // 000000A8244C: D5010010 200A2110
	v_add_f32_e32 v15, v15, v32                                // 000000A82454: 061E410F
	v_mov_b32_dpp v47, v19 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A82458: 7E5E02FA FF016113
	v_cndmask_b32_e64 v19, -v19, v19, s2                       // 000000A82460: D5010013 200A2713
	global_load_d16_b16 v32, v1, s[6:7] offset:1376            // 000000A82468: DC820560 20060001
	v_add_f32_e32 v16, v16, v25                                // 000000A82470: 06203310
	v_mov_b32_dpp v25, v26 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A82474: 7E3202FA FF01611A
	v_cndmask_b32_e64 v26, -v26, v26, s2                       // 000000A8247C: D501001A 200A351A
	v_cndmask_b32_e64 v0, -v15, v15, s1                        // 000000A82484: D5010000 20061F0F
	v_add_f32_e32 v19, v19, v47                                // 000000A8248C: 06265F13
	v_mov_b32_dpp v27, v22 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A82490: 7E3602FA FF016116
	v_cndmask_b32_e64 v22, -v22, v22, s2                       // 000000A82498: D5010016 200A2D16
	v_dual_add_f32 v25, v26, v25 :: v_dual_sub_f32 v12, v12, v23// 000000A824A0: C90A331A 190C2F0C
	v_add_f32_e32 v26, v18, v11                                // 000000A824A8: 06341712
	v_sub_f32_e32 v11, v18, v11                                // 000000A824AC: 08161712
	v_mov_b32_dpp v23, v16 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A824B0: 7E2E02FA FF016210
	v_cndmask_b32_e64 v16, -v16, v16, s3                       // 000000A824B8: D5010010 200E2110
	v_mov_b32_dpp v18, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A824C0: 7E2402FA FF01680F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A824C8: BF870232
	v_add_f32_e32 v16, v16, v23                                // 000000A824CC: 06202F10
	v_mov_b32_dpp v23, v25 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A824D0: 7E2E02FA FF016219
	v_cndmask_b32_e64 v25, -v25, v25, s3                       // 000000A824D8: D5010019 200E3319
	v_add_f32_e32 v0, v0, v18                                  // 000000A824E0: 06002500
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A824E4: BF8701A4
	v_mov_b32_dpp v15, v16 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A824E8: 7E1E02FA FF016410
	v_cndmask_b32_e64 v16, -v16, v16, s4                       // 000000A824F0: D5010010 20122110
	v_dual_add_f32 v23, v25, v23 :: v_dual_mul_f32 v0, 0x3db504f3, v0// 000000A824F8: C9062F19 170000FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A82504: BF870112
	v_add_f32_e32 v15, v16, v15                                // 000000A82508: 061E1F10
	v_mov_b32_dpp v16, v23 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A8250C: 7E2002FA FF016417
	v_cndmask_b32_e64 v23, -v23, v23, s4                       // 000000A82514: D5010017 20122F17
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A8251C: BF8701A3
	v_mov_b32_dpp v18, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A82520: 7E2402FA FF01680F
	v_cndmask_b32_e64 v15, -v15, v15, s1                       // 000000A82528: D501000F 20061F0F
	v_add_f32_e32 v16, v23, v16                                // 000000A82530: 06202117
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A82534: BF870232
	v_add_f32_e32 v15, v15, v18                                // 000000A82538: 061E250F
	v_mov_b32_dpp v25, v26 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A8253C: 7E3202FA FF01611A
	v_cndmask_b32_e64 v26, -v26, v26, s2                       // 000000A82544: D501001A 200A351A
	v_mov_b32_dpp v18, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A8254C: 7E2402FA FF016810
	v_cndmask_b32_e64 v16, -v16, v16, s1                       // 000000A82554: D5010010 20062110
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A8255C: BF870091
	v_dual_add_f32 v25, v26, v25 :: v_dual_add_f32 v16, v16, v18// 000000A82560: C908331A 19102510
	v_mov_b32_dpp v23, v25 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A82568: 7E2E02FA FF016219
	v_cndmask_b32_e64 v25, -v25, v25, s3                       // 000000A82570: D5010019 200E3319
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A82578: BF8701B1
	v_dual_mul_f32 v16, 0x3db504f3, v16 :: v_dual_add_f32 v23, v25, v23// 000000A8257C: C8C820FF 10162F19 3DB504F3
	v_mov_b32_dpp v25, v21 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A82588: 7E3202FA FF016115
	v_cndmask_b32_e64 v21, -v21, v21, s2                       // 000000A82590: D5010015 200A2B15
	v_mov_b32_dpp v18, v23 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A82598: 7E2402FA FF016417
	v_cndmask_b32_e64 v23, -v23, v23, s4                       // 000000A825A0: D5010017 20122F17
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A825A8: BF870003
	v_add_f32_e32 v21, v21, v25                                // 000000A825AC: 062A3315
	v_mul_f32_e32 v15, 0x3db504f3, v15                         // 000000A825B0: 101E1EFF 3DB504F3
	s_clause 0x3                                               // 000000A825B8: BF850003
	global_load_d16_b16 v25, v1, s[6:7] offset:1440            // 000000A825BC: DC8205A0 19060001
	global_load_d16_b16 v26, v1, s[6:7] offset:1408            // 000000A825C4: DC820580 1A060001
	global_load_d16_b16 v33, v1, s[6:7] offset:1472            // 000000A825CC: DC8205C0 21060001
	global_load_d16_b16 v34, v1, s[6:7] offset:1504            // 000000A825D4: DC8205E0 22060001
	v_add_f32_e32 v18, v23, v18                                // 000000A825DC: 06242517
	v_mov_b32_dpp v35, v21 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A825E0: 7E4602FA FF016215
	v_cndmask_b32_e64 v21, -v21, v21, s3                       // 000000A825E8: D5010015 200E2B15
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A825F0: BF8701A3
	v_mov_b32_dpp v44, v18 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A825F4: 7E5802FA FF016812
	v_cndmask_b32_e64 v18, -v18, v18, s1                       // 000000A825FC: D5010012 20062512
	v_add_f32_e32 v21, v21, v35                                // 000000A82604: 062A4715
	v_add_f32_e32 v35, v17, v30                                // 000000A82608: 06463D11
	v_mov_b32_dpp v23, v36 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A8260C: 7E2E02FA FF016124
	v_cndmask_b32_e64 v36, -v36, v36, s2                       // 000000A82614: D5010024 200A4924
	v_dual_add_f32 v18, v18, v44 :: v_dual_sub_f32 v17, v17, v30// 000000A8261C: C90A5912 12103D11
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A82624: BF870224
	v_mov_b32_dpp v45, v35 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A82628: 7E5A02FA FF016123
	v_cndmask_b32_e64 v35, -v35, v35, s2                       // 000000A82630: D5010023 200A4723
	v_add_f32_e32 v23, v36, v23                                // 000000A82638: 062E2F24
	v_mov_b32_dpp v36, v21 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A8263C: 7E4802FA FF016415
	v_cndmask_b32_e64 v21, -v21, v21, s4                       // 000000A82644: D5010015 20122B15
	v_mul_f32_e32 v18, 0x3db504f3, v18                         // 000000A8264C: 102424FF 3DB504F3
	v_mov_b32_dpp v30, v17 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A82654: 7E3C02FA FF016111
	v_mov_b32_dpp v46, v23 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A8265C: 7E5C02FA FF016217
	v_cndmask_b32_e64 v23, -v23, v23, s3                       // 000000A82664: D5010017 200E2F17
	v_cndmask_b32_e64 v17, -v17, v17, s2                       // 000000A8266C: D5010011 200A2311
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000A82674: BF8700B2
	v_add_f32_e32 v23, v23, v46                                // 000000A82678: 062E5D17
	v_mov_b32_dpp v46, v19 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A8267C: 7E5C02FA FF016213
	v_cndmask_b32_e64 v19, -v19, v19, s3                       // 000000A82684: D5010013 200E2713
	v_add_f32_e32 v19, v19, v46                                // 000000A8268C: 06265D13
	v_mov_b32_dpp v46, v12 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A82690: 7E5C02FA FF01610C
	v_cndmask_b32_e64 v12, -v12, v12, s2                       // 000000A82698: D501000C 200A190C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A826A0: BF870091
	v_dual_add_f32 v35, v35, v45 :: v_dual_add_f32 v12, v12, v46// 000000A826A4: C9085B23 230C5D0C
	v_mov_b32_dpp v46, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A826AC: 7E5C02FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, s3                       // 000000A826B4: D501000C 200E190C
	v_add_f32_e32 v21, v21, v36                                // 000000A826BC: 062A4915
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A826C0: BF8700A4
	v_mov_b32_dpp v36, v35 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A826C4: 7E4802FA FF016223
	v_cndmask_b32_e64 v35, -v35, v35, s3                       // 000000A826CC: D5010023 200E4723
	v_dual_add_f32 v12, v12, v46 :: v_dual_add_f32 v35, v35, v36// 000000A826D4: C9085D0C 0C224923
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A826DC: BF8701A4
	v_mov_b32_dpp v36, v21 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A826E0: 7E4802FA FF016815
	v_cndmask_b32_e64 v21, -v21, v21, s1                       // 000000A826E8: D5010015 20062B15
	v_mov_b32_dpp v44, v35 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A826F0: 7E5802FA FF016423
	v_cndmask_b32_e64 v35, -v35, v35, s4                       // 000000A826F8: D5010023 20124723
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A82700: BF870113
	v_add_f32_e32 v21, v21, v36                                // 000000A82704: 062A4915
	v_add_f32_e32 v35, v35, v44                                // 000000A82708: 06465923
	v_mov_b32_dpp v44, v19 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A8270C: 7E5802FA FF016413
	v_cndmask_b32_e64 v19, -v19, v19, s4                       // 000000A82714: D5010013 20122713
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000A8271C: BF8700B1
	v_add_f32_e32 v19, v19, v44                                // 000000A82720: 06265913
	v_mov_b32_dpp v44, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A82724: 7E5802FA FF01640C
	v_cndmask_b32_e64 v12, -v12, v12, s4                       // 000000A8272C: D501000C 2012190C
	v_add_f32_e32 v12, v12, v44                                // 000000A82734: 0618590C
	v_mov_b32_dpp v45, v23 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A82738: 7E5A02FA FF016417
	v_cndmask_b32_e64 v23, -v23, v23, s4                       // 000000A82740: D5010017 20122F17
	v_mov_b32_dpp v44, v11 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A82748: 7E5802FA FF01610B
	v_cndmask_b32_e64 v11, -v11, v11, s2                       // 000000A82750: D501000B 200A170B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A82758: BF870113
	v_add_f32_e32 v23, v23, v45                                // 000000A8275C: 062E5B17
	v_add_f32_e32 v11, v11, v44                                // 000000A82760: 0616590B
	v_mov_b32_dpp v44, v12 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A82764: 7E5802FA FF01680C
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 000000A8276C: D501000C 2006190C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A82774: BF8700A4
	v_mov_b32_dpp v45, v23 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A82778: 7E5A02FA FF016817
	v_cndmask_b32_e64 v23, -v23, v23, s1                       // 000000A82780: D5010017 20062F17
	v_dual_add_f32 v12, v12, v44 :: v_dual_add_f32 v23, v23, v45// 000000A82788: C908590C 0C165B17
	v_mov_b32_dpp v45, v35 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A82790: 7E5A02FA FF016823
	v_cndmask_b32_e64 v35, -v35, v35, s1                       // 000000A82798: D5010023 20064723
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000A827A0: BF870133
	v_dual_mul_f32 v12, 0x3db504f3, v12 :: v_dual_mul_f32 v23, 0x3db504f3, v23// 000000A827A4: C8C618FF 0C162EFF 3DB504F3
	s_waitcnt vmcnt(19)                                        // 000000A827B0: BF894FF7
	v_fma_mix_f32 v0, v5, v0, neg(0) op_sel_hi:[1,0,0]         // 000000A827B4: CC200000 8A020105
	v_fma_mix_f32 v2, v2, v23, neg(0) op_sel_hi:[1,0,0]        // 000000A827BC: CC200002 8A022F02
	s_waitcnt vmcnt(18)                                        // 000000A827C4: BF894BF7
	v_fma_mix_f32 v6, v6, v15, neg(0) op_sel_hi:[1,0,0]        // 000000A827C8: CC200006 8A021F06
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A827D0: BF870092
	v_mul_f32_e32 v36, 0xbfb8aa3b, v2                          // 000000A827D4: 104804FF BFB8AA3B
	v_exp_f32_e32 v36, v36                                     // 000000A827DC: 7E484B24
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A827E0: BF870095
	v_add_f32_e32 v36, 1.0, v36                                // 000000A827E4: 064848F2
	v_div_scale_f32 v46, null, v36, v36, v2                    // 000000A827E8: D6FC7C2E 040A4924
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000A827F0: BF870291
	v_rcp_f32_e32 v47, v46                                     // 000000A827F4: 7E5E552E
	v_fma_f32 v49, -v46, v47, 1.0                              // 000000A827F8: D6130031 23CA5F2E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000A82800: BF8700D1
	v_fmac_f32_e32 v47, v49, v47                               // 000000A82804: 565E5F31
	v_div_scale_f32 v49, vcc_lo, v2, v36, v2                   // 000000A82808: D6FC6A31 040A4902
	v_add_f32_e32 v23, v35, v45                                // 000000A82810: 062E5B23
	v_mov_b32_dpp v35, v19 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A82814: 7E4602FA FF016813
	v_cndmask_b32_e64 v19, -v19, v19, s1                       // 000000A8281C: D5010013 20062713
	v_add_f32_e32 v19, v19, v35                                // 000000A82824: 06264713
	v_add_f32_e32 v35, v13, v20                                // 000000A82828: 0646290D
	v_sub_f32_e32 v13, v13, v20                                // 000000A8282C: 081A290D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A82830: BF8700A2
	v_mov_b32_dpp v45, v35 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A82834: 7E5A02FA FF016123
	v_cndmask_b32_e64 v35, -v35, v35, s2                       // 000000A8283C: D5010023 200A4723
	v_add_f32_e32 v35, v35, v45                                // 000000A82844: 06465B23
	v_mov_b32_dpp v45, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A82848: 7E5A02FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s3                       // 000000A82850: D501000B 200E170B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A82858: BF8701A3
	v_mov_b32_dpp v48, v35 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A8285C: 7E6002FA FF016223
	v_cndmask_b32_e64 v35, -v35, v35, s3                       // 000000A82864: D5010023 200E4723
	v_add_f32_e32 v11, v11, v45                                // 000000A8286C: 06165B0B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A82870: BF870112
	v_add_f32_e32 v35, v35, v48                                // 000000A82874: 06466123
	v_mov_b32_dpp v44, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A82878: 7E5802FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s4                       // 000000A82880: D501000B 2012170B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A82888: BF8701A3
	v_mov_b32_dpp v50, v35 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A8288C: 7E6402FA FF016423
	v_cndmask_b32_e64 v35, -v35, v35, s4                       // 000000A82894: D5010023 20124723
	v_dual_add_f32 v11, v11, v44 :: v_dual_add_f32 v44, v14, v9// 000000A8289C: C908590B 0B2C130E
	v_sub_f32_e32 v9, v14, v9                                  // 000000A828A4: 0812130E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A828A8: BF870193
	v_add_f32_e32 v35, v35, v50                                // 000000A828AC: 06466523
	v_mov_b32_dpp v51, v44 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A828B0: 7E6602FA FF01612C
	v_cndmask_b32_e64 v44, -v44, v44, s2                       // 000000A828B8: D501002C 200A592C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A828C0: BF8700A3
	v_mov_b32_dpp v52, v35 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A828C4: 7E6802FA FF016823
	v_cndmask_b32_e64 v35, -v35, v35, s1                       // 000000A828CC: D5010023 20064723
	v_dual_add_f32 v44, v44, v51 :: v_dual_add_f32 v35, v35, v52// 000000A828D4: C908672C 2C226923
	v_mul_f32_e32 v52, v49, v47                                // 000000A828DC: 10685F31
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A828E0: BF870222
	v_mov_b32_dpp v54, v44 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A828E4: 7E6C02FA FF01622C
	v_cndmask_b32_e64 v44, -v44, v44, s3                       // 000000A828EC: D501002C 200E592C
	v_mul_f32_e32 v35, 0x3db504f3, v35                         // 000000A828F4: 104646FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A828FC: BF870194
	v_fma_f32 v55, -v46, v52, v49                              // 000000A82900: D6130037 24C6692E
	v_dual_add_f32 v44, v44, v54 :: v_dual_mul_f32 v21, 0x3db504f3, v21// 000000A82908: C9066D2C 2C142AFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A82914: BF870193
	v_fma_mix_f32 v4, v4, v35, neg(0) op_sel_hi:[1,0,0]        // 000000A82918: CC200004 8A024704
	v_fmac_f32_e32 v52, v55, v47                               // 000000A82920: 56685F37
	s_waitcnt vmcnt(12)                                        // 000000A82924: BF8933F7
	v_fma_mix_f32 v16, v29, v16, neg(0) op_sel_hi:[1,0,0]      // 000000A82928: CC200010 8A02211D
	v_mov_b32_dpp v35, v44 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A82930: 7E4602FA FF01642C
	v_cndmask_b32_e64 v44, -v44, v44, s4                       // 000000A82938: D501002C 2012592C
	v_fma_f32 v46, -v46, v52, v49                              // 000000A82940: D613002E 24C6692E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A82948: BF870112
	v_add_f32_e32 v35, v44, v35                                // 000000A8294C: 0646472C
	v_div_fmas_f32 v44, v46, v47, v52                          // 000000A82950: D637002C 04D25F2E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A82958: BF8701A2
	v_mov_b32_dpp v46, v35 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A8295C: 7E5C02FA FF016823
	v_cndmask_b32_e64 v35, -v35, v35, s1                       // 000000A82964: D5010023 20064723
	v_div_fixup_f32 v2, v44, v36, v2                           // 000000A8296C: D6270002 040A492C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A82974: BF870091
	v_dual_mul_f32 v23, 0x3db504f3, v23 :: v_dual_mul_f32 v0, v0, v2// 000000A82978: C8C62EFF 17000500 3DB504F3
	v_fma_mix_f32 v3, v3, v23, neg(0) op_sel_hi:[1,0,0]        // 000000A82984: CC200003 8A022F03
	v_add_f32_e32 v2, v22, v27                                 // 000000A8298C: 06043716
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A82990: BF870092
	v_mul_f32_e32 v23, 0xbfb8aa3b, v3                          // 000000A82994: 102E06FF BFB8AA3B
	v_exp_f32_e32 v23, v23                                     // 000000A8299C: 7E2E4B17
	s_waitcnt vmcnt(4)                                         // 000000A829A0: BF8913F7
	v_fma_mix_f32 v18, v32, v18, neg(0) op_sel_hi:[1,0,0]      // 000000A829A4: CC200012 8A022520
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A829AC: BF870095
	v_add_f32_e32 v23, 1.0, v23                                // 000000A829B0: 062E2EF2
	v_div_scale_f32 v45, null, v23, v23, v3                    // 000000A829B4: D6FC7C2D 040E2F17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000A829BC: BF870291
	v_rcp_f32_e32 v48, v45                                     // 000000A829C0: 7E60552D
	v_fma_f32 v50, -v45, v48, 1.0                              // 000000A829C4: D6130032 23CA612D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000A829CC: BF8700C1
	v_fmac_f32_e32 v48, v50, v48                               // 000000A829D0: 56606132
	v_div_scale_f32 v50, s5, v3, v23, v3                       // 000000A829D4: D6FC0532 040E2F03
	s_mov_b32 vcc_lo, s5                                       // 000000A829DC: BEEA0005
	v_mul_f32_e32 v53, v50, v48                                // 000000A829E0: 106A6132
	v_fma_f32 v56, -v45, v53, v50                              // 000000A829E4: D6130038 24CA6B2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A829EC: BF870091
	v_fmac_f32_e32 v53, v56, v48                               // 000000A829F0: 566A6138
	v_fma_f32 v45, -v45, v53, v50                              // 000000A829F4: D613002D 24CA6B2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A829FC: BF870091
	v_div_fmas_f32 v45, v45, v48, v53                          // 000000A82A00: D637002D 04D6612D
	v_div_fixup_f32 v3, v45, v23, v3                           // 000000A82A08: D6270003 040E2F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A82A10: BF8701B1
	v_dual_mul_f32 v3, v6, v3 :: v_dual_add_f32 v6, v17, v30   // 000000A82A14: C8C80706 03063D11
	v_mov_b32_dpp v17, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A82A1C: 7E2202FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 000000A82A24: D5010002 200E0502
	v_fma_mix_f32 v3, v7, v3, neg(0) op_sel_hi:[1,0,0]         // 000000A82A2C: CC200003 8A020707
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A82A34: BF870224
	v_mov_b32_dpp v22, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A82A38: 7E2C02FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, s3                          // 000000A82A40: D5010006 200E0D06
	v_add_f32_e32 v2, v2, v17                                  // 000000A82A48: 06042302
	v_mov_b32_dpp v17, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A82A4C: 7E2202FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, s2                       // 000000A82A54: D501000D 200A1B0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A82A5C: BF870214
	v_add_f32_e32 v6, v6, v22                                  // 000000A82A60: 060C2D06
	v_mov_b32_dpp v14, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A82A64: 7E1C02FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s4                          // 000000A82A6C: D5010002 20120502
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A82A74: BF870004
	v_add_f32_e32 v13, v13, v17                                // 000000A82A78: 061A230D
	v_mov_b32_dpp v17, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A82A7C: 7E2202FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s2                          // 000000A82A84: D5010009 200A1309
	v_mov_b32_dpp v20, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A82A8C: 7E2802FA FF016406
	v_add_f32_e32 v2, v2, v14                                  // 000000A82A94: 06041D02
	v_mov_b32_dpp v22, v13 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A82A98: 7E2C02FA FF01620D
	v_cndmask_b32_e64 v13, -v13, v13, s3                       // 000000A82AA0: D501000D 200E1B0D
	v_add_f32_e32 v9, v9, v17                                  // 000000A82AA8: 06122309
	v_cndmask_b32_e64 v6, -v6, v6, s4                          // 000000A82AAC: D5010006 20120D06
	v_mov_b32_dpp v17, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A82AB4: 7E2202FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 000000A82ABC: D5010002 20060502
	v_mul_f32_e32 v19, 0x3db504f3, v19                         // 000000A82AC4: 102626FF 3DB504F3
	v_add_f32_e32 v13, v13, v22                                // 000000A82ACC: 061A2D0D
	v_mov_b32_dpp v14, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A82AD0: 7E1C02FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 000000A82AD8: D5010009 200E1309
	v_add_f32_e32 v2, v2, v17                                  // 000000A82AE0: 06042302
	v_add_f32_e32 v6, v6, v20                                  // 000000A82AE4: 060C2906
	v_mov_b32_dpp v20, v13 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A82AE8: 7E2802FA FF01640D
	v_cndmask_b32_e64 v13, -v13, v13, s4                       // 000000A82AF0: D501000D 20121B0D
	v_add_f32_e32 v9, v9, v14                                  // 000000A82AF8: 06121D09
	v_mul_f32_e32 v2, 0x3db504f3, v2                           // 000000A82AFC: 100404FF 3DB504F3
	v_mov_b32_dpp v14, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A82B04: 7E1C02FA FF016806
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 000000A82B0C: D5010006 20060D06
	v_add_f32_e32 v13, v13, v20                                // 000000A82B14: 061A290D
	v_mov_b32_dpp v17, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A82B18: 7E2202FA FF016409
	v_fma_mix_f32 v2, v10, v2, neg(0) op_sel_hi:[1,0,0]        // 000000A82B20: CC200002 8A02050A
	v_cndmask_b32_e64 v9, -v9, v9, s4                          // 000000A82B28: D5010009 20121309
	v_add_f32_e32 v6, v6, v14                                  // 000000A82B30: 060C1D06
	v_mov_b32_dpp v14, v13 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A82B34: 7E1C02FA FF01680D
	v_cndmask_b32_e64 v13, -v13, v13, s1                       // 000000A82B3C: D501000D 20061B0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A82B44: BF870234
	v_dual_mul_f32 v20, 0xbfb8aa3b, v2 :: v_dual_add_f32 v9, v9, v17// 000000A82B48: C8C804FF 14082309 BFB8AA3B
	v_mov_b32_dpp v51, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A82B54: 7E6602FA FF01680B
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 000000A82B5C: D501000B 2006170B
	v_add_f32_e32 v10, v13, v14                                // 000000A82B64: 06141D0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000A82B68: BF870144
	v_exp_f32_e32 v20, v20                                     // 000000A82B6C: 7E284B14
	v_mov_b32_dpp v13, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A82B70: 7E1A02FA FF016809
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 000000A82B78: D5010009 20061309
	v_mul_f32_e32 v6, 0x3db504f3, v6                           // 000000A82B80: 100C0CFF 3DB504F3
	v_dual_mul_f32 v10, 0x3db504f3, v10 :: v_dual_add_f32 v9, v9, v13// 000000A82B88: C8C814FF 0A081B09 3DB504F3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000A82B94: BF870292
	v_fma_mix_f32 v6, v24, v6, neg(0) op_sel_hi:[1,0,0]        // 000000A82B98: CC200006 8A020D18
	v_dual_add_f32 v11, v11, v51 :: v_dual_add_f32 v20, 1.0, v20// 000000A82BA0: C908670B 0B1428F2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A82BA8: BF870213
	v_fma_mix_f32 v10, v28, v10, neg(0) op_sel_hi:[1,0,0]      // 000000A82BAC: CC20000A 8A02151C
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 000000A82BB4: 101212FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A82BBC: BF870214
	v_mul_f32_e32 v22, 0xbfb8aa3b, v6                          // 000000A82BC0: 102C0CFF BFB8AA3B
	v_div_scale_f32 v30, null, v20, v20, v2                    // 000000A82BC8: D6FC7C1E 040A2914
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A82BD0: BF870214
	v_mul_f32_e32 v28, 0xbfb8aa3b, v10                         // 000000A82BD4: 103814FF BFB8AA3B
	v_fma_mix_f32 v9, v31, v9, neg(0) op_sel_hi:[1,0,0]        // 000000A82BDC: CC200009 8A02131F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(TRANS32_DEP_2)// 000000A82BE4: BF870334
	v_exp_f32_e32 v22, v22                                     // 000000A82BE8: 7E2C4B16
	v_mul_f32_e32 v11, 0x3db504f3, v11                         // 000000A82BEC: 101616FF 3DB504F3
	v_rcp_f32_e32 v31, v30                                     // 000000A82BF4: 7E3E551E
	v_add_f32_e32 v22, 1.0, v22                                // 000000A82BF8: 062C2CF2
	s_waitcnt vmcnt(0)                                         // 000000A82BFC: BF8903F7
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000A82C00: BF870292
	v_fma_mix_f32 v11, v34, v11, neg(0) op_sel_hi:[1,0,0]      // 000000A82C04: CC20000B 8A021722
	v_fma_f32 v44, -v30, v31, 1.0                              // 000000A82C0C: D613002C 23CA3F1E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000A82C14: BF870131
	v_fmac_f32_e32 v31, v44, v31                               // 000000A82C18: 563E3F2C
	v_add_f32_e32 v5, v35, v46                                 // 000000A82C1C: 060A5D23
	v_div_scale_f32 v35, null, v22, v22, v6                    // 000000A82C20: D6FC7C23 041A2D16
	v_mul_f32_e32 v5, 0x3db504f3, v5                           // 000000A82C28: 100A0AFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A82C30: BF870092
	v_rcp_f32_e32 v36, v35                                     // 000000A82C34: 7E485523
	v_fma_mix_f32 v5, v8, v5, neg(0) op_sel_hi:[1,0,0]         // 000000A82C38: CC200005 8A020B08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000A82C40: BF870291
	v_mul_f32_e32 v7, 0xbfb8aa3b, v5                           // 000000A82C44: 100E0AFF BFB8AA3B
	v_fma_f32 v44, -v35, v36, 1.0                              // 000000A82C4C: D613002C 23CA4923
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A82C54: BF870092
	v_exp_f32_e32 v7, v7                                       // 000000A82C58: 7E0E4B07
	v_fmac_f32_e32 v36, v44, v36                               // 000000A82C5C: 5648492C
	v_div_scale_f32 v44, s7, v6, v22, v6                       // 000000A82C60: D6FC072C 041A2D06
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A82C68: BF870095
	v_add_f32_e32 v7, 1.0, v7                                  // 000000A82C6C: 060E0EF2
	v_div_scale_f32 v17, null, v7, v7, v5                      // 000000A82C70: D6FC7C11 04160F07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000A82C78: BF870291
	v_rcp_f32_e32 v14, v17                                     // 000000A82C7C: 7E1C5511
	v_fma_f32 v27, -v17, v14, 1.0                              // 000000A82C80: D613001B 23CA1D11
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A82C88: BF870091
	v_dual_mul_f32 v51, 0xbfb8aa3b, v4 :: v_dual_fmac_f32 v14, v27, v14// 000000A82C8C: C8C008FF 330E1D1B BFB8AA3B
	v_exp_f32_e32 v49, v51                                     // 000000A82C98: 7E624B33
	v_mul_f32_e32 v27, 0xbfb8aa3b, v9                          // 000000A82C9C: 103612FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A82CA4: BF870095
	v_add_f32_e32 v47, 1.0, v49                                // 000000A82CA8: 065E62F2
	v_div_scale_f32 v23, null, v47, v47, v4                    // 000000A82CAC: D6FC7C17 04125F2F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000A82CB4: BF870291
	v_rcp_f32_e32 v15, v23                                     // 000000A82CB8: 7E1E5517
	v_fma_f32 v8, -v23, v15, 1.0                               // 000000A82CBC: D6130008 23CA1F17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A82CC4: BF8700A1
	v_fmac_f32_e32 v15, v8, v15                                // 000000A82CC8: 561E1F08
	v_div_scale_f32 v8, vcc_lo, v4, v47, v4                    // 000000A82CCC: D6FC6A08 04125F04
	v_mul_f32_e32 v13, v8, v15                                 // 000000A82CD4: 101A1F08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A82CD8: BF870091
	v_fma_f32 v24, -v23, v13, v8                               // 000000A82CDC: D6130018 24221B17
	v_fmac_f32_e32 v13, v24, v15                               // 000000A82CE4: 561A1F18
	v_exp_f32_e32 v24, v28                                     // 000000A82CE8: 7E304B1C
	v_div_scale_f32 v28, s5, v5, v7, v5                        // 000000A82CEC: D6FC051C 04160F05
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000A82CF4: BF870122
	v_fma_f32 v8, -v23, v13, v8                                // 000000A82CF8: D6130008 24221B17
	v_exp_f32_e32 v23, v27                                     // 000000A82D00: 7E2E4B1B
	v_mul_f32_e32 v27, v28, v14                                // 000000A82D04: 10361D1C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000A82D08: BF870312
	v_div_fmas_f32 v8, v8, v15, v13                            // 000000A82D0C: D6370008 04361F08
	v_add_f32_e32 v24, 1.0, v24                                // 000000A82D14: 063030F2
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A82D18: BF8701A3
	v_fma_f32 v15, -v17, v27, v28                              // 000000A82D1C: D613000F 24723711
	s_mov_b32 vcc_lo, s5                                       // 000000A82D24: BEEA0005
	v_div_fixup_f32 v4, v8, v47, v4                            // 000000A82D28: D6270004 04125F08
	s_delay_alu instid0(TRANS32_DEP_1)                         // 000000A82D30: BF870005
	v_add_f32_e32 v23, 1.0, v23                                // 000000A82D34: 062E2EF2
	v_div_scale_f32 v13, null, v24, v24, v10                   // 000000A82D38: D6FC7C0D 042A3118
	v_fmac_f32_e32 v27, v15, v14                               // 000000A82D40: 56361D0F
	v_div_scale_f32 v8, s6, v2, v20, v2                        // 000000A82D44: D6FC0608 040A2902
	v_mul_f32_e32 v4, v16, v4                                  // 000000A82D4C: 10080910
	v_div_scale_f32 v29, null, v23, v23, v9                    // 000000A82D50: D6FC7C1D 04262F17
	v_rcp_f32_e32 v45, v13                                     // 000000A82D58: 7E5A550D
	v_fma_f32 v17, -v17, v27, v28                              // 000000A82D5C: D6130011 24723711
	v_mul_f32_e32 v28, v8, v31                                 // 000000A82D64: 10383F08
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A82D68: BF870113
	v_rcp_f32_e32 v15, v29                                     // 000000A82D6C: 7E1E551D
	v_div_fmas_f32 v14, v17, v14, v27                          // 000000A82D70: D637000E 046E1D11
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(TRANS32_DEP_2)// 000000A82D78: BF870332
	v_fma_f32 v17, -v30, v28, v8                               // 000000A82D7C: D6130011 2422391E
	v_mul_f32_e32 v27, v44, v36                                // 000000A82D84: 1036492C
	s_mov_b32 vcc_lo, s6                                       // 000000A82D88: BEEA0006
	v_fma_f32 v16, -v13, v45, 1.0                              // 000000A82D8C: D6130010 23CA5B0D
	v_div_fixup_f32 v5, v14, v7, v5                            // 000000A82D94: D6270005 04160F0E
	v_fmac_f32_e32 v28, v17, v31                               // 000000A82D9C: 56383F11
	v_fma_f32 v7, -v35, v27, v44                               // 000000A82DA0: D6130007 24B23723
	s_delay_alu instid0(TRANS32_DEP_1)                         // 000000A82DA8: BF870005
	v_fma_f32 v46, -v29, v15, 1.0                              // 000000A82DAC: D613002E 23CA1F1D
	v_fmac_f32_e32 v45, v16, v45                               // 000000A82DB4: 565A5B10
	v_div_scale_f32 v16, s8, v10, v24, v10                     // 000000A82DB8: D6FC0810 042A310A
	v_fma_f32 v8, -v30, v28, v8                                // 000000A82DC0: D6130008 2422391E
	v_fmac_f32_e32 v27, v7, v36                                // 000000A82DC8: 56364907
	v_fmac_f32_e32 v15, v46, v15                               // 000000A82DCC: 561E1F2E
	v_div_scale_f32 v46, s5, v9, v23, v9                       // 000000A82DD0: D6FC052E 04262F09
	v_mul_f32_e32 v47, v16, v45                                // 000000A82DD8: 105E5B10
	v_div_fmas_f32 v8, v8, v31, v28                            // 000000A82DDC: D6370008 04723F08
	s_mov_b32 vcc_lo, s7                                       // 000000A82DE4: BEEA0007
	v_mul_f32_e32 v5, v18, v5                                  // 000000A82DE8: 100A0B12
	v_mul_f32_e32 v17, v46, v15                                // 000000A82DEC: 10221F2E
	v_fma_f32 v14, -v13, v47, v16                              // 000000A82DF0: D613000E 24425F0D
	v_div_fixup_f32 v2, v8, v20, v2                            // 000000A82DF8: D6270002 040A2908
	v_fma_mix_f32 v8, v33, v12, neg(0) op_sel_hi:[1,0,0]       // 000000A82E00: CC200008 8A021921
	v_fma_mix_f32 v5, v39, v5, neg(0) op_sel_hi:[1,0,0]        // 000000A82E08: CC200005 8A020B27
	v_fma_f32 v7, -v29, v17, v46                               // 000000A82E10: D6130007 24BA231D
	v_fmac_f32_e32 v47, v14, v45                               // 000000A82E18: 565E5B0E
	v_fma_f32 v14, -v35, v27, v44                              // 000000A82E1C: D613000E 24B23723
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A82E24: BF870193
	v_fmac_f32_e32 v17, v7, v15                                // 000000A82E28: 56221F07
	v_fma_f32 v7, -v13, v47, v16                               // 000000A82E2C: D6130007 24425F0D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A82E34: BF8701A3
	v_div_fmas_f32 v13, v14, v36, v27                          // 000000A82E38: D637000D 046E490E
	s_mov_b32 vcc_lo, s8                                       // 000000A82E40: BEEA0008
	v_fma_f32 v14, -v29, v17, v46                              // 000000A82E44: D613000E 24BA231D
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A82E4C: BF870003
	v_div_fmas_f32 v7, v7, v45, v47                            // 000000A82E50: D6370007 04BE5B07
	s_mov_b32 vcc_lo, s5                                       // 000000A82E58: BEEA0005
	v_div_fixup_f32 v6, v13, v22, v6                           // 000000A82E5C: D6270006 041A2D0D
	v_fma_mix_f32 v13, v25, v19, neg(0) op_sel_hi:[1,0,0]      // 000000A82E64: CC20000D 8A022719
	v_div_fmas_f32 v14, v14, v15, v17                          // 000000A82E6C: D637000E 04461F0E
	v_fma_mix_f32 v15, v26, v21, neg(0) op_sel_hi:[1,0,0]      // 000000A82E74: CC20000F 8A022B1A
	v_div_fixup_f32 v7, v7, v24, v10                           // 000000A82E7C: D6270007 042A3107
	v_fma_mix_f32 v10, v4, v38, v5 op_sel_hi:[0,1,0]           // 000000A82E84: CC20000A 14164D04
	v_mul_f32_e32 v6, v13, v6                                  // 000000A82E8C: 100C0D0D
	v_div_fixup_f32 v9, v14, v23, v9                           // 000000A82E90: D6270009 04262F0E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A82E98: BF870194
	v_dual_mul_f32 v2, v15, v2 :: v_dual_mul_f32 v7, v8, v7    // 000000A82E9C: C8C6050F 02060F08
	v_fma_mix_f32 v6, v41, v6, neg(0) op_sel_hi:[1,0,0]        // 000000A82EA4: CC200006 8A020D29
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A82EAC: BF870113
	v_mul_f32_e32 v9, v11, v9                                  // 000000A82EB0: 1012130B
	v_fma_mix_f32 v11, v2, v40, v6 op_sel_hi:[0,1,0]           // 000000A82EB4: CC20000B 141A5102
	s_delay_alu instid0(VALU_DEP_2)                            // 000000A82EBC: BF870002
	v_fma_mix_f32 v8, v43, v9, neg(0) op_sel_hi:[1,0,0]        // 000000A82EC0: CC200008 8A02132B
	v_fma_mix_f32 v9, v0, v37, v3 op_sel_hi:[0,1,0]            // 000000A82EC8: CC200009 140E4B00
	v_fma_mix_f32 v0, v0, v37, -v3 op_sel_hi:[0,1,0]           // 000000A82ED0: CC200000 940E4B00
	v_fma_mix_f32 v3, v4, v38, -v5 op_sel_hi:[0,1,0]           // 000000A82ED8: CC200003 94164D04
	v_fma_mix_f32 v2, v2, v40, -v6 op_sel_hi:[0,1,0]           // 000000A82EE0: CC200002 941A5102
	v_fma_mix_f32 v12, v7, v42, v8 op_sel_hi:[0,1,0]           // 000000A82EE8: CC20000C 14225507
	v_add_f32_e32 v4, v9, v10                                  // 000000A82EF0: 06081509
	v_fma_mix_f32 v6, v7, v42, -v8 op_sel_hi:[0,1,0]           // 000000A82EF4: CC200006 94225507
	v_dual_sub_f32 v7, v9, v10 :: v_dual_add_f32 v8, v0, v3    // 000000A82EFC: C9481509 07080700
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A82F04: BF870194
	v_dual_add_f32 v5, v11, v12 :: v_dual_sub_f32 v0, v0, v3   // 000000A82F08: C90A190B 05000700
	v_dual_sub_f32 v9, v11, v12 :: v_dual_add_f32 v10, v2, v6  // 000000A82F10: C948190B 090A0D02
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A82F18: BF8701A2
	v_dual_sub_f32 v2, v2, v6 :: v_dual_add_f32 v3, v4, v5     // 000000A82F1C: C9480D02 02020B04
	v_sub_f32_e32 v4, v4, v5                                   // 000000A82F24: 08080B04
	v_add_f32_e32 v6, v8, v10                                  // 000000A82F28: 060C1508
	v_sub_f32_e32 v8, v8, v10                                  // 000000A82F2C: 08101508
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A82F30: BF870004
	v_mov_b32_dpp v5, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A82F34: 7E0A02FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s2                          // 000000A82F3C: D5010003 200A0703
	v_add_f32_e32 v10, v7, v9                                  // 000000A82F44: 06141307
	v_sub_f32_e32 v7, v7, v9                                   // 000000A82F48: 080E1307
	v_mov_b32_dpp v14, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A82F4C: 7E1C02FA FF016104
	v_cndmask_b32_e64 v15, -v4, v4, s2                         // 000000A82F54: D501000F 200A0904
	v_add_f32_e32 v3, v3, v5                                   // 000000A82F5C: 06060B03
	v_mov_b32_dpp v5, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A82F60: 7E0A02FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s2                          // 000000A82F68: D5010006 200A0D06
	v_mov_b32_dpp v9, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A82F70: 7E1202FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 000000A82F78: D501000A 200A150A
	v_mov_b32_dpp v11, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A82F80: 7E1602FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 000000A82F88: D5010003 200E0703
	v_dual_add_f32 v5, v6, v5 :: v_dual_add_f32 v6, v0, v2     // 000000A82F90: C9080B06 05060500
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A82F98: BF870194
	v_dual_add_f32 v9, v10, v9 :: v_dual_sub_f32 v10, v0, v2   // 000000A82F9C: C90A130A 090A0500
	v_add_f32_e32 v0, v3, v11                                  // 000000A82FA4: 06001703
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A82FA8: BF870223
	v_mov_b32_dpp v2, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A82FAC: 7E0402FA FF016205
	v_cndmask_b32_e64 v3, -v5, v5, s3                          // 000000A82FB4: D5010003 200E0B05
	v_mov_b32_dpp v5, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A82FBC: 7E0A02FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 000000A82FC4: D5010009 200E1309
	v_mov_b32_dpp v11, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A82FCC: 7E1602FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s2                          // 000000A82FD4: D5010006 200A0D06
	v_add_f32_e32 v2, v3, v2                                   // 000000A82FDC: 06040503
	v_mov_b32_dpp v16, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A82FE0: 7E2002FA FF01610A
	v_add_f32_e32 v5, v9, v5                                   // 000000A82FE8: 060A0B09
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 000000A82FEC: D501000A 200A150A
	v_add_f32_e32 v6, v6, v11                                  // 000000A82FF4: 060C1706
	v_mov_b32_dpp v9, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A82FF8: 7E1202FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s4                          // 000000A83000: D5010002 20120502
	v_mov_b32_dpp v11, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A83008: 7E1602FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s4                          // 000000A83010: D5010005 20120B05
	v_mov_b32_dpp v12, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A83018: 7E1802FA FF016206
	v_cndmask_b32_e64 v13, -v6, v6, s3                         // 000000A83020: D501000D 200E0D06
	v_add_f32_e32 v4, v2, v9                                   // 000000A83028: 06081302
	v_add_f32_e32 v10, v10, v16                                // 000000A8302C: 0614210A
	v_dual_add_f32 v6, v5, v11 :: v_dual_add_f32 v11, v15, v14 // 000000A83030: C9081705 060A1D0F
	v_mov_b32_dpp v14, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A83038: 7E1C02FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 000000A83040: D5010008 200A1108
	v_mov_b32_dpp v15, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A83048: 7E1E02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s2                          // 000000A83050: D5010007 200A0F07
	v_add_f32_e32 v9, v13, v12                                 // 000000A83058: 0612190D
	v_mov_b32_dpp v13, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A8305C: 7E1A02FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s3                       // 000000A83064: D501000B 200E170B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A8306C: BF870234
	v_dual_add_f32 v8, v8, v14 :: v_dual_add_f32 v7, v7, v15   // 000000A83070: C9081D08 08061F07
	v_mov_b32_dpp v15, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A83078: 7E1E02FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, s3                       // 000000A83080: D501000A 200E150A
	v_add_f32_e32 v11, v11, v13                                // 000000A83088: 06161B0B
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A8308C: BF870004
	v_mov_b32_dpp v13, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A83090: 7E1A02FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s3                          // 000000A83098: D5010008 200E1108
	v_mov_b32_dpp v14, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A830A0: 7E1C02FA FF016207
	v_cndmask_b32_e64 v7, -v7, v7, s3                          // 000000A830A8: D5010007 200E0F07
	v_add_f32_e32 v10, v10, v15                                // 000000A830B0: 06141F0A
	v_mov_b32_dpp v3, v0 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A830B4: 7E0602FA FF016400
	v_add_f32_e32 v8, v8, v13                                  // 000000A830BC: 06101B08
	v_cndmask_b32_e64 v0, -v0, v0, s4                          // 000000A830C0: D5010000 20120100
	v_add_f32_e32 v7, v7, v14                                  // 000000A830C8: 060E1D07
	v_mov_b32_dpp v12, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A830CC: 7E1802FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s4                          // 000000A830D4: D5010009 20121309
	v_mov_b32_dpp v13, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A830DC: 7E1A02FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s4                       // 000000A830E4: D501000B 2012170B
	v_mov_b32_dpp v14, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A830EC: 7E1C02FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, s4                          // 000000A830F4: D5010008 20121108
	v_mov_b32_dpp v15, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A830FC: 7E1E02FA FF016407
	v_cndmask_b32_e64 v7, -v7, v7, s4                          // 000000A83104: D5010007 20120F07
	v_mov_b32_dpp v16, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A8310C: 7E2002FA FF01640A
	v_cndmask_b32_e64 v17, -v10, v10, s4                       // 000000A83114: D5010011 2012150A
	v_dual_add_f32 v0, v0, v3 :: v_dual_add_f32 v9, v9, v12    // 000000A8311C: C9080700 00081909
	v_dual_add_f32 v10, v11, v13 :: v_dual_add_f32 v11, v8, v14// 000000A83124: C9081B0B 0A0A1D08
	v_add_f32_e32 v13, v7, v15                                 // 000000A8312C: 061A1F07
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A83130: BF870214
	v_add_f32_e32 v15, v17, v16                                // 000000A83134: 061E2111
	v_mov_b32_dpp v2, v0 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A83138: 7E0402FA FF016800
	v_mov_b32_dpp v3, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A83140: 7E0602FA FF016804
	v_mov_b32_dpp v5, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A83148: 7E0A02FA FF016806
	v_mov_b32_dpp v7, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A83150: 7E0E02FA FF016809
	v_mov_b32_dpp v8, v10 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A83158: 7E1002FA FF01680A
	v_mov_b32_dpp v12, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A83160: 7E1802FA FF01680B
	v_mov_b32_dpp v14, v13 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A83168: 7E1C02FA FF01680D
	v_mov_b32_dpp v16, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A83170: 7E2002FA FF01680F
	s_mov_b32 s2, 0x3db504f3                                   // 000000A83178: BE8200FF 3DB504F3
	s_and_b32 exec_lo, exec_lo, s0                             // 000000A83180: 8B7E007E
	s_cbranch_execz 65                                         // 000000A83184: BFA50041 <_ZN7halogen12_GLOBAL__N_112k_ht_gemv_guILi4ELi8ELi1EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_S5_PDF16_+0x378c>
	v_cndmask_b32_e64 v15, -v15, v15, s1                       // 000000A83188: D501000F 20061F0F
	v_cndmask_b32_e64 v0, -v0, v0, s1                          // 000000A83190: D5010000 20060100
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000A83198: D5010004 20060904
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 000000A831A0: D5010006 20060D06
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 000000A831A8: D5010009 20061309
	v_cndmask_b32_e64 v13, -v13, v13, s1                       // 000000A831B0: D501000D 20061B0D
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 000000A831B8: D501000A 2006150A
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 000000A831C0: D501000B 2006170B
	v_dual_add_f32 v15, v15, v16 :: v_dual_add_f32 v0, v0, v2  // 000000A831C8: C908210F 0F000500
	v_add_f32_e32 v3, v4, v3                                   // 000000A831D0: 06060704
	v_add_f32_e32 v5, v6, v5                                   // 000000A831D4: 060A0B06
	v_add_f32_e32 v7, v9, v7                                   // 000000A831D8: 060E0F09
	s_mul_i32 s0, s26, 0x500                                   // 000000A831DC: 9600FF1A 00000500
	v_dual_add_f32 v13, v13, v14 :: v_dual_add_f32 v8, v10, v8 // 000000A831E4: C9081D0D 0D08110A
	s_mul_hi_i32 s1, s26, 0x500                                // 000000A831EC: 9701FF1A 00000500
	v_add_f32_e32 v11, v11, v12                                // 000000A831F4: 0616190B
	s_add_u32 s0, s12, s0                                      // 000000A831F8: 8000000C
	v_fma_mixlo_f16 v0, v0, s2, 0                              // 000000A831FC: CC210000 02000500
	s_addc_u32 s1, s13, s1                                     // 000000A83204: 8201010D
	v_fma_mixhi_f16 v0, v3, s2, 0                              // 000000A83208: CC220000 02000503
	s_add_u32 s0, s0, s14                                      // 000000A83210: 80000E00
	v_fma_mixlo_f16 v2, v5, s2, 0                              // 000000A83214: CC210002 02000505
	s_addc_u32 s1, s1, s15                                     // 000000A8321C: 82010F01
	v_fma_mixhi_f16 v2, v7, s2, 0                              // 000000A83220: CC220002 02000507
	v_fma_mixlo_f16 v3, v8, s2, 0                              // 000000A83228: CC210003 02000508
	v_fma_mixhi_f16 v3, v11, s2, 0                             // 000000A83230: CC220003 0200050B
	v_fma_mixlo_f16 v4, v13, s2, 0                             // 000000A83238: CC210004 0200050D
	v_fma_mixhi_f16 v4, v15, s2, 0                             // 000000A83240: CC220004 0200050F
	s_clause 0x7                                               // 000000A83248: BF850007
	global_store_b16 v1, v0, s[0:1]                            // 000000A8324C: DC660000 00000001
	global_store_d16_hi_b16 v1, v0, s[0:1] offset:32           // 000000A83254: DC960020 00000001
	global_store_b16 v1, v2, s[0:1] offset:64                  // 000000A8325C: DC660040 00000201
	global_store_d16_hi_b16 v1, v2, s[0:1] offset:96           // 000000A83264: DC960060 00000201
	global_store_b16 v1, v3, s[0:1] offset:128                 // 000000A8326C: DC660080 00000301
	global_store_d16_hi_b16 v1, v3, s[0:1] offset:160          // 000000A83274: DC9600A0 00000301
	global_store_b16 v1, v4, s[0:1] offset:192                 // 000000A8327C: DC6600C0 00000401
	global_store_d16_hi_b16 v1, v4, s[0:1] offset:224          // 000000A83284: DC9600E0 00000401
	s_endpgm                                                   // 000000A8328C: BFB00000
		...

