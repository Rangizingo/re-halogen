00000000008c1500 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[8:23], s[0:1], null                          // 0000008C1500: F4100200 F8000000
	s_ashr_i32 s3, s2, 31                                      // 0000008C1508: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 0000008C150C: 32040082
	v_lshrrev_b32_e32 v22, 5, v0                               // 0000008C1510: 322C0085
	v_and_b32_e32 v23, 31, v0                                  // 0000008C1514: 362E009F
	.long 0x7f0a3880                                           // 0000008C1518: 7F0A3880
	v_lshlrev_b32_e32 v21, 2, v0                               // 0000008C151C: 302A0082
	s_waitcnt lgkmcnt(0)                                       // 0000008C1520: BF89FC07
	.long 0xd4510004                                           // 0000008C1524: D4510004
	v_cndmask_b32_e32 v0, s2, v16, vcc_lo                      // 0000008C1528: 02002002
	s_and_b32 s4, s4, exec_lo                                  // 0000008C152C: 8B047E04
	s_cselect_b32 s6, s3, 0                                    // 0000008C1530: 98068003
	s_cselect_b32 s7, s2, 0                                    // 0000008C1534: 98078002
	s_add_u32 s4, s8, s20                                      // 0000008C1538: 80041408
	s_addc_u32 s5, s9, s21                                     // 0000008C153C: 82051509
	v_and_b32_e32 v1, 15, v0                                   // 0000008C1540: 3602008F
	v_and_b32_e32 v2, 60, v2                                   // 0000008C1544: 360404BC
	s_ashr_i32 s20, s15, 31                                    // 0000008C1548: 86149F0F
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008C154C: BF870119
	s_lshr_b32 s20, s20, 27                                    // 0000008C1550: 85149B14
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000008C1554: 30020282
	s_add_u32 s20, s14, s20                                    // 0000008C1558: 8014140E
	s_clause 0x1                                               // 0000008C155C: BF850001
	global_load_b32 v3, v1, s[8:9]                             // 0000008C1560: DC520000 03080001
	global_load_b32 v4, v2, s[8:9]                             // 0000008C1568: DC520000 04080002
	s_addc_u32 s21, s15, 0                                     // 0000008C1570: 8215800F
	v_mov_b32_e32 v1, s4                                       // 0000008C1574: 7E020204
	s_lshr_b64 s[20:21], s[20:21], 5                           // 0000008C1578: 85948514
	v_mov_b32_e32 v2, s5                                       // 0000008C157C: 7E040205
	s_add_i32 s21, s20, 7                                      // 0000008C1580: 81158714
	s_mul_i32 s5, s23, s7                                      // 0000008C1584: 96050717
	s_ashr_i32 s24, s21, 31                                    // 0000008C1588: 86189F15
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000008C158C: BF8704B9
	s_lshr_b32 s4, s24, 29                                     // 0000008C1590: 85049D18
	v_mad_u64_u32 v[17:18], null, s22, s7, v[1:2]              // 0000008C1594: D6FE7C11 04040E16
	s_add_i32 s21, s21, s4                                     // 0000008C159C: 81150415
	s_ashr_i32 s4, s21, 3                                      // 0000008C15A0: 86048315
	s_cmpk_lt_i32 s20, 0x801                                   // 0000008C15A4: B3940801
	.long 0xd72c0001                                           // 0000008C15A8: D72C0001
	v_cndmask_b32_e32 v1, s4, v22, vcc_lo                      // 0000008C15AC: 02022C04
	s_mul_i32 s21, s22, s6                                     // 0000008C15B0: 96150616
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000008C15B4: BF870141
	v_add_nc_u32_e32 v7, s4, v1                                // 0000008C15B8: 4A0E0204
	v_add_nc_u32_e32 v24, v1, v23                              // 0000008C15BC: 4A302F01
	s_cselect_b32 s4, -1, 0                                    // 0000008C15C0: 980480C1
	s_cmpk_gt_i32 s20, 0x800                                   // 0000008C15C4: B2940800
	v_min_i32_e32 v25, s20, v7                                 // 0000008C15C8: 22320E14
	s_cselect_b32 s20, -1, 0                                   // 0000008C15CC: 981480C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000008C15D0: BF870159
	s_and_b32 vcc_lo, exec_lo, s20                             // 0000008C15D4: 8B6A147E
	s_waitcnt vmcnt(1)                                         // 0000008C15D8: BF8907F7
	v_bfe_u32 v2, v3, 16, 1                                    // 0000008C15DC: D6100002 02052103
	s_waitcnt vmcnt(0)                                         // 0000008C15E4: BF8903F7
	v_bfe_u32 v6, v4, 16, 1                                    // 0000008C15E8: D6100006 02052104
	v_add3_u32 v2, v3, v2, 0x7fff                              // 0000008C15F0: D6550002 03FE0503 00007FFF
	v_add_nc_u32_e32 v3, s5, v18                               // 0000008C15FC: 4A062405
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000008C1600: BF870223
	v_add3_u32 v4, v4, v6, 0x7fff                              // 0000008C1604: D6550004 03FE0D04 00007FFF
	.long 0xd4410005                                           // 0000008C1610: D4410005
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 0000008C1614: 02023318
	.long 0x7e0a3982                                           // 0000008C1618: 7E0A3982
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008C161C: BF870114
	v_add_nc_u32_e32 v26, s21, v3                              // 0000008C1620: 4A340615
	v_and_or_b32 v1, 0xffff0000, v4, v5                        // 0000008C1624: D6570001 041608FF FFFF0000
	ds_store_b32 v21, v1                                       // 0000008C1630: D8340000 00000115
	s_waitcnt lgkmcnt(0)                                       // 0000008C1638: BF89FC07
	s_barrier                                                  // 0000008C163C: BFBD0000
	buffer_gl0_inv                                             // 0000008C1640: E0AC0000 00000000
	s_cbranch_vccnz 154                                        // 0000008C1648: BFA4009A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x3b4>
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v1, 0               // 0000008C164C: CA100080 02000080
	s_and_saveexec_b32 s21, s5                                 // 0000008C1654: BE952005
	s_cbranch_execz 11                                         // 0000008C1658: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x188>
	v_lshlrev_b32_e32 v1, 1, v24                               // 0000008C165C: 30023081
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C1660: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v1                               // 0000008C1664: 3408029F
	.long 0xd7006a03                                           // 0000008C1668: D7006A03
	v_cndmask_b32_e32 v1, v17, v1, vcc_lo                      // 0000008C166C: 02020311
	v_add_co_ci_u32_e64 v4, null, v26, v4, vcc_lo              // 0000008C1670: D5207C04 01AA091A
	global_load_d16_b16 v1, v[3:4], off                        // 0000008C1678: DC820000 017C0003
	s_waitcnt vmcnt(0)                                         // 0000008C1680: BF8903F7
	v_cvt_f32_f16_e32 v1, v1                                   // 0000008C1684: 7E021701
	s_or_b32 exec_lo, exec_lo, s21                             // 0000008C1688: 8C7E157E
	v_add_nc_u32_e32 v3, 32, v24                               // 0000008C168C: 4A0630A0
	s_mov_b32 s5, exec_lo                                      // 0000008C1690: BE85007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008C1694: BF870001
	.long 0xd4c1007e                                           // 0000008C1698: D4C1007E
	v_cndmask_b32_e32 v1, v3, v25, vcc_lo                      // 0000008C169C: 02023303
	s_cbranch_execz 11                                         // 0000008C16A0: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x1d0>
	v_lshlrev_b32_e32 v2, 1, v3                                // 0000008C16A4: 30040681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C16A8: BF8700A1
	v_ashrrev_i32_e32 v3, 31, v2                               // 0000008C16AC: 3406049F
	.long 0xd7006a02                                           // 0000008C16B0: D7006A02
	v_cndmask_b32_e32 v1, v17, v2, vcc_lo                      // 0000008C16B4: 02020511
	v_add_co_ci_u32_e64 v3, null, v26, v3, vcc_lo              // 0000008C16B8: D5207C03 01AA071A
	global_load_d16_b16 v2, v[2:3], off                        // 0000008C16C0: DC820000 027C0002
	s_waitcnt vmcnt(0)                                         // 0000008C16C8: BF8903F7
	v_cvt_f32_f16_e32 v2, v2                                   // 0000008C16CC: 7E041702
	s_or_b32 exec_lo, exec_lo, s5                              // 0000008C16D0: 8C7E057E
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v5, 64, v24      // 0000008C16D4: CA200080 040430C0
	v_mov_b32_e32 v3, 0                                        // 0000008C16DC: 7E060280
	s_mov_b32 s5, exec_lo                                      // 0000008C16E0: BE85007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008C16E4: BF870002
	.long 0xd4c1007e                                           // 0000008C16E8: D4C1007E
	v_cndmask_b32_e32 v1, v5, v25, vcc_lo                      // 0000008C16EC: 02023305
	s_cbranch_execz 11                                         // 0000008C16F0: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x220>
	v_lshlrev_b32_e32 v3, 1, v5                                // 0000008C16F4: 30060A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C16F8: BF8700A1
	v_ashrrev_i32_e32 v6, 31, v3                               // 0000008C16FC: 340C069F
	.long 0xd7006a05                                           // 0000008C1700: D7006A05
	v_cndmask_b32_e32 v1, v17, v3, vcc_lo                      // 0000008C1704: 02020711
	v_add_co_ci_u32_e64 v6, null, v26, v6, vcc_lo              // 0000008C1708: D5207C06 01AA0D1A
	global_load_d16_b16 v3, v[5:6], off                        // 0000008C1710: DC820000 037C0005
	s_waitcnt vmcnt(0)                                         // 0000008C1718: BF8903F7
	v_cvt_f32_f16_e32 v3, v3                                   // 0000008C171C: 7E061703
	s_or_b32 exec_lo, exec_lo, s5                              // 0000008C1720: 8C7E057E
	v_add_nc_u32_e32 v5, 0x60, v24                             // 0000008C1724: 4A0A30FF 00000060
	s_mov_b32 s5, exec_lo                                      // 0000008C172C: BE85007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008C1730: BF870001
	.long 0xd4c1007e                                           // 0000008C1734: D4C1007E
	v_cndmask_b32_e32 v1, v5, v25, vcc_lo                      // 0000008C1738: 02023305
	s_cbranch_execz 11                                         // 0000008C173C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x26c>
	v_lshlrev_b32_e32 v4, 1, v5                                // 0000008C1740: 30080A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C1744: BF8700A1
	v_ashrrev_i32_e32 v5, 31, v4                               // 0000008C1748: 340A089F
	.long 0xd7006a04                                           // 0000008C174C: D7006A04
	v_cndmask_b32_e32 v1, v17, v4, vcc_lo                      // 0000008C1750: 02020911
	v_add_co_ci_u32_e64 v5, null, v26, v5, vcc_lo              // 0000008C1754: D5207C05 01AA0B1A
	global_load_d16_b16 v4, v[4:5], off                        // 0000008C175C: DC820000 047C0004
	s_waitcnt vmcnt(0)                                         // 0000008C1764: BF8903F7
	v_cvt_f32_f16_e32 v4, v4                                   // 0000008C1768: 7E081704
	s_or_b32 exec_lo, exec_lo, s5                              // 0000008C176C: 8C7E057E
	v_dual_mov_b32 v6, 0 :: v_dual_add_nc_u32 v7, 0x80, v24    // 0000008C1770: CA200080 060630FF 00000080
	v_mov_b32_e32 v5, 0                                        // 0000008C177C: 7E0A0280
	s_mov_b32 s5, exec_lo                                      // 0000008C1780: BE85007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008C1784: BF870002
	.long 0xd4c1007e                                           // 0000008C1788: D4C1007E
	v_cndmask_b32_e32 v1, v7, v25, vcc_lo                      // 0000008C178C: 02023307
	s_cbranch_execz 11                                         // 0000008C1790: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x2c0>
	v_lshlrev_b32_e32 v5, 1, v7                                // 0000008C1794: 300A0E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C1798: BF8700A1
	v_ashrrev_i32_e32 v8, 31, v5                               // 0000008C179C: 34100A9F
	.long 0xd7006a07                                           // 0000008C17A0: D7006A07
	v_cndmask_b32_e32 v1, v17, v5, vcc_lo                      // 0000008C17A4: 02020B11
	v_add_co_ci_u32_e64 v8, null, v26, v8, vcc_lo              // 0000008C17A8: D5207C08 01AA111A
	global_load_d16_b16 v5, v[7:8], off                        // 0000008C17B0: DC820000 057C0007
	s_waitcnt vmcnt(0)                                         // 0000008C17B8: BF8903F7
	v_cvt_f32_f16_e32 v5, v5                                   // 0000008C17BC: 7E0A1705
	s_or_b32 exec_lo, exec_lo, s5                              // 0000008C17C0: 8C7E057E
	v_add_nc_u32_e32 v7, 0xa0, v24                             // 0000008C17C4: 4A0E30FF 000000A0
	s_mov_b32 s5, exec_lo                                      // 0000008C17CC: BE85007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008C17D0: BF870001
	.long 0xd4c1007e                                           // 0000008C17D4: D4C1007E
	v_cndmask_b32_e32 v1, v7, v25, vcc_lo                      // 0000008C17D8: 02023307
	s_cbranch_execz 11                                         // 0000008C17DC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x30c>
	v_lshlrev_b32_e32 v6, 1, v7                                // 0000008C17E0: 300C0E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C17E4: BF8700A1
	v_ashrrev_i32_e32 v7, 31, v6                               // 0000008C17E8: 340E0C9F
	.long 0xd7006a06                                           // 0000008C17EC: D7006A06
	v_cndmask_b32_e32 v1, v17, v6, vcc_lo                      // 0000008C17F0: 02020D11
	v_add_co_ci_u32_e64 v7, null, v26, v7, vcc_lo              // 0000008C17F4: D5207C07 01AA0F1A
	global_load_d16_b16 v6, v[6:7], off                        // 0000008C17FC: DC820000 067C0006
	s_waitcnt vmcnt(0)                                         // 0000008C1804: BF8903F7
	v_cvt_f32_f16_e32 v6, v6                                   // 0000008C1808: 7E0C1706
	s_or_b32 exec_lo, exec_lo, s5                              // 0000008C180C: 8C7E057E
	v_dual_mov_b32 v8, 0 :: v_dual_add_nc_u32 v9, 0xc0, v24    // 0000008C1810: CA200080 080830FF 000000C0
	v_mov_b32_e32 v7, 0                                        // 0000008C181C: 7E0E0280
	s_mov_b32 s5, exec_lo                                      // 0000008C1820: BE85007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008C1824: BF870002
	.long 0xd4c1007e                                           // 0000008C1828: D4C1007E
	v_cndmask_b32_e32 v1, v9, v25, vcc_lo                      // 0000008C182C: 02023309
	s_cbranch_execz 11                                         // 0000008C1830: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x360>
	v_lshlrev_b32_e32 v7, 1, v9                                // 0000008C1834: 300E1281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C1838: BF8700A1
	v_ashrrev_i32_e32 v10, 31, v7                              // 0000008C183C: 34140E9F
	.long 0xd7006a09                                           // 0000008C1840: D7006A09
	v_cndmask_b32_e32 v1, v17, v7, vcc_lo                      // 0000008C1844: 02020F11
	v_add_co_ci_u32_e64 v10, null, v26, v10, vcc_lo            // 0000008C1848: D5207C0A 01AA151A
	global_load_d16_b16 v7, v[9:10], off                       // 0000008C1850: DC820000 077C0009
	s_waitcnt vmcnt(0)                                         // 0000008C1858: BF8903F7
	v_cvt_f32_f16_e32 v7, v7                                   // 0000008C185C: 7E0E1707
	s_or_b32 exec_lo, exec_lo, s5                              // 0000008C1860: 8C7E057E
	v_add_nc_u32_e32 v9, 0xe0, v24                             // 0000008C1864: 4A1230FF 000000E0
	s_mov_b32 s5, exec_lo                                      // 0000008C186C: BE85007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008C1870: BF870001
	.long 0xd4c1007e                                           // 0000008C1874: D4C1007E
	v_cndmask_b32_e32 v1, v9, v25, vcc_lo                      // 0000008C1878: 02023309
	s_cbranch_execz 11                                         // 0000008C187C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x3ac>
	v_lshlrev_b32_e32 v8, 1, v9                                // 0000008C1880: 30101281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C1884: BF8700A1
	v_ashrrev_i32_e32 v9, 31, v8                               // 0000008C1888: 3412109F
	.long 0xd7006a08                                           // 0000008C188C: D7006A08
	v_cndmask_b32_e32 v1, v17, v8, vcc_lo                      // 0000008C1890: 02021111
	v_add_co_ci_u32_e64 v9, null, v26, v9, vcc_lo              // 0000008C1894: D5207C09 01AA131A
	global_load_d16_b16 v8, v[8:9], off                        // 0000008C189C: DC820000 087C0008
	s_waitcnt vmcnt(0)                                         // 0000008C18A4: BF8903F7
	v_cvt_f32_f16_e32 v8, v8                                   // 0000008C18A8: 7E101708
	s_or_b32 exec_lo, exec_lo, s5                              // 0000008C18AC: 8C7E057E
	s_branch 9                                                 // 0000008C18B0: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x3d8>
	v_mov_b32_e32 v1, 0                                        // 0000008C18B4: 7E020280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008C18B8: BF870001
	v_mov_b32_e32 v2, v1                                       // 0000008C18BC: 7E040301
	v_mov_b32_e32 v3, v1                                       // 0000008C18C0: 7E060301
	v_mov_b32_e32 v4, v1                                       // 0000008C18C4: 7E080301
	v_mov_b32_e32 v5, v1                                       // 0000008C18C8: 7E0A0301
	v_mov_b32_e32 v6, v1                                       // 0000008C18CC: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 0000008C18D0: 7E0E0301
	v_mov_b32_e32 v8, v1                                       // 0000008C18D4: 7E100301
	s_add_u32 s8, s8, s18                                      // 0000008C18D8: 80081208
	s_addc_u32 s9, s9, s19                                     // 0000008C18DC: 82091309
	s_lshr_b32 s5, s15, 31                                     // 0000008C18E0: 85059F0F
	v_dual_mov_b32 v9, s7 :: v_dual_mov_b32 v20, 0             // 0000008C18E4: CA100007 09140080
	s_add_u32 s18, s14, s5                                     // 0000008C18EC: 8012050E
	s_addc_u32 s19, s15, 0                                     // 0000008C18F0: 8213800F
	.long 0xd4410005                                           // 0000008C18F4: D4410005
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 0000008C18F8: 02023318
	s_ashr_i64 s[18:19], s[18:19], 1                           // 0000008C18FC: 86928112
	v_dual_mov_b32 v13, 0 :: v_dual_mov_b32 v14, 0             // 0000008C1900: CA100080 0D0E0080
	v_mad_u64_u32 v[18:19], null, v9, s18, s[8:9]              // 0000008C1908: D6FE7C12 00202509
	.long 0xd72c0009                                           // 0000008C1910: D72C0009
	v_cndmask_b32_e32 v0, s7, v19, vcc_lo                      // 0000008C1914: 02002607
	.long 0xd72c000a                                           // 0000008C1918: D72C000A
	v_cndmask_b32_e32 v0, s6, v18, vcc_lo                      // 0000008C191C: 02002406
	v_dual_mov_b32 v27, 0 :: v_dual_mov_b32 v16, 0             // 0000008C1920: CA100080 1B100080
	v_cndmask_b32_e64 v28, 0, 1, s20                           // 0000008C1928: D501001C 00510280
	v_mov_b32_e32 v15, 0                                       // 0000008C1930: 7E1E0280
	s_delay_alu instid0(VALU_DEP_4)                            // 0000008C1934: BF870004
	v_add3_u32 v29, v10, v19, v9                               // 0000008C1938: D655001D 0426270A
	s_and_saveexec_b32 s6, s5                                  // 0000008C1940: BE862005
	s_cbranch_execz 22                                         // 0000008C1944: BFA50016 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x4a0>
	v_dual_mov_b32 v20, 0 :: v_dual_lshlrev_b32 v9, 4, v24     // 0000008C1948: CA220080 14083084
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C1950: BF8700A1
	v_ashrrev_i32_e32 v10, 31, v9                              // 0000008C1954: 3414129F
	.long 0xd7006a09                                           // 0000008C1958: D7006A09
	v_cndmask_b32_e32 v1, v18, v9, vcc_lo                      // 0000008C195C: 02021312
	v_add_co_ci_u32_e64 v10, null, v29, v10, vcc_lo            // 0000008C1960: D5207C0A 01AA151D
	s_and_not1_b32 vcc_lo, exec_lo, s20                        // 0000008C1968: 916A147E
	global_load_b128 v[13:16], v[9:10], off                    // 0000008C196C: DC5E0000 0D7C0009
	s_cbranch_vccnz 10                                         // 0000008C1974: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x4a0>
	v_lshlrev_b32_e32 v9, 1, v24                               // 0000008C1978: 30123081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C197C: BF870091
	.long 0xd7006a09                                           // 0000008C1980: D7006A09
	v_cndmask_b32_e32 v1, v17, v9, vcc_lo                      // 0000008C1984: 02021311
	v_add_co_ci_u32_e64 v10, null, 0, v26, vcc_lo              // 0000008C1988: D5207C0A 01AA3480
	global_load_d16_b16 v9, v[9:10], off                       // 0000008C1990: DC820000 097C0009
	s_waitcnt vmcnt(0)                                         // 0000008C1998: BF8903F7
	v_cvt_f32_f16_e32 v20, v9                                  // 0000008C199C: 7E281709
	s_or_b32 exec_lo, exec_lo, s6                              // 0000008C19A0: 8C7E067E
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v32, 0             // 0000008C19A4: CA100080 1F200080
	v_mov_b32_e32 v30, 0                                       // 0000008C19AC: 7E3C0280
	s_and_saveexec_b32 s18, s5                                 // 0000008C19B0: BE922005
	s_cbranch_execz 429                                        // 0000008C19B4: BFA501AD <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0xb6c>
	v_dual_mov_b32 v30, 0 :: v_dual_add_nc_u32 v9, 32, v24     // 0000008C19B8: CA200080 1E0830A0
	v_dual_mov_b32 v32, 0 :: v_dual_lshlrev_b32 v19, 5, v24    // 0000008C19C0: CA220080 20123085
	v_mov_b32_e32 v27, 0                                       // 0000008C19C8: 7E360280
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008C19CC: BF870003
	v_lshlrev_b32_e32 v33, 4, v9                               // 0000008C19D0: 30421284
	v_dual_mov_b32 v31, 0 :: v_dual_lshlrev_b32 v34, 1, v9     // 0000008C19D4: CA220080 1F221281
	v_mov_b32_e32 v35, v20                                     // 0000008C19DC: 7E460314
	s_mul_i32 s5, s15, 6                                       // 0000008C19E0: 9605860F
	s_mul_hi_u32 s8, s14, 6                                    // 0000008C19E4: 9688860E
	s_lshl_b64 s[6:7], s[14:15], 2                             // 0000008C19E8: 8486820E
	s_add_i32 s19, s8, s5                                      // 0000008C19EC: 81130508
	s_mul_i32 s21, s14, 6                                      // 0000008C19F0: 9615860E
	s_mov_b32 s20, 0                                           // 0000008C19F4: BE940080
	s_lshl_b64 s[8:9], s[14:15], 1                             // 0000008C19F8: 8488810E
	s_branch 375                                               // 0000008C19FC: BFA00177 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0xadc>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000008C1A00: 8C7E0E7E
	v_cndmask_b32_e64 v50, v20, v1, s4                         // 0000008C1A04: D5010032 00120314
	v_cndmask_b32_e64 v36, v1, v2, s4                          // 0000008C1A0C: D5010024 00120501
	v_and_b32_e32 v1, 0xff, v13                                // 0000008C1A14: 36021AFF 000000FF
	v_cndmask_b32_e64 v42, v7, v8, s4                          // 0000008C1A1C: D501002A 00121107
	v_cndmask_b32_e64 v41, v6, v7, s4                          // 0000008C1A24: D5010029 00120F06
	v_cndmask_b32_e64 v40, v5, v6, s4                          // 0000008C1A2C: D5010028 00120D05
	v_cndmask_b32_e64 v39, v4, v5, s4                          // 0000008C1A34: D5010027 00120B04
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000008C1A3C: 30020282
	v_cndmask_b32_e64 v38, v3, v4, s4                          // 0000008C1A40: D5010026 00120903
	v_cndmask_b32_e64 v37, v2, v3, s4                          // 0000008C1A48: D5010025 00120702
	v_mov_b32_e32 v43, v8                                      // 0000008C1A50: 7E560308
	v_ashrrev_i32_e32 v20, 31, v19                             // 0000008C1A54: 3428269F
	ds_load_b32 v51, v1                                        // 0000008C1A58: D8D80000 33000001
	v_lshrrev_b32_e32 v1, 6, v13                               // 0000008C1A60: 32021A86
	v_add_nc_u32_e32 v33, 0x200, v33                           // 0000008C1A64: 4A4242FF 00000200
	s_and_b32 s5, exec_lo, s5                                  // 0000008C1A6C: 8B05057E
	v_add_nc_u32_e32 v34, 64, v34                              // 0000008C1A70: 4A4444C0
	s_or_b32 s20, s5, s20                                      // 0000008C1A74: 8C141405
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000008C1A78: 360202FF 000003FC
	ds_load_b32 v52, v1                                        // 0000008C1A80: D8D80000 34000001
	v_lshrrev_b32_e32 v1, 14, v13                              // 0000008C1A88: 32021A8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008C1A8C: BF8700B1
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000008C1A90: 360202FF 000003FC
	ds_load_b32 v53, v1                                        // 0000008C1A98: D8D80000 35000001
	v_lshrrev_b32_e32 v1, 22, v13                              // 0000008C1AA0: 32021A96
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000008C1AA4: 360202FF 000003FC
	ds_load_b32 v54, v1                                        // 0000008C1AAC: D8D80000 36000001
	v_and_b32_e32 v1, 0xff, v14                                // 0000008C1AB4: 36021CFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008C1ABC: BF8700B1
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000008C1AC0: 30020282
	ds_load_b32 v55, v1                                        // 0000008C1AC4: D8D80000 37000001
	v_lshrrev_b32_e32 v1, 6, v14                               // 0000008C1ACC: 32021C86
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000008C1AD0: 360202FF 000003FC
	ds_load_b32 v56, v1                                        // 0000008C1AD8: D8D80000 38000001
	v_lshrrev_b32_e32 v1, 14, v14                              // 0000008C1AE0: 32021C8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008C1AE4: BF8700B1
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000008C1AE8: 360202FF 000003FC
	ds_load_b32 v57, v1                                        // 0000008C1AF0: D8D80000 39000001
	v_lshrrev_b32_e32 v1, 22, v14                              // 0000008C1AF8: 32021C96
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000008C1AFC: 360202FF 000003FC
	ds_load_b32 v58, v1                                        // 0000008C1B04: D8D80000 3A000001
	v_and_b32_e32 v1, 0xff, v15                                // 0000008C1B0C: 36021EFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008C1B14: BF8700B1
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000008C1B18: 30020282
	ds_load_b32 v59, v1                                        // 0000008C1B1C: D8D80000 3B000001
	v_lshrrev_b32_e32 v1, 6, v15                               // 0000008C1B24: 32021E86
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000008C1B28: 360202FF 000003FC
	ds_load_b32 v60, v1                                        // 0000008C1B30: D8D80000 3C000001
	v_lshrrev_b32_e32 v1, 14, v15                              // 0000008C1B38: 32021E8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008C1B3C: BF8700B1
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000008C1B40: 360202FF 000003FC
	ds_load_b32 v61, v1                                        // 0000008C1B48: D8D80000 3D000001
	v_lshrrev_b32_e32 v1, 22, v15                              // 0000008C1B50: 32021E96
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000008C1B54: 360202FF 000003FC
	ds_load_b32 v62, v1                                        // 0000008C1B5C: D8D80000 3E000001
	v_and_b32_e32 v1, 0xff, v16                                // 0000008C1B64: 360220FF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008C1B6C: BF8700B1
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000008C1B70: 30020282
	ds_load_b32 v63, v1                                        // 0000008C1B74: D8D80000 3F000001
	v_lshrrev_b32_e32 v1, 6, v16                               // 0000008C1B7C: 32022086
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000008C1B80: 360202FF 000003FC
	ds_load_b32 v64, v1                                        // 0000008C1B88: D8D80000 40000001
	v_lshrrev_b32_e32 v1, 14, v16                              // 0000008C1B90: 3202208E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008C1B94: BF8700B1
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000008C1B98: 360202FF 000003FC
	ds_load_b32 v65, v1                                        // 0000008C1BA0: D8D80000 41000001
	v_lshrrev_b32_e32 v1, 22, v16                              // 0000008C1BA8: 32022096
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000008C1BAC: 360202FF 000003FC
	ds_load_b32 v66, v1                                        // 0000008C1BB4: D8D80000 42000001
	.long 0xd73c0001                                           // 0000008C1BBC: D73C0001
	v_cndmask_b32_e32 v1, 1, v19, vcc_lo                       // 0000008C1BC0: 02022681
	v_dual_mov_b32 v20, v35 :: v_dual_add_nc_u32 v19, 0x400, v19// 0000008C1BC4: CA200123 141226FF 00000400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C1BD0: BF870092
	.long 0xd7006a30                                           // 0000008C1BD4: D7006A30
	v_cndmask_b32_e32 v1, s10, v1, vcc_lo                      // 0000008C1BD8: 0202020A
	v_add_co_ci_u32_e64 v49, null, s11, v2, vcc_lo             // 0000008C1BDC: D5207C31 01AA040B
	s_clause 0x3                                               // 0000008C1BE4: BF850003
	global_load_b128 v[1:4], v[48:49], off                     // 0000008C1BE8: DC5E0000 017C0030
	global_load_b128 v[5:8], v[48:49], off offset:16           // 0000008C1BF0: DC5E0010 057C0030
	global_load_b128 v[13:16], v[48:49], off offset:32         // 0000008C1BF8: DC5E0020 0D7C0030
	global_load_b128 v[44:47], v[48:49], off offset:48         // 0000008C1C00: DC5E0030 2C7C0030
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 0000008C1C08: BF890CF7
	v_dot2_f32_bf16 v1, v1, v51, 0                             // 0000008C1C0C: CC1A4001 1A026701
	s_waitcnt lgkmcnt(14)                                      // 0000008C1C14: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C1C18: BF8700A1
	v_dot2_f32_bf16 v1, v2, v52, v1                            // 0000008C1C1C: CC1A4001 1C066902
	s_waitcnt lgkmcnt(13)                                      // 0000008C1C24: BF89FCD7
	v_dot2_f32_bf16 v1, v3, v53, v1                            // 0000008C1C28: CC1A4001 1C066B03
	s_waitcnt lgkmcnt(12)                                      // 0000008C1C30: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C1C34: BF8700A1
	v_dot2_f32_bf16 v1, v4, v54, v1                            // 0000008C1C38: CC1A4001 1C066D04
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 0000008C1C40: BF8908B7
	v_dot2_f32_bf16 v1, v5, v55, v1                            // 0000008C1C44: CC1A4001 1C066F05
	s_waitcnt lgkmcnt(10)                                      // 0000008C1C4C: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C1C50: BF8700A1
	v_dot2_f32_bf16 v1, v6, v56, v1                            // 0000008C1C54: CC1A4001 1C067106
	s_waitcnt lgkmcnt(9)                                       // 0000008C1C5C: BF89FC97
	v_dot2_f32_bf16 v1, v7, v57, v1                            // 0000008C1C60: CC1A4001 1C067307
	s_waitcnt lgkmcnt(8)                                       // 0000008C1C68: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C1C6C: BF8700A1
	v_dot2_f32_bf16 v1, v8, v58, v1                            // 0000008C1C70: CC1A4001 1C067508
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 0000008C1C78: BF890477
	v_dot2_f32_bf16 v1, v13, v59, v1                           // 0000008C1C7C: CC1A4001 1C06770D
	s_waitcnt lgkmcnt(6)                                       // 0000008C1C84: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C1C88: BF8700A1
	v_dot2_f32_bf16 v1, v14, v60, v1                           // 0000008C1C8C: CC1A4001 1C06790E
	s_waitcnt lgkmcnt(5)                                       // 0000008C1C94: BF89FC57
	v_dot2_f32_bf16 v1, v15, v61, v1                           // 0000008C1C98: CC1A4001 1C067B0F
	s_waitcnt lgkmcnt(4)                                       // 0000008C1CA0: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C1CA4: BF8700A1
	v_dot2_f32_bf16 v1, v16, v62, v1                           // 0000008C1CA8: CC1A4001 1C067D10
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 0000008C1CB0: BF890037
	v_dot2_f32_bf16 v1, v44, v63, v1                           // 0000008C1CB4: CC1A4001 1C067F2C
	.long 0xd7006a2c                                           // 0000008C1CBC: D7006A2C
	v_cndmask_b32_e32 v0, v48, v8, vcc_lo                      // 0000008C1CC0: 02001130
	s_waitcnt lgkmcnt(2)                                       // 0000008C1CC4: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000008C1CC8: BF870132
	v_dot2_f32_bf16 v1, v45, v64, v1                           // 0000008C1CCC: CC1A4001 1C06812D
	v_add_co_ci_u32_e64 v45, null, s9, v49, vcc_lo             // 0000008C1CD4: D5207C2D 01AA6209
	s_waitcnt lgkmcnt(1)                                       // 0000008C1CDC: BF89FC17
	v_dot2_f32_bf16 v1, v46, v65, v1                           // 0000008C1CE0: CC1A4001 1C06832E
	s_waitcnt lgkmcnt(0)                                       // 0000008C1CE8: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C1CEC: BF870091
	v_dot2_f32_bf16 v1, v47, v66, v1                           // 0000008C1CF0: CC1A4001 1C06852F
	v_fmac_f32_e32 v30, v50, v1                                // 0000008C1CF8: 563C0332
	s_clause 0x3                                               // 0000008C1CFC: BF850003
	global_load_b128 v[1:4], v[44:45], off                     // 0000008C1D00: DC5E0000 017C002C
	global_load_b128 v[5:8], v[44:45], off offset:16           // 0000008C1D08: DC5E0010 057C002C
	global_load_b128 v[13:16], v[44:45], off offset:32         // 0000008C1D10: DC5E0020 0D7C002C
	global_load_b128 v[44:47], v[44:45], off offset:48         // 0000008C1D18: DC5E0030 2C7C002C
	s_waitcnt vmcnt(3)                                         // 0000008C1D20: BF890FF7
	v_dot2_f32_bf16 v1, v1, v51, 0                             // 0000008C1D24: CC1A4001 1A026701
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C1D2C: BF870091
	v_dot2_f32_bf16 v1, v2, v52, v1                            // 0000008C1D30: CC1A4001 1C066902
	v_dot2_f32_bf16 v1, v3, v53, v1                            // 0000008C1D38: CC1A4001 1C066B03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C1D40: BF8700A1
	v_dot2_f32_bf16 v1, v4, v54, v1                            // 0000008C1D44: CC1A4001 1C066D04
	s_waitcnt vmcnt(2)                                         // 0000008C1D4C: BF890BF7
	v_dot2_f32_bf16 v1, v5, v55, v1                            // 0000008C1D50: CC1A4001 1C066F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C1D58: BF870091
	v_dot2_f32_bf16 v1, v6, v56, v1                            // 0000008C1D5C: CC1A4001 1C067106
	v_dot2_f32_bf16 v1, v7, v57, v1                            // 0000008C1D64: CC1A4001 1C067307
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C1D6C: BF8700A1
	v_dot2_f32_bf16 v1, v8, v58, v1                            // 0000008C1D70: CC1A4001 1C067508
	s_waitcnt vmcnt(1)                                         // 0000008C1D78: BF8907F7
	v_dot2_f32_bf16 v1, v13, v59, v1                           // 0000008C1D7C: CC1A4001 1C06770D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C1D84: BF870091
	v_dot2_f32_bf16 v1, v14, v60, v1                           // 0000008C1D88: CC1A4001 1C06790E
	v_dot2_f32_bf16 v1, v15, v61, v1                           // 0000008C1D90: CC1A4001 1C067B0F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C1D98: BF8700A1
	v_dot2_f32_bf16 v1, v16, v62, v1                           // 0000008C1D9C: CC1A4001 1C067D10
	s_waitcnt vmcnt(0)                                         // 0000008C1DA4: BF8903F7
	v_dot2_f32_bf16 v1, v44, v63, v1                           // 0000008C1DA8: CC1A4001 1C067F2C
	.long 0xd7006a2c                                           // 0000008C1DB0: D7006A2C
	v_cndmask_b32_e32 v0, v48, v6, vcc_lo                      // 0000008C1DB4: 02000D30
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008C1DB8: BF870122
	v_dot2_f32_bf16 v1, v45, v64, v1                           // 0000008C1DBC: CC1A4001 1C06812D
	v_add_co_ci_u32_e64 v45, null, s7, v49, vcc_lo             // 0000008C1DC4: D5207C2D 01AA6207
	v_dot2_f32_bf16 v1, v46, v65, v1                           // 0000008C1DCC: CC1A4001 1C06832E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C1DD4: BF870091
	v_dot2_f32_bf16 v1, v47, v66, v1                           // 0000008C1DD8: CC1A4001 1C06852F
	v_fmac_f32_e32 v32, v50, v1                                // 0000008C1DE0: 56400332
	s_clause 0x3                                               // 0000008C1DE4: BF850003
	global_load_b128 v[1:4], v[44:45], off                     // 0000008C1DE8: DC5E0000 017C002C
	global_load_b128 v[5:8], v[44:45], off offset:16           // 0000008C1DF0: DC5E0010 057C002C
	global_load_b128 v[13:16], v[44:45], off offset:32         // 0000008C1DF8: DC5E0020 0D7C002C
	global_load_b128 v[44:47], v[44:45], off offset:48         // 0000008C1E00: DC5E0030 2C7C002C
	s_waitcnt vmcnt(3)                                         // 0000008C1E08: BF890FF7
	v_dot2_f32_bf16 v1, v1, v51, 0                             // 0000008C1E0C: CC1A4001 1A026701
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C1E14: BF870091
	v_dot2_f32_bf16 v1, v2, v52, v1                            // 0000008C1E18: CC1A4001 1C066902
	v_dot2_f32_bf16 v1, v3, v53, v1                            // 0000008C1E20: CC1A4001 1C066B03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C1E28: BF8700A1
	v_dot2_f32_bf16 v1, v4, v54, v1                            // 0000008C1E2C: CC1A4001 1C066D04
	s_waitcnt vmcnt(2)                                         // 0000008C1E34: BF890BF7
	v_dot2_f32_bf16 v1, v5, v55, v1                            // 0000008C1E38: CC1A4001 1C066F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C1E40: BF870091
	v_dot2_f32_bf16 v1, v6, v56, v1                            // 0000008C1E44: CC1A4001 1C067106
	v_dot2_f32_bf16 v1, v7, v57, v1                            // 0000008C1E4C: CC1A4001 1C067307
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C1E54: BF8700A1
	v_dot2_f32_bf16 v1, v8, v58, v1                            // 0000008C1E58: CC1A4001 1C067508
	s_waitcnt vmcnt(1)                                         // 0000008C1E60: BF8907F7
	v_dot2_f32_bf16 v1, v13, v59, v1                           // 0000008C1E64: CC1A4001 1C06770D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C1E6C: BF870091
	v_dot2_f32_bf16 v1, v14, v60, v1                           // 0000008C1E70: CC1A4001 1C06790E
	v_dot2_f32_bf16 v1, v15, v61, v1                           // 0000008C1E78: CC1A4001 1C067B0F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C1E80: BF8700A1
	v_dot2_f32_bf16 v1, v16, v62, v1                           // 0000008C1E84: CC1A4001 1C067D10
	s_waitcnt vmcnt(0)                                         // 0000008C1E8C: BF8903F7
	v_dot2_f32_bf16 v1, v44, v63, v1                           // 0000008C1E90: CC1A4001 1C067F2C
	.long 0xd7006a2c                                           // 0000008C1E98: D7006A2C
	v_cndmask_b32_e32 v0, v48, v21, vcc_lo                     // 0000008C1E9C: 02002B30
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008C1EA0: BF870122
	v_dot2_f32_bf16 v1, v45, v64, v1                           // 0000008C1EA4: CC1A4001 1C06812D
	v_add_co_ci_u32_e64 v45, null, s19, v49, vcc_lo            // 0000008C1EAC: D5207C2D 01AA6213
	v_dot2_f32_bf16 v1, v46, v65, v1                           // 0000008C1EB4: CC1A4001 1C06832E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C1EBC: BF870091
	v_dot2_f32_bf16 v1, v47, v66, v1                           // 0000008C1EC0: CC1A4001 1C06852F
	v_fmac_f32_e32 v31, v50, v1                                // 0000008C1EC8: 563E0332
	s_clause 0x3                                               // 0000008C1ECC: BF850003
	global_load_b128 v[1:4], v[44:45], off                     // 0000008C1ED0: DC5E0000 017C002C
	global_load_b128 v[5:8], v[44:45], off offset:16           // 0000008C1ED8: DC5E0010 057C002C
	global_load_b128 v[13:16], v[44:45], off offset:32         // 0000008C1EE0: DC5E0020 0D7C002C
	global_load_b128 v[44:47], v[44:45], off offset:48         // 0000008C1EE8: DC5E0030 2C7C002C
	s_waitcnt vmcnt(3)                                         // 0000008C1EF0: BF890FF7
	v_dot2_f32_bf16 v1, v1, v51, 0                             // 0000008C1EF4: CC1A4001 1A026701
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C1EFC: BF870091
	v_dot2_f32_bf16 v1, v2, v52, v1                            // 0000008C1F00: CC1A4001 1C066902
	v_dot2_f32_bf16 v1, v3, v53, v1                            // 0000008C1F08: CC1A4001 1C066B03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C1F10: BF8700A1
	v_dot2_f32_bf16 v1, v4, v54, v1                            // 0000008C1F14: CC1A4001 1C066D04
	s_waitcnt vmcnt(2)                                         // 0000008C1F1C: BF890BF7
	v_dot2_f32_bf16 v1, v5, v55, v1                            // 0000008C1F20: CC1A4001 1C066F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C1F28: BF870091
	v_dot2_f32_bf16 v1, v6, v56, v1                            // 0000008C1F2C: CC1A4001 1C067106
	v_dot2_f32_bf16 v1, v7, v57, v1                            // 0000008C1F34: CC1A4001 1C067307
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C1F3C: BF8700A1
	v_dot2_f32_bf16 v1, v8, v58, v1                            // 0000008C1F40: CC1A4001 1C067508
	s_waitcnt vmcnt(1)                                         // 0000008C1F48: BF8907F7
	v_dot2_f32_bf16 v1, v13, v59, v1                           // 0000008C1F4C: CC1A4001 1C06770D
	v_mov_b32_e32 v13, v9                                      // 0000008C1F54: 7E1A0309
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008C1F58: BF870122
	v_dot2_f32_bf16 v1, v14, v60, v1                           // 0000008C1F5C: CC1A4001 1C06790E
	v_mov_b32_e32 v14, v10                                     // 0000008C1F64: 7E1C030A
	v_dot2_f32_bf16 v1, v15, v61, v1                           // 0000008C1F68: CC1A4001 1C067B0F
	v_mov_b32_e32 v15, v11                                     // 0000008C1F70: 7E1E030B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000008C1F74: BF870132
	v_dot2_f32_bf16 v1, v16, v62, v1                           // 0000008C1F78: CC1A4001 1C067D10
	v_mov_b32_e32 v16, v12                                     // 0000008C1F80: 7E20030C
	s_waitcnt vmcnt(0)                                         // 0000008C1F84: BF8903F7
	v_dot2_f32_bf16 v1, v44, v63, v1                           // 0000008C1F88: CC1A4001 1C067F2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C1F90: BF870091
	v_dot2_f32_bf16 v1, v45, v64, v1                           // 0000008C1F94: CC1A4001 1C06812D
	v_dot2_f32_bf16 v1, v46, v65, v1                           // 0000008C1F9C: CC1A4001 1C06832E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C1FA4: BF870091
	v_dot2_f32_bf16 v1, v47, v66, v1                           // 0000008C1FA8: CC1A4001 1C06852F
	v_fmac_f32_e32 v27, v50, v1                                // 0000008C1FB0: 56360332
	v_dual_mov_b32 v1, v36 :: v_dual_mov_b32 v2, v37           // 0000008C1FB4: CA100124 01020125
	v_dual_mov_b32 v3, v38 :: v_dual_mov_b32 v4, v39           // 0000008C1FBC: CA100126 03040127
	v_dual_mov_b32 v5, v40 :: v_dual_mov_b32 v6, v41           // 0000008C1FC4: CA100128 05060129
	v_dual_mov_b32 v7, v42 :: v_dual_mov_b32 v8, v43           // 0000008C1FCC: CA10012A 0708012B
	s_and_not1_b32 exec_lo, exec_lo, s20                       // 0000008C1FD4: 917E147E
	s_cbranch_execz 35                                         // 0000008C1FD8: BFA50023 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0xb68>
	s_waitcnt vmcnt(0)                                         // 0000008C1FDC: BF8903F7
	v_dual_mov_b32 v9, v13 :: v_dual_add_nc_u32 v24, 32, v24   // 0000008C1FE0: CA20010D 091830A0
	v_dual_mov_b32 v10, v14 :: v_dual_mov_b32 v11, v15         // 0000008C1FE8: CA10010E 0A0A010F
	v_mov_b32_e32 v12, v16                                     // 0000008C1FF0: 7E180310
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008C1FF4: BF870003
	.long 0xd4460005                                           // 0000008C1FF8: D4460005
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 0000008C1FFC: 02023318
	s_mov_b32 s14, exec_lo                                     // 0000008C2000: BE8E007E
	.long 0xd4c1007e                                           // 0000008C2004: D4C1007E
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 0000008C2008: 02023318
	s_cbranch_execz 65148                                      // 0000008C200C: BFA5FE7C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x500>
	v_ashrrev_i32_e32 v10, 31, v33                             // 0000008C2010: 3414429F
	.long 0xd7006a09                                           // 0000008C2014: D7006A09
	v_cndmask_b32_e32 v1, v18, v33, vcc_lo                     // 0000008C2018: 02024312
	v_mov_b32_e32 v35, v20                                     // 0000008C201C: 7E460314
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008C2020: BF870003
	v_add_co_ci_u32_e64 v10, null, v29, v10, vcc_lo            // 0000008C2024: D5207C0A 01AA151D
	v_cmp_ne_u32_e32 vcc_lo, 1, v28                            // 0000008C202C: 7C9A3881
	global_load_b128 v[9:12], v[9:10], off                     // 0000008C2030: DC5E0000 097C0009
	s_cbranch_vccnz 65137                                      // 0000008C2038: BFA4FE71 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x500>
	v_ashrrev_i32_e32 v36, 31, v34                             // 0000008C203C: 3448449F
	.long 0xd7006a23                                           // 0000008C2040: D7006A23
	v_cndmask_b32_e32 v1, v17, v34, vcc_lo                     // 0000008C2044: 02024511
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008C2048: BF870001
	v_add_co_ci_u32_e64 v36, null, v26, v36, vcc_lo            // 0000008C204C: D5207C24 01AA491A
	global_load_d16_b16 v35, v[35:36], off                     // 0000008C2054: DC820000 237C0023
	s_waitcnt vmcnt(0)                                         // 0000008C205C: BF8903F7
	v_cvt_f32_f16_e32 v35, v35                                 // 0000008C2060: 7E461723
	s_branch 65126                                             // 0000008C2064: BFA0FE66 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x500>
	s_or_b32 exec_lo, exec_lo, s20                             // 0000008C2068: 8C7E147E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008C206C: BF8700B9
	s_or_b32 exec_lo, exec_lo, s18                             // 0000008C2070: 8C7E127E
	.long 0xd71f0001                                           // 0000008C2074: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000008C2078: 020100C1
	s_mov_b32 s4, exec_lo                                      // 0000008C207C: BE84007E
	v_xor_b32_e32 v2, 16, v1                                   // 0000008C2080: 3A040290
	v_xor_b32_e32 v6, 8, v1                                    // 0000008C2084: 3A0C0288
	v_xor_b32_e32 v10, 4, v1                                   // 0000008C2088: 3A140284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000008C208C: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000008C2090: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 0000008C2094: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 0000008C2098: 7C980CA0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008C209C: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000008C20A0: 30040482
	ds_bpermute_b32 v5, v2, v31                                // 0000008C20A4: DACC0000 05001F02
	s_waitcnt lgkmcnt(0)                                       // 0000008C20AC: BF89FC07
	v_add_f32_e32 v5, v31, v5                                  // 0000008C20B0: 060A0B1F
	ds_bpermute_b32 v3, v2, v30                                // 0000008C20B4: DACC0000 03001E02
	ds_bpermute_b32 v4, v2, v32                                // 0000008C20BC: DACC0000 04002002
	ds_bpermute_b32 v2, v2, v27                                // 0000008C20C4: DACC0000 02001B02
	s_waitcnt lgkmcnt(2)                                       // 0000008C20CC: BF89FC27
	v_dual_add_f32 v3, v30, v3 :: v_dual_cndmask_b32 v6, v1, v6// 0000008C20D0: C912071E 03060D01
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 0000008C20D8: 7C9814A0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008C20DC: BF870002
	v_lshlrev_b32_e32 v6, 2, v6                                // 0000008C20E0: 300C0C82
	v_cndmask_b32_e32 v10, v1, v10, vcc_lo                     // 0000008C20E4: 02141501
	ds_bpermute_b32 v9, v6, v5                                 // 0000008C20E8: DACC0000 09000506
	s_waitcnt lgkmcnt(0)                                       // 0000008C20F0: BF89FC07
	v_dual_add_f32 v5, v5, v9 :: v_dual_lshlrev_b32 v10, 2, v10// 0000008C20F4: C9221305 050A1482
	ds_bpermute_b32 v7, v6, v3                                 // 0000008C20FC: DACC0000 07000306
	v_add_f32_e32 v2, v27, v2                                  // 0000008C2104: 0604051B
	s_waitcnt lgkmcnt(0)                                       // 0000008C2108: BF89FC07
	v_dual_add_f32 v3, v3, v7 :: v_dual_add_f32 v4, v32, v4    // 0000008C210C: C9080F03 03040920
	ds_bpermute_b32 v8, v6, v4                                 // 0000008C2114: DACC0000 08000406
	ds_bpermute_b32 v6, v6, v2                                 // 0000008C211C: DACC0000 06000206
	s_waitcnt lgkmcnt(0)                                       // 0000008C2124: BF89FC07
	v_add_f32_e32 v2, v2, v6                                   // 0000008C2128: 06040D02
	ds_bpermute_b32 v6, v10, v3                                // 0000008C212C: DACC0000 0600030A
	ds_bpermute_b32 v9, v10, v2                                // 0000008C2134: DACC0000 0900020A
	s_waitcnt lgkmcnt(1)                                       // 0000008C213C: BF89FC17
	v_dual_add_f32 v3, v3, v6 :: v_dual_add_f32 v4, v4, v8     // 0000008C2140: C9080D03 03041104
	ds_bpermute_b32 v8, v10, v5                                // 0000008C2148: DACC0000 0800050A
	s_waitcnt lgkmcnt(1)                                       // 0000008C2150: BF89FC17
	v_add_f32_e32 v6, v2, v9                                   // 0000008C2154: 060C1302
	ds_bpermute_b32 v7, v10, v4                                // 0000008C2158: DACC0000 0700040A
	v_xor_b32_e32 v10, 2, v1                                   // 0000008C2160: 3A140282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008C2164: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 0000008C2168: 7C9814A0
	v_cndmask_b32_e32 v10, v1, v10, vcc_lo                     // 0000008C216C: 02141501
	s_waitcnt lgkmcnt(1)                                       // 0000008C2170: BF89FC17
	v_dual_add_f32 v5, v5, v8 :: v_dual_lshlrev_b32 v10, 2, v10// 0000008C2174: C9221105 050A1482
	ds_bpermute_b32 v2, v10, v3                                // 0000008C217C: DACC0000 0200030A
	s_waitcnt lgkmcnt(1)                                       // 0000008C2184: BF89FC17
	v_add_f32_e32 v4, v4, v7                                   // 0000008C2188: 06080F04
	ds_bpermute_b32 v8, v10, v5                                // 0000008C218C: DACC0000 0800050A
	ds_bpermute_b32 v9, v10, v6                                // 0000008C2194: DACC0000 0900060A
	ds_bpermute_b32 v7, v10, v4                                // 0000008C219C: DACC0000 0700040A
	v_xor_b32_e32 v10, 1, v1                                   // 0000008C21A4: 3A140281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008C21A8: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 0000008C21AC: 7C9814A0
	v_cndmask_b32_e32 v1, v1, v10, vcc_lo                      // 0000008C21B0: 02021501
	s_waitcnt lgkmcnt(3)                                       // 0000008C21B4: BF89FC37
	v_dual_add_f32 v1, v3, v2 :: v_dual_lshlrev_b32 v10, 2, v1 // 0000008C21B8: C9220503 010A0282
	s_waitcnt lgkmcnt(2)                                       // 0000008C21C0: BF89FC27
	v_add_f32_e32 v3, v5, v8                                   // 0000008C21C4: 06061105
	s_waitcnt lgkmcnt(0)                                       // 0000008C21C8: BF89FC07
	v_dual_add_f32 v5, v6, v9 :: v_dual_add_f32 v2, v4, v7     // 0000008C21CC: C9081306 05020F04
	ds_bpermute_b32 v4, v10, v1                                // 0000008C21D4: DACC0000 0400010A
	ds_bpermute_b32 v7, v10, v3                                // 0000008C21DC: DACC0000 0700030A
	ds_bpermute_b32 v8, v10, v5                                // 0000008C21E4: DACC0000 0800050A
	ds_bpermute_b32 v6, v10, v2                                // 0000008C21EC: DACC0000 0600020A
	v_cmpx_eq_u32_e32 0, v23                                   // 0000008C21F4: 7D942E80
	s_cbranch_execz 9                                          // 0000008C21F8: BFA50009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0xd20>
	s_waitcnt lgkmcnt(1)                                       // 0000008C21FC: BF89FC17
	v_dual_add_f32 v8, v5, v8 :: v_dual_add_f32 v7, v3, v7     // 0000008C2200: C9081105 08060F03
	s_waitcnt lgkmcnt(0)                                       // 0000008C2208: BF89FC07
	v_dual_add_f32 v6, v2, v6 :: v_dual_add_f32 v5, v1, v4     // 0000008C220C: C9080D02 06040901
	v_lshlrev_b32_e32 v1, 4, v22                               // 0000008C2214: 30022C84
	ds_store_b128 v1, v[5:8] offset:1024                       // 0000008C2218: DB7C0400 00000501
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008C2220: 8C7E047E
	.long 0xd4510004                                           // 0000008C2224: D4510004
	v_cndmask_b32_e32 v0, s2, v16, vcc_lo                      // 0000008C2228: 02002002
	v_cmp_gt_u32_e32 vcc_lo, 4, v0                             // 0000008C222C: 7C980084
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000008C2230: BF890007
	s_barrier                                                  // 0000008C2234: BFBD0000
	buffer_gl0_inv                                             // 0000008C2238: E0AC0000 00000000
	s_and_b32 s4, vcc_lo, s4                                   // 0000008C2240: 8B04046A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000008C2244: BF870009
	s_and_saveexec_b32 s5, s4                                  // 0000008C2248: BE852004
	s_cbranch_execz 80                                         // 0000008C224C: BFA50050 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0xe90>
	v_add_nc_u32_e32 v7, 0x400, v21                            // 0000008C2250: 4A0E2AFF 00000400
	s_lshr_b32 s4, s17, 31                                     // 0000008C2258: 85049F11
	s_load_b64 s[0:1], s[0:1], 0x40                            // 0000008C225C: F4040000 F8000040
	s_add_u32 s4, s16, s4                                      // 0000008C2264: 80040410
	s_addc_u32 s5, s17, 0                                      // 0000008C2268: 82058011
	ds_load_2addr_b32 v[1:2], v7 offset1:4                     // 0000008C226C: D8DC0400 01000007
	ds_load_2addr_b32 v[3:4], v7 offset0:8 offset1:12          // 0000008C2274: D8DC0C08 03000007
	ds_load_2addr_b32 v[5:6], v7 offset0:16 offset1:20         // 0000008C227C: D8DC1410 05000007
	s_ashr_i64 s[4:5], s[4:5], 1                               // 0000008C2284: 86848104
	s_lshr_b32 s6, s3, 23                                      // 0000008C2288: 85069703
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000008C228C: BF8704B9
	s_add_u32 s6, s2, s6                                       // 0000008C2290: 80060602
	s_addc_u32 s7, s3, 0                                       // 0000008C2294: 82078003
	s_and_b32 s6, s6, 0xfffffe00                               // 0000008C2298: 8B06FF06 FFFFFE00
	s_sub_u32 s2, s2, s6                                       // 0000008C22A0: 80820602
	s_subb_u32 s3, s3, s7                                      // 0000008C22A4: 82830703
	s_waitcnt lgkmcnt(0)                                       // 0000008C22A8: BF89FC07
	v_add_f32_e32 v1, 0, v1                                    // 0000008C22AC: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C22B0: BF870091
	v_add_f32_e32 v1, v1, v2                                   // 0000008C22B4: 06020501
	v_add_f32_e32 v3, v1, v3                                   // 0000008C22B8: 06060701
	v_mad_u64_u32 v[1:2], null, s4, v0, 0                      // 0000008C22BC: D6FE7C01 02020004
	.long 0xd4540004                                           // 0000008C22C4: D4540004
	v_cndmask_b32_e32 v0, 0x100, v2, vcc_lo                    // 0000008C22C8: 020004FF 00000100
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C22D0: BF870093
	v_add_f32_e32 v3, v3, v4                                   // 0000008C22D4: 06060903
	v_add_f32_e32 v4, v3, v5                                   // 0000008C22D8: 06080B03
	s_delay_alu instid0(VALU_DEP_4)                            // 0000008C22DC: BF870004
	v_mad_u64_u32 v[2:3], null, s5, v0, v[2:3]                 // 0000008C22E0: D6FE7C02 040A0005
	s_and_b32 s5, s4, exec_lo                                  // 0000008C22E8: 8B057E04
	s_cselect_b32 s8, s12, s0                                  // 0000008C22EC: 9808000C
	s_cselect_b32 s5, s13, s1                                  // 0000008C22F0: 9805010D
	v_add_f32_e32 v0, v4, v6                                   // 0000008C22F4: 06000D04
	ds_load_2addr_b32 v[7:8], v7 offset0:24 offset1:28         // 0000008C22F8: D8DC1C18 07000007
	s_add_u32 s0, s2, 0xffffff00                               // 0000008C2300: 8000FF02 FFFFFF00
	s_addc_u32 s1, s3, -1                                      // 0000008C2308: 8201C103
	s_and_b32 s4, s4, exec_lo                                  // 0000008C230C: 8B047E04
	s_cselect_b32 s1, s3, s1                                   // 0000008C2310: 98010103
	s_cselect_b32 s0, s2, s0                                   // 0000008C2314: 98000002
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000008C2318: BF870149
	s_lshl_b64 s[0:1], s[0:1], 1                               // 0000008C231C: 84808100
	s_waitcnt lgkmcnt(0)                                       // 0000008C2320: BF89FC07
	v_add_f32_e32 v3, v0, v7                                   // 0000008C2324: 06060F00
	.long 0xd73c0000                                           // 0000008C2328: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000008C232C: 02020281
	v_add_f32_e32 v2, v3, v8                                   // 0000008C2330: 06041103
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C2334: BF870092
	.long 0xd7006a00                                           // 0000008C2338: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 0000008C233C: 02020008
	v_add_co_ci_u32_e64 v1, null, s5, v1, vcc_lo               // 0000008C2340: D5207C01 01AA0205
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008C2348: BF870193
	v_bfe_u32 v3, v2, 16, 1                                    // 0000008C234C: D6100003 02052102
	.long 0xd7006a00                                           // 0000008C2354: D7006A00
	v_cndmask_b32_e32 v0, v0, v6, vcc_lo                       // 0000008C2358: 02000D00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008C235C: BF870191
	v_add_co_ci_u32_e64 v1, null, s7, v1, vcc_lo               // 0000008C2360: D5207C01 01AA0207
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000008C2368: D6550002 03FE0702 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C2374: BF870093
	.long 0xd7006a00                                           // 0000008C2378: D7006A00
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 0000008C237C: 02000100
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 0000008C2380: D5207C01 01AA0201
	global_store_d16_hi_b16 v[0:1], v2, off                    // 0000008C2388: DC960000 007C0200
	s_endpgm                                                   // 0000008C2390: BFB00000
		...

