000000000055a200 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 00000055A200: F4100100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 00000055A208: 86039F02
	v_lshrrev_b32_e32 v21, 2, v0                               // 00000055A20C: 322A0082
	s_lshl_b64 s[2:3], s[2:3], 2                               // 00000055A210: 84828202
	v_and_b32_e32 v1, 15, v0                                   // 00000055A214: 3602008F
	v_lshrrev_b32_e32 v22, 6, v0                               // 00000055A218: 322C0086
	v_bfe_u32 v23, v0, 5, 1                                    // 00000055A21C: D6100017 02050B00
	v_and_b32_e32 v2, 60, v21                                  // 00000055A224: 36042ABC
	.long 0x7f0a3880                                           // 00000055A228: 7F0A3880
	v_lshlrev_b32_e32 v1, 2, v1                                // 00000055A22C: 30020282
	s_waitcnt lgkmcnt(0)                                       // 00000055A230: BF89FC07
	s_clause 0x1                                               // 00000055A234: BF850001
	global_load_b32 v3, v1, s[4:5]                             // 00000055A238: DC520000 03040001
	global_load_b32 v4, v2, s[4:5]                             // 00000055A240: DC520000 04040002
	s_add_u32 s0, s4, s16                                      // 00000055A248: 80001004
	s_addc_u32 s1, s5, s17                                     // 00000055A24C: 82011105
	s_ashr_i32 s16, s11, 31                                    // 00000055A250: 86109F0B
	v_mov_b32_e32 v2, s3                                       // 00000055A254: 7E040203
	s_lshr_b32 s16, s16, 27                                    // 00000055A258: 85109B10
	v_or_b32_e32 v1, s2, v22                                   // 00000055A25C: 38022C02
	s_add_u32 s16, s10, s16                                    // 00000055A260: 8010100A
	s_addc_u32 s17, s11, 0                                     // 00000055A264: 8211800B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000055A268: BF870099
	s_lshr_b64 s[16:17], s[16:17], 5                           // 00000055A26C: 85908510
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 00000055A270: 7CA8020C
	s_add_i32 s17, s16, 1                                      // 00000055A274: 81118110
	v_and_b32_e32 v24, 31, v0                                  // 00000055A278: 3630009F
	s_lshr_b32 s20, s17, 31                                    // 00000055A27C: 85149F11
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000055A280: BF870009
	s_add_i32 s17, s17, s20                                    // 00000055A284: 81111411
	v_cndmask_b32_e32 v9, 0, v1, vcc_lo                        // 00000055A288: 02120280
	s_ashr_i32 s17, s17, 1                                     // 00000055A28C: 86118111
	v_cndmask_b32_e64 v10, 0, s3, vcc_lo                       // 00000055A290: D501000A 01A80680
	.long 0xd72c0002                                           // 00000055A298: D72C0002
	v_cndmask_b32_e32 v1, s17, v23, vcc_lo                     // 00000055A29C: 02022E11
	s_cmpk_lt_i32 s16, 0x201                                   // 00000055A2A0: B3900201
	.long 0xd72c0007                                           // 00000055A2A4: D72C0007
	v_cndmask_b32_e32 v1, s19, v9, vcc_lo                      // 00000055A2A8: 02021213
	v_mad_u64_u32 v[17:18], null, s18, v9, s[0:1]              // 00000055A2AC: D6FE7C11 00021212
	s_cselect_b32 s0, -1, 0                                    // 00000055A2B4: 980080C1
	s_cmpk_gt_i32 s16, 0x200                                   // 00000055A2B8: B2900200
	v_lshlrev_b32_e32 v1, 2, v0                                // 00000055A2BC: 30020082
	v_add_nc_u32_e32 v11, s17, v2                              // 00000055A2C0: 4A160411
	v_add_nc_u32_e32 v25, v2, v24                              // 00000055A2C4: 4A323102
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000055A2C8: BF8704A2
	v_min_i32_e32 v26, s16, v11                                // 00000055A2CC: 22341610
	s_cselect_b32 s16, -1, 0                                   // 00000055A2D0: 981080C1
	s_and_b32 vcc_lo, exec_lo, s16                             // 00000055A2D4: 8B6A107E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 00000055A2D8: BF870151
	.long 0xd4410001                                           // 00000055A2DC: D4410001
	v_cndmask_b32_e32 v1, v25, v26, vcc_lo                     // 00000055A2E0: 02023519
	s_waitcnt vmcnt(1)                                         // 00000055A2E4: BF8907F7
	v_bfe_u32 v6, v3, 16, 1                                    // 00000055A2E8: D6100006 02052103
	s_waitcnt vmcnt(0)                                         // 00000055A2F0: BF8903F7
	v_bfe_u32 v8, v4, 16, 1                                    // 00000055A2F4: D6100008 02052104
	v_add3_u32 v3, v3, v6, 0x7fff                              // 00000055A2FC: D6550003 03FE0D03 00007FFF
	.long 0xd72c0006                                           // 00000055A308: D72C0006
	v_cndmask_b32_e32 v1, s18, v10, vcc_lo                     // 00000055A30C: 02021412
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000055A310: BF870193
	v_add3_u32 v4, v4, v8, 0x7fff                              // 00000055A314: D6550004 03FE1104 00007FFF
	.long 0x7e0a3983                                           // 00000055A320: 7E0A3983
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000055A324: BF870113
	v_add3_u32 v27, v7, v18, v6                                // 00000055A328: D655001B 041A2507
	v_and_or_b32 v2, 0xffff0000, v4, v5                        // 00000055A330: D6570002 041608FF FFFF0000
	ds_store_b32 v1, v2                                        // 00000055A33C: D8340000 00000201
	s_waitcnt lgkmcnt(0)                                       // 00000055A344: BF89FC07
	s_barrier                                                  // 00000055A348: BFBD0000
	buffer_gl0_inv                                             // 00000055A34C: E0AC0000 00000000
	s_cbranch_vccnz 154                                        // 00000055A354: BFA4009A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x3c0>
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v1, 0               // 00000055A358: CA100080 02000080
	s_and_saveexec_b32 s17, s1                                 // 00000055A360: BE912001
	s_cbranch_execz 11                                         // 00000055A364: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x194>
	v_lshlrev_b32_e32 v1, 1, v25                               // 00000055A368: 30023281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000055A36C: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v1                               // 00000055A370: 3408029F
	.long 0xd7006a03                                           // 00000055A374: D7006A03
	v_cndmask_b32_e32 v1, v17, v1, vcc_lo                      // 00000055A378: 02020311
	v_add_co_ci_u32_e64 v4, null, v27, v4, vcc_lo              // 00000055A37C: D5207C04 01AA091B
	global_load_d16_b16 v1, v[3:4], off                        // 00000055A384: DC820000 017C0003
	s_waitcnt vmcnt(0)                                         // 00000055A38C: BF8903F7
	v_cvt_f32_f16_e32 v1, v1                                   // 00000055A390: 7E021701
	s_or_b32 exec_lo, exec_lo, s17                             // 00000055A394: 8C7E117E
	v_add_nc_u32_e32 v3, 32, v25                               // 00000055A398: 4A0632A0
	s_mov_b32 s1, exec_lo                                      // 00000055A39C: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000055A3A0: BF870001
	.long 0xd4c1007e                                           // 00000055A3A4: D4C1007E
	v_cndmask_b32_e32 v1, v3, v26, vcc_lo                      // 00000055A3A8: 02023503
	s_cbranch_execz 11                                         // 00000055A3AC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x1dc>
	v_lshlrev_b32_e32 v2, 1, v3                                // 00000055A3B0: 30040681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000055A3B4: BF8700A1
	v_ashrrev_i32_e32 v3, 31, v2                               // 00000055A3B8: 3406049F
	.long 0xd7006a02                                           // 00000055A3BC: D7006A02
	v_cndmask_b32_e32 v1, v17, v2, vcc_lo                      // 00000055A3C0: 02020511
	v_add_co_ci_u32_e64 v3, null, v27, v3, vcc_lo              // 00000055A3C4: D5207C03 01AA071B
	global_load_d16_b16 v2, v[2:3], off                        // 00000055A3CC: DC820000 027C0002
	s_waitcnt vmcnt(0)                                         // 00000055A3D4: BF8903F7
	v_cvt_f32_f16_e32 v2, v2                                   // 00000055A3D8: 7E041702
	s_or_b32 exec_lo, exec_lo, s1                              // 00000055A3DC: 8C7E017E
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v5, 64, v25      // 00000055A3E0: CA200080 040432C0
	v_mov_b32_e32 v3, 0                                        // 00000055A3E8: 7E060280
	s_mov_b32 s1, exec_lo                                      // 00000055A3EC: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000055A3F0: BF870002
	.long 0xd4c1007e                                           // 00000055A3F4: D4C1007E
	v_cndmask_b32_e32 v1, v5, v26, vcc_lo                      // 00000055A3F8: 02023505
	s_cbranch_execz 11                                         // 00000055A3FC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x22c>
	v_lshlrev_b32_e32 v3, 1, v5                                // 00000055A400: 30060A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000055A404: BF8700A1
	v_ashrrev_i32_e32 v6, 31, v3                               // 00000055A408: 340C069F
	.long 0xd7006a05                                           // 00000055A40C: D7006A05
	v_cndmask_b32_e32 v1, v17, v3, vcc_lo                      // 00000055A410: 02020711
	v_add_co_ci_u32_e64 v6, null, v27, v6, vcc_lo              // 00000055A414: D5207C06 01AA0D1B
	global_load_d16_b16 v3, v[5:6], off                        // 00000055A41C: DC820000 037C0005
	s_waitcnt vmcnt(0)                                         // 00000055A424: BF8903F7
	v_cvt_f32_f16_e32 v3, v3                                   // 00000055A428: 7E061703
	s_or_b32 exec_lo, exec_lo, s1                              // 00000055A42C: 8C7E017E
	v_add_nc_u32_e32 v5, 0x60, v25                             // 00000055A430: 4A0A32FF 00000060
	s_mov_b32 s1, exec_lo                                      // 00000055A438: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000055A43C: BF870001
	.long 0xd4c1007e                                           // 00000055A440: D4C1007E
	v_cndmask_b32_e32 v1, v5, v26, vcc_lo                      // 00000055A444: 02023505
	s_cbranch_execz 11                                         // 00000055A448: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x278>
	v_lshlrev_b32_e32 v4, 1, v5                                // 00000055A44C: 30080A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000055A450: BF8700A1
	v_ashrrev_i32_e32 v5, 31, v4                               // 00000055A454: 340A089F
	.long 0xd7006a04                                           // 00000055A458: D7006A04
	v_cndmask_b32_e32 v1, v17, v4, vcc_lo                      // 00000055A45C: 02020911
	v_add_co_ci_u32_e64 v5, null, v27, v5, vcc_lo              // 00000055A460: D5207C05 01AA0B1B
	global_load_d16_b16 v4, v[4:5], off                        // 00000055A468: DC820000 047C0004
	s_waitcnt vmcnt(0)                                         // 00000055A470: BF8903F7
	v_cvt_f32_f16_e32 v4, v4                                   // 00000055A474: 7E081704
	s_or_b32 exec_lo, exec_lo, s1                              // 00000055A478: 8C7E017E
	v_dual_mov_b32 v6, 0 :: v_dual_add_nc_u32 v7, 0x80, v25    // 00000055A47C: CA200080 060632FF 00000080
	v_mov_b32_e32 v5, 0                                        // 00000055A488: 7E0A0280
	s_mov_b32 s1, exec_lo                                      // 00000055A48C: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000055A490: BF870002
	.long 0xd4c1007e                                           // 00000055A494: D4C1007E
	v_cndmask_b32_e32 v1, v7, v26, vcc_lo                      // 00000055A498: 02023507
	s_cbranch_execz 11                                         // 00000055A49C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x2cc>
	v_lshlrev_b32_e32 v5, 1, v7                                // 00000055A4A0: 300A0E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000055A4A4: BF8700A1
	v_ashrrev_i32_e32 v8, 31, v5                               // 00000055A4A8: 34100A9F
	.long 0xd7006a07                                           // 00000055A4AC: D7006A07
	v_cndmask_b32_e32 v1, v17, v5, vcc_lo                      // 00000055A4B0: 02020B11
	v_add_co_ci_u32_e64 v8, null, v27, v8, vcc_lo              // 00000055A4B4: D5207C08 01AA111B
	global_load_d16_b16 v5, v[7:8], off                        // 00000055A4BC: DC820000 057C0007
	s_waitcnt vmcnt(0)                                         // 00000055A4C4: BF8903F7
	v_cvt_f32_f16_e32 v5, v5                                   // 00000055A4C8: 7E0A1705
	s_or_b32 exec_lo, exec_lo, s1                              // 00000055A4CC: 8C7E017E
	v_add_nc_u32_e32 v7, 0xa0, v25                             // 00000055A4D0: 4A0E32FF 000000A0
	s_mov_b32 s1, exec_lo                                      // 00000055A4D8: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000055A4DC: BF870001
	.long 0xd4c1007e                                           // 00000055A4E0: D4C1007E
	v_cndmask_b32_e32 v1, v7, v26, vcc_lo                      // 00000055A4E4: 02023507
	s_cbranch_execz 11                                         // 00000055A4E8: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x318>
	v_lshlrev_b32_e32 v6, 1, v7                                // 00000055A4EC: 300C0E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000055A4F0: BF8700A1
	v_ashrrev_i32_e32 v7, 31, v6                               // 00000055A4F4: 340E0C9F
	.long 0xd7006a06                                           // 00000055A4F8: D7006A06
	v_cndmask_b32_e32 v1, v17, v6, vcc_lo                      // 00000055A4FC: 02020D11
	v_add_co_ci_u32_e64 v7, null, v27, v7, vcc_lo              // 00000055A500: D5207C07 01AA0F1B
	global_load_d16_b16 v6, v[6:7], off                        // 00000055A508: DC820000 067C0006
	s_waitcnt vmcnt(0)                                         // 00000055A510: BF8903F7
	v_cvt_f32_f16_e32 v6, v6                                   // 00000055A514: 7E0C1706
	s_or_b32 exec_lo, exec_lo, s1                              // 00000055A518: 8C7E017E
	v_dual_mov_b32 v8, 0 :: v_dual_add_nc_u32 v11, 0xc0, v25   // 00000055A51C: CA200080 080A32FF 000000C0
	v_mov_b32_e32 v7, 0                                        // 00000055A528: 7E0E0280
	s_mov_b32 s1, exec_lo                                      // 00000055A52C: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000055A530: BF870002
	.long 0xd4c1007e                                           // 00000055A534: D4C1007E
	v_cndmask_b32_e32 v1, v11, v26, vcc_lo                     // 00000055A538: 0202350B
	s_cbranch_execz 11                                         // 00000055A53C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x36c>
	v_lshlrev_b32_e32 v7, 1, v11                               // 00000055A540: 300E1681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000055A544: BF8700A1
	v_ashrrev_i32_e32 v12, 31, v7                              // 00000055A548: 34180E9F
	.long 0xd7006a0b                                           // 00000055A54C: D7006A0B
	v_cndmask_b32_e32 v1, v17, v7, vcc_lo                      // 00000055A550: 02020F11
	v_add_co_ci_u32_e64 v12, null, v27, v12, vcc_lo            // 00000055A554: D5207C0C 01AA191B
	global_load_d16_b16 v7, v[11:12], off                      // 00000055A55C: DC820000 077C000B
	s_waitcnt vmcnt(0)                                         // 00000055A564: BF8903F7
	v_cvt_f32_f16_e32 v7, v7                                   // 00000055A568: 7E0E1707
	s_or_b32 exec_lo, exec_lo, s1                              // 00000055A56C: 8C7E017E
	v_add_nc_u32_e32 v11, 0xe0, v25                            // 00000055A570: 4A1632FF 000000E0
	s_mov_b32 s1, exec_lo                                      // 00000055A578: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000055A57C: BF870001
	.long 0xd4c1007e                                           // 00000055A580: D4C1007E
	v_cndmask_b32_e32 v1, v11, v26, vcc_lo                     // 00000055A584: 0202350B
	s_cbranch_execz 11                                         // 00000055A588: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x3b8>
	v_lshlrev_b32_e32 v8, 1, v11                               // 00000055A58C: 30101681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000055A590: BF8700A1
	v_ashrrev_i32_e32 v12, 31, v8                              // 00000055A594: 3418109F
	.long 0xd7006a0b                                           // 00000055A598: D7006A0B
	v_cndmask_b32_e32 v1, v17, v8, vcc_lo                      // 00000055A59C: 02021111
	v_add_co_ci_u32_e64 v12, null, v27, v12, vcc_lo            // 00000055A5A0: D5207C0C 01AA191B
	global_load_d16_b16 v8, v[11:12], off                      // 00000055A5A8: DC820000 087C000B
	s_waitcnt vmcnt(0)                                         // 00000055A5B0: BF8903F7
	v_cvt_f32_f16_e32 v8, v8                                   // 00000055A5B4: 7E101708
	s_or_b32 exec_lo, exec_lo, s1                              // 00000055A5B8: 8C7E017E
	s_branch 9                                                 // 00000055A5BC: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x3e4>
	v_mov_b32_e32 v1, 0                                        // 00000055A5C0: 7E020280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000055A5C4: BF870001
	v_mov_b32_e32 v2, v1                                       // 00000055A5C8: 7E040301
	v_mov_b32_e32 v3, v1                                       // 00000055A5CC: 7E060301
	v_mov_b32_e32 v4, v1                                       // 00000055A5D0: 7E080301
	v_mov_b32_e32 v5, v1                                       // 00000055A5D4: 7E0A0301
	v_mov_b32_e32 v6, v1                                       // 00000055A5D8: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 00000055A5DC: 7E0E0301
	v_mov_b32_e32 v8, v1                                       // 00000055A5E0: 7E100301
	s_add_u32 s4, s4, s14                                      // 00000055A5E4: 80040E04
	s_addc_u32 s5, s5, s15                                     // 00000055A5E8: 82050F05
	s_lshr_b32 s1, s11, 31                                     // 00000055A5EC: 85019F0B
	v_dual_mov_b32 v13, 0 :: v_dual_mov_b32 v28, 0             // 00000055A5F0: CA100080 0D1C0080
	s_add_u32 s14, s10, s1                                     // 00000055A5F8: 800E010A
	s_addc_u32 s15, s11, 0                                     // 00000055A5FC: 820F800B
	.long 0xd4410001                                           // 00000055A600: D4410001
	v_cndmask_b32_e32 v1, v25, v26, vcc_lo                     // 00000055A604: 02023519
	s_ashr_i64 s[14:15], s[14:15], 1                           // 00000055A608: 868E810E
	v_cndmask_b32_e64 v29, 0, 1, s16                           // 00000055A60C: D501001D 00410280
	v_mad_u64_u32 v[18:19], null, v9, s14, s[4:5]              // 00000055A614: D6FE7C12 00101D09
	.long 0xd72c0009                                           // 00000055A61C: D72C0009
	v_cndmask_b32_e32 v0, v9, v15, vcc_lo                      // 00000055A620: 02001F09
	.long 0xd72c000a                                           // 00000055A624: D72C000A
	v_cndmask_b32_e32 v0, v10, v14, vcc_lo                     // 00000055A628: 02001D0A
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v15, 0             // 00000055A62C: CA100080 140E0080
	v_mov_b32_e32 v14, 0                                       // 00000055A634: 7E1C0280
	v_mov_b32_e32 v16, 0                                       // 00000055A638: 7E200280
	s_delay_alu instid0(VALU_DEP_4)                            // 00000055A63C: BF870004
	v_add3_u32 v30, v10, v19, v9                               // 00000055A640: D655001E 0426270A
	s_and_saveexec_b32 s4, s1                                  // 00000055A648: BE842001
	s_cbranch_execz 22                                         // 00000055A64C: BFA50016 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x4a8>
	v_dual_mov_b32 v20, 0 :: v_dual_lshlrev_b32 v9, 4, v25     // 00000055A650: CA220080 14083284
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000055A658: BF8700A1
	v_ashrrev_i32_e32 v10, 31, v9                              // 00000055A65C: 3414129F
	.long 0xd7006a09                                           // 00000055A660: D7006A09
	v_cndmask_b32_e32 v1, v18, v9, vcc_lo                      // 00000055A664: 02021312
	v_add_co_ci_u32_e64 v10, null, v30, v10, vcc_lo            // 00000055A668: D5207C0A 01AA151E
	s_and_not1_b32 vcc_lo, exec_lo, s16                        // 00000055A670: 916A107E
	global_load_b128 v[13:16], v[9:10], off                    // 00000055A674: DC5E0000 0D7C0009
	s_cbranch_vccnz 10                                         // 00000055A67C: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x4a8>
	v_lshlrev_b32_e32 v9, 1, v25                               // 00000055A680: 30123281
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000055A684: BF870091
	.long 0xd7006a09                                           // 00000055A688: D7006A09
	v_cndmask_b32_e32 v1, v17, v9, vcc_lo                      // 00000055A68C: 02021311
	v_add_co_ci_u32_e64 v10, null, 0, v27, vcc_lo              // 00000055A690: D5207C0A 01AA3680
	global_load_d16_b16 v9, v[9:10], off                       // 00000055A698: DC820000 097C0009
	s_waitcnt vmcnt(0)                                         // 00000055A6A0: BF8903F7
	v_cvt_f32_f16_e32 v20, v9                                  // 00000055A6A4: 7E281709
	s_or_b32 exec_lo, exec_lo, s4                              // 00000055A6A8: 8C7E047E
	v_dual_mov_b32 v32, 0 :: v_dual_mov_b32 v33, 0             // 00000055A6AC: CA100080 20200080
	v_mov_b32_e32 v31, 0                                       // 00000055A6B4: 7E3E0280
	s_and_saveexec_b32 s14, s1                                 // 00000055A6B8: BE8E2001
	s_cbranch_execz 430                                        // 00000055A6BC: BFA501AE <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xb78>
	v_dual_mov_b32 v32, 0 :: v_dual_add_nc_u32 v9, 32, v25     // 00000055A6C0: CA200080 200832A0
	v_dual_mov_b32 v28, 0 :: v_dual_lshlrev_b32 v19, 5, v25    // 00000055A6C8: CA220080 1C123285
	s_delay_alu instid0(VALU_DEP_2)                            // 00000055A6D0: BF870002
	v_dual_mov_b32 v33, 0 :: v_dual_lshlrev_b32 v34, 4, v9     // 00000055A6D4: CA220080 21221284
	v_mov_b32_e32 v31, 0                                       // 00000055A6DC: 7E3E0280
	v_dual_mov_b32 v36, v20 :: v_dual_lshlrev_b32 v35, 1, v9   // 00000055A6E0: CA220114 24221281
	s_mul_i32 s1, s11, 6                                       // 00000055A6E8: 9601860B
	s_mul_hi_u32 s15, s10, 6                                   // 00000055A6EC: 968F860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 00000055A6F0: 8484820A
	s_add_i32 s15, s15, s1                                     // 00000055A6F4: 810F010F
	s_mul_i32 s17, s10, 6                                      // 00000055A6F8: 9611860A
	s_mov_b32 s16, 0                                           // 00000055A6FC: BE900080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 00000055A700: 848A810A
	s_branch 376                                               // 00000055A704: BFA00178 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xae8>
	s_or_b32 exec_lo, exec_lo, s18                             // 00000055A708: 8C7E127E
	v_cndmask_b32_e64 v51, v20, v1, s0                         // 00000055A70C: D5010033 00020314
	v_cndmask_b32_e64 v37, v1, v2, s0                          // 00000055A714: D5010025 00020501
	v_dual_mov_b32 v44, v8 :: v_dual_and_b32 v1, 0xff, v13     // 00000055A71C: CA240108 2C001AFF 000000FF
	v_cndmask_b32_e64 v43, v7, v8, s0                          // 00000055A728: D501002B 00021107
	v_cndmask_b32_e64 v42, v6, v7, s0                          // 00000055A730: D501002A 00020F06
	v_cndmask_b32_e64 v41, v5, v6, s0                          // 00000055A738: D5010029 00020D05
	v_cndmask_b32_e64 v40, v4, v5, s0                          // 00000055A740: D5010028 00020B04
	v_lshlrev_b32_e32 v1, 2, v1                                // 00000055A748: 30020282
	v_cndmask_b32_e64 v39, v3, v4, s0                          // 00000055A74C: D5010027 00020903
	v_cndmask_b32_e64 v38, v2, v3, s0                          // 00000055A754: D5010026 00020702
	v_ashrrev_i32_e32 v20, 31, v19                             // 00000055A75C: 3428269F
	s_and_b32 s1, exec_lo, s1                                  // 00000055A760: 8B01017E
	ds_load_b32 v52, v1                                        // 00000055A764: D8D80000 34000001
	v_lshrrev_b32_e32 v1, 6, v13                               // 00000055A76C: 32021A86
	s_or_b32 s16, s1, s16                                      // 00000055A770: 8C101001
	v_add_nc_u32_e32 v34, 0x200, v34                           // 00000055A774: 4A4444FF 00000200
	v_add_nc_u32_e32 v35, 64, v35                              // 00000055A77C: 4A4646C0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000055A780: BF8700B3
	v_and_b32_e32 v1, 0x3fc, v1                                // 00000055A784: 360202FF 000003FC
	ds_load_b32 v53, v1                                        // 00000055A78C: D8D80000 35000001
	v_lshrrev_b32_e32 v1, 14, v13                              // 00000055A794: 32021A8E
	v_and_b32_e32 v1, 0x3fc, v1                                // 00000055A798: 360202FF 000003FC
	ds_load_b32 v54, v1                                        // 00000055A7A0: D8D80000 36000001
	v_lshrrev_b32_e32 v1, 22, v13                              // 00000055A7A8: 32021A96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000055A7AC: BF8700B1
	v_and_b32_e32 v1, 0x3fc, v1                                // 00000055A7B0: 360202FF 000003FC
	ds_load_b32 v55, v1                                        // 00000055A7B8: D8D80000 37000001
	v_and_b32_e32 v1, 0xff, v14                                // 00000055A7C0: 36021CFF 000000FF
	v_lshlrev_b32_e32 v1, 2, v1                                // 00000055A7C8: 30020282
	ds_load_b32 v56, v1                                        // 00000055A7CC: D8D80000 38000001
	v_lshrrev_b32_e32 v1, 6, v14                               // 00000055A7D4: 32021C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000055A7D8: BF8700B1
	v_and_b32_e32 v1, 0x3fc, v1                                // 00000055A7DC: 360202FF 000003FC
	ds_load_b32 v57, v1                                        // 00000055A7E4: D8D80000 39000001
	v_lshrrev_b32_e32 v1, 14, v14                              // 00000055A7EC: 32021C8E
	v_and_b32_e32 v1, 0x3fc, v1                                // 00000055A7F0: 360202FF 000003FC
	ds_load_b32 v58, v1                                        // 00000055A7F8: D8D80000 3A000001
	v_lshrrev_b32_e32 v1, 22, v14                              // 00000055A800: 32021C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000055A804: BF8700B1
	v_and_b32_e32 v1, 0x3fc, v1                                // 00000055A808: 360202FF 000003FC
	ds_load_b32 v59, v1                                        // 00000055A810: D8D80000 3B000001
	v_and_b32_e32 v1, 0xff, v15                                // 00000055A818: 36021EFF 000000FF
	v_lshlrev_b32_e32 v1, 2, v1                                // 00000055A820: 30020282
	ds_load_b32 v60, v1                                        // 00000055A824: D8D80000 3C000001
	v_lshrrev_b32_e32 v1, 6, v15                               // 00000055A82C: 32021E86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000055A830: BF8700B1
	v_and_b32_e32 v1, 0x3fc, v1                                // 00000055A834: 360202FF 000003FC
	ds_load_b32 v61, v1                                        // 00000055A83C: D8D80000 3D000001
	v_lshrrev_b32_e32 v1, 14, v15                              // 00000055A844: 32021E8E
	v_and_b32_e32 v1, 0x3fc, v1                                // 00000055A848: 360202FF 000003FC
	ds_load_b32 v62, v1                                        // 00000055A850: D8D80000 3E000001
	v_lshrrev_b32_e32 v1, 22, v15                              // 00000055A858: 32021E96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000055A85C: BF8700B1
	v_and_b32_e32 v1, 0x3fc, v1                                // 00000055A860: 360202FF 000003FC
	ds_load_b32 v63, v1                                        // 00000055A868: D8D80000 3F000001
	v_and_b32_e32 v1, 0xff, v16                                // 00000055A870: 360220FF 000000FF
	v_lshlrev_b32_e32 v1, 2, v1                                // 00000055A878: 30020282
	ds_load_b32 v64, v1                                        // 00000055A87C: D8D80000 40000001
	v_lshrrev_b32_e32 v1, 6, v16                               // 00000055A884: 32022086
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000055A888: BF8700B1
	v_and_b32_e32 v1, 0x3fc, v1                                // 00000055A88C: 360202FF 000003FC
	ds_load_b32 v65, v1                                        // 00000055A894: D8D80000 41000001
	v_lshrrev_b32_e32 v1, 14, v16                              // 00000055A89C: 3202208E
	v_and_b32_e32 v1, 0x3fc, v1                                // 00000055A8A0: 360202FF 000003FC
	ds_load_b32 v66, v1                                        // 00000055A8A8: D8D80000 42000001
	v_lshrrev_b32_e32 v1, 22, v16                              // 00000055A8B0: 32022096
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000055A8B4: BF870141
	v_and_b32_e32 v1, 0x3fc, v1                                // 00000055A8B8: 360202FF 000003FC
	ds_load_b32 v67, v1                                        // 00000055A8C0: D8D80000 43000001
	.long 0xd73c0001                                           // 00000055A8C8: D73C0001
	v_cndmask_b32_e32 v1, 1, v19, vcc_lo                       // 00000055A8CC: 02022681
	v_dual_mov_b32 v20, v36 :: v_dual_add_nc_u32 v19, 0x400, v19// 00000055A8D0: CA200124 141226FF 00000400
	.long 0xd7006a31                                           // 00000055A8DC: D7006A31
	v_cndmask_b32_e32 v1, s6, v1, vcc_lo                       // 00000055A8E0: 02020206
	s_delay_alu instid0(VALU_DEP_1)                            // 00000055A8E4: BF870001
	v_add_co_ci_u32_e64 v50, null, s7, v2, vcc_lo              // 00000055A8E8: D5207C32 01AA0407
	s_clause 0x3                                               // 00000055A8F0: BF850003
	global_load_b128 v[1:4], v[49:50], off                     // 00000055A8F4: DC5E0000 017C0031
	global_load_b128 v[5:8], v[49:50], off offset:16           // 00000055A8FC: DC5E0010 057C0031
	global_load_b128 v[13:16], v[49:50], off offset:32         // 00000055A904: DC5E0020 0D7C0031
	global_load_b128 v[45:48], v[49:50], off offset:48         // 00000055A90C: DC5E0030 2D7C0031
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 00000055A914: BF890CF7
	v_dot2_f32_bf16 v1, v1, v52, 0                             // 00000055A918: CC1A4001 1A026901
	s_waitcnt lgkmcnt(14)                                      // 00000055A920: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000055A924: BF8700A1
	v_dot2_f32_bf16 v1, v2, v53, v1                            // 00000055A928: CC1A4001 1C066B02
	s_waitcnt lgkmcnt(13)                                      // 00000055A930: BF89FCD7
	v_dot2_f32_bf16 v1, v3, v54, v1                            // 00000055A934: CC1A4001 1C066D03
	s_waitcnt lgkmcnt(12)                                      // 00000055A93C: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000055A940: BF8700A1
	v_dot2_f32_bf16 v1, v4, v55, v1                            // 00000055A944: CC1A4001 1C066F04
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 00000055A94C: BF8908B7
	v_dot2_f32_bf16 v1, v5, v56, v1                            // 00000055A950: CC1A4001 1C067105
	s_waitcnt lgkmcnt(10)                                      // 00000055A958: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000055A95C: BF8700A1
	v_dot2_f32_bf16 v1, v6, v57, v1                            // 00000055A960: CC1A4001 1C067306
	s_waitcnt lgkmcnt(9)                                       // 00000055A968: BF89FC97
	v_dot2_f32_bf16 v1, v7, v58, v1                            // 00000055A96C: CC1A4001 1C067507
	s_waitcnt lgkmcnt(8)                                       // 00000055A974: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000055A978: BF8700A1
	v_dot2_f32_bf16 v1, v8, v59, v1                            // 00000055A97C: CC1A4001 1C067708
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 00000055A984: BF890477
	v_dot2_f32_bf16 v1, v13, v60, v1                           // 00000055A988: CC1A4001 1C06790D
	s_waitcnt lgkmcnt(6)                                       // 00000055A990: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000055A994: BF8700A1
	v_dot2_f32_bf16 v1, v14, v61, v1                           // 00000055A998: CC1A4001 1C067B0E
	s_waitcnt lgkmcnt(5)                                       // 00000055A9A0: BF89FC57
	v_dot2_f32_bf16 v1, v15, v62, v1                           // 00000055A9A4: CC1A4001 1C067D0F
	s_waitcnt lgkmcnt(4)                                       // 00000055A9AC: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000055A9B0: BF8700A1
	v_dot2_f32_bf16 v1, v16, v63, v1                           // 00000055A9B4: CC1A4001 1C067F10
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 00000055A9BC: BF890037
	v_dot2_f32_bf16 v1, v45, v64, v1                           // 00000055A9C0: CC1A4001 1C06812D
	.long 0xd7006a2d                                           // 00000055A9C8: D7006A2D
	v_cndmask_b32_e32 v0, v49, v10, vcc_lo                     // 00000055A9CC: 02001531
	s_waitcnt lgkmcnt(2)                                       // 00000055A9D0: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000055A9D4: BF870132
	v_dot2_f32_bf16 v1, v46, v65, v1                           // 00000055A9D8: CC1A4001 1C06832E
	v_add_co_ci_u32_e64 v46, null, s11, v50, vcc_lo            // 00000055A9E0: D5207C2E 01AA640B
	s_waitcnt lgkmcnt(1)                                       // 00000055A9E8: BF89FC17
	v_dot2_f32_bf16 v1, v47, v66, v1                           // 00000055A9EC: CC1A4001 1C06852F
	s_waitcnt lgkmcnt(0)                                       // 00000055A9F4: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000055A9F8: BF870091
	v_dot2_f32_bf16 v1, v48, v67, v1                           // 00000055A9FC: CC1A4001 1C068730
	v_fmac_f32_e32 v31, v51, v1                                // 00000055AA04: 563E0333
	s_clause 0x3                                               // 00000055AA08: BF850003
	global_load_b128 v[1:4], v[45:46], off                     // 00000055AA0C: DC5E0000 017C002D
	global_load_b128 v[5:8], v[45:46], off offset:16           // 00000055AA14: DC5E0010 057C002D
	global_load_b128 v[13:16], v[45:46], off offset:32         // 00000055AA1C: DC5E0020 0D7C002D
	global_load_b128 v[45:48], v[45:46], off offset:48         // 00000055AA24: DC5E0030 2D7C002D
	s_waitcnt vmcnt(3)                                         // 00000055AA2C: BF890FF7
	v_dot2_f32_bf16 v1, v1, v52, 0                             // 00000055AA30: CC1A4001 1A026901
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000055AA38: BF870091
	v_dot2_f32_bf16 v1, v2, v53, v1                            // 00000055AA3C: CC1A4001 1C066B02
	v_dot2_f32_bf16 v1, v3, v54, v1                            // 00000055AA44: CC1A4001 1C066D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000055AA4C: BF8700A1
	v_dot2_f32_bf16 v1, v4, v55, v1                            // 00000055AA50: CC1A4001 1C066F04
	s_waitcnt vmcnt(2)                                         // 00000055AA58: BF890BF7
	v_dot2_f32_bf16 v1, v5, v56, v1                            // 00000055AA5C: CC1A4001 1C067105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000055AA64: BF870091
	v_dot2_f32_bf16 v1, v6, v57, v1                            // 00000055AA68: CC1A4001 1C067306
	v_dot2_f32_bf16 v1, v7, v58, v1                            // 00000055AA70: CC1A4001 1C067507
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000055AA78: BF8700A1
	v_dot2_f32_bf16 v1, v8, v59, v1                            // 00000055AA7C: CC1A4001 1C067708
	s_waitcnt vmcnt(1)                                         // 00000055AA84: BF8907F7
	v_dot2_f32_bf16 v1, v13, v60, v1                           // 00000055AA88: CC1A4001 1C06790D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000055AA90: BF870091
	v_dot2_f32_bf16 v1, v14, v61, v1                           // 00000055AA94: CC1A4001 1C067B0E
	v_dot2_f32_bf16 v1, v15, v62, v1                           // 00000055AA9C: CC1A4001 1C067D0F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000055AAA4: BF8700A1
	v_dot2_f32_bf16 v1, v16, v63, v1                           // 00000055AAA8: CC1A4001 1C067F10
	s_waitcnt vmcnt(0)                                         // 00000055AAB0: BF8903F7
	v_dot2_f32_bf16 v1, v45, v64, v1                           // 00000055AAB4: CC1A4001 1C06812D
	.long 0xd7006a2d                                           // 00000055AABC: D7006A2D
	v_cndmask_b32_e32 v0, v49, v4, vcc_lo                      // 00000055AAC0: 02000931
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000055AAC4: BF870122
	v_dot2_f32_bf16 v1, v46, v65, v1                           // 00000055AAC8: CC1A4001 1C06832E
	v_add_co_ci_u32_e64 v46, null, s5, v50, vcc_lo             // 00000055AAD0: D5207C2E 01AA6405
	v_dot2_f32_bf16 v1, v47, v66, v1                           // 00000055AAD8: CC1A4001 1C06852F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000055AAE0: BF870091
	v_dot2_f32_bf16 v1, v48, v67, v1                           // 00000055AAE4: CC1A4001 1C068730
	v_fmac_f32_e32 v33, v51, v1                                // 00000055AAEC: 56420333
	s_clause 0x3                                               // 00000055AAF0: BF850003
	global_load_b128 v[1:4], v[45:46], off                     // 00000055AAF4: DC5E0000 017C002D
	global_load_b128 v[5:8], v[45:46], off offset:16           // 00000055AAFC: DC5E0010 057C002D
	global_load_b128 v[13:16], v[45:46], off offset:32         // 00000055AB04: DC5E0020 0D7C002D
	global_load_b128 v[45:48], v[45:46], off offset:48         // 00000055AB0C: DC5E0030 2D7C002D
	s_waitcnt vmcnt(3)                                         // 00000055AB14: BF890FF7
	v_dot2_f32_bf16 v1, v1, v52, 0                             // 00000055AB18: CC1A4001 1A026901
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000055AB20: BF870091
	v_dot2_f32_bf16 v1, v2, v53, v1                            // 00000055AB24: CC1A4001 1C066B02
	v_dot2_f32_bf16 v1, v3, v54, v1                            // 00000055AB2C: CC1A4001 1C066D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000055AB34: BF8700A1
	v_dot2_f32_bf16 v1, v4, v55, v1                            // 00000055AB38: CC1A4001 1C066F04
	s_waitcnt vmcnt(2)                                         // 00000055AB40: BF890BF7
	v_dot2_f32_bf16 v1, v5, v56, v1                            // 00000055AB44: CC1A4001 1C067105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000055AB4C: BF870091
	v_dot2_f32_bf16 v1, v6, v57, v1                            // 00000055AB50: CC1A4001 1C067306
	v_dot2_f32_bf16 v1, v7, v58, v1                            // 00000055AB58: CC1A4001 1C067507
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000055AB60: BF8700A1
	v_dot2_f32_bf16 v1, v8, v59, v1                            // 00000055AB64: CC1A4001 1C067708
	s_waitcnt vmcnt(1)                                         // 00000055AB6C: BF8907F7
	v_dot2_f32_bf16 v1, v13, v60, v1                           // 00000055AB70: CC1A4001 1C06790D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000055AB78: BF870091
	v_dot2_f32_bf16 v1, v14, v61, v1                           // 00000055AB7C: CC1A4001 1C067B0E
	v_dot2_f32_bf16 v1, v15, v62, v1                           // 00000055AB84: CC1A4001 1C067D0F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000055AB8C: BF8700A1
	v_dot2_f32_bf16 v1, v16, v63, v1                           // 00000055AB90: CC1A4001 1C067F10
	s_waitcnt vmcnt(0)                                         // 00000055AB98: BF8903F7
	v_dot2_f32_bf16 v1, v45, v64, v1                           // 00000055AB9C: CC1A4001 1C06812D
	.long 0xd7006a2d                                           // 00000055ABA4: D7006A2D
	v_cndmask_b32_e32 v0, v49, v17, vcc_lo                     // 00000055ABA8: 02002331
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000055ABAC: BF870122
	v_dot2_f32_bf16 v1, v46, v65, v1                           // 00000055ABB0: CC1A4001 1C06832E
	v_add_co_ci_u32_e64 v46, null, s15, v50, vcc_lo            // 00000055ABB8: D5207C2E 01AA640F
	v_dot2_f32_bf16 v1, v47, v66, v1                           // 00000055ABC0: CC1A4001 1C06852F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000055ABC8: BF870091
	v_dot2_f32_bf16 v1, v48, v67, v1                           // 00000055ABCC: CC1A4001 1C068730
	v_fmac_f32_e32 v32, v51, v1                                // 00000055ABD4: 56400333
	s_clause 0x3                                               // 00000055ABD8: BF850003
	global_load_b128 v[1:4], v[45:46], off                     // 00000055ABDC: DC5E0000 017C002D
	global_load_b128 v[5:8], v[45:46], off offset:16           // 00000055ABE4: DC5E0010 057C002D
	global_load_b128 v[13:16], v[45:46], off offset:32         // 00000055ABEC: DC5E0020 0D7C002D
	global_load_b128 v[45:48], v[45:46], off offset:48         // 00000055ABF4: DC5E0030 2D7C002D
	s_waitcnt vmcnt(3)                                         // 00000055ABFC: BF890FF7
	v_dot2_f32_bf16 v1, v1, v52, 0                             // 00000055AC00: CC1A4001 1A026901
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000055AC08: BF870091
	v_dot2_f32_bf16 v1, v2, v53, v1                            // 00000055AC0C: CC1A4001 1C066B02
	v_dot2_f32_bf16 v1, v3, v54, v1                            // 00000055AC14: CC1A4001 1C066D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000055AC1C: BF8700A1
	v_dot2_f32_bf16 v1, v4, v55, v1                            // 00000055AC20: CC1A4001 1C066F04
	s_waitcnt vmcnt(2)                                         // 00000055AC28: BF890BF7
	v_dot2_f32_bf16 v1, v5, v56, v1                            // 00000055AC2C: CC1A4001 1C067105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000055AC34: BF870091
	v_dot2_f32_bf16 v1, v6, v57, v1                            // 00000055AC38: CC1A4001 1C067306
	v_dot2_f32_bf16 v1, v7, v58, v1                            // 00000055AC40: CC1A4001 1C067507
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000055AC48: BF8700A1
	v_dot2_f32_bf16 v1, v8, v59, v1                            // 00000055AC4C: CC1A4001 1C067708
	s_waitcnt vmcnt(1)                                         // 00000055AC54: BF8907F7
	v_dot2_f32_bf16 v1, v13, v60, v1                           // 00000055AC58: CC1A4001 1C06790D
	v_mov_b32_e32 v13, v9                                      // 00000055AC60: 7E1A0309
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000055AC64: BF870122
	v_dot2_f32_bf16 v1, v14, v61, v1                           // 00000055AC68: CC1A4001 1C067B0E
	v_mov_b32_e32 v14, v10                                     // 00000055AC70: 7E1C030A
	v_dot2_f32_bf16 v1, v15, v62, v1                           // 00000055AC74: CC1A4001 1C067D0F
	v_mov_b32_e32 v15, v11                                     // 00000055AC7C: 7E1E030B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000055AC80: BF870132
	v_dot2_f32_bf16 v1, v16, v63, v1                           // 00000055AC84: CC1A4001 1C067F10
	v_mov_b32_e32 v16, v12                                     // 00000055AC8C: 7E20030C
	s_waitcnt vmcnt(0)                                         // 00000055AC90: BF8903F7
	v_dot2_f32_bf16 v1, v45, v64, v1                           // 00000055AC94: CC1A4001 1C06812D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000055AC9C: BF870091
	v_dot2_f32_bf16 v1, v46, v65, v1                           // 00000055ACA0: CC1A4001 1C06832E
	v_dot2_f32_bf16 v1, v47, v66, v1                           // 00000055ACA8: CC1A4001 1C06852F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000055ACB0: BF870091
	v_dot2_f32_bf16 v1, v48, v67, v1                           // 00000055ACB4: CC1A4001 1C068730
	v_dual_fmac_f32 v28, v51, v1 :: v_dual_mov_b32 v1, v37     // 00000055ACBC: C8100333 1C000125
	v_dual_mov_b32 v2, v38 :: v_dual_mov_b32 v3, v39           // 00000055ACC4: CA100126 02020127
	v_dual_mov_b32 v4, v40 :: v_dual_mov_b32 v5, v41           // 00000055ACCC: CA100128 04040129
	v_dual_mov_b32 v6, v42 :: v_dual_mov_b32 v7, v43           // 00000055ACD4: CA10012A 0606012B
	v_mov_b32_e32 v8, v44                                      // 00000055ACDC: 7E10032C
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 00000055ACE0: 917E107E
	s_cbranch_execz 35                                         // 00000055ACE4: BFA50023 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xb74>
	s_waitcnt vmcnt(0)                                         // 00000055ACE8: BF8903F7
	v_dual_mov_b32 v10, v14 :: v_dual_add_nc_u32 v25, 32, v25  // 00000055ACEC: CA20010E 0A1832A0
	v_dual_mov_b32 v9, v13 :: v_dual_mov_b32 v12, v16          // 00000055ACF4: CA10010D 090C0110
	v_mov_b32_e32 v11, v15                                     // 00000055ACFC: 7E16030F
	s_delay_alu instid0(VALU_DEP_3)                            // 00000055AD00: BF870003
	.long 0xd4460001                                           // 00000055AD04: D4460001
	v_cndmask_b32_e32 v1, v25, v26, vcc_lo                     // 00000055AD08: 02023519
	s_mov_b32 s18, exec_lo                                     // 00000055AD0C: BE92007E
	.long 0xd4c1007e                                           // 00000055AD10: D4C1007E
	v_cndmask_b32_e32 v1, v25, v26, vcc_lo                     // 00000055AD14: 02023519
	s_cbranch_execz 65147                                      // 00000055AD18: BFA5FE7B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x508>
	v_ashrrev_i32_e32 v10, 31, v34                             // 00000055AD1C: 3414449F
	.long 0xd7006a09                                           // 00000055AD20: D7006A09
	v_cndmask_b32_e32 v1, v18, v34, vcc_lo                     // 00000055AD24: 02024512
	v_mov_b32_e32 v36, v20                                     // 00000055AD28: 7E480314
	s_delay_alu instid0(VALU_DEP_3)                            // 00000055AD2C: BF870003
	v_add_co_ci_u32_e64 v10, null, v30, v10, vcc_lo            // 00000055AD30: D5207C0A 01AA151E
	v_cmp_ne_u32_e32 vcc_lo, 1, v29                            // 00000055AD38: 7C9A3A81
	global_load_b128 v[9:12], v[9:10], off                     // 00000055AD3C: DC5E0000 097C0009
	s_cbranch_vccnz 65136                                      // 00000055AD44: BFA4FE70 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x508>
	v_ashrrev_i32_e32 v37, 31, v35                             // 00000055AD48: 344A469F
	.long 0xd7006a24                                           // 00000055AD4C: D7006A24
	v_cndmask_b32_e32 v1, v17, v35, vcc_lo                     // 00000055AD50: 02024711
	s_delay_alu instid0(VALU_DEP_1)                            // 00000055AD54: BF870001
	v_add_co_ci_u32_e64 v37, null, v27, v37, vcc_lo            // 00000055AD58: D5207C25 01AA4B1B
	global_load_d16_b16 v36, v[36:37], off                     // 00000055AD60: DC820000 247C0024
	s_waitcnt vmcnt(0)                                         // 00000055AD68: BF8903F7
	v_cvt_f32_f16_e32 v36, v36                                 // 00000055AD6C: 7E481724
	s_branch 65125                                             // 00000055AD70: BFA0FE65 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x508>
	s_or_b32 exec_lo, exec_lo, s16                             // 00000055AD74: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000055AD78: BF8700B9
	s_or_b32 exec_lo, exec_lo, s14                             // 00000055AD7C: 8C7E0E7E
	.long 0xd71f0001                                           // 00000055AD80: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000055AD84: 020100C1
	s_mov_b32 s0, exec_lo                                      // 00000055AD88: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 00000055AD8C: 3A040290
	v_xor_b32_e32 v6, 8, v1                                    // 00000055AD90: 3A0C0288
	v_xor_b32_e32 v10, 4, v1                                   // 00000055AD94: 3A140284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000055AD98: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 00000055AD9C: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 00000055ADA0: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 00000055ADA4: 7C980CA0
	s_delay_alu instid0(VALU_DEP_2)                            // 00000055ADA8: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 00000055ADAC: 30040482
	ds_bpermute_b32 v5, v2, v32                                // 00000055ADB0: DACC0000 05002002
	s_waitcnt lgkmcnt(0)                                       // 00000055ADB8: BF89FC07
	v_add_f32_e32 v5, v32, v5                                  // 00000055ADBC: 060A0B20
	ds_bpermute_b32 v3, v2, v31                                // 00000055ADC0: DACC0000 03001F02
	ds_bpermute_b32 v4, v2, v33                                // 00000055ADC8: DACC0000 04002102
	ds_bpermute_b32 v2, v2, v28                                // 00000055ADD0: DACC0000 02001C02
	s_waitcnt lgkmcnt(2)                                       // 00000055ADD8: BF89FC27
	v_dual_add_f32 v3, v31, v3 :: v_dual_cndmask_b32 v6, v1, v6// 00000055ADDC: C912071F 03060D01
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 00000055ADE4: 7C9814A0
	s_delay_alu instid0(VALU_DEP_2)                            // 00000055ADE8: BF870002
	v_lshlrev_b32_e32 v6, 2, v6                                // 00000055ADEC: 300C0C82
	v_cndmask_b32_e32 v10, v1, v10, vcc_lo                     // 00000055ADF0: 02141501
	ds_bpermute_b32 v9, v6, v5                                 // 00000055ADF4: DACC0000 09000506
	s_waitcnt lgkmcnt(0)                                       // 00000055ADFC: BF89FC07
	v_dual_add_f32 v5, v5, v9 :: v_dual_lshlrev_b32 v10, 2, v10// 00000055AE00: C9221305 050A1482
	ds_bpermute_b32 v7, v6, v3                                 // 00000055AE08: DACC0000 07000306
	s_waitcnt lgkmcnt(0)                                       // 00000055AE10: BF89FC07
	v_dual_add_f32 v2, v28, v2 :: v_dual_add_f32 v3, v3, v7    // 00000055AE14: C908051C 02020F03
	v_add_f32_e32 v4, v33, v4                                  // 00000055AE1C: 06080921
	ds_bpermute_b32 v8, v6, v4                                 // 00000055AE20: DACC0000 08000406
	ds_bpermute_b32 v6, v6, v2                                 // 00000055AE28: DACC0000 06000206
	s_waitcnt lgkmcnt(0)                                       // 00000055AE30: BF89FC07
	v_add_f32_e32 v2, v2, v6                                   // 00000055AE34: 06040D02
	ds_bpermute_b32 v6, v10, v3                                // 00000055AE38: DACC0000 0600030A
	ds_bpermute_b32 v9, v10, v2                                // 00000055AE40: DACC0000 0900020A
	s_waitcnt lgkmcnt(1)                                       // 00000055AE48: BF89FC17
	v_dual_add_f32 v3, v3, v6 :: v_dual_add_f32 v4, v4, v8     // 00000055AE4C: C9080D03 03041104
	ds_bpermute_b32 v8, v10, v5                                // 00000055AE54: DACC0000 0800050A
	s_waitcnt lgkmcnt(1)                                       // 00000055AE5C: BF89FC17
	v_add_f32_e32 v6, v2, v9                                   // 00000055AE60: 060C1302
	ds_bpermute_b32 v7, v10, v4                                // 00000055AE64: DACC0000 0700040A
	v_xor_b32_e32 v10, 2, v1                                   // 00000055AE6C: 3A140282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000055AE70: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 00000055AE74: 7C9814A0
	v_cndmask_b32_e32 v10, v1, v10, vcc_lo                     // 00000055AE78: 02141501
	s_waitcnt lgkmcnt(1)                                       // 00000055AE7C: BF89FC17
	v_dual_add_f32 v5, v5, v8 :: v_dual_lshlrev_b32 v10, 2, v10// 00000055AE80: C9221105 050A1482
	ds_bpermute_b32 v2, v10, v3                                // 00000055AE88: DACC0000 0200030A
	s_waitcnt lgkmcnt(1)                                       // 00000055AE90: BF89FC17
	v_add_f32_e32 v4, v4, v7                                   // 00000055AE94: 06080F04
	ds_bpermute_b32 v8, v10, v5                                // 00000055AE98: DACC0000 0800050A
	ds_bpermute_b32 v9, v10, v6                                // 00000055AEA0: DACC0000 0900060A
	ds_bpermute_b32 v7, v10, v4                                // 00000055AEA8: DACC0000 0700040A
	v_xor_b32_e32 v10, 1, v1                                   // 00000055AEB0: 3A140281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000055AEB4: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 00000055AEB8: 7C9814A0
	v_cndmask_b32_e32 v1, v1, v10, vcc_lo                      // 00000055AEBC: 02021501
	s_waitcnt lgkmcnt(3)                                       // 00000055AEC0: BF89FC37
	v_dual_add_f32 v1, v3, v2 :: v_dual_lshlrev_b32 v10, 2, v1 // 00000055AEC4: C9220503 010A0282
	s_waitcnt lgkmcnt(2)                                       // 00000055AECC: BF89FC27
	v_add_f32_e32 v3, v5, v8                                   // 00000055AED0: 06061105
	s_waitcnt lgkmcnt(0)                                       // 00000055AED4: BF89FC07
	v_dual_add_f32 v5, v6, v9 :: v_dual_add_f32 v2, v4, v7     // 00000055AED8: C9081306 05020F04
	ds_bpermute_b32 v4, v10, v1                                // 00000055AEE0: DACC0000 0400010A
	ds_bpermute_b32 v7, v10, v3                                // 00000055AEE8: DACC0000 0700030A
	ds_bpermute_b32 v8, v10, v5                                // 00000055AEF0: DACC0000 0800050A
	ds_bpermute_b32 v6, v10, v2                                // 00000055AEF8: DACC0000 0600020A
	v_cmpx_eq_u32_e32 0, v24                                   // 00000055AF00: 7D943080
	s_cbranch_execz 12                                         // 00000055AF04: BFA5000C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xd38>
	s_waitcnt lgkmcnt(1)                                       // 00000055AF08: BF89FC17
	v_dual_add_f32 v8, v5, v8 :: v_dual_lshlrev_b32 v9, 4, v23 // 00000055AF0C: C9221105 08082E84
	s_waitcnt lgkmcnt(0)                                       // 00000055AF14: BF89FC07
	v_dual_add_f32 v7, v3, v7 :: v_dual_add_f32 v6, v2, v6     // 00000055AF18: C9080F03 07060D02
	v_add_f32_e32 v5, v1, v4                                   // 00000055AF20: 060A0901
	s_delay_alu instid0(VALU_DEP_3)                            // 00000055AF24: BF870003
	v_lshl_or_b32 v1, v22, 5, v9                               // 00000055AF28: D6560001 04250B16
	ds_store_b128 v1, v[5:8] offset:1024                       // 00000055AF30: DB7C0400 00000501
	s_or_b32 exec_lo, exec_lo, s0                              // 00000055AF38: 8C7E007E
	v_or_b32_e32 v1, s2, v21                                   // 00000055AF3C: 38022A02
	v_mov_b32_e32 v2, s3                                       // 00000055AF40: 7E040203
	.long 0xd44c0000                                           // 00000055AF44: D44C0000
	v_cndmask_b32_e32 v1, 16, v0, vcc_lo                       // 00000055AF48: 02020090
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000055AF4C: BF890007
	s_barrier                                                  // 00000055AF50: BFBD0000
	buffer_gl0_inv                                             // 00000055AF54: E0AC0000 00000000
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 00000055AF5C: 7CA8020C
	s_and_b32 s0, s0, vcc_lo                                   // 00000055AF60: 8B006A00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000055AF64: BF870009
	s_and_saveexec_b32 s1, s0                                  // 00000055AF68: BE812000
	s_cbranch_execz 40                                         // 00000055AF6C: BFA50028 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xe10>
	v_and_b32_e32 v0, 3, v0                                    // 00000055AF70: 36000083
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000055AF74: BF870091
	v_lshlrev_b32_e32 v3, 2, v0                                // 00000055AF78: 30060082
	v_lshl_or_b32 v3, v21, 5, v3                               // 00000055AF7C: D6560003 040D0B15
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000055AF84: BF8700B1
	v_add_nc_u32_e32 v3, 0x400, v3                             // 00000055AF88: 4A0606FF 00000400
	ds_load_2addr_b32 v[6:7], v3 offset1:4                     // 00000055AF90: D8DC0400 06000003
	v_mad_u64_u32 v[3:4], null, s12, v0, 0                     // 00000055AF98: D6FE7C03 0202000C
	v_mad_u64_u32 v[4:5], null, s13, v0, v[4:5]                // 00000055AFA0: D6FE7C04 0412000D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000055AFA8: BF870131
	.long 0xd73c0003                                           // 00000055AFAC: D73C0003
	v_cndmask_b32_e32 v1, 1, v3, vcc_lo                        // 00000055AFB0: 02020681
	s_waitcnt lgkmcnt(0)                                       // 00000055AFB4: BF89FC07
	v_add_f32_e32 v0, 0, v6                                    // 00000055AFB8: 06000C80
	.long 0xd7006a03                                           // 00000055AFBC: D7006A03
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 00000055AFC0: 02020608
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000055AFC4: BF8701B2
	v_add_f32_e32 v5, v0, v7                                   // 00000055AFC8: 060A0F00
	.long 0xd73c0000                                           // 00000055AFCC: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000055AFD0: 02020281
	v_add_co_ci_u32_e64 v4, null, s9, v4, vcc_lo               // 00000055AFD4: D5207C04 01AA0809
	v_bfe_u32 v2, v5, 16, 1                                    // 00000055AFDC: D6100002 02052105
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000055AFE4: BF870093
	.long 0xd7006a00                                           // 00000055AFE8: D7006A00
	v_cndmask_b32_e32 v1, v3, v0, vcc_lo                       // 00000055AFEC: 02020103
	v_add_co_ci_u32_e64 v1, null, v4, v1, vcc_lo               // 00000055AFF0: D5207C01 01AA0304
	s_delay_alu instid0(VALU_DEP_3)                            // 00000055AFF8: BF870003
	v_add3_u32 v2, v5, v2, 0x7fff                              // 00000055AFFC: D6550002 03FE0505 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off                    // 00000055B008: DC960000 007C0200
	s_endpgm                                                   // 00000055B010: BFB00000
		...

