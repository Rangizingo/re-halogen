000000000070e900 <_ZN7halogen12_GLOBAL__N_16k_lq6kILi2ELi32ELi2ELb1EEEvPKhPKtPvll>:
; _ZN7halogen12_GLOBAL__N_16k_lq6kILi2ELi32ELi2ELb1EEEvPKhPKtPvll():
	s_load_b256 s[4:11], s[0:1], null                          // 00000070E900: F40C0100 F8000000
	s_mov_b32 s3, 0                                            // 00000070E908: BE830080
	v_bfe_u32 v5, v0, 5, 1                                     // 00000070E90C: D6100005 02050B00
	s_lshl_b64 s[14:15], s[2:3], 2                             // 00000070E914: 848E8202
	v_dual_mov_b32 v10, 0 :: v_dual_and_b32 v7, 31, v0         // 00000070E918: CA240080 0A06009F
	v_lshrrev_b32_e32 v6, 6, v0                                // 00000070E920: 320C0086
	v_mov_b32_e32 v11, 0                                       // 00000070E924: 7E160280
	s_waitcnt lgkmcnt(0)                                       // 00000070E928: BF89FC07
	s_ashr_i32 s12, s11, 31                                    // 00000070E92C: 860C9F0B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000070E930: BF870499
	s_lshr_b32 s12, s12, 28                                    // 00000070E934: 850C9C0C
	s_add_u32 s12, s10, s12                                    // 00000070E938: 800C0C0A
	s_addc_u32 s13, s11, 0                                     // 00000070E93C: 820D800B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000070E940: BF870499
	s_lshr_b64 s[16:17], s[12:13], 4                           // 00000070E944: 8590840C
	s_add_i32 s2, s16, 1                                       // 00000070E948: 81028110
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000070E94C: BF870499
	s_lshr_b32 s12, s2, 31                                     // 00000070E950: 850C9F02
	s_add_i32 s2, s2, s12                                      // 00000070E954: 81020C02
	s_load_b64 s[12:13], s[0:1], 0x20                          // 00000070E958: F4040300 F8000020
	s_ashr_i32 s2, s2, 1                                       // 00000070E960: 86028102
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000070E964: BF870099
	.long 0xd72c0001                                           // 00000070E968: D72C0001
	v_cndmask_b32_e32 v1, s2, v5, vcc_lo                       // 00000070E96C: 02020A02
	v_add_nc_u32_e32 v2, s2, v1                                // 00000070E970: 4A040202
	v_add_nc_u32_e32 v8, v1, v7                                // 00000070E974: 4A100F01
	s_mov_b32 s2, exec_lo                                      // 00000070E978: BE82007E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000070E97C: BF870092
	v_min_i32_e32 v9, s16, v2                                  // 00000070E980: 22120410
	.long 0xd4c1007e                                           // 00000070E984: D4C1007E
	v_cndmask_b32_e32 v1, v8, v9, vcc_lo                       // 00000070E988: 02021308
	s_cbranch_execz 404                                        // 00000070E98C: BFA50194 <_ZN7halogen12_GLOBAL__N_16k_lq6kILi2ELi32ELi2ELb1EEEvPKhPKtPvll+0x6e0>
	.long 0xd7000001                                           // 00000070E990: D7000001
	v_cndmask_b32_e32 v1, s14, v6, vcc_lo                      // 00000070E994: 02020C0E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000070E998: BF870001
	v_add_co_ci_u32_e64 v2, null, s15, 0, s0                   // 00000070E99C: D5207C02 0001000F
	s_ashr_i32 s0, s11, 31                                     // 00000070E9A4: 86009F0B
	v_dual_mov_b32 v10, 0 :: v_dual_lshlrev_b32 v3, 4, v8      // 00000070E9A8: CA220080 0A021084
	s_lshr_b32 s0, s0, 24                                      // 00000070E9B0: 85009800
	s_waitcnt lgkmcnt(0)                                       // 00000070E9B4: BF89FC07
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 00000070E9B8: 7CA8020C
	s_add_u32 s0, s10, s0                                      // 00000070E9BC: 8000000A
	s_addc_u32 s1, s11, 0                                      // 00000070E9C0: 8201800B
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000070E9C4: BF870009
	s_ashr_i64 s[0:1], s[0:1], 8                               // 00000070E9C8: 86808800
	v_dual_cndmask_b32 v2, 0, v2 :: v_dual_cndmask_b32 v1, 0, v1// 00000070E9CC: CA520480 02000280
	s_mulk_i32 s1, 0xd2                                        // 00000070E9D4: B80100D2
	s_mul_hi_u32 s16, s0, 0xd2                                 // 00000070E9D8: 9690FF00 000000D2
	s_mulk_i32 s0, 0xd2                                        // 00000070E9E0: B80000D2
	s_add_i32 s16, s16, s1                                     // 00000070E9E4: 81100110
	.long 0xd72c000b                                           // 00000070E9E8: D72C000B
	v_cndmask_b32_e32 v1, s0, v2, vcc_lo                       // 00000070E9EC: 02020400
	.long 0xd72c0004                                           // 00000070E9F0: D72C0004
	v_cndmask_b32_e32 v1, s16, v1, vcc_lo                      // 00000070E9F4: 02020210
	v_mad_u64_u32 v[1:2], null, s0, v1, s[4:5]                 // 00000070E9F8: D6FE7C01 00120200
	s_lshl_b64 s[4:5], s[10:11], 1                             // 00000070EA00: 8484810A
	v_add3_u32 v2, v4, v2, v11                                 // 00000070EA04: D6550002 042E0504
	v_mov_b32_e32 v11, 0                                       // 00000070EA0C: 7E160280
	v_ashrrev_i32_e32 v4, 4, v8                                // 00000070EA10: 34081084
	v_bfe_u32 v13, v8, 3, 1                                    // 00000070EA14: D610000D 02050708
	v_and_b32_e32 v14, 32, v3                                  // 00000070EA1C: 361C06A0
	v_and_b32_e32 v12, 15, v8                                  // 00000070EA20: 3618108F
	v_and_b32_e32 v16, 16, v3                                  // 00000070EA24: 36200690
	.long 0xd72c0004                                           // 00000070EA28: D72C0004
	v_cndmask_b32_e32 v1, 0xd2, v4, vcc_lo                     // 00000070EA2C: 020208FF 000000D2
	v_lshlrev_b32_e32 v15, 6, v13                              // 00000070EA34: 301E1A86
	v_lshlrev_b32_e32 v13, 5, v13                              // 00000070EA38: 301A1A85
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000070EA3C: BF8700A3
	v_ashrrev_i32_e32 v17, 31, v4                              // 00000070EA40: 3422089F
	.long 0xd7006a14                                           // 00000070EA44: D7006A14
	v_cndmask_b32_e32 v1, v1, v4, vcc_lo                       // 00000070EA48: 02020901
	v_add_co_ci_u32_e64 v21, null, v2, v17, vcc_lo             // 00000070EA4C: D5207C15 01AA2302
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000070EA54: BF8701A2
	.long 0xd7006a04                                           // 00000070EA58: D7006A04
	v_cndmask_b32_e32 v1, v20, v15, vcc_lo                     // 00000070EA5C: 02021F14
	.long 0xd700000f                                           // 00000070EA60: D700000F
	v_cndmask_b32_e32 v1, v20, v13, vcc_lo                     // 00000070EA64: 02021B14
	v_add_co_ci_u32_e64 v17, null, 0, v21, vcc_lo              // 00000070EA68: D5207C11 01AA2A80
	v_add_co_ci_u32_e64 v18, null, 0, v21, s0                  // 00000070EA70: D5207C12 00022A80
	s_delay_alu instid0(VALU_DEP_4)                            // 00000070EA78: BF870004
	.long 0xd7006a04                                           // 00000070EA7C: D7006A04
	v_cndmask_b32_e32 v1, v4, v14, vcc_lo                      // 00000070EA80: 02021D04
	.long 0xd700010c                                           // 00000070EA84: D700010C
	v_cndmask_b32_e32 v1, v20, v12, vcc_lo                     // 00000070EA88: 02021914
	.long 0xd700000e                                           // 00000070EA8C: D700000E
	v_cndmask_b32_e32 v1, v15, v16, vcc_lo                     // 00000070EA90: 0202210F
	v_add_co_ci_u32_e64 v17, null, 0, v17, vcc_lo              // 00000070EA94: D5207C11 01AA2280
	v_add_co_ci_u32_e64 v13, null, 0, v21, s1                  // 00000070EA9C: D5207C0D 00062A80
	v_add_co_ci_u32_e64 v15, null, 0, v18, s0                  // 00000070EAA4: D5207C0F 00022480
	.long 0xd7006a10                                           // 00000070EAAC: D7006A10
	v_cndmask_b32_e32 v1, v4, v16, vcc_lo                      // 00000070EAB0: 02022104
	s_delay_alu instid0(VALU_DEP_1)                            // 00000070EAB4: BF870001
	v_add_co_ci_u32_e64 v17, null, 0, v17, vcc_lo              // 00000070EAB8: D5207C11 01AA2280
	s_clause 0x3                                               // 00000070EAC0: BF850003
	global_load_i8 v36, v[12:13], off offset:192               // 00000070EAC4: DC4600C0 247C000C
	global_load_b128 v[12:15], v[14:15], off offset:128        // 00000070EACC: DC5E0080 0C7C000E
	global_load_b128 v[16:19], v[16:17], off                   // 00000070EAD4: DC5E0000 107C0010
	global_load_d16_b16 v37, v[20:21], off offset:208          // 00000070EADC: DC8200D0 257C0014
	v_ashrrev_i32_e32 v4, 31, v3                               // 00000070EAE4: 3408069F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000070EAE8: BF870091
	.long 0xd73c0014                                           // 00000070EAEC: D73C0014
	v_cndmask_b32_e32 v1, 1, v3, vcc_lo                        // 00000070EAF0: 02020681
	.long 0xd7006a1c                                           // 00000070EAF4: D7006A1C
	v_cndmask_b32_e32 v1, s6, v20, vcc_lo                      // 00000070EAF8: 02022806
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000070EAFC: BF870111
	v_add_co_ci_u32_e64 v29, null, s7, v21, vcc_lo             // 00000070EB00: D5207C1D 01AA2A07
	.long 0xd7006a20                                           // 00000070EB08: D7006A20
	v_cndmask_b32_e32 v0, v28, v4, vcc_lo                      // 00000070EB0C: 0200091C
	s_delay_alu instid0(VALU_DEP_1)                            // 00000070EB10: BF870001
	v_add_co_ci_u32_e64 v33, null, s5, v29, vcc_lo             // 00000070EB14: D5207C21 01AA3A05
	s_clause 0x3                                               // 00000070EB1C: BF850003
	global_load_b128 v[20:23], v[28:29], off                   // 00000070EB20: DC5E0000 147C001C
	global_load_b128 v[24:27], v[32:33], off                   // 00000070EB28: DC5E0000 187C0020
	global_load_b128 v[28:31], v[28:29], off offset:16         // 00000070EB30: DC5E0010 1C7C001C
	global_load_b128 v[32:35], v[32:33], off offset:16         // 00000070EB38: DC5E0010 207C0020
	s_waitcnt vmcnt(7)                                         // 00000070EB40: BF891FF7
	v_cvt_f32_i32_e32 v36, v36                                 // 00000070EB44: 7E480B24
	s_waitcnt vmcnt(4)                                         // 00000070EB48: BF8913F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000070EB4C: BF8701C1
	v_fma_mix_f32 v36, v37, v36, neg(0) op_sel_hi:[1,0,0]      // 00000070EB50: CC200024 8A024925
	v_and_b32_e32 v38, 6, v8                                   // 00000070EB58: 364C1086
	v_and_b32_e32 v4, 4, v8                                    // 00000070EB5C: 36081084
	v_add_nc_u32_e32 v8, 32, v8                                // 00000070EB60: 4A1010A0
	v_or_b32_e32 v42, 16, v38                                  // 00000070EB64: 38544C90
	v_or_b32_e32 v40, 8, v38                                   // 00000070EB68: 38504C88
	s_delay_alu instid0(VALU_DEP_4)                            // 00000070EB6C: BF870004
	v_or_b32_e32 v41, 16, v4                                   // 00000070EB70: 38520890
	v_or_b32_e32 v44, 24, v38                                  // 00000070EB74: 38584C98
	v_lshrrev_b32_e32 v45, v38, v12                            // 00000070EB78: 325A1926
	v_lshrrev_b32_e32 v47, v42, v12                            // 00000070EB7C: 325E192A
	v_or_b32_e32 v39, 8, v4                                    // 00000070EB80: 384E0888
	v_or_b32_e32 v43, 24, v4                                   // 00000070EB84: 38560898
	v_lshrrev_b32_e32 v46, v40, v12                            // 00000070EB88: 325C1928
	v_lshrrev_b32_e32 v12, v44, v12                            // 00000070EB8C: 3218192C
	v_lshrrev_b32_e32 v48, v38, v13                            // 00000070EB90: 32601B26
	v_lshrrev_b32_e32 v49, v40, v13                            // 00000070EB94: 32621B28
	v_lshrrev_b32_e32 v50, v42, v13                            // 00000070EB98: 32641B2A
	v_lshrrev_b32_e32 v13, v44, v13                            // 00000070EB9C: 321A1B2C
	v_lshrrev_b32_e32 v51, v38, v14                            // 00000070EBA0: 32661D26
	v_lshrrev_b32_e32 v52, v40, v14                            // 00000070EBA4: 32681D28
	v_lshrrev_b32_e32 v53, v42, v14                            // 00000070EBA8: 326A1D2A
	v_lshrrev_b32_e32 v14, v44, v14                            // 00000070EBAC: 321C1D2C
	v_lshrrev_b32_e32 v38, v38, v15                            // 00000070EBB0: 324C1F26
	v_lshrrev_b32_e32 v40, v40, v15                            // 00000070EBB4: 32501F28
	v_lshrrev_b32_e32 v42, v42, v15                            // 00000070EBB8: 32541F2A
	v_lshrrev_b32_e32 v15, v44, v15                            // 00000070EBBC: 321E1F2C
	v_bfe_u32 v37, v16, v4, 4                                  // 00000070EBC0: D6100025 02120910
	v_lshlrev_b32_e32 v44, 4, v45                              // 00000070EBC8: 30585A84
	v_bfe_u32 v54, v16, v41, 4                                 // 00000070EBCC: D6100036 02125310
	v_lshlrev_b32_e32 v47, 4, v47                              // 00000070EBD4: 305E5E84
	v_bfe_u32 v45, v16, v39, 4                                 // 00000070EBD8: D610002D 02124F10
	v_bfe_u32 v56, v17, v39, 4                                 // 00000070EBE0: D6100038 02124F11
	v_bfe_u32 v58, v18, v4, 4                                  // 00000070EBE8: D610003A 02120912
	v_bfe_u32 v59, v18, v39, 4                                 // 00000070EBF0: D610003B 02124F12
	v_bfe_u32 v60, v18, v41, 4                                 // 00000070EBF8: D610003C 02125312
	v_bfe_u32 v18, v18, v43, 4                                 // 00000070EC00: D6100012 02125712
	v_lshlrev_b32_e32 v14, 4, v14                              // 00000070EC08: 301C1C84
	v_bfe_u32 v39, v19, v39, 4                                 // 00000070EC0C: D6100027 02124F13
	v_lshlrev_b32_e32 v40, 4, v40                              // 00000070EC14: 30505084
	v_and_or_b32 v37, v44, 48, v37                             // 00000070EC18: D6570025 0495612C
	v_and_or_b32 v44, v47, 48, v54                             // 00000070EC20: D657002C 04D9612F
	v_and_or_b32 v14, v14, 48, v18                             // 00000070EC28: D657000E 0449610E
	v_lshlrev_b32_e32 v38, 4, v38                              // 00000070EC30: 304C4C84
	v_and_or_b32 v18, v40, 48, v39                             // 00000070EC34: D6570012 049D6128
	v_bfe_u32 v57, v17, v41, 4                                 // 00000070EC3C: D6100039 02125311
	v_subrev_nc_u32_e32 v39, 32, v44                           // 00000070EC44: 4E4E58A0
	v_bfe_u32 v41, v19, v41, 4                                 // 00000070EC48: D6100029 02125313
	v_lshlrev_b32_e32 v42, 4, v42                              // 00000070EC50: 30545484
	v_subrev_nc_u32_e32 v14, 32, v14                           // 00000070EC54: 4E1C1CA0
	v_lshlrev_b32_e32 v52, 4, v52                              // 00000070EC58: 30686884
	v_cvt_f32_i32_e32 v39, v39                                 // 00000070EC5C: 7E4E0B27
	v_subrev_nc_u32_e32 v18, 32, v18                           // 00000070EC60: 4E2424A0
	v_bfe_u32 v16, v16, v43, 4                                 // 00000070EC64: D6100010 02125710
	v_cvt_f32_i32_e32 v14, v14                                 // 00000070EC6C: 7E1C0B0E
	v_lshlrev_b32_e32 v13, 4, v13                              // 00000070EC70: 301A1A84
	v_mul_f32_e32 v39, v36, v39                                // 00000070EC74: 104E4F24
	v_bfe_u32 v55, v17, v4, 4                                  // 00000070EC78: D6100037 02120911
	v_bfe_u32 v4, v19, v4, 4                                   // 00000070EC80: D6100004 02120913
	v_bfe_u32 v17, v17, v43, 4                                 // 00000070EC88: D6100011 02125711
	v_bfe_u32 v19, v19, v43, 4                                 // 00000070EC90: D6100013 02125713
	v_mul_f32_e32 v14, v36, v14                                // 00000070EC98: 101C1D24
	v_and_or_b32 v47, v52, 48, v59                             // 00000070EC9C: D657002F 04ED6134
	v_and_or_b32 v4, v38, 48, v4                               // 00000070ECA4: D6570004 04116126
	v_and_or_b32 v38, v42, 48, v41                             // 00000070ECAC: D6570026 04A5612A
	v_and_or_b32 v13, v13, 48, v17                             // 00000070ECB4: D657000D 0445610D
	v_lshlrev_b32_e32 v48, 4, v48                              // 00000070ECBC: 30606084
	v_subrev_nc_u32_e32 v42, 32, v47                           // 00000070ECC0: 4E545EA0
	v_subrev_nc_u32_e32 v4, 32, v4                             // 00000070ECC4: 4E0808A0
	v_subrev_nc_u32_e32 v38, 32, v38                           // 00000070ECC8: 4E4C4CA0
	v_lshlrev_b32_e32 v50, 4, v50                              // 00000070ECCC: 30646484
	v_cvt_f32_i32_e32 v18, v18                                 // 00000070ECD0: 7E240B12
	v_lshlrev_b32_e32 v53, 4, v53                              // 00000070ECD4: 306A6A84
	v_cvt_f32_i32_e32 v4, v4                                   // 00000070ECD8: 7E080B04
	v_lshlrev_b32_e32 v51, 4, v51                              // 00000070ECDC: 30666684
	v_cvt_f32_i32_e32 v38, v38                                 // 00000070ECE0: 7E4C0B26
	v_lshlrev_b32_e32 v15, 4, v15                              // 00000070ECE4: 301E1E84
	v_cvt_f32_i32_e32 v42, v42                                 // 00000070ECE8: 7E540B2A
	v_mul_f32_e32 v4, v36, v4                                  // 00000070ECEC: 10080924
	v_and_or_b32 v17, v51, 48, v58                             // 00000070ECF0: D6570011 04E96133
	v_mul_f32_e32 v38, v36, v38                                // 00000070ECF8: 104C4D24
	v_and_or_b32 v15, v15, 48, v19                             // 00000070ECFC: D657000F 044D610F
	v_dual_mul_f32 v42, v36, v42 :: v_dual_lshlrev_b32 v49, 4, v49// 00000070ED04: C8E25524 2A306284
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000070ED0C: BF870224
	v_subrev_nc_u32_e32 v17, 32, v17                           // 00000070ED10: 4E2222A0
	v_subrev_nc_u32_e32 v19, 32, v37                           // 00000070ED14: 4E264AA0
	v_subrev_nc_u32_e32 v15, 32, v15                           // 00000070ED18: 4E1E1EA0
	v_mul_f32_e32 v18, v36, v18                                // 00000070ED1C: 10242524
	v_subrev_nc_u32_e32 v13, 32, v13                           // 00000070ED20: 4E1A1AA0
	v_cvt_f32_i32_e32 v17, v17                                 // 00000070ED24: 7E220B11
	v_lshlrev_b32_e32 v46, 4, v46                              // 00000070ED28: 305C5C84
	v_cvt_f32_i32_e32 v15, v15                                 // 00000070ED2C: 7E1E0B0F
	v_lshlrev_b32_e32 v12, 4, v12                              // 00000070ED30: 30181884
	v_cvt_f32_i32_e32 v19, v19                                 // 00000070ED34: 7E260B13
	v_mul_f32_e32 v17, v36, v17                                // 00000070ED38: 10222324
	v_and_or_b32 v43, v46, 48, v45                             // 00000070ED3C: D657002B 04B5612E
	v_and_or_b32 v45, v49, 48, v56                             // 00000070ED44: D657002D 04E16131
	v_and_or_b32 v46, v50, 48, v57                             // 00000070ED4C: D657002E 04E56132
	v_mul_f32_e32 v15, v36, v15                                // 00000070ED54: 101E1F24
	v_and_or_b32 v12, v12, 48, v16                             // 00000070ED58: D657000C 0441610C
	v_and_or_b32 v16, v48, 48, v55                             // 00000070ED60: D6570010 04DD6130
	v_and_or_b32 v48, v53, 48, v60                             // 00000070ED68: D6570030 04F16135
	v_subrev_nc_u32_e32 v37, 32, v43                           // 00000070ED70: 4E4A56A0
	v_subrev_nc_u32_e32 v40, 32, v45                           // 00000070ED74: 4E505AA0
	v_subrev_nc_u32_e32 v12, 32, v12                           // 00000070ED78: 4E1818A0
	v_subrev_nc_u32_e32 v16, 32, v16                           // 00000070ED7C: 4E2020A0
	v_subrev_nc_u32_e32 v41, 32, v46                           // 00000070ED80: 4E525CA0
	v_subrev_nc_u32_e32 v43, 32, v48                           // 00000070ED84: 4E5660A0
	v_cvt_f32_i32_e32 v37, v37                                 // 00000070ED88: 7E4A0B25
	v_cvt_f32_i32_e32 v12, v12                                 // 00000070ED8C: 7E180B0C
	v_cvt_f32_i32_e32 v16, v16                                 // 00000070ED90: 7E200B10
	v_cvt_f32_i32_e32 v40, v40                                 // 00000070ED94: 7E500B28
	v_cvt_f32_i32_e32 v41, v41                                 // 00000070ED98: 7E520B29
	v_cvt_f32_i32_e32 v13, v13                                 // 00000070ED9C: 7E1A0B0D
	v_cvt_f32_i32_e32 v43, v43                                 // 00000070EDA0: 7E560B2B
	v_mul_f32_e32 v19, v36, v19                                // 00000070EDA4: 10262724
	v_mul_f32_e32 v37, v36, v37                                // 00000070EDA8: 104A4B24
	v_mul_f32_e32 v12, v36, v12                                // 00000070EDAC: 10181924
	v_mul_f32_e32 v16, v36, v16                                // 00000070EDB0: 10202124
	v_mul_f32_e32 v40, v36, v40                                // 00000070EDB4: 10505124
	v_mul_f32_e32 v41, v36, v41                                // 00000070EDB8: 10525324
	v_mul_f32_e32 v13, v36, v13                                // 00000070EDBC: 101A1B24
	v_mul_f32_e32 v43, v36, v43                                // 00000070EDC0: 10565724
	v_bfe_u32 v36, v19, 16, 1                                  // 00000070EDC4: D6100024 02052113
	v_bfe_u32 v44, v37, 16, 1                                  // 00000070EDCC: D610002C 02052125
	v_bfe_u32 v45, v39, 16, 1                                  // 00000070EDD4: D610002D 02052127
	v_bfe_u32 v46, v12, 16, 1                                  // 00000070EDDC: D610002E 0205210C
	v_bfe_u32 v47, v16, 16, 1                                  // 00000070EDE4: D610002F 02052110
	v_add3_u32 v19, v19, v36, 0x7fff                           // 00000070EDEC: D6550013 03FE4913 00007FFF
	v_add3_u32 v37, v37, v44, 0x7fff                           // 00000070EDF8: D6550025 03FE5925 00007FFF
	v_add3_u32 v39, v39, v45, 0x7fff                           // 00000070EE04: D6550027 03FE5B27 00007FFF
	v_bfe_u32 v48, v40, 16, 1                                  // 00000070EE10: D6100030 02052128
	v_add3_u32 v12, v12, v46, 0x7fff                           // 00000070EE18: D655000C 03FE5D0C 00007FFF
	.long 0x7e4a3993                                           // 00000070EE24: 7E4A3993
	v_bfe_u32 v49, v41, 16, 1                                  // 00000070EE28: D6100031 02052129
	v_add3_u32 v16, v16, v47, 0x7fff                           // 00000070EE30: D6550010 03FE5F10 00007FFF
	.long 0x7e1839a7                                           // 00000070EE3C: 7E1839A7
	v_bfe_u32 v50, v13, 16, 1                                  // 00000070EE40: D6100032 0205210D
	s_waitcnt vmcnt(3)                                         // 00000070EE48: BF890FF7
	v_dot2_f32_bf16 v19, v20, v37, 0                           // 00000070EE4C: CC1A4013 1A024B14
	s_waitcnt vmcnt(2)                                         // 00000070EE54: BF890BF7
	v_dot2_f32_bf16 v20, v24, v37, 0                           // 00000070EE58: CC1A4014 1A024B18
	v_add3_u32 v24, v40, v48, 0x7fff                           // 00000070EE60: D6550018 03FE6128 00007FFF
	v_bfe_u32 v51, v17, 16, 1                                  // 00000070EE6C: D6100033 02052111
	v_add3_u32 v37, v41, v49, 0x7fff                           // 00000070EE74: D6550025 03FE6329 00007FFF
	.long 0x7e303990                                           // 00000070EE80: 7E303990
	v_dot2_f32_bf16 v16, v21, v12, v19                         // 00000070EE84: CC1A4010 1C4E1915
	v_dot2_f32_bf16 v12, v25, v12, v20                         // 00000070EE8C: CC1A400C 1C521919
	v_bfe_u32 v52, v42, 16, 1                                  // 00000070EE94: D6100034 0205212A
	v_add3_u32 v13, v13, v50, 0x7fff                           // 00000070EE9C: D655000D 03FE650D 00007FFF
	v_bfe_u32 v53, v43, 16, 1                                  // 00000070EEA8: D6100035 0205212B
	v_add3_u32 v17, v17, v51, 0x7fff                           // 00000070EEB0: D6550011 03FE6711 00007FFF
	.long 0x7e1a39a5                                           // 00000070EEBC: 7E1A39A5
	v_dot2_f32_bf16 v16, v22, v24, v16                         // 00000070EEC0: CC1A4010 1C423116
	v_dot2_f32_bf16 v12, v26, v24, v12                         // 00000070EEC8: CC1A400C 1C32311A
	v_bfe_u32 v54, v14, 16, 1                                  // 00000070EED0: D6100036 0205210E
	v_add3_u32 v19, v42, v52, 0x7fff                           // 00000070EED8: D6550013 03FE692A 00007FFF
	v_bfe_u32 v55, v4, 16, 1                                   // 00000070EEE4: D6100037 02052104
	v_add3_u32 v20, v43, v53, 0x7fff                           // 00000070EEEC: D6550014 03FE6B2B 00007FFF
	.long 0x7e263991                                           // 00000070EEF8: 7E263991
	v_dot2_f32_bf16 v16, v23, v13, v16                         // 00000070EEFC: CC1A4010 1C421B17
	v_dot2_f32_bf16 v12, v27, v13, v12                         // 00000070EF04: CC1A400C 1C321B1B
	v_bfe_u32 v56, v18, 16, 1                                  // 00000070EF0C: D6100038 02052112
	v_add3_u32 v13, v14, v54, 0x7fff                           // 00000070EF14: D655000D 03FE6D0E 00007FFF
	v_bfe_u32 v57, v38, 16, 1                                  // 00000070EF20: D6100039 02052126
	v_add3_u32 v4, v4, v55, 0x7fff                             // 00000070EF28: D6550004 03FE6F04 00007FFF
	.long 0x7e1a3994                                           // 00000070EF34: 7E1A3994
	s_waitcnt vmcnt(1)                                         // 00000070EF38: BF8907F7
	v_dot2_f32_bf16 v14, v28, v19, v16                         // 00000070EF3C: CC1A400E 1C42271C
	s_waitcnt vmcnt(0)                                         // 00000070EF44: BF8903F7
	v_dot2_f32_bf16 v12, v32, v19, v12                         // 00000070EF48: CC1A400C 1C322720
	v_bfe_u32 v36, v15, 16, 1                                  // 00000070EF50: D6100024 0205210F
	v_add3_u32 v16, v18, v56, 0x7fff                           // 00000070EF58: D6550010 03FE7112 00007FFF
	v_add3_u32 v17, v38, v57, 0x7fff                           // 00000070EF64: D6550011 03FE7326 00007FFF
	.long 0x7e203984                                           // 00000070EF70: 7E203984
	v_dot2_f32_bf16 v4, v29, v13, v14                          // 00000070EF74: CC1A4004 1C3A1B1D
	v_dot2_f32_bf16 v12, v33, v13, v12                         // 00000070EF7C: CC1A400C 1C321B21
	v_add3_u32 v13, v15, v36, 0x7fff                           // 00000070EF84: D655000D 03FE490F 00007FFF
	.long 0x7e1a3991                                           // 00000070EF90: 7E1A3991
	v_cmp_ge_i32_e32 vcc_lo, v8, v9                            // 00000070EF94: 7C8C1308
	v_dot2_f32_bf16 v4, v30, v16, v4                           // 00000070EF98: CC1A4004 1C12211E
	v_dot2_f32_bf16 v12, v34, v16, v12                         // 00000070EFA0: CC1A400C 1C322122
	s_or_b32 s3, vcc_lo, s3                                    // 00000070EFA8: 8C03036A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000070EFAC: BF870112
	v_dot2_f32_bf16 v4, v31, v13, v4                           // 00000070EFB0: CC1A4004 1C121B1F
	v_dot2_f32_bf16 v12, v35, v13, v12                         // 00000070EFB8: CC1A400C 1C321B23
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000070EFC0: BF870112
	v_dual_add_f32 v10, v10, v4 :: v_dual_add_nc_u32 v3, 0x200, v3// 00000070EFC4: C920090A 0A0206FF 00000200
	v_add_f32_e32 v11, v11, v12                                // 00000070EFD0: 0616190B
	s_and_not1_b32 exec_lo, exec_lo, s3                        // 00000070EFD4: 917E037E
	s_cbranch_execnz 65165                                     // 00000070EFD8: BFA6FE8D <_ZN7halogen12_GLOBAL__N_16k_lq6kILi2ELi32ELi2ELb1EEEvPKhPKtPvll+0x110>
	s_or_b32 exec_lo, exec_lo, s3                              // 00000070EFDC: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000070EFE0: BF8700B9
	s_or_b32 exec_lo, exec_lo, s2                              // 00000070EFE4: 8C7E027E
	.long 0xd71f0001                                           // 00000070EFE8: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000070EFEC: 020100C1
	s_mov_b32 s0, exec_lo                                      // 00000070EFF0: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 00000070EFF4: 3A040290
	v_xor_b32_e32 v4, 8, v1                                    // 00000070EFF8: 3A080288
	v_xor_b32_e32 v9, 4, v1                                    // 00000070EFFC: 3A120284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000070F000: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 00000070F004: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 00000070F008: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 00000070F00C: 7C9808A0
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo                       // 00000070F010: 02080901
	v_cmp_gt_u32_e32 vcc_lo, 32, v9                            // 00000070F014: 7C9812A0
	s_delay_alu instid0(VALU_DEP_4)                            // 00000070F018: BF870004
	v_dual_cndmask_b32 v9, v1, v9 :: v_dual_lshlrev_b32 v2, 2, v2// 00000070F01C: CA621301 09020482
	ds_bpermute_b32 v3, v2, v10                                // 00000070F024: DACC0000 03000A02
	ds_bpermute_b32 v2, v2, v11                                // 00000070F02C: DACC0000 02000B02
	v_lshlrev_b32_e32 v9, 2, v9                                // 00000070F034: 30121282
	s_waitcnt lgkmcnt(0)                                       // 00000070F038: BF89FC07
	v_dual_add_f32 v3, v10, v3 :: v_dual_lshlrev_b32 v4, 2, v4 // 00000070F03C: C922070A 03040882
	v_add_f32_e32 v2, v11, v2                                  // 00000070F044: 0604050B
	ds_bpermute_b32 v8, v4, v3                                 // 00000070F048: DACC0000 08000304
	ds_bpermute_b32 v4, v4, v2                                 // 00000070F050: DACC0000 04000204
	s_waitcnt lgkmcnt(1)                                       // 00000070F058: BF89FC17
	v_add_f32_e32 v3, v3, v8                                   // 00000070F05C: 06061103
	s_waitcnt lgkmcnt(0)                                       // 00000070F060: BF89FC07
	v_add_f32_e32 v2, v2, v4                                   // 00000070F064: 06040902
	ds_bpermute_b32 v4, v9, v3                                 // 00000070F068: DACC0000 04000309
	ds_bpermute_b32 v8, v9, v2                                 // 00000070F070: DACC0000 08000209
	v_xor_b32_e32 v9, 2, v1                                    // 00000070F078: 3A120282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000070F07C: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v9                            // 00000070F080: 7C9812A0
	v_cndmask_b32_e32 v9, v1, v9, vcc_lo                       // 00000070F084: 02121301
	v_lshlrev_b32_e32 v9, 2, v9                                // 00000070F088: 30121282
	s_waitcnt lgkmcnt(1)                                       // 00000070F08C: BF89FC17
	v_add_f32_e32 v3, v3, v4                                   // 00000070F090: 06060903
	s_waitcnt lgkmcnt(0)                                       // 00000070F094: BF89FC07
	v_add_f32_e32 v2, v2, v8                                   // 00000070F098: 06041102
	ds_bpermute_b32 v4, v9, v3                                 // 00000070F09C: DACC0000 04000309
	ds_bpermute_b32 v8, v9, v2                                 // 00000070F0A4: DACC0000 08000209
	v_xor_b32_e32 v9, 1, v1                                    // 00000070F0AC: 3A120281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000070F0B0: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v9                            // 00000070F0B4: 7C9812A0
	v_cndmask_b32_e32 v1, v1, v9, vcc_lo                       // 00000070F0B8: 02021301
	v_lshlrev_b32_e32 v9, 2, v1                                // 00000070F0BC: 30120282
	s_waitcnt lgkmcnt(1)                                       // 00000070F0C0: BF89FC17
	v_add_f32_e32 v1, v3, v4                                   // 00000070F0C4: 06020903
	s_waitcnt lgkmcnt(0)                                       // 00000070F0C8: BF89FC07
	v_add_f32_e32 v2, v2, v8                                   // 00000070F0CC: 06041102
	ds_bpermute_b32 v3, v9, v1                                 // 00000070F0D0: DACC0000 03000109
	ds_bpermute_b32 v4, v9, v2                                 // 00000070F0D8: DACC0000 04000209
	v_cmpx_eq_u32_e32 0, v7                                    // 00000070F0E0: 7D940E80
	s_cbranch_execz 9                                          // 00000070F0E4: BFA50009 <_ZN7halogen12_GLOBAL__N_16k_lq6kILi2ELi32ELi2ELb1EEEvPKhPKtPvll+0x80c>
	s_waitcnt lgkmcnt(0)                                       // 00000070F0E8: BF89FC07
	v_dual_add_f32 v2, v2, v4 :: v_dual_lshlrev_b32 v5, 3, v5  // 00000070F0EC: C9220902 02040A83
	v_add_f32_e32 v1, v1, v3                                   // 00000070F0F4: 06020701
	s_delay_alu instid0(VALU_DEP_2)                            // 00000070F0F8: BF870002
	v_lshl_or_b32 v3, v6, 4, v5                                // 00000070F0FC: D6560003 04150906
	ds_store_b64 v3, v[1:2]                                    // 00000070F104: D9340000 00000103
	s_or_b32 exec_lo, exec_lo, s0                              // 00000070F10C: 8C7E007E
	s_waitcnt lgkmcnt(1)                                       // 00000070F110: BF89FC17
	v_lshrrev_b32_e32 v3, 1, v0                                // 00000070F114: 32060081
	v_mov_b32_e32 v2, s15                                      // 00000070F118: 7E04020F
	.long 0xd44c0000                                           // 00000070F11C: D44C0000
	v_cndmask_b32_e32 v1, 8, v0, vcc_lo                        // 00000070F120: 02020088
	s_waitcnt lgkmcnt(0)                                       // 00000070F124: BF89FC07
	s_barrier                                                  // 00000070F128: BFBD0000
	v_or_b32_e32 v1, s14, v3                                   // 00000070F12C: 3802060E
	buffer_gl0_inv                                             // 00000070F130: E0AC0000 00000000
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 00000070F138: 7CA8020C
	s_and_b32 s0, s0, vcc_lo                                   // 00000070F13C: 8B006A00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000070F140: BF870009
	s_and_saveexec_b32 s1, s0                                  // 00000070F144: BE812000
	s_cbranch_execz 31                                         // 00000070F148: BFA5001F <_ZN7halogen12_GLOBAL__N_16k_lq6kILi2ELi32ELi2ELb1EEEvPKhPKtPvll+0x8c8>
	v_and_b32_e32 v0, 1, v0                                    // 00000070F14C: 36000081
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000070F150: BF870241
	v_lshlrev_b32_e32 v4, 2, v0                                // 00000070F154: 30080082
	.long 0xd72c0006                                           // 00000070F158: D72C0006
	v_cndmask_b32_e32 v1, s13, v0, vcc_lo                      // 00000070F15C: 0202000D
	.long 0xd72c0005                                           // 00000070F160: D72C0005
	v_cndmask_b32_e32 v1, s12, v0, vcc_lo                      // 00000070F164: 0202000C
	.long 0xd73c0000                                           // 00000070F168: D73C0000
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000070F16C: 02020282
	v_lshl_or_b32 v3, v3, 4, v4                                // 00000070F170: D6560003 04110903
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000070F178: BF8700D3
	.long 0xd73c0005                                           // 00000070F17C: D73C0005
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 00000070F180: 02020A82
	ds_load_2addr_b32 v[3:4], v3 offset1:2                     // 00000070F184: D8DC0200 03000003
	s_waitcnt lgkmcnt(0)                                       // 00000070F18C: BF89FC07
	v_add_f32_e32 v2, 0, v3                                    // 00000070F190: 06040680
	.long 0xd7006a03                                           // 00000070F194: D7006A03
	v_cndmask_b32_e32 v1, s8, v5, vcc_lo                       // 00000070F198: 02020A08
	v_add_co_ci_u32_e64 v5, null, s9, v6, vcc_lo               // 00000070F19C: D5207C05 01AA0C09
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000070F1A4: BF870193
	v_add_f32_e32 v2, v2, v4                                   // 00000070F1A8: 06040902
	.long 0xd7006a00                                           // 00000070F1AC: D7006A00
	v_cndmask_b32_e32 v1, v3, v0, vcc_lo                       // 00000070F1B0: 02020103
	s_delay_alu instid0(VALU_DEP_1)                            // 00000070F1B4: BF870001
	v_add_co_ci_u32_e64 v1, null, v5, v1, vcc_lo               // 00000070F1B8: D5207C01 01AA0305
	global_store_b32 v[0:1], v2, off                           // 00000070F1C0: DC6A0000 007C0200
	s_endpgm                                                   // 00000070F1C8: BFB00000
		...

