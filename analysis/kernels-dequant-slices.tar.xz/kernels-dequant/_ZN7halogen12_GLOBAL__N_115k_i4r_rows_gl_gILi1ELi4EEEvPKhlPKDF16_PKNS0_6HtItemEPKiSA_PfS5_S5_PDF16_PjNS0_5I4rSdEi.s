0000000000dd1500 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi1ELi4EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi>:
; _ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi1ELi4EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi():
	s_clause 0x1                                               // 000000DD1500: BF850001
	s_load_b32 s3, s[0:1], 0xb0                                // 000000DD1504: F40000C0 F80000B0
	s_load_b512 s[12:27], s[0:1], 0x40                         // 000000DD150C: F4100300 F8000040
	v_mov_b32_e32 v65, v0                                      // 000000DD1514: 7E820300
	s_mov_b32 s4, -1                                           // 000000DD1518: BE8400C1
	s_waitcnt lgkmcnt(0)                                       // 000000DD151C: BF89FC07
	s_cmp_lt_i32 s2, s3                                        // 000000DD1520: BF040302
	s_cbranch_scc1 2259                                        // 000000DD1524: BFA208D3 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi1ELi4EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x2374>
	s_clause 0x1                                               // 000000DD1528: BF850001
	s_load_b64 s[10:11], s[0:1], 0xa4                          // 000000DD152C: F4040280 F80000A4
	s_load_b128 s[36:39], s[0:1], 0x98                         // 000000DD1534: F4080900 F8000098
	s_sub_i32 s3, s2, s3                                       // 000000DD153C: 81830302
	s_clause 0x1                                               // 000000DD1540: BF850001
	s_load_b128 s[28:31], s[0:1], 0x80                         // 000000DD1544: F4080700 F8000080
	s_load_b64 s[40:41], s[0:1], 0x90                          // 000000DD154C: F4040A00 F8000090
	v_lshrrev_b32_e32 v8, 5, v65                               // 000000DD1554: 32108285
	v_and_b32_e32 v9, 31, v65                                  // 000000DD1558: 3612829F
	s_mov_b32 s44, 0                                           // 000000DD155C: BEAC0080
	s_mov_b32 s42, exec_lo                                     // 000000DD1560: BEAA007E
	s_waitcnt lgkmcnt(0)                                       // 000000DD1564: BF89FC07
	s_abs_i32 s4, s11                                          // 000000DD1568: BE84150B
	s_ashr_i32 s7, s11, 31                                     // 000000DD156C: 86079F0B
	s_cvt_f32_u32 s5, s4                                       // 000000DD1570: BE856504
	s_sub_i32 s6, 0, s4                                        // 000000DD1574: 81860480
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000DD1578: BF87029A
	v_rcp_iflag_f32_e32 v0, s5                                 // 000000DD157C: 7E005605
	v_readfirstlane_b32 s5, v0                                 // 000000DD1580: 7E0A0500
	s_mul_f32 s5, s5, 0x4f7ffffe                               // 000000DD1584: A205FF05 4F7FFFFE
	s_delay_alu instid0(SALU_CYCLE_3) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 000000DD158C: BF87059B
	s_cvt_u32_f32 s5, s5                                       // 000000DD1590: BE856705
	s_mul_i32 s6, s6, s5                                       // 000000DD1594: 96060506
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000DD1598: BF870499
	s_mul_hi_u32 s6, s5, s6                                    // 000000DD159C: 96860605
	s_add_i32 s5, s5, s6                                       // 000000DD15A0: 81050605
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000DD15A4: BF870499
	s_mul_hi_u32 s5, s3, s5                                    // 000000DD15A8: 96850503
	s_mul_i32 s6, s5, s4                                       // 000000DD15AC: 96060405
	s_add_i32 s8, s5, 1                                        // 000000DD15B0: 81088105
	s_sub_i32 s6, s3, s6                                       // 000000DD15B4: 81860603
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000DD15B8: BF870009
	s_sub_i32 s9, s6, s4                                       // 000000DD15BC: 81890406
	s_cmp_ge_u32 s6, s4                                        // 000000DD15C0: BF090406
	s_cselect_b32 s5, s8, s5                                   // 000000DD15C4: 98050508
	s_cselect_b32 s6, s9, s6                                   // 000000DD15C8: 98060609
	s_add_i32 s8, s5, 1                                        // 000000DD15CC: 81088105
	s_cmp_ge_u32 s6, s4                                        // 000000DD15D0: BF090406
	s_cselect_b32 s4, s8, s5                                   // 000000DD15D4: 98040508
	s_ashr_i32 s35, s38, 31                                    // 000000DD15D8: 86239F26
	s_xor_b32 s4, s4, s7                                       // 000000DD15DC: 8D040704
	s_lshr_b32 s5, s35, 25                                     // 000000DD15E0: 85059923
	s_sub_i32 s34, s4, s7                                      // 000000DD15E4: 81A20704
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000DD15E8: BF870499
	s_mul_i32 s4, s34, s11                                     // 000000DD15EC: 96040B22
	s_sub_i32 s33, s3, s4                                      // 000000DD15F0: 81A10403
	s_add_i32 s3, s38, s5                                      // 000000DD15F4: 81030526
	s_mul_i32 s39, s33, s10                                    // 000000DD15F8: 96270A21
	s_ashr_i32 s3, s3, 7                                       // 000000DD15FC: 86038703
	s_add_i32 s4, s39, s10                                     // 000000DD1600: 81040A27
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000DD1604: BF870499
	s_min_i32 s3, s3, s4                                       // 000000DD1608: 89030403
	s_sub_i32 s43, s3, s39                                     // 000000DD160C: 81AB2703
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000DD1610: BF870009
	.long 0xd4c4007e                                           // 000000DD1614: D4C4007E
	v_cndmask_b32_e32 v1, s43, v8, vcc_lo                      // 000000DD1618: 0202102B
	s_cbranch_execz 499                                        // 000000DD161C: BFA501F3 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi1ELi4EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x8ec>
	s_add_i32 s45, s36, -1                                     // 000000DD1620: 812DC124
	s_cmp_lg_u64 s[26:27], 0                                   // 000000DD1624: BF11801A
	v_dual_mov_b32 v0, v8 :: v_dual_and_b32 v1, 1, v65         // 000000DD1628: CA240108 00008281
	s_cselect_b32 s46, -1, 0                                   // 000000DD1630: 982E80C1
	s_abs_i32 s47, s43                                         // 000000DD1634: BEAF152B
	v_and_b32_e32 v2, 2, v65                                   // 000000DD1638: 36048282
	s_cvt_f32_u32 s3, s47                                      // 000000DD163C: BE83652F
	v_lshlrev_b32_e32 v6, 3, v9                                // 000000DD1640: 300C1283
	v_lshlrev_b32_e32 v7, 7, v8                                // 000000DD1644: 300E1087
	v_and_b32_e32 v3, 4, v65                                   // 000000DD1648: 36068284
	v_rcp_iflag_f32_e32 v4, s3                                 // 000000DD164C: 7E085603
	v_and_b32_e32 v5, 8, v65                                   // 000000DD1650: 360A8288
	.long 0xd44a0004                                           // 000000DD1654: D44A0004
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000DD1658: 02020280
	.long 0xd44a0005                                           // 000000DD165C: D44A0005
	v_cndmask_b32_e32 v1, 0, v2, vcc_lo                        // 000000DD1660: 02020480
	v_lshl_or_b32 v1, v8, 8, v6                                // 000000DD1664: D6560001 04191108
	v_lshl_add_u32 v2, s39, 7, v7                              // 000000DD166C: D6460002 041D0E27
	s_ashr_i32 s49, s43, 31                                    // 000000DD1674: 86319F2B
	s_sub_i32 s51, 0, s47                                      // 000000DD1678: 81B32F80
	s_mul_i32 s10, s49, 0x1400                                 // 000000DD167C: 960AFF31 00001400
	.long 0xd44c0003                                           // 000000DD1684: D44C0003
	v_cndmask_b32_e32 v1, 16, v9, vcc_lo                       // 000000DD1688: 02021290
	v_readfirstlane_b32 s7, v4                                 // 000000DD168C: 7E0E0504
	.long 0xd44a0006                                           // 000000DD1690: D44A0006
	v_cndmask_b32_e32 v1, 0, v3, vcc_lo                        // 000000DD1694: 02020680
	v_subrev_nc_u32_e32 v10, s10, v1                           // 000000DD1698: 4E14020A
	v_lshl_or_b32 v1, v9, 2, v2                                // 000000DD169C: D6560001 04090509
	s_lshl_b32 s8, s43, 7                                      // 000000DD16A4: 8408872B
	s_mul_f32 s9, s7, 0x4f7ffffe                               // 000000DD16A8: A209FF07 4F7FFFFE
	.long 0xd44a0007                                           // 000000DD16B0: D44A0007
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 000000DD16B4: 02020A80
	s_mov_b32 s48, 0x76543210                                  // 000000DD16B8: BEB000FF 76543210
	s_lshl_b32 s50, s43, 8                                     // 000000DD16C0: 8432882B
	s_cvt_u32_f32 s9, s9                                       // 000000DD16C4: BE896709
	s_mov_b32 s53, 0x3db504f3                                  // 000000DD16C8: BEB500FF 3DB504F3
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000DD16D0: BF87049A
	s_mul_i32 s51, s51, s9                                     // 000000DD16D4: 96330933
	s_mul_hi_u32 s10, s9, s51                                  // 000000DD16D8: 968A3309
	s_sub_i32 s51, 0, s8                                       // 000000DD16DC: 81B30880
	s_add_i32 s52, s9, s10                                     // 000000DD16E0: 81340A09
	s_branch 161                                               // 000000DD16E4: BFA000A1 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi1ELi4EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x46c>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD16E8: BF870091
	.long 0xd7006a02                                           // 000000DD16EC: D7006A02
	v_cndmask_b32_e32 v1, s20, v2, vcc_lo                      // 000000DD16F0: 02020414
	v_add_co_ci_u32_e64 v3, null, s21, v3, vcc_lo              // 000000DD16F4: D5207C03 01AA0615
	v_add_nc_u32_e32 v1, 0x400, v1                             // 000000DD16FC: 4A0202FF 00000400
	global_load_d16_b16 v2, v[2:3], off offset:6               // 000000DD1704: DC820006 027C0002
	v_add_f32_e32 v3, v16, v14                                 // 000000DD170C: 06061D10
	s_waitcnt vmcnt(0)                                         // 000000DD1710: BF8903F7
	v_fma_mix_f32 v5, v15, v2, v13 op_sel_hi:[0,1,0]           // 000000DD1714: CC200005 1436050F
	v_sub_f32_e32 v4, v16, v14                                 // 000000DD171C: 08081D10
	v_fma_mix_f32 v2, -v15, v2, v13 op_sel_hi:[0,1,0]          // 000000DD1720: CC200002 3436050F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DD1728: BF870121
	v_dual_add_f32 v6, v3, v5 :: v_dual_add_f32 v7, v4, v2     // 000000DD172C: C9080B03 06060504
	v_sub_f32_e32 v2, v4, v2                                   // 000000DD1734: 08040504
	v_mov_b32_dpp v4, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DD1738: 7E0802FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s4                          // 000000DD1740: D5010006 20120D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000DD1748: BF870241
	v_dual_add_f32 v4, v6, v4 :: v_dual_sub_f32 v3, v3, v5     // 000000DD174C: C90A0906 04020B03
	v_mov_b32_dpp v5, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DD1754: 7E0A02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s4                          // 000000DD175C: D5010007 20120F07
	.long 0xd72c0006                                           // 000000DD1764: D72C0006
	v_cndmask_b32_e32 v1, 0x1400, v12, vcc_lo                  // 000000DD1768: 020218FF 00001400
	v_mov_b32_dpp v13, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DD1770: 7E1A02FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s4                          // 000000DD1778: D5010003 20120703
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DD1780: BF870004
	v_add_f32_e32 v5, v7, v5                                   // 000000DD1784: 060A0B07
	v_mov_b32_dpp v14, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DD1788: 7E1C02FA FF016102
	v_cndmask_b32_e64 v2, -v2, v2, s4                          // 000000DD1790: D5010002 20120502
	v_mov_b32_dpp v7, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DD1798: 7E0E02FA FF016204
	v_add_f32_e32 v3, v3, v13                                  // 000000DD17A0: 06061B03
	v_mov_b32_dpp v12, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DD17A4: 7E1802FA FF016205
	v_cndmask_b32_e64 v4, -v4, v4, s5                          // 000000DD17AC: D5010004 20160904
	v_add_f32_e32 v2, v2, v14                                  // 000000DD17B4: 06041D02
	v_cndmask_b32_e64 v5, -v5, v5, s5                          // 000000DD17B8: D5010005 20160B05
	v_mov_b32_dpp v13, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DD17C0: 7E1A02FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s5                          // 000000DD17C8: D5010003 20160703
	v_add_f32_e32 v4, v4, v7                                   // 000000DD17D0: 06080F04
	v_mov_b32_dpp v14, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DD17D4: 7E1C02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s5                          // 000000DD17DC: D5010002 20160502
	v_add_f32_e32 v5, v5, v12                                  // 000000DD17E4: 060A1905
	.long 0xd72c0007                                           // 000000DD17E8: D72C0007
	v_cndmask_b32_e32 v1, s50, v11, vcc_lo                     // 000000DD17EC: 02021632
	v_add_f32_e32 v3, v3, v13                                  // 000000DD17F0: 06061B03
	v_mov_b32_dpp v11, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DD17F4: 7E1602FA FF016404
	v_add_f32_e32 v2, v2, v14                                  // 000000DD17FC: 06041D02
	v_mov_b32_dpp v12, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DD1800: 7E1802FA FF016405
	v_cndmask_b32_e64 v4, -v4, v4, s6                          // 000000DD1808: D5010004 201A0904
	v_cndmask_b32_e64 v5, -v5, v5, s6                          // 000000DD1810: D5010005 201A0B05
	v_mov_b32_dpp v13, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DD1818: 7E1A02FA FF016403
	v_mov_b32_dpp v14, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DD1820: 7E1C02FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s6                          // 000000DD1828: D5010002 201A0502
	v_cndmask_b32_e64 v3, -v3, v3, s6                          // 000000DD1830: D5010003 201A0703
	v_dual_add_f32 v4, v4, v11 :: v_dual_add_f32 v5, v5, v12   // 000000DD1838: C9081704 04041905
	v_add_nc_u32_e32 v0, 8, v0                                 // 000000DD1840: 4A000088
	v_sub_nc_u32_e32 v6, v6, v7                                // 000000DD1844: 4C0C0F06
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DD1848: BF870214
	v_add_f32_e32 v3, v3, v13                                  // 000000DD184C: 06061B03
	v_mov_b32_dpp v11, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DD1850: 7E1602FA FF016804
	v_mov_b32_dpp v12, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DD1858: 7E1802FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s7                          // 000000DD1860: D5010005 201E0B05
	v_add_f32_e32 v2, v2, v14                                  // 000000DD1868: 06041D02
	v_cndmask_b32_e64 v4, -v4, v4, s7                          // 000000DD186C: D5010004 201E0904
	v_mov_b32_dpp v13, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DD1874: 7E1A02FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s7                          // 000000DD187C: D5010003 201E0703
	v_add_f32_e32 v5, v5, v12                                  // 000000DD1884: 060A1905
	v_mov_b32_dpp v14, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DD1888: 7E1C02FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s7                          // 000000DD1890: D5010002 201E0502
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DD1898: BF870214
	v_dual_add_f32 v4, v4, v11 :: v_dual_add_f32 v3, v3, v13   // 000000DD189C: C9081704 04021B03
	v_mov_b32_e32 v12, v5                                      // 000000DD18A4: 7E180305
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 000000DD18A8: D5010005 200E0B05
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DD18B0: BF870213
	v_dual_add_f32 v2, v2, v14 :: v_dual_mov_b32 v11, v4       // 000000DD18B4: C9101D02 020A0104
	v_mov_b32_e32 v13, v3                                      // 000000DD18BC: 7E1A0303
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DD18C0: BF870224
	v_permlanex16_b32 v12, v12, s48, 0xfedcba98                // 000000DD18C4: D65C000C 03FC610C FEDCBA98
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000DD18D0: D5010004 200E0904
	v_mov_b32_e32 v14, v2                                      // 000000DD18D8: 7E1C0302
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 000000DD18DC: D5010002 200E0502
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 000000DD18E4: D5010003 200E0703
	v_permlanex16_b32 v11, v11, s48, 0xfedcba98                // 000000DD18EC: D65C000B 03FC610B FEDCBA98
	v_permlanex16_b32 v13, v13, s48, 0xfedcba98                // 000000DD18F8: D65C000D 03FC610D FEDCBA98
	v_add_f32_e32 v5, v5, v12                                  // 000000DD1904: 060A1905
	v_permlanex16_b32 v14, v14, s48, 0xfedcba98                // 000000DD1908: D65C000E 03FC610E FEDCBA98
	v_cmp_le_i32_e32 vcc_lo, s43, v0                           // 000000DD1914: 7C86002B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DD1918: BF870224
	v_dual_add_f32 v4, v4, v11 :: v_dual_add_f32 v11, v3, v13  // 000000DD191C: C9081704 040A1B03
	v_add_nc_u32_e32 v6, v10, v6                               // 000000DD1924: 4A0C0D0A
	v_add_f32_e32 v7, v2, v14                                  // 000000DD1928: 060E1D02
	v_fma_mixhi_f16 v2, v5, s53, 0                             // 000000DD192C: CC220002 02006B05
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DD1934: BF870004
	v_fma_mixlo_f16 v2, v4, s53, 0                             // 000000DD1938: CC210002 02006B04
	v_fma_mixlo_f16 v3, v11, s53, 0                            // 000000DD1940: CC210003 02006B0B
	v_add_nc_u32_e32 v10, 0x800, v10                           // 000000DD1948: 4A1414FF 00000800
	v_fma_mixhi_f16 v3, v7, s53, 0                             // 000000DD1950: CC220003 02006B07
	s_or_b32 s44, vcc_lo, s44                                  // 000000DD1958: 8C2C2C6A
	ds_store_b64 v6, v[2:3] offset:20480                       // 000000DD195C: D9345000 00000206
	s_and_not1_b32 exec_lo, exec_lo, s44                       // 000000DD1964: 917E2C7E
	s_cbranch_execz 288                                        // 000000DD1968: BFA50120 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi1ELi4EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x8ec>
	.long 0xd72d0002                                           // 000000DD196C: D72D0002
	v_cndmask_b32_e32 v0, v0, v52, vcc_lo                      // 000000DD1970: 02006900
	s_mov_b32 s8, -1                                           // 000000DD1974: BE8800C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD1978: BF870091
	.long 0xd72c0003                                           // 000000DD197C: D72C0003
	v_cndmask_b32_e32 v0, v2, v47, vcc_lo                      // 000000DD1980: 02005F02
	v_sub_nc_u32_e32 v3, v0, v3                                // 000000DD1984: 4C060700
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DD1988: BF870121
	v_subrev_nc_u32_e32 v5, s47, v3                            // 000000DD198C: 4E0A062F
	v_cmp_le_u32_e32 vcc_lo, s47, v3                           // 000000DD1990: 7C96062F
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_add_nc_u32 v4, 1, v2// 000000DD1994: CA600B03 03040481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DD199C: BF870111
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000DD19A0: 02040902
	v_cmp_le_u32_e32 vcc_lo, s47, v3                           // 000000DD19A4: 7C96062F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD19A8: BF870092
	v_add_nc_u32_e32 v4, 1, v2                                 // 000000DD19AC: 4A080481
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000DD19B0: 02040902
	s_and_not1_b32 vcc_lo, exec_lo, s46                        // 000000DD19B4: 916A2E7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD19B8: BF870091
	v_xor_b32_e32 v12, s49, v2                                 // 000000DD19BC: 3A180431
	v_subrev_nc_u32_e32 v11, s49, v12                          // 000000DD19C0: 4E161831
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DD19C4: BF8700A1
	v_mad_u64_u32 v[6:7], null, s51, v11, v[1:2]               // 000000DD19C8: D6FE7C06 04061633
	v_min_i32_e32 v2, s45, v11                                 // 000000DD19D0: 2204162D
	v_mad_i64_i32 v[4:5], null, v2, s38, 0                     // 000000DD19D4: D6FF7C04 02004D02
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD19DC: BF870093
	v_ashrrev_i32_e32 v7, 31, v6                               // 000000DD19E0: 340E0C9F
	.long 0xd73c0002                                           // 000000DD19E4: D73C0002
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000DD19E8: 02020C81
	s_cbranch_vccnz 211                                        // 000000DD19EC: BFA400D3 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi1ELi4EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x83c>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD19F0: BF870093
	.long 0xd7006a06                                           // 000000DD19F4: D7006A06
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 000000DD19F8: 02020D04
	v_add_co_ci_u32_e64 v7, null, v5, v7, vcc_lo               // 000000DD19FC: D5207C07 01AA0F05
	.long 0x7f3a3880                                           // 000000DD1A04: 7F3A3880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DD1A08: BF870112
	.long 0xd73c0006                                           // 000000DD1A0C: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000DD1A10: 02020C81
	.long 0x7f40399d                                           // 000000DD1A14: 7F40399D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD1A18: BF870092
	.long 0xd7006a0d                                           // 000000DD1A1C: D7006A0D
	v_cndmask_b32_e32 v1, s24, v6, vcc_lo                      // 000000DD1A20: 02020C18
	v_add_co_ci_u32_e64 v14, null, s25, v7, vcc_lo             // 000000DD1A24: D5207C0E 01AA0E19
	.long 0xd7006a06                                           // 000000DD1A2C: D7006A06
	v_cndmask_b32_e32 v1, s26, v6, vcc_lo                      // 000000DD1A30: 02020C1A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DD1A34: BF870001
	v_add_co_ci_u32_e64 v7, null, s27, v7, vcc_lo              // 000000DD1A38: D5207C07 01AA0E1B
	global_load_b64 v[13:14], v[13:14], off                    // 000000DD1A40: DC560000 0D7C000D
	.long 0xd7006a0f                                           // 000000DD1A48: D7006A0F
	v_cndmask_b32_e32 v1, s20, v2, vcc_lo                      // 000000DD1A4C: 02020414
	global_load_b64 v[6:7], v[6:7], off                        // 000000DD1A50: DC560000 067C0006
	v_add_co_ci_u32_e64 v16, null, s21, v3, vcc_lo             // 000000DD1A58: D5207C10 01AA0615
	s_clause 0x1                                               // 000000DD1A60: BF850001
	global_load_b32 v17, v[15:16], off                         // 000000DD1A64: DC520000 117C000F
	global_load_d16_b16 v15, v[15:16], off offset:4            // 000000DD1A6C: DC820004 0F7C000F
	s_waitcnt vmcnt(3)                                         // 000000DD1A74: BF890FF7
	.long 0x7e20390d                                           // 000000DD1A78: 7E20390D
	s_waitcnt vmcnt(2)                                         // 000000DD1A7C: BF890BF7
	v_and_b32_e32 v39, 0xffff0000, v6                          // 000000DD1A80: 364E0CFF FFFF0000
	v_lshlrev_b32_e32 v6, 16, v6                               // 000000DD1A88: 300C0C90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD1A8C: BF870093
	v_lshlrev_b32_e32 v16, 16, v16                             // 000000DD1A90: 30202090
	v_mul_f32_e32 v20, 0xbfb8aa3b, v16                         // 000000DD1A94: 102820FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000DD1A9C: BF870291
	v_exp_f32_e32 v20, v20                                     // 000000DD1AA0: 7E284B14
	v_dual_add_f32 v20, 1.0, v20 :: v_dual_and_b32 v13, 0xffff0000, v13// 000000DD1AA4: C92428F2 140C1AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DD1AB0: BF870111
	v_mul_f32_e32 v19, 0xbfb8aa3b, v13                         // 000000DD1AB4: 10261AFF BFB8AA3B
	v_div_scale_f32 v24, null, v20, v20, v16                   // 000000DD1ABC: D6FC7C18 04422914
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000DD1AC4: BF8701B2
	v_exp_f32_e32 v19, v19                                     // 000000DD1AC8: 7E264B13
	v_lshlrev_b32_e32 v18, 16, v14                             // 000000DD1ACC: 30241C90
	v_div_scale_f32 v37, s9, v16, v20, v16                     // 000000DD1AD0: D6FC0925 04422910
	v_rcp_f32_e32 v28, v24                                     // 000000DD1AD8: 7E385518
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DD1ADC: BF870196
	v_add_f32_e32 v19, 1.0, v19                                // 000000DD1AE0: 062626F2
	v_mul_f32_e32 v21, 0xbfb8aa3b, v18                         // 000000DD1AE4: 102A24FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DD1AEC: BF870195
	v_fma_f32 v36, -v24, v28, 1.0                              // 000000DD1AF0: D6130024 23CA3918
	v_div_scale_f32 v23, null, v19, v19, v13                   // 000000DD1AF8: D6FC7C17 04362713
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DD1B00: BF870003
	v_exp_f32_e32 v21, v21                                     // 000000DD1B04: 7E2A4B15
	v_and_b32_e32 v14, 0xffff0000, v14                         // 000000DD1B08: 361C1CFF FFFF0000
	v_div_scale_f32 v33, vcc_lo, v13, v19, v13                 // 000000DD1B10: D6FC6A21 0436270D
	v_fmac_f32_e32 v28, v36, v28                               // 000000DD1B18: 56383924
	v_rcp_f32_e32 v26, v23                                     // 000000DD1B1C: 7E345517
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_3)   // 000000DD1B20: BF870186
	v_dual_add_f32 v21, 1.0, v21 :: v_dual_mul_f32 v22, 0xbfb8aa3b, v14// 000000DD1B24: C9062AF2 15161CFF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DD1B30: BF870115
	v_fma_f32 v34, -v23, v26, 1.0                              // 000000DD1B34: D6130022 23CA3517
	v_div_scale_f32 v25, null, v21, v21, v18                   // 000000DD1B3C: D6FC7C19 044A2B15
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DD1B44: BF8701A3
	v_exp_f32_e32 v22, v22                                     // 000000DD1B48: 7E2C4B16
	v_div_scale_f32 v35, s8, v18, v21, v18                     // 000000DD1B4C: D6FC0823 044A2B12
	v_fmac_f32_e32 v26, v34, v26                               // 000000DD1B54: 56343522
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000DD1B58: BF870293
	v_rcp_f32_e32 v30, v25                                     // 000000DD1B5C: 7E3C5519
	v_fma_f32 v38, -v25, v30, 1.0                              // 000000DD1B60: D6130026 23CA3D19
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DD1B68: BF870191
	v_fmac_f32_e32 v30, v38, v30                               // 000000DD1B6C: 563C3D26
	v_mul_f32_e32 v38, v33, v26                                // 000000DD1B70: 104C3521
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DD1B74: BF870112
	v_mul_f32_e32 v40, v35, v30                                // 000000DD1B78: 10503D23
	v_fma_f32 v41, -v23, v38, v33                              // 000000DD1B7C: D6130029 24864D17
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DD1B84: BF870112
	v_fma_f32 v44, -v25, v40, v35                              // 000000DD1B88: D613002C 248E5119
	v_fmac_f32_e32 v38, v41, v26                               // 000000DD1B90: 564C3529
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DD1B94: BF870112
	v_fmac_f32_e32 v40, v44, v30                               // 000000DD1B98: 56503D2C
	v_fma_f32 v23, -v23, v38, v33                              // 000000DD1B9C: D6130017 24864D17
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DD1BA4: BF870112
	v_fma_f32 v25, -v25, v40, v35                              // 000000DD1BA8: D6130019 248E5119
	v_div_fmas_f32 v23, v23, v26, v38                          // 000000DD1BB0: D6370017 049A3517
	s_mov_b32 vcc_lo, s9                                       // 000000DD1BB8: BEEA0009
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD1BBC: BF870091
	v_div_fixup_f32 v13, v23, v19, v13                         // 000000DD1BC0: D627000D 04362717
	v_dual_add_f32 v22, 1.0, v22 :: v_dual_mul_f32 v13, v13, v39// 000000DD1BC8: C9062CF2 160C4F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DD1BD0: BF8701A1
	v_div_scale_f32 v27, null, v22, v22, v14                   // 000000DD1BD4: D6FC7C1B 043A2D16
	v_div_scale_f32 v36, s10, v14, v22, v14                    // 000000DD1BDC: D6FC0A24 043A2D0E
	.long 0x7e3a398d                                           // 000000DD1BE4: 7E3A398D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000DD1BE8: BF870293
	v_rcp_f32_e32 v31, v27                                     // 000000DD1BEC: 7E3E551B
	v_fma_f32 v34, -v27, v31, 1.0                              // 000000DD1BF0: D6130022 23CA3F1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD1BF8: BF870091
	v_dual_fmac_f32 v31, v34, v31 :: v_dual_mul_f32 v34, v37, v28// 000000DD1BFC: C8063F22 1F223925
	v_mul_f32_e32 v42, v36, v31                                // 000000DD1C04: 10543F24
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DD1C08: BF870112
	v_fma_f32 v43, -v24, v34, v37                              // 000000DD1C0C: D613002B 24964518
	v_fma_f32 v41, -v27, v42, v36                              // 000000DD1C14: D6130029 2492551B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DD1C1C: BF870112
	v_fmac_f32_e32 v34, v43, v28                               // 000000DD1C20: 5644392B
	v_fmac_f32_e32 v42, v41, v31                               // 000000DD1C24: 56543F29
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DD1C28: BF870112
	v_fma_f32 v24, -v24, v34, v37                              // 000000DD1C2C: D6130018 24964518
	v_fma_f32 v23, -v27, v42, v36                              // 000000DD1C34: D6130017 2492551B
	s_delay_alu instid0(VALU_DEP_2)                            // 000000DD1C3C: BF870002
	v_div_fmas_f32 v24, v24, v28, v34                          // 000000DD1C40: D6370018 048A3918
	s_mov_b32 vcc_lo, s8                                       // 000000DD1C48: BEEA0008
	s_mov_b32 s8, 0                                            // 000000DD1C4C: BE880080
	v_div_fmas_f32 v19, v25, v30, v40                          // 000000DD1C50: D6370013 04A23D19
	s_mov_b32 vcc_lo, s10                                      // 000000DD1C58: BEEA000A
	v_div_fixup_f32 v16, v24, v20, v16                         // 000000DD1C5C: D6270010 04422918
	v_lshlrev_b32_e32 v20, 16, v7                              // 000000DD1C64: 30280E90
	v_and_b32_e32 v7, 0xffff0000, v7                           // 000000DD1C68: 360E0EFF FFFF0000
	v_div_fixup_f32 v18, v19, v21, v18                         // 000000DD1C70: D6270012 044A2B13
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DD1C78: BF8701A4
	v_mul_f32_e32 v6, v16, v6                                  // 000000DD1C7C: 100C0D10
	v_div_fmas_f32 v16, v23, v31, v42                          // 000000DD1C80: D6370010 04AA3F17
	v_mul_f32_e32 v18, v18, v20                                // 000000DD1C88: 10242912
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DD1C8C: BF870193
	.long 0x7e403986                                           // 000000DD1C90: 7E403986
	v_div_fixup_f32 v14, v16, v22, v14                         // 000000DD1C94: D627000E 043A2D10
	v_and_b32_e32 v16, 1, v29                                  // 000000DD1C9C: 36203A81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DD1CA0: BF870194
	v_bfe_u32 v19, v18, 16, 1                                  // 000000DD1CA4: D6100013 02052112
	v_dual_mul_f32 v7, v14, v7 :: v_dual_and_b32 v20, 1, v32   // 000000DD1CAC: C8E40F0E 07144081
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DD1CB4: BF870193
	v_add3_u32 v13, v13, v16, 0x7fff                           // 000000DD1CB8: D655000D 03FE210D 00007FFF
	v_add3_u32 v14, v18, v19, 0x7fff                           // 000000DD1CC4: D655000E 03FE2712 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DD1CD0: BF870213
	v_add3_u32 v6, v6, v20, 0x7fff                             // 000000DD1CD4: D6550006 03FE2906 00007FFF
	v_bfe_u32 v16, v7, 16, 1                                   // 000000DD1CE0: D6100010 02052107
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DD1CE8: BF870214
	v_and_b32_e32 v13, 0xffff0000, v13                         // 000000DD1CEC: 361A1AFF FFFF0000
	v_and_b32_e32 v18, 0xffff0000, v14                         // 000000DD1CF4: 36241CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DD1CFC: BF870214
	v_and_b32_e32 v6, 0xffff0000, v6                           // 000000DD1D00: 360C0CFF FFFF0000
	v_add3_u32 v7, v7, v16, 0x7fff                             // 000000DD1D08: D6550007 03FE2107 00007FFF
	s_waitcnt vmcnt(1)                                         // 000000DD1D14: BF8907F7
	v_fma_mix_f32 v14, v17, v13, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DD1D18: CC20080E 8A021B11
	s_waitcnt vmcnt(0)                                         // 000000DD1D20: BF8903F7
	v_fma_mix_f32 v13, v15, v18, neg(0) op_sel_hi:[1,0,0]      // 000000DD1D24: CC20000D 8A02250F
	v_fma_mix_f32 v16, v17, v6, neg(0) op_sel_hi:[1,0,0]       // 000000DD1D2C: CC200010 8A020D11
	v_and_b32_e32 v15, 0xffff0000, v7                          // 000000DD1D34: 361E0EFF FFFF0000
	s_and_not1_b32 vcc_lo, exec_lo, s8                         // 000000DD1D3C: 916A087E
	s_cbranch_vccnz 65129                                      // 000000DD1D40: BFA4FE69 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi1ELi4EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x1e8>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD1D44: BF870093
	.long 0xd73c0004                                           // 000000DD1D48: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 000000DD1D4C: 02020881
	.long 0xd7006a04                                           // 000000DD1D50: D7006A04
	v_cndmask_b32_e32 v1, s24, v4, vcc_lo                      // 000000DD1D54: 02020818
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DD1D58: BF870111
	v_add_co_ci_u32_e64 v5, null, s25, v5, vcc_lo              // 000000DD1D5C: D5207C05 01AA0A19
	.long 0xd7006a04                                           // 000000DD1D64: D7006A04
	v_cndmask_b32_e32 v1, v4, v2, vcc_lo                       // 000000DD1D68: 02020504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DD1D6C: BF8700A1
	v_add_co_ci_u32_e64 v5, null, v5, v3, vcc_lo               // 000000DD1D70: D5207C05 01AA0705
	.long 0xd7006a06                                           // 000000DD1D78: D7006A06
	v_cndmask_b32_e32 v1, s20, v2, vcc_lo                      // 000000DD1D7C: 02020414
	v_add_co_ci_u32_e64 v7, null, s21, v3, vcc_lo              // 000000DD1D80: D5207C07 01AA0615
	global_load_b64 v[4:5], v[4:5], off                        // 000000DD1D88: DC560000 047C0004
	s_clause 0x1                                               // 000000DD1D90: BF850001
	global_load_b32 v15, v[6:7], off                           // 000000DD1D94: DC520000 0F7C0006
	global_load_d16_b16 v6, v[6:7], off offset:4               // 000000DD1D9C: DC820004 067C0006
	s_waitcnt vmcnt(2)                                         // 000000DD1DA4: BF890BF7
	.long 0x7e0e3904                                           // 000000DD1DA8: 7E0E3904
	v_and_b32_e32 v4, 0xffff0000, v4                           // 000000DD1DAC: 360808FF FFFF0000
	v_lshlrev_b32_e32 v13, 16, v5                              // 000000DD1DB4: 301A0A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DD1DB8: BF8701A3
	v_lshlrev_b32_e32 v7, 16, v7                               // 000000DD1DBC: 300E0E90
	s_waitcnt vmcnt(1)                                         // 000000DD1DC0: BF8907F7
	v_fma_mix_f32 v14, v15, v4, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DD1DC4: CC20080E 8A02090F
	s_waitcnt vmcnt(0)                                         // 000000DD1DCC: BF8903F7
	v_fma_mix_f32 v13, v6, v13, neg(0) op_sel_hi:[1,0,0]       // 000000DD1DD0: CC20000D 8A021B06
	v_fma_mix_f32 v16, v15, v7, neg(0) op_sel_hi:[1,0,0]       // 000000DD1DD8: CC200010 8A020F0F
	v_and_b32_e32 v15, 0xffff0000, v5                          // 000000DD1DE0: 361E0AFF FFFF0000
	s_branch 65087                                             // 000000DD1DE8: BFA0FE3F <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi1ELi4EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x1e8>
	s_or_b32 exec_lo, exec_lo, s42                             // 000000DD1DEC: 8C7E2A7E
	s_bfe_i32 s42, s43, 0x1001c                                // 000000DD1DF0: 93AAFF2B 0001001C
	s_lshl_b32 s6, s39, 3                                      // 000000DD1DF8: 84068327
	s_lshr_b64 s[4:5], s[42:43], 29                            // 000000DD1DFC: 85849D2A
	s_lshr_b32 s5, s35, 28                                     // 000000DD1E00: 85059C23
	s_add_i32 s3, s4, 7                                        // 000000DD1E04: 81038704
	s_add_i32 s5, s38, s5                                      // 000000DD1E08: 81050526
	s_ashr_i32 s3, s3, 3                                       // 000000DD1E0C: 86038303
	s_lshl_b32 s4, s43, 3                                      // 000000DD1E10: 8404832B
	.long 0xd72c0001                                           // 000000DD1E14: D72C0001
	v_cndmask_b32_e32 v1, s3, v8, vcc_lo                       // 000000DD1E18: 02021003
	s_waitcnt lgkmcnt(0)                                       // 000000DD1E1C: BF89FC07
	s_barrier                                                  // 000000DD1E20: BFBD0000
	buffer_gl0_inv                                             // 000000DD1E24: E0AC0000 00000000
	v_add_nc_u32_e32 v0, s3, v1                                // 000000DD1E2C: 4A000203
	s_ashr_i32 s3, s5, 4                                       // 000000DD1E30: 86038405
	s_ashr_i32 s5, s6, 31                                      // 000000DD1E34: 86059F06
	s_mul_hi_i32 s7, s34, s3                                   // 000000DD1E38: 97070322
	s_mul_i32 s3, s34, s3                                      // 000000DD1E3C: 96030322
	v_min_i32_e32 v7, s4, v0                                   // 000000DD1E40: 220E0004
	s_add_u32 s4, s3, s6                                       // 000000DD1E44: 80040603
	s_addc_u32 s5, s7, s5                                      // 000000DD1E48: 82050507
	v_lshlrev_b32_e32 v0, 2, v9                                // 000000DD1E4C: 30001282
	s_lshl_b64 s[4:5], s[4:5], 10                              // 000000DD1E50: 84848A04
	v_cmp_lt_i32_e32 vcc_lo, v1, v7                            // 000000DD1E54: 7C820F01
	s_add_u32 s4, s18, s4                                      // 000000DD1E58: 80040412
	s_addc_u32 s5, s19, s5                                     // 000000DD1E5C: 82050513
	s_and_saveexec_b32 s6, vcc_lo                              // 000000DD1E60: BE86206A
	s_cbranch_execz 92                                         // 000000DD1E64: BFA5005C <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi1ELi4EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0xad8>
	.long 0xd7010302                                           // 000000DD1E68: D7010302
	v_cndmask_b32_e32 v0, v9, v129, vcc_lo                     // 000000DD1E6C: 02010309
	v_mov_b32_e32 v4, 0                                        // 000000DD1E70: 7E080280
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DD1E74: BF870122
	v_cndmask_b32_e64 v3, v2, 31, s3                           // 000000DD1E78: D5010003 000D3F02
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000DD1E80: 3404029F
	.long 0xd44c0003                                           // 000000DD1E84: D44C0003
	v_cndmask_b32_e32 v1, 31, v3, vcc_lo                       // 000000DD1E88: 0202069F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD1E8C: BF870091
	v_cndmask_b32_e64 v5, 0xe1, 1, s3                          // 000000DD1E90: D5010005 000D02FF 000000E1
	v_add_nc_u32_e32 v10, v5, v3                               // 000000DD1E9C: 4A140705
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DD1EA0: BF8701A4
	.long 0xd73c0005                                           // 000000DD1EA4: D73C0005
	v_cndmask_b32_e32 v1, 10, v1, vcc_lo                       // 000000DD1EA8: 0202028A
	.long 0xd73c0002                                           // 000000DD1EAC: D73C0002
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 000000DD1EB0: 02020682
	v_lshlrev_b32_e32 v4, 24, v10                              // 000000DD1EB4: 30081498
	v_bfe_i32 v11, v10, 7, 1                                   // 000000DD1EB8: D611000B 02050F0A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD1EC0: BF870094
	.long 0xd700030c                                           // 000000DD1EC4: D700030C
	v_cndmask_b32_e32 v1, s4, v5, vcc_lo                       // 000000DD1EC8: 02020A04
	v_add_co_ci_u32_e64 v6, null, s5, v6, s3                   // 000000DD1ECC: D5207C06 000E0C05
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DD1ED4: BF870194
	v_ashrrev_i32_e32 v10, 22, v4                              // 000000DD1ED8: 34140896
	.long 0xd7000304                                           // 000000DD1EDC: D7000304
	v_cndmask_b32_e32 v1, v12, v2, vcc_lo                      // 000000DD1EE0: 0202050C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DD1EE4: BF870191
	v_add_co_ci_u32_e64 v5, null, v6, v3, s3                   // 000000DD1EE8: D5207C05 000E0706
	.long 0xd700030a                                           // 000000DD1EF0: D700030A
	v_cndmask_b32_e32 v1, v12, v10, vcc_lo                     // 000000DD1EF4: 0202150C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DD1EF8: BF8700A1
	v_add_co_ci_u32_e64 v11, null, v6, v11, s3                 // 000000DD1EFC: D5207C0B 000E1706
	.long 0xd700030c                                           // 000000DD1F04: D700030C
	v_cndmask_b32_e32 v1, v12, v0, vcc_lo                      // 000000DD1F08: 0202010C
	v_add_co_ci_u32_e64 v13, null, 0, v6, s3                   // 000000DD1F0C: D5207C0D 000E0C80
	s_clause 0x17                                              // 000000DD1F14: BF850017
	global_load_b32 v2, v[4:5], off                            // 000000DD1F18: DC520000 027C0004
	global_load_b32 v55, v[4:5], off offset:128                // 000000DD1F20: DC520080 377C0004
	global_load_b32 v52, v[4:5], off offset:256                // 000000DD1F28: DC520100 347C0004
	global_load_b32 v49, v[4:5], off offset:384                // 000000DD1F30: DC520180 317C0004
	global_load_b32 v46, v[4:5], off offset:512                // 000000DD1F38: DC520200 2E7C0004
	global_load_b32 v43, v[4:5], off offset:640                // 000000DD1F40: DC520280 2B7C0004
	global_load_b32 v25, v[4:5], off offset:768                // 000000DD1F48: DC520300 197C0004
	global_load_b32 v19, v[4:5], off offset:896                // 000000DD1F50: DC520380 137C0004
	global_load_b32 v4, v[10:11], off                          // 000000DD1F58: DC520000 047C000A
	global_load_b32 v56, v[10:11], off offset:128              // 000000DD1F60: DC520080 387C000A
	global_load_b32 v53, v[10:11], off offset:256              // 000000DD1F68: DC520100 357C000A
	global_load_b32 v50, v[10:11], off offset:384              // 000000DD1F70: DC520180 327C000A
	global_load_b32 v47, v[10:11], off offset:512              // 000000DD1F78: DC520200 2F7C000A
	global_load_b32 v44, v[10:11], off offset:640              // 000000DD1F80: DC520280 2C7C000A
	global_load_b32 v26, v[10:11], off offset:768              // 000000DD1F88: DC520300 1A7C000A
	global_load_b32 v20, v[10:11], off offset:896              // 000000DD1F90: DC520380 147C000A
	global_load_b32 v3, v[12:13], off                          // 000000DD1F98: DC520000 037C000C
	global_load_b32 v54, v[12:13], off offset:128              // 000000DD1FA0: DC520080 367C000C
	global_load_b32 v51, v[12:13], off offset:256              // 000000DD1FA8: DC520100 337C000C
	global_load_b32 v48, v[12:13], off offset:384              // 000000DD1FB0: DC520180 307C000C
	global_load_b32 v45, v[12:13], off offset:512              // 000000DD1FB8: DC520200 2D7C000C
	global_load_b32 v42, v[12:13], off offset:640              // 000000DD1FC0: DC520280 2A7C000C
	global_load_b32 v24, v[12:13], off offset:768              // 000000DD1FC8: DC520300 187C000C
	global_load_b32 v18, v[12:13], off offset:896              // 000000DD1FD0: DC520380 127C000C
	s_or_b32 exec_lo, exec_lo, s6                              // 000000DD1FD8: 8C7E067E
	v_dual_mov_b32 v11, 0 :: v_dual_mov_b32 v10, 0             // 000000DD1FDC: CA100080 0B0A0080
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v13, 0             // 000000DD1FE4: CA100080 0C0C0080
	v_dual_mov_b32 v14, 0 :: v_dual_mov_b32 v15, 0             // 000000DD1FEC: CA100080 0E0E0080
	v_dual_mov_b32 v16, 0 :: v_dual_mov_b32 v17, 0             // 000000DD1FF4: CA100080 10100080
	s_ashr_i32 s35, s34, 31                                    // 000000DD1FFC: 86239F22
	s_and_saveexec_b32 s3, vcc_lo                              // 000000DD2000: BE83206A
	s_cbranch_execz 959                                        // 000000DD2004: BFA503BF <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi1ELi4EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x1a04>
	v_dual_mov_b32 v10, 0 :: v_dual_add_nc_u32 v5, -1, v65     // 000000DD2008: CA200080 0A0482C1
	v_dual_mov_b32 v11, 0 :: v_dual_lshlrev_b32 v22, 2, v9     // 000000DD2010: CA220080 0B161282
	v_and_or_b32 v21, v65, 16, 0x5000                          // 000000DD2018: D6570015 03FD2141 00005000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000DD2024: BF8701B3
	v_dual_mov_b32 v12, 0 :: v_dual_and_b32 v5, 31, v5         // 000000DD2028: CA240080 0C040A9F
	v_dual_mov_b32 v13, 0 :: v_dual_mov_b32 v14, 0             // 000000DD2030: CA100080 0D0E0080
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v16, 0             // 000000DD2038: CA100080 0F100080
	v_lshlrev_b32_e32 v23, 2, v5                               // 000000DD2040: 302E0A82
	v_mov_b32_e32 v17, 0                                       // 000000DD2044: 7E220280
	s_mov_b32 s6, 0                                            // 000000DD2048: BE860080
	s_movk_i32 s7, 0x1eee                                      // 000000DD204C: B0071EEE
	s_branch 881                                               // 000000DD2050: BFA00371 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi1ELi4EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x1918>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000DD2054: 8C7E087E
	s_waitcnt vmcnt(15)                                        // 000000DD2058: BF893FF7
	v_alignbit_b32 v57, v2, v4, 16                             // 000000DD205C: D6160039 02420902
	s_waitcnt vmcnt(7)                                         // 000000DD2064: BF891FF7
	v_bfe_u32 v58, v3, 12, 16                                  // 000000DD2068: D610003A 02411903
	v_bfe_u32 v59, v3, 8, 16                                   // 000000DD2070: D610003B 02411103
	v_lshl_add_u32 v1, v1, 5, v21                              // 000000DD2078: D6460001 04550B01
	v_bfe_u32 v60, v3, 4, 16                                   // 000000DD2080: D610003C 02410903
	v_bfe_u32 v61, v57, 12, 16                                 // 000000DD2088: D610003D 02411939
	v_bfe_u32 v64, v57, 8, 16                                  // 000000DD2090: D6100040 02411139
	.long 0xd72c003a                                           // 000000DD2098: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000DD209C: 020274FF 83DCD12D
	.long 0xd72c003b                                           // 000000DD20A4: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000DD20A8: 020276FF 83DCD12D
	.long 0xd72c003c                                           // 000000DD20B0: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000DD20B4: 020278FF 83DCD12D
	.long 0xd72c003d                                           // 000000DD20BC: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000DD20C0: 02027AFF 83DCD12D
	.long 0xd72c0040                                           // 000000DD20C8: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000DD20CC: 020280FF 83DCD12D
	v_alignbit_b32 v55, v55, v56, 16                           // 000000DD20D4: D6160037 02427137
	v_alignbit_b32 v52, v52, v53, 16                           // 000000DD20DC: D6160034 02426B34
	v_alignbit_b32 v49, v49, v50, 16                           // 000000DD20E4: D6160031 02426531
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000DD20EC: D622003A 03FD013A 00006400
	v_sad_u8 v59, v59, 0, 0x6400                               // 000000DD20F8: D622003B 03FD013B 00006400
	v_sad_u8 v60, v60, 0, 0x6400                               // 000000DD2104: D622003C 03FD013C 00006400
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000DD2110: D622003D 03FD013D 00006400
	v_sad_u8 v64, v64, 0, 0x6400                               // 000000DD211C: D6220040 03FD0140 00006400
	v_and_b32_e32 v58, 0xffff, v58                             // 000000DD2128: 367474FF 0000FFFF
	v_bfe_u32 v50, v49, 12, 16                                 // 000000DD2130: D6100032 02411931
	v_alignbit_b32 v46, v46, v47, 16                           // 000000DD2138: D616002E 02425F2E
	v_and_b32_e32 v61, 0xffff, v61                             // 000000DD2140: 367A7AFF 0000FFFF
	v_alignbit_b32 v25, v25, v26, 16                           // 000000DD2148: D6160019 02423519
	v_lshl_or_b32 v58, v59, 16, v58                            // 000000DD2150: D656003A 04E9213B
	.long 0xd72c0032                                           // 000000DD2158: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 000000DD215C: 020264FF 83DCD12D
	v_alignbit_b32 v43, v43, v44, 16                           // 000000DD2164: D616002B 0242592B
	v_lshl_or_b32 v61, v64, 16, v61                            // 000000DD216C: D656003D 04F52140
	s_waitcnt vmcnt(5)                                         // 000000DD2174: BF8917F7
	v_bfe_u32 v64, v51, 4, 16                                  // 000000DD2178: D6100040 02410933
	v_pk_fma_f16 v58, v58, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DD2180: CC0E003A 0BFC0F3A 0000C931
	v_alignbit_b32 v19, v19, v20, 16                           // 000000DD218C: D6160013 02422913
	v_cmp_eq_u32_e32 vcc_lo, v5, v7                            // 000000DD2194: 7C940F05
	v_pk_fma_f16 v59, v61, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DD2198: CC0E003B 0BFC0F3D 0000C931
	v_and_b32_e32 v62, 0xffff, v3                              // 000000DD21A4: 367C06FF 0000FFFF
	ds_load_b128 v[1:4], v1                                    // 000000DD21AC: DBFC0000 01000001
	v_bfe_u32 v61, v54, 12, 16                                 // 000000DD21B4: D610003D 02411936
	v_sad_u8 v50, v50, 0, 0x6400                               // 000000DD21BC: D6220032 03FD0132 00006400
	s_or_b32 s6, vcc_lo, s6                                    // 000000DD21C8: 8C06066A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DD21CC: BF870112
	.long 0xd72c003d                                           // 000000DD21D0: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000DD21D4: 02027AFF 83DCD12D
	v_and_b32_e32 v50, 0xffff, v50                             // 000000DD21DC: 366464FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD21E4: BF870092
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000DD21E8: D622003D 03FD013D 00006400
	v_and_b32_e32 v61, 0xffff, v61                             // 000000DD21F4: 367A7AFF 0000FFFF
	s_waitcnt lgkmcnt(0)                                       // 000000DD21FC: BF89FC07
	v_dot2acc_f32_f16 v17, v59, v1                             // 000000DD2200: 0422033B
	.long 0xd72c003e                                           // 000000DD2204: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000DD2208: 02027CFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD2210: BF870091
	v_sad_u8 v62, v62, 0, 0x6400                               // 000000DD2214: D622003E 03FD013E 00006400
	v_lshlrev_b32_e32 v62, 16, v62                             // 000000DD2220: 307C7C90
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000DD2224: BF8701B1
	v_and_or_b32 v56, 0xffff, v60, v62                         // 000000DD2228: D6570038 04FA78FF 0000FFFF
	v_bfe_u32 v60, v55, 12, 16                                 // 000000DD2234: D610003C 02411937
	v_bfe_u32 v62, v55, 8, 16                                  // 000000DD223C: D610003E 02411137
	v_pk_fma_f16 v56, v56, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DD2244: CC0E0038 0BFC0F38 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DD2250: BF870193
	.long 0xd72c003c                                           // 000000DD2254: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000DD2258: 020278FF 83DCD12D
	.long 0xd72c003e                                           // 000000DD2260: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000DD2264: 02027CFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DD226C: BF870112
	v_sad_u8 v60, v60, 0, 0x6400                               // 000000DD2270: D622003C 03FD013C 00006400
	v_sad_u8 v62, v62, 0, 0x6400                               // 000000DD227C: D622003E 03FD013E 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD2288: BF870092
	v_and_b32_e32 v60, 0xffff, v60                             // 000000DD228C: 367878FF 0000FFFF
	v_lshl_or_b32 v60, v62, 16, v60                            // 000000DD2294: D656003C 04F1213E
	v_bfe_u32 v62, v51, 12, 16                                 // 000000DD229C: D610003E 02411933
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000DD22A4: BF870232
	v_pk_fma_f16 v53, v60, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DD22A8: CC0E0035 0BFC0F3C 0000C931
	v_and_b32_e32 v59, 0xffff, v55                             // 000000DD22B4: 36766EFF 0000FFFF
	v_bfe_u32 v55, v55, 4, 16                                  // 000000DD22BC: D6100037 02410937
	.long 0xd72c003e                                           // 000000DD22C4: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000DD22C8: 02027CFF 83DCD12D
	v_and_b32_e32 v60, 0xffff, v52                             // 000000DD22D0: 367868FF 0000FFFF
	v_dot2acc_f32_f16 v16, v53, v1                             // 000000DD22D8: 04200335
	.long 0xd72c003b                                           // 000000DD22DC: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000DD22E0: 020276FF 83DCD12D
	.long 0xd72c0037                                           // 000000DD22E8: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000DD22EC: 02026EFF 83DCD12D
	.long 0xd72c0035                                           // 000000DD22F4: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000DD22F8: 020280FF 83DCD12D
	.long 0xd72c003c                                           // 000000DD2300: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000DD2304: 020278FF 83DCD12D
	v_sad_u8 v62, v62, 0, 0x6400                               // 000000DD230C: D622003E 03FD013E 00006400
	v_sad_u8 v59, v59, 0, 0x6400                               // 000000DD2318: D622003B 03FD013B 00006400
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000DD2324: D6220037 03FD0137 00006400
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000DD2330: D6220035 03FD0135 00006400
	v_sad_u8 v60, v60, 0, 0x6400                               // 000000DD233C: D622003C 03FD013C 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD2348: BF870094
	v_lshlrev_b32_e32 v59, 16, v59                             // 000000DD234C: 30767690
	v_and_or_b32 v55, 0xffff, v55, v59                         // 000000DD2350: D6570037 04EE6EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000DD235C: BF8701B1
	v_pk_fma_f16 v55, v55, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DD2360: CC0E0037 0BFC0F37 0000C931
	v_and_b32_e32 v63, 0xffff, v57                             // 000000DD236C: 367E72FF 0000FFFF
	v_bfe_u32 v57, v57, 4, 16                                  // 000000DD2374: D6100039 02410939
	v_dot2acc_f32_f16 v16, v55, v2                             // 000000DD237C: 04200537
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DD2380: BF870193
	.long 0xd72c003f                                           // 000000DD2384: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000DD2388: 02027EFF 83DCD12D
	.long 0xd72c0039                                           // 000000DD2390: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 000000DD2394: 020272FF 83DCD12D
	s_waitcnt vmcnt(4)                                         // 000000DD239C: BF8913F7
	v_bfe_u32 v55, v48, 4, 16                                  // 000000DD23A0: D6100037 02410930
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DD23A8: BF870193
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000DD23AC: D622003F 03FD013F 00006400
	v_sad_u8 v57, v57, 0, 0x6400                               // 000000DD23B8: D6220039 03FD0139 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD23C4: BF870092
	v_lshlrev_b32_e32 v63, 16, v63                             // 000000DD23C8: 307E7E90
	v_and_or_b32 v57, 0xffff, v57, v63                         // 000000DD23CC: D6570039 04FE72FF 0000FFFF
	v_bfe_u32 v63, v54, 8, 16                                  // 000000DD23D8: D610003F 02411136
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD23E0: BF870092
	v_pk_fma_f16 v57, v57, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DD23E4: CC0E0039 0BFC0F39 0000C931
	v_dot2acc_f32_f16 v17, v57, v2                             // 000000DD23F0: 04220539
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DD23F4: BF8701A3
	.long 0xd72c0039                                           // 000000DD23F8: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000DD23FC: 02027EFF 83DCD12D
	v_bfe_u32 v63, v54, 4, 16                                  // 000000DD2404: D610003F 02410936
	v_dot2acc_f32_f16 v17, v58, v3                             // 000000DD240C: 0422073A
	v_bfe_u32 v58, v52, 12, 16                                 // 000000DD2410: D610003A 02411934
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DD2418: BF870003
	.long 0xd72c003b                                           // 000000DD241C: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000DD2420: 02027EFF 83DCD12D
	v_bfe_u32 v63, v51, 8, 16                                  // 000000DD2428: D610003F 02411133
	v_sad_u8 v57, v57, 0, 0x6400                               // 000000DD2430: D6220039 03FD0139 00006400
	v_and_b32_e32 v51, 0xffff, v51                             // 000000DD243C: 366666FF 0000FFFF
	.long 0xd72c003a                                           // 000000DD2444: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000DD2448: 020274FF 83DCD12D
	v_dual_dot2acc_f32_f16 v17, v56, v4 :: v_dual_and_b32 v54, 0xffff, v54// 000000DD2450: CB240938 11366CFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DD245C: BF870004
	v_lshl_or_b32 v57, v57, 16, v61                            // 000000DD2460: D6560039 04F52139
	v_bfe_u32 v61, v52, 8, 16                                  // 000000DD2468: D610003D 02411134
	v_bfe_u32 v52, v52, 4, 16                                  // 000000DD2470: D6100034 02410934
	.long 0xd72c0033                                           // 000000DD2478: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 000000DD247C: 020266FF 83DCD12D
	.long 0xd72c003f                                           // 000000DD2484: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000DD2488: 02027EFF 83DCD12D
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000DD2490: D622003A 03FD013A 00006400
	.long 0xd72c003d                                           // 000000DD249C: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000DD24A0: 02027AFF 83DCD12D
	.long 0xd72c0034                                           // 000000DD24A8: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 000000DD24AC: 020268FF 83DCD12D
	.long 0xd72c0036                                           // 000000DD24B4: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 000000DD24B8: 02026CFF 83DCD12D
	v_sad_u8 v59, v59, 0, 0x6400                               // 000000DD24C0: D622003B 03FD013B 00006400
	v_and_b32_e32 v58, 0xffff, v58                             // 000000DD24CC: 367474FF 0000FFFF
	v_sad_u8 v51, v51, 0, 0x6400                               // 000000DD24D4: D6220033 03FD0133 00006400
	v_pk_fma_f16 v57, v57, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DD24E0: CC0E0039 0BFC0F39 0000C931
	s_waitcnt vmcnt(3)                                         // 000000DD24EC: BF890FF7
	v_bfe_u32 v56, v45, 8, 16                                  // 000000DD24F0: D6100038 0241112D
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000DD24F8: D622003D 03FD013D 00006400
	v_sad_u8 v52, v52, 0, 0x6400                               // 000000DD2504: D6220034 03FD0134 00006400
	v_lshlrev_b32_e32 v51, 16, v51                             // 000000DD2510: 30666690
	v_sad_u8 v54, v54, 0, 0x6400                               // 000000DD2514: D6220036 03FD0136 00006400
	v_dot2acc_f32_f16 v16, v57, v3                             // 000000DD2520: 04200739
	v_lshl_or_b32 v58, v61, 16, v58                            // 000000DD2524: D656003A 04E9213D
	v_sad_u8 v61, v63, 0, 0x6400                               // 000000DD252C: D622003D 03FD013F 00006400
	v_and_or_b32 v51, 0xffff, v53, v51                         // 000000DD2538: D6570033 04CE6AFF 0000FFFF
	.long 0xd72c0038                                           // 000000DD2544: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000DD2548: 020270FF 83DCD12D
	v_bfe_u32 v57, v45, 4, 16                                  // 000000DD2550: D6100039 0241092D
	v_pk_fma_f16 v58, v58, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DD2558: CC0E003A 0BFC0F3A 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DD2564: BF870114
	v_pk_fma_f16 v51, v51, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DD2568: CC0E0033 0BFC0F33 0000C931
	v_dual_dot2acc_f32_f16 v15, v58, v1 :: v_dual_lshlrev_b32 v60, 16, v60// 000000DD2574: CB22033A 0F3C7890
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DD257C: BF870121
	v_and_or_b32 v52, 0xffff, v52, v60                         // 000000DD2580: D6570034 04F268FF 0000FFFF
	v_and_b32_e32 v60, 0xffff, v62                             // 000000DD258C: 36787CFF 0000FFFF
	v_pk_fma_f16 v52, v52, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DD2594: CC0E0034 0BFC0F34 0000C931
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DD25A0: BF870112
	v_lshl_or_b32 v60, v61, 16, v60                            // 000000DD25A4: D656003C 04F1213D
	v_dot2acc_f32_f16 v15, v52, v2                             // 000000DD25AC: 041E0534
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD25B0: BF870092
	v_pk_fma_f16 v53, v60, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DD25B4: CC0E0035 0BFC0F3C 0000C931
	v_dual_dot2acc_f32_f16 v15, v53, v3 :: v_dual_lshlrev_b32 v54, 16, v54// 000000DD25C0: CB220735 0F366C90
	v_bfe_u32 v53, v48, 12, 16                                 // 000000DD25C8: D6100035 02411930
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DD25D0: BF870192
	v_dot2acc_f32_f16 v15, v51, v4                             // 000000DD25D4: 041E0933
	v_and_or_b32 v54, 0xffff, v59, v54                         // 000000DD25D8: D6570036 04DA76FF 0000FFFF
	v_bfe_u32 v51, v49, 8, 16                                  // 000000DD25E4: D6100033 02411131
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DD25EC: BF870194
	.long 0xd72c0035                                           // 000000DD25F0: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000DD25F4: 02026AFF 83DCD12D
	v_pk_fma_f16 v52, v54, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DD25FC: CC0E0034 0BFC0F36 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000DD2608: BF870233
	.long 0xd72c0033                                           // 000000DD260C: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 000000DD2610: 020266FF 83DCD12D
	v_bfe_u32 v54, v48, 8, 16                                  // 000000DD2618: D6100036 02411130
	v_and_b32_e32 v48, 0xffff, v48                             // 000000DD2620: 366060FF 0000FFFF
	v_dot2acc_f32_f16 v16, v52, v4                             // 000000DD2628: 04200934
	v_and_b32_e32 v52, 0xffff, v49                             // 000000DD262C: 366862FF 0000FFFF
	v_bfe_u32 v49, v49, 4, 16                                  // 000000DD2634: D6100031 02410931
	.long 0xd72c0036                                           // 000000DD263C: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 000000DD2640: 02026CFF 83DCD12D
	v_sad_u8 v51, v51, 0, 0x6400                               // 000000DD2648: D6220033 03FD0133 00006400
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000DD2654: D6220035 03FD0135 00006400
	.long 0xd72c0034                                           // 000000DD2660: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 000000DD2664: 020268FF 83DCD12D
	.long 0xd72c0031                                           // 000000DD266C: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 000000DD2670: 020262FF 83DCD12D
	.long 0xd72c0030                                           // 000000DD2678: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 000000DD267C: 020260FF 83DCD12D
	v_lshl_or_b32 v50, v51, 16, v50                            // 000000DD2684: D6560032 04C92133
	.long 0xd72c0033                                           // 000000DD268C: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000DD2690: 02026EFF 83DCD12D
	v_sad_u8 v54, v54, 0, 0x6400                               // 000000DD2698: D6220036 03FD0136 00006400
	v_bfe_u32 v55, v45, 12, 16                                 // 000000DD26A4: D6100037 0241192D
	v_sad_u8 v52, v52, 0, 0x6400                               // 000000DD26AC: D6220034 03FD0134 00006400
	v_sad_u8 v49, v49, 0, 0x6400                               // 000000DD26B8: D6220031 03FD0131 00006400
	v_pk_fma_f16 v50, v50, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DD26C4: CC0E0032 0BFC0F32 0000C931
	v_sad_u8 v48, v48, 0, 0x6400                               // 000000DD26D0: D6220030 03FD0130 00006400
	v_sad_u8 v51, v51, 0, 0x6400                               // 000000DD26DC: D6220033 03FD0133 00006400
	v_lshlrev_b32_e32 v52, 16, v52                             // 000000DD26E8: 30686890
	.long 0xd72c0037                                           // 000000DD26EC: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000DD26F0: 02026EFF 83DCD12D
	v_dot2acc_f32_f16 v14, v50, v1                             // 000000DD26F8: 041C0332
	v_lshlrev_b32_e32 v48, 16, v48                             // 000000DD26FC: 30606090
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DD2700: BF8701A4
	v_and_or_b32 v49, 0xffff, v49, v52                         // 000000DD2704: D6570031 04D262FF 0000FFFF
	v_bfe_u32 v52, v46, 12, 16                                 // 000000DD2710: D6100034 0241192E
	v_and_or_b32 v48, 0xffff, v51, v48                         // 000000DD2718: D6570030 04C266FF 0000FFFF
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000DD2724: D6220037 03FD0137 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DD2730: BF870214
	v_pk_fma_f16 v49, v49, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DD2734: CC0E0031 0BFC0F31 0000C931
	.long 0xd72c0034                                           // 000000DD2740: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 000000DD2744: 020268FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000DD274C: BF8701B2
	v_dual_dot2acc_f32_f16 v14, v49, v2 :: v_dual_and_b32 v53, 0xffff, v53// 000000DD2750: CB240531 0E346AFF 0000FFFF
	s_waitcnt vmcnt(2)                                         // 000000DD275C: BF890BF7
	v_bfe_u32 v49, v42, 12, 16                                 // 000000DD2760: D6100031 0241192A
	v_sad_u8 v52, v52, 0, 0x6400                               // 000000DD2768: D6220034 03FD0134 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DD2774: BF870223
	v_lshl_or_b32 v47, v54, 16, v53                            // 000000DD2778: D656002F 04D52136
	v_bfe_u32 v54, v46, 8, 16                                  // 000000DD2780: D6100036 0241112E
	.long 0xd72c0031                                           // 000000DD2788: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 000000DD278C: 020262FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000DD2794: BF870254
	v_and_b32_e32 v52, 0xffff, v52                             // 000000DD2798: 366868FF 0000FFFF
	v_and_b32_e32 v53, 0xffff, v46                             // 000000DD27A0: 366A5CFF 0000FFFF
	v_bfe_u32 v46, v46, 4, 16                                  // 000000DD27A8: D610002E 0241092E
	.long 0xd72c0036                                           // 000000DD27B0: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 000000DD27B4: 02026CFF 83DCD12D
	v_pk_fma_f16 v47, v47, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DD27BC: CC0E002F 0BFC0F2F 0000C931
	.long 0xd72c0035                                           // 000000DD27C8: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000DD27CC: 02026AFF 83DCD12D
	v_sad_u8 v49, v49, 0, 0x6400                               // 000000DD27D4: D6220031 03FD0131 00006400
	.long 0xd72c002e                                           // 000000DD27E0: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 000000DD27E4: 02025CFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DD27EC: BF870224
	v_dot2acc_f32_f16 v14, v47, v3                             // 000000DD27F0: 041C072F
	v_sad_u8 v54, v54, 0, 0x6400                               // 000000DD27F4: D6220036 03FD0136 00006400
	v_and_b32_e32 v49, 0xffff, v49                             // 000000DD2800: 366262FF 0000FFFF
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000DD2808: D6220035 03FD0135 00006400
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DD2814: BF870003
	v_lshl_or_b32 v51, v54, 16, v52                            // 000000DD2818: D6560033 04D12136
	v_sad_u8 v46, v46, 0, 0x6400                               // 000000DD2820: D622002E 03FD012E 00006400
	v_sad_u8 v54, v56, 0, 0x6400                               // 000000DD282C: D6220036 03FD0138 00006400
	.long 0xd72c0034                                           // 000000DD2838: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 000000DD283C: 020272FF 83DCD12D
	v_mov_b32_e32 v56, v40                                     // 000000DD2844: 7E700328
	v_pk_fma_f16 v50, v51, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DD2848: CC0E0032 0BFC0F33 0000C931
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000DD2854: BF870131
	v_dot2acc_f32_f16 v13, v50, v1                             // 000000DD2858: 041A0332
	v_bfe_u32 v50, v42, 8, 16                                  // 000000DD285C: D6100032 0241112A
	v_sad_u8 v52, v52, 0, 0x6400                               // 000000DD2864: D6220034 03FD0134 00006400
	.long 0xd72c0032                                           // 000000DD2870: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 000000DD2874: 020264FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD287C: BF870091
	v_sad_u8 v50, v50, 0, 0x6400                               // 000000DD2880: D6220032 03FD0132 00006400
	v_lshl_or_b32 v26, v50, 16, v49                            // 000000DD288C: D656001A 04C52132
	s_waitcnt vmcnt(1)                                         // 000000DD2894: BF8907F7
	v_bfe_u32 v49, v24, 12, 16                                 // 000000DD2898: D6100031 02411918
	v_bfe_u32 v50, v25, 8, 16                                  // 000000DD28A0: D6100032 02411119
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DD28A8: BF870223
	v_pk_fma_f16 v26, v26, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DD28AC: CC0E001A 0BFC0F1A 0000C931
	v_lshlrev_b32_e32 v53, 16, v53                             // 000000DD28B8: 306A6A90
	.long 0xd72c0031                                           // 000000DD28BC: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 000000DD28C0: 020262FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DD28C8: BF870194
	.long 0xd72c0032                                           // 000000DD28CC: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 000000DD28D0: 020264FF 83DCD12D
	v_and_or_b32 v46, 0xffff, v46, v53                         // 000000DD28D8: D657002E 04D65CFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DD28E4: BF870113
	v_sad_u8 v49, v49, 0, 0x6400                               // 000000DD28E8: D6220031 03FD0131 00006400
	v_pk_fma_f16 v46, v46, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DD28F4: CC0E002E 0BFC0F2E 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DD2900: BF870194
	v_sad_u8 v50, v50, 0, 0x6400                               // 000000DD2904: D6220032 03FD0132 00006400
	v_and_b32_e32 v49, 0xffff, v49                             // 000000DD2910: 366262FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000DD2918: BF870253
	v_dot2acc_f32_f16 v13, v46, v2                             // 000000DD291C: 041A052E
	v_pk_fma_f16 v46, v48, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DD2920: CC0E002E 0BFC0F30 0000C931
	v_and_b32_e32 v53, 0xffff, v55                             // 000000DD292C: 366A6EFF 0000FFFF
	v_bfe_u32 v48, v43, 12, 16                                 // 000000DD2934: D6100030 0241192B
	v_mov_b32_e32 v55, v34                                     // 000000DD293C: 7E6E0322
	v_dot2acc_f32_f16 v14, v46, v4                             // 000000DD2940: 041C092E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DD2944: BF870214
	v_lshl_or_b32 v51, v54, 16, v53                            // 000000DD2948: D6560033 04D52136
	.long 0xd72c002f                                           // 000000DD2950: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 000000DD2954: 020260FF 83DCD12D
	v_dual_mov_b32 v53, v39 :: v_dual_mov_b32 v46, v29         // 000000DD295C: CA100127 352E011D
	v_mov_b32_e32 v54, v40                                     // 000000DD2964: 7E6C0328
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000DD2968: BF870244
	v_pk_fma_f16 v44, v51, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DD296C: CC0E002C 0BFC0F33 0000C931
	v_bfe_u32 v51, v42, 4, 16                                  // 000000DD2978: D6100033 0241092A
	v_and_b32_e32 v42, 0xffff, v42                             // 000000DD2980: 365454FF 0000FFFF
	v_sad_u8 v47, v47, 0, 0x6400                               // 000000DD2988: D622002F 03FD012F 00006400
	v_dot2acc_f32_f16 v13, v44, v3                             // 000000DD2994: 041A072C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DD2998: BF870214
	.long 0xd72c0033                                           // 000000DD299C: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 000000DD29A0: 020266FF 83DCD12D
	.long 0xd72c002a                                           // 000000DD29A8: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 000000DD29AC: 020254FF 83DCD12D
	v_bfe_u32 v44, v43, 8, 16                                  // 000000DD29B4: D610002C 0241112B
	v_and_b32_e32 v48, 0xffff, v43                             // 000000DD29BC: 366056FF 0000FFFF
	v_bfe_u32 v43, v43, 4, 16                                  // 000000DD29C4: D610002B 0241092B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 000000DD29CC: BF8701D3
	.long 0xd72c002c                                           // 000000DD29D0: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v44, vcc_lo              // 000000DD29D4: 020258FF 83DCD12D
	v_sad_u8 v51, v51, 0, 0x6400                               // 000000DD29DC: D6220033 03FD0133 00006400
	v_sad_u8 v42, v42, 0, 0x6400                               // 000000DD29E8: D622002A 03FD012A 00006400
	.long 0xd72c0030                                           // 000000DD29F4: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 000000DD29F8: 020260FF 83DCD12D
	.long 0xd72c002b                                           // 000000DD2A00: D72C002B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 000000DD2A04: 020256FF 83DCD12D
	v_lshlrev_b32_e32 v42, 16, v42                             // 000000DD2A0C: 30545490
	v_sad_u8 v44, v44, 0, 0x6400                               // 000000DD2A10: D622002C 03FD012C 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DD2A1C: BF870194
	v_sad_u8 v48, v48, 0, 0x6400                               // 000000DD2A20: D6220030 03FD0130 00006400
	v_and_or_b32 v42, 0xffff, v51, v42                         // 000000DD2A2C: D657002A 04AA66FF 0000FFFF
	v_sad_u8 v43, v43, 0, 0x6400                               // 000000DD2A38: D622002B 03FD012B 00006400
	v_bfe_u32 v51, v24, 8, 16                                  // 000000DD2A44: D6100033 02411118
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DD2A4C: BF870214
	v_lshlrev_b32_e32 v48, 16, v48                             // 000000DD2A50: 30606090
	v_pk_fma_f16 v42, v42, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DD2A54: CC0E002A 0BFC0F2A 0000C931
	v_and_b32_e32 v47, 0xffff, v47                             // 000000DD2A60: 365E5EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DD2A68: BF8701A3
	v_and_or_b32 v43, 0xffff, v43, v48                         // 000000DD2A6C: D657002B 04C256FF 0000FFFF
	v_and_b32_e32 v48, 0xffff, v25                             // 000000DD2A78: 366032FF 0000FFFF
	v_lshl_or_b32 v44, v44, 16, v47                            // 000000DD2A80: D656002C 04BD212C
	v_bfe_u32 v47, v25, 12, 16                                 // 000000DD2A88: D610002F 02411919
	v_bfe_u32 v25, v25, 4, 16                                  // 000000DD2A90: D6100019 02410919
	v_pk_fma_f16 v43, v43, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DD2A98: CC0E002B 0BFC0F2B 0000C931
	.long 0xd72c0030                                           // 000000DD2AA4: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 000000DD2AA8: 020260FF 83DCD12D
	v_pk_fma_f16 v44, v44, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DD2AB0: CC0E002C 0BFC0F2C 0000C931
	.long 0xd72c002f                                           // 000000DD2ABC: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 000000DD2AC0: 02025EFF 83DCD12D
	.long 0xd72c0019                                           // 000000DD2AC8: D72C0019
	v_cndmask_b32_e32 v1, 0x83dcd12d, v25, vcc_lo              // 000000DD2ACC: 020232FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DD2AD4: BF870003
	v_dot2acc_f32_f16 v12, v44, v1                             // 000000DD2AD8: 0418032C
	.long 0xd72c002c                                           // 000000DD2ADC: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 000000DD2AE0: 020266FF 83DCD12D
	v_sad_u8 v48, v48, 0, 0x6400                               // 000000DD2AE8: D6220030 03FD0130 00006400
	v_bfe_u32 v51, v24, 4, 16                                  // 000000DD2AF4: D6100033 02410918
	v_sad_u8 v47, v47, 0, 0x6400                               // 000000DD2AFC: D622002F 03FD012F 00006400
	v_dot2acc_f32_f16 v12, v43, v2                             // 000000DD2B08: 0418052B
	v_bfe_u32 v43, v19, 12, 16                                 // 000000DD2B0C: D610002B 02411913
	v_sad_u8 v25, v25, 0, 0x6400                               // 000000DD2B14: D6220019 03FD0119 00006400
	v_lshlrev_b32_e32 v48, 16, v48                             // 000000DD2B20: 30606090
	v_and_b32_e32 v47, 0xffff, v47                             // 000000DD2B24: 365E5EFF 0000FFFF
	v_sad_u8 v44, v44, 0, 0x6400                               // 000000DD2B2C: D622002C 03FD012C 00006400
	.long 0xd72c002b                                           // 000000DD2B38: D72C002B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 000000DD2B3C: 020256FF 83DCD12D
	v_and_b32_e32 v24, 0xffff, v24                             // 000000DD2B44: 363030FF 0000FFFF
	v_and_or_b32 v25, 0xffff, v25, v48                         // 000000DD2B4C: D6570019 04C232FF 0000FFFF
	v_lshl_or_b32 v47, v50, 16, v47                            // 000000DD2B58: D656002F 04BD2132
	v_lshl_or_b32 v44, v44, 16, v49                            // 000000DD2B60: D656002C 04C5212C
	v_bfe_u32 v49, v19, 8, 16                                  // 000000DD2B68: D6100031 02411113
	s_waitcnt vmcnt(0)                                         // 000000DD2B70: BF8903F7
	v_bfe_u32 v50, v18, 12, 16                                 // 000000DD2B74: D6100032 02411912
	.long 0xd72c0030                                           // 000000DD2B7C: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 000000DD2B80: 020266FF 83DCD12D
	v_bfe_u32 v51, v18, 8, 16                                  // 000000DD2B88: D6100033 02411112
	v_sad_u8 v43, v43, 0, 0x6400                               // 000000DD2B90: D622002B 03FD012B 00006400
	.long 0xd72c0031                                           // 000000DD2B9C: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 000000DD2BA0: 020262FF 83DCD12D
	.long 0xd72c0032                                           // 000000DD2BA8: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 000000DD2BAC: 020264FF 83DCD12D
	v_pk_fma_f16 v25, v25, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DD2BB4: CC0E0019 0BFC0F19 0000C931
	.long 0xd72c0033                                           // 000000DD2BC0: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 000000DD2BC4: 020266FF 83DCD12D
	v_and_b32_e32 v43, 0xffff, v43                             // 000000DD2BCC: 365656FF 0000FFFF
	v_pk_fma_f16 v44, v44, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DD2BD4: CC0E002C 0BFC0F2C 0000C931
	v_dot2acc_f32_f16 v12, v26, v3                             // 000000DD2BE0: 0418071A
	v_mov_b32_e32 v26, v35                                     // 000000DD2BE4: 7E340323
	v_sad_u8 v49, v49, 0, 0x6400                               // 000000DD2BE8: D6220031 03FD0131 00006400
	v_sad_u8 v50, v50, 0, 0x6400                               // 000000DD2BF4: D6220032 03FD0132 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DD2C00: BF870224
	v_dot2acc_f32_f16 v12, v42, v4                             // 000000DD2C04: 0418092A
	v_mov_b32_e32 v42, v36                                     // 000000DD2C08: 7E540324
	v_lshl_or_b32 v43, v49, 16, v43                            // 000000DD2C0C: D656002B 04AD2131
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DD2C14: BF870004
	v_and_b32_e32 v49, 0xffff, v50                             // 000000DD2C18: 366264FF 0000FFFF
	v_sad_u8 v50, v51, 0, 0x6400                               // 000000DD2C20: D6220032 03FD0133 00006400
	v_mov_b32_e32 v51, v39                                     // 000000DD2C2C: 7E660327
	.long 0xd72c0014                                           // 000000DD2C30: D72C0014
	v_cndmask_b32_e32 v1, 0x83dcd12d, v24, vcc_lo              // 000000DD2C34: 020230FF 83DCD12D
	v_pk_fma_f16 v24, v47, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DD2C3C: CC0E0018 0BFC0F2F 0000C931
	v_sad_u8 v47, v48, 0, 0x6400                               // 000000DD2C48: D622002F 03FD0130 00006400
	v_and_b32_e32 v48, 0xffff, v19                             // 000000DD2C54: 366026FF 0000FFFF
	v_bfe_u32 v19, v19, 4, 16                                  // 000000DD2C5C: D6100013 02410913
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DD2C64: BF870224
	v_dot2acc_f32_f16 v10, v24, v1                             // 000000DD2C68: 04140318
	v_and_b32_e32 v45, 0xffff, v45                             // 000000DD2C6C: 365A5AFF 0000FFFF
	.long 0xd72c0030                                           // 000000DD2C74: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 000000DD2C78: 020260FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DD2C80: BF870004
	.long 0xd72c0013                                           // 000000DD2C84: D72C0013
	v_cndmask_b32_e32 v1, 0x83dcd12d, v19, vcc_lo              // 000000DD2C88: 020226FF 83DCD12D
	v_sad_u8 v20, v20, 0, 0x6400                               // 000000DD2C90: D6220014 03FD0114 00006400
	v_dot2acc_f32_f16 v10, v25, v2                             // 000000DD2C9C: 04140519
	.long 0xd72c002d                                           // 000000DD2CA0: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v45, vcc_lo              // 000000DD2CA4: 02025AFF 83DCD12D
	v_pk_fma_f16 v24, v43, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DD2CAC: CC0E0018 0BFC0F2B 0000C931
	v_lshl_or_b32 v43, v50, 16, v49                            // 000000DD2CB8: D656002B 04C52132
	v_lshlrev_b32_e32 v20, 16, v20                             // 000000DD2CC0: 30282890
	v_sad_u8 v48, v48, 0, 0x6400                               // 000000DD2CC4: D6220030 03FD0130 00006400
	v_dot2acc_f32_f16 v10, v44, v3                             // 000000DD2CD0: 0414072C
	v_sad_u8 v19, v19, 0, 0x6400                               // 000000DD2CD4: D6220013 03FD0113 00006400
	v_dot2acc_f32_f16 v11, v24, v1                             // 000000DD2CE0: 04160318
	v_sad_u8 v45, v45, 0, 0x6400                               // 000000DD2CE4: D622002D 03FD012D 00006400
	v_lshlrev_b32_e32 v48, 16, v48                             // 000000DD2CF0: 30606090
	v_and_or_b32 v1, 0xffff, v47, v20                          // 000000DD2CF4: D6570001 04525EFF 0000FFFF
	v_pk_fma_f16 v20, v43, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DD2D00: CC0E0014 0BFC0F2B 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DD2D0C: BF870214
	v_dual_mov_b32 v24, v35 :: v_dual_lshlrev_b32 v45, 16, v45 // 000000DD2D10: CA220123 182C5A90
	v_and_or_b32 v19, 0xffff, v19, v48                         // 000000DD2D18: D6570013 04C226FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DD2D24: BF870224
	v_pk_fma_f16 v1, v1, s7, 0xc931 op_sel_hi:[1,0,0]          // 000000DD2D28: CC0E0001 0BFC0F01 0000C931
	v_dual_mov_b32 v25, v27 :: v_dual_mov_b32 v44, v36         // 000000DD2D34: CA10011B 192C0124
	v_and_or_b32 v45, 0xffff, v52, v45                         // 000000DD2D3C: D657002D 04B668FF 0000FFFF
	v_bfe_u32 v52, v18, 4, 16                                  // 000000DD2D48: D6100034 02410912
	v_and_b32_e32 v18, 0xffff, v18                             // 000000DD2D50: 362424FF 0000FFFF
	v_pk_fma_f16 v19, v19, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DD2D58: CC0E0013 0BFC0F13 0000C931
	v_dot2acc_f32_f16 v10, v1, v4                              // 000000DD2D64: 04140901
	v_pk_fma_f16 v45, v45, s7, 0xc931 op_sel_hi:[1,0,0]        // 000000DD2D68: CC0E002D 0BFC0F2D 0000C931
	.long 0xd72c0030                                           // 000000DD2D74: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 000000DD2D78: 020268FF 83DCD12D
	.long 0xd72c0012                                           // 000000DD2D80: D72C0012
	v_cndmask_b32_e32 v1, 0x83dcd12d, v18, vcc_lo              // 000000DD2D84: 020224FF 83DCD12D
	v_dot2acc_f32_f16 v11, v19, v2                             // 000000DD2D8C: 04160513
	v_mov_b32_e32 v19, v6                                      // 000000DD2D90: 7E260306
	v_dot2acc_f32_f16 v13, v45, v4                             // 000000DD2D94: 041A092D
	v_mov_b32_e32 v43, v28                                     // 000000DD2D98: 7E56031C
	v_mov_b32_e32 v45, v37                                     // 000000DD2D9C: 7E5A0325
	v_dot2acc_f32_f16 v11, v20, v3                             // 000000DD2DA0: 04160714
	v_sad_u8 v48, v48, 0, 0x6400                               // 000000DD2DA4: D6220030 03FD0130 00006400
	v_sad_u8 v18, v18, 0, 0x6400                               // 000000DD2DB0: D6220012 03FD0112 00006400
	v_mov_b32_e32 v20, v33                                     // 000000DD2DBC: 7E280321
	v_dual_mov_b32 v47, v37 :: v_dual_mov_b32 v50, v38         // 000000DD2DC0: CA100125 2F320126
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000DD2DC8: BF8701B3
	v_dual_mov_b32 v49, v30 :: v_dual_lshlrev_b32 v18, 16, v18 // 000000DD2DCC: CA22011E 31122490
	v_dual_mov_b32 v52, v31 :: v_dual_mov_b32 v3, v41          // 000000DD2DD4: CA10011F 34020129
	v_mov_b32_e32 v1, v5                                       // 000000DD2DDC: 7E020305
	v_and_or_b32 v18, 0xffff, v48, v18                         // 000000DD2DE0: D6570012 044A60FF 0000FFFF
	v_mov_b32_e32 v48, v38                                     // 000000DD2DEC: 7E600326
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD2DF0: BF870092
	v_pk_fma_f16 v2, v18, s7, 0xc931 op_sel_hi:[1,0,0]         // 000000DD2DF4: CC0E0002 0BFC0F12 0000C931
	v_dual_mov_b32 v18, v33 :: v_dual_dot2acc_f32_f16 v11, v2, v4// 000000DD2E00: CA180121 120A0902
	v_mov_b32_e32 v4, v41                                      // 000000DD2E08: 7E080329
	v_mov_b32_e32 v2, v32                                      // 000000DD2E0C: 7E040320
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 000000DD2E10: 917E067E
	s_cbranch_execz 58                                         // 000000DD2E14: BFA5003A <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi1ELi4EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x1a00>
	v_add_nc_u32_e32 v5, 1, v1                                 // 000000DD2E18: 4A0A0281
	s_mov_b32 s8, exec_lo                                      // 000000DD2E1C: BE88007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DD2E20: BF870001
	.long 0xd4c1007e                                           // 000000DD2E24: D4C1007E
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 000000DD2E28: 02020F05
	s_cbranch_execz 64649                                      // 000000DD2E2C: BFA5FC89 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi1ELi4EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0xb54>
	v_ashrrev_i32_e32 v6, 31, v5                               // 000000DD2E30: 340C0A9F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD2E34: BF870091
	.long 0xd73c001b                                           // 000000DD2E38: D73C001B
	v_cndmask_b32_e32 v1, 10, v5, vcc_lo                       // 000000DD2E3C: 02020A8A
	.long 0xd7006a06                                           // 000000DD2E40: D7006A06
	v_cndmask_b32_e32 v1, s4, v27, vcc_lo                      // 000000DD2E44: 02023604
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DD2E48: BF870111
	v_add_co_ci_u32_e64 v27, null, s5, v28, vcc_lo             // 000000DD2E4C: D5207C1B 01AA3805
	.long 0xd7006a23                                           // 000000DD2E54: D7006A23
	v_cndmask_b32_e32 v1, v6, v23, vcc_lo                      // 000000DD2E58: 02022F06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DD2E5C: BF8700A1
	v_add_co_ci_u32_e64 v36, null, 0, v27, vcc_lo              // 000000DD2E60: D5207C24 01AA3680
	.long 0xd7006a39                                           // 000000DD2E68: D7006A39
	v_cndmask_b32_e32 v1, v6, v22, vcc_lo                      // 000000DD2E6C: 02022D06
	v_add_co_ci_u32_e64 v58, null, 0, v27, vcc_lo              // 000000DD2E70: D5207C3A 01AA3680
	s_clause 0xf                                               // 000000DD2E78: BF85000F
	global_load_b32 v32, v[35:36], off                         // 000000DD2E7C: DC520000 207C0023
	global_load_b32 v34, v[35:36], off offset:128              // 000000DD2E84: DC520080 227C0023
	global_load_b32 v31, v[35:36], off offset:256              // 000000DD2E8C: DC520100 1F7C0023
	global_load_b32 v30, v[35:36], off offset:384              // 000000DD2E94: DC520180 1E7C0023
	global_load_b32 v29, v[35:36], off offset:512              // 000000DD2E9C: DC520200 1D7C0023
	global_load_b32 v28, v[35:36], off offset:640              // 000000DD2EA4: DC520280 1C7C0023
	global_load_b32 v27, v[35:36], off offset:768              // 000000DD2EAC: DC520300 1B7C0023
	global_load_b32 v6, v[35:36], off offset:896               // 000000DD2EB4: DC520380 067C0023
	global_load_b32 v41, v[57:58], off                         // 000000DD2EBC: DC520000 297C0039
	global_load_b32 v40, v[57:58], off offset:128              // 000000DD2EC4: DC520080 287C0039
	global_load_b32 v39, v[57:58], off offset:256              // 000000DD2ECC: DC520100 277C0039
	global_load_b32 v38, v[57:58], off offset:384              // 000000DD2ED4: DC520180 267C0039
	global_load_b32 v37, v[57:58], off offset:512              // 000000DD2EDC: DC520200 257C0039
	global_load_b32 v36, v[57:58], off offset:640              // 000000DD2EE4: DC520280 247C0039
	global_load_b32 v35, v[57:58], off offset:768              // 000000DD2EEC: DC520300 237C0039
	global_load_b32 v33, v[57:58], off offset:896              // 000000DD2EF4: DC520380 217C0039
	s_branch 64597                                             // 000000DD2EFC: BFA0FC55 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi1ELi4EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0xb54>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000DD2F00: 8C7E067E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000DD2F04: BF870009
	s_or_b32 exec_lo, exec_lo, s3                              // 000000DD2F08: 8C7E037E
	s_waitcnt vmcnt(23)                                        // 000000DD2F0C: BF895FF7
	v_dual_mov_b32 v1, v17 :: v_dual_mov_b32 v2, v16           // 000000DD2F10: CA100111 01020110
	s_waitcnt vmcnt(7)                                         // 000000DD2F18: BF891FF7
	v_dual_mov_b32 v3, v15 :: v_dual_mov_b32 v4, v14           // 000000DD2F1C: CA10010F 0304010E
	v_dual_mov_b32 v5, v13 :: v_dual_mov_b32 v6, v12           // 000000DD2F24: CA10010D 0506010C
	s_waitcnt vmcnt(0)                                         // 000000DD2F2C: BF8903F7
	v_dual_mov_b32 v7, v10 :: v_dual_mov_b32 v18, v11          // 000000DD2F30: CA10010A 0712010B
	s_mov_b32 s3, 0x76543210                                   // 000000DD2F38: BE8300FF 76543210
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000DD2F40: BF870009
	v_permlanex16_b32 v1, v1, s3, 0xfedcba98                   // 000000DD2F44: D65C0001 03FC0701 FEDCBA98
	v_permlanex16_b32 v2, v2, s3, 0xfedcba98                   // 000000DD2F50: D65C0002 03FC0702 FEDCBA98
	v_permlanex16_b32 v3, v3, s3, 0xfedcba98                   // 000000DD2F5C: D65C0003 03FC0703 FEDCBA98
	v_permlanex16_b32 v4, v4, s3, 0xfedcba98                   // 000000DD2F68: D65C0004 03FC0704 FEDCBA98
	v_permlanex16_b32 v5, v5, s3, 0xfedcba98                   // 000000DD2F74: D65C0005 03FC0705 FEDCBA98
	v_permlanex16_b32 v6, v6, s3, 0xfedcba98                   // 000000DD2F80: D65C0006 03FC0706 FEDCBA98
	v_permlanex16_b32 v7, v7, s3, 0xfedcba98                   // 000000DD2F8C: D65C0007 03FC0707 FEDCBA98
	v_permlanex16_b32 v18, v18, s3, 0xfedcba98                 // 000000DD2F98: D65C0012 03FC0712 FEDCBA98
	.long 0xd44c0003                                           // 000000DD2FA4: D44C0003
	v_cndmask_b32_e32 v1, 16, v9, vcc_lo                       // 000000DD2FA8: 02021290
	s_barrier                                                  // 000000DD2FAC: BFBD0000
	buffer_gl0_inv                                             // 000000DD2FB0: E0AC0000 00000000
	s_and_saveexec_b32 s4, s3                                  // 000000DD2FB8: BE842003
	s_cbranch_execz 21                                         // 000000DD2FBC: BFA50015 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi1ELi4EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x1b14>
	v_lshl_or_b32 v0, v8, 9, v0                                // 000000DD2FC0: D6560000 04011308
	v_dual_add_f32 v1, v17, v1 :: v_dual_add_f32 v2, v16, v2   // 000000DD2FC8: C9080311 01020510
	v_add_f32_e32 v3, v15, v3                                  // 000000DD2FD0: 0606070F
	v_dual_add_f32 v9, v11, v18 :: v_dual_add_f32 v4, v14, v4  // 000000DD2FD4: C908250B 0904090E
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DD2FDC: BF870004
	v_dual_add_f32 v5, v13, v5 :: v_dual_add_nc_u32 v0, 0x5000, v0// 000000DD2FE0: C9200B0D 050000FF 00005000
	v_dual_add_f32 v6, v12, v6 :: v_dual_add_f32 v7, v10, v7   // 000000DD2FEC: C9080D0C 06060F0A
	ds_store_2addr_b32 v0, v1, v2 offset1:16                   // 000000DD2FF4: D8381000 00020100
	ds_store_2addr_b32 v0, v3, v4 offset0:32 offset1:48        // 000000DD2FFC: D8383020 00040300
	ds_store_2addr_b32 v0, v5, v6 offset0:64 offset1:80        // 000000DD3004: D8385040 00060500
	ds_store_2addr_b32 v0, v7, v9 offset0:96 offset1:112       // 000000DD300C: D8387060 00090700
	s_or_b32 exec_lo, exec_lo, s4                              // 000000DD3014: 8C7E047E
	.long 0xd44c0004                                           // 000000DD3018: D44C0004
	v_cndmask_b32_e32 v1, 0x80, v65, vcc_lo                    // 000000DD301C: 020282FF 00000080
	s_waitcnt lgkmcnt(0)                                       // 000000DD3024: BF89FC07
	s_barrier                                                  // 000000DD3028: BFBD0000
	buffer_gl0_inv                                             // 000000DD302C: E0AC0000 00000000
	s_and_saveexec_b32 s5, s4                                  // 000000DD3034: BE852004
	s_cbranch_execnz 7                                         // 000000DD3038: BFA60007 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi1ELi4EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x1b58>
	s_or_b32 exec_lo, exec_lo, s5                              // 000000DD303C: 8C7E057E
	s_cmp_lt_i32 s11, 2                                        // 000000DD3040: BF04820B
	s_mov_b32 s5, -1                                           // 000000DD3044: BE8500C1
	s_cbranch_scc0 33                                          // 000000DD3048: BFA10021 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi1ELi4EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x1bd0>
	s_and_b32 vcc_lo, exec_lo, s5                              // 000000DD304C: 8B6A057E
	s_cbranch_vccnz 155                                        // 000000DD3050: BFA4009B <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi1ELi4EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x1dc0>
	s_branch 518                                               // 000000DD3054: BFA00206 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi1ELi4EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x2370>
	v_lshlrev_b32_e32 v6, 2, v65                               // 000000DD3058: 300C8282
	ds_load_2addr_stride64_b32 v[0:1], v6 offset0:80 offset1:82// 000000DD305C: D8E05250 00000006
	ds_load_2addr_stride64_b32 v[2:3], v6 offset0:84 offset1:86// 000000DD3064: D8E05654 02000006
	ds_load_2addr_stride64_b32 v[4:5], v6 offset0:88 offset1:90// 000000DD306C: D8E05A58 04000006
	s_waitcnt lgkmcnt(2)                                       // 000000DD3074: BF89FC27
	v_add_f32_e32 v0, 0, v0                                    // 000000DD3078: 06000080
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DD307C: BF8700A1
	v_add_f32_e32 v0, v0, v1                                   // 000000DD3080: 06000300
	s_waitcnt lgkmcnt(1)                                       // 000000DD3084: BF89FC17
	v_add_f32_e32 v2, v0, v2                                   // 000000DD3088: 06040500
	ds_load_2addr_stride64_b32 v[0:1], v6 offset0:92 offset1:94// 000000DD308C: D8E05E5C 00000006
	v_add_f32_e32 v2, v2, v3                                   // 000000DD3094: 06040702
	s_waitcnt lgkmcnt(1)                                       // 000000DD3098: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD309C: BF870091
	v_add_f32_e32 v2, v2, v4                                   // 000000DD30A0: 06040902
	v_add_f32_e32 v2, v2, v5                                   // 000000DD30A4: 06040B02
	s_waitcnt lgkmcnt(0)                                       // 000000DD30A8: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD30AC: BF870091
	v_add_f32_e32 v0, v2, v0                                   // 000000DD30B0: 06000102
	v_add_f32_e32 v0, v0, v1                                   // 000000DD30B4: 06000300
	ds_store_b32 v6, v0 offset:24576                           // 000000DD30B8: D8346000 00000006
	s_or_b32 exec_lo, exec_lo, s5                              // 000000DD30C0: 8C7E057E
	s_cmp_lt_i32 s11, 2                                        // 000000DD30C4: BF04820B
	s_mov_b32 s5, -1                                           // 000000DD30C8: BE8500C1
	s_cbranch_scc1 65503                                       // 000000DD30CC: BFA2FFDF <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi1ELi4EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x1b4c>
	s_waitcnt lgkmcnt(0)                                       // 000000DD30D0: BF89FC07
	s_barrier                                                  // 000000DD30D4: BFBD0000
	buffer_gl0_inv                                             // 000000DD30D8: E0AC0000 00000000
	s_and_saveexec_b32 s5, s4                                  // 000000DD30E0: BE852004
	s_cbranch_execz 17                                         // 000000DD30E4: BFA50011 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi1ELi4EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x1c2c>
	v_lshlrev_b32_e32 v0, 2, v65                               // 000000DD30E8: 30008282
	s_mul_hi_i32 s7, s33, s37                                  // 000000DD30EC: 97072521
	s_mul_i32 s6, s33, s37                                     // 000000DD30F0: 96062521
	s_lshl_b32 s8, s34, 7                                      // 000000DD30F4: 84088722
	s_lshl_b64 s[6:7], s[6:7], 2                               // 000000DD30F8: 84868206
	ds_load_b32 v1, v0 offset:24576                            // 000000DD30FC: D8D86000 01000000
	s_ashr_i32 s9, s8, 31                                      // 000000DD3104: 86099F08
	s_add_u32 s10, s30, s6                                     // 000000DD3108: 800A061E
	s_addc_u32 s18, s31, s7                                    // 000000DD310C: 8212071F
	s_lshl_b64 s[6:7], s[8:9], 2                               // 000000DD3110: 84868208
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000DD3114: BF870009
	s_add_u32 s6, s10, s6                                      // 000000DD3118: 8006060A
	s_addc_u32 s7, s18, s7                                     // 000000DD311C: 82070712
	s_waitcnt lgkmcnt(0)                                       // 000000DD3120: BF89FC07
	global_store_b32 v0, v1, s[6:7]                            // 000000DD3124: DC6A0000 00060100
	s_or_b32 exec_lo, exec_lo, s5                              // 000000DD312C: 8C7E057E
	.long 0xd44a0005                                           // 000000DD3130: D44A0005
	v_cndmask_b32_e32 v1, 0, v65, vcc_lo                       // 000000DD3134: 02028280
	s_waitcnt_vscnt null, 0x0                                  // 000000DD3138: BC7C0000
	buffer_gl1_inv                                             // 000000DD313C: E0B00000 00000000
	buffer_gl0_inv                                             // 000000DD3144: E0AC0000 00000000
	s_barrier                                                  // 000000DD314C: BFBD0000
	buffer_gl0_inv                                             // 000000DD3150: E0AC0000 00000000
	s_and_saveexec_b32 s6, s5                                  // 000000DD3158: BE862005
	s_cbranch_execz 29                                         // 000000DD315C: BFA5001D <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi1ELi4EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x1cd4>
	s_mov_b32 s8, exec_lo                                      // 000000DD3160: BE88007E
	s_mov_b32 s7, exec_lo                                      // 000000DD3164: BE87007E
	.long 0xd71f0000                                           // 000000DD3168: D71F0000
	v_cndmask_b32_e32 v0, s8, v128, vcc_lo                     // 000000DD316C: 02010008
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DD3170: BF870001
	v_cmpx_eq_u32_e32 0, v0                                    // 000000DD3174: 7D940080
	s_cbranch_execz 9                                          // 000000DD3178: BFA50009 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi1ELi4EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x1ca0>
	s_lshl_b64 s[18:19], s[34:35], 2                           // 000000DD317C: 84928222
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000DD3180: BF8704B9
	s_add_u32 s18, s40, s18                                    // 000000DD3184: 80121228
	s_addc_u32 s19, s41, s19                                   // 000000DD3188: 82131329
	s_bcnt1_i32_b32 s8, s8                                     // 000000DD318C: BE881808
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v2, s8              // 000000DD3190: CA100080 01020008
	global_atomic_add_u32 v1, v1, v2, s[18:19] glc             // 000000DD3198: DCD64000 01120201
	s_or_b32 exec_lo, exec_lo, s7                              // 000000DD31A0: 8C7E077E
	s_waitcnt vmcnt(0)                                         // 000000DD31A4: BF8903F7
	v_readfirstlane_b32 s7, v1                                 // 000000DD31A8: 7E0E0501
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DD31AC: BF870001
	v_dual_mov_b32 v1, 0 :: v_dual_add_nc_u32 v0, s7, v0       // 000000DD31B0: CA200080 01000007
	s_add_i32 s7, s11, -1                                      // 000000DD31B8: 8107C10B
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000DD31BC: BF870481
	v_cmp_eq_u32_e32 vcc_lo, s7, v0                            // 000000DD31C0: 7C940007
	v_cndmask_b32_e64 v0, 0, 1, vcc_lo                         // 000000DD31C4: D5010000 01A90280
	ds_store_b32 v1, v0 offset:25632                           // 000000DD31CC: D8346420 00000001
	s_or_b32 exec_lo, exec_lo, s6                              // 000000DD31D4: 8C7E067E
	v_mov_b32_e32 v0, 0                                        // 000000DD31D8: 7E000280
	s_waitcnt lgkmcnt(0)                                       // 000000DD31DC: BF89FC07
	s_barrier                                                  // 000000DD31E0: BFBD0000
	buffer_gl0_inv                                             // 000000DD31E4: E0AC0000 00000000
	ds_load_b32 v0, v0 offset:25632                            // 000000DD31EC: D8D86420 00000000
	s_waitcnt lgkmcnt(0)                                       // 000000DD31F4: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v0                             // 000000DD31F8: 7C940080
	s_cbranch_vccnz 47                                         // 000000DD31FC: BFA4002F <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi1ELi4EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x1dbc>
	buffer_gl1_inv                                             // 000000DD3200: E0B00000 00000000
	buffer_gl0_inv                                             // 000000DD3208: E0AC0000 00000000
	s_and_saveexec_b32 s8, s4                                  // 000000DD3210: BE882004
	s_cbranch_execz 29                                         // 000000DD3214: BFA5001D <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi1ELi4EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x1d8c>
	s_lshl_b32 s6, s34, 7                                      // 000000DD3218: 84068722
	v_dual_mov_b32 v3, 0 :: v_dual_lshlrev_b32 v0, 2, v65      // 000000DD321C: CA220080 03008282
	s_ashr_i32 s7, s6, 31                                      // 000000DD3224: 86079F06
	s_ashr_i32 s19, s37, 31                                    // 000000DD3228: 86139F25
	s_lshl_b64 s[6:7], s[6:7], 2                               // 000000DD322C: 84868206
	s_mov_b32 s18, s37                                         // 000000DD3230: BE920025
	s_add_u32 s4, s30, s6                                      // 000000DD3234: 8004061E
	s_addc_u32 s6, s31, s7                                     // 000000DD3238: 8206071F
	.long 0xd7000401                                           // 000000DD323C: D7000401
	v_cndmask_b32_e32 v1, s4, v0, vcc_lo                       // 000000DD3240: 02020004
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DD3244: BF870001
	v_add_co_ci_u32_e64 v2, null, s6, 0, s4                    // 000000DD3248: D5207C02 00110006
	s_lshl_b64 s[6:7], s[18:19], 2                             // 000000DD3250: 84868212
	global_load_b32 v4, v[1:2], off glc                        // 000000DD3254: DC524000 047C0001
	.long 0xd7006a01                                           // 000000DD325C: D7006A01
	v_cndmask_b32_e32 v0, v1, v6, vcc_lo                       // 000000DD3260: 02000D01
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000DD3264: BF8704A1
	v_add_co_ci_u32_e64 v2, null, s7, v2, vcc_lo               // 000000DD3268: D5207C02 01AA0407
	s_add_i32 s11, s11, -1                                     // 000000DD3270: 810BC10B
	s_cmp_eq_u32 s11, 0                                        // 000000DD3274: BF06800B
	s_waitcnt vmcnt(0)                                         // 000000DD3278: BF8903F7
	v_add_f32_e32 v3, v3, v4                                   // 000000DD327C: 06060903
	s_cbranch_scc0 65524                                       // 000000DD3280: BFA1FFF4 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi1ELi4EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x1d54>
	ds_store_b32 v0, v3 offset:24576                           // 000000DD3284: D8346000 00000300
	s_or_b32 exec_lo, exec_lo, s8                              // 000000DD328C: 8C7E087E
	s_and_saveexec_b32 s4, s5                                  // 000000DD3290: BE842005
	s_cbranch_execz 6                                          // 000000DD3294: BFA50006 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi1ELi4EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x1db0>
	s_lshl_b64 s[6:7], s[34:35], 2                             // 000000DD3298: 84868222
	v_mov_b32_e32 v0, 0                                        // 000000DD329C: 7E000280
	s_add_u32 s6, s40, s6                                      // 000000DD32A0: 80060628
	s_addc_u32 s7, s41, s7                                     // 000000DD32A4: 82070729
	global_store_b32 v0, v0, s[6:7]                            // 000000DD32A8: DC6A0000 00060000
	s_or_b32 exec_lo, exec_lo, s4                              // 000000DD32B0: 8C7E047E
	s_cbranch_execnz 2                                         // 000000DD32B4: BFA60002 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi1ELi4EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x1dc0>
	s_branch 365                                               // 000000DD32B8: BFA0016D <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi1ELi4EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x2370>
	s_branch 364                                               // 000000DD32BC: BFA0016C <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi1ELi4EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x2370>
	v_cmp_eq_u32_e32 vcc_lo, 0, v8                             // 000000DD32C0: 7C941080
	s_cmp_gt_i32 s36, 0                                        // 000000DD32C4: BF028024
	s_waitcnt lgkmcnt(0)                                       // 000000DD32C8: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 000000DD32CC: BC7C0000
	s_cselect_b32 s4, -1, 0                                    // 000000DD32D0: 980480C1
	s_barrier                                                  // 000000DD32D4: BFBD0000
	s_and_b32 s4, vcc_lo, s4                                   // 000000DD32D8: 8B04046A
	buffer_gl0_inv                                             // 000000DD32DC: E0AC0000 00000000
	s_and_saveexec_b32 s6, s4                                  // 000000DD32E4: BE862004
	s_cbranch_execz 352                                        // 000000DD32E8: BFA50160 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi1ELi4EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x236c>
	v_and_b32_e32 v0, 15, v65                                  // 000000DD32EC: 3600828F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD32F0: BF870091
	v_lshlrev_b32_e32 v1, 2, v0                                // 000000DD32F4: 30020082
	v_add_nc_u32_e32 v7, 0x6000, v1                            // 000000DD32F8: 4A0E02FF 00006000
	ds_load_2addr_b32 v[1:2], v7 offset1:16                    // 000000DD3300: D8DC1000 01000007
	ds_load_2addr_b32 v[3:4], v7 offset0:32 offset1:48         // 000000DD3308: D8DC3020 03000007
	ds_load_2addr_b32 v[5:6], v7 offset0:64 offset1:80         // 000000DD3310: D8DC5040 05000007
	ds_load_2addr_b32 v[7:8], v7 offset0:96 offset1:112        // 000000DD3318: D8DC7060 07000007
	v_and_b32_e32 v9, 1, v65                                   // 000000DD3320: 36128281
	v_and_b32_e32 v10, 2, v65                                  // 000000DD3324: 36148282
	s_waitcnt lgkmcnt(3)                                       // 000000DD3328: BF89FC37
	v_dual_add_f32 v12, v1, v2 :: v_dual_and_b32 v11, 4, v65   // 000000DD332C: C9240501 0C0A8284
	s_waitcnt lgkmcnt(2)                                       // 000000DD3334: BF89FC27
	v_dual_sub_f32 v1, v1, v2 :: v_dual_add_f32 v2, v3, v4     // 000000DD3338: C9480501 01020903
	s_waitcnt lgkmcnt(1)                                       // 000000DD3340: BF89FC17
	v_dual_sub_f32 v3, v3, v4 :: v_dual_add_f32 v4, v5, v6     // 000000DD3344: C9480903 03040D05
	s_waitcnt lgkmcnt(0)                                       // 000000DD334C: BF89FC07
	v_dual_sub_f32 v5, v5, v6 :: v_dual_add_f32 v6, v7, v8     // 000000DD3350: C9480D05 05061107
	v_dual_sub_f32 v7, v7, v8 :: v_dual_add_f32 v8, v12, v2    // 000000DD3358: C9481107 0708050C
	v_sub_f32_e32 v2, v12, v2                                  // 000000DD3360: 0804050C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000DD3364: BF870243
	v_dual_add_f32 v12, v1, v3 :: v_dual_add_f32 v13, v4, v6   // 000000DD3368: C9080701 0C0C0D04
	v_dual_sub_f32 v1, v1, v3 :: v_dual_sub_f32 v4, v4, v6     // 000000DD3370: C94A0701 01040D04
	v_cmp_eq_u32_e32 vcc_lo, 0, v9                             // 000000DD3378: 7C941280
	.long 0xd44a0004                                           // 000000DD337C: D44A0004
	v_cndmask_b32_e32 v1, 0, v10, vcc_lo                       // 000000DD3380: 02021480
	v_dual_add_f32 v6, v8, v13 :: v_dual_add_f32 v3, v5, v7    // 000000DD3384: C9081B08 06020F05
	v_sub_f32_e32 v5, v5, v7                                   // 000000DD338C: 080A0F05
	v_sub_f32_e32 v7, v8, v13                                  // 000000DD3390: 080E1B08
	.long 0xd44a0005                                           // 000000DD3394: D44A0005
	v_cndmask_b32_e32 v1, 0, v11, vcc_lo                       // 000000DD3398: 02021680
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DD339C: BF870003
	v_dual_add_f32 v8, v12, v3 :: v_dual_sub_f32 v9, v1, v5    // 000000DD33A0: C90A070C 08080B01
	v_dual_sub_f32 v3, v12, v3 :: v_dual_add_f32 v12, v2, v4   // 000000DD33A8: C948070C 030C0902
	v_sub_f32_e32 v2, v2, v4                                   // 000000DD33B0: 08040902
	v_add_f32_e32 v4, v1, v5                                   // 000000DD33B4: 06080B01
	v_mov_b32_dpp v1, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DD33B8: 7E0202FA FF016106
	v_cndmask_b32_e64 v5, -v6, v6, vcc_lo                      // 000000DD33C0: D5010005 21AA0D06
	v_mov_b32_dpp v6, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DD33C8: 7E0C02FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000DD33D0: D5010008 21AA1108
	v_mov_b32_dpp v14, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DD33D8: 7E1C02FA FF016104
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000DD33E0: D5010004 21AA0904
	v_mov_b32_dpp v13, v12 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DD33E8: 7E1A02FA FF01610C
	v_cndmask_b32_e64 v12, -v12, v12, vcc_lo                   // 000000DD33F0: D501000C 21AA190C
	v_mov_b32_dpp v15, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DD33F8: 7E1E02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000DD3400: D5010007 21AA0F07
	v_mov_b32_dpp v16, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DD3408: 7E2002FA FF016103
	v_cndmask_b32_e64 v17, -v3, v3, vcc_lo                     // 000000DD3410: D5010011 21AA0703
	v_mov_b32_dpp v18, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DD3418: 7E2402FA FF016102
	v_cndmask_b32_e64 v19, -v2, v2, vcc_lo                     // 000000DD3420: D5010013 21AA0502
	v_dual_add_f32 v2, v8, v6 :: v_dual_add_f32 v1, v5, v1     // 000000DD3428: C9080D08 02000305
	v_dual_add_f32 v3, v4, v14 :: v_dual_add_f32 v6, v7, v15   // 000000DD3430: C9081D04 03061F07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DD3438: BF870192
	v_cndmask_b32_e64 v7, -v2, v2, s4                          // 000000DD343C: D5010007 20120502
	v_mov_b32_dpp v5, v1 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DD3444: 7E0A02FA FF016201
	v_cndmask_b32_e64 v1, -v1, v1, s4                          // 000000DD344C: D5010001 20120301
	v_mov_b32_dpp v2, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DD3454: 7E0402FA FF016202
	v_mov_b32_dpp v10, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DD345C: 7E1402FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s4                          // 000000DD3464: D5010003 20120703
	v_add_f32_e32 v4, v12, v13                                 // 000000DD346C: 06081B0C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DD3470: BF870224
	v_dual_add_f32 v1, v1, v5 :: v_dual_add_f32 v2, v7, v2     // 000000DD3474: C9080B01 01020507
	v_mov_b32_dpp v12, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DD347C: 7E1802FA FF016206
	v_add_f32_e32 v3, v3, v10                                  // 000000DD3484: 06061503
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DD3488: BF870004
	v_mov_b32_dpp v8, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DD348C: 7E1002FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s4                          // 000000DD3494: D5010004 20120904
	v_mov_b32_dpp v5, v1 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DD349C: 7E0A02FA FF016401
	v_cndmask_b32_e64 v7, -v2, v2, s5                          // 000000DD34A4: D5010007 20160502
	v_cndmask_b32_e64 v1, -v1, v1, s5                          // 000000DD34AC: D5010001 20160301
	v_mov_b32_dpp v10, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DD34B4: 7E1402FA FF016402
	v_add_f32_e32 v4, v4, v8                                   // 000000DD34BC: 06081104
	v_mov_b32_dpp v8, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DD34C0: 7E1002FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s5                          // 000000DD34C8: D5010003 20160703
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DD34D0: BF870214
	v_dual_add_f32 v2, v1, v5 :: v_dual_add_f32 v5, v7, v10    // 000000DD34D4: C9080B01 02041507
	v_mov_b32_dpp v7, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DD34DC: 7E0E02FA FF016404
	v_cndmask_b32_e64 v10, -v4, v4, s5                         // 000000DD34E4: D501000A 20160904
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DD34EC: BF870004
	v_add_f32_e32 v3, v3, v8                                   // 000000DD34F0: 06061103
	v_mov_b32_dpp v8, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DD34F4: 7E1002FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000DD34FC: D5010009 21AA1309
	v_add_f32_e32 v11, v17, v16                                // 000000DD3504: 06162111
	v_cndmask_b32_e64 v6, -v6, v6, s4                          // 000000DD3508: D5010006 20120D06
	v_add_f32_e32 v13, v19, v18                                // 000000DD3510: 061A2513
	v_mov_b32_dpp v1, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DD3514: 7E0202FA FF016802
	v_add_f32_e32 v8, v9, v8                                   // 000000DD351C: 06101109
	v_mov_b32_dpp v4, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DD3520: 7E0802FA FF016805
	v_add_f32_e32 v12, v6, v12                                 // 000000DD3528: 06181906
	v_mov_b32_dpp v14, v13 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DD352C: 7E1C02FA FF01620D
	v_cndmask_b32_e64 v13, -v13, v13, s4                       // 000000DD3534: D501000D 20121B0D
	v_mov_b32_dpp v15, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DD353C: 7E1E02FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s4                          // 000000DD3544: D5010008 20121108
	v_add_f32_e32 v6, v10, v7                                  // 000000DD354C: 060C0F0A
	v_mov_b32_dpp v9, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DD3550: 7E1202FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s4                       // 000000DD3558: D501000B 2012170B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DD3560: BF870114
	v_dual_add_f32 v7, v13, v14 :: v_dual_add_f32 v8, v8, v15  // 000000DD3564: C9081D0D 07081F08
	v_add_f32_e32 v9, v11, v9                                  // 000000DD356C: 0612130B
	v_mov_b32_dpp v10, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DD3570: 7E1402FA FF01640C
	v_cndmask_b32_e64 v12, -v12, v12, s5                       // 000000DD3578: D501000C 2016190C
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DD3580: BF870004
	v_mov_b32_dpp v14, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DD3584: 7E1C02FA FF016407
	v_mov_b32_dpp v16, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DD358C: 7E2002FA FF016408
	v_mov_b32_dpp v11, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DD3594: 7E1602FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s5                          // 000000DD359C: D5010009 20161309
	v_cndmask_b32_e64 v17, -v7, v7, s5                         // 000000DD35A4: D5010011 20160F07
	v_cndmask_b32_e64 v8, -v8, v8, s5                          // 000000DD35AC: D5010008 20161108
	v_add_f32_e32 v13, v12, v10                                // 000000DD35B4: 061A150C
	v_mov_b32_dpp v7, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DD35B8: 7E0E02FA FF016806
	v_add_f32_e32 v15, v9, v11                                 // 000000DD35C0: 061E1709
	v_add_f32_e32 v14, v17, v14                                // 000000DD35C4: 061C1D11
	v_add_f32_e32 v16, v8, v16                                 // 000000DD35C8: 06202108
	v_mov_b32_dpp v8, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DD35CC: 7E1002FA FF016803
	v_mov_b32_dpp v9, v13 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DD35D4: 7E1202FA FF01680D
	v_mov_b32_dpp v10, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DD35DC: 7E1402FA FF01680F
	v_mov_b32_dpp v11, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DD35E4: 7E1602FA FF01680E
	v_mov_b32_dpp v12, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DD35EC: 7E1802FA FF016810
	s_and_b32 exec_lo, exec_lo, s3                             // 000000DD35F4: 8B7E037E
	s_cbranch_execz 156                                        // 000000DD35F8: BFA5009C <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi1ELi4EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x236c>
	v_lshl_or_b32 v17, s34, 7, v0                              // 000000DD35FC: D6560011 04010E22
	v_and_b32_e32 v0, 8, v65                                   // 000000DD3604: 36008288
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD3608: BF870092
	v_ashrrev_i32_e32 v18, 31, v17                             // 000000DD360C: 3424229F
	.long 0xd73c0011                                           // 000000DD3610: D73C0011
	v_cndmask_b32_e32 v1, 1, v17, vcc_lo                       // 000000DD3614: 02022281
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD3618: BF870091
	.long 0xd7006a13                                           // 000000DD361C: D7006A13
	v_cndmask_b32_e32 v1, s22, v17, vcc_lo                     // 000000DD3620: 02022216
	v_add_co_ci_u32_e64 v20, null, s23, v18, vcc_lo            // 000000DD3624: D5207C14 01AA2417
	v_cmp_eq_u32_e32 vcc_lo, 0, v0                             // 000000DD362C: 7C940080
	s_clause 0x7                                               // 000000DD3630: BF850007
	global_load_d16_b16 v21, v[19:20], off offset:32           // 000000DD3634: DC820020 157C0013
	global_load_d16_b16 v22, v[19:20], off                     // 000000DD363C: DC820000 167C0013
	global_load_d16_b16 v23, v[19:20], off offset:64           // 000000DD3644: DC820040 177C0013
	global_load_d16_b16 v24, v[19:20], off offset:96           // 000000DD364C: DC820060 187C0013
	global_load_d16_b16 v25, v[19:20], off offset:128          // 000000DD3654: DC820080 197C0013
	global_load_d16_b16 v26, v[19:20], off offset:160          // 000000DD365C: DC8200A0 1A7C0013
	global_load_d16_b16 v27, v[19:20], off offset:192          // 000000DD3664: DC8200C0 1B7C0013
	global_load_d16_b16 v19, v[19:20], off offset:224          // 000000DD366C: DC8200E0 137C0013
	.long 0x7f283880                                           // 000000DD3674: 7F283880
	v_cndmask_b32_e64 v0, -v5, v5, vcc_lo                      // 000000DD3678: D5010000 21AA0B05
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000DD3680: D5010003 21AA0703
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 000000DD3688: D501000D 21AA1B0D
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 000000DD3690: D5010002 21AA0502
	s_waitcnt vmcnt(7)                                         // 000000DD3698: BF891FF7
	.long 0x7f2a3994                                           // 000000DD369C: 7F2A3994
	v_add_f32_e32 v0, v0, v4                                   // 000000DD36A0: 06000900
	v_cndmask_b32_e64 v4, -v6, v6, vcc_lo                      // 000000DD36A4: D5010004 21AA0D06
	v_cndmask_b32_e64 v6, -v15, v15, vcc_lo                    // 000000DD36AC: D5010006 21AA1F0F
	v_cndmask_b32_e64 v15, -v16, v16, vcc_lo                   // 000000DD36B4: D501000F 21AA2110
	v_add_f32_e32 v3, v3, v8                                   // 000000DD36BC: 06061103
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 000000DD36C0: D501000E 21AA1D0E
	v_dual_add_f32 v4, v4, v7 :: v_dual_add_f32 v7, v13, v9    // 000000DD36C8: C9080F04 0406130D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DD36D0: BF8701A3
	v_dual_mul_f32 v16, 0x3db504f3, v0 :: v_dual_mul_f32 v3, 0x3db504f3, v3// 000000DD36D4: C8C600FF 100206FF 3DB504F3
	v_dual_add_f32 v2, v2, v1 :: v_dual_add_f32 v9, v15, v12   // 000000DD36E0: C9080302 0208190F
	v_dual_add_f32 v6, v6, v10 :: v_dual_mul_f32 v7, 0x3db504f3, v7// 000000DD36E8: C9061506 06060EFF 3DB504F3
	.long 0x7f0a3994                                           // 000000DD36F4: 7F0A3994
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DD36F8: BF870003
	v_mul_f32_e32 v2, 0x3db504f3, v2                           // 000000DD36FC: 100404FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000DD3704: BF8903F7
	.long 0x7f263994                                           // 000000DD3708: 7F263994
	v_dual_mul_f32 v6, 0x3db504f3, v6 :: v_dual_mul_f32 v9, 0x3db504f3, v9// 000000DD370C: C8C60CFF 060812FF 3DB504F3
	v_mul_f32_e32 v4, 0x3db504f3, v4                           // 000000DD3718: 100808FF 3DB504F3
	.long 0x7f2c3994                                           // 000000DD3720: 7F2C3994
	.long 0xd7006a00                                           // 000000DD3724: D7006A00
	v_cndmask_b32_e32 v1, s28, v17, vcc_lo                     // 000000DD3728: 0202221C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DD372C: BF870221
	v_add_co_ci_u32_e64 v1, null, s29, v18, vcc_lo             // 000000DD3730: D5207C01 01AA241D
	v_fma_mix_f32 v10, v21, v16, neg(0) op_sel_hi:[1,0,0]      // 000000DD3738: CC20000A 8A022115
	v_fma_mix_f32 v2, v22, v2, neg(0) op_sel_hi:[1,0,0]        // 000000DD3740: CC200002 8A020516
	v_fma_mix_f32 v4, v23, v4, neg(0) op_sel_hi:[1,0,0]        // 000000DD3748: CC200004 8A020917
	v_fma_mix_f32 v3, v24, v3, neg(0) op_sel_hi:[1,0,0]        // 000000DD3750: CC200003 8A020718
	v_fma_mix_f32 v7, v25, v7, neg(0) op_sel_hi:[1,0,0]        // 000000DD3758: CC200007 8A020F19
	.long 0x7e28398a                                           // 000000DD3760: 7E28398A
	v_add_f32_e32 v8, v14, v11                                 // 000000DD3764: 0610170E
	v_fma_mix_f32 v6, v26, v6, neg(0) op_sel_hi:[1,0,0]        // 000000DD3768: CC200006 8A020D1A
	v_fma_mix_f32 v9, v19, v9, neg(0) op_sel_hi:[1,0,0]        // 000000DD3770: CC200009 8A021313
	.long 0x7e0a3982                                           // 000000DD3778: 7E0A3982
	v_and_b32_e32 v11, 1, v20                                  // 000000DD377C: 36162881
	v_mul_f32_e32 v8, 0x3db504f3, v8                           // 000000DD3780: 101010FF 3DB504F3
	.long 0x7e283983                                           // 000000DD3788: 7E283983
	.long 0x7e263984                                           // 000000DD378C: 7E263984
	.long 0x7e2a3987                                           // 000000DD3790: 7E2A3987
	v_and_b32_e32 v5, 1, v5                                    // 000000DD3794: 360A0A81
	v_fma_mix_f32 v8, v27, v8, neg(0) op_sel_hi:[1,0,0]        // 000000DD3798: CC200008 8A02111B
	v_and_b32_e32 v12, 1, v20                                  // 000000DD37A0: 36182881
	.long 0x7e283986                                           // 000000DD37A4: 7E283986
	v_and_b32_e32 v13, 1, v19                                  // 000000DD37A8: 361A2681
	v_and_b32_e32 v14, 1, v21                                  // 000000DD37AC: 361C2A81
	.long 0x7e2c3988                                           // 000000DD37B0: 7E2C3988
	v_add3_u32 v2, v2, v5, 0x7fff                              // 000000DD37B4: D6550002 03FE0B02 00007FFF
	v_and_b32_e32 v15, 1, v20                                  // 000000DD37C0: 361E2881
	.long 0x7e283989                                           // 000000DD37C4: 7E283989
	v_add3_u32 v10, v10, v11, 0x7fff                           // 000000DD37C8: D655000A 03FE170A 00007FFF
	v_and_b32_e32 v16, 1, v22                                  // 000000DD37D4: 36202C81
	v_add3_u32 v4, v4, v13, 0x7fff                             // 000000DD37D8: D6550004 03FE1B04 00007FFF
	v_add3_u32 v3, v3, v12, 0x7fff                             // 000000DD37E4: D6550003 03FE1903 00007FFF
	v_and_b32_e32 v5, 1, v20                                   // 000000DD37F0: 360A2881
	v_add3_u32 v7, v7, v14, 0x7fff                             // 000000DD37F4: D6550007 03FE1D07 00007FFF
	v_add3_u32 v8, v8, v16, 0x7fff                             // 000000DD3800: D6550008 03FE2108 00007FFF
	v_add3_u32 v6, v6, v15, 0x7fff                             // 000000DD380C: D6550006 03FE1F06 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DD3818: BF870004
	v_add3_u32 v5, v9, v5, 0x7fff                              // 000000DD381C: D6550005 03FE0B09 00007FFF
	s_clause 0x7                                               // 000000DD3828: BF850007
	global_store_d16_hi_b16 v[0:1], v2, off                    // 000000DD382C: DC960000 007C0200
	global_store_d16_hi_b16 v[0:1], v10, off offset:32         // 000000DD3834: DC960020 007C0A00
	global_store_d16_hi_b16 v[0:1], v4, off offset:64          // 000000DD383C: DC960040 007C0400
	global_store_d16_hi_b16 v[0:1], v3, off offset:96          // 000000DD3844: DC960060 007C0300
	global_store_d16_hi_b16 v[0:1], v7, off offset:128         // 000000DD384C: DC960080 007C0700
	global_store_d16_hi_b16 v[0:1], v6, off offset:160         // 000000DD3854: DC9600A0 007C0600
	global_store_d16_hi_b16 v[0:1], v8, off offset:192         // 000000DD385C: DC9600C0 007C0800
	global_store_d16_hi_b16 v[0:1], v5, off offset:224         // 000000DD3864: DC9600E0 007C0500
	s_or_b32 exec_lo, exec_lo, s6                              // 000000DD386C: 8C7E067E
	s_mov_b32 s4, 0                                            // 000000DD3870: BE840080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000DD3874: BF870009
	s_and_b32 vcc_lo, exec_lo, s4                              // 000000DD3878: 8B6A047E
	s_cbranch_vccz 6021                                        // 000000DD387C: BFA31785 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi1ELi4EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x8194>
	s_load_b512 s[36:51], s[0:1], null                         // 000000DD3880: F4100900 F8000000
	v_mov_b32_e32 v0, 0                                        // 000000DD3888: 7E000280
	s_mul_hi_i32 s0, s2, 0x66666667                            // 000000DD388C: 9700FF02 66666667
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000DD3894: BF8704A9
	s_lshr_b32 s1, s0, 31                                      // 000000DD3898: 85019F00
	s_ashr_i32 s4, s0, 3                                       // 000000DD389C: 86048300
	s_add_i32 s4, s4, s1                                       // 000000DD38A0: 81040104
	s_waitcnt lgkmcnt(0)                                       // 000000DD38A4: BF89FC07
	global_load_b32 v1, v0, s[46:47]                           // 000000DD38A8: DC520000 012E0000
	s_waitcnt vmcnt(0)                                         // 000000DD38B0: BF8903F7
	v_cmp_ge_i32_e32 vcc_lo, s4, v1                            // 000000DD38B4: 7C8C0204
	s_cbranch_vccnz 6006                                       // 000000DD38B8: BFA41776 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi1ELi4EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x8194>
	s_mul_i32 s0, s4, 5                                        // 000000DD38BC: 96008504
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000DD38C0: BF870499
	s_ashr_i32 s1, s0, 31                                      // 000000DD38C4: 86019F00
	s_lshl_b64 s[0:1], s[0:1], 4                               // 000000DD38C8: 84808400
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000DD38CC: BF870009
	s_add_u32 s0, s42, s0                                      // 000000DD38D0: 8000002A
	s_addc_u32 s1, s43, s1                                     // 000000DD38D4: 8201012B
	s_clause 0x1                                               // 000000DD38D8: BF850001
	global_load_b64 v[1:2], v0, s[0:1] offset:8                // 000000DD38DC: DC560008 01000000
	global_load_b32 v0, v0, s[0:1]                             // 000000DD38E4: DC520000 00000000
	s_waitcnt vmcnt(1)                                         // 000000DD38EC: BF8907F7
	v_readfirstlane_b32 s5, v1                                 // 000000DD38F0: 7E0A0501
	v_readfirstlane_b32 s0, v2                                 // 000000DD38F4: 7E000502
	s_sub_i32 s1, s0, s5                                       // 000000DD38F8: 81810500
	s_mov_b32 s0, exec_lo                                      // 000000DD38FC: BE80007E
	s_min_i32 s3, s1, 4                                        // 000000DD3900: 89038401
	v_cmpx_gt_u32_e32 4, v65                                   // 000000DD3904: 7D988284
	s_cbranch_execz 22                                         // 000000DD3908: BFA50016 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi1ELi4EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x2464>
	v_mov_b32_e32 v1, 0                                        // 000000DD390C: 7E020280
	s_mov_b32 s6, exec_lo                                      // 000000DD3910: BE86007E
	.long 0xd4cc007e                                           // 000000DD3914: D4CC007E
	v_cndmask_b32_e32 v1, s3, v65, vcc_lo                      // 000000DD3918: 02028203
	s_cbranch_execz 12                                         // 000000DD391C: BFA5000C <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi1ELi4EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x2450>
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s5, v65      // 000000DD3920: CA200080 02008205
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD3928: BF870091
	.long 0xd73c0001                                           // 000000DD392C: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000DD3930: 02020282
	.long 0xd7006a01                                           // 000000DD3934: D7006A01
	v_cndmask_b32_e32 v1, s44, v1, vcc_lo                      // 000000DD3938: 0202022C
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DD393C: BF870001
	v_add_co_ci_u32_e64 v2, null, s45, v2, vcc_lo              // 000000DD3940: D5207C02 01AA042D
	global_load_b32 v1, v[1:2], off                            // 000000DD3948: DC520000 017C0001
	s_or_b32 exec_lo, exec_lo, s6                              // 000000DD3950: 8C7E067E
	v_lshlrev_b32_e32 v2, 2, v65                               // 000000DD3954: 30048282
	s_waitcnt vmcnt(0)                                         // 000000DD3958: BF8903F7
	ds_store_b32 v2, v1 offset:25600                           // 000000DD395C: D8346400 00000102
	s_or_b32 exec_lo, exec_lo, s0                              // 000000DD3964: 8C7E007E
	s_cmp_gt_i32 s1, 0                                         // 000000DD3968: BF028001
	s_mov_b32 s6, 0                                            // 000000DD396C: BE860080
	s_cselect_b32 s5, -1, 0                                    // 000000DD3970: 980580C1
	s_cmp_lt_i32 s1, 1                                         // 000000DD3974: BF048101
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000DD3978: BF890007
	s_waitcnt_vscnt null, 0x0                                  // 000000DD397C: BC7C0000
	s_barrier                                                  // 000000DD3980: BFBD0000
	buffer_gl0_inv                                             // 000000DD3984: E0AC0000 00000000
	s_cbranch_scc1 193                                         // 000000DD398C: BFA200C1 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi1ELi4EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x2794>
	.long 0xd44c0000                                           // 000000DD3990: D44C0000
	v_cndmask_b32_e32 v1, 0x140, v65, vcc_lo                   // 000000DD3994: 020282FF 00000140
	s_cmp_eq_u32 s1, 1                                         // 000000DD399C: BF068101
	s_mov_b32 s1, -1                                           // 000000DD39A0: BE8100C1
	s_cbranch_scc1 125                                         // 000000DD39A4: BFA2007D <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi1ELi4EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x269c>
	v_lshlrev_b32_e32 v5, 4, v65                               // 000000DD39A8: 300A8284
	v_or_b32_e32 v6, 0xffffff00, v65                           // 000000DD39AC: 380C82FF FFFFFF00
	s_and_b32 s6, s3, 6                                        // 000000DD39B4: 8B068603
	s_mov_b32 s7, 0                                            // 000000DD39B8: BE870080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD39BC: BF870092
	.long 0xd7000101                                           // 000000DD39C0: D7000101
	v_cndmask_b32_e32 v1, s40, v5, vcc_lo                      // 000000DD39C4: 02020A28
	v_add_co_ci_u32_e64 v2, null, s41, 0, s1                   // 000000DD39C8: D5207C02 00050029
	s_branch 7                                                 // 000000DD39D0: BFA00007 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi1ELi4EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x24f0>
	s_or_b32 exec_lo, exec_lo, s9                              // 000000DD39D4: 8C7E097E
	v_add_nc_u32_e32 v5, 0x2800, v5                            // 000000DD39D8: 4A0A0AFF 00002800
	s_add_i32 s7, s7, 2                                        // 000000DD39E0: 81078207
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000DD39E4: BF870009
	s_cmp_eq_u32 s7, s6                                        // 000000DD39E8: BF060607
	s_cbranch_scc1 105                                         // 000000DD39EC: BFA20069 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi1ELi4EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x2694>
	s_lshl2_add_u32 s8, s7, 0x6400                             // 000000DD39F0: 8788FF07 00006400
	s_and_saveexec_b32 s9, s0                                  // 000000DD39F8: BE892000
	s_cbranch_execz 52                                         // 000000DD39FC: BFA50034 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi1ELi4EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x25d0>
	v_dual_mov_b32 v3, s8 :: v_dual_mov_b32 v8, v6             // 000000DD3A00: CA100008 03080106
	v_mov_b32_e32 v7, v5                                       // 000000DD3A08: 7E0E0305
	ds_load_b32 v3, v3                                         // 000000DD3A0C: D8D80000 03000003
	s_waitcnt lgkmcnt(0)                                       // 000000DD3A14: BF89FC07
	v_readfirstlane_b32 s1, v3                                 // 000000DD3A18: 7E020503
	s_mul_hi_i32 s1, s1, 0x66666667                            // 000000DD3A1C: 9701FF01 66666667
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000DD3A24: BF8704A9
	s_lshr_b32 s10, s1, 31                                     // 000000DD3A28: 850A9F01
	s_ashr_i32 s1, s1, 2                                       // 000000DD3A2C: 86018201
	s_add_i32 s1, s1, s10                                      // 000000DD3A30: 81010A01
	s_mov_b32 s10, 0                                           // 000000DD3A34: BE8A0080
	v_mad_i64_i32 v[3:4], null, 0x1400, s1, v[1:2]             // 000000DD3A38: D6FF7C03 040402FF 00001400
	s_nop 0                                                    // 000000DD3A44: BF800000
	s_nop 0                                                    // 000000DD3A48: BF800000
	s_nop 0                                                    // 000000DD3A4C: BF800000
	s_nop 0                                                    // 000000DD3A50: BF800000
	s_nop 0                                                    // 000000DD3A54: BF800000
	s_nop 0                                                    // 000000DD3A58: BF800000
	s_nop 0                                                    // 000000DD3A5C: BF800000
	s_nop 0                                                    // 000000DD3A60: BF800000
	s_nop 0                                                    // 000000DD3A64: BF800000
	s_nop 0                                                    // 000000DD3A68: BF800000
	s_nop 0                                                    // 000000DD3A6C: BF800000
	s_nop 0                                                    // 000000DD3A70: BF800000
	s_nop 0                                                    // 000000DD3A74: BF800000
	s_nop 0                                                    // 000000DD3A78: BF800000
	s_nop 0                                                    // 000000DD3A7C: BF800000
	global_load_b128 v[9:12], v[3:4], off                      // 000000DD3A80: DC5E0000 097C0003
	v_add_nc_u32_e32 v8, 0x100, v8                             // 000000DD3A88: 4A1010FF 00000100
	.long 0xd7006a03                                           // 000000DD3A90: D7006A03
	v_cndmask_b32_e32 v1, 0x1000, v3, vcc_lo                   // 000000DD3A94: 020206FF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DD3A9C: BF870191
	v_add_co_ci_u32_e64 v4, null, 0, v4, vcc_lo                // 000000DD3AA0: D5207C04 01AA0880
	.long 0xd4490001                                           // 000000DD3AA8: D4490001
	v_cndmask_b32_e32 v1, 63, v8, vcc_lo                       // 000000DD3AAC: 020210BF
	s_or_b32 s10, s1, s10                                      // 000000DD3AB0: 8C0A0A01
	s_waitcnt vmcnt(0)                                         // 000000DD3AB4: BF8903F7
	ds_store_b128 v7, v[9:12]                                  // 000000DD3AB8: DB7C0000 00000907
	v_add_nc_u32_e32 v7, 0x1000, v7                            // 000000DD3AC0: 4A0E0EFF 00001000
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 000000DD3AC8: 917E0A7E
	s_cbranch_execnz 65516                                     // 000000DD3ACC: BFA6FFEC <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi1ELi4EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x2580>
	s_or_b32 exec_lo, exec_lo, s9                              // 000000DD3AD0: 8C7E097E
	s_and_saveexec_b32 s9, s0                                  // 000000DD3AD4: BE892000
	s_cbranch_execz 65470                                      // 000000DD3AD8: BFA5FFBE <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi1ELi4EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x24d4>
	v_dual_mov_b32 v3, s8 :: v_dual_mov_b32 v8, v5             // 000000DD3ADC: CA100008 03080105
	v_mov_b32_e32 v7, v6                                       // 000000DD3AE4: 7E0E0306
	ds_load_b32 v3, v3 offset:4                                // 000000DD3AE8: D8D80004 03000003
	s_waitcnt lgkmcnt(0)                                       // 000000DD3AF0: BF89FC07
	v_readfirstlane_b32 s1, v3                                 // 000000DD3AF4: 7E020503
	s_mul_hi_i32 s1, s1, 0x66666667                            // 000000DD3AF8: 9701FF01 66666667
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000DD3B00: BF8704A9
	s_lshr_b32 s8, s1, 31                                      // 000000DD3B04: 85089F01
	s_ashr_i32 s1, s1, 2                                       // 000000DD3B08: 86018201
	s_add_i32 s1, s1, s8                                       // 000000DD3B0C: 81010801
	s_mov_b32 s8, 0                                            // 000000DD3B10: BE880080
	v_mad_i64_i32 v[3:4], null, 0x1400, s1, v[1:2]             // 000000DD3B14: D6FF7C03 040402FF 00001400
	s_nop 0                                                    // 000000DD3B20: BF800000
	s_nop 0                                                    // 000000DD3B24: BF800000
	s_nop 0                                                    // 000000DD3B28: BF800000
	s_nop 0                                                    // 000000DD3B2C: BF800000
	s_nop 0                                                    // 000000DD3B30: BF800000
	s_nop 0                                                    // 000000DD3B34: BF800000
	s_nop 0                                                    // 000000DD3B38: BF800000
	s_nop 0                                                    // 000000DD3B3C: BF800000
	global_load_b128 v[9:12], v[3:4], off                      // 000000DD3B40: DC5E0000 097C0003
	v_add_nc_u32_e32 v7, 0x100, v7                             // 000000DD3B48: 4A0E0EFF 00000100
	.long 0xd7006a03                                           // 000000DD3B50: D7006A03
	v_cndmask_b32_e32 v1, 0x1000, v3, vcc_lo                   // 000000DD3B54: 020206FF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DD3B5C: BF870191
	v_add_co_ci_u32_e64 v4, null, 0, v4, vcc_lo                // 000000DD3B60: D5207C04 01AA0880
	.long 0xd4490001                                           // 000000DD3B68: D4490001
	v_cndmask_b32_e32 v1, 63, v7, vcc_lo                       // 000000DD3B6C: 02020EBF
	s_or_b32 s8, s1, s8                                        // 000000DD3B70: 8C080801
	s_waitcnt vmcnt(0)                                         // 000000DD3B74: BF8903F7
	ds_store_b128 v8, v[9:12] offset:5120                      // 000000DD3B78: DB7C1400 00000908
	v_add_nc_u32_e32 v8, 0x1000, v8                            // 000000DD3B80: 4A1010FF 00001000
	s_and_not1_b32 exec_lo, exec_lo, s8                        // 000000DD3B88: 917E087E
	s_cbranch_execnz 65516                                     // 000000DD3B8C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi1ELi4EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x2640>
	s_branch 65424                                             // 000000DD3B90: BFA0FF90 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi1ELi4EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x24d4>
	s_bitcmp1_b32 s3, 0                                        // 000000DD3B94: BF0D8003
	s_cselect_b32 s1, -1, 0                                    // 000000DD3B98: 980180C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000DD3B9C: BF870009
	s_and_b32 vcc_lo, exec_lo, s1                              // 000000DD3BA0: 8B6A017E
	s_cbranch_vccz 59                                          // 000000DD3BA4: BFA3003B <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi1ELi4EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x2794>
	s_and_saveexec_b32 s1, s0                                  // 000000DD3BA8: BE812000
	s_cbranch_execz 56                                         // 000000DD3BAC: BFA50038 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi1ELi4EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x2790>
	s_lshl_b32 s0, s6, 2                                       // 000000DD3BB0: 84008206
	v_lshlrev_b32_e32 v3, 4, v65                               // 000000DD3BB4: 30068284
	v_mov_b32_e32 v1, s0                                       // 000000DD3BB8: 7E020200
	v_or_b32_e32 v4, 0xffffff00, v65                           // 000000DD3BBC: 380882FF FFFFFF00
	ds_load_b32 v1, v1 offset:25600                            // 000000DD3BC4: D8D86400 01000001
	s_waitcnt lgkmcnt(0)                                       // 000000DD3BCC: BF89FC07
	v_readfirstlane_b32 s0, v1                                 // 000000DD3BD0: 7E000501
	v_mad_u64_u32 v[1:2], null, 0x1400, s6, v[3:4]             // 000000DD3BD4: D6FE7C01 040C0CFF 00001400
	s_mul_hi_i32 s0, s0, 0x66666667                            // 000000DD3BE0: 9700FF00 66666667
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000DD3BE8: BF8704A9
	s_lshr_b32 s7, s0, 31                                      // 000000DD3BEC: 85079F00
	s_ashr_i32 s0, s0, 2                                       // 000000DD3BF0: 86008200
	s_add_i32 s0, s0, s7                                       // 000000DD3BF4: 81000700
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000DD3BF8: BF8700D9
	s_mul_i32 s6, s0, 0x1400                                   // 000000DD3BFC: 9606FF00 00001400
	s_mul_hi_i32 s0, s0, 0x1400                                // 000000DD3C04: 9700FF00 00001400
	s_add_u32 s6, s40, s6                                      // 000000DD3C0C: 80060628
	s_addc_u32 s0, s41, s0                                     // 000000DD3C10: 82000029
	.long 0xd7000602                                           // 000000DD3C14: D7000602
	v_cndmask_b32_e32 v1, s6, v3, vcc_lo                       // 000000DD3C18: 02020606
	v_add_co_ci_u32_e64 v3, null, s0, 0, s6                    // 000000DD3C1C: D5207C03 00190000
	s_mov_b32 s6, 0                                            // 000000DD3C24: BE860080
	s_nop 0                                                    // 000000DD3C28: BF800000
	s_nop 0                                                    // 000000DD3C2C: BF800000
	s_nop 0                                                    // 000000DD3C30: BF800000
	s_nop 0                                                    // 000000DD3C34: BF800000
	s_nop 0                                                    // 000000DD3C38: BF800000
	s_nop 0                                                    // 000000DD3C3C: BF800000
	global_load_b128 v[5:8], v[2:3], off                       // 000000DD3C40: DC5E0000 057C0002
	v_add_nc_u32_e32 v4, 0x100, v4                             // 000000DD3C48: 4A0808FF 00000100
	.long 0xd7006a02                                           // 000000DD3C50: D7006A02
	v_cndmask_b32_e32 v1, 0x1000, v2, vcc_lo                   // 000000DD3C54: 020204FF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DD3C5C: BF870191
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 000000DD3C60: D5207C03 01AA0680
	.long 0xd4490000                                           // 000000DD3C68: D4490000
	v_cndmask_b32_e32 v1, 63, v4, vcc_lo                       // 000000DD3C6C: 020208BF
	s_or_b32 s6, s0, s6                                        // 000000DD3C70: 8C060600
	s_waitcnt vmcnt(0)                                         // 000000DD3C74: BF8903F7
	ds_store_b128 v1, v[5:8]                                   // 000000DD3C78: DB7C0000 00000501
	v_add_nc_u32_e32 v1, 0x1000, v1                            // 000000DD3C80: 4A0202FF 00001000
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 000000DD3C88: 917E067E
	s_cbranch_execnz 65516                                     // 000000DD3C8C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi1ELi4EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x2740>
	s_or_b32 exec_lo, exec_lo, s1                              // 000000DD3C90: 8C7E017E
	s_mul_i32 s0, s4, 0xffffffec                               // 000000DD3C94: 9600FF04 FFFFFFEC
	s_and_not1_b32 vcc_lo, exec_lo, s5                         // 000000DD3C9C: 916A057E
	s_add_i32 s0, s0, s2                                       // 000000DD3CA0: 81000200
	s_waitcnt lgkmcnt(0)                                       // 000000DD3CA4: BF89FC07
	s_barrier                                                  // 000000DD3CA8: BFBD0000
	buffer_gl0_inv                                             // 000000DD3CAC: E0AC0000 00000000
	s_cbranch_vccnz 5022                                       // 000000DD3CB4: BFA4139E <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi1ELi4EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x7630>
	v_lshrrev_b32_e32 v1, 2, v65                               // 000000DD3CB8: 32028282
	v_bfe_u32 v2, v65, 2, 3                                    // 000000DD3CBC: D6100002 020D0541
	s_lshl_b32 s1, s0, 6                                       // 000000DD3CC4: 84018600
	s_add_u32 s4, s36, s38                                     // 000000DD3CC8: 80042624
	s_addc_u32 s5, s37, s39                                    // 000000DD3CCC: 82052725
	v_and_b32_e32 v1, 56, v1                                   // 000000DD3CD0: 360202B8
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DD3CD4: BF8700A1
	v_or3_b32 v21, s1, v1, v2                                  // 000000DD3CD8: D6580015 040A0201
	s_mov_b32 s1, 0                                            // 000000DD3CE0: BE810080
	v_ashrrev_i32_e32 v22, 31, v21                             // 000000DD3CE4: 342C2A9F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD3CE8: BF870091
	v_mad_i64_i32 v[0:1], null, 0x500, v0, v[21:22]            // 000000DD3CEC: D6FF7C00 045600FF 00000500
	v_mad_u64_u32 v[25:26], null, v0, 40, s[4:5]               // 000000DD3CF8: D6FE7C19 00115100
	v_mad_u64_u32 v[9:10], null, 0x500, v0, s[36:37]           // 000000DD3D00: D6FE7C09 009200FF 00000500
	v_and_b32_e32 v0, 3, v65                                   // 000000DD3D0C: 36008283
	scratch_store_b32 off, v0, off offset:400                  // 000000DD3D10: DC690190 007C0000
	v_mad_i32_i24 v26, v1, 40, v26                             // 000000DD3D18: D60A001A 04695101
	v_mad_i32_i24 v10, 0x500, v1, v10                          // 000000DD3D20: D60A000A 042A02FF 00000500
	v_lshlrev_b32_e32 v0, 4, v0                                // 000000DD3D2C: 30000084
	s_clause 0x1                                               // 000000DD3D30: BF850001
	global_load_b128 v[5:8], v[25:26], off                     // 000000DD3D34: DC5E0000 057C0019
	global_load_b128 v[1:4], v[25:26], off offset:16           // 000000DD3D3C: DC5E0010 017C0019
	.long 0xd7006a17                                           // 000000DD3D44: D7006A17
	v_cndmask_b32_e32 v1, v9, v0, vcc_lo                       // 000000DD3D48: 02020109
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DD3D4C: BF870001
	v_add_co_ci_u32_e64 v24, null, 0, v10, vcc_lo              // 000000DD3D50: D5207C18 01AA1480
	s_clause 0x3                                               // 000000DD3D58: BF850003
	global_load_b128 v[9:12], v[23:24], off                    // 000000DD3D5C: DC5E0000 097C0017
	global_load_b128 v[13:16], v[23:24], off offset:64         // 000000DD3D64: DC5E0040 0D7C0017
	global_load_b128 v[17:20], v[23:24], off offset:128        // 000000DD3D6C: DC5E0080 117C0017
	global_load_b64 v[25:26], v[25:26], off offset:32          // 000000DD3D74: DC560020 197C0019
	s_waitcnt vmcnt(5)                                         // 000000DD3D7C: BF8917F7
	v_cvt_f32_f16_e32 v0, v5                                   // 000000DD3D80: 7E001705
	s_clause 0x1                                               // 000000DD3D84: BF850001
	scratch_store_b32 off, v65, off offset:480                 // 000000DD3D88: DC6901E0 007C4100
	scratch_store_b32 off, v0, off                             // 000000DD3D90: DC690000 007C0000
	v_cvt_f32_f16_e32 v0, v133/*Invalid register, operand has 'VS_32_Lo128' register class*/// 000000DD3D98: 7E001785
	s_waitcnt vmcnt(2)                                         // 000000DD3D9C: BF890BF7
	v_and_b32_e32 v41, 0xf0f0f0f, v15                          // 000000DD3DA0: 36521EFF 0F0F0F0F
	v_lshrrev_b32_e32 v42, 4, v15                              // 000000DD3DA8: 32541E84
	v_and_b32_e32 v34, 0xf0f0f0f, v13                          // 000000DD3DAC: 36441AFF 0F0F0F0F
	v_lshrrev_b32_e32 v35, 4, v13                              // 000000DD3DB4: 32461A84
	scratch_store_b32 off, v0, off offset:4                    // 000000DD3DB8: DC690004 007C0000
	v_cvt_f32_f16_e32 v0, v6                                   // 000000DD3DC0: 7E001706
	v_lshrrev_b32_e32 v28, 4, v9                               // 000000DD3DC4: 32381284
	v_lshrrev_b32_e32 v30, 4, v10                              // 000000DD3DC8: 323C1484
	v_and_b32_e32 v29, 0xf0f0f0f, v10                          // 000000DD3DCC: 363A14FF 0F0F0F0F
	v_and_b32_e32 v31, 0xf0f0f0f, v11                          // 000000DD3DD4: 363E16FF 0F0F0F0F
	scratch_store_b32 off, v0, off offset:8                    // 000000DD3DDC: DC690008 007C0000
	v_cvt_f32_f16_e32 v0, v134/*Invalid register, operand has 'VS_32_Lo128' register class*/// 000000DD3DE4: 7E001786
	v_lshrrev_b32_e32 v11, 4, v11                              // 000000DD3DE8: 32161684
	v_lshrrev_b32_e32 v33, 4, v12                              // 000000DD3DEC: 32421884
	v_and_b32_e32 v32, 0xf0f0f0f, v12                          // 000000DD3DF0: 364018FF 0F0F0F0F
	v_lshrrev_b32_e32 v39, 4, v14                              // 000000DD3DF8: 324E1C84
	scratch_store_b32 off, v0, off offset:12                   // 000000DD3DFC: DC69000C 007C0000
	v_cvt_f32_f16_e32 v0, v7                                   // 000000DD3E04: 7E001707
	v_and_b32_e32 v38, 0xf0f0f0f, v14                          // 000000DD3E08: 364C1CFF 0F0F0F0F
	v_lshrrev_b32_e32 v44, 4, v16                              // 000000DD3E10: 32582084
	v_and_b32_e32 v43, 0xf0f0f0f, v16                          // 000000DD3E14: 365620FF 0F0F0F0F
	s_waitcnt vmcnt(1)                                         // 000000DD3E1C: BF8907F7
	v_lshrrev_b32_e32 v46, 4, v17                              // 000000DD3E20: 325C2284
	scratch_store_b32 off, v0, off offset:16                   // 000000DD3E24: DC690010 007C0000
	v_cvt_f32_f16_e32 v0, v135/*Invalid register, operand has 'VS_32_Lo128' register class*/// 000000DD3E2C: 7E001787
	v_and_b32_e32 v45, 0xf0f0f0f, v17                          // 000000DD3E30: 365A22FF 0F0F0F0F
	v_and_b32_e32 v47, 0xf0f0f0f, v18                          // 000000DD3E38: 365E24FF 0F0F0F0F
	v_lshrrev_b32_e32 v18, 4, v18                              // 000000DD3E40: 32242484
	v_and_b32_e32 v49, 0xf0f0f0f, v20                          // 000000DD3E44: 366228FF 0F0F0F0F
	scratch_store_b32 off, v0, off offset:20                   // 000000DD3E4C: DC690014 007C0000
	v_cvt_f32_f16_e32 v0, v8                                   // 000000DD3E54: 7E001708
	v_lshrrev_b32_e32 v20, 4, v20                              // 000000DD3E58: 32282884
	v_and_b32_e32 v48, 0xf0f0f0f, v19                          // 000000DD3E5C: 366026FF 0F0F0F0F
	v_lshrrev_b32_e32 v19, 4, v19                              // 000000DD3E64: 32262684
	scratch_store_b32 off, v0, off offset:24                   // 000000DD3E68: DC690018 007C0000
	v_cvt_f32_f16_e32 v0, v136/*Invalid register, operand has 'VS_32_Lo128' register class*/// 000000DD3E70: 7E001788
	v_and_b32_e32 v8, 0xf0f0f0f, v9                            // 000000DD3E74: 361012FF 0F0F0F0F
	scratch_store_b32 off, v0, off offset:28                   // 000000DD3E7C: DC69001C 007C0000
	v_cvt_f32_f16_e32 v0, v1                                   // 000000DD3E84: 7E001701
	scratch_store_b32 off, v0, off offset:32                   // 000000DD3E88: DC690020 007C0000
	v_cvt_f32_f16_e32 v0, v129/*Invalid register, operand has 'VS_32_Lo128' register class*/// 000000DD3E90: 7E001781
	scratch_store_b32 off, v0, off offset:36                   // 000000DD3E94: DC690024 007C0000
	v_cvt_f32_f16_e32 v0, v2                                   // 000000DD3E9C: 7E001702
	scratch_store_b32 off, v0, off offset:40                   // 000000DD3EA0: DC690028 007C0000
	v_cvt_f32_f16_e32 v0, v130/*Invalid register, operand has 'VS_32_Lo128' register class*/// 000000DD3EA8: 7E001782
	scratch_store_b32 off, v0, off offset:44                   // 000000DD3EAC: DC69002C 007C0000
	v_cvt_f32_f16_e32 v0, v3                                   // 000000DD3EB4: 7E001703
	scratch_store_b32 off, v0, off offset:48                   // 000000DD3EB8: DC690030 007C0000
	v_cvt_f32_f16_e32 v0, v131/*Invalid register, operand has 'VS_32_Lo128' register class*/// 000000DD3EC0: 7E001783
	scratch_store_b32 off, v0, off offset:52                   // 000000DD3EC4: DC690034 007C0000
	v_cvt_f32_f16_e32 v0, v4                                   // 000000DD3ECC: 7E001704
	scratch_store_b32 off, v0, off offset:56                   // 000000DD3ED0: DC690038 007C0000
	v_cvt_f32_f16_e32 v0, v132/*Invalid register, operand has 'VS_32_Lo128' register class*/// 000000DD3ED8: 7E001784
	scratch_store_b32 off, v0, off offset:60                   // 000000DD3EDC: DC69003C 007C0000
	s_clause 0x1                                               // 000000DD3EE4: BF850001
	global_load_b128 v[0:3], v[23:24], off offset:192          // 000000DD3EE8: DC5E00C0 007C0017
	global_load_b128 v[4:7], v[23:24], off offset:256          // 000000DD3EF0: DC5E0100 047C0017
	s_waitcnt vmcnt(1)                                         // 000000DD3EF8: BF8907F7
	v_and_b32_e32 v50, 0xf0f0f0f, v0                           // 000000DD3EFC: 366400FF 0F0F0F0F
	v_lshrrev_b32_e32 v51, 4, v0                               // 000000DD3F04: 32660084
	v_and_b32_e32 v52, 0xf0f0f0f, v1                           // 000000DD3F08: 366802FF 0F0F0F0F
	v_lshrrev_b32_e32 v53, 4, v1                               // 000000DD3F10: 326A0284
	v_and_b32_e32 v54, 0xf0f0f0f, v2                           // 000000DD3F14: 366C04FF 0F0F0F0F
	v_lshrrev_b32_e32 v55, 4, v2                               // 000000DD3F1C: 326E0484
	v_and_b32_e32 v56, 0xf0f0f0f, v3                           // 000000DD3F20: 367006FF 0F0F0F0F
	v_lshrrev_b32_e32 v57, 4, v3                               // 000000DD3F28: 32720684
	s_waitcnt vmcnt(0)                                         // 000000DD3F2C: BF8903F7
	v_and_b32_e32 v58, 0xf0f0f0f, v4                           // 000000DD3F30: 367408FF 0F0F0F0F
	v_lshrrev_b32_e32 v59, 4, v4                               // 000000DD3F38: 32760884
	v_and_b32_e32 v60, 0xf0f0f0f, v5                           // 000000DD3F3C: 36780AFF 0F0F0F0F
	v_lshrrev_b32_e32 v61, 4, v5                               // 000000DD3F44: 327A0A84
	v_and_b32_e32 v62, 0xf0f0f0f, v6                           // 000000DD3F48: 367C0CFF 0F0F0F0F
	v_lshrrev_b32_e32 v63, 4, v6                               // 000000DD3F50: 327E0C84
	v_and_b32_e32 v64, 0xf0f0f0f, v7                           // 000000DD3F54: 36800EFF 0F0F0F0F
	v_lshrrev_b32_e32 v65, 4, v7                               // 000000DD3F5C: 32820E84
	s_clause 0x1                                               // 000000DD3F60: BF850001
	global_load_b128 v[0:3], v[23:24], off offset:320          // 000000DD3F64: DC5E0140 007C0017
	global_load_b128 v[4:7], v[23:24], off offset:384          // 000000DD3F6C: DC5E0180 047C0017
	s_waitcnt vmcnt(1)                                         // 000000DD3F74: BF8907F7
	v_and_b32_e32 v66, 0xf0f0f0f, v0                           // 000000DD3F78: 368400FF 0F0F0F0F
	v_lshrrev_b32_e32 v67, 4, v0                               // 000000DD3F80: 32860084
	v_and_b32_e32 v68, 0xf0f0f0f, v1                           // 000000DD3F84: 368802FF 0F0F0F0F
	v_lshrrev_b32_e32 v71, 4, v1                               // 000000DD3F8C: 328E0284
	v_and_b32_e32 v72, 0xf0f0f0f, v2                           // 000000DD3F90: 369004FF 0F0F0F0F
	v_lshrrev_b32_e32 v73, 4, v2                               // 000000DD3F98: 32920484
	v_and_b32_e32 v74, 0xf0f0f0f, v3                           // 000000DD3F9C: 369406FF 0F0F0F0F
	v_lshrrev_b32_e32 v75, 4, v3                               // 000000DD3FA4: 32960684
	s_waitcnt vmcnt(0)                                         // 000000DD3FA8: BF8903F7
	v_and_b32_e32 v76, 0xf0f0f0f, v4                           // 000000DD3FAC: 369808FF 0F0F0F0F
	v_lshrrev_b32_e32 v77, 4, v4                               // 000000DD3FB4: 329A0884
	v_and_b32_e32 v78, 0xf0f0f0f, v5                           // 000000DD3FB8: 369C0AFF 0F0F0F0F
	v_lshrrev_b32_e32 v79, 4, v5                               // 000000DD3FC0: 329E0A84
	v_and_b32_e32 v80, 0xf0f0f0f, v6                           // 000000DD3FC4: 36A00CFF 0F0F0F0F
	v_lshrrev_b32_e32 v81, 4, v6                               // 000000DD3FCC: 32A20C84
	v_and_b32_e32 v82, 0xf0f0f0f, v7                           // 000000DD3FD0: 36A40EFF 0F0F0F0F
	v_lshrrev_b32_e32 v83, 4, v7                               // 000000DD3FD8: 32A60E84
	s_clause 0x1                                               // 000000DD3FDC: BF850001
	global_load_b128 v[0:3], v[23:24], off offset:448          // 000000DD3FE0: DC5E01C0 007C0017
	global_load_b128 v[4:7], v[23:24], off offset:512          // 000000DD3FE8: DC5E0200 047C0017
	s_waitcnt vmcnt(1)                                         // 000000DD3FF0: BF8907F7
	v_and_b32_e32 v84, 0xf0f0f0f, v0                           // 000000DD3FF4: 36A800FF 0F0F0F0F
	v_lshrrev_b32_e32 v85, 4, v0                               // 000000DD3FFC: 32AA0084
	v_and_b32_e32 v86, 0xf0f0f0f, v1                           // 000000DD4000: 36AC02FF 0F0F0F0F
	v_lshrrev_b32_e32 v87, 4, v1                               // 000000DD4008: 32AE0284
	v_and_b32_e32 v88, 0xf0f0f0f, v2                           // 000000DD400C: 36B004FF 0F0F0F0F
	v_lshrrev_b32_e32 v89, 4, v2                               // 000000DD4014: 32B20484
	v_and_b32_e32 v90, 0xf0f0f0f, v3                           // 000000DD4018: 36B406FF 0F0F0F0F
	v_lshrrev_b32_e32 v91, 4, v3                               // 000000DD4020: 32B60684
	s_waitcnt vmcnt(0)                                         // 000000DD4024: BF8903F7
	v_and_b32_e32 v92, 0xf0f0f0f, v4                           // 000000DD4028: 36B808FF 0F0F0F0F
	v_lshrrev_b32_e32 v93, 4, v4                               // 000000DD4030: 32BA0884
	v_and_b32_e32 v94, 0xf0f0f0f, v5                           // 000000DD4034: 36BC0AFF 0F0F0F0F
	v_lshrrev_b32_e32 v95, 4, v5                               // 000000DD403C: 32BE0A84
	v_and_b32_e32 v100, 0xf0f0f0f, v6                          // 000000DD4040: 36C80CFF 0F0F0F0F
	v_lshrrev_b32_e32 v97, 4, v6                               // 000000DD4048: 32C20C84
	v_and_b32_e32 v101, 0xf0f0f0f, v7                          // 000000DD404C: 36CA0EFF 0F0F0F0F
	v_lshrrev_b32_e32 v102, 4, v7                              // 000000DD4054: 32CC0E84
	s_clause 0x1                                               // 000000DD4058: BF850001
	global_load_b128 v[0:3], v[23:24], off offset:576          // 000000DD405C: DC5E0240 007C0017
	global_load_b128 v[4:7], v[23:24], off offset:640          // 000000DD4064: DC5E0280 047C0017
	s_waitcnt vmcnt(1)                                         // 000000DD406C: BF8907F7
	v_and_b32_e32 v106, 0xf0f0f0f, v0                          // 000000DD4070: 36D400FF 0F0F0F0F
	v_lshrrev_b32_e32 v107, 4, v0                              // 000000DD4078: 32D60084
	v_and_b32_e32 v108, 0xf0f0f0f, v1                          // 000000DD407C: 36D802FF 0F0F0F0F
	v_lshrrev_b32_e32 v109, 4, v1                              // 000000DD4084: 32DA0284
	v_and_b32_e32 v110, 0xf0f0f0f, v2                          // 000000DD4088: 36DC04FF 0F0F0F0F
	v_lshrrev_b32_e32 v111, 4, v2                              // 000000DD4090: 32DE0484
	v_and_b32_e32 v112, 0xf0f0f0f, v3                          // 000000DD4094: 36E006FF 0F0F0F0F
	v_lshrrev_b32_e32 v113, 4, v3                              // 000000DD409C: 32E20684
	s_waitcnt vmcnt(0)                                         // 000000DD40A0: BF8903F7
	v_and_b32_e32 v114, 0xf0f0f0f, v4                          // 000000DD40A4: 36E408FF 0F0F0F0F
	v_lshrrev_b32_e32 v115, 4, v4                              // 000000DD40AC: 32E60884
	v_and_b32_e32 v116, 0xf0f0f0f, v5                          // 000000DD40B0: 36E80AFF 0F0F0F0F
	v_lshrrev_b32_e32 v117, 4, v5                              // 000000DD40B8: 32EA0A84
	v_and_b32_e32 v118, 0xf0f0f0f, v6                          // 000000DD40BC: 36EC0CFF 0F0F0F0F
	v_lshrrev_b32_e32 v119, 4, v6                              // 000000DD40C4: 32EE0C84
	v_and_b32_e32 v120, 0xf0f0f0f, v7                          // 000000DD40C8: 36F00EFF 0F0F0F0F
	v_lshrrev_b32_e32 v121, 4, v7                              // 000000DD40D0: 32F20E84
	s_clause 0x1                                               // 000000DD40D4: BF850001
	global_load_b128 v[0:3], v[23:24], off offset:704          // 000000DD40D8: DC5E02C0 007C0017
	global_load_b128 v[4:7], v[23:24], off offset:768          // 000000DD40E0: DC5E0300 047C0017
	s_waitcnt vmcnt(1)                                         // 000000DD40E8: BF8907F7
	v_and_b32_e32 v122, 0xf0f0f0f, v0                          // 000000DD40EC: 36F400FF 0F0F0F0F
	v_lshrrev_b32_e32 v123, 4, v0                              // 000000DD40F4: 32F60084
	v_and_b32_e32 v124, 0xf0f0f0f, v1                          // 000000DD40F8: 36F802FF 0F0F0F0F
	v_lshrrev_b32_e32 v125, 4, v1                              // 000000DD4100: 32FA0284
	v_and_b32_e32 v126, 0xf0f0f0f, v2                          // 000000DD4104: 36FC04FF 0F0F0F0F
	v_lshrrev_b32_e32 v127, 4, v2                              // 000000DD410C: 32FE0484
	v_and_b32_e32 v128, 0xf0f0f0f, v3                          // 000000DD4110: 370006FF 0F0F0F0F
	v_lshrrev_b32_e32 v129, 4, v3                              // 000000DD4118: 33020684
	s_waitcnt vmcnt(0)                                         // 000000DD411C: BF8903F7
	v_and_b32_e32 v130, 0xf0f0f0f, v4                          // 000000DD4120: 370408FF 0F0F0F0F
	v_lshrrev_b32_e32 v131, 4, v4                              // 000000DD4128: 33060884
	v_and_b32_e32 v132, 0xf0f0f0f, v5                          // 000000DD412C: 37080AFF 0F0F0F0F
	v_lshrrev_b32_e32 v133, 4, v5                              // 000000DD4134: 330A0A84
	v_and_b32_e32 v134, 0xf0f0f0f, v6                          // 000000DD4138: 370C0CFF 0F0F0F0F
	v_lshrrev_b32_e32 v135, 4, v6                              // 000000DD4140: 330E0C84
	v_and_b32_e32 v136, 0xf0f0f0f, v7                          // 000000DD4144: 37100EFF 0F0F0F0F
	v_lshrrev_b32_e32 v137, 4, v7                              // 000000DD414C: 33120E84
	s_clause 0x1                                               // 000000DD4150: BF850001
	global_load_b128 v[0:3], v[23:24], off offset:832          // 000000DD4154: DC5E0340 007C0017
	global_load_b128 v[4:7], v[23:24], off offset:896          // 000000DD415C: DC5E0380 047C0017
	s_waitcnt vmcnt(1)                                         // 000000DD4164: BF8907F7
	v_and_b32_e32 v138, 0xf0f0f0f, v0                          // 000000DD4168: 371400FF 0F0F0F0F
	v_lshrrev_b32_e32 v139, 4, v0                              // 000000DD4170: 33160084
	v_and_b32_e32 v140, 0xf0f0f0f, v1                          // 000000DD4174: 371802FF 0F0F0F0F
	v_lshrrev_b32_e32 v141, 4, v1                              // 000000DD417C: 331A0284
	v_and_b32_e32 v142, 0xf0f0f0f, v2                          // 000000DD4180: 371C04FF 0F0F0F0F
	v_lshrrev_b32_e32 v143, 4, v2                              // 000000DD4188: 331E0484
	v_and_b32_e32 v144, 0xf0f0f0f, v3                          // 000000DD418C: 372006FF 0F0F0F0F
	v_lshrrev_b32_e32 v145, 4, v3                              // 000000DD4194: 33220684
	s_waitcnt vmcnt(0)                                         // 000000DD4198: BF8903F7
	v_and_b32_e32 v146, 0xf0f0f0f, v4                          // 000000DD419C: 372408FF 0F0F0F0F
	v_lshrrev_b32_e32 v147, 4, v4                              // 000000DD41A4: 33260884
	v_and_b32_e32 v148, 0xf0f0f0f, v5                          // 000000DD41A8: 37280AFF 0F0F0F0F
	v_lshrrev_b32_e32 v149, 4, v5                              // 000000DD41B0: 332A0A84
	v_and_b32_e32 v150, 0xf0f0f0f, v6                          // 000000DD41B4: 372C0CFF 0F0F0F0F
	v_lshrrev_b32_e32 v151, 4, v6                              // 000000DD41BC: 332E0C84
	v_and_b32_e32 v152, 0xf0f0f0f, v7                          // 000000DD41C0: 37300EFF 0F0F0F0F
	v_lshrrev_b32_e32 v153, 4, v7                              // 000000DD41C8: 33320E84
	s_clause 0x1                                               // 000000DD41CC: BF850001
	global_load_b128 v[0:3], v[23:24], off offset:960          // 000000DD41D0: DC5E03C0 007C0017
	global_load_b128 v[4:7], v[23:24], off offset:1024         // 000000DD41D8: DC5E0400 047C0017
	s_waitcnt vmcnt(1)                                         // 000000DD41E0: BF8907F7
	v_and_b32_e32 v156, 0xf0f0f0f, v0                          // 000000DD41E4: 373800FF 0F0F0F0F
	v_lshrrev_b32_e32 v157, 4, v0                              // 000000DD41EC: 333A0084
	v_and_b32_e32 v158, 0xf0f0f0f, v1                          // 000000DD41F0: 373C02FF 0F0F0F0F
	v_lshrrev_b32_e32 v159, 4, v1                              // 000000DD41F8: 333E0284
	v_and_b32_e32 v160, 0xf0f0f0f, v2                          // 000000DD41FC: 374004FF 0F0F0F0F
	v_lshrrev_b32_e32 v161, 4, v2                              // 000000DD4204: 33420484
	v_and_b32_e32 v162, 0xf0f0f0f, v3                          // 000000DD4208: 374406FF 0F0F0F0F
	v_lshrrev_b32_e32 v163, 4, v3                              // 000000DD4210: 33460684
	s_waitcnt vmcnt(0)                                         // 000000DD4214: BF8903F7
	v_and_b32_e32 v164, 0xf0f0f0f, v4                          // 000000DD4218: 374808FF 0F0F0F0F
	v_lshrrev_b32_e32 v165, 4, v4                              // 000000DD4220: 334A0884
	v_and_b32_e32 v166, 0xf0f0f0f, v5                          // 000000DD4224: 374C0AFF 0F0F0F0F
	v_lshrrev_b32_e32 v167, 4, v5                              // 000000DD422C: 334E0A84
	v_and_b32_e32 v168, 0xf0f0f0f, v6                          // 000000DD4230: 37500CFF 0F0F0F0F
	v_lshrrev_b32_e32 v169, 4, v6                              // 000000DD4238: 33520C84
	v_and_b32_e32 v170, 0xf0f0f0f, v7                          // 000000DD423C: 37540EFF 0F0F0F0F
	v_lshrrev_b32_e32 v171, 4, v7                              // 000000DD4244: 33560E84
	s_clause 0x1                                               // 000000DD4248: BF850001
	global_load_b128 v[0:3], v[23:24], off offset:1088         // 000000DD424C: DC5E0440 007C0017
	global_load_b128 v[4:7], v[23:24], off offset:1152         // 000000DD4254: DC5E0480 047C0017
	s_waitcnt vmcnt(1)                                         // 000000DD425C: BF8907F7
	v_and_b32_e32 v172, 0xf0f0f0f, v0                          // 000000DD4260: 375800FF 0F0F0F0F
	v_lshrrev_b32_e32 v173, 4, v0                              // 000000DD4268: 335A0084
	s_waitcnt vmcnt(0)                                         // 000000DD426C: BF8903F7
	v_lshrrev_b32_e32 v0, 4, v6                                // 000000DD4270: 32000C84
	v_and_b32_e32 v174, 0xf0f0f0f, v1                          // 000000DD4274: 375C02FF 0F0F0F0F
	v_lshrrev_b32_e32 v175, 4, v1                              // 000000DD427C: 335E0284
	v_and_b32_e32 v176, 0xf0f0f0f, v2                          // 000000DD4280: 376004FF 0F0F0F0F
	v_lshrrev_b32_e32 v177, 4, v2                              // 000000DD4288: 33620484
	scratch_store_b32 off, v0, off offset:336                  // 000000DD428C: DC690150 007C0000
	v_lshrrev_b32_e32 v0, 4, v7                                // 000000DD4294: 32000E84
	v_and_b32_e32 v178, 0xf0f0f0f, v3                          // 000000DD4298: 376406FF 0F0F0F0F
	v_lshrrev_b32_e32 v179, 4, v3                              // 000000DD42A0: 33660684
	v_and_b32_e32 v104, 0xf0f0f0f, v4                          // 000000DD42A4: 36D008FF 0F0F0F0F
	v_lshrrev_b32_e32 v180, 4, v4                              // 000000DD42AC: 33680884
	scratch_store_b32 off, v0, off offset:404                  // 000000DD42B0: DC690194 007C0000
	global_load_b128 v[0:3], v[23:24], off offset:1216         // 000000DD42B8: DC5E04C0 007C0017
	v_and_b32_e32 v69, 0xf0f0f0f, v5                           // 000000DD42C0: 368A0AFF 0F0F0F0F
	v_lshrrev_b32_e32 v27, 4, v5                               // 000000DD42C8: 32360A84
	v_and_b32_e32 v36, 0xf0f0f0f, v6                           // 000000DD42CC: 36480CFF 0F0F0F0F
	v_and_b32_e32 v16, 0xf0f0f0f, v7                           // 000000DD42D4: 36200EFF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DD42DC: BF870003
	v_and_b32_e32 v27, 0xf0f0f0f, v27                          // 000000DD42E0: 363636FF 0F0F0F0F
	s_waitcnt vmcnt(0)                                         // 000000DD42E8: BF8903F7
	v_and_b32_e32 v15, 0xf0f0f0f, v0                           // 000000DD42EC: 361E00FF 0F0F0F0F
	v_lshrrev_b32_e32 v0, 4, v0                                // 000000DD42F4: 32000084
	v_and_b32_e32 v13, 0xf0f0f0f, v1                           // 000000DD42F8: 361A02FF 0F0F0F0F
	v_and_b32_e32 v10, 0xf0f0f0f, v2                           // 000000DD4300: 361404FF 0F0F0F0F
	v_and_b32_e32 v9, 0xf0f0f0f, v3                            // 000000DD4308: 361206FF 0F0F0F0F
	scratch_store_b32 off, v0, off offset:356                  // 000000DD4310: DC690164 007C0000
	v_lshrrev_b32_e32 v0, 4, v1                                // 000000DD4318: 32000284
	scratch_store_b32 off, v0, off offset:352                  // 000000DD431C: DC690160 007C0000
	v_lshrrev_b32_e32 v0, 4, v2                                // 000000DD4324: 32000484
	scratch_store_b32 off, v0, off offset:348                  // 000000DD4328: DC69015C 007C0000
	v_lshrrev_b32_e32 v0, 4, v3                                // 000000DD4330: 32000684
	scratch_store_b32 off, v0, off offset:344                  // 000000DD4334: DC690158 007C0000
	.long 0xd73c0000                                           // 000000DD433C: D73C0000
	v_cndmask_b32_e32 v1, 2, v21, vcc_lo                       // 000000DD4340: 02022A82
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD4344: BF870091
	.long 0xd7006a00                                           // 000000DD4348: D7006A00
	v_cndmask_b32_e32 v1, s48, v0, vcc_lo                      // 000000DD434C: 02020030
	v_add_co_ci_u32_e64 v1, null, s49, v1, vcc_lo              // 000000DD4350: D5207C01 01AA0231
	scratch_store_b64 off, v[0:1], off offset:472              // 000000DD4358: DC6D01D8 007C0000
	v_and_b32_e32 v0, 0xf0f0f0f, v28                           // 000000DD4360: 360038FF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DD4368: BF870001
	v_perm_b32 v1, v0, v8, 0xc040c00                           // 000000DD436C: D6440001 03FE1100 0C040C00
	scratch_store_b32 off, v1, off offset:380                  // 000000DD4378: DC69017C 007C0100
	v_perm_b32 v1, v0, v8, 0xc050c01                           // 000000DD4380: D6440001 03FE1100 0C050C01
	scratch_store_b32 off, v1, off offset:384                  // 000000DD438C: DC690180 007C0100
	v_perm_b32 v1, v0, v8, 0xc060c02                           // 000000DD4394: D6440001 03FE1100 0C060C02
	v_perm_b32 v0, v0, v8, 0xc070c03                           // 000000DD43A0: D6440000 03FE1100 0C070C03
	s_clause 0x1                                               // 000000DD43AC: BF850001
	scratch_store_b32 off, v1, off offset:388                  // 000000DD43B0: DC690184 007C0100
	scratch_store_b32 off, v0, off offset:392                  // 000000DD43B8: DC690188 007C0000
	v_and_b32_e32 v0, 0xf0f0f0f, v30                           // 000000DD43C0: 36003CFF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DD43C8: BF870001
	v_perm_b32 v1, v0, v29, 0xc040c00                          // 000000DD43CC: D6440001 03FE3B00 0C040C00
	scratch_store_b32 off, v1, off offset:364                  // 000000DD43D8: DC69016C 007C0100
	v_perm_b32 v1, v0, v29, 0xc050c01                          // 000000DD43E0: D6440001 03FE3B00 0C050C01
	scratch_store_b32 off, v1, off offset:368                  // 000000DD43EC: DC690170 007C0100
	v_perm_b32 v1, v0, v29, 0xc060c02                          // 000000DD43F4: D6440001 03FE3B00 0C060C02
	v_perm_b32 v0, v0, v29, 0xc070c03                          // 000000DD4400: D6440000 03FE3B00 0C070C03
	s_clause 0x1                                               // 000000DD440C: BF850001
	scratch_store_b32 off, v1, off offset:372                  // 000000DD4410: DC690174 007C0100
	scratch_store_b32 off, v0, off offset:360                  // 000000DD4418: DC690168 007C0000
	v_and_b32_e32 v0, 0xf0f0f0f, v11                           // 000000DD4420: 360016FF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DD4428: BF870001
	v_perm_b32 v1, v0, v31, 0xc040c00                          // 000000DD442C: D6440001 03FE3F00 0C040C00
	v_perm_b32 v181, v0, v31, 0xc050c01                        // 000000DD4438: D64400B5 03FE3F00 0C050C01
	v_perm_b32 v182, v0, v31, 0xc070c03                        // 000000DD4444: D64400B6 03FE3F00 0C070C03
	scratch_store_b32 off, v1, off offset:376                  // 000000DD4450: DC690178 007C0100
	v_perm_b32 v1, v0, v31, 0xc060c02                          // 000000DD4458: D6440001 03FE3F00 0C060C02
	v_and_b32_e32 v0, 0xf0f0f0f, v33                           // 000000DD4464: 360042FF 0F0F0F0F
	scratch_store_b32 off, v1, off offset:396                  // 000000DD446C: DC69018C 007C0100
	v_perm_b32 v183, v0, v32, 0xc040c00                        // 000000DD4474: D64400B7 03FE4100 0C040C00
	v_perm_b32 v184, v0, v32, 0xc050c01                        // 000000DD4480: D64400B8 03FE4100 0C050C01
	v_perm_b32 v185, v0, v32, 0xc060c02                        // 000000DD448C: D64400B9 03FE4100 0C060C02
	v_perm_b32 v186, v0, v32, 0xc070c03                        // 000000DD4498: D64400BA 03FE4100 0C070C03
	v_and_b32_e32 v0, 0xf0f0f0f, v35                           // 000000DD44A4: 360046FF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DD44AC: BF870001
	v_perm_b32 v187, v0, v34, 0xc040c00                        // 000000DD44B0: D64400BB 03FE4500 0C040C00
	v_perm_b32 v188, v0, v34, 0xc050c01                        // 000000DD44BC: D64400BC 03FE4500 0C050C01
	v_perm_b32 v189, v0, v34, 0xc060c02                        // 000000DD44C8: D64400BD 03FE4500 0C060C02
	v_perm_b32 v190, v0, v34, 0xc070c03                        // 000000DD44D4: D64400BE 03FE4500 0C070C03
	v_and_b32_e32 v0, 0xf0f0f0f, v39                           // 000000DD44E0: 36004EFF 0F0F0F0F
	v_and_b32_e32 v39, 0xf0f0f0f, v87                          // 000000DD44E8: 364EAEFF 0F0F0F0F
	v_and_b32_e32 v87, 0xf0f0f0f, v137                         // 000000DD44F0: 36AF12FF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DD44F8: BF870003
	v_perm_b32 v191, v0, v38, 0xc040c00                        // 000000DD44FC: D64400BF 03FE4D00 0C040C00
	v_perm_b32 v192, v0, v38, 0xc050c01                        // 000000DD4508: D64400C0 03FE4D00 0C050C01
	v_perm_b32 v193, v0, v38, 0xc060c02                        // 000000DD4514: D64400C1 03FE4D00 0C060C02
	v_perm_b32 v194, v0, v38, 0xc070c03                        // 000000DD4520: D64400C2 03FE4D00 0C070C03
	v_and_b32_e32 v0, 0xf0f0f0f, v42                           // 000000DD452C: 360054FF 0F0F0F0F
	v_and_b32_e32 v38, 0xf0f0f0f, v85                          // 000000DD4534: 364CAAFF 0F0F0F0F
	v_perm_b32 v70, v39, v86, 0xc040c00                        // 000000DD453C: D6440046 03FEAD27 0C040C00
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DD4548: BF870003
	v_perm_b32 v195, v0, v41, 0xc040c00                        // 000000DD454C: D64400C3 03FE5300 0C040C00
	v_perm_b32 v196, v0, v41, 0xc050c01                        // 000000DD4558: D64400C4 03FE5300 0C050C01
	v_perm_b32 v197, v0, v41, 0xc060c02                        // 000000DD4564: D64400C5 03FE5300 0C060C02
	v_perm_b32 v198, v0, v41, 0xc070c03                        // 000000DD4570: D64400C6 03FE5300 0C070C03
	v_and_b32_e32 v0, 0xf0f0f0f, v44                           // 000000DD457C: 360058FF 0F0F0F0F
	v_perm_b32 v96, v38, v84, 0xc070c03                        // 000000DD4584: D6440060 03FEA926 0C070C03
	s_delay_alu instid0(VALU_DEP_2)                            // 000000DD4590: BF870002
	v_perm_b32 v199, v0, v43, 0xc040c00                        // 000000DD4594: D64400C7 03FE5700 0C040C00
	v_perm_b32 v200, v0, v43, 0xc050c01                        // 000000DD45A0: D64400C8 03FE5700 0C050C01
	v_perm_b32 v201, v0, v43, 0xc060c02                        // 000000DD45AC: D64400C9 03FE5700 0C060C02
	v_perm_b32 v202, v0, v43, 0xc070c03                        // 000000DD45B8: D64400CA 03FE5700 0C070C03
	v_and_b32_e32 v0, 0xf0f0f0f, v46                           // 000000DD45C4: 36005CFF 0F0F0F0F
	v_and_b32_e32 v43, 0xf0f0f0f, v91                          // 000000DD45CC: 3656B6FF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_2)                            // 000000DD45D4: BF870002
	v_perm_b32 v203, v0, v45, 0xc040c00                        // 000000DD45D8: D64400CB 03FE5B00 0C040C00
	v_perm_b32 v204, v0, v45, 0xc050c01                        // 000000DD45E4: D64400CC 03FE5B00 0C050C01
	v_perm_b32 v205, v0, v45, 0xc060c02                        // 000000DD45F0: D64400CD 03FE5B00 0C060C02
	v_perm_b32 v206, v0, v45, 0xc070c03                        // 000000DD45FC: D64400CE 03FE5B00 0C070C03
	v_and_b32_e32 v0, 0xf0f0f0f, v18                           // 000000DD4608: 360024FF 0F0F0F0F
	v_and_b32_e32 v18, 0xf0f0f0f, v20                          // 000000DD4610: 362428FF 0F0F0F0F
	v_perm_b32 v240, v43, v90, 0xc050c01                       // 000000DD4618: D64400F0 03FEB52B 0C050C01
	v_perm_b32 v236, v43, v90, 0xc060c02                       // 000000DD4624: D64400EC 03FEB52B 0C060C02
	v_perm_b32 v239, v43, v90, 0xc070c03                       // 000000DD4630: D64400EF 03FEB52B 0C070C03
	v_perm_b32 v207, v0, v47, 0xc040c00                        // 000000DD463C: D64400CF 03FE5F00 0C040C00
	v_perm_b32 v214, v18, v49, 0xc040c00                       // 000000DD4648: D64400D6 03FE6312 0C040C00
	v_perm_b32 v215, v18, v49, 0xc050c01                       // 000000DD4654: D64400D7 03FE6312 0C050C01
	v_perm_b32 v216, v18, v49, 0xc060c02                       // 000000DD4660: D64400D8 03FE6312 0C060C02
	v_perm_b32 v217, v18, v49, 0xc070c03                       // 000000DD466C: D64400D9 03FE6312 0C070C03
	v_and_b32_e32 v18, 0xf0f0f0f, v51                          // 000000DD4678: 362466FF 0F0F0F0F
	v_perm_b32 v208, v0, v47, 0xc050c01                        // 000000DD4680: D64400D0 03FE5F00 0C050C01
	v_perm_b32 v209, v0, v47, 0xc060c02                        // 000000DD468C: D64400D1 03FE5F00 0C060C02
	v_perm_b32 v210, v0, v47, 0xc070c03                        // 000000DD4698: D64400D2 03FE5F00 0C070C03
	v_and_b32_e32 v0, 0xf0f0f0f, v19                           // 000000DD46A4: 360026FF 0F0F0F0F
	v_perm_b32 v218, v18, v50, 0xc040c00                       // 000000DD46AC: D64400DA 03FE6512 0C040C00
	v_perm_b32 v219, v18, v50, 0xc050c01                       // 000000DD46B8: D64400DB 03FE6512 0C050C01
	v_perm_b32 v220, v18, v50, 0xc060c02                       // 000000DD46C4: D64400DC 03FE6512 0C060C02
	v_perm_b32 v221, v18, v50, 0xc070c03                       // 000000DD46D0: D64400DD 03FE6512 0C070C03
	v_and_b32_e32 v18, 0xf0f0f0f, v53                          // 000000DD46DC: 36246AFF 0F0F0F0F
	v_perm_b32 v211, v0, v48, 0xc040c00                        // 000000DD46E4: D64400D3 03FE6100 0C040C00
	v_perm_b32 v212, v0, v48, 0xc050c01                        // 000000DD46F0: D64400D4 03FE6100 0C050C01
	v_perm_b32 v213, v0, v48, 0xc060c02                        // 000000DD46FC: D64400D5 03FE6100 0C060C02
	v_perm_b32 v0, v0, v48, 0xc070c03                          // 000000DD4708: D6440000 03FE6100 0C070C03
	v_perm_b32 v222, v18, v52, 0xc040c00                       // 000000DD4714: D64400DE 03FE6912 0C040C00
	v_perm_b32 v223, v18, v52, 0xc050c01                       // 000000DD4720: D64400DF 03FE6912 0C050C01
	v_perm_b32 v224, v18, v52, 0xc060c02                       // 000000DD472C: D64400E0 03FE6912 0C060C02
	v_perm_b32 v225, v18, v52, 0xc070c03                       // 000000DD4738: D64400E1 03FE6912 0C070C03
	v_and_b32_e32 v18, 0xf0f0f0f, v55                          // 000000DD4744: 36246EFF 0F0F0F0F
	v_perm_b32 v52, v38, v84, 0xc040c00                        // 000000DD474C: D6440034 03FEA926 0C040C00
	v_perm_b32 v53, v38, v84, 0xc050c01                        // 000000DD4758: D6440035 03FEA926 0C050C01
	v_or_b32_e32 v0, 0x64006400, v0                            // 000000DD4764: 380000FF 64006400
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DD476C: BF870004
	v_perm_b32 v226, v18, v54, 0xc040c00                       // 000000DD4770: D64400E2 03FE6D12 0C040C00
	v_perm_b32 v227, v18, v54, 0xc050c01                       // 000000DD477C: D64400E3 03FE6D12 0C050C01
	v_perm_b32 v228, v18, v54, 0xc060c02                       // 000000DD4788: D64400E4 03FE6D12 0C060C02
	v_perm_b32 v229, v18, v54, 0xc070c03                       // 000000DD4794: D64400E5 03FE6D12 0C070C03
	v_and_b32_e32 v18, 0xf0f0f0f, v57                          // 000000DD47A0: 362472FF 0F0F0F0F
	.long 0xcc0f4000                                           // 000000DD47A8: CC0F4000
	v_mul_i32_i24_e32 v1, 0xe408, v0                           // 000000DD47AC: 120200FF 0000E408
	v_or_b32_e32 v85, 0x64006400, v226                         // 000000DD47B4: 38ABC4FF 64006400
	v_perm_b32 v226, v87, v136, 0xc040c00                      // 000000DD47BC: D64400E2 03FF1157 0C040C00
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000DD47C8: BF8700D4
	v_perm_b32 v230, v18, v56, 0xc040c00                       // 000000DD47CC: D64400E6 03FE7112 0C040C00
	v_perm_b32 v231, v18, v56, 0xc050c01                       // 000000DD47D8: D64400E7 03FE7112 0C050C01
	v_perm_b32 v232, v18, v56, 0xc060c02                       // 000000DD47E4: D64400E8 03FE7112 0C060C02
	v_perm_b32 v233, v18, v56, 0xc070c03                       // 000000DD47F0: D64400E9 03FE7112 0C070C03
	v_and_b32_e32 v18, 0xf0f0f0f, v59                          // 000000DD47FC: 362476FF 0F0F0F0F
	v_perm_b32 v234, v18, v58, 0xc040c00                       // 000000DD4804: D64400EA 03FE7512 0C040C00
	v_perm_b32 v59, v18, v58, 0xc050c01                        // 000000DD4810: D644003B 03FE7512 0C050C01
	v_perm_b32 v235, v18, v58, 0xc060c02                       // 000000DD481C: D64400EB 03FE7512 0C060C02
	v_perm_b32 v54, v18, v58, 0xc070c03                        // 000000DD4828: D6440036 03FE7512 0C070C03
	v_and_b32_e32 v18, 0xf0f0f0f, v61                          // 000000DD4834: 36247AFF 0F0F0F0F
	v_and_b32_e32 v61, 0xf0f0f0f, v93                          // 000000DD483C: 367ABAFF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_2)                            // 000000DD4844: BF870002
	v_perm_b32 v58, v18, v60, 0xc040c00                        // 000000DD4848: D644003A 03FE7912 0C040C00
	v_perm_b32 v50, v18, v60, 0xc050c01                        // 000000DD4854: D6440032 03FE7912 0C050C01
	v_perm_b32 v55, v18, v60, 0xc060c02                        // 000000DD4860: D6440037 03FE7912 0C060C02
	v_perm_b32 v35, v18, v60, 0xc070c03                        // 000000DD486C: D6440023 03FE7912 0C070C03
	v_and_b32_e32 v18, 0xf0f0f0f, v63                          // 000000DD4878: 36247EFF 0F0F0F0F
	v_perm_b32 v155, v61, v92, 0xc040c00                       // 000000DD4880: D644009B 03FEB93D 0C040C00
	v_perm_b32 v154, v61, v92, 0xc050c01                       // 000000DD488C: D644009A 03FEB93D 0C050C01
	v_perm_b32 v247, v61, v92, 0xc060c02                       // 000000DD4898: D64400F7 03FEB93D 0C060C02
	v_perm_b32 v246, v61, v92, 0xc070c03                       // 000000DD48A4: D64400F6 03FEB93D 0C070C03
	v_perm_b32 v51, v18, v62, 0xc040c00                        // 000000DD48B0: D6440033 03FE7D12 0C040C00
	v_perm_b32 v33, v18, v62, 0xc050c01                        // 000000DD48BC: D6440021 03FE7D12 0C050C01
	v_perm_b32 v47, v18, v62, 0xc060c02                        // 000000DD48C8: D644002F 03FE7D12 0C060C02
	v_perm_b32 v30, v18, v62, 0xc070c03                        // 000000DD48D4: D644001E 03FE7D12 0C070C03
	v_and_b32_e32 v18, 0xf0f0f0f, v65                          // 000000DD48E0: 362482FF 0F0F0F0F
	v_and_b32_e32 v61, 0xf0f0f0f, v95                          // 000000DD48E8: 367ABEFF 0F0F0F0F
	v_perm_b32 v62, v27, v69, 0xc050c01                        // 000000DD48F0: D644003E 03FE8B1B 0C050C01
	v_perm_b32 v63, v27, v69, 0xc060c02                        // 000000DD48FC: D644003F 03FE8B1B 0C060C02
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DD4908: BF870004
	v_perm_b32 v34, v18, v64, 0xc040c00                        // 000000DD490C: D6440022 03FE8112 0C040C00
	v_perm_b32 v23, v18, v64, 0xc050c01                        // 000000DD4918: D6440017 03FE8112 0C050C01
	v_perm_b32 v31, v18, v64, 0xc060c02                        // 000000DD4924: D644001F 03FE8112 0C060C02
	v_perm_b32 v24, v18, v64, 0xc070c03                        // 000000DD4930: D6440018 03FE8112 0C070C03
	v_and_b32_e32 v18, 0xf0f0f0f, v67                          // 000000DD493C: 362486FF 0F0F0F0F
	v_perm_b32 v245, v61, v94, 0xc040c00                       // 000000DD4944: D64400F5 03FEBD3D 0C040C00
	v_perm_b32 v242, v61, v94, 0xc050c01                       // 000000DD4950: D64400F2 03FEBD3D 0C050C01
	v_perm_b32 v241, v61, v94, 0xc060c02                       // 000000DD495C: D64400F1 03FEBD3D 0C060C02
	v_or_b32_e32 v24, 0x64006400, v24                          // 000000DD4968: 383030FF 64006400
	v_perm_b32 v237, v18, v66, 0xc040c00                       // 000000DD4970: D64400ED 03FE8512 0C040C00
	v_perm_b32 v238, v18, v66, 0xc050c01                       // 000000DD497C: D64400EE 03FE8512 0C050C01
	v_perm_b32 v243, v18, v66, 0xc060c02                       // 000000DD4988: D64400F3 03FE8512 0C060C02
	v_perm_b32 v248, v18, v66, 0xc070c03                       // 000000DD4994: D64400F8 03FE8512 0C070C03
	v_and_b32_e32 v18, 0xf0f0f0f, v71                          // 000000DD49A0: 36248EFF 0F0F0F0F
	v_and_b32_e32 v71, 0xf0f0f0f, v109                         // 000000DD49A8: 368EDAFF 0F0F0F0F
	v_or_b32_e32 v23, 0x64006400, v23                          // 000000DD49B0: 382E2EFF 64006400
	.long 0xcc0f4018                                           // 000000DD49B8: CC0F4018
	v_mul_i32_i24_e32 v1, 0xe408, v24                          // 000000DD49BC: 120230FF 0000E408
	scratch_load_b32 v66, off, off offset:336                  // 000000DD49C4: DC510150 427C0000
	v_perm_b32 v252, v18, v68, 0xc040c00                       // 000000DD49CC: D64400FC 03FE8912 0C040C00
	v_perm_b32 v253, v18, v68, 0xc050c01                       // 000000DD49D8: D64400FD 03FE8912 0C050C01
	v_perm_b32 v1, v18, v68, 0xc060c02                         // 000000DD49E4: D6440001 03FE8912 0C060C02
	v_perm_b32 v2, v18, v68, 0xc070c03                         // 000000DD49F0: D6440002 03FE8912 0C070C03
	v_and_b32_e32 v18, 0xf0f0f0f, v73                          // 000000DD49FC: 362492FF 0F0F0F0F
	.long 0xcc0f4017                                           // 000000DD4A04: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v23                          // 000000DD4A08: 12022EFF 0000E408
	scratch_store_b32 off, v24, off offset:64                  // 000000DD4A10: DC690040 007C1800
	v_or_b32_e32 v24, 0x64006400, v30                          // 000000DD4A18: 38303CFF 64006400
	v_or_b32_e32 v1, 0x64006400, v1                            // 000000DD4A20: 380202FF 64006400
	v_perm_b32 v19, v18, v72, 0xc040c00                        // 000000DD4A28: D6440013 03FE9112 0C040C00
	v_perm_b32 v20, v18, v72, 0xc050c01                        // 000000DD4A34: D6440014 03FE9112 0C050C01
	v_perm_b32 v3, v18, v72, 0xc060c02                         // 000000DD4A40: D6440003 03FE9112 0C060C02
	v_perm_b32 v4, v18, v72, 0xc070c03                         // 000000DD4A4C: D6440004 03FE9112 0C070C03
	v_and_b32_e32 v18, 0xf0f0f0f, v75                          // 000000DD4A58: 362496FF 0F0F0F0F
	scratch_store_b32 off, v23, off offset:68                  // 000000DD4A60: DC690044 007C1700
	v_and_b32_e32 v30, 0xf0f0f0f, v117                         // 000000DD4A68: 363CEAFF 0F0F0F0F
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DD4A70: 380404FF 64006400
	.long 0xcc0f4001                                           // 000000DD4A78: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DD4A7C: 120202FF 0000E408
	v_perm_b32 v21, v18, v74, 0xc040c00                        // 000000DD4A84: D6440015 03FE9512 0C040C00
	v_perm_b32 v22, v18, v74, 0xc050c01                        // 000000DD4A90: D6440016 03FE9512 0C050C01
	v_perm_b32 v28, v18, v74, 0xc060c02                        // 000000DD4A9C: D644001C 03FE9512 0C060C02
	v_perm_b32 v5, v18, v74, 0xc070c03                         // 000000DD4AA8: D6440005 03FE9512 0C070C03
	v_and_b32_e32 v18, 0xf0f0f0f, v77                          // 000000DD4AB4: 36249AFF 0F0F0F0F
	scratch_store_b32 off, v1, off offset:428                  // 000000DD4ABC: DC6901AC 007C0100
	.long 0xcc0f4001                                           // 000000DD4AC4: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DD4AC8: 120204FF 0000E408
	v_and_b32_e32 v75, 0xf0f0f0f, v129                         // 000000DD4AD0: 369702FF 0F0F0F0F
	v_perm_b32 v77, v39, v86, 0xc060c02                        // 000000DD4AD8: D644004D 03FEAD27 0C060C02
	v_perm_b32 v29, v18, v76, 0xc040c00                        // 000000DD4AE4: D644001D 03FE9912 0C040C00
	v_perm_b32 v32, v18, v76, 0xc050c01                        // 000000DD4AF0: D6440020 03FE9912 0C050C01
	v_perm_b32 v44, v18, v76, 0xc060c02                        // 000000DD4AFC: D644002C 03FE9912 0C060C02
	v_perm_b32 v45, v18, v76, 0xc070c03                        // 000000DD4B08: D644002D 03FE9912 0C070C03
	v_and_b32_e32 v18, 0xf0f0f0f, v79                          // 000000DD4B14: 36249EFF 0F0F0F0F
	v_or_b32_e32 v76, 0x64006400, v233                         // 000000DD4B1C: 3899D2FF 64006400
	v_and_b32_e32 v79, 0xf0f0f0f, v131                         // 000000DD4B24: 369F06FF 0F0F0F0F
	scratch_store_b32 off, v1, off offset:432                  // 000000DD4B2C: DC6901B0 007C0100
	v_or_b32_e32 v2, 0x64006400, v4                            // 000000DD4B34: 380408FF 64006400
	v_perm_b32 v6, v18, v78, 0xc040c00                         // 000000DD4B3C: D6440006 03FE9D12 0C040C00
	v_perm_b32 v7, v18, v78, 0xc050c01                         // 000000DD4B48: D6440007 03FE9D12 0C050C01
	v_perm_b32 v8, v18, v78, 0xc060c02                         // 000000DD4B54: D6440008 03FE9D12 0C060C02
	v_perm_b32 v11, v18, v78, 0xc070c03                        // 000000DD4B60: D644000B 03FE9D12 0C070C03
	v_and_b32_e32 v18, 0xf0f0f0f, v81                          // 000000DD4B6C: 3624A2FF 0F0F0F0F
	v_perm_b32 v233, v79, v130, 0xc040c00                      // 000000DD4B74: D64400E9 03FF054F 0C040C00
	v_perm_b32 v81, v39, v86, 0xc050c01                        // 000000DD4B80: D6440051 03FEAD27 0C050C01
	v_perm_b32 v78, v39, v86, 0xc070c03                        // 000000DD4B8C: D644004E 03FEAD27 0C070C03
	v_or_b32_e32 v86, 0x64006400, v227                         // 000000DD4B98: 38ADC6FF 64006400
	v_perm_b32 v46, v18, v80, 0xc040c00                        // 000000DD4BA0: D644002E 03FEA112 0C040C00
	v_perm_b32 v12, v18, v80, 0xc050c01                        // 000000DD4BAC: D644000C 03FEA112 0C050C01
	v_perm_b32 v14, v18, v80, 0xc060c02                        // 000000DD4BB8: D644000E 03FEA112 0C060C02
	v_perm_b32 v17, v18, v80, 0xc070c03                        // 000000DD4BC4: D6440011 03FEA112 0C070C03
	v_and_b32_e32 v18, 0xf0f0f0f, v83                          // 000000DD4BD0: 3624A6FF 0F0F0F0F
	v_or_b32_e32 v80, 0x64006400, v231                         // 000000DD4BD8: 38A1CEFF 64006400
	v_or_b32_e32 v83, 0x64006400, v229                         // 000000DD4BE0: 38A7CAFF 64006400
	v_and_b32_e32 v39, 0xf0f0f0f, v89                          // 000000DD4BE8: 364EB2FF 0F0F0F0F
	v_or_b32_e32 v89, 0x64006400, v225                         // 000000DD4BF0: 38B3C2FF 64006400
	v_perm_b32 v48, v18, v82, 0xc040c00                        // 000000DD4BF8: D6440030 03FEA512 0C040C00
	v_perm_b32 v49, v18, v82, 0xc050c01                        // 000000DD4C04: D6440031 03FEA512 0C050C01
	v_perm_b32 v37, v18, v82, 0xc060c02                        // 000000DD4C10: D6440025 03FEA512 0C060C02
	v_perm_b32 v40, v18, v82, 0xc070c03                        // 000000DD4C1C: D6440028 03FEA512 0C070C03
	v_perm_b32 v18, v38, v84, 0xc060c02                        // 000000DD4C28: D6440012 03FEA926 0C060C02
	v_perm_b32 v38, v61, v94, 0xc070c03                        // 000000DD4C34: D6440026 03FEBD3D 0C070C03
	v_and_b32_e32 v61, 0xf0f0f0f, v97                          // 000000DD4C40: 367AC2FF 0F0F0F0F
	v_and_b32_e32 v82, 0xf0f0f0f, v133                         // 000000DD4C48: 36A50AFF 0F0F0F0F
	v_and_b32_e32 v84, 0xf0f0f0f, v135                         // 000000DD4C50: 36A90EFF 0F0F0F0F
	v_perm_b32 v98, v39, v88, 0xc040c00                        // 000000DD4C58: D6440062 03FEB127 0C040C00
	scratch_store_b32 off, v38, off offset:748                 // 000000DD4C64: DC6902EC 007C2600
	v_perm_b32 v38, v61, v100, 0xc040c00                       // 000000DD4C6C: D6440026 03FEC93D 0C040C00
	v_perm_b32 v231, v82, v132, 0xc050c01                      // 000000DD4C78: D64400E7 03FF0952 0C050C01
	v_perm_b32 v99, v39, v88, 0xc050c01                        // 000000DD4C84: D6440063 03FEB127 0C050C01
	v_perm_b32 v105, v39, v88, 0xc060c02                       // 000000DD4C90: D6440069 03FEB127 0C060C02
	v_perm_b32 v103, v39, v88, 0xc070c03                       // 000000DD4C9C: D6440067 03FEB127 0C070C03
	scratch_store_b32 off, v38, off offset:752                 // 000000DD4CA8: DC6902F0 007C2600
	v_perm_b32 v38, v61, v100, 0xc050c01                       // 000000DD4CB0: D6440026 03FEC93D 0C050C01
	v_or_b32_e32 v88, 0x64006400, v224                         // 000000DD4CBC: 38B1C0FF 64006400
	v_perm_b32 v39, v43, v90, 0xc040c00                        // 000000DD4CC4: D6440027 03FEB52B 0C040C00
	v_and_b32_e32 v90, 0xf0f0f0f, v139                         // 000000DD4CD0: 36B516FF 0F0F0F0F
	v_or_b32_e32 v4, 0x64006400, v22                           // 000000DD4CD8: 38082CFF 64006400
	scratch_store_b32 off, v38, off offset:756                 // 000000DD4CE0: DC6902F4 007C2600
	v_perm_b32 v38, v61, v100, 0xc060c02                       // 000000DD4CE8: D6440026 03FEC93D 0C060C02
	v_perm_b32 v229, v90, v138, 0xc050c01                      // 000000DD4CF4: D64400E5 03FF155A 0C050C01
	scratch_store_b32 off, v38, off offset:760                 // 000000DD4D00: DC6902F8 007C2600
	v_perm_b32 v38, v61, v100, 0xc070c03                       // 000000DD4D08: D6440026 03FEC93D 0C070C03
	v_and_b32_e32 v61, 0xf0f0f0f, v102                         // 000000DD4D14: 367ACCFF 0F0F0F0F
	scratch_store_b32 off, v38, off offset:764                 // 000000DD4D1C: DC6902FC 007C2600
	v_perm_b32 v38, v61, v101, 0xc040c00                       // 000000DD4D24: D6440026 03FECB3D 0C040C00
	scratch_store_b32 off, v38, off offset:728                 // 000000DD4D30: DC6902D8 007C2600
	v_perm_b32 v38, v61, v101, 0xc050c01                       // 000000DD4D38: D6440026 03FECB3D 0C050C01
	scratch_store_b32 off, v38, off offset:732                 // 000000DD4D44: DC6902DC 007C2600
	v_perm_b32 v38, v61, v101, 0xc060c02                       // 000000DD4D4C: D6440026 03FECB3D 0C060C02
	scratch_store_b32 off, v38, off offset:736                 // 000000DD4D58: DC6902E0 007C2600
	v_perm_b32 v38, v61, v101, 0xc070c03                       // 000000DD4D60: D6440026 03FECB3D 0C070C03
	v_and_b32_e32 v61, 0xf0f0f0f, v107                         // 000000DD4D6C: 367AD6FF 0F0F0F0F
	scratch_store_b32 off, v38, off offset:740                 // 000000DD4D74: DC6902E4 007C2600
	v_perm_b32 v38, v61, v106, 0xc040c00                       // 000000DD4D7C: D6440026 03FED53D 0C040C00
	scratch_store_b32 off, v38, off offset:744                 // 000000DD4D88: DC6902E8 007C2600
	v_perm_b32 v38, v61, v106, 0xc050c01                       // 000000DD4D90: D6440026 03FED53D 0C050C01
	scratch_store_b32 off, v38, off offset:644                 // 000000DD4D9C: DC690284 007C2600
	v_perm_b32 v38, v61, v106, 0xc060c02                       // 000000DD4DA4: D6440026 03FED53D 0C060C02
	scratch_store_b32 off, v38, off offset:648                 // 000000DD4DB0: DC690288 007C2600
	v_perm_b32 v38, v61, v106, 0xc070c03                       // 000000DD4DB8: D6440026 03FED53D 0C070C03
	scratch_store_b32 off, v38, off offset:652                 // 000000DD4DC4: DC69028C 007C2600
	v_perm_b32 v38, v71, v108, 0xc040c00                       // 000000DD4DCC: D6440026 03FED947 0C040C00
	scratch_store_b32 off, v38, off offset:656                 // 000000DD4DD8: DC690290 007C2600
	v_perm_b32 v38, v71, v108, 0xc050c01                       // 000000DD4DE0: D6440026 03FED947 0C050C01
	scratch_store_b32 off, v38, off offset:660                 // 000000DD4DEC: DC690294 007C2600
	v_perm_b32 v38, v71, v108, 0xc060c02                       // 000000DD4DF4: D6440026 03FED947 0C060C02
	scratch_store_b32 off, v38, off offset:544                 // 000000DD4E00: DC690220 007C2600
	v_perm_b32 v38, v71, v108, 0xc070c03                       // 000000DD4E08: D6440026 03FED947 0C070C03
	v_and_b32_e32 v71, 0xf0f0f0f, v111                         // 000000DD4E14: 368EDEFF 0F0F0F0F
	scratch_store_b32 off, v38, off offset:548                 // 000000DD4E1C: DC690224 007C2600
	v_perm_b32 v38, v71, v110, 0xc040c00                       // 000000DD4E24: D6440026 03FEDD47 0C040C00
	scratch_store_b32 off, v38, off offset:552                 // 000000DD4E30: DC690228 007C2600
	v_perm_b32 v38, v71, v110, 0xc050c01                       // 000000DD4E38: D6440026 03FEDD47 0C050C01
	scratch_store_b32 off, v38, off offset:556                 // 000000DD4E44: DC69022C 007C2600
	v_perm_b32 v38, v71, v110, 0xc060c02                       // 000000DD4E4C: D6440026 03FEDD47 0C060C02
	scratch_store_b32 off, v38, off offset:560                 // 000000DD4E58: DC690230 007C2600
	v_perm_b32 v38, v71, v110, 0xc070c03                       // 000000DD4E60: D6440026 03FEDD47 0C070C03
	v_and_b32_e32 v71, 0xf0f0f0f, v113                         // 000000DD4E6C: 368EE2FF 0F0F0F0F
	scratch_store_b32 off, v38, off offset:484                 // 000000DD4E74: DC6901E4 007C2600
	v_perm_b32 v38, v71, v112, 0xc040c00                       // 000000DD4E7C: D6440026 03FEE147 0C040C00
	scratch_store_b32 off, v38, off offset:488                 // 000000DD4E88: DC6901E8 007C2600
	v_perm_b32 v38, v71, v112, 0xc050c01                       // 000000DD4E90: D6440026 03FEE147 0C050C01
	scratch_store_b32 off, v38, off offset:492                 // 000000DD4E9C: DC6901EC 007C2600
	v_perm_b32 v38, v71, v112, 0xc060c02                       // 000000DD4EA4: D6440026 03FEE147 0C060C02
	scratch_store_b32 off, v38, off offset:496                 // 000000DD4EB0: DC6901F0 007C2600
	v_perm_b32 v38, v71, v112, 0xc070c03                       // 000000DD4EB8: D6440026 03FEE147 0C070C03
	v_and_b32_e32 v71, 0xf0f0f0f, v115                         // 000000DD4EC4: 368EE6FF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DD4ECC: BF870001
	v_perm_b32 v23, v71, v114, 0xc040c00                       // 000000DD4ED0: D6440017 03FEE547 0C040C00
	scratch_store_b32 off, v23, off offset:504                 // 000000DD4EDC: DC6901F8 007C1700
	v_perm_b32 v23, v71, v114, 0xc050c01                       // 000000DD4EE4: D6440017 03FEE547 0C050C01
	scratch_store_b32 off, v23, off offset:508                 // 000000DD4EF0: DC6901FC 007C1700
	v_perm_b32 v23, v71, v114, 0xc060c02                       // 000000DD4EF8: D6440017 03FEE547 0C060C02
	scratch_store_b32 off, v23, off offset:512                 // 000000DD4F04: DC690200 007C1700
	v_perm_b32 v23, v71, v114, 0xc070c03                       // 000000DD4F0C: D6440017 03FEE547 0C070C03
	scratch_store_b32 off, v23, off offset:516                 // 000000DD4F18: DC690204 007C1700
	v_or_b32_e32 v23, 0x64006400, v31                          // 000000DD4F20: 382E3EFF 64006400
	v_and_b32_e32 v31, 0xf0f0f0f, v127                         // 000000DD4F28: 363EFEFF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_2)                            // 000000DD4F30: BF870002
	.long 0xcc0f4017                                           // 000000DD4F34: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v23                          // 000000DD4F38: 12022EFF 0000E408
	scratch_store_b32 off, v23, off offset:72                  // 000000DD4F40: DC690048 007C1700
	.long 0xcc0f4017                                           // 000000DD4F48: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v24                          // 000000DD4F4C: 120230FF 0000E408
	v_or_b32_e32 v24, 0x64006400, v33                          // 000000DD4F54: 383042FF 64006400
	scratch_store_b32 off, v23, off offset:76                  // 000000DD4F5C: DC69004C 007C1700
	v_perm_b32 v23, v30, v116, 0xc040c00                       // 000000DD4F64: D6440017 03FEE91E 0C040C00
	scratch_store_b32 off, v23, off offset:564                 // 000000DD4F70: DC690234 007C1700
	v_perm_b32 v23, v30, v116, 0xc050c01                       // 000000DD4F78: D6440017 03FEE91E 0C050C01
	scratch_store_b32 off, v23, off offset:520                 // 000000DD4F84: DC690208 007C1700
	v_perm_b32 v23, v30, v116, 0xc060c02                       // 000000DD4F8C: D6440017 03FEE91E 0C060C02
	scratch_store_b32 off, v23, off offset:524                 // 000000DD4F98: DC69020C 007C1700
	v_perm_b32 v23, v30, v116, 0xc070c03                       // 000000DD4FA0: D6440017 03FEE91E 0C070C03
	v_and_b32_e32 v30, 0xf0f0f0f, v119                         // 000000DD4FAC: 363CEEFF 0F0F0F0F
	scratch_store_b32 off, v23, off offset:528                 // 000000DD4FB4: DC690210 007C1700
	v_or_b32_e32 v23, 0x64006400, v34                          // 000000DD4FBC: 382E44FF 64006400
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DD4FC4: BF870001
	.long 0xcc0f4017                                           // 000000DD4FC8: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v23                          // 000000DD4FCC: 12022EFF 0000E408
	s_clause 0x1                                               // 000000DD4FD4: BF850001
	scratch_store_b32 off, v38, off offset:500                 // 000000DD4FD8: DC6901F4 007C2600
	scratch_store_b32 off, v23, off offset:80                  // 000000DD4FE0: DC690050 007C1700
	.long 0xcc0f4017                                           // 000000DD4FE8: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v24                          // 000000DD4FEC: 120230FF 0000E408
	v_or_b32_e32 v24, 0x64006400, v35                          // 000000DD4FF4: 383046FF 64006400
	scratch_store_b32 off, v23, off offset:84                  // 000000DD4FFC: DC690054 007C1700
	v_perm_b32 v23, v30, v118, 0xc040c00                       // 000000DD5004: D6440017 03FEED1E 0C040C00
	scratch_store_b32 off, v23, off offset:568                 // 000000DD5010: DC690238 007C1700
	v_perm_b32 v23, v30, v118, 0xc050c01                       // 000000DD5018: D6440017 03FEED1E 0C050C01
	scratch_store_b32 off, v23, off offset:572                 // 000000DD5024: DC69023C 007C1700
	v_perm_b32 v23, v30, v118, 0xc060c02                       // 000000DD502C: D6440017 03FEED1E 0C060C02
	scratch_store_b32 off, v23, off offset:532                 // 000000DD5038: DC690214 007C1700
	v_perm_b32 v23, v30, v118, 0xc070c03                       // 000000DD5040: D6440017 03FEED1E 0C070C03
	v_and_b32_e32 v30, 0xf0f0f0f, v121                         // 000000DD504C: 363CF2FF 0F0F0F0F
	v_or_b32_e32 v121, 0x64006400, v223                        // 000000DD5054: 38F3BEFF 64006400
	scratch_store_b32 off, v23, off offset:536                 // 000000DD505C: DC690218 007C1700
	v_or_b32_e32 v23, 0x64006400, v47                          // 000000DD5064: 382E5EFF 64006400
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DD506C: BF870001
	.long 0xcc0f4017                                           // 000000DD5070: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v23                          // 000000DD5074: 12022EFF 0000E408
	scratch_store_b32 off, v23, off offset:88                  // 000000DD507C: DC690058 007C1700
	.long 0xcc0f4017                                           // 000000DD5084: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v24                          // 000000DD5088: 120230FF 0000E408
	v_or_b32_e32 v24, 0x64006400, v50                          // 000000DD5090: 383064FF 64006400
	scratch_store_b32 off, v23, off offset:92                  // 000000DD5098: DC69005C 007C1700
	v_perm_b32 v23, v30, v120, 0xc040c00                       // 000000DD50A0: D6440017 03FEF11E 0C040C00
	scratch_store_b32 off, v23, off offset:576                 // 000000DD50AC: DC690240 007C1700
	v_perm_b32 v23, v30, v120, 0xc050c01                       // 000000DD50B4: D6440017 03FEF11E 0C050C01
	scratch_store_b32 off, v23, off offset:580                 // 000000DD50C0: DC690244 007C1700
	v_perm_b32 v23, v30, v120, 0xc060c02                       // 000000DD50C8: D6440017 03FEF11E 0C060C02
	scratch_store_b32 off, v23, off offset:584                 // 000000DD50D4: DC690248 007C1700
	v_perm_b32 v23, v30, v120, 0xc070c03                       // 000000DD50DC: D6440017 03FEF11E 0C070C03
	v_and_b32_e32 v30, 0xf0f0f0f, v123                         // 000000DD50E8: 363CF6FF 0F0F0F0F
	v_and_b32_e32 v123, 0xf0f0f0f, v143                        // 000000DD50F0: 36F71EFF 0F0F0F0F
	scratch_store_b32 off, v23, off offset:540                 // 000000DD50F8: DC69021C 007C1700
	v_or_b32_e32 v23, 0x64006400, v51                          // 000000DD5100: 382E66FF 64006400
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DD5108: BF870001
	.long 0xcc0f4017                                           // 000000DD510C: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v23                          // 000000DD5110: 12022EFF 0000E408
	scratch_store_b32 off, v23, off offset:96                  // 000000DD5118: DC690060 007C1700
	.long 0xcc0f4017                                           // 000000DD5120: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v24                          // 000000DD5124: 120230FF 0000E408
	v_or_b32_e32 v24, 0x64006400, v54                          // 000000DD512C: 38306CFF 64006400
	scratch_store_b32 off, v23, off offset:100                 // 000000DD5134: DC690064 007C1700
	v_perm_b32 v23, v30, v122, 0xc040c00                       // 000000DD513C: D6440017 03FEF51E 0C040C00
	scratch_store_b32 off, v23, off offset:588                 // 000000DD5148: DC69024C 007C1700
	v_perm_b32 v23, v30, v122, 0xc050c01                       // 000000DD5150: D6440017 03FEF51E 0C050C01
	scratch_store_b32 off, v23, off offset:592                 // 000000DD515C: DC690250 007C1700
	v_perm_b32 v23, v30, v122, 0xc060c02                       // 000000DD5164: D6440017 03FEF51E 0C060C02
	scratch_store_b32 off, v23, off offset:596                 // 000000DD5170: DC690254 007C1700
	v_perm_b32 v23, v30, v122, 0xc070c03                       // 000000DD5178: D6440017 03FEF51E 0C070C03
	v_and_b32_e32 v30, 0xf0f0f0f, v125                         // 000000DD5184: 363CFAFF 0F0F0F0F
	v_and_b32_e32 v122, 0xf0f0f0f, v141                        // 000000DD518C: 36F51AFF 0F0F0F0F
	scratch_store_b32 off, v23, off offset:600                 // 000000DD5194: DC690258 007C1700
	v_or_b32_e32 v23, 0x64006400, v55                          // 000000DD519C: 382E6EFF 64006400
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DD51A4: BF870001
	.long 0xcc0f4017                                           // 000000DD51A8: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v23                          // 000000DD51AC: 12022EFF 0000E408
	scratch_store_b32 off, v23, off offset:104                 // 000000DD51B4: DC690068 007C1700
	.long 0xcc0f4017                                           // 000000DD51BC: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v24                          // 000000DD51C0: 120230FF 0000E408
	v_or_b32_e32 v24, 0x64006400, v58                          // 000000DD51C8: 383074FF 64006400
	scratch_store_b32 off, v23, off offset:108                 // 000000DD51D0: DC69006C 007C1700
	v_perm_b32 v23, v30, v124, 0xc040c00                       // 000000DD51D8: D6440017 03FEF91E 0C040C00
	scratch_store_b32 off, v23, off offset:604                 // 000000DD51E4: DC69025C 007C1700
	v_perm_b32 v23, v30, v124, 0xc050c01                       // 000000DD51EC: D6440017 03FEF91E 0C050C01
	scratch_store_b32 off, v23, off offset:608                 // 000000DD51F8: DC690260 007C1700
	v_perm_b32 v23, v30, v124, 0xc060c02                       // 000000DD5200: D6440017 03FEF91E 0C060C02
	scratch_store_b32 off, v23, off offset:612                 // 000000DD520C: DC690264 007C1700
	v_perm_b32 v23, v30, v124, 0xc070c03                       // 000000DD5214: D6440017 03FEF91E 0C070C03
	v_or_b32_e32 v30, 0x64006400, v59                          // 000000DD5220: 383C76FF 64006400
	scratch_store_b32 off, v23, off offset:616                 // 000000DD5228: DC690268 007C1700
	.long 0xcc0f4017                                           // 000000DD5230: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v24                          // 000000DD5234: 120230FF 0000E408
	scratch_store_b32 off, v23, off offset:112                 // 000000DD523C: DC690070 007C1700
	.long 0xcc0f4017                                           // 000000DD5244: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v30                          // 000000DD5248: 12023CFF 0000E408
	v_or_b32_e32 v30, 0x64006400, v235                         // 000000DD5250: 383DD6FF 64006400
	v_perm_b32 v235, v122, v140, 0xc050c01                     // 000000DD5258: D64400EB 03FF197A 0C050C01
	scratch_store_b32 off, v23, off offset:116                 // 000000DD5264: DC690074 007C1700
	v_perm_b32 v23, v31, v126, 0xc040c00                       // 000000DD526C: D6440017 03FEFD1F 0C040C00
	scratch_store_b32 off, v23, off offset:664                 // 000000DD5278: DC690298 007C1700
	v_perm_b32 v23, v31, v126, 0xc050c01                       // 000000DD5280: D6440017 03FEFD1F 0C050C01
	scratch_store_b32 off, v23, off offset:620                 // 000000DD528C: DC69026C 007C1700
	v_perm_b32 v23, v31, v126, 0xc060c02                       // 000000DD5294: D6440017 03FEFD1F 0C060C02
	scratch_store_b32 off, v23, off offset:624                 // 000000DD52A0: DC690270 007C1700
	v_perm_b32 v23, v31, v126, 0xc070c03                       // 000000DD52A8: D6440017 03FEFD1F 0C070C03
	v_or_b32_e32 v31, 0x64006400, v234                         // 000000DD52B4: 383FD4FF 64006400
	v_perm_b32 v234, v122, v140, 0xc040c00                     // 000000DD52BC: D64400EA 03FF197A 0C040C00
	scratch_store_b32 off, v23, off offset:628                 // 000000DD52C8: DC690274 007C1700
	.long 0xcc0f4017                                           // 000000DD52D0: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v30                          // 000000DD52D4: 12023CFF 0000E408
	v_or_b32_e32 v30, 0x64006400, v214                         // 000000DD52DC: 383DACFF 64006400
	scratch_store_b32 off, v23, off offset:120                 // 000000DD52E4: DC690078 007C1700
	.long 0xcc0f4017                                           // 000000DD52EC: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v31                          // 000000DD52F0: 12023EFF 0000E408
	scratch_store_b32 off, v23, off offset:124                 // 000000DD52F8: DC69007C 007C1700
	v_perm_b32 v23, v75, v128, 0xc040c00                       // 000000DD5300: D6440017 03FF014B 0C040C00
	scratch_store_b32 off, v23, off offset:668                 // 000000DD530C: DC69029C 007C1700
	v_perm_b32 v23, v75, v128, 0xc050c01                       // 000000DD5314: D6440017 03FF014B 0C050C01
	scratch_store_b32 off, v23, off offset:672                 // 000000DD5320: DC6902A0 007C1700
	v_perm_b32 v23, v75, v128, 0xc060c02                       // 000000DD5328: D6440017 03FF014B 0C060C02
	scratch_store_b32 off, v23, off offset:632                 // 000000DD5334: DC690278 007C1700
	v_perm_b32 v23, v75, v128, 0xc070c03                       // 000000DD533C: D6440017 03FF014B 0C070C03
	v_or_b32_e32 v75, 0x64006400, v232                         // 000000DD5348: 3897D0FF 64006400
	v_perm_b32 v232, v79, v130, 0xc050c01                      // 000000DD5350: D64400E8 03FF054F 0C050C01
	scratch_store_b32 off, v23, off offset:636                 // 000000DD535C: DC69027C 007C1700
	.long 0xcc0f4017                                           // 000000DD5364: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v75                          // 000000DD5368: 120296FF 0000E408
	scratch_store_b32 off, v23, off offset:128                 // 000000DD5370: DC690080 007C1700
	.long 0xcc0f4017                                           // 000000DD5378: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v76                          // 000000DD537C: 120298FF 0000E408
	scratch_store_b32 off, v23, off offset:132                 // 000000DD5384: DC690084 007C1700
	v_perm_b32 v23, v79, v130, 0xc060c02                       // 000000DD538C: D6440017 03FF054F 0C060C02
	scratch_store_b32 off, v23, off offset:676                 // 000000DD5398: DC6902A4 007C1700
	v_perm_b32 v23, v79, v130, 0xc070c03                       // 000000DD53A0: D6440017 03FF054F 0C070C03
	v_or_b32_e32 v79, 0x64006400, v230                         // 000000DD53AC: 389FCCFF 64006400
	v_perm_b32 v230, v90, v138, 0xc040c00                      // 000000DD53B4: D64400E6 03FF155A 0C040C00
	scratch_store_b32 off, v23, off offset:640                 // 000000DD53C0: DC690280 007C1700
	.long 0xcc0f4017                                           // 000000DD53C8: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v79                          // 000000DD53CC: 12029EFF 0000E408
	scratch_store_b32 off, v23, off offset:136                 // 000000DD53D4: DC690088 007C1700
	.long 0xcc0f4017                                           // 000000DD53DC: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v80                          // 000000DD53E0: 1202A0FF 0000E408
	scratch_store_b32 off, v23, off offset:140                 // 000000DD53E8: DC69008C 007C1700
	v_perm_b32 v23, v82, v132, 0xc040c00                       // 000000DD53F0: D6440017 03FF0952 0C040C00
	scratch_store_b32 off, v23, off offset:680                 // 000000DD53FC: DC6902A8 007C1700
	v_perm_b32 v23, v82, v132, 0xc060c02                       // 000000DD5404: D6440017 03FF0952 0C060C02
	scratch_store_b32 off, v23, off offset:684                 // 000000DD5410: DC6902AC 007C1700
	v_perm_b32 v23, v82, v132, 0xc070c03                       // 000000DD5418: D6440017 03FF0952 0C070C03
	v_or_b32_e32 v82, 0x64006400, v228                         // 000000DD5424: 38A5C8FF 64006400
	v_perm_b32 v228, v84, v134, 0xc040c00                      // 000000DD542C: D64400E4 03FF0D54 0C040C00
	scratch_store_b32 off, v23, off offset:688                 // 000000DD5438: DC6902B0 007C1700
	.long 0xcc0f4017                                           // 000000DD5440: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v82                          // 000000DD5444: 1202A4FF 0000E408
	v_perm_b32 v82, v27, v69, 0xc070c03                        // 000000DD544C: D6440052 03FE8B1B 0C070C03
	scratch_store_b32 off, v23, off offset:144                 // 000000DD5458: DC690090 007C1700
	.long 0xcc0f4017                                           // 000000DD5460: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v83                          // 000000DD5464: 1202A6FF 0000E408
	scratch_store_b32 off, v23, off offset:148                 // 000000DD546C: DC690094 007C1700
	v_perm_b32 v23, v84, v134, 0xc050c01                       // 000000DD5474: D6440017 03FF0D54 0C050C01
	scratch_store_b32 off, v23, off offset:692                 // 000000DD5480: DC6902B4 007C1700
	v_perm_b32 v23, v84, v134, 0xc060c02                       // 000000DD5488: D6440017 03FF0D54 0C060C02
	scratch_store_b32 off, v23, off offset:696                 // 000000DD5494: DC6902B8 007C1700
	v_perm_b32 v23, v84, v134, 0xc070c03                       // 000000DD549C: D6440017 03FF0D54 0C070C03
	scratch_store_b32 off, v23, off offset:700                 // 000000DD54A8: DC6902BC 007C1700
	.long 0xcc0f4017                                           // 000000DD54B0: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v85                          // 000000DD54B4: 1202AAFF 0000E408
	scratch_store_b32 off, v23, off offset:152                 // 000000DD54BC: DC690098 007C1700
	.long 0xcc0f4017                                           // 000000DD54C4: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v86                          // 000000DD54C8: 1202ACFF 0000E408
	scratch_store_b32 off, v23, off offset:156                 // 000000DD54D0: DC69009C 007C1700
	v_perm_b32 v23, v87, v136, 0xc050c01                       // 000000DD54D8: D6440017 03FF1157 0C050C01
	scratch_store_b32 off, v23, off offset:704                 // 000000DD54E4: DC6902C0 007C1700
	v_perm_b32 v23, v87, v136, 0xc060c02                       // 000000DD54EC: D6440017 03FF1157 0C060C02
	scratch_store_b32 off, v23, off offset:708                 // 000000DD54F8: DC6902C4 007C1700
	v_perm_b32 v23, v87, v136, 0xc070c03                       // 000000DD5500: D6440017 03FF1157 0C070C03
	scratch_store_b32 off, v23, off offset:712                 // 000000DD550C: DC6902C8 007C1700
	.long 0xcc0f4017                                           // 000000DD5514: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v88                          // 000000DD5518: 1202B0FF 0000E408
	scratch_store_b32 off, v23, off offset:160                 // 000000DD5520: DC6900A0 007C1700
	.long 0xcc0f4017                                           // 000000DD5528: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v89                          // 000000DD552C: 1202B2FF 0000E408
	scratch_store_b32 off, v23, off offset:164                 // 000000DD5534: DC6900A4 007C1700
	v_perm_b32 v23, v90, v138, 0xc060c02                       // 000000DD553C: D6440017 03FF155A 0C060C02
	scratch_store_b32 off, v23, off offset:716                 // 000000DD5548: DC6902CC 007C1700
	v_perm_b32 v23, v90, v138, 0xc070c03                       // 000000DD5550: D6440017 03FF155A 0C070C03
	v_or_b32_e32 v90, 0x64006400, v222                         // 000000DD555C: 38B5BCFF 64006400
	scratch_store_b32 off, v23, off offset:720                 // 000000DD5564: DC6902D0 007C1700
	.long 0xcc0f4017                                           // 000000DD556C: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v90                          // 000000DD5570: 1202B4FF 0000E408
	scratch_store_b32 off, v23, off offset:168                 // 000000DD5578: DC6900A8 007C1700
	.long 0xcc0f4017                                           // 000000DD5580: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v121                         // 000000DD5584: 1202F2FF 0000E408
	v_or_b32_e32 v121, 0x64006400, v220                        // 000000DD558C: 38F3B8FF 64006400
	scratch_store_b32 off, v23, off offset:172                 // 000000DD5594: DC6900AC 007C1700
	v_perm_b32 v23, v122, v140, 0xc060c02                      // 000000DD559C: D6440017 03FF197A 0C060C02
	scratch_store_b32 off, v23, off offset:768                 // 000000DD55A8: DC690300 007C1700
	v_perm_b32 v23, v122, v140, 0xc070c03                      // 000000DD55B0: D6440017 03FF197A 0C070C03
	v_or_b32_e32 v122, 0x64006400, v221                        // 000000DD55BC: 38F5BAFF 64006400
	scratch_store_b32 off, v23, off offset:724                 // 000000DD55C4: DC6902D4 007C1700
	.long 0xcc0f4017                                           // 000000DD55CC: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v121                         // 000000DD55D0: 1202F2FF 0000E408
	v_or_b32_e32 v121, 0x64006400, v218                        // 000000DD55D8: 38F3B4FF 64006400
	scratch_store_b32 off, v23, off offset:176                 // 000000DD55E0: DC6900B0 007C1700
	.long 0xcc0f4017                                           // 000000DD55E8: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v122                         // 000000DD55EC: 1202F4FF 0000E408
	v_or_b32_e32 v122, 0x64006400, v219                        // 000000DD55F4: 38F5B6FF 64006400
	scratch_store_b32 off, v23, off offset:180                 // 000000DD55FC: DC6900B4 007C1700
	v_perm_b32 v23, v123, v142, 0xc040c00                      // 000000DD5604: D6440017 03FF1D7B 0C040C00
	scratch_store_b32 off, v23, off offset:772                 // 000000DD5610: DC690304 007C1700
	v_perm_b32 v23, v123, v142, 0xc050c01                      // 000000DD5618: D6440017 03FF1D7B 0C050C01
	scratch_store_b32 off, v23, off offset:776                 // 000000DD5624: DC690308 007C1700
	v_perm_b32 v23, v123, v142, 0xc060c02                      // 000000DD562C: D6440017 03FF1D7B 0C060C02
	scratch_store_b32 off, v23, off offset:780                 // 000000DD5638: DC69030C 007C1700
	v_perm_b32 v23, v123, v142, 0xc070c03                      // 000000DD5640: D6440017 03FF1D7B 0C070C03
	v_and_b32_e32 v123, 0xf0f0f0f, v145                        // 000000DD564C: 36F722FF 0F0F0F0F
	scratch_store_b32 off, v23, off offset:784                 // 000000DD5654: DC690310 007C1700
	.long 0xcc0f4017                                           // 000000DD565C: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v121                         // 000000DD5660: 1202F2FF 0000E408
	v_or_b32_e32 v121, 0x64006400, v217                        // 000000DD5668: 38F3B2FF 64006400
	scratch_store_b32 off, v23, off offset:184                 // 000000DD5670: DC6900B8 007C1700
	.long 0xcc0f4017                                           // 000000DD5678: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v122                         // 000000DD567C: 1202F4FF 0000E408
	v_or_b32_e32 v122, 0x64006400, v215                        // 000000DD5684: 38F5AEFF 64006400
	scratch_store_b32 off, v23, off offset:188                 // 000000DD568C: DC6900BC 007C1700
	v_perm_b32 v23, v123, v144, 0xc040c00                      // 000000DD5694: D6440017 03FF217B 0C040C00
	scratch_store_b32 off, v23, off offset:788                 // 000000DD56A0: DC690314 007C1700
	v_perm_b32 v23, v123, v144, 0xc050c01                      // 000000DD56A8: D6440017 03FF217B 0C050C01
	scratch_store_b32 off, v23, off offset:792                 // 000000DD56B4: DC690318 007C1700
	v_perm_b32 v23, v123, v144, 0xc060c02                      // 000000DD56BC: D6440017 03FF217B 0C060C02
	scratch_store_b32 off, v23, off offset:796                 // 000000DD56C8: DC69031C 007C1700
	v_perm_b32 v23, v123, v144, 0xc070c03                      // 000000DD56D0: D6440017 03FF217B 0C070C03
	v_and_b32_e32 v123, 0xf0f0f0f, v147                        // 000000DD56DC: 36F726FF 0F0F0F0F
	scratch_store_b32 off, v23, off offset:800                 // 000000DD56E4: DC690320 007C1700
	.long 0xcc0f4017                                           // 000000DD56EC: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v121                         // 000000DD56F0: 1202F2FF 0000E408
	v_or_b32_e32 v121, 0x64006400, v216                        // 000000DD56F8: 38F3B0FF 64006400
	v_perm_b32 v244, v123, v146, 0xc040c00                     // 000000DD5700: D64400F4 03FF257B 0C040C00
	v_perm_b32 v250, v123, v146, 0xc060c02                     // 000000DD570C: D64400FA 03FF257B 0C060C02
	v_perm_b32 v251, v123, v146, 0xc070c03                     // 000000DD5718: D64400FB 03FF257B 0C070C03
	scratch_store_b32 off, v23, off offset:192                 // 000000DD5724: DC6900C0 007C1700
	.long 0xcc0f4017                                           // 000000DD572C: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v122                         // 000000DD5730: 1202F4FF 0000E408
	v_and_b32_e32 v122, 0xf0f0f0f, v149                        // 000000DD5738: 36F52AFF 0F0F0F0F
	scratch_store_b32 off, v23, off offset:196                 // 000000DD5740: DC6900C4 007C1700
	v_perm_b32 v23, v123, v146, 0xc050c01                      // 000000DD5748: D6440017 03FF257B 0C050C01
	v_perm_b32 v249, v122, v148, 0xc050c01                     // 000000DD5754: D64400F9 03FF297A 0C050C01
	v_perm_b32 v254, v122, v148, 0xc060c02                     // 000000DD5760: D64400FE 03FF297A 0C060C02
	v_perm_b32 v255, v122, v148, 0xc070c03                     // 000000DD576C: D64400FF 03FF297A 0C070C03
	v_and_b32_e32 v123, 0xf0f0f0f, v153                        // 000000DD5778: 36F732FF 0F0F0F0F
	scratch_store_b32 off, v23, off offset:804                 // 000000DD5780: DC690324 007C1700
	.long 0xcc0f4017                                           // 000000DD5788: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v121                         // 000000DD578C: 1202F2FF 0000E408
	v_or_b32_e32 v121, 0x64006400, v212                        // 000000DD5794: 38F3A8FF 64006400
	v_perm_b32 v118, v123, v152, 0xc050c01                     // 000000DD579C: D6440076 03FF317B 0C050C01
	scratch_store_b32 off, v23, off offset:200                 // 000000DD57A8: DC6900C8 007C1700
	.long 0xcc0f4017                                           // 000000DD57B0: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v30                          // 000000DD57B4: 12023CFF 0000E408
	scratch_store_b32 off, v0, off offset:204                  // 000000DD57BC: DC6900CC 007C0000
	v_perm_b32 v0, v122, v148, 0xc040c00                       // 000000DD57C4: D6440000 03FF297A 0C040C00
	v_and_b32_e32 v122, 0xf0f0f0f, v151                        // 000000DD57D0: 36F52EFF 0F0F0F0F
	scratch_store_b32 off, v23, off offset:208                 // 000000DD57D8: DC6900D0 007C1700
	.long 0xcc0f4017                                           // 000000DD57E0: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v121                         // 000000DD57E4: 1202F2FF 0000E408
	v_or_b32_e32 v121, 0x64006400, v213                        // 000000DD57EC: 38F3AAFF 64006400
	v_perm_b32 v30, v122, v150, 0xc040c00                      // 000000DD57F4: D644001E 03FF2D7A 0C040C00
	v_perm_b32 v31, v122, v150, 0xc050c01                      // 000000DD5800: D644001F 03FF2D7A 0C050C01
	v_perm_b32 v33, v122, v150, 0xc060c02                      // 000000DD580C: D6440021 03FF2D7A 0C060C02
	scratch_store_b32 off, v23, off offset:212                 // 000000DD5818: DC6900D4 007C1700
	v_perm_b32 v23, v122, v150, 0xc070c03                      // 000000DD5820: D6440017 03FF2D7A 0C070C03
	v_or_b32_e32 v122, 0x64006400, v210                        // 000000DD582C: 38F5A4FF 64006400
	v_or_b32_e32 v0, 0x64006400, v0                            // 000000DD5834: 380000FF 64006400
	scratch_store_b32 off, v23, off offset:808                 // 000000DD583C: DC690328 007C1700
	.long 0xcc0f4017                                           // 000000DD5844: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v121                         // 000000DD5848: 1202F2FF 0000E408
	v_or_b32_e32 v121, 0x64006400, v211                        // 000000DD5850: 38F3A6FF 64006400
	scratch_store_b32 off, v23, off offset:216                 // 000000DD5858: DC6900D8 007C1700
	.long 0xcc0f4017                                           // 000000DD5860: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v122                         // 000000DD5864: 1202F4FF 0000E408
	v_or_b32_e32 v122, 0x64006400, v208                        // 000000DD586C: 38F5A0FF 64006400
	scratch_store_b32 off, v23, off offset:220                 // 000000DD5874: DC6900DC 007C1700
	v_perm_b32 v23, v123, v152, 0xc040c00                      // 000000DD587C: D6440017 03FF317B 0C040C00
	scratch_store_b32 off, v23, off offset:812                 // 000000DD5888: DC69032C 007C1700
	v_perm_b32 v23, v123, v152, 0xc060c02                      // 000000DD5890: D6440017 03FF317B 0C060C02
	scratch_store_b32 off, v23, off offset:816                 // 000000DD589C: DC690330 007C1700
	v_perm_b32 v23, v123, v152, 0xc070c03                      // 000000DD58A4: D6440017 03FF317B 0C070C03
	v_and_b32_e32 v123, 0xf0f0f0f, v157                        // 000000DD58B0: 36F73AFF 0F0F0F0F
	scratch_store_b32 off, v23, off offset:820                 // 000000DD58B8: DC690334 007C1700
	.long 0xcc0f4017                                           // 000000DD58C0: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v121                         // 000000DD58C4: 1202F2FF 0000E408
	v_or_b32_e32 v121, 0x64006400, v209                        // 000000DD58CC: 38F3A2FF 64006400
	v_perm_b32 v120, v123, v156, 0xc040c00                     // 000000DD58D4: D6440078 03FF397B 0C040C00
	scratch_store_b32 off, v23, off offset:224                 // 000000DD58E0: DC6900E0 007C1700
	.long 0xcc0f4017                                           // 000000DD58E8: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v122                         // 000000DD58EC: 1202F4FF 0000E408
	v_or_b32_e32 v122, 0x64006400, v206                        // 000000DD58F4: 38F59CFF 64006400
	scratch_store_b32 off, v23, off offset:228                 // 000000DD58FC: DC6900E4 007C1700
	v_perm_b32 v23, v123, v156, 0xc050c01                      // 000000DD5904: D6440017 03FF397B 0C050C01
	scratch_store_b32 off, v23, off offset:824                 // 000000DD5910: DC690338 007C1700
	v_perm_b32 v23, v123, v156, 0xc060c02                      // 000000DD5918: D6440017 03FF397B 0C060C02
	scratch_store_b32 off, v23, off offset:828                 // 000000DD5924: DC69033C 007C1700
	v_perm_b32 v23, v123, v156, 0xc070c03                      // 000000DD592C: D6440017 03FF397B 0C070C03
	v_and_b32_e32 v123, 0xf0f0f0f, v159                        // 000000DD5938: 36F73EFF 0F0F0F0F
	scratch_store_b32 off, v23, off offset:832                 // 000000DD5940: DC690340 007C1700
	.long 0xcc0f4017                                           // 000000DD5948: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v121                         // 000000DD594C: 1202F2FF 0000E408
	v_or_b32_e32 v121, 0x64006400, v207                        // 000000DD5954: 38F39EFF 64006400
	v_perm_b32 v101, v123, v158, 0xc040c00                     // 000000DD595C: D6440065 03FF3D7B 0C040C00
	v_perm_b32 v117, v123, v158, 0xc070c03                     // 000000DD5968: D6440075 03FF3D7B 0C070C03
	scratch_store_b32 off, v23, off offset:232                 // 000000DD5974: DC6900E8 007C1700
	.long 0xcc0f4017                                           // 000000DD597C: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v122                         // 000000DD5980: 1202F4FF 0000E408
	v_or_b32_e32 v122, 0x64006400, v204                        // 000000DD5988: 38F598FF 64006400
	scratch_store_b32 off, v23, off offset:236                 // 000000DD5990: DC6900EC 007C1700
	v_perm_b32 v23, v123, v158, 0xc050c01                      // 000000DD5998: D6440017 03FF3D7B 0C050C01
	scratch_store_b32 off, v23, off offset:836                 // 000000DD59A4: DC690344 007C1700
	v_perm_b32 v23, v123, v158, 0xc060c02                      // 000000DD59AC: D6440017 03FF3D7B 0C060C02
	v_and_b32_e32 v123, 0xf0f0f0f, v161                        // 000000DD59B8: 36F742FF 0F0F0F0F
	scratch_store_b32 off, v23, off offset:840                 // 000000DD59C0: DC690348 007C1700
	.long 0xcc0f4017                                           // 000000DD59C8: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v121                         // 000000DD59CC: 1202F2FF 0000E408
	v_or_b32_e32 v121, 0x64006400, v205                        // 000000DD59D4: 38F39AFF 64006400
	v_perm_b32 v34, v123, v160, 0xc040c00                      // 000000DD59DC: D6440022 03FF417B 0C040C00
	v_perm_b32 v35, v123, v160, 0xc050c01                      // 000000DD59E8: D6440023 03FF417B 0C050C01
	scratch_store_b32 off, v23, off offset:240                 // 000000DD59F4: DC6900F0 007C1700
	.long 0xcc0f4017                                           // 000000DD59FC: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v122                         // 000000DD5A00: 1202F4FF 0000E408
	v_or_b32_e32 v122, 0x64006400, v203                        // 000000DD5A08: 38F596FF 64006400
	scratch_store_b32 off, v23, off offset:244                 // 000000DD5A10: DC6900F4 007C1700
	v_perm_b32 v23, v123, v160, 0xc060c02                      // 000000DD5A18: D6440017 03FF417B 0C060C02
	scratch_store_b32 off, v23, off offset:844                 // 000000DD5A24: DC69034C 007C1700
	v_perm_b32 v23, v123, v160, 0xc070c03                      // 000000DD5A2C: D6440017 03FF417B 0C070C03
	v_and_b32_e32 v123, 0xf0f0f0f, v163                        // 000000DD5A38: 36F746FF 0F0F0F0F
	scratch_store_b32 off, v23, off offset:848                 // 000000DD5A40: DC690350 007C1700
	.long 0xcc0f4017                                           // 000000DD5A48: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v121                         // 000000DD5A4C: 1202F2FF 0000E408
	v_or_b32_e32 v121, 0x64006400, v201                        // 000000DD5A54: 38F392FF 64006400
	v_perm_b32 v92, v123, v162, 0xc040c00                      // 000000DD5A5C: D644005C 03FF457B 0C040C00
	v_perm_b32 v95, v123, v162, 0xc050c01                      // 000000DD5A68: D644005F 03FF457B 0C050C01
	v_perm_b32 v97, v123, v162, 0xc060c02                      // 000000DD5A74: D6440061 03FF457B 0C060C02
	scratch_store_b32 off, v23, off offset:248                 // 000000DD5A80: DC6900F8 007C1700
	.long 0xcc0f4017                                           // 000000DD5A88: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v122                         // 000000DD5A8C: 1202F4FF 0000E408
	v_or_b32_e32 v122, 0x64006400, v202                        // 000000DD5A94: 38F594FF 64006400
	v_perm_b32 v119, v123, v162, 0xc070c03                     // 000000DD5A9C: D6440077 03FF457B 0C070C03
	v_and_b32_e32 v123, 0xf0f0f0f, v165                        // 000000DD5AA8: 36F74AFF 0F0F0F0F
	scratch_store_b32 off, v23, off offset:252                 // 000000DD5AB0: DC6900FC 007C1700
	.long 0xcc0f4017                                           // 000000DD5AB8: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v121                         // 000000DD5ABC: 1202F2FF 0000E408
	v_or_b32_e32 v121, 0x64006400, v199                        // 000000DD5AC4: 38F38EFF 64006400
	v_perm_b32 v100, v123, v164, 0xc040c00                     // 000000DD5ACC: D6440064 03FF497B 0C040C00
	v_perm_b32 v102, v123, v164, 0xc050c01                     // 000000DD5AD8: D6440066 03FF497B 0C050C01
	v_perm_b32 v106, v123, v164, 0xc060c02                     // 000000DD5AE4: D644006A 03FF497B 0C060C02
	scratch_store_b32 off, v23, off offset:256                 // 000000DD5AF0: DC690100 007C1700
	.long 0xcc0f4017                                           // 000000DD5AF8: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v122                         // 000000DD5AFC: 1202F4FF 0000E408
	v_or_b32_e32 v122, 0x64006400, v200                        // 000000DD5B04: 38F590FF 64006400
	v_perm_b32 v88, v123, v164, 0xc070c03                      // 000000DD5B0C: D6440058 03FF497B 0C070C03
	v_and_b32_e32 v123, 0xf0f0f0f, v167                        // 000000DD5B18: 36F74EFF 0F0F0F0F
	scratch_store_b32 off, v23, off offset:260                 // 000000DD5B20: DC690104 007C1700
	.long 0xcc0f4017                                           // 000000DD5B28: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v121                         // 000000DD5B2C: 1202F2FF 0000E408
	v_or_b32_e32 v121, 0x64006400, v197                        // 000000DD5B34: 38F38AFF 64006400
	v_perm_b32 v108, v123, v166, 0xc040c00                     // 000000DD5B3C: D644006C 03FF4D7B 0C040C00
	v_perm_b32 v109, v123, v166, 0xc050c01                     // 000000DD5B48: D644006D 03FF4D7B 0C050C01
	v_perm_b32 v91, v123, v166, 0xc060c02                      // 000000DD5B54: D644005B 03FF4D7B 0C060C02
	scratch_store_b32 off, v23, off offset:264                 // 000000DD5B60: DC690108 007C1700
	.long 0xcc0f4017                                           // 000000DD5B68: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v122                         // 000000DD5B6C: 1202F4FF 0000E408
	v_or_b32_e32 v122, 0x64006400, v198                        // 000000DD5B74: 38F58CFF 64006400
	v_perm_b32 v111, v123, v166, 0xc070c03                     // 000000DD5B7C: D644006F 03FF4D7B 0C070C03
	v_and_b32_e32 v123, 0xf0f0f0f, v169                        // 000000DD5B88: 36F752FF 0F0F0F0F
	scratch_store_b32 off, v23, off offset:268                 // 000000DD5B90: DC69010C 007C1700
	.long 0xcc0f4017                                           // 000000DD5B98: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v121                         // 000000DD5B9C: 1202F2FF 0000E408
	v_or_b32_e32 v121, 0x64006400, v195                        // 000000DD5BA4: 38F386FF 64006400
	v_perm_b32 v94, v123, v168, 0xc050c01                      // 000000DD5BAC: D644005E 03FF517B 0C050C01
	v_perm_b32 v107, v123, v168, 0xc060c02                     // 000000DD5BB8: D644006B 03FF517B 0C060C02
	v_perm_b32 v110, v123, v168, 0xc070c03                     // 000000DD5BC4: D644006E 03FF517B 0C070C03
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000DD5BD0: BF8700D4
	.long 0xcc0f4018                                           // 000000DD5BD4: CC0F4018
	v_mul_i32_i24_e32 v1, 0xe408, v121                         // 000000DD5BD8: 1202F2FF 0000E408
	scratch_store_b32 off, v23, off offset:272                 // 000000DD5BE0: DC690110 007C1700
	.long 0xcc0f4017                                           // 000000DD5BE8: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v122                         // 000000DD5BEC: 1202F4FF 0000E408
	v_or_b32_e32 v122, 0x64006400, v196                        // 000000DD5BF4: 38F588FF 64006400
	v_or_b32_e32 v121, 0x64006400, v193                        // 000000DD5BFC: 38F382FF 64006400
	.long 0xcc0f4029                                           // 000000DD5C04: CC0F4029
	v_mul_i32_i24_e32 v1, 0xe408, v121                         // 000000DD5C08: 1202F2FF 0000E408
	scratch_store_b32 off, v24, off offset:280                 // 000000DD5C10: DC690118 007C1800
	.long 0xcc0f4018                                           // 000000DD5C18: CC0F4018
	v_mul_i32_i24_e32 v1, 0xe408, v122                         // 000000DD5C1C: 1202F4FF 0000E408
	v_or_b32_e32 v122, 0x64006400, v194                        // 000000DD5C24: 38F584FF 64006400
	v_or_b32_e32 v121, 0x64006400, v191                        // 000000DD5C2C: 38F37EFF 64006400
	scratch_store_b32 off, v23, off offset:276                 // 000000DD5C34: DC690114 007C1700
	v_perm_b32 v23, v123, v168, 0xc040c00                      // 000000DD5C3C: D6440017 03FF517B 0C040C00
	v_and_b32_e32 v123, 0xf0f0f0f, v171                        // 000000DD5C48: 36F756FF 0F0F0F0F
	.long 0xcc0f402f                                           // 000000DD5C50: CC0F402F
	v_mul_i32_i24_e32 v1, 0xe408, v121                         // 000000DD5C54: 1202F2FF 0000E408
	scratch_store_b32 off, v41, off offset:288                 // 000000DD5C5C: DC690120 007C2900
	.long 0xcc0f4029                                           // 000000DD5C64: CC0F4029
	v_mul_i32_i24_e32 v1, 0xe408, v122                         // 000000DD5C68: 1202F4FF 0000E408
	v_or_b32_e32 v122, 0x64006400, v192                        // 000000DD5C70: 38F580FF 64006400
	v_or_b32_e32 v121, 0x64006400, v189                        // 000000DD5C78: 38F37AFF 64006400
	scratch_store_b32 off, v24, off offset:284                 // 000000DD5C80: DC69011C 007C1800
	v_perm_b32 v24, v123, v170, 0xc040c00                      // 000000DD5C88: D6440018 03FF557B 0C040C00
	v_perm_b32 v38, v123, v170, 0xc050c01                      // 000000DD5C94: D6440026 03FF557B 0C050C01
	v_perm_b32 v89, v123, v170, 0xc060c02                      // 000000DD5CA0: D6440059 03FF557B 0C060C02
	.long 0xcc0f4033                                           // 000000DD5CAC: CC0F4033
	v_mul_i32_i24_e32 v1, 0xe408, v121                         // 000000DD5CB0: 1202F2FF 0000E408
	scratch_store_b32 off, v47, off offset:296                 // 000000DD5CB8: DC690128 007C2F00
	.long 0xcc0f402f                                           // 000000DD5CC0: CC0F402F
	v_mul_i32_i24_e32 v1, 0xe408, v122                         // 000000DD5CC4: 1202F4FF 0000E408
	v_or_b32_e32 v122, 0x64006400, v190                        // 000000DD5CCC: 38F57CFF 64006400
	v_or_b32_e32 v121, 0x64006400, v187                        // 000000DD5CD4: 38F376FF 64006400
	s_clause 0x1                                               // 000000DD5CDC: BF850001
	scratch_store_b32 off, v51, off offset:304                 // 000000DD5CE0: DC690130 007C3300
	scratch_store_b32 off, v41, off offset:292                 // 000000DD5CE8: DC690124 007C2900
	v_perm_b32 v90, v123, v170, 0xc070c03                      // 000000DD5CF0: D644005A 03FF557B 0C070C03
	.long 0xcc0f4033                                           // 000000DD5CFC: CC0F4033
	v_mul_i32_i24_e32 v1, 0xe408, v122                         // 000000DD5D00: 1202F4FF 0000E408
	scratch_store_b32 off, v47, off offset:300                 // 000000DD5D08: DC69012C 007C2F00
	v_or_b32_e32 v122, 0x64006400, v188                        // 000000DD5D10: 38F578FF 64006400
	v_and_b32_e32 v123, 0xf0f0f0f, v173                        // 000000DD5D18: 36F75AFF 0F0F0F0F
	v_or_b32_e32 v22, 0x64006400, v23                          // 000000DD5D20: 382C2EFF 64006400
	scratch_store_b32 off, v51, off offset:308                 // 000000DD5D28: DC690134 007C3300
	.long 0xcc0f4033                                           // 000000DD5D30: CC0F4033
	v_mul_i32_i24_e32 v1, 0xe408, v121                         // 000000DD5D34: 1202F2FF 0000E408
	v_or_b32_e32 v121, 0x64006400, v186                        // 000000DD5D3C: 38F374FF 64006400
	v_perm_b32 v41, v123, v172, 0xc040c00                      // 000000DD5D44: D6440029 03FF597B 0C040C00
	v_perm_b32 v42, v123, v172, 0xc050c01                      // 000000DD5D50: D644002A 03FF597B 0C050C01
	v_perm_b32 v43, v123, v172, 0xc060c02                      // 000000DD5D5C: D644002B 03FF597B 0C060C02
	v_perm_b32 v93, v123, v172, 0xc070c03                      // 000000DD5D68: D644005D 03FF597B 0C070C03
	.long 0xcc0f4038                                           // 000000DD5D74: CC0F4038
	v_mul_i32_i24_e32 v1, 0xe408, v121                         // 000000DD5D78: 1202F2FF 0000E408
	scratch_store_b32 off, v51, off offset:312                 // 000000DD5D80: DC690138 007C3300
	.long 0xcc0f4033                                           // 000000DD5D88: CC0F4033
	v_mul_i32_i24_e32 v1, 0xe408, v122                         // 000000DD5D8C: 1202F4FF 0000E408
	v_or_b32_e32 v122, 0x64006400, v184                        // 000000DD5D94: 38F570FF 64006400
	v_or_b32_e32 v121, 0x64006400, v185                        // 000000DD5D9C: 38F372FF 64006400
	v_and_b32_e32 v123, 0xf0f0f0f, v175                        // 000000DD5DA4: 36F75EFF 0F0F0F0F
	v_or_b32_e32 v23, 0x64006400, v94                          // 000000DD5DAC: 382EBCFF 64006400
	.long 0xcc0f4016                                           // 000000DD5DB4: CC0F4016
	v_mul_i32_i24_e32 v1, 0xe408, v22                          // 000000DD5DB8: 12022CFF 0000E408
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DD5DC0: BF870004
	.long 0xcc0f403d                                           // 000000DD5DC4: CC0F403D
	v_mul_i32_i24_e32 v1, 0xe408, v121                         // 000000DD5DC8: 1202F2FF 0000E408
	scratch_store_b32 off, v56, off offset:320                 // 000000DD5DD0: DC690140 007C3800
	.long 0xcc0f4038                                           // 000000DD5DD8: CC0F4038
	v_mul_i32_i24_e32 v1, 0xe408, v122                         // 000000DD5DDC: 1202F4FF 0000E408
	v_or_b32_e32 v122, 0x64006400, v182                        // 000000DD5DE4: 38F56CFF 64006400
	s_clause 0x1                                               // 000000DD5DEC: BF850001
	scratch_store_b32 off, v51, off offset:316                 // 000000DD5DF0: DC69013C 007C3300
	scratch_store_b32 off, v61, off offset:328                 // 000000DD5DF8: DC690148 007C3D00
	v_or_b32_e32 v121, 0x64006400, v181                        // 000000DD5E00: 38F36AFF 64006400
	v_perm_b32 v47, v123, v174, 0xc040c00                      // 000000DD5E08: D644002F 03FF5D7B 0C040C00
	.long 0xcc0f403d                                           // 000000DD5E14: CC0F403D
	v_mul_i32_i24_e32 v1, 0xe408, v122                         // 000000DD5E18: 1202F4FF 0000E408
	scratch_store_b32 off, v56, off offset:324                 // 000000DD5E20: DC690144 007C3800
	v_perm_b32 v50, v123, v174, 0xc050c01                      // 000000DD5E28: D6440032 03FF5D7B 0C050C01
	v_perm_b32 v60, v123, v174, 0xc060c02                      // 000000DD5E34: D644003C 03FF5D7B 0C060C02
	v_perm_b32 v54, v123, v174, 0xc070c03                      // 000000DD5E40: D6440036 03FF5D7B 0C070C03
	scratch_store_b32 off, v61, off offset:332                 // 000000DD5E4C: DC69014C 007C3D00
	v_perm_b32 v61, v27, v69, 0xc040c00                        // 000000DD5E54: D644003D 03FE8B1B 0C040C00
	v_or_b32_e32 v27, 0x64006400, v183                         // 000000DD5E60: 38376EFF 64006400
	v_and_b32_e32 v123, 0xf0f0f0f, v177                        // 000000DD5E68: 36F762FF 0F0F0F0F
	s_waitcnt vmcnt(0)                                         // 000000DD5E70: BF8903F7
	v_and_b32_e32 v122, 0xf0f0f0f, v66                         // 000000DD5E74: 36F484FF 0F0F0F0F
	.long 0xcc0f4017                                           // 000000DD5E7C: CC0F4017
	v_mul_i32_i24_e32 v1, 0xe408, v23                          // 000000DD5E80: 12022EFF 0000E408
	.long 0xcc0f401b                                           // 000000DD5E88: CC0F401B
	v_mul_i32_i24_e32 v1, 0xe408, v27                          // 000000DD5E8C: 120236FF 0000E408
	v_perm_b32 v55, v123, v176, 0xc040c00                      // 000000DD5E94: D6440037 03FF617B 0C040C00
	v_perm_b32 v65, v123, v176, 0xc050c01                      // 000000DD5EA0: D6440041 03FF617B 0C050C01
	v_perm_b32 v58, v123, v176, 0xc060c02                      // 000000DD5EAC: D644003A 03FF617B 0C060C02
	v_perm_b32 v59, v123, v176, 0xc070c03                      // 000000DD5EB8: D644003B 03FF617B 0C070C03
	scratch_store_b32 off, v27, off offset:336                 // 000000DD5EC4: DC690150 007C1B00
	.long 0xcc0f401b                                           // 000000DD5ECC: CC0F401B
	v_mul_i32_i24_e32 v1, 0xe408, v121                         // 000000DD5ED0: 1202F2FF 0000E408
	v_and_b32_e32 v123, 0xf0f0f0f, v179                        // 000000DD5ED8: 36F766FF 0F0F0F0F
	v_perm_b32 v66, v122, v36, 0xc040c00                       // 000000DD5EE0: D6440042 03FE497A 0C040C00
	v_perm_b32 v67, v122, v36, 0xc050c01                       // 000000DD5EEC: D6440043 03FE497A 0C050C01
	v_perm_b32 v68, v122, v36, 0xc060c02                       // 000000DD5EF8: D6440044 03FE497A 0C060C02
	scratch_store_b32 off, v27, off offset:340                 // 000000DD5F04: DC690154 007C1B00
	scratch_load_b32 v27, off, off offset:404                  // 000000DD5F0C: DC510194 1B7C0000
	v_perm_b32 v69, v122, v36, 0xc070c03                       // 000000DD5F14: D6440045 03FE497A 0C070C03
	v_perm_b32 v51, v123, v178, 0xc040c00                      // 000000DD5F20: D6440033 03FF657B 0C040C00
	v_perm_b32 v79, v123, v178, 0xc050c01                      // 000000DD5F2C: D644004F 03FF657B 0C050C01
	v_perm_b32 v80, v123, v178, 0xc060c02                      // 000000DD5F38: D6440050 03FF657B 0C060C02
	v_perm_b32 v64, v123, v178, 0xc070c03                      // 000000DD5F44: D6440040 03FF657B 0C070C03
	v_and_b32_e32 v123, 0xf0f0f0f, v180                        // 000000DD5F50: 36F768FF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DD5F58: BF870001
	v_perm_b32 v56, v123, v104, 0xc040c00                      // 000000DD5F5C: D6440038 03FED17B 0C040C00
	v_perm_b32 v57, v123, v104, 0xc050c01                      // 000000DD5F68: D6440039 03FED17B 0C050C01
	v_perm_b32 v76, v123, v104, 0xc060c02                      // 000000DD5F74: D644004C 03FED17B 0C060C02
	v_perm_b32 v104, v123, v104, 0xc070c03                     // 000000DD5F80: D6440068 03FED17B 0C070C03
	s_waitcnt vmcnt(0)                                         // 000000DD5F8C: BF8903F7
	v_and_b32_e32 v27, 0xf0f0f0f, v27                          // 000000DD5F90: 363636FF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DD5F98: BF870001
	v_perm_b32 v75, v27, v16, 0xc040c00                        // 000000DD5F9C: D644004B 03FE211B 0C040C00
	v_perm_b32 v72, v27, v16, 0xc050c01                        // 000000DD5FA8: D6440048 03FE211B 0C050C01
	v_perm_b32 v73, v27, v16, 0xc060c02                        // 000000DD5FB4: D6440049 03FE211B 0C060C02
	v_perm_b32 v74, v27, v16, 0xc070c03                        // 000000DD5FC0: D644004A 03FE211B 0C070C03
	scratch_load_b32 v16, off, off offset:356                  // 000000DD5FCC: DC510164 107C0000
	v_or_b32_e32 v73, 0x64006400, v73                          // 000000DD5FD4: 389292FF 64006400
	v_or_b32_e32 v74, 0x64006400, v74                          // 000000DD5FDC: 389494FF 64006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DD5FE4: BF870112
	.long 0xcc0f4049                                           // 000000DD5FE8: CC0F4049
	v_mul_i32_i24_e32 v1, 0xe408, v73                          // 000000DD5FEC: 120292FF 0000E408
	.long 0xcc0f404a                                           // 000000DD5FF4: CC0F404A
	v_mul_i32_i24_e32 v1, 0xe408, v74                          // 000000DD5FF8: 120294FF 0000E408
	s_waitcnt vmcnt(0)                                         // 000000DD6000: BF8903F7
	v_and_b32_e32 v16, 0xf0f0f0f, v16                          // 000000DD6004: 362020FF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DD600C: BF870001
	v_perm_b32 v71, v16, v15, 0xc040c00                        // 000000DD6010: D6440047 03FE1F10 0C040C00
	v_perm_b32 v86, v16, v15, 0xc050c01                        // 000000DD601C: D6440056 03FE1F10 0C050C01
	v_perm_b32 v87, v16, v15, 0xc060c02                        // 000000DD6028: D6440057 03FE1F10 0C060C02
	v_perm_b32 v85, v16, v15, 0xc070c03                        // 000000DD6034: D6440055 03FE1F10 0C070C03
	s_clause 0x1                                               // 000000DD6040: BF850001
	scratch_load_b32 v15, off, off offset:352                  // 000000DD6044: DC510160 0F7C0000
	scratch_load_b32 v16, off, off offset:388                  // 000000DD604C: DC510184 107C0000
	s_waitcnt vmcnt(1)                                         // 000000DD6054: BF8907F7
	v_and_b32_e32 v15, 0xf0f0f0f, v15                          // 000000DD6058: 361E1EFF 0F0F0F0F
	s_waitcnt vmcnt(0)                                         // 000000DD6060: BF8903F7
	v_or_b32_e32 v16, 0x64006400, v16                          // 000000DD6064: 382020FF 64006400
	s_delay_alu instid0(VALU_DEP_2)                            // 000000DD606C: BF870002
	v_perm_b32 v83, v15, v13, 0xc040c00                        // 000000DD6070: D6440053 03FE1B0F 0C040C00
	v_perm_b32 v84, v15, v13, 0xc050c01                        // 000000DD607C: D6440054 03FE1B0F 0C050C01
	v_perm_b32 v116, v15, v13, 0xc060c02                       // 000000DD6088: D6440074 03FE1B0F 0C060C02
	v_perm_b32 v115, v15, v13, 0xc070c03                       // 000000DD6094: D6440073 03FE1B0F 0C070C03
	s_clause 0x1                                               // 000000DD60A0: BF850001
	scratch_load_b32 v13, off, off offset:348                  // 000000DD60A4: DC51015C 0D7C0000
	scratch_load_b32 v15, off, off offset:368                  // 000000DD60AC: DC510170 0F7C0000
	s_waitcnt vmcnt(1)                                         // 000000DD60B4: BF8907F7
	v_and_b32_e32 v13, 0xf0f0f0f, v13                          // 000000DD60B8: 361A1AFF 0F0F0F0F
	s_waitcnt vmcnt(0)                                         // 000000DD60C0: BF8903F7
	v_or_b32_e32 v15, 0x64006400, v15                          // 000000DD60C4: 381E1EFF 64006400
	s_delay_alu instid0(VALU_DEP_2)                            // 000000DD60CC: BF870002
	v_perm_b32 v112, v13, v10, 0xc040c00                       // 000000DD60D0: D6440070 03FE150D 0C040C00
	v_perm_b32 v113, v13, v10, 0xc050c01                       // 000000DD60DC: D6440071 03FE150D 0C050C01
	v_perm_b32 v114, v13, v10, 0xc060c02                       // 000000DD60E8: D6440072 03FE150D 0C060C02
	v_perm_b32 v27, v13, v10, 0xc070c03                        // 000000DD60F4: D644001B 03FE150D 0C070C03
	scratch_load_b32 v10, off, off offset:344                  // 000000DD6100: DC510158 0A7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD6108: BF8903F7
	v_and_b32_e32 v10, 0xf0f0f0f, v10                          // 000000DD610C: 361414FF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DD6114: BF870001
	v_perm_b32 v13, v10, v9, 0xc040c00                         // 000000DD6118: D644000D 03FE130A 0C040C00
	scratch_store_b32 off, v13, off offset:852                 // 000000DD6124: DC690354 007C0D00
	v_perm_b32 v13, v10, v9, 0xc050c01                         // 000000DD612C: D644000D 03FE130A 0C050C01
	scratch_store_b32 off, v13, off offset:856                 // 000000DD6138: DC690358 007C0D00
	v_perm_b32 v13, v10, v9, 0xc060c02                         // 000000DD6140: D644000D 03FE130A 0C060C02
	v_perm_b32 v9, v10, v9, 0xc070c03                          // 000000DD614C: D6440009 03FE130A 0C070C03
	scratch_load_b32 v10, off, off offset:360                  // 000000DD6158: DC510168 0A7C0000
	scratch_store_b32 off, v9, off offset:864                  // 000000DD6160: DC690360 007C0900
	v_cvt_f32_f16_e32 v9, v25                                  // 000000DD6168: 7E121719
	scratch_store_b32 off, v13, off offset:860                 // 000000DD616C: DC69035C 007C0D00
	scratch_load_b32 v13, off, off offset:376                  // 000000DD6174: DC510178 0D7C0000
	scratch_store_b32 off, v9, off offset:344                  // 000000DD617C: DC690158 007C0900
	v_cvt_f32_f16_e32 v9, v153/*Invalid register, operand has 'VS_32_Lo128' register class*/// 000000DD6184: 7E121799
	v_or_b32_e32 v25, 0x64006400, v107                         // 000000DD6188: 3832D6FF 64006400
	scratch_store_b32 off, v9, off offset:348                  // 000000DD6190: DC69015C 007C0900
	v_cvt_f32_f16_e32 v9, v26                                  // 000000DD6198: 7E12171A
	scratch_store_b32 off, v9, off offset:352                  // 000000DD619C: DC690160 007C0900
	v_cvt_f32_f16_e32 v9, v154/*Invalid register, operand has 'VS_32_Lo128' register class*/// 000000DD61A4: 7E12179A
	v_or_b32_e32 v26, 0x64006400, v110                         // 000000DD61A8: 3834DCFF 64006400
	scratch_store_b32 off, v9, off offset:356                  // 000000DD61B0: DC690164 007C0900
	scratch_load_b32 v9, off, off offset:396                   // 000000DD61B8: DC51018C 097C0000
	s_waitcnt vmcnt(2)                                         // 000000DD61C0: BF890BF7
	v_or_b32_e32 v10, 0x64006400, v10                          // 000000DD61C4: 381414FF 64006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000DD61CC: BF8700D1
	.long 0xcc0f400a                                           // 000000DD61D0: CC0F400A
	v_mul_i32_i24_e32 v1, 0xe408, v10                          // 000000DD61D4: 120214FF 0000E408
	s_waitcnt vmcnt(1)                                         // 000000DD61DC: BF8907F7
	v_or_b32_e32 v13, 0x64006400, v13                          // 000000DD61E0: 381A1AFF 64006400
	s_waitcnt vmcnt(0)                                         // 000000DD61E8: BF8903F7
	v_or_b32_e32 v9, 0x64006400, v9                            // 000000DD61EC: 381212FF 64006400
	.long 0xcc0f4009                                           // 000000DD61F4: CC0F4009
	v_mul_i32_i24_e32 v1, 0xe408, v9                           // 000000DD61F8: 120212FF 0000E408
	scratch_store_b32 off, v9, off offset:360                  // 000000DD6200: DC690168 007C0900
	scratch_load_b32 v9, off, off offset:364                   // 000000DD6208: DC51016C 097C0000
	scratch_store_b32 off, v10, off offset:364                 // 000000DD6210: DC69016C 007C0A00
	.long 0xcc0f400a                                           // 000000DD6218: CC0F400A
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DD621C: 12021AFF 0000E408
	scratch_load_b32 v13, off, off offset:380                  // 000000DD6224: DC51017C 0D7C0000
	scratch_store_b32 off, v10, off offset:368                 // 000000DD622C: DC690170 007C0A00
	scratch_load_b32 v10, off, off offset:372                  // 000000DD6234: DC510174 0A7C0000
	s_waitcnt vmcnt(2)                                         // 000000DD623C: BF890BF7
	v_or_b32_e32 v9, 0x64006400, v9                            // 000000DD6240: 381212FF 64006400
	s_waitcnt vmcnt(1)                                         // 000000DD6248: BF8907F7
	v_or_b32_e32 v13, 0x64006400, v13                          // 000000DD624C: 381A1AFF 64006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000DD6254: BF8700B2
	.long 0xcc0f4009                                           // 000000DD6258: CC0F4009
	v_mul_i32_i24_e32 v1, 0xe408, v9                           // 000000DD625C: 120212FF 0000E408
	s_waitcnt vmcnt(0)                                         // 000000DD6264: BF8903F7
	v_or_b32_e32 v10, 0x64006400, v10                          // 000000DD6268: 381414FF 64006400
	.long 0xcc0f400a                                           // 000000DD6270: CC0F400A
	v_mul_i32_i24_e32 v1, 0xe408, v10                          // 000000DD6274: 120214FF 0000E408
	scratch_store_b32 off, v9, off offset:372                  // 000000DD627C: DC690174 007C0900
	.long 0xcc0f4009                                           // 000000DD6284: CC0F4009
	v_mul_i32_i24_e32 v1, 0xe408, v15                          // 000000DD6288: 12021EFF 0000E408
	scratch_load_b32 v15, off, off offset:384                  // 000000DD6290: DC510180 0F7C0000
	scratch_store_b32 off, v9, off offset:376                  // 000000DD6298: DC690178 007C0900
	scratch_load_b32 v9, off, off offset:392                   // 000000DD62A0: DC510188 097C0000
	s_waitcnt vmcnt(1)                                         // 000000DD62A8: BF8907F7
	v_or_b32_e32 v15, 0x64006400, v15                          // 000000DD62AC: 381E1EFF 64006400
	s_waitcnt vmcnt(0)                                         // 000000DD62B4: BF8903F7
	v_or_b32_e32 v9, 0x64006400, v9                            // 000000DD62B8: 381212FF 64006400
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DD62C0: BF870001
	.long 0xcc0f4009                                           // 000000DD62C4: CC0F4009
	v_mul_i32_i24_e32 v1, 0xe408, v9                           // 000000DD62C8: 120212FF 0000E408
	scratch_store_b32 off, v10, off offset:380                 // 000000DD62D0: DC69017C 007C0A00
	v_or_b32_e32 v10, 0x64006400, v238                         // 000000DD62D8: 3815DCFF 64006400
	scratch_store_b32 off, v9, off offset:384                  // 000000DD62E0: DC690180 007C0900
	.long 0xcc0f4009                                           // 000000DD62E8: CC0F4009
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DD62EC: 12021AFF 0000E408
	v_or_b32_e32 v13, 0x64006400, v243                         // 000000DD62F4: 381BE6FF 64006400
	scratch_store_b32 off, v9, off offset:388                  // 000000DD62FC: DC690184 007C0900
	.long 0xcc0f4009                                           // 000000DD6304: CC0F4009
	v_mul_i32_i24_e32 v1, 0xe408, v15                          // 000000DD6308: 12021EFF 0000E408
	v_or_b32_e32 v15, 0x64006400, v248                         // 000000DD6310: 381FF0FF 64006400
	scratch_store_b32 off, v9, off offset:392                  // 000000DD6318: DC690188 007C0900
	.long 0xcc0f4009                                           // 000000DD6320: CC0F4009
	v_mul_i32_i24_e32 v1, 0xe408, v16                          // 000000DD6324: 120220FF 0000E408
	v_or_b32_e32 v16, 0x64006400, v252                         // 000000DD632C: 3821F8FF 64006400
	.long 0xcc0f40fc                                           // 000000DD6334: CC0F40FC
	v_mul_i32_i24_e32 v1, 0xe408, v0                           // 000000DD6338: 120200FF 0000E408
	v_or_b32_e32 v0, 0x64006400, v254                          // 000000DD6340: 3801FCFF 64006400
	scratch_store_b32 off, v9, off offset:396                  // 000000DD6348: DC69018C 007C0900
	scratch_load_b32 v9, off, off offset:400                   // 000000DD6350: DC510190 097C0000
	.long 0xcc0f40fe                                           // 000000DD6358: CC0F40FE
	v_mul_i32_i24_e32 v1, 0xe408, v0                           // 000000DD635C: 120200FF 0000E408
	scratch_load_b32 v0, off, off offset:808                   // 000000DD6364: DC510328 007C0000
	s_waitcnt vmcnt(1)                                         // 000000DD636C: BF8907F7
	v_cmp_eq_u32_e32 vcc_lo, 0, v9                             // 000000DD6370: 7C941280
	v_lshlrev_b32_e32 v9, 6, v9                                // 000000DD6374: 30121286
	s_waitcnt vmcnt(0)                                         // 000000DD6378: BF8903F7
	v_or_b32_e32 v0, 0x64006400, v0                            // 000000DD637C: 380000FF 64006400
	scratch_store_b32 off, v9, off offset:400                  // 000000DD6384: DC690190 007C0900
	v_or_b32_e32 v9, 0x64006400, v237                          // 000000DD638C: 3813DAFF 64006400
	.long 0xcc0f4000                                           // 000000DD6394: CC0F4000
	v_mul_i32_i24_e32 v1, 0xe408, v0                           // 000000DD6398: 120200FF 0000E408
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000DD63A0: BF870152
	.long 0xcc0f4009                                           // 000000DD63A4: CC0F4009
	v_mul_i32_i24_e32 v1, 0xe408, v9                           // 000000DD63A8: 120212FF 0000E408
	scratch_store_b32 off, v9, off offset:404                  // 000000DD63B0: DC690194 007C0900
	.long 0xcc0f4009                                           // 000000DD63B8: CC0F4009
	v_mul_i32_i24_e32 v1, 0xe408, v10                          // 000000DD63BC: 120214FF 0000E408
	v_or_b32_e32 v10, 0x64006400, v19                          // 000000DD63C4: 381426FF 64006400
	v_or_b32_e32 v19, 0x64006400, v109                         // 000000DD63CC: 3826DAFF 64006400
	.long 0xcc0f4001                                           // 000000DD63D4: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v10                          // 000000DD63D8: 120214FF 0000E408
	scratch_store_b32 off, v9, off offset:408                  // 000000DD63E0: DC690198 007C0900
	.long 0xcc0f4009                                           // 000000DD63E8: CC0F4009
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DD63EC: 12021AFF 0000E408
	v_or_b32_e32 v13, 0x64006400, v20                          // 000000DD63F4: 381A28FF 64006400
	v_or_b32_e32 v10, 0x64006400, v101                         // 000000DD63FC: 3814CAFF 64006400
	scratch_store_b32 off, v1, off offset:436                  // 000000DD6404: DC6901B4 007C0100
	v_or_b32_e32 v20, 0x64006400, v91                          // 000000DD640C: 3828B6FF 64006400
	.long 0xcc0f4013                                           // 000000DD6414: CC0F4013
	v_mul_i32_i24_e32 v1, 0xe408, v19                          // 000000DD6418: 120226FF 0000E408
	.long 0xcc0f4001                                           // 000000DD6420: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DD6424: 12021AFF 0000E408
	scratch_store_b32 off, v9, off offset:412                  // 000000DD642C: DC69019C 007C0900
	.long 0xcc0f4009                                           // 000000DD6434: CC0F4009
	v_mul_i32_i24_e32 v1, 0xe408, v15                          // 000000DD6438: 12021EFF 0000E408
	v_or_b32_e32 v13, 0x64006400, v119                         // 000000DD6440: 381AEEFF 64006400
	v_or_b32_e32 v15, 0x64006400, v102                         // 000000DD6448: 381ECCFF 64006400
	scratch_store_b32 off, v1, off offset:440                  // 000000DD6450: DC6901B8 007C0100
	v_or_b32_e32 v1, 0x64006400, v3                            // 000000DD6458: 380206FF 64006400
	v_or_b32_e32 v3, 0x64006400, v21                           // 000000DD6460: 38062AFF 64006400
	v_or_b32_e32 v21, 0x64006400, v111                         // 000000DD6468: 382ADEFF 64006400
	.long 0xcc0f400d                                           // 000000DD6470: CC0F400D
	v_mul_i32_i24_e32 v1, 0xe408, v13                          // 000000DD6474: 12021AFF 0000E408
	.long 0xcc0f400f                                           // 000000DD647C: CC0F400F
	v_mul_i32_i24_e32 v1, 0xe408, v15                          // 000000DD6480: 12021EFF 0000E408
	.long 0xcc0f4001                                           // 000000DD6488: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DD648C: 120202FF 0000E408
	scratch_store_b32 off, v9, off offset:416                  // 000000DD6494: DC6901A0 007C0900
	.long 0xcc0f4009                                           // 000000DD649C: CC0F4009
	v_mul_i32_i24_e32 v1, 0xe408, v16                          // 000000DD64A0: 120220FF 0000E408
	v_or_b32_e32 v16, 0x64006400, v106                         // 000000DD64A8: 3820D4FF 64006400
	.long 0xcc0f4014                                           // 000000DD64B0: CC0F4014
	v_mul_i32_i24_e32 v1, 0xe408, v20                          // 000000DD64B4: 120228FF 0000E408
	scratch_store_b32 off, v1, off offset:444                  // 000000DD64BC: DC6901BC 007C0100
	.long 0xcc0f4001                                           // 000000DD64C4: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DD64C8: 120204FF 0000E408
	scratch_store_b32 off, v9, off offset:420                  // 000000DD64D0: DC6901A4 007C0900
	v_or_b32_e32 v9, 0x64006400, v253                          // 000000DD64D8: 3813FAFF 64006400
	v_or_b32_e32 v2, 0x64006400, v29                           // 000000DD64E0: 38043AFF 64006400
	.long 0xcc0f4010                                           // 000000DD64E8: CC0F4010
	v_mul_i32_i24_e32 v1, 0xe408, v16                          // 000000DD64EC: 120220FF 0000E408
	scratch_store_b32 off, v1, off offset:448                  // 000000DD64F4: DC6901C0 007C0100
	.long 0xcc0f4001                                           // 000000DD64FC: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DD6500: 120206FF 0000E408
	.long 0xcc0f4009                                           // 000000DD6508: CC0F4009
	v_mul_i32_i24_e32 v1, 0xe408, v9                           // 000000DD650C: 120212FF 0000E408
	v_or_b32_e32 v3, 0x64006400, v32                           // 000000DD6514: 380640FF 64006400
	.long 0xcc0f4015                                           // 000000DD651C: CC0F4015
	v_mul_i32_i24_e32 v1, 0xe408, v21                          // 000000DD6520: 12022AFF 0000E408
	s_clause 0x1                                               // 000000DD6528: BF850001
	scratch_store_b32 off, v1, off offset:452                  // 000000DD652C: DC6901C4 007C0100
	scratch_store_b32 off, v9, off offset:424                  // 000000DD6534: DC6901A8 007C0900
	v_or_b32_e32 v9, 0x64006400, v28                           // 000000DD653C: 381238FF 64006400
	.long 0xcc0f4001                                           // 000000DD6544: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DD6548: 120208FF 0000E408
	v_or_b32_e32 v4, 0x64006400, v44                           // 000000DD6550: 380858FF 64006400
	.long 0xcc0f4079                                           // 000000DD6558: CC0F4079
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DD655C: 120206FF 0000E408
	v_or_b32_e32 v3, 0x64006400, v8                            // 000000DD6564: 380610FF 64006400
	v_or_b32_e32 v44, 0x64006400, v41                          // 000000DD656C: 385852FF 64006400
	scratch_store_b32 off, v1, off offset:456                  // 000000DD6574: DC6901C8 007C0100
	.long 0xcc0f4001                                           // 000000DD657C: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v9                           // 000000DD6580: 120212FF 0000E408
	.long 0xcc0f407a                                           // 000000DD6588: CC0F407A
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DD658C: 120208FF 0000E408
	v_or_b32_e32 v4, 0x64006400, v11                           // 000000DD6594: 380816FF 64006400
	.long 0xcc0f407e                                           // 000000DD659C: CC0F407E
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DD65A0: 120206FF 0000E408
	v_or_b32_e32 v3, 0x64006400, v17                           // 000000DD65A8: 380622FF 64006400
	scratch_store_b32 off, v1, off offset:460                  // 000000DD65B0: DC6901CC 007C0100
	v_or_b32_e32 v1, 0x64006400, v5                            // 000000DD65B8: 38020AFF 64006400
	v_or_b32_e32 v5, 0x64006400, v45                           // 000000DD65C0: 380A5AFF 64006400
	.long 0xcc0f407f                                           // 000000DD65C8: CC0F407F
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DD65CC: 120208FF 0000E408
	v_or_b32_e32 v4, 0x64006400, v48                           // 000000DD65D4: 380860FF 64006400
	.long 0xcc0f4083                                           // 000000DD65DC: CC0F4083
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DD65E0: 120206FF 0000E408
	.long 0xcc0f4001                                           // 000000DD65E8: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DD65EC: 120202FF 0000E408
	.long 0xcc0f407b                                           // 000000DD65F4: CC0F407B
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DD65F8: 12020AFF 0000E408
	v_or_b32_e32 v5, 0x64006400, v46                           // 000000DD6600: 380A5CFF 64006400
	.long 0xcc0f4084                                           // 000000DD6608: CC0F4084
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DD660C: 120208FF 0000E408
	v_or_b32_e32 v3, 0x64006400, v52                           // 000000DD6614: 380668FF 64006400
	scratch_store_b32 off, v1, off offset:464                  // 000000DD661C: DC6901D0 007C0100
	.long 0xcc0f4001                                           // 000000DD6624: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DD6628: 120204FF 0000E408
	v_or_b32_e32 v2, 0x64006400, v7                            // 000000DD6630: 38040EFF 64006400
	v_or_b32_e32 v4, 0x64006400, v53                           // 000000DD6638: 38086AFF 64006400
	.long 0xcc0f4080                                           // 000000DD6640: CC0F4080
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DD6644: 12020AFF 0000E408
	v_or_b32_e32 v5, 0x64006400, v49                           // 000000DD664C: 380A62FF 64006400
	scratch_store_b32 off, v1, off offset:468                  // 000000DD6654: DC6901D4 007C0100
	v_or_b32_e32 v1, 0x64006400, v6                            // 000000DD665C: 38020CFF 64006400
	.long 0xcc0f407d                                           // 000000DD6664: CC0F407D
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DD6668: 120204FF 0000E408
	v_or_b32_e32 v2, 0x64006400, v14                           // 000000DD6670: 38041CFF 64006400
	.long 0xcc0f4088                                           // 000000DD6678: CC0F4088
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DD667C: 120206FF 0000E408
	.long 0xcc0f4089                                           // 000000DD6684: CC0F4089
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DD6688: 120208FF 0000E408
	.long 0xcc0f407c                                           // 000000DD6690: CC0F407C
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DD6694: 120202FF 0000E408
	v_or_b32_e32 v1, 0x64006400, v12                           // 000000DD669C: 380218FF 64006400
	.long 0xcc0f4082                                           // 000000DD66A4: CC0F4082
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DD66A8: 120204FF 0000E408
	v_or_b32_e32 v2, 0x64006400, v40                           // 000000DD66B0: 380450FF 64006400
	v_or_b32_e32 v3, 0x64006400, v81                           // 000000DD66B8: 3806A2FF 64006400
	v_or_b32_e32 v4, 0x64006400, v77                           // 000000DD66C0: 38089AFF 64006400
	.long 0xcc0f4081                                           // 000000DD66C8: CC0F4081
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DD66CC: 120202FF 0000E408
	v_or_b32_e32 v1, 0x64006400, v37                           // 000000DD66D4: 38024AFF 64006400
	.long 0xcc0f4087                                           // 000000DD66DC: CC0F4087
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DD66E0: 120204FF 0000E408
	v_or_b32_e32 v2, 0x64006400, v70                           // 000000DD66E8: 38048CFF 64006400
	.long 0xcc0f4085                                           // 000000DD66F0: CC0F4085
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DD66F4: 12020AFF 0000E408
	v_or_b32_e32 v5, 0x64006400, v18                           // 000000DD66FC: 380A24FF 64006400
	.long 0xcc0f4086                                           // 000000DD6704: CC0F4086
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DD6708: 120202FF 0000E408
	v_or_b32_e32 v1, 0x64006400, v96                           // 000000DD6710: 3802C0FF 64006400
	.long 0xcc0f408c                                           // 000000DD6718: CC0F408C
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DD671C: 120204FF 0000E408
	.long 0xcc0f408d                                           // 000000DD6724: CC0F408D
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DD6728: 120206FF 0000E408
	.long 0xcc0f408e                                           // 000000DD6730: CC0F408E
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DD6734: 120208FF 0000E408
	v_or_b32_e32 v2, 0x64006400, v99                           // 000000DD673C: 3804C6FF 64006400
	.long 0xcc0f408b                                           // 000000DD6744: CC0F408B
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DD6748: 120202FF 0000E408
	v_or_b32_e32 v1, 0x64006400, v98                           // 000000DD6750: 3802C4FF 64006400
	v_or_b32_e32 v3, 0x64006400, v105                          // 000000DD6758: 3806D2FF 64006400
	v_or_b32_e32 v4, 0x64006400, v103                          // 000000DD6760: 3808CEFF 64006400
	.long 0xcc0f408a                                           // 000000DD6768: CC0F408A
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DD676C: 12020AFF 0000E408
	v_or_b32_e32 v5, 0x64006400, v78                           // 000000DD6774: 380A9CFF 64006400
	.long 0xcc0f4090                                           // 000000DD677C: CC0F4090
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DD6780: 120202FF 0000E408
	.long 0xcc0f4091                                           // 000000DD6788: CC0F4091
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DD678C: 120204FF 0000E408
	.long 0xcc0f4092                                           // 000000DD6794: CC0F4092
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DD6798: 120206FF 0000E408
	.long 0xcc0f4093                                           // 000000DD67A0: CC0F4093
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DD67A4: 120208FF 0000E408
	v_or_b32_e32 v1, 0x64006400, v240                          // 000000DD67AC: 3803E0FF 64006400
	v_or_b32_e32 v2, 0x64006400, v236                          // 000000DD67B4: 3805D8FF 64006400
	v_or_b32_e32 v3, 0x64006400, v239                          // 000000DD67BC: 3807DEFF 64006400
	v_or_b32_e32 v4, 0x64006400, v155                          // 000000DD67C4: 380936FF 64006400
	.long 0xcc0f408f                                           // 000000DD67CC: CC0F408F
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DD67D0: 12020AFF 0000E408
	v_or_b32_e32 v5, 0x64006400, v39                           // 000000DD67D8: 380A4EFF 64006400
	.long 0xcc0f4095                                           // 000000DD67E0: CC0F4095
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DD67E4: 120202FF 0000E408
	.long 0xcc0f4096                                           // 000000DD67EC: CC0F4096
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DD67F0: 120204FF 0000E408
	.long 0xcc0f4097                                           // 000000DD67F8: CC0F4097
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DD67FC: 120206FF 0000E408
	.long 0xcc0f4098                                           // 000000DD6804: CC0F4098
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DD6808: 120208FF 0000E408
	v_or_b32_e32 v1, 0x64006400, v247                          // 000000DD6810: 3803EEFF 64006400
	v_or_b32_e32 v2, 0x64006400, v246                          // 000000DD6818: 3805ECFF 64006400
	v_or_b32_e32 v3, 0x64006400, v245                          // 000000DD6820: 3807EAFF 64006400
	v_or_b32_e32 v4, 0x64006400, v242                          // 000000DD6828: 3809E4FF 64006400
	.long 0xcc0f4094                                           // 000000DD6830: CC0F4094
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DD6834: 12020AFF 0000E408
	v_or_b32_e32 v5, 0x64006400, v154                          // 000000DD683C: 380B34FF 64006400
	.long 0xcc0f409a                                           // 000000DD6844: CC0F409A
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DD6848: 120202FF 0000E408
	.long 0xcc0f409b                                           // 000000DD6850: CC0F409B
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DD6854: 120204FF 0000E408
	.long 0xcc0f409c                                           // 000000DD685C: CC0F409C
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DD6860: 120206FF 0000E408
	.long 0xcc0f409d                                           // 000000DD6868: CC0F409D
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DD686C: 120208FF 0000E408
	s_clause 0x3                                               // 000000DD6874: BF850003
	scratch_load_b32 v1, off, off offset:748                   // 000000DD6878: DC5102EC 017C0000
	scratch_load_b32 v2, off, off offset:752                   // 000000DD6880: DC5102F0 027C0000
	scratch_load_b32 v3, off, off offset:756                   // 000000DD6888: DC5102F4 037C0000
	scratch_load_b32 v4, off, off offset:760                   // 000000DD6890: DC5102F8 047C0000
	.long 0xcc0f4099                                           // 000000DD6898: CC0F4099
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DD689C: 12020AFF 0000E408
	v_or_b32_e32 v5, 0x64006400, v241                          // 000000DD68A4: 380BE2FF 64006400
	v_or_b32_e32 v39, 0x64006400, v24                          // 000000DD68AC: 384E30FF 64006400
	.long 0xcc0f4018                                           // 000000DD68B4: CC0F4018
	v_mul_i32_i24_e32 v1, 0xe408, v25                          // 000000DD68B8: 120232FF 0000E408
	v_or_b32_e32 v25, 0x64006400, v89                          // 000000DD68C0: 3832B2FF 64006400
	v_or_b32_e32 v40, 0x64006400, v38                          // 000000DD68C8: 38504CFF 64006400
	.long 0xcc0f409e                                           // 000000DD68D0: CC0F409E
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DD68D4: 12020AFF 0000E408
	scratch_load_b32 v5, off, off offset:764                   // 000000DD68DC: DC5102FC 057C0000
	.long 0xcc0f4026                                           // 000000DD68E4: CC0F4026
	v_mul_i32_i24_e32 v1, 0xe408, v26                          // 000000DD68E8: 120234FF 0000E408
	v_or_b32_e32 v26, 0x64006400, v90                          // 000000DD68F0: 3834B4FF 64006400
	v_or_b32_e32 v45, 0x64006400, v42                          // 000000DD68F8: 385A54FF 64006400
	v_or_b32_e32 v46, 0x64006400, v43                          // 000000DD6900: 385C56FF 64006400
	.long 0xcc0f4029                                           // 000000DD6908: CC0F4029
	v_mul_i32_i24_e32 v1, 0xe408, v25                          // 000000DD690C: 120232FF 0000E408
	v_or_b32_e32 v25, 0x64006400, v93                          // 000000DD6914: 3832BAFF 64006400
	.long 0xcc0f402a                                           // 000000DD691C: CC0F402A
	v_mul_i32_i24_e32 v1, 0xe408, v26                          // 000000DD6920: 120234FF 0000E408
	.long 0xcc0f402b                                           // 000000DD6928: CC0F402B
	v_mul_i32_i24_e32 v1, 0xe408, v44                          // 000000DD692C: 120258FF 0000E408
	.long 0xcc0f402c                                           // 000000DD6934: CC0F402C
	v_mul_i32_i24_e32 v1, 0xe408, v45                          // 000000DD6938: 12025AFF 0000E408
	.long 0xcc0f402d                                           // 000000DD6940: CC0F402D
	v_mul_i32_i24_e32 v1, 0xe408, v46                          // 000000DD6944: 12025CFF 0000E408
	v_or_b32_e32 v26, 0x64006400, v47                          // 000000DD694C: 38345EFF 64006400
	.long 0xcc0f402e                                           // 000000DD6954: CC0F402E
	v_mul_i32_i24_e32 v1, 0xe408, v25                          // 000000DD6958: 120232FF 0000E408
	v_or_b32_e32 v25, 0x64006400, v55                          // 000000DD6960: 38326EFF 64006400
	v_or_b32_e32 v55, 0x64006400, v51                          // 000000DD6968: 386E66FF 64006400
	v_or_b32_e32 v48, 0x64006400, v50                          // 000000DD6970: 386064FF 64006400
	.long 0xcc0f402f                                           // 000000DD6978: CC0F402F
	v_mul_i32_i24_e32 v1, 0xe408, v26                          // 000000DD697C: 120234FF 0000E408
	v_or_b32_e32 v26, 0x64006400, v65                          // 000000DD6984: 383482FF 64006400
	.long 0xcc0f4033                                           // 000000DD698C: CC0F4033
	v_mul_i32_i24_e32 v1, 0xe408, v25                          // 000000DD6990: 120232FF 0000E408
	v_or_b32_e32 v25, 0x64006400, v79                          // 000000DD6998: 38329EFF 64006400
	v_or_b32_e32 v50, 0x64006400, v54                          // 000000DD69A0: 38646CFF 64006400
	v_or_b32_e32 v54, 0x64006400, v59                          // 000000DD69A8: 386C76FF 64006400
	.long 0xcc0f4034                                           // 000000DD69B0: CC0F4034
	v_mul_i32_i24_e32 v1, 0xe408, v26                          // 000000DD69B4: 120234FF 0000E408
	v_or_b32_e32 v26, 0x64006400, v80                          // 000000DD69BC: 3834A0FF 64006400
	v_or_b32_e32 v59, 0x64006400, v56                          // 000000DD69C4: 387670FF 64006400
	.long 0xcc0f4038                                           // 000000DD69CC: CC0F4038
	v_mul_i32_i24_e32 v1, 0xe408, v25                          // 000000DD69D0: 120232FF 0000E408
	v_or_b32_e32 v25, 0x64006400, v76                          // 000000DD69D8: 383298FF 64006400
	v_or_b32_e32 v49, 0x64006400, v60                          // 000000DD69E0: 386278FF 64006400
	v_or_b32_e32 v53, 0x64006400, v58                          // 000000DD69E8: 386A74FF 64006400
	v_or_b32_e32 v58, 0x64006400, v64                          // 000000DD69F0: 387480FF 64006400
	v_or_b32_e32 v60, 0x64006400, v57                          // 000000DD69F8: 387872FF 64006400
	.long 0xcc0f4039                                           // 000000DD6A00: CC0F4039
	v_mul_i32_i24_e32 v1, 0xe408, v26                          // 000000DD6A04: 120234FF 0000E408
	v_or_b32_e32 v26, 0x64006400, v104                         // 000000DD6A0C: 3834D0FF 64006400
	v_or_b32_e32 v64, 0x64006400, v61                          // 000000DD6A14: 38807AFF 64006400
	.long 0xcc0f403d                                           // 000000DD6A1C: CC0F403D
	v_mul_i32_i24_e32 v1, 0xe408, v25                          // 000000DD6A20: 120232FF 0000E408
	v_or_b32_e32 v25, 0x64006400, v82                          // 000000DD6A28: 3832A4FF 64006400
	v_or_b32_e32 v65, 0x64006400, v62                          // 000000DD6A30: 38827CFF 64006400
	.long 0xcc0f403e                                           // 000000DD6A38: CC0F403E
	v_mul_i32_i24_e32 v1, 0xe408, v26                          // 000000DD6A3C: 120234FF 0000E408
	v_or_b32_e32 v26, 0x64006400, v66                          // 000000DD6A44: 383484FF 64006400
	v_or_b32_e32 v76, 0x64006400, v68                          // 000000DD6A4C: 389888FF 64006400
	.long 0xcc0f4042                                           // 000000DD6A54: CC0F4042
	v_mul_i32_i24_e32 v1, 0xe408, v25                          // 000000DD6A58: 120232FF 0000E408
	v_or_b32_e32 v25, 0x64006400, v75                          // 000000DD6A60: 383296FF 64006400
	v_or_b32_e32 v75, 0x64006400, v71                          // 000000DD6A68: 38968EFF 64006400
	v_or_b32_e32 v77, 0x64006400, v69                          // 000000DD6A70: 389A8AFF 64006400
	.long 0xcc0f4045                                           // 000000DD6A78: CC0F4045
	v_mul_i32_i24_e32 v1, 0xe408, v76                          // 000000DD6A7C: 120298FF 0000E408
	v_or_b32_e32 v70, 0x64006400, v63                          // 000000DD6A84: 388C7EFF 64006400
	.long 0xcc0f4047                                           // 000000DD6A8C: CC0F4047
	v_mul_i32_i24_e32 v1, 0xe408, v25                          // 000000DD6A90: 120232FF 0000E408
	v_or_b32_e32 v25, 0x64006400, v86                          // 000000DD6A98: 3832ACFF 64006400
	.long 0xcc0f403f                                           // 000000DD6AA0: CC0F403F
	v_mul_i32_i24_e32 v1, 0xe408, v64                          // 000000DD6AA4: 120280FF 0000E408
	.long 0xcc0f4040                                           // 000000DD6AAC: CC0F4040
	v_mul_i32_i24_e32 v1, 0xe408, v65                          // 000000DD6AB0: 120282FF 0000E408
	.long 0xcc0f4041                                           // 000000DD6AB8: CC0F4041
	v_mul_i32_i24_e32 v1, 0xe408, v70                          // 000000DD6ABC: 12028CFF 0000E408
	v_or_b32_e32 v70, 0x64006400, v67                          // 000000DD6AC4: 388C86FF 64006400
	.long 0xcc0f404c                                           // 000000DD6ACC: CC0F404C
	v_mul_i32_i24_e32 v1, 0xe408, v25                          // 000000DD6AD0: 120232FF 0000E408
	v_or_b32_e32 v25, 0x64006400, v116                         // 000000DD6AD8: 3832E8FF 64006400
	.long 0xcc0f4043                                           // 000000DD6AE0: CC0F4043
	v_mul_i32_i24_e32 v1, 0xe408, v26                          // 000000DD6AE4: 120234FF 0000E408
	v_or_b32_e32 v26, 0x64006400, v72                          // 000000DD6AEC: 383490FF 64006400
	.long 0xcc0f4044                                           // 000000DD6AF4: CC0F4044
	v_mul_i32_i24_e32 v1, 0xe408, v70                          // 000000DD6AF8: 12028CFF 0000E408
	.long 0xcc0f4046                                           // 000000DD6B00: CC0F4046
	v_mul_i32_i24_e32 v1, 0xe408, v77                          // 000000DD6B04: 12029AFF 0000E408
	.long 0xcc0f4051                                           // 000000DD6B0C: CC0F4051
	v_mul_i32_i24_e32 v1, 0xe408, v25                          // 000000DD6B10: 120232FF 0000E408
	v_or_b32_e32 v25, 0x64006400, v27                          // 000000DD6B18: 383236FF 64006400
	.long 0xcc0f4048                                           // 000000DD6B20: CC0F4048
	v_mul_i32_i24_e32 v1, 0xe408, v26                          // 000000DD6B24: 120234FF 0000E408
	v_or_b32_e32 v26, 0x64006400, v87                          // 000000DD6B2C: 3834AEFF 64006400
	v_or_b32_e32 v17, 0x64006400, v88                          // 000000DD6B34: 3822B0FF 64006400
	v_or_b32_e32 v11, 0x64006400, v35                          // 000000DD6B3C: 381646FF 64006400
	v_or_b32_e32 v12, 0x64006400, v97                          // 000000DD6B44: 3818C2FF 64006400
	v_or_b32_e32 v14, 0x64006400, v100                         // 000000DD6B4C: 381CC8FF 64006400
	.long 0xcc0f404d                                           // 000000DD6B54: CC0F404D
	v_mul_i32_i24_e32 v1, 0xe408, v26                          // 000000DD6B58: 120234FF 0000E408
	v_or_b32_e32 v26, 0x64006400, v115                         // 000000DD6B60: 3834E6FF 64006400
	.long 0xcc0f4025                                           // 000000DD6B68: CC0F4025
	v_mul_i32_i24_e32 v1, 0xe408, v11                          // 000000DD6B6C: 120216FF 0000E408
	v_or_b32_e32 v11, 0x64006400, v95                          // 000000DD6B74: 3816BEFF 64006400
	v_or_b32_e32 v18, 0x64006400, v108                         // 000000DD6B7C: 3824D8FF 64006400
	v_or_b32_e32 v78, 0x64006400, v85                          // 000000DD6B84: 389CAAFF 64006400
	.long 0xcc0f4052                                           // 000000DD6B8C: CC0F4052
	v_mul_i32_i24_e32 v1, 0xe408, v26                          // 000000DD6B90: 120234FF 0000E408
	v_or_b32_e32 v79, 0x64006400, v83                          // 000000DD6B98: 389EA6FF 64006400
	v_or_b32_e32 v80, 0x64006400, v84                          // 000000DD6BA0: 38A0A8FF 64006400
	v_or_b32_e32 v83, 0x64006400, v112                         // 000000DD6BA8: 38A6E0FF 64006400
	v_or_b32_e32 v84, 0x64006400, v113                         // 000000DD6BB0: 38A8E2FF 64006400
	v_or_b32_e32 v85, 0x64006400, v114                         // 000000DD6BB8: 38AAE4FF 64006400
	.long 0xcc0f400b                                           // 000000DD6BC0: CC0F400B
	v_mul_i32_i24_e32 v1, 0xe408, v11                          // 000000DD6BC4: 120216FF 0000E408
	.long 0xcc0f400c                                           // 000000DD6BCC: CC0F400C
	v_mul_i32_i24_e32 v1, 0xe408, v12                          // 000000DD6BD0: 120218FF 0000E408
	.long 0xcc0f400e                                           // 000000DD6BD8: CC0F400E
	v_mul_i32_i24_e32 v1, 0xe408, v14                          // 000000DD6BDC: 12021CFF 0000E408
	.long 0xcc0f4011                                           // 000000DD6BE4: CC0F4011
	v_mul_i32_i24_e32 v1, 0xe408, v17                          // 000000DD6BE8: 120222FF 0000E408
	.long 0xcc0f4012                                           // 000000DD6BF0: CC0F4012
	v_mul_i32_i24_e32 v1, 0xe408, v18                          // 000000DD6BF4: 120224FF 0000E408
	.long 0xcc0f4027                                           // 000000DD6BFC: CC0F4027
	v_mul_i32_i24_e32 v1, 0xe408, v39                          // 000000DD6C00: 12024EFF 0000E408
	.long 0xcc0f4028                                           // 000000DD6C08: CC0F4028
	v_mul_i32_i24_e32 v1, 0xe408, v40                          // 000000DD6C0C: 120250FF 0000E408
	.long 0xcc0f4030                                           // 000000DD6C14: CC0F4030
	v_mul_i32_i24_e32 v1, 0xe408, v48                          // 000000DD6C18: 120260FF 0000E408
	.long 0xcc0f4031                                           // 000000DD6C20: CC0F4031
	v_mul_i32_i24_e32 v1, 0xe408, v49                          // 000000DD6C24: 120262FF 0000E408
	.long 0xcc0f4032                                           // 000000DD6C2C: CC0F4032
	v_mul_i32_i24_e32 v1, 0xe408, v50                          // 000000DD6C30: 120264FF 0000E408
	.long 0xcc0f4035                                           // 000000DD6C38: CC0F4035
	v_mul_i32_i24_e32 v1, 0xe408, v53                          // 000000DD6C3C: 12026AFF 0000E408
	.long 0xcc0f4036                                           // 000000DD6C44: CC0F4036
	v_mul_i32_i24_e32 v1, 0xe408, v54                          // 000000DD6C48: 12026CFF 0000E408
	.long 0xcc0f4037                                           // 000000DD6C50: CC0F4037
	v_mul_i32_i24_e32 v1, 0xe408, v55                          // 000000DD6C54: 12026EFF 0000E408
	.long 0xcc0f403a                                           // 000000DD6C5C: CC0F403A
	v_mul_i32_i24_e32 v1, 0xe408, v58                          // 000000DD6C60: 120274FF 0000E408
	.long 0xcc0f403b                                           // 000000DD6C68: CC0F403B
	v_mul_i32_i24_e32 v1, 0xe408, v59                          // 000000DD6C6C: 120276FF 0000E408
	.long 0xcc0f403c                                           // 000000DD6C74: CC0F403C
	v_mul_i32_i24_e32 v1, 0xe408, v60                          // 000000DD6C78: 120278FF 0000E408
	.long 0xcc0f404b                                           // 000000DD6C80: CC0F404B
	v_mul_i32_i24_e32 v1, 0xe408, v75                          // 000000DD6C84: 120296FF 0000E408
	.long 0xcc0f404e                                           // 000000DD6C8C: CC0F404E
	v_mul_i32_i24_e32 v1, 0xe408, v78                          // 000000DD6C90: 12029CFF 0000E408
	.long 0xcc0f404f                                           // 000000DD6C98: CC0F404F
	v_mul_i32_i24_e32 v1, 0xe408, v79                          // 000000DD6C9C: 12029EFF 0000E408
	.long 0xcc0f4050                                           // 000000DD6CA4: CC0F4050
	v_mul_i32_i24_e32 v1, 0xe408, v80                          // 000000DD6CA8: 1202A0FF 0000E408
	.long 0xcc0f4053                                           // 000000DD6CB0: CC0F4053
	v_mul_i32_i24_e32 v1, 0xe408, v83                          // 000000DD6CB4: 1202A6FF 0000E408
	.long 0xcc0f4054                                           // 000000DD6CBC: CC0F4054
	v_mul_i32_i24_e32 v1, 0xe408, v84                          // 000000DD6CC0: 1202A8FF 0000E408
	.long 0xcc0f4055                                           // 000000DD6CC8: CC0F4055
	v_mul_i32_i24_e32 v1, 0xe408, v85                          // 000000DD6CCC: 1202AAFF 0000E408
	.long 0xcc0f4056                                           // 000000DD6CD4: CC0F4056
	v_mul_i32_i24_e32 v1, 0xe408, v25                          // 000000DD6CD8: 120232FF 0000E408
	s_clause 0x1                                               // 000000DD6CE0: BF850001
	scratch_load_b32 v27, off, off offset:856                  // 000000DD6CE4: DC510358 1B7C0000
	scratch_load_b32 v26, off, off offset:852                  // 000000DD6CEC: DC510354 1A7C0000
	s_waitcnt vmcnt(6)                                         // 000000DD6CF4: BF891BF7
	v_or_b32_e32 v1, 0x64006400, v1                            // 000000DD6CF8: 380202FF 64006400
	s_waitcnt vmcnt(5)                                         // 000000DD6D00: BF8917F7
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DD6D04: 380404FF 64006400
	s_waitcnt vmcnt(4)                                         // 000000DD6D0C: BF8913F7
	v_or_b32_e32 v3, 0x64006400, v3                            // 000000DD6D10: 380606FF 64006400
	s_waitcnt vmcnt(3)                                         // 000000DD6D18: BF890FF7
	v_or_b32_e32 v4, 0x64006400, v4                            // 000000DD6D1C: 380808FF 64006400
	.long 0xcc0f409f                                           // 000000DD6D24: CC0F409F
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DD6D28: 120202FF 0000E408
	.long 0xcc0f40a0                                           // 000000DD6D30: CC0F40A0
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DD6D34: 120204FF 0000E408
	.long 0xcc0f40a1                                           // 000000DD6D3C: CC0F40A1
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DD6D40: 120206FF 0000E408
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DD6D48: BF870004
	.long 0xcc0f40a2                                           // 000000DD6D4C: CC0F40A2
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DD6D50: 120208FF 0000E408
	s_clause 0x3                                               // 000000DD6D58: BF850003
	scratch_load_b32 v1, off, off offset:728                   // 000000DD6D5C: DC5102D8 017C0000
	scratch_load_b32 v2, off, off offset:732                   // 000000DD6D64: DC5102DC 027C0000
	scratch_load_b32 v3, off, off offset:736                   // 000000DD6D6C: DC5102E0 037C0000
	scratch_load_b32 v4, off, off offset:740                   // 000000DD6D74: DC5102E4 047C0000
	s_waitcnt vmcnt(6)                                         // 000000DD6D7C: BF891BF7
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000DD6D80: 380A0AFF 64006400
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DD6D88: BF870001
	.long 0xcc0f40a3                                           // 000000DD6D8C: CC0F40A3
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DD6D90: 12020AFF 0000E408
	scratch_load_b32 v5, off, off offset:744                   // 000000DD6D98: DC5102E8 057C0000
	s_waitcnt vmcnt(6)                                         // 000000DD6DA0: BF891BF7
	v_or_b32_e32 v88, 0x64006400, v27                          // 000000DD6DA4: 38B036FF 64006400
	s_waitcnt vmcnt(5)                                         // 000000DD6DAC: BF8917F7
	v_or_b32_e32 v26, 0x64006400, v26                          // 000000DD6DB0: 383434FF 64006400
	scratch_load_b32 v27, off, off offset:860                  // 000000DD6DB8: DC51035C 1B7C0000
	.long 0xcc0f4058                                           // 000000DD6DC0: CC0F4058
	v_mul_i32_i24_e32 v1, 0xe408, v88                          // 000000DD6DC4: 1202B0FF 0000E408
	.long 0xcc0f4057                                           // 000000DD6DCC: CC0F4057
	v_mul_i32_i24_e32 v1, 0xe408, v26                          // 000000DD6DD0: 120234FF 0000E408
	s_waitcnt vmcnt(5)                                         // 000000DD6DD8: BF8917F7
	v_or_b32_e32 v1, 0x64006400, v1                            // 000000DD6DDC: 380202FF 64006400
	s_waitcnt vmcnt(4)                                         // 000000DD6DE4: BF8913F7
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DD6DE8: 380404FF 64006400
	s_waitcnt vmcnt(3)                                         // 000000DD6DF0: BF890FF7
	v_or_b32_e32 v3, 0x64006400, v3                            // 000000DD6DF4: 380606FF 64006400
	s_waitcnt vmcnt(2)                                         // 000000DD6DFC: BF890BF7
	v_or_b32_e32 v4, 0x64006400, v4                            // 000000DD6E00: 380808FF 64006400
	.long 0xcc0f40a4                                           // 000000DD6E08: CC0F40A4
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DD6E0C: 120202FF 0000E408
	.long 0xcc0f40a5                                           // 000000DD6E14: CC0F40A5
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DD6E18: 120204FF 0000E408
	.long 0xcc0f40a6                                           // 000000DD6E20: CC0F40A6
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DD6E24: 120206FF 0000E408
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DD6E2C: BF870004
	.long 0xcc0f40a7                                           // 000000DD6E30: CC0F40A7
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DD6E34: 120208FF 0000E408
	s_clause 0x3                                               // 000000DD6E3C: BF850003
	scratch_load_b32 v1, off, off offset:644                   // 000000DD6E40: DC510284 017C0000
	scratch_load_b32 v2, off, off offset:648                   // 000000DD6E48: DC510288 027C0000
	scratch_load_b32 v3, off, off offset:652                   // 000000DD6E50: DC51028C 037C0000
	scratch_load_b32 v4, off, off offset:656                   // 000000DD6E58: DC510290 047C0000
	s_waitcnt vmcnt(5)                                         // 000000DD6E60: BF8917F7
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000DD6E64: 380A0AFF 64006400
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DD6E6C: BF870001
	.long 0xcc0f40a8                                           // 000000DD6E70: CC0F40A8
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DD6E74: 12020AFF 0000E408
	scratch_load_b32 v5, off, off offset:660                   // 000000DD6E7C: DC510294 057C0000
	s_waitcnt vmcnt(5)                                         // 000000DD6E84: BF8917F7
	v_or_b32_e32 v89, 0x64006400, v27                          // 000000DD6E88: 38B236FF 64006400
	scratch_load_b32 v27, off, off offset:864                  // 000000DD6E90: DC510360 1B7C0000
	.long 0xcc0f4059                                           // 000000DD6E98: CC0F4059
	v_mul_i32_i24_e32 v1, 0xe408, v89                          // 000000DD6E9C: 1202B2FF 0000E408
	s_waitcnt vmcnt(5)                                         // 000000DD6EA4: BF8917F7
	v_or_b32_e32 v1, 0x64006400, v1                            // 000000DD6EA8: 380202FF 64006400
	s_waitcnt vmcnt(4)                                         // 000000DD6EB0: BF8913F7
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DD6EB4: 380404FF 64006400
	s_waitcnt vmcnt(3)                                         // 000000DD6EBC: BF890FF7
	v_or_b32_e32 v3, 0x64006400, v3                            // 000000DD6EC0: 380606FF 64006400
	s_waitcnt vmcnt(2)                                         // 000000DD6EC8: BF890BF7
	v_or_b32_e32 v4, 0x64006400, v4                            // 000000DD6ECC: 380808FF 64006400
	.long 0xcc0f40a9                                           // 000000DD6ED4: CC0F40A9
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DD6ED8: 120202FF 0000E408
	.long 0xcc0f40aa                                           // 000000DD6EE0: CC0F40AA
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DD6EE4: 120204FF 0000E408
	.long 0xcc0f40ab                                           // 000000DD6EEC: CC0F40AB
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DD6EF0: 120206FF 0000E408
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DD6EF8: BF870004
	.long 0xcc0f40ac                                           // 000000DD6EFC: CC0F40AC
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DD6F00: 120208FF 0000E408
	s_clause 0x3                                               // 000000DD6F08: BF850003
	scratch_load_b32 v1, off, off offset:544                   // 000000DD6F0C: DC510220 017C0000
	scratch_load_b32 v2, off, off offset:548                   // 000000DD6F14: DC510224 027C0000
	scratch_load_b32 v3, off, off offset:552                   // 000000DD6F1C: DC510228 037C0000
	scratch_load_b32 v4, off, off offset:556                   // 000000DD6F24: DC51022C 047C0000
	s_waitcnt vmcnt(5)                                         // 000000DD6F2C: BF8917F7
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000DD6F30: 380A0AFF 64006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000DD6F38: BF8700C1
	.long 0xcc0f40ad                                           // 000000DD6F3C: CC0F40AD
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DD6F40: 12020AFF 0000E408
	scratch_load_b32 v5, off, off offset:560                   // 000000DD6F48: DC510230 057C0000
	s_waitcnt vmcnt(5)                                         // 000000DD6F50: BF8917F7
	v_or_b32_e32 v90, 0x64006400, v27                          // 000000DD6F54: 38B436FF 64006400
	.long 0xcc0f405a                                           // 000000DD6F5C: CC0F405A
	v_mul_i32_i24_e32 v1, 0xe408, v90                          // 000000DD6F60: 1202B4FF 0000E408
	s_waitcnt vmcnt(4)                                         // 000000DD6F68: BF8913F7
	v_or_b32_e32 v1, 0x64006400, v1                            // 000000DD6F6C: 380202FF 64006400
	s_waitcnt vmcnt(3)                                         // 000000DD6F74: BF890FF7
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DD6F78: 380404FF 64006400
	s_waitcnt vmcnt(2)                                         // 000000DD6F80: BF890BF7
	v_or_b32_e32 v3, 0x64006400, v3                            // 000000DD6F84: 380606FF 64006400
	s_waitcnt vmcnt(1)                                         // 000000DD6F8C: BF8907F7
	v_or_b32_e32 v4, 0x64006400, v4                            // 000000DD6F90: 380808FF 64006400
	.long 0xcc0f40ae                                           // 000000DD6F98: CC0F40AE
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DD6F9C: 120202FF 0000E408
	.long 0xcc0f40af                                           // 000000DD6FA4: CC0F40AF
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DD6FA8: 120204FF 0000E408
	.long 0xcc0f40b0                                           // 000000DD6FB0: CC0F40B0
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DD6FB4: 120206FF 0000E408
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DD6FBC: BF870004
	.long 0xcc0f40b1                                           // 000000DD6FC0: CC0F40B1
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DD6FC4: 120208FF 0000E408
	s_clause 0x3                                               // 000000DD6FCC: BF850003
	scratch_load_b32 v1, off, off offset:484                   // 000000DD6FD0: DC5101E4 017C0000
	scratch_load_b32 v2, off, off offset:488                   // 000000DD6FD8: DC5101E8 027C0000
	scratch_load_b32 v3, off, off offset:492                   // 000000DD6FE0: DC5101EC 037C0000
	scratch_load_b32 v4, off, off offset:496                   // 000000DD6FE8: DC5101F0 047C0000
	s_waitcnt vmcnt(4)                                         // 000000DD6FF0: BF8913F7
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000DD6FF4: 380A0AFF 64006400
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DD6FFC: BF870001
	.long 0xcc0f40b2                                           // 000000DD7000: CC0F40B2
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DD7004: 12020AFF 0000E408
	scratch_load_b32 v5, off, off offset:500                   // 000000DD700C: DC5101F4 057C0000
	s_waitcnt vmcnt(4)                                         // 000000DD7014: BF8913F7
	v_or_b32_e32 v1, 0x64006400, v1                            // 000000DD7018: 380202FF 64006400
	s_waitcnt vmcnt(3)                                         // 000000DD7020: BF890FF7
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DD7024: 380404FF 64006400
	s_waitcnt vmcnt(2)                                         // 000000DD702C: BF890BF7
	v_or_b32_e32 v3, 0x64006400, v3                            // 000000DD7030: 380606FF 64006400
	s_waitcnt vmcnt(1)                                         // 000000DD7038: BF8907F7
	v_or_b32_e32 v4, 0x64006400, v4                            // 000000DD703C: 380808FF 64006400
	.long 0xcc0f40b3                                           // 000000DD7044: CC0F40B3
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DD7048: 120202FF 0000E408
	.long 0xcc0f40b4                                           // 000000DD7050: CC0F40B4
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DD7054: 120204FF 0000E408
	.long 0xcc0f40b5                                           // 000000DD705C: CC0F40B5
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DD7060: 120206FF 0000E408
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DD7068: BF870004
	.long 0xcc0f40b6                                           // 000000DD706C: CC0F40B6
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DD7070: 120208FF 0000E408
	s_clause 0x3                                               // 000000DD7078: BF850003
	scratch_load_b32 v1, off, off offset:504                   // 000000DD707C: DC5101F8 017C0000
	scratch_load_b32 v2, off, off offset:508                   // 000000DD7084: DC5101FC 027C0000
	scratch_load_b32 v3, off, off offset:512                   // 000000DD708C: DC510200 037C0000
	scratch_load_b32 v4, off, off offset:516                   // 000000DD7094: DC510204 047C0000
	s_waitcnt vmcnt(4)                                         // 000000DD709C: BF8913F7
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000DD70A0: 380A0AFF 64006400
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DD70A8: BF870001
	.long 0xcc0f40b7                                           // 000000DD70AC: CC0F40B7
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DD70B0: 12020AFF 0000E408
	scratch_load_b32 v5, off, off offset:564                   // 000000DD70B8: DC510234 057C0000
	s_waitcnt vmcnt(4)                                         // 000000DD70C0: BF8913F7
	v_or_b32_e32 v1, 0x64006400, v1                            // 000000DD70C4: 380202FF 64006400
	s_waitcnt vmcnt(3)                                         // 000000DD70CC: BF890FF7
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DD70D0: 380404FF 64006400
	s_waitcnt vmcnt(2)                                         // 000000DD70D8: BF890BF7
	v_or_b32_e32 v3, 0x64006400, v3                            // 000000DD70DC: 380606FF 64006400
	s_waitcnt vmcnt(1)                                         // 000000DD70E4: BF8907F7
	v_or_b32_e32 v4, 0x64006400, v4                            // 000000DD70E8: 380808FF 64006400
	.long 0xcc0f40b8                                           // 000000DD70F0: CC0F40B8
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DD70F4: 120202FF 0000E408
	.long 0xcc0f40b9                                           // 000000DD70FC: CC0F40B9
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DD7100: 120204FF 0000E408
	.long 0xcc0f40ba                                           // 000000DD7108: CC0F40BA
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DD710C: 120206FF 0000E408
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DD7114: BF870004
	.long 0xcc0f40bb                                           // 000000DD7118: CC0F40BB
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DD711C: 120208FF 0000E408
	s_clause 0x3                                               // 000000DD7124: BF850003
	scratch_load_b32 v1, off, off offset:520                   // 000000DD7128: DC510208 017C0000
	scratch_load_b32 v2, off, off offset:524                   // 000000DD7130: DC51020C 027C0000
	scratch_load_b32 v3, off, off offset:528                   // 000000DD7138: DC510210 037C0000
	scratch_load_b32 v4, off, off offset:568                   // 000000DD7140: DC510238 047C0000
	s_waitcnt vmcnt(4)                                         // 000000DD7148: BF8913F7
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000DD714C: 380A0AFF 64006400
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DD7154: BF870001
	.long 0xcc0f40bc                                           // 000000DD7158: CC0F40BC
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DD715C: 12020AFF 0000E408
	scratch_load_b32 v5, off, off offset:572                   // 000000DD7164: DC51023C 057C0000
	s_waitcnt vmcnt(4)                                         // 000000DD716C: BF8913F7
	v_or_b32_e32 v1, 0x64006400, v1                            // 000000DD7170: 380202FF 64006400
	s_waitcnt vmcnt(3)                                         // 000000DD7178: BF890FF7
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DD717C: 380404FF 64006400
	s_waitcnt vmcnt(2)                                         // 000000DD7184: BF890BF7
	v_or_b32_e32 v3, 0x64006400, v3                            // 000000DD7188: 380606FF 64006400
	s_waitcnt vmcnt(1)                                         // 000000DD7190: BF8907F7
	v_or_b32_e32 v4, 0x64006400, v4                            // 000000DD7194: 380808FF 64006400
	.long 0xcc0f40bd                                           // 000000DD719C: CC0F40BD
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DD71A0: 120202FF 0000E408
	.long 0xcc0f40be                                           // 000000DD71A8: CC0F40BE
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DD71AC: 120204FF 0000E408
	scratch_load_b32 v1, off, off offset:532                   // 000000DD71B4: DC510214 017C0000
	.long 0xcc0f40c0                                           // 000000DD71BC: CC0F40C0
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DD71C0: 120208FF 0000E408
	s_clause 0x1                                               // 000000DD71C8: BF850001
	scratch_load_b32 v4, off, off offset:580                   // 000000DD71CC: DC510244 047C0000
	scratch_load_b32 v2, off, off offset:536                   // 000000DD71D4: DC510218 027C0000
	s_waitcnt vmcnt(3)                                         // 000000DD71DC: BF890FF7
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000DD71E0: 380A0AFF 64006400
	.long 0xcc0f40bf                                           // 000000DD71E8: CC0F40BF
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DD71EC: 120206FF 0000E408
	scratch_load_b32 v3, off, off offset:576                   // 000000DD71F4: DC510240 037C0000
	.long 0xcc0f40c1                                           // 000000DD71FC: CC0F40C1
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DD7200: 12020AFF 0000E408
	scratch_load_b32 v5, off, off offset:584                   // 000000DD7208: DC510248 057C0000
	s_waitcnt vmcnt(4)                                         // 000000DD7210: BF8913F7
	v_or_b32_e32 v1, 0x64006400, v1                            // 000000DD7214: 380202FF 64006400
	s_waitcnt vmcnt(3)                                         // 000000DD721C: BF890FF7
	v_or_b32_e32 v4, 0x64006400, v4                            // 000000DD7220: 380808FF 64006400
	s_waitcnt vmcnt(2)                                         // 000000DD7228: BF890BF7
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DD722C: 380404FF 64006400
	.long 0xcc0f40c2                                           // 000000DD7234: CC0F40C2
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DD7238: 120202FF 0000E408
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DD7240: BF870193
	.long 0xcc0f40c5                                           // 000000DD7244: CC0F40C5
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DD7248: 120208FF 0000E408
	.long 0xcc0f40c3                                           // 000000DD7250: CC0F40C3
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DD7254: 120204FF 0000E408
	s_clause 0x2                                               // 000000DD725C: BF850002
	scratch_load_b32 v2, off, off offset:588                   // 000000DD7260: DC51024C 027C0000
	scratch_load_b32 v4, off, off offset:596                   // 000000DD7268: DC510254 047C0000
	scratch_load_b32 v1, off, off offset:540                   // 000000DD7270: DC51021C 017C0000
	s_waitcnt vmcnt(4)                                         // 000000DD7278: BF8913F7
	v_or_b32_e32 v3, 0x64006400, v3                            // 000000DD727C: 380606FF 64006400
	s_waitcnt vmcnt(3)                                         // 000000DD7284: BF890FF7
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000DD7288: 380A0AFF 64006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DD7290: BF870112
	.long 0xcc0f40c4                                           // 000000DD7294: CC0F40C4
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DD7298: 120206FF 0000E408
	.long 0xcc0f40c6                                           // 000000DD72A0: CC0F40C6
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DD72A4: 12020AFF 0000E408
	s_clause 0x1                                               // 000000DD72AC: BF850001
	scratch_load_b32 v3, off, off offset:592                   // 000000DD72B0: DC510250 037C0000
	scratch_load_b32 v5, off, off offset:600                   // 000000DD72B8: DC510258 057C0000
	s_waitcnt vmcnt(4)                                         // 000000DD72C0: BF8913F7
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DD72C4: 380404FF 64006400
	s_waitcnt vmcnt(3)                                         // 000000DD72CC: BF890FF7
	v_or_b32_e32 v4, 0x64006400, v4                            // 000000DD72D0: 380808FF 64006400
	s_waitcnt vmcnt(2)                                         // 000000DD72D8: BF890BF7
	v_or_b32_e32 v1, 0x64006400, v1                            // 000000DD72DC: 380202FF 64006400
	.long 0xcc0f40c8                                           // 000000DD72E4: CC0F40C8
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DD72E8: 120204FF 0000E408
	scratch_load_b32 v2, off, off offset:608                   // 000000DD72F0: DC510260 027C0000
	.long 0xcc0f40c7                                           // 000000DD72F8: CC0F40C7
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DD72FC: 120202FF 0000E408
	scratch_load_b32 v1, off, off offset:604                   // 000000DD7304: DC51025C 017C0000
	.long 0xcc0f40ca                                           // 000000DD730C: CC0F40CA
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DD7310: 120208FF 0000E408
	scratch_load_b32 v4, off, off offset:616                   // 000000DD7318: DC510268 047C0000
	s_waitcnt vmcnt(4)                                         // 000000DD7320: BF8913F7
	v_or_b32_e32 v3, 0x64006400, v3                            // 000000DD7324: 380606FF 64006400
	s_waitcnt vmcnt(3)                                         // 000000DD732C: BF890FF7
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000DD7330: 380A0AFF 64006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DD7338: BF870112
	.long 0xcc0f40c9                                           // 000000DD733C: CC0F40C9
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DD7340: 120206FF 0000E408
	.long 0xcc0f40cb                                           // 000000DD7348: CC0F40CB
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DD734C: 12020AFF 0000E408
	s_clause 0x1                                               // 000000DD7354: BF850001
	scratch_load_b32 v3, off, off offset:612                   // 000000DD7358: DC510264 037C0000
	scratch_load_b32 v5, off, off offset:664                   // 000000DD7360: DC510298 057C0000
	s_waitcnt vmcnt(4)                                         // 000000DD7368: BF8913F7
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DD736C: 380404FF 64006400
	s_waitcnt vmcnt(3)                                         // 000000DD7374: BF890FF7
	v_or_b32_e32 v1, 0x64006400, v1                            // 000000DD7378: 380202FF 64006400
	s_waitcnt vmcnt(2)                                         // 000000DD7380: BF890BF7
	v_or_b32_e32 v4, 0x64006400, v4                            // 000000DD7384: 380808FF 64006400
	.long 0xcc0f40cd                                           // 000000DD738C: CC0F40CD
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DD7390: 120204FF 0000E408
	scratch_load_b32 v2, off, off offset:624                   // 000000DD7398: DC510270 027C0000
	.long 0xcc0f40cc                                           // 000000DD73A0: CC0F40CC
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DD73A4: 120202FF 0000E408
	scratch_load_b32 v1, off, off offset:620                   // 000000DD73AC: DC51026C 017C0000
	.long 0xcc0f40cf                                           // 000000DD73B4: CC0F40CF
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DD73B8: 120208FF 0000E408
	scratch_load_b32 v4, off, off offset:668                   // 000000DD73C0: DC51029C 047C0000
	s_waitcnt vmcnt(4)                                         // 000000DD73C8: BF8913F7
	v_or_b32_e32 v3, 0x64006400, v3                            // 000000DD73CC: 380606FF 64006400
	s_waitcnt vmcnt(3)                                         // 000000DD73D4: BF890FF7
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000DD73D8: 380A0AFF 64006400
	s_delay_alu instid0(VALU_DEP_2)                            // 000000DD73E0: BF870002
	.long 0xcc0f40ce                                           // 000000DD73E4: CC0F40CE
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DD73E8: 120206FF 0000E408
	scratch_load_b32 v3, off, off offset:628                   // 000000DD73F0: DC510274 037C0000
	.long 0xcc0f40d0                                           // 000000DD73F8: CC0F40D0
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DD73FC: 12020AFF 0000E408
	scratch_load_b32 v5, off, off offset:672                   // 000000DD7404: DC5102A0 057C0000
	s_waitcnt vmcnt(4)                                         // 000000DD740C: BF8913F7
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DD7410: 380404FF 64006400
	s_waitcnt vmcnt(3)                                         // 000000DD7418: BF890FF7
	v_or_b32_e32 v1, 0x64006400, v1                            // 000000DD741C: 380202FF 64006400
	s_delay_alu instid0(VALU_DEP_2)                            // 000000DD7424: BF870002
	.long 0xcc0f40d2                                           // 000000DD7428: CC0F40D2
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DD742C: 120204FF 0000E408
	scratch_load_b32 v2, off, off offset:636                   // 000000DD7434: DC51027C 027C0000
	.long 0xcc0f40d1                                           // 000000DD743C: CC0F40D1
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DD7440: 120202FF 0000E408
	scratch_load_b32 v1, off, off offset:632                   // 000000DD7448: DC510278 017C0000
	s_waitcnt vmcnt(4)                                         // 000000DD7450: BF8913F7
	v_or_b32_e32 v4, 0x64006400, v4                            // 000000DD7454: 380808FF 64006400
	s_waitcnt vmcnt(3)                                         // 000000DD745C: BF890FF7
	v_or_b32_e32 v3, 0x64006400, v3                            // 000000DD7460: 380606FF 64006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DD7468: BF8701A2
	.long 0xcc0f40d4                                           // 000000DD746C: CC0F40D4
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DD7470: 120208FF 0000E408
	v_or_b32_e32 v4, 0x64006400, v232                          // 000000DD7478: 3809D0FF 64006400
	.long 0xcc0f40d3                                           // 000000DD7480: CC0F40D3
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DD7484: 120206FF 0000E408
	v_or_b32_e32 v3, 0x64006400, v233                          // 000000DD748C: 3807D2FF 64006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000DD7494: BF8700C3
	.long 0xcc0f40d9                                           // 000000DD7498: CC0F40D9
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DD749C: 120208FF 0000E408
	scratch_load_b32 v4, off, off offset:684                   // 000000DD74A4: DC5102AC 047C0000
	.long 0xcc0f40d8                                           // 000000DD74AC: CC0F40D8
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DD74B0: 120206FF 0000E408
	v_or_b32_e32 v3, 0x64006400, v231                          // 000000DD74B8: 3807CEFF 64006400
	.long 0xcc0f40dd                                           // 000000DD74C0: CC0F40DD
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DD74C4: 120206FF 0000E408
	scratch_load_b32 v3, off, off offset:696                   // 000000DD74CC: DC5102B8 037C0000
	s_waitcnt vmcnt(3)                                         // 000000DD74D4: BF890FF7
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DD74D8: 380404FF 64006400
	s_waitcnt vmcnt(2)                                         // 000000DD74E0: BF890BF7
	v_or_b32_e32 v1, 0x64006400, v1                            // 000000DD74E4: 380202FF 64006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000DD74EC: BF8700D2
	.long 0xcc0f40d7                                           // 000000DD74F0: CC0F40D7
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DD74F4: 120204FF 0000E408
	scratch_load_b32 v2, off, off offset:680                   // 000000DD74FC: DC5102A8 027C0000
	.long 0xcc0f40d6                                           // 000000DD7504: CC0F40D6
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DD7508: 120202FF 0000E408
	scratch_load_b32 v1, off, off offset:640                   // 000000DD7510: DC510280 017C0000
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000DD7518: 380A0AFF 64006400
	.long 0xcc0f40d5                                           // 000000DD7520: CC0F40D5
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DD7524: 12020AFF 0000E408
	scratch_load_b32 v5, off, off offset:676                   // 000000DD752C: DC5102A4 057C0000
	s_waitcnt vmcnt(3)                                         // 000000DD7534: BF890FF7
	v_or_b32_e32 v3, 0x64006400, v3                            // 000000DD7538: 380606FF 64006400
	s_waitcnt vmcnt(2)                                         // 000000DD7540: BF890BF7
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DD7544: 380404FF 64006400
	s_waitcnt vmcnt(1)                                         // 000000DD754C: BF8907F7
	v_or_b32_e32 v1, 0x64006400, v1                            // 000000DD7550: 380202FF 64006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000DD7558: BF8700C2
	.long 0xcc0f40dc                                           // 000000DD755C: CC0F40DC
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DD7560: 120204FF 0000E408
	scratch_load_b32 v2, off, off offset:692                   // 000000DD7568: DC5102B4 027C0000
	.long 0xcc0f40db                                           // 000000DD7570: CC0F40DB
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DD7574: 120202FF 0000E408
	v_or_b32_e32 v1, 0x64006400, v228                          // 000000DD757C: 3803C8FF 64006400
	.long 0xcc0f40e0                                           // 000000DD7584: CC0F40E0
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DD7588: 120202FF 0000E408
	scratch_load_b32 v1, off, off offset:704                   // 000000DD7590: DC5102C0 017C0000
	s_waitcnt vmcnt(2)                                         // 000000DD7598: BF890BF7
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000DD759C: 380A0AFF 64006400
	v_or_b32_e32 v4, 0x64006400, v4                            // 000000DD75A4: 380808FF 64006400
	s_delay_alu instid0(VALU_DEP_2)                            // 000000DD75AC: BF870002
	.long 0xcc0f40da                                           // 000000DD75B0: CC0F40DA
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DD75B4: 12020AFF 0000E408
	scratch_load_b32 v5, off, off offset:688                   // 000000DD75BC: DC5102B0 057C0000
	.long 0xcc0f40de                                           // 000000DD75C4: CC0F40DE
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DD75C8: 120208FF 0000E408
	scratch_load_b32 v4, off, off offset:700                   // 000000DD75D0: DC5102BC 047C0000
	s_waitcnt vmcnt(3)                                         // 000000DD75D8: BF890FF7
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DD75DC: 380404FF 64006400
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DD75E4: BF870001
	.long 0xcc0f40e1                                           // 000000DD75E8: CC0F40E1
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DD75EC: 120204FF 0000E408
	scratch_load_b32 v2, off, off offset:708                   // 000000DD75F4: DC5102C4 027C0000
	s_waitcnt vmcnt(3)                                         // 000000DD75FC: BF890FF7
	v_or_b32_e32 v1, 0x64006400, v1                            // 000000DD7600: 380202FF 64006400
	s_waitcnt vmcnt(2)                                         // 000000DD7608: BF890BF7
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000DD760C: 380A0AFF 64006400
	s_waitcnt vmcnt(1)                                         // 000000DD7614: BF8907F7
	v_or_b32_e32 v4, 0x64006400, v4                            // 000000DD7618: 380808FF 64006400
	s_delay_alu instid0(VALU_DEP_2)                            // 000000DD7620: BF870002
	.long 0xcc0f40df                                           // 000000DD7624: CC0F40DF
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DD7628: 12020AFF 0000E408
	v_or_b32_e32 v5, 0x64006400, v226                          // 000000DD7630: 380BC4FF 64006400
	.long 0xcc0f40e2                                           // 000000DD7638: CC0F40E2
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DD763C: 120206FF 0000E408
	scratch_load_b32 v3, off, off offset:712                   // 000000DD7644: DC5102C8 037C0000
	.long 0xcc0f40e3                                           // 000000DD764C: CC0F40E3
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DD7650: 120208FF 0000E408
	v_or_b32_e32 v4, 0x64006400, v230                          // 000000DD7658: 3809CCFF 64006400
	.long 0xcc0f40e4                                           // 000000DD7660: CC0F40E4
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DD7664: 12020AFF 0000E408
	v_or_b32_e32 v5, 0x64006400, v229                          // 000000DD766C: 380BCAFF 64006400
	.long 0xcc0f40e5                                           // 000000DD7674: CC0F40E5
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DD7678: 120202FF 0000E408
	scratch_load_b32 v1, off, off offset:716                   // 000000DD7680: DC5102CC 017C0000
	.long 0xcc0f40e8                                           // 000000DD7688: CC0F40E8
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DD768C: 120208FF 0000E408
	v_or_b32_e32 v4, 0x64006400, v235                          // 000000DD7694: 3809D6FF 64006400
	.long 0xcc0f40e9                                           // 000000DD769C: CC0F40E9
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DD76A0: 12020AFF 0000E408
	scratch_load_b32 v5, off, off offset:768                   // 000000DD76A8: DC510300 057C0000
	.long 0xcc0f40ed                                           // 000000DD76B0: CC0F40ED
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DD76B4: 120208FF 0000E408
	scratch_load_b32 v4, off, off offset:780                   // 000000DD76BC: DC51030C 047C0000
	s_waitcnt vmcnt(4)                                         // 000000DD76C4: BF8913F7
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DD76C8: 380404FF 64006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000DD76D0: BF8700C1
	.long 0xcc0f40e6                                           // 000000DD76D4: CC0F40E6
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DD76D8: 120204FF 0000E408
	scratch_load_b32 v2, off, off offset:720                   // 000000DD76E0: DC5102D0 027C0000
	s_waitcnt vmcnt(4)                                         // 000000DD76E8: BF8913F7
	v_or_b32_e32 v3, 0x64006400, v3                            // 000000DD76EC: 380606FF 64006400
	.long 0xcc0f40e7                                           // 000000DD76F4: CC0F40E7
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DD76F8: 120206FF 0000E408
	s_waitcnt vmcnt(3)                                         // 000000DD7700: BF890FF7
	v_or_b32_e32 v1, 0x64006400, v1                            // 000000DD7704: 380202FF 64006400
	v_or_b32_e32 v3, 0x64006400, v234                          // 000000DD770C: 3807D4FF 64006400
	s_waitcnt vmcnt(2)                                         // 000000DD7714: BF890BF7
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000DD7718: 380A0AFF 64006400
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DD7720: BF870003
	.long 0xcc0f40ea                                           // 000000DD7724: CC0F40EA
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DD7728: 120202FF 0000E408
	scratch_load_b32 v1, off, off offset:724                   // 000000DD7730: DC5102D4 017C0000
	.long 0xcc0f40ec                                           // 000000DD7738: CC0F40EC
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DD773C: 120206FF 0000E408
	scratch_load_b32 v3, off, off offset:776                   // 000000DD7744: DC510308 037C0000
	.long 0xcc0f40ee                                           // 000000DD774C: CC0F40EE
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DD7750: 12020AFF 0000E408
	scratch_load_b32 v5, off, off offset:784                   // 000000DD7758: DC510310 057C0000
	s_waitcnt vmcnt(4)                                         // 000000DD7760: BF8913F7
	v_or_b32_e32 v4, 0x64006400, v4                            // 000000DD7764: 380808FF 64006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000DD776C: BF8700C1
	.long 0xcc0f40f2                                           // 000000DD7770: CC0F40F2
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DD7774: 120208FF 0000E408
	scratch_load_b32 v4, off, off offset:800                   // 000000DD777C: DC510320 047C0000
	s_waitcnt vmcnt(4)                                         // 000000DD7784: BF8913F7
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DD7788: 380404FF 64006400
	.long 0xcc0f40eb                                           // 000000DD7790: CC0F40EB
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DD7794: 120204FF 0000E408
	scratch_load_b32 v2, off, off offset:772                   // 000000DD779C: DC510304 027C0000
	s_waitcnt vmcnt(4)                                         // 000000DD77A4: BF8913F7
	v_or_b32_e32 v1, 0x64006400, v1                            // 000000DD77A8: 380202FF 64006400
	s_waitcnt vmcnt(3)                                         // 000000DD77B0: BF890FF7
	v_or_b32_e32 v3, 0x64006400, v3                            // 000000DD77B4: 380606FF 64006400
	s_waitcnt vmcnt(2)                                         // 000000DD77BC: BF890BF7
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000DD77C0: 380A0AFF 64006400
	.long 0xcc0f40ef                                           // 000000DD77C8: CC0F40EF
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DD77CC: 120202FF 0000E408
	scratch_load_b32 v1, off, off offset:788                   // 000000DD77D4: DC510314 017C0000
	.long 0xcc0f40f1                                           // 000000DD77DC: CC0F40F1
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DD77E0: 120206FF 0000E408
	scratch_load_b32 v3, off, off offset:796                   // 000000DD77E8: DC51031C 037C0000
	.long 0xcc0f40f3                                           // 000000DD77F0: CC0F40F3
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DD77F4: 12020AFF 0000E408
	v_or_b32_e32 v5, 0x64006400, v244                          // 000000DD77FC: 380BE8FF 64006400
	s_waitcnt vmcnt(3)                                         // 000000DD7804: BF890FF7
	v_or_b32_e32 v4, 0x64006400, v4                            // 000000DD7808: 380808FF 64006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000DD7810: BF8700C2
	.long 0xcc0f40f8                                           // 000000DD7814: CC0F40F8
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000DD7818: 12020AFF 0000E408
	scratch_load_b32 v5, off, off offset:816                   // 000000DD7820: DC510330 057C0000
	.long 0xcc0f40f7                                           // 000000DD7828: CC0F40F7
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DD782C: 120208FF 0000E408
	v_or_b32_e32 v4, 0x64006400, v249                          // 000000DD7834: 3809F2FF 64006400
	.long 0xcc0f40fd                                           // 000000DD783C: CC0F40FD
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DD7840: 120208FF 0000E408
	v_or_b32_e32 v4, 0x64006400, v33                           // 000000DD7848: 380842FF 64006400
	.long 0xcc0f4021                                           // 000000DD7850: CC0F4021
	v_mul_i32_i24_e32 v1, 0xe408, v10                          // 000000DD7854: 120214FF 0000E408
	v_or_b32_e32 v10, 0x64006400, v34                          // 000000DD785C: 381444FF 64006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DD7864: BF8700A3
	.long 0xcc0f401c                                           // 000000DD7868: CC0F401C
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DD786C: 120208FF 0000E408
	v_or_b32_e32 v4, 0x64006400, v118                          // 000000DD7874: 3808ECFF 64006400
	.long 0xcc0f401d                                           // 000000DD787C: CC0F401D
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DD7880: 120208FF 0000E408
	scratch_load_b32 v4, off, off offset:824                   // 000000DD7888: DC510338 047C0000
	s_waitcnt vmcnt(4)                                         // 000000DD7890: BF8913F7
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DD7894: 380404FF 64006400
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DD789C: BF870001
	.long 0xcc0f40f0                                           // 000000DD78A0: CC0F40F0
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DD78A4: 120204FF 0000E408
	scratch_load_b32 v2, off, off offset:792                   // 000000DD78AC: DC510318 027C0000
	s_waitcnt vmcnt(4)                                         // 000000DD78B4: BF8913F7
	v_or_b32_e32 v1, 0x64006400, v1                            // 000000DD78B8: 380202FF 64006400
	s_waitcnt vmcnt(3)                                         // 000000DD78C0: BF890FF7
	v_or_b32_e32 v3, 0x64006400, v3                            // 000000DD78C4: 380606FF 64006400
	s_delay_alu instid0(VALU_DEP_2)                            // 000000DD78CC: BF870002
	.long 0xcc0f40f4                                           // 000000DD78D0: CC0F40F4
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DD78D4: 120202FF 0000E408
	scratch_load_b32 v1, off, off offset:804                   // 000000DD78DC: DC510324 017C0000
	.long 0xcc0f40f6                                           // 000000DD78E4: CC0F40F6
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DD78E8: 120206FF 0000E408
	v_or_b32_e32 v3, 0x64006400, v251                          // 000000DD78F0: 3807F6FF 64006400
	s_waitcnt vmcnt(3)                                         // 000000DD78F8: BF890FF7
	v_or_b32_e32 v6, 0x64006400, v5                            // 000000DD78FC: 380C0AFF 64006400
	scratch_load_b32 v5, off, off offset:820                   // 000000DD7904: DC510334 057C0000
	.long 0xcc0f40fb                                           // 000000DD790C: CC0F40FB
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DD7910: 120206FF 0000E408
	v_or_b32_e32 v3, 0x64006400, v31                           // 000000DD7918: 38063EFF 64006400
	.long 0xcc0f4006                                           // 000000DD7920: CC0F4006
	v_mul_i32_i24_e32 v1, 0xe408, v6                           // 000000DD7924: 12020CFF 0000E408
	s_waitcnt vmcnt(2)                                         // 000000DD792C: BF890BF7
	v_or_b32_e32 v2, 0x64006400, v2                            // 000000DD7930: 380404FF 64006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DD7938: BF8700A1
	.long 0xcc0f40f5                                           // 000000DD793C: CC0F40F5
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DD7940: 120204FF 0000E408
	v_or_b32_e32 v2, 0x64006400, v250                          // 000000DD7948: 3805F4FF 64006400
	.long 0xcc0f40fa                                           // 000000DD7950: CC0F40FA
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DD7954: 120204FF 0000E408
	v_or_b32_e32 v2, 0x64006400, v30                           // 000000DD795C: 38043CFF 64006400
	s_waitcnt vmcnt(1)                                         // 000000DD7964: BF8907F7
	v_or_b32_e32 v1, 0x64006400, v1                            // 000000DD7968: 380202FF 64006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000DD7970: BF870141
	.long 0xcc0f40f9                                           // 000000DD7974: CC0F40F9
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DD7978: 120202FF 0000E408
	v_or_b32_e32 v1, 0x64006400, v255                          // 000000DD7980: 3803FEFF 64006400
	s_waitcnt vmcnt(0)                                         // 000000DD7988: BF8903F7
	v_or_b32_e32 v7, 0x64006400, v5                            // 000000DD798C: 380E0AFF 64006400
	.long 0xcc0f40ff                                           // 000000DD7994: CC0F40FF
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000DD7998: 120202FF 0000E408
	.long 0xcc0f4001                                           // 000000DD79A0: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v2                           // 000000DD79A4: 120204FF 0000E408
	.long 0xcc0f4002                                           // 000000DD79AC: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DD79B0: 120206FF 0000E408
	scratch_load_b32 v3, off, off offset:812                   // 000000DD79B8: DC51032C 037C0000
	.long 0xcc0f401e                                           // 000000DD79C0: CC0F401E
	v_mul_i32_i24_e32 v1, 0xe408, v7                           // 000000DD79C4: 12020EFF 0000E408
	scratch_load_b32 v7, off, off offset:828                   // 000000DD79CC: DC51033C 077C0000
	v_or_b32_e32 v4, 0x64006400, v4                            // 000000DD79D4: 380808FF 64006400
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DD79DC: BF870001
	.long 0xcc0f401f                                           // 000000DD79E0: CC0F401F
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DD79E4: 120208FF 0000E408
	scratch_load_b32 v4, off, off offset:840                   // 000000DD79EC: DC510348 047C0000
	s_waitcnt vmcnt(2)                                         // 000000DD79F4: BF890BF7
	v_or_b32_e32 v3, 0x64006400, v3                            // 000000DD79F8: 380606FF 64006400
	s_waitcnt vmcnt(1)                                         // 000000DD7A00: BF8907F7
	v_or_b32_e32 v8, 0x64006400, v7                            // 000000DD7A04: 38100EFF 64006400
	scratch_load_b32 v7, off, off offset:832                   // 000000DD7A0C: DC510340 077C0000
	.long 0xcc0f4005                                           // 000000DD7A14: CC0F4005
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DD7A18: 120206FF 0000E408
	v_or_b32_e32 v3, 0x64006400, v120                          // 000000DD7A20: 3806F0FF 64006400
	.long 0xcc0f4008                                           // 000000DD7A28: CC0F4008
	v_mul_i32_i24_e32 v1, 0xe408, v8                           // 000000DD7A2C: 120210FF 0000E408
	s_waitcnt vmcnt(1)                                         // 000000DD7A34: BF8907F7
	v_or_b32_e32 v4, 0x64006400, v4                            // 000000DD7A38: 380808FF 64006400
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DD7A40: BF870001
	.long 0xcc0f4023                                           // 000000DD7A44: CC0F4023
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DD7A48: 120208FF 0000E408
	scratch_load_b32 v4, off, off offset:844                   // 000000DD7A50: DC51034C 047C0000
	s_waitcnt vmcnt(1)                                         // 000000DD7A58: BF8907F7
	v_or_b32_e32 v9, 0x64006400, v7                            // 000000DD7A5C: 38120EFF 64006400
	.long 0xcc0f4007                                           // 000000DD7A64: CC0F4007
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DD7A68: 120206FF 0000E408
	scratch_load_b32 v3, off, off offset:836                   // 000000DD7A70: DC510344 037C0000
	.long 0xcc0f4020                                           // 000000DD7A78: CC0F4020
	v_mul_i32_i24_e32 v1, 0xe408, v9                           // 000000DD7A7C: 120212FF 0000E408
	v_or_b32_e32 v9, 0x64006400, v117                          // 000000DD7A84: 3812EAFF 64006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000DD7A8C: BF8700C1
	.long 0xcc0f4024                                           // 000000DD7A90: CC0F4024
	v_mul_i32_i24_e32 v1, 0xe408, v9                           // 000000DD7A94: 120212FF 0000E408
	scratch_load_b32 v9, off, off offset:848                   // 000000DD7A9C: DC510350 097C0000
	s_waitcnt vmcnt(2)                                         // 000000DD7AA4: BF890BF7
	v_or_b32_e32 v4, 0x64006400, v4                            // 000000DD7AA8: 380808FF 64006400
	.long 0xcc0f4004                                           // 000000DD7AB0: CC0F4004
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000DD7AB4: 120208FF 0000E408
	s_waitcnt vmcnt(1)                                         // 000000DD7ABC: BF8907F7
	v_or_b32_e32 v3, 0x64006400, v3                            // 000000DD7AC0: 380606FF 64006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000DD7AC8: BF870151
	.long 0xcc0f4022                                           // 000000DD7ACC: CC0F4022
	v_mul_i32_i24_e32 v1, 0xe408, v3                           // 000000DD7AD0: 120206FF 0000E408
	.long 0xcc0f4003                                           // 000000DD7AD8: CC0F4003
	v_mul_i32_i24_e32 v1, 0xe408, v10                          // 000000DD7ADC: 120214FF 0000E408
	v_or_b32_e32 v10, 0x64006400, v92                          // 000000DD7AE4: 3814B8FF 64006400
	s_waitcnt vmcnt(0)                                         // 000000DD7AEC: BF8903F7
	v_or_b32_e32 v9, 0x64006400, v9                            // 000000DD7AF0: 381212FF 64006400
	.long 0xcc0f400a                                           // 000000DD7AF8: CC0F400A
	v_mul_i32_i24_e32 v1, 0xe408, v10                          // 000000DD7AFC: 120214FF 0000E408
	s_delay_alu instid0(VALU_DEP_2)                            // 000000DD7B04: BF870002
	.long 0xcc0f4009                                           // 000000DD7B08: CC0F4009
	v_mul_i32_i24_e32 v1, 0xe408, v9                           // 000000DD7B0C: 120212FF 0000E408
	s_branch 5                                                 // 000000DD7B14: BFA00005 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi1ELi4EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x662c>
	s_or_b32 exec_lo, exec_lo, s2                              // 000000DD7B18: 8C7E027E
	s_add_i32 s1, s1, 1                                        // 000000DD7B1C: 81018101
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000DD7B20: BF870009
	s_cmp_lg_u32 s1, s3                                        // 000000DD7B24: BF070301
	s_cbranch_scc0 1023                                        // 000000DD7B28: BFA103FF <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi1ELi4EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x7628>
	scratch_load_b32 v25, off, off offset:400                  // 000000DD7B2C: DC510190 197C0000
	s_mul_i32 s2, s1, 0x1400                                   // 000000DD7B34: 9602FF01 00001400
	v_mov_b32_e32 v91, 0                                       // 000000DD7B3C: 7EB60280
	s_clause 0x1                                               // 000000DD7B40: BF850001
	scratch_load_b32 v26, off, off offset:312                  // 000000DD7B44: DC510138 1A7C0000
	scratch_load_b32 v27, off, off offset:184                  // 000000DD7B4C: DC5100B8 1B7C0000
	s_waitcnt vmcnt(2)                                         // 000000DD7B54: BF890BF7
	v_or_b32_e32 v92, s2, v25                                  // 000000DD7B58: 38B83202
	scratch_load_b32 v25, off, off offset:388                  // 000000DD7B5C: DC510184 197C0000
	ds_load_b128 v[93:96], v92                                 // 000000DD7B64: DBFC0000 5D00005C
	ds_load_b128 v[97:100], v92 offset:16                      // 000000DD7B6C: DBFC0010 6100005C
	ds_load_b128 v[105:108], v92 offset:512                    // 000000DD7B74: DBFC0200 6900005C
	ds_load_b128 v[109:112], v92 offset:528                    // 000000DD7B7C: DBFC0210 6D00005C
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 000000DD7B84: BF890037
	v_dot2acc_f32_f16 v91, v25, v93                            // 000000DD7B88: 04B6BB19
	scratch_load_b32 v25, off, off offset:392                  // 000000DD7B8C: DC510188 197C0000
	s_waitcnt vmcnt(0)                                         // 000000DD7B94: BF8903F7
	v_dot2acc_f32_f16 v91, v25, v94                            // 000000DD7B98: 04B6BD19
	scratch_load_b32 v25, off, off offset:396                  // 000000DD7B9C: DC51018C 197C0000
	s_waitcnt vmcnt(0)                                         // 000000DD7BA4: BF8903F7
	v_dot2acc_f32_f16 v91, v25, v95                            // 000000DD7BA8: 04B6BF19
	scratch_load_b32 v25, off, off offset:384                  // 000000DD7BAC: DC510180 197C0000
	s_waitcnt vmcnt(0)                                         // 000000DD7BB4: BF8903F7
	v_dot2acc_f32_f16 v91, v25, v96                            // 000000DD7BB8: 04B6C119
	ds_load_b128 v[93:96], v92 offset:256                      // 000000DD7BBC: DBFC0100 5D00005C
	ds_load_b128 v[101:104], v92 offset:272                    // 000000DD7BC4: DBFC0110 6500005C
	v_mov_b32_e32 v25, 0                                       // 000000DD7BCC: 7E320280
	s_waitcnt lgkmcnt(1)                                       // 000000DD7BD0: BF89FC17
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DD7BD4: BF870001
	v_dot2acc_f32_f16 v25, v26, v93                            // 000000DD7BD8: 0432BB1A
	scratch_load_b32 v26, off, off offset:316                  // 000000DD7BDC: DC51013C 1A7C0000
	v_mov_b32_e32 v93, 0                                       // 000000DD7BE4: 7EBA0280
	s_waitcnt vmcnt(0)                                         // 000000DD7BE8: BF8903F7
	v_dot2acc_f32_f16 v25, v26, v94                            // 000000DD7BEC: 0432BD1A
	scratch_load_b32 v26, off, off offset:304                  // 000000DD7BF0: DC510130 1A7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD7BF8: BF8903F7
	v_dual_mov_b32 v94, 0 :: v_dual_dot2acc_f32_f16 v25, v26, v95// 000000DD7BFC: CA180080 5E18BF1A
	scratch_load_b32 v26, off, off offset:308                  // 000000DD7C04: DC510134 1A7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD7C0C: BF8903F7
	v_dot2acc_f32_f16 v25, v26, v96                            // 000000DD7C10: 0432C11A
	scratch_load_b32 v26, off, off offset:252                  // 000000DD7C14: DC5100FC 1A7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD7C1C: BF8903F7
	v_dot2acc_f32_f16 v93, v26, v105                           // 000000DD7C20: 04BAD31A
	scratch_load_b32 v26, off, off offset:244                  // 000000DD7C24: DC5100F4 1A7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD7C2C: BF8903F7
	v_dot2acc_f32_f16 v93, v26, v106                           // 000000DD7C30: 04BAD51A
	scratch_load_b32 v26, off, off offset:248                  // 000000DD7C34: DC5100F8 1A7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD7C3C: BF8903F7
	v_dot2acc_f32_f16 v93, v26, v107                           // 000000DD7C40: 04BAD71A
	scratch_load_b32 v26, off, off offset:236                  // 000000DD7C44: DC5100EC 1A7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD7C4C: BF8903F7
	v_dot2acc_f32_f16 v93, v26, v108                           // 000000DD7C50: 04BAD91A
	ds_load_b128 v[105:108], v92 offset:768                    // 000000DD7C54: DBFC0300 6900005C
	ds_load_b128 v[113:116], v92 offset:784                    // 000000DD7C5C: DBFC0310 7100005C
	v_mov_b32_e32 v26, 0                                       // 000000DD7C64: 7E340280
	s_waitcnt lgkmcnt(1)                                       // 000000DD7C68: BF89FC17
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DD7C6C: BF870001
	v_dot2acc_f32_f16 v26, v27, v105                           // 000000DD7C70: 0434D31B
	scratch_load_b32 v27, off, off offset:188                  // 000000DD7C74: DC5100BC 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD7C7C: BF8903F7
	v_dot2acc_f32_f16 v26, v27, v106                           // 000000DD7C80: 0434D51B
	scratch_load_b32 v27, off, off offset:176                  // 000000DD7C84: DC5100B0 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD7C8C: BF8903F7
	v_dot2acc_f32_f16 v26, v27, v107                           // 000000DD7C90: 0434D71B
	scratch_load_b32 v27, off, off offset:180                  // 000000DD7C94: DC5100B4 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD7C9C: BF8903F7
	v_dot2acc_f32_f16 v26, v27, v108                           // 000000DD7CA0: 0434D91B
	scratch_load_b32 v27, off, off offset:124                  // 000000DD7CA4: DC51007C 1B7C0000
	ds_load_b128 v[105:108], v92 offset:1024                   // 000000DD7CAC: DBFC0400 6900005C
	ds_load_b128 v[117:120], v92 offset:1040                   // 000000DD7CB4: DBFC0410 7500005C
	s_waitcnt vmcnt(0) lgkmcnt(1)                              // 000000DD7CBC: BF890017
	v_dot2acc_f32_f16 v94, v27, v105                           // 000000DD7CC0: 04BCD31B
	scratch_load_b32 v27, off, off offset:116                  // 000000DD7CC4: DC510074 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD7CCC: BF8903F7
	v_dot2acc_f32_f16 v94, v27, v106                           // 000000DD7CD0: 04BCD51B
	scratch_load_b32 v27, off, off offset:120                  // 000000DD7CD4: DC510078 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD7CDC: BF8903F7
	v_dot2acc_f32_f16 v94, v27, v107                           // 000000DD7CE0: 04BCD71B
	scratch_load_b32 v27, off, off offset:108                  // 000000DD7CE4: DC51006C 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD7CEC: BF8903F7
	v_dot2acc_f32_f16 v94, v27, v108                           // 000000DD7CF0: 04BCD91B
	scratch_load_b32 v27, off, off offset:372                  // 000000DD7CF4: DC510174 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD7CFC: BF8903F7
	v_dot2acc_f32_f16 v91, v27, v97                            // 000000DD7D00: 04B6C31B
	scratch_load_b32 v27, off, off offset:376                  // 000000DD7D04: DC510178 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD7D0C: BF8903F7
	v_dot2acc_f32_f16 v91, v27, v98                            // 000000DD7D10: 04B6C51B
	scratch_load_b32 v27, off, off offset:380                  // 000000DD7D14: DC51017C 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD7D1C: BF8903F7
	v_dot2acc_f32_f16 v91, v27, v99                            // 000000DD7D20: 04B6C71B
	scratch_load_b32 v27, off, off offset:364                  // 000000DD7D24: DC51016C 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD7D2C: BF8903F7
	v_dot2acc_f32_f16 v91, v27, v100                           // 000000DD7D30: 04B6C91B
	scratch_load_b32 v27, off, off offset:296                  // 000000DD7D34: DC510128 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD7D3C: BF8903F7
	v_dot2acc_f32_f16 v25, v27, v101                           // 000000DD7D40: 0432CB1B
	scratch_load_b32 v27, off, off offset:300                  // 000000DD7D44: DC51012C 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD7D4C: BF8903F7
	v_dot2acc_f32_f16 v25, v27, v102                           // 000000DD7D50: 0432CD1B
	scratch_load_b32 v27, off, off offset:288                  // 000000DD7D54: DC510120 1B7C0000
	ds_load_b128 v[95:98], v92 offset:32                       // 000000DD7D5C: DBFC0020 5F00005C
	ds_load_b128 v[99:102], v92 offset:48                      // 000000DD7D64: DBFC0030 6300005C
	s_waitcnt vmcnt(0)                                         // 000000DD7D6C: BF8903F7
	v_dot2acc_f32_f16 v25, v27, v103                           // 000000DD7D70: 0432CF1B
	scratch_load_b32 v27, off, off offset:292                  // 000000DD7D74: DC510124 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD7D7C: BF8903F7
	v_dot2acc_f32_f16 v25, v27, v104                           // 000000DD7D80: 0432D11B
	scratch_load_b32 v27, off, off offset:240                  // 000000DD7D84: DC5100F0 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD7D8C: BF8903F7
	v_dot2acc_f32_f16 v93, v27, v109                           // 000000DD7D90: 04BADB1B
	scratch_load_b32 v27, off, off offset:228                  // 000000DD7D94: DC5100E4 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD7D9C: BF8903F7
	v_dot2acc_f32_f16 v93, v27, v110                           // 000000DD7DA0: 04BADD1B
	scratch_load_b32 v27, off, off offset:232                  // 000000DD7DA4: DC5100E8 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD7DAC: BF8903F7
	v_dot2acc_f32_f16 v93, v27, v111                           // 000000DD7DB0: 04BADF1B
	scratch_load_b32 v27, off, off offset:220                  // 000000DD7DB4: DC5100DC 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD7DBC: BF8903F7
	v_dot2acc_f32_f16 v93, v27, v112                           // 000000DD7DC0: 04BAE11B
	scratch_load_b32 v27, off, off offset:168                  // 000000DD7DC4: DC5100A8 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD7DCC: BF8903F7
	v_dot2acc_f32_f16 v26, v27, v113                           // 000000DD7DD0: 0434E31B
	scratch_load_b32 v27, off, off offset:172                  // 000000DD7DD4: DC5100AC 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD7DDC: BF8903F7
	v_dot2acc_f32_f16 v26, v27, v114                           // 000000DD7DE0: 0434E51B
	scratch_load_b32 v27, off, off offset:160                  // 000000DD7DE4: DC5100A0 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD7DEC: BF8903F7
	v_dot2acc_f32_f16 v26, v27, v115                           // 000000DD7DF0: 0434E71B
	scratch_load_b32 v27, off, off offset:164                  // 000000DD7DF4: DC5100A4 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD7DFC: BF8903F7
	v_dot2acc_f32_f16 v26, v27, v116                           // 000000DD7E00: 0434E91B
	scratch_load_b32 v27, off, off offset:112                  // 000000DD7E04: DC510070 1B7C0000
	s_waitcnt vmcnt(0) lgkmcnt(2)                              // 000000DD7E0C: BF890027
	v_dot2acc_f32_f16 v94, v27, v117                           // 000000DD7E10: 04BCEB1B
	scratch_load_b32 v27, off, off offset:100                  // 000000DD7E14: DC510064 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD7E1C: BF8903F7
	v_dot2acc_f32_f16 v94, v27, v118                           // 000000DD7E20: 04BCED1B
	scratch_load_b32 v27, off, off offset:104                  // 000000DD7E24: DC510068 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD7E2C: BF8903F7
	v_dot2acc_f32_f16 v94, v27, v119                           // 000000DD7E30: 04BCEF1B
	scratch_load_b32 v27, off, off offset:92                   // 000000DD7E34: DC51005C 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD7E3C: BF8903F7
	v_dual_mov_b32 v119, 0 :: v_dual_dot2acc_f32_f16 v94, v27, v120// 000000DD7E40: CA180080 775EF11B
	scratch_load_b32 v27, off, off offset:368                  // 000000DD7E48: DC510170 1B7C0000
	s_waitcnt vmcnt(0) lgkmcnt(1)                              // 000000DD7E50: BF890017
	v_dual_mov_b32 v120, 0 :: v_dual_dot2acc_f32_f16 v91, v27, v95// 000000DD7E54: CA180080 785ABF1B
	scratch_load_b32 v27, off, off offset:340                  // 000000DD7E5C: DC510154 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD7E64: BF8903F7
	v_dot2acc_f32_f16 v91, v27, v96                            // 000000DD7E68: 04B6C11B
	scratch_load_b32 v27, off, off offset:360                  // 000000DD7E6C: DC510168 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD7E74: BF8903F7
	v_dot2acc_f32_f16 v91, v27, v97                            // 000000DD7E78: 04B6C31B
	scratch_load_b32 v27, off, off offset:332                  // 000000DD7E7C: DC51014C 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD7E84: BF8903F7
	v_dot2acc_f32_f16 v91, v27, v98                            // 000000DD7E88: 04B6C51B
	scratch_load_b32 v27, off, off offset:280                  // 000000DD7E8C: DC510118 1B7C0000
	ds_load_b128 v[95:98], v92 offset:288                      // 000000DD7E94: DBFC0120 5F00005C
	ds_load_b128 v[103:106], v92 offset:304                    // 000000DD7E9C: DBFC0130 6700005C
	s_waitcnt vmcnt(0) lgkmcnt(1)                              // 000000DD7EA4: BF890017
	v_dot2acc_f32_f16 v25, v27, v95                            // 000000DD7EA8: 0432BF1B
	scratch_load_b32 v27, off, off offset:284                  // 000000DD7EAC: DC51011C 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD7EB4: BF8903F7
	v_dot2acc_f32_f16 v25, v27, v96                            // 000000DD7EB8: 0432C11B
	scratch_load_b32 v27, off, off offset:272                  // 000000DD7EBC: DC510110 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD7EC4: BF8903F7
	v_dot2acc_f32_f16 v25, v27, v97                            // 000000DD7EC8: 0432C31B
	scratch_load_b32 v27, off, off offset:276                  // 000000DD7ECC: DC510114 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD7ED4: BF8903F7
	v_dot2acc_f32_f16 v25, v27, v98                            // 000000DD7ED8: 0432C51B
	scratch_load_b32 v27, off, off offset:224                  // 000000DD7EDC: DC5100E0 1B7C0000
	ds_load_b128 v[95:98], v92 offset:544                      // 000000DD7EE4: DBFC0220 5F00005C
	ds_load_b128 v[107:110], v92 offset:560                    // 000000DD7EEC: DBFC0230 6B00005C
	s_waitcnt vmcnt(0) lgkmcnt(1)                              // 000000DD7EF4: BF890017
	v_dot2acc_f32_f16 v93, v27, v95                            // 000000DD7EF8: 04BABF1B
	scratch_load_b32 v27, off, off offset:212                  // 000000DD7EFC: DC5100D4 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD7F04: BF8903F7
	v_dot2acc_f32_f16 v93, v27, v96                            // 000000DD7F08: 04BAC11B
	scratch_load_b32 v27, off, off offset:216                  // 000000DD7F0C: DC5100D8 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD7F14: BF8903F7
	v_dot2acc_f32_f16 v93, v27, v97                            // 000000DD7F18: 04BAC31B
	scratch_load_b32 v27, off, off offset:204                  // 000000DD7F1C: DC5100CC 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD7F24: BF8903F7
	v_dot2acc_f32_f16 v93, v27, v98                            // 000000DD7F28: 04BAC51B
	scratch_load_b32 v27, off, off offset:152                  // 000000DD7F2C: DC510098 1B7C0000
	ds_load_b128 v[95:98], v92 offset:800                      // 000000DD7F34: DBFC0320 5F00005C
	ds_load_b128 v[111:114], v92 offset:816                    // 000000DD7F3C: DBFC0330 6F00005C
	s_waitcnt vmcnt(0) lgkmcnt(1)                              // 000000DD7F44: BF890017
	v_dot2acc_f32_f16 v26, v27, v95                            // 000000DD7F48: 0434BF1B
	scratch_load_b32 v27, off, off offset:156                  // 000000DD7F4C: DC51009C 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD7F54: BF8903F7
	v_dot2acc_f32_f16 v26, v27, v96                            // 000000DD7F58: 0434C11B
	scratch_load_b32 v27, off, off offset:144                  // 000000DD7F5C: DC510090 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD7F64: BF8903F7
	v_dot2acc_f32_f16 v26, v27, v97                            // 000000DD7F68: 0434C31B
	scratch_load_b32 v27, off, off offset:148                  // 000000DD7F6C: DC510094 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD7F74: BF8903F7
	v_dot2acc_f32_f16 v26, v27, v98                            // 000000DD7F78: 0434C51B
	scratch_load_b32 v27, off, off offset:96                   // 000000DD7F7C: DC510060 1B7C0000
	ds_load_b128 v[95:98], v92 offset:1056                     // 000000DD7F84: DBFC0420 5F00005C
	ds_load_b128 v[115:118], v92 offset:1072                   // 000000DD7F8C: DBFC0430 7300005C
	s_waitcnt vmcnt(0) lgkmcnt(1)                              // 000000DD7F94: BF890017
	v_dot2acc_f32_f16 v94, v27, v95                            // 000000DD7F98: 04BCBF1B
	scratch_load_b32 v27, off, off offset:84                   // 000000DD7F9C: DC510054 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD7FA4: BF8903F7
	v_dual_mov_b32 v95, 0 :: v_dual_dot2acc_f32_f16 v94, v27, v96// 000000DD7FA8: CA180080 5F5EC11B
	scratch_load_b32 v27, off, off offset:88                   // 000000DD7FB0: DC510058 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD7FB8: BF8903F7
	v_dot2acc_f32_f16 v94, v27, v97                            // 000000DD7FBC: 04BCC31B
	scratch_load_b32 v27, off, off offset:76                   // 000000DD7FC0: DC51004C 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD7FC8: BF8903F7
	v_dot2acc_f32_f16 v94, v27, v98                            // 000000DD7FCC: 04BCC51B
	scratch_load_b32 v27, off, off offset:336                  // 000000DD7FD0: DC510150 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD7FD8: BF8903F7
	v_dot2acc_f32_f16 v91, v27, v99                            // 000000DD7FDC: 04B6C71B
	scratch_load_b32 v27, off, off offset:324                  // 000000DD7FE0: DC510144 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD7FE8: BF8903F7
	v_dot2acc_f32_f16 v91, v27, v100                           // 000000DD7FEC: 04B6C91B
	scratch_load_b32 v27, off, off offset:328                  // 000000DD7FF0: DC510148 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD7FF8: BF8903F7
	v_dot2acc_f32_f16 v91, v27, v101                           // 000000DD7FFC: 04B6CB1B
	scratch_load_b32 v27, off, off offset:320                  // 000000DD8000: DC510140 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD8008: BF8903F7
	v_dot2acc_f32_f16 v91, v27, v102                           // 000000DD800C: 04B6CD1B
	scratch_load_b32 v27, off, off offset:264                  // 000000DD8010: DC510108 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD8018: BF8903F7
	v_dot2acc_f32_f16 v25, v27, v103                           // 000000DD801C: 0432CF1B
	scratch_load_b32 v27, off, off offset:268                  // 000000DD8020: DC51010C 1B7C0000
	ds_load_b128 v[96:99], v92 offset:1280                     // 000000DD8028: DBFC0500 6000005C
	ds_load_b128 v[100:103], v92 offset:1296                   // 000000DD8030: DBFC0510 6400005C
	s_waitcnt vmcnt(0)                                         // 000000DD8038: BF8903F7
	v_dot2acc_f32_f16 v25, v27, v104                           // 000000DD803C: 0432D11B
	scratch_load_b32 v27, off, off offset:256                  // 000000DD8040: DC510100 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD8048: BF8903F7
	v_dot2acc_f32_f16 v25, v27, v105                           // 000000DD804C: 0432D31B
	scratch_load_b32 v27, off, off offset:260                  // 000000DD8050: DC510104 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD8058: BF8903F7
	v_dot2acc_f32_f16 v25, v27, v106                           // 000000DD805C: 0432D51B
	scratch_load_b32 v27, off, off offset:208                  // 000000DD8060: DC5100D0 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD8068: BF8903F7
	v_dot2acc_f32_f16 v93, v27, v107                           // 000000DD806C: 04BAD71B
	scratch_load_b32 v27, off, off offset:196                  // 000000DD8070: DC5100C4 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD8078: BF8903F7
	v_dot2acc_f32_f16 v93, v27, v108                           // 000000DD807C: 04BAD91B
	scratch_load_b32 v27, off, off offset:200                  // 000000DD8080: DC5100C8 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD8088: BF8903F7
	v_dot2acc_f32_f16 v93, v27, v109                           // 000000DD808C: 04BADB1B
	scratch_load_b32 v27, off, off offset:192                  // 000000DD8090: DC5100C0 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD8098: BF8903F7
	v_dot2acc_f32_f16 v93, v27, v110                           // 000000DD809C: 04BADD1B
	scratch_load_b32 v27, off, off offset:136                  // 000000DD80A0: DC510088 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD80A8: BF8903F7
	v_dot2acc_f32_f16 v26, v27, v111                           // 000000DD80AC: 0434DF1B
	scratch_load_b32 v27, off, off offset:140                  // 000000DD80B0: DC51008C 1B7C0000
	ds_load_b128 v[104:107], v92 offset:1536                   // 000000DD80B8: DBFC0600 6800005C
	ds_load_b128 v[108:111], v92 offset:1552                   // 000000DD80C0: DBFC0610 6C00005C
	s_waitcnt vmcnt(0)                                         // 000000DD80C8: BF8903F7
	v_dot2acc_f32_f16 v26, v27, v112                           // 000000DD80CC: 0434E11B
	scratch_load_b32 v27, off, off offset:128                  // 000000DD80D0: DC510080 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD80D8: BF8903F7
	v_dot2acc_f32_f16 v26, v27, v113                           // 000000DD80DC: 0434E31B
	scratch_load_b32 v27, off, off offset:132                  // 000000DD80E0: DC510084 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD80E8: BF8903F7
	v_dot2acc_f32_f16 v26, v27, v114                           // 000000DD80EC: 0434E51B
	scratch_load_b32 v27, off, off offset:404                  // 000000DD80F0: DC510194 1B7C0000
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 000000DD80F8: BF890037
	v_dot2acc_f32_f16 v95, v27, v96                            // 000000DD80FC: 04BEC11B
	scratch_load_b32 v27, off, off offset:408                  // 000000DD8100: DC510198 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD8108: BF8903F7
	v_dot2acc_f32_f16 v95, v27, v97                            // 000000DD810C: 04BEC31B
	scratch_load_b32 v27, off, off offset:412                  // 000000DD8110: DC51019C 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD8118: BF8903F7
	v_dot2acc_f32_f16 v95, v27, v98                            // 000000DD811C: 04BEC51B
	scratch_load_b32 v27, off, off offset:416                  // 000000DD8120: DC5101A0 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD8128: BF8903F7
	v_dot2acc_f32_f16 v95, v27, v99                            // 000000DD812C: 04BEC71B
	scratch_load_b32 v27, off, off offset:80                   // 000000DD8130: DC510050 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD8138: BF8903F7
	v_dot2acc_f32_f16 v94, v27, v115                           // 000000DD813C: 04BCE71B
	scratch_load_b32 v27, off, off offset:68                   // 000000DD8140: DC510044 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD8148: BF8903F7
	v_dot2acc_f32_f16 v94, v27, v116                           // 000000DD814C: 04BCE91B
	scratch_load_b32 v27, off, off offset:72                   // 000000DD8150: DC510048 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD8158: BF8903F7
	v_dot2acc_f32_f16 v94, v27, v117                           // 000000DD815C: 04BCEB1B
	scratch_load_b32 v27, off, off offset:64                   // 000000DD8160: DC510040 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD8168: BF8903F7
	v_dot2acc_f32_f16 v94, v27, v118                           // 000000DD816C: 04BCED1B
	scratch_load_b32 v27, off, off offset:420                  // 000000DD8170: DC5101A4 1B7C0000
	s_waitcnt vmcnt(0) lgkmcnt(2)                              // 000000DD8178: BF890027
	v_dual_mov_b32 v118, 0 :: v_dual_dot2acc_f32_f16 v95, v27, v100// 000000DD817C: CA180080 765EC91B
	scratch_load_b32 v27, off, off offset:424                  // 000000DD8184: DC5101A8 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD818C: BF8903F7
	v_dot2acc_f32_f16 v95, v27, v101                           // 000000DD8190: 04BECB1B
	scratch_load_b32 v27, off, off offset:428                  // 000000DD8194: DC5101AC 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD819C: BF8903F7
	v_dot2acc_f32_f16 v95, v27, v102                           // 000000DD81A0: 04BECD1B
	scratch_load_b32 v27, off, off offset:432                  // 000000DD81A4: DC5101B0 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD81AC: BF8903F7
	v_dot2acc_f32_f16 v95, v27, v103                           // 000000DD81B0: 04BECF1B
	scratch_load_b32 v27, off, off offset:436                  // 000000DD81B4: DC5101B4 1B7C0000
	ds_load_b128 v[96:99], v92 offset:1312                     // 000000DD81BC: DBFC0520 6000005C
	ds_load_b128 v[100:103], v92 offset:1328                   // 000000DD81C4: DBFC0530 6400005C
	s_waitcnt vmcnt(0) lgkmcnt(1)                              // 000000DD81CC: BF890017
	v_dot2acc_f32_f16 v95, v27, v96                            // 000000DD81D0: 04BEC11B
	scratch_load_b32 v27, off, off offset:440                  // 000000DD81D4: DC5101B8 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD81DC: BF8903F7
	v_dual_mov_b32 v96, 0 :: v_dual_dot2acc_f32_f16 v95, v27, v97// 000000DD81E0: CA180080 605EC31B
	scratch_load_b32 v27, off, off offset:444                  // 000000DD81E8: DC5101BC 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD81F0: BF8903F7
	v_dot2acc_f32_f16 v95, v27, v98                            // 000000DD81F4: 04BEC51B
	scratch_load_b32 v27, off, off offset:448                  // 000000DD81F8: DC5101C0 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD8200: BF8903F7
	v_dot2acc_f32_f16 v95, v27, v99                            // 000000DD8204: 04BEC71B
	scratch_load_b32 v27, off, off offset:468                  // 000000DD8208: DC5101D4 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD8210: BF8903F7
	v_dot2acc_f32_f16 v96, v27, v104                           // 000000DD8214: 04C0D11B
	scratch_load_b32 v27, off, off offset:452                  // 000000DD8218: DC5101C4 1B7C0000
	v_dot2acc_f32_f16 v96, v121, v105                          // 000000DD8220: 04C0D379
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD8224: BF870091
	v_dot2acc_f32_f16 v96, v122, v106                          // 000000DD8228: 04C0D57A
	v_dot2acc_f32_f16 v96, v123, v107                          // 000000DD822C: 04C0D77B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD8230: BF870091
	v_dot2acc_f32_f16 v96, v124, v108                          // 000000DD8234: 04C0D97C
	v_dot2acc_f32_f16 v96, v125, v109                          // 000000DD8238: 04C0DB7D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD823C: BF870091
	v_dot2acc_f32_f16 v96, v126, v110                          // 000000DD8240: 04C0DD7E
	v_dot2acc_f32_f16 v96, v127, v111                          // 000000DD8244: 04C0DF7F
	ds_load_b128 v[105:108], v92 offset:1792                   // 000000DD8248: DBFC0700 6900005C
	ds_load_b128 v[109:112], v92 offset:1808                   // 000000DD8250: DBFC0710 6D00005C
	s_waitcnt vmcnt(0) lgkmcnt(2)                              // 000000DD8258: BF890027
	v_dot2acc_f32_f16 v95, v27, v100                           // 000000DD825C: 04BEC91B
	scratch_load_b32 v27, off, off offset:456                  // 000000DD8260: DC5101C8 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD8268: BF8903F7
	v_dot2acc_f32_f16 v95, v27, v101                           // 000000DD826C: 04BECB1B
	scratch_load_b32 v27, off, off offset:460                  // 000000DD8270: DC5101CC 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD8278: BF8903F7
	v_dot2acc_f32_f16 v95, v27, v102                           // 000000DD827C: 04BECD1B
	scratch_load_b32 v27, off, off offset:464                  // 000000DD8280: DC5101D0 1B7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD8288: BF8903F7
	v_dot2acc_f32_f16 v95, v27, v103                           // 000000DD828C: 04BECF1B
	ds_load_b128 v[97:100], v92 offset:1568                    // 000000DD8290: DBFC0620 6100005C
	ds_load_b128 v[101:104], v92 offset:1584                   // 000000DD8298: DBFC0630 6500005C
	s_waitcnt lgkmcnt(1)                                       // 000000DD82A0: BF89FC17
	v_dual_mov_b32 v27, 0 :: v_dual_dot2acc_f32_f16 v96, v128, v97// 000000DD82A4: CA180080 1B60C380
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD82AC: BF870091
	v_dual_mov_b32 v97, 0 :: v_dual_dot2acc_f32_f16 v96, v129, v98// 000000DD82B0: CA180080 6160C581
	v_dual_dot2acc_f32_f16 v97, v136, v105 :: v_dual_dot2acc_f32_f16 v96, v130, v99// 000000DD82B8: CB18D388 6160C782
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DD82C0: BF8700A1
	v_dual_dot2acc_f32_f16 v97, v137, v106 :: v_dual_dot2acc_f32_f16 v96, v131, v100// 000000DD82C4: CB18D589 6160C983
	s_waitcnt lgkmcnt(0)                                       // 000000DD82CC: BF89FC07
	v_dual_dot2acc_f32_f16 v97, v138, v107 :: v_dual_dot2acc_f32_f16 v96, v132, v101// 000000DD82D0: CB18D78A 6160CB84
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD82D8: BF870091
	v_dual_dot2acc_f32_f16 v97, v139, v108 :: v_dual_dot2acc_f32_f16 v96, v133, v102// 000000DD82DC: CB18D98B 6160CD85
	v_dual_dot2acc_f32_f16 v97, v140, v109 :: v_dual_dot2acc_f32_f16 v96, v134, v103// 000000DD82E4: CB18DB8C 6160CF86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000DD82EC: BF8700C1
	v_dual_dot2acc_f32_f16 v97, v141, v110 :: v_dual_dot2acc_f32_f16 v96, v135, v104// 000000DD82F0: CB18DD8D 6160D187
	ds_load_b128 v[98:101], v92 offset:1824                    // 000000DD82F8: DBFC0720 6200005C
	ds_load_b128 v[102:105], v92 offset:1840                   // 000000DD8300: DBFC0730 6600005C
	v_dot2acc_f32_f16 v97, v142, v111                          // 000000DD8308: 04C2DF8E
	v_dot2acc_f32_f16 v97, v143, v112                          // 000000DD830C: 04C2E18F
	ds_load_b128 v[106:109], v92 offset:2048                   // 000000DD8310: DBFC0800 6A00005C
	ds_load_b128 v[110:113], v92 offset:2064                   // 000000DD8318: DBFC0810 6E00005C
	s_waitcnt lgkmcnt(3)                                       // 000000DD8320: BF89FC37
	v_dual_dot2acc_f32_f16 v97, v144, v98 :: v_dual_mov_b32 v98, 0// 000000DD8324: CB10C590 61620080
	s_waitcnt lgkmcnt(1)                                       // 000000DD832C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD8330: BF870091
	v_dual_dot2acc_f32_f16 v97, v145, v99 :: v_dual_dot2acc_f32_f16 v98, v152, v106// 000000DD8334: CB18C791 6162D598
	v_dual_dot2acc_f32_f16 v97, v146, v100 :: v_dual_dot2acc_f32_f16 v98, v153, v107// 000000DD833C: CB18C992 6162D799
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD8344: BF870091
	v_dual_dot2acc_f32_f16 v97, v147, v101 :: v_dual_dot2acc_f32_f16 v98, v154, v108// 000000DD8348: CB18CB93 6162D99A
	v_dual_dot2acc_f32_f16 v97, v148, v102 :: v_dual_dot2acc_f32_f16 v98, v155, v109// 000000DD8350: CB18CD94 6162DB9B
	s_waitcnt lgkmcnt(0)                                       // 000000DD8358: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD835C: BF870091
	v_dual_dot2acc_f32_f16 v97, v149, v103 :: v_dual_dot2acc_f32_f16 v98, v156, v110// 000000DD8360: CB18CF95 6162DD9C
	v_dual_dot2acc_f32_f16 v97, v150, v104 :: v_dual_dot2acc_f32_f16 v98, v157, v111// 000000DD8368: CB18D196 6162DF9D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000DD8370: BF8700C1
	v_dot2acc_f32_f16 v97, v151, v105                          // 000000DD8374: 04C2D397
	ds_load_b128 v[99:102], v92 offset:2080                    // 000000DD8378: DBFC0820 6300005C
	ds_load_b128 v[103:106], v92 offset:2096                   // 000000DD8380: DBFC0830 6700005C
	v_dot2acc_f32_f16 v98, v158, v112                          // 000000DD8388: 04C4E19E
	v_dot2acc_f32_f16 v98, v159, v113                          // 000000DD838C: 04C4E39F
	ds_load_b128 v[107:110], v92 offset:2304                   // 000000DD8390: DBFC0900 6B00005C
	ds_load_b128 v[111:114], v92 offset:2320                   // 000000DD8398: DBFC0910 6F00005C
	s_waitcnt lgkmcnt(3)                                       // 000000DD83A0: BF89FC37
	v_dual_dot2acc_f32_f16 v98, v160, v99 :: v_dual_mov_b32 v99, 0// 000000DD83A4: CB10C7A0 62620080
	s_waitcnt lgkmcnt(1)                                       // 000000DD83AC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD83B0: BF870091
	v_dual_dot2acc_f32_f16 v98, v161, v100 :: v_dual_dot2acc_f32_f16 v99, v168, v107// 000000DD83B4: CB18C9A1 6262D7A8
	v_dual_dot2acc_f32_f16 v98, v162, v101 :: v_dual_dot2acc_f32_f16 v99, v169, v108// 000000DD83BC: CB18CBA2 6262D9A9
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD83C4: BF870091
	v_dual_dot2acc_f32_f16 v98, v163, v102 :: v_dual_dot2acc_f32_f16 v99, v170, v109// 000000DD83C8: CB18CDA3 6262DBAA
	v_dual_dot2acc_f32_f16 v98, v164, v103 :: v_dual_dot2acc_f32_f16 v99, v171, v110// 000000DD83D0: CB18CFA4 6262DDAB
	s_waitcnt lgkmcnt(0)                                       // 000000DD83D8: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD83DC: BF870091
	v_dual_dot2acc_f32_f16 v98, v165, v104 :: v_dual_dot2acc_f32_f16 v99, v172, v111// 000000DD83E0: CB18D1A5 6262DFAC
	v_dual_dot2acc_f32_f16 v98, v166, v105 :: v_dual_dot2acc_f32_f16 v99, v173, v112// 000000DD83E8: CB18D3A6 6262E1AD
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000DD83F0: BF8700C1
	v_dot2acc_f32_f16 v98, v167, v106                          // 000000DD83F4: 04C4D5A7
	ds_load_b128 v[100:103], v92 offset:2336                   // 000000DD83F8: DBFC0920 6400005C
	ds_load_b128 v[104:107], v92 offset:2352                   // 000000DD8400: DBFC0930 6800005C
	v_dot2acc_f32_f16 v99, v174, v113                          // 000000DD8408: 04C6E3AE
	v_dot2acc_f32_f16 v99, v175, v114                          // 000000DD840C: 04C6E5AF
	ds_load_b128 v[108:111], v92 offset:2560                   // 000000DD8410: DBFC0A00 6C00005C
	ds_load_b128 v[112:115], v92 offset:2576                   // 000000DD8418: DBFC0A10 7000005C
	s_waitcnt lgkmcnt(3)                                       // 000000DD8420: BF89FC37
	v_dual_dot2acc_f32_f16 v99, v176, v100 :: v_dual_mov_b32 v100, 0// 000000DD8424: CB10C9B0 63640080
	s_waitcnt lgkmcnt(1)                                       // 000000DD842C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD8430: BF870091
	v_dual_dot2acc_f32_f16 v99, v177, v101 :: v_dual_dot2acc_f32_f16 v100, v184, v108// 000000DD8434: CB18CBB1 6364D9B8
	v_dual_dot2acc_f32_f16 v99, v178, v102 :: v_dual_dot2acc_f32_f16 v100, v185, v109// 000000DD843C: CB18CDB2 6364DBB9
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD8444: BF870091
	v_dual_dot2acc_f32_f16 v99, v179, v103 :: v_dual_dot2acc_f32_f16 v100, v186, v110// 000000DD8448: CB18CFB3 6364DDBA
	v_dual_dot2acc_f32_f16 v99, v180, v104 :: v_dual_dot2acc_f32_f16 v100, v187, v111// 000000DD8450: CB18D1B4 6364DFBB
	s_waitcnt lgkmcnt(0)                                       // 000000DD8458: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD845C: BF870091
	v_dual_dot2acc_f32_f16 v99, v181, v105 :: v_dual_dot2acc_f32_f16 v100, v188, v112// 000000DD8460: CB18D3B5 6364E1BC
	v_dual_dot2acc_f32_f16 v99, v182, v106 :: v_dual_dot2acc_f32_f16 v100, v189, v113// 000000DD8468: CB18D5B6 6364E3BD
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000DD8470: BF8700C1
	v_dot2acc_f32_f16 v99, v183, v107                          // 000000DD8474: 04C6D7B7
	ds_load_b128 v[101:104], v92 offset:2592                   // 000000DD8478: DBFC0A20 6500005C
	ds_load_b128 v[105:108], v92 offset:2608                   // 000000DD8480: DBFC0A30 6900005C
	v_dot2acc_f32_f16 v100, v190, v114                         // 000000DD8488: 04C8E5BE
	v_dot2acc_f32_f16 v100, v191, v115                         // 000000DD848C: 04C8E7BF
	ds_load_b128 v[109:112], v92 offset:2816                   // 000000DD8490: DBFC0B00 6D00005C
	ds_load_b128 v[113:116], v92 offset:2832                   // 000000DD8498: DBFC0B10 7100005C
	s_waitcnt lgkmcnt(3)                                       // 000000DD84A0: BF89FC37
	v_dual_dot2acc_f32_f16 v100, v192, v101 :: v_dual_mov_b32 v101, 0// 000000DD84A4: CB10CBC0 64640080
	s_waitcnt lgkmcnt(1)                                       // 000000DD84AC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD84B0: BF870091
	v_dual_dot2acc_f32_f16 v100, v193, v102 :: v_dual_dot2acc_f32_f16 v101, v200, v109// 000000DD84B4: CB18CDC1 6464DBC8
	v_dual_dot2acc_f32_f16 v100, v194, v103 :: v_dual_dot2acc_f32_f16 v101, v201, v110// 000000DD84BC: CB18CFC2 6464DDC9
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD84C4: BF870091
	v_dual_dot2acc_f32_f16 v100, v195, v104 :: v_dual_dot2acc_f32_f16 v101, v202, v111// 000000DD84C8: CB18D1C3 6464DFCA
	v_dual_dot2acc_f32_f16 v100, v196, v105 :: v_dual_dot2acc_f32_f16 v101, v203, v112// 000000DD84D0: CB18D3C4 6464E1CB
	s_waitcnt lgkmcnt(0)                                       // 000000DD84D8: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD84DC: BF870091
	v_dual_dot2acc_f32_f16 v100, v197, v106 :: v_dual_dot2acc_f32_f16 v101, v204, v113// 000000DD84E0: CB18D5C5 6464E3CC
	v_dual_dot2acc_f32_f16 v100, v198, v107 :: v_dual_dot2acc_f32_f16 v101, v205, v114// 000000DD84E8: CB18D7C6 6464E5CD
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000DD84F0: BF8700C1
	v_dot2acc_f32_f16 v100, v199, v108                         // 000000DD84F4: 04C8D9C7
	ds_load_b128 v[102:105], v92 offset:2848                   // 000000DD84F8: DBFC0B20 6600005C
	ds_load_b128 v[106:109], v92 offset:2864                   // 000000DD8500: DBFC0B30 6A00005C
	v_dot2acc_f32_f16 v101, v206, v115                         // 000000DD8508: 04CAE7CE
	v_dot2acc_f32_f16 v101, v207, v116                         // 000000DD850C: 04CAE9CF
	ds_load_b128 v[110:113], v92 offset:3072                   // 000000DD8510: DBFC0C00 6E00005C
	ds_load_b128 v[114:117], v92 offset:3088                   // 000000DD8518: DBFC0C10 7200005C
	s_waitcnt lgkmcnt(3)                                       // 000000DD8520: BF89FC37
	v_dual_dot2acc_f32_f16 v101, v208, v102 :: v_dual_mov_b32 v102, 0// 000000DD8524: CB10CDD0 65660080
	s_waitcnt lgkmcnt(1)                                       // 000000DD852C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD8530: BF870091
	v_dual_dot2acc_f32_f16 v101, v209, v103 :: v_dual_dot2acc_f32_f16 v102, v216, v110// 000000DD8534: CB18CFD1 6566DDD8
	v_dual_dot2acc_f32_f16 v101, v210, v104 :: v_dual_dot2acc_f32_f16 v102, v217, v111// 000000DD853C: CB18D1D2 6566DFD9
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD8544: BF870091
	v_dual_dot2acc_f32_f16 v101, v211, v105 :: v_dual_dot2acc_f32_f16 v102, v218, v112// 000000DD8548: CB18D3D3 6566E1DA
	v_dual_dot2acc_f32_f16 v101, v212, v106 :: v_dual_dot2acc_f32_f16 v102, v219, v113// 000000DD8550: CB18D5D4 6566E3DB
	s_waitcnt lgkmcnt(0)                                       // 000000DD8558: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD855C: BF870091
	v_dual_dot2acc_f32_f16 v101, v213, v107 :: v_dual_dot2acc_f32_f16 v102, v220, v114// 000000DD8560: CB18D7D5 6566E5DC
	v_dual_dot2acc_f32_f16 v101, v214, v108 :: v_dual_dot2acc_f32_f16 v102, v221, v115// 000000DD8568: CB18D9D6 6566E7DD
	v_mov_b32_e32 v115, 0                                      // 000000DD8570: 7EE60280
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000DD8574: BF870152
	v_dot2acc_f32_f16 v101, v215, v109                         // 000000DD8578: 04CADBD7
	ds_load_b128 v[103:106], v92 offset:3104                   // 000000DD857C: DBFC0C20 6700005C
	ds_load_b128 v[107:110], v92 offset:3120                   // 000000DD8584: DBFC0C30 6B00005C
	v_dot2acc_f32_f16 v102, v222, v116                         // 000000DD858C: 04CCE9DE
	v_mov_b32_e32 v116, 0                                      // 000000DD8590: 7EE80280
	v_dual_dot2acc_f32_f16 v102, v223, v117 :: v_dual_mov_b32 v117, 0// 000000DD8594: CB10EBDF 66740080
	s_waitcnt lgkmcnt(1)                                       // 000000DD859C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD85A0: BF870091
	v_dot2acc_f32_f16 v102, v224, v103                         // 000000DD85A4: 04CCCFE0
	v_dot2acc_f32_f16 v102, v225, v104                         // 000000DD85A8: 04CCD1E1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD85AC: BF870091
	v_dot2acc_f32_f16 v102, v226, v105                         // 000000DD85B0: 04CCD3E2
	v_dot2acc_f32_f16 v102, v227, v106                         // 000000DD85B4: 04CCD5E3
	ds_load_b128 v[103:106], v92 offset:3328                   // 000000DD85B8: DBFC0D00 6700005C
	ds_load_b128 v[111:114], v92 offset:3344                   // 000000DD85C0: DBFC0D10 6F00005C
	s_waitcnt lgkmcnt(2)                                       // 000000DD85C8: BF89FC27
	v_dot2acc_f32_f16 v102, v228, v107                         // 000000DD85CC: 04CCD7E4
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DD85D0: BF8700A1
	v_dot2acc_f32_f16 v102, v229, v108                         // 000000DD85D4: 04CCD9E5
	s_waitcnt lgkmcnt(1)                                       // 000000DD85D8: BF89FC17
	v_dual_dot2acc_f32_f16 v102, v230, v109 :: v_dual_dot2acc_f32_f16 v115, v232, v103// 000000DD85DC: CB18DBE6 6672CFE8
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD85E4: BF870091
	v_dual_dot2acc_f32_f16 v102, v231, v110 :: v_dual_dot2acc_f32_f16 v115, v233, v104// 000000DD85E8: CB18DDE7 6672D1E9
	v_dot2acc_f32_f16 v115, v234, v105                         // 000000DD85F0: 04E6D3EA
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000DD85F4: BF8700D1
	v_dot2acc_f32_f16 v115, v235, v106                         // 000000DD85F8: 04E6D5EB
	ds_load_b128 v[103:106], v92 offset:3360                   // 000000DD85FC: DBFC0D20 6700005C
	ds_load_b128 v[107:110], v92 offset:3376                   // 000000DD8604: DBFC0D30 6B00005C
	s_waitcnt lgkmcnt(2)                                       // 000000DD860C: BF89FC27
	v_dot2acc_f32_f16 v115, v236, v111                         // 000000DD8610: 04E6DFEC
	v_dot2acc_f32_f16 v115, v237, v112                         // 000000DD8614: 04E6E1ED
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD8618: BF870091
	v_dot2acc_f32_f16 v115, v238, v113                         // 000000DD861C: 04E6E3EE
	v_dot2acc_f32_f16 v115, v239, v114                         // 000000DD8620: 04E6E5EF
	s_waitcnt lgkmcnt(1)                                       // 000000DD8624: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD8628: BF870091
	v_dot2acc_f32_f16 v115, v240, v103                         // 000000DD862C: 04E6CFF0
	v_dot2acc_f32_f16 v115, v241, v104                         // 000000DD8630: 04E6D1F1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD8634: BF870091
	v_dot2acc_f32_f16 v115, v242, v105                         // 000000DD8638: 04E6D3F2
	v_dot2acc_f32_f16 v115, v243, v106                         // 000000DD863C: 04E6D5F3
	ds_load_b128 v[103:106], v92 offset:3584                   // 000000DD8640: DBFC0E00 6700005C
	ds_load_b128 v[111:114], v92 offset:3600                   // 000000DD8648: DBFC0E10 6F00005C
	s_waitcnt lgkmcnt(2)                                       // 000000DD8650: BF89FC27
	v_dot2acc_f32_f16 v115, v244, v107                         // 000000DD8654: 04E6D7F4
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DD8658: BF8700A1
	v_dot2acc_f32_f16 v115, v245, v108                         // 000000DD865C: 04E6D9F5
	s_waitcnt lgkmcnt(1)                                       // 000000DD8660: BF89FC17
	v_dual_dot2acc_f32_f16 v115, v246, v109 :: v_dual_dot2acc_f32_f16 v116, v248, v103// 000000DD8664: CB18DBF6 7374CFF8
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD866C: BF870091
	v_dual_dot2acc_f32_f16 v115, v247, v110 :: v_dual_dot2acc_f32_f16 v116, v249, v104// 000000DD8670: CB18DDF7 7374D1F9
	v_dot2acc_f32_f16 v116, v250, v105                         // 000000DD8678: 04E8D3FA
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000DD867C: BF8700D1
	v_dot2acc_f32_f16 v116, v251, v106                         // 000000DD8680: 04E8D5FB
	ds_load_b128 v[103:106], v92 offset:3616                   // 000000DD8684: DBFC0E20 6700005C
	ds_load_b128 v[107:110], v92 offset:3632                   // 000000DD868C: DBFC0E30 6B00005C
	s_waitcnt lgkmcnt(2)                                       // 000000DD8694: BF89FC27
	v_dot2acc_f32_f16 v116, v252, v111                         // 000000DD8698: 04E8DFFC
	v_dot2acc_f32_f16 v116, v253, v112                         // 000000DD869C: 04E8E1FD
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD86A0: BF870091
	v_dot2acc_f32_f16 v116, v254, v113                         // 000000DD86A4: 04E8E3FE
	v_dot2acc_f32_f16 v116, v255, v114                         // 000000DD86A8: 04E8E5FF
	s_waitcnt lgkmcnt(1)                                       // 000000DD86AC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD86B0: BF870091
	v_dot2acc_f32_f16 v116, v1, v103                           // 000000DD86B4: 04E8CF01
	v_dot2acc_f32_f16 v116, v2, v104                           // 000000DD86B8: 04E8D102
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD86BC: BF870091
	v_dot2acc_f32_f16 v116, v28, v105                          // 000000DD86C0: 04E8D31C
	v_dot2acc_f32_f16 v116, v0, v106                           // 000000DD86C4: 04E8D500
	ds_load_b128 v[103:106], v92 offset:3840                   // 000000DD86C8: DBFC0F00 6700005C
	ds_load_b128 v[111:114], v92 offset:3856                   // 000000DD86D0: DBFC0F10 6F00005C
	s_waitcnt lgkmcnt(2)                                       // 000000DD86D8: BF89FC27
	v_dot2acc_f32_f16 v116, v5, v107                           // 000000DD86DC: 04E8D705
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DD86E0: BF8700A1
	v_dot2acc_f32_f16 v116, v29, v108                          // 000000DD86E4: 04E8D91D
	s_waitcnt lgkmcnt(1)                                       // 000000DD86E8: BF89FC17
	v_dual_dot2acc_f32_f16 v116, v6, v109 :: v_dual_dot2acc_f32_f16 v117, v7, v103// 000000DD86EC: CB18DB06 7474CF07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD86F4: BF870091
	v_dual_dot2acc_f32_f16 v116, v30, v110 :: v_dual_dot2acc_f32_f16 v117, v31, v104// 000000DD86F8: CB18DD1E 7474D11F
	v_dot2acc_f32_f16 v117, v8, v105                           // 000000DD8700: 04EAD308
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000DD8704: BF8700D1
	v_dot2acc_f32_f16 v117, v32, v106                          // 000000DD8708: 04EAD520
	ds_load_b128 v[103:106], v92 offset:3872                   // 000000DD870C: DBFC0F20 6700005C
	ds_load_b128 v[107:110], v92 offset:3888                   // 000000DD8714: DBFC0F30 6B00005C
	s_waitcnt lgkmcnt(2)                                       // 000000DD871C: BF89FC27
	v_dot2acc_f32_f16 v117, v33, v111                          // 000000DD8720: 04EADF21
	v_dot2acc_f32_f16 v117, v34, v112                          // 000000DD8724: 04EAE122
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD8728: BF870091
	v_dot2acc_f32_f16 v117, v35, v113                          // 000000DD872C: 04EAE323
	v_dot2acc_f32_f16 v117, v36, v114                          // 000000DD8730: 04EAE524
	s_waitcnt lgkmcnt(1)                                       // 000000DD8734: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD8738: BF870091
	v_dot2acc_f32_f16 v117, v3, v103                           // 000000DD873C: 04EACF03
	v_dot2acc_f32_f16 v117, v37, v104                          // 000000DD8740: 04EAD125
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD8744: BF870091
	v_dot2acc_f32_f16 v117, v4, v105                           // 000000DD8748: 04EAD304
	v_dot2acc_f32_f16 v117, v9, v106                           // 000000DD874C: 04EAD509
	ds_load_b128 v[103:106], v92 offset:4096                   // 000000DD8750: DBFC1000 6700005C
	ds_load_b128 v[111:114], v92 offset:4112                   // 000000DD8758: DBFC1010 6F00005C
	s_waitcnt lgkmcnt(2)                                       // 000000DD8760: BF89FC27
	v_dot2acc_f32_f16 v117, v10, v107                          // 000000DD8764: 04EAD70A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DD8768: BF8700A1
	v_dot2acc_f32_f16 v117, v11, v108                          // 000000DD876C: 04EAD90B
	s_waitcnt lgkmcnt(1)                                       // 000000DD8770: BF89FC17
	v_dual_dot2acc_f32_f16 v117, v12, v109 :: v_dual_dot2acc_f32_f16 v118, v14, v103// 000000DD8774: CB18DB0C 7576CF0E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD877C: BF870091
	v_dual_dot2acc_f32_f16 v117, v13, v110 :: v_dual_dot2acc_f32_f16 v118, v15, v104// 000000DD8780: CB18DD0D 7576D10F
	v_dot2acc_f32_f16 v118, v16, v105                          // 000000DD8788: 04ECD310
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000DD878C: BF8700D1
	v_dot2acc_f32_f16 v118, v17, v106                          // 000000DD8790: 04ECD511
	ds_load_b128 v[103:106], v92 offset:4128                   // 000000DD8794: DBFC1020 6700005C
	ds_load_b128 v[107:110], v92 offset:4144                   // 000000DD879C: DBFC1030 6B00005C
	s_waitcnt lgkmcnt(2)                                       // 000000DD87A4: BF89FC27
	v_dot2acc_f32_f16 v118, v18, v111                          // 000000DD87A8: 04ECDF12
	v_dot2acc_f32_f16 v118, v19, v112                          // 000000DD87AC: 04ECE113
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD87B0: BF870091
	v_dot2acc_f32_f16 v118, v20, v113                          // 000000DD87B4: 04ECE314
	v_dot2acc_f32_f16 v118, v21, v114                          // 000000DD87B8: 04ECE515
	s_waitcnt lgkmcnt(1)                                       // 000000DD87BC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD87C0: BF870091
	v_dot2acc_f32_f16 v118, v22, v103                          // 000000DD87C4: 04ECCF16
	v_dot2acc_f32_f16 v118, v23, v104                          // 000000DD87C8: 04ECD117
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD87CC: BF870091
	v_dot2acc_f32_f16 v118, v24, v105                          // 000000DD87D0: 04ECD318
	v_dot2acc_f32_f16 v118, v38, v106                          // 000000DD87D4: 04ECD526
	ds_load_b128 v[103:106], v92 offset:4352                   // 000000DD87D8: DBFC1100 6700005C
	ds_load_b128 v[111:114], v92 offset:4368                   // 000000DD87E0: DBFC1110 6F00005C
	s_waitcnt lgkmcnt(2)                                       // 000000DD87E8: BF89FC27
	v_dot2acc_f32_f16 v118, v39, v107                          // 000000DD87EC: 04ECD727
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DD87F0: BF8700A1
	v_dot2acc_f32_f16 v118, v40, v108                          // 000000DD87F4: 04ECD928
	s_waitcnt lgkmcnt(1)                                       // 000000DD87F8: BF89FC17
	v_dual_dot2acc_f32_f16 v118, v41, v109 :: v_dual_dot2acc_f32_f16 v119, v43, v103// 000000DD87FC: CB18DB29 7676CF2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD8804: BF870091
	v_dual_dot2acc_f32_f16 v118, v42, v110 :: v_dual_dot2acc_f32_f16 v119, v44, v104// 000000DD8808: CB18DD2A 7676D12C
	v_dot2acc_f32_f16 v119, v45, v105                          // 000000DD8810: 04EED32D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000DD8814: BF8700D1
	v_dot2acc_f32_f16 v119, v46, v106                          // 000000DD8818: 04EED52E
	ds_load_b128 v[103:106], v92 offset:4384                   // 000000DD881C: DBFC1120 6700005C
	ds_load_b128 v[107:110], v92 offset:4400                   // 000000DD8824: DBFC1130 6B00005C
	s_waitcnt lgkmcnt(2)                                       // 000000DD882C: BF89FC27
	v_dot2acc_f32_f16 v119, v47, v111                          // 000000DD8830: 04EEDF2F
	v_dot2acc_f32_f16 v119, v48, v112                          // 000000DD8834: 04EEE130
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD8838: BF870091
	v_dot2acc_f32_f16 v119, v49, v113                          // 000000DD883C: 04EEE331
	v_dot2acc_f32_f16 v119, v50, v114                          // 000000DD8840: 04EEE532
	s_waitcnt lgkmcnt(1)                                       // 000000DD8844: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD8848: BF870091
	v_dot2acc_f32_f16 v119, v51, v103                          // 000000DD884C: 04EECF33
	v_dot2acc_f32_f16 v119, v52, v104                          // 000000DD8850: 04EED134
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD8854: BF870091
	v_dot2acc_f32_f16 v119, v53, v105                          // 000000DD8858: 04EED335
	v_dot2acc_f32_f16 v119, v54, v106                          // 000000DD885C: 04EED536
	ds_load_b128 v[103:106], v92 offset:4608                   // 000000DD8860: DBFC1200 6700005C
	ds_load_b128 v[111:114], v92 offset:4624                   // 000000DD8868: DBFC1210 6F00005C
	s_waitcnt lgkmcnt(2)                                       // 000000DD8870: BF89FC27
	v_dot2acc_f32_f16 v119, v55, v107                          // 000000DD8874: 04EED737
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DD8878: BF8700A1
	v_dot2acc_f32_f16 v119, v56, v108                          // 000000DD887C: 04EED938
	s_waitcnt lgkmcnt(1)                                       // 000000DD8880: BF89FC17
	v_dual_dot2acc_f32_f16 v119, v57, v109 :: v_dual_dot2acc_f32_f16 v120, v59, v103// 000000DD8884: CB18DB39 7778CF3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD888C: BF870091
	v_dual_dot2acc_f32_f16 v119, v58, v110 :: v_dual_dot2acc_f32_f16 v120, v60, v104// 000000DD8890: CB18DD3A 7778D13C
	v_dot2acc_f32_f16 v120, v61, v105                          // 000000DD8898: 04F0D33D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000DD889C: BF8700D1
	v_dot2acc_f32_f16 v120, v62, v106                          // 000000DD88A0: 04F0D53E
	ds_load_b128 v[103:106], v92 offset:4864                   // 000000DD88A4: DBFC1300 6700005C
	ds_load_b128 v[107:110], v92 offset:4880                   // 000000DD88AC: DBFC1310 6B00005C
	s_waitcnt lgkmcnt(2)                                       // 000000DD88B4: BF89FC27
	v_dot2acc_f32_f16 v120, v63, v111                          // 000000DD88B8: 04F0DF3F
	v_dot2acc_f32_f16 v120, v64, v112                          // 000000DD88BC: 04F0E140
	s_waitcnt lgkmcnt(1)                                       // 000000DD88C0: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD88C4: BF870091
	v_dual_dot2acc_f32_f16 v120, v65, v113 :: v_dual_dot2acc_f32_f16 v27, v75, v103// 000000DD88C8: CB18E341 781ACF4B
	v_dual_dot2acc_f32_f16 v120, v66, v114 :: v_dual_dot2acc_f32_f16 v27, v76, v104// 000000DD88D0: CB18E542 781AD14C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD88D8: BF870091
	v_dot2acc_f32_f16 v27, v77, v105                           // 000000DD88DC: 0436D34D
	v_dot2acc_f32_f16 v27, v78, v106                           // 000000DD88E0: 0436D54E
	ds_load_b128 v[103:106], v92 offset:4640                   // 000000DD88E4: DBFC1220 6700005C
	ds_load_b128 v[111:114], v92 offset:4656                   // 000000DD88EC: DBFC1230 6F00005C
	s_waitcnt lgkmcnt(2)                                       // 000000DD88F4: BF89FC27
	v_dot2acc_f32_f16 v27, v79, v107                           // 000000DD88F8: 0436D74F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DD88FC: BF8700A1
	v_dot2acc_f32_f16 v27, v80, v108                           // 000000DD8900: 0436D950
	s_waitcnt lgkmcnt(1)                                       // 000000DD8904: BF89FC17
	v_dual_dot2acc_f32_f16 v27, v81, v109 :: v_dual_dot2acc_f32_f16 v120, v67, v103// 000000DD8908: CB18DB51 1B78CF43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD8910: BF870091
	v_dual_dot2acc_f32_f16 v27, v82, v110 :: v_dual_dot2acc_f32_f16 v120, v68, v104// 000000DD8914: CB18DD52 1B78D144
	v_dot2acc_f32_f16 v120, v69, v105                          // 000000DD891C: 04F0D345
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DD8920: BF870001
	v_dot2acc_f32_f16 v120, v70, v106                          // 000000DD8924: 04F0D546
	ds_load_b128 v[103:106], v92 offset:4896                   // 000000DD8928: DBFC1320 6700005C
	ds_load_b128 v[107:110], v92 offset:4912                   // 000000DD8930: DBFC1330 6B00005C
	scratch_load_b32 v92, off, off                             // 000000DD8938: DC510000 5C7C0000
	s_waitcnt lgkmcnt(2)                                       // 000000DD8940: BF89FC27
	v_dot2acc_f32_f16 v120, v71, v111                          // 000000DD8944: 04F0DF47
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD8948: BF870091
	v_dot2acc_f32_f16 v120, v72, v112                          // 000000DD894C: 04F0E148
	v_dot2acc_f32_f16 v120, v73, v113                          // 000000DD8950: 04F0E349
	s_waitcnt lgkmcnt(1)                                       // 000000DD8954: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD8958: BF870091
	v_dual_dot2acc_f32_f16 v120, v74, v114 :: v_dual_dot2acc_f32_f16 v27, v83, v103// 000000DD895C: CB18E54A 781ACF53
	v_dot2acc_f32_f16 v27, v84, v104                           // 000000DD8964: 0436D154
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD8968: BF870091
	v_dot2acc_f32_f16 v27, v85, v105                           // 000000DD896C: 0436D355
	v_dot2acc_f32_f16 v27, v86, v106                           // 000000DD8970: 0436D556
	s_waitcnt lgkmcnt(0)                                       // 000000DD8974: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD8978: BF870091
	v_dot2acc_f32_f16 v27, v87, v107                           // 000000DD897C: 0436D757
	v_dot2acc_f32_f16 v27, v88, v108                           // 000000DD8980: 0436D958
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD8984: BF870091
	v_dot2acc_f32_f16 v27, v89, v109                           // 000000DD8988: 0436DB59
	v_dot2acc_f32_f16 v27, v90, v110                           // 000000DD898C: 0436DD5A
	s_waitcnt vmcnt(0)                                         // 000000DD8990: BF8903F7
	v_fma_f32 v91, v92, v91, 0                                 // 000000DD8994: D613005B 0202B75C
	scratch_load_b32 v92, off, off offset:4                    // 000000DD899C: DC510004 5C7C0000
	s_waitcnt vmcnt(0)                                         // 000000DD89A4: BF8903F7
	v_fmac_f32_e32 v91, v92, v25                               // 000000DD89A8: 56B6335C
	scratch_load_b32 v25, off, off offset:8                    // 000000DD89AC: DC510008 197C0000
	s_waitcnt vmcnt(0)                                         // 000000DD89B4: BF8903F7
	v_fmac_f32_e32 v91, v25, v93                               // 000000DD89B8: 56B6BB19
	scratch_load_b32 v25, off, off offset:12                   // 000000DD89BC: DC51000C 197C0000
	s_waitcnt vmcnt(0)                                         // 000000DD89C4: BF8903F7
	v_fmac_f32_e32 v91, v25, v26                               // 000000DD89C8: 56B63519
	scratch_load_b32 v25, off, off offset:16                   // 000000DD89CC: DC510010 197C0000
	s_waitcnt vmcnt(0)                                         // 000000DD89D4: BF8903F7
	v_fmac_f32_e32 v91, v25, v94                               // 000000DD89D8: 56B6BD19
	scratch_load_b32 v25, off, off offset:20                   // 000000DD89DC: DC510014 197C0000
	s_waitcnt vmcnt(0)                                         // 000000DD89E4: BF8903F7
	v_fmac_f32_e32 v91, v25, v95                               // 000000DD89E8: 56B6BF19
	scratch_load_b32 v25, off, off offset:24                   // 000000DD89EC: DC510018 197C0000
	s_waitcnt vmcnt(0)                                         // 000000DD89F4: BF8903F7
	v_fmac_f32_e32 v91, v25, v96                               // 000000DD89F8: 56B6C119
	scratch_load_b32 v25, off, off offset:28                   // 000000DD89FC: DC51001C 197C0000
	s_waitcnt vmcnt(0)                                         // 000000DD8A04: BF8903F7
	v_fmac_f32_e32 v91, v25, v97                               // 000000DD8A08: 56B6C319
	scratch_load_b32 v25, off, off offset:32                   // 000000DD8A0C: DC510020 197C0000
	s_waitcnt vmcnt(0)                                         // 000000DD8A14: BF8903F7
	v_fmac_f32_e32 v91, v25, v98                               // 000000DD8A18: 56B6C519
	scratch_load_b32 v25, off, off offset:36                   // 000000DD8A1C: DC510024 197C0000
	s_waitcnt vmcnt(0)                                         // 000000DD8A24: BF8903F7
	v_fmac_f32_e32 v91, v25, v99                               // 000000DD8A28: 56B6C719
	scratch_load_b32 v25, off, off offset:40                   // 000000DD8A2C: DC510028 197C0000
	s_waitcnt vmcnt(0)                                         // 000000DD8A34: BF8903F7
	v_fmac_f32_e32 v91, v25, v100                              // 000000DD8A38: 56B6C919
	scratch_load_b32 v25, off, off offset:44                   // 000000DD8A3C: DC51002C 197C0000
	s_waitcnt vmcnt(0)                                         // 000000DD8A44: BF8903F7
	v_fmac_f32_e32 v91, v25, v101                              // 000000DD8A48: 56B6CB19
	scratch_load_b32 v25, off, off offset:48                   // 000000DD8A4C: DC510030 197C0000
	s_waitcnt vmcnt(0)                                         // 000000DD8A54: BF8903F7
	v_fmac_f32_e32 v91, v25, v102                              // 000000DD8A58: 56B6CD19
	scratch_load_b32 v25, off, off offset:52                   // 000000DD8A5C: DC510034 197C0000
	s_waitcnt vmcnt(0)                                         // 000000DD8A64: BF8903F7
	v_fmac_f32_e32 v91, v25, v115                              // 000000DD8A68: 56B6E719
	scratch_load_b32 v25, off, off offset:56                   // 000000DD8A6C: DC510038 197C0000
	s_waitcnt vmcnt(0)                                         // 000000DD8A74: BF8903F7
	v_fmac_f32_e32 v91, v25, v116                              // 000000DD8A78: 56B6E919
	scratch_load_b32 v25, off, off offset:60                   // 000000DD8A7C: DC51003C 197C0000
	s_waitcnt vmcnt(0)                                         // 000000DD8A84: BF8903F7
	v_fmac_f32_e32 v91, v25, v117                              // 000000DD8A88: 56B6EB19
	scratch_load_b32 v25, off, off offset:344                  // 000000DD8A8C: DC510158 197C0000
	s_waitcnt vmcnt(0)                                         // 000000DD8A94: BF8903F7
	v_fmac_f32_e32 v91, v25, v118                              // 000000DD8A98: 56B6ED19
	scratch_load_b32 v25, off, off offset:348                  // 000000DD8A9C: DC51015C 197C0000
	s_waitcnt vmcnt(0)                                         // 000000DD8AA4: BF8903F7
	v_fmac_f32_e32 v91, v25, v119                              // 000000DD8AA8: 56B6EF19
	scratch_load_b32 v25, off, off offset:352                  // 000000DD8AAC: DC510160 197C0000
	s_waitcnt vmcnt(0)                                         // 000000DD8AB4: BF8903F7
	v_fmac_f32_e32 v91, v25, v120                              // 000000DD8AB8: 56B6F119
	scratch_load_b32 v25, off, off offset:356                  // 000000DD8ABC: DC510164 197C0000
	s_waitcnt vmcnt(0)                                         // 000000DD8AC4: BF8903F7
	v_fmac_f32_e32 v91, v25, v27                               // 000000DD8AC8: 56B63719
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD8ACC: BF870091
	v_mov_b32_dpp v25, v91 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DD8AD0: 7E3202FA FF01615B
	v_add_f32_e32 v25, v91, v25                                // 000000DD8AD8: 0632335B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DD8ADC: BF870001
	v_mov_b32_dpp v26, v25 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DD8AE0: 7E3402FA FF016219
	s_and_saveexec_b32 s2, vcc_lo                              // 000000DD8AE8: BE82206A
	s_cbranch_execz 64522                                      // 000000DD8AEC: BFA5FC0A <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi1ELi4EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x6618>
	scratch_load_b64 v[91:92], off, off offset:472             // 000000DD8AF0: DC5501D8 5B7C0000
	s_lshl_b32 s4, s1, 2                                       // 000000DD8AF8: 84048201
	v_add_f32_e32 v25, v25, v26                                // 000000DD8AFC: 06323519
	v_mov_b32_e32 v27, s4                                      // 000000DD8B00: 7E360204
	ds_load_b32 v27, v27 offset:25600                          // 000000DD8B04: D8D86400 1B00001B
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000DD8B0C: BF890007
	v_mad_i64_i32 v[91:92], null, 0x1400, v27, v[91:92]        // 000000DD8B10: D6FF7C5B 056E36FF 00001400
	global_store_b32 v[91:92], v25, off                        // 000000DD8B1C: DC6A0000 007C195B
	s_branch 64508                                             // 000000DD8B24: BFA0FBFC <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi1ELi4EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x6618>
	scratch_load_b32 v65, off, off offset:480                  // 000000DD8B28: DC5101E0 417C0000
	s_mul_hi_i32 s1, s0, 0x66666667                            // 000000DD8B30: 9701FF00 66666667
	s_waitcnt vmcnt(0)                                         // 000000DD8B38: BF8903F7
	s_waitcnt_vscnt null, 0x0                                  // 000000DD8B3C: BC7C0000
	buffer_gl1_inv                                             // 000000DD8B40: E0B00000 00000000
	buffer_gl0_inv                                             // 000000DD8B48: E0AC0000 00000000
	s_lshr_b32 s2, s1, 31                                      // 000000DD8B50: 85029F01
	s_lshr_b32 s1, s1, 2                                       // 000000DD8B54: 85018201
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 000000DD8B58: BF8704D9
	s_add_i32 s1, s1, s2                                       // 000000DD8B5C: 81010201
	s_barrier                                                  // 000000DD8B60: BFBD0000
	s_mul_i32 s1, s1, 10                                       // 000000DD8B64: 96018A01
	buffer_gl0_inv                                             // 000000DD8B68: E0AC0000 00000000
	s_sub_i32 s0, s0, s1                                       // 000000DD8B70: 81800100
	s_bfe_u32 s1, s0, 0x10007                                  // 000000DD8B74: 9301FF00 00010007
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000DD8B7C: BF870499
	s_add_i32 s0, s0, s1                                       // 000000DD8B80: 81000100
	s_bfe_i32 s0, s0, 0x80000                                  // 000000DD8B84: 9380FF00 00080000
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000DD8B8C: BF870499
	s_sext_i32_i16 s0, s0                                      // 000000DD8B90: BE800F00
	s_ashr_i32 s8, s0, 1                                       // 000000DD8B94: 86088100
	s_mov_b32 s0, exec_lo                                      // 000000DD8B98: BE80007E
	.long 0xd4cc007e                                           // 000000DD8B9C: D4CC007E
	v_cndmask_b32_e32 v1, s3, v65, vcc_lo                      // 000000DD8BA0: 02028203
	s_cbranch_execz 24                                         // 000000DD8BA4: BFA50018 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi1ELi4EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x7708>
	v_dual_mov_b32 v3, 1 :: v_dual_lshlrev_b32 v2, 2, v65      // 000000DD8BA8: CA220081 03028282
	ds_load_b32 v0, v2 offset:25600                            // 000000DD8BB0: D8D86400 00000002
	s_waitcnt lgkmcnt(0)                                       // 000000DD8BB8: BF89FC07
	v_mad_u64_u32 v[0:1], null, v0, 5, s[8:9]                  // 000000DD8BBC: D6FE7C00 00210B00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD8BC4: BF870091
	v_ashrrev_i32_e32 v1, 31, v0                               // 000000DD8BC8: 3402009F
	.long 0xd73c0000                                           // 000000DD8BCC: D73C0000
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 000000DD8BD0: 02020082
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD8BD4: BF870091
	.long 0xd7006a00                                           // 000000DD8BD8: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 000000DD8BDC: 02020010
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 000000DD8BE0: D5207C01 01AA0211
	global_atomic_add_u32 v0, v[0:1], v3, off glc              // 000000DD8BE8: DCD64000 007C0300
	s_waitcnt vmcnt(0)                                         // 000000DD8BF0: BF8903F7
	v_cmp_eq_u32_e32 vcc_lo, 3, v0                             // 000000DD8BF4: 7C940083
	v_cndmask_b32_e64 v0, 0, 1, vcc_lo                         // 000000DD8BF8: D5010000 01A90280
	ds_store_b32 v2, v0 offset:25616                           // 000000DD8C00: D8346410 00000002
	s_or_b32 exec_lo, exec_lo, s0                              // 000000DD8C08: 8C7E007E
	v_lshrrev_b32_e32 v0, 5, v65                               // 000000DD8C0C: 32008285
	s_waitcnt lgkmcnt(0)                                       // 000000DD8C10: BF89FC07
	s_barrier                                                  // 000000DD8C14: BFBD0000
	buffer_gl0_inv                                             // 000000DD8C18: E0AC0000 00000000
	s_mov_b32 s0, exec_lo                                      // 000000DD8C20: BE80007E
	.long 0xd4c4007e                                           // 000000DD8C24: D4C4007E
	v_cndmask_b32_e32 v1, s3, v0, vcc_lo                       // 000000DD8C28: 02020003
	s_cbranch_execz 665                                        // 000000DD8C2C: BFA50299 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi1ELi4EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x8194>
	v_lshlrev_b32_e32 v0, 2, v0                                // 000000DD8C30: 30000082
	ds_load_b32 v1, v0 offset:25616                            // 000000DD8C34: D8D86410 01000000
	s_waitcnt lgkmcnt(0)                                       // 000000DD8C3C: BF89FC07
	v_cmp_ne_u32_e32 vcc_lo, 0, v1                             // 000000DD8C40: 7C9A0280
	s_and_b32 exec_lo, exec_lo, vcc_lo                         // 000000DD8C44: 8B7E6A7E
	s_cbranch_execz 658                                        // 000000DD8C48: BFA50292 <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi1ELi4EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x8194>
	v_add_nc_u32_e32 v0, 0x6410, v0                            // 000000DD8C4C: 4A0000FF 00006410
	buffer_gl1_inv                                             // 000000DD8C54: E0B00000 00000000
	buffer_gl0_inv                                             // 000000DD8C5C: E0AC0000 00000000
	s_lshl_b32 s10, s8, 7                                      // 000000DD8C64: 840A8708
	v_and_b32_e32 v1, 31, v65                                  // 000000DD8C68: 3602829F
	s_ashr_i32 s11, s10, 31                                    // 000000DD8C6C: 860B9F0A
	v_add_nc_u32_e32 v0, -16, v0                               // 000000DD8C70: 4A0000D0
	s_lshl_b64 s[0:1], s[10:11], 2                             // 000000DD8C74: 8480820A
	s_mov_b32 s9, 0x76543210                                   // 000000DD8C78: BE8900FF 76543210
	v_lshlrev_b32_e32 v4, 4, v1                                // 000000DD8C80: 30080284
	ds_load_b32 v0, v0                                         // 000000DD8C84: D8D80000 00000000
	s_waitcnt lgkmcnt(0)                                       // 000000DD8C8C: BF89FC07
	v_mad_i64_i32 v[2:3], null, 0x1400, v0, s[48:49]           // 000000DD8C90: D6FF7C02 00C200FF 00001400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD8C9C: BF870091
	.long 0xd7006a02                                           // 000000DD8CA0: D7006A02
	v_cndmask_b32_e32 v0, v2, v0, vcc_lo                       // 000000DD8CA4: 02000102
	v_add_co_ci_u32_e64 v3, null, s1, v3, vcc_lo               // 000000DD8CA8: D5207C03 01AA0601
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD8CB0: BF870092
	.long 0xd7006a02                                           // 000000DD8CB4: D7006A02
	v_cndmask_b32_e32 v1, v2, v4, vcc_lo                       // 000000DD8CB8: 02020902
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 000000DD8CBC: D5207C03 01AA0680
	s_clause 0x7                                               // 000000DD8CC4: BF850007
	global_load_b32 v8, v[2:3], off glc                        // 000000DD8CC8: DC524000 087C0002
	global_load_b32 v9, v[2:3], off offset:2560 glc            // 000000DD8CD0: DC524A00 097C0002
	global_load_b32 v10, v[2:3], off offset:4 glc              // 000000DD8CD8: DC524004 0A7C0002
	global_load_b32 v11, v[2:3], off offset:2564 glc           // 000000DD8CE0: DC524A04 0B7C0002
	global_load_b32 v12, v[2:3], off offset:8 glc              // 000000DD8CE8: DC524008 0C7C0002
	global_load_b32 v13, v[2:3], off offset:2568 glc           // 000000DD8CF0: DC524A08 0D7C0002
	global_load_b32 v14, v[2:3], off offset:12 glc             // 000000DD8CF8: DC52400C 0E7C0002
	global_load_b32 v15, v[2:3], off offset:2572 glc           // 000000DD8D00: DC524A0C 0F7C0002
	v_and_b32_e32 v16, 1, v65                                  // 000000DD8D08: 36208281
	v_and_b32_e32 v17, 2, v65                                  // 000000DD8D0C: 36228282
	v_and_b32_e32 v19, 8, v65                                  // 000000DD8D10: 36268288
	s_waitcnt vmcnt(5)                                         // 000000DD8D14: BF8917F7
	v_add_f32_e32 v21, v8, v10                                 // 000000DD8D18: 062A1508
	v_sub_f32_e32 v8, v8, v10                                  // 000000DD8D1C: 08101508
	v_lshl_or_b32 v2, v1, 2, s10                               // 000000DD8D20: D6560002 00290501
	s_waitcnt vmcnt(1)                                         // 000000DD8D28: BF8907F7
	v_add_f32_e32 v10, v12, v14                                // 000000DD8D2C: 06141D0C
	v_sub_f32_e32 v12, v12, v14                                // 000000DD8D30: 08181D0C
	v_add_f32_e32 v14, v9, v11                                 // 000000DD8D34: 061C1709
	v_ashrrev_i32_e32 v3, 31, v2                               // 000000DD8D38: 3406049F
	v_sub_f32_e32 v9, v9, v11                                  // 000000DD8D3C: 08121709
	s_waitcnt vmcnt(0)                                         // 000000DD8D40: BF8903F7
	v_add_f32_e32 v11, v13, v15                                // 000000DD8D44: 06161F0D
	v_dual_sub_f32 v13, v13, v15 :: v_dual_add_f32 v22, v8, v12// 000000DD8D48: C9481F0D 0D161908
	.long 0xd73c0002                                           // 000000DD8D50: D73C0002
	v_cndmask_b32_e32 v1, 1, v2, vcc_lo                        // 000000DD8D54: 02020481
	.long 0xd44a0000                                           // 000000DD8D58: D44A0000
	v_cndmask_b32_e32 v1, 0, v16, vcc_lo                       // 000000DD8D5C: 02022080
	v_and_b32_e32 v20, 16, v65                                 // 000000DD8D60: 36288290
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000DD8D64: BF8700C4
	v_add_f32_e32 v16, v9, v13                                 // 000000DD8D68: 06201B09
	v_sub_f32_e32 v9, v9, v13                                  // 000000DD8D6C: 08121B09
	v_dual_add_f32 v15, v21, v10 :: v_dual_and_b32 v18, 4, v65 // 000000DD8D70: C9241515 0F128284
	.long 0xd7006a04                                           // 000000DD8D78: D7006A04
	v_cndmask_b32_e32 v1, s50, v2, vcc_lo                      // 000000DD8D7C: 02020432
	v_add_co_ci_u32_e64 v5, null, s51, v3, vcc_lo              // 000000DD8D80: D5207C05 01AA0633
	s_clause 0x1                                               // 000000DD8D88: BF850001
	global_load_b64 v[6:7], v[4:5], off                        // 000000DD8D8C: DC560000 067C0004
	global_load_b64 v[4:5], v[4:5], off offset:1280            // 000000DD8D94: DC560500 047C0004
	.long 0xd7006a02                                           // 000000DD8D9C: D7006A02
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 000000DD8DA0: 0202040C
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DD8DA4: BF870001
	v_add_co_ci_u32_e64 v3, null, s13, v3, vcc_lo              // 000000DD8DA8: D5207C03 01AA060D
	v_mov_b32_dpp v27, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DD8DB0: 7E3602FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 000000DD8DB8: D5010009 20021309
	v_sub_f32_e32 v8, v8, v12                                  // 000000DD8DC0: 08101908
	global_load_b64 v[2:3], v[2:3], off                        // 000000DD8DC4: DC560000 027C0002
	v_add_f32_e32 v12, v14, v11                                // 000000DD8DCC: 0618170E
	v_sub_f32_e32 v11, v14, v11                                // 000000DD8DD0: 0816170E
	v_mov_b32_dpp v13, v15 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DD8DD4: 7E1A02FA FF01610F
	v_cndmask_b32_e64 v14, -v15, v15, s0                       // 000000DD8DDC: D501000E 20021F0F
	v_sub_f32_e32 v10, v21, v10                                // 000000DD8DE4: 08141515
	v_mov_b32_dpp v15, v22 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DD8DE8: 7E1E02FA FF016116
	v_mov_b32_dpp v26, v11 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DD8DF0: 7E3402FA FF01610B
	v_cndmask_b32_e64 v11, -v11, v11, s0                       // 000000DD8DF8: D501000B 2002170B
	v_cndmask_b32_e64 v21, -v22, v22, s0                       // 000000DD8E00: D5010015 20022D16
	.long 0xd44a0001                                           // 000000DD8E08: D44A0001
	v_cndmask_b32_e32 v1, 0, v17, vcc_lo                       // 000000DD8E0C: 02022280
	v_add_f32_e32 v13, v14, v13                                // 000000DD8E10: 061A1B0E
	v_mov_b32_dpp v22, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DD8E14: 7E2C02FA FF01610A
	v_add_f32_e32 v11, v11, v26                                // 000000DD8E1C: 0616350B
	v_cndmask_b32_e64 v10, -v10, v10, s0                       // 000000DD8E20: D501000A 2002150A
	v_add_f32_e32 v15, v21, v15                                // 000000DD8E28: 061E1F15
	v_add_f32_e32 v9, v9, v27                                  // 000000DD8E2C: 06123709
	v_mov_b32_dpp v23, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DD8E30: 7E2E02FA FF016108
	v_mov_b32_dpp v21, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DD8E38: 7E2A02FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 000000DD8E40: D501000B 2006170B
	v_cndmask_b32_e64 v8, -v8, v8, s0                          // 000000DD8E48: D5010008 20021108
	v_add_f32_e32 v10, v10, v22                                // 000000DD8E50: 06142D0A
	v_mov_b32_dpp v22, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DD8E54: 7E2C02FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 000000DD8E5C: D5010009 20061309
	v_add_f32_e32 v11, v11, v21                                // 000000DD8E64: 06162B0B
	v_mov_b32_dpp v24, v12 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DD8E68: 7E3002FA FF01610C
	v_cndmask_b32_e64 v12, -v12, v12, s0                       // 000000DD8E70: D501000C 2002190C
	.long 0xd44a0003                                           // 000000DD8E78: D44A0003
	v_cndmask_b32_e32 v1, 0, v18, vcc_lo                       // 000000DD8E7C: 02022480
	v_add_f32_e32 v9, v9, v22                                  // 000000DD8E80: 06122D09
	v_mov_b32_dpp v18, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DD8E84: 7E2402FA FF01640B
	.long 0xd44a0002                                           // 000000DD8E8C: D44A0002
	v_cndmask_b32_e32 v1, 0, v19, vcc_lo                       // 000000DD8E90: 02022680
	v_add_f32_e32 v12, v12, v24                                // 000000DD8E94: 0618310C
	v_mov_b32_dpp v24, v15 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DD8E98: 7E3002FA FF01620F
	v_cndmask_b32_e64 v15, -v15, v15, s1                       // 000000DD8EA0: D501000F 20061F0F
	v_cndmask_b32_e64 v11, -v11, v11, s3                       // 000000DD8EA8: D501000B 200E170B
	v_add_f32_e32 v8, v8, v23                                  // 000000DD8EB0: 06102F08
	v_mov_b32_dpp v23, v13 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DD8EB4: 7E2E02FA FF01620D
	v_cndmask_b32_e64 v13, -v13, v13, s1                       // 000000DD8EBC: D501000D 20061B0D
	v_add_f32_e32 v15, v15, v24                                // 000000DD8EC4: 061E310F
	v_mov_b32_dpp v25, v16 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DD8EC8: 7E3202FA FF016110
	v_cndmask_b32_e64 v16, -v16, v16, s0                       // 000000DD8ED0: D5010010 20022110
	v_mov_b32_dpp v14, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DD8ED8: 7E1C02FA FF01620C
	v_add_f32_e32 v13, v13, v23                                // 000000DD8EE0: 061A2F0D
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 000000DD8EE4: D501000C 2006190C
	v_mov_b32_dpp v23, v15 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DD8EEC: 7E2E02FA FF01640F
	v_add_f32_e32 v16, v16, v25                                // 000000DD8EF4: 06203310
	v_mov_b32_dpp v25, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DD8EF8: 7E3202FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 000000DD8F00: D501000A 2006150A
	v_mov_b32_dpp v22, v13 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DD8F08: 7E2C02FA FF01640D
	v_cndmask_b32_e64 v15, -v15, v15, s3                       // 000000DD8F10: D501000F 200E1F0F
	v_mov_b32_dpp v17, v16 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DD8F18: 7E2202FA FF016210
	v_cndmask_b32_e64 v16, -v16, v16, s1                       // 000000DD8F20: D5010010 20062110
	v_cndmask_b32_e64 v13, -v13, v13, s3                       // 000000DD8F28: D501000D 200E1B0D
	v_add_f32_e32 v10, v10, v25                                // 000000DD8F30: 0614330A
	v_mov_b32_dpp v21, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DD8F34: 7E2A02FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 000000DD8F3C: D5010009 200E1309
	v_add_f32_e32 v12, v12, v14                                // 000000DD8F44: 06181D0C
	v_dual_add_f32 v14, v16, v17 :: v_dual_add_f32 v15, v15, v23// 000000DD8F48: C9082310 0E0E2F0F
	v_add_f32_e32 v11, v11, v18                                // 000000DD8F50: 0616250B
	v_mov_b32_dpp v26, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DD8F54: 7E3402FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s1                          // 000000DD8F5C: D5010008 20061108
	v_add_f32_e32 v13, v13, v22                                // 000000DD8F64: 061A2D0D
	v_mov_b32_dpp v17, v14 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DD8F68: 7E2202FA FF01640E
	v_cndmask_b32_e64 v14, -v14, v14, s3                       // 000000DD8F70: D501000E 200E1D0E
	v_add_f32_e32 v9, v9, v21                                  // 000000DD8F78: 06122B09
	v_mov_b32_dpp v22, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DD8F7C: 7E2C02FA FF01680F
	v_mov_b32_dpp v21, v13 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DD8F84: 7E2A02FA FF01680D
	v_cndmask_b32_e64 v15, -v15, v15, s2                       // 000000DD8F8C: D501000F 200A1F0F
	v_cndmask_b32_e64 v13, -v13, v13, s2                       // 000000DD8F94: D501000D 200A1B0D
	v_add_f32_e32 v8, v8, v26                                  // 000000DD8F9C: 06103508
	v_mov_b32_dpp v16, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DD8FA0: 7E2002FA FF01640C
	v_cndmask_b32_e64 v12, -v12, v12, s3                       // 000000DD8FA8: D501000C 200E190C
	v_dual_add_f32 v14, v14, v17 :: v_dual_add_f32 v15, v15, v22// 000000DD8FB0: C908230E 0E0E2D0F
	v_mov_b32_dpp v18, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DD8FB8: 7E2402FA FF01680B
	v_cndmask_b32_e64 v11, -v11, v11, s2                       // 000000DD8FC0: D501000B 200A170B
	v_add_f32_e32 v13, v13, v21                                // 000000DD8FC8: 061A2B0D
	v_mov_b32_dpp v25, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DD8FCC: 7E3202FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, s3                          // 000000DD8FD4: D5010008 200E1108
	v_mov_b32_dpp v24, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DD8FDC: 7E3002FA FF01640A
	v_cndmask_b32_e64 v10, -v10, v10, s3                       // 000000DD8FE4: D501000A 200E150A
	v_dual_add_f32 v12, v12, v16 :: v_dual_add_f32 v11, v11, v18// 000000DD8FEC: C908210C 0C0A250B
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DD8FF4: BF870004
	v_add_f32_e32 v8, v8, v25                                  // 000000DD8FF8: 06103308
	v_mov_b32_dpp v17, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DD8FFC: 7E2202FA FF01680E
	v_cndmask_b32_e64 v14, -v14, v14, s2                       // 000000DD9004: D501000E 200A1D0E
	.long 0xd44a0004                                           // 000000DD900C: D44A0004
	v_cndmask_b32_e32 v1, 0, v20, vcc_lo                       // 000000DD9010: 02022880
	v_mov_b32_e32 v18, v15                                     // 000000DD9014: 7E24030F
	v_add_f32_e32 v10, v10, v24                                // 000000DD9018: 0614310A
	v_mov_b32_dpp v16, v12 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DD901C: 7E2002FA FF01680C
	v_cndmask_b32_e64 v12, -v12, v12, s2                       // 000000DD9024: D501000C 200A190C
	v_cndmask_b32_e64 v15, -v15, v15, s4                       // 000000DD902C: D501000F 20121F0F
	v_permlanex16_b32 v18, v18, s9, 0xfedcba98                 // 000000DD9034: D65C0012 03FC1312 FEDCBA98
	v_dual_add_f32 v14, v14, v17 :: v_dual_mov_b32 v17, v13    // 000000DD9040: C910230E 0E10010D
	v_mov_b32_dpp v24, v8 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DD9048: 7E3002FA FF016808
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 000000DD9050: D5010008 200A1108
	v_cndmask_b32_e64 v13, -v13, v13, s4                       // 000000DD9058: D501000D 20121B0D
	v_add_f32_e32 v15, v15, v18                                // 000000DD9060: 061E250F
	v_permlanex16_b32 v17, v17, s9, 0xfedcba98                 // 000000DD9064: D65C0011 03FC1311 FEDCBA98
	v_mov_b32_dpp v19, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DD9070: 7E2602FA FF016809
	v_add_f32_e32 v8, v8, v24                                  // 000000DD9078: 06103108
	v_cndmask_b32_e64 v9, -v9, v9, s2                          // 000000DD907C: D5010009 200A1309
	v_mul_f32_e32 v15, 0x3db504f3, v15                         // 000000DD9084: 101E1EFF 3DB504F3
	v_dual_add_f32 v13, v13, v17 :: v_dual_add_f32 v12, v12, v16// 000000DD908C: C908230D 0D0C210C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000DD9094: BF870234
	v_mov_b32_e32 v21, v8                                      // 000000DD9098: 7E2A0308
	v_mov_b32_dpp v23, v10 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DD909C: 7E2E02FA FF01680A
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 000000DD90A4: D501000A 200A150A
	v_mul_f32_e32 v13, 0x3db504f3, v13                         // 000000DD90AC: 101A1AFF 3DB504F3
	v_cndmask_b32_e64 v8, -v8, v8, s4                          // 000000DD90B4: D5010008 20121108
	v_permlanex16_b32 v21, v21, s9, 0xfedcba98                 // 000000DD90BC: D65C0015 03FC1315 FEDCBA98
	v_add_f32_e32 v9, v9, v19                                  // 000000DD90C8: 06122709
	v_add_f32_e32 v10, v10, v23                                // 000000DD90CC: 06142F0A
	v_mov_b32_e32 v17, v14                                     // 000000DD90D0: 7E22030E
	v_cndmask_b32_e64 v16, -v12, v12, s4                       // 000000DD90D4: D5010010 2012190C
	v_add_f32_e32 v8, v8, v21                                  // 000000DD90DC: 06102B08
	v_permlanex16_b32 v12, v12, s9, 0xfedcba98                 // 000000DD90E0: D65C000C 03FC130C FEDCBA98
	v_mov_b32_e32 v21, v9                                      // 000000DD90EC: 7E2A0309
	v_cndmask_b32_e64 v9, -v9, v9, s4                          // 000000DD90F0: D5010009 20121309
	v_permlanex16_b32 v17, v17, s9, 0xfedcba98                 // 000000DD90F8: D65C0011 03FC1311 FEDCBA98
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD9104: BF870093
	v_permlanex16_b32 v21, v21, s9, 0xfedcba98                 // 000000DD9108: D65C0015 03FC1315 FEDCBA98
	v_add_f32_e32 v9, v9, v21                                  // 000000DD9114: 06122B09
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DD9118: BF870001
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 000000DD911C: 101212FF 3DB504F3
	s_waitcnt vmcnt(2)                                         // 000000DD9124: BF890BF7
	v_fma_mix_f32 v13, v6, v13, neg(0) op_sel_hi:[1,0,0]       // 000000DD9128: CC20000D 8A021B06
	v_fma_mix_f32 v6, v6, v15, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DD9130: CC200806 8A021F06
	v_mov_b32_e32 v20, v10                                     // 000000DD9138: 7E28030A
	v_cndmask_b32_e64 v10, -v10, v10, s4                       // 000000DD913C: D501000A 2012150A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DD9144: BF870193
	v_mul_f32_e32 v15, 0xbfb8aa3b, v6                          // 000000DD9148: 101E0CFF BFB8AA3B
	v_permlanex16_b32 v20, v20, s9, 0xfedcba98                 // 000000DD9150: D65C0014 03FC1314 FEDCBA98
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD915C: BF870092
	v_exp_f32_e32 v15, v15                                     // 000000DD9160: 7E1E4B0F
	v_add_f32_e32 v10, v10, v20                                // 000000DD9164: 0614290A
	v_mov_b32_e32 v20, v11                                     // 000000DD9168: 7E28030B
	v_mul_f32_e32 v8, 0x3db504f3, v8                           // 000000DD916C: 101010FF 3DB504F3
	v_cndmask_b32_e64 v11, -v11, v11, s4                       // 000000DD9174: D501000B 2012170B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DD917C: BF870214
	v_mul_f32_e32 v10, 0x3db504f3, v10                         // 000000DD9180: 101414FF 3DB504F3
	v_permlanex16_b32 v20, v20, s9, 0xfedcba98                 // 000000DD9188: D65C0014 03FC1314 FEDCBA98
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DD9194: BF870195
	v_add_f32_e32 v15, 1.0, v15                                // 000000DD9198: 061E1EF2
	v_fma_mix_f32 v10, v7, v10, neg(0) op_sel_hi:[1,0,0]       // 000000DD919C: CC20000A 8A021507
	v_fma_mix_f32 v7, v7, v8, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DD91A4: CC200807 8A021107
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000DD91AC: BF870234
	v_add_f32_e32 v11, v11, v20                                // 000000DD91B0: 0616290B
	v_cndmask_b32_e64 v8, -v14, v14, s4                        // 000000DD91B4: D5010008 20121D0E
	v_div_scale_f32 v23, null, v15, v15, v6                    // 000000DD91BC: D6FC7C17 041A1F0F
	v_dual_mul_f32 v18, 0xbfb8aa3b, v10 :: v_dual_mul_f32 v19, 0xbfb8aa3b, v7// 000000DD91C4: C8C614FF 12120EFF BFB8AA3B
	v_div_scale_f32 v20, s5, v6, v15, v6                       // 000000DD91D0: D6FC0514 041A1F06
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DD91D8: BF870194
	v_dual_add_f32 v8, v8, v17 :: v_dual_mul_f32 v11, 0x3db504f3, v11// 000000DD91DC: C9062308 080A16FF 3DB504F3
	v_exp_f32_e32 v18, v18                                     // 000000DD91E8: 7E244B12
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(TRANS32_DEP_2)// 000000DD91EC: BF870343
	v_exp_f32_e32 v19, v19                                     // 000000DD91F0: 7E264B13
	v_mul_f32_e32 v14, 0xbfb8aa3b, v13                         // 000000DD91F4: 101C1AFF BFB8AA3B
	v_rcp_f32_e32 v26, v23                                     // 000000DD91FC: 7E345517
	v_mul_f32_e32 v8, 0x3db504f3, v8                           // 000000DD9200: 101010FF 3DB504F3
	v_dual_add_f32 v18, 1.0, v18 :: v_dual_add_f32 v19, 1.0, v19// 000000DD9208: C90824F2 121226F2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000DD9210: BF870313
	v_exp_f32_e32 v14, v14                                     // 000000DD9214: 7E1C4B0E
	v_fma_f32 v30, -v23, v26, 1.0                              // 000000DD9218: D613001E 23CA3517
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DD9220: BF870192
	v_div_scale_f32 v24, null, v18, v18, v10                   // 000000DD9224: D6FC7C18 042A2512
	v_div_scale_f32 v25, null, v19, v19, v7                    // 000000DD922C: D6FC7C19 041E2713
	v_div_scale_f32 v33, s7, v7, v19, v7                       // 000000DD9234: D6FC0721 041E2707
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DD923C: BF870214
	v_fmac_f32_e32 v26, v30, v26                               // 000000DD9240: 5634351E
	v_rcp_f32_e32 v27, v24                                     // 000000DD9244: 7E365518
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000DD9248: BF870313
	v_rcp_f32_e32 v28, v25                                     // 000000DD924C: 7E385519
	v_fma_f32 v31, -v24, v27, 1.0                              // 000000DD9250: D613001F 23CA3718
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000DD9258: BF870297
	v_add_f32_e32 v14, 1.0, v14                                // 000000DD925C: 061C1CF2
	v_fma_f32 v32, -v25, v28, 1.0                              // 000000DD9260: D6130020 23CA3919
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DD9268: BF870193
	v_fmac_f32_e32 v27, v31, v27                               // 000000DD926C: 5636371F
	v_div_scale_f32 v22, null, v14, v14, v13                   // 000000DD9270: D6FC7C16 04361D0E
	v_add_f32_e32 v12, v16, v12                                // 000000DD9278: 06181910
	v_div_scale_f32 v17, vcc_lo, v13, v14, v13                 // 000000DD927C: D6FC6A11 04361D0D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000DD9284: BF870293
	v_rcp_f32_e32 v16, v22                                     // 000000DD9288: 7E205516
	v_fma_f32 v29, -v22, v16, 1.0                              // 000000DD928C: D613001D 23CA2116
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD9294: BF870091
	v_fmac_f32_e32 v16, v29, v16                               // 000000DD9298: 5620211D
	v_mul_f32_e32 v29, v17, v16                                // 000000DD929C: 103A2111
	v_div_scale_f32 v21, s6, v10, v18, v10                     // 000000DD92A0: D6FC0615 042A250A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DD92A8: BF870112
	v_fma_f32 v34, -v22, v29, v17                              // 000000DD92AC: D6130022 24463B16
	v_dual_mul_f32 v31, v21, v27 :: v_dual_mul_f32 v12, 0x3db504f3, v12// 000000DD92B4: C8C63715 1F0C18FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DD92C0: BF870121
	v_fma_f32 v36, -v24, v31, v21                              // 000000DD92C4: D6130024 24563F18
	s_waitcnt vmcnt(1)                                         // 000000DD92CC: BF8907F7
	v_fma_mix_f32 v12, v4, v12, neg(0) op_sel_hi:[1,0,0]       // 000000DD92D0: CC20000C 8A021904
	v_fma_mix_f32 v4, v4, v8, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DD92D8: CC200804 8A021104
	v_fma_mix_f32 v8, v5, v9, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DD92E0: CC200808 8A021305
	v_fma_mix_f32 v5, v5, v11, neg(0) op_sel_hi:[1,0,0]        // 000000DD92E8: CC200005 8A021705
	v_fmac_f32_e32 v31, v36, v27                               // 000000DD92F0: 563E3724
	v_dual_mul_f32 v30, v20, v26 :: v_dual_fmac_f32 v29, v34, v16// 000000DD92F4: C8C03514 1E1C2122
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DD92FC: BF870112
	v_fma_f32 v21, -v24, v31, v21                              // 000000DD9300: D6130015 24563F18
	v_fma_f32 v35, -v23, v30, v20                              // 000000DD9308: D6130023 24523D17
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DD9310: BF870113
	v_fma_f32 v17, -v22, v29, v17                              // 000000DD9314: D6130011 24463B16
	v_fmac_f32_e32 v30, v35, v26                               // 000000DD931C: 563C3523
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000DD9320: BF870132
	v_div_fmas_f32 v16, v17, v16, v29                          // 000000DD9324: D6370010 04762111
	s_mov_b32 vcc_lo, s5                                       // 000000DD932C: BEEA0005
	s_mov_b32 s5, 0x3db504f3                                   // 000000DD9330: BE8500FF 3DB504F3
	v_fma_f32 v20, -v23, v30, v20                              // 000000DD9338: D6130014 24523D17
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DD9340: BF8701A2
	v_div_fixup_f32 v9, v16, v14, v13                          // 000000DD9344: D6270009 04361D10
	v_lshlrev_b32_e32 v13, 3, v1                               // 000000DD934C: 301A0283
	v_div_fmas_f32 v17, v20, v26, v30                          // 000000DD9350: D6370011 047A3514
	s_mov_b32 vcc_lo, s6                                       // 000000DD9358: BEEA0006
	v_div_fmas_f32 v20, v21, v27, v31                          // 000000DD935C: D6370014 047E3715
	s_mov_b32 vcc_lo, s7                                       // 000000DD9364: BEEA0007
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DD9368: BF870112
	v_div_fixup_f32 v6, v17, v15, v6                           // 000000DD936C: D6270006 041A1F11
	v_div_fixup_f32 v10, v20, v18, v10                         // 000000DD9374: D627000A 042A2514
	v_fmac_f32_e32 v28, v32, v28                               // 000000DD937C: 56383920
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DD9380: BF870193
	v_mul_f32_e32 v4, v4, v6                                   // 000000DD9384: 10080D04
	v_mul_f32_e32 v5, v5, v10                                  // 000000DD9388: 100A1505
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DD938C: BF8701A3
	v_mul_f32_e32 v32, v33, v28                                // 000000DD9390: 10403921
	s_waitcnt vmcnt(0)                                         // 000000DD9394: BF8903F7
	v_fma_mix_f32 v4, v2, v4, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DD9398: CC200804 8A020902
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD93A0: BF870092
	v_fma_f32 v37, -v25, v32, v33                              // 000000DD93A4: D6130025 24864119
	v_fmac_f32_e32 v32, v37, v28                               // 000000DD93AC: 56403925
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD93B0: BF870091
	v_fma_f32 v22, -v25, v32, v33                              // 000000DD93B4: D6130016 24864119
	v_div_fmas_f32 v21, v22, v28, v32                          // 000000DD93BC: D6370015 04823916
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD93C4: BF870091
	v_div_fixup_f32 v7, v21, v19, v7                           // 000000DD93C8: D6270007 041E2715
	v_mul_f32_e32 v6, v8, v7                                   // 000000DD93D0: 100C0F08
	v_mul_f32_e32 v7, v12, v9                                  // 000000DD93D4: 100E130C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DD93D8: BF870112
	v_fma_mix_f32 v6, v3, v6, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000DD93DC: CC200806 8A020D03
	v_fma_mix_f32 v8, v7, v2, v4 op_sel_hi:[0,1,0]             // 000000DD93E4: CC200008 14120507
	v_fma_mix_f32 v2, v7, v2, -v4 op_sel_hi:[0,1,0]            // 000000DD93EC: CC200002 94120507
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DD93F4: BF8700A3
	v_fma_mix_f32 v9, v5, v3, v6 op_sel_hi:[0,1,0]             // 000000DD93F8: CC200009 141A0705
	v_fma_mix_f32 v3, v5, v3, -v6 op_sel_hi:[0,1,0]            // 000000DD9400: CC200003 941A0705
	v_dual_add_f32 v4, v8, v9 :: v_dual_add_f32 v5, v2, v3     // 000000DD9408: C9081308 04040702
	v_sub_f32_e32 v2, v2, v3                                   // 000000DD9410: 08040702
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DD9414: BF870222
	v_mov_b32_dpp v3, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DD9418: 7E0602FA FF016104
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 000000DD9420: D5010004 20020904
	v_mov_b32_dpp v7, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DD9428: 7E0E02FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 000000DD9430: D5010005 20020B05
	v_cndmask_b32_e64 v10, -v2, v2, s0                         // 000000DD9438: D501000A 20020502
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DD9440: BF870194
	v_add_f32_e32 v3, v4, v3                                   // 000000DD9444: 06060704
	v_add_f32_e32 v4, v5, v7                                   // 000000DD9448: 06080F05
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DD944C: BF8700A2
	v_mov_b32_dpp v7, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DD9450: 7E0E02FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 000000DD9458: D5010003 20060703
	v_add_f32_e32 v3, v3, v7                                   // 000000DD9460: 06060F03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DD9464: BF8700A1
	v_mov_b32_dpp v7, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DD9468: 7E0E02FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 000000DD9470: D5010003 200E0703
	v_add_f32_e32 v3, v3, v7                                   // 000000DD9478: 06060F03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000DD947C: BF8701C1
	v_mov_b32_dpp v7, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DD9480: 7E0E02FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s2                          // 000000DD9488: D5010003 200A0703
	v_sub_f32_e32 v6, v8, v9                                   // 000000DD9490: 080C1308
	v_mov_b32_dpp v9, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DD9494: 7E1202FA FF016102
	v_add_f32_e32 v7, v3, v7                                   // 000000DD949C: 060E0F03
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DD94A0: BF8700A3
	v_mov_b32_dpp v8, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DD94A4: 7E1002FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s0                          // 000000DD94AC: D5010006 20020D06
	v_dual_mov_b32 v2, 0 :: v_dual_add_f32 v5, v6, v8          // 000000DD94B4: CA080080 02041106
	v_add_f32_e32 v6, v10, v9                                  // 000000DD94BC: 060C130A
	v_mov_b32_dpp v8, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DD94C0: 7E1002FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000DD94C8: D5010004 20060904
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DD94D0: BF870004
	v_mov_b32_dpp v9, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DD94D4: 7E1202FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s1                          // 000000DD94DC: D5010005 20060B05
	v_mov_b32_dpp v10, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DD94E4: 7E1402FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 000000DD94EC: D5010006 20060D06
	v_add_f32_e32 v4, v4, v8                                   // 000000DD94F4: 06081104
	s_lshl_b64 s[0:1], s[10:11], 1                             // 000000DD94F8: 8480810A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DD94FC: BF870112
	v_dual_add_f32 v5, v5, v9 :: v_dual_add_f32 v6, v6, v10    // 000000DD9500: C9081305 05061506
	v_mov_b32_dpp v8, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DD9508: 7E1002FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000DD9510: D5010004 200E0904
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000DD9518: BF8701C3
	v_mov_b32_dpp v9, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DD951C: 7E1202FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 000000DD9524: D5010005 200E0B05
	v_mov_b32_dpp v10, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DD952C: 7E1402FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s3                          // 000000DD9534: D5010006 200E0D06
	v_dual_add_f32 v4, v4, v8 :: v_dual_add_f32 v5, v5, v9     // 000000DD953C: C9081104 04041305
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DD9544: BF870112
	v_add_f32_e32 v6, v6, v10                                  // 000000DD9548: 060C1506
	v_mov_b32_dpp v8, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DD954C: 7E1002FA FF016804
	v_cndmask_b32_e64 v9, -v4, v4, s2                          // 000000DD9554: D5010009 200A0904
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000DD955C: BF870254
	v_mov_b32_dpp v10, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DD9560: 7E1402FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s2                          // 000000DD9568: D5010005 200A0B05
	v_mov_b32_dpp v11, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DD9570: 7E1602FA FF016806
	v_cndmask_b32_e64 v6, -v6, v6, s2                          // 000000DD9578: D5010006 200A0D06
	v_dual_add_f32 v8, v9, v8 :: v_dual_mov_b32 v9, v7         // 000000DD9580: C9101109 08080107
	v_add_f32_e32 v5, v5, v10                                  // 000000DD9588: 060A1505
	v_mad_i64_i32 v[3:4], null, 0x500, v0, s[14:15]            // 000000DD958C: D6FF7C03 003A00FF 00000500
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DD9598: BF870214
	v_add_f32_e32 v6, v6, v11                                  // 000000DD959C: 060C1706
	v_mov_b32_e32 v10, v8                                      // 000000DD95A0: 7E140308
	v_cndmask_b32_e64 v7, -v7, v7, s4                          // 000000DD95A4: D5010007 20120F07
	v_mov_b32_e32 v11, v5                                      // 000000DD95AC: 7E160305
	v_cndmask_b32_e64 v5, -v5, v5, s4                          // 000000DD95B0: D5010005 20120B05
	v_mov_b32_e32 v12, v6                                      // 000000DD95B8: 7E180306
	v_permlanex16_b32 v9, v9, s9, 0xfedcba98                   // 000000DD95BC: D65C0009 03FC1309 FEDCBA98
	v_cndmask_b32_e64 v8, -v8, v8, s4                          // 000000DD95C8: D5010008 20121108
	v_permlanex16_b32 v11, v11, s9, 0xfedcba98                 // 000000DD95D0: D65C000B 03FC130B FEDCBA98
	v_cndmask_b32_e64 v6, -v6, v6, s4                          // 000000DD95DC: D5010006 20120D06
	v_permlanex16_b32 v10, v10, s9, 0xfedcba98                 // 000000DD95E4: D65C000A 03FC130A FEDCBA98
	v_permlanex16_b32 v12, v12, s9, 0xfedcba98                 // 000000DD95F0: D65C000C 03FC130C FEDCBA98
	v_add_f32_e32 v7, v7, v9                                   // 000000DD95FC: 060E1307
	v_add_f32_e32 v5, v5, v11                                  // 000000DD9600: 060A1705
	.long 0xd7006a09                                           // 000000DD9604: D7006A09
	v_cndmask_b32_e32 v0, v3, v0, vcc_lo                       // 000000DD9608: 02000103
	v_add_f32_e32 v8, v8, v10                                  // 000000DD960C: 06101508
	v_add_f32_e32 v6, v6, v12                                  // 000000DD9610: 060C1906
	v_add_co_ci_u32_e64 v10, null, s1, v4, vcc_lo              // 000000DD9614: D5207C0A 01AA0801
	v_fma_mixlo_f16 v4, v5, s5, 0                              // 000000DD961C: CC210004 02000B05
	.long 0xd7006a05                                           // 000000DD9624: D7006A05
	v_cndmask_b32_e32 v1, v9, v13, vcc_lo                      // 000000DD9628: 02021B09
	v_fma_mixlo_f16 v3, v7, s5, 0                              // 000000DD962C: CC210003 02000B07
	v_fma_mixhi_f16 v3, v8, s5, 0                              // 000000DD9634: CC220003 02000B08
	v_fma_mixhi_f16 v4, v6, s5, 0                              // 000000DD963C: CC220004 02000B06
	v_add_co_ci_u32_e64 v6, null, 0, v10, vcc_lo               // 000000DD9644: D5207C06 01AA1480
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 000000DD964C: 7C940280
	global_store_b64 v[5:6], v[3:4], off                       // 000000DD9650: DC6E0000 007C0305
	s_and_b32 exec_lo, exec_lo, vcc_lo                         // 000000DD9658: 8B7E6A7E
	s_cbranch_execz 13                                         // 000000DD965C: BFA5000D <_ZN7halogen12_GLOBAL__N_115k_i4r_rows_gl_gILi1ELi4EEEvPKhlPKDF16_PKNS0_6HtItemEPKiSA_PfS5_S5_PDF16_PjNS0_5I4rSdEi+0x8194>
	v_mad_u64_u32 v[0:1], null, v0, 5, s[8:9]                  // 000000DD9660: D6FE7C00 00210B00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD9668: BF870091
	v_ashrrev_i32_e32 v1, 31, v0                               // 000000DD966C: 3402009F
	.long 0xd73c0000                                           // 000000DD9670: D73C0000
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 000000DD9674: 02020082
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DD9678: BF870091
	.long 0xd7006a00                                           // 000000DD967C: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 000000DD9680: 02020010
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 000000DD9684: D5207C01 01AA0211
	global_store_b32 v[0:1], v2, off                           // 000000DD968C: DC6A0000 007C0200
	s_nop 0                                                    // 000000DD9694: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000DD9698: BFB60003
	s_endpgm                                                   // 000000DD969C: BFB00000
		...

