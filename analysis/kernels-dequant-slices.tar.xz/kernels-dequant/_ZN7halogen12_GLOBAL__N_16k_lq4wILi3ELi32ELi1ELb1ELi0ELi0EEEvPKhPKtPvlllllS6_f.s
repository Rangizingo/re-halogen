0000000000746d00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi1ELb1ELi0ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi1ELb1ELi0ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000746D00: F4100100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 000000746D08: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 000000746D0C: 32040082
	s_lshl_b64 s[0:1], s[2:3], 3                               // 000000746D10: 84808302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000746D14: BF8701A9
	v_dual_mov_b32 v10, s1 :: v_dual_and_b32 v1, 15, v0        // 000000746D18: CA240001 0A00008F
	.long 0x7f103880                                           // 000000746D20: 7F103880
	v_and_b32_e32 v2, 60, v2                                   // 000000746D24: 360404BC
	s_delay_alu instid0(VALU_DEP_3)                            // 000000746D28: BF870003
	v_dual_mov_b32 v18, 0 :: v_dual_lshlrev_b32 v1, 2, v1      // 000000746D2C: CA220080 12000282
	v_dual_mov_b32 v3, 0 :: v_dual_and_b32 v16, 31, v0         // 000000746D34: CA240080 0310009F
	v_mov_b32_e32 v17, 0                                       // 000000746D3C: 7E220280
	s_waitcnt lgkmcnt(0)                                       // 000000746D40: BF89FC07
	s_clause 0x1                                               // 000000746D44: BF850001
	global_load_b32 v4, v1, s[4:5]                             // 000000746D48: DC520000 04040001
	global_load_b32 v7, v2, s[4:5]                             // 000000746D50: DC520000 07040002
	v_lshrrev_b32_e32 v2, 5, v0                                // 000000746D58: 32040085
	s_add_u32 s2, s4, s14                                      // 000000746D5C: 80020E04
	s_addc_u32 s3, s5, s15                                     // 000000746D60: 82030F05
	v_mov_b32_e32 v1, 0                                        // 000000746D64: 7E020280
	s_delay_alu instid0(VALU_DEP_2)                            // 000000746D68: BF870002
	v_or_b32_e32 v9, s0, v2                                    // 000000746D6C: 38120400
	s_lshr_b32 s0, s11, 31                                     // 000000746D70: 85009F0B
	v_mov_b32_e32 v2, 0                                        // 000000746D74: 7E040280
	s_add_u32 s14, s10, s0                                     // 000000746D78: 800E000A
	s_addc_u32 s15, s11, 0                                     // 000000746D7C: 820F800B
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[9:10]                 // 000000746D80: 7CA8120C
	s_ashr_i32 s20, s11, 31                                    // 000000746D84: 86149F0B
	v_cndmask_b32_e32 v11, 0, v9, vcc_lo                       // 000000746D88: 02161280
	v_cndmask_b32_e64 v14, 0, s1, vcc_lo                       // 000000746D8C: D501000E 01A80280
	s_ashr_i64 s[0:1], s[14:15], 1                             // 000000746D94: 8680810E
	s_lshr_b32 s14, s20, 27                                    // 000000746D98: 850E9B14
	s_delay_alu instid0(VALU_DEP_1)                            // 000000746D9C: BF870001
	.long 0xd72c0014                                           // 000000746DA0: D72C0014
	v_cndmask_b32_e32 v0, v14, v0, vcc_lo                      // 000000746DA4: 0200010E
	.long 0xd72c000e                                           // 000000746DA8: D72C000E
	v_cndmask_b32_e32 v1, s18, v14, vcc_lo                     // 000000746DAC: 02021C12
	s_waitcnt vmcnt(1)                                         // 000000746DB0: BF8907F7
	v_bfe_u32 v12, v4, 16, 1                                   // 000000746DB4: D610000C 02052104
	s_waitcnt vmcnt(0)                                         // 000000746DBC: BF8903F7
	v_bfe_u32 v19, v7, 16, 1                                   // 000000746DC0: D6100013 02052107
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000746DC8: BF870112
	v_add3_u32 v4, v4, v12, 0x7fff                             // 000000746DCC: D6550004 03FE1904 00007FFF
	v_add3_u32 v7, v7, v19, 0x7fff                             // 000000746DD8: D6550007 03FE2707 00007FFF
	v_lshlrev_b32_e32 v19, 2, v0                               // 000000746DE4: 30260082
	s_delay_alu instid0(VALU_DEP_3)                            // 000000746DE8: BF870003
	.long 0x7e103984                                           // 000000746DEC: 7E103984
	v_mov_b32_e32 v4, 0                                        // 000000746DF0: 7E080280
	.long 0xd72c000d                                           // 000000746DF4: D72C000D
	v_cndmask_b32_e32 v1, s19, v11, vcc_lo                     // 000000746DF8: 02021613
	v_mad_u64_u32 v[5:6], null, s18, v11, 0                    // 000000746DFC: D6FE7C05 02021612
	.long 0xd72c000f                                           // 000000746E04: D72C000F
	v_cndmask_b32_e32 v0, v11, v1, vcc_lo                      // 000000746E08: 0200030B
	v_mad_u64_u32 v[11:12], null, v11, s0, s[2:3]              // 000000746E0C: D6FE7C0B 0008010B
	s_add_u32 s2, s10, s14                                     // 000000746E14: 80020E0A
	s_addc_u32 s3, s11, 0                                      // 000000746E18: 8203800B
	v_and_or_b32 v7, 0xffff0000, v7, v8                        // 000000746E1C: D6570007 04220EFF FFFF0000
	s_lshr_b64 s[2:3], s[2:3], 5                               // 000000746E28: 85828502
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000746E2C: BF870009
	.long 0xd4440000                                           // 000000746E30: D4440000
	v_cndmask_b32_e32 v1, s2, v16, vcc_lo                      // 000000746E34: 02022002
	v_add3_u32 v6, v6, v14, v13                                // 000000746E38: D6550006 04361D06
	v_add3_u32 v0, v20, v12, v15                               // 000000746E40: D6550000 043E1914
	ds_store_b32 v19, v7                                       // 000000746E48: D8340000 00000713
	s_waitcnt lgkmcnt(0)                                       // 000000746E50: BF89FC07
	s_barrier                                                  // 000000746E54: BFBD0000
	buffer_gl0_inv                                             // 000000746E58: E0AC0000 00000000
	s_and_saveexec_b32 s3, s0                                  // 000000746E60: BE832000
	s_cbranch_execz 26                                         // 000000746E64: BFA5001A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi1ELb1ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x1d0>
	s_add_u32 s1, s4, s16                                      // 000000746E68: 80011004
	s_addc_u32 s14, s5, s17                                    // 000000746E6C: 820E1105
	v_lshlrev_b32_e32 v1, 1, v16                               // 000000746E70: 30022081
	.long 0xd7000102                                           // 000000746E74: D7000102
	v_cndmask_b32_e32 v1, s1, v5, vcc_lo                       // 000000746E78: 02020A01
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000746E7C: BF8701A1
	v_add_co_ci_u32_e64 v3, null, s14, v6, s1                  // 000000746E80: D5207C03 00060C0E
	v_lshlrev_b32_e32 v4, 4, v16                               // 000000746E88: 30082084
	.long 0xd7000101                                           // 000000746E8C: D7000101
	v_cndmask_b32_e32 v1, v2, v1, vcc_lo                       // 000000746E90: 02020302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000746E94: BF870191
	v_add_co_ci_u32_e64 v2, null, 0, v3, s1                    // 000000746E98: D5207C02 00060680
	.long 0xd7000103                                           // 000000746EA0: D7000103
	v_cndmask_b32_e32 v1, v11, v4, vcc_lo                      // 000000746EA4: 0202090B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000746EA8: BF870001
	v_add_co_ci_u32_e64 v4, null, 0, v0, s1                    // 000000746EAC: D5207C04 00060080
	s_clause 0x1                                               // 000000746EB4: BF850001
	global_load_d16_b16 v7, v[1:2], off                        // 000000746EB8: DC820000 077C0001
	global_load_b128 v[1:4], v[3:4], off                       // 000000746EC0: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 000000746EC8: BF8907F7
	v_cvt_f32_f16_e32 v18, v7                                  // 000000746ECC: 7E241707
	s_or_b32 exec_lo, exec_lo, s3                              // 000000746ED0: 8C7E037E
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v20, 0             // 000000746ED4: CA100080 13140080
	s_and_saveexec_b32 s3, s0                                  // 000000746EDC: BE832000
	s_cbranch_execz 331                                        // 000000746EE0: BFA5014B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi1ELb1ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x710>
	v_dual_mov_b32 v22, v16 :: v_dual_lshlrev_b32 v7, 1, v16   // 000000746EE4: CA220110 16062081
	.long 0xd7000005                                           // 000000746EEC: D7000005
	v_cndmask_b32_e32 v1, s16, v5, vcc_lo                      // 000000746EF0: 02020A10
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000746EF4: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s17, v6, s0                  // 000000746EF8: D5207C06 00020C11
	v_dual_mov_b32 v13, 0 :: v_dual_lshlrev_b32 v12, 5, v16    // 000000746F00: CA220080 0D0C2085
	.long 0xd7000005                                           // 000000746F08: D7000005
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 000000746F0C: 02020F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000746F10: BF8701A1
	v_add_co_ci_u32_e64 v6, null, 0, v6, s0                    // 000000746F14: D5207C06 00020C80
	v_lshl_or_b32 v21, v16, 4, 0x200                           // 000000746F1C: D6560015 03FD0910 00000200
	.long 0xd7000005                                           // 000000746F28: D7000005
	v_cndmask_b32_e32 v1, s4, v5, vcc_lo                       // 000000746F2C: 02020A04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000746F30: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s5, v6, s0                   // 000000746F34: D5207C06 00020C05
	v_dual_mov_b32 v20, v13 :: v_dual_mov_b32 v23, v18         // 000000746F3C: CA10010D 14160112
	.long 0xd700000e                                           // 000000746F44: D700000E
	v_cndmask_b32_e32 v0, v5, v192, vcc_lo                     // 000000746F48: 02018105
	s_delay_alu instid0(VALU_DEP_1)                            // 000000746F4C: BF870001
	v_add_co_ci_u32_e64 v15, null, 0, v6, s0                   // 000000746F50: D5207C0F 00020C80
	v_mov_b32_e32 v19, v13                                     // 000000746F58: 7E26030D
	v_mov_b32_e32 v17, v13                                     // 000000746F5C: 7E22030D
	s_lshl_b64 s[4:5], s[10:11], 2                             // 000000746F60: 8484820A
	s_mov_b32 s14, 0                                           // 000000746F64: BE8E0080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 000000746F68: 848A810A
	s_branch 270                                               // 000000746F6C: BFA0010E <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi1ELb1ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x6a8>
	s_or_b32 exec_lo, exec_lo, s15                             // 000000746F70: 8C7E0F7E
	.long 0xd73c0018                                           // 000000746F74: D73C0018
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 000000746F78: 02021881
	v_and_b32_e32 v72, 0xff, v1                                // 000000746F7C: 369002FF 000000FF
	v_lshrrev_b32_e32 v73, 6, v1                               // 000000746F84: 32920286
	v_lshrrev_b32_e32 v74, 14, v1                              // 000000746F88: 3294028E
	v_lshrrev_b32_e32 v1, 22, v1                               // 000000746F8C: 32020296
	v_and_b32_e32 v75, 0xff, v2                                // 000000746F90: 369604FF 000000FF
	.long 0xd700013c                                           // 000000746F98: D700013C
	v_cndmask_b32_e32 v1, s6, v24, vcc_lo                      // 000000746F9C: 02023006
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000746FA0: BF8701A1
	v_add_co_ci_u32_e64 v61, null, s7, v25, s1                 // 000000746FA4: D5207C3D 00063207
	v_lshlrev_b32_e32 v72, 2, v72                              // 000000746FAC: 30909082
	.long 0xd7000140                                           // 000000746FB0: D7000140
	v_cndmask_b32_e32 v0, v60, v10, vcc_lo                     // 000000746FB4: 0200153C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000746FB8: BF8700A1
	v_add_co_ci_u32_e64 v65, null, s11, v61, s1                // 000000746FBC: D5207C41 00067A0B
	.long 0xd7000144                                           // 000000746FC4: D7000144
	v_cndmask_b32_e32 v0, v60, v4, vcc_lo                      // 000000746FC8: 0200093C
	v_add_co_ci_u32_e64 v69, null, s5, v61, s1                 // 000000746FCC: D5207C45 00067A05
	s_clause 0xb                                               // 000000746FD4: BF85000B
	global_load_b128 v[24:27], v[60:61], off                   // 000000746FD8: DC5E0000 187C003C
	global_load_b128 v[28:31], v[64:65], off                   // 000000746FE0: DC5E0000 1C7C0040
	global_load_b128 v[32:35], v[68:69], off                   // 000000746FE8: DC5E0000 207C0044
	global_load_b128 v[36:39], v[60:61], off offset:16         // 000000746FF0: DC5E0010 247C003C
	global_load_b128 v[40:43], v[64:65], off offset:16         // 000000746FF8: DC5E0010 287C0040
	global_load_b128 v[44:47], v[68:69], off offset:16         // 000000747000: DC5E0010 2C7C0044
	global_load_b128 v[48:51], v[60:61], off offset:32         // 000000747008: DC5E0020 307C003C
	global_load_b128 v[52:55], v[64:65], off offset:32         // 000000747010: DC5E0020 347C0040
	global_load_b128 v[56:59], v[68:69], off offset:32         // 000000747018: DC5E0020 387C0044
	global_load_b128 v[60:63], v[60:61], off offset:48         // 000000747020: DC5E0030 3C7C003C
	global_load_b128 v[64:67], v[64:65], off offset:48         // 000000747028: DC5E0030 407C0040
	global_load_b128 v[68:71], v[68:69], off offset:48         // 000000747030: DC5E0030 447C0044
	v_and_b32_e32 v73, 0x3fc, v73                              // 000000747038: 369292FF 000003FC
	ds_load_b32 v72, v72                                       // 000000747040: D8D80000 48000048
	v_and_b32_e32 v74, 0x3fc, v74                              // 000000747048: 369494FF 000003FC
	v_lshrrev_b32_e32 v76, 6, v2                               // 000000747050: 32980486
	v_lshrrev_b32_e32 v77, 14, v2                              // 000000747054: 329A048E
	ds_load_b32 v73, v73                                       // 000000747058: D8D80000 49000049
	v_lshrrev_b32_e32 v2, 22, v2                               // 000000747060: 32040496
	ds_load_b32 v74, v74                                       // 000000747064: D8D80000 4A00004A
	v_and_b32_e32 v1, 0x3fc, v1                                // 00000074706C: 360202FF 000003FC
	v_lshlrev_b32_e32 v75, 2, v75                              // 000000747074: 30969682
	v_and_b32_e32 v76, 0x3fc, v76                              // 000000747078: 369898FF 000003FC
	v_and_b32_e32 v77, 0x3fc, v77                              // 000000747080: 369A9AFF 000003FC
	v_and_b32_e32 v2, 0x3fc, v2                                // 000000747088: 360404FF 000003FC
	ds_load_b32 v1, v1                                         // 000000747090: D8D80000 01000001
	ds_load_b32 v75, v75                                       // 000000747098: D8D80000 4B00004B
	ds_load_b32 v76, v76                                       // 0000007470A0: D8D80000 4C00004C
	ds_load_b32 v77, v77                                       // 0000007470A8: D8D80000 4D00004D
	ds_load_b32 v2, v2                                         // 0000007470B0: D8D80000 02000002
	v_and_b32_e32 v78, 0xff, v3                                // 0000007470B8: 369C06FF 000000FF
	v_lshrrev_b32_e32 v79, 6, v3                               // 0000007470C0: 329E0686
	v_lshrrev_b32_e32 v80, 14, v3                              // 0000007470C4: 32A0068E
	v_lshrrev_b32_e32 v3, 22, v3                               // 0000007470C8: 32060696
	v_and_b32_e32 v81, 0xff, v4                                // 0000007470CC: 36A208FF 000000FF
	v_lshrrev_b32_e32 v82, 14, v4                              // 0000007470D4: 32A4088E
	s_and_b32 s1, exec_lo, s0                                  // 0000007470D8: 8B01007E
	.long 0xd700000e                                           // 0000007470DC: D700000E
	v_cndmask_b32_e32 v0, v14, v192, vcc_lo                    // 0000007470E0: 0201810E
	v_and_b32_e32 v3, 0x3fc, v3                                // 0000007470E4: 360606FF 000003FC
	v_add_nc_u32_e32 v12, 0x400, v12                           // 0000007470EC: 4A1818FF 00000400
	v_add_nc_u32_e32 v21, 0x200, v21                           // 0000007470F4: 4A2A2AFF 00000200
	v_add_co_ci_u32_e64 v15, null, 0, v15, s0                  // 0000007470FC: D5207C0F 00021E80
	s_or_b32 s14, s1, s14                                      // 000000747104: 8C0E0E01
	s_waitcnt vmcnt(11) lgkmcnt(7)                             // 000000747108: BF892C77
	v_dot2_f32_bf16 v24, v24, v72, 0                           // 00000074710C: CC1A4018 1A029118
	s_waitcnt vmcnt(10)                                        // 000000747114: BF892BF7
	v_dot2_f32_bf16 v28, v28, v72, 0                           // 000000747118: CC1A401C 1A02911C
	s_waitcnt vmcnt(9)                                         // 000000747120: BF8927F7
	v_dot2_f32_bf16 v32, v32, v72, 0                           // 000000747124: CC1A4020 1A029120
	v_lshrrev_b32_e32 v72, 6, v4                               // 00000074712C: 32900886
	v_lshrrev_b32_e32 v4, 22, v4                               // 000000747130: 32080896
	s_waitcnt lgkmcnt(6)                                       // 000000747134: BF89FC67
	v_dot2_f32_bf16 v24, v25, v73, v24                         // 000000747138: CC1A4018 1C629319
	v_dot2_f32_bf16 v25, v29, v73, v28                         // 000000747140: CC1A4019 1C72931D
	v_dot2_f32_bf16 v28, v33, v73, v32                         // 000000747148: CC1A401C 1C829321
	v_lshlrev_b32_e32 v29, 2, v78                              // 000000747150: 303A9C82
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000747154: 360808FF 000003FC
	s_waitcnt lgkmcnt(5)                                       // 00000074715C: BF89FC57
	v_dot2_f32_bf16 v24, v26, v74, v24                         // 000000747160: CC1A4018 1C62951A
	v_dot2_f32_bf16 v25, v30, v74, v25                         // 000000747168: CC1A4019 1C66951E
	v_dot2_f32_bf16 v26, v34, v74, v28                         // 000000747170: CC1A401A 1C729522
	v_and_b32_e32 v28, 0x3fc, v79                              // 000000747178: 36389EFF 000003FC
	v_and_b32_e32 v30, 0x3fc, v80                              // 000000747180: 363CA0FF 000003FC
	s_waitcnt lgkmcnt(4)                                       // 000000747188: BF89FC47
	v_dot2_f32_bf16 v24, v27, v1, v24                          // 00000074718C: CC1A4018 1C62031B
	v_dot2_f32_bf16 v25, v31, v1, v25                          // 000000747194: CC1A4019 1C66031F
	v_dot2_f32_bf16 v1, v35, v1, v26                           // 00000074719C: CC1A4001 1C6A0323
	ds_load_b32 v27, v29                                       // 0000007471A4: D8D80000 1B00001D
	ds_load_b32 v30, v30                                       // 0000007471AC: D8D80000 1E00001E
	ds_load_b32 v28, v28                                       // 0000007471B4: D8D80000 1C00001C
	s_waitcnt vmcnt(8) lgkmcnt(6)                              // 0000007471BC: BF892067
	v_dot2_f32_bf16 v24, v36, v75, v24                         // 0000007471C0: CC1A4018 1C629724
	s_waitcnt vmcnt(7)                                         // 0000007471C8: BF891FF7
	v_dot2_f32_bf16 v25, v40, v75, v25                         // 0000007471CC: CC1A4019 1C669728
	s_waitcnt vmcnt(6)                                         // 0000007471D4: BF891BF7
	v_dot2_f32_bf16 v1, v44, v75, v1                           // 0000007471D8: CC1A4001 1C06972C
	v_lshlrev_b32_e32 v26, 2, v81                              // 0000007471E0: 3034A282
	v_and_b32_e32 v29, 0x3fc, v72                              // 0000007471E4: 363A90FF 000003FC
	s_waitcnt lgkmcnt(5)                                       // 0000007471EC: BF89FC57
	v_dot2_f32_bf16 v24, v37, v76, v24                         // 0000007471F0: CC1A4018 1C629925
	v_dot2_f32_bf16 v25, v41, v76, v25                         // 0000007471F8: CC1A4019 1C669929
	v_dot2_f32_bf16 v1, v45, v76, v1                           // 000000747200: CC1A4001 1C06992D
	v_and_b32_e32 v31, 0x3fc, v82                              // 000000747208: 363EA4FF 000003FC
	s_waitcnt lgkmcnt(4)                                       // 000000747210: BF89FC47
	v_dot2_f32_bf16 v24, v38, v77, v24                         // 000000747214: CC1A4018 1C629B26
	v_dot2_f32_bf16 v25, v42, v77, v25                         // 00000074721C: CC1A4019 1C669B2A
	v_dot2_f32_bf16 v1, v46, v77, v1                           // 000000747224: CC1A4001 1C069B2E
	s_waitcnt lgkmcnt(3)                                       // 00000074722C: BF89FC37
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000747230: BF870193
	v_dot2_f32_bf16 v24, v39, v2, v24                          // 000000747234: CC1A4018 1C620527
	v_dot2_f32_bf16 v25, v43, v2, v25                          // 00000074723C: CC1A4019 1C66052B
	s_delay_alu instid0(VALU_DEP_3)                            // 000000747244: BF870003
	v_dot2_f32_bf16 v1, v47, v2, v1                            // 000000747248: CC1A4001 1C06052F
	ds_load_b32 v2, v3                                         // 000000747250: D8D80000 02000003
	ds_load_b32 v3, v26                                        // 000000747258: D8D80000 0300001A
	ds_load_b32 v26, v29                                       // 000000747260: D8D80000 1A00001D
	ds_load_b32 v29, v31                                       // 000000747268: D8D80000 1D00001F
	ds_load_b32 v31, v4                                        // 000000747270: D8D80000 1F000004
	s_waitcnt vmcnt(5) lgkmcnt(7)                              // 000000747278: BF891477
	v_dot2_f32_bf16 v4, v48, v27, v24                          // 00000074727C: CC1A4004 1C623730
	s_waitcnt vmcnt(4)                                         // 000000747284: BF8913F7
	v_dot2_f32_bf16 v24, v52, v27, v25                         // 000000747288: CC1A4018 1C663734
	s_waitcnt vmcnt(3)                                         // 000000747290: BF890FF7
	v_dot2_f32_bf16 v1, v56, v27, v1                           // 000000747294: CC1A4001 1C063738
	s_waitcnt lgkmcnt(5)                                       // 00000074729C: BF89FC57
	v_dot2_f32_bf16 v4, v49, v28, v4                           // 0000007472A0: CC1A4004 1C123931
	v_dot2_f32_bf16 v24, v53, v28, v24                         // 0000007472A8: CC1A4018 1C623935
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007472B0: BF870193
	v_dot2_f32_bf16 v1, v57, v28, v1                           // 0000007472B4: CC1A4001 1C063939
	v_dot2_f32_bf16 v4, v50, v30, v4                           // 0000007472BC: CC1A4004 1C123D32
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007472C4: BF870193
	v_dot2_f32_bf16 v24, v54, v30, v24                         // 0000007472C8: CC1A4018 1C623D36
	v_dot2_f32_bf16 v1, v58, v30, v1                           // 0000007472D0: CC1A4001 1C063D3A
	s_waitcnt lgkmcnt(4)                                       // 0000007472D8: BF89FC47
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007472DC: BF870193
	v_dot2_f32_bf16 v4, v51, v2, v4                            // 0000007472E0: CC1A4004 1C120533
	v_dot2_f32_bf16 v24, v55, v2, v24                          // 0000007472E8: CC1A4018 1C620537
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007472F0: BF8701A3
	v_dot2_f32_bf16 v1, v59, v2, v1                            // 0000007472F4: CC1A4001 1C06053B
	s_waitcnt vmcnt(2) lgkmcnt(3)                              // 0000007472FC: BF890837
	v_dot2_f32_bf16 v2, v60, v3, v4                            // 000000747300: CC1A4002 1C12073C
	s_waitcnt vmcnt(1)                                         // 000000747308: BF8907F7
	v_dot2_f32_bf16 v4, v64, v3, v24                           // 00000074730C: CC1A4004 1C620740
	s_waitcnt vmcnt(0)                                         // 000000747314: BF8903F7
	v_dot2_f32_bf16 v1, v68, v3, v1                            // 000000747318: CC1A4001 1C060744
	s_waitcnt lgkmcnt(2)                                       // 000000747320: BF89FC27
	v_dot2_f32_bf16 v2, v61, v26, v2                           // 000000747324: CC1A4002 1C0A353D
	v_dot2_f32_bf16 v3, v65, v26, v4                           // 00000074732C: CC1A4003 1C123541
	s_delay_alu instid0(VALU_DEP_3)                            // 000000747334: BF870003
	v_dot2_f32_bf16 v1, v69, v26, v1                           // 000000747338: CC1A4001 1C063545
	v_mov_b32_e32 v4, v8                                       // 000000747340: 7E080308
	s_waitcnt lgkmcnt(1)                                       // 000000747344: BF89FC17
	v_dot2_f32_bf16 v2, v62, v29, v2                           // 000000747348: CC1A4002 1C0A3B3E
	v_dot2_f32_bf16 v24, v66, v29, v3                          // 000000747350: CC1A4018 1C0E3B42
	v_dot2_f32_bf16 v1, v70, v29, v1                           // 000000747358: CC1A4001 1C063B46
	v_mov_b32_e32 v3, v7                                       // 000000747360: 7E060307
	s_waitcnt lgkmcnt(0)                                       // 000000747364: BF89FC07
	v_dot2_f32_bf16 v7, v63, v31, v2                           // 000000747368: CC1A4007 1C0A3F3F
	v_dot2_f32_bf16 v8, v67, v31, v24                          // 000000747370: CC1A4008 1C623F43
	v_dot2_f32_bf16 v24, v71, v31, v1                          // 000000747378: CC1A4018 1C063F47
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v1, v5             // 000000747380: CA100106 02000105
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000747388: BF870214
	v_fmac_f32_e32 v20, v18, v7                                // 00000074738C: 56280F12
	v_fmac_f32_e32 v19, v18, v8                                // 000000747390: 56261112
	s_delay_alu instid0(VALU_DEP_4)                            // 000000747394: BF870004
	v_dual_fmac_f32 v17, v18, v24 :: v_dual_mov_b32 v18, v23   // 000000747398: C8103112 11120117
	s_and_not1_b32 exec_lo, exec_lo, s14                       // 0000007473A0: 917E0E7E
	s_cbranch_execz 25                                         // 0000007473A4: BFA50019 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi1ELb1ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x70c>
	s_waitcnt vmcnt(0)                                         // 0000007473A8: BF8903F7
	v_dual_mov_b32 v5, v1 :: v_dual_add_nc_u32 v22, 32, v22    // 0000007473AC: CA200101 05162CA0
	v_dual_mov_b32 v6, v2 :: v_dual_mov_b32 v7, v3             // 0000007473B4: CA100102 06060103
	v_mov_b32_e32 v8, v4                                       // 0000007473BC: 7E100304
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007473C0: BF870003
	.long 0xd4430000                                           // 0000007473C4: D4430000
	v_cndmask_b32_e32 v1, s2, v22, vcc_lo                      // 0000007473C8: 02022C02
	s_mov_b32 s15, exec_lo                                     // 0000007473CC: BE8F007E
	.long 0xd4c4007e                                           // 0000007473D0: D4C4007E
	v_cndmask_b32_e32 v1, s2, v22, vcc_lo                      // 0000007473D4: 02022C02
	s_cbranch_execz 65253                                      // 0000007473D8: BFA5FEE5 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi1ELb1ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x270>
	.long 0xd7000105                                           // 0000007473DC: D7000105
	v_cndmask_b32_e32 v1, v11, v21, vcc_lo                     // 0000007473E0: 02022B0B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007473E4: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v0, s1                    // 0000007473E8: D5207C06 00060080
	global_load_d16_b16 v23, v[14:15], off                     // 0000007473F0: DC820000 177C000E
	global_load_b128 v[5:8], v[5:6], off                       // 0000007473F8: DC5E0000 057C0005
	s_waitcnt vmcnt(1)                                         // 000000747400: BF8907F7
	v_cvt_f32_f16_e32 v23, v23                                 // 000000747404: 7E2E1717
	s_branch 65241                                             // 000000747408: BFA0FED9 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi1ELb1ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x270>
	s_or_b32 exec_lo, exec_lo, s14                             // 00000074740C: 8C7E0E7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000747410: BF8700B9
	s_or_b32 exec_lo, exec_lo, s3                              // 000000747414: 8C7E037E
	.long 0xd71f0000                                           // 000000747418: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000074741C: 020100C1
	s_waitcnt vmcnt(0)                                         // 000000747420: BF8903F7
	v_xor_b32_e32 v1, 16, v0                                   // 000000747424: 3A020090
	v_xor_b32_e32 v4, 8, v0                                    // 000000747428: 3A080088
	v_xor_b32_e32 v7, 4, v0                                    // 00000074742C: 3A0E0084
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000747430: BF870093
	.long 0xd44c0000                                           // 000000747434: D44C0000
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 000000747438: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s0                           // 00000074743C: D5010001 00020300
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000747444: BF870114
	.long 0xd44c0000                                           // 000000747448: D44C0000
	v_cndmask_b32_e32 v1, 32, v4, vcc_lo                       // 00000074744C: 020208A0
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000747450: 30020282
	s_delay_alu instid0(VALU_DEP_2)                            // 000000747454: BF870002
	v_cndmask_b32_e64 v4, v0, v4, s0                           // 000000747458: D5010004 00020900
	.long 0xd44c0000                                           // 000000747460: D44C0000
	v_cndmask_b32_e32 v1, 32, v7, vcc_lo                       // 000000747464: 02020EA0
	ds_bpermute_b32 v2, v1, v20                                // 000000747468: DACC0000 02001401
	v_cndmask_b32_e64 v7, v0, v7, s0                           // 000000747470: D5010007 00020F00
	s_waitcnt lgkmcnt(0)                                       // 000000747478: BF89FC07
	v_add_f32_e32 v2, v20, v2                                  // 00000074747C: 06040514
	ds_bpermute_b32 v3, v1, v19                                // 000000747480: DACC0000 03001301
	v_lshlrev_b32_e32 v4, 2, v4                                // 000000747488: 30080882
	ds_bpermute_b32 v1, v1, v17                                // 00000074748C: DACC0000 01001101
	s_waitcnt lgkmcnt(1)                                       // 000000747494: BF89FC17
	v_add_f32_e32 v3, v19, v3                                  // 000000747498: 06060713
	ds_bpermute_b32 v5, v4, v2                                 // 00000074749C: DACC0000 05000204
	v_lshlrev_b32_e32 v7, 2, v7                                // 0000007474A4: 300E0E82
	ds_bpermute_b32 v6, v4, v3                                 // 0000007474A8: DACC0000 06000304
	s_waitcnt lgkmcnt(1)                                       // 0000007474B0: BF89FC17
	v_add_f32_e32 v2, v2, v5                                   // 0000007474B4: 06040B02
	v_add_f32_e32 v1, v17, v1                                  // 0000007474B8: 06020311
	ds_bpermute_b32 v4, v4, v1                                 // 0000007474BC: DACC0000 04000104
	s_waitcnt lgkmcnt(0)                                       // 0000007474C4: BF89FC07
	v_add_f32_e32 v1, v1, v4                                   // 0000007474C8: 06020901
	ds_bpermute_b32 v4, v7, v2                                 // 0000007474CC: DACC0000 04000207
	s_waitcnt lgkmcnt(0)                                       // 0000007474D4: BF89FC07
	v_dual_add_f32 v2, v2, v4 :: v_dual_add_f32 v3, v3, v6     // 0000007474D8: C9080902 02020D03
	ds_bpermute_b32 v6, v7, v1                                 // 0000007474E0: DACC0000 06000107
	ds_bpermute_b32 v5, v7, v3                                 // 0000007474E8: DACC0000 05000307
	v_xor_b32_e32 v7, 2, v0                                    // 0000007474F0: 3A0E0082
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007474F4: BF870091
	.long 0xd44c0000                                           // 0000007474F8: D44C0000
	v_cndmask_b32_e32 v1, 32, v7, vcc_lo                       // 0000007474FC: 02020EA0
	v_cndmask_b32_e64 v7, v0, v7, s0                           // 000000747500: D5010007 00020F00
	s_waitcnt lgkmcnt(1)                                       // 000000747508: BF89FC17
	s_delay_alu instid0(VALU_DEP_1)                            // 00000074750C: BF870001
	v_dual_add_f32 v4, v1, v6 :: v_dual_lshlrev_b32 v7, 2, v7  // 000000747510: C9220D01 04060E82
	s_waitcnt lgkmcnt(0)                                       // 000000747518: BF89FC07
	v_add_f32_e32 v3, v3, v5                                   // 00000074751C: 06060B03
	ds_bpermute_b32 v1, v7, v2                                 // 000000747520: DACC0000 01000207
	ds_bpermute_b32 v6, v7, v4                                 // 000000747528: DACC0000 06000407
	ds_bpermute_b32 v5, v7, v3                                 // 000000747530: DACC0000 05000307
	v_xor_b32_e32 v7, 1, v0                                    // 000000747538: 3A0E0081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000074753C: BF870091
	.long 0xd44c0000                                           // 000000747540: D44C0000
	v_cndmask_b32_e32 v1, 32, v7, vcc_lo                       // 000000747544: 02020EA0
	v_cndmask_b32_e64 v0, v0, v7, s0                           // 000000747548: D5010000 00020F00
	.long 0xd44a0000                                           // 000000747550: D44A0000
	v_cndmask_b32_e32 v1, 0, v16, vcc_lo                       // 000000747554: 02022080
	s_waitcnt lgkmcnt(2)                                       // 000000747558: BF89FC27
	s_delay_alu instid0(VALU_DEP_2)                            // 00000074755C: BF870002
	v_dual_add_f32 v0, v2, v1 :: v_dual_lshlrev_b32 v7, 2, v0  // 000000747560: C9220302 00060082
	s_and_b32 s0, s0, vcc_lo                                   // 000000747568: 8B006A00
	s_waitcnt lgkmcnt(0)                                       // 00000074756C: BF89FC07
	v_add_f32_e32 v1, v3, v5                                   // 000000747570: 06020B03
	v_add_f32_e32 v3, v4, v6                                   // 000000747574: 06060D04
	ds_bpermute_b32 v2, v7, v0                                 // 000000747578: DACC0000 02000007
	ds_bpermute_b32 v4, v7, v1                                 // 000000747580: DACC0000 04000107
	ds_bpermute_b32 v5, v7, v3                                 // 000000747588: DACC0000 05000307
	s_and_saveexec_b32 s1, s0                                  // 000000747590: BE812000
	s_cbranch_execz 31                                         // 000000747594: BFA5001F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi1ELb1ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x914>
	.long 0xd73c0006                                           // 000000747598: D73C0006
	v_cndmask_b32_e32 v1, 2, v9, vcc_lo                        // 00000074759C: 02021282
	s_waitcnt lgkmcnt(2)                                       // 0000007475A0: BF89FC27
	v_add_f32_e32 v10, v0, v2                                  // 0000007475A4: 06140500
	s_waitcnt lgkmcnt(0)                                       // 0000007475A8: BF89FC07
	v_dual_add_f32 v8, v3, v5 :: v_dual_add_f32 v9, v1, v4     // 0000007475AC: C9080B03 08080901
	s_lshl_b64 s[0:1], s[12:13], 2                             // 0000007475B4: 8480820C
	.long 0xd7006a00                                           // 0000007475B8: D7006A00
	v_cndmask_b32_e32 v1, s8, v6, vcc_lo                       // 0000007475BC: 02020C08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007475C0: BF870111
	v_add_co_ci_u32_e64 v1, null, s9, v7, vcc_lo               // 0000007475C4: D5207C01 01AA0E09
	.long 0xd7006a02                                           // 0000007475CC: D7006A02
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 0000007475D0: 02000100
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000007475D4: BF8704A1
	v_add_co_ci_u32_e64 v3, null, s1, v1, vcc_lo               // 0000007475D8: D5207C03 01AA0201
	s_lshl_b64 s[0:1], s[12:13], 3                             // 0000007475E0: 8480830C
	.long 0xd7006a04                                           // 0000007475E4: D7006A04
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 0000007475E8: 02000100
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007475EC: BF870001
	v_add_co_ci_u32_e64 v5, null, s1, v1, vcc_lo               // 0000007475F0: D5207C05 01AA0201
	s_clause 0x2                                               // 0000007475F8: BF850002
	global_store_b32 v[0:1], v10, off                          // 0000007475FC: DC6A0000 007C0A00
	global_store_b32 v[2:3], v9, off                           // 000000747604: DC6A0000 007C0902
	global_store_b32 v[4:5], v8, off                           // 00000074760C: DC6A0000 007C0804
	s_endpgm                                                   // 000000747614: BFB00000
		...

