0000000000556800 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000556800: F4100100 F8000000
	v_and_b32_e32 v16, 15, v0                                  // 000000556808: 3620008F
	v_lshrrev_b32_e32 v1, 4, v0                                // 00000055680C: 32020084
	s_ashr_i32 s3, s2, 31                                      // 000000556810: 86039F02
	.long 0x7f103880                                           // 000000556814: 7F103880
	s_lshl_b64 s[0:1], s[2:3], 4                               // 000000556818: 84808402
	v_mov_b32_e32 v17, 0                                       // 00000055681C: 7E220280
	v_dual_mov_b32 v10, s1 :: v_dual_lshlrev_b32 v3, 2, v1     // 000000556820: CA220001 0A020282
	v_or_b32_e32 v9, s0, v1                                    // 000000556828: 38120200
	v_dual_mov_b32 v1, 0 :: v_dual_lshlrev_b32 v2, 2, v16      // 00000055682C: CA220080 01022082
	s_waitcnt lgkmcnt(0)                                       // 000000556834: BF89FC07
	s_clause 0x1                                               // 000000556838: BF850001
	global_load_b32 v4, v2, s[4:5]                             // 00000055683C: DC520000 04040002
	global_load_b32 v7, v3, s[4:5]                             // 000000556844: DC520000 07040003
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[9:10]                 // 00000055684C: 7CA8120C
	s_add_u32 s2, s4, s14                                      // 000000556850: 80020E04
	s_addc_u32 s3, s5, s15                                     // 000000556854: 82030F05
	s_lshr_b32 s0, s11, 31                                     // 000000556858: 85009F0B
	v_mov_b32_e32 v18, 0                                       // 00000055685C: 7E240280
	s_add_u32 s14, s10, s0                                     // 000000556860: 800E000A
	v_cndmask_b32_e32 v11, 0, v9, vcc_lo                       // 000000556864: 02161280
	v_cndmask_b32_e64 v14, 0, s1, vcc_lo                       // 000000556868: D501000E 01A80280
	s_addc_u32 s15, s11, 0                                     // 000000556870: 820F800B
	s_ashr_i32 s20, s11, 31                                    // 000000556874: 86149F0B
	s_ashr_i64 s[0:1], s[14:15], 1                             // 000000556878: 8680810E
	.long 0xd72c000d                                           // 00000055687C: D72C000D
	v_cndmask_b32_e32 v1, s19, v11, vcc_lo                     // 000000556880: 02021613
	v_mad_u64_u32 v[5:6], null, s18, v11, 0                    // 000000556884: D6FE7C05 02021612
	.long 0xd72c000f                                           // 00000055688C: D72C000F
	v_cndmask_b32_e32 v0, v11, v1, vcc_lo                      // 000000556890: 0200030B
	.long 0xd72c0014                                           // 000000556894: D72C0014
	v_cndmask_b32_e32 v0, v14, v0, vcc_lo                      // 000000556898: 0200010E
	.long 0xd72c000e                                           // 00000055689C: D72C000E
	v_cndmask_b32_e32 v1, s18, v14, vcc_lo                     // 0000005568A0: 02021C12
	s_lshr_b32 s14, s20, 27                                    // 0000005568A4: 850E9B14
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, 0               // 0000005568A8: CA100080 02020080
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000005568B0: BF870152
	v_add3_u32 v6, v6, v14, v13                                // 0000005568B4: D6550006 04361D06
	s_waitcnt vmcnt(1)                                         // 0000005568BC: BF8907F7
	v_bfe_u32 v12, v4, 16, 1                                   // 0000005568C0: D610000C 02052104
	s_waitcnt vmcnt(0)                                         // 0000005568C8: BF8903F7
	v_bfe_u32 v19, v7, 16, 1                                   // 0000005568CC: D6100013 02052107
	v_add3_u32 v4, v4, v12, 0x7fff                             // 0000005568D4: D6550004 03FE1904 00007FFF
	v_mad_u64_u32 v[11:12], null, v11, s0, s[2:3]              // 0000005568E0: D6FE7C0B 0008010B
	s_add_u32 s2, s10, s14                                     // 0000005568E8: 80020E0A
	v_add3_u32 v7, v7, v19, 0x7fff                             // 0000005568EC: D6550007 03FE2707 00007FFF
	s_addc_u32 s3, s11, 0                                      // 0000005568F8: 8203800B
	.long 0x7e103984                                           // 0000005568FC: 7E103984
	s_lshr_b64 s[2:3], s[2:3], 5                               // 000000556900: 85828502
	v_dual_mov_b32 v4, 0 :: v_dual_lshlrev_b32 v19, 2, v0      // 000000556904: CA220080 04120082
	.long 0xd4440000                                           // 00000055690C: D4440000
	v_cndmask_b32_e32 v1, s2, v16, vcc_lo                      // 000000556910: 02022002
	s_delay_alu instid0(VALU_DEP_3)                            // 000000556914: BF870003
	v_and_or_b32 v7, 0xffff0000, v7, v8                        // 000000556918: D6570007 04220EFF FFFF0000
	v_add3_u32 v0, v20, v12, v15                               // 000000556924: D6550000 043E1914
	ds_store_b32 v19, v7                                       // 00000055692C: D8340000 00000713
	s_waitcnt lgkmcnt(0)                                       // 000000556934: BF89FC07
	s_barrier                                                  // 000000556938: BFBD0000
	buffer_gl0_inv                                             // 00000055693C: E0AC0000 00000000
	s_and_saveexec_b32 s3, s0                                  // 000000556944: BE832000
	s_cbranch_execz 26                                         // 000000556948: BFA5001A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x1b4>
	s_add_u32 s1, s4, s16                                      // 00000055694C: 80011004
	s_addc_u32 s14, s5, s17                                    // 000000556950: 820E1105
	v_lshlrev_b32_e32 v1, 1, v16                               // 000000556954: 30022081
	.long 0xd7000102                                           // 000000556958: D7000102
	v_cndmask_b32_e32 v1, s1, v5, vcc_lo                       // 00000055695C: 02020A01
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000556960: BF8701A1
	v_add_co_ci_u32_e64 v3, null, s14, v6, s1                  // 000000556964: D5207C03 00060C0E
	v_lshlrev_b32_e32 v4, 4, v16                               // 00000055696C: 30082084
	.long 0xd7000101                                           // 000000556970: D7000101
	v_cndmask_b32_e32 v1, v2, v1, vcc_lo                       // 000000556974: 02020302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000556978: BF870191
	v_add_co_ci_u32_e64 v2, null, 0, v3, s1                    // 00000055697C: D5207C02 00060680
	.long 0xd7000103                                           // 000000556984: D7000103
	v_cndmask_b32_e32 v1, v11, v4, vcc_lo                      // 000000556988: 0202090B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000055698C: BF870001
	v_add_co_ci_u32_e64 v4, null, 0, v0, s1                    // 000000556990: D5207C04 00060080
	s_clause 0x1                                               // 000000556998: BF850001
	global_load_d16_b16 v7, v[1:2], off                        // 00000055699C: DC820000 077C0001
	global_load_b128 v[1:4], v[3:4], off                       // 0000005569A4: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 0000005569AC: BF8907F7
	v_cvt_f32_f16_e32 v18, v7                                  // 0000005569B0: 7E241707
	s_or_b32 exec_lo, exec_lo, s3                              // 0000005569B4: 8C7E037E
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v20, 0             // 0000005569B8: CA100080 13140080
	s_and_saveexec_b32 s3, s0                                  // 0000005569C0: BE832000
	s_cbranch_execz 331                                        // 0000005569C4: BFA5014B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x6f4>
	v_dual_mov_b32 v22, v16 :: v_dual_lshlrev_b32 v7, 1, v16   // 0000005569C8: CA220110 16062081
	.long 0xd7000005                                           // 0000005569D0: D7000005
	v_cndmask_b32_e32 v1, s16, v5, vcc_lo                      // 0000005569D4: 02020A10
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000005569D8: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s17, v6, s0                  // 0000005569DC: D5207C06 00020C11
	v_dual_mov_b32 v13, 0 :: v_dual_lshlrev_b32 v12, 5, v16    // 0000005569E4: CA220080 0D0C2085
	.long 0xd7000005                                           // 0000005569EC: D7000005
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 0000005569F0: 02020F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000005569F4: BF8701A1
	v_add_co_ci_u32_e64 v6, null, 0, v6, s0                    // 0000005569F8: D5207C06 00020C80
	v_lshl_or_b32 v21, v16, 4, 0x100                           // 000000556A00: D6560015 03FD0910 00000100
	.long 0xd7000005                                           // 000000556A0C: D7000005
	v_cndmask_b32_e32 v1, s4, v5, vcc_lo                       // 000000556A10: 02020A04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000556A14: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s5, v6, s0                   // 000000556A18: D5207C06 00020C05
	v_dual_mov_b32 v20, v13 :: v_dual_mov_b32 v23, v18         // 000000556A20: CA10010D 14160112
	.long 0xd700000e                                           // 000000556A28: D700000E
	v_cndmask_b32_e32 v0, v5, v160, vcc_lo                     // 000000556A2C: 02014105
	s_delay_alu instid0(VALU_DEP_1)                            // 000000556A30: BF870001
	v_add_co_ci_u32_e64 v15, null, 0, v6, s0                   // 000000556A34: D5207C0F 00020C80
	v_mov_b32_e32 v19, v13                                     // 000000556A3C: 7E26030D
	v_mov_b32_e32 v17, v13                                     // 000000556A40: 7E22030D
	s_lshl_b64 s[4:5], s[10:11], 2                             // 000000556A44: 8484820A
	s_mov_b32 s14, 0                                           // 000000556A48: BE8E0080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 000000556A4C: 848A810A
	s_branch 270                                               // 000000556A50: BFA0010E <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x68c>
	s_or_b32 exec_lo, exec_lo, s15                             // 000000556A54: 8C7E0F7E
	.long 0xd73c0018                                           // 000000556A58: D73C0018
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 000000556A5C: 02021881
	v_and_b32_e32 v72, 0xff, v1                                // 000000556A60: 369002FF 000000FF
	v_lshrrev_b32_e32 v73, 6, v1                               // 000000556A68: 32920286
	v_lshrrev_b32_e32 v74, 14, v1                              // 000000556A6C: 3294028E
	v_lshrrev_b32_e32 v1, 22, v1                               // 000000556A70: 32020296
	v_and_b32_e32 v75, 0xff, v2                                // 000000556A74: 369604FF 000000FF
	.long 0xd700013c                                           // 000000556A7C: D700013C
	v_cndmask_b32_e32 v1, s6, v24, vcc_lo                      // 000000556A80: 02023006
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000556A84: BF8701A1
	v_add_co_ci_u32_e64 v61, null, s7, v25, s1                 // 000000556A88: D5207C3D 00063207
	v_lshlrev_b32_e32 v72, 2, v72                              // 000000556A90: 30909082
	.long 0xd7000140                                           // 000000556A94: D7000140
	v_cndmask_b32_e32 v0, v60, v10, vcc_lo                     // 000000556A98: 0200153C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000556A9C: BF8700A1
	v_add_co_ci_u32_e64 v65, null, s11, v61, s1                // 000000556AA0: D5207C41 00067A0B
	.long 0xd7000144                                           // 000000556AA8: D7000144
	v_cndmask_b32_e32 v0, v60, v4, vcc_lo                      // 000000556AAC: 0200093C
	v_add_co_ci_u32_e64 v69, null, s5, v61, s1                 // 000000556AB0: D5207C45 00067A05
	s_clause 0xb                                               // 000000556AB8: BF85000B
	global_load_b128 v[24:27], v[60:61], off                   // 000000556ABC: DC5E0000 187C003C
	global_load_b128 v[28:31], v[64:65], off                   // 000000556AC4: DC5E0000 1C7C0040
	global_load_b128 v[32:35], v[68:69], off                   // 000000556ACC: DC5E0000 207C0044
	global_load_b128 v[36:39], v[60:61], off offset:16         // 000000556AD4: DC5E0010 247C003C
	global_load_b128 v[40:43], v[64:65], off offset:16         // 000000556ADC: DC5E0010 287C0040
	global_load_b128 v[44:47], v[68:69], off offset:16         // 000000556AE4: DC5E0010 2C7C0044
	global_load_b128 v[48:51], v[60:61], off offset:32         // 000000556AEC: DC5E0020 307C003C
	global_load_b128 v[52:55], v[64:65], off offset:32         // 000000556AF4: DC5E0020 347C0040
	global_load_b128 v[56:59], v[68:69], off offset:32         // 000000556AFC: DC5E0020 387C0044
	global_load_b128 v[60:63], v[60:61], off offset:48         // 000000556B04: DC5E0030 3C7C003C
	global_load_b128 v[64:67], v[64:65], off offset:48         // 000000556B0C: DC5E0030 407C0040
	global_load_b128 v[68:71], v[68:69], off offset:48         // 000000556B14: DC5E0030 447C0044
	v_and_b32_e32 v73, 0x3fc, v73                              // 000000556B1C: 369292FF 000003FC
	ds_load_b32 v72, v72                                       // 000000556B24: D8D80000 48000048
	v_and_b32_e32 v74, 0x3fc, v74                              // 000000556B2C: 369494FF 000003FC
	v_lshrrev_b32_e32 v76, 6, v2                               // 000000556B34: 32980486
	v_lshrrev_b32_e32 v77, 14, v2                              // 000000556B38: 329A048E
	ds_load_b32 v73, v73                                       // 000000556B3C: D8D80000 49000049
	v_lshrrev_b32_e32 v2, 22, v2                               // 000000556B44: 32040496
	ds_load_b32 v74, v74                                       // 000000556B48: D8D80000 4A00004A
	v_and_b32_e32 v1, 0x3fc, v1                                // 000000556B50: 360202FF 000003FC
	v_lshlrev_b32_e32 v75, 2, v75                              // 000000556B58: 30969682
	v_and_b32_e32 v76, 0x3fc, v76                              // 000000556B5C: 369898FF 000003FC
	v_and_b32_e32 v77, 0x3fc, v77                              // 000000556B64: 369A9AFF 000003FC
	v_and_b32_e32 v2, 0x3fc, v2                                // 000000556B6C: 360404FF 000003FC
	ds_load_b32 v1, v1                                         // 000000556B74: D8D80000 01000001
	ds_load_b32 v75, v75                                       // 000000556B7C: D8D80000 4B00004B
	ds_load_b32 v76, v76                                       // 000000556B84: D8D80000 4C00004C
	ds_load_b32 v77, v77                                       // 000000556B8C: D8D80000 4D00004D
	ds_load_b32 v2, v2                                         // 000000556B94: D8D80000 02000002
	v_and_b32_e32 v78, 0xff, v3                                // 000000556B9C: 369C06FF 000000FF
	v_lshrrev_b32_e32 v79, 6, v3                               // 000000556BA4: 329E0686
	v_lshrrev_b32_e32 v80, 14, v3                              // 000000556BA8: 32A0068E
	v_lshrrev_b32_e32 v3, 22, v3                               // 000000556BAC: 32060696
	v_and_b32_e32 v81, 0xff, v4                                // 000000556BB0: 36A208FF 000000FF
	v_lshrrev_b32_e32 v82, 14, v4                              // 000000556BB8: 32A4088E
	s_and_b32 s1, exec_lo, s0                                  // 000000556BBC: 8B01007E
	.long 0xd700000e                                           // 000000556BC0: D700000E
	v_cndmask_b32_e32 v0, v14, v160, vcc_lo                    // 000000556BC4: 0201410E
	v_and_b32_e32 v3, 0x3fc, v3                                // 000000556BC8: 360606FF 000003FC
	v_add_nc_u32_e32 v12, 0x200, v12                           // 000000556BD0: 4A1818FF 00000200
	v_add_nc_u32_e32 v21, 0x100, v21                           // 000000556BD8: 4A2A2AFF 00000100
	v_add_co_ci_u32_e64 v15, null, 0, v15, s0                  // 000000556BE0: D5207C0F 00021E80
	s_or_b32 s14, s1, s14                                      // 000000556BE8: 8C0E0E01
	s_waitcnt vmcnt(11) lgkmcnt(7)                             // 000000556BEC: BF892C77
	v_dot2_f32_bf16 v24, v24, v72, 0                           // 000000556BF0: CC1A4018 1A029118
	s_waitcnt vmcnt(10)                                        // 000000556BF8: BF892BF7
	v_dot2_f32_bf16 v28, v28, v72, 0                           // 000000556BFC: CC1A401C 1A02911C
	s_waitcnt vmcnt(9)                                         // 000000556C04: BF8927F7
	v_dot2_f32_bf16 v32, v32, v72, 0                           // 000000556C08: CC1A4020 1A029120
	v_lshrrev_b32_e32 v72, 6, v4                               // 000000556C10: 32900886
	v_lshrrev_b32_e32 v4, 22, v4                               // 000000556C14: 32080896
	s_waitcnt lgkmcnt(6)                                       // 000000556C18: BF89FC67
	v_dot2_f32_bf16 v24, v25, v73, v24                         // 000000556C1C: CC1A4018 1C629319
	v_dot2_f32_bf16 v25, v29, v73, v28                         // 000000556C24: CC1A4019 1C72931D
	v_dot2_f32_bf16 v28, v33, v73, v32                         // 000000556C2C: CC1A401C 1C829321
	v_lshlrev_b32_e32 v29, 2, v78                              // 000000556C34: 303A9C82
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000556C38: 360808FF 000003FC
	s_waitcnt lgkmcnt(5)                                       // 000000556C40: BF89FC57
	v_dot2_f32_bf16 v24, v26, v74, v24                         // 000000556C44: CC1A4018 1C62951A
	v_dot2_f32_bf16 v25, v30, v74, v25                         // 000000556C4C: CC1A4019 1C66951E
	v_dot2_f32_bf16 v26, v34, v74, v28                         // 000000556C54: CC1A401A 1C729522
	v_and_b32_e32 v28, 0x3fc, v79                              // 000000556C5C: 36389EFF 000003FC
	v_and_b32_e32 v30, 0x3fc, v80                              // 000000556C64: 363CA0FF 000003FC
	s_waitcnt lgkmcnt(4)                                       // 000000556C6C: BF89FC47
	v_dot2_f32_bf16 v24, v27, v1, v24                          // 000000556C70: CC1A4018 1C62031B
	v_dot2_f32_bf16 v25, v31, v1, v25                          // 000000556C78: CC1A4019 1C66031F
	v_dot2_f32_bf16 v1, v35, v1, v26                           // 000000556C80: CC1A4001 1C6A0323
	ds_load_b32 v27, v29                                       // 000000556C88: D8D80000 1B00001D
	ds_load_b32 v30, v30                                       // 000000556C90: D8D80000 1E00001E
	ds_load_b32 v28, v28                                       // 000000556C98: D8D80000 1C00001C
	s_waitcnt vmcnt(8) lgkmcnt(6)                              // 000000556CA0: BF892067
	v_dot2_f32_bf16 v24, v36, v75, v24                         // 000000556CA4: CC1A4018 1C629724
	s_waitcnt vmcnt(7)                                         // 000000556CAC: BF891FF7
	v_dot2_f32_bf16 v25, v40, v75, v25                         // 000000556CB0: CC1A4019 1C669728
	s_waitcnt vmcnt(6)                                         // 000000556CB8: BF891BF7
	v_dot2_f32_bf16 v1, v44, v75, v1                           // 000000556CBC: CC1A4001 1C06972C
	v_lshlrev_b32_e32 v26, 2, v81                              // 000000556CC4: 3034A282
	v_and_b32_e32 v29, 0x3fc, v72                              // 000000556CC8: 363A90FF 000003FC
	s_waitcnt lgkmcnt(5)                                       // 000000556CD0: BF89FC57
	v_dot2_f32_bf16 v24, v37, v76, v24                         // 000000556CD4: CC1A4018 1C629925
	v_dot2_f32_bf16 v25, v41, v76, v25                         // 000000556CDC: CC1A4019 1C669929
	v_dot2_f32_bf16 v1, v45, v76, v1                           // 000000556CE4: CC1A4001 1C06992D
	v_and_b32_e32 v31, 0x3fc, v82                              // 000000556CEC: 363EA4FF 000003FC
	s_waitcnt lgkmcnt(4)                                       // 000000556CF4: BF89FC47
	v_dot2_f32_bf16 v24, v38, v77, v24                         // 000000556CF8: CC1A4018 1C629B26
	v_dot2_f32_bf16 v25, v42, v77, v25                         // 000000556D00: CC1A4019 1C669B2A
	v_dot2_f32_bf16 v1, v46, v77, v1                           // 000000556D08: CC1A4001 1C069B2E
	s_waitcnt lgkmcnt(3)                                       // 000000556D10: BF89FC37
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000556D14: BF870193
	v_dot2_f32_bf16 v24, v39, v2, v24                          // 000000556D18: CC1A4018 1C620527
	v_dot2_f32_bf16 v25, v43, v2, v25                          // 000000556D20: CC1A4019 1C66052B
	s_delay_alu instid0(VALU_DEP_3)                            // 000000556D28: BF870003
	v_dot2_f32_bf16 v1, v47, v2, v1                            // 000000556D2C: CC1A4001 1C06052F
	ds_load_b32 v2, v3                                         // 000000556D34: D8D80000 02000003
	ds_load_b32 v3, v26                                        // 000000556D3C: D8D80000 0300001A
	ds_load_b32 v26, v29                                       // 000000556D44: D8D80000 1A00001D
	ds_load_b32 v29, v31                                       // 000000556D4C: D8D80000 1D00001F
	ds_load_b32 v31, v4                                        // 000000556D54: D8D80000 1F000004
	s_waitcnt vmcnt(5) lgkmcnt(7)                              // 000000556D5C: BF891477
	v_dot2_f32_bf16 v4, v48, v27, v24                          // 000000556D60: CC1A4004 1C623730
	s_waitcnt vmcnt(4)                                         // 000000556D68: BF8913F7
	v_dot2_f32_bf16 v24, v52, v27, v25                         // 000000556D6C: CC1A4018 1C663734
	s_waitcnt vmcnt(3)                                         // 000000556D74: BF890FF7
	v_dot2_f32_bf16 v1, v56, v27, v1                           // 000000556D78: CC1A4001 1C063738
	s_waitcnt lgkmcnt(5)                                       // 000000556D80: BF89FC57
	v_dot2_f32_bf16 v4, v49, v28, v4                           // 000000556D84: CC1A4004 1C123931
	v_dot2_f32_bf16 v24, v53, v28, v24                         // 000000556D8C: CC1A4018 1C623935
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000556D94: BF870193
	v_dot2_f32_bf16 v1, v57, v28, v1                           // 000000556D98: CC1A4001 1C063939
	v_dot2_f32_bf16 v4, v50, v30, v4                           // 000000556DA0: CC1A4004 1C123D32
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000556DA8: BF870193
	v_dot2_f32_bf16 v24, v54, v30, v24                         // 000000556DAC: CC1A4018 1C623D36
	v_dot2_f32_bf16 v1, v58, v30, v1                           // 000000556DB4: CC1A4001 1C063D3A
	s_waitcnt lgkmcnt(4)                                       // 000000556DBC: BF89FC47
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000556DC0: BF870193
	v_dot2_f32_bf16 v4, v51, v2, v4                            // 000000556DC4: CC1A4004 1C120533
	v_dot2_f32_bf16 v24, v55, v2, v24                          // 000000556DCC: CC1A4018 1C620537
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000556DD4: BF8701A3
	v_dot2_f32_bf16 v1, v59, v2, v1                            // 000000556DD8: CC1A4001 1C06053B
	s_waitcnt vmcnt(2) lgkmcnt(3)                              // 000000556DE0: BF890837
	v_dot2_f32_bf16 v2, v60, v3, v4                            // 000000556DE4: CC1A4002 1C12073C
	s_waitcnt vmcnt(1)                                         // 000000556DEC: BF8907F7
	v_dot2_f32_bf16 v4, v64, v3, v24                           // 000000556DF0: CC1A4004 1C620740
	s_waitcnt vmcnt(0)                                         // 000000556DF8: BF8903F7
	v_dot2_f32_bf16 v1, v68, v3, v1                            // 000000556DFC: CC1A4001 1C060744
	s_waitcnt lgkmcnt(2)                                       // 000000556E04: BF89FC27
	v_dot2_f32_bf16 v2, v61, v26, v2                           // 000000556E08: CC1A4002 1C0A353D
	v_dot2_f32_bf16 v3, v65, v26, v4                           // 000000556E10: CC1A4003 1C123541
	s_delay_alu instid0(VALU_DEP_3)                            // 000000556E18: BF870003
	v_dot2_f32_bf16 v1, v69, v26, v1                           // 000000556E1C: CC1A4001 1C063545
	v_mov_b32_e32 v4, v8                                       // 000000556E24: 7E080308
	s_waitcnt lgkmcnt(1)                                       // 000000556E28: BF89FC17
	v_dot2_f32_bf16 v2, v62, v29, v2                           // 000000556E2C: CC1A4002 1C0A3B3E
	v_dot2_f32_bf16 v24, v66, v29, v3                          // 000000556E34: CC1A4018 1C0E3B42
	v_dot2_f32_bf16 v1, v70, v29, v1                           // 000000556E3C: CC1A4001 1C063B46
	v_mov_b32_e32 v3, v7                                       // 000000556E44: 7E060307
	s_waitcnt lgkmcnt(0)                                       // 000000556E48: BF89FC07
	v_dot2_f32_bf16 v7, v63, v31, v2                           // 000000556E4C: CC1A4007 1C0A3F3F
	v_dot2_f32_bf16 v8, v67, v31, v24                          // 000000556E54: CC1A4008 1C623F43
	v_dot2_f32_bf16 v24, v71, v31, v1                          // 000000556E5C: CC1A4018 1C063F47
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v1, v5             // 000000556E64: CA100106 02000105
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000556E6C: BF870214
	v_fmac_f32_e32 v20, v18, v7                                // 000000556E70: 56280F12
	v_fmac_f32_e32 v19, v18, v8                                // 000000556E74: 56261112
	s_delay_alu instid0(VALU_DEP_4)                            // 000000556E78: BF870004
	v_dual_fmac_f32 v17, v18, v24 :: v_dual_mov_b32 v18, v23   // 000000556E7C: C8103112 11120117
	s_and_not1_b32 exec_lo, exec_lo, s14                       // 000000556E84: 917E0E7E
	s_cbranch_execz 25                                         // 000000556E88: BFA50019 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x6f0>
	s_waitcnt vmcnt(0)                                         // 000000556E8C: BF8903F7
	v_dual_mov_b32 v5, v1 :: v_dual_add_nc_u32 v22, 16, v22    // 000000556E90: CA200101 05162C90
	v_dual_mov_b32 v6, v2 :: v_dual_mov_b32 v7, v3             // 000000556E98: CA100102 06060103
	v_mov_b32_e32 v8, v4                                       // 000000556EA0: 7E100304
	s_delay_alu instid0(VALU_DEP_3)                            // 000000556EA4: BF870003
	.long 0xd4430000                                           // 000000556EA8: D4430000
	v_cndmask_b32_e32 v1, s2, v22, vcc_lo                      // 000000556EAC: 02022C02
	s_mov_b32 s15, exec_lo                                     // 000000556EB0: BE8F007E
	.long 0xd4c4007e                                           // 000000556EB4: D4C4007E
	v_cndmask_b32_e32 v1, s2, v22, vcc_lo                      // 000000556EB8: 02022C02
	s_cbranch_execz 65253                                      // 000000556EBC: BFA5FEE5 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x254>
	.long 0xd7000105                                           // 000000556EC0: D7000105
	v_cndmask_b32_e32 v1, v11, v21, vcc_lo                     // 000000556EC4: 02022B0B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000556EC8: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v0, s1                    // 000000556ECC: D5207C06 00060080
	global_load_d16_b16 v23, v[14:15], off                     // 000000556ED4: DC820000 177C000E
	global_load_b128 v[5:8], v[5:6], off                       // 000000556EDC: DC5E0000 057C0005
	s_waitcnt vmcnt(1)                                         // 000000556EE4: BF8907F7
	v_cvt_f32_f16_e32 v23, v23                                 // 000000556EE8: 7E2E1717
	s_branch 65241                                             // 000000556EEC: BFA0FED9 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x254>
	s_or_b32 exec_lo, exec_lo, s14                             // 000000556EF0: 8C7E0E7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000556EF4: BF8700B9
	s_or_b32 exec_lo, exec_lo, s3                              // 000000556EF8: 8C7E037E
	.long 0xd71f0000                                           // 000000556EFC: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000556F00: 020100C1
	s_waitcnt vmcnt(0)                                         // 000000556F04: BF8903F7
	v_xor_b32_e32 v1, 8, v0                                    // 000000556F08: 3A020088
	v_xor_b32_e32 v4, 4, v0                                    // 000000556F0C: 3A080084
	v_xor_b32_e32 v7, 2, v0                                    // 000000556F10: 3A0E0082
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000556F14: BF870093
	.long 0xd44c0000                                           // 000000556F18: D44C0000
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 000000556F1C: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s0                           // 000000556F20: D5010001 00020300
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000556F28: BF870114
	.long 0xd44c0000                                           // 000000556F2C: D44C0000
	v_cndmask_b32_e32 v1, 32, v4, vcc_lo                       // 000000556F30: 020208A0
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000556F34: 30020282
	s_delay_alu instid0(VALU_DEP_2)                            // 000000556F38: BF870002
	v_cndmask_b32_e64 v4, v0, v4, s0                           // 000000556F3C: D5010004 00020900
	.long 0xd44c0000                                           // 000000556F44: D44C0000
	v_cndmask_b32_e32 v1, 32, v7, vcc_lo                       // 000000556F48: 02020EA0
	ds_bpermute_b32 v2, v1, v20                                // 000000556F4C: DACC0000 02001401
	v_cndmask_b32_e64 v7, v0, v7, s0                           // 000000556F54: D5010007 00020F00
	s_waitcnt lgkmcnt(0)                                       // 000000556F5C: BF89FC07
	v_add_f32_e32 v2, v20, v2                                  // 000000556F60: 06040514
	ds_bpermute_b32 v3, v1, v19                                // 000000556F64: DACC0000 03001301
	v_lshlrev_b32_e32 v4, 2, v4                                // 000000556F6C: 30080882
	ds_bpermute_b32 v1, v1, v17                                // 000000556F70: DACC0000 01001101
	s_waitcnt lgkmcnt(1)                                       // 000000556F78: BF89FC17
	v_add_f32_e32 v3, v19, v3                                  // 000000556F7C: 06060713
	ds_bpermute_b32 v5, v4, v2                                 // 000000556F80: DACC0000 05000204
	v_lshlrev_b32_e32 v7, 2, v7                                // 000000556F88: 300E0E82
	ds_bpermute_b32 v6, v4, v3                                 // 000000556F8C: DACC0000 06000304
	s_waitcnt lgkmcnt(1)                                       // 000000556F94: BF89FC17
	v_add_f32_e32 v2, v2, v5                                   // 000000556F98: 06040B02
	v_add_f32_e32 v1, v17, v1                                  // 000000556F9C: 06020311
	s_waitcnt lgkmcnt(0)                                       // 000000556FA0: BF89FC07
	v_add_f32_e32 v3, v3, v6                                   // 000000556FA4: 06060D03
	ds_bpermute_b32 v4, v4, v1                                 // 000000556FA8: DACC0000 04000104
	ds_bpermute_b32 v5, v7, v3                                 // 000000556FB0: DACC0000 05000307
	s_waitcnt lgkmcnt(1)                                       // 000000556FB8: BF89FC17
	v_add_f32_e32 v1, v1, v4                                   // 000000556FBC: 06020901
	ds_bpermute_b32 v4, v7, v2                                 // 000000556FC0: DACC0000 04000207
	s_waitcnt lgkmcnt(1)                                       // 000000556FC8: BF89FC17
	v_add_f32_e32 v3, v3, v5                                   // 000000556FCC: 06060B03
	ds_bpermute_b32 v6, v7, v1                                 // 000000556FD0: DACC0000 06000107
	v_xor_b32_e32 v7, 1, v0                                    // 000000556FD8: 3A0E0081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000556FDC: BF870091
	.long 0xd44c0000                                           // 000000556FE0: D44C0000
	v_cndmask_b32_e32 v1, 32, v7, vcc_lo                       // 000000556FE4: 02020EA0
	v_cndmask_b32_e64 v0, v0, v7, s0                           // 000000556FE8: D5010000 00020F00
	.long 0xd44a0000                                           // 000000556FF0: D44A0000
	v_cndmask_b32_e32 v1, 0, v16, vcc_lo                       // 000000556FF4: 02022080
	s_delay_alu instid0(VALU_DEP_2)                            // 000000556FF8: BF870002
	v_lshlrev_b32_e32 v7, 2, v0                                // 000000556FFC: 300E0082
	s_waitcnt lgkmcnt(1)                                       // 000000557000: BF89FC17
	v_add_f32_e32 v2, v2, v4                                   // 000000557004: 06040902
	s_and_b32 s0, s0, vcc_lo                                   // 000000557008: 8B006A00
	s_waitcnt lgkmcnt(0)                                       // 00000055700C: BF89FC07
	v_add_f32_e32 v0, v1, v6                                   // 000000557010: 06000D01
	ds_bpermute_b32 v5, v7, v3                                 // 000000557014: DACC0000 05000307
	ds_bpermute_b32 v4, v7, v2                                 // 00000055701C: DACC0000 04000207
	ds_bpermute_b32 v1, v7, v0                                 // 000000557024: DACC0000 01000007
	s_and_saveexec_b32 s1, s0                                  // 00000055702C: BE812000
	s_cbranch_execz 49                                         // 000000557030: BFA50031 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi16ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x8f8>
	s_waitcnt lgkmcnt(1)                                       // 000000557034: BF89FC17
	v_dual_add_f32 v5, v3, v5 :: v_dual_add_f32 v4, v2, v4     // 000000557038: C9080B03 05040902
	.long 0x7f0c3880                                           // 000000557040: 7F0C3880
	.long 0xd73c0002                                           // 000000557044: D73C0002
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 000000557048: 02021281
	s_lshl_b64 s[0:1], s[12:13], 1                             // 00000055704C: 8480810C
	s_delay_alu instid0(VALU_DEP_3)                            // 000000557050: BF870003
	.long 0x7e0c3985                                           // 000000557054: 7E0C3985
	.long 0x7e0e3984                                           // 000000557058: 7E0E3984
	.long 0x7f0e3986                                           // 00000055705C: 7F0E3986
	s_waitcnt lgkmcnt(0)                                       // 000000557060: BF89FC07
	v_add_f32_e32 v8, v0, v1                                   // 000000557064: 06100300
	.long 0xd7006a00                                           // 000000557068: D7006A00
	v_cndmask_b32_e32 v1, s8, v2, vcc_lo                       // 00000055706C: 02020408
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000557070: BF870231
	v_add_co_ci_u32_e64 v1, null, s9, v3, vcc_lo               // 000000557074: D5207C01 01AA0609
	v_and_b32_e32 v7, 1, v7                                    // 00000055707C: 360E0E81
	v_and_b32_e32 v6, 1, v6                                    // 000000557080: 360C0C81
	.long 0xd7006a02                                           // 000000557084: D7006A02
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 000000557088: 02000100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000055708C: BF870211
	v_add_co_ci_u32_e64 v3, null, s1, v1, vcc_lo               // 000000557090: D5207C03 01AA0201
	v_add3_u32 v7, v4, v7, 0x7fff                              // 000000557098: D6550007 03FE0F04 00007FFF
	v_bfe_u32 v4, v8, 16, 1                                    // 0000005570A4: D6100004 02052108
	s_lshl_b64 s[0:1], s[12:13], 2                             // 0000005570AC: 8480820C
	v_add3_u32 v6, v5, v6, 0x7fff                              // 0000005570B0: D6550006 03FE0D05 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005570BC: BF8700A2
	v_add3_u32 v8, v8, v4, 0x7fff                              // 0000005570C0: D6550008 03FE0908 00007FFF
	.long 0xd7006a04                                           // 0000005570CC: D7006A04
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 0000005570D0: 02000100
	v_add_co_ci_u32_e64 v5, null, s1, v1, vcc_lo               // 0000005570D4: D5207C05 01AA0201
	s_clause 0x2                                               // 0000005570DC: BF850002
	global_store_d16_hi_b16 v[0:1], v7, off                    // 0000005570E0: DC960000 007C0700
	global_store_d16_hi_b16 v[2:3], v6, off                    // 0000005570E8: DC960000 007C0602
	global_store_d16_hi_b16 v[4:5], v8, off                    // 0000005570F0: DC960000 007C0804
	s_endpgm                                                   // 0000005570F8: BFB00000
	v_illegal                                                  // 0000005570FC: 00000000

