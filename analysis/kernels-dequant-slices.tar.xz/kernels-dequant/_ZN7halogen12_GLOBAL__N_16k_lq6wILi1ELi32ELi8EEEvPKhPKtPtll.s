000000000032fd00 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi1ELi32ELi8EEEvPKhPKtPtll>:
; _ZN7halogen12_GLOBAL__N_16k_lq6wILi1ELi32ELi8EEEvPKhPKtPtll():
	s_load_b256 s[4:11], s[0:1], null                          // 00000032FD00: F40C0100 F8000000
	s_mov_b32 s3, 0                                            // 00000032FD08: BE830080
	v_lshrrev_b32_e32 v16, 5, v0                               // 00000032FD0C: 32200085
	v_mov_b32_e32 v1, 0                                        // 00000032FD10: 7E020280
	v_dual_mov_b32 v17, 0 :: v_dual_mov_b32 v2, 0              // 00000032FD14: CA100080 11020080
	v_mov_b32_e32 v13, 0                                       // 00000032FD1C: 7E1A0280
	v_dual_mov_b32 v29, 0 :: v_dual_and_b32 v18, 31, v0        // 00000032FD20: CA240080 1D12009F
	v_mov_b32_e32 v12, 0                                       // 00000032FD28: 7E180280
	s_waitcnt lgkmcnt(0)                                       // 00000032FD2C: BF89FC07
	s_ashr_i32 s14, s11, 31                                    // 00000032FD30: 860E9F0B
	v_mov_b32_e32 v3, s4                                       // 00000032FD34: 7E060204
	s_lshr_b32 s12, s14, 27                                    // 00000032FD38: 850C9B0E
	v_mov_b32_e32 v4, s5                                       // 00000032FD3C: 7E080205
	s_add_u32 s12, s10, s12                                    // 00000032FD40: 800C0C0A
	s_addc_u32 s13, s11, 0                                     // 00000032FD44: 820D800B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000032FD48: BF8704B9
	s_lshr_b64 s[18:19], s[12:13], 5                           // 00000032FD4C: 8592850C
	s_load_b64 s[12:13], s[0:1], 0x20                          // 00000032FD50: F4040300 F8000020
	s_add_i32 s15, s18, 7                                      // 00000032FD58: 810F8712
	s_ashr_i32 s16, s15, 31                                    // 00000032FD5C: 86109F0F
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000032FD60: BF870499
	s_lshr_b32 s0, s16, 29                                     // 00000032FD64: 85009D10
	s_add_i32 s15, s15, s0                                     // 00000032FD68: 810F000F
	s_lshr_b32 s0, s11, 31                                     // 00000032FD6C: 85009F0B
	s_ashr_i32 s19, s15, 3                                     // 00000032FD70: 8613830F
	s_add_u32 s0, s10, s0                                      // 00000032FD74: 8000000A
	s_addc_u32 s1, s11, 0                                      // 00000032FD78: 8201800B
	s_lshr_b32 s15, s14, 30                                    // 00000032FD7C: 850F9E0E
	s_ashr_i64 s[16:17], s[0:1], 1                             // 00000032FD80: 86908100
	s_add_u32 s0, s10, s15                                     // 00000032FD84: 80000F0A
	s_addc_u32 s1, s11, 0                                      // 00000032FD88: 8201800B
	s_lshr_b32 s20, s14, 28                                    // 00000032FD8C: 85149C0E
	s_ashr_i64 s[14:15], s[0:1], 2                             // 00000032FD90: 868E8200
	s_add_u32 s0, s10, s20                                     // 00000032FD94: 8000140A
	s_addc_u32 s1, s11, 0                                      // 00000032FD98: 8201800B
	.long 0xd72c0005                                           // 00000032FD9C: D72C0005
	v_cndmask_b32_e32 v1, s19, v16, vcc_lo                     // 00000032FDA0: 02022013
	s_ashr_i64 s[0:1], s[0:1], 4                               // 00000032FDA4: 86808400
	s_add_u32 s4, s14, s16                                     // 00000032FDA8: 8004100E
	s_addc_u32 s10, s15, s17                                   // 00000032FDAC: 820A110F
	s_add_u32 s0, s4, s0                                       // 00000032FDB0: 80000004
	s_addc_u32 s1, s10, s1                                     // 00000032FDB4: 8201010A
	s_add_u32 s0, s0, 15                                       // 00000032FDB8: 80008F00
	s_addc_u32 s1, s1, 0                                       // 00000032FDBC: 82018001
	s_waitcnt lgkmcnt(0)                                       // 00000032FDC0: BF89FC07
	.long 0xd451000a                                           // 00000032FDC4: D451000A
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 00000032FDC8: 02001802
	s_ashr_i32 s4, s1, 31                                      // 00000032FDCC: 86049F01
	v_add_nc_u32_e32 v6, s19, v5                               // 00000032FDD0: 4A0C0A13
	s_lshr_b32 s4, s4, 28                                      // 00000032FDD4: 85049C04
	v_add_nc_u32_e32 v19, v5, v18                              // 00000032FDD8: 4A262505
	s_add_u32 s0, s0, s4                                       // 00000032FDDC: 80000400
	s_addc_u32 s1, s1, 0                                       // 00000032FDE0: 82018001
	s_lshl_b64 s[4:5], s[2:3], 4                               // 00000032FDE4: 84848402
	s_ashr_i64 s[0:1], s[0:1], 4                               // 00000032FDE8: 86808400
	s_and_b32 s10, s10, exec_lo                                // 00000032FDEC: 8B0A7E0A
	s_cselect_b32 s4, s4, 0                                    // 00000032FDF0: 98048004
	s_cselect_b32 s5, s5, 0                                    // 00000032FDF4: 98058005
	v_mad_u64_u32 v[9:10], null, s4, s0, v[3:4]                // 00000032FDF8: D6FE7C09 040C0004
	v_mov_b32_e32 v3, 0                                        // 00000032FE00: 7E060280
	s_mul_i32 s5, s5, s0                                       // 00000032FE04: 96050005
	v_mov_b32_e32 v4, 0                                        // 00000032FE08: 7E080280
	v_min_i32_e32 v20, s18, v6                                 // 00000032FE0C: 22280C12
	s_mul_i32 s4, s4, s1                                       // 00000032FE10: 96040104
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000032FE14: BF870114
	v_add_nc_u32_e32 v5, s5, v10                               // 00000032FE18: 4A0A1405
	v_cmp_lt_i32_e32 vcc_lo, v19, v20                          // 00000032FE1C: 7C822913
	s_delay_alu instid0(VALU_DEP_2)                            // 00000032FE20: BF870002
	v_add_nc_u32_e32 v21, s4, v5                               // 00000032FE24: 4A2A0A04
	s_and_saveexec_b32 s1, vcc_lo                              // 00000032FE28: BE81206A
	s_cbranch_execz 39                                         // 00000032FE2C: BFA50027 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi1ELi32ELi8EEEvPKhPKtPtll+0x1cc>
	v_lshlrev_b32_e32 v1, 4, v19                               // 00000032FE30: 30022684
	v_lshlrev_b32_e32 v4, 1, v19                               // 00000032FE34: 30082681
	v_lshlrev_b32_e32 v3, 3, v19                               // 00000032FE38: 30062683
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000032FE3C: BF870223
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000032FE40: 3404029F
	.long 0xd7000001                                           // 00000032FE44: D7000001
	v_cndmask_b32_e32 v1, v9, v1, vcc_lo                       // 00000032FE48: 02020309
	v_and_b32_e32 v4, -4, v4                                   // 00000032FE4C: 360808C4
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000032FE50: BF870214
	v_ashrrev_i32_e32 v7, 31, v3                               // 00000032FE54: 340E069F
	v_add_co_ci_u32_e64 v2, null, v21, v2, s0                  // 00000032FE58: D5207C02 00020515
	.long 0xd7000005                                           // 00000032FE60: D7000005
	v_cndmask_b32_e32 v0, v9, v16, vcc_lo                      // 00000032FE64: 02002109
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000032FE68: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s17, v21, s0                 // 00000032FE6C: D5207C06 00022A11
	v_ashrrev_i32_e32 v11, 31, v4                              // 00000032FE74: 3416089F
	.long 0xd7000008                                           // 00000032FE78: D7000008
	v_cndmask_b32_e32 v0, v5, v14, vcc_lo                      // 00000032FE7C: 02001D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000032FE80: BF8700A1
	v_add_co_ci_u32_e64 v10, null, s15, v6, s0                 // 00000032FE84: D5207C0A 00020C0F
	.long 0xd7000005                                           // 00000032FE8C: D7000005
	v_cndmask_b32_e32 v1, v5, v3, vcc_lo                       // 00000032FE90: 02020705
	v_add_co_ci_u32_e64 v6, null, v6, v7, s0                   // 00000032FE94: D5207C06 00020F06
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000032FE9C: BF870094
	.long 0xd7000007                                           // 00000032FEA0: D7000007
	v_cndmask_b32_e32 v1, v8, v4, vcc_lo                       // 00000032FEA4: 02020908
	v_add_co_ci_u32_e64 v8, null, v10, v11, s0                 // 00000032FEA8: D5207C08 0002170A
	s_clause 0x2                                               // 00000032FEB0: BF850002
	global_load_b128 v[1:4], v[1:2], off                       // 00000032FEB4: DC5E0000 017C0001
	global_load_b64 v[12:13], v[5:6], off                      // 00000032FEBC: DC560000 0C7C0005
	global_load_b32 v29, v[7:8], off                           // 00000032FEC4: DC520000 1D7C0007
	s_or_b32 exec_lo, exec_lo, s1                              // 00000032FECC: 8C7E017E
	s_and_saveexec_b32 s1, vcc_lo                              // 00000032FED0: BE81206A
	s_cbranch_execz 618                                        // 00000032FED4: BFA5026A <_ZN7halogen12_GLOBAL__N_16k_lq6wILi1ELi32ELi8EEEvPKhPKtPtll+0xb80>
	.long 0xd7006a16                                           // 00000032FED8: D7006A16
	v_cndmask_b32_e32 v0, v9, v16, vcc_lo                      // 00000032FEDC: 02002109
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000032FEE0: BF8701B1
	v_add_co_ci_u32_e64 v23, null, s17, v21, vcc_lo            // 00000032FEE4: D5207C17 01AA2A11
	s_waitcnt vmcnt(0)                                         // 00000032FEEC: BF8903F7
	v_dual_mov_b32 v30, v29 :: v_dual_add_nc_u32 v5, 32, v19   // 00000032FEF0: CA20011D 1E0426A0
	.long 0xd7006a18                                           // 00000032FEF8: D7006A18
	v_cndmask_b32_e32 v0, v22, v14, vcc_lo                     // 00000032FEFC: 02001D16
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000032FF00: BF870221
	v_add_co_ci_u32_e64 v25, null, s15, v23, vcc_lo            // 00000032FF04: D5207C19 01AA2E0F
	v_dual_mov_b32 v17, 0 :: v_dual_lshlrev_b32 v10, 5, v19    // 00000032FF0C: CA220080 110A2685
	v_lshlrev_b32_e32 v26, 4, v5                               // 00000032FF14: 30340A84
	v_lshlrev_b32_e32 v27, 3, v5                               // 00000032FF18: 30360A83
	v_lshlrev_b32_e32 v28, 1, v5                               // 00000032FF1C: 30380A81
	s_mov_b32 s4, 0                                            // 00000032FF20: BE840080
	s_branch 558                                               // 00000032FF24: BFA0022E <_ZN7halogen12_GLOBAL__N_16k_lq6wILi1ELi32ELi8EEEvPKhPKtPtll+0xae0>
	s_or_b32 exec_lo, exec_lo, s5                              // 00000032FF28: 8C7E057E
	v_ashrrev_i32_e32 v11, 31, v10                             // 00000032FF2C: 3416149F
	v_lshlrev_b32_e32 v47, 2, v12                              // 00000032FF30: 305E1882
	v_lshrrev_b32_e32 v48, 4, v1                               // 00000032FF34: 32600284
	v_lshrrev_b32_e32 v49, 8, v1                               // 00000032FF38: 32620288
	v_lshrrev_b32_e32 v50, 2, v12                              // 00000032FF3C: 32641882
	.long 0xd73c001f                                           // 00000032FF40: D73C001F
	v_cndmask_b32_e32 v1, 1, v10, vcc_lo                       // 00000032FF44: 02021481
	v_lshlrev_b32_e32 v11, 4, v12                              // 00000032FF48: 30161884
	v_and_b32_e32 v47, 48, v47                                 // 00000032FF4C: 365E5EB0
	v_and_b32_e32 v51, 48, v12                                 // 00000032FF50: 366618B0
	v_lshrrev_b32_e32 v52, 12, v1                              // 00000032FF54: 3268028C
	v_and_b32_e32 v50, 48, v50                                 // 00000032FF58: 366464B0
	.long 0xd700002b                                           // 00000032FF5C: D700002B
	v_cndmask_b32_e32 v1, s6, v31, vcc_lo                      // 00000032FF60: 02023E06
	s_delay_alu instid0(VALU_DEP_1)                            // 00000032FF64: BF870001
	v_add_co_ci_u32_e64 v44, null, s7, v32, s0                 // 00000032FF68: D5207C2C 00024007
	v_and_b32_e32 v11, 48, v11                                 // 00000032FF70: 361616B0
	v_and_or_b32 v47, v48, 15, v47                             // 00000032FF74: D657002F 04BD1F30
	v_and_or_b32 v48, v49, 15, v51                             // 00000032FF7C: D6570030 04CD1F31
	s_clause 0x3                                               // 00000032FF84: BF850003
	global_load_b128 v[31:34], v[43:44], off                   // 00000032FF88: DC5E0000 1F7C002B
	global_load_b128 v[35:38], v[43:44], off offset:16         // 00000032FF90: DC5E0010 237C002B
	global_load_b128 v[39:42], v[43:44], off offset:32         // 00000032FF98: DC5E0020 277C002B
	global_load_b128 v[43:46], v[43:44], off offset:48         // 00000032FFA0: DC5E0030 2B7C002B
	v_and_or_b32 v49, v52, 15, v50                             // 00000032FFA8: D6570031 04C91F34
	v_and_or_b32 v11, v1, 15, v11                              // 00000032FFB0: D657000B 042D1F01
	v_cvt_f32_ubyte0_e32 v47, v47                              // 00000032FFB8: 7E5E232F
	v_cvt_f32_ubyte0_e32 v48, v48                              // 00000032FFBC: 7E602330
	.long 0x7f683880                                           // 00000032FFC0: 7F683880
	v_cvt_f32_ubyte0_e32 v49, v49                              // 00000032FFC4: 7E622331
	v_cvt_f32_ubyte0_e32 v11, v11                              // 00000032FFC8: 7E16230B
	v_fma_mix_f32 v47, v47, v29, v29 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032FFCC: CC20602F 14763B2F
	v_fma_mix_f32 v48, v48, v29, v29 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032FFD4: CC206030 14763B30
	v_lshrrev_b32_e32 v54, 10, v12                             // 00000032FFDC: 326C188A
	v_fma_mix_f32 v49, v49, v29, v29 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032FFE0: CC206031 14763B31
	v_fma_mix_f32 v11, v11, v29, v29 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032FFE8: CC20600B 14763B0B
	v_bfe_u32 v51, v47, 16, 1                                  // 00000032FFF0: D6100033 0205212F
	v_lshrrev_b32_e32 v59, 22, v12                             // 00000032FFF8: 32761896
	v_lshrrev_b32_e32 v58, 20, v2                              // 00000032FFFC: 32740494
	v_bfe_u32 v53, v49, 16, 1                                  // 000000330000: D6100035 02052131
	v_bfe_u32 v50, v11, 16, 1                                  // 000000330008: D6100032 0205210B
	v_add3_u32 v47, v47, v51, 0x7fff                           // 000000330010: D655002F 03FE672F 00007FFF
	v_lshrrev_b32_e32 v51, 20, v1                              // 00000033001C: 32660294
	v_lshrrev_b32_e32 v60, 24, v2                              // 000000330020: 32780498
	v_add3_u32 v49, v49, v53, 0x7fff                           // 000000330024: D6550031 03FE6B31 00007FFF
	v_add3_u32 v11, v11, v50, 0x7fff                           // 000000330030: D655000B 03FE650B 00007FFF
	v_bfe_u32 v50, v48, 16, 1                                  // 00000033003C: D6100032 02052130
	v_lshrrev_b32_e32 v53, 24, v1                              // 000000330044: 326A0298
	v_lshlrev_b32_e32 v63, 4, v13                              // 000000330048: 307E1A84
	v_and_b32_e32 v59, 48, v59                                 // 00000033004C: 367676B0
	.long 0x7e68398b                                           // 000000330050: 7E68398B
	v_add3_u32 v11, v48, v50, 0x7fff                           // 000000330054: D655000B 03FE6530 00007FFF
	v_lshrrev_b32_e32 v48, 4, v12                              // 000000330060: 32601884
	v_lshrrev_b32_e32 v50, 8, v12                              // 000000330064: 32641888
	v_lshrrev_b32_e32 v56, 14, v12                             // 000000330068: 3270188E
	v_and_or_b32 v47, 0xffff0000, v47, v52                     // 00000033006C: D657002F 04D25EFF FFFF0000
	.long 0x7e68398b                                           // 000000330078: 7E68398B
	v_lshrrev_b32_e32 v11, 6, v12                              // 00000033007C: 32161886
	v_and_b32_e32 v48, 48, v48                                 // 000000330080: 366060B0
	v_and_b32_e32 v50, 48, v50                                 // 000000330084: 366464B0
	v_lshrrev_b32_e32 v61, 28, v2                              // 000000330088: 327A049C
	v_and_or_b32 v49, 0xffff0000, v49, v52                     // 00000033008C: D6570031 04D262FF FFFF0000
	.long 0x7e683981                                           // 000000330098: 7E683981
	v_and_b32_e32 v11, 48, v11                                 // 00000033009C: 361616B0
	v_lshrrev_b32_e32 v1, 28, v1                               // 0000003300A0: 3202029C
	v_and_or_b32 v50, v53, 15, v50                             // 0000003300A4: D6570032 04C91F35
	v_lshlrev_b32_e32 v65, 2, v13                              // 0000003300AC: 30821A82
	v_and_or_b32 v48, v52, 15, v48                             // 0000003300B0: D6570030 04C11F34
	v_and_or_b32 v11, v51, 15, v11                             // 0000003300B8: D657000B 042D1F33
	v_and_or_b32 v1, v54, 48, v1                               // 0000003300C0: D6570001 04056136
	v_cvt_f32_ubyte0_e32 v50, v50                              // 0000003300C8: 7E642332
	v_lshrrev_b32_e32 v51, 12, v12                             // 0000003300CC: 3266188C
	v_cvt_f32_ubyte0_e32 v48, v48                              // 0000003300D0: 7E602330
	v_cvt_f32_ubyte0_e32 v11, v11                              // 0000003300D4: 7E16230B
	v_cvt_f32_ubyte0_e32 v1, v1                                // 0000003300D8: 7E022301
	v_fma_mix_f32 v50, v50, v29, v29 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003300DC: CC206032 14763B32
	v_and_or_b32 v58, v58, 15, v59                             // 0000003300E4: D657003A 04ED1F3A
	v_fma_mix_f32 v48, v48, v29, v29 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003300EC: CC206030 14763B30
	v_fma_mix_f32 v11, v11, v29, v29 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003300F4: CC20600B 14763B0B
	v_fma_mix_f32 v1, v1, v29, v29 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003300FC: CC206001 14763B01
	v_lshrrev_b32_e32 v64, 4, v3                               // 000000330104: 32800684
	v_and_b32_e32 v66, 48, v13                                 // 000000330108: 36841AB0
	v_bfe_u32 v53, v48, 16, 1                                  // 00000033010C: D6100035 02052130
	v_bfe_u32 v55, v11, 16, 1                                  // 000000330114: D6100037 0205210B
	v_bfe_u32 v57, v1, 16, 1                                   // 00000033011C: D6100039 02052101
	v_cvt_f32_ubyte0_e32 v58, v58                              // 000000330124: 7E74233A
	v_lshrrev_b32_e32 v67, 12, v3                              // 000000330128: 3286068C
	v_add3_u32 v48, v48, v53, 0x7fff                           // 00000033012C: D6550030 03FE6B30 00007FFF
	v_bfe_u32 v53, v50, 16, 1                                  // 000000330138: D6100035 02052132
	v_add3_u32 v11, v11, v55, 0x7fff                           // 000000330140: D655000B 03FE6F0B 00007FFF
	v_add3_u32 v1, v1, v57, 0x7fff                             // 00000033014C: D6550001 03FE7301 00007FFF
	v_lshrrev_b32_e32 v55, 18, v12                             // 000000330158: 326E1892
	.long 0x7e6839b0                                           // 00000033015C: 7E6839B0
	v_add3_u32 v48, v50, v53, 0x7fff                           // 000000330160: D6550030 03FE6B32 00007FFF
	v_lshrrev_b32_e32 v50, 8, v2                               // 00000033016C: 32640488
	v_lshrrev_b32_e32 v53, 20, v12                             // 000000330170: 326A1894
	v_and_b32_e32 v55, 48, v55                                 // 000000330174: 366E6EB0
	v_and_or_b32 v11, 0xffff0000, v11, v52                     // 000000330178: D657000B 04D216FF FFFF0000
	.long 0x7e6839b0                                           // 000000330184: 7E6839B0
	v_lshrrev_b32_e32 v48, 12, v2                              // 000000330188: 3260048C
	v_lshrrev_b32_e32 v57, 24, v12                             // 00000033018C: 32721898
	v_and_b32_e32 v53, 48, v53                                 // 000000330190: 366A6AB0
	v_fma_mix_f32 v58, v58, v29, v29 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000330194: CC20603A 14763B3A
	v_and_or_b32 v1, 0xffff0000, v1, v52                       // 00000033019C: D6570001 04D202FF FFFF0000
	.long 0x7e68398c                                           // 0000003301A8: 7E68398C
	v_and_or_b32 v48, v48, 15, v55                             // 0000003301AC: D6570030 04DD1F30
	v_and_b32_e32 v57, 48, v57                                 // 0000003301B4: 367272B0
	v_lshrrev_b32_e32 v12, 26, v12                             // 0000003301B8: 3218189A
	v_lshrrev_b32_e32 v55, 2, v13                              // 0000003301BC: 326E1A82
	v_and_b32_e32 v62, 48, v52                                 // 0000003301C0: 367C68B0
	v_cvt_f32_ubyte0_e32 v48, v48                              // 0000003301C4: 7E602330
	v_and_or_b32 v57, v60, 15, v57                             // 0000003301C8: D6570039 04E51F3C
	v_and_or_b32 v12, v12, 48, v61                             // 0000003301D0: D657000C 04F5610C
	v_and_b32_e32 v61, 48, v65                                 // 0000003301D8: 367A82B0
	v_and_or_b32 v50, v50, 15, v62                             // 0000003301DC: D6570032 04F91F32
	v_fma_mix_f32 v48, v48, v29, v29 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003301E4: CC206030 14763B30
	v_lshrrev_b32_e32 v62, 8, v3                               // 0000003301EC: 327C0688
	v_cvt_f32_ubyte0_e32 v57, v57                              // 0000003301F0: 7E722339
	v_and_b32_e32 v55, 48, v55                                 // 0000003301F4: 366E6EB0
	v_cvt_f32_ubyte0_e32 v50, v50                              // 0000003301F8: 7E642332
	v_bfe_u32 v77, v48, 16, 1                                  // 0000003301FC: D610004D 02052130
	v_and_or_b32 v62, v62, 15, v66                             // 000000330204: D657003E 05091F3E
	v_cvt_f32_ubyte0_e32 v12, v12                              // 00000033020C: 7E18230C
	v_and_or_b32 v59, v64, 15, v61                             // 000000330210: D657003B 04F51F40
	v_fma_mix_f32 v50, v50, v29, v29 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000330218: CC206032 14763B32
	v_add3_u32 v48, v48, v77, 0x7fff                           // 000000330220: D6550030 03FE9B30 00007FFF
	v_fma_mix_f32 v57, v57, v29, v29 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000033022C: CC206039 14763B39
	v_and_or_b32 v55, v67, 15, v55                             // 000000330234: D6570037 04DD1F43
	v_cvt_f32_ubyte0_e32 v60, v62                              // 00000033023C: 7E78233E
	v_bfe_u32 v73, v50, 16, 1                                  // 000000330240: D6100049 02052132
	v_fma_mix_f32 v12, v12, v29, v29 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000330248: CC20600C 14763B0C
	v_cvt_f32_ubyte0_e32 v59, v59                              // 000000330250: 7E76233B
	v_cvt_f32_ubyte0_e32 v55, v55                              // 000000330254: 7E6E2337
	v_fma_mix_f32 v60, v60, v29, v29 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000330258: CC20603C 14763B3C
	v_add3_u32 v50, v50, v73, 0x7fff                           // 000000330260: D6550032 03FE9332 00007FFF
	v_bfe_u32 v62, v12, 16, 1                                  // 00000033026C: D610003E 0205210C
	v_fma_mix_f32 v59, v59, v29, v29 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000330274: CC20603B 14763B3B
	v_fma_mix_f32 v55, v55, v29, v29 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000033027C: CC206037 14763B37
	v_lshrrev_b32_e32 v69, 4, v13                              // 000000330284: 328A1A84
	.long 0x7e6839b2                                           // 000000330288: 7E6839B2
	v_and_b32_e32 v50, 48, v63                                 // 00000033028C: 36647EB0
	v_bfe_u32 v63, v58, 16, 1                                  // 000000330290: D610003F 0205213A
	v_add3_u32 v12, v12, v62, 0x7fff                           // 000000330298: D655000C 03FE7D0C 00007FFF
	v_lshrrev_b32_e32 v68, 8, v13                              // 0000003302A4: 32881A88
	v_and_or_b32 v48, 0xffff0000, v48, v52                     // 0000003302A8: D6570030 04D260FF FFFF0000
	.long 0x7e683982                                           // 0000003302B4: 7E683982
	v_and_or_b32 v50, v3, 15, v50                              // 0000003302B8: D6570032 04C91F03
	v_add3_u32 v58, v58, v63, 0x7fff                           // 0000003302C0: D655003A 03FE7F3A 00007FFF
	v_lshrrev_b32_e32 v71, 6, v13                              // 0000003302CC: 328E1A86
	v_and_b32_e32 v62, 48, v69                                 // 0000003302D0: 367C8AB0
	v_and_or_b32 v53, v52, 15, v53                             // 0000003302D4: D6570035 04D51F34
	v_cvt_f32_ubyte0_e32 v50, v50                              // 0000003302DC: 7E642332
	v_lshrrev_b32_e32 v70, 20, v3                              // 0000003302E0: 328C0694
	v_lshrrev_b32_e32 v72, 24, v3                              // 0000003302E4: 32900698
	v_and_b32_e32 v65, 48, v71                                 // 0000003302E8: 36828EB0
	v_cvt_f32_ubyte0_e32 v53, v53                              // 0000003302EC: 7E6A2335
	v_fma_mix_f32 v50, v50, v29, v29 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003302F0: CC206032 14763B32
	v_and_b32_e32 v66, 48, v68                                 // 0000003302F8: 368488B0
	v_lshrrev_b32_e32 v75, 28, v3                              // 0000003302FC: 3296069C
	v_lshrrev_b32_e32 v76, 10, v13                             // 000000330300: 32981A8A
	v_fma_mix_f32 v53, v53, v29, v29 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000330304: CC206035 14763B35
	v_and_or_b32 v65, v70, 15, v65                             // 00000033030C: D6570041 05051F46
	v_and_or_b32 v66, v72, 15, v66                             // 000000330314: D6570042 05091F48
	v_and_b32_e32 v51, 48, v51                                 // 00000033031C: 366666B0
	v_and_or_b32 v70, v76, 48, v75                             // 000000330320: D6570046 052D614C
	v_bfe_u32 v61, v53, 16, 1                                  // 000000330328: D610003D 02052135
	v_cvt_f32_ubyte0_e32 v65, v65                              // 000000330330: 7E822341
	v_cvt_f32_ubyte0_e32 v66, v66                              // 000000330334: 7E842342
	v_lshrrev_b32_e32 v54, 4, v2                               // 000000330338: 326C0484
	v_cvt_f32_ubyte0_e32 v70, v70                              // 00000033033C: 7E8C2346
	v_add3_u32 v53, v53, v61, 0x7fff                           // 000000330340: D6550035 03FE7B35 00007FFF
	v_bfe_u32 v61, v57, 16, 1                                  // 00000033034C: D610003D 02052139
	v_fma_mix_f32 v65, v65, v29, v29 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000330354: CC206041 14763B41
	v_fma_mix_f32 v66, v66, v29, v29 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000033035C: CC206042 14763B42
	v_fma_mix_f32 v70, v70, v29, v29 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000330364: CC206046 14763B46
	.long 0x7e6839b5                                           // 00000033036C: 7E6839B5
	v_add3_u32 v53, v57, v61, 0x7fff                           // 000000330370: D6550035 03FE7B39 00007FFF
	v_bfe_u32 v57, v50, 16, 1                                  // 00000033037C: D6100039 02052132
	v_bfe_u32 v61, v59, 16, 1                                  // 000000330384: D610003D 0205213B
	v_bfe_u32 v75, v65, 16, 1                                  // 00000033038C: D610004B 02052141
	v_and_or_b32 v58, 0xffff0000, v58, v52                     // 000000330394: D657003A 04D274FF FFFF0000
	.long 0x7e6839b5                                           // 0000003303A0: 7E6839B5
	v_add3_u32 v50, v50, v57, 0x7fff                           // 0000003303A4: D6550032 03FE7332 00007FFF
	v_bfe_u32 v53, v60, 16, 1                                  // 0000003303B0: D6100035 0205213C
	v_bfe_u32 v57, v55, 16, 1                                  // 0000003303B8: D6100039 02052137
	v_add3_u32 v59, v59, v61, 0x7fff                           // 0000003303C0: D655003B 03FE7B3B 00007FFF
	v_and_or_b32 v12, 0xffff0000, v12, v52                     // 0000003303CC: D657000C 04D218FF FFFF0000
	.long 0x7e6839b2                                           // 0000003303D8: 7E6839B2
	v_add3_u32 v50, v60, v53, 0x7fff                           // 0000003303DC: D6550032 03FE6B3C 00007FFF
	v_add3_u32 v55, v55, v57, 0x7fff                           // 0000003303E8: D6550037 03FE7337 00007FFF
	v_bfe_u32 v76, v70, 16, 1                                  // 0000003303F4: D610004C 02052146
	v_add3_u32 v65, v65, v75, 0x7fff                           // 0000003303FC: D6550041 03FE9741 00007FFF
	v_and_or_b32 v57, 0xffff0000, v59, v52                     // 000000330408: D6570039 04D276FF FFFF0000
	.long 0x7e6839b2                                           // 000000330414: 7E6839B2
	v_and_b32_e32 v56, 48, v56                                 // 000000330418: 367070B0
	v_add3_u32 v70, v70, v76, 0x7fff                           // 00000033041C: D6550046 03FE9946 00007FFF
	v_and_or_b32 v2, v2, 15, v51                               // 000000330428: D6570002 04CD1F02
	v_lshrrev_b32_e32 v74, 12, v13                             // 000000330430: 32941A8C
	v_and_or_b32 v55, 0xffff0000, v55, v52                     // 000000330434: D6570037 04D26EFF FFFF0000
	.long 0x7e683983                                           // 000000330440: 7E683983
	v_lshrrev_b32_e32 v50, 14, v13                             // 000000330444: 32641A8E
	v_lshrrev_b32_e32 v61, 20, v13                             // 000000330448: 327A1A94
	v_lshrrev_b32_e32 v63, 18, v13                             // 00000033044C: 327E1A92
	v_lshrrev_b32_e32 v64, 24, v13                             // 000000330450: 32801A98
	v_and_or_b32 v62, v52, 15, v62                             // 000000330454: D657003E 04F91F34
	v_lshrrev_b32_e32 v68, 22, v13                             // 00000033045C: 32881A96
	v_lshrrev_b32_e32 v73, 26, v13                             // 000000330460: 32921A9A
	v_cvt_f32_ubyte0_e32 v2, v2                                // 000000330464: 7E042302
	v_lshrrev_b32_e32 v59, 8, v4                               // 000000330468: 32760888
	v_cvt_f32_ubyte0_e32 v62, v62                              // 00000033046C: 7E7C233E
	v_lshrrev_b32_e32 v3, 12, v4                               // 000000330470: 3206088C
	v_and_b32_e32 v53, 15, v4                                  // 000000330474: 366A088F
	v_fma_mix_f32 v2, v2, v29, v29 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000330478: CC206002 14763B02
	v_lshrrev_b32_e32 v60, 4, v4                               // 000000330480: 32780884
	v_fma_mix_f32 v62, v62, v29, v29 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000330484: CC20603E 14763B3E
	v_lshrrev_b32_e32 v71, 28, v4                              // 00000033048C: 328E089C
	v_and_or_b32 v53, v74, 48, v53                             // 000000330490: D6570035 04D5614A
	v_and_b32_e32 v50, 48, v50                                 // 000000330498: 366464B0
	v_lshrrev_b32_e32 v67, 20, v4                              // 00000033049C: 32860894
	v_bfe_u32 v72, v62, 16, 1                                  // 0000003304A0: D6100048 0205213E
	v_lshrrev_b32_e32 v69, 24, v4                              // 0000003304A8: 328A0898
	v_and_b32_e32 v64, 48, v64                                 // 0000003304AC: 368080B0
	.long 0x7f6639b4                                           // 0000003304B0: 7F6639B4
	v_add_nc_u32_e32 v26, 0x200, v26                           // 0000003304B4: 4A3434FF 00000200
	v_add3_u32 v62, v62, v72, 0x7fff                           // 0000003304BC: D655003E 03FE913E 00007FFF
	v_bfe_u32 v72, v66, 16, 1                                  // 0000003304C8: D6100048 02052142
	v_add_nc_u32_e32 v27, 0x100, v27                           // 0000003304D0: 4A3636FF 00000100
	v_add_nc_u32_e32 v28, 64, v28                              // 0000003304D8: 4A3838C0
	v_add_nc_u32_e32 v10, 0x400, v10                           // 0000003304DC: 4A1414FF 00000400
	.long 0x7e6839be                                           // 0000003304E4: 7E6839BE
	v_add3_u32 v62, v66, v72, 0x7fff                           // 0000003304E8: D655003E 03FE9142 00007FFF
	.long 0x7f8439b4                                           // 0000003304F4: 7F8439B4
	s_and_b32 s0, exec_lo, vcc_lo                              // 0000003304F8: 8B006A7E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003304FC: BF870193
	v_and_or_b32 v65, 0xffff0000, v65, v52                     // 000000330500: D6570041 04D282FF FFFF0000
	.long 0x7e6839be                                           // 00000033050C: 7E6839BE
	s_or_b32 s4, s0, s4                                        // 000000330510: 8C040400
	s_delay_alu instid0(VALU_DEP_1)                            // 000000330514: BF870001
	v_and_or_b32 v62, 0xffff0000, v70, v52                     // 000000330518: D657003E 04D28CFF FFFF0000
	.long 0x7e68398d                                           // 000000330524: 7E68398D
	v_and_or_b32 v13, v54, 15, v56                             // 000000330528: D657000D 04E11F36
	v_and_b32_e32 v56, 48, v61                                 // 000000330530: 36707AB0
	v_and_b32_e32 v54, 48, v63                                 // 000000330534: 366C7EB0
	v_and_b32_e32 v63, 48, v68                                 // 000000330538: 367E88B0
	v_and_b32_e32 v61, 48, v52                                 // 00000033053C: 367A68B0
	v_cvt_f32_ubyte0_e32 v13, v13                              // 000000330540: 7E1A230D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000330544: BF870194
	v_and_or_b32 v3, v3, 15, v54                               // 000000330548: D6570003 04D91F03
	v_and_or_b32 v59, v59, 15, v61                             // 000000330550: D657003B 04F51F3B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000330558: BF870223
	v_fma_mix_f32 v13, v13, v29, v29 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000033055C: CC20600D 14763B0D
	v_bfe_u32 v61, v2, 16, 1                                   // 000000330564: D610003D 02052102
	v_cvt_f32_ubyte0_e32 v3, v3                                // 00000033056C: 7E062303
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000330570: BF870193
	v_bfe_u32 v54, v13, 16, 1                                  // 000000330574: D6100036 0205210D
	v_add3_u32 v2, v2, v61, 0x7fff                             // 00000033057C: D6550002 03FE7B02 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000330588: BF870193
	v_fma_mix_f32 v3, v3, v29, v29 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000033058C: CC206003 14763B03
	v_add3_u32 v13, v13, v54, 0x7fff                           // 000000330594: D655000D 03FE6D0D 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003305A0: BF870093
	.long 0x7e843982                                           // 0000003305A4: 7E843982
	v_and_or_b32 v13, 0xffff0000, v13, v66                     // 0000003305A8: D657000D 050A1AFF FFFF0000
	s_waitcnt vmcnt(3)                                         // 0000003305B4: BF890FF7
	v_dot2_f32_bf16 v31, v31, v47, 0                           // 0000003305B8: CC1A401F 1A025F1F
	v_cvt_f32_ubyte0_e32 v47, v59                              // 0000003305C0: 7E5E233B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003305C4: BF870112
	v_dot2_f32_bf16 v31, v32, v49, v31                         // 0000003305C8: CC1A401F 1C7E6320
	v_fma_mix_f32 v32, v47, v29, v29 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003305D0: CC206020 14763B2F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003305D8: BF870112
	v_dot2_f32_bf16 v2, v33, v11, v31                          // 0000003305DC: CC1A4002 1C7E1721
	v_bfe_u32 v11, v32, 16, 1                                  // 0000003305E4: D610000B 02052120
	v_and_or_b32 v31, v73, 48, v71                             // 0000003305EC: D657001F 051D6149
	v_cvt_f32_ubyte0_e32 v33, v53                              // 0000003305F4: 7E422335
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003305F8: BF870004
	v_dot2_f32_bf16 v1, v34, v1, v2                            // 0000003305FC: CC1A4001 1C0A0322
	v_bfe_u32 v2, v3, 16, 1                                    // 000000330604: D6100002 02052103
	v_add3_u32 v11, v32, v11, 0x7fff                           // 00000033060C: D655000B 03FE1720 00007FFF
	v_and_or_b32 v32, v60, 15, v50                             // 000000330618: D6570020 04C91F3C
	s_waitcnt vmcnt(2)                                         // 000000330620: BF890BF7
	v_dot2_f32_bf16 v1, v35, v13, v1                           // 000000330624: CC1A4001 1C061B23
	v_add3_u32 v2, v3, v2, 0x7fff                              // 00000033062C: D6550002 03FE0503 00007FFF
	.long 0x7e68398b                                           // 000000330638: 7E68398B
	v_cvt_f32_ubyte0_e32 v13, v31                              // 00000033063C: 7E1A231F
	v_cvt_f32_ubyte0_e32 v31, v32                              // 000000330640: 7E3E2320
	v_dot2_f32_bf16 v1, v36, v48, v1                           // 000000330644: CC1A4001 1C066124
	v_and_or_b32 v3, v67, 15, v63                              // 00000033064C: D6570003 04FD1F43
	v_and_or_b32 v2, 0xffff0000, v2, v52                       // 000000330654: D6570002 04D204FF FFFF0000
	.long 0x7e683984                                           // 000000330660: 7E683984
	v_fma_mix_f32 v4, v33, v29, v29 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000330664: CC206004 14763B21
	v_dot2_f32_bf16 v1, v37, v58, v1                           // 00000033066C: CC1A4001 1C067525
	v_and_or_b32 v11, v69, 15, v64                             // 000000330674: D657000B 05011F45
	v_fma_mix_f32 v31, v31, v29, v29 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000033067C: CC20601F 14763B1F
	v_and_or_b32 v32, v52, 15, v56                             // 000000330684: D6570020 04E11F34
	v_cvt_f32_ubyte0_e32 v3, v3                                // 00000033068C: 7E062303
	v_dot2_f32_bf16 v1, v38, v12, v1                           // 000000330690: CC1A4001 1C061926
	v_fma_mix_f32 v12, v13, v29, v29 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000330698: CC20600C 14763B0D
	v_bfe_u32 v13, v4, 16, 1                                   // 0000003306A0: D610000D 02052104
	v_cvt_f32_ubyte0_e32 v32, v32                              // 0000003306A8: 7E402320
	v_cvt_f32_ubyte0_e32 v11, v11                              // 0000003306AC: 7E16230B
	s_waitcnt vmcnt(1)                                         // 0000003306B0: BF8907F7
	v_dot2_f32_bf16 v1, v39, v57, v1                           // 0000003306B4: CC1A4001 1C067327
	v_fma_mix_f32 v3, v3, v29, v29 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003306BC: CC206003 14763B03
	v_add3_u32 v4, v4, v13, 0x7fff                             // 0000003306C4: D6550004 03FE1B04 00007FFF
	v_fma_mix_f32 v13, v32, v29, v29 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003306D0: CC20600D 14763B20
	v_bfe_u32 v32, v31, 16, 1                                  // 0000003306D8: D6100020 0205211F
	v_dot2_f32_bf16 v1, v40, v55, v1                           // 0000003306E0: CC1A4001 1C066F28
	v_fma_mix_f32 v11, v11, v29, v29 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003306E8: CC20600B 14763B0B
	.long 0x7e663984                                           // 0000003306F0: 7E663984
	v_bfe_u32 v4, v13, 16, 1                                   // 0000003306F4: D6100004 0205210D
	v_add3_u32 v29, v31, v32, 0x7fff                           // 0000003306FC: D655001D 03FE411F 00007FFF
	v_dot2_f32_bf16 v1, v41, v65, v1                           // 000000330708: CC1A4001 1C068329
	v_bfe_u32 v31, v3, 16, 1                                   // 000000330710: D610001F 02052103
	v_bfe_u32 v32, v11, 16, 1                                  // 000000330718: D6100020 0205210B
	v_add3_u32 v4, v13, v4, 0x7fff                             // 000000330720: D6550004 03FE090D 00007FFF
	v_and_or_b32 v13, 0xffff0000, v29, v51                     // 00000033072C: D657000D 04CE3AFF FFFF0000
	v_dot2_f32_bf16 v1, v42, v62, v1                           // 000000330738: CC1A4001 1C067D2A
	v_bfe_u32 v29, v12, 16, 1                                  // 000000330740: D610001D 0205210C
	v_add3_u32 v3, v3, v31, 0x7fff                             // 000000330748: D6550003 03FE3F03 00007FFF
	.long 0x7e683984                                           // 000000330754: 7E683984
	v_add3_u32 v4, v11, v32, 0x7fff                            // 000000330758: D6550004 03FE410B 00007FFF
	s_waitcnt vmcnt(0)                                         // 000000330764: BF8903F7
	v_dot2_f32_bf16 v1, v43, v13, v1                           // 000000330768: CC1A4001 1C061B2B
	v_add3_u32 v11, v12, v29, 0x7fff                           // 000000330770: D655000B 03FE3B0C 00007FFF
	v_mov_b32_e32 v12, v14                                     // 00000033077C: 7E18030E
	v_and_or_b32 v3, 0xffff0000, v3, v52                       // 000000330780: D6570003 04D206FF FFFF0000
	.long 0x7e683984                                           // 00000033078C: 7E683984
	v_dot2_f32_bf16 v1, v44, v2, v1                            // 000000330790: CC1A4001 1C06052C
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v13, v15           // 000000330798: CA100106 020C010F
	v_mov_b32_e32 v29, v30                                     // 0000003307A0: 7E3A031E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003307A4: BF870214
	v_and_or_b32 v4, 0xffff0000, v11, v52                      // 0000003307A8: D6570004 04D216FF FFFF0000
	v_dot2_f32_bf16 v1, v45, v3, v1                            // 0000003307B4: CC1A4001 1C06072D
	v_mov_b32_e32 v3, v7                                       // 0000003307BC: 7E060307
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003307C0: BF870092
	v_dot2_f32_bf16 v1, v46, v4, v1                            // 0000003307C4: CC1A4001 1C06092E
	v_dual_mov_b32 v4, v8 :: v_dual_add_f32 v17, v17, v1       // 0000003307CC: CA080108 04100311
	v_mov_b32_e32 v1, v5                                       // 0000003307D4: 7E020305
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000003307D8: 917E047E
	s_cbranch_execz 39                                         // 0000003307DC: BFA50027 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi1ELi32ELi8EEEvPKhPKtPtll+0xb7c>
	v_dual_mov_b32 v6, v2 :: v_dual_add_nc_u32 v19, 32, v19    // 0000003307E0: CA200102 061226A0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000003307E8: BF870002
	v_dual_mov_b32 v5, v1 :: v_dual_mov_b32 v8, v4             // 0000003307EC: CA100101 05080104
	v_dual_mov_b32 v7, v3 :: v_dual_mov_b32 v14, v12           // 0000003307F4: CA100103 070E010C
	v_mov_b32_e32 v15, v13                                     // 0000003307FC: 7E1E030D
	s_mov_b32 s5, exec_lo                                      // 000000330800: BE85007E
	v_cmp_ge_i32_e32 vcc_lo, v19, v20                          // 000000330804: 7C8C2913
	.long 0xd4c1007e                                           // 000000330808: D4C1007E
	v_cndmask_b32_e32 v1, v19, v20, vcc_lo                     // 00000033080C: 02022913
	s_cbranch_execz 64965                                      // 000000330810: BFA5FDC5 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi1ELi32ELi8EEEvPKhPKtPtll+0x228>
	v_and_b32_e32 v7, -4, v28                                  // 000000330814: 360E38C4
	v_ashrrev_i32_e32 v6, 31, v26                              // 000000330818: 340C349F
	v_ashrrev_i32_e32 v8, 31, v27                              // 00000033081C: 3410369F
	.long 0xd7000005                                           // 000000330820: D7000005
	v_cndmask_b32_e32 v1, v9, v26, vcc_lo                      // 000000330824: 02023509
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000330828: BF870214
	v_ashrrev_i32_e32 v11, 31, v7                              // 00000033082C: 34160E9F
	v_add_co_ci_u32_e64 v6, null, v21, v6, s0                  // 000000330830: D5207C06 00020D15
	.long 0xd700000e                                           // 000000330838: D700000E
	v_cndmask_b32_e32 v1, v22, v27, vcc_lo                     // 00000033083C: 02023716
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000330840: BF8700A1
	v_add_co_ci_u32_e64 v15, null, v23, v8, s0                 // 000000330844: D5207C0F 00021117
	.long 0xd700001e                                           // 00000033084C: D700001E
	v_cndmask_b32_e32 v1, v24, v7, vcc_lo                      // 000000330850: 02020F18
	v_add_co_ci_u32_e64 v31, null, v25, v11, s0                // 000000330854: D5207C1F 00021719
	s_clause 0x2                                               // 00000033085C: BF850002
	global_load_b128 v[5:8], v[5:6], off                       // 000000330860: DC5E0000 057C0005
	global_load_b64 v[14:15], v[14:15], off                    // 000000330868: DC560000 0E7C000E
	global_load_b32 v30, v[30:31], off                         // 000000330870: DC520000 1E7C001E
	s_branch 64939                                             // 000000330878: BFA0FDAB <_ZN7halogen12_GLOBAL__N_16k_lq6wILi1ELi32ELi8EEEvPKhPKtPtll+0x228>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000033087C: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000330880: BF8700C9
	s_or_b32 exec_lo, exec_lo, s1                              // 000000330884: 8C7E017E
	s_waitcnt vmcnt(2)                                         // 000000330888: BF890BF7
	.long 0xd71f0001                                           // 00000033088C: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000330890: 020100C1
	s_mov_b32 s0, exec_lo                                      // 000000330894: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 000000330898: 3A040290
	v_xor_b32_e32 v3, 8, v1                                    // 00000033089C: 3A060288
	v_xor_b32_e32 v4, 4, v1                                    // 0000003308A0: 3A080284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000003308A4: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000003308A8: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 0000003308AC: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v3                            // 0000003308B0: 7C9806A0
	v_cndmask_b32_e32 v3, v1, v3, vcc_lo                       // 0000003308B4: 02060701
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 0000003308B8: 7C9808A0
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo                       // 0000003308BC: 02080901
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003308C0: BF870211
	v_lshlrev_b32_e32 v4, 2, v4                                // 0000003308C4: 30080882
	v_lshlrev_b32_e32 v3, 2, v3                                // 0000003308C8: 30060682
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000003308CC: 30040482
	ds_bpermute_b32 v2, v2, v17                                // 0000003308D0: DACC0000 02001102
	s_waitcnt lgkmcnt(0)                                       // 0000003308D8: BF89FC07
	v_add_f32_e32 v2, v17, v2                                  // 0000003308DC: 06040511
	ds_bpermute_b32 v3, v3, v2                                 // 0000003308E0: DACC0000 03000203
	s_waitcnt lgkmcnt(0)                                       // 0000003308E8: BF89FC07
	v_add_f32_e32 v2, v2, v3                                   // 0000003308EC: 06040702
	ds_bpermute_b32 v3, v4, v2                                 // 0000003308F0: DACC0000 03000204
	v_xor_b32_e32 v4, 2, v1                                    // 0000003308F8: 3A080282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003308FC: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 000000330900: 7C9808A0
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo                       // 000000330904: 02080901
	v_lshlrev_b32_e32 v4, 2, v4                                // 000000330908: 30080882
	s_waitcnt lgkmcnt(0)                                       // 00000033090C: BF89FC07
	v_add_f32_e32 v2, v2, v3                                   // 000000330910: 06040702
	ds_bpermute_b32 v3, v4, v2                                 // 000000330914: DACC0000 03000204
	v_xor_b32_e32 v4, 1, v1                                    // 00000033091C: 3A080281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000330920: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 000000330924: 7C9808A0
	s_waitcnt lgkmcnt(0)                                       // 000000330928: BF89FC07
	v_dual_cndmask_b32 v4, v1, v4 :: v_dual_add_f32 v1, v2, v3 // 00000033092C: CA480901 04000702
	v_lshlrev_b32_e32 v2, 2, v4                                // 000000330934: 30040882
	ds_bpermute_b32 v2, v2, v1                                 // 000000330938: DACC0000 02000102
	v_cmpx_eq_u32_e32 0, v18                                   // 000000330940: 7D942480
	s_cbranch_execz 5                                          // 000000330944: BFA50005 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi1ELi32ELi8EEEvPKhPKtPtll+0xc5c>
	s_waitcnt lgkmcnt(0)                                       // 000000330948: BF89FC07
	v_dual_add_f32 v1, v1, v2 :: v_dual_lshlrev_b32 v2, 2, v16 // 00000033094C: C9220501 01022082
	ds_store_b32 v2, v1                                        // 000000330954: D8340000 00000102
	s_or_b32 exec_lo, exec_lo, s0                              // 00000033095C: 8C7E007E
	.long 0xd4510000                                           // 000000330960: D4510000
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 000000330964: 02001802
	v_cmp_eq_u32_e32 vcc_lo, 0, v0                             // 000000330968: 7C940080
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000033096C: BF890007
	s_barrier                                                  // 000000330970: BFBD0000
	buffer_gl0_inv                                             // 000000330974: E0AC0000 00000000
	s_and_b32 s0, vcc_lo, s0                                   // 00000033097C: 8B00006A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000330980: BF870009
	s_and_saveexec_b32 s1, s0                                  // 000000330984: BE812000
	s_cbranch_execz 30                                         // 000000330988: BFA5001E <_ZN7halogen12_GLOBAL__N_16k_lq6wILi1ELi32ELi8EEEvPKhPKtPtll+0xd04>
	v_mov_b32_e32 v8, 0                                        // 00000033098C: 7E100280
	s_lshl_b64 s[0:1], s[2:3], 1                               // 000000330990: 84808102
	ds_load_b128 v[0:3], v8                                    // 000000330994: DBFC0000 00000008
	ds_load_b128 v[4:7], v8 offset:16                          // 00000033099C: DBFC0010 04000008
	s_add_u32 s0, s8, s0                                       // 0000003309A4: 80000008
	s_addc_u32 s1, s9, s1                                      // 0000003309A8: 82010109
	s_waitcnt lgkmcnt(1)                                       // 0000003309AC: BF89FC17
	v_add_f32_e32 v0, 0, v0                                    // 0000003309B0: 06000080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003309B4: BF870091
	v_add_f32_e32 v0, v0, v1                                   // 0000003309B8: 06000300
	v_add_f32_e32 v0, v0, v2                                   // 0000003309BC: 06000500
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003309C0: BF8700A1
	v_add_f32_e32 v0, v0, v3                                   // 0000003309C4: 06000700
	s_waitcnt lgkmcnt(0)                                       // 0000003309C8: BF89FC07
	v_add_f32_e32 v0, v0, v4                                   // 0000003309CC: 06000900
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003309D0: BF870091
	v_add_f32_e32 v0, v0, v5                                   // 0000003309D4: 06000B00
	v_add_f32_e32 v0, v0, v6                                   // 0000003309D8: 06000D00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003309DC: BF870091
	v_add_f32_e32 v0, v0, v7                                   // 0000003309E0: 06000F00
	v_bfe_u32 v1, v0, 16, 1                                    // 0000003309E4: D6100001 02052100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003309EC: BF870091
	v_add_nc_u32_e32 v0, v0, v1                                // 0000003309F0: 4A000300
	v_add_nc_u32_e32 v0, 0x7fff, v0                            // 0000003309F4: 4A0000FF 00007FFF
	global_store_d16_hi_b16 v8, v0, s[0:1]                     // 0000003309FC: DC960000 00000008
	s_endpgm                                                   // 000000330A04: BFB00000
		...

