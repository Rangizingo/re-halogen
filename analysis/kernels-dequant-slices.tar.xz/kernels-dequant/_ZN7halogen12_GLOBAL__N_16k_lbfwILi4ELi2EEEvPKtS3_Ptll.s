00000000002d9a00 <_ZN7halogen12_GLOBAL__N_16k_lbfwILi4ELi2EEEvPKtS3_Ptll>:
; _ZN7halogen12_GLOBAL__N_16k_lbfwILi4ELi2EEEvPKtS3_Ptll():
	s_load_b64 s[8:9], s[0:1], 0x20                            // 0000002D9A00: F4040200 F8000020
	v_lshrrev_b32_e32 v1, 5, v0                                // 0000002D9A08: 32020085
	s_mov_b32 s3, 0                                            // 0000002D9A0C: BE830080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002D9A10: BF870009
	s_lshl_b64 s[2:3], s[2:3], 3                               // 0000002D9A14: 84828302
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000002D9A18: BF870481
	v_or_b32_e32 v1, s2, v1                                    // 0000002D9A1C: 38020202
	v_mov_b32_e32 v2, s3                                       // 0000002D9A20: 7E040203
	s_mov_b32 s2, exec_lo                                      // 0000002D9A24: BE82007E
	s_waitcnt lgkmcnt(0)                                       // 0000002D9A28: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002D9A2C: BF870001
	.long 0xd4d4007e                                           // 0000002D9A30: D4D4007E
	v_cndmask_b32_e32 v1, s8, v1, vcc_lo                       // 0000002D9A34: 02020208
	s_cbranch_execz 353                                        // 0000002D9A38: BFA50161 <_ZN7halogen12_GLOBAL__N_16k_lbfwILi4ELi2EEEvPKtS3_Ptll+0x5c0>
	s_load_b256 s[0:7], s[0:1], null                           // 0000002D9A3C: F40C0000 F8000000
	v_and_b32_e32 v0, 31, v0                                   // 0000002D9A44: 3600009F
	s_waitcnt lgkmcnt(0)                                       // 0000002D9A48: BF89FC07
	.long 0xd451000a                                           // 0000002D9A4C: D451000A
	v_cndmask_b32_e32 v0, s6, v129, vcc_lo                     // 0000002D9A50: 02010206
	s_and_b32 vcc_lo, exec_lo, s10                             // 0000002D9A54: 8B6A0A7E
	s_cbranch_vccnz 182                                        // 0000002D9A58: BFA400B6 <_ZN7halogen12_GLOBAL__N_16k_lbfwILi4ELi2EEEvPKtS3_Ptll+0x334>
	.long 0xd72c0007                                           // 0000002D9A5C: D72C0007
	v_cndmask_b32_e32 v1, s7, v1, vcc_lo                       // 0000002D9A60: 02020207
	.long 0xd72c0008                                           // 0000002D9A64: D72C0008
	v_cndmask_b32_e32 v1, s6, v2, vcc_lo                       // 0000002D9A68: 02020406
	v_mad_u64_u32 v[5:6], null, s6, v1, 0                      // 0000002D9A6C: D6FE7C05 02020206
	s_lshl_b64 s[10:11], s[6:7], 1                             // 0000002D9A74: 848A8106
	s_mul_i32 s12, s7, 6                                       // 0000002D9A78: 960C8607
	s_mul_hi_u32 s13, s6, 6                                    // 0000002D9A7C: 968D8606
	s_mul_i32 s14, s6, 6                                       // 0000002D9A80: 960E8606
	s_add_u32 s10, s2, s10                                     // 0000002D9A84: 800A0A02
	s_addc_u32 s11, s3, s11                                    // 0000002D9A88: 820B0B03
	s_add_i32 s13, s13, s12                                    // 0000002D9A8C: 810D0C0D
	v_add3_u32 v6, v6, v8, v7                                  // 0000002D9A90: D6550006 041E1106
	s_add_u32 s12, s2, s14                                     // 0000002D9A98: 800C0E02
	v_dual_mov_b32 v3, 0 :: v_dual_lshlrev_b32 v4, 4, v0       // 0000002D9A9C: CA220080 03040084
	s_addc_u32 s13, s3, s13                                    // 0000002D9AA4: 820D0D03
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002D9AA8: BF870122
	.long 0xd73c0005                                           // 0000002D9AAC: D73C0005
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 0000002D9AB0: 02020A81
	v_mov_b32_e32 v9, 0                                        // 0000002D9AB4: 7E120280
	.long 0xd7006a07                                           // 0000002D9AB8: D7006A07
	v_cndmask_b32_e32 v1, s0, v5, vcc_lo                       // 0000002D9ABC: 02020A00
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002D9AC0: BF870001
	v_add_co_ci_u32_e64 v8, null, s1, v6, vcc_lo               // 0000002D9AC4: D5207C08 01AA0C01
	s_lshl_b64 s[0:1], s[6:7], 2                               // 0000002D9ACC: 84808206
	v_dual_mov_b32 v6, 0 :: v_dual_mov_b32 v5, 0               // 0000002D9AD0: CA100080 06040080
	s_add_u32 s14, s2, s0                                      // 0000002D9AD8: 800E0002
	s_addc_u32 s15, s3, s1                                     // 0000002D9ADC: 820F0103
	s_mov_b64 s[0:1], 0                                        // 0000002D9AE0: BE800180
	.long 0xd7001022                                           // 0000002D9AE4: D7001022
	v_cndmask_b32_e32 v1, s2, v4, vcc_lo                       // 0000002D9AE8: 02020802
	.long 0xd7006a1e                                           // 0000002D9AEC: D7006A1E
	v_cndmask_b32_e32 v1, v7, v4, vcc_lo                       // 0000002D9AF0: 02020907
	v_add_co_ci_u32_e64 v35, null, s3, 0, s16                  // 0000002D9AF4: D5207C23 00410003
	.long 0xd7001026                                           // 0000002D9AFC: D7001026
	v_cndmask_b32_e32 v1, s10, v4, vcc_lo                      // 0000002D9B00: 0202080A
	v_add_co_ci_u32_e64 v31, null, 0, v8, vcc_lo               // 0000002D9B04: D5207C1F 01AA1080
	v_add_co_ci_u32_e64 v39, null, s11, 0, s16                 // 0000002D9B0C: D5207C27 0041000B
	.long 0xd700102a                                           // 0000002D9B14: D700102A
	v_cndmask_b32_e32 v1, s14, v4, vcc_lo                      // 0000002D9B18: 0202080E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002D9B1C: BF8700A1
	v_add_co_ci_u32_e64 v43, null, s15, 0, s16                 // 0000002D9B20: D5207C2B 0041000F
	.long 0xd700102e                                           // 0000002D9B28: D700102E
	v_cndmask_b32_e32 v1, s12, v4, vcc_lo                      // 0000002D9B2C: 0202080C
	v_add_co_ci_u32_e64 v47, null, s13, 0, s16                 // 0000002D9B30: D5207C2F 0041000D
	global_load_b128 v[10:13], v[30:31], off                   // 0000002D9B38: DC5E0000 0A7C001E
	global_load_b128 v[14:17], v[34:35], off                   // 0000002D9B40: DC5E0000 0E7C0022
	global_load_b128 v[18:21], v[38:39], off                   // 0000002D9B48: DC5E0000 127C0026
	global_load_b128 v[22:25], v[42:43], off                   // 0000002D9B50: DC5E0000 167C002A
	global_load_b128 v[26:29], v[46:47], off                   // 0000002D9B58: DC5E0000 1A7C002E
	global_load_b128 v[30:33], v[30:31], off offset:512        // 0000002D9B60: DC5E0200 1E7C001E
	global_load_b128 v[34:37], v[34:35], off offset:512        // 0000002D9B68: DC5E0200 227C0022
	global_load_b128 v[38:41], v[38:39], off offset:512        // 0000002D9B70: DC5E0200 267C0026
	global_load_b128 v[42:45], v[42:43], off offset:512        // 0000002D9B78: DC5E0200 2A7C002A
	global_load_b128 v[46:49], v[46:47], off offset:512        // 0000002D9B80: DC5E0200 2E7C002E
	s_add_u32 s0, s0, 0x200                                    // 0000002D9B88: 8000FF00 00000200
	s_addc_u32 s1, s1, 0                                       // 0000002D9B90: 82018001
	s_add_u32 s10, s10, 0x400                                  // 0000002D9B94: 800AFF0A 00000400
	s_addc_u32 s11, s11, 0                                     // 0000002D9B9C: 820B800B
	.long 0xd4560010                                           // 0000002D9BA0: D4560010
	v_cndmask_b32_e32 v0, s0, v6, vcc_lo                       // 0000002D9BA4: 02000C00
	.long 0xd7006a07                                           // 0000002D9BA8: D7006A07
	v_cndmask_b32_e32 v1, 0x400, v7, vcc_lo                    // 0000002D9BAC: 02020EFF 00000400
	s_add_u32 s12, s12, 0x400                                  // 0000002D9BB4: 800CFF0C 00000400
	s_addc_u32 s13, s13, 0                                     // 0000002D9BBC: 820D800D
	v_add_co_ci_u32_e64 v8, null, 0, v8, vcc_lo                // 0000002D9BC0: D5207C08 01AA1080
	s_add_u32 s2, s2, 0x400                                    // 0000002D9BC8: 8002FF02 00000400
	s_addc_u32 s3, s3, 0                                       // 0000002D9BD0: 82038003
	s_add_u32 s14, s14, 0x400                                  // 0000002D9BD4: 800EFF0E 00000400
	s_addc_u32 s15, s15, 0                                     // 0000002D9BDC: 820F800F
	s_and_b32 vcc_lo, exec_lo, s16                             // 0000002D9BE0: 8B6A107E
	s_waitcnt vmcnt(8)                                         // 0000002D9BE4: BF8923F7
	v_dot2_f32_bf16 v3, v14, v10, v3                           // 0000002D9BE8: CC1A4003 1C0E150E
	s_waitcnt vmcnt(7)                                         // 0000002D9BF0: BF891FF7
	v_dot2_f32_bf16 v9, v18, v10, v9                           // 0000002D9BF4: CC1A4009 1C261512
	s_waitcnt vmcnt(6)                                         // 0000002D9BFC: BF891BF7
	v_dot2_f32_bf16 v6, v22, v10, v6                           // 0000002D9C00: CC1A4006 1C1A1516
	s_waitcnt vmcnt(5)                                         // 0000002D9C08: BF8917F7
	v_dot2_f32_bf16 v5, v26, v10, v5                           // 0000002D9C0C: CC1A4005 1C16151A
	v_dot2_f32_bf16 v3, v15, v11, v3                           // 0000002D9C14: CC1A4003 1C0E170F
	v_dot2_f32_bf16 v9, v19, v11, v9                           // 0000002D9C1C: CC1A4009 1C261713
	v_dot2_f32_bf16 v6, v23, v11, v6                           // 0000002D9C24: CC1A4006 1C1A1717
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002D9C2C: BF870214
	v_dot2_f32_bf16 v5, v27, v11, v5                           // 0000002D9C30: CC1A4005 1C16171B
	v_dot2_f32_bf16 v3, v16, v12, v3                           // 0000002D9C38: CC1A4003 1C0E1910
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002D9C40: BF870214
	v_dot2_f32_bf16 v9, v20, v12, v9                           // 0000002D9C44: CC1A4009 1C261914
	v_dot2_f32_bf16 v6, v24, v12, v6                           // 0000002D9C4C: CC1A4006 1C1A1918
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002D9C54: BF870214
	v_dot2_f32_bf16 v5, v28, v12, v5                           // 0000002D9C58: CC1A4005 1C16191C
	v_dot2_f32_bf16 v3, v17, v13, v3                           // 0000002D9C60: CC1A4003 1C0E1B11
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002D9C68: BF870214
	v_dot2_f32_bf16 v9, v21, v13, v9                           // 0000002D9C6C: CC1A4009 1C261B15
	v_dot2_f32_bf16 v6, v25, v13, v6                           // 0000002D9C74: CC1A4006 1C1A1B19
	s_delay_alu instid0(VALU_DEP_4)                            // 0000002D9C7C: BF870004
	v_dot2_f32_bf16 v5, v29, v13, v5                           // 0000002D9C80: CC1A4005 1C161B1D
	s_waitcnt vmcnt(3)                                         // 0000002D9C88: BF890FF7
	v_dot2_f32_bf16 v3, v34, v30, v3                           // 0000002D9C8C: CC1A4003 1C0E3D22
	s_waitcnt vmcnt(2)                                         // 0000002D9C94: BF890BF7
	v_dot2_f32_bf16 v9, v38, v30, v9                           // 0000002D9C98: CC1A4009 1C263D26
	s_waitcnt vmcnt(1)                                         // 0000002D9CA0: BF8907F7
	v_dot2_f32_bf16 v6, v42, v30, v6                           // 0000002D9CA4: CC1A4006 1C1A3D2A
	s_waitcnt vmcnt(0)                                         // 0000002D9CAC: BF8903F7
	v_dot2_f32_bf16 v5, v46, v30, v5                           // 0000002D9CB0: CC1A4005 1C163D2E
	v_dot2_f32_bf16 v3, v35, v31, v3                           // 0000002D9CB8: CC1A4003 1C0E3F23
	v_dot2_f32_bf16 v9, v39, v31, v9                           // 0000002D9CC0: CC1A4009 1C263F27
	v_dot2_f32_bf16 v6, v43, v31, v6                           // 0000002D9CC8: CC1A4006 1C1A3F2B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002D9CD0: BF870214
	v_dot2_f32_bf16 v5, v47, v31, v5                           // 0000002D9CD4: CC1A4005 1C163F2F
	v_dot2_f32_bf16 v3, v36, v32, v3                           // 0000002D9CDC: CC1A4003 1C0E4124
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002D9CE4: BF870214
	v_dot2_f32_bf16 v9, v40, v32, v9                           // 0000002D9CE8: CC1A4009 1C264128
	v_dot2_f32_bf16 v6, v44, v32, v6                           // 0000002D9CF0: CC1A4006 1C1A412C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002D9CF8: BF870214
	v_dot2_f32_bf16 v5, v48, v32, v5                           // 0000002D9CFC: CC1A4005 1C164130
	v_dot2_f32_bf16 v3, v37, v33, v3                           // 0000002D9D04: CC1A4003 1C0E4325
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002D9D0C: BF870214
	v_dot2_f32_bf16 v9, v41, v33, v9                           // 0000002D9D10: CC1A4009 1C264329
	v_dot2_f32_bf16 v6, v45, v33, v6                           // 0000002D9D18: CC1A4006 1C1A432D
	s_delay_alu instid0(VALU_DEP_4)                            // 0000002D9D20: BF870004
	v_dot2_f32_bf16 v5, v49, v33, v5                           // 0000002D9D24: CC1A4005 1C164331
	s_cbranch_vccz 65389                                       // 0000002D9D2C: BFA3FF6D <_ZN7halogen12_GLOBAL__N_16k_lbfwILi4ELi2EEEvPKtS3_Ptll+0xe4>
	s_branch 4                                                 // 0000002D9D30: BFA00004 <_ZN7halogen12_GLOBAL__N_16k_lbfwILi4ELi2EEEvPKtS3_Ptll+0x344>
	v_dual_mov_b32 v5, 0 :: v_dual_mov_b32 v6, 0               // 0000002D9D34: CA100080 05060080
	v_mov_b32_e32 v9, 0                                        // 0000002D9D3C: 7E120280
	v_mov_b32_e32 v3, 0                                        // 0000002D9D40: 7E060280
	.long 0xd71f0004                                           // 0000002D9D44: D71F0004
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000002D9D48: 020100C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002D9D4C: BF870121
	v_xor_b32_e32 v7, 16, v4                                   // 0000002D9D50: 3A0E0890
	v_xor_b32_e32 v12, 8, v4                                   // 0000002D9D54: 3A180888
	v_cmp_gt_u32_e32 vcc_lo, 32, v7                            // 0000002D9D58: 7C980EA0
	v_cndmask_b32_e32 v7, v4, v7, vcc_lo                       // 0000002D9D5C: 020E0F04
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002D9D60: BF8700A3
	v_cmp_gt_u32_e32 vcc_lo, 32, v12                           // 0000002D9D64: 7C9818A0
	v_cndmask_b32_e32 v12, v4, v12, vcc_lo                     // 0000002D9D68: 02181904
	v_lshlrev_b32_e32 v12, 2, v12                              // 0000002D9D6C: 30181882
	s_delay_alu instid0(VALU_DEP_4)                            // 0000002D9D70: BF870004
	v_lshlrev_b32_e32 v7, 2, v7                                // 0000002D9D74: 300E0E82
	ds_bpermute_b32 v8, v7, v3                                 // 0000002D9D78: DACC0000 08000307
	ds_bpermute_b32 v10, v7, v9                                // 0000002D9D80: DACC0000 0A000907
	s_waitcnt lgkmcnt(0)                                       // 0000002D9D88: BF89FC07
	v_dual_add_f32 v3, v3, v8 :: v_dual_add_f32 v8, v9, v10    // 0000002D9D8C: C9081103 03081509
	ds_bpermute_b32 v11, v7, v6                                // 0000002D9D94: DACC0000 0B000607
	ds_bpermute_b32 v7, v7, v5                                 // 0000002D9D9C: DACC0000 07000507
	ds_bpermute_b32 v9, v12, v8                                // 0000002D9DA4: DACC0000 0900080C
	s_waitcnt lgkmcnt(2)                                       // 0000002D9DAC: BF89FC27
	v_add_f32_e32 v6, v6, v11                                  // 0000002D9DB0: 060C1706
	s_waitcnt lgkmcnt(1)                                       // 0000002D9DB4: BF89FC17
	v_add_f32_e32 v5, v5, v7                                   // 0000002D9DB8: 060A0F05
	ds_bpermute_b32 v7, v12, v3                                // 0000002D9DBC: DACC0000 0700030C
	ds_bpermute_b32 v10, v12, v6                               // 0000002D9DC4: DACC0000 0A00060C
	ds_bpermute_b32 v11, v12, v5                               // 0000002D9DCC: DACC0000 0B00050C
	v_xor_b32_e32 v12, 4, v4                                   // 0000002D9DD4: 3A180884
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002D9DD8: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v12                           // 0000002D9DDC: 7C9818A0
	s_waitcnt lgkmcnt(2)                                       // 0000002D9DE0: BF89FC27
	v_dual_cndmask_b32 v12, v4, v12 :: v_dual_add_f32 v3, v3, v7// 0000002D9DE4: CA481904 0C020F03
	v_dual_add_f32 v7, v8, v9 :: v_dual_lshlrev_b32 v12, 2, v12// 0000002D9DEC: C9221308 070C1882
	s_waitcnt lgkmcnt(0)                                       // 0000002D9DF4: BF89FC07
	v_dual_add_f32 v6, v6, v10 :: v_dual_add_f32 v5, v5, v11   // 0000002D9DF8: C9081506 06041705
	ds_bpermute_b32 v8, v12, v3                                // 0000002D9E00: DACC0000 0800030C
	ds_bpermute_b32 v9, v12, v7                                // 0000002D9E08: DACC0000 0900070C
	ds_bpermute_b32 v10, v12, v6                               // 0000002D9E10: DACC0000 0A00060C
	ds_bpermute_b32 v11, v12, v5                               // 0000002D9E18: DACC0000 0B00050C
	v_xor_b32_e32 v12, 2, v4                                   // 0000002D9E20: 3A180882
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000002D9E24: BF870151
	v_cmp_gt_u32_e32 vcc_lo, 32, v12                           // 0000002D9E28: 7C9818A0
	v_cndmask_b32_e32 v12, v4, v12, vcc_lo                     // 0000002D9E2C: 02181904
	s_waitcnt lgkmcnt(1)                                       // 0000002D9E30: BF89FC17
	v_dual_add_f32 v3, v3, v8 :: v_dual_add_f32 v6, v6, v10    // 0000002D9E34: C9081103 03061506
	s_waitcnt lgkmcnt(0)                                       // 0000002D9E3C: BF89FC07
	v_dual_add_f32 v5, v5, v11 :: v_dual_lshlrev_b32 v12, 2, v12// 0000002D9E40: C9221705 050C1882
	v_add_f32_e32 v8, v7, v9                                   // 0000002D9E48: 06101307
	ds_bpermute_b32 v7, v12, v3                                // 0000002D9E4C: DACC0000 0700030C
	s_waitcnt lgkmcnt(0)                                       // 0000002D9E54: BF89FC07
	v_add_f32_e32 v7, v3, v7                                   // 0000002D9E58: 060E0F03
	ds_bpermute_b32 v11, v12, v5                               // 0000002D9E5C: DACC0000 0B00050C
	ds_bpermute_b32 v10, v12, v6                               // 0000002D9E64: DACC0000 0A00060C
	s_waitcnt lgkmcnt(1)                                       // 0000002D9E6C: BF89FC17
	v_add_f32_e32 v3, v5, v11                                  // 0000002D9E70: 06061705
	ds_bpermute_b32 v9, v12, v8                                // 0000002D9E74: DACC0000 0900080C
	v_xor_b32_e32 v12, 1, v4                                   // 0000002D9E7C: 3A180881
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000002D9E80: BF870131
	v_cmp_gt_u32_e32 vcc_lo, 32, v12                           // 0000002D9E84: 7C9818A0
	v_cndmask_b32_e32 v4, v4, v12, vcc_lo                      // 0000002D9E88: 02081904
	v_cmp_eq_u32_e32 vcc_lo, 0, v0                             // 0000002D9E8C: 7C940080
	v_lshlrev_b32_e32 v12, 2, v4                               // 0000002D9E90: 30180882
	s_waitcnt lgkmcnt(1)                                       // 0000002D9E94: BF89FC17
	v_add_f32_e32 v4, v6, v10                                  // 0000002D9E98: 06081506
	s_waitcnt lgkmcnt(0)                                       // 0000002D9E9C: BF89FC07
	v_add_f32_e32 v8, v8, v9                                   // 0000002D9EA0: 06101308
	ds_bpermute_b32 v9, v12, v7                                // 0000002D9EA4: DACC0000 0900070C
	ds_bpermute_b32 v5, v12, v4                                // 0000002D9EAC: DACC0000 0500040C
	ds_bpermute_b32 v6, v12, v3                                // 0000002D9EB4: DACC0000 0600030C
	ds_bpermute_b32 v10, v12, v8                               // 0000002D9EBC: DACC0000 0A00080C
	s_and_b32 exec_lo, exec_lo, vcc_lo                         // 0000002D9EC4: 8B7E6A7E
	s_cbranch_execz 61                                         // 0000002D9EC8: BFA5003D <_ZN7halogen12_GLOBAL__N_16k_lbfwILi4ELi2EEEvPKtS3_Ptll+0x5c0>
	s_waitcnt lgkmcnt(0)                                       // 0000002D9ECC: BF89FC07
	v_dual_add_f32 v8, v8, v10 :: v_dual_add_f32 v7, v7, v9    // 0000002D9ED0: C9081508 08061307
	.long 0xd73c0000                                           // 0000002D9ED8: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000002D9EDC: 02020281
	.long 0x7f123880                                           // 0000002D9EE0: 7F123880
	v_dual_add_f32 v11, v4, v5 :: v_dual_add_f32 v12, v3, v6   // 0000002D9EE4: C9080B04 0B0C0D03
	s_delay_alu instid0(VALU_DEP_4)                            // 0000002D9EEC: BF870004
	.long 0x7e123988                                           // 0000002D9EF0: 7E123988
	.long 0x7e143987                                           // 0000002D9EF4: 7E143987
	.long 0xd7006a03                                           // 0000002D9EF8: D7006A03
	v_cndmask_b32_e32 v1, s4, v0, vcc_lo                       // 0000002D9EFC: 02020004
	.long 0x7f143989                                           // 0000002D9F00: 7F143989
	v_add_co_ci_u32_e64 v4, null, s5, v1, vcc_lo               // 0000002D9F04: D5207C04 01AA0205
	v_and_b32_e32 v2, 1, v9                                    // 0000002D9F0C: 36041281
	.long 0x7e12398c                                           // 0000002D9F10: 7E12398C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002D9F14: BF870214
	v_and_b32_e32 v5, 1, v10                                   // 0000002D9F18: 360A1481
	v_mad_u64_u32 v[0:1], null, s8, 6, v[3:4]                  // 0000002D9F1C: D6FE7C00 040D0C08
	s_lshl_b64 s[0:1], s[8:9], 1                               // 0000002D9F24: 84808108
	v_add3_u32 v10, v8, v2, 0x7fff                             // 0000002D9F28: D655000A 03FE0508 00007FFF
	.long 0x7e04398b                                           // 0000002D9F34: 7E04398B
	.long 0x7f043989                                           // 0000002D9F38: 7F043989
	v_add3_u32 v13, v7, v5, 0x7fff                             // 0000002D9F3C: D655000D 03FE0B07 00007FFF
	.long 0xd7006a05                                           // 0000002D9F48: D7006A05
	v_cndmask_b32_e32 v0, v3, v0, vcc_lo                       // 0000002D9F4C: 02000103
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002D9F50: BF870211
	v_add_co_ci_u32_e64 v6, null, s1, v4, vcc_lo               // 0000002D9F54: D5207C06 01AA0801
	v_and_b32_e32 v14, 1, v2                                   // 0000002D9F5C: 361C0481
	s_lshl_b64 s[0:1], s[8:9], 2                               // 0000002D9F60: 84808208
	v_and_b32_e32 v9, 1, v9                                    // 0000002D9F64: 36121281
	v_mad_u64_u32 v[1:2], null, s9, 6, v[1:2]                  // 0000002D9F68: D6FE7C01 04050C09
	.long 0xd7006a07                                           // 0000002D9F70: D7006A07
	v_cndmask_b32_e32 v0, v3, v0, vcc_lo                       // 0000002D9F74: 02000103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002D9F78: BF870001
	v_add_co_ci_u32_e64 v8, null, s1, v4, vcc_lo               // 0000002D9F7C: D5207C08 01AA0801
	v_add3_u32 v2, v11, v14, 0x7fff                            // 0000002D9F84: D6550002 03FE1D0B 00007FFF
	v_add3_u32 v9, v12, v9, 0x7fff                             // 0000002D9F90: D6550009 03FE130C 00007FFF
	s_clause 0x3                                               // 0000002D9F9C: BF850003
	global_store_d16_hi_b16 v[3:4], v13, off                   // 0000002D9FA0: DC960000 007C0D03
	global_store_d16_hi_b16 v[5:6], v10, off                   // 0000002D9FA8: DC960000 007C0A05
	global_store_d16_hi_b16 v[7:8], v2, off                    // 0000002D9FB0: DC960000 007C0207
	global_store_d16_hi_b16 v[0:1], v9, off                    // 0000002D9FB8: DC960000 007C0900
	s_endpgm                                                   // 0000002D9FC0: BFB00000
		...

