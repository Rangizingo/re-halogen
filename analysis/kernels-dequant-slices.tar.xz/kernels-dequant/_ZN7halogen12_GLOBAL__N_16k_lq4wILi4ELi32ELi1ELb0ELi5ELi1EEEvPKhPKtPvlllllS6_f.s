00000000008c6500 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[8:23], s[0:1], null                          // 0000008C6500: F4100200 F8000000
	v_and_b32_e32 v1, 15, v0                                   // 0000008C6508: 3602008F
	v_lshrrev_b32_e32 v2, 2, v0                                // 0000008C650C: 32040082
	s_ashr_i32 s3, s2, 31                                      // 0000008C6510: 86039F02
	v_lshrrev_b32_e32 v3, 5, v0                                // 0000008C6514: 32060085
	s_lshl_b64 s[2:3], s[2:3], 3                               // 0000008C6518: 84828302
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000008C651C: 30020282
	v_dual_mov_b32 v17, s3 :: v_dual_and_b32 v2, 60, v2        // 0000008C6520: CA240003 110204BC
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008C6528: BF870003
	v_or_b32_e32 v16, s2, v3                                   // 0000008C652C: 38200602
	.long 0x7f063880                                           // 0000008C6530: 7F063880
	v_and_b32_e32 v23, 31, v0                                  // 0000008C6534: 362E009F
	v_lshlrev_b32_e32 v0, 2, v0                                // 0000008C6538: 30000082
	s_waitcnt lgkmcnt(0)                                       // 0000008C653C: BF89FC07
	s_clause 0x1                                               // 0000008C6540: BF850001
	global_load_b32 v1, v1, s[8:9]                             // 0000008C6544: DC520000 01080001
	global_load_b32 v2, v2, s[8:9]                             // 0000008C654C: DC520000 02080002
	.long 0xd4540002                                           // 0000008C6554: D4540002
	v_cndmask_b32_e32 v1, s16, v16, vcc_lo                     // 0000008C6558: 02022010
	s_add_u32 s24, s8, s20                                     // 0000008C655C: 80181408
	s_addc_u32 s25, s9, s21                                    // 0000008C6560: 82191509
	s_ashr_i32 s4, s15, 31                                     // 0000008C6564: 86049F0F
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000008C6568: BF870159
	s_lshr_b32 s4, s4, 27                                      // 0000008C656C: 85049B04
	v_cndmask_b32_e64 v10, 0, v16, s2                          // 0000008C6570: D501000A 000A2080
	v_cndmask_b32_e64 v12, 0, s3, s2                           // 0000008C6578: D501000C 00080680
	s_add_u32 s4, s14, s4                                      // 0000008C6580: 8004040E
	s_addc_u32 s5, s15, 0                                      // 0000008C6584: 8205800F
	.long 0xd72c0004                                           // 0000008C6588: D72C0004
	v_cndmask_b32_e32 v1, s23, v10, vcc_lo                     // 0000008C658C: 02021417
	v_mad_u64_u32 v[8:9], null, s22, v10, 0                    // 0000008C6590: D6FE7C08 02021416
	s_lshr_b64 s[6:7], s[4:5], 5                               // 0000008C6598: 85868504
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000008C659C: BF870009
	s_cmpk_lt_i32 s6, 0x101                                    // 0000008C65A0: B3860101
	.long 0xd4440004                                           // 0000008C65A4: D4440004
	v_cndmask_b32_e32 v1, s6, v23, vcc_lo                      // 0000008C65A8: 02022E06
	s_cselect_b32 s3, -1, 0                                    // 0000008C65AC: 980380C1
	s_cmpk_gt_i32 s6, 0x100                                    // 0000008C65B0: B2860100
	.long 0xd700050b                                           // 0000008C65B4: D700050B
	v_cndmask_b32_e32 v1, s24, v8, vcc_lo                      // 0000008C65B8: 02021018
	s_cselect_b32 s7, -1, 0                                    // 0000008C65BC: 980780C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000008C65C0: BF870159
	s_and_b32 vcc_lo, exec_lo, s7                              // 0000008C65C4: 8B6A077E
	s_waitcnt vmcnt(1)                                         // 0000008C65C8: BF8907F7
	v_bfe_u32 v5, v1, 16, 1                                    // 0000008C65CC: D6100005 02052101
	s_waitcnt vmcnt(0)                                         // 0000008C65D4: BF8903F7
	v_bfe_u32 v6, v2, 16, 1                                    // 0000008C65D8: D6100006 02052102
	v_add3_u32 v1, v1, v5, 0x7fff                              // 0000008C65E0: D6550001 03FE0B01 00007FFF
	.long 0xd72c0005                                           // 0000008C65EC: D72C0005
	v_cndmask_b32_e32 v1, s22, v12, vcc_lo                     // 0000008C65F0: 02021816
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008C65F4: BF870193
	v_add3_u32 v2, v2, v6, 0x7fff                              // 0000008C65F8: D6550002 03FE0D02 00007FFF
	.long 0x7e063981                                           // 0000008C6604: 7E063981
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008C6608: BF870113
	v_add3_u32 v9, v9, v5, v4                                  // 0000008C660C: D6550009 04120B09
	v_and_or_b32 v1, 0xffff0000, v2, v3                        // 0000008C6614: D6570001 040E04FF FFFF0000
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008C6620: BF870002
	v_add_co_ci_u32_e64 v20, null, s25, v9, s5                 // 0000008C6624: D5207C14 00161219
	ds_store_b32 v0, v1                                        // 0000008C662C: D8340000 00000100
	s_waitcnt lgkmcnt(0)                                       // 0000008C6634: BF89FC07
	s_barrier                                                  // 0000008C6638: BFBD0000
	buffer_gl0_inv                                             // 0000008C663C: E0AC0000 00000000
	s_cbranch_vccnz 146                                        // 0000008C6644: BFA40092 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x390>
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v0, 0               // 0000008C6648: CA100080 01000080
	s_and_saveexec_b32 s5, s4                                  // 0000008C6650: BE852004
	s_cbranch_execz 10                                         // 0000008C6654: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x180>
	v_lshlrev_b32_e32 v0, 1, v23                               // 0000008C6658: 30002E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C665C: BF870091
	.long 0xd7006a02                                           // 0000008C6660: D7006A02
	v_cndmask_b32_e32 v1, v11, v0, vcc_lo                      // 0000008C6664: 0202010B
	v_add_co_ci_u32_e64 v3, null, 0, v20, vcc_lo               // 0000008C6668: D5207C03 01AA2880
	global_load_d16_b16 v0, v[2:3], off                        // 0000008C6670: DC820000 007C0002
	s_waitcnt vmcnt(0)                                         // 0000008C6678: BF8903F7
	v_cvt_f32_f16_e32 v0, v0                                   // 0000008C667C: 7E001700
	s_or_b32 exec_lo, exec_lo, s5                              // 0000008C6680: 8C7E057E
	v_or_b32_e32 v2, 32, v23                                   // 0000008C6684: 38042EA0
	s_mov_b32 s4, exec_lo                                      // 0000008C6688: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008C668C: BF870001
	.long 0xd4c4007e                                           // 0000008C6690: D4C4007E
	v_cndmask_b32_e32 v1, s6, v2, vcc_lo                       // 0000008C6694: 02020406
	s_cbranch_execz 10                                         // 0000008C6698: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x1c4>
	v_lshlrev_b32_e32 v1, 1, v2                                // 0000008C669C: 30020481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C66A0: BF870091
	.long 0xd7006a01                                           // 0000008C66A4: D7006A01
	v_cndmask_b32_e32 v1, v11, v1, vcc_lo                      // 0000008C66A8: 0202030B
	v_add_co_ci_u32_e64 v2, null, 0, v20, vcc_lo               // 0000008C66AC: D5207C02 01AA2880
	global_load_d16_b16 v1, v[1:2], off                        // 0000008C66B4: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000008C66BC: BF8903F7
	v_cvt_f32_f16_e32 v1, v1                                   // 0000008C66C0: 7E021701
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008C66C4: 8C7E047E
	v_or_b32_e32 v4, 64, v23                                   // 0000008C66C8: 38082EC0
	v_dual_mov_b32 v3, 0 :: v_dual_mov_b32 v2, 0               // 0000008C66CC: CA100080 03020080
	s_mov_b32 s4, exec_lo                                      // 0000008C66D4: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008C66D8: BF870002
	.long 0xd4c4007e                                           // 0000008C66DC: D4C4007E
	v_cndmask_b32_e32 v1, s6, v4, vcc_lo                       // 0000008C66E0: 02020806
	s_cbranch_execz 10                                         // 0000008C66E4: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x210>
	v_lshlrev_b32_e32 v2, 1, v4                                // 0000008C66E8: 30040881
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C66EC: BF870091
	.long 0xd7006a04                                           // 0000008C66F0: D7006A04
	v_cndmask_b32_e32 v1, v11, v2, vcc_lo                      // 0000008C66F4: 0202050B
	v_add_co_ci_u32_e64 v5, null, 0, v20, vcc_lo               // 0000008C66F8: D5207C05 01AA2880
	global_load_d16_b16 v2, v[4:5], off                        // 0000008C6700: DC820000 027C0004
	s_waitcnt vmcnt(0)                                         // 0000008C6708: BF8903F7
	v_cvt_f32_f16_e32 v2, v2                                   // 0000008C670C: 7E041702
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008C6710: 8C7E047E
	v_or_b32_e32 v4, 0x60, v23                                 // 0000008C6714: 38082EFF 00000060
	s_mov_b32 s4, exec_lo                                      // 0000008C671C: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008C6720: BF870001
	.long 0xd4c4007e                                           // 0000008C6724: D4C4007E
	v_cndmask_b32_e32 v1, s6, v4, vcc_lo                       // 0000008C6728: 02020806
	s_cbranch_execz 10                                         // 0000008C672C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x258>
	v_lshlrev_b32_e32 v3, 1, v4                                // 0000008C6730: 30060881
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C6734: BF870091
	.long 0xd7006a03                                           // 0000008C6738: D7006A03
	v_cndmask_b32_e32 v1, v11, v3, vcc_lo                      // 0000008C673C: 0202070B
	v_add_co_ci_u32_e64 v4, null, 0, v20, vcc_lo               // 0000008C6740: D5207C04 01AA2880
	global_load_d16_b16 v3, v[3:4], off                        // 0000008C6748: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 0000008C6750: BF8903F7
	v_cvt_f32_f16_e32 v3, v3                                   // 0000008C6754: 7E061703
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008C6758: 8C7E047E
	v_or_b32_e32 v6, 0x80, v23                                 // 0000008C675C: 380C2EFF 00000080
	v_dual_mov_b32 v5, 0 :: v_dual_mov_b32 v4, 0               // 0000008C6764: CA100080 05040080
	s_mov_b32 s4, exec_lo                                      // 0000008C676C: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008C6770: BF870002
	.long 0xd4c4007e                                           // 0000008C6774: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 0000008C6778: 02020C06
	s_cbranch_execz 10                                         // 0000008C677C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x2a8>
	v_lshlrev_b32_e32 v4, 1, v6                                // 0000008C6780: 30080C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C6784: BF870091
	.long 0xd7006a06                                           // 0000008C6788: D7006A06
	v_cndmask_b32_e32 v1, v11, v4, vcc_lo                      // 0000008C678C: 0202090B
	v_add_co_ci_u32_e64 v7, null, 0, v20, vcc_lo               // 0000008C6790: D5207C07 01AA2880
	global_load_d16_b16 v4, v[6:7], off                        // 0000008C6798: DC820000 047C0006
	s_waitcnt vmcnt(0)                                         // 0000008C67A0: BF8903F7
	v_cvt_f32_f16_e32 v4, v4                                   // 0000008C67A4: 7E081704
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008C67A8: 8C7E047E
	v_or_b32_e32 v6, 0xa0, v23                                 // 0000008C67AC: 380C2EFF 000000A0
	s_mov_b32 s4, exec_lo                                      // 0000008C67B4: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008C67B8: BF870001
	.long 0xd4c4007e                                           // 0000008C67BC: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 0000008C67C0: 02020C06
	s_cbranch_execz 10                                         // 0000008C67C4: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x2f0>
	v_lshlrev_b32_e32 v5, 1, v6                                // 0000008C67C8: 300A0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C67CC: BF870091
	.long 0xd7006a05                                           // 0000008C67D0: D7006A05
	v_cndmask_b32_e32 v1, v11, v5, vcc_lo                      // 0000008C67D4: 02020B0B
	v_add_co_ci_u32_e64 v6, null, 0, v20, vcc_lo               // 0000008C67D8: D5207C06 01AA2880
	global_load_d16_b16 v5, v[5:6], off                        // 0000008C67E0: DC820000 057C0005
	s_waitcnt vmcnt(0)                                         // 0000008C67E8: BF8903F7
	v_cvt_f32_f16_e32 v5, v5                                   // 0000008C67EC: 7E0A1705
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008C67F0: 8C7E047E
	v_or_b32_e32 v13, 0xc0, v23                                // 0000008C67F4: 381A2EFF 000000C0
	v_dual_mov_b32 v7, 0 :: v_dual_mov_b32 v6, 0               // 0000008C67FC: CA100080 07060080
	s_mov_b32 s4, exec_lo                                      // 0000008C6804: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008C6808: BF870002
	.long 0xd4c4007e                                           // 0000008C680C: D4C4007E
	v_cndmask_b32_e32 v1, s6, v13, vcc_lo                      // 0000008C6810: 02021A06
	s_cbranch_execz 10                                         // 0000008C6814: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x340>
	v_lshlrev_b32_e32 v6, 1, v13                               // 0000008C6818: 300C1A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C681C: BF870091
	.long 0xd7006a0d                                           // 0000008C6820: D7006A0D
	v_cndmask_b32_e32 v1, v11, v6, vcc_lo                      // 0000008C6824: 02020D0B
	v_add_co_ci_u32_e64 v14, null, 0, v20, vcc_lo              // 0000008C6828: D5207C0E 01AA2880
	global_load_d16_b16 v6, v[13:14], off                      // 0000008C6830: DC820000 067C000D
	s_waitcnt vmcnt(0)                                         // 0000008C6838: BF8903F7
	v_cvt_f32_f16_e32 v6, v6                                   // 0000008C683C: 7E0C1706
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008C6840: 8C7E047E
	v_or_b32_e32 v13, 0xe0, v23                                // 0000008C6844: 381A2EFF 000000E0
	s_mov_b32 s4, exec_lo                                      // 0000008C684C: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008C6850: BF870001
	.long 0xd4c4007e                                           // 0000008C6854: D4C4007E
	v_cndmask_b32_e32 v1, s6, v13, vcc_lo                      // 0000008C6858: 02021A06
	s_cbranch_execz 10                                         // 0000008C685C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x388>
	v_lshlrev_b32_e32 v7, 1, v13                               // 0000008C6860: 300E1A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C6864: BF870091
	.long 0xd7006a0d                                           // 0000008C6868: D7006A0D
	v_cndmask_b32_e32 v1, v11, v7, vcc_lo                      // 0000008C686C: 02020F0B
	v_add_co_ci_u32_e64 v14, null, 0, v20, vcc_lo              // 0000008C6870: D5207C0E 01AA2880
	global_load_d16_b16 v7, v[13:14], off                      // 0000008C6878: DC820000 077C000D
	s_waitcnt vmcnt(0)                                         // 0000008C6880: BF8903F7
	v_cvt_f32_f16_e32 v7, v7                                   // 0000008C6884: 7E0E1707
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008C6888: 8C7E047E
	s_branch 9                                                 // 0000008C688C: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x3b4>
	v_mov_b32_e32 v0, 0                                        // 0000008C6890: 7E000280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008C6894: BF870001
	v_mov_b32_e32 v1, v0                                       // 0000008C6898: 7E020300
	v_mov_b32_e32 v2, v0                                       // 0000008C689C: 7E040300
	v_mov_b32_e32 v3, v0                                       // 0000008C68A0: 7E060300
	v_mov_b32_e32 v4, v0                                       // 0000008C68A4: 7E080300
	v_mov_b32_e32 v5, v0                                       // 0000008C68A8: 7E0A0300
	v_mov_b32_e32 v6, v0                                       // 0000008C68AC: 7E0C0300
	v_mov_b32_e32 v7, v0                                       // 0000008C68B0: 7E0E0300
	s_add_u32 s4, s8, s18                                      // 0000008C68B4: 80041208
	s_addc_u32 s5, s9, s19                                     // 0000008C68B8: 82051309
	s_lshr_b32 s18, s15, 31                                    // 0000008C68BC: 85129F0F
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v13, 0             // 0000008C68C0: CA100080 180C0080
	s_add_u32 s18, s14, s18                                    // 0000008C68C8: 8012120E
	s_addc_u32 s19, s15, 0                                     // 0000008C68CC: 8213800F
	v_cndmask_b32_e64 v25, 0, 1, s7                            // 0000008C68D0: D5010019 001D0280
	s_ashr_i64 s[18:19], s[18:19], 1                           // 0000008C68D8: 86928112
	v_mov_b32_e32 v33, 0                                       // 0000008C68DC: 7E420280
	v_mad_u64_u32 v[18:19], null, v10, s18, s[4:5]             // 0000008C68E0: D6FE7C12 0010250A
	.long 0xd72c000a                                           // 0000008C68E8: D72C000A
	v_cndmask_b32_e32 v0, v10, v19, vcc_lo                     // 0000008C68EC: 0200270A
	.long 0xd72c000f                                           // 0000008C68F0: D72C000F
	v_cndmask_b32_e32 v0, v12, v18, vcc_lo                     // 0000008C68F4: 0200250C
	.long 0xd4440004                                           // 0000008C68F8: D4440004
	v_cndmask_b32_e32 v1, s6, v23, vcc_lo                      // 0000008C68FC: 02022E06
	v_mov_b32_e32 v12, 0                                       // 0000008C6900: 7E180280
	v_mov_b32_e32 v14, 0                                       // 0000008C6904: 7E1C0280
	s_delay_alu instid0(VALU_DEP_4)                            // 0000008C6908: BF870004
	v_add3_u32 v26, v15, v19, v10                              // 0000008C690C: D655001A 042A270F
	v_mov_b32_e32 v15, 0                                       // 0000008C6914: 7E1E0280
	s_and_saveexec_b32 s5, s4                                  // 0000008C6918: BE852004
	s_cbranch_execz 21                                         // 0000008C691C: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x474>
	v_dual_mov_b32 v33, 0 :: v_dual_lshlrev_b32 v10, 4, v23    // 0000008C6920: CA220080 210A2E84
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C6928: BF870091
	.long 0xd7006a0c                                           // 0000008C692C: D7006A0C
	v_cndmask_b32_e32 v1, v18, v10, vcc_lo                     // 0000008C6930: 02021512
	v_add_co_ci_u32_e64 v13, null, 0, v26, vcc_lo              // 0000008C6934: D5207C0D 01AA3480
	s_and_not1_b32 vcc_lo, exec_lo, s7                         // 0000008C693C: 916A077E
	global_load_b128 v[12:15], v[12:13], off                   // 0000008C6940: DC5E0000 0C7C000C
	s_cbranch_vccnz 10                                         // 0000008C6948: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x474>
	v_lshlrev_b32_e32 v10, 1, v23                              // 0000008C694C: 30142E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C6950: BF870091
	.long 0xd7006a0a                                           // 0000008C6954: D7006A0A
	v_cndmask_b32_e32 v1, v11, v10, vcc_lo                     // 0000008C6958: 0202150B
	v_add_co_ci_u32_e64 v11, null, 0, v20, vcc_lo              // 0000008C695C: D5207C0B 01AA2880
	global_load_d16_b16 v10, v[10:11], off                     // 0000008C6964: DC820000 0A7C000A
	s_waitcnt vmcnt(0)                                         // 0000008C696C: BF8903F7
	v_cvt_f32_f16_e32 v33, v10                                 // 0000008C6970: 7E42170A
	s_or_b32 exec_lo, exec_lo, s5                              // 0000008C6974: 8C7E057E
	v_dual_mov_b32 v27, 0 :: v_dual_mov_b32 v28, 0             // 0000008C6978: CA100080 1B1C0080
	v_mov_b32_e32 v29, 0                                       // 0000008C6980: 7E3A0280
	s_and_saveexec_b32 s5, s4                                  // 0000008C6984: BE852004
	s_cbranch_execz 447                                        // 0000008C6988: BFA501BF <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0xb88>
	v_dual_mov_b32 v31, v23 :: v_dual_lshlrev_b32 v10, 1, v23  // 0000008C698C: CA220117 1F0A2E81
	.long 0xd7006a08                                           // 0000008C6994: D7006A08
	v_cndmask_b32_e32 v1, s20, v8, vcc_lo                      // 0000008C6998: 02021014
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008C699C: BF8701A1
	v_add_co_ci_u32_e64 v9, null, s21, v9, vcc_lo              // 0000008C69A0: D5207C09 01AA1215
	v_dual_mov_b32 v20, 0 :: v_dual_lshlrev_b32 v19, 5, v23    // 0000008C69A8: CA220080 14122E85
	.long 0xd7006a08                                           // 0000008C69B0: D7006A08
	v_cndmask_b32_e32 v1, v8, v10, vcc_lo                      // 0000008C69B4: 02021508
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008C69B8: BF8701A1
	v_add_co_ci_u32_e64 v9, null, 0, v9, vcc_lo                // 0000008C69BC: D5207C09 01AA1280
	v_lshl_or_b32 v30, v23, 4, 0x200                           // 0000008C69C4: D656001E 03FD0917 00000200
	.long 0xd7006a08                                           // 0000008C69D0: D7006A08
	v_cndmask_b32_e32 v1, s8, v8, vcc_lo                       // 0000008C69D4: 02021008
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008C69D8: BF8701A1
	v_add_co_ci_u32_e64 v9, null, s9, v9, vcc_lo               // 0000008C69DC: D5207C09 01AA1209
	v_dual_mov_b32 v29, v20 :: v_dual_mov_b32 v32, v33         // 0000008C69E4: CA100114 1D200121
	.long 0xd7006a15                                           // 0000008C69EC: D7006A15
	v_cndmask_b32_e32 v0, v8, v192, vcc_lo                     // 0000008C69F0: 02018108
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008C69F4: BF870001
	v_add_co_ci_u32_e64 v22, null, 0, v9, vcc_lo               // 0000008C69F8: D5207C16 01AA1280
	v_mov_b32_e32 v28, v20                                     // 0000008C6A00: 7E380314
	v_mov_b32_e32 v27, v20                                     // 0000008C6A04: 7E360314
	v_mov_b32_e32 v24, v20                                     // 0000008C6A08: 7E300314
	s_mul_i32 s4, s15, 6                                       // 0000008C6A0C: 9604860F
	s_mul_hi_u32 s7, s14, 6                                    // 0000008C6A10: 9687860E
	s_lshl_b64 s[18:19], s[14:15], 2                           // 0000008C6A14: 8492820E
	s_add_i32 s7, s7, s4                                       // 0000008C6A18: 81070407
	s_mul_i32 s21, s14, 6                                      // 0000008C6A1C: 9615860E
	s_mov_b32 s20, 0                                           // 0000008C6A20: BE940080
	s_lshl_b64 s[8:9], s[14:15], 1                             // 0000008C6A24: 8488810E
	s_branch 378                                               // 0000008C6A28: BFA0017A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0xb14>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000008C6A2C: 8C7E0E7E
	v_cndmask_b32_e64 v33, v33, v0, s3                         // 0000008C6A30: D5010021 000E0121
	v_cndmask_b32_e64 v34, v0, v1, s3                          // 0000008C6A38: D5010022 000E0300
	v_dual_mov_b32 v41, v7 :: v_dual_and_b32 v0, 0xff, v12     // 0000008C6A40: CA240107 290018FF 000000FF
	v_cndmask_b32_e64 v40, v6, v7, s3                          // 0000008C6A4C: D5010028 000E0F06
	v_cndmask_b32_e64 v39, v5, v6, s3                          // 0000008C6A54: D5010027 000E0D05
	v_cndmask_b32_e64 v38, v4, v5, s3                          // 0000008C6A5C: D5010026 000E0B04
	v_cndmask_b32_e64 v37, v3, v4, s3                          // 0000008C6A64: D5010025 000E0903
	v_lshlrev_b32_e32 v0, 2, v0                                // 0000008C6A6C: 30000082
	v_cndmask_b32_e64 v36, v2, v3, s3                          // 0000008C6A70: D5010024 000E0702
	v_cndmask_b32_e64 v35, v1, v2, s3                          // 0000008C6A78: D5010023 000E0501
	s_and_b32 s4, exec_lo, s4                                  // 0000008C6A80: 8B04047E
	v_add_nc_u32_e32 v30, 0x200, v30                           // 0000008C6A84: 4A3C3CFF 00000200
	ds_load_b32 v48, v0                                        // 0000008C6A8C: D8D80000 30000000
	v_lshrrev_b32_e32 v0, 6, v12                               // 0000008C6A94: 32001886
	s_or_b32 s20, s4, s20                                      // 0000008C6A98: 8C141404
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008C6A9C: BF8700B1
	v_and_b32_e32 v0, 0x3fc, v0                                // 0000008C6AA0: 360000FF 000003FC
	ds_load_b32 v49, v0                                        // 0000008C6AA8: D8D80000 31000000
	v_lshrrev_b32_e32 v0, 14, v12                              // 0000008C6AB0: 3200188E
	v_and_b32_e32 v0, 0x3fc, v0                                // 0000008C6AB4: 360000FF 000003FC
	ds_load_b32 v50, v0                                        // 0000008C6ABC: D8D80000 32000000
	v_lshrrev_b32_e32 v0, 22, v12                              // 0000008C6AC4: 32001896
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008C6AC8: BF8700B1
	v_and_b32_e32 v0, 0x3fc, v0                                // 0000008C6ACC: 360000FF 000003FC
	ds_load_b32 v51, v0                                        // 0000008C6AD4: D8D80000 33000000
	v_and_b32_e32 v0, 0xff, v13                                // 0000008C6ADC: 36001AFF 000000FF
	v_lshlrev_b32_e32 v0, 2, v0                                // 0000008C6AE4: 30000082
	ds_load_b32 v52, v0                                        // 0000008C6AE8: D8D80000 34000000
	v_lshrrev_b32_e32 v0, 6, v13                               // 0000008C6AF0: 32001A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008C6AF4: BF8700B1
	v_and_b32_e32 v0, 0x3fc, v0                                // 0000008C6AF8: 360000FF 000003FC
	ds_load_b32 v53, v0                                        // 0000008C6B00: D8D80000 35000000
	v_lshrrev_b32_e32 v0, 14, v13                              // 0000008C6B08: 32001A8E
	v_and_b32_e32 v0, 0x3fc, v0                                // 0000008C6B0C: 360000FF 000003FC
	ds_load_b32 v54, v0                                        // 0000008C6B14: D8D80000 36000000
	v_lshrrev_b32_e32 v0, 22, v13                              // 0000008C6B1C: 32001A96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008C6B20: BF8700B1
	v_and_b32_e32 v0, 0x3fc, v0                                // 0000008C6B24: 360000FF 000003FC
	ds_load_b32 v55, v0                                        // 0000008C6B2C: D8D80000 37000000
	v_and_b32_e32 v0, 0xff, v14                                // 0000008C6B34: 36001CFF 000000FF
	v_lshlrev_b32_e32 v0, 2, v0                                // 0000008C6B3C: 30000082
	ds_load_b32 v56, v0                                        // 0000008C6B40: D8D80000 38000000
	v_lshrrev_b32_e32 v0, 6, v14                               // 0000008C6B48: 32001C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008C6B4C: BF8700B1
	v_and_b32_e32 v0, 0x3fc, v0                                // 0000008C6B50: 360000FF 000003FC
	ds_load_b32 v57, v0                                        // 0000008C6B58: D8D80000 39000000
	v_lshrrev_b32_e32 v0, 14, v14                              // 0000008C6B60: 32001C8E
	v_and_b32_e32 v0, 0x3fc, v0                                // 0000008C6B64: 360000FF 000003FC
	ds_load_b32 v58, v0                                        // 0000008C6B6C: D8D80000 3A000000
	v_lshrrev_b32_e32 v0, 22, v14                              // 0000008C6B74: 32001C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008C6B78: BF8700B1
	v_and_b32_e32 v0, 0x3fc, v0                                // 0000008C6B7C: 360000FF 000003FC
	ds_load_b32 v59, v0                                        // 0000008C6B84: D8D80000 3B000000
	v_and_b32_e32 v0, 0xff, v15                                // 0000008C6B8C: 36001EFF 000000FF
	v_lshlrev_b32_e32 v0, 2, v0                                // 0000008C6B94: 30000082
	ds_load_b32 v60, v0                                        // 0000008C6B98: D8D80000 3C000000
	v_lshrrev_b32_e32 v0, 6, v15                               // 0000008C6BA0: 32001E86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008C6BA4: BF8700B1
	v_and_b32_e32 v0, 0x3fc, v0                                // 0000008C6BA8: 360000FF 000003FC
	ds_load_b32 v61, v0                                        // 0000008C6BB0: D8D80000 3D000000
	v_lshrrev_b32_e32 v0, 14, v15                              // 0000008C6BB8: 32001E8E
	v_and_b32_e32 v0, 0x3fc, v0                                // 0000008C6BBC: 360000FF 000003FC
	ds_load_b32 v62, v0                                        // 0000008C6BC4: D8D80000 3E000000
	v_lshrrev_b32_e32 v0, 22, v15                              // 0000008C6BCC: 32001E96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000008C6BD0: BF870141
	v_and_b32_e32 v0, 0x3fc, v0                                // 0000008C6BD4: 360000FF 000003FC
	ds_load_b32 v63, v0                                        // 0000008C6BDC: D8D80000 3F000000
	.long 0xd73c0000                                           // 0000008C6BE4: D73C0000
	v_cndmask_b32_e32 v1, 1, v19, vcc_lo                       // 0000008C6BE8: 02022681
	v_add_nc_u32_e32 v19, 0x400, v19                           // 0000008C6BEC: 4A2626FF 00000400
	.long 0xd7006a2e                                           // 0000008C6BF4: D7006A2E
	v_cndmask_b32_e32 v1, s10, v0, vcc_lo                      // 0000008C6BF8: 0202000A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008C6BFC: BF870001
	v_add_co_ci_u32_e64 v47, null, s11, v1, vcc_lo             // 0000008C6C00: D5207C2F 01AA020B
	s_clause 0x3                                               // 0000008C6C08: BF850003
	global_load_b128 v[0:3], v[46:47], off                     // 0000008C6C0C: DC5E0000 007C002E
	global_load_b128 v[4:7], v[46:47], off offset:16           // 0000008C6C14: DC5E0010 047C002E
	global_load_b128 v[12:15], v[46:47], off offset:32         // 0000008C6C1C: DC5E0020 0C7C002E
	global_load_b128 v[42:45], v[46:47], off offset:48         // 0000008C6C24: DC5E0030 2A7C002E
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 0000008C6C2C: BF890CF7
	v_dot2_f32_bf16 v0, v0, v48, 0                             // 0000008C6C30: CC1A4000 1A026100
	s_waitcnt lgkmcnt(14)                                      // 0000008C6C38: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C6C3C: BF8700A1
	v_dot2_f32_bf16 v0, v1, v49, v0                            // 0000008C6C40: CC1A4000 1C026301
	s_waitcnt lgkmcnt(13)                                      // 0000008C6C48: BF89FCD7
	v_dot2_f32_bf16 v0, v2, v50, v0                            // 0000008C6C4C: CC1A4000 1C026502
	s_waitcnt lgkmcnt(12)                                      // 0000008C6C54: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C6C58: BF8700A1
	v_dot2_f32_bf16 v0, v3, v51, v0                            // 0000008C6C5C: CC1A4000 1C026703
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 0000008C6C64: BF8908B7
	v_dot2_f32_bf16 v0, v4, v52, v0                            // 0000008C6C68: CC1A4000 1C026904
	s_waitcnt lgkmcnt(10)                                      // 0000008C6C70: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C6C74: BF8700A1
	v_dot2_f32_bf16 v0, v5, v53, v0                            // 0000008C6C78: CC1A4000 1C026B05
	s_waitcnt lgkmcnt(9)                                       // 0000008C6C80: BF89FC97
	v_dot2_f32_bf16 v0, v6, v54, v0                            // 0000008C6C84: CC1A4000 1C026D06
	s_waitcnt lgkmcnt(8)                                       // 0000008C6C8C: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C6C90: BF8700A1
	v_dot2_f32_bf16 v0, v7, v55, v0                            // 0000008C6C94: CC1A4000 1C026F07
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 0000008C6C9C: BF890477
	v_dot2_f32_bf16 v0, v12, v56, v0                           // 0000008C6CA0: CC1A4000 1C02710C
	s_waitcnt lgkmcnt(6)                                       // 0000008C6CA8: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C6CAC: BF8700A1
	v_dot2_f32_bf16 v0, v13, v57, v0                           // 0000008C6CB0: CC1A4000 1C02730D
	s_waitcnt lgkmcnt(5)                                       // 0000008C6CB8: BF89FC57
	v_dot2_f32_bf16 v0, v14, v58, v0                           // 0000008C6CBC: CC1A4000 1C02750E
	s_waitcnt lgkmcnt(4)                                       // 0000008C6CC4: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C6CC8: BF8700A1
	v_dot2_f32_bf16 v0, v15, v59, v0                           // 0000008C6CCC: CC1A4000 1C02770F
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 0000008C6CD4: BF890037
	v_dot2_f32_bf16 v0, v42, v60, v0                           // 0000008C6CD8: CC1A4000 1C02792A
	.long 0xd7006a2a                                           // 0000008C6CE0: D7006A2A
	v_cndmask_b32_e32 v0, v46, v8, vcc_lo                      // 0000008C6CE4: 0200112E
	s_waitcnt lgkmcnt(2)                                       // 0000008C6CE8: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000008C6CEC: BF870132
	v_dot2_f32_bf16 v0, v43, v61, v0                           // 0000008C6CF0: CC1A4000 1C027B2B
	v_add_co_ci_u32_e64 v43, null, s9, v47, vcc_lo             // 0000008C6CF8: D5207C2B 01AA5E09
	s_waitcnt lgkmcnt(1)                                       // 0000008C6D00: BF89FC17
	v_dot2_f32_bf16 v0, v44, v62, v0                           // 0000008C6D04: CC1A4000 1C027D2C
	s_waitcnt lgkmcnt(0)                                       // 0000008C6D0C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C6D10: BF870091
	v_dot2_f32_bf16 v0, v45, v63, v0                           // 0000008C6D14: CC1A4000 1C027F2D
	v_fmac_f32_e32 v29, v33, v0                                // 0000008C6D1C: 563A0121
	s_clause 0x3                                               // 0000008C6D20: BF850003
	global_load_b128 v[0:3], v[42:43], off                     // 0000008C6D24: DC5E0000 007C002A
	global_load_b128 v[4:7], v[42:43], off offset:16           // 0000008C6D2C: DC5E0010 047C002A
	global_load_b128 v[12:15], v[42:43], off offset:32         // 0000008C6D34: DC5E0020 0C7C002A
	global_load_b128 v[42:45], v[42:43], off offset:48         // 0000008C6D3C: DC5E0030 2A7C002A
	s_waitcnt vmcnt(3)                                         // 0000008C6D44: BF890FF7
	v_dot2_f32_bf16 v0, v0, v48, 0                             // 0000008C6D48: CC1A4000 1A026100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C6D50: BF870091
	v_dot2_f32_bf16 v0, v1, v49, v0                            // 0000008C6D54: CC1A4000 1C026301
	v_dot2_f32_bf16 v0, v2, v50, v0                            // 0000008C6D5C: CC1A4000 1C026502
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C6D64: BF8700A1
	v_dot2_f32_bf16 v0, v3, v51, v0                            // 0000008C6D68: CC1A4000 1C026703
	s_waitcnt vmcnt(2)                                         // 0000008C6D70: BF890BF7
	v_dot2_f32_bf16 v0, v4, v52, v0                            // 0000008C6D74: CC1A4000 1C026904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C6D7C: BF870091
	v_dot2_f32_bf16 v0, v5, v53, v0                            // 0000008C6D80: CC1A4000 1C026B05
	v_dot2_f32_bf16 v0, v6, v54, v0                            // 0000008C6D88: CC1A4000 1C026D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C6D90: BF8700A1
	v_dot2_f32_bf16 v0, v7, v55, v0                            // 0000008C6D94: CC1A4000 1C026F07
	s_waitcnt vmcnt(1)                                         // 0000008C6D9C: BF8907F7
	v_dot2_f32_bf16 v0, v12, v56, v0                           // 0000008C6DA0: CC1A4000 1C02710C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C6DA8: BF870091
	v_dot2_f32_bf16 v0, v13, v57, v0                           // 0000008C6DAC: CC1A4000 1C02730D
	v_dot2_f32_bf16 v0, v14, v58, v0                           // 0000008C6DB4: CC1A4000 1C02750E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C6DBC: BF8700A1
	v_dot2_f32_bf16 v0, v15, v59, v0                           // 0000008C6DC0: CC1A4000 1C02770F
	s_waitcnt vmcnt(0)                                         // 0000008C6DC8: BF8903F7
	v_dot2_f32_bf16 v0, v42, v60, v0                           // 0000008C6DCC: CC1A4000 1C02792A
	.long 0xd7006a2a                                           // 0000008C6DD4: D7006A2A
	v_cndmask_b32_e32 v0, v46, v18, vcc_lo                     // 0000008C6DD8: 0200252E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008C6DDC: BF870122
	v_dot2_f32_bf16 v0, v43, v61, v0                           // 0000008C6DE0: CC1A4000 1C027B2B
	v_add_co_ci_u32_e64 v43, null, s19, v47, vcc_lo            // 0000008C6DE8: D5207C2B 01AA5E13
	v_dot2_f32_bf16 v0, v44, v62, v0                           // 0000008C6DF0: CC1A4000 1C027D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C6DF8: BF870091
	v_dot2_f32_bf16 v0, v45, v63, v0                           // 0000008C6DFC: CC1A4000 1C027F2D
	v_fmac_f32_e32 v28, v33, v0                                // 0000008C6E04: 56380121
	s_clause 0x3                                               // 0000008C6E08: BF850003
	global_load_b128 v[0:3], v[42:43], off                     // 0000008C6E0C: DC5E0000 007C002A
	global_load_b128 v[4:7], v[42:43], off offset:16           // 0000008C6E14: DC5E0010 047C002A
	global_load_b128 v[12:15], v[42:43], off offset:32         // 0000008C6E1C: DC5E0020 0C7C002A
	global_load_b128 v[42:45], v[42:43], off offset:48         // 0000008C6E24: DC5E0030 2A7C002A
	s_waitcnt vmcnt(3)                                         // 0000008C6E2C: BF890FF7
	v_dot2_f32_bf16 v0, v0, v48, 0                             // 0000008C6E30: CC1A4000 1A026100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C6E38: BF870091
	v_dot2_f32_bf16 v0, v1, v49, v0                            // 0000008C6E3C: CC1A4000 1C026301
	v_dot2_f32_bf16 v0, v2, v50, v0                            // 0000008C6E44: CC1A4000 1C026502
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C6E4C: BF8700A1
	v_dot2_f32_bf16 v0, v3, v51, v0                            // 0000008C6E50: CC1A4000 1C026703
	s_waitcnt vmcnt(2)                                         // 0000008C6E58: BF890BF7
	v_dot2_f32_bf16 v0, v4, v52, v0                            // 0000008C6E5C: CC1A4000 1C026904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C6E64: BF870091
	v_dot2_f32_bf16 v0, v5, v53, v0                            // 0000008C6E68: CC1A4000 1C026B05
	v_dot2_f32_bf16 v0, v6, v54, v0                            // 0000008C6E70: CC1A4000 1C026D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C6E78: BF8700A1
	v_dot2_f32_bf16 v0, v7, v55, v0                            // 0000008C6E7C: CC1A4000 1C026F07
	s_waitcnt vmcnt(1)                                         // 0000008C6E84: BF8907F7
	v_dot2_f32_bf16 v0, v12, v56, v0                           // 0000008C6E88: CC1A4000 1C02710C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C6E90: BF870091
	v_dot2_f32_bf16 v0, v13, v57, v0                           // 0000008C6E94: CC1A4000 1C02730D
	v_dot2_f32_bf16 v0, v14, v58, v0                           // 0000008C6E9C: CC1A4000 1C02750E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C6EA4: BF8700A1
	v_dot2_f32_bf16 v0, v15, v59, v0                           // 0000008C6EA8: CC1A4000 1C02770F
	s_waitcnt vmcnt(0)                                         // 0000008C6EB0: BF8903F7
	v_dot2_f32_bf16 v0, v42, v60, v0                           // 0000008C6EB4: CC1A4000 1C02792A
	.long 0xd7006a2a                                           // 0000008C6EBC: D7006A2A
	v_cndmask_b32_e32 v0, v46, v21, vcc_lo                     // 0000008C6EC0: 02002B2E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000008C6EC4: BF8701B2
	v_dot2_f32_bf16 v0, v43, v61, v0                           // 0000008C6EC8: CC1A4000 1C027B2B
	v_add_co_ci_u32_e64 v43, null, s7, v47, vcc_lo             // 0000008C6ED0: D5207C2B 01AA5E07
	.long 0xd7006a15                                           // 0000008C6ED8: D7006A15
	v_cndmask_b32_e32 v0, v21, v192, vcc_lo                    // 0000008C6EDC: 02018115
	v_dot2_f32_bf16 v0, v44, v62, v0                           // 0000008C6EE0: CC1A4000 1C027D2C
	v_add_co_ci_u32_e64 v22, null, 0, v22, vcc_lo              // 0000008C6EE8: D5207C16 01AA2C80
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C6EF0: BF870092
	v_dot2_f32_bf16 v0, v45, v63, v0                           // 0000008C6EF4: CC1A4000 1C027F2D
	v_fmac_f32_e32 v27, v33, v0                                // 0000008C6EFC: 56360121
	s_clause 0x3                                               // 0000008C6F00: BF850003
	global_load_b128 v[0:3], v[42:43], off                     // 0000008C6F04: DC5E0000 007C002A
	global_load_b128 v[4:7], v[42:43], off offset:16           // 0000008C6F0C: DC5E0010 047C002A
	global_load_b128 v[12:15], v[42:43], off offset:32         // 0000008C6F14: DC5E0020 0C7C002A
	global_load_b128 v[42:45], v[42:43], off offset:48         // 0000008C6F1C: DC5E0030 2A7C002A
	s_waitcnt vmcnt(3)                                         // 0000008C6F24: BF890FF7
	v_dot2_f32_bf16 v0, v0, v48, 0                             // 0000008C6F28: CC1A4000 1A026100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C6F30: BF870091
	v_dot2_f32_bf16 v0, v1, v49, v0                            // 0000008C6F34: CC1A4000 1C026301
	v_dot2_f32_bf16 v0, v2, v50, v0                            // 0000008C6F3C: CC1A4000 1C026502
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C6F44: BF8700A1
	v_dot2_f32_bf16 v0, v3, v51, v0                            // 0000008C6F48: CC1A4000 1C026703
	s_waitcnt vmcnt(2)                                         // 0000008C6F50: BF890BF7
	v_dot2_f32_bf16 v0, v4, v52, v0                            // 0000008C6F54: CC1A4000 1C026904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C6F5C: BF870091
	v_dot2_f32_bf16 v0, v5, v53, v0                            // 0000008C6F60: CC1A4000 1C026B05
	v_dot2_f32_bf16 v0, v6, v54, v0                            // 0000008C6F68: CC1A4000 1C026D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C6F70: BF8700A1
	v_dot2_f32_bf16 v0, v7, v55, v0                            // 0000008C6F74: CC1A4000 1C026F07
	s_waitcnt vmcnt(1)                                         // 0000008C6F7C: BF8907F7
	v_dot2_f32_bf16 v0, v12, v56, v0                           // 0000008C6F80: CC1A4000 1C02710C
	v_mov_b32_e32 v12, v8                                      // 0000008C6F88: 7E180308
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008C6F8C: BF870122
	v_dot2_f32_bf16 v0, v13, v57, v0                           // 0000008C6F90: CC1A4000 1C02730D
	v_mov_b32_e32 v13, v9                                      // 0000008C6F98: 7E1A0309
	v_dot2_f32_bf16 v0, v14, v58, v0                           // 0000008C6F9C: CC1A4000 1C02750E
	v_mov_b32_e32 v14, v10                                     // 0000008C6FA4: 7E1C030A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000008C6FA8: BF870132
	v_dot2_f32_bf16 v0, v15, v59, v0                           // 0000008C6FAC: CC1A4000 1C02770F
	v_mov_b32_e32 v15, v11                                     // 0000008C6FB4: 7E1E030B
	s_waitcnt vmcnt(0)                                         // 0000008C6FB8: BF8903F7
	v_dot2_f32_bf16 v0, v42, v60, v0                           // 0000008C6FBC: CC1A4000 1C02792A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C6FC4: BF870091
	v_dot2_f32_bf16 v0, v43, v61, v0                           // 0000008C6FC8: CC1A4000 1C027B2B
	v_dot2_f32_bf16 v0, v44, v62, v0                           // 0000008C6FD0: CC1A4000 1C027D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C6FD8: BF870091
	v_dot2_f32_bf16 v0, v45, v63, v0                           // 0000008C6FDC: CC1A4000 1C027F2D
	v_fmac_f32_e32 v24, v33, v0                                // 0000008C6FE4: 56300121
	v_dual_mov_b32 v0, v34 :: v_dual_mov_b32 v33, v32          // 0000008C6FE8: CA100122 00200120
	v_dual_mov_b32 v1, v35 :: v_dual_mov_b32 v2, v36           // 0000008C6FF0: CA100123 01020124
	v_dual_mov_b32 v3, v37 :: v_dual_mov_b32 v4, v38           // 0000008C6FF8: CA100125 03040126
	v_dual_mov_b32 v5, v39 :: v_dual_mov_b32 v6, v40           // 0000008C7000: CA100127 05060128
	v_mov_b32_e32 v7, v41                                      // 0000008C7008: 7E0E0329
	s_and_not1_b32 exec_lo, exec_lo, s20                       // 0000008C700C: 917E147E
	s_cbranch_execz 28                                         // 0000008C7010: BFA5001C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0xb84>
	s_waitcnt vmcnt(0)                                         // 0000008C7014: BF8903F7
	v_dual_mov_b32 v8, v12 :: v_dual_add_nc_u32 v31, 32, v31   // 0000008C7018: CA20010C 081E3EA0
	v_dual_mov_b32 v9, v13 :: v_dual_mov_b32 v10, v14          // 0000008C7020: CA10010D 090A010E
	v_mov_b32_e32 v11, v15                                     // 0000008C7028: 7E16030F
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008C702C: BF870003
	.long 0xd4430004                                           // 0000008C7030: D4430004
	v_cndmask_b32_e32 v1, s6, v31, vcc_lo                      // 0000008C7034: 02023E06
	s_mov_b32 s14, exec_lo                                     // 0000008C7038: BE8E007E
	.long 0xd4c4007e                                           // 0000008C703C: D4C4007E
	v_cndmask_b32_e32 v1, s6, v31, vcc_lo                      // 0000008C7040: 02023E06
	s_cbranch_execz 65145                                      // 0000008C7044: BFA5FE79 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x52c>
	.long 0xd7006a08                                           // 0000008C7048: D7006A08
	v_cndmask_b32_e32 v1, v18, v30, vcc_lo                     // 0000008C704C: 02023D12
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008C7050: BF870001
	v_add_co_ci_u32_e64 v9, null, 0, v26, vcc_lo               // 0000008C7054: D5207C09 01AA3480
	v_cmp_ne_u32_e32 vcc_lo, 1, v25                            // 0000008C705C: 7C9A3281
	v_mov_b32_e32 v32, v33                                     // 0000008C7060: 7E400321
	global_load_b128 v[8:11], v[8:9], off                      // 0000008C7064: DC5E0000 087C0008
	s_cbranch_vccnz 65135                                      // 0000008C706C: BFA4FE6F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x52c>
	global_load_d16_b16 v32, v[21:22], off                     // 0000008C7070: DC820000 207C0015
	s_waitcnt vmcnt(0)                                         // 0000008C7078: BF8903F7
	v_cvt_f32_f16_e32 v32, v32                                 // 0000008C707C: 7E401720
	s_branch 65130                                             // 0000008C7080: BFA0FE6A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x52c>
	s_or_b32 exec_lo, exec_lo, s20                             // 0000008C7084: 8C7E147E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C7088: BF8700A9
	s_or_b32 exec_lo, exec_lo, s5                              // 0000008C708C: 8C7E057E
	.long 0xd71f0000                                           // 0000008C7090: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000008C7094: 020100C1
	v_xor_b32_e32 v1, 16, v0                                   // 0000008C7098: 3A020090
	v_xor_b32_e32 v5, 8, v0                                    // 0000008C709C: 3A0A0088
	v_xor_b32_e32 v9, 4, v0                                    // 0000008C70A0: 3A120084
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000008C70A4: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v1                            // 0000008C70A8: 7C9802A0
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 0000008C70AC: 02020300
	v_cmp_gt_u32_e32 vcc_lo, 32, v5                            // 0000008C70B0: 7C980AA0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008C70B4: BF870002
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000008C70B8: 30020282
	ds_bpermute_b32 v4, v1, v27                                // 0000008C70BC: DACC0000 04001B01
	s_waitcnt lgkmcnt(0)                                       // 0000008C70C4: BF89FC07
	v_add_f32_e32 v4, v27, v4                                  // 0000008C70C8: 0608091B
	ds_bpermute_b32 v2, v1, v29                                // 0000008C70CC: DACC0000 02001D01
	ds_bpermute_b32 v3, v1, v28                                // 0000008C70D4: DACC0000 03001C01
	ds_bpermute_b32 v1, v1, v24                                // 0000008C70DC: DACC0000 01001801
	s_waitcnt lgkmcnt(2)                                       // 0000008C70E4: BF89FC27
	v_dual_add_f32 v2, v29, v2 :: v_dual_cndmask_b32 v5, v0, v5// 0000008C70E8: C912051D 02040B00
	s_waitcnt lgkmcnt(0)                                       // 0000008C70F0: BF89FC07
	v_add_f32_e32 v1, v24, v1                                  // 0000008C70F4: 06020318
	v_cmp_gt_u32_e32 vcc_lo, 32, v9                            // 0000008C70F8: 7C9812A0
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008C70FC: BF870003
	v_lshlrev_b32_e32 v5, 2, v5                                // 0000008C7100: 300A0A82
	v_cndmask_b32_e32 v9, v0, v9, vcc_lo                       // 0000008C7104: 02121300
	ds_bpermute_b32 v8, v5, v4                                 // 0000008C7108: DACC0000 08000405
	s_waitcnt lgkmcnt(0)                                       // 0000008C7110: BF89FC07
	v_add_f32_e32 v4, v4, v8                                   // 0000008C7114: 06081104
	ds_bpermute_b32 v6, v5, v2                                 // 0000008C7118: DACC0000 06000205
	s_waitcnt lgkmcnt(0)                                       // 0000008C7120: BF89FC07
	v_dual_add_f32 v2, v2, v6 :: v_dual_lshlrev_b32 v9, 2, v9  // 0000008C7124: C9220D02 02081282
	v_add_f32_e32 v3, v28, v3                                  // 0000008C712C: 0606071C
	ds_bpermute_b32 v7, v5, v3                                 // 0000008C7130: DACC0000 07000305
	ds_bpermute_b32 v5, v5, v1                                 // 0000008C7138: DACC0000 05000105
	s_waitcnt lgkmcnt(0)                                       // 0000008C7140: BF89FC07
	v_add_f32_e32 v1, v1, v5                                   // 0000008C7144: 06020B01
	ds_bpermute_b32 v5, v9, v2                                 // 0000008C7148: DACC0000 05000209
	s_waitcnt lgkmcnt(0)                                       // 0000008C7150: BF89FC07
	v_add_f32_e32 v2, v2, v5                                   // 0000008C7154: 06040B02
	v_xor_b32_e32 v5, 1, v0                                    // 0000008C7158: 3A0A0081
	v_add_f32_e32 v3, v3, v7                                   // 0000008C715C: 06060F03
	ds_bpermute_b32 v7, v9, v4                                 // 0000008C7160: DACC0000 07000409
	ds_bpermute_b32 v6, v9, v3                                 // 0000008C7168: DACC0000 06000309
	s_waitcnt lgkmcnt(0)                                       // 0000008C7170: BF89FC07
	v_dual_add_f32 v3, v3, v6 :: v_dual_add_f32 v6, v4, v7     // 0000008C7174: C9080D03 03060F04
	ds_bpermute_b32 v8, v9, v1                                 // 0000008C717C: DACC0000 08000109
	v_xor_b32_e32 v9, 2, v0                                    // 0000008C7184: 3A120082
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000008C7188: BF870131
	v_cmp_gt_u32_e32 vcc_lo, 32, v9                            // 0000008C718C: 7C9812A0
	v_cndmask_b32_e32 v9, v0, v9, vcc_lo                       // 0000008C7190: 02121300
	v_cmp_gt_u32_e32 vcc_lo, 32, v5                            // 0000008C7194: 7C980AA0
	v_lshlrev_b32_e32 v9, 2, v9                                // 0000008C7198: 30121282
	v_cndmask_b32_e32 v0, v0, v5, vcc_lo                       // 0000008C719C: 02000B00
	v_cmp_eq_u32_e32 vcc_lo, 0, v23                            // 0000008C71A0: 7C942E80
	s_waitcnt lgkmcnt(0)                                       // 0000008C71A4: BF89FC07
	v_add_f32_e32 v1, v1, v8                                   // 0000008C71A8: 06021101
	ds_bpermute_b32 v4, v9, v2                                 // 0000008C71AC: DACC0000 04000209
	ds_bpermute_b32 v7, v9, v3                                 // 0000008C71B4: DACC0000 07000309
	ds_bpermute_b32 v8, v9, v6                                 // 0000008C71BC: DACC0000 08000609
	v_lshlrev_b32_e32 v10, 2, v0                               // 0000008C71C4: 30140082
	ds_bpermute_b32 v9, v9, v1                                 // 0000008C71C8: DACC0000 09000109
	s_and_b32 s2, vcc_lo, s2                                   // 0000008C71D0: 8B02026A
	s_waitcnt lgkmcnt(2)                                       // 0000008C71D4: BF89FC27
	v_dual_add_f32 v5, v2, v4 :: v_dual_add_f32 v4, v3, v7     // 0000008C71D8: C9080902 05040F03
	s_waitcnt lgkmcnt(0)                                       // 0000008C71E0: BF89FC07
	v_dual_add_f32 v0, v6, v8 :: v_dual_add_f32 v1, v1, v9     // 0000008C71E4: C9081106 00001301
	ds_bpermute_b32 v6, v10, v5                                // 0000008C71EC: DACC0000 0600050A
	ds_bpermute_b32 v7, v10, v4                                // 0000008C71F4: DACC0000 0700040A
	ds_bpermute_b32 v2, v10, v0                                // 0000008C71FC: DACC0000 0200000A
	ds_bpermute_b32 v3, v10, v1                                // 0000008C7204: DACC0000 0300010A
	s_and_saveexec_b32 s3, s2                                  // 0000008C720C: BE832002
	s_cbranch_execz 100                                        // 0000008C7210: BFA50064 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0xea4>
	v_ashrrev_i32_e32 v8, 31, v17                              // 0000008C7214: 3410229F
	s_load_b64 s[2:3], s[0:1], 0x40                            // 0000008C7218: F4040080 F8000040
	s_lshr_b32 s0, s17, 31                                     // 0000008C7220: 85009F11
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000008C7224: BF890007
	v_dual_mov_b32 v13, s12 :: v_dual_add_f32 v6, v5, v6       // 0000008C7228: CA08000C 0D060D05
	v_lshrrev_b32_e32 v8, 23, v8                               // 0000008C7230: 32101097
	s_add_u32 s4, s16, s0                                      // 0000008C7234: 80040010
	.long 0x7f1c3880                                           // 0000008C7238: 7F1C3880
	s_addc_u32 s5, s17, 0                                      // 0000008C723C: 82058011
	v_mov_b32_e32 v12, s13                                     // 0000008C7240: 7E18020D
	.long 0xd7006a08                                           // 0000008C7244: D7006A08
	v_cndmask_b32_e32 v1, v16, v8, vcc_lo                      // 0000008C7248: 02021110
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008C724C: BF870111
	v_add_co_ci_u32_e64 v10, null, 0, v17, vcc_lo              // 0000008C7250: D5207C0A 01AA2280
	v_and_b32_e32 v11, 0xfffffe00, v8                          // 0000008C7258: 361610FF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C7260: BF870091
	.long 0xd7016a08                                           // 0000008C7264: D7016A08
	v_cndmask_b32_e32 v1, v16, v11, vcc_lo                     // 0000008C7268: 02021710
	v_sub_co_ci_u32_e64 v9, null, v17, v10, vcc_lo             // 0000008C726C: D5217C09 01AA1511
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008C7274: BF8700B1
	v_cmp_gt_i64_e32 vcc_lo, 0x100, v[8:9]                     // 0000008C7278: 7CA810FF 00000100
	v_add_f32_e32 v7, v4, v7                                   // 0000008C7280: 060E0F04
	.long 0xd7000004                                           // 0000008C7284: D7000004
	v_cndmask_b32_e32 v1, 0xffffff00, v8, vcc_lo               // 0000008C7288: 020210FF FFFFFF00
	v_add_co_ci_u32_e64 v5, null, -1, v9, s0                   // 0000008C7290: D5207C05 000212C1
	v_cndmask_b32_e32 v12, s3, v12, vcc_lo                     // 0000008C7298: 02181803
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000008C729C: BF870223
	v_cndmask_b32_e32 v4, v4, v8, vcc_lo                       // 0000008C72A0: 02081104
	.long 0x7e103986                                           // 0000008C72A4: 7E103986
	v_cndmask_b32_e32 v5, v5, v9, vcc_lo                       // 0000008C72A8: 020A1305
	.long 0x7f10398e                                           // 0000008C72AC: 7F10398E
	v_cndmask_b32_e32 v9, s2, v13, vcc_lo                      // 0000008C72B0: 02121A02
	.long 0x7e1c3987                                           // 0000008C72B4: 7E1C3987
	s_ashr_i64 s[0:1], s[4:5], 1                               // 0000008C72B8: 86808104
	.long 0xd73c0004                                           // 0000008C72BC: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 0000008C72C0: 02020881
	v_and_b32_e32 v8, 1, v8                                    // 0000008C72C4: 36101081
	.long 0xd7006a09                                           // 0000008C72C8: D7006A09
	v_cndmask_b32_e32 v1, v9, v11, vcc_lo                      // 0000008C72CC: 02021709
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008C72D0: BF8701A1
	v_add_co_ci_u32_e64 v10, null, v12, v10, vcc_lo            // 0000008C72D4: D5207C0A 01AA150C
	v_and_b32_e32 v13, 1, v14                                  // 0000008C72DC: 361A1C81
	.long 0xd7006a04                                           // 0000008C72E0: D7006A04
	v_cndmask_b32_e32 v1, v9, v4, vcc_lo                       // 0000008C72E4: 02020909
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000008C72E8: BF8701B1
	v_add_co_ci_u32_e64 v5, null, v10, v5, vcc_lo              // 0000008C72EC: D5207C05 01AA0B0A
	v_dual_add_f32 v9, v1, v3 :: v_dual_add_f32 v10, v0, v2    // 0000008C72F4: C9080701 090A0500
	.long 0x7f04398e                                           // 0000008C72FC: 7F04398E
	v_mad_u64_u32 v[0:1], null, s0, 6, v[4:5]                  // 0000008C7300: D6FE7C00 04110C00
	s_and_b32 s2, s4, -2                                       // 0000008C7308: 8B02C204
	.long 0x7e1c3989                                           // 0000008C730C: 7E1C3989
	.long 0x7e04398a                                           // 0000008C7310: 7E04398A
	v_add3_u32 v11, v7, v13, 0x7fff                            // 0000008C7314: D655000B 03FE1B07 00007FFF
	v_add3_u32 v8, v6, v8, 0x7fff                              // 0000008C7320: D6550008 03FE1106 00007FFF
	.long 0xd7006a06                                           // 0000008C732C: D7006A06
	v_cndmask_b32_e32 v0, v4, v2, vcc_lo                       // 0000008C7330: 02000504
	s_delay_alu instid0(VALU_DEP_4)                            // 0000008C7334: BF870004
	v_and_b32_e32 v13, 1, v2                                   // 0000008C7338: 361A0481
	s_lshl_b64 s[2:3], s[0:1], 2                               // 0000008C733C: 84828200
	v_and_b32_e32 v12, 1, v14                                  // 0000008C7340: 36181C81
	v_mad_u64_u32 v[1:2], null, s1, 6, v[1:2]                  // 0000008C7344: D6FE7C01 04050C01
	v_add_co_ci_u32_e64 v7, null, s5, v5, vcc_lo               // 0000008C734C: D5207C07 01AA0A05
	.long 0xd7006a02                                           // 0000008C7354: D7006A02
	v_cndmask_b32_e32 v0, v4, v2, vcc_lo                       // 0000008C7358: 02000504
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008C735C: BF870001
	v_add_co_ci_u32_e64 v3, null, s3, v5, vcc_lo               // 0000008C7360: D5207C03 01AA0A03
	v_add3_u32 v10, v10, v13, 0x7fff                           // 0000008C7368: D655000A 03FE1B0A 00007FFF
	v_add3_u32 v9, v9, v12, 0x7fff                             // 0000008C7374: D6550009 03FE1909 00007FFF
	s_clause 0x3                                               // 0000008C7380: BF850003
	global_store_d16_hi_b16 v[4:5], v8, off                    // 0000008C7384: DC960000 007C0804
	global_store_d16_hi_b16 v[6:7], v11, off                   // 0000008C738C: DC960000 007C0B06
	global_store_d16_hi_b16 v[2:3], v10, off                   // 0000008C7394: DC960000 007C0A02
	global_store_d16_hi_b16 v[0:1], v9, off                    // 0000008C739C: DC960000 007C0900
	s_endpgm                                                   // 0000008C73A4: BFB00000
		...

