0000000000d3c200 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt>:
; _ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt():
	s_load_b256 s[8:15], s[0:1], null                          // 000000D3C200: F40C0200 F8000000
	s_mov_b32 s3, 0                                            // 000000D3C208: BE830080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000D3C20C: BF870009
	s_lshl_b64 s[4:5], s[2:3], 4                               // 000000D3C210: 84848402
	s_waitcnt lgkmcnt(0)                                       // 000000D3C214: BF89FC07
	s_add_u32 s4, s12, s4                                      // 000000D3C218: 8004040C
	s_addc_u32 s5, s13, s5                                     // 000000D3C21C: 8205050D
	s_load_b128 s[16:19], s[4:5], null                         // 000000D3C220: F4080402 F8000000
	s_load_b64 s[6:7], s[0:1], 0x20                            // 000000D3C228: F4040180 F8000020
	s_waitcnt lgkmcnt(0)                                       // 000000D3C230: BF89FC07
	s_sub_i32 s0, s19, s18                                     // 000000D3C234: 81801213
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000D3C238: BF870499
	s_min_i32 s19, s0, 64                                      // 000000D3C23C: 8913C000
	s_add_i32 s0, s19, 15                                      // 000000D3C240: 81008F13
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000D3C244: BF870009
	s_ashr_i32 s20, s0, 4                                      // 000000D3C248: 86148400
	s_mov_b32 s0, -1                                           // 000000D3C24C: BE8000C1
	s_cmp_lt_i32 s20, 3                                        // 000000D3C250: BF048314
	s_cbranch_scc1 6674                                        // 000000D3C254: BFA21A12 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x68a0>
	v_or_b32_e32 v57, 0x200, v0                                // 000000D3C258: 387200FF 00000200
	.long 0xd44c0000                                           // 000000D3C260: D44C0000
	v_cndmask_b32_e32 v1, 0x300, v0, vcc_lo                    // 000000D3C264: 020200FF 00000300
	s_cmp_gt_i32 s20, 3                                        // 000000D3C26C: BF028314
	s_mov_b32 s1, -1                                           // 000000D3C270: BE8100C1
	s_cbranch_scc0 3646                                        // 000000D3C274: BFA10E3E <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x3970>
	v_lshrrev_b32_e32 v19, 4, v0                               // 000000D3C278: 32260084
	v_or_b32_e32 v1, 0x100, v0                                 // 000000D3C27C: 380200FF 00000100
	s_add_i32 s1, s19, -1                                      // 000000D3C284: 8101C113
	v_or_b32_e32 v4, 0x300, v0                                 // 000000D3C288: 380800FF 00000300
	v_lshlrev_b32_e32 v2, 3, v0                                // 000000D3C290: 30040083
	v_min_i32_e32 v3, s1, v19                                  // 000000D3C294: 22062601
	v_lshrrev_b32_e32 v9, 4, v1                                // 000000D3C298: 32120284
	v_lshrrev_b32_e32 v1, 4, v57                               // 000000D3C29C: 32027284
	v_lshrrev_b32_e32 v4, 4, v4                                // 000000D3C2A0: 32080884
	v_and_b32_e32 v58, 0x78, v2                                // 000000D3C2A4: 367404FF 00000078
	v_add_nc_u32_e32 v2, s18, v3                               // 000000D3C2AC: 4A040612
	v_min_i32_e32 v3, s1, v9                                   // 000000D3C2B0: 22061201
	v_min_i32_e32 v5, s1, v1                                   // 000000D3C2B4: 220A0201
	v_min_i32_e32 v7, s1, v4                                   // 000000D3C2B8: 220E0801
	v_lshlrev_b32_e32 v10, 1, v58                              // 000000D3C2BC: 30147481
	v_mad_i64_i32 v[1:2], null, 0x500, v2, 0                   // 000000D3C2C0: D6FF7C01 020204FF 00000500
	v_add_nc_u32_e32 v3, s18, v3                               // 000000D3C2CC: 4A060612
	v_add_nc_u32_e32 v5, s18, v5                               // 000000D3C2D0: 4A0A0A12
	v_add_nc_u32_e32 v7, s18, v7                               // 000000D3C2D4: 4A0E0E12
	.long 0xd7000111                                           // 000000D3C2D8: D7000111
	v_cndmask_b32_e32 v1, s10, v10, vcc_lo                     // 000000D3C2DC: 0202140A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D3C2E0: BF870214
	v_mad_i64_i32 v[3:4], null, 0x500, v3, 0                   // 000000D3C2E4: D6FF7C03 020206FF 00000500
	v_mad_i64_i32 v[5:6], null, 0x500, v5, 0                   // 000000D3C2F0: D6FF7C05 02020AFF 00000500
	v_add_co_ci_u32_e64 v18, null, s11, 0, s1                  // 000000D3C2FC: D5207C12 0005000B
	v_mad_i64_i32 v[7:8], null, 0x500, v7, 0                   // 000000D3C304: D6FF7C07 02020EFF 00000500
	.long 0xd7006a0b                                           // 000000D3C310: D7006A0B
	v_cndmask_b32_e32 v1, v17, v1, vcc_lo                      // 000000D3C314: 02020311
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D3C318: BF8700A1
	v_add_co_ci_u32_e64 v12, null, v18, v2, vcc_lo             // 000000D3C31C: D5207C0C 01AA0512
	.long 0xd7006a0d                                           // 000000D3C324: D7006A0D
	v_cndmask_b32_e32 v1, v17, v3, vcc_lo                      // 000000D3C328: 02020711
	v_add_co_ci_u32_e64 v14, null, v18, v4, vcc_lo             // 000000D3C32C: D5207C0E 01AA0912
	.long 0xd7006a0f                                           // 000000D3C334: D7006A0F
	v_cndmask_b32_e32 v1, v17, v5, vcc_lo                      // 000000D3C338: 02020B11
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D3C33C: BF8700A1
	v_add_co_ci_u32_e64 v16, null, v18, v6, vcc_lo             // 000000D3C340: D5207C10 01AA0D12
	.long 0xd7006a11                                           // 000000D3C348: D7006A11
	v_cndmask_b32_e32 v1, v17, v7, vcc_lo                      // 000000D3C34C: 02020F11
	v_add_co_ci_u32_e64 v18, null, v18, v8, vcc_lo             // 000000D3C350: D5207C12 01AA1112
	s_clause 0x3                                               // 000000D3C358: BF850003
	global_load_b128 v[33:36], v[11:12], off                   // 000000D3C35C: DC5E0000 217C000B
	global_load_b128 v[37:40], v[13:14], off                   // 000000D3C364: DC5E0000 257C000D
	global_load_b128 v[41:44], v[15:16], off                   // 000000D3C36C: DC5E0000 297C000F
	global_load_b128 v[45:48], v[17:18], off                   // 000000D3C374: DC5E0000 2D7C0011
	v_mul_u32_u24_e32 v60, 0x88, v19                           // 000000D3C37C: 167826FF 00000088
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D3C384: BF870001
	v_lshl_add_u32 v11, v60, 1, v10                            // 000000D3C388: D646000B 0429033C
	s_waitcnt vmcnt(3)                                         // 000000D3C390: BF890FF7
	ds_store_b128 v11, v[33:36]                                // 000000D3C394: DB7C0000 0000210B
	s_and_saveexec_b32 s1, s0                                  // 000000D3C39C: BE812000
	s_cbranch_execnz 10509                                     // 000000D3C3A0: BFA6290D <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0xa5d8>
	s_or_b32 exec_lo, exec_lo, s1                              // 000000D3C3A4: 8C7E017E
	.long 0xd44c0001                                           // 000000D3C3A8: D44C0001
	v_cndmask_b32_e32 v1, 0x200, v0, vcc_lo                    // 000000D3C3AC: 020200FF 00000200
	s_and_saveexec_b32 s2, s1                                  // 000000D3C3B4: BE822001
	s_cbranch_execnz 10515                                     // 000000D3C3B8: BFA62913 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0xa608>
	s_or_b32 exec_lo, exec_lo, s2                              // 000000D3C3BC: 8C7E027E
	.long 0xd44c0002                                           // 000000D3C3C0: D44C0002
	v_cndmask_b32_e32 v1, 0x100, v0, vcc_lo                    // 000000D3C3C4: 020200FF 00000100
	s_and_saveexec_b32 s3, s2                                  // 000000D3C3CC: BE832002
	s_cbranch_execz 3                                          // 000000D3C3D0: BFA50003 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x1e0>
	s_waitcnt vmcnt(0)                                         // 000000D3C3D4: BF8903F7
	ds_store_b128 v11, v[45:48] offset:13056                   // 000000D3C3D8: DB7C3300 00002D0B
	s_or_b32 exec_lo, exec_lo, s3                              // 000000D3C3E0: 8C7E037E
	v_dual_mov_b32 v26, 0 :: v_dual_and_b32 v59, 31, v0        // 000000D3C3E4: CA240080 1A3A009F
	.long 0xd7006a07                                           // 000000D3C3EC: D7006A07
	v_cndmask_b32_e32 v1, s10, v7, vcc_lo                      // 000000D3C3F0: 02020E0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D3C3F4: BF8700A1
	v_add_co_ci_u32_e64 v8, null, s11, v8, vcc_lo              // 000000D3C3F8: D5207C08 01AA100B
	.long 0xd7006a0c                                           // 000000D3C400: D7006A0C
	v_cndmask_b32_e32 v1, s10, v5, vcc_lo                      // 000000D3C404: 02020A0A
	v_add_co_ci_u32_e64 v13, null, s11, v6, vcc_lo             // 000000D3C408: D5207C0D 01AA0C0B
	v_cmp_ne_u32_e32 vcc_lo, 0, v59                            // 000000D3C410: 7C9A7680
	v_lshlrev_b32_e32 v10, 5, v59                              // 000000D3C414: 30147685
	s_mul_i32 s3, s16, 0xc8000                                 // 000000D3C418: 9603FF10 000C8000
	s_mul_i32 s13, s17, 0xa000                                 // 000000D3C420: 960DFF11 0000A000
	s_mul_hi_i32 s4, s16, 0xc8000                              // 000000D3C428: 9704FF10 000C8000
	s_mul_hi_i32 s5, s17, 0xa000                               // 000000D3C430: 9705FF11 0000A000
	s_add_u32 s13, s3, s13                                     // 000000D3C438: 800D0D03
	s_addc_u32 s4, s4, s5                                      // 000000D3C43C: 82040504
	v_add_nc_u32_e32 v11, 0x3f0, v10                           // 000000D3C440: 4A1614FF 000003F0
	v_mul_u32_u24_e32 v62, 0x110, v9                           // 000000D3C448: 167C12FF 00000110
	v_dual_mov_b32 v30, v26 :: v_dual_and_b32 v61, 15, v0      // 000000D3C450: CA24011A 1E3C008F
	.long 0xd44c0003                                           // 000000D3C458: D44C0003
	v_cndmask_b32_e32 v1, 16, v59, vcc_lo                      // 000000D3C45C: 02027690
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000D3C460: BF870244
	v_lshrrev_b32_e32 v9, 5, v11                               // 000000D3C464: 32121685
	v_dual_mov_b32 v28, v26 :: v_dual_and_b32 v5, 0x7e0, v11   // 000000D3C468: CA24011A 1C0416FF 000007E0
	v_mov_b32_e32 v27, v26                                     // 000000D3C474: 7E36031A
	v_mov_b32_e32 v29, v26                                     // 000000D3C478: 7E3A031A
	v_subrev_nc_u32_e32 v9, 32, v9                             // 000000D3C47C: 4E1212A0
	v_mov_b32_e32 v31, v26                                     // 000000D3C480: 7E3E031A
	v_mov_b32_e32 v32, v26                                     // 000000D3C484: 7E40031A
	v_mov_b32_e32 v17, v26                                     // 000000D3C488: 7E22031A
	s_delay_alu instid0(VALU_DEP_4)                            // 000000D3C48C: BF870004
	v_dual_mov_b32 v18, v26 :: v_dual_cndmask_b32 v25, 31, v9  // 000000D3C490: CA12011A 1218129F
	v_lshlrev_b32_e32 v9, 2, v0                                // 000000D3C498: 30120082
	v_sub_nc_u32_e32 v10, v5, v10                              // 000000D3C49C: 4C141505
	v_mov_b32_e32 v19, v26                                     // 000000D3C4A0: 7E26031A
	v_mov_b32_e32 v20, v26                                     // 000000D3C4A4: 7E28031A
	v_cmp_gt_i32_e32 vcc_lo, 31, v25                           // 000000D3C4A8: 7C88329F
	v_and_or_b32 v9, 0x380, v9, s13                            // 000000D3C4AC: D6570009 003612FF 00000380
	v_dual_mov_b32 v10, s4 :: v_dual_add_nc_u32 v67, 0xfffffc30, v10// 000000D3C4B8: CA200004 0A4214FF FFFFFC30
	v_mul_u32_u24_e32 v63, 0x110, v61                          // 000000D3C4C4: 167E7AFF 00000110
	v_cndmask_b32_e64 v6, 0xffffffe1, 1, vcc_lo                // 000000D3C4CC: D5010006 01A902FF FFFFFFE1
	.long 0xd7006a41                                           // 000000D3C4D8: D7006A41
	v_cndmask_b32_e32 v1, 0x100, v7, vcc_lo                    // 000000D3C4DC: 02020EFF 00000100
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000D3C4E4: BF8700B1
	v_add_co_ci_u32_e64 v66, null, 0, v8, vcc_lo               // 000000D3C4E8: D5207C42 01AA1080
	.long 0xd73c0007                                           // 000000D3C4F0: D73C0007
	v_cndmask_b32_e32 v1, 2, v25, vcc_lo                       // 000000D3C4F4: 02023282
	.long 0xd7006a44                                           // 000000D3C4F8: D7006A44
	v_cndmask_b32_e32 v1, 0x100, v12, vcc_lo                   // 000000D3C4FC: 020218FF 00000100
	v_add_co_ci_u32_e64 v69, null, 0, v13, vcc_lo              // 000000D3C504: D5207C45 01AA1A80
	v_add_nc_u32_e32 v5, v6, v25                               // 000000D3C50C: 4A0A3306
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D3C510: BF870094
	.long 0xd7006a07                                           // 000000D3C514: D7006A07
	v_cndmask_b32_e32 v1, v9, v7, vcc_lo                       // 000000D3C518: 02020F09
	v_add_co_ci_u32_e64 v8, null, v10, v8, vcc_lo              // 000000D3C51C: D5207C08 01AA110A
	.long 0xd7006a03                                           // 000000D3C524: D7006A03
	v_cndmask_b32_e32 v1, s10, v3, vcc_lo                      // 000000D3C528: 0202060A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D3C52C: BF870211
	v_add_co_ci_u32_e64 v4, null, s11, v4, vcc_lo              // 000000D3C530: D5207C04 01AA080B
	.long 0xd7006a46                                           // 000000D3C538: D7006A46
	v_cndmask_b32_e32 v1, s8, v7, vcc_lo                       // 000000D3C53C: 02020E08
	v_ashrrev_i32_e32 v6, 31, v5                               // 000000D3C540: 340C0A9F
	v_add_co_ci_u32_e64 v71, null, s9, v8, vcc_lo              // 000000D3C544: D5207C47 01AA1009
	.long 0xd7006a48                                           // 000000D3C54C: D7006A48
	v_cndmask_b32_e32 v1, 0x100, v3, vcc_lo                    // 000000D3C550: 020206FF 00000100
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D3C558: BF8700A1
	v_add_co_ci_u32_e64 v73, null, 0, v4, vcc_lo               // 000000D3C55C: D5207C49 01AA0880
	.long 0xd7006a03                                           // 000000D3C564: D7006A03
	v_cndmask_b32_e32 v1, s10, v1, vcc_lo                      // 000000D3C568: 0202020A
	v_add_co_ci_u32_e64 v4, null, s11, v2, vcc_lo              // 000000D3C56C: D5207C04 01AA040B
	.long 0xd73c0001                                           // 000000D3C574: D73C0001
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 000000D3C578: 02020A82
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D3C57C: BF870093
	.long 0xd7006a4a                                           // 000000D3C580: D7006A4A
	v_cndmask_b32_e32 v1, 0x100, v3, vcc_lo                    // 000000D3C584: 020206FF 00000100
	v_add_co_ci_u32_e64 v75, null, 0, v4, vcc_lo               // 000000D3C58C: D5207C4B 01AA0880
	v_lshl_or_b32 v3, v59, 2, v9                               // 000000D3C594: D6560003 0425053B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D3C59C: BF870094
	.long 0xd7006a01                                           // 000000D3C5A0: D7006A01
	v_cndmask_b32_e32 v1, v9, v1, vcc_lo                       // 000000D3C5A4: 02020309
	v_add_co_ci_u32_e64 v2, null, v10, v2, vcc_lo              // 000000D3C5A8: D5207C02 01AA050A
	v_mov_b32_e32 v4, s4                                       // 000000D3C5B0: 7E080204
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D3C5B4: BF870093
	.long 0xd7006a4c                                           // 000000D3C5B8: D7006A4C
	v_cndmask_b32_e32 v1, s8, v1, vcc_lo                       // 000000D3C5BC: 02020208
	v_add_co_ci_u32_e64 v77, null, s9, v2, vcc_lo              // 000000D3C5C0: D5207C4D 01AA0409
	.long 0xd7006a4e                                           // 000000D3C5C8: D7006A4E
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 000000D3C5CC: 02020608
	v_dual_mov_b32 v25, v26 :: v_dual_lshlrev_b32 v64, 4, v61  // 000000D3C5D0: CA22011A 19407A84
	v_add_co_ci_u32_e64 v79, null, s9, v4, vcc_lo              // 000000D3C5D8: D5207C4F 01AA0809
	v_mov_b32_e32 v21, v26                                     // 000000D3C5E0: 7E2A031A
	v_mov_b32_e32 v22, v26                                     // 000000D3C5E4: 7E2C031A
	v_mov_b32_e32 v23, v26                                     // 000000D3C5E8: 7E2E031A
	v_mov_b32_e32 v24, v26                                     // 000000D3C5EC: 7E30031A
	v_mov_b32_e32 v9, v26                                      // 000000D3C5F0: 7E12031A
	v_mov_b32_e32 v10, v26                                     // 000000D3C5F4: 7E14031A
	v_mov_b32_e32 v11, v26                                     // 000000D3C5F8: 7E16031A
	v_mov_b32_e32 v12, v26                                     // 000000D3C5FC: 7E18031A
	v_mov_b32_e32 v13, v26                                     // 000000D3C600: 7E1A031A
	v_mov_b32_e32 v14, v26                                     // 000000D3C604: 7E1C031A
	v_mov_b32_e32 v15, v26                                     // 000000D3C608: 7E1E031A
	v_mov_b32_e32 v16, v26                                     // 000000D3C60C: 7E20031A
	v_mov_b32_e32 v1, v26                                      // 000000D3C610: 7E02031A
	v_mov_b32_e32 v2, v26                                      // 000000D3C614: 7E04031A
	v_mov_b32_e32 v3, v26                                      // 000000D3C618: 7E06031A
	v_mov_b32_e32 v4, v26                                      // 000000D3C61C: 7E08031A
	v_mov_b32_e32 v5, v26                                      // 000000D3C620: 7E0A031A
	v_mov_b32_e32 v6, v26                                      // 000000D3C624: 7E0C031A
	v_mov_b32_e32 v7, v26                                      // 000000D3C628: 7E0E031A
	v_mov_b32_e32 v8, v26                                      // 000000D3C62C: 7E10031A
	s_mov_b32 s12, 0                                           // 000000D3C630: BE8C0080
	s_mov_b64 s[4:5], 0                                        // 000000D3C634: BE840180
	s_mov_b32 s13, 0xdcd12d                                    // 000000D3C638: BE8D00FF 00DCD12D
	s_movk_i32 s21, 0x83                                       // 000000D3C640: B0150083
	s_movk_i32 s22, 0x1eee                                     // 000000D3C644: B0161EEE
	s_mov_b32 s23, 0x76543210                                  // 000000D3C648: BE9700FF 76543210
	s_movk_i32 s24, 0x60                                       // 000000D3C650: B0180060
	s_movk_i32 s25, 0x80                                       // 000000D3C654: B0190080
	s_movk_i32 s26, 0xa0                                       // 000000D3C658: B01A00A0
	s_movk_i32 s27, 0xc0                                       // 000000D3C65C: B01B00C0
	s_movk_i32 s28, 0xe0                                       // 000000D3C660: B01C00E0
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000D3C664: BF890007
	s_barrier                                                  // 000000D3C668: BFBD0000
	buffer_gl0_inv                                             // 000000D3C66C: E0AC0000 00000000
	s_branch 33                                                // 000000D3C674: BFA00021 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x4fc>
	s_or_b32 exec_lo, exec_lo, s29                             // 000000D3C678: 8C7E1D7E
	.long 0xd7006a41                                           // 000000D3C67C: D7006A41
	v_cndmask_b32_e32 v1, 0x100, v65, vcc_lo                   // 000000D3C680: 020282FF 00000100
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D3C688: BF8700A1
	v_add_co_ci_u32_e64 v66, null, 0, v66, vcc_lo              // 000000D3C68C: D5207C42 01AA8480
	.long 0xd7006a44                                           // 000000D3C694: D7006A44
	v_cndmask_b32_e32 v1, 0x100, v68, vcc_lo                   // 000000D3C698: 020288FF 00000100
	v_add_co_ci_u32_e64 v69, null, 0, v69, vcc_lo              // 000000D3C6A0: D5207C45 01AA8A80
	.long 0xd7006a48                                           // 000000D3C6A8: D7006A48
	v_cndmask_b32_e32 v1, 0x100, v72, vcc_lo                   // 000000D3C6AC: 020290FF 00000100
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D3C6B4: BF8700A1
	v_add_co_ci_u32_e64 v73, null, 0, v73, vcc_lo              // 000000D3C6B8: D5207C49 01AA9280
	.long 0xd7006a4a                                           // 000000D3C6C0: D7006A4A
	v_cndmask_b32_e32 v1, 0x100, v74, vcc_lo                   // 000000D3C6C4: 020294FF 00000100
	v_add_co_ci_u32_e64 v75, null, 0, v75, vcc_lo              // 000000D3C6CC: D5207C4B 01AA9680
	s_add_u32 s4, s4, 0x2000                                   // 000000D3C6D4: 8004FF04 00002000
	s_addc_u32 s5, s5, 0                                       // 000000D3C6DC: 82058005
	s_add_i32 s12, s12, 1                                      // 000000D3C6E0: 810C810C
	s_cmpk_eq_u32 s4, 0xa000                                   // 000000D3C6E4: B484A000
	s_waitcnt lgkmcnt(0)                                       // 000000D3C6E8: BF89FC07
	s_barrier                                                  // 000000D3C6EC: BFBD0000
	buffer_gl0_inv                                             // 000000D3C6F0: E0AC0000 00000000
	s_cbranch_scc1 1597                                        // 000000D3C6F8: BFA2063D <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x1df0>
	s_cmpk_lg_u32 s4, 0x8000                                   // 000000D3C6FC: B5048000
	s_cselect_b32 s29, -1, 0                                   // 000000D3C700: 981D80C1
	s_cmpk_eq_u32 s4, 0x8000                                   // 000000D3C704: B4848000
	s_cbranch_scc1 26                                          // 000000D3C708: BFA2001A <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x574>
	.long 0xd7006a21                                           // 000000D3C70C: D7006A21
	v_cndmask_b32_e32 v1, v74, v64, vcc_lo                     // 000000D3C710: 0202814A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D3C714: BF8700A1
	v_add_co_ci_u32_e64 v34, null, 0, v75, vcc_lo              // 000000D3C718: D5207C22 01AA9680
	.long 0xd7006a25                                           // 000000D3C720: D7006A25
	v_cndmask_b32_e32 v1, v72, v64, vcc_lo                     // 000000D3C724: 02028148
	v_add_co_ci_u32_e64 v38, null, 0, v73, vcc_lo              // 000000D3C728: D5207C26 01AA9280
	.long 0xd7006a29                                           // 000000D3C730: D7006A29
	v_cndmask_b32_e32 v1, v68, v64, vcc_lo                     // 000000D3C734: 02028144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D3C738: BF8700A1
	v_add_co_ci_u32_e64 v42, null, 0, v69, vcc_lo              // 000000D3C73C: D5207C2A 01AA8A80
	.long 0xd7006a2d                                           // 000000D3C744: D7006A2D
	v_cndmask_b32_e32 v1, v65, v64, vcc_lo                     // 000000D3C748: 02028141
	v_add_co_ci_u32_e64 v46, null, 0, v66, vcc_lo              // 000000D3C74C: D5207C2E 01AA8480
	global_load_b128 v[33:36], v[33:34], off                   // 000000D3C754: DC5E0000 217C0021
	global_load_b128 v[37:40], v[37:38], off                   // 000000D3C75C: DC5E0000 257C0025
	global_load_b128 v[41:44], v[41:42], off                   // 000000D3C764: DC5E0000 297C0029
	global_load_b128 v[45:48], v[45:46], off                   // 000000D3C76C: DC5E0000 2D7C002D
	.long 0xd7006a33                                           // 000000D3C774: D7006A33
	v_cndmask_b32_e32 v0, v70, v4, vcc_lo                      // 000000D3C778: 02000946
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D3C77C: BF8700A1
	v_add_co_ci_u32_e64 v52, null, s5, v71, vcc_lo             // 000000D3C780: D5207C34 01AA8E05
	.long 0xd7006a31                                           // 000000D3C788: D7006A31
	v_cndmask_b32_e32 v0, v76, v4, vcc_lo                      // 000000D3C78C: 0200094C
	v_add_co_ci_u32_e64 v50, null, s5, v77, vcc_lo             // 000000D3C790: D5207C32 01AA9A05
	.long 0xd7006a35                                           // 000000D3C798: D7006A35
	v_cndmask_b32_e32 v0, v78, v4, vcc_lo                      // 000000D3C79C: 0200094E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D3C7A0: BF870001
	v_add_co_ci_u32_e64 v54, null, s5, v79, vcc_lo             // 000000D3C7A4: D5207C36 01AA9E05
	global_load_b32 v56, v[51:52], off                         // 000000D3C7AC: DC520000 387C0033
	s_bfe_i32 s31, s12, 0x10000                                // 000000D3C7B4: 939FFF0C 00010000
	s_and_b32 s30, s12, 1                                      // 000000D3C7BC: 8B1E810C
	s_clause 0x1                                               // 000000D3C7C0: BF850001
	global_load_b32 v80, v[53:54], off                         // 000000D3C7C4: DC520000 507C0035
	global_load_b32 v55, v[49:50], off                         // 000000D3C7CC: DC520000 377C0031
	s_and_b32 s31, s31, 0x4400                                 // 000000D3C7D4: 8B1FFF1F 00004400
	s_cmp_eq_u32 s30, 0                                        // 000000D3C7DC: BF06801E
	s_cselect_b32 s30, -1, 0                                   // 000000D3C7E0: 981E80C1
	s_waitcnt vmcnt(1)                                         // 000000D3C7E4: BF8907F7
	v_bfe_u32 v81, v80, 12, 16                                 // 000000D3C7E8: D6100051 02411950
	s_waitcnt vmcnt(0)                                         // 000000D3C7F0: BF8903F7
	.long 0xd73d0037                                           // 000000D3C7F4: D73D0037
	v_cndmask_b32_e32 v1, v67, v55, vcc_lo                     // 000000D3C7F8: 02026F43
	v_bfe_u32 v83, v80, 8, 16                                  // 000000D3C7FC: D6100053 02411150
	v_bfe_u32 v85, v80, 4, 16                                  // 000000D3C804: D6100055 02410950
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000D3C80C: BF8700B3
	v_bfe_u32 v56, v55, 12, 16                                 // 000000D3C810: D6100038 02411937
	v_mul_u32_u24_e32 v86, s13, v56                            // 000000D3C818: 16AC700D
	v_mul_u32_u24_e32 v56, s21, v56                            // 000000D3C81C: 16707015
	v_lshl_add_u32 v56, v56, 24, v86                           // 000000D3C820: D6460038 05593138
	v_bfe_u32 v82, v55, 8, 16                                  // 000000D3C828: D6100052 02411137
	v_mul_u32_u24_e32 v86, s13, v82                            // 000000D3C830: 16ACA40D
	v_mul_u32_u24_e32 v82, s21, v82                            // 000000D3C834: 16A4A415
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000D3C838: BF870241
	v_lshl_add_u32 v82, v82, 24, v86                           // 000000D3C83C: D6460052 05593152
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000D3C844: D6220038 03FD0138 00006400
	v_bfe_u32 v84, v55, 4, 16                                  // 000000D3C850: D6100054 02410937
	v_and_b32_e32 v55, 0xffff, v55                             // 000000D3C858: 366E6EFF 0000FFFF
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000D3C860: D6220052 03FD0152 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D3C86C: BF870094
	v_and_b32_e32 v56, 0xffff, v56                             // 000000D3C870: 367070FF 0000FFFF
	v_lshl_or_b32 v56, v82, 16, v56                            // 000000D3C878: D6560038 04E12152
	v_mul_u32_u24_e32 v82, s13, v84                            // 000000D3C880: 16A4A80D
	v_mul_u32_u24_e32 v84, s21, v84                            // 000000D3C884: 16A8A815
	v_lshl_add_u32 v82, v84, 24, v82                           // 000000D3C888: D6460052 05493154
	v_mul_u32_u24_e32 v84, s13, v55                            // 000000D3C890: 16A86E0D
	v_mul_u32_u24_e32 v55, s21, v55                            // 000000D3C894: 166E6E15
	v_lshl_add_u32 v55, v55, 24, v84                           // 000000D3C898: D6460037 05513137
	v_pk_fma_f16 v56, v56, s22, 0xc931 op_sel_hi:[1,0,0]       // 000000D3C8A0: CC0E0038 0BFC2D38 0000C931
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000D3C8AC: D6220052 03FD0152 00006400
	v_and_b32_e32 v80, 0xffff, v80                             // 000000D3C8B8: 36A0A0FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D3C8C0: BF870194
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000D3C8C4: D6220037 03FD0137 00006400
	v_and_b32_e32 v82, 0xffff, v82                             // 000000D3C8D0: 36A4A4FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D3C8D8: BF870001
	v_lshl_or_b32 v55, v55, 16, v82                            // 000000D3C8DC: D6560037 05492137
	v_mul_u32_u24_e32 v82, s13, v81                            // 000000D3C8E4: 16A4A20D
	v_mul_u32_u24_e32 v81, s21, v81                            // 000000D3C8E8: 16A2A215
	v_lshl_add_u32 v81, v81, 24, v82                           // 000000D3C8EC: D6460051 05493151
	v_mul_u32_u24_e32 v82, s13, v83                            // 000000D3C8F4: 16A4A60D
	v_mul_u32_u24_e32 v83, s21, v83                            // 000000D3C8F8: 16A6A615
	v_lshl_add_u32 v82, v83, 24, v82                           // 000000D3C8FC: D6460052 05493153
	v_pk_fma_f16 v55, v55, s22, 0xc931 op_sel_hi:[1,0,0]       // 000000D3C904: CC0E0037 0BFC2D37 0000C931
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000D3C910: D6220051 03FD0151 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D3C91C: BF870113
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000D3C920: D6220052 03FD0152 00006400
	v_and_b32_e32 v81, 0xffff, v81                             // 000000D3C92C: 36A2A2FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D3C934: BF8700A1
	v_lshl_or_b32 v81, v82, 16, v81                            // 000000D3C938: D6560051 05452152
	v_mul_u32_u24_e32 v82, s21, v85                            // 000000D3C940: 16A4AA15
	v_pk_fma_f16 v83, v81, s22, 0xc931 op_sel_hi:[1,0,0]       // 000000D3C944: CC0E0053 0BFC2D51 0000C931
	v_mul_u32_u24_e32 v81, s13, v85                            // 000000D3C950: 16A2AA0D
	v_lshl_add_u32 v81, v82, 24, v81                           // 000000D3C954: D6460051 05453152
	v_mul_u32_u24_e32 v82, s13, v80                            // 000000D3C95C: 16A4A00D
	v_mul_u32_u24_e32 v80, s21, v80                            // 000000D3C960: 16A0A015
	v_lshl_add_u32 v80, v80, 24, v82                           // 000000D3C964: D6460050 05493150
	v_mov_b32_e32 v82, v55                                     // 000000D3C96C: 7EA40337
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000D3C970: D6220051 03FD0151 00006400
	v_mov_b32_e32 v86, v83                                     // 000000D3C97C: 7EAC0353
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D3C980: BF870214
	v_sad_u8 v80, v80, 0, 0x6400                               // 000000D3C984: D6220050 03FD0150 00006400
	v_permlanex16_b32 v82, v82, s23, 0xfedcba98                // 000000D3C990: D65C0052 03FC2F52 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D3C99C: BF870214
	v_and_b32_e32 v81, 0xffff, v81                             // 000000D3C9A0: 36A2A2FF 0000FFFF
	v_permlanex16_b32 v86, v86, s23, 0xfedcba98                // 000000D3C9A8: D65C0056 03FC2F56 FEDCBA98
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D3C9B4: BF870193
	v_cndmask_b32_e64 v85, v55, v82, s3                        // 000000D3C9B8: D5010055 000EA537
	v_lshl_or_b32 v80, v80, 16, v81                            // 000000D3C9C0: D6560050 05452150
	v_mov_b32_e32 v81, v56                                     // 000000D3C9C8: 7EA20338
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D3C9CC: BF870112
	v_pk_fma_f16 v87, v80, s22, 0xc931 op_sel_hi:[1,0,0]       // 000000D3C9D0: CC0E0057 0BFC2D50 0000C931
	v_permlanex16_b32 v81, v81, s23, 0xfedcba98                // 000000D3C9DC: D65C0051 03FC2F51 FEDCBA98
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D3C9E8: BF870112
	v_mov_b32_e32 v88, v87                                     // 000000D3C9EC: 7EB00357
	v_cndmask_b32_e64 v80, v81, v56, s3                        // 000000D3C9F0: D5010050 000E7151
	v_cndmask_b32_e64 v84, v56, v81, s3                        // 000000D3C9F8: D5010054 000EA338
	v_cndmask_b32_e64 v81, v82, v55, s3                        // 000000D3CA00: D5010051 000E6F52
	v_add_nc_u32_e32 v55, s31, v63                             // 000000D3CA08: 4A6E7E1F
	v_permlanex16_b32 v88, v88, s23, 0xfedcba98                // 000000D3CA0C: D65C0058 03FC2F58 FEDCBA98
	v_cndmask_b32_e64 v82, v86, v83, s3                        // 000000D3CA18: D5010052 000EA756
	v_cndmask_b32_e64 v86, v83, v86, s3                        // 000000D3CA20: D5010056 000EAD53
	s_and_b32 s31, s30, exec_lo                                // 000000D3CA28: 8B1F7E1E
	s_cselect_b32 s31, 32, 0x4420                              // 000000D3CA2C: 981FFFA0 00004420
	v_cndmask_b32_e64 v83, v88, v87, s3                        // 000000D3CA34: D5010053 000EAF58
	v_cndmask_b32_e64 v87, v87, v88, s3                        // 000000D3CA3C: D5010057 000EB157
	ds_load_b128 v[88:91], v55                                 // 000000D3CA44: DBFC0000 58000037
	ds_load_b128 v[92:95], v55 offset:16                       // 000000D3CA4C: DBFC0010 5C000037
	s_waitcnt lgkmcnt(0)                                       // 000000D3CA54: BF89FC07
	v_wmma_f32_16x16x16_f16 v[25:32], v[80:87], v[88:95], v[25:32]// 000000D3CA58: CC404019 1C66B150
	ds_load_b128 v[88:91], v55 offset:4352                     // 000000D3CA60: DBFC1100 58000037
	ds_load_b128 v[92:95], v55 offset:4368                     // 000000D3CA68: DBFC1110 5C000037
	s_waitcnt lgkmcnt(0)                                       // 000000D3CA70: BF89FC07
	v_wmma_f32_16x16x16_f16 v[17:24], v[80:87], v[88:95], v[17:24]// 000000D3CA74: CC404011 1C46B150
	ds_load_b128 v[88:91], v55 offset:8704                     // 000000D3CA7C: DBFC2200 58000037
	ds_load_b128 v[92:95], v55 offset:8720                     // 000000D3CA84: DBFC2210 5C000037
	s_waitcnt lgkmcnt(0)                                       // 000000D3CA8C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[9:16], v[80:87], v[88:95], v[9:16]// 000000D3CA90: CC404009 1C26B150
	ds_load_b128 v[88:91], v55 offset:13056                    // 000000D3CA98: DBFC3300 58000037
	ds_load_b128 v[92:95], v55 offset:13072                    // 000000D3CAA0: DBFC3310 5C000037
	s_waitcnt lgkmcnt(0)                                       // 000000D3CAA8: BF89FC07
	v_wmma_f32_16x16x16_f16 v[1:8], v[80:87], v[88:95], v[1:8] // 000000D3CAAC: CC404001 1C06B150
	s_clause 0x2                                               // 000000D3CAB4: BF850002
	global_load_b32 v56, v[51:52], off offset:1024             // 000000D3CAB8: DC520400 387C0033
	global_load_b32 v55, v[49:50], off offset:1024             // 000000D3CAC0: DC520400 377C0031
	global_load_b32 v80, v[53:54], off offset:1024             // 000000D3CAC8: DC520400 507C0035
	s_waitcnt vmcnt(1)                                         // 000000D3CAD0: BF8907F7
	.long 0xd73d0037                                           // 000000D3CAD4: D73D0037
	v_cndmask_b32_e32 v1, v67, v55, vcc_lo                     // 000000D3CAD8: 02026F43
	s_waitcnt vmcnt(0)                                         // 000000D3CADC: BF8903F7
	v_bfe_u32 v81, v80, 12, 16                                 // 000000D3CAE0: D6100051 02411950
	v_bfe_u32 v83, v80, 8, 16                                  // 000000D3CAE8: D6100053 02411150
	v_bfe_u32 v85, v80, 4, 16                                  // 000000D3CAF0: D6100055 02410950
	v_and_b32_e32 v80, 0xffff, v80                             // 000000D3CAF8: 36A0A0FF 0000FFFF
	v_bfe_u32 v56, v55, 12, 16                                 // 000000D3CB00: D6100038 02411937
	v_mul_u32_u24_e32 v86, s13, v56                            // 000000D3CB08: 16AC700D
	v_mul_u32_u24_e32 v56, s21, v56                            // 000000D3CB0C: 16707015
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000D3CB10: BF8700C1
	v_lshl_add_u32 v56, v56, 24, v86                           // 000000D3CB14: D6460038 05593138
	v_bfe_u32 v82, v55, 8, 16                                  // 000000D3CB1C: D6100052 02411137
	v_mul_u32_u24_e32 v86, s13, v82                            // 000000D3CB24: 16ACA40D
	v_mul_u32_u24_e32 v82, s21, v82                            // 000000D3CB28: 16A4A415
	v_lshl_add_u32 v82, v82, 24, v86                           // 000000D3CB2C: D6460052 05593152
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000D3CB34: D6220038 03FD0138 00006400
	v_bfe_u32 v84, v55, 4, 16                                  // 000000D3CB40: D6100054 02410937
	v_and_b32_e32 v55, 0xffff, v55                             // 000000D3CB48: 366E6EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D3CB50: BF870214
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000D3CB54: D6220052 03FD0152 00006400
	v_and_b32_e32 v56, 0xffff, v56                             // 000000D3CB60: 367070FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D3CB68: BF870001
	v_lshl_or_b32 v56, v82, 16, v56                            // 000000D3CB6C: D6560038 04E12152
	v_mul_u32_u24_e32 v82, s13, v84                            // 000000D3CB74: 16A4A80D
	v_mul_u32_u24_e32 v84, s21, v84                            // 000000D3CB78: 16A8A815
	v_lshl_add_u32 v82, v84, 24, v82                           // 000000D3CB7C: D6460052 05493154
	v_mul_u32_u24_e32 v84, s13, v55                            // 000000D3CB84: 16A86E0D
	v_mul_u32_u24_e32 v55, s21, v55                            // 000000D3CB88: 166E6E15
	v_lshl_add_u32 v55, v55, 24, v84                           // 000000D3CB8C: D6460037 05513137
	v_pk_fma_f16 v56, v56, s22, 0xc931 op_sel_hi:[1,0,0]       // 000000D3CB94: CC0E0038 0BFC2D38 0000C931
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000D3CBA0: D6220052 03FD0152 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D3CBAC: BF870113
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000D3CBB0: D6220037 03FD0137 00006400
	v_and_b32_e32 v82, 0xffff, v82                             // 000000D3CBBC: 36A4A4FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D3CBC4: BF870001
	v_lshl_or_b32 v55, v55, 16, v82                            // 000000D3CBC8: D6560037 05492137
	v_mul_u32_u24_e32 v82, s13, v81                            // 000000D3CBD0: 16A4A20D
	v_mul_u32_u24_e32 v81, s21, v81                            // 000000D3CBD4: 16A2A215
	v_lshl_add_u32 v81, v81, 24, v82                           // 000000D3CBD8: D6460051 05493151
	v_mul_u32_u24_e32 v82, s13, v83                            // 000000D3CBE0: 16A4A60D
	v_mul_u32_u24_e32 v83, s21, v83                            // 000000D3CBE4: 16A6A615
	v_lshl_add_u32 v82, v83, 24, v82                           // 000000D3CBE8: D6460052 05493153
	v_pk_fma_f16 v55, v55, s22, 0xc931 op_sel_hi:[1,0,0]       // 000000D3CBF0: CC0E0037 0BFC2D37 0000C931
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000D3CBFC: D6220051 03FD0151 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D3CC08: BF870113
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000D3CC0C: D6220052 03FD0152 00006400
	v_and_b32_e32 v81, 0xffff, v81                             // 000000D3CC18: 36A2A2FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D3CC20: BF8700A1
	v_lshl_or_b32 v81, v82, 16, v81                            // 000000D3CC24: D6560051 05452152
	v_mul_u32_u24_e32 v82, s21, v85                            // 000000D3CC2C: 16A4AA15
	v_pk_fma_f16 v83, v81, s22, 0xc931 op_sel_hi:[1,0,0]       // 000000D3CC30: CC0E0053 0BFC2D51 0000C931
	v_mul_u32_u24_e32 v81, s13, v85                            // 000000D3CC3C: 16A2AA0D
	v_lshl_add_u32 v81, v82, 24, v81                           // 000000D3CC40: D6460051 05453152
	v_mul_u32_u24_e32 v82, s13, v80                            // 000000D3CC48: 16A4A00D
	v_mul_u32_u24_e32 v80, s21, v80                            // 000000D3CC4C: 16A0A015
	v_lshl_add_u32 v80, v80, 24, v82                           // 000000D3CC50: D6460050 05493150
	v_mov_b32_e32 v82, v55                                     // 000000D3CC58: 7EA40337
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000D3CC5C: D6220051 03FD0151 00006400
	v_mov_b32_e32 v86, v83                                     // 000000D3CC68: 7EAC0353
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D3CC6C: BF870214
	v_sad_u8 v80, v80, 0, 0x6400                               // 000000D3CC70: D6220050 03FD0150 00006400
	v_permlanex16_b32 v82, v82, s23, 0xfedcba98                // 000000D3CC7C: D65C0052 03FC2F52 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D3CC88: BF870214
	v_and_b32_e32 v81, 0xffff, v81                             // 000000D3CC8C: 36A2A2FF 0000FFFF
	v_permlanex16_b32 v86, v86, s23, 0xfedcba98                // 000000D3CC94: D65C0056 03FC2F56 FEDCBA98
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D3CCA0: BF870193
	v_cndmask_b32_e64 v85, v55, v82, s3                        // 000000D3CCA4: D5010055 000EA537
	v_lshl_or_b32 v80, v80, 16, v81                            // 000000D3CCAC: D6560050 05452150
	v_mov_b32_e32 v81, v56                                     // 000000D3CCB4: 7EA20338
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D3CCB8: BF870112
	v_pk_fma_f16 v87, v80, s22, 0xc931 op_sel_hi:[1,0,0]       // 000000D3CCBC: CC0E0057 0BFC2D50 0000C931
	v_permlanex16_b32 v81, v81, s23, 0xfedcba98                // 000000D3CCC8: D65C0051 03FC2F51 FEDCBA98
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D3CCD4: BF870112
	v_mov_b32_e32 v88, v87                                     // 000000D3CCD8: 7EB00357
	v_cndmask_b32_e64 v80, v81, v56, s3                        // 000000D3CCDC: D5010050 000E7151
	v_cndmask_b32_e64 v84, v56, v81, s3                        // 000000D3CCE4: D5010054 000EA338
	v_cndmask_b32_e64 v81, v82, v55, s3                        // 000000D3CCEC: D5010051 000E6F52
	v_add_nc_u32_e32 v55, s31, v63                             // 000000D3CCF4: 4A6E7E1F
	v_permlanex16_b32 v88, v88, s23, 0xfedcba98                // 000000D3CCF8: D65C0058 03FC2F58 FEDCBA98
	v_cndmask_b32_e64 v82, v86, v83, s3                        // 000000D3CD04: D5010052 000EA756
	v_cndmask_b32_e64 v86, v83, v86, s3                        // 000000D3CD0C: D5010056 000EAD53
	s_cselect_b32 s31, 64, 0x4440                              // 000000D3CD14: 981FFFC0 00004440
	s_delay_alu instid0(VALU_DEP_3)                            // 000000D3CD1C: BF870003
	v_cndmask_b32_e64 v83, v88, v87, s3                        // 000000D3CD20: D5010053 000EAF58
	v_cndmask_b32_e64 v87, v87, v88, s3                        // 000000D3CD28: D5010057 000EB157
	ds_load_b128 v[88:91], v55                                 // 000000D3CD30: DBFC0000 58000037
	ds_load_b128 v[92:95], v55 offset:16                       // 000000D3CD38: DBFC0010 5C000037
	s_waitcnt lgkmcnt(0)                                       // 000000D3CD40: BF89FC07
	v_wmma_f32_16x16x16_f16 v[25:32], v[80:87], v[88:95], v[25:32]// 000000D3CD44: CC404019 1C66B150
	ds_load_b128 v[88:91], v55 offset:4352                     // 000000D3CD4C: DBFC1100 58000037
	ds_load_b128 v[92:95], v55 offset:4368                     // 000000D3CD54: DBFC1110 5C000037
	s_waitcnt lgkmcnt(0)                                       // 000000D3CD5C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[17:24], v[80:87], v[88:95], v[17:24]// 000000D3CD60: CC404011 1C46B150
	ds_load_b128 v[88:91], v55 offset:8704                     // 000000D3CD68: DBFC2200 58000037
	ds_load_b128 v[92:95], v55 offset:8720                     // 000000D3CD70: DBFC2210 5C000037
	s_waitcnt lgkmcnt(0)                                       // 000000D3CD78: BF89FC07
	v_wmma_f32_16x16x16_f16 v[9:16], v[80:87], v[88:95], v[9:16]// 000000D3CD7C: CC404009 1C26B150
	ds_load_b128 v[88:91], v55 offset:13056                    // 000000D3CD84: DBFC3300 58000037
	ds_load_b128 v[92:95], v55 offset:13072                    // 000000D3CD8C: DBFC3310 5C000037
	s_waitcnt lgkmcnt(0)                                       // 000000D3CD94: BF89FC07
	v_wmma_f32_16x16x16_f16 v[1:8], v[80:87], v[88:95], v[1:8] // 000000D3CD98: CC404001 1C06B150
	s_clause 0x2                                               // 000000D3CDA0: BF850002
	global_load_b32 v56, v[51:52], off offset:2048             // 000000D3CDA4: DC520800 387C0033
	global_load_b32 v55, v[49:50], off offset:2048             // 000000D3CDAC: DC520800 377C0031
	global_load_b32 v80, v[53:54], off offset:2048             // 000000D3CDB4: DC520800 507C0035
	s_waitcnt vmcnt(1)                                         // 000000D3CDBC: BF8907F7
	.long 0xd73d0037                                           // 000000D3CDC0: D73D0037
	v_cndmask_b32_e32 v1, v67, v55, vcc_lo                     // 000000D3CDC4: 02026F43
	s_waitcnt vmcnt(0)                                         // 000000D3CDC8: BF8903F7
	v_bfe_u32 v81, v80, 12, 16                                 // 000000D3CDCC: D6100051 02411950
	v_bfe_u32 v83, v80, 8, 16                                  // 000000D3CDD4: D6100053 02411150
	v_bfe_u32 v85, v80, 4, 16                                  // 000000D3CDDC: D6100055 02410950
	v_and_b32_e32 v80, 0xffff, v80                             // 000000D3CDE4: 36A0A0FF 0000FFFF
	v_bfe_u32 v56, v55, 12, 16                                 // 000000D3CDEC: D6100038 02411937
	v_mul_u32_u24_e32 v86, s13, v56                            // 000000D3CDF4: 16AC700D
	v_mul_u32_u24_e32 v56, s21, v56                            // 000000D3CDF8: 16707015
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000D3CDFC: BF8700C1
	v_lshl_add_u32 v56, v56, 24, v86                           // 000000D3CE00: D6460038 05593138
	v_bfe_u32 v82, v55, 8, 16                                  // 000000D3CE08: D6100052 02411137
	v_mul_u32_u24_e32 v86, s13, v82                            // 000000D3CE10: 16ACA40D
	v_mul_u32_u24_e32 v82, s21, v82                            // 000000D3CE14: 16A4A415
	v_lshl_add_u32 v82, v82, 24, v86                           // 000000D3CE18: D6460052 05593152
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000D3CE20: D6220038 03FD0138 00006400
	v_bfe_u32 v84, v55, 4, 16                                  // 000000D3CE2C: D6100054 02410937
	v_and_b32_e32 v55, 0xffff, v55                             // 000000D3CE34: 366E6EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D3CE3C: BF870214
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000D3CE40: D6220052 03FD0152 00006400
	v_and_b32_e32 v56, 0xffff, v56                             // 000000D3CE4C: 367070FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D3CE54: BF870001
	v_lshl_or_b32 v56, v82, 16, v56                            // 000000D3CE58: D6560038 04E12152
	v_mul_u32_u24_e32 v82, s13, v84                            // 000000D3CE60: 16A4A80D
	v_mul_u32_u24_e32 v84, s21, v84                            // 000000D3CE64: 16A8A815
	v_lshl_add_u32 v82, v84, 24, v82                           // 000000D3CE68: D6460052 05493154
	v_mul_u32_u24_e32 v84, s13, v55                            // 000000D3CE70: 16A86E0D
	v_mul_u32_u24_e32 v55, s21, v55                            // 000000D3CE74: 166E6E15
	v_lshl_add_u32 v55, v55, 24, v84                           // 000000D3CE78: D6460037 05513137
	v_pk_fma_f16 v56, v56, s22, 0xc931 op_sel_hi:[1,0,0]       // 000000D3CE80: CC0E0038 0BFC2D38 0000C931
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000D3CE8C: D6220052 03FD0152 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D3CE98: BF870113
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000D3CE9C: D6220037 03FD0137 00006400
	v_and_b32_e32 v82, 0xffff, v82                             // 000000D3CEA8: 36A4A4FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D3CEB0: BF870001
	v_lshl_or_b32 v55, v55, 16, v82                            // 000000D3CEB4: D6560037 05492137
	v_mul_u32_u24_e32 v82, s13, v81                            // 000000D3CEBC: 16A4A20D
	v_mul_u32_u24_e32 v81, s21, v81                            // 000000D3CEC0: 16A2A215
	v_lshl_add_u32 v81, v81, 24, v82                           // 000000D3CEC4: D6460051 05493151
	v_mul_u32_u24_e32 v82, s13, v83                            // 000000D3CECC: 16A4A60D
	v_mul_u32_u24_e32 v83, s21, v83                            // 000000D3CED0: 16A6A615
	v_lshl_add_u32 v82, v83, 24, v82                           // 000000D3CED4: D6460052 05493153
	v_pk_fma_f16 v55, v55, s22, 0xc931 op_sel_hi:[1,0,0]       // 000000D3CEDC: CC0E0037 0BFC2D37 0000C931
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000D3CEE8: D6220051 03FD0151 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D3CEF4: BF870113
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000D3CEF8: D6220052 03FD0152 00006400
	v_and_b32_e32 v81, 0xffff, v81                             // 000000D3CF04: 36A2A2FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D3CF0C: BF8700A1
	v_lshl_or_b32 v81, v82, 16, v81                            // 000000D3CF10: D6560051 05452152
	v_mul_u32_u24_e32 v82, s21, v85                            // 000000D3CF18: 16A4AA15
	v_pk_fma_f16 v83, v81, s22, 0xc931 op_sel_hi:[1,0,0]       // 000000D3CF1C: CC0E0053 0BFC2D51 0000C931
	v_mul_u32_u24_e32 v81, s13, v85                            // 000000D3CF28: 16A2AA0D
	v_lshl_add_u32 v81, v82, 24, v81                           // 000000D3CF2C: D6460051 05453152
	v_mul_u32_u24_e32 v82, s13, v80                            // 000000D3CF34: 16A4A00D
	v_mul_u32_u24_e32 v80, s21, v80                            // 000000D3CF38: 16A0A015
	v_lshl_add_u32 v80, v80, 24, v82                           // 000000D3CF3C: D6460050 05493150
	v_mov_b32_e32 v82, v55                                     // 000000D3CF44: 7EA40337
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000D3CF48: D6220051 03FD0151 00006400
	v_mov_b32_e32 v86, v83                                     // 000000D3CF54: 7EAC0353
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D3CF58: BF870214
	v_sad_u8 v80, v80, 0, 0x6400                               // 000000D3CF5C: D6220050 03FD0150 00006400
	v_permlanex16_b32 v82, v82, s23, 0xfedcba98                // 000000D3CF68: D65C0052 03FC2F52 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D3CF74: BF870214
	v_and_b32_e32 v81, 0xffff, v81                             // 000000D3CF78: 36A2A2FF 0000FFFF
	v_permlanex16_b32 v86, v86, s23, 0xfedcba98                // 000000D3CF80: D65C0056 03FC2F56 FEDCBA98
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D3CF8C: BF870193
	v_cndmask_b32_e64 v85, v55, v82, s3                        // 000000D3CF90: D5010055 000EA537
	v_lshl_or_b32 v80, v80, 16, v81                            // 000000D3CF98: D6560050 05452150
	v_mov_b32_e32 v81, v56                                     // 000000D3CFA0: 7EA20338
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D3CFA4: BF870112
	v_pk_fma_f16 v87, v80, s22, 0xc931 op_sel_hi:[1,0,0]       // 000000D3CFA8: CC0E0057 0BFC2D50 0000C931
	v_permlanex16_b32 v81, v81, s23, 0xfedcba98                // 000000D3CFB4: D65C0051 03FC2F51 FEDCBA98
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D3CFC0: BF870112
	v_mov_b32_e32 v88, v87                                     // 000000D3CFC4: 7EB00357
	v_cndmask_b32_e64 v80, v81, v56, s3                        // 000000D3CFC8: D5010050 000E7151
	v_cndmask_b32_e64 v84, v56, v81, s3                        // 000000D3CFD0: D5010054 000EA338
	v_cndmask_b32_e64 v81, v82, v55, s3                        // 000000D3CFD8: D5010051 000E6F52
	v_add_nc_u32_e32 v55, s31, v63                             // 000000D3CFE0: 4A6E7E1F
	v_permlanex16_b32 v88, v88, s23, 0xfedcba98                // 000000D3CFE4: D65C0058 03FC2F58 FEDCBA98
	v_cndmask_b32_e64 v82, v86, v83, s3                        // 000000D3CFF0: D5010052 000EA756
	v_cndmask_b32_e64 v86, v83, v86, s3                        // 000000D3CFF8: D5010056 000EAD53
	s_cselect_b32 s31, s24, 0x4460                             // 000000D3D000: 981FFF18 00004460
	s_delay_alu instid0(VALU_DEP_3)                            // 000000D3D008: BF870003
	v_cndmask_b32_e64 v83, v88, v87, s3                        // 000000D3D00C: D5010053 000EAF58
	v_cndmask_b32_e64 v87, v87, v88, s3                        // 000000D3D014: D5010057 000EB157
	ds_load_b128 v[88:91], v55                                 // 000000D3D01C: DBFC0000 58000037
	ds_load_b128 v[92:95], v55 offset:16                       // 000000D3D024: DBFC0010 5C000037
	s_waitcnt lgkmcnt(0)                                       // 000000D3D02C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[25:32], v[80:87], v[88:95], v[25:32]// 000000D3D030: CC404019 1C66B150
	ds_load_b128 v[88:91], v55 offset:4352                     // 000000D3D038: DBFC1100 58000037
	ds_load_b128 v[92:95], v55 offset:4368                     // 000000D3D040: DBFC1110 5C000037
	s_waitcnt lgkmcnt(0)                                       // 000000D3D048: BF89FC07
	v_wmma_f32_16x16x16_f16 v[17:24], v[80:87], v[88:95], v[17:24]// 000000D3D04C: CC404011 1C46B150
	ds_load_b128 v[88:91], v55 offset:8704                     // 000000D3D054: DBFC2200 58000037
	ds_load_b128 v[92:95], v55 offset:8720                     // 000000D3D05C: DBFC2210 5C000037
	s_waitcnt lgkmcnt(0)                                       // 000000D3D064: BF89FC07
	v_wmma_f32_16x16x16_f16 v[9:16], v[80:87], v[88:95], v[9:16]// 000000D3D068: CC404009 1C26B150
	ds_load_b128 v[88:91], v55 offset:13056                    // 000000D3D070: DBFC3300 58000037
	ds_load_b128 v[92:95], v55 offset:13072                    // 000000D3D078: DBFC3310 5C000037
	s_waitcnt lgkmcnt(0)                                       // 000000D3D080: BF89FC07
	v_wmma_f32_16x16x16_f16 v[1:8], v[80:87], v[88:95], v[1:8] // 000000D3D084: CC404001 1C06B150
	s_clause 0x2                                               // 000000D3D08C: BF850002
	global_load_b32 v56, v[51:52], off offset:3072             // 000000D3D090: DC520C00 387C0033
	global_load_b32 v55, v[49:50], off offset:3072             // 000000D3D098: DC520C00 377C0031
	global_load_b32 v80, v[53:54], off offset:3072             // 000000D3D0A0: DC520C00 507C0035
	s_waitcnt vmcnt(1)                                         // 000000D3D0A8: BF8907F7
	.long 0xd73d0037                                           // 000000D3D0AC: D73D0037
	v_cndmask_b32_e32 v1, v67, v55, vcc_lo                     // 000000D3D0B0: 02026F43
	s_waitcnt vmcnt(0)                                         // 000000D3D0B4: BF8903F7
	v_bfe_u32 v81, v80, 12, 16                                 // 000000D3D0B8: D6100051 02411950
	v_bfe_u32 v83, v80, 8, 16                                  // 000000D3D0C0: D6100053 02411150
	v_bfe_u32 v85, v80, 4, 16                                  // 000000D3D0C8: D6100055 02410950
	v_and_b32_e32 v80, 0xffff, v80                             // 000000D3D0D0: 36A0A0FF 0000FFFF
	v_bfe_u32 v56, v55, 12, 16                                 // 000000D3D0D8: D6100038 02411937
	v_mul_u32_u24_e32 v86, s13, v56                            // 000000D3D0E0: 16AC700D
	v_mul_u32_u24_e32 v56, s21, v56                            // 000000D3D0E4: 16707015
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000D3D0E8: BF8700C1
	v_lshl_add_u32 v56, v56, 24, v86                           // 000000D3D0EC: D6460038 05593138
	v_bfe_u32 v82, v55, 8, 16                                  // 000000D3D0F4: D6100052 02411137
	v_mul_u32_u24_e32 v86, s13, v82                            // 000000D3D0FC: 16ACA40D
	v_mul_u32_u24_e32 v82, s21, v82                            // 000000D3D100: 16A4A415
	v_lshl_add_u32 v82, v82, 24, v86                           // 000000D3D104: D6460052 05593152
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000D3D10C: D6220038 03FD0138 00006400
	v_bfe_u32 v84, v55, 4, 16                                  // 000000D3D118: D6100054 02410937
	v_and_b32_e32 v55, 0xffff, v55                             // 000000D3D120: 366E6EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D3D128: BF870214
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000D3D12C: D6220052 03FD0152 00006400
	v_and_b32_e32 v56, 0xffff, v56                             // 000000D3D138: 367070FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D3D140: BF870001
	v_lshl_or_b32 v56, v82, 16, v56                            // 000000D3D144: D6560038 04E12152
	v_mul_u32_u24_e32 v82, s13, v84                            // 000000D3D14C: 16A4A80D
	v_mul_u32_u24_e32 v84, s21, v84                            // 000000D3D150: 16A8A815
	v_lshl_add_u32 v82, v84, 24, v82                           // 000000D3D154: D6460052 05493154
	v_mul_u32_u24_e32 v84, s13, v55                            // 000000D3D15C: 16A86E0D
	v_mul_u32_u24_e32 v55, s21, v55                            // 000000D3D160: 166E6E15
	v_lshl_add_u32 v55, v55, 24, v84                           // 000000D3D164: D6460037 05513137
	v_pk_fma_f16 v56, v56, s22, 0xc931 op_sel_hi:[1,0,0]       // 000000D3D16C: CC0E0038 0BFC2D38 0000C931
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000D3D178: D6220052 03FD0152 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D3D184: BF870113
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000D3D188: D6220037 03FD0137 00006400
	v_and_b32_e32 v82, 0xffff, v82                             // 000000D3D194: 36A4A4FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D3D19C: BF870001
	v_lshl_or_b32 v55, v55, 16, v82                            // 000000D3D1A0: D6560037 05492137
	v_mul_u32_u24_e32 v82, s13, v81                            // 000000D3D1A8: 16A4A20D
	v_mul_u32_u24_e32 v81, s21, v81                            // 000000D3D1AC: 16A2A215
	v_lshl_add_u32 v81, v81, 24, v82                           // 000000D3D1B0: D6460051 05493151
	v_mul_u32_u24_e32 v82, s13, v83                            // 000000D3D1B8: 16A4A60D
	v_mul_u32_u24_e32 v83, s21, v83                            // 000000D3D1BC: 16A6A615
	v_lshl_add_u32 v82, v83, 24, v82                           // 000000D3D1C0: D6460052 05493153
	v_pk_fma_f16 v55, v55, s22, 0xc931 op_sel_hi:[1,0,0]       // 000000D3D1C8: CC0E0037 0BFC2D37 0000C931
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000D3D1D4: D6220051 03FD0151 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D3D1E0: BF870113
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000D3D1E4: D6220052 03FD0152 00006400
	v_and_b32_e32 v81, 0xffff, v81                             // 000000D3D1F0: 36A2A2FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D3D1F8: BF8700A1
	v_lshl_or_b32 v81, v82, 16, v81                            // 000000D3D1FC: D6560051 05452152
	v_mul_u32_u24_e32 v82, s21, v85                            // 000000D3D204: 16A4AA15
	v_pk_fma_f16 v83, v81, s22, 0xc931 op_sel_hi:[1,0,0]       // 000000D3D208: CC0E0053 0BFC2D51 0000C931
	v_mul_u32_u24_e32 v81, s13, v85                            // 000000D3D214: 16A2AA0D
	v_lshl_add_u32 v81, v82, 24, v81                           // 000000D3D218: D6460051 05453152
	v_mul_u32_u24_e32 v82, s13, v80                            // 000000D3D220: 16A4A00D
	v_mul_u32_u24_e32 v80, s21, v80                            // 000000D3D224: 16A0A015
	v_lshl_add_u32 v80, v80, 24, v82                           // 000000D3D228: D6460050 05493150
	v_mov_b32_e32 v82, v55                                     // 000000D3D230: 7EA40337
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000D3D234: D6220051 03FD0151 00006400
	v_mov_b32_e32 v86, v83                                     // 000000D3D240: 7EAC0353
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D3D244: BF870214
	v_sad_u8 v80, v80, 0, 0x6400                               // 000000D3D248: D6220050 03FD0150 00006400
	v_permlanex16_b32 v82, v82, s23, 0xfedcba98                // 000000D3D254: D65C0052 03FC2F52 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D3D260: BF870214
	v_and_b32_e32 v81, 0xffff, v81                             // 000000D3D264: 36A2A2FF 0000FFFF
	v_permlanex16_b32 v86, v86, s23, 0xfedcba98                // 000000D3D26C: D65C0056 03FC2F56 FEDCBA98
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D3D278: BF870193
	v_cndmask_b32_e64 v85, v55, v82, s3                        // 000000D3D27C: D5010055 000EA537
	v_lshl_or_b32 v80, v80, 16, v81                            // 000000D3D284: D6560050 05452150
	v_mov_b32_e32 v81, v56                                     // 000000D3D28C: 7EA20338
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D3D290: BF870112
	v_pk_fma_f16 v87, v80, s22, 0xc931 op_sel_hi:[1,0,0]       // 000000D3D294: CC0E0057 0BFC2D50 0000C931
	v_permlanex16_b32 v81, v81, s23, 0xfedcba98                // 000000D3D2A0: D65C0051 03FC2F51 FEDCBA98
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D3D2AC: BF870112
	v_mov_b32_e32 v88, v87                                     // 000000D3D2B0: 7EB00357
	v_cndmask_b32_e64 v80, v81, v56, s3                        // 000000D3D2B4: D5010050 000E7151
	v_cndmask_b32_e64 v84, v56, v81, s3                        // 000000D3D2BC: D5010054 000EA338
	v_cndmask_b32_e64 v81, v82, v55, s3                        // 000000D3D2C4: D5010051 000E6F52
	v_add_nc_u32_e32 v55, s31, v63                             // 000000D3D2CC: 4A6E7E1F
	v_permlanex16_b32 v88, v88, s23, 0xfedcba98                // 000000D3D2D0: D65C0058 03FC2F58 FEDCBA98
	v_cndmask_b32_e64 v82, v86, v83, s3                        // 000000D3D2DC: D5010052 000EA756
	v_cndmask_b32_e64 v86, v83, v86, s3                        // 000000D3D2E4: D5010056 000EAD53
	s_cselect_b32 s31, s25, 0x4480                             // 000000D3D2EC: 981FFF19 00004480
	s_delay_alu instid0(VALU_DEP_3)                            // 000000D3D2F4: BF870003
	v_cndmask_b32_e64 v83, v88, v87, s3                        // 000000D3D2F8: D5010053 000EAF58
	v_cndmask_b32_e64 v87, v87, v88, s3                        // 000000D3D300: D5010057 000EB157
	ds_load_b128 v[88:91], v55                                 // 000000D3D308: DBFC0000 58000037
	ds_load_b128 v[92:95], v55 offset:16                       // 000000D3D310: DBFC0010 5C000037
	s_waitcnt lgkmcnt(0)                                       // 000000D3D318: BF89FC07
	v_wmma_f32_16x16x16_f16 v[25:32], v[80:87], v[88:95], v[25:32]// 000000D3D31C: CC404019 1C66B150
	ds_load_b128 v[88:91], v55 offset:4352                     // 000000D3D324: DBFC1100 58000037
	ds_load_b128 v[92:95], v55 offset:4368                     // 000000D3D32C: DBFC1110 5C000037
	s_waitcnt lgkmcnt(0)                                       // 000000D3D334: BF89FC07
	v_wmma_f32_16x16x16_f16 v[17:24], v[80:87], v[88:95], v[17:24]// 000000D3D338: CC404011 1C46B150
	ds_load_b128 v[88:91], v55 offset:8704                     // 000000D3D340: DBFC2200 58000037
	ds_load_b128 v[92:95], v55 offset:8720                     // 000000D3D348: DBFC2210 5C000037
	s_waitcnt lgkmcnt(0)                                       // 000000D3D350: BF89FC07
	v_wmma_f32_16x16x16_f16 v[9:16], v[80:87], v[88:95], v[9:16]// 000000D3D354: CC404009 1C26B150
	ds_load_b128 v[88:91], v55 offset:13056                    // 000000D3D35C: DBFC3300 58000037
	ds_load_b128 v[92:95], v55 offset:13072                    // 000000D3D364: DBFC3310 5C000037
	.long 0xd7006a37                                           // 000000D3D36C: D7006A37
	v_cndmask_b32_e32 v1, 0x1000, v51, vcc_lo                  // 000000D3D370: 020266FF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D3D378: BF8700A1
	v_add_co_ci_u32_e64 v56, null, 0, v52, vcc_lo              // 000000D3D37C: D5207C38 01AA6880
	.long 0xd7006a31                                           // 000000D3D384: D7006A31
	v_cndmask_b32_e32 v1, 0x1000, v49, vcc_lo                  // 000000D3D388: 020262FF 00001000
	v_add_co_ci_u32_e64 v50, null, 0, v50, vcc_lo              // 000000D3D390: D5207C32 01AA6480
	.long 0xd7006a33                                           // 000000D3D398: D7006A33
	v_cndmask_b32_e32 v1, 0x1000, v53, vcc_lo                  // 000000D3D39C: 02026AFF 00001000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D3D3A4: BF870001
	v_add_co_ci_u32_e64 v52, null, 0, v54, vcc_lo              // 000000D3D3A8: D5207C34 01AA6C80
	s_waitcnt lgkmcnt(0)                                       // 000000D3D3B0: BF89FC07
	v_wmma_f32_16x16x16_f16 v[1:8], v[80:87], v[88:95], v[1:8] // 000000D3D3B4: CC404001 1C06B150
	s_clause 0x2                                               // 000000D3D3BC: BF850002
	global_load_b32 v81, v[55:56], off                         // 000000D3D3C0: DC520000 517C0037
	global_load_b32 v80, v[49:50], off                         // 000000D3D3C8: DC520000 507C0031
	global_load_b32 v82, v[51:52], off                         // 000000D3D3D0: DC520000 527C0033
	s_waitcnt vmcnt(1)                                         // 000000D3D3D8: BF8907F7
	.long 0xd73d0035                                           // 000000D3D3DC: D73D0035
	v_cndmask_b32_e32 v1, v67, v80, vcc_lo                     // 000000D3D3E0: 0202A143
	s_waitcnt vmcnt(0)                                         // 000000D3D3E4: BF8903F7
	v_bfe_u32 v80, v82, 12, 16                                 // 000000D3D3E8: D6100050 02411952
	v_bfe_u32 v83, v82, 8, 16                                  // 000000D3D3F0: D6100053 02411152
	v_bfe_u32 v85, v82, 4, 16                                  // 000000D3D3F8: D6100055 02410952
	v_and_b32_e32 v82, 0xffff, v82                             // 000000D3D400: 36A4A4FF 0000FFFF
	v_bfe_u32 v54, v53, 12, 16                                 // 000000D3D408: D6100036 02411935
	v_mul_u32_u24_e32 v86, s13, v54                            // 000000D3D410: 16AC6C0D
	v_mul_u32_u24_e32 v54, s21, v54                            // 000000D3D414: 166C6C15
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000D3D418: BF8700C1
	v_lshl_add_u32 v54, v54, 24, v86                           // 000000D3D41C: D6460036 05593136
	v_bfe_u32 v81, v53, 8, 16                                  // 000000D3D424: D6100051 02411135
	v_mul_u32_u24_e32 v86, s13, v81                            // 000000D3D42C: 16ACA20D
	v_mul_u32_u24_e32 v81, s21, v81                            // 000000D3D430: 16A2A215
	v_lshl_add_u32 v81, v81, 24, v86                           // 000000D3D434: D6460051 05593151
	v_sad_u8 v54, v54, 0, 0x6400                               // 000000D3D43C: D6220036 03FD0136 00006400
	v_bfe_u32 v84, v53, 4, 16                                  // 000000D3D448: D6100054 02410935
	v_and_b32_e32 v53, 0xffff, v53                             // 000000D3D450: 366A6AFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D3D458: BF870214
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000D3D45C: D6220051 03FD0151 00006400
	v_and_b32_e32 v54, 0xffff, v54                             // 000000D3D468: 366C6CFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D3D470: BF870001
	v_lshl_or_b32 v54, v81, 16, v54                            // 000000D3D474: D6560036 04D92151
	v_mul_u32_u24_e32 v81, s13, v84                            // 000000D3D47C: 16A2A80D
	v_mul_u32_u24_e32 v84, s21, v84                            // 000000D3D480: 16A8A815
	v_lshl_add_u32 v81, v84, 24, v81                           // 000000D3D484: D6460051 05453154
	v_mul_u32_u24_e32 v84, s13, v53                            // 000000D3D48C: 16A86A0D
	v_mul_u32_u24_e32 v53, s21, v53                            // 000000D3D490: 166A6A15
	v_lshl_add_u32 v53, v53, 24, v84                           // 000000D3D494: D6460035 05513135
	v_pk_fma_f16 v54, v54, s22, 0xc931 op_sel_hi:[1,0,0]       // 000000D3D49C: CC0E0036 0BFC2D36 0000C931
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000D3D4A8: D6220051 03FD0151 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D3D4B4: BF870113
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000D3D4B8: D6220035 03FD0135 00006400
	v_and_b32_e32 v81, 0xffff, v81                             // 000000D3D4C4: 36A2A2FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D3D4CC: BF870001
	v_lshl_or_b32 v53, v53, 16, v81                            // 000000D3D4D0: D6560035 05452135
	v_mul_u32_u24_e32 v81, s13, v80                            // 000000D3D4D8: 16A2A00D
	v_mul_u32_u24_e32 v80, s21, v80                            // 000000D3D4DC: 16A0A015
	v_lshl_add_u32 v80, v80, 24, v81                           // 000000D3D4E0: D6460050 05453150
	v_mul_u32_u24_e32 v81, s13, v83                            // 000000D3D4E8: 16A2A60D
	v_mul_u32_u24_e32 v83, s21, v83                            // 000000D3D4EC: 16A6A615
	v_lshl_add_u32 v81, v83, 24, v81                           // 000000D3D4F0: D6460051 05453153
	v_pk_fma_f16 v53, v53, s22, 0xc931 op_sel_hi:[1,0,0]       // 000000D3D4F8: CC0E0035 0BFC2D35 0000C931
	v_sad_u8 v80, v80, 0, 0x6400                               // 000000D3D504: D6220050 03FD0150 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D3D510: BF870113
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000D3D514: D6220051 03FD0151 00006400
	v_and_b32_e32 v80, 0xffff, v80                             // 000000D3D520: 36A0A0FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D3D528: BF8700A1
	v_lshl_or_b32 v80, v81, 16, v80                            // 000000D3D52C: D6560050 05412151
	v_mul_u32_u24_e32 v81, s21, v85                            // 000000D3D534: 16A2AA15
	v_pk_fma_f16 v83, v80, s22, 0xc931 op_sel_hi:[1,0,0]       // 000000D3D538: CC0E0053 0BFC2D50 0000C931
	v_mul_u32_u24_e32 v80, s13, v85                            // 000000D3D544: 16A0AA0D
	v_lshl_add_u32 v80, v81, 24, v80                           // 000000D3D548: D6460050 05413151
	v_mul_u32_u24_e32 v81, s13, v82                            // 000000D3D550: 16A2A40D
	v_mul_u32_u24_e32 v82, s21, v82                            // 000000D3D554: 16A4A415
	v_lshl_add_u32 v81, v82, 24, v81                           // 000000D3D558: D6460051 05453152
	v_mov_b32_e32 v82, v53                                     // 000000D3D560: 7EA40335
	v_sad_u8 v80, v80, 0, 0x6400                               // 000000D3D564: D6220050 03FD0150 00006400
	v_mov_b32_e32 v86, v83                                     // 000000D3D570: 7EAC0353
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D3D574: BF870214
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000D3D578: D6220051 03FD0151 00006400
	v_permlanex16_b32 v82, v82, s23, 0xfedcba98                // 000000D3D584: D65C0052 03FC2F52 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D3D590: BF870214
	v_and_b32_e32 v80, 0xffff, v80                             // 000000D3D594: 36A0A0FF 0000FFFF
	v_permlanex16_b32 v86, v86, s23, 0xfedcba98                // 000000D3D59C: D65C0056 03FC2F56 FEDCBA98
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D3D5A8: BF870193
	v_cndmask_b32_e64 v85, v53, v82, s3                        // 000000D3D5AC: D5010055 000EA535
	v_lshl_or_b32 v80, v81, 16, v80                            // 000000D3D5B4: D6560050 05412151
	v_mov_b32_e32 v81, v54                                     // 000000D3D5BC: 7EA20336
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D3D5C0: BF870112
	v_pk_fma_f16 v87, v80, s22, 0xc931 op_sel_hi:[1,0,0]       // 000000D3D5C4: CC0E0057 0BFC2D50 0000C931
	v_permlanex16_b32 v81, v81, s23, 0xfedcba98                // 000000D3D5D0: D65C0051 03FC2F51 FEDCBA98
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D3D5DC: BF870112
	v_mov_b32_e32 v88, v87                                     // 000000D3D5E0: 7EB00357
	v_cndmask_b32_e64 v80, v81, v54, s3                        // 000000D3D5E4: D5010050 000E6D51
	v_cndmask_b32_e64 v84, v54, v81, s3                        // 000000D3D5EC: D5010054 000EA336
	v_cndmask_b32_e64 v81, v82, v53, s3                        // 000000D3D5F4: D5010051 000E6B52
	v_add_nc_u32_e32 v53, s31, v63                             // 000000D3D5FC: 4A6A7E1F
	v_permlanex16_b32 v88, v88, s23, 0xfedcba98                // 000000D3D600: D65C0058 03FC2F58 FEDCBA98
	v_cndmask_b32_e64 v82, v86, v83, s3                        // 000000D3D60C: D5010052 000EA756
	v_cndmask_b32_e64 v86, v83, v86, s3                        // 000000D3D614: D5010056 000EAD53
	s_cselect_b32 s31, s26, 0x44a0                             // 000000D3D61C: 981FFF1A 000044A0
	s_delay_alu instid0(VALU_DEP_3)                            // 000000D3D624: BF870003
	v_cndmask_b32_e64 v83, v88, v87, s3                        // 000000D3D628: D5010053 000EAF58
	v_cndmask_b32_e64 v87, v87, v88, s3                        // 000000D3D630: D5010057 000EB157
	ds_load_b128 v[88:91], v53                                 // 000000D3D638: DBFC0000 58000035
	ds_load_b128 v[92:95], v53 offset:16                       // 000000D3D640: DBFC0010 5C000035
	s_waitcnt lgkmcnt(0)                                       // 000000D3D648: BF89FC07
	v_wmma_f32_16x16x16_f16 v[25:32], v[80:87], v[88:95], v[25:32]// 000000D3D64C: CC404019 1C66B150
	ds_load_b128 v[88:91], v53 offset:4352                     // 000000D3D654: DBFC1100 58000035
	ds_load_b128 v[92:95], v53 offset:4368                     // 000000D3D65C: DBFC1110 5C000035
	s_waitcnt lgkmcnt(0)                                       // 000000D3D664: BF89FC07
	v_wmma_f32_16x16x16_f16 v[17:24], v[80:87], v[88:95], v[17:24]// 000000D3D668: CC404011 1C46B150
	ds_load_b128 v[88:91], v53 offset:8704                     // 000000D3D670: DBFC2200 58000035
	ds_load_b128 v[92:95], v53 offset:8720                     // 000000D3D678: DBFC2210 5C000035
	s_waitcnt lgkmcnt(0)                                       // 000000D3D680: BF89FC07
	v_wmma_f32_16x16x16_f16 v[9:16], v[80:87], v[88:95], v[9:16]// 000000D3D684: CC404009 1C26B150
	ds_load_b128 v[88:91], v53 offset:13056                    // 000000D3D68C: DBFC3300 58000035
	ds_load_b128 v[92:95], v53 offset:13072                    // 000000D3D694: DBFC3310 5C000035
	s_waitcnt lgkmcnt(0)                                       // 000000D3D69C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[1:8], v[80:87], v[88:95], v[1:8] // 000000D3D6A0: CC404001 1C06B150
	s_clause 0x2                                               // 000000D3D6A8: BF850002
	global_load_b32 v54, v[55:56], off offset:1024             // 000000D3D6AC: DC520400 367C0037
	global_load_b32 v53, v[49:50], off offset:1024             // 000000D3D6B4: DC520400 357C0031
	global_load_b32 v80, v[51:52], off offset:1024             // 000000D3D6BC: DC520400 507C0033
	s_waitcnt vmcnt(1)                                         // 000000D3D6C4: BF8907F7
	.long 0xd73d0035                                           // 000000D3D6C8: D73D0035
	v_cndmask_b32_e32 v1, v67, v53, vcc_lo                     // 000000D3D6CC: 02026B43
	s_waitcnt vmcnt(0)                                         // 000000D3D6D0: BF8903F7
	v_bfe_u32 v81, v80, 12, 16                                 // 000000D3D6D4: D6100051 02411950
	v_bfe_u32 v83, v80, 8, 16                                  // 000000D3D6DC: D6100053 02411150
	v_bfe_u32 v85, v80, 4, 16                                  // 000000D3D6E4: D6100055 02410950
	v_and_b32_e32 v80, 0xffff, v80                             // 000000D3D6EC: 36A0A0FF 0000FFFF
	v_bfe_u32 v54, v53, 12, 16                                 // 000000D3D6F4: D6100036 02411935
	v_mul_u32_u24_e32 v86, s13, v54                            // 000000D3D6FC: 16AC6C0D
	v_mul_u32_u24_e32 v54, s21, v54                            // 000000D3D700: 166C6C15
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000D3D704: BF8700C1
	v_lshl_add_u32 v54, v54, 24, v86                           // 000000D3D708: D6460036 05593136
	v_bfe_u32 v82, v53, 8, 16                                  // 000000D3D710: D6100052 02411135
	v_mul_u32_u24_e32 v86, s13, v82                            // 000000D3D718: 16ACA40D
	v_mul_u32_u24_e32 v82, s21, v82                            // 000000D3D71C: 16A4A415
	v_lshl_add_u32 v82, v82, 24, v86                           // 000000D3D720: D6460052 05593152
	v_sad_u8 v54, v54, 0, 0x6400                               // 000000D3D728: D6220036 03FD0136 00006400
	v_bfe_u32 v84, v53, 4, 16                                  // 000000D3D734: D6100054 02410935
	v_and_b32_e32 v53, 0xffff, v53                             // 000000D3D73C: 366A6AFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D3D744: BF870214
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000D3D748: D6220052 03FD0152 00006400
	v_and_b32_e32 v54, 0xffff, v54                             // 000000D3D754: 366C6CFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D3D75C: BF870001
	v_lshl_or_b32 v54, v82, 16, v54                            // 000000D3D760: D6560036 04D92152
	v_mul_u32_u24_e32 v82, s13, v84                            // 000000D3D768: 16A4A80D
	v_mul_u32_u24_e32 v84, s21, v84                            // 000000D3D76C: 16A8A815
	v_lshl_add_u32 v82, v84, 24, v82                           // 000000D3D770: D6460052 05493154
	v_mul_u32_u24_e32 v84, s13, v53                            // 000000D3D778: 16A86A0D
	v_mul_u32_u24_e32 v53, s21, v53                            // 000000D3D77C: 166A6A15
	v_lshl_add_u32 v53, v53, 24, v84                           // 000000D3D780: D6460035 05513135
	v_pk_fma_f16 v54, v54, s22, 0xc931 op_sel_hi:[1,0,0]       // 000000D3D788: CC0E0036 0BFC2D36 0000C931
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000D3D794: D6220052 03FD0152 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D3D7A0: BF870113
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000D3D7A4: D6220035 03FD0135 00006400
	v_and_b32_e32 v82, 0xffff, v82                             // 000000D3D7B0: 36A4A4FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D3D7B8: BF870001
	v_lshl_or_b32 v53, v53, 16, v82                            // 000000D3D7BC: D6560035 05492135
	v_mul_u32_u24_e32 v82, s13, v81                            // 000000D3D7C4: 16A4A20D
	v_mul_u32_u24_e32 v81, s21, v81                            // 000000D3D7C8: 16A2A215
	v_lshl_add_u32 v81, v81, 24, v82                           // 000000D3D7CC: D6460051 05493151
	v_mul_u32_u24_e32 v82, s13, v83                            // 000000D3D7D4: 16A4A60D
	v_mul_u32_u24_e32 v83, s21, v83                            // 000000D3D7D8: 16A6A615
	v_lshl_add_u32 v82, v83, 24, v82                           // 000000D3D7DC: D6460052 05493153
	v_pk_fma_f16 v53, v53, s22, 0xc931 op_sel_hi:[1,0,0]       // 000000D3D7E4: CC0E0035 0BFC2D35 0000C931
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000D3D7F0: D6220051 03FD0151 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D3D7FC: BF870113
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000D3D800: D6220052 03FD0152 00006400
	v_and_b32_e32 v81, 0xffff, v81                             // 000000D3D80C: 36A2A2FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D3D814: BF8700A1
	v_lshl_or_b32 v81, v82, 16, v81                            // 000000D3D818: D6560051 05452152
	v_mul_u32_u24_e32 v82, s21, v85                            // 000000D3D820: 16A4AA15
	v_pk_fma_f16 v83, v81, s22, 0xc931 op_sel_hi:[1,0,0]       // 000000D3D824: CC0E0053 0BFC2D51 0000C931
	v_mul_u32_u24_e32 v81, s13, v85                            // 000000D3D830: 16A2AA0D
	v_lshl_add_u32 v81, v82, 24, v81                           // 000000D3D834: D6460051 05453152
	v_mul_u32_u24_e32 v82, s13, v80                            // 000000D3D83C: 16A4A00D
	v_mul_u32_u24_e32 v80, s21, v80                            // 000000D3D840: 16A0A015
	v_lshl_add_u32 v80, v80, 24, v82                           // 000000D3D844: D6460050 05493150
	v_mov_b32_e32 v82, v53                                     // 000000D3D84C: 7EA40335
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000D3D850: D6220051 03FD0151 00006400
	v_mov_b32_e32 v86, v83                                     // 000000D3D85C: 7EAC0353
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D3D860: BF870214
	v_sad_u8 v80, v80, 0, 0x6400                               // 000000D3D864: D6220050 03FD0150 00006400
	v_permlanex16_b32 v82, v82, s23, 0xfedcba98                // 000000D3D870: D65C0052 03FC2F52 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D3D87C: BF870214
	v_and_b32_e32 v81, 0xffff, v81                             // 000000D3D880: 36A2A2FF 0000FFFF
	v_permlanex16_b32 v86, v86, s23, 0xfedcba98                // 000000D3D888: D65C0056 03FC2F56 FEDCBA98
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D3D894: BF870193
	v_cndmask_b32_e64 v85, v53, v82, s3                        // 000000D3D898: D5010055 000EA535
	v_lshl_or_b32 v80, v80, 16, v81                            // 000000D3D8A0: D6560050 05452150
	v_mov_b32_e32 v81, v54                                     // 000000D3D8A8: 7EA20336
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D3D8AC: BF870112
	v_pk_fma_f16 v87, v80, s22, 0xc931 op_sel_hi:[1,0,0]       // 000000D3D8B0: CC0E0057 0BFC2D50 0000C931
	v_permlanex16_b32 v81, v81, s23, 0xfedcba98                // 000000D3D8BC: D65C0051 03FC2F51 FEDCBA98
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D3D8C8: BF870112
	v_mov_b32_e32 v88, v87                                     // 000000D3D8CC: 7EB00357
	v_cndmask_b32_e64 v80, v81, v54, s3                        // 000000D3D8D0: D5010050 000E6D51
	v_cndmask_b32_e64 v84, v54, v81, s3                        // 000000D3D8D8: D5010054 000EA336
	v_cndmask_b32_e64 v81, v82, v53, s3                        // 000000D3D8E0: D5010051 000E6B52
	v_add_nc_u32_e32 v53, s31, v63                             // 000000D3D8E8: 4A6A7E1F
	v_permlanex16_b32 v88, v88, s23, 0xfedcba98                // 000000D3D8EC: D65C0058 03FC2F58 FEDCBA98
	v_cndmask_b32_e64 v82, v86, v83, s3                        // 000000D3D8F8: D5010052 000EA756
	v_cndmask_b32_e64 v86, v83, v86, s3                        // 000000D3D900: D5010056 000EAD53
	s_cselect_b32 s31, s27, 0x44c0                             // 000000D3D908: 981FFF1B 000044C0
	s_delay_alu instid0(VALU_DEP_3)                            // 000000D3D910: BF870003
	v_cndmask_b32_e64 v83, v88, v87, s3                        // 000000D3D914: D5010053 000EAF58
	v_cndmask_b32_e64 v87, v87, v88, s3                        // 000000D3D91C: D5010057 000EB157
	ds_load_b128 v[88:91], v53                                 // 000000D3D924: DBFC0000 58000035
	ds_load_b128 v[92:95], v53 offset:16                       // 000000D3D92C: DBFC0010 5C000035
	s_waitcnt lgkmcnt(0)                                       // 000000D3D934: BF89FC07
	v_wmma_f32_16x16x16_f16 v[25:32], v[80:87], v[88:95], v[25:32]// 000000D3D938: CC404019 1C66B150
	ds_load_b128 v[88:91], v53 offset:4352                     // 000000D3D940: DBFC1100 58000035
	ds_load_b128 v[92:95], v53 offset:4368                     // 000000D3D948: DBFC1110 5C000035
	s_waitcnt lgkmcnt(0)                                       // 000000D3D950: BF89FC07
	v_wmma_f32_16x16x16_f16 v[17:24], v[80:87], v[88:95], v[17:24]// 000000D3D954: CC404011 1C46B150
	ds_load_b128 v[88:91], v53 offset:8704                     // 000000D3D95C: DBFC2200 58000035
	ds_load_b128 v[92:95], v53 offset:8720                     // 000000D3D964: DBFC2210 5C000035
	s_waitcnt lgkmcnt(0)                                       // 000000D3D96C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[9:16], v[80:87], v[88:95], v[9:16]// 000000D3D970: CC404009 1C26B150
	ds_load_b128 v[88:91], v53 offset:13056                    // 000000D3D978: DBFC3300 58000035
	ds_load_b128 v[92:95], v53 offset:13072                    // 000000D3D980: DBFC3310 5C000035
	s_waitcnt lgkmcnt(0)                                       // 000000D3D988: BF89FC07
	v_wmma_f32_16x16x16_f16 v[1:8], v[80:87], v[88:95], v[1:8] // 000000D3D98C: CC404001 1C06B150
	s_clause 0x2                                               // 000000D3D994: BF850002
	global_load_b32 v54, v[55:56], off offset:2048             // 000000D3D998: DC520800 367C0037
	global_load_b32 v53, v[49:50], off offset:2048             // 000000D3D9A0: DC520800 357C0031
	global_load_b32 v80, v[51:52], off offset:2048             // 000000D3D9A8: DC520800 507C0033
	s_waitcnt vmcnt(1)                                         // 000000D3D9B0: BF8907F7
	.long 0xd73d0035                                           // 000000D3D9B4: D73D0035
	v_cndmask_b32_e32 v1, v67, v53, vcc_lo                     // 000000D3D9B8: 02026B43
	s_waitcnt vmcnt(0)                                         // 000000D3D9BC: BF8903F7
	v_bfe_u32 v81, v80, 12, 16                                 // 000000D3D9C0: D6100051 02411950
	v_bfe_u32 v83, v80, 8, 16                                  // 000000D3D9C8: D6100053 02411150
	v_bfe_u32 v85, v80, 4, 16                                  // 000000D3D9D0: D6100055 02410950
	v_and_b32_e32 v80, 0xffff, v80                             // 000000D3D9D8: 36A0A0FF 0000FFFF
	v_bfe_u32 v54, v53, 12, 16                                 // 000000D3D9E0: D6100036 02411935
	v_mul_u32_u24_e32 v86, s13, v54                            // 000000D3D9E8: 16AC6C0D
	v_mul_u32_u24_e32 v54, s21, v54                            // 000000D3D9EC: 166C6C15
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000D3D9F0: BF8700C1
	v_lshl_add_u32 v54, v54, 24, v86                           // 000000D3D9F4: D6460036 05593136
	v_bfe_u32 v82, v53, 8, 16                                  // 000000D3D9FC: D6100052 02411135
	v_mul_u32_u24_e32 v86, s13, v82                            // 000000D3DA04: 16ACA40D
	v_mul_u32_u24_e32 v82, s21, v82                            // 000000D3DA08: 16A4A415
	v_lshl_add_u32 v82, v82, 24, v86                           // 000000D3DA0C: D6460052 05593152
	v_sad_u8 v54, v54, 0, 0x6400                               // 000000D3DA14: D6220036 03FD0136 00006400
	v_bfe_u32 v84, v53, 4, 16                                  // 000000D3DA20: D6100054 02410935
	v_and_b32_e32 v53, 0xffff, v53                             // 000000D3DA28: 366A6AFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D3DA30: BF870214
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000D3DA34: D6220052 03FD0152 00006400
	v_and_b32_e32 v54, 0xffff, v54                             // 000000D3DA40: 366C6CFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D3DA48: BF870001
	v_lshl_or_b32 v54, v82, 16, v54                            // 000000D3DA4C: D6560036 04D92152
	v_mul_u32_u24_e32 v82, s13, v84                            // 000000D3DA54: 16A4A80D
	v_mul_u32_u24_e32 v84, s21, v84                            // 000000D3DA58: 16A8A815
	v_lshl_add_u32 v82, v84, 24, v82                           // 000000D3DA5C: D6460052 05493154
	v_mul_u32_u24_e32 v84, s13, v53                            // 000000D3DA64: 16A86A0D
	v_mul_u32_u24_e32 v53, s21, v53                            // 000000D3DA68: 166A6A15
	v_lshl_add_u32 v53, v53, 24, v84                           // 000000D3DA6C: D6460035 05513135
	v_pk_fma_f16 v54, v54, s22, 0xc931 op_sel_hi:[1,0,0]       // 000000D3DA74: CC0E0036 0BFC2D36 0000C931
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000D3DA80: D6220052 03FD0152 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D3DA8C: BF870113
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000D3DA90: D6220035 03FD0135 00006400
	v_and_b32_e32 v82, 0xffff, v82                             // 000000D3DA9C: 36A4A4FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D3DAA4: BF870001
	v_lshl_or_b32 v53, v53, 16, v82                            // 000000D3DAA8: D6560035 05492135
	v_mul_u32_u24_e32 v82, s13, v81                            // 000000D3DAB0: 16A4A20D
	v_mul_u32_u24_e32 v81, s21, v81                            // 000000D3DAB4: 16A2A215
	v_lshl_add_u32 v81, v81, 24, v82                           // 000000D3DAB8: D6460051 05493151
	v_mul_u32_u24_e32 v82, s13, v83                            // 000000D3DAC0: 16A4A60D
	v_mul_u32_u24_e32 v83, s21, v83                            // 000000D3DAC4: 16A6A615
	v_lshl_add_u32 v82, v83, 24, v82                           // 000000D3DAC8: D6460052 05493153
	v_pk_fma_f16 v53, v53, s22, 0xc931 op_sel_hi:[1,0,0]       // 000000D3DAD0: CC0E0035 0BFC2D35 0000C931
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000D3DADC: D6220051 03FD0151 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D3DAE8: BF870113
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000D3DAEC: D6220052 03FD0152 00006400
	v_and_b32_e32 v81, 0xffff, v81                             // 000000D3DAF8: 36A2A2FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D3DB00: BF8700A1
	v_lshl_or_b32 v81, v82, 16, v81                            // 000000D3DB04: D6560051 05452152
	v_mul_u32_u24_e32 v82, s21, v85                            // 000000D3DB0C: 16A4AA15
	v_pk_fma_f16 v83, v81, s22, 0xc931 op_sel_hi:[1,0,0]       // 000000D3DB10: CC0E0053 0BFC2D51 0000C931
	v_mul_u32_u24_e32 v81, s13, v85                            // 000000D3DB1C: 16A2AA0D
	v_lshl_add_u32 v81, v82, 24, v81                           // 000000D3DB20: D6460051 05453152
	v_mul_u32_u24_e32 v82, s13, v80                            // 000000D3DB28: 16A4A00D
	v_mul_u32_u24_e32 v80, s21, v80                            // 000000D3DB2C: 16A0A015
	v_lshl_add_u32 v80, v80, 24, v82                           // 000000D3DB30: D6460050 05493150
	v_mov_b32_e32 v82, v53                                     // 000000D3DB38: 7EA40335
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000D3DB3C: D6220051 03FD0151 00006400
	v_mov_b32_e32 v86, v83                                     // 000000D3DB48: 7EAC0353
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D3DB4C: BF870214
	v_sad_u8 v80, v80, 0, 0x6400                               // 000000D3DB50: D6220050 03FD0150 00006400
	v_permlanex16_b32 v82, v82, s23, 0xfedcba98                // 000000D3DB5C: D65C0052 03FC2F52 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D3DB68: BF870214
	v_and_b32_e32 v81, 0xffff, v81                             // 000000D3DB6C: 36A2A2FF 0000FFFF
	v_permlanex16_b32 v86, v86, s23, 0xfedcba98                // 000000D3DB74: D65C0056 03FC2F56 FEDCBA98
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D3DB80: BF870193
	v_cndmask_b32_e64 v85, v53, v82, s3                        // 000000D3DB84: D5010055 000EA535
	v_lshl_or_b32 v80, v80, 16, v81                            // 000000D3DB8C: D6560050 05452150
	v_mov_b32_e32 v81, v54                                     // 000000D3DB94: 7EA20336
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D3DB98: BF870112
	v_pk_fma_f16 v87, v80, s22, 0xc931 op_sel_hi:[1,0,0]       // 000000D3DB9C: CC0E0057 0BFC2D50 0000C931
	v_permlanex16_b32 v81, v81, s23, 0xfedcba98                // 000000D3DBA8: D65C0051 03FC2F51 FEDCBA98
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D3DBB4: BF870112
	v_mov_b32_e32 v88, v87                                     // 000000D3DBB8: 7EB00357
	v_cndmask_b32_e64 v80, v81, v54, s3                        // 000000D3DBBC: D5010050 000E6D51
	v_cndmask_b32_e64 v84, v54, v81, s3                        // 000000D3DBC4: D5010054 000EA336
	v_cndmask_b32_e64 v81, v82, v53, s3                        // 000000D3DBCC: D5010051 000E6B52
	v_add_nc_u32_e32 v53, s31, v63                             // 000000D3DBD4: 4A6A7E1F
	v_permlanex16_b32 v88, v88, s23, 0xfedcba98                // 000000D3DBD8: D65C0058 03FC2F58 FEDCBA98
	v_cndmask_b32_e64 v82, v86, v83, s3                        // 000000D3DBE4: D5010052 000EA756
	v_cndmask_b32_e64 v86, v83, v86, s3                        // 000000D3DBEC: D5010056 000EAD53
	s_and_b32 s31, s30, exec_lo                                // 000000D3DBF4: 8B1F7E1E
	s_cselect_b32 s31, s28, 0x44e0                             // 000000D3DBF8: 981FFF1C 000044E0
	v_cndmask_b32_e64 v83, v88, v87, s3                        // 000000D3DC00: D5010053 000EAF58
	v_cndmask_b32_e64 v87, v87, v88, s3                        // 000000D3DC08: D5010057 000EB157
	ds_load_b128 v[88:91], v53                                 // 000000D3DC10: DBFC0000 58000035
	ds_load_b128 v[92:95], v53 offset:16                       // 000000D3DC18: DBFC0010 5C000035
	s_and_not1_b32 vcc_lo, exec_lo, s29                        // 000000D3DC20: 916A1D7E
	s_waitcnt lgkmcnt(0)                                       // 000000D3DC24: BF89FC07
	v_wmma_f32_16x16x16_f16 v[25:32], v[80:87], v[88:95], v[25:32]// 000000D3DC28: CC404019 1C66B150
	ds_load_b128 v[88:91], v53 offset:4352                     // 000000D3DC30: DBFC1100 58000035
	ds_load_b128 v[92:95], v53 offset:4368                     // 000000D3DC38: DBFC1110 5C000035
	s_waitcnt lgkmcnt(0)                                       // 000000D3DC40: BF89FC07
	v_wmma_f32_16x16x16_f16 v[17:24], v[80:87], v[88:95], v[17:24]// 000000D3DC44: CC404011 1C46B150
	ds_load_b128 v[88:91], v53 offset:8704                     // 000000D3DC4C: DBFC2200 58000035
	ds_load_b128 v[92:95], v53 offset:8720                     // 000000D3DC54: DBFC2210 5C000035
	s_waitcnt lgkmcnt(0)                                       // 000000D3DC5C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[9:16], v[80:87], v[88:95], v[9:16]// 000000D3DC60: CC404009 1C26B150
	ds_load_b128 v[88:91], v53 offset:13056                    // 000000D3DC68: DBFC3300 58000035
	ds_load_b128 v[92:95], v53 offset:13072                    // 000000D3DC70: DBFC3310 5C000035
	s_clause 0x2                                               // 000000D3DC78: BF850002
	global_load_b32 v54, v[55:56], off offset:3072             // 000000D3DC7C: DC520C00 367C0037
	global_load_b32 v53, v[49:50], off offset:3072             // 000000D3DC84: DC520C00 357C0031
	global_load_b32 v49, v[51:52], off offset:3072             // 000000D3DC8C: DC520C00 317C0033
	s_waitcnt lgkmcnt(0)                                       // 000000D3DC94: BF89FC07
	v_wmma_f32_16x16x16_f16 v[1:8], v[80:87], v[88:95], v[1:8] // 000000D3DC98: CC404001 1C06B150
	v_add_nc_u32_e32 v88, s31, v63                             // 000000D3DCA0: 4AB07E1F
	s_waitcnt vmcnt(1)                                         // 000000D3DCA4: BF8907F7
	.long 0xd73d0032                                           // 000000D3DCA8: D73D0032
	v_cndmask_b32_e32 v1, v67, v53, vcc_lo                     // 000000D3DCAC: 02026B43
	s_waitcnt vmcnt(0)                                         // 000000D3DCB0: BF8903F7
	v_bfe_u32 v52, v49, 12, 16                                 // 000000D3DCB4: D6100034 02411931
	v_bfe_u32 v54, v49, 8, 16                                  // 000000D3DCBC: D6100036 02411131
	v_bfe_u32 v56, v49, 4, 16                                  // 000000D3DCC4: D6100038 02410931
	v_and_b32_e32 v49, 0xffff, v49                             // 000000D3DCCC: 366262FF 0000FFFF
	v_bfe_u32 v51, v50, 12, 16                                 // 000000D3DCD4: D6100033 02411932
	v_mul_u32_u24_e32 v80, s13, v51                            // 000000D3DCDC: 16A0660D
	v_mul_u32_u24_e32 v51, s21, v51                            // 000000D3DCE0: 16666615
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000D3DCE4: BF8700C1
	v_lshl_add_u32 v51, v51, 24, v80                           // 000000D3DCE8: D6460033 05413133
	v_bfe_u32 v53, v50, 8, 16                                  // 000000D3DCF0: D6100035 02411132
	v_mul_u32_u24_e32 v80, s13, v53                            // 000000D3DCF8: 16A06A0D
	v_mul_u32_u24_e32 v53, s21, v53                            // 000000D3DCFC: 166A6A15
	v_lshl_add_u32 v53, v53, 24, v80                           // 000000D3DD00: D6460035 05413135
	v_sad_u8 v51, v51, 0, 0x6400                               // 000000D3DD08: D6220033 03FD0133 00006400
	v_bfe_u32 v55, v50, 4, 16                                  // 000000D3DD14: D6100037 02410932
	v_and_b32_e32 v50, 0xffff, v50                             // 000000D3DD1C: 366464FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D3DD24: BF870214
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000D3DD28: D6220035 03FD0135 00006400
	v_and_b32_e32 v51, 0xffff, v51                             // 000000D3DD34: 366666FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D3DD3C: BF870001
	v_lshl_or_b32 v51, v53, 16, v51                            // 000000D3DD40: D6560033 04CD2135
	v_mul_u32_u24_e32 v53, s13, v55                            // 000000D3DD48: 166A6E0D
	v_mul_u32_u24_e32 v55, s21, v55                            // 000000D3DD4C: 166E6E15
	v_lshl_add_u32 v53, v55, 24, v53                           // 000000D3DD50: D6460035 04D53137
	v_mul_u32_u24_e32 v55, s13, v50                            // 000000D3DD58: 166E640D
	v_mul_u32_u24_e32 v50, s21, v50                            // 000000D3DD5C: 16646415
	v_lshl_add_u32 v50, v50, 24, v55                           // 000000D3DD60: D6460032 04DD3132
	v_pk_fma_f16 v51, v51, s22, 0xc931 op_sel_hi:[1,0,0]       // 000000D3DD68: CC0E0033 0BFC2D33 0000C931
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000D3DD74: D6220035 03FD0135 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D3DD80: BF870113
	v_sad_u8 v50, v50, 0, 0x6400                               // 000000D3DD84: D6220032 03FD0132 00006400
	v_and_b32_e32 v53, 0xffff, v53                             // 000000D3DD90: 366A6AFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D3DD98: BF8700A1
	v_lshl_or_b32 v50, v50, 16, v53                            // 000000D3DD9C: D6560032 04D52132
	v_mul_u32_u24_e32 v53, s21, v54                            // 000000D3DDA4: 166A6C15
	v_pk_fma_f16 v55, v50, s22, 0xc931 op_sel_hi:[1,0,0]       // 000000D3DDA8: CC0E0037 0BFC2D32 0000C931
	v_mul_u32_u24_e32 v50, s13, v52                            // 000000D3DDB4: 1664680D
	v_mul_u32_u24_e32 v52, s21, v52                            // 000000D3DDB8: 16686815
	v_lshl_add_u32 v50, v52, 24, v50                           // 000000D3DDBC: D6460032 04C93134
	v_mul_u32_u24_e32 v52, s13, v54                            // 000000D3DDC4: 16686C0D
	v_lshl_add_u32 v52, v53, 24, v52                           // 000000D3DDC8: D6460034 04D13135
	v_mul_u32_u24_e32 v53, s21, v56                            // 000000D3DDD0: 166A7015
	v_mov_b32_e32 v54, v55                                     // 000000D3DDD4: 7E6C0337
	v_sad_u8 v50, v50, 0, 0x6400                               // 000000D3DDD8: D6220032 03FD0132 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D3DDE4: BF870193
	v_sad_u8 v52, v52, 0, 0x6400                               // 000000D3DDE8: D6220034 03FD0134 00006400
	v_permlanex16_b32 v54, v54, s23, 0xfedcba98                // 000000D3DDF4: D65C0036 03FC2F36 FEDCBA98
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D3DE00: BF870093
	v_and_b32_e32 v50, 0xffff, v50                             // 000000D3DE04: 366464FF 0000FFFF
	v_lshl_or_b32 v50, v52, 16, v50                            // 000000D3DE0C: D6560032 04C92134
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D3DE14: BF870001
	v_pk_fma_f16 v52, v50, s22, 0xc931 op_sel_hi:[1,0,0]       // 000000D3DE18: CC0E0034 0BFC2D32 0000C931
	v_mul_u32_u24_e32 v50, s13, v56                            // 000000D3DE24: 1664700D
	v_lshl_add_u32 v50, v53, 24, v50                           // 000000D3DE28: D6460032 04C93135
	v_mul_u32_u24_e32 v53, s13, v49                            // 000000D3DE30: 166A620D
	v_mul_u32_u24_e32 v49, s21, v49                            // 000000D3DE34: 16626215
	v_lshl_add_u32 v49, v49, 24, v53                           // 000000D3DE38: D6460031 04D53131
	v_mov_b32_e32 v80, v52                                     // 000000D3DE40: 7EA00334
	v_sad_u8 v50, v50, 0, 0x6400                               // 000000D3DE44: D6220032 03FD0132 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D3DE50: BF870193
	v_sad_u8 v49, v49, 0, 0x6400                               // 000000D3DE54: D6220031 03FD0131 00006400
	v_permlanex16_b32 v80, v80, s23, 0xfedcba98                // 000000D3DE60: D65C0050 03FC2F50 FEDCBA98
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D3DE6C: BF870093
	v_and_b32_e32 v50, 0xffff, v50                             // 000000D3DE70: 366464FF 0000FFFF
	v_lshl_or_b32 v49, v49, 16, v50                            // 000000D3DE78: D6560031 04C92131
	v_mov_b32_e32 v50, v51                                     // 000000D3DE80: 7E640333
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D3DE84: BF870112
	v_pk_fma_f16 v56, v49, s22, 0xc931 op_sel_hi:[1,0,0]       // 000000D3DE88: CC0E0038 0BFC2D31 0000C931
	v_permlanex16_b32 v50, v50, s23, 0xfedcba98                // 000000D3DE94: D65C0032 03FC2F32 FEDCBA98
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D3DEA0: BF870112
	v_mov_b32_e32 v81, v56                                     // 000000D3DEA4: 7EA20338
	v_cndmask_b32_e64 v49, v50, v51, s3                        // 000000D3DEA8: D5010031 000E6732
	v_cndmask_b32_e64 v53, v51, v50, s3                        // 000000D3DEB0: D5010035 000E6533
	v_cndmask_b32_e64 v50, v54, v55, s3                        // 000000D3DEB8: D5010032 000E6F36
	v_cndmask_b32_e64 v54, v55, v54, s3                        // 000000D3DEC0: D5010036 000E6D37
	v_permlanex16_b32 v81, v81, s23, 0xfedcba98                // 000000D3DEC8: D65C0051 03FC2F51 FEDCBA98
	v_cndmask_b32_e64 v51, v80, v52, s3                        // 000000D3DED4: D5010033 000E6950
	v_cndmask_b32_e64 v55, v52, v80, s3                        // 000000D3DEDC: D5010037 000EA134
	s_delay_alu instid0(VALU_DEP_3)                            // 000000D3DEE4: BF870003
	v_cndmask_b32_e64 v52, v81, v56, s3                        // 000000D3DEE8: D5010034 000E7151
	v_cndmask_b32_e64 v56, v56, v81, s3                        // 000000D3DEF0: D5010038 000EA338
	ds_load_b128 v[80:83], v88                                 // 000000D3DEF8: DBFC0000 50000058
	ds_load_b128 v[84:87], v88 offset:16                       // 000000D3DF00: DBFC0010 54000058
	s_waitcnt lgkmcnt(0)                                       // 000000D3DF08: BF89FC07
	v_wmma_f32_16x16x16_f16 v[25:32], v[49:56], v[80:87], v[25:32]// 000000D3DF0C: CC404019 1C66A131
	ds_load_b128 v[80:83], v88 offset:4352                     // 000000D3DF14: DBFC1100 50000058
	ds_load_b128 v[84:87], v88 offset:4368                     // 000000D3DF1C: DBFC1110 54000058
	s_waitcnt lgkmcnt(0)                                       // 000000D3DF24: BF89FC07
	v_wmma_f32_16x16x16_f16 v[17:24], v[49:56], v[80:87], v[17:24]// 000000D3DF28: CC404011 1C46A131
	ds_load_b128 v[80:83], v88 offset:8704                     // 000000D3DF30: DBFC2200 50000058
	ds_load_b128 v[84:87], v88 offset:8720                     // 000000D3DF38: DBFC2210 54000058
	s_waitcnt lgkmcnt(0)                                       // 000000D3DF40: BF89FC07
	v_wmma_f32_16x16x16_f16 v[9:16], v[49:56], v[80:87], v[9:16]// 000000D3DF44: CC404009 1C26A131
	ds_load_b128 v[80:83], v88 offset:13056                    // 000000D3DF4C: DBFC3300 50000058
	ds_load_b128 v[84:87], v88 offset:13072                    // 000000D3DF54: DBFC3310 54000058
	s_waitcnt lgkmcnt(0)                                       // 000000D3DF5C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[1:8], v[49:56], v[80:87], v[1:8] // 000000D3DF60: CC404001 1C06A131
	s_cbranch_vccnz 63940                                      // 000000D3DF68: BFA4F9C4 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x47c>
	s_and_b32 s29, s30, exec_lo                                // 000000D3DF6C: 8B1D7E1E
	s_cselect_b32 s29, 0x4400, 0                               // 000000D3DF70: 981D80FF 00004400
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D3DF78: BF870099
	v_lshl_or_b32 v50, v58, 1, s29                             // 000000D3DF7C: D6560032 0075033A
	v_lshl_add_u32 v49, v60, 1, v50                            // 000000D3DF84: D6460031 04C9033C
	ds_store_b128 v49, v[33:36]                                // 000000D3DF8C: DB7C0000 00002131
	s_and_saveexec_b32 s29, s0                                 // 000000D3DF94: BE9D2000
	s_cbranch_execnz 7                                         // 000000D3DF98: BFA60007 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x1db8>
	s_or_b32 exec_lo, exec_lo, s29                             // 000000D3DF9C: 8C7E1D7E
	s_and_saveexec_b32 s29, s1                                 // 000000D3DFA0: BE9D2001
	s_cbranch_execnz 10                                        // 000000D3DFA4: BFA6000A <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x1dd0>
	s_or_b32 exec_lo, exec_lo, s29                             // 000000D3DFA8: 8C7E1D7E
	s_and_saveexec_b32 s29, s2                                 // 000000D3DFAC: BE9D2002
	s_cbranch_execz 63921                                      // 000000D3DFB0: BFA5F9B1 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x478>
	s_branch 11                                                // 000000D3DFB4: BFA0000B <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x1de4>
	v_add_nc_u32_e32 v50, v50, v62                             // 000000D3DFB8: 4A647D32
	ds_store_b128 v50, v[37:40]                                // 000000D3DFBC: DB7C0000 00002532
	s_or_b32 exec_lo, exec_lo, s29                             // 000000D3DFC4: 8C7E1D7E
	s_and_saveexec_b32 s29, s1                                 // 000000D3DFC8: BE9D2001
	s_cbranch_execz 65526                                      // 000000D3DFCC: BFA5FFF6 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x1da8>
	ds_store_b128 v49, v[41:44] offset:8704                    // 000000D3DFD0: DB7C2200 00002931
	s_or_b32 exec_lo, exec_lo, s29                             // 000000D3DFD8: 8C7E1D7E
	s_and_saveexec_b32 s29, s2                                 // 000000D3DFDC: BE9D2002
	s_cbranch_execz 63909                                      // 000000D3DFE0: BFA5F9A5 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x478>
	ds_store_b128 v49, v[45:48] offset:13056                   // 000000D3DFE4: DB7C3300 00002D31
	s_branch 63906                                             // 000000D3DFEC: BFA0F9A2 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x478>
	v_lshrrev_b32_e32 v33, 5, v0                               // 000000D3DFF0: 32420085
	v_lshrrev_b32_e32 v34, 2, v59                              // 000000D3DFF4: 32447682
	s_mul_i32 s1, s16, 0x1400                                  // 000000D3DFF8: 9601FF10 00001400
	s_mul_hi_i32 s0, s16, 0x1400                               // 000000D3E000: 9700FF10 00001400
	s_add_u32 s2, s14, s1                                      // 000000D3E008: 8002010E
	v_lshlrev_b32_e32 v36, 6, v33                              // 000000D3E00C: 30484286
	s_addc_u32 s3, s15, s0                                     // 000000D3E010: 8203000F
	s_lshl_b32 s0, s17, 7                                      // 000000D3E014: 84008711
	v_and_b32_e32 v37, 1, v0                                   // 000000D3E018: 364A0081
	s_ashr_i32 s1, s0, 31                                      // 000000D3E01C: 86019F00
	v_mad_u32_u24 v36, 0x210, v61, v36                         // 000000D3E020: D60B0024 04927AFF 00000210
	s_lshl_b64 s[4:5], s[0:1], 1                               // 000000D3E02C: 84848100
	v_and_b32_e32 v38, 4, v0                                   // 000000D3E030: 364C0084
	s_add_u32 s12, s2, s4                                      // 000000D3E034: 800C0402
	s_addc_u32 s13, s3, s5                                     // 000000D3E038: 820D0503
	v_and_or_b32 v34, v34, 4, v36                              // 000000D3E03C: D6570022 04910922
	v_and_b32_e32 v36, 2, v0                                   // 000000D3E044: 36480082
	.long 0xd44a0003                                           // 000000D3E048: D44A0003
	v_cndmask_b32_e32 v1, 0, v37, vcc_lo                       // 000000D3E04C: 02024A80
	v_and_b32_e32 v37, 8, v0                                   // 000000D3E050: 364A0088
	v_lshlrev_b32_e32 v35, 4, v59                              // 000000D3E054: 30467684
	.long 0xd44a0001                                           // 000000D3E058: D44A0001
	v_cndmask_b32_e32 v1, 0, v38, vcc_lo                       // 000000D3E05C: 02024C80
	.long 0xd44a0002                                           // 000000D3E060: D44A0002
	v_cndmask_b32_e32 v1, 0, v36, vcc_lo                       // 000000D3E064: 02024880
	v_lshlrev_b32_e32 v36, 3, v59                              // 000000D3E068: 30487683
	.long 0xd44a0000                                           // 000000D3E06C: D44A0000
	v_cndmask_b32_e32 v1, 0, v37, vcc_lo                       // 000000D3E070: 02024A80
	v_lshlrev_b32_e32 v37, 2, v59                              // 000000D3E074: 304A7682
	ds_store_2addr_b32 v34, v25, v26 offset1:2                 // 000000D3E078: D8380200 001A1922
	ds_store_2addr_b32 v34, v27, v28 offset0:4 offset1:6       // 000000D3E080: D8380604 001C1B22
	ds_store_2addr_b32 v34, v29, v30 offset0:8 offset1:10      // 000000D3E088: D8380A08 001E1D22
	v_and_b32_e32 v39, 16, v0                                  // 000000D3E090: 364E0090
	.long 0xd7001524                                           // 000000D3E094: D7001524
	v_cndmask_b32_e32 v1, s6, v36, vcc_lo                      // 000000D3E098: 02024806
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D3E09C: BF8701A1
	v_add_co_ci_u32_e64 v38, null, s7, 0, s21                  // 000000D3E0A0: D5207C26 00550007
	v_mad_u32_u24 v28, 0x210, v33, v35                         // 000000D3E0A8: D60B001C 048E42FF 00000210
	.long 0xd7000419                                           // 000000D3E0B4: D7000419
	v_cndmask_b32_e32 v0, v36, v4, vcc_lo                      // 000000D3E0B8: 02000924
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D3E0BC: BF870001
	v_add_co_ci_u32_e64 v26, null, s5, v38, s4                 // 000000D3E0C0: D5207C1A 00124C05
	v_lshlrev_b32_e32 v27, 1, v37                              // 000000D3E0C8: 30364A81
	s_mov_b32 s5, exec_lo                                      // 000000D3E0CC: BE85007E
	v_cmp_eq_u32_e32 vcc_lo, 0, v39                            // 000000D3E0D0: 7C944E80
	ds_store_2addr_b32 v34, v31, v32 offset0:12 offset1:14     // 000000D3E0D4: D8380E0C 00201F22
	s_waitcnt lgkmcnt(0)                                       // 000000D3E0DC: BF89FC07
	s_barrier                                                  // 000000D3E0E0: BFBD0000
	buffer_gl0_inv                                             // 000000D3E0E4: E0AC0000 00000000
	.long 0xd4c4007e                                           // 000000D3E0EC: D4C4007E
	v_cndmask_b32_e32 v1, s19, v33, vcc_lo                     // 000000D3E0F0: 02024213
	s_cbranch_execz 198                                        // 000000D3E0F4: BFA500C6 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x2210>
	global_load_b64 v[36:37], v27, s[12:13]                    // 000000D3E0F8: DC560000 240C001B
	ds_load_b128 v[29:32], v28                                 // 000000D3E100: DBFC0000 1D00001C
	s_mov_b32 s4, 0x76543210                                   // 000000D3E108: BE8400FF 76543210
	s_waitcnt lgkmcnt(0)                                       // 000000D3E110: BF89FC07
	v_dual_add_f32 v38, v29, v30 :: v_dual_add_f32 v39, v31, v32// 000000D3E114: C9083D1D 2626411F
	v_dual_sub_f32 v29, v29, v30 :: v_dual_sub_f32 v30, v31, v32// 000000D3E11C: C94A3D1D 1D1E411F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D3E124: BF870112
	v_sub_f32_e32 v32, v38, v39                                // 000000D3E128: 08404F26
	v_dual_add_f32 v31, v38, v39 :: v_dual_add_f32 v38, v29, v30// 000000D3E12C: C9084F26 1F263D1D
	v_sub_f32_e32 v29, v29, v30                                // 000000D3E134: 083A3D1D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D3E138: BF870223
	v_mov_b32_dpp v39, v32 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D3E13C: 7E4E02FA FF016120
	v_cndmask_b32_e64 v32, -v32, v32, s3                       // 000000D3E144: D5010020 200E4120
	v_mov_b32_dpp v30, v31 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D3E14C: 7E3C02FA FF01611F
	v_cndmask_b32_e64 v31, -v31, v31, s3                       // 000000D3E154: D501001F 200E3F1F
	v_mov_b32_dpp v40, v38 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D3E15C: 7E5002FA FF016126
	v_mov_b32_dpp v41, v29 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D3E164: 7E5202FA FF01611D
	v_cndmask_b32_e64 v29, -v29, v29, s3                       // 000000D3E16C: D501001D 200E3B1D
	v_cndmask_b32_e64 v38, -v38, v38, s3                       // 000000D3E174: D5010026 200E4D26
	v_add_f32_e32 v32, v32, v39                                // 000000D3E17C: 06404F20
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D3E180: BF870193
	v_dual_add_f32 v30, v31, v30 :: v_dual_add_f32 v29, v29, v41// 000000D3E184: C9083D1F 1E1C531D
	v_add_f32_e32 v31, v38, v40                                // 000000D3E18C: 063E5126
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D3E190: BF870223
	v_mov_b32_dpp v38, v32 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D3E194: 7E4C02FA FF016220
	v_cndmask_b32_e64 v32, -v32, v32, s2                       // 000000D3E19C: D5010020 200A4120
	v_mov_b32_dpp v39, v30 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D3E1A4: 7E4E02FA FF01621E
	v_mov_b32_dpp v40, v29 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D3E1AC: 7E5002FA FF01621D
	v_cndmask_b32_e64 v29, -v29, v29, s2                       // 000000D3E1B4: D501001D 200A3B1D
	v_cndmask_b32_e64 v30, -v30, v30, s2                       // 000000D3E1BC: D501001E 200A3D1E
	v_add_f32_e32 v32, v32, v38                                // 000000D3E1C4: 06404D20
	v_mov_b32_dpp v38, v31 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D3E1C8: 7E4C02FA FF01621F
	v_cndmask_b32_e64 v31, -v31, v31, s2                       // 000000D3E1D0: D501001F 200A3F1F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D3E1D8: BF870214
	v_dual_add_f32 v29, v29, v40 :: v_dual_add_f32 v30, v30, v39// 000000D3E1DC: C908511D 1D1E4F1E
	v_mov_b32_dpp v39, v32 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D3E1E4: 7E4E02FA FF016420
	v_cndmask_b32_e64 v32, -v32, v32, s1                       // 000000D3E1EC: D5010020 20064120
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D3E1F4: BF870214
	v_add_f32_e32 v31, v31, v38                                // 000000D3E1F8: 063E4D1F
	v_mov_b32_dpp v38, v29 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D3E1FC: 7E4C02FA FF01641D
	v_cndmask_b32_e64 v29, -v29, v29, s1                       // 000000D3E204: D501001D 20063B1D
	v_mov_b32_dpp v40, v30 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D3E20C: 7E5002FA FF01641E
	v_add_f32_e32 v32, v32, v39                                // 000000D3E214: 06404F20
	v_cndmask_b32_e64 v30, -v30, v30, s1                       // 000000D3E218: D501001E 20063D1E
	v_mov_b32_dpp v39, v31 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D3E220: 7E4E02FA FF01641F
	v_add_f32_e32 v29, v29, v38                                // 000000D3E228: 063A4D1D
	v_cndmask_b32_e64 v31, -v31, v31, s1                       // 000000D3E22C: D501001F 20063F1F
	v_mov_b32_dpp v38, v32 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D3E234: 7E4C02FA FF016820
	v_cndmask_b32_e64 v32, -v32, v32, s0                       // 000000D3E23C: D5010020 20024120
	v_add_f32_e32 v30, v30, v40                                // 000000D3E244: 063C511E
	v_mov_b32_dpp v40, v29 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D3E248: 7E5002FA FF01681D
	v_cndmask_b32_e64 v29, -v29, v29, s0                       // 000000D3E250: D501001D 20023B1D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D3E258: BF870214
	v_dual_add_f32 v31, v31, v39 :: v_dual_add_f32 v32, v32, v38// 000000D3E25C: C9084F1F 1F204D20
	v_mov_b32_dpp v38, v30 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D3E264: 7E4C02FA FF01681E
	v_cndmask_b32_e64 v30, -v30, v30, s0                       // 000000D3E26C: D501001E 20023D1E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D3E274: BF870214
	v_add_f32_e32 v29, v29, v40                                // 000000D3E278: 063A511D
	v_mov_b32_dpp v40, v31 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D3E27C: 7E5002FA FF01681F
	v_mov_b32_e32 v39, v32                                     // 000000D3E284: 7E4E0320
	v_cndmask_b32_e64 v31, -v31, v31, s0                       // 000000D3E288: D501001F 20023F1F
	v_cndmask_b32_e64 v32, -v32, v32, vcc_lo                   // 000000D3E290: D5010020 21AA4120
	v_mov_b32_e32 v42, v29                                     // 000000D3E298: 7E54031D
	v_add_f32_e32 v30, v30, v38                                // 000000D3E29C: 063C4D1E
	v_permlanex16_b32 v39, v39, s4, 0xfedcba98                 // 000000D3E2A0: D65C0027 03FC0927 FEDCBA98
	v_add_f32_e32 v31, v31, v40                                // 000000D3E2AC: 063E511F
	v_cndmask_b32_e64 v29, -v29, v29, vcc_lo                   // 000000D3E2B0: D501001D 21AA3B1D
	v_permlanex16_b32 v42, v42, s4, 0xfedcba98                 // 000000D3E2B8: D65C002A 03FC092A FEDCBA98
	v_mov_b32_e32 v38, v30                                     // 000000D3E2C4: 7E4C031E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D3E2C8: BF870224
	v_dual_add_f32 v32, v32, v39 :: v_dual_mov_b32 v39, v31    // 000000D3E2CC: C9104F20 2026011F
	v_cndmask_b32_e64 v30, -v30, v30, vcc_lo                   // 000000D3E2D4: D501001E 21AA3D1E
	v_add_f32_e32 v29, v29, v42                                // 000000D3E2DC: 063A551D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D3E2E0: BF870214
	v_permlanex16_b32 v38, v38, s4, 0xfedcba98                 // 000000D3E2E4: D65C0026 03FC0926 FEDCBA98
	v_mul_f32_e32 v32, 0x3db504f3, v32                         // 000000D3E2F0: 104040FF 3DB504F3
	.long 0x7f523880                                           // 000000D3E2F8: 7F523880
	v_cndmask_b32_e64 v31, -v31, v31, vcc_lo                   // 000000D3E2FC: D501001F 21AA3F1F
	v_permlanex16_b32 v39, v39, s4, 0xfedcba98                 // 000000D3E304: D65C0027 03FC0927 FEDCBA98
	v_dual_mul_f32 v29, 0x3db504f3, v29 :: v_dual_add_f32 v30, v30, v38// 000000D3E310: C8C83AFF 1D1E4D1E 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D3E31C: BF870114
	.long 0x7f4c39a9                                           // 000000D3E320: 7F4C39A9
	v_dual_add_f32 v31, v31, v39 :: v_dual_mul_f32 v30, 0x3db504f3, v30// 000000D3E324: C9064F1F 1F1E3CFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D3E330: BF870001
	v_mul_f32_e32 v31, 0x3db504f3, v31                         // 000000D3E334: 103E3EFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000D3E33C: BF8903F7
	v_fma_mix_f32 v32, v37, v32, neg(0) op_sel_hi:[1,0,0]      // 000000D3E340: CC200020 8A024125
	v_fma_mix_f32 v29, v37, v29, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D3E348: CC20081D 8A023B25
	.long 0x7f4a39a9                                           // 000000D3E350: 7F4A39A9
	v_fma_mix_f32 v30, v36, v30, neg(0) op_sel_hi:[1,0,0]      // 000000D3E354: CC20001E 8A023D24
	v_fma_mix_f32 v31, v36, v31, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D3E35C: CC20081F 8A023F24
	.long 0x7e4c39a0                                           // 000000D3E364: 7E4C39A0
	.long 0x7e4a399d                                           // 000000D3E368: 7E4A399D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D3E36C: BF870193
	v_bfe_u32 v39, v31, 16, 1                                  // 000000D3E370: D6100027 0205211F
	v_and_b32_e32 v38, 1, v38                                  // 000000D3E378: 364C4C81
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D3E37C: BF870223
	v_and_b32_e32 v36, 1, v37                                  // 000000D3E380: 36484A81
	v_bfe_u32 v37, v30, 16, 1                                  // 000000D3E384: D6100025 0205211E
	v_add3_u32 v31, v31, v39, 0x7fff                           // 000000D3E38C: D655001F 03FE4F1F 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000D3E398: BF870244
	v_add3_u32 v32, v32, v38, 0x7fff                           // 000000D3E39C: D6550020 03FE4D20 00007FFF
	.long 0x7f4c39a9                                           // 000000D3E3A8: 7F4C39A9
	v_add3_u32 v29, v29, v36, 0x7fff                           // 000000D3E3AC: D655001D 03FE491D 00007FFF
	v_add3_u32 v30, v30, v37, 0x7fff                           // 000000D3E3B8: D655001E 03FE4B1E 00007FFF
	.long 0x7e4c39a0                                           // 000000D3E3C4: 7E4C39A0
	v_add_nc_u32_e32 v32, s18, v33                             // 000000D3E3C8: 4A404212
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D3E3CC: BF870214
	v_and_b32_e32 v36, 0xffff0000, v29                         // 000000D3E3D0: 36483AFF FFFF0000
	.long 0x7e52399e                                           // 000000D3E3D8: 7E52399E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D3E3DC: BF870214
	v_and_b32_e32 v37, 0xffff, v38                             // 000000D3E3E0: 364A4CFF 0000FFFF
	v_mad_i64_i32 v[29:30], null, 0x1400, v32, v[25:26]        // 000000D3E3E8: D6FF7C1D 046640FF 00001400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D3E3F4: BF870193
	v_and_or_b32 v31, 0xffff0000, v31, v41                     // 000000D3E3F8: D657001F 04A63EFF FFFF0000
	v_or_b32_e32 v32, v36, v37                                 // 000000D3E404: 38404B24
	global_store_b64 v[29:30], v[31:32], off                   // 000000D3E408: DC6E0000 007C1F1D
	s_or_b32 exec_lo, exec_lo, s5                              // 000000D3E410: 8C7E057E
	v_or_b32_e32 v30, 8, v33                                   // 000000D3E414: 383C4288
	s_mov_b32 s5, exec_lo                                      // 000000D3E418: BE85007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D3E41C: BF870001
	v_mad_u32_u24 v29, 0x210, v30, v35                         // 000000D3E420: D60B001D 048E3CFF 00000210
	.long 0xd4c4007e                                           // 000000D3E42C: D4C4007E
	v_cndmask_b32_e32 v1, s19, v30, vcc_lo                     // 000000D3E430: 02023C13
	s_cbranch_execz 197                                        // 000000D3E434: BFA500C5 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x254c>
	global_load_b64 v[31:32], v27, s[12:13]                    // 000000D3E438: DC560000 1F0C001B
	ds_load_b128 v[35:38], v29                                 // 000000D3E440: DBFC0000 2300001D
	s_mov_b32 s4, 0x76543210                                   // 000000D3E448: BE8400FF 76543210
	s_waitcnt lgkmcnt(0)                                       // 000000D3E450: BF89FC07
	v_dual_add_f32 v39, v35, v36 :: v_dual_add_nc_u32 v30, s18, v30// 000000D3E454: C9204923 271E3C12
	v_dual_add_f32 v40, v37, v38 :: v_dual_sub_f32 v35, v35, v36// 000000D3E45C: C90A4D25 28224923
	v_sub_f32_e32 v36, v37, v38                                // 000000D3E464: 08484D25
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D3E468: BF8701A2
	v_sub_f32_e32 v38, v39, v40                                // 000000D3E46C: 084C5127
	v_add_f32_e32 v37, v39, v40                                // 000000D3E470: 064A5127
	v_add_f32_e32 v39, v35, v36                                // 000000D3E474: 064E4923
	v_sub_f32_e32 v35, v35, v36                                // 000000D3E478: 08464923
	s_delay_alu instid0(VALU_DEP_4)                            // 000000D3E47C: BF870004
	v_mov_b32_dpp v40, v38 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D3E480: 7E5002FA FF016126
	v_cndmask_b32_e64 v38, -v38, v38, s3                       // 000000D3E488: D5010026 200E4D26
	v_mov_b32_dpp v36, v37 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D3E490: 7E4802FA FF016125
	v_cndmask_b32_e64 v37, -v37, v37, s3                       // 000000D3E498: D5010025 200E4B25
	v_mov_b32_dpp v41, v39 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D3E4A0: 7E5202FA FF016127
	v_mov_b32_dpp v42, v35 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D3E4A8: 7E5402FA FF016123
	v_cndmask_b32_e64 v35, -v35, v35, s3                       // 000000D3E4B0: D5010023 200E4723
	v_cndmask_b32_e64 v39, -v39, v39, s3                       // 000000D3E4B8: D5010027 200E4F27
	v_add_f32_e32 v38, v38, v40                                // 000000D3E4C0: 064C5126
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D3E4C4: BF870193
	v_dual_add_f32 v36, v37, v36 :: v_dual_add_f32 v35, v35, v42// 000000D3E4C8: C9084925 24225523
	v_add_f32_e32 v37, v39, v41                                // 000000D3E4D0: 064A5327
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D3E4D4: BF870223
	v_mov_b32_dpp v39, v38 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D3E4D8: 7E4E02FA FF016226
	v_cndmask_b32_e64 v38, -v38, v38, s2                       // 000000D3E4E0: D5010026 200A4D26
	v_mov_b32_dpp v40, v36 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D3E4E8: 7E5002FA FF016224
	v_mov_b32_dpp v41, v35 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D3E4F0: 7E5202FA FF016223
	v_cndmask_b32_e64 v35, -v35, v35, s2                       // 000000D3E4F8: D5010023 200A4723
	v_cndmask_b32_e64 v36, -v36, v36, s2                       // 000000D3E500: D5010024 200A4924
	v_add_f32_e32 v38, v38, v39                                // 000000D3E508: 064C4F26
	v_mov_b32_dpp v39, v37 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D3E50C: 7E4E02FA FF016225
	v_cndmask_b32_e64 v37, -v37, v37, s2                       // 000000D3E514: D5010025 200A4B25
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D3E51C: BF870214
	v_dual_add_f32 v35, v35, v41 :: v_dual_add_f32 v36, v36, v40// 000000D3E520: C9085323 23245124
	v_mov_b32_dpp v40, v38 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D3E528: 7E5002FA FF016426
	v_cndmask_b32_e64 v38, -v38, v38, s1                       // 000000D3E530: D5010026 20064D26
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D3E538: BF870214
	v_add_f32_e32 v37, v37, v39                                // 000000D3E53C: 064A4F25
	v_mov_b32_dpp v39, v35 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D3E540: 7E4E02FA FF016423
	v_cndmask_b32_e64 v35, -v35, v35, s1                       // 000000D3E548: D5010023 20064723
	v_mov_b32_dpp v41, v36 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D3E550: 7E5202FA FF016424
	v_add_f32_e32 v38, v38, v40                                // 000000D3E558: 064C5126
	v_cndmask_b32_e64 v36, -v36, v36, s1                       // 000000D3E55C: D5010024 20064924
	v_mov_b32_dpp v40, v37 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D3E564: 7E5002FA FF016425
	v_add_f32_e32 v35, v35, v39                                // 000000D3E56C: 06464F23
	v_cndmask_b32_e64 v37, -v37, v37, s1                       // 000000D3E570: D5010025 20064B25
	v_mov_b32_dpp v39, v38 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D3E578: 7E4E02FA FF016826
	v_cndmask_b32_e64 v38, -v38, v38, s0                       // 000000D3E580: D5010026 20024D26
	v_add_f32_e32 v36, v36, v41                                // 000000D3E588: 06485324
	v_mov_b32_dpp v41, v35 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D3E58C: 7E5202FA FF016823
	v_cndmask_b32_e64 v35, -v35, v35, s0                       // 000000D3E594: D5010023 20024723
	.long 0x7f543880                                           // 000000D3E59C: 7F543880
	v_dual_add_f32 v38, v38, v39 :: v_dual_add_f32 v37, v37, v40// 000000D3E5A0: C9084F26 26245125
	v_mov_b32_dpp v39, v36 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D3E5A8: 7E4E02FA FF016824
	v_cndmask_b32_e64 v36, -v36, v36, s0                       // 000000D3E5B0: D5010024 20024924
	s_delay_alu instid0(VALU_DEP_3)                            // 000000D3E5B8: BF870003
	v_dual_add_f32 v35, v35, v41 :: v_dual_mov_b32 v40, v38    // 000000D3E5BC: C9105323 23280126
	v_cndmask_b32_e64 v38, -v38, v38, vcc_lo                   // 000000D3E5C4: D5010026 21AA4D26
	v_mov_b32_dpp v41, v37 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D3E5CC: 7E5202FA FF016825
	v_cndmask_b32_e64 v37, -v37, v37, s0                       // 000000D3E5D4: D5010025 20024B25
	v_add_f32_e32 v36, v36, v39                                // 000000D3E5DC: 06484F24
	v_permlanex16_b32 v40, v40, s4, 0xfedcba98                 // 000000D3E5E0: D65C0028 03FC0928 FEDCBA98
	v_mov_b32_e32 v43, v35                                     // 000000D3E5EC: 7E560323
	v_cndmask_b32_e64 v35, -v35, v35, vcc_lo                   // 000000D3E5F0: D5010023 21AA4723
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D3E5F8: BF870193
	v_dual_add_f32 v38, v38, v40 :: v_dual_add_f32 v37, v37, v41// 000000D3E5FC: C9085126 26245325
	v_permlanex16_b32 v43, v43, s4, 0xfedcba98                 // 000000D3E604: D65C002B 03FC092B FEDCBA98
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D3E610: BF870192
	v_dual_mul_f32 v38, 0x3db504f3, v38 :: v_dual_mov_b32 v39, v36// 000000D3E614: C8D04CFF 26260124 3DB504F3
	v_mov_b32_e32 v40, v37                                     // 000000D3E620: 7E500325
	v_cndmask_b32_e64 v36, -v36, v36, vcc_lo                   // 000000D3E624: D5010024 21AA4924
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000D3E62C: BF870244
	v_add_f32_e32 v35, v35, v43                                // 000000D3E630: 06465723
	v_cndmask_b32_e64 v37, -v37, v37, vcc_lo                   // 000000D3E634: D5010025 21AA4B25
	v_permlanex16_b32 v39, v39, s4, 0xfedcba98                 // 000000D3E63C: D65C0027 03FC0927 FEDCBA98
	v_permlanex16_b32 v40, v40, s4, 0xfedcba98                 // 000000D3E648: D65C0028 03FC0928 FEDCBA98
	v_mul_f32_e32 v35, 0x3db504f3, v35                         // 000000D3E654: 104646FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000D3E65C: BF870122
	v_dual_add_f32 v36, v36, v39 :: v_dual_add_f32 v37, v37, v40// 000000D3E660: C9084F24 24245125
	.long 0x7f4e39aa                                           // 000000D3E668: 7F4E39AA
	v_mul_f32_e32 v37, 0x3db504f3, v37                         // 000000D3E66C: 104A4AFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000D3E674: BF8903F7
	v_fma_mix_f32 v38, v32, v38, neg(0) op_sel_hi:[1,0,0]      // 000000D3E678: CC200026 8A024D20
	v_fma_mix_f32 v32, v32, v35, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D3E680: CC200820 8A024720
	v_mul_f32_e32 v35, 0x3db504f3, v36                         // 000000D3E688: 104648FF 3DB504F3
	.long 0x7f4839aa                                           // 000000D3E690: 7F4839AA
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D3E694: BF870214
	.long 0x7e4e39a6                                           // 000000D3E698: 7E4E39A6
	.long 0x7e4839a0                                           // 000000D3E69C: 7E4839A0
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D3E6A0: BF870224
	v_fma_mix_f32 v35, v31, v35, neg(0) op_sel_hi:[1,0,0]      // 000000D3E6A4: CC200023 8A02471F
	v_fma_mix_f32 v31, v31, v37, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D3E6AC: CC20081F 8A024B1F
	v_and_b32_e32 v39, 1, v39                                  // 000000D3E6B4: 364E4E81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D3E6B8: BF870194
	v_and_b32_e32 v36, 1, v36                                  // 000000D3E6BC: 36484881
	v_bfe_u32 v40, v31, 16, 1                                  // 000000D3E6C0: D6100028 0205211F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000D3E6C8: BF870243
	v_add3_u32 v37, v38, v39, 0x7fff                           // 000000D3E6CC: D6550025 03FE4F26 00007FFF
	v_bfe_u32 v38, v35, 16, 1                                  // 000000D3E6D8: D6100026 02052123
	.long 0x7f4e39aa                                           // 000000D3E6E0: 7F4E39AA
	v_add3_u32 v32, v32, v36, 0x7fff                           // 000000D3E6E4: D6550020 03FE4920 00007FFF
	.long 0x7e4e39a5                                           // 000000D3E6F0: 7E4E39A5
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D3E6F4: BF870224
	v_add3_u32 v35, v35, v38, 0x7fff                           // 000000D3E6F8: D6550023 03FE4D23 00007FFF
	v_add3_u32 v37, v31, v40, 0x7fff                           // 000000D3E704: D6550025 03FE511F 00007FFF
	v_and_b32_e32 v32, 0xffff0000, v32                         // 000000D3E710: 364040FF FFFF0000
	v_mad_i64_i32 v[30:31], null, 0x1400, v30, v[25:26]        // 000000D3E718: D6FF7C1E 04663CFF 00001400
	v_and_b32_e32 v36, 0xffff, v39                             // 000000D3E724: 36484EFF 0000FFFF
	.long 0x7e5439a3                                           // 000000D3E72C: 7E5439A3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D3E730: BF870112
	v_or_b32_e32 v36, v32, v36                                 // 000000D3E734: 38484920
	v_and_or_b32 v35, 0xffff0000, v37, v42                     // 000000D3E738: D6570023 04AA4AFF FFFF0000
	global_store_b64 v[30:31], v[35:36], off                   // 000000D3E744: DC6E0000 007C231E
	s_or_b32 exec_lo, exec_lo, s5                              // 000000D3E74C: 8C7E057E
	v_or_b32_e32 v30, 16, v33                                  // 000000D3E750: 383C4290
	s_mov_b32 s5, exec_lo                                      // 000000D3E754: BE85007E
	s_waitcnt_vscnt null, 0x0                                  // 000000D3E758: BC7C0000
	s_barrier                                                  // 000000D3E75C: BFBD0000
	buffer_gl0_inv                                             // 000000D3E760: E0AC0000 00000000
	ds_store_2addr_b32 v34, v17, v18 offset1:2                 // 000000D3E768: D8380200 00121122
	ds_store_2addr_b32 v34, v19, v20 offset0:4 offset1:6       // 000000D3E770: D8380604 00141322
	ds_store_2addr_b32 v34, v21, v22 offset0:8 offset1:10      // 000000D3E778: D8380A08 00161522
	ds_store_2addr_b32 v34, v23, v24 offset0:12 offset1:14     // 000000D3E780: D8380E0C 00181722
	s_waitcnt lgkmcnt(0)                                       // 000000D3E788: BF89FC07
	s_barrier                                                  // 000000D3E78C: BFBD0000
	buffer_gl0_inv                                             // 000000D3E790: E0AC0000 00000000
	.long 0xd4c4007e                                           // 000000D3E798: D4C4007E
	v_cndmask_b32_e32 v1, s19, v30, vcc_lo                     // 000000D3E79C: 02023C13
	s_cbranch_execz 199                                        // 000000D3E7A0: BFA500C7 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x28c0>
	global_load_b64 v[21:22], v27, s[12:13]                    // 000000D3E7A4: DC560000 150C001B
	ds_load_b128 v[17:20], v28                                 // 000000D3E7AC: DBFC0000 1100001C
	s_mov_b32 s4, 0x76543210                                   // 000000D3E7B4: BE8400FF 76543210
	s_waitcnt lgkmcnt(0)                                       // 000000D3E7BC: BF89FC07
	v_dual_add_f32 v23, v17, v18 :: v_dual_add_f32 v24, v19, v20// 000000D3E7C0: C9082511 17182913
	v_dual_sub_f32 v17, v17, v18 :: v_dual_sub_f32 v18, v19, v20// 000000D3E7C8: C94A2511 11122913
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D3E7D0: BF870112
	v_add_f32_e32 v19, v23, v24                                // 000000D3E7D4: 06263117
	v_dual_sub_f32 v20, v23, v24 :: v_dual_add_f32 v23, v17, v18// 000000D3E7D8: C9483117 14162511
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D3E7E0: BF870001
	v_mov_b32_dpp v24, v20 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D3E7E4: 7E3002FA FF016114
	v_cndmask_b32_e64 v20, -v20, v20, s3                       // 000000D3E7EC: D5010014 200E2914
	v_sub_f32_e32 v17, v17, v18                                // 000000D3E7F4: 08222511
	v_mov_b32_dpp v18, v19 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D3E7F8: 7E2402FA FF016113
	v_cndmask_b32_e64 v19, -v19, v19, s3                       // 000000D3E800: D5010013 200E2713
	v_mov_b32_dpp v31, v23 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D3E808: 7E3E02FA FF016117
	v_cndmask_b32_e64 v23, -v23, v23, s3                       // 000000D3E810: D5010017 200E2F17
	v_add_f32_e32 v20, v20, v24                                // 000000D3E818: 06283114
	v_mov_b32_dpp v32, v17 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D3E81C: 7E4002FA FF016111
	v_cndmask_b32_e64 v17, -v17, v17, s3                       // 000000D3E824: D5010011 200E2311
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D3E82C: BF870091
	v_dual_add_f32 v18, v19, v18 :: v_dual_add_f32 v17, v17, v32// 000000D3E830: C9082513 12104111
	v_mov_b32_dpp v24, v18 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D3E838: 7E3002FA FF016212
	v_cndmask_b32_e64 v18, -v18, v18, s2                       // 000000D3E840: D5010012 200A2512
	v_add_f32_e32 v19, v23, v31                                // 000000D3E848: 06263F17
	v_mov_b32_dpp v23, v20 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D3E84C: 7E2E02FA FF016214
	v_cndmask_b32_e64 v20, -v20, v20, s2                       // 000000D3E854: D5010014 200A2914
	v_mov_b32_dpp v31, v17 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D3E85C: 7E3E02FA FF016211
	v_cndmask_b32_e64 v17, -v17, v17, s2                       // 000000D3E864: D5010011 200A2311
	v_add_f32_e32 v18, v18, v24                                // 000000D3E86C: 06243112
	.long 0x7f403880                                           // 000000D3E870: 7F403880
	v_add_f32_e32 v20, v20, v23                                // 000000D3E874: 06282F14
	v_mov_b32_dpp v23, v19 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D3E878: 7E2E02FA FF016213
	v_cndmask_b32_e64 v19, -v19, v19, s2                       // 000000D3E880: D5010013 200A2713
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000D3E888: BF870233
	v_mov_b32_dpp v24, v20 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D3E88C: 7E3002FA FF016414
	v_cndmask_b32_e64 v20, -v20, v20, s1                       // 000000D3E894: D5010014 20062914
	v_add_f32_e32 v17, v17, v31                                // 000000D3E89C: 06223F11
	v_add_f32_e32 v19, v19, v23                                // 000000D3E8A0: 06262F13
	v_mov_b32_dpp v31, v18 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D3E8A4: 7E3E02FA FF016412
	v_cndmask_b32_e64 v18, -v18, v18, s1                       // 000000D3E8AC: D5010012 20062512
	v_add_f32_e32 v20, v20, v24                                // 000000D3E8B4: 06283114
	v_mov_b32_dpp v23, v17 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D3E8B8: 7E2E02FA FF016411
	v_cndmask_b32_e64 v17, -v17, v17, s1                       // 000000D3E8C0: D5010011 20062311
	v_mov_b32_dpp v24, v19 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D3E8C8: 7E3002FA FF016413
	v_cndmask_b32_e64 v19, -v19, v19, s1                       // 000000D3E8D0: D5010013 20062713
	v_add_f32_e32 v18, v18, v31                                // 000000D3E8D8: 06243F12
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000D3E8DC: BF8700B4
	v_add_f32_e32 v17, v17, v23                                // 000000D3E8E0: 06222F11
	v_mov_b32_dpp v23, v20 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D3E8E4: 7E2E02FA FF016814
	v_cndmask_b32_e64 v20, -v20, v20, s0                       // 000000D3E8EC: D5010014 20022914
	v_dual_add_f32 v19, v19, v24 :: v_dual_add_f32 v20, v20, v23// 000000D3E8F4: C9083113 13142F14
	v_mov_b32_dpp v23, v18 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D3E8FC: 7E2E02FA FF016812
	v_cndmask_b32_e64 v18, -v18, v18, s0                       // 000000D3E904: D5010012 20022512
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000D3E90C: BF870123
	v_mov_b32_e32 v24, v20                                     // 000000D3E910: 7E300314
	v_cndmask_b32_e64 v20, -v20, v20, vcc_lo                   // 000000D3E914: D5010014 21AA2914
	v_permlanex16_b32 v24, v24, s4, 0xfedcba98                 // 000000D3E91C: D65C0018 03FC0918 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000D3E928: BF8700B1
	v_add_f32_e32 v20, v20, v24                                // 000000D3E92C: 06283114
	v_mov_b32_dpp v31, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D3E930: 7E3E02FA FF016811
	v_cndmask_b32_e64 v17, -v17, v17, s0                       // 000000D3E938: D5010011 20022311
	v_dual_mul_f32 v20, 0x3db504f3, v20 :: v_dual_add_f32 v17, v17, v31// 000000D3E940: C8C828FF 14103F11 3DB504F3
	v_mov_b32_dpp v31, v19 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D3E94C: 7E3E02FA FF016813
	v_cndmask_b32_e64 v19, -v19, v19, s0                       // 000000D3E954: D5010013 20022713
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D3E95C: BF870091
	v_add_f32_e32 v19, v19, v31                                // 000000D3E960: 06263F13
	v_dual_mov_b32 v24, v19 :: v_dual_mov_b32 v35, v17         // 000000D3E964: CA100113 18220111
	v_cndmask_b32_e64 v17, -v17, v17, vcc_lo                   // 000000D3E96C: D5010011 21AA2311
	v_cndmask_b32_e64 v19, -v19, v19, vcc_lo                   // 000000D3E974: D5010013 21AA2713
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D3E97C: BF870213
	v_permlanex16_b32 v24, v24, s4, 0xfedcba98                 // 000000D3E980: D65C0018 03FC0918 FEDCBA98
	v_permlanex16_b32 v35, v35, s4, 0xfedcba98                 // 000000D3E98C: D65C0023 03FC0923 FEDCBA98
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D3E998: BF870112
	v_add_f32_e32 v19, v19, v24                                // 000000D3E99C: 06263113
	v_add_f32_e32 v17, v17, v35                                // 000000D3E9A0: 06224711
	v_add_f32_e32 v18, v18, v23                                // 000000D3E9A4: 06242F12
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D3E9A8: BF870193
	v_mul_f32_e32 v19, 0x3db504f3, v19                         // 000000D3E9AC: 102626FF 3DB504F3
	v_mul_f32_e32 v17, 0x3db504f3, v17                         // 000000D3E9B4: 102222FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000D3E9BC: BF870123
	v_mov_b32_e32 v23, v18                                     // 000000D3E9C0: 7E2E0312
	v_cndmask_b32_e64 v18, -v18, v18, vcc_lo                   // 000000D3E9C4: D5010012 21AA2512
	v_permlanex16_b32 v23, v23, s4, 0xfedcba98                 // 000000D3E9CC: D65C0017 03FC0917 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000D3E9D8: BF870121
	v_add_f32_e32 v18, v18, v23                                // 000000D3E9DC: 06242F12
	.long 0x7f2e39a0                                           // 000000D3E9E0: 7F2E39A0
	v_mul_f32_e32 v18, 0x3db504f3, v18                         // 000000D3E9E4: 102424FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000D3E9EC: BF8903F7
	v_fma_mix_f32 v20, v22, v20, neg(0) op_sel_hi:[1,0,0]      // 000000D3E9F0: CC200014 8A022916
	v_fma_mix_f32 v17, v22, v17, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D3E9F8: CC200811 8A022316
	.long 0x7f2c39a0                                           // 000000D3EA00: 7F2C39A0
	v_fma_mix_f32 v18, v21, v18, neg(0) op_sel_hi:[1,0,0]      // 000000D3EA04: CC200012 8A022515
	v_fma_mix_f32 v19, v21, v19, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D3EA0C: CC200813 8A022715
	.long 0x7e2e3994                                           // 000000D3EA14: 7E2E3994
	.long 0x7e2c3991                                           // 000000D3EA18: 7E2C3991
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D3EA1C: BF870193
	v_bfe_u32 v24, v19, 16, 1                                  // 000000D3EA20: D6100018 02052113
	v_and_b32_e32 v23, 1, v23                                  // 000000D3EA28: 362E2E81
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D3EA2C: BF870223
	v_and_b32_e32 v21, 1, v22                                  // 000000D3EA30: 362A2C81
	v_bfe_u32 v22, v18, 16, 1                                  // 000000D3EA34: D6100016 02052112
	v_add3_u32 v19, v19, v24, 0x7fff                           // 000000D3EA3C: D6550013 03FE3113 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000D3EA48: BF870244
	v_add3_u32 v20, v20, v23, 0x7fff                           // 000000D3EA4C: D6550014 03FE2F14 00007FFF
	.long 0x7f2e39a0                                           // 000000D3EA58: 7F2E39A0
	v_add3_u32 v17, v17, v21, 0x7fff                           // 000000D3EA5C: D6550011 03FE2B11 00007FFF
	v_add3_u32 v18, v18, v22, 0x7fff                           // 000000D3EA68: D6550012 03FE2D12 00007FFF
	.long 0x7e2e3994                                           // 000000D3EA74: 7E2E3994
	v_add_nc_u32_e32 v20, s18, v30                             // 000000D3EA78: 4A283C12
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D3EA7C: BF870214
	v_and_b32_e32 v21, 0xffff0000, v17                         // 000000D3EA80: 362A22FF FFFF0000
	.long 0x7e403992                                           // 000000D3EA88: 7E403992
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D3EA8C: BF870214
	v_and_b32_e32 v22, 0xffff, v23                             // 000000D3EA90: 362C2EFF 0000FFFF
	v_mad_i64_i32 v[17:18], null, 0x1400, v20, v[25:26]        // 000000D3EA98: D6FF7C11 046628FF 00001400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D3EAA4: BF870193
	v_and_or_b32 v19, 0xffff0000, v19, v32                     // 000000D3EAA8: D6570013 048226FF FFFF0000
	v_or_b32_e32 v20, v21, v22                                 // 000000D3EAB4: 38282D15
	global_store_b64 v[17:18], v[19:20], off                   // 000000D3EAB8: DC6E0000 007C1311
	s_or_b32 exec_lo, exec_lo, s5                              // 000000D3EAC0: 8C7E057E
	v_or_b32_e32 v17, 24, v33                                  // 000000D3EAC4: 38224298
	s_mov_b32 s5, exec_lo                                      // 000000D3EAC8: BE85007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D3EACC: BF870001
	.long 0xd4c4007e                                           // 000000D3EAD0: D4C4007E
	v_cndmask_b32_e32 v1, s19, v17, vcc_lo                     // 000000D3EAD4: 02022213
	s_cbranch_execz 203                                        // 000000D3EAD8: BFA500CB <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x2c08>
	global_load_b64 v[22:23], v27, s[12:13]                    // 000000D3EADC: DC560000 160C001B
	ds_load_b128 v[18:21], v29                                 // 000000D3EAE4: DBFC0000 1200001D
	s_mov_b32 s4, 0x76543210                                   // 000000D3EAEC: BE8400FF 76543210
	s_waitcnt lgkmcnt(0)                                       // 000000D3EAF4: BF89FC07
	v_dual_add_f32 v24, v18, v19 :: v_dual_add_nc_u32 v17, s18, v17// 000000D3EAF8: C9202712 18102212
	v_add_f32_e32 v30, v20, v21                                // 000000D3EB00: 063C2B14
	v_dual_sub_f32 v18, v18, v19 :: v_dual_sub_f32 v19, v20, v21// 000000D3EB04: C94A2712 12122B14
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D3EB0C: BF8700A2
	v_add_f32_e32 v20, v24, v30                                // 000000D3EB10: 06283D18
	v_sub_f32_e32 v21, v24, v30                                // 000000D3EB14: 082A3D18
	v_mov_b32_dpp v30, v21 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D3EB18: 7E3C02FA FF016115
	v_cndmask_b32_e64 v21, -v21, v21, s3                       // 000000D3EB20: D5010015 200E2B15
	v_add_f32_e32 v24, v18, v19                                // 000000D3EB28: 06302712
	v_sub_f32_e32 v18, v18, v19                                // 000000D3EB2C: 08242712
	v_mov_b32_dpp v19, v20 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D3EB30: 7E2602FA FF016114
	v_cndmask_b32_e64 v20, -v20, v20, s3                       // 000000D3EB38: D5010014 200E2914
	v_add_f32_e32 v21, v21, v30                                // 000000D3EB40: 062A3D15
	v_mov_b32_dpp v31, v24 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D3EB44: 7E3E02FA FF016118
	v_cndmask_b32_e64 v24, -v24, v24, s3                       // 000000D3EB4C: D5010018 200E3118
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D3EB54: BF870114
	v_add_f32_e32 v19, v20, v19                                // 000000D3EB58: 06262714
	v_add_f32_e32 v20, v24, v31                                // 000000D3EB5C: 06283F18
	v_mov_b32_dpp v24, v21 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D3EB60: 7E3002FA FF016215
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000D3EB68: BF870133
	v_mov_b32_dpp v30, v19 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D3EB6C: 7E3C02FA FF016213
	v_cndmask_b32_e64 v19, -v19, v19, s2                       // 000000D3EB74: D5010013 200A2713
	v_cndmask_b32_e64 v21, -v21, v21, s2                       // 000000D3EB7C: D5010015 200A2B15
	v_add_f32_e32 v19, v19, v30                                // 000000D3EB84: 06263D13
	v_mov_b32_dpp v32, v18 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D3EB88: 7E4002FA FF016112
	v_cndmask_b32_e64 v18, -v18, v18, s3                       // 000000D3EB90: D5010012 200E2512
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D3EB98: BF870114
	v_add_f32_e32 v21, v21, v24                                // 000000D3EB9C: 062A3115
	v_add_f32_e32 v18, v18, v32                                // 000000D3EBA0: 06244112
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000D3EBA4: BF870232
	v_mov_b32_dpp v30, v21 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D3EBA8: 7E3C02FA FF016415
	v_cndmask_b32_e64 v21, -v21, v21, s1                       // 000000D3EBB0: D5010015 20062B15
	.long 0x7f403880                                           // 000000D3EBB8: 7F403880
	v_mov_b32_dpp v31, v18 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D3EBBC: 7E3E02FA FF016212
	v_cndmask_b32_e64 v18, -v18, v18, s2                       // 000000D3EBC4: D5010012 200A2512
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000D3EBCC: BF870234
	v_add_f32_e32 v21, v21, v30                                // 000000D3EBD0: 062A3D15
	v_mov_b32_dpp v24, v20 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D3EBD4: 7E3002FA FF016214
	v_cndmask_b32_e64 v20, -v20, v20, s2                       // 000000D3EBDC: D5010014 200A2914
	v_add_f32_e32 v18, v18, v31                                // 000000D3EBE4: 06243F12
	v_mov_b32_dpp v31, v19 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D3EBE8: 7E3E02FA FF016413
	v_cndmask_b32_e64 v19, -v19, v19, s1                       // 000000D3EBF0: D5010013 20062713
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D3EBF8: BF870214
	v_add_f32_e32 v20, v20, v24                                // 000000D3EBFC: 06283114
	v_mov_b32_dpp v24, v18 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D3EC00: 7E3002FA FF016412
	v_cndmask_b32_e64 v18, -v18, v18, s1                       // 000000D3EC08: D5010012 20062512
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000D3EC10: BF8701B1
	v_dual_add_f32 v19, v19, v31 :: v_dual_add_f32 v18, v18, v24// 000000D3EC14: C9083F13 13123112
	v_mov_b32_dpp v24, v21 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D3EC1C: 7E3002FA FF016815
	v_cndmask_b32_e64 v21, -v21, v21, s0                       // 000000D3EC24: D5010015 20022B15
	v_mov_b32_dpp v31, v18 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D3EC2C: 7E3E02FA FF016812
	v_cndmask_b32_e64 v18, -v18, v18, s0                       // 000000D3EC34: D5010012 20022512
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000D3EC3C: BF8700B3
	v_add_f32_e32 v21, v21, v24                                // 000000D3EC40: 062A3115
	v_mov_b32_dpp v24, v19 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D3EC44: 7E3002FA FF016813
	v_cndmask_b32_e64 v19, -v19, v19, s0                       // 000000D3EC4C: D5010013 20022713
	v_dual_add_f32 v18, v18, v31 :: v_dual_add_f32 v19, v19, v24// 000000D3EC54: C9083F12 12123113
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000D3EC5C: BF870231
	v_mov_b32_e32 v35, v18                                     // 000000D3EC60: 7E460312
	v_mov_b32_dpp v30, v20 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D3EC64: 7E3C02FA FF016414
	v_cndmask_b32_e64 v20, -v20, v20, s1                       // 000000D3EC6C: D5010014 20062914
	v_mov_b32_e32 v24, v19                                     // 000000D3EC74: 7E300313
	v_cndmask_b32_e64 v19, -v19, v19, vcc_lo                   // 000000D3EC78: D5010013 21AA2713
	v_permlanex16_b32 v35, v35, s4, 0xfedcba98                 // 000000D3EC80: D65C0023 03FC0923 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D3EC8C: BF870214
	v_add_f32_e32 v20, v20, v30                                // 000000D3EC90: 06283D14
	v_permlanex16_b32 v24, v24, s4, 0xfedcba98                 // 000000D3EC94: D65C0018 03FC0918 FEDCBA98
	v_mov_b32_e32 v30, v21                                     // 000000D3ECA0: 7E3C0315
	v_cndmask_b32_e64 v21, -v21, v21, vcc_lo                   // 000000D3ECA4: D5010015 21AA2B15
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D3ECAC: BF870214
	v_mov_b32_dpp v31, v20 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D3ECB0: 7E3E02FA FF016814
	v_add_f32_e32 v19, v19, v24                                // 000000D3ECB8: 06263113
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000D3ECBC: BF870234
	v_permlanex16_b32 v30, v30, s4, 0xfedcba98                 // 000000D3ECC0: D65C001E 03FC091E FEDCBA98
	v_cndmask_b32_e64 v20, -v20, v20, s0                       // 000000D3ECCC: D5010014 20022914
	.long 0x7f3039a0                                           // 000000D3ECD4: 7F3039A0
	v_mul_f32_e32 v19, 0x3db504f3, v19                         // 000000D3ECD8: 102626FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D3ECE0: BF870093
	v_dual_add_f32 v21, v21, v30 :: v_dual_add_f32 v20, v20, v31// 000000D3ECE4: C9083D15 15143F14
	v_mul_f32_e32 v21, 0x3db504f3, v21                         // 000000D3ECEC: 102A2AFF 3DB504F3
	v_cndmask_b32_e64 v18, -v18, v18, vcc_lo                   // 000000D3ECF4: D5010012 21AA2512
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D3ECFC: BF8701A3
	v_mov_b32_e32 v30, v20                                     // 000000D3ED00: 7E3C0314
	v_cndmask_b32_e64 v20, -v20, v20, vcc_lo                   // 000000D3ED04: D5010014 21AA2914
	v_add_f32_e32 v18, v18, v35                                // 000000D3ED0C: 06244712
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D3ED10: BF870113
	v_permlanex16_b32 v30, v30, s4, 0xfedcba98                 // 000000D3ED14: D65C001E 03FC091E FEDCBA98
	v_mul_f32_e32 v18, 0x3db504f3, v18                         // 000000D3ED20: 102424FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D3ED28: BF870092
	v_add_f32_e32 v20, v20, v30                                // 000000D3ED2C: 06283D14
	v_mul_f32_e32 v20, 0x3db504f3, v20                         // 000000D3ED30: 102828FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000D3ED38: BF8903F7
	v_fma_mix_f32 v21, v23, v21, neg(0) op_sel_hi:[1,0,0]      // 000000D3ED3C: CC200015 8A022B17
	v_fma_mix_f32 v18, v23, v18, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D3ED44: CC200812 8A022517
	.long 0x7f2e39a0                                           // 000000D3ED4C: 7F2E39A0
	v_fma_mix_f32 v19, v22, v19, neg(0) op_sel_hi:[1,0,0]      // 000000D3ED50: CC200013 8A022716
	v_fma_mix_f32 v20, v22, v20, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D3ED58: CC200814 8A022916
	.long 0x7e303995                                           // 000000D3ED60: 7E303995
	.long 0x7e2e3992                                           // 000000D3ED64: 7E2E3992
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D3ED68: BF870193
	v_bfe_u32 v30, v20, 16, 1                                  // 000000D3ED6C: D610001E 02052114
	v_and_b32_e32 v24, 1, v24                                  // 000000D3ED74: 36303081
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D3ED78: BF8701A3
	v_and_b32_e32 v22, 1, v23                                  // 000000D3ED7C: 362C2E81
	v_bfe_u32 v23, v19, 16, 1                                  // 000000D3ED80: D6100017 02052113
	v_add3_u32 v21, v21, v24, 0x7fff                           // 000000D3ED88: D6550015 03FE3115 00007FFF
	.long 0x7f3039a0                                           // 000000D3ED94: 7F3039A0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D3ED98: BF870214
	v_add3_u32 v18, v18, v22, 0x7fff                           // 000000D3ED9C: D6550012 03FE2D12 00007FFF
	v_add3_u32 v19, v19, v23, 0x7fff                           // 000000D3EDA8: D6550013 03FE2F13 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D3EDB4: BF870224
	.long 0x7e303995                                           // 000000D3EDB8: 7E303995
	v_add3_u32 v21, v20, v30, 0x7fff                           // 000000D3EDBC: D6550015 03FE3D14 00007FFF
	v_and_b32_e32 v20, 0xffff0000, v18                         // 000000D3EDC8: 362824FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000D3EDD0: BF8701B4
	.long 0x7e403993                                           // 000000D3EDD4: 7E403993
	v_mad_i64_i32 v[17:18], null, 0x1400, v17, v[25:26]        // 000000D3EDD8: D6FF7C11 046622FF 00001400
	v_and_b32_e32 v22, 0xffff, v24                             // 000000D3EDE4: 362C30FF 0000FFFF
	v_and_or_b32 v19, 0xffff0000, v21, v32                     // 000000D3EDEC: D6570013 04822AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2)                            // 000000D3EDF8: BF870002
	v_or_b32_e32 v20, v20, v22                                 // 000000D3EDFC: 38282D14
	global_store_b64 v[17:18], v[19:20], off                   // 000000D3EE00: DC6E0000 007C1311
	s_or_b32 exec_lo, exec_lo, s5                              // 000000D3EE08: 8C7E057E
	v_or_b32_e32 v17, 32, v33                                  // 000000D3EE0C: 382242A0
	s_mov_b32 s5, exec_lo                                      // 000000D3EE10: BE85007E
	s_waitcnt_vscnt null, 0x0                                  // 000000D3EE14: BC7C0000
	s_barrier                                                  // 000000D3EE18: BFBD0000
	buffer_gl0_inv                                             // 000000D3EE1C: E0AC0000 00000000
	ds_store_2addr_b32 v34, v9, v10 offset1:2                  // 000000D3EE24: D8380200 000A0922
	ds_store_2addr_b32 v34, v11, v12 offset0:4 offset1:6       // 000000D3EE2C: D8380604 000C0B22
	ds_store_2addr_b32 v34, v13, v14 offset0:8 offset1:10      // 000000D3EE34: D8380A08 000E0D22
	ds_store_2addr_b32 v34, v15, v16 offset0:12 offset1:14     // 000000D3EE3C: D8380E0C 00100F22
	s_waitcnt lgkmcnt(0)                                       // 000000D3EE44: BF89FC07
	s_barrier                                                  // 000000D3EE48: BFBD0000
	buffer_gl0_inv                                             // 000000D3EE4C: E0AC0000 00000000
	.long 0xd4c4007e                                           // 000000D3EE54: D4C4007E
	v_cndmask_b32_e32 v1, s19, v17, vcc_lo                     // 000000D3EE58: 02022213
	s_cbranch_execz 198                                        // 000000D3EE5C: BFA500C6 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x2f78>
	global_load_b64 v[13:14], v27, s[12:13]                    // 000000D3EE60: DC560000 0D0C001B
	ds_load_b128 v[9:12], v28                                  // 000000D3EE68: DBFC0000 0900001C
	s_mov_b32 s4, 0x76543210                                   // 000000D3EE70: BE8400FF 76543210
	s_waitcnt lgkmcnt(0)                                       // 000000D3EE78: BF89FC07
	v_dual_add_f32 v15, v9, v10 :: v_dual_add_f32 v16, v11, v12// 000000D3EE7C: C9081509 0F10190B
	v_dual_sub_f32 v9, v9, v10 :: v_dual_sub_f32 v10, v11, v12 // 000000D3EE84: C94A1509 090A190B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D3EE8C: BF870112
	v_add_f32_e32 v11, v15, v16                                // 000000D3EE90: 0616210F
	v_dual_sub_f32 v12, v15, v16 :: v_dual_add_f32 v15, v9, v10// 000000D3EE94: C948210F 0C0E1509
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D3EE9C: BF870001
	v_mov_b32_dpp v16, v12 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D3EEA0: 7E2002FA FF01610C
	v_cndmask_b32_e64 v12, -v12, v12, s3                       // 000000D3EEA8: D501000C 200E190C
	v_sub_f32_e32 v9, v9, v10                                  // 000000D3EEB0: 08121509
	v_mov_b32_dpp v10, v11 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D3EEB4: 7E1402FA FF01610B
	v_cndmask_b32_e64 v11, -v11, v11, s3                       // 000000D3EEBC: D501000B 200E170B
	v_mov_b32_dpp v18, v15 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D3EEC4: 7E2402FA FF01610F
	v_cndmask_b32_e64 v15, -v15, v15, s3                       // 000000D3EECC: D501000F 200E1F0F
	v_add_f32_e32 v12, v12, v16                                // 000000D3EED4: 0618210C
	v_mov_b32_dpp v19, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D3EED8: 7E2602FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 000000D3EEE0: D5010009 200E1309
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D3EEE8: BF870091
	v_dual_add_f32 v10, v11, v10 :: v_dual_add_f32 v9, v9, v19 // 000000D3EEEC: C908150B 0A082709
	v_mov_b32_dpp v16, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D3EEF4: 7E2002FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 000000D3EEFC: D501000A 200A150A
	v_add_f32_e32 v11, v15, v18                                // 000000D3EF04: 0616250F
	v_mov_b32_dpp v15, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D3EF08: 7E1E02FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, s2                       // 000000D3EF10: D501000C 200A190C
	v_mov_b32_dpp v18, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D3EF18: 7E2402FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s2                          // 000000D3EF20: D5010009 200A1309
	v_add_f32_e32 v10, v10, v16                                // 000000D3EF28: 0614210A
	.long 0x7f263880                                           // 000000D3EF2C: 7F263880
	v_add_f32_e32 v12, v12, v15                                // 000000D3EF30: 06181F0C
	v_mov_b32_dpp v15, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D3EF34: 7E1E02FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s2                       // 000000D3EF3C: D501000B 200A170B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000D3EF44: BF870253
	v_mov_b32_dpp v16, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D3EF48: 7E2002FA FF01640C
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 000000D3EF50: D501000C 2006190C
	v_add_f32_e32 v9, v9, v18                                  // 000000D3EF58: 06122509
	v_mov_b32_dpp v18, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D3EF5C: 7E2402FA FF01640A
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 000000D3EF64: D501000A 2006150A
	v_dual_add_f32 v11, v11, v15 :: v_dual_add_f32 v12, v12, v16// 000000D3EF6C: C9081F0B 0B0C210C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D3EF74: BF870224
	v_mov_b32_dpp v15, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D3EF78: 7E1E02FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 000000D3EF80: D5010009 20061309
	v_add_f32_e32 v10, v10, v18                                // 000000D3EF88: 0614250A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D3EF8C: BF870224
	v_mov_b32_dpp v16, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D3EF90: 7E2002FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 000000D3EF98: D501000B 2006170B
	v_add_f32_e32 v9, v9, v15                                  // 000000D3EFA0: 06121F09
	v_mov_b32_dpp v15, v12 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D3EFA4: 7E1E02FA FF01680C
	v_cndmask_b32_e64 v12, -v12, v12, s0                       // 000000D3EFAC: D501000C 2002190C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000D3EFB4: BF8701B1
	v_dual_add_f32 v11, v11, v16 :: v_dual_add_f32 v12, v12, v15// 000000D3EFB8: C908210B 0B0C1F0C
	v_mov_b32_dpp v15, v10 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D3EFC0: 7E1E02FA FF01680A
	v_cndmask_b32_e64 v10, -v10, v10, s0                       // 000000D3EFC8: D501000A 2002150A
	v_mov_b32_e32 v16, v12                                     // 000000D3EFD0: 7E20030C
	v_mov_b32_dpp v18, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D3EFD4: 7E2402FA FF016809
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 000000D3EFDC: D5010009 20021309
	v_cndmask_b32_e64 v12, -v12, v12, vcc_lo                   // 000000D3EFE4: D501000C 21AA190C
	v_add_f32_e32 v10, v10, v15                                // 000000D3EFEC: 06141F0A
	v_permlanex16_b32 v16, v16, s4, 0xfedcba98                 // 000000D3EFF0: D65C0010 03FC0910 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000D3EFFC: BF870234
	v_add_f32_e32 v9, v9, v18                                  // 000000D3F000: 06122509
	v_mov_b32_dpp v18, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D3F004: 7E2402FA FF01680B
	v_cndmask_b32_e64 v11, -v11, v11, s0                       // 000000D3F00C: D501000B 2002170B
	v_dual_add_f32 v12, v12, v16 :: v_dual_mov_b32 v15, v10    // 000000D3F014: C910210C 0C0E010A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D3F01C: BF870224
	v_mov_b32_e32 v20, v9                                      // 000000D3F020: 7E280309
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000D3F024: D5010009 21AA1309
	v_add_f32_e32 v11, v11, v18                                // 000000D3F02C: 0616250B
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 000000D3F030: D501000A 21AA150A
	v_permlanex16_b32 v15, v15, s4, 0xfedcba98                 // 000000D3F038: D65C000F 03FC090F FEDCBA98
	v_permlanex16_b32 v20, v20, s4, 0xfedcba98                 // 000000D3F044: D65C0014 03FC0914 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D3F050: BF8701A4
	v_mov_b32_e32 v16, v11                                     // 000000D3F054: 7E20030B
	v_cndmask_b32_e64 v11, -v11, v11, vcc_lo                   // 000000D3F058: D501000B 21AA170B
	v_add_f32_e32 v9, v9, v20                                  // 000000D3F060: 06122909
	v_mul_f32_e32 v12, 0x3db504f3, v12                         // 000000D3F064: 101818FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000D3F06C: BF8701C4
	v_permlanex16_b32 v16, v16, s4, 0xfedcba98                 // 000000D3F070: D65C0010 03FC0910 FEDCBA98
	v_add_f32_e32 v10, v10, v15                                // 000000D3F07C: 06141F0A
	.long 0x7f1e3993                                           // 000000D3F080: 7F1E3993
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 000000D3F084: 101212FF 3DB504F3
	v_dual_add_f32 v11, v11, v16 :: v_dual_mul_f32 v10, 0x3db504f3, v10// 000000D3F08C: C906210B 0B0A14FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D3F098: BF870001
	v_mul_f32_e32 v11, 0x3db504f3, v11                         // 000000D3F09C: 101616FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000D3F0A4: BF8903F7
	v_fma_mix_f32 v12, v14, v12, neg(0) op_sel_hi:[1,0,0]      // 000000D3F0A8: CC20000C 8A02190E
	v_fma_mix_f32 v9, v14, v9, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D3F0B0: CC200809 8A02130E
	.long 0x7f1c3993                                           // 000000D3F0B8: 7F1C3993
	v_fma_mix_f32 v10, v13, v10, neg(0) op_sel_hi:[1,0,0]      // 000000D3F0BC: CC20000A 8A02150D
	v_fma_mix_f32 v11, v13, v11, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D3F0C4: CC20080B 8A02170D
	.long 0x7e1e398c                                           // 000000D3F0CC: 7E1E398C
	.long 0x7e1c3989                                           // 000000D3F0D0: 7E1C3989
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D3F0D4: BF870193
	v_bfe_u32 v16, v11, 16, 1                                  // 000000D3F0D8: D6100010 0205210B
	v_and_b32_e32 v15, 1, v15                                  // 000000D3F0E0: 361E1E81
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D3F0E4: BF870223
	v_and_b32_e32 v13, 1, v14                                  // 000000D3F0E8: 361A1C81
	v_bfe_u32 v14, v10, 16, 1                                  // 000000D3F0EC: D610000E 0205210A
	v_add3_u32 v11, v11, v16, 0x7fff                           // 000000D3F0F4: D655000B 03FE210B 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000D3F100: BF870244
	v_add3_u32 v12, v12, v15, 0x7fff                           // 000000D3F104: D655000C 03FE1F0C 00007FFF
	.long 0x7f1e3993                                           // 000000D3F110: 7F1E3993
	v_add3_u32 v9, v9, v13, 0x7fff                             // 000000D3F114: D6550009 03FE1B09 00007FFF
	v_add3_u32 v10, v10, v14, 0x7fff                           // 000000D3F120: D655000A 03FE1D0A 00007FFF
	.long 0x7e1e398c                                           // 000000D3F12C: 7E1E398C
	v_add_nc_u32_e32 v12, s18, v17                             // 000000D3F130: 4A182212
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D3F134: BF870214
	v_and_b32_e32 v13, 0xffff0000, v9                          // 000000D3F138: 361A12FF FFFF0000
	.long 0x7e26398a                                           // 000000D3F140: 7E26398A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D3F144: BF870214
	v_and_b32_e32 v14, 0xffff, v15                             // 000000D3F148: 361C1EFF 0000FFFF
	v_mad_i64_i32 v[9:10], null, 0x1400, v12, v[25:26]         // 000000D3F150: D6FF7C09 046618FF 00001400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D3F15C: BF870193
	v_and_or_b32 v11, 0xffff0000, v11, v19                     // 000000D3F160: D657000B 044E16FF FFFF0000
	v_or_b32_e32 v12, v13, v14                                 // 000000D3F16C: 38181D0D
	global_store_b64 v[9:10], v[11:12], off                    // 000000D3F170: DC6E0000 007C0B09
	s_or_b32 exec_lo, exec_lo, s5                              // 000000D3F178: 8C7E057E
	v_or_b32_e32 v9, 40, v33                                   // 000000D3F17C: 381242A8
	s_mov_b32 s5, exec_lo                                      // 000000D3F180: BE85007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D3F184: BF870001
	.long 0xd4c4007e                                           // 000000D3F188: D4C4007E
	v_cndmask_b32_e32 v1, s19, v9, vcc_lo                      // 000000D3F18C: 02021213
	s_cbranch_execz 200                                        // 000000D3F190: BFA500C8 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x32b4>
	global_load_b64 v[14:15], v27, s[12:13]                    // 000000D3F194: DC560000 0E0C001B
	ds_load_b128 v[10:13], v29                                 // 000000D3F19C: DBFC0000 0A00001D
	s_mov_b32 s4, 0x76543210                                   // 000000D3F1A4: BE8400FF 76543210
	s_waitcnt lgkmcnt(0)                                       // 000000D3F1AC: BF89FC07
	v_dual_add_f32 v16, v10, v11 :: v_dual_add_nc_u32 v9, s18, v9// 000000D3F1B0: C920170A 10081212
	v_dual_add_f32 v17, v12, v13 :: v_dual_sub_f32 v10, v10, v11// 000000D3F1B8: C90A1B0C 110A170A
	v_sub_f32_e32 v11, v12, v13                                // 000000D3F1C0: 08161B0C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D3F1C4: BF8701A2
	v_sub_f32_e32 v13, v16, v17                                // 000000D3F1C8: 081A2310
	v_add_f32_e32 v12, v16, v17                                // 000000D3F1CC: 06182310
	v_add_f32_e32 v16, v10, v11                                // 000000D3F1D0: 0620170A
	s_delay_alu instid0(VALU_DEP_3)                            // 000000D3F1D4: BF870003
	v_mov_b32_dpp v17, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D3F1D8: 7E2202FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, s3                       // 000000D3F1E0: D501000D 200E1B0D
	v_sub_f32_e32 v10, v10, v11                                // 000000D3F1E8: 0814170A
	v_mov_b32_dpp v11, v12 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D3F1EC: 7E1602FA FF01610C
	v_cndmask_b32_e64 v12, -v12, v12, s3                       // 000000D3F1F4: D501000C 200E190C
	v_mov_b32_dpp v18, v16 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D3F1FC: 7E2402FA FF016110
	v_add_f32_e32 v13, v13, v17                                // 000000D3F204: 061A230D
	v_mov_b32_dpp v19, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D3F208: 7E2602FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, s3                       // 000000D3F210: D501000A 200E150A
	v_cndmask_b32_e64 v16, -v16, v16, s3                       // 000000D3F218: D5010010 200E2110
	v_add_f32_e32 v11, v12, v11                                // 000000D3F220: 0616170C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D3F224: BF870193
	v_add_f32_e32 v10, v10, v19                                // 000000D3F228: 0614270A
	v_add_f32_e32 v12, v16, v18                                // 000000D3F22C: 06182510
	v_mov_b32_dpp v16, v13 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D3F230: 7E2002FA FF01620D
	v_cndmask_b32_e64 v13, -v13, v13, s2                       // 000000D3F238: D501000D 200A1B0D
	.long 0x7f263880                                           // 000000D3F240: 7F263880
	v_mov_b32_dpp v18, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D3F244: 7E2402FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 000000D3F24C: D501000A 200A150A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000D3F254: BF8700B1
	v_dual_add_f32 v13, v13, v16 :: v_dual_add_f32 v10, v10, v18// 000000D3F258: C908210D 0D0A250A
	v_mov_b32_dpp v17, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D3F260: 7E2202FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s2                       // 000000D3F268: D501000B 200A170B
	v_add_f32_e32 v11, v11, v17                                // 000000D3F270: 0616230B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D3F274: BF8701A4
	v_mov_b32_dpp v17, v13 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D3F278: 7E2202FA FF01640D
	v_cndmask_b32_e64 v13, -v13, v13, s1                       // 000000D3F280: D501000D 20061B0D
	v_mov_b32_dpp v18, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D3F288: 7E2402FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 000000D3F290: D501000B 2006170B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000D3F298: BF8700B3
	v_add_f32_e32 v13, v13, v17                                // 000000D3F29C: 061A230D
	v_mov_b32_dpp v16, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D3F2A0: 7E2002FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, s2                       // 000000D3F2A8: D501000C 200A190C
	v_dual_add_f32 v11, v11, v18 :: v_dual_add_f32 v12, v12, v16// 000000D3F2B0: C908250B 0B0C210C
	v_mov_b32_dpp v16, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D3F2B8: 7E2002FA FF01640A
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 000000D3F2C0: D501000A 2006150A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D3F2C8: BF8701A3
	v_mov_b32_dpp v17, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D3F2CC: 7E2202FA FF01640C
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 000000D3F2D4: D501000C 2006190C
	v_add_f32_e32 v10, v10, v16                                // 000000D3F2DC: 0614210A
	v_mov_b32_dpp v16, v13 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D3F2E0: 7E2002FA FF01680D
	v_cndmask_b32_e64 v13, -v13, v13, s0                       // 000000D3F2E8: D501000D 20021B0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000D3F2F0: BF8701B1
	v_dual_add_f32 v12, v12, v17 :: v_dual_add_f32 v13, v13, v16// 000000D3F2F4: C908230C 0C0C210D
	v_mov_b32_dpp v16, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D3F2FC: 7E2002FA FF01680B
	v_cndmask_b32_e64 v11, -v11, v11, s0                       // 000000D3F304: D501000B 2002170B
	v_mov_b32_e32 v17, v13                                     // 000000D3F30C: 7E22030D
	v_mov_b32_dpp v18, v10 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D3F310: 7E2402FA FF01680A
	v_cndmask_b32_e64 v10, -v10, v10, s0                       // 000000D3F318: D501000A 2002150A
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 000000D3F320: D501000D 21AA1B0D
	v_add_f32_e32 v11, v11, v16                                // 000000D3F328: 0616210B
	v_permlanex16_b32 v17, v17, s4, 0xfedcba98                 // 000000D3F32C: D65C0011 03FC0911 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000D3F338: BF8701B4
	v_add_f32_e32 v10, v10, v18                                // 000000D3F33C: 0614250A
	v_mov_b32_dpp v18, v12 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D3F340: 7E2402FA FF01680C
	v_cndmask_b32_e64 v12, -v12, v12, s0                       // 000000D3F348: D501000C 2002190C
	v_dual_add_f32 v13, v13, v17 :: v_dual_mov_b32 v20, v10    // 000000D3F350: C910230D 0D14010A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 000000D3F358: D501000A 21AA150A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D3F360: BF870222
	v_dual_add_f32 v12, v12, v18 :: v_dual_mul_f32 v13, 0x3db504f3, v13// 000000D3F364: C906250C 0C0C1AFF 3DB504F3
	v_mov_b32_e32 v16, v11                                     // 000000D3F370: 7E20030B
	v_permlanex16_b32 v20, v20, s4, 0xfedcba98                 // 000000D3F374: D65C0014 03FC0914 FEDCBA98
	v_cndmask_b32_e64 v11, -v11, v11, vcc_lo                   // 000000D3F380: D501000B 21AA170B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000D3F388: BF8701B4
	v_mov_b32_e32 v17, v12                                     // 000000D3F38C: 7E22030C
	v_cndmask_b32_e64 v12, -v12, v12, vcc_lo                   // 000000D3F390: D501000C 21AA190C
	v_permlanex16_b32 v16, v16, s4, 0xfedcba98                 // 000000D3F398: D65C0010 03FC0910 FEDCBA98
	v_permlanex16_b32 v17, v17, s4, 0xfedcba98                 // 000000D3F3A4: D65C0011 03FC0911 FEDCBA98
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D3F3B0: BF8701A2
	v_add_f32_e32 v11, v11, v16                                // 000000D3F3B4: 0616210B
	.long 0x7f203993                                           // 000000D3F3B8: 7F203993
	v_add_f32_e32 v12, v12, v17                                // 000000D3F3BC: 0618230C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D3F3C0: BF870113
	v_dual_add_f32 v10, v10, v20 :: v_dual_mul_f32 v11, 0x3db504f3, v11// 000000D3F3C4: C906290A 0A0A16FF 3DB504F3
	v_mul_f32_e32 v12, 0x3db504f3, v12                         // 000000D3F3D0: 101818FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000D3F3D8: BF870132
	v_mul_f32_e32 v10, 0x3db504f3, v10                         // 000000D3F3DC: 101414FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000D3F3E4: BF8903F7
	v_fma_mix_f32 v13, v15, v13, neg(0) op_sel_hi:[1,0,0]      // 000000D3F3E8: CC20000D 8A021B0F
	v_fma_mix_f32 v10, v15, v10, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D3F3F0: CC20080A 8A02150F
	.long 0x7f1e3993                                           // 000000D3F3F8: 7F1E3993
	v_fma_mix_f32 v11, v14, v11, neg(0) op_sel_hi:[1,0,0]      // 000000D3F3FC: CC20000B 8A02170E
	v_fma_mix_f32 v12, v14, v12, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D3F404: CC20080C 8A02190E
	.long 0x7e20398d                                           // 000000D3F40C: 7E20398D
	.long 0x7e1e398a                                           // 000000D3F410: 7E1E398A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D3F414: BF870193
	v_bfe_u32 v17, v12, 16, 1                                  // 000000D3F418: D6100011 0205210C
	v_and_b32_e32 v16, 1, v16                                  // 000000D3F420: 36202081
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D3F424: BF8701A3
	v_and_b32_e32 v14, 1, v15                                  // 000000D3F428: 361C1E81
	v_bfe_u32 v15, v11, 16, 1                                  // 000000D3F42C: D610000F 0205210B
	v_add3_u32 v13, v13, v16, 0x7fff                           // 000000D3F434: D655000D 03FE210D 00007FFF
	.long 0x7f203993                                           // 000000D3F440: 7F203993
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D3F444: BF870214
	v_add3_u32 v10, v10, v14, 0x7fff                           // 000000D3F448: D655000A 03FE1D0A 00007FFF
	v_add3_u32 v11, v11, v15, 0x7fff                           // 000000D3F454: D655000B 03FE1F0B 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D3F460: BF870224
	.long 0x7e20398d                                           // 000000D3F464: 7E20398D
	v_add3_u32 v13, v12, v17, 0x7fff                           // 000000D3F468: D655000D 03FE230C 00007FFF
	v_and_b32_e32 v12, 0xffff0000, v10                         // 000000D3F474: 361814FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000D3F47C: BF8701B4
	.long 0x7e26398b                                           // 000000D3F480: 7E26398B
	v_mad_i64_i32 v[9:10], null, 0x1400, v9, v[25:26]          // 000000D3F484: D6FF7C09 046612FF 00001400
	v_and_b32_e32 v14, 0xffff, v16                             // 000000D3F490: 361C20FF 0000FFFF
	v_and_or_b32 v11, 0xffff0000, v13, v19                     // 000000D3F498: D657000B 044E1AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2)                            // 000000D3F4A4: BF870002
	v_or_b32_e32 v12, v12, v14                                 // 000000D3F4A8: 38181D0C
	global_store_b64 v[9:10], v[11:12], off                    // 000000D3F4AC: DC6E0000 007C0B09
	s_or_b32 exec_lo, exec_lo, s5                              // 000000D3F4B4: 8C7E057E
	v_or_b32_e32 v9, 48, v33                                   // 000000D3F4B8: 381242B0
	s_mov_b32 s5, exec_lo                                      // 000000D3F4BC: BE85007E
	s_waitcnt_vscnt null, 0x0                                  // 000000D3F4C0: BC7C0000
	s_barrier                                                  // 000000D3F4C4: BFBD0000
	buffer_gl0_inv                                             // 000000D3F4C8: E0AC0000 00000000
	ds_store_2addr_b32 v34, v1, v2 offset1:2                   // 000000D3F4D0: D8380200 00020122
	ds_store_2addr_b32 v34, v3, v4 offset0:4 offset1:6         // 000000D3F4D8: D8380604 00040322
	ds_store_2addr_b32 v34, v5, v6 offset0:8 offset1:10        // 000000D3F4E0: D8380A08 00060522
	ds_store_2addr_b32 v34, v7, v8 offset0:12 offset1:14       // 000000D3F4E8: D8380E0C 00080722
	s_waitcnt lgkmcnt(0)                                       // 000000D3F4F0: BF89FC07
	s_barrier                                                  // 000000D3F4F4: BFBD0000
	buffer_gl0_inv                                             // 000000D3F4F8: E0AC0000 00000000
	.long 0xd4c4007e                                           // 000000D3F500: D4C4007E
	v_cndmask_b32_e32 v1, s19, v9, vcc_lo                      // 000000D3F504: 02021213
	s_cbranch_execz 198                                        // 000000D3F508: BFA500C6 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x3624>
	global_load_b64 v[5:6], v27, s[12:13]                      // 000000D3F50C: DC560000 050C001B
	ds_load_b128 v[1:4], v28                                   // 000000D3F514: DBFC0000 0100001C
	s_mov_b32 s4, 0x76543210                                   // 000000D3F51C: BE8400FF 76543210
	s_waitcnt lgkmcnt(0)                                       // 000000D3F524: BF89FC07
	v_dual_add_f32 v7, v1, v2 :: v_dual_add_f32 v8, v3, v4     // 000000D3F528: C9080501 07080903
	v_dual_sub_f32 v1, v1, v2 :: v_dual_sub_f32 v2, v3, v4     // 000000D3F530: C94A0501 01020903
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D3F538: BF870112
	v_add_f32_e32 v3, v7, v8                                   // 000000D3F53C: 06061107
	v_dual_sub_f32 v4, v7, v8 :: v_dual_add_f32 v7, v1, v2     // 000000D3F540: C9481107 04060501
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D3F548: BF870001
	v_mov_b32_dpp v8, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D3F54C: 7E1002FA FF016104
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000D3F554: D5010004 200E0904
	v_sub_f32_e32 v1, v1, v2                                   // 000000D3F55C: 08020501
	v_mov_b32_dpp v2, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D3F560: 7E0402FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 000000D3F568: D5010003 200E0703
	v_mov_b32_dpp v10, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D3F570: 7E1402FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s3                          // 000000D3F578: D5010007 200E0F07
	v_add_f32_e32 v4, v4, v8                                   // 000000D3F580: 06081104
	v_mov_b32_dpp v11, v1 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D3F584: 7E1602FA FF016101
	v_cndmask_b32_e64 v1, -v1, v1, s3                          // 000000D3F58C: D5010001 200E0301
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D3F594: BF870091
	v_dual_add_f32 v2, v3, v2 :: v_dual_add_f32 v1, v1, v11    // 000000D3F598: C9080503 02001701
	v_mov_b32_dpp v8, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D3F5A0: 7E1002FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s2                          // 000000D3F5A8: D5010002 200A0502
	v_add_f32_e32 v3, v7, v10                                  // 000000D3F5B0: 06061507
	v_mov_b32_dpp v7, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D3F5B4: 7E0E02FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s2                          // 000000D3F5BC: D5010004 200A0904
	v_mov_b32_dpp v10, v1 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D3F5C4: 7E1402FA FF016201
	v_cndmask_b32_e64 v1, -v1, v1, s2                          // 000000D3F5CC: D5010001 200A0301
	v_add_f32_e32 v2, v2, v8                                   // 000000D3F5D4: 06041102
	.long 0x7f163880                                           // 000000D3F5D8: 7F163880
	v_add_f32_e32 v4, v4, v7                                   // 000000D3F5DC: 06080F04
	v_mov_b32_dpp v7, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D3F5E0: 7E0E02FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s2                          // 000000D3F5E8: D5010003 200A0703
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000D3F5F0: BF870253
	v_mov_b32_dpp v8, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D3F5F4: 7E1002FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000D3F5FC: D5010004 20060904
	v_add_f32_e32 v1, v1, v10                                  // 000000D3F604: 06021501
	v_mov_b32_dpp v10, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D3F608: 7E1402FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 000000D3F610: D5010002 20060502
	v_dual_add_f32 v3, v3, v7 :: v_dual_add_f32 v4, v4, v8     // 000000D3F618: C9080F03 03041104
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D3F620: BF870224
	v_mov_b32_dpp v7, v1 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D3F624: 7E0E02FA FF016401
	v_cndmask_b32_e64 v1, -v1, v1, s1                          // 000000D3F62C: D5010001 20060301
	v_add_f32_e32 v2, v2, v10                                  // 000000D3F634: 06041502
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D3F638: BF870224
	v_mov_b32_dpp v8, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D3F63C: 7E1002FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 000000D3F644: D5010003 20060703
	v_add_f32_e32 v1, v1, v7                                   // 000000D3F64C: 06020F01
	v_mov_b32_dpp v7, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D3F650: 7E0E02FA FF016804
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 000000D3F658: D5010004 20020904
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000D3F660: BF8701B1
	v_dual_add_f32 v3, v3, v8 :: v_dual_add_f32 v4, v4, v7     // 000000D3F664: C9081103 03040F04
	v_mov_b32_dpp v7, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D3F66C: 7E0E02FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 000000D3F674: D5010002 20020502
	v_mov_b32_e32 v8, v4                                       // 000000D3F67C: 7E100304
	v_mov_b32_dpp v10, v1 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D3F680: 7E1402FA FF016801
	v_cndmask_b32_e64 v1, -v1, v1, s0                          // 000000D3F688: D5010001 20020301
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000D3F690: D5010004 21AA0904
	v_add_f32_e32 v2, v2, v7                                   // 000000D3F698: 06040F02
	v_permlanex16_b32 v8, v8, s4, 0xfedcba98                   // 000000D3F69C: D65C0008 03FC0908 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000D3F6A8: BF870234
	v_add_f32_e32 v1, v1, v10                                  // 000000D3F6AC: 06021501
	v_mov_b32_dpp v10, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D3F6B0: 7E1402FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 000000D3F6B8: D5010003 20020703
	v_dual_add_f32 v4, v4, v8 :: v_dual_mov_b32 v7, v2         // 000000D3F6C0: C9101104 04060102
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D3F6C8: BF870224
	v_mov_b32_e32 v12, v1                                      // 000000D3F6CC: 7E180301
	v_cndmask_b32_e64 v1, -v1, v1, vcc_lo                      // 000000D3F6D0: D5010001 21AA0301
	v_add_f32_e32 v3, v3, v10                                  // 000000D3F6D8: 06061503
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 000000D3F6DC: D5010002 21AA0502
	v_permlanex16_b32 v7, v7, s4, 0xfedcba98                   // 000000D3F6E4: D65C0007 03FC0907 FEDCBA98
	v_permlanex16_b32 v12, v12, s4, 0xfedcba98                 // 000000D3F6F0: D65C000C 03FC090C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D3F6FC: BF8701A4
	v_mov_b32_e32 v8, v3                                       // 000000D3F700: 7E100303
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000D3F704: D5010003 21AA0703
	v_add_f32_e32 v1, v1, v12                                  // 000000D3F70C: 06021901
	v_mul_f32_e32 v4, 0x3db504f3, v4                           // 000000D3F710: 100808FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000D3F718: BF8701C4
	v_permlanex16_b32 v8, v8, s4, 0xfedcba98                   // 000000D3F71C: D65C0008 03FC0908 FEDCBA98
	v_add_f32_e32 v2, v2, v7                                   // 000000D3F728: 06040F02
	.long 0x7f0e398b                                           // 000000D3F72C: 7F0E398B
	v_mul_f32_e32 v1, 0x3db504f3, v1                           // 000000D3F730: 100202FF 3DB504F3
	v_dual_add_f32 v3, v3, v8 :: v_dual_mul_f32 v2, 0x3db504f3, v2// 000000D3F738: C9061103 030204FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D3F744: BF870001
	v_mul_f32_e32 v3, 0x3db504f3, v3                           // 000000D3F748: 100606FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000D3F750: BF8903F7
	v_fma_mix_f32 v4, v6, v4, neg(0) op_sel_hi:[1,0,0]         // 000000D3F754: CC200004 8A020906
	v_fma_mix_f32 v1, v6, v1, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D3F75C: CC200801 8A020306
	.long 0x7f0c398b                                           // 000000D3F764: 7F0C398B
	v_fma_mix_f32 v2, v5, v2, neg(0) op_sel_hi:[1,0,0]         // 000000D3F768: CC200002 8A020505
	v_fma_mix_f32 v3, v5, v3, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D3F770: CC200803 8A020705
	.long 0x7e0e3984                                           // 000000D3F778: 7E0E3984
	.long 0x7e0c3981                                           // 000000D3F77C: 7E0C3981
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D3F780: BF870193
	v_bfe_u32 v8, v3, 16, 1                                    // 000000D3F784: D6100008 02052103
	v_and_b32_e32 v7, 1, v7                                    // 000000D3F78C: 360E0E81
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D3F790: BF870223
	v_and_b32_e32 v5, 1, v6                                    // 000000D3F794: 360A0C81
	v_bfe_u32 v6, v2, 16, 1                                    // 000000D3F798: D6100006 02052102
	v_add3_u32 v3, v3, v8, 0x7fff                              // 000000D3F7A0: D6550003 03FE1103 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000D3F7AC: BF870244
	v_add3_u32 v4, v4, v7, 0x7fff                              // 000000D3F7B0: D6550004 03FE0F04 00007FFF
	.long 0x7f0e398b                                           // 000000D3F7BC: 7F0E398B
	v_add3_u32 v1, v1, v5, 0x7fff                              // 000000D3F7C0: D6550001 03FE0B01 00007FFF
	v_add3_u32 v2, v2, v6, 0x7fff                              // 000000D3F7CC: D6550002 03FE0D02 00007FFF
	.long 0x7e0e3984                                           // 000000D3F7D8: 7E0E3984
	v_add_nc_u32_e32 v4, s18, v9                               // 000000D3F7DC: 4A081212
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D3F7E0: BF870214
	v_and_b32_e32 v5, 0xffff0000, v1                           // 000000D3F7E4: 360A02FF FFFF0000
	.long 0x7e163982                                           // 000000D3F7EC: 7E163982
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D3F7F0: BF870214
	v_and_b32_e32 v6, 0xffff, v7                               // 000000D3F7F4: 360C0EFF 0000FFFF
	v_mad_i64_i32 v[1:2], null, 0x1400, v4, v[25:26]           // 000000D3F7FC: D6FF7C01 046608FF 00001400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D3F808: BF870193
	v_and_or_b32 v3, 0xffff0000, v3, v11                       // 000000D3F80C: D6570003 042E06FF FFFF0000
	v_or_b32_e32 v4, v5, v6                                    // 000000D3F818: 38080D05
	global_store_b64 v[1:2], v[3:4], off                       // 000000D3F81C: DC6E0000 007C0301
	s_or_b32 exec_lo, exec_lo, s5                              // 000000D3F824: 8C7E057E
	v_or_b32_e32 v1, 56, v33                                   // 000000D3F828: 380242B8
	s_mov_b32 s5, exec_lo                                      // 000000D3F82C: BE85007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D3F830: BF870001
	.long 0xd4c4007e                                           // 000000D3F834: D4C4007E
	v_cndmask_b32_e32 v1, s19, v1, vcc_lo                      // 000000D3F838: 02020213
	s_cbranch_execz 200                                        // 000000D3F83C: BFA500C8 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x3960>
	global_load_b64 v[6:7], v27, s[12:13]                      // 000000D3F840: DC560000 060C001B
	ds_load_b128 v[2:5], v29                                   // 000000D3F848: DBFC0000 0200001D
	s_waitcnt lgkmcnt(0)                                       // 000000D3F850: BF89FC07
	v_dual_add_f32 v8, v2, v3 :: v_dual_add_nc_u32 v1, s18, v1 // 000000D3F854: C9200702 08000212
	v_dual_add_f32 v9, v4, v5 :: v_dual_sub_f32 v2, v2, v3     // 000000D3F85C: C90A0B04 09020702
	v_sub_f32_e32 v3, v4, v5                                   // 000000D3F864: 08060B04
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D3F868: BF8701A2
	v_sub_f32_e32 v5, v8, v9                                   // 000000D3F86C: 080A1308
	v_add_f32_e32 v4, v8, v9                                   // 000000D3F870: 06081308
	v_add_f32_e32 v8, v2, v3                                   // 000000D3F874: 06100702
	s_delay_alu instid0(VALU_DEP_3)                            // 000000D3F878: BF870003
	v_mov_b32_dpp v9, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D3F87C: 7E1202FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 000000D3F884: D5010005 200E0B05
	v_sub_f32_e32 v2, v2, v3                                   // 000000D3F88C: 08040702
	v_mov_b32_dpp v3, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D3F890: 7E0602FA FF016104
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000D3F898: D5010004 200E0904
	v_mov_b32_dpp v10, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D3F8A0: 7E1402FA FF016108
	v_add_f32_e32 v5, v5, v9                                   // 000000D3F8A8: 060A1305
	v_mov_b32_dpp v11, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D3F8AC: 7E1602FA FF016102
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 000000D3F8B4: D5010002 200E0502
	v_cndmask_b32_e64 v8, -v8, v8, s3                          // 000000D3F8BC: D5010008 200E1108
	v_add_f32_e32 v3, v4, v3                                   // 000000D3F8C4: 06060704
	s_mov_b32 s3, 0x76543210                                   // 000000D3F8C8: BE8300FF 76543210
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D3F8D0: BF870193
	v_add_f32_e32 v2, v2, v11                                  // 000000D3F8D4: 06041702
	v_add_f32_e32 v4, v8, v10                                  // 000000D3F8D8: 06081508
	v_mov_b32_dpp v8, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D3F8DC: 7E1002FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s2                          // 000000D3F8E4: D5010005 200A0B05
	.long 0x7f163880                                           // 000000D3F8EC: 7F163880
	v_mov_b32_dpp v10, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D3F8F0: 7E1402FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s2                          // 000000D3F8F8: D5010002 200A0502
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000D3F900: BF8700B1
	v_dual_add_f32 v5, v5, v8 :: v_dual_add_f32 v2, v2, v10    // 000000D3F904: C9081105 05021502
	v_mov_b32_dpp v9, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D3F90C: 7E1202FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s2                          // 000000D3F914: D5010003 200A0703
	v_add_f32_e32 v3, v3, v9                                   // 000000D3F91C: 06061303
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D3F920: BF8701A4
	v_mov_b32_dpp v9, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D3F924: 7E1202FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s1                          // 000000D3F92C: D5010005 20060B05
	v_mov_b32_dpp v10, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D3F934: 7E1402FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 000000D3F93C: D5010003 20060703
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000D3F944: BF8700B3
	v_add_f32_e32 v5, v5, v9                                   // 000000D3F948: 060A1305
	v_mov_b32_dpp v8, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D3F94C: 7E1002FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s2                          // 000000D3F954: D5010004 200A0904
	v_dual_add_f32 v3, v3, v10 :: v_dual_add_f32 v4, v4, v8    // 000000D3F95C: C9081503 03041104
	v_mov_b32_dpp v8, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D3F964: 7E1002FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 000000D3F96C: D5010002 20060502
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D3F974: BF8701A3
	v_mov_b32_dpp v9, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D3F978: 7E1202FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000D3F980: D5010004 20060904
	v_add_f32_e32 v2, v2, v8                                   // 000000D3F988: 06041102
	v_mov_b32_dpp v8, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D3F98C: 7E1002FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 000000D3F994: D5010005 20020B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000D3F99C: BF8701B1
	v_dual_add_f32 v4, v4, v9 :: v_dual_add_f32 v5, v5, v8     // 000000D3F9A0: C9081304 04041105
	v_mov_b32_dpp v8, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D3F9A8: 7E1002FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 000000D3F9B0: D5010003 20020703
	v_mov_b32_e32 v9, v5                                       // 000000D3F9B8: 7E120305
	v_mov_b32_dpp v10, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D3F9BC: 7E1402FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 000000D3F9C4: D5010002 20020502
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000D3F9CC: D5010005 21AA0B05
	v_add_f32_e32 v3, v3, v8                                   // 000000D3F9D4: 06061103
	v_permlanex16_b32 v9, v9, s3, 0xfedcba98                   // 000000D3F9D8: D65C0009 03FC0709 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000D3F9E4: BF8701B4
	v_add_f32_e32 v2, v2, v10                                  // 000000D3F9E8: 06041502
	v_mov_b32_dpp v10, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D3F9EC: 7E1402FA FF016804
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 000000D3F9F4: D5010004 20020904
	v_dual_add_f32 v5, v5, v9 :: v_dual_mov_b32 v12, v2        // 000000D3F9FC: C9101305 050C0102
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 000000D3FA04: D5010002 21AA0502
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D3FA0C: BF870222
	v_dual_add_f32 v4, v4, v10 :: v_dual_mul_f32 v5, 0x3db504f3, v5// 000000D3FA10: C9061504 04040AFF 3DB504F3
	v_mov_b32_e32 v8, v3                                       // 000000D3FA1C: 7E100303
	v_permlanex16_b32 v12, v12, s3, 0xfedcba98                 // 000000D3FA20: D65C000C 03FC070C FEDCBA98
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000D3FA2C: D5010003 21AA0703
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000D3FA34: BF8701B4
	v_mov_b32_e32 v9, v4                                       // 000000D3FA38: 7E120304
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000D3FA3C: D5010004 21AA0904
	v_permlanex16_b32 v8, v8, s3, 0xfedcba98                   // 000000D3FA44: D65C0008 03FC0708 FEDCBA98
	v_permlanex16_b32 v9, v9, s3, 0xfedcba98                   // 000000D3FA50: D65C0009 03FC0709 FEDCBA98
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D3FA5C: BF8701A2
	v_add_f32_e32 v3, v3, v8                                   // 000000D3FA60: 06061103
	.long 0x7f10398b                                           // 000000D3FA64: 7F10398B
	v_add_f32_e32 v4, v4, v9                                   // 000000D3FA68: 06081304
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D3FA6C: BF870113
	v_dual_add_f32 v2, v2, v12 :: v_dual_mul_f32 v3, 0x3db504f3, v3// 000000D3FA70: C9061902 020206FF 3DB504F3
	v_mul_f32_e32 v4, 0x3db504f3, v4                           // 000000D3FA7C: 100808FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000D3FA84: BF870132
	v_mul_f32_e32 v2, 0x3db504f3, v2                           // 000000D3FA88: 100404FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000D3FA90: BF8903F7
	v_fma_mix_f32 v5, v7, v5, neg(0) op_sel_hi:[1,0,0]         // 000000D3FA94: CC200005 8A020B07
	v_fma_mix_f32 v2, v7, v2, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D3FA9C: CC200802 8A020507
	.long 0x7f0e398b                                           // 000000D3FAA4: 7F0E398B
	v_fma_mix_f32 v3, v6, v3, neg(0) op_sel_hi:[1,0,0]         // 000000D3FAA8: CC200003 8A020706
	v_fma_mix_f32 v4, v6, v4, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D3FAB0: CC200804 8A020906
	.long 0x7e103985                                           // 000000D3FAB8: 7E103985
	.long 0x7e0e3982                                           // 000000D3FABC: 7E0E3982
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D3FAC0: BF870193
	v_bfe_u32 v9, v4, 16, 1                                    // 000000D3FAC4: D6100009 02052104
	v_and_b32_e32 v8, 1, v8                                    // 000000D3FACC: 36101081
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D3FAD0: BF8701A3
	v_and_b32_e32 v6, 1, v7                                    // 000000D3FAD4: 360C0E81
	v_bfe_u32 v7, v3, 16, 1                                    // 000000D3FAD8: D6100007 02052103
	v_add3_u32 v5, v5, v8, 0x7fff                              // 000000D3FAE0: D6550005 03FE1105 00007FFF
	.long 0x7f10398b                                           // 000000D3FAEC: 7F10398B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D3FAF0: BF870214
	v_add3_u32 v2, v2, v6, 0x7fff                              // 000000D3FAF4: D6550002 03FE0D02 00007FFF
	v_add3_u32 v3, v3, v7, 0x7fff                              // 000000D3FB00: D6550003 03FE0F03 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D3FB0C: BF870224
	.long 0x7e103985                                           // 000000D3FB10: 7E103985
	v_add3_u32 v5, v4, v9, 0x7fff                              // 000000D3FB14: D6550005 03FE1304 00007FFF
	v_and_b32_e32 v4, 0xffff0000, v2                           // 000000D3FB20: 360804FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000D3FB28: BF8701B4
	.long 0x7e163983                                           // 000000D3FB2C: 7E163983
	v_mad_i64_i32 v[1:2], null, 0x1400, v1, v[25:26]           // 000000D3FB30: D6FF7C01 046602FF 00001400
	v_and_b32_e32 v6, 0xffff, v8                               // 000000D3FB3C: 360C10FF 0000FFFF
	v_and_or_b32 v3, 0xffff0000, v5, v11                       // 000000D3FB44: D6570003 042E0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2)                            // 000000D3FB50: BF870002
	v_or_b32_e32 v4, v4, v6                                    // 000000D3FB54: 38080D04
	global_store_b64 v[1:2], v[3:4], off                       // 000000D3FB58: DC6E0000 007C0301
	s_or_b32 exec_lo, exec_lo, s5                              // 000000D3FB60: 8C7E057E
	s_mov_b32 s1, 0                                            // 000000D3FB64: BE810080
	s_waitcnt_vscnt null, 0x0                                  // 000000D3FB68: BC7C0000
	s_barrier                                                  // 000000D3FB6C: BFBD0000
	s_and_b32 vcc_lo, exec_lo, s1                              // 000000D3FB70: 8B6A017E
	s_cbranch_vccz 3016                                        // 000000D3FB74: BFA30BC8 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x6898>
	v_or_b32_e32 v1, 0x100, v0                                 // 000000D3FB78: 380200FF 00000100
	v_lshrrev_b32_e32 v7, 4, v0                                // 000000D3FB80: 320E0084
	s_add_i32 s0, s19, -1                                      // 000000D3FB84: 8100C113
	v_lshrrev_b32_e32 v9, 4, v57                               // 000000D3FB88: 32127284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000D3FB8C: BF8701B3
	v_lshrrev_b32_e32 v8, 4, v1                                // 000000D3FB90: 32100284
	v_lshlrev_b32_e32 v1, 3, v0                                // 000000D3FB94: 30020083
	v_min_i32_e32 v2, s0, v7                                   // 000000D3FB98: 22040E00
	v_min_i32_e32 v3, s0, v8                                   // 000000D3FB9C: 22061000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D3FBA0: BF870223
	v_and_b32_e32 v87, 0x78, v1                                // 000000D3FBA4: 36AE02FF 00000078
	v_min_i32_e32 v1, s0, v9                                   // 000000D3FBAC: 22021200
	v_add_nc_u32_e32 v2, s18, v2                               // 000000D3FBB0: 4A040412
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D3FBB4: BF870214
	v_add_nc_u32_e32 v3, s18, v3                               // 000000D3FBB8: 4A060612
	v_lshlrev_b32_e32 v10, 1, v87                              // 000000D3FBBC: 3014AE81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D3FBC0: BF870214
	v_add_nc_u32_e32 v5, s18, v1                               // 000000D3FBC4: 4A0A0212
	v_mad_i64_i32 v[1:2], null, 0x500, v2, 0                   // 000000D3FBC8: D6FF7C01 020204FF 00000500
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D3FBD4: BF870214
	v_mad_i64_i32 v[3:4], null, 0x500, v3, 0                   // 000000D3FBD8: D6FF7C03 020206FF 00000500
	.long 0xd700000f                                           // 000000D3FBE4: D700000F
	v_cndmask_b32_e32 v1, s10, v10, vcc_lo                     // 000000D3FBE8: 0202140A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D3FBEC: BF8701A4
	v_mad_i64_i32 v[5:6], null, 0x500, v5, 0                   // 000000D3FBF0: D6FF7C05 02020AFF 00000500
	v_add_co_ci_u32_e64 v16, null, s11, 0, s0                  // 000000D3FBFC: D5207C10 0001000B
	.long 0xd7006a0b                                           // 000000D3FC04: D7006A0B
	v_cndmask_b32_e32 v1, v15, v1, vcc_lo                      // 000000D3FC08: 0202030F
	.long 0xd44c0000                                           // 000000D3FC0C: D44C0000
	v_cndmask_b32_e32 v1, 0x300, v0, vcc_lo                    // 000000D3FC10: 020200FF 00000300
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D3FC18: BF8700A3
	v_add_co_ci_u32_e64 v12, null, v16, v2, vcc_lo             // 000000D3FC1C: D5207C0C 01AA0510
	.long 0xd7006a0d                                           // 000000D3FC24: D7006A0D
	v_cndmask_b32_e32 v1, v15, v3, vcc_lo                      // 000000D3FC28: 0202070F
	v_add_co_ci_u32_e64 v14, null, v16, v4, vcc_lo             // 000000D3FC2C: D5207C0E 01AA0910
	.long 0xd7006a0f                                           // 000000D3FC34: D7006A0F
	v_cndmask_b32_e32 v1, v15, v5, vcc_lo                      // 000000D3FC38: 02020B0F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D3FC3C: BF870001
	v_add_co_ci_u32_e64 v16, null, v16, v6, vcc_lo             // 000000D3FC40: D5207C10 01AA0D10
	s_clause 0x2                                               // 000000D3FC48: BF850002
	global_load_b128 v[49:52], v[11:12], off                   // 000000D3FC4C: DC5E0000 317C000B
	global_load_b128 v[53:56], v[13:14], off                   // 000000D3FC54: DC5E0000 357C000D
	global_load_b128 v[57:60], v[15:16], off                   // 000000D3FC5C: DC5E0000 397C000F
	s_and_saveexec_b32 s1, s0                                  // 000000D3FC64: BE812000
	s_cbranch_execz 6                                          // 000000D3FC68: BFA50006 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x3a84>
	v_mad_u32_u24 v11, 0x110, v7, v10                          // 000000D3FC6C: D60B000B 042A0EFF 00000110
	s_waitcnt vmcnt(2)                                         // 000000D3FC78: BF890BF7
	ds_store_b128 v11, v[49:52]                                // 000000D3FC7C: DB7C0000 0000310B
	s_or_b32 exec_lo, exec_lo, s1                              // 000000D3FC84: 8C7E017E
	.long 0xd44c0001                                           // 000000D3FC88: D44C0001
	v_cndmask_b32_e32 v1, 0x200, v0, vcc_lo                    // 000000D3FC8C: 020200FF 00000200
	s_and_saveexec_b32 s2, s1                                  // 000000D3FC94: BE822001
	s_cbranch_execz 6                                          // 000000D3FC98: BFA50006 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x3ab4>
	v_mad_u32_u24 v11, 0x110, v8, v10                          // 000000D3FC9C: D60B000B 042A10FF 00000110
	s_waitcnt vmcnt(1)                                         // 000000D3FCA8: BF8907F7
	ds_store_b128 v11, v[53:56]                                // 000000D3FCAC: DB7C0000 0000350B
	s_or_b32 exec_lo, exec_lo, s2                              // 000000D3FCB4: 8C7E027E
	.long 0xd44c0002                                           // 000000D3FCB8: D44C0002
	v_cndmask_b32_e32 v1, 0x100, v0, vcc_lo                    // 000000D3FCBC: 020200FF 00000100
	v_mul_u32_u24_e32 v90, 0x110, v9                           // 000000D3FCC4: 16B412FF 00000110
	s_and_saveexec_b32 s3, s2                                  // 000000D3FCCC: BE832002
	s_cbranch_execz 5                                          // 000000D3FCD0: BFA50005 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x3ae8>
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D3FCD4: BF870001
	v_add_nc_u32_e32 v9, v10, v90                              // 000000D3FCD8: 4A12B50A
	s_waitcnt vmcnt(0)                                         // 000000D3FCDC: BF8903F7
	ds_store_b128 v9, v[57:60]                                 // 000000D3FCE0: DB7C0000 00003909
	s_or_b32 exec_lo, exec_lo, s3                              // 000000D3FCE8: 8C7E037E
	v_and_b32_e32 v88, 31, v0                                  // 000000D3FCEC: 36B0009F
	s_mul_i32 s5, s16, 0xc8000                                 // 000000D3FCF0: 9605FF10 000C8000
	s_mul_i32 s13, s17, 0xa000                                 // 000000D3FCF8: 960DFF11 0000A000
	s_mul_hi_i32 s4, s16, 0xc8000                              // 000000D3FD00: 9704FF10 000C8000
	s_mul_hi_i32 s21, s17, 0xa000                              // 000000D3FD08: 9715FF11 0000A000
	v_dual_mov_b32 v18, 0 :: v_dual_lshlrev_b32 v9, 5, v88     // 000000D3FD10: CA220080 1208B085
	s_add_u32 s5, s5, s13                                      // 000000D3FD18: 80050D05
	s_addc_u32 s4, s4, s21                                     // 000000D3FD1C: 82041504
	v_and_b32_e32 v89, 15, v0                                  // 000000D3FD20: 36B2008F
	s_delay_alu instid0(VALU_DEP_2)                            // 000000D3FD24: BF870002
	v_add_nc_u32_e32 v10, 0x3f0, v9                            // 000000D3FD28: 4A1412FF 000003F0
	v_mul_u32_u24_e32 v91, 0x110, v7                           // 000000D3FD30: 16B60EFF 00000110
	v_cmp_ne_u32_e32 vcc_lo, 0, v88                            // 000000D3FD38: 7C9AB080
	v_mul_u32_u24_e32 v92, 0x110, v8                           // 000000D3FD3C: 16B810FF 00000110
	v_lshlrev_b32_e32 v8, 4, v89                               // 000000D3FD44: 3010B284
	v_lshrrev_b32_e32 v11, 5, v10                              // 000000D3FD48: 32161485
	v_mov_b32_e32 v21, v18                                     // 000000D3FD4C: 7E2A0312
	v_mov_b32_e32 v23, v18                                     // 000000D3FD50: 7E2E0312
	v_mov_b32_e32 v24, v18                                     // 000000D3FD54: 7E300312
	v_mov_b32_e32 v13, v18                                     // 000000D3FD58: 7E1A0312
	v_subrev_nc_u32_e32 v7, 32, v11                            // 000000D3FD5C: 4E0E16A0
	v_mov_b32_e32 v14, v18                                     // 000000D3FD60: 7E1C0312
	v_mov_b32_e32 v15, v18                                     // 000000D3FD64: 7E1E0312
	v_mov_b32_e32 v16, v18                                     // 000000D3FD68: 7E200312
	s_mov_b32 s12, 0                                           // 000000D3FD6C: BE8C0080
	v_cndmask_b32_e32 v17, 31, v7, vcc_lo                      // 000000D3FD70: 02220E9F
	.long 0xd7006a05                                           // 000000D3FD74: D7006A05
	v_cndmask_b32_e32 v1, v5, v8, vcc_lo                       // 000000D3FD78: 02021105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D3FD7C: BF870191
	v_add_co_ci_u32_e64 v6, null, 0, v6, vcc_lo                // 000000D3FD80: D5207C06 01AA0C80
	v_cmp_gt_i32_e32 vcc_lo, 31, v17                           // 000000D3FD88: 7C88229F
	v_dual_mov_b32 v20, v18 :: v_dual_and_b32 v7, 0x7e0, v10   // 000000D3FD8C: CA240112 140614FF 000007E0
	.long 0xd44c0003                                           // 000000D3FD98: D44C0003
	v_cndmask_b32_e32 v1, 16, v88, vcc_lo                      // 000000D3FD9C: 0202B090
	s_mov_b32 s13, 0xdcd12d                                    // 000000D3FDA0: BE8D00FF 00DCD12D
	v_cndmask_b32_e64 v10, 0xffffffe1, 1, vcc_lo               // 000000D3FDA8: D501000A 01A902FF FFFFFFE1
	.long 0xd7006a0b                                           // 000000D3FDB4: D7006A0B
	v_cndmask_b32_e32 v1, v3, v8, vcc_lo                       // 000000D3FDB8: 02021103
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D3FDBC: BF8700A1
	v_add_co_ci_u32_e64 v12, null, 0, v4, vcc_lo               // 000000D3FDC0: D5207C0C 01AA0880
	.long 0xd7006a05                                           // 000000D3FDC8: D7006A05
	v_cndmask_b32_e32 v1, s10, v5, vcc_lo                      // 000000D3FDCC: 02020A0A
	v_add_co_ci_u32_e64 v6, null, s11, v6, vcc_lo              // 000000D3FDD0: D5207C06 01AA0C0B
	v_sub_nc_u32_e32 v4, v7, v9                                // 000000D3FDD8: 4C081307
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D3FDDC: BF870223
	.long 0xd7006a3d                                           // 000000D3FDE0: D7006A3D
	v_cndmask_b32_e32 v1, 0x100, v5, vcc_lo                    // 000000D3FDE4: 02020AFF 00000100
	v_dual_mov_b32 v22, v18 :: v_dual_lshlrev_b32 v5, 2, v0    // 000000D3FDEC: CA220112 16040082
	v_add_co_ci_u32_e64 v62, null, 0, v6, vcc_lo               // 000000D3FDF4: D5207C3E 01AA0C80
	.long 0xd7006a07                                           // 000000D3FDFC: D7006A07
	v_cndmask_b32_e32 v1, s10, v11, vcc_lo                     // 000000D3FE00: 0202160A
	v_add_nc_u32_e32 v3, v10, v17                              // 000000D3FE04: 4A06230A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000D3FE08: BF8700D4
	v_and_or_b32 v10, 0x380, v5, s5                            // 000000D3FE0C: D657000A 00160AFF 00000380
	.long 0xd73c0005                                           // 000000D3FE18: D73C0005
	v_cndmask_b32_e32 v1, 2, v17, vcc_lo                       // 000000D3FE1C: 02022282
	v_add_co_ci_u32_e64 v9, null, s11, v12, vcc_lo             // 000000D3FE20: D5207C09 01AA180B
	v_mov_b32_e32 v11, s4                                      // 000000D3FE28: 7E160204
	.long 0xd7006a3f                                           // 000000D3FE2C: D7006A3F
	v_cndmask_b32_e32 v1, 0x100, v7, vcc_lo                    // 000000D3FE30: 02020EFF 00000100
	v_add_co_ci_u32_e64 v64, null, 0, v9, vcc_lo               // 000000D3FE38: D5207C40 01AA1280
	.long 0xd7006a05                                           // 000000D3FE40: D7006A05
	v_cndmask_b32_e32 v1, v10, v5, vcc_lo                      // 000000D3FE44: 02020B0A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D3FE48: BF870001
	v_add_co_ci_u32_e64 v6, null, v11, v6, vcc_lo              // 000000D3FE4C: D5207C06 01AA0D0B
	v_mov_b32_e32 v17, v18                                     // 000000D3FE54: 7E220312
	.long 0xd7006a01                                           // 000000D3FE58: D7006A01
	v_cndmask_b32_e32 v1, v1, v8, vcc_lo                       // 000000D3FE5C: 02021101
	v_dual_mov_b32 v19, v18 :: v_dual_add_nc_u32 v94, 0xfffffc30, v4// 000000D3FE60: CA200112 135E08FF FFFFFC30
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000D3FE6C: 3408069F
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 000000D3FE70: D5207C02 01AA0480
	.long 0xd7006a5f                                           // 000000D3FE78: D7006A5F
	v_cndmask_b32_e32 v1, s8, v5, vcc_lo                       // 000000D3FE7C: 02020A08
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D3FE80: BF8700A1
	v_add_co_ci_u32_e64 v96, null, s9, v6, vcc_lo              // 000000D3FE84: D5207C60 01AA0C09
	.long 0xd7006a05                                           // 000000D3FE8C: D7006A05
	v_cndmask_b32_e32 v1, s10, v1, vcc_lo                      // 000000D3FE90: 0202020A
	v_add_co_ci_u32_e64 v6, null, s11, v2, vcc_lo              // 000000D3FE94: D5207C06 01AA040B
	.long 0xd73c0001                                           // 000000D3FE9C: D73C0001
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 000000D3FEA0: 02020682
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D3FEA4: BF870093
	.long 0xd7006a41                                           // 000000D3FEA8: D7006A41
	v_cndmask_b32_e32 v1, 0x100, v5, vcc_lo                    // 000000D3FEAC: 02020AFF 00000100
	v_add_co_ci_u32_e64 v66, null, 0, v6, vcc_lo               // 000000D3FEB4: D5207C42 01AA0C80
	v_lshl_or_b32 v3, v88, 2, v10                              // 000000D3FEBC: D6560003 04290558
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D3FEC4: BF870094
	.long 0xd7006a01                                           // 000000D3FEC8: D7006A01
	v_cndmask_b32_e32 v1, v10, v1, vcc_lo                      // 000000D3FECC: 0202030A
	v_add_co_ci_u32_e64 v2, null, v11, v2, vcc_lo              // 000000D3FED0: D5207C02 01AA050B
	v_mov_b32_e32 v4, s4                                       // 000000D3FED8: 7E080204
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D3FEDC: BF870093
	.long 0xd7006a61                                           // 000000D3FEE0: D7006A61
	v_cndmask_b32_e32 v1, s8, v1, vcc_lo                       // 000000D3FEE4: 02020208
	v_add_co_ci_u32_e64 v98, null, s9, v2, vcc_lo              // 000000D3FEE8: D5207C62 01AA0409
	.long 0xd7006a63                                           // 000000D3FEF0: D7006A63
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 000000D3FEF4: 02020608
	v_mul_u32_u24_e32 v93, 0x110, v89                          // 000000D3FEF8: 16BAB2FF 00000110
	v_add_co_ci_u32_e64 v100, null, s9, v4, vcc_lo             // 000000D3FF00: D5207C64 01AA0809
	v_mov_b32_e32 v9, v18                                      // 000000D3FF08: 7E120312
	v_mov_b32_e32 v10, v18                                     // 000000D3FF0C: 7E140312
	v_mov_b32_e32 v11, v18                                     // 000000D3FF10: 7E160312
	v_mov_b32_e32 v12, v18                                     // 000000D3FF14: 7E180312
	v_mov_b32_e32 v1, v18                                      // 000000D3FF18: 7E020312
	v_mov_b32_e32 v2, v18                                      // 000000D3FF1C: 7E040312
	v_mov_b32_e32 v3, v18                                      // 000000D3FF20: 7E060312
	v_mov_b32_e32 v4, v18                                      // 000000D3FF24: 7E080312
	v_mov_b32_e32 v5, v18                                      // 000000D3FF28: 7E0A0312
	v_mov_b32_e32 v6, v18                                      // 000000D3FF2C: 7E0C0312
	v_mov_b32_e32 v7, v18                                      // 000000D3FF30: 7E0E0312
	v_mov_b32_e32 v8, v18                                      // 000000D3FF34: 7E100312
	s_mov_b64 s[4:5], 0                                        // 000000D3FF38: BE840180
	s_movk_i32 s21, 0x83                                       // 000000D3FF3C: B0150083
	s_movk_i32 s22, 0x1eee                                     // 000000D3FF40: B0161EEE
	s_mov_b32 s23, 0x76543210                                  // 000000D3FF44: BE9700FF 76543210
	s_movk_i32 s24, 0x60                                       // 000000D3FF4C: B0180060
	s_movk_i32 s25, 0x80                                       // 000000D3FF50: B0190080
	s_movk_i32 s26, 0xa0                                       // 000000D3FF54: B01A00A0
	s_movk_i32 s27, 0xc0                                       // 000000D3FF58: B01B00C0
	s_movk_i32 s28, 0xe0                                       // 000000D3FF5C: B01C00E0
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000D3FF60: BF890007
	s_barrier                                                  // 000000D3FF64: BFBD0000
	buffer_gl0_inv                                             // 000000D3FF68: E0AC0000 00000000
	s_branch 28                                                // 000000D3FF70: BFA0001C <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x3de4>
	s_or_b32 exec_lo, exec_lo, s29                             // 000000D3FF74: 8C7E1D7E
	.long 0xd7006a3d                                           // 000000D3FF78: D7006A3D
	v_cndmask_b32_e32 v1, 0x100, v61, vcc_lo                   // 000000D3FF7C: 02027AFF 00000100
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D3FF84: BF8700A1
	v_add_co_ci_u32_e64 v62, null, 0, v62, vcc_lo              // 000000D3FF88: D5207C3E 01AA7C80
	.long 0xd7006a3f                                           // 000000D3FF90: D7006A3F
	v_cndmask_b32_e32 v1, 0x100, v63, vcc_lo                   // 000000D3FF94: 02027EFF 00000100
	v_add_co_ci_u32_e64 v64, null, 0, v64, vcc_lo              // 000000D3FF9C: D5207C40 01AA8080
	.long 0xd7006a41                                           // 000000D3FFA4: D7006A41
	v_cndmask_b32_e32 v1, 0x100, v65, vcc_lo                   // 000000D3FFA8: 020282FF 00000100
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D3FFB0: BF870001
	v_add_co_ci_u32_e64 v66, null, 0, v66, vcc_lo              // 000000D3FFB4: D5207C42 01AA8480
	s_add_u32 s4, s4, 0x2000                                   // 000000D3FFBC: 8004FF04 00002000
	s_addc_u32 s5, s5, 0                                       // 000000D3FFC4: 82058005
	s_add_i32 s12, s12, 1                                      // 000000D3FFC8: 810C810C
	s_cmpk_eq_u32 s4, 0xa000                                   // 000000D3FFCC: B484A000
	s_waitcnt lgkmcnt(0)                                       // 000000D3FFD0: BF89FC07
	s_barrier                                                  // 000000D3FFD4: BFBD0000
	buffer_gl0_inv                                             // 000000D3FFD8: E0AC0000 00000000
	s_cbranch_scc1 1401                                        // 000000D3FFE0: BFA20579 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x53c8>
	s_cmpk_lg_u32 s4, 0x8000                                   // 000000D3FFE4: B5048000
	s_cselect_b32 s29, -1, 0                                   // 000000D3FFE8: 981D80C1
	s_cmpk_eq_u32 s4, 0x8000                                   // 000000D3FFEC: B4848000
	s_cbranch_scc1 6                                           // 000000D3FFF0: BFA20006 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x3e0c>
	global_load_b128 v[49:52], v[65:66], off                   // 000000D3FFF4: DC5E0000 317C0041
	global_load_b128 v[53:56], v[63:64], off                   // 000000D3FFFC: DC5E0000 357C003F
	global_load_b128 v[57:60], v[61:62], off                   // 000000D40004: DC5E0000 397C003D
	.long 0xd7006a19                                           // 000000D4000C: D7006A19
	v_cndmask_b32_e32 v0, v95, v4, vcc_lo                      // 000000D40010: 0200095F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D40014: BF8700A1
	v_add_co_ci_u32_e64 v26, null, s5, v96, vcc_lo             // 000000D40018: D5207C1A 01AAC005
	.long 0xd7006a1b                                           // 000000D40020: D7006A1B
	v_cndmask_b32_e32 v0, v97, v4, vcc_lo                      // 000000D40024: 02000961
	v_add_co_ci_u32_e64 v28, null, s5, v98, vcc_lo             // 000000D40028: D5207C1C 01AAC405
	.long 0xd7006a1d                                           // 000000D40030: D7006A1D
	v_cndmask_b32_e32 v0, v99, v4, vcc_lo                      // 000000D40034: 02000963
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D40038: BF8700A1
	v_add_co_ci_u32_e64 v30, null, s5, v100, vcc_lo            // 000000D4003C: D5207C1E 01AAC805
	.long 0xd7006a51                                           // 000000D40044: D7006A51
	v_cndmask_b32_e32 v1, 0x1000, v25, vcc_lo                  // 000000D40048: 020232FF 00001000
	v_add_co_ci_u32_e64 v82, null, 0, v26, vcc_lo              // 000000D40050: D5207C52 01AA3480
	.long 0xd7006a53                                           // 000000D40058: D7006A53
	v_cndmask_b32_e32 v1, 0x1000, v27, vcc_lo                  // 000000D4005C: 020236FF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D40064: BF8700A1
	v_add_co_ci_u32_e64 v84, null, 0, v28, vcc_lo              // 000000D40068: D5207C54 01AA3880
	.long 0xd7006a55                                           // 000000D40070: D7006A55
	v_cndmask_b32_e32 v1, 0x1000, v29, vcc_lo                  // 000000D40074: 02023AFF 00001000
	v_add_co_ci_u32_e64 v86, null, 0, v30, vcc_lo              // 000000D4007C: D5207C56 01AA3C80
	s_clause 0x17                                              // 000000D40084: BF850017
	global_load_b32 v68, v[25:26], off                         // 000000D40088: DC520000 447C0019
	global_load_b32 v67, v[27:28], off                         // 000000D40090: DC520000 437C001B
	global_load_b32 v101, v[29:30], off                        // 000000D40098: DC520000 657C001D
	global_load_b32 v70, v[25:26], off offset:1024             // 000000D400A0: DC520400 467C0019
	global_load_b32 v69, v[27:28], off offset:1024             // 000000D400A8: DC520400 457C001B
	global_load_b32 v102, v[29:30], off offset:1024            // 000000D400B0: DC520400 667C001D
	global_load_b32 v72, v[25:26], off offset:2048             // 000000D400B8: DC520800 487C0019
	global_load_b32 v71, v[27:28], off offset:2048             // 000000D400C0: DC520800 477C001B
	global_load_b32 v103, v[29:30], off offset:2048            // 000000D400C8: DC520800 677C001D
	global_load_b32 v73, v[27:28], off offset:3072             // 000000D400D0: DC520C00 497C001B
	global_load_b32 v74, v[25:26], off offset:3072             // 000000D400D8: DC520C00 4A7C0019
	global_load_b32 v105, v[29:30], off offset:3072            // 000000D400E0: DC520C00 697C001D
	global_load_b32 v80, v[81:82], off                         // 000000D400E8: DC520000 507C0051
	global_load_b32 v79, v[83:84], off                         // 000000D400F0: DC520000 4F7C0053
	global_load_b32 v104, v[85:86], off                        // 000000D400F8: DC520000 687C0055
	global_load_b32 v76, v[81:82], off offset:1024             // 000000D40100: DC520400 4C7C0051
	global_load_b32 v75, v[83:84], off offset:1024             // 000000D40108: DC520400 4B7C0053
	global_load_b32 v78, v[81:82], off offset:2048             // 000000D40110: DC520800 4E7C0051
	global_load_b32 v77, v[83:84], off offset:2048             // 000000D40118: DC520800 4D7C0053
	global_load_b32 v83, v[83:84], off offset:3072             // 000000D40120: DC520C00 537C0053
	global_load_b32 v84, v[81:82], off offset:3072             // 000000D40128: DC520C00 547C0051
	global_load_b32 v205, v[85:86], off offset:1024            // 000000D40130: DC520400 CD7C0055
	global_load_b32 v82, v[85:86], off offset:2048             // 000000D40138: DC520800 527C0055
	global_load_b32 v81, v[85:86], off offset:3072             // 000000D40140: DC520C00 517C0055
	s_bfe_i32 s30, s12, 0x10000                                // 000000D40148: 939EFF0C 00010000
	s_and_b32 s31, s12, 1                                      // 000000D40150: 8B1F810C
	s_and_b32 s33, s30, 0x4400                                 // 000000D40154: 8B21FF1E 00004400
	s_cmp_eq_u32 s31, 0                                        // 000000D4015C: BF06801F
	v_add_nc_u32_e32 v45, s33, v93                             // 000000D40160: 4A5ABA21
	s_cselect_b32 s30, -1, 0                                   // 000000D40164: 981E80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000D40168: BF870009
	s_and_b32 s31, s30, exec_lo                                // 000000D4016C: 8B1F7E1E
	s_cselect_b32 s31, 32, 0x4420                              // 000000D40170: 981FFFA0 00004420
	s_cselect_b32 s33, 64, 0x4440                              // 000000D40178: 9821FFC0 00004440
	s_cselect_b32 s34, s24, 0x4460                             // 000000D40180: 9822FF18 00004460
	v_add_nc_u32_e32 v107, s33, v93                            // 000000D40188: 4AD6BA21
	v_add_nc_u32_e32 v106, s34, v93                            // 000000D4018C: 4AD4BA22
	s_waitcnt vmcnt(22)                                        // 000000D40190: BF895BF7
	.long 0xd73d0043                                           // 000000D40194: D73D0043
	v_cndmask_b32_e32 v1, v94, v67, vcc_lo                     // 000000D40198: 0202875E
	s_waitcnt vmcnt(21)                                        // 000000D4019C: BF8957F7
	v_bfe_u32 v85, v101, 12, 16                                // 000000D401A0: D6100055 02411965
	v_mul_u32_u24_e32 v184, s13, v85                           // 000000D401A8: 1770AA0D
	v_mul_u32_u24_e32 v85, s21, v85                            // 000000D401AC: 16AAAA15
	s_waitcnt vmcnt(19)                                        // 000000D401B0: BF894FF7
	.long 0xd73d0044                                           // 000000D401B4: D73D0044
	v_cndmask_b32_e32 v1, v94, v69, vcc_lo                     // 000000D401B8: 02028B5E
	v_lshl_add_u32 v85, v85, 24, v184                          // 000000D401BC: D6460055 06E13155
	s_waitcnt vmcnt(16)                                        // 000000D401C4: BF8943F7
	.long 0xd73d0045                                           // 000000D401C8: D73D0045
	v_cndmask_b32_e32 v1, v94, v71, vcc_lo                     // 000000D401CC: 02028F5E
	v_bfe_u32 v86, v101, 8, 16                                 // 000000D401D0: D6100056 02411165
	s_waitcnt vmcnt(15)                                        // 000000D401D8: BF893FF7
	v_bfe_u32 v72, v103, 12, 16                                // 000000D401DC: D6100048 02411967
	s_waitcnt vmcnt(13)                                        // 000000D401E4: BF8937F7
	.long 0xd73d0046                                           // 000000D401E8: D73D0046
	v_cndmask_b32_e32 v1, v94, v73, vcc_lo                     // 000000D401EC: 0202935E
	s_waitcnt vmcnt(12)                                        // 000000D401F0: BF8933F7
	v_bfe_u32 v71, v105, 12, 16                                // 000000D401F4: D6100047 02411969
	v_bfe_u32 v74, v105, 4, 16                                 // 000000D401FC: D610004A 02410969
	v_mul_u32_u24_e32 v185, s13, v86                           // 000000D40204: 1772AC0D
	v_mul_u32_u24_e32 v86, s21, v86                            // 000000D40208: 16ACAC15
	v_mul_u32_u24_e32 v192, s13, v72                           // 000000D4020C: 1780900D
	v_mul_u32_u24_e32 v193, s21, v72                           // 000000D40210: 17829015
	v_mul_u32_u24_e32 v197, s13, v71                           // 000000D40214: 178A8E0D
	v_mul_u32_u24_e32 v198, s21, v71                           // 000000D40218: 178C8E15
	v_mul_u32_u24_e32 v200, s13, v74                           // 000000D4021C: 1790940D
	v_mul_u32_u24_e32 v74, s21, v74                            // 000000D40220: 16949415
	s_waitcnt vmcnt(10)                                        // 000000D40224: BF892BF7
	.long 0xd73d0047                                           // 000000D40228: D73D0047
	v_cndmask_b32_e32 v1, v94, v79, vcc_lo                     // 000000D4022C: 02029F5E
	v_lshl_add_u32 v86, v86, 24, v185                          // 000000D40230: D6460056 06E53156
	v_lshl_add_u32 v74, v74, 24, v200                          // 000000D40238: D646004A 0721314A
	v_sad_u8 v85, v85, 0, 0x6400                               // 000000D40240: D6220055 03FD0155 00006400
	v_bfe_u32 v183, v103, 4, 16                                // 000000D4024C: D61000B7 02410967
	v_bfe_u32 v182, v103, 8, 16                                // 000000D40254: D61000B6 02411167
	v_bfe_u32 v73, v105, 8, 16                                 // 000000D4025C: D6100049 02411169
	v_and_b32_e32 v105, 0xffff, v105                           // 000000D40264: 36D2D2FF 0000FFFF
	v_mul_u32_u24_e32 v195, s13, v183                          // 000000D4026C: 17876E0D
	v_mul_u32_u24_e32 v183, s21, v183                          // 000000D40270: 176F6E15
	v_mul_u32_u24_e32 v194, s13, v182                          // 000000D40274: 17856C0D
	v_mul_u32_u24_e32 v182, s21, v182                          // 000000D40278: 176D6C15
	v_mul_u32_u24_e32 v199, s13, v73                           // 000000D4027C: 178E920D
	v_mul_u32_u24_e32 v73, s21, v73                            // 000000D40280: 16929215
	v_mul_u32_u24_e32 v201, s13, v105                          // 000000D40284: 1792D20D
	v_mul_u32_u24_e32 v105, s21, v105                          // 000000D40288: 16D2D215
	v_bfe_u32 v72, v67, 12, 16                                 // 000000D4028C: D6100048 02411943
	v_lshl_add_u32 v183, v183, 24, v195                        // 000000D40294: D64600B7 070D31B7
	v_mul_u32_u24_e32 v195, s13, v72                           // 000000D4029C: 1786900D
	v_bfe_u32 v203, v67, 4, 16                                 // 000000D402A0: D61000CB 02410943
	v_lshl_add_u32 v182, v182, 24, v194                        // 000000D402A8: D64600B6 070931B6
	v_lshl_add_u32 v194, v198, 24, v197                        // 000000D402B0: D64600C2 071531C6
	v_lshl_add_u32 v73, v73, 24, v199                          // 000000D402B8: D6460049 071D3149
	v_lshl_add_u32 v105, v105, 24, v201                        // 000000D402C0: D6460069 07253169
	v_mul_u32_u24_e32 v72, s21, v72                            // 000000D402C8: 16909015
	v_mul_u32_u24_e32 v198, s13, v203                          // 000000D402CC: 178D960D
	v_mul_u32_u24_e32 v199, s21, v203                          // 000000D402D0: 178F9615
	v_sad_u8 v86, v86, 0, 0x6400                               // 000000D402D4: D6220056 03FD0156 00006400
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000D402E0: D622004A 03FD014A 00006400
	v_bfe_u32 v215, v71, 12, 16                                // 000000D402EC: D61000D7 02411947
	v_bfe_u32 v216, v71, 8, 16                                 // 000000D402F4: D61000D8 02411147
	v_bfe_u32 v217, v71, 4, 16                                 // 000000D402FC: D61000D9 02410947
	v_and_b32_e32 v218, 0xffff, v71                            // 000000D40304: 37B48EFF 0000FFFF
	v_lshl_add_u32 v71, v72, 24, v195                          // 000000D4030C: D6460047 070D3148
	v_lshl_add_u32 v195, v199, 24, v198                        // 000000D40314: D64600C3 071931C7
	v_and_b32_e32 v85, 0xffff, v85                             // 000000D4031C: 36AAAAFF 0000FFFF
	v_bfe_u32 v202, v67, 8, 16                                 // 000000D40324: D61000CA 02411143
	v_and_b32_e32 v67, 0xffff, v67                             // 000000D4032C: 368686FF 0000FFFF
	v_mul_u32_u24_e32 v200, s13, v67                           // 000000D40334: 1790860D
	v_mul_u32_u24_e32 v67, s21, v67                            // 000000D40338: 16868615
	v_sad_u8 v105, v105, 0, 0x6400                             // 000000D4033C: D6220069 03FD0169 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 000000D40348: BF870002
	v_lshl_add_u32 v67, v67, 24, v200                          // 000000D4034C: D6460043 07213143
	v_and_b32_e32 v74, 0xffff, v74                             // 000000D40354: 369494FF 0000FFFF
	v_sad_u8 v195, v195, 0, 0x6400                             // 000000D4035C: D62200C3 03FD01C3 00006400
	v_lshl_or_b32 v85, v86, 16, v85                            // 000000D40368: D6560055 05552156
	v_and_b32_e32 v103, 0xffff, v103                           // 000000D40370: 36CECEFF 0000FFFF
	v_sad_u8 v67, v67, 0, 0x6400                               // 000000D40378: D6220043 03FD0143 00006400
	v_lshl_or_b32 v74, v105, 16, v74                           // 000000D40384: D656004A 05292169
	v_and_b32_e32 v105, 0xffff, v195                           // 000000D4038C: 36D386FF 0000FFFF
	v_pk_fma_f16 v85, v85, s22, 0xc931 op_sel_hi:[1,0,0]       // 000000D40394: CC0E0055 0BFC2D55 0000C931
	v_add_nc_u32_e32 v108, s31, v93                            // 000000D403A0: 4AD8BA1F
	v_mul_u32_u24_e32 v196, s13, v103                          // 000000D403A4: 1788CE0D
	v_mul_u32_u24_e32 v103, s21, v103                          // 000000D403A8: 16CECE15
	v_lshl_or_b32 v67, v67, 16, v105                           // 000000D403AC: D6560043 05A52143
	v_mov_b32_e32 v105, v85                                    // 000000D403B4: 7ED20355
	ds_load_b128 v[109:112], v108                              // 000000D403B8: DBFC0000 6D00006C
	ds_load_b128 v[113:116], v108 offset:16                    // 000000D403C0: DBFC0010 7100006C
	ds_load_b128 v[117:120], v108 offset:4352                  // 000000D403C8: DBFC1100 7500006C
	ds_load_b128 v[121:124], v108 offset:4368                  // 000000D403D0: DBFC1110 7900006C
	ds_load_b128 v[125:128], v108 offset:8704                  // 000000D403D8: DBFC2200 7D00006C
	ds_load_b128 v[129:132], v108 offset:8720                  // 000000D403E0: DBFC2210 8100006C
	ds_load_b128 v[133:136], v107                              // 000000D403E8: DBFC0000 8500006B
	ds_load_b128 v[137:140], v107 offset:16                    // 000000D403F0: DBFC0010 8900006B
	ds_load_b128 v[141:144], v107 offset:4352                  // 000000D403F8: DBFC1100 8D00006B
	ds_load_b128 v[145:148], v107 offset:4368                  // 000000D40400: DBFC1110 9100006B
	ds_load_b128 v[149:152], v107 offset:8704                  // 000000D40408: DBFC2200 9500006B
	ds_load_b128 v[153:156], v107 offset:8720                  // 000000D40410: DBFC2210 9900006B
	ds_load_b128 v[157:160], v106                              // 000000D40418: DBFC0000 9D00006A
	ds_load_b128 v[161:164], v106 offset:16                    // 000000D40420: DBFC0010 A100006A
	ds_load_b128 v[165:168], v106 offset:4352                  // 000000D40428: DBFC1100 A500006A
	ds_load_b128 v[169:172], v106 offset:4368                  // 000000D40430: DBFC1110 A900006A
	ds_load_b128 v[173:176], v106 offset:8704                  // 000000D40438: DBFC2200 AD00006A
	ds_load_b128 v[177:180], v106 offset:8720                  // 000000D40440: DBFC2210 B100006A
	v_bfe_u32 v106, v101, 4, 16                                // 000000D40448: D610006A 02410965
	v_bfe_u32 v107, v102, 12, 16                               // 000000D40450: D610006B 02411966
	v_bfe_u32 v108, v102, 8, 16                                // 000000D40458: D610006C 02411166
	v_mul_u32_u24_e32 v186, s13, v106                          // 000000D40460: 1774D40D
	v_mul_u32_u24_e32 v106, s21, v106                          // 000000D40464: 16D4D415
	v_mul_u32_u24_e32 v188, s13, v107                          // 000000D40468: 1778D60D
	v_mul_u32_u24_e32 v107, s21, v107                          // 000000D4046C: 16D6D615
	v_mul_u32_u24_e32 v189, s13, v108                          // 000000D40470: 177AD80D
	v_mul_u32_u24_e32 v108, s21, v108                          // 000000D40474: 16D8D815
	v_lshl_add_u32 v106, v106, 24, v186                        // 000000D40478: D646006A 06E9316A
	v_lshl_add_u32 v107, v107, 24, v188                        // 000000D40480: D646006B 06F1316B
	v_lshl_add_u32 v103, v103, 24, v196                        // 000000D40488: D6460067 07113167
	v_sad_u8 v183, v183, 0, 0x6400                             // 000000D40490: D62200B7 03FD01B7 00006400
	v_lshl_add_u32 v108, v108, 24, v189                        // 000000D4049C: D646006C 06F5316C
	v_bfe_u32 v189, v69, 4, 16                                 // 000000D404A4: D61000BD 02410945
	v_mul_u32_u24_e32 v209, s13, v189                          // 000000D404AC: 17A37A0D
	v_mul_u32_u24_e32 v189, s21, v189                          // 000000D404B0: 177B7A15
	v_bfe_u32 v184, v68, 12, 16                                // 000000D404B4: D61000B8 02411944
	s_delay_alu instid0(VALU_DEP_2)                            // 000000D404BC: BF870002
	v_lshl_add_u32 v189, v189, 24, v209                        // 000000D404C0: D64600BD 074531BD
	v_pk_fma_f16 v209, v74, s22, 0xc931 op_sel_hi:[1,0,0]      // 000000D404C8: CC0E00D1 0BFC2D4A 0000C931
	v_and_b32_e32 v101, 0xffff, v101                           // 000000D404D4: 36CACAFF 0000FFFF
	v_mul_u32_u24_e32 v187, s13, v101                          // 000000D404DC: 1776CA0D
	v_mul_u32_u24_e32 v101, s21, v101                          // 000000D404E0: 16CACA15
	v_mul_u32_u24_e32 v201, s13, v184                          // 000000D404E4: 1793700D
	v_mul_u32_u24_e32 v184, s21, v184                          // 000000D404E8: 17717015
	v_lshl_add_u32 v101, v101, 24, v187                        // 000000D404EC: D6460065 06ED3165
	v_sad_u8 v106, v106, 0, 0x6400                             // 000000D404F4: D622006A 03FD016A 00006400
	v_sad_u8 v107, v107, 0, 0x6400                             // 000000D40500: D622006B 03FD016B 00006400
	v_sad_u8 v103, v103, 0, 0x6400                             // 000000D4050C: D6220067 03FD0167 00006400
	v_lshl_add_u32 v184, v184, 24, v201                        // 000000D40518: D64600B8 072531B8
	v_and_b32_e32 v183, 0xffff, v183                           // 000000D40520: 376F6EFF 0000FFFF
	v_bfe_u32 v185, v68, 8, 16                                 // 000000D40528: D61000B9 02411144
	v_mul_u32_u24_e32 v196, s13, v202                          // 000000D40530: 1789940D
	v_mul_u32_u24_e32 v197, s21, v202                          // 000000D40534: 178B9415
	v_mul_u32_u24_e32 v202, s13, v185                          // 000000D40538: 1795720D
	v_mul_u32_u24_e32 v185, s21, v185                          // 000000D4053C: 17737215
	v_sad_u8 v101, v101, 0, 0x6400                             // 000000D40540: D6220065 03FD0165 00006400
	v_sad_u8 v108, v108, 0, 0x6400                             // 000000D4054C: D622006C 03FD016C 00006400
	v_lshl_add_u32 v72, v197, 24, v196                         // 000000D40558: D6460048 071131C5
	v_lshl_add_u32 v185, v185, 24, v202                        // 000000D40560: D64600B9 072931B9
	v_and_b32_e32 v106, 0xffff, v106                           // 000000D40568: 36D4D4FF 0000FFFF
	v_and_b32_e32 v107, 0xffff, v107                           // 000000D40570: 36D6D6FF 0000FFFF
	v_sad_u8 v71, v71, 0, 0x6400                               // 000000D40578: D6220047 03FD0147 00006400
	v_sad_u8 v184, v184, 0, 0x6400                             // 000000D40584: D62200B8 03FD01B8 00006400
	v_lshl_or_b32 v103, v103, 16, v183                         // 000000D40590: D6560067 06DD2167
	v_bfe_u32 v181, v102, 4, 16                                // 000000D40598: D61000B5 02410966
	v_mul_u32_u24_e32 v190, s13, v181                          // 000000D405A0: 177D6A0D
	v_mul_u32_u24_e32 v181, s21, v181                          // 000000D405A4: 176B6A15
	v_sad_u8 v72, v72, 0, 0x6400                               // 000000D405A8: D6220048 03FD0148 00006400
	v_sad_u8 v185, v185, 0, 0x6400                             // 000000D405B4: D62200B9 03FD01B9 00006400
	v_lshl_or_b32 v86, v101, 16, v106                          // 000000D405C0: D6560056 05A92165
	v_lshl_or_b32 v101, v108, 16, v107                         // 000000D405C8: D6560065 05AD216C
	v_and_b32_e32 v71, 0xffff, v71                             // 000000D405D0: 368E8EFF 0000FFFF
	v_and_b32_e32 v107, 0xffff, v184                           // 000000D405D8: 36D770FF 0000FFFF
	v_pk_fma_f16 v103, v103, s22, 0xc931 op_sel_hi:[1,0,0]     // 000000D405E0: CC0E0067 0BFC2D67 0000C931
	v_lshl_add_u32 v181, v181, 24, v190                        // 000000D405EC: D64600B5 06F931B5
	v_and_b32_e32 v102, 0xffff, v102                           // 000000D405F4: 36CCCCFF 0000FFFF
	v_lshl_or_b32 v71, v72, 16, v71                            // 000000D405FC: D6560047 051D2148
	v_lshl_or_b32 v72, v185, 16, v107                          // 000000D40604: D6560048 05AD21B9
	v_mov_b32_e32 v185, v103                                   // 000000D4060C: 7F720367
	v_mul_u32_u24_e32 v191, s13, v102                          // 000000D40610: 177ECC0D
	v_mul_u32_u24_e32 v102, s21, v102                          // 000000D40614: 16CCCC15
	v_lshl_add_u32 v102, v102, 24, v191                        // 000000D40618: D6460066 06FD3166
	v_sad_u8 v181, v181, 0, 0x6400                             // 000000D40620: D62200B5 03FD01B5 00006400
	v_bfe_u32 v187, v69, 12, 16                                // 000000D4062C: D61000BB 02411945
	v_bfe_u32 v191, v70, 12, 16                                // 000000D40634: D61000BF 02411946
	v_mul_u32_u24_e32 v207, s13, v187                          // 000000D4063C: 179F760D
	v_mul_u32_u24_e32 v187, s21, v187                          // 000000D40640: 17777615
	v_mul_u32_u24_e32 v211, s13, v191                          // 000000D40644: 17A77E0D
	v_mul_u32_u24_e32 v191, s21, v191                          // 000000D40648: 177F7E15
	v_sad_u8 v102, v102, 0, 0x6400                             // 000000D4064C: D6220066 03FD0166 00006400
	v_sad_u8 v194, v194, 0, 0x6400                             // 000000D40658: D62200C2 03FD01C2 00006400
	v_lshl_add_u32 v187, v187, 24, v207                        // 000000D40664: D64600BB 073D31BB
	v_lshl_add_u32 v191, v191, 24, v211                        // 000000D4066C: D64600BF 074D31BF
	v_and_b32_e32 v181, 0xffff, v181                           // 000000D40674: 376B6AFF 0000FFFF
	v_bfe_u32 v186, v68, 4, 16                                 // 000000D4067C: D61000BA 02410944
	v_bfe_u32 v188, v69, 8, 16                                 // 000000D40684: D61000BC 02411145
	v_lshl_add_u32 v190, v193, 24, v192                        // 000000D4068C: D64600BE 070131C1
	v_bfe_u32 v192, v70, 8, 16                                 // 000000D40694: D61000C0 02411146
	v_mul_u32_u24_e32 v203, s13, v186                          // 000000D4069C: 1797740D
	v_mul_u32_u24_e32 v186, s21, v186                          // 000000D406A0: 17757415
	v_mul_u32_u24_e32 v208, s13, v188                          // 000000D406A4: 17A1780D
	v_mul_u32_u24_e32 v188, s21, v188                          // 000000D406A8: 17797815
	v_mul_u32_u24_e32 v212, s13, v192                          // 000000D406AC: 17A9800D
	v_mul_u32_u24_e32 v192, s21, v192                          // 000000D406B0: 17818015
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000D406B4: D6220049 03FD0149 00006400
	v_lshl_add_u32 v186, v186, 24, v203                        // 000000D406C0: D64600BA 072D31BA
	v_lshl_add_u32 v188, v188, 24, v208                        // 000000D406C8: D64600BC 074131BC
	v_lshl_add_u32 v192, v192, 24, v212                        // 000000D406D0: D64600C0 075131C0
	v_and_b32_e32 v194, 0xffff, v194                           // 000000D406D8: 378584FF 0000FFFF
	v_sad_u8 v187, v187, 0, 0x6400                             // 000000D406E0: D62200BB 03FD01BB 00006400
	v_sad_u8 v191, v191, 0, 0x6400                             // 000000D406EC: D62200BF 03FD01BF 00006400
	v_lshl_or_b32 v102, v102, 16, v181                         // 000000D406F8: D6560066 06D52166
	v_sad_u8 v186, v186, 0, 0x6400                             // 000000D40700: D62200BA 03FD01BA 00006400
	v_sad_u8 v188, v188, 0, 0x6400                             // 000000D4070C: D62200BC 03FD01BC 00006400
	v_sad_u8 v192, v192, 0, 0x6400                             // 000000D40718: D62200C0 03FD01C0 00006400
	v_lshl_or_b32 v73, v73, 16, v194                           // 000000D40724: D6560049 07092149
	v_and_b32_e32 v181, 0xffff, v187                           // 000000D4072C: 376B76FF 0000FFFF
	v_and_b32_e32 v183, 0xffff, v191                           // 000000D40734: 376F7EFF 0000FFFF
	v_pk_fma_f16 v102, v102, s22, 0xc931 op_sel_hi:[1,0,0]     // 000000D4073C: CC0E0066 0BFC2D66 0000C931
	v_and_b32_e32 v68, 0xffff, v68                             // 000000D40748: 368888FF 0000FFFF
	v_sad_u8 v190, v190, 0, 0x6400                             // 000000D40750: D62200BE 03FD01BE 00006400
	v_and_b32_e32 v108, 0xffff, v186                           // 000000D4075C: 36D974FF 0000FFFF
	v_pk_fma_f16 v186, v73, s22, 0xc931 op_sel_hi:[1,0,0]      // 000000D40764: CC0E00BA 0BFC2D49 0000C931
	v_lshl_or_b32 v73, v188, 16, v181                          // 000000D40770: D6560049 06D521BC
	v_lshl_or_b32 v74, v192, 16, v183                          // 000000D40778: D656004A 06DD21C0
	v_mov_b32_e32 v181, v102                                   // 000000D40780: 7F6A0366
	v_mul_u32_u24_e32 v206, s13, v68                           // 000000D40784: 179C880D
	v_mul_u32_u24_e32 v68, s21, v68                            // 000000D40788: 16888815
	v_lshl_add_u32 v68, v68, 24, v206                          // 000000D4078C: D6460044 07393144
	v_bfe_u32 v193, v70, 4, 16                                 // 000000D40794: D61000C1 02410946
	v_mul_u32_u24_e32 v196, s13, v215                          // 000000D4079C: 1789AE0D
	v_mul_u32_u24_e32 v197, s21, v215                          // 000000D407A0: 178BAE15
	v_mul_u32_u24_e32 v201, s21, v217                          // 000000D407A4: 1793B215
	v_sad_u8 v182, v182, 0, 0x6400                             // 000000D407A8: D62200B6 03FD01B6 00006400
	v_mul_u32_u24_e32 v213, s13, v193                          // 000000D407B4: 17AB820D
	v_mul_u32_u24_e32 v193, s21, v193                          // 000000D407B8: 17838215
	v_mul_u32_u24_e32 v200, s13, v217                          // 000000D407BC: 1791B20D
	v_sad_u8 v189, v189, 0, 0x6400                             // 000000D407C0: D62200BD 03FD01BD 00006400
	v_lshl_add_u32 v196, v197, 24, v196                        // 000000D407CC: D64600C4 071131C5
	v_lshl_add_u32 v197, v201, 24, v200                        // 000000D407D4: D64600C5 072131C9
	v_pk_fma_f16 v201, v74, s22, 0xc931 op_sel_hi:[1,0,0]      // 000000D407DC: CC0E00C9 0BFC2D4A 0000C931
	v_and_b32_e32 v190, 0xffff, v190                           // 000000D407E8: 377D7CFF 0000FFFF
	v_lshl_add_u32 v193, v193, 24, v213                        // 000000D407F0: D64600C1 075531C1
	v_sad_u8 v68, v68, 0, 0x6400                               // 000000D407F8: D6220044 03FD0144 00006400
	v_and_b32_e32 v69, 0xffff, v69                             // 000000D40804: 368A8AFF 0000FFFF
	v_and_b32_e32 v70, 0xffff, v70                             // 000000D4080C: 368C8CFF 0000FFFF
	v_mul_u32_u24_e32 v210, s13, v69                           // 000000D40814: 17A48A0D
	v_mul_u32_u24_e32 v69, s21, v69                            // 000000D40818: 168A8A15
	v_pk_fma_f16 v101, v101, s22, 0xc931 op_sel_hi:[1,0,0]     // 000000D4081C: CC0E0065 0BFC2D65 0000C931
	v_mov_b32_e32 v215, v201                                   // 000000D40828: 7FAE03C9
	v_lshl_or_b32 v106, v182, 16, v190                         // 000000D4082C: D656006A 06F921B6
	v_dual_mov_b32 v189, v186 :: v_dual_and_b32 v182, 0xffff, v189// 000000D40834: CA2401BA BDB77AFF 0000FFFF
	v_mul_u32_u24_e32 v214, s13, v70                           // 000000D40840: 17AC8C0D
	v_mul_u32_u24_e32 v70, s21, v70                            // 000000D40844: 168C8C15
	v_lshl_add_u32 v69, v69, 24, v210                          // 000000D40848: D6460045 07493145
	v_lshl_add_u32 v70, v70, 24, v214                          // 000000D40850: D6460046 07593146
	v_sad_u8 v193, v193, 0, 0x6400                             // 000000D40858: D62200C1 03FD01C1 00006400
	v_pk_fma_f16 v86, v86, s22, 0xc931 op_sel_hi:[1,0,0]       // 000000D40864: CC0E0056 0BFC2D56 0000C931
	v_lshl_or_b32 v68, v68, 16, v108                           // 000000D40870: D6560044 05B12144
	v_pk_fma_f16 v71, v71, s22, 0xc931 op_sel_hi:[1,0,0]       // 000000D40878: CC0E0047 0BFC2D47 0000C931
	v_pk_fma_f16 v190, v67, s22, 0xc931 op_sel_hi:[1,0,0]      // 000000D40884: CC0E00BE 0BFC2D43 0000C931
	v_mov_b32_e32 v108, v101                                   // 000000D40890: 7ED80365
	ds_load_b128 v[25:28], v45                                 // 000000D40894: DBFC0000 1900002D
	ds_load_b128 v[29:32], v45 offset:16                       // 000000D4089C: DBFC0010 1D00002D
	ds_load_b128 v[33:36], v45 offset:4352                     // 000000D408A4: DBFC1100 2100002D
	ds_load_b128 v[37:40], v45 offset:4368                     // 000000D408AC: DBFC1110 2500002D
	ds_load_b128 v[41:44], v45 offset:8704                     // 000000D408B4: DBFC2200 2900002D
	ds_load_b128 v[45:48], v45 offset:8720                     // 000000D408BC: DBFC2210 2D00002D
	v_sad_u8 v69, v69, 0, 0x6400                               // 000000D408C4: D6220045 03FD0145 00006400
	v_sad_u8 v70, v70, 0, 0x6400                               // 000000D408D0: D6220046 03FD0146 00006400
	v_dual_mov_b32 v107, v86 :: v_dual_and_b32 v184, 0xffff, v193// 000000D408DC: CA240156 6BB982FF 0000FFFF
	v_pk_fma_f16 v193, v72, s22, 0xc931 op_sel_hi:[1,0,0]      // 000000D408E8: CC0E00C1 0BFC2D48 0000C931
	v_pk_fma_f16 v194, v68, s22, 0xc931 op_sel_hi:[1,0,0]      // 000000D408F4: CC0E00C2 0BFC2D44 0000C931
	v_mov_b32_e32 v68, v71                                     // 000000D40900: 7E880347
	v_mov_b32_e32 v72, v190                                    // 000000D40904: 7E9003BE
	v_lshl_or_b32 v69, v69, 16, v182                           // 000000D40908: D6560045 06D92145
	v_lshl_or_b32 v70, v70, 16, v184                           // 000000D40910: D6560046 06E12146
	v_permlanex16_b32 v105, v105, s23, 0xfedcba98              // 000000D40918: D65C0069 03FC2F69 FEDCBA98
	v_permlanex16_b32 v107, v107, s23, 0xfedcba98              // 000000D40924: D65C006B 03FC2F6B FEDCBA98
	v_permlanex16_b32 v68, v68, s23, 0xfedcba98                // 000000D40930: D65C0044 03FC2F44 FEDCBA98
	v_permlanex16_b32 v72, v72, s23, 0xfedcba98                // 000000D4093C: D65C0048 03FC2F48 FEDCBA98
	v_mul_u32_u24_e32 v198, s13, v216                          // 000000D40948: 178DB00D
	v_mul_u32_u24_e32 v199, s21, v216                          // 000000D4094C: 178FB015
	v_lshl_add_u32 v206, v199, 24, v198                        // 000000D40950: D64600CE 071931C7
	v_sad_u8 v208, v197, 0, 0x6400                             // 000000D40958: D62200D0 03FD01C5 00006400
	v_pk_fma_f16 v197, v73, s22, 0xc931 op_sel_hi:[1,0,0]      // 000000D40964: CC0E00C5 0BFC2D49 0000C931
	v_pk_fma_f16 v198, v69, s22, 0xc931 op_sel_hi:[1,0,0]      // 000000D40970: CC0E00C6 0BFC2D45 0000C931
	v_pk_fma_f16 v202, v70, s22, 0xc931 op_sel_hi:[1,0,0]      // 000000D4097C: CC0E00CA 0BFC2D46 0000C931
	v_cndmask_b32_e64 v69, v105, v85, s3                       // 000000D40988: D5010045 000EAB69
	v_cndmask_b32_e64 v73, v85, v105, s3                       // 000000D40990: D5010049 000ED355
	v_cndmask_b32_e64 v70, v107, v86, s3                       // 000000D40998: D5010046 000EAD6B
	v_cndmask_b32_e64 v74, v86, v107, s3                       // 000000D409A0: D501004A 000ED756
	v_cndmask_b32_e64 v67, v68, v71, s3                        // 000000D409A8: D5010043 000E8F44
	v_cndmask_b32_e64 v71, v71, v68, s3                        // 000000D409B0: D5010047 000E8947
	v_cndmask_b32_e64 v68, v72, v190, s3                       // 000000D409B8: D5010044 000F7D48
	v_cndmask_b32_e64 v72, v190, v72, s3                       // 000000D409C0: D5010048 000E91BE
	s_waitcnt vmcnt(9)                                         // 000000D409C8: BF8927F7
	v_bfe_u32 v79, v104, 12, 16                                // 000000D409CC: D610004F 02411968
	v_mov_b32_e32 v211, v193                                   // 000000D409D4: 7FA603C1
	v_bfe_u32 v204, v104, 4, 16                                // 000000D409D8: D61000CC 02410968
	v_bfe_u32 v80, v104, 8, 16                                 // 000000D409E0: D6100050 02411168
	s_waitcnt lgkmcnt(4)                                       // 000000D409E8: BF89FC47
	v_wmma_f32_16x16x16_f16 v[17:24], v[67:74], v[25:32], v[17:24]// 000000D409EC: CC404011 1C463343
	v_mul_u32_u24_e32 v31, s13, v79                            // 000000D409F4: 163E9E0D
	v_mul_u32_u24_e32 v32, s21, v79                            // 000000D409F8: 16409E15
	v_lshl_add_u32 v31, v32, 24, v31                           // 000000D409FC: D646001F 047D3120
	v_mul_u32_u24_e32 v29, s13, v218                           // 000000D40A04: 163BB40D
	v_mul_u32_u24_e32 v30, s21, v218                           // 000000D40A08: 163DB415
	v_lshl_add_u32 v29, v30, 24, v29                           // 000000D40A0C: D646001D 0475311E
	v_mul_u32_u24_e32 v30, s13, v204                           // 000000D40A14: 163D980D
	v_mul_u32_u24_e32 v32, s21, v204                           // 000000D40A18: 16419815
	v_lshl_add_u32 v30, v32, 24, v30                           // 000000D40A1C: D646001E 04793120
	v_mul_u32_u24_e32 v32, s13, v80                            // 000000D40A24: 1640A00D
	v_sad_u8 v207, v196, 0, 0x6400                             // 000000D40A28: D62200CF 03FD01C4 00006400
	s_waitcnt lgkmcnt(2)                                       // 000000D40A34: BF89FC27
	v_wmma_f32_16x16x16_f16 v[9:16], v[67:74], v[33:40], v[9:16]// 000000D40A38: CC404009 1C264343
	v_sad_u8 v31, v31, 0, 0x6400                               // 000000D40A40: D622001F 03FD011F 00006400
	v_mul_u32_u24_e32 v33, s21, v80                            // 000000D40A4C: 1642A015
	v_lshl_add_u32 v32, v33, 24, v32                           // 000000D40A50: D6460020 04813121
	v_and_b32_e32 v25, 0xffff, v104                            // 000000D40A58: 3632D0FF 0000FFFF
	v_mul_u32_u24_e32 v33, s13, v25                            // 000000D40A60: 1642320D
	v_mul_u32_u24_e32 v25, s21, v25                            // 000000D40A64: 16323215
	v_pk_fma_f16 v106, v106, s22, 0xc931 op_sel_hi:[1,0,0]     // 000000D40A68: CC0E006A 0BFC2D6A 0000C931
	v_sad_u8 v30, v30, 0, 0x6400                               // 000000D40A74: D622001E 03FD011E 00006400
	v_lshl_add_u32 v25, v25, 24, v33                           // 000000D40A80: D6460019 04853119
	v_and_b32_e32 v26, 0xffff, v207                            // 000000D40A88: 36359EFF 0000FFFF
	v_sad_u8 v27, v206, 0, 0x6400                              // 000000D40A90: D622001B 03FD01CE 00006400
	v_and_b32_e32 v28, 0xffff, v208                            // 000000D40A9C: 3639A0FF 0000FFFF
	v_sad_u8 v29, v29, 0, 0x6400                               // 000000D40AA4: D622001D 03FD011D 00006400
	v_and_b32_e32 v31, 0xffff, v31                             // 000000D40AB0: 363E3EFF 0000FFFF
	v_sad_u8 v32, v32, 0, 0x6400                               // 000000D40AB8: D6220020 03FD0120 00006400
	v_mov_b32_e32 v182, v106                                   // 000000D40AC4: 7F6C036A
	v_mov_b32_e32 v212, v194                                   // 000000D40AC8: 7FA803C2
	v_and_b32_e32 v30, 0xffff, v30                             // 000000D40ACC: 363C3CFF 0000FFFF
	v_sad_u8 v25, v25, 0, 0x6400                               // 000000D40AD4: D6220019 03FD0119 00006400
	v_lshl_or_b32 v26, v27, 16, v26                            // 000000D40AE0: D656001A 0469211B
	v_lshl_or_b32 v27, v29, 16, v28                            // 000000D40AE8: D656001B 0471211D
	v_lshl_or_b32 v28, v32, 16, v31                            // 000000D40AF0: D656001C 047D2120
	s_waitcnt vmcnt(7)                                         // 000000D40AF8: BF891FF7
	.long 0xd73d0020                                           // 000000D40AFC: D73D0020
	v_cndmask_b32_e32 v1, v94, v75, vcc_lo                     // 000000D40B00: 0202975E
	v_permlanex16_b32 v108, v108, s23, 0xfedcba98              // 000000D40B04: D65C006C 03FC2F6C FEDCBA98
	v_permlanex16_b32 v185, v185, s23, 0xfedcba98              // 000000D40B10: D65C00B9 03FC2FB9 FEDCBA98
	v_permlanex16_b32 v181, v181, s23, 0xfedcba98              // 000000D40B1C: D65C00B5 03FC2FB5 FEDCBA98
	v_permlanex16_b32 v182, v182, s23, 0xfedcba98              // 000000D40B28: D65C00B6 03FC2FB6 FEDCBA98
	v_permlanex16_b32 v189, v189, s23, 0xfedcba98              // 000000D40B34: D65C00BD 03FC2FBD FEDCBA98
	v_dual_mov_b32 v213, v197 :: v_dual_mov_b32 v214, v198     // 000000D40B40: CA1001C5 D5D601C6
	v_permlanex16_b32 v211, v211, s23, 0xfedcba98              // 000000D40B48: D65C00D3 03FC2FD3 FEDCBA98
	v_permlanex16_b32 v212, v212, s23, 0xfedcba98              // 000000D40B54: D65C00D4 03FC2FD4 FEDCBA98
	v_lshl_or_b32 v25, v25, 16, v30                            // 000000D40B60: D6560019 04792119
	s_cselect_b32 s31, s25, 0x4480                             // 000000D40B68: 981FFF19 00004480
	v_cndmask_b32_e64 v183, v108, v101, s3                     // 000000D40B70: D50100B7 000ECB6C
	v_cndmask_b32_e64 v187, v101, v108, s3                     // 000000D40B78: D50100BB 000ED965
	v_bfe_u32 v101, v32, 4, 16                                 // 000000D40B80: D6100065 02410920
	v_cndmask_b32_e64 v192, v185, v103, s3                     // 000000D40B88: D50100C0 000ECFB9
	v_cndmask_b32_e64 v196, v103, v185, s3                     // 000000D40B90: D50100C4 000F7367
	s_waitcnt lgkmcnt(0)                                       // 000000D40B98: BF89FC07
	v_wmma_f32_16x16x16_f16 v[1:8], v[67:74], v[41:48], v[1:8] // 000000D40B9C: CC404001 1C065343
	v_add_nc_u32_e32 v71, s31, v93                             // 000000D40BA4: 4A8EBA1F
	v_bfe_u32 v75, v32, 12, 16                                 // 000000D40BA8: D610004B 02411920
	s_waitcnt vmcnt(2)                                         // 000000D40BB0: BF890BF7
	v_bfe_u32 v76, v205, 12, 16                                // 000000D40BB4: D610004C 024119CD
	v_mul_u32_u24_e32 v103, s13, v101                          // 000000D40BBC: 16CECA0D
	v_mul_u32_u24_e32 v101, s21, v101                          // 000000D40BC0: 16CACA15
	v_mov_b32_e32 v210, v209                                   // 000000D40BC4: 7FA403D1
	v_mov_b32_e32 v216, v202                                   // 000000D40BC8: 7FB003CA
	v_cndmask_b32_e64 v184, v181, v102, s3                     // 000000D40BCC: D50100B8 000ECDB5
	v_cndmask_b32_e64 v188, v102, v181, s3                     // 000000D40BD4: D50100BC 000F6B66
	v_cndmask_b32_e64 v191, v182, v106, s3                     // 000000D40BDC: D50100BF 000ED5B6
	v_cndmask_b32_e64 v195, v106, v182, s3                     // 000000D40BE4: D50100C3 000F6D6A
	v_cndmask_b32_e64 v199, v189, v186, s3                     // 000000D40BEC: D50100C7 000F75BD
	v_cndmask_b32_e64 v203, v186, v189, s3                     // 000000D40BF4: D50100CB 000F7BBA
	v_permlanex16_b32 v213, v213, s23, 0xfedcba98              // 000000D40BFC: D65C00D5 03FC2FD5 FEDCBA98
	v_permlanex16_b32 v214, v214, s23, 0xfedcba98              // 000000D40C08: D65C00D6 03FC2FD6 FEDCBA98
	v_cndmask_b32_e64 v181, v211, v193, s3                     // 000000D40C14: D50100B5 000F83D3
	v_cndmask_b32_e64 v185, v193, v211, s3                     // 000000D40C1C: D50100B9 000FA7C1
	v_cndmask_b32_e64 v182, v212, v194, s3                     // 000000D40C24: D50100B6 000F85D4
	v_cndmask_b32_e64 v186, v194, v212, s3                     // 000000D40C2C: D50100BA 000FA9C2
	v_pk_fma_f16 v26, v26, s22, 0xc931 op_sel_hi:[1,0,0]       // 000000D40C34: CC0E001A 0BFC2D1A 0000C931
	v_pk_fma_f16 v27, v27, s22, 0xc931 op_sel_hi:[1,0,0]       // 000000D40C40: CC0E001B 0BFC2D1B 0000C931
	v_pk_fma_f16 v28, v28, s22, 0xc931 op_sel_hi:[1,0,0]       // 000000D40C4C: CC0E001C 0BFC2D1C 0000C931
	v_pk_fma_f16 v79, v25, s22, 0xc931 op_sel_hi:[1,0,0]       // 000000D40C58: CC0E004F 0BFC2D19 0000C931
	v_mul_u32_u24_e32 v102, s13, v75                           // 000000D40C64: 16CC960D
	v_mul_u32_u24_e32 v75, s21, v75                            // 000000D40C68: 16969615
	v_lshl_add_u32 v101, v101, 24, v103                        // 000000D40C6C: D6460065 059D3165
	v_mul_u32_u24_e32 v105, s13, v76                           // 000000D40C74: 16D2980D
	v_mul_u32_u24_e32 v76, s21, v76                            // 000000D40C78: 16989815
	v_lshl_add_u32 v75, v75, 24, v102                          // 000000D40C7C: D646004B 0599314B
	v_lshl_add_u32 v76, v76, 24, v105                          // 000000D40C84: D646004C 05A5314C
	v_bfe_u32 v85, v32, 8, 16                                  // 000000D40C8C: D6100055 02411120
	v_and_b32_e32 v32, 0xffff, v32                             // 000000D40C94: 364040FF 0000FFFF
	v_bfe_u32 v102, v205, 4, 16                                // 000000D40C9C: D6100066 024109CD
	v_mul_u32_u24_e32 v104, s13, v32                           // 000000D40CA4: 16D0400D
	v_mul_u32_u24_e32 v32, s21, v32                            // 000000D40CA8: 16404015
	ds_load_b128 v[33:36], v71                                 // 000000D40CAC: DBFC0000 21000047
	ds_load_b128 v[37:40], v71 offset:16                       // 000000D40CB4: DBFC0010 25000047
	ds_load_b128 v[41:44], v71 offset:4352                     // 000000D40CBC: DBFC1100 29000047
	ds_load_b128 v[45:48], v71 offset:4368                     // 000000D40CC4: DBFC1110 2D000047
	ds_load_b128 v[67:70], v71 offset:8704                     // 000000D40CCC: DBFC2200 43000047
	ds_load_b128 v[71:74], v71 offset:8720                     // 000000D40CD4: DBFC2210 47000047
	v_bfe_u32 v86, v205, 8, 16                                 // 000000D40CDC: D6100056 024111CD
	v_lshl_add_u32 v32, v32, 24, v104                          // 000000D40CE4: D6460020 05A13120
	v_mul_u32_u24_e32 v104, s13, v102                          // 000000D40CEC: 16D0CC0D
	v_mul_u32_u24_e32 v102, s21, v102                          // 000000D40CF0: 16CCCC15
	v_permlanex16_b32 v210, v210, s23, 0xfedcba98              // 000000D40CF4: D65C00D2 03FC2FD2 FEDCBA98
	v_permlanex16_b32 v215, v215, s23, 0xfedcba98              // 000000D40D00: D65C00D7 03FC2FD7 FEDCBA98
	v_permlanex16_b32 v216, v216, s23, 0xfedcba98              // 000000D40D0C: D65C00D8 03FC2FD8 FEDCBA98
	v_cndmask_b32_e64 v189, v213, v197, s3                     // 000000D40D18: D50100BD 000F8BD5
	v_cndmask_b32_e64 v193, v197, v213, s3                     // 000000D40D20: D50100C1 000FABC5
	v_cndmask_b32_e64 v190, v214, v198, s3                     // 000000D40D28: D50100BE 000F8DD6
	v_cndmask_b32_e64 v194, v198, v214, s3                     // 000000D40D30: D50100C2 000FADC6
	v_wmma_f32_16x16x16_f16 v[17:24], v[181:188], v[109:116], v[17:24]// 000000D40D38: CC404011 1C46DBB5
	v_dual_mov_b32 v29, v26 :: v_dual_mov_b32 v30, v27         // 000000D40D40: CA10011A 1D1E011B
	v_dual_mov_b32 v31, v28 :: v_dual_mov_b32 v80, v79         // 000000D40D48: CA10011C 1F50014F
	v_mul_u32_u24_e32 v103, s13, v85                           // 000000D40D50: 16CEAA0D
	v_mul_u32_u24_e32 v85, s21, v85                            // 000000D40D54: 16AAAA15
	v_sad_u8 v101, v101, 0, 0x6400                             // 000000D40D58: D6220065 03FD0165 00006400
	v_lshl_add_u32 v102, v102, 24, v104                        // 000000D40D64: D6460066 05A13166
	v_mul_u32_u24_e32 v104, s13, v86                           // 000000D40D6C: 16D0AC0D
	v_mul_u32_u24_e32 v86, s21, v86                            // 000000D40D70: 16ACAC15
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000D40D74: D622004B 03FD014B 00006400
	v_lshl_add_u32 v85, v85, 24, v103                          // 000000D40D80: D6460055 059D3155
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000D40D88: D622004C 03FD014C 00006400
	v_lshl_add_u32 v86, v86, 24, v104                          // 000000D40D94: D6460056 05A13156
	v_and_b32_e32 v103, 0xffff, v205                           // 000000D40D9C: 36CF9AFF 0000FFFF
	v_mul_u32_u24_e32 v104, s13, v103                          // 000000D40DA4: 16D0CE0D
	v_mul_u32_u24_e32 v103, s21, v103                          // 000000D40DA8: 16CECE15
	v_cndmask_b32_e64 v200, v210, v209, s3                     // 000000D40DAC: D50100C8 000FA3D2
	v_cndmask_b32_e64 v197, v215, v201, s3                     // 000000D40DB4: D50100C5 000F93D7
	v_cndmask_b32_e64 v201, v201, v215, s3                     // 000000D40DBC: D50100C9 000FAFC9
	v_cndmask_b32_e64 v198, v216, v202, s3                     // 000000D40DC4: D50100C6 000F95D8
	v_cndmask_b32_e64 v202, v202, v216, s3                     // 000000D40DCC: D50100CA 000FB1CA
	v_wmma_f32_16x16x16_f16 v[17:24], v[189:196], v[133:140], v[17:24]// 000000D40DD4: CC404011 1C470BBD
	v_cndmask_b32_e64 v204, v209, v210, s3                     // 000000D40DDC: D50100CC 000FA5D1
	v_permlanex16_b32 v29, v29, s23, 0xfedcba98                // 000000D40DE4: D65C001D 03FC2F1D FEDCBA98
	v_permlanex16_b32 v30, v30, s23, 0xfedcba98                // 000000D40DF0: D65C001E 03FC2F1E FEDCBA98
	v_permlanex16_b32 v31, v31, s23, 0xfedcba98                // 000000D40DFC: D65C001F 03FC2F1F FEDCBA98
	v_permlanex16_b32 v80, v80, s23, 0xfedcba98                // 000000D40E08: D65C0050 03FC2F50 FEDCBA98
	v_and_b32_e32 v101, 0xffff, v101                           // 000000D40E14: 36CACAFF 0000FFFF
	v_lshl_add_u32 v103, v103, 24, v104                        // 000000D40E1C: D6460067 05A13167
	v_sad_u8 v104, v32, 0, 0x6400                              // 000000D40E24: D6220068 03FD0120 00006400
	v_and_b32_e32 v75, 0xffff, v75                             // 000000D40E30: 369696FF 0000FFFF
	v_sad_u8 v85, v85, 0, 0x6400                               // 000000D40E38: D6220055 03FD0155 00006400
	v_and_b32_e32 v76, 0xffff, v76                             // 000000D40E44: 369898FF 0000FFFF
	v_sad_u8 v86, v86, 0, 0x6400                               // 000000D40E4C: D6220056 03FD0156 00006400
	v_wmma_f32_16x16x16_f16 v[17:24], v[197:204], v[157:164], v[17:24]// 000000D40E58: CC404011 1C473BC5
	v_cndmask_b32_e64 v25, v29, v26, s3                        // 000000D40E60: D5010019 000E351D
	v_cndmask_b32_e64 v29, v26, v29, s3                        // 000000D40E68: D501001D 000E3B1A
	v_cndmask_b32_e64 v26, v30, v27, s3                        // 000000D40E70: D501001A 000E371E
	v_cndmask_b32_e64 v30, v27, v30, s3                        // 000000D40E78: D501001E 000E3D1B
	v_cndmask_b32_e64 v27, v31, v28, s3                        // 000000D40E80: D501001B 000E391F
	v_cndmask_b32_e64 v31, v28, v31, s3                        // 000000D40E88: D501001F 000E3F1C
	v_cndmask_b32_e64 v28, v80, v79, s3                        // 000000D40E90: D501001C 000E9F50
	v_cndmask_b32_e64 v32, v79, v80, s3                        // 000000D40E98: D5010020 000EA14F
	v_lshl_or_b32 v79, v104, 16, v101                          // 000000D40EA0: D656004F 05952168
	v_wmma_f32_16x16x16_f16 v[1:8], v[181:188], v[125:132], v[1:8]// 000000D40EA8: CC404001 1C06FBB5
	v_lshl_or_b32 v75, v85, 16, v75                            // 000000D40EB0: D656004B 052D2155
	v_lshl_or_b32 v76, v86, 16, v76                            // 000000D40EB8: D656004C 05312156
	v_wmma_f32_16x16x16_f16 v[9:16], v[181:188], v[117:124], v[9:16]// 000000D40EC0: CC404009 1C26EBB5
	s_waitcnt lgkmcnt(4)                                       // 000000D40EC8: BF89FC47
	v_wmma_f32_16x16x16_f16 v[17:24], v[25:32], v[33:40], v[17:24]// 000000D40ECC: CC404011 1C464319
	v_pk_fma_f16 v33, v79, s22, 0xc931 op_sel_hi:[1,0,0]       // 000000D40ED4: CC0E0021 0BFC2D4F 0000C931
	v_wmma_f32_16x16x16_f16 v[1:8], v[189:196], v[149:156], v[1:8]// 000000D40EE0: CC404001 1C072BBD
	v_sad_u8 v102, v102, 0, 0x6400                             // 000000D40EE8: D6220066 03FD0166 00006400
	v_pk_fma_f16 v75, v75, s22, 0xc931 op_sel_hi:[1,0,0]       // 000000D40EF4: CC0E004B 0BFC2D4B 0000C931
	v_pk_fma_f16 v34, v76, s22, 0xc931 op_sel_hi:[1,0,0]       // 000000D40F00: CC0E0022 0BFC2D4C 0000C931
	v_wmma_f32_16x16x16_f16 v[9:16], v[189:196], v[141:148], v[9:16]// 000000D40F0C: CC404009 1C271BBD
	v_mov_b32_e32 v36, v33                                     // 000000D40F14: 7E480321
	v_wmma_f32_16x16x16_f16 v[1:8], v[197:204], v[173:180], v[1:8]// 000000D40F18: CC404001 1C075BC5
	v_and_b32_e32 v102, 0xffff, v102                           // 000000D40F20: 36CCCCFF 0000FFFF
	v_sad_u8 v103, v103, 0, 0x6400                             // 000000D40F28: D6220067 03FD0167 00006400
	v_mov_b32_e32 v35, v75                                     // 000000D40F34: 7E46034B
	v_mov_b32_e32 v37, v34                                     // 000000D40F38: 7E4A0322
	s_cselect_b32 s31, s26, 0x44a0                             // 000000D40F3C: 981FFF1A 000044A0
	v_wmma_f32_16x16x16_f16 v[9:16], v[197:204], v[165:172], v[9:16]// 000000D40F44: CC404009 1C274BC5
	v_permlanex16_b32 v36, v36, s23, 0xfedcba98                // 000000D40F4C: D65C0024 03FC2F24 FEDCBA98
	v_lshl_or_b32 v80, v103, 16, v102                          // 000000D40F58: D6560050 05992167
	v_permlanex16_b32 v35, v35, s23, 0xfedcba98                // 000000D40F60: D65C0023 03FC2F23 FEDCBA98
	s_waitcnt lgkmcnt(0)                                       // 000000D40F6C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[1:8], v[25:32], v[67:74], v[1:8] // 000000D40F70: CC404001 1C068719
	v_permlanex16_b32 v37, v37, s23, 0xfedcba98                // 000000D40F78: D65C0025 03FC2F25 FEDCBA98
	v_add_nc_u32_e32 v71, s31, v93                             // 000000D40F84: 4A8EBA1F
	v_wmma_f32_16x16x16_f16 v[9:16], v[25:32], v[41:48], v[9:16]// 000000D40F88: CC404009 1C265319
	v_cndmask_b32_e64 v26, v36, v33, s3                        // 000000D40F90: D501001A 000E4324
	v_cndmask_b32_e64 v30, v33, v36, s3                        // 000000D40F98: D501001E 000E4921
	.long 0xd73d0020                                           // 000000D40FA0: D73D0020
	v_cndmask_b32_e32 v1, v94, v77, vcc_lo                     // 000000D40FA4: 02029B5E
	v_pk_fma_f16 v76, v80, s22, 0xc931 op_sel_hi:[1,0,0]       // 000000D40FA8: CC0E004C 0BFC2D50 0000C931
	v_cndmask_b32_e64 v25, v35, v75, s3                        // 000000D40FB4: D5010019 000E9723
	v_cndmask_b32_e64 v29, v75, v35, s3                        // 000000D40FBC: D501001D 000E474B
	v_cndmask_b32_e64 v27, v37, v34, s3                        // 000000D40FC4: D501001B 000E4525
	v_cndmask_b32_e64 v31, v34, v37, s3                        // 000000D40FCC: D501001F 000E4B22
	ds_load_b128 v[33:36], v71                                 // 000000D40FD4: DBFC0000 21000047
	ds_load_b128 v[37:40], v71 offset:16                       // 000000D40FDC: DBFC0010 25000047
	ds_load_b128 v[41:44], v71 offset:4352                     // 000000D40FE4: DBFC1100 29000047
	ds_load_b128 v[45:48], v71 offset:4368                     // 000000D40FEC: DBFC1110 2D000047
	ds_load_b128 v[67:70], v71 offset:8704                     // 000000D40FF4: DBFC2200 43000047
	ds_load_b128 v[71:74], v71 offset:8720                     // 000000D40FFC: DBFC2210 47000047
	v_mov_b32_e32 v79, v76                                     // 000000D41004: 7E9E034C
	v_bfe_u32 v75, v32, 12, 16                                 // 000000D41008: D610004B 02411920
	v_bfe_u32 v85, v32, 4, 16                                  // 000000D41010: D6100055 02410920
	v_bfe_u32 v78, v32, 8, 16                                  // 000000D41018: D610004E 02411120
	v_mul_u32_u24_e32 v86, s13, v75                            // 000000D41020: 16AC960D
	v_mul_u32_u24_e32 v75, s21, v75                            // 000000D41024: 16969615
	v_mul_u32_u24_e32 v101, s13, v85                           // 000000D41028: 16CAAA0D
	v_mul_u32_u24_e32 v85, s21, v85                            // 000000D4102C: 16AAAA15
	v_lshl_add_u32 v75, v75, 24, v86                           // 000000D41030: D646004B 0559314B
	v_lshl_add_u32 v85, v85, 24, v101                          // 000000D41038: D6460055 05953155
	v_mul_u32_u24_e32 v101, s13, v78                           // 000000D41040: 16CA9C0D
	v_mul_u32_u24_e32 v78, s21, v78                            // 000000D41044: 169C9C15
	v_and_b32_e32 v32, 0xffff, v32                             // 000000D41048: 364040FF 0000FFFF
	v_lshl_add_u32 v78, v78, 24, v101                          // 000000D41050: D646004E 0595314E
	v_mul_u32_u24_e32 v101, s13, v32                           // 000000D41058: 16CA400D
	v_mul_u32_u24_e32 v32, s21, v32                            // 000000D4105C: 16404015
	v_permlanex16_b32 v79, v79, s23, 0xfedcba98                // 000000D41060: D65C004F 03FC2F4F FEDCBA98
	v_lshl_add_u32 v32, v32, 24, v101                          // 000000D4106C: D6460020 05953120
	s_waitcnt vmcnt(1)                                         // 000000D41074: BF8907F7
	v_bfe_u32 v86, v82, 4, 16                                  // 000000D41078: D6100056 02410952
	v_bfe_u32 v80, v82, 8, 16                                  // 000000D41080: D6100050 02411152
	v_mul_u32_u24_e32 v101, s13, v86                           // 000000D41088: 16CAAC0D
	v_mul_u32_u24_e32 v86, s21, v86                            // 000000D4108C: 16ACAC15
	v_bfe_u32 v77, v82, 12, 16                                 // 000000D41090: D610004D 02411952
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000D41098: D622004B 03FD014B 00006400
	v_and_b32_e32 v82, 0xffff, v82                             // 000000D410A4: 36A4A4FF 0000FFFF
	v_lshl_add_u32 v86, v86, 24, v101                          // 000000D410AC: D6460056 05953156
	v_mul_u32_u24_e32 v101, s13, v80                           // 000000D410B4: 16CAA00D
	v_mul_u32_u24_e32 v80, s21, v80                            // 000000D410B8: 16A0A015
	v_lshl_add_u32 v80, v80, 24, v101                          // 000000D410BC: D6460050 05953150
	v_mul_u32_u24_e32 v101, s13, v82                           // 000000D410C4: 16CAA40D
	v_mul_u32_u24_e32 v82, s21, v82                            // 000000D410C8: 16A4A415
	v_cndmask_b32_e64 v28, v79, v76, s3                        // 000000D410CC: D501001C 000E994F
	v_lshl_add_u32 v82, v82, 24, v101                          // 000000D410D4: D6460052 05953152
	v_sad_u8 v101, v32, 0, 0x6400                              // 000000D410DC: D6220065 03FD0120 00006400
	v_cndmask_b32_e64 v32, v76, v79, s3                        // 000000D410E8: D5010020 000E9F4C
	v_and_b32_e32 v75, 0xffff, v75                             // 000000D410F0: 369696FF 0000FFFF
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000D410F8: D622004E 03FD014E 00006400
	v_mul_u32_u24_e32 v102, s13, v77                           // 000000D41104: 16CC9A0D
	v_mul_u32_u24_e32 v77, s21, v77                            // 000000D41108: 169A9A15
	s_waitcnt lgkmcnt(0)                                       // 000000D4110C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[1:8], v[25:32], v[67:74], v[1:8] // 000000D41110: CC404001 1C068719
	.long 0xd73d0043                                           // 000000D41118: D73D0043
	v_cndmask_b32_e32 v1, v94, v83, vcc_lo                     // 000000D4111C: 0202A75E
	v_lshl_or_b32 v75, v78, 16, v75                            // 000000D41120: D656004B 052D214E
	v_lshl_add_u32 v77, v77, 24, v102                          // 000000D41128: D646004D 0599314D
	v_sad_u8 v85, v85, 0, 0x6400                               // 000000D41130: D6220055 03FD0155 00006400
	v_sad_u8 v86, v86, 0, 0x6400                               // 000000D4113C: D6220056 03FD0156 00006400
	v_wmma_f32_16x16x16_f16 v[17:24], v[25:32], v[33:40], v[17:24]// 000000D41148: CC404011 1C464319
	v_bfe_u32 v68, v67, 12, 16                                 // 000000D41150: D6100044 02411943
	v_mul_u32_u24_e32 v69, s13, v68                            // 000000D41158: 168A880D
	v_mul_u32_u24_e32 v68, s21, v68                            // 000000D4115C: 16888815
	v_pk_fma_f16 v75, v75, s22, 0xc931 op_sel_hi:[1,0,0]       // 000000D41160: CC0E004B 0BFC2D4B 0000C931
	s_delay_alu instid0(VALU_DEP_2)                            // 000000D4116C: BF870002
	v_lshl_add_u32 v68, v68, 24, v69                           // 000000D41170: D6460044 05153144
	v_sad_u8 v77, v77, 0, 0x6400                               // 000000D41178: D622004D 03FD014D 00006400
	v_bfe_u32 v69, v67, 8, 16                                  // 000000D41184: D6100045 02411143
	v_bfe_u32 v73, v67, 4, 16                                  // 000000D4118C: D6100049 02410943
	v_mul_u32_u24_e32 v74, s13, v69                            // 000000D41194: 16948A0D
	v_mul_u32_u24_e32 v69, s21, v69                            // 000000D41198: 168A8A15
	s_delay_alu instid0(VALU_DEP_2)                            // 000000D4119C: BF870002
	v_lshl_add_u32 v69, v69, 24, v74                           // 000000D411A0: D6460045 05293145
	v_mul_u32_u24_e32 v74, s13, v73                            // 000000D411A8: 1694920D
	v_mul_u32_u24_e32 v73, s21, v73                            // 000000D411AC: 16929215
	v_dual_mov_b32 v36, v75 :: v_dual_and_b32 v85, 0xffff, v85 // 000000D411B0: CA24014B 2454AAFF 0000FFFF
	v_sad_u8 v68, v68, 0, 0x6400                               // 000000D411BC: D6220044 03FD0144 00006400
	v_lshl_add_u32 v73, v73, 24, v74                           // 000000D411C8: D6460049 05293149
	v_and_b32_e32 v77, 0xffff, v77                             // 000000D411D0: 369A9AFF 0000FFFF
	v_sad_u8 v80, v80, 0, 0x6400                               // 000000D411D8: D6220050 03FD0150 00006400
	v_and_b32_e32 v86, 0xffff, v86                             // 000000D411E4: 36ACACFF 0000FFFF
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000D411EC: D6220052 03FD0152 00006400
	v_lshl_or_b32 v76, v101, 16, v85                           // 000000D411F8: D656004C 05552165
	v_permlanex16_b32 v36, v36, s23, 0xfedcba98                // 000000D41200: D65C0024 03FC2F24 FEDCBA98
	v_and_b32_e32 v68, 0xffff, v68                             // 000000D4120C: 368888FF 0000FFFF
	v_sad_u8 v69, v69, 0, 0x6400                               // 000000D41214: D6220045 03FD0145 00006400
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000D41220: D6220049 03FD0149 00006400
	v_lshl_or_b32 v77, v80, 16, v77                            // 000000D4122C: D656004D 05352150
	v_lshl_or_b32 v78, v82, 16, v86                            // 000000D41234: D656004E 05592152
	s_waitcnt vmcnt(0)                                         // 000000D4123C: BF8903F7
	v_bfe_u32 v70, v81, 12, 16                                 // 000000D41240: D6100046 02411951
	v_and_b32_e32 v67, 0xffff, v67                             // 000000D41248: 368686FF 0000FFFF
	v_pk_fma_f16 v33, v76, s22, 0xc931 op_sel_hi:[1,0,0]       // 000000D41250: CC0E0021 0BFC2D4C 0000C931
	v_wmma_f32_16x16x16_f16 v[9:16], v[25:32], v[41:48], v[9:16]// 000000D4125C: CC404009 1C265319
	v_cndmask_b32_e64 v25, v36, v75, s3                        // 000000D41264: D5010019 000E9724
	v_cndmask_b32_e64 v29, v75, v36, s3                        // 000000D4126C: D501001D 000E494B
	v_bfe_u32 v74, v81, 4, 16                                  // 000000D41274: D610004A 02410951
	v_mul_u32_u24_e32 v75, s13, v67                            // 000000D4127C: 1696860D
	v_mul_u32_u24_e32 v67, s21, v67                            // 000000D41280: 16868615
	v_mul_u32_u24_e32 v76, s13, v70                            // 000000D41284: 16988C0D
	v_mul_u32_u24_e32 v70, s21, v70                            // 000000D41288: 168C8C15
	v_lshl_or_b32 v68, v69, 16, v68                            // 000000D4128C: D6560044 05112145
	v_and_b32_e32 v69, 0xffff, v73                             // 000000D41294: 368A92FF 0000FFFF
	v_mul_u32_u24_e32 v73, s13, v74                            // 000000D4129C: 1692940D
	v_pk_fma_f16 v34, v77, s22, 0xc931 op_sel_hi:[1,0,0]       // 000000D412A0: CC0E0022 0BFC2D4D 0000C931
	v_pk_fma_f16 v35, v78, s22, 0xc931 op_sel_hi:[1,0,0]       // 000000D412AC: CC0E0023 0BFC2D4E 0000C931
	v_lshl_add_u32 v70, v70, 24, v76                           // 000000D412B8: D6460046 05313146
	v_lshl_add_u32 v67, v67, 24, v75                           // 000000D412C0: D6460043 052D3143
	v_mul_u32_u24_e32 v74, s21, v74                            // 000000D412C8: 16949415
	v_lshl_add_u32 v73, v74, 24, v73                           // 000000D412CC: D6460049 0525314A
	v_bfe_u32 v72, v81, 8, 16                                  // 000000D412D4: D6100048 02411151
	v_mul_u32_u24_e32 v74, s13, v72                            // 000000D412DC: 1694900D
	v_mul_u32_u24_e32 v72, s21, v72                            // 000000D412E0: 16909015
	v_and_b32_e32 v75, 0xffff, v81                             // 000000D412E4: 3696A2FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2)                            // 000000D412EC: BF870002
	v_lshl_add_u32 v72, v72, 24, v74                           // 000000D412F0: D6460048 05293148
	v_mul_u32_u24_e32 v74, s13, v75                            // 000000D412F8: 1694960D
	v_dual_mov_b32 v37, v33 :: v_dual_mov_b32 v38, v34         // 000000D412FC: CA100121 25260122
	v_mov_b32_e32 v39, v35                                     // 000000D41304: 7E4E0323
	v_sad_u8 v70, v70, 0, 0x6400                               // 000000D41308: D6220046 03FD0146 00006400
	v_sad_u8 v67, v67, 0, 0x6400                               // 000000D41314: D6220043 03FD0143 00006400
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000D41320: D6220049 03FD0149 00006400
	v_mul_u32_u24_e32 v75, s21, v75                            // 000000D4132C: 16969615
	v_lshl_add_u32 v74, v75, 24, v74                           // 000000D41330: D646004A 0529314B
	s_cselect_b32 s31, s27, 0x44c0                             // 000000D41338: 981FFF1B 000044C0
	v_permlanex16_b32 v37, v37, s23, 0xfedcba98                // 000000D41340: D65C0025 03FC2F25 FEDCBA98
	v_permlanex16_b32 v38, v38, s23, 0xfedcba98                // 000000D4134C: D65C0026 03FC2F26 FEDCBA98
	v_permlanex16_b32 v39, v39, s23, 0xfedcba98                // 000000D41358: D65C0027 03FC2F27 FEDCBA98
	v_add_nc_u32_e32 v71, s31, v93                             // 000000D41364: 4A8EBA1F
	v_and_b32_e32 v70, 0xffff, v70                             // 000000D41368: 368C8CFF 0000FFFF
	v_sad_u8 v72, v72, 0, 0x6400                               // 000000D41370: D6220048 03FD0148 00006400
	v_lshl_or_b32 v75, v67, 16, v69                            // 000000D4137C: D656004B 05152143
	v_and_b32_e32 v76, 0xffff, v73                             // 000000D41384: 369892FF 0000FFFF
	v_sad_u8 v77, v74, 0, 0x6400                               // 000000D4138C: D622004D 03FD014A 00006400
	s_and_b32 s31, s30, exec_lo                                // 000000D41398: 8B1F7E1E
	s_cselect_b32 s31, s28, 0x44e0                             // 000000D4139C: 981FFF1C 000044E0
	v_cndmask_b32_e64 v26, v37, v33, s3                        // 000000D413A4: D501001A 000E4325
	v_cndmask_b32_e64 v30, v33, v37, s3                        // 000000D413AC: D501001E 000E4B21
	v_cndmask_b32_e64 v27, v38, v34, s3                        // 000000D413B4: D501001B 000E4526
	v_cndmask_b32_e64 v31, v34, v38, s3                        // 000000D413BC: D501001F 000E4D22
	v_cndmask_b32_e64 v28, v39, v35, s3                        // 000000D413C4: D501001C 000E4727
	v_cndmask_b32_e64 v32, v35, v39, s3                        // 000000D413CC: D5010020 000E4F23
	ds_load_b128 v[33:36], v71                                 // 000000D413D4: DBFC0000 21000047
	ds_load_b128 v[37:40], v71 offset:16                       // 000000D413DC: DBFC0010 25000047
	ds_load_b128 v[41:44], v71 offset:4352                     // 000000D413E4: DBFC1100 29000047
	ds_load_b128 v[45:48], v71 offset:4368                     // 000000D413EC: DBFC1110 2D000047
	v_pk_fma_f16 v83, v68, s22, 0xc931 op_sel_hi:[1,0,0]       // 000000D413F4: CC0E0053 0BFC2D44 0000C931
	v_lshl_or_b32 v78, v72, 16, v70                            // 000000D41400: D656004E 05192148
	ds_load_b128 v[67:70], v71 offset:8704                     // 000000D41408: DBFC2200 43000047
	ds_load_b128 v[71:74], v71 offset:8720                     // 000000D41410: DBFC2210 47000047
	v_pk_fma_f16 v84, v75, s22, 0xc931 op_sel_hi:[1,0,0]       // 000000D41418: CC0E0054 0BFC2D4B 0000C931
	v_lshl_or_b32 v75, v77, 16, v76                            // 000000D41424: D656004B 0531214D
	v_add_nc_u32_e32 v113, s31, v93                            // 000000D4142C: 4AE2BA1F
	v_pk_fma_f16 v85, v78, s22, 0xc931 op_sel_hi:[1,0,0]       // 000000D41430: CC0E0055 0BFC2D4E 0000C931
	v_mov_b32_e32 v86, v83                                     // 000000D4143C: 7EAC0353
	v_mov_b32_e32 v118, v84                                    // 000000D41440: 7EEC0354
	v_pk_fma_f16 v117, v75, s22, 0xc931 op_sel_hi:[1,0,0]      // 000000D41444: CC0E0075 0BFC2D4B 0000C931
	ds_load_b128 v[75:78], v113                                // 000000D41450: DBFC0000 4B000071
	ds_load_b128 v[79:82], v113 offset:16                      // 000000D41458: DBFC0010 4F000071
	ds_load_b128 v[101:104], v113 offset:4352                  // 000000D41460: DBFC1100 65000071
	ds_load_b128 v[105:108], v113 offset:4368                  // 000000D41468: DBFC1110 69000071
	ds_load_b128 v[109:112], v113 offset:8704                  // 000000D41470: DBFC2200 6D000071
	ds_load_b128 v[113:116], v113 offset:8720                  // 000000D41478: DBFC2210 71000071
	v_mov_b32_e32 v119, v85                                    // 000000D41480: 7EEE0355
	v_permlanex16_b32 v86, v86, s23, 0xfedcba98                // 000000D41484: D65C0056 03FC2F56 FEDCBA98
	v_permlanex16_b32 v118, v118, s23, 0xfedcba98              // 000000D41490: D65C0076 03FC2F76 FEDCBA98
	v_mov_b32_e32 v120, v117                                   // 000000D4149C: 7EF00375
	s_and_not1_b32 vcc_lo, exec_lo, s29                        // 000000D414A0: 916A1D7E
	v_permlanex16_b32 v119, v119, s23, 0xfedcba98              // 000000D414A4: D65C0077 03FC2F77 FEDCBA98
	s_waitcnt lgkmcnt(10)                                      // 000000D414B0: BF89FCA7
	v_wmma_f32_16x16x16_f16 v[17:24], v[25:32], v[33:40], v[17:24]// 000000D414B4: CC404011 1C464319
	v_cndmask_b32_e64 v33, v86, v83, s3                        // 000000D414BC: D5010021 000EA756
	v_permlanex16_b32 v120, v120, s23, 0xfedcba98              // 000000D414C4: D65C0078 03FC2F78 FEDCBA98
	v_cndmask_b32_e64 v37, v83, v86, s3                        // 000000D414D0: D5010025 000EAD53
	v_cndmask_b32_e64 v34, v118, v84, s3                       // 000000D414D8: D5010022 000EA976
	v_cndmask_b32_e64 v38, v84, v118, s3                       // 000000D414E0: D5010026 000EED54
	v_cndmask_b32_e64 v35, v119, v85, s3                       // 000000D414E8: D5010023 000EAB77
	v_cndmask_b32_e64 v39, v85, v119, s3                       // 000000D414F0: D5010027 000EEF55
	v_cndmask_b32_e64 v36, v120, v117, s3                      // 000000D414F8: D5010024 000EEB78
	v_cndmask_b32_e64 v40, v117, v120, s3                      // 000000D41500: D5010028 000EF175
	s_waitcnt lgkmcnt(8)                                       // 000000D41508: BF89FC87
	v_wmma_f32_16x16x16_f16 v[9:16], v[25:32], v[41:48], v[9:16]// 000000D4150C: CC404009 1C265319
	s_waitcnt lgkmcnt(6)                                       // 000000D41514: BF89FC67
	v_wmma_f32_16x16x16_f16 v[1:8], v[25:32], v[67:74], v[1:8] // 000000D41518: CC404001 1C068719
	s_waitcnt lgkmcnt(4)                                       // 000000D41520: BF89FC47
	v_wmma_f32_16x16x16_f16 v[17:24], v[33:40], v[75:82], v[17:24]// 000000D41524: CC404011 1C469721
	s_waitcnt lgkmcnt(2)                                       // 000000D4152C: BF89FC27
	v_wmma_f32_16x16x16_f16 v[9:16], v[33:40], v[101:108], v[9:16]// 000000D41530: CC404009 1C26CB21
	s_waitcnt lgkmcnt(0)                                       // 000000D41538: BF89FC07
	v_wmma_f32_16x16x16_f16 v[1:8], v[33:40], v[109:116], v[1:8]// 000000D4153C: CC404001 1C06DB21
	s_cbranch_vccnz 64140                                      // 000000D41544: BFA4FA8C <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x3d78>
	s_and_b32 s29, s30, exec_lo                                // 000000D41548: 8B1D7E1E
	s_cselect_b32 s29, 0x4400, 0                               // 000000D4154C: 981D80FF 00004400
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000D41554: BF870009
	v_lshl_or_b32 v25, v87, 1, s29                             // 000000D41558: D6560019 00750357
	s_and_saveexec_b32 s29, s0                                 // 000000D41560: BE9D2000
	s_cbranch_execnz 7                                         // 000000D41564: BFA60007 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x5384>
	s_or_b32 exec_lo, exec_lo, s29                             // 000000D41568: 8C7E1D7E
	s_and_saveexec_b32 s29, s1                                 // 000000D4156C: BE9D2001
	s_cbranch_execnz 11                                        // 000000D41570: BFA6000B <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x53a0>
	s_or_b32 exec_lo, exec_lo, s29                             // 000000D41574: 8C7E1D7E
	s_and_saveexec_b32 s29, s2                                 // 000000D41578: BE9D2002
	s_cbranch_execz 64125                                      // 000000D4157C: BFA5FA7D <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x3d74>
	s_branch 13                                                // 000000D41580: BFA0000D <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x53b8>
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D41584: BF870001
	v_add_nc_u32_e32 v26, v25, v91                             // 000000D41588: 4A34B719
	ds_store_b128 v26, v[49:52]                                // 000000D4158C: DB7C0000 0000311A
	s_or_b32 exec_lo, exec_lo, s29                             // 000000D41594: 8C7E1D7E
	s_and_saveexec_b32 s29, s1                                 // 000000D41598: BE9D2001
	s_cbranch_execz 65525                                      // 000000D4159C: BFA5FFF5 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x5374>
	v_add_nc_u32_e32 v26, v25, v92                             // 000000D415A0: 4A34B919
	ds_store_b128 v26, v[53:56]                                // 000000D415A4: DB7C0000 0000351A
	s_or_b32 exec_lo, exec_lo, s29                             // 000000D415AC: 8C7E1D7E
	s_and_saveexec_b32 s29, s2                                 // 000000D415B0: BE9D2002
	s_cbranch_execz 64111                                      // 000000D415B4: BFA5FA6F <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x3d74>
	v_add_nc_u32_e32 v25, v25, v90                             // 000000D415B8: 4A32B519
	ds_store_b128 v25, v[57:60]                                // 000000D415BC: DB7C0000 00003919
	s_branch 64107                                             // 000000D415C4: BFA0FA6B <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x3d74>
	v_lshrrev_b32_e32 v25, 5, v0                               // 000000D415C8: 32320085
	v_lshrrev_b32_e32 v26, 2, v88                              // 000000D415CC: 3234B082
	s_mul_i32 s1, s16, 0x1400                                  // 000000D415D0: 9601FF10 00001400
	s_mul_hi_i32 s0, s16, 0x1400                               // 000000D415D8: 9700FF10 00001400
	s_add_u32 s2, s14, s1                                      // 000000D415E0: 8002010E
	v_lshlrev_b32_e32 v28, 6, v25                              // 000000D415E4: 30383286
	s_addc_u32 s3, s15, s0                                     // 000000D415E8: 8203000F
	s_lshl_b32 s0, s17, 7                                      // 000000D415EC: 84008711
	v_and_b32_e32 v29, 1, v0                                   // 000000D415F0: 363A0081
	s_ashr_i32 s1, s0, 31                                      // 000000D415F4: 86019F00
	v_mad_u32_u24 v28, 0x210, v89, v28                         // 000000D415F8: D60B001C 0472B2FF 00000210
	s_lshl_b64 s[4:5], s[0:1], 1                               // 000000D41604: 84848100
	v_and_b32_e32 v30, 4, v0                                   // 000000D41608: 363C0084
	s_add_u32 s12, s2, s4                                      // 000000D4160C: 800C0402
	s_addc_u32 s13, s3, s5                                     // 000000D41610: 820D0503
	v_and_or_b32 v26, v26, 4, v28                              // 000000D41614: D657001A 0471091A
	v_and_b32_e32 v28, 2, v0                                   // 000000D4161C: 36380082
	.long 0xd44a0003                                           // 000000D41620: D44A0003
	v_cndmask_b32_e32 v1, 0, v29, vcc_lo                       // 000000D41624: 02023A80
	v_and_b32_e32 v29, 8, v0                                   // 000000D41628: 363A0088
	v_lshlrev_b32_e32 v27, 4, v88                              // 000000D4162C: 3036B084
	.long 0xd44a0001                                           // 000000D41630: D44A0001
	v_cndmask_b32_e32 v1, 0, v30, vcc_lo                       // 000000D41634: 02023C80
	.long 0xd44a0002                                           // 000000D41638: D44A0002
	v_cndmask_b32_e32 v1, 0, v28, vcc_lo                       // 000000D4163C: 02023880
	v_lshlrev_b32_e32 v28, 3, v88                              // 000000D41640: 3038B083
	.long 0xd44a0000                                           // 000000D41644: D44A0000
	v_cndmask_b32_e32 v1, 0, v29, vcc_lo                       // 000000D41648: 02023A80
	v_lshlrev_b32_e32 v29, 2, v88                              // 000000D4164C: 303AB082
	ds_store_2addr_b32 v26, v17, v18 offset1:2                 // 000000D41650: D8380200 0012111A
	ds_store_2addr_b32 v26, v19, v20 offset0:4 offset1:6       // 000000D41658: D8380604 0014131A
	ds_store_2addr_b32 v26, v21, v22 offset0:8 offset1:10      // 000000D41660: D8380A08 0016151A
	v_and_b32_e32 v31, 16, v0                                  // 000000D41668: 363E0090
	.long 0xd700151c                                           // 000000D4166C: D700151C
	v_cndmask_b32_e32 v1, s6, v28, vcc_lo                      // 000000D41670: 02023806
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D41674: BF8701A1
	v_add_co_ci_u32_e64 v30, null, s7, 0, s21                  // 000000D41678: D5207C1E 00550007
	v_mad_u32_u24 v20, 0x210, v25, v27                         // 000000D41680: D60B0014 046E32FF 00000210
	.long 0xd7000411                                           // 000000D4168C: D7000411
	v_cndmask_b32_e32 v0, v28, v4, vcc_lo                      // 000000D41690: 0200091C
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D41694: BF870001
	v_add_co_ci_u32_e64 v18, null, s5, v30, s4                 // 000000D41698: D5207C12 00123C05
	v_lshlrev_b32_e32 v19, 1, v29                              // 000000D416A0: 30263A81
	s_mov_b32 s5, exec_lo                                      // 000000D416A4: BE85007E
	v_cmp_eq_u32_e32 vcc_lo, 0, v31                            // 000000D416A8: 7C943E80
	ds_store_2addr_b32 v26, v23, v24 offset0:12 offset1:14     // 000000D416AC: D8380E0C 0018171A
	s_waitcnt lgkmcnt(0)                                       // 000000D416B4: BF89FC07
	s_barrier                                                  // 000000D416B8: BFBD0000
	buffer_gl0_inv                                             // 000000D416BC: E0AC0000 00000000
	.long 0xd4c4007e                                           // 000000D416C4: D4C4007E
	v_cndmask_b32_e32 v1, s19, v25, vcc_lo                     // 000000D416C8: 02023213
	s_cbranch_execz 198                                        // 000000D416CC: BFA500C6 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x57e8>
	global_load_b64 v[28:29], v19, s[12:13]                    // 000000D416D0: DC560000 1C0C0013
	ds_load_b128 v[21:24], v20                                 // 000000D416D8: DBFC0000 15000014
	s_mov_b32 s4, 0x76543210                                   // 000000D416E0: BE8400FF 76543210
	s_waitcnt lgkmcnt(0)                                       // 000000D416E8: BF89FC07
	v_dual_add_f32 v30, v21, v22 :: v_dual_add_f32 v31, v23, v24// 000000D416EC: C9082D15 1E1E3117
	v_dual_sub_f32 v21, v21, v22 :: v_dual_sub_f32 v22, v23, v24// 000000D416F4: C94A2D15 15163117
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D416FC: BF870112
	v_sub_f32_e32 v24, v30, v31                                // 000000D41700: 08303F1E
	v_dual_add_f32 v23, v30, v31 :: v_dual_add_f32 v30, v21, v22// 000000D41704: C9083F1E 171E2D15
	v_sub_f32_e32 v21, v21, v22                                // 000000D4170C: 082A2D15
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D41710: BF870223
	v_mov_b32_dpp v31, v24 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D41714: 7E3E02FA FF016118
	v_cndmask_b32_e64 v24, -v24, v24, s3                       // 000000D4171C: D5010018 200E3118
	v_mov_b32_dpp v22, v23 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D41724: 7E2C02FA FF016117
	v_cndmask_b32_e64 v23, -v23, v23, s3                       // 000000D4172C: D5010017 200E2F17
	v_mov_b32_dpp v32, v30 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D41734: 7E4002FA FF01611E
	v_mov_b32_dpp v33, v21 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D4173C: 7E4202FA FF016115
	v_cndmask_b32_e64 v21, -v21, v21, s3                       // 000000D41744: D5010015 200E2B15
	v_cndmask_b32_e64 v30, -v30, v30, s3                       // 000000D4174C: D501001E 200E3D1E
	v_add_f32_e32 v24, v24, v31                                // 000000D41754: 06303F18
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D41758: BF870193
	v_dual_add_f32 v22, v23, v22 :: v_dual_add_f32 v21, v21, v33// 000000D4175C: C9082D17 16144315
	v_add_f32_e32 v23, v30, v32                                // 000000D41764: 062E411E
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D41768: BF870223
	v_mov_b32_dpp v30, v24 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D4176C: 7E3C02FA FF016218
	v_cndmask_b32_e64 v24, -v24, v24, s2                       // 000000D41774: D5010018 200A3118
	v_mov_b32_dpp v31, v22 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D4177C: 7E3E02FA FF016216
	v_mov_b32_dpp v32, v21 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D41784: 7E4002FA FF016215
	v_cndmask_b32_e64 v21, -v21, v21, s2                       // 000000D4178C: D5010015 200A2B15
	v_cndmask_b32_e64 v22, -v22, v22, s2                       // 000000D41794: D5010016 200A2D16
	v_add_f32_e32 v24, v24, v30                                // 000000D4179C: 06303D18
	v_mov_b32_dpp v30, v23 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D417A0: 7E3C02FA FF016217
	v_cndmask_b32_e64 v23, -v23, v23, s2                       // 000000D417A8: D5010017 200A2F17
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D417B0: BF870214
	v_dual_add_f32 v21, v21, v32 :: v_dual_add_f32 v22, v22, v31// 000000D417B4: C9084115 15163F16
	v_mov_b32_dpp v31, v24 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D417BC: 7E3E02FA FF016418
	v_cndmask_b32_e64 v24, -v24, v24, s1                       // 000000D417C4: D5010018 20063118
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D417CC: BF870214
	v_add_f32_e32 v23, v23, v30                                // 000000D417D0: 062E3D17
	v_mov_b32_dpp v30, v21 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D417D4: 7E3C02FA FF016415
	v_cndmask_b32_e64 v21, -v21, v21, s1                       // 000000D417DC: D5010015 20062B15
	v_mov_b32_dpp v32, v22 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D417E4: 7E4002FA FF016416
	v_add_f32_e32 v24, v24, v31                                // 000000D417EC: 06303F18
	v_cndmask_b32_e64 v22, -v22, v22, s1                       // 000000D417F0: D5010016 20062D16
	v_mov_b32_dpp v31, v23 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D417F8: 7E3E02FA FF016417
	v_add_f32_e32 v21, v21, v30                                // 000000D41800: 062A3D15
	v_cndmask_b32_e64 v23, -v23, v23, s1                       // 000000D41804: D5010017 20062F17
	v_mov_b32_dpp v30, v24 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D4180C: 7E3C02FA FF016818
	v_cndmask_b32_e64 v24, -v24, v24, s0                       // 000000D41814: D5010018 20023118
	v_add_f32_e32 v22, v22, v32                                // 000000D4181C: 062C4116
	v_mov_b32_dpp v32, v21 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D41820: 7E4002FA FF016815
	v_cndmask_b32_e64 v21, -v21, v21, s0                       // 000000D41828: D5010015 20022B15
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D41830: BF870214
	v_dual_add_f32 v23, v23, v31 :: v_dual_add_f32 v24, v24, v30// 000000D41834: C9083F17 17183D18
	v_mov_b32_dpp v30, v22 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D4183C: 7E3C02FA FF016816
	v_cndmask_b32_e64 v22, -v22, v22, s0                       // 000000D41844: D5010016 20022D16
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D4184C: BF870214
	v_add_f32_e32 v21, v21, v32                                // 000000D41850: 062A4115
	v_mov_b32_dpp v32, v23 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D41854: 7E4002FA FF016817
	v_mov_b32_e32 v31, v24                                     // 000000D4185C: 7E3E0318
	v_cndmask_b32_e64 v23, -v23, v23, s0                       // 000000D41860: D5010017 20022F17
	v_cndmask_b32_e64 v24, -v24, v24, vcc_lo                   // 000000D41868: D5010018 21AA3118
	v_mov_b32_e32 v34, v21                                     // 000000D41870: 7E440315
	v_add_f32_e32 v22, v22, v30                                // 000000D41874: 062C3D16
	v_permlanex16_b32 v31, v31, s4, 0xfedcba98                 // 000000D41878: D65C001F 03FC091F FEDCBA98
	v_add_f32_e32 v23, v23, v32                                // 000000D41884: 062E4117
	v_cndmask_b32_e64 v21, -v21, v21, vcc_lo                   // 000000D41888: D5010015 21AA2B15
	v_permlanex16_b32 v34, v34, s4, 0xfedcba98                 // 000000D41890: D65C0022 03FC0922 FEDCBA98
	v_mov_b32_e32 v30, v22                                     // 000000D4189C: 7E3C0316
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D418A0: BF870224
	v_dual_add_f32 v24, v24, v31 :: v_dual_mov_b32 v31, v23    // 000000D418A4: C9103F18 181E0117
	v_cndmask_b32_e64 v22, -v22, v22, vcc_lo                   // 000000D418AC: D5010016 21AA2D16
	v_add_f32_e32 v21, v21, v34                                // 000000D418B4: 062A4515
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D418B8: BF870214
	v_permlanex16_b32 v30, v30, s4, 0xfedcba98                 // 000000D418BC: D65C001E 03FC091E FEDCBA98
	v_mul_f32_e32 v24, 0x3db504f3, v24                         // 000000D418C8: 103030FF 3DB504F3
	.long 0x7f423880                                           // 000000D418D0: 7F423880
	v_cndmask_b32_e64 v23, -v23, v23, vcc_lo                   // 000000D418D4: D5010017 21AA2F17
	v_permlanex16_b32 v31, v31, s4, 0xfedcba98                 // 000000D418DC: D65C001F 03FC091F FEDCBA98
	v_dual_mul_f32 v21, 0x3db504f3, v21 :: v_dual_add_f32 v22, v22, v30// 000000D418E8: C8C82AFF 15163D16 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D418F4: BF870114
	.long 0x7f3c39a1                                           // 000000D418F8: 7F3C39A1
	v_dual_add_f32 v23, v23, v31 :: v_dual_mul_f32 v22, 0x3db504f3, v22// 000000D418FC: C9063F17 17162CFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D41908: BF870001
	v_mul_f32_e32 v23, 0x3db504f3, v23                         // 000000D4190C: 102E2EFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000D41914: BF8903F7
	v_fma_mix_f32 v24, v29, v24, neg(0) op_sel_hi:[1,0,0]      // 000000D41918: CC200018 8A02311D
	v_fma_mix_f32 v21, v29, v21, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D41920: CC200815 8A022B1D
	.long 0x7f3a39a1                                           // 000000D41928: 7F3A39A1
	v_fma_mix_f32 v22, v28, v22, neg(0) op_sel_hi:[1,0,0]      // 000000D4192C: CC200016 8A022D1C
	v_fma_mix_f32 v23, v28, v23, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D41934: CC200817 8A022F1C
	.long 0x7e3c3998                                           // 000000D4193C: 7E3C3998
	.long 0x7e3a3995                                           // 000000D41940: 7E3A3995
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D41944: BF870193
	v_bfe_u32 v31, v23, 16, 1                                  // 000000D41948: D610001F 02052117
	v_and_b32_e32 v30, 1, v30                                  // 000000D41950: 363C3C81
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D41954: BF870223
	v_and_b32_e32 v28, 1, v29                                  // 000000D41958: 36383A81
	v_bfe_u32 v29, v22, 16, 1                                  // 000000D4195C: D610001D 02052116
	v_add3_u32 v23, v23, v31, 0x7fff                           // 000000D41964: D6550017 03FE3F17 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000D41970: BF870244
	v_add3_u32 v24, v24, v30, 0x7fff                           // 000000D41974: D6550018 03FE3D18 00007FFF
	.long 0x7f3c39a1                                           // 000000D41980: 7F3C39A1
	v_add3_u32 v21, v21, v28, 0x7fff                           // 000000D41984: D6550015 03FE3915 00007FFF
	v_add3_u32 v22, v22, v29, 0x7fff                           // 000000D41990: D6550016 03FE3B16 00007FFF
	.long 0x7e3c3998                                           // 000000D4199C: 7E3C3998
	v_add_nc_u32_e32 v24, s18, v25                             // 000000D419A0: 4A303212
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D419A4: BF870214
	v_and_b32_e32 v28, 0xffff0000, v21                         // 000000D419A8: 36382AFF FFFF0000
	.long 0x7e423996                                           // 000000D419B0: 7E423996
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D419B4: BF870214
	v_and_b32_e32 v29, 0xffff, v30                             // 000000D419B8: 363A3CFF 0000FFFF
	v_mad_i64_i32 v[21:22], null, 0x1400, v24, v[17:18]        // 000000D419C0: D6FF7C15 044630FF 00001400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D419CC: BF870193
	v_and_or_b32 v23, 0xffff0000, v23, v33                     // 000000D419D0: D6570017 04862EFF FFFF0000
	v_or_b32_e32 v24, v28, v29                                 // 000000D419DC: 38303B1C
	global_store_b64 v[21:22], v[23:24], off                   // 000000D419E0: DC6E0000 007C1715
	s_or_b32 exec_lo, exec_lo, s5                              // 000000D419E8: 8C7E057E
	v_or_b32_e32 v22, 8, v25                                   // 000000D419EC: 382C3288
	s_mov_b32 s5, exec_lo                                      // 000000D419F0: BE85007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D419F4: BF870001
	v_mad_u32_u24 v21, 0x210, v22, v27                         // 000000D419F8: D60B0015 046E2CFF 00000210
	.long 0xd4c4007e                                           // 000000D41A04: D4C4007E
	v_cndmask_b32_e32 v1, s19, v22, vcc_lo                     // 000000D41A08: 02022C13
	s_cbranch_execz 197                                        // 000000D41A0C: BFA500C5 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x5b24>
	global_load_b64 v[23:24], v19, s[12:13]                    // 000000D41A10: DC560000 170C0013
	ds_load_b128 v[27:30], v21                                 // 000000D41A18: DBFC0000 1B000015
	s_mov_b32 s4, 0x76543210                                   // 000000D41A20: BE8400FF 76543210
	s_waitcnt lgkmcnt(0)                                       // 000000D41A28: BF89FC07
	v_dual_add_f32 v31, v27, v28 :: v_dual_add_nc_u32 v22, s18, v22// 000000D41A2C: C920391B 1F162C12
	v_dual_add_f32 v32, v29, v30 :: v_dual_sub_f32 v27, v27, v28// 000000D41A34: C90A3D1D 201A391B
	v_sub_f32_e32 v28, v29, v30                                // 000000D41A3C: 08383D1D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D41A40: BF8701A2
	v_sub_f32_e32 v30, v31, v32                                // 000000D41A44: 083C411F
	v_add_f32_e32 v29, v31, v32                                // 000000D41A48: 063A411F
	v_add_f32_e32 v31, v27, v28                                // 000000D41A4C: 063E391B
	v_sub_f32_e32 v27, v27, v28                                // 000000D41A50: 0836391B
	s_delay_alu instid0(VALU_DEP_4)                            // 000000D41A54: BF870004
	v_mov_b32_dpp v32, v30 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D41A58: 7E4002FA FF01611E
	v_cndmask_b32_e64 v30, -v30, v30, s3                       // 000000D41A60: D501001E 200E3D1E
	v_mov_b32_dpp v28, v29 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D41A68: 7E3802FA FF01611D
	v_cndmask_b32_e64 v29, -v29, v29, s3                       // 000000D41A70: D501001D 200E3B1D
	v_mov_b32_dpp v33, v31 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D41A78: 7E4202FA FF01611F
	v_mov_b32_dpp v34, v27 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D41A80: 7E4402FA FF01611B
	v_cndmask_b32_e64 v27, -v27, v27, s3                       // 000000D41A88: D501001B 200E371B
	v_cndmask_b32_e64 v31, -v31, v31, s3                       // 000000D41A90: D501001F 200E3F1F
	v_add_f32_e32 v30, v30, v32                                // 000000D41A98: 063C411E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D41A9C: BF870193
	v_dual_add_f32 v28, v29, v28 :: v_dual_add_f32 v27, v27, v34// 000000D41AA0: C908391D 1C1A451B
	v_add_f32_e32 v29, v31, v33                                // 000000D41AA8: 063A431F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D41AAC: BF870223
	v_mov_b32_dpp v31, v30 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D41AB0: 7E3E02FA FF01621E
	v_cndmask_b32_e64 v30, -v30, v30, s2                       // 000000D41AB8: D501001E 200A3D1E
	v_mov_b32_dpp v32, v28 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D41AC0: 7E4002FA FF01621C
	v_mov_b32_dpp v33, v27 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D41AC8: 7E4202FA FF01621B
	v_cndmask_b32_e64 v27, -v27, v27, s2                       // 000000D41AD0: D501001B 200A371B
	v_cndmask_b32_e64 v28, -v28, v28, s2                       // 000000D41AD8: D501001C 200A391C
	v_add_f32_e32 v30, v30, v31                                // 000000D41AE0: 063C3F1E
	v_mov_b32_dpp v31, v29 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D41AE4: 7E3E02FA FF01621D
	v_cndmask_b32_e64 v29, -v29, v29, s2                       // 000000D41AEC: D501001D 200A3B1D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D41AF4: BF870214
	v_dual_add_f32 v27, v27, v33 :: v_dual_add_f32 v28, v28, v32// 000000D41AF8: C908431B 1B1C411C
	v_mov_b32_dpp v32, v30 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D41B00: 7E4002FA FF01641E
	v_cndmask_b32_e64 v30, -v30, v30, s1                       // 000000D41B08: D501001E 20063D1E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D41B10: BF870214
	v_add_f32_e32 v29, v29, v31                                // 000000D41B14: 063A3F1D
	v_mov_b32_dpp v31, v27 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D41B18: 7E3E02FA FF01641B
	v_cndmask_b32_e64 v27, -v27, v27, s1                       // 000000D41B20: D501001B 2006371B
	v_mov_b32_dpp v33, v28 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D41B28: 7E4202FA FF01641C
	v_add_f32_e32 v30, v30, v32                                // 000000D41B30: 063C411E
	v_cndmask_b32_e64 v28, -v28, v28, s1                       // 000000D41B34: D501001C 2006391C
	v_mov_b32_dpp v32, v29 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D41B3C: 7E4002FA FF01641D
	v_add_f32_e32 v27, v27, v31                                // 000000D41B44: 06363F1B
	v_cndmask_b32_e64 v29, -v29, v29, s1                       // 000000D41B48: D501001D 20063B1D
	v_mov_b32_dpp v31, v30 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D41B50: 7E3E02FA FF01681E
	v_cndmask_b32_e64 v30, -v30, v30, s0                       // 000000D41B58: D501001E 20023D1E
	v_add_f32_e32 v28, v28, v33                                // 000000D41B60: 0638431C
	v_mov_b32_dpp v33, v27 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D41B64: 7E4202FA FF01681B
	v_cndmask_b32_e64 v27, -v27, v27, s0                       // 000000D41B6C: D501001B 2002371B
	.long 0x7f443880                                           // 000000D41B74: 7F443880
	v_dual_add_f32 v30, v30, v31 :: v_dual_add_f32 v29, v29, v32// 000000D41B78: C9083F1E 1E1C411D
	v_mov_b32_dpp v31, v28 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D41B80: 7E3E02FA FF01681C
	v_cndmask_b32_e64 v28, -v28, v28, s0                       // 000000D41B88: D501001C 2002391C
	s_delay_alu instid0(VALU_DEP_3)                            // 000000D41B90: BF870003
	v_dual_add_f32 v27, v27, v33 :: v_dual_mov_b32 v32, v30    // 000000D41B94: C910431B 1B20011E
	v_cndmask_b32_e64 v30, -v30, v30, vcc_lo                   // 000000D41B9C: D501001E 21AA3D1E
	v_mov_b32_dpp v33, v29 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D41BA4: 7E4202FA FF01681D
	v_cndmask_b32_e64 v29, -v29, v29, s0                       // 000000D41BAC: D501001D 20023B1D
	v_add_f32_e32 v28, v28, v31                                // 000000D41BB4: 06383F1C
	v_permlanex16_b32 v32, v32, s4, 0xfedcba98                 // 000000D41BB8: D65C0020 03FC0920 FEDCBA98
	v_mov_b32_e32 v35, v27                                     // 000000D41BC4: 7E46031B
	v_cndmask_b32_e64 v27, -v27, v27, vcc_lo                   // 000000D41BC8: D501001B 21AA371B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D41BD0: BF870193
	v_dual_add_f32 v30, v30, v32 :: v_dual_add_f32 v29, v29, v33// 000000D41BD4: C908411E 1E1C431D
	v_permlanex16_b32 v35, v35, s4, 0xfedcba98                 // 000000D41BDC: D65C0023 03FC0923 FEDCBA98
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D41BE8: BF870192
	v_dual_mul_f32 v30, 0x3db504f3, v30 :: v_dual_mov_b32 v31, v28// 000000D41BEC: C8D03CFF 1E1E011C 3DB504F3
	v_mov_b32_e32 v32, v29                                     // 000000D41BF8: 7E40031D
	v_cndmask_b32_e64 v28, -v28, v28, vcc_lo                   // 000000D41BFC: D501001C 21AA391C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000D41C04: BF870244
	v_add_f32_e32 v27, v27, v35                                // 000000D41C08: 0636471B
	v_cndmask_b32_e64 v29, -v29, v29, vcc_lo                   // 000000D41C0C: D501001D 21AA3B1D
	v_permlanex16_b32 v31, v31, s4, 0xfedcba98                 // 000000D41C14: D65C001F 03FC091F FEDCBA98
	v_permlanex16_b32 v32, v32, s4, 0xfedcba98                 // 000000D41C20: D65C0020 03FC0920 FEDCBA98
	v_mul_f32_e32 v27, 0x3db504f3, v27                         // 000000D41C2C: 103636FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000D41C34: BF870122
	v_dual_add_f32 v28, v28, v31 :: v_dual_add_f32 v29, v29, v32// 000000D41C38: C9083F1C 1C1C411D
	.long 0x7f3e39a2                                           // 000000D41C40: 7F3E39A2
	v_mul_f32_e32 v29, 0x3db504f3, v29                         // 000000D41C44: 103A3AFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000D41C4C: BF8903F7
	v_fma_mix_f32 v30, v24, v30, neg(0) op_sel_hi:[1,0,0]      // 000000D41C50: CC20001E 8A023D18
	v_fma_mix_f32 v24, v24, v27, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D41C58: CC200818 8A023718
	v_mul_f32_e32 v27, 0x3db504f3, v28                         // 000000D41C60: 103638FF 3DB504F3
	.long 0x7f3839a2                                           // 000000D41C68: 7F3839A2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D41C6C: BF870214
	.long 0x7e3e399e                                           // 000000D41C70: 7E3E399E
	.long 0x7e383998                                           // 000000D41C74: 7E383998
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D41C78: BF870224
	v_fma_mix_f32 v27, v23, v27, neg(0) op_sel_hi:[1,0,0]      // 000000D41C7C: CC20001B 8A023717
	v_fma_mix_f32 v23, v23, v29, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D41C84: CC200817 8A023B17
	v_and_b32_e32 v31, 1, v31                                  // 000000D41C8C: 363E3E81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D41C90: BF870194
	v_and_b32_e32 v28, 1, v28                                  // 000000D41C94: 36383881
	v_bfe_u32 v32, v23, 16, 1                                  // 000000D41C98: D6100020 02052117
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000D41CA0: BF870243
	v_add3_u32 v29, v30, v31, 0x7fff                           // 000000D41CA4: D655001D 03FE3F1E 00007FFF
	v_bfe_u32 v30, v27, 16, 1                                  // 000000D41CB0: D610001E 0205211B
	.long 0x7f3e39a2                                           // 000000D41CB8: 7F3E39A2
	v_add3_u32 v24, v24, v28, 0x7fff                           // 000000D41CBC: D6550018 03FE3918 00007FFF
	.long 0x7e3e399d                                           // 000000D41CC8: 7E3E399D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D41CCC: BF870224
	v_add3_u32 v27, v27, v30, 0x7fff                           // 000000D41CD0: D655001B 03FE3D1B 00007FFF
	v_add3_u32 v29, v23, v32, 0x7fff                           // 000000D41CDC: D655001D 03FE4117 00007FFF
	v_and_b32_e32 v24, 0xffff0000, v24                         // 000000D41CE8: 363030FF FFFF0000
	v_mad_i64_i32 v[22:23], null, 0x1400, v22, v[17:18]        // 000000D41CF0: D6FF7C16 04462CFF 00001400
	v_and_b32_e32 v28, 0xffff, v31                             // 000000D41CFC: 36383EFF 0000FFFF
	.long 0x7e44399b                                           // 000000D41D04: 7E44399B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D41D08: BF870112
	v_or_b32_e32 v28, v24, v28                                 // 000000D41D0C: 38383918
	v_and_or_b32 v27, 0xffff0000, v29, v34                     // 000000D41D10: D657001B 048A3AFF FFFF0000
	global_store_b64 v[22:23], v[27:28], off                   // 000000D41D1C: DC6E0000 007C1B16
	s_or_b32 exec_lo, exec_lo, s5                              // 000000D41D24: 8C7E057E
	v_or_b32_e32 v22, 16, v25                                  // 000000D41D28: 382C3290
	s_mov_b32 s5, exec_lo                                      // 000000D41D2C: BE85007E
	s_waitcnt_vscnt null, 0x0                                  // 000000D41D30: BC7C0000
	s_barrier                                                  // 000000D41D34: BFBD0000
	buffer_gl0_inv                                             // 000000D41D38: E0AC0000 00000000
	ds_store_2addr_b32 v26, v9, v10 offset1:2                  // 000000D41D40: D8380200 000A091A
	ds_store_2addr_b32 v26, v11, v12 offset0:4 offset1:6       // 000000D41D48: D8380604 000C0B1A
	ds_store_2addr_b32 v26, v13, v14 offset0:8 offset1:10      // 000000D41D50: D8380A08 000E0D1A
	ds_store_2addr_b32 v26, v15, v16 offset0:12 offset1:14     // 000000D41D58: D8380E0C 00100F1A
	s_waitcnt lgkmcnt(0)                                       // 000000D41D60: BF89FC07
	s_barrier                                                  // 000000D41D64: BFBD0000
	buffer_gl0_inv                                             // 000000D41D68: E0AC0000 00000000
	.long 0xd4c4007e                                           // 000000D41D70: D4C4007E
	v_cndmask_b32_e32 v1, s19, v22, vcc_lo                     // 000000D41D74: 02022C13
	s_cbranch_execz 199                                        // 000000D41D78: BFA500C7 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x5e98>
	global_load_b64 v[13:14], v19, s[12:13]                    // 000000D41D7C: DC560000 0D0C0013
	ds_load_b128 v[9:12], v20                                  // 000000D41D84: DBFC0000 09000014
	s_mov_b32 s4, 0x76543210                                   // 000000D41D8C: BE8400FF 76543210
	s_waitcnt lgkmcnt(0)                                       // 000000D41D94: BF89FC07
	v_dual_add_f32 v15, v9, v10 :: v_dual_add_f32 v16, v11, v12// 000000D41D98: C9081509 0F10190B
	v_dual_sub_f32 v9, v9, v10 :: v_dual_sub_f32 v10, v11, v12 // 000000D41DA0: C94A1509 090A190B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D41DA8: BF870112
	v_add_f32_e32 v11, v15, v16                                // 000000D41DAC: 0616210F
	v_dual_sub_f32 v12, v15, v16 :: v_dual_add_f32 v15, v9, v10// 000000D41DB0: C948210F 0C0E1509
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D41DB8: BF870001
	v_mov_b32_dpp v16, v12 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D41DBC: 7E2002FA FF01610C
	v_cndmask_b32_e64 v12, -v12, v12, s3                       // 000000D41DC4: D501000C 200E190C
	v_sub_f32_e32 v9, v9, v10                                  // 000000D41DCC: 08121509
	v_mov_b32_dpp v10, v11 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D41DD0: 7E1402FA FF01610B
	v_cndmask_b32_e64 v11, -v11, v11, s3                       // 000000D41DD8: D501000B 200E170B
	v_mov_b32_dpp v23, v15 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D41DE0: 7E2E02FA FF01610F
	v_cndmask_b32_e64 v15, -v15, v15, s3                       // 000000D41DE8: D501000F 200E1F0F
	v_add_f32_e32 v12, v12, v16                                // 000000D41DF0: 0618210C
	v_mov_b32_dpp v24, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D41DF4: 7E3002FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 000000D41DFC: D5010009 200E1309
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D41E04: BF870091
	v_dual_add_f32 v10, v11, v10 :: v_dual_add_f32 v9, v9, v24 // 000000D41E08: C908150B 0A083109
	v_mov_b32_dpp v16, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D41E10: 7E2002FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 000000D41E18: D501000A 200A150A
	v_add_f32_e32 v11, v15, v23                                // 000000D41E20: 06162F0F
	v_mov_b32_dpp v15, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D41E24: 7E1E02FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, s2                       // 000000D41E2C: D501000C 200A190C
	v_mov_b32_dpp v23, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D41E34: 7E2E02FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s2                          // 000000D41E3C: D5010009 200A1309
	v_add_f32_e32 v10, v10, v16                                // 000000D41E44: 0614210A
	.long 0x7f303880                                           // 000000D41E48: 7F303880
	v_add_f32_e32 v12, v12, v15                                // 000000D41E4C: 06181F0C
	v_mov_b32_dpp v15, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D41E50: 7E1E02FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s2                       // 000000D41E58: D501000B 200A170B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000D41E60: BF870233
	v_mov_b32_dpp v16, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D41E64: 7E2002FA FF01640C
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 000000D41E6C: D501000C 2006190C
	v_add_f32_e32 v9, v9, v23                                  // 000000D41E74: 06122F09
	v_add_f32_e32 v11, v11, v15                                // 000000D41E78: 06161F0B
	v_mov_b32_dpp v23, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D41E7C: 7E2E02FA FF01640A
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 000000D41E84: D501000A 2006150A
	v_add_f32_e32 v12, v12, v16                                // 000000D41E8C: 0618210C
	v_mov_b32_dpp v15, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D41E90: 7E1E02FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 000000D41E98: D5010009 20061309
	v_mov_b32_dpp v16, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D41EA0: 7E2002FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 000000D41EA8: D501000B 2006170B
	v_add_f32_e32 v10, v10, v23                                // 000000D41EB0: 06142F0A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000D41EB4: BF8700B4
	v_add_f32_e32 v9, v9, v15                                  // 000000D41EB8: 06121F09
	v_mov_b32_dpp v15, v12 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D41EBC: 7E1E02FA FF01680C
	v_cndmask_b32_e64 v12, -v12, v12, s0                       // 000000D41EC4: D501000C 2002190C
	v_dual_add_f32 v11, v11, v16 :: v_dual_add_f32 v12, v12, v15// 000000D41ECC: C908210B 0B0C1F0C
	v_mov_b32_dpp v15, v10 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D41ED4: 7E1E02FA FF01680A
	v_cndmask_b32_e64 v10, -v10, v10, s0                       // 000000D41EDC: D501000A 2002150A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000D41EE4: BF870123
	v_mov_b32_e32 v16, v12                                     // 000000D41EE8: 7E20030C
	v_cndmask_b32_e64 v12, -v12, v12, vcc_lo                   // 000000D41EEC: D501000C 21AA190C
	v_permlanex16_b32 v16, v16, s4, 0xfedcba98                 // 000000D41EF4: D65C0010 03FC0910 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000D41F00: BF8700B1
	v_add_f32_e32 v12, v12, v16                                // 000000D41F04: 0618210C
	v_mov_b32_dpp v23, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D41F08: 7E2E02FA FF016809
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 000000D41F10: D5010009 20021309
	v_dual_mul_f32 v12, 0x3db504f3, v12 :: v_dual_add_f32 v9, v9, v23// 000000D41F18: C8C818FF 0C082F09 3DB504F3
	v_mov_b32_dpp v23, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D41F24: 7E2E02FA FF01680B
	v_cndmask_b32_e64 v11, -v11, v11, s0                       // 000000D41F2C: D501000B 2002170B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D41F34: BF870091
	v_add_f32_e32 v11, v11, v23                                // 000000D41F38: 06162F0B
	v_dual_mov_b32 v16, v11 :: v_dual_mov_b32 v27, v9          // 000000D41F3C: CA10010B 101A0109
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000D41F44: D5010009 21AA1309
	v_cndmask_b32_e64 v11, -v11, v11, vcc_lo                   // 000000D41F4C: D501000B 21AA170B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D41F54: BF870213
	v_permlanex16_b32 v16, v16, s4, 0xfedcba98                 // 000000D41F58: D65C0010 03FC0910 FEDCBA98
	v_permlanex16_b32 v27, v27, s4, 0xfedcba98                 // 000000D41F64: D65C001B 03FC091B FEDCBA98
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D41F70: BF870112
	v_add_f32_e32 v11, v11, v16                                // 000000D41F74: 0616210B
	v_add_f32_e32 v9, v9, v27                                  // 000000D41F78: 06123709
	v_add_f32_e32 v10, v10, v15                                // 000000D41F7C: 06141F0A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D41F80: BF870193
	v_mul_f32_e32 v11, 0x3db504f3, v11                         // 000000D41F84: 101616FF 3DB504F3
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 000000D41F8C: 101212FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000D41F94: BF870123
	v_mov_b32_e32 v15, v10                                     // 000000D41F98: 7E1E030A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 000000D41F9C: D501000A 21AA150A
	v_permlanex16_b32 v15, v15, s4, 0xfedcba98                 // 000000D41FA4: D65C000F 03FC090F FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000D41FB0: BF870121
	v_add_f32_e32 v10, v10, v15                                // 000000D41FB4: 06141F0A
	.long 0x7f1e3998                                           // 000000D41FB8: 7F1E3998
	v_mul_f32_e32 v10, 0x3db504f3, v10                         // 000000D41FBC: 101414FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000D41FC4: BF8903F7
	v_fma_mix_f32 v12, v14, v12, neg(0) op_sel_hi:[1,0,0]      // 000000D41FC8: CC20000C 8A02190E
	v_fma_mix_f32 v9, v14, v9, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D41FD0: CC200809 8A02130E
	.long 0x7f1c3998                                           // 000000D41FD8: 7F1C3998
	v_fma_mix_f32 v10, v13, v10, neg(0) op_sel_hi:[1,0,0]      // 000000D41FDC: CC20000A 8A02150D
	v_fma_mix_f32 v11, v13, v11, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D41FE4: CC20080B 8A02170D
	.long 0x7e1e398c                                           // 000000D41FEC: 7E1E398C
	.long 0x7e1c3989                                           // 000000D41FF0: 7E1C3989
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D41FF4: BF870193
	v_bfe_u32 v16, v11, 16, 1                                  // 000000D41FF8: D6100010 0205210B
	v_and_b32_e32 v15, 1, v15                                  // 000000D42000: 361E1E81
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D42004: BF870223
	v_and_b32_e32 v13, 1, v14                                  // 000000D42008: 361A1C81
	v_bfe_u32 v14, v10, 16, 1                                  // 000000D4200C: D610000E 0205210A
	v_add3_u32 v11, v11, v16, 0x7fff                           // 000000D42014: D655000B 03FE210B 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000D42020: BF870244
	v_add3_u32 v12, v12, v15, 0x7fff                           // 000000D42024: D655000C 03FE1F0C 00007FFF
	.long 0x7f1e3998                                           // 000000D42030: 7F1E3998
	v_add3_u32 v9, v9, v13, 0x7fff                             // 000000D42034: D6550009 03FE1B09 00007FFF
	v_add3_u32 v10, v10, v14, 0x7fff                           // 000000D42040: D655000A 03FE1D0A 00007FFF
	.long 0x7e1e398c                                           // 000000D4204C: 7E1E398C
	v_add_nc_u32_e32 v12, s18, v22                             // 000000D42050: 4A182C12
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D42054: BF870214
	v_and_b32_e32 v13, 0xffff0000, v9                          // 000000D42058: 361A12FF FFFF0000
	.long 0x7e30398a                                           // 000000D42060: 7E30398A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D42064: BF870214
	v_and_b32_e32 v14, 0xffff, v15                             // 000000D42068: 361C1EFF 0000FFFF
	v_mad_i64_i32 v[9:10], null, 0x1400, v12, v[17:18]         // 000000D42070: D6FF7C09 044618FF 00001400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D4207C: BF870193
	v_and_or_b32 v11, 0xffff0000, v11, v24                     // 000000D42080: D657000B 046216FF FFFF0000
	v_or_b32_e32 v12, v13, v14                                 // 000000D4208C: 38181D0D
	global_store_b64 v[9:10], v[11:12], off                    // 000000D42090: DC6E0000 007C0B09
	s_or_b32 exec_lo, exec_lo, s5                              // 000000D42098: 8C7E057E
	v_or_b32_e32 v9, 24, v25                                   // 000000D4209C: 38123298
	s_mov_b32 s5, exec_lo                                      // 000000D420A0: BE85007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D420A4: BF870001
	.long 0xd4c4007e                                           // 000000D420A8: D4C4007E
	v_cndmask_b32_e32 v1, s19, v9, vcc_lo                      // 000000D420AC: 02021213
	s_cbranch_execz 203                                        // 000000D420B0: BFA500CB <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x61e0>
	global_load_b64 v[14:15], v19, s[12:13]                    // 000000D420B4: DC560000 0E0C0013
	ds_load_b128 v[10:13], v21                                 // 000000D420BC: DBFC0000 0A000015
	s_mov_b32 s4, 0x76543210                                   // 000000D420C4: BE8400FF 76543210
	s_waitcnt lgkmcnt(0)                                       // 000000D420CC: BF89FC07
	v_dual_add_f32 v16, v10, v11 :: v_dual_add_nc_u32 v9, s18, v9// 000000D420D0: C920170A 10081212
	v_add_f32_e32 v22, v12, v13                                // 000000D420D8: 062C1B0C
	v_dual_sub_f32 v10, v10, v11 :: v_dual_sub_f32 v11, v12, v13// 000000D420DC: C94A170A 0A0A1B0C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D420E4: BF8700A2
	v_add_f32_e32 v12, v16, v22                                // 000000D420E8: 06182D10
	v_sub_f32_e32 v13, v16, v22                                // 000000D420EC: 081A2D10
	v_mov_b32_dpp v22, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D420F0: 7E2C02FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, s3                       // 000000D420F8: D501000D 200E1B0D
	v_add_f32_e32 v16, v10, v11                                // 000000D42100: 0620170A
	v_sub_f32_e32 v10, v10, v11                                // 000000D42104: 0814170A
	v_mov_b32_dpp v11, v12 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D42108: 7E1602FA FF01610C
	v_cndmask_b32_e64 v12, -v12, v12, s3                       // 000000D42110: D501000C 200E190C
	v_add_f32_e32 v13, v13, v22                                // 000000D42118: 061A2D0D
	v_mov_b32_dpp v23, v16 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D4211C: 7E2E02FA FF016110
	v_cndmask_b32_e64 v16, -v16, v16, s3                       // 000000D42124: D5010010 200E2110
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D4212C: BF870114
	v_add_f32_e32 v11, v12, v11                                // 000000D42130: 0616170C
	v_add_f32_e32 v12, v16, v23                                // 000000D42134: 06182F10
	v_mov_b32_dpp v16, v13 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D42138: 7E2002FA FF01620D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000D42140: BF870133
	v_mov_b32_dpp v22, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D42144: 7E2C02FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s2                       // 000000D4214C: D501000B 200A170B
	v_cndmask_b32_e64 v13, -v13, v13, s2                       // 000000D42154: D501000D 200A1B0D
	v_add_f32_e32 v11, v11, v22                                // 000000D4215C: 06162D0B
	v_mov_b32_dpp v24, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D42160: 7E3002FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, s3                       // 000000D42168: D501000A 200E150A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D42170: BF870114
	v_add_f32_e32 v13, v13, v16                                // 000000D42174: 061A210D
	v_add_f32_e32 v10, v10, v24                                // 000000D42178: 0614310A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000D4217C: BF870232
	v_mov_b32_dpp v22, v13 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D42180: 7E2C02FA FF01640D
	v_cndmask_b32_e64 v13, -v13, v13, s1                       // 000000D42188: D501000D 20061B0D
	.long 0x7f303880                                           // 000000D42190: 7F303880
	v_mov_b32_dpp v23, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D42194: 7E2E02FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 000000D4219C: D501000A 200A150A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000D421A4: BF870234
	v_add_f32_e32 v13, v13, v22                                // 000000D421A8: 061A2D0D
	v_mov_b32_dpp v16, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D421AC: 7E2002FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, s2                       // 000000D421B4: D501000C 200A190C
	v_add_f32_e32 v10, v10, v23                                // 000000D421BC: 06142F0A
	v_mov_b32_dpp v23, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D421C0: 7E2E02FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 000000D421C8: D501000B 2006170B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D421D0: BF870214
	v_add_f32_e32 v12, v12, v16                                // 000000D421D4: 0618210C
	v_mov_b32_dpp v16, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D421D8: 7E2002FA FF01640A
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 000000D421E0: D501000A 2006150A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000D421E8: BF8701B1
	v_dual_add_f32 v11, v11, v23 :: v_dual_add_f32 v10, v10, v16// 000000D421EC: C9082F0B 0B0A210A
	v_mov_b32_dpp v16, v13 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D421F4: 7E2002FA FF01680D
	v_cndmask_b32_e64 v13, -v13, v13, s0                       // 000000D421FC: D501000D 20021B0D
	v_mov_b32_dpp v23, v10 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D42204: 7E2E02FA FF01680A
	v_cndmask_b32_e64 v10, -v10, v10, s0                       // 000000D4220C: D501000A 2002150A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000D42214: BF8700B3
	v_add_f32_e32 v13, v13, v16                                // 000000D42218: 061A210D
	v_mov_b32_dpp v16, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D4221C: 7E2002FA FF01680B
	v_cndmask_b32_e64 v11, -v11, v11, s0                       // 000000D42224: D501000B 2002170B
	v_dual_add_f32 v10, v10, v23 :: v_dual_add_f32 v11, v11, v16// 000000D4222C: C9082F0A 0A0A210B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000D42234: BF870231
	v_mov_b32_e32 v27, v10                                     // 000000D42238: 7E36030A
	v_mov_b32_dpp v22, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D4223C: 7E2C02FA FF01640C
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 000000D42244: D501000C 2006190C
	v_mov_b32_e32 v16, v11                                     // 000000D4224C: 7E20030B
	v_cndmask_b32_e64 v11, -v11, v11, vcc_lo                   // 000000D42250: D501000B 21AA170B
	v_permlanex16_b32 v27, v27, s4, 0xfedcba98                 // 000000D42258: D65C001B 03FC091B FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D42264: BF870214
	v_add_f32_e32 v12, v12, v22                                // 000000D42268: 06182D0C
	v_permlanex16_b32 v16, v16, s4, 0xfedcba98                 // 000000D4226C: D65C0010 03FC0910 FEDCBA98
	v_mov_b32_e32 v22, v13                                     // 000000D42278: 7E2C030D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 000000D4227C: D501000D 21AA1B0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D42284: BF870214
	v_mov_b32_dpp v23, v12 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D42288: 7E2E02FA FF01680C
	v_add_f32_e32 v11, v11, v16                                // 000000D42290: 0616210B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000D42294: BF870234
	v_permlanex16_b32 v22, v22, s4, 0xfedcba98                 // 000000D42298: D65C0016 03FC0916 FEDCBA98
	v_cndmask_b32_e64 v12, -v12, v12, s0                       // 000000D422A4: D501000C 2002190C
	.long 0x7f203998                                           // 000000D422AC: 7F203998
	v_mul_f32_e32 v11, 0x3db504f3, v11                         // 000000D422B0: 101616FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D422B8: BF870093
	v_dual_add_f32 v13, v13, v22 :: v_dual_add_f32 v12, v12, v23// 000000D422BC: C9082D0D 0D0C2F0C
	v_mul_f32_e32 v13, 0x3db504f3, v13                         // 000000D422C4: 101A1AFF 3DB504F3
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 000000D422CC: D501000A 21AA150A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D422D4: BF8701A3
	v_mov_b32_e32 v22, v12                                     // 000000D422D8: 7E2C030C
	v_cndmask_b32_e64 v12, -v12, v12, vcc_lo                   // 000000D422DC: D501000C 21AA190C
	v_add_f32_e32 v10, v10, v27                                // 000000D422E4: 0614370A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D422E8: BF870113
	v_permlanex16_b32 v22, v22, s4, 0xfedcba98                 // 000000D422EC: D65C0016 03FC0916 FEDCBA98
	v_mul_f32_e32 v10, 0x3db504f3, v10                         // 000000D422F8: 101414FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D42300: BF870092
	v_add_f32_e32 v12, v12, v22                                // 000000D42304: 06182D0C
	v_mul_f32_e32 v12, 0x3db504f3, v12                         // 000000D42308: 101818FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000D42310: BF8903F7
	v_fma_mix_f32 v13, v15, v13, neg(0) op_sel_hi:[1,0,0]      // 000000D42314: CC20000D 8A021B0F
	v_fma_mix_f32 v10, v15, v10, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D4231C: CC20080A 8A02150F
	.long 0x7f1e3998                                           // 000000D42324: 7F1E3998
	v_fma_mix_f32 v11, v14, v11, neg(0) op_sel_hi:[1,0,0]      // 000000D42328: CC20000B 8A02170E
	v_fma_mix_f32 v12, v14, v12, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D42330: CC20080C 8A02190E
	.long 0x7e20398d                                           // 000000D42338: 7E20398D
	.long 0x7e1e398a                                           // 000000D4233C: 7E1E398A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D42340: BF870193
	v_bfe_u32 v22, v12, 16, 1                                  // 000000D42344: D6100016 0205210C
	v_and_b32_e32 v16, 1, v16                                  // 000000D4234C: 36202081
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D42350: BF8701A3
	v_and_b32_e32 v14, 1, v15                                  // 000000D42354: 361C1E81
	v_bfe_u32 v15, v11, 16, 1                                  // 000000D42358: D610000F 0205210B
	v_add3_u32 v13, v13, v16, 0x7fff                           // 000000D42360: D655000D 03FE210D 00007FFF
	.long 0x7f203998                                           // 000000D4236C: 7F203998
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D42370: BF870214
	v_add3_u32 v10, v10, v14, 0x7fff                           // 000000D42374: D655000A 03FE1D0A 00007FFF
	v_add3_u32 v11, v11, v15, 0x7fff                           // 000000D42380: D655000B 03FE1F0B 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D4238C: BF870224
	.long 0x7e20398d                                           // 000000D42390: 7E20398D
	v_add3_u32 v13, v12, v22, 0x7fff                           // 000000D42394: D655000D 03FE2D0C 00007FFF
	v_and_b32_e32 v12, 0xffff0000, v10                         // 000000D423A0: 361814FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000D423A8: BF8701B4
	.long 0x7e30398b                                           // 000000D423AC: 7E30398B
	v_mad_i64_i32 v[9:10], null, 0x1400, v9, v[17:18]          // 000000D423B0: D6FF7C09 044612FF 00001400
	v_and_b32_e32 v14, 0xffff, v16                             // 000000D423BC: 361C20FF 0000FFFF
	v_and_or_b32 v11, 0xffff0000, v13, v24                     // 000000D423C4: D657000B 04621AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2)                            // 000000D423D0: BF870002
	v_or_b32_e32 v12, v12, v14                                 // 000000D423D4: 38181D0C
	global_store_b64 v[9:10], v[11:12], off                    // 000000D423D8: DC6E0000 007C0B09
	s_or_b32 exec_lo, exec_lo, s5                              // 000000D423E0: 8C7E057E
	v_or_b32_e32 v9, 32, v25                                   // 000000D423E4: 381232A0
	s_mov_b32 s5, exec_lo                                      // 000000D423E8: BE85007E
	s_waitcnt_vscnt null, 0x0                                  // 000000D423EC: BC7C0000
	s_barrier                                                  // 000000D423F0: BFBD0000
	buffer_gl0_inv                                             // 000000D423F4: E0AC0000 00000000
	ds_store_2addr_b32 v26, v1, v2 offset1:2                   // 000000D423FC: D8380200 0002011A
	ds_store_2addr_b32 v26, v3, v4 offset0:4 offset1:6         // 000000D42404: D8380604 0004031A
	ds_store_2addr_b32 v26, v5, v6 offset0:8 offset1:10        // 000000D4240C: D8380A08 0006051A
	ds_store_2addr_b32 v26, v7, v8 offset0:12 offset1:14       // 000000D42414: D8380E0C 0008071A
	s_waitcnt lgkmcnt(0)                                       // 000000D4241C: BF89FC07
	s_barrier                                                  // 000000D42420: BFBD0000
	buffer_gl0_inv                                             // 000000D42424: E0AC0000 00000000
	.long 0xd4c4007e                                           // 000000D4242C: D4C4007E
	v_cndmask_b32_e32 v1, s19, v9, vcc_lo                      // 000000D42430: 02021213
	s_cbranch_execz 198                                        // 000000D42434: BFA500C6 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x6550>
	global_load_b64 v[5:6], v19, s[12:13]                      // 000000D42438: DC560000 050C0013
	ds_load_b128 v[1:4], v20                                   // 000000D42440: DBFC0000 01000014
	s_mov_b32 s4, 0x76543210                                   // 000000D42448: BE8400FF 76543210
	s_waitcnt lgkmcnt(0)                                       // 000000D42450: BF89FC07
	v_dual_add_f32 v7, v1, v2 :: v_dual_add_f32 v8, v3, v4     // 000000D42454: C9080501 07080903
	v_dual_sub_f32 v1, v1, v2 :: v_dual_sub_f32 v2, v3, v4     // 000000D4245C: C94A0501 01020903
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D42464: BF870112
	v_add_f32_e32 v3, v7, v8                                   // 000000D42468: 06061107
	v_dual_sub_f32 v4, v7, v8 :: v_dual_add_f32 v7, v1, v2     // 000000D4246C: C9481107 04060501
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D42474: BF870001
	v_mov_b32_dpp v8, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D42478: 7E1002FA FF016104
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000D42480: D5010004 200E0904
	v_sub_f32_e32 v1, v1, v2                                   // 000000D42488: 08020501
	v_mov_b32_dpp v2, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D4248C: 7E0402FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 000000D42494: D5010003 200E0703
	v_mov_b32_dpp v10, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D4249C: 7E1402FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s3                          // 000000D424A4: D5010007 200E0F07
	v_add_f32_e32 v4, v4, v8                                   // 000000D424AC: 06081104
	v_mov_b32_dpp v11, v1 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D424B0: 7E1602FA FF016101
	v_cndmask_b32_e64 v1, -v1, v1, s3                          // 000000D424B8: D5010001 200E0301
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D424C0: BF870091
	v_dual_add_f32 v2, v3, v2 :: v_dual_add_f32 v1, v1, v11    // 000000D424C4: C9080503 02001701
	v_mov_b32_dpp v8, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D424CC: 7E1002FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s2                          // 000000D424D4: D5010002 200A0502
	v_add_f32_e32 v3, v7, v10                                  // 000000D424DC: 06061507
	v_mov_b32_dpp v7, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D424E0: 7E0E02FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s2                          // 000000D424E8: D5010004 200A0904
	v_mov_b32_dpp v10, v1 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D424F0: 7E1402FA FF016201
	v_cndmask_b32_e64 v1, -v1, v1, s2                          // 000000D424F8: D5010001 200A0301
	v_add_f32_e32 v2, v2, v8                                   // 000000D42500: 06041102
	.long 0x7f163880                                           // 000000D42504: 7F163880
	v_add_f32_e32 v4, v4, v7                                   // 000000D42508: 06080F04
	v_mov_b32_dpp v7, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D4250C: 7E0E02FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s2                          // 000000D42514: D5010003 200A0703
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000D4251C: BF870253
	v_mov_b32_dpp v8, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D42520: 7E1002FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000D42528: D5010004 20060904
	v_add_f32_e32 v1, v1, v10                                  // 000000D42530: 06021501
	v_mov_b32_dpp v10, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D42534: 7E1402FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 000000D4253C: D5010002 20060502
	v_dual_add_f32 v3, v3, v7 :: v_dual_add_f32 v4, v4, v8     // 000000D42544: C9080F03 03041104
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D4254C: BF870224
	v_mov_b32_dpp v7, v1 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D42550: 7E0E02FA FF016401
	v_cndmask_b32_e64 v1, -v1, v1, s1                          // 000000D42558: D5010001 20060301
	v_add_f32_e32 v2, v2, v10                                  // 000000D42560: 06041502
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D42564: BF870224
	v_mov_b32_dpp v8, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D42568: 7E1002FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 000000D42570: D5010003 20060703
	v_add_f32_e32 v1, v1, v7                                   // 000000D42578: 06020F01
	v_mov_b32_dpp v7, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D4257C: 7E0E02FA FF016804
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 000000D42584: D5010004 20020904
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000D4258C: BF8701B1
	v_dual_add_f32 v3, v3, v8 :: v_dual_add_f32 v4, v4, v7     // 000000D42590: C9081103 03040F04
	v_mov_b32_dpp v7, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D42598: 7E0E02FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 000000D425A0: D5010002 20020502
	v_mov_b32_e32 v8, v4                                       // 000000D425A8: 7E100304
	v_mov_b32_dpp v10, v1 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D425AC: 7E1402FA FF016801
	v_cndmask_b32_e64 v1, -v1, v1, s0                          // 000000D425B4: D5010001 20020301
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000D425BC: D5010004 21AA0904
	v_add_f32_e32 v2, v2, v7                                   // 000000D425C4: 06040F02
	v_permlanex16_b32 v8, v8, s4, 0xfedcba98                   // 000000D425C8: D65C0008 03FC0908 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000D425D4: BF870234
	v_add_f32_e32 v1, v1, v10                                  // 000000D425D8: 06021501
	v_mov_b32_dpp v10, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D425DC: 7E1402FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 000000D425E4: D5010003 20020703
	v_dual_add_f32 v4, v4, v8 :: v_dual_mov_b32 v7, v2         // 000000D425EC: C9101104 04060102
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D425F4: BF870224
	v_mov_b32_e32 v12, v1                                      // 000000D425F8: 7E180301
	v_cndmask_b32_e64 v1, -v1, v1, vcc_lo                      // 000000D425FC: D5010001 21AA0301
	v_add_f32_e32 v3, v3, v10                                  // 000000D42604: 06061503
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 000000D42608: D5010002 21AA0502
	v_permlanex16_b32 v7, v7, s4, 0xfedcba98                   // 000000D42610: D65C0007 03FC0907 FEDCBA98
	v_permlanex16_b32 v12, v12, s4, 0xfedcba98                 // 000000D4261C: D65C000C 03FC090C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D42628: BF8701A4
	v_mov_b32_e32 v8, v3                                       // 000000D4262C: 7E100303
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000D42630: D5010003 21AA0703
	v_add_f32_e32 v1, v1, v12                                  // 000000D42638: 06021901
	v_mul_f32_e32 v4, 0x3db504f3, v4                           // 000000D4263C: 100808FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000D42644: BF8701C4
	v_permlanex16_b32 v8, v8, s4, 0xfedcba98                   // 000000D42648: D65C0008 03FC0908 FEDCBA98
	v_add_f32_e32 v2, v2, v7                                   // 000000D42654: 06040F02
	.long 0x7f0e398b                                           // 000000D42658: 7F0E398B
	v_mul_f32_e32 v1, 0x3db504f3, v1                           // 000000D4265C: 100202FF 3DB504F3
	v_dual_add_f32 v3, v3, v8 :: v_dual_mul_f32 v2, 0x3db504f3, v2// 000000D42664: C9061103 030204FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D42670: BF870001
	v_mul_f32_e32 v3, 0x3db504f3, v3                           // 000000D42674: 100606FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000D4267C: BF8903F7
	v_fma_mix_f32 v4, v6, v4, neg(0) op_sel_hi:[1,0,0]         // 000000D42680: CC200004 8A020906
	v_fma_mix_f32 v1, v6, v1, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D42688: CC200801 8A020306
	.long 0x7f0c398b                                           // 000000D42690: 7F0C398B
	v_fma_mix_f32 v2, v5, v2, neg(0) op_sel_hi:[1,0,0]         // 000000D42694: CC200002 8A020505
	v_fma_mix_f32 v3, v5, v3, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D4269C: CC200803 8A020705
	.long 0x7e0e3984                                           // 000000D426A4: 7E0E3984
	.long 0x7e0c3981                                           // 000000D426A8: 7E0C3981
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D426AC: BF870193
	v_bfe_u32 v8, v3, 16, 1                                    // 000000D426B0: D6100008 02052103
	v_and_b32_e32 v7, 1, v7                                    // 000000D426B8: 360E0E81
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D426BC: BF870223
	v_and_b32_e32 v5, 1, v6                                    // 000000D426C0: 360A0C81
	v_bfe_u32 v6, v2, 16, 1                                    // 000000D426C4: D6100006 02052102
	v_add3_u32 v3, v3, v8, 0x7fff                              // 000000D426CC: D6550003 03FE1103 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000D426D8: BF870244
	v_add3_u32 v4, v4, v7, 0x7fff                              // 000000D426DC: D6550004 03FE0F04 00007FFF
	.long 0x7f0e398b                                           // 000000D426E8: 7F0E398B
	v_add3_u32 v1, v1, v5, 0x7fff                              // 000000D426EC: D6550001 03FE0B01 00007FFF
	v_add3_u32 v2, v2, v6, 0x7fff                              // 000000D426F8: D6550002 03FE0D02 00007FFF
	.long 0x7e0e3984                                           // 000000D42704: 7E0E3984
	v_add_nc_u32_e32 v4, s18, v9                               // 000000D42708: 4A081212
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D4270C: BF870214
	v_and_b32_e32 v5, 0xffff0000, v1                           // 000000D42710: 360A02FF FFFF0000
	.long 0x7e163982                                           // 000000D42718: 7E163982
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D4271C: BF870214
	v_and_b32_e32 v6, 0xffff, v7                               // 000000D42720: 360C0EFF 0000FFFF
	v_mad_i64_i32 v[1:2], null, 0x1400, v4, v[17:18]           // 000000D42728: D6FF7C01 044608FF 00001400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D42734: BF870193
	v_and_or_b32 v3, 0xffff0000, v3, v11                       // 000000D42738: D6570003 042E06FF FFFF0000
	v_or_b32_e32 v4, v5, v6                                    // 000000D42744: 38080D05
	global_store_b64 v[1:2], v[3:4], off                       // 000000D42748: DC6E0000 007C0301
	s_or_b32 exec_lo, exec_lo, s5                              // 000000D42750: 8C7E057E
	v_or_b32_e32 v1, 40, v25                                   // 000000D42754: 380232A8
	s_mov_b32 s5, exec_lo                                      // 000000D42758: BE85007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D4275C: BF870001
	.long 0xd4c4007e                                           // 000000D42760: D4C4007E
	v_cndmask_b32_e32 v1, s19, v1, vcc_lo                      // 000000D42764: 02020213
	s_cbranch_execz 200                                        // 000000D42768: BFA500C8 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x688c>
	global_load_b64 v[6:7], v19, s[12:13]                      // 000000D4276C: DC560000 060C0013
	ds_load_b128 v[2:5], v21                                   // 000000D42774: DBFC0000 02000015
	s_waitcnt lgkmcnt(0)                                       // 000000D4277C: BF89FC07
	v_dual_add_f32 v8, v2, v3 :: v_dual_add_nc_u32 v1, s18, v1 // 000000D42780: C9200702 08000212
	v_dual_add_f32 v9, v4, v5 :: v_dual_sub_f32 v2, v2, v3     // 000000D42788: C90A0B04 09020702
	v_sub_f32_e32 v3, v4, v5                                   // 000000D42790: 08060B04
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D42794: BF8701A2
	v_sub_f32_e32 v5, v8, v9                                   // 000000D42798: 080A1308
	v_add_f32_e32 v4, v8, v9                                   // 000000D4279C: 06081308
	v_add_f32_e32 v8, v2, v3                                   // 000000D427A0: 06100702
	s_delay_alu instid0(VALU_DEP_3)                            // 000000D427A4: BF870003
	v_mov_b32_dpp v9, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D427A8: 7E1202FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 000000D427B0: D5010005 200E0B05
	v_sub_f32_e32 v2, v2, v3                                   // 000000D427B8: 08040702
	v_mov_b32_dpp v3, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D427BC: 7E0602FA FF016104
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000D427C4: D5010004 200E0904
	v_mov_b32_dpp v10, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D427CC: 7E1402FA FF016108
	v_add_f32_e32 v5, v5, v9                                   // 000000D427D4: 060A1305
	v_mov_b32_dpp v11, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D427D8: 7E1602FA FF016102
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 000000D427E0: D5010002 200E0502
	v_cndmask_b32_e64 v8, -v8, v8, s3                          // 000000D427E8: D5010008 200E1108
	v_add_f32_e32 v3, v4, v3                                   // 000000D427F0: 06060704
	s_mov_b32 s3, 0x76543210                                   // 000000D427F4: BE8300FF 76543210
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D427FC: BF870193
	v_add_f32_e32 v2, v2, v11                                  // 000000D42800: 06041702
	v_add_f32_e32 v4, v8, v10                                  // 000000D42804: 06081508
	v_mov_b32_dpp v8, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D42808: 7E1002FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s2                          // 000000D42810: D5010005 200A0B05
	.long 0x7f163880                                           // 000000D42818: 7F163880
	v_mov_b32_dpp v10, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D4281C: 7E1402FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s2                          // 000000D42824: D5010002 200A0502
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000D4282C: BF8700B1
	v_dual_add_f32 v5, v5, v8 :: v_dual_add_f32 v2, v2, v10    // 000000D42830: C9081105 05021502
	v_mov_b32_dpp v9, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D42838: 7E1202FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s2                          // 000000D42840: D5010003 200A0703
	v_add_f32_e32 v3, v3, v9                                   // 000000D42848: 06061303
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D4284C: BF8701A4
	v_mov_b32_dpp v9, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D42850: 7E1202FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s1                          // 000000D42858: D5010005 20060B05
	v_mov_b32_dpp v10, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D42860: 7E1402FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 000000D42868: D5010003 20060703
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000D42870: BF8700B3
	v_add_f32_e32 v5, v5, v9                                   // 000000D42874: 060A1305
	v_mov_b32_dpp v8, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D42878: 7E1002FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s2                          // 000000D42880: D5010004 200A0904
	v_dual_add_f32 v3, v3, v10 :: v_dual_add_f32 v4, v4, v8    // 000000D42888: C9081503 03041104
	v_mov_b32_dpp v8, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D42890: 7E1002FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 000000D42898: D5010002 20060502
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D428A0: BF8701A3
	v_mov_b32_dpp v9, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D428A4: 7E1202FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000D428AC: D5010004 20060904
	v_add_f32_e32 v2, v2, v8                                   // 000000D428B4: 06041102
	v_mov_b32_dpp v8, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D428B8: 7E1002FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 000000D428C0: D5010005 20020B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000D428C8: BF8701B1
	v_dual_add_f32 v4, v4, v9 :: v_dual_add_f32 v5, v5, v8     // 000000D428CC: C9081304 04041105
	v_mov_b32_dpp v8, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D428D4: 7E1002FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 000000D428DC: D5010003 20020703
	v_mov_b32_e32 v9, v5                                       // 000000D428E4: 7E120305
	v_mov_b32_dpp v10, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D428E8: 7E1402FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 000000D428F0: D5010002 20020502
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000D428F8: D5010005 21AA0B05
	v_add_f32_e32 v3, v3, v8                                   // 000000D42900: 06061103
	v_permlanex16_b32 v9, v9, s3, 0xfedcba98                   // 000000D42904: D65C0009 03FC0709 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000D42910: BF8701B4
	v_add_f32_e32 v2, v2, v10                                  // 000000D42914: 06041502
	v_mov_b32_dpp v10, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D42918: 7E1402FA FF016804
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 000000D42920: D5010004 20020904
	v_dual_add_f32 v5, v5, v9 :: v_dual_mov_b32 v12, v2        // 000000D42928: C9101305 050C0102
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 000000D42930: D5010002 21AA0502
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D42938: BF870222
	v_dual_add_f32 v4, v4, v10 :: v_dual_mul_f32 v5, 0x3db504f3, v5// 000000D4293C: C9061504 04040AFF 3DB504F3
	v_mov_b32_e32 v8, v3                                       // 000000D42948: 7E100303
	v_permlanex16_b32 v12, v12, s3, 0xfedcba98                 // 000000D4294C: D65C000C 03FC070C FEDCBA98
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000D42958: D5010003 21AA0703
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000D42960: BF8701B4
	v_mov_b32_e32 v9, v4                                       // 000000D42964: 7E120304
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000D42968: D5010004 21AA0904
	v_permlanex16_b32 v8, v8, s3, 0xfedcba98                   // 000000D42970: D65C0008 03FC0708 FEDCBA98
	v_permlanex16_b32 v9, v9, s3, 0xfedcba98                   // 000000D4297C: D65C0009 03FC0709 FEDCBA98
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D42988: BF8701A2
	v_add_f32_e32 v3, v3, v8                                   // 000000D4298C: 06061103
	.long 0x7f10398b                                           // 000000D42990: 7F10398B
	v_add_f32_e32 v4, v4, v9                                   // 000000D42994: 06081304
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D42998: BF870113
	v_dual_add_f32 v2, v2, v12 :: v_dual_mul_f32 v3, 0x3db504f3, v3// 000000D4299C: C9061902 020206FF 3DB504F3
	v_mul_f32_e32 v4, 0x3db504f3, v4                           // 000000D429A8: 100808FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000D429B0: BF870132
	v_mul_f32_e32 v2, 0x3db504f3, v2                           // 000000D429B4: 100404FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000D429BC: BF8903F7
	v_fma_mix_f32 v5, v7, v5, neg(0) op_sel_hi:[1,0,0]         // 000000D429C0: CC200005 8A020B07
	v_fma_mix_f32 v2, v7, v2, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D429C8: CC200802 8A020507
	.long 0x7f0e398b                                           // 000000D429D0: 7F0E398B
	v_fma_mix_f32 v3, v6, v3, neg(0) op_sel_hi:[1,0,0]         // 000000D429D4: CC200003 8A020706
	v_fma_mix_f32 v4, v6, v4, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D429DC: CC200804 8A020906
	.long 0x7e103985                                           // 000000D429E4: 7E103985
	.long 0x7e0e3982                                           // 000000D429E8: 7E0E3982
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D429EC: BF870193
	v_bfe_u32 v9, v4, 16, 1                                    // 000000D429F0: D6100009 02052104
	v_and_b32_e32 v8, 1, v8                                    // 000000D429F8: 36101081
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D429FC: BF8701A3
	v_and_b32_e32 v6, 1, v7                                    // 000000D42A00: 360C0E81
	v_bfe_u32 v7, v3, 16, 1                                    // 000000D42A04: D6100007 02052103
	v_add3_u32 v5, v5, v8, 0x7fff                              // 000000D42A0C: D6550005 03FE1105 00007FFF
	.long 0x7f10398b                                           // 000000D42A18: 7F10398B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D42A1C: BF870214
	v_add3_u32 v2, v2, v6, 0x7fff                              // 000000D42A20: D6550002 03FE0D02 00007FFF
	v_add3_u32 v3, v3, v7, 0x7fff                              // 000000D42A2C: D6550003 03FE0F03 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D42A38: BF870224
	.long 0x7e103985                                           // 000000D42A3C: 7E103985
	v_add3_u32 v5, v4, v9, 0x7fff                              // 000000D42A40: D6550005 03FE1304 00007FFF
	v_and_b32_e32 v4, 0xffff0000, v2                           // 000000D42A4C: 360804FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000D42A54: BF8701B4
	.long 0x7e163983                                           // 000000D42A58: 7E163983
	v_mad_i64_i32 v[1:2], null, 0x1400, v1, v[17:18]           // 000000D42A5C: D6FF7C01 044602FF 00001400
	v_and_b32_e32 v6, 0xffff, v8                               // 000000D42A68: 360C10FF 0000FFFF
	v_and_or_b32 v3, 0xffff0000, v5, v11                       // 000000D42A70: D6570003 042E0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2)                            // 000000D42A7C: BF870002
	v_or_b32_e32 v4, v4, v6                                    // 000000D42A80: 38080D04
	global_store_b64 v[1:2], v[3:4], off                       // 000000D42A84: DC6E0000 007C0301
	s_or_b32 exec_lo, exec_lo, s5                              // 000000D42A8C: 8C7E057E
	s_waitcnt_vscnt null, 0x0                                  // 000000D42A90: BC7C0000
	s_barrier                                                  // 000000D42A94: BFBD0000
	s_mov_b32 s0, 0                                            // 000000D42A98: BE800080
	s_mov_b32 s3, -1                                           // 000000D42A9C: BE8300C1
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 000000D42AA0: 916A007E
	s_cbranch_vccnz 4415                                       // 000000D42AA4: BFA4113F <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0xada4>
	s_cmp_gt_i32 s20, 1                                        // 000000D42AA8: BF028114
	s_mov_b32 s0, -1                                           // 000000D42AAC: BE8000C1
	s_cbranch_scc0 2482                                        // 000000D42AB0: BFA109B2 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x8f7c>
	v_or_b32_e32 v2, 0x100, v0                                 // 000000D42AB4: 380400FF 00000100
	v_lshrrev_b32_e32 v1, 4, v0                                // 000000D42ABC: 32020084
	v_lshlrev_b32_e32 v3, 3, v0                                // 000000D42AC0: 30060083
	s_add_i32 s0, s19, -1                                      // 000000D42AC4: 8100C113
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D42AC8: BF870193
	v_lshrrev_b32_e32 v2, 4, v2                                // 000000D42ACC: 32040484
	v_min_i32_e32 v4, s0, v1                                   // 000000D42AD0: 22080200
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D42AD4: BF870193
	v_and_b32_e32 v63, 0x78, v3                                // 000000D42AD8: 367E06FF 00000078
	v_min_i32_e32 v5, s0, v2                                   // 000000D42AE0: 220A0400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D42AE4: BF870193
	v_add_nc_u32_e32 v3, s18, v4                               // 000000D42AE8: 4A060812
	v_lshlrev_b32_e32 v7, 1, v63                               // 000000D42AEC: 300E7E81
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D42AF0: BF870193
	v_add_nc_u32_e32 v5, s18, v5                               // 000000D42AF4: 4A0A0A12
	v_mad_i64_i32 v[3:4], null, 0x500, v3, 0                   // 000000D42AF8: D6FF7C03 020206FF 00000500
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D42B04: BF870093
	.long 0xd700000a                                           // 000000D42B08: D700000A
	v_cndmask_b32_e32 v1, s10, v7, vcc_lo                      // 000000D42B0C: 02020E0A
	v_add_co_ci_u32_e64 v11, null, s11, 0, s0                  // 000000D42B10: D5207C0B 0001000B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D42B18: BF870224
	v_mad_i64_i32 v[5:6], null, 0x500, v5, 0                   // 000000D42B1C: D6FF7C05 02020AFF 00000500
	.long 0xd44c0000                                           // 000000D42B28: D44C0000
	v_cndmask_b32_e32 v1, 0x200, v0, vcc_lo                    // 000000D42B2C: 020200FF 00000200
	.long 0xd7006a08                                           // 000000D42B34: D7006A08
	v_cndmask_b32_e32 v1, v10, v3, vcc_lo                      // 000000D42B38: 0202070A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D42B3C: BF870211
	v_add_co_ci_u32_e64 v9, null, v11, v4, vcc_lo              // 000000D42B40: D5207C09 01AA090B
	.long 0xd7006a0a                                           // 000000D42B48: D7006A0A
	v_cndmask_b32_e32 v1, v10, v5, vcc_lo                      // 000000D42B4C: 02020B0A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D42B50: BF870001
	v_add_co_ci_u32_e64 v11, null, v11, v6, vcc_lo             // 000000D42B54: D5207C0B 01AA0D0B
	s_clause 0x1                                               // 000000D42B5C: BF850001
	global_load_b128 v[34:37], v[8:9], off                     // 000000D42B60: DC5E0000 227C0008
	global_load_b128 v[38:41], v[10:11], off                   // 000000D42B68: DC5E0000 267C000A
	s_and_saveexec_b32 s1, s0                                  // 000000D42B70: BE812000
	s_cbranch_execz 6                                          // 000000D42B74: BFA50006 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x6990>
	v_mad_u32_u24 v8, 0x110, v1, v7                            // 000000D42B78: D60B0008 041E02FF 00000110
	s_waitcnt vmcnt(1)                                         // 000000D42B84: BF8907F7
	ds_store_b128 v8, v[34:37]                                 // 000000D42B88: DB7C0000 00002208
	s_or_b32 exec_lo, exec_lo, s1                              // 000000D42B90: 8C7E017E
	.long 0xd44c0001                                           // 000000D42B94: D44C0001
	v_cndmask_b32_e32 v1, 0x100, v0, vcc_lo                    // 000000D42B98: 020200FF 00000100
	v_mul_u32_u24_e32 v65, 0x110, v2                           // 000000D42BA0: 168204FF 00000110
	s_and_saveexec_b32 s2, s1                                  // 000000D42BA8: BE822001
	s_cbranch_execz 5                                          // 000000D42BAC: BFA50005 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x69c4>
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D42BB0: BF870001
	v_add_nc_u32_e32 v2, v7, v65                               // 000000D42BB4: 4A048307
	s_waitcnt vmcnt(0)                                         // 000000D42BB8: BF8903F7
	ds_store_b128 v2, v[38:41]                                 // 000000D42BBC: DB7C0000 00002602
	s_or_b32 exec_lo, exec_lo, s2                              // 000000D42BC4: 8C7E027E
	v_and_b32_e32 v62, 31, v0                                  // 000000D42BC8: 367C009F
	s_mul_i32 s5, s16, 0xc8000                                 // 000000D42BCC: 9605FF10 000C8000
	s_mul_i32 s12, s17, 0xa000                                 // 000000D42BD4: 960CFF11 0000A000
	s_mul_hi_i32 s4, s16, 0xc8000                              // 000000D42BDC: 9704FF10 000C8000
	s_mul_hi_i32 s13, s17, 0xa000                              // 000000D42BE4: 970DFF11 0000A000
	v_dual_mov_b32 v2, 0 :: v_dual_lshlrev_b32 v7, 5, v62      // 000000D42BEC: CA220080 02067C85
	v_and_b32_e32 v64, 15, v0                                  // 000000D42BF4: 3680008F
	s_add_u32 s5, s5, s12                                      // 000000D42BF8: 80050C05
	s_addc_u32 s4, s4, s13                                     // 000000D42BFC: 82040D04
	s_delay_alu instid0(VALU_DEP_2)                            // 000000D42C00: BF870002
	v_add_nc_u32_e32 v8, 0x3f0, v7                             // 000000D42C04: 4A100EFF 000003F0
	v_mul_u32_u24_e32 v66, 0x110, v1                           // 000000D42C0C: 168402FF 00000110
	v_lshlrev_b32_e32 v9, 4, v64                               // 000000D42C14: 30128084
	v_mov_b32_e32 v11, v2                                      // 000000D42C18: 7E160302
	v_mov_b32_e32 v12, v2                                      // 000000D42C1C: 7E180302
	v_lshrrev_b32_e32 v1, 5, v8                                // 000000D42C20: 32021085
	v_mov_b32_e32 v13, v2                                      // 000000D42C24: 7E1A0302
	.long 0xd7006a05                                           // 000000D42C28: D7006A05
	v_cndmask_b32_e32 v1, v5, v9, vcc_lo                       // 000000D42C2C: 02021305
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D42C30: BF870211
	v_add_co_ci_u32_e64 v6, null, 0, v6, vcc_lo                // 000000D42C34: D5207C06 01AA0C80
	v_subrev_nc_u32_e32 v1, 32, v1                             // 000000D42C3C: 4E0202A0
	v_cmp_ne_u32_e32 vcc_lo, 0, v62                            // 000000D42C40: 7C9A7C80
	v_mov_b32_e32 v14, v2                                      // 000000D42C44: 7E1C0302
	v_mov_b32_e32 v15, v2                                      // 000000D42C48: 7E1E0302
	v_mov_b32_e32 v16, v2                                      // 000000D42C4C: 7E200302
	v_mov_b32_e32 v17, v2                                      // 000000D42C50: 7E220302
	v_cndmask_b32_e32 v1, 31, v1, vcc_lo                       // 000000D42C54: 0202029F
	.long 0xd7006a09                                           // 000000D42C58: D7006A09
	v_cndmask_b32_e32 v1, v3, v9, vcc_lo                       // 000000D42C5C: 02021303
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D42C60: BF870191
	v_add_co_ci_u32_e64 v10, null, 0, v4, vcc_lo               // 000000D42C64: D5207C0A 01AA0880
	v_cmp_gt_i32_e32 vcc_lo, 31, v1                            // 000000D42C6C: 7C88029F
	v_and_b32_e32 v3, 0x7e0, v8                                // 000000D42C70: 360610FF 000007E0
	.long 0xd44c0002                                           // 000000D42C78: D44C0002
	v_cndmask_b32_e32 v1, 16, v62, vcc_lo                      // 000000D42C7C: 02027C90
	s_mov_b32 s3, 0                                            // 000000D42C80: BE830080
	s_mov_b32 s12, 0xdcd12d                                    // 000000D42C84: BE8C00FF 00DCD12D
	v_cndmask_b32_e64 v4, 0xffffffe1, 1, vcc_lo                // 000000D42C8C: D5010004 01A902FF FFFFFFE1
	.long 0xd7006a05                                           // 000000D42C98: D7006A05
	v_cndmask_b32_e32 v1, s10, v5, vcc_lo                      // 000000D42C9C: 02020A0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D42CA0: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s11, v6, vcc_lo              // 000000D42CA4: D5207C06 01AA0C0B
	v_sub_nc_u32_e32 v7, v3, v7                                // 000000D42CAC: 4C0E0F03
	.long 0xd7006a2a                                           // 000000D42CB0: D7006A2A
	v_cndmask_b32_e32 v1, 0x100, v5, vcc_lo                    // 000000D42CB4: 02020AFF 00000100
	v_lshlrev_b32_e32 v5, 2, v0                                // 000000D42CBC: 300A0082
	v_add_nc_u32_e32 v3, v4, v1                                // 000000D42CC0: 4A060304
	v_add_co_ci_u32_e64 v43, null, 0, v6, vcc_lo               // 000000D42CC4: D5207C2B 01AA0C80
	v_add_nc_u32_e32 v68, 0xfffffc30, v7                       // 000000D42CCC: 4A880EFF FFFFFC30
	.long 0xd7006a07                                           // 000000D42CD4: D7006A07
	v_cndmask_b32_e32 v1, s10, v9, vcc_lo                      // 000000D42CD8: 0202120A
	v_and_or_b32 v9, 0x380, v5, s5                             // 000000D42CDC: D6570009 00160AFF 00000380
	.long 0xd73c0005                                           // 000000D42CE8: D73C0005
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000D42CEC: 02020282
	v_add_co_ci_u32_e64 v8, null, s11, v10, vcc_lo             // 000000D42CF0: D5207C08 01AA140B
	v_mov_b32_e32 v10, s4                                      // 000000D42CF8: 7E140204
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000D42CFC: 3408069F
	.long 0xd7006a2c                                           // 000000D42D00: D7006A2C
	v_cndmask_b32_e32 v1, 0x100, v7, vcc_lo                    // 000000D42D04: 02020EFF 00000100
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D42D0C: BF8700A1
	v_add_co_ci_u32_e64 v45, null, 0, v8, vcc_lo               // 000000D42D10: D5207C2D 01AA1080
	.long 0xd7006a01                                           // 000000D42D18: D7006A01
	v_cndmask_b32_e32 v1, v9, v5, vcc_lo                       // 000000D42D1C: 02020B09
	v_add_co_ci_u32_e64 v5, null, v10, v6, vcc_lo              // 000000D42D20: D5207C05 01AA0D0A
	.long 0xd73c0003                                           // 000000D42D28: D73C0003
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 000000D42D2C: 02020682
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D42D30: BF870093
	.long 0xd7006a01                                           // 000000D42D34: D7006A01
	v_cndmask_b32_e32 v1, s8, v1, vcc_lo                       // 000000D42D38: 02020208
	v_add_co_ci_u32_e64 v69, null, s9, v5, vcc_lo              // 000000D42D3C: D5207C45 01AA0A09
	v_lshl_or_b32 v5, v62, 2, v9                               // 000000D42D44: D6560005 0425053E
	v_mov_b32_e32 v6, s4                                       // 000000D42D4C: 7E0C0204
	.long 0xd7006a03                                           // 000000D42D50: D7006A03
	v_cndmask_b32_e32 v1, v9, v3, vcc_lo                       // 000000D42D54: 02020709
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D42D58: BF870211
	v_add_co_ci_u32_e64 v4, null, v10, v4, vcc_lo              // 000000D42D5C: D5207C04 01AA090A
	.long 0xd7006a46                                           // 000000D42D64: D7006A46
	v_cndmask_b32_e32 v1, s8, v5, vcc_lo                       // 000000D42D68: 02020A08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D42D6C: BF870211
	v_add_co_ci_u32_e64 v71, null, s9, v6, vcc_lo              // 000000D42D70: D5207C47 01AA0C09
	.long 0xd7006a48                                           // 000000D42D78: D7006A48
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 000000D42D7C: 02020608
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D42D80: BF870001
	v_add_co_ci_u32_e64 v73, null, s9, v4, vcc_lo              // 000000D42D84: D5207C49 01AA0809
	v_mov_b32_e32 v3, v2                                       // 000000D42D8C: 7E060302
	v_mul_u32_u24_e32 v67, 0x110, v64                          // 000000D42D90: 168680FF 00000110
	v_mov_b32_e32 v4, v2                                       // 000000D42D98: 7E080302
	v_mov_b32_e32 v5, v2                                       // 000000D42D9C: 7E0A0302
	v_mov_b32_e32 v6, v2                                       // 000000D42DA0: 7E0C0302
	v_mov_b32_e32 v7, v2                                       // 000000D42DA4: 7E0E0302
	v_mov_b32_e32 v8, v2                                       // 000000D42DA8: 7E100302
	v_mov_b32_e32 v9, v2                                       // 000000D42DAC: 7E120302
	v_mov_b32_e32 v10, v2                                      // 000000D42DB0: 7E140302
	s_mov_b64 s[4:5], 0                                        // 000000D42DB4: BE840180
	s_movk_i32 s13, 0x83                                       // 000000D42DB8: B00D0083
	s_movk_i32 s21, 0x1eee                                     // 000000D42DBC: B0151EEE
	s_mov_b32 s22, 0x76543210                                  // 000000D42DC0: BE9600FF 76543210
	s_movk_i32 s23, 0x60                                       // 000000D42DC8: B0170060
	s_movk_i32 s24, 0x80                                       // 000000D42DCC: B0180080
	s_movk_i32 s25, 0xa0                                       // 000000D42DD0: B01900A0
	s_movk_i32 s26, 0xc0                                       // 000000D42DD4: B01A00C0
	s_movk_i32 s27, 0xe0                                       // 000000D42DD8: B01B00E0
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000D42DDC: BF890007
	s_barrier                                                  // 000000D42DE0: BFBD0000
	buffer_gl0_inv                                             // 000000D42DE4: E0AC0000 00000000
	s_branch 22                                                // 000000D42DEC: BFA00016 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x6c48>
	s_or_b32 exec_lo, exec_lo, s28                             // 000000D42DF0: 8C7E1C7E
	.long 0xd7006a2a                                           // 000000D42DF4: D7006A2A
	v_cndmask_b32_e32 v1, 0x100, v42, vcc_lo                   // 000000D42DF8: 020254FF 00000100
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D42E00: BF8700A1
	v_add_co_ci_u32_e64 v43, null, 0, v43, vcc_lo              // 000000D42E04: D5207C2B 01AA5680
	.long 0xd7006a2c                                           // 000000D42E0C: D7006A2C
	v_cndmask_b32_e32 v1, 0x100, v44, vcc_lo                   // 000000D42E10: 020258FF 00000100
	v_add_co_ci_u32_e64 v45, null, 0, v45, vcc_lo              // 000000D42E18: D5207C2D 01AA5A80
	s_add_u32 s4, s4, 0x2000                                   // 000000D42E20: 8004FF04 00002000
	s_addc_u32 s5, s5, 0                                       // 000000D42E28: 82058005
	s_add_i32 s3, s3, 1                                        // 000000D42E2C: 81038103
	s_cmpk_eq_u32 s4, 0xa000                                   // 000000D42E30: B484A000
	s_waitcnt lgkmcnt(0)                                       // 000000D42E34: BF89FC07
	s_barrier                                                  // 000000D42E38: BFBD0000
	buffer_gl0_inv                                             // 000000D42E3C: E0AC0000 00000000
	s_cbranch_scc1 1341                                        // 000000D42E44: BFA2053D <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x813c>
	s_cmpk_lg_u32 s4, 0x8000                                   // 000000D42E48: B5048000
	s_cselect_b32 s28, -1, 0                                   // 000000D42E4C: 981C80C1
	s_cmpk_eq_u32 s4, 0x8000                                   // 000000D42E50: B4848000
	s_cbranch_scc1 4                                           // 000000D42E54: BFA20004 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x6c68>
	global_load_b128 v[34:37], v[44:45], off                   // 000000D42E58: DC5E0000 227C002C
	global_load_b128 v[38:41], v[42:43], off                   // 000000D42E60: DC5E0000 267C002A
	.long 0xd7006a12                                           // 000000D42E68: D7006A12
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 000000D42E6C: 02000901
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D42E70: BF8700A1
	v_add_co_ci_u32_e64 v19, null, s5, v69, vcc_lo             // 000000D42E74: D5207C13 01AA8A05
	.long 0xd7006a14                                           // 000000D42E7C: D7006A14
	v_cndmask_b32_e32 v0, v72, v4, vcc_lo                      // 000000D42E80: 02000948
	v_add_co_ci_u32_e64 v21, null, s5, v73, vcc_lo             // 000000D42E84: D5207C15 01AA9205
	.long 0xd7006a16                                           // 000000D42E8C: D7006A16
	v_cndmask_b32_e32 v0, v70, v4, vcc_lo                      // 000000D42E90: 02000946
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D42E94: BF870001
	v_add_co_ci_u32_e64 v23, null, s5, v71, vcc_lo             // 000000D42E98: D5207C17 01AA8E05
	s_clause 0xb                                               // 000000D42EA0: BF85000B
	global_load_b32 v47, v[18:19], off                         // 000000D42EA4: DC520000 2F7C0012
	global_load_b32 v46, v[20:21], off                         // 000000D42EAC: DC520000 2E7C0014
	global_load_b32 v74, v[22:23], off                         // 000000D42EB4: DC520000 4A7C0016
	global_load_b32 v49, v[18:19], off offset:1024             // 000000D42EBC: DC520400 317C0012
	global_load_b32 v48, v[20:21], off offset:1024             // 000000D42EC4: DC520400 307C0014
	global_load_b32 v75, v[22:23], off offset:1024             // 000000D42ECC: DC520400 4B7C0016
	global_load_b32 v51, v[18:19], off offset:2048             // 000000D42ED4: DC520800 337C0012
	global_load_b32 v50, v[20:21], off offset:2048             // 000000D42EDC: DC520800 327C0014
	global_load_b32 v76, v[22:23], off offset:2048             // 000000D42EE4: DC520800 4C7C0016
	global_load_b32 v54, v[20:21], off offset:3072             // 000000D42EEC: DC520C00 367C0014
	global_load_b32 v55, v[18:19], off offset:3072             // 000000D42EF4: DC520C00 377C0012
	global_load_b32 v77, v[22:23], off offset:3072             // 000000D42EFC: DC520C00 4D7C0016
	.long 0xd7006a50                                           // 000000D42F04: D7006A50
	v_cndmask_b32_e32 v1, 0x1000, v18, vcc_lo                  // 000000D42F08: 020224FF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D42F10: BF8700A1
	v_add_co_ci_u32_e64 v81, null, 0, v19, vcc_lo              // 000000D42F14: D5207C51 01AA2680
	.long 0xd7006a3a                                           // 000000D42F1C: D7006A3A
	v_cndmask_b32_e32 v1, 0x1000, v20, vcc_lo                  // 000000D42F20: 020228FF 00001000
	v_add_co_ci_u32_e64 v59, null, 0, v21, vcc_lo              // 000000D42F28: D5207C3B 01AA2A80
	.long 0xd7006a52                                           // 000000D42F30: D7006A52
	v_cndmask_b32_e32 v1, 0x1000, v22, vcc_lo                  // 000000D42F34: 02022CFF 00001000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D42F3C: BF870001
	v_add_co_ci_u32_e64 v83, null, 0, v23, vcc_lo              // 000000D42F40: D5207C53 01AA2E80
	s_clause 0xb                                               // 000000D42F48: BF85000B
	global_load_b32 v61, v[80:81], off                         // 000000D42F4C: DC520000 3D7C0050
	global_load_b32 v60, v[58:59], off                         // 000000D42F54: DC520000 3C7C003A
	global_load_b32 v79, v[82:83], off                         // 000000D42F5C: DC520000 4F7C0052
	global_load_b32 v53, v[80:81], off offset:1024             // 000000D42F64: DC520400 357C0050
	global_load_b32 v52, v[58:59], off offset:1024             // 000000D42F6C: DC520400 347C003A
	global_load_b32 v57, v[80:81], off offset:2048             // 000000D42F74: DC520800 397C0050
	global_load_b32 v56, v[58:59], off offset:2048             // 000000D42F7C: DC520800 387C003A
	global_load_b32 v58, v[58:59], off offset:3072             // 000000D42F84: DC520C00 3A7C003A
	global_load_b32 v59, v[80:81], off offset:3072             // 000000D42F8C: DC520C00 3B7C0050
	global_load_b32 v160, v[82:83], off offset:1024            // 000000D42F94: DC520400 A07C0052
	global_load_b32 v161, v[82:83], off offset:2048            // 000000D42F9C: DC520800 A17C0052
	global_load_b32 v78, v[82:83], off offset:3072             // 000000D42FA4: DC520C00 4E7C0052
	s_bfe_i32 s29, s3, 0x10000                                 // 000000D42FAC: 939DFF03 00010000
	s_and_b32 s30, s3, 1                                       // 000000D42FB4: 8B1E8103
	s_and_b32 s31, s29, 0x4400                                 // 000000D42FB8: 8B1FFF1D 00004400
	s_cmp_eq_u32 s30, 0                                        // 000000D42FC0: BF06801E
	s_cselect_b32 s29, -1, 0                                   // 000000D42FC4: 981D80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000D42FC8: BF870009
	s_and_b32 s30, s29, exec_lo                                // 000000D42FCC: 8B1E7E1D
	s_cselect_b32 s30, 32, 0x4420                              // 000000D42FD0: 981EFFA0 00004420
	s_cselect_b32 s33, s23, 0x4460                             // 000000D42FD8: 9821FF17 00004460
	s_waitcnt vmcnt(22)                                        // 000000D42FE0: BF895BF7
	.long 0xd73d002e                                           // 000000D42FE4: D73D002E
	v_cndmask_b32_e32 v1, v68, v46, vcc_lo                     // 000000D42FE8: 02025D44
	s_waitcnt vmcnt(21)                                        // 000000D42FEC: BF8957F7
	v_bfe_u32 v128, v74, 12, 16                                // 000000D42FF0: D6100080 0241194A
	v_mul_u32_u24_e32 v136, s12, v128                          // 000000D42FF8: 1711000C
	v_mul_u32_u24_e32 v128, s13, v128                          // 000000D42FFC: 1701000D
	s_waitcnt vmcnt(18)                                        // 000000D43000: BF894BF7
	v_bfe_u32 v131, v75, 12, 16                                // 000000D43004: D6100083 0241194B
	v_mul_u32_u24_e32 v140, s12, v131                          // 000000D4300C: 1719060C
	v_mul_u32_u24_e32 v131, s13, v131                          // 000000D43010: 1707060D
	v_lshl_add_u32 v128, v128, 24, v136                        // 000000D43014: D6460080 06213180
	s_delay_alu instid0(VALU_DEP_2)                            // 000000D4301C: BF870002
	v_lshl_add_u32 v131, v131, 24, v140                        // 000000D43020: D6460083 06313183
	v_bfe_u32 v129, v74, 8, 16                                 // 000000D43028: D6100081 0241114A
	v_bfe_u32 v132, v75, 8, 16                                 // 000000D43030: D6100084 0241114B
	v_mul_u32_u24_e32 v137, s12, v129                          // 000000D43038: 1713020C
	v_mul_u32_u24_e32 v129, s13, v129                          // 000000D4303C: 1703020D
	v_mul_u32_u24_e32 v141, s12, v132                          // 000000D43040: 171B080C
	v_mul_u32_u24_e32 v132, s13, v132                          // 000000D43044: 1709080D
	v_lshl_add_u32 v129, v129, 24, v137                        // 000000D43048: D6460081 06253181
	v_lshl_add_u32 v132, v132, 24, v141                        // 000000D43050: D6460084 06353184
	v_sad_u8 v128, v128, 0, 0x6400                             // 000000D43058: D6220080 03FD0180 00006400
	v_sad_u8 v131, v131, 0, 0x6400                             // 000000D43064: D6220083 03FD0183 00006400
	.long 0xd73d002f                                           // 000000D43070: D73D002F
	v_cndmask_b32_e32 v1, v68, v48, vcc_lo                     // 000000D43074: 02026144
	v_sad_u8 v129, v129, 0, 0x6400                             // 000000D43078: D6220081 03FD0181 00006400
	v_sad_u8 v132, v132, 0, 0x6400                             // 000000D43084: D6220084 03FD0184 00006400
	v_and_b32_e32 v128, 0xffff, v128                           // 000000D43090: 370100FF 0000FFFF
	v_and_b32_e32 v131, 0xffff, v131                           // 000000D43098: 370706FF 0000FFFF
	v_bfe_u32 v133, v75, 4, 16                                 // 000000D430A0: D6100085 0241094B
	v_mul_u32_u24_e32 v142, s12, v133                          // 000000D430A8: 171D0A0C
	v_mul_u32_u24_e32 v133, s13, v133                          // 000000D430AC: 170B0A0D
	v_lshl_or_b32 v128, v129, 16, v128                         // 000000D430B0: D6560080 06012181
	v_lshl_or_b32 v129, v132, 16, v131                         // 000000D430B8: D6560081 060D2184
	v_lshl_add_u32 v133, v133, 24, v142                        // 000000D430C0: D6460085 06393185
	v_bfe_u32 v130, v74, 4, 16                                 // 000000D430C8: D6100082 0241094A
	v_mul_u32_u24_e32 v138, s12, v130                          // 000000D430D0: 1715040C
	v_mul_u32_u24_e32 v130, s13, v130                          // 000000D430D4: 1705040D
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D430D8: BF870001
	v_lshl_add_u32 v130, v130, 24, v138                        // 000000D430DC: D6460082 06293182
	v_bfe_u32 v138, v47, 4, 16                                 // 000000D430E4: D610008A 0241092F
	v_pk_fma_f16 v129, v129, s21, 0xc931 op_sel_hi:[1,0,0]     // 000000D430EC: CC0E0081 0BFC2B81 0000C931
	v_and_b32_e32 v75, 0xffff, v75                             // 000000D430F8: 369696FF 0000FFFF
	v_mul_u32_u24_e32 v143, s12, v75                           // 000000D43100: 171E960C
	v_mul_u32_u24_e32 v75, s13, v75                            // 000000D43104: 1696960D
	v_mul_u32_u24_e32 v157, s12, v138                          // 000000D43108: 173B140C
	v_mul_u32_u24_e32 v138, s13, v138                          // 000000D4310C: 1715140D
	v_lshl_add_u32 v75, v75, 24, v143                          // 000000D43110: D646004B 063D314B
	v_sad_u8 v133, v133, 0, 0x6400                             // 000000D43118: D6220085 03FD0185 00006400
	v_lshl_add_u32 v138, v138, 24, v157                        // 000000D43124: D646008A 0675318A
	v_bfe_u32 v136, v47, 12, 16                                // 000000D4312C: D6100088 0241192F
	v_bfe_u32 v137, v47, 8, 16                                 // 000000D43134: D6100089 0241112F
	v_and_b32_e32 v47, 0xffff, v47                             // 000000D4313C: 365E5EFF 0000FFFF
	v_mul_u32_u24_e32 v158, s12, v47                           // 000000D43144: 173C5E0C
	v_mul_u32_u24_e32 v47, s13, v47                            // 000000D43148: 165E5E0D
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000D4314C: D622004B 03FD014B 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 000000D43158: BF870002
	v_lshl_add_u32 v47, v47, 24, v158                          // 000000D4315C: D646002F 0679312F
	v_and_b32_e32 v133, 0xffff, v133                           // 000000D43164: 370B0AFF 0000FFFF
	v_sad_u8 v138, v138, 0, 0x6400                             // 000000D4316C: D622008A 03FD018A 00006400
	s_waitcnt vmcnt(16)                                        // 000000D43178: BF8943F7
	.long 0xd73d0030                                           // 000000D4317C: D73D0030
	v_cndmask_b32_e32 v1, v68, v50, vcc_lo                     // 000000D43180: 02026544
	s_waitcnt vmcnt(15)                                        // 000000D43184: BF893FF7
	v_bfe_u32 v51, v76, 12, 16                                 // 000000D43188: D6100033 0241194C
	v_sad_u8 v47, v47, 0, 0x6400                               // 000000D43190: D622002F 03FD012F 00006400
	v_lshl_or_b32 v75, v75, 16, v133                           // 000000D4319C: D656004B 0615214B
	v_and_b32_e32 v133, 0xffff, v138                           // 000000D431A4: 370B14FF 0000FFFF
	v_mul_u32_u24_e32 v144, s12, v51                           // 000000D431AC: 1720660C
	v_mul_u32_u24_e32 v145, s13, v51                           // 000000D431B0: 1722660D
	v_lshl_add_u32 v142, v145, 24, v144                        // 000000D431B4: D646008E 06413191
	s_waitcnt vmcnt(13)                                        // 000000D431BC: BF8937F7
	.long 0xd73d0031                                           // 000000D431C0: D73D0031
	v_cndmask_b32_e32 v1, v68, v54, vcc_lo                     // 000000D431C4: 02026D44
	v_lshl_or_b32 v47, v47, 16, v133                           // 000000D431C8: D656002F 0615212F
	v_bfe_u32 v134, v76, 8, 16                                 // 000000D431D0: D6100086 0241114C
	v_mul_u32_u24_e32 v146, s12, v134                          // 000000D431D8: 17250C0C
	v_mul_u32_u24_e32 v134, s13, v134                          // 000000D431DC: 170D0C0D
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D431E0: BF870001
	v_lshl_add_u32 v134, v134, 24, v146                        // 000000D431E4: D6460086 06493186
	v_pk_fma_f16 v47, v47, s21, 0xc931 op_sel_hi:[1,0,0]       // 000000D431EC: CC0E002F 0BFC2B2F 0000C931
	v_and_b32_e32 v74, 0xffff, v74                             // 000000D431F8: 369494FF 0000FFFF
	v_sad_u8 v130, v130, 0, 0x6400                             // 000000D43200: D6220082 03FD0182 00006400
	v_sad_u8 v142, v142, 0, 0x6400                             // 000000D4320C: D622008E 03FD018E 00006400
	v_bfe_u32 v145, v49, 4, 16                                 // 000000D43218: D6100091 02410931
	v_mov_b32_e32 v157, v47                                    // 000000D43220: 7F3A032F
	v_mul_u32_u24_e32 v139, s12, v74                           // 000000D43224: 1716940C
	v_mul_u32_u24_e32 v74, s13, v74                            // 000000D43228: 1694940D
	v_lshl_add_u32 v74, v74, 24, v139                          // 000000D4322C: D646004A 062D314A
	v_mul_u32_u24_e32 v168, s12, v145                          // 000000D43234: 1751220C
	v_mul_u32_u24_e32 v145, s13, v145                          // 000000D43238: 1723220D
	v_sad_u8 v134, v134, 0, 0x6400                             // 000000D4323C: D6220086 03FD0186 00006400
	v_lshl_add_u32 v145, v145, 24, v168                        // 000000D43248: D6460091 06A13191
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000D43250: D622004A 03FD014A 00006400
	v_and_b32_e32 v130, 0xffff, v130                           // 000000D4325C: 370504FF 0000FFFF
	v_and_b32_e32 v142, 0xffff, v142                           // 000000D43264: 371D1CFF 0000FFFF
	s_waitcnt vmcnt(12)                                        // 000000D4326C: BF8933F7
	v_bfe_u32 v54, v77, 8, 16                                  // 000000D43270: D6100036 0241114D
	v_sad_u8 v145, v145, 0, 0x6400                             // 000000D43278: D6220091 03FD0191 00006400
	v_bfe_u32 v50, v77, 12, 16                                 // 000000D43284: D6100032 0241194D
	v_lshl_or_b32 v74, v74, 16, v130                           // 000000D4328C: D656004A 0609214A
	v_lshl_or_b32 v130, v134, 16, v142                         // 000000D43294: D6560082 06392186
	v_mul_u32_u24_e32 v150, s13, v50                           // 000000D4329C: 172C640D
	v_mul_u32_u24_e32 v151, s12, v54                           // 000000D432A0: 172E6C0C
	v_mul_u32_u24_e32 v54, s13, v54                            // 000000D432A4: 166C6C0D
	v_bfe_u32 v155, v46, 8, 16                                 // 000000D432A8: D610009B 0241112E
	v_bfe_u32 v143, v49, 12, 16                                // 000000D432B0: D610008F 02411931
	v_mul_u32_u24_e32 v149, s12, v50                           // 000000D432B8: 172A640C
	v_lshl_add_u32 v146, v150, 24, v149                        // 000000D432BC: D6460092 06553196
	v_lshl_add_u32 v54, v54, 24, v151                          // 000000D432C4: D6460036 065D3136
	v_mul_u32_u24_e32 v150, s12, v155                          // 000000D432CC: 172D360C
	v_mul_u32_u24_e32 v151, s13, v155                          // 000000D432D0: 172F360D
	v_mul_u32_u24_e32 v155, s12, v136                          // 000000D432D4: 1737100C
	v_mul_u32_u24_e32 v136, s13, v136                          // 000000D432D8: 1711100D
	v_mul_u32_u24_e32 v166, s12, v143                          // 000000D432DC: 174D1E0C
	v_mul_u32_u24_e32 v143, s13, v143                          // 000000D432E0: 171F1E0D
	v_lshl_add_u32 v136, v136, 24, v155                        // 000000D432E4: D6460088 066D3188
	v_lshl_add_u32 v143, v143, 24, v166                        // 000000D432EC: D646008F 0699318F
	v_bfe_u32 v55, v77, 4, 16                                  // 000000D432F4: D6100037 0241094D
	v_and_b32_e32 v138, 0xffff, v145                           // 000000D432FC: 371522FF 0000FFFF
	v_pk_fma_f16 v145, v130, s21, 0xc931 op_sel_hi:[1,0,0]     // 000000D43304: CC0E0091 0BFC2B82 0000C931
	v_and_b32_e32 v77, 0xffff, v77                             // 000000D43310: 369A9AFF 0000FFFF
	v_mul_u32_u24_e32 v152, s12, v55                           // 000000D43318: 17306E0C
	v_mul_u32_u24_e32 v55, s13, v55                            // 000000D4331C: 166E6E0D
	v_mul_u32_u24_e32 v153, s12, v77                           // 000000D43320: 17329A0C
	v_mul_u32_u24_e32 v77, s13, v77                            // 000000D43324: 169A9A0D
	v_bfe_u32 v156, v46, 4, 16                                 // 000000D43328: D610009C 0241092E
	v_bfe_u32 v144, v49, 8, 16                                 // 000000D43330: D6100090 02411131
	v_lshl_add_u32 v55, v55, 24, v152                          // 000000D43338: D6460037 06613137
	v_lshl_add_u32 v77, v77, 24, v153                          // 000000D43340: D646004D 0665314D
	v_mul_u32_u24_e32 v152, s12, v156                          // 000000D43348: 1731380C
	v_mul_u32_u24_e32 v153, s13, v156                          // 000000D4334C: 1733380D
	v_mul_u32_u24_e32 v156, s12, v137                          // 000000D43350: 1739120C
	v_mul_u32_u24_e32 v137, s13, v137                          // 000000D43354: 1713120D
	v_mul_u32_u24_e32 v167, s12, v144                          // 000000D43358: 174F200C
	v_mul_u32_u24_e32 v144, s13, v144                          // 000000D4335C: 1721200D
	v_lshl_add_u32 v137, v137, 24, v156                        // 000000D43360: D6460089 06713189
	v_lshl_add_u32 v144, v144, 24, v167                        // 000000D43368: D6460090 069D3190
	v_sad_u8 v136, v136, 0, 0x6400                             // 000000D43370: D6220088 03FD0188 00006400
	v_sad_u8 v143, v143, 0, 0x6400                             // 000000D4337C: D622008F 03FD018F 00006400
	s_waitcnt vmcnt(10)                                        // 000000D43388: BF892BF7
	.long 0xd73d0032                                           // 000000D4338C: D73D0032
	v_cndmask_b32_e32 v1, v68, v60, vcc_lo                     // 000000D43390: 02027944
	v_sad_u8 v137, v137, 0, 0x6400                             // 000000D43394: D6220089 03FD0189 00006400
	v_sad_u8 v144, v144, 0, 0x6400                             // 000000D433A0: D6220090 03FD0190 00006400
	v_and_b32_e32 v132, 0xffff, v136                           // 000000D433AC: 370910FF 0000FFFF
	v_and_b32_e32 v136, 0xffff, v143                           // 000000D433B4: 37111EFF 0000FFFF
	v_bfe_u32 v135, v76, 4, 16                                 // 000000D433BC: D6100087 0241094C
	v_and_b32_e32 v76, 0xffff, v76                             // 000000D433C4: 369898FF 0000FFFF
	v_mul_u32_u24_e32 v147, s12, v135                          // 000000D433CC: 17270E0C
	v_lshl_or_b32 v130, v137, 16, v132                         // 000000D433D0: D6560082 06112189
	v_lshl_or_b32 v132, v144, 16, v136                         // 000000D433D8: D6560084 06212190
	v_mul_u32_u24_e32 v135, s13, v135                          // 000000D433E0: 170F0E0D
	v_mul_u32_u24_e32 v148, s12, v76                           // 000000D433E4: 1728980C
	v_mul_u32_u24_e32 v76, s13, v76                            // 000000D433E8: 1698980D
	s_waitcnt vmcnt(9)                                         // 000000D433EC: BF8927F7
	v_bfe_u32 v51, v79, 12, 16                                 // 000000D433F0: D6100033 0241194F
	v_bfe_u32 v154, v46, 12, 16                                // 000000D433F8: D610009A 0241192E
	v_lshl_add_u32 v135, v135, 24, v147                        // 000000D43400: D6460087 064D3187
	v_lshl_add_u32 v76, v76, 24, v148                          // 000000D43408: D646004C 0651314C
	v_mul_u32_u24_e32 v147, s12, v51                           // 000000D43410: 1726660C
	v_mul_u32_u24_e32 v51, s13, v51                            // 000000D43414: 1666660D
	v_mul_u32_u24_e32 v148, s12, v154                          // 000000D43418: 1729340C
	v_mul_u32_u24_e32 v149, s13, v154                          // 000000D4341C: 172B340D
	v_bfe_u32 v170, v50, 12, 16                                // 000000D43420: D61000AA 02411932
	v_bfe_u32 v171, v50, 8, 16                                 // 000000D43428: D61000AB 02411132
	v_lshl_add_u32 v51, v51, 24, v147                          // 000000D43430: D6460033 064D3133
	v_lshl_add_u32 v147, v149, 24, v148                        // 000000D43438: D6460093 06513195
	v_lshl_add_u32 v148, v151, 24, v150                        // 000000D43440: D6460094 06593197
	v_lshl_add_u32 v149, v153, 24, v152                        // 000000D43448: D6460095 06613199
	v_mul_u32_u24_e32 v150, s12, v170                          // 000000D43450: 172D540C
	v_mul_u32_u24_e32 v151, s13, v170                          // 000000D43454: 172F540D
	v_mul_u32_u24_e32 v153, s13, v171                          // 000000D43458: 1733560D
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000D4345C: D6220037 03FD0137 00006400
	v_mul_u32_u24_e32 v152, s12, v171                          // 000000D43468: 1731560C
	v_lshl_add_u32 v150, v151, 24, v150                        // 000000D4346C: D6460096 06593197
	v_lshl_add_u32 v151, v153, 24, v152                        // 000000D43474: D6460097 06613199
	v_pk_fma_f16 v153, v132, s21, 0xc931 op_sel_hi:[1,0,0]     // 000000D4347C: CC0E0099 0BFC2B84 0000C931
	v_and_b32_e32 v46, 0xffff, v46                             // 000000D43488: 365C5CFF 0000FFFF
	v_sad_u8 v77, v77, 0, 0x6400                               // 000000D43490: D622004D 03FD014D 00006400
	v_and_b32_e32 v55, 0xffff, v55                             // 000000D4349C: 366E6EFF 0000FFFF
	v_sad_u8 v147, v147, 0, 0x6400                             // 000000D434A4: D6220093 03FD0193 00006400
	v_mov_b32_e32 v167, v153                                   // 000000D434B0: 7F4E0399
	v_mul_u32_u24_e32 v154, s12, v46                           // 000000D434B4: 17345C0C
	v_mul_u32_u24_e32 v46, s13, v46                            // 000000D434B8: 165C5C0D
	v_lshl_add_u32 v46, v46, 24, v154                          // 000000D434BC: D646002E 0669312E
	v_sad_u8 v149, v149, 0, 0x6400                             // 000000D434C4: D6220095 03FD0195 00006400
	v_bfe_u32 v141, v48, 4, 16                                 // 000000D434D0: D610008D 02410930
	v_mul_u32_u24_e32 v164, s12, v141                          // 000000D434D8: 17491A0C
	v_mul_u32_u24_e32 v141, s13, v141                          // 000000D434DC: 171B1A0D
	v_sad_u8 v148, v148, 0, 0x6400                             // 000000D434E0: D6220094 03FD0194 00006400
	v_lshl_or_b32 v55, v77, 16, v55                            // 000000D434EC: D6560037 04DD214D
	v_and_b32_e32 v77, 0xffff, v147                            // 000000D434F4: 369B26FF 0000FFFF
	v_sad_u8 v135, v135, 0, 0x6400                             // 000000D434FC: D6220087 03FD0187 00006400
	v_lshl_add_u32 v141, v141, 24, v164                        // 000000D43508: D646008D 0691318D
	v_sad_u8 v46, v46, 0, 0x6400                               // 000000D43510: D622002E 03FD012E 00006400
	v_and_b32_e32 v131, 0xffff, v149                           // 000000D4351C: 37072AFF 0000FFFF
	v_bfe_u32 v139, v48, 12, 16                                // 000000D43524: D610008B 02411930
	v_bfe_u32 v140, v48, 8, 16                                 // 000000D4352C: D610008C 02411130
	v_and_b32_e32 v48, 0xffff, v48                             // 000000D43534: 366060FF 0000FFFF
	v_mul_u32_u24_e32 v162, s12, v139                          // 000000D4353C: 1745160C
	v_mul_u32_u24_e32 v139, s13, v139                          // 000000D43540: 1717160D
	v_mul_u32_u24_e32 v165, s12, v48                           // 000000D43544: 174A600C
	v_mul_u32_u24_e32 v48, s13, v48                            // 000000D43548: 1660600D
	v_lshl_or_b32 v77, v148, 16, v77                           // 000000D4354C: D656004D 05352194
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000D43554: D622004C 03FD014C 00006400
	v_lshl_add_u32 v139, v139, 24, v162                        // 000000D43560: D646008B 0689318B
	v_lshl_add_u32 v48, v48, 24, v165                          // 000000D43568: D6460030 06953130
	v_and_b32_e32 v135, 0xffff, v135                           // 000000D43570: 370F0EFF 0000FFFF
	v_sad_u8 v141, v141, 0, 0x6400                             // 000000D43578: D622008D 03FD018D 00006400
	v_lshl_or_b32 v46, v46, 16, v131                           // 000000D43584: D656002E 060D212E
	v_pk_fma_f16 v128, v128, s21, 0xc931 op_sel_hi:[1,0,0]     // 000000D4358C: CC0E0080 0BFC2B80 0000C931
	v_add_nc_u32_e32 v30, s31, v67                             // 000000D43598: 4A3C861F
	v_mul_u32_u24_e32 v163, s12, v140                          // 000000D4359C: 1747180C
	v_mul_u32_u24_e32 v140, s13, v140                          // 000000D435A0: 1719180D
	v_pk_fma_f16 v77, v77, s21, 0xc931 op_sel_hi:[1,0,0]       // 000000D435A4: CC0E004D 0BFC2B4D 0000C931
	v_bfe_u32 v172, v50, 4, 16                                 // 000000D435B0: D61000AC 02410932
	v_lshl_add_u32 v140, v140, 24, v163                        // 000000D435B8: D646008C 068D318C
	v_mul_u32_u24_e32 v154, s12, v172                          // 000000D435C0: 1735580C
	v_mul_u32_u24_e32 v155, s13, v172                          // 000000D435C4: 1737580D
	v_sad_u8 v139, v139, 0, 0x6400                             // 000000D435C8: D622008B 03FD018B 00006400
	v_sad_u8 v48, v48, 0, 0x6400                               // 000000D435D4: D6220030 03FD0130 00006400
	v_lshl_add_u32 v152, v155, 24, v154                        // 000000D435E0: D6460098 0669319B
	v_lshl_or_b32 v76, v76, 16, v135                           // 000000D435E8: D656004C 061D214C
	v_and_b32_e32 v135, 0xffff, v141                           // 000000D435F0: 370F1AFF 0000FFFF
	v_pk_fma_f16 v74, v74, s21, 0xc931 op_sel_hi:[1,0,0]       // 000000D435F8: CC0E004A 0BFC2B4A 0000C931
	v_pk_fma_f16 v46, v46, s21, 0xc931 op_sel_hi:[1,0,0]       // 000000D43604: CC0E002E 0BFC2B2E 0000C931
	v_mov_b32_e32 v133, v128                                   // 000000D43610: 7F0A0380
	ds_load_b128 v[18:21], v30                                 // 000000D43614: DBFC0000 1200001E
	ds_load_b128 v[22:25], v30 offset:16                       // 000000D4361C: DBFC0010 1600001E
	ds_load_b128 v[26:29], v30 offset:4352                     // 000000D43624: DBFC1100 1A00001E
	ds_load_b128 v[30:33], v30 offset:4368                     // 000000D4362C: DBFC1110 1E00001E
	v_dual_mov_b32 v132, v77 :: v_dual_and_b32 v49, 0xffff, v49// 000000D43634: CA24014D 843062FF 0000FFFF
	v_mul_u32_u24_e32 v169, s12, v49                           // 000000D43640: 1752620C
	v_mul_u32_u24_e32 v49, s13, v49                            // 000000D43644: 1662620D
	v_sad_u8 v146, v146, 0, 0x6400                             // 000000D43648: D6220092 03FD0192 00006400
	v_add_nc_u32_e32 v92, s30, v67                             // 000000D43654: 4AB8861E
	v_lshl_add_u32 v49, v49, 24, v169                          // 000000D43658: D6460031 06A53131
	v_sad_u8 v140, v140, 0, 0x6400                             // 000000D43660: D622008C 03FD018C 00006400
	v_and_b32_e32 v134, 0xffff, v139                           // 000000D4366C: 370D16FF 0000FFFF
	v_sad_u8 v141, v152, 0, 0x6400                             // 000000D43674: D622008D 03FD0198 00006400
	v_lshl_or_b32 v48, v48, 16, v135                           // 000000D43680: D6560030 061D2130
	v_dual_mov_b32 v135, v74 :: v_dual_mov_b32 v136, v129      // 000000D43688: CA10014A 87880181
	v_mov_b32_e32 v152, v46                                    // 000000D43690: 7F30032E
	v_sad_u8 v54, v54, 0, 0x6400                               // 000000D43694: D6220036 03FD0136 00006400
	v_and_b32_e32 v146, 0xffff, v146                           // 000000D436A0: 372524FF 0000FFFF
	v_sad_u8 v49, v49, 0, 0x6400                               // 000000D436A8: D6220031 03FD0131 00006400
	v_lshl_or_b32 v131, v140, 16, v134                         // 000000D436B4: D6560083 0619218C
	v_permlanex16_b32 v133, v133, s22, 0xfedcba98              // 000000D436BC: D65C0085 03FC2D85 FEDCBA98
	v_permlanex16_b32 v135, v135, s22, 0xfedcba98              // 000000D436C8: D65C0087 03FC2D87 FEDCBA98
	v_permlanex16_b32 v136, v136, s22, 0xfedcba98              // 000000D436D4: D65C0088 03FC2D88 FEDCBA98
	v_permlanex16_b32 v132, v132, s22, 0xfedcba98              // 000000D436E0: D65C0084 03FC2D84 FEDCBA98
	v_permlanex16_b32 v152, v152, s22, 0xfedcba98              // 000000D436EC: D65C0098 03FC2D98 FEDCBA98
	v_lshl_or_b32 v54, v54, 16, v146                           // 000000D436F8: D6560036 06492136
	v_lshl_or_b32 v49, v49, 16, v138                           // 000000D43700: D6560031 06292131
	v_pk_fma_f16 v148, v130, s21, 0xc931 op_sel_hi:[1,0,0]     // 000000D43708: CC0E0094 0BFC2B82 0000C931
	v_pk_fma_f16 v149, v131, s21, 0xc931 op_sel_hi:[1,0,0]     // 000000D43714: CC0E0095 0BFC2B83 0000C931
	v_cndmask_b32_e64 v130, v133, v128, s2                     // 000000D43720: D5010082 000B0185
	v_cndmask_b32_e64 v134, v128, v133, s2                     // 000000D43728: D5010086 000B0B80
	v_cndmask_b32_e64 v131, v135, v74, s2                      // 000000D43730: D5010083 000A9587
	v_cndmask_b32_e64 v135, v74, v135, s2                      // 000000D43738: D5010087 000B0F4A
	v_cndmask_b32_e64 v138, v136, v129, s2                     // 000000D43740: D501008A 000B0388
	v_cndmask_b32_e64 v142, v129, v136, s2                     // 000000D43748: D501008E 000B1181
	v_cndmask_b32_e64 v128, v132, v77, s2                      // 000000D43750: D5010080 000A9B84
	v_cndmask_b32_e64 v132, v77, v132, s2                      // 000000D43758: D5010084 000B094D
	v_cndmask_b32_e64 v129, v152, v46, s2                      // 000000D43760: D5010081 000A5D98
	v_cndmask_b32_e64 v133, v46, v152, s2                      // 000000D43768: D5010085 000B312E
	v_and_b32_e32 v50, 0xffff, v50                             // 000000D43770: 366464FF 0000FFFF
	v_bfe_u32 v61, v79, 4, 16                                  // 000000D43778: D610003D 0241094F
	v_mul_u32_u24_e32 v156, s12, v50                           // 000000D43780: 1738640C
	v_mul_u32_u24_e32 v50, s13, v50                            // 000000D43784: 1664640D
	v_pk_fma_f16 v54, v54, s21, 0xc931 op_sel_hi:[1,0,0]       // 000000D43788: CC0E0036 0BFC2B36 0000C931
	v_mul_u32_u24_e32 v159, s12, v61                           // 000000D43794: 173E7A0C
	v_mul_u32_u24_e32 v61, s13, v61                            // 000000D43798: 167A7A0D
	v_lshl_add_u32 v50, v50, 24, v156                          // 000000D4379C: D6460032 06713132
	v_sad_u8 v139, v150, 0, 0x6400                             // 000000D437A4: D622008B 03FD0196 00006400
	s_waitcnt lgkmcnt(2)                                       // 000000D437B0: BF89FC27
	v_wmma_f32_16x16x16_f16 v[2:9], v[128:135], v[18:25], v[2:9]// 000000D437B4: CC404002 1C0A2580
	v_lshl_add_u32 v18, v61, 24, v159                          // 000000D437BC: D6460012 067D313D
	v_bfe_u32 v60, v79, 8, 16                                  // 000000D437C4: D610003C 0241114F
	v_mul_u32_u24_e32 v20, s12, v60                            // 000000D437CC: 1628780C
	v_mul_u32_u24_e32 v21, s13, v60                            // 000000D437D0: 162A780D
	v_dual_mov_b32 v144, v54 :: v_dual_and_b32 v79, 0xffff, v79// 000000D437D4: CA240136 904E9EFF 0000FFFF
	v_sad_u8 v19, v51, 0, 0x6400                               // 000000D437E0: D6220013 03FD0133 00006400
	v_lshl_add_u32 v20, v21, 24, v20                           // 000000D437EC: D6460014 04513115
	v_mul_u32_u24_e32 v21, s12, v79                            // 000000D437F4: 162A9E0C
	v_mul_u32_u24_e32 v22, s13, v79                            // 000000D437F8: 162C9E0D
	v_sad_u8 v155, v151, 0, 0x6400                             // 000000D437FC: D622009B 03FD0197 00006400
	v_and_b32_e32 v162, 0xffff, v139                           // 000000D43808: 374516FF 0000FFFF
	v_and_b32_e32 v163, 0xffff, v141                           // 000000D43810: 37471AFF 0000FFFF
	v_sad_u8 v18, v18, 0, 0x6400                               // 000000D43818: D6220012 03FD0112 00006400
	v_lshl_add_u32 v21, v22, 24, v21                           // 000000D43824: D6460015 04553116
	v_sad_u8 v22, v50, 0, 0x6400                               // 000000D4382C: D6220016 03FD0132 00006400
	v_and_b32_e32 v19, 0xffff, v19                             // 000000D43838: 362626FF 0000FFFF
	v_sad_u8 v20, v20, 0, 0x6400                               // 000000D43840: D6220014 03FD0114 00006400
	v_pk_fma_f16 v75, v75, s21, 0xc931 op_sel_hi:[1,0,0]       // 000000D4384C: CC0E004B 0BFC2B4B 0000C931
	v_and_b32_e32 v18, 0xffff, v18                             // 000000D43858: 362424FF 0000FFFF
	v_sad_u8 v21, v21, 0, 0x6400                               // 000000D43860: D6220015 03FD0115 00006400
	v_lshl_or_b32 v23, v155, 16, v162                          // 000000D4386C: D6560017 0689219B
	v_lshl_or_b32 v22, v22, 16, v163                           // 000000D43874: D6560016 068D2116
	v_pk_fma_f16 v76, v76, s21, 0xc931 op_sel_hi:[1,0,0]       // 000000D4387C: CC0E004C 0BFC2B4C 0000C931
	s_cselect_b32 s31, 64, 0x4440                              // 000000D43888: 981FFFC0 00004440
	v_lshl_or_b32 v19, v20, 16, v19                            // 000000D43890: D6560013 044D2114
	v_dual_mov_b32 v137, v75 :: v_dual_add_nc_u32 v108, s31, v67// 000000D43898: CA20014B 896C861F
	v_lshl_or_b32 v18, v21, 16, v18                            // 000000D438A0: D6560012 04492115
	v_pk_fma_f16 v20, v23, s21, 0xc931 op_sel_hi:[1,0,0]       // 000000D438A8: CC0E0014 0BFC2B17 0000C931
	v_pk_fma_f16 v21, v22, s21, 0xc931 op_sel_hi:[1,0,0]       // 000000D438B4: CC0E0015 0BFC2B16 0000C931
	v_dual_mov_b32 v141, v76 :: v_dual_add_nc_u32 v124, s33, v67// 000000D438C0: CA20014C 8D7C8621
	v_mov_b32_e32 v140, v145                                   // 000000D438C8: 7F180391
	v_mov_b32_e32 v156, v148                                   // 000000D438CC: 7F380394
	v_pk_fma_f16 v48, v48, s21, 0xc931 op_sel_hi:[1,0,0]       // 000000D438D0: CC0E0030 0BFC2B30 0000C931
	v_pk_fma_f16 v49, v49, s21, 0xc931 op_sel_hi:[1,0,0]       // 000000D438DC: CC0E0031 0BFC2B31 0000C931
	s_waitcnt lgkmcnt(0)                                       // 000000D438E8: BF89FC07
	v_wmma_f32_16x16x16_f16 v[10:17], v[128:135], v[26:33], v[10:17]// 000000D438EC: CC40400A 1C2A3580
	v_pk_fma_f16 v24, v19, s21, 0xc931 op_sel_hi:[1,0,0]       // 000000D438F4: CC0E0018 0BFC2B13 0000C931
	s_waitcnt vmcnt(7)                                         // 000000D43900: BF891FF7
	.long 0xd73d0019                                           // 000000D43904: D73D0019
	v_cndmask_b32_e32 v1, v68, v52, vcc_lo                     // 000000D43908: 02026944
	v_permlanex16_b32 v137, v137, s22, 0xfedcba98              // 000000D4390C: D65C0089 03FC2D89 FEDCBA98
	v_mov_b32_e32 v19, v20                                     // 000000D43918: 7E260314
	v_mov_b32_e32 v23, v21                                     // 000000D4391C: 7E2E0315
	ds_load_b128 v[80:83], v92                                 // 000000D43920: DBFC0000 5000005C
	ds_load_b128 v[84:87], v92 offset:16                       // 000000D43928: DBFC0010 5400005C
	ds_load_b128 v[88:91], v92 offset:4352                     // 000000D43930: DBFC1100 5800005C
	ds_load_b128 v[92:95], v92 offset:4368                     // 000000D43938: DBFC1110 5C00005C
	ds_load_b128 v[96:99], v108                                // 000000D43940: DBFC0000 6000006C
	ds_load_b128 v[100:103], v108 offset:16                    // 000000D43948: DBFC0010 6400006C
	ds_load_b128 v[104:107], v108 offset:4352                  // 000000D43950: DBFC1100 6800006C
	ds_load_b128 v[108:111], v108 offset:4368                  // 000000D43958: DBFC1110 6C00006C
	ds_load_b128 v[112:115], v124                              // 000000D43960: DBFC0000 7000007C
	ds_load_b128 v[116:119], v124 offset:16                    // 000000D43968: DBFC0010 7400007C
	ds_load_b128 v[120:123], v124 offset:4352                  // 000000D43970: DBFC1100 7800007C
	ds_load_b128 v[124:127], v124 offset:4368                  // 000000D43978: DBFC1110 7C00007C
	v_pk_fma_f16 v55, v55, s21, 0xc931 op_sel_hi:[1,0,0]       // 000000D43980: CC0E0037 0BFC2B37 0000C931
	v_permlanex16_b32 v140, v140, s22, 0xfedcba98              // 000000D4398C: D65C008C 03FC2D8C FEDCBA98
	v_permlanex16_b32 v141, v141, s22, 0xfedcba98              // 000000D43998: D65C008D 03FC2D8D FEDCBA98
	v_permlanex16_b32 v156, v156, s22, 0xfedcba98              // 000000D439A4: D65C009C 03FC2D9C FEDCBA98
	v_permlanex16_b32 v157, v157, s22, 0xfedcba98              // 000000D439B0: D65C009D 03FC2D9D FEDCBA98
	v_dual_mov_b32 v165, v149 :: v_dual_mov_b32 v166, v48      // 000000D439BC: CA100195 A5A60130
	v_dual_mov_b32 v168, v49 :: v_dual_mov_b32 v27, v24        // 000000D439C4: CA100131 A81A0118
	v_permlanex16_b32 v144, v144, s22, 0xfedcba98              // 000000D439CC: D65C0090 03FC2D90 FEDCBA98
	v_cndmask_b32_e64 v139, v137, v75, s2                      // 000000D439D8: D501008B 000A9789
	v_cndmask_b32_e64 v143, v75, v137, s2                      // 000000D439E0: D501008F 000B134B
	v_permlanex16_b32 v19, v19, s22, 0xfedcba98                // 000000D439E8: D65C0013 03FC2D13 FEDCBA98
	v_permlanex16_b32 v23, v23, s22, 0xfedcba98                // 000000D439F4: D65C0017 03FC2D17 FEDCBA98
	v_bfe_u32 v75, v25, 4, 16                                  // 000000D43A00: D610004B 02410919
	v_mul_u32_u24_e32 v77, s12, v75                            // 000000D43A08: 169A960C
	v_mul_u32_u24_e32 v75, s13, v75                            // 000000D43A0C: 1696960D
	v_mov_b32_e32 v164, v55                                    // 000000D43A10: 7F480337
	v_cndmask_b32_e64 v146, v140, v145, s2                     // 000000D43A14: D5010092 000B238C
	v_cndmask_b32_e64 v150, v145, v140, s2                     // 000000D43A1C: D5010096 000B1991
	v_cndmask_b32_e64 v147, v141, v76, s2                      // 000000D43A24: D5010093 000A998D
	v_cndmask_b32_e64 v151, v76, v141, s2                      // 000000D43A2C: D5010097 000B1B4C
	v_cndmask_b32_e64 v136, v156, v148, s2                     // 000000D43A34: D5010088 000B299C
	v_cndmask_b32_e64 v140, v148, v156, s2                     // 000000D43A3C: D501008C 000B3994
	v_cndmask_b32_e64 v137, v157, v47, s2                      // 000000D43A44: D5010089 000A5F9D
	v_cndmask_b32_e64 v141, v47, v157, s2                      // 000000D43A4C: D501008D 000B3B2F
	s_cselect_b32 s30, s24, 0x4480                             // 000000D43A54: 981EFF18 00004480
	v_lshl_add_u32 v75, v75, 24, v77                           // 000000D43A5C: D646004B 0535314B
	v_permlanex16_b32 v165, v165, s22, 0xfedcba98              // 000000D43A64: D65C00A5 03FC2DA5 FEDCBA98
	v_permlanex16_b32 v166, v166, s22, 0xfedcba98              // 000000D43A70: D65C00A6 03FC2DA6 FEDCBA98
	v_permlanex16_b32 v167, v167, s22, 0xfedcba98              // 000000D43A7C: D65C00A7 03FC2DA7 FEDCBA98
	v_permlanex16_b32 v168, v168, s22, 0xfedcba98              // 000000D43A88: D65C00A8 03FC2DA8 FEDCBA98
	v_permlanex16_b32 v27, v27, s22, 0xfedcba98                // 000000D43A94: D65C001B 03FC2D1B FEDCBA98
	v_add_nc_u32_e32 v50, s30, v67                             // 000000D43AA0: 4A64861E
	v_cndmask_b32_e64 v154, v144, v54, s2                      // 000000D43AA4: D501009A 000A6D90
	v_cndmask_b32_e64 v158, v54, v144, s2                      // 000000D43AAC: D501009E 000B2136
	v_pk_fma_f16 v54, v18, s21, 0xc931 op_sel_hi:[1,0,0]       // 000000D43AB4: CC0E0036 0BFC2B12 0000C931
	v_cndmask_b32_e64 v18, v19, v20, s2                        // 000000D43AC0: D5010012 000A2913
	v_cndmask_b32_e64 v22, v20, v19, s2                        // 000000D43AC8: D5010016 000A2714
	v_cndmask_b32_e64 v19, v23, v21, s2                        // 000000D43AD0: D5010013 000A2B17
	v_cndmask_b32_e64 v23, v21, v23, s2                        // 000000D43AD8: D5010017 000A2F15
	v_bfe_u32 v21, v25, 12, 16                                 // 000000D43AE0: D6100015 02411919
	v_bfe_u32 v61, v25, 8, 16                                  // 000000D43AE8: D610003D 02411119
	v_and_b32_e32 v25, 0xffff, v25                             // 000000D43AF0: 363232FF 0000FFFF
	s_waitcnt vmcnt(2)                                         // 000000D43AF8: BF890BF7
	v_bfe_u32 v60, v160, 12, 16                                // 000000D43AFC: D610003C 024119A0
	v_mul_u32_u24_e32 v76, s12, v21                            // 000000D43B04: 16982A0C
	v_mul_u32_u24_e32 v21, s13, v21                            // 000000D43B08: 162A2A0D
	v_mul_u32_u24_e32 v79, s12, v25                            // 000000D43B0C: 169E320C
	v_mul_u32_u24_e32 v25, s13, v25                            // 000000D43B10: 1632320D
	v_permlanex16_b32 v164, v164, s22, 0xfedcba98              // 000000D43B14: D65C00A4 03FC2DA4 FEDCBA98
	s_waitcnt lgkmcnt(10)                                      // 000000D43B20: BF89FCA7
	v_wmma_f32_16x16x16_f16 v[2:9], v[136:143], v[80:87], v[2:9]// 000000D43B24: CC404002 1C0AA188
	v_lshl_add_u32 v21, v21, 24, v76                           // 000000D43B2C: D6460015 05313115
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000D43B34: D622004B 03FD014B 00006400
	v_mul_u32_u24_e32 v80, s12, v60                            // 000000D43B40: 16A0780C
	v_mul_u32_u24_e32 v60, s13, v60                            // 000000D43B44: 1678780D
	v_lshl_add_u32 v25, v25, 24, v79                           // 000000D43B48: D6460019 053D3119
	v_lshl_add_u32 v60, v60, 24, v80                           // 000000D43B50: D646003C 0541313C
	v_cndmask_b32_e64 v144, v165, v149, s2                     // 000000D43B58: D5010090 000B2BA5
	v_cndmask_b32_e64 v148, v149, v165, s2                     // 000000D43B60: D5010094 000B4B95
	v_cndmask_b32_e64 v145, v166, v48, s2                      // 000000D43B68: D5010091 000A61A6
	v_cndmask_b32_e64 v149, v48, v166, s2                      // 000000D43B70: D5010095 000B4D30
	v_cndmask_b32_e64 v152, v167, v153, s2                     // 000000D43B78: D5010098 000B33A7
	v_cndmask_b32_e64 v156, v153, v167, s2                     // 000000D43B80: D501009C 000B4F99
	v_cndmask_b32_e64 v153, v168, v49, s2                      // 000000D43B88: D5010099 000A63A8
	v_cndmask_b32_e64 v157, v49, v168, s2                      // 000000D43B90: D501009D 000B5131
	v_cndmask_b32_e64 v20, v27, v24, s2                        // 000000D43B98: D5010014 000A311B
	v_cndmask_b32_e64 v24, v24, v27, s2                        // 000000D43BA0: D5010018 000A3718
	ds_load_b128 v[26:29], v50                                 // 000000D43BA8: DBFC0000 1A000032
	ds_load_b128 v[30:33], v50 offset:16                       // 000000D43BB0: DBFC0010 1E000032
	ds_load_b128 v[46:49], v50 offset:4352                     // 000000D43BB8: DBFC1100 2E000032
	ds_load_b128 v[50:53], v50 offset:4368                     // 000000D43BC0: DBFC1110 32000032
	v_bfe_u32 v76, v160, 4, 16                                 // 000000D43BC8: D610004C 024109A0
	v_bfe_u32 v74, v160, 8, 16                                 // 000000D43BD0: D610004A 024111A0
	v_mul_u32_u24_e32 v77, s12, v61                            // 000000D43BD8: 169A7A0C
	v_mul_u32_u24_e32 v61, s13, v61                            // 000000D43BDC: 167A7A0D
	v_mul_u32_u24_e32 v79, s12, v76                            // 000000D43BE0: 169E980C
	v_mul_u32_u24_e32 v76, s13, v76                            // 000000D43BE4: 1698980D
	v_cndmask_b32_e64 v155, v164, v55, s2                      // 000000D43BE8: D501009B 000A6FA4
	v_cndmask_b32_e64 v159, v55, v164, s2                      // 000000D43BF0: D501009F 000B4937
	v_mov_b32_e32 v55, v54                                     // 000000D43BF8: 7E6E0336
	v_sad_u8 v21, v21, 0, 0x6400                               // 000000D43BFC: D6220015 03FD0115 00006400
	v_lshl_add_u32 v61, v61, 24, v77                           // 000000D43C08: D646003D 0535313D
	v_and_b32_e32 v75, 0xffff, v75                             // 000000D43C10: 369696FF 0000FFFF
	v_lshl_add_u32 v76, v76, 24, v79                           // 000000D43C18: D646004C 053D314C
	v_mul_u32_u24_e32 v79, s12, v74                            // 000000D43C20: 169E940C
	v_mul_u32_u24_e32 v74, s13, v74                            // 000000D43C24: 1694940D
	v_sad_u8 v25, v25, 0, 0x6400                               // 000000D43C28: D6220019 03FD0119 00006400
	v_sad_u8 v60, v60, 0, 0x6400                               // 000000D43C34: D622003C 03FD013C 00006400
	v_lshl_add_u32 v74, v74, 24, v79                           // 000000D43C40: D646004A 053D314A
	s_waitcnt lgkmcnt(10)                                      // 000000D43C48: BF89FCA7
	v_wmma_f32_16x16x16_f16 v[2:9], v[144:151], v[96:103], v[2:9]// 000000D43C4C: CC404002 1C0AC190
	v_permlanex16_b32 v55, v55, s22, 0xfedcba98                // 000000D43C54: D65C0037 03FC2D37 FEDCBA98
	v_and_b32_e32 v77, 0xffff, v160                            // 000000D43C60: 369B40FF 0000FFFF
	v_and_b32_e32 v21, 0xffff, v21                             // 000000D43C68: 362A2AFF 0000FFFF
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000D43C70: D622003D 03FD013D 00006400
	v_lshl_or_b32 v75, v25, 16, v75                            // 000000D43C7C: D656004B 052D2119
	v_mul_u32_u24_e32 v79, s12, v77                            // 000000D43C84: 169E9A0C
	v_mul_u32_u24_e32 v77, s13, v77                            // 000000D43C88: 169A9A0D
	v_and_b32_e32 v60, 0xffff, v60                             // 000000D43C8C: 367878FF 0000FFFF
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000D43C94: D622004A 03FD014A 00006400
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000D43CA0: D622004C 03FD014C 00006400
	v_lshl_add_u32 v77, v77, 24, v79                           // 000000D43CAC: D646004D 053D314D
	v_wmma_f32_16x16x16_f16 v[10:17], v[136:143], v[88:95], v[10:17]// 000000D43CB4: CC40400A 1C2AB188
	s_waitcnt lgkmcnt(6)                                       // 000000D43CBC: BF89FC67
	v_wmma_f32_16x16x16_f16 v[2:9], v[152:159], v[112:119], v[2:9]// 000000D43CC0: CC404002 1C0AE198
	v_lshl_or_b32 v61, v61, 16, v21                            // 000000D43CC8: D656003D 0455213D
	v_cndmask_b32_e64 v21, v55, v54, s2                        // 000000D43CD0: D5010015 000A6D37
	v_cndmask_b32_e64 v25, v54, v55, s2                        // 000000D43CD8: D5010019 000A6F36
	v_pk_fma_f16 v54, v75, s21, 0xc931 op_sel_hi:[1,0,0]       // 000000D43CE0: CC0E0036 0BFC2B4B 0000C931
	v_lshl_or_b32 v60, v74, 16, v60                            // 000000D43CEC: D656003C 04F1214A
	v_and_b32_e32 v76, 0xffff, v76                             // 000000D43CF4: 369898FF 0000FFFF
	v_sad_u8 v77, v77, 0, 0x6400                               // 000000D43CFC: D622004D 03FD014D 00006400
	v_wmma_f32_16x16x16_f16 v[10:17], v[144:151], v[104:111], v[10:17]// 000000D43D08: CC40400A 1C2AD190
	s_waitcnt lgkmcnt(2)                                       // 000000D43D10: BF89FC27
	v_wmma_f32_16x16x16_f16 v[2:9], v[18:25], v[26:33], v[2:9] // 000000D43D14: CC404002 1C0A3512
	v_mov_b32_e32 v26, v54                                     // 000000D43D1C: 7E340336
	v_pk_fma_f16 v55, v60, s21, 0xc931 op_sel_hi:[1,0,0]       // 000000D43D20: CC0E0037 0BFC2B3C 0000C931
	v_lshl_or_b32 v74, v77, 16, v76                            // 000000D43D2C: D656004A 0531214D
	v_pk_fma_f16 v61, v61, s21, 0xc931 op_sel_hi:[1,0,0]       // 000000D43D34: CC0E003D 0BFC2B3D 0000C931
	v_wmma_f32_16x16x16_f16 v[10:17], v[152:159], v[120:127], v[10:17]// 000000D43D40: CC40400A 1C2AF198
	v_permlanex16_b32 v26, v26, s22, 0xfedcba98                // 000000D43D48: D65C001A 03FC2D1A FEDCBA98
	v_mov_b32_e32 v27, v55                                     // 000000D43D54: 7E360337
	v_pk_fma_f16 v60, v74, s21, 0xc931 op_sel_hi:[1,0,0]       // 000000D43D58: CC0E003C 0BFC2B4A 0000C931
	v_mov_b32_e32 v74, v61                                     // 000000D43D64: 7E94033D
	s_cselect_b32 s30, s25, 0x44a0                             // 000000D43D68: 981EFF19 000044A0
	s_waitcnt lgkmcnt(0)                                       // 000000D43D70: BF89FC07
	v_wmma_f32_16x16x16_f16 v[10:17], v[18:25], v[46:53], v[10:17]// 000000D43D74: CC40400A 1C2A5D12
	v_cndmask_b32_e64 v19, v26, v54, s2                        // 000000D43D7C: D5010013 000A6D1A
	v_cndmask_b32_e64 v23, v54, v26, s2                        // 000000D43D84: D5010017 000A3536
	.long 0xd73d0019                                           // 000000D43D8C: D73D0019
	v_cndmask_b32_e32 v1, v68, v56, vcc_lo                     // 000000D43D90: 02027144
	v_permlanex16_b32 v27, v27, s22, 0xfedcba98                // 000000D43D94: D65C001B 03FC2D1B FEDCBA98
	v_add_nc_u32_e32 v21, s30, v67                             // 000000D43DA0: 4A2A861E
	v_permlanex16_b32 v74, v74, s22, 0xfedcba98                // 000000D43DA4: D65C004A 03FC2D4A FEDCBA98
	s_waitcnt vmcnt(1)                                         // 000000D43DB0: BF8907F7
	v_bfe_u32 v54, v161, 12, 16                                // 000000D43DB4: D6100036 024119A1
	v_mul_u32_u24_e32 v77, s12, v54                            // 000000D43DBC: 169A6C0C
	v_cndmask_b32_e64 v20, v27, v55, s2                        // 000000D43DC0: D5010014 000A6F1B
	v_cndmask_b32_e64 v24, v55, v27, s2                        // 000000D43DC8: D5010018 000A3737
	ds_load_b128 v[26:29], v21                                 // 000000D43DD0: DBFC0000 1A000015
	ds_load_b128 v[30:33], v21 offset:16                       // 000000D43DD8: DBFC0010 1E000015
	ds_load_b128 v[46:49], v21 offset:4352                     // 000000D43DE0: DBFC1100 2E000015
	ds_load_b128 v[50:53], v21 offset:4368                     // 000000D43DE8: DBFC1110 32000015
	v_bfe_u32 v21, v25, 12, 16                                 // 000000D43DF0: D6100015 02411919
	v_cndmask_b32_e64 v18, v74, v61, s2                        // 000000D43DF8: D5010012 000A7B4A
	v_cndmask_b32_e64 v22, v61, v74, s2                        // 000000D43E00: D5010016 000A953D
	v_mul_u32_u24_e32 v61, s12, v21                            // 000000D43E08: 167A2A0C
	v_mul_u32_u24_e32 v21, s13, v21                            // 000000D43E0C: 162A2A0D
	v_lshl_add_u32 v21, v21, 24, v61                           // 000000D43E10: D6460015 04F53115
	v_bfe_u32 v57, v25, 4, 16                                  // 000000D43E18: D6100039 02410919
	v_bfe_u32 v55, v25, 8, 16                                  // 000000D43E20: D6100037 02411119
	v_mul_u32_u24_e32 v74, s12, v57                            // 000000D43E28: 1694720C
	v_mul_u32_u24_e32 v57, s13, v57                            // 000000D43E2C: 1672720D
	s_delay_alu instid0(VALU_DEP_2)                            // 000000D43E30: BF870002
	v_lshl_add_u32 v57, v57, 24, v74                           // 000000D43E34: D6460039 05293139
	v_mul_u32_u24_e32 v74, s12, v55                            // 000000D43E3C: 16946E0C
	v_mul_u32_u24_e32 v55, s13, v55                            // 000000D43E40: 166E6E0D
	v_sad_u8 v21, v21, 0, 0x6400                               // 000000D43E44: D6220015 03FD0115 00006400
	v_lshl_add_u32 v55, v55, 24, v74                           // 000000D43E50: D6460037 05293137
	v_mul_u32_u24_e32 v54, s13, v54                            // 000000D43E58: 166C6C0D
	v_lshl_add_u32 v54, v54, 24, v77                           // 000000D43E5C: D6460036 05353136
	v_and_b32_e32 v25, 0xffff, v25                             // 000000D43E64: 363232FF 0000FFFF
	v_bfe_u32 v61, v161, 4, 16                                 // 000000D43E6C: D610003D 024109A1
	v_mul_u32_u24_e32 v76, s12, v25                            // 000000D43E74: 1698320C
	v_mul_u32_u24_e32 v25, s13, v25                            // 000000D43E78: 1632320D
	v_bfe_u32 v56, v161, 8, 16                                 // 000000D43E7C: D6100038 024111A1
	v_lshl_add_u32 v25, v25, 24, v76                           // 000000D43E84: D6460019 05313119
	v_mul_u32_u24_e32 v76, s12, v61                            // 000000D43E8C: 16987A0C
	v_mul_u32_u24_e32 v61, s13, v61                            // 000000D43E90: 167A7A0D
	v_and_b32_e32 v21, 0xffff, v21                             // 000000D43E94: 362A2AFF 0000FFFF
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000D43E9C: D6220037 03FD0137 00006400
	v_lshl_add_u32 v61, v61, 24, v76                           // 000000D43EA8: D646003D 0531313D
	v_mul_u32_u24_e32 v76, s12, v56                            // 000000D43EB0: 1698700C
	v_mul_u32_u24_e32 v56, s13, v56                            // 000000D43EB4: 1670700D
	v_sad_u8 v54, v54, 0, 0x6400                               // 000000D43EB8: D6220036 03FD0136 00006400
	v_lshl_add_u32 v56, v56, 24, v76                           // 000000D43EC4: D6460038 05313138
	v_mov_b32_e32 v75, v60                                     // 000000D43ECC: 7E96033C
	v_sad_u8 v57, v57, 0, 0x6400                               // 000000D43ED0: D6220039 03FD0139 00006400
	v_lshl_or_b32 v55, v55, 16, v21                            // 000000D43EDC: D6560037 04552137
	v_and_b32_e32 v54, 0xffff, v54                             // 000000D43EE4: 366C6CFF 0000FFFF
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000D43EEC: D6220038 03FD0138 00006400
	v_permlanex16_b32 v75, v75, s22, 0xfedcba98                // 000000D43EF8: D65C004B 03FC2D4B FEDCBA98
	v_and_b32_e32 v74, 0xffff, v161                            // 000000D43F04: 369542FF 0000FFFF
	v_and_b32_e32 v57, 0xffff, v57                             // 000000D43F0C: 367272FF 0000FFFF
	v_sad_u8 v25, v25, 0, 0x6400                               // 000000D43F14: D6220019 03FD0119 00006400
	v_mul_u32_u24_e32 v76, s12, v74                            // 000000D43F20: 1698940C
	v_mul_u32_u24_e32 v74, s13, v74                            // 000000D43F24: 1694940D
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000D43F28: D622003D 03FD013D 00006400
	v_lshl_add_u32 v74, v74, 24, v76                           // 000000D43F34: D646004A 0531314A
	v_pk_fma_f16 v55, v55, s21, 0xc931 op_sel_hi:[1,0,0]       // 000000D43F3C: CC0E0037 0BFC2B37 0000C931
	v_lshl_or_b32 v54, v56, 16, v54                            // 000000D43F48: D6560036 04D92138
	v_cndmask_b32_e64 v21, v75, v60, s2                        // 000000D43F50: D5010015 000A794B
	v_lshl_or_b32 v57, v25, 16, v57                            // 000000D43F58: D6560039 04E52119
	v_cndmask_b32_e64 v25, v60, v75, s2                        // 000000D43F60: D5010019 000A973C
	v_and_b32_e32 v61, 0xffff, v61                             // 000000D43F68: 367A7AFF 0000FFFF
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000D43F70: D622004A 03FD014A 00006400
	v_mov_b32_e32 v60, v55                                     // 000000D43F7C: 7E780337
	v_pk_fma_f16 v54, v54, s21, 0xc931 op_sel_hi:[1,0,0]       // 000000D43F80: CC0E0036 0BFC2B36 0000C931
	s_waitcnt lgkmcnt(0)                                       // 000000D43F8C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[10:17], v[18:25], v[46:53], v[10:17]// 000000D43F90: CC40400A 1C2A5D12
	.long 0xd73d002e                                           // 000000D43F98: D73D002E
	v_cndmask_b32_e32 v1, v68, v58, vcc_lo                     // 000000D43F9C: 02027544
	v_lshl_or_b32 v56, v74, 16, v61                            // 000000D43FA0: D6560038 04F5214A
	v_permlanex16_b32 v60, v60, s22, 0xfedcba98                // 000000D43FA8: D65C003C 03FC2D3C FEDCBA98
	v_wmma_f32_16x16x16_f16 v[2:9], v[18:25], v[26:33], v[2:9] // 000000D43FB4: CC404002 1C0A3512
	v_mov_b32_e32 v27, v54                                     // 000000D43FBC: 7E360336
	s_waitcnt vmcnt(0)                                         // 000000D43FC0: BF8903F7
	v_bfe_u32 v48, v78, 12, 16                                 // 000000D43FC4: D6100030 0241194E
	v_bfe_u32 v47, v46, 12, 16                                 // 000000D43FCC: D610002F 0241192E
	v_pk_fma_f16 v56, v56, s21, 0xc931 op_sel_hi:[1,0,0]       // 000000D43FD4: CC0E0038 0BFC2B38 0000C931
	v_mul_u32_u24_e32 v49, s12, v47                            // 000000D43FE0: 16625E0C
	v_mul_u32_u24_e32 v47, s13, v47                            // 000000D43FE4: 165E5E0D
	v_bfe_u32 v52, v46, 4, 16                                  // 000000D43FE8: D6100034 0241092E
	v_cndmask_b32_e64 v18, v60, v55, s2                        // 000000D43FF0: D5010012 000A6F3C
	v_cndmask_b32_e64 v22, v55, v60, s2                        // 000000D43FF8: D5010016 000A7937
	v_lshl_add_u32 v47, v47, 24, v49                           // 000000D44000: D646002F 04C5312F
	v_bfe_u32 v49, v46, 8, 16                                  // 000000D44008: D6100031 0241112E
	v_mul_u32_u24_e32 v55, s12, v52                            // 000000D44010: 166E680C
	v_mul_u32_u24_e32 v52, s13, v52                            // 000000D44014: 1668680D
	v_and_b32_e32 v46, 0xffff, v46                             // 000000D44018: 365C5CFF 0000FFFF
	v_permlanex16_b32 v27, v27, s22, 0xfedcba98                // 000000D44020: D65C001B 03FC2D1B FEDCBA98
	v_lshl_add_u32 v52, v52, 24, v55                           // 000000D4402C: D6460034 04DD3134
	v_mul_u32_u24_e32 v55, s12, v46                            // 000000D44034: 166E5C0C
	v_mul_u32_u24_e32 v46, s13, v46                            // 000000D44038: 165C5C0D
	v_bfe_u32 v53, v78, 4, 16                                  // 000000D4403C: D6100035 0241094E
	v_lshl_add_u32 v46, v46, 24, v55                           // 000000D44044: D646002E 04DD312E
	v_mul_u32_u24_e32 v55, s12, v48                            // 000000D4404C: 166E600C
	v_mul_u32_u24_e32 v48, s13, v48                            // 000000D44050: 1660600D
	v_lshl_add_u32 v48, v48, 24, v55                           // 000000D44054: D6460030 04DD3130
	v_mul_u32_u24_e32 v55, s12, v53                            // 000000D4405C: 166E6A0C
	v_mul_u32_u24_e32 v53, s13, v53                            // 000000D44060: 166A6A0D
	v_pk_fma_f16 v57, v57, s21, 0xc931 op_sel_hi:[1,0,0]       // 000000D44064: CC0E0039 0BFC2B39 0000C931
	v_mov_b32_e32 v28, v56                                     // 000000D44070: 7E380338
	v_lshl_add_u32 v53, v53, 24, v55                           // 000000D44074: D6460035 04DD3135
	v_cndmask_b32_e64 v20, v27, v54, s2                        // 000000D4407C: D5010014 000A6D1B
	v_cndmask_b32_e64 v24, v54, v27, s2                        // 000000D44084: D5010018 000A3736
	v_bfe_u32 v51, v78, 8, 16                                  // 000000D4408C: D6100033 0241114E
	v_mul_u32_u24_e32 v54, s12, v49                            // 000000D44094: 166C620C
	v_mul_u32_u24_e32 v49, s13, v49                            // 000000D44098: 1662620D
	v_lshl_add_u32 v49, v49, 24, v54                           // 000000D4409C: D6460031 04D93131
	v_and_b32_e32 v54, 0xffff, v78                             // 000000D440A4: 366C9CFF 0000FFFF
	v_mul_u32_u24_e32 v55, s12, v51                            // 000000D440AC: 166E660C
	v_mul_u32_u24_e32 v51, s13, v51                            // 000000D440B0: 1666660D
	v_lshl_add_u32 v51, v51, 24, v55                           // 000000D440B4: D6460033 04DD3133
	v_mul_u32_u24_e32 v55, s12, v54                            // 000000D440BC: 166E6C0C
	v_mul_u32_u24_e32 v54, s13, v54                            // 000000D440C0: 166C6C0D
	v_mov_b32_e32 v26, v57                                     // 000000D440C4: 7E340339
	v_permlanex16_b32 v28, v28, s22, 0xfedcba98                // 000000D440C8: D65C001C 03FC2D1C FEDCBA98
	v_sad_u8 v47, v47, 0, 0x6400                               // 000000D440D4: D622002F 03FD012F 00006400
	v_sad_u8 v52, v52, 0, 0x6400                               // 000000D440E0: D6220034 03FD0134 00006400
	v_sad_u8 v48, v48, 0, 0x6400                               // 000000D440EC: D6220030 03FD0130 00006400
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000D440F8: D6220035 03FD0135 00006400
	v_lshl_add_u32 v54, v54, 24, v55                           // 000000D44104: D6460036 04DD3136
	s_cselect_b32 s30, s26, 0x44c0                             // 000000D4410C: 981EFF1A 000044C0
	v_permlanex16_b32 v26, v26, s22, 0xfedcba98                // 000000D44114: D65C001A 03FC2D1A FEDCBA98
	v_add_nc_u32_e32 v50, s30, v67                             // 000000D44120: 4A64861E
	v_cndmask_b32_e64 v21, v28, v56, s2                        // 000000D44124: D5010015 000A711C
	v_cndmask_b32_e64 v25, v56, v28, s2                        // 000000D4412C: D5010019 000A3938
	v_and_b32_e32 v47, 0xffff, v47                             // 000000D44134: 365E5EFF 0000FFFF
	v_sad_u8 v49, v49, 0, 0x6400                               // 000000D4413C: D6220031 03FD0131 00006400
	v_and_b32_e32 v52, 0xffff, v52                             // 000000D44148: 366868FF 0000FFFF
	v_sad_u8 v46, v46, 0, 0x6400                               // 000000D44150: D622002E 03FD012E 00006400
	v_and_b32_e32 v48, 0xffff, v48                             // 000000D4415C: 366060FF 0000FFFF
	v_sad_u8 v51, v51, 0, 0x6400                               // 000000D44164: D6220033 03FD0133 00006400
	v_and_b32_e32 v56, 0xffff, v53                             // 000000D44170: 36706AFF 0000FFFF
	v_sad_u8 v54, v54, 0, 0x6400                               // 000000D44178: D6220036 03FD0136 00006400
	s_cselect_b32 s30, s27, 0x44e0                             // 000000D44184: 981EFF1B 000044E0
	v_cndmask_b32_e64 v19, v26, v57, s2                        // 000000D4418C: D5010013 000A731A
	v_cndmask_b32_e64 v23, v57, v26, s2                        // 000000D44194: D5010017 000A3539
	ds_load_b128 v[26:29], v50                                 // 000000D4419C: DBFC0000 1A000032
	ds_load_b128 v[30:33], v50 offset:16                       // 000000D441A4: DBFC0010 1E000032
	v_lshl_or_b32 v55, v49, 16, v47                            // 000000D441AC: D6560037 04BD2131
	v_lshl_or_b32 v57, v46, 16, v52                            // 000000D441B4: D6560039 04D1212E
	v_lshl_or_b32 v58, v51, 16, v48                            // 000000D441BC: D656003A 04C12133
	ds_load_b128 v[46:49], v50 offset:4352                     // 000000D441C4: DBFC1100 2E000032
	ds_load_b128 v[50:53], v50 offset:4368                     // 000000D441CC: DBFC1110 32000032
	v_lshl_or_b32 v54, v54, 16, v56                            // 000000D441D4: D6560036 04E12136
	v_add_nc_u32_e32 v78, s30, v67                             // 000000D441DC: 4A9C861E
	v_pk_fma_f16 v82, v55, s21, 0xc931 op_sel_hi:[1,0,0]       // 000000D441E0: CC0E0052 0BFC2B37 0000C931
	v_pk_fma_f16 v83, v57, s21, 0xc931 op_sel_hi:[1,0,0]       // 000000D441EC: CC0E0053 0BFC2B39 0000C931
	v_pk_fma_f16 v84, v58, s21, 0xc931 op_sel_hi:[1,0,0]       // 000000D441F8: CC0E0054 0BFC2B3A 0000C931
	v_pk_fma_f16 v85, v54, s21, 0xc931 op_sel_hi:[1,0,0]       // 000000D44204: CC0E0055 0BFC2B36 0000C931
	ds_load_b128 v[54:57], v78                                 // 000000D44210: DBFC0000 3600004E
	ds_load_b128 v[58:61], v78 offset:16                       // 000000D44218: DBFC0010 3A00004E
	ds_load_b128 v[74:77], v78 offset:4352                     // 000000D44220: DBFC1100 4A00004E
	ds_load_b128 v[78:81], v78 offset:4368                     // 000000D44228: DBFC1110 4E00004E
	v_dual_mov_b32 v86, v82 :: v_dual_mov_b32 v87, v83         // 000000D44230: CA100152 56560153
	v_dual_mov_b32 v88, v84 :: v_dual_mov_b32 v89, v85         // 000000D44238: CA100154 58580155
	s_and_not1_b32 vcc_lo, exec_lo, s28                        // 000000D44240: 916A1C7E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D44244: BF870192
	v_permlanex16_b32 v86, v86, s22, 0xfedcba98                // 000000D44248: D65C0056 03FC2D56 FEDCBA98
	v_permlanex16_b32 v87, v87, s22, 0xfedcba98                // 000000D44254: D65C0057 03FC2D57 FEDCBA98
	s_delay_alu instid0(VALU_DEP_3)                            // 000000D44260: BF870003
	v_permlanex16_b32 v88, v88, s22, 0xfedcba98                // 000000D44264: D65C0058 03FC2D58 FEDCBA98
	v_permlanex16_b32 v89, v89, s22, 0xfedcba98                // 000000D44270: D65C0059 03FC2D59 FEDCBA98
	s_waitcnt lgkmcnt(6)                                       // 000000D4427C: BF89FC67
	v_wmma_f32_16x16x16_f16 v[2:9], v[18:25], v[26:33], v[2:9] // 000000D44280: CC404002 1C0A3512
	v_cndmask_b32_e64 v26, v86, v82, s2                        // 000000D44288: D501001A 000AA556
	v_cndmask_b32_e64 v30, v82, v86, s2                        // 000000D44290: D501001E 000AAD52
	v_cndmask_b32_e64 v27, v87, v83, s2                        // 000000D44298: D501001B 000AA757
	v_cndmask_b32_e64 v31, v83, v87, s2                        // 000000D442A0: D501001F 000AAF53
	v_cndmask_b32_e64 v28, v88, v84, s2                        // 000000D442A8: D501001C 000AA958
	v_cndmask_b32_e64 v32, v84, v88, s2                        // 000000D442B0: D5010020 000AB154
	v_cndmask_b32_e64 v29, v89, v85, s2                        // 000000D442B8: D501001D 000AAB59
	v_cndmask_b32_e64 v33, v85, v89, s2                        // 000000D442C0: D5010021 000AB355
	s_waitcnt lgkmcnt(4)                                       // 000000D442C8: BF89FC47
	v_wmma_f32_16x16x16_f16 v[10:17], v[18:25], v[46:53], v[10:17]// 000000D442CC: CC40400A 1C2A5D12
	s_waitcnt lgkmcnt(2)                                       // 000000D442D4: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000D442D8: BF870122
	v_wmma_f32_16x16x16_f16 v[2:9], v[26:33], v[54:61], v[2:9] // 000000D442DC: CC404002 1C0A6D1A
	s_waitcnt lgkmcnt(0)                                       // 000000D442E4: BF89FC07
	v_wmma_f32_16x16x16_f16 v[10:17], v[26:33], v[74:81], v[10:17]// 000000D442E8: CC40400A 1C2A951A
	s_cbranch_vccnz 64192                                      // 000000D442F0: BFA4FAC0 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x6bf4>
	s_and_b32 s28, s29, exec_lo                                // 000000D442F4: 8B1C7E1D
	s_cselect_b32 s28, 0x4400, 0                               // 000000D442F8: 981C80FF 00004400
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000D44300: BF870009
	v_lshl_or_b32 v18, v63, 1, s28                             // 000000D44304: D6560012 0071033F
	s_and_saveexec_b32 s28, s0                                 // 000000D4430C: BE9C2000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D44310: BF870001
	v_add_nc_u32_e32 v19, v18, v66                             // 000000D44314: 4A268512
	ds_store_b128 v19, v[34:37]                                // 000000D44318: DB7C0000 00002213
	s_or_b32 exec_lo, exec_lo, s28                             // 000000D44320: 8C7E1C7E
	s_and_saveexec_b32 s28, s1                                 // 000000D44324: BE9C2001
	s_cbranch_execz 64177                                      // 000000D44328: BFA5FAB1 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x6bf0>
	v_add_nc_u32_e32 v18, v18, v65                             // 000000D4432C: 4A248312
	ds_store_b128 v18, v[38:41]                                // 000000D44330: DB7C0000 00002612
	s_branch 64173                                             // 000000D44338: BFA0FAAD <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x6bf0>
	v_lshrrev_b32_e32 v18, 5, v0                               // 000000D4433C: 32240085
	v_lshrrev_b32_e32 v1, 2, v62                               // 000000D44340: 32027C82
	s_mul_i32 s1, s16, 0x1400                                  // 000000D44344: 9601FF10 00001400
	s_mul_hi_i32 s0, s16, 0x1400                               // 000000D4434C: 9700FF10 00001400
	s_add_u32 s2, s14, s1                                      // 000000D44354: 8002010E
	v_lshlrev_b32_e32 v19, 6, v18                              // 000000D44358: 30262486
	s_addc_u32 s3, s15, s0                                     // 000000D4435C: 8203000F
	s_lshl_b32 s0, s17, 7                                      // 000000D44360: 84008711
	v_and_b32_e32 v21, 1, v0                                   // 000000D44364: 362A0081
	s_ashr_i32 s1, s0, 31                                      // 000000D44368: 86019F00
	v_mad_u32_u24 v19, 0x210, v64, v19                         // 000000D4436C: D60B0013 044E80FF 00000210
	s_lshl_b64 s[4:5], s[0:1], 1                               // 000000D44378: 84848100
	v_and_b32_e32 v22, 4, v0                                   // 000000D4437C: 362C0084
	s_add_u32 s12, s2, s4                                      // 000000D44380: 800C0402
	s_addc_u32 s13, s3, s5                                     // 000000D44384: 820D0503
	v_and_or_b32 v19, v1, 4, v19                               // 000000D44388: D6570013 044D0901
	v_and_b32_e32 v1, 2, v0                                    // 000000D44390: 36020082
	.long 0xd44a0003                                           // 000000D44394: D44A0003
	v_cndmask_b32_e32 v1, 0, v21, vcc_lo                       // 000000D44398: 02022A80
	v_and_b32_e32 v21, 8, v0                                   // 000000D4439C: 362A0088
	v_lshlrev_b32_e32 v20, 4, v62                              // 000000D443A0: 30287C84
	.long 0xd44a0001                                           // 000000D443A4: D44A0001
	v_cndmask_b32_e32 v1, 0, v22, vcc_lo                       // 000000D443A8: 02022C80
	.long 0xd44a0002                                           // 000000D443AC: D44A0002
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000D443B0: 02020280
	v_lshlrev_b32_e32 v1, 3, v62                               // 000000D443B4: 30027C83
	.long 0xd44a0000                                           // 000000D443B8: D44A0000
	v_cndmask_b32_e32 v1, 0, v21, vcc_lo                       // 000000D443BC: 02022A80
	v_lshlrev_b32_e32 v21, 2, v62                              // 000000D443C0: 302A7C82
	v_and_b32_e32 v23, 16, v0                                  // 000000D443C4: 362E0090
	ds_store_2addr_b32 v19, v2, v3 offset1:2                   // 000000D443C8: D8380200 00030213
	ds_store_2addr_b32 v19, v4, v5 offset0:4 offset1:6         // 000000D443D0: D8380604 00050413
	ds_store_2addr_b32 v19, v6, v7 offset0:8 offset1:10        // 000000D443D8: D8380A08 00070613
	.long 0xd7001501                                           // 000000D443E0: D7001501
	v_cndmask_b32_e32 v1, s6, v1, vcc_lo                       // 000000D443E4: 02020206
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D443E8: BF8701A1
	v_add_co_ci_u32_e64 v22, null, s7, 0, s21                  // 000000D443EC: D5207C16 00550007
	v_mad_u32_u24 v4, 0x210, v18, v20                          // 000000D443F4: D60B0004 045224FF 00000210
	.long 0xd7000401                                           // 000000D44400: D7000401
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 000000D44404: 02000901
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D44408: BF870001
	v_add_co_ci_u32_e64 v2, null, s5, v22, s4                  // 000000D4440C: D5207C02 00122C05
	v_lshlrev_b32_e32 v3, 1, v21                               // 000000D44414: 30062A81
	s_mov_b32 s5, exec_lo                                      // 000000D44418: BE85007E
	v_cmp_eq_u32_e32 vcc_lo, 0, v23                            // 000000D4441C: 7C942E80
	ds_store_2addr_b32 v19, v8, v9 offset0:12 offset1:14       // 000000D44420: D8380E0C 00090813
	s_waitcnt lgkmcnt(0)                                       // 000000D44428: BF89FC07
	s_barrier                                                  // 000000D4442C: BFBD0000
	buffer_gl0_inv                                             // 000000D44430: E0AC0000 00000000
	.long 0xd4c4007e                                           // 000000D44438: D4C4007E
	v_cndmask_b32_e32 v1, s19, v18, vcc_lo                     // 000000D4443C: 02022413
	s_cbranch_execz 204                                        // 000000D44440: BFA500CC <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x8574>
	global_load_b64 v[21:22], v3, s[12:13]                     // 000000D44444: DC560000 150C0003
	ds_load_b128 v[5:8], v4                                    // 000000D4444C: DBFC0000 05000004
	s_mov_b32 s4, 0x76543210                                   // 000000D44454: BE8400FF 76543210
	s_waitcnt lgkmcnt(0)                                       // 000000D4445C: BF89FC07
	v_add_f32_e32 v9, v5, v6                                   // 000000D44460: 06120D05
	v_add_f32_e32 v23, v7, v8                                  // 000000D44464: 062E1107
	v_dual_sub_f32 v5, v5, v6 :: v_dual_sub_f32 v6, v7, v8     // 000000D44468: C94A0D05 05061107
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000D44470: BF870122
	v_sub_f32_e32 v8, v9, v23                                  // 000000D44474: 08102F09
	v_add_f32_e32 v7, v9, v23                                  // 000000D44478: 060E2F09
	v_mov_b32_dpp v23, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D4447C: 7E2E02FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, s3                          // 000000D44484: D5010008 200E1108
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000D4448C: BF8700C1
	v_dual_add_f32 v8, v8, v23 :: v_dual_add_f32 v9, v5, v6    // 000000D44490: C9082F08 08080D05
	v_sub_f32_e32 v5, v5, v6                                   // 000000D44498: 080A0D05
	v_mov_b32_dpp v6, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D4449C: 7E0C02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s3                          // 000000D444A4: D5010007 200E0F07
	v_add_f32_e32 v6, v7, v6                                   // 000000D444AC: 060C0D07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D444B0: BF8700A1
	v_mov_b32_dpp v23, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D444B4: 7E2E02FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, s2                          // 000000D444BC: D5010006 200A0D06
	v_add_f32_e32 v6, v6, v23                                  // 000000D444C4: 060C2F06
	v_mov_b32_dpp v24, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D444C8: 7E3002FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 000000D444D0: D5010009 200E1309
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000D444D8: BF8700B1
	v_add_f32_e32 v7, v9, v24                                  // 000000D444DC: 060E3109
	v_mov_b32_dpp v9, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D444E0: 7E1202FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 000000D444E8: D5010008 200A1108
	v_add_f32_e32 v8, v8, v9                                   // 000000D444F0: 06101308
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D444F4: BF8701A4
	v_mov_b32_dpp v9, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D444F8: 7E1202FA FF016207
	v_cndmask_b32_e64 v7, -v7, v7, s2                          // 000000D44500: D5010007 200A0F07
	v_mov_b32_dpp v23, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D44508: 7E2E02FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, s1                          // 000000D44510: D5010008 20061108
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000D44518: BF8701B1
	v_dual_add_f32 v7, v7, v9 :: v_dual_add_f32 v8, v8, v23    // 000000D4451C: C9081307 07082F08
	v_mov_b32_dpp v25, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D44524: 7E3202FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 000000D4452C: D5010005 200E0B05
	v_mov_b32_dpp v23, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D44534: 7E2E02FA FF016407
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 000000D4453C: D5010007 20060F07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D44544: BF8701A3
	v_add_f32_e32 v5, v5, v25                                  // 000000D44548: 060A3305
	.long 0x7f323880                                           // 000000D4454C: 7F323880
	v_add_f32_e32 v7, v7, v23                                  // 000000D44550: 060E2F07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D44554: BF8700A3
	v_mov_b32_dpp v24, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D44558: 7E3002FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s2                          // 000000D44560: D5010005 200A0B05
	v_add_f32_e32 v5, v5, v24                                  // 000000D44568: 060A3105
	v_mov_b32_dpp v24, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D4456C: 7E3002FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 000000D44574: D5010006 20060D06
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D4457C: BF8700A3
	v_mov_b32_dpp v9, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D44580: 7E1202FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s1                          // 000000D44588: D5010005 20060B05
	v_dual_add_f32 v6, v6, v24 :: v_dual_add_f32 v5, v5, v9    // 000000D44590: C9083106 06041305
	v_mov_b32_dpp v9, v8 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D44598: 7E1202FA FF016808
	v_cndmask_b32_e64 v8, -v8, v8, s0                          // 000000D445A0: D5010008 20021108
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D445A8: BF870211
	v_add_f32_e32 v8, v8, v9                                   // 000000D445AC: 06101308
	v_mov_b32_dpp v9, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D445B0: 7E1202FA FF016806
	v_cndmask_b32_e64 v6, -v6, v6, s0                          // 000000D445B8: D5010006 20020D06
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D445C0: BF8701A3
	v_mov_b32_e32 v23, v8                                      // 000000D445C4: 7E2E0308
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000D445C8: D5010008 21AA1108
	v_add_f32_e32 v6, v6, v9                                   // 000000D445D0: 060C1306
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D445D4: BF870113
	v_permlanex16_b32 v23, v23, s4, 0xfedcba98                 // 000000D445D8: D65C0017 03FC0917 FEDCBA98
	v_mov_b32_e32 v9, v6                                       // 000000D445E4: 7E120306
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 000000D445E8: D5010006 21AA0D06
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000D445F0: BF870243
	v_add_f32_e32 v8, v8, v23                                  // 000000D445F4: 06102F08
	v_mov_b32_dpp v24, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D445F8: 7E3002FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 000000D44600: D5010005 20020B05
	v_permlanex16_b32 v9, v9, s4, 0xfedcba98                   // 000000D44608: D65C0009 03FC0909 FEDCBA98
	v_mul_f32_e32 v8, 0x3db504f3, v8                           // 000000D44614: 101010FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000D4461C: BF870122
	v_dual_add_f32 v5, v5, v24 :: v_dual_add_f32 v6, v6, v9    // 000000D44620: C9083105 05061306
	.long 0x7f123999                                           // 000000D44628: 7F123999
	v_mov_b32_e32 v26, v5                                      // 000000D4462C: 7E340305
	v_mov_b32_dpp v24, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D44630: 7E3002FA FF016807
	v_cndmask_b32_e64 v7, -v7, v7, s0                          // 000000D44638: D5010007 20020F07
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000D44640: D5010005 21AA0B05
	v_mul_f32_e32 v6, 0x3db504f3, v6                           // 000000D44648: 100C0CFF 3DB504F3
	v_permlanex16_b32 v26, v26, s4, 0xfedcba98                 // 000000D44650: D65C001A 03FC091A FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D4465C: BF870114
	v_add_f32_e32 v7, v7, v24                                  // 000000D44660: 060E3107
	v_add_f32_e32 v5, v5, v26                                  // 000000D44664: 060A3505
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D44668: BF8701A2
	v_mov_b32_e32 v23, v7                                      // 000000D4466C: 7E2E0307
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000D44670: D5010007 21AA0F07
	v_mul_f32_e32 v5, 0x3db504f3, v5                           // 000000D44678: 100A0AFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D44680: BF870093
	v_permlanex16_b32 v23, v23, s4, 0xfedcba98                 // 000000D44684: D65C0017 03FC0917 FEDCBA98
	v_add_f32_e32 v7, v7, v23                                  // 000000D44690: 060E2F07
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D44694: BF870001
	v_mul_f32_e32 v7, 0x3db504f3, v7                           // 000000D44698: 100E0EFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000D446A0: BF8903F7
	v_fma_mix_f32 v8, v22, v8, neg(0) op_sel_hi:[1,0,0]        // 000000D446A4: CC200008 8A021116
	v_fma_mix_f32 v5, v22, v5, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D446AC: CC200805 8A020B16
	.long 0x7f2c3999                                           // 000000D446B4: 7F2C3999
	v_fma_mix_f32 v6, v21, v6, neg(0) op_sel_hi:[1,0,0]        // 000000D446B8: CC200006 8A020D15
	v_fma_mix_f32 v7, v21, v7, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D446C0: CC200807 8A020F15
	.long 0x7e123988                                           // 000000D446C8: 7E123988
	.long 0x7e2c3985                                           // 000000D446CC: 7E2C3985
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D446D0: BF870193
	v_bfe_u32 v23, v7, 16, 1                                   // 000000D446D4: D6100017 02052107
	v_and_b32_e32 v9, 1, v9                                    // 000000D446DC: 36121281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D446E0: BF870193
	v_and_b32_e32 v21, 1, v22                                  // 000000D446E4: 362A2C81
	v_add3_u32 v7, v7, v23, 0x7fff                             // 000000D446E8: D6550007 03FE2F07 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D446F4: BF870223
	v_add3_u32 v8, v8, v9, 0x7fff                              // 000000D446F8: D6550008 03FE1308 00007FFF
	v_bfe_u32 v9, v6, 16, 1                                    // 000000D44704: D6100009 02052106
	v_add3_u32 v5, v5, v21, 0x7fff                             // 000000D4470C: D6550005 03FE2B05 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D44718: BF870193
	.long 0x7e2c3988                                           // 000000D4471C: 7E2C3988
	v_add3_u32 v6, v6, v9, 0x7fff                              // 000000D44720: D6550006 03FE1306 00007FFF
	v_add_nc_u32_e32 v8, s18, v18                              // 000000D4472C: 4A102412
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D44730: BF870214
	v_and_b32_e32 v9, 0xffff0000, v5                           // 000000D44734: 36120AFF FFFF0000
	v_and_b32_e32 v21, 0xffff, v22                             // 000000D4473C: 362A2CFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D44744: BF870214
	.long 0x7e323986                                           // 000000D44748: 7E323986
	v_mad_i64_i32 v[5:6], null, 0x1400, v8, v[1:2]             // 000000D4474C: D6FF7C05 040610FF 00001400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D44758: BF870193
	v_or_b32_e32 v8, v9, v21                                   // 000000D4475C: 38102B09
	v_and_or_b32 v7, 0xffff0000, v7, v25                       // 000000D44760: D6570007 04660EFF FFFF0000
	global_store_b64 v[5:6], v[7:8], off                       // 000000D4476C: DC6E0000 007C0705
	s_or_b32 exec_lo, exec_lo, s5                              // 000000D44774: 8C7E057E
	v_or_b32_e32 v6, 8, v18                                    // 000000D44778: 380C2488
	s_mov_b32 s5, exec_lo                                      // 000000D4477C: BE85007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D44780: BF870001
	v_mad_u32_u24 v5, 0x210, v6, v20                           // 000000D44784: D60B0005 04520CFF 00000210
	.long 0xd4c4007e                                           // 000000D44790: D4C4007E
	v_cndmask_b32_e32 v1, s19, v6, vcc_lo                      // 000000D44794: 02020C13
	s_cbranch_execz 201                                        // 000000D44798: BFA500C9 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x88c0>
	global_load_b64 v[7:8], v3, s[12:13]                       // 000000D4479C: DC560000 070C0003
	ds_load_b128 v[20:23], v5                                  // 000000D447A4: DBFC0000 14000005
	s_mov_b32 s4, 0x76543210                                   // 000000D447AC: BE8400FF 76543210
	s_waitcnt lgkmcnt(0)                                       // 000000D447B4: BF89FC07
	v_dual_add_f32 v9, v20, v21 :: v_dual_add_nc_u32 v6, s18, v6// 000000D447B8: C9202B14 09060C12
	v_add_f32_e32 v24, v22, v23                                // 000000D447C0: 06302F16
	v_dual_sub_f32 v20, v20, v21 :: v_dual_sub_f32 v21, v22, v23// 000000D447C4: C94A2B14 14142F16
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D447CC: BF8701A2
	v_add_f32_e32 v22, v9, v24                                 // 000000D447D0: 062C3109
	v_sub_f32_e32 v9, v9, v24                                  // 000000D447D4: 08123109
	v_add_f32_e32 v23, v20, v21                                // 000000D447D8: 062E2B14
	v_sub_f32_e32 v20, v20, v21                                // 000000D447DC: 08282B14
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D447E0: BF870214
	v_mov_b32_dpp v21, v22 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D447E4: 7E2A02FA FF016116
	v_mov_b32_dpp v24, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D447EC: 7E3002FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 000000D447F4: D5010009 200E1309
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000D447FC: BF870254
	v_mov_b32_dpp v26, v20 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D44800: 7E3402FA FF016114
	v_cndmask_b32_e64 v20, -v20, v20, s3                       // 000000D44808: D5010014 200E2914
	v_cndmask_b32_e64 v22, -v22, v22, s3                       // 000000D44810: D5010016 200E2D16
	v_mov_b32_dpp v25, v23 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D44818: 7E3202FA FF016117
	v_cndmask_b32_e64 v23, -v23, v23, s3                       // 000000D44820: D5010017 200E2F17
	v_dual_add_f32 v9, v9, v24 :: v_dual_add_f32 v20, v20, v26 // 000000D44828: C9083109 09143514
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D44830: BF870224
	v_add_f32_e32 v21, v22, v21                                // 000000D44834: 062A2B16
	.long 0x7f343880                                           // 000000D44838: 7F343880
	v_add_f32_e32 v22, v23, v25                                // 000000D4483C: 062C3317
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000D44840: BF8701C4
	v_mov_b32_dpp v23, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D44844: 7E2E02FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s2                          // 000000D4484C: D5010009 200A1309
	v_mov_b32_dpp v25, v20 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D44854: 7E3202FA FF016214
	v_cndmask_b32_e64 v20, -v20, v20, s2                       // 000000D4485C: D5010014 200A2914
	v_add_f32_e32 v9, v9, v23                                  // 000000D44864: 06122F09
	v_mov_b32_dpp v23, v22 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D44868: 7E2E02FA FF016216
	v_cndmask_b32_e64 v22, -v22, v22, s2                       // 000000D44870: D5010016 200A2D16
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D44878: BF870114
	v_add_f32_e32 v20, v20, v25                                // 000000D4487C: 06283314
	v_add_f32_e32 v22, v22, v23                                // 000000D44880: 062C2F16
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D44884: BF8700A2
	v_mov_b32_dpp v23, v20 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D44888: 7E2E02FA FF016414
	v_cndmask_b32_e64 v20, -v20, v20, s1                       // 000000D44890: D5010014 20062914
	v_add_f32_e32 v20, v20, v23                                // 000000D44898: 06282F14
	v_mov_b32_dpp v24, v21 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D4489C: 7E3002FA FF016215
	v_cndmask_b32_e64 v21, -v21, v21, s2                       // 000000D448A4: D5010015 200A2B15
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000D448AC: BF8701B1
	v_add_f32_e32 v21, v21, v24                                // 000000D448B0: 062A3115
	v_mov_b32_dpp v24, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D448B4: 7E3002FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 000000D448BC: D5010009 20061309
	v_mov_b32_dpp v25, v21 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D448C4: 7E3202FA FF016415
	v_cndmask_b32_e64 v21, -v21, v21, s1                       // 000000D448CC: D5010015 20062B15
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000D448D4: BF870233
	v_add_f32_e32 v9, v9, v24                                  // 000000D448D8: 06123109
	v_mov_b32_dpp v24, v22 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D448DC: 7E3002FA FF016416
	v_cndmask_b32_e64 v22, -v22, v22, s1                       // 000000D448E4: D5010016 20062D16
	v_add_f32_e32 v21, v21, v25                                // 000000D448EC: 062A3315
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000D448F0: BF8701C4
	v_mov_b32_dpp v23, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D448F4: 7E2E02FA FF016809
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 000000D448FC: D5010009 20021309
	v_mov_b32_dpp v25, v20 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D44904: 7E3202FA FF016814
	v_cndmask_b32_e64 v20, -v20, v20, s0                       // 000000D4490C: D5010014 20022914
	v_dual_add_f32 v22, v22, v24 :: v_dual_add_f32 v9, v9, v23 // 000000D44914: C9083116 16082F09
	v_mov_b32_dpp v23, v21 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D4491C: 7E2E02FA FF016815
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D44924: BF870223
	v_add_f32_e32 v20, v20, v25                                // 000000D44928: 06283314
	v_cndmask_b32_e64 v21, -v21, v21, s0                       // 000000D4492C: D5010015 20022B15
	v_mov_b32_dpp v25, v22 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D44934: 7E3202FA FF016816
	v_mov_b32_e32 v24, v9                                      // 000000D4493C: 7E300309
	v_cndmask_b32_e64 v22, -v22, v22, s0                       // 000000D44940: D5010016 20022D16
	v_mov_b32_e32 v27, v20                                     // 000000D44948: 7E360314
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000D4494C: D5010009 21AA1309
	v_add_f32_e32 v21, v21, v23                                // 000000D44954: 062A2F15
	v_permlanex16_b32 v24, v24, s4, 0xfedcba98                 // 000000D44958: D65C0018 03FC0918 FEDCBA98
	v_add_f32_e32 v22, v22, v25                                // 000000D44964: 062C3316
	v_cndmask_b32_e64 v20, -v20, v20, vcc_lo                   // 000000D44968: D5010014 21AA2914
	v_permlanex16_b32 v27, v27, s4, 0xfedcba98                 // 000000D44970: D65C001B 03FC091B FEDCBA98
	v_mov_b32_e32 v23, v21                                     // 000000D4497C: 7E2E0315
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D44980: BF870224
	v_dual_add_f32 v9, v9, v24 :: v_dual_mov_b32 v24, v22      // 000000D44984: C9103109 09180116
	v_cndmask_b32_e64 v21, -v21, v21, vcc_lo                   // 000000D4498C: D5010015 21AA2B15
	v_add_f32_e32 v20, v20, v27                                // 000000D44994: 06283714
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D44998: BF870214
	v_permlanex16_b32 v23, v23, s4, 0xfedcba98                 // 000000D4499C: D65C0017 03FC0917 FEDCBA98
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 000000D449A8: 101212FF 3DB504F3
	v_cndmask_b32_e64 v22, -v22, v22, vcc_lo                   // 000000D449B0: D5010016 21AA2D16
	v_permlanex16_b32 v24, v24, s4, 0xfedcba98                 // 000000D449B8: D65C0018 03FC0918 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D449C4: BF8701A4
	v_dual_mul_f32 v20, 0x3db504f3, v20 :: v_dual_add_f32 v21, v21, v23// 000000D449C8: C8C828FF 14142F15 3DB504F3
	.long 0x7f2e399a                                           // 000000D449D4: 7F2E399A
	v_add_f32_e32 v22, v22, v24                                // 000000D449D8: 062C3116
	s_waitcnt vmcnt(0)                                         // 000000D449DC: BF8903F7
	v_fma_mix_f32 v9, v8, v9, neg(0) op_sel_hi:[1,0,0]         // 000000D449E0: CC200009 8A021308
	v_fma_mix_f32 v8, v8, v20, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D449E8: CC200808 8A022908
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000D449F0: BF870232
	.long 0x7e2e3989                                           // 000000D449F4: 7E2E3989
	v_mul_f32_e32 v20, 0x3db504f3, v21                         // 000000D449F8: 10282AFF 3DB504F3
	.long 0x7f2a399a                                           // 000000D44A00: 7F2A399A
	.long 0x7e2a3988                                           // 000000D44A04: 7E2A3988
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D44A08: BF870214
	v_dual_mul_f32 v22, 0x3db504f3, v22 :: v_dual_and_b32 v23, 1, v23// 000000D44A0C: C8E42CFF 16162E81 3DB504F3
	v_fma_mix_f32 v20, v7, v20, neg(0) op_sel_hi:[1,0,0]       // 000000D44A18: CC200014 8A022907
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D44A20: BF870193
	v_and_b32_e32 v21, 1, v21                                  // 000000D44A24: 362A2A81
	v_fma_mix_f32 v7, v7, v22, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D44A28: CC200807 8A022D07
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D44A30: BF870214
	v_add3_u32 v9, v9, v23, 0x7fff                             // 000000D44A34: D6550009 03FE2F09 00007FFF
	v_bfe_u32 v22, v20, 16, 1                                  // 000000D44A40: D6100016 02052114
	.long 0x7f2e399a                                           // 000000D44A48: 7F2E399A
	v_add3_u32 v8, v8, v21, 0x7fff                             // 000000D44A4C: D6550008 03FE2B08 00007FFF
	v_bfe_u32 v24, v7, 16, 1                                   // 000000D44A58: D6100018 02052107
	.long 0x7e2e3989                                           // 000000D44A60: 7E2E3989
	v_add3_u32 v9, v20, v22, 0x7fff                            // 000000D44A64: D6550009 03FE2D14 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D44A70: BF870214
	v_and_b32_e32 v8, 0xffff0000, v8                           // 000000D44A74: 361010FF FFFF0000
	v_add3_u32 v20, v7, v24, 0x7fff                            // 000000D44A7C: D6550014 03FE3107 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D44A88: BF870214
	v_and_b32_e32 v21, 0xffff, v23                             // 000000D44A8C: 362A2EFF 0000FFFF
	.long 0x7e343989                                           // 000000D44A94: 7E343989
	v_mad_i64_i32 v[6:7], null, 0x1400, v6, v[1:2]             // 000000D44A98: D6FF7C06 04060CFF 00001400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D44AA4: BF870193
	v_or_b32_e32 v9, v8, v21                                   // 000000D44AA8: 38122B08
	v_and_or_b32 v8, 0xffff0000, v20, v26                      // 000000D44AAC: D6570008 046A28FF FFFF0000
	global_store_b64 v[6:7], v[8:9], off                       // 000000D44AB8: DC6E0000 007C0806
	s_or_b32 exec_lo, exec_lo, s5                              // 000000D44AC0: 8C7E057E
	v_or_b32_e32 v6, 16, v18                                   // 000000D44AC4: 380C2490
	s_mov_b32 s5, exec_lo                                      // 000000D44AC8: BE85007E
	s_waitcnt_vscnt null, 0x0                                  // 000000D44ACC: BC7C0000
	s_barrier                                                  // 000000D44AD0: BFBD0000
	buffer_gl0_inv                                             // 000000D44AD4: E0AC0000 00000000
	ds_store_2addr_b32 v19, v10, v11 offset1:2                 // 000000D44ADC: D8380200 000B0A13
	ds_store_2addr_b32 v19, v12, v13 offset0:4 offset1:6       // 000000D44AE4: D8380604 000D0C13
	ds_store_2addr_b32 v19, v14, v15 offset0:8 offset1:10      // 000000D44AEC: D8380A08 000F0E13
	ds_store_2addr_b32 v19, v16, v17 offset0:12 offset1:14     // 000000D44AF4: D8380E0C 00111013
	s_waitcnt lgkmcnt(0)                                       // 000000D44AFC: BF89FC07
	s_barrier                                                  // 000000D44B00: BFBD0000
	buffer_gl0_inv                                             // 000000D44B04: E0AC0000 00000000
	.long 0xd4c4007e                                           // 000000D44B0C: D4C4007E
	v_cndmask_b32_e32 v1, s19, v6, vcc_lo                      // 000000D44B10: 02020C13
	s_cbranch_execz 199                                        // 000000D44B14: BFA500C7 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x8c34>
	global_load_b64 v[11:12], v3, s[12:13]                     // 000000D44B18: DC560000 0B0C0003
	ds_load_b128 v[7:10], v4                                   // 000000D44B20: DBFC0000 07000004
	s_mov_b32 s4, 0x76543210                                   // 000000D44B28: BE8400FF 76543210
	v_add_nc_u32_e32 v6, s18, v6                               // 000000D44B30: 4A0C0C12
	s_waitcnt lgkmcnt(0)                                       // 000000D44B34: BF89FC07
	v_dual_add_f32 v4, v7, v8 :: v_dual_add_f32 v13, v9, v10   // 000000D44B38: C9081107 040C1509
	v_dual_sub_f32 v7, v7, v8 :: v_dual_sub_f32 v8, v9, v10    // 000000D44B40: C94A1107 07081509
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D44B48: BF8701A2
	v_add_f32_e32 v9, v4, v13                                  // 000000D44B4C: 06121B04
	v_sub_f32_e32 v4, v4, v13                                  // 000000D44B50: 08081B04
	v_add_f32_e32 v10, v7, v8                                  // 000000D44B54: 06141107
	v_sub_f32_e32 v7, v7, v8                                   // 000000D44B58: 080E1107
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D44B5C: BF870214
	v_mov_b32_dpp v8, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D44B60: 7E1002FA FF016109
	v_mov_b32_dpp v13, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D44B68: 7E1A02FA FF016104
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000D44B70: D5010004 200E0904
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 000000D44B78: D5010009 200E1309
	v_mov_b32_dpp v14, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D44B80: 7E1C02FA FF01610A
	v_mov_b32_dpp v15, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D44B88: 7E1E02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s3                          // 000000D44B90: D5010007 200E0F07
	v_cndmask_b32_e64 v10, -v10, v10, s3                       // 000000D44B98: D501000A 200E150A
	v_add_f32_e32 v4, v4, v13                                  // 000000D44BA0: 06081B04
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D44BA4: BF870193
	v_dual_add_f32 v8, v9, v8 :: v_dual_add_f32 v7, v7, v15    // 000000D44BA8: C9081109 08061F07
	v_add_f32_e32 v9, v10, v14                                 // 000000D44BB0: 06121D0A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D44BB4: BF870223
	v_mov_b32_dpp v10, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D44BB8: 7E1402FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s2                          // 000000D44BC0: D5010004 200A0904
	v_mov_b32_dpp v13, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D44BC8: 7E1A02FA FF016208
	v_mov_b32_dpp v14, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D44BD0: 7E1C02FA FF016207
	v_cndmask_b32_e64 v7, -v7, v7, s2                          // 000000D44BD8: D5010007 200A0F07
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 000000D44BE0: D5010008 200A1108
	v_add_f32_e32 v4, v4, v10                                  // 000000D44BE8: 06081504
	v_mov_b32_dpp v10, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D44BEC: 7E1402FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s2                          // 000000D44BF4: D5010009 200A1309
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D44BFC: BF870214
	v_dual_add_f32 v7, v7, v14 :: v_dual_add_f32 v8, v8, v13   // 000000D44C00: C9081D07 07081B08
	v_mov_b32_dpp v13, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D44C08: 7E1A02FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000D44C10: D5010004 20060904
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D44C18: BF870214
	v_add_f32_e32 v9, v9, v10                                  // 000000D44C1C: 06121509
	v_mov_b32_dpp v10, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D44C20: 7E1402FA FF016407
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 000000D44C28: D5010007 20060F07
	v_mov_b32_dpp v14, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D44C30: 7E1C02FA FF016408
	v_add_f32_e32 v4, v4, v13                                  // 000000D44C38: 06081B04
	v_mov_b32_dpp v13, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D44C3C: 7E1A02FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 000000D44C44: D5010009 20061309
	v_add_f32_e32 v7, v7, v10                                  // 000000D44C4C: 060E1507
	v_cndmask_b32_e64 v8, -v8, v8, s1                          // 000000D44C50: D5010008 20061108
	v_mov_b32_dpp v10, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D44C58: 7E1402FA FF016804
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 000000D44C60: D5010004 20020904
	v_add_f32_e32 v9, v9, v13                                  // 000000D44C68: 06121B09
	.long 0x7f1e3880                                           // 000000D44C6C: 7F1E3880
	v_add_f32_e32 v8, v8, v14                                  // 000000D44C70: 06101D08
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D44C74: BF870094
	v_add_f32_e32 v4, v4, v10                                  // 000000D44C78: 06081504
	v_mov_b32_e32 v13, v4                                      // 000000D44C7C: 7E1A0304
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000D44C80: D5010004 21AA0904
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D44C88: BF870092
	v_permlanex16_b32 v13, v13, s4, 0xfedcba98                 // 000000D44C8C: D65C000D 03FC090D FEDCBA98
	v_add_f32_e32 v4, v4, v13                                  // 000000D44C98: 06081B04
	v_mov_b32_dpp v14, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D44C9C: 7E1C02FA FF016807
	v_cndmask_b32_e64 v7, -v7, v7, s0                          // 000000D44CA4: D5010007 20020F07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000D44CAC: BF8700B1
	v_dual_mul_f32 v4, 0x3db504f3, v4 :: v_dual_add_f32 v7, v7, v14// 000000D44CB0: C8C808FF 04061D07 3DB504F3
	v_mov_b32_dpp v14, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D44CBC: 7E1C02FA FF016809
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 000000D44CC4: D5010009 20021309
	v_add_f32_e32 v9, v9, v14                                  // 000000D44CCC: 06121D09
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000D44CD0: BF870241
	v_mov_b32_e32 v13, v9                                      // 000000D44CD4: 7E1A0309
	v_mov_b32_dpp v10, v8 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D44CD8: 7E1402FA FF016808
	v_cndmask_b32_e64 v8, -v8, v8, s0                          // 000000D44CE0: D5010008 20021108
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000D44CE8: D5010009 21AA1309
	v_permlanex16_b32 v13, v13, s4, 0xfedcba98                 // 000000D44CF0: D65C000D 03FC090D FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D44CFC: BF870091
	v_dual_add_f32 v8, v8, v10 :: v_dual_add_f32 v9, v9, v13   // 000000D44D00: C9081508 08081B09
	v_mov_b32_e32 v10, v8                                      // 000000D44D08: 7E140308
	v_mov_b32_e32 v16, v7                                      // 000000D44D0C: 7E200307
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000D44D10: D5010007 21AA0F07
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D44D18: BF870214
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 000000D44D1C: 101212FF 3DB504F3
	v_permlanex16_b32 v10, v10, s4, 0xfedcba98                 // 000000D44D24: D65C000A 03FC090A FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D44D30: BF870094
	v_permlanex16_b32 v16, v16, s4, 0xfedcba98                 // 000000D44D34: D65C0010 03FC0910 FEDCBA98
	v_add_f32_e32 v7, v7, v16                                  // 000000D44D40: 060E2107
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D44D44: BF8700A1
	v_mul_f32_e32 v7, 0x3db504f3, v7                           // 000000D44D48: 100E0EFF 3DB504F3
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000D44D50: D5010008 21AA1108
	v_add_f32_e32 v8, v8, v10                                  // 000000D44D58: 06101508
	.long 0x7f14398f                                           // 000000D44D5C: 7F14398F
	s_delay_alu instid0(VALU_DEP_2)                            // 000000D44D60: BF870002
	v_mul_f32_e32 v8, 0x3db504f3, v8                           // 000000D44D64: 101010FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000D44D6C: BF8903F7
	v_fma_mix_f32 v4, v12, v4, neg(0) op_sel_hi:[1,0,0]        // 000000D44D70: CC200004 8A02090C
	v_fma_mix_f32 v7, v12, v7, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D44D78: CC200807 8A020F0C
	.long 0x7f18398f                                           // 000000D44D80: 7F18398F
	v_fma_mix_f32 v8, v11, v8, neg(0) op_sel_hi:[1,0,0]        // 000000D44D84: CC200008 8A02110B
	v_fma_mix_f32 v9, v11, v9, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D44D8C: CC200809 8A02130B
	.long 0x7e143984                                           // 000000D44D94: 7E143984
	.long 0x7e183987                                           // 000000D44D98: 7E183987
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D44D9C: BF870193
	v_bfe_u32 v13, v9, 16, 1                                   // 000000D44DA0: D610000D 02052109
	v_and_b32_e32 v10, 1, v10                                  // 000000D44DA8: 36141481
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D44DAC: BF870113
	v_and_b32_e32 v11, 1, v12                                  // 000000D44DB0: 36161881
	v_add3_u32 v4, v4, v10, 0x7fff                             // 000000D44DB4: D6550004 03FE1504 00007FFF
	v_bfe_u32 v10, v8, 16, 1                                   // 000000D44DC0: D610000A 02052108
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D44DC8: BF870193
	v_add3_u32 v7, v7, v11, 0x7fff                             // 000000D44DCC: D6550007 03FE1707 00007FFF
	.long 0x7e183984                                           // 000000D44DD8: 7E183984
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D44DDC: BF870223
	v_add3_u32 v4, v8, v10, 0x7fff                             // 000000D44DE0: D6550004 03FE1508 00007FFF
	v_add3_u32 v8, v9, v13, 0x7fff                             // 000000D44DEC: D6550008 03FE1B09 00007FFF
	v_and_b32_e32 v9, 0xffff0000, v7                           // 000000D44DF8: 36120EFF FFFF0000
	v_mad_i64_i32 v[6:7], null, 0x1400, v6, v[1:2]             // 000000D44E00: D6FF7C06 04060CFF 00001400
	v_and_b32_e32 v10, 0xffff, v12                             // 000000D44E0C: 361418FF 0000FFFF
	.long 0x7e1e3984                                           // 000000D44E14: 7E1E3984
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D44E18: BF870112
	v_or_b32_e32 v9, v9, v10                                   // 000000D44E1C: 38121509
	v_and_or_b32 v8, 0xffff0000, v8, v15                       // 000000D44E20: D6570008 043E10FF FFFF0000
	global_store_b64 v[6:7], v[8:9], off                       // 000000D44E2C: DC6E0000 007C0806
	s_or_b32 exec_lo, exec_lo, s5                              // 000000D44E34: 8C7E057E
	v_or_b32_e32 v4, 24, v18                                   // 000000D44E38: 38082498
	s_mov_b32 s5, exec_lo                                      // 000000D44E3C: BE85007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D44E40: BF870001
	.long 0xd4c4007e                                           // 000000D44E44: D4C4007E
	v_cndmask_b32_e32 v1, s19, v4, vcc_lo                      // 000000D44E48: 02020813
	s_cbranch_execz 198                                        // 000000D44E4C: BFA500C6 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x8f68>
	global_load_b64 v[9:10], v3, s[12:13]                      // 000000D44E50: DC560000 090C0003
	ds_load_b128 v[5:8], v5                                    // 000000D44E58: DBFC0000 05000005
	v_add_nc_u32_e32 v4, s18, v4                               // 000000D44E60: 4A080812
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000D44E64: BF8700C1
	v_mad_i64_i32 v[1:2], null, 0x1400, v4, v[1:2]             // 000000D44E68: D6FF7C01 040608FF 00001400
	s_waitcnt lgkmcnt(0)                                       // 000000D44E74: BF89FC07
	v_add_f32_e32 v3, v5, v6                                   // 000000D44E78: 06060D05
	v_dual_sub_f32 v5, v5, v6 :: v_dual_sub_f32 v6, v7, v8     // 000000D44E7C: C94A0D05 05061107
	v_dual_add_f32 v11, v7, v8 :: v_dual_add_f32 v8, v5, v6    // 000000D44E84: C9081107 0B080D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000D44E8C: BF870231
	v_add_f32_e32 v7, v3, v11                                  // 000000D44E90: 060E1703
	v_sub_f32_e32 v3, v3, v11                                  // 000000D44E94: 08061703
	v_sub_f32_e32 v5, v5, v6                                   // 000000D44E98: 080A0D05
	v_mov_b32_dpp v12, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D44E9C: 7E1802FA FF016108
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D44EA4: BF870214
	v_mov_b32_dpp v6, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D44EA8: 7E0C02FA FF016107
	v_mov_b32_dpp v11, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D44EB0: 7E1602FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 000000D44EB8: D5010003 200E0703
	v_cndmask_b32_e64 v7, -v7, v7, s3                          // 000000D44EC0: D5010007 200E0F07
	v_mov_b32_dpp v13, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D44EC8: 7E1A02FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 000000D44ED0: D5010005 200E0B05
	v_cndmask_b32_e64 v8, -v8, v8, s3                          // 000000D44ED8: D5010008 200E1108
	v_add_f32_e32 v3, v3, v11                                  // 000000D44EE0: 06061703
	v_add_f32_e32 v6, v7, v6                                   // 000000D44EE4: 060C0D07
	s_mov_b32 s3, 0x76543210                                   // 000000D44EE8: BE8300FF 76543210
	v_add_f32_e32 v5, v5, v13                                  // 000000D44EF0: 060A1B05
	v_add_f32_e32 v7, v8, v12                                  // 000000D44EF4: 060E1908
	v_mov_b32_dpp v8, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D44EF8: 7E1002FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s2                          // 000000D44F00: D5010003 200A0703
	v_mov_b32_dpp v11, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D44F08: 7E1602FA FF016206
	v_mov_b32_dpp v12, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D44F10: 7E1802FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s2                          // 000000D44F18: D5010005 200A0B05
	v_cndmask_b32_e64 v6, -v6, v6, s2                          // 000000D44F20: D5010006 200A0D06
	v_add_f32_e32 v3, v3, v8                                   // 000000D44F28: 06061103
	v_mov_b32_dpp v8, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D44F2C: 7E1002FA FF016207
	v_cndmask_b32_e64 v7, -v7, v7, s2                          // 000000D44F34: D5010007 200A0F07
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D44F3C: BF870214
	v_dual_add_f32 v5, v5, v12 :: v_dual_add_f32 v6, v6, v11   // 000000D44F40: C9081905 05061706
	v_mov_b32_dpp v11, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D44F48: 7E1602FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 000000D44F50: D5010003 20060703
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D44F58: BF870214
	v_add_f32_e32 v7, v7, v8                                   // 000000D44F5C: 060E1107
	v_mov_b32_dpp v8, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D44F60: 7E1002FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s1                          // 000000D44F68: D5010005 20060B05
	v_mov_b32_dpp v12, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D44F70: 7E1802FA FF016406
	v_add_f32_e32 v3, v3, v11                                  // 000000D44F78: 06061703
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 000000D44F7C: D5010006 20060D06
	v_mov_b32_dpp v11, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D44F84: 7E1602FA FF016407
	v_add_f32_e32 v5, v5, v8                                   // 000000D44F8C: 060A1105
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 000000D44F90: D5010007 20060F07
	v_mov_b32_dpp v8, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D44F98: 7E1002FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 000000D44FA0: D5010003 20020703
	v_add_f32_e32 v6, v6, v12                                  // 000000D44FA8: 060C1906
	.long 0x7f1a3880                                           // 000000D44FAC: 7F1A3880
	v_mov_b32_dpp v12, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D44FB0: 7E1802FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 000000D44FB8: D5010005 20020B05
	v_add_f32_e32 v3, v3, v8                                   // 000000D44FC0: 06061103
	v_mov_b32_dpp v8, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D44FC4: 7E1002FA FF016806
	v_cndmask_b32_e64 v6, -v6, v6, s0                          // 000000D44FCC: D5010006 20020D06
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D44FD4: BF870114
	v_add_f32_e32 v5, v5, v12                                  // 000000D44FD8: 060A1905
	v_add_f32_e32 v6, v6, v8                                   // 000000D44FDC: 060C1106
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D44FE0: BF8701A2
	v_mov_b32_e32 v14, v5                                      // 000000D44FE4: 7E1C0305
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000D44FE8: D5010005 21AA0B05
	v_mov_b32_e32 v8, v6                                       // 000000D44FF0: 7E100306
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 000000D44FF4: D5010006 21AA0D06
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D44FFC: BF870194
	v_permlanex16_b32 v14, v14, s3, 0xfedcba98                 // 000000D45000: D65C000E 03FC070E FEDCBA98
	v_permlanex16_b32 v8, v8, s3, 0xfedcba98                   // 000000D4500C: D65C0008 03FC0708 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D45018: BF870001
	v_dual_add_f32 v5, v5, v14 :: v_dual_add_f32 v6, v6, v8    // 000000D4501C: C9081D05 05061106
	.long 0x7f10398d                                           // 000000D45024: 7F10398D
	v_add_f32_e32 v7, v7, v11                                  // 000000D45028: 060E1707
	v_mov_b32_e32 v11, v3                                      // 000000D4502C: 7E160303
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000D45030: D5010003 21AA0703
	v_dual_mul_f32 v5, 0x3db504f3, v5 :: v_dual_mul_f32 v6, 0x3db504f3, v6// 000000D45038: C8C60AFF 05060CFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D45044: BF870093
	v_permlanex16_b32 v11, v11, s3, 0xfedcba98                 // 000000D45048: D65C000B 03FC070B FEDCBA98
	v_add_f32_e32 v3, v3, v11                                  // 000000D45054: 06061703
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D45058: BF8700A1
	v_mul_f32_e32 v3, 0x3db504f3, v3                           // 000000D4505C: 100606FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000D45064: BF8903F7
	v_fma_mix_f32 v3, v10, v3, neg(0) op_sel_hi:[1,0,0]        // 000000D45068: CC200003 8A02070A
	v_fma_mix_f32 v5, v10, v5, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D45070: CC200805 8A020B0A
	.long 0x7f14398d                                           // 000000D45078: 7F14398D
	v_fma_mix_f32 v6, v9, v6, neg(0) op_sel_hi:[1,0,0]         // 000000D4507C: CC200006 8A020D09
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D45084: BF870214
	.long 0x7e103983                                           // 000000D45088: 7E103983
	.long 0x7e143985                                           // 000000D4508C: 7E143985
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000D45090: BF8701B2
	v_and_b32_e32 v8, 1, v8                                    // 000000D45094: 36101081
	v_mov_b32_dpp v12, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D45098: 7E1802FA FF016807
	v_cndmask_b32_e64 v7, -v7, v7, s0                          // 000000D450A0: D5010007 20020F07
	v_add3_u32 v3, v3, v8, 0x7fff                              // 000000D450A8: D6550003 03FE1103 00007FFF
	v_bfe_u32 v8, v6, 16, 1                                    // 000000D450B4: D6100008 02052106
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D450BC: BF870093
	v_add_f32_e32 v7, v7, v12                                  // 000000D450C0: 060E1907
	v_mov_b32_e32 v11, v7                                      // 000000D450C4: 7E160307
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000D450C8: D5010007 21AA0F07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D450D0: BF870092
	v_permlanex16_b32 v11, v11, s3, 0xfedcba98                 // 000000D450D4: D65C000B 03FC070B FEDCBA98
	v_add_f32_e32 v7, v7, v11                                  // 000000D450E0: 060E1707
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D450E4: BF870091
	v_mul_f32_e32 v7, 0x3db504f3, v7                           // 000000D450E8: 100E0EFF 3DB504F3
	v_fma_mix_f32 v7, v9, v7, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D450F0: CC200807 8A020F09
	v_and_b32_e32 v9, 1, v10                                   // 000000D450F8: 36121481
	.long 0x7e143983                                           // 000000D450FC: 7E143983
	v_add3_u32 v3, v6, v8, 0x7fff                              // 000000D45100: D6550003 03FE1106 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D4510C: BF870214
	v_bfe_u32 v11, v7, 16, 1                                   // 000000D45110: D610000B 02052107
	v_add3_u32 v5, v5, v9, 0x7fff                              // 000000D45118: D6550005 03FE1305 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D45124: BF870193
	.long 0x7e1a3983                                           // 000000D45128: 7E1A3983
	v_add3_u32 v6, v7, v11, 0x7fff                             // 000000D4512C: D6550006 03FE1707 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D45138: BF8701A3
	v_and_b32_e32 v5, 0xffff0000, v5                           // 000000D4513C: 360A0AFF FFFF0000
	v_and_b32_e32 v7, 0xffff, v10                              // 000000D45144: 360E14FF 0000FFFF
	v_and_or_b32 v3, 0xffff0000, v6, v13                       // 000000D4514C: D6570003 04360CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2)                            // 000000D45158: BF870002
	v_or_b32_e32 v4, v5, v7                                    // 000000D4515C: 38080F05
	global_store_b64 v[1:2], v[3:4], off                       // 000000D45160: DC6E0000 007C0301
	s_or_b32 exec_lo, exec_lo, s5                              // 000000D45168: 8C7E057E
	s_mov_b32 s0, 0                                            // 000000D4516C: BE800080
	s_mov_b32 s3, -1                                           // 000000D45170: BE8300C1
	s_waitcnt_vscnt null, 0x0                                  // 000000D45174: BC7C0000
	s_barrier                                                  // 000000D45178: BFBD0000
	s_and_b32 vcc_lo, exec_lo, s0                              // 000000D4517C: 8B6A007E
	s_cbranch_vccz 1928                                        // 000000D45180: BFA30788 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0xada4>
	s_cmp_eq_u32 s20, 1                                        // 000000D45184: BF068114
	s_cbranch_scc0 1926                                        // 000000D45188: BFA10786 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0xada4>
	v_lshrrev_b32_e32 v5, 4, v0                                // 000000D4518C: 320A0084
	v_lshlrev_b32_e32 v1, 3, v0                                // 000000D45190: 30020083
	s_add_i32 s0, s19, -1                                      // 000000D45194: 8100C113
	s_mov_b32 s1, exec_lo                                      // 000000D45198: BE81007E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D4519C: BF870112
	v_min_i32_e32 v2, s0, v5                                   // 000000D451A0: 22040A00
	v_and_b32_e32 v29, 0x78, v1                                // 000000D451A4: 363A02FF 00000078
	v_mul_u32_u24_e32 v30, 0x110, v5                           // 000000D451AC: 163C0AFF 00000110
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D451B4: BF870193
	v_add_nc_u32_e32 v1, s18, v2                               // 000000D451B8: 4A020412
	v_lshlrev_b32_e32 v2, 1, v29                               // 000000D451BC: 30043A81
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D451C0: BF870112
	v_mad_i64_i32 v[3:4], null, 0x500, v1, 0                   // 000000D451C4: D6FF7C03 020202FF 00000500
	.long 0xd7000001                                           // 000000D451D0: D7000001
	v_cndmask_b32_e32 v1, s10, v2, vcc_lo                      // 000000D451D4: 0202040A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D451D8: BF8701A1
	v_add_co_ci_u32_e64 v2, null, s11, 0, s0                   // 000000D451DC: D5207C02 0001000B
	.long 0xd4490000                                           // 000000D451E4: D4490000
	v_cndmask_b32_e32 v1, 0xff, v0, vcc_lo                     // 000000D451E8: 020200FF 000000FF
	.long 0xd7006a01                                           // 000000D451F0: D7006A01
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 000000D451F4: 02020701
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D451F8: BF870001
	v_add_co_ci_u32_e64 v2, null, v2, v4, vcc_lo               // 000000D451FC: D5207C02 01AA0902
	global_load_b128 v[10:13], v[1:2], off                     // 000000D45204: DC5E0000 0A7C0001
	v_mov_b32_e32 v2, 0                                        // 000000D4520C: 7E040280
	v_cmpx_gt_u32_e32 0x100, v0                                // 000000D45210: 7D9800FF 00000100
	s_cbranch_execz 5                                          // 000000D45218: BFA50005 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x9030>
	v_lshl_add_u32 v1, v29, 1, v30                             // 000000D4521C: D6460001 0479031D
	s_waitcnt vmcnt(0)                                         // 000000D45224: BF8903F7
	ds_store_b128 v1, v[10:13]                                 // 000000D45228: DB7C0000 00000A01
	s_or_b32 exec_lo, exec_lo, s1                              // 000000D45230: 8C7E017E
	v_and_b32_e32 v28, 31, v0                                  // 000000D45234: 3638009F
	s_mul_i32 s2, s16, 0xc8000                                 // 000000D45238: 9602FF10 000C8000
	s_mul_i32 s5, s17, 0xa000                                  // 000000D45240: 9605FF11 0000A000
	s_mul_hi_i32 s1, s16, 0xc8000                              // 000000D45248: 9701FF10 000C8000
	s_mul_hi_i32 s3, s17, 0xa000                               // 000000D45250: 9703FF11 0000A000
	s_add_u32 s2, s2, s5                                       // 000000D45258: 80020502
	s_addc_u32 s3, s1, s3                                      // 000000D4525C: 82030301
	v_lshlrev_b32_e32 v5, 5, v28                               // 000000D45260: 300A3885
	v_cmp_ne_u32_e32 vcc_lo, 0, v28                            // 000000D45264: 7C9A3880
	v_and_b32_e32 v31, 15, v0                                  // 000000D45268: 363E008F
	v_mov_b32_e32 v9, s3                                       // 000000D4526C: 7E120203
	v_lshlrev_b32_e32 v7, 2, v0                                // 000000D45270: 300E0082
	v_add_nc_u32_e32 v6, 0x3f0, v5                             // 000000D45274: 4A0C0AFF 000003F0
	s_mov_b32 s4, 0                                            // 000000D4527C: BE840080
	v_lshlrev_b32_e32 v8, 4, v31                               // 000000D45280: 30103E84
	s_mov_b32 s5, 0xdcd12d                                     // 000000D45284: BE8500FF 00DCD12D
	v_and_or_b32 v7, 0x380, v7, s2                             // 000000D4528C: D6570007 000A0EFF 00000380
	v_lshrrev_b32_e32 v1, 5, v6                                // 000000D45298: 32020C85
	v_and_b32_e32 v6, 0x7e0, v6                                // 000000D4529C: 360C0CFF 000007E0
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000D452A4: BF890007
	s_barrier                                                  // 000000D452A8: BFBD0000
	buffer_gl0_inv                                             // 000000D452AC: E0AC0000 00000000
	v_subrev_nc_u32_e32 v1, 32, v1                             // 000000D452B4: 4E0202A0
	v_sub_nc_u32_e32 v5, v6, v5                                // 000000D452B8: 4C0A0B06
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D452BC: BF870112
	v_cndmask_b32_e32 v1, 31, v1, vcc_lo                       // 000000D452C0: 0202029F
	v_add_nc_u32_e32 v33, 0xfffffc30, v5                       // 000000D452C4: 4A420AFF FFFFFC30
	.long 0xd44c0001                                           // 000000D452CC: D44C0001
	v_cndmask_b32_e32 v1, 16, v28, vcc_lo                      // 000000D452D0: 02023890
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000D452D4: BF8700C3
	v_cmp_gt_i32_e32 vcc_lo, 31, v1                            // 000000D452D8: 7C88029F
	.long 0xd73c0005                                           // 000000D452DC: D73C0005
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000D452E0: 02020282
	v_cndmask_b32_e64 v14, 0xffffffe1, 1, vcc_lo               // 000000D452E4: D501000E 01A902FF FFFFFFE1
	.long 0xd7006a08                                           // 000000D452F0: D7006A08
	v_cndmask_b32_e32 v1, v3, v8, vcc_lo                       // 000000D452F4: 02021103
	v_add_co_ci_u32_e64 v4, null, 0, v4, vcc_lo                // 000000D452F8: D5207C04 01AA0880
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D45300: BF870193
	v_add_nc_u32_e32 v3, v14, v1                               // 000000D45304: 4A06030E
	.long 0xd7006a08                                           // 000000D45308: D7006A08
	v_cndmask_b32_e32 v1, s10, v8, vcc_lo                      // 000000D4530C: 0202100A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D45310: BF870191
	v_add_co_ci_u32_e64 v15, null, s11, v4, vcc_lo             // 000000D45314: D5207C0F 01AA080B
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000D4531C: 3408069F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D45320: BF870093
	.long 0xd7006a0e                                           // 000000D45324: D7006A0E
	v_cndmask_b32_e32 v1, 0x100, v8, vcc_lo                    // 000000D45328: 020210FF 00000100
	v_add_co_ci_u32_e64 v15, null, 0, v15, vcc_lo              // 000000D45330: D5207C0F 01AA1E80
	.long 0xd7006a01                                           // 000000D45338: D7006A01
	v_cndmask_b32_e32 v1, v7, v5, vcc_lo                       // 000000D4533C: 02020B07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D45340: BF8701A1
	v_add_co_ci_u32_e64 v5, null, v9, v6, vcc_lo               // 000000D45344: D5207C05 01AA0D09
	.long 0xd73c0003                                           // 000000D4534C: D73C0003
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 000000D45350: 02020682
	.long 0xd7006a01                                           // 000000D45354: D7006A01
	v_cndmask_b32_e32 v1, s8, v1, vcc_lo                       // 000000D45358: 02020208
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000D4535C: BF8700C1
	v_add_co_ci_u32_e64 v34, null, s9, v5, vcc_lo              // 000000D45360: D5207C22 01AA0A09
	v_lshl_or_b32 v5, v28, 2, v7                               // 000000D45368: D6560005 041D051C
	v_mov_b32_e32 v6, s3                                       // 000000D45370: 7E0C0203
	.long 0xd7006a03                                           // 000000D45374: D7006A03
	v_cndmask_b32_e32 v1, v7, v3, vcc_lo                       // 000000D45378: 02020707
	v_add_co_ci_u32_e64 v4, null, v9, v4, vcc_lo               // 000000D4537C: D5207C04 01AA0909
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D45384: BF870094
	.long 0xd7006a23                                           // 000000D45388: D7006A23
	v_cndmask_b32_e32 v1, s8, v5, vcc_lo                       // 000000D4538C: 02020A08
	v_add_co_ci_u32_e64 v36, null, s9, v6, vcc_lo              // 000000D45390: D5207C24 01AA0C09
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D45398: BF870094
	.long 0xd7006a25                                           // 000000D4539C: D7006A25
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 000000D453A0: 02020608
	v_add_co_ci_u32_e64 v38, null, s9, v4, vcc_lo              // 000000D453A4: D5207C26 01AA0809
	v_mov_b32_e32 v3, v2                                       // 000000D453AC: 7E060302
	v_mov_b32_e32 v4, v2                                       // 000000D453B0: 7E080302
	v_mul_u32_u24_e32 v32, 0x110, v31                          // 000000D453B4: 16403EFF 00000110
	v_mov_b32_e32 v5, v2                                       // 000000D453BC: 7E0A0302
	v_mov_b32_e32 v6, v2                                       // 000000D453C0: 7E0C0302
	v_mov_b32_e32 v7, v2                                       // 000000D453C4: 7E0E0302
	v_mov_b32_e32 v8, v2                                       // 000000D453C8: 7E100302
	v_mov_b32_e32 v9, v2                                       // 000000D453CC: 7E120302
	s_mov_b64 s[2:3], 0                                        // 000000D453D0: BE820180
	s_movk_i32 s8, 0x83                                        // 000000D453D4: B0080083
	s_movk_i32 s9, 0x1eee                                      // 000000D453D8: B0091EEE
	s_mov_b32 s10, 0x76543210                                  // 000000D453DC: BE8A00FF 76543210
	s_branch 17                                                // 000000D453E4: BFA00011 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x922c>
	s_or_b32 exec_lo, exec_lo, s11                             // 000000D453E8: 8C7E0B7E
	.long 0xd7006a0e                                           // 000000D453EC: D7006A0E
	v_cndmask_b32_e32 v1, 0x100, v14, vcc_lo                   // 000000D453F0: 02021CFF 00000100
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D453F8: BF870001
	v_add_co_ci_u32_e64 v15, null, 0, v15, vcc_lo              // 000000D453FC: D5207C0F 01AA1E80
	s_add_u32 s2, s2, 0x2000                                   // 000000D45404: 8002FF02 00002000
	s_addc_u32 s3, s3, 0                                       // 000000D4540C: 82038003
	s_add_i32 s4, s4, 1                                        // 000000D45410: 81048104
	s_cmpk_eq_u32 s2, 0xa000                                   // 000000D45414: B482A000
	s_waitcnt lgkmcnt(0)                                       // 000000D45418: BF89FC07
	s_barrier                                                  // 000000D4541C: BFBD0000
	buffer_gl0_inv                                             // 000000D45420: E0AC0000 00000000
	s_cbranch_scc1 1281                                        // 000000D45428: BFA20501 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0xa630>
	s_cmpk_eq_u32 s2, 0x8000                                   // 000000D4542C: B4828000
	s_cselect_b32 s11, -1, 0                                   // 000000D45430: 980B80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000D45434: BF870009
	s_and_b32 vcc_lo, exec_lo, s11                             // 000000D45438: 8B6A0B7E
	s_cbranch_vccnz 2                                          // 000000D4543C: BFA40002 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x9248>
	global_load_b128 v[10:13], v[14:15], off                   // 000000D45440: DC5E0000 0A7C000E
	.long 0xd7006a14                                           // 000000D45448: D7006A14
	v_cndmask_b32_e32 v0, v1, v2, vcc_lo                       // 000000D4544C: 02000501
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D45450: BF8700A1
	v_add_co_ci_u32_e64 v21, null, s3, v34, vcc_lo             // 000000D45454: D5207C15 01AA4403
	.long 0xd7006a18                                           // 000000D4545C: D7006A18
	v_cndmask_b32_e32 v0, v37, v2, vcc_lo                      // 000000D45460: 02000525
	v_add_co_ci_u32_e64 v25, null, s3, v38, vcc_lo             // 000000D45464: D5207C19 01AA4C03
	.long 0xd7006a1a                                           // 000000D4546C: D7006A1A
	v_cndmask_b32_e32 v0, v35, v2, vcc_lo                      // 000000D45470: 02000523
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D45474: BF870001
	v_add_co_ci_u32_e64 v27, null, s3, v36, vcc_lo             // 000000D45478: D5207C1B 01AA4803
	s_clause 0xb                                               // 000000D45480: BF85000B
	global_load_b32 v17, v[20:21], off                         // 000000D45484: DC520000 117C0014
	global_load_b32 v16, v[24:25], off                         // 000000D4548C: DC520000 107C0018
	global_load_b32 v40, v[26:27], off                         // 000000D45494: DC520000 287C001A
	global_load_b32 v19, v[20:21], off offset:1024             // 000000D4549C: DC520400 137C0014
	global_load_b32 v18, v[24:25], off offset:1024             // 000000D454A4: DC520400 127C0018
	global_load_b32 v41, v[26:27], off offset:1024             // 000000D454AC: DC520400 297C001A
	global_load_b32 v23, v[20:21], off offset:2048             // 000000D454B4: DC520800 177C0014
	global_load_b32 v22, v[24:25], off offset:2048             // 000000D454BC: DC520800 167C0018
	global_load_b32 v42, v[26:27], off offset:2048             // 000000D454C4: DC520800 2A7C001A
	global_load_b32 v76, v[24:25], off offset:3072             // 000000D454CC: DC520C00 4C7C0018
	global_load_b32 v77, v[20:21], off offset:3072             // 000000D454D4: DC520C00 4D7C0014
	global_load_b32 v80, v[26:27], off offset:3072             // 000000D454DC: DC520C00 507C001A
	.long 0xd7006a2b                                           // 000000D454E4: D7006A2B
	v_cndmask_b32_e32 v1, 0x1000, v20, vcc_lo                  // 000000D454E8: 020228FF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D454F0: BF8700A1
	v_add_co_ci_u32_e64 v44, null, 0, v21, vcc_lo              // 000000D454F4: D5207C2C 01AA2A80
	.long 0xd7006a2d                                           // 000000D454FC: D7006A2D
	v_cndmask_b32_e32 v1, 0x1000, v24, vcc_lo                  // 000000D45500: 020230FF 00001000
	v_add_co_ci_u32_e64 v46, null, 0, v25, vcc_lo              // 000000D45508: D5207C2E 01AA3280
	.long 0xd7006a2f                                           // 000000D45510: D7006A2F
	v_cndmask_b32_e32 v1, 0x1000, v26, vcc_lo                  // 000000D45514: 020234FF 00001000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D4551C: BF870001
	v_add_co_ci_u32_e64 v48, null, 0, v27, vcc_lo              // 000000D45520: D5207C30 01AA3680
	s_clause 0xb                                               // 000000D45528: BF85000B
	global_load_b32 v79, v[43:44], off                         // 000000D4552C: DC520000 4F7C002B
	global_load_b32 v78, v[45:46], off                         // 000000D45534: DC520000 4E7C002D
	global_load_b32 v81, v[47:48], off                         // 000000D4553C: DC520000 517C002F
	global_load_b32 v21, v[43:44], off offset:1024             // 000000D45544: DC520400 157C002B
	global_load_b32 v25, v[43:44], off offset:2048             // 000000D4554C: DC520800 197C002B
	global_load_b32 v27, v[43:44], off offset:3072             // 000000D45554: DC520C00 1B7C002B
	global_load_b32 v20, v[45:46], off offset:1024             // 000000D4555C: DC520400 147C002D
	global_load_b32 v108, v[47:48], off offset:1024            // 000000D45564: DC520400 6C7C002F
	global_load_b32 v24, v[45:46], off offset:2048             // 000000D4556C: DC520800 187C002D
	global_load_b32 v109, v[47:48], off offset:2048            // 000000D45574: DC520800 6D7C002F
	global_load_b32 v43, v[47:48], off offset:3072             // 000000D4557C: DC520C00 2B7C002F
	global_load_b32 v26, v[45:46], off offset:3072             // 000000D45584: DC520C00 1A7C002D
	s_and_b32 s12, s4, 1                                       // 000000D4558C: 8B0C8104
	s_bfe_i32 s13, s4, 0x10000                                 // 000000D45590: 938DFF04 00010000
	s_cmp_eq_u32 s12, 0                                        // 000000D45598: BF06800C
	s_cselect_b32 s12, -1, 0                                   // 000000D4559C: 980C80C1
	s_and_b32 s13, s13, 0x4400                                 // 000000D455A0: 8B0DFF0D 00004400
	s_waitcnt vmcnt(22)                                        // 000000D455A8: BF895BF7
	.long 0xd73d0010                                           // 000000D455AC: D73D0010
	v_cndmask_b32_e32 v1, v33, v16, vcc_lo                     // 000000D455B0: 02022121
	s_waitcnt vmcnt(21)                                        // 000000D455B4: BF8957F7
	v_bfe_u32 v82, v40, 12, 16                                 // 000000D455B8: D6100052 02411928
	v_bfe_u32 v84, v40, 4, 16                                  // 000000D455C0: D6100054 02410928
	v_mul_u32_u24_e32 v90, s5, v82                             // 000000D455C8: 16B4A405
	s_waitcnt vmcnt(18)                                        // 000000D455CC: BF894BF7
	v_bfe_u32 v85, v41, 12, 16                                 // 000000D455D0: D6100055 02411929
	v_mul_u32_u24_e32 v82, s8, v82                             // 000000D455D8: 16A4A408
	v_mul_u32_u24_e32 v92, s5, v84                             // 000000D455DC: 16B8A805
	v_mul_u32_u24_e32 v84, s8, v84                             // 000000D455E0: 16A8A808
	v_mul_u32_u24_e32 v95, s5, v85                             // 000000D455E4: 16BEAA05
	v_mul_u32_u24_e32 v85, s8, v85                             // 000000D455E8: 16AAAA08
	v_lshl_add_u32 v82, v82, 24, v90                           // 000000D455EC: D6460052 05693152
	v_lshl_add_u32 v84, v84, 24, v92                           // 000000D455F4: D6460054 05713154
	v_lshl_add_u32 v85, v85, 24, v95                           // 000000D455FC: D6460055 057D3155
	v_bfe_u32 v83, v40, 8, 16                                  // 000000D45604: D6100053 02411128
	v_bfe_u32 v86, v41, 8, 16                                  // 000000D4560C: D6100056 02411129
	v_mul_u32_u24_e32 v91, s5, v83                             // 000000D45614: 16B6A605
	v_mul_u32_u24_e32 v83, s8, v83                             // 000000D45618: 16A6A608
	v_mul_u32_u24_e32 v96, s5, v86                             // 000000D4561C: 16C0AC05
	v_mul_u32_u24_e32 v86, s8, v86                             // 000000D45620: 16ACAC08
	v_and_b32_e32 v40, 0xffff, v40                             // 000000D45624: 365050FF 0000FFFF
	v_mul_u32_u24_e32 v93, s5, v40                             // 000000D4562C: 16BA5005
	v_mul_u32_u24_e32 v94, s8, v40                             // 000000D45630: 16BC5008
	v_lshl_add_u32 v83, v83, 24, v91                           // 000000D45634: D6460053 056D3153
	v_lshl_add_u32 v90, v94, 24, v93                           // 000000D4563C: D646005A 0575315E
	v_lshl_add_u32 v86, v86, 24, v96                           // 000000D45644: D6460056 05813156
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000D4564C: D6220052 03FD0152 00006400
	v_sad_u8 v84, v84, 0, 0x6400                               // 000000D45658: D6220054 03FD0154 00006400
	v_sad_u8 v85, v85, 0, 0x6400                               // 000000D45664: D6220055 03FD0155 00006400
	v_sad_u8 v83, v83, 0, 0x6400                               // 000000D45670: D6220053 03FD0153 00006400
	v_sad_u8 v90, v90, 0, 0x6400                               // 000000D4567C: D622005A 03FD015A 00006400
	v_sad_u8 v86, v86, 0, 0x6400                               // 000000D45688: D6220056 03FD0156 00006400
	v_and_b32_e32 v82, 0xffff, v82                             // 000000D45694: 36A4A4FF 0000FFFF
	v_and_b32_e32 v84, 0xffff, v84                             // 000000D4569C: 36A8A8FF 0000FFFF
	v_and_b32_e32 v85, 0xffff, v85                             // 000000D456A4: 36AAAAFF 0000FFFF
	v_bfe_u32 v87, v41, 4, 16                                  // 000000D456AC: D6100057 02410929
	v_mul_u32_u24_e32 v97, s5, v87                             // 000000D456B4: 16C2AE05
	v_mul_u32_u24_e32 v87, s8, v87                             // 000000D456B8: 16AEAE08
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D456BC: BF870001
	v_lshl_add_u32 v87, v87, 24, v97                           // 000000D456C0: D6460057 05853157
	v_lshl_or_b32 v82, v83, 16, v82                            // 000000D456C8: D6560052 05492153
	v_lshl_or_b32 v83, v90, 16, v84                            // 000000D456D0: D6560053 0551215A
	v_lshl_or_b32 v84, v86, 16, v85                            // 000000D456D8: D6560054 05552156
	s_waitcnt vmcnt(15)                                        // 000000D456E0: BF893FF7
	v_bfe_u32 v89, v42, 4, 16                                  // 000000D456E4: D6100059 0241092A
	v_sad_u8 v87, v87, 0, 0x6400                               // 000000D456EC: D6220057 03FD0157 00006400
	v_mul_u32_u24_e32 v102, s5, v89                            // 000000D456F8: 16CCB205
	v_mul_u32_u24_e32 v89, s8, v89                             // 000000D456FC: 16B2B208
	v_pk_fma_f16 v84, v84, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000D45700: CC0E0054 0BFC1354 0000C931
	v_and_b32_e32 v41, 0xffff, v41                             // 000000D4570C: 365252FF 0000FFFF
	v_mul_u32_u24_e32 v98, s5, v41                             // 000000D45714: 16C45205
	v_mul_u32_u24_e32 v99, s8, v41                             // 000000D45718: 16C65208
	v_lshl_add_u32 v94, v99, 24, v98                           // 000000D4571C: D646005E 05893163
	v_and_b32_e32 v87, 0xffff, v87                             // 000000D45724: 36AEAEFF 0000FFFF
	v_lshl_add_u32 v89, v89, 24, v102                          // 000000D4572C: D6460059 05993159
	.long 0xd73d0011                                           // 000000D45734: D73D0011
	v_cndmask_b32_e32 v1, v33, v18, vcc_lo                     // 000000D45738: 02022521
	.long 0xd73d0012                                           // 000000D4573C: D73D0012
	v_cndmask_b32_e32 v1, v33, v22, vcc_lo                     // 000000D45740: 02022D21
	v_sad_u8 v94, v94, 0, 0x6400                               // 000000D45744: D622005E 03FD015E 00006400
	v_bfe_u32 v19, v42, 12, 16                                 // 000000D45750: D6100013 0241192A
	v_bfe_u32 v88, v42, 8, 16                                  // 000000D45758: D6100058 0241112A
	v_sad_u8 v89, v89, 0, 0x6400                               // 000000D45760: D6220059 03FD0159 00006400
	v_mul_u32_u24_e32 v100, s5, v19                            // 000000D4576C: 16C82605
	v_lshl_or_b32 v85, v94, 16, v87                            // 000000D45770: D6560055 055D215E
	v_mul_u32_u24_e32 v19, s8, v19                             // 000000D45778: 16262608
	s_waitcnt vmcnt(13)                                        // 000000D4577C: BF8937F7
	.long 0xd73d0016                                           // 000000D45780: D73D0016
	v_cndmask_b32_e32 v1, v33, v76, vcc_lo                     // 000000D45784: 02029921
	v_and_b32_e32 v89, 0xffff, v89                             // 000000D45788: 36B2B2FF 0000FFFF
	v_lshl_add_u32 v19, v19, 24, v100                          // 000000D45790: D6460013 05913113
	v_pk_fma_f16 v85, v85, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000D45798: CC0E0055 0BFC1355 0000C931
	v_and_b32_e32 v42, 0xffff, v42                             // 000000D457A4: 365454FF 0000FFFF
	v_mul_u32_u24_e32 v103, s5, v42                            // 000000D457AC: 16CE5405
	v_mul_u32_u24_e32 v42, s8, v42                             // 000000D457B0: 16545408
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D457B4: BF870001
	v_lshl_add_u32 v42, v42, 24, v103                          // 000000D457B8: D646002A 059D312A
	s_waitcnt vmcnt(12)                                        // 000000D457C0: BF8933F7
	v_bfe_u32 v23, v80, 12, 16                                 // 000000D457C4: D6100017 02411950
	v_bfe_u32 v77, v80, 4, 16                                  // 000000D457CC: D610004D 02410950
	v_mul_u32_u24_e32 v104, s5, v23                            // 000000D457D4: 16D02E05
	v_mul_u32_u24_e32 v23, s8, v23                             // 000000D457D8: 162E2E08
	v_sad_u8 v42, v42, 0, 0x6400                               // 000000D457DC: D622002A 03FD012A 00006400
	v_mul_u32_u24_e32 v106, s5, v77                            // 000000D457E8: 16D49A05
	v_mul_u32_u24_e32 v77, s8, v77                             // 000000D457EC: 169A9A08
	v_lshl_add_u32 v23, v23, 24, v104                          // 000000D457F0: D6460017 05A13117
	v_lshl_add_u32 v77, v77, 24, v106                          // 000000D457F8: D646004D 05A9314D
	v_lshl_or_b32 v42, v42, 16, v89                            // 000000D45800: D656002A 0565212A
	v_mul_u32_u24_e32 v101, s5, v88                            // 000000D45808: 16CAB005
	v_mul_u32_u24_e32 v88, s8, v88                             // 000000D4580C: 16B0B008
	v_lshl_add_u32 v88, v88, 24, v101                          // 000000D45810: D6460058 05953158
	v_sad_u8 v19, v19, 0, 0x6400                               // 000000D45818: D6220013 03FD0113 00006400
	v_bfe_u32 v76, v80, 8, 16                                  // 000000D45824: D610004C 02411150
	v_pk_fma_f16 v42, v42, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000D4582C: CC0E002A 0BFC132A 0000C931
	v_and_b32_e32 v80, 0xffff, v80                             // 000000D45838: 36A0A0FF 0000FFFF
	v_mul_u32_u24_e32 v105, s5, v76                            // 000000D45840: 16D29805
	v_mul_u32_u24_e32 v76, s8, v76                             // 000000D45844: 16989808
	v_mul_u32_u24_e32 v107, s5, v80                            // 000000D45848: 16D6A005
	v_mul_u32_u24_e32 v80, s8, v80                             // 000000D4584C: 16A0A008
	v_lshl_add_u32 v76, v76, 24, v105                          // 000000D45850: D646004C 05A5314C
	v_lshl_add_u32 v80, v80, 24, v107                          // 000000D45858: D6460050 05AD3150
	v_sad_u8 v23, v23, 0, 0x6400                               // 000000D45860: D6220017 03FD0117 00006400
	v_sad_u8 v77, v77, 0, 0x6400                               // 000000D4586C: D622004D 03FD014D 00006400
	v_sad_u8 v88, v88, 0, 0x6400                               // 000000D45878: D6220058 03FD0158 00006400
	v_and_b32_e32 v19, 0xffff, v19                             // 000000D45884: 362626FF 0000FFFF
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000D4588C: D622004C 03FD014C 00006400
	v_sad_u8 v80, v80, 0, 0x6400                               // 000000D45898: D6220050 03FD0150 00006400
	v_and_b32_e32 v23, 0xffff, v23                             // 000000D458A4: 362E2EFF 0000FFFF
	v_and_b32_e32 v77, 0xffff, v77                             // 000000D458AC: 369A9AFF 0000FFFF
	v_lshl_or_b32 v19, v88, 16, v19                            // 000000D458B4: D6560013 044D2158
	s_waitcnt vmcnt(10)                                        // 000000D458BC: BF892BF7
	.long 0xd73d0028                                           // 000000D458C0: D73D0028
	v_cndmask_b32_e32 v1, v33, v78, vcc_lo                     // 000000D458C4: 02029D21
	s_waitcnt vmcnt(9)                                         // 000000D458C8: BF8927F7
	v_bfe_u32 v41, v81, 12, 16                                 // 000000D458CC: D6100029 02411951
	v_lshl_or_b32 v23, v76, 16, v23                            // 000000D458D4: D6560017 045D214C
	v_lshl_or_b32 v76, v80, 16, v77                            // 000000D458DC: D656004C 05352150
	v_bfe_u32 v78, v81, 8, 16                                  // 000000D458E4: D610004E 02411151
	v_bfe_u32 v79, v81, 4, 16                                  // 000000D458EC: D610004F 02410951
	v_bfe_u32 v95, v18, 12, 16                                 // 000000D458F4: D610005F 02411912
	v_pk_fma_f16 v19, v19, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000D458FC: CC0E0013 0BFC1313 0000C931
	v_and_b32_e32 v81, 0xffff, v81                             // 000000D45908: 36A2A2FF 0000FFFF
	v_bfe_u32 v110, v16, 12, 16                                // 000000D45910: D610006E 02411910
	v_bfe_u32 v111, v16, 8, 16                                 // 000000D45918: D610006F 02411110
	v_mul_u32_u24_e32 v101, s5, v41                            // 000000D45920: 16CA5205
	v_mul_u32_u24_e32 v41, s8, v41                             // 000000D45924: 16525208
	v_mul_u32_u24_e32 v102, s5, v78                            // 000000D45928: 16CC9C05
	v_mul_u32_u24_e32 v78, s8, v78                             // 000000D4592C: 169C9C08
	v_mul_u32_u24_e32 v104, s5, v81                            // 000000D45930: 16D0A205
	v_mul_u32_u24_e32 v81, s8, v81                             // 000000D45934: 16A2A208
	v_mul_u32_u24_e32 v105, s5, v110                           // 000000D45938: 16D2DC05
	v_mul_u32_u24_e32 v107, s5, v111                           // 000000D4593C: 16D6DE05
	v_mul_u32_u24_e32 v118, s5, v95                            // 000000D45940: 16ECBE05
	v_mul_u32_u24_e32 v95, s8, v95                             // 000000D45944: 16BEBE08
	v_bfe_u32 v93, v17, 4, 16                                  // 000000D45948: D610005D 02410911
	v_mul_u32_u24_e32 v106, s8, v110                           // 000000D45950: 16D4DC08
	v_mul_u32_u24_e32 v110, s8, v111                           // 000000D45954: 16DCDE08
	v_bfe_u32 v126, v40, 12, 16                                // 000000D45958: D610007E 02411928
	v_bfe_u32 v127, v40, 8, 16                                 // 000000D45960: D610007F 02411128
	v_lshl_add_u32 v41, v41, 24, v101                          // 000000D45968: D6460029 05953129
	v_lshl_add_u32 v78, v78, 24, v102                          // 000000D45970: D646004E 0599314E
	v_lshl_add_u32 v81, v81, 24, v104                          // 000000D45978: D6460051 05A13151
	v_lshl_add_u32 v101, v106, 24, v105                        // 000000D45980: D6460065 05A5316A
	v_lshl_add_u32 v102, v110, 24, v107                        // 000000D45988: D6460066 05AD316E
	v_lshl_add_u32 v95, v95, 24, v118                          // 000000D45990: D646005F 05D9315F
	v_mul_u32_u24_e32 v104, s5, v126                           // 000000D45998: 16D0FC05
	v_mul_u32_u24_e32 v105, s8, v126                           // 000000D4599C: 16D2FC08
	v_mul_u32_u24_e32 v107, s8, v127                           // 000000D459A0: 16D6FE08
	v_bfe_u32 v112, v16, 4, 16                                 // 000000D459A4: D6100070 02410910
	v_mul_u32_u24_e32 v103, s5, v79                            // 000000D459AC: 16CE9E05
	v_mul_u32_u24_e32 v79, s8, v79                             // 000000D459B0: 169E9E08
	v_mul_u32_u24_e32 v116, s5, v93                            // 000000D459B4: 16E8BA05
	v_mul_u32_u24_e32 v93, s8, v93                             // 000000D459B8: 16BABA08
	v_mul_u32_u24_e32 v106, s5, v127                           // 000000D459BC: 16D4FE05
	v_lshl_add_u32 v104, v105, 24, v104                        // 000000D459C0: D6460068 05A13169
	v_lshl_add_u32 v105, v107, 24, v106                        // 000000D459C8: D6460069 05A9316B
	v_pk_fma_f16 v107, v76, s9, 0xc931 op_sel_hi:[1,0,0]       // 000000D459D0: CC0E006B 0BFC134C 0000C931
	v_mul_u32_u24_e32 v111, s5, v112                           // 000000D459DC: 16DEE005
	v_mul_u32_u24_e32 v112, s8, v112                           // 000000D459E0: 16E0E008
	v_lshl_add_u32 v79, v79, 24, v103                          // 000000D459E4: D646004F 059D314F
	v_lshl_add_u32 v103, v112, 24, v111                        // 000000D459EC: D6460067 05BD3170
	v_lshl_add_u32 v93, v93, 24, v116                          // 000000D459F4: D646005D 05D1315D
	v_bfe_u32 v96, v18, 8, 16                                  // 000000D459FC: D6100060 02411112
	v_mul_u32_u24_e32 v119, s5, v96                            // 000000D45A04: 16EEC005
	v_mul_u32_u24_e32 v96, s8, v96                             // 000000D45A08: 16C0C008
	v_and_b32_e32 v16, 0xffff, v16                             // 000000D45A0C: 362020FF 0000FFFF
	v_bfe_u32 v128, v40, 4, 16                                 // 000000D45A14: D6100080 02410928
	v_lshl_add_u32 v96, v96, 24, v119                          // 000000D45A1C: D6460060 05DD3160
	v_mul_u32_u24_e32 v111, s8, v128                           // 000000D45A24: 16DF0008
	v_sad_u8 v41, v41, 0, 0x6400                               // 000000D45A28: D6220029 03FD0129 00006400
	v_sad_u8 v95, v95, 0, 0x6400                               // 000000D45A34: D622005F 03FD015F 00006400
	v_mul_u32_u24_e32 v110, s5, v128                           // 000000D45A40: 16DD0005
	v_lshl_add_u32 v106, v111, 24, v110                        // 000000D45A44: D646006A 05B9316F
	v_mov_b32_e32 v111, v107                                   // 000000D45A4C: 7EDE036B
	v_mul_u32_u24_e32 v113, s5, v16                            // 000000D45A50: 16E22005
	v_mul_u32_u24_e32 v16, s8, v16                             // 000000D45A54: 16202008
	v_lshl_add_u32 v16, v16, 24, v113                          // 000000D45A58: D6460010 05C53110
	v_sad_u8 v103, v103, 0, 0x6400                             // 000000D45A60: D6220067 03FD0167 00006400
	v_sad_u8 v93, v93, 0, 0x6400                               // 000000D45A6C: D622005D 03FD015D 00006400
	v_bfe_u32 v98, v22, 12, 16                                 // 000000D45A78: D6100062 02411916
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000D45A80: D622004E 03FD014E 00006400
	v_sad_u8 v96, v96, 0, 0x6400                               // 000000D45A8C: D6220060 03FD0160 00006400
	v_and_b32_e32 v41, 0xffff, v41                             // 000000D45A98: 365252FF 0000FFFF
	v_and_b32_e32 v88, 0xffff, v95                             // 000000D45AA0: 36B0BEFF 0000FFFF
	v_pk_fma_f16 v23, v23, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000D45AA8: CC0E0017 0BFC1317 0000C931
	v_mul_u32_u24_e32 v122, s5, v98                            // 000000D45AB4: 16F4C405
	v_mul_u32_u24_e32 v98, s8, v98                             // 000000D45AB8: 16C4C408
	v_lshl_add_u32 v98, v98, 24, v122                          // 000000D45ABC: D6460062 05E93162
	v_sad_u8 v16, v16, 0, 0x6400                               // 000000D45AC4: D6220010 03FD0110 00006400
	v_and_b32_e32 v80, 0xffff, v103                            // 000000D45AD0: 36A0CEFF 0000FFFF
	v_and_b32_e32 v87, 0xffff, v93                             // 000000D45AD8: 36AEBAFF 0000FFFF
	v_sad_u8 v93, v104, 0, 0x6400                              // 000000D45AE0: D622005D 03FD0168 00006400
	v_bfe_u32 v91, v17, 12, 16                                 // 000000D45AEC: D610005B 02411911
	v_bfe_u32 v92, v17, 8, 16                                  // 000000D45AF4: D610005C 02411111
	v_and_b32_e32 v17, 0xffff, v17                             // 000000D45AFC: 362222FF 0000FFFF
	v_bfe_u32 v99, v22, 8, 16                                  // 000000D45B04: D6100063 02411116
	v_lshl_or_b32 v41, v78, 16, v41                            // 000000D45B0C: D6560029 04A5214E
	v_lshl_or_b32 v78, v96, 16, v88                            // 000000D45B14: D656004E 05612160
	v_mov_b32_e32 v96, v23                                     // 000000D45B1C: 7EC00317
	v_mul_u32_u24_e32 v117, s5, v17                            // 000000D45B20: 16EA2205
	v_mul_u32_u24_e32 v17, s8, v17                             // 000000D45B24: 16222208
	v_mul_u32_u24_e32 v114, s5, v91                            // 000000D45B28: 16E4B605
	v_mul_u32_u24_e32 v91, s8, v91                             // 000000D45B2C: 16B6B608
	v_mul_u32_u24_e32 v123, s5, v99                            // 000000D45B30: 16F6C605
	v_mul_u32_u24_e32 v99, s8, v99                             // 000000D45B34: 16C6C608
	v_lshl_add_u32 v17, v17, 24, v117                          // 000000D45B38: D6460011 05D53111
	v_lshl_add_u32 v91, v91, 24, v114                          // 000000D45B40: D646005B 05C9315B
	v_lshl_add_u32 v99, v99, 24, v123                          // 000000D45B48: D6460063 05ED3163
	v_sad_u8 v79, v79, 0, 0x6400                               // 000000D45B50: D622004F 03FD014F 00006400
	v_sad_u8 v101, v101, 0, 0x6400                             // 000000D45B5C: D6220065 03FD0165 00006400
	v_sad_u8 v98, v98, 0, 0x6400                               // 000000D45B68: D6220062 03FD0162 00006400
	v_lshl_or_b32 v16, v16, 16, v80                            // 000000D45B74: D6560010 05412110
	v_dual_mov_b32 v93, v42 :: v_dual_and_b32 v80, 0xffff, v93 // 000000D45B7C: CA24012A 5D50BAFF 0000FFFF
	v_bfe_u32 v97, v18, 4, 16                                  // 000000D45B88: D6100061 02410912
	v_mul_u32_u24_e32 v115, s5, v92                            // 000000D45B90: 16E6B805
	v_mul_u32_u24_e32 v92, s8, v92                             // 000000D45B94: 16B8B808
	v_mul_u32_u24_e32 v120, s5, v97                            // 000000D45B98: 16F0C205
	v_mul_u32_u24_e32 v97, s8, v97                             // 000000D45B9C: 16C2C208
	v_sad_u8 v17, v17, 0, 0x6400                               // 000000D45BA0: D6220011 03FD0111 00006400
	v_lshl_add_u32 v92, v92, 24, v115                          // 000000D45BAC: D646005C 05CD315C
	v_lshl_add_u32 v97, v97, 24, v120                          // 000000D45BB4: D6460061 05E13161
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000D45BBC: D6220051 03FD0151 00006400
	v_sad_u8 v102, v102, 0, 0x6400                             // 000000D45BC8: D6220066 03FD0166 00006400
	v_sad_u8 v91, v91, 0, 0x6400                               // 000000D45BD4: D622005B 03FD015B 00006400
	v_sad_u8 v99, v99, 0, 0x6400                               // 000000D45BE0: D6220063 03FD0163 00006400
	v_and_b32_e32 v77, 0xffff, v79                             // 000000D45BEC: 369A9EFF 0000FFFF
	v_and_b32_e32 v79, 0xffff, v101                            // 000000D45BF4: 369ECAFF 0000FFFF
	v_and_b32_e32 v90, 0xffff, v98                             // 000000D45BFC: 36B4C4FF 0000FFFF
	v_sad_u8 v95, v106, 0, 0x6400                              // 000000D45C04: D622005F 03FD016A 00006400
	v_permlanex16_b32 v93, v93, s10, 0xfedcba98                // 000000D45C10: D65C005D 03FC155D FEDCBA98
	v_bfe_u32 v100, v22, 4, 16                                 // 000000D45C1C: D6100064 02410916
	v_mul_u32_u24_e32 v124, s5, v100                           // 000000D45C24: 16F8C805
	v_mul_u32_u24_e32 v100, s8, v100                           // 000000D45C28: 16C8C808
	v_lshl_or_b32 v17, v17, 16, v87                            // 000000D45C2C: D6560011 055D2111
	s_delay_alu instid0(VALU_DEP_2)                            // 000000D45C34: BF870002
	v_lshl_add_u32 v100, v100, 24, v124                        // 000000D45C38: D6460064 05F13164
	v_sad_u8 v92, v92, 0, 0x6400                               // 000000D45C40: D622005C 03FD015C 00006400
	v_sad_u8 v97, v97, 0, 0x6400                               // 000000D45C4C: D6220061 03FD0161 00006400
	v_lshl_or_b32 v110, v81, 16, v77                           // 000000D45C58: D656006E 05352151
	v_lshl_or_b32 v76, v102, 16, v79                           // 000000D45C60: D656004C 053D2166
	v_lshl_or_b32 v79, v99, 16, v90                            // 000000D45C68: D656004F 05692163
	v_and_b32_e32 v81, 0xffff, v95                             // 000000D45C70: 36A2BEFF 0000FFFF
	v_cndmask_b32_e64 v95, v93, v42, s1                        // 000000D45C78: D501005F 0006555D
	v_cndmask_b32_e64 v99, v42, v93, s1                        // 000000D45C80: D5010063 0006BB2A
	v_pk_fma_f16 v42, v41, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000D45C88: CC0E002A 0BFC1329 0000C931
	v_and_b32_e32 v86, 0xffff, v91                             // 000000D45C94: 36ACB6FF 0000FFFF
	v_pk_fma_f16 v17, v17, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000D45C9C: CC0E0011 0BFC1311 0000C931
	v_sad_u8 v100, v100, 0, 0x6400                             // 000000D45CA8: D6220064 03FD0164 00006400
	v_and_b32_e32 v89, 0xffff, v97                             // 000000D45CB4: 36B2C2FF 0000FFFF
	v_pk_fma_f16 v97, v76, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000D45CBC: CC0E0061 0BFC134C 0000C931
	v_lshl_or_b32 v77, v92, 16, v86                            // 000000D45CC8: D656004D 0559215C
	v_and_b32_e32 v40, 0xffff, v40                             // 000000D45CD0: 365050FF 0000FFFF
	v_and_b32_e32 v18, 0xffff, v18                             // 000000D45CD8: 362424FF 0000FFFF
	v_sad_u8 v94, v105, 0, 0x6400                              // 000000D45CE0: D622005E 03FD0169 00006400
	v_mov_b32_e32 v105, v17                                    // 000000D45CEC: 7ED20311
	v_mul_u32_u24_e32 v112, s5, v40                            // 000000D45CF0: 16E05005
	v_mul_u32_u24_e32 v40, s8, v40                             // 000000D45CF4: 16505008
	v_lshl_add_u32 v40, v40, 24, v112                          // 000000D45CF8: D6460028 05C13128
	v_and_b32_e32 v91, 0xffff, v100                            // 000000D45D00: 36B6C8FF 0000FFFF
	v_pk_fma_f16 v100, v77, s9, 0xc931 op_sel_hi:[1,0,0]       // 000000D45D08: CC0E0064 0BFC134D 0000C931
	v_mov_b32_e32 v77, v97                                     // 000000D45D14: 7E9A0361
	v_mul_u32_u24_e32 v121, s5, v18                            // 000000D45D18: 16F22405
	v_mul_u32_u24_e32 v18, s8, v18                             // 000000D45D1C: 16242408
	v_lshl_add_u32 v18, v18, 24, v121                          // 000000D45D20: D6460012 05E53112
	v_sad_u8 v40, v40, 0, 0x6400                               // 000000D45D28: D6220028 03FD0128 00006400
	v_pk_fma_f16 v16, v16, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000D45D34: CC0E0010 0BFC1310 0000C931
	v_pk_fma_f16 v82, v82, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000D45D40: CC0E0052 0BFC1352 0000C931
	v_pk_fma_f16 v83, v83, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000D45D4C: CC0E0053 0BFC1353 0000C931
	v_sad_u8 v18, v18, 0, 0x6400                               // 000000D45D58: D6220012 03FD0112 00006400
	v_add_nc_u32_e32 v39, s13, v32                             // 000000D45D64: 4A4E400D
	v_and_b32_e32 v22, 0xffff, v22                             // 000000D45D68: 362C2CFF 0000FFFF
	v_lshl_or_b32 v40, v40, 16, v81                            // 000000D45D70: D6560028 05452128
	v_mov_b32_e32 v81, v16                                     // 000000D45D78: 7EA20310
	v_mul_u32_u24_e32 v125, s5, v22                            // 000000D45D7C: 16FA2C05
	v_mul_u32_u24_e32 v22, s8, v22                             // 000000D45D80: 162C2C08
	v_lshl_add_u32 v22, v22, 24, v125                          // 000000D45D84: D6460016 05F53116
	v_lshl_or_b32 v18, v18, 16, v89                            // 000000D45D8C: D6560012 05652112
	v_dual_mov_b32 v86, v82 :: v_dual_mov_b32 v87, v83         // 000000D45D94: CA100152 56560153
	ds_load_b128 v[44:47], v39                                 // 000000D45D9C: DBFC0000 2C000027
	ds_load_b128 v[48:51], v39 offset:16                       // 000000D45DA4: DBFC0010 30000027
	ds_load_b128 v[52:55], v39 offset:32                       // 000000D45DAC: DBFC0020 34000027
	ds_load_b128 v[56:59], v39 offset:48                       // 000000D45DB4: DBFC0030 38000027
	ds_load_b128 v[60:63], v39 offset:64                       // 000000D45DBC: DBFC0040 3C000027
	ds_load_b128 v[64:67], v39 offset:80                       // 000000D45DC4: DBFC0050 40000027
	ds_load_b128 v[68:71], v39 offset:96                       // 000000D45DCC: DBFC0060 44000027
	ds_load_b128 v[72:75], v39 offset:112                      // 000000D45DD4: DBFC0070 48000027
	v_mov_b32_e32 v89, v85                                     // 000000D45DDC: 7EB20355
	v_sad_u8 v22, v22, 0, 0x6400                               // 000000D45DE0: D6220016 03FD0116 00006400
	v_pk_fma_f16 v18, v18, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000D45DEC: CC0E0012 0BFC1312 0000C931
	v_mov_b32_e32 v88, v84                                     // 000000D45DF8: 7EB00354
	v_permlanex16_b32 v86, v86, s10, 0xfedcba98                // 000000D45DFC: D65C0056 03FC1556 FEDCBA98
	v_permlanex16_b32 v87, v87, s10, 0xfedcba98                // 000000D45E08: D65C0057 03FC1557 FEDCBA98
	v_mov_b32_e32 v104, v100                                   // 000000D45E14: 7ED00364
	v_permlanex16_b32 v77, v77, s10, 0xfedcba98                // 000000D45E18: D65C004D 03FC154D FEDCBA98
	v_permlanex16_b32 v81, v81, s10, 0xfedcba98                // 000000D45E24: D65C0051 03FC1551 FEDCBA98
	v_permlanex16_b32 v89, v89, s10, 0xfedcba98                // 000000D45E30: D65C0059 03FC1559 FEDCBA98
	v_permlanex16_b32 v105, v105, s10, 0xfedcba98              // 000000D45E3C: D65C0069 03FC1569 FEDCBA98
	v_lshl_or_b32 v22, v22, 16, v91                            // 000000D45E48: D6560016 056D2116
	v_mov_b32_e32 v92, v19                                     // 000000D45E50: 7EB80313
	v_lshl_or_b32 v112, v94, 16, v80                           // 000000D45E54: D6560070 0541215E
	v_mov_b32_e32 v114, v18                                    // 000000D45E5C: 7EE40312
	v_pk_fma_f16 v101, v78, s9, 0xc931 op_sel_hi:[1,0,0]       // 000000D45E60: CC0E0065 0BFC134E 0000C931
	v_pk_fma_f16 v103, v79, s9, 0xc931 op_sel_hi:[1,0,0]       // 000000D45E6C: CC0E0067 0BFC134F 0000C931
	v_permlanex16_b32 v88, v88, s10, 0xfedcba98                // 000000D45E78: D65C0058 03FC1558 FEDCBA98
	v_cndmask_b32_e64 v78, v86, v82, s1                        // 000000D45E84: D501004E 0006A556
	v_cndmask_b32_e64 v82, v82, v86, s1                        // 000000D45E8C: D5010052 0006AD52
	v_cndmask_b32_e64 v79, v87, v83, s1                        // 000000D45E94: D501004F 0006A757
	v_cndmask_b32_e64 v83, v83, v87, s1                        // 000000D45E9C: D5010053 0006AF53
	v_permlanex16_b32 v104, v104, s10, 0xfedcba98              // 000000D45EA4: D65C0068 03FC1568 FEDCBA98
	v_cndmask_b32_e64 v76, v77, v97, s1                        // 000000D45EB0: D501004C 0006C34D
	v_cndmask_b32_e64 v80, v97, v77, s1                        // 000000D45EB8: D5010050 00069B61
	v_cndmask_b32_e64 v77, v81, v16, s1                        // 000000D45EC0: D501004D 00062151
	v_cndmask_b32_e64 v81, v16, v81, s1                        // 000000D45EC8: D5010051 0006A310
	v_cndmask_b32_e64 v87, v89, v85, s1                        // 000000D45ED0: D5010057 0006AB59
	v_cndmask_b32_e64 v91, v85, v89, s1                        // 000000D45ED8: D501005B 0006B355
	v_cndmask_b32_e64 v85, v105, v17, s1                       // 000000D45EE0: D5010055 00062369
	v_cndmask_b32_e64 v89, v17, v105, s1                       // 000000D45EE8: D5010059 0006D311
	v_pk_fma_f16 v17, v40, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000D45EF0: CC0E0011 0BFC1328 0000C931
	s_waitcnt vmcnt(5)                                         // 000000D45EFC: BF8917F7
	.long 0xd73d0028                                           // 000000D45F00: D73D0028
	v_cndmask_b32_e32 v1, v33, v20, vcc_lo                     // 000000D45F04: 02022921
	v_pk_fma_f16 v22, v22, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000D45F08: CC0E0016 0BFC1316 0000C931
	v_permlanex16_b32 v92, v92, s10, 0xfedcba98                // 000000D45F14: D65C005C 03FC155C FEDCBA98
	v_permlanex16_b32 v114, v114, s10, 0xfedcba98              // 000000D45F20: D65C0072 03FC1572 FEDCBA98
	v_pk_fma_f16 v16, v112, s9, 0xc931 op_sel_hi:[1,0,0]       // 000000D45F2C: CC0E0010 0BFC1370 0000C931
	v_cndmask_b32_e64 v86, v88, v84, s1                        // 000000D45F38: D5010056 0006A958
	v_cndmask_b32_e64 v90, v84, v88, s1                        // 000000D45F40: D501005A 0006B154
	v_cndmask_b32_e64 v84, v104, v100, s1                      // 000000D45F48: D5010054 0006C968
	v_cndmask_b32_e64 v88, v100, v104, s1                      // 000000D45F50: D5010058 0006D164
	s_waitcnt lgkmcnt(6)                                       // 000000D45F58: BF89FC67
	v_wmma_f32_16x16x16_f16 v[2:9], v[76:83], v[44:51], v[2:9] // 000000D45F5C: CC404002 1C0A594C
	v_dual_mov_b32 v113, v101 :: v_dual_mov_b32 v116, v22      // 000000D45F64: CA100165 71740116
	v_cndmask_b32_e64 v94, v92, v19, s1                        // 000000D45F6C: D501005E 0006275C
	v_cndmask_b32_e64 v98, v19, v92, s1                        // 000000D45F74: D5010062 0006B913
	v_cndmask_b32_e64 v93, v114, v18, s1                       // 000000D45F7C: D501005D 00062572
	v_cndmask_b32_e64 v97, v18, v114, s1                       // 000000D45F84: D5010061 0006E512
	v_dual_mov_b32 v18, v16 :: v_dual_mov_b32 v19, v17         // 000000D45F8C: CA100110 12120111
	v_bfe_u32 v41, v40, 12, 16                                 // 000000D45F94: D6100029 02411928
	s_waitcnt lgkmcnt(4)                                       // 000000D45F9C: BF89FC47
	v_wmma_f32_16x16x16_f16 v[2:9], v[84:91], v[52:59], v[2:9] // 000000D45FA0: CC404002 1C0A6954
	v_mul_u32_u24_e32 v56, s5, v41                             // 000000D45FA8: 16705205
	v_mul_u32_u24_e32 v41, s8, v41                             // 000000D45FAC: 16525208
	v_lshl_add_u32 v41, v41, 24, v56                           // 000000D45FB0: D6460029 04E13129
	v_bfe_u32 v55, v40, 4, 16                                  // 000000D45FB8: D6100037 02410928
	v_mul_u32_u24_e32 v57, s5, v55                             // 000000D45FC0: 16726E05
	v_mul_u32_u24_e32 v55, s8, v55                             // 000000D45FC4: 166E6E08
	v_permlanex16_b32 v96, v96, s10, 0xfedcba98                // 000000D45FC8: D65C0060 03FC1560 FEDCBA98
	v_permlanex16_b32 v113, v113, s10, 0xfedcba98              // 000000D45FD4: D65C0071 03FC1571 FEDCBA98
	v_permlanex16_b32 v116, v116, s10, 0xfedcba98              // 000000D45FE0: D65C0074 03FC1574 FEDCBA98
	v_permlanex16_b32 v18, v18, s10, 0xfedcba98                // 000000D45FEC: D65C0012 03FC1512 FEDCBA98
	v_permlanex16_b32 v19, v19, s10, 0xfedcba98                // 000000D45FF8: D65C0013 03FC1513 FEDCBA98
	v_bfe_u32 v53, v40, 8, 16                                  // 000000D46004: D6100035 02411128
	v_lshl_add_u32 v55, v55, 24, v57                           // 000000D4600C: D6460037 04E53137
	v_mul_u32_u24_e32 v57, s5, v53                             // 000000D46014: 16726A05
	v_mul_u32_u24_e32 v53, s8, v53                             // 000000D46018: 166A6A08
	v_sad_u8 v41, v41, 0, 0x6400                               // 000000D4601C: D6220029 03FD0129 00006400
	v_lshl_add_u32 v53, v53, 24, v57                           // 000000D46028: D6460035 04E53135
	v_and_b32_e32 v40, 0xffff, v40                             // 000000D46030: 365050FF 0000FFFF
	v_mul_u32_u24_e32 v58, s5, v40                             // 000000D46038: 16745005
	v_mul_u32_u24_e32 v40, s8, v40                             // 000000D4603C: 16505008
	v_mov_b32_e32 v115, v103                                   // 000000D46040: 7EE60367
	v_cndmask_b32_e64 v102, v96, v23, s1                       // 000000D46044: D5010066 00062F60
	v_cndmask_b32_e64 v106, v23, v96, s1                       // 000000D4604C: D501006A 0006C117
	v_cndmask_b32_e64 v92, v113, v101, s1                      // 000000D46054: D501005C 0006CB71
	v_cndmask_b32_e64 v96, v101, v113, s1                      // 000000D4605C: D5010060 0006E365
	v_cndmask_b32_e64 v101, v116, v22, s1                      // 000000D46064: D5010065 00062D74
	v_cndmask_b32_e64 v105, v22, v116, s1                      // 000000D4606C: D5010069 0006E916
	v_pk_fma_f16 v51, v110, s9, 0xc931 op_sel_hi:[1,0,0]       // 000000D46074: CC0E0033 0BFC136E 0000C931
	v_cndmask_b32_e64 v44, v18, v16, s1                        // 000000D46080: D501002C 00062112
	v_cndmask_b32_e64 v48, v16, v18, s1                        // 000000D46088: D5010030 00062510
	v_cndmask_b32_e64 v45, v19, v17, s1                        // 000000D46090: D501002D 00062313
	v_cndmask_b32_e64 v49, v17, v19, s1                        // 000000D46098: D5010031 00062711
	ds_load_b128 v[16:19], v39 offset:128                      // 000000D460A0: DBFC0080 10000027
	ds_load_b128 v[20:23], v39 offset:144                      // 000000D460A8: DBFC0090 14000027
	s_waitcnt vmcnt(4)                                         // 000000D460B0: BF8913F7
	v_bfe_u32 v50, v108, 12, 16                                // 000000D460B4: D6100032 0241196C
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000D460BC: D6220037 03FD0137 00006400
	v_lshl_add_u32 v40, v40, 24, v58                           // 000000D460C8: D6460028 04E93128
	v_mul_u32_u24_e32 v59, s5, v50                             // 000000D460D0: 16766405
	v_mul_u32_u24_e32 v50, s8, v50                             // 000000D460D4: 16646408
	v_and_b32_e32 v41, 0xffff, v41                             // 000000D460D8: 365252FF 0000FFFF
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000D460E0: D6220035 03FD0135 00006400
	v_lshl_add_u32 v50, v50, 24, v59                           // 000000D460EC: D6460032 04ED3132
	v_bfe_u32 v56, v108, 4, 16                                 // 000000D460F4: D6100038 0241096C
	v_permlanex16_b32 v111, v111, s10, 0xfedcba98              // 000000D460FC: D65C006F 03FC156F FEDCBA98
	v_permlanex16_b32 v115, v115, s10, 0xfedcba98              // 000000D46108: D65C0073 03FC1573 FEDCBA98
	v_dual_mov_b32 v47, v42 :: v_dual_mov_b32 v52, v51         // 000000D46114: CA10012A 2F340133
	v_bfe_u32 v54, v108, 8, 16                                 // 000000D4611C: D6100036 0241116C
	v_and_b32_e32 v55, 0xffff, v55                             // 000000D46124: 366E6EFF 0000FFFF
	v_mul_u32_u24_e32 v58, s5, v56                             // 000000D4612C: 16747005
	v_mul_u32_u24_e32 v56, s8, v56                             // 000000D46130: 16707008
	v_sad_u8 v40, v40, 0, 0x6400                               // 000000D46134: D6220028 03FD0128 00006400
	v_lshl_add_u32 v56, v56, 24, v58                           // 000000D46140: D6460038 04E93138
	v_mul_u32_u24_e32 v58, s5, v54                             // 000000D46148: 16746C05
	v_mul_u32_u24_e32 v54, s8, v54                             // 000000D4614C: 166C6C08
	v_sad_u8 v50, v50, 0, 0x6400                               // 000000D46150: D6220032 03FD0132 00006400
	v_lshl_add_u32 v54, v54, 24, v58                           // 000000D4615C: D6460036 04E93136
	v_lshl_or_b32 v41, v53, 16, v41                            // 000000D46164: D6560029 04A52135
	v_cndmask_b32_e64 v100, v115, v103, s1                     // 000000D4616C: D5010064 0006CF73
	v_cndmask_b32_e64 v104, v103, v115, s1                     // 000000D46174: D5010068 0006E767
	s_waitcnt lgkmcnt(4)                                       // 000000D4617C: BF89FC47
	v_wmma_f32_16x16x16_f16 v[2:9], v[92:99], v[60:67], v[2:9] // 000000D46180: CC404002 1C0A795C
	v_cndmask_b32_e64 v103, v111, v107, s1                     // 000000D46188: D5010067 0006D76F
	v_cndmask_b32_e64 v107, v107, v111, s1                     // 000000D46190: D501006B 0006DF6B
	v_permlanex16_b32 v47, v47, s10, 0xfedcba98                // 000000D46198: D65C002F 03FC152F FEDCBA98
	v_permlanex16_b32 v52, v52, s10, 0xfedcba98                // 000000D461A4: D65C0034 03FC1534 FEDCBA98
	v_and_b32_e32 v57, 0xffff, v108                            // 000000D461B0: 3672D8FF 0000FFFF
	v_lshl_or_b32 v40, v40, 16, v55                            // 000000D461B8: D6560028 04DD2128
	v_mul_u32_u24_e32 v58, s5, v57                             // 000000D461C0: 16747205
	v_mul_u32_u24_e32 v57, s8, v57                             // 000000D461C4: 16727208
	s_delay_alu instid0(VALU_DEP_2)                            // 000000D461C8: BF870002
	v_lshl_add_u32 v57, v57, 24, v58                           // 000000D461CC: D6460039 04E93139
	v_and_b32_e32 v58, 0xffff, v50                             // 000000D461D4: 367464FF 0000FFFF
	v_sad_u8 v54, v54, 0, 0x6400                               // 000000D461DC: D6220036 03FD0136 00006400
	v_pk_fma_f16 v41, v41, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000D461E8: CC0E0029 0BFC1329 0000C931
	s_waitcnt lgkmcnt(2)                                       // 000000D461F4: BF89FC27
	v_wmma_f32_16x16x16_f16 v[2:9], v[100:107], v[68:75], v[2:9]// 000000D461F8: CC404002 1C0A8964
	v_cndmask_b32_e64 v46, v47, v42, s1                        // 000000D46200: D501002E 0006552F
	v_cndmask_b32_e64 v50, v42, v47, s1                        // 000000D46208: D5010032 00065F2A
	v_cndmask_b32_e64 v47, v52, v51, s1                        // 000000D46210: D501002F 00066734
	v_pk_fma_f16 v40, v40, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000D46218: CC0E0028 0BFC1328 0000C931
	v_cndmask_b32_e64 v51, v51, v52, s1                        // 000000D46224: D5010033 00066933
	v_lshl_or_b32 v42, v54, 16, v58                            // 000000D4622C: D656002A 04E92136
	v_mov_b32_e32 v54, v41                                     // 000000D46234: 7E6C0329
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000D46238: D6220038 03FD0138 00006400
	v_mov_b32_e32 v52, v40                                     // 000000D46244: 7E680328
	s_waitcnt lgkmcnt(0)                                       // 000000D46248: BF89FC07
	v_wmma_f32_16x16x16_f16 v[2:9], v[44:51], v[16:23], v[2:9] // 000000D4624C: CC404002 1C0A212C
	s_waitcnt vmcnt(3)                                         // 000000D46254: BF890FF7
	.long 0xd73d0016                                           // 000000D46258: D73D0016
	v_cndmask_b32_e32 v1, v33, v24, vcc_lo                     // 000000D4625C: 02023121
	v_permlanex16_b32 v54, v54, s10, 0xfedcba98                // 000000D46260: D65C0036 03FC1536 FEDCBA98
	v_and_b32_e32 v56, 0xffff, v56                             // 000000D4626C: 367070FF 0000FFFF
	v_permlanex16_b32 v52, v52, s10, 0xfedcba98                // 000000D46274: D65C0034 03FC1534 FEDCBA98
	v_sad_u8 v57, v57, 0, 0x6400                               // 000000D46280: D6220039 03FD0139 00006400
	s_waitcnt vmcnt(2)                                         // 000000D4628C: BF890BF7
	v_bfe_u32 v23, v109, 12, 16                                // 000000D46290: D6100017 0241196D
	v_bfe_u32 v19, v22, 12, 16                                 // 000000D46298: D6100013 02411916
	v_cndmask_b32_e64 v16, v54, v41, s1                        // 000000D462A0: D5010010 00065336
	v_cndmask_b32_e64 v20, v41, v54, s1                        // 000000D462A8: D5010014 00066D29
	v_mul_u32_u24_e32 v41, s5, v19                             // 000000D462B0: 16522605
	v_mul_u32_u24_e32 v19, s8, v19                             // 000000D462B4: 16262608
	v_lshl_add_u32 v19, v19, 24, v41                           // 000000D462B8: D6460013 04A53113
	v_cndmask_b32_e64 v17, v52, v40, s1                        // 000000D462C0: D5010011 00065134
	v_cndmask_b32_e64 v21, v40, v52, s1                        // 000000D462C8: D5010015 00066928
	v_bfe_u32 v40, v22, 4, 16                                  // 000000D462D0: D6100028 02410916
	v_bfe_u32 v24, v22, 8, 16                                  // 000000D462D8: D6100018 02411116
	v_mul_u32_u24_e32 v52, s5, v40                             // 000000D462E0: 16685005
	v_mul_u32_u24_e32 v40, s8, v40                             // 000000D462E4: 16505008
	s_delay_alu instid0(VALU_DEP_2)                            // 000000D462E8: BF870002
	v_lshl_add_u32 v40, v40, 24, v52                           // 000000D462EC: D6460028 04D13128
	v_mul_u32_u24_e32 v52, s5, v24                             // 000000D462F4: 16683005
	v_mul_u32_u24_e32 v24, s8, v24                             // 000000D462F8: 16303008
	v_sad_u8 v19, v19, 0, 0x6400                               // 000000D462FC: D6220013 03FD0113 00006400
	v_lshl_add_u32 v24, v24, 24, v52                           // 000000D46308: D6460018 04D13118
	v_lshl_or_b32 v53, v57, 16, v56                            // 000000D46310: D6560035 04E12139
	v_mul_u32_u24_e32 v57, s5, v23                             // 000000D46318: 16722E05
	v_mul_u32_u24_e32 v23, s8, v23                             // 000000D4631C: 162E2E08
	v_and_b32_e32 v22, 0xffff, v22                             // 000000D46320: 362C2CFF 0000FFFF
	v_lshl_add_u32 v23, v23, 24, v57                           // 000000D46328: D6460017 04E53117
	v_bfe_u32 v41, v109, 4, 16                                 // 000000D46330: D6100029 0241096D
	v_mul_u32_u24_e32 v54, s5, v22                             // 000000D46338: 166C2C05
	v_mul_u32_u24_e32 v22, s8, v22                             // 000000D4633C: 162C2C08
	v_lshl_add_u32 v22, v22, 24, v54                           // 000000D46340: D6460016 04D93116
	v_mul_u32_u24_e32 v54, s5, v41                             // 000000D46348: 166C5205
	v_mul_u32_u24_e32 v41, s8, v41                             // 000000D4634C: 16525208
	v_bfe_u32 v25, v109, 8, 16                                 // 000000D46350: D6100019 0241116D
	v_sad_u8 v40, v40, 0, 0x6400                               // 000000D46358: D6220028 03FD0128 00006400
	v_and_b32_e32 v19, 0xffff, v19                             // 000000D46364: 362626FF 0000FFFF
	v_sad_u8 v24, v24, 0, 0x6400                               // 000000D4636C: D6220018 03FD0118 00006400
	v_lshl_add_u32 v41, v41, 24, v54                           // 000000D46378: D6460029 04D93129
	v_mul_u32_u24_e32 v54, s5, v25                             // 000000D46380: 166C3205
	v_mul_u32_u24_e32 v25, s8, v25                             // 000000D46384: 16323208
	v_pk_fma_f16 v42, v42, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000D46388: CC0E002A 0BFC132A 0000C931
	v_sad_u8 v23, v23, 0, 0x6400                               // 000000D46394: D6220017 03FD0117 00006400
	v_lshl_add_u32 v25, v25, 24, v54                           // 000000D463A0: D6460019 04D93119
	v_and_b32_e32 v52, 0xffff, v109                            // 000000D463A8: 3668DAFF 0000FFFF
	v_mul_u32_u24_e32 v54, s5, v52                             // 000000D463B0: 166C6805
	v_mul_u32_u24_e32 v52, s8, v52                             // 000000D463B4: 16686808
	v_pk_fma_f16 v53, v53, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000D463B8: CC0E0035 0BFC1335 0000C931
	ds_load_b128 v[44:47], v39 offset:160                      // 000000D463C4: DBFC00A0 2C000027
	ds_load_b128 v[48:51], v39 offset:176                      // 000000D463CC: DBFC00B0 30000027
	v_and_b32_e32 v40, 0xffff, v40                             // 000000D463D4: 365050FF 0000FFFF
	v_sad_u8 v41, v41, 0, 0x6400                               // 000000D463DC: D6220029 03FD0129 00006400
	v_lshl_add_u32 v52, v52, 24, v54                           // 000000D463E8: D6460034 04D93134
	v_sad_u8 v54, v22, 0, 0x6400                               // 000000D463F0: D6220036 03FD0116 00006400
	v_lshl_or_b32 v19, v24, 16, v19                            // 000000D463FC: D6560013 044D2118
	v_mov_b32_e32 v55, v42                                     // 000000D46404: 7E6E032A
	v_and_b32_e32 v23, 0xffff, v23                             // 000000D46408: 362E2EFF 0000FFFF
	v_sad_u8 v25, v25, 0, 0x6400                               // 000000D46410: D6220019 03FD0119 00006400
	v_dual_mov_b32 v56, v53 :: v_dual_and_b32 v41, 0xffff, v41 // 000000D4641C: CA240135 382852FF 0000FFFF
	v_sad_u8 v52, v52, 0, 0x6400                               // 000000D46428: D6220034 03FD0134 00006400
	v_lshl_or_b32 v24, v54, 16, v40                            // 000000D46434: D6560018 04A12136
	v_pk_fma_f16 v40, v19, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000D4643C: CC0E0028 0BFC1313 0000C931
	v_permlanex16_b32 v55, v55, s10, 0xfedcba98                // 000000D46448: D65C0037 03FC1537 FEDCBA98
	v_lshl_or_b32 v23, v25, 16, v23                            // 000000D46454: D6560017 045D2119
	v_permlanex16_b32 v56, v56, s10, 0xfedcba98                // 000000D4645C: D65C0038 03FC1538 FEDCBA98
	v_lshl_or_b32 v25, v52, 16, v41                            // 000000D46468: D6560019 04A52134
	v_pk_fma_f16 v41, v24, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000D46470: CC0E0029 0BFC1318 0000C931
	v_mov_b32_e32 v24, v40                                     // 000000D4647C: 7E300328
	v_cndmask_b32_e64 v18, v55, v42, s1                        // 000000D46480: D5010012 00065537
	v_cndmask_b32_e64 v22, v42, v55, s1                        // 000000D46488: D5010016 00066F2A
	v_pk_fma_f16 v42, v23, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000D46490: CC0E002A 0BFC1317 0000C931
	v_cndmask_b32_e64 v19, v56, v53, s1                        // 000000D4649C: D5010013 00066B38
	v_cndmask_b32_e64 v23, v53, v56, s1                        // 000000D464A4: D5010017 00067135
	v_permlanex16_b32 v24, v24, s10, 0xfedcba98                // 000000D464AC: D65C0018 03FC1518 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4)                            // 000000D464B8: BF870004
	v_dual_mov_b32 v52, v41 :: v_dual_mov_b32 v53, v42         // 000000D464BC: CA100129 3434012A
	v_pk_fma_f16 v25, v25, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000D464C4: CC0E0019 0BFC1319 0000C931
	s_waitcnt lgkmcnt(0)                                       // 000000D464D0: BF89FC07
	v_wmma_f32_16x16x16_f16 v[2:9], v[16:23], v[44:51], v[2:9] // 000000D464D4: CC404002 1C0A5910
	v_cndmask_b32_e64 v16, v24, v40, s1                        // 000000D464DC: D5010010 00065118
	v_cndmask_b32_e64 v20, v40, v24, s1                        // 000000D464E4: D5010014 00063128
	s_waitcnt vmcnt(0)                                         // 000000D464EC: BF8903F7
	.long 0xd73d0017                                           // 000000D464F0: D73D0017
	v_cndmask_b32_e32 v1, v33, v26, vcc_lo                     // 000000D464F4: 02023521
	v_permlanex16_b32 v53, v53, s10, 0xfedcba98                // 000000D464F8: D65C0035 03FC1535 FEDCBA98
	v_permlanex16_b32 v52, v52, s10, 0xfedcba98                // 000000D46504: D65C0034 03FC1534 FEDCBA98
	v_bfe_u32 v24, v43, 12, 16                                 // 000000D46510: D6100018 0241192B
	v_bfe_u32 v27, v43, 8, 16                                  // 000000D46518: D610001B 0241112B
	v_mov_b32_e32 v54, v25                                     // 000000D46520: 7E6C0319
	v_bfe_u32 v40, v23, 4, 16                                  // 000000D46524: D6100028 02410917
	v_cndmask_b32_e64 v18, v53, v42, s1                        // 000000D4652C: D5010012 00065535
	v_cndmask_b32_e64 v22, v42, v53, s1                        // 000000D46534: D5010016 00066B2A
	v_bfe_u32 v19, v23, 12, 16                                 // 000000D4653C: D6100013 02411917
	v_bfe_u32 v26, v23, 8, 16                                  // 000000D46544: D610001A 02411117
	v_mul_u32_u24_e32 v42, s5, v40                             // 000000D4654C: 16545005
	v_mul_u32_u24_e32 v40, s8, v40                             // 000000D46550: 16505008
	v_cndmask_b32_e64 v17, v52, v41, s1                        // 000000D46554: D5010011 00065334
	v_cndmask_b32_e64 v21, v41, v52, s1                        // 000000D4655C: D5010015 00066929
	v_mul_u32_u24_e32 v41, s5, v19                             // 000000D46564: 16522605
	v_mul_u32_u24_e32 v19, s8, v19                             // 000000D46568: 16262608
	v_lshl_add_u32 v40, v40, 24, v42                           // 000000D4656C: D6460028 04A93128
	v_mul_u32_u24_e32 v42, s5, v26                             // 000000D46574: 16543405
	v_mul_u32_u24_e32 v26, s8, v26                             // 000000D46578: 16343408
	v_and_b32_e32 v23, 0xffff, v23                             // 000000D4657C: 362E2EFF 0000FFFF
	v_lshl_add_u32 v19, v19, 24, v41                           // 000000D46584: D6460013 04A53113
	v_bfe_u32 v41, v43, 4, 16                                  // 000000D4658C: D6100029 0241092B
	v_lshl_add_u32 v26, v26, 24, v42                           // 000000D46594: D646001A 04A9311A
	v_and_b32_e32 v42, 0xffff, v43                             // 000000D4659C: 365456FF 0000FFFF
	v_mul_u32_u24_e32 v43, s5, v23                             // 000000D465A4: 16562E05
	v_mul_u32_u24_e32 v23, s8, v23                             // 000000D465A8: 162E2E08
	v_mul_u32_u24_e32 v52, s5, v24                             // 000000D465AC: 16683005
	v_mul_u32_u24_e32 v24, s8, v24                             // 000000D465B0: 16303008
	v_lshl_add_u32 v23, v23, 24, v43                           // 000000D465B4: D6460017 04AD3117
	v_mul_u32_u24_e32 v43, s5, v41                             // 000000D465BC: 16565205
	v_mul_u32_u24_e32 v41, s8, v41                             // 000000D465C0: 16525208
	v_lshl_add_u32 v24, v24, 24, v52                           // 000000D465C4: D6460018 04D13118
	v_lshl_add_u32 v41, v41, 24, v43                           // 000000D465CC: D6460029 04AD3129
	v_mul_u32_u24_e32 v43, s5, v27                             // 000000D465D4: 16563605
	v_mul_u32_u24_e32 v27, s8, v27                             // 000000D465D8: 16363608
	v_lshl_add_u32 v27, v27, 24, v43                           // 000000D465DC: D646001B 04AD311B
	v_mul_u32_u24_e32 v43, s5, v42                             // 000000D465E4: 16565405
	v_mul_u32_u24_e32 v42, s8, v42                             // 000000D465E8: 16545408
	v_sad_u8 v19, v19, 0, 0x6400                               // 000000D465EC: D6220013 03FD0113 00006400
	v_sad_u8 v40, v40, 0, 0x6400                               // 000000D465F8: D6220028 03FD0128 00006400
	v_sad_u8 v24, v24, 0, 0x6400                               // 000000D46604: D6220018 03FD0118 00006400
	v_sad_u8 v41, v41, 0, 0x6400                               // 000000D46610: D6220029 03FD0129 00006400
	v_lshl_add_u32 v42, v42, 24, v43                           // 000000D4661C: D646002A 04AD312A
	v_and_b32_e32 v19, 0xffff, v19                             // 000000D46624: 362626FF 0000FFFF
	v_sad_u8 v26, v26, 0, 0x6400                               // 000000D4662C: D622001A 03FD011A 00006400
	v_and_b32_e32 v40, 0xffff, v40                             // 000000D46638: 365050FF 0000FFFF
	v_sad_u8 v23, v23, 0, 0x6400                               // 000000D46640: D6220017 03FD0117 00006400
	v_and_b32_e32 v24, 0xffff, v24                             // 000000D4664C: 363030FF 0000FFFF
	v_sad_u8 v27, v27, 0, 0x6400                               // 000000D46654: D622001B 03FD011B 00006400
	v_and_b32_e32 v41, 0xffff, v41                             // 000000D46660: 365252FF 0000FFFF
	v_sad_u8 v42, v42, 0, 0x6400                               // 000000D46668: D622002A 03FD012A 00006400
	v_permlanex16_b32 v54, v54, s10, 0xfedcba98                // 000000D46674: D65C0036 03FC1536 FEDCBA98
	ds_load_b128 v[44:47], v39 offset:192                      // 000000D46680: DBFC00C0 2C000027
	ds_load_b128 v[48:51], v39 offset:208                      // 000000D46688: DBFC00D0 30000027
	v_lshl_or_b32 v26, v26, 16, v19                            // 000000D46690: D656001A 044D211A
	v_lshl_or_b32 v23, v23, 16, v40                            // 000000D46698: D6560017 04A12117
	v_lshl_or_b32 v24, v27, 16, v24                            // 000000D466A0: D6560018 0461211B
	v_lshl_or_b32 v27, v42, 16, v41                            // 000000D466A8: D656001B 04A5212A
	v_cndmask_b32_e64 v19, v54, v25, s1                        // 000000D466B0: D5010013 00063336
	v_pk_fma_f16 v26, v26, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000D466B8: CC0E001A 0BFC131A 0000C931
	v_pk_fma_f16 v40, v23, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000D466C4: CC0E0028 0BFC1317 0000C931
	v_cndmask_b32_e64 v23, v25, v54, s1                        // 000000D466D0: D5010017 00066D19
	v_pk_fma_f16 v24, v24, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000D466D8: CC0E0018 0BFC1318 0000C931
	v_pk_fma_f16 v25, v27, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000D466E4: CC0E0019 0BFC131B 0000C931
	ds_load_b128 v[52:55], v39 offset:224                      // 000000D466F0: DBFC00E0 34000027
	ds_load_b128 v[56:59], v39 offset:240                      // 000000D466F8: DBFC00F0 38000027
	v_mov_b32_e32 v27, v26                                     // 000000D46700: 7E36031A
	v_mov_b32_e32 v41, v40                                     // 000000D46704: 7E520328
	v_dual_mov_b32 v39, v24 :: v_dual_mov_b32 v42, v25         // 000000D46708: CA100118 272A0119
	s_nor_b32 s13, s0, s11                                     // 000000D46710: 8F0D0B00
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D46714: BF870193
	v_permlanex16_b32 v27, v27, s10, 0xfedcba98                // 000000D46718: D65C001B 03FC151B FEDCBA98
	v_permlanex16_b32 v41, v41, s10, 0xfedcba98                // 000000D46724: D65C0029 03FC1529 FEDCBA98
	s_delay_alu instid0(VALU_DEP_3)                            // 000000D46730: BF870003
	v_permlanex16_b32 v39, v39, s10, 0xfedcba98                // 000000D46734: D65C0027 03FC1527 FEDCBA98
	v_permlanex16_b32 v42, v42, s10, 0xfedcba98                // 000000D46740: D65C002A 03FC152A FEDCBA98
	s_waitcnt lgkmcnt(2)                                       // 000000D4674C: BF89FC27
	v_wmma_f32_16x16x16_f16 v[2:9], v[16:23], v[44:51], v[2:9] // 000000D46750: CC404002 1C0A5910
	v_cndmask_b32_e64 v16, v27, v26, s1                        // 000000D46758: D5010010 0006351B
	v_cndmask_b32_e64 v20, v26, v27, s1                        // 000000D46760: D5010014 0006371A
	v_cndmask_b32_e64 v17, v41, v40, s1                        // 000000D46768: D5010011 00065129
	v_cndmask_b32_e64 v21, v40, v41, s1                        // 000000D46770: D5010015 00065328
	v_cndmask_b32_e64 v18, v39, v24, s1                        // 000000D46778: D5010012 00063127
	v_cndmask_b32_e64 v22, v24, v39, s1                        // 000000D46780: D5010016 00064F18
	v_cndmask_b32_e64 v19, v42, v25, s1                        // 000000D46788: D5010013 0006332A
	v_cndmask_b32_e64 v23, v25, v42, s1                        // 000000D46790: D5010017 00065519
	s_waitcnt lgkmcnt(0)                                       // 000000D46798: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D4679C: BF870001
	v_wmma_f32_16x16x16_f16 v[2:9], v[16:23], v[52:59], v[2:9] // 000000D467A0: CC404002 1C0A6910
	s_and_saveexec_b32 s11, s13                                // 000000D467A8: BE8B200D
	s_cbranch_execz 64270                                      // 000000D467AC: BFA5FB0E <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x91e8>
	s_and_b32 s12, s12, exec_lo                                // 000000D467B0: 8B0C7E0C
	s_cselect_b32 s12, 0x4400, 0                               // 000000D467B4: 980C80FF 00004400
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D467BC: BF870099
	v_add_nc_u32_e32 v16, s12, v30                             // 000000D467C0: 4A203C0C
	v_lshl_add_u32 v16, v29, 1, v16                            // 000000D467C4: D6460010 0441031D
	ds_store_b128 v16, v[10:13]                                // 000000D467CC: DB7C0000 00000A10
	s_branch 64260                                             // 000000D467D4: BFA0FB04 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x91e8>
	v_mad_u32_u24 v10, 0x110, v9, v10                          // 000000D467D8: D60B000A 042A12FF 00000110
	s_waitcnt vmcnt(2)                                         // 000000D467E4: BF890BF7
	ds_store_b128 v10, v[37:40]                                // 000000D467E8: DB7C0000 0000250A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000D467F0: 8C7E017E
	.long 0xd44c0001                                           // 000000D467F4: D44C0001
	v_cndmask_b32_e32 v1, 0x200, v0, vcc_lo                    // 000000D467F8: 020200FF 00000200
	s_and_saveexec_b32 s2, s1                                  // 000000D46800: BE822001
	s_cbranch_execz 55021                                      // 000000D46804: BFA5D6ED <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x1bc>
	s_waitcnt vmcnt(1)                                         // 000000D46808: BF8907F7
	ds_store_b128 v11, v[41:44] offset:8704                    // 000000D4680C: DB7C2200 0000290B
	s_or_b32 exec_lo, exec_lo, s2                              // 000000D46814: 8C7E027E
	.long 0xd44c0002                                           // 000000D46818: D44C0002
	v_cndmask_b32_e32 v1, 0x100, v0, vcc_lo                    // 000000D4681C: 020200FF 00000100
	s_and_saveexec_b32 s3, s2                                  // 000000D46824: BE832002
	s_cbranch_execnz 55018                                     // 000000D46828: BFA6D6EA <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x1d4>
	s_branch 55020                                             // 000000D4682C: BFA0D6EC <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x1e0>
	v_lshrrev_b32_e32 v11, 5, v0                               // 000000D46830: 32160085
	v_and_b32_e32 v13, 1, v0                                   // 000000D46834: 361A0081
	v_and_b32_e32 v14, 2, v0                                   // 000000D46838: 361C0082
	v_and_b32_e32 v15, 4, v0                                   // 000000D4683C: 361E0084
	v_and_b32_e32 v16, 8, v0                                   // 000000D46840: 36200088
	v_lshlrev_b32_e32 v1, 6, v11                               // 000000D46844: 30021686
	v_and_b32_e32 v0, 16, v0                                   // 000000D46848: 36000090
	v_lshrrev_b32_e32 v12, 2, v28                              // 000000D4684C: 32183882
	s_lshl_b32 s0, s17, 7                                      // 000000D46850: 84008711
	s_mul_i32 s3, s16, 0x1400                                  // 000000D46854: 9603FF10 00001400
	v_mad_u32_u24 v1, 0x210, v31, v1                           // 000000D4685C: D60B0001 04063EFF 00000210
	v_cmp_eq_u32_e32 vcc_lo, 0, v0                             // 000000D46868: 7C940080
	v_lshlrev_b32_e32 v0, 3, v28                               // 000000D4686C: 30003883
	s_mul_hi_i32 s2, s16, 0x1400                               // 000000D46870: 9702FF10 00001400
	s_ashr_i32 s1, s0, 31                                      // 000000D46878: 86019F00
	v_and_or_b32 v1, v12, 4, v1                                // 000000D4687C: D6570001 0405090C
	s_add_u32 s3, s14, s3                                      // 000000D46884: 8003030E
	s_addc_u32 s9, s15, s2                                     // 000000D46888: 8209020F
	s_lshl_b64 s[4:5], s[0:1], 1                               // 000000D4688C: 84848100
	.long 0xd7000000                                           // 000000D46890: D7000000
	v_cndmask_b32_e32 v1, s6, v0, vcc_lo                       // 000000D46894: 02020006
	v_lshlrev_b32_e32 v12, 2, v28                              // 000000D46898: 30183882
	ds_store_2addr_b32 v1, v2, v3 offset1:2                    // 000000D4689C: D8380200 00030201
	ds_store_2addr_b32 v1, v4, v5 offset0:4 offset1:6          // 000000D468A4: D8380604 00050401
	ds_store_2addr_b32 v1, v6, v7 offset0:8 offset1:10         // 000000D468AC: D8380A08 00070601
	ds_store_2addr_b32 v1, v8, v9 offset0:12 offset1:14        // 000000D468B4: D8380E0C 00090801
	v_add_co_ci_u32_e64 v1, null, s7, 0, s0                    // 000000D468BC: D5207C01 00010007
	s_add_u32 s8, s3, s4                                       // 000000D468C4: 80080403
	.long 0xd7000400                                           // 000000D468C8: D7000400
	v_cndmask_b32_e32 v0, v0, v4, vcc_lo                       // 000000D468CC: 02000900
	v_lshlrev_b32_e32 v10, 4, v28                              // 000000D468D0: 30143884
	.long 0xd44a0003                                           // 000000D468D4: D44A0003
	v_cndmask_b32_e32 v1, 0, v13, vcc_lo                       // 000000D468D8: 02021A80
	.long 0xd44a0002                                           // 000000D468DC: D44A0002
	v_cndmask_b32_e32 v1, 0, v14, vcc_lo                       // 000000D468E0: 02021C80
	.long 0xd44a0001                                           // 000000D468E4: D44A0001
	v_cndmask_b32_e32 v1, 0, v15, vcc_lo                       // 000000D468E8: 02021E80
	.long 0xd44a0000                                           // 000000D468EC: D44A0000
	v_cndmask_b32_e32 v1, 0, v16, vcc_lo                       // 000000D468F0: 02022080
	v_add_co_ci_u32_e64 v1, null, s5, v1, s4                   // 000000D468F4: D5207C01 00120205
	v_lshlrev_b32_e32 v2, 1, v12                               // 000000D468FC: 30041881
	s_addc_u32 s9, s9, s5                                      // 000000D46900: 82090509
	s_mov_b32 s5, exec_lo                                      // 000000D46904: BE85007E
	s_waitcnt lgkmcnt(0)                                       // 000000D46908: BF89FC07
	s_barrier                                                  // 000000D4690C: BFBD0000
	buffer_gl0_inv                                             // 000000D46910: E0AC0000 00000000
	.long 0xd4c4007e                                           // 000000D46918: D4C4007E
	v_cndmask_b32_e32 v1, s19, v11, vcc_lo                     // 000000D4691C: 02021613
	s_cbranch_execz 204                                        // 000000D46920: BFA500CC <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0xaa54>
	global_load_b64 v[7:8], v2, s[8:9]                         // 000000D46924: DC560000 07080002
	v_mad_u32_u24 v3, 0x210, v11, v10                          // 000000D4692C: D60B0003 042A16FF 00000210
	s_mov_b32 s4, 0x76543210                                   // 000000D46938: BE8400FF 76543210
	ds_load_b128 v[3:6], v3                                    // 000000D46940: DBFC0000 03000003
	s_waitcnt lgkmcnt(0)                                       // 000000D46948: BF89FC07
	v_dual_add_f32 v9, v3, v4 :: v_dual_add_f32 v12, v5, v6    // 000000D4694C: C9080903 090C0D05
	v_dual_sub_f32 v3, v3, v4 :: v_dual_sub_f32 v4, v5, v6     // 000000D46954: C94A0903 03040D05
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D4695C: BF8701A2
	v_add_f32_e32 v5, v9, v12                                  // 000000D46960: 060A1909
	v_sub_f32_e32 v6, v9, v12                                  // 000000D46964: 080C1909
	v_add_f32_e32 v9, v3, v4                                   // 000000D46968: 06120903
	v_sub_f32_e32 v3, v3, v4                                   // 000000D4696C: 08060903
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D46970: BF870224
	v_mov_b32_dpp v4, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D46974: 7E0802FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 000000D4697C: D5010005 200E0B05
	v_mov_b32_dpp v13, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D46984: 7E1A02FA FF016109
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000D4698C: BF870134
	v_mov_b32_dpp v14, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D46990: 7E1C02FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 000000D46998: D5010003 200E0703
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 000000D469A0: D5010009 200E1309
	v_dual_add_f32 v4, v5, v4 :: v_dual_add_f32 v3, v3, v14    // 000000D469A8: C9080905 04021D03
	v_mov_b32_dpp v12, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D469B0: 7E1802FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s3                          // 000000D469B8: D5010006 200E0D06
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000D469C0: BF8700C4
	v_add_f32_e32 v5, v9, v13                                  // 000000D469C4: 060A1B09
	.long 0x7f1c3880                                           // 000000D469C8: 7F1C3880
	v_mov_b32_dpp v13, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D469CC: 7E1A02FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s2                          // 000000D469D4: D5010003 200A0703
	v_dual_add_f32 v6, v6, v12 :: v_dual_add_f32 v3, v3, v13   // 000000D469DC: C9081906 06021B03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000D469E4: BF8701C1
	v_mov_b32_dpp v9, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D469E8: 7E1202FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, s2                          // 000000D469F0: D5010006 200A0D06
	v_mov_b32_dpp v12, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D469F8: 7E1802FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s2                          // 000000D46A00: D5010004 200A0904
	v_add_f32_e32 v6, v6, v9                                   // 000000D46A08: 060C1306
	v_mov_b32_dpp v9, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D46A0C: 7E1202FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s2                          // 000000D46A14: D5010005 200A0B05
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D46A1C: BF870214
	v_add_f32_e32 v4, v4, v12                                  // 000000D46A20: 06081904
	v_mov_b32_dpp v12, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D46A24: 7E1802FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 000000D46A2C: D5010006 20060D06
	s_delay_alu instid0(VALU_DEP_4)                            // 000000D46A34: BF870004
	v_add_f32_e32 v5, v5, v9                                   // 000000D46A38: 060A1305
	v_mov_b32_dpp v9, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D46A3C: 7E1202FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 000000D46A44: D5010003 20060703
	v_mov_b32_dpp v13, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D46A4C: 7E1A02FA FF016404
	v_add_f32_e32 v6, v6, v12                                  // 000000D46A54: 060C1906
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000D46A58: D5010004 20060904
	v_mov_b32_dpp v12, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D46A60: 7E1802FA FF016405
	v_add_f32_e32 v3, v3, v9                                   // 000000D46A68: 06061303
	v_cndmask_b32_e64 v5, -v5, v5, s1                          // 000000D46A6C: D5010005 20060B05
	v_mov_b32_dpp v9, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D46A74: 7E1202FA FF016806
	v_cndmask_b32_e64 v6, -v6, v6, s0                          // 000000D46A7C: D5010006 20020D06
	v_add_f32_e32 v4, v4, v13                                  // 000000D46A84: 06081B04
	v_mov_b32_dpp v13, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D46A88: 7E1A02FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 000000D46A90: D5010003 20020703
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D46A98: BF870214
	v_dual_add_f32 v6, v6, v9 :: v_dual_add_f32 v5, v5, v12    // 000000D46A9C: C9081306 06041905
	v_mov_b32_dpp v9, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D46AA4: 7E1202FA FF016804
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 000000D46AAC: D5010004 20020904
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D46AB4: BF8701A3
	v_mov_b32_e32 v12, v6                                      // 000000D46AB8: 7E180306
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 000000D46ABC: D5010006 21AA0D06
	v_add_f32_e32 v4, v4, v9                                   // 000000D46AC4: 06081304
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000D46AC8: BF8701C3
	v_permlanex16_b32 v12, v12, s4, 0xfedcba98                 // 000000D46ACC: D65C000C 03FC090C FEDCBA98
	v_add_f32_e32 v3, v3, v13                                  // 000000D46AD8: 06061B03
	v_mov_b32_dpp v13, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D46ADC: 7E1A02FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 000000D46AE4: D5010005 20020B05
	v_dual_add_f32 v6, v6, v12 :: v_dual_mov_b32 v15, v3       // 000000D46AEC: C9101906 060E0103
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000D46AF4: D5010003 21AA0703
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D46AFC: BF870222
	v_dual_add_f32 v5, v5, v13 :: v_dual_mul_f32 v6, 0x3db504f3, v6// 000000D46B00: C9061B05 05060CFF 3DB504F3
	v_mov_b32_e32 v9, v4                                       // 000000D46B0C: 7E120304
	v_permlanex16_b32 v15, v15, s4, 0xfedcba98                 // 000000D46B10: D65C000F 03FC090F FEDCBA98
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000D46B1C: D5010004 21AA0904
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000D46B24: BF870244
	v_mov_b32_e32 v12, v5                                      // 000000D46B28: 7E180305
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000D46B2C: D5010005 21AA0B05
	v_permlanex16_b32 v9, v9, s4, 0xfedcba98                   // 000000D46B34: D65C0009 03FC0909 FEDCBA98
	v_add_f32_e32 v3, v3, v15                                  // 000000D46B40: 06061F03
	v_permlanex16_b32 v12, v12, s4, 0xfedcba98                 // 000000D46B44: D65C000C 03FC090C FEDCBA98
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D46B50: BF870223
	v_add_f32_e32 v4, v4, v9                                   // 000000D46B54: 06081304
	.long 0x7f12398e                                           // 000000D46B58: 7F12398E
	v_mul_f32_e32 v3, 0x3db504f3, v3                           // 000000D46B5C: 100606FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D46B64: BF870214
	v_add_f32_e32 v5, v5, v12                                  // 000000D46B68: 060A1905
	v_mul_f32_e32 v4, 0x3db504f3, v4                           // 000000D46B6C: 100808FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000D46B74: BF8903F7
	v_fma_mix_f32 v6, v8, v6, neg(0) op_sel_hi:[1,0,0]         // 000000D46B78: CC200006 8A020D08
	v_fma_mix_f32 v3, v8, v3, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D46B80: CC200803 8A020708
	.long 0x7f10398e                                           // 000000D46B88: 7F10398E
	v_fma_mix_f32 v4, v7, v4, neg(0) op_sel_hi:[1,0,0]         // 000000D46B8C: CC200004 8A020907
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D46B94: BF870214
	.long 0x7e123986                                           // 000000D46B98: 7E123986
	.long 0x7e103983                                           // 000000D46B9C: 7E103983
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D46BA0: BF870092
	v_and_b32_e32 v9, 1, v9                                    // 000000D46BA4: 36121281
	v_add3_u32 v6, v6, v9, 0x7fff                              // 000000D46BA8: D6550006 03FE1306 00007FFF
	.long 0x7f12398e                                           // 000000D46BB4: 7F12398E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D46BB8: BF8700A2
	.long 0x7e123986                                           // 000000D46BBC: 7E123986
	v_dual_mul_f32 v5, 0x3db504f3, v5 :: v_dual_add_nc_u32 v6, s18, v11// 000000D46BC0: C8E00AFF 05061612 3DB504F3
	v_fma_mix_f32 v5, v7, v5, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D46BCC: CC200805 8A020B07
	v_and_b32_e32 v7, 1, v8                                    // 000000D46BD4: 360E1081
	v_bfe_u32 v8, v4, 16, 1                                    // 000000D46BD8: D6100008 02052104
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D46BE0: BF870193
	v_bfe_u32 v12, v5, 16, 1                                   // 000000D46BE4: D610000C 02052105
	v_add3_u32 v3, v3, v7, 0x7fff                              // 000000D46BEC: D6550003 03FE0F03 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D46BF8: BF870223
	v_add3_u32 v4, v4, v8, 0x7fff                              // 000000D46BFC: D6550004 03FE1104 00007FFF
	v_and_b32_e32 v8, 0xffff, v9                               // 000000D46C08: 361012FF 0000FFFF
	v_add3_u32 v5, v5, v12, 0x7fff                             // 000000D46C10: D6550005 03FE1905 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D46C1C: BF870214
	v_and_b32_e32 v7, 0xffff0000, v3                           // 000000D46C20: 360E06FF FFFF0000
	.long 0x7e1c3984                                           // 000000D46C28: 7E1C3984
	v_mad_i64_i32 v[3:4], null, 0x1400, v6, v[0:1]             // 000000D46C2C: D6FF7C03 04020CFF 00001400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D46C38: BF870193
	v_or_b32_e32 v6, v7, v8                                    // 000000D46C3C: 380C1107
	v_and_or_b32 v5, 0xffff0000, v5, v14                       // 000000D46C40: D6570005 043A0AFF FFFF0000
	global_store_b64 v[3:4], v[5:6], off                       // 000000D46C4C: DC6E0000 007C0503
	s_or_b32 exec_lo, exec_lo, s5                              // 000000D46C54: 8C7E057E
	v_or_b32_e32 v3, 8, v11                                    // 000000D46C58: 38061688
	s_mov_b32 s5, exec_lo                                      // 000000D46C5C: BE85007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D46C60: BF870001
	.long 0xd4c4007e                                           // 000000D46C64: D4C4007E
	v_cndmask_b32_e32 v1, s19, v3, vcc_lo                      // 000000D46C68: 02020613
	s_cbranch_execz 201                                        // 000000D46C6C: BFA500C9 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0xad94>
	global_load_b64 v[8:9], v2, s[8:9]                         // 000000D46C70: DC560000 08080002
	v_mad_u32_u24 v2, 0x210, v3, v10                           // 000000D46C78: D60B0002 042A06FF 00000210
	v_add_nc_u32_e32 v3, s18, v3                               // 000000D46C84: 4A060612
	ds_load_b128 v[4:7], v2                                    // 000000D46C88: DBFC0000 04000002
	v_mad_i64_i32 v[0:1], null, 0x1400, v3, v[0:1]             // 000000D46C90: D6FF7C00 040206FF 00001400
	s_waitcnt lgkmcnt(0)                                       // 000000D46C9C: BF89FC07
	v_add_f32_e32 v2, v4, v5                                   // 000000D46CA0: 06040B04
	v_dual_sub_f32 v4, v4, v5 :: v_dual_sub_f32 v5, v6, v7     // 000000D46CA4: C94A0B04 04040F06
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D46CAC: BF870091
	v_dual_add_f32 v10, v6, v7 :: v_dual_add_f32 v7, v4, v5    // 000000D46CB0: C9080F06 0A060B04
	v_add_f32_e32 v6, v2, v10                                  // 000000D46CB8: 060C1502
	v_sub_f32_e32 v2, v2, v10                                  // 000000D46CBC: 08041502
	v_sub_f32_e32 v4, v4, v5                                   // 000000D46CC0: 08080B04
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D46CC4: BF870214
	v_mov_b32_dpp v11, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D46CC8: 7E1602FA FF016107
	v_mov_b32_dpp v5, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D46CD0: 7E0A02FA FF016106
	s_delay_alu instid0(VALU_DEP_4)                            // 000000D46CD8: BF870004
	v_mov_b32_dpp v10, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D46CDC: 7E1402FA FF016102
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 000000D46CE4: D5010002 200E0502
	v_cndmask_b32_e64 v6, -v6, v6, s3                          // 000000D46CEC: D5010006 200E0D06
	v_mov_b32_dpp v12, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D46CF4: 7E1802FA FF016104
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000D46CFC: D5010004 200E0904
	v_cndmask_b32_e64 v7, -v7, v7, s3                          // 000000D46D04: D5010007 200E0F07
	v_add_f32_e32 v2, v2, v10                                  // 000000D46D0C: 06041502
	v_add_f32_e32 v5, v6, v5                                   // 000000D46D10: 060A0B06
	s_mov_b32 s3, 0x76543210                                   // 000000D46D14: BE8300FF 76543210
	v_add_f32_e32 v4, v4, v12                                  // 000000D46D1C: 06081904
	v_add_f32_e32 v6, v7, v11                                  // 000000D46D20: 060C1707
	v_mov_b32_dpp v7, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D46D24: 7E0E02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s2                          // 000000D46D2C: D5010002 200A0502
	v_mov_b32_dpp v10, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D46D34: 7E1402FA FF016205
	v_mov_b32_dpp v11, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D46D3C: 7E1602FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s2                          // 000000D46D44: D5010004 200A0904
	v_cndmask_b32_e64 v5, -v5, v5, s2                          // 000000D46D4C: D5010005 200A0B05
	v_add_f32_e32 v2, v2, v7                                   // 000000D46D54: 06040F02
	v_mov_b32_dpp v7, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D46D58: 7E0E02FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, s2                          // 000000D46D60: D5010006 200A0D06
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D46D68: BF870214
	v_dual_add_f32 v4, v4, v11 :: v_dual_add_f32 v5, v5, v10   // 000000D46D6C: C9081704 04041505
	v_mov_b32_dpp v10, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D46D74: 7E1402FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 000000D46D7C: D5010002 20060502
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D46D84: BF870214
	v_add_f32_e32 v6, v6, v7                                   // 000000D46D88: 060C0F06
	v_mov_b32_dpp v7, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D46D8C: 7E0E02FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000D46D94: D5010004 20060904
	v_mov_b32_dpp v11, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D46D9C: 7E1602FA FF016405
	v_add_f32_e32 v2, v2, v10                                  // 000000D46DA4: 06041502
	v_cndmask_b32_e64 v5, -v5, v5, s1                          // 000000D46DA8: D5010005 20060B05
	v_mov_b32_dpp v10, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D46DB0: 7E1402FA FF016406
	v_add_f32_e32 v4, v4, v7                                   // 000000D46DB8: 06080F04
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 000000D46DBC: D5010006 20060D06
	v_mov_b32_dpp v7, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D46DC4: 7E0E02FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 000000D46DCC: D5010002 20020502
	v_add_f32_e32 v5, v5, v11                                  // 000000D46DD4: 060A1705
	.long 0x7f183880                                           // 000000D46DD8: 7F183880
	v_mov_b32_dpp v11, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D46DDC: 7E1602FA FF016804
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 000000D46DE4: D5010004 20020904
	v_add_f32_e32 v2, v2, v7                                   // 000000D46DEC: 06040F02
	v_mov_b32_dpp v7, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D46DF0: 7E0E02FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 000000D46DF8: D5010005 20020B05
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D46E00: BF870114
	v_add_f32_e32 v4, v4, v11                                  // 000000D46E04: 06081704
	v_add_f32_e32 v5, v5, v7                                   // 000000D46E08: 060A0F05
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D46E0C: BF8701A2
	v_mov_b32_e32 v13, v4                                      // 000000D46E10: 7E1A0304
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000D46E14: D5010004 21AA0904
	v_mov_b32_e32 v7, v5                                       // 000000D46E1C: 7E0E0305
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000D46E20: D5010005 21AA0B05
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D46E28: BF870194
	v_permlanex16_b32 v13, v13, s3, 0xfedcba98                 // 000000D46E2C: D65C000D 03FC070D FEDCBA98
	v_permlanex16_b32 v7, v7, s3, 0xfedcba98                   // 000000D46E38: D65C0007 03FC0707 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D46E44: BF870001
	v_dual_add_f32 v4, v4, v13 :: v_dual_add_f32 v5, v5, v7    // 000000D46E48: C9081B04 04040F05
	.long 0x7f0e398c                                           // 000000D46E50: 7F0E398C
	v_add_f32_e32 v6, v6, v10                                  // 000000D46E54: 060C1506
	v_mov_b32_e32 v10, v2                                      // 000000D46E58: 7E140302
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 000000D46E5C: D5010002 21AA0502
	v_dual_mul_f32 v4, 0x3db504f3, v4 :: v_dual_mul_f32 v5, 0x3db504f3, v5// 000000D46E64: C8C608FF 04040AFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D46E70: BF870093
	v_permlanex16_b32 v10, v10, s3, 0xfedcba98                 // 000000D46E74: D65C000A 03FC070A FEDCBA98
	v_add_f32_e32 v2, v2, v10                                  // 000000D46E80: 06041502
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D46E84: BF8700A1
	v_mul_f32_e32 v2, 0x3db504f3, v2                           // 000000D46E88: 100404FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000D46E90: BF8903F7
	v_fma_mix_f32 v2, v9, v2, neg(0) op_sel_hi:[1,0,0]         // 000000D46E94: CC200002 8A020509
	v_fma_mix_f32 v4, v9, v4, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D46E9C: CC200804 8A020909
	.long 0x7f12398c                                           // 000000D46EA4: 7F12398C
	v_fma_mix_f32 v5, v8, v5, neg(0) op_sel_hi:[1,0,0]         // 000000D46EA8: CC200005 8A020B08
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D46EB0: BF870214
	.long 0x7e0e3982                                           // 000000D46EB4: 7E0E3982
	.long 0x7e123984                                           // 000000D46EB8: 7E123984
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000D46EBC: BF8701B2
	v_and_b32_e32 v7, 1, v7                                    // 000000D46EC0: 360E0E81
	v_mov_b32_dpp v11, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D46EC4: 7E1602FA FF016806
	v_cndmask_b32_e64 v6, -v6, v6, s0                          // 000000D46ECC: D5010006 20020D06
	v_add3_u32 v2, v2, v7, 0x7fff                              // 000000D46ED4: D6550002 03FE0F02 00007FFF
	v_bfe_u32 v7, v5, 16, 1                                    // 000000D46EE0: D6100007 02052105
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D46EE8: BF870093
	v_add_f32_e32 v6, v6, v11                                  // 000000D46EEC: 060C1706
	v_mov_b32_e32 v10, v6                                      // 000000D46EF0: 7E140306
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 000000D46EF4: D5010006 21AA0D06
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D46EFC: BF870092
	v_permlanex16_b32 v10, v10, s3, 0xfedcba98                 // 000000D46F00: D65C000A 03FC070A FEDCBA98
	v_add_f32_e32 v6, v6, v10                                  // 000000D46F0C: 060C1506
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D46F10: BF870091
	v_mul_f32_e32 v6, 0x3db504f3, v6                           // 000000D46F14: 100C0CFF 3DB504F3
	v_fma_mix_f32 v6, v8, v6, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D46F1C: CC200806 8A020D08
	v_and_b32_e32 v8, 1, v9                                    // 000000D46F24: 36101281
	.long 0x7e123982                                           // 000000D46F28: 7E123982
	v_add3_u32 v2, v5, v7, 0x7fff                              // 000000D46F2C: D6550002 03FE0F05 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D46F38: BF870214
	v_bfe_u32 v10, v6, 16, 1                                   // 000000D46F3C: D610000A 02052106
	v_add3_u32 v4, v4, v8, 0x7fff                              // 000000D46F44: D6550004 03FE1104 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D46F50: BF870193
	.long 0x7e183982                                           // 000000D46F54: 7E183982
	v_add3_u32 v5, v6, v10, 0x7fff                             // 000000D46F58: D6550005 03FE1506 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D46F64: BF8701A3
	v_and_b32_e32 v4, 0xffff0000, v4                           // 000000D46F68: 360808FF FFFF0000
	v_and_b32_e32 v6, 0xffff, v9                               // 000000D46F70: 360C12FF 0000FFFF
	v_and_or_b32 v2, 0xffff0000, v5, v12                       // 000000D46F78: D6570002 04320AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2)                            // 000000D46F84: BF870002
	v_or_b32_e32 v3, v4, v6                                    // 000000D46F88: 38060D04
	global_store_b64 v[0:1], v[2:3], off                       // 000000D46F8C: DC6E0000 007C0200
	s_or_b32 exec_lo, exec_lo, s5                              // 000000D46F94: 8C7E057E
	s_mov_b32 s3, -1                                           // 000000D46F98: BE8300C1
	s_waitcnt_vscnt null, 0x0                                  // 000000D46F9C: BC7C0000
	s_barrier                                                  // 000000D46FA0: BFBD0000
	s_and_b32 vcc_lo, exec_lo, s3                              // 000000D46FA4: 8B6A037E
	s_cbranch_vccz 2                                           // 000000D46FA8: BFA30002 <_ZN7halogen12_GLOBAL__N_113k_ht_moe_dn2wILi4ELi64ELi6ELi2EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0xadb4>
	buffer_gl0_inv                                             // 000000D46FAC: E0AC0000 00000000
	s_endpgm                                                   // 000000D46FB4: BFB00000
		...

