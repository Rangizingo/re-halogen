00000000003eaa00 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj>:
; _ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj():
	s_clause 0x1                                               // 0000003EAA00: BF850001
	s_load_b64 s[4:5], s[0:1], 0x130                           // 0000003EAA04: F4040100 F8000130
	s_load_b128 s[16:19], s[0:1], 0x198                        // 0000003EAA0C: F4080400 F8000198
	s_waitcnt lgkmcnt(0)                                       // 0000003EAA14: BF89FC07
	s_cmp_eq_u64 s[4:5], 0                                     // 0000003EAA18: BF108004
	s_cbranch_scc1 246                                         // 0000003EAA1C: BFA200F6 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3f8>
	s_load_b32 s6, s[0:1], 0x138                               // 0000003EAA20: F4000180 F8000138
	s_waitcnt lgkmcnt(0)                                       // 0000003EAA28: BF89FC07
	s_cmp_lt_i32 s2, s6                                        // 0000003EAA2C: BF040602
	s_cselect_b32 s3, -1, 0                                    // 0000003EAA30: 980380C1
	s_cmp_ge_i32 s2, s6                                        // 0000003EAA34: BF030602
	s_cbranch_scc0 233                                         // 0000003EAA38: BFA100E9 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3e0>
	v_lshrrev_b32_e32 v1, 5, v0                                // 0000003EAA3C: 32020085
	s_sub_i32 s6, s2, s6                                       // 0000003EAA40: 81860602
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000003EAA44: BF870481
	v_lshl_or_b32 v1, s6, 3, v1                                // 0000003EAA48: D6560001 04050606
	s_mul_i32 s6, s18, 20                                      // 0000003EAA50: 96069412
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000003EAA54: BF870481
	v_cmp_gt_i32_e32 vcc_lo, s6, v1                            // 0000003EAA58: 7C880206
	s_and_saveexec_b32 s6, vcc_lo                              // 0000003EAA5C: BE86206A
	s_cbranch_execz 222                                        // 0000003EAA60: BFA500DE <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3dc>
	.long 0xd72e0002                                           // 0000003EAA64: D72E0002
	v_cndmask_b32_e32 v1, 0x66666667, v1, vcc_lo               // 0000003EAA68: 020202FF 66666667
	v_and_b32_e32 v9, 31, v0                                   // 0000003EAA70: 3612009F
	s_load_b64 s[8:9], s[0:1], 0x128                           // 0000003EAA74: F4040200 F8000128
	s_mov_b32 s7, 0x76543210                                   // 0000003EAA7C: BE8700FF 76543210
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003EAA84: BF8700A2
	v_lshrrev_b32_e32 v3, 31, v2                               // 0000003EAA88: 3206049F
	v_ashrrev_i32_e32 v2, 3, v2                                // 0000003EAA8C: 34040483
	v_add_nc_u32_e32 v8, v2, v3                                // 0000003EAA90: 4A100702
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003EAA94: BF870121
	.long 0xd72c0002                                           // 0000003EAA98: D72C0002
	v_cndmask_b32_e32 v1, 0xffffffec, v8, vcc_lo               // 0000003EAA9C: 020210FF FFFFFFEC
	v_mad_i64_i32 v[4:5], null, 0x1400, v8, s[16:17]           // 0000003EAAA4: D6FF7C04 004210FF 00001400
	v_add_lshl_u32 v1, v2, v1, 7                               // 0000003EAAB0: D6470001 021E0302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003EAAB8: BF870091
	v_lshl_or_b32 v2, v9, 2, v1                                // 0000003EAABC: D6560002 04050509
	v_ashrrev_i32_e32 v3, 31, v2                               // 0000003EAAC4: 3406049F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003EAAC8: BF870091
	.long 0xd73c0002                                           // 0000003EAACC: D73C0002
	v_cndmask_b32_e32 v1, 1, v2, vcc_lo                        // 0000003EAAD0: 02020481
	.long 0xd7006a04                                           // 0000003EAAD4: D7006A04
	v_cndmask_b32_e32 v1, v4, v2, vcc_lo                       // 0000003EAAD8: 02020504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000003EAADC: BF8700B1
	v_add_co_ci_u32_e64 v5, null, v5, v3, vcc_lo               // 0000003EAAE0: D5207C05 01AA0705
	s_waitcnt lgkmcnt(0)                                       // 0000003EAAE8: BF89FC07
	.long 0xd7006a02                                           // 0000003EAAEC: D7006A02
	v_cndmask_b32_e32 v1, s8, v2, vcc_lo                       // 0000003EAAF0: 02020408
	v_add_co_ci_u32_e64 v3, null, s9, v3, vcc_lo               // 0000003EAAF4: D5207C03 01AA0609
	global_load_b64 v[4:5], v[4:5], off                        // 0000003EAAFC: DC560000 047C0004
	s_mov_b32 s8, 0x3db504f3                                   // 0000003EAB04: BE8800FF 3DB504F3
	global_load_b64 v[6:7], v[2:3], off                        // 0000003EAB0C: DC560000 067C0002
	s_waitcnt vmcnt(1)                                         // 0000003EAB14: BF8907F7
	.long 0x7e043904                                           // 0000003EAB18: 7E043904
	v_and_b32_e32 v3, 0xffff0000, v4                           // 0000003EAB1C: 360608FF FFFF0000
	.long 0x7e083905                                           // 0000003EAB24: 7E083905
	v_and_b32_e32 v5, 0xffff0000, v5                           // 0000003EAB28: 360A0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003EAB30: BF870004
	v_lshlrev_b32_e32 v14, 16, v2                              // 0000003EAB34: 301C0490
	s_waitcnt vmcnt(0)                                         // 0000003EAB38: BF8903F7
	v_fma_mix_f32 v3, v6, v3, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 0000003EAB3C: CC200803 8A020706
	v_lshlrev_b32_e32 v4, 16, v4                               // 0000003EAB44: 30080890
	v_fma_mix_f32 v5, v7, v5, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 0000003EAB48: CC200805 8A020B07
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000003EAB50: 3404029F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000003EAB54: BF870224
	v_fma_mix_f32 v15, v6, v14, v3 op_sel_hi:[1,0,0]           // 0000003EAB58: CC20000F 0C0E1D06
	v_fma_mix_f32 v6, v6, v14, -v3 op_sel_hi:[1,0,0]           // 0000003EAB60: CC200006 8C0E1D06
	v_fma_mix_f32 v14, v7, v4, v5 op_sel_hi:[1,0,0]            // 0000003EAB68: CC20000E 0C160907
	v_fma_mix_f32 v5, v7, v4, -v5 op_sel_hi:[1,0,0]            // 0000003EAB70: CC200005 8C160907
	v_and_b32_e32 v10, 1, v0                                   // 0000003EAB78: 36140081
	v_and_b32_e32 v11, 2, v0                                   // 0000003EAB7C: 36160082
	v_and_b32_e32 v13, 8, v0                                   // 0000003EAB80: 361A0088
	.long 0xd73c0001                                           // 0000003EAB84: D73C0001
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000003EAB88: 02020281
	v_add_f32_e32 v16, v6, v5                                  // 0000003EAB8C: 06200B06
	v_sub_f32_e32 v5, v6, v5                                   // 0000003EAB90: 080A0B06
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 0000003EAB94: 7C941480
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003EAB98: BF870193
	v_mov_b32_dpp v10, v16 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003EAB9C: 7E1402FA FF016110
	v_mov_b32_dpp v17, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003EABA4: 7E2202FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 0000003EABAC: D5010005 21AA0B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 0000003EABB4: BF8701D1
	v_add_f32_e32 v5, v5, v17                                  // 0000003EABB8: 060A2305
	v_mad_i64_i32 v[3:4], null, 0x1400, v8, s[4:5]             // 0000003EABBC: D6FF7C03 001210FF 00001400
	v_add_f32_e32 v8, v15, v14                                 // 0000003EABC8: 06101D0F
	v_sub_f32_e32 v14, v15, v14                                // 0000003EABCC: 081C1D0F
	v_cndmask_b32_e64 v15, -v16, v16, vcc_lo                   // 0000003EABD0: D501000F 21AA2110
	v_mov_b32_dpp v6, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003EABD8: 7E0C02FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 0000003EABE0: D5010008 21AA1108
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000003EABE8: BF870234
	v_mov_b32_dpp v16, v14 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003EABEC: 7E2002FA FF01610E
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 0000003EABF4: D501000E 21AA1D0E
	v_cmp_eq_u32_e32 vcc_lo, 0, v11                            // 0000003EABFC: 7C941680
	v_dual_add_f32 v6, v8, v6 :: v_dual_lshlrev_b32 v7, 3, v9  // 0000003EAC00: C9220D08 06061283
	v_add_f32_e32 v8, v15, v10                                 // 0000003EAC08: 0610150F
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003EAC0C: BF870004
	v_add_f32_e32 v10, v14, v16                                // 0000003EAC10: 0614210E
	v_mov_b32_dpp v16, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003EAC14: 7E2002FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 0000003EAC1C: D5010005 21AA0B05
	v_mov_b32_dpp v11, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003EAC24: 7E1602FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 0000003EAC2C: D5010006 21AA0D06
	v_mov_b32_dpp v15, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003EAC34: 7E1E02FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 0000003EAC3C: D501000A 21AA150A
	v_add_f32_e32 v5, v5, v16                                  // 0000003EAC44: 060A2105
	v_mov_b32_dpp v14, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003EAC48: 7E1C02FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 0000003EAC50: D5010008 21AA1108
	v_add_f32_e32 v6, v6, v11                                  // 0000003EAC58: 060C1706
	v_add_f32_e32 v10, v10, v15                                // 0000003EAC5C: 06141F0A
	v_mov_b32_dpp v15, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003EAC60: 7E1E02FA FF016405
	v_and_b32_e32 v12, 4, v0                                   // 0000003EAC68: 36180084
	v_add_f32_e32 v8, v8, v14                                  // 0000003EAC6C: 06101D08
	v_mov_b32_dpp v11, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003EAC70: 7E1602FA FF016406
	v_mov_b32_dpp v14, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003EAC78: 7E1C02FA FF01640A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000003EAC80: BF8701C4
	v_cmp_eq_u32_e32 vcc_lo, 0, v12                            // 0000003EAC84: 7C941880
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 0000003EAC88: D5010006 21AA0D06
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 0000003EAC90: D5010005 21AA0B05
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 0000003EAC98: D501000A 21AA150A
	v_add_f32_e32 v6, v6, v11                                  // 0000003EACA0: 060C1706
	s_delay_alu instid0(VALU_DEP_3)                            // 0000003EACA4: BF870003
	v_add_f32_e32 v5, v5, v15                                  // 0000003EACA8: 060A1F05
	v_mov_b32_dpp v12, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003EACAC: 7E1802FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 0000003EACB4: D5010008 21AA1108
	v_cmp_eq_u32_e32 vcc_lo, 0, v13                            // 0000003EACBC: 7C941A80
	v_add_f32_e32 v10, v10, v14                                // 0000003EACC0: 06141D0A
	v_mov_b32_dpp v11, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003EACC4: 7E1602FA FF016806
	v_mov_b32_dpp v14, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003EACCC: 7E1C02FA FF016805
	v_add_f32_e32 v8, v8, v12                                  // 0000003EACD4: 06101908
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 0000003EACD8: D5010006 21AA0D06
	v_mov_b32_dpp v13, v10 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003EACE0: 7E1A02FA FF01680A
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 0000003EACE8: D5010005 21AA0B05
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 0000003EACF0: D501000A 21AA150A
	v_mov_b32_dpp v12, v8 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003EACF8: 7E1802FA FF016808
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 0000003EAD00: D5010008 21AA1108
	v_add_f32_e32 v6, v6, v11                                  // 0000003EAD08: 060C1706
	v_cmp_gt_u32_e32 vcc_lo, 16, v9                            // 0000003EAD0C: 7C981290
	v_add_f32_e32 v5, v5, v14                                  // 0000003EAD10: 060A1D05
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003EAD14: BF870214
	v_dual_add_f32 v9, v10, v13 :: v_dual_add_f32 v8, v8, v12  // 0000003EAD18: C9081B0A 09081908
	v_mov_b32_e32 v10, v6                                      // 0000003EAD20: 7E140306
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 0000003EAD24: D5010006 21AA0D06
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003EAD2C: BF870214
	v_mov_b32_e32 v13, v5                                      // 0000003EAD30: 7E1A0305
	v_mov_b32_e32 v12, v9                                      // 0000003EAD34: 7E180309
	v_cndmask_b32_e64 v11, -v8, v8, vcc_lo                     // 0000003EAD38: D501000B 21AA1108
	v_permlanex16_b32 v8, v8, s7, 0xfedcba98                   // 0000003EAD40: D65C0008 03FC0F08 FEDCBA98
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 0000003EAD4C: D5010005 21AA0B05
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 0000003EAD54: D5010009 21AA1309
	v_permlanex16_b32 v10, v10, s7, 0xfedcba98                 // 0000003EAD5C: D65C000A 03FC0F0A FEDCBA98
	v_permlanex16_b32 v12, v12, s7, 0xfedcba98                 // 0000003EAD68: D65C000C 03FC0F0C FEDCBA98
	v_permlanex16_b32 v13, v13, s7, 0xfedcba98                 // 0000003EAD74: D65C000D 03FC0F0D FEDCBA98
	.long 0xd7006a01                                           // 0000003EAD80: D7006A01
	v_cndmask_b32_e32 v1, v3, v1, vcc_lo                       // 0000003EAD84: 02020303
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000003EAD88: BF8700D1
	v_add_co_ci_u32_e64 v2, null, v4, v2, vcc_lo               // 0000003EAD8C: D5207C02 01AA0504
	v_dual_add_f32 v3, v11, v8 :: v_dual_add_f32 v4, v6, v10   // 0000003EAD94: C908110B 03041506
	v_add_f32_e32 v6, v9, v12                                  // 0000003EAD9C: 060C1909
	v_add_f32_e32 v5, v5, v13                                  // 0000003EADA0: 060A1B05
	.long 0xd7006a01                                           // 0000003EADA4: D7006A01
	v_cndmask_b32_e32 v1, v1, v7, vcc_lo                       // 0000003EADA8: 02020F01
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 0000003EADAC: D5207C02 01AA0480
	v_fma_mixhi_f16 v3, v3, s8, 0                              // 0000003EADB4: CC220003 02001103
	v_fma_mixlo_f16 v3, v4, s8, 0                              // 0000003EADBC: CC210003 02001104
	v_fma_mixhi_f16 v4, v5, s8, 0                              // 0000003EADC4: CC220004 02001105
	v_fma_mixlo_f16 v4, v6, s8, 0                              // 0000003EADCC: CC210004 02001106
	global_store_b64 v[1:2], v[3:4], off                       // 0000003EADD4: DC6E0000 007C0301
	s_or_b32 exec_lo, exec_lo, s6                              // 0000003EADDC: 8C7E067E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003EADE0: BF870009
	s_and_b32 vcc_lo, exec_lo, s3                              // 0000003EADE4: 8B6A037E
	s_cbranch_vccnz 4                                          // 0000003EADE8: BFA40004 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3fc>
	s_nop 0                                                    // 0000003EADEC: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000003EADF0: BFB60003
	s_endpgm                                                   // 0000003EADF4: BFB00000
	s_cbranch_execz 65532                                      // 0000003EADF8: BFA5FFFC <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	s_clause 0x3                                               // 0000003EADFC: BF850003
	s_load_b32 s3, s[0:1], 0x120                               // 0000003EAE00: F40000C0 F8000120
	s_load_b32 s4, s[0:1], 0x7c                                // 0000003EAE08: F4000100 F800007C
	s_load_b32 s5, s[0:1], 0xc4                                // 0000003EAE10: F4000140 F80000C4
	s_load_b32 s6, s[0:1], 0x10c                               // 0000003EAE18: F4000180 F800010C
	v_and_b32_e32 v41, 31, v0                                  // 0000003EAE20: 3652009F
	v_lshrrev_b32_e32 v40, 5, v0                               // 0000003EAE24: 32500085
	s_delay_alu instid0(VALU_DEP_2)                            // 0000003EAE28: BF870002
	v_lshlrev_b32_e32 v7, 3, v41                               // 0000003EAE2C: 300E5283
	s_waitcnt lgkmcnt(0)                                       // 0000003EAE30: BF89FC07
	s_cmp_gt_i32 s3, 1                                         // 0000003EAE34: BF028103
	s_cselect_b32 s7, -1, 0                                    // 0000003EAE38: 980780C1
	s_cmp_ge_i32 s2, s4                                        // 0000003EAE3C: BF030402
	s_cselect_b32 s4, -1, 0                                    // 0000003EAE40: 980480C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003EAE44: BF870009
	s_and_b32 s4, s7, s4                                       // 0000003EAE48: 8B040407
	s_cmp_gt_i32 s3, 2                                         // 0000003EAE4C: BF028203
	v_cndmask_b32_e64 v1, 0, 1, s4                             // 0000003EAE50: D5010001 00110280
	s_cselect_b32 s7, -1, 0                                    // 0000003EAE58: 980780C1
	s_cmp_ge_i32 s2, s5                                        // 0000003EAE5C: BF030502
	s_cselect_b32 s5, -1, 0                                    // 0000003EAE60: 980580C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003EAE64: BF870009
	s_and_b32 s4, s7, s5                                       // 0000003EAE68: 8B040507
	s_cmp_gt_i32 s3, 3                                         // 0000003EAE6C: BF028303
	v_readfirstlane_b32 s5, v1                                 // 0000003EAE70: 7E0A0501
	s_cselect_b32 s3, -1, 0                                    // 0000003EAE74: 980380C1
	s_cmp_ge_i32 s2, s6                                        // 0000003EAE78: BF030602
	s_cselect_b32 s6, -1, 0                                    // 0000003EAE7C: 980680C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 0000003EAE80: BF8704D9
	s_and_b32 s3, s3, s6                                       // 0000003EAE84: 8B030603
	s_and_b32 s4, s4, exec_lo                                  // 0000003EAE88: 8B047E04
	s_cselect_b32 s4, 2, s5                                    // 0000003EAE8C: 98040582
	s_and_b32 s3, s3, exec_lo                                  // 0000003EAE90: 8B037E03
	s_cselect_b32 s3, 3, s4                                    // 0000003EAE94: 98030483
	s_mulk_i32 s3, 0x48                                        // 0000003EAE98: B8030048
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003EAE9C: BF870009
	s_add_u32 s4, s0, s3                                       // 0000003EAEA0: 80040300
	s_addc_u32 s5, s1, 0                                       // 0000003EAEA4: 82058001
	s_clause 0x3                                               // 0000003EAEA8: BF850003
	s_load_b32 s28, s[4:5], 0x38                               // 0000003EAEAC: F4000702 F8000038
	s_load_b64 s[30:31], s[4:5], 0x40                          // 0000003EAEB4: F4040782 F8000040
	s_load_b128 s[20:23], s[4:5], 0x28                         // 0000003EAEBC: F4080502 F8000028
	s_load_b64 s[24:25], s[4:5], 0x20                          // 0000003EAEC4: F4040602 F8000020
	s_waitcnt lgkmcnt(0)                                       // 0000003EAECC: BF89FC07
	s_abs_i32 s3, s21                                          // 0000003EAED0: BE831515
	s_sub_i32 s2, s2, s23                                      // 0000003EAED4: 81821702
	s_cvt_f32_u32 s6, s3                                       // 0000003EAED8: BE866503
	s_sub_i32 s7, 0, s3                                        // 0000003EAEDC: 81870380
	s_abs_i32 s8, s2                                           // 0000003EAEE0: BE881502
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000003EAEE4: BF870299
	v_rcp_iflag_f32_e32 v1, s6                                 // 0000003EAEE8: 7E025606
	v_readfirstlane_b32 s6, v1                                 // 0000003EAEEC: 7E0C0501
	s_mul_f32 s6, s6, 0x4f7ffffe                               // 0000003EAEF0: A206FF06 4F7FFFFE
	s_delay_alu instid0(SALU_CYCLE_3) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 0000003EAEF8: BF87059B
	s_cvt_u32_f32 s6, s6                                       // 0000003EAEFC: BE866706
	s_mul_i32 s7, s7, s6                                       // 0000003EAF00: 96070607
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000003EAF04: BF870499
	s_mul_hi_u32 s7, s6, s7                                    // 0000003EAF08: 96870706
	s_add_i32 s6, s6, s7                                       // 0000003EAF0C: 81060706
	s_xor_b32 s7, s2, s21                                      // 0000003EAF10: 8D071502
	s_mul_hi_u32 s6, s8, s6                                    // 0000003EAF14: 96860608
	s_ashr_i32 s7, s7, 31                                      // 0000003EAF18: 86079F07
	s_mul_i32 s9, s6, s3                                       // 0000003EAF1C: 96090306
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003EAF20: BF870009
	s_sub_i32 s8, s8, s9                                       // 0000003EAF24: 81880908
	s_add_i32 s9, s6, 1                                        // 0000003EAF28: 81098106
	s_sub_i32 s10, s8, s3                                      // 0000003EAF2C: 818A0308
	s_cmp_ge_u32 s8, s3                                        // 0000003EAF30: BF090308
	s_cselect_b32 s6, s9, s6                                   // 0000003EAF34: 98060609
	s_cselect_b32 s8, s10, s8                                  // 0000003EAF38: 9808080A
	s_add_i32 s9, s6, 1                                        // 0000003EAF3C: 81098106
	s_cmp_ge_u32 s8, s3                                        // 0000003EAF40: BF090308
	s_cselect_b32 s3, s9, s6                                   // 0000003EAF44: 98030609
	s_load_b256 s[8:15], s[4:5], null                          // 0000003EAF48: F40C0202 F8000000
	s_xor_b32 s3, s3, s7                                       // 0000003EAF50: 8D030703
	s_ashr_i32 s29, s19, 31                                    // 0000003EAF54: 861D9F13
	s_sub_i32 s26, s3, s7                                      // 0000003EAF58: 819A0703
	s_lshr_b32 s4, s29, 25                                     // 0000003EAF5C: 8504991D
	s_mul_i32 s3, s26, s21                                     // 0000003EAF60: 9603151A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 0000003EAF64: BF8704D9
	s_sub_i32 s23, s2, s3                                      // 0000003EAF68: 81970302
	s_add_i32 s2, s19, s4                                      // 0000003EAF6C: 81020413
	s_mul_i32 s27, s22, s23                                    // 0000003EAF70: 961B1716
	s_ashr_i32 s2, s2, 7                                       // 0000003EAF74: 86028702
	s_add_i32 s3, s27, s22                                     // 0000003EAF78: 8103161B
	s_min_i32 s2, s2, s3                                       // 0000003EAF7C: 89020302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000003EAF80: BF8704B9
	s_sub_i32 s7, s2, s27                                      // 0000003EAF84: 81871B02
	s_mov_b32 s2, exec_lo                                      // 0000003EAF88: BE82007E
	s_lshl_b32 s22, s7, 1                                      // 0000003EAF8C: 84168107
	.long 0xd4c3007e                                           // 0000003EAF90: D4C3007E
	v_cndmask_b32_e32 v1, s22, v40, vcc_lo                     // 0000003EAF94: 02025016
	s_xor_b32 s2, exec_lo, s2                                  // 0000003EAF98: 8D02027E
	v_lshlrev_b32_e32 v7, 3, v41                               // 0000003EAF9C: 300E5283
	s_and_not1_saveexec_b32 s33, s2                            // 0000003EAFA0: BEA13002
	s_cbranch_execz 286                                        // 0000003EAFA4: BFA5011E <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0xa20>
	s_abs_i32 s34, s7                                          // 0000003EAFA8: BEA21507
	v_lshlrev_b32_e32 v9, 7, v40                               // 0000003EAFAC: 30125087
	s_cvt_f32_u32 s2, s34                                      // 0000003EAFB0: BE826522
	v_and_b32_e32 v4, 4, v0                                    // 0000003EAFB4: 36080084
	v_and_b32_e32 v5, 8, v0                                    // 0000003EAFB8: 360A0088
	v_lshl_or_b32 v8, v40, 8, v7                               // 0000003EAFBC: D6560008 041D1128
	v_rcp_iflag_f32_e32 v1, s2                                 // 0000003EAFC4: 7E025602
	s_sub_i32 s2, 0, s34                                       // 0000003EAFC8: 81822280
	v_lshl_add_u32 v9, s27, 7, v9                              // 0000003EAFCC: D6460009 04250E1B
	s_ashr_i32 s38, s7, 31                                     // 0000003EAFD4: 86269F07
	.long 0xd44a0004                                           // 0000003EAFD8: D44A0004
	v_cndmask_b32_e32 v1, 0, v4, vcc_lo                        // 0000003EAFDC: 02020880
	s_mul_i32 s40, s38, 0x1400                                 // 0000003EAFE0: 9628FF26 00001400
	.long 0xd44a0005                                           // 0000003EAFE8: D44A0005
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 0000003EAFEC: 02020A80
	s_lshl_b32 s6, s7, 7                                       // 0000003EAFF0: 84068707
	s_add_i32 s35, s18, -1                                     // 0000003EAFF4: 8123C112
	s_mov_b32 s36, s19                                         // 0000003EAFF8: BEA40013
	v_dual_mul_f32 v1, 0x4f7ffffe, v1 :: v_dual_and_b32 v2, 1, v0// 0000003EAFFC: C8E402FF 01020081 4F7FFFFE
	s_mov_b32 s37, 0                                           // 0000003EB008: BEA50080
	s_lshl_b32 s39, s7, 8                                      // 0000003EB00C: 84278807
	s_mov_b32 s41, 0x76543210                                  // 0000003EB010: BEA900FF 76543210
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000003EB018: BF8701C1
	v_cvt_u32_f32_e32 v3, v1                                   // 0000003EB01C: 7E060F01
	v_dual_mov_b32 v4, v40 :: v_dual_and_b32 v1, 2, v0         // 0000003EB020: CA240128 04000082
	s_mov_b32 s42, 0x3db504f3                                  // 0000003EB028: BEAA00FF 3DB504F3
	v_cmp_gt_u32_e32 vcc_lo, 16, v41                           // 0000003EB030: 7C985290
	.long 0xd72c0006                                           // 0000003EB034: D72C0006
	v_cndmask_b32_e32 v1, s2, v3, vcc_lo                       // 0000003EB038: 02020602
	.long 0xd44a0002                                           // 0000003EB03C: D44A0002
	v_cndmask_b32_e32 v1, 0, v2, vcc_lo                        // 0000003EB040: 02020480
	.long 0xd44a0003                                           // 0000003EB044: D44A0003
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000003EB048: 02020280
	v_subrev_nc_u32_e32 v2, s40, v8                            // 0000003EB04C: 4E041028
	v_lshl_or_b32 v1, v41, 2, v9                               // 0000003EB050: D6560001 04250529
	s_sub_i32 s40, 0, s6                                       // 0000003EB058: 81A80680
	.long 0xd72d0006                                           // 0000003EB05C: D72D0006
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000003EB060: 02020D03
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003EB064: BF870001
	v_add_nc_u32_e32 v3, v3, v6                                // 0000003EB068: 4A060D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003EB06C: BF870091
	.long 0xd72d0005                                           // 0000003EB070: D72D0005
	v_cndmask_b32_e32 v1, v4, v3, vcc_lo                       // 0000003EB074: 02020704
	.long 0xd72c0006                                           // 0000003EB078: D72C0006
	v_cndmask_b32_e32 v0, v5, v34, vcc_lo                      // 0000003EB07C: 02004505
	v_add_nc_u32_e32 v8, 1, v5                                 // 0000003EB080: 4A100A81
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003EB084: BF870092
	v_sub_nc_u32_e32 v6, v4, v6                                // 0000003EB088: 4C0C0D04
	v_subrev_nc_u32_e32 v9, s34, v6                            // 0000003EB08C: 4E120C22
	.long 0xd44b0006                                           // 0000003EB090: D44B0006
	v_cndmask_b32_e32 v1, s34, v6, vcc_lo                      // 0000003EB094: 02020C22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003EB098: BF870191
	v_cndmask_b32_e64 v5, v5, v8, s6                           // 0000003EB09C: D5010005 001A1105
	v_cndmask_b32_e64 v6, v6, v9, s6                           // 0000003EB0A4: D5010006 001A1306
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003EB0AC: BF870112
	v_add_nc_u32_e32 v8, 1, v5                                 // 0000003EB0B0: 4A100A81
	.long 0xd44b0006                                           // 0000003EB0B4: D44B0006
	v_cndmask_b32_e32 v1, s34, v6, vcc_lo                      // 0000003EB0B8: 02020C22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003EB0BC: BF870091
	v_cndmask_b32_e64 v5, v5, v8, s6                           // 0000003EB0C0: D5010005 001A1105
	v_xor_b32_e32 v10, s38, v5                                 // 0000003EB0C8: 3A140A26
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003EB0CC: BF870121
	v_subrev_nc_u32_e32 v11, s38, v10                          // 0000003EB0D0: 4E161426
	.long 0xd72c000a                                           // 0000003EB0D4: D72C000A
	v_cndmask_b32_e32 v1, 0x1400, v10, vcc_lo                  // 0000003EB0D8: 020214FF 00001400
	v_min_i32_e32 v8, s35, v11                                 // 0000003EB0E0: 22101623
	v_mad_u64_u32 v[5:6], null, s40, v11, v[1:2]               // 0000003EB0E4: D6FE7C05 04061628
	.long 0xd72c000b                                           // 0000003EB0EC: D72C000B
	v_cndmask_b32_e32 v1, s39, v11, vcc_lo                     // 0000003EB0F0: 02021627
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003EB0F4: BF870193
	v_mad_i64_i32 v[8:9], null, v8, s36, 0                     // 0000003EB0F8: D6FF7C08 02004908
	v_ashrrev_i32_e32 v6, 31, v5                               // 0000003EB100: 340C0A9F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003EB104: BF870193
	v_sub_nc_u32_e32 v10, v10, v11                             // 0000003EB108: 4C14170A
	.long 0xd73c0008                                           // 0000003EB10C: D73C0008
	v_cndmask_b32_e32 v1, 1, v8, vcc_lo                        // 0000003EB110: 02021081
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003EB114: BF870193
	.long 0xd73c0005                                           // 0000003EB118: D73C0005
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 0000003EB11C: 02020A81
	v_add_nc_u32_e32 v10, v2, v10                              // 0000003EB120: 4A141502
	v_add_nc_u32_e32 v2, 0x800, v2                             // 0000003EB124: 4A0404FF 00000800
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003EB12C: BF870094
	.long 0xd700060c                                           // 0000003EB130: D700060C
	v_cndmask_b32_e32 v1, s16, v8, vcc_lo                      // 0000003EB134: 02021010
	v_add_co_ci_u32_e64 v13, null, s17, v9, s6                 // 0000003EB138: D5207C0D 001A1211
	s_waitcnt lgkmcnt(0)                                       // 0000003EB140: BF89FC07
	.long 0xd7000608                                           // 0000003EB144: D7000608
	v_cndmask_b32_e32 v1, s10, v5, vcc_lo                      // 0000003EB148: 02020A0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003EB14C: BF8700A1
	v_add_co_ci_u32_e64 v9, null, s11, v6, s6                  // 0000003EB150: D5207C09 001A0C0B
	.long 0xd7000605                                           // 0000003EB158: D7000605
	v_cndmask_b32_e32 v1, v12, v5, vcc_lo                      // 0000003EB15C: 02020B0C
	v_add_co_ci_u32_e64 v6, null, v13, v6, s6                  // 0000003EB160: D5207C06 001A0D0D
	global_load_b64 v[5:6], v[5:6], off                        // 0000003EB168: DC560000 057C0005
	global_load_b64 v[8:9], v[8:9], off                        // 0000003EB170: DC560000 087C0008
	s_waitcnt vmcnt(1)                                         // 0000003EB178: BF8907F7
	.long 0x7e1a3906                                           // 0000003EB17C: 7E1A3906
	v_and_b32_e32 v6, 0xffff0000, v6                           // 0000003EB180: 360C0CFF FFFF0000
	.long 0x7e183905                                           // 0000003EB188: 7E183905
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003EB18C: BF8701A3
	v_lshlrev_b32_e32 v13, 16, v13                             // 0000003EB190: 301A1A90
	s_waitcnt vmcnt(0)                                         // 0000003EB194: BF8903F7
	v_fma_mix_f32 v6, v9, v6, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 0000003EB198: CC200806 8A020D09
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003EB1A0: BF870113
	v_lshlrev_b32_e32 v12, 16, v12                             // 0000003EB1A4: 30181890
	v_fma_mix_f32 v14, v9, v13, v6 op_sel_hi:[1,0,0]           // 0000003EB1A8: CC20000E 0C1A1B09
	v_and_b32_e32 v5, 0xffff0000, v5                           // 0000003EB1B0: 360A0AFF FFFF0000
	v_fma_mix_f32 v6, v9, v13, -v6 op_sel_hi:[1,0,0]           // 0000003EB1B8: CC200006 8C1A1B09
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003EB1C0: BF870092
	v_fma_mix_f32 v5, v8, v5, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 0000003EB1C4: CC200805 8A020B08
	v_fma_mix_f32 v15, v8, v12, v5 op_sel_hi:[1,0,0]           // 0000003EB1CC: CC20000F 0C161908
	v_add_nc_u32_e32 v1, 0x400, v1                             // 0000003EB1D4: 4A0202FF 00000400
	v_fma_mix_f32 v5, v8, v12, -v5 op_sel_hi:[1,0,0]           // 0000003EB1DC: CC200005 8C161908
	v_add_nc_u32_e32 v4, 8, v4                                 // 0000003EB1E4: 4A080888
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003EB1E8: BF870194
	v_add_f32_e32 v8, v15, v14                                 // 0000003EB1EC: 06101D0F
	v_dual_sub_f32 v12, v15, v14 :: v_dual_add_f32 v9, v6, v5  // 0000003EB1F0: C9481D0F 0C080B06
	v_sub_f32_e32 v5, v5, v6                                   // 0000003EB1F8: 080A0D05
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003EB1FC: BF870214
	.long 0xd4430006                                           // 0000003EB200: D4430006
	v_cndmask_b32_e32 v1, s22, v4, vcc_lo                      // 0000003EB204: 02020816
	v_mov_b32_dpp v6, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003EB208: 7E0C02FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 0000003EB210: D5010008 200A1108
	v_mov_b32_dpp v14, v12 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003EB218: 7E1C02FA FF01610C
	v_mov_b32_dpp v15, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003EB220: 7E1E02FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, s2                          // 0000003EB228: D5010005 200A0B05
	v_cndmask_b32_e64 v12, -v12, v12, s2                       // 0000003EB230: D501000C 200A190C
	v_add_f32_e32 v6, v8, v6                                   // 0000003EB238: 060C0D08
	v_mov_b32_dpp v13, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003EB23C: 7E1A02FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s2                          // 0000003EB244: D5010009 200A1309
	v_add_f32_e32 v5, v5, v15                                  // 0000003EB24C: 060A1F05
	s_or_b32 s37, s6, s37                                      // 0000003EB250: 8C252506
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003EB254: BF870112
	v_dual_add_f32 v8, v9, v13 :: v_dual_add_f32 v9, v12, v14  // 0000003EB258: C9081B09 08081D0C
	v_mov_b32_dpp v15, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003EB260: 7E1E02FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 0000003EB268: D5010005 200E0B05
	v_mov_b32_dpp v12, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003EB270: 7E1802FA FF016206
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003EB278: BF870004
	v_mov_b32_dpp v13, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003EB27C: 7E1A02FA FF016208
	v_mov_b32_dpp v14, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003EB284: 7E1C02FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 0000003EB28C: D5010009 200E1309
	v_cndmask_b32_e64 v6, -v6, v6, s3                          // 0000003EB294: D5010006 200E0D06
	v_cndmask_b32_e64 v8, -v8, v8, s3                          // 0000003EB29C: D5010008 200E1108
	v_add_f32_e32 v5, v5, v15                                  // 0000003EB2A4: 060A1F05
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003EB2A8: BF870114
	v_add_f32_e32 v9, v9, v14                                  // 0000003EB2AC: 06121D09
	v_mov_b32_dpp v15, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003EB2B0: 7E1E02FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s4                          // 0000003EB2B8: D5010005 20120B05
	v_add_f32_e32 v6, v6, v12                                  // 0000003EB2C0: 060C1906
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000003EB2C4: BF870224
	v_mov_b32_dpp v14, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003EB2C8: 7E1C02FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s4                          // 0000003EB2D0: D5010009 20121309
	v_dual_add_f32 v8, v8, v13 :: v_dual_add_f32 v5, v5, v15   // 0000003EB2D8: C9081B08 08041F05
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000003EB2E0: BF870224
	v_mov_b32_dpp v12, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003EB2E4: 7E1802FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s4                          // 0000003EB2EC: D5010006 20120D06
	v_add_f32_e32 v9, v9, v14                                  // 0000003EB2F4: 06121D09
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003EB2F8: BF870004
	v_mov_b32_dpp v13, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003EB2FC: 7E1A02FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, s4                          // 0000003EB304: D5010008 20121108
	v_mov_b32_dpp v15, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003EB30C: 7E1E02FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s5                          // 0000003EB314: D5010005 20160B05
	v_add_f32_e32 v6, v6, v12                                  // 0000003EB31C: 060C1906
	v_mov_b32_dpp v14, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003EB320: 7E1C02FA FF016809
	v_cndmask_b32_e64 v9, -v9, v9, s5                          // 0000003EB328: D5010009 20161309
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003EB330: BF870214
	v_dual_add_f32 v8, v8, v13 :: v_dual_add_f32 v5, v5, v15   // 0000003EB334: C9081B08 08041F05
	v_mov_b32_dpp v12, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003EB33C: 7E1802FA FF016806
	v_cndmask_b32_e64 v6, -v6, v6, s5                          // 0000003EB344: D5010006 20160D06
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003EB34C: BF870214
	v_add_f32_e32 v9, v9, v14                                  // 0000003EB350: 06121D09
	v_mov_b32_dpp v13, v8 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003EB354: 7E1A02FA FF016808
	v_cndmask_b32_e64 v8, -v8, v8, s5                          // 0000003EB35C: D5010008 20161108
	v_mov_b32_e32 v15, v5                                      // 0000003EB364: 7E1E0305
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 0000003EB368: D5010005 21AA0B05
	v_mov_b32_e32 v14, v9                                      // 0000003EB370: 7E1C0309
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 0000003EB374: D5010009 21AA1309
	v_add_f32_e32 v8, v8, v13                                  // 0000003EB37C: 06101B08
	v_add_f32_e32 v6, v6, v12                                  // 0000003EB380: 060C1906
	v_permlanex16_b32 v15, v15, s41, 0xfedcba98                // 0000003EB384: D65C000F 03FC530F FEDCBA98
	v_permlanex16_b32 v14, v14, s41, 0xfedcba98                // 0000003EB390: D65C000E 03FC530E FEDCBA98
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003EB39C: BF870193
	v_dual_mov_b32 v13, v8 :: v_dual_mov_b32 v12, v6           // 0000003EB3A0: CA100108 0D0C0106
	v_add_f32_e32 v11, v5, v15                                 // 0000003EB3A8: 06161F05
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 0000003EB3AC: D5010008 21AA1108
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 0000003EB3B4: D5010006 21AA0D06
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003EB3BC: BF870124
	v_permlanex16_b32 v13, v13, s41, 0xfedcba98                // 0000003EB3C0: D65C000D 03FC530D FEDCBA98
	v_permlanex16_b32 v12, v12, s41, 0xfedcba98                // 0000003EB3CC: D65C000C 03FC530C FEDCBA98
	v_dual_add_f32 v9, v9, v14 :: v_dual_add_f32 v8, v8, v13   // 0000003EB3D8: C9081D09 09081B08
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003EB3E0: BF870112
	v_add_f32_e32 v6, v6, v12                                  // 0000003EB3E4: 060C1906
	v_fma_mixhi_f16 v5, v8, s42, 0                             // 0000003EB3E8: CC220005 02005508
	s_delay_alu instid0(VALU_DEP_2)                            // 0000003EB3F0: BF870002
	v_fma_mixlo_f16 v5, v6, s42, 0                             // 0000003EB3F4: CC210005 02005506
	v_fma_mixhi_f16 v6, v11, s42, 0                            // 0000003EB3FC: CC220006 0200550B
	v_fma_mixlo_f16 v6, v9, s42, 0                             // 0000003EB404: CC210006 02005509
	ds_store_b64 v10, v[5:6]                                   // 0000003EB40C: D9340000 0000050A
	s_and_not1_b32 exec_lo, exec_lo, s37                       // 0000003EB414: 917E257E
	s_cbranch_execnz 65300                                     // 0000003EB418: BFA6FF14 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x66c>
	s_or_b32 exec_lo, exec_lo, s37                             // 0000003EB41C: 8C7E257E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003EB420: BF870009
	s_or_b32 exec_lo, exec_lo, s33                             // 0000003EB424: 8C7E217E
	s_bfe_i32 s6, s7, 0x1001c                                  // 0000003EB428: 9386FF07 0001001C
	v_mad_u32_u24 v8, v41, 24, 0x2f0                           // 0000003EB430: D60B0008 03FD3129 000002F0
	s_lshr_b64 s[2:3], s[6:7], 29                              // 0000003EB43C: 85829D06
	s_lshr_b32 s3, s29, 28                                     // 0000003EB440: 85039C1D
	s_add_i32 s2, s2, 7                                        // 0000003EB444: 81028702
	s_add_i32 s3, s19, s3                                      // 0000003EB448: 81030313
	s_ashr_i32 s2, s2, 3                                       // 0000003EB44C: 86028302
	v_lshrrev_b32_e32 v1, 5, v8                                // 0000003EB450: 32021085
	.long 0xd72c000c                                           // 0000003EB454: D72C000C
	v_cndmask_b32_e32 v1, s2, v40, vcc_lo                      // 0000003EB458: 02025002
	s_ashr_i32 s3, s3, 4                                       // 0000003EB45C: 86038403
	s_lshl_b32 s4, s7, 3                                       // 0000003EB460: 84048307
	s_lshl_b32 s5, s27, 3                                      // 0000003EB464: 8405831B
	s_mul_hi_i32 s7, s26, s3                                   // 0000003EB468: 9707031A
	s_mul_i32 s3, s26, s3                                      // 0000003EB46C: 9603031A
	s_ashr_i32 s6, s5, 31                                      // 0000003EB470: 86069F05
	v_cmp_eq_u32_e32 vcc_lo, 0, v41                            // 0000003EB474: 7C945280
	v_add_nc_u32_e32 v2, s2, v12                               // 0000003EB478: 4A041802
	s_add_u32 s2, s3, s5                                       // 0000003EB47C: 80020503
	s_addc_u32 s3, s7, s6                                      // 0000003EB480: 82030607
	s_mul_i32 s5, s2, 0x300                                    // 0000003EB484: 9605FF02 00000300
	s_mulk_i32 s3, 0x300                                       // 0000003EB48C: B8030300
	v_min_i32_e32 v42, s4, v2                                  // 0000003EB490: 22540404
	v_subrev_nc_u32_e32 v2, 24, v1                             // 0000003EB494: 4E040298
	v_add_nc_u32_e32 v1, 1, v12                                // 0000003EB498: 4A021881
	s_mul_hi_u32 s4, s2, 0x300                                 // 0000003EB49C: 9684FF02 00000300
	v_add_nc_u32_e32 v13, 8, v8                                // 0000003EB4A4: 4A1A1088
	s_add_i32 s3, s4, s3                                       // 0000003EB4A8: 81030304
	v_cndmask_b32_e64 v10, v2, 23, vcc_lo                      // 0000003EB4AC: D501000A 01A92F02
	.long 0xd4410002                                           // 0000003EB4B4: D4410002
	v_cndmask_b32_e32 v1, v1, v42, vcc_lo                      // 0000003EB4B8: 02025501
	s_waitcnt lgkmcnt(0)                                       // 0000003EB4BC: BF89FC07
	s_add_u32 s4, s8, s5                                       // 0000003EB4C0: 80040508
	s_addc_u32 s5, s9, s3                                      // 0000003EB4C4: 82050309
	s_waitcnt_vscnt null, 0x0                                  // 0000003EB4C8: BC7C0000
	s_barrier                                                  // 0000003EB4CC: BFBD0000
	buffer_gl0_inv                                             // 0000003EB4D0: E0AC0000 00000000
	s_and_saveexec_b32 s3, s2                                  // 0000003EB4D8: BE832002
	s_cbranch_execz 123                                        // 0000003EB4DC: BFA5007B <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0xccc>
	v_lshrrev_b32_e32 v2, 5, v13                               // 0000003EB4E0: 32041A85
	.long 0xd4440002                                           // 0000003EB4E4: D4440002
	v_cndmask_b32_e32 v1, 23, v10, vcc_lo                      // 0000003EB4E8: 02021497
	v_mad_i64_i32 v[4:5], null, 0x300, v1, s[4:5]              // 0000003EB4EC: D6FF7C04 001202FF 00000300
	v_mov_b32_e32 v11, 0                                       // 0000003EB4F8: 7E160280
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003EB4FC: BF870214
	v_subrev_nc_u32_e32 v2, 24, v2                             // 0000003EB500: 4E040498
	v_cndmask_b32_e64 v3, 0xe9, 1, s2                          // 0000003EB504: D5010003 000902FF 000000E9
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003EB510: BF870193
	.long 0xd73c000e                                           // 0000003EB514: D73C000E
	v_cndmask_b32_e32 v1, 2, v10, vcc_lo                       // 0000003EB518: 02021482
	v_cndmask_b32_e64 v2, v2, 23, vcc_lo                       // 0000003EB51C: D5010002 01A92F02
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003EB524: BF8701A3
	v_add_nc_u32_e32 v6, v3, v10                               // 0000003EB528: 4A0C1503
	v_mov_b32_e32 v3, v11                                      // 0000003EB52C: 7E06030B
	.long 0xd4440002                                           // 0000003EB530: D4440002
	v_cndmask_b32_e32 v1, 23, v2, vcc_lo                       // 0000003EB534: 02020497
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003EB538: BF8701A3
	v_lshlrev_b32_e32 v1, 24, v6                               // 0000003EB53C: 30020C98
	v_bfe_i32 v6, v6, 7, 1                                     // 0000003EB540: D6110006 02050F06
	v_cndmask_b32_e64 v9, 0xe9, 1, s2                          // 0000003EB548: D5010009 000902FF 000000E9
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003EB554: BF8700A3
	v_ashrrev_i32_e32 v11, 22, v1                              // 0000003EB558: 34160296
	.long 0xd700020e                                           // 0000003EB55C: D700020E
	v_cndmask_b32_e32 v1, v4, v14, vcc_lo                      // 0000003EB560: 02021D04
	v_add_co_ci_u32_e64 v15, null, v5, v15, s2                 // 0000003EB564: D5207C0F 000A1F05
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000003EB56C: BF8700B4
	v_add_nc_u32_e32 v9, v9, v2                                // 0000003EB570: 4A120509
	.long 0xd73c0001                                           // 0000003EB574: D73C0001
	v_cndmask_b32_e32 v1, 2, v2, vcc_lo                        // 0000003EB578: 02020482
	.long 0xd7000210                                           // 0000003EB57C: D7000210
	v_cndmask_b32_e32 v1, v4, v11, vcc_lo                      // 0000003EB580: 02021704
	v_add_co_ci_u32_e64 v17, null, v5, v6, s2                  // 0000003EB584: D5207C11 000A0D05
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000003EB58C: BF8700B4
	v_lshlrev_b32_e32 v3, 24, v9                               // 0000003EB590: 30061298
	v_bfe_i32 v6, v9, 7, 1                                     // 0000003EB594: D6110006 02050F09
	.long 0xd7000201                                           // 0000003EB59C: D7000201
	v_cndmask_b32_e32 v1, v4, v1, vcc_lo                       // 0000003EB5A0: 02020304
	v_add_co_ci_u32_e64 v2, null, v5, v2, s2                   // 0000003EB5A4: D5207C02 000A0505
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003EB5AC: BF870094
	v_ashrrev_i32_e32 v3, 22, v3                               // 0000003EB5B0: 34060696
	.long 0xd7000203                                           // 0000003EB5B4: D7000203
	v_cndmask_b32_e32 v1, v4, v3, vcc_lo                       // 0000003EB5B8: 02020704
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003EB5BC: BF870001
	v_add_co_ci_u32_e64 v4, null, v5, v6, s2                   // 0000003EB5C0: D5207C04 000A0D05
	s_clause 0x1f                                              // 0000003EB5C8: BF85001F
	global_load_b32 v48, v[14:15], off                         // 0000003EB5CC: DC520000 307C000E
	global_load_b32 v47, v[14:15], off offset:96               // 0000003EB5D4: DC520060 2F7C000E
	global_load_b32 v46, v[14:15], off offset:192              // 0000003EB5DC: DC5200C0 2E7C000E
	global_load_b32 v45, v[14:15], off offset:288              // 0000003EB5E4: DC520120 2D7C000E
	global_load_b32 v44, v[14:15], off offset:384              // 0000003EB5EC: DC520180 2C7C000E
	global_load_b32 v43, v[14:15], off offset:480              // 0000003EB5F4: DC5201E0 2B7C000E
	global_load_b32 v49, v[14:15], off offset:576              // 0000003EB5FC: DC520240 317C000E
	global_load_b32 v51, v[14:15], off offset:672              // 0000003EB604: DC5202A0 337C000E
	global_load_b32 v60, v[16:17], off                         // 0000003EB60C: DC520000 3C7C0010
	global_load_b32 v57, v[16:17], off offset:96               // 0000003EB614: DC520060 397C0010
	global_load_b32 v55, v[16:17], off offset:192              // 0000003EB61C: DC5200C0 377C0010
	global_load_b32 v53, v[16:17], off offset:288              // 0000003EB624: DC520120 357C0010
	global_load_b32 v52, v[16:17], off offset:384              // 0000003EB62C: DC520180 347C0010
	global_load_b32 v50, v[16:17], off offset:480              // 0000003EB634: DC5201E0 327C0010
	global_load_b32 v65, v[16:17], off offset:576              // 0000003EB63C: DC520240 417C0010
	global_load_b32 v63, v[16:17], off offset:672              // 0000003EB644: DC5202A0 3F7C0010
	global_load_b32 v67, v[1:2], off                           // 0000003EB64C: DC520000 437C0001
	global_load_b32 v64, v[1:2], off offset:96                 // 0000003EB654: DC520060 407C0001
	global_load_b32 v61, v[1:2], off offset:192                // 0000003EB65C: DC5200C0 3D7C0001
	global_load_b32 v58, v[1:2], off offset:288                // 0000003EB664: DC520120 3A7C0001
	global_load_b32 v56, v[1:2], off offset:384                // 0000003EB66C: DC520180 387C0001
	global_load_b32 v54, v[1:2], off offset:480                // 0000003EB674: DC5201E0 367C0001
	global_load_b32 v72, v[1:2], off offset:576                // 0000003EB67C: DC520240 487C0001
	global_load_b32 v71, v[1:2], off offset:672                // 0000003EB684: DC5202A0 477C0001
	global_load_b32 v70, v[3:4], off                           // 0000003EB68C: DC520000 467C0003
	global_load_b32 v69, v[3:4], off offset:96                 // 0000003EB694: DC520060 457C0003
	global_load_b32 v68, v[3:4], off offset:192                // 0000003EB69C: DC5200C0 447C0003
	global_load_b32 v66, v[3:4], off offset:288                // 0000003EB6A4: DC520120 427C0003
	global_load_b32 v62, v[3:4], off offset:384                // 0000003EB6AC: DC520180 3E7C0003
	global_load_b32 v59, v[3:4], off offset:480                // 0000003EB6B4: DC5201E0 3B7C0003
	global_load_b32 v74, v[3:4], off offset:576                // 0000003EB6BC: DC520240 4A7C0003
	global_load_b32 v73, v[3:4], off offset:672                // 0000003EB6C4: DC5202A0 497C0003
	s_or_b32 exec_lo, exec_lo, s3                              // 0000003EB6CC: 8C7E037E
	.long 0xd4410002                                           // 0000003EB6D0: D4410002
	v_cndmask_b32_e32 v1, v12, v42, vcc_lo                     // 0000003EB6D4: 0202550C
	s_and_saveexec_b32 s6, s2                                  // 0000003EB6D8: BE862002
	s_cbranch_execz 121                                        // 0000003EB6DC: BFA50079 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0xec4>
	v_lshrrev_b32_e32 v1, 5, v13                               // 0000003EB6E0: 32021A85
	.long 0xd4440003                                           // 0000003EB6E4: D4440003
	v_cndmask_b32_e32 v1, 23, v10, vcc_lo                      // 0000003EB6E8: 02021497
	v_mov_b32_e32 v11, 0                                       // 0000003EB6EC: 7E160280
	v_mad_i64_i32 v[3:4], null, 0x300, v12, s[4:5]             // 0000003EB6F0: D6FF7C03 001218FF 00000300
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003EB6FC: BF870214
	v_subrev_nc_u32_e32 v1, 24, v1                             // 0000003EB700: 4E020298
	v_cndmask_b32_e64 v2, 0xe9, 1, s3                          // 0000003EB704: D5010002 000D02FF 000000E9
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003EB710: BF870112
	v_cndmask_b32_e64 v1, v1, 23, vcc_lo                       // 0000003EB714: D5010001 01A92F01
	v_dual_mov_b32 v2, v11 :: v_dual_add_nc_u32 v9, v2, v10    // 0000003EB71C: CA20010B 02081502
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003EB724: BF870112
	.long 0xd4440003                                           // 0000003EB728: D4440003
	v_cndmask_b32_e32 v1, 23, v1, vcc_lo                       // 0000003EB72C: 02020297
	v_lshlrev_b32_e32 v14, 24, v9                              // 0000003EB730: 301C1298
	.long 0xd73c0005                                           // 0000003EB734: D73C0005
	v_cndmask_b32_e32 v1, 2, v10, vcc_lo                       // 0000003EB738: 02021482
	v_bfe_i32 v9, v9, 7, 1                                     // 0000003EB73C: D6110009 02050F09
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003EB744: BF870214
	v_cndmask_b32_e64 v15, 0xe9, 1, s3                         // 0000003EB748: D501000F 000D02FF 000000E9
	v_ashrrev_i32_e32 v11, 22, v14                             // 0000003EB754: 34161C96
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003EB758: BF870194
	.long 0xd700030e                                           // 0000003EB75C: D700030E
	v_cndmask_b32_e32 v1, v3, v5, vcc_lo                       // 0000003EB760: 02020B03
	v_add_nc_u32_e32 v18, v15, v1                              // 0000003EB764: 4A24030F
	.long 0xd73c0001                                           // 0000003EB768: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000003EB76C: 02020282
	v_add_co_ci_u32_e64 v15, null, v4, v6, s3                  // 0000003EB770: D5207C0F 000E0D04
	.long 0xd7000310                                           // 0000003EB778: D7000310
	v_cndmask_b32_e32 v1, v3, v11, vcc_lo                      // 0000003EB77C: 02021703
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000003EB780: BF870244
	v_lshlrev_b32_e32 v5, 24, v18                              // 0000003EB784: 300A2498
	v_bfe_i32 v6, v18, 7, 1                                    // 0000003EB788: D6110006 02050F12
	v_add_co_ci_u32_e64 v17, null, v4, v9, s3                  // 0000003EB790: D5207C11 000E1304
	.long 0xd700034b                                           // 0000003EB798: D700034B
	v_cndmask_b32_e32 v1, v3, v1, vcc_lo                       // 0000003EB79C: 02020303
	v_ashrrev_i32_e32 v5, 22, v5                               // 0000003EB7A0: 340A0A96
	v_add_co_ci_u32_e64 v76, null, v4, v2, s3                  // 0000003EB7A4: D5207C4C 000E0504
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003EB7AC: BF870092
	.long 0xd700034d                                           // 0000003EB7B0: D700034D
	v_cndmask_b32_e32 v1, v3, v5, vcc_lo                       // 0000003EB7B4: 02020B03
	v_add_co_ci_u32_e64 v78, null, v4, v6, s3                  // 0000003EB7B8: D5207C4E 000E0D04
	s_clause 0x1f                                              // 0000003EB7C0: BF85001F
	global_load_b32 v2, v[14:15], off                          // 0000003EB7C4: DC520000 027C000E
	global_load_b32 v6, v[14:15], off offset:96                // 0000003EB7CC: DC520060 067C000E
	global_load_b32 v35, v[14:15], off offset:192              // 0000003EB7D4: DC5200C0 237C000E
	global_load_b32 v31, v[14:15], off offset:288              // 0000003EB7DC: DC520120 1F7C000E
	global_load_b32 v27, v[14:15], off offset:384              // 0000003EB7E4: DC520180 1B7C000E
	global_load_b32 v19, v[14:15], off offset:480              // 0000003EB7EC: DC5201E0 137C000E
	global_load_b32 v23, v[14:15], off offset:576              // 0000003EB7F4: DC520240 177C000E
	global_load_b32 v15, v[14:15], off offset:672              // 0000003EB7FC: DC5202A0 0F7C000E
	global_load_b32 v1, v[16:17], off                          // 0000003EB804: DC520000 017C0010
	global_load_b32 v5, v[16:17], off offset:96                // 0000003EB80C: DC520060 057C0010
	global_load_b32 v34, v[16:17], off offset:192              // 0000003EB814: DC5200C0 227C0010
	global_load_b32 v30, v[16:17], off offset:288              // 0000003EB81C: DC520120 1E7C0010
	global_load_b32 v26, v[16:17], off offset:384              // 0000003EB824: DC520180 1A7C0010
	global_load_b32 v18, v[16:17], off offset:480              // 0000003EB82C: DC5201E0 127C0010
	global_load_b32 v22, v[16:17], off offset:576              // 0000003EB834: DC520240 167C0010
	global_load_b32 v14, v[16:17], off offset:672              // 0000003EB83C: DC5202A0 0E7C0010
	global_load_b32 v4, v[75:76], off                          // 0000003EB844: DC520000 047C004B
	global_load_b32 v39, v[75:76], off offset:96               // 0000003EB84C: DC520060 277C004B
	global_load_b32 v37, v[75:76], off offset:192              // 0000003EB854: DC5200C0 257C004B
	global_load_b32 v33, v[75:76], off offset:288              // 0000003EB85C: DC520120 217C004B
	global_load_b32 v29, v[75:76], off offset:384              // 0000003EB864: DC520180 1D7C004B
	global_load_b32 v21, v[75:76], off offset:480              // 0000003EB86C: DC5201E0 157C004B
	global_load_b32 v25, v[75:76], off offset:576              // 0000003EB874: DC520240 197C004B
	global_load_b32 v17, v[75:76], off offset:672              // 0000003EB87C: DC5202A0 117C004B
	global_load_b32 v3, v[77:78], off                          // 0000003EB884: DC520000 037C004D
	global_load_b32 v38, v[77:78], off offset:96               // 0000003EB88C: DC520060 267C004D
	global_load_b32 v36, v[77:78], off offset:192              // 0000003EB894: DC5200C0 247C004D
	global_load_b32 v32, v[77:78], off offset:288              // 0000003EB89C: DC520120 207C004D
	global_load_b32 v28, v[77:78], off offset:384              // 0000003EB8A4: DC520180 1C7C004D
	global_load_b32 v20, v[77:78], off offset:480              // 0000003EB8AC: DC5201E0 147C004D
	global_load_b32 v24, v[77:78], off offset:576              // 0000003EB8B4: DC520240 187C004D
	global_load_b32 v16, v[77:78], off offset:672              // 0000003EB8BC: DC5202A0 107C004D
	s_or_b32 exec_lo, exec_lo, s6                              // 0000003EB8C4: 8C7E067E
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v76, 0              // 0000003EB8C8: CA100080 094C0080
	v_dual_mov_b32 v77, 0 :: v_dual_mov_b32 v78, 0             // 0000003EB8D0: CA100080 4D4E0080
	v_dual_mov_b32 v79, 0 :: v_dual_mov_b32 v82, 0             // 0000003EB8D8: CA100080 4F520080
	v_dual_mov_b32 v83, 0 :: v_dual_mov_b32 v84, 0             // 0000003EB8E0: CA100080 53540080
	v_dual_mov_b32 v75, 0 :: v_dual_mov_b32 v80, 0             // 0000003EB8E8: CA100080 4B500080
	v_dual_mov_b32 v81, 0 :: v_dual_mov_b32 v86, 0             // 0000003EB8F0: CA100080 51560080
	v_dual_mov_b32 v85, 0 :: v_dual_mov_b32 v88, 0             // 0000003EB8F8: CA100080 55580080
	v_mov_b32_e32 v87, 0                                       // 0000003EB900: 7EAE0280
	v_mov_b32_e32 v89, 0                                       // 0000003EB904: 7EB20280
	s_ashr_i32 s27, s26, 31                                    // 0000003EB908: 861B9F1A
	s_and_saveexec_b32 s3, s2                                  // 0000003EB90C: BE832002
	s_cbranch_execz 1110                                       // 0000003EB910: BFA50456 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x206c>
	v_lshrrev_b32_e32 v9, 5, v13                               // 0000003EB914: 32121A85
	v_or_b32_e32 v76, 4, v7                                    // 0000003EB918: 38980E84
	.long 0xd4440002                                           // 0000003EB91C: D4440002
	v_cndmask_b32_e32 v1, 23, v10, vcc_lo                      // 0000003EB920: 02021497
	v_mul_i32_i24_e32 v13, 0xffffffe8, v41                     // 0000003EB924: 121A52FF FFFFFFE8
	v_ashrrev_i32_e32 v11, 31, v10                             // 0000003EB92C: 3416149F
	v_subrev_nc_u32_e32 v7, 24, v9                             // 0000003EB930: 4E0E1298
	v_dual_mov_b32 v9, 0 :: v_dual_and_b32 v78, 16, v0         // 0000003EB934: CA240080 094E0090
	v_and_b32_e32 v75, 0x7e0, v8                               // 0000003EB93C: 369610FF 000007E0
	v_cndmask_b32_e64 v77, 0xe9, 1, s2                         // 0000003EB944: D501004D 000902FF 000000E9
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003EB950: BF870004
	v_cndmask_b32_e64 v8, v7, 23, vcc_lo                       // 0000003EB954: D5010008 01A92F07
	v_add_nc_u32_e32 v91, 2, v12                               // 0000003EB95C: 4AB61882
	v_mul_i32_i24_e32 v86, -3, v76                             // 0000003EB960: 12AC98C3
	v_add3_u32 v92, v13, v75, 0xfffffd34                       // 0000003EB964: D655005C 03FE970D FFFFFD34
	v_mad_u32_u24 v13, v76, 3, 0x2f0                           // 0000003EB970: D60B000D 03FD074C 000002F0
	.long 0xd7030007                                           // 0000003EB97C: D7030007
	v_cndmask_b32_e32 v0, v8, v129, vcc_lo                     // 0000003EB980: 02010308
	v_add_nc_u32_e32 v81, v77, v10                             // 0000003EB984: 4AA2154D
	v_lshl_or_b32 v93, v12, 5, v78                             // 0000003EB988: D656005D 05390B0C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003EB990: BF870214
	v_dual_mov_b32 v77, v9 :: v_dual_and_b32 v12, 0x7e0, v13   // 0000003EB994: CA240109 4D0C1AFF 000007E0
	.long 0xd7624007                                           // 0000003EB9A0: D7624007
	v_cndmask_b32_e32 v1, 0xff, v7, vcc_lo                     // 0000003EB9A4: 02020EFF 000000FF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000003EB9AC: BF870234
	v_dual_mov_b32 v82, v9 :: v_dual_and_b32 v13, 0xff, v81    // 0000003EB9B0: CA240109 520CA2FF 000000FF
	.long 0xd73c000a                                           // 0000003EB9BC: D73C000A
	v_cndmask_b32_e32 v1, 2, v10, vcc_lo                       // 0000003EB9C0: 02021482
	v_mov_b32_e32 v80, v9                                      // 0000003EB9C4: 7EA00309
	v_cmp_ne_u16_e32 vcc_lo, 24, v135/*Invalid register, operand has 'VGPR_32_Lo128' register class*/// 0000003EB9C8: 7C7B0E98
	v_add3_u32 v94, v86, v12, 0xfffffd34                       // 0000003EB9CC: D655005E 03FE1956 FFFFFD34
	v_lshlrev_b32_e32 v95, 2, v13                              // 0000003EB9D8: 30BE1A82
	.long 0xd73c000c                                           // 0000003EB9DC: D73C000C
	v_cndmask_b32_e32 v1, 2, v8, vcc_lo                        // 0000003EB9E0: 02021082
	v_sub_nc_u32_e32 v90, 0, v42                               // 0000003EB9E4: 4CB45480
	v_cndmask_b16 v7, 0, v7, vcc_lo                            // 0000003EB9E8: D65D0007 01AA0E80
	v_mov_b32_e32 v84, v9                                      // 0000003EB9F0: 7EA80309
	v_mov_b32_e32 v76, v9                                      // 0000003EB9F4: 7E980309
	v_mov_b32_e32 v78, v9                                      // 0000003EB9F8: 7E9C0309
	v_mov_b32_e32 v83, v9                                      // 0000003EB9FC: 7EA60309
	v_and_b32_e32 v7, 0xff, v7                                 // 0000003EBA00: 360E0EFF 000000FF
	v_mov_b32_e32 v79, v9                                      // 0000003EBA08: 7E9E0309
	v_mov_b32_e32 v75, v9                                      // 0000003EBA0C: 7E960309
	v_mov_b32_e32 v81, v9                                      // 0000003EBA10: 7EA20309
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003EBA14: BF870004
	v_dual_mov_b32 v85, v9 :: v_dual_lshlrev_b32 v96, 2, v7    // 0000003EBA18: CA220109 55600E82
	v_mov_b32_e32 v86, v9                                      // 0000003EBA20: 7EAC0309
	v_mov_b32_e32 v88, v9                                      // 0000003EBA24: 7EB00309
	v_mov_b32_e32 v87, v9                                      // 0000003EBA28: 7EAE0309
	v_mov_b32_e32 v89, v9                                      // 0000003EBA2C: 7EB20309
	s_mov_b32 s2, 0                                            // 0000003EBA30: BE820080
	s_movk_i32 s6, 0x1eee                                      // 0000003EBA34: B0061EEE
	s_branch 933                                               // 0000003EBA38: BFA003A5 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1ed0>
	s_or_b32 exec_lo, exec_lo, s7                              // 0000003EBA3C: 8C7E077E
	.long 0xd73d0081                                           // 0000003EBA40: D73D0081
	v_cndmask_b32_e32 v1, v94, v3, vcc_lo                      // 0000003EBA44: 0202075E
	.long 0xd73d0007                                           // 0000003EBA48: D73D0007
	v_cndmask_b32_e32 v1, v92, v1, vcc_lo                      // 0000003EBA4C: 0202035C
	ds_load_b128 v[1:4], v93                                   // 0000003EBA50: DBFC0000 0100005D
	.long 0xd73d0026                                           // 0000003EBA58: D73D0026
	v_cndmask_b32_e32 v1, v94, v38, vcc_lo                     // 0000003EBA5C: 02024D5E
	.long 0xd73d0022                                           // 0000003EBA60: D73D0022
	v_cndmask_b32_e32 v1, v92, v34, vcc_lo                     // 0000003EBA64: 0202455C
	.long 0xd73d0023                                           // 0000003EBA68: D73D0023
	v_cndmask_b32_e32 v1, v94, v36, vcc_lo                     // 0000003EBA6C: 0202495E
	v_bfe_u32 v132, v129, 9, 16                                // 0000003EBA70: D6100084 02411381
	v_bfe_u32 v8, v7, 9, 16                                    // 0000003EBA78: D6100008 02411307
	v_bfe_u32 v133, v129, 6, 16                                // 0000003EBA80: D6100085 02410D81
	v_bfe_u32 v130, v7, 6, 16                                  // 0000003EBA88: D6100082 02410D07
	v_bfe_u32 v134, v129, 3, 16                                // 0000003EBA90: D6100086 02410781
	.long 0xd72c0084                                           // 0000003EBA98: D72C0084
	v_cndmask_b32_e32 v1, 0x83dcd12d, v132, vcc_lo             // 0000003EBA9C: 020308FF 83DCD12D
	v_and_b32_e32 v129, 0xffff, v129                           // 0000003EBAA4: 370302FF 0000FFFF
	.long 0xd72c0008                                           // 0000003EBAAC: D72C0008
	v_cndmask_b32_e32 v1, 0x83dcd12d, v8, vcc_lo               // 0000003EBAB0: 020210FF 83DCD12D
	.long 0xd72c0085                                           // 0000003EBAB8: D72C0085
	v_cndmask_b32_e32 v1, 0x83dcd12d, v133, vcc_lo             // 0000003EBABC: 02030AFF 83DCD12D
	.long 0xd72c0082                                           // 0000003EBAC4: D72C0082
	v_cndmask_b32_e32 v1, 0x83dcd12d, v130, vcc_lo             // 0000003EBAC8: 020304FF 83DCD12D
	.long 0xd72c0086                                           // 0000003EBAD0: D72C0086
	v_cndmask_b32_e32 v1, 0x83dcd12d, v134, vcc_lo             // 0000003EBAD4: 02030CFF 83DCD12D
	.long 0xd72c0081                                           // 0000003EBADC: D72C0081
	v_cndmask_b32_e32 v1, 0x83dcd12d, v129, vcc_lo             // 0000003EBAE0: 020302FF 83DCD12D
	v_bfe_u32 v131, v7, 3, 16                                  // 0000003EBAE8: D6100083 02410707
	v_sad_u8 v132, v132, 0, 0x6400                             // 0000003EBAF0: D6220084 03FD0184 00006400
	v_bfe_u32 v137, v38, 6, 16                                 // 0000003EBAFC: D6100089 02410D26
	v_sad_u8 v8, v8, 0, 0x6400                                 // 0000003EBB04: D6220008 03FD0108 00006400
	v_sad_u8 v133, v133, 0, 0x6400                             // 0000003EBB10: D6220085 03FD0185 00006400
	v_sad_u8 v130, v130, 0, 0x6400                             // 0000003EBB1C: D6220082 03FD0182 00006400
	v_and_b32_e32 v132, 0xffff, v132                           // 0000003EBB28: 370908FF 0000FFFF
	v_sad_u8 v129, v129, 0, 0x6400                             // 0000003EBB30: D6220081 03FD0181 00006400
	v_and_b32_e32 v8, 0xffff, v8                               // 0000003EBB3C: 361010FF 0000FFFF
	v_sad_u8 v134, v134, 0, 0x6400                             // 0000003EBB44: D6220086 03FD0186 00006400
	.long 0xd72c0083                                           // 0000003EBB50: D72C0083
	v_cndmask_b32_e32 v1, 0x83dcd12d, v131, vcc_lo             // 0000003EBB54: 020306FF 83DCD12D
	v_lshl_or_b32 v132, v133, 16, v132                         // 0000003EBB5C: D6560084 06112185
	.long 0xd72c0089                                           // 0000003EBB64: D72C0089
	v_cndmask_b32_e32 v1, 0x83dcd12d, v137, vcc_lo             // 0000003EBB68: 020312FF 83DCD12D
	v_lshl_or_b32 v135, v130, 16, v8                           // 0000003EBB70: D6560087 04212182
	v_bfe_u32 v138, v38, 3, 16                                 // 0000003EBB78: D610008A 02410726
	v_bfe_u32 v37, v34, 6, 16                                  // 0000003EBB80: D6100025 02410D22
	v_pk_fma_f16 v132, v132, s6, 0xc931 op_sel_hi:[1,0,0]      // 0000003EBB88: CC0E0084 0BFC0D84 0000C931
	v_lshlrev_b32_e32 v136, 16, v129                           // 0000003EBB94: 31110290
	.long 0xd73d0081                                           // 0000003EBB98: D73D0081
	v_cndmask_b32_e32 v1, v92, v5, vcc_lo                      // 0000003EBB9C: 02020B5C
	v_pk_fma_f16 v133, v135, s6, 0xc931 op_sel_hi:[1,0,0]      // 0000003EBBA0: CC0E0085 0BFC0D87 0000C931
	v_sad_u8 v131, v131, 0, 0x6400                             // 0000003EBBAC: D6220083 03FD0183 00006400
	.long 0xd72c0025                                           // 0000003EBBB8: D72C0025
	v_cndmask_b32_e32 v1, 0x83dcd12d, v37, vcc_lo              // 0000003EBBBC: 02024AFF 83DCD12D
	v_and_or_b32 v130, 0xffff, v134, v136                      // 0000003EBBC4: D6570082 06230CFF 0000FFFF
	v_bfe_u32 v136, v38, 9, 16                                 // 0000003EBBD0: D6100088 02411326
	v_bfe_u32 v134, v129, 9, 16                                // 0000003EBBD8: D6100086 02411381
	v_and_b32_e32 v135, 0xffff, v129                           // 0000003EBBE0: 370F02FF 0000FFFF
	.long 0xd73d001e                                           // 0000003EBBE8: D73D001E
	v_cndmask_b32_e32 v1, v92, v30, vcc_lo                     // 0000003EBBEC: 02023D5C
	v_pk_fma_f16 v130, v130, s6, 0xc931 op_sel_hi:[1,0,0]      // 0000003EBBF0: CC0E0082 0BFC0D82 0000C931
	.long 0xd72c0088                                           // 0000003EBBFC: D72C0088
	v_cndmask_b32_e32 v1, 0x83dcd12d, v136, vcc_lo             // 0000003EBC00: 020310FF 83DCD12D
	.long 0xd72c0027                                           // 0000003EBC08: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v134, vcc_lo             // 0000003EBC0C: 02030CFF 83DCD12D
	v_bfe_u32 v134, v129, 6, 16                                // 0000003EBC14: D6100086 02410D81
	v_bfe_u32 v129, v129, 3, 16                                // 0000003EBC1C: D6100081 02410781
	.long 0xd72c0087                                           // 0000003EBC24: D72C0087
	v_cndmask_b32_e32 v1, 0x83dcd12d, v135, vcc_lo             // 0000003EBC28: 02030EFF 83DCD12D
	v_sad_u8 v37, v37, 0, 0x6400                               // 0000003EBC30: D6220025 03FD0125 00006400
	.long 0xd73d001a                                           // 0000003EBC3C: D73D001A
	v_cndmask_b32_e32 v1, v92, v26, vcc_lo                     // 0000003EBC40: 0202355C
	.long 0xd72c0086                                           // 0000003EBC44: D72C0086
	v_cndmask_b32_e32 v1, 0x83dcd12d, v134, vcc_lo             // 0000003EBC48: 02030CFF 83DCD12D
	.long 0xd72c0081                                           // 0000003EBC50: D72C0081
	v_cndmask_b32_e32 v1, 0x83dcd12d, v129, vcc_lo             // 0000003EBC54: 020302FF 83DCD12D
	v_sad_u8 v39, v39, 0, 0x6400                               // 0000003EBC5C: D6220027 03FD0127 00006400
	v_sad_u8 v136, v136, 0, 0x6400                             // 0000003EBC68: D6220088 03FD0188 00006400
	.long 0xd73d001b                                           // 0000003EBC74: D73D001B
	v_cndmask_b32_e32 v1, v94, v28, vcc_lo                     // 0000003EBC78: 0202395E
	v_sad_u8 v135, v135, 0, 0x6400                             // 0000003EBC7C: D6220087 03FD0187 00006400
	v_bfe_u32 v29, v26, 6, 16                                  // 0000003EBC88: D610001D 02410D1A
	v_and_b32_e32 v39, 0xffff, v39                             // 0000003EBC90: 364E4EFF 0000FFFF
	v_sad_u8 v134, v134, 0, 0x6400                             // 0000003EBC98: D6220086 03FD0186 00006400
	v_sad_u8 v129, v129, 0, 0x6400                             // 0000003EBCA4: D6220081 03FD0181 00006400
	.long 0xd73d0012                                           // 0000003EBCB0: D73D0012
	v_cndmask_b32_e32 v1, v92, v18, vcc_lo                     // 0000003EBCB4: 0202255C
	.long 0xd72c001d                                           // 0000003EBCB8: D72C001D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v29, vcc_lo              // 0000003EBCBC: 02023AFF 83DCD12D
	.long 0xd73d000e                                           // 0000003EBCC4: D73D000E
	v_cndmask_b32_e32 v1, v92, v14, vcc_lo                     // 0000003EBCC8: 02021D5C
	v_lshl_or_b32 v39, v134, 16, v39                           // 0000003EBCCC: D6560027 049D2186
	.long 0xd72c0086                                           // 0000003EBCD4: D72C0086
	v_cndmask_b32_e32 v1, 0x83dcd12d, v138, vcc_lo             // 0000003EBCD8: 020314FF 83DCD12D
	v_add_nc_u32_e32 v91, 1, v91                               // 0000003EBCE0: 4AB6B681
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000003EBCE4: BF870253
	v_pk_fma_f16 v39, v39, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003EBCE8: CC0E0027 0BFC0D27 0000C931
	v_and_b32_e32 v7, 0xffff, v7                               // 0000003EBCF4: 360E0EFF 0000FFFF
	v_lshlrev_b32_e32 v135, 16, v135                           // 0000003EBCFC: 310F0E90
	v_sad_u8 v29, v29, 0, 0x6400                               // 0000003EBD00: D622001D 03FD011D 00006400
	v_sad_u8 v134, v134, 0, 0x6400                             // 0000003EBD0C: D6220086 03FD0186 00006400
	.long 0xd72c0007                                           // 0000003EBD18: D72C0007
	v_cndmask_b32_e32 v1, 0x83dcd12d, v7, vcc_lo               // 0000003EBD1C: 02020EFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003EBD24: BF870094
	v_and_or_b32 v129, 0xffff, v129, v135                      // 0000003EBD28: D6570081 061F02FF 0000FFFF
	v_pk_fma_f16 v129, v129, s6, 0xc931 op_sel_hi:[1,0,0]      // 0000003EBD34: CC0E0081 0BFC0D81 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003EBD40: BF870093
	v_sad_u8 v7, v7, 0, 0x6400                                 // 0000003EBD44: D6220007 03FD0107 00006400
	v_lshlrev_b32_e32 v7, 16, v7                               // 0000003EBD50: 300E0E90
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003EBD54: BF870001
	v_and_or_b32 v131, 0xffff, v131, v7                        // 0000003EBD58: D6570083 041F06FF 0000FFFF
	ds_load_b128 v[5:8], v93 offset:5120                       // 0000003EBD64: DBFC1400 0500005D
	v_and_b32_e32 v38, 0xffff, v38                             // 0000003EBD6C: 364C4CFF 0000FFFF
	s_waitcnt lgkmcnt(1)                                       // 0000003EBD74: BF89FC17
	v_dot2acc_f32_f16 v88, v39, v1                             // 0000003EBD78: 04B00327
	v_dot2acc_f32_f16 v89, v133, v1                            // 0000003EBD7C: 04B20385
	v_pk_fma_f16 v131, v131, s6, 0xc931 op_sel_hi:[1,0,0]      // 0000003EBD80: CC0E0083 0BFC0D83 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003EBD8C: BF870113
	v_dual_dot2acc_f32_f16 v88, v129, v2 :: v_dual_add_nc_u32 v93, 32, v93// 0000003EBD90: CB200581 585CBAA0
	v_dot2acc_f32_f16 v89, v131, v2                            // 0000003EBD98: 04B20583
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003EBD9C: BF8700A1
	v_dot2acc_f32_f16 v89, v132, v3                            // 0000003EBDA0: 04B20784
	s_waitcnt lgkmcnt(0)                                       // 0000003EBDA4: BF89FC07
	v_dual_dot2acc_f32_f16 v89, v130, v4 :: v_dual_dot2acc_f32_f16 v86, v39, v5// 0000003EBDA8: CB180982 59560B27
	v_bfe_u32 v39, v34, 9, 16                                  // 0000003EBDB0: D6100027 02411322
	v_dot2acc_f32_f16 v87, v133, v5                            // 0000003EBDB8: 04AE0B85
	.long 0xd72c0026                                           // 0000003EBDBC: D72C0026
	v_cndmask_b32_e32 v1, 0x83dcd12d, v38, vcc_lo              // 0000003EBDC0: 02024CFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000003EBDC8: BF870254
	v_dual_dot2acc_f32_f16 v86, v129, v6 :: v_dual_and_b32 v135, 0xffff, v136// 0000003EBDCC: CB240D81 568710FF 0000FFFF
	v_sad_u8 v136, v137, 0, 0x6400                             // 0000003EBDD8: D6220088 03FD0189 00006400
	.long 0xd72c0024                                           // 0000003EBDE4: D72C0024
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 0000003EBDE8: 02024EFF 83DCD12D
	v_bfe_u32 v129, v35, 9, 16                                 // 0000003EBDF0: D6100081 02411323
	v_sad_u8 v38, v38, 0, 0x6400                               // 0000003EBDF8: D6220026 03FD0126 00006400
	v_lshl_or_b32 v133, v136, 16, v135                         // 0000003EBE04: D6560085 061D2188
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000003EBE0C: BF870233
	.long 0xd72c0081                                           // 0000003EBE10: D72C0081
	v_cndmask_b32_e32 v1, 0x83dcd12d, v129, vcc_lo             // 0000003EBE14: 020302FF 83DCD12D
	v_sad_u8 v36, v36, 0, 0x6400                               // 0000003EBE1C: D6220024 03FD0124 00006400
	v_dot2acc_f32_f16 v87, v131, v6                            // 0000003EBE28: 04AE0D83
	v_pk_fma_f16 v131, v133, s6, 0xc931 op_sel_hi:[1,0,0]      // 0000003EBE2C: CC0E0083 0BFC0D85 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003EBE38: BF870193
	v_and_b32_e32 v36, 0xffff, v36                             // 0000003EBE3C: 364848FF 0000FFFF
	v_dual_dot2acc_f32_f16 v87, v132, v7 :: v_dual_lshlrev_b32 v38, 16, v38// 0000003EBE44: CB220F84 57264C90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000003EBE4C: BF870233
	v_dot2acc_f32_f16 v88, v131, v3                            // 0000003EBE50: 04B00783
	v_dot2acc_f32_f16 v86, v131, v7                            // 0000003EBE54: 04AC0F83
	v_and_b32_e32 v131, 0xffff, v35                            // 0000003EBE58: 370646FF 0000FFFF
	v_and_or_b32 v38, 0xffff, v134, v38                        // 0000003EBE60: D6570026 049B0CFF 0000FFFF
	v_dot2acc_f32_f16 v87, v130, v8                            // 0000003EBE6C: 04AE1182
	v_bfe_u32 v130, v35, 6, 16                                 // 0000003EBE70: D6100082 02410D23
	v_bfe_u32 v35, v35, 3, 16                                  // 0000003EBE78: D6100023 02410723
	.long 0xd72c0083                                           // 0000003EBE80: D72C0083
	v_cndmask_b32_e32 v1, 0x83dcd12d, v131, vcc_lo             // 0000003EBE84: 020306FF 83DCD12D
	v_lshl_or_b32 v36, v37, 16, v36                            // 0000003EBE8C: D6560024 04912125
	v_pk_fma_f16 v38, v38, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003EBE94: CC0E0026 0BFC0D26 0000C931
	v_and_b32_e32 v39, 0xffff, v34                             // 0000003EBEA0: 364E44FF 0000FFFF
	.long 0xd72c0023                                           // 0000003EBEA8: D72C0023
	v_cndmask_b32_e32 v1, 0x83dcd12d, v35, vcc_lo              // 0000003EBEAC: 020246FF 83DCD12D
	v_bfe_u32 v34, v34, 3, 16                                  // 0000003EBEB4: D6100022 02410722
	.long 0xd72c0082                                           // 0000003EBEBC: D72C0082
	v_cndmask_b32_e32 v1, 0x83dcd12d, v130, vcc_lo             // 0000003EBEC0: 020304FF 83DCD12D
	v_dot2acc_f32_f16 v88, v38, v4                             // 0000003EBEC8: 04B00926
	v_sad_u8 v131, v131, 0, 0x6400                             // 0000003EBECC: D6220083 03FD0183 00006400
	v_dot2acc_f32_f16 v86, v38, v8                             // 0000003EBED8: 04AC1126
	.long 0xd72c0027                                           // 0000003EBEDC: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 0000003EBEE0: 02024EFF 83DCD12D
	.long 0xd72c0022                                           // 0000003EBEE8: D72C0022
	v_cndmask_b32_e32 v1, 0x83dcd12d, v34, vcc_lo              // 0000003EBEEC: 020244FF 83DCD12D
	v_sad_u8 v35, v35, 0, 0x6400                               // 0000003EBEF4: D6220023 03FD0123 00006400
	v_lshlrev_b32_e32 v37, 16, v131                            // 0000003EBF00: 304B0690
	v_sad_u8 v129, v129, 0, 0x6400                             // 0000003EBF04: D6220081 03FD0181 00006400
	v_sad_u8 v130, v130, 0, 0x6400                             // 0000003EBF10: D6220082 03FD0182 00006400
	s_delay_alu instid0(VALU_DEP_3)                            // 0000003EBF1C: BF870003
	v_and_or_b32 v31, 0xffff, v35, v37                         // 0000003EBF20: D657001F 049646FF 0000FFFF
	v_bfe_u32 v37, v30, 9, 16                                  // 0000003EBF2C: D6100025 0241131E
	v_pk_fma_f16 v35, v36, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003EBF34: CC0E0023 0BFC0D24 0000C931
	v_sad_u8 v39, v39, 0, 0x6400                               // 0000003EBF40: D6220027 03FD0127 00006400
	v_sad_u8 v34, v34, 0, 0x6400                               // 0000003EBF4C: D6220022 03FD0122 00006400
	v_pk_fma_f16 v38, v31, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003EBF58: CC0E0026 0BFC0D1F 0000C931
	.long 0xd73d001f                                           // 0000003EBF64: D73D001F
	v_cndmask_b32_e32 v1, v94, v32, vcc_lo                     // 0000003EBF68: 0202415E
	.long 0xd72c0020                                           // 0000003EBF6C: D72C0020
	v_cndmask_b32_e32 v1, 0x83dcd12d, v37, vcc_lo              // 0000003EBF70: 02024AFF 83DCD12D
	v_bfe_u32 v33, v30, 6, 16                                  // 0000003EBF78: D6100021 02410D1E
	v_and_b32_e32 v129, 0xffff, v129                           // 0000003EBF80: 370302FF 0000FFFF
	v_dot2acc_f32_f16 v81, v35, v5                             // 0000003EBF88: 04A20B23
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003EBF8C: BF8700A3
	.long 0xd72c0021                                           // 0000003EBF90: D72C0021
	v_cndmask_b32_e32 v1, 0x83dcd12d, v33, vcc_lo              // 0000003EBF94: 020242FF 83DCD12D
	v_sad_u8 v32, v32, 0, 0x6400                               // 0000003EBF9C: D6220020 03FD0120 00006400
	v_dual_dot2acc_f32_f16 v85, v35, v1 :: v_dual_and_b32 v32, 0xffff, v32// 0000003EBFA8: CB240323 552040FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003EBFB4: BF870093
	v_sad_u8 v33, v33, 0, 0x6400                               // 0000003EBFB8: D6220021 03FD0121 00006400
	v_lshl_or_b32 v32, v33, 16, v32                            // 0000003EBFC4: D6560020 04812121
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003EBFCC: BF870091
	v_pk_fma_f16 v32, v32, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003EBFD0: CC0E0020 0BFC0D20 0000C931
	v_dual_dot2acc_f32_f16 v84, v32, v5 :: v_dual_lshlrev_b32 v39, 16, v39// 0000003EBFDC: CB220B20 54264E90
	v_dot2acc_f32_f16 v80, v32, v1                             // 0000003EBFE4: 04A00320
	v_bfe_u32 v32, v27, 9, 16                                  // 0000003EBFE8: D6100020 0241131B
	s_delay_alu instid0(VALU_DEP_3)                            // 0000003EBFF0: BF870003
	v_and_or_b32 v34, 0xffff, v34, v39                         // 0000003EBFF4: D6570022 049E44FF 0000FFFF
	v_lshl_or_b32 v39, v130, 16, v129                          // 0000003EC000: D6560027 06052182
	v_bfe_u32 v129, v31, 6, 16                                 // 0000003EC008: D6100081 02410D1F
	v_bfe_u32 v130, v31, 3, 16                                 // 0000003EC010: D6100082 0241071F
	.long 0xd72c0020                                           // 0000003EC018: D72C0020
	v_cndmask_b32_e32 v1, 0x83dcd12d, v32, vcc_lo              // 0000003EC01C: 020240FF 83DCD12D
	v_pk_fma_f16 v34, v34, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003EC024: CC0E0022 0BFC0D22 0000C931
	v_pk_fma_f16 v36, v39, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003EC030: CC0E0024 0BFC0D27 0000C931
	v_and_b32_e32 v39, 0xffff, v30                             // 0000003EC03C: 364E3CFF 0000FFFF
	.long 0xd72c0021                                           // 0000003EC044: D72C0021
	v_cndmask_b32_e32 v1, 0x83dcd12d, v130, vcc_lo             // 0000003EC048: 020304FF 83DCD12D
	v_bfe_u32 v30, v30, 3, 16                                  // 0000003EC050: D610001E 0241071E
	.long 0xd72c0081                                           // 0000003EC058: D72C0081
	v_cndmask_b32_e32 v1, 0x83dcd12d, v129, vcc_lo             // 0000003EC05C: 020302FF 83DCD12D
	v_dot2acc_f32_f16 v85, v34, v2                             // 0000003EC064: 04AA0522
	.long 0xd72c0025                                           // 0000003EC068: D72C0025
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 0000003EC06C: 02024EFF 83DCD12D
	v_bfe_u32 v39, v31, 9, 16                                  // 0000003EC074: D6100027 0241131F
	v_and_b32_e32 v31, 0xffff, v31                             // 0000003EC07C: 363E3EFF 0000FFFF
	.long 0xd72c001e                                           // 0000003EC084: D72C001E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v30, vcc_lo              // 0000003EC088: 02023CFF 83DCD12D
	v_sad_u8 v33, v33, 0, 0x6400                               // 0000003EC090: D6220021 03FD0121 00006400
	v_sad_u8 v32, v32, 0, 0x6400                               // 0000003EC09C: D6220020 03FD0120 00006400
	.long 0xd72c0027                                           // 0000003EC0A8: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 0000003EC0AC: 02024EFF 83DCD12D
	.long 0xd72c001f                                           // 0000003EC0B4: D72C001F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v31, vcc_lo              // 0000003EC0B8: 02023EFF 83DCD12D
	v_sad_u8 v37, v37, 0, 0x6400                               // 0000003EC0C0: D6220025 03FD0125 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000003EC0CC: BF8700C4
	v_and_b32_e32 v32, 0xffff, v32                             // 0000003EC0D0: 364040FF 0000FFFF
	v_sad_u8 v30, v30, 0, 0x6400                               // 0000003EC0D8: D622001E 03FD011E 00006400
	v_sad_u8 v39, v39, 0, 0x6400                               // 0000003EC0E4: D6220027 03FD0127 00006400
	v_sad_u8 v31, v31, 0, 0x6400                               // 0000003EC0F0: D622001F 03FD011F 00006400
	v_lshlrev_b32_e32 v31, 16, v31                             // 0000003EC0FC: 303E3E90
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003EC100: BF870121
	v_and_or_b32 v31, 0xffff, v33, v31                         // 0000003EC104: D657001F 047E42FF 0000FFFF
	v_bfe_u32 v33, v27, 6, 16                                  // 0000003EC110: D6100021 02410D1B
	v_pk_fma_f16 v31, v31, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003EC118: CC0E001F 0BFC0D1F 0000C931
	v_lshlrev_b32_e32 v37, 16, v37                             // 0000003EC124: 304A4A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003EC128: BF870113
	.long 0xd72c0021                                           // 0000003EC12C: D72C0021
	v_cndmask_b32_e32 v1, 0x83dcd12d, v33, vcc_lo              // 0000003EC130: 020242FF 83DCD12D
	v_and_or_b32 v30, 0xffff, v30, v37                         // 0000003EC138: D657001E 04963CFF 0000FFFF
	v_and_b32_e32 v37, 0xffff, v39                             // 0000003EC144: 364A4EFF 0000FFFF
	v_sad_u8 v39, v129, 0, 0x6400                              // 0000003EC14C: D6220027 03FD0181 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003EC158: BF870214
	v_sad_u8 v33, v33, 0, 0x6400                               // 0000003EC15C: D6220021 03FD0121 00006400
	v_pk_fma_f16 v30, v30, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003EC168: CC0E001E 0BFC0D1E 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003EC174: BF8701A3
	v_lshl_or_b32 v35, v39, 16, v37                            // 0000003EC178: D6560023 04952127
	v_mov_b32_e32 v37, v61                                     // 0000003EC180: 7E4A033D
	v_dual_mov_b32 v39, v64 :: v_dual_dot2acc_f32_f16 v80, v30, v2// 0000003EC184: CA180140 2750051E
	v_dot2acc_f32_f16 v84, v30, v6                             // 0000003EC18C: 04A80D1E
	v_bfe_u32 v30, v26, 9, 16                                  // 0000003EC190: D610001E 0241131A
	s_waitcnt vmcnt(13)                                        // 0000003EC198: BF8937F7
	v_dual_mov_b32 v61, v113 :: v_dual_mov_b32 v64, v115       // 0000003EC19C: CA100171 3D400173
	s_delay_alu instid0(VALU_DEP_2)                            // 0000003EC1A4: BF870002
	.long 0xd72c001c                                           // 0000003EC1A8: D72C001C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v30, vcc_lo              // 0000003EC1AC: 02023CFF 83DCD12D
	v_and_b32_e32 v30, 0xffff, v26                             // 0000003EC1B4: 363C34FF 0000FFFF
	v_dot2acc_f32_f16 v81, v34, v6                             // 0000003EC1BC: 04A20D22
	v_pk_fma_f16 v34, v35, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003EC1C0: CC0E0022 0BFC0D23 0000C931
	v_bfe_u32 v26, v26, 3, 16                                  // 0000003EC1CC: D610001A 0241071A
	v_mov_b32_e32 v35, v46                                     // 0000003EC1D4: 7E46032E
	.long 0xd72c001e                                           // 0000003EC1D8: D72C001E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v30, vcc_lo              // 0000003EC1DC: 02023CFF 83DCD12D
	v_mov_b32_e32 v46, v100                                    // 0000003EC1E4: 7E5C0364
	v_dot2acc_f32_f16 v80, v34, v3                             // 0000003EC1E8: 04A00722
	v_dot2acc_f32_f16 v84, v34, v7                             // 0000003EC1EC: 04A80F22
	v_and_b32_e32 v34, 0xffff, v27                             // 0000003EC1F0: 364436FF 0000FFFF
	v_bfe_u32 v27, v27, 3, 16                                  // 0000003EC1F8: D610001B 0241071B
	v_sad_u8 v28, v28, 0, 0x6400                               // 0000003EC200: D622001C 03FD011C 00006400
	.long 0xd72c001a                                           // 0000003EC20C: D72C001A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v26, vcc_lo              // 0000003EC210: 020234FF 83DCD12D
	v_dot2acc_f32_f16 v85, v36, v3                             // 0000003EC218: 04AA0724
	.long 0xd72c0022                                           // 0000003EC21C: D72C0022
	v_cndmask_b32_e32 v1, 0x83dcd12d, v34, vcc_lo              // 0000003EC220: 020244FF 83DCD12D
	.long 0xd72c001b                                           // 0000003EC228: D72C001B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v27, vcc_lo              // 0000003EC22C: 020236FF 83DCD12D
	v_and_b32_e32 v28, 0xffff, v28                             // 0000003EC234: 363838FF 0000FFFF
	v_sad_u8 v30, v30, 0, 0x6400                               // 0000003EC23C: D622001E 03FD011E 00006400
	v_dual_dot2acc_f32_f16 v81, v36, v7 :: v_dual_dot2acc_f32_f16 v80, v31, v4// 0000003EC248: CB180F24 5150091F
	v_sad_u8 v26, v26, 0, 0x6400                               // 0000003EC250: D622001A 03FD011A 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000003EC25C: BF870254
	v_lshl_or_b32 v28, v29, 16, v28                            // 0000003EC260: D656001C 0471211D
	v_sad_u8 v34, v34, 0, 0x6400                               // 0000003EC268: D6220022 03FD0122 00006400
	v_lshlrev_b32_e32 v30, 16, v30                             // 0000003EC274: 303C3C90
	v_sad_u8 v27, v27, 0, 0x6400                               // 0000003EC278: D622001B 03FD011B 00006400
	v_dual_dot2acc_f32_f16 v84, v31, v8 :: v_dual_and_b32 v31, 0xffff, v18// 0000003EC284: CB24111F 541E24FF 0000FFFF
	v_lshlrev_b32_e32 v29, 16, v34                             // 0000003EC290: 303A4490
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003EC294: BF870004
	v_and_or_b32 v26, 0xffff, v26, v30                         // 0000003EC298: D657001A 047A34FF 0000FFFF
	v_lshl_or_b32 v30, v33, 16, v32                            // 0000003EC2A4: D656001E 04812121
	v_mov_b32_e32 v36, v68                                     // 0000003EC2AC: 7E480344
	v_mov_b32_e32 v34, v55                                     // 0000003EC2B0: 7E440337
	v_and_or_b32 v19, 0xffff, v27, v29                         // 0000003EC2B4: D6570013 047636FF 0000FFFF
	v_bfe_u32 v29, v18, 9, 16                                  // 0000003EC2C0: D610001D 02411312
	v_pk_fma_f16 v27, v28, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003EC2C8: CC0E001B 0BFC0D1C 0000C931
	v_pk_fma_f16 v28, v30, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003EC2D4: CC0E001C 0BFC0D1E 0000C931
	v_pk_fma_f16 v26, v26, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003EC2E0: CC0E001A 0BFC0D1A 0000C931
	v_pk_fma_f16 v30, v19, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003EC2EC: CC0E001E 0BFC0D13 0000C931
	.long 0xd73d0013                                           // 0000003EC2F8: D73D0013
	v_cndmask_b32_e32 v1, v94, v20, vcc_lo                     // 0000003EC2FC: 0202295E
	.long 0xd72c0014                                           // 0000003EC300: D72C0014
	v_cndmask_b32_e32 v1, 0x83dcd12d, v29, vcc_lo              // 0000003EC304: 02023AFF 83DCD12D
	v_bfe_u32 v21, v18, 6, 16                                  // 0000003EC30C: D6100015 02410D12
	v_bfe_u32 v18, v18, 3, 16                                  // 0000003EC314: D6100012 02410712
	.long 0xd72c001d                                           // 0000003EC31C: D72C001D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v31, vcc_lo              // 0000003EC320: 02023EFF 83DCD12D
	v_dot2acc_f32_f16 v83, v27, v5                             // 0000003EC328: 04A60B1B
	v_bfe_u32 v31, v19, 9, 16                                  // 0000003EC32C: D610001F 02411313
	.long 0xd72c0015                                           // 0000003EC334: D72C0015
	v_cndmask_b32_e32 v1, 0x83dcd12d, v21, vcc_lo              // 0000003EC338: 02022AFF 83DCD12D
	v_bfe_u32 v32, v19, 6, 16                                  // 0000003EC340: D6100020 02410D13
	.long 0xd72c0012                                           // 0000003EC348: D72C0012
	v_cndmask_b32_e32 v1, 0x83dcd12d, v18, vcc_lo              // 0000003EC34C: 020224FF 83DCD12D
	v_sad_u8 v20, v20, 0, 0x6400                               // 0000003EC354: D6220014 03FD0114 00006400
	v_bfe_u32 v33, v19, 3, 16                                  // 0000003EC360: D6100021 02410713
	.long 0xd72c001f                                           // 0000003EC368: D72C001F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v31, vcc_lo              // 0000003EC36C: 02023EFF 83DCD12D
	v_and_b32_e32 v19, 0xffff, v19                             // 0000003EC374: 362626FF 0000FFFF
	v_sad_u8 v29, v29, 0, 0x6400                               // 0000003EC37C: D622001D 03FD011D 00006400
	v_dual_dot2acc_f32_f16 v75, v27, v1 :: v_dual_and_b32 v20, 0xffff, v20// 0000003EC388: CB24031B 4B1428FF 0000FFFF
	v_sad_u8 v21, v21, 0, 0x6400                               // 0000003EC394: D6220015 03FD0115 00006400
	.long 0xd72c0020                                           // 0000003EC3A0: D72C0020
	v_cndmask_b32_e32 v1, 0x83dcd12d, v32, vcc_lo              // 0000003EC3A4: 020240FF 83DCD12D
	.long 0xd72c0013                                           // 0000003EC3AC: D72C0013
	v_cndmask_b32_e32 v1, 0x83dcd12d, v19, vcc_lo              // 0000003EC3B0: 020226FF 83DCD12D
	v_sad_u8 v18, v18, 0, 0x6400                               // 0000003EC3B8: D6220012 03FD0112 00006400
	v_lshlrev_b32_e32 v29, 16, v29                             // 0000003EC3C4: 303A3A90
	v_sad_u8 v31, v31, 0, 0x6400                               // 0000003EC3C8: D622001F 03FD011F 00006400
	v_lshl_or_b32 v20, v21, 16, v20                            // 0000003EC3D4: D6560014 04512115
	.long 0xd72c0015                                           // 0000003EC3DC: D72C0015
	v_cndmask_b32_e32 v1, 0x83dcd12d, v33, vcc_lo              // 0000003EC3E0: 020242FF 83DCD12D
	v_dot2acc_f32_f16 v75, v26, v2                             // 0000003EC3E8: 0496051A
	v_and_or_b32 v18, 0xffff, v18, v29                         // 0000003EC3EC: D6570012 047624FF 0000FFFF
	v_and_b32_e32 v29, 0xffff, v31                             // 0000003EC3F8: 363A3EFF 0000FFFF
	v_sad_u8 v31, v32, 0, 0x6400                               // 0000003EC400: D622001F 03FD0120 00006400
	v_sad_u8 v19, v19, 0, 0x6400                               // 0000003EC40C: D6220013 03FD0113 00006400
	v_dot2acc_f32_f16 v83, v26, v6                             // 0000003EC418: 04A60D1A
	v_pk_fma_f16 v27, v18, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003EC41C: CC0E001B 0BFC0D12 0000C931
	v_sad_u8 v21, v21, 0, 0x6400                               // 0000003EC428: D6220015 03FD0115 00006400
	v_lshl_or_b32 v18, v31, 16, v29                            // 0000003EC434: D6560012 0475211F
	v_lshlrev_b32_e32 v19, 16, v19                             // 0000003EC43C: 30262690
	v_pk_fma_f16 v20, v20, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003EC440: CC0E0014 0BFC0D14 0000C931
	v_dual_mov_b32 v32, v66 :: v_dual_mov_b32 v29, v56         // 0000003EC44C: CA100142 201C0138
	s_waitcnt vmcnt(5)                                         // 0000003EC454: BF8917F7
	v_mov_b32_e32 v68, v118                                    // 0000003EC458: 7E880376
	v_pk_fma_f16 v26, v18, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003EC45C: CC0E001A 0BFC0D12 0000C931
	v_and_or_b32 v21, 0xffff, v21, v19                         // 0000003EC468: D6570015 044E2AFF 0000FFFF
	.long 0xd73d0012                                           // 0000003EC474: D73D0012
	v_cndmask_b32_e32 v1, v92, v22, vcc_lo                     // 0000003EC478: 02022D5C
	v_dot2acc_f32_f16 v82, v20, v1                             // 0000003EC47C: 04A40314
	v_dot2acc_f32_f16 v79, v20, v5                             // 0000003EC480: 049E0B14
	.long 0xd73d0013                                           // 0000003EC484: D73D0013
	v_cndmask_b32_e32 v1, v94, v24, vcc_lo                     // 0000003EC488: 0202315E
	v_dot2acc_f32_f16 v85, v38, v4                             // 0000003EC48C: 04AA0926
	v_dot2acc_f32_f16 v81, v38, v8                             // 0000003EC490: 04A21126
	v_bfe_u32 v22, v18, 9, 16                                  // 0000003EC494: D6100016 02411312
	v_bfe_u32 v23, v18, 3, 16                                  // 0000003EC49C: D6100017 02410712
	v_dot2acc_f32_f16 v82, v27, v2                             // 0000003EC4A4: 04A4051B
	v_dot2acc_f32_f16 v79, v27, v6                             // 0000003EC4A8: 049E0D1B
	v_bfe_u32 v24, v19, 9, 16                                  // 0000003EC4AC: D6100018 02411313
	.long 0xd72c0014                                           // 0000003EC4B4: D72C0014
	v_cndmask_b32_e32 v1, 0x83dcd12d, v22, vcc_lo              // 0000003EC4B8: 02022CFF 83DCD12D
	v_bfe_u32 v22, v18, 6, 16                                  // 0000003EC4C0: D6100016 02410D12
	v_and_b32_e32 v18, 0xffff, v18                             // 0000003EC4C8: 362424FF 0000FFFF
	v_dot2acc_f32_f16 v82, v26, v3                             // 0000003EC4D0: 04A4071A
	v_dot2acc_f32_f16 v79, v26, v7                             // 0000003EC4D4: 049E0F1A
	v_and_b32_e32 v26, 0xffff, v19                             // 0000003EC4D8: 363426FF 0000FFFF
	.long 0xd72c0016                                           // 0000003EC4E0: D72C0016
	v_cndmask_b32_e32 v1, 0x83dcd12d, v22, vcc_lo              // 0000003EC4E4: 02022CFF 83DCD12D
	.long 0xd72c0012                                           // 0000003EC4EC: D72C0012
	v_cndmask_b32_e32 v1, 0x83dcd12d, v18, vcc_lo              // 0000003EC4F0: 020224FF 83DCD12D
	v_sad_u8 v20, v20, 0, 0x6400                               // 0000003EC4F8: D6220014 03FD0114 00006400
	.long 0xd72c0017                                           // 0000003EC504: D72C0017
	v_cndmask_b32_e32 v1, 0x83dcd12d, v23, vcc_lo              // 0000003EC508: 02022EFF 83DCD12D
	v_bfe_u32 v25, v19, 6, 16                                  // 0000003EC510: D6100019 02410D13
	.long 0xd72c0018                                           // 0000003EC518: D72C0018
	v_cndmask_b32_e32 v1, 0x83dcd12d, v24, vcc_lo              // 0000003EC51C: 020230FF 83DCD12D
	v_bfe_u32 v19, v19, 3, 16                                  // 0000003EC524: D6100013 02410713
	v_and_b32_e32 v20, 0xffff, v20                             // 0000003EC52C: 362828FF 0000FFFF
	v_sad_u8 v22, v22, 0, 0x6400                               // 0000003EC534: D6220016 03FD0116 00006400
	v_sad_u8 v18, v18, 0, 0x6400                               // 0000003EC540: D6220012 03FD0112 00006400
	.long 0xd72c001a                                           // 0000003EC54C: D72C001A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v26, vcc_lo              // 0000003EC550: 020234FF 83DCD12D
	.long 0xd72c0019                                           // 0000003EC558: D72C0019
	v_cndmask_b32_e32 v1, 0x83dcd12d, v25, vcc_lo              // 0000003EC55C: 020232FF 83DCD12D
	.long 0xd72c0013                                           // 0000003EC564: D72C0013
	v_cndmask_b32_e32 v1, 0x83dcd12d, v19, vcc_lo              // 0000003EC568: 020226FF 83DCD12D
	v_lshl_or_b32 v20, v22, 16, v20                            // 0000003EC570: D6560014 04512116
	v_sad_u8 v22, v23, 0, 0x6400                               // 0000003EC578: D6220016 03FD0117 00006400
	v_lshlrev_b32_e32 v18, 16, v18                             // 0000003EC584: 30242490
	v_sad_u8 v24, v24, 0, 0x6400                               // 0000003EC588: D6220018 03FD0118 00006400
	v_dot2acc_f32_f16 v75, v28, v3                             // 0000003EC594: 0496071C
	v_sad_u8 v23, v26, 0, 0x6400                               // 0000003EC598: D6220017 03FD011A 00006400
	v_pk_fma_f16 v20, v20, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003EC5A4: CC0E0014 0BFC0D14 0000C931
	v_and_or_b32 v18, 0xffff, v22, v18                         // 0000003EC5B0: D6570012 044A2CFF 0000FFFF
	v_and_b32_e32 v24, 0xffff, v24                             // 0000003EC5BC: 363030FF 0000FFFF
	v_sad_u8 v25, v25, 0, 0x6400                               // 0000003EC5C4: D6220019 03FD0119 00006400
	v_sad_u8 v19, v19, 0, 0x6400                               // 0000003EC5D0: D6220013 03FD0113 00006400
	v_lshlrev_b32_e32 v23, 16, v23                             // 0000003EC5DC: 302E2E90
	v_pk_fma_f16 v18, v18, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003EC5E0: CC0E0012 0BFC0D12 0000C931
	v_dot2acc_f32_f16 v78, v20, v1                             // 0000003EC5EC: 049C0314
	v_dot2acc_f32_f16 v77, v20, v5                             // 0000003EC5F0: 049A0B14
	v_pk_fma_f16 v21, v21, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003EC5F4: CC0E0015 0BFC0D15 0000C931
	v_lshl_or_b32 v22, v25, 16, v24                            // 0000003EC600: D6560016 04612119
	v_mov_b32_e32 v38, v69                                     // 0000003EC608: 7E4C0345
	v_dot2acc_f32_f16 v78, v18, v2                             // 0000003EC60C: 049C0512
	v_dot2acc_f32_f16 v77, v18, v6                             // 0000003EC610: 049A0D12
	v_mov_b32_e32 v18, v50                                     // 0000003EC614: 7E240332
	v_and_or_b32 v15, 0xffff, v19, v23                         // 0000003EC618: D657000F 045E26FF 0000FFFF
	v_dot2acc_f32_f16 v82, v21, v4                             // 0000003EC624: 04A40915
	v_dot2acc_f32_f16 v79, v21, v8                             // 0000003EC628: 049E1115
	v_bfe_u32 v21, v14, 9, 16                                  // 0000003EC62C: D6100015 0241130E
	v_pk_fma_f16 v19, v22, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003EC634: CC0E0013 0BFC0D16 0000C931
	v_pk_fma_f16 v22, v15, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003EC640: CC0E0016 0BFC0D0F 0000C931
	.long 0xd73d000f                                           // 0000003EC64C: D73D000F
	v_cndmask_b32_e32 v1, v94, v16, vcc_lo                     // 0000003EC650: 0202215E
	v_and_b32_e32 v23, 0xffff, v14                             // 0000003EC654: 362E1CFF 0000FFFF
	.long 0xd72c0010                                           // 0000003EC65C: D72C0010
	v_cndmask_b32_e32 v1, 0x83dcd12d, v21, vcc_lo              // 0000003EC660: 02022AFF 83DCD12D
	v_bfe_u32 v17, v14, 6, 16                                  // 0000003EC668: D6100011 02410D0E
	v_bfe_u32 v14, v14, 3, 16                                  // 0000003EC670: D610000E 0241070E
	v_dot2acc_f32_f16 v78, v19, v3                             // 0000003EC678: 049C0713
	.long 0xd72c0015                                           // 0000003EC67C: D72C0015
	v_cndmask_b32_e32 v1, 0x83dcd12d, v23, vcc_lo              // 0000003EC680: 02022EFF 83DCD12D
	v_bfe_u32 v23, v15, 9, 16                                  // 0000003EC688: D6100017 0241130F
	.long 0xd72c0011                                           // 0000003EC690: D72C0011
	v_cndmask_b32_e32 v1, 0x83dcd12d, v17, vcc_lo              // 0000003EC694: 020222FF 83DCD12D
	v_bfe_u32 v24, v15, 6, 16                                  // 0000003EC69C: D6100018 02410D0F
	v_sad_u8 v16, v16, 0, 0x6400                               // 0000003EC6A4: D6220010 03FD0110 00006400
	.long 0xd72c000e                                           // 0000003EC6B0: D72C000E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v14, vcc_lo              // 0000003EC6B4: 02021CFF 83DCD12D
	v_bfe_u32 v25, v15, 3, 16                                  // 0000003EC6BC: D6100019 0241070F
	.long 0xd72c0017                                           // 0000003EC6C4: D72C0017
	v_cndmask_b32_e32 v1, 0x83dcd12d, v23, vcc_lo              // 0000003EC6C8: 02022EFF 83DCD12D
	v_and_b32_e32 v15, 0xffff, v15                             // 0000003EC6D0: 361E1EFF 0000FFFF
	v_sad_u8 v21, v21, 0, 0x6400                               // 0000003EC6D8: D6220015 03FD0115 00006400
	v_and_b32_e32 v16, 0xffff, v16                             // 0000003EC6E4: 362020FF 0000FFFF
	v_sad_u8 v17, v17, 0, 0x6400                               // 0000003EC6EC: D6220011 03FD0111 00006400
	.long 0xd72c0018                                           // 0000003EC6F8: D72C0018
	v_cndmask_b32_e32 v1, 0x83dcd12d, v24, vcc_lo              // 0000003EC6FC: 020230FF 83DCD12D
	.long 0xd72c000f                                           // 0000003EC704: D72C000F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v15, vcc_lo              // 0000003EC708: 02021EFF 83DCD12D
	v_sad_u8 v14, v14, 0, 0x6400                               // 0000003EC710: D622000E 03FD010E 00006400
	v_lshlrev_b32_e32 v21, 16, v21                             // 0000003EC71C: 302A2A90
	v_sad_u8 v23, v23, 0, 0x6400                               // 0000003EC720: D6220017 03FD0117 00006400
	v_lshl_or_b32 v16, v17, 16, v16                            // 0000003EC72C: D6560010 04412111
	.long 0xd72c0011                                           // 0000003EC734: D72C0011
	v_cndmask_b32_e32 v1, 0x83dcd12d, v25, vcc_lo              // 0000003EC738: 020232FF 83DCD12D
	v_dual_dot2acc_f32_f16 v83, v28, v7 :: v_dual_dot2acc_f32_f16 v78, v22, v4// 0000003EC740: CB180F1C 534E0916
	v_and_or_b32 v14, 0xffff, v14, v21                         // 0000003EC748: D657000E 04561CFF 0000FFFF
	v_and_b32_e32 v21, 0xffff, v23                             // 0000003EC754: 362A2EFF 0000FFFF
	v_sad_u8 v23, v24, 0, 0x6400                               // 0000003EC75C: D6220017 03FD0118 00006400
	v_sad_u8 v15, v15, 0, 0x6400                               // 0000003EC768: D622000F 03FD010F 00006400
	v_pk_fma_f16 v16, v16, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003EC774: CC0E0010 0BFC0D10 0000C931
	v_pk_fma_f16 v14, v14, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000003EC780: CC0E000E 0BFC0D0E 0000C931
	v_sad_u8 v17, v17, 0, 0x6400                               // 0000003EC78C: D6220011 03FD0111 00006400
	v_lshl_or_b32 v20, v23, 16, v21                            // 0000003EC798: D6560014 04552117
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000003EC7A0: BF870234
	v_dual_dot2acc_f32_f16 v76, v16, v1 :: v_dual_lshlrev_b32 v15, 16, v15// 0000003EC7A4: CB220310 4C0E1E90
	v_dot2acc_f32_f16 v9, v16, v5                              // 0000003EC7AC: 04120B10
	v_mov_b32_e32 v21, v54                                     // 0000003EC7B0: 7E2A0336
	v_pk_fma_f16 v1, v20, s6, 0xc931 op_sel_hi:[1,0,0]         // 0000003EC7B4: CC0E0001 0BFC0D14 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000003EC7C0: BF870244
	v_and_or_b32 v5, 0xffff, v17, v15                          // 0000003EC7C4: D6570005 043E22FF 0000FFFF
	v_dot2acc_f32_f16 v76, v14, v2                             // 0000003EC7D0: 0498050E
	v_mov_b32_e32 v54, v106                                    // 0000003EC7D4: 7E6C036A
	v_dual_dot2acc_f32_f16 v9, v14, v6 :: v_dual_mov_b32 v50, v103// 0000003EC7D8: CB100D0E 09320167
	v_pk_fma_f16 v2, v5, s6, 0xc931 op_sel_hi:[1,0,0]          // 0000003EC7E0: CC0E0002 0BFC0D05 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003EC7EC: BF870194
	v_dot2acc_f32_f16 v76, v1, v3                              // 0000003EC7F0: 04980701
	v_dual_mov_b32 v56, v108 :: v_dual_dot2acc_f32_f16 v9, v1, v7// 0000003EC7F4: CA18016C 38080F01
	s_waitcnt vmcnt(4)                                         // 0000003EC7FC: BF8913F7
	v_dual_mov_b32 v66, v116 :: v_dual_add_nc_u32 v1, v90, v91 // 0000003EC800: CA200174 4200B75A
	v_dual_dot2acc_f32_f16 v83, v30, v8 :: v_dual_mov_b32 v26, v52// 0000003EC808: CB10111E 531A0134
	v_dot2acc_f32_f16 v76, v2, v4                              // 0000003EC810: 04980902
	v_dual_mov_b32 v52, v104 :: v_dual_dot2acc_f32_f16 v9, v2, v8// 0000003EC814: CA180168 34081102
	v_dual_mov_b32 v2, v48 :: v_dual_dot2acc_f32_f16 v77, v19, v7// 0000003EC81C: CA180130 024C0F13
	v_cmp_eq_u32_e32 vcc_lo, 2, v1                             // 0000003EC824: 7C940282
	v_dual_dot2acc_f32_f16 v75, v30, v4 :: v_dual_mov_b32 v20, v59// 0000003EC828: CB10091E 4B14013B
	v_dual_mov_b32 v19, v43 :: v_dual_mov_b32 v28, v62         // 0000003EC830: CA10012B 131C013E
	v_dual_mov_b32 v27, v44 :: v_dual_mov_b32 v48, v102        // 0000003EC838: CA10012C 1B300166
	v_dual_mov_b32 v33, v58 :: v_dual_mov_b32 v30, v53         // 0000003EC840: CA10013A 211E0135
	v_mov_b32_e32 v31, v45                                     // 0000003EC848: 7E3E032D
	v_dual_mov_b32 v5, v57 :: v_dual_mov_b32 v6, v47           // 0000003EC84C: CA100139 0506012F
	v_dual_mov_b32 v3, v70 :: v_dual_mov_b32 v4, v67           // 0000003EC854: CA100146 03040143
	v_mov_b32_e32 v1, v60                                      // 0000003EC85C: 7E02033C
	s_waitcnt vmcnt(2)                                         // 0000003EC860: BF890BF7
	v_mov_b32_e32 v59, v111                                    // 0000003EC864: 7E76036F
	v_dual_mov_b32 v43, v97 :: v_dual_mov_b32 v62, v114        // 0000003EC868: CA100161 2B3E0172
	v_dot2acc_f32_f16 v77, v22, v8                             // 0000003EC870: 049A1116
	v_mov_b32_e32 v44, v98                                     // 0000003EC874: 7E580362
	v_dual_mov_b32 v58, v110 :: v_dual_mov_b32 v53, v105       // 0000003EC878: CA10016E 3A340169
	v_mov_b32_e32 v45, v99                                     // 0000003EC880: 7E5A0363
	v_mov_b32_e32 v55, v107                                    // 0000003EC884: 7E6E036B
	v_mov_b32_e32 v69, v119                                    // 0000003EC888: 7E8A0377
	v_mov_b32_e32 v57, v109                                    // 0000003EC88C: 7E72036D
	v_dual_mov_b32 v47, v101 :: v_dual_mov_b32 v70, v120       // 0000003EC890: CA100165 2F460178
	v_dual_mov_b32 v67, v117 :: v_dual_mov_b32 v60, v112       // 0000003EC898: CA100175 433C0170
	v_dual_mov_b32 v23, v128 :: v_dual_mov_b32 v22, v127       // 0000003EC8A0: CA100180 1716017F
	v_dual_mov_b32 v25, v126 :: v_dual_mov_b32 v24, v125       // 0000003EC8A8: CA10017E 1918017D
	v_dual_mov_b32 v15, v124 :: v_dual_mov_b32 v14, v123       // 0000003EC8B0: CA10017C 0F0E017B
	v_dual_mov_b32 v17, v122 :: v_dual_mov_b32 v16, v121       // 0000003EC8B8: CA10017A 11100179
	s_or_b32 s2, vcc_lo, s2                                    // 0000003EC8C0: 8C02026A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003EC8C4: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s2                        // 0000003EC8C8: 917E027E
	s_cbranch_execz 102                                        // 0000003EC8CC: BFA50066 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2068>
	s_waitcnt vmcnt(1)                                         // 0000003EC8D0: BF8907F7
	v_dual_mov_b32 v128, v49 :: v_dual_mov_b32 v125, v74       // 0000003EC8D4: CA100131 807C014A
	v_dual_mov_b32 v127, v65 :: v_dual_mov_b32 v126, v72       // 0000003EC8DC: CA100141 7F7E0148
	s_waitcnt vmcnt(0)                                         // 0000003EC8E4: BF8903F7
	v_dual_mov_b32 v124, v51 :: v_dual_mov_b32 v121, v73       // 0000003EC8E8: CA100133 7C780149
	v_mov_b32_e32 v123, v63                                    // 0000003EC8F0: 7EF6033F
	v_mov_b32_e32 v122, v71                                    // 0000003EC8F4: 7EF40347
	s_mov_b32 s7, exec_lo                                      // 0000003EC8F8: BE87007E
	.long 0xd4c1007e                                           // 0000003EC8FC: D4C1007E
	v_cndmask_b32_e32 v1, v91, v42, vcc_lo                     // 0000003EC900: 0202555B
	s_cbranch_execz 64589                                      // 0000003EC904: BFA5FC4D <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x103c>
	v_mad_i64_i32 v[7:8], null, 0x300, v91, s[4:5]             // 0000003EC908: D6FF7C07 0012B6FF 00000300
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003EC914: BF870091
	.long 0xd7006a47                                           // 0000003EC918: D7006A47
	v_cndmask_b32_e32 v1, v7, v10, vcc_lo                      // 0000003EC91C: 02021507
	v_add_co_ci_u32_e64 v72, null, v8, v11, vcc_lo             // 0000003EC920: D5207C48 01AA1708
	.long 0xd7006a49                                           // 0000003EC928: D7006A49
	v_cndmask_b32_e32 v1, v7, v95, vcc_lo                      // 0000003EC92C: 0202BF07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003EC930: BF8700A1
	v_add_co_ci_u32_e64 v74, null, 0, v8, vcc_lo               // 0000003EC934: D5207C4A 01AA1080
	.long 0xd7006a76                                           // 0000003EC93C: D7006A76
	v_cndmask_b32_e32 v1, v7, v12, vcc_lo                      // 0000003EC940: 02021907
	v_add_co_ci_u32_e64 v119, null, v8, v13, vcc_lo            // 0000003EC944: D5207C77 01AA1B08
	.long 0xd7006a07                                           // 0000003EC94C: D7006A07
	v_cndmask_b32_e32 v1, v7, v96, vcc_lo                      // 0000003EC950: 0202C107
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003EC954: BF870001
	v_add_co_ci_u32_e64 v8, null, 0, v8, vcc_lo                // 0000003EC958: D5207C08 01AA1080
	s_clause 0x1f                                              // 0000003EC960: BF85001F
	global_load_b32 v102, v[71:72], off                        // 0000003EC964: DC520000 667C0047
	global_load_b32 v101, v[71:72], off offset:96              // 0000003EC96C: DC520060 657C0047
	global_load_b32 v100, v[71:72], off offset:192             // 0000003EC974: DC5200C0 647C0047
	global_load_b32 v99, v[71:72], off offset:288              // 0000003EC97C: DC520120 637C0047
	global_load_b32 v98, v[71:72], off offset:384              // 0000003EC984: DC520180 627C0047
	global_load_b32 v97, v[71:72], off offset:480              // 0000003EC98C: DC5201E0 617C0047
	global_load_b32 v49, v[71:72], off offset:576              // 0000003EC994: DC520240 317C0047
	global_load_b32 v51, v[71:72], off offset:672              // 0000003EC99C: DC5202A0 337C0047
	global_load_b32 v112, v[73:74], off                        // 0000003EC9A4: DC520000 707C0049
	global_load_b32 v109, v[73:74], off offset:96              // 0000003EC9AC: DC520060 6D7C0049
	global_load_b32 v107, v[73:74], off offset:192             // 0000003EC9B4: DC5200C0 6B7C0049
	global_load_b32 v105, v[73:74], off offset:288             // 0000003EC9BC: DC520120 697C0049
	global_load_b32 v104, v[73:74], off offset:384             // 0000003EC9C4: DC520180 687C0049
	global_load_b32 v103, v[73:74], off offset:480             // 0000003EC9CC: DC5201E0 677C0049
	global_load_b32 v65, v[73:74], off offset:576              // 0000003EC9D4: DC520240 417C0049
	global_load_b32 v63, v[73:74], off offset:672              // 0000003EC9DC: DC5202A0 3F7C0049
	global_load_b32 v117, v[118:119], off                      // 0000003EC9E4: DC520000 757C0076
	global_load_b32 v115, v[118:119], off offset:96            // 0000003EC9EC: DC520060 737C0076
	global_load_b32 v113, v[118:119], off offset:192           // 0000003EC9F4: DC5200C0 717C0076
	global_load_b32 v110, v[118:119], off offset:288           // 0000003EC9FC: DC520120 6E7C0076
	global_load_b32 v108, v[118:119], off offset:384           // 0000003ECA04: DC520180 6C7C0076
	global_load_b32 v106, v[118:119], off offset:480           // 0000003ECA0C: DC5201E0 6A7C0076
	global_load_b32 v72, v[118:119], off offset:576            // 0000003ECA14: DC520240 487C0076
	global_load_b32 v71, v[118:119], off offset:672            // 0000003ECA1C: DC5202A0 477C0076
	global_load_b32 v120, v[7:8], off                          // 0000003ECA24: DC520000 787C0007
	global_load_b32 v119, v[7:8], off offset:96                // 0000003ECA2C: DC520060 777C0007
	global_load_b32 v118, v[7:8], off offset:192               // 0000003ECA34: DC5200C0 767C0007
	global_load_b32 v116, v[7:8], off offset:288               // 0000003ECA3C: DC520120 747C0007
	global_load_b32 v114, v[7:8], off offset:384               // 0000003ECA44: DC520180 727C0007
	global_load_b32 v111, v[7:8], off offset:480               // 0000003ECA4C: DC5201E0 6F7C0007
	global_load_b32 v74, v[7:8], off offset:576                // 0000003ECA54: DC520240 4A7C0007
	global_load_b32 v73, v[7:8], off offset:672                // 0000003ECA5C: DC5202A0 497C0007
	s_branch 64501                                             // 0000003ECA64: BFA0FBF5 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x103c>
	s_or_b32 exec_lo, exec_lo, s2                              // 0000003ECA68: 8C7E027E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003ECA6C: BF870009
	s_or_b32 exec_lo, exec_lo, s3                              // 0000003ECA70: 8C7E037E
	s_waitcnt vmcnt(23)                                        // 0000003ECA74: BF895FF7
	v_dual_mov_b32 v1, v89 :: v_dual_mov_b32 v2, v87           // 0000003ECA78: CA100159 01020157
	s_waitcnt vmcnt(7)                                         // 0000003ECA80: BF891FF7
	v_dual_mov_b32 v3, v88 :: v_dual_mov_b32 v6, v86           // 0000003ECA84: CA100158 03060156
	v_dual_mov_b32 v4, v85 :: v_dual_mov_b32 v7, v75           // 0000003ECA8C: CA100155 0406014B
	v_dual_mov_b32 v5, v81 :: v_dual_mov_b32 v8, v80           // 0000003ECA94: CA100151 05080150
	v_dual_mov_b32 v10, v84 :: v_dual_mov_b32 v11, v83         // 0000003ECA9C: CA100154 0A0A0153
	v_dual_mov_b32 v12, v82 :: v_dual_mov_b32 v13, v79         // 0000003ECAA4: CA100152 0C0C014F
	v_dual_mov_b32 v14, v78 :: v_dual_mov_b32 v15, v77         // 0000003ECAAC: CA10014E 0E0E014D
	s_waitcnt vmcnt(0)                                         // 0000003ECAB4: BF8903F7
	v_dual_mov_b32 v16, v76 :: v_dual_mov_b32 v17, v9          // 0000003ECAB8: CA10014C 10100109
	s_mov_b32 s2, 0x76543210                                   // 0000003ECAC0: BE8200FF 76543210
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003ECAC8: BF870009
	v_permlanex16_b32 v1, v1, s2, 0xfedcba98                   // 0000003ECACC: D65C0001 03FC0501 FEDCBA98
	v_permlanex16_b32 v2, v2, s2, 0xfedcba98                   // 0000003ECAD8: D65C0002 03FC0502 FEDCBA98
	v_permlanex16_b32 v3, v3, s2, 0xfedcba98                   // 0000003ECAE4: D65C0003 03FC0503 FEDCBA98
	v_permlanex16_b32 v6, v6, s2, 0xfedcba98                   // 0000003ECAF0: D65C0006 03FC0506 FEDCBA98
	v_permlanex16_b32 v4, v4, s2, 0xfedcba98                   // 0000003ECAFC: D65C0004 03FC0504 FEDCBA98
	v_permlanex16_b32 v5, v5, s2, 0xfedcba98                   // 0000003ECB08: D65C0005 03FC0505 FEDCBA98
	v_permlanex16_b32 v8, v8, s2, 0xfedcba98                   // 0000003ECB14: D65C0008 03FC0508 FEDCBA98
	v_permlanex16_b32 v10, v10, s2, 0xfedcba98                 // 0000003ECB20: D65C000A 03FC050A FEDCBA98
	v_permlanex16_b32 v7, v7, s2, 0xfedcba98                   // 0000003ECB2C: D65C0007 03FC0507 FEDCBA98
	v_permlanex16_b32 v11, v11, s2, 0xfedcba98                 // 0000003ECB38: D65C000B 03FC050B FEDCBA98
	v_permlanex16_b32 v12, v12, s2, 0xfedcba98                 // 0000003ECB44: D65C000C 03FC050C FEDCBA98
	v_permlanex16_b32 v13, v13, s2, 0xfedcba98                 // 0000003ECB50: D65C000D 03FC050D FEDCBA98
	v_permlanex16_b32 v14, v14, s2, 0xfedcba98                 // 0000003ECB5C: D65C000E 03FC050E FEDCBA98
	v_permlanex16_b32 v15, v15, s2, 0xfedcba98                 // 0000003ECB68: D65C000F 03FC050F FEDCBA98
	v_permlanex16_b32 v16, v16, s2, 0xfedcba98                 // 0000003ECB74: D65C0010 03FC0510 FEDCBA98
	v_permlanex16_b32 v17, v17, s2, 0xfedcba98                 // 0000003ECB80: D65C0011 03FC0511 FEDCBA98
	.long 0xd44c0002                                           // 0000003ECB8C: D44C0002
	v_cndmask_b32_e32 v1, 16, v41, vcc_lo                      // 0000003ECB90: 02025290
	s_barrier                                                  // 0000003ECB94: BFBD0000
	buffer_gl0_inv                                             // 0000003ECB98: E0AC0000 00000000
	s_and_saveexec_b32 s3, s2                                  // 0000003ECBA0: BE832002
	s_cbranch_execz 36                                         // 0000003ECBA4: BFA50024 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2238>
	v_dual_add_f32 v9, v9, v17 :: v_dual_add_f32 v16, v76, v16 // 0000003ECBA8: C9082309 0910214C
	v_dual_add_f32 v8, v80, v8 :: v_dual_lshlrev_b32 v17, 2, v41// 0000003ECBB0: C9221150 08105282
	v_dual_add_f32 v6, v86, v6 :: v_dual_add_f32 v3, v88, v3   // 0000003ECBB8: C9080D56 06020758
	v_dual_add_f32 v1, v89, v1 :: v_dual_add_f32 v2, v87, v2   // 0000003ECBC0: C9080359 01020557
	s_delay_alu instid0(VALU_DEP_3)                            // 0000003ECBC8: BF870003
	v_lshl_or_b32 v17, v40, 10, v17                            // 0000003ECBCC: D6560011 04451528
	v_dual_add_f32 v4, v85, v4 :: v_dual_add_f32 v7, v75, v7   // 0000003ECBD4: C9080955 04060F4B
	v_dual_add_f32 v11, v83, v11 :: v_dual_add_f32 v10, v84, v10// 0000003ECBDC: C9081753 0B0A1554
	v_add_f32_e32 v5, v81, v5                                  // 0000003ECBE4: 060A0B51
	v_dual_add_f32 v13, v79, v13 :: v_dual_add_f32 v12, v82, v12// 0000003ECBE8: C9081B4F 0D0C1952
	v_dual_add_f32 v15, v77, v15 :: v_dual_add_f32 v14, v78, v14// 0000003ECBF0: C9081F4D 0F0E1D4E
	ds_store_2addr_b32 v17, v1, v3 offset1:16                  // 0000003ECBF8: D8381000 00030111
	ds_store_2addr_b32 v17, v2, v6 offset0:128 offset1:144     // 0000003ECC00: D8389080 00060211
	ds_store_2addr_b32 v17, v4, v8 offset0:32 offset1:48       // 0000003ECC08: D8383020 00080411
	ds_store_2addr_b32 v17, v5, v10 offset0:160 offset1:176    // 0000003ECC10: D838B0A0 000A0511
	ds_store_2addr_b32 v17, v7, v12 offset0:64 offset1:80      // 0000003ECC18: D8385040 000C0711
	ds_store_2addr_b32 v17, v11, v13 offset0:192 offset1:208   // 0000003ECC20: D838D0C0 000D0B11
	ds_store_2addr_b32 v17, v14, v16 offset0:96 offset1:112    // 0000003ECC28: D8387060 00100E11
	ds_store_2addr_b32 v17, v15, v9 offset0:224 offset1:240    // 0000003ECC30: D838F0E0 00090F11
	s_or_b32 exec_lo, exec_lo, s3                              // 0000003ECC38: 8C7E037E
	.long 0xd44c0003                                           // 0000003ECC3C: D44C0003
	v_cndmask_b32_e32 v1, 0x100, v0, vcc_lo                    // 0000003ECC40: 020200FF 00000100
	s_waitcnt lgkmcnt(0)                                       // 0000003ECC48: BF89FC07
	s_barrier                                                  // 0000003ECC4C: BFBD0000
	buffer_gl0_inv                                             // 0000003ECC50: E0AC0000 00000000
	s_and_saveexec_b32 s4, s3                                  // 0000003ECC58: BE842003
	s_cbranch_execnz 7                                         // 0000003ECC5C: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x227c>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000003ECC60: 8C7E047E
	s_cmp_lt_i32 s21, 2                                        // 0000003ECC64: BF048215
	s_mov_b32 s4, -1                                           // 0000003ECC68: BE8400C1
	s_cbranch_scc0 33                                          // 0000003ECC6C: BFA10021 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x22f4>
	s_and_b32 vcc_lo, exec_lo, s4                              // 0000003ECC70: 8B6A047E
	s_cbranch_vccz 63581                                       // 0000003ECC74: BFA3F85D <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	s_branch 214                                               // 0000003ECC78: BFA000D6 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x25d4>
	v_lshlrev_b32_e32 v7, 2, v0                                // 0000003ECC7C: 300E0082
	ds_load_2addr_stride64_b32 v[1:2], v7 offset1:4            // 0000003ECC80: D8E00400 01000007
	ds_load_2addr_stride64_b32 v[3:4], v7 offset0:8 offset1:12 // 0000003ECC88: D8E00C08 03000007
	ds_load_2addr_stride64_b32 v[5:6], v7 offset0:16 offset1:20// 0000003ECC90: D8E01410 05000007
	s_waitcnt lgkmcnt(2)                                       // 0000003ECC98: BF89FC27
	v_add_f32_e32 v1, 0, v1                                    // 0000003ECC9C: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003ECCA0: BF8700A1
	v_add_f32_e32 v1, v1, v2                                   // 0000003ECCA4: 06020501
	s_waitcnt lgkmcnt(1)                                       // 0000003ECCA8: BF89FC17
	v_add_f32_e32 v3, v1, v3                                   // 0000003ECCAC: 06060701
	ds_load_2addr_stride64_b32 v[1:2], v7 offset0:24 offset1:28// 0000003ECCB0: D8E01C18 01000007
	v_add_f32_e32 v3, v3, v4                                   // 0000003ECCB8: 06060903
	s_waitcnt lgkmcnt(1)                                       // 0000003ECCBC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003ECCC0: BF870091
	v_add_f32_e32 v3, v3, v5                                   // 0000003ECCC4: 06060B03
	v_add_f32_e32 v3, v3, v6                                   // 0000003ECCC8: 06060D03
	s_waitcnt lgkmcnt(0)                                       // 0000003ECCCC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003ECCD0: BF870091
	v_add_f32_e32 v1, v3, v1                                   // 0000003ECCD4: 06020303
	v_add_f32_e32 v1, v1, v2                                   // 0000003ECCD8: 06020501
	ds_store_b32 v7, v1 offset:8192                            // 0000003ECCDC: D8342000 00000107
	s_or_b32 exec_lo, exec_lo, s4                              // 0000003ECCE4: 8C7E047E
	s_cmp_lt_i32 s21, 2                                        // 0000003ECCE8: BF048215
	s_mov_b32 s4, -1                                           // 0000003ECCEC: BE8400C1
	s_cbranch_scc1 65503                                       // 0000003ECCF0: BFA2FFDF <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2270>
	s_load_b128 s[4:7], s[0:1], 0x1a8                          // 0000003ECCF4: F4080100 F80001A8
	s_lshl_b64 s[8:9], s[30:31], 2                             // 0000003ECCFC: 8488821E
	s_waitcnt lgkmcnt(0)                                       // 0000003ECD00: BF89FC07
	s_barrier                                                  // 0000003ECD04: BFBD0000
	buffer_gl0_inv                                             // 0000003ECD08: E0AC0000 00000000
	s_add_u32 s1, s4, s8                                       // 0000003ECD10: 80010804
	s_addc_u32 s4, s5, s9                                      // 0000003ECD14: 82040905
	s_and_saveexec_b32 s0, s3                                  // 0000003ECD18: BE802003
	s_cbranch_execz 41                                         // 0000003ECD1C: BFA50029 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x23c4>
	v_lshrrev_b32_e32 v1, 7, v0                                // 0000003ECD20: 32020087
	s_ashr_i32 s5, s20, 31                                     // 0000003ECD24: 86059F14
	v_lshlrev_b32_e32 v4, 2, v0                                // 0000003ECD28: 30080082
	s_lshl_b32 s8, s26, 7                                      // 0000003ECD2C: 8408871A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003ECD30: BF870009
	s_ashr_i32 s9, s8, 31                                      // 0000003ECD34: 86099F08
	v_lshl_or_b32 v1, s23, 1, v1                               // 0000003ECD38: D6560001 04050217
	ds_load_b32 v4, v4 offset:8192                             // 0000003ECD40: D8D82000 04000004
	s_lshl_b64 s[8:9], s[8:9], 2                               // 0000003ECD48: 84888208
	.long 0xd72c0003                                           // 0000003ECD4C: D72C0003
	v_cndmask_b32_e32 v0, v1, v5, vcc_lo                       // 0000003ECD50: 02000B01
	v_mad_u64_u32 v[1:2], null, v1, s20, 0                     // 0000003ECD54: D6FE7C01 02002901
	s_ashr_i32 s5, s23, 31                                     // 0000003ECD5C: 86059F17
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000003ECD60: BF870499
	s_mul_i32 s5, s5, s20                                      // 0000003ECD64: 96051405
	v_add3_u32 v2, v2, v3, s5                                  // 0000003ECD68: D6550002 00160702
	v_and_b32_e32 v3, 0x7f, v0                                 // 0000003ECD70: 360600FF 0000007F
	s_add_u32 s5, s1, s8                                       // 0000003ECD78: 80050801
	s_addc_u32 s8, s4, s9                                      // 0000003ECD7C: 82080904
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003ECD80: BF870112
	.long 0xd73c0001                                           // 0000003ECD84: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000003ECD88: 02020282
	v_lshlrev_b32_e32 v3, 2, v3                                // 0000003ECD8C: 30060682
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003ECD90: BF870092
	.long 0xd7006a01                                           // 0000003ECD94: D7006A01
	v_cndmask_b32_e32 v1, s5, v1, vcc_lo                       // 0000003ECD98: 02020205
	v_add_co_ci_u32_e64 v2, null, s8, v2, vcc_lo               // 0000003ECD9C: D5207C02 01AA0408
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003ECDA4: BF870092
	.long 0xd7006a01                                           // 0000003ECDA8: D7006A01
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 0000003ECDAC: 02020701
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 0000003ECDB0: D5207C02 01AA0480
	s_waitcnt lgkmcnt(0)                                       // 0000003ECDB8: BF89FC07
	global_store_b32 v[1:2], v4, off                           // 0000003ECDBC: DC6A0000 007C0401
	s_or_b32 exec_lo, exec_lo, s0                              // 0000003ECDC4: 8C7E007E
	s_ashr_i32 s29, s28, 31                                    // 0000003ECDC8: 861D9F1C
	.long 0xd44a0000                                           // 0000003ECDCC: D44A0000
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 0000003ECDD0: 02020080
	s_lshl_b64 s[8:9], s[28:29], 2                             // 0000003ECDD4: 8488821C
	s_waitcnt_vscnt null, 0x0                                  // 0000003ECDD8: BC7C0000
	buffer_gl1_inv                                             // 0000003ECDDC: E0B00000 00000000
	buffer_gl0_inv                                             // 0000003ECDE4: E0AC0000 00000000
	s_add_u32 s5, s6, s8                                       // 0000003ECDEC: 80050806
	s_addc_u32 s6, s7, s9                                      // 0000003ECDF0: 82060907
	s_barrier                                                  // 0000003ECDF4: BFBD0000
	buffer_gl0_inv                                             // 0000003ECDF8: E0AC0000 00000000
	s_and_saveexec_b32 s7, s0                                  // 0000003ECE00: BE872000
	s_cbranch_execz 29                                         // 0000003ECE04: BFA5001D <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x247c>
	s_mov_b32 s9, exec_lo                                      // 0000003ECE08: BE89007E
	s_mov_b32 s8, exec_lo                                      // 0000003ECE0C: BE88007E
	.long 0xd71f0001                                           // 0000003ECE10: D71F0001
	v_cndmask_b32_e32 v0, s9, v128, vcc_lo                     // 0000003ECE14: 02010009
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003ECE18: BF870001
	v_cmpx_eq_u32_e32 0, v1                                    // 0000003ECE1C: 7D940280
	s_cbranch_execz 9                                          // 0000003ECE20: BFA50009 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2448>
	s_lshl_b64 s[10:11], s[26:27], 2                           // 0000003ECE24: 848A821A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000003ECE28: BF8704B9
	s_add_u32 s10, s5, s10                                     // 0000003ECE2C: 800A0A05
	s_addc_u32 s11, s6, s11                                    // 0000003ECE30: 820B0B06
	s_bcnt1_i32_b32 s9, s9                                     // 0000003ECE34: BE891809
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, s9              // 0000003ECE38: CA100080 02020009
	global_atomic_add_u32 v2, v2, v3, s[10:11] glc             // 0000003ECE40: DCD64000 020A0302
	s_or_b32 exec_lo, exec_lo, s8                              // 0000003ECE48: 8C7E087E
	s_waitcnt vmcnt(0)                                         // 0000003ECE4C: BF8903F7
	v_readfirstlane_b32 s8, v2                                 // 0000003ECE50: 7E100502
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003ECE54: BF870001
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s8, v1       // 0000003ECE58: CA200080 02000208
	s_add_i32 s8, s21, -1                                      // 0000003ECE60: 8108C115
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000003ECE64: BF870481
	v_cmp_eq_u32_e32 vcc_lo, s8, v1                            // 0000003ECE68: 7C940208
	v_cndmask_b32_e64 v1, 0, 1, vcc_lo                         // 0000003ECE6C: D5010001 01A90280
	ds_store_b32 v2, v1 offset:10240                           // 0000003ECE74: D8342800 00000102
	s_or_b32 exec_lo, exec_lo, s7                              // 0000003ECE7C: 8C7E077E
	v_mov_b32_e32 v1, 0                                        // 0000003ECE80: 7E020280
	s_waitcnt lgkmcnt(0)                                       // 0000003ECE84: BF89FC07
	s_barrier                                                  // 0000003ECE88: BFBD0000
	buffer_gl0_inv                                             // 0000003ECE8C: E0AC0000 00000000
	ds_load_b32 v1, v1 offset:10240                            // 0000003ECE94: D8D82800 01000001
	s_waitcnt lgkmcnt(0)                                       // 0000003ECE9C: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 0000003ECEA0: 7C940280
	s_cbranch_vccnz 74                                         // 0000003ECEA4: BFA4004A <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x25d0>
	buffer_gl1_inv                                             // 0000003ECEA8: E0B00000 00000000
	buffer_gl0_inv                                             // 0000003ECEB0: E0AC0000 00000000
	s_and_saveexec_b32 s7, s3                                  // 0000003ECEB8: BE872003
	s_cbranch_execz 56                                         // 0000003ECEBC: BFA50038 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x25a0>
	v_and_b32_e32 v2, 0x7f, v0                                 // 0000003ECEC0: 360400FF 0000007F
	s_lshl_b32 s8, s26, 7                                      // 0000003ECEC8: 8408871A
	s_ashr_i32 s3, s20, 31                                     // 0000003ECECC: 86039F14
	s_ashr_i32 s9, s8, 31                                      // 0000003ECED0: 86099F08
	v_lshrrev_b32_e32 v1, 7, v0                                // 0000003ECED4: 32020087
	v_dual_mov_b32 v2, 0 :: v_dual_lshlrev_b32 v3, 2, v2       // 0000003ECED8: CA220080 02020482
	s_lshl_b64 s[8:9], s[8:9], 2                               // 0000003ECEE0: 84888208
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003ECEE4: BF8700A9
	s_add_u32 s1, s1, s8                                       // 0000003ECEE8: 80010801
	s_addc_u32 s4, s4, s9                                      // 0000003ECEEC: 82040904
	.long 0xd7000103                                           // 0000003ECEF0: D7000103
	v_cndmask_b32_e32 v1, s1, v3, vcc_lo                       // 0000003ECEF4: 02020601
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003ECEF8: BF870001
	v_add_co_ci_u32_e64 v4, null, s4, 0, s1                    // 0000003ECEFC: D5207C04 00050004
	s_mov_b32 s1, s20                                          // 0000003ECF04: BE810014
	s_nop 0                                                    // 0000003ECF08: BF800000
	s_nop 0                                                    // 0000003ECF0C: BF800000
	s_nop 0                                                    // 0000003ECF10: BF800000
	s_nop 0                                                    // 0000003ECF14: BF800000
	s_nop 0                                                    // 0000003ECF18: BF800000
	s_nop 0                                                    // 0000003ECF1C: BF800000
	s_nop 0                                                    // 0000003ECF20: BF800000
	s_nop 0                                                    // 0000003ECF24: BF800000
	s_nop 0                                                    // 0000003ECF28: BF800000
	s_nop 0                                                    // 0000003ECF2C: BF800000
	s_nop 0                                                    // 0000003ECF30: BF800000
	s_nop 0                                                    // 0000003ECF34: BF800000
	s_nop 0                                                    // 0000003ECF38: BF800000
	s_nop 0                                                    // 0000003ECF3C: BF800000
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000003ECF40: BF8704A9
	v_mad_u64_u32 v[5:6], null, v1, s1, 0                      // 0000003ECF44: D6FE7C05 02000301
	s_add_i32 s21, s21, -1                                     // 0000003ECF4C: 8115C115
	s_cmp_eq_u32 s21, 0                                        // 0000003ECF50: BF068015
	v_mad_u64_u32 v[6:7], null, v1, s3, v[6:7]                 // 0000003ECF54: D6FE7C06 04180701
	v_add_nc_u32_e32 v1, 2, v1                                 // 0000003ECF5C: 4A020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003ECF60: BF870092
	.long 0xd73c0005                                           // 0000003ECF64: D73C0005
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 0000003ECF68: 02020A82
	.long 0xd7006a05                                           // 0000003ECF6C: D7006A05
	v_cndmask_b32_e32 v1, v3, v5, vcc_lo                       // 0000003ECF70: 02020B03
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003ECF74: BF870001
	v_add_co_ci_u32_e64 v6, null, v4, v6, vcc_lo               // 0000003ECF78: D5207C06 01AA0D04
	global_load_b32 v5, v[5:6], off glc                        // 0000003ECF80: DC524000 057C0005
	s_waitcnt vmcnt(0)                                         // 0000003ECF88: BF8903F7
	v_add_f32_e32 v2, v2, v5                                   // 0000003ECF8C: 06040B02
	s_cbranch_scc0 65515                                       // 0000003ECF90: BFA1FFEB <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2540>
	v_lshlrev_b32_e32 v1, 2, v0                                // 0000003ECF94: 30020082
	ds_store_b32 v1, v2 offset:8192                            // 0000003ECF98: D8342000 00000201
	s_or_b32 exec_lo, exec_lo, s7                              // 0000003ECFA0: 8C7E077E
	s_and_saveexec_b32 s1, s0                                  // 0000003ECFA4: BE812000
	s_cbranch_execz 6                                          // 0000003ECFA8: BFA50006 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x25c4>
	s_lshl_b64 s[8:9], s[26:27], 2                             // 0000003ECFAC: 8488821A
	v_mov_b32_e32 v1, 0                                        // 0000003ECFB0: 7E020280
	s_add_u32 s4, s5, s8                                       // 0000003ECFB4: 80040805
	s_addc_u32 s5, s6, s9                                      // 0000003ECFB8: 82050906
	global_store_b32 v1, v1, s[4:5]                            // 0000003ECFBC: DC6A0000 00040101
	s_or_b32 exec_lo, exec_lo, s1                              // 0000003ECFC4: 8C7E017E
	s_cbranch_execz 63368                                      // 0000003ECFC8: BFA5F788 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	s_branch 1                                                 // 0000003ECFCC: BFA00001 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x25d4>
	s_branch 63366                                             // 0000003ECFD0: BFA0F786 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	v_cmp_gt_i32_e32 vcc_lo, s18, v40                          // 0000003ECFD4: 7C885012
	.long 0xd44c0000                                           // 0000003ECFD8: D44C0000
	v_cndmask_b32_e32 v1, 64, v0, vcc_lo                       // 0000003ECFDC: 020200C0
	s_waitcnt lgkmcnt(0)                                       // 0000003ECFE0: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 0000003ECFE4: BC7C0000
	s_barrier                                                  // 0000003ECFE8: BFBD0000
	buffer_gl0_inv                                             // 0000003ECFEC: E0AC0000 00000000
	s_and_b32 s0, vcc_lo, s0                                   // 0000003ECFF4: 8B00006A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003ECFF8: BF870009
	s_and_saveexec_b32 s1, s0                                  // 0000003ECFFC: BE812000
	s_cbranch_execz 63354                                      // 0000003ED000: BFA5F77A <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	v_and_b32_e32 v1, 15, v0                                   // 0000003ED004: 3602008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003ED008: BF870091
	v_lshlrev_b32_e32 v2, 2, v1                                // 0000003ED00C: 30040282
	v_lshl_or_b32 v2, v40, 9, v2                               // 0000003ED010: D6560002 04091328
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003ED018: BF870001
	v_add_nc_u32_e32 v8, 0x2000, v2                            // 0000003ED01C: 4A1004FF 00002000
	ds_load_2addr_b32 v[2:3], v8 offset1:16                    // 0000003ED024: D8DC1000 02000008
	ds_load_2addr_b32 v[4:5], v8 offset0:32 offset1:48         // 0000003ED02C: D8DC3020 04000008
	ds_load_2addr_b32 v[6:7], v8 offset0:64 offset1:80         // 0000003ED034: D8DC5040 06000008
	ds_load_2addr_b32 v[8:9], v8 offset0:96 offset1:112        // 0000003ED03C: D8DC7060 08000008
	v_and_b32_e32 v10, 1, v0                                   // 0000003ED044: 36140081
	v_and_b32_e32 v11, 2, v0                                   // 0000003ED048: 36160082
	s_waitcnt lgkmcnt(3)                                       // 0000003ED04C: BF89FC37
	v_dual_add_f32 v13, v2, v3 :: v_dual_and_b32 v12, 4, v0    // 0000003ED050: C9240702 0D0C0084
	s_waitcnt lgkmcnt(2)                                       // 0000003ED058: BF89FC27
	v_dual_sub_f32 v2, v2, v3 :: v_dual_add_f32 v3, v4, v5     // 0000003ED05C: C9480702 02020B04
	s_waitcnt lgkmcnt(1)                                       // 0000003ED064: BF89FC17
	v_dual_sub_f32 v4, v4, v5 :: v_dual_add_f32 v5, v6, v7     // 0000003ED068: C9480B04 04040F06
	s_waitcnt lgkmcnt(0)                                       // 0000003ED070: BF89FC07
	v_dual_sub_f32 v6, v6, v7 :: v_dual_add_f32 v7, v8, v9     // 0000003ED074: C9480F06 06061308
	v_dual_sub_f32 v8, v8, v9 :: v_dual_add_f32 v9, v13, v3    // 0000003ED07C: C9481308 0808070D
	v_sub_f32_e32 v3, v13, v3                                  // 0000003ED084: 0806070D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000003ED088: BF870243
	v_dual_add_f32 v13, v2, v4 :: v_dual_add_f32 v14, v5, v7   // 0000003ED08C: C9080902 0D0E0F05
	v_dual_sub_f32 v2, v2, v4 :: v_dual_sub_f32 v5, v5, v7     // 0000003ED094: C94A0902 02040F05
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 0000003ED09C: 7C941480
	.long 0xd44a0000                                           // 0000003ED0A0: D44A0000
	v_cndmask_b32_e32 v1, 0, v12, vcc_lo                       // 0000003ED0A4: 02021880
	v_dual_add_f32 v7, v9, v14 :: v_dual_add_f32 v4, v6, v8    // 0000003ED0A8: C9081D09 07041106
	v_sub_f32_e32 v6, v6, v8                                   // 0000003ED0B0: 080C1106
	v_sub_f32_e32 v8, v9, v14                                  // 0000003ED0B4: 08101D09
	s_delay_alu instid0(VALU_DEP_3)                            // 0000003ED0B8: BF870003
	v_add_f32_e32 v9, v13, v4                                  // 0000003ED0BC: 0612090D
	v_dual_sub_f32 v4, v13, v4 :: v_dual_add_f32 v13, v3, v5   // 0000003ED0C0: C948090D 040C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 0000003ED0C8: 08060B03
	v_add_f32_e32 v5, v2, v6                                   // 0000003ED0CC: 060A0D02
	v_sub_f32_e32 v2, v2, v6                                   // 0000003ED0D0: 08040D02
	v_mov_b32_dpp v6, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003ED0D4: 7E0C02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 0000003ED0DC: D5010007 21AA0F07
	v_mov_b32_dpp v10, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003ED0E4: 7E1402FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 0000003ED0EC: D5010009 21AA1309
	v_mov_b32_dpp v14, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003ED0F4: 7E1C02FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 0000003ED0FC: D501000D 21AA1B0D
	v_mov_b32_dpp v15, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003ED104: 7E1E02FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 0000003ED10C: D5010005 21AA0B05
	v_mov_b32_dpp v16, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003ED114: 7E2002FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 0000003ED11C: D5010008 21AA1108
	v_mov_b32_dpp v17, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003ED124: 7E2202FA FF016104
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 0000003ED12C: D5010004 21AA0904
	v_mov_b32_dpp v18, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003ED134: 7E2402FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 0000003ED13C: D5010003 21AA0703
	v_mov_b32_dpp v19, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000003ED144: 7E2602FA FF016102
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 0000003ED14C: D5010002 21AA0502
	v_dual_add_f32 v6, v7, v6 :: v_dual_add_f32 v5, v5, v15    // 0000003ED154: C9080D07 06041F05
	v_cmp_eq_u32_e32 vcc_lo, 0, v11                            // 0000003ED15C: 7C941680
	v_dual_add_f32 v7, v9, v10 :: v_dual_add_f32 v8, v8, v16   // 0000003ED160: C9081509 07082108
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000003ED168: BF870233
	v_mov_b32_dpp v10, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003ED16C: 7E1402FA FF016206
	v_add_f32_e32 v4, v4, v17                                  // 0000003ED174: 06082304
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 0000003ED178: D5010006 21AA0D06
	v_mov_b32_dpp v11, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003ED180: 7E1602FA FF016207
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 0000003ED188: D5010007 21AA0F07
	v_add_f32_e32 v2, v2, v19                                  // 0000003ED190: 06042702
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003ED194: BF870092
	v_dual_add_f32 v6, v6, v10 :: v_dual_add_f32 v7, v7, v11   // 0000003ED198: C9081506 06061707
	v_mov_b32_dpp v10, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003ED1A0: 7E1402FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s0                          // 0000003ED1A8: D5010006 20020D06
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000003ED1B0: BF8700D3
	v_mov_b32_dpp v11, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003ED1B4: 7E1602FA FF016407
	v_cndmask_b32_e64 v7, -v7, v7, s0                          // 0000003ED1BC: D5010007 20020F07
	v_add_f32_e32 v9, v13, v14                                 // 0000003ED1C4: 06121D0D
	v_mov_b32_dpp v14, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003ED1C8: 7E1C02FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 0000003ED1D0: D5010005 21AA0B05
	v_dual_add_f32 v15, v5, v14 :: v_dual_add_f32 v14, v7, v11 // 0000003ED1D8: C9081D05 0F0E1707
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003ED1E0: BF8701A4
	v_mov_b32_dpp v13, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003ED1E4: 7E1A02FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 0000003ED1EC: D5010009 21AA1309
	v_mov_b32_dpp v7, v15 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003ED1F4: 7E0E02FA FF01640F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003ED1FC: BF870194
	v_mov_b32_dpp v23, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003ED200: 7E2E02FA FF01680E
	v_add_f32_e32 v9, v9, v13                                  // 0000003ED208: 06121B09
	v_mov_b32_dpp v13, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003ED20C: 7E1A02FA FF016208
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003ED214: BF8700A2
	v_mov_b32_dpp v12, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003ED218: 7E1802FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 0000003ED220: D5010009 20021309
	v_add_f32_e32 v21, v9, v12                                 // 0000003ED228: 062A1909
	v_mov_b32_dpp v12, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003ED22C: 7E1802FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 0000003ED234: D5010002 21AA0502
	v_add_f32_e32 v3, v3, v18                                  // 0000003ED23C: 06062503
	v_cndmask_b32_e64 v9, -v15, v15, s0                        // 0000003ED240: D5010009 20021F0F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003ED248: BF870193
	v_add_f32_e32 v2, v2, v12                                  // 0000003ED24C: 06041902
	v_mov_b32_dpp v11, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003ED250: 7E1602FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 0000003ED258: D5010003 21AA0703
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003ED260: BF870114
	v_add_f32_e32 v19, v9, v7                                  // 0000003ED264: 06260F09
	v_add_f32_e32 v3, v3, v11                                  // 0000003ED268: 06061703
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003ED26C: BF870112
	v_mov_b32_dpp v20, v19 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003ED270: 7E2802FA FF016813
	v_mov_b32_dpp v12, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003ED278: 7E1802FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 0000003ED280: D5010003 20020703
	v_add_f32_e32 v5, v6, v10                                  // 0000003ED288: 060A1506
	v_cndmask_b32_e64 v6, -v8, v8, vcc_lo                      // 0000003ED28C: D5010006 21AA1108
	v_mov_b32_dpp v10, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000003ED294: 7E1402FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 0000003ED29C: D5010004 21AA0904
	v_add_f32_e32 v12, v3, v12                                 // 0000003ED2A4: 06181903
	v_mov_b32_dpp v8, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003ED2A8: 7E1002FA FF016805
	v_add_f32_e32 v6, v6, v13                                  // 0000003ED2B0: 060C1B06
	v_mov_b32_dpp v13, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003ED2B4: 7E1A02FA FF016402
	v_add_f32_e32 v4, v4, v10                                  // 0000003ED2BC: 06081504
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 0000003ED2C0: D5010002 20020502
	v_mov_b32_dpp v22, v21 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003ED2C8: 7E2C02FA FF016815
	v_mov_b32_dpp v10, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003ED2D0: 7E1402FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s0                          // 0000003ED2D8: D5010006 20020D06
	v_mov_b32_dpp v11, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000003ED2E0: 7E1602FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 0000003ED2E8: D5010004 20020904
	v_add_f32_e32 v9, v2, v13                                  // 0000003ED2F0: 06121B02
	v_mov_b32_dpp v13, v12 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003ED2F4: 7E1A02FA FF01680C
	v_add_f32_e32 v17, v6, v10                                 // 0000003ED2FC: 06221506
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003ED300: BF870214
	v_add_f32_e32 v15, v4, v11                                 // 0000003ED304: 061E1704
	v_mov_b32_dpp v10, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003ED308: 7E1402FA FF016809
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003ED310: BF870193
	v_mov_b32_dpp v18, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003ED314: 7E2402FA FF016811
	v_mov_b32_dpp v16, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000003ED31C: 7E2002FA FF01680F
	s_and_b32 exec_lo, exec_lo, s2                             // 0000003ED324: 8B7E027E
	s_cbranch_execz 63152                                      // 0000003ED328: BFA5F6B0 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	v_lshl_or_b32 v3, s26, 7, v1                               // 0000003ED32C: D6560003 04050E1A
	v_and_b32_e32 v0, 8, v0                                    // 0000003ED334: 36000088
	s_cmp_lg_u64 s[24:25], 0                                   // 0000003ED338: BF118018
	s_cselect_b32 s1, -1, 0                                    // 0000003ED33C: 980180C1
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003ED340: BF870112
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000003ED344: 3408069F
	.long 0xd44a0000                                           // 0000003ED348: D44A0000
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 0000003ED34C: 02020080
	s_lshr_b32 s2, s20, 31                                     // 0000003ED350: 85029F14
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003ED354: BF870009
	s_add_i32 s2, s20, s2                                      // 0000003ED358: 81020214
	.long 0xd73c0001                                           // 0000003ED35C: D73C0001
	v_cndmask_b32_e32 v1, 1, v3, vcc_lo                        // 0000003ED360: 02020681
	v_cndmask_b32_e64 v0, -v5, v5, s0                          // 0000003ED364: D5010000 20020B05
	v_mad_i64_i32 v[4:5], null, s20, v40, 0                    // 0000003ED36C: D6FF7C04 02025014
	s_ashr_i32 s2, s2, 1                                       // 0000003ED374: 86028102
	s_cmp_eq_u64 s[24:25], 0                                   // 0000003ED378: BF108018
	v_mad_i64_i32 v[24:25], null, s2, v40, 0                   // 0000003ED37C: D6FF7C18 02025002
	.long 0xd7006a06                                           // 0000003ED384: D7006A06
	v_cndmask_b32_e32 v1, s12, v1, vcc_lo                      // 0000003ED388: 0202020C
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003ED38C: BF870001
	v_add_co_ci_u32_e64 v7, null, s13, v2, vcc_lo              // 0000003ED390: D5207C07 01AA040D
	v_add_f32_e32 v0, v0, v8                                   // 0000003ED398: 06001100
	.long 0xd73c0004                                           // 0000003ED39C: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 0000003ED3A0: 02020881
	global_load_d16_b16 v11, v[6:7], off                       // 0000003ED3A4: DC820000 0B7C0006
	v_mul_f32_e32 v0, 0x3db504f3, v0                           // 0000003ED3AC: 100000FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 0000003ED3B4: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003ED3B8: BF8700A1
	v_fma_mix_f32 v26, v11, v0, neg(0) op_sel_hi:[1,0,0]       // 0000003ED3BC: CC20001A 8A02010B
	.long 0xd7006a00                                           // 0000003ED3C4: D7006A00
	v_cndmask_b32_e32 v1, s14, v4, vcc_lo                      // 0000003ED3C8: 0202080E
	v_add_co_ci_u32_e64 v8, null, s15, v5, vcc_lo              // 0000003ED3CC: D5207C08 01AA0A0F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000003ED3D4: BF8701B3
	v_bfe_u32 v27, v26, 16, 1                                  // 0000003ED3D8: D610001B 0205211A
	.long 0xd73c0004                                           // 0000003ED3E0: D73C0004
	v_cndmask_b32_e32 v1, 1, v24, vcc_lo                       // 0000003ED3E4: 02023081
	v_ashrrev_i32_e32 v11, 31, v3                              // 0000003ED3E8: 3416069F
	v_add3_u32 v24, v26, v27, 0x7fff                           // 0000003ED3EC: D6550018 03FE371A 00007FFF
	s_cbranch_scc1 569                                         // 0000003ED3F8: BFA20239 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x32e0>
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003ED3FC: BF870122
	v_lshrrev_b32_e32 v25, 23, v11                             // 0000003ED400: 32321697
	v_mov_b32_e32 v29, s14                                     // 0000003ED404: 7E3A020E
	v_add_nc_u32_e32 v25, v3, v25                              // 0000003ED408: 4A323303
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003ED40C: BF870091
	v_and_b32_e32 v26, 0xfffffe00, v25                         // 0000003ED410: 363432FF FFFFFE00
	v_sub_nc_u32_e32 v27, v3, v26                              // 0000003ED418: 4C363503
	v_mov_b32_e32 v26, s15                                     // 0000003ED41C: 7E34020F
	v_ashrrev_i32_e32 v25, 9, v25                              // 0000003ED420: 34323289
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003ED424: BF8701A3
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v27                        // 0000003ED428: 7C8836FF 00000100
	v_add_nc_u32_e32 v28, 0xffffff00, v27                      // 0000003ED430: 4A3836FF FFFFFF00
	v_dual_cndmask_b32 v30, s25, v26 :: v_dual_lshlrev_b32 v25, 8, v25// 0000003ED438: CA623419 1E183288
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003ED440: BF870112
	v_cndmask_b32_e32 v27, v28, v27, vcc_lo                    // 0000003ED444: 0236371C
	v_ashrrev_i32_e32 v26, 31, v25                             // 0000003ED448: 3434329F
	v_cndmask_b32_e32 v29, s24, v29, vcc_lo                    // 0000003ED44C: 023A3A18
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003ED450: BF870193
	v_ashrrev_i32_e32 v28, 31, v27                             // 0000003ED454: 3438369F
	.long 0xd73c0019                                           // 0000003ED458: D73C0019
	v_cndmask_b32_e32 v1, 1, v25, vcc_lo                       // 0000003ED45C: 02023281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003ED460: BF870093
	.long 0xd7006a1d                                           // 0000003ED464: D7006A1D
	v_cndmask_b32_e32 v1, v29, v4, vcc_lo                      // 0000003ED468: 0202091D
	v_add_co_ci_u32_e64 v30, null, v30, v5, vcc_lo             // 0000003ED46C: D5207C1E 01AA0B1E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003ED474: BF870194
	.long 0xd73c001b                                           // 0000003ED478: D73C001B
	v_cndmask_b32_e32 v1, 1, v27, vcc_lo                       // 0000003ED47C: 02023681
	.long 0xd7006a19                                           // 0000003ED480: D7006A19
	v_cndmask_b32_e32 v1, v29, v25, vcc_lo                     // 0000003ED484: 0202331D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003ED488: BF870111
	v_add_co_ci_u32_e64 v26, null, v30, v26, vcc_lo            // 0000003ED48C: D5207C1A 01AA351E
	.long 0xd7006a19                                           // 0000003ED494: D7006A19
	v_cndmask_b32_e32 v1, v25, v27, vcc_lo                     // 0000003ED498: 02023719
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003ED49C: BF870001
	v_add_co_ci_u32_e64 v26, null, v26, v28, vcc_lo            // 0000003ED4A0: D5207C1A 01AA391A
	global_store_d16_hi_b16 v[25:26], v24, off                 // 0000003ED4A8: DC960000 007C1819
	s_cbranch_execnz 7                                         // 0000003ED4B0: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2ad0>
	.long 0xd7006a19                                           // 0000003ED4B4: D7006A19
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 0000003ED4B8: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003ED4BC: BF870001
	v_add_co_ci_u32_e64 v26, null, v8, v2, vcc_lo              // 0000003ED4C0: D5207C1A 01AA0508
	global_store_d16_hi_b16 v[25:26], v24, off                 // 0000003ED4C8: DC960000 007C1819
	global_load_d16_b16 v24, v[6:7], off offset:32             // 0000003ED4D0: DC820020 187C0006
	v_cndmask_b32_e64 v14, -v14, v14, s0                       // 0000003ED4D8: D501000E 20021D0E
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000003ED4E0: 916A017E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003ED4E4: BF870091
	v_add_f32_e32 v14, v14, v23                                // 0000003ED4E8: 061C2F0E
	v_mul_f32_e32 v14, 0x3db504f3, v14                         // 0000003ED4EC: 101C1CFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 0000003ED4F4: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003ED4F8: BF870121
	v_fma_mix_f32 v23, v24, v14, neg(0) op_sel_hi:[1,0,0]      // 0000003ED4FC: CC200017 8A021D18
	v_cndmask_b32_e64 v14, 0, 1, s1                            // 0000003ED504: D501000E 00050280
	v_bfe_u32 v24, v23, 16, 1                                  // 0000003ED50C: D6100018 02052117
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003ED514: BF870001
	v_add3_u32 v23, v23, v24, 0x7fff                           // 0000003ED518: D6550017 03FE3117 00007FFF
	s_cbranch_vccnz 495                                        // 0000003ED524: BFA401EF <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x32e4>
	v_or_b32_e32 v24, 16, v3                                   // 0000003ED528: 38300690
	v_lshrrev_b32_e32 v25, 23, v11                             // 0000003ED52C: 32321697
	v_mov_b32_e32 v27, s15                                     // 0000003ED530: 7E36020F
	v_mov_b32_e32 v29, s14                                     // 0000003ED534: 7E3A020E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003ED538: BF870093
	v_add_nc_u32_e32 v25, v24, v25                             // 0000003ED53C: 4A323318
	v_and_b32_e32 v26, 0xfffffe00, v25                         // 0000003ED540: 363432FF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003ED548: BF870091
	v_sub_nc_u32_e32 v26, v24, v26                             // 0000003ED54C: 4C343518
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v26                        // 0000003ED550: 7C8834FF 00000100
	v_add_nc_u32_e32 v28, 0xffffff00, v26                      // 0000003ED558: 4A3834FF FFFFFF00
	v_cndmask_b32_e32 v30, s25, v27, vcc_lo                    // 0000003ED560: 023C3619
	v_ashrrev_i32_e32 v25, 9, v25                              // 0000003ED564: 34323289
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003ED568: BF8701A3
	v_cndmask_b32_e32 v26, v28, v26, vcc_lo                    // 0000003ED56C: 0234351C
	v_cndmask_b32_e32 v28, s24, v29, vcc_lo                    // 0000003ED570: 02383A18
	v_lshlrev_b32_e32 v24, 8, v25                              // 0000003ED574: 30303288
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003ED578: BF870193
	v_ashrrev_i32_e32 v27, 31, v26                             // 0000003ED57C: 3436349F
	.long 0xd7006a1c                                           // 0000003ED580: D7006A1C
	v_cndmask_b32_e32 v1, v28, v4, vcc_lo                      // 0000003ED584: 0202091C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003ED588: BF870211
	v_add_co_ci_u32_e64 v29, null, v30, v5, vcc_lo             // 0000003ED58C: D5207C1D 01AA0B1E
	v_ashrrev_i32_e32 v25, 31, v24                             // 0000003ED594: 3432309F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003ED598: BF870114
	.long 0xd73c001a                                           // 0000003ED59C: D73C001A
	v_cndmask_b32_e32 v1, 1, v26, vcc_lo                       // 0000003ED5A0: 02023481
	.long 0xd73c0018                                           // 0000003ED5A4: D73C0018
	v_cndmask_b32_e32 v1, 1, v24, vcc_lo                       // 0000003ED5A8: 02023081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003ED5AC: BF870091
	.long 0xd7006a18                                           // 0000003ED5B0: D7006A18
	v_cndmask_b32_e32 v1, v28, v24, vcc_lo                     // 0000003ED5B4: 0202311C
	v_add_co_ci_u32_e64 v25, null, v29, v25, vcc_lo            // 0000003ED5B8: D5207C19 01AA331D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003ED5C0: BF870092
	.long 0xd7006a18                                           // 0000003ED5C4: D7006A18
	v_cndmask_b32_e32 v1, v24, v26, vcc_lo                     // 0000003ED5C8: 02023518
	v_add_co_ci_u32_e64 v25, null, v25, v27, vcc_lo            // 0000003ED5CC: D5207C19 01AA3719
	global_store_d16_hi_b16 v[24:25], v23, off                 // 0000003ED5D4: DC960000 007C1718
	s_cbranch_execnz 7                                         // 0000003ED5DC: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2bfc>
	.long 0xd7006a18                                           // 0000003ED5E0: D7006A18
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 0000003ED5E4: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003ED5E8: BF870001
	v_add_co_ci_u32_e64 v25, null, v8, v2, vcc_lo              // 0000003ED5EC: D5207C19 01AA0508
	global_store_d16_hi_b16 v[24:25], v23, off offset:32       // 0000003ED5F4: DC960020 007C1718
	global_load_d16_b16 v23, v[6:7], off offset:64             // 0000003ED5FC: DC820040 177C0006
	v_cndmask_b32_e64 v21, -v21, v21, s0                       // 0000003ED604: D5010015 20022B15
	v_cmp_ne_u32_e32 vcc_lo, 1, v14                            // 0000003ED60C: 7C9A1C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003ED610: BF8700A2
	v_add_f32_e32 v21, v21, v22                                // 0000003ED614: 062A2D15
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 0000003ED618: 8B6A6A7E
	v_mul_f32_e32 v21, 0x3db504f3, v21                         // 0000003ED61C: 102A2AFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 0000003ED624: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003ED628: BF870091
	v_fma_mix_f32 v21, v23, v21, neg(0) op_sel_hi:[1,0,0]      // 0000003ED62C: CC200015 8A022B17
	v_bfe_u32 v22, v21, 16, 1                                  // 0000003ED634: D6100016 02052115
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003ED63C: BF870001
	v_add3_u32 v21, v21, v22, 0x7fff                           // 0000003ED640: D6550015 03FE2D15 00007FFF
	s_cbranch_vccnz 422                                        // 0000003ED64C: BFA401A6 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x32e8>
	v_or_b32_e32 v22, 32, v3                                   // 0000003ED650: 382C06A0
	v_lshrrev_b32_e32 v23, 23, v11                             // 0000003ED654: 322E1697
	v_mov_b32_e32 v25, s15                                     // 0000003ED658: 7E32020F
	v_mov_b32_e32 v27, s14                                     // 0000003ED65C: 7E36020E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003ED660: BF870093
	v_add_nc_u32_e32 v23, v22, v23                             // 0000003ED664: 4A2E2F16
	v_and_b32_e32 v24, 0xfffffe00, v23                         // 0000003ED668: 36302EFF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003ED670: BF870091
	v_sub_nc_u32_e32 v24, v22, v24                             // 0000003ED674: 4C303116
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v24                        // 0000003ED678: 7C8830FF 00000100
	v_add_nc_u32_e32 v26, 0xffffff00, v24                      // 0000003ED680: 4A3430FF FFFFFF00
	v_cndmask_b32_e32 v28, s25, v25, vcc_lo                    // 0000003ED688: 02383219
	v_ashrrev_i32_e32 v23, 9, v23                              // 0000003ED68C: 342E2E89
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003ED690: BF8701A3
	v_cndmask_b32_e32 v24, v26, v24, vcc_lo                    // 0000003ED694: 0230311A
	v_cndmask_b32_e32 v26, s24, v27, vcc_lo                    // 0000003ED698: 02343618
	v_lshlrev_b32_e32 v22, 8, v23                              // 0000003ED69C: 302C2E88
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003ED6A0: BF870193
	v_ashrrev_i32_e32 v25, 31, v24                             // 0000003ED6A4: 3432309F
	.long 0xd7006a1a                                           // 0000003ED6A8: D7006A1A
	v_cndmask_b32_e32 v1, v26, v4, vcc_lo                      // 0000003ED6AC: 0202091A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003ED6B0: BF870211
	v_add_co_ci_u32_e64 v27, null, v28, v5, vcc_lo             // 0000003ED6B4: D5207C1B 01AA0B1C
	v_ashrrev_i32_e32 v23, 31, v22                             // 0000003ED6BC: 342E2C9F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003ED6C0: BF870114
	.long 0xd73c0018                                           // 0000003ED6C4: D73C0018
	v_cndmask_b32_e32 v1, 1, v24, vcc_lo                       // 0000003ED6C8: 02023081
	.long 0xd73c0016                                           // 0000003ED6CC: D73C0016
	v_cndmask_b32_e32 v1, 1, v22, vcc_lo                       // 0000003ED6D0: 02022C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003ED6D4: BF870091
	.long 0xd7006a16                                           // 0000003ED6D8: D7006A16
	v_cndmask_b32_e32 v1, v26, v22, vcc_lo                     // 0000003ED6DC: 02022D1A
	v_add_co_ci_u32_e64 v23, null, v27, v23, vcc_lo            // 0000003ED6E0: D5207C17 01AA2F1B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003ED6E8: BF870092
	.long 0xd7006a16                                           // 0000003ED6EC: D7006A16
	v_cndmask_b32_e32 v1, v22, v24, vcc_lo                     // 0000003ED6F0: 02023116
	v_add_co_ci_u32_e64 v23, null, v23, v25, vcc_lo            // 0000003ED6F4: D5207C17 01AA3317
	global_store_d16_hi_b16 v[22:23], v21, off                 // 0000003ED6FC: DC960000 007C1516
	s_cbranch_execnz 7                                         // 0000003ED704: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2d24>
	.long 0xd7006a16                                           // 0000003ED708: D7006A16
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 0000003ED70C: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003ED710: BF870001
	v_add_co_ci_u32_e64 v23, null, v8, v2, vcc_lo              // 0000003ED714: D5207C17 01AA0508
	global_store_d16_hi_b16 v[22:23], v21, off offset:64       // 0000003ED71C: DC960040 007C1516
	global_load_d16_b16 v21, v[6:7], off offset:96             // 0000003ED724: DC820060 157C0006
	v_cndmask_b32_e64 v19, -v19, v19, s0                       // 0000003ED72C: D5010013 20022713
	v_cmp_ne_u32_e32 vcc_lo, 1, v14                            // 0000003ED734: 7C9A1C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003ED738: BF8700A2
	v_add_f32_e32 v19, v19, v20                                // 0000003ED73C: 06262913
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 0000003ED740: 8B6A6A7E
	v_mul_f32_e32 v19, 0x3db504f3, v19                         // 0000003ED744: 102626FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 0000003ED74C: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003ED750: BF870091
	v_fma_mix_f32 v19, v21, v19, neg(0) op_sel_hi:[1,0,0]      // 0000003ED754: CC200013 8A022715
	v_bfe_u32 v20, v19, 16, 1                                  // 0000003ED75C: D6100014 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003ED764: BF870001
	v_add3_u32 v19, v19, v20, 0x7fff                           // 0000003ED768: D6550013 03FE2913 00007FFF
	s_cbranch_vccnz 349                                        // 0000003ED774: BFA4015D <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x32ec>
	v_or_b32_e32 v20, 48, v3                                   // 0000003ED778: 382806B0
	v_lshrrev_b32_e32 v21, 23, v11                             // 0000003ED77C: 322A1697
	v_mov_b32_e32 v23, s15                                     // 0000003ED780: 7E2E020F
	v_mov_b32_e32 v25, s14                                     // 0000003ED784: 7E32020E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003ED788: BF870093
	v_add_nc_u32_e32 v21, v20, v21                             // 0000003ED78C: 4A2A2B14
	v_and_b32_e32 v22, 0xfffffe00, v21                         // 0000003ED790: 362C2AFF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003ED798: BF870091
	v_sub_nc_u32_e32 v22, v20, v22                             // 0000003ED79C: 4C2C2D14
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v22                        // 0000003ED7A0: 7C882CFF 00000100
	v_add_nc_u32_e32 v24, 0xffffff00, v22                      // 0000003ED7A8: 4A302CFF FFFFFF00
	v_cndmask_b32_e32 v26, s25, v23, vcc_lo                    // 0000003ED7B0: 02342E19
	v_ashrrev_i32_e32 v21, 9, v21                              // 0000003ED7B4: 342A2A89
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003ED7B8: BF8701A3
	v_cndmask_b32_e32 v22, v24, v22, vcc_lo                    // 0000003ED7BC: 022C2D18
	v_cndmask_b32_e32 v24, s24, v25, vcc_lo                    // 0000003ED7C0: 02303218
	v_lshlrev_b32_e32 v20, 8, v21                              // 0000003ED7C4: 30282A88
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003ED7C8: BF870193
	v_ashrrev_i32_e32 v23, 31, v22                             // 0000003ED7CC: 342E2C9F
	.long 0xd7006a18                                           // 0000003ED7D0: D7006A18
	v_cndmask_b32_e32 v1, v24, v4, vcc_lo                      // 0000003ED7D4: 02020918
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003ED7D8: BF870211
	v_add_co_ci_u32_e64 v25, null, v26, v5, vcc_lo             // 0000003ED7DC: D5207C19 01AA0B1A
	v_ashrrev_i32_e32 v21, 31, v20                             // 0000003ED7E4: 342A289F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003ED7E8: BF870114
	.long 0xd73c0016                                           // 0000003ED7EC: D73C0016
	v_cndmask_b32_e32 v1, 1, v22, vcc_lo                       // 0000003ED7F0: 02022C81
	.long 0xd73c0014                                           // 0000003ED7F4: D73C0014
	v_cndmask_b32_e32 v1, 1, v20, vcc_lo                       // 0000003ED7F8: 02022881
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003ED7FC: BF870091
	.long 0xd7006a14                                           // 0000003ED800: D7006A14
	v_cndmask_b32_e32 v1, v24, v20, vcc_lo                     // 0000003ED804: 02022918
	v_add_co_ci_u32_e64 v21, null, v25, v21, vcc_lo            // 0000003ED808: D5207C15 01AA2B19
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003ED810: BF870092
	.long 0xd7006a14                                           // 0000003ED814: D7006A14
	v_cndmask_b32_e32 v1, v20, v22, vcc_lo                     // 0000003ED818: 02022D14
	v_add_co_ci_u32_e64 v21, null, v21, v23, vcc_lo            // 0000003ED81C: D5207C15 01AA2F15
	global_store_d16_hi_b16 v[20:21], v19, off                 // 0000003ED824: DC960000 007C1314
	s_cbranch_execnz 7                                         // 0000003ED82C: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2e4c>
	.long 0xd7006a14                                           // 0000003ED830: D7006A14
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 0000003ED834: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003ED838: BF870001
	v_add_co_ci_u32_e64 v21, null, v8, v2, vcc_lo              // 0000003ED83C: D5207C15 01AA0508
	global_store_d16_hi_b16 v[20:21], v19, off offset:96       // 0000003ED844: DC960060 007C1314
	global_load_d16_b16 v19, v[6:7], off offset:128            // 0000003ED84C: DC820080 137C0006
	v_cndmask_b32_e64 v17, -v17, v17, s0                       // 0000003ED854: D5010011 20022311
	v_cmp_ne_u32_e32 vcc_lo, 1, v14                            // 0000003ED85C: 7C9A1C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003ED860: BF8700A2
	v_add_f32_e32 v17, v17, v18                                // 0000003ED864: 06222511
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 0000003ED868: 8B6A6A7E
	v_mul_f32_e32 v17, 0x3db504f3, v17                         // 0000003ED86C: 102222FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 0000003ED874: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003ED878: BF870091
	v_fma_mix_f32 v17, v19, v17, neg(0) op_sel_hi:[1,0,0]      // 0000003ED87C: CC200011 8A022313
	v_bfe_u32 v18, v17, 16, 1                                  // 0000003ED884: D6100012 02052111
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003ED88C: BF870001
	v_add3_u32 v17, v17, v18, 0x7fff                           // 0000003ED890: D6550011 03FE2511 00007FFF
	s_cbranch_vccnz 276                                        // 0000003ED89C: BFA40114 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x32f0>
	v_or_b32_e32 v18, 64, v3                                   // 0000003ED8A0: 382406C0
	v_lshrrev_b32_e32 v19, 23, v11                             // 0000003ED8A4: 32261697
	v_mov_b32_e32 v21, s15                                     // 0000003ED8A8: 7E2A020F
	v_mov_b32_e32 v23, s14                                     // 0000003ED8AC: 7E2E020E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003ED8B0: BF870093
	v_add_nc_u32_e32 v19, v18, v19                             // 0000003ED8B4: 4A262712
	v_and_b32_e32 v20, 0xfffffe00, v19                         // 0000003ED8B8: 362826FF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003ED8C0: BF870091
	v_sub_nc_u32_e32 v20, v18, v20                             // 0000003ED8C4: 4C282912
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v20                        // 0000003ED8C8: 7C8828FF 00000100
	v_add_nc_u32_e32 v22, 0xffffff00, v20                      // 0000003ED8D0: 4A2C28FF FFFFFF00
	v_cndmask_b32_e32 v24, s25, v21, vcc_lo                    // 0000003ED8D8: 02302A19
	v_ashrrev_i32_e32 v19, 9, v19                              // 0000003ED8DC: 34262689
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003ED8E0: BF8701A3
	v_cndmask_b32_e32 v20, v22, v20, vcc_lo                    // 0000003ED8E4: 02282916
	v_cndmask_b32_e32 v22, s24, v23, vcc_lo                    // 0000003ED8E8: 022C2E18
	v_lshlrev_b32_e32 v18, 8, v19                              // 0000003ED8EC: 30242688
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003ED8F0: BF870193
	v_ashrrev_i32_e32 v21, 31, v20                             // 0000003ED8F4: 342A289F
	.long 0xd7006a16                                           // 0000003ED8F8: D7006A16
	v_cndmask_b32_e32 v1, v22, v4, vcc_lo                      // 0000003ED8FC: 02020916
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003ED900: BF870211
	v_add_co_ci_u32_e64 v23, null, v24, v5, vcc_lo             // 0000003ED904: D5207C17 01AA0B18
	v_ashrrev_i32_e32 v19, 31, v18                             // 0000003ED90C: 3426249F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003ED910: BF870114
	.long 0xd73c0014                                           // 0000003ED914: D73C0014
	v_cndmask_b32_e32 v1, 1, v20, vcc_lo                       // 0000003ED918: 02022881
	.long 0xd73c0012                                           // 0000003ED91C: D73C0012
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 0000003ED920: 02022481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003ED924: BF870091
	.long 0xd7006a12                                           // 0000003ED928: D7006A12
	v_cndmask_b32_e32 v1, v22, v18, vcc_lo                     // 0000003ED92C: 02022516
	v_add_co_ci_u32_e64 v19, null, v23, v19, vcc_lo            // 0000003ED930: D5207C13 01AA2717
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003ED938: BF870092
	.long 0xd7006a12                                           // 0000003ED93C: D7006A12
	v_cndmask_b32_e32 v1, v18, v20, vcc_lo                     // 0000003ED940: 02022912
	v_add_co_ci_u32_e64 v19, null, v19, v21, vcc_lo            // 0000003ED944: D5207C13 01AA2B13
	global_store_d16_hi_b16 v[18:19], v17, off                 // 0000003ED94C: DC960000 007C1112
	s_cbranch_execnz 7                                         // 0000003ED954: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2f74>
	.long 0xd7006a12                                           // 0000003ED958: D7006A12
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 0000003ED95C: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003ED960: BF870001
	v_add_co_ci_u32_e64 v19, null, v8, v2, vcc_lo              // 0000003ED964: D5207C13 01AA0508
	global_store_d16_hi_b16 v[18:19], v17, off offset:128      // 0000003ED96C: DC960080 007C1112
	global_load_d16_b16 v17, v[6:7], off offset:160            // 0000003ED974: DC8200A0 117C0006
	v_cndmask_b32_e64 v15, -v15, v15, s0                       // 0000003ED97C: D501000F 20021F0F
	v_cmp_ne_u32_e32 vcc_lo, 1, v14                            // 0000003ED984: 7C9A1C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003ED988: BF8700A2
	v_add_f32_e32 v15, v15, v16                                // 0000003ED98C: 061E210F
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 0000003ED990: 8B6A6A7E
	v_mul_f32_e32 v15, 0x3db504f3, v15                         // 0000003ED994: 101E1EFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 0000003ED99C: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003ED9A0: BF870091
	v_fma_mix_f32 v15, v17, v15, neg(0) op_sel_hi:[1,0,0]      // 0000003ED9A4: CC20000F 8A021F11
	v_bfe_u32 v16, v15, 16, 1                                  // 0000003ED9AC: D6100010 0205210F
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003ED9B4: BF870001
	v_add3_u32 v15, v15, v16, 0x7fff                           // 0000003ED9B8: D655000F 03FE210F 00007FFF
	s_cbranch_vccnz 203                                        // 0000003ED9C4: BFA400CB <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x32f4>
	v_or_b32_e32 v16, 0x50, v3                                 // 0000003ED9C8: 382006FF 00000050
	v_lshrrev_b32_e32 v17, 23, v11                             // 0000003ED9D0: 32221697
	v_mov_b32_e32 v19, s15                                     // 0000003ED9D4: 7E26020F
	v_mov_b32_e32 v21, s14                                     // 0000003ED9D8: 7E2A020E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003ED9DC: BF870093
	v_add_nc_u32_e32 v17, v16, v17                             // 0000003ED9E0: 4A222310
	v_and_b32_e32 v18, 0xfffffe00, v17                         // 0000003ED9E4: 362422FF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003ED9EC: BF870091
	v_sub_nc_u32_e32 v18, v16, v18                             // 0000003ED9F0: 4C242510
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v18                        // 0000003ED9F4: 7C8824FF 00000100
	v_add_nc_u32_e32 v20, 0xffffff00, v18                      // 0000003ED9FC: 4A2824FF FFFFFF00
	v_cndmask_b32_e32 v22, s25, v19, vcc_lo                    // 0000003EDA04: 022C2619
	v_ashrrev_i32_e32 v17, 9, v17                              // 0000003EDA08: 34222289
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003EDA0C: BF8701A3
	v_cndmask_b32_e32 v18, v20, v18, vcc_lo                    // 0000003EDA10: 02242514
	v_cndmask_b32_e32 v20, s24, v21, vcc_lo                    // 0000003EDA14: 02282A18
	v_lshlrev_b32_e32 v16, 8, v17                              // 0000003EDA18: 30202288
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003EDA1C: BF870193
	v_ashrrev_i32_e32 v19, 31, v18                             // 0000003EDA20: 3426249F
	.long 0xd7006a14                                           // 0000003EDA24: D7006A14
	v_cndmask_b32_e32 v1, v20, v4, vcc_lo                      // 0000003EDA28: 02020914
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003EDA2C: BF870211
	v_add_co_ci_u32_e64 v21, null, v22, v5, vcc_lo             // 0000003EDA30: D5207C15 01AA0B16
	v_ashrrev_i32_e32 v17, 31, v16                             // 0000003EDA38: 3422209F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003EDA3C: BF870114
	.long 0xd73c0012                                           // 0000003EDA40: D73C0012
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 0000003EDA44: 02022481
	.long 0xd73c0010                                           // 0000003EDA48: D73C0010
	v_cndmask_b32_e32 v1, 1, v16, vcc_lo                       // 0000003EDA4C: 02022081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003EDA50: BF870091
	.long 0xd7006a10                                           // 0000003EDA54: D7006A10
	v_cndmask_b32_e32 v1, v20, v16, vcc_lo                     // 0000003EDA58: 02022114
	v_add_co_ci_u32_e64 v17, null, v21, v17, vcc_lo            // 0000003EDA5C: D5207C11 01AA2315
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003EDA64: BF870092
	.long 0xd7006a10                                           // 0000003EDA68: D7006A10
	v_cndmask_b32_e32 v1, v16, v18, vcc_lo                     // 0000003EDA6C: 02022510
	v_add_co_ci_u32_e64 v17, null, v17, v19, vcc_lo            // 0000003EDA70: D5207C11 01AA2711
	global_store_d16_hi_b16 v[16:17], v15, off                 // 0000003EDA78: DC960000 007C0F10
	s_cbranch_execnz 7                                         // 0000003EDA80: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x30a0>
	.long 0xd7006a10                                           // 0000003EDA84: D7006A10
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 0000003EDA88: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003EDA8C: BF870001
	v_add_co_ci_u32_e64 v17, null, v8, v2, vcc_lo              // 0000003EDA90: D5207C11 01AA0508
	global_store_d16_hi_b16 v[16:17], v15, off offset:160      // 0000003EDA98: DC9600A0 007C0F10
	global_load_d16_b16 v15, v[6:7], off offset:192            // 0000003EDAA0: DC8200C0 0F7C0006
	v_cndmask_b32_e64 v12, -v12, v12, s0                       // 0000003EDAA8: D501000C 2002190C
	v_cmp_ne_u32_e32 vcc_lo, 1, v14                            // 0000003EDAB0: 7C9A1C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003EDAB4: BF8700A2
	v_add_f32_e32 v12, v12, v13                                // 0000003EDAB8: 06181B0C
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 0000003EDABC: 8B6A6A7E
	v_mul_f32_e32 v12, 0x3db504f3, v12                         // 0000003EDAC0: 101818FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 0000003EDAC8: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003EDACC: BF870091
	v_fma_mix_f32 v12, v15, v12, neg(0) op_sel_hi:[1,0,0]      // 0000003EDAD0: CC20000C 8A02190F
	v_bfe_u32 v13, v12, 16, 1                                  // 0000003EDAD8: D610000D 0205210C
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003EDAE0: BF870001
	v_add3_u32 v12, v12, v13, 0x7fff                           // 0000003EDAE4: D655000C 03FE1B0C 00007FFF
	s_cbranch_vccnz 129                                        // 0000003EDAF0: BFA40081 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x32f8>
	v_or_b32_e32 v13, 0x60, v3                                 // 0000003EDAF4: 381A06FF 00000060
	v_lshrrev_b32_e32 v15, 23, v11                             // 0000003EDAFC: 321E1697
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003EDB00: BF870091
	v_dual_mov_b32 v18, s14 :: v_dual_add_nc_u32 v15, v13, v15 // 0000003EDB04: CA20000E 120E1F0D
	v_and_b32_e32 v16, 0xfffffe00, v15                         // 0000003EDB0C: 36201EFF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000003EDB14: BF8701B1
	v_sub_nc_u32_e32 v13, v13, v16                             // 0000003EDB18: 4C1A210D
	v_mov_b32_e32 v16, s15                                     // 0000003EDB1C: 7E20020F
	v_ashrrev_i32_e32 v15, 9, v15                              // 0000003EDB20: 341E1E89
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v13                        // 0000003EDB24: 7C881AFF 00000100
	v_add_nc_u32_e32 v17, 0xffffff00, v13                      // 0000003EDB2C: 4A221AFF FFFFFF00
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003EDB34: BF8701A3
	v_lshlrev_b32_e32 v15, 8, v15                              // 0000003EDB38: 301E1E88
	v_cndmask_b32_e32 v19, s25, v16, vcc_lo                    // 0000003EDB3C: 02262019
	v_cndmask_b32_e32 v17, v17, v13, vcc_lo                    // 0000003EDB40: 02221B11
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003EDB44: BF8701A3
	v_ashrrev_i32_e32 v16, 31, v15                             // 0000003EDB48: 34201E9F
	v_cndmask_b32_e32 v13, s24, v18, vcc_lo                    // 0000003EDB4C: 021A2418
	v_ashrrev_i32_e32 v18, 31, v17                             // 0000003EDB50: 3424229F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003EDB54: BF870193
	.long 0xd73c000f                                           // 0000003EDB58: D73C000F
	v_cndmask_b32_e32 v1, 1, v15, vcc_lo                       // 0000003EDB5C: 02021E81
	.long 0xd7006a0d                                           // 0000003EDB60: D7006A0D
	v_cndmask_b32_e32 v1, v13, v4, vcc_lo                      // 0000003EDB64: 0202090D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003EDB68: BF870211
	v_add_co_ci_u32_e64 v19, null, v19, v5, vcc_lo             // 0000003EDB6C: D5207C13 01AA0B13
	.long 0xd73c0011                                           // 0000003EDB74: D73C0011
	v_cndmask_b32_e32 v1, 1, v17, vcc_lo                       // 0000003EDB78: 02022281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003EDB7C: BF870093
	.long 0xd7006a0d                                           // 0000003EDB80: D7006A0D
	v_cndmask_b32_e32 v1, v13, v15, vcc_lo                     // 0000003EDB84: 02021F0D
	v_add_co_ci_u32_e64 v16, null, v19, v16, vcc_lo            // 0000003EDB88: D5207C10 01AA2113
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003EDB90: BF870092
	.long 0xd7006a0f                                           // 0000003EDB94: D7006A0F
	v_cndmask_b32_e32 v1, v13, v17, vcc_lo                     // 0000003EDB98: 0202230D
	v_add_co_ci_u32_e64 v16, null, v16, v18, vcc_lo            // 0000003EDB9C: D5207C10 01AA2510
	global_store_d16_hi_b16 v[15:16], v12, off                 // 0000003EDBA4: DC960000 007C0C0F
	s_cbranch_execnz 7                                         // 0000003EDBAC: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x31cc>
	.long 0xd7006a0f                                           // 0000003EDBB0: D7006A0F
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 0000003EDBB4: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003EDBB8: BF870001
	v_add_co_ci_u32_e64 v16, null, v8, v2, vcc_lo              // 0000003EDBBC: D5207C10 01AA0508
	global_store_d16_hi_b16 v[15:16], v12, off offset:192      // 0000003EDBC4: DC9600C0 007C0C0F
	global_load_d16_b16 v6, v[6:7], off offset:224             // 0000003EDBCC: DC8200E0 067C0006
	v_cndmask_b32_e64 v7, -v9, v9, s0                          // 0000003EDBD4: D5010007 20021309
	v_cmp_ne_u32_e32 vcc_lo, 1, v14                            // 0000003EDBDC: 7C9A1C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003EDBE0: BF8700A2
	v_add_f32_e32 v7, v7, v10                                  // 0000003EDBE4: 060E1507
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 0000003EDBE8: 8B6A6A7E
	v_mul_f32_e32 v7, 0x3db504f3, v7                           // 0000003EDBEC: 100E0EFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 0000003EDBF4: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003EDBF8: BF870091
	v_fma_mix_f32 v6, v6, v7, neg(0) op_sel_hi:[1,0,0]         // 0000003EDBFC: CC200006 8A020F06
	v_bfe_u32 v7, v6, 16, 1                                    // 0000003EDC04: D6100007 02052106
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003EDC0C: BF870001
	v_add3_u32 v6, v6, v7, 0x7fff                              // 0000003EDC10: D6550006 03FE0F06 00007FFF
	s_cbranch_vccnz 55                                         // 0000003EDC1C: BFA40037 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x32fc>
	v_or_b32_e32 v3, 0x70, v3                                  // 0000003EDC20: 380606FF 00000070
	v_lshrrev_b32_e32 v7, 23, v11                              // 0000003EDC28: 320E1697
	v_mov_b32_e32 v10, s15                                     // 0000003EDC2C: 7E14020F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003EDC30: BF870092
	v_dual_mov_b32 v12, s14 :: v_dual_add_nc_u32 v7, v3, v7    // 0000003EDC34: CA20000E 0C060F03
	v_and_b32_e32 v9, 0xfffffe00, v7                           // 0000003EDC3C: 36120EFF FFFFFE00
	v_ashrrev_i32_e32 v7, 9, v7                                // 0000003EDC44: 340E0E89
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003EDC48: BF870112
	v_sub_nc_u32_e32 v3, v3, v9                                // 0000003EDC4C: 4C061303
	v_lshlrev_b32_e32 v9, 8, v7                                // 0000003EDC50: 30120E88
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000003EDC54: BF870232
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v3                         // 0000003EDC58: 7C8806FF 00000100
	v_add_nc_u32_e32 v7, 0xffffff00, v3                        // 0000003EDC60: 4A0E06FF FFFFFF00
	v_cndmask_b32_e32 v13, s25, v10, vcc_lo                    // 0000003EDC68: 021A1419
	v_ashrrev_i32_e32 v10, 31, v9                              // 0000003EDC6C: 3414129F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003EDC70: BF8701A3
	v_cndmask_b32_e32 v11, v7, v3, vcc_lo                      // 0000003EDC74: 02160707
	v_cndmask_b32_e32 v3, s24, v12, vcc_lo                     // 0000003EDC78: 02061818
	.long 0xd73c0009                                           // 0000003EDC7C: D73C0009
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 0000003EDC80: 02021281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003EDC84: BF870193
	v_ashrrev_i32_e32 v12, 31, v11                             // 0000003EDC88: 3418169F
	.long 0xd7006a07                                           // 0000003EDC8C: D7006A07
	v_cndmask_b32_e32 v1, v3, v4, vcc_lo                       // 0000003EDC90: 02020903
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003EDC94: BF870191
	v_add_co_ci_u32_e64 v5, null, v13, v5, vcc_lo              // 0000003EDC98: D5207C05 01AA0B0D
	.long 0xd73c0003                                           // 0000003EDCA0: D73C0003
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 0000003EDCA4: 02021681
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003EDCA8: BF870093
	.long 0xd7006a07                                           // 0000003EDCAC: D7006A07
	v_cndmask_b32_e32 v1, v7, v9, vcc_lo                       // 0000003EDCB0: 02021307
	v_add_co_ci_u32_e64 v5, null, v5, v10, vcc_lo              // 0000003EDCB4: D5207C05 01AA1505
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003EDCBC: BF870092
	.long 0xd7006a03                                           // 0000003EDCC0: D7006A03
	v_cndmask_b32_e32 v1, v7, v3, vcc_lo                       // 0000003EDCC4: 02020707
	v_add_co_ci_u32_e64 v4, null, v5, v4, vcc_lo               // 0000003EDCC8: D5207C04 01AA0905
	global_store_d16_hi_b16 v[3:4], v6, off                    // 0000003EDCD0: DC960000 007C0603
	s_cbranch_execnz 62532                                     // 0000003EDCD8: BFA6F444 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	s_branch 7                                                 // 0000003EDCDC: BFA00007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x32fc>
	s_branch 65012                                             // 0000003EDCE0: BFA0FDF4 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2ab4>
	s_branch 65086                                             // 0000003EDCE4: BFA0FE3E <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2be0>
	s_branch 65159                                             // 0000003EDCE8: BFA0FE87 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2d08>
	s_branch 65232                                             // 0000003EDCEC: BFA0FED0 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2e30>
	s_branch 65305                                             // 0000003EDCF0: BFA0FF19 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2f58>
	s_branch 65379                                             // 0000003EDCF4: BFA0FF63 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3084>
	s_branch 65453                                             // 0000003EDCF8: BFA0FFAD <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi3ELi2ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x31b0>
	.long 0xd7006a00                                           // 0000003EDCFC: D7006A00
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 0000003EDD00: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003EDD04: BF870001
	v_add_co_ci_u32_e64 v1, null, v8, v2, vcc_lo               // 0000003EDD08: D5207C01 01AA0508
	global_store_d16_hi_b16 v[0:1], v6, off offset:224         // 0000003EDD10: DC9600E0 007C0600
	s_nop 0                                                    // 0000003EDD18: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000003EDD1C: BFB60003
	s_endpgm                                                   // 0000003EDD20: BFB00000
		...

