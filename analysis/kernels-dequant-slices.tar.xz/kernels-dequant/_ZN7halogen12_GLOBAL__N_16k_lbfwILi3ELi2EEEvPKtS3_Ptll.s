00000000002d8d00 <_ZN7halogen12_GLOBAL__N_16k_lbfwILi3ELi2EEEvPKtS3_Ptll>:
; _ZN7halogen12_GLOBAL__N_16k_lbfwILi3ELi2EEEvPKtS3_Ptll():
	s_load_b64 s[8:9], s[0:1], 0x20                            // 0000002D8D00: F4040200 F8000020
	v_lshrrev_b32_e32 v1, 5, v0                                // 0000002D8D08: 32020085
	s_mov_b32 s3, 0                                            // 0000002D8D0C: BE830080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002D8D10: BF870009
	s_lshl_b64 s[2:3], s[2:3], 3                               // 0000002D8D14: 84828302
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000002D8D18: BF870481
	v_or_b32_e32 v1, s2, v1                                    // 0000002D8D1C: 38020202
	v_mov_b32_e32 v2, s3                                       // 0000002D8D20: 7E040203
	s_mov_b32 s2, exec_lo                                      // 0000002D8D24: BE82007E
	s_waitcnt lgkmcnt(0)                                       // 0000002D8D28: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002D8D2C: BF870001
	.long 0xd4d4007e                                           // 0000002D8D30: D4D4007E
	v_cndmask_b32_e32 v1, s8, v1, vcc_lo                       // 0000002D8D34: 02020208
	s_cbranch_execz 287                                        // 0000002D8D38: BFA5011F <_ZN7halogen12_GLOBAL__N_16k_lbfwILi3ELi2EEEvPKtS3_Ptll+0x4b8>
	s_load_b256 s[0:7], s[0:1], null                           // 0000002D8D3C: F40C0000 F8000000
	v_and_b32_e32 v0, 31, v0                                   // 0000002D8D44: 3600009F
	s_waitcnt lgkmcnt(0)                                       // 0000002D8D48: BF89FC07
	.long 0xd451000a                                           // 0000002D8D4C: D451000A
	v_cndmask_b32_e32 v0, s6, v129, vcc_lo                     // 0000002D8D50: 02010206
	s_and_b32 vcc_lo, exec_lo, s10                             // 0000002D8D54: 8B6A0A7E
	s_cbranch_vccnz 145                                        // 0000002D8D58: BFA40091 <_ZN7halogen12_GLOBAL__N_16k_lbfwILi3ELi2EEEvPKtS3_Ptll+0x2a0>
	.long 0xd72c0003                                           // 0000002D8D5C: D72C0003
	v_cndmask_b32_e32 v1, s7, v1, vcc_lo                       // 0000002D8D60: 02020207
	.long 0xd72c0006                                           // 0000002D8D64: D72C0006
	v_cndmask_b32_e32 v1, s6, v2, vcc_lo                       // 0000002D8D68: 02020406
	v_mad_u64_u32 v[4:5], null, s6, v1, 0                      // 0000002D8D6C: D6FE7C04 02020206
	s_lshl_b64 s[10:11], s[6:7], 1                             // 0000002D8D74: 848A8106
	v_dual_mov_b32 v8, 0 :: v_dual_mov_b32 v7, 0               // 0000002D8D78: CA100080 08060080
	s_add_u32 s10, s2, s10                                     // 0000002D8D80: 800A0A02
	s_addc_u32 s11, s3, s11                                    // 0000002D8D84: 820B0B03
	s_lshl_b64 s[12:13], s[6:7], 2                             // 0000002D8D88: 848C8206
	v_add3_u32 v5, v5, v6, v3                                  // 0000002D8D8C: D6550005 040E0D05
	v_dual_mov_b32 v6, 0 :: v_dual_lshlrev_b32 v3, 4, v0       // 0000002D8D94: CA220080 06020084
	s_add_u32 s12, s2, s12                                     // 0000002D8D9C: 800C0C02
	s_addc_u32 s13, s3, s13                                    // 0000002D8DA0: 820D0D03
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002D8DA4: BF870092
	.long 0xd73c0004                                           // 0000002D8DA8: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 0000002D8DAC: 02020881
	.long 0xd7006a04                                           // 0000002D8DB0: D7006A04
	v_cndmask_b32_e32 v1, s0, v4, vcc_lo                       // 0000002D8DB4: 02020800
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002D8DB8: BF870001
	v_add_co_ci_u32_e64 v5, null, s1, v5, vcc_lo               // 0000002D8DBC: D5207C05 01AA0A01
	s_mov_b64 s[0:1], 0                                        // 0000002D8DC4: BE800180
	.long 0xd7000e1d                                           // 0000002D8DC8: D7000E1D
	v_cndmask_b32_e32 v1, s2, v3, vcc_lo                       // 0000002D8DCC: 02020602
	.long 0xd7006a19                                           // 0000002D8DD0: D7006A19
	v_cndmask_b32_e32 v1, v4, v3, vcc_lo                       // 0000002D8DD4: 02020704
	v_add_co_ci_u32_e64 v30, null, s3, 0, s14                  // 0000002D8DD8: D5207C1E 00390003
	.long 0xd7000e21                                           // 0000002D8DE0: D7000E21
	v_cndmask_b32_e32 v1, s10, v3, vcc_lo                      // 0000002D8DE4: 0202060A
	v_add_co_ci_u32_e64 v26, null, 0, v5, vcc_lo               // 0000002D8DE8: D5207C1A 01AA0A80
	v_add_co_ci_u32_e64 v34, null, s11, 0, s14                 // 0000002D8DF0: D5207C22 0039000B
	.long 0xd7000e25                                           // 0000002D8DF8: D7000E25
	v_cndmask_b32_e32 v1, s12, v3, vcc_lo                      // 0000002D8DFC: 0202060C
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002D8E00: BF870001
	v_add_co_ci_u32_e64 v38, null, s13, 0, s14                 // 0000002D8E04: D5207C26 0039000D
	global_load_b128 v[9:12], v[25:26], off                    // 0000002D8E0C: DC5E0000 097C0019
	global_load_b128 v[13:16], v[29:30], off                   // 0000002D8E14: DC5E0000 0D7C001D
	global_load_b128 v[17:20], v[33:34], off                   // 0000002D8E1C: DC5E0000 117C0021
	global_load_b128 v[21:24], v[37:38], off                   // 0000002D8E24: DC5E0000 157C0025
	global_load_b128 v[25:28], v[25:26], off offset:512        // 0000002D8E2C: DC5E0200 197C0019
	global_load_b128 v[29:32], v[29:30], off offset:512        // 0000002D8E34: DC5E0200 1D7C001D
	global_load_b128 v[33:36], v[33:34], off offset:512        // 0000002D8E3C: DC5E0200 217C0021
	global_load_b128 v[37:40], v[37:38], off offset:512        // 0000002D8E44: DC5E0200 257C0025
	s_add_u32 s0, s0, 0x200                                    // 0000002D8E4C: 8000FF00 00000200
	s_addc_u32 s1, s1, 0                                       // 0000002D8E54: 82018001
	.long 0xd7006a04                                           // 0000002D8E58: D7006A04
	v_cndmask_b32_e32 v1, 0x400, v4, vcc_lo                    // 0000002D8E5C: 020208FF 00000400
	.long 0xd456000e                                           // 0000002D8E64: D456000E
	v_cndmask_b32_e32 v0, s0, v6, vcc_lo                       // 0000002D8E68: 02000C00
	s_add_u32 s10, s10, 0x400                                  // 0000002D8E6C: 800AFF0A 00000400
	s_addc_u32 s11, s11, 0                                     // 0000002D8E74: 820B800B
	v_add_co_ci_u32_e64 v5, null, 0, v5, vcc_lo                // 0000002D8E78: D5207C05 01AA0A80
	s_add_u32 s12, s12, 0x400                                  // 0000002D8E80: 800CFF0C 00000400
	s_addc_u32 s13, s13, 0                                     // 0000002D8E88: 820D800D
	s_add_u32 s2, s2, 0x400                                    // 0000002D8E8C: 8002FF02 00000400
	s_addc_u32 s3, s3, 0                                       // 0000002D8E94: 82038003
	s_and_b32 vcc_lo, exec_lo, s14                             // 0000002D8E98: 8B6A0E7E
	s_waitcnt vmcnt(6)                                         // 0000002D8E9C: BF891BF7
	v_dot2_f32_bf16 v6, v13, v9, v6                            // 0000002D8EA0: CC1A4006 1C1A130D
	s_waitcnt vmcnt(5)                                         // 0000002D8EA8: BF8917F7
	v_dot2_f32_bf16 v8, v17, v9, v8                            // 0000002D8EAC: CC1A4008 1C221311
	s_waitcnt vmcnt(4)                                         // 0000002D8EB4: BF8913F7
	v_dot2_f32_bf16 v7, v21, v9, v7                            // 0000002D8EB8: CC1A4007 1C1E1315
	v_dot2_f32_bf16 v6, v14, v10, v6                           // 0000002D8EC0: CC1A4006 1C1A150E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002D8EC8: BF870193
	v_dot2_f32_bf16 v8, v18, v10, v8                           // 0000002D8ECC: CC1A4008 1C221512
	v_dot2_f32_bf16 v7, v22, v10, v7                           // 0000002D8ED4: CC1A4007 1C1E1516
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002D8EDC: BF870193
	v_dot2_f32_bf16 v6, v15, v11, v6                           // 0000002D8EE0: CC1A4006 1C1A170F
	v_dot2_f32_bf16 v8, v19, v11, v8                           // 0000002D8EE8: CC1A4008 1C221713
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002D8EF0: BF870193
	v_dot2_f32_bf16 v7, v23, v11, v7                           // 0000002D8EF4: CC1A4007 1C1E1717
	v_dot2_f32_bf16 v6, v16, v12, v6                           // 0000002D8EFC: CC1A4006 1C1A1910
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002D8F04: BF870193
	v_dot2_f32_bf16 v8, v20, v12, v8                           // 0000002D8F08: CC1A4008 1C221914
	v_dot2_f32_bf16 v7, v24, v12, v7                           // 0000002D8F10: CC1A4007 1C1E1918
	s_waitcnt vmcnt(2)                                         // 0000002D8F18: BF890BF7
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002D8F1C: BF870003
	v_dot2_f32_bf16 v6, v29, v25, v6                           // 0000002D8F20: CC1A4006 1C1A331D
	s_waitcnt vmcnt(1)                                         // 0000002D8F28: BF8907F7
	v_dot2_f32_bf16 v8, v33, v25, v8                           // 0000002D8F2C: CC1A4008 1C223321
	s_waitcnt vmcnt(0)                                         // 0000002D8F34: BF8903F7
	v_dot2_f32_bf16 v7, v37, v25, v7                           // 0000002D8F38: CC1A4007 1C1E3325
	v_dot2_f32_bf16 v6, v30, v26, v6                           // 0000002D8F40: CC1A4006 1C1A351E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002D8F48: BF870193
	v_dot2_f32_bf16 v8, v34, v26, v8                           // 0000002D8F4C: CC1A4008 1C223522
	v_dot2_f32_bf16 v7, v38, v26, v7                           // 0000002D8F54: CC1A4007 1C1E3526
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002D8F5C: BF870193
	v_dot2_f32_bf16 v6, v31, v27, v6                           // 0000002D8F60: CC1A4006 1C1A371F
	v_dot2_f32_bf16 v8, v35, v27, v8                           // 0000002D8F68: CC1A4008 1C223723
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002D8F70: BF870193
	v_dot2_f32_bf16 v7, v39, v27, v7                           // 0000002D8F74: CC1A4007 1C1E3727
	v_dot2_f32_bf16 v6, v32, v28, v6                           // 0000002D8F7C: CC1A4006 1C1A3920
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002D8F84: BF870193
	v_dot2_f32_bf16 v8, v36, v28, v8                           // 0000002D8F88: CC1A4008 1C223924
	v_dot2_f32_bf16 v7, v40, v28, v7                           // 0000002D8F90: CC1A4007 1C1E3928
	s_cbranch_vccz 65419                                       // 0000002D8F98: BFA3FF8B <_ZN7halogen12_GLOBAL__N_16k_lbfwILi3ELi2EEEvPKtS3_Ptll+0xc8>
	s_branch 3                                                 // 0000002D8F9C: BFA00003 <_ZN7halogen12_GLOBAL__N_16k_lbfwILi3ELi2EEEvPKtS3_Ptll+0x2ac>
	v_dual_mov_b32 v7, 0 :: v_dual_mov_b32 v8, 0               // 0000002D8FA0: CA100080 07080080
	v_mov_b32_e32 v6, 0                                        // 0000002D8FA8: 7E0C0280
	.long 0xd71f0003                                           // 0000002D8FAC: D71F0003
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000002D8FB0: 020100C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002D8FB4: BF870121
	v_xor_b32_e32 v4, 16, v3                                   // 0000002D8FB8: 3A080690
	v_xor_b32_e32 v10, 8, v3                                   // 0000002D8FBC: 3A140688
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 0000002D8FC0: 7C9808A0
	v_cndmask_b32_e32 v4, v3, v4, vcc_lo                       // 0000002D8FC4: 02080903
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002D8FC8: BF870113
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 0000002D8FCC: 7C9814A0
	v_lshlrev_b32_e32 v4, 2, v4                                // 0000002D8FD0: 30080882
	v_cndmask_b32_e32 v10, v3, v10, vcc_lo                     // 0000002D8FD4: 02141503
	ds_bpermute_b32 v5, v4, v6                                 // 0000002D8FD8: DACC0000 05000604
	ds_bpermute_b32 v9, v4, v8                                 // 0000002D8FE0: DACC0000 09000804
	ds_bpermute_b32 v4, v4, v7                                 // 0000002D8FE8: DACC0000 04000704
	s_waitcnt lgkmcnt(2)                                       // 0000002D8FF0: BF89FC27
	v_dual_add_f32 v5, v6, v5 :: v_dual_lshlrev_b32 v10, 2, v10// 0000002D8FF4: C9220B06 050A1482
	s_waitcnt lgkmcnt(1)                                       // 0000002D8FFC: BF89FC17
	v_add_f32_e32 v6, v8, v9                                   // 0000002D9000: 060C1308
	s_waitcnt lgkmcnt(0)                                       // 0000002D9004: BF89FC07
	v_add_f32_e32 v4, v7, v4                                   // 0000002D9008: 06080907
	ds_bpermute_b32 v7, v10, v5                                // 0000002D900C: DACC0000 0700050A
	ds_bpermute_b32 v8, v10, v6                                // 0000002D9014: DACC0000 0800060A
	ds_bpermute_b32 v9, v10, v4                                // 0000002D901C: DACC0000 0900040A
	v_xor_b32_e32 v10, 4, v3                                   // 0000002D9024: 3A140684
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002D9028: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 0000002D902C: 7C9814A0
	v_cndmask_b32_e32 v10, v3, v10, vcc_lo                     // 0000002D9030: 02141503
	s_waitcnt lgkmcnt(2)                                       // 0000002D9034: BF89FC27
	v_dual_add_f32 v5, v5, v7 :: v_dual_lshlrev_b32 v10, 2, v10// 0000002D9038: C9220F05 050A1482
	s_waitcnt lgkmcnt(1)                                       // 0000002D9040: BF89FC17
	v_add_f32_e32 v6, v6, v8                                   // 0000002D9044: 060C1106
	s_waitcnt lgkmcnt(0)                                       // 0000002D9048: BF89FC07
	v_add_f32_e32 v4, v4, v9                                   // 0000002D904C: 06081304
	ds_bpermute_b32 v7, v10, v5                                // 0000002D9050: DACC0000 0700050A
	ds_bpermute_b32 v8, v10, v6                                // 0000002D9058: DACC0000 0800060A
	ds_bpermute_b32 v9, v10, v4                                // 0000002D9060: DACC0000 0900040A
	v_xor_b32_e32 v10, 2, v3                                   // 0000002D9068: 3A140682
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002D906C: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 0000002D9070: 7C9814A0
	v_cndmask_b32_e32 v10, v3, v10, vcc_lo                     // 0000002D9074: 02141503
	s_waitcnt lgkmcnt(2)                                       // 0000002D9078: BF89FC27
	v_dual_add_f32 v5, v5, v7 :: v_dual_lshlrev_b32 v10, 2, v10// 0000002D907C: C9220F05 050A1482
	s_waitcnt lgkmcnt(1)                                       // 0000002D9084: BF89FC17
	v_add_f32_e32 v6, v6, v8                                   // 0000002D9088: 060C1106
	s_waitcnt lgkmcnt(0)                                       // 0000002D908C: BF89FC07
	v_add_f32_e32 v4, v4, v9                                   // 0000002D9090: 06081304
	ds_bpermute_b32 v7, v10, v5                                // 0000002D9094: DACC0000 0700050A
	ds_bpermute_b32 v8, v10, v6                                // 0000002D909C: DACC0000 0800060A
	ds_bpermute_b32 v9, v10, v4                                // 0000002D90A4: DACC0000 0900040A
	v_xor_b32_e32 v10, 1, v3                                   // 0000002D90AC: 3A140681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000002D90B0: BF870131
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 0000002D90B4: 7C9814A0
	v_cndmask_b32_e32 v3, v3, v10, vcc_lo                      // 0000002D90B8: 02061503
	v_cmp_eq_u32_e32 vcc_lo, 0, v0                             // 0000002D90BC: 7C940080
	v_lshlrev_b32_e32 v10, 2, v3                               // 0000002D90C0: 30140682
	s_waitcnt lgkmcnt(1)                                       // 0000002D90C4: BF89FC17
	v_dual_add_f32 v5, v5, v7 :: v_dual_add_f32 v6, v6, v8     // 0000002D90C8: C9080F05 05061106
	s_waitcnt lgkmcnt(0)                                       // 0000002D90D0: BF89FC07
	v_add_f32_e32 v3, v4, v9                                   // 0000002D90D4: 06061304
	ds_bpermute_b32 v7, v10, v5                                // 0000002D90D8: DACC0000 0700050A
	ds_bpermute_b32 v8, v10, v6                                // 0000002D90E0: DACC0000 0800060A
	ds_bpermute_b32 v4, v10, v3                                // 0000002D90E8: DACC0000 0400030A
	s_and_b32 exec_lo, exec_lo, vcc_lo                         // 0000002D90F0: 8B7E6A7E
	s_cbranch_execz 48                                         // 0000002D90F4: BFA50030 <_ZN7halogen12_GLOBAL__N_16k_lbfwILi3ELi2EEEvPKtS3_Ptll+0x4b8>
	s_waitcnt lgkmcnt(1)                                       // 0000002D90F8: BF89FC17
	v_dual_add_f32 v6, v6, v8 :: v_dual_add_f32 v5, v5, v7     // 0000002D90FC: C9081106 06040F05
	.long 0x7f0e3880                                           // 0000002D9104: 7F0E3880
	.long 0xd73c0000                                           // 0000002D9108: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000002D910C: 02020281
	s_waitcnt lgkmcnt(0)                                       // 0000002D9110: BF89FC07
	v_add_f32_e32 v4, v3, v4                                   // 0000002D9114: 06080903
	.long 0x7e0e3986                                           // 0000002D9118: 7E0E3986
	.long 0x7e103985                                           // 0000002D911C: 7E103985
	.long 0x7f103987                                           // 0000002D9120: 7F103987
	s_lshl_b64 s[0:1], s[8:9], 1                               // 0000002D9124: 84808108
	.long 0xd7006a00                                           // 0000002D9128: D7006A00
	v_cndmask_b32_e32 v1, s4, v0, vcc_lo                       // 0000002D912C: 02020004
	v_and_b32_e32 v2, 1, v7                                    // 0000002D9130: 36040E81
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002D9134: BF8701A3
	v_and_b32_e32 v3, 1, v8                                    // 0000002D9138: 36061081
	v_add_co_ci_u32_e64 v1, null, s5, v1, vcc_lo               // 0000002D913C: D5207C01 01AA0205
	v_add3_u32 v6, v6, v2, 0x7fff                              // 0000002D9144: D6550006 03FE0506 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002D9150: BF8700B3
	v_add3_u32 v7, v5, v3, 0x7fff                              // 0000002D9154: D6550007 03FE0705 00007FFF
	v_bfe_u32 v5, v4, 16, 1                                    // 0000002D9160: D6100005 02052104
	.long 0xd7006a02                                           // 0000002D9168: D7006A02
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 0000002D916C: 02000100
	v_add_co_ci_u32_e64 v3, null, s1, v1, vcc_lo               // 0000002D9170: D5207C03 01AA0201
	s_lshl_b64 s[0:1], s[8:9], 2                               // 0000002D9178: 84808208
	v_add3_u32 v8, v4, v5, 0x7fff                              // 0000002D917C: D6550008 03FE0B04 00007FFF
	.long 0xd7006a04                                           // 0000002D9188: D7006A04
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 0000002D918C: 02000100
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002D9190: BF870001
	v_add_co_ci_u32_e64 v5, null, s1, v1, vcc_lo               // 0000002D9194: D5207C05 01AA0201
	s_clause 0x2                                               // 0000002D919C: BF850002
	global_store_d16_hi_b16 v[0:1], v7, off                    // 0000002D91A0: DC960000 007C0700
	global_store_d16_hi_b16 v[2:3], v6, off                    // 0000002D91A8: DC960000 007C0602
	global_store_d16_hi_b16 v[4:5], v8, off                    // 0000002D91B0: DC960000 007C0804
	s_endpgm                                                   // 0000002D91B8: BFB00000
		...

