0000000000725b00 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi2ELi16ELi1ELb1EEEvPKhPKtPvll>:
; _ZN7halogen12_GLOBAL__N_18k_lq8s32ILi2ELi16ELi1ELb1EEEvPKhPKtPvll():
	s_clause 0x1                                               // 000000725B00: BF850001
	s_load_b256 s[4:11], s[0:1], null                          // 000000725B04: F40C0100 F8000000
	s_load_b64 s[12:13], s[0:1], 0x20                          // 000000725B0C: F4040300 F8000020
	v_lshrrev_b32_e32 v1, 4, v0                                // 000000725B14: 32020084
	s_mov_b32 s3, 0                                            // 000000725B18: BE830080
	v_dual_mov_b32 v16, 0 :: v_dual_and_b32 v15, 15, v0        // 000000725B1C: CA240080 100E008F
	s_lshl_b64 s[0:1], s[2:3], 4                               // 000000725B24: 84808402
	.long 0x7e2a3880                                           // 000000725B28: 7E2A3880
	v_or_b32_e32 v9, s0, v1                                    // 000000725B2C: 38120200
	v_dual_mov_b32 v10, s1 :: v_dual_mov_b32 v3, 0             // 000000725B30: CA100001 0A020080
	v_lshlrev_b32_e32 v11, 4, v15                              // 000000725B38: 30161E84
	s_waitcnt lgkmcnt(0)                                       // 000000725B3C: BF89FC07
	s_ashr_i32 s0, s11, 31                                     // 000000725B40: 86009F0B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000725B44: BF8704A2
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[9:10]                 // 000000725B48: 7CA8120C
	s_lshr_b32 s0, s0, 28                                      // 000000725B4C: 85009C00
	s_add_u32 s2, s10, s0                                      // 000000725B50: 8002000A
	s_addc_u32 s3, s11, 0                                      // 000000725B54: 8203800B
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000725B58: BF870009
	s_ashr_i64 s[2:3], s[2:3], 4                               // 000000725B5C: 86828402
	v_cndmask_b32_e32 v1, 0, v9, vcc_lo                        // 000000725B60: 02021280
	s_add_u32 s0, s10, s2                                      // 000000725B64: 8000020A
	v_cndmask_b32_e64 v2, 0, s1, vcc_lo                        // 000000725B68: D5010002 01A80280
	s_addc_u32 s1, s11, s3                                     // 000000725B70: 8201030B
	s_add_u32 s0, s0, 15                                       // 000000725B74: 80008F00
	s_addc_u32 s1, s1, 0                                       // 000000725B78: 82018001
	s_and_b32 s0, s0, -16                                      // 000000725B7C: 8B00D000
	.long 0xd72c0004                                           // 000000725B80: D72C0004
	v_cndmask_b32_e32 v0, v1, v1, vcc_lo                       // 000000725B84: 02000301
	.long 0xd72c0007                                           // 000000725B88: D72C0007
	v_cndmask_b32_e32 v0, v2, v0, vcc_lo                       // 000000725B8C: 02000102
	v_mad_u64_u32 v[5:6], null, v1, s0, 0                      // 000000725B90: D6FE7C05 02000101
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v2, 0               // 000000725B98: CA100080 01020080
	.long 0xd4440000                                           // 000000725BA0: D4440000
	v_cndmask_b32_e32 v1, s2, v15, vcc_lo                      // 000000725BA4: 02021E02
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000725BA8: BF870213
	v_add3_u32 v6, v6, v4, v7                                  // 000000725BAC: D6550006 041E0906
	.long 0xd7000111                                           // 000000725BB4: D7000111
	v_cndmask_b32_e32 v1, s4, v5, vcc_lo                       // 000000725BB8: 02020A04
	v_mov_b32_e32 v4, 0                                        // 000000725BBC: 7E080280
	s_delay_alu instid0(VALU_DEP_3)                            // 000000725BC0: BF870003
	v_add_co_ci_u32_e64 v18, null, s5, v6, s1                  // 000000725BC4: D5207C12 00060C05
	s_and_saveexec_b32 s3, s0                                  // 000000725BCC: BE832000
	s_cbranch_execz 21                                         // 000000725BD0: BFA50015 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi2ELi16ELi1ELb1EEEvPKhPKtPvll+0x128>
	v_lshlrev_b32_e32 v1, 4, v15                               // 000000725BD4: 30021E84
	.long 0xd7000103                                           // 000000725BD8: D7000103
	v_cndmask_b32_e32 v0, v17, v10, vcc_lo                     // 000000725BDC: 02001511
	v_and_b32_e32 v7, 14, v0                                   // 000000725BE0: 360E008E
	v_add_co_ci_u32_e64 v4, null, s11, v18, s1                 // 000000725BE4: D5207C04 0006240B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000725BEC: BF870094
	.long 0xd7000101                                           // 000000725BF0: D7000101
	v_cndmask_b32_e32 v1, v17, v1, vcc_lo                      // 000000725BF4: 02020311
	v_add_co_ci_u32_e64 v2, null, 0, v18, s1                   // 000000725BF8: D5207C02 00062480
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000725C00: BF870094
	.long 0xd7000107                                           // 000000725C04: D7000107
	v_cndmask_b32_e32 v1, v3, v7, vcc_lo                       // 000000725C08: 02020F03
	v_add_co_ci_u32_e64 v8, null, 0, v4, s1                    // 000000725C0C: D5207C08 00060880
	s_clause 0x1                                               // 000000725C14: BF850001
	global_load_b128 v[1:4], v[1:2], off                       // 000000725C18: DC5E0000 017C0001
	global_load_d16_b16 v21, v[7:8], off                       // 000000725C20: DC820000 157C0007
	s_or_b32 exec_lo, exec_lo, s3                              // 000000725C28: 8C7E037E
	v_mov_b32_e32 v19, 0                                       // 000000725C2C: 7E260280
	s_and_saveexec_b32 s3, s0                                  // 000000725C30: BE832000
	s_cbranch_execz 328                                        // 000000725C34: BFA50148 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi2ELi16ELi1ELb1EEEvPKhPKtPvll+0x658>
	v_and_or_b32 v0, v0, 14, 16                                // 000000725C38: D6570000 02411D00
	.long 0xd7000005                                           // 000000725C40: D7000005
	v_cndmask_b32_e32 v1, s10, v5, vcc_lo                      // 000000725C44: 02020A0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000725C48: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s11, v6, s0                  // 000000725C4C: D5207C06 00020C0B
	v_mov_b32_e32 v12, 0                                       // 000000725C54: 7E180280
	.long 0xd7000000                                           // 000000725C58: D7000000
	v_cndmask_b32_e32 v1, v5, v0, vcc_lo                       // 000000725C5C: 02020105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000725C60: BF870191
	v_add_co_ci_u32_e64 v5, null, 0, v6, s0                    // 000000725C64: D5207C05 00020C80
	v_dual_mov_b32 v20, v15 :: v_dual_mov_b32 v19, v12         // 000000725C6C: CA10010F 1412010C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000725C74: BF870093
	.long 0xd700000d                                           // 000000725C78: D700000D
	v_cndmask_b32_e32 v1, s4, v0, vcc_lo                       // 000000725C7C: 02020004
	v_add_co_ci_u32_e64 v14, null, s5, v5, s0                  // 000000725C80: D5207C0E 00020A05
	v_mov_b32_e32 v16, v12                                     // 000000725C88: 7E20030C
	s_mov_b32 s14, 0                                           // 000000725C8C: BE8E0080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 000000725C90: 8484810A
	s_branch 274                                               // 000000725C94: BFA00112 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi2ELi16ELi1ELb1EEEvPKhPKtPvll+0x5e0>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000725C98: 8C7E0A7E
	.long 0xd73c0017                                           // 000000725C9C: D73C0017
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 000000725CA0: 02021681
	v_bfe_i32 v11, v1, 0, 8                                    // 000000725CA4: D611000B 02210101
	v_bfe_i32 v39, v1, 8, 8                                    // 000000725CAC: D6110027 02211101
	v_bfe_i32 v40, v1, 16, 8                                   // 000000725CB4: D6110028 02212101
	.long 0x7f2a3880                                           // 000000725CBC: 7F2A3880
	v_ashrrev_i32_e32 v1, 24, v1                               // 000000725CC0: 34020298
	.long 0xd700011f                                           // 000000725CC4: D700011F
	v_cndmask_b32_e32 v1, s6, v23, vcc_lo                      // 000000725CC8: 02022E06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000725CCC: BF8701A1
	v_add_co_ci_u32_e64 v32, null, s7, v24, s1                 // 000000725CD0: D5207C20 00063007
	v_cvt_f32_i32_e32 v11, v11                                 // 000000725CD8: 7E160B0B
	.long 0xd7000123                                           // 000000725CDC: D7000123
	v_cndmask_b32_e32 v0, v31, v4, vcc_lo                      // 000000725CE0: 0200091F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000725CE4: BF870001
	v_add_co_ci_u32_e64 v36, null, s5, v32, s1                 // 000000725CE8: D5207C24 00064005
	v_bfe_i32 v41, v2, 0, 8                                    // 000000725CF0: D6110029 02210102
	v_cvt_f32_i32_e32 v39, v39                                 // 000000725CF8: 7E4E0B27
	s_clause 0x3                                               // 000000725CFC: BF850003
	global_load_b128 v[23:26], v[31:32], off                   // 000000725D00: DC5E0000 177C001F
	global_load_b128 v[27:30], v[35:36], off                   // 000000725D08: DC5E0000 1B7C0023
	global_load_b128 v[31:34], v[31:32], off offset:16         // 000000725D10: DC5E0010 1F7C001F
	global_load_b128 v[35:38], v[35:36], off offset:16         // 000000725D18: DC5E0010 237C0023
	v_cvt_f32_i32_e32 v40, v40                                 // 000000725D20: 7E500B28
	v_fma_mix_f32 v11, v21, v11, neg(0) op_sel_hi:[1,0,0]      // 000000725D24: CC20000B 8A021715
	v_bfe_i32 v42, v2, 8, 8                                    // 000000725D2C: D611002A 02211102
	v_bfe_i32 v43, v2, 16, 8                                   // 000000725D34: D611002B 02212102
	v_ashrrev_i32_e32 v2, 24, v2                               // 000000725D3C: 34040498
	v_bfe_i32 v44, v3, 0, 8                                    // 000000725D40: D611002C 02210103
	v_bfe_i32 v45, v3, 8, 8                                    // 000000725D48: D611002D 02211103
	v_bfe_i32 v46, v3, 16, 8                                   // 000000725D50: D611002E 02212103
	v_ashrrev_i32_e32 v3, 24, v3                               // 000000725D58: 34060698
	v_bfe_i32 v47, v4, 0, 8                                    // 000000725D5C: D611002F 02210104
	v_bfe_i32 v48, v4, 8, 8                                    // 000000725D64: D6110030 02211104
	v_bfe_i32 v49, v4, 16, 8                                   // 000000725D6C: D6110031 02212104
	v_ashrrev_i32_e32 v4, 24, v4                               // 000000725D74: 34080898
	v_cvt_f32_i32_e32 v1, v1                                   // 000000725D78: 7E020B01
	v_cvt_f32_i32_e32 v41, v41                                 // 000000725D7C: 7E520B29
	v_fma_mix_f32 v39, v21, v39, neg(0) op_sel_hi:[1,0,0]      // 000000725D80: CC200027 8A024F15
	v_fma_mix_f32 v40, v21, v40, neg(0) op_sel_hi:[1,0,0]      // 000000725D88: CC200028 8A025115
	v_bfe_u32 v54, v11, 16, 1                                  // 000000725D90: D6100036 0205210B
	v_cvt_f32_i32_e32 v42, v42                                 // 000000725D98: 7E540B2A
	v_cvt_f32_i32_e32 v43, v43                                 // 000000725D9C: 7E560B2B
	v_cvt_f32_i32_e32 v2, v2                                   // 000000725DA0: 7E040B02
	v_cvt_f32_i32_e32 v44, v44                                 // 000000725DA4: 7E580B2C
	v_cvt_f32_i32_e32 v45, v45                                 // 000000725DA8: 7E5A0B2D
	v_cvt_f32_i32_e32 v46, v46                                 // 000000725DAC: 7E5C0B2E
	v_cvt_f32_i32_e32 v3, v3                                   // 000000725DB0: 7E060B03
	v_cvt_f32_i32_e32 v47, v47                                 // 000000725DB4: 7E5E0B2F
	v_cvt_f32_i32_e32 v48, v48                                 // 000000725DB8: 7E600B30
	v_cvt_f32_i32_e32 v49, v49                                 // 000000725DBC: 7E620B31
	v_cvt_f32_i32_e32 v4, v4                                   // 000000725DC0: 7E080B04
	v_fma_mix_f32 v1, v21, v1, neg(0) op_sel_hi:[1,0,0]        // 000000725DC4: CC200001 8A020315
	v_fma_mix_f32 v41, v21, v41, neg(0) op_sel_hi:[1,0,0]      // 000000725DCC: CC200029 8A025315
	v_bfe_u32 v55, v39, 16, 1                                  // 000000725DD4: D6100037 02052127
	v_bfe_u32 v56, v40, 16, 1                                  // 000000725DDC: D6100038 02052128
	v_add3_u32 v11, v11, v54, 0x7fff                           // 000000725DE4: D655000B 03FE6D0B 00007FFF
	v_fma_mix_f32 v42, v21, v42, neg(0) op_sel_hi:[1,0,0]      // 000000725DF0: CC20002A 8A025515
	v_fma_mix_f32 v43, v21, v43, neg(0) op_sel_hi:[1,0,0]      // 000000725DF8: CC20002B 8A025715
	v_fma_mix_f32 v2, v21, v2, neg(0) op_sel_hi:[1,0,0]        // 000000725E00: CC200002 8A020515
	v_fma_mix_f32 v44, v21, v44, neg(0) op_sel_hi:[1,0,0]      // 000000725E08: CC20002C 8A025915
	v_fma_mix_f32 v45, v21, v45, neg(0) op_sel_hi:[1,0,0]      // 000000725E10: CC20002D 8A025B15
	v_fma_mix_f32 v46, v21, v46, neg(0) op_sel_hi:[1,0,0]      // 000000725E18: CC20002E 8A025D15
	v_fma_mix_f32 v3, v21, v3, neg(0) op_sel_hi:[1,0,0]        // 000000725E20: CC200003 8A020715
	v_fma_mix_f32 v47, v21, v47, neg(0) op_sel_hi:[1,0,0]      // 000000725E28: CC20002F 8A025F15
	v_fma_mix_f32 v48, v21, v48, neg(0) op_sel_hi:[1,0,0]      // 000000725E30: CC200030 8A026115
	v_fma_mix_f32 v49, v21, v49, neg(0) op_sel_hi:[1,0,0]      // 000000725E38: CC200031 8A026315
	v_fma_mix_f32 v4, v21, v4, neg(0) op_sel_hi:[1,0,0]        // 000000725E40: CC200004 8A020915
	v_bfe_u32 v57, v1, 16, 1                                   // 000000725E48: D6100039 02052101
	v_bfe_u32 v58, v41, 16, 1                                  // 000000725E50: D610003A 02052129
	v_add3_u32 v39, v39, v55, 0x7fff                           // 000000725E58: D6550027 03FE6F27 00007FFF
	v_add3_u32 v40, v40, v56, 0x7fff                           // 000000725E64: D6550028 03FE7128 00007FFF
	.long 0x7e2a398b                                           // 000000725E70: 7E2A398B
	.long 0x7f643995                                           // 000000725E74: 7F643995
	v_bfe_u32 v59, v42, 16, 1                                  // 000000725E78: D610003B 0205212A
	v_bfe_u32 v60, v43, 16, 1                                  // 000000725E80: D610003C 0205212B
	v_add3_u32 v1, v1, v57, 0x7fff                             // 000000725E88: D6550001 03FE7301 00007FFF
	v_add3_u32 v41, v41, v58, 0x7fff                           // 000000725E94: D6550029 03FE7529 00007FFF
	.long 0x7e6439a8                                           // 000000725EA0: 7E6439A8
	v_and_or_b32 v39, 0xffff0000, v39, v21                     // 000000725EA4: D6570027 04564EFF FFFF0000
	v_bfe_u32 v61, v2, 16, 1                                   // 000000725EB0: D610003D 02052102
	v_bfe_u32 v62, v44, 16, 1                                  // 000000725EB8: D610003E 0205212C
	v_add3_u32 v42, v42, v59, 0x7fff                           // 000000725EC0: D655002A 03FE772A 00007FFF
	v_add3_u32 v11, v43, v60, 0x7fff                           // 000000725ECC: D655000B 03FE792B 00007FFF
	v_and_or_b32 v1, 0xffff0000, v1, v50                       // 000000725ED8: D6570001 04CA02FF FFFF0000
	.long 0x7e2a39a9                                           // 000000725EE4: 7E2A39A9
	.long 0x7f663995                                           // 000000725EE8: 7F663995
	v_bfe_u32 v63, v45, 16, 1                                  // 000000725EEC: D610003F 0205212D
	v_bfe_u32 v64, v46, 16, 1                                  // 000000725EF4: D6100040 0205212E
	v_add3_u32 v2, v2, v61, 0x7fff                             // 000000725EFC: D6550002 03FE7B02 00007FFF
	v_add3_u32 v40, v44, v62, 0x7fff                           // 000000725F08: D6550028 03FE7D2C 00007FFF
	.long 0x7e66398b                                           // 000000725F14: 7E66398B
	v_and_or_b32 v11, 0xffff0000, v42, v21                     // 000000725F18: D657000B 045654FF FFFF0000
	v_bfe_u32 v65, v3, 16, 1                                   // 000000725F24: D6100041 02052103
	v_bfe_u32 v66, v47, 16, 1                                  // 000000725F2C: D6100042 0205212F
	v_add3_u32 v43, v45, v63, 0x7fff                           // 000000725F34: D655002B 03FE7F2D 00007FFF
	v_add3_u32 v44, v46, v64, 0x7fff                           // 000000725F40: D655002C 03FE812E 00007FFF
	v_and_or_b32 v2, 0xffff0000, v2, v51                       // 000000725F4C: D6570002 04CE04FF FFFF0000
	.long 0x7e2a39a8                                           // 000000725F58: 7E2A39A8
	.long 0x7f683995                                           // 000000725F5C: 7F683995
	v_bfe_u32 v67, v48, 16, 1                                  // 000000725F60: D6100043 02052130
	v_bfe_u32 v68, v49, 16, 1                                  // 000000725F68: D6100044 02052131
	v_add3_u32 v3, v3, v65, 0x7fff                             // 000000725F70: D6550003 03FE8303 00007FFF
	.long 0x7e6839ac                                           // 000000725F7C: 7E6839AC
	v_bfe_u32 v69, v4, 16, 1                                   // 000000725F80: D6100045 02052104
	.long 0x7f6a3995                                           // 000000725F88: 7F6A3995
	s_and_b32 s1, exec_lo, s0                                  // 000000725F8C: 8B01007E
	.long 0xd700000d                                           // 000000725F90: D700000D
	v_cndmask_b32_e32 v0, v13, v144, vcc_lo                    // 000000725F94: 0201210D
	v_and_or_b32 v3, 0xffff0000, v3, v52                       // 000000725F98: D6570003 04D206FF FFFF0000
	v_add3_u32 v4, v4, v69, 0x7fff                             // 000000725FA4: D6550004 03FE8B04 00007FFF
	v_add_co_ci_u32_e64 v14, null, 0, v14, s0                  // 000000725FB0: D5207C0E 00021C80
	s_or_b32 s14, s1, s14                                      // 000000725FB8: 8C0E0E01
	s_waitcnt vmcnt(3)                                         // 000000725FBC: BF890FF7
	v_dot2_f32_bf16 v23, v23, v39, 0                           // 000000725FC0: CC1A4017 1A024F17
	s_waitcnt vmcnt(2)                                         // 000000725FC8: BF890BF7
	v_dot2_f32_bf16 v27, v27, v39, 0                           // 000000725FCC: CC1A401B 1A024F1B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000725FD4: BF870112
	v_dot2_f32_bf16 v23, v24, v1, v23                          // 000000725FD8: CC1A4017 1C5E0318
	v_dot2_f32_bf16 v1, v28, v1, v27                           // 000000725FE0: CC1A4001 1C6E031C
	v_add3_u32 v24, v47, v66, 0x7fff                           // 000000725FE8: D6550018 03FE852F 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000725FF4: BF870193
	v_dot2_f32_bf16 v23, v25, v11, v23                         // 000000725FF8: CC1A4017 1C5E1719
	v_dot2_f32_bf16 v1, v29, v11, v1                           // 000000726000: CC1A4001 1C06171D
	v_and_or_b32 v25, 0xffff0000, v43, v21                     // 000000726008: D6570019 045656FF FFFF0000
	v_add3_u32 v11, v48, v67, 0x7fff                           // 000000726014: D655000B 03FE8730 00007FFF
	.long 0x7e2a3998                                           // 000000726020: 7E2A3998
	v_dot2_f32_bf16 v23, v26, v2, v23                          // 000000726024: CC1A4017 1C5E051A
	v_dot2_f32_bf16 v1, v30, v2, v1                            // 00000072602C: CC1A4001 1C06051E
	v_add3_u32 v2, v49, v68, 0x7fff                            // 000000726034: D6550002 03FE8931 00007FFF
	s_waitcnt vmcnt(1)                                         // 000000726040: BF8907F7
	s_delay_alu instid0(VALU_DEP_3)                            // 000000726044: BF870003
	v_dot2_f32_bf16 v23, v31, v25, v23                         // 000000726048: CC1A4017 1C5E331F
	s_waitcnt vmcnt(0)                                         // 000000726050: BF8903F7
	v_dot2_f32_bf16 v1, v35, v25, v1                           // 000000726054: CC1A4001 1C063323
	.long 0x7e6a3982                                           // 00000072605C: 7E6A3982
	v_and_or_b32 v2, 0xffff0000, v11, v21                      // 000000726060: D6570002 045616FF FFFF0000
	v_dot2_f32_bf16 v11, v32, v3, v23                          // 00000072606C: CC1A400B 1C5E0720
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000726074: BF870214
	v_dot2_f32_bf16 v1, v36, v3, v1                            // 000000726078: CC1A4001 1C060724
	v_and_or_b32 v3, 0xffff0000, v4, v53                       // 000000726080: D6570003 04D608FF FFFF0000
	v_mov_b32_e32 v4, v8                                       // 00000072608C: 7E080308
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000726090: BF870214
	v_dot2_f32_bf16 v21, v33, v2, v11                          // 000000726094: CC1A4015 1C2E0521
	v_dot2_f32_bf16 v1, v37, v2, v1                            // 00000072609C: CC1A4001 1C060525
	v_mov_b32_e32 v11, v22                                     // 0000007260A4: 7E160316
	v_mov_b32_e32 v2, v6                                       // 0000007260A8: 7E040306
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000007260AC: BF870214
	v_dot2_f32_bf16 v8, v34, v3, v21                           // 0000007260B0: CC1A4008 1C560722
	v_dot2_f32_bf16 v21, v38, v3, v1                           // 0000007260B8: CC1A4015 1C060726
	v_mov_b32_e32 v3, v7                                       // 0000007260C0: 7E060307
	v_mov_b32_e32 v1, v5                                       // 0000007260C4: 7E020305
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007260C8: BF870003
	v_dual_add_f32 v19, v19, v8 :: v_dual_add_f32 v16, v16, v21// 0000007260CC: C9081113 13102B10
	.long 0x7e2a3900                                           // 0000007260D4: 7E2A3900
	s_and_not1_b32 exec_lo, exec_lo, s14                       // 0000007260D8: 917E0E7E
	s_cbranch_execz 29                                         // 0000007260DC: BFA5001D <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi2ELi16ELi1ELb1EEEvPKhPKtPvll+0x654>
	v_add_nc_u32_e32 v20, 16, v20                              // 0000007260E0: 4A282890
	v_add_nc_u32_e32 v22, 0x100, v11                           // 0000007260E4: 4A2C16FF 00000100
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000007260EC: BF8704A2
	.long 0xd4430000                                           // 0000007260F0: D4430000
	v_cndmask_b32_e32 v1, s2, v20, vcc_lo                      // 0000007260F4: 02022802
	s_and_saveexec_b32 s1, s0                                  // 0000007260F8: BE812000
	s_xor_b32 s1, exec_lo, s1                                  // 0000007260FC: 8D01017E
	v_add_nc_u32_e32 v22, 0x100, v11                           // 000000726100: 4A2C16FF 00000100
	s_or_saveexec_b32 s10, s1                                  // 000000726108: BE8A2201
	s_waitcnt vmcnt(0)                                         // 00000072610C: BF8903F7
	.long 0x7e003915                                           // 000000726110: 7E003915
	v_dual_mov_b32 v5, v1 :: v_dual_mov_b32 v6, v2             // 000000726114: CA100101 05060102
	v_dual_mov_b32 v7, v3 :: v_dual_mov_b32 v8, v4             // 00000072611C: CA100103 07080104
	s_xor_b32 exec_lo, exec_lo, s10                            // 000000726124: 8D7E0A7E
	s_cbranch_execz 65243                                      // 000000726128: BFA5FEDB <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi2ELi16ELi1ELb1EEEvPKhPKtPvll+0x198>
	.long 0xd7000105                                           // 00000072612C: D7000105
	v_cndmask_b32_e32 v1, v17, v22, vcc_lo                     // 000000726130: 02022D11
	s_delay_alu instid0(VALU_DEP_1)                            // 000000726134: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v18, s1                   // 000000726138: D5207C06 00062480
	global_load_b128 v[5:8], v[5:6], off                       // 000000726140: DC5E0000 057C0005
	global_load_d16_b16 v0, v[13:14], off                      // 000000726148: DC820000 007C000D
	s_branch 65233                                             // 000000726150: BFA0FED1 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi2ELi16ELi1ELb1EEEvPKhPKtPvll+0x198>
	s_or_b32 exec_lo, exec_lo, s14                             // 000000726154: 8C7E0E7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000726158: BF8700B9
	s_or_b32 exec_lo, exec_lo, s3                              // 00000072615C: 8C7E037E
	.long 0xd71f0000                                           // 000000726160: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000726164: 020100C1
	s_waitcnt vmcnt(1)                                         // 000000726168: BF8907F7
	v_xor_b32_e32 v1, 8, v0                                    // 00000072616C: 3A020088
	v_xor_b32_e32 v3, 4, v0                                    // 000000726170: 3A060084
	v_xor_b32_e32 v5, 2, v0                                    // 000000726174: 3A0A0082
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000726178: BF870093
	.long 0xd44c0000                                           // 00000072617C: D44C0000
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 000000726180: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s0                           // 000000726184: D5010001 00020300
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000072618C: BF870114
	.long 0xd44c0000                                           // 000000726190: D44C0000
	v_cndmask_b32_e32 v1, 32, v3, vcc_lo                       // 000000726194: 020206A0
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000726198: 30020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000072619C: BF8700D2
	v_cndmask_b32_e64 v3, v0, v3, s0                           // 0000007261A0: D5010003 00020700
	.long 0xd44c0000                                           // 0000007261A8: D44C0000
	v_cndmask_b32_e32 v1, 32, v5, vcc_lo                       // 0000007261AC: 02020AA0
	ds_bpermute_b32 v2, v1, v19                                // 0000007261B0: DACC0000 02001301
	v_cndmask_b32_e64 v5, v0, v5, s0                           // 0000007261B8: D5010005 00020B00
	s_waitcnt lgkmcnt(0)                                       // 0000007261C0: BF89FC07
	v_dual_add_f32 v2, v19, v2 :: v_dual_lshlrev_b32 v5, 2, v5 // 0000007261C4: C9220513 02040A82
	v_lshlrev_b32_e32 v3, 2, v3                                // 0000007261CC: 30060682
	ds_bpermute_b32 v1, v1, v16                                // 0000007261D0: DACC0000 01001001
	ds_bpermute_b32 v4, v3, v2                                 // 0000007261D8: DACC0000 04000203
	s_waitcnt lgkmcnt(0)                                       // 0000007261E0: BF89FC07
	v_dual_add_f32 v2, v2, v4 :: v_dual_add_f32 v1, v16, v1    // 0000007261E4: C9080902 02000310
	ds_bpermute_b32 v3, v3, v1                                 // 0000007261EC: DACC0000 03000103
	s_waitcnt lgkmcnt(0)                                       // 0000007261F4: BF89FC07
	v_add_f32_e32 v1, v1, v3                                   // 0000007261F8: 06020701
	ds_bpermute_b32 v3, v5, v2                                 // 0000007261FC: DACC0000 03000205
	ds_bpermute_b32 v4, v5, v1                                 // 000000726204: DACC0000 04000105
	v_xor_b32_e32 v5, 1, v0                                    // 00000072620C: 3A0A0081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000726210: BF870091
	.long 0xd44c0000                                           // 000000726214: D44C0000
	v_cndmask_b32_e32 v1, 32, v5, vcc_lo                       // 000000726218: 02020AA0
	v_cndmask_b32_e64 v0, v0, v5, s0                           // 00000072621C: D5010000 00020B00
	.long 0xd44a0000                                           // 000000726224: D44A0000
	v_cndmask_b32_e32 v1, 0, v15, vcc_lo                       // 000000726228: 02021E80
	s_waitcnt lgkmcnt(1)                                       // 00000072622C: BF89FC17
	s_delay_alu instid0(VALU_DEP_2)                            // 000000726230: BF870002
	v_dual_add_f32 v0, v2, v3 :: v_dual_lshlrev_b32 v5, 2, v0  // 000000726234: C9220702 00040082
	s_and_b32 s0, s0, vcc_lo                                   // 00000072623C: 8B006A00
	s_waitcnt lgkmcnt(0)                                       // 000000726240: BF89FC07
	v_add_f32_e32 v1, v1, v4                                   // 000000726244: 06020901
	ds_bpermute_b32 v2, v5, v0                                 // 000000726248: DACC0000 02000005
	ds_bpermute_b32 v3, v5, v1                                 // 000000726250: DACC0000 03000105
	s_and_saveexec_b32 s1, s0                                  // 000000726258: BE812000
	s_cbranch_execz 21                                         // 00000072625C: BFA50015 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi2ELi16ELi1ELb1EEEvPKhPKtPvll+0x7b4>
	.long 0xd73c0004                                           // 000000726260: D73C0004
	v_cndmask_b32_e32 v1, 2, v9, vcc_lo                        // 000000726264: 02021282
	s_waitcnt lgkmcnt(0)                                       // 000000726268: BF89FC07
	v_dual_add_f32 v6, v1, v3 :: v_dual_add_f32 v7, v0, v2     // 00000072626C: C9080701 06060500
	s_lshl_b64 s[0:1], s[12:13], 2                             // 000000726274: 8480820C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000726278: BF870092
	.long 0xd7006a00                                           // 00000072627C: D7006A00
	v_cndmask_b32_e32 v1, s8, v4, vcc_lo                       // 000000726280: 02020808
	v_add_co_ci_u32_e64 v1, null, s9, v5, vcc_lo               // 000000726284: D5207C01 01AA0A09
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000072628C: BF870092
	.long 0xd7006a02                                           // 000000726290: D7006A02
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 000000726294: 02000100
	v_add_co_ci_u32_e64 v3, null, s1, v1, vcc_lo               // 000000726298: D5207C03 01AA0201
	s_clause 0x1                                               // 0000007262A0: BF850001
	global_store_b32 v[0:1], v7, off                           // 0000007262A4: DC6A0000 007C0700
	global_store_b32 v[2:3], v6, off                           // 0000007262AC: DC6A0000 007C0602
	s_endpgm                                                   // 0000007262B4: BFB00000
		...

