000000000081a500 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 00000081A500: F4100100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 00000081A508: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 00000081A50C: 32040082
	s_lshl_b64 s[0:1], s[2:3], 3                               // 00000081A510: 84808302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000081A514: BF8701A9
	v_dual_mov_b32 v24, s1 :: v_dual_and_b32 v1, 15, v0        // 00000081A518: CA240001 1800008F
	v_and_b32_e32 v30, 31, v0                                  // 00000081A520: 363C009F
	v_and_b32_e32 v2, 60, v2                                   // 00000081A524: 360404BC
	v_lshlrev_b32_e32 v7, 2, v0                                // 00000081A528: 300E0082
	s_delay_alu instid0(VALU_DEP_4)                            // 00000081A52C: BF870004
	v_lshlrev_b32_e32 v1, 2, v1                                // 00000081A530: 30020282
	.long 0x7f0c3880                                           // 00000081A534: 7F0C3880
	s_waitcnt lgkmcnt(0)                                       // 00000081A538: BF89FC07
	s_clause 0x1                                               // 00000081A53C: BF850001
	global_load_b32 v3, v1, s[4:5]                             // 00000081A540: DC520000 03040001
	global_load_b32 v4, v2, s[4:5]                             // 00000081A548: DC520000 04040002
	v_lshrrev_b32_e32 v1, 5, v0                                // 00000081A550: 32020085
	s_add_u32 s22, s4, s16                                     // 00000081A554: 80161004
	s_addc_u32 s23, s5, s17                                    // 00000081A558: 82171105
	s_ashr_i32 s2, s11, 31                                     // 00000081A55C: 86029F0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000081A560: BF8704A1
	v_or_b32_e32 v23, s0, v1                                   // 00000081A564: 382E0200
	s_lshr_b32 s2, s2, 27                                      // 00000081A568: 85029B02
	s_add_u32 s2, s10, s2                                      // 00000081A56C: 8002020A
	s_addc_u32 s3, s11, 0                                      // 00000081A570: 8203800B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000081A574: BF8704A1
	.long 0xd4540000                                           // 00000081A578: D4540000
	v_cndmask_b32_e32 v1, s12, v23, vcc_lo                     // 00000081A57C: 02022E0C
	s_lshr_b64 s[20:21], s[2:3], 5                             // 00000081A580: 85948502
	s_cmpk_lt_i32 s20, 0x101                                   // 00000081A584: B3940101
	.long 0xd4440002                                           // 00000081A588: D4440002
	v_cndmask_b32_e32 v1, s20, v30, vcc_lo                     // 00000081A58C: 02023C14
	v_cndmask_b32_e64 v2, 0, v23, s0                           // 00000081A590: D5010002 00022E80
	v_cndmask_b32_e64 v5, 0, s1, s0                            // 00000081A598: D5010005 00000280
	s_cselect_b32 s1, -1, 0                                    // 00000081A5A0: 980180C1
	s_cmpk_gt_i32 s20, 0x100                                   // 00000081A5A4: B2940100
	s_delay_alu instid0(VALU_DEP_2)                            // 00000081A5A8: BF870002
	.long 0xd72c0008                                           // 00000081A5AC: D72C0008
	v_cndmask_b32_e32 v1, s19, v2, vcc_lo                      // 00000081A5B0: 02020413
	v_mad_u64_u32 v[0:1], null, s18, v2, 0                     // 00000081A5B4: D6FE7C00 02020412
	s_waitcnt vmcnt(1)                                         // 00000081A5BC: BF8907F7
	v_bfe_u32 v9, v3, 16, 1                                    // 00000081A5C0: D6100009 02052103
	s_waitcnt vmcnt(0)                                         // 00000081A5C8: BF8903F7
	v_bfe_u32 v10, v4, 16, 1                                   // 00000081A5CC: D610000A 02052104
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000081A5D4: BF8701A2
	v_add3_u32 v3, v3, v9, 0x7fff                              // 00000081A5D8: D6550003 03FE1303 00007FFF
	.long 0xd72c0009                                           // 00000081A5E4: D72C0009
	v_cndmask_b32_e32 v1, s18, v5, vcc_lo                      // 00000081A5E8: 02020A12
	v_add3_u32 v4, v4, v10, 0x7fff                             // 00000081A5EC: D6550004 03FE1504 00007FFF
	s_cselect_b32 s18, -1, 0                                   // 00000081A5F8: 981280C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000081A5FC: BF870239
	s_and_b32 vcc_lo, exec_lo, s18                             // 00000081A600: 8B6A127E
	.long 0x7e0c3983                                           // 00000081A604: 7E0C3983
	.long 0xd7000303                                           // 00000081A608: D7000303
	v_cndmask_b32_e32 v1, s22, v0, vcc_lo                      // 00000081A60C: 02020016
	v_add3_u32 v1, v1, v9, v8                                  // 00000081A610: D6550001 04221301
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000081A618: BF870113
	v_and_or_b32 v6, 0xffff0000, v4, v6                        // 00000081A61C: D6570006 041A08FF FFFF0000
	v_add_co_ci_u32_e64 v4, null, s23, v1, s3                  // 00000081A628: D5207C04 000E0217
	ds_store_b32 v7, v6                                        // 00000081A630: D8340000 00000607
	s_waitcnt lgkmcnt(0)                                       // 00000081A638: BF89FC07
	s_barrier                                                  // 00000081A63C: BFBD0000
	buffer_gl0_inv                                             // 00000081A640: E0AC0000 00000000
	s_cbranch_vccnz 146                                        // 00000081A648: BFA40092 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x394>
	v_dual_mov_b32 v8, 0 :: v_dual_mov_b32 v7, 0               // 00000081A64C: CA100080 08060080
	s_and_saveexec_b32 s3, s2                                  // 00000081A654: BE832002
	s_cbranch_execz 10                                         // 00000081A658: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x184>
	v_lshlrev_b32_e32 v6, 1, v30                               // 00000081A65C: 300C3C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081A660: BF870091
	.long 0xd7006a06                                           // 00000081A664: D7006A06
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000081A668: 02020D03
	v_add_co_ci_u32_e64 v7, null, 0, v4, vcc_lo                // 00000081A66C: D5207C07 01AA0880
	global_load_d16_b16 v6, v[6:7], off                        // 00000081A674: DC820000 067C0006
	s_waitcnt vmcnt(0)                                         // 00000081A67C: BF8903F7
	v_cvt_f32_f16_e32 v7, v6                                   // 00000081A680: 7E0E1706
	s_or_b32 exec_lo, exec_lo, s3                              // 00000081A684: 8C7E037E
	v_or_b32_e32 v6, 32, v30                                   // 00000081A688: 380C3CA0
	s_mov_b32 s2, exec_lo                                      // 00000081A68C: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000081A690: BF870001
	.long 0xd4c4007e                                           // 00000081A694: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 00000081A698: 02020C14
	s_cbranch_execz 10                                         // 00000081A69C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x1c8>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000081A6A0: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081A6A4: BF870091
	.long 0xd7006a08                                           // 00000081A6A8: D7006A08
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000081A6AC: 02020D03
	v_add_co_ci_u32_e64 v9, null, 0, v4, vcc_lo                // 00000081A6B0: D5207C09 01AA0880
	global_load_d16_b16 v6, v[8:9], off                        // 00000081A6B8: DC820000 067C0008
	s_waitcnt vmcnt(0)                                         // 00000081A6C0: BF8903F7
	v_cvt_f32_f16_e32 v8, v6                                   // 00000081A6C4: 7E101706
	s_or_b32 exec_lo, exec_lo, s2                              // 00000081A6C8: 8C7E027E
	v_or_b32_e32 v6, 64, v30                                   // 00000081A6CC: 380C3CC0
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v9, 0              // 00000081A6D0: CA100080 0A080080
	s_mov_b32 s2, exec_lo                                      // 00000081A6D8: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000081A6DC: BF870002
	.long 0xd4c4007e                                           // 00000081A6E0: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 00000081A6E4: 02020C14
	s_cbranch_execz 10                                         // 00000081A6E8: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x214>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000081A6EC: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081A6F0: BF870091
	.long 0xd7006a0b                                           // 00000081A6F4: D7006A0B
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000081A6F8: 02020D03
	v_add_co_ci_u32_e64 v12, null, 0, v4, vcc_lo               // 00000081A6FC: D5207C0C 01AA0880
	global_load_d16_b16 v6, v[11:12], off                      // 00000081A704: DC820000 067C000B
	s_waitcnt vmcnt(0)                                         // 00000081A70C: BF8903F7
	v_cvt_f32_f16_e32 v9, v6                                   // 00000081A710: 7E121706
	s_or_b32 exec_lo, exec_lo, s2                              // 00000081A714: 8C7E027E
	v_or_b32_e32 v6, 0x60, v30                                 // 00000081A718: 380C3CFF 00000060
	s_mov_b32 s2, exec_lo                                      // 00000081A720: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000081A724: BF870001
	.long 0xd4c4007e                                           // 00000081A728: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 00000081A72C: 02020C14
	s_cbranch_execz 10                                         // 00000081A730: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x25c>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000081A734: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081A738: BF870091
	.long 0xd7006a0a                                           // 00000081A73C: D7006A0A
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000081A740: 02020D03
	v_add_co_ci_u32_e64 v11, null, 0, v4, vcc_lo               // 00000081A744: D5207C0B 01AA0880
	global_load_d16_b16 v6, v[10:11], off                      // 00000081A74C: DC820000 067C000A
	s_waitcnt vmcnt(0)                                         // 00000081A754: BF8903F7
	v_cvt_f32_f16_e32 v10, v6                                  // 00000081A758: 7E141706
	s_or_b32 exec_lo, exec_lo, s2                              // 00000081A75C: 8C7E027E
	v_or_b32_e32 v6, 0x80, v30                                 // 00000081A760: 380C3CFF 00000080
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v11, 0             // 00000081A768: CA100080 0C0A0080
	s_mov_b32 s2, exec_lo                                      // 00000081A770: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000081A774: BF870002
	.long 0xd4c4007e                                           // 00000081A778: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 00000081A77C: 02020C14
	s_cbranch_execz 10                                         // 00000081A780: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x2ac>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000081A784: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081A788: BF870091
	.long 0xd7006a0d                                           // 00000081A78C: D7006A0D
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000081A790: 02020D03
	v_add_co_ci_u32_e64 v14, null, 0, v4, vcc_lo               // 00000081A794: D5207C0E 01AA0880
	global_load_d16_b16 v6, v[13:14], off                      // 00000081A79C: DC820000 067C000D
	s_waitcnt vmcnt(0)                                         // 00000081A7A4: BF8903F7
	v_cvt_f32_f16_e32 v11, v6                                  // 00000081A7A8: 7E161706
	s_or_b32 exec_lo, exec_lo, s2                              // 00000081A7AC: 8C7E027E
	v_or_b32_e32 v6, 0xa0, v30                                 // 00000081A7B0: 380C3CFF 000000A0
	s_mov_b32 s2, exec_lo                                      // 00000081A7B8: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000081A7BC: BF870001
	.long 0xd4c4007e                                           // 00000081A7C0: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 00000081A7C4: 02020C14
	s_cbranch_execz 10                                         // 00000081A7C8: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x2f4>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000081A7CC: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081A7D0: BF870091
	.long 0xd7006a0c                                           // 00000081A7D4: D7006A0C
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000081A7D8: 02020D03
	v_add_co_ci_u32_e64 v13, null, 0, v4, vcc_lo               // 00000081A7DC: D5207C0D 01AA0880
	global_load_d16_b16 v6, v[12:13], off                      // 00000081A7E4: DC820000 067C000C
	s_waitcnt vmcnt(0)                                         // 00000081A7EC: BF8903F7
	v_cvt_f32_f16_e32 v12, v6                                  // 00000081A7F0: 7E181706
	s_or_b32 exec_lo, exec_lo, s2                              // 00000081A7F4: 8C7E027E
	v_or_b32_e32 v6, 0xc0, v30                                 // 00000081A7F8: 380C3CFF 000000C0
	v_dual_mov_b32 v14, 0 :: v_dual_mov_b32 v13, 0             // 00000081A800: CA100080 0E0C0080
	s_mov_b32 s2, exec_lo                                      // 00000081A808: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000081A80C: BF870002
	.long 0xd4c4007e                                           // 00000081A810: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 00000081A814: 02020C14
	s_cbranch_execz 10                                         // 00000081A818: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x344>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000081A81C: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081A820: BF870091
	.long 0xd7006a0f                                           // 00000081A824: D7006A0F
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000081A828: 02020D03
	v_add_co_ci_u32_e64 v16, null, 0, v4, vcc_lo               // 00000081A82C: D5207C10 01AA0880
	global_load_d16_b16 v6, v[15:16], off                      // 00000081A834: DC820000 067C000F
	s_waitcnt vmcnt(0)                                         // 00000081A83C: BF8903F7
	v_cvt_f32_f16_e32 v13, v6                                  // 00000081A840: 7E1A1706
	s_or_b32 exec_lo, exec_lo, s2                              // 00000081A844: 8C7E027E
	v_or_b32_e32 v6, 0xe0, v30                                 // 00000081A848: 380C3CFF 000000E0
	s_mov_b32 s2, exec_lo                                      // 00000081A850: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000081A854: BF870001
	.long 0xd4c4007e                                           // 00000081A858: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 00000081A85C: 02020C14
	s_cbranch_execz 10                                         // 00000081A860: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x38c>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000081A864: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081A868: BF870091
	.long 0xd7006a0e                                           // 00000081A86C: D7006A0E
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000081A870: 02020D03
	v_add_co_ci_u32_e64 v15, null, 0, v4, vcc_lo               // 00000081A874: D5207C0F 01AA0880
	global_load_d16_b16 v6, v[14:15], off                      // 00000081A87C: DC820000 067C000E
	s_waitcnt vmcnt(0)                                         // 00000081A884: BF8903F7
	v_cvt_f32_f16_e32 v14, v6                                  // 00000081A888: 7E1C1706
	s_or_b32 exec_lo, exec_lo, s2                              // 00000081A88C: 8C7E027E
	s_branch 9                                                 // 00000081A890: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x3b8>
	v_mov_b32_e32 v7, 0                                        // 00000081A894: 7E0E0280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000081A898: BF870001
	v_mov_b32_e32 v8, v7                                       // 00000081A89C: 7E100307
	v_mov_b32_e32 v9, v7                                       // 00000081A8A0: 7E120307
	v_mov_b32_e32 v10, v7                                      // 00000081A8A4: 7E140307
	v_mov_b32_e32 v11, v7                                      // 00000081A8A8: 7E160307
	v_mov_b32_e32 v12, v7                                      // 00000081A8AC: 7E180307
	v_mov_b32_e32 v13, v7                                      // 00000081A8B0: 7E1A0307
	v_mov_b32_e32 v14, v7                                      // 00000081A8B4: 7E1C0307
	s_add_u32 s2, s4, s14                                      // 00000081A8B8: 80020E04
	s_addc_u32 s3, s5, s15                                     // 00000081A8BC: 82030F05
	s_lshr_b32 s14, s11, 31                                    // 00000081A8C0: 850E9F0B
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v32, 0             // 00000081A8C4: CA100080 13200080
	s_add_u32 s14, s10, s14                                    // 00000081A8CC: 800E0E0A
	s_addc_u32 s15, s11, 0                                     // 00000081A8D0: 820F800B
	v_cndmask_b32_e64 v31, 0, 1, s18                           // 00000081A8D4: D501001F 00490280
	s_ashr_i64 s[14:15], s[14:15], 1                           // 00000081A8DC: 868E810E
	v_dual_mov_b32 v42, 0 :: v_dual_mov_b32 v21, 0             // 00000081A8E0: CA100080 2A140080
	v_mad_u64_u32 v[25:26], null, v2, s14, s[2:3]              // 00000081A8E8: D6FE7C19 00081D02
	.long 0xd72c0002                                           // 00000081A8F0: D72C0002
	v_cndmask_b32_e32 v0, v2, v15, vcc_lo                      // 00000081A8F4: 02001F02
	.long 0xd72c0005                                           // 00000081A8F8: D72C0005
	v_cndmask_b32_e32 v0, v5, v14, vcc_lo                      // 00000081A8FC: 02001D05
	.long 0xd4440002                                           // 00000081A900: D4440002
	v_cndmask_b32_e32 v1, s20, v30, vcc_lo                     // 00000081A904: 02023C14
	v_mov_b32_e32 v20, 0                                       // 00000081A908: 7E280280
	v_mov_b32_e32 v22, 0                                       // 00000081A90C: 7E2C0280
	s_delay_alu instid0(VALU_DEP_4)                            // 00000081A910: BF870004
	v_add3_u32 v33, v5, v26, v2                                // 00000081A914: D6550021 040A3505
	s_and_saveexec_b32 s3, s2                                  // 00000081A91C: BE832002
	s_cbranch_execz 21                                         // 00000081A920: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x478>
	v_lshlrev_b32_e32 v2, 4, v30                               // 00000081A924: 30043C84
	v_mov_b32_e32 v42, 0                                       // 00000081A928: 7E540280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081A92C: BF870092
	.long 0xd7006a05                                           // 00000081A930: D7006A05
	v_cndmask_b32_e32 v1, v25, v2, vcc_lo                      // 00000081A934: 02020519
	v_add_co_ci_u32_e64 v6, null, 0, v33, vcc_lo               // 00000081A938: D5207C06 01AA4280
	s_and_not1_b32 vcc_lo, exec_lo, s18                        // 00000081A940: 916A127E
	global_load_b128 v[19:22], v[5:6], off                     // 00000081A944: DC5E0000 137C0005
	s_cbranch_vccnz 10                                         // 00000081A94C: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x478>
	v_lshlrev_b32_e32 v2, 1, v30                               // 00000081A950: 30043C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081A954: BF870091
	.long 0xd7006a02                                           // 00000081A958: D7006A02
	v_cndmask_b32_e32 v1, v3, v2, vcc_lo                       // 00000081A95C: 02020503
	v_add_co_ci_u32_e64 v3, null, 0, v4, vcc_lo                // 00000081A960: D5207C03 01AA0880
	global_load_d16_b16 v2, v[2:3], off                        // 00000081A968: DC820000 027C0002
	s_waitcnt vmcnt(0)                                         // 00000081A970: BF8903F7
	v_cvt_f32_f16_e32 v42, v2                                  // 00000081A974: 7E541702
	s_or_b32 exec_lo, exec_lo, s3                              // 00000081A978: 8C7E037E
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v35, 0             // 00000081A97C: CA100080 22220080
	v_dual_mov_b32 v36, 0 :: v_dual_mov_b32 v37, 0             // 00000081A984: CA100080 24240080
	v_mov_b32_e32 v38, 0                                       // 00000081A98C: 7E4C0280
	s_and_saveexec_b32 s3, s2                                  // 00000081A990: BE832002
	s_cbranch_execz 565                                        // 00000081A994: BFA50235 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0xd6c>
	v_dual_mov_b32 v27, 0 :: v_dual_lshlrev_b32 v2, 1, v30     // 00000081A998: CA220080 1B023C81
	.long 0xd7006a00                                           // 00000081A9A0: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 00000081A9A4: 02020010
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000081A9A8: BF870191
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 00000081A9AC: D5207C01 01AA0211
	v_dual_mov_b32 v37, v27 :: v_dual_lshlrev_b32 v26, 5, v30  // 00000081A9B4: CA22011B 251A3C85
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081A9BC: BF870093
	.long 0xd7006a00                                           // 00000081A9C0: D7006A00
	v_cndmask_b32_e32 v1, v0, v2, vcc_lo                       // 00000081A9C4: 02020500
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 00000081A9C8: D5207C01 01AA0280
	v_lshl_or_b32 v39, v30, 4, 0x200                           // 00000081A9D0: D6560027 03FD091E 00000200
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081A9DC: BF870093
	.long 0xd7006a00                                           // 00000081A9E0: D7006A00
	v_cndmask_b32_e32 v1, s4, v0, vcc_lo                       // 00000081A9E4: 02020004
	v_add_co_ci_u32_e64 v1, null, s5, v1, vcc_lo               // 00000081A9E8: D5207C01 01AA0205
	v_dual_mov_b32 v40, v30 :: v_dual_mov_b32 v35, v27         // 00000081A9F0: CA10011E 2822011B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081A9F8: BF870093
	.long 0xd7006a1c                                           // 00000081A9FC: D7006A1C
	v_cndmask_b32_e32 v0, v0, v192, vcc_lo                     // 00000081AA00: 02018100
	v_add_co_ci_u32_e64 v29, null, 0, v1, vcc_lo               // 00000081AA04: D5207C1D 01AA0280
	v_dual_mov_b32 v38, v27 :: v_dual_mov_b32 v41, v42         // 00000081AA0C: CA10011B 2628012A
	v_mov_b32_e32 v36, v27                                     // 00000081AA14: 7E48031B
	v_mov_b32_e32 v34, v27                                     // 00000081AA18: 7E44031B
	v_mov_b32_e32 v32, v27                                     // 00000081AA1C: 7E40031B
	s_mul_i32 s2, s11, 6                                       // 00000081AA20: 9602860B
	s_mul_hi_u32 s18, s10, 6                                   // 00000081AA24: 9692860A
	s_lshl_b64 s[14:15], s[10:11], 2                           // 00000081AA28: 848E820A
	s_add_i32 s18, s18, s2                                     // 00000081AA2C: 81120212
	s_mul_i32 s17, s10, 6                                      // 00000081AA30: 9611860A
	s_mov_b32 s16, 0                                           // 00000081AA34: BE900080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 00000081AA38: 8484810A
	s_branch 494                                               // 00000081AA3C: BFA001EE <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0xcf8>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000081AA40: 8C7E0A7E
	v_cndmask_b32_e64 v52, v42, v7, s1                         // 00000081AA44: D5010034 00060F2A
	v_cndmask_b32_e64 v1, v8, v9, s1                           // 00000081AA4C: D5010001 00061308
	v_cndmask_b32_e64 v0, v7, v8, s1                           // 00000081AA54: D5010000 00061107
	v_dual_mov_b32 v7, v14 :: v_dual_and_b32 v8, 0xff, v19     // 00000081AA5C: CA24010E 070826FF 000000FF
	v_cndmask_b32_e64 v6, v13, v14, s1                         // 00000081AA68: D5010006 00061D0D
	v_cndmask_b32_e64 v5, v12, v13, s1                         // 00000081AA70: D5010005 00061B0C
	v_cndmask_b32_e64 v4, v11, v12, s1                         // 00000081AA78: D5010004 0006190B
	v_cndmask_b32_e64 v3, v10, v11, s1                         // 00000081AA80: D5010003 0006170A
	v_lshlrev_b32_e32 v8, 2, v8                                // 00000081AA88: 30101082
	v_cndmask_b32_e64 v2, v9, v10, s1                          // 00000081AA8C: D5010002 00061509
	s_and_b32 s2, exec_lo, s2                                  // 00000081AA94: 8B02027E
	v_add_nc_u32_e32 v39, 0x200, v39                           // 00000081AA98: 4A4E4EFF 00000200
	s_or_b32 s16, s2, s16                                      // 00000081AAA0: 8C101002
	ds_load_b32 v14, v8                                        // 00000081AAA4: D8D80000 0E000008
	v_lshrrev_b32_e32 v8, 6, v19                               // 00000081AAAC: 32102686
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000081AAB0: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000081AAB4: 361010FF 000003FC
	ds_load_b32 v53, v8                                        // 00000081AABC: D8D80000 35000008
	v_lshrrev_b32_e32 v8, 14, v19                              // 00000081AAC4: 3210268E
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000081AAC8: 361010FF 000003FC
	ds_load_b32 v54, v8                                        // 00000081AAD0: D8D80000 36000008
	v_lshrrev_b32_e32 v8, 22, v19                              // 00000081AAD8: 32102696
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000081AADC: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000081AAE0: 361010FF 000003FC
	ds_load_b32 v55, v8                                        // 00000081AAE8: D8D80000 37000008
	v_and_b32_e32 v8, 0xff, v20                                // 00000081AAF0: 361028FF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 00000081AAF8: 30101082
	ds_load_b32 v56, v8                                        // 00000081AAFC: D8D80000 38000008
	v_lshrrev_b32_e32 v8, 6, v20                               // 00000081AB04: 32102886
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000081AB08: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000081AB0C: 361010FF 000003FC
	ds_load_b32 v57, v8                                        // 00000081AB14: D8D80000 39000008
	v_lshrrev_b32_e32 v8, 14, v20                              // 00000081AB1C: 3210288E
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000081AB20: 361010FF 000003FC
	ds_load_b32 v58, v8                                        // 00000081AB28: D8D80000 3A000008
	v_lshrrev_b32_e32 v8, 22, v20                              // 00000081AB30: 32102896
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000081AB34: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000081AB38: 361010FF 000003FC
	ds_load_b32 v59, v8                                        // 00000081AB40: D8D80000 3B000008
	v_and_b32_e32 v8, 0xff, v21                                // 00000081AB48: 36102AFF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 00000081AB50: 30101082
	ds_load_b32 v60, v8                                        // 00000081AB54: D8D80000 3C000008
	v_lshrrev_b32_e32 v8, 6, v21                               // 00000081AB5C: 32102A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000081AB60: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000081AB64: 361010FF 000003FC
	ds_load_b32 v61, v8                                        // 00000081AB6C: D8D80000 3D000008
	v_lshrrev_b32_e32 v8, 14, v21                              // 00000081AB74: 32102A8E
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000081AB78: 361010FF 000003FC
	ds_load_b32 v62, v8                                        // 00000081AB80: D8D80000 3E000008
	v_lshrrev_b32_e32 v8, 22, v21                              // 00000081AB88: 32102A96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000081AB8C: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000081AB90: 361010FF 000003FC
	ds_load_b32 v63, v8                                        // 00000081AB98: D8D80000 3F000008
	v_and_b32_e32 v8, 0xff, v22                                // 00000081ABA0: 36102CFF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 00000081ABA8: 30101082
	ds_load_b32 v64, v8                                        // 00000081ABAC: D8D80000 40000008
	v_lshrrev_b32_e32 v8, 6, v22                               // 00000081ABB4: 32102C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000081ABB8: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000081ABBC: 361010FF 000003FC
	ds_load_b32 v65, v8                                        // 00000081ABC4: D8D80000 41000008
	v_lshrrev_b32_e32 v8, 14, v22                              // 00000081ABCC: 32102C8E
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000081ABD0: 361010FF 000003FC
	ds_load_b32 v66, v8                                        // 00000081ABD8: D8D80000 42000008
	v_lshrrev_b32_e32 v8, 22, v22                              // 00000081ABE0: 32102C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000081ABE4: BF870141
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000081ABE8: 361010FF 000003FC
	ds_load_b32 v67, v8                                        // 00000081ABF0: D8D80000 43000008
	.long 0xd73c0008                                           // 00000081ABF8: D73C0008
	v_cndmask_b32_e32 v1, 1, v26, vcc_lo                       // 00000081ABFC: 02023481
	v_add_nc_u32_e32 v26, 0x400, v26                           // 00000081AC00: 4A3434FF 00000400
	.long 0xd7006a0c                                           // 00000081AC08: D7006A0C
	v_cndmask_b32_e32 v1, s6, v8, vcc_lo                       // 00000081AC0C: 02021006
	s_delay_alu instid0(VALU_DEP_1)                            // 00000081AC10: BF870001
	v_add_co_ci_u32_e64 v13, null, s7, v9, vcc_lo              // 00000081AC14: D5207C0D 01AA1207
	s_clause 0x3                                               // 00000081AC1C: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 00000081AC20: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 00000081AC28: DC5E0010 137C000C
	global_load_b128 v[42:45], v[12:13], off offset:32         // 00000081AC30: DC5E0020 2A7C000C
	global_load_b128 v[46:49], v[12:13], off offset:48         // 00000081AC38: DC5E0030 2E7C000C
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 00000081AC40: BF890CF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000081AC44: CC1A4008 1A021D08
	s_waitcnt lgkmcnt(14)                                      // 00000081AC4C: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000081AC50: BF8700A1
	v_dot2_f32_bf16 v8, v9, v53, v8                            // 00000081AC54: CC1A4008 1C226B09
	s_waitcnt lgkmcnt(13)                                      // 00000081AC5C: BF89FCD7
	v_dot2_f32_bf16 v8, v10, v54, v8                           // 00000081AC60: CC1A4008 1C226D0A
	s_waitcnt lgkmcnt(12)                                      // 00000081AC68: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000081AC6C: BF8700A1
	v_dot2_f32_bf16 v8, v11, v55, v8                           // 00000081AC70: CC1A4008 1C226F0B
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 00000081AC78: BF8908B7
	v_dot2_f32_bf16 v8, v19, v56, v8                           // 00000081AC7C: CC1A4008 1C227113
	s_waitcnt lgkmcnt(10)                                      // 00000081AC84: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000081AC88: BF8700A1
	v_dot2_f32_bf16 v8, v20, v57, v8                           // 00000081AC8C: CC1A4008 1C227314
	s_waitcnt lgkmcnt(9)                                       // 00000081AC94: BF89FC97
	v_dot2_f32_bf16 v8, v21, v58, v8                           // 00000081AC98: CC1A4008 1C227515
	s_waitcnt lgkmcnt(8)                                       // 00000081ACA0: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000081ACA4: BF8700A1
	v_dot2_f32_bf16 v8, v22, v59, v8                           // 00000081ACA8: CC1A4008 1C227716
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 00000081ACB0: BF890477
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 00000081ACB4: CC1A4008 1C22792A
	s_waitcnt lgkmcnt(6)                                       // 00000081ACBC: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000081ACC0: BF8700A1
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 00000081ACC4: CC1A4008 1C227B2B
	s_waitcnt lgkmcnt(5)                                       // 00000081ACCC: BF89FC57
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 00000081ACD0: CC1A4008 1C227D2C
	s_waitcnt lgkmcnt(4)                                       // 00000081ACD8: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000081ACDC: BF8700A1
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 00000081ACE0: CC1A4008 1C227F2D
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 00000081ACE8: BF890037
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 00000081ACEC: CC1A4008 1C22812E
	.long 0xd7006a2e                                           // 00000081ACF4: D7006A2E
	v_cndmask_b32_e32 v0, v12, v4, vcc_lo                      // 00000081ACF8: 0200090C
	s_waitcnt lgkmcnt(2)                                       // 00000081ACFC: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000081AD00: BF8701C2
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 00000081AD04: CC1A4008 1C22832F
	v_add_co_ci_u32_e64 v47, null, s5, v13, vcc_lo             // 00000081AD0C: D5207C2F 01AA1A05
	.long 0xd7006a32                                           // 00000081AD14: D7006A32
	v_cndmask_b32_e32 v0, v12, v14, vcc_lo                     // 00000081AD18: 02001D0C
	s_waitcnt lgkmcnt(1)                                       // 00000081AD1C: BF89FC17
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 00000081AD20: CC1A4008 1C228530
	v_add_co_ci_u32_e64 v51, null, s15, v13, vcc_lo            // 00000081AD28: D5207C33 01AA1A0F
	.long 0xd7006a0c                                           // 00000081AD30: D7006A0C
	v_cndmask_b32_e32 v0, v12, v17, vcc_lo                     // 00000081AD34: 0200230C
	s_waitcnt lgkmcnt(0)                                       // 00000081AD38: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000081AD3C: BF870123
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 00000081AD40: CC1A4008 1C228731
	v_add_co_ci_u32_e64 v13, null, s18, v13, vcc_lo            // 00000081AD48: D5207C0D 01AA1A12
	v_fmac_f32_e32 v38, v52, v8                                // 00000081AD50: 564C1134
	s_clause 0x3                                               // 00000081AD54: BF850003
	global_load_b128 v[8:11], v[46:47], off                    // 00000081AD58: DC5E0000 087C002E
	global_load_b128 v[19:22], v[46:47], off offset:16         // 00000081AD60: DC5E0010 137C002E
	global_load_b128 v[42:45], v[46:47], off offset:32         // 00000081AD68: DC5E0020 2A7C002E
	global_load_b128 v[46:49], v[46:47], off offset:48         // 00000081AD70: DC5E0030 2E7C002E
	s_waitcnt vmcnt(3)                                         // 00000081AD78: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000081AD7C: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081AD84: BF870091
	v_dot2_f32_bf16 v8, v9, v53, v8                            // 00000081AD88: CC1A4008 1C226B09
	v_dot2_f32_bf16 v8, v10, v54, v8                           // 00000081AD90: CC1A4008 1C226D0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000081AD98: BF8700A1
	v_dot2_f32_bf16 v8, v11, v55, v8                           // 00000081AD9C: CC1A4008 1C226F0B
	s_waitcnt vmcnt(2)                                         // 00000081ADA4: BF890BF7
	v_dot2_f32_bf16 v8, v19, v56, v8                           // 00000081ADA8: CC1A4008 1C227113
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081ADB0: BF870091
	v_dot2_f32_bf16 v8, v20, v57, v8                           // 00000081ADB4: CC1A4008 1C227314
	v_dot2_f32_bf16 v8, v21, v58, v8                           // 00000081ADBC: CC1A4008 1C227515
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000081ADC4: BF8700A1
	v_dot2_f32_bf16 v8, v22, v59, v8                           // 00000081ADC8: CC1A4008 1C227716
	s_waitcnt vmcnt(1)                                         // 00000081ADD0: BF8907F7
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 00000081ADD4: CC1A4008 1C22792A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081ADDC: BF870091
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 00000081ADE0: CC1A4008 1C227B2B
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 00000081ADE8: CC1A4008 1C227D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000081ADF0: BF8700A1
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 00000081ADF4: CC1A4008 1C227F2D
	s_waitcnt vmcnt(0)                                         // 00000081ADFC: BF8903F7
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 00000081AE00: CC1A4008 1C22812E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081AE08: BF870091
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 00000081AE0C: CC1A4008 1C22832F
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 00000081AE14: CC1A4008 1C228530
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081AE1C: BF870091
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 00000081AE20: CC1A4008 1C228731
	v_fmac_f32_e32 v37, v52, v8                                // 00000081AE28: 564A1134
	s_clause 0x3                                               // 00000081AE2C: BF850003
	global_load_b128 v[8:11], v[50:51], off                    // 00000081AE30: DC5E0000 087C0032
	global_load_b128 v[19:22], v[50:51], off offset:16         // 00000081AE38: DC5E0010 137C0032
	global_load_b128 v[42:45], v[50:51], off offset:32         // 00000081AE40: DC5E0020 2A7C0032
	global_load_b128 v[46:49], v[50:51], off offset:48         // 00000081AE48: DC5E0030 2E7C0032
	s_waitcnt vmcnt(3)                                         // 00000081AE50: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000081AE54: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081AE5C: BF870091
	v_dot2_f32_bf16 v8, v9, v53, v8                            // 00000081AE60: CC1A4008 1C226B09
	v_dot2_f32_bf16 v8, v10, v54, v8                           // 00000081AE68: CC1A4008 1C226D0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000081AE70: BF8700A1
	v_dot2_f32_bf16 v8, v11, v55, v8                           // 00000081AE74: CC1A4008 1C226F0B
	s_waitcnt vmcnt(2)                                         // 00000081AE7C: BF890BF7
	v_dot2_f32_bf16 v8, v19, v56, v8                           // 00000081AE80: CC1A4008 1C227113
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081AE88: BF870091
	v_dot2_f32_bf16 v8, v20, v57, v8                           // 00000081AE8C: CC1A4008 1C227314
	v_dot2_f32_bf16 v8, v21, v58, v8                           // 00000081AE94: CC1A4008 1C227515
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000081AE9C: BF8700A1
	v_dot2_f32_bf16 v8, v22, v59, v8                           // 00000081AEA0: CC1A4008 1C227716
	s_waitcnt vmcnt(1)                                         // 00000081AEA8: BF8907F7
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 00000081AEAC: CC1A4008 1C22792A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081AEB4: BF870091
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 00000081AEB8: CC1A4008 1C227B2B
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 00000081AEC0: CC1A4008 1C227D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000081AEC8: BF8700A1
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 00000081AECC: CC1A4008 1C227F2D
	s_waitcnt vmcnt(0)                                         // 00000081AED4: BF8903F7
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 00000081AED8: CC1A4008 1C22812E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081AEE0: BF870091
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 00000081AEE4: CC1A4008 1C22832F
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 00000081AEEC: CC1A4008 1C228530
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081AEF4: BF870091
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 00000081AEF8: CC1A4008 1C228731
	v_fmac_f32_e32 v36, v52, v8                                // 00000081AF00: 56481134
	s_clause 0x3                                               // 00000081AF04: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 00000081AF08: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 00000081AF10: DC5E0010 137C000C
	global_load_b128 v[42:45], v[12:13], off offset:32         // 00000081AF18: DC5E0020 2A7C000C
	global_load_b128 v[46:49], v[12:13], off offset:48         // 00000081AF20: DC5E0030 2E7C000C
	s_waitcnt vmcnt(3)                                         // 00000081AF28: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000081AF2C: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081AF34: BF870091
	v_dot2_f32_bf16 v8, v9, v53, v8                            // 00000081AF38: CC1A4008 1C226B09
	v_dot2_f32_bf16 v8, v10, v54, v8                           // 00000081AF40: CC1A4008 1C226D0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000081AF48: BF8700A1
	v_dot2_f32_bf16 v8, v11, v55, v8                           // 00000081AF4C: CC1A4008 1C226F0B
	s_waitcnt vmcnt(2)                                         // 00000081AF54: BF890BF7
	v_dot2_f32_bf16 v8, v19, v56, v8                           // 00000081AF58: CC1A4008 1C227113
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081AF60: BF870091
	v_dot2_f32_bf16 v8, v20, v57, v8                           // 00000081AF64: CC1A4008 1C227314
	v_dot2_f32_bf16 v8, v21, v58, v8                           // 00000081AF6C: CC1A4008 1C227515
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000081AF74: BF8700A1
	v_dot2_f32_bf16 v8, v22, v59, v8                           // 00000081AF78: CC1A4008 1C227716
	s_waitcnt vmcnt(1)                                         // 00000081AF80: BF8907F7
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 00000081AF84: CC1A4008 1C22792A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081AF8C: BF870091
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 00000081AF90: CC1A4008 1C227B2B
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 00000081AF98: CC1A4008 1C227D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000081AFA0: BF8700A1
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 00000081AFA4: CC1A4008 1C227F2D
	s_waitcnt vmcnt(0)                                         // 00000081AFAC: BF8903F7
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 00000081AFB0: CC1A4008 1C22812E
	.long 0xd7006a2e                                           // 00000081AFB8: D7006A2E
	v_cndmask_b32_e32 v0, v50, v14, vcc_lo                     // 00000081AFBC: 02001D32
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000081AFC0: BF8701B2
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 00000081AFC4: CC1A4008 1C22832F
	v_add_co_ci_u32_e64 v47, null, s15, v51, vcc_lo            // 00000081AFCC: D5207C2F 01AA660F
	.long 0xd7006a0c                                           // 00000081AFD4: D7006A0C
	v_cndmask_b32_e32 v0, v12, v14, vcc_lo                     // 00000081AFD8: 02001D0C
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 00000081AFDC: CC1A4008 1C228530
	v_add_co_ci_u32_e64 v13, null, s15, v13, vcc_lo            // 00000081AFE4: D5207C0D 01AA1A0F
	.long 0xd7006a1c                                           // 00000081AFEC: D7006A1C
	v_cndmask_b32_e32 v0, v28, v192, vcc_lo                    // 00000081AFF0: 0201811C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000081AFF4: BF870123
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 00000081AFF8: CC1A4008 1C228731
	v_add_co_ci_u32_e64 v29, null, 0, v29, vcc_lo              // 00000081B000: D5207C1D 01AA3A80
	v_fmac_f32_e32 v35, v52, v8                                // 00000081B008: 56461134
	s_clause 0x3                                               // 00000081B00C: BF850003
	global_load_b128 v[8:11], v[46:47], off                    // 00000081B010: DC5E0000 087C002E
	global_load_b128 v[19:22], v[46:47], off offset:16         // 00000081B018: DC5E0010 137C002E
	global_load_b128 v[42:45], v[46:47], off offset:32         // 00000081B020: DC5E0020 2A7C002E
	global_load_b128 v[46:49], v[46:47], off offset:48         // 00000081B028: DC5E0030 2E7C002E
	s_waitcnt vmcnt(3)                                         // 00000081B030: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000081B034: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081B03C: BF870091
	v_dot2_f32_bf16 v8, v9, v53, v8                            // 00000081B040: CC1A4008 1C226B09
	v_dot2_f32_bf16 v8, v10, v54, v8                           // 00000081B048: CC1A4008 1C226D0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000081B050: BF8700A1
	v_dot2_f32_bf16 v8, v11, v55, v8                           // 00000081B054: CC1A4008 1C226F0B
	s_waitcnt vmcnt(2)                                         // 00000081B05C: BF890BF7
	v_dot2_f32_bf16 v8, v19, v56, v8                           // 00000081B060: CC1A4008 1C227113
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081B068: BF870091
	v_dot2_f32_bf16 v8, v20, v57, v8                           // 00000081B06C: CC1A4008 1C227314
	v_dot2_f32_bf16 v8, v21, v58, v8                           // 00000081B074: CC1A4008 1C227515
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000081B07C: BF8700A1
	v_dot2_f32_bf16 v8, v22, v59, v8                           // 00000081B080: CC1A4008 1C227716
	s_waitcnt vmcnt(1)                                         // 00000081B088: BF8907F7
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 00000081B08C: CC1A4008 1C22792A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081B094: BF870091
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 00000081B098: CC1A4008 1C227B2B
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 00000081B0A0: CC1A4008 1C227D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000081B0A8: BF8700A1
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 00000081B0AC: CC1A4008 1C227F2D
	s_waitcnt vmcnt(0)                                         // 00000081B0B4: BF8903F7
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 00000081B0B8: CC1A4008 1C22812E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081B0C0: BF870091
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 00000081B0C4: CC1A4008 1C22832F
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 00000081B0CC: CC1A4008 1C228530
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081B0D4: BF870091
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 00000081B0D8: CC1A4008 1C228731
	v_fmac_f32_e32 v34, v52, v8                                // 00000081B0E0: 56441134
	s_clause 0x3                                               // 00000081B0E4: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 00000081B0E8: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 00000081B0F0: DC5E0010 137C000C
	global_load_b128 v[42:45], v[12:13], off offset:32         // 00000081B0F8: DC5E0020 2A7C000C
	global_load_b128 v[46:49], v[12:13], off offset:48         // 00000081B100: DC5E0030 2E7C000C
	s_waitcnt vmcnt(3)                                         // 00000081B108: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000081B10C: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081B114: BF870091
	v_dot2_f32_bf16 v8, v9, v53, v8                            // 00000081B118: CC1A4008 1C226B09
	v_dot2_f32_bf16 v8, v10, v54, v8                           // 00000081B120: CC1A4008 1C226D0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000081B128: BF8700A1
	v_dot2_f32_bf16 v8, v11, v55, v8                           // 00000081B12C: CC1A4008 1C226F0B
	s_waitcnt vmcnt(2)                                         // 00000081B134: BF890BF7
	v_dot2_f32_bf16 v8, v19, v56, v8                           // 00000081B138: CC1A4008 1C227113
	v_mov_b32_e32 v19, v15                                     // 00000081B140: 7E26030F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000081B144: BF870122
	v_dot2_f32_bf16 v8, v20, v57, v8                           // 00000081B148: CC1A4008 1C227314
	v_mov_b32_e32 v20, v16                                     // 00000081B150: 7E280310
	v_dot2_f32_bf16 v8, v21, v58, v8                           // 00000081B154: CC1A4008 1C227515
	v_mov_b32_e32 v21, v17                                     // 00000081B15C: 7E2A0311
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000081B160: BF870132
	v_dot2_f32_bf16 v8, v22, v59, v8                           // 00000081B164: CC1A4008 1C227716
	v_mov_b32_e32 v22, v18                                     // 00000081B16C: 7E2C0312
	s_waitcnt vmcnt(1)                                         // 00000081B170: BF8907F7
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 00000081B174: CC1A4008 1C22792A
	v_mov_b32_e32 v42, v41                                     // 00000081B17C: 7E540329
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081B180: BF870092
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 00000081B184: CC1A4008 1C227B2B
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 00000081B18C: CC1A4008 1C227D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000081B194: BF8700A1
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 00000081B198: CC1A4008 1C227F2D
	s_waitcnt vmcnt(0)                                         // 00000081B1A0: BF8903F7
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 00000081B1A4: CC1A4008 1C22812E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081B1AC: BF870091
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 00000081B1B0: CC1A4008 1C22832F
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 00000081B1B8: CC1A4008 1C228530
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081B1C0: BF870091
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 00000081B1C4: CC1A4008 1C228731
	v_fmac_f32_e32 v32, v52, v8                                // 00000081B1CC: 56401134
	v_mov_b32_e32 v14, v7                                      // 00000081B1D0: 7E1C0307
	v_dual_mov_b32 v13, v6 :: v_dual_mov_b32 v12, v5           // 00000081B1D4: CA100106 0D0C0105
	v_dual_mov_b32 v11, v4 :: v_dual_mov_b32 v10, v3           // 00000081B1DC: CA100104 0B0A0103
	v_dual_mov_b32 v9, v2 :: v_dual_mov_b32 v8, v1             // 00000081B1E4: CA100102 09080101
	v_mov_b32_e32 v7, v0                                       // 00000081B1EC: 7E0E0300
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 00000081B1F0: 917E107E
	s_cbranch_execz 28                                         // 00000081B1F4: BFA5001C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0xd68>
	s_waitcnt vmcnt(0)                                         // 00000081B1F8: BF8903F7
	v_dual_mov_b32 v15, v19 :: v_dual_add_nc_u32 v40, 32, v40  // 00000081B1FC: CA200113 0F2850A0
	v_dual_mov_b32 v16, v20 :: v_dual_mov_b32 v17, v21         // 00000081B204: CA100114 10100115
	v_mov_b32_e32 v18, v22                                     // 00000081B20C: 7E240316
	s_delay_alu instid0(VALU_DEP_3)                            // 00000081B210: BF870003
	.long 0xd4430002                                           // 00000081B214: D4430002
	v_cndmask_b32_e32 v1, s20, v40, vcc_lo                     // 00000081B218: 02025014
	s_mov_b32 s10, exec_lo                                     // 00000081B21C: BE8A007E
	.long 0xd4c4007e                                           // 00000081B220: D4C4007E
	v_cndmask_b32_e32 v1, s20, v40, vcc_lo                     // 00000081B224: 02025014
	s_cbranch_execz 65029                                      // 00000081B228: BFA5FE05 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x540>
	.long 0xd7006a00                                           // 00000081B22C: D7006A00
	v_cndmask_b32_e32 v1, v25, v39, vcc_lo                     // 00000081B230: 02024F19
	s_delay_alu instid0(VALU_DEP_1)                            // 00000081B234: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v33, vcc_lo               // 00000081B238: D5207C01 01AA4280
	v_cmp_ne_u32_e32 vcc_lo, 1, v31                            // 00000081B240: 7C9A3E81
	v_mov_b32_e32 v41, v42                                     // 00000081B244: 7E52032A
	global_load_b128 v[15:18], v[0:1], off                     // 00000081B248: DC5E0000 0F7C0000
	s_cbranch_vccnz 65019                                      // 00000081B250: BFA4FDFB <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x540>
	global_load_d16_b16 v0, v[28:29], off                      // 00000081B254: DC820000 007C001C
	s_waitcnt vmcnt(0)                                         // 00000081B25C: BF8903F7
	v_cvt_f32_f16_e32 v41, v0                                  // 00000081B260: 7E521700
	s_branch 65014                                             // 00000081B264: BFA0FDF6 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x540>
	s_or_b32 exec_lo, exec_lo, s16                             // 00000081B268: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000081B26C: BF8700A9
	s_or_b32 exec_lo, exec_lo, s3                              // 00000081B270: 8C7E037E
	.long 0xd71f0000                                           // 00000081B274: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000081B278: 020100C1
	v_xor_b32_e32 v1, 16, v0                                   // 00000081B27C: 3A020090
	v_xor_b32_e32 v7, 8, v0                                    // 00000081B280: 3A0E0088
	v_xor_b32_e32 v13, 4, v0                                   // 00000081B284: 3A1A0084
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000081B288: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v1                            // 00000081B28C: 7C9802A0
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 00000081B290: 02020300
	v_cmp_gt_u32_e32 vcc_lo, 32, v7                            // 00000081B294: 7C980EA0
	s_delay_alu instid0(VALU_DEP_2)                            // 00000081B298: BF870002
	v_lshlrev_b32_e32 v1, 2, v1                                // 00000081B29C: 30020282
	ds_bpermute_b32 v4, v1, v36                                // 00000081B2A0: DACC0000 04002401
	s_waitcnt lgkmcnt(0)                                       // 00000081B2A8: BF89FC07
	v_add_f32_e32 v4, v36, v4                                  // 00000081B2AC: 06080924
	ds_bpermute_b32 v2, v1, v38                                // 00000081B2B0: DACC0000 02002601
	ds_bpermute_b32 v6, v1, v34                                // 00000081B2B8: DACC0000 06002201
	v_cndmask_b32_e32 v7, v0, v7, vcc_lo                       // 00000081B2C0: 020E0F00
	ds_bpermute_b32 v3, v1, v37                                // 00000081B2C4: DACC0000 03002501
	ds_bpermute_b32 v5, v1, v35                                // 00000081B2CC: DACC0000 05002301
	ds_bpermute_b32 v1, v1, v32                                // 00000081B2D4: DACC0000 01002001
	v_cmp_gt_u32_e32 vcc_lo, 32, v13                           // 00000081B2DC: 7C981AA0
	s_waitcnt lgkmcnt(4)                                       // 00000081B2E0: BF89FC47
	v_add_f32_e32 v2, v38, v2                                  // 00000081B2E4: 06040526
	s_waitcnt lgkmcnt(3)                                       // 00000081B2E8: BF89FC37
	v_dual_add_f32 v6, v34, v6 :: v_dual_lshlrev_b32 v7, 2, v7 // 00000081B2EC: C9220D22 06060E82
	ds_bpermute_b32 v8, v7, v2                                 // 00000081B2F4: DACC0000 08000207
	s_waitcnt lgkmcnt(0)                                       // 00000081B2FC: BF89FC07
	v_add_f32_e32 v2, v2, v8                                   // 00000081B300: 06041102
	ds_bpermute_b32 v10, v7, v4                                // 00000081B304: DACC0000 0A000407
	ds_bpermute_b32 v12, v7, v6                                // 00000081B30C: DACC0000 0C000607
	v_add_f32_e32 v3, v37, v3                                  // 00000081B314: 06060725
	v_add_f32_e32 v5, v35, v5                                  // 00000081B318: 060A0B23
	v_add_f32_e32 v1, v32, v1                                  // 00000081B31C: 06020320
	s_waitcnt lgkmcnt(1)                                       // 00000081B320: BF89FC17
	v_add_f32_e32 v4, v4, v10                                  // 00000081B324: 06081504
	ds_bpermute_b32 v9, v7, v3                                 // 00000081B328: DACC0000 09000307
	s_waitcnt lgkmcnt(1)                                       // 00000081B330: BF89FC17
	v_dual_add_f32 v6, v6, v12 :: v_dual_cndmask_b32 v13, v0, v13// 00000081B334: C9121906 060C1B00
	ds_bpermute_b32 v11, v7, v5                                // 00000081B33C: DACC0000 0B000507
	ds_bpermute_b32 v7, v7, v1                                 // 00000081B344: DACC0000 07000107
	v_lshlrev_b32_e32 v13, 2, v13                              // 00000081B34C: 301A1A82
	s_waitcnt lgkmcnt(2)                                       // 00000081B350: BF89FC27
	v_add_f32_e32 v3, v3, v9                                   // 00000081B354: 06061303
	ds_bpermute_b32 v9, v13, v4                                // 00000081B358: DACC0000 0900040D
	s_waitcnt lgkmcnt(2)                                       // 00000081B360: BF89FC27
	v_add_f32_e32 v5, v5, v11                                  // 00000081B364: 060A1705
	s_waitcnt lgkmcnt(1)                                       // 00000081B368: BF89FC17
	v_add_f32_e32 v1, v1, v7                                   // 00000081B36C: 06020F01
	ds_bpermute_b32 v7, v13, v2                                // 00000081B370: DACC0000 0700020D
	ds_bpermute_b32 v8, v13, v3                                // 00000081B378: DACC0000 0800030D
	ds_bpermute_b32 v11, v13, v6                               // 00000081B380: DACC0000 0B00060D
	ds_bpermute_b32 v12, v13, v1                               // 00000081B388: DACC0000 0C00010D
	s_waitcnt lgkmcnt(4)                                       // 00000081B390: BF89FC47
	v_add_f32_e32 v4, v4, v9                                   // 00000081B394: 06081304
	ds_bpermute_b32 v10, v13, v5                               // 00000081B398: DACC0000 0A00050D
	v_xor_b32_e32 v13, 2, v0                                   // 00000081B3A0: 3A1A0082
	s_waitcnt lgkmcnt(4)                                       // 00000081B3A4: BF89FC47
	v_add_f32_e32 v2, v2, v7                                   // 00000081B3A8: 06040F02
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 00000081B3AC: BF870152
	v_cmp_gt_u32_e32 vcc_lo, 32, v13                           // 00000081B3B0: 7C981AA0
	s_waitcnt lgkmcnt(0)                                       // 00000081B3B4: BF89FC07
	v_add_f32_e32 v7, v5, v10                                  // 00000081B3B8: 060E1505
	v_cndmask_b32_e32 v13, v0, v13, vcc_lo                     // 00000081B3BC: 021A1B00
	v_xor_b32_e32 v5, 1, v0                                    // 00000081B3C0: 3A0A0081
	v_lshlrev_b32_e32 v13, 2, v13                              // 00000081B3C4: 301A1A82
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000081B3C8: BF870142
	v_cmp_gt_u32_e32 vcc_lo, 32, v5                            // 00000081B3CC: 7C980AA0
	ds_bpermute_b32 v10, v13, v4                               // 00000081B3D0: DACC0000 0A00040D
	v_dual_cndmask_b32 v0, v0, v5 :: v_dual_add_f32 v9, v1, v12// 00000081B3D8: CA480B00 00081901
	v_cmp_eq_u32_e32 vcc_lo, 0, v30                            // 00000081B3E0: 7C943C80
	v_lshlrev_b32_e32 v14, 2, v0                               // 00000081B3E4: 301C0082
	v_dual_add_f32 v3, v3, v8 :: v_dual_add_f32 v8, v6, v11    // 00000081B3E8: C9081103 03081706
	s_and_b32 s0, vcc_lo, s0                                   // 00000081B3F0: 8B00006A
	s_waitcnt lgkmcnt(0)                                       // 00000081B3F4: BF89FC07
	v_add_f32_e32 v4, v4, v10                                  // 00000081B3F8: 06081504
	ds_bpermute_b32 v1, v13, v2                                // 00000081B3FC: DACC0000 0100020D
	ds_bpermute_b32 v6, v13, v3                                // 00000081B404: DACC0000 0600030D
	ds_bpermute_b32 v11, v13, v7                               // 00000081B40C: DACC0000 0B00070D
	ds_bpermute_b32 v12, v13, v8                               // 00000081B414: DACC0000 0C00080D
	ds_bpermute_b32 v13, v13, v9                               // 00000081B41C: DACC0000 0D00090D
	s_waitcnt lgkmcnt(3)                                       // 00000081B424: BF89FC37
	v_dual_add_f32 v5, v2, v1 :: v_dual_add_f32 v6, v3, v6     // 00000081B428: C9080302 05060D03
	s_waitcnt lgkmcnt(1)                                       // 00000081B430: BF89FC17
	v_dual_add_f32 v0, v7, v11 :: v_dual_add_f32 v1, v8, v12   // 00000081B434: C9081707 00001908
	s_waitcnt lgkmcnt(0)                                       // 00000081B43C: BF89FC07
	v_add_f32_e32 v7, v9, v13                                  // 00000081B440: 060E1B09
	ds_bpermute_b32 v9, v14, v5                                // 00000081B444: DACC0000 0900050E
	ds_bpermute_b32 v10, v14, v6                               // 00000081B44C: DACC0000 0A00060E
	ds_bpermute_b32 v8, v14, v4                                // 00000081B454: DACC0000 0800040E
	ds_bpermute_b32 v2, v14, v0                                // 00000081B45C: DACC0000 0200000E
	ds_bpermute_b32 v3, v14, v1                                // 00000081B464: DACC0000 0300010E
	ds_bpermute_b32 v11, v14, v7                               // 00000081B46C: DACC0000 0B00070E
	s_and_saveexec_b32 s1, s0                                  // 00000081B474: BE812000
	s_cbranch_execz 287                                        // 00000081B478: BFA5011F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x13f8>
	s_waitcnt lgkmcnt(4)                                       // 00000081B47C: BF89FC47
	v_dual_add_f32 v5, v5, v9 :: v_dual_add_f32 v6, v6, v10    // 00000081B480: C9081305 05061506
	s_waitcnt lgkmcnt(0)                                       // 00000081B488: BF89FC07
	v_dual_add_f32 v7, v7, v11 :: v_dual_add_f32 v4, v4, v8    // 00000081B48C: C9081707 07041104
	v_dual_add_f32 v2, v0, v2 :: v_dual_add_f32 v3, v1, v3     // 00000081B494: C9080500 02020701
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000081B49C: BF870193
	v_bfe_u32 v9, v6, 16, 1                                    // 00000081B4A0: D6100009 02052106
	v_bfe_u32 v13, v7, 16, 1                                   // 00000081B4A8: D610000D 02052107
	v_bfe_u32 v8, v5, 16, 1                                    // 00000081B4B0: D6100008 02052105
	s_delay_alu instid0(VALU_DEP_4)                            // 00000081B4B8: BF870004
	v_bfe_u32 v11, v2, 16, 1                                   // 00000081B4BC: D610000B 02052102
	v_bfe_u32 v12, v3, 16, 1                                   // 00000081B4C4: D610000C 02052103
	v_add3_u32 v6, v6, v9, 0x7fff                              // 00000081B4CC: D6550006 03FE1306 00007FFF
	v_add3_u32 v7, v7, v13, 0x7fff                             // 00000081B4D8: D6550007 03FE1B07 00007FFF
	v_add3_u32 v5, v5, v8, 0x7fff                              // 00000081B4E4: D6550005 03FE1105 00007FFF
	v_add3_u32 v2, v2, v11, 0x7fff                             // 00000081B4F0: D6550002 03FE1702 00007FFF
	v_bfe_u32 v9, v4, 16, 1                                    // 00000081B4FC: D6100009 02052104
	v_and_b32_e32 v6, 0xffff0000, v6                           // 00000081B504: 360C0CFF FFFF0000
	v_and_b32_e32 v7, 0xffff0000, v7                           // 00000081B50C: 360E0EFF FFFF0000
	.long 0xd73c0000                                           // 00000081B514: D73C0000
	v_cndmask_b32_e32 v1, 1, v23, vcc_lo                       // 00000081B518: 02022E81
	v_and_b32_e32 v2, 0xffff0000, v2                           // 00000081B51C: 360404FF FFFF0000
	v_add3_u32 v4, v4, v9, 0x7fff                              // 00000081B524: D6550004 03FE1304 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000081B530: BF8701B4
	v_dual_mul_f32 v6, 0xbfb8aa3b, v6 :: v_dual_mul_f32 v7, 0xbfb8aa3b, v7// 00000081B534: C8C60CFF 06060EFF BFB8AA3B
	v_add3_u32 v3, v3, v12, 0x7fff                             // 00000081B540: D6550003 03FE1903 00007FFF
	.long 0xd7006a00                                           // 00000081B54C: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 00000081B550: 02020008
	v_exp_f32_e32 v6, v6                                       // 00000081B554: 7E0C4B06
	v_and_b32_e32 v5, 0xffff0000, v5                           // 00000081B558: 360A0AFF FFFF0000
	v_and_b32_e32 v4, 0xffff0000, v4                           // 00000081B560: 360808FF FFFF0000
	s_lshl_b64 s[0:1], s[12:13], 1                             // 00000081B568: 8480810C
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 00000081B56C: D5207C01 01AA0209
	v_exp_f32_e32 v7, v7                                       // 00000081B574: 7E0E4B07
	.long 0x7f143880                                           // 00000081B578: 7F143880
	v_mul_f32_e32 v2, 0xbfb8aa3b, v2                           // 00000081B57C: 100404FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000081B584: BF870196
	v_dual_add_f32 v6, 1.0, v6 :: v_dual_mul_f32 v5, 0xbfb8aa3b, v5// 00000081B588: C9060CF2 06040AFF BFB8AA3B
	.long 0x7f10398a                                           // 00000081B594: 7F10398A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000081B598: BF8701A3
	v_exp_f32_e32 v2, v2                                       // 00000081B59C: 7E044B02
	v_and_b32_e32 v3, 0xffff0000, v3                           // 00000081B5A0: 360606FF FFFF0000
	v_div_scale_f32 v11, null, v6, v6, 1.0                     // 00000081B5A8: D6FC7C0B 03CA0D06
	v_exp_f32_e32 v5, v5                                       // 00000081B5B0: 7E0A4B05
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000081B5B4: BF870117
	v_add_f32_e32 v7, 1.0, v7                                  // 00000081B5B8: 060E0EF2
	v_rcp_f32_e32 v14, v11                                     // 00000081B5BC: 7E1C550B
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000081B5C0: BF870296
	v_dual_add_f32 v2, 1.0, v2 :: v_dual_add_f32 v5, 1.0, v5   // 00000081B5C4: C90804F2 02040AF2
	v_fma_f32 v17, -v11, v14, 1.0                              // 00000081B5CC: D6130011 23CA1D0B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000081B5D4: BF870112
	v_div_scale_f32 v9, null, v5, v5, 1.0                      // 00000081B5D8: D6FC7C09 03CA0B05
	v_fmac_f32_e32 v14, v17, v14                               // 00000081B5E0: 561C1D11
	s_delay_alu instid0(VALU_DEP_2)                            // 00000081B5E4: BF870002
	v_rcp_f32_e32 v13, v9                                      // 00000081B5E8: 7E1A5509
	v_mul_f32_e32 v12, 0xbfb8aa3b, v3                          // 00000081B5EC: 101806FF BFB8AA3B
	.long 0xd7006a03                                           // 00000081B5F4: D7006A03
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 00000081B5F8: 02000100
	s_waitcnt vmcnt(0)                                         // 00000081B5FC: BF8903F7
	v_div_scale_f32 v19, s0, 1.0, v6, 1.0                      // 00000081B600: D6FC0013 03CA0CF2
	v_mul_f32_e32 v4, 0xbfb8aa3b, v4                           // 00000081B608: 100808FF BFB8AA3B
	v_div_scale_f32 v17, null, v2, v2, 1.0                     // 00000081B610: D6FC7C11 03CA0502
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000081B618: BF870193
	v_mul_f32_e32 v21, v19, v14                                // 00000081B61C: 102A1D13
	v_exp_f32_e32 v15, v4                                      // 00000081B620: 7E1E4B04
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000081B624: BF8701C6
	v_fma_f32 v16, -v9, v13, 1.0                               // 00000081B628: D6130010 23CA1B09
	v_add_co_ci_u32_e64 v4, null, s1, v1, vcc_lo               // 00000081B630: D5207C04 01AA0201
	v_div_scale_f32 v18, vcc_lo, 1.0, v5, 1.0                  // 00000081B638: D6FC6A12 03CA0AF2
	v_rcp_f32_e32 v23, v17                                     // 00000081B640: 7E2E5511
	v_fmac_f32_e32 v13, v16, v13                               // 00000081B644: 561A1B10
	v_fma_f32 v25, -v11, v21, v19                              // 00000081B648: D6130019 244E2B0B
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_2)   // 00000081B650: BF870106
	v_dual_add_f32 v15, 1.0, v15 :: v_dual_mul_f32 v20, v18, v13// 00000081B654: C9061EF2 0F141B12
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000081B65C: BF870122
	v_fmac_f32_e32 v21, v25, v14                               // 00000081B660: 562A1D19
	v_exp_f32_e32 v12, v12                                     // 00000081B664: 7E184B0C
	v_div_scale_f32 v16, null, v15, v15, 1.0                   // 00000081B668: D6FC7C10 03CA1F0F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 00000081B670: BF870313
	v_fma_f32 v24, -v9, v20, v18                               // 00000081B674: D6130018 244A2909
	v_fma_f32 v28, -v17, v23, 1.0                              // 00000081B67C: D613001C 23CA2F11
	v_fma_f32 v11, -v11, v21, v19                              // 00000081B684: D613000B 244E2B0B
	v_div_scale_f32 v26, s1, 1.0, v15, 1.0                     // 00000081B68C: D6FC011A 03CA1EF2
	v_rcp_f32_e32 v22, v16                                     // 00000081B694: 7E2C5510
	v_fmac_f32_e32 v20, v24, v13                               // 00000081B698: 56281B18
	v_div_scale_f32 v24, null, v7, v7, 1.0                     // 00000081B69C: D6FC7C18 03CA0F07
	v_fmac_f32_e32 v23, v28, v23                               // 00000081B6A4: 562E2F1C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000081B6A8: BF870193
	v_fma_f32 v9, -v9, v20, v18                                // 00000081B6AC: D6130009 244A2909
	v_rcp_f32_e32 v29, v24                                     // 00000081B6B4: 7E3A5518
	v_div_scale_f32 v18, s2, 1.0, v2, 1.0                      // 00000081B6B8: D6FC0212 03CA04F2
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000081B6C0: BF870196
	v_fma_f32 v25, -v16, v22, 1.0                              // 00000081B6C4: D6130019 23CA2D10
	v_div_fmas_f32 v9, v9, v13, v20                            // 00000081B6CC: D6370009 04521B09
	s_mov_b32 vcc_lo, s0                                       // 00000081B6D4: BEEA0000
	v_div_scale_f32 v20, s4, 1.0, v7, 1.0                      // 00000081B6D8: D6FC0414 03CA0EF2
	v_div_fmas_f32 v11, v11, v14, v21                          // 00000081B6E0: D637000B 04561D0B
	v_fmac_f32_e32 v22, v25, v22                               // 00000081B6E8: 562C2D19
	v_add_f32_e32 v12, 1.0, v12                                // 00000081B6EC: 061818F2
	v_div_fixup_f32 v5, v9, v5, 1.0                            // 00000081B6F0: D6270005 03CA0B09
	v_fma_f32 v14, -v24, v29, 1.0                              // 00000081B6F8: D613000E 23CA3B18
	v_div_fixup_f32 v6, v11, v6, 1.0                           // 00000081B700: D6270006 03CA0D0B
	v_mul_f32_e32 v11, v26, v22                                // 00000081B708: 10162D1A
	v_div_scale_f32 v27, null, v12, v12, 1.0                   // 00000081B70C: D6FC7C1B 03CA190C
	.long 0x7e103985                                           // 00000081B714: 7E103985
	v_mul_f32_e32 v21, v18, v23                                // 00000081B718: 102A2F12
	.long 0x7e143986                                           // 00000081B71C: 7E143986
	v_fmac_f32_e32 v29, v14, v29                               // 00000081B720: 563A3B0E
	v_rcp_f32_e32 v19, v27                                     // 00000081B724: 7E26551B
	v_and_b32_e32 v8, 1, v8                                    // 00000081B728: 36101081
	v_div_scale_f32 v13, s3, 1.0, v12, 1.0                     // 00000081B72C: D6FC030D 03CA18F2
	v_and_b32_e32 v14, 1, v10                                  // 00000081B734: 361C1481
	s_mov_b32 vcc_lo, s1                                       // 00000081B738: BEEA0001
	s_lshl_b64 s[0:1], s[12:13], 2                             // 00000081B73C: 8480820C
	v_add3_u32 v5, v5, v8, 0x7fff                              // 00000081B740: D6550005 03FE1105 00007FFF
	v_fma_f32 v8, -v17, v21, v18                               // 00000081B74C: D6130008 244A2B11
	v_add3_u32 v14, v6, v14, 0x7fff                            // 00000081B754: D655000E 03FE1D06 00007FFF
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000081B760: BF8700D5
	v_fma_f32 v9, -v27, v19, 1.0                               // 00000081B764: D6130009 23CA271B
	global_store_d16_hi_b16 v[0:1], v5, off                    // 00000081B76C: DC960000 007C0500
	v_fmac_f32_e32 v21, v8, v23                                // 00000081B774: 562A2F08
	v_dual_mul_f32 v8, v20, v29 :: v_dual_fmac_f32 v19, v9, v19// 00000081B778: C8C03B14 08122709
	v_fma_f32 v9, -v16, v11, v26                               // 00000081B780: D6130009 246A1710
	v_fmac_f32_e32 v11, v9, v22                                // 00000081B788: 56162D09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000081B78C: BF870211
	v_fma_f32 v5, -v16, v11, v26                               // 00000081B790: D6130005 246A1710
	v_fma_f32 v16, -v24, v8, v20                               // 00000081B798: D6130010 24521118
	v_mul_f32_e32 v9, v13, v19                                 // 00000081B7A0: 1012270D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000081B7A4: BF870193
	v_div_fmas_f32 v5, v5, v22, v11                            // 00000081B7A8: D6370005 042E2D05
	v_fmac_f32_e32 v8, v16, v29                                // 00000081B7B0: 56103B10
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000081B7B4: BF870133
	v_fma_f32 v6, -v27, v9, v13                                // 00000081B7B8: D6130006 2436131B
	v_fma_f32 v11, -v17, v21, v18                              // 00000081B7C0: D613000B 244A2B11
	s_mov_b32 vcc_lo, s2                                       // 00000081B7C8: BEEA0002
	v_fmac_f32_e32 v9, v6, v19                                 // 00000081B7CC: 56122706
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000081B7D0: BF8701B2
	v_div_fmas_f32 v6, v11, v23, v21                           // 00000081B7D4: D6370006 04562F0B
	v_div_fixup_f32 v11, v5, v15, 1.0                          // 00000081B7DC: D627000B 03CA1F05
	s_mov_b32 vcc_lo, s3                                       // 00000081B7E4: BEEA0003
	v_fma_f32 v5, -v27, v9, v13                                // 00000081B7E8: D6130005 2436131B
	s_delay_alu instid0(VALU_DEP_3)                            // 00000081B7F0: BF870003
	v_div_fixup_f32 v2, v6, v2, 1.0                            // 00000081B7F4: D6270002 03CA0506
	v_fma_f32 v6, -v24, v8, v20                                // 00000081B7FC: D6130006 24521118
	.long 0x7e1a398b                                           // 00000081B804: 7E1A398B
	.long 0x7f1a398a                                           // 00000081B808: 7F1A398A
	v_div_fmas_f32 v9, v5, v19, v9                             // 00000081B80C: D6370009 04262705
	s_mov_b32 vcc_lo, s4                                       // 00000081B814: BEEA0004
	.long 0x7e143982                                           // 00000081B818: 7E143982
	v_div_fmas_f32 v8, v6, v29, v8                             // 00000081B81C: D6370008 04223B06
	.long 0xd7006a05                                           // 00000081B824: D7006A05
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 00000081B828: 02000100
	v_div_fixup_f32 v9, v9, v12, 1.0                           // 00000081B82C: D6270009 03CA1909
	v_add_co_ci_u32_e64 v6, null, s1, v1, vcc_lo               // 00000081B834: D5207C06 01AA0201
	s_delay_alu instid0(VALU_DEP_4)                            // 00000081B83C: BF870004
	v_div_fixup_f32 v15, v8, v7, 1.0                           // 00000081B840: D627000F 03CA0F08
	v_mad_u64_u32 v[0:1], null, s12, 6, v[0:1]                 // 00000081B848: D6FE7C00 04010C0C
	v_and_b32_e32 v7, 1, v10                                   // 00000081B850: 360E1481
	.long 0x7e183989                                           // 00000081B854: 7E183989
	.long 0x7f18398a                                           // 00000081B858: 7F18398A
	.long 0x7e14398f                                           // 00000081B85C: 7E14398F
	v_and_b32_e32 v8, 1, v13                                   // 00000081B860: 36101A81
	v_add3_u32 v13, v2, v7, 0x7fff                             // 00000081B864: D655000D 03FE0F02 00007FFF
	.long 0xd7006a07                                           // 00000081B870: D7006A07
	v_cndmask_b32_e32 v0, v5, v0, vcc_lo                       // 00000081B874: 02000105
	v_mad_u64_u32 v[1:2], null, s13, 6, v[1:2]                 // 00000081B878: D6FE7C01 04050C0D
	v_and_b32_e32 v2, 1, v10                                   // 00000081B880: 36041481
	v_and_b32_e32 v10, 1, v12                                  // 00000081B884: 36141881
	v_add3_u32 v11, v11, v8, 0x7fff                            // 00000081B888: D655000B 03FE110B 00007FFF
	v_add_co_ci_u32_e64 v8, null, s1, v6, vcc_lo               // 00000081B894: D5207C08 01AA0C01
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000081B89C: BF870214
	v_add3_u32 v2, v15, v2, 0x7fff                             // 00000081B8A0: D6550002 03FE050F 00007FFF
	v_add3_u32 v12, v9, v10, 0x7fff                            // 00000081B8AC: D655000C 03FE1509 00007FFF
	.long 0xd7006a09                                           // 00000081B8B8: D7006A09
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 00000081B8BC: 02000100
	s_delay_alu instid0(VALU_DEP_1)                            // 00000081B8C0: BF870001
	v_add_co_ci_u32_e64 v10, null, s1, v1, vcc_lo              // 00000081B8C4: D5207C0A 01AA0201
	s_clause 0x4                                               // 00000081B8CC: BF850004
	global_store_d16_hi_b16 v[3:4], v14, off                   // 00000081B8D0: DC960000 007C0E03
	global_store_d16_hi_b16 v[5:6], v11, off                   // 00000081B8D8: DC960000 007C0B05
	global_store_d16_hi_b16 v[0:1], v13, off                   // 00000081B8E0: DC960000 007C0D00
	global_store_d16_hi_b16 v[7:8], v12, off                   // 00000081B8E8: DC960000 007C0C07
	global_store_d16_hi_b16 v[9:10], v2, off                   // 00000081B8F0: DC960000 007C0209
	s_endpgm                                                   // 00000081B8F8: BFB00000
	v_illegal                                                  // 00000081B8FC: 00000000

