000000000055ff00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 00000055FF00: F4100100 F8000000
	v_dual_mov_b32 v28, 0 :: v_dual_and_b32 v1, 15, v0         // 00000055FF08: CA240080 1C00008F
	v_lshrrev_b32_e32 v2, 2, v0                                // 00000055FF10: 32040082
	s_ashr_i32 s3, s2, 31                                      // 00000055FF14: 86039F02
	v_mov_b32_e32 v5, 0                                        // 00000055FF18: 7E0A0280
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000055FF1C: BF870193
	v_dual_mov_b32 v6, 0 :: v_dual_lshlrev_b32 v1, 2, v1       // 00000055FF20: CA220080 06000282
	v_and_b32_e32 v2, 60, v2                                   // 00000055FF28: 360404BC
	v_lshrrev_b32_e32 v15, 5, v0                               // 00000055FF2C: 321E0085
	.long 0x7f263880                                           // 00000055FF30: 7F263880
	v_dual_mov_b32 v17, 0 :: v_dual_mov_b32 v8, 0              // 00000055FF34: CA100080 11080080
	v_dual_mov_b32 v7, 0 :: v_dual_lshlrev_b32 v14, 2, v0      // 00000055FF3C: CA220080 070E0082
	s_waitcnt lgkmcnt(0)                                       // 00000055FF44: BF89FC07
	s_clause 0x1                                               // 00000055FF48: BF850001
	global_load_b32 v11, v1, s[4:5]                            // 00000055FF4C: DC520000 0B040001
	global_load_b32 v13, v2, s[4:5]                            // 00000055FF54: DC520000 0D040002
	.long 0xd4510000                                           // 00000055FF5C: D4510000
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 00000055FF60: 02001802
	s_and_b32 s0, s0, exec_lo                                  // 00000055FF64: 8B007E00
	s_cselect_b32 s22, s3, 0                                   // 00000055FF68: 98168003
	s_cselect_b32 s23, s2, 0                                   // 00000055FF6C: 98178002
	s_add_u32 s0, s4, s14                                      // 00000055FF70: 80000E04
	s_addc_u32 s1, s5, s15                                     // 00000055FF74: 82010F05
	s_lshr_b32 s14, s11, 31                                    // 00000055FF78: 850E9F0B
	v_mov_b32_e32 v2, s1                                       // 00000055FF7C: 7E040201
	s_add_u32 s14, s10, s14                                    // 00000055FF80: 800E0E0A
	s_addc_u32 s15, s11, 0                                     // 00000055FF84: 820F800B
	s_ashr_i32 s20, s11, 31                                    // 00000055FF88: 86149F0B
	s_ashr_i64 s[14:15], s[14:15], 1                           // 00000055FF8C: 868E810E
	s_lshr_b32 s20, s20, 27                                    // 00000055FF90: 85149B14
	v_dual_mov_b32 v1, s0 :: v_dual_and_b32 v16, 31, v0        // 00000055FF94: CA240000 0110009F
	s_add_u32 s20, s10, s20                                    // 00000055FF9C: 8014140A
	s_addc_u32 s21, s11, 0                                     // 00000055FFA0: 8215800B
	s_mul_i32 s19, s19, s23                                    // 00000055FFA4: 96131713
	s_lshr_b64 s[20:21], s[20:21], 5                           // 00000055FFA8: 85948514
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000055FFAC: BF870499
	s_add_i32 s21, s20, 7                                      // 00000055FFB0: 81158714
	s_ashr_i32 s24, s21, 31                                    // 00000055FFB4: 86189F15
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000055FFB8: BF870499
	s_lshr_b32 s24, s24, 29                                    // 00000055FFBC: 85189D18
	s_add_i32 s21, s21, s24                                    // 00000055FFC0: 81151815
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000055FFC4: BF870009
	s_ashr_i32 s21, s21, 3                                     // 00000055FFC8: 86158315
	s_add_u32 s0, s4, s16                                      // 00000055FFCC: 80001004
	s_addc_u32 s1, s5, s17                                     // 00000055FFD0: 82011105
	.long 0xd72c0012                                           // 00000055FFD4: D72C0012
	v_cndmask_b32_e32 v1, s21, v15, vcc_lo                     // 00000055FFD8: 02021E15
	v_dual_mov_b32 v4, s1 :: v_dual_mov_b32 v3, s0             // 00000055FFDC: CA100001 04020000
	v_mad_u64_u32 v[9:10], null, s23, s14, v[1:2]              // 00000055FFE4: D6FE7C09 04041C17
	s_mul_i32 s0, s22, s14                                     // 00000055FFEC: 96000E16
	s_waitcnt vmcnt(1)                                         // 00000055FFF0: BF8907F7
	v_bfe_u32 v12, v11, 16, 1                                  // 00000055FFF4: D610000C 0205210B
	s_waitcnt vmcnt(0)                                         // 00000055FFFC: BF8903F7
	v_bfe_u32 v1, v13, 16, 1                                   // 000000560000: D6100001 0205210D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000560008: BF870232
	v_add3_u32 v2, v11, v12, 0x7fff                            // 00000056000C: D6550002 03FE190B 00007FFF
	v_mad_u64_u32 v[11:12], null, s18, s23, v[3:4]             // 000000560018: D6FE7C0B 040C2E12
	v_add_nc_u32_e32 v3, s21, v18                              // 000000560020: 4A062415
	v_add3_u32 v1, v13, v1, 0x7fff                             // 000000560024: D6550001 03FE030D 00007FFF
	s_mul_i32 s23, s23, s15                                    // 000000560030: 96170F17
	.long 0x7e263982                                           // 000000560034: 7E263982
	v_add_nc_u32_e32 v2, s0, v10                               // 000000560038: 4A041400
	v_add_nc_u32_e32 v10, v18, v16                             // 00000056003C: 4A142112
	v_min_i32_e32 v18, s20, v3                                 // 000000560040: 22240614
	v_add_nc_u32_e32 v3, s19, v12                              // 000000560044: 4A061813
	s_mul_i32 s0, s18, s22                                     // 000000560048: 96001612
	v_and_or_b32 v1, 0xffff0000, v1, v19                       // 00000056004C: D6570001 044E02FF FFFF0000
	v_add_nc_u32_e32 v19, s23, v2                              // 000000560058: 4A260417
	v_cmp_lt_i32_e32 vcc_lo, v10, v18                          // 00000056005C: 7C82250A
	v_add_nc_u32_e32 v20, s0, v3                               // 000000560060: 4A280600
	ds_store_b32 v14, v1                                       // 000000560064: D8340000 0000010E
	s_waitcnt lgkmcnt(0)                                       // 00000056006C: BF89FC07
	s_barrier                                                  // 000000560070: BFBD0000
	buffer_gl0_inv                                             // 000000560074: E0AC0000 00000000
	s_and_saveexec_b32 s1, vcc_lo                              // 00000056007C: BE81206A
	s_cbranch_execz 21                                         // 000000560080: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x1d8>
	v_lshlrev_b32_e32 v1, 1, v10                               // 000000560084: 30021481
	v_lshlrev_b32_e32 v3, 4, v10                               // 000000560088: 30061484
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000056008C: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000560090: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000560094: 3408069F
	.long 0xd7000001                                           // 000000560098: D7000001
	v_cndmask_b32_e32 v1, v11, v1, vcc_lo                      // 00000056009C: 0202030B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005600A0: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v20, v2, s0                  // 0000005600A4: D5207C02 00020514
	.long 0xd7000003                                           // 0000005600AC: D7000003
	v_cndmask_b32_e32 v1, v9, v3, vcc_lo                       // 0000005600B0: 02020709
	v_add_co_ci_u32_e64 v4, null, v19, v4, s0                  // 0000005600B4: D5207C04 00020913
	s_clause 0x1                                               // 0000005600BC: BF850001
	global_load_d16_b16 v1, v[1:2], off                        // 0000005600C0: DC820000 017C0001
	global_load_b128 v[5:8], v[3:4], off                       // 0000005600C8: DC5E0000 057C0003
	s_waitcnt vmcnt(1)                                         // 0000005600D0: BF8907F7
	v_cvt_f32_f16_e32 v28, v1                                  // 0000005600D4: 7E381701
	s_or_b32 exec_lo, exec_lo, s1                              // 0000005600D8: 8C7E017E
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v23, 0             // 0000005600DC: CA100080 16160080
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v21, 0             // 0000005600E4: CA100080 18140080
	s_and_saveexec_b32 s1, vcc_lo                              // 0000005600EC: BE81206A
	s_cbranch_execz 460                                        // 0000005600F0: BFA501CC <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x924>
	v_dual_mov_b32 v24, 0 :: v_dual_add_nc_u32 v1, 32, v10     // 0000005600F4: CA200080 180014A0
	v_dual_mov_b32 v21, 0 :: v_dual_lshlrev_b32 v12, 5, v10    // 0000005600FC: CA220080 150C1485
	v_mov_b32_e32 v17, 0                                       // 000000560104: 7E220280
	s_delay_alu instid0(VALU_DEP_3)                            // 000000560108: BF870003
	v_dual_mov_b32 v22, 0 :: v_dual_lshlrev_b32 v25, 4, v1     // 00000056010C: CA220080 16180284
	v_dual_mov_b32 v23, 0 :: v_dual_lshlrev_b32 v26, 1, v1     // 000000560114: CA220080 171A0281
	v_mov_b32_e32 v27, v28                                     // 00000056011C: 7E36031C
	s_mul_i32 s0, s11, 6                                       // 000000560120: 9600860B
	s_mul_hi_u32 s14, s10, 6                                   // 000000560124: 968E860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 000000560128: 8484820A
	s_add_i32 s14, s14, s0                                     // 00000056012C: 810E000E
	s_mul_i32 s16, s10, 6                                      // 000000560130: 9610860A
	s_mov_b32 s15, 0                                           // 000000560134: BE8F0080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 000000560138: 848A810A
	s_branch 409                                               // 00000056013C: BFA00199 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x8a4>
	s_or_b32 exec_lo, exec_lo, s17                             // 000000560140: 8C7E117E
	v_and_b32_e32 v13, 0xff, v5                                // 000000560144: 361A0AFF 000000FF
	s_and_b32 s0, exec_lo, vcc_lo                              // 00000056014C: 8B006A7E
	v_add_nc_u32_e32 v25, 0x200, v25                           // 000000560150: 4A3232FF 00000200
	s_or_b32 s15, s0, s15                                      // 000000560158: 8C0F0F00
	v_add_nc_u32_e32 v26, 64, v26                              // 00000056015C: 4A3434C0
	v_lshlrev_b32_e32 v13, 2, v13                              // 000000560160: 301A1A82
	ds_load_b32 v45, v13                                       // 000000560164: D8D80000 2D00000D
	v_lshrrev_b32_e32 v13, 6, v5                               // 00000056016C: 321A0A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000560170: BF870141
	v_and_b32_e32 v13, 0x3fc, v13                              // 000000560174: 361A1AFF 000003FC
	ds_load_b32 v46, v13                                       // 00000056017C: D8D80000 2E00000D
	v_lshrrev_b32_e32 v13, 14, v5                              // 000000560184: 321A0A8E
	v_lshrrev_b32_e32 v5, 22, v5                               // 000000560188: 320A0A96
	v_and_b32_e32 v13, 0x3fc, v13                              // 00000056018C: 361A1AFF 000003FC
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000560194: BF870152
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000560198: 360A0AFF 000003FC
	ds_load_b32 v47, v13                                       // 0000005601A0: D8D80000 2F00000D
	ds_load_b32 v48, v5                                        // 0000005601A8: D8D80000 30000005
	v_and_b32_e32 v5, 0xff, v6                                 // 0000005601B0: 360A0CFF 000000FF
	v_ashrrev_i32_e32 v13, 31, v12                             // 0000005601B8: 341A189F
	v_lshlrev_b32_e32 v5, 2, v5                                // 0000005601BC: 300A0A82
	ds_load_b32 v49, v5                                        // 0000005601C0: D8D80000 31000005
	v_lshrrev_b32_e32 v5, 6, v6                                // 0000005601C8: 320A0C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000005601CC: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000005601D0: 360A0AFF 000003FC
	ds_load_b32 v50, v5                                        // 0000005601D8: D8D80000 32000005
	v_lshrrev_b32_e32 v5, 14, v6                               // 0000005601E0: 320A0C8E
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000005601E4: 360A0AFF 000003FC
	ds_load_b32 v51, v5                                        // 0000005601EC: D8D80000 33000005
	v_lshrrev_b32_e32 v5, 22, v6                               // 0000005601F4: 320A0C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000005601F8: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000005601FC: 360A0AFF 000003FC
	ds_load_b32 v52, v5                                        // 000000560204: D8D80000 34000005
	v_and_b32_e32 v5, 0xff, v7                                 // 00000056020C: 360A0EFF 000000FF
	v_lshlrev_b32_e32 v5, 2, v5                                // 000000560214: 300A0A82
	ds_load_b32 v53, v5                                        // 000000560218: D8D80000 35000005
	v_lshrrev_b32_e32 v5, 6, v7                                // 000000560220: 320A0E86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000560224: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000560228: 360A0AFF 000003FC
	ds_load_b32 v54, v5                                        // 000000560230: D8D80000 36000005
	v_lshrrev_b32_e32 v5, 14, v7                               // 000000560238: 320A0E8E
	v_and_b32_e32 v5, 0x3fc, v5                                // 00000056023C: 360A0AFF 000003FC
	ds_load_b32 v55, v5                                        // 000000560244: D8D80000 37000005
	v_lshrrev_b32_e32 v5, 22, v7                               // 00000056024C: 320A0E96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000560250: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000560254: 360A0AFF 000003FC
	ds_load_b32 v56, v5                                        // 00000056025C: D8D80000 38000005
	v_and_b32_e32 v5, 0xff, v8                                 // 000000560264: 360A10FF 000000FF
	v_lshlrev_b32_e32 v5, 2, v5                                // 00000056026C: 300A0A82
	ds_load_b32 v57, v5                                        // 000000560270: D8D80000 39000005
	v_lshrrev_b32_e32 v5, 6, v8                                // 000000560278: 320A1086
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000056027C: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000560280: 360A0AFF 000003FC
	ds_load_b32 v58, v5                                        // 000000560288: D8D80000 3A000005
	v_lshrrev_b32_e32 v5, 14, v8                               // 000000560290: 320A108E
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000560294: 360A0AFF 000003FC
	ds_load_b32 v59, v5                                        // 00000056029C: D8D80000 3B000005
	v_lshrrev_b32_e32 v5, 22, v8                               // 0000005602A4: 320A1096
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000005602A8: BF870141
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000005602AC: 360A0AFF 000003FC
	ds_load_b32 v60, v5                                        // 0000005602B4: D8D80000 3C000005
	.long 0xd73c0005                                           // 0000005602BC: D73C0005
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 0000005602C0: 02021881
	v_add_nc_u32_e32 v12, 0x400, v12                           // 0000005602C4: 4A1818FF 00000400
	.long 0xd7006a29                                           // 0000005602CC: D7006A29
	v_cndmask_b32_e32 v1, s6, v5, vcc_lo                       // 0000005602D0: 02020A06
	s_delay_alu instid0(VALU_DEP_1)                            // 0000005602D4: BF870001
	v_add_co_ci_u32_e64 v42, null, s7, v6, vcc_lo              // 0000005602D8: D5207C2A 01AA0C07
	s_clause 0x3                                               // 0000005602E0: BF850003
	global_load_b128 v[5:8], v[41:42], off                     // 0000005602E4: DC5E0000 057C0029
	global_load_b128 v[29:32], v[41:42], off offset:16         // 0000005602EC: DC5E0010 1D7C0029
	global_load_b128 v[33:36], v[41:42], off offset:32         // 0000005602F4: DC5E0020 217C0029
	global_load_b128 v[37:40], v[41:42], off offset:48         // 0000005602FC: DC5E0030 257C0029
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 000000560304: BF890CF7
	v_dot2_f32_bf16 v5, v5, v45, 0                             // 000000560308: CC1A4005 1A025B05
	s_waitcnt lgkmcnt(14)                                      // 000000560310: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000560314: BF8700A1
	v_dot2_f32_bf16 v5, v6, v46, v5                            // 000000560318: CC1A4005 1C165D06
	s_waitcnt lgkmcnt(13)                                      // 000000560320: BF89FCD7
	v_dot2_f32_bf16 v5, v7, v47, v5                            // 000000560324: CC1A4005 1C165F07
	s_waitcnt lgkmcnt(12)                                      // 00000056032C: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000560330: BF8700A1
	v_dot2_f32_bf16 v5, v8, v48, v5                            // 000000560334: CC1A4005 1C166108
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 00000056033C: BF8908B7
	v_dot2_f32_bf16 v5, v29, v49, v5                           // 000000560340: CC1A4005 1C16631D
	s_waitcnt lgkmcnt(10)                                      // 000000560348: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056034C: BF8700A1
	v_dot2_f32_bf16 v5, v30, v50, v5                           // 000000560350: CC1A4005 1C16651E
	s_waitcnt lgkmcnt(9)                                       // 000000560358: BF89FC97
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 00000056035C: CC1A4005 1C16671F
	s_waitcnt lgkmcnt(8)                                       // 000000560364: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000560368: BF8700A1
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 00000056036C: CC1A4005 1C166920
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 000000560374: BF890477
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 000000560378: CC1A4005 1C166B21
	s_waitcnt lgkmcnt(6)                                       // 000000560380: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000560384: BF8700A1
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 000000560388: CC1A4005 1C166D22
	s_waitcnt lgkmcnt(5)                                       // 000000560390: BF89FC57
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 000000560394: CC1A4005 1C166F23
	s_waitcnt lgkmcnt(4)                                       // 00000056039C: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005603A0: BF8700A1
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 0000005603A4: CC1A4005 1C167124
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 0000005603AC: BF890037
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 0000005603B0: CC1A4005 1C167325
	.long 0xd7006a25                                           // 0000005603B8: D7006A25
	v_cndmask_b32_e32 v0, v41, v10, vcc_lo                     // 0000005603BC: 02001529
	s_waitcnt lgkmcnt(2)                                       // 0000005603C0: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000005603C4: BF8701C2
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 0000005603C8: CC1A4005 1C167526
	v_add_co_ci_u32_e64 v38, null, s11, v42, vcc_lo            // 0000005603D0: D5207C26 01AA540B
	.long 0xd7006a2b                                           // 0000005603D8: D7006A2B
	v_cndmask_b32_e32 v0, v41, v4, vcc_lo                      // 0000005603DC: 02000929
	s_waitcnt lgkmcnt(1)                                       // 0000005603E0: BF89FC17
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 0000005603E4: CC1A4005 1C167727
	v_add_co_ci_u32_e64 v44, null, s5, v42, vcc_lo             // 0000005603EC: D5207C2C 01AA5405
	s_waitcnt lgkmcnt(0)                                       // 0000005603F4: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005603F8: BF870092
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 0000005603FC: CC1A4005 1C167928
	v_fmac_f32_e32 v21, v28, v5                                // 000000560404: 562A0B1C
	s_clause 0x3                                               // 000000560408: BF850003
	global_load_b128 v[5:8], v[37:38], off                     // 00000056040C: DC5E0000 057C0025
	global_load_b128 v[29:32], v[37:38], off offset:16         // 000000560414: DC5E0010 1D7C0025
	global_load_b128 v[33:36], v[37:38], off offset:32         // 00000056041C: DC5E0020 217C0025
	global_load_b128 v[37:40], v[37:38], off offset:48         // 000000560424: DC5E0030 257C0025
	s_waitcnt vmcnt(3)                                         // 00000056042C: BF890FF7
	v_dot2_f32_bf16 v5, v5, v45, 0                             // 000000560430: CC1A4005 1A025B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000560438: BF870091
	v_dot2_f32_bf16 v5, v6, v46, v5                            // 00000056043C: CC1A4005 1C165D06
	v_dot2_f32_bf16 v5, v7, v47, v5                            // 000000560444: CC1A4005 1C165F07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056044C: BF8700A1
	v_dot2_f32_bf16 v5, v8, v48, v5                            // 000000560450: CC1A4005 1C166108
	s_waitcnt vmcnt(2)                                         // 000000560458: BF890BF7
	v_dot2_f32_bf16 v5, v29, v49, v5                           // 00000056045C: CC1A4005 1C16631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000560464: BF870091
	v_dot2_f32_bf16 v5, v30, v50, v5                           // 000000560468: CC1A4005 1C16651E
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 000000560470: CC1A4005 1C16671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000560478: BF8700A1
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 00000056047C: CC1A4005 1C166920
	s_waitcnt vmcnt(1)                                         // 000000560484: BF8907F7
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 000000560488: CC1A4005 1C166B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000560490: BF870091
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 000000560494: CC1A4005 1C166D22
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 00000056049C: CC1A4005 1C166F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005604A4: BF8700A1
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 0000005604A8: CC1A4005 1C167124
	s_waitcnt vmcnt(0)                                         // 0000005604B0: BF8903F7
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 0000005604B4: CC1A4005 1C167325
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005604BC: BF870091
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 0000005604C0: CC1A4005 1C167526
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 0000005604C8: CC1A4005 1C167727
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005604D0: BF870091
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 0000005604D4: CC1A4005 1C167928
	v_fmac_f32_e32 v24, v28, v5                                // 0000005604DC: 56300B1C
	s_clause 0x3                                               // 0000005604E0: BF850003
	global_load_b128 v[5:8], v[43:44], off                     // 0000005604E4: DC5E0000 057C002B
	global_load_b128 v[29:32], v[43:44], off offset:16         // 0000005604EC: DC5E0010 1D7C002B
	global_load_b128 v[33:36], v[43:44], off offset:32         // 0000005604F4: DC5E0020 217C002B
	global_load_b128 v[37:40], v[43:44], off offset:48         // 0000005604FC: DC5E0030 257C002B
	s_waitcnt vmcnt(3)                                         // 000000560504: BF890FF7
	v_dot2_f32_bf16 v5, v5, v45, 0                             // 000000560508: CC1A4005 1A025B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000560510: BF870091
	v_dot2_f32_bf16 v5, v6, v46, v5                            // 000000560514: CC1A4005 1C165D06
	v_dot2_f32_bf16 v5, v7, v47, v5                            // 00000056051C: CC1A4005 1C165F07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000560524: BF8700A1
	v_dot2_f32_bf16 v5, v8, v48, v5                            // 000000560528: CC1A4005 1C166108
	s_waitcnt vmcnt(2)                                         // 000000560530: BF890BF7
	v_dot2_f32_bf16 v5, v29, v49, v5                           // 000000560534: CC1A4005 1C16631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056053C: BF870091
	v_dot2_f32_bf16 v5, v30, v50, v5                           // 000000560540: CC1A4005 1C16651E
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 000000560548: CC1A4005 1C16671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000560550: BF8700A1
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 000000560554: CC1A4005 1C166920
	s_waitcnt vmcnt(1)                                         // 00000056055C: BF8907F7
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 000000560560: CC1A4005 1C166B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000560568: BF870091
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 00000056056C: CC1A4005 1C166D22
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 000000560574: CC1A4005 1C166F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056057C: BF8700A1
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 000000560580: CC1A4005 1C167124
	s_waitcnt vmcnt(0)                                         // 000000560588: BF8903F7
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 00000056058C: CC1A4005 1C167325
	.long 0xd7006a25                                           // 000000560594: D7006A25
	v_cndmask_b32_e32 v0, v41, v16, vcc_lo                     // 000000560598: 02002129
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000056059C: BF870122
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 0000005605A0: CC1A4005 1C167526
	v_add_co_ci_u32_e64 v38, null, s14, v42, vcc_lo            // 0000005605A8: D5207C26 01AA540E
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 0000005605B0: CC1A4005 1C167727
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005605B8: BF870091
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 0000005605BC: CC1A4005 1C167928
	v_fmac_f32_e32 v23, v28, v5                                // 0000005605C4: 562E0B1C
	s_clause 0x3                                               // 0000005605C8: BF850003
	global_load_b128 v[5:8], v[37:38], off                     // 0000005605CC: DC5E0000 057C0025
	global_load_b128 v[29:32], v[37:38], off offset:16         // 0000005605D4: DC5E0010 1D7C0025
	global_load_b128 v[33:36], v[37:38], off offset:32         // 0000005605DC: DC5E0020 217C0025
	global_load_b128 v[37:40], v[37:38], off offset:48         // 0000005605E4: DC5E0030 257C0025
	s_waitcnt vmcnt(3)                                         // 0000005605EC: BF890FF7
	v_dot2_f32_bf16 v5, v5, v45, 0                             // 0000005605F0: CC1A4005 1A025B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005605F8: BF870091
	v_dot2_f32_bf16 v5, v6, v46, v5                            // 0000005605FC: CC1A4005 1C165D06
	v_dot2_f32_bf16 v5, v7, v47, v5                            // 000000560604: CC1A4005 1C165F07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056060C: BF8700A1
	v_dot2_f32_bf16 v5, v8, v48, v5                            // 000000560610: CC1A4005 1C166108
	s_waitcnt vmcnt(2)                                         // 000000560618: BF890BF7
	v_dot2_f32_bf16 v5, v29, v49, v5                           // 00000056061C: CC1A4005 1C16631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000560624: BF870091
	v_dot2_f32_bf16 v5, v30, v50, v5                           // 000000560628: CC1A4005 1C16651E
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 000000560630: CC1A4005 1C16671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000560638: BF8700A1
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 00000056063C: CC1A4005 1C166920
	s_waitcnt vmcnt(1)                                         // 000000560644: BF8907F7
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 000000560648: CC1A4005 1C166B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000560650: BF870091
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 000000560654: CC1A4005 1C166D22
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 00000056065C: CC1A4005 1C166F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000560664: BF8700A1
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 000000560668: CC1A4005 1C167124
	s_waitcnt vmcnt(0)                                         // 000000560670: BF8903F7
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 000000560674: CC1A4005 1C167325
	.long 0xd7006a25                                           // 00000056067C: D7006A25
	v_cndmask_b32_e32 v0, v43, v4, vcc_lo                      // 000000560680: 0200092B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000560684: BF870122
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 000000560688: CC1A4005 1C167526
	v_add_co_ci_u32_e64 v38, null, s5, v44, vcc_lo             // 000000560690: D5207C26 01AA5805
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 000000560698: CC1A4005 1C167727
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005606A0: BF870091
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 0000005606A4: CC1A4005 1C167928
	v_fmac_f32_e32 v22, v28, v5                                // 0000005606AC: 562C0B1C
	s_clause 0x3                                               // 0000005606B0: BF850003
	global_load_b128 v[5:8], v[37:38], off                     // 0000005606B4: DC5E0000 057C0025
	global_load_b128 v[29:32], v[37:38], off offset:16         // 0000005606BC: DC5E0010 1D7C0025
	global_load_b128 v[33:36], v[37:38], off offset:32         // 0000005606C4: DC5E0020 217C0025
	global_load_b128 v[37:40], v[37:38], off offset:48         // 0000005606CC: DC5E0030 257C0025
	s_waitcnt vmcnt(3)                                         // 0000005606D4: BF890FF7
	v_dot2_f32_bf16 v5, v5, v45, 0                             // 0000005606D8: CC1A4005 1A025B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000005606E0: BF870121
	v_dot2_f32_bf16 v5, v6, v46, v5                            // 0000005606E4: CC1A4005 1C165D06
	v_mov_b32_e32 v6, v2                                       // 0000005606EC: 7E0C0302
	v_dot2_f32_bf16 v5, v7, v47, v5                            // 0000005606F0: CC1A4005 1C165F07
	v_mov_b32_e32 v7, v3                                       // 0000005606F8: 7E0E0303
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000005606FC: BF870132
	v_dot2_f32_bf16 v5, v8, v48, v5                            // 000000560700: CC1A4005 1C166108
	v_mov_b32_e32 v8, v4                                       // 000000560708: 7E100304
	s_waitcnt vmcnt(2)                                         // 00000056070C: BF890BF7
	v_dot2_f32_bf16 v5, v29, v49, v5                           // 000000560710: CC1A4005 1C16631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000560718: BF870091
	v_dot2_f32_bf16 v5, v30, v50, v5                           // 00000056071C: CC1A4005 1C16651E
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 000000560724: CC1A4005 1C16671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056072C: BF8700A1
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 000000560730: CC1A4005 1C166920
	s_waitcnt vmcnt(1)                                         // 000000560738: BF8907F7
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 00000056073C: CC1A4005 1C166B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000560744: BF870091
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 000000560748: CC1A4005 1C166D22
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 000000560750: CC1A4005 1C166F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000560758: BF8700A1
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 00000056075C: CC1A4005 1C167124
	s_waitcnt vmcnt(0)                                         // 000000560764: BF8903F7
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 000000560768: CC1A4005 1C167325
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000560770: BF870091
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 000000560774: CC1A4005 1C167526
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 00000056077C: CC1A4005 1C167727
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000560784: BF870091
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 000000560788: CC1A4005 1C167928
	v_fmac_f32_e32 v17, v28, v5                                // 000000560790: 56220B1C
	v_dual_mov_b32 v5, v1 :: v_dual_mov_b32 v28, v27           // 000000560794: CA100101 051C011B
	s_and_not1_b32 exec_lo, exec_lo, s15                       // 00000056079C: 917E0F7E
	s_cbranch_execz 31                                         // 0000005607A0: BFA5001F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x920>
	s_waitcnt vmcnt(0)                                         // 0000005607A4: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000005607A8: BF8701C1
	v_dual_mov_b32 v1, v5 :: v_dual_add_nc_u32 v10, 32, v10    // 0000005607AC: CA200105 010A14A0
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v3, v7             // 0000005607B4: CA100106 02020107
	v_mov_b32_e32 v4, v8                                       // 0000005607BC: 7E080308
	s_mov_b32 s17, exec_lo                                     // 0000005607C0: BE91007E
	v_cmp_ge_i32_e32 vcc_lo, v10, v18                          // 0000005607C4: 7C8C250A
	.long 0xd4c1007e                                           // 0000005607C8: D4C1007E
	v_cndmask_b32_e32 v1, v10, v18, vcc_lo                     // 0000005607CC: 0202250A
	s_cbranch_execz 65115                                      // 0000005607D0: BFA5FE5B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x240>
	v_ashrrev_i32_e32 v2, 31, v26                              // 0000005607D4: 3404349F
	v_ashrrev_i32_e32 v4, 31, v25                              // 0000005607D8: 3408329F
	.long 0xd7000001                                           // 0000005607DC: D7000001
	v_cndmask_b32_e32 v1, v11, v26, vcc_lo                     // 0000005607E0: 0202350B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005607E4: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v20, v2, s0                  // 0000005607E8: D5207C02 00020514
	.long 0xd7000003                                           // 0000005607F0: D7000003
	v_cndmask_b32_e32 v1, v9, v25, vcc_lo                      // 0000005607F4: 02023309
	v_add_co_ci_u32_e64 v4, null, v19, v4, s0                  // 0000005607F8: D5207C04 00020913
	s_clause 0x1                                               // 000000560800: BF850001
	global_load_d16_b16 v13, v[1:2], off                       // 000000560804: DC820000 0D7C0001
	global_load_b128 v[1:4], v[3:4], off                       // 00000056080C: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 000000560814: BF8907F7
	v_cvt_f32_f16_e32 v27, v13                                 // 000000560818: 7E36170D
	s_branch 65096                                             // 00000056081C: BFA0FE48 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x240>
	s_or_b32 exec_lo, exec_lo, s15                             // 000000560820: 8C7E0F7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000560824: BF8700B9
	s_or_b32 exec_lo, exec_lo, s1                              // 000000560828: 8C7E017E
	.long 0xd71f0001                                           // 00000056082C: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000560830: 020100C1
	s_mov_b32 s0, exec_lo                                      // 000000560834: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 000000560838: 3A040290
	s_waitcnt vmcnt(0)                                         // 00000056083C: BF8903F7
	v_xor_b32_e32 v7, 8, v1                                    // 000000560840: 3A0E0288
	v_xor_b32_e32 v12, 4, v1                                   // 000000560844: 3A180284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000560848: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 00000056084C: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 000000560850: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v7                            // 000000560854: 7C980EA0
	v_cndmask_b32_e32 v7, v1, v7, vcc_lo                       // 000000560858: 020E0F01
	v_cmp_gt_u32_e32 vcc_lo, 32, v12                           // 00000056085C: 7C9818A0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000560860: BF870002
	v_lshlrev_b32_e32 v7, 2, v7                                // 000000560864: 300E0E82
	v_lshlrev_b32_e32 v2, 2, v2                                // 000000560868: 30040482
	ds_bpermute_b32 v3, v2, v21                                // 00000056086C: DACC0000 03001502
	s_waitcnt lgkmcnt(0)                                       // 000000560874: BF89FC07
	v_add_f32_e32 v3, v21, v3                                  // 000000560878: 06060715
	ds_bpermute_b32 v4, v2, v24                                // 00000056087C: DACC0000 04001802
	ds_bpermute_b32 v5, v2, v23                                // 000000560884: DACC0000 05001702
	ds_bpermute_b32 v6, v2, v22                                // 00000056088C: DACC0000 06001602
	ds_bpermute_b32 v2, v2, v17                                // 000000560894: DACC0000 02001102
	ds_bpermute_b32 v8, v7, v3                                 // 00000056089C: DACC0000 08000307
	s_waitcnt lgkmcnt(3)                                       // 0000005608A4: BF89FC37
	v_dual_add_f32 v4, v24, v4 :: v_dual_add_f32 v5, v23, v5   // 0000005608A8: C9080918 04040B17
	s_waitcnt lgkmcnt(2)                                       // 0000005608B0: BF89FC27
	v_add_f32_e32 v6, v22, v6                                  // 0000005608B4: 060C0D16
	s_waitcnt lgkmcnt(0)                                       // 0000005608B8: BF89FC07
	v_dual_add_f32 v2, v17, v2 :: v_dual_add_f32 v3, v3, v8    // 0000005608BC: C9080511 02021103
	ds_bpermute_b32 v9, v7, v4                                 // 0000005608C4: DACC0000 09000407
	ds_bpermute_b32 v10, v7, v5                                // 0000005608CC: DACC0000 0A000507
	v_cndmask_b32_e32 v12, v1, v12, vcc_lo                     // 0000005608D4: 02181901
	ds_bpermute_b32 v11, v7, v6                                // 0000005608D8: DACC0000 0B000607
	ds_bpermute_b32 v7, v7, v2                                 // 0000005608E0: DACC0000 07000207
	v_lshlrev_b32_e32 v12, 2, v12                              // 0000005608E8: 30181882
	s_waitcnt lgkmcnt(2)                                       // 0000005608EC: BF89FC27
	v_dual_add_f32 v4, v4, v9 :: v_dual_add_f32 v5, v5, v10    // 0000005608F0: C9081304 04041505
	ds_bpermute_b32 v8, v12, v4                                // 0000005608F8: DACC0000 0800040C
	ds_bpermute_b32 v9, v12, v5                                // 000000560900: DACC0000 0900050C
	s_waitcnt lgkmcnt(3)                                       // 000000560908: BF89FC37
	v_add_f32_e32 v6, v6, v11                                  // 00000056090C: 060C1706
	s_waitcnt lgkmcnt(1)                                       // 000000560910: BF89FC17
	v_add_f32_e32 v4, v4, v8                                   // 000000560914: 06081104
	v_add_f32_e32 v2, v2, v7                                   // 000000560918: 06040F02
	ds_bpermute_b32 v7, v12, v3                                // 00000056091C: DACC0000 0700030C
	s_waitcnt lgkmcnt(1)                                       // 000000560924: BF89FC17
	v_add_f32_e32 v5, v5, v9                                   // 000000560928: 060A1305
	ds_bpermute_b32 v10, v12, v6                               // 00000056092C: DACC0000 0A00060C
	ds_bpermute_b32 v11, v12, v2                               // 000000560934: DACC0000 0B00020C
	v_xor_b32_e32 v12, 2, v1                                   // 00000056093C: 3A180282
	s_delay_alu instid0(VALU_DEP_1)                            // 000000560940: BF870001
	v_cmp_gt_u32_e32 vcc_lo, 32, v12                           // 000000560944: 7C9818A0
	s_waitcnt lgkmcnt(2)                                       // 000000560948: BF89FC27
	v_dual_add_f32 v3, v3, v7 :: v_dual_cndmask_b32 v12, v1, v12// 00000056094C: C9120F03 030C1901
	s_waitcnt lgkmcnt(1)                                       // 000000560954: BF89FC17
	v_add_f32_e32 v6, v6, v10                                  // 000000560958: 060C1506
	s_waitcnt lgkmcnt(0)                                       // 00000056095C: BF89FC07
	v_add_f32_e32 v2, v2, v11                                  // 000000560960: 06041702
	v_lshlrev_b32_e32 v12, 2, v12                              // 000000560964: 30181882
	ds_bpermute_b32 v7, v12, v3                                // 000000560968: DACC0000 0700030C
	ds_bpermute_b32 v8, v12, v4                                // 000000560970: DACC0000 0800040C
	ds_bpermute_b32 v9, v12, v5                                // 000000560978: DACC0000 0900050C
	ds_bpermute_b32 v10, v12, v6                               // 000000560980: DACC0000 0A00060C
	ds_bpermute_b32 v11, v12, v2                               // 000000560988: DACC0000 0B00020C
	v_xor_b32_e32 v12, 1, v1                                   // 000000560990: 3A180281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000560994: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v12                           // 000000560998: 7C9818A0
	v_cndmask_b32_e32 v1, v1, v12, vcc_lo                      // 00000056099C: 02021901
	s_waitcnt lgkmcnt(4)                                       // 0000005609A0: BF89FC47
	v_dual_add_f32 v1, v3, v7 :: v_dual_lshlrev_b32 v12, 2, v1 // 0000005609A4: C9220F03 010C0282
	s_waitcnt lgkmcnt(2)                                       // 0000005609AC: BF89FC27
	v_dual_add_f32 v3, v4, v8 :: v_dual_add_f32 v4, v5, v9     // 0000005609B0: C9081104 03041305
	s_waitcnt lgkmcnt(1)                                       // 0000005609B8: BF89FC17
	v_add_f32_e32 v7, v6, v10                                  // 0000005609BC: 060E1506
	s_waitcnt lgkmcnt(0)                                       // 0000005609C0: BF89FC07
	v_add_f32_e32 v2, v2, v11                                  // 0000005609C4: 06041702
	ds_bpermute_b32 v5, v12, v1                                // 0000005609C8: DACC0000 0500010C
	ds_bpermute_b32 v8, v12, v3                                // 0000005609D0: DACC0000 0800030C
	ds_bpermute_b32 v9, v12, v4                                // 0000005609D8: DACC0000 0900040C
	ds_bpermute_b32 v10, v12, v7                               // 0000005609E0: DACC0000 0A00070C
	ds_bpermute_b32 v6, v12, v2                                // 0000005609E8: DACC0000 0600020C
	v_cmpx_eq_u32_e32 0, v16                                   // 0000005609F0: 7D942080
	s_cbranch_execz 18                                         // 0000005609F4: BFA50012 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0xb40>
	v_mul_u32_u24_e32 v11, 20, v15                             // 0000005609F8: 16161E94
	s_waitcnt lgkmcnt(0)                                       // 0000005609FC: BF89FC07
	v_dual_add_f32 v3, v3, v8 :: v_dual_add_f32 v2, v2, v6     // 000000560A00: C9081103 03020D02
	v_add_f32_e32 v1, v1, v5                                   // 000000560A08: 06020B01
	v_dual_add_f32 v7, v7, v10 :: v_dual_add_f32 v4, v4, v9    // 000000560A0C: C9081507 07041304
	v_or_b32_e32 v5, 0x400, v11                                // 000000560A14: 380A16FF 00000400
	v_mad_u32_u24 v8, v15, 20, 0x408                           // 000000560A1C: D60B0008 03FD290F 00000408
	ds_store_2addr_b32 v5, v1, v3 offset1:1                    // 000000560A28: D8380100 00030105
	ds_store_2addr_b32 v8, v4, v7 offset1:1                    // 000000560A30: D8380100 00070408
	ds_store_b32 v11, v2 offset:1040                           // 000000560A38: D8340410 0000020B
	s_or_b32 exec_lo, exec_lo, s0                              // 000000560A40: 8C7E007E
	.long 0xd4510000                                           // 000000560A44: D4510000
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 000000560A48: 02001802
	v_cmp_gt_u32_e32 vcc_lo, 5, v0                             // 000000560A4C: 7C980085
	s_waitcnt lgkmcnt(0)                                       // 000000560A50: BF89FC07
	s_barrier                                                  // 000000560A54: BFBD0000
	buffer_gl0_inv                                             // 000000560A58: E0AC0000 00000000
	s_and_b32 s0, vcc_lo, s0                                   // 000000560A60: 8B00006A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000560A64: BF870009
	s_and_saveexec_b32 s1, s0                                  // 000000560A68: BE812000
	s_cbranch_execz 52                                         // 000000560A6C: BFA50034 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0xc40>
	v_add_nc_u32_e32 v7, 0x400, v14                            // 000000560A70: 4A0E1CFF 00000400
	s_lshl_b64 s[0:1], s[2:3], 1                               // 000000560A78: 84808102
	ds_load_2addr_b32 v[1:2], v7 offset1:5                     // 000000560A7C: D8DC0500 01000007
	ds_load_2addr_b32 v[3:4], v7 offset0:10 offset1:15         // 000000560A84: D8DC0F0A 03000007
	ds_load_2addr_b32 v[5:6], v7 offset0:20 offset1:25         // 000000560A8C: D8DC1914 05000007
	ds_load_2addr_b32 v[7:8], v7 offset0:30 offset1:35         // 000000560A94: D8DC231E 07000007
	s_waitcnt lgkmcnt(3)                                       // 000000560A9C: BF89FC37
	v_add_f32_e32 v1, 0, v1                                    // 000000560AA0: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000560AA4: BF8700A1
	v_add_f32_e32 v1, v1, v2                                   // 000000560AA8: 06020501
	s_waitcnt lgkmcnt(2)                                       // 000000560AAC: BF89FC27
	v_add_f32_e32 v1, v1, v3                                   // 000000560AB0: 06020701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000560AB4: BF870131
	v_add_f32_e32 v3, v1, v4                                   // 000000560AB8: 06060901
	v_mad_u64_u32 v[1:2], null, s12, v0, 0                     // 000000560ABC: D6FE7C01 0202000C
	s_waitcnt lgkmcnt(1)                                       // 000000560AC4: BF89FC17
	v_add_f32_e32 v3, v3, v5                                   // 000000560AC8: 06060B03
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000560ACC: BF870191
	v_add_f32_e32 v4, v3, v6                                   // 000000560AD0: 06080D03
	v_mad_u64_u32 v[2:3], null, s13, v0, v[2:3]                // 000000560AD4: D6FE7C02 040A000D
	s_waitcnt lgkmcnt(0)                                       // 000000560ADC: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000560AE0: BF870092
	v_add_f32_e32 v0, v4, v7                                   // 000000560AE4: 06000F04
	v_add_f32_e32 v3, v0, v8                                   // 000000560AE8: 06061100
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000560AEC: BF870113
	.long 0xd73c0000                                           // 000000560AF0: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 000000560AF4: 02020281
	v_bfe_u32 v2, v3, 16, 1                                    // 000000560AF8: D6100002 02052103
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000560B00: BF870092
	.long 0xd7006a00                                           // 000000560B04: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 000000560B08: 02020008
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 000000560B0C: D5207C01 01AA0209
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000560B14: BF870193
	v_add3_u32 v2, v3, v2, 0x7fff                              // 000000560B18: D6550002 03FE0503 00007FFF
	.long 0xd7006a00                                           // 000000560B24: D7006A00
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 000000560B28: 02000100
	s_delay_alu instid0(VALU_DEP_1)                            // 000000560B2C: BF870001
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 000000560B30: D5207C01 01AA0201
	global_store_d16_hi_b16 v[0:1], v2, off                    // 000000560B38: DC960000 007C0200
	s_endpgm                                                   // 000000560B40: BFB00000
		...

