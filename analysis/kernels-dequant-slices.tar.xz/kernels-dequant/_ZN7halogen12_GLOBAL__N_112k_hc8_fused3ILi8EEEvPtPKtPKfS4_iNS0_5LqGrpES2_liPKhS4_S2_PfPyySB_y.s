000000000032ce00 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y>:
; _ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y():
	s_clause 0x2                                               // 00000032CE00: BF850002
	s_load_b32 s24, s[0:1], 0x20                               // 00000032CE04: F4000600 F8000020
	s_load_b128 s[20:23], s[0:1], 0x150                        // 00000032CE0C: F4080500 F8000150
	s_load_b512 s[4:19], s[0:1], 0x168                         // 00000032CE14: F4100100 F8000168
	s_mov_b32 s3, -1                                           // 00000032CE1C: BE8300C1
	s_waitcnt lgkmcnt(0)                                       // 00000032CE20: BF89FC07
	s_cmp_ge_i32 s2, s24                                       // 00000032CE24: BF031802
	s_cbranch_scc0 1949                                        // 00000032CE28: BFA1079D <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x1ea0>
	s_load_b32 s3, s[0:1], 0x160                               // 00000032CE2C: F40000C0 F8000160
	s_mov_b32 s25, -1                                          // 00000032CE34: BE9900C1
	s_waitcnt lgkmcnt(0)                                       // 00000032CE38: BF89FC07
	s_add_i32 s3, s3, s24                                      // 00000032CE3C: 81031803
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000032CE40: BF870009
	s_cmp_ge_i32 s2, s3                                        // 00000032CE44: BF030302
	s_cbranch_scc0 1275                                        // 00000032CE48: BFA104FB <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x1438>
	v_lshrrev_b32_e32 v1, 6, v0                                // 00000032CE4C: 32020086
	v_bfe_u32 v2, v0, 4, 2                                     // 00000032CE50: D6100002 02090900
	s_sub_i32 s3, s2, s3                                       // 00000032CE58: 81830302
	v_dual_mov_b32 v14, 0 :: v_dual_and_b32 v13, 15, v0        // 00000032CE5C: CA240080 0E0C008F
	s_lshl_b32 s3, s3, 2                                       // 00000032CE64: 84038203
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000032CE68: BF8701A2
	v_mul_u32_u24_e32 v2, 0xa00, v2                            // 00000032CE6C: 160404FF 00000A00
	v_or_b32_e32 v1, s3, v1                                    // 00000032CE74: 38020203
	v_lshlrev_b32_e32 v11, 4, v13                              // 00000032CE78: 30161A84
	v_or_b32_e32 v16, 16, v13                                  // 00000032CE7C: 38201A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000032CE80: BF8700A3
	v_ashrrev_i32_e32 v3, 31, v1                               // 00000032CE84: 3406029F
	.long 0xd7006a01                                           // 00000032CE88: D7006A01
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 00000032CE8C: 02020501
	v_add_co_ci_u32_e64 v2, null, 0, v3, vcc_lo                // 00000032CE90: D5207C02 01AA0680
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000032CE98: BF870132
	v_mad_u64_u32 v[9:10], null, 0x154, v1, s[4:5]             // 00000032CE9C: D6FE7C09 001202FF 00000154
	v_and_b32_e32 v3, 12, v0                                   // 00000032CEA8: 3606008C
	s_mov_b32 s4, exec_lo                                      // 00000032CEAC: BE84007E
	v_mad_i32_i24 v10, 0x154, v2, v10                          // 00000032CEB0: D60A000A 042A04FF 00000154
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000032CEBC: BF870093
	.long 0xd7006a01                                           // 00000032CEC0: D7006A01
	v_cndmask_b32_e32 v1, v9, v11, vcc_lo                      // 00000032CEC4: 02021709
	v_add_co_ci_u32_e64 v2, null, 0, v10, vcc_lo               // 00000032CEC8: D5207C02 01AA1480
	.long 0xd7006a03                                           // 00000032CED0: D7006A03
	v_cndmask_b32_e32 v1, v9, v3, vcc_lo                       // 00000032CED4: 02020709
	s_delay_alu instid0(VALU_DEP_1)                            // 00000032CED8: BF870001
	v_add_co_ci_u32_e64 v4, null, 0, v10, vcc_lo               // 00000032CEDC: D5207C04 01AA1480
	s_clause 0x1                                               // 00000032CEE4: BF850001
	global_load_b128 v[5:8], v[1:2], off                       // 00000032CEE8: DC5E0000 057C0001
	global_load_b32 v17, v[3:4], off offset:320                // 00000032CEF0: DC520140 117C0003
	v_cmpx_gt_u32_e32 20, v16                                  // 00000032CEF8: 7D982094
	s_cbranch_execz 5                                          // 00000032CEFC: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x114>
	s_clause 0x1                                               // 00000032CF00: BF850001
	global_load_b128 v[1:4], v[1:2], off offset:256            // 00000032CF04: DC5E0100 017C0001
	global_load_b32 v14, v[9:10], off offset:336               // 00000032CF0C: DC520150 0E7C0009
	s_or_b32 exec_lo, exec_lo, s4                              // 00000032CF14: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000032CF18: BF870009
	s_mov_b32 s4, exec_lo                                      // 00000032CF1C: BE84007E
	v_cmpx_eq_u32_e32 0, v0                                    // 00000032CF20: 7D940080
	s_xor_b32 s4, exec_lo, s4                                  // 00000032CF24: 8D04047E
	s_cbranch_execz 20                                         // 00000032CF28: BFA50014 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x17c>
	v_mov_b32_e32 v9, 0                                        // 00000032CF2C: 7E120280
	global_load_b64 v[18:19], v9, s[16:17] glc                 // 00000032CF30: DC564000 12100009
	s_waitcnt vmcnt(0)                                         // 00000032CF38: BF8903F7
	buffer_gl1_inv                                             // 00000032CF3C: E0B00000 00000000
	buffer_gl0_inv                                             // 00000032CF44: E0AC0000 00000000
	v_cmp_le_u64_e32 vcc_lo, s[18:19], v[18:19]                // 00000032CF4C: 7CB62412
	s_cbranch_vccnz 10                                         // 00000032CF50: BFA4000A <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x17c>
	s_sleep 1                                                  // 00000032CF54: BF830001
	global_load_b64 v[18:19], v9, s[16:17] glc                 // 00000032CF58: DC564000 12100009
	s_waitcnt vmcnt(0)                                         // 00000032CF60: BF8903F7
	buffer_gl1_inv                                             // 00000032CF64: E0B00000 00000000
	buffer_gl0_inv                                             // 00000032CF6C: E0AC0000 00000000
	v_cmp_gt_u64_e32 vcc_lo, s[18:19], v[18:19]                // 00000032CF74: 7CB82412
	s_cbranch_vccnz 65526                                      // 00000032CF78: BFA4FFF6 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x154>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000032CF7C: 8C7E047E
	v_lshlrev_b32_e32 v15, 1, v11                              // 00000032CF80: 301E1681
	s_waitcnt vmcnt(0)                                         // 00000032CF84: BF8903F7
	s_barrier                                                  // 00000032CF88: BFBD0000
	buffer_gl0_inv                                             // 00000032CF8C: E0AC0000 00000000
	buffer_gl1_inv                                             // 00000032CF94: E0B00000 00000000
	buffer_gl0_inv                                             // 00000032CF9C: E0AC0000 00000000
	s_clause 0x6                                               // 00000032CFA4: BF850006
	global_load_b128 v[18:21], v15, s[6:7]                     // 00000032CFA8: DC5E0000 1206000F
	global_load_b128 v[22:25], v15, s[6:7] offset:640          // 00000032CFB0: DC5E0280 1606000F
	global_load_b128 v[26:29], v15, s[6:7] offset:1280         // 00000032CFB8: DC5E0500 1A06000F
	global_load_b128 v[30:33], v15, s[6:7] offset:1920         // 00000032CFC0: DC5E0780 1E06000F
	global_load_b128 v[34:37], v15, s[6:7] offset:2560         // 00000032CFC8: DC5E0A00 2206000F
	global_load_b128 v[38:41], v15, s[6:7] offset:3200         // 00000032CFD0: DC5E0C80 2606000F
	global_load_b128 v[42:45], v15, s[6:7] offset:3840         // 00000032CFD8: DC5E0F00 2A06000F
	.long 0xd7000409                                           // 00000032CFE0: D7000409
	v_cndmask_b32_e32 v1, s6, v15, vcc_lo                      // 00000032CFE4: 02021E06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000032CFE8: BF8701A1
	v_add_co_ci_u32_e64 v10, null, s7, 0, s4                   // 00000032CFEC: D5207C0A 00110007
	v_cvt_f32_ubyte0_e32 v82, v5                               // 00000032CFF4: 7EA42305
	.long 0xd7006a0b                                           // 00000032CFF8: D7006A0B
	v_cndmask_b32_e32 v1, 0x1000, v9, vcc_lo                   // 00000032CFFC: 020212FF 00001000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000032D004: BF870001
	v_add_co_ci_u32_e64 v12, null, 0, v10, vcc_lo              // 00000032D008: D5207C0C 01AA1480
	v_cvt_f32_ubyte1_e32 v83, v5                               // 00000032D010: 7EA62505
	v_cvt_f32_ubyte2_e32 v84, v5                               // 00000032D014: 7EA82705
	s_clause 0x8                                               // 00000032D018: BF850008
	global_load_b128 v[46:49], v[11:12], off offset:384        // 00000032D01C: DC5E0180 2E7C000B
	global_load_b128 v[50:53], v15, s[6:7] offset:16           // 00000032D024: DC5E0010 3206000F
	global_load_b128 v[54:57], v15, s[6:7] offset:656          // 00000032D02C: DC5E0290 3606000F
	global_load_b128 v[58:61], v15, s[6:7] offset:1296         // 00000032D034: DC5E0510 3A06000F
	global_load_b128 v[62:65], v15, s[6:7] offset:1936         // 00000032D03C: DC5E0790 3E06000F
	global_load_b128 v[66:69], v15, s[6:7] offset:2576         // 00000032D044: DC5E0A10 4206000F
	global_load_b128 v[70:73], v15, s[6:7] offset:3216         // 00000032D04C: DC5E0C90 4606000F
	global_load_b128 v[74:77], v15, s[6:7] offset:3856         // 00000032D054: DC5E0F10 4A06000F
	global_load_b128 v[78:81], v[11:12], off offset:400        // 00000032D05C: DC5E0190 4E7C000B
	v_cvt_f32_ubyte3_e32 v5, v5                                // 00000032D064: 7E0A2905
	v_cvt_f32_ubyte0_e32 v85, v6                               // 00000032D068: 7EAA2306
	v_cvt_f32_ubyte1_e32 v86, v6                               // 00000032D06C: 7EAC2506
	v_cvt_f32_ubyte2_e32 v87, v6                               // 00000032D070: 7EAE2706
	v_cvt_f32_ubyte3_e32 v6, v6                                // 00000032D074: 7E0C2906
	v_cvt_f32_ubyte0_e32 v88, v7                               // 00000032D078: 7EB02307
	v_cvt_f32_ubyte1_e32 v89, v7                               // 00000032D07C: 7EB22507
	v_cvt_f32_ubyte2_e32 v90, v7                               // 00000032D080: 7EB42707
	v_cvt_f32_ubyte3_e32 v7, v7                                // 00000032D084: 7E0E2907
	v_cvt_f32_ubyte0_e32 v91, v8                               // 00000032D088: 7EB62308
	v_cvt_f32_ubyte1_e32 v92, v8                               // 00000032D08C: 7EB82508
	v_cvt_f32_ubyte2_e32 v93, v8                               // 00000032D090: 7EBA2708
	v_cvt_f32_ubyte3_e32 v8, v8                                // 00000032D094: 7E102908
	v_fma_mix_f32 v82, v82, v17, v17 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032D098: CC206052 14462352
	v_fma_mix_f32 v83, v83, v17, v17 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032D0A0: CC206053 14462353
	v_fma_mix_f32 v84, v84, v17, v17 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032D0A8: CC206054 14462354
	v_fma_mix_f32 v5, v5, v17, v17 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032D0B0: CC206005 14462305
	v_fma_mix_f32 v85, v85, v17, v17 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032D0B8: CC206055 14462355
	v_fma_mix_f32 v86, v86, v17, v17 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032D0C0: CC206056 14462356
	v_fma_mix_f32 v87, v87, v17, v17 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032D0C8: CC206057 14462357
	v_fma_mix_f32 v6, v6, v17, v17 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032D0D0: CC206006 14462306
	v_fma_mix_f32 v88, v88, v17, v17 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032D0D8: CC206058 14462358
	v_fma_mix_f32 v89, v89, v17, v17 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032D0E0: CC206059 14462359
	v_fma_mix_f32 v90, v90, v17, v17 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032D0E8: CC20605A 1446235A
	v_fma_mix_f32 v7, v7, v17, v17 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032D0F0: CC206007 14462307
	v_fma_mix_f32 v91, v91, v17, v17 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032D0F8: CC20605B 1446235B
	v_fma_mix_f32 v92, v92, v17, v17 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032D100: CC20605C 1446235C
	v_fma_mix_f32 v93, v93, v17, v17 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032D108: CC20605D 1446235D
	v_fma_mix_f32 v8, v8, v17, v17 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032D110: CC206008 14462308
	v_bfe_u32 v17, v82, 16, 1                                  // 00000032D118: D6100011 02052152
	v_bfe_u32 v98, v83, 16, 1                                  // 00000032D120: D6100062 02052153
	v_bfe_u32 v99, v84, 16, 1                                  // 00000032D128: D6100063 02052154
	.long 0x7f1e3880                                           // 00000032D130: 7F1E3880
	v_bfe_u32 v100, v5, 16, 1                                  // 00000032D134: D6100064 02052105
	v_add3_u32 v17, v82, v17, 0x7fff                           // 00000032D13C: D6550011 03FE2352 00007FFF
	v_bfe_u32 v101, v85, 16, 1                                 // 00000032D148: D6100065 02052155
	v_add3_u32 v82, v83, v98, 0x7fff                           // 00000032D150: D6550052 03FEC553 00007FFF
	v_add3_u32 v83, v84, v99, 0x7fff                           // 00000032D15C: D6550053 03FEC754 00007FFF
	.long 0x7fbc398f                                           // 00000032D168: 7FBC398F
	.long 0x7e1e3991                                           // 00000032D16C: 7E1E3991
	v_bfe_u32 v102, v86, 16, 1                                 // 00000032D170: D6100066 02052156
	v_add3_u32 v5, v5, v100, 0x7fff                            // 00000032D178: D6550005 03FEC905 00007FFF
	v_add3_u32 v84, v85, v101, 0x7fff                          // 00000032D184: D6550054 03FECB55 00007FFF
	.long 0x7ebc39d3                                           // 00000032D190: 7EBC39D3
	v_and_or_b32 v82, 0xffff0000, v82, v15                     // 00000032D194: D6570052 043EA4FF FFFF0000
	v_bfe_u32 v103, v87, 16, 1                                 // 00000032D1A0: D6100067 02052157
	v_add3_u32 v85, v86, v102, 0x7fff                          // 00000032D1A8: D6550055 03FECD56 00007FFF
	.long 0x7e1e39d4                                           // 00000032D1B4: 7E1E39D4
	v_and_or_b32 v5, 0xffff0000, v5, v94                       // 00000032D1B8: D6570005 057A0AFF FFFF0000
	v_bfe_u32 v104, v6, 16, 1                                  // 00000032D1C4: D6100068 02052106
	v_bfe_u32 v105, v88, 16, 1                                 // 00000032D1CC: D6100069 02052158
	v_add3_u32 v86, v87, v103, 0x7fff                          // 00000032D1D4: D6550056 03FECF57 00007FFF
	v_and_or_b32 v85, 0xffff0000, v85, v15                     // 00000032D1E0: D6570055 043EAAFF FFFF0000
	.long 0x7fbe398f                                           // 00000032D1EC: 7FBE398F
	v_bfe_u32 v106, v89, 16, 1                                 // 00000032D1F0: D610006A 02052159
	v_bfe_u32 v107, v90, 16, 1                                 // 00000032D1F8: D610006B 0205215A
	v_add3_u32 v6, v6, v104, 0x7fff                            // 00000032D200: D6550006 03FED106 00007FFF
	v_add3_u32 v17, v88, v105, 0x7fff                          // 00000032D20C: D6550011 03FED358 00007FFF
	.long 0x7ebe39d6                                           // 00000032D218: 7EBE39D6
	v_bfe_u32 v108, v7, 16, 1                                  // 00000032D21C: D610006C 02052107
	v_bfe_u32 v109, v91, 16, 1                                 // 00000032D224: D610006D 0205215B
	v_add3_u32 v87, v89, v106, 0x7fff                          // 00000032D22C: D6550057 03FED559 00007FFF
	v_add3_u32 v88, v90, v107, 0x7fff                          // 00000032D238: D6550058 03FED75A 00007FFF
	.long 0x7e1e3991                                           // 00000032D244: 7E1E3991
	v_and_or_b32 v6, 0xffff0000, v6, v95                       // 00000032D248: D6570006 057E0CFF FFFF0000
	.long 0x7fc0398f                                           // 00000032D254: 7FC0398F
	v_bfe_u32 v110, v92, 16, 1                                 // 00000032D258: D610006E 0205215C
	v_bfe_u32 v111, v93, 16, 1                                 // 00000032D260: D610006F 0205215D
	v_add3_u32 v7, v7, v108, 0x7fff                            // 00000032D268: D6550007 03FED907 00007FFF
	v_add3_u32 v84, v91, v109, 0x7fff                          // 00000032D274: D6550054 03FEDB5B 00007FFF
	.long 0x7ec039d8                                           // 00000032D280: 7EC039D8
	v_and_or_b32 v17, 0xffff0000, v87, v15                     // 00000032D284: D6570011 043EAEFF FFFF0000
	v_bfe_u32 v112, v8, 16, 1                                  // 00000032D290: D6100070 02052108
	v_add3_u32 v89, v92, v110, 0x7fff                          // 00000032D298: D6550059 03FEDD5C 00007FFF
	v_add3_u32 v90, v93, v111, 0x7fff                          // 00000032D2A4: D655005A 03FEDF5D 00007FFF
	.long 0x7e1e39d4                                           // 00000032D2B0: 7E1E39D4
	v_and_or_b32 v7, 0xffff0000, v7, v96                       // 00000032D2B4: D6570007 05820EFF FFFF0000
	.long 0x7fc2398f                                           // 00000032D2C0: 7FC2398F
	v_add3_u32 v8, v8, v112, 0x7fff                            // 00000032D2C4: D6550008 03FEE108 00007FFF
	.long 0x7ec239da                                           // 00000032D2D0: 7EC239DA
	v_and_or_b32 v83, 0xffff0000, v89, v15                     // 00000032D2D4: D6570053 043EB2FF FFFF0000
	s_mov_b32 s4, exec_lo                                      // 00000032D2E0: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000032D2E4: BF870002
	v_and_or_b32 v8, 0xffff0000, v8, v97                       // 00000032D2E8: D6570008 058610FF FFFF0000
	s_waitcnt vmcnt(15)                                        // 00000032D2F4: BF893FF7
	v_dot2_f32_bf16 v18, v18, v82, 0                           // 00000032D2F8: CC1A4012 1A02A512
	s_waitcnt vmcnt(14)                                        // 00000032D300: BF893BF7
	v_dot2_f32_bf16 v22, v22, v82, 0                           // 00000032D304: CC1A4016 1A02A516
	s_waitcnt vmcnt(13)                                        // 00000032D30C: BF8937F7
	v_dot2_f32_bf16 v26, v26, v82, 0                           // 00000032D310: CC1A401A 1A02A51A
	s_waitcnt vmcnt(12)                                        // 00000032D318: BF8933F7
	v_dot2_f32_bf16 v30, v30, v82, 0                           // 00000032D31C: CC1A401E 1A02A51E
	s_waitcnt vmcnt(11)                                        // 00000032D324: BF892FF7
	v_dot2_f32_bf16 v34, v34, v82, 0                           // 00000032D328: CC1A4022 1A02A522
	s_waitcnt vmcnt(10)                                        // 00000032D330: BF892BF7
	v_dot2_f32_bf16 v38, v38, v82, 0                           // 00000032D334: CC1A4026 1A02A526
	v_dot2_f32_bf16 v18, v19, v5, v18                          // 00000032D33C: CC1A4012 1C4A0B13
	v_dot2_f32_bf16 v19, v23, v5, v22                          // 00000032D344: CC1A4013 1C5A0B17
	v_dot2_f32_bf16 v22, v27, v5, v26                          // 00000032D34C: CC1A4016 1C6A0B1B
	s_waitcnt vmcnt(9)                                         // 00000032D354: BF8927F7
	v_dot2_f32_bf16 v42, v42, v82, 0                           // 00000032D358: CC1A402A 1A02A52A
	v_dot2_f32_bf16 v27, v39, v5, v38                          // 00000032D360: CC1A401B 1C9A0B27
	v_dot2_f32_bf16 v23, v31, v5, v30                          // 00000032D368: CC1A4017 1C7A0B1F
	v_dot2_f32_bf16 v19, v24, v85, v19                         // 00000032D370: CC1A4013 1C4EAB18
	v_dot2_f32_bf16 v26, v35, v5, v34                          // 00000032D378: CC1A401A 1C8A0B23
	v_dot2_f32_bf16 v30, v43, v5, v42                          // 00000032D380: CC1A401E 1CAA0B2B
	v_dot2_f32_bf16 v24, v40, v85, v27                         // 00000032D388: CC1A4018 1C6EAB28
	s_waitcnt vmcnt(8)                                         // 00000032D390: BF8923F7
	v_dot2_f32_bf16 v27, v46, v82, 0                           // 00000032D394: CC1A401B 1A02A52E
	v_dot2_f32_bf16 v18, v20, v85, v18                         // 00000032D39C: CC1A4012 1C4AAB14
	v_dot2_f32_bf16 v20, v28, v85, v22                         // 00000032D3A4: CC1A4014 1C5AAB1C
	v_dot2_f32_bf16 v22, v32, v85, v23                         // 00000032D3AC: CC1A4016 1C5EAB20
	v_dot2_f32_bf16 v23, v36, v85, v26                         // 00000032D3B4: CC1A4017 1C6AAB24
	v_dot2_f32_bf16 v5, v47, v5, v27                           // 00000032D3BC: CC1A4005 1C6E0B2F
	v_dot2_f32_bf16 v26, v44, v85, v30                         // 00000032D3C4: CC1A401A 1C7AAB2C
	v_dot2_f32_bf16 v18, v21, v6, v18                          // 00000032D3CC: CC1A4012 1C4A0D15
	v_dot2_f32_bf16 v19, v25, v6, v19                          // 00000032D3D4: CC1A4013 1C4E0D19
	v_dot2_f32_bf16 v20, v29, v6, v20                          // 00000032D3DC: CC1A4014 1C520D1D
	v_dot2_f32_bf16 v5, v48, v85, v5                           // 00000032D3E4: CC1A4005 1C16AB30
	v_dot2_f32_bf16 v21, v33, v6, v22                          // 00000032D3EC: CC1A4015 1C5A0D21
	v_dot2_f32_bf16 v22, v37, v6, v23                          // 00000032D3F4: CC1A4016 1C5E0D25
	v_dot2_f32_bf16 v23, v41, v6, v24                          // 00000032D3FC: CC1A4017 1C620D29
	v_dot2_f32_bf16 v24, v45, v6, v26                          // 00000032D404: CC1A4018 1C6A0D2D
	s_waitcnt vmcnt(7)                                         // 00000032D40C: BF891FF7
	v_dot2_f32_bf16 v18, v50, v17, v18                         // 00000032D410: CC1A4012 1C4A2332
	v_dot2_f32_bf16 v5, v49, v6, v5                            // 00000032D418: CC1A4005 1C160D31
	s_waitcnt vmcnt(6)                                         // 00000032D420: BF891BF7
	v_dot2_f32_bf16 v19, v54, v17, v19                         // 00000032D424: CC1A4013 1C4E2336
	s_waitcnt vmcnt(5)                                         // 00000032D42C: BF8917F7
	v_dot2_f32_bf16 v20, v58, v17, v20                         // 00000032D430: CC1A4014 1C52233A
	s_waitcnt vmcnt(4)                                         // 00000032D438: BF8913F7
	v_dot2_f32_bf16 v21, v62, v17, v21                         // 00000032D43C: CC1A4015 1C56233E
	s_waitcnt vmcnt(3)                                         // 00000032D444: BF890FF7
	v_dot2_f32_bf16 v22, v66, v17, v22                         // 00000032D448: CC1A4016 1C5A2342
	s_waitcnt vmcnt(2)                                         // 00000032D450: BF890BF7
	v_dot2_f32_bf16 v23, v70, v17, v23                         // 00000032D454: CC1A4017 1C5E2346
	s_waitcnt vmcnt(1)                                         // 00000032D45C: BF8907F7
	v_dot2_f32_bf16 v24, v74, v17, v24                         // 00000032D460: CC1A4018 1C62234A
	v_dot2_f32_bf16 v18, v51, v7, v18                          // 00000032D468: CC1A4012 1C4A0F33
	s_waitcnt vmcnt(0)                                         // 00000032D470: BF8903F7
	v_dot2_f32_bf16 v5, v78, v17, v5                           // 00000032D474: CC1A4005 1C16234E
	v_dot2_f32_bf16 v19, v55, v7, v19                          // 00000032D47C: CC1A4013 1C4E0F37
	v_dot2_f32_bf16 v20, v59, v7, v20                          // 00000032D484: CC1A4014 1C520F3B
	v_dot2_f32_bf16 v21, v63, v7, v21                          // 00000032D48C: CC1A4015 1C560F3F
	v_dot2_f32_bf16 v22, v67, v7, v22                          // 00000032D494: CC1A4016 1C5A0F43
	v_dot2_f32_bf16 v23, v71, v7, v23                          // 00000032D49C: CC1A4017 1C5E0F47
	v_dot2_f32_bf16 v24, v75, v7, v24                          // 00000032D4A4: CC1A4018 1C620F4B
	v_dot2_f32_bf16 v6, v52, v83, v18                          // 00000032D4AC: CC1A4006 1C4AA734
	v_dot2_f32_bf16 v5, v79, v7, v5                            // 00000032D4B4: CC1A4005 1C160F4F
	v_dot2_f32_bf16 v18, v56, v83, v19                         // 00000032D4BC: CC1A4012 1C4EA738
	v_dot2_f32_bf16 v19, v60, v83, v20                         // 00000032D4C4: CC1A4013 1C52A73C
	v_dot2_f32_bf16 v20, v64, v83, v21                         // 00000032D4CC: CC1A4014 1C56A740
	v_dot2_f32_bf16 v21, v68, v83, v22                         // 00000032D4D4: CC1A4015 1C5AA744
	v_dot2_f32_bf16 v17, v72, v83, v23                         // 00000032D4DC: CC1A4011 1C5EA748
	v_dot2_f32_bf16 v22, v76, v83, v24                         // 00000032D4E4: CC1A4016 1C62A74C
	v_dot2_f32_bf16 v6, v53, v8, v6                            // 00000032D4EC: CC1A4006 1C1A1135
	v_dot2_f32_bf16 v5, v80, v83, v5                           // 00000032D4F4: CC1A4005 1C16A750
	v_dot2_f32_bf16 v18, v57, v8, v18                          // 00000032D4FC: CC1A4012 1C4A1139
	v_dot2_f32_bf16 v7, v61, v8, v19                           // 00000032D504: CC1A4007 1C4E113D
	v_dot2_f32_bf16 v23, v65, v8, v20                          // 00000032D50C: CC1A4017 1C521141
	v_dot2_f32_bf16 v21, v69, v8, v21                          // 00000032D514: CC1A4015 1C561145
	v_dot2_f32_bf16 v24, v73, v8, v17                          // 00000032D51C: CC1A4018 1C461149
	v_dot2_f32_bf16 v22, v77, v8, v22                          // 00000032D524: CC1A4016 1C5A114D
	v_add_f32_e32 v19, 0, v6                                   // 00000032D52C: 06260C80
	v_dot2_f32_bf16 v6, v81, v8, v5                            // 00000032D530: CC1A4006 1C161151
	v_dual_add_f32 v20, 0, v18 :: v_dual_add_f32 v17, 0, v7    // 00000032D538: C9082480 14100E80
	v_add_f32_e32 v8, 0, v24                                   // 00000032D540: 06103080
	v_dual_add_f32 v18, 0, v23 :: v_dual_add_f32 v7, 0, v21    // 00000032D544: C9082E80 12062A80
	s_delay_alu instid0(VALU_DEP_4)                            // 00000032D54C: BF870004
	v_add_f32_e32 v6, 0, v6                                    // 00000032D550: 060C0C80
	v_add_f32_e32 v5, 0, v22                                   // 00000032D554: 060A2C80
	v_cmpx_gt_u32_e32 20, v16                                  // 00000032D558: 7D982094
	s_cbranch_execz 358                                        // 00000032D55C: BFA50166 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0xcf8>
	s_clause 0x6                                               // 00000032D560: BF850006
	global_load_b128 v[21:24], v[9:10], off offset:512         // 00000032D564: DC5E0200 157C0009
	global_load_b128 v[25:28], v[9:10], off offset:1152        // 00000032D56C: DC5E0480 197C0009
	global_load_b128 v[29:32], v[9:10], off offset:1792        // 00000032D574: DC5E0700 1D7C0009
	global_load_b128 v[33:36], v[9:10], off offset:2432        // 00000032D57C: DC5E0980 217C0009
	global_load_b128 v[37:40], v[9:10], off offset:3072        // 00000032D584: DC5E0C00 257C0009
	global_load_b128 v[41:44], v[9:10], off offset:3712        // 00000032D58C: DC5E0E80 297C0009
	global_load_b128 v[45:48], v[11:12], off offset:896        // 00000032D594: DC5E0380 2D7C000B
	.long 0xd7006a4d                                           // 00000032D59C: D7006A4D
	v_cndmask_b32_e32 v1, 0x200, v9, vcc_lo                    // 00000032D5A0: 020212FF 00000200
	s_delay_alu instid0(VALU_DEP_1)                            // 00000032D5A8: BF870001
	v_add_co_ci_u32_e64 v78, null, 0, v10, vcc_lo              // 00000032D5AC: D5207C4E 01AA1480
	v_cvt_f32_ubyte0_e32 v16, v1                               // 00000032D5B4: 7E202301
	v_cvt_f32_ubyte1_e32 v81, v1                               // 00000032D5B8: 7EA22501
	s_clause 0x8                                               // 00000032D5BC: BF850008
	global_load_b128 v[49:52], v[77:78], off offset:3840       // 00000032D5C0: DC5E0F00 317C004D
	global_load_b128 v[53:56], v[9:10], off offset:528         // 00000032D5C8: DC5E0210 357C0009
	global_load_b128 v[57:60], v[9:10], off offset:1168        // 00000032D5D0: DC5E0490 397C0009
	global_load_b128 v[61:64], v[9:10], off offset:1808        // 00000032D5D8: DC5E0710 3D7C0009
	global_load_b128 v[65:68], v[9:10], off offset:2448        // 00000032D5E0: DC5E0990 417C0009
	global_load_b128 v[69:72], v[9:10], off offset:3088        // 00000032D5E8: DC5E0C10 457C0009
	global_load_b128 v[73:76], v[9:10], off offset:3728        // 00000032D5F0: DC5E0E90 497C0009
	global_load_b128 v[9:12], v[11:12], off offset:912         // 00000032D5F8: DC5E0390 097C000B
	global_load_b128 v[77:80], v[77:78], off offset:3856       // 00000032D600: DC5E0F10 4D7C004D
	v_cvt_f32_ubyte2_e32 v82, v1                               // 00000032D608: 7EA42701
	v_cvt_f32_ubyte3_e32 v1, v1                                // 00000032D60C: 7E022901
	v_cvt_f32_ubyte0_e32 v84, v2                               // 00000032D610: 7EA82302
	v_cvt_f32_ubyte1_e32 v85, v2                               // 00000032D614: 7EAA2502
	v_cvt_f32_ubyte2_e32 v86, v2                               // 00000032D618: 7EAC2702
	v_cvt_f32_ubyte3_e32 v2, v2                                // 00000032D61C: 7E042902
	v_cvt_f32_ubyte0_e32 v88, v3                               // 00000032D620: 7EB02303
	v_cvt_f32_ubyte1_e32 v89, v3                               // 00000032D624: 7EB22503
	v_cvt_f32_ubyte2_e32 v90, v3                               // 00000032D628: 7EB42703
	v_cvt_f32_ubyte3_e32 v3, v3                                // 00000032D62C: 7E062903
	v_cvt_f32_ubyte0_e32 v92, v4                               // 00000032D630: 7EB82304
	v_cvt_f32_ubyte1_e32 v93, v4                               // 00000032D634: 7EBA2504
	v_cvt_f32_ubyte2_e32 v94, v4                               // 00000032D638: 7EBC2704
	v_cvt_f32_ubyte3_e32 v4, v4                                // 00000032D63C: 7E082904
	v_fma_mix_f32 v16, v16, v14, v14 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032D640: CC206010 143A1D10
	v_fma_mix_f32 v81, v81, v14, v14 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032D648: CC206051 143A1D51
	v_fma_mix_f32 v82, v82, v14, v14 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032D650: CC206052 143A1D52
	v_fma_mix_f32 v1, v1, v14, v14 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032D658: CC206001 143A1D01
	v_fma_mix_f32 v84, v84, v14, v14 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032D660: CC206054 143A1D54
	v_fma_mix_f32 v85, v85, v14, v14 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032D668: CC206055 143A1D55
	v_fma_mix_f32 v86, v86, v14, v14 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032D670: CC206056 143A1D56
	v_fma_mix_f32 v2, v2, v14, v14 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032D678: CC206002 143A1D02
	v_fma_mix_f32 v88, v88, v14, v14 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032D680: CC206058 143A1D58
	v_fma_mix_f32 v89, v89, v14, v14 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032D688: CC206059 143A1D59
	v_fma_mix_f32 v90, v90, v14, v14 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032D690: CC20605A 143A1D5A
	v_fma_mix_f32 v3, v3, v14, v14 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032D698: CC206003 143A1D03
	v_fma_mix_f32 v92, v92, v14, v14 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032D6A0: CC20605C 143A1D5C
	v_fma_mix_f32 v93, v93, v14, v14 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032D6A8: CC20605D 143A1D5D
	v_fma_mix_f32 v94, v94, v14, v14 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032D6B0: CC20605E 143A1D5E
	v_fma_mix_f32 v4, v4, v14, v14 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032D6B8: CC206004 143A1D04
	v_bfe_u32 v14, v16, 16, 1                                  // 00000032D6C0: D610000E 02052110
	v_bfe_u32 v96, v81, 16, 1                                  // 00000032D6C8: D6100060 02052151
	v_bfe_u32 v97, v82, 16, 1                                  // 00000032D6D0: D6100061 02052152
	v_bfe_u32 v98, v1, 16, 1                                   // 00000032D6D8: D6100062 02052101
	v_bfe_u32 v99, v84, 16, 1                                  // 00000032D6E0: D6100063 02052154
	v_add3_u32 v14, v16, v14, 0x7fff                           // 00000032D6E8: D655000E 03FE1D10 00007FFF
	v_add3_u32 v16, v81, v96, 0x7fff                           // 00000032D6F4: D6550010 03FEC151 00007FFF
	v_add3_u32 v81, v82, v97, 0x7fff                           // 00000032D700: D6550051 03FEC352 00007FFF
	.long 0x7fa6398f                                           // 00000032D70C: 7FA6398F
	v_bfe_u32 v100, v85, 16, 1                                 // 00000032D710: D6100064 02052155
	.long 0x7e1e398e                                           // 00000032D718: 7E1E398E
	v_bfe_u32 v101, v86, 16, 1                                 // 00000032D71C: D6100065 02052156
	v_add3_u32 v1, v1, v98, 0x7fff                             // 00000032D724: D6550001 03FEC501 00007FFF
	v_add3_u32 v82, v84, v99, 0x7fff                           // 00000032D730: D6550052 03FEC754 00007FFF
	.long 0x7ea639d1                                           // 00000032D73C: 7EA639D1
	v_and_or_b32 v16, 0xffff0000, v16, v15                     // 00000032D740: D6570010 043E20FF FFFF0000
	v_bfe_u32 v102, v2, 16, 1                                  // 00000032D74C: D6100066 02052102
	v_bfe_u32 v103, v88, 16, 1                                 // 00000032D754: D6100067 02052158
	v_add3_u32 v84, v85, v100, 0x7fff                          // 00000032D75C: D6550054 03FEC955 00007FFF
	v_add3_u32 v85, v86, v101, 0x7fff                          // 00000032D768: D6550055 03FECB56 00007FFF
	.long 0x7e1e39d2                                           // 00000032D774: 7E1E39D2
	v_and_or_b32 v1, 0xffff0000, v1, v83                       // 00000032D778: D6570001 054E02FF FFFF0000
	.long 0x7fae398f                                           // 00000032D784: 7FAE398F
	v_bfe_u32 v104, v89, 16, 1                                 // 00000032D788: D6100068 02052159
	v_bfe_u32 v105, v90, 16, 1                                 // 00000032D790: D6100069 0205215A
	v_add3_u32 v2, v2, v102, 0x7fff                            // 00000032D798: D6550002 03FECD02 00007FFF
	v_add3_u32 v14, v88, v103, 0x7fff                          // 00000032D7A4: D655000E 03FECF58 00007FFF
	v_and_or_b32 v84, 0xffff0000, v84, v15                     // 00000032D7B0: D6570054 043EA8FF FFFF0000
	.long 0x7eae39d5                                           // 00000032D7BC: 7EAE39D5
	v_bfe_u32 v106, v3, 16, 1                                  // 00000032D7C0: D610006A 02052103
	v_bfe_u32 v107, v92, 16, 1                                 // 00000032D7C8: D610006B 0205215C
	v_add3_u32 v86, v89, v104, 0x7fff                          // 00000032D7D0: D6550056 03FED159 00007FFF
	v_add3_u32 v88, v90, v105, 0x7fff                          // 00000032D7DC: D6550058 03FED35A 00007FFF
	.long 0x7e1e398e                                           // 00000032D7E8: 7E1E398E
	v_and_or_b32 v2, 0xffff0000, v2, v87                       // 00000032D7EC: D6570002 055E04FF FFFF0000
	.long 0x7fb6398f                                           // 00000032D7F8: 7FB6398F
	v_bfe_u32 v108, v93, 16, 1                                 // 00000032D7FC: D610006C 0205215D
	v_bfe_u32 v109, v94, 16, 1                                 // 00000032D804: D610006D 0205215E
	v_add3_u32 v3, v3, v106, 0x7fff                            // 00000032D80C: D6550003 03FED503 00007FFF
	v_add3_u32 v82, v92, v107, 0x7fff                          // 00000032D818: D6550052 03FED75C 00007FFF
	.long 0x7eb639d8                                           // 00000032D824: 7EB639D8
	v_and_or_b32 v14, 0xffff0000, v86, v15                     // 00000032D828: D657000E 043EACFF FFFF0000
	v_bfe_u32 v110, v4, 16, 1                                  // 00000032D834: D610006E 02052104
	v_add3_u32 v89, v93, v108, 0x7fff                          // 00000032D83C: D6550059 03FED95D 00007FFF
	v_add3_u32 v90, v94, v109, 0x7fff                          // 00000032D848: D655005A 03FEDB5E 00007FFF
	.long 0x7e1e39d2                                           // 00000032D854: 7E1E39D2
	v_and_or_b32 v3, 0xffff0000, v3, v91                       // 00000032D858: D6570003 056E06FF FFFF0000
	.long 0x7fbe398f                                           // 00000032D864: 7FBE398F
	v_add3_u32 v4, v4, v110, 0x7fff                            // 00000032D868: D6550004 03FEDD04 00007FFF
	.long 0x7ebe39da                                           // 00000032D874: 7EBE39DA
	v_and_or_b32 v15, 0xffff0000, v89, v15                     // 00000032D878: D657000F 043EB2FF FFFF0000
	s_delay_alu instid0(VALU_DEP_2)                            // 00000032D884: BF870002
	v_and_or_b32 v4, 0xffff0000, v4, v95                       // 00000032D888: D6570004 057E08FF FFFF0000
	s_waitcnt vmcnt(15)                                        // 00000032D894: BF893FF7
	v_dot2_f32_bf16 v21, v21, v16, 0                           // 00000032D898: CC1A4015 1A022115
	s_waitcnt vmcnt(14)                                        // 00000032D8A0: BF893BF7
	v_dot2_f32_bf16 v25, v25, v16, 0                           // 00000032D8A4: CC1A4019 1A022119
	s_waitcnt vmcnt(13)                                        // 00000032D8AC: BF8937F7
	v_dot2_f32_bf16 v29, v29, v16, 0                           // 00000032D8B0: CC1A401D 1A02211D
	s_waitcnt vmcnt(12)                                        // 00000032D8B8: BF8933F7
	v_dot2_f32_bf16 v33, v33, v16, 0                           // 00000032D8BC: CC1A4021 1A022121
	s_waitcnt vmcnt(11)                                        // 00000032D8C4: BF892FF7
	v_dot2_f32_bf16 v37, v37, v16, 0                           // 00000032D8C8: CC1A4025 1A022125
	s_waitcnt vmcnt(10)                                        // 00000032D8D0: BF892BF7
	v_dot2_f32_bf16 v41, v41, v16, 0                           // 00000032D8D4: CC1A4029 1A022129
	s_waitcnt vmcnt(9)                                         // 00000032D8DC: BF8927F7
	v_dot2_f32_bf16 v45, v45, v16, 0                           // 00000032D8E0: CC1A402D 1A02212D
	s_waitcnt vmcnt(8)                                         // 00000032D8E8: BF8923F7
	v_dot2_f32_bf16 v16, v49, v16, 0                           // 00000032D8EC: CC1A4010 1A022131
	v_dot2_f32_bf16 v21, v22, v1, v21                          // 00000032D8F4: CC1A4015 1C560316
	v_dot2_f32_bf16 v22, v26, v1, v25                          // 00000032D8FC: CC1A4016 1C66031A
	v_dot2_f32_bf16 v25, v30, v1, v29                          // 00000032D904: CC1A4019 1C76031E
	v_dot2_f32_bf16 v26, v34, v1, v33                          // 00000032D90C: CC1A401A 1C860322
	v_dot2_f32_bf16 v29, v38, v1, v37                          // 00000032D914: CC1A401D 1C960326
	v_dot2_f32_bf16 v30, v42, v1, v41                          // 00000032D91C: CC1A401E 1CA6032A
	v_dot2_f32_bf16 v33, v46, v1, v45                          // 00000032D924: CC1A4021 1CB6032E
	v_dot2_f32_bf16 v1, v50, v1, v16                           // 00000032D92C: CC1A4001 1C420332
	v_dot2_f32_bf16 v21, v23, v84, v21                         // 00000032D934: CC1A4015 1C56A917
	v_dot2_f32_bf16 v22, v27, v84, v22                         // 00000032D93C: CC1A4016 1C5AA91B
	v_dot2_f32_bf16 v23, v31, v84, v25                         // 00000032D944: CC1A4017 1C66A91F
	v_dot2_f32_bf16 v25, v35, v84, v26                         // 00000032D94C: CC1A4019 1C6AA923
	v_dot2_f32_bf16 v26, v39, v84, v29                         // 00000032D954: CC1A401A 1C76A927
	v_dot2_f32_bf16 v27, v43, v84, v30                         // 00000032D95C: CC1A401B 1C7AA92B
	v_dot2_f32_bf16 v16, v47, v84, v33                         // 00000032D964: CC1A4010 1C86A92F
	v_dot2_f32_bf16 v1, v51, v84, v1                           // 00000032D96C: CC1A4001 1C06A933
	v_dot2_f32_bf16 v21, v24, v2, v21                          // 00000032D974: CC1A4015 1C560518
	v_dot2_f32_bf16 v22, v28, v2, v22                          // 00000032D97C: CC1A4016 1C5A051C
	v_dot2_f32_bf16 v23, v32, v2, v23                          // 00000032D984: CC1A4017 1C5E0520
	v_dot2_f32_bf16 v24, v36, v2, v25                          // 00000032D98C: CC1A4018 1C660524
	v_dot2_f32_bf16 v25, v40, v2, v26                          // 00000032D994: CC1A4019 1C6A0528
	v_dot2_f32_bf16 v26, v44, v2, v27                          // 00000032D99C: CC1A401A 1C6E052C
	v_dot2_f32_bf16 v16, v48, v2, v16                          // 00000032D9A4: CC1A4010 1C420530
	v_dot2_f32_bf16 v1, v52, v2, v1                            // 00000032D9AC: CC1A4001 1C060534
	s_waitcnt vmcnt(7)                                         // 00000032D9B4: BF891FF7
	v_dot2_f32_bf16 v21, v53, v14, v21                         // 00000032D9B8: CC1A4015 1C561D35
	s_waitcnt vmcnt(6)                                         // 00000032D9C0: BF891BF7
	v_dot2_f32_bf16 v22, v57, v14, v22                         // 00000032D9C4: CC1A4016 1C5A1D39
	s_waitcnt vmcnt(5)                                         // 00000032D9CC: BF8917F7
	v_dot2_f32_bf16 v23, v61, v14, v23                         // 00000032D9D0: CC1A4017 1C5E1D3D
	s_waitcnt vmcnt(4)                                         // 00000032D9D8: BF8913F7
	v_dot2_f32_bf16 v24, v65, v14, v24                         // 00000032D9DC: CC1A4018 1C621D41
	s_waitcnt vmcnt(3)                                         // 00000032D9E4: BF890FF7
	v_dot2_f32_bf16 v25, v69, v14, v25                         // 00000032D9E8: CC1A4019 1C661D45
	s_waitcnt vmcnt(2)                                         // 00000032D9F0: BF890BF7
	v_dot2_f32_bf16 v26, v73, v14, v26                         // 00000032D9F4: CC1A401A 1C6A1D49
	s_waitcnt vmcnt(1)                                         // 00000032D9FC: BF8907F7
	v_dot2_f32_bf16 v2, v9, v14, v16                           // 00000032DA00: CC1A4002 1C421D09
	s_waitcnt vmcnt(0)                                         // 00000032DA08: BF8903F7
	v_dot2_f32_bf16 v1, v77, v14, v1                           // 00000032DA0C: CC1A4001 1C061D4D
	v_dot2_f32_bf16 v9, v54, v3, v21                           // 00000032DA14: CC1A4009 1C560736
	v_dot2_f32_bf16 v16, v58, v3, v22                          // 00000032DA1C: CC1A4010 1C5A073A
	v_dot2_f32_bf16 v21, v62, v3, v23                          // 00000032DA24: CC1A4015 1C5E073E
	v_dot2_f32_bf16 v22, v66, v3, v24                          // 00000032DA2C: CC1A4016 1C620742
	v_dot2_f32_bf16 v23, v70, v3, v25                          // 00000032DA34: CC1A4017 1C660746
	v_dot2_f32_bf16 v24, v74, v3, v26                          // 00000032DA3C: CC1A4018 1C6A074A
	v_dot2_f32_bf16 v2, v10, v3, v2                            // 00000032DA44: CC1A4002 1C0A070A
	v_dot2_f32_bf16 v1, v78, v3, v1                            // 00000032DA4C: CC1A4001 1C06074E
	v_dot2_f32_bf16 v9, v55, v15, v9                           // 00000032DA54: CC1A4009 1C261F37
	v_dot2_f32_bf16 v10, v59, v15, v16                         // 00000032DA5C: CC1A400A 1C421F3B
	v_dot2_f32_bf16 v14, v63, v15, v21                         // 00000032DA64: CC1A400E 1C561F3F
	v_dot2_f32_bf16 v16, v67, v15, v22                         // 00000032DA6C: CC1A4010 1C5A1F43
	v_dot2_f32_bf16 v21, v71, v15, v23                         // 00000032DA74: CC1A4015 1C5E1F47
	v_dot2_f32_bf16 v22, v75, v15, v24                         // 00000032DA7C: CC1A4016 1C621F4B
	v_dot2_f32_bf16 v2, v11, v15, v2                           // 00000032DA84: CC1A4002 1C0A1F0B
	v_dot2_f32_bf16 v1, v79, v15, v1                           // 00000032DA8C: CC1A4001 1C061F4F
	v_dot2_f32_bf16 v3, v56, v4, v9                            // 00000032DA94: CC1A4003 1C260938
	v_dot2_f32_bf16 v9, v60, v4, v10                           // 00000032DA9C: CC1A4009 1C2A093C
	v_dot2_f32_bf16 v10, v64, v4, v14                          // 00000032DAA4: CC1A400A 1C3A0940
	v_dot2_f32_bf16 v11, v68, v4, v16                          // 00000032DAAC: CC1A400B 1C420944
	v_dot2_f32_bf16 v14, v72, v4, v21                          // 00000032DAB4: CC1A400E 1C560948
	v_dot2_f32_bf16 v15, v76, v4, v22                          // 00000032DABC: CC1A400F 1C5A094C
	v_dot2_f32_bf16 v2, v12, v4, v2                            // 00000032DAC4: CC1A4002 1C0A090C
	v_dot2_f32_bf16 v1, v80, v4, v1                            // 00000032DACC: CC1A4001 1C060950
	v_dual_add_f32 v19, v19, v3 :: v_dual_add_f32 v20, v20, v9 // 00000032DAD4: C9080713 13141314
	v_dual_add_f32 v17, v17, v10 :: v_dual_add_f32 v18, v18, v11// 00000032DADC: C9081511 11121712
	v_dual_add_f32 v7, v7, v14 :: v_dual_add_f32 v8, v8, v15   // 00000032DAE4: C9081D07 07081F08
	s_delay_alu instid0(VALU_DEP_4)                            // 00000032DAEC: BF870004
	v_dual_add_f32 v5, v5, v1 :: v_dual_add_f32 v6, v6, v2     // 00000032DAF0: C9080305 05060506
	s_or_b32 exec_lo, exec_lo, s4                              // 00000032DAF8: 8C7E047E
	.long 0xd71f0001                                           // 00000032DAFC: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000032DB00: 020100C1
	s_mov_b32 s4, exec_lo                                      // 00000032DB04: BE84007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000032DB08: BF870121
	v_xor_b32_e32 v2, 8, v1                                    // 00000032DB0C: 3A040288
	v_xor_b32_e32 v15, 4, v1                                   // 00000032DB10: 3A1E0284
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 00000032DB14: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 00000032DB18: 02040501
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000032DB1C: BF8700A3
	v_cmp_gt_u32_e32 vcc_lo, 32, v15                           // 00000032DB20: 7C981EA0
	v_cndmask_b32_e32 v15, v1, v15, vcc_lo                     // 00000032DB24: 021E1F01
	v_lshlrev_b32_e32 v15, 2, v15                              // 00000032DB28: 301E1E82
	s_delay_alu instid0(VALU_DEP_4)                            // 00000032DB2C: BF870004
	v_lshlrev_b32_e32 v2, 2, v2                                // 00000032DB30: 30040482
	ds_bpermute_b32 v3, v2, v20                                // 00000032DB34: DACC0000 03001402
	s_waitcnt lgkmcnt(0)                                       // 00000032DB3C: BF89FC07
	v_add_f32_e32 v3, v20, v3                                  // 00000032DB40: 06060714
	ds_bpermute_b32 v4, v2, v19                                // 00000032DB44: DACC0000 04001302
	ds_bpermute_b32 v11, v2, v8                                // 00000032DB4C: DACC0000 0B000802
	ds_bpermute_b32 v9, v2, v18                                // 00000032DB54: DACC0000 09001202
	ds_bpermute_b32 v10, v2, v17                               // 00000032DB5C: DACC0000 0A001102
	ds_bpermute_b32 v12, v2, v7                                // 00000032DB64: DACC0000 0C000702
	ds_bpermute_b32 v14, v2, v6                                // 00000032DB6C: DACC0000 0E000602
	ds_bpermute_b32 v2, v2, v5                                 // 00000032DB74: DACC0000 02000502
	s_waitcnt lgkmcnt(6)                                       // 00000032DB7C: BF89FC67
	v_add_f32_e32 v4, v19, v4                                  // 00000032DB80: 06080913
	v_xor_b32_e32 v19, 2, v1                                   // 00000032DB84: 3A260282
	s_waitcnt lgkmcnt(4)                                       // 00000032DB88: BF89FC47
	v_dual_add_f32 v8, v8, v11 :: v_dual_add_f32 v9, v18, v9   // 00000032DB8C: C9081708 08081312
	s_waitcnt lgkmcnt(2)                                       // 00000032DB94: BF89FC27
	v_dual_add_f32 v10, v17, v10 :: v_dual_add_f32 v7, v7, v12 // 00000032DB98: C9081511 0A061907
	v_cmp_gt_u32_e32 vcc_lo, 32, v19                           // 00000032DBA0: 7C9826A0
	s_waitcnt lgkmcnt(1)                                       // 00000032DBA4: BF89FC17
	v_add_f32_e32 v6, v6, v14                                  // 00000032DBA8: 060C1D06
	ds_bpermute_b32 v16, v15, v8                               // 00000032DBAC: DACC0000 1000080F
	ds_bpermute_b32 v11, v15, v4                               // 00000032DBB4: DACC0000 0B00040F
	ds_bpermute_b32 v17, v15, v7                               // 00000032DBBC: DACC0000 1100070F
	v_cndmask_b32_e32 v19, v1, v19, vcc_lo                     // 00000032DBC4: 02262701
	s_waitcnt lgkmcnt(3)                                       // 00000032DBC8: BF89FC37
	v_add_f32_e32 v2, v5, v2                                   // 00000032DBCC: 06040505
	ds_bpermute_b32 v5, v15, v3                                // 00000032DBD0: DACC0000 0500030F
	ds_bpermute_b32 v18, v15, v6                               // 00000032DBD8: DACC0000 1200060F
	ds_bpermute_b32 v12, v15, v9                               // 00000032DBE0: DACC0000 0C00090F
	ds_bpermute_b32 v14, v15, v10                              // 00000032DBE8: DACC0000 0E000A0F
	v_lshlrev_b32_e32 v19, 2, v19                              // 00000032DBF0: 30262682
	ds_bpermute_b32 v15, v15, v2                               // 00000032DBF4: DACC0000 0F00020F
	s_waitcnt lgkmcnt(7)                                       // 00000032DBFC: BF89FC77
	v_add_f32_e32 v8, v8, v16                                  // 00000032DC00: 06102108
	s_waitcnt lgkmcnt(5)                                       // 00000032DC04: BF89FC57
	v_dual_add_f32 v4, v4, v11 :: v_dual_add_f32 v7, v7, v17   // 00000032DC08: C9081704 04062307
	s_waitcnt lgkmcnt(4)                                       // 00000032DC10: BF89FC47
	v_add_f32_e32 v3, v3, v5                                   // 00000032DC14: 06060B03
	ds_bpermute_b32 v17, v19, v8                               // 00000032DC18: DACC0000 11000813
	s_waitcnt lgkmcnt(4)                                       // 00000032DC20: BF89FC47
	v_add_f32_e32 v11, v6, v18                                 // 00000032DC24: 06162506
	s_waitcnt lgkmcnt(2)                                       // 00000032DC28: BF89FC27
	v_dual_add_f32 v5, v9, v12 :: v_dual_add_f32 v10, v10, v14 // 00000032DC2C: C9081909 050A1D0A
	ds_bpermute_b32 v6, v19, v3                                // 00000032DC34: DACC0000 06000313
	v_xor_b32_e32 v14, 1, v1                                   // 00000032DC3C: 3A1C0281
	ds_bpermute_b32 v9, v19, v4                                // 00000032DC40: DACC0000 09000413
	ds_bpermute_b32 v12, v19, v5                               // 00000032DC48: DACC0000 0C000513
	ds_bpermute_b32 v16, v19, v10                              // 00000032DC50: DACC0000 10000A13
	ds_bpermute_b32 v18, v19, v7                               // 00000032DC58: DACC0000 12000713
	v_cmp_gt_u32_e32 vcc_lo, 32, v14                           // 00000032DC60: 7C981CA0
	s_waitcnt lgkmcnt(6)                                       // 00000032DC64: BF89FC67
	v_dual_add_f32 v2, v2, v15 :: v_dual_cndmask_b32 v1, v1, v14// 00000032DC68: C9121F02 02001D01
	s_waitcnt lgkmcnt(4)                                       // 00000032DC70: BF89FC47
	s_delay_alu instid0(VALU_DEP_1)                            // 00000032DC74: BF870001
	v_dual_add_f32 v14, v3, v6 :: v_dual_lshlrev_b32 v21, 2, v1// 00000032DC78: C9220D03 0E140282
	v_add_f32_e32 v6, v8, v17                                  // 00000032DC80: 060C2308
	ds_bpermute_b32 v20, v19, v11                              // 00000032DC84: DACC0000 14000B13
	ds_bpermute_b32 v19, v19, v2                               // 00000032DC8C: DACC0000 13000213
	s_waitcnt lgkmcnt(3)                                       // 00000032DC94: BF89FC37
	v_dual_add_f32 v15, v4, v9 :: v_dual_add_f32 v10, v10, v16 // 00000032DC98: C9081304 0F0A210A
	v_add_f32_e32 v9, v5, v12                                  // 00000032DCA0: 06121905
	s_waitcnt lgkmcnt(2)                                       // 00000032DCA4: BF89FC27
	v_add_f32_e32 v5, v7, v18                                  // 00000032DCA8: 060A2507
	ds_bpermute_b32 v16, v21, v14                              // 00000032DCAC: DACC0000 10000E15
	ds_bpermute_b32 v17, v21, v15                              // 00000032DCB4: DACC0000 11000F15
	ds_bpermute_b32 v8, v21, v6                                // 00000032DCBC: DACC0000 08000615
	ds_bpermute_b32 v7, v21, v5                                // 00000032DCC4: DACC0000 07000515
	s_waitcnt lgkmcnt(4)                                       // 00000032DCCC: BF89FC47
	v_dual_add_f32 v1, v11, v20 :: v_dual_add_f32 v2, v2, v19  // 00000032DCD0: C908290B 01022702
	ds_bpermute_b32 v11, v21, v10                              // 00000032DCD8: DACC0000 0B000A15
	ds_bpermute_b32 v12, v21, v9                               // 00000032DCE0: DACC0000 0C000915
	ds_bpermute_b32 v3, v21, v1                                // 00000032DCE8: DACC0000 03000115
	ds_bpermute_b32 v4, v21, v2                                // 00000032DCF0: DACC0000 04000215
	v_cmpx_eq_u32_e32 0, v13                                   // 00000032DCF8: 7D941A80
	s_cbranch_execz 65                                         // 00000032DCFC: BFA50041 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x1004>
	s_waitcnt lgkmcnt(6)                                       // 00000032DD00: BF89FC67
	v_dual_add_f32 v13, v15, v17 :: v_dual_add_f32 v14, v14, v16// 00000032DD04: C908230F 0D0E210E
	.long 0x7f1e3880                                           // 00000032DD0C: 7F1E3880
	s_waitcnt lgkmcnt(2)                                       // 00000032DD10: BF89FC27
	v_dual_add_f32 v10, v10, v11 :: v_dual_add_f32 v9, v9, v12 // 00000032DD14: C908170A 0A081909
	s_delay_alu instid0(VALU_DEP_3)                            // 00000032DD1C: BF870003
	.long 0x7e20398d                                           // 00000032DD20: 7E20398D
	.long 0x7e1e398e                                           // 00000032DD24: 7E1E398E
	.long 0x7f20398f                                           // 00000032DD28: 7F20398F
	v_lshrrev_b32_e32 v17, 4, v0                               // 00000032DD2C: 32220084
	v_dual_add_f32 v6, v6, v8 :: v_dual_add_f32 v5, v5, v7     // 00000032DD30: C9081106 06040F05
	s_waitcnt lgkmcnt(0)                                       // 00000032DD38: BF89FC07
	v_add_f32_e32 v2, v2, v4                                   // 00000032DD3C: 06040902
	v_and_b32_e32 v8, 1, v16                                   // 00000032DD40: 36102081
	v_and_b32_e32 v16, 1, v15                                  // 00000032DD44: 36201E81
	.long 0x7e1e3989                                           // 00000032DD48: 7E1E3989
	v_lshlrev_b32_e32 v11, 4, v17                              // 00000032DD4C: 30162284
	.long 0x7e18398a                                           // 00000032DD50: 7E18398A
	v_add3_u32 v8, v13, v8, 0x7fff                             // 00000032DD54: D6550008 03FE110D 00007FFF
	.long 0x7f18398f                                           // 00000032DD60: 7F18398F
	v_and_b32_e32 v4, 1, v15                                   // 00000032DD64: 36081E81
	.long 0x7e1e3986                                           // 00000032DD68: 7E1E3986
	v_add_f32_e32 v13, v1, v3                                  // 00000032DD6C: 061A0701
	.long 0x7e0e3985                                           // 00000032DD70: 7E0E3985
	.long 0x7e023982                                           // 00000032DD74: 7E023982
	.long 0x7f02398f                                           // 00000032DD78: 7F02398F
	.long 0x7f0e398f                                           // 00000032DD7C: 7F0E398F
	v_and_b32_e32 v3, 1, v12                                   // 00000032DD80: 36061881
	v_and_b32_e32 v12, 1, v15                                  // 00000032DD84: 36181E81
	.long 0x7e1e398d                                           // 00000032DD88: 7E1E398D
	v_and_b32_e32 v17, 1, v1                                   // 00000032DD8C: 36220281
	v_and_b32_e32 v7, 1, v7                                    // 00000032DD90: 360E0E81
	v_add3_u32 v1, v14, v16, 0x7fff                            // 00000032DD94: D6550001 03FE210E 00007FFF
	v_add3_u32 v10, v10, v3, 0x7fff                            // 00000032DDA0: D655000A 03FE070A 00007FFF
	v_and_b32_e32 v14, 1, v15                                  // 00000032DDAC: 361C1E81
	v_add3_u32 v15, v2, v17, 0x7fff                            // 00000032DDB0: D655000F 03FE2302 00007FFF
	v_add3_u32 v5, v5, v7, 0x7fff                              // 00000032DDBC: D6550005 03FE0F05 00007FFF
	v_add3_u32 v2, v9, v4, 0x7fff                              // 00000032DDC8: D6550002 03FE0909 00007FFF
	v_add3_u32 v3, v6, v12, 0x7fff                             // 00000032DDD4: D6550003 03FE1906 00007FFF
	v_add3_u32 v4, v13, v14, 0x7fff                            // 00000032DDE0: D6550004 03FE1D0D 00007FFF
	.long 0x7e08398f                                           // 00000032DDEC: 7E08398F
	.long 0x7e063985                                           // 00000032DDF0: 7E063985
	.long 0x7e04398a                                           // 00000032DDF4: 7E04398A
	.long 0x7e023988                                           // 00000032DDF8: 7E023988
	ds_store_b128 v11, v[1:4] offset:1024                      // 00000032DDFC: DB7C0400 0000010B
	s_or_b32 exec_lo, exec_lo, s4                              // 00000032DE04: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000032DE08: BF870009
	s_mov_b32 s6, exec_lo                                      // 00000032DE0C: BE86007E
	s_waitcnt lgkmcnt(0)                                       // 00000032DE10: BF89FC07
	s_barrier                                                  // 00000032DE14: BFBD0000
	buffer_gl0_inv                                             // 00000032DE18: E0AC0000 00000000
	v_cmpx_gt_u32_e32 32, v0                                   // 00000032DE20: 7D9800A0
	s_cbranch_execz 258                                        // 00000032DE24: BFA50102 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x1430>
	v_lshrrev_b32_e32 v11, 3, v0                               // 00000032DE28: 32160083
	v_and_b32_e32 v12, 7, v0                                   // 00000032DE2C: 36180087
	s_cmp_eq_u64 s[10:11], 0                                   // 00000032DE30: BF10800A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000032DE34: BF870112
	v_or_b32_e32 v1, s3, v11                                   // 00000032DE38: 38021603
	v_mul_u32_u24_e32 v5, 0x5000, v12                          // 00000032DE3C: 160A18FF 00005000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000032DE44: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000032DE48: 3404029F
	.long 0xd7000305                                           // 00000032DE4C: D7000305
	v_cndmask_b32_e32 v1, s20, v5, vcc_lo                      // 00000032DE50: 02020A14
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000032DE54: BF870191
	v_add_co_ci_u32_e64 v6, null, s21, 0, s3                   // 00000032DE58: D5207C06 000D0015
	.long 0xd73c0003                                           // 00000032DE60: D73C0003
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000032DE64: 02020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000032DE68: BF870091
	.long 0xd7006a03                                           // 00000032DE6C: D7006A03
	v_cndmask_b32_e32 v1, v5, v3, vcc_lo                       // 00000032DE70: 02020705
	v_add_co_ci_u32_e64 v4, null, v6, v4, vcc_lo               // 00000032DE74: D5207C04 01AA0906
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000032DE7C: BF870092
	.long 0xd7006a05                                           // 00000032DE80: D7006A05
	v_cndmask_b32_e32 v1, 0x2000, v3, vcc_lo                   // 00000032DE84: 020206FF 00002000
	v_add_co_ci_u32_e64 v6, null, 0, v4, vcc_lo                // 00000032DE8C: D5207C06 01AA0880
	.long 0xd7006a07                                           // 00000032DE94: D7006A07
	v_cndmask_b32_e32 v1, 0x3000, v3, vcc_lo                   // 00000032DE98: 020206FF 00003000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000032DEA0: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v4, vcc_lo                // 00000032DEA4: D5207C08 01AA0880
	.long 0xd7006a09                                           // 00000032DEAC: D7006A09
	v_cndmask_b32_e32 v1, 0x1000, v3, vcc_lo                   // 00000032DEB0: 020206FF 00001000
	v_add_co_ci_u32_e64 v10, null, 0, v4, vcc_lo               // 00000032DEB8: D5207C0A 01AA0880
	s_clause 0x3                                               // 00000032DEC0: BF850003
	global_load_u16 v5, v[5:6], off offset:2048                // 00000032DEC4: DC4A0800 057C0005
	global_load_u16 v6, v[7:8], off offset:3072                // 00000032DECC: DC4A0C00 067C0007
	global_load_u16 v3, v[3:4], off                            // 00000032DED4: DC4A0000 037C0003
	global_load_u16 v4, v[9:10], off offset:1024               // 00000032DEDC: DC4A0400 047C0009
	v_lshlrev_b32_e32 v7, 1, v12                               // 00000032DEE4: 300E1881
	s_delay_alu instid0(VALU_DEP_1)                            // 00000032DEE8: BF870001
	v_lshl_or_b32 v7, v11, 6, v7                               // 00000032DEEC: D6560007 041D0D0B
	ds_load_u16 v8, v7 offset:1024                             // 00000032DEF4: D8F00400 08000007
	ds_load_u16 v9, v7 offset:1040                             // 00000032DEFC: D8F00410 09000007
	ds_load_u16 v10, v7 offset:1056                            // 00000032DF04: D8F00420 0A000007
	ds_load_u16 v7, v7 offset:1072                             // 00000032DF0C: D8F00430 07000007
	s_waitcnt lgkmcnt(0)                                       // 00000032DF14: BF89FC07
	v_lshlrev_b32_e32 v7, 16, v7                               // 00000032DF18: 300E0E90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000032DF1C: BF870091
	v_dual_mul_f32 v7, 0xbfb8aa3b, v7 :: v_dual_lshlrev_b32 v8, 16, v8// 00000032DF20: C8E20EFF 07081090 BFB8AA3B
	v_dual_mul_f32 v8, 0xbfb8aa3b, v8 :: v_dual_lshlrev_b32 v9, 16, v9// 00000032DF2C: C8E210FF 08081290 BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000032DF38: BF870092
	v_exp_f32_e32 v7, v7                                       // 00000032DF3C: 7E0E4B07
	v_mul_f32_e32 v9, 0xbfb8aa3b, v9                           // 00000032DF40: 101212FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000032DF48: BF870092
	v_exp_f32_e32 v8, v8                                       // 00000032DF4C: 7E104B08
	v_exp_f32_e32 v9, v9                                       // 00000032DF50: 7E124B09
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 00000032DF54: BF870317
	v_dual_add_f32 v7, 1.0, v7 :: v_dual_lshlrev_b32 v10, 16, v10// 00000032DF58: C9220EF2 070A1490
	v_add_f32_e32 v8, 1.0, v8                                  // 00000032DF60: 061010F2
	s_delay_alu instid0(VALU_DEP_2)                            // 00000032DF64: BF870002
	v_div_scale_f32 v15, null, v7, v7, 1.0                     // 00000032DF68: D6FC7C0F 03CA0F07
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_3)   // 00000032DF70: BF870185
	v_dual_add_f32 v9, 1.0, v9 :: v_dual_mul_f32 v10, 0xbfb8aa3b, v10// 00000032DF74: C90612F2 090A14FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000032DF80: BF870223
	v_div_scale_f32 v11, null, v8, v8, 1.0                     // 00000032DF84: D6FC7C0B 03CA1108
	v_div_scale_f32 v20, vcc_lo, 1.0, v8, 1.0                  // 00000032DF8C: D6FC6A14 03CA10F2
	v_rcp_f32_e32 v19, v15                                     // 00000032DF94: 7E26550F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000032DF98: BF870143
	v_div_scale_f32 v13, null, v9, v9, 1.0                     // 00000032DF9C: D6FC7C0D 03CA1309
	v_exp_f32_e32 v10, v10                                     // 00000032DFA4: 7E144B0A
	v_rcp_f32_e32 v16, v11                                     // 00000032DFA8: 7E20550B
	v_div_scale_f32 v21, s3, 1.0, v9, 1.0                      // 00000032DFAC: D6FC0315 03CA12F2
	v_rcp_f32_e32 v17, v13                                     // 00000032DFB4: 7E22550D
	v_fma_f32 v26, -v15, v19, 1.0                              // 00000032DFB8: D613001A 23CA270F
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 00000032DFC0: BF870317
	v_add_f32_e32 v10, 1.0, v10                                // 00000032DFC4: 061414F2
	v_fma_f32 v22, -v11, v16, 1.0                              // 00000032DFC8: D6130016 23CA210B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000032DFD0: BF870293
	v_fmac_f32_e32 v19, v26, v19                               // 00000032DFD4: 5626271A
	v_fma_f32 v23, -v13, v17, 1.0                              // 00000032DFD8: D6130017 23CA230D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000032DFE0: BF870214
	v_div_scale_f32 v14, null, v10, v10, 1.0                   // 00000032DFE4: D6FC7C0E 03CA150A
	v_fmac_f32_e32 v16, v22, v16                               // 00000032DFEC: 56202116
	v_div_scale_f32 v25, s4, 1.0, v10, 1.0                     // 00000032DFF0: D6FC0419 03CA14F2
	v_div_scale_f32 v22, s5, 1.0, v7, 1.0                      // 00000032DFF8: D6FC0516 03CA0EF2
	v_fmac_f32_e32 v17, v23, v17                               // 00000032E000: 56222317
	v_rcp_f32_e32 v18, v14                                     // 00000032E004: 7E24550E
	v_mul_f32_e32 v23, v20, v16                                // 00000032E008: 102E2114
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000032E00C: BF870093
	v_mul_f32_e32 v27, v22, v19                                // 00000032E010: 10362716
	v_fma_f32 v31, -v15, v27, v22                              // 00000032E014: D613001F 245A370F
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000032E01C: BF870095
	v_fma_f32 v24, -v14, v18, 1.0                              // 00000032E020: D6130018 23CA250E
	v_dual_fmac_f32 v27, v31, v19 :: v_dual_fmac_f32 v18, v24, v18// 00000032E028: C800271F 1B122518
	v_mul_f32_e32 v24, v21, v17                                // 00000032E030: 10302315
	v_fma_f32 v28, -v11, v23, v20                              // 00000032E034: D613001C 24522F0B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000032E03C: BF870213
	v_fma_f32 v15, -v15, v27, v22                              // 00000032E040: D613000F 245A370F
	v_mul_f32_e32 v26, v25, v18                                // 00000032E048: 10342519
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000032E04C: BF870214
	v_fma_f32 v29, -v13, v24, v21                              // 00000032E050: D613001D 2456310D
	v_fmac_f32_e32 v23, v28, v16                               // 00000032E058: 562E211C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000032E05C: BF870193
	v_fma_f32 v30, -v14, v26, v25                              // 00000032E060: D613001E 2466350E
	v_fmac_f32_e32 v24, v29, v17                               // 00000032E068: 5630231D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000032E06C: BF870193
	v_fma_f32 v11, -v11, v23, v20                              // 00000032E070: D613000B 24522F0B
	v_fmac_f32_e32 v26, v30, v18                               // 00000032E078: 5634251E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000032E07C: BF870193
	v_fma_f32 v13, -v13, v24, v21                              // 00000032E080: D613000D 2456310D
	v_div_fmas_f32 v11, v11, v16, v23                          // 00000032E088: D637000B 045E210B
	s_mov_b32 vcc_lo, s3                                       // 00000032E090: BEEA0003
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000032E094: BF870193
	v_fma_f32 v14, -v14, v26, v25                              // 00000032E098: D613000E 2466350E
	v_div_fmas_f32 v13, v13, v17, v24                          // 00000032E0A0: D637000D 0462230D
	s_mov_b32 vcc_lo, s4                                       // 00000032E0A8: BEEA0004
	v_div_fixup_f32 v8, v11, v8, 1.0                           // 00000032E0AC: D6270008 03CA110B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000032E0B4: BF870193
	v_div_fmas_f32 v11, v14, v18, v26                          // 00000032E0B8: D637000B 046A250E
	v_div_fixup_f32 v9, v13, v9, 1.0                           // 00000032E0C0: D6270009 03CA130D
	s_mov_b32 vcc_lo, s5                                       // 00000032E0C8: BEEA0005
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000032E0CC: BF870243
	v_bfe_u32 v13, v8, 16, 1                                   // 00000032E0D0: D610000D 02052108
	v_div_fmas_f32 v14, v15, v19, v27                          // 00000032E0D8: D637000E 046E270F
	v_div_fixup_f32 v10, v11, v10, 1.0                         // 00000032E0E0: D627000A 03CA150B
	v_bfe_u32 v11, v9, 16, 1                                   // 00000032E0E8: D610000B 02052109
	v_add3_u32 v8, v8, v13, 0x7fff                             // 00000032E0F0: D6550008 03FE1B08 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000032E0FC: BF870214
	v_div_fixup_f32 v7, v14, v7, 1.0                           // 00000032E100: D6270007 03CA0F0E
	v_bfe_u32 v13, v10, 16, 1                                  // 00000032E108: D610000D 0205210A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000032E110: BF870194
	v_add3_u32 v9, v9, v11, 0x7fff                             // 00000032E114: D6550009 03FE1709 00007FFF
	v_bfe_u32 v11, v7, 16, 1                                   // 00000032E120: D610000B 02052107
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000032E128: BF870193
	v_add3_u32 v10, v10, v13, 0x7fff                           // 00000032E12C: D655000A 03FE1B0A 00007FFF
	v_and_b32_e32 v9, 0xffff0000, v9                           // 00000032E138: 361212FF FFFF0000
	s_delay_alu instid0(VALU_DEP_3)                            // 00000032E140: BF870003
	v_add3_u32 v7, v7, v11, 0x7fff                             // 00000032E144: D6550007 03FE1707 00007FFF
	s_waitcnt vmcnt(3)                                         // 00000032E150: BF890FF7
	v_lshlrev_b32_e32 v5, 16, v5                               // 00000032E154: 300A0A90
	s_waitcnt vmcnt(2)                                         // 00000032E158: BF890BF7
	v_lshlrev_b32_e32 v6, 16, v6                               // 00000032E15C: 300C0C90
	s_waitcnt vmcnt(1)                                         // 00000032E160: BF8907F7
	v_lshlrev_b32_e32 v3, 16, v3                               // 00000032E164: 30060690
	s_waitcnt vmcnt(0)                                         // 00000032E168: BF8903F7
	v_lshlrev_b32_e32 v4, 16, v4                               // 00000032E16C: 30080890
	v_and_b32_e32 v8, 0xffff0000, v8                           // 00000032E170: 361010FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000032E178: BF870091
	v_fma_f32 v3, v3, v8, 0                                    // 00000032E17C: D6130003 02021103
	v_dual_fmac_f32 v3, v4, v9 :: v_dual_and_b32 v4, 0xffff0000, v7// 00000032E184: C8241304 03040EFF FFFF0000
	v_and_b32_e32 v8, 0xffff0000, v10                          // 00000032E190: 361014FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000032E198: BF870091
	v_fmac_f32_e32 v3, v5, v8                                  // 00000032E19C: 56061105
	v_fmac_f32_e32 v3, v6, v4                                  // 00000032E1A0: 56060906
	v_mul_u32_u24_e32 v4, 0xa00, v12                           // 00000032E1A4: 160818FF 00000A00
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000032E1AC: BF870112
	v_mul_f32_e32 v3, 0x3e800000, v3                           // 00000032E1B0: 100606FF 3E800000
	.long 0xd7006a01                                           // 00000032E1B8: D7006A01
	v_cndmask_b32_e32 v1, v1, v4, vcc_lo                       // 00000032E1BC: 02020901
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000032E1C0: BF870191
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 00000032E1C4: D5207C02 01AA0480
	v_bfe_u32 v6, v3, 16, 1                                    // 00000032E1CC: D6100006 02052103
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000032E1D4: BF870112
	.long 0xd73c0004                                           // 00000032E1D8: D73C0004
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000032E1DC: 02020281
	v_add3_u32 v6, v3, v6, 0x7fff                              // 00000032E1E0: D6550006 03FE0D03 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000032E1EC: BF870092
	.long 0xd7006a04                                           // 00000032E1F0: D7006A04
	v_cndmask_b32_e32 v1, s8, v4, vcc_lo                       // 00000032E1F4: 02020808
	v_add_co_ci_u32_e64 v5, null, s9, v5, vcc_lo               // 00000032E1F8: D5207C05 01AA0A09
	global_store_d16_hi_b16 v[4:5], v6, off                    // 00000032E200: DC960000 007C0604
	s_cbranch_scc1 9                                           // 00000032E208: BFA20009 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x1430>
	.long 0xd73c0001                                           // 00000032E20C: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000032E210: 02020282
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000032E214: BF870091
	.long 0xd7006a01                                           // 00000032E218: D7006A01
	v_cndmask_b32_e32 v1, s10, v1, vcc_lo                      // 00000032E21C: 0202020A
	v_add_co_ci_u32_e64 v2, null, s11, v2, vcc_lo              // 00000032E220: D5207C02 01AA040B
	global_store_b32 v[1:2], v3, off                           // 00000032E228: DC6A0000 007C0301
	s_or_b32 exec_lo, exec_lo, s6                              // 00000032E230: 8C7E067E
	s_mov_b32 s25, 0                                           // 00000032E234: BE990080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000032E238: BF870009
	s_and_b32 vcc_lo, exec_lo, s25                             // 00000032E23C: 8B6A197E
	s_cbranch_vccz 662                                         // 00000032E240: BFA30296 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x1e9c>
	s_clause 0x3                                               // 00000032E244: BF850003
	s_load_b32 s3, s[0:1], 0x148                               // 00000032E248: F40000C0 F8000148
	s_load_b32 s4, s[0:1], 0xb0                                // 00000032E250: F4000100 F80000B0
	s_load_b32 s6, s[0:1], 0xf8                                // 00000032E258: F4000180 F80000F8
	s_load_b32 s7, s[0:1], 0x140                               // 00000032E260: F40001C0 F8000140
	s_sub_i32 s5, s2, s24                                      // 00000032E268: 81851802
	v_lshrrev_b32_e32 v3, 5, v0                                // 00000032E26C: 32060085
	v_mov_b32_e32 v29, 0                                       // 00000032E270: 7E3A0280
	v_and_b32_e32 v15, 31, v0                                  // 00000032E274: 361E009F
	s_waitcnt lgkmcnt(0)                                       // 00000032E278: BF89FC07
	s_cmp_gt_i32 s3, 1                                         // 00000032E27C: BF028103
	s_cselect_b32 s8, -1, 0                                    // 00000032E280: 980880C1
	s_cmp_ge_i32 s5, s4                                        // 00000032E284: BF030405
	s_cselect_b32 s4, -1, 0                                    // 00000032E288: 980480C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000032E28C: BF870009
	s_and_b32 s4, s8, s4                                       // 00000032E290: 8B040408
	s_cmp_gt_i32 s3, 2                                         // 00000032E294: BF028203
	v_cndmask_b32_e64 v1, 0, 1, s4                             // 00000032E298: D5010001 00110280
	s_cselect_b32 s8, -1, 0                                    // 00000032E2A0: 980880C1
	s_cmp_ge_i32 s5, s6                                        // 00000032E2A4: BF030605
	s_cselect_b32 s6, -1, 0                                    // 00000032E2A8: 980680C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000032E2AC: BF870009
	s_and_b32 s4, s8, s6                                       // 00000032E2B0: 8B040608
	s_cmp_gt_i32 s3, 3                                         // 00000032E2B4: BF028303
	v_readfirstlane_b32 s6, v1                                 // 00000032E2B8: 7E0C0501
	s_cselect_b32 s3, -1, 0                                    // 00000032E2BC: 980380C1
	s_cmp_ge_i32 s5, s7                                        // 00000032E2C0: BF030705
	s_cselect_b32 s7, -1, 0                                    // 00000032E2C4: 980780C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 00000032E2C8: BF8704D9
	s_and_b32 s3, s3, s7                                       // 00000032E2CC: 8B030703
	s_and_b32 s4, s4, exec_lo                                  // 00000032E2D0: 8B047E04
	s_cselect_b32 s4, 2, s6                                    // 00000032E2D4: 98040682
	s_and_b32 s3, s3, exec_lo                                  // 00000032E2D8: 8B037E03
	s_cselect_b32 s3, 3, s4                                    // 00000032E2DC: 98030483
	s_mulk_i32 s3, 0x48                                        // 00000032E2E0: B8030048
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000032E2E4: BF870009
	s_add_u32 s10, s0, s3                                      // 00000032E2E8: 800A0300
	s_addc_u32 s11, s1, 0                                      // 00000032E2EC: 820B8001
	s_clause 0x1                                               // 00000032E2F0: BF850001
	s_load_b64 s[6:7], s[10:11], 0x58                          // 00000032E2F4: F4040185 F8000058
	s_load_b32 s3, s[10:11], 0x68                              // 00000032E2FC: F40000C5 F8000068
	s_add_u32 s8, s10, 40                                      // 00000032E304: 8008A80A
	s_addc_u32 s9, s11, 0                                      // 00000032E308: 8209800B
	s_load_b64 s[10:11], s[10:11], 0x28                        // 00000032E30C: F4040285 F8000028
	s_waitcnt lgkmcnt(0)                                       // 00000032E314: BF89FC07
	.long 0xd4510013                                           // 00000032E318: D4510013
	v_cndmask_b32_e32 v0, s6, v137, vcc_lo                     // 00000032E31C: 02011206
	s_and_b32 s4, s19, exec_lo                                 // 00000032E320: 8B047E13
	s_cselect_b32 s18, 8, 2                                    // 00000032E324: 98128288
	s_cselect_b32 s24, 3, 1                                    // 00000032E328: 98188183
	v_cvt_f32_ubyte0_e32 v1, s18                               // 00000032E32C: 7E022212
	s_sub_i32 s26, s5, s3                                      // 00000032E330: 819A0305
	s_add_i32 s3, s18, -1                                      // 00000032E334: 8103C112
	s_ashr_i32 s27, s26, 31                                    // 00000032E338: 861B9F1A
	s_and_b32 s4, s19, exec_lo                                 // 00000032E33C: 8B047E13
	v_rcp_iflag_f32_e32 v1, v1                                 // 00000032E340: 7E025701
	s_cselect_b32 s25, 0, 2                                    // 00000032E344: 98198280
	s_ashr_i32 s4, s23, 31                                     // 00000032E348: 86049F17
	s_lshl_b64 s[26:27], s[26:27], s25                         // 00000032E34C: 849A191A
	s_lshr_b32 s4, s4, 28                                      // 00000032E350: 85049C04
	v_lshrrev_b32_e32 v13, s24, v3                             // 00000032E354: 321A0618
	s_add_u32 s28, s22, s4                                     // 00000032E358: 801C0416
	s_addc_u32 s29, s23, 0                                     // 00000032E35C: 821D8017
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000032E360: BF870299
	s_ashr_i64 s[28:29], s[28:29], 4                           // 00000032E364: 869C841C
	v_readfirstlane_b32 s30, v1                                // 00000032E368: 7E3C0501
	.long 0xd7001a01                                           // 00000032E36C: D7001A01
	v_cndmask_b32_e32 v1, s26, v13, vcc_lo                     // 00000032E370: 02021A1A
	s_delay_alu instid0(VALU_DEP_1)                            // 00000032E374: BF870001
	v_add_co_ci_u32_e64 v2, null, s27, 0, s26                  // 00000032E378: D5207C02 0069001B
	s_mul_f32 s4, s30, 0x4f7ffffe                              // 00000032E380: A204FF1E 4F7FFFFE
	s_add_u32 s30, s28, s22                                    // 00000032E388: 801E161C
	s_addc_u32 s29, s29, s23                                   // 00000032E38C: 821D171D
	s_sub_i32 s31, 0, s18                                      // 00000032E390: 819F1280
	s_cvt_u32_f32 s4, s4                                       // 00000032E394: BE846704
	s_add_i32 s33, s3, s28                                     // 00000032E398: 81211C03
	v_cmp_gt_i64_e32 vcc_lo, s[6:7], v[1:2]                    // 00000032E39C: 7CA80206
	s_abs_i32 s34, s33                                         // 00000032E3A0: BEA21521
	s_mul_i32 s31, s31, s4                                     // 00000032E3A4: 961F041F
	s_ashr_i32 s27, s33, 31                                    // 00000032E3A8: 861B9F21
	s_mul_hi_u32 s31, s4, s31                                  // 00000032E3AC: 969F1F04
	v_dual_cndmask_b32 v1, 0, v1 :: v_dual_and_b32 v14, s3, v3 // 00000032E3B0: CA640280 010E0603
	s_add_i32 s4, s4, s31                                      // 00000032E3B8: 81041F04
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo                        // 00000032E3BC: 02040480
	s_mul_hi_u32 s4, s34, s4                                   // 00000032E3C0: 96840422
	v_mov_b32_e32 v3, 0                                        // 00000032E3C4: 7E060280
	s_mul_i32 s26, s4, s18                                     // 00000032E3C8: 961A1204
	s_add_i32 s31, s4, 1                                       // 00000032E3CC: 811F8104
	s_sub_i32 s26, s34, s26                                    // 00000032E3D0: 819A1A22
	.long 0xd72c0004                                           // 00000032E3D4: D72C0004
	v_cndmask_b32_e32 v0, v2, v30, vcc_lo                      // 00000032E3D8: 02003D02
	s_sub_i32 s33, s26, s18                                    // 00000032E3DC: 81A1121A
	s_cmp_ge_u32 s26, s18                                      // 00000032E3E0: BF09121A
	.long 0xd72c0006                                           // 00000032E3E4: D72C0006
	v_cndmask_b32_e32 v0, v1, v29, vcc_lo                      // 00000032E3E8: 02003B01
	s_cselect_b32 s4, s31, s4                                  // 00000032E3EC: 9804041F
	s_cselect_b32 s26, s33, s26                                // 00000032E3F0: 981A1A21
	s_add_i32 s31, s4, 1                                       // 00000032E3F4: 811F8104
	s_cmp_ge_u32 s26, s18                                      // 00000032E3F8: BF09121A
	v_mad_u64_u32 v[9:10], null, v1, s30, s[10:11]             // 00000032E3FC: D6FE7C09 00283D01
	s_cselect_b32 s3, s31, s4                                  // 00000032E404: 9803041F
	v_mov_b32_e32 v2, 0                                        // 00000032E408: 7E040280
	s_xor_b32 s3, s3, s27                                      // 00000032E40C: 8D031B03
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000032E410: BF870499
	s_sub_i32 s3, s3, s27                                      // 00000032E414: 81831B03
	.long 0xd72c0005                                           // 00000032E418: D72C0005
	v_cndmask_b32_e32 v0, v14, v3, vcc_lo                      // 00000032E41C: 0200070E
	v_mov_b32_e32 v1, 0                                        // 00000032E420: 7E020280
	v_add3_u32 v10, v4, v10, v6                                // 00000032E424: D655000A 041A1504
	.long 0xd7006a12                                           // 00000032E42C: D7006A12
	v_cndmask_b32_e32 v0, v9, v22, vcc_lo                      // 00000032E430: 02002D09
	v_mov_b32_e32 v4, 0                                        // 00000032E434: 7E080280
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000032E438: BF870133
	v_add_co_ci_u32_e64 v19, null, s23, v10, vcc_lo            // 00000032E43C: D5207C13 01AA1417
	v_add_nc_u32_e32 v7, s3, v5                                // 00000032E444: 4A0E0A03
	v_add_nc_u32_e32 v16, v5, v15                              // 00000032E448: 4A201F05
	v_min_i32_e32 v17, s28, v7                                 // 00000032E44C: 22220E1C
	s_delay_alu instid0(VALU_DEP_1)                            // 00000032E450: BF870001
	.long 0xd4410004                                           // 00000032E454: D4410004
	v_cndmask_b32_e32 v1, v16, v17, vcc_lo                     // 00000032E458: 02022310
	s_and_saveexec_b32 s3, s4                                  // 00000032E45C: BE832004
	s_cbranch_execz 19                                         // 00000032E460: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x16b0>
	v_lshlrev_b32_e32 v1, 4, v16                               // 00000032E464: 30022084
	v_and_b32_e32 v3, -4, v16                                  // 00000032E468: 360620C4
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000032E46C: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000032E470: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 00000032E474: 3408069F
	.long 0xd7006a01                                           // 00000032E478: D7006A01
	v_cndmask_b32_e32 v1, v9, v1, vcc_lo                       // 00000032E47C: 02020309
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000032E480: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v10, v2, vcc_lo              // 00000032E484: D5207C02 01AA050A
	.long 0xd7006a06                                           // 00000032E48C: D7006A06
	v_cndmask_b32_e32 v1, v18, v3, vcc_lo                      // 00000032E490: 02020712
	v_add_co_ci_u32_e64 v7, null, v19, v4, vcc_lo              // 00000032E494: D5207C07 01AA0913
	s_clause 0x1                                               // 00000032E49C: BF850001
	global_load_b128 v[1:4], v[1:2], off                       // 00000032E4A0: DC5E0000 017C0001
	global_load_b32 v29, v[6:7], off                           // 00000032E4A8: DC520000 1D7C0006
	s_or_b32 exec_lo, exec_lo, s3                              // 00000032E4B0: 8C7E037E
	.long 0xd44a0003                                           // 00000032E4B4: D44A0003
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 00000032E4B8: 02020080
	s_and_saveexec_b32 s10, s3                                 // 00000032E4BC: BE8A2003
	s_cbranch_execz 20                                         // 00000032E4C0: BFA50014 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x1714>
	v_mov_b32_e32 v6, 0                                        // 00000032E4C4: 7E0C0280
	global_load_b64 v[7:8], v6, s[12:13] glc                   // 00000032E4C8: DC564000 070C0006
	s_waitcnt vmcnt(0)                                         // 00000032E4D0: BF8903F7
	buffer_gl1_inv                                             // 00000032E4D4: E0B00000 00000000
	buffer_gl0_inv                                             // 00000032E4DC: E0AC0000 00000000
	v_cmp_le_u64_e32 vcc_lo, s[14:15], v[7:8]                  // 00000032E4E4: 7CB60E0E
	s_cbranch_vccnz 10                                         // 00000032E4E8: BFA4000A <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x1714>
	s_sleep 1                                                  // 00000032E4EC: BF830001
	global_load_b64 v[7:8], v6, s[12:13] glc                   // 00000032E4F0: DC564000 070C0006
	s_waitcnt vmcnt(0)                                         // 00000032E4F8: BF8903F7
	buffer_gl1_inv                                             // 00000032E4FC: E0B00000 00000000
	buffer_gl0_inv                                             // 00000032E504: E0AC0000 00000000
	v_cmp_gt_u64_e32 vcc_lo, s[14:15], v[7:8]                  // 00000032E50C: 7CB80E0E
	s_cbranch_vccnz 65526                                      // 00000032E510: BFA4FFF6 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x16ec>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000032E514: 8C7E0A7E
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v22, 0             // 00000032E518: CA100080 15160080
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v24, 0             // 00000032E520: CA100080 17180080
	v_dual_mov_b32 v25, 0 :: v_dual_mov_b32 v26, 0             // 00000032E528: CA100080 191A0080
	v_dual_mov_b32 v27, 0 :: v_dual_mov_b32 v20, 0             // 00000032E530: CA100080 1B140080
	s_waitcnt vmcnt(0)                                         // 00000032E538: BF8903F7
	s_waitcnt_vscnt null, 0x0                                  // 00000032E53C: BC7C0000
	s_barrier                                                  // 00000032E540: BFBD0000
	buffer_gl0_inv                                             // 00000032E544: E0AC0000 00000000
	buffer_gl1_inv                                             // 00000032E54C: E0B00000 00000000
	buffer_gl0_inv                                             // 00000032E554: E0AC0000 00000000
	s_and_saveexec_b32 s26, s4                                 // 00000032E55C: BE9A2004
	s_cbranch_execz 852                                        // 00000032E560: BFA50354 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x24b4>
	v_dual_mov_b32 v27, 0 :: v_dual_lshlrev_b32 v6, 4, v15     // 00000032E564: CA220080 1B061E84
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v25, 0             // 00000032E56C: CA100080 14180080
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v23, 0             // 00000032E574: CA100080 1A160080
	s_delay_alu instid0(VALU_DEP_3)                            // 00000032E57C: BF870003
	v_lshl_add_u32 v11, v5, 4, v6                              // 00000032E580: D646000B 04190905
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v21, 0             // 00000032E588: CA100080 18140080
	v_mov_b32_e32 v22, 0                                       // 00000032E590: 7E2C0280
	s_mul_i32 s4, s23, 6                                       // 00000032E594: 96048617
	s_mul_hi_u32 s14, s22, 6                                   // 00000032E598: 968E8616
	s_lshl_b64 s[10:11], s[22:23], 2                           // 00000032E59C: 848A8216
	s_add_i32 s27, s14, s4                                     // 00000032E5A0: 811B040E
	s_mul_i32 s29, s22, 6                                      // 00000032E5A4: 961D8616
	s_mov_b32 s28, 0                                           // 00000032E5A8: BE9C0080
	s_lshl_b64 s[14:15], s[22:23], 1                           // 00000032E5AC: 848E8116
	s_branch 406                                               // 00000032E5B0: BFA00196 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x1e0c>
	s_or_b32 exec_lo, exec_lo, s22                             // 00000032E5B4: 8C7E167E
	v_ashrrev_i32_e32 v12, 31, v11                             // 00000032E5B8: 3418169F
	v_cvt_f32_ubyte1_e32 v96, v1                               // 00000032E5BC: 7EC02501
	v_cvt_f32_ubyte3_e32 v97, v1                               // 00000032E5C0: 7EC22901
	v_cvt_f32_ubyte0_e32 v98, v2                               // 00000032E5C4: 7EC42302
	v_cvt_f32_ubyte1_e32 v99, v2                               // 00000032E5C8: 7EC62502
	.long 0xd73c000b                                           // 00000032E5CC: D73C000B
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 00000032E5D0: 02021681
	v_cvt_f32_ubyte2_e32 v100, v2                              // 00000032E5D4: 7EC82702
	v_cvt_f32_ubyte3_e32 v101, v2                              // 00000032E5D8: 7ECA2902
	s_waitcnt vmcnt(1)                                         // 00000032E5DC: BF8907F7
	v_mov_b32_e32 v2, v6                                       // 00000032E5E0: 7E040306
	v_cvt_f32_ubyte0_e32 v102, v3                              // 00000032E5E4: 7ECC2303
	v_cvt_f32_ubyte1_e32 v103, v3                              // 00000032E5E8: 7ECE2503
	.long 0xd700040b                                           // 00000032E5EC: D700040B
	v_cndmask_b32_e32 v1, s20, v11, vcc_lo                     // 00000032E5F0: 02021614
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000032E5F4: BF8701A1
	v_add_co_ci_u32_e64 v12, null, s21, v12, s4                // 00000032E5F8: D5207C0C 00121815
	v_cvt_f32_ubyte2_e32 v104, v3                              // 00000032E600: 7ED02703
	.long 0xd7000443                                           // 00000032E604: D7000443
	v_cndmask_b32_e32 v0, v11, v14, vcc_lo                     // 00000032E608: 02001D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000032E60C: BF8700A1
	v_add_co_ci_u32_e64 v68, null, s15, v12, s4                // 00000032E610: D5207C44 0012180F
	.long 0xd7000447                                           // 00000032E618: D7000447
	v_cndmask_b32_e32 v0, v11, v10, vcc_lo                     // 00000032E61C: 0200150B
	v_add_co_ci_u32_e64 v72, null, s11, v12, s4                // 00000032E620: D5207C48 0012180B
	.long 0xd700044b                                           // 00000032E628: D700044B
	v_cndmask_b32_e32 v0, v11, v29, vcc_lo                     // 00000032E62C: 02003B0B
	global_load_b128 v[31:34], v[11:12], off                   // 00000032E630: DC5E0000 1F7C000B
	v_add_co_ci_u32_e64 v76, null, s27, v12, s4                // 00000032E638: D5207C4C 0012181B
	.long 0xd700044f                                           // 00000032E640: D700044F
	v_cndmask_b32_e32 v0, v71, v10, vcc_lo                     // 00000032E644: 02001547
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000032E648: BF8700A1
	v_add_co_ci_u32_e64 v80, null, s11, v72, s4                // 00000032E64C: D5207C50 0012900B
	.long 0xd7000453                                           // 00000032E654: D7000453
	v_cndmask_b32_e32 v0, v75, v10, vcc_lo                     // 00000032E658: 0200154B
	v_add_co_ci_u32_e64 v84, null, s11, v76, s4                // 00000032E65C: D5207C54 0012980B
	s_clause 0x4                                               // 00000032E664: BF850004
	global_load_b128 v[35:38], v[67:68], off                   // 00000032E668: DC5E0000 237C0043
	global_load_b128 v[39:42], v[71:72], off                   // 00000032E670: DC5E0000 277C0047
	global_load_b128 v[43:46], v[75:76], off                   // 00000032E678: DC5E0000 2B7C004B
	global_load_b128 v[47:50], v[79:80], off                   // 00000032E680: DC5E0000 2F7C004F
	global_load_b128 v[51:54], v[83:84], off                   // 00000032E688: DC5E0000 337C0053
	.long 0xd7000457                                           // 00000032E690: D7000457
	v_cndmask_b32_e32 v0, v79, v10, vcc_lo                     // 00000032E694: 0200154F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000032E698: BF8700A1
	v_add_co_ci_u32_e64 v88, null, s11, v80, s4                // 00000032E69C: D5207C58 0012A00B
	.long 0xd700045b                                           // 00000032E6A4: D700045B
	v_cndmask_b32_e32 v0, v83, v10, vcc_lo                     // 00000032E6A8: 02001553
	v_add_co_ci_u32_e64 v92, null, s11, v84, s4                // 00000032E6AC: D5207C5C 0012A80B
	s_clause 0x9                                               // 00000032E6B4: BF850009
	global_load_b128 v[55:58], v[87:88], off                   // 00000032E6B8: DC5E0000 377C0057
	global_load_b128 v[59:62], v[91:92], off                   // 00000032E6C0: DC5E0000 3B7C005B
	global_load_b128 v[63:66], v[11:12], off offset:16         // 00000032E6C8: DC5E0010 3F7C000B
	global_load_b128 v[67:70], v[67:68], off offset:16         // 00000032E6D0: DC5E0010 437C0043
	global_load_b128 v[71:74], v[71:72], off offset:16         // 00000032E6D8: DC5E0010 477C0047
	global_load_b128 v[75:78], v[75:76], off offset:16         // 00000032E6E0: DC5E0010 4B7C004B
	global_load_b128 v[79:82], v[79:80], off offset:16         // 00000032E6E8: DC5E0010 4F7C004F
	global_load_b128 v[83:86], v[83:84], off offset:16         // 00000032E6F0: DC5E0010 537C0053
	global_load_b128 v[87:90], v[87:88], off offset:16         // 00000032E6F8: DC5E0010 577C0057
	global_load_b128 v[91:94], v[91:92], off offset:16         // 00000032E700: DC5E0010 5B7C005B
	v_cvt_f32_ubyte0_e32 v11, v1                               // 00000032E708: 7E162301
	v_cvt_f32_ubyte2_e32 v12, v1                               // 00000032E70C: 7E182701
	v_mov_b32_e32 v1, v5                                       // 00000032E710: 7E020305
	v_cvt_f32_ubyte3_e32 v105, v3                              // 00000032E714: 7ED22903
	v_cvt_f32_ubyte0_e32 v106, v4                              // 00000032E718: 7ED42304
	v_fma_mix_f32 v5, v11, v29, v29 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032E71C: CC206005 14763B0B
	v_cvt_f32_ubyte1_e32 v107, v4                              // 00000032E724: 7ED62504
	v_cvt_f32_ubyte2_e32 v108, v4                              // 00000032E728: 7ED82704
	v_cvt_f32_ubyte3_e32 v109, v4                              // 00000032E72C: 7EDA2904
	v_dual_mov_b32 v4, v8 :: v_dual_mov_b32 v3, v7             // 00000032E730: CA100108 04020107
	v_fma_mix_f32 v6, v12, v29, v29 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032E738: CC206006 14763B0C
	v_fma_mix_f32 v7, v96, v29, v29 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032E740: CC206007 14763B60
	v_fma_mix_f32 v12, v98, v29, v29 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032E748: CC20600C 14763B62
	v_mov_b32_e32 v11, v30                                     // 00000032E750: 7E16031E
	v_bfe_u32 v30, v5, 16, 1                                   // 00000032E754: D610001E 02052105
	v_fma_mix_f32 v8, v97, v29, v29 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032E75C: CC206008 14763B61
	v_fma_mix_f32 v97, v99, v29, v29 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032E764: CC206061 14763B63
	v_bfe_u32 v110, v6, 16, 1                                  // 00000032E76C: D610006E 02052106
	v_bfe_u32 v111, v7, 16, 1                                  // 00000032E774: D610006F 02052107
	v_bfe_u32 v113, v12, 16, 1                                 // 00000032E77C: D6100071 0205210C
	v_add3_u32 v5, v5, v30, 0x7fff                             // 00000032E784: D6550005 03FE3D05 00007FFF
	.long 0x7fbe3880                                           // 00000032E790: 7FBE3880
	v_fma_mix_f32 v98, v100, v29, v29 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032E794: CC206062 14763B64
	v_bfe_u32 v112, v8, 16, 1                                  // 00000032E79C: D6100070 02052108
	v_bfe_u32 v114, v97, 16, 1                                 // 00000032E7A4: D6100072 02052161
	v_add3_u32 v6, v6, v110, 0x7fff                            // 00000032E7AC: D6550006 03FEDD06 00007FFF
	v_add3_u32 v7, v7, v111, 0x7fff                            // 00000032E7B8: D6550007 03FEDF07 00007FFF
	v_add3_u32 v12, v12, v113, 0x7fff                          // 00000032E7C4: D655000C 03FEE30C 00007FFF
	.long 0x7ebe3985                                           // 00000032E7D0: 7EBE3985
	.long 0x7fc039df                                           // 00000032E7D4: 7FC039DF
	v_fma_mix_f32 v99, v101, v29, v29 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032E7D8: CC206063 14763B65
	v_fma_mix_f32 v100, v102, v29, v29 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032E7E0: CC206064 14763B66
	v_bfe_u32 v115, v98, 16, 1                                 // 00000032E7E8: D6100073 02052162
	v_add3_u32 v8, v8, v112, 0x7fff                            // 00000032E7F0: D6550008 03FEE108 00007FFF
	v_add3_u32 v30, v97, v114, 0x7fff                          // 00000032E7FC: D655001E 03FEE561 00007FFF
	.long 0x7ec03986                                           // 00000032E808: 7EC03986
	v_and_or_b32 v6, 0xffff0000, v7, v95                       // 00000032E80C: D6570006 057E0EFF FFFF0000
	.long 0x7ebe398c                                           // 00000032E818: 7EBE398C
	v_fma_mix_f32 v101, v103, v29, v29 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032E81C: CC206065 14763B67
	v_fma_mix_f32 v102, v104, v29, v29 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032E824: CC206066 14763B68
	v_bfe_u32 v116, v99, 16, 1                                 // 00000032E82C: D6100074 02052163
	v_bfe_u32 v117, v100, 16, 1                                // 00000032E834: D6100075 02052164
	v_add3_u32 v97, v98, v115, 0x7fff                          // 00000032E83C: D6550061 03FEE762 00007FFF
	v_and_or_b32 v7, 0xffff0000, v8, v96                       // 00000032E848: D6570007 058210FF FFFF0000
	v_and_or_b32 v8, 0xffff0000, v30, v95                      // 00000032E854: D6570008 057E3CFF FFFF0000
	v_fma_mix_f32 v103, v105, v29, v29 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032E860: CC206067 14763B69
	v_fma_mix_f32 v104, v106, v29, v29 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032E868: CC206068 14763B6A
	v_fma_mix_f32 v105, v107, v29, v29 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032E870: CC206069 14763B6B
	.long 0x7fd639df                                           // 00000032E878: 7FD639DF
	v_bfe_u32 v118, v101, 16, 1                                // 00000032E87C: D6100076 02052165
	v_bfe_u32 v119, v102, 16, 1                                // 00000032E884: D6100077 02052166
	v_add3_u32 v98, v99, v116, 0x7fff                          // 00000032E88C: D6550062 03FEE963 00007FFF
	v_add3_u32 v99, v100, v117, 0x7fff                         // 00000032E898: D6550063 03FEEB64 00007FFF
	.long 0x7ed639e1                                           // 00000032E8A4: 7ED639E1
	v_fma_mix_f32 v106, v108, v29, v29 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032E8A8: CC20606A 14763B6C
	v_bfe_u32 v120, v103, 16, 1                                // 00000032E8B0: D6100078 02052167
	v_bfe_u32 v121, v104, 16, 1                                // 00000032E8B8: D6100079 02052168
	v_add3_u32 v100, v101, v118, 0x7fff                        // 00000032E8C0: D6550064 03FEED65 00007FFF
	v_add3_u32 v101, v102, v119, 0x7fff                        // 00000032E8CC: D6550065 03FEEF66 00007FFF
	.long 0x7ebe39e3                                           // 00000032E8D8: 7EBE39E3
	v_and_or_b32 v12, 0xffff0000, v98, v107                    // 00000032E8DC: D657000C 05AEC4FF FFFF0000
	v_fma_mix_f32 v29, v109, v29, v29 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032E8E8: CC20601D 14763B6D
	.long 0x7fd839df                                           // 00000032E8F0: 7FD839DF
	v_bfe_u32 v122, v105, 16, 1                                // 00000032E8F4: D610007A 02052169
	v_bfe_u32 v123, v106, 16, 1                                // 00000032E8FC: D610007B 0205216A
	v_add3_u32 v102, v103, v120, 0x7fff                        // 00000032E904: D6550066 03FEF167 00007FFF
	v_add3_u32 v103, v104, v121, 0x7fff                        // 00000032E910: D6550067 03FEF368 00007FFF
	.long 0x7ed839e5                                           // 00000032E91C: 7ED839E5
	v_and_or_b32 v96, 0xffff0000, v100, v95                    // 00000032E920: D6570060 057EC8FF FFFF0000
	v_bfe_u32 v124, v29, 16, 1                                 // 00000032E92C: D610007C 0205211D
	v_add3_u32 v5, v105, v122, 0x7fff                          // 00000032E934: D6550005 03FEF569 00007FFF
	v_add3_u32 v104, v106, v123, 0x7fff                        // 00000032E940: D6550068 03FEF76A 00007FFF
	.long 0x7ebe39e7                                           // 00000032E94C: 7EBE39E7
	.long 0x7fda39df                                           // 00000032E950: 7FDA39DF
	v_add3_u32 v29, v29, v124, 0x7fff                          // 00000032E954: D655001D 03FEF91D 00007FFF
	s_and_b32 s4, exec_lo, vcc_lo                              // 00000032E960: 8B046A7E
	.long 0x7eda39e8                                           // 00000032E964: 7EDA39E8
	v_and_or_b32 v5, 0xffff0000, v5, v95                       // 00000032E968: D6570005 057E0AFF FFFF0000
	s_or_b32 s28, s4, s28                                      // 00000032E974: 8C1C1C04
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000032E978: BF870142
	v_and_or_b32 v29, 0xffff0000, v29, v109                    // 00000032E97C: D657001D 05B63AFF FFFF0000
	s_waitcnt vmcnt(15)                                        // 00000032E988: BF893FF7
	v_dot2_f32_bf16 v30, v31, v6, 0                            // 00000032E98C: CC1A401E 1A020D1F
	v_and_or_b32 v31, 0xffff0000, v102, v108                   // 00000032E994: D657001F 05B2CCFF FFFF0000
	v_dot2_f32_bf16 v30, v32, v7, v30                          // 00000032E9A0: CC1A401E 1C7A0F20
	s_waitcnt vmcnt(14)                                        // 00000032E9A8: BF893BF7
	v_dot2_f32_bf16 v32, v35, v6, 0                            // 00000032E9AC: CC1A4020 1A020D23
	s_waitcnt vmcnt(13)                                        // 00000032E9B4: BF8937F7
	v_dot2_f32_bf16 v35, v39, v6, 0                            // 00000032E9B8: CC1A4023 1A020D27
	s_waitcnt vmcnt(12)                                        // 00000032E9C0: BF8933F7
	v_dot2_f32_bf16 v39, v43, v6, 0                            // 00000032E9C4: CC1A4027 1A020D2B
	v_dot2_f32_bf16 v30, v33, v8, v30                          // 00000032E9CC: CC1A401E 1C7A1121
	v_dot2_f32_bf16 v32, v36, v7, v32                          // 00000032E9D4: CC1A4020 1C820F24
	v_dot2_f32_bf16 v33, v40, v7, v35                          // 00000032E9DC: CC1A4021 1C8E0F28
	s_delay_alu instid0(VALU_DEP_4)                            // 00000032E9E4: BF870004
	v_dot2_f32_bf16 v35, v44, v7, v39                          // 00000032E9E8: CC1A4023 1C9E0F2C
	s_waitcnt vmcnt(11)                                        // 00000032E9F0: BF892FF7
	v_dot2_f32_bf16 v36, v47, v6, 0                            // 00000032E9F4: CC1A4024 1A020D2F
	s_waitcnt vmcnt(10)                                        // 00000032E9FC: BF892BF7
	v_dot2_f32_bf16 v39, v51, v6, 0                            // 00000032EA00: CC1A4027 1A020D33
	v_dot2_f32_bf16 v30, v34, v12, v30                         // 00000032EA08: CC1A401E 1C7A1922
	v_dot2_f32_bf16 v32, v37, v8, v32                          // 00000032EA10: CC1A4020 1C821125
	v_dot2_f32_bf16 v33, v41, v8, v33                          // 00000032EA18: CC1A4021 1C861129
	v_dot2_f32_bf16 v34, v45, v8, v35                          // 00000032EA20: CC1A4022 1C8E112D
	v_dot2_f32_bf16 v35, v48, v7, v36                          // 00000032EA28: CC1A4023 1C920F30
	v_dot2_f32_bf16 v36, v52, v7, v39                          // 00000032EA30: CC1A4024 1C9E0F34
	s_waitcnt vmcnt(9)                                         // 00000032EA38: BF8927F7
	v_dot2_f32_bf16 v37, v55, v6, 0                            // 00000032EA3C: CC1A4025 1A020D37
	s_waitcnt vmcnt(8)                                         // 00000032EA44: BF8923F7
	v_dot2_f32_bf16 v6, v59, v6, 0                             // 00000032EA48: CC1A4006 1A020D3B
	s_waitcnt vmcnt(7)                                         // 00000032EA50: BF891FF7
	v_dot2_f32_bf16 v30, v63, v96, v30                         // 00000032EA54: CC1A401E 1C7AC13F
	v_dot2_f32_bf16 v32, v38, v12, v32                         // 00000032EA5C: CC1A4020 1C821926
	v_dot2_f32_bf16 v33, v42, v12, v33                         // 00000032EA64: CC1A4021 1C86192A
	v_dot2_f32_bf16 v34, v46, v12, v34                         // 00000032EA6C: CC1A4022 1C8A192E
	v_dot2_f32_bf16 v35, v49, v8, v35                          // 00000032EA74: CC1A4023 1C8E1131
	v_dot2_f32_bf16 v36, v53, v8, v36                          // 00000032EA7C: CC1A4024 1C921135
	v_dot2_f32_bf16 v37, v56, v7, v37                          // 00000032EA84: CC1A4025 1C960F38
	v_dot2_f32_bf16 v6, v60, v7, v6                            // 00000032EA8C: CC1A4006 1C1A0F3C
	v_dot2_f32_bf16 v7, v64, v31, v30                          // 00000032EA94: CC1A4007 1C7A3F40
	s_waitcnt vmcnt(6)                                         // 00000032EA9C: BF891BF7
	v_dot2_f32_bf16 v30, v67, v96, v32                         // 00000032EAA0: CC1A401E 1C82C143
	s_waitcnt vmcnt(5)                                         // 00000032EAA8: BF8917F7
	v_dot2_f32_bf16 v32, v71, v96, v33                         // 00000032EAAC: CC1A4020 1C86C147
	s_waitcnt vmcnt(4)                                         // 00000032EAB4: BF8913F7
	v_dot2_f32_bf16 v33, v75, v96, v34                         // 00000032EAB8: CC1A4021 1C8AC14B
	v_dot2_f32_bf16 v34, v50, v12, v35                         // 00000032EAC0: CC1A4022 1C8E1932
	v_dot2_f32_bf16 v35, v54, v12, v36                         // 00000032EAC8: CC1A4023 1C921936
	v_dot2_f32_bf16 v36, v57, v8, v37                          // 00000032EAD0: CC1A4024 1C961139
	v_dot2_f32_bf16 v6, v61, v8, v6                            // 00000032EAD8: CC1A4006 1C1A113D
	v_dot2_f32_bf16 v7, v65, v5, v7                            // 00000032EAE0: CC1A4007 1C1E0B41
	v_dot2_f32_bf16 v8, v68, v31, v30                          // 00000032EAE8: CC1A4008 1C7A3F44
	v_dot2_f32_bf16 v30, v72, v31, v32                         // 00000032EAF0: CC1A401E 1C823F48
	v_dot2_f32_bf16 v32, v76, v31, v33                         // 00000032EAF8: CC1A4020 1C863F4C
	s_waitcnt vmcnt(3)                                         // 00000032EB00: BF890FF7
	v_dot2_f32_bf16 v33, v79, v96, v34                         // 00000032EB04: CC1A4021 1C8AC14F
	s_waitcnt vmcnt(2)                                         // 00000032EB0C: BF890BF7
	v_dot2_f32_bf16 v34, v83, v96, v35                         // 00000032EB10: CC1A4022 1C8EC153
	v_dot2_f32_bf16 v35, v58, v12, v36                         // 00000032EB18: CC1A4023 1C92193A
	v_dot2_f32_bf16 v6, v62, v12, v6                           // 00000032EB20: CC1A4006 1C1A193E
	v_dot2_f32_bf16 v7, v66, v29, v7                           // 00000032EB28: CC1A4007 1C1E3B42
	v_dot2_f32_bf16 v8, v69, v5, v8                            // 00000032EB30: CC1A4008 1C220B45
	v_dot2_f32_bf16 v12, v73, v5, v30                          // 00000032EB38: CC1A400C 1C7A0B49
	v_dot2_f32_bf16 v30, v77, v5, v32                          // 00000032EB40: CC1A401E 1C820B4D
	v_dot2_f32_bf16 v32, v80, v31, v33                         // 00000032EB48: CC1A4020 1C863F50
	v_dot2_f32_bf16 v33, v84, v31, v34                         // 00000032EB50: CC1A4021 1C8A3F54
	s_waitcnt vmcnt(1)                                         // 00000032EB58: BF8907F7
	v_dot2_f32_bf16 v34, v87, v96, v35                         // 00000032EB5C: CC1A4022 1C8EC157
	s_waitcnt vmcnt(0)                                         // 00000032EB64: BF8903F7
	v_dot2_f32_bf16 v6, v91, v96, v6                           // 00000032EB68: CC1A4006 1C1AC15B
	v_add_f32_e32 v20, v20, v7                                 // 00000032EB70: 06280F14
	v_dot2_f32_bf16 v7, v70, v29, v8                           // 00000032EB74: CC1A4007 1C223B46
	v_dot2_f32_bf16 v8, v74, v29, v12                          // 00000032EB7C: CC1A4008 1C323B4A
	v_dot2_f32_bf16 v12, v78, v29, v30                         // 00000032EB84: CC1A400C 1C7A3B4E
	v_dot2_f32_bf16 v30, v88, v31, v34                         // 00000032EB8C: CC1A401E 1C8A3F58
	v_dot2_f32_bf16 v6, v92, v31, v6                           // 00000032EB94: CC1A4006 1C1A3F5C
	v_dot2_f32_bf16 v31, v81, v5, v32                          // 00000032EB9C: CC1A401F 1C820B51
	v_dot2_f32_bf16 v32, v85, v5, v33                          // 00000032EBA4: CC1A4020 1C860B55
	v_dual_add_f32 v27, v27, v7 :: v_dual_add_f32 v26, v26, v8 // 00000032EBAC: C9080F1B 1B1A111A
	v_dot2_f32_bf16 v7, v89, v5, v30                           // 00000032EBB4: CC1A4007 1C7A0B59
	v_dot2_f32_bf16 v5, v93, v5, v6                            // 00000032EBBC: CC1A4005 1C1A0B5D
	v_dot2_f32_bf16 v6, v82, v29, v31                          // 00000032EBC4: CC1A4006 1C7E3B52
	v_dot2_f32_bf16 v8, v86, v29, v32                          // 00000032EBCC: CC1A4008 1C823B56
	v_add_f32_e32 v25, v25, v12                                // 00000032EBD4: 06321919
	v_dot2_f32_bf16 v7, v90, v29, v7                           // 00000032EBD8: CC1A4007 1C1E3B5A
	v_dot2_f32_bf16 v5, v94, v29, v5                           // 00000032EBE0: CC1A4005 1C163B5E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000032EBE8: BF870194
	v_dual_add_f32 v24, v24, v6 :: v_dual_add_f32 v23, v23, v8 // 00000032EBEC: C9080D18 18161117
	v_dual_mov_b32 v29, v28 :: v_dual_add_f32 v22, v22, v7     // 00000032EBF4: CA08011C 1D160F16
	s_delay_alu instid0(VALU_DEP_3)                            // 00000032EBFC: BF870003
	v_add_f32_e32 v21, v21, v5                                 // 00000032EC00: 062A0B15
	s_and_not1_b32 exec_lo, exec_lo, s28                       // 00000032EC04: 917E1C7E
	s_cbranch_execz 425                                        // 00000032EC08: BFA501A9 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x24b0>
	v_add_nc_u32_e32 v16, 32, v16                              // 00000032EC0C: 4A2020A0
	v_add_nc_u32_e32 v30, 0x200, v11                           // 00000032EC10: 4A3C16FF 00000200
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000032EC18: BF8704A2
	v_cmp_ge_i32_e32 vcc_lo, v16, v17                          // 00000032EC1C: 7C8C2310
	s_and_saveexec_b32 s4, vcc_lo                              // 00000032EC20: BE84206A
	s_xor_b32 s4, exec_lo, s4                                  // 00000032EC24: 8D04047E
	v_add_nc_u32_e32 v30, 0x200, v11                           // 00000032EC28: 4A3C16FF 00000200
	s_or_saveexec_b32 s22, s4                                  // 00000032EC30: BE962204
	v_dual_mov_b32 v28, v29 :: v_dual_mov_b32 v7, v3           // 00000032EC34: CA10011D 1C060103
	v_dual_mov_b32 v5, v1 :: v_dual_mov_b32 v6, v2             // 00000032EC3C: CA100101 05060102
	v_mov_b32_e32 v8, v4                                       // 00000032EC44: 7E100304
	s_xor_b32 exec_lo, exec_lo, s22                            // 00000032EC48: 8D7E167E
	s_cbranch_execz 65113                                      // 00000032EC4C: BFA5FE59 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x17b4>
	v_and_b32_e32 v7, -4, v16                                  // 00000032EC50: 360E20C4
	v_ashrrev_i32_e32 v6, 31, v30                              // 00000032EC54: 340C3C9F
	.long 0xd7000405                                           // 00000032EC58: D7000405
	v_cndmask_b32_e32 v1, v9, v30, vcc_lo                      // 00000032EC5C: 02023D09
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000032EC60: BF870193
	v_ashrrev_i32_e32 v8, 31, v7                               // 00000032EC64: 34100E9F
	v_add_co_ci_u32_e64 v6, null, v10, v6, s4                  // 00000032EC68: D5207C06 00120D0A
	.long 0xd700041f                                           // 00000032EC70: D700041F
	v_cndmask_b32_e32 v1, v18, v7, vcc_lo                      // 00000032EC74: 02020F12
	s_delay_alu instid0(VALU_DEP_1)                            // 00000032EC78: BF870001
	v_add_co_ci_u32_e64 v32, null, v19, v8, s4                 // 00000032EC7C: D5207C20 00121113
	s_clause 0x1                                               // 00000032EC84: BF850001
	global_load_b128 v[5:8], v[5:6], off                       // 00000032EC88: DC5E0000 057C0005
	global_load_b32 v28, v[31:32], off                         // 00000032EC90: DC520000 1C7C001F
	s_branch 65094                                             // 00000032EC98: BFA0FE46 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x17b4>
	s_mov_b32 s3, 0                                            // 00000032EC9C: BE830080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000032ECA0: BF870009
	s_and_not1_b32 vcc_lo, exec_lo, s3                         // 00000032ECA4: 916A037E
	s_cbranch_vccnz 1011                                       // 00000032ECA8: BFA403F3 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2e78>
	s_load_b256 s[4:11], s[0:1], null                          // 00000032ECAC: F40C0100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 00000032ECB4: 86039F02
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v5, v0              // 00000032ECB8: CA100080 02040100
	s_lshr_b32 s14, s3, 30                                     // 00000032ECC0: 850E9E03
	s_load_b32 s1, s[0:1], 0x1b4                               // 00000032ECC4: F4000040 F80001B4
	s_add_i32 s16, s2, s14                                     // 00000032ECCC: 81100E02
	s_lshl_b64 s[14:15], s[2:3], 2                             // 00000032ECD0: 848E8202
	s_ashr_i32 s3, s16, 2                                      // 00000032ECD4: 86038210
	s_mul_i32 s0, s2, 0x1400                                   // 00000032ECD8: 9600FF02 00001400
	v_dual_mov_b32 v4, 0 :: v_dual_mov_b32 v1, v0              // 00000032ECE0: CA100080 04000100
	s_waitcnt lgkmcnt(0)                                       // 00000032ECE8: BF89FC07
	s_add_u32 s8, s8, s14                                      // 00000032ECEC: 80080E08
	s_addc_u32 s9, s9, s15                                     // 00000032ECF0: 82090F09
	s_add_u32 s0, s4, s0                                       // 00000032ECF4: 80000004
	global_load_b32 v3, v2, s[8:9]                             // 00000032ECF8: DC520000 03080002
	s_mul_hi_i32 s8, s2, 0x1400                                // 00000032ED00: 9708FF02 00001400
	s_mul_i32 s9, s3, 0x1400                                   // 00000032ED08: 9609FF03 00001400
	s_addc_u32 s8, s5, s8                                      // 00000032ED10: 82080805
	s_mul_hi_i32 s14, s3, 0x1400                               // 00000032ED14: 970EFF03 00001400
	s_add_u32 s6, s6, s9                                       // 00000032ED1C: 80060906
	s_addc_u32 s7, s7, s14                                     // 00000032ED20: 82070E07
	s_and_b32 s1, s1, 0xffff                                   // 00000032ED24: 8B01FF01 0000FFFF
	s_mov_b32 s9, 0                                            // 00000032ED2C: BE890080
	s_set_inst_prefetch_distance 0x1                           // 00000032ED30: BF840001
	s_nop 0                                                    // 00000032ED34: BF800000
	s_nop 0                                                    // 00000032ED38: BF800000
	s_nop 0                                                    // 00000032ED3C: BF800000
	.long 0xd73c0006                                           // 00000032ED40: D73C0006
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000032ED44: 02020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000032ED48: BF870091
	.long 0xd7006a08                                           // 00000032ED4C: D7006A08
	v_cndmask_b32_e32 v1, s0, v6, vcc_lo                       // 00000032ED50: 02020C00
	v_add_co_ci_u32_e64 v9, null, s8, v7, vcc_lo               // 00000032ED54: D5207C09 01AA0E08
	.long 0xd7006a06                                           // 00000032ED5C: D7006A06
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 00000032ED60: 02020C06
	s_delay_alu instid0(VALU_DEP_1)                            // 00000032ED64: BF870001
	v_add_co_ci_u32_e64 v7, null, s7, v7, vcc_lo               // 00000032ED68: D5207C07 01AA0E07
	global_load_u16 v10, v[8:9], off                           // 00000032ED70: DC4A0000 0A7C0008
	global_load_u16 v6, v[6:7], off                            // 00000032ED78: DC4A0000 067C0006
	s_waitcnt vmcnt(1)                                         // 00000032ED80: BF8907F7
	v_lshlrev_b32_e32 v7, 16, v10                              // 00000032ED84: 300E1490
	s_waitcnt vmcnt(0)                                         // 00000032ED88: BF8903F7
	v_lshlrev_b32_e32 v6, 16, v6                               // 00000032ED8C: 300C0C90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000032ED90: BF870091
	v_fmac_f32_e32 v7, v3, v6                                  // 00000032ED94: 560E0D03
	v_bfe_u32 v6, v7, 16, 1                                    // 00000032ED98: D6100006 02052107
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000032EDA0: BF870091
	v_add3_u32 v6, v7, v6, 0x7fff                              // 00000032EDA4: D6550006 03FE0D07 00007FFF
	v_and_b32_e32 v7, 0xffff0000, v6                           // 00000032EDB0: 360E0CFF FFFF0000
	v_add_nc_u32_e32 v1, s1, v1                                // 00000032EDB8: 4A020201
	global_store_d16_hi_b16 v[8:9], v6, off                    // 00000032EDBC: DC960000 007C0608
	v_fmac_f32_e32 v4, v7, v7                                  // 00000032EDC4: 56080F07
	v_cmp_lt_u32_e32 vcc_lo, 0x9ff, v1                         // 00000032EDC8: 7C9202FF 000009FF
	s_or_b32 s9, vcc_lo, s9                                    // 00000032EDD0: 8C09096A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000032EDD4: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s9                        // 00000032EDD8: 917E097E
	s_cbranch_execnz 65496                                     // 00000032EDDC: BFA6FFD8 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x1f40>
	s_set_inst_prefetch_distance 0x2                           // 00000032EDE0: BF840002
	s_or_b32 exec_lo, exec_lo, s9                              // 00000032EDE4: 8C7E097E
	v_lshlrev_b32_e32 v1, 2, v0                                // 00000032EDE8: 30020082
	s_lshr_b32 s6, s1, 1                                       // 00000032EDEC: 85068101
	s_mov_b32 s0, 0                                            // 00000032EDF0: BE800080
	ds_store_b32 v1, v4                                        // 00000032EDF4: D8340000 00000401
	s_waitcnt lgkmcnt(0)                                       // 00000032EDFC: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 00000032EE00: BC7C0000
	s_barrier                                                  // 00000032EE04: BFBD0000
	s_branch 17                                                // 00000032EE08: BFA00011 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2050>
	s_nop 0                                                    // 00000032EE0C: BF800000
	s_nop 0                                                    // 00000032EE10: BF800000
	s_nop 0                                                    // 00000032EE14: BF800000
	s_nop 0                                                    // 00000032EE18: BF800000
	s_nop 0                                                    // 00000032EE1C: BF800000
	s_nop 0                                                    // 00000032EE20: BF800000
	s_nop 0                                                    // 00000032EE24: BF800000
	s_nop 0                                                    // 00000032EE28: BF800000
	s_nop 0                                                    // 00000032EE2C: BF800000
	s_nop 0                                                    // 00000032EE30: BF800000
	s_nop 0                                                    // 00000032EE34: BF800000
	s_nop 0                                                    // 00000032EE38: BF800000
	s_nop 0                                                    // 00000032EE3C: BF800000
	s_or_b32 exec_lo, exec_lo, s7                              // 00000032EE40: 8C7E077E
	s_waitcnt lgkmcnt(0)                                       // 00000032EE44: BF89FC07
	s_barrier                                                  // 00000032EE48: BFBD0000
	s_lshr_b32 s6, s6, 1                                       // 00000032EE4C: 85068106
	buffer_gl0_inv                                             // 00000032EE50: E0AC0000 00000000
	s_cbranch_scc0 15                                          // 00000032EE58: BFA1000F <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2098>
	s_mov_b32 s7, exec_lo                                      // 00000032EE5C: BE87007E
	.long 0xd4cc007e                                           // 00000032EE60: D4CC007E
	v_cndmask_b32_e32 v1, s6, v0, vcc_lo                       // 00000032EE64: 02020006
	s_cbranch_execz 65525                                      // 00000032EE68: BFA5FFF5 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2040>
	v_lshl_add_u32 v2, s6, 2, v1                               // 00000032EE6C: D6460002 04050406
	ds_load_b32 v2, v2                                         // 00000032EE74: D8D80000 02000002
	ds_load_b32 v3, v1                                         // 00000032EE7C: D8D80000 03000001
	s_waitcnt lgkmcnt(0)                                       // 00000032EE84: BF89FC07
	v_add_f32_e32 v2, v2, v3                                   // 00000032EE88: 06040702
	ds_store_b32 v1, v2                                        // 00000032EE8C: D8340000 00000201
	s_branch 65514                                             // 00000032EE94: BFA0FFEA <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2040>
	v_mov_b32_e32 v1, 0                                        // 00000032EE98: 7E020280
	s_cmp_eq_u32 s1, 1                                         // 00000032EE9C: BF068101
	s_mul_hi_i32 s6, s2, 0x1400                                // 00000032EEA0: 9706FF02 00001400
	s_mul_i32 s7, s2, 0x1400                                   // 00000032EEA8: 9607FF02 00001400
	ds_load_b32 v1, v1                                         // 00000032EEB0: D8D80000 01000001
	s_waitcnt lgkmcnt(0)                                       // 00000032EEB8: BF89FC07
	v_div_scale_f32 v2, null, 0x45200000, 0x45200000, v1       // 00000032EEBC: D6FC7C02 0405FEFF 45200000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000032EEC8: BF870001
	v_rcp_f32_e32 v3, v2                                       // 00000032EECC: 7E065502
	v_xor_b32_e32 v2, 0x80000000, v2                           // 00000032EED0: 3A0404FF 80000000
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_1)   // 00000032EED8: BF870085
	v_fma_f32 v4, v2, v3, 1.0                                  // 00000032EEDC: D6130004 03CA0702
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000032EEE4: BF8700A1
	v_fmac_f32_e32 v3, v4, v3                                  // 00000032EEE8: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, 0x45200000, v1             // 00000032EEEC: D6FC6A04 0405FF01 45200000
	v_mul_f32_e32 v6, v4, v3                                   // 00000032EEF8: 100C0704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000032EEFC: BF870091
	v_fma_f32 v7, v2, v6, v4                                   // 00000032EF00: D6130007 04120D02
	v_fmac_f32_e32 v6, v7, v3                                  // 00000032EF08: 560C0707
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000032EF0C: BF870091
	v_fmac_f32_e32 v4, v2, v6                                  // 00000032EF10: 56080D02
	v_div_fmas_f32 v2, v4, v3, v6                              // 00000032EF14: D6370002 041A0704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000032EF1C: BF870091
	v_div_fixup_f32 v1, v2, 0x45200000, v1                     // 00000032EF20: D6270001 0405FF02 45200000
	v_add_f32_e32 v1, 0x358637bd, v1                           // 00000032EF2C: 060202FF 358637BD
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000032EF34: BF870121
	v_mul_f32_e32 v2, 0x4b800000, v1                           // 00000032EF38: 100402FF 4B800000
	v_cmp_gt_f32_e32 vcc_lo, 0x800000, v1                      // 00000032EF40: 7C2802FF 00800000
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 00000032EF48: 02020501
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000032EF4C: BF870291
	v_rsq_f32_e32 v1, v1                                       // 00000032EF50: 7E025D01
	v_mul_f32_e32 v2, 0x45800000, v1                           // 00000032EF54: 100402FF 45800000
	s_cbranch_scc1 5                                           // 00000032EF5C: BFA20005 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2174>
	s_mov_b32 s0, -1                                           // 00000032EF60: BE8000C1
	s_delay_alu instid0(VALU_DEP_1)                            // 00000032EF64: BF870001
	v_cndmask_b32_e32 v7, v1, v2, vcc_lo                       // 00000032EF68: 020E0501
	s_cbranch_execz 3                                          // 00000032EF6C: BFA50003 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x217c>
	s_branch 95                                                // 00000032EF70: BFA0005F <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x22f0>
	s_delay_alu instid0(VALU_DEP_1)                            // 00000032EF74: BF870001
	v_cndmask_b32_e32 v7, v1, v2, vcc_lo                       // 00000032EF78: 020E0501
	v_sub_nc_u32_e32 v8, 0xa00, v0                             // 00000032EF7C: 4C1000FF 00000A00
	v_lshl_or_b32 v2, v0, 1, s7                                // 00000032EF84: D6560002 001D0300
	s_mul_i32 s0, s2, 0xa00                                    // 00000032EF8C: 9600FF02 00000A00
	v_mov_b32_e32 v6, s6                                       // 00000032EF94: 7E0C0206
	v_or_b32_e32 v1, s0, v0                                    // 00000032EF98: 38020000
	v_and_b32_e32 v9, 0xbfe, v8                                // 00000032EF9C: 361210FF 00000BFE
	.long 0xd7006a03                                           // 00000032EFA4: D7006A03
	v_cndmask_b32_e32 v1, s4, v2, vcc_lo                       // 00000032EFA8: 02020404
	s_mul_i32 s0, s3, 0x2800                                   // 00000032EFAC: 9600FF03 00002800
	v_add_co_ci_u32_e64 v4, null, s5, v6, vcc_lo               // 00000032EFB4: D5207C04 01AA0C05
	.long 0xd7006a05                                           // 00000032EFBC: D7006A05
	v_cndmask_b32_e32 v1, s20, v2, vcc_lo                      // 00000032EFC0: 02020414
	v_subrev_nc_u32_e32 v1, s0, v1                             // 00000032EFC4: 4E020200
	v_add_co_ci_u32_e64 v6, null, s21, v6, vcc_lo              // 00000032EFC8: D5207C06 01AA0C15
	v_mov_b32_e32 v10, v9                                      // 00000032EFD0: 7E140309
	s_mov_b32 s8, 0                                            // 00000032EFD4: BE880080
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000032EFD8: BF8700B3
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000032EFDC: 3404029F
	global_load_b32 v13, v[3:4], off                           // 00000032EFE0: DC520000 0D7C0003
	.long 0xd73c000b                                           // 00000032EFE8: D73C000B
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000032EFEC: 02020281
	.long 0xd7006a0b                                           // 00000032EFF0: D7006A0B
	v_cndmask_b32_e32 v1, s10, v11, vcc_lo                     // 00000032EFF4: 0202160A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000032EFF8: BF8700A1
	v_add_co_ci_u32_e64 v12, null, s11, v12, vcc_lo            // 00000032EFFC: D5207C0C 01AA180B
	.long 0xd7006a03                                           // 00000032F004: D7006A03
	v_cndmask_b32_e32 v0, v3, v132, vcc_lo                     // 00000032F008: 02010903
	v_add_co_ci_u32_e64 v4, null, 0, v4, vcc_lo                // 00000032F00C: D5207C04 01AA0880
	global_load_b32 v2, v[11:12], off                          // 00000032F014: DC520000 027C000B
	.long 0x7f163880                                           // 00000032F01C: 7F163880
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000032F020: BF8700D1
	.long 0x7f18398b                                           // 00000032F024: 7F18398B
	s_waitcnt vmcnt(1)                                         // 00000032F028: BF8907F7
	.long 0x7e1c390d                                           // 00000032F02C: 7E1C390D
	s_waitcnt vmcnt(0)                                         // 00000032F030: BF8903F7
	.long 0x7e1e3902                                           // 00000032F034: 7E1E3902
	v_lshlrev_b32_e32 v15, 16, v15                             // 00000032F038: 301E1E90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000032F03C: BF870091
	v_dual_add_f32 v15, 1.0, v15 :: v_dual_lshlrev_b32 v14, 16, v14// 00000032F040: C9221EF2 0F0E1C90
	v_dual_mul_f32 v14, v7, v14 :: v_dual_add_nc_u32 v1, 2, v1 // 00000032F048: C8E01D07 0E000282
	v_and_b32_e32 v2, 0xffff0000, v2                           // 00000032F050: 360404FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000032F058: BF870091
	v_dual_add_f32 v2, 1.0, v2 :: v_dual_and_b32 v13, 0xffff0000, v13// 00000032F05C: C92404F2 020C1AFF FFFF0000
	v_dual_mul_f32 v13, v7, v13 :: v_dual_add_nc_u32 v10, -2, v10// 00000032F068: C8E01B07 0D0A14C2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000032F070: BF870111
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 00000032F074: 7C941480
	v_dual_mul_f32 v2, v13, v2 :: v_dual_mul_f32 v13, v14, v15 // 00000032F078: C8C6050D 020C1F0E
	s_or_b32 s8, vcc_lo, s8                                    // 00000032F080: 8C08086A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000032F084: BF870111
	.long 0x7e163982                                           // 00000032F088: 7E163982
	.long 0x7e18398d                                           // 00000032F08C: 7E18398D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000032F090: BF870112
	v_and_b32_e32 v11, 1, v11                                  // 00000032F094: 36161681
	v_and_b32_e32 v12, 1, v12                                  // 00000032F098: 36181881
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000032F09C: BF870112
	v_add3_u32 v2, v2, v11, 0x7fff                             // 00000032F0A0: D6550002 03FE1702 00007FFF
	v_add3_u32 v11, v13, v12, 0x7fff                           // 00000032F0AC: D655000B 03FE190D 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000032F0B8: BF8700B1
	.long 0x7e04398b                                           // 00000032F0BC: 7E04398B
	global_store_b32 v[5:6], v2, off                           // 00000032F0C0: DC6A0000 007C0205
	.long 0xd7000005                                           // 00000032F0C8: D7000005
	v_cndmask_b32_e32 v0, v5, v132, vcc_lo                     // 00000032F0CC: 02010905
	v_add_co_ci_u32_e64 v6, null, 0, v6, s0                    // 00000032F0D0: D5207C06 00020C80
	s_and_not1_b32 exec_lo, exec_lo, s8                        // 00000032F0D8: 917E087E
	s_cbranch_execnz 65470                                     // 00000032F0DC: BFA6FFBE <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x21d8>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000032F0E0: 8C7E087E
	v_add_nc_u32_e32 v5, v0, v9                                // 00000032F0E4: 4A0A1300
	.long 0xd44d0000                                           // 00000032F0E8: D44D0000
	v_cndmask_b32_e32 v1, v8, v9, vcc_lo                       // 00000032F0EC: 02021308
	s_delay_alu instid0(VALU_DEP_1)                            // 00000032F0F0: BF870001
	s_and_saveexec_b32 s8, s0                                  // 00000032F0F4: BE882000
	s_cbranch_execz 79                                         // 00000032F0F8: BFA5004F <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2438>
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000032F0FC: BF8704A2
	v_lshlrev_b32_e32 v1, 1, v5                                // 00000032F100: 30020A81
	s_lshl_b32 s0, s3, 2                                       // 00000032F104: 84008203
	s_sub_i32 s2, s2, s0                                       // 00000032F108: 81820002
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000032F10C: BF870099
	s_mulk_i32 s2, 0xa00                                       // 00000032F110: B8020A00
	.long 0xd7000303                                           // 00000032F114: D7000303
	v_cndmask_b32_e32 v1, s7, v1, vcc_lo                       // 00000032F118: 02020207
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000032F11C: BF8700B1
	v_add_co_ci_u32_e64 v4, null, s6, 0, s3                    // 00000032F120: D5207C04 000D0006
	s_lshl_b32 s3, s1, 1                                       // 00000032F128: 84038101
	.long 0xd7006a01                                           // 00000032F12C: D7006A01
	v_cndmask_b32_e32 v1, s4, v3, vcc_lo                       // 00000032F130: 02020604
	v_add_co_ci_u32_e64 v2, null, s5, v4, vcc_lo               // 00000032F134: D5207C02 01AA0805
	.long 0xd7006a03                                           // 00000032F13C: D7006A03
	v_cndmask_b32_e32 v1, s20, v3, vcc_lo                      // 00000032F140: 02020614
	s_delay_alu instid0(VALU_DEP_1)                            // 00000032F144: BF870001
	v_add_co_ci_u32_e64 v4, null, s21, v4, vcc_lo              // 00000032F148: D5207C04 01AA0815
	s_mov_b32 s4, 0                                            // 00000032F150: BE840080
	s_set_inst_prefetch_distance 0x1                           // 00000032F154: BF840001
	s_nop 0                                                    // 00000032F158: BF800000
	s_nop 0                                                    // 00000032F15C: BF800000
	s_nop 0                                                    // 00000032F160: BF800000
	s_nop 0                                                    // 00000032F164: BF800000
	s_nop 0                                                    // 00000032F168: BF800000
	s_nop 0                                                    // 00000032F16C: BF800000
	s_nop 0                                                    // 00000032F170: BF800000
	s_nop 0                                                    // 00000032F174: BF800000
	s_nop 0                                                    // 00000032F178: BF800000
	s_nop 0                                                    // 00000032F17C: BF800000
	v_add_nc_u32_e32 v8, s2, v5                                // 00000032F180: 4A100A02
	global_load_u16 v6, v[1:2], off                            // 00000032F184: DC4A0000 067C0001
	v_ashrrev_i32_e32 v9, 31, v8                               // 00000032F18C: 3412109F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000032F190: BF870091
	.long 0xd73c0008                                           // 00000032F194: D73C0008
	v_cndmask_b32_e32 v1, 1, v8, vcc_lo                        // 00000032F198: 02021081
	.long 0xd7006a08                                           // 00000032F19C: D7006A08
	v_cndmask_b32_e32 v1, s10, v8, vcc_lo                      // 00000032F1A0: 0202100A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000032F1A4: BF8700A1
	v_add_co_ci_u32_e64 v9, null, s11, v9, vcc_lo              // 00000032F1A8: D5207C09 01AA120B
	.long 0xd7006a01                                           // 00000032F1B0: D7006A01
	v_cndmask_b32_e32 v0, v1, v3, vcc_lo                       // 00000032F1B4: 02000701
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 00000032F1B8: D5207C02 01AA0480
	global_load_u16 v8, v[8:9], off                            // 00000032F1C0: DC4A0000 087C0008
	s_waitcnt vmcnt(1)                                         // 00000032F1C8: BF8907F7
	v_lshlrev_b32_e32 v6, 16, v6                               // 00000032F1CC: 300C0C90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000032F1D0: BF870091
	v_dual_mul_f32 v6, v7, v6 :: v_dual_add_nc_u32 v5, s1, v5  // 00000032F1D4: C8E00D07 06040A01
	v_cmp_lt_u32_e32 vcc_lo, 0x9ff, v5                         // 00000032F1DC: 7C920AFF 000009FF
	s_or_b32 s4, vcc_lo, s4                                    // 00000032F1E4: 8C04046A
	s_waitcnt vmcnt(0)                                         // 00000032F1E8: BF8903F7
	v_lshlrev_b32_e32 v8, 16, v8                               // 00000032F1EC: 30101090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000032F1F0: BF870091
	v_add_f32_e32 v8, 1.0, v8                                  // 00000032F1F4: 061010F2
	v_mul_f32_e32 v6, v6, v8                                   // 00000032F1F8: 100C1106
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000032F1FC: BF870091
	v_bfe_u32 v8, v6, 16, 1                                    // 00000032F200: D6100008 02052106
	v_add3_u32 v6, v6, v8, 0x7fff                              // 00000032F208: D6550006 03FE1106 00007FFF
	global_store_d16_hi_b16 v[3:4], v6, off                    // 00000032F214: DC960000 007C0603
	.long 0xd7000003                                           // 00000032F21C: D7000003
	v_cndmask_b32_e32 v0, v3, v3, vcc_lo                       // 00000032F220: 02000703
	s_delay_alu instid0(VALU_DEP_1)                            // 00000032F224: BF870001
	v_add_co_ci_u32_e64 v4, null, 0, v4, s0                    // 00000032F228: D5207C04 00020880
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000032F230: 917E047E
	s_cbranch_execnz 65490                                     // 00000032F234: BFA6FFD2 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2380>
	s_set_inst_prefetch_distance 0x2                           // 00000032F238: BF840002
	s_or_b32 exec_lo, exec_lo, s8                              // 00000032F23C: 8C7E087E
	s_waitcnt_vscnt null, 0x0                                  // 00000032F240: BC7C0000
	s_barrier                                                  // 00000032F244: BFBD0000
	buffer_gl0_inv                                             // 00000032F248: E0AC0000 00000000
	s_mov_b32 s0, exec_lo                                      // 00000032F250: BE80007E
	v_cmpx_eq_u32_e32 0, v0                                    // 00000032F254: 7D940080
	s_cbranch_execz 647                                        // 00000032F258: BFA50287 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2e78>
	s_mov_b32 s0, exec_lo                                      // 00000032F25C: BE80007E
	buffer_gl1_inv                                             // 00000032F260: E0B00000 00000000
	buffer_gl0_inv                                             // 00000032F268: E0AC0000 00000000
	.long 0xd71f0000                                           // 00000032F270: D71F0000
	v_cndmask_b32_e32 v0, s0, v128, vcc_lo                     // 00000032F274: 02010000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000032F278: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, 0, v0                             // 00000032F27C: 7C940080
	s_and_b32 s1, exec_lo, vcc_lo                              // 00000032F280: 8B016A7E
	s_mov_b32 exec_lo, s1                                      // 00000032F284: BEFE0001
	s_cbranch_execz 635                                        // 00000032F288: BFA5027B <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2e78>
	s_bcnt1_i32_b32 s0, s0                                     // 00000032F28C: BE801800
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000032F290: BF870009
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v0, s0              // 00000032F294: CA100080 01000000
	global_atomic_add_u64 v1, v[0:1], s[12:13]                 // 00000032F29C: DD0E0000 000C0001
	s_nop 0                                                    // 00000032F2A4: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 00000032F2A8: BFB60003
	s_endpgm                                                   // 00000032F2AC: BFB00000
	s_or_b32 exec_lo, exec_lo, s28                             // 00000032F2B0: 8C7E1C7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000032F2B4: BF8700B9
	s_or_b32 exec_lo, exec_lo, s26                             // 00000032F2B8: 8C7E1A7E
	.long 0xd71f0001                                           // 00000032F2BC: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000032F2C0: 020100C1
	s_mov_b32 s4, exec_lo                                      // 00000032F2C4: BE84007E
	v_xor_b32_e32 v2, 16, v1                                   // 00000032F2C8: 3A040290
	v_xor_b32_e32 v10, 8, v1                                   // 00000032F2CC: 3A140288
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000032F2D0: BF8701A2
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 00000032F2D4: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 00000032F2D8: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 00000032F2DC: 7C9814A0
	s_delay_alu instid0(VALU_DEP_2)                            // 00000032F2E0: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 00000032F2E4: 30040482
	ds_bpermute_b32 v5, v2, v26                                // 00000032F2E8: DACC0000 05001A02
	s_waitcnt lgkmcnt(0)                                       // 00000032F2F0: BF89FC07
	v_add_f32_e32 v5, v26, v5                                  // 00000032F2F4: 060A0B1A
	ds_bpermute_b32 v3, v2, v20                                // 00000032F2F8: DACC0000 03001402
	ds_bpermute_b32 v7, v2, v24                                // 00000032F300: DACC0000 07001802
	ds_bpermute_b32 v9, v2, v22                                // 00000032F308: DACC0000 09001602
	ds_bpermute_b32 v4, v2, v27                                // 00000032F310: DACC0000 04001B02
	ds_bpermute_b32 v6, v2, v25                                // 00000032F318: DACC0000 06001902
	ds_bpermute_b32 v8, v2, v23                                // 00000032F320: DACC0000 08001702
	ds_bpermute_b32 v2, v2, v21                                // 00000032F328: DACC0000 02001502
	s_waitcnt lgkmcnt(6)                                       // 00000032F330: BF89FC67
	v_dual_cndmask_b32 v10, v1, v10 :: v_dual_add_f32 v3, v20, v3// 00000032F334: CA481501 0A020714
	s_waitcnt lgkmcnt(5)                                       // 00000032F33C: BF89FC57
	s_delay_alu instid0(VALU_DEP_1)                            // 00000032F340: BF870001
	v_dual_add_f32 v7, v24, v7 :: v_dual_lshlrev_b32 v10, 2, v10// 00000032F344: C9220F18 070A1482
	s_waitcnt lgkmcnt(1)                                       // 00000032F34C: BF89FC17
	v_dual_add_f32 v9, v22, v9 :: v_dual_add_f32 v8, v23, v8   // 00000032F350: C9081316 09081117
	ds_bpermute_b32 v11, v10, v3                               // 00000032F358: DACC0000 0B00030A
	s_waitcnt lgkmcnt(1)                                       // 00000032F360: BF89FC17
	v_add_f32_e32 v2, v21, v2                                  // 00000032F364: 06040515
	v_xor_b32_e32 v21, 4, v1                                   // 00000032F368: 3A2A0284
	ds_bpermute_b32 v16, v10, v5                               // 00000032F36C: DACC0000 1000050A
	ds_bpermute_b32 v18, v10, v7                               // 00000032F374: DACC0000 1200070A
	ds_bpermute_b32 v19, v10, v8                               // 00000032F37C: DACC0000 1300080A
	ds_bpermute_b32 v20, v10, v9                               // 00000032F384: DACC0000 1400090A
	v_cmp_gt_u32_e32 vcc_lo, 32, v21                           // 00000032F38C: 7C982AA0
	v_dual_add_f32 v4, v27, v4 :: v_dual_cndmask_b32 v21, v1, v21// 00000032F390: C912091B 04142B01
	v_add_f32_e32 v6, v25, v6                                  // 00000032F398: 060C0D19
	ds_bpermute_b32 v12, v10, v4                               // 00000032F39C: DACC0000 0C00040A
	v_lshlrev_b32_e32 v21, 2, v21                              // 00000032F3A4: 302A2A82
	ds_bpermute_b32 v17, v10, v6                               // 00000032F3A8: DACC0000 1100060A
	s_waitcnt lgkmcnt(6)                                       // 00000032F3B0: BF89FC67
	v_add_f32_e32 v3, v3, v11                                  // 00000032F3B4: 06061703
	ds_bpermute_b32 v10, v10, v2                               // 00000032F3B8: DACC0000 0A00020A
	s_waitcnt lgkmcnt(6)                                       // 00000032F3C0: BF89FC67
	v_add_f32_e32 v5, v5, v16                                  // 00000032F3C4: 060A2105
	s_waitcnt lgkmcnt(4)                                       // 00000032F3C8: BF89FC47
	v_dual_add_f32 v7, v7, v18 :: v_dual_add_f32 v8, v8, v19   // 00000032F3CC: C9082507 07082708
	s_waitcnt lgkmcnt(3)                                       // 00000032F3D4: BF89FC37
	v_add_f32_e32 v9, v9, v20                                  // 00000032F3D8: 06122909
	ds_bpermute_b32 v18, v21, v8                               // 00000032F3DC: DACC0000 12000815
	ds_bpermute_b32 v19, v21, v9                               // 00000032F3E4: DACC0000 13000915
	s_waitcnt lgkmcnt(4)                                       // 00000032F3EC: BF89FC47
	v_add_f32_e32 v4, v4, v12                                  // 00000032F3F0: 06081904
	s_waitcnt lgkmcnt(3)                                       // 00000032F3F4: BF89FC37
	v_add_f32_e32 v6, v6, v17                                  // 00000032F3F8: 060C2306
	ds_bpermute_b32 v11, v21, v4                               // 00000032F3FC: DACC0000 0B000415
	ds_bpermute_b32 v12, v21, v5                               // 00000032F404: DACC0000 0C000515
	s_waitcnt lgkmcnt(4)                                       // 00000032F40C: BF89FC47
	v_add_f32_e32 v2, v2, v10                                  // 00000032F410: 06041502
	ds_bpermute_b32 v10, v21, v3                               // 00000032F414: DACC0000 0A000315
	ds_bpermute_b32 v16, v21, v6                               // 00000032F41C: DACC0000 10000615
	ds_bpermute_b32 v17, v21, v7                               // 00000032F424: DACC0000 11000715
	ds_bpermute_b32 v20, v21, v2                               // 00000032F42C: DACC0000 14000215
	v_xor_b32_e32 v21, 2, v1                                   // 00000032F434: 3A2A0282
	s_waitcnt lgkmcnt(7)                                       // 00000032F438: BF89FC77
	v_add_f32_e32 v8, v8, v18                                  // 00000032F43C: 06102508
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 00000032F440: BF870152
	v_cmp_gt_u32_e32 vcc_lo, 32, v21                           // 00000032F444: 7C982AA0
	s_waitcnt lgkmcnt(5)                                       // 00000032F448: BF89FC57
	v_dual_cndmask_b32 v21, v1, v21 :: v_dual_add_f32 v4, v4, v11// 00000032F44C: CA482B01 15041704
	s_waitcnt lgkmcnt(4)                                       // 00000032F454: BF89FC47
	v_add_f32_e32 v5, v5, v12                                  // 00000032F458: 060A1905
	v_lshlrev_b32_e32 v21, 2, v21                              // 00000032F45C: 302A2A82
	s_waitcnt lgkmcnt(2)                                       // 00000032F460: BF89FC27
	v_dual_add_f32 v3, v3, v10 :: v_dual_add_f32 v6, v6, v16   // 00000032F464: C9081503 03062106
	s_waitcnt lgkmcnt(1)                                       // 00000032F46C: BF89FC17
	v_add_f32_e32 v7, v7, v17                                  // 00000032F470: 060E2307
	s_waitcnt lgkmcnt(0)                                       // 00000032F474: BF89FC07
	v_dual_add_f32 v9, v9, v19 :: v_dual_add_f32 v10, v2, v20  // 00000032F478: C9082709 090A2902
	ds_bpermute_b32 v2, v21, v3                                // 00000032F480: DACC0000 02000315
	ds_bpermute_b32 v11, v21, v4                               // 00000032F488: DACC0000 0B000415
	ds_bpermute_b32 v12, v21, v5                               // 00000032F490: DACC0000 0C000515
	ds_bpermute_b32 v16, v21, v6                               // 00000032F498: DACC0000 10000615
	ds_bpermute_b32 v17, v21, v7                               // 00000032F4A0: DACC0000 11000715
	ds_bpermute_b32 v18, v21, v8                               // 00000032F4A8: DACC0000 12000815
	ds_bpermute_b32 v19, v21, v9                               // 00000032F4B0: DACC0000 13000915
	ds_bpermute_b32 v20, v21, v10                              // 00000032F4B8: DACC0000 14000A15
	v_xor_b32_e32 v21, 1, v1                                   // 00000032F4C0: 3A2A0281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000032F4C4: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v21                           // 00000032F4C8: 7C982AA0
	v_cndmask_b32_e32 v1, v1, v21, vcc_lo                      // 00000032F4CC: 02022B01
	v_lshlrev_b32_e32 v21, 2, v1                               // 00000032F4D0: 302A0282
	s_waitcnt lgkmcnt(6)                                       // 00000032F4D4: BF89FC67
	v_dual_add_f32 v1, v3, v2 :: v_dual_add_f32 v2, v4, v11    // 00000032F4D8: C9080503 01021704
	s_waitcnt lgkmcnt(5)                                       // 00000032F4E0: BF89FC57
	v_add_f32_e32 v4, v5, v12                                  // 00000032F4E4: 06081905
	s_waitcnt lgkmcnt(4)                                       // 00000032F4E8: BF89FC47
	v_add_f32_e32 v5, v6, v16                                  // 00000032F4EC: 060A2106
	s_waitcnt lgkmcnt(0)                                       // 00000032F4F0: BF89FC07
	v_dual_add_f32 v3, v7, v17 :: v_dual_add_f32 v16, v10, v20 // 00000032F4F4: C9082307 0310290A
	v_dual_add_f32 v11, v8, v18 :: v_dual_add_f32 v12, v9, v19 // 00000032F4FC: C9082508 0B0C2709
	ds_bpermute_b32 v6, v21, v1                                // 00000032F504: DACC0000 06000115
	ds_bpermute_b32 v7, v21, v2                                // 00000032F50C: DACC0000 07000215
	ds_bpermute_b32 v9, v21, v4                                // 00000032F514: DACC0000 09000415
	ds_bpermute_b32 v10, v21, v5                               // 00000032F51C: DACC0000 0A000515
	ds_bpermute_b32 v8, v21, v3                                // 00000032F524: DACC0000 08000315
	ds_bpermute_b32 v17, v21, v11                              // 00000032F52C: DACC0000 11000B15
	ds_bpermute_b32 v18, v21, v12                              // 00000032F534: DACC0000 12000C15
	ds_bpermute_b32 v19, v21, v16                              // 00000032F53C: DACC0000 13001015
	v_cmpx_eq_u32_e32 0, v15                                   // 00000032F544: 7D941E80
	s_cbranch_execz 16                                         // 00000032F548: BFA50010 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x278c>
	v_lshlrev_b32_e32 v13, s24, v13                            // 00000032F54C: 301A1A18
	s_waitcnt lgkmcnt(0)                                       // 00000032F550: BF89FC07
	v_add_f32_e32 v19, v16, v19                                // 00000032F554: 06262710
	v_dual_add_f32 v18, v12, v18 :: v_dual_add_f32 v17, v11, v17// 00000032F558: C908250C 1210230B
	v_dual_add_f32 v12, v5, v10 :: v_dual_add_f32 v11, v4, v9  // 00000032F560: C9081505 0C0A1304
	v_add_f32_e32 v16, v3, v8                                  // 00000032F568: 06201103
	v_dual_add_f32 v10, v2, v7 :: v_dual_add_f32 v9, v1, v6    // 00000032F56C: C9080F02 0A080D01
	v_add_lshl_u32 v1, v13, v14, 5                             // 00000032F574: D6470001 02161D0D
	ds_store_b128 v1, v[9:12] offset:1280                      // 00000032F57C: DB7C0500 00000901
	ds_store_b128 v1, v[16:19] offset:1296                     // 00000032F584: DB7C0510 00001001
	s_or_b32 exec_lo, exec_lo, s4                              // 00000032F58C: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000032F590: BF870009
	s_and_b32 s4, s19, exec_lo                                 // 00000032F594: 8B047E13
	s_cselect_b32 s4, 8, 32                                    // 00000032F598: 9804A088
	s_mov_b32 s19, exec_lo                                     // 00000032F59C: BE93007E
	s_waitcnt lgkmcnt(0)                                       // 00000032F5A0: BF89FC07
	s_barrier                                                  // 00000032F5A4: BFBD0000
	buffer_gl0_inv                                             // 00000032F5A8: E0AC0000 00000000
	.long 0xd4cc007e                                           // 00000032F5B0: D4CC007E
	v_cndmask_b32_e32 v1, s4, v0, vcc_lo                       // 00000032F5B4: 02020004
	s_cbranch_execz 404                                        // 00000032F5B8: BFA50194 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2e0c>
	s_load_b32 s4, s[8:9], 0x40                                // 00000032F5BC: F4000104 F8000040
	v_lshrrev_b32_e32 v5, 3, v0                                // 00000032F5C4: 320A0083
	v_mov_b32_e32 v4, 0                                        // 00000032F5C8: 7E080280
	s_waitcnt lgkmcnt(0)                                       // 00000032F5CC: BF89FC07
	s_sub_i32 s4, s5, s4                                       // 00000032F5D0: 81840405
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000032F5D4: BF870499
	s_ashr_i32 s5, s4, 31                                      // 00000032F5D8: 86059F04
	s_lshl_b64 s[4:5], s[4:5], s25                             // 00000032F5DC: 84841904
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000032F5E0: BF870099
	.long 0xd7000401                                           // 00000032F5E4: D7000401
	v_cndmask_b32_e32 v1, s4, v5, vcc_lo                       // 00000032F5E8: 02020A04
	v_add_co_ci_u32_e64 v2, null, s5, 0, s4                    // 00000032F5EC: D5207C02 00110005
	s_delay_alu instid0(VALU_DEP_1)                            // 00000032F5F4: BF870001
	v_cmp_gt_i64_e32 vcc_lo, s[6:7], v[1:2]                    // 00000032F5F8: 7CA80206
	s_and_b32 exec_lo, exec_lo, vcc_lo                         // 00000032F5FC: 8B7E6A7E
	s_cbranch_execz 386                                        // 00000032F600: BFA50182 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2e0c>
	v_and_b32_e32 v3, 7, v0                                    // 00000032F604: 36060087
	v_lshlrev_b32_e32 v5, s24, v5                              // 00000032F608: 300A0A18
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000032F60C: BF870092
	v_lshlrev_b32_e32 v6, 2, v3                                // 00000032F610: 300C0682
	v_lshl_or_b32 v5, v5, 5, v6                                // 00000032F614: D6560005 04190B05
	ds_load_b32 v6, v5 offset:1280                             // 00000032F61C: D8D80500 06000005
	v_add_nc_u32_e32 v5, 32, v5                                // 00000032F624: 4A0A0AA0
	s_add_i32 s18, s18, -1                                     // 00000032F628: 8112C112
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000032F62C: BF870009
	s_cmp_eq_u32 s18, 0                                        // 00000032F630: BF068012
	s_waitcnt lgkmcnt(0)                                       // 00000032F634: BF89FC07
	v_add_f32_e32 v4, v4, v6                                   // 00000032F638: 06080D04
	s_cbranch_scc0 65527                                       // 00000032F63C: BFA1FFF7 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x281c>
	s_clause 0x1                                               // 00000032F640: BF850001
	s_load_b64 s[14:15], s[8:9], 0x38                          // 00000032F644: F4040384 F8000038
	s_load_b64 s[10:11], s[8:9], 0x8                           // 00000032F64C: F4040284 F8000008
	s_mov_b32 s18, -1                                          // 00000032F654: BE9200C1
	s_mov_b32 s5, 0                                            // 00000032F658: BE850080
	s_mov_b32 s4, 0                                            // 00000032F65C: BE840080
	s_waitcnt lgkmcnt(0)                                       // 00000032F660: BF89FC07
	s_cmp_lt_i32 s15, 3                                        // 00000032F664: BF04830F
	s_cbranch_scc1 195                                         // 00000032F668: BFA200C3 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2b78>
	s_cmp_gt_i32 s15, 3                                        // 00000032F66C: BF02830F
	s_cbranch_scc0 73                                          // 00000032F670: BFA10049 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2998>
	s_cmp_gt_i32 s15, 4                                        // 00000032F674: BF02840F
	s_cbranch_scc0 73                                          // 00000032F678: BFA10049 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x29a0>
	s_cmp_eq_u32 s15, 5                                        // 00000032F67C: BF06850F
	s_mov_b32 s4, -1                                           // 00000032F680: BE8400C1
	s_cbranch_scc0 66                                          // 00000032F684: BFA10042 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2990>
	v_lshrrev_b32_e32 v5, 23, v2                               // 00000032F688: 320A0497
	s_lshr_b32 s4, s7, 31                                      // 00000032F68C: 85049F07
	s_load_b64 s[8:9], s[8:9], 0x10                            // 00000032F690: F4040204 F8000010
	s_add_u32 s22, s6, s4                                      // 00000032F698: 80160406
	s_addc_u32 s23, s7, 0                                      // 00000032F69C: 82178007
	.long 0xd7006a05                                           // 00000032F6A0: D7006A05
	v_cndmask_b32_e32 v1, v1, v5, vcc_lo                       // 00000032F6A4: 02020B01
	s_ashr_i64 s[22:23], s[22:23], 1                           // 00000032F6A8: 86968116
	v_add_co_ci_u32_e64 v10, null, 0, v2, vcc_lo               // 00000032F6AC: D5207C0A 01AA0480
	v_dual_mov_b32 v12, s11 :: v_dual_and_b32 v11, 0xfffffe00, v5// 00000032F6B4: CA24000B 0C0A0AFF FFFFFE00
	v_mad_u64_u32 v[5:6], null, s22, v3, 0                     // 00000032F6C0: D6FE7C05 02020616
	v_bfe_u32 v15, v4, 16, 1                                   // 00000032F6C8: D610000F 02052104
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000032F6D0: BF870093
	.long 0xd7016a08                                           // 00000032F6D4: D7016A08
	v_cndmask_b32_e32 v1, v1, v11, vcc_lo                      // 00000032F6D8: 02021701
	v_sub_co_ci_u32_e64 v9, null, v2, v10, vcc_lo              // 00000032F6DC: D5217C09 01AA1502
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000032F6E4: BF870194
	v_mad_u64_u32 v[6:7], null, s23, v3, v[6:7]                // 00000032F6E8: D6FE7C06 041A0617
	.long 0xd700040d                                           // 00000032F6F0: D700040D
	v_cndmask_b32_e32 v1, 0xffffff00, v8, vcc_lo               // 00000032F6F4: 020210FF FFFFFF00
	s_delay_alu instid0(VALU_DEP_3)                            // 00000032F6FC: BF870003
	v_cmp_gt_i64_e32 vcc_lo, 0x100, v[8:9]                     // 00000032F700: 7CA810FF 00000100
	v_mov_b32_e32 v7, s10                                      // 00000032F708: 7E0E020A
	v_add_co_ci_u32_e64 v14, null, -1, v9, s4                  // 00000032F70C: D5207C0E 001212C1
	s_mov_b32 s4, 0                                            // 00000032F714: BE840080
	.long 0xd73c0005                                           // 00000032F718: D73C0005
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 00000032F71C: 02020A81
	s_waitcnt lgkmcnt(0)                                       // 00000032F720: BF89FC07
	v_dual_cndmask_b32 v8, v13, v8 :: v_dual_cndmask_b32 v7, s8, v7// 00000032F724: CA52110D 08060E08
	v_dual_cndmask_b32 v12, s9, v12 :: v_dual_cndmask_b32 v9, v14, v9// 00000032F72C: CA521809 0C08130E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000032F734: BF870092
	.long 0xd7006a07                                           // 00000032F738: D7006A07
	v_cndmask_b32_e32 v1, v7, v5, vcc_lo                       // 00000032F73C: 02020B07
	v_add_co_ci_u32_e64 v12, null, v12, v6, vcc_lo             // 00000032F740: D5207C0C 01AA0D0C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000032F748: BF870193
	.long 0xd73c0005                                           // 00000032F74C: D73C0005
	v_cndmask_b32_e32 v1, 1, v8, vcc_lo                        // 00000032F750: 02021081
	.long 0xd7006a07                                           // 00000032F754: D7006A07
	v_cndmask_b32_e32 v1, v7, v11, vcc_lo                      // 00000032F758: 02021707
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000032F75C: BF8701A1
	v_add_co_ci_u32_e64 v8, null, v12, v10, vcc_lo             // 00000032F760: D5207C08 01AA150C
	v_add3_u32 v9, v4, v15, 0x7fff                             // 00000032F768: D6550009 03FE1F04 00007FFF
	.long 0xd7006a05                                           // 00000032F774: D7006A05
	v_cndmask_b32_e32 v1, v7, v5, vcc_lo                       // 00000032F778: 02020B07
	s_delay_alu instid0(VALU_DEP_1)                            // 00000032F77C: BF870001
	v_add_co_ci_u32_e64 v6, null, v8, v6, vcc_lo               // 00000032F780: D5207C06 01AA0D08
	global_store_d16_hi_b16 v[5:6], v9, off                    // 00000032F788: DC960000 007C0905
	s_mov_b32 s8, 0                                            // 00000032F790: BE880080
	s_branch 3                                                 // 00000032F794: BFA00003 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x29a4>
	s_mov_b32 s8, -1                                           // 00000032F798: BE8800C1
	s_branch 54                                                // 00000032F79C: BFA00036 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2a78>
	s_mov_b32 s8, -1                                           // 00000032F7A0: BE8800C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000032F7A4: BF870009
	s_and_b32 vcc_lo, exec_lo, s8                              // 00000032F7A8: 8B6A087E
	s_cbranch_vccz 49                                          // 00000032F7AC: BFA30031 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2a74>
	v_mul_f32_e32 v5, 0xbfb8aa3b, v4                           // 00000032F7B0: 100A08FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000032F7B8: BF870291
	v_exp_f32_e32 v5, v5                                       // 00000032F7BC: 7E0A4B05
	v_add_f32_e32 v9, 1.0, v5                                  // 00000032F7C0: 06120AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000032F7C4: BF870091
	v_div_scale_f32 v8, null, v9, v9, 1.0                      // 00000032F7C8: D6FC7C08 03CA1309
	v_rcp_f32_e32 v10, v8                                      // 00000032F7D0: 7E145508
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000032F7D4: BF870095
	v_fma_f32 v5, -v8, v10, 1.0                                // 00000032F7D8: D6130005 23CA1508
	v_fmac_f32_e32 v10, v5, v10                                // 00000032F7E0: 56141505
	v_div_scale_f32 v11, vcc_lo, 1.0, v9, 1.0                  // 00000032F7E4: D6FC6A0B 03CA12F2
	v_mad_u64_u32 v[5:6], null, s6, v3, 0                      // 00000032F7EC: D6FE7C05 02020606
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000032F7F4: BF870112
	v_mul_f32_e32 v12, v11, v10                                // 00000032F7F8: 1018150B
	v_mad_u64_u32 v[6:7], null, s7, v3, v[6:7]                 // 00000032F7FC: D6FE7C06 041A0607
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000032F804: BF870092
	v_fma_f32 v13, -v8, v12, v11                               // 00000032F808: D613000D 242E1908
	v_fmac_f32_e32 v12, v13, v10                               // 00000032F810: 5618150D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000032F814: BF870113
	.long 0xd73c0005                                           // 00000032F818: D73C0005
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 00000032F81C: 02020A82
	v_fma_f32 v11, -v8, v12, v11                               // 00000032F820: D613000B 242E1908
	.long 0xd73c0007                                           // 00000032F828: D73C0007
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000032F82C: 02020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000032F830: BF870212
	v_div_fmas_f32 v10, v11, v10, v12                          // 00000032F834: D637000A 0432150B
	.long 0xd7006a05                                           // 00000032F83C: D7006A05
	v_cndmask_b32_e32 v1, s10, v5, vcc_lo                      // 00000032F840: 02020A0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000032F844: BF870191
	v_add_co_ci_u32_e64 v6, null, s11, v6, vcc_lo              // 00000032F848: D5207C06 01AA0C0B
	v_div_fixup_f32 v9, v10, v9, 1.0                           // 00000032F850: D6270009 03CA130A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000032F858: BF870093
	.long 0xd7006a05                                           // 00000032F85C: D7006A05
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 00000032F860: 02020F05
	v_add_co_ci_u32_e64 v6, null, v6, v8, vcc_lo               // 00000032F864: D5207C06 01AA1106
	global_store_b32 v[5:6], v9, off                           // 00000032F86C: DC6A0000 007C0905
	s_mov_b32 s8, 0                                            // 00000032F874: BE880080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000032F878: BF870009
	s_and_b32 vcc_lo, exec_lo, s8                              // 00000032F87C: 8B6A087E
	s_cbranch_vccz 60                                          // 00000032F880: BFA3003C <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2b74>
	v_bfe_u32 v5, v4, 16, 1                                    // 00000032F884: D6100005 02052104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000032F88C: BF870091
	v_add3_u32 v5, v4, v5, 0x7fff                              // 00000032F890: D6550005 03FE0B04 00007FFF
	v_and_b32_e32 v5, 0xffff0000, v5                           // 00000032F89C: 360A0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000032F8A4: BF870091
	v_mul_f32_e32 v5, s14, v5                                  // 00000032F8A8: 100A0A0E
	v_mul_f32_e32 v5, 0xbfb8aa3b, v5                           // 00000032F8AC: 100A0AFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000032F8B4: BF870291
	v_exp_f32_e32 v5, v5                                       // 00000032F8B8: 7E0A4B05
	v_add_f32_e32 v9, 1.0, v5                                  // 00000032F8BC: 06120AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000032F8C0: BF870091
	v_div_scale_f32 v8, null, v9, v9, 1.0                      // 00000032F8C4: D6FC7C08 03CA1309
	v_rcp_f32_e32 v10, v8                                      // 00000032F8CC: 7E145508
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000032F8D0: BF870095
	v_fma_f32 v5, -v8, v10, 1.0                                // 00000032F8D4: D6130005 23CA1508
	v_fmac_f32_e32 v10, v5, v10                                // 00000032F8DC: 56141505
	v_div_scale_f32 v11, vcc_lo, 1.0, v9, 1.0                  // 00000032F8E0: D6FC6A0B 03CA12F2
	v_mad_u64_u32 v[5:6], null, s6, v3, 0                      // 00000032F8E8: D6FE7C05 02020606
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000032F8F0: BF870092
	v_mul_f32_e32 v12, v11, v10                                // 00000032F8F4: 1018150B
	v_fma_f32 v7, -v8, v12, v11                                // 00000032F8F8: D6130007 242E1908
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000032F900: BF870211
	v_fmac_f32_e32 v12, v7, v10                                // 00000032F904: 56181507
	v_mad_u64_u32 v[6:7], null, s7, v3, v[6:7]                 // 00000032F908: D6FE7C06 041A0607
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000032F910: BF870112
	v_fma_f32 v7, -v8, v12, v11                                // 00000032F914: D6130007 242E1908
	.long 0xd73c0005                                           // 00000032F91C: D73C0005
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 00000032F920: 02020A82
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000032F924: BF8701A2
	v_div_fmas_f32 v10, v7, v10, v12                           // 00000032F928: D637000A 04321507
	.long 0xd73c0007                                           // 00000032F930: D73C0007
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000032F934: 02020282
	.long 0xd7006a05                                           // 00000032F938: D7006A05
	v_cndmask_b32_e32 v1, s10, v5, vcc_lo                      // 00000032F93C: 02020A0A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000032F940: BF8701A3
	v_div_fixup_f32 v9, v10, v9, 1.0                           // 00000032F944: D6270009 03CA130A
	v_add_co_ci_u32_e64 v6, null, s11, v6, vcc_lo              // 00000032F94C: D5207C06 01AA0C0B
	.long 0xd7006a05                                           // 00000032F954: D7006A05
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 00000032F958: 02020F05
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000032F95C: BF870193
	v_add_f32_e32 v9, v9, v9                                   // 00000032F960: 06121309
	v_add_co_ci_u32_e64 v6, null, v6, v8, vcc_lo               // 00000032F964: D5207C06 01AA1106
	global_store_b32 v[5:6], v9, off                           // 00000032F96C: DC6A0000 007C0905
	s_mov_b32 s18, 0                                           // 00000032F974: BE920080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000032F978: BF870009
	s_and_b32 vcc_lo, exec_lo, s18                             // 00000032F97C: 8B6A127E
	s_cbranch_vccz 73                                          // 00000032F980: BFA30049 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2ca8>
	s_cmp_gt_i32 s15, 1                                        // 00000032F984: BF02810F
	s_mov_b32 s5, -1                                           // 00000032F988: BE8500C1
	s_cbranch_scc0 64                                          // 00000032F98C: BFA10040 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2c90>
	v_bfe_u32 v5, v4, 16, 1                                    // 00000032F990: D6100005 02052104
	s_mov_b32 s5, 0                                            // 00000032F998: BE850080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000032F99C: BF870091
	v_add3_u32 v5, v4, v5, 0x7fff                              // 00000032F9A0: D6550005 03FE0B04 00007FFF
	v_and_b32_e32 v5, 0xffff0000, v5                           // 00000032F9AC: 360A0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000032F9B4: BF870091
	v_mul_f32_e32 v5, 0xbfb8aa3b, v5                           // 00000032F9B8: 100A0AFF BFB8AA3B
	v_exp_f32_e32 v5, v5                                       // 00000032F9C0: 7E0A4B05
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000032F9C4: BF870095
	v_add_f32_e32 v8, 1.0, v5                                  // 00000032F9C8: 06100AF2
	v_div_scale_f32 v7, null, v8, v8, 1.0                      // 00000032F9CC: D6FC7C07 03CA1108
	v_div_scale_f32 v10, vcc_lo, 1.0, v8, 1.0                  // 00000032F9D4: D6FC6A0A 03CA10F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000032F9DC: BF870292
	v_rcp_f32_e32 v9, v7                                       // 00000032F9E0: 7E125507
	v_fma_f32 v5, -v7, v9, 1.0                                 // 00000032F9E4: D6130005 23CA1307
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000032F9EC: BF870121
	v_fmac_f32_e32 v9, v5, v9                                  // 00000032F9F0: 56121305
	v_mad_u64_u32 v[5:6], null, s6, v3, 0                      // 00000032F9F4: D6FE7C05 02020606
	v_mul_f32_e32 v11, v10, v9                                 // 00000032F9FC: 1016130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000032FA00: BF870091
	v_fma_f32 v12, -v7, v11, v10                               // 00000032FA04: D613000C 242A1707
	v_fmac_f32_e32 v11, v12, v9                                // 00000032FA0C: 5616130C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000032FA10: BF870121
	v_fma_f32 v10, -v7, v11, v10                               // 00000032FA14: D613000A 242A1707
	v_mad_u64_u32 v[6:7], null, s7, v3, v[6:7]                 // 00000032FA1C: D6FE7C06 041A0607
	v_div_fmas_f32 v7, v10, v9, v11                            // 00000032FA24: D6370007 042E130A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000032FA2C: BF870112
	.long 0xd73c0005                                           // 00000032FA30: D73C0005
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 00000032FA34: 02020A81
	v_div_fixup_f32 v9, v7, v8, 1.0                            // 00000032FA38: D6270009 03CA1107
	.long 0xd73c0007                                           // 00000032FA40: D73C0007
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000032FA44: 02020281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000032FA48: BF870193
	.long 0xd7006a05                                           // 00000032FA4C: D7006A05
	v_cndmask_b32_e32 v1, s10, v5, vcc_lo                      // 00000032FA50: 02020A0A
	v_bfe_u32 v10, v9, 16, 1                                   // 00000032FA54: D610000A 02052109
	v_add_co_ci_u32_e64 v6, null, s11, v6, vcc_lo              // 00000032FA5C: D5207C06 01AA0C0B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000032FA64: BF870193
	.long 0xd7006a05                                           // 00000032FA68: D7006A05
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 00000032FA6C: 02020F05
	v_add3_u32 v9, v9, v10, 0x7fff                             // 00000032FA70: D6550009 03FE1509 00007FFF
	s_delay_alu instid0(VALU_DEP_3)                            // 00000032FA7C: BF870003
	v_add_co_ci_u32_e64 v6, null, v6, v8, vcc_lo               // 00000032FA80: D5207C06 01AA1106
	global_store_d16_hi_b16 v[5:6], v9, off                    // 00000032FA88: DC960000 007C0905
	s_and_not1_b32 vcc_lo, exec_lo, s5                         // 00000032FA90: 916A057E
	s_mov_b32 s5, 0                                            // 00000032FA94: BE850080
	s_cbranch_vccnz 3                                          // 00000032FA98: BFA40003 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2ca8>
	s_cmp_lg_u32 s15, 1                                        // 00000032FA9C: BF07810F
	s_mov_b32 s5, -1                                           // 00000032FAA0: BE8500C1
	s_cselect_b32 s4, -1, 0                                    // 00000032FAA4: 980480C1
	v_bfe_u32 v5, v4, 16, 1                                    // 00000032FAA8: D6100005 02052104
	.long 0xd73c0001                                           // 00000032FAB0: D73C0001
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000032FAB4: 02020281
	s_and_b32 vcc_lo, exec_lo, s4                              // 00000032FAB8: 8B6A047E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000032FABC: BF870002
	v_add3_u32 v4, v4, v5, 0x7fff                              // 00000032FAC0: D6550004 03FE0B04 00007FFF
	s_cbranch_vccz 20                                          // 00000032FACC: BFA30014 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2d20>
	v_mad_u64_u32 v[5:6], null, s6, v3, 0                      // 00000032FAD0: D6FE7C05 02020606
	s_mov_b32 s5, 0                                            // 00000032FAD8: BE850080
	v_mad_u64_u32 v[6:7], null, s7, v3, v[6:7]                 // 00000032FADC: D6FE7C06 041A0607
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000032FAE4: BF870091
	.long 0xd73c0005                                           // 00000032FAE8: D73C0005
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 00000032FAEC: 02020A81
	.long 0xd7006a05                                           // 00000032FAF0: D7006A05
	v_cndmask_b32_e32 v1, s10, v5, vcc_lo                      // 00000032FAF4: 02020A0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000032FAF8: BF870111
	v_add_co_ci_u32_e64 v6, null, s11, v6, vcc_lo              // 00000032FAFC: D5207C06 01AA0C0B
	.long 0xd7006a05                                           // 00000032FB04: D7006A05
	v_cndmask_b32_e32 v1, v5, v1, vcc_lo                       // 00000032FB08: 02020305
	s_delay_alu instid0(VALU_DEP_1)                            // 00000032FB0C: BF870001
	v_add_co_ci_u32_e64 v6, null, v6, v2, vcc_lo               // 00000032FB10: D5207C06 01AA0506
	global_store_d16_hi_b16 v[5:6], v4, off                    // 00000032FB18: DC960000 007C0405
	s_and_not1_b32 vcc_lo, exec_lo, s5                         // 00000032FB20: 916A057E
	s_cbranch_vccnz 57                                         // 00000032FB24: BFA40039 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2e0c>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000032FB28: BF870091
	v_and_b32_e32 v4, 0xffff0000, v4                           // 00000032FB2C: 360808FF FFFF0000
	v_mul_f32_e32 v7, s14, v4                                  // 00000032FB34: 100E080E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000032FB38: BF870091
	v_mul_f32_e32 v4, 0xbfb8aa3b, v7                           // 00000032FB3C: 10080EFF BFB8AA3B
	v_exp_f32_e32 v4, v4                                       // 00000032FB44: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000032FB48: BF870095
	v_add_f32_e32 v8, 1.0, v4                                  // 00000032FB4C: 061008F2
	v_div_scale_f32 v6, null, v8, v8, v7                       // 00000032FB50: D6FC7C06 041E1108
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000032FB58: BF870291
	v_rcp_f32_e32 v9, v6                                       // 00000032FB5C: 7E125506
	v_fma_f32 v4, -v6, v9, 1.0                                 // 00000032FB60: D6130004 23CA1306
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000032FB68: BF870131
	v_fmac_f32_e32 v9, v4, v9                                  // 00000032FB6C: 56121304
	v_div_scale_f32 v10, vcc_lo, v7, v8, v7                    // 00000032FB70: D6FC6A0A 041E1107
	v_mad_u64_u32 v[4:5], null, s6, v3, 0                      // 00000032FB78: D6FE7C04 02020606
	v_mul_f32_e32 v11, v10, v9                                 // 00000032FB80: 1016130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000032FB84: BF870091
	v_fma_f32 v12, -v6, v11, v10                               // 00000032FB88: D613000C 242A1706
	v_fmac_f32_e32 v11, v12, v9                                // 00000032FB90: 5616130C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000032FB94: BF870121
	v_fma_f32 v10, -v6, v11, v10                               // 00000032FB98: D613000A 242A1706
	v_mad_u64_u32 v[5:6], null, s7, v3, v[5:6]                 // 00000032FBA0: D6FE7C05 04160607
	v_div_fmas_f32 v3, v10, v9, v11                            // 00000032FBA8: D6370003 042E130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000032FBB0: BF870191
	v_div_fixup_f32 v6, v3, v8, v7                             // 00000032FBB4: D6270006 041E1103
	.long 0xd73c0003                                           // 00000032FBBC: D73C0003
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 00000032FBC0: 02020881
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000032FBC4: BF870112
	v_bfe_u32 v5, v6, 16, 1                                    // 00000032FBC8: D6100005 02052106
	.long 0xd7006a03                                           // 00000032FBD0: D7006A03
	v_cndmask_b32_e32 v1, s10, v3, vcc_lo                      // 00000032FBD4: 0202060A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000032FBD8: BF870191
	v_add_co_ci_u32_e64 v4, null, s11, v4, vcc_lo              // 00000032FBDC: D5207C04 01AA080B
	v_add3_u32 v5, v6, v5, 0x7fff                              // 00000032FBE4: D6550005 03FE0B06 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000032FBF0: BF870093
	.long 0xd7006a01                                           // 00000032FBF4: D7006A01
	v_cndmask_b32_e32 v1, v3, v1, vcc_lo                       // 00000032FBF8: 02020303
	v_add_co_ci_u32_e64 v2, null, v4, v2, vcc_lo               // 00000032FBFC: D5207C02 01AA0504
	global_store_d16_hi_b16 v[1:2], v5, off                    // 00000032FC04: DC960000 007C0501
	s_or_b32 exec_lo, exec_lo, s19                             // 00000032FC0C: 8C7E137E
	s_waitcnt_vscnt null, 0x0                                  // 00000032FC10: BC7C0000
	s_barrier                                                  // 00000032FC14: BFBD0000
	buffer_gl0_inv                                             // 00000032FC18: E0AC0000 00000000
	s_and_saveexec_b32 s4, s3                                  // 00000032FC20: BE842003
	s_cbranch_execz 18                                         // 00000032FC24: BFA50012 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2e70>
	s_mov_b32 s3, exec_lo                                      // 00000032FC28: BE83007E
	buffer_gl1_inv                                             // 00000032FC2C: E0B00000 00000000
	buffer_gl0_inv                                             // 00000032FC34: E0AC0000 00000000
	.long 0xd71f0001                                           // 00000032FC3C: D71F0001
	v_cndmask_b32_e32 v0, s3, v128, vcc_lo                     // 00000032FC40: 02010003
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000032FC44: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 00000032FC48: 7C940280
	s_and_b32 s5, exec_lo, vcc_lo                              // 00000032FC4C: 8B056A7E
	s_mov_b32 exec_lo, s5                                      // 00000032FC50: BEFE0005
	s_cbranch_execz 6                                          // 00000032FC54: BFA50006 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2e70>
	s_bcnt1_i32_b32 s3, s3                                     // 00000032FC58: BE831803
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000032FC5C: BF870009
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v1, s3              // 00000032FC60: CA100080 02000003
	global_atomic_add_u64 v2, v[1:2], s[16:17]                 // 00000032FC68: DD0E0000 00100102
	s_or_b32 exec_lo, exec_lo, s4                              // 00000032FC70: 8C7E047E
	s_cbranch_execz 64525                                      // 00000032FC74: BFA5FC0D <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi8EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x1eac>
	s_nop 0                                                    // 00000032FC78: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 00000032FC7C: BFB60003
	s_endpgm                                                   // 00000032FC80: BFB00000
		...

