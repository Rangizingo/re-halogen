000000000029e300 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl>:
; _ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl():
	s_clause 0x3                                               // 00000029E300: BF850003
	s_load_b32 s3, s[0:1], 0x120                               // 00000029E304: F40000C0 F8000120
	s_load_b32 s4, s[0:1], 0x88                                // 00000029E30C: F4000100 F8000088
	s_load_b32 s5, s[0:1], 0xd0                                // 00000029E314: F4000140 F80000D0
	s_load_b32 s6, s[0:1], 0x118                               // 00000029E31C: F4000180 F8000118
	v_dual_mov_b32 v20, 0 :: v_dual_and_b32 v17, 15, v0        // 00000029E324: CA240080 1410008F
	v_lshrrev_b32_e32 v2, 4, v0                                // 00000029E32C: 32040084
	v_lshlrev_b32_e32 v16, 2, v0                               // 00000029E330: 30200082
	s_delay_alu instid0(VALU_DEP_2)                            // 00000029E334: BF870002
	v_dual_mov_b32 v24, 0 :: v_dual_lshlrev_b32 v3, 2, v2      // 00000029E338: CA220080 18020482
	s_waitcnt lgkmcnt(0)                                       // 00000029E340: BF89FC07
	s_cmp_gt_i32 s3, 1                                         // 00000029E344: BF028103
	s_cselect_b32 s7, -1, 0                                    // 00000029E348: 980780C1
	s_cmp_ge_i32 s2, s4                                        // 00000029E34C: BF030402
	s_cselect_b32 s4, -1, 0                                    // 00000029E350: 980480C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000029E354: BF870009
	s_and_b32 s4, s7, s4                                       // 00000029E358: 8B040407
	s_cmp_gt_i32 s3, 2                                         // 00000029E35C: BF028203
	v_cndmask_b32_e64 v1, 0, 1, s4                             // 00000029E360: D5010001 00110280
	s_cselect_b32 s7, -1, 0                                    // 00000029E368: 980780C1
	s_cmp_ge_i32 s2, s5                                        // 00000029E36C: BF030502
	s_cselect_b32 s5, -1, 0                                    // 00000029E370: 980580C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000029E374: BF870009
	s_and_b32 s4, s7, s5                                       // 00000029E378: 8B040507
	s_cmp_gt_i32 s3, 3                                         // 00000029E37C: BF028303
	v_readfirstlane_b32 s5, v1                                 // 00000029E380: 7E0A0501
	s_cselect_b32 s3, -1, 0                                    // 00000029E384: 980380C1
	s_cmp_ge_i32 s2, s6                                        // 00000029E388: BF030602
	v_lshlrev_b32_e32 v1, 2, v17                               // 00000029E38C: 30022282
	s_cselect_b32 s6, -1, 0                                    // 00000029E390: 980680C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 00000029E394: BF8704D9
	s_and_b32 s3, s3, s6                                       // 00000029E398: 8B030603
	s_and_b32 s4, s4, exec_lo                                  // 00000029E39C: 8B047E04
	s_cselect_b32 s4, 2, s5                                    // 00000029E3A0: 98040582
	s_and_b32 s3, s3, exec_lo                                  // 00000029E3A4: 8B037E03
	s_cselect_b32 s3, 3, s4                                    // 00000029E3A8: 98030483
	s_mulk_i32 s3, 0x48                                        // 00000029E3AC: B8030048
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000029E3B0: BF870009
	s_add_u32 s16, s0, s3                                      // 00000029E3B4: 80100300
	s_addc_u32 s17, s1, 0                                      // 00000029E3B8: 82118001
	s_clause 0x1                                               // 00000029E3BC: BF850001
	s_load_b256 s[4:11], s[16:17], 0x18                        // 00000029E3C0: F40C0108 F8000018
	s_load_b64 s[18:19], s[16:17], null                        // 00000029E3C8: F4040488 F8000000
	s_waitcnt lgkmcnt(0)                                       // 00000029E3D0: BF89FC07
	.long 0xd4540003                                           // 00000029E3D4: D4540003
	v_cndmask_b32_e32 v0, s10, v136, vcc_lo                    // 00000029E3D8: 0201100A
	s_and_b32 s12, s3, exec_lo                                 // 00000029E3DC: 8B0C7E03
	s_load_b128 s[12:15], s[0:1], 0x128                        // 00000029E3E0: F4080300 F8000128
	s_clause 0x1                                               // 00000029E3E8: BF850001
	global_load_b32 v1, v1, s[18:19]                           // 00000029E3EC: DC520000 01120001
	global_load_b32 v3, v3, s[18:19]                           // 00000029E3F4: DC520000 03120003
	s_cselect_b32 s24, 1, 16                                   // 00000029E3FC: 98189081
	s_cselect_b32 s0, 0, 4                                     // 00000029E400: 98008480
	s_add_i32 s25, s24, -1                                     // 00000029E404: 8119C118
	v_lshrrev_b32_e32 v18, s0, v2                              // 00000029E408: 32240400
	v_and_b32_e32 v19, s25, v2                                 // 00000029E40C: 36260419
	s_waitcnt vmcnt(1)                                         // 00000029E410: BF8907F7
	v_bfe_u32 v4, v1, 16, 1                                    // 00000029E414: D6100004 02052101
	s_waitcnt vmcnt(0)                                         // 00000029E41C: BF8903F7
	v_bfe_u32 v5, v3, 16, 1                                    // 00000029E420: D6100005 02052103
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000029E428: BF8701A2
	v_add3_u32 v1, v1, v4, 0x7fff                              // 00000029E42C: D6550001 03FE0901 00007FFF
	.long 0x7f083880                                           // 00000029E438: 7F083880
	v_add3_u32 v3, v3, v5, 0x7fff                              // 00000029E43C: D6550003 03FE0B03 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029E448: BF870093
	.long 0x7e083981                                           // 00000029E44C: 7E083981
	v_and_or_b32 v1, 0xffff0000, v3, v4                        // 00000029E450: D6570001 041206FF FFFF0000
	ds_store_b32 v16, v1                                       // 00000029E45C: D8340000 00000110
	v_cvt_f32_ubyte0_e32 v1, s24                               // 00000029E464: 7E022218
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000029E468: BF870291
	v_rcp_iflag_f32_e32 v1, v1                                 // 00000029E46C: 7E025701
	v_readfirstlane_b32 s1, v1                                 // 00000029E470: 7E020501
	v_mov_b32_e32 v1, 0                                        // 00000029E474: 7E020280
	s_mul_f32 s22, s1, 0x4f7ffffe                              // 00000029E478: A216FF01 4F7FFFFE
	s_delay_alu instid0(SALU_CYCLE_3)                          // 00000029E480: BF87000B
	s_cvt_u32_f32 s26, s22                                     // 00000029E484: BE9A6716
	s_waitcnt lgkmcnt(0)                                       // 00000029E488: BF89FC07
	s_barrier                                                  // 00000029E48C: BFBD0000
	buffer_gl0_inv                                             // 00000029E490: E0AC0000 00000000
	s_load_b32 s20, s[16:17], 0x40                             // 00000029E498: F4000508 F8000040
	s_waitcnt lgkmcnt(0)                                       // 00000029E4A0: BF89FC07
	s_sub_i32 s0, s2, s20                                      // 00000029E4A4: 81801402
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000029E4A8: BF870009
	s_ashr_i32 s1, s0, 31                                      // 00000029E4AC: 86019F00
	s_and_b32 s3, s3, exec_lo                                  // 00000029E4B0: 8B037E03
	s_cselect_b32 s3, 4, 0                                     // 00000029E4B4: 98038084
	s_lshr_b32 s20, s15, 31                                    // 00000029E4B8: 85149F0F
	s_lshl_b64 s[0:1], s[0:1], s3                              // 00000029E4BC: 84800300
	s_add_u32 s20, s14, s20                                    // 00000029E4C0: 8014140E
	s_addc_u32 s21, s15, 0                                     // 00000029E4C4: 8215800F
	s_ashr_i32 s3, s15, 31                                     // 00000029E4C8: 86039F0F
	s_ashr_i64 s[20:21], s[20:21], 1                           // 00000029E4CC: 86948114
	s_lshr_b32 s3, s3, 27                                      // 00000029E4D0: 85039B03
	.long 0xd7000009                                           // 00000029E4D4: D7000009
	v_cndmask_b32_e32 v1, s0, v18, vcc_lo                      // 00000029E4D8: 02022400
	s_add_u32 s22, s14, s3                                     // 00000029E4DC: 8016030E
	s_addc_u32 s23, s15, 0                                     // 00000029E4E0: 8217800F
	s_sub_i32 s3, 0, s24                                       // 00000029E4E4: 81831880
	s_lshr_b64 s[22:23], s[22:23], 5                           // 00000029E4E8: 85968516
	s_mul_i32 s3, s3, s26                                      // 00000029E4EC: 96031A03
	s_add_i32 s23, s25, s22                                    // 00000029E4F0: 81171619
	s_mul_hi_u32 s3, s26, s3                                   // 00000029E4F4: 9683031A
	s_abs_i32 s27, s23                                         // 00000029E4F8: BE9B1517
	s_add_i32 s26, s26, s3                                     // 00000029E4FC: 811A031A
	v_add_co_ci_u32_e64 v10, null, s1, 0, s0                   // 00000029E500: D5207C0A 00010001
	s_mul_hi_u32 s3, s27, s26                                  // 00000029E508: 96831A1B
	s_ashr_i32 s1, s23, 31                                     // 00000029E50C: 86019F17
	s_mul_i32 s0, s3, s24                                      // 00000029E510: 96001803
	s_add_i32 s26, s3, 1                                       // 00000029E514: 811A8103
	s_sub_i32 s23, s27, s0                                     // 00000029E518: 8197001B
	.long 0xd4540000                                           // 00000029E51C: D4540000
	v_cndmask_b32_e32 v1, s10, v9, vcc_lo                      // 00000029E520: 0202120A
	s_sub_i32 s27, s23, s24                                    // 00000029E524: 819B1817
	s_cmp_ge_u32 s23, s24                                      // 00000029E528: BF091817
	s_cselect_b32 s3, s26, s3                                  // 00000029E52C: 9803031A
	s_cselect_b32 s23, s27, s23                                // 00000029E530: 9817171B
	s_add_i32 s26, s3, 1                                       // 00000029E534: 811A8103
	s_cmp_ge_u32 s23, s24                                      // 00000029E538: BF091817
	v_cndmask_b32_e64 v3, 0, v10, s0                           // 00000029E53C: D5010003 00021480
	s_cselect_b32 s3, s26, s3                                  // 00000029E544: 9803031A
	v_cndmask_b32_e64 v2, 0, v9, s0                            // 00000029E548: D5010002 00021280
	s_xor_b32 s3, s3, s1                                       // 00000029E550: 8D030103
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000029E554: BF870009
	s_sub_i32 s1, s3, s1                                       // 00000029E558: 81810103
	s_add_u32 s4, s18, s4                                      // 00000029E55C: 80040412
	s_addc_u32 s5, s19, s5                                     // 00000029E560: 82050513
	.long 0xd72c0004                                           // 00000029E564: D72C0004
	v_cndmask_b32_e32 v0, v3, v20, vcc_lo                      // 00000029E568: 02002903
	.long 0xd72c0007                                           // 00000029E56C: D72C0007
	v_cndmask_b32_e32 v0, v2, v21, vcc_lo                      // 00000029E570: 02002B02
	v_mad_u64_u32 v[11:12], null, v2, s20, s[4:5]              // 00000029E574: D6FE7C0B 00102902
	s_add_u32 s6, s18, s6                                      // 00000029E57C: 80060612
	.long 0xd72c0006                                           // 00000029E580: D72C0006
	v_cndmask_b32_e32 v0, v3, v8, vcc_lo                       // 00000029E584: 02001103
	s_addc_u32 s7, s19, s7                                     // 00000029E588: 82070713
	.long 0xd72c0008                                           // 00000029E58C: D72C0008
	v_cndmask_b32_e32 v0, v2, v9, vcc_lo                       // 00000029E590: 02001302
	v_mad_u64_u32 v[13:14], null, v2, s8, s[6:7]               // 00000029E594: D6FE7C0D 00181102
	.long 0xd4510003                                           // 00000029E59C: D4510003
	v_cndmask_b32_e32 v0, s10, v137, vcc_lo                    // 00000029E5A0: 0201120A
	v_mov_b32_e32 v2, 0                                        // 00000029E5A4: 7E040280
	v_add3_u32 v12, v4, v12, v7                                // 00000029E5A8: D655000C 041E1904
	v_mov_b32_e32 v4, 0                                        // 00000029E5B0: 7E080280
	.long 0xd72c0005                                           // 00000029E5B4: D72C0005
	v_cndmask_b32_e32 v1, s1, v19, vcc_lo                      // 00000029E5B8: 02022601
	v_add3_u32 v23, v6, v14, v8                                // 00000029E5BC: D6550017 04221D06
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000029E5C4: BF870122
	v_add_nc_u32_e32 v3, s1, v5                                // 00000029E5C8: 4A060A01
	v_add_nc_u32_e32 v21, v5, v17                              // 00000029E5CC: 4A2A2305
	v_min_i32_e32 v22, s22, v3                                 // 00000029E5D0: 222C0616
	v_mov_b32_e32 v3, 0                                        // 00000029E5D4: 7E060280
	s_delay_alu instid0(VALU_DEP_2)                            // 00000029E5D8: BF870002
	v_cmp_lt_i32_e32 vcc_lo, v21, v22                          // 00000029E5DC: 7C822D15
	s_and_saveexec_b32 s4, vcc_lo                              // 00000029E5E0: BE84206A
	s_cbranch_execz 21                                         // 00000029E5E4: BFA50015 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x33c>
	v_lshlrev_b32_e32 v1, 1, v21                               // 00000029E5E8: 30022A81
	v_lshlrev_b32_e32 v3, 4, v21                               // 00000029E5EC: 30062A84
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000029E5F0: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000029E5F4: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 00000029E5F8: 3408069F
	.long 0xd7000101                                           // 00000029E5FC: D7000101
	v_cndmask_b32_e32 v1, v13, v1, vcc_lo                      // 00000029E600: 0202030D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000029E604: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v23, v2, s1                  // 00000029E608: D5207C02 00060517
	.long 0xd7000103                                           // 00000029E610: D7000103
	v_cndmask_b32_e32 v1, v11, v3, vcc_lo                      // 00000029E614: 0202070B
	v_add_co_ci_u32_e64 v4, null, v12, v4, s1                  // 00000029E618: D5207C04 0006090C
	s_clause 0x1                                               // 00000029E620: BF850001
	global_load_d16_b16 v6, v[1:2], off                        // 00000029E624: DC820000 067C0001
	global_load_b128 v[1:4], v[3:4], off                       // 00000029E62C: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 00000029E634: BF8907F7
	v_cvt_f32_f16_e32 v24, v6                                  // 00000029E638: 7E301706
	s_or_b32 exec_lo, exec_lo, s4                              // 00000029E63C: 8C7E047E
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v25, 0             // 00000029E640: CA100080 1A180080
	s_and_saveexec_b32 s8, vcc_lo                              // 00000029E648: BE88206A
	s_cbranch_execz 316                                        // 00000029E64C: BFA5013C <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x840>
	v_dual_mov_b32 v25, 0 :: v_dual_lshlrev_b32 v6, 5, v17     // 00000029E650: CA220080 19062285
	v_dual_mov_b32 v26, 0 :: v_dual_add_nc_u32 v7, 16, v21     // 00000029E658: CA200080 1A062A90
	s_lshl_b64 s[4:5], s[14:15], 2                             // 00000029E660: 8484820E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000029E664: BF870112
	v_lshl_add_u32 v14, v5, 5, v6                              // 00000029E668: D646000E 04190B05
	v_dual_mov_b32 v20, 0 :: v_dual_lshlrev_b32 v27, 4, v7     // 00000029E670: CA220080 141A0E84
	v_dual_mov_b32 v29, v24 :: v_dual_lshlrev_b32 v28, 1, v7   // 00000029E678: CA220118 1D1C0E81
	s_mov_b32 s9, 0                                            // 00000029E680: BE890080
	s_lshl_b64 s[6:7], s[14:15], 1                             // 00000029E684: 8486810E
	s_branch 269                                               // 00000029E688: BFA0010D <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x7c0>
	s_or_b32 exec_lo, exec_lo, s14                             // 00000029E68C: 8C7E0E7E
	v_ashrrev_i32_e32 v15, 31, v14                             // 00000029E690: 341E1C9F
	v_lshrrev_b32_e32 v78, 6, v1                               // 00000029E694: 329C0286
	v_lshrrev_b32_e32 v79, 14, v1                              // 00000029E698: 329E028E
	v_and_b32_e32 v80, 0xff, v2                                // 00000029E69C: 36A004FF 000000FF
	v_lshrrev_b32_e32 v81, 6, v2                               // 00000029E6A4: 32A20486
	.long 0xd73c001e                                           // 00000029E6A8: D73C001E
	v_cndmask_b32_e32 v1, 1, v14, vcc_lo                       // 00000029E6AC: 02021C81
	v_and_b32_e32 v15, 0xff, v1                                // 00000029E6B0: 361E02FF 000000FF
	v_and_b32_e32 v78, 0x3fc, v78                              // 00000029E6B8: 369C9CFF 000003FC
	v_and_b32_e32 v79, 0x3fc, v79                              // 00000029E6C0: 369E9EFF 000003FC
	v_lshrrev_b32_e32 v1, 22, v1                               // 00000029E6C8: 32020296
	v_lshrrev_b32_e32 v82, 14, v2                              // 00000029E6CC: 32A4048E
	.long 0xd7000142                                           // 00000029E6D0: D7000142
	v_cndmask_b32_e32 v1, s12, v30, vcc_lo                     // 00000029E6D4: 02023C0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000029E6D8: BF8701A1
	v_add_co_ci_u32_e64 v67, null, s13, v31, s1                // 00000029E6DC: D5207C43 00063E0D
	v_lshlrev_b32_e32 v15, 2, v15                              // 00000029E6E4: 301E1E82
	.long 0xd7000146                                           // 00000029E6E8: D7000146
	v_cndmask_b32_e32 v0, v66, v6, vcc_lo                      // 00000029E6EC: 02000D42
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000029E6F0: BF8700A1
	v_add_co_ci_u32_e64 v71, null, s7, v67, s1                 // 00000029E6F4: D5207C47 00068607
	.long 0xd700014a                                           // 00000029E6FC: D700014A
	v_cndmask_b32_e32 v0, v66, v4, vcc_lo                      // 00000029E700: 02000942
	v_add_co_ci_u32_e64 v75, null, s5, v67, s1                 // 00000029E704: D5207C4B 00068605
	s_clause 0xb                                               // 00000029E70C: BF85000B
	global_load_b128 v[30:33], v[66:67], off                   // 00000029E710: DC5E0000 1E7C0042
	global_load_b128 v[34:37], v[70:71], off                   // 00000029E718: DC5E0000 227C0046
	global_load_b128 v[38:41], v[74:75], off                   // 00000029E720: DC5E0000 267C004A
	global_load_b128 v[42:45], v[66:67], off offset:16         // 00000029E728: DC5E0010 2A7C0042
	global_load_b128 v[46:49], v[70:71], off offset:16         // 00000029E730: DC5E0010 2E7C0046
	global_load_b128 v[50:53], v[74:75], off offset:16         // 00000029E738: DC5E0010 327C004A
	global_load_b128 v[54:57], v[66:67], off offset:32         // 00000029E740: DC5E0020 367C0042
	global_load_b128 v[58:61], v[70:71], off offset:32         // 00000029E748: DC5E0020 3A7C0046
	global_load_b128 v[62:65], v[74:75], off offset:32         // 00000029E750: DC5E0020 3E7C004A
	global_load_b128 v[66:69], v[66:67], off offset:48         // 00000029E758: DC5E0030 427C0042
	global_load_b128 v[70:73], v[70:71], off offset:48         // 00000029E760: DC5E0030 467C0046
	global_load_b128 v[74:77], v[74:75], off offset:48         // 00000029E768: DC5E0030 4A7C004A
	ds_load_b32 v15, v15                                       // 00000029E770: D8D80000 0F00000F
	ds_load_b32 v78, v78                                       // 00000029E778: D8D80000 4E00004E
	ds_load_b32 v79, v79                                       // 00000029E780: D8D80000 4F00004F
	v_lshrrev_b32_e32 v2, 22, v2                               // 00000029E788: 32040496
	v_and_b32_e32 v1, 0x3fc, v1                                // 00000029E78C: 360202FF 000003FC
	v_lshlrev_b32_e32 v80, 2, v80                              // 00000029E794: 30A0A082
	v_and_b32_e32 v81, 0x3fc, v81                              // 00000029E798: 36A2A2FF 000003FC
	v_and_b32_e32 v82, 0x3fc, v82                              // 00000029E7A0: 36A4A4FF 000003FC
	v_and_b32_e32 v2, 0x3fc, v2                                // 00000029E7A8: 360404FF 000003FC
	ds_load_b32 v1, v1                                         // 00000029E7B0: D8D80000 01000001
	ds_load_b32 v80, v80                                       // 00000029E7B8: D8D80000 50000050
	ds_load_b32 v81, v81                                       // 00000029E7C0: D8D80000 51000051
	ds_load_b32 v82, v82                                       // 00000029E7C8: D8D80000 52000052
	ds_load_b32 v2, v2                                         // 00000029E7D0: D8D80000 02000002
	v_and_b32_e32 v83, 0xff, v3                                // 00000029E7D8: 36A606FF 000000FF
	v_lshrrev_b32_e32 v84, 6, v3                               // 00000029E7E0: 32A80686
	v_lshrrev_b32_e32 v85, 14, v3                              // 00000029E7E4: 32AA068E
	v_lshrrev_b32_e32 v3, 22, v3                               // 00000029E7E8: 32060696
	v_and_b32_e32 v86, 0xff, v4                                // 00000029E7EC: 36AC08FF 000000FF
	v_lshrrev_b32_e32 v87, 14, v4                              // 00000029E7F4: 32AE088E
	v_add_nc_u32_e32 v27, 0x100, v27                           // 00000029E7F8: 4A3636FF 00000100
	v_add_nc_u32_e32 v28, 32, v28                              // 00000029E800: 4A3838A0
	v_and_b32_e32 v3, 0x3fc, v3                                // 00000029E804: 360606FF 000003FC
	v_add_nc_u32_e32 v14, 0x200, v14                           // 00000029E80C: 4A1C1CFF 00000200
	s_and_b32 s1, exec_lo, vcc_lo                              // 00000029E814: 8B016A7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000029E818: BF870009
	s_or_b32 s9, s1, s9                                        // 00000029E81C: 8C090901
	s_waitcnt vmcnt(11) lgkmcnt(7)                             // 00000029E820: BF892C77
	v_dot2_f32_bf16 v30, v30, v15, 0                           // 00000029E824: CC1A401E 1A021F1E
	s_waitcnt vmcnt(10)                                        // 00000029E82C: BF892BF7
	v_dot2_f32_bf16 v34, v34, v15, 0                           // 00000029E830: CC1A4022 1A021F22
	s_waitcnt vmcnt(9)                                         // 00000029E838: BF8927F7
	v_dot2_f32_bf16 v15, v38, v15, 0                           // 00000029E83C: CC1A400F 1A021F26
	v_lshrrev_b32_e32 v38, 6, v4                               // 00000029E844: 324C0886
	v_lshrrev_b32_e32 v4, 22, v4                               // 00000029E848: 32080896
	s_waitcnt lgkmcnt(6)                                       // 00000029E84C: BF89FC67
	v_dot2_f32_bf16 v30, v31, v78, v30                         // 00000029E850: CC1A401E 1C7A9D1F
	v_dot2_f32_bf16 v31, v35, v78, v34                         // 00000029E858: CC1A401F 1C8A9D23
	v_dot2_f32_bf16 v15, v39, v78, v15                         // 00000029E860: CC1A400F 1C3E9D27
	v_lshlrev_b32_e32 v34, 2, v83                              // 00000029E868: 3044A682
	v_and_b32_e32 v35, 0x3fc, v85                              // 00000029E86C: 3646AAFF 000003FC
	s_waitcnt lgkmcnt(5)                                       // 00000029E874: BF89FC57
	v_dot2_f32_bf16 v30, v32, v79, v30                         // 00000029E878: CC1A401E 1C7A9F20
	v_dot2_f32_bf16 v31, v36, v79, v31                         // 00000029E880: CC1A401F 1C7E9F24
	v_dot2_f32_bf16 v15, v40, v79, v15                         // 00000029E888: CC1A400F 1C3E9F28
	v_and_b32_e32 v32, 0x3fc, v84                              // 00000029E890: 3640A8FF 000003FC
	ds_load_b32 v35, v35                                       // 00000029E898: D8D80000 23000023
	s_waitcnt lgkmcnt(5)                                       // 00000029E8A0: BF89FC57
	v_dot2_f32_bf16 v30, v33, v1, v30                          // 00000029E8A4: CC1A401E 1C7A0321
	v_dot2_f32_bf16 v31, v37, v1, v31                          // 00000029E8AC: CC1A401F 1C7E0325
	v_dot2_f32_bf16 v1, v41, v1, v15                           // 00000029E8B4: CC1A4001 1C3E0329
	ds_load_b32 v33, v34                                       // 00000029E8BC: D8D80000 21000022
	ds_load_b32 v32, v32                                       // 00000029E8C4: D8D80000 20000020
	s_waitcnt vmcnt(8) lgkmcnt(6)                              // 00000029E8CC: BF892067
	v_dot2_f32_bf16 v30, v42, v80, v30                         // 00000029E8D0: CC1A401E 1C7AA12A
	s_waitcnt vmcnt(7)                                         // 00000029E8D8: BF891FF7
	v_dot2_f32_bf16 v31, v46, v80, v31                         // 00000029E8DC: CC1A401F 1C7EA12E
	s_waitcnt vmcnt(6)                                         // 00000029E8E4: BF891BF7
	v_dot2_f32_bf16 v1, v50, v80, v1                           // 00000029E8E8: CC1A4001 1C06A132
	v_lshlrev_b32_e32 v15, 2, v86                              // 00000029E8F0: 301EAC82
	v_and_b32_e32 v34, 0x3fc, v38                              // 00000029E8F4: 36444CFF 000003FC
	s_waitcnt lgkmcnt(5)                                       // 00000029E8FC: BF89FC57
	v_dot2_f32_bf16 v30, v43, v81, v30                         // 00000029E900: CC1A401E 1C7AA32B
	v_dot2_f32_bf16 v31, v47, v81, v31                         // 00000029E908: CC1A401F 1C7EA32F
	v_dot2_f32_bf16 v1, v51, v81, v1                           // 00000029E910: CC1A4001 1C06A333
	v_and_b32_e32 v36, 0x3fc, v87                              // 00000029E918: 3648AEFF 000003FC
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000029E920: 360808FF 000003FC
	s_waitcnt lgkmcnt(4)                                       // 00000029E928: BF89FC47
	v_dot2_f32_bf16 v30, v44, v82, v30                         // 00000029E92C: CC1A401E 1C7AA52C
	v_dot2_f32_bf16 v31, v48, v82, v31                         // 00000029E934: CC1A401F 1C7EA530
	v_dot2_f32_bf16 v1, v52, v82, v1                           // 00000029E93C: CC1A4001 1C06A534
	s_waitcnt lgkmcnt(3)                                       // 00000029E944: BF89FC37
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000029E948: BF870193
	v_dot2_f32_bf16 v30, v45, v2, v30                          // 00000029E94C: CC1A401E 1C7A052D
	v_dot2_f32_bf16 v31, v49, v2, v31                          // 00000029E954: CC1A401F 1C7E0531
	s_delay_alu instid0(VALU_DEP_3)                            // 00000029E95C: BF870003
	v_dot2_f32_bf16 v1, v53, v2, v1                            // 00000029E960: CC1A4001 1C060535
	ds_load_b32 v2, v3                                         // 00000029E968: D8D80000 02000003
	ds_load_b32 v3, v15                                        // 00000029E970: D8D80000 0300000F
	ds_load_b32 v15, v34                                       // 00000029E978: D8D80000 0F000022
	ds_load_b32 v34, v36                                       // 00000029E980: D8D80000 22000024
	ds_load_b32 v36, v4                                        // 00000029E988: D8D80000 24000004
	s_waitcnt vmcnt(5) lgkmcnt(6)                              // 00000029E990: BF891467
	v_dot2_f32_bf16 v4, v54, v33, v30                          // 00000029E994: CC1A4004 1C7A4336
	s_waitcnt vmcnt(4)                                         // 00000029E99C: BF8913F7
	v_dot2_f32_bf16 v30, v58, v33, v31                         // 00000029E9A0: CC1A401E 1C7E433A
	s_waitcnt vmcnt(3)                                         // 00000029E9A8: BF890FF7
	v_dot2_f32_bf16 v1, v62, v33, v1                           // 00000029E9AC: CC1A4001 1C06433E
	s_waitcnt lgkmcnt(5)                                       // 00000029E9B4: BF89FC57
	v_dot2_f32_bf16 v4, v55, v32, v4                           // 00000029E9B8: CC1A4004 1C124137
	v_dot2_f32_bf16 v30, v59, v32, v30                         // 00000029E9C0: CC1A401E 1C7A413B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000029E9C8: BF870193
	v_dot2_f32_bf16 v1, v63, v32, v1                           // 00000029E9CC: CC1A4001 1C06413F
	v_dot2_f32_bf16 v4, v56, v35, v4                           // 00000029E9D4: CC1A4004 1C124738
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000029E9DC: BF870193
	v_dot2_f32_bf16 v30, v60, v35, v30                         // 00000029E9E0: CC1A401E 1C7A473C
	v_dot2_f32_bf16 v1, v64, v35, v1                           // 00000029E9E8: CC1A4001 1C064740
	s_waitcnt lgkmcnt(4)                                       // 00000029E9F0: BF89FC47
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000029E9F4: BF870193
	v_dot2_f32_bf16 v4, v57, v2, v4                            // 00000029E9F8: CC1A4004 1C120539
	v_dot2_f32_bf16 v30, v61, v2, v30                          // 00000029EA00: CC1A401E 1C7A053D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000029EA08: BF8701A3
	v_dot2_f32_bf16 v1, v65, v2, v1                            // 00000029EA0C: CC1A4001 1C060541
	s_waitcnt vmcnt(2) lgkmcnt(3)                              // 00000029EA14: BF890837
	v_dot2_f32_bf16 v2, v66, v3, v4                            // 00000029EA18: CC1A4002 1C120742
	s_waitcnt vmcnt(1)                                         // 00000029EA20: BF8907F7
	v_dot2_f32_bf16 v4, v70, v3, v30                           // 00000029EA24: CC1A4004 1C7A0746
	s_waitcnt vmcnt(0)                                         // 00000029EA2C: BF8903F7
	v_dot2_f32_bf16 v1, v74, v3, v1                            // 00000029EA30: CC1A4001 1C06074A
	s_waitcnt lgkmcnt(2)                                       // 00000029EA38: BF89FC27
	v_dot2_f32_bf16 v2, v67, v15, v2                           // 00000029EA3C: CC1A4002 1C0A1F43
	v_dot2_f32_bf16 v3, v71, v15, v4                           // 00000029EA44: CC1A4003 1C121F47
	s_delay_alu instid0(VALU_DEP_3)                            // 00000029EA4C: BF870003
	v_dot2_f32_bf16 v1, v75, v15, v1                           // 00000029EA50: CC1A4001 1C061F4B
	v_mov_b32_e32 v4, v8                                       // 00000029EA58: 7E080308
	s_waitcnt lgkmcnt(1)                                       // 00000029EA5C: BF89FC17
	v_dot2_f32_bf16 v8, v68, v34, v2                           // 00000029EA60: CC1A4008 1C0A4544
	v_dot2_f32_bf16 v15, v72, v34, v3                          // 00000029EA68: CC1A400F 1C0E4548
	v_dot2_f32_bf16 v1, v76, v34, v1                           // 00000029EA70: CC1A4001 1C06454C
	v_dual_mov_b32 v3, v7 :: v_dual_mov_b32 v2, v6             // 00000029EA78: CA100107 03020106
	s_waitcnt lgkmcnt(0)                                       // 00000029EA80: BF89FC07
	v_dot2_f32_bf16 v6, v69, v36, v8                           // 00000029EA84: CC1A4006 1C224945
	v_dot2_f32_bf16 v7, v73, v36, v15                          // 00000029EA8C: CC1A4007 1C3E4949
	v_dot2_f32_bf16 v8, v77, v36, v1                           // 00000029EA94: CC1A4008 1C06494D
	v_mov_b32_e32 v1, v5                                       // 00000029EA9C: 7E020305
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000029EAA0: BF870214
	v_fmac_f32_e32 v25, v24, v6                                // 00000029EAA4: 56320D18
	v_fmac_f32_e32 v26, v24, v7                                // 00000029EAA8: 56340F18
	s_delay_alu instid0(VALU_DEP_4)                            // 00000029EAAC: BF870004
	v_fmac_f32_e32 v20, v24, v8                                // 00000029EAB0: 56281118
	v_mov_b32_e32 v24, v29                                     // 00000029EAB4: 7E30031D
	s_and_not1_b32 exec_lo, exec_lo, s9                        // 00000029EAB8: 917E097E
	s_cbranch_execz 31                                         // 00000029EABC: BFA5001F <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x83c>
	s_waitcnt vmcnt(0)                                         // 00000029EAC0: BF8903F7
	v_dual_mov_b32 v6, v2 :: v_dual_add_nc_u32 v21, 16, v21    // 00000029EAC4: CA200102 06142A90
	v_dual_mov_b32 v5, v1 :: v_dual_mov_b32 v8, v4             // 00000029EACC: CA100101 05080104
	v_mov_b32_e32 v7, v3                                       // 00000029EAD4: 7E0E0303
	s_mov_b32 s14, exec_lo                                     // 00000029EAD8: BE8E007E
	s_delay_alu instid0(VALU_DEP_3)                            // 00000029EADC: BF870003
	v_cmp_ge_i32_e32 vcc_lo, v21, v22                          // 00000029EAE0: 7C8C2D15
	.long 0xd4c1007e                                           // 00000029EAE4: D4C1007E
	v_cndmask_b32_e32 v1, v21, v22, vcc_lo                     // 00000029EAE8: 02022D15
	s_cbranch_execz 65255                                      // 00000029EAEC: BFA5FEE7 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x38c>
	v_ashrrev_i32_e32 v6, 31, v28                              // 00000029EAF0: 340C389F
	v_ashrrev_i32_e32 v8, 31, v27                              // 00000029EAF4: 3410369F
	.long 0xd7000105                                           // 00000029EAF8: D7000105
	v_cndmask_b32_e32 v1, v13, v28, vcc_lo                     // 00000029EAFC: 0202390D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000029EB00: BF8700A1
	v_add_co_ci_u32_e64 v6, null, v23, v6, s1                  // 00000029EB04: D5207C06 00060D17
	.long 0xd7000107                                           // 00000029EB0C: D7000107
	v_cndmask_b32_e32 v1, v11, v27, vcc_lo                     // 00000029EB10: 0202370B
	v_add_co_ci_u32_e64 v8, null, v12, v8, s1                  // 00000029EB14: D5207C08 0006110C
	s_clause 0x1                                               // 00000029EB1C: BF850001
	global_load_d16_b16 v15, v[5:6], off                       // 00000029EB20: DC820000 0F7C0005
	global_load_b128 v[5:8], v[7:8], off                       // 00000029EB28: DC5E0000 057C0007
	s_waitcnt vmcnt(1)                                         // 00000029EB30: BF8907F7
	v_cvt_f32_f16_e32 v29, v15                                 // 00000029EB34: 7E3A170F
	s_branch 65236                                             // 00000029EB38: BFA0FED4 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x38c>
	s_or_b32 exec_lo, exec_lo, s9                              // 00000029EB3C: 8C7E097E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000029EB40: BF870149
	s_or_b32 exec_lo, exec_lo, s8                              // 00000029EB44: 8C7E087E
	s_waitcnt vmcnt(0)                                         // 00000029EB48: BF8903F7
	.long 0xd71f0001                                           // 00000029EB4C: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000029EB50: 020100C1
	.long 0xd44a0001                                           // 00000029EB54: D44A0001
	v_cndmask_b32_e32 v1, 0, v17, vcc_lo                       // 00000029EB58: 02022280
	v_xor_b32_e32 v2, 8, v1                                    // 00000029EB5C: 3A040288
	v_xor_b32_e32 v5, 4, v1                                    // 00000029EB60: 3A0A0284
	v_xor_b32_e32 v8, 2, v1                                    // 00000029EB64: 3A100282
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000029EB68: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 00000029EB6C: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 00000029EB70: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v5                            // 00000029EB74: 7C980AA0
	v_cndmask_b32_e32 v5, v1, v5, vcc_lo                       // 00000029EB78: 020A0B01
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 00000029EB7C: 7C9810A0
	s_delay_alu instid0(VALU_DEP_2)                            // 00000029EB80: BF870002
	v_lshlrev_b32_e32 v5, 2, v5                                // 00000029EB84: 300A0A82
	v_lshlrev_b32_e32 v2, 2, v2                                // 00000029EB88: 30040482
	ds_bpermute_b32 v3, v2, v25                                // 00000029EB8C: DACC0000 03001902
	s_waitcnt lgkmcnt(0)                                       // 00000029EB94: BF89FC07
	v_add_f32_e32 v3, v25, v3                                  // 00000029EB98: 06060719
	ds_bpermute_b32 v4, v2, v26                                // 00000029EB9C: DACC0000 04001A02
	ds_bpermute_b32 v2, v2, v20                                // 00000029EBA4: DACC0000 02001402
	ds_bpermute_b32 v6, v5, v3                                 // 00000029EBAC: DACC0000 06000305
	v_cndmask_b32_e32 v8, v1, v8, vcc_lo                       // 00000029EBB4: 02101101
	s_waitcnt lgkmcnt(2)                                       // 00000029EBB8: BF89FC27
	v_add_f32_e32 v4, v26, v4                                  // 00000029EBBC: 0608091A
	s_waitcnt lgkmcnt(1)                                       // 00000029EBC0: BF89FC17
	v_add_f32_e32 v2, v20, v2                                  // 00000029EBC4: 06040514
	s_waitcnt lgkmcnt(0)                                       // 00000029EBC8: BF89FC07
	v_add_f32_e32 v3, v3, v6                                   // 00000029EBCC: 06060D03
	ds_bpermute_b32 v7, v5, v4                                 // 00000029EBD0: DACC0000 07000405
	ds_bpermute_b32 v5, v5, v2                                 // 00000029EBD8: DACC0000 05000205
	v_lshlrev_b32_e32 v8, 2, v8                                // 00000029EBE0: 30101082
	s_waitcnt lgkmcnt(1)                                       // 00000029EBE4: BF89FC17
	v_add_f32_e32 v4, v4, v7                                   // 00000029EBE8: 06080F04
	s_waitcnt lgkmcnt(0)                                       // 00000029EBEC: BF89FC07
	v_add_f32_e32 v2, v2, v5                                   // 00000029EBF0: 06040B02
	ds_bpermute_b32 v5, v8, v3                                 // 00000029EBF4: DACC0000 05000308
	s_waitcnt lgkmcnt(0)                                       // 00000029EBFC: BF89FC07
	v_add_f32_e32 v3, v3, v5                                   // 00000029EC00: 06060B03
	ds_bpermute_b32 v6, v8, v4                                 // 00000029EC04: DACC0000 06000408
	ds_bpermute_b32 v7, v8, v2                                 // 00000029EC0C: DACC0000 07000208
	v_xor_b32_e32 v8, 1, v1                                    // 00000029EC14: 3A100281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000029EC18: BF8700D1
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 00000029EC1C: 7C9810A0
	v_cndmask_b32_e32 v1, v1, v8, vcc_lo                       // 00000029EC20: 02021101
	s_and_b32 vcc_lo, exec_lo, s3                              // 00000029EC24: 8B6A037E
	s_mov_b32 s3, -1                                           // 00000029EC28: BE8300C1
	s_waitcnt lgkmcnt(1)                                       // 00000029EC2C: BF89FC17
	v_dual_add_f32 v4, v4, v6 :: v_dual_lshlrev_b32 v1, 2, v1  // 00000029EC30: C9220D04 04000282
	s_waitcnt lgkmcnt(0)                                       // 00000029EC38: BF89FC07
	v_add_f32_e32 v2, v2, v7                                   // 00000029EC3C: 06040F02
	ds_bpermute_b32 v5, v1, v3                                 // 00000029EC40: DACC0000 05000301
	ds_bpermute_b32 v6, v1, v4                                 // 00000029EC48: DACC0000 06000401
	ds_bpermute_b32 v1, v1, v2                                 // 00000029EC50: DACC0000 01000201
	s_waitcnt lgkmcnt(1)                                       // 00000029EC58: BF89FC17
	v_dual_add_f32 v8, v3, v5 :: v_dual_add_f32 v7, v4, v6     // 00000029EC5C: C9080B03 08060D04
	s_waitcnt lgkmcnt(0)                                       // 00000029EC64: BF89FC07
	v_add_f32_e32 v6, v2, v1                                   // 00000029EC68: 060C0302
	s_cbranch_vccz 431                                         // 00000029EC6C: BFA301AF <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x102c>
	s_and_saveexec_b32 s3, s1                                  // 00000029EC70: BE832001
	s_cbranch_execz 11                                         // 00000029EC74: BFA5000B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x9a4>
	v_lshl_or_b32 v1, v18, 4, v19                              // 00000029EC78: D6560001 044D0912
	s_delay_alu instid0(VALU_DEP_1)                            // 00000029EC80: BF870001
	v_mad_u32_u24 v2, v1, 12, 0x400                            // 00000029EC84: D60B0002 03FD1901 00000400
	v_mul_u32_u24_e32 v1, 12, v1                               // 00000029EC90: 1602028C
	ds_store_2addr_b32 v2, v8, v7 offset1:1                    // 00000029EC94: D8380100 00070802
	ds_store_b32 v1, v6 offset:1032                            // 00000029EC9C: D8340408 00000601
	s_or_b32 exec_lo, exec_lo, s3                              // 00000029ECA4: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000029ECA8: BF870009
	s_mov_b32 s8, exec_lo                                      // 00000029ECAC: BE88007E
	s_waitcnt lgkmcnt(0)                                       // 00000029ECB0: BF89FC07
	s_barrier                                                  // 00000029ECB4: BFBD0000
	buffer_gl0_inv                                             // 00000029ECB8: E0AC0000 00000000
	v_cmpx_gt_u32_e32 3, v0                                    // 00000029ECC0: 7D980083
	s_cbranch_execz 407                                        // 00000029ECC4: BFA50197 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1024>
	s_load_b32 s3, s[16:17], 0x40                              // 00000029ECC8: F40000C8 F8000040
	s_waitcnt lgkmcnt(0)                                       // 00000029ECD0: BF89FC07
	s_sub_i32 s2, s2, s3                                       // 00000029ECD4: 81820302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000029ECD8: BF870499
	s_ashr_i32 s3, s2, 31                                      // 00000029ECDC: 86039F02
	.long 0xd4530004                                           // 00000029ECE0: D4530004
	v_cndmask_b32_e32 v0, s10, v2, vcc_lo                      // 00000029ECE4: 0200040A
	s_and_b32 vcc_lo, exec_lo, s4                              // 00000029ECE8: 8B6A047E
	s_cbranch_vccnz 397                                        // 00000029ECEC: BFA4018D <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1024>
	v_add_nc_u32_e32 v5, 0x400, v16                            // 00000029ECF0: 4A0A20FF 00000400
	s_clause 0x1                                               // 00000029ECF8: BF850001
	s_load_b64 s[6:7], s[16:17], 0x38                          // 00000029ECFC: F4040188 F8000038
	s_load_b64 s[4:5], s[16:17], 0x8                           // 00000029ED04: F4040108 F8000008
	s_mov_b32 s9, 0                                            // 00000029ED0C: BE890080
	s_mov_b32 s13, -1                                          // 00000029ED10: BE8D00C1
	s_mov_b32 s12, 0                                           // 00000029ED14: BE8C0080
	ds_load_2addr_b32 v[1:2], v5 offset1:3                     // 00000029ED18: D8DC0300 01000005
	ds_load_2addr_b32 v[3:4], v5 offset0:6 offset1:9           // 00000029ED20: D8DC0906 03000005
	ds_load_2addr_b32 v[11:12], v5 offset0:12 offset1:15       // 00000029ED28: D8DC0F0C 0B000005
	s_waitcnt lgkmcnt(0)                                       // 00000029ED30: BF89FC07
	s_cmp_lt_i32 s7, 3                                         // 00000029ED34: BF048307
	v_add_f32_e32 v1, 0, v1                                    // 00000029ED38: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000029ED3C: BF8700B1
	v_add_f32_e32 v13, v1, v2                                  // 00000029ED40: 061A0501
	ds_load_2addr_b32 v[1:2], v5 offset0:18 offset1:21         // 00000029ED44: D8DC1512 01000005
	v_add_f32_e32 v3, v13, v3                                  // 00000029ED4C: 0606070D
	v_add_f32_e32 v13, v3, v4                                  // 00000029ED50: 061A0903
	ds_load_2addr_b32 v[3:4], v5 offset0:24 offset1:27         // 00000029ED54: D8DC1B18 03000005
	v_add_f32_e32 v11, v13, v11                                // 00000029ED5C: 0616170D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000029ED60: BF8700C1
	v_add_f32_e32 v13, v11, v12                                // 00000029ED64: 061A190B
	ds_load_2addr_b32 v[11:12], v5 offset0:30 offset1:33       // 00000029ED68: D8DC211E 0B000005
	s_waitcnt lgkmcnt(2)                                       // 00000029ED70: BF89FC27
	v_add_f32_e32 v1, v13, v1                                  // 00000029ED74: 0602030D
	v_add_f32_e32 v1, v1, v2                                   // 00000029ED78: 06020501
	s_waitcnt lgkmcnt(1)                                       // 00000029ED7C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000029ED80: BF8700C1
	v_add_f32_e32 v3, v1, v3                                   // 00000029ED84: 06060701
	ds_load_2addr_b32 v[1:2], v5 offset0:36 offset1:39         // 00000029ED88: D8DC2724 01000005
	v_add_f32_e32 v3, v3, v4                                   // 00000029ED90: 06060903
	s_waitcnt lgkmcnt(1)                                       // 00000029ED94: BF89FC17
	v_add_f32_e32 v11, v3, v11                                 // 00000029ED98: 06161703
	ds_load_2addr_b32 v[3:4], v5 offset0:42 offset1:45         // 00000029ED9C: D8DC2D2A 03000005
	v_add_f32_e32 v5, v11, v12                                 // 00000029EDA4: 060A190B
	s_waitcnt lgkmcnt(1)                                       // 00000029EDA8: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029EDAC: BF870091
	v_add_f32_e32 v1, v5, v1                                   // 00000029EDB0: 06020305
	v_add_f32_e32 v1, v1, v2                                   // 00000029EDB4: 06020501
	s_waitcnt lgkmcnt(0)                                       // 00000029EDB8: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029EDBC: BF870091
	v_add_f32_e32 v1, v1, v3                                   // 00000029EDC0: 06020701
	v_add_f32_e32 v1, v1, v4                                   // 00000029EDC4: 06020901
	s_cbranch_scc1 178                                         // 00000029EDC8: BFA200B2 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0xd94>
	s_cmp_gt_i32 s7, 3                                         // 00000029EDCC: BF028307
	s_cbranch_scc0 112                                         // 00000029EDD0: BFA10070 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0xc94>
	s_cmp_gt_i32 s7, 4                                         // 00000029EDD4: BF028407
	s_cbranch_scc0 58                                          // 00000029EDD8: BFA1003A <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0xbc4>
	s_cmp_eq_u32 s7, 5                                         // 00000029EDDC: BF068507
	s_mov_b32 s12, -1                                          // 00000029EDE0: BE8C00C1
	s_cbranch_scc0 54                                          // 00000029EDE4: BFA10036 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0xbc0>
	s_ashr_i32 s14, s2, 31                                     // 00000029EDE8: 860E9F02
	s_load_b64 s[12:13], s[16:17], 0x10                        // 00000029EDEC: F4040308 F8000010
	s_lshr_b32 s14, s14, 23                                    // 00000029EDF4: 850E970E
	s_lshr_b32 s15, s10, 31                                    // 00000029EDF8: 850F9F0A
	s_add_i32 s14, s2, s14                                     // 00000029EDFC: 810E0E02
	s_add_i32 s18, s10, s15                                    // 00000029EE00: 81120F0A
	s_ashr_i32 s14, s14, 9                                     // 00000029EE04: 860E890E
	s_ashr_i32 s18, s18, 1                                     // 00000029EE08: 86128112
	s_ashr_i32 s15, s14, 31                                    // 00000029EE0C: 860F9F0E
	v_mad_i64_i32 v[2:3], null, s18, v0, 0                     // 00000029EE10: D6FF7C02 02020012
	s_lshl_b64 s[14:15], s[14:15], 9                           // 00000029EE18: 848E890E
	v_bfe_u32 v4, v1, 16, 1                                    // 00000029EE1C: D6100004 02052101
	s_sub_u32 s18, s2, s14                                     // 00000029EE24: 80920E02
	s_subb_u32 s19, s3, s15                                    // 00000029EE28: 82930F03
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000029EE2C: BF870119
	.long 0xd4540014                                           // 00000029EE30: D4540014
	v_cndmask_b32_e32 v0, 0x100, v18, vcc_lo                   // 00000029EE34: 020024FF 00000100
	v_add3_u32 v4, v1, v4, 0x7fff                              // 00000029EE3C: D6550004 03FE0901 00007FFF
	.long 0xd73c0002                                           // 00000029EE48: D73C0002
	v_cndmask_b32_e32 v1, 1, v2, vcc_lo                        // 00000029EE4C: 02020481
	s_and_b32 s21, s20, exec_lo                                // 00000029EE50: 8B157E14
	s_waitcnt lgkmcnt(0)                                       // 00000029EE54: BF89FC07
	s_cselect_b32 s12, s4, s12                                 // 00000029EE58: 980C0C04
	s_cselect_b32 s21, s5, s13                                 // 00000029EE5C: 98150D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029EE60: BF870091
	.long 0xd7006a02                                           // 00000029EE64: D7006A02
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 00000029EE68: 0202040C
	v_add_co_ci_u32_e64 v3, null, s21, v3, vcc_lo              // 00000029EE6C: D5207C03 01AA0615
	s_add_u32 s22, s18, 0xffffff00                             // 00000029EE74: 8016FF12 FFFFFF00
	s_addc_u32 s13, s19, -1                                    // 00000029EE7C: 820DC113
	s_and_b32 s20, s20, exec_lo                                // 00000029EE80: 8B147E14
	.long 0xd7006a02                                           // 00000029EE84: D7006A02
	v_cndmask_b32_e32 v0, v2, v14, vcc_lo                      // 00000029EE88: 02001D02
	s_cselect_b32 s13, s19, s13                                // 00000029EE8C: 980D0D13
	s_cselect_b32 s12, s18, s22                                // 00000029EE90: 980C1612
	v_add_co_ci_u32_e64 v3, null, s15, v3, vcc_lo              // 00000029EE94: D5207C03 01AA060F
	s_lshl_b64 s[12:13], s[12:13], 1                           // 00000029EE9C: 848C810C
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029EEA0: BF870099
	.long 0xd7006a02                                           // 00000029EEA4: D7006A02
	v_cndmask_b32_e32 v0, v2, v12, vcc_lo                      // 00000029EEA8: 02001902
	v_add_co_ci_u32_e64 v3, null, s13, v3, vcc_lo              // 00000029EEAC: D5207C03 01AA060D
	s_mov_b32 s12, 0                                           // 00000029EEB4: BE8C0080
	global_store_d16_hi_b16 v[2:3], v4, off                    // 00000029EEB8: DC960000 007C0402
	s_mov_b32 s13, 0                                           // 00000029EEC0: BE8D0080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000029EEC4: BF870009
	s_and_b32 vcc_lo, exec_lo, s13                             // 00000029EEC8: 8B6A0D7E
	s_cbranch_vccz 48                                          // 00000029EECC: BFA30030 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0xc90>
	v_mul_f32_e32 v2, 0xbfb8aa3b, v1                           // 00000029EED0: 100402FF BFB8AA3B
	s_lshl_b64 s[14:15], s[2:3], 2                             // 00000029EED8: 848E8202
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000029EEDC: BF870291
	v_exp_f32_e32 v2, v2                                       // 00000029EEE0: 7E044B02
	v_add_f32_e32 v5, 1.0, v2                                  // 00000029EEE4: 060A04F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029EEE8: BF870091
	v_div_scale_f32 v11, null, v5, v5, 1.0                     // 00000029EEEC: D6FC7C0B 03CA0B05
	v_rcp_f32_e32 v12, v11                                     // 00000029EEF4: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029EEF8: BF870095
	v_fma_f32 v2, -v11, v12, 1.0                               // 00000029EEFC: D6130002 23CA190B
	v_fmac_f32_e32 v12, v2, v12                                // 00000029EF04: 56181902
	v_div_scale_f32 v13, vcc_lo, 1.0, v5, 1.0                  // 00000029EF08: D6FC6A0D 03CA0AF2
	v_mad_u64_u32 v[2:3], null, s10, v0, 0                     // 00000029EF10: D6FE7C02 0202000A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000029EF18: BF870112
	v_mul_f32_e32 v14, v13, v12                                // 00000029EF1C: 101C190D
	v_mad_u64_u32 v[3:4], null, s11, v0, v[3:4]                // 00000029EF20: D6FE7C03 040E000B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029EF28: BF870092
	v_fma_f32 v15, -v11, v14, v13                              // 00000029EF2C: D613000F 24361D0B
	v_fmac_f32_e32 v14, v15, v12                               // 00000029EF34: 561C190F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000029EF38: BF870113
	.long 0xd73c0002                                           // 00000029EF3C: D73C0002
	v_cndmask_b32_e32 v1, 2, v2, vcc_lo                        // 00000029EF40: 02020482
	v_fma_f32 v4, -v11, v14, v13                               // 00000029EF44: D6130004 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000029EF4C: BF870191
	v_div_fmas_f32 v4, v4, v12, v14                            // 00000029EF50: D6370004 043A1904
	.long 0xd7006a02                                           // 00000029EF58: D7006A02
	v_cndmask_b32_e32 v1, s4, v2, vcc_lo                       // 00000029EF5C: 02020404
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000029EF60: BF870191
	v_add_co_ci_u32_e64 v3, null, s5, v3, vcc_lo               // 00000029EF64: D5207C03 01AA0605
	v_div_fixup_f32 v4, v4, v5, 1.0                            // 00000029EF6C: D6270004 03CA0B04
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029EF74: BF870093
	.long 0xd7006a02                                           // 00000029EF78: D7006A02
	v_cndmask_b32_e32 v0, v2, v14, vcc_lo                      // 00000029EF7C: 02001D02
	v_add_co_ci_u32_e64 v3, null, s15, v3, vcc_lo              // 00000029EF80: D5207C03 01AA060F
	global_store_b32 v[2:3], v4, off                           // 00000029EF88: DC6A0000 007C0402
	s_mov_b32 s13, 0                                           // 00000029EF90: BE8D0080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000029EF94: BF870009
	s_and_b32 vcc_lo, exec_lo, s13                             // 00000029EF98: 8B6A0D7E
	s_cbranch_vccz 60                                          // 00000029EF9C: BFA3003C <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0xd90>
	v_bfe_u32 v2, v1, 16, 1                                    // 00000029EFA0: D6100002 02052101
	s_lshl_b64 s[14:15], s[2:3], 2                             // 00000029EFA8: 848E8202
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029EFAC: BF870091
	v_add3_u32 v2, v1, v2, 0x7fff                              // 00000029EFB0: D6550002 03FE0501 00007FFF
	v_and_b32_e32 v2, 0xffff0000, v2                           // 00000029EFBC: 360404FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029EFC4: BF870091
	v_mul_f32_e32 v2, s6, v2                                   // 00000029EFC8: 10040406
	v_mul_f32_e32 v2, 0xbfb8aa3b, v2                           // 00000029EFCC: 100404FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000029EFD4: BF870291
	v_exp_f32_e32 v2, v2                                       // 00000029EFD8: 7E044B02
	v_add_f32_e32 v5, 1.0, v2                                  // 00000029EFDC: 060A04F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029EFE0: BF870091
	v_div_scale_f32 v11, null, v5, v5, 1.0                     // 00000029EFE4: D6FC7C0B 03CA0B05
	v_rcp_f32_e32 v12, v11                                     // 00000029EFEC: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029EFF0: BF870095
	v_fma_f32 v2, -v11, v12, 1.0                               // 00000029EFF4: D6130002 23CA190B
	v_fmac_f32_e32 v12, v2, v12                                // 00000029EFFC: 56181902
	v_div_scale_f32 v13, vcc_lo, 1.0, v5, 1.0                  // 00000029F000: D6FC6A0D 03CA0AF2
	v_mad_u64_u32 v[2:3], null, s10, v0, 0                     // 00000029F008: D6FE7C02 0202000A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029F010: BF870092
	v_mul_f32_e32 v14, v13, v12                                // 00000029F014: 101C190D
	v_fma_f32 v4, -v11, v14, v13                               // 00000029F018: D6130004 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000029F020: BF870211
	v_fmac_f32_e32 v14, v4, v12                                // 00000029F024: 561C1904
	v_mad_u64_u32 v[3:4], null, s11, v0, v[3:4]                // 00000029F028: D6FE7C03 040E000B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000029F030: BF870112
	v_fma_f32 v4, -v11, v14, v13                               // 00000029F034: D6130004 24361D0B
	.long 0xd73c0002                                           // 00000029F03C: D73C0002
	v_cndmask_b32_e32 v1, 2, v2, vcc_lo                        // 00000029F040: 02020482
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000029F044: BF870112
	v_div_fmas_f32 v4, v4, v12, v14                            // 00000029F048: D6370004 043A1904
	.long 0xd7006a02                                           // 00000029F050: D7006A02
	v_cndmask_b32_e32 v1, s4, v2, vcc_lo                       // 00000029F054: 02020404
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000029F058: BF870212
	v_div_fixup_f32 v4, v4, v5, 1.0                            // 00000029F05C: D6270004 03CA0B04
	v_add_co_ci_u32_e64 v3, null, s5, v3, vcc_lo               // 00000029F064: D5207C03 01AA0605
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000029F06C: BF870193
	.long 0xd7006a02                                           // 00000029F070: D7006A02
	v_cndmask_b32_e32 v0, v2, v14, vcc_lo                      // 00000029F074: 02001D02
	v_add_f32_e32 v4, v4, v4                                   // 00000029F078: 06080904
	s_delay_alu instid0(VALU_DEP_3)                            // 00000029F07C: BF870003
	v_add_co_ci_u32_e64 v3, null, s15, v3, vcc_lo              // 00000029F080: D5207C03 01AA060F
	global_store_b32 v[2:3], v4, off                           // 00000029F088: DC6A0000 007C0402
	s_mov_b32 s13, 0                                           // 00000029F090: BE8D0080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000029F094: BF870009
	s_and_b32 vcc_lo, exec_lo, s13                             // 00000029F098: 8B6A0D7E
	s_cbranch_vccz 72                                          // 00000029F09C: BFA30048 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0xec0>
	s_cmp_gt_i32 s7, 1                                         // 00000029F0A0: BF028107
	s_mov_b32 s9, -1                                           // 00000029F0A4: BE8900C1
	s_cbranch_scc0 63                                          // 00000029F0A8: BFA1003F <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0xea8>
	v_bfe_u32 v2, v1, 16, 1                                    // 00000029F0AC: D6100002 02052101
	s_lshl_b64 s[14:15], s[2:3], 1                             // 00000029F0B4: 848E8102
	s_mov_b32 s9, 0                                            // 00000029F0B8: BE890080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029F0BC: BF870091
	v_add3_u32 v2, v1, v2, 0x7fff                              // 00000029F0C0: D6550002 03FE0501 00007FFF
	v_and_b32_e32 v2, 0xffff0000, v2                           // 00000029F0CC: 360404FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029F0D4: BF870091
	v_mul_f32_e32 v2, 0xbfb8aa3b, v2                           // 00000029F0D8: 100404FF BFB8AA3B
	v_exp_f32_e32 v2, v2                                       // 00000029F0E0: 7E044B02
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029F0E4: BF870095
	v_add_f32_e32 v5, 1.0, v2                                  // 00000029F0E8: 060A04F2
	v_div_scale_f32 v4, null, v5, v5, 1.0                      // 00000029F0EC: D6FC7C04 03CA0B05
	v_div_scale_f32 v12, vcc_lo, 1.0, v5, 1.0                  // 00000029F0F4: D6FC6A0C 03CA0AF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000029F0FC: BF870292
	v_rcp_f32_e32 v11, v4                                      // 00000029F100: 7E165504
	v_fma_f32 v2, -v4, v11, 1.0                                // 00000029F104: D6130002 23CA1704
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000029F10C: BF870121
	v_fmac_f32_e32 v11, v2, v11                                // 00000029F110: 56161702
	v_mad_u64_u32 v[2:3], null, s10, v0, 0                     // 00000029F114: D6FE7C02 0202000A
	v_mul_f32_e32 v13, v12, v11                                // 00000029F11C: 101A170C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029F120: BF870091
	v_fma_f32 v14, -v4, v13, v12                               // 00000029F124: D613000E 24321B04
	v_fmac_f32_e32 v13, v14, v11                               // 00000029F12C: 561A170E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000029F130: BF870121
	v_fma_f32 v12, -v4, v13, v12                               // 00000029F134: D613000C 24321B04
	v_mad_u64_u32 v[3:4], null, s11, v0, v[3:4]                // 00000029F13C: D6FE7C03 040E000B
	v_div_fmas_f32 v4, v12, v11, v13                           // 00000029F144: D6370004 0436170C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000029F14C: BF870112
	.long 0xd73c0002                                           // 00000029F150: D73C0002
	v_cndmask_b32_e32 v1, 1, v2, vcc_lo                        // 00000029F154: 02020481
	v_div_fixup_f32 v4, v4, v5, 1.0                            // 00000029F158: D6270004 03CA0B04
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000029F160: BF870112
	.long 0xd7006a02                                           // 00000029F164: D7006A02
	v_cndmask_b32_e32 v1, s4, v2, vcc_lo                       // 00000029F168: 02020404
	v_bfe_u32 v5, v4, 16, 1                                    // 00000029F16C: D6100005 02052104
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000029F174: BF870194
	v_add_co_ci_u32_e64 v3, null, s5, v3, vcc_lo               // 00000029F178: D5207C03 01AA0605
	.long 0xd7006a02                                           // 00000029F180: D7006A02
	v_cndmask_b32_e32 v0, v2, v14, vcc_lo                      // 00000029F184: 02001D02
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000029F188: BF870193
	v_add3_u32 v4, v4, v5, 0x7fff                              // 00000029F18C: D6550004 03FE0B04 00007FFF
	v_add_co_ci_u32_e64 v3, null, s15, v3, vcc_lo              // 00000029F198: D5207C03 01AA060F
	global_store_d16_hi_b16 v[2:3], v4, off                    // 00000029F1A0: DC960000 007C0402
	s_and_not1_b32 vcc_lo, exec_lo, s9                         // 00000029F1A8: 916A097E
	s_mov_b32 s9, 0                                            // 00000029F1AC: BE890080
	s_cbranch_vccnz 3                                          // 00000029F1B0: BFA40003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0xec0>
	s_cmp_lg_u32 s7, 1                                         // 00000029F1B4: BF078107
	s_mov_b32 s9, -1                                           // 00000029F1B8: BE8900C1
	s_cselect_b32 s12, -1, 0                                   // 00000029F1BC: 980C80C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000029F1C0: BF8700A1
	v_bfe_u32 v2, v1, 16, 1                                    // 00000029F1C4: D6100002 02052101
	s_and_b32 vcc_lo, exec_lo, s12                             // 00000029F1CC: 8B6A0C7E
	v_add3_u32 v1, v1, v2, 0x7fff                              // 00000029F1D0: D6550001 03FE0501 00007FFF
	s_cbranch_vccz 21                                          // 00000029F1DC: BFA30015 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0xf34>
	v_mad_u64_u32 v[2:3], null, s10, v0, 0                     // 00000029F1E0: D6FE7C02 0202000A
	s_lshl_b64 s[12:13], s[2:3], 1                             // 00000029F1E8: 848C8102
	s_mov_b32 s9, 0                                            // 00000029F1EC: BE890080
	v_mad_u64_u32 v[3:4], null, s11, v0, v[3:4]                // 00000029F1F0: D6FE7C03 040E000B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029F1F8: BF870091
	.long 0xd73c0002                                           // 00000029F1FC: D73C0002
	v_cndmask_b32_e32 v1, 1, v2, vcc_lo                        // 00000029F200: 02020481
	.long 0xd7006a02                                           // 00000029F204: D7006A02
	v_cndmask_b32_e32 v1, s4, v2, vcc_lo                       // 00000029F208: 02020404
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000029F20C: BF870111
	v_add_co_ci_u32_e64 v3, null, s5, v3, vcc_lo               // 00000029F210: D5207C03 01AA0605
	.long 0xd7006a02                                           // 00000029F218: D7006A02
	v_cndmask_b32_e32 v0, v2, v12, vcc_lo                      // 00000029F21C: 02001902
	s_delay_alu instid0(VALU_DEP_1)                            // 00000029F220: BF870001
	v_add_co_ci_u32_e64 v3, null, s13, v3, vcc_lo              // 00000029F224: D5207C03 01AA060D
	global_store_d16_hi_b16 v[2:3], v1, off                    // 00000029F22C: DC960000 007C0102
	s_and_not1_b32 vcc_lo, exec_lo, s9                         // 00000029F234: 916A097E
	s_cbranch_vccnz 58                                         // 00000029F238: BFA4003A <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1024>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000029F23C: BF8700A1
	v_and_b32_e32 v1, 0xffff0000, v1                           // 00000029F240: 360202FF FFFF0000
	s_lshl_b64 s[2:3], s[2:3], 1                               // 00000029F248: 84828102
	v_mul_f32_e32 v4, s6, v1                                   // 00000029F24C: 10080206
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029F250: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v4                           // 00000029F254: 100208FF BFB8AA3B
	v_exp_f32_e32 v1, v1                                       // 00000029F25C: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029F260: BF870095
	v_add_f32_e32 v5, 1.0, v1                                  // 00000029F264: 060A02F2
	v_div_scale_f32 v3, null, v5, v5, v4                       // 00000029F268: D6FC7C03 04120B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000029F270: BF870291
	v_rcp_f32_e32 v11, v3                                      // 00000029F274: 7E165503
	v_fma_f32 v1, -v3, v11, 1.0                                // 00000029F278: D6130001 23CA1703
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000029F280: BF870131
	v_fmac_f32_e32 v11, v1, v11                                // 00000029F284: 56161701
	v_div_scale_f32 v12, vcc_lo, v4, v5, v4                    // 00000029F288: D6FC6A0C 04120B04
	v_mad_u64_u32 v[1:2], null, s10, v0, 0                     // 00000029F290: D6FE7C01 0202000A
	v_mul_f32_e32 v13, v12, v11                                // 00000029F298: 101A170C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029F29C: BF870091
	v_fma_f32 v14, -v3, v13, v12                               // 00000029F2A0: D613000E 24321B03
	v_fmac_f32_e32 v13, v14, v11                               // 00000029F2A8: 561A170E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000029F2AC: BF870121
	v_fma_f32 v12, -v3, v13, v12                               // 00000029F2B0: D613000C 24321B03
	v_mad_u64_u32 v[2:3], null, s11, v0, v[2:3]                // 00000029F2B8: D6FE7C02 040A000B
	v_div_fmas_f32 v0, v12, v11, v13                           // 00000029F2C0: D6370000 0436170C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000029F2C8: BF870191
	v_div_fixup_f32 v3, v0, v5, v4                             // 00000029F2CC: D6270003 04120B00
	.long 0xd73c0000                                           // 00000029F2D4: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000029F2D8: 02020281
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000029F2DC: BF870112
	v_bfe_u32 v2, v3, 16, 1                                    // 00000029F2E0: D6100002 02052103
	.long 0xd7006a00                                           // 00000029F2E8: D7006A00
	v_cndmask_b32_e32 v1, s4, v0, vcc_lo                       // 00000029F2EC: 02020004
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000029F2F0: BF870191
	v_add_co_ci_u32_e64 v1, null, s5, v1, vcc_lo               // 00000029F2F4: D5207C01 01AA0205
	v_add3_u32 v2, v3, v2, 0x7fff                              // 00000029F2FC: D6550002 03FE0503 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029F308: BF870093
	.long 0xd7006a00                                           // 00000029F30C: D7006A00
	v_cndmask_b32_e32 v0, v0, v2, vcc_lo                       // 00000029F310: 02000500
	v_add_co_ci_u32_e64 v1, null, s3, v1, vcc_lo               // 00000029F314: D5207C01 01AA0203
	global_store_d16_hi_b16 v[0:1], v2, off                    // 00000029F31C: DC960000 007C0200
	s_or_b32 exec_lo, exec_lo, s8                              // 00000029F324: 8C7E087E
	s_mov_b32 s3, 0                                            // 00000029F328: BE830080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000029F32C: BF870009
	s_and_b32 vcc_lo, exec_lo, s3                              // 00000029F330: 8B6A037E
	s_cbranch_vccz 830                                         // 00000029F334: BFA3033E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1d30>
	s_and_b32 s0, s1, s0                                       // 00000029F338: 8B000001
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000029F33C: BF870009
	s_and_saveexec_b32 s1, s0                                  // 00000029F340: BE812000
	s_cbranch_execz 826                                        // 00000029F344: BFA5033A <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1d30>
	v_ashrrev_i32_e32 v0, 31, v10                              // 00000029F348: 3400149F
	s_clause 0x1                                               // 00000029F34C: BF850001
	s_load_b64 s[4:5], s[16:17], 0x8                           // 00000029F350: F4040108 F8000008
	s_load_b64 s[2:3], s[16:17], 0x38                          // 00000029F358: F4040088 F8000038
	.long 0xd73c0002                                           // 00000029F360: D73C0002
	v_cndmask_b32_e32 v1, 2, v9, vcc_lo                        // 00000029F364: 02021282
	s_mov_b32 s7, -1                                           // 00000029F368: BE8700C1
	s_mov_b32 s1, 0                                            // 00000029F36C: BE810080
	v_lshrrev_b32_e32 v0, 23, v0                               // 00000029F370: 32000097
	s_mov_b32 s6, 0                                            // 00000029F374: BE860080
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000029F378: BF8701B1
	.long 0xd7006a04                                           // 00000029F37C: D7006A04
	v_cndmask_b32_e32 v1, v9, v0, vcc_lo                       // 00000029F380: 02020109
	.long 0xd73c0000                                           // 00000029F384: D73C0000
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 00000029F388: 02021281
	v_add_co_ci_u32_e64 v11, null, 0, v10, vcc_lo              // 00000029F38C: D5207C0B 01AA1480
	v_and_b32_e32 v12, 0xfffffe00, v4                          // 00000029F394: 361808FF FFFFFE00
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029F39C: BF870093
	.long 0xd7016a00                                           // 00000029F3A0: D7016A00
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 00000029F3A4: 02020080
	v_sub_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 00000029F3A8: D5217C01 01AA0280
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029F3B0: BF870093
	.long 0xd7016a04                                           // 00000029F3B4: D7016A04
	v_cndmask_b32_e32 v1, v9, v12, vcc_lo                      // 00000029F3B8: 02021909
	v_sub_co_ci_u32_e64 v5, null, v10, v11, vcc_lo             // 00000029F3BC: D5217C05 01AA170A
	s_waitcnt lgkmcnt(0)                                       // 00000029F3C4: BF89FC07
	.long 0xd7006a02                                           // 00000029F3C8: D7006A02
	v_cndmask_b32_e32 v1, s4, v2, vcc_lo                       // 00000029F3CC: 02020404
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000029F3D0: BF8700D1
	v_add_co_ci_u32_e64 v3, null, s5, v3, vcc_lo               // 00000029F3D4: D5207C03 01AA0605
	.long 0xd7006a09                                           // 00000029F3DC: D7006A09
	v_cndmask_b32_e32 v1, 0xffffff00, v4, vcc_lo               // 00000029F3E0: 020208FF FFFFFF00
	.long 0xd4540000                                           // 00000029F3E8: D4540000
	v_cndmask_b32_e32 v1, 0x100, v4, vcc_lo                    // 00000029F3EC: 020208FF 00000100
	v_add_co_ci_u32_e64 v10, null, -1, v5, vcc_lo              // 00000029F3F4: D5207C0A 01AA0AC1
	.long 0xd7006a00                                           // 00000029F3FC: D7006A00
	v_cndmask_b32_e32 v1, v2, v0, vcc_lo                       // 00000029F400: 02020102
	v_add_co_ci_u32_e64 v1, null, v3, v1, vcc_lo               // 00000029F404: D5207C01 01AA0303
	s_delay_alu instid0(VALU_DEP_3)                            // 00000029F40C: BF870003
	v_cndmask_b32_e64 v5, v10, v5, s0                          // 00000029F410: D5010005 00020B0A
	v_cndmask_b32_e64 v4, v9, v4, s0                           // 00000029F418: D5010004 00020909
	s_cmp_lt_i32 s3, 3                                         // 00000029F420: BF048303
	s_cbranch_scc1 118                                         // 00000029F424: BFA20076 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1300>
	s_cmp_gt_i32 s3, 3                                         // 00000029F428: BF028303
	s_cbranch_scc0 70                                          // 00000029F42C: BFA10046 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1248>
	s_cmp_gt_i32 s3, 4                                         // 00000029F430: BF028403
	s_cbranch_scc0 34                                          // 00000029F434: BFA10022 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x11c0>
	s_cmp_eq_u32 s3, 5                                         // 00000029F438: BF068503
	s_mov_b32 s6, -1                                           // 00000029F43C: BE8600C1
	s_cbranch_scc0 30                                          // 00000029F440: BFA1001E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x11bc>
	s_load_b64 s[6:7], s[16:17], 0x10                          // 00000029F444: F4040188 F8000010
	v_dual_mov_b32 v9, s4 :: v_dual_mov_b32 v10, s5            // 00000029F44C: CA100004 090A0005
	v_bfe_u32 v14, v8, 16, 1                                   // 00000029F454: D610000E 02052108
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000029F45C: BF8701A1
	v_add3_u32 v14, v8, v14, 0x7fff                            // 00000029F460: D655000E 03FE1D08 00007FFF
	s_waitcnt lgkmcnt(0)                                       // 00000029F46C: BF89FC07
	v_cndmask_b32_e64 v13, s6, v9, s0                          // 00000029F470: D501000D 00021206
	v_cndmask_b32_e64 v15, s7, v10, s0                         // 00000029F478: D501000F 00021407
	.long 0xd73c0009                                           // 00000029F480: D73C0009
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 00000029F484: 02020881
	s_mov_b32 s6, 0                                            // 00000029F488: BE860080
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029F48C: BF870093
	.long 0xd7006a0d                                           // 00000029F490: D7006A0D
	v_cndmask_b32_e32 v1, v13, v12, vcc_lo                     // 00000029F494: 0202190D
	v_add_co_ci_u32_e64 v15, null, v15, v11, vcc_lo            // 00000029F498: D5207C0F 01AA170F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029F4A0: BF870092
	.long 0xd7006a09                                           // 00000029F4A4: D7006A09
	v_cndmask_b32_e32 v1, v13, v9, vcc_lo                      // 00000029F4A8: 0202130D
	v_add_co_ci_u32_e64 v10, null, v15, v10, vcc_lo            // 00000029F4AC: D5207C0A 01AA150F
	global_store_d16_hi_b16 v[9:10], v14, off                  // 00000029F4B4: DC960000 007C0E09
	s_mov_b32 s7, 0                                            // 00000029F4BC: BE870080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000029F4C0: BF870009
	s_and_b32 vcc_lo, exec_lo, s7                              // 00000029F4C4: 8B6A077E
	s_cbranch_vccz 30                                          // 00000029F4C8: BFA3001E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1244>
	v_mul_f32_e32 v9, 0xbfb8aa3b, v8                           // 00000029F4CC: 101210FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000029F4D4: BF870291
	v_exp_f32_e32 v9, v9                                       // 00000029F4D8: 7E124B09
	v_add_f32_e32 v9, 1.0, v9                                  // 00000029F4DC: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029F4E0: BF870091
	v_div_scale_f32 v10, null, v9, v9, 1.0                     // 00000029F4E4: D6FC7C0A 03CA1309
	v_rcp_f32_e32 v13, v10                                     // 00000029F4EC: 7E1A550A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029F4F0: BF870095
	v_fma_f32 v14, -v10, v13, 1.0                              // 00000029F4F4: D613000E 23CA1B0A
	v_fmac_f32_e32 v13, v14, v13                               // 00000029F4FC: 561A1B0E
	v_div_scale_f32 v14, vcc_lo, 1.0, v9, 1.0                  // 00000029F500: D6FC6A0E 03CA12F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029F508: BF870091
	v_mul_f32_e32 v15, v14, v13                                // 00000029F50C: 101E1B0E
	v_fma_f32 v16, -v10, v15, v14                              // 00000029F510: D6130010 243A1F0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029F518: BF870091
	v_fmac_f32_e32 v15, v16, v13                               // 00000029F51C: 561E1B10
	v_fma_f32 v10, -v10, v15, v14                              // 00000029F520: D613000A 243A1F0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029F528: BF870091
	v_div_fmas_f32 v10, v10, v13, v15                          // 00000029F52C: D637000A 043E1B0A
	v_div_fixup_f32 v9, v10, v9, 1.0                           // 00000029F534: D6270009 03CA130A
	global_store_b32 v[2:3], v9, off                           // 00000029F53C: DC6A0000 007C0902
	s_mov_b32 s7, 0                                            // 00000029F544: BE870080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000029F548: BF870009
	s_and_b32 vcc_lo, exec_lo, s7                              // 00000029F54C: 8B6A077E
	s_cbranch_vccz 42                                          // 00000029F550: BFA3002A <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x12fc>
	v_bfe_u32 v9, v8, 16, 1                                    // 00000029F554: D6100009 02052108
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029F55C: BF870091
	v_add3_u32 v9, v8, v9, 0x7fff                              // 00000029F560: D6550009 03FE1308 00007FFF
	v_and_b32_e32 v9, 0xffff0000, v9                           // 00000029F56C: 361212FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029F574: BF870091
	v_mul_f32_e32 v9, s2, v9                                   // 00000029F578: 10121202
	v_mul_f32_e32 v9, 0xbfb8aa3b, v9                           // 00000029F57C: 101212FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000029F584: BF870291
	v_exp_f32_e32 v9, v9                                       // 00000029F588: 7E124B09
	v_add_f32_e32 v9, 1.0, v9                                  // 00000029F58C: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029F590: BF870091
	v_div_scale_f32 v10, null, v9, v9, 1.0                     // 00000029F594: D6FC7C0A 03CA1309
	v_rcp_f32_e32 v13, v10                                     // 00000029F59C: 7E1A550A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029F5A0: BF870095
	v_fma_f32 v14, -v10, v13, 1.0                              // 00000029F5A4: D613000E 23CA1B0A
	v_fmac_f32_e32 v13, v14, v13                               // 00000029F5AC: 561A1B0E
	v_div_scale_f32 v14, vcc_lo, 1.0, v9, 1.0                  // 00000029F5B0: D6FC6A0E 03CA12F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029F5B8: BF870091
	v_mul_f32_e32 v15, v14, v13                                // 00000029F5BC: 101E1B0E
	v_fma_f32 v16, -v10, v15, v14                              // 00000029F5C0: D6130010 243A1F0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029F5C8: BF870091
	v_fmac_f32_e32 v15, v16, v13                               // 00000029F5CC: 561E1B10
	v_fma_f32 v10, -v10, v15, v14                              // 00000029F5D0: D613000A 243A1F0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029F5D8: BF870091
	v_div_fmas_f32 v10, v10, v13, v15                          // 00000029F5DC: D637000A 043E1B0A
	v_div_fixup_f32 v9, v10, v9, 1.0                           // 00000029F5E4: D6270009 03CA130A
	s_delay_alu instid0(VALU_DEP_1)                            // 00000029F5EC: BF870001
	v_add_f32_e32 v9, v9, v9                                   // 00000029F5F0: 06121309
	global_store_b32 v[2:3], v9, off                           // 00000029F5F4: DC6A0000 007C0902
	s_mov_b32 s7, 0                                            // 00000029F5FC: BE870080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000029F600: BF870009
	s_and_b32 vcc_lo, exec_lo, s7                              // 00000029F604: 8B6A077E
	s_cbranch_vccz 55                                          // 00000029F608: BFA30037 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x13e8>
	s_cmp_gt_i32 s3, 1                                         // 00000029F60C: BF028103
	s_mov_b32 s1, -1                                           // 00000029F610: BE8100C1
	s_cbranch_scc0 46                                          // 00000029F614: BFA1002E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x13d0>
	v_bfe_u32 v9, v8, 16, 1                                    // 00000029F618: D6100009 02052108
	s_mov_b32 s1, 0                                            // 00000029F620: BE810080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029F624: BF870091
	v_add3_u32 v9, v8, v9, 0x7fff                              // 00000029F628: D6550009 03FE1308 00007FFF
	v_and_b32_e32 v9, 0xffff0000, v9                           // 00000029F634: 361212FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029F63C: BF870091
	v_mul_f32_e32 v9, 0xbfb8aa3b, v9                           // 00000029F640: 101212FF BFB8AA3B
	v_exp_f32_e32 v9, v9                                       // 00000029F648: 7E124B09
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029F64C: BF870095
	v_add_f32_e32 v9, 1.0, v9                                  // 00000029F650: 061212F2
	v_div_scale_f32 v10, null, v9, v9, 1.0                     // 00000029F654: D6FC7C0A 03CA1309
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000029F65C: BF870291
	v_rcp_f32_e32 v13, v10                                     // 00000029F660: 7E1A550A
	v_fma_f32 v14, -v10, v13, 1.0                              // 00000029F664: D613000E 23CA1B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000029F66C: BF8700A1
	v_fmac_f32_e32 v13, v14, v13                               // 00000029F670: 561A1B0E
	v_div_scale_f32 v14, vcc_lo, 1.0, v9, 1.0                  // 00000029F674: D6FC6A0E 03CA12F2
	v_mul_f32_e32 v15, v14, v13                                // 00000029F67C: 101E1B0E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029F680: BF870091
	v_fma_f32 v16, -v10, v15, v14                              // 00000029F684: D6130010 243A1F0A
	v_fmac_f32_e32 v15, v16, v13                               // 00000029F68C: 561E1B10
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029F690: BF870091
	v_fma_f32 v10, -v10, v15, v14                              // 00000029F694: D613000A 243A1F0A
	v_div_fmas_f32 v10, v10, v13, v15                          // 00000029F69C: D637000A 043E1B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029F6A4: BF870091
	v_div_fixup_f32 v9, v10, v9, 1.0                           // 00000029F6A8: D6270009 03CA130A
	v_bfe_u32 v10, v9, 16, 1                                   // 00000029F6B0: D610000A 02052109
	s_delay_alu instid0(VALU_DEP_1)                            // 00000029F6B8: BF870001
	v_add3_u32 v9, v9, v10, 0x7fff                             // 00000029F6BC: D6550009 03FE1509 00007FFF
	global_store_d16_hi_b16 v[0:1], v9, off                    // 00000029F6C8: DC960000 007C0900
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 00000029F6D0: 916A017E
	s_mov_b32 s1, 0                                            // 00000029F6D4: BE810080
	s_cbranch_vccnz 3                                          // 00000029F6D8: BFA40003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x13e8>
	s_cmp_lg_u32 s3, 1                                         // 00000029F6DC: BF078103
	s_mov_b32 s1, -1                                           // 00000029F6E0: BE8100C1
	s_cselect_b32 s6, -1, 0                                    // 00000029F6E4: 980680C1
	v_bfe_u32 v9, v8, 16, 1                                    // 00000029F6E8: D6100009 02052108
	s_and_b32 vcc_lo, exec_lo, s6                              // 00000029F6F0: 8B6A067E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000029F6F4: BF870001
	v_add3_u32 v8, v8, v9, 0x7fff                              // 00000029F6F8: D6550008 03FE1308 00007FFF
	s_cbranch_vccz 3                                           // 00000029F704: BFA30003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1414>
	s_mov_b32 s1, 0                                            // 00000029F708: BE810080
	global_store_d16_hi_b16 v[0:1], v8, off                    // 00000029F70C: DC960000 007C0800
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 00000029F714: 916A017E
	s_cbranch_vccnz 41                                         // 00000029F718: BFA40029 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x14c0>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029F71C: BF870091
	v_and_b32_e32 v8, 0xffff0000, v8                           // 00000029F720: 361010FF FFFF0000
	v_mul_f32_e32 v8, s2, v8                                   // 00000029F728: 10101002
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029F72C: BF870091
	v_mul_f32_e32 v9, 0xbfb8aa3b, v8                           // 00000029F730: 101210FF BFB8AA3B
	v_exp_f32_e32 v9, v9                                       // 00000029F738: 7E124B09
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029F73C: BF870095
	v_add_f32_e32 v9, 1.0, v9                                  // 00000029F740: 061212F2
	v_div_scale_f32 v10, null, v9, v9, v8                      // 00000029F744: D6FC7C0A 04221309
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000029F74C: BF870291
	v_rcp_f32_e32 v13, v10                                     // 00000029F750: 7E1A550A
	v_fma_f32 v14, -v10, v13, 1.0                              // 00000029F754: D613000E 23CA1B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000029F75C: BF8700A1
	v_fmac_f32_e32 v13, v14, v13                               // 00000029F760: 561A1B0E
	v_div_scale_f32 v14, vcc_lo, v8, v9, v8                    // 00000029F764: D6FC6A0E 04221308
	v_mul_f32_e32 v15, v14, v13                                // 00000029F76C: 101E1B0E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029F770: BF870091
	v_fma_f32 v16, -v10, v15, v14                              // 00000029F774: D6130010 243A1F0A
	v_fmac_f32_e32 v15, v16, v13                               // 00000029F77C: 561E1B10
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029F780: BF870091
	v_fma_f32 v10, -v10, v15, v14                              // 00000029F784: D613000A 243A1F0A
	v_div_fmas_f32 v10, v10, v13, v15                          // 00000029F78C: D637000A 043E1B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029F794: BF870091
	v_div_fixup_f32 v8, v10, v9, v8                            // 00000029F798: D6270008 0422130A
	v_bfe_u32 v9, v8, 16, 1                                    // 00000029F7A0: D6100009 02052108
	s_delay_alu instid0(VALU_DEP_1)                            // 00000029F7A8: BF870001
	v_add3_u32 v8, v8, v9, 0x7fff                              // 00000029F7AC: D6550008 03FE1308 00007FFF
	global_store_d16_hi_b16 v[0:1], v8, off                    // 00000029F7B8: DC960000 007C0800
	s_mov_b32 s7, -1                                           // 00000029F7C0: BE8700C1
	s_mov_b32 s1, 0                                            // 00000029F7C4: BE810080
	s_cmp_lt_i32 s3, 3                                         // 00000029F7C8: BF048303
	s_mov_b32 s6, 0                                            // 00000029F7CC: BE860080
	s_cbranch_scc1 135                                         // 00000029F7D0: BFA20087 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x16f0>
	s_cmp_gt_i32 s3, 3                                         // 00000029F7D4: BF028303
	s_cbranch_scc0 82                                          // 00000029F7D8: BFA10052 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1624>
	s_cmp_gt_i32 s3, 4                                         // 00000029F7DC: BF028403
	s_cbranch_scc0 40                                          // 00000029F7E0: BFA10028 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1584>
	s_cmp_eq_u32 s3, 5                                         // 00000029F7E4: BF068503
	s_mov_b32 s6, -1                                           // 00000029F7E8: BE8600C1
	s_cbranch_scc0 36                                          // 00000029F7EC: BFA10024 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1580>
	s_load_b64 s[6:7], s[16:17], 0x10                          // 00000029F7F0: F4040188 F8000010
	v_dual_mov_b32 v8, s4 :: v_dual_mov_b32 v9, s5             // 00000029F7F8: CA100004 08080005
	v_bfe_u32 v10, v7, 16, 1                                   // 00000029F800: D610000A 02052107
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000029F808: BF8701A1
	v_add3_u32 v10, v7, v10, 0x7fff                            // 00000029F80C: D655000A 03FE1507 00007FFF
	s_waitcnt lgkmcnt(0)                                       // 00000029F818: BF89FC07
	v_cndmask_b32_e64 v8, s6, v8, s0                           // 00000029F81C: D5010008 00021006
	v_cndmask_b32_e64 v9, s7, v9, s0                           // 00000029F824: D5010009 00021207
	s_and_b32 s6, s10, -2                                      // 00000029F82C: 8B06C20A
	s_delay_alu instid0(VALU_DEP_2) | instid1(SALU_CYCLE_1)    // 00000029F830: BF870482
	.long 0xd7006a0d                                           // 00000029F834: D7006A0D
	v_cndmask_b32_e32 v0, v8, v6, vcc_lo                       // 00000029F838: 02000D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000029F83C: BF8701A1
	v_add_co_ci_u32_e64 v14, null, s11, v9, vcc_lo             // 00000029F840: D5207C0E 01AA120B
	.long 0xd73c0008                                           // 00000029F848: D73C0008
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 00000029F84C: 02020881
	.long 0xd7006a0d                                           // 00000029F850: D7006A0D
	v_cndmask_b32_e32 v1, v13, v12, vcc_lo                     // 00000029F854: 0202190D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000029F858: BF8700B1
	v_add_co_ci_u32_e64 v14, null, v14, v11, vcc_lo            // 00000029F85C: D5207C0E 01AA170E
	s_mov_b32 s6, 0                                            // 00000029F864: BE860080
	.long 0xd7006a08                                           // 00000029F868: D7006A08
	v_cndmask_b32_e32 v1, v13, v8, vcc_lo                      // 00000029F86C: 0202110D
	v_add_co_ci_u32_e64 v9, null, v14, v9, vcc_lo              // 00000029F870: D5207C09 01AA130E
	global_store_d16_hi_b16 v[8:9], v10, off                   // 00000029F878: DC960000 007C0A08
	s_mov_b32 s7, 0                                            // 00000029F880: BE870080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000029F884: BF870009
	s_and_b32 vcc_lo, exec_lo, s7                              // 00000029F888: 8B6A077E
	s_cbranch_vccz 36                                          // 00000029F88C: BFA30024 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1620>
	v_mul_f32_e32 v8, 0xbfb8aa3b, v7                           // 00000029F890: 10100EFF BFB8AA3B
	s_lshl_b64 s[8:9], s[10:11], 2                             // 00000029F898: 8488820A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000029F89C: BF870291
	v_exp_f32_e32 v8, v8                                       // 00000029F8A0: 7E104B08
	v_add_f32_e32 v8, 1.0, v8                                  // 00000029F8A4: 061010F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000029F8A8: BF870121
	v_div_scale_f32 v9, null, v8, v8, 1.0                      // 00000029F8AC: D6FC7C09 03CA1108
	v_div_scale_f32 v14, vcc_lo, 1.0, v8, 1.0                  // 00000029F8B4: D6FC6A0E 03CA10F2
	v_rcp_f32_e32 v10, v9                                      // 00000029F8BC: 7E145509
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029F8C0: BF870095
	v_fma_f32 v13, -v9, v10, 1.0                               // 00000029F8C4: D613000D 23CA1509
	v_fmac_f32_e32 v10, v13, v10                               // 00000029F8CC: 5614150D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029F8D0: BF870091
	v_mul_f32_e32 v13, v14, v10                                // 00000029F8D4: 101A150E
	v_fma_f32 v15, -v9, v13, v14                               // 00000029F8D8: D613000F 243A1B09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029F8E0: BF870091
	v_fmac_f32_e32 v13, v15, v10                               // 00000029F8E4: 561A150F
	v_fma_f32 v9, -v9, v13, v14                                // 00000029F8E8: D6130009 243A1B09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029F8F0: BF870091
	v_div_fmas_f32 v9, v9, v10, v13                            // 00000029F8F4: D6370009 04361509
	v_div_fixup_f32 v10, v9, v8, 1.0                           // 00000029F8FC: D627000A 03CA1109
	.long 0xd7006a08                                           // 00000029F904: D7006A08
	v_cndmask_b32_e32 v0, v2, v8, vcc_lo                       // 00000029F908: 02001102
	s_delay_alu instid0(VALU_DEP_1)                            // 00000029F90C: BF870001
	v_add_co_ci_u32_e64 v9, null, s9, v3, vcc_lo               // 00000029F910: D5207C09 01AA0609
	global_store_b32 v[8:9], v10, off                          // 00000029F918: DC6A0000 007C0A08
	s_mov_b32 s7, 0                                            // 00000029F920: BE870080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000029F924: BF870009
	s_and_b32 vcc_lo, exec_lo, s7                              // 00000029F928: 8B6A077E
	s_cbranch_vccz 47                                          // 00000029F92C: BFA3002F <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x16ec>
	v_bfe_u32 v8, v7, 16, 1                                    // 00000029F930: D6100008 02052107
	s_lshl_b64 s[8:9], s[10:11], 2                             // 00000029F938: 8488820A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029F93C: BF870091
	v_add3_u32 v8, v7, v8, 0x7fff                              // 00000029F940: D6550008 03FE1107 00007FFF
	v_and_b32_e32 v8, 0xffff0000, v8                           // 00000029F94C: 361010FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029F954: BF870091
	v_mul_f32_e32 v8, s2, v8                                   // 00000029F958: 10101002
	v_mul_f32_e32 v8, 0xbfb8aa3b, v8                           // 00000029F95C: 101010FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000029F964: BF870291
	v_exp_f32_e32 v8, v8                                       // 00000029F968: 7E104B08
	v_add_f32_e32 v8, 1.0, v8                                  // 00000029F96C: 061010F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000029F970: BF870121
	v_div_scale_f32 v9, null, v8, v8, 1.0                      // 00000029F974: D6FC7C09 03CA1108
	v_div_scale_f32 v14, vcc_lo, 1.0, v8, 1.0                  // 00000029F97C: D6FC6A0E 03CA10F2
	v_rcp_f32_e32 v10, v9                                      // 00000029F984: 7E145509
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029F988: BF870095
	v_fma_f32 v13, -v9, v10, 1.0                               // 00000029F98C: D613000D 23CA1509
	v_fmac_f32_e32 v10, v13, v10                               // 00000029F994: 5614150D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029F998: BF870091
	v_mul_f32_e32 v13, v14, v10                                // 00000029F99C: 101A150E
	v_fma_f32 v15, -v9, v13, v14                               // 00000029F9A0: D613000F 243A1B09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029F9A8: BF870091
	v_fmac_f32_e32 v13, v15, v10                               // 00000029F9AC: 561A150F
	v_fma_f32 v9, -v9, v13, v14                                // 00000029F9B0: D6130009 243A1B09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029F9B8: BF870091
	v_div_fmas_f32 v9, v9, v10, v13                            // 00000029F9BC: D6370009 04361509
	v_div_fixup_f32 v8, v9, v8, 1.0                            // 00000029F9C4: D6270008 03CA1109
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000029F9CC: BF8700A1
	v_add_f32_e32 v10, v8, v8                                  // 00000029F9D0: 06141108
	.long 0xd7006a08                                           // 00000029F9D4: D7006A08
	v_cndmask_b32_e32 v0, v2, v8, vcc_lo                       // 00000029F9D8: 02001102
	v_add_co_ci_u32_e64 v9, null, s9, v3, vcc_lo               // 00000029F9DC: D5207C09 01AA0609
	global_store_b32 v[8:9], v10, off                          // 00000029F9E4: DC6A0000 007C0A08
	s_mov_b32 s7, 0                                            // 00000029F9EC: BE870080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000029F9F0: BF870009
	s_and_b32 vcc_lo, exec_lo, s7                              // 00000029F9F4: 8B6A077E
	s_cbranch_vccz 60                                          // 00000029F9F8: BFA3003C <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x17ec>
	s_cmp_gt_i32 s3, 1                                         // 00000029F9FC: BF028103
	s_mov_b32 s1, -1                                           // 00000029FA00: BE8100C1
	s_cbranch_scc0 51                                          // 00000029FA04: BFA10033 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x17d4>
	v_bfe_u32 v8, v7, 16, 1                                    // 00000029FA08: D6100008 02052107
	s_lshl_b64 s[8:9], s[10:11], 1                             // 00000029FA10: 8488810A
	s_mov_b32 s1, 0                                            // 00000029FA14: BE810080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029FA18: BF870091
	v_add3_u32 v8, v7, v8, 0x7fff                              // 00000029FA1C: D6550008 03FE1107 00007FFF
	v_and_b32_e32 v8, 0xffff0000, v8                           // 00000029FA28: 361010FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029FA30: BF870091
	v_mul_f32_e32 v8, 0xbfb8aa3b, v8                           // 00000029FA34: 101010FF BFB8AA3B
	v_exp_f32_e32 v8, v8                                       // 00000029FA3C: 7E104B08
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029FA40: BF870095
	v_add_f32_e32 v8, 1.0, v8                                  // 00000029FA44: 061010F2
	v_div_scale_f32 v9, null, v8, v8, 1.0                      // 00000029FA48: D6FC7C09 03CA1108
	v_div_scale_f32 v14, vcc_lo, 1.0, v8, 1.0                  // 00000029FA50: D6FC6A0E 03CA10F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000029FA58: BF870292
	v_rcp_f32_e32 v10, v9                                      // 00000029FA5C: 7E145509
	v_fma_f32 v13, -v9, v10, 1.0                               // 00000029FA60: D613000D 23CA1509
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029FA68: BF870091
	v_fmac_f32_e32 v10, v13, v10                               // 00000029FA6C: 5614150D
	v_mul_f32_e32 v13, v14, v10                                // 00000029FA70: 101A150E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029FA74: BF870091
	v_fma_f32 v15, -v9, v13, v14                               // 00000029FA78: D613000F 243A1B09
	v_fmac_f32_e32 v13, v15, v10                               // 00000029FA80: 561A150F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029FA84: BF870091
	v_fma_f32 v9, -v9, v13, v14                                // 00000029FA88: D6130009 243A1B09
	v_div_fmas_f32 v9, v9, v10, v13                            // 00000029FA90: D6370009 04361509
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029FA98: BF870091
	v_div_fixup_f32 v8, v9, v8, 1.0                            // 00000029FA9C: D6270008 03CA1109
	v_bfe_u32 v9, v8, 16, 1                                    // 00000029FAA4: D6100009 02052108
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000029FAAC: BF8700A1
	v_add3_u32 v10, v8, v9, 0x7fff                             // 00000029FAB0: D655000A 03FE1308 00007FFF
	.long 0xd7006a08                                           // 00000029FABC: D7006A08
	v_cndmask_b32_e32 v0, v0, v8, vcc_lo                       // 00000029FAC0: 02001100
	v_add_co_ci_u32_e64 v9, null, s9, v1, vcc_lo               // 00000029FAC4: D5207C09 01AA0209
	global_store_d16_hi_b16 v[8:9], v10, off                   // 00000029FACC: DC960000 007C0A08
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 00000029FAD4: 916A017E
	s_mov_b32 s1, 0                                            // 00000029FAD8: BE810080
	s_cbranch_vccnz 3                                          // 00000029FADC: BFA40003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x17ec>
	s_cmp_lg_u32 s3, 1                                         // 00000029FAE0: BF078103
	s_mov_b32 s1, -1                                           // 00000029FAE4: BE8100C1
	s_cselect_b32 s6, -1, 0                                    // 00000029FAE8: 980680C1
	v_bfe_u32 v8, v7, 16, 1                                    // 00000029FAEC: D6100008 02052107
	s_and_b32 vcc_lo, exec_lo, s6                              // 00000029FAF4: 8B6A067E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000029FAF8: BF870001
	v_add3_u32 v7, v7, v8, 0x7fff                              // 00000029FAFC: D6550007 03FE1107 00007FFF
	s_cbranch_vccz 9                                           // 00000029FB08: BFA30009 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1830>
	s_lshl_b64 s[6:7], s[10:11], 1                             // 00000029FB0C: 8486810A
	s_mov_b32 s1, 0                                            // 00000029FB10: BE810080
	.long 0xd7006a08                                           // 00000029FB14: D7006A08
	v_cndmask_b32_e32 v0, v0, v6, vcc_lo                       // 00000029FB18: 02000D00
	s_delay_alu instid0(VALU_DEP_1)                            // 00000029FB1C: BF870001
	v_add_co_ci_u32_e64 v9, null, s7, v1, vcc_lo               // 00000029FB20: D5207C09 01AA0207
	global_store_d16_hi_b16 v[8:9], v7, off                    // 00000029FB28: DC960000 007C0708
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 00000029FB30: 916A017E
	s_cbranch_vccnz 46                                         // 00000029FB34: BFA4002E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x18f0>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000029FB38: BF8700A1
	v_and_b32_e32 v7, 0xffff0000, v7                           // 00000029FB3C: 360E0EFF FFFF0000
	s_lshl_b64 s[6:7], s[10:11], 1                             // 00000029FB44: 8486810A
	v_mul_f32_e32 v7, s2, v7                                   // 00000029FB48: 100E0E02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029FB4C: BF870091
	v_mul_f32_e32 v8, 0xbfb8aa3b, v7                           // 00000029FB50: 10100EFF BFB8AA3B
	v_exp_f32_e32 v8, v8                                       // 00000029FB58: 7E104B08
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029FB5C: BF870095
	v_add_f32_e32 v8, 1.0, v8                                  // 00000029FB60: 061010F2
	v_div_scale_f32 v9, null, v8, v8, v7                       // 00000029FB64: D6FC7C09 041E1108
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000029FB6C: BF870291
	v_rcp_f32_e32 v10, v9                                      // 00000029FB70: 7E145509
	v_fma_f32 v13, -v9, v10, 1.0                               // 00000029FB74: D613000D 23CA1509
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000029FB7C: BF8700A1
	v_fmac_f32_e32 v10, v13, v10                               // 00000029FB80: 5614150D
	v_div_scale_f32 v14, vcc_lo, v7, v8, v7                    // 00000029FB84: D6FC6A0E 041E1107
	v_mul_f32_e32 v13, v14, v10                                // 00000029FB8C: 101A150E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029FB90: BF870091
	v_fma_f32 v15, -v9, v13, v14                               // 00000029FB94: D613000F 243A1B09
	v_fmac_f32_e32 v13, v15, v10                               // 00000029FB9C: 561A150F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029FBA0: BF870091
	v_fma_f32 v9, -v9, v13, v14                                // 00000029FBA4: D6130009 243A1B09
	v_div_fmas_f32 v9, v9, v10, v13                            // 00000029FBAC: D6370009 04361509
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029FBB4: BF870091
	v_div_fixup_f32 v7, v9, v8, v7                             // 00000029FBB8: D6270007 041E1109
	v_bfe_u32 v8, v7, 16, 1                                    // 00000029FBC0: D6100008 02052107
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000029FBC8: BF8700A1
	v_add3_u32 v9, v7, v8, 0x7fff                              // 00000029FBCC: D6550009 03FE1107 00007FFF
	.long 0xd7006a07                                           // 00000029FBD8: D7006A07
	v_cndmask_b32_e32 v0, v0, v6, vcc_lo                       // 00000029FBDC: 02000D00
	v_add_co_ci_u32_e64 v8, null, s7, v1, vcc_lo               // 00000029FBE0: D5207C08 01AA0207
	global_store_d16_hi_b16 v[7:8], v9, off                    // 00000029FBE8: DC960000 007C0907
	s_mov_b32 s7, -1                                           // 00000029FBF0: BE8700C1
	s_mov_b32 s1, 0                                            // 00000029FBF4: BE810080
	s_cmp_lt_i32 s3, 3                                         // 00000029FBF8: BF048303
	s_mov_b32 s6, 0                                            // 00000029FBFC: BE860080
	s_cbranch_scc1 139                                         // 00000029FC00: BFA2008B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1b30>
	s_cmp_gt_i32 s3, 3                                         // 00000029FC04: BF028303
	s_cbranch_scc0 46                                          // 00000029FC08: BFA1002E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x19c4>
	s_cmp_gt_i32 s3, 4                                         // 00000029FC0C: BF028403
	s_cbranch_scc0 46                                          // 00000029FC10: BFA1002E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x19cc>
	s_cmp_eq_u32 s3, 5                                         // 00000029FC14: BF068503
	s_mov_b32 s6, -1                                           // 00000029FC18: BE8600C1
	s_cbranch_scc0 39                                          // 00000029FC1C: BFA10027 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x19bc>
	s_load_b64 s[6:7], s[16:17], 0x10                          // 00000029FC20: F4040188 F8000010
	v_dual_mov_b32 v7, s4 :: v_dual_mov_b32 v8, s5             // 00000029FC28: CA100004 07080005
	s_and_b32 s5, s11, 0x7fffffff                              // 00000029FC30: 8B05FF0B 7FFFFFFF
	s_and_b32 s4, s10, -2                                      // 00000029FC38: 8B04C20A
	.long 0xd73c0004                                           // 00000029FC3C: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 00000029FC40: 02020881
	s_lshl_b64 s[4:5], s[4:5], 1                               // 00000029FC44: 84848104
	v_bfe_u32 v9, v6, 16, 1                                    // 00000029FC48: D6100009 02052106
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 00000029FC50: BF870151
	v_add3_u32 v9, v6, v9, 0x7fff                              // 00000029FC54: D6550009 03FE1306 00007FFF
	s_waitcnt lgkmcnt(0)                                       // 00000029FC60: BF89FC07
	v_cndmask_b32_e64 v7, s6, v7, s0                           // 00000029FC64: D5010007 00020E06
	v_cndmask_b32_e64 v8, s7, v8, s0                           // 00000029FC6C: D5010008 00021007
	s_mov_b32 s6, 0                                            // 00000029FC74: BE860080
	.long 0xd7006a07                                           // 00000029FC78: D7006A07
	v_cndmask_b32_e32 v0, v7, v4, vcc_lo                       // 00000029FC7C: 02000907
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000029FC80: BF870111
	v_add_co_ci_u32_e64 v8, null, s5, v8, vcc_lo               // 00000029FC84: D5207C08 01AA1005
	.long 0xd7006a07                                           // 00000029FC8C: D7006A07
	v_cndmask_b32_e32 v1, v7, v12, vcc_lo                      // 00000029FC90: 02021907
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000029FC94: BF870111
	v_add_co_ci_u32_e64 v8, null, v8, v11, vcc_lo              // 00000029FC98: D5207C08 01AA1708
	.long 0xd7006a04                                           // 00000029FCA0: D7006A04
	v_cndmask_b32_e32 v1, v7, v4, vcc_lo                       // 00000029FCA4: 02020907
	s_delay_alu instid0(VALU_DEP_1)                            // 00000029FCA8: BF870001
	v_add_co_ci_u32_e64 v5, null, v8, v5, vcc_lo               // 00000029FCAC: D5207C05 01AA0B08
	global_store_d16_hi_b16 v[4:5], v9, off                    // 00000029FCB4: DC960000 007C0904
	s_mov_b32 s0, 0                                            // 00000029FCBC: BE800080
	s_branch 3                                                 // 00000029FCC0: BFA00003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x19d0>
	s_cbranch_execnz 42                                        // 00000029FCC4: BFA6002A <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1a70>
	s_branch 88                                                // 00000029FCC8: BFA00058 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1b2c>
	s_mov_b32 s0, -1                                           // 00000029FCCC: BE8000C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000029FCD0: BF870009
	s_and_b32 vcc_lo, exec_lo, s0                              // 00000029FCD4: 8B6A007E
	s_cbranch_vccz 36                                          // 00000029FCD8: BFA30024 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1a6c>
	v_mul_f32_e32 v4, 0xbfb8aa3b, v6                           // 00000029FCDC: 10080CFF BFB8AA3B
	s_lshl_b64 s[4:5], s[10:11], 3                             // 00000029FCE4: 8484830A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000029FCE8: BF870291
	v_exp_f32_e32 v4, v4                                       // 00000029FCEC: 7E084B04
	v_add_f32_e32 v4, 1.0, v4                                  // 00000029FCF0: 060808F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000029FCF4: BF870121
	v_div_scale_f32 v5, null, v4, v4, 1.0                      // 00000029FCF8: D6FC7C05 03CA0904
	v_div_scale_f32 v9, vcc_lo, 1.0, v4, 1.0                   // 00000029FD00: D6FC6A09 03CA08F2
	v_rcp_f32_e32 v7, v5                                       // 00000029FD08: 7E0E5505
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029FD0C: BF870095
	v_fma_f32 v8, -v5, v7, 1.0                                 // 00000029FD10: D6130008 23CA0F05
	v_fmac_f32_e32 v7, v8, v7                                  // 00000029FD18: 560E0F08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029FD1C: BF870091
	v_mul_f32_e32 v8, v9, v7                                   // 00000029FD20: 10100F09
	v_fma_f32 v10, -v5, v8, v9                                 // 00000029FD24: D613000A 24261105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029FD2C: BF870091
	v_fmac_f32_e32 v8, v10, v7                                 // 00000029FD30: 56100F0A
	v_fma_f32 v5, -v5, v8, v9                                  // 00000029FD34: D6130005 24261105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029FD3C: BF870091
	v_div_fmas_f32 v5, v5, v7, v8                              // 00000029FD40: D6370005 04220F05
	v_div_fixup_f32 v7, v5, v4, 1.0                            // 00000029FD48: D6270007 03CA0905
	.long 0xd7006a04                                           // 00000029FD50: D7006A04
	v_cndmask_b32_e32 v0, v2, v4, vcc_lo                       // 00000029FD54: 02000902
	s_delay_alu instid0(VALU_DEP_1)                            // 00000029FD58: BF870001
	v_add_co_ci_u32_e64 v5, null, s5, v3, vcc_lo               // 00000029FD5C: D5207C05 01AA0605
	global_store_b32 v[4:5], v7, off                           // 00000029FD64: DC6A0000 007C0704
	s_branch 47                                                // 00000029FD6C: BFA0002F <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1b2c>
	v_bfe_u32 v4, v6, 16, 1                                    // 00000029FD70: D6100004 02052106
	s_lshl_b64 s[4:5], s[10:11], 3                             // 00000029FD78: 8484830A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029FD7C: BF870091
	v_add3_u32 v4, v6, v4, 0x7fff                              // 00000029FD80: D6550004 03FE0906 00007FFF
	v_and_b32_e32 v4, 0xffff0000, v4                           // 00000029FD8C: 360808FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029FD94: BF870091
	v_mul_f32_e32 v4, s2, v4                                   // 00000029FD98: 10080802
	v_mul_f32_e32 v4, 0xbfb8aa3b, v4                           // 00000029FD9C: 100808FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000029FDA4: BF870291
	v_exp_f32_e32 v4, v4                                       // 00000029FDA8: 7E084B04
	v_add_f32_e32 v4, 1.0, v4                                  // 00000029FDAC: 060808F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000029FDB0: BF870121
	v_div_scale_f32 v5, null, v4, v4, 1.0                      // 00000029FDB4: D6FC7C05 03CA0904
	v_div_scale_f32 v9, vcc_lo, 1.0, v4, 1.0                   // 00000029FDBC: D6FC6A09 03CA08F2
	v_rcp_f32_e32 v7, v5                                       // 00000029FDC4: 7E0E5505
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029FDC8: BF870095
	v_fma_f32 v8, -v5, v7, 1.0                                 // 00000029FDCC: D6130008 23CA0F05
	v_fmac_f32_e32 v7, v8, v7                                  // 00000029FDD4: 560E0F08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029FDD8: BF870091
	v_mul_f32_e32 v8, v9, v7                                   // 00000029FDDC: 10100F09
	v_fma_f32 v10, -v5, v8, v9                                 // 00000029FDE0: D613000A 24261105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029FDE8: BF870091
	v_fmac_f32_e32 v8, v10, v7                                 // 00000029FDEC: 56100F0A
	v_fma_f32 v5, -v5, v8, v9                                  // 00000029FDF0: D6130005 24261105
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000029FDF8: BF8700A1
	v_div_fmas_f32 v5, v5, v7, v8                              // 00000029FDFC: D6370005 04220F05
	.long 0xd7006a02                                           // 00000029FE04: D7006A02
	v_cndmask_b32_e32 v0, v2, v4, vcc_lo                       // 00000029FE08: 02000902
	v_add_co_ci_u32_e64 v3, null, s5, v3, vcc_lo               // 00000029FE0C: D5207C03 01AA0605
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029FE14: BF870093
	v_div_fixup_f32 v4, v5, v4, 1.0                            // 00000029FE18: D6270004 03CA0905
	v_add_f32_e32 v4, v4, v4                                   // 00000029FE20: 06080904
	global_store_b32 v[2:3], v4, off                           // 00000029FE24: DC6A0000 007C0402
	s_mov_b32 s7, 0                                            // 00000029FE2C: BE870080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000029FE30: BF870009
	s_and_b32 vcc_lo, exec_lo, s7                              // 00000029FE34: 8B6A077E
	s_cbranch_vccz 60                                          // 00000029FE38: BFA3003C <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1c2c>
	s_cmp_gt_i32 s3, 1                                         // 00000029FE3C: BF028103
	s_mov_b32 s0, -1                                           // 00000029FE40: BE8000C1
	s_cbranch_scc0 51                                          // 00000029FE44: BFA10033 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1c14>
	v_bfe_u32 v2, v6, 16, 1                                    // 00000029FE48: D6100002 02052106
	s_lshl_b64 s[0:1], s[10:11], 2                             // 00000029FE50: 8480820A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029FE54: BF870091
	v_add3_u32 v2, v6, v2, 0x7fff                              // 00000029FE58: D6550002 03FE0506 00007FFF
	v_and_b32_e32 v2, 0xffff0000, v2                           // 00000029FE64: 360404FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029FE6C: BF870091
	v_mul_f32_e32 v2, 0xbfb8aa3b, v2                           // 00000029FE70: 100404FF BFB8AA3B
	v_exp_f32_e32 v2, v2                                       // 00000029FE78: 7E044B02
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029FE7C: BF870095
	v_add_f32_e32 v2, 1.0, v2                                  // 00000029FE80: 060404F2
	v_div_scale_f32 v3, null, v2, v2, 1.0                      // 00000029FE84: D6FC7C03 03CA0502
	v_div_scale_f32 v7, vcc_lo, 1.0, v2, 1.0                   // 00000029FE8C: D6FC6A07 03CA04F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000029FE94: BF870292
	v_rcp_f32_e32 v4, v3                                       // 00000029FE98: 7E085503
	v_fma_f32 v5, -v3, v4, 1.0                                 // 00000029FE9C: D6130005 23CA0903
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029FEA4: BF870091
	v_fmac_f32_e32 v4, v5, v4                                  // 00000029FEA8: 56080905
	v_mul_f32_e32 v5, v7, v4                                   // 00000029FEAC: 100A0907
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029FEB0: BF870091
	v_fma_f32 v8, -v3, v5, v7                                  // 00000029FEB4: D6130008 241E0B03
	v_fmac_f32_e32 v5, v8, v4                                  // 00000029FEBC: 560A0908
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029FEC0: BF870091
	v_fma_f32 v3, -v3, v5, v7                                  // 00000029FEC4: D6130003 241E0B03
	v_div_fmas_f32 v3, v3, v4, v5                              // 00000029FECC: D6370003 04160903
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029FED4: BF870091
	v_div_fixup_f32 v2, v3, v2, 1.0                            // 00000029FED8: D6270002 03CA0503
	v_bfe_u32 v3, v2, 16, 1                                    // 00000029FEE0: D6100003 02052102
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000029FEE8: BF8700A1
	v_add3_u32 v4, v2, v3, 0x7fff                              // 00000029FEEC: D6550004 03FE0702 00007FFF
	.long 0xd7006a02                                           // 00000029FEF8: D7006A02
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 00000029FEFC: 02000100
	v_add_co_ci_u32_e64 v3, null, s1, v1, vcc_lo               // 00000029FF00: D5207C03 01AA0201
	s_mov_b32 s0, 0                                            // 00000029FF08: BE800080
	global_store_d16_hi_b16 v[2:3], v4, off                    // 00000029FF0C: DC960000 007C0402
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 00000029FF14: 916A007E
	s_mov_b32 s1, 0                                            // 00000029FF18: BE810080
	s_cbranch_vccnz 3                                          // 00000029FF1C: BFA40003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1c2c>
	s_cmp_lg_u32 s3, 1                                         // 00000029FF20: BF078103
	s_mov_b32 s1, -1                                           // 00000029FF24: BE8100C1
	s_cselect_b32 s6, -1, 0                                    // 00000029FF28: 980680C1
	v_bfe_u32 v2, v6, 16, 1                                    // 00000029FF2C: D6100002 02052106
	s_and_b32 vcc_lo, exec_lo, s6                              // 00000029FF34: 8B6A067E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000029FF38: BF870001
	v_add3_u32 v2, v6, v2, 0x7fff                              // 00000029FF3C: D6550002 03FE0506 00007FFF
	s_cbranch_vccz 9                                           // 00000029FF48: BFA30009 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1c70>
	s_lshl_b64 s[0:1], s[10:11], 2                             // 00000029FF4C: 8480820A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029FF50: BF870099
	.long 0xd7006a03                                           // 00000029FF54: D7006A03
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 00000029FF58: 02000100
	v_add_co_ci_u32_e64 v4, null, s1, v1, vcc_lo               // 00000029FF5C: D5207C04 01AA0201
	s_mov_b32 s1, 0                                            // 00000029FF64: BE810080
	global_store_d16_hi_b16 v[3:4], v2, off                    // 00000029FF68: DC960000 007C0203
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 00000029FF70: 916A017E
	s_cbranch_vccnz 46                                         // 00000029FF74: BFA4002E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi3ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1d30>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000029FF78: BF8700A1
	v_and_b32_e32 v2, 0xffff0000, v2                           // 00000029FF7C: 360404FF FFFF0000
	s_lshl_b64 s[0:1], s[10:11], 2                             // 00000029FF84: 8480820A
	v_mul_f32_e32 v2, s2, v2                                   // 00000029FF88: 10040402
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029FF8C: BF870091
	v_mul_f32_e32 v3, 0xbfb8aa3b, v2                           // 00000029FF90: 100604FF BFB8AA3B
	v_exp_f32_e32 v3, v3                                       // 00000029FF98: 7E064B03
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029FF9C: BF870095
	v_add_f32_e32 v3, 1.0, v3                                  // 00000029FFA0: 060606F2
	v_div_scale_f32 v4, null, v3, v3, v2                       // 00000029FFA4: D6FC7C04 040A0703
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000029FFAC: BF870291
	v_rcp_f32_e32 v5, v4                                       // 00000029FFB0: 7E0A5504
	v_fma_f32 v6, -v4, v5, 1.0                                 // 00000029FFB4: D6130006 23CA0B04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000029FFBC: BF8700A1
	v_fmac_f32_e32 v5, v6, v5                                  // 00000029FFC0: 560A0B06
	v_div_scale_f32 v7, vcc_lo, v2, v3, v2                     // 00000029FFC4: D6FC6A07 040A0702
	v_mul_f32_e32 v6, v7, v5                                   // 00000029FFCC: 100C0B07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029FFD0: BF870091
	v_fma_f32 v8, -v4, v6, v7                                  // 00000029FFD4: D6130008 241E0D04
	v_fmac_f32_e32 v6, v8, v5                                  // 00000029FFDC: 560C0B08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029FFE0: BF870091
	v_fma_f32 v4, -v4, v6, v7                                  // 00000029FFE4: D6130004 241E0D04
	v_div_fmas_f32 v4, v4, v5, v6                              // 00000029FFEC: D6370004 041A0B04
	.long 0xd7006a00                                           // 00000029FFF4: D7006A00
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 00000029FFF8: 02000100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000029FFFC: BF870191
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 0000002A0000: D5207C01 01AA0201
	v_div_fixup_f32 v2, v4, v3, v2                             // 0000002A0008: D6270002 040A0704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002A0010: BF870091
	v_bfe_u32 v3, v2, 16, 1                                    // 0000002A0014: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000002A001C: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off                    // 0000002A0028: DC960000 007C0200
	s_endpgm                                                   // 0000002A0030: BFB00000
		...

