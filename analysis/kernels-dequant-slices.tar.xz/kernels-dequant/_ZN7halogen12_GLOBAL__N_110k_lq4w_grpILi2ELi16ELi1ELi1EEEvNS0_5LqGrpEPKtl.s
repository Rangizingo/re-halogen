0000000000295b00 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl>:
; _ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl():
	s_clause 0x3                                               // 000000295B00: BF850003
	s_load_b32 s3, s[0:1], 0x120                               // 000000295B04: F40000C0 F8000120
	s_load_b32 s4, s[0:1], 0x88                                // 000000295B0C: F4000100 F8000088
	s_load_b32 s5, s[0:1], 0xd0                                // 000000295B14: F4000140 F80000D0
	s_load_b32 s6, s[0:1], 0x118                               // 000000295B1C: F4000180 F8000118
	v_and_b32_e32 v24, 15, v0                                  // 000000295B24: 3630008F
	v_lshlrev_b32_e32 v23, 2, v0                               // 000000295B28: 302E0082
	s_delay_alu instid0(VALU_DEP_2)                            // 000000295B2C: BF870002
	v_lshlrev_b32_e32 v2, 2, v24                               // 000000295B30: 30043082
	s_waitcnt lgkmcnt(0)                                       // 000000295B34: BF89FC07
	s_cmp_gt_i32 s3, 1                                         // 000000295B38: BF028103
	s_cselect_b32 s7, -1, 0                                    // 000000295B3C: 980780C1
	s_cmp_ge_i32 s2, s4                                        // 000000295B40: BF030402
	s_cselect_b32 s4, -1, 0                                    // 000000295B44: 980480C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000295B48: BF870009
	s_and_b32 s4, s7, s4                                       // 000000295B4C: 8B040407
	s_cmp_gt_i32 s3, 2                                         // 000000295B50: BF028203
	v_cndmask_b32_e64 v1, 0, 1, s4                             // 000000295B54: D5010001 00110280
	s_cselect_b32 s7, -1, 0                                    // 000000295B5C: 980780C1
	s_cmp_ge_i32 s2, s5                                        // 000000295B60: BF030502
	s_cselect_b32 s5, -1, 0                                    // 000000295B64: 980580C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000295B68: BF870009
	s_and_b32 s4, s7, s5                                       // 000000295B6C: 8B040507
	s_cmp_gt_i32 s3, 3                                         // 000000295B70: BF028303
	v_readfirstlane_b32 s5, v1                                 // 000000295B74: 7E0A0501
	s_cselect_b32 s3, -1, 0                                    // 000000295B78: 980380C1
	s_cmp_ge_i32 s2, s6                                        // 000000295B7C: BF030602
	v_lshrrev_b32_e32 v1, 4, v0                                // 000000295B80: 32020084
	s_cselect_b32 s6, -1, 0                                    // 000000295B84: 980680C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000295B88: BF870009
	s_and_b32 s3, s3, s6                                       // 000000295B8C: 8B030603
	s_and_b32 s4, s4, exec_lo                                  // 000000295B90: 8B047E04
	s_cselect_b32 s4, 2, s5                                    // 000000295B94: 98040582
	s_and_b32 s3, s3, exec_lo                                  // 000000295B98: 8B037E03
	s_cselect_b32 s3, 3, s4                                    // 000000295B9C: 98030483
	v_lshlrev_b32_e32 v3, 2, v1                                // 000000295BA0: 30060282
	s_mulk_i32 s3, 0x48                                        // 000000295BA4: B8030048
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000295BA8: BF870009
	s_add_u32 s16, s0, s3                                      // 000000295BAC: 80100300
	s_addc_u32 s17, s1, 0                                      // 000000295BB0: 82118001
	s_clause 0x1                                               // 000000295BB4: BF850001
	s_load_b256 s[4:11], s[16:17], 0x18                        // 000000295BB8: F40C0108 F8000018
	s_load_b64 s[18:19], s[16:17], null                        // 000000295BC0: F4040488 F8000000
	s_waitcnt lgkmcnt(0)                                       // 000000295BC8: BF89FC07
	.long 0xd4540003                                           // 000000295BCC: D4540003
	v_cndmask_b32_e32 v0, s10, v136, vcc_lo                    // 000000295BD0: 0201100A
	s_and_b32 s12, s3, exec_lo                                 // 000000295BD4: 8B0C7E03
	s_load_b128 s[12:15], s[0:1], 0x128                        // 000000295BD8: F4080300 F8000128
	s_clause 0x1                                               // 000000295BE0: BF850001
	global_load_b32 v2, v2, s[18:19]                           // 000000295BE4: DC520000 02120002
	global_load_b32 v3, v3, s[18:19]                           // 000000295BEC: DC520000 03120003
	s_cselect_b32 s22, 1, 16                                   // 000000295BF4: 98169081
	s_cselect_b32 s23, 0, 4                                    // 000000295BF8: 98178480
	s_add_i32 s24, s22, -1                                     // 000000295BFC: 8118C116
	v_lshrrev_b32_e32 v25, s23, v1                             // 000000295C00: 32320217
	v_and_b32_e32 v26, s24, v1                                 // 000000295C04: 36340218
	s_waitcnt vmcnt(1)                                         // 000000295C08: BF8907F7
	v_bfe_u32 v4, v2, 16, 1                                    // 000000295C0C: D6100004 02052102
	s_waitcnt vmcnt(0)                                         // 000000295C14: BF8903F7
	v_bfe_u32 v5, v3, 16, 1                                    // 000000295C18: D6100005 02052103
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000295C20: BF8701A2
	v_add3_u32 v2, v2, v4, 0x7fff                              // 000000295C24: D6550002 03FE0902 00007FFF
	.long 0x7f083880                                           // 000000295C30: 7F083880
	v_add3_u32 v3, v3, v5, 0x7fff                              // 000000295C34: D6550003 03FE0B03 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000295C40: BF870093
	.long 0x7e083982                                           // 000000295C44: 7E083982
	v_and_or_b32 v2, 0xffff0000, v3, v4                        // 000000295C48: D6570002 041206FF FFFF0000
	ds_store_b32 v23, v2                                       // 000000295C54: D8340000 00000217
	v_cvt_f32_ubyte0_e32 v2, s22                               // 000000295C5C: 7E042216
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000295C60: BF870291
	v_rcp_iflag_f32_e32 v2, v2                                 // 000000295C64: 7E045702
	v_readfirstlane_b32 s21, v2                                // 000000295C68: 7E2A0502
	s_waitcnt lgkmcnt(0)                                       // 000000295C6C: BF89FC07
	s_barrier                                                  // 000000295C70: BFBD0000
	buffer_gl0_inv                                             // 000000295C74: E0AC0000 00000000
	s_load_b32 s20, s[16:17], 0x40                             // 000000295C7C: F4000508 F8000040
	s_waitcnt lgkmcnt(0)                                       // 000000295C84: BF89FC07
	s_sub_i32 s0, s2, s20                                      // 000000295C88: 81801402
	s_mul_f32 s20, s21, 0x4f7ffffe                             // 000000295C8C: A214FF15 4F7FFFFE
	s_ashr_i32 s1, s0, 31                                      // 000000295C94: 86019F00
	s_and_b32 s3, s3, exec_lo                                  // 000000295C98: 8B037E03
	s_cselect_b32 s3, 4, 0                                     // 000000295C9C: 98038084
	s_cvt_u32_f32 s25, s20                                     // 000000295CA0: BE996714
	s_lshl_b64 s[0:1], s[0:1], s3                              // 000000295CA4: 84800300
	s_add_u32 s6, s18, s6                                      // 000000295CA8: 80060612
	s_addc_u32 s7, s19, s7                                     // 000000295CAC: 82070713
	s_ashr_i32 s3, s15, 31                                     // 000000295CB0: 86039F0F
	.long 0xd7000011                                           // 000000295CB4: D7000011
	v_cndmask_b32_e32 v1, s0, v25, vcc_lo                      // 000000295CB8: 02023200
	s_lshr_b32 s3, s3, 27                                      // 000000295CBC: 85039B03
	v_add_co_ci_u32_e64 v18, null, s1, 0, s0                   // 000000295CC0: D5207C12 00010001
	s_add_u32 s20, s14, s3                                     // 000000295CC8: 8014030E
	s_addc_u32 s21, s15, 0                                     // 000000295CCC: 8215800F
	s_sub_i32 s3, 0, s22                                       // 000000295CD0: 81831680
	s_lshr_b64 s[20:21], s[20:21], 5                           // 000000295CD4: 85948514
	s_mul_i32 s3, s3, s25                                      // 000000295CD8: 96031903
	s_add_i32 s21, s24, s20                                    // 000000295CDC: 81151418
	s_mul_hi_u32 s3, s25, s3                                   // 000000295CE0: 96830319
	s_abs_i32 s26, s21                                         // 000000295CE4: BE9A1515
	s_add_i32 s25, s25, s3                                     // 000000295CE8: 81190319
	s_ashr_i32 s21, s21, 31                                    // 000000295CEC: 86159F15
	s_mul_hi_u32 s3, s26, s25                                  // 000000295CF0: 9683191A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000295CF4: BF8704B9
	s_mul_i32 s23, s3, s22                                     // 000000295CF8: 96171603
	s_add_i32 s25, s3, 1                                       // 000000295CFC: 81198103
	s_sub_i32 s23, s26, s23                                    // 000000295D00: 8197171A
	s_sub_i32 s26, s23, s22                                    // 000000295D04: 819A1617
	s_cmp_ge_u32 s23, s22                                      // 000000295D08: BF091617
	s_cselect_b32 s0, s25, s3                                  // 000000295D0C: 98000319
	s_cselect_b32 s1, s26, s23                                 // 000000295D10: 9801171A
	s_add_i32 s3, s0, 1                                        // 000000295D14: 81038100
	s_cmp_ge_u32 s1, s22                                       // 000000295D18: BF091601
	s_cselect_b32 s1, s3, s0                                   // 000000295D1C: 98010003
	.long 0xd4540000                                           // 000000295D20: D4540000
	v_cndmask_b32_e32 v1, s10, v17, vcc_lo                     // 000000295D24: 0202220A
	s_xor_b32 s1, s1, s21                                      // 000000295D28: 8D011501
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000295D2C: BF870499
	s_sub_i32 s3, s1, s21                                      // 000000295D30: 81831501
	.long 0xd72c000d                                           // 000000295D34: D72C000D
	v_cndmask_b32_e32 v1, s3, v26, vcc_lo                      // 000000295D38: 02023403
	v_cndmask_b32_e64 v9, 0, v18, s0                           // 000000295D3C: D5010009 00022480
	v_cndmask_b32_e64 v10, 0, v17, s0                          // 000000295D44: D501000A 00022280
	s_cmpk_lt_i32 s3, 0x81                                     // 000000295D4C: B3830081
	s_cselect_b32 s1, -1, 0                                    // 000000295D50: 980180C1
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000295D54: BF870112
	.long 0xd72c0002                                           // 000000295D58: D72C0002
	v_cndmask_b32_e32 v0, v9, v8, vcc_lo                       // 000000295D5C: 02001109
	.long 0xd72c0003                                           // 000000295D60: D72C0003
	v_cndmask_b32_e32 v0, v10, v9, vcc_lo                      // 000000295D64: 0200130A
	v_add_nc_u32_e32 v1, s3, v13                               // 000000295D68: 4A021A03
	v_mad_u64_u32 v[19:20], null, v10, s8, s[6:7]              // 000000295D6C: D6FE7C13 0018110A
	.long 0xd4510006                                           // 000000295D74: D4510006
	v_cndmask_b32_e32 v0, s10, v137, vcc_lo                    // 000000295D78: 0201120A
	s_cmpk_gt_i32 s3, 0x80                                     // 000000295D7C: B2830080
	v_min_i32_e32 v27, s20, v1                                 // 000000295D80: 22360214
	v_dual_mov_b32 v1, 0 :: v_dual_add_nc_u32 v28, v13, v24    // 000000295D84: CA200080 011C310D
	s_cselect_b32 s7, -1, 0                                    // 000000295D8C: 980780C1
	v_add3_u32 v29, v2, v20, v3                                // 000000295D90: D655001D 040E2902
	s_and_b32 vcc_lo, exec_lo, s7                              // 000000295D98: 8B6A077E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000295D9C: BF870002
	.long 0xd4410003                                           // 000000295DA0: D4410003
	v_cndmask_b32_e32 v1, v28, v27, vcc_lo                     // 000000295DA4: 0202371C
	s_cbranch_vccnz 151                                        // 000000295DA8: BFA40097 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x508>
	s_and_saveexec_b32 s8, s3                                  // 000000295DAC: BE882003
	s_cbranch_execz 11                                         // 000000295DB0: BFA5000B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x2e0>
	v_lshlrev_b32_e32 v1, 1, v28                               // 000000295DB4: 30023881
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000295DB8: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000295DBC: 3404029F
	.long 0xd7006a01                                           // 000000295DC0: D7006A01
	v_cndmask_b32_e32 v1, v19, v1, vcc_lo                      // 000000295DC4: 02020313
	v_add_co_ci_u32_e64 v2, null, v29, v2, vcc_lo              // 000000295DC8: D5207C02 01AA051D
	global_load_d16_b16 v1, v[1:2], off                        // 000000295DD0: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000295DD8: BF8903F7
	v_cvt_f32_f16_e32 v1, v1                                   // 000000295DDC: 7E021701
	s_or_b32 exec_lo, exec_lo, s8                              // 000000295DE0: 8C7E087E
	v_dual_mov_b32 v3, 0 :: v_dual_add_nc_u32 v4, 16, v28      // 000000295DE4: CA200080 03043890
	v_mov_b32_e32 v2, 0                                        // 000000295DEC: 7E040280
	s_mov_b32 s3, exec_lo                                      // 000000295DF0: BE83007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000295DF4: BF870002
	.long 0xd4c1007e                                           // 000000295DF8: D4C1007E
	v_cndmask_b32_e32 v1, v4, v27, vcc_lo                      // 000000295DFC: 02023704
	s_cbranch_execz 11                                         // 000000295E00: BFA5000B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x330>
	v_lshlrev_b32_e32 v2, 1, v4                                // 000000295E04: 30040881
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000295E08: BF8700A1
	v_ashrrev_i32_e32 v5, 31, v2                               // 000000295E0C: 340A049F
	.long 0xd7006a04                                           // 000000295E10: D7006A04
	v_cndmask_b32_e32 v1, v19, v2, vcc_lo                      // 000000295E14: 02020513
	v_add_co_ci_u32_e64 v5, null, v29, v5, vcc_lo              // 000000295E18: D5207C05 01AA0B1D
	global_load_d16_b16 v2, v[4:5], off                        // 000000295E20: DC820000 027C0004
	s_waitcnt vmcnt(0)                                         // 000000295E28: BF8903F7
	v_cvt_f32_f16_e32 v2, v2                                   // 000000295E2C: 7E041702
	s_or_b32 exec_lo, exec_lo, s3                              // 000000295E30: 8C7E037E
	v_add_nc_u32_e32 v4, 32, v28                               // 000000295E34: 4A0838A0
	s_mov_b32 s3, exec_lo                                      // 000000295E38: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000295E3C: BF870001
	.long 0xd4c1007e                                           // 000000295E40: D4C1007E
	v_cndmask_b32_e32 v1, v4, v27, vcc_lo                      // 000000295E44: 02023704
	s_cbranch_execz 11                                         // 000000295E48: BFA5000B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x378>
	v_lshlrev_b32_e32 v3, 1, v4                                // 000000295E4C: 30060881
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000295E50: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000295E54: 3408069F
	.long 0xd7006a03                                           // 000000295E58: D7006A03
	v_cndmask_b32_e32 v1, v19, v3, vcc_lo                      // 000000295E5C: 02020713
	v_add_co_ci_u32_e64 v4, null, v29, v4, vcc_lo              // 000000295E60: D5207C04 01AA091D
	global_load_d16_b16 v3, v[3:4], off                        // 000000295E68: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 000000295E70: BF8903F7
	v_cvt_f32_f16_e32 v3, v3                                   // 000000295E74: 7E061703
	s_or_b32 exec_lo, exec_lo, s3                              // 000000295E78: 8C7E037E
	v_dual_mov_b32 v5, 0 :: v_dual_add_nc_u32 v6, 48, v28      // 000000295E7C: CA200080 050638B0
	v_mov_b32_e32 v4, 0                                        // 000000295E84: 7E080280
	s_mov_b32 s3, exec_lo                                      // 000000295E88: BE83007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000295E8C: BF870002
	.long 0xd4c1007e                                           // 000000295E90: D4C1007E
	v_cndmask_b32_e32 v1, v6, v27, vcc_lo                      // 000000295E94: 02023706
	s_cbranch_execz 11                                         // 000000295E98: BFA5000B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x3c8>
	v_lshlrev_b32_e32 v4, 1, v6                                // 000000295E9C: 30080C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000295EA0: BF8700A1
	v_ashrrev_i32_e32 v7, 31, v4                               // 000000295EA4: 340E089F
	.long 0xd7006a06                                           // 000000295EA8: D7006A06
	v_cndmask_b32_e32 v1, v19, v4, vcc_lo                      // 000000295EAC: 02020913
	v_add_co_ci_u32_e64 v7, null, v29, v7, vcc_lo              // 000000295EB0: D5207C07 01AA0F1D
	global_load_d16_b16 v4, v[6:7], off                        // 000000295EB8: DC820000 047C0006
	s_waitcnt vmcnt(0)                                         // 000000295EC0: BF8903F7
	v_cvt_f32_f16_e32 v4, v4                                   // 000000295EC4: 7E081704
	s_or_b32 exec_lo, exec_lo, s3                              // 000000295EC8: 8C7E037E
	v_add_nc_u32_e32 v6, 64, v28                               // 000000295ECC: 4A0C38C0
	s_mov_b32 s3, exec_lo                                      // 000000295ED0: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000295ED4: BF870001
	.long 0xd4c1007e                                           // 000000295ED8: D4C1007E
	v_cndmask_b32_e32 v1, v6, v27, vcc_lo                      // 000000295EDC: 02023706
	s_cbranch_execz 11                                         // 000000295EE0: BFA5000B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x410>
	v_lshlrev_b32_e32 v5, 1, v6                                // 000000295EE4: 300A0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000295EE8: BF8700A1
	v_ashrrev_i32_e32 v6, 31, v5                               // 000000295EEC: 340C0A9F
	.long 0xd7006a05                                           // 000000295EF0: D7006A05
	v_cndmask_b32_e32 v1, v19, v5, vcc_lo                      // 000000295EF4: 02020B13
	v_add_co_ci_u32_e64 v6, null, v29, v6, vcc_lo              // 000000295EF8: D5207C06 01AA0D1D
	global_load_d16_b16 v5, v[5:6], off                        // 000000295F00: DC820000 057C0005
	s_waitcnt vmcnt(0)                                         // 000000295F08: BF8903F7
	v_cvt_f32_f16_e32 v5, v5                                   // 000000295F0C: 7E0A1705
	s_or_b32 exec_lo, exec_lo, s3                              // 000000295F10: 8C7E037E
	v_dual_mov_b32 v7, 0 :: v_dual_add_nc_u32 v8, 0x50, v28    // 000000295F14: CA200080 070838FF 00000050
	v_mov_b32_e32 v6, 0                                        // 000000295F20: 7E0C0280
	s_mov_b32 s3, exec_lo                                      // 000000295F24: BE83007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000295F28: BF870002
	.long 0xd4c1007e                                           // 000000295F2C: D4C1007E
	v_cndmask_b32_e32 v1, v8, v27, vcc_lo                      // 000000295F30: 02023708
	s_cbranch_execz 11                                         // 000000295F34: BFA5000B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x464>
	v_lshlrev_b32_e32 v6, 1, v8                                // 000000295F38: 300C1081
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000295F3C: BF8700A1
	v_ashrrev_i32_e32 v8, 31, v6                               // 000000295F40: 34100C9F
	.long 0xd7006a0b                                           // 000000295F44: D7006A0B
	v_cndmask_b32_e32 v1, v19, v6, vcc_lo                      // 000000295F48: 02020D13
	v_add_co_ci_u32_e64 v12, null, v29, v8, vcc_lo             // 000000295F4C: D5207C0C 01AA111D
	global_load_d16_b16 v6, v[11:12], off                      // 000000295F54: DC820000 067C000B
	s_waitcnt vmcnt(0)                                         // 000000295F5C: BF8903F7
	v_cvt_f32_f16_e32 v6, v6                                   // 000000295F60: 7E0C1706
	s_or_b32 exec_lo, exec_lo, s3                              // 000000295F64: 8C7E037E
	v_add_nc_u32_e32 v8, 0x60, v28                             // 000000295F68: 4A1038FF 00000060
	s_mov_b32 s3, exec_lo                                      // 000000295F70: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000295F74: BF870001
	.long 0xd4c1007e                                           // 000000295F78: D4C1007E
	v_cndmask_b32_e32 v1, v8, v27, vcc_lo                      // 000000295F7C: 02023708
	s_cbranch_execz 11                                         // 000000295F80: BFA5000B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x4b0>
	v_lshlrev_b32_e32 v7, 1, v8                                // 000000295F84: 300E1081
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000295F88: BF8700A1
	v_ashrrev_i32_e32 v8, 31, v7                               // 000000295F8C: 34100E9F
	.long 0xd7006a07                                           // 000000295F90: D7006A07
	v_cndmask_b32_e32 v1, v19, v7, vcc_lo                      // 000000295F94: 02020F13
	v_add_co_ci_u32_e64 v8, null, v29, v8, vcc_lo              // 000000295F98: D5207C08 01AA111D
	global_load_d16_b16 v7, v[7:8], off                        // 000000295FA0: DC820000 077C0007
	s_waitcnt vmcnt(0)                                         // 000000295FA8: BF8903F7
	v_cvt_f32_f16_e32 v7, v7                                   // 000000295FAC: 7E0E1707
	s_or_b32 exec_lo, exec_lo, s3                              // 000000295FB0: 8C7E037E
	v_dual_mov_b32 v8, 0 :: v_dual_add_nc_u32 v11, 0x70, v28   // 000000295FB4: CA200080 080A38FF 00000070
	s_mov_b32 s3, exec_lo                                      // 000000295FC0: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000295FC4: BF870001
	.long 0xd4c1007e                                           // 000000295FC8: D4C1007E
	v_cndmask_b32_e32 v1, v11, v27, vcc_lo                     // 000000295FCC: 0202370B
	s_cbranch_execz 11                                         // 000000295FD0: BFA5000B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x500>
	v_lshlrev_b32_e32 v8, 1, v11                               // 000000295FD4: 30101681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000295FD8: BF8700A1
	v_ashrrev_i32_e32 v12, 31, v8                              // 000000295FDC: 3418109F
	.long 0xd7006a0b                                           // 000000295FE0: D7006A0B
	v_cndmask_b32_e32 v1, v19, v8, vcc_lo                      // 000000295FE4: 02021113
	v_add_co_ci_u32_e64 v12, null, v29, v12, vcc_lo            // 000000295FE8: D5207C0C 01AA191D
	global_load_d16_b16 v8, v[11:12], off                      // 000000295FF0: DC820000 087C000B
	s_waitcnt vmcnt(0)                                         // 000000295FF8: BF8903F7
	v_cvt_f32_f16_e32 v8, v8                                   // 000000295FFC: 7E101708
	s_or_b32 exec_lo, exec_lo, s3                              // 000000296000: 8C7E037E
	s_branch 9                                                 // 000000296004: BFA00009 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x52c>
	v_mov_b32_e32 v1, 0                                        // 000000296008: 7E020280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000029600C: BF870001
	v_mov_b32_e32 v2, v1                                       // 000000296010: 7E040301
	v_mov_b32_e32 v3, v1                                       // 000000296014: 7E060301
	v_mov_b32_e32 v4, v1                                       // 000000296018: 7E080301
	v_mov_b32_e32 v5, v1                                       // 00000029601C: 7E0A0301
	v_mov_b32_e32 v6, v1                                       // 000000296020: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 000000296024: 7E0E0301
	v_mov_b32_e32 v8, v1                                       // 000000296028: 7E100301
	s_add_u32 s4, s18, s4                                      // 00000029602C: 80040412
	s_addc_u32 s5, s19, s5                                     // 000000296030: 82050513
	s_lshr_b32 s3, s15, 31                                     // 000000296034: 85039F0F
	v_cndmask_b32_e64 v31, 0, 1, s7                            // 000000296038: D501001F 001D0280
	s_add_u32 s8, s14, s3                                      // 000000296040: 8008030E
	s_addc_u32 s9, s15, 0                                      // 000000296044: 8209800F
	.long 0xd4410003                                           // 000000296048: D4410003
	v_cndmask_b32_e32 v1, v28, v27, vcc_lo                     // 00000029604C: 0202371C
	s_ashr_i64 s[8:9], s[8:9], 1                               // 000000296050: 86888108
	v_mov_b32_e32 v30, 0                                       // 000000296054: 7E3C0280
	v_mad_u64_u32 v[20:21], null, v10, s8, s[4:5]              // 000000296058: D6FE7C14 0010110A
	.long 0xd72c000c                                           // 000000296060: D72C000C
	v_cndmask_b32_e32 v0, v10, v9, vcc_lo                      // 000000296064: 0200130A
	.long 0xd72c000e                                           // 000000296068: D72C000E
	v_cndmask_b32_e32 v0, v9, v8, vcc_lo                       // 00000029606C: 02001109
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v34, 0              // 000000296070: CA100080 09220080
	v_dual_mov_b32 v11, 0 :: v_dual_mov_b32 v10, 0             // 000000296078: CA100080 0B0A0080
	s_delay_alu instid0(VALU_DEP_3)                            // 000000296080: BF870003
	v_add3_u32 v32, v14, v21, v12                              // 000000296084: D6550020 04322B0E
	v_mov_b32_e32 v12, 0                                       // 00000029608C: 7E180280
	s_and_saveexec_b32 s4, s3                                  // 000000296090: BE842003
	s_cbranch_execz 22                                         // 000000296094: BFA50016 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x5f0>
	v_dual_mov_b32 v34, 0 :: v_dual_lshlrev_b32 v9, 4, v28     // 000000296098: CA220080 22083884
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002960A0: BF8700A1
	v_ashrrev_i32_e32 v10, 31, v9                              // 0000002960A4: 3414129F
	.long 0xd7006a09                                           // 0000002960A8: D7006A09
	v_cndmask_b32_e32 v1, v20, v9, vcc_lo                      // 0000002960AC: 02021314
	v_add_co_ci_u32_e64 v10, null, v32, v10, vcc_lo            // 0000002960B0: D5207C0A 01AA1520
	s_and_not1_b32 vcc_lo, exec_lo, s7                         // 0000002960B8: 916A077E
	global_load_b128 v[9:12], v[9:10], off                     // 0000002960BC: DC5E0000 097C0009
	s_cbranch_vccnz 10                                         // 0000002960C4: BFA4000A <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x5f0>
	v_lshlrev_b32_e32 v14, 1, v28                              // 0000002960C8: 301C3881
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002960CC: BF870091
	.long 0xd7006a0e                                           // 0000002960D0: D7006A0E
	v_cndmask_b32_e32 v1, v19, v14, vcc_lo                     // 0000002960D4: 02021D13
	v_add_co_ci_u32_e64 v15, null, 0, v29, vcc_lo              // 0000002960D8: D5207C0F 01AA3A80
	global_load_d16_b16 v14, v[14:15], off                     // 0000002960E0: DC820000 0E7C000E
	s_waitcnt vmcnt(0)                                         // 0000002960E8: BF8903F7
	v_cvt_f32_f16_e32 v34, v14                                 // 0000002960EC: 7E44170E
	s_or_b32 exec_lo, exec_lo, s4                              // 0000002960F0: 8C7E047E
	v_mov_b32_e32 v33, 0                                       // 0000002960F4: 7E420280
	s_and_saveexec_b32 s7, s3                                  // 0000002960F8: BE872003
	s_cbranch_execz 292                                        // 0000002960FC: BFA50124 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0xa90>
	v_dual_mov_b32 v33, 0 :: v_dual_lshlrev_b32 v14, 5, v24    // 000000296100: CA220080 210E3085
	v_dual_mov_b32 v30, 0 :: v_dual_add_nc_u32 v15, 16, v28    // 000000296108: CA200080 1E0E3890
	s_mov_b32 s8, 0                                            // 000000296110: BE880080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000296114: BF870112
	v_lshl_add_u32 v21, v13, 5, v14                            // 000000296118: D6460015 04390B0D
	v_dual_mov_b32 v37, v34 :: v_dual_lshlrev_b32 v36, 1, v15  // 000000296120: CA220122 25241E81
	v_lshlrev_b32_e32 v35, 4, v15                              // 000000296128: 30461E84
	s_lshl_b64 s[4:5], s[14:15], 1                             // 00000029612C: 8484810E
	s_branch 243                                               // 000000296130: BFA000F3 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0xa00>
	s_or_b32 exec_lo, exec_lo, s9                              // 000000296134: 8C7E097E
	v_ashrrev_i32_e32 v22, 31, v21                             // 000000296138: 342C2A9F
	v_lshrrev_b32_e32 v70, 6, v9                               // 00000029613C: 328C1286
	v_lshrrev_b32_e32 v71, 14, v9                              // 000000296140: 328E128E
	v_and_b32_e32 v72, 0xff, v10                               // 000000296144: 369014FF 000000FF
	v_lshrrev_b32_e32 v73, 6, v10                              // 00000029614C: 32921486
	.long 0xd73c0026                                           // 000000296150: D73C0026
	v_cndmask_b32_e32 v1, 1, v21, vcc_lo                       // 000000296154: 02022A81
	v_and_b32_e32 v22, 0xff, v9                                // 000000296158: 362C12FF 000000FF
	v_and_b32_e32 v70, 0x3fc, v70                              // 000000296160: 368C8CFF 000003FC
	v_and_b32_e32 v71, 0x3fc, v71                              // 000000296168: 368E8EFF 000003FC
	v_lshrrev_b32_e32 v9, 22, v9                               // 000000296170: 32121296
	v_lshrrev_b32_e32 v74, 14, v10                             // 000000296174: 3294148E
	.long 0xd7006a3e                                           // 000000296178: D7006A3E
	v_cndmask_b32_e32 v1, s12, v38, vcc_lo                     // 00000029617C: 02024C0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000296180: BF8701A1
	v_add_co_ci_u32_e64 v63, null, s13, v39, vcc_lo            // 000000296184: D5207C3F 01AA4E0D
	v_lshlrev_b32_e32 v22, 2, v22                              // 00000029618C: 302C2C82
	.long 0xd7006a42                                           // 000000296190: D7006A42
	v_cndmask_b32_e32 v0, v62, v4, vcc_lo                      // 000000296194: 0200093E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000296198: BF870001
	v_add_co_ci_u32_e64 v67, null, s5, v63, vcc_lo             // 00000029619C: D5207C43 01AA7E05
	ds_load_b32 v22, v22                                       // 0000002961A4: D8D80000 16000016
	ds_load_b32 v70, v70                                       // 0000002961AC: D8D80000 46000046
	ds_load_b32 v71, v71                                       // 0000002961B4: D8D80000 47000047
	s_clause 0x7                                               // 0000002961BC: BF850007
	global_load_b128 v[38:41], v[62:63], off                   // 0000002961C0: DC5E0000 267C003E
	global_load_b128 v[42:45], v[66:67], off                   // 0000002961C8: DC5E0000 2A7C0042
	global_load_b128 v[46:49], v[62:63], off offset:16         // 0000002961D0: DC5E0010 2E7C003E
	global_load_b128 v[50:53], v[66:67], off offset:16         // 0000002961D8: DC5E0010 327C0042
	global_load_b128 v[54:57], v[62:63], off offset:32         // 0000002961E0: DC5E0020 367C003E
	global_load_b128 v[58:61], v[66:67], off offset:32         // 0000002961E8: DC5E0020 3A7C0042
	global_load_b128 v[62:65], v[62:63], off offset:48         // 0000002961F0: DC5E0030 3E7C003E
	global_load_b128 v[66:69], v[66:67], off offset:48         // 0000002961F8: DC5E0030 427C0042
	v_lshrrev_b32_e32 v10, 22, v10                             // 000000296200: 32141496
	v_and_b32_e32 v9, 0x3fc, v9                                // 000000296204: 361212FF 000003FC
	v_lshlrev_b32_e32 v72, 2, v72                              // 00000029620C: 30909082
	v_and_b32_e32 v73, 0x3fc, v73                              // 000000296210: 369292FF 000003FC
	v_and_b32_e32 v74, 0x3fc, v74                              // 000000296218: 369494FF 000003FC
	v_and_b32_e32 v10, 0x3fc, v10                              // 000000296220: 361414FF 000003FC
	ds_load_b32 v9, v9                                         // 000000296228: D8D80000 09000009
	ds_load_b32 v72, v72                                       // 000000296230: D8D80000 48000048
	ds_load_b32 v73, v73                                       // 000000296238: D8D80000 49000049
	ds_load_b32 v74, v74                                       // 000000296240: D8D80000 4A00004A
	ds_load_b32 v10, v10                                       // 000000296248: D8D80000 0A00000A
	v_add_nc_u32_e32 v36, 32, v36                              // 000000296250: 4A4848A0
	s_and_b32 s3, exec_lo, s3                                  // 000000296254: 8B03037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000296258: BF870009
	s_or_b32 s8, s3, s8                                        // 00000029625C: 8C080803
	s_waitcnt vmcnt(7) lgkmcnt(7)                              // 000000296260: BF891C77
	v_dot2_f32_bf16 v38, v38, v22, 0                           // 000000296264: CC1A4026 1A022D26
	s_waitcnt vmcnt(6)                                         // 00000029626C: BF891BF7
	v_dot2_f32_bf16 v22, v42, v22, 0                           // 000000296270: CC1A4016 1A022D2A
	v_and_b32_e32 v42, 0xff, v11                               // 000000296278: 365416FF 000000FF
	s_waitcnt lgkmcnt(6)                                       // 000000296280: BF89FC67
	v_dot2_f32_bf16 v38, v39, v70, v38                         // 000000296284: CC1A4026 1C9A8D27
	s_delay_alu instid0(VALU_DEP_3)                            // 00000029628C: BF870003
	v_dot2_f32_bf16 v22, v43, v70, v22                         // 000000296290: CC1A4016 1C5A8D2B
	v_lshrrev_b32_e32 v39, 6, v11                              // 000000296298: 324E1686
	v_lshrrev_b32_e32 v43, 14, v11                             // 00000029629C: 3256168E
	v_lshrrev_b32_e32 v11, 22, v11                             // 0000002962A0: 32161696
	s_waitcnt lgkmcnt(5)                                       // 0000002962A4: BF89FC57
	v_dot2_f32_bf16 v38, v40, v71, v38                         // 0000002962A8: CC1A4026 1C9A8F28
	v_dot2_f32_bf16 v22, v44, v71, v22                         // 0000002962B0: CC1A4016 1C5A8F2C
	v_and_b32_e32 v39, 0x3fc, v39                              // 0000002962B8: 364E4EFF 000003FC
	v_lshrrev_b32_e32 v44, 6, v12                              // 0000002962C0: 32581886
	v_and_b32_e32 v40, 0xff, v12                               // 0000002962C4: 365018FF 000000FF
	s_waitcnt lgkmcnt(4)                                       // 0000002962CC: BF89FC47
	v_dot2_f32_bf16 v38, v41, v9, v38                          // 0000002962D0: CC1A4026 1C9A1329
	v_dot2_f32_bf16 v9, v45, v9, v22                           // 0000002962D8: CC1A4009 1C5A132D
	v_lshlrev_b32_e32 v22, 2, v42                              // 0000002962E0: 302C5482
	v_and_b32_e32 v41, 0x3fc, v43                              // 0000002962E4: 365256FF 000003FC
	v_lshrrev_b32_e32 v70, 14, v12                             // 0000002962EC: 328C188E
	s_waitcnt vmcnt(5) lgkmcnt(3)                              // 0000002962F0: BF891437
	v_dot2_f32_bf16 v38, v46, v72, v38                         // 0000002962F4: CC1A4026 1C9A912E
	s_waitcnt vmcnt(4)                                         // 0000002962FC: BF8913F7
	v_dot2_f32_bf16 v9, v50, v72, v9                           // 000000296300: CC1A4009 1C269132
	ds_load_b32 v22, v22                                       // 000000296308: D8D80000 16000016
	ds_load_b32 v39, v39                                       // 000000296310: D8D80000 27000027
	ds_load_b32 v41, v41                                       // 000000296318: D8D80000 29000029
	s_waitcnt lgkmcnt(5)                                       // 000000296320: BF89FC57
	v_dot2_f32_bf16 v38, v47, v73, v38                         // 000000296324: CC1A4026 1C9A932F
	v_dot2_f32_bf16 v9, v51, v73, v9                           // 00000029632C: CC1A4009 1C269333
	v_lshrrev_b32_e32 v12, 22, v12                             // 000000296334: 32181896
	v_and_b32_e32 v42, 0x3fc, v44                              // 000000296338: 365458FF 000003FC
	v_cndmask_b32_e64 v44, v7, v8, s1                          // 000000296340: D501002C 00061107
	s_waitcnt lgkmcnt(4)                                       // 000000296348: BF89FC47
	v_dot2_f32_bf16 v38, v48, v74, v38                         // 00000029634C: CC1A4026 1C9A9530
	v_dot2_f32_bf16 v9, v52, v74, v9                           // 000000296354: CC1A4009 1C269534
	v_and_b32_e32 v11, 0x3fc, v11                              // 00000029635C: 361616FF 000003FC
	v_lshlrev_b32_e32 v40, 2, v40                              // 000000296364: 30505082
	v_and_b32_e32 v43, 0x3fc, v70                              // 000000296368: 36568CFF 000003FC
	s_waitcnt lgkmcnt(3)                                       // 000000296370: BF89FC37
	v_dot2_f32_bf16 v38, v49, v10, v38                         // 000000296374: CC1A4026 1C9A1531
	v_dot2_f32_bf16 v9, v53, v10, v9                           // 00000029637C: CC1A4009 1C261535
	v_and_b32_e32 v12, 0x3fc, v12                              // 000000296384: 361818FF 000003FC
	ds_load_b32 v10, v11                                       // 00000029638C: D8D80000 0A00000B
	ds_load_b32 v11, v40                                       // 000000296394: D8D80000 0B000028
	ds_load_b32 v45, v42                                       // 00000029639C: D8D80000 2D00002A
	ds_load_b32 v46, v43                                       // 0000002963A4: D8D80000 2E00002B
	ds_load_b32 v47, v12                                       // 0000002963AC: D8D80000 2F00000C
	v_cndmask_b32_e64 v43, v6, v7, s1                          // 0000002963B4: D501002B 00060F06
	v_cndmask_b32_e64 v42, v5, v6, s1                          // 0000002963BC: D501002A 00060D05
	v_cndmask_b32_e64 v40, v3, v4, s1                          // 0000002963C4: D5010028 00060903
	s_waitcnt vmcnt(3) lgkmcnt(7)                              // 0000002963CC: BF890C77
	v_dot2_f32_bf16 v12, v54, v22, v38                         // 0000002963D0: CC1A400C 1C9A2D36
	s_waitcnt vmcnt(2)                                         // 0000002963D8: BF890BF7
	v_dot2_f32_bf16 v9, v58, v22, v9                           // 0000002963DC: CC1A4009 1C262D3A
	v_cndmask_b32_e64 v22, v34, v1, s1                         // 0000002963E4: D5010016 00060322
	v_cndmask_b32_e64 v38, v1, v2, s1                          // 0000002963EC: D5010026 00060501
	v_mov_b32_e32 v34, v37                                     // 0000002963F4: 7E440325
	s_waitcnt lgkmcnt(6)                                       // 0000002963F8: BF89FC67
	v_dot2_f32_bf16 v12, v55, v39, v12                         // 0000002963FC: CC1A400C 1C324F37
	v_dot2_f32_bf16 v9, v59, v39, v9                           // 000000296404: CC1A4009 1C264F3B
	v_cndmask_b32_e64 v39, v2, v3, s1                          // 00000029640C: D5010027 00060702
	s_waitcnt lgkmcnt(5)                                       // 000000296414: BF89FC57
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000296418: BF870193
	v_dot2_f32_bf16 v12, v56, v41, v12                         // 00000029641C: CC1A400C 1C325338
	v_dot2_f32_bf16 v9, v60, v41, v9                           // 000000296424: CC1A4009 1C26533C
	v_cndmask_b32_e64 v41, v4, v5, s1                          // 00000029642C: D5010029 00060B04
	s_waitcnt lgkmcnt(4)                                       // 000000296434: BF89FC47
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000296438: BF870193
	v_dot2_f32_bf16 v12, v57, v10, v12                         // 00000029643C: CC1A400C 1C321539
	v_dot2_f32_bf16 v9, v61, v10, v9                           // 000000296444: CC1A4009 1C26153D
	v_mov_b32_e32 v10, v14                                     // 00000029644C: 7E14030E
	s_waitcnt vmcnt(1) lgkmcnt(3)                              // 000000296450: BF890437
	s_delay_alu instid0(VALU_DEP_3)                            // 000000296454: BF870003
	v_dot2_f32_bf16 v5, v62, v11, v12                          // 000000296458: CC1A4005 1C32173E
	s_waitcnt vmcnt(0)                                         // 000000296460: BF8903F7
	v_dot2_f32_bf16 v6, v66, v11, v9                           // 000000296464: CC1A4006 1C261742
	v_dual_mov_b32 v12, v16 :: v_dual_mov_b32 v11, v15         // 00000029646C: CA100110 0C0A010F
	v_mov_b32_e32 v9, v13                                      // 000000296474: 7E12030D
	s_waitcnt lgkmcnt(2)                                       // 000000296478: BF89FC27
	v_dot2_f32_bf16 v1, v63, v45, v5                           // 00000029647C: CC1A4001 1C165B3F
	v_dot2_f32_bf16 v2, v67, v45, v6                           // 000000296484: CC1A4002 1C1A5B43
	v_mov_b32_e32 v45, v8                                      // 00000029648C: 7E5A0308
	v_add_nc_u32_e32 v35, 0x100, v35                           // 000000296490: 4A4646FF 00000100
	v_add_nc_u32_e32 v21, 0x200, v21                           // 000000296498: 4A2A2AFF 00000200
	s_waitcnt lgkmcnt(1)                                       // 0000002964A0: BF89FC17
	v_dot2_f32_bf16 v1, v64, v46, v1                           // 0000002964A4: CC1A4001 1C065D40
	v_dot2_f32_bf16 v2, v68, v46, v2                           // 0000002964AC: CC1A4002 1C0A5D44
	s_waitcnt lgkmcnt(0)                                       // 0000002964B4: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002964B8: BF870112
	v_dot2_f32_bf16 v1, v65, v47, v1                           // 0000002964BC: CC1A4001 1C065F41
	v_dot2_f32_bf16 v2, v69, v47, v2                           // 0000002964C4: CC1A4002 1C0A5F45
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002964CC: BF870112
	v_fmac_f32_e32 v33, v22, v1                                // 0000002964D0: 56420316
	v_fmac_f32_e32 v30, v22, v2                                // 0000002964D4: 563C0516
	v_dual_mov_b32 v1, v38 :: v_dual_mov_b32 v2, v39           // 0000002964D8: CA100126 01020127
	v_dual_mov_b32 v3, v40 :: v_dual_mov_b32 v4, v41           // 0000002964E0: CA100128 03040129
	v_dual_mov_b32 v5, v42 :: v_dual_mov_b32 v6, v43           // 0000002964E8: CA10012A 0506012B
	v_dual_mov_b32 v7, v44 :: v_dual_mov_b32 v8, v45           // 0000002964F0: CA10012C 0708012D
	s_and_not1_b32 exec_lo, exec_lo, s8                        // 0000002964F8: 917E087E
	s_cbranch_execz 35                                         // 0000002964FC: BFA50023 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0xa8c>
	s_waitcnt vmcnt(0)                                         // 000000296500: BF8903F7
	v_dual_mov_b32 v13, v9 :: v_dual_add_nc_u32 v28, 16, v28   // 000000296504: CA200109 0D1C3890
	v_dual_mov_b32 v14, v10 :: v_dual_mov_b32 v15, v11         // 00000029650C: CA10010A 0E0E010B
	v_mov_b32_e32 v16, v12                                     // 000000296514: 7E20030C
	s_delay_alu instid0(VALU_DEP_3)                            // 000000296518: BF870003
	.long 0xd4460003                                           // 00000029651C: D4460003
	v_cndmask_b32_e32 v1, v28, v27, vcc_lo                     // 000000296520: 0202371C
	s_mov_b32 s9, exec_lo                                      // 000000296524: BE89007E
	.long 0xd4c1007e                                           // 000000296528: D4C1007E
	v_cndmask_b32_e32 v1, v28, v27, vcc_lo                     // 00000029652C: 0202371C
	s_cbranch_execz 65280                                      // 000000296530: BFA5FF00 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x634>
	v_ashrrev_i32_e32 v14, 31, v35                             // 000000296534: 341C469F
	.long 0xd7006a0d                                           // 000000296538: D7006A0D
	v_cndmask_b32_e32 v1, v20, v35, vcc_lo                     // 00000029653C: 02024714
	v_mov_b32_e32 v37, v34                                     // 000000296540: 7E4A0322
	s_delay_alu instid0(VALU_DEP_3)                            // 000000296544: BF870003
	v_add_co_ci_u32_e64 v14, null, v32, v14, vcc_lo            // 000000296548: D5207C0E 01AA1D20
	v_cmp_ne_u32_e32 vcc_lo, 1, v31                            // 000000296550: 7C9A3E81
	global_load_b128 v[13:16], v[13:14], off                   // 000000296554: DC5E0000 0D7C000D
	s_cbranch_vccnz 65269                                      // 00000029655C: BFA4FEF5 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x634>
	v_ashrrev_i32_e32 v22, 31, v36                             // 000000296560: 342C489F
	.long 0xd7006a25                                           // 000000296564: D7006A25
	v_cndmask_b32_e32 v1, v19, v36, vcc_lo                     // 000000296568: 02024913
	s_delay_alu instid0(VALU_DEP_1)                            // 00000029656C: BF870001
	v_add_co_ci_u32_e64 v38, null, v29, v22, vcc_lo            // 000000296570: D5207C26 01AA2D1D
	global_load_d16_b16 v22, v[37:38], off                     // 000000296578: DC820000 167C0025
	s_waitcnt vmcnt(0)                                         // 000000296580: BF8903F7
	v_cvt_f32_f16_e32 v37, v22                                 // 000000296584: 7E4A1716
	s_branch 65258                                             // 000000296588: BFA0FEEA <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x634>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000029658C: 8C7E087E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000296590: BF870009
	s_or_b32 exec_lo, exec_lo, s7                              // 000000296594: 8C7E077E
	.long 0xd71f0001                                           // 000000296598: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000029659C: 020100C1
	.long 0xd44a0001                                           // 0000002965A0: D44A0001
	v_cndmask_b32_e32 v1, 0, v24, vcc_lo                       // 0000002965A4: 02023080
	s_mov_b32 s3, -1                                           // 0000002965A8: BE8300C1
	v_xor_b32_e32 v2, 8, v1                                    // 0000002965AC: 3A040288
	v_xor_b32_e32 v4, 4, v1                                    // 0000002965B0: 3A080284
	v_xor_b32_e32 v6, 2, v1                                    // 0000002965B4: 3A0C0282
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000002965B8: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000002965BC: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 0000002965C0: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 0000002965C4: 7C9808A0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002965C8: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000002965CC: 30040482
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo                       // 0000002965D0: 02080901
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 0000002965D4: 7C980CA0
	ds_bpermute_b32 v3, v2, v33                                // 0000002965D8: DACC0000 03002102
	v_lshlrev_b32_e32 v4, 2, v4                                // 0000002965E0: 30080882
	v_cndmask_b32_e32 v6, v1, v6, vcc_lo                       // 0000002965E4: 020C0D01
	s_waitcnt lgkmcnt(0)                                       // 0000002965E8: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002965EC: BF870001
	v_dual_add_f32 v3, v33, v3 :: v_dual_lshlrev_b32 v6, 2, v6 // 0000002965F0: C9220721 03060C82
	ds_bpermute_b32 v2, v2, v30                                // 0000002965F8: DACC0000 02001E02
	ds_bpermute_b32 v5, v4, v3                                 // 000000296600: DACC0000 05000304
	s_waitcnt lgkmcnt(0)                                       // 000000296608: BF89FC07
	v_dual_add_f32 v3, v3, v5 :: v_dual_add_f32 v2, v30, v2    // 00000029660C: C9080B03 0302051E
	ds_bpermute_b32 v4, v4, v2                                 // 000000296614: DACC0000 04000204
	s_waitcnt lgkmcnt(0)                                       // 00000029661C: BF89FC07
	v_add_f32_e32 v2, v2, v4                                   // 000000296620: 06040902
	ds_bpermute_b32 v4, v6, v3                                 // 000000296624: DACC0000 04000306
	ds_bpermute_b32 v5, v6, v2                                 // 00000029662C: DACC0000 05000206
	v_xor_b32_e32 v6, 1, v1                                    // 000000296634: 3A0C0281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000296638: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 00000029663C: 7C980CA0
	v_cndmask_b32_e32 v1, v1, v6, vcc_lo                       // 000000296640: 02020D01
	s_and_b32 vcc_lo, exec_lo, s6                              // 000000296644: 8B6A067E
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000296648: 30020282
	s_waitcnt lgkmcnt(0)                                       // 00000029664C: BF89FC07
	v_dual_add_f32 v3, v3, v4 :: v_dual_add_f32 v2, v2, v5     // 000000296650: C9080903 03020B02
	ds_bpermute_b32 v4, v1, v3                                 // 000000296658: DACC0000 04000301
	ds_bpermute_b32 v5, v1, v2                                 // 000000296660: DACC0000 05000201
	s_waitcnt lgkmcnt(0)                                       // 000000296668: BF89FC07
	v_dual_add_f32 v1, v3, v4 :: v_dual_add_f32 v2, v2, v5     // 00000029666C: C9080903 01020B02
	s_cbranch_vccz 425                                         // 000000296674: BFA301A9 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x121c>
	s_and_saveexec_b32 s3, s1                                  // 000000296678: BE832001
	v_lshlrev_b32_e32 v3, 3, v26                               // 00000029667C: 30063483
	s_delay_alu instid0(VALU_DEP_1)                            // 000000296680: BF870001
	v_lshl_or_b32 v3, v25, 7, v3                               // 000000296684: D6560003 040D0F19
	ds_store_b64 v3, v[1:2] offset:1024                        // 00000029668C: D9340400 00000103
	s_or_b32 exec_lo, exec_lo, s3                              // 000000296694: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000296698: BF870009
	s_mov_b32 s8, exec_lo                                      // 00000029669C: BE88007E
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000002966A0: BF890007
	s_barrier                                                  // 0000002966A4: BFBD0000
	buffer_gl0_inv                                             // 0000002966A8: E0AC0000 00000000
	v_cmpx_gt_u32_e32 2, v0                                    // 0000002966B0: 7D980082
	s_cbranch_execz 407                                        // 0000002966B4: BFA50197 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1214>
	s_load_b32 s3, s[16:17], 0x40                              // 0000002966B8: F40000C8 F8000040
	s_waitcnt lgkmcnt(0)                                       // 0000002966C0: BF89FC07
	s_sub_i32 s2, s2, s3                                       // 0000002966C4: 81820302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000002966C8: BF870499
	s_ashr_i32 s3, s2, 31                                      // 0000002966CC: 86039F02
	.long 0xd4530004                                           // 0000002966D0: D4530004
	v_cndmask_b32_e32 v0, s10, v2, vcc_lo                      // 0000002966D4: 0200040A
	s_and_b32 vcc_lo, exec_lo, s4                              // 0000002966D8: 8B6A047E
	s_cbranch_vccnz 397                                        // 0000002966DC: BFA4018D <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1214>
	v_add_nc_u32_e32 v9, 0x400, v23                            // 0000002966E0: 4A122EFF 00000400
	s_clause 0x1                                               // 0000002966E8: BF850001
	s_load_b64 s[6:7], s[16:17], 0x38                          // 0000002966EC: F4040188 F8000038
	s_load_b64 s[4:5], s[16:17], 0x8                           // 0000002966F4: F4040108 F8000008
	s_mov_b32 s9, 0                                            // 0000002966FC: BE890080
	s_mov_b32 s13, -1                                          // 000000296700: BE8D00C1
	s_mov_b32 s12, 0                                           // 000000296704: BE8C0080
	ds_load_2addr_b32 v[3:4], v9 offset1:2                     // 000000296708: D8DC0200 03000009
	ds_load_2addr_b32 v[5:6], v9 offset0:4 offset1:6           // 000000296710: D8DC0604 05000009
	ds_load_2addr_b32 v[7:8], v9 offset0:8 offset1:10          // 000000296718: D8DC0A08 07000009
	s_waitcnt lgkmcnt(0)                                       // 000000296720: BF89FC07
	s_cmp_lt_i32 s7, 3                                         // 000000296724: BF048307
	v_add_f32_e32 v3, 0, v3                                    // 000000296728: 06060680
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000029672C: BF8700B1
	v_add_f32_e32 v10, v3, v4                                  // 000000296730: 06140903
	ds_load_2addr_b32 v[3:4], v9 offset0:12 offset1:14         // 000000296734: D8DC0E0C 03000009
	v_add_f32_e32 v5, v10, v5                                  // 00000029673C: 060A0B0A
	v_add_f32_e32 v10, v5, v6                                  // 000000296740: 06140D05
	ds_load_2addr_b32 v[5:6], v9 offset0:16 offset1:18         // 000000296744: D8DC1210 05000009
	v_add_f32_e32 v7, v10, v7                                  // 00000029674C: 060E0F0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000296750: BF8700C1
	v_add_f32_e32 v10, v7, v8                                  // 000000296754: 06141107
	ds_load_2addr_b32 v[7:8], v9 offset0:20 offset1:22         // 000000296758: D8DC1614 07000009
	s_waitcnt lgkmcnt(2)                                       // 000000296760: BF89FC27
	v_add_f32_e32 v3, v10, v3                                  // 000000296764: 0606070A
	v_add_f32_e32 v3, v3, v4                                   // 000000296768: 06060903
	s_waitcnt lgkmcnt(1)                                       // 00000029676C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000296770: BF8700C1
	v_add_f32_e32 v5, v3, v5                                   // 000000296774: 060A0B03
	ds_load_2addr_b32 v[3:4], v9 offset0:24 offset1:26         // 000000296778: D8DC1A18 03000009
	v_add_f32_e32 v5, v5, v6                                   // 000000296780: 060A0D05
	s_waitcnt lgkmcnt(1)                                       // 000000296784: BF89FC17
	v_add_f32_e32 v7, v5, v7                                   // 000000296788: 060E0F05
	ds_load_2addr_b32 v[5:6], v9 offset0:28 offset1:30         // 00000029678C: D8DC1E1C 05000009
	v_add_f32_e32 v7, v7, v8                                   // 000000296794: 060E1107
	s_waitcnt lgkmcnt(1)                                       // 000000296798: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029679C: BF870091
	v_add_f32_e32 v3, v7, v3                                   // 0000002967A0: 06060707
	v_add_f32_e32 v3, v3, v4                                   // 0000002967A4: 06060903
	s_waitcnt lgkmcnt(0)                                       // 0000002967A8: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002967AC: BF870091
	v_add_f32_e32 v3, v3, v5                                   // 0000002967B0: 06060B03
	v_add_f32_e32 v3, v3, v6                                   // 0000002967B4: 06060D03
	s_cbranch_scc1 178                                         // 0000002967B8: BFA200B2 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0xf84>
	s_cmp_gt_i32 s7, 3                                         // 0000002967BC: BF028307
	s_cbranch_scc0 112                                         // 0000002967C0: BFA10070 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0xe84>
	s_cmp_gt_i32 s7, 4                                         // 0000002967C4: BF028407
	s_cbranch_scc0 58                                          // 0000002967C8: BFA1003A <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0xdb4>
	s_cmp_eq_u32 s7, 5                                         // 0000002967CC: BF068507
	s_mov_b32 s12, -1                                          // 0000002967D0: BE8C00C1
	s_cbranch_scc0 54                                          // 0000002967D4: BFA10036 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0xdb0>
	s_ashr_i32 s14, s2, 31                                     // 0000002967D8: 860E9F02
	s_load_b64 s[12:13], s[16:17], 0x10                        // 0000002967DC: F4040308 F8000010
	s_lshr_b32 s14, s14, 23                                    // 0000002967E4: 850E970E
	s_lshr_b32 s15, s10, 31                                    // 0000002967E8: 850F9F0A
	s_add_i32 s14, s2, s14                                     // 0000002967EC: 810E0E02
	s_add_i32 s18, s10, s15                                    // 0000002967F0: 81120F0A
	s_ashr_i32 s14, s14, 9                                     // 0000002967F4: 860E890E
	s_ashr_i32 s18, s18, 1                                     // 0000002967F8: 86128112
	s_ashr_i32 s15, s14, 31                                    // 0000002967FC: 860F9F0E
	v_mad_i64_i32 v[4:5], null, s18, v0, 0                     // 000000296800: D6FF7C04 02020012
	s_lshl_b64 s[14:15], s[14:15], 9                           // 000000296808: 848E890E
	v_bfe_u32 v6, v3, 16, 1                                    // 00000029680C: D6100006 02052103
	s_sub_u32 s18, s2, s14                                     // 000000296814: 80920E02
	s_subb_u32 s19, s3, s15                                    // 000000296818: 82930F03
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000029681C: BF870119
	.long 0xd4540014                                           // 000000296820: D4540014
	v_cndmask_b32_e32 v0, 0x100, v18, vcc_lo                   // 000000296824: 020024FF 00000100
	v_add3_u32 v6, v3, v6, 0x7fff                              // 00000029682C: D6550006 03FE0D03 00007FFF
	.long 0xd73c0004                                           // 000000296838: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 00000029683C: 02020881
	s_and_b32 s21, s20, exec_lo                                // 000000296840: 8B157E14
	s_waitcnt lgkmcnt(0)                                       // 000000296844: BF89FC07
	s_cselect_b32 s12, s4, s12                                 // 000000296848: 980C0C04
	s_cselect_b32 s21, s5, s13                                 // 00000029684C: 98150D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000296850: BF870091
	.long 0xd7006a04                                           // 000000296854: D7006A04
	v_cndmask_b32_e32 v1, s12, v4, vcc_lo                      // 000000296858: 0202080C
	v_add_co_ci_u32_e64 v5, null, s21, v5, vcc_lo              // 00000029685C: D5207C05 01AA0A15
	s_add_u32 s22, s18, 0xffffff00                             // 000000296864: 8016FF12 FFFFFF00
	s_addc_u32 s13, s19, -1                                    // 00000029686C: 820DC113
	s_and_b32 s20, s20, exec_lo                                // 000000296870: 8B147E14
	.long 0xd7006a04                                           // 000000296874: D7006A04
	v_cndmask_b32_e32 v0, v4, v14, vcc_lo                      // 000000296878: 02001D04
	s_cselect_b32 s13, s19, s13                                // 00000029687C: 980D0D13
	s_cselect_b32 s12, s18, s22                                // 000000296880: 980C1612
	v_add_co_ci_u32_e64 v5, null, s15, v5, vcc_lo              // 000000296884: D5207C05 01AA0A0F
	s_lshl_b64 s[12:13], s[12:13], 1                           // 00000029688C: 848C810C
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000296890: BF870099
	.long 0xd7006a04                                           // 000000296894: D7006A04
	v_cndmask_b32_e32 v0, v4, v12, vcc_lo                      // 000000296898: 02001904
	v_add_co_ci_u32_e64 v5, null, s13, v5, vcc_lo              // 00000029689C: D5207C05 01AA0A0D
	s_mov_b32 s12, 0                                           // 0000002968A4: BE8C0080
	global_store_d16_hi_b16 v[4:5], v6, off                    // 0000002968A8: DC960000 007C0604
	s_mov_b32 s13, 0                                           // 0000002968B0: BE8D0080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002968B4: BF870009
	s_and_b32 vcc_lo, exec_lo, s13                             // 0000002968B8: 8B6A0D7E
	s_cbranch_vccz 48                                          // 0000002968BC: BFA30030 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0xe80>
	v_mul_f32_e32 v4, 0xbfb8aa3b, v3                           // 0000002968C0: 100806FF BFB8AA3B
	s_lshl_b64 s[14:15], s[2:3], 2                             // 0000002968C8: 848E8202
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002968CC: BF870291
	v_exp_f32_e32 v4, v4                                       // 0000002968D0: 7E084B04
	v_add_f32_e32 v7, 1.0, v4                                  // 0000002968D4: 060E08F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002968D8: BF870121
	v_div_scale_f32 v8, null, v7, v7, 1.0                      // 0000002968DC: D6FC7C08 03CA0F07
	v_div_scale_f32 v10, vcc_lo, 1.0, v7, 1.0                  // 0000002968E4: D6FC6A0A 03CA0EF2
	v_rcp_f32_e32 v9, v8                                       // 0000002968EC: 7E125508
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002968F0: BF870095
	v_fma_f32 v4, -v8, v9, 1.0                                 // 0000002968F4: D6130004 23CA1308
	v_fmac_f32_e32 v9, v4, v9                                  // 0000002968FC: 56121304
	v_mad_u64_u32 v[4:5], null, s10, v0, 0                     // 000000296900: D6FE7C04 0202000A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000296908: BF870112
	v_mul_f32_e32 v11, v10, v9                                 // 00000029690C: 1016130A
	v_mad_u64_u32 v[5:6], null, s11, v0, v[5:6]                // 000000296910: D6FE7C05 0416000B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000296918: BF870092
	v_fma_f32 v12, -v8, v11, v10                               // 00000029691C: D613000C 242A1708
	v_fmac_f32_e32 v11, v12, v9                                // 000000296924: 5616130C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000296928: BF870113
	.long 0xd73c0004                                           // 00000029692C: D73C0004
	v_cndmask_b32_e32 v1, 2, v4, vcc_lo                        // 000000296930: 02020882
	v_fma_f32 v6, -v8, v11, v10                                // 000000296934: D6130006 242A1708
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000029693C: BF870191
	v_div_fmas_f32 v6, v6, v9, v11                             // 000000296940: D6370006 042E1306
	.long 0xd7006a04                                           // 000000296948: D7006A04
	v_cndmask_b32_e32 v1, s4, v4, vcc_lo                       // 00000029694C: 02020804
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000296950: BF870191
	v_add_co_ci_u32_e64 v5, null, s5, v5, vcc_lo               // 000000296954: D5207C05 01AA0A05
	v_div_fixup_f32 v6, v6, v7, 1.0                            // 00000029695C: D6270006 03CA0F06
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000296964: BF870093
	.long 0xd7006a04                                           // 000000296968: D7006A04
	v_cndmask_b32_e32 v0, v4, v14, vcc_lo                      // 00000029696C: 02001D04
	v_add_co_ci_u32_e64 v5, null, s15, v5, vcc_lo              // 000000296970: D5207C05 01AA0A0F
	global_store_b32 v[4:5], v6, off                           // 000000296978: DC6A0000 007C0604
	s_mov_b32 s13, 0                                           // 000000296980: BE8D0080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000296984: BF870009
	s_and_b32 vcc_lo, exec_lo, s13                             // 000000296988: 8B6A0D7E
	s_cbranch_vccz 60                                          // 00000029698C: BFA3003C <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0xf80>
	v_bfe_u32 v4, v3, 16, 1                                    // 000000296990: D6100004 02052103
	s_lshl_b64 s[14:15], s[2:3], 2                             // 000000296998: 848E8202
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029699C: BF870091
	v_add3_u32 v4, v3, v4, 0x7fff                              // 0000002969A0: D6550004 03FE0903 00007FFF
	v_and_b32_e32 v4, 0xffff0000, v4                           // 0000002969AC: 360808FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002969B4: BF870091
	v_mul_f32_e32 v4, s6, v4                                   // 0000002969B8: 10080806
	v_mul_f32_e32 v4, 0xbfb8aa3b, v4                           // 0000002969BC: 100808FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002969C4: BF870291
	v_exp_f32_e32 v4, v4                                       // 0000002969C8: 7E084B04
	v_add_f32_e32 v7, 1.0, v4                                  // 0000002969CC: 060E08F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002969D0: BF870121
	v_div_scale_f32 v8, null, v7, v7, 1.0                      // 0000002969D4: D6FC7C08 03CA0F07
	v_div_scale_f32 v10, vcc_lo, 1.0, v7, 1.0                  // 0000002969DC: D6FC6A0A 03CA0EF2
	v_rcp_f32_e32 v9, v8                                       // 0000002969E4: 7E125508
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002969E8: BF870095
	v_fma_f32 v4, -v8, v9, 1.0                                 // 0000002969EC: D6130004 23CA1308
	v_fmac_f32_e32 v9, v4, v9                                  // 0000002969F4: 56121304
	v_mad_u64_u32 v[4:5], null, s10, v0, 0                     // 0000002969F8: D6FE7C04 0202000A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000296A00: BF870092
	v_mul_f32_e32 v11, v10, v9                                 // 000000296A04: 1016130A
	v_fma_f32 v6, -v8, v11, v10                                // 000000296A08: D6130006 242A1708
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000296A10: BF870211
	v_fmac_f32_e32 v11, v6, v9                                 // 000000296A14: 56161306
	v_mad_u64_u32 v[5:6], null, s11, v0, v[5:6]                // 000000296A18: D6FE7C05 0416000B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000296A20: BF870112
	v_fma_f32 v6, -v8, v11, v10                                // 000000296A24: D6130006 242A1708
	.long 0xd73c0004                                           // 000000296A2C: D73C0004
	v_cndmask_b32_e32 v1, 2, v4, vcc_lo                        // 000000296A30: 02020882
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000296A34: BF870112
	v_div_fmas_f32 v6, v6, v9, v11                             // 000000296A38: D6370006 042E1306
	.long 0xd7006a04                                           // 000000296A40: D7006A04
	v_cndmask_b32_e32 v1, s4, v4, vcc_lo                       // 000000296A44: 02020804
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000296A48: BF870212
	v_div_fixup_f32 v6, v6, v7, 1.0                            // 000000296A4C: D6270006 03CA0F06
	v_add_co_ci_u32_e64 v5, null, s5, v5, vcc_lo               // 000000296A54: D5207C05 01AA0A05
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000296A5C: BF870193
	.long 0xd7006a04                                           // 000000296A60: D7006A04
	v_cndmask_b32_e32 v0, v4, v14, vcc_lo                      // 000000296A64: 02001D04
	v_add_f32_e32 v6, v6, v6                                   // 000000296A68: 060C0D06
	s_delay_alu instid0(VALU_DEP_3)                            // 000000296A6C: BF870003
	v_add_co_ci_u32_e64 v5, null, s15, v5, vcc_lo              // 000000296A70: D5207C05 01AA0A0F
	global_store_b32 v[4:5], v6, off                           // 000000296A78: DC6A0000 007C0604
	s_mov_b32 s13, 0                                           // 000000296A80: BE8D0080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000296A84: BF870009
	s_and_b32 vcc_lo, exec_lo, s13                             // 000000296A88: 8B6A0D7E
	s_cbranch_vccz 72                                          // 000000296A8C: BFA30048 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x10b0>
	s_cmp_gt_i32 s7, 1                                         // 000000296A90: BF028107
	s_mov_b32 s9, -1                                           // 000000296A94: BE8900C1
	s_cbranch_scc0 63                                          // 000000296A98: BFA1003F <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1098>
	v_bfe_u32 v4, v3, 16, 1                                    // 000000296A9C: D6100004 02052103
	s_lshl_b64 s[14:15], s[2:3], 1                             // 000000296AA4: 848E8102
	s_mov_b32 s9, 0                                            // 000000296AA8: BE890080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000296AAC: BF870091
	v_add3_u32 v4, v3, v4, 0x7fff                              // 000000296AB0: D6550004 03FE0903 00007FFF
	v_and_b32_e32 v4, 0xffff0000, v4                           // 000000296ABC: 360808FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000296AC4: BF870091
	v_mul_f32_e32 v4, 0xbfb8aa3b, v4                           // 000000296AC8: 100808FF BFB8AA3B
	v_exp_f32_e32 v4, v4                                       // 000000296AD0: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000296AD4: BF870095
	v_add_f32_e32 v7, 1.0, v4                                  // 000000296AD8: 060E08F2
	v_div_scale_f32 v6, null, v7, v7, 1.0                      // 000000296ADC: D6FC7C06 03CA0F07
	v_div_scale_f32 v9, vcc_lo, 1.0, v7, 1.0                   // 000000296AE4: D6FC6A09 03CA0EF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000296AEC: BF870292
	v_rcp_f32_e32 v8, v6                                       // 000000296AF0: 7E105506
	v_fma_f32 v4, -v6, v8, 1.0                                 // 000000296AF4: D6130004 23CA1106
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000296AFC: BF870121
	v_fmac_f32_e32 v8, v4, v8                                  // 000000296B00: 56101104
	v_mad_u64_u32 v[4:5], null, s10, v0, 0                     // 000000296B04: D6FE7C04 0202000A
	v_mul_f32_e32 v10, v9, v8                                  // 000000296B0C: 10141109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000296B10: BF870091
	v_fma_f32 v11, -v6, v10, v9                                // 000000296B14: D613000B 24261506
	v_fmac_f32_e32 v10, v11, v8                                // 000000296B1C: 5614110B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000296B20: BF870121
	v_fma_f32 v9, -v6, v10, v9                                 // 000000296B24: D6130009 24261506
	v_mad_u64_u32 v[5:6], null, s11, v0, v[5:6]                // 000000296B2C: D6FE7C05 0416000B
	v_div_fmas_f32 v6, v9, v8, v10                             // 000000296B34: D6370006 042A1109
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000296B3C: BF870112
	.long 0xd73c0004                                           // 000000296B40: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 000000296B44: 02020881
	v_div_fixup_f32 v6, v6, v7, 1.0                            // 000000296B48: D6270006 03CA0F06
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000296B50: BF870112
	.long 0xd7006a04                                           // 000000296B54: D7006A04
	v_cndmask_b32_e32 v1, s4, v4, vcc_lo                       // 000000296B58: 02020804
	v_bfe_u32 v7, v6, 16, 1                                    // 000000296B5C: D6100007 02052106
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000296B64: BF870194
	v_add_co_ci_u32_e64 v5, null, s5, v5, vcc_lo               // 000000296B68: D5207C05 01AA0A05
	.long 0xd7006a04                                           // 000000296B70: D7006A04
	v_cndmask_b32_e32 v0, v4, v14, vcc_lo                      // 000000296B74: 02001D04
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000296B78: BF870193
	v_add3_u32 v6, v6, v7, 0x7fff                              // 000000296B7C: D6550006 03FE0F06 00007FFF
	v_add_co_ci_u32_e64 v5, null, s15, v5, vcc_lo              // 000000296B88: D5207C05 01AA0A0F
	global_store_d16_hi_b16 v[4:5], v6, off                    // 000000296B90: DC960000 007C0604
	s_and_not1_b32 vcc_lo, exec_lo, s9                         // 000000296B98: 916A097E
	s_mov_b32 s9, 0                                            // 000000296B9C: BE890080
	s_cbranch_vccnz 3                                          // 000000296BA0: BFA40003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x10b0>
	s_cmp_lg_u32 s7, 1                                         // 000000296BA4: BF078107
	s_mov_b32 s9, -1                                           // 000000296BA8: BE8900C1
	s_cselect_b32 s12, -1, 0                                   // 000000296BAC: 980C80C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000296BB0: BF8700A1
	v_bfe_u32 v4, v3, 16, 1                                    // 000000296BB4: D6100004 02052103
	s_and_b32 vcc_lo, exec_lo, s12                             // 000000296BBC: 8B6A0C7E
	v_add3_u32 v3, v3, v4, 0x7fff                              // 000000296BC0: D6550003 03FE0903 00007FFF
	s_cbranch_vccz 21                                          // 000000296BCC: BFA30015 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1124>
	v_mad_u64_u32 v[4:5], null, s10, v0, 0                     // 000000296BD0: D6FE7C04 0202000A
	s_lshl_b64 s[12:13], s[2:3], 1                             // 000000296BD8: 848C8102
	s_mov_b32 s9, 0                                            // 000000296BDC: BE890080
	v_mad_u64_u32 v[5:6], null, s11, v0, v[5:6]                // 000000296BE0: D6FE7C05 0416000B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000296BE8: BF870091
	.long 0xd73c0004                                           // 000000296BEC: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 000000296BF0: 02020881
	.long 0xd7006a04                                           // 000000296BF4: D7006A04
	v_cndmask_b32_e32 v1, s4, v4, vcc_lo                       // 000000296BF8: 02020804
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000296BFC: BF870111
	v_add_co_ci_u32_e64 v5, null, s5, v5, vcc_lo               // 000000296C00: D5207C05 01AA0A05
	.long 0xd7006a04                                           // 000000296C08: D7006A04
	v_cndmask_b32_e32 v0, v4, v12, vcc_lo                      // 000000296C0C: 02001904
	s_delay_alu instid0(VALU_DEP_1)                            // 000000296C10: BF870001
	v_add_co_ci_u32_e64 v5, null, s13, v5, vcc_lo              // 000000296C14: D5207C05 01AA0A0D
	global_store_d16_hi_b16 v[4:5], v3, off                    // 000000296C1C: DC960000 007C0304
	s_and_not1_b32 vcc_lo, exec_lo, s9                         // 000000296C24: 916A097E
	s_cbranch_vccnz 58                                         // 000000296C28: BFA4003A <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1214>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000296C2C: BF8700A1
	v_and_b32_e32 v3, 0xffff0000, v3                           // 000000296C30: 360606FF FFFF0000
	s_lshl_b64 s[2:3], s[2:3], 1                               // 000000296C38: 84828102
	v_mul_f32_e32 v6, s6, v3                                   // 000000296C3C: 100C0606
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000296C40: BF870091
	v_mul_f32_e32 v3, 0xbfb8aa3b, v6                           // 000000296C44: 10060CFF BFB8AA3B
	v_exp_f32_e32 v3, v3                                       // 000000296C4C: 7E064B03
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000296C50: BF870095
	v_add_f32_e32 v7, 1.0, v3                                  // 000000296C54: 060E06F2
	v_div_scale_f32 v5, null, v7, v7, v6                       // 000000296C58: D6FC7C05 041A0F07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000296C60: BF870291
	v_rcp_f32_e32 v8, v5                                       // 000000296C64: 7E105505
	v_fma_f32 v3, -v5, v8, 1.0                                 // 000000296C68: D6130003 23CA1105
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000296C70: BF870131
	v_fmac_f32_e32 v8, v3, v8                                  // 000000296C74: 56101103
	v_div_scale_f32 v9, vcc_lo, v6, v7, v6                     // 000000296C78: D6FC6A09 041A0F06
	v_mad_u64_u32 v[3:4], null, s10, v0, 0                     // 000000296C80: D6FE7C03 0202000A
	v_mul_f32_e32 v10, v9, v8                                  // 000000296C88: 10141109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000296C8C: BF870091
	v_fma_f32 v11, -v5, v10, v9                                // 000000296C90: D613000B 24261505
	v_fmac_f32_e32 v10, v11, v8                                // 000000296C98: 5614110B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000296C9C: BF870121
	v_fma_f32 v9, -v5, v10, v9                                 // 000000296CA0: D6130009 24261505
	v_mad_u64_u32 v[4:5], null, s11, v0, v[4:5]                // 000000296CA8: D6FE7C04 0412000B
	v_div_fmas_f32 v0, v9, v8, v10                             // 000000296CB0: D6370000 042A1109
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000296CB8: BF870112
	.long 0xd73c0003                                           // 000000296CBC: D73C0003
	v_cndmask_b32_e32 v1, 1, v3, vcc_lo                        // 000000296CC0: 02020681
	v_div_fixup_f32 v0, v0, v7, v6                             // 000000296CC4: D6270000 041A0F00
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000296CCC: BF870112
	.long 0xd7006a03                                           // 000000296CD0: D7006A03
	v_cndmask_b32_e32 v1, s4, v3, vcc_lo                       // 000000296CD4: 02020604
	v_bfe_u32 v5, v0, 16, 1                                    // 000000296CD8: D6100005 02052100
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000296CE0: BF870194
	v_add_co_ci_u32_e64 v4, null, s5, v4, vcc_lo               // 000000296CE4: D5207C04 01AA0805
	.long 0xd7006a03                                           // 000000296CEC: D7006A03
	v_cndmask_b32_e32 v0, v3, v2, vcc_lo                       // 000000296CF0: 02000503
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000296CF4: BF870193
	v_add3_u32 v0, v0, v5, 0x7fff                              // 000000296CF8: D6550000 03FE0B00 00007FFF
	v_add_co_ci_u32_e64 v4, null, s3, v4, vcc_lo               // 000000296D04: D5207C04 01AA0803
	global_store_d16_hi_b16 v[3:4], v0, off                    // 000000296D0C: DC960000 007C0003
	s_or_b32 exec_lo, exec_lo, s8                              // 000000296D14: 8C7E087E
	s_mov_b32 s3, 0                                            // 000000296D18: BE830080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000296D1C: BF870009
	s_and_b32 vcc_lo, exec_lo, s3                              // 000000296D20: 8B6A037E
	s_cbranch_vccz 559                                         // 000000296D24: BFA3022F <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1ae4>
	s_and_b32 s0, s1, s0                                       // 000000296D28: 8B000001
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000296D2C: BF870009
	s_and_saveexec_b32 s1, s0                                  // 000000296D30: BE812000
	s_cbranch_execz 555                                        // 000000296D34: BFA5022B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1ae4>
	v_ashrrev_i32_e32 v0, 31, v18                              // 000000296D38: 3400249F
	s_clause 0x1                                               // 000000296D3C: BF850001
	s_load_b64 s[4:5], s[16:17], 0x8                           // 000000296D40: F4040108 F8000008
	s_load_b64 s[2:3], s[16:17], 0x38                          // 000000296D48: F4040088 F8000038
	.long 0xd73c0003                                           // 000000296D50: D73C0003
	v_cndmask_b32_e32 v1, 1, v17, vcc_lo                       // 000000296D54: 02022281
	.long 0xd73c0005                                           // 000000296D58: D73C0005
	v_cndmask_b32_e32 v1, 2, v17, vcc_lo                       // 000000296D5C: 02022282
	s_mov_b32 s7, -1                                           // 000000296D60: BE8700C1
	v_lshrrev_b32_e32 v0, 23, v0                               // 000000296D64: 32000097
	s_mov_b32 s1, 0                                            // 000000296D68: BE810080
	s_mov_b32 s6, 0                                            // 000000296D6C: BE860080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000296D70: BF870091
	.long 0xd7006a07                                           // 000000296D74: D7006A07
	v_cndmask_b32_e32 v1, v17, v0, vcc_lo                      // 000000296D78: 02020111
	v_add_co_ci_u32_e64 v0, null, 0, v18, vcc_lo               // 000000296D7C: D5207C00 01AA2480
	.long 0xd7016a03                                           // 000000296D84: D7016A03
	v_cndmask_b32_e32 v1, 0, v3, vcc_lo                        // 000000296D88: 02020680
	s_waitcnt vmcnt(0)                                         // 000000296D8C: BF8903F7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000296D90: BF870123
	v_and_b32_e32 v9, 0xfffffe00, v7                           // 000000296D94: 36120EFF FFFFFE00
	v_sub_co_ci_u32_e64 v4, null, 0, v4, vcc_lo                // 000000296D9C: D5217C04 01AA0880
	.long 0xd7016a07                                           // 000000296DA4: D7016A07
	v_cndmask_b32_e32 v1, v17, v9, vcc_lo                      // 000000296DA8: 02021311
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000296DAC: BF8700B1
	v_sub_co_ci_u32_e64 v8, null, v18, v0, vcc_lo              // 000000296DB0: D5217C08 01AA0112
	s_waitcnt lgkmcnt(0)                                       // 000000296DB8: BF89FC07
	.long 0xd7006a05                                           // 000000296DBC: D7006A05
	v_cndmask_b32_e32 v1, s4, v5, vcc_lo                       // 000000296DC0: 02020A04
	v_add_co_ci_u32_e64 v6, null, s5, v6, vcc_lo               // 000000296DC4: D5207C06 01AA0C05
	.long 0xd7006a0a                                           // 000000296DCC: D7006A0A
	v_cndmask_b32_e32 v1, 0xffffff00, v7, vcc_lo               // 000000296DD0: 02020EFF FFFFFF00
	.long 0xd4540000                                           // 000000296DD8: D4540000
	v_cndmask_b32_e32 v1, 0x100, v7, vcc_lo                    // 000000296DDC: 02020EFF 00000100
	v_add_co_ci_u32_e64 v11, null, -1, v8, vcc_lo              // 000000296DE4: D5207C0B 01AA10C1
	.long 0xd7006a03                                           // 000000296DEC: D7006A03
	v_cndmask_b32_e32 v1, v5, v3, vcc_lo                       // 000000296DF0: 02020705
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000296DF4: BF870191
	v_add_co_ci_u32_e64 v4, null, v6, v4, vcc_lo               // 000000296DF8: D5207C04 01AA0906
	v_cndmask_b32_e64 v8, v11, v8, s0                          // 000000296E00: D5010008 0002110B
	v_cndmask_b32_e64 v7, v10, v7, s0                          // 000000296E08: D5010007 00020F0A
	s_cmp_lt_i32 s3, 3                                         // 000000296E10: BF048303
	s_cbranch_scc1 118                                         // 000000296E14: BFA20076 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x14f0>
	s_cmp_gt_i32 s3, 3                                         // 000000296E18: BF028303
	s_cbranch_scc0 70                                          // 000000296E1C: BFA10046 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1438>
	s_cmp_gt_i32 s3, 4                                         // 000000296E20: BF028403
	s_cbranch_scc0 34                                          // 000000296E24: BFA10022 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x13b0>
	s_cmp_eq_u32 s3, 5                                         // 000000296E28: BF068503
	s_mov_b32 s6, -1                                           // 000000296E2C: BE8600C1
	s_cbranch_scc0 30                                          // 000000296E30: BFA1001E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x13ac>
	s_load_b64 s[6:7], s[16:17], 0x10                          // 000000296E34: F4040188 F8000010
	v_dual_mov_b32 v10, s4 :: v_dual_mov_b32 v11, s5           // 000000296E3C: CA100004 0A0A0005
	v_bfe_u32 v13, v1, 16, 1                                   // 000000296E44: D610000D 02052101
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000296E4C: BF8701A1
	v_add3_u32 v13, v1, v13, 0x7fff                            // 000000296E50: D655000D 03FE1B01 00007FFF
	s_waitcnt lgkmcnt(0)                                       // 000000296E5C: BF89FC07
	v_cndmask_b32_e64 v12, s6, v10, s0                         // 000000296E60: D501000C 00021406
	v_cndmask_b32_e64 v14, s7, v11, s0                         // 000000296E68: D501000E 00021607
	.long 0xd73c000a                                           // 000000296E70: D73C000A
	v_cndmask_b32_e32 v1, 1, v7, vcc_lo                        // 000000296E74: 02020E81
	s_mov_b32 s6, 0                                            // 000000296E78: BE860080
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000296E7C: BF870093
	.long 0xd7006a0c                                           // 000000296E80: D7006A0C
	v_cndmask_b32_e32 v1, v12, v9, vcc_lo                      // 000000296E84: 0202130C
	v_add_co_ci_u32_e64 v14, null, v14, v0, vcc_lo             // 000000296E88: D5207C0E 01AA010E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000296E90: BF870092
	.long 0xd7006a0a                                           // 000000296E94: D7006A0A
	v_cndmask_b32_e32 v1, v12, v10, vcc_lo                     // 000000296E98: 0202150C
	v_add_co_ci_u32_e64 v11, null, v14, v11, vcc_lo            // 000000296E9C: D5207C0B 01AA170E
	global_store_d16_hi_b16 v[10:11], v13, off                 // 000000296EA4: DC960000 007C0D0A
	s_mov_b32 s7, 0                                            // 000000296EAC: BE870080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000296EB0: BF870009
	s_and_b32 vcc_lo, exec_lo, s7                              // 000000296EB4: 8B6A077E
	s_cbranch_vccz 30                                          // 000000296EB8: BFA3001E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1434>
	v_mul_f32_e32 v10, 0xbfb8aa3b, v1                          // 000000296EBC: 101402FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000296EC4: BF870291
	v_exp_f32_e32 v10, v10                                     // 000000296EC8: 7E144B0A
	v_add_f32_e32 v10, 1.0, v10                                // 000000296ECC: 061414F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000296ED0: BF870091
	v_div_scale_f32 v11, null, v10, v10, 1.0                   // 000000296ED4: D6FC7C0B 03CA150A
	v_rcp_f32_e32 v12, v11                                     // 000000296EDC: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000296EE0: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 000000296EE4: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 000000296EEC: 5618190D
	v_div_scale_f32 v13, vcc_lo, 1.0, v10, 1.0                 // 000000296EF0: D6FC6A0D 03CA14F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000296EF8: BF870091
	v_mul_f32_e32 v14, v13, v12                                // 000000296EFC: 101C190D
	v_fma_f32 v15, -v11, v14, v13                              // 000000296F00: D613000F 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000296F08: BF870091
	v_fmac_f32_e32 v14, v15, v12                               // 000000296F0C: 561C190F
	v_fma_f32 v11, -v11, v14, v13                              // 000000296F10: D613000B 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000296F18: BF870091
	v_div_fmas_f32 v11, v11, v12, v14                          // 000000296F1C: D637000B 043A190B
	v_div_fixup_f32 v10, v11, v10, 1.0                         // 000000296F24: D627000A 03CA150B
	global_store_b32 v[5:6], v10, off                          // 000000296F2C: DC6A0000 007C0A05
	s_mov_b32 s7, 0                                            // 000000296F34: BE870080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000296F38: BF870009
	s_and_b32 vcc_lo, exec_lo, s7                              // 000000296F3C: 8B6A077E
	s_cbranch_vccz 42                                          // 000000296F40: BFA3002A <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x14ec>
	v_bfe_u32 v10, v1, 16, 1                                   // 000000296F44: D610000A 02052101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000296F4C: BF870091
	v_add3_u32 v10, v1, v10, 0x7fff                            // 000000296F50: D655000A 03FE1501 00007FFF
	v_and_b32_e32 v10, 0xffff0000, v10                         // 000000296F5C: 361414FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000296F64: BF870091
	v_mul_f32_e32 v10, s2, v10                                 // 000000296F68: 10141402
	v_mul_f32_e32 v10, 0xbfb8aa3b, v10                         // 000000296F6C: 101414FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000296F74: BF870291
	v_exp_f32_e32 v10, v10                                     // 000000296F78: 7E144B0A
	v_add_f32_e32 v10, 1.0, v10                                // 000000296F7C: 061414F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000296F80: BF870091
	v_div_scale_f32 v11, null, v10, v10, 1.0                   // 000000296F84: D6FC7C0B 03CA150A
	v_rcp_f32_e32 v12, v11                                     // 000000296F8C: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000296F90: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 000000296F94: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 000000296F9C: 5618190D
	v_div_scale_f32 v13, vcc_lo, 1.0, v10, 1.0                 // 000000296FA0: D6FC6A0D 03CA14F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000296FA8: BF870091
	v_mul_f32_e32 v14, v13, v12                                // 000000296FAC: 101C190D
	v_fma_f32 v15, -v11, v14, v13                              // 000000296FB0: D613000F 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000296FB8: BF870091
	v_fmac_f32_e32 v14, v15, v12                               // 000000296FBC: 561C190F
	v_fma_f32 v11, -v11, v14, v13                              // 000000296FC0: D613000B 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000296FC8: BF870091
	v_div_fmas_f32 v11, v11, v12, v14                          // 000000296FCC: D637000B 043A190B
	v_div_fixup_f32 v10, v11, v10, 1.0                         // 000000296FD4: D627000A 03CA150B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000296FDC: BF870001
	v_add_f32_e32 v10, v10, v10                                // 000000296FE0: 0614150A
	global_store_b32 v[5:6], v10, off                          // 000000296FE4: DC6A0000 007C0A05
	s_mov_b32 s7, 0                                            // 000000296FEC: BE870080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000296FF0: BF870009
	s_and_b32 vcc_lo, exec_lo, s7                              // 000000296FF4: 8B6A077E
	s_cbranch_vccz 55                                          // 000000296FF8: BFA30037 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x15d8>
	s_cmp_gt_i32 s3, 1                                         // 000000296FFC: BF028103
	s_mov_b32 s1, -1                                           // 000000297000: BE8100C1
	s_cbranch_scc0 46                                          // 000000297004: BFA1002E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x15c0>
	v_bfe_u32 v10, v1, 16, 1                                   // 000000297008: D610000A 02052101
	s_mov_b32 s1, 0                                            // 000000297010: BE810080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000297014: BF870091
	v_add3_u32 v10, v1, v10, 0x7fff                            // 000000297018: D655000A 03FE1501 00007FFF
	v_and_b32_e32 v10, 0xffff0000, v10                         // 000000297024: 361414FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029702C: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v10                         // 000000297030: 101414FF BFB8AA3B
	v_exp_f32_e32 v10, v10                                     // 000000297038: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029703C: BF870095
	v_add_f32_e32 v10, 1.0, v10                                // 000000297040: 061414F2
	v_div_scale_f32 v11, null, v10, v10, 1.0                   // 000000297044: D6FC7C0B 03CA150A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000029704C: BF870291
	v_rcp_f32_e32 v12, v11                                     // 000000297050: 7E18550B
	v_fma_f32 v13, -v11, v12, 1.0                              // 000000297054: D613000D 23CA190B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000029705C: BF8700A1
	v_fmac_f32_e32 v12, v13, v12                               // 000000297060: 5618190D
	v_div_scale_f32 v13, vcc_lo, 1.0, v10, 1.0                 // 000000297064: D6FC6A0D 03CA14F2
	v_mul_f32_e32 v14, v13, v12                                // 00000029706C: 101C190D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000297070: BF870091
	v_fma_f32 v15, -v11, v14, v13                              // 000000297074: D613000F 24361D0B
	v_fmac_f32_e32 v14, v15, v12                               // 00000029707C: 561C190F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000297080: BF870091
	v_fma_f32 v11, -v11, v14, v13                              // 000000297084: D613000B 24361D0B
	v_div_fmas_f32 v11, v11, v12, v14                          // 00000029708C: D637000B 043A190B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000297094: BF870091
	v_div_fixup_f32 v10, v11, v10, 1.0                         // 000000297098: D627000A 03CA150B
	v_bfe_u32 v11, v10, 16, 1                                  // 0000002970A0: D610000B 0205210A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002970A8: BF870001
	v_add3_u32 v10, v10, v11, 0x7fff                           // 0000002970AC: D655000A 03FE170A 00007FFF
	global_store_d16_hi_b16 v[3:4], v10, off                   // 0000002970B8: DC960000 007C0A03
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002970C0: 916A017E
	s_mov_b32 s1, 0                                            // 0000002970C4: BE810080
	s_cbranch_vccnz 3                                          // 0000002970C8: BFA40003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x15d8>
	s_cmp_lg_u32 s3, 1                                         // 0000002970CC: BF078103
	s_mov_b32 s1, -1                                           // 0000002970D0: BE8100C1
	s_cselect_b32 s6, -1, 0                                    // 0000002970D4: 980680C1
	v_bfe_u32 v10, v1, 16, 1                                   // 0000002970D8: D610000A 02052101
	s_and_b32 vcc_lo, exec_lo, s6                              // 0000002970E0: 8B6A067E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002970E4: BF870001
	v_add3_u32 v1, v1, v10, 0x7fff                             // 0000002970E8: D6550001 03FE1501 00007FFF
	s_cbranch_vccz 3                                           // 0000002970F4: BFA30003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1604>
	s_mov_b32 s1, 0                                            // 0000002970F8: BE810080
	global_store_d16_hi_b16 v[3:4], v1, off                    // 0000002970FC: DC960000 007C0103
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 000000297104: 916A017E
	s_cbranch_vccnz 41                                         // 000000297108: BFA40029 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x16b0>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029710C: BF870091
	v_and_b32_e32 v1, 0xffff0000, v1                           // 000000297110: 360202FF FFFF0000
	v_mul_f32_e32 v1, s2, v1                                   // 000000297118: 10020202
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029711C: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v1                          // 000000297120: 101402FF BFB8AA3B
	v_exp_f32_e32 v10, v10                                     // 000000297128: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029712C: BF870095
	v_add_f32_e32 v10, 1.0, v10                                // 000000297130: 061414F2
	v_div_scale_f32 v11, null, v10, v10, v1                    // 000000297134: D6FC7C0B 0406150A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000029713C: BF870291
	v_rcp_f32_e32 v12, v11                                     // 000000297140: 7E18550B
	v_fma_f32 v13, -v11, v12, 1.0                              // 000000297144: D613000D 23CA190B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000029714C: BF8700A1
	v_fmac_f32_e32 v12, v13, v12                               // 000000297150: 5618190D
	v_div_scale_f32 v13, vcc_lo, v1, v10, v1                   // 000000297154: D6FC6A0D 04061501
	v_mul_f32_e32 v14, v13, v12                                // 00000029715C: 101C190D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000297160: BF870091
	v_fma_f32 v15, -v11, v14, v13                              // 000000297164: D613000F 24361D0B
	v_fmac_f32_e32 v14, v15, v12                               // 00000029716C: 561C190F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000297170: BF870091
	v_fma_f32 v11, -v11, v14, v13                              // 000000297174: D613000B 24361D0B
	v_div_fmas_f32 v11, v11, v12, v14                          // 00000029717C: D637000B 043A190B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000297184: BF870091
	v_div_fixup_f32 v1, v11, v10, v1                           // 000000297188: D6270001 0406150B
	v_bfe_u32 v10, v1, 16, 1                                   // 000000297190: D610000A 02052101
	s_delay_alu instid0(VALU_DEP_1)                            // 000000297198: BF870001
	v_add3_u32 v1, v1, v10, 0x7fff                             // 00000029719C: D6550001 03FE1501 00007FFF
	global_store_d16_hi_b16 v[3:4], v1, off                    // 0000002971A8: DC960000 007C0103
	s_mov_b32 s7, -1                                           // 0000002971B0: BE8700C1
	s_mov_b32 s1, 0                                            // 0000002971B4: BE810080
	s_cmp_lt_i32 s3, 3                                         // 0000002971B8: BF048303
	s_mov_b32 s6, 0                                            // 0000002971BC: BE860080
	s_cbranch_scc1 136                                         // 0000002971C0: BFA20088 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x18e4>
	s_cmp_gt_i32 s3, 3                                         // 0000002971C4: BF028303
	s_cbranch_scc0 43                                          // 0000002971C8: BFA1002B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1778>
	s_cmp_gt_i32 s3, 4                                         // 0000002971CC: BF028403
	s_cbranch_scc0 43                                          // 0000002971D0: BFA1002B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1780>
	s_cmp_eq_u32 s3, 5                                         // 0000002971D4: BF068503
	s_mov_b32 s6, -1                                           // 0000002971D8: BE8600C1
	s_cbranch_scc0 36                                          // 0000002971DC: BFA10024 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1770>
	s_load_b64 s[6:7], s[16:17], 0x10                          // 0000002971E0: F4040188 F8000010
	v_dual_mov_b32 v1, s4 :: v_dual_mov_b32 v10, s5            // 0000002971E8: CA100004 010A0005
	.long 0xd73c0007                                           // 0000002971F0: D73C0007
	v_cndmask_b32_e32 v1, 1, v7, vcc_lo                        // 0000002971F4: 02020E81
	v_bfe_u32 v11, v2, 16, 1                                   // 0000002971F8: D610000B 02052102
	s_waitcnt lgkmcnt(0)                                       // 000000297200: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000297204: BF870143
	v_cndmask_b32_e64 v1, s6, v1, s0                           // 000000297208: D5010001 00020206
	v_cndmask_b32_e64 v10, s7, v10, s0                         // 000000297210: D501000A 00021407
	s_and_b32 s0, s10, -2                                      // 000000297218: 8B00C20A
	s_mov_b32 s6, 0                                            // 00000029721C: BE860080
	.long 0xd7006a01                                           // 000000297220: D7006A01
	v_cndmask_b32_e32 v0, v1, v0, vcc_lo                       // 000000297224: 02000101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000297228: BF870111
	v_add_co_ci_u32_e64 v10, null, s11, v10, vcc_lo            // 00000029722C: D5207C0A 01AA140B
	.long 0xd7006a01                                           // 000000297234: D7006A01
	v_cndmask_b32_e32 v1, v1, v9, vcc_lo                       // 000000297238: 02021301
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000029723C: BF8701A1
	v_add_co_ci_u32_e64 v9, null, v10, v0, vcc_lo              // 000000297240: D5207C09 01AA010A
	v_add3_u32 v10, v2, v11, 0x7fff                            // 000000297248: D655000A 03FE1702 00007FFF
	.long 0xd7006a00                                           // 000000297254: D7006A00
	v_cndmask_b32_e32 v1, v1, v7, vcc_lo                       // 000000297258: 02020F01
	s_delay_alu instid0(VALU_DEP_1)                            // 00000029725C: BF870001
	v_add_co_ci_u32_e64 v1, null, v9, v8, vcc_lo               // 000000297260: D5207C01 01AA1109
	global_store_d16_hi_b16 v[0:1], v10, off                   // 000000297268: DC960000 007C0A00
	s_mov_b32 s0, 0                                            // 000000297270: BE800080
	s_branch 3                                                 // 000000297274: BFA00003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1784>
	s_cbranch_execnz 42                                        // 000000297278: BFA6002A <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1824>
	s_branch 88                                                // 00000029727C: BFA00058 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x18e0>
	s_mov_b32 s0, -1                                           // 000000297280: BE8000C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000297284: BF870009
	s_and_b32 vcc_lo, exec_lo, s0                              // 000000297288: 8B6A007E
	s_cbranch_vccz 36                                          // 00000029728C: BFA30024 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1820>
	v_mul_f32_e32 v0, 0xbfb8aa3b, v2                           // 000000297290: 100004FF BFB8AA3B
	s_lshl_b64 s[4:5], s[10:11], 2                             // 000000297298: 8484820A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000029729C: BF870291
	v_exp_f32_e32 v0, v0                                       // 0000002972A0: 7E004B00
	v_add_f32_e32 v0, 1.0, v0                                  // 0000002972A4: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002972A8: BF870121
	v_div_scale_f32 v1, null, v0, v0, 1.0                      // 0000002972AC: D6FC7C01 03CA0100
	v_div_scale_f32 v9, vcc_lo, 1.0, v0, 1.0                   // 0000002972B4: D6FC6A09 03CA00F2
	v_rcp_f32_e32 v7, v1                                       // 0000002972BC: 7E0E5501
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002972C0: BF870095
	v_fma_f32 v8, -v1, v7, 1.0                                 // 0000002972C4: D6130008 23CA0F01
	v_fmac_f32_e32 v7, v8, v7                                  // 0000002972CC: 560E0F08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002972D0: BF870091
	v_mul_f32_e32 v8, v9, v7                                   // 0000002972D4: 10100F09
	v_fma_f32 v10, -v1, v8, v9                                 // 0000002972D8: D613000A 24261101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002972E0: BF870091
	v_fmac_f32_e32 v8, v10, v7                                 // 0000002972E4: 56100F0A
	v_fma_f32 v1, -v1, v8, v9                                  // 0000002972E8: D6130001 24261101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002972F0: BF870091
	v_div_fmas_f32 v1, v1, v7, v8                              // 0000002972F4: D6370001 04220F01
	v_div_fixup_f32 v7, v1, v0, 1.0                            // 0000002972FC: D6270007 03CA0101
	.long 0xd7006a00                                           // 000000297304: D7006A00
	v_cndmask_b32_e32 v0, v5, v4, vcc_lo                       // 000000297308: 02000905
	s_delay_alu instid0(VALU_DEP_1)                            // 00000029730C: BF870001
	v_add_co_ci_u32_e64 v1, null, s5, v6, vcc_lo               // 000000297310: D5207C01 01AA0C05
	global_store_b32 v[0:1], v7, off                           // 000000297318: DC6A0000 007C0700
	s_branch 47                                                // 000000297320: BFA0002F <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x18e0>
	v_bfe_u32 v0, v2, 16, 1                                    // 000000297324: D6100000 02052102
	s_lshl_b64 s[4:5], s[10:11], 2                             // 00000029732C: 8484820A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000297330: BF870091
	v_add3_u32 v0, v2, v0, 0x7fff                              // 000000297334: D6550000 03FE0102 00007FFF
	v_and_b32_e32 v0, 0xffff0000, v0                           // 000000297340: 360000FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000297348: BF870091
	v_mul_f32_e32 v0, s2, v0                                   // 00000029734C: 10000002
	v_mul_f32_e32 v0, 0xbfb8aa3b, v0                           // 000000297350: 100000FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000297358: BF870291
	v_exp_f32_e32 v0, v0                                       // 00000029735C: 7E004B00
	v_add_f32_e32 v0, 1.0, v0                                  // 000000297360: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000297364: BF870121
	v_div_scale_f32 v1, null, v0, v0, 1.0                      // 000000297368: D6FC7C01 03CA0100
	v_div_scale_f32 v9, vcc_lo, 1.0, v0, 1.0                   // 000000297370: D6FC6A09 03CA00F2
	v_rcp_f32_e32 v7, v1                                       // 000000297378: 7E0E5501
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029737C: BF870095
	v_fma_f32 v8, -v1, v7, 1.0                                 // 000000297380: D6130008 23CA0F01
	v_fmac_f32_e32 v7, v8, v7                                  // 000000297388: 560E0F08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029738C: BF870091
	v_mul_f32_e32 v8, v9, v7                                   // 000000297390: 10100F09
	v_fma_f32 v10, -v1, v8, v9                                 // 000000297394: D613000A 24261101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000029739C: BF870091
	v_fmac_f32_e32 v8, v10, v7                                 // 0000002973A0: 56100F0A
	v_fma_f32 v1, -v1, v8, v9                                  // 0000002973A4: D6130001 24261101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002973AC: BF870091
	v_div_fmas_f32 v1, v1, v7, v8                              // 0000002973B0: D6370001 04220F01
	v_div_fixup_f32 v0, v1, v0, 1.0                            // 0000002973B8: D6270000 03CA0101
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002973C0: BF8700A1
	v_add_f32_e32 v7, v0, v0                                   // 0000002973C4: 060E0100
	.long 0xd7006a00                                           // 0000002973C8: D7006A00
	v_cndmask_b32_e32 v0, v5, v4, vcc_lo                       // 0000002973CC: 02000905
	v_add_co_ci_u32_e64 v1, null, s5, v6, vcc_lo               // 0000002973D0: D5207C01 01AA0C05
	global_store_b32 v[0:1], v7, off                           // 0000002973D8: DC6A0000 007C0700
	s_mov_b32 s7, 0                                            // 0000002973E0: BE870080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002973E4: BF870009
	s_and_b32 vcc_lo, exec_lo, s7                              // 0000002973E8: 8B6A077E
	s_cbranch_vccz 60                                          // 0000002973EC: BFA3003C <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x19e0>
	s_cmp_gt_i32 s3, 1                                         // 0000002973F0: BF028103
	s_mov_b32 s0, -1                                           // 0000002973F4: BE8000C1
	s_cbranch_scc0 51                                          // 0000002973F8: BFA10033 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x19c8>
	v_bfe_u32 v0, v2, 16, 1                                    // 0000002973FC: D6100000 02052102
	s_lshl_b64 s[0:1], s[10:11], 1                             // 000000297404: 8480810A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000297408: BF870091
	v_add3_u32 v0, v2, v0, 0x7fff                              // 00000029740C: D6550000 03FE0102 00007FFF
	v_and_b32_e32 v0, 0xffff0000, v0                           // 000000297418: 360000FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000297420: BF870091
	v_mul_f32_e32 v0, 0xbfb8aa3b, v0                           // 000000297424: 100000FF BFB8AA3B
	v_exp_f32_e32 v0, v0                                       // 00000029742C: 7E004B00
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000297430: BF870095
	v_add_f32_e32 v0, 1.0, v0                                  // 000000297434: 060000F2
	v_div_scale_f32 v1, null, v0, v0, 1.0                      // 000000297438: D6FC7C01 03CA0100
	v_div_scale_f32 v7, vcc_lo, 1.0, v0, 1.0                   // 000000297440: D6FC6A07 03CA00F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000297448: BF870292
	v_rcp_f32_e32 v5, v1                                       // 00000029744C: 7E0A5501
	v_fma_f32 v6, -v1, v5, 1.0                                 // 000000297450: D6130006 23CA0B01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000297458: BF870091
	v_fmac_f32_e32 v5, v6, v5                                  // 00000029745C: 560A0B06
	v_mul_f32_e32 v6, v7, v5                                   // 000000297460: 100C0B07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000297464: BF870091
	v_fma_f32 v8, -v1, v6, v7                                  // 000000297468: D6130008 241E0D01
	v_fmac_f32_e32 v6, v8, v5                                  // 000000297470: 560C0B08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000297474: BF870091
	v_fma_f32 v1, -v1, v6, v7                                  // 000000297478: D6130001 241E0D01
	v_div_fmas_f32 v1, v1, v5, v6                              // 000000297480: D6370001 041A0B01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000297488: BF870091
	v_div_fixup_f32 v0, v1, v0, 1.0                            // 00000029748C: D6270000 03CA0101
	v_bfe_u32 v1, v0, 16, 1                                    // 000000297494: D6100001 02052100
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000029749C: BF8700A1
	v_add3_u32 v5, v0, v1, 0x7fff                              // 0000002974A0: D6550005 03FE0300 00007FFF
	.long 0xd7006a00                                           // 0000002974AC: D7006A00
	v_cndmask_b32_e32 v0, v3, v0, vcc_lo                       // 0000002974B0: 02000103
	v_add_co_ci_u32_e64 v1, null, s1, v4, vcc_lo               // 0000002974B4: D5207C01 01AA0801
	s_mov_b32 s0, 0                                            // 0000002974BC: BE800080
	global_store_d16_hi_b16 v[0:1], v5, off                    // 0000002974C0: DC960000 007C0500
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 0000002974C8: 916A007E
	s_mov_b32 s1, 0                                            // 0000002974CC: BE810080
	s_cbranch_vccnz 3                                          // 0000002974D0: BFA40003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x19e0>
	s_cmp_lg_u32 s3, 1                                         // 0000002974D4: BF078103
	s_mov_b32 s1, -1                                           // 0000002974D8: BE8100C1
	s_cselect_b32 s6, -1, 0                                    // 0000002974DC: 980680C1
	v_bfe_u32 v0, v2, 16, 1                                    // 0000002974E0: D6100000 02052102
	s_and_b32 vcc_lo, exec_lo, s6                              // 0000002974E8: 8B6A067E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002974EC: BF870001
	v_add3_u32 v0, v2, v0, 0x7fff                              // 0000002974F0: D6550000 03FE0102 00007FFF
	s_cbranch_vccz 9                                           // 0000002974FC: BFA30009 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1a24>
	s_lshl_b64 s[0:1], s[10:11], 1                             // 000000297500: 8480810A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000297504: BF870099
	.long 0xd7006a01                                           // 000000297508: D7006A01
	v_cndmask_b32_e32 v0, v3, v0, vcc_lo                       // 00000029750C: 02000103
	v_add_co_ci_u32_e64 v2, null, s1, v4, vcc_lo               // 000000297510: D5207C02 01AA0801
	s_mov_b32 s1, 0                                            // 000000297518: BE810080
	global_store_d16_hi_b16 v[1:2], v0, off                    // 00000029751C: DC960000 007C0001
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 000000297524: 916A017E
	s_cbranch_vccnz 46                                         // 000000297528: BFA4002E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi2ELi16ELi1ELi1EEEvNS0_5LqGrpEPKtl+0x1ae4>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000029752C: BF8700A1
	v_and_b32_e32 v0, 0xffff0000, v0                           // 000000297530: 360000FF FFFF0000
	s_lshl_b64 s[0:1], s[10:11], 1                             // 000000297538: 8480810A
	v_mul_f32_e32 v0, s2, v0                                   // 00000029753C: 10000002
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000297540: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 000000297544: 100200FF BFB8AA3B
	v_exp_f32_e32 v1, v1                                       // 00000029754C: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000297550: BF870095
	v_add_f32_e32 v1, 1.0, v1                                  // 000000297554: 060202F2
	v_div_scale_f32 v2, null, v1, v1, v0                       // 000000297558: D6FC7C02 04020301
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000297560: BF870291
	v_rcp_f32_e32 v5, v2                                       // 000000297564: 7E0A5502
	v_fma_f32 v6, -v2, v5, 1.0                                 // 000000297568: D6130006 23CA0B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000297570: BF8700A1
	v_fmac_f32_e32 v5, v6, v5                                  // 000000297574: 560A0B06
	v_div_scale_f32 v7, vcc_lo, v0, v1, v0                     // 000000297578: D6FC6A07 04020300
	v_mul_f32_e32 v6, v7, v5                                   // 000000297580: 100C0B07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000297584: BF870091
	v_fma_f32 v8, -v2, v6, v7                                  // 000000297588: D6130008 241E0D02
	v_fmac_f32_e32 v6, v8, v5                                  // 000000297590: 560C0B08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000297594: BF870091
	v_fma_f32 v2, -v2, v6, v7                                  // 000000297598: D6130002 241E0D02
	v_div_fmas_f32 v2, v2, v5, v6                              // 0000002975A0: D6370002 041A0B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002975A8: BF870091
	v_div_fixup_f32 v0, v2, v1, v0                             // 0000002975AC: D6270000 04020302
	v_bfe_u32 v1, v0, 16, 1                                    // 0000002975B4: D6100001 02052100
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002975BC: BF8700A1
	v_add3_u32 v2, v0, v1, 0x7fff                              // 0000002975C0: D6550002 03FE0300 00007FFF
	.long 0xd7006a00                                           // 0000002975CC: D7006A00
	v_cndmask_b32_e32 v0, v3, v0, vcc_lo                       // 0000002975D0: 02000103
	v_add_co_ci_u32_e64 v1, null, s1, v4, vcc_lo               // 0000002975D4: D5207C01 01AA0801
	global_store_d16_hi_b16 v[0:1], v2, off                    // 0000002975DC: DC960000 007C0200
	s_endpgm                                                   // 0000002975E4: BFB00000
		...

