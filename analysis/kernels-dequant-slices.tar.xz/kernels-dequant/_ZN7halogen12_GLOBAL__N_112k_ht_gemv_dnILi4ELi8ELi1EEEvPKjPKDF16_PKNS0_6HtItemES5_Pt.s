0000000000a84e00 <_ZN7halogen12_GLOBAL__N_112k_ht_gemv_dnILi4ELi8ELi1EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt>:
; _ZN7halogen12_GLOBAL__N_112k_ht_gemv_dnILi4ELi8ELi1EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt():
	s_load_b256 s[4:11], s[0:1], null                          // 000000A84E00: F40C0100 F8000000
	s_mov_b32 s3, 0                                            // 000000A84E08: BE830080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A84E0C: BF870009
	s_lshl_b64 s[2:3], s[2:3], 4                               // 000000A84E10: 84828402
	s_waitcnt lgkmcnt(0)                                       // 000000A84E14: BF89FC07
	s_add_u32 s2, s8, s2                                       // 000000A84E18: 80020208
	s_addc_u32 s3, s9, s3                                      // 000000A84E1C: 82030309
	s_load_b64 s[8:9], s[0:1], 0x20                            // 000000A84E20: F4040200 F8000020
	s_load_b128 s[12:15], s[2:3], null                         // 000000A84E28: F4080301 F8000000
	s_mov_b32 s0, exec_lo                                      // 000000A84E30: BE80007E
	v_cmpx_gt_u32_e32 0x50, v0                                 // 000000A84E34: 7D9800FF 00000050
	s_cbranch_execz 16                                         // 000000A84E3C: BFA50010 <_ZN7halogen12_GLOBAL__N_112k_ht_gemv_dnILi4ELi8ELi1EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x80>
	s_waitcnt lgkmcnt(0)                                       // 000000A84E40: BF89FC07
	s_add_i32 s1, s15, -1                                      // 000000A84E44: 8101C10F
	v_lshlrev_b32_e32 v5, 4, v0                                // 000000A84E48: 300A0084
	s_min_i32 s1, s14, s1                                      // 000000A84E4C: 8901010E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A84E50: BF870009
	s_mul_i32 s2, s1, 0x500                                    // 000000A84E54: 9602FF01 00000500
	s_mul_hi_i32 s1, s1, 0x500                                 // 000000A84E5C: 9701FF01 00000500
	s_add_u32 s2, s6, s2                                       // 000000A84E64: 80020206
	s_addc_u32 s3, s7, s1                                      // 000000A84E68: 82030107
	global_load_b128 v[1:4], v5, s[2:3]                        // 000000A84E6C: DC5E0000 01020005
	s_waitcnt vmcnt(0)                                         // 000000A84E74: BF8903F7
	ds_store_b128 v5, v[1:4]                                   // 000000A84E78: DB7C0000 00000105
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A84E80: 8C7E007E
	v_lshrrev_b32_e32 v7, 5, v0                                // 000000A84E84: 320E0085
	v_dual_mov_b32 v11, 0 :: v_dual_and_b32 v8, 31, v0         // 000000A84E88: CA240080 0B08009F
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v13, 0             // 000000A84E90: CA100080 0C0C0080
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A84E98: BF8701B3
	v_mul_u32_u24_e32 v1, 5, v7                                // 000000A84E9C: 16020E85
	v_dual_mov_b32 v14, 0 :: v_dual_mov_b32 v17, 0             // 000000A84EA0: CA100080 0E100080
	v_dual_mov_b32 v16, 0 :: v_dual_mov_b32 v19, 0             // 000000A84EA8: CA100080 10120080
	v_min_u32_e32 v2, 35, v1                                   // 000000A84EB0: 260402A3
	v_dual_mov_b32 v18, 0 :: v_dual_lshlrev_b32 v9, 2, v8      // 000000A84EB4: CA220080 12081082
	v_mov_b32_e32 v20, 0                                       // 000000A84EBC: 7E280280
	s_waitcnt lgkmcnt(0)                                       // 000000A84EC0: BF89FC07
	s_mul_hi_i32 s2, s12, 0xc8000                              // 000000A84EC4: 9702FF0C 000C8000
	v_add_nc_u32_e32 v10, 5, v2                                // 000000A84ECC: 4A140485
	s_mul_i32 s6, s12, 0xc8000                                 // 000000A84ED0: 9606FF0C 000C8000
	s_mul_hi_i32 s3, s13, 0xa000                               // 000000A84ED8: 9703FF0D 0000A000
	s_mul_i32 s7, s13, 0xa000                                  // 000000A84EE0: 9607FF0D 0000A000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A84EE8: BF870001
	v_cmp_lt_u32_e32 vcc_lo, v1, v10                           // 000000A84EEC: 7C921501
	s_barrier                                                  // 000000A84EF0: BFBD0000
	buffer_gl0_inv                                             // 000000A84EF4: E0AC0000 00000000
	s_and_saveexec_b32 s1, vcc_lo                              // 000000A84EFC: BE81206A
	s_cbranch_execz 33                                         // 000000A84F00: BFA50021 <_ZN7halogen12_GLOBAL__N_112k_ht_gemv_dnILi4ELi8ELi1EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x188>
	v_mul_u32_u24_e32 v3, 0x1400, v7                           // 000000A84F04: 16060EFF 00001400
	s_add_u32 s0, s4, s6                                       // 000000A84F0C: 80000604
	s_addc_u32 s16, s5, s2                                     // 000000A84F10: 82100205
	s_add_u32 s0, s0, s7                                       // 000000A84F14: 80000700
	s_addc_u32 s16, s16, s3                                    // 000000A84F18: 82100310
	.long 0xd7000003                                           // 000000A84F1C: D7000003
	v_cndmask_b32_e32 v1, s0, v3, vcc_lo                       // 000000A84F20: 02020600
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A84F24: BF870111
	v_add_co_ci_u32_e64 v4, null, s16, 0, s0                   // 000000A84F28: D5207C04 00010010
	.long 0xd7000003                                           // 000000A84F30: D7000003
	v_cndmask_b32_e32 v1, v3, v9, vcc_lo                       // 000000A84F34: 02021303
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A84F38: BF870001
	v_add_co_ci_u32_e64 v4, null, 0, v4, s0                    // 000000A84F3C: D5207C04 00020880
	s_clause 0x7                                               // 000000A84F44: BF850007
	global_load_b32 v12, v[3:4], off                           // 000000A84F48: DC520000 0C7C0003
	global_load_b32 v13, v[3:4], off offset:128                // 000000A84F50: DC520080 0D7C0003
	global_load_b32 v14, v[3:4], off offset:256                // 000000A84F58: DC520100 0E7C0003
	global_load_b32 v16, v[3:4], off offset:384                // 000000A84F60: DC520180 107C0003
	global_load_b32 v17, v[3:4], off offset:512                // 000000A84F68: DC520200 117C0003
	global_load_b32 v18, v[3:4], off offset:640                // 000000A84F70: DC520280 127C0003
	global_load_b32 v19, v[3:4], off offset:768                // 000000A84F78: DC520300 137C0003
	global_load_b32 v20, v[3:4], off offset:896                // 000000A84F80: DC520380 147C0003
	s_or_b32 exec_lo, exec_lo, s1                              // 000000A84F88: 8C7E017E
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v22, 0             // 000000A84F8C: CA100080 15160080
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v24, 0             // 000000A84F94: CA100080 17180080
	v_dual_mov_b32 v25, 0 :: v_dual_mov_b32 v26, 0             // 000000A84F9C: CA100080 191A0080
	v_mov_b32_e32 v15, 0                                       // 000000A84FA4: 7E1E0280
	s_and_saveexec_b32 s1, vcc_lo                              // 000000A84FA8: BE81206A
	s_cbranch_execz 985                                        // 000000A84FAC: BFA503D9 <_ZN7halogen12_GLOBAL__N_112k_ht_gemv_dnILi4ELi8ELi1EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x1114>
	v_cmp_ne_u32_e32 vcc_lo, 0, v8                             // 000000A84FB0: 7C9A1080
	v_lshlrev_b32_e32 v3, 5, v8                                // 000000A84FB4: 30061085
	v_dual_mov_b32 v26, 0 :: v_dual_and_b32 v21, 16, v0        // 000000A84FB8: CA240080 1A140090
	v_dual_mov_b32 v25, 0 :: v_dual_lshlrev_b32 v22, 10, v1    // 000000A84FC0: CA220080 1916028A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000A84FC8: BF870143
	v_dual_mov_b32 v15, 0 :: v_dual_add_nc_u32 v4, 0x3f0, v3   // 000000A84FCC: CA200080 0F0406FF 000003F0
	s_add_u32 s0, s6, s7                                       // 000000A84FD8: 80000706
	s_addc_u32 s2, s2, s3                                      // 000000A84FDC: 82020302
	v_lshl_or_b32 v27, v1, 5, v21                              // 000000A84FE0: D656001B 04550B01
	v_lshrrev_b32_e32 v6, 5, v4                                // 000000A84FE8: 320C0885
	.long 0xd7000015                                           // 000000A84FEC: D7000015
	v_cndmask_b32_e32 v1, s0, v22, vcc_lo                      // 000000A84FF0: 02022C00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A84FF4: BF870191
	v_add_co_ci_u32_e64 v22, null, s2, 0, s0                   // 000000A84FF8: D5207C16 00010002
	v_subrev_nc_u32_e32 v6, 32, v6                             // 000000A85000: 4E0C0CA0
	v_and_b32_e32 v4, 0x7e0, v4                                // 000000A85004: 360808FF 000007E0
	v_mul_u32_u24_e32 v5, 0x420, v7                            // 000000A8500C: 160A0EFF 00000420
	v_mad_u32_u24 v11, 0x420, v7, v9                           // 000000A85014: D60B000B 04260EFF 00000420
	v_sub_nc_u32_e32 v29, 0, v2                                // 000000A85020: 4C3A0480
	v_cndmask_b32_e32 v6, 31, v6, vcc_lo                       // 000000A85024: 020C0C9F
	.long 0xd7006a15                                           // 000000A85028: D7006A15
	v_cndmask_b32_e32 v1, v21, v9, vcc_lo                      // 000000A8502C: 02021315
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A85030: BF870191
	v_add_co_ci_u32_e64 v22, null, 0, v22, vcc_lo              // 000000A85034: D5207C16 01AA2C80
	v_dual_mov_b32 v24, 0 :: v_dual_add_nc_u32 v23, 1, v6      // 000000A8503C: CA200080 18160C81
	v_sub_nc_u32_e32 v3, v4, v3                                // 000000A85044: 4C060704
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A85048: BF870194
	.long 0xd7006a15                                           // 000000A8504C: D7006A15
	v_cndmask_b32_e32 v1, s4, v21, vcc_lo                      // 000000A85050: 02022A04
	v_and_b32_e32 v4, 31, v23                                  // 000000A85054: 36082E9F
	v_add_co_ci_u32_e64 v22, null, s5, v22, vcc_lo             // 000000A85058: D5207C16 01AA2C05
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A85060: BF870224
	v_add_nc_u32_e32 v28, 0xfffffc30, v3                       // 000000A85064: 4A3806FF FFFFFC30
	v_lshl_add_u32 v3, v6, 2, v5                               // 000000A8506C: D6460003 04150506
	v_lshl_add_u32 v4, v4, 2, v5                               // 000000A85074: D6460004 04150504
	.long 0xd7006a05                                           // 000000A8507C: D7006A05
	v_cndmask_b32_e32 v1, 0x400, v21, vcc_lo                   // 000000A85080: 02022AFF 00000400
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A85088: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v22, vcc_lo               // 000000A8508C: D5207C06 01AA2C80
	v_add_nc_u32_e32 v30, 1, v1                                // 000000A85094: 4A3C0281
	v_dual_mov_b32 v22, 0 :: v_dual_add_nc_u32 v31, 0x400, v11 // 000000A85098: CA200080 161E16FF 00000400
	v_add_nc_u32_e32 v32, 0x800, v11                           // 000000A850A4: 4A4016FF 00000800
	v_add_nc_u32_e32 v33, 0x400, v3                            // 000000A850AC: 4A4206FF 00000400
	v_add_nc_u32_e32 v34, 0x400, v4                            // 000000A850B4: 4A4408FF 00000400
	v_add_nc_u32_e32 v35, 0x800, v3                            // 000000A850BC: 4A4606FF 00000800
	v_dual_mov_b32 v23, 0 :: v_dual_add_nc_u32 v36, 0x800, v4  // 000000A850C4: CA200080 172408FF 00000800
	v_mov_b32_e32 v21, 0                                       // 000000A850D0: 7E2A0280
	v_mov_b32_e32 v11, 0                                       // 000000A850D4: 7E160280
	s_mov_b32 s2, 0                                            // 000000A850D8: BE820080
	s_movk_i32 s3, 0x1eee                                      // 000000A850DC: B0031EEE
	s_branch 873                                               // 000000A850E0: BFA00369 <_ZN7halogen12_GLOBAL__N_112k_ht_gemv_dnILi4ELi8ELi1EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x1088>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A850E4: 8C7E007E
	ds_load_2addr_b32 v[37:38], v34 offset0:64 offset1:96      // 000000A850E8: D8DC6040 25000022
	ds_load_2addr_b32 v[43:44], v31 offset0:64 offset1:96      // 000000A850F0: D8DC6040 2B00001F
	ds_load_2addr_b32 v[41:42], v33 offset0:64 offset1:96      // 000000A850F8: D8DC6040 29000021
	ds_load_b128 v[1:4], v27                                   // 000000A85100: DBFC0000 0100001B
	.long 0xd7000005                                           // 000000A85108: D7000005
	v_cndmask_b32_e32 v1, 0x400, v5, vcc_lo                    // 000000A8510C: 02020AFF 00000400
	v_add_nc_u32_e32 v27, 32, v27                              // 000000A85114: 4A3636A0
	v_add_co_ci_u32_e64 v6, null, 0, v6, s0                    // 000000A85118: D5207C06 00020C80
	s_waitcnt lgkmcnt(3)                                       // 000000A85120: BF89FC37
	v_mov_b32_e32 v40, v37                                     // 000000A85124: 7E500325
	s_waitcnt lgkmcnt(2)                                       // 000000A85128: BF89FC27
	v_bfe_u32 v37, v43, 12, 16                                 // 000000A8512C: D6100025 0241192B
	v_bfe_u32 v45, v43, 8, 16                                  // 000000A85134: D610002D 0241112B
	v_bfe_u32 v46, v43, 4, 16                                  // 000000A8513C: D610002E 0241092B
	v_and_b32_e32 v43, 0xffff, v43                             // 000000A85144: 365656FF 0000FFFF
	s_waitcnt lgkmcnt(1)                                       // 000000A8514C: BF89FC17
	v_mov_b32_e32 v39, v42                                     // 000000A85150: 7E4E032A
	.long 0xd73d0028                                           // 000000A85154: D73D0028
	v_cndmask_b32_e32 v1, v28, v40, vcc_lo                     // 000000A85158: 0202511C
	v_bfe_u32 v42, v44, 12, 16                                 // 000000A8515C: D610002A 0241192C
	v_bfe_u32 v47, v44, 8, 16                                  // 000000A85164: D610002F 0241112C
	v_bfe_u32 v48, v44, 4, 16                                  // 000000A8516C: D6100030 0241092C
	v_and_b32_e32 v44, 0xffff, v44                             // 000000A85174: 365858FF 0000FFFF
	.long 0xd72c0029                                           // 000000A8517C: D72C0029
	v_cndmask_b32_e32 v1, 0x83dcd12d, v37, vcc_lo              // 000000A85180: 02024AFF 83DCD12D
	.long 0xd73d0025                                           // 000000A85188: D73D0025
	v_cndmask_b32_e32 v1, v28, v38, vcc_lo                     // 000000A8518C: 02024D1C
	v_bfe_u32 v38, v40, 12, 16                                 // 000000A85190: D6100026 02411928
	.long 0xd72c0027                                           // 000000A85198: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 000000A8519C: 020254FF 83DCD12D
	v_bfe_u32 v42, v40, 8, 16                                  // 000000A851A4: D610002A 02411128
	.long 0xd72c002b                                           // 000000A851AC: D72C002B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 000000A851B0: 020256FF 83DCD12D
	.long 0xd72c002e                                           // 000000A851B8: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 000000A851BC: 02025CFF 83DCD12D
	.long 0xd72c0026                                           // 000000A851C4: D72C0026
	v_cndmask_b32_e32 v1, 0x83dcd12d, v38, vcc_lo              // 000000A851C8: 02024CFF 83DCD12D
	v_bfe_u32 v50, v37, 12, 16                                 // 000000A851D0: D6100032 02411925
	.long 0xd72c002a                                           // 000000A851D8: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 000000A851DC: 020254FF 83DCD12D
	v_bfe_u32 v49, v40, 4, 16                                  // 000000A851E4: D6100031 02410928
	.long 0xd72c002d                                           // 000000A851EC: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v45, vcc_lo              // 000000A851F0: 02025AFF 83DCD12D
	v_sad_u8 v41, v41, 0, 0x6400                               // 000000A851F8: D6220029 03FD0129 00006400
	v_sad_u8 v43, v43, 0, 0x6400                               // 000000A85204: D622002B 03FD012B 00006400
	.long 0xd72c0032                                           // 000000A85210: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 000000A85214: 020264FF 83DCD12D
	v_sad_u8 v38, v38, 0, 0x6400                               // 000000A8521C: D6220026 03FD0126 00006400
	v_sad_u8 v46, v46, 0, 0x6400                               // 000000A85228: D622002E 03FD012E 00006400
	v_sad_u8 v42, v42, 0, 0x6400                               // 000000A85234: D622002A 03FD012A 00006400
	v_lshlrev_b32_e32 v43, 16, v43                             // 000000A85240: 30565690
	.long 0xd72c0031                                           // 000000A85244: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 000000A85248: 020262FF 83DCD12D
	v_and_b32_e32 v38, 0xffff, v38                             // 000000A85250: 364C4CFF 0000FFFF
	v_sad_u8 v45, v45, 0, 0x6400                               // 000000A85258: D622002D 03FD012D 00006400
	v_and_b32_e32 v41, 0xffff, v41                             // 000000A85264: 365252FF 0000FFFF
	v_and_or_b32 v46, 0xffff, v46, v43                         // 000000A8526C: D657002E 04AE5CFF 0000FFFF
	v_sad_u8 v43, v50, 0, 0x6400                               // 000000A85278: D622002B 03FD0132 00006400
	v_lshl_or_b32 v38, v42, 16, v38                            // 000000A85284: D6560026 0499212A
	v_bfe_u32 v51, v37, 8, 16                                  // 000000A8528C: D6100033 02411125
	.long 0xd72c002c                                           // 000000A85294: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v44, vcc_lo              // 000000A85298: 020258FF 83DCD12D
	v_lshl_or_b32 v41, v45, 16, v41                            // 000000A852A0: D6560029 04A5212D
	v_sad_u8 v45, v49, 0, 0x6400                               // 000000A852A8: D622002D 03FD0131 00006400
	v_pk_fma_f16 v50, v38, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A852B4: CC0E0032 0BFC0726 0000C931
	v_and_b32_e32 v40, 0xffff, v40                             // 000000A852C0: 365050FF 0000FFFF
	.long 0xd72c0033                                           // 000000A852C8: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 000000A852CC: 020266FF 83DCD12D
	.long 0xd72c0030                                           // 000000A852D4: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 000000A852D8: 020260FF 83DCD12D
	v_bfe_u32 v52, v37, 4, 16                                  // 000000A852E0: D6100034 02410925
	s_waitcnt lgkmcnt(0)                                       // 000000A852E8: BF89FC07
	v_dot2acc_f32_f16 v15, v50, v1                             // 000000A852EC: 041E0332
	.long 0xd72c0028                                           // 000000A852F0: D72C0028
	v_cndmask_b32_e32 v1, 0x83dcd12d, v40, vcc_lo              // 000000A852F4: 020250FF 83DCD12D
	v_sad_u8 v44, v44, 0, 0x6400                               // 000000A852FC: D622002C 03FD012C 00006400
	.long 0xd72c002f                                           // 000000A85308: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 000000A8530C: 02025EFF 83DCD12D
	.long 0xd72c0034                                           // 000000A85314: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 000000A85318: 020268FF 83DCD12D
	v_sad_u8 v49, v51, 0, 0x6400                               // 000000A85320: D6220031 03FD0133 00006400
	v_sad_u8 v48, v48, 0, 0x6400                               // 000000A8532C: D6220030 03FD0130 00006400
	v_sad_u8 v39, v39, 0, 0x6400                               // 000000A85338: D6220027 03FD0127 00006400
	v_sad_u8 v40, v40, 0, 0x6400                               // 000000A85344: D6220028 03FD0128 00006400
	v_sad_u8 v47, v47, 0, 0x6400                               // 000000A85350: D622002F 03FD012F 00006400
	v_sad_u8 v52, v52, 0, 0x6400                               // 000000A8535C: D6220034 03FD0134 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A85368: BF870214
	v_and_b32_e32 v39, 0xffff, v39                             // 000000A8536C: 364E4EFF 0000FFFF
	v_lshlrev_b32_e32 v40, 16, v40                             // 000000A85374: 30505090
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A85378: BF870112
	v_lshl_or_b32 v47, v47, 16, v39                            // 000000A8537C: D656002F 049D212F
	v_and_or_b32 v40, 0xffff, v45, v40                         // 000000A85384: D6570028 04A25AFF 0000FFFF
	v_pk_fma_f16 v45, v41, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A85390: CC0E002D 0BFC0729 0000C931
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000A8539C: BF8700B2
	v_pk_fma_f16 v51, v40, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A853A0: CC0E0033 0BFC0728 0000C931
	ds_load_2addr_b32 v[40:41], v33 offset0:128 offset1:160    // 000000A853AC: D8DCA080 28000021
	v_dual_dot2acc_f32_f16 v15, v51, v2 :: v_dual_lshlrev_b32 v44, 16, v44// 000000A853B4: CB220533 0F2C5890
	v_and_or_b32 v44, 0xffff, v48, v44                         // 000000A853BC: D657002C 04B260FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A853C8: BF870112
	v_dot2acc_f32_f16 v15, v45, v3                             // 000000A853CC: 041E072D
	v_pk_fma_f16 v44, v44, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A853D0: CC0E002C 0BFC072C 0000C931
	v_and_b32_e32 v43, 0xffff, v43                             // 000000A853DC: 365656FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A853E4: BF870091
	v_lshl_or_b32 v43, v49, 16, v43                            // 000000A853E8: D656002B 04AD2131
	v_pk_fma_f16 v49, v43, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A853F0: CC0E0031 0BFC072B 0000C931
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A853FC: BF8700A1
	v_dot2acc_f32_f16 v26, v49, v1                             // 000000A85400: 04340331
	v_and_b32_e32 v37, 0xffff, v37                             // 000000A85404: 364A4AFF 0000FFFF
	.long 0xd72c0025                                           // 000000A8540C: D72C0025
	v_cndmask_b32_e32 v1, 0x83dcd12d, v37, vcc_lo              // 000000A85410: 02024AFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000A85418: BF8700B1
	v_sad_u8 v42, v37, 0, 0x6400                               // 000000A8541C: D622002A 03FD0125 00006400
	ds_load_2addr_b32 v[37:38], v34 offset0:128 offset1:160    // 000000A85428: D8DCA080 25000022
	v_lshlrev_b32_e32 v42, 16, v42                             // 000000A85430: 30545490
	v_and_or_b32 v42, 0xffff, v52, v42                         // 000000A85434: D657002A 04AA68FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000A85440: BF870151
	v_pk_fma_f16 v50, v42, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A85444: CC0E0032 0BFC072A 0000C931
	ds_load_2addr_b32 v[42:43], v31 offset0:128 offset1:160    // 000000A85450: D8DCA080 2A00001F
	s_waitcnt lgkmcnt(1)                                       // 000000A85458: BF89FC17
	v_dual_dot2acc_f32_f16 v26, v50, v2 :: v_dual_mov_b32 v39, v37// 000000A8545C: CB100532 1A260125
	v_pk_fma_f16 v37, v47, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A85464: CC0E0025 0BFC072F 0000C931
	.long 0xd73d0027                                           // 000000A85470: D73D0027
	v_cndmask_b32_e32 v1, v28, v39, vcc_lo                     // 000000A85474: 02024F1C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A85478: BF8701A2
	v_dot2acc_f32_f16 v26, v37, v3                             // 000000A8547C: 04340725
	v_pk_fma_f16 v40, v46, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A85480: CC0E0028 0BFC072E 0000C931
	v_bfe_u32 v37, v39, 12, 16                                 // 000000A8548C: D6100025 02411927
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A85494: BF870223
	v_dot2acc_f32_f16 v26, v44, v4                             // 000000A85498: 0434092C
	v_bfe_u32 v45, v39, 8, 16                                  // 000000A8549C: D610002D 02411127
	v_dual_dot2acc_f32_f16 v15, v40, v4 :: v_dual_and_b32 v40, 0xffff, v39// 000000A854A4: CB240928 0F284EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A854B0: BF870004
	.long 0xd72c0025                                           // 000000A854B4: D72C0025
	v_cndmask_b32_e32 v1, 0x83dcd12d, v37, vcc_lo              // 000000A854B8: 02024AFF 83DCD12D
	s_waitcnt lgkmcnt(0)                                       // 000000A854C0: BF89FC07
	v_bfe_u32 v44, v42, 12, 16                                 // 000000A854C4: D610002C 0241192A
	v_bfe_u32 v39, v39, 4, 16                                  // 000000A854CC: D6100027 02410927
	v_bfe_u32 v46, v42, 8, 16                                  // 000000A854D4: D610002E 0241112A
	.long 0xd72c002d                                           // 000000A854DC: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v45, vcc_lo              // 000000A854E0: 02025AFF 83DCD12D
	v_bfe_u32 v47, v42, 4, 16                                  // 000000A854E8: D610002F 0241092A
	.long 0xd72c002c                                           // 000000A854F0: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v44, vcc_lo              // 000000A854F4: 020258FF 83DCD12D
	v_and_b32_e32 v42, 0xffff, v42                             // 000000A854FC: 365454FF 0000FFFF
	v_sad_u8 v37, v37, 0, 0x6400                               // 000000A85504: D6220025 03FD0125 00006400
	.long 0xd72c0027                                           // 000000A85510: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 000000A85514: 02024EFF 83DCD12D
	.long 0xd72c0028                                           // 000000A8551C: D72C0028
	v_cndmask_b32_e32 v1, 0x83dcd12d, v40, vcc_lo              // 000000A85520: 020250FF 83DCD12D
	.long 0xd72c002e                                           // 000000A85528: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 000000A8552C: 02025CFF 83DCD12D
	.long 0xd72c002a                                           // 000000A85534: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 000000A85538: 020254FF 83DCD12D
	v_and_b32_e32 v37, 0xffff, v37                             // 000000A85540: 364A4AFF 0000FFFF
	v_sad_u8 v44, v44, 0, 0x6400                               // 000000A85548: D622002C 03FD012C 00006400
	v_sad_u8 v45, v45, 0, 0x6400                               // 000000A85554: D622002D 03FD012D 00006400
	.long 0xd72c002f                                           // 000000A85560: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 000000A85564: 02025EFF 83DCD12D
	v_sad_u8 v48, v39, 0, 0x6400                               // 000000A8556C: D6220030 03FD0127 00006400
	v_mov_b32_e32 v39, v41                                     // 000000A85578: 7E4E0329
	v_sad_u8 v40, v40, 0, 0x6400                               // 000000A8557C: D6220028 03FD0128 00006400
	v_and_b32_e32 v44, 0xffff, v44                             // 000000A85588: 365858FF 0000FFFF
	v_sad_u8 v41, v46, 0, 0x6400                               // 000000A85590: D6220029 03FD012E 00006400
	v_lshl_or_b32 v45, v45, 16, v37                            // 000000A8559C: D656002D 0495212D
	v_sad_u8 v42, v42, 0, 0x6400                               // 000000A855A4: D622002A 03FD012A 00006400
	.long 0xd73d0025                                           // 000000A855B0: D73D0025
	v_cndmask_b32_e32 v1, v28, v38, vcc_lo                     // 000000A855B4: 02024D1C
	v_sad_u8 v39, v47, 0, 0x6400                               // 000000A855B8: D6220027 03FD012F 00006400
	v_lshl_or_b32 v38, v41, 16, v44                            // 000000A855C4: D6560026 04B12129
	v_bfe_u32 v47, v43, 12, 16                                 // 000000A855CC: D610002F 0241192B
	v_lshlrev_b32_e32 v41, 16, v42                             // 000000A855D4: 30525490
	v_pk_fma_f16 v42, v45, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A855D8: CC0E002A 0BFC072D 0000C931
	v_lshlrev_b32_e32 v40, 16, v40                             // 000000A855E4: 30505090
	v_bfe_u32 v44, v37, 12, 16                                 // 000000A855E8: D610002C 02411925
	v_pk_fma_f16 v45, v38, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A855F0: CC0E002D 0BFC0726 0000C931
	v_and_or_b32 v38, 0xffff, v39, v41                         // 000000A855FC: D6570026 04A64EFF 0000FFFF
	v_dot2acc_f32_f16 v25, v42, v1                             // 000000A85608: 0432032A
	v_and_or_b32 v40, 0xffff, v48, v40                         // 000000A8560C: D6570028 04A260FF 0000FFFF
	v_bfe_u32 v39, v37, 8, 16                                  // 000000A85618: D6100027 02411125
	.long 0xd72c0029                                           // 000000A85620: D72C0029
	v_cndmask_b32_e32 v1, 0x83dcd12d, v44, vcc_lo              // 000000A85624: 020258FF 83DCD12D
	v_pk_fma_f16 v44, v38, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A8562C: CC0E002C 0BFC0726 0000C931
	v_bfe_u32 v48, v43, 8, 16                                  // 000000A85638: D6100030 0241112B
	v_pk_fma_f16 v40, v40, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A85640: CC0E0028 0BFC0728 0000C931
	.long 0xd72c0027                                           // 000000A8564C: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 000000A85650: 02024EFF 83DCD12D
	.long 0xd72c002f                                           // 000000A85658: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 000000A8565C: 02025EFF 83DCD12D
	v_bfe_u32 v50, v43, 4, 16                                  // 000000A85664: D6100032 0241092B
	.long 0xd72c0030                                           // 000000A8566C: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 000000A85670: 020260FF 83DCD12D
	v_dual_dot2acc_f32_f16 v25, v40, v2 :: v_dual_and_b32 v42, 0xffff, v37// 000000A85678: CB240528 192A4AFF 0000FFFF
	v_bfe_u32 v40, v37, 4, 16                                  // 000000A85684: D6100028 02410925
	ds_load_2addr_b32 v[37:38], v34 offset0:192 offset1:224    // 000000A8568C: D8DCE0C0 25000022
	v_sad_u8 v46, v41, 0, 0x6400                               // 000000A85694: D622002E 03FD0129 00006400
	v_dot2acc_f32_f16 v25, v45, v3                             // 000000A856A0: 0432072D
	.long 0xd72c002a                                           // 000000A856A4: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 000000A856A8: 020254FF 83DCD12D
	.long 0xd72c0031                                           // 000000A856B0: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v40, vcc_lo              // 000000A856B4: 020250FF 83DCD12D
	ds_load_2addr_b32 v[40:41], v33 offset0:192 offset1:224    // 000000A856BC: D8DCE0C0 28000021
	v_dual_dot2acc_f32_f16 v25, v44, v4 :: v_dual_and_b32 v46, 0xffff, v46// 000000A856C4: CB24092C 192E5CFF 0000FFFF
	v_sad_u8 v39, v39, 0, 0x6400                               // 000000A856D0: D6220027 03FD0127 00006400
	v_sad_u8 v47, v47, 0, 0x6400                               // 000000A856DC: D622002F 03FD012F 00006400
	v_sad_u8 v48, v48, 0, 0x6400                               // 000000A856E8: D6220030 03FD0130 00006400
	v_sad_u8 v42, v42, 0, 0x6400                               // 000000A856F4: D622002A 03FD012A 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A85700: BF870234
	v_lshl_or_b32 v39, v39, 16, v46                            // 000000A85704: D6560027 04B92127
	v_sad_u8 v46, v49, 0, 0x6400                               // 000000A8570C: D622002E 03FD0131 00006400
	v_and_b32_e32 v47, 0xffff, v47                             // 000000A85718: 365E5EFF 0000FFFF
	v_lshlrev_b32_e32 v42, 16, v42                             // 000000A85720: 30545490
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A85724: BF8701B4
	v_pk_fma_f16 v49, v39, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A85728: CC0E0031 0BFC0727 0000C931
	s_waitcnt lgkmcnt(1)                                       // 000000A85734: BF89FC17
	v_mov_b32_e32 v39, v37                                     // 000000A85738: 7E4E0325
	v_and_or_b32 v46, 0xffff, v46, v42                         // 000000A8573C: D657002E 04AA5CFF 0000FFFF
	.long 0xd72c0025                                           // 000000A85748: D72C0025
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 000000A8574C: 020264FF 83DCD12D
	v_dot2acc_f32_f16 v24, v49, v1                             // 000000A85754: 04300331
	s_waitcnt lgkmcnt(0)                                       // 000000A85758: BF89FC07
	.long 0xd73d0027                                           // 000000A8575C: D73D0027
	v_cndmask_b32_e32 v1, v28, v39, vcc_lo                     // 000000A85760: 02024F1C
	v_pk_fma_f16 v40, v46, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A85764: CC0E0028 0BFC072E 0000C931
	v_lshl_or_b32 v46, v48, 16, v47                            // 000000A85770: D656002E 04BD2130
	v_sad_u8 v37, v37, 0, 0x6400                               // 000000A85778: D6220025 03FD0125 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A85784: BF870193
	v_dot2acc_f32_f16 v24, v40, v2                             // 000000A85788: 04300528
	v_pk_fma_f16 v45, v46, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A8578C: CC0E002D 0BFC072E 0000C931
	v_bfe_u32 v48, v39, 12, 16                                 // 000000A85798: D6100030 02411927
	v_bfe_u32 v46, v39, 8, 16                                  // 000000A857A0: D610002E 02411127
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A857A8: BF870223
	v_dot2acc_f32_f16 v24, v45, v3                             // 000000A857AC: 0430072D
	v_and_b32_e32 v43, 0xffff, v43                             // 000000A857B0: 365656FF 0000FFFF
	.long 0xd72c0028                                           // 000000A857B8: D72C0028
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 000000A857BC: 020260FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A857C4: BF870194
	.long 0xd72c002d                                           // 000000A857C8: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 000000A857CC: 02025CFF 83DCD12D
	.long 0xd72c002b                                           // 000000A857D4: D72C002B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 000000A857D8: 020256FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A857E0: BF870193
	v_sad_u8 v40, v40, 0, 0x6400                               // 000000A857E4: D6220028 03FD0128 00006400
	v_sad_u8 v45, v45, 0, 0x6400                               // 000000A857F0: D622002D 03FD012D 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000A857FC: BF870143
	v_sad_u8 v50, v43, 0, 0x6400                               // 000000A85800: D6220032 03FD012B 00006400
	ds_load_2addr_b32 v[42:43], v31 offset0:192 offset1:224    // 000000A8580C: D8DCE0C0 2A00001F
	v_and_b32_e32 v40, 0xffff, v40                             // 000000A85814: 365050FF 0000FFFF
	v_lshlrev_b32_e32 v47, 16, v50                             // 000000A8581C: 305E6490
	v_lshl_or_b32 v40, v45, 16, v40                            // 000000A85820: D6560028 04A1212D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A85828: BF870092
	v_and_or_b32 v37, 0xffff, v37, v47                         // 000000A8582C: D6570025 04BE4AFF 0000FFFF
	v_pk_fma_f16 v44, v37, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A85838: CC0E002C 0BFC0725 0000C931
	v_bfe_u32 v37, v39, 4, 16                                  // 000000A85844: D6100025 02410927
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000A8584C: BF8701C2
	v_dual_dot2acc_f32_f16 v24, v44, v4 :: v_dual_and_b32 v39, 0xffff, v39// 000000A85850: CB24092C 18264EFF 0000FFFF
	s_waitcnt lgkmcnt(0)                                       // 000000A8585C: BF89FC07
	v_bfe_u32 v46, v42, 12, 16                                 // 000000A85860: D610002E 0241192A
	v_and_b32_e32 v48, 0xffff, v42                             // 000000A85868: 366054FF 0000FFFF
	.long 0xd72c0027                                           // 000000A85870: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 000000A85874: 02024EFF 83DCD12D
	.long 0xd72c0025                                           // 000000A8587C: D72C0025
	v_cndmask_b32_e32 v1, 0x83dcd12d, v37, vcc_lo              // 000000A85880: 02024AFF 83DCD12D
	v_bfe_u32 v47, v42, 8, 16                                  // 000000A85888: D610002F 0241112A
	.long 0xd72c002e                                           // 000000A85890: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 000000A85894: 02025CFF 83DCD12D
	.long 0xd72c0030                                           // 000000A8589C: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 000000A858A0: 020260FF 83DCD12D
	v_bfe_u32 v42, v42, 4, 16                                  // 000000A858A8: D610002A 0241092A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A858B0: BF870234
	.long 0xd72c002d                                           // 000000A858B4: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 000000A858B8: 02025EFF 83DCD12D
	v_sad_u8 v39, v39, 0, 0x6400                               // 000000A858C0: D6220027 03FD0127 00006400
	v_sad_u8 v47, v37, 0, 0x6400                               // 000000A858CC: D622002F 03FD0125 00006400
	.long 0xd72c002a                                           // 000000A858D8: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 000000A858DC: 020254FF 83DCD12D
	v_sad_u8 v46, v46, 0, 0x6400                               // 000000A858E4: D622002E 03FD012E 00006400
	v_sad_u8 v37, v48, 0, 0x6400                               // 000000A858F0: D6220025 03FD0130 00006400
	v_lshlrev_b32_e32 v49, 16, v39                             // 000000A858FC: 30624E90
	v_mov_b32_e32 v39, v41                                     // 000000A85900: 7E4E0329
	v_sad_u8 v45, v45, 0, 0x6400                               // 000000A85904: D622002D 03FD012D 00006400
	v_and_b32_e32 v41, 0xffff, v46                             // 000000A85910: 36525CFF 0000FFFF
	v_lshlrev_b32_e32 v46, 16, v37                             // 000000A85918: 305C4A90
	v_sad_u8 v42, v42, 0, 0x6400                               // 000000A8591C: D622002A 03FD012A 00006400
	.long 0xd73d0025                                           // 000000A85928: D73D0025
	v_cndmask_b32_e32 v1, v28, v38, vcc_lo                     // 000000A8592C: 02024D1C
	v_pk_fma_f16 v39, v40, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A85930: CC0E0027 0BFC0728 0000C931
	v_lshl_or_b32 v40, v45, 16, v41                            // 000000A8593C: D6560028 04A5212D
	v_and_or_b32 v38, 0xffff, v47, v49                         // 000000A85944: D6570026 04C65EFF 0000FFFF
	v_and_or_b32 v41, 0xffff, v42, v46                         // 000000A85950: D6570029 04BA54FF 0000FFFF
	v_bfe_u32 v46, v43, 8, 16                                  // 000000A8595C: D610002E 0241112B
	v_bfe_u32 v42, v37, 12, 16                                 // 000000A85964: D610002A 02411925
	v_dot2acc_f32_f16 v23, v39, v1                             // 000000A8596C: 042E0327
	v_pk_fma_f16 v44, v40, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A85970: CC0E002C 0BFC0728 0000C931
	v_bfe_u32 v40, v37, 8, 16                                  // 000000A8597C: D6100028 02411125
	v_pk_fma_f16 v38, v38, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A85984: CC0E0026 0BFC0726 0000C931
	.long 0xd72c0027                                           // 000000A85990: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 000000A85994: 020254FF 83DCD12D
	v_pk_fma_f16 v45, v41, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A8599C: CC0E002D 0BFC0729 0000C931
	v_bfe_u32 v41, v37, 4, 16                                  // 000000A859A8: D6100029 02410925
	v_and_b32_e32 v37, 0xffff, v37                             // 000000A859B0: 364A4AFF 0000FFFF
	.long 0xd72c0028                                           // 000000A859B8: D72C0028
	v_cndmask_b32_e32 v1, 0x83dcd12d, v40, vcc_lo              // 000000A859BC: 020250FF 83DCD12D
	v_dot2acc_f32_f16 v23, v38, v2                             // 000000A859C4: 042E0526
	v_bfe_u32 v42, v43, 12, 16                                 // 000000A859C8: D610002A 0241192B
	v_bfe_u32 v47, v43, 4, 16                                  // 000000A859D0: D610002F 0241092B
	v_sad_u8 v39, v39, 0, 0x6400                               // 000000A859D8: D6220027 03FD0127 00006400
	.long 0xd72c0030                                           // 000000A859E4: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v37, vcc_lo              // 000000A859E8: 02024AFF 83DCD12D
	ds_load_2addr_b32 v[37:38], v36 offset1:32                 // 000000A859F0: D8DC2000 25000024
	v_and_b32_e32 v43, 0xffff, v43                             // 000000A859F8: 365656FF 0000FFFF
	v_sad_u8 v49, v40, 0, 0x6400                               // 000000A85A00: D6220031 03FD0128 00006400
	v_and_b32_e32 v39, 0xffff, v39                             // 000000A85A0C: 364E4EFF 0000FFFF
	.long 0xd72c0032                                           // 000000A85A14: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v41, vcc_lo              // 000000A85A18: 020252FF 83DCD12D
	ds_load_2addr_b32 v[40:41], v35 offset1:32                 // 000000A85A20: D8DC2000 28000023
	.long 0xd72c002b                                           // 000000A85A28: D72C002B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 000000A85A2C: 020256FF 83DCD12D
	.long 0xd72c002a                                           // 000000A85A34: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 000000A85A38: 020254FF 83DCD12D
	v_lshl_or_b32 v49, v49, 16, v39                            // 000000A85A40: D6560031 049D2131
	v_sad_u8 v39, v48, 0, 0x6400                               // 000000A85A48: D6220027 03FD0130 00006400
	.long 0xd72c002e                                           // 000000A85A54: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 000000A85A58: 02025CFF 83DCD12D
	.long 0xd72c002f                                           // 000000A85A60: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 000000A85A64: 02025EFF 83DCD12D
	v_sad_u8 v50, v50, 0, 0x6400                               // 000000A85A6C: D6220032 03FD0132 00006400
	v_pk_fma_f16 v49, v49, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A85A78: CC0E0031 0BFC0731 0000C931
	v_lshlrev_b32_e32 v51, 16, v39                             // 000000A85A84: 30664E90
	v_sad_u8 v39, v43, 0, 0x6400                               // 000000A85A88: D6220027 03FD012B 00006400
	v_sad_u8 v48, v42, 0, 0x6400                               // 000000A85A94: D6220030 03FD012A 00006400
	ds_load_2addr_b32 v[42:43], v32 offset1:32                 // 000000A85AA0: D8DC2000 2A000020
	v_sad_u8 v46, v46, 0, 0x6400                               // 000000A85AA8: D622002E 03FD012E 00006400
	v_sad_u8 v47, v47, 0, 0x6400                               // 000000A85AB4: D622002F 03FD012F 00006400
	s_waitcnt lgkmcnt(2)                                       // 000000A85AC0: BF89FC27
	v_dual_mov_b32 v39, v37 :: v_dual_lshlrev_b32 v52, 16, v39 // 000000A85AC4: CA220125 27344E90
	v_dual_dot2acc_f32_f16 v23, v44, v3 :: v_dual_and_b32 v48, 0xffff, v48// 000000A85ACC: CB24072C 173060FF 0000FFFF
	v_and_or_b32 v37, 0xffff, v50, v51                         // 000000A85AD8: D6570025 04CE64FF 0000FFFF
	v_dot2acc_f32_f16 v22, v49, v1                             // 000000A85AE4: 042C0331
	s_waitcnt lgkmcnt(1)                                       // 000000A85AE8: BF89FC17
	.long 0xd73d0027                                           // 000000A85AEC: D73D0027
	v_cndmask_b32_e32 v1, v28, v39, vcc_lo                     // 000000A85AF0: 02024F1C
	v_lshl_or_b32 v46, v46, 16, v48                            // 000000A85AF4: D656002E 04C1212E
	v_and_or_b32 v47, 0xffff, v47, v52                         // 000000A85AFC: D657002F 04D25EFF 0000FFFF
	v_pk_fma_f16 v37, v37, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A85B08: CC0E0025 0BFC0725 0000C931
	v_dual_dot2acc_f32_f16 v23, v45, v4 :: v_dual_add_nc_u32 v30, 1, v30// 000000A85B14: CB20092D 171E3C81
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A85B1C: BF870224
	v_pk_fma_f16 v40, v46, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A85B20: CC0E0028 0BFC072E 0000C931
	v_bfe_u32 v46, v39, 12, 16                                 // 000000A85B2C: D610002E 02411927
	v_dual_dot2acc_f32_f16 v22, v37, v2 :: v_dual_and_b32 v37, 0xffff, v39// 000000A85B34: CB240525 16244EFF 0000FFFF
	v_pk_fma_f16 v44, v47, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A85B40: CC0E002C 0BFC072F 0000C931
	v_bfe_u32 v47, v39, 8, 16                                  // 000000A85B4C: D610002F 02411127
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A85B54: BF870004
	.long 0xd72c002e                                           // 000000A85B58: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 000000A85B5C: 02025CFF 83DCD12D
	v_bfe_u32 v39, v39, 4, 16                                  // 000000A85B64: D6100027 02410927
	.long 0xd72c0025                                           // 000000A85B6C: D72C0025
	v_cndmask_b32_e32 v1, 0x83dcd12d, v37, vcc_lo              // 000000A85B70: 02024AFF 83DCD12D
	s_waitcnt lgkmcnt(0)                                       // 000000A85B78: BF89FC07
	v_bfe_u32 v48, v42, 12, 16                                 // 000000A85B7C: D6100030 0241192A
	.long 0xd72c002f                                           // 000000A85B84: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 000000A85B88: 02025EFF 83DCD12D
	v_bfe_u32 v49, v42, 8, 16                                  // 000000A85B90: D6100031 0241112A
	.long 0xd72c0027                                           // 000000A85B98: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 000000A85B9C: 02024EFF 83DCD12D
	v_bfe_u32 v50, v42, 4, 16                                  // 000000A85BA4: D6100032 0241092A
	v_sad_u8 v46, v46, 0, 0x6400                               // 000000A85BAC: D622002E 03FD012E 00006400
	.long 0xd72c0030                                           // 000000A85BB8: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 000000A85BBC: 020260FF 83DCD12D
	v_sad_u8 v37, v37, 0, 0x6400                               // 000000A85BC4: D6220025 03FD0125 00006400
	.long 0xd72c0031                                           // 000000A85BD0: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 000000A85BD4: 020262FF 83DCD12D
	v_sad_u8 v47, v47, 0, 0x6400                               // 000000A85BDC: D622002F 03FD012F 00006400
	v_and_b32_e32 v46, 0xffff, v46                             // 000000A85BE8: 365C5CFF 0000FFFF
	v_sad_u8 v51, v39, 0, 0x6400                               // 000000A85BF0: D6220033 03FD0127 00006400
	v_lshlrev_b32_e32 v37, 16, v37                             // 000000A85BFC: 304A4A90
	v_mov_b32_e32 v39, v41                                     // 000000A85C00: 7E4E0329
	v_sad_u8 v48, v48, 0, 0x6400                               // 000000A85C04: D6220030 03FD0130 00006400
	v_lshl_or_b32 v46, v47, 16, v46                            // 000000A85C10: D656002E 04B9212F
	v_dot2acc_f32_f16 v22, v40, v3                             // 000000A85C18: 042C0728
	v_and_or_b32 v47, 0xffff, v51, v37                         // 000000A85C1C: D657002F 049666FF 0000FFFF
	.long 0xd73d0025                                           // 000000A85C28: D73D0025
	v_cndmask_b32_e32 v1, v28, v38, vcc_lo                     // 000000A85C2C: 02024D1C
	v_sad_u8 v41, v49, 0, 0x6400                               // 000000A85C30: D6220029 03FD0131 00006400
	v_pk_fma_f16 v40, v46, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A85C3C: CC0E0028 0BFC072E 0000C931
	v_and_b32_e32 v42, 0xffff, v42                             // 000000A85C48: 365454FF 0000FFFF
	.long 0xd72c0031                                           // 000000A85C50: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 000000A85C54: 020264FF 83DCD12D
	v_bfe_u32 v50, v43, 8, 16                                  // 000000A85C5C: D6100032 0241112B
	v_bfe_u32 v51, v43, 4, 16                                  // 000000A85C64: D6100033 0241092B
	v_dual_dot2acc_f32_f16 v21, v40, v1 :: v_dual_and_b32 v48, 0xffff, v48// 000000A85C6C: CB240328 153060FF 0000FFFF
	.long 0xd72c0027                                           // 000000A85C78: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 000000A85C7C: 020254FF 83DCD12D
	v_bfe_u32 v42, v37, 12, 16                                 // 000000A85C84: D610002A 02411925
	.long 0xd72c0032                                           // 000000A85C8C: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 000000A85C90: 020264FF 83DCD12D
	v_sad_u8 v46, v49, 0, 0x6400                               // 000000A85C98: D622002E 03FD0131 00006400
	v_lshl_or_b32 v38, v41, 16, v48                            // 000000A85CA4: D6560026 04C12129
	v_pk_fma_f16 v41, v47, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A85CAC: CC0E0029 0BFC072F 0000C931
	v_and_b32_e32 v47, 0xffff, v37                             // 000000A85CB8: 365E4AFF 0000FFFF
	.long 0xd72c002a                                           // 000000A85CC0: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 000000A85CC4: 020254FF 83DCD12D
	v_bfe_u32 v48, v37, 8, 16                                  // 000000A85CCC: D6100030 02411125
	v_bfe_u32 v37, v37, 4, 16                                  // 000000A85CD4: D6100025 02410925
	v_bfe_u32 v49, v43, 12, 16                                 // 000000A85CDC: D6100031 0241192B
	.long 0xd72c002f                                           // 000000A85CE4: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 000000A85CE8: 02025EFF 83DCD12D
	v_pk_fma_f16 v38, v38, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A85CF0: CC0E0026 0BFC0726 0000C931
	.long 0xd72c0030                                           // 000000A85CFC: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 000000A85D00: 020260FF 83DCD12D
	.long 0xd72c0025                                           // 000000A85D08: D72C0025
	v_cndmask_b32_e32 v1, 0x83dcd12d, v37, vcc_lo              // 000000A85D0C: 02024AFF 83DCD12D
	v_sad_u8 v42, v42, 0, 0x6400                               // 000000A85D14: D622002A 03FD012A 00006400
	v_dot2acc_f32_f16 v21, v41, v2                             // 000000A85D20: 042A0529
	.long 0xd72c0031                                           // 000000A85D24: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 000000A85D28: 020262FF 83DCD12D
	v_and_b32_e32 v43, 0xffff, v43                             // 000000A85D30: 365656FF 0000FFFF
	v_sad_u8 v47, v47, 0, 0x6400                               // 000000A85D38: D622002F 03FD012F 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A85D44: BF870234
	v_dual_dot2acc_f32_f16 v21, v38, v3 :: v_dual_and_b32 v42, 0xffff, v42// 000000A85D48: CB240726 152A54FF 0000FFFF
	v_sad_u8 v48, v48, 0, 0x6400                               // 000000A85D54: D6220030 03FD0130 00006400
	v_sad_u8 v37, v37, 0, 0x6400                               // 000000A85D60: D6220025 03FD0125 00006400
	v_lshlrev_b32_e32 v47, 16, v47                             // 000000A85D6C: 305E5E90
	v_sad_u8 v49, v49, 0, 0x6400                               // 000000A85D70: D6220031 03FD0131 00006400
	.long 0xd72c002b                                           // 000000A85D7C: D72C002B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 000000A85D80: 020256FF 83DCD12D
	v_lshl_or_b32 v42, v48, 16, v42                            // 000000A85D88: D656002A 04A92130
	v_sad_u8 v39, v39, 0, 0x6400                               // 000000A85D90: D6220027 03FD0127 00006400
	v_and_or_b32 v37, 0xffff, v37, v47                         // 000000A85D9C: D6570025 04BE4AFF 0000FFFF
	.long 0xd72c002f                                           // 000000A85DA8: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 000000A85DAC: 020266FF 83DCD12D
	v_dot2acc_f32_f16 v22, v44, v4                             // 000000A85DB4: 042C092C
	v_pk_fma_f16 v42, v42, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A85DB8: CC0E002A 0BFC072A 0000C931
	v_lshlrev_b32_e32 v39, 16, v39                             // 000000A85DC4: 304E4E90
	v_pk_fma_f16 v37, v37, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A85DC8: CC0E0025 0BFC0725 0000C931
	v_sad_u8 v40, v43, 0, 0x6400                               // 000000A85DD4: D6220028 03FD012B 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A85DE0: BF870004
	v_dot2acc_f32_f16 v11, v42, v1                             // 000000A85DE4: 0416032A
	v_and_b32_e32 v48, 0xffff, v49                             // 000000A85DE8: 366062FF 0000FFFF
	v_sad_u8 v49, v50, 0, 0x6400                               // 000000A85DF0: D6220031 03FD0132 00006400
	v_sad_u8 v47, v47, 0, 0x6400                               // 000000A85DFC: D622002F 03FD012F 00006400
	v_and_or_b32 v1, 0xffff, v46, v39                          // 000000A85E08: D6570001 049E5CFF 0000FFFF
	v_dot2acc_f32_f16 v11, v37, v2                             // 000000A85E14: 04160525
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A85E18: BF870194
	v_lshl_or_b32 v43, v49, 16, v48                            // 000000A85E1C: D656002B 04C12131
	v_pk_fma_f16 v1, v1, s3, 0xc931 op_sel_hi:[1,0,0]          // 000000A85E24: CC0E0001 0BFC0701 0000C931
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A85E30: BF8701A2
	v_pk_fma_f16 v39, v43, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A85E34: CC0E0027 0BFC072B 0000C931
	v_lshlrev_b32_e32 v40, 16, v40                             // 000000A85E40: 30505090
	v_dot2acc_f32_f16 v21, v1, v4                              // 000000A85E44: 042A0901
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A85E48: BF870193
	v_dot2acc_f32_f16 v11, v39, v3                             // 000000A85E4C: 04160727
	v_and_or_b32 v40, 0xffff, v47, v40                         // 000000A85E50: D6570028 04A25EFF 0000FFFF
	v_add_nc_u32_e32 v3, v29, v30                              // 000000A85E5C: 4A063D1D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A85E60: BF870112
	v_pk_fma_f16 v2, v40, s3, 0xc931 op_sel_hi:[1,0,0]         // 000000A85E64: CC0E0002 0BFC0728 0000C931
	v_cmp_eq_u32_e32 vcc_lo, 6, v3                             // 000000A85E70: 7C940686
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000A85E74: BF8704A2
	v_dot2acc_f32_f16 v11, v2, v4                              // 000000A85E78: 04160902
	s_or_b32 s2, vcc_lo, s2                                    // 000000A85E7C: 8C02026A
	s_and_not1_b32 exec_lo, exec_lo, s2                        // 000000A85E80: 917E027E
	s_cbranch_execz 34                                         // 000000A85E84: BFA50022 <_ZN7halogen12_GLOBAL__N_112k_ht_gemv_dnILi4ELi8ELi1EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x1110>
	s_mov_b32 s0, exec_lo                                      // 000000A85E88: BE80007E
	s_waitcnt vmcnt(6)                                         // 000000A85E8C: BF891BF7
	ds_store_2addr_b32 v31, v12, v13 offset0:64 offset1:96     // 000000A85E90: D8386040 000D0C1F
	s_waitcnt vmcnt(4)                                         // 000000A85E98: BF8913F7
	ds_store_2addr_b32 v31, v14, v16 offset0:128 offset1:160   // 000000A85E9C: D838A080 00100E1F
	s_waitcnt vmcnt(2)                                         // 000000A85EA4: BF890BF7
	ds_store_2addr_b32 v31, v17, v18 offset0:192 offset1:224   // 000000A85EA8: D838E0C0 0012111F
	s_waitcnt vmcnt(0)                                         // 000000A85EB0: BF8903F7
	ds_store_2addr_b32 v32, v19, v20 offset1:32                // 000000A85EB4: D8382000 00141320
	.long 0xd4c9007e                                           // 000000A85EBC: D4C9007E
	v_cndmask_b32_e32 v1, v30, v10, vcc_lo                     // 000000A85EC0: 0202151E
	s_cbranch_execz 64647                                      // 000000A85EC4: BFA5FC87 <_ZN7halogen12_GLOBAL__N_112k_ht_gemv_dnILi4ELi8ELi1EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x2e4>
	s_clause 0x7                                               // 000000A85EC8: BF850007
	global_load_b32 v12, v[5:6], off                           // 000000A85ECC: DC520000 0C7C0005
	global_load_b32 v13, v[5:6], off offset:128                // 000000A85ED4: DC520080 0D7C0005
	global_load_b32 v14, v[5:6], off offset:256                // 000000A85EDC: DC520100 0E7C0005
	global_load_b32 v16, v[5:6], off offset:384                // 000000A85EE4: DC520180 107C0005
	global_load_b32 v17, v[5:6], off offset:512                // 000000A85EEC: DC520200 117C0005
	global_load_b32 v18, v[5:6], off offset:640                // 000000A85EF4: DC520280 127C0005
	global_load_b32 v19, v[5:6], off offset:768                // 000000A85EFC: DC520300 137C0005
	global_load_b32 v20, v[5:6], off offset:896                // 000000A85F04: DC520380 147C0005
	s_branch 64629                                             // 000000A85F0C: BFA0FC75 <_ZN7halogen12_GLOBAL__N_112k_ht_gemv_dnILi4ELi8ELi1EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x2e4>
	s_or_b32 exec_lo, exec_lo, s2                              // 000000A85F10: 8C7E027E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A85F14: BF870099
	s_or_b32 exec_lo, exec_lo, s1                              // 000000A85F18: 8C7E017E
	v_dual_mov_b32 v1, v15 :: v_dual_mov_b32 v2, v26           // 000000A85F1C: CA10010F 0102011A
	v_dual_mov_b32 v3, v25 :: v_dual_mov_b32 v10, v24          // 000000A85F24: CA100119 030A0118
	v_dual_mov_b32 v4, v23 :: v_dual_mov_b32 v5, v22           // 000000A85F2C: CA100117 04040116
	v_mov_b32_e32 v6, v21                                      // 000000A85F34: 7E0C0315
	s_waitcnt vmcnt(7)                                         // 000000A85F38: BF891FF7
	v_mov_b32_e32 v12, v11                                     // 000000A85F3C: 7E18030B
	s_mov_b32 s0, 0x76543210                                   // 000000A85F40: BE8000FF 76543210
	v_cmp_gt_u32_e32 vcc_lo, 16, v8                            // 000000A85F48: 7C981090
	v_permlanex16_b32 v1, v1, s0, 0xfedcba98                   // 000000A85F4C: D65C0001 03FC0101 FEDCBA98
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 000000A85F58: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 000000A85F64: D65C0003 03FC0103 FEDCBA98
	v_permlanex16_b32 v10, v10, s0, 0xfedcba98                 // 000000A85F70: D65C000A 03FC010A FEDCBA98
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 000000A85F7C: D65C0004 03FC0104 FEDCBA98
	v_permlanex16_b32 v5, v5, s0, 0xfedcba98                   // 000000A85F88: D65C0005 03FC0105 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 000000A85F94: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v12, v12, s0, 0xfedcba98                 // 000000A85FA0: D65C000C 03FC010C FEDCBA98
	s_waitcnt vmcnt(0)                                         // 000000A85FAC: BF8903F7
	s_barrier                                                  // 000000A85FB0: BFBD0000
	buffer_gl0_inv                                             // 000000A85FB4: E0AC0000 00000000
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A85FBC: BE80206A
	s_cbranch_execz 18                                         // 000000A85FC0: BFA50012 <_ZN7halogen12_GLOBAL__N_112k_ht_gemv_dnILi4ELi8ELi1EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x120c>
	v_dual_add_f32 v1, v15, v1 :: v_dual_add_f32 v2, v26, v2   // 000000A85FC4: C908030F 0102051A
	v_lshl_or_b32 v9, v7, 9, v9                                // 000000A85FCC: D6560009 04251307
	v_dual_add_f32 v8, v11, v12 :: v_dual_add_f32 v3, v25, v3  // 000000A85FD4: C908190B 08020719
	v_dual_add_f32 v10, v24, v10 :: v_dual_add_f32 v5, v22, v5 // 000000A85FDC: C9081518 0A040B16
	v_add_f32_e32 v4, v23, v4                                  // 000000A85FE4: 06080917
	v_add_f32_e32 v6, v21, v6                                  // 000000A85FE8: 060C0D15
	ds_store_2addr_b32 v9, v1, v2 offset1:16                   // 000000A85FEC: D8381000 00020109
	ds_store_2addr_b32 v9, v3, v10 offset0:32 offset1:48       // 000000A85FF4: D8383020 000A0309
	ds_store_2addr_b32 v9, v4, v5 offset0:64 offset1:80        // 000000A85FFC: D8385040 00050409
	ds_store_2addr_b32 v9, v6, v8 offset0:96 offset1:112       // 000000A86004: D8387060 00080609
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A8600C: 8C7E007E
	s_sub_i32 s0, s15, s14                                     // 000000A86010: 81800E0F
	s_waitcnt lgkmcnt(0)                                       // 000000A86014: BF89FC07
	s_min_i32 s0, s0, 1                                        // 000000A86018: 89008100
	s_barrier                                                  // 000000A8601C: BFBD0000
	buffer_gl0_inv                                             // 000000A86020: E0AC0000 00000000
	s_mov_b32 s1, exec_lo                                      // 000000A86028: BE81007E
	.long 0xd4c4007e                                           // 000000A8602C: D4C4007E
	v_cndmask_b32_e32 v1, s0, v7, vcc_lo                       // 000000A86030: 02020E00
	s_cbranch_execz 510                                        // 000000A86034: BFA501FE <_ZN7halogen12_GLOBAL__N_112k_ht_gemv_dnILi4ELi8ELi1EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x1a30>
	v_and_b32_e32 v1, 15, v0                                   // 000000A86038: 3602008F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A8603C: BF870001
	v_lshlrev_b32_e32 v16, 2, v1                               // 000000A86040: 30200282
	ds_load_2addr_b32 v[2:3], v16 offset1:16                   // 000000A86044: D8DC1000 02000010
	ds_load_2addr_b32 v[4:5], v16 offset0:128 offset1:144      // 000000A8604C: D8DC9080 04000010
	s_waitcnt lgkmcnt(1)                                       // 000000A86054: BF89FC17
	v_dual_add_f32 v53, 0, v3 :: v_dual_add_f32 v52, 0, v2     // 000000A86058: C9080680 35340480
	v_add_nc_u32_e32 v48, 0x400, v16                           // 000000A86060: 4A6020FF 00000400
	v_add_nc_u32_e32 v50, 0x800, v16                           // 000000A86068: 4A6420FF 00000800
	v_add_nc_u32_e32 v51, 0xc00, v16                           // 000000A86070: 4A6620FF 00000C00
	s_waitcnt lgkmcnt(0)                                       // 000000A86078: BF89FC07
	v_add_f32_e32 v53, v53, v5                                 // 000000A8607C: 066A0B35
	ds_load_2addr_b32 v[6:7], v16 offset0:32 offset1:48        // 000000A86080: D8DC3020 06000010
	ds_load_2addr_b32 v[8:9], v16 offset0:160 offset1:176      // 000000A86088: D8DCB0A0 08000010
	ds_load_2addr_b32 v[10:11], v16 offset0:64 offset1:80      // 000000A86090: D8DC5040 0A000010
	ds_load_2addr_b32 v[12:13], v16 offset0:192 offset1:208    // 000000A86098: D8DCD0C0 0C000010
	ds_load_2addr_b32 v[14:15], v16 offset0:96 offset1:112     // 000000A860A0: D8DC7060 0E000010
	ds_load_2addr_b32 v[16:17], v16 offset0:224 offset1:240    // 000000A860A8: D8DCF0E0 10000010
	ds_load_2addr_b32 v[18:19], v48 offset1:16                 // 000000A860B0: D8DC1000 12000030
	ds_load_2addr_b32 v[20:21], v48 offset0:128 offset1:144    // 000000A860B8: D8DC9080 14000030
	ds_load_2addr_b32 v[22:23], v50 offset1:16                 // 000000A860C0: D8DC1000 16000032
	ds_load_2addr_b32 v[24:25], v50 offset0:128 offset1:144    // 000000A860C8: D8DC9080 18000032
	ds_load_2addr_b32 v[26:27], v51 offset1:16                 // 000000A860D0: D8DC1000 1A000033
	ds_load_2addr_b32 v[28:29], v51 offset0:128 offset1:144    // 000000A860D8: D8DC9080 1C000033
	ds_load_2addr_b32 v[30:31], v48 offset0:32 offset1:48      // 000000A860E0: D8DC3020 1E000030
	ds_load_2addr_b32 v[32:33], v48 offset0:160 offset1:176    // 000000A860E8: D8DCB0A0 20000030
	ds_load_2addr_b32 v[34:35], v50 offset0:32 offset1:48      // 000000A860F0: D8DC3020 22000032
	ds_load_2addr_b32 v[36:37], v50 offset0:160 offset1:176    // 000000A860F8: D8DCB0A0 24000032
	ds_load_2addr_b32 v[38:39], v51 offset0:32 offset1:48      // 000000A86100: D8DC3020 26000033
	ds_load_2addr_b32 v[40:41], v51 offset0:160 offset1:176    // 000000A86108: D8DCB0A0 28000033
	ds_load_2addr_b32 v[42:43], v48 offset0:64 offset1:80      // 000000A86110: D8DC5040 2A000030
	ds_load_2addr_b32 v[44:45], v48 offset0:192 offset1:208    // 000000A86118: D8DCD0C0 2C000030
	ds_load_2addr_b32 v[46:47], v50 offset0:64 offset1:80      // 000000A86120: D8DC5040 2E000032
	s_waitcnt lgkmcnt(20)                                      // 000000A86128: BF89FD47
	v_add_f32_e32 v6, 0, v6                                    // 000000A8612C: 060C0C80
	s_waitcnt lgkmcnt(18)                                      // 000000A86130: BF89FD27
	v_dual_add_f32 v52, v52, v4 :: v_dual_add_f32 v11, 0, v11  // 000000A86134: C9080934 340A1680
	ds_load_2addr_b32 v[2:3], v48 offset0:96 offset1:112       // 000000A8613C: D8DC7060 02000030
	ds_load_2addr_b32 v[48:49], v48 offset0:224 offset1:240    // 000000A86144: D8DCF0E0 30000030
	v_dual_add_f32 v7, 0, v7 :: v_dual_add_f32 v6, v6, v8      // 000000A8614C: C9080E80 07061106
	s_waitcnt lgkmcnt(16)                                      // 000000A86154: BF89FD07
	v_dual_add_f32 v15, 0, v15 :: v_dual_add_f32 v8, v52, v18  // 000000A86158: C9081E80 0F082534
	v_add_f32_e32 v10, 0, v10                                  // 000000A86160: 06141480
	ds_load_2addr_b32 v[4:5], v50 offset0:96 offset1:112       // 000000A86164: D8DC7060 04000032
	v_add_f32_e32 v18, v53, v19                                // 000000A8616C: 06242735
	v_dual_add_f32 v14, 0, v14 :: v_dual_add_f32 v7, v7, v9    // 000000A86170: C9081C80 0E061307
	s_waitcnt lgkmcnt(11)                                      // 000000A86178: BF89FCB7
	v_add_f32_e32 v6, v6, v30                                  // 000000A8617C: 060C3D06
	v_add_f32_e32 v9, v10, v12                                 // 000000A86180: 0612190A
	v_add_f32_e32 v8, v8, v20                                  // 000000A86184: 06102908
	v_add_f32_e32 v12, v11, v13                                // 000000A86188: 06181B0B
	v_dual_add_f32 v18, v18, v21 :: v_dual_add_f32 v7, v7, v31 // 000000A8618C: C9082B12 12063F07
	s_waitcnt lgkmcnt(5)                                       // 000000A86194: BF89FC57
	v_add_f32_e32 v9, v9, v42                                  // 000000A86198: 06125509
	v_dual_add_f32 v8, v8, v22 :: v_dual_add_f32 v13, v14, v16 // 000000A8619C: C9082D08 080C210E
	v_dual_add_f32 v14, v15, v17 :: v_dual_add_f32 v15, v12, v43// 000000A861A4: C908230F 0E0E570C
	v_add_f32_e32 v6, v6, v32                                  // 000000A861AC: 060C4106
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A861B0: BF870003
	v_add_f32_e32 v8, v8, v24                                  // 000000A861B4: 06103108
	s_waitcnt lgkmcnt(4)                                       // 000000A861B8: BF89FC47
	v_add_f32_e32 v19, v9, v44                                 // 000000A861BC: 06265909
	s_waitcnt lgkmcnt(2)                                       // 000000A861C0: BF89FC27
	v_add_f32_e32 v17, v14, v3                                 // 000000A861C4: 0622070E
	v_dual_add_f32 v18, v18, v23 :: v_dual_add_f32 v23, v15, v45// 000000A861C8: C9082F12 12165B0F
	v_add_f32_e32 v6, v6, v34                                  // 000000A861D0: 060C4506
	v_add_f32_e32 v16, v13, v2                                 // 000000A861D4: 0620050D
	s_waitcnt lgkmcnt(1)                                       // 000000A861D8: BF89FC17
	v_add_f32_e32 v17, v17, v49                                // 000000A861DC: 06226311
	v_dual_add_f32 v10, v18, v25 :: v_dual_add_f32 v19, v19, v46// 000000A861E0: C9083312 0A125D13
	v_dual_add_f32 v23, v23, v47 :: v_dual_add_f32 v6, v6, v36 // 000000A861E8: C9085F17 17064906
	s_waitcnt lgkmcnt(0)                                       // 000000A861F0: BF89FC07
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A861F4: BF870003
	v_add_f32_e32 v5, v17, v5                                  // 000000A861F8: 060A0B11
	ds_load_2addr_b32 v[2:3], v51 offset0:192 offset1:208      // 000000A861FC: D8DCD0C0 02000033
	ds_load_2addr_b32 v[14:15], v51 offset0:224 offset1:240    // 000000A86204: D8DCF0E0 0E000033
	v_add_f32_e32 v18, v7, v33                                 // 000000A8620C: 06244307
	v_add_f32_e32 v6, v6, v38                                  // 000000A86210: 060C4D06
	ds_load_2addr_b32 v[12:13], v51 offset0:96 offset1:112     // 000000A86214: D8DC7060 0C000033
	v_add_f32_e32 v22, v6, v40                                 // 000000A8621C: 062C5106
	ds_load_2addr_b32 v[6:7], v50 offset0:192 offset1:208      // 000000A86220: D8DCD0C0 06000032
	s_waitcnt lgkmcnt(0)                                       // 000000A86228: BF89FC07
	v_dual_add_f32 v8, v8, v26 :: v_dual_add_f32 v7, v23, v7   // 000000A8622C: C9083508 08060F17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000A86234: BF8700C1
	v_add_f32_e32 v20, v8, v28                                 // 000000A86238: 06283908
	ds_load_2addr_b32 v[8:9], v50 offset0:224 offset1:240      // 000000A8623C: D8DCF0E0 08000032
	s_waitcnt lgkmcnt(0)                                       // 000000A86244: BF89FC07
	v_dual_add_f32 v10, v10, v27 :: v_dual_add_f32 v5, v5, v9  // 000000A86248: C908370A 0A041305
	v_add_f32_e32 v21, v10, v29                                // 000000A86250: 062A3B0A
	ds_load_2addr_b32 v[10:11], v51 offset0:64 offset1:80      // 000000A86254: D8DC5040 0A000033
	v_add_f32_e32 v5, v5, v13                                  // 000000A8625C: 060A1B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A86260: BF8700A1
	v_dual_add_f32 v5, v5, v15 :: v_dual_add_f32 v6, v19, v6   // 000000A86264: C9081F05 05060D13
	s_waitcnt lgkmcnt(0)                                       // 000000A8626C: BF89FC07
	v_dual_add_f32 v6, v6, v10 :: v_dual_add_f32 v7, v7, v11   // 000000A86270: C9081506 06061707
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A86278: BF8701B1
	v_dual_add_f32 v2, v6, v2 :: v_dual_add_f32 v3, v7, v3     // 000000A8627C: C9080506 02020707
	v_sub_f32_e32 v7, v20, v21                                 // 000000A86284: 080E2B14
	v_add_f32_e32 v6, v20, v21                                 // 000000A86288: 060C2B14
	v_add_f32_e32 v10, v2, v3                                  // 000000A8628C: 06140702
	v_sub_f32_e32 v2, v2, v3                                   // 000000A86290: 08040702
	v_add_f32_e32 v16, v16, v48                                // 000000A86294: 06206110
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A86298: BF870091
	v_add_f32_e32 v4, v16, v4                                  // 000000A8629C: 06080910
	v_add_f32_e32 v4, v4, v8                                   // 000000A862A0: 06081104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A862A4: BF870091
	v_add_f32_e32 v4, v4, v12                                  // 000000A862A8: 06081904
	v_add_f32_e32 v4, v4, v14                                  // 000000A862AC: 06081D04
	v_add_f32_e32 v18, v18, v35                                // 000000A862B0: 06244712
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A862B4: BF870112
	v_dual_add_f32 v11, v4, v5 :: v_dual_and_b32 v14, 1, v0    // 000000A862B8: C9240B04 0B0E0081
	v_add_f32_e32 v16, v18, v37                                // 000000A862C0: 06204B12
	v_sub_f32_e32 v3, v4, v5                                   // 000000A862C4: 08060B04
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A862C8: BF870213
	.long 0xd44a0000                                           // 000000A862CC: D44A0000
	v_cndmask_b32_e32 v1, 0, v14, vcc_lo                       // 000000A862D0: 02021C80
	v_add_f32_e32 v5, v10, v11                                 // 000000A862D4: 060A170A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A862D8: BF870214
	v_add_f32_e32 v8, v16, v39                                 // 000000A862DC: 06104F10
	v_add_f32_e32 v13, v2, v3                                  // 000000A862E0: 061A0702
	v_dual_sub_f32 v2, v2, v3 :: v_dual_and_b32 v3, 2, v0      // 000000A862E4: C9640702 02020082
	v_sub_f32_e32 v10, v10, v11                                // 000000A862EC: 0814170A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A862F0: BF870194
	v_add_f32_e32 v8, v8, v41                                  // 000000A862F4: 06105308
	.long 0xd44a0001                                           // 000000A862F8: D44A0001
	v_cndmask_b32_e32 v1, 0, v3, vcc_lo                        // 000000A862FC: 02020680
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000A86300: BF870122
	v_add_f32_e32 v9, v22, v8                                  // 000000A86304: 06121116
	v_sub_f32_e32 v8, v22, v8                                  // 000000A86308: 08101116
	v_add_f32_e32 v4, v6, v9                                   // 000000A8630C: 06081306
	v_sub_f32_e32 v6, v6, v9                                   // 000000A86310: 080C1306
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A86314: BF8701A2
	v_dual_add_f32 v12, v7, v8 :: v_dual_add_f32 v9, v4, v5    // 000000A86318: C9081107 0C080B04
	v_sub_f32_e32 v5, v4, v5                                   // 000000A86320: 080A0B04
	v_add_f32_e32 v3, v6, v10                                  // 000000A86324: 06061506
	v_sub_f32_e32 v10, v6, v10                                 // 000000A86328: 08141506
	v_and_b32_e32 v6, 4, v0                                    // 000000A8632C: 360C0084
	v_mov_b32_dpp v11, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A86330: 7E1602FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 000000A86338: D5010009 20021309
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A86340: BF870113
	.long 0xd44a0002                                           // 000000A86344: D44A0002
	v_cndmask_b32_e32 v1, 0, v6, vcc_lo                        // 000000A86348: 02020C80
	v_dual_add_f32 v4, v9, v11 :: v_dual_sub_f32 v9, v12, v13  // 000000A8634C: C90A1709 04081B0C
	v_dual_sub_f32 v7, v7, v8 :: v_dual_add_f32 v8, v12, v13   // 000000A86354: C9481107 07081B0C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A8635C: BF8701A2
	v_mov_b32_dpp v11, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A86360: 7E1602FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000A86368: D5010004 20060904
	v_add_f32_e32 v13, v7, v2                                  // 000000A86370: 061A0507
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A86374: BF870224
	v_mov_b32_dpp v14, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A86378: 7E1C02FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, s0                          // 000000A86380: D5010008 20021108
	v_dual_sub_f32 v7, v7, v2 :: v_dual_add_f32 v4, v4, v11    // 000000A86388: C9480507 07041704
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A86390: BF870194
	v_mov_b32_dpp v11, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A86394: 7E1602FA FF01610D
	v_add_f32_e32 v8, v8, v14                                  // 000000A8639C: 06101D08
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A863A0: BF8701A3
	v_mov_b32_dpp v6, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A863A4: 7E0C02FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s2                          // 000000A863AC: D5010004 200A0904
	v_mov_b32_dpp v12, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A863B4: 7E1802FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s1                          // 000000A863BC: D5010008 20061108
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000A863C4: BF8701C1
	v_add_f32_e32 v8, v8, v12                                  // 000000A863C8: 06101908
	v_cndmask_b32_e64 v12, -v13, v13, s0                       // 000000A863CC: D501000C 20021B0D
	v_mov_b32_dpp v13, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A863D4: 7E1A02FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 000000A863DC: D5010003 20020703
	v_add_f32_e32 v11, v12, v11                                // 000000A863E4: 0616170C
	v_mov_b32_dpp v12, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A863E8: 7E1802FA FF016408
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A863F0: BF870223
	v_add_f32_e32 v3, v3, v13                                  // 000000A863F4: 06061B03
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 000000A863F8: D5010008 200A1108
	v_mov_b32_dpp v13, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A86400: 7E1A02FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 000000A86408: D501000B 2006170B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000A86410: BF870254
	v_mov_b32_dpp v14, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A86414: 7E1C02FA FF016203
	v_cndmask_b32_e64 v15, -v3, v3, s1                         // 000000A8641C: D501000F 20060703
	v_add_f32_e32 v3, v4, v6                                   // 000000A86424: 06060D04
	v_add_f32_e32 v6, v8, v12                                  // 000000A86428: 060C1908
	v_add_f32_e32 v8, v11, v13                                 // 000000A8642C: 06101B0B
	v_add_f32_e32 v11, v15, v14                                // 000000A86430: 06161D0F
	v_mov_b32_dpp v14, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A86434: 7E1C02FA FF016105
	v_cndmask_b32_e64 v15, -v5, v5, s0                         // 000000A8643C: D501000F 20020B05
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A86444: BF870004
	v_mov_b32_dpp v12, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A86448: 7E1802FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 000000A86450: D5010008 200A1108
	v_mov_b32_dpp v13, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A86458: 7E1A02FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s2                       // 000000A86460: D501000B 200A170B
	v_mov_b32_dpp v2, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A86468: 7E0402FA FF016803
	v_mov_b32_dpp v4, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A86470: 7E0802FA FF016806
	v_add_f32_e32 v5, v8, v12                                  // 000000A86478: 060A1908
	v_mov_b32_dpp v8, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A8647C: 7E1002FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 000000A86484: D5010009 20021309
	v_add_f32_e32 v12, v15, v14                                // 000000A8648C: 06181D0F
	v_mov_b32_dpp v14, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A86490: 7E1C02FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, s0                       // 000000A86498: D501000A 2002150A
	v_mov_b32_dpp v15, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A864A0: 7E1E02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s0                          // 000000A864A8: D5010007 20020F07
	v_add_f32_e32 v8, v9, v8                                   // 000000A864B0: 06101109
	v_mov_b32_dpp v9, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A864B4: 7E1202FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 000000A864BC: D501000C 2006190C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A864C4: BF870214
	v_dual_add_f32 v10, v10, v14 :: v_dual_add_f32 v7, v7, v15 // 000000A864C8: C9081D0A 0A061F07
	v_mov_b32_dpp v14, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A864D0: 7E1C02FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s1                          // 000000A864D8: D5010008 20061108
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A864E0: BF870214
	v_add_f32_e32 v9, v12, v9                                  // 000000A864E4: 0612130C
	v_mov_b32_dpp v12, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A864E8: 7E1802FA FF01620A
	v_mov_b32_dpp v15, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A864F0: 7E1E02FA FF016207
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 000000A864F8: D501000A 2006150A
	v_cndmask_b32_e64 v16, -v7, v7, s1                         // 000000A86500: D5010010 20060F07
	v_dual_add_f32 v8, v8, v14 :: v_dual_add_f32 v7, v11, v13  // 000000A86508: C9081D08 08061B0B
	v_mov_b32_dpp v11, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A86510: 7E1602FA FF016409
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A86518: BF870214
	v_add_f32_e32 v10, v10, v12                                // 000000A8651C: 0614190A
	v_add_f32_e32 v12, v16, v15                                // 000000A86520: 06181F10
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A86524: BF870004
	v_mov_b32_dpp v13, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A86528: 7E1A02FA FF016408
	v_cndmask_b32_e64 v15, -v8, v8, s2                         // 000000A86530: D501000F 200A1108
	v_cndmask_b32_e64 v9, -v9, v9, s2                          // 000000A86538: D5010009 200A1309
	v_mov_b32_dpp v17, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A86540: 7E2202FA FF01640A
	v_mov_b32_dpp v18, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A86548: 7E2402FA FF01640C
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 000000A86550: D501000A 200A150A
	v_cndmask_b32_e64 v12, -v12, v12, s2                       // 000000A86558: D501000C 200A190C
	v_add_f32_e32 v14, v9, v11                                 // 000000A86560: 061C1709
	v_add_f32_e32 v16, v15, v13                                // 000000A86564: 06201B0F
	v_mov_b32_dpp v8, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A86568: 7E1002FA FF016807
	v_add_f32_e32 v15, v10, v17                                // 000000A86570: 061E230A
	v_add_f32_e32 v17, v12, v18                                // 000000A86574: 0622250C
	v_mov_b32_dpp v9, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A86578: 7E1202FA FF016805
	v_mov_b32_dpp v10, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A86580: 7E1402FA FF01680E
	v_mov_b32_dpp v11, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A86588: 7E1602FA FF016810
	v_mov_b32_dpp v12, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A86590: 7E1802FA FF01680F
	v_mov_b32_dpp v13, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A86598: 7E1A02FA FF016811
	s_and_b32 exec_lo, exec_lo, vcc_lo                         // 000000A865A0: 8B7E6A7E
	s_cbranch_execz 162                                        // 000000A865A4: BFA500A2 <_ZN7halogen12_GLOBAL__N_112k_ht_gemv_dnILi4ELi8ELi1EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x1a30>
	v_and_b32_e32 v0, 8, v0                                    // 000000A865A8: 36000088
	s_mul_i32 s0, s12, 0x1400                                  // 000000A865AC: 9600FF0C 00001400
	s_mul_hi_i32 s1, s12, 0x1400                               // 000000A865B4: 9701FF0C 00001400
	s_add_u32 s2, s10, s0                                      // 000000A865BC: 8002000A
	s_addc_u32 s3, s11, s1                                     // 000000A865C0: 8203010B
	v_cmp_eq_u32_e32 vcc_lo, 0, v0                             // 000000A865C4: 7C940080
	s_lshl_b32 s0, s13, 7                                      // 000000A865C8: 8400870D
	.long 0x7f243880                                           // 000000A865CC: 7F243880
	s_ashr_i32 s1, s0, 31                                      // 000000A865D0: 86019F00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A865D4: BF870009
	s_lshl_b64 s[0:1], s[0:1], 1                               // 000000A865D8: 84808100
	v_cndmask_b32_e64 v0, -v6, v6, vcc_lo                      // 000000A865DC: D5010000 21AA0D06
	v_lshlrev_b32_e32 v1, 1, v1                                // 000000A865E4: 30020281
	s_add_u32 s2, s2, s0                                       // 000000A865E8: 80020002
	s_addc_u32 s3, s3, s1                                      // 000000A865EC: 82030103
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000A865F0: D5010003 21AA0703
	v_add_f32_e32 v0, v0, v4                                   // 000000A865F8: 06000900
	s_clause 0x7                                               // 000000A865FC: BF850007
	global_load_d16_b16 v18, v1, s[2:3] offset:32              // 000000A86600: DC820020 12020001
	global_load_d16_b16 v19, v1, s[2:3]                        // 000000A86608: DC820000 13020001
	global_load_d16_b16 v20, v1, s[2:3] offset:64              // 000000A86610: DC820040 14020001
	global_load_d16_b16 v21, v1, s[2:3] offset:96              // 000000A86618: DC820060 15020001
	global_load_d16_b16 v22, v1, s[2:3] offset:128             // 000000A86620: DC820080 16020001
	global_load_d16_b16 v23, v1, s[2:3] offset:160             // 000000A86628: DC8200A0 17020001
	global_load_d16_b16 v24, v1, s[2:3] offset:192             // 000000A86630: DC8200C0 18020001
	global_load_d16_b16 v25, v1, s[2:3] offset:224             // 000000A86638: DC8200E0 19020001
	v_cndmask_b32_e64 v4, -v5, v5, vcc_lo                      // 000000A86640: D5010004 21AA0B05
	v_cndmask_b32_e64 v5, -v7, v7, vcc_lo                      // 000000A86648: D5010005 21AA0F07
	v_cndmask_b32_e64 v7, -v16, v16, vcc_lo                    // 000000A86650: D5010007 21AA2110
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 000000A86658: D501000E 21AA1D0E
	v_add_f32_e32 v2, v3, v2                                   // 000000A86660: 06040503
	v_mul_f32_e32 v0, 0x3db504f3, v0                           // 000000A86664: 100000FF 3DB504F3
	v_dual_add_f32 v3, v5, v8 :: v_dual_add_f32 v4, v4, v9     // 000000A8666C: C9081105 03041304
	v_cndmask_b32_e64 v16, -v17, v17, vcc_lo                   // 000000A86674: D5010010 21AA2311
	v_cndmask_b32_e64 v15, -v15, v15, vcc_lo                   // 000000A8667C: D501000F 21AA1F0F
	v_add_f32_e32 v5, v14, v10                                 // 000000A86684: 060A150E
	v_add_f32_e32 v7, v7, v11                                  // 000000A86688: 060E1707
	v_dual_mul_f32 v3, 0x3db504f3, v3 :: v_dual_mul_f32 v4, 0x3db504f3, v4// 000000A8668C: C8C606FF 030408FF 3DB504F3
	s_waitcnt vmcnt(4)                                         // 000000A86698: BF8913F7
	.long 0x7f2a3992                                           // 000000A8669C: 7F2A3992
	v_dual_add_f32 v8, v15, v12 :: v_dual_add_f32 v9, v16, v13 // 000000A866A0: C908190F 08081B10
	v_dual_mul_f32 v2, 0x3db504f3, v2 :: v_dual_mul_f32 v7, 0x3db504f3, v7// 000000A866A8: C8C604FF 02060EFF 3DB504F3
	v_mul_f32_e32 v5, 0x3db504f3, v5                           // 000000A866B4: 100A0AFF 3DB504F3
	.long 0x7f263992                                           // 000000A866BC: 7F263992
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A866C0: BF870004
	v_dual_mul_f32 v9, 0x3db504f3, v9 :: v_dual_mul_f32 v8, 0x3db504f3, v8// 000000A866C4: C8C612FF 090810FF 3DB504F3
	.long 0x7f283992                                           // 000000A866D0: 7F283992
	.long 0x7f0c3992                                           // 000000A866D4: 7F0C3992
	s_mul_i32 s3, s14, 0x1400                                  // 000000A866D8: 9603FF0E 00001400
	s_mul_hi_i32 s2, s14, 0x1400                               // 000000A866E0: 9702FF0E 00001400
	s_add_u32 s3, s8, s3                                       // 000000A866E8: 80030308
	s_addc_u32 s2, s9, s2                                      // 000000A866EC: 82020209
	s_add_u32 s0, s3, s0                                       // 000000A866F0: 80000003
	s_addc_u32 s1, s2, s1                                      // 000000A866F4: 82010102
	v_fma_mix_f32 v0, v18, v0, neg(0) op_sel_hi:[1,0,0]        // 000000A866F8: CC200000 8A020112
	v_fma_mix_f32 v2, v19, v2, neg(0) op_sel_hi:[1,0,0]        // 000000A86700: CC200002 8A020513
	v_fma_mix_f32 v3, v20, v3, neg(0) op_sel_hi:[1,0,0]        // 000000A86708: CC200003 8A020714
	v_fma_mix_f32 v4, v21, v4, neg(0) op_sel_hi:[1,0,0]        // 000000A86710: CC200004 8A020915
	s_waitcnt vmcnt(3)                                         // 000000A86718: BF890FF7
	v_fma_mix_f32 v5, v22, v5, neg(0) op_sel_hi:[1,0,0]        // 000000A8671C: CC200005 8A020B16
	.long 0x7e243980                                           // 000000A86724: 7E243980
	s_waitcnt vmcnt(2)                                         // 000000A86728: BF890BF7
	v_fma_mix_f32 v7, v23, v7, neg(0) op_sel_hi:[1,0,0]        // 000000A8672C: CC200007 8A020F17
	s_waitcnt vmcnt(1)                                         // 000000A86734: BF8907F7
	v_fma_mix_f32 v8, v24, v8, neg(0) op_sel_hi:[1,0,0]        // 000000A86738: CC200008 8A021118
	s_waitcnt vmcnt(0)                                         // 000000A86740: BF8903F7
	v_fma_mix_f32 v9, v25, v9, neg(0) op_sel_hi:[1,0,0]        // 000000A86744: CC200009 8A021319
	.long 0x7e0c3982                                           // 000000A8674C: 7E0C3982
	v_and_b32_e32 v10, 1, v18                                  // 000000A86750: 36142481
	.long 0x7e243984                                           // 000000A86754: 7E243984
	.long 0x7e263983                                           // 000000A86758: 7E263983
	.long 0x7e283985                                           // 000000A8675C: 7E283985
	.long 0x7e2a3988                                           // 000000A86760: 7E2A3988
	v_and_b32_e32 v6, 1, v6                                    // 000000A86764: 360C0C81
	v_and_b32_e32 v11, 1, v18                                  // 000000A86768: 36162481
	.long 0x7e243987                                           // 000000A8676C: 7E243987
	v_and_b32_e32 v12, 1, v19                                  // 000000A86770: 36182681
	v_and_b32_e32 v13, 1, v20                                  // 000000A86774: 361A2881
	v_and_b32_e32 v15, 1, v21                                  // 000000A86778: 361E2A81
	v_add3_u32 v2, v2, v6, 0x7fff                              // 000000A8677C: D6550002 03FE0D02 00007FFF
	v_and_b32_e32 v14, 1, v18                                  // 000000A86788: 361C2481
	.long 0x7e243989                                           // 000000A8678C: 7E243989
	v_add3_u32 v0, v0, v10, 0x7fff                             // 000000A86790: D6550000 03FE1500 00007FFF
	v_add3_u32 v3, v3, v12, 0x7fff                             // 000000A8679C: D6550003 03FE1903 00007FFF
	v_add3_u32 v4, v4, v11, 0x7fff                             // 000000A867A8: D6550004 03FE1704 00007FFF
	v_add3_u32 v5, v5, v13, 0x7fff                             // 000000A867B4: D6550005 03FE1B05 00007FFF
	v_and_b32_e32 v6, 1, v18                                   // 000000A867C0: 360C2481
	v_add3_u32 v8, v8, v15, 0x7fff                             // 000000A867C4: D6550008 03FE1F08 00007FFF
	v_add3_u32 v7, v7, v14, 0x7fff                             // 000000A867D0: D6550007 03FE1D07 00007FFF
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A867DC: BF870003
	v_add3_u32 v6, v9, v6, 0x7fff                              // 000000A867E0: D6550006 03FE0D09 00007FFF
	s_clause 0x7                                               // 000000A867EC: BF850007
	global_store_d16_hi_b16 v1, v2, s[0:1]                     // 000000A867F0: DC960000 00000201
	global_store_d16_hi_b16 v1, v0, s[0:1] offset:32           // 000000A867F8: DC960020 00000001
	global_store_d16_hi_b16 v1, v3, s[0:1] offset:64           // 000000A86800: DC960040 00000301
	global_store_d16_hi_b16 v1, v4, s[0:1] offset:96           // 000000A86808: DC960060 00000401
	global_store_d16_hi_b16 v1, v5, s[0:1] offset:128          // 000000A86810: DC960080 00000501
	global_store_d16_hi_b16 v1, v7, s[0:1] offset:160          // 000000A86818: DC9600A0 00000701
	global_store_d16_hi_b16 v1, v8, s[0:1] offset:192          // 000000A86820: DC9600C0 00000801
	global_store_d16_hi_b16 v1, v6, s[0:1] offset:224          // 000000A86828: DC9600E0 00000601
	s_endpgm                                                   // 000000A86830: BFB00000
		...

