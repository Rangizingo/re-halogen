0000000000fb3b00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi16ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi16ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000FB3B00: F4100100 F8000000
	v_and_b32_e32 v30, 15, v0                                  // 000000FB3B08: 363C008F
	v_lshrrev_b32_e32 v1, 4, v0                                // 000000FB3B0C: 32020084
	s_ashr_i32 s3, s2, 31                                      // 000000FB3B10: 86039F02
	v_lshlrev_b32_e32 v7, 2, v0                                // 000000FB3B14: 300E0082
	s_lshl_b64 s[0:1], s[2:3], 4                               // 000000FB3B18: 84808402
	v_lshlrev_b32_e32 v2, 2, v30                               // 000000FB3B1C: 30043C82
	v_dual_mov_b32 v24, s1 :: v_dual_lshlrev_b32 v3, 2, v1     // 000000FB3B20: CA220001 18020282
	v_or_b32_e32 v23, s0, v1                                   // 000000FB3B28: 382E0200
	.long 0x7f0c3880                                           // 000000FB3B2C: 7F0C3880
	s_waitcnt lgkmcnt(0)                                       // 000000FB3B30: BF89FC07
	s_clause 0x1                                               // 000000FB3B34: BF850001
	global_load_b32 v4, v2, s[4:5]                             // 000000FB3B38: DC520000 04040002
	global_load_b32 v3, v3, s[4:5]                             // 000000FB3B40: DC520000 03040003
	.long 0xd4540000                                           // 000000FB3B48: D4540000
	v_cndmask_b32_e32 v1, s12, v23, vcc_lo                     // 000000FB3B4C: 02022E0C
	s_add_u32 s22, s4, s16                                     // 000000FB3B50: 80161004
	s_addc_u32 s23, s5, s17                                    // 000000FB3B54: 82171105
	s_ashr_i32 s2, s11, 31                                     // 000000FB3B58: 86029F0B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000FB3B5C: BF870159
	s_lshr_b32 s2, s2, 27                                      // 000000FB3B60: 85029B02
	v_cndmask_b32_e64 v2, 0, v23, s0                           // 000000FB3B64: D5010002 00022E80
	v_cndmask_b32_e64 v5, 0, s1, s0                            // 000000FB3B6C: D5010005 00000280
	s_add_u32 s2, s10, s2                                      // 000000FB3B74: 8002020A
	s_addc_u32 s3, s11, 0                                      // 000000FB3B78: 8203800B
	.long 0xd72c0008                                           // 000000FB3B7C: D72C0008
	v_cndmask_b32_e32 v1, s19, v2, vcc_lo                      // 000000FB3B80: 02020413
	v_mad_u64_u32 v[0:1], null, s18, v2, 0                     // 000000FB3B84: D6FE7C00 02020412
	s_lshr_b64 s[20:21], s[2:3], 5                             // 000000FB3B8C: 85948502
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000FB3B90: BF870009
	s_cmpk_lt_i32 s20, 0x81                                    // 000000FB3B94: B3940081
	.long 0xd4440002                                           // 000000FB3B98: D4440002
	v_cndmask_b32_e32 v1, s20, v30, vcc_lo                     // 000000FB3B9C: 02023C14
	s_cselect_b32 s1, -1, 0                                    // 000000FB3BA0: 980180C1
	s_cmpk_gt_i32 s20, 0x80                                    // 000000FB3BA4: B2940080
	s_waitcnt vmcnt(1)                                         // 000000FB3BA8: BF8907F7
	v_bfe_u32 v9, v4, 16, 1                                    // 000000FB3BAC: D6100009 02052104
	s_waitcnt vmcnt(0)                                         // 000000FB3BB4: BF8903F7
	v_bfe_u32 v10, v3, 16, 1                                   // 000000FB3BB8: D610000A 02052103
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000FB3BC0: BF8701A2
	v_add3_u32 v4, v4, v9, 0x7fff                              // 000000FB3BC4: D6550004 03FE1304 00007FFF
	.long 0xd72c0009                                           // 000000FB3BD0: D72C0009
	v_cndmask_b32_e32 v1, s18, v5, vcc_lo                      // 000000FB3BD4: 02020A12
	v_add3_u32 v3, v3, v10, 0x7fff                             // 000000FB3BD8: D6550003 03FE1503 00007FFF
	s_cselect_b32 s18, -1, 0                                   // 000000FB3BE4: 981280C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000FB3BE8: BF8701A9
	s_and_b32 vcc_lo, exec_lo, s18                             // 000000FB3BEC: 8B6A127E
	.long 0x7e0c3984                                           // 000000FB3BF0: 7E0C3984
	v_add3_u32 v1, v1, v9, v8                                  // 000000FB3BF4: D6550001 04221301
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FB3BFC: BF8700A2
	v_and_or_b32 v6, 0xffff0000, v3, v6                        // 000000FB3C00: D6570006 041A06FF FFFF0000
	.long 0xd7000303                                           // 000000FB3C0C: D7000303
	v_cndmask_b32_e32 v1, s22, v0, vcc_lo                      // 000000FB3C10: 02020016
	v_add_co_ci_u32_e64 v4, null, s23, v1, s3                  // 000000FB3C14: D5207C04 000E0217
	ds_store_b32 v7, v6                                        // 000000FB3C1C: D8340000 00000607
	s_waitcnt lgkmcnt(0)                                       // 000000FB3C24: BF89FC07
	s_barrier                                                  // 000000FB3C28: BFBD0000
	buffer_gl0_inv                                             // 000000FB3C2C: E0AC0000 00000000
	s_cbranch_vccnz 144                                        // 000000FB3C34: BFA40090 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi16ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x378>
	v_dual_mov_b32 v8, 0 :: v_dual_mov_b32 v7, 0               // 000000FB3C38: CA100080 08060080
	s_and_saveexec_b32 s3, s2                                  // 000000FB3C40: BE832002
	s_cbranch_execz 10                                         // 000000FB3C44: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi16ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x170>
	v_lshlrev_b32_e32 v6, 1, v30                               // 000000FB3C48: 300C3C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB3C4C: BF870091
	.long 0xd7006a06                                           // 000000FB3C50: D7006A06
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 000000FB3C54: 02020D03
	v_add_co_ci_u32_e64 v7, null, 0, v4, vcc_lo                // 000000FB3C58: D5207C07 01AA0880
	global_load_d16_b16 v6, v[6:7], off                        // 000000FB3C60: DC820000 067C0006
	s_waitcnt vmcnt(0)                                         // 000000FB3C68: BF8903F7
	v_cvt_f32_f16_e32 v7, v6                                   // 000000FB3C6C: 7E0E1706
	s_or_b32 exec_lo, exec_lo, s3                              // 000000FB3C70: 8C7E037E
	v_or_b32_e32 v6, 16, v30                                   // 000000FB3C74: 380C3C90
	s_mov_b32 s2, exec_lo                                      // 000000FB3C78: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000FB3C7C: BF870001
	.long 0xd4c4007e                                           // 000000FB3C80: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 000000FB3C84: 02020C14
	s_cbranch_execz 10                                         // 000000FB3C88: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi16ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x1b4>
	v_lshlrev_b32_e32 v6, 1, v6                                // 000000FB3C8C: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB3C90: BF870091
	.long 0xd7006a08                                           // 000000FB3C94: D7006A08
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 000000FB3C98: 02020D03
	v_add_co_ci_u32_e64 v9, null, 0, v4, vcc_lo                // 000000FB3C9C: D5207C09 01AA0880
	global_load_d16_b16 v6, v[8:9], off                        // 000000FB3CA4: DC820000 067C0008
	s_waitcnt vmcnt(0)                                         // 000000FB3CAC: BF8903F7
	v_cvt_f32_f16_e32 v8, v6                                   // 000000FB3CB0: 7E101706
	s_or_b32 exec_lo, exec_lo, s2                              // 000000FB3CB4: 8C7E027E
	v_or_b32_e32 v6, 32, v30                                   // 000000FB3CB8: 380C3CA0
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v9, 0              // 000000FB3CBC: CA100080 0A080080
	s_mov_b32 s2, exec_lo                                      // 000000FB3CC4: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000FB3CC8: BF870002
	.long 0xd4c4007e                                           // 000000FB3CCC: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 000000FB3CD0: 02020C14
	s_cbranch_execz 10                                         // 000000FB3CD4: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi16ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x200>
	v_lshlrev_b32_e32 v6, 1, v6                                // 000000FB3CD8: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB3CDC: BF870091
	.long 0xd7006a0b                                           // 000000FB3CE0: D7006A0B
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 000000FB3CE4: 02020D03
	v_add_co_ci_u32_e64 v12, null, 0, v4, vcc_lo               // 000000FB3CE8: D5207C0C 01AA0880
	global_load_d16_b16 v6, v[11:12], off                      // 000000FB3CF0: DC820000 067C000B
	s_waitcnt vmcnt(0)                                         // 000000FB3CF8: BF8903F7
	v_cvt_f32_f16_e32 v9, v6                                   // 000000FB3CFC: 7E121706
	s_or_b32 exec_lo, exec_lo, s2                              // 000000FB3D00: 8C7E027E
	v_or_b32_e32 v6, 48, v30                                   // 000000FB3D04: 380C3CB0
	s_mov_b32 s2, exec_lo                                      // 000000FB3D08: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000FB3D0C: BF870001
	.long 0xd4c4007e                                           // 000000FB3D10: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 000000FB3D14: 02020C14
	s_cbranch_execz 10                                         // 000000FB3D18: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi16ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x244>
	v_lshlrev_b32_e32 v6, 1, v6                                // 000000FB3D1C: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB3D20: BF870091
	.long 0xd7006a0a                                           // 000000FB3D24: D7006A0A
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 000000FB3D28: 02020D03
	v_add_co_ci_u32_e64 v11, null, 0, v4, vcc_lo               // 000000FB3D2C: D5207C0B 01AA0880
	global_load_d16_b16 v6, v[10:11], off                      // 000000FB3D34: DC820000 067C000A
	s_waitcnt vmcnt(0)                                         // 000000FB3D3C: BF8903F7
	v_cvt_f32_f16_e32 v10, v6                                  // 000000FB3D40: 7E141706
	s_or_b32 exec_lo, exec_lo, s2                              // 000000FB3D44: 8C7E027E
	v_or_b32_e32 v6, 64, v30                                   // 000000FB3D48: 380C3CC0
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v11, 0             // 000000FB3D4C: CA100080 0C0A0080
	s_mov_b32 s2, exec_lo                                      // 000000FB3D54: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000FB3D58: BF870002
	.long 0xd4c4007e                                           // 000000FB3D5C: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 000000FB3D60: 02020C14
	s_cbranch_execz 10                                         // 000000FB3D64: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi16ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x290>
	v_lshlrev_b32_e32 v6, 1, v6                                // 000000FB3D68: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB3D6C: BF870091
	.long 0xd7006a0d                                           // 000000FB3D70: D7006A0D
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 000000FB3D74: 02020D03
	v_add_co_ci_u32_e64 v14, null, 0, v4, vcc_lo               // 000000FB3D78: D5207C0E 01AA0880
	global_load_d16_b16 v6, v[13:14], off                      // 000000FB3D80: DC820000 067C000D
	s_waitcnt vmcnt(0)                                         // 000000FB3D88: BF8903F7
	v_cvt_f32_f16_e32 v11, v6                                  // 000000FB3D8C: 7E161706
	s_or_b32 exec_lo, exec_lo, s2                              // 000000FB3D90: 8C7E027E
	v_or_b32_e32 v6, 0x50, v30                                 // 000000FB3D94: 380C3CFF 00000050
	s_mov_b32 s2, exec_lo                                      // 000000FB3D9C: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000FB3DA0: BF870001
	.long 0xd4c4007e                                           // 000000FB3DA4: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 000000FB3DA8: 02020C14
	s_cbranch_execz 10                                         // 000000FB3DAC: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi16ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x2d8>
	v_lshlrev_b32_e32 v6, 1, v6                                // 000000FB3DB0: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB3DB4: BF870091
	.long 0xd7006a0c                                           // 000000FB3DB8: D7006A0C
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 000000FB3DBC: 02020D03
	v_add_co_ci_u32_e64 v13, null, 0, v4, vcc_lo               // 000000FB3DC0: D5207C0D 01AA0880
	global_load_d16_b16 v6, v[12:13], off                      // 000000FB3DC8: DC820000 067C000C
	s_waitcnt vmcnt(0)                                         // 000000FB3DD0: BF8903F7
	v_cvt_f32_f16_e32 v12, v6                                  // 000000FB3DD4: 7E181706
	s_or_b32 exec_lo, exec_lo, s2                              // 000000FB3DD8: 8C7E027E
	v_or_b32_e32 v6, 0x60, v30                                 // 000000FB3DDC: 380C3CFF 00000060
	v_dual_mov_b32 v14, 0 :: v_dual_mov_b32 v13, 0             // 000000FB3DE4: CA100080 0E0C0080
	s_mov_b32 s2, exec_lo                                      // 000000FB3DEC: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000FB3DF0: BF870002
	.long 0xd4c4007e                                           // 000000FB3DF4: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 000000FB3DF8: 02020C14
	s_cbranch_execz 10                                         // 000000FB3DFC: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi16ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x328>
	v_lshlrev_b32_e32 v6, 1, v6                                // 000000FB3E00: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB3E04: BF870091
	.long 0xd7006a0f                                           // 000000FB3E08: D7006A0F
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 000000FB3E0C: 02020D03
	v_add_co_ci_u32_e64 v16, null, 0, v4, vcc_lo               // 000000FB3E10: D5207C10 01AA0880
	global_load_d16_b16 v6, v[15:16], off                      // 000000FB3E18: DC820000 067C000F
	s_waitcnt vmcnt(0)                                         // 000000FB3E20: BF8903F7
	v_cvt_f32_f16_e32 v13, v6                                  // 000000FB3E24: 7E1A1706
	s_or_b32 exec_lo, exec_lo, s2                              // 000000FB3E28: 8C7E027E
	v_or_b32_e32 v6, 0x70, v30                                 // 000000FB3E2C: 380C3CFF 00000070
	s_mov_b32 s2, exec_lo                                      // 000000FB3E34: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000FB3E38: BF870001
	.long 0xd4c4007e                                           // 000000FB3E3C: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 000000FB3E40: 02020C14
	s_cbranch_execz 10                                         // 000000FB3E44: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi16ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x370>
	v_lshlrev_b32_e32 v6, 1, v6                                // 000000FB3E48: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB3E4C: BF870091
	.long 0xd7006a0e                                           // 000000FB3E50: D7006A0E
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 000000FB3E54: 02020D03
	v_add_co_ci_u32_e64 v15, null, 0, v4, vcc_lo               // 000000FB3E58: D5207C0F 01AA0880
	global_load_d16_b16 v6, v[14:15], off                      // 000000FB3E60: DC820000 067C000E
	s_waitcnt vmcnt(0)                                         // 000000FB3E68: BF8903F7
	v_cvt_f32_f16_e32 v14, v6                                  // 000000FB3E6C: 7E1C1706
	s_or_b32 exec_lo, exec_lo, s2                              // 000000FB3E70: 8C7E027E
	s_branch 9                                                 // 000000FB3E74: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi16ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x39c>
	v_mov_b32_e32 v7, 0                                        // 000000FB3E78: 7E0E0280
	s_delay_alu instid0(VALU_DEP_1)                            // 000000FB3E7C: BF870001
	v_mov_b32_e32 v8, v7                                       // 000000FB3E80: 7E100307
	v_mov_b32_e32 v9, v7                                       // 000000FB3E84: 7E120307
	v_mov_b32_e32 v10, v7                                      // 000000FB3E88: 7E140307
	v_mov_b32_e32 v11, v7                                      // 000000FB3E8C: 7E160307
	v_mov_b32_e32 v12, v7                                      // 000000FB3E90: 7E180307
	v_mov_b32_e32 v13, v7                                      // 000000FB3E94: 7E1A0307
	v_mov_b32_e32 v14, v7                                      // 000000FB3E98: 7E1C0307
	s_add_u32 s2, s4, s14                                      // 000000FB3E9C: 80020E04
	s_addc_u32 s3, s5, s15                                     // 000000FB3EA0: 82030F05
	s_lshr_b32 s14, s11, 31                                    // 000000FB3EA4: 850E9F0B
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v44, 0             // 000000FB3EA8: CA100080 132C0080
	s_add_u32 s14, s10, s14                                    // 000000FB3EB0: 800E0E0A
	s_addc_u32 s15, s11, 0                                     // 000000FB3EB4: 820F800B
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v20, 0             // 000000FB3EB8: CA100080 1F140080
	s_ashr_i64 s[14:15], s[14:15], 1                           // 000000FB3EC0: 868E810E
	v_cndmask_b32_e64 v32, 0, 1, s18                           // 000000FB3EC4: D5010020 00490280
	v_mad_u64_u32 v[25:26], null, v2, s14, s[2:3]              // 000000FB3ECC: D6FE7C19 00081D02
	.long 0xd72c0002                                           // 000000FB3ED4: D72C0002
	v_cndmask_b32_e32 v0, v2, v15, vcc_lo                      // 000000FB3ED8: 02001F02
	.long 0xd72c0005                                           // 000000FB3EDC: D72C0005
	v_cndmask_b32_e32 v0, v5, v14, vcc_lo                      // 000000FB3EE0: 02001D05
	.long 0xd4440002                                           // 000000FB3EE4: D4440002
	v_cndmask_b32_e32 v1, s20, v30, vcc_lo                     // 000000FB3EE8: 02023C14
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v22, 0             // 000000FB3EEC: CA100080 15160080
	s_delay_alu instid0(VALU_DEP_3)                            // 000000FB3EF4: BF870003
	v_add3_u32 v33, v5, v26, v2                                // 000000FB3EF8: D6550021 040A3505
	s_and_saveexec_b32 s3, s2                                  // 000000FB3F00: BE832002
	s_cbranch_execz 21                                         // 000000FB3F04: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi16ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x45c>
	v_lshlrev_b32_e32 v2, 4, v30                               // 000000FB3F08: 30043C84
	v_mov_b32_e32 v44, 0                                       // 000000FB3F0C: 7E580280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB3F10: BF870092
	.long 0xd7006a05                                           // 000000FB3F14: D7006A05
	v_cndmask_b32_e32 v1, v25, v2, vcc_lo                      // 000000FB3F18: 02020519
	v_add_co_ci_u32_e64 v6, null, 0, v33, vcc_lo               // 000000FB3F1C: D5207C06 01AA4280
	s_and_not1_b32 vcc_lo, exec_lo, s18                        // 000000FB3F24: 916A127E
	global_load_b128 v[19:22], v[5:6], off                     // 000000FB3F28: DC5E0000 137C0005
	s_cbranch_vccnz 10                                         // 000000FB3F30: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi16ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x45c>
	v_lshlrev_b32_e32 v2, 1, v30                               // 000000FB3F34: 30043C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB3F38: BF870091
	.long 0xd7006a02                                           // 000000FB3F3C: D7006A02
	v_cndmask_b32_e32 v1, v3, v2, vcc_lo                       // 000000FB3F40: 02020503
	v_add_co_ci_u32_e64 v3, null, 0, v4, vcc_lo                // 000000FB3F44: D5207C03 01AA0880
	global_load_d16_b16 v2, v[2:3], off                        // 000000FB3F4C: DC820000 027C0002
	s_waitcnt vmcnt(0)                                         // 000000FB3F54: BF8903F7
	v_cvt_f32_f16_e32 v44, v2                                  // 000000FB3F58: 7E581702
	s_or_b32 exec_lo, exec_lo, s3                              // 000000FB3F5C: 8C7E037E
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v35, 0             // 000000FB3F60: CA100080 22220080
	v_dual_mov_b32 v36, 0 :: v_dual_mov_b32 v37, 0             // 000000FB3F68: CA100080 24240080
	v_dual_mov_b32 v38, 0 :: v_dual_mov_b32 v39, 0             // 000000FB3F70: CA100080 26260080
	v_mov_b32_e32 v40, 0                                       // 000000FB3F78: 7E500280
	s_and_saveexec_b32 s3, s2                                  // 000000FB3F7C: BE832002
	s_cbranch_execz 685                                        // 000000FB3F80: BFA502AD <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi16ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0xf38>
	v_dual_mov_b32 v27, 0 :: v_dual_lshlrev_b32 v2, 1, v30     // 000000FB3F84: CA220080 1B023C81
	.long 0xd7006a00                                           // 000000FB3F8C: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 000000FB3F90: 02020010
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000FB3F94: BF870191
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 000000FB3F98: D5207C01 01AA0211
	v_dual_mov_b32 v39, v27 :: v_dual_lshlrev_b32 v26, 5, v30  // 000000FB3FA0: CA22011B 271A3C85
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB3FA8: BF870093
	.long 0xd7006a00                                           // 000000FB3FAC: D7006A00
	v_cndmask_b32_e32 v1, v0, v2, vcc_lo                       // 000000FB3FB0: 02020500
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 000000FB3FB4: D5207C01 01AA0280
	v_lshl_or_b32 v41, v30, 4, 0x100                           // 000000FB3FBC: D6560029 03FD091E 00000100
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB3FC8: BF870093
	.long 0xd7006a00                                           // 000000FB3FCC: D7006A00
	v_cndmask_b32_e32 v1, s4, v0, vcc_lo                       // 000000FB3FD0: 02020004
	v_add_co_ci_u32_e64 v1, null, s5, v1, vcc_lo               // 000000FB3FD4: D5207C01 01AA0205
	v_dual_mov_b32 v42, v30 :: v_dual_mov_b32 v37, v27         // 000000FB3FDC: CA10011E 2A24011B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB3FE4: BF870093
	.long 0xd7006a1c                                           // 000000FB3FE8: D7006A1C
	v_cndmask_b32_e32 v0, v0, v160, vcc_lo                     // 000000FB3FEC: 02014100
	v_add_co_ci_u32_e64 v29, null, 0, v1, vcc_lo               // 000000FB3FF0: D5207C1D 01AA0280
	v_dual_mov_b32 v40, v27 :: v_dual_mov_b32 v43, v44         // 000000FB3FF8: CA10011B 282A012C
	v_mov_b32_e32 v38, v27                                     // 000000FB4000: 7E4C031B
	v_mov_b32_e32 v36, v27                                     // 000000FB4004: 7E48031B
	v_mov_b32_e32 v35, v27                                     // 000000FB4008: 7E46031B
	v_mov_b32_e32 v34, v27                                     // 000000FB400C: 7E44031B
	v_mov_b32_e32 v31, v27                                     // 000000FB4010: 7E3E031B
	s_mul_i32 s2, s11, 6                                       // 000000FB4014: 9602860B
	s_mul_hi_u32 s18, s10, 6                                   // 000000FB4018: 9692860A
	s_lshl_b64 s[14:15], s[10:11], 2                           // 000000FB401C: 848E820A
	s_add_i32 s18, s18, s2                                     // 000000FB4020: 81120212
	s_mul_i32 s17, s10, 6                                      // 000000FB4024: 9611860A
	s_mov_b32 s16, 0                                           // 000000FB4028: BE900080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 000000FB402C: 8484810A
	s_branch 612                                               // 000000FB4030: BFA00264 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi16ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0xec4>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000FB4034: 8C7E0A7E
	v_cndmask_b32_e64 v44, v44, v7, s1                         // 000000FB4038: D501002C 00060F2C
	v_cndmask_b32_e64 v1, v8, v9, s1                           // 000000FB4040: D5010001 00061308
	v_cndmask_b32_e64 v0, v7, v8, s1                           // 000000FB4048: D5010000 00061107
	v_dual_mov_b32 v7, v14 :: v_dual_and_b32 v8, 0xff, v19     // 000000FB4050: CA24010E 070826FF 000000FF
	v_cndmask_b32_e64 v6, v13, v14, s1                         // 000000FB405C: D5010006 00061D0D
	v_cndmask_b32_e64 v5, v12, v13, s1                         // 000000FB4064: D5010005 00061B0C
	v_cndmask_b32_e64 v4, v11, v12, s1                         // 000000FB406C: D5010004 0006190B
	v_cndmask_b32_e64 v3, v10, v11, s1                         // 000000FB4074: D5010003 0006170A
	v_lshlrev_b32_e32 v8, 2, v8                                // 000000FB407C: 30101082
	v_cndmask_b32_e64 v2, v9, v10, s1                          // 000000FB4080: D5010002 00061509
	s_and_b32 s2, exec_lo, s2                                  // 000000FB4088: 8B02027E
	v_add_nc_u32_e32 v41, 0x100, v41                           // 000000FB408C: 4A5252FF 00000100
	s_or_b32 s16, s2, s16                                      // 000000FB4094: 8C101002
	ds_load_b32 v14, v8                                        // 000000FB4098: D8D80000 0E000008
	v_lshrrev_b32_e32 v8, 6, v19                               // 000000FB40A0: 32102686
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000FB40A4: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000FB40A8: 361010FF 000003FC
	ds_load_b32 v55, v8                                        // 000000FB40B0: D8D80000 37000008
	v_lshrrev_b32_e32 v8, 14, v19                              // 000000FB40B8: 3210268E
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000FB40BC: 361010FF 000003FC
	ds_load_b32 v56, v8                                        // 000000FB40C4: D8D80000 38000008
	v_lshrrev_b32_e32 v8, 22, v19                              // 000000FB40CC: 32102696
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000FB40D0: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000FB40D4: 361010FF 000003FC
	ds_load_b32 v57, v8                                        // 000000FB40DC: D8D80000 39000008
	v_and_b32_e32 v8, 0xff, v20                                // 000000FB40E4: 361028FF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 000000FB40EC: 30101082
	ds_load_b32 v58, v8                                        // 000000FB40F0: D8D80000 3A000008
	v_lshrrev_b32_e32 v8, 6, v20                               // 000000FB40F8: 32102886
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000FB40FC: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000FB4100: 361010FF 000003FC
	ds_load_b32 v59, v8                                        // 000000FB4108: D8D80000 3B000008
	v_lshrrev_b32_e32 v8, 14, v20                              // 000000FB4110: 3210288E
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000FB4114: 361010FF 000003FC
	ds_load_b32 v60, v8                                        // 000000FB411C: D8D80000 3C000008
	v_lshrrev_b32_e32 v8, 22, v20                              // 000000FB4124: 32102896
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000FB4128: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000FB412C: 361010FF 000003FC
	ds_load_b32 v61, v8                                        // 000000FB4134: D8D80000 3D000008
	v_and_b32_e32 v8, 0xff, v21                                // 000000FB413C: 36102AFF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 000000FB4144: 30101082
	ds_load_b32 v62, v8                                        // 000000FB4148: D8D80000 3E000008
	v_lshrrev_b32_e32 v8, 6, v21                               // 000000FB4150: 32102A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000FB4154: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000FB4158: 361010FF 000003FC
	ds_load_b32 v63, v8                                        // 000000FB4160: D8D80000 3F000008
	v_lshrrev_b32_e32 v8, 14, v21                              // 000000FB4168: 32102A8E
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000FB416C: 361010FF 000003FC
	ds_load_b32 v64, v8                                        // 000000FB4174: D8D80000 40000008
	v_lshrrev_b32_e32 v8, 22, v21                              // 000000FB417C: 32102A96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000FB4180: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000FB4184: 361010FF 000003FC
	ds_load_b32 v65, v8                                        // 000000FB418C: D8D80000 41000008
	v_and_b32_e32 v8, 0xff, v22                                // 000000FB4194: 36102CFF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 000000FB419C: 30101082
	ds_load_b32 v66, v8                                        // 000000FB41A0: D8D80000 42000008
	v_lshrrev_b32_e32 v8, 6, v22                               // 000000FB41A8: 32102C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000FB41AC: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000FB41B0: 361010FF 000003FC
	ds_load_b32 v67, v8                                        // 000000FB41B8: D8D80000 43000008
	v_lshrrev_b32_e32 v8, 14, v22                              // 000000FB41C0: 32102C8E
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000FB41C4: 361010FF 000003FC
	ds_load_b32 v68, v8                                        // 000000FB41CC: D8D80000 44000008
	v_lshrrev_b32_e32 v8, 22, v22                              // 000000FB41D4: 32102C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000FB41D8: BF870141
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000FB41DC: 361010FF 000003FC
	ds_load_b32 v69, v8                                        // 000000FB41E4: D8D80000 45000008
	.long 0xd73c0008                                           // 000000FB41EC: D73C0008
	v_cndmask_b32_e32 v1, 1, v26, vcc_lo                       // 000000FB41F0: 02023481
	v_add_nc_u32_e32 v26, 0x200, v26                           // 000000FB41F4: 4A3434FF 00000200
	.long 0xd7006a0c                                           // 000000FB41FC: D7006A0C
	v_cndmask_b32_e32 v1, s6, v8, vcc_lo                       // 000000FB4200: 02021006
	s_delay_alu instid0(VALU_DEP_1)                            // 000000FB4204: BF870001
	v_add_co_ci_u32_e64 v13, null, s7, v9, vcc_lo              // 000000FB4208: D5207C0D 01AA1207
	s_clause 0x3                                               // 000000FB4210: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 000000FB4214: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 000000FB421C: DC5E0010 137C000C
	global_load_b128 v[45:48], v[12:13], off offset:32         // 000000FB4224: DC5E0020 2D7C000C
	global_load_b128 v[49:52], v[12:13], off offset:48         // 000000FB422C: DC5E0030 317C000C
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 000000FB4234: BF890CF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 000000FB4238: CC1A4008 1A021D08
	s_waitcnt lgkmcnt(14)                                      // 000000FB4240: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FB4244: BF8700A1
	v_dot2_f32_bf16 v8, v9, v55, v8                            // 000000FB4248: CC1A4008 1C226F09
	s_waitcnt lgkmcnt(13)                                      // 000000FB4250: BF89FCD7
	v_dot2_f32_bf16 v8, v10, v56, v8                           // 000000FB4254: CC1A4008 1C22710A
	s_waitcnt lgkmcnt(12)                                      // 000000FB425C: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FB4260: BF8700A1
	v_dot2_f32_bf16 v8, v11, v57, v8                           // 000000FB4264: CC1A4008 1C22730B
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 000000FB426C: BF8908B7
	v_dot2_f32_bf16 v8, v19, v58, v8                           // 000000FB4270: CC1A4008 1C227513
	s_waitcnt lgkmcnt(10)                                      // 000000FB4278: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FB427C: BF8700A1
	v_dot2_f32_bf16 v8, v20, v59, v8                           // 000000FB4280: CC1A4008 1C227714
	s_waitcnt lgkmcnt(9)                                       // 000000FB4288: BF89FC97
	v_dot2_f32_bf16 v8, v21, v60, v8                           // 000000FB428C: CC1A4008 1C227915
	s_waitcnt lgkmcnt(8)                                       // 000000FB4294: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FB4298: BF8700A1
	v_dot2_f32_bf16 v8, v22, v61, v8                           // 000000FB429C: CC1A4008 1C227B16
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 000000FB42A4: BF890477
	v_dot2_f32_bf16 v8, v45, v62, v8                           // 000000FB42A8: CC1A4008 1C227D2D
	s_waitcnt lgkmcnt(6)                                       // 000000FB42B0: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FB42B4: BF8700A1
	v_dot2_f32_bf16 v8, v46, v63, v8                           // 000000FB42B8: CC1A4008 1C227F2E
	s_waitcnt lgkmcnt(5)                                       // 000000FB42C0: BF89FC57
	v_dot2_f32_bf16 v8, v47, v64, v8                           // 000000FB42C4: CC1A4008 1C22812F
	s_waitcnt lgkmcnt(4)                                       // 000000FB42CC: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FB42D0: BF8700A1
	v_dot2_f32_bf16 v8, v48, v65, v8                           // 000000FB42D4: CC1A4008 1C228330
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 000000FB42DC: BF890037
	v_dot2_f32_bf16 v8, v49, v66, v8                           // 000000FB42E0: CC1A4008 1C228531
	.long 0xd7006a31                                           // 000000FB42E8: D7006A31
	v_cndmask_b32_e32 v0, v12, v4, vcc_lo                      // 000000FB42EC: 0200090C
	s_waitcnt lgkmcnt(2)                                       // 000000FB42F0: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000FB42F4: BF8701C2
	v_dot2_f32_bf16 v8, v50, v67, v8                           // 000000FB42F8: CC1A4008 1C228732
	v_add_co_ci_u32_e64 v50, null, s5, v13, vcc_lo             // 000000FB4300: D5207C32 01AA1A05
	.long 0xd7006a35                                           // 000000FB4308: D7006A35
	v_cndmask_b32_e32 v0, v12, v14, vcc_lo                     // 000000FB430C: 02001D0C
	s_waitcnt lgkmcnt(1)                                       // 000000FB4310: BF89FC17
	v_dot2_f32_bf16 v8, v51, v68, v8                           // 000000FB4314: CC1A4008 1C228933
	v_add_co_ci_u32_e64 v54, null, s15, v13, vcc_lo            // 000000FB431C: D5207C36 01AA1A0F
	.long 0xd7006a0c                                           // 000000FB4324: D7006A0C
	v_cndmask_b32_e32 v0, v12, v17, vcc_lo                     // 000000FB4328: 0200230C
	s_waitcnt lgkmcnt(0)                                       // 000000FB432C: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000FB4330: BF870123
	v_dot2_f32_bf16 v8, v52, v69, v8                           // 000000FB4334: CC1A4008 1C228B34
	v_add_co_ci_u32_e64 v13, null, s18, v13, vcc_lo            // 000000FB433C: D5207C0D 01AA1A12
	v_fmac_f32_e32 v40, v44, v8                                // 000000FB4344: 5650112C
	s_clause 0x3                                               // 000000FB4348: BF850003
	global_load_b128 v[8:11], v[49:50], off                    // 000000FB434C: DC5E0000 087C0031
	global_load_b128 v[19:22], v[49:50], off offset:16         // 000000FB4354: DC5E0010 137C0031
	global_load_b128 v[45:48], v[49:50], off offset:32         // 000000FB435C: DC5E0020 2D7C0031
	global_load_b128 v[49:52], v[49:50], off offset:48         // 000000FB4364: DC5E0030 317C0031
	s_waitcnt vmcnt(3)                                         // 000000FB436C: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 000000FB4370: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB4378: BF870091
	v_dot2_f32_bf16 v8, v9, v55, v8                            // 000000FB437C: CC1A4008 1C226F09
	v_dot2_f32_bf16 v8, v10, v56, v8                           // 000000FB4384: CC1A4008 1C22710A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FB438C: BF8700A1
	v_dot2_f32_bf16 v8, v11, v57, v8                           // 000000FB4390: CC1A4008 1C22730B
	s_waitcnt vmcnt(2)                                         // 000000FB4398: BF890BF7
	v_dot2_f32_bf16 v8, v19, v58, v8                           // 000000FB439C: CC1A4008 1C227513
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB43A4: BF870091
	v_dot2_f32_bf16 v8, v20, v59, v8                           // 000000FB43A8: CC1A4008 1C227714
	v_dot2_f32_bf16 v8, v21, v60, v8                           // 000000FB43B0: CC1A4008 1C227915
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FB43B8: BF8700A1
	v_dot2_f32_bf16 v8, v22, v61, v8                           // 000000FB43BC: CC1A4008 1C227B16
	s_waitcnt vmcnt(1)                                         // 000000FB43C4: BF8907F7
	v_dot2_f32_bf16 v8, v45, v62, v8                           // 000000FB43C8: CC1A4008 1C227D2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB43D0: BF870091
	v_dot2_f32_bf16 v8, v46, v63, v8                           // 000000FB43D4: CC1A4008 1C227F2E
	v_dot2_f32_bf16 v8, v47, v64, v8                           // 000000FB43DC: CC1A4008 1C22812F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FB43E4: BF8700A1
	v_dot2_f32_bf16 v8, v48, v65, v8                           // 000000FB43E8: CC1A4008 1C228330
	s_waitcnt vmcnt(0)                                         // 000000FB43F0: BF8903F7
	v_dot2_f32_bf16 v8, v49, v66, v8                           // 000000FB43F4: CC1A4008 1C228531
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB43FC: BF870091
	v_dot2_f32_bf16 v8, v50, v67, v8                           // 000000FB4400: CC1A4008 1C228732
	v_dot2_f32_bf16 v8, v51, v68, v8                           // 000000FB4408: CC1A4008 1C228933
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB4410: BF870091
	v_dot2_f32_bf16 v8, v52, v69, v8                           // 000000FB4414: CC1A4008 1C228B34
	v_fmac_f32_e32 v39, v44, v8                                // 000000FB441C: 564E112C
	s_clause 0x3                                               // 000000FB4420: BF850003
	global_load_b128 v[8:11], v[53:54], off                    // 000000FB4424: DC5E0000 087C0035
	global_load_b128 v[19:22], v[53:54], off offset:16         // 000000FB442C: DC5E0010 137C0035
	global_load_b128 v[45:48], v[53:54], off offset:32         // 000000FB4434: DC5E0020 2D7C0035
	global_load_b128 v[49:52], v[53:54], off offset:48         // 000000FB443C: DC5E0030 317C0035
	.long 0xd7006a35                                           // 000000FB4444: D7006A35
	v_cndmask_b32_e32 v0, v53, v14, vcc_lo                     // 000000FB4448: 02001D35
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000FB444C: BF8700B1
	v_add_co_ci_u32_e64 v54, null, s15, v54, vcc_lo            // 000000FB4450: D5207C36 01AA6C0F
	s_waitcnt vmcnt(3)                                         // 000000FB4458: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 000000FB445C: CC1A4008 1A021D08
	v_dot2_f32_bf16 v8, v9, v55, v8                            // 000000FB4464: CC1A4008 1C226F09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB446C: BF870091
	v_dot2_f32_bf16 v8, v10, v56, v8                           // 000000FB4470: CC1A4008 1C22710A
	v_dot2_f32_bf16 v8, v11, v57, v8                           // 000000FB4478: CC1A4008 1C22730B
	s_waitcnt vmcnt(2)                                         // 000000FB4480: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB4484: BF870091
	v_dot2_f32_bf16 v8, v19, v58, v8                           // 000000FB4488: CC1A4008 1C227513
	v_dot2_f32_bf16 v8, v20, v59, v8                           // 000000FB4490: CC1A4008 1C227714
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB4498: BF870091
	v_dot2_f32_bf16 v8, v21, v60, v8                           // 000000FB449C: CC1A4008 1C227915
	v_dot2_f32_bf16 v8, v22, v61, v8                           // 000000FB44A4: CC1A4008 1C227B16
	s_waitcnt vmcnt(1)                                         // 000000FB44AC: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB44B0: BF870091
	v_dot2_f32_bf16 v8, v45, v62, v8                           // 000000FB44B4: CC1A4008 1C227D2D
	v_dot2_f32_bf16 v8, v46, v63, v8                           // 000000FB44BC: CC1A4008 1C227F2E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB44C4: BF870091
	v_dot2_f32_bf16 v8, v47, v64, v8                           // 000000FB44C8: CC1A4008 1C22812F
	v_dot2_f32_bf16 v8, v48, v65, v8                           // 000000FB44D0: CC1A4008 1C228330
	s_waitcnt vmcnt(0)                                         // 000000FB44D8: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB44DC: BF870091
	v_dot2_f32_bf16 v8, v49, v66, v8                           // 000000FB44E0: CC1A4008 1C228531
	v_dot2_f32_bf16 v8, v50, v67, v8                           // 000000FB44E8: CC1A4008 1C228732
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB44F0: BF870091
	v_dot2_f32_bf16 v8, v51, v68, v8                           // 000000FB44F4: CC1A4008 1C228933
	v_dot2_f32_bf16 v8, v52, v69, v8                           // 000000FB44FC: CC1A4008 1C228B34
	s_delay_alu instid0(VALU_DEP_1)                            // 000000FB4504: BF870001
	v_fmac_f32_e32 v38, v44, v8                                // 000000FB4508: 564C112C
	s_clause 0x3                                               // 000000FB450C: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 000000FB4510: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 000000FB4518: DC5E0010 137C000C
	global_load_b128 v[45:48], v[12:13], off offset:32         // 000000FB4520: DC5E0020 2D7C000C
	global_load_b128 v[49:52], v[12:13], off offset:48         // 000000FB4528: DC5E0030 317C000C
	.long 0xd7006a0c                                           // 000000FB4530: D7006A0C
	v_cndmask_b32_e32 v0, v12, v14, vcc_lo                     // 000000FB4534: 02001D0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000FB4538: BF8700B1
	v_add_co_ci_u32_e64 v13, null, s15, v13, vcc_lo            // 000000FB453C: D5207C0D 01AA1A0F
	s_waitcnt vmcnt(3)                                         // 000000FB4544: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 000000FB4548: CC1A4008 1A021D08
	v_dot2_f32_bf16 v8, v9, v55, v8                            // 000000FB4550: CC1A4008 1C226F09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB4558: BF870091
	v_dot2_f32_bf16 v8, v10, v56, v8                           // 000000FB455C: CC1A4008 1C22710A
	v_dot2_f32_bf16 v8, v11, v57, v8                           // 000000FB4564: CC1A4008 1C22730B
	s_waitcnt vmcnt(2)                                         // 000000FB456C: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB4570: BF870091
	v_dot2_f32_bf16 v8, v19, v58, v8                           // 000000FB4574: CC1A4008 1C227513
	v_dot2_f32_bf16 v8, v20, v59, v8                           // 000000FB457C: CC1A4008 1C227714
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB4584: BF870091
	v_dot2_f32_bf16 v8, v21, v60, v8                           // 000000FB4588: CC1A4008 1C227915
	v_dot2_f32_bf16 v8, v22, v61, v8                           // 000000FB4590: CC1A4008 1C227B16
	s_waitcnt vmcnt(1)                                         // 000000FB4598: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB459C: BF870091
	v_dot2_f32_bf16 v8, v45, v62, v8                           // 000000FB45A0: CC1A4008 1C227D2D
	v_dot2_f32_bf16 v8, v46, v63, v8                           // 000000FB45A8: CC1A4008 1C227F2E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB45B0: BF870091
	v_dot2_f32_bf16 v8, v47, v64, v8                           // 000000FB45B4: CC1A4008 1C22812F
	v_dot2_f32_bf16 v8, v48, v65, v8                           // 000000FB45BC: CC1A4008 1C228330
	s_waitcnt vmcnt(0)                                         // 000000FB45C4: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB45C8: BF870091
	v_dot2_f32_bf16 v8, v49, v66, v8                           // 000000FB45CC: CC1A4008 1C228531
	v_dot2_f32_bf16 v8, v50, v67, v8                           // 000000FB45D4: CC1A4008 1C228732
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB45DC: BF870091
	v_dot2_f32_bf16 v8, v51, v68, v8                           // 000000FB45E0: CC1A4008 1C228933
	v_dot2_f32_bf16 v8, v52, v69, v8                           // 000000FB45E8: CC1A4008 1C228B34
	s_delay_alu instid0(VALU_DEP_1)                            // 000000FB45F0: BF870001
	v_fmac_f32_e32 v37, v44, v8                                // 000000FB45F4: 564A112C
	s_clause 0x3                                               // 000000FB45F8: BF850003
	global_load_b128 v[8:11], v[53:54], off                    // 000000FB45FC: DC5E0000 087C0035
	global_load_b128 v[19:22], v[53:54], off offset:16         // 000000FB4604: DC5E0010 137C0035
	global_load_b128 v[45:48], v[53:54], off offset:32         // 000000FB460C: DC5E0020 2D7C0035
	global_load_b128 v[49:52], v[53:54], off offset:48         // 000000FB4614: DC5E0030 317C0035
	s_waitcnt vmcnt(3)                                         // 000000FB461C: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 000000FB4620: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB4628: BF870091
	v_dot2_f32_bf16 v8, v9, v55, v8                            // 000000FB462C: CC1A4008 1C226F09
	v_dot2_f32_bf16 v8, v10, v56, v8                           // 000000FB4634: CC1A4008 1C22710A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FB463C: BF8700A1
	v_dot2_f32_bf16 v8, v11, v57, v8                           // 000000FB4640: CC1A4008 1C22730B
	s_waitcnt vmcnt(2)                                         // 000000FB4648: BF890BF7
	v_dot2_f32_bf16 v8, v19, v58, v8                           // 000000FB464C: CC1A4008 1C227513
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB4654: BF870091
	v_dot2_f32_bf16 v8, v20, v59, v8                           // 000000FB4658: CC1A4008 1C227714
	v_dot2_f32_bf16 v8, v21, v60, v8                           // 000000FB4660: CC1A4008 1C227915
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FB4668: BF8700A1
	v_dot2_f32_bf16 v8, v22, v61, v8                           // 000000FB466C: CC1A4008 1C227B16
	s_waitcnt vmcnt(1)                                         // 000000FB4674: BF8907F7
	v_dot2_f32_bf16 v8, v45, v62, v8                           // 000000FB4678: CC1A4008 1C227D2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB4680: BF870091
	v_dot2_f32_bf16 v8, v46, v63, v8                           // 000000FB4684: CC1A4008 1C227F2E
	v_dot2_f32_bf16 v8, v47, v64, v8                           // 000000FB468C: CC1A4008 1C22812F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FB4694: BF8700A1
	v_dot2_f32_bf16 v8, v48, v65, v8                           // 000000FB4698: CC1A4008 1C228330
	s_waitcnt vmcnt(0)                                         // 000000FB46A0: BF8903F7
	v_dot2_f32_bf16 v8, v49, v66, v8                           // 000000FB46A4: CC1A4008 1C228531
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB46AC: BF870091
	v_dot2_f32_bf16 v8, v50, v67, v8                           // 000000FB46B0: CC1A4008 1C228732
	v_dot2_f32_bf16 v8, v51, v68, v8                           // 000000FB46B8: CC1A4008 1C228933
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB46C0: BF870091
	v_dot2_f32_bf16 v8, v52, v69, v8                           // 000000FB46C4: CC1A4008 1C228B34
	v_fmac_f32_e32 v36, v44, v8                                // 000000FB46CC: 5648112C
	s_clause 0x3                                               // 000000FB46D0: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 000000FB46D4: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 000000FB46DC: DC5E0010 137C000C
	global_load_b128 v[45:48], v[12:13], off offset:32         // 000000FB46E4: DC5E0020 2D7C000C
	global_load_b128 v[49:52], v[12:13], off offset:48         // 000000FB46EC: DC5E0030 317C000C
	s_waitcnt vmcnt(3)                                         // 000000FB46F4: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 000000FB46F8: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB4700: BF870091
	v_dot2_f32_bf16 v8, v9, v55, v8                            // 000000FB4704: CC1A4008 1C226F09
	v_dot2_f32_bf16 v8, v10, v56, v8                           // 000000FB470C: CC1A4008 1C22710A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FB4714: BF8700A1
	v_dot2_f32_bf16 v8, v11, v57, v8                           // 000000FB4718: CC1A4008 1C22730B
	s_waitcnt vmcnt(2)                                         // 000000FB4720: BF890BF7
	v_dot2_f32_bf16 v8, v19, v58, v8                           // 000000FB4724: CC1A4008 1C227513
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB472C: BF870091
	v_dot2_f32_bf16 v8, v20, v59, v8                           // 000000FB4730: CC1A4008 1C227714
	v_dot2_f32_bf16 v8, v21, v60, v8                           // 000000FB4738: CC1A4008 1C227915
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FB4740: BF8700A1
	v_dot2_f32_bf16 v8, v22, v61, v8                           // 000000FB4744: CC1A4008 1C227B16
	s_waitcnt vmcnt(1)                                         // 000000FB474C: BF8907F7
	v_dot2_f32_bf16 v8, v45, v62, v8                           // 000000FB4750: CC1A4008 1C227D2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB4758: BF870091
	v_dot2_f32_bf16 v8, v46, v63, v8                           // 000000FB475C: CC1A4008 1C227F2E
	v_dot2_f32_bf16 v8, v47, v64, v8                           // 000000FB4764: CC1A4008 1C22812F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FB476C: BF8700A1
	v_dot2_f32_bf16 v8, v48, v65, v8                           // 000000FB4770: CC1A4008 1C228330
	s_waitcnt vmcnt(0)                                         // 000000FB4778: BF8903F7
	v_dot2_f32_bf16 v8, v49, v66, v8                           // 000000FB477C: CC1A4008 1C228531
	.long 0xd7006a31                                           // 000000FB4784: D7006A31
	v_cndmask_b32_e32 v0, v53, v14, vcc_lo                     // 000000FB4788: 02001D35
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000FB478C: BF8701B2
	v_dot2_f32_bf16 v8, v50, v67, v8                           // 000000FB4790: CC1A4008 1C228732
	v_add_co_ci_u32_e64 v50, null, s15, v54, vcc_lo            // 000000FB4798: D5207C32 01AA6C0F
	.long 0xd7006a0c                                           // 000000FB47A0: D7006A0C
	v_cndmask_b32_e32 v0, v12, v14, vcc_lo                     // 000000FB47A4: 02001D0C
	v_dot2_f32_bf16 v8, v51, v68, v8                           // 000000FB47A8: CC1A4008 1C228933
	v_add_co_ci_u32_e64 v13, null, s15, v13, vcc_lo            // 000000FB47B0: D5207C0D 01AA1A0F
	.long 0xd7006a1c                                           // 000000FB47B8: D7006A1C
	v_cndmask_b32_e32 v0, v28, v160, vcc_lo                    // 000000FB47BC: 0201411C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000FB47C0: BF870123
	v_dot2_f32_bf16 v8, v52, v69, v8                           // 000000FB47C4: CC1A4008 1C228B34
	v_add_co_ci_u32_e64 v29, null, 0, v29, vcc_lo              // 000000FB47CC: D5207C1D 01AA3A80
	v_fmac_f32_e32 v35, v44, v8                                // 000000FB47D4: 5646112C
	s_clause 0x3                                               // 000000FB47D8: BF850003
	global_load_b128 v[8:11], v[49:50], off                    // 000000FB47DC: DC5E0000 087C0031
	global_load_b128 v[19:22], v[49:50], off offset:16         // 000000FB47E4: DC5E0010 137C0031
	global_load_b128 v[45:48], v[49:50], off offset:32         // 000000FB47EC: DC5E0020 2D7C0031
	global_load_b128 v[49:52], v[49:50], off offset:48         // 000000FB47F4: DC5E0030 317C0031
	s_waitcnt vmcnt(3)                                         // 000000FB47FC: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 000000FB4800: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB4808: BF870091
	v_dot2_f32_bf16 v8, v9, v55, v8                            // 000000FB480C: CC1A4008 1C226F09
	v_dot2_f32_bf16 v8, v10, v56, v8                           // 000000FB4814: CC1A4008 1C22710A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FB481C: BF8700A1
	v_dot2_f32_bf16 v8, v11, v57, v8                           // 000000FB4820: CC1A4008 1C22730B
	s_waitcnt vmcnt(2)                                         // 000000FB4828: BF890BF7
	v_dot2_f32_bf16 v8, v19, v58, v8                           // 000000FB482C: CC1A4008 1C227513
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB4834: BF870091
	v_dot2_f32_bf16 v8, v20, v59, v8                           // 000000FB4838: CC1A4008 1C227714
	v_dot2_f32_bf16 v8, v21, v60, v8                           // 000000FB4840: CC1A4008 1C227915
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FB4848: BF8700A1
	v_dot2_f32_bf16 v8, v22, v61, v8                           // 000000FB484C: CC1A4008 1C227B16
	s_waitcnt vmcnt(1)                                         // 000000FB4854: BF8907F7
	v_dot2_f32_bf16 v8, v45, v62, v8                           // 000000FB4858: CC1A4008 1C227D2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB4860: BF870091
	v_dot2_f32_bf16 v8, v46, v63, v8                           // 000000FB4864: CC1A4008 1C227F2E
	v_dot2_f32_bf16 v8, v47, v64, v8                           // 000000FB486C: CC1A4008 1C22812F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FB4874: BF8700A1
	v_dot2_f32_bf16 v8, v48, v65, v8                           // 000000FB4878: CC1A4008 1C228330
	s_waitcnt vmcnt(0)                                         // 000000FB4880: BF8903F7
	v_dot2_f32_bf16 v8, v49, v66, v8                           // 000000FB4884: CC1A4008 1C228531
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB488C: BF870091
	v_dot2_f32_bf16 v8, v50, v67, v8                           // 000000FB4890: CC1A4008 1C228732
	v_dot2_f32_bf16 v8, v51, v68, v8                           // 000000FB4898: CC1A4008 1C228933
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB48A0: BF870091
	v_dot2_f32_bf16 v8, v52, v69, v8                           // 000000FB48A4: CC1A4008 1C228B34
	v_fmac_f32_e32 v34, v44, v8                                // 000000FB48AC: 5644112C
	s_clause 0x3                                               // 000000FB48B0: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 000000FB48B4: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 000000FB48BC: DC5E0010 137C000C
	global_load_b128 v[45:48], v[12:13], off offset:32         // 000000FB48C4: DC5E0020 2D7C000C
	global_load_b128 v[49:52], v[12:13], off offset:48         // 000000FB48CC: DC5E0030 317C000C
	s_waitcnt vmcnt(3)                                         // 000000FB48D4: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 000000FB48D8: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB48E0: BF870091
	v_dot2_f32_bf16 v8, v9, v55, v8                            // 000000FB48E4: CC1A4008 1C226F09
	v_dot2_f32_bf16 v8, v10, v56, v8                           // 000000FB48EC: CC1A4008 1C22710A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FB48F4: BF8700A1
	v_dot2_f32_bf16 v8, v11, v57, v8                           // 000000FB48F8: CC1A4008 1C22730B
	s_waitcnt vmcnt(2)                                         // 000000FB4900: BF890BF7
	v_dot2_f32_bf16 v8, v19, v58, v8                           // 000000FB4904: CC1A4008 1C227513
	v_mov_b32_e32 v19, v15                                     // 000000FB490C: 7E26030F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000FB4910: BF870122
	v_dot2_f32_bf16 v8, v20, v59, v8                           // 000000FB4914: CC1A4008 1C227714
	v_mov_b32_e32 v20, v16                                     // 000000FB491C: 7E280310
	v_dot2_f32_bf16 v8, v21, v60, v8                           // 000000FB4920: CC1A4008 1C227915
	v_mov_b32_e32 v21, v17                                     // 000000FB4928: 7E2A0311
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000FB492C: BF870132
	v_dot2_f32_bf16 v8, v22, v61, v8                           // 000000FB4930: CC1A4008 1C227B16
	v_mov_b32_e32 v22, v18                                     // 000000FB4938: 7E2C0312
	s_waitcnt vmcnt(1)                                         // 000000FB493C: BF8907F7
	v_dot2_f32_bf16 v8, v45, v62, v8                           // 000000FB4940: CC1A4008 1C227D2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB4948: BF870091
	v_dot2_f32_bf16 v8, v46, v63, v8                           // 000000FB494C: CC1A4008 1C227F2E
	v_dot2_f32_bf16 v8, v47, v64, v8                           // 000000FB4954: CC1A4008 1C22812F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FB495C: BF8700A1
	v_dot2_f32_bf16 v8, v48, v65, v8                           // 000000FB4960: CC1A4008 1C228330
	s_waitcnt vmcnt(0)                                         // 000000FB4968: BF8903F7
	v_dot2_f32_bf16 v8, v49, v66, v8                           // 000000FB496C: CC1A4008 1C228531
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB4974: BF870091
	v_dot2_f32_bf16 v8, v50, v67, v8                           // 000000FB4978: CC1A4008 1C228732
	v_dot2_f32_bf16 v8, v51, v68, v8                           // 000000FB4980: CC1A4008 1C228933
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000FB4988: BF870091
	v_dot2_f32_bf16 v8, v52, v69, v8                           // 000000FB498C: CC1A4008 1C228B34
	v_dual_fmac_f32 v31, v44, v8 :: v_dual_mov_b32 v14, v7     // 000000FB4994: C810112C 1F0E0107
	v_dual_mov_b32 v44, v43 :: v_dual_mov_b32 v13, v6          // 000000FB499C: CA10012B 2C0C0106
	v_dual_mov_b32 v12, v5 :: v_dual_mov_b32 v11, v4           // 000000FB49A4: CA100105 0C0A0104
	v_dual_mov_b32 v10, v3 :: v_dual_mov_b32 v9, v2            // 000000FB49AC: CA100103 0A080102
	v_dual_mov_b32 v8, v1 :: v_dual_mov_b32 v7, v0             // 000000FB49B4: CA100101 08060100
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 000000FB49BC: 917E107E
	s_cbranch_execz 28                                         // 000000FB49C0: BFA5001C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi16ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0xf34>
	s_waitcnt vmcnt(0)                                         // 000000FB49C4: BF8903F7
	v_dual_mov_b32 v15, v19 :: v_dual_add_nc_u32 v42, 16, v42  // 000000FB49C8: CA200113 0F2A5490
	v_dual_mov_b32 v16, v20 :: v_dual_mov_b32 v17, v21         // 000000FB49D0: CA100114 10100115
	v_mov_b32_e32 v18, v22                                     // 000000FB49D8: 7E240316
	s_delay_alu instid0(VALU_DEP_3)                            // 000000FB49DC: BF870003
	.long 0xd4430002                                           // 000000FB49E0: D4430002
	v_cndmask_b32_e32 v1, s20, v42, vcc_lo                     // 000000FB49E4: 02025414
	s_mov_b32 s10, exec_lo                                     // 000000FB49E8: BE8A007E
	.long 0xd4c4007e                                           // 000000FB49EC: D4C4007E
	v_cndmask_b32_e32 v1, s20, v42, vcc_lo                     // 000000FB49F0: 02025414
	s_cbranch_execz 64911                                      // 000000FB49F4: BFA5FD8F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi16ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x534>
	.long 0xd7006a00                                           // 000000FB49F8: D7006A00
	v_cndmask_b32_e32 v1, v25, v41, vcc_lo                     // 000000FB49FC: 02025319
	s_delay_alu instid0(VALU_DEP_1)                            // 000000FB4A00: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v33, vcc_lo               // 000000FB4A04: D5207C01 01AA4280
	v_cmp_ne_u32_e32 vcc_lo, 1, v32                            // 000000FB4A0C: 7C9A4081
	v_mov_b32_e32 v43, v44                                     // 000000FB4A10: 7E56032C
	global_load_b128 v[15:18], v[0:1], off                     // 000000FB4A14: DC5E0000 0F7C0000
	s_cbranch_vccnz 64901                                      // 000000FB4A1C: BFA4FD85 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi16ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x534>
	global_load_d16_b16 v0, v[28:29], off                      // 000000FB4A20: DC820000 007C001C
	s_waitcnt vmcnt(0)                                         // 000000FB4A28: BF8903F7
	v_cvt_f32_f16_e32 v43, v0                                  // 000000FB4A2C: 7E561700
	s_branch 64896                                             // 000000FB4A30: BFA0FD80 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi16ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x534>
	s_or_b32 exec_lo, exec_lo, s16                             // 000000FB4A34: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FB4A38: BF8700A9
	s_or_b32 exec_lo, exec_lo, s3                              // 000000FB4A3C: 8C7E037E
	.long 0xd71f0000                                           // 000000FB4A40: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000FB4A44: 020100C1
	v_xor_b32_e32 v1, 8, v0                                    // 000000FB4A48: 3A020088
	v_xor_b32_e32 v9, 4, v0                                    // 000000FB4A4C: 3A120084
	v_xor_b32_e32 v17, 2, v0                                   // 000000FB4A50: 3A220082
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000FB4A54: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v1                            // 000000FB4A58: 7C9802A0
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 000000FB4A5C: 02020300
	v_cmp_gt_u32_e32 vcc_lo, 32, v9                            // 000000FB4A60: 7C9812A0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000FB4A64: BF870002
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000FB4A68: 30020282
	ds_bpermute_b32 v2, v1, v40                                // 000000FB4A6C: DACC0000 02002801
	s_waitcnt lgkmcnt(0)                                       // 000000FB4A74: BF89FC07
	v_add_f32_e32 v2, v40, v2                                  // 000000FB4A78: 06040528
	ds_bpermute_b32 v8, v1, v34                                // 000000FB4A7C: DACC0000 08002201
	ds_bpermute_b32 v6, v1, v36                                // 000000FB4A84: DACC0000 06002401
	v_cndmask_b32_e32 v9, v0, v9, vcc_lo                       // 000000FB4A8C: 02121300
	ds_bpermute_b32 v3, v1, v39                                // 000000FB4A90: DACC0000 03002701
	ds_bpermute_b32 v4, v1, v38                                // 000000FB4A98: DACC0000 04002601
	ds_bpermute_b32 v5, v1, v37                                // 000000FB4AA0: DACC0000 05002501
	ds_bpermute_b32 v7, v1, v35                                // 000000FB4AA8: DACC0000 07002301
	ds_bpermute_b32 v1, v1, v31                                // 000000FB4AB0: DACC0000 01001F01
	v_cmp_gt_u32_e32 vcc_lo, 32, v17                           // 000000FB4AB8: 7C9822A0
	s_waitcnt lgkmcnt(6)                                       // 000000FB4ABC: BF89FC67
	v_dual_cndmask_b32 v17, v0, v17 :: v_dual_add_f32 v8, v34, v8// 000000FB4AC0: CA482300 11081122
	s_waitcnt lgkmcnt(5)                                       // 000000FB4AC8: BF89FC57
	v_dual_add_f32 v6, v36, v6 :: v_dual_lshlrev_b32 v9, 2, v9 // 000000FB4ACC: C9220D24 06081282
	s_waitcnt lgkmcnt(3)                                       // 000000FB4AD4: BF89FC37
	v_add_f32_e32 v4, v38, v4                                  // 000000FB4AD8: 06080926
	ds_bpermute_b32 v10, v9, v2                                // 000000FB4ADC: DACC0000 0A000209
	v_add_f32_e32 v3, v39, v3                                  // 000000FB4AE4: 06060727
	ds_bpermute_b32 v14, v9, v6                                // 000000FB4AE8: DACC0000 0E000609
	ds_bpermute_b32 v12, v9, v4                                // 000000FB4AF0: DACC0000 0C000409
	ds_bpermute_b32 v16, v9, v8                                // 000000FB4AF8: DACC0000 10000809
	s_waitcnt lgkmcnt(6)                                       // 000000FB4B00: BF89FC67
	v_add_f32_e32 v5, v37, v5                                  // 000000FB4B04: 060A0B25
	s_waitcnt lgkmcnt(5)                                       // 000000FB4B08: BF89FC57
	v_add_f32_e32 v7, v35, v7                                  // 000000FB4B0C: 060E0F23
	s_waitcnt lgkmcnt(3)                                       // 000000FB4B10: BF89FC37
	v_dual_add_f32 v1, v31, v1 :: v_dual_add_f32 v2, v2, v10   // 000000FB4B14: C908031F 01021502
	ds_bpermute_b32 v11, v9, v3                                // 000000FB4B1C: DACC0000 0B000309
	v_xor_b32_e32 v10, 1, v0                                   // 000000FB4B24: 3A140081
	s_waitcnt lgkmcnt(2)                                       // 000000FB4B28: BF89FC27
	v_add_f32_e32 v4, v4, v12                                  // 000000FB4B2C: 06081904
	ds_bpermute_b32 v13, v9, v5                                // 000000FB4B30: DACC0000 0D000509
	v_add_f32_e32 v6, v6, v14                                  // 000000FB4B38: 060C1D06
	ds_bpermute_b32 v15, v9, v7                                // 000000FB4B3C: DACC0000 0F000709
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 000000FB4B44: 7C9814A0
	s_waitcnt lgkmcnt(3)                                       // 000000FB4B48: BF89FC37
	v_add_f32_e32 v8, v8, v16                                  // 000000FB4B4C: 06102108
	ds_bpermute_b32 v9, v9, v1                                 // 000000FB4B50: DACC0000 09000109
	v_cndmask_b32_e32 v0, v0, v10, vcc_lo                      // 000000FB4B58: 02001500
	v_cmp_eq_u32_e32 vcc_lo, 0, v30                            // 000000FB4B5C: 7C943C80
	s_delay_alu instid0(VALU_DEP_2)                            // 000000FB4B60: BF870002
	v_lshlrev_b32_e32 v18, 2, v0                               // 000000FB4B64: 30240082
	v_lshlrev_b32_e32 v17, 2, v17                              // 000000FB4B68: 30222282
	s_and_b32 s0, vcc_lo, s0                                   // 000000FB4B6C: 8B00006A
	s_waitcnt lgkmcnt(3)                                       // 000000FB4B70: BF89FC37
	v_add_f32_e32 v3, v3, v11                                  // 000000FB4B74: 06061703
	ds_bpermute_b32 v12, v17, v4                               // 000000FB4B78: DACC0000 0C000411
	s_waitcnt lgkmcnt(0)                                       // 000000FB4B80: BF89FC07
	v_dual_add_f32 v9, v1, v9 :: v_dual_add_f32 v12, v4, v12   // 000000FB4B84: C9081301 090C1904
	ds_bpermute_b32 v1, v17, v2                                // 000000FB4B8C: DACC0000 01000211
	v_add_f32_e32 v7, v7, v15                                  // 000000FB4B94: 060E1F07
	ds_bpermute_b32 v11, v17, v3                               // 000000FB4B98: DACC0000 0B000311
	ds_bpermute_b32 v14, v17, v6                               // 000000FB4BA0: DACC0000 0E000611
	ds_bpermute_b32 v16, v17, v8                               // 000000FB4BA8: DACC0000 10000811
	s_waitcnt lgkmcnt(3)                                       // 000000FB4BB0: BF89FC37
	v_add_f32_e32 v10, v2, v1                                  // 000000FB4BB4: 06140302
	ds_bpermute_b32 v15, v17, v7                               // 000000FB4BB8: DACC0000 0F000711
	s_waitcnt lgkmcnt(0)                                       // 000000FB4BC0: BF89FC07
	v_dual_add_f32 v5, v5, v13 :: v_dual_add_f32 v2, v7, v15   // 000000FB4BC4: C9081B05 05021F07
	ds_bpermute_b32 v13, v17, v5                               // 000000FB4BCC: DACC0000 0D000511
	ds_bpermute_b32 v17, v17, v9                               // 000000FB4BD4: DACC0000 11000911
	v_add_f32_e32 v11, v3, v11                                 // 000000FB4BDC: 06161703
	v_add_f32_e32 v1, v6, v14                                  // 000000FB4BE0: 06021D06
	v_add_f32_e32 v3, v8, v16                                  // 000000FB4BE4: 06062108
	ds_bpermute_b32 v15, v18, v12                              // 000000FB4BE8: DACC0000 0F000C12
	ds_bpermute_b32 v7, v18, v2                                // 000000FB4BF0: DACC0000 07000212
	ds_bpermute_b32 v8, v18, v3                                // 000000FB4BF8: DACC0000 08000312
	s_waitcnt lgkmcnt(4)                                       // 000000FB4C00: BF89FC47
	v_add_f32_e32 v0, v5, v13                                  // 000000FB4C04: 06001B05
	s_waitcnt lgkmcnt(3)                                       // 000000FB4C08: BF89FC37
	v_add_f32_e32 v4, v9, v17                                  // 000000FB4C0C: 06082309
	ds_bpermute_b32 v13, v18, v10                              // 000000FB4C10: DACC0000 0D000A12
	ds_bpermute_b32 v14, v18, v11                              // 000000FB4C18: DACC0000 0E000B12
	ds_bpermute_b32 v6, v18, v1                                // 000000FB4C20: DACC0000 06000112
	ds_bpermute_b32 v5, v18, v0                                // 000000FB4C28: DACC0000 05000012
	ds_bpermute_b32 v9, v18, v4                                // 000000FB4C30: DACC0000 09000412
	s_and_saveexec_b32 s1, s0                                  // 000000FB4C38: BE812000
	s_cbranch_execz 272                                        // 000000FB4C3C: BFA50110 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi16ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x1580>
	s_waitcnt lgkmcnt(3)                                       // 000000FB4C40: BF89FC37
	v_dual_add_f32 v10, v10, v13 :: v_dual_add_f32 v11, v11, v14// 000000FB4C44: C9081B0A 0A0A1D0B
	v_add_f32_e32 v12, v12, v15                                // 000000FB4C4C: 06181F0C
	s_waitcnt lgkmcnt(2)                                       // 000000FB4C50: BF89FC27
	v_dual_add_f32 v8, v3, v8 :: v_dual_add_f32 v3, v1, v6     // 000000FB4C54: C9081103 08020D01
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000FB4C5C: BF8701C3
	v_dual_mul_f32 v10, 0xbfb8aa3b, v10 :: v_dual_mul_f32 v11, 0xbfb8aa3b, v11// 000000FB4C60: C8C614FF 0A0A16FF BFB8AA3B
	s_waitcnt lgkmcnt(1)                                       // 000000FB4C6C: BF89FC17
	v_dual_mul_f32 v12, 0xbfb8aa3b, v12 :: v_dual_add_f32 v5, v0, v5// 000000FB4C70: C8C818FF 0C040B00 BFB8AA3B
	.long 0xd73c0000                                           // 000000FB4C7C: D73C0000
	v_cndmask_b32_e32 v1, 2, v23, vcc_lo                       // 000000FB4C80: 02022E82
	v_exp_f32_e32 v10, v10                                     // 000000FB4C84: 7E144B0A
	v_exp_f32_e32 v11, v11                                     // 000000FB4C88: 7E164B0B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000FB4C8C: BF8700D2
	v_exp_f32_e32 v12, v12                                     // 000000FB4C90: 7E184B0C
	s_waitcnt lgkmcnt(0)                                       // 000000FB4C94: BF89FC07
	v_add_f32_e32 v4, v4, v9                                   // 000000FB4C98: 06081304
	v_dual_add_f32 v2, v2, v7 :: v_dual_mul_f32 v5, 0xbfb8aa3b, v5// 000000FB4C9C: C9060F02 02040AFF BFB8AA3B
	.long 0xd7006a00                                           // 000000FB4CA8: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 000000FB4CAC: 02020008
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 000000FB4CB0: D5207C01 01AA0209
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000FB4CB8: BF870317
	v_dual_add_f32 v6, 1.0, v10 :: v_dual_mul_f32 v3, 0xbfb8aa3b, v3// 000000FB4CBC: C90614F2 060206FF BFB8AA3B
	v_add_f32_e32 v7, 1.0, v11                                 // 000000FB4CC8: 060E16F2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000FB4CCC: BF8701A5
	v_add_f32_e32 v9, 1.0, v12                                 // 000000FB4CD0: 061218F2
	v_exp_f32_e32 v5, v5                                       // 000000FB4CD4: 7E0A4B05
	v_div_scale_f32 v10, null, v6, v6, 1.0                     // 000000FB4CD8: D6FC7C0A 03CA0D06
	v_exp_f32_e32 v3, v3                                       // 000000FB4CE0: 7E064B03
	v_div_scale_f32 v11, null, v7, v7, 1.0                     // 000000FB4CE4: D6FC7C0B 03CA0F07
	v_div_scale_f32 v12, null, v9, v9, 1.0                     // 000000FB4CEC: D6FC7C0C 03CA1309
	s_waitcnt vmcnt(0)                                         // 000000FB4CF4: BF8903F7
	v_div_scale_f32 v20, s0, 1.0, v7, 1.0                      // 000000FB4CF8: D6FC0014 03CA0EF2
	v_rcp_f32_e32 v13, v10                                     // 000000FB4D00: 7E1A550A
	v_div_scale_f32 v21, s1, 1.0, v9, 1.0                      // 000000FB4D04: D6FC0115 03CA12F2
	v_rcp_f32_e32 v14, v11                                     // 000000FB4D0C: 7E1C550B
	v_rcp_f32_e32 v15, v12                                     // 000000FB4D10: 7E1E550C
	s_lshl_b64 s[2:3], s[12:13], 2                             // 000000FB4D14: 8482820C
	s_lshl_b64 s[4:5], s[12:13], 3                             // 000000FB4D18: 8484830C
	v_mul_f32_e32 v8, 0xbfb8aa3b, v8                           // 000000FB4D1C: 101010FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(SKIP_1) | instid1(TRANS32_DEP_2)// 000000FB4D24: BF870327
	v_fma_f32 v17, -v10, v13, 1.0                              // 000000FB4D28: D6130011 23CA1B0A
	v_mul_f32_e32 v2, 0xbfb8aa3b, v2                           // 000000FB4D30: 100404FF BFB8AA3B
	v_fma_f32 v18, -v11, v14, 1.0                              // 000000FB4D38: D6130012 23CA1D0B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000FB4D40: BF870235
	v_fma_f32 v19, -v12, v15, 1.0                              // 000000FB4D44: D6130013 23CA1F0C
	v_add_f32_e32 v16, 1.0, v5                                 // 000000FB4D4C: 06200AF2
	v_div_scale_f32 v5, vcc_lo, 1.0, v6, 1.0                   // 000000FB4D50: D6FC6A05 03CA0CF2
	v_dual_fmac_f32 v13, v17, v13 :: v_dual_fmac_f32 v14, v18, v14// 000000FB4D58: C8001B11 0D0E1D12
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000FB4D60: BF8701B4
	v_fmac_f32_e32 v15, v19, v15                               // 000000FB4D64: 561E1F13
	v_exp_f32_e32 v17, v2                                      // 000000FB4D68: 7E224B02
	v_div_scale_f32 v18, null, v16, v16, 1.0                   // 000000FB4D6C: D6FC7C12 03CA2110
	v_dual_mul_f32 v19, v5, v13 :: v_dual_mul_f32 v22, v20, v14// 000000FB4D74: C8C61B05 13161D14
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000FB4D7C: BF8701A3
	v_mul_f32_e32 v23, v21, v15                                // 000000FB4D80: 102E1F15
	.long 0xd7000202                                           // 000000FB4D84: D7000202
	v_cndmask_b32_e32 v0, v0, v2, vcc_lo                       // 000000FB4D88: 02000500
	v_fma_f32 v26, -v10, v19, v5                               // 000000FB4D8C: D613001A 2416270A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000FB4D94: BF8701C4
	v_fma_f32 v27, -v11, v22, v20                              // 000000FB4D98: D613001B 24522D0B
	v_add_f32_e32 v24, 1.0, v3                                 // 000000FB4DA0: 063006F2
	v_rcp_f32_e32 v25, v18                                     // 000000FB4DA4: 7E325512
	v_fma_f32 v28, -v12, v23, v21                              // 000000FB4DA8: D613001C 24562F0C
	v_dual_fmac_f32 v19, v26, v13 :: v_dual_fmac_f32 v22, v27, v14// 000000FB4DB0: C8001B1A 13161D1B
	v_add_f32_e32 v17, 1.0, v17                                // 000000FB4DB8: 062222F2
	v_exp_f32_e32 v8, v8                                       // 000000FB4DBC: 7E104B08
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000FB4DC0: BF870193
	v_fmac_f32_e32 v23, v28, v15                               // 000000FB4DC4: 562E1F1C
	v_fma_f32 v5, -v10, v19, v5                                // 000000FB4DC8: D6130005 2416270A
	v_fma_f32 v10, -v11, v22, v20                              // 000000FB4DD0: D613000A 24522D0B
	v_add_co_ci_u32_e64 v3, null, s3, v1, s2                   // 000000FB4DD8: D5207C03 000A0203
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000FB4DE0: BF870216
	v_fma_f32 v27, -v18, v25, 1.0                              // 000000FB4DE4: D613001B 23CA3312
	v_div_fmas_f32 v5, v5, v13, v19                            // 000000FB4DEC: D6370005 044E1B05
	v_div_scale_f32 v13, null, v17, v17, 1.0                   // 000000FB4DF4: D6FC7C0D 03CA2311
	v_fma_f32 v11, -v12, v23, v21                              // 000000FB4DFC: D613000B 24562F0C
	s_mov_b32 vcc_lo, s0                                       // 000000FB4E04: BEEA0000
	v_fmac_f32_e32 v25, v27, v25                               // 000000FB4E08: 5632331B
	v_div_fmas_f32 v10, v10, v14, v22                          // 000000FB4E0C: D637000A 045A1D0A
	s_mov_b32 vcc_lo, s1                                       // 000000FB4E14: BEEA0001
	v_mul_f32_e32 v14, 0xbfb8aa3b, v4                          // 000000FB4E18: 101C08FF BFB8AA3B
	v_rcp_f32_e32 v19, v13                                     // 000000FB4E20: 7E26550D
	v_div_fmas_f32 v11, v11, v15, v23                          // 000000FB4E24: D637000B 045E1F0B
	v_div_fixup_f32 v5, v5, v6, 1.0                            // 000000FB4E2C: D6270005 03CA0D05
	.long 0xd7000004                                           // 000000FB4E34: D7000004
	v_cndmask_b32_e32 v0, v0, v4, vcc_lo                       // 000000FB4E38: 02000900
	v_div_scale_f32 v6, vcc_lo, 1.0, v16, 1.0                  // 000000FB4E3C: D6FC6A06 03CA20F2
	v_div_fixup_f32 v7, v10, v7, 1.0                           // 000000FB4E44: D6270007 03CA0F0A
	v_exp_f32_e32 v14, v14                                     // 000000FB4E4C: 7E1C4B0E
	v_div_fixup_f32 v9, v11, v9, 1.0                           // 000000FB4E50: D6270009 03CA130B
	global_store_b32 v[0:1], v5, off                           // 000000FB4E58: DC6A0000 007C0500
	v_add_co_ci_u32_e64 v5, null, s5, v1, s0                   // 000000FB4E60: D5207C05 00020205
	v_div_scale_f32 v26, null, v24, v24, 1.0                   // 000000FB4E68: D6FC7C1A 03CA3118
	v_mul_f32_e32 v10, v6, v25                                 // 000000FB4E70: 10143306
	s_clause 0x1                                               // 000000FB4E74: BF850001
	global_store_b32 v[2:3], v7, off                           // 000000FB4E78: DC6A0000 007C0702
	global_store_b32 v[4:5], v9, off                           // 000000FB4E80: DC6A0000 007C0904
	v_fma_f32 v3, -v13, v19, 1.0                               // 000000FB4E88: D6130003 23CA270D
	v_add_f32_e32 v8, 1.0, v8                                  // 000000FB4E90: 061010F2
	v_rcp_f32_e32 v12, v26                                     // 000000FB4E94: 7E18551A
	v_add_f32_e32 v9, 1.0, v14                                 // 000000FB4E98: 06121CF2
	v_fma_f32 v15, -v18, v10, v6                               // 000000FB4E9C: D613000F 241A1512
	v_fmac_f32_e32 v19, v3, v19                                // 000000FB4EA4: 56262703
	v_div_scale_f32 v7, null, v8, v8, 1.0                      // 000000FB4EA8: D6FC7C07 03CA1108
	v_div_scale_f32 v3, s1, 1.0, v17, 1.0                      // 000000FB4EB0: D6FC0103 03CA22F2
	v_mad_u64_u32 v[0:1], null, s12, 12, v[0:1]                // 000000FB4EB8: D6FE7C00 0401180C
	v_fmac_f32_e32 v10, v15, v25                               // 000000FB4EC0: 5614330F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000FB4EC4: BF870314
	v_rcp_f32_e32 v15, v7                                      // 000000FB4EC8: 7E1E5507
	v_fma_f32 v11, -v26, v12, 1.0                              // 000000FB4ECC: D613000B 23CA191A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000FB4ED4: BF870122
	v_fma_f32 v6, -v18, v10, v6                                // 000000FB4ED8: D6130006 241A1512
	v_div_scale_f32 v18, null, v9, v9, 1.0                     // 000000FB4EE0: D6FC7C12 03CA1309
	v_div_fmas_f32 v6, v6, v25, v10                            // 000000FB4EE8: D6370006 042A3306
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000FB4EF0: BF870312
	v_rcp_f32_e32 v10, v18                                     // 000000FB4EF4: 7E145512
	v_fma_f32 v20, -v7, v15, 1.0                               // 000000FB4EF8: D6130014 23CA1F07
	v_fmac_f32_e32 v12, v11, v12                               // 000000FB4F00: 5618190B
	v_div_scale_f32 v11, s0, 1.0, v24, 1.0                     // 000000FB4F04: D6FC000B 03CA30F2
	v_div_fixup_f32 v16, v6, v16, 1.0                          // 000000FB4F0C: D6270010 03CA2106
	s_mov_b32 vcc_lo, s0                                       // 000000FB4F14: BEEA0000
	v_fmac_f32_e32 v15, v20, v15                               // 000000FB4F18: 561E1F14
	v_div_scale_f32 v20, s2, 1.0, v8, 1.0                      // 000000FB4F1C: D6FC0214 03CA10F2
	v_mul_f32_e32 v2, v11, v12                                 // 000000FB4F24: 1004190B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000FB4F28: BF870115
	v_fma_f32 v21, -v18, v10, 1.0                              // 000000FB4F2C: D6130015 23CA1512
	v_fma_f32 v14, -v26, v2, v11                               // 000000FB4F34: D613000E 242E051A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000FB4F3C: BF870112
	v_fmac_f32_e32 v10, v21, v10                               // 000000FB4F40: 56141515
	v_fmac_f32_e32 v2, v14, v12                                // 000000FB4F44: 5604190E
	v_mul_f32_e32 v14, v3, v19                                 // 000000FB4F48: 101C2703
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000FB4F4C: BF870112
	v_fma_f32 v6, -v26, v2, v11                                // 000000FB4F50: D6130006 242E051A
	v_fma_f32 v11, -v13, v14, v3                               // 000000FB4F58: D613000B 240E1D0D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000FB4F60: BF870112
	v_div_fmas_f32 v6, v6, v12, v2                             // 000000FB4F64: D6370006 040A1906
	v_fmac_f32_e32 v14, v11, v19                               // 000000FB4F6C: 561C270B
	v_mul_f32_e32 v11, v20, v15                                // 000000FB4F70: 10161F14
	v_div_scale_f32 v12, s0, 1.0, v9, 1.0                      // 000000FB4F74: D6FC000C 03CA12F2
	v_mad_u64_u32 v[1:2], null, s13, 12, v[1:2]                // 000000FB4F7C: D6FE7C01 0405180D
	v_div_fixup_f32 v21, v6, v24, 1.0                          // 000000FB4F84: D6270015 03CA3106
	v_fma_f32 v2, -v13, v14, v3                                // 000000FB4F8C: D6130002 240E1D0D
	v_fma_f32 v3, -v7, v11, v20                                // 000000FB4F94: D6130003 24521707
	v_mul_f32_e32 v6, v12, v10                                 // 000000FB4F9C: 100C150C
	s_mov_b32 vcc_lo, s1                                       // 000000FB4FA0: BEEA0001
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000FB4FA4: BF870193
	v_div_fmas_f32 v13, v2, v19, v14                           // 000000FB4FA8: D637000D 043A2702
	v_fmac_f32_e32 v11, v3, v15                                // 000000FB4FB0: 56161F03
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FB4FB4: BF8700A3
	v_fma_f32 v14, -v18, v6, v12                               // 000000FB4FB8: D613000E 24320D12
	.long 0xd7006a02                                           // 000000FB4FC0: D7006A02
	v_cndmask_b32_e32 v0, v4, v4, vcc_lo                       // 000000FB4FC4: 02000904
	v_add_co_ci_u32_e64 v3, null, s5, v5, vcc_lo               // 000000FB4FC8: D5207C03 01AA0A05
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000FB4FD0: BF870214
	v_fma_f32 v4, -v7, v11, v20                                // 000000FB4FD4: D6130004 24521707
	v_fmac_f32_e32 v6, v14, v10                                // 000000FB4FDC: 560C150E
	s_mov_b32 vcc_lo, s2                                       // 000000FB4FE0: BEEA0002
	v_div_fixup_f32 v13, v13, v17, 1.0                         // 000000FB4FE4: D627000D 03CA230D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000FB4FEC: BF870193
	v_div_fmas_f32 v7, v4, v15, v11                            // 000000FB4FF0: D6370007 042E1F04
	v_fma_f32 v11, -v18, v6, v12                               // 000000FB4FF8: D613000B 24320D12
	.long 0xd7006a04                                           // 000000FB5000: D7006A04
	v_cndmask_b32_e32 v0, v0, v4, vcc_lo                       // 000000FB5004: 02000900
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000FB5008: BF8700D1
	v_add_co_ci_u32_e64 v5, null, s5, v1, vcc_lo               // 000000FB500C: D5207C05 01AA0205
	s_mov_b32 vcc_lo, s0                                       // 000000FB5014: BEEA0000
	v_div_fixup_f32 v12, v7, v8, 1.0                           // 000000FB5018: D627000C 03CA1107
	v_div_fmas_f32 v8, v11, v10, v6                            // 000000FB5020: D6370008 041A150B
	.long 0xd7006a06                                           // 000000FB5028: D7006A06
	v_cndmask_b32_e32 v0, v2, v4, vcc_lo                       // 000000FB502C: 02000902
	v_add_co_ci_u32_e64 v7, null, s5, v3, vcc_lo               // 000000FB5030: D5207C07 01AA0605
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000FB5038: BF8700A3
	v_div_fixup_f32 v10, v8, v9, 1.0                           // 000000FB503C: D627000A 03CA1308
	.long 0xd7006a08                                           // 000000FB5044: D7006A08
	v_cndmask_b32_e32 v0, v4, v4, vcc_lo                       // 000000FB5048: 02000904
	v_add_co_ci_u32_e64 v9, null, s5, v5, vcc_lo               // 000000FB504C: D5207C09 01AA0A05
	s_clause 0x4                                               // 000000FB5054: BF850004
	global_store_b32 v[0:1], v16, off                          // 000000FB5058: DC6A0000 007C1000
	global_store_b32 v[2:3], v21, off                          // 000000FB5060: DC6A0000 007C1502
	global_store_b32 v[4:5], v13, off                          // 000000FB5068: DC6A0000 007C0D04
	global_store_b32 v[6:7], v12, off                          // 000000FB5070: DC6A0000 007C0C06
	global_store_b32 v[8:9], v10, off                          // 000000FB5078: DC6A0000 007C0A08
	s_endpgm                                                   // 000000FB5080: BFB00000
		...

