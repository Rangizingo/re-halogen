00000000009b9800 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi4ELi8ELi2ELb0EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE>:
; _ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi4ELi8ELi2ELb0EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE():
	s_load_b256 s[4:11], s[0:1], null                          // 0000009B9800: F40C0100 F8000000
	s_mul_hi_i32 s3, s2, 0x66666667                            // 0000009B9808: 9703FF02 66666667
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000009B9810: BF8704A9
	s_lshr_b32 s12, s3, 31                                     // 0000009B9814: 850C9F03
	s_ashr_i32 s3, s3, 3                                       // 0000009B9818: 86038303
	s_add_i32 s12, s3, s12                                     // 0000009B981C: 810C0C03
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000009B9820: BF870499
	s_ashr_i32 s13, s12, 31                                    // 0000009B9824: 860D9F0C
	s_lshl_b64 s[14:15], s[12:13], 2                           // 0000009B9828: 848E820C
	s_waitcnt lgkmcnt(0)                                       // 0000009B982C: BF89FC07
	s_add_u32 s14, s8, s14                                     // 0000009B9830: 800E0E08
	s_addc_u32 s15, s9, s15                                    // 0000009B9834: 820F0F09
	s_load_b64 s[8:9], s[0:1], 0x20                            // 0000009B9838: F4040200 F8000020
	s_load_b32 s3, s[14:15], null                              // 0000009B9840: F40000C7 F8000000
	s_mov_b32 s0, exec_lo                                      // 0000009B9848: BE80007E
	v_cmpx_gt_u32_e32 0x50, v0                                 // 0000009B984C: 7D9800FF 00000050
	s_cbranch_execz 12                                         // 0000009B9854: BFA5000C <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi4ELi8ELi2ELb0EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x88>
	s_mul_i32 s1, s12, 0x500                                   // 0000009B9858: 9601FF0C 00000500
	v_lshlrev_b32_e32 v5, 4, v0                                // 0000009B9860: 300A0084
	s_mul_hi_i32 s13, s12, 0x500                               // 0000009B9864: 970DFF0C 00000500
	s_add_u32 s6, s6, s1                                       // 0000009B986C: 80060106
	s_addc_u32 s7, s7, s13                                     // 0000009B9870: 82070D07
	global_load_b128 v[1:4], v5, s[6:7]                        // 0000009B9874: DC5E0000 01060005
	s_waitcnt vmcnt(0)                                         // 0000009B987C: BF8903F7
	ds_store_b128 v5, v[1:4]                                   // 0000009B9880: DB7C0000 00000105
	s_or_b32 exec_lo, exec_lo, s0                              // 0000009B9888: 8C7E007E
	v_lshrrev_b32_e32 v7, 5, v0                                // 0000009B988C: 320E0085
	v_and_b32_e32 v9, 31, v0                                   // 0000009B9890: 3612009F
	s_mul_i32 s6, s12, 0xffffffec                              // 0000009B9894: 9606FF0C FFFFFFEC
	s_waitcnt lgkmcnt(0)                                       // 0000009B989C: BF89FC07
	s_mul_i32 s1, s3, 0xc8000                                  // 0000009B98A0: 9601FF03 000C8000
	s_add_i32 s6, s6, s2                                       // 0000009B98A8: 81060206
	v_mul_u32_u24_e32 v3, 5, v7                                // 0000009B98AC: 16060E85
	s_mul_hi_i32 s0, s3, 0xc8000                               // 0000009B98B0: 9700FF03 000C8000
	s_add_u32 s1, s4, s1                                       // 0000009B98B8: 80010104
	s_mul_i32 s2, s6, 0xa000                                   // 0000009B98BC: 9602FF06 0000A000
	v_lshlrev_b32_e32 v8, 2, v9                                // 0000009B98C4: 30101282
	v_min_u32_e32 v4, 35, v3                                   // 0000009B98C8: 260806A3
	s_addc_u32 s0, s5, s0                                      // 0000009B98CC: 82000005
	s_mul_hi_i32 s4, s6, 0xa000                                // 0000009B98D0: 9704FF06 0000A000
	s_add_u32 s1, s1, s2                                       // 0000009B98D8: 80010201
	s_addc_u32 s2, s0, s4                                      // 0000009B98DC: 82020400
	v_add_nc_u32_e32 v10, 5, v4                                // 0000009B98E0: 4A140885
	s_barrier                                                  // 0000009B98E4: BFBD0000
	buffer_gl0_inv                                             // 0000009B98E8: E0AC0000 00000000
	v_cmp_lt_u32_e32 vcc_lo, v3, v10                           // 0000009B98F0: 7C921503
	s_and_saveexec_b32 s4, vcc_lo                              // 0000009B98F4: BE84206A
	s_cbranch_execz 91                                         // 0000009B98F8: BFA5005B <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi4ELi8ELi2ELb0EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x268>
	.long 0xd7010001                                           // 0000009B98FC: D7010001
	v_cndmask_b32_e32 v0, v9, v129, vcc_lo                     // 0000009B9900: 02010309
	v_mul_u32_u24_e32 v6, 0x1400, v7                           // 0000009B9904: 160C0EFF 00001400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009B990C: BF870092
	v_cndmask_b32_e64 v1, v1, 31, s0                           // 0000009B9910: D5010001 00013F01
	.long 0xd44c0000                                           // 0000009B9918: D44C0000
	v_cndmask_b32_e32 v1, 31, v1, vcc_lo                       // 0000009B991C: 0202029F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000009B9920: BF8700B1
	v_cndmask_b32_e64 v5, 0xe1, 1, s0                          // 0000009B9924: D5010005 000102FF 000000E1
	v_mov_b32_e32 v2, 0                                        // 0000009B9930: 7E040280
	.long 0xd700000d                                           // 0000009B9934: D700000D
	v_cndmask_b32_e32 v1, s1, v6, vcc_lo                       // 0000009B9938: 02020C01
	v_add_co_ci_u32_e64 v14, null, s2, 0, s0                   // 0000009B993C: D5207C0E 00010002
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009B9944: BF870214
	v_add_nc_u32_e32 v5, v5, v1                                // 0000009B9948: 4A0A0305
	.long 0xd73c0001                                           // 0000009B994C: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000009B9950: 02020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000009B9954: BF8701A2
	v_lshlrev_b32_e32 v11, 24, v5                              // 0000009B9958: 30160A98
	v_bfe_i32 v12, v5, 7, 1                                    // 0000009B995C: D611000C 02050F05
	.long 0xd7000005                                           // 0000009B9964: D7000005
	v_cndmask_b32_e32 v1, v13, v1, vcc_lo                      // 0000009B9968: 0202030D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009B996C: BF870211
	v_add_co_ci_u32_e64 v6, null, v14, v2, s0                  // 0000009B9970: D5207C06 0002050E
	v_ashrrev_i32_e32 v11, 22, v11                             // 0000009B9978: 34161696
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009B997C: BF870091
	.long 0xd700000b                                           // 0000009B9980: D700000B
	v_cndmask_b32_e32 v1, v13, v11, vcc_lo                     // 0000009B9984: 0202170D
	v_add_co_ci_u32_e64 v12, null, v14, v12, s0                // 0000009B9988: D5207C0C 0002190E
	.long 0xd700000d                                           // 0000009B9990: D700000D
	v_cndmask_b32_e32 v1, v13, v8, vcc_lo                      // 0000009B9994: 0202110D
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009B9998: BF870001
	v_add_co_ci_u32_e64 v14, null, 0, v14, s0                  // 0000009B999C: D5207C0E 00021C80
	s_clause 0x17                                              // 0000009B99A4: BF850017
	global_load_b32 v1, v[5:6], off                            // 0000009B99A8: DC520000 017C0005
	global_load_b32 v57, v[5:6], off offset:128                // 0000009B99B0: DC520080 397C0005
	global_load_b32 v55, v[5:6], off offset:256                // 0000009B99B8: DC520100 377C0005
	global_load_b32 v51, v[5:6], off offset:384                // 0000009B99C0: DC520180 337C0005
	global_load_b32 v49, v[5:6], off offset:512                // 0000009B99C8: DC520200 317C0005
	global_load_b32 v46, v[5:6], off offset:640                // 0000009B99D0: DC520280 2E7C0005
	global_load_b32 v43, v[5:6], off offset:768                // 0000009B99D8: DC520300 2B7C0005
	global_load_b32 v22, v[5:6], off offset:896                // 0000009B99E0: DC520380 167C0005
	global_load_b32 v2, v[11:12], off                          // 0000009B99E8: DC520000 027C000B
	global_load_b32 v59, v[11:12], off offset:128              // 0000009B99F0: DC520080 3B7C000B
	global_load_b32 v56, v[11:12], off offset:256              // 0000009B99F8: DC520100 387C000B
	global_load_b32 v53, v[11:12], off offset:384              // 0000009B9A00: DC520180 357C000B
	global_load_b32 v50, v[11:12], off offset:512              // 0000009B9A08: DC520200 327C000B
	global_load_b32 v47, v[11:12], off offset:640              // 0000009B9A10: DC520280 2F7C000B
	global_load_b32 v44, v[11:12], off offset:768              // 0000009B9A18: DC520300 2C7C000B
	global_load_b32 v24, v[11:12], off offset:896              // 0000009B9A20: DC520380 187C000B
	global_load_b32 v60, v[13:14], off                         // 0000009B9A28: DC520000 3C7C000D
	global_load_b32 v58, v[13:14], off offset:128              // 0000009B9A30: DC520080 3A7C000D
	global_load_b32 v54, v[13:14], off offset:256              // 0000009B9A38: DC520100 367C000D
	global_load_b32 v52, v[13:14], off offset:384              // 0000009B9A40: DC520180 347C000D
	global_load_b32 v48, v[13:14], off offset:512              // 0000009B9A48: DC520200 307C000D
	global_load_b32 v45, v[13:14], off offset:640              // 0000009B9A50: DC520280 2D7C000D
	global_load_b32 v26, v[13:14], off offset:768              // 0000009B9A58: DC520300 1A7C000D
	global_load_b32 v19, v[13:14], off offset:896              // 0000009B9A60: DC520380 137C000D
	s_or_b32 exec_lo, exec_lo, s4                              // 0000009B9A68: 8C7E047E
	v_dual_mov_b32 v14, 0 :: v_dual_mov_b32 v11, 0             // 0000009B9A6C: CA100080 0E0A0080
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v13, 0             // 0000009B9A74: CA100080 0C0C0080
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v16, 0             // 0000009B9A7C: CA100080 0F100080
	v_dual_mov_b32 v17, 0 :: v_dual_mov_b32 v18, 0             // 0000009B9A84: CA100080 11120080
	s_and_saveexec_b32 s0, vcc_lo                              // 0000009B9A8C: BE80206A
	s_cbranch_execz 987                                        // 0000009B9A90: BFA503DB <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi4ELi8ELi2ELb0EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x1200>
	v_dual_mov_b32 v6, 0 :: v_dual_add_nc_u32 v11, -1, v0      // 0000009B9A94: CA200080 060A00C1
	v_and_b32_e32 v12, 16, v0                                  // 0000009B9A9C: 36180090
	v_add_nc_u32_e32 v5, 1, v3                                 // 0000009B9AA0: 4A0A0681
	v_sub_nc_u32_e32 v20, 0, v4                                // 0000009B9AA4: 4C280880
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000009B9AA8: BF870244
	v_and_b32_e32 v11, 31, v11                                 // 0000009B9AAC: 3616169F
	v_dual_mov_b32 v16, v6 :: v_dual_lshlrev_b32 v21, 2, v9    // 0000009B9AB0: CA220106 10141282
	v_mov_b32_e32 v14, v6                                      // 0000009B9AB8: 7E1C0306
	v_mov_b32_e32 v13, v6                                      // 0000009B9ABC: 7E1A0306
	v_dual_mov_b32 v18, v6 :: v_dual_lshlrev_b32 v25, 2, v11   // 0000009B9AC0: CA220106 12181682
	v_mov_b32_e32 v11, v6                                      // 0000009B9AC8: 7E160306
	v_lshl_or_b32 v23, v3, 5, v12                              // 0000009B9ACC: D6560017 04310B03
	v_mov_b32_e32 v12, v6                                      // 0000009B9AD4: 7E180306
	v_mov_b32_e32 v15, v6                                      // 0000009B9AD8: 7E1E0306
	v_mov_b32_e32 v17, v6                                      // 0000009B9ADC: 7E220306
	s_mov_b32 s4, 0                                            // 0000009B9AE0: BE840080
	s_mov_b32 s5, 0xdcd12d                                     // 0000009B9AE4: BE8500FF 00DCD12D
	s_movk_i32 s7, 0x83                                        // 0000009B9AEC: B0070083
	s_movk_i32 s13, 0x1eee                                     // 0000009B9AF0: B00D1EEE
	s_branch 906                                               // 0000009B9AF4: BFA0038A <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi4ELi8ELi2ELb0EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x1120>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000009B9AF8: 8C7E0E7E
	s_waitcnt vmcnt(15)                                        // 0000009B9AFC: BF893FF7
	v_alignbit_b32 v61, v1, v2, 16                             // 0000009B9B00: D616003D 02420501
	ds_load_b128 v[1:4], v23                                   // 0000009B9B08: DBFC0000 01000017
	s_waitcnt vmcnt(7)                                         // 0000009B9B10: BF891FF7
	v_bfe_u32 v62, v60, 12, 16                                 // 0000009B9B14: D610003E 0241193C
	v_bfe_u32 v63, v60, 8, 16                                  // 0000009B9B1C: D610003F 0241113C
	v_bfe_u32 v65, v60, 4, 16                                  // 0000009B9B24: D6100041 0241093C
	v_bfe_u32 v64, v61, 12, 16                                 // 0000009B9B2C: D6100040 0241193D
	v_mul_u32_u24_e32 v68, s5, v64                             // 0000009B9B34: 16888005
	v_mul_u32_u24_e32 v64, s7, v64                             // 0000009B9B38: 16808007
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000009B9B3C: BF8700C1
	v_lshl_add_u32 v64, v64, 24, v68                           // 0000009B9B40: D6460040 05113140
	v_bfe_u32 v66, v61, 8, 16                                  // 0000009B9B48: D6100042 0241113D
	v_mul_u32_u24_e32 v68, s5, v66                             // 0000009B9B50: 16888405
	v_mul_u32_u24_e32 v66, s7, v66                             // 0000009B9B54: 16848407
	v_lshl_add_u32 v66, v66, 24, v68                           // 0000009B9B58: D6460042 05113142
	v_sad_u8 v64, v64, 0, 0x6400                               // 0000009B9B60: D6220040 03FD0140 00006400
	v_bfe_u32 v67, v61, 4, 16                                  // 0000009B9B6C: D6100043 0241093D
	v_mul_u32_u24_e32 v68, s5, v67                             // 0000009B9B74: 16888605
	v_mul_u32_u24_e32 v67, s7, v67                             // 0000009B9B78: 16868607
	v_sad_u8 v66, v66, 0, 0x6400                               // 0000009B9B7C: D6220042 03FD0142 00006400
	v_and_b32_e32 v64, 0xffff, v64                             // 0000009B9B88: 368080FF 0000FFFF
	v_lshl_add_u32 v67, v67, 24, v68                           // 0000009B9B90: D6460043 05113143
	v_mul_u32_u24_e32 v68, s5, v62                             // 0000009B9B98: 16887C05
	v_mul_u32_u24_e32 v62, s7, v62                             // 0000009B9B9C: 167C7C07
	v_lshl_add_u32 v62, v62, 24, v68                           // 0000009B9BA0: D646003E 0511313E
	v_lshl_or_b32 v64, v66, 16, v64                            // 0000009B9BA8: D6560040 05012142
	v_sad_u8 v67, v67, 0, 0x6400                               // 0000009B9BB0: D6220043 03FD0143 00006400
	v_and_b32_e32 v60, 0xffff, v60                             // 0000009B9BBC: 367878FF 0000FFFF
	v_alignbit_b32 v57, v57, v59, 16                           // 0000009B9BC4: D6160039 02427739
	v_sad_u8 v62, v62, 0, 0x6400                               // 0000009B9BCC: D622003E 03FD013E 00006400
	v_pk_fma_f16 v64, v64, s13, 0xc931 op_sel_hi:[1,0,0]       // 0000009B9BD8: CC0E0040 0BFC1B40 0000C931
	v_and_b32_e32 v67, 0xffff, v67                             // 0000009B9BE4: 368686FF 0000FFFF
	s_waitcnt vmcnt(6)                                         // 0000009B9BEC: BF891BF7
	v_bfe_u32 v66, v58, 8, 16                                  // 0000009B9BF0: D6100042 0241113A
	v_alignbit_b32 v55, v55, v56, 16                           // 0000009B9BF8: D6160037 02427137
	v_and_b32_e32 v62, 0xffff, v62                             // 0000009B9C00: 367C7CFF 0000FFFF
	s_waitcnt lgkmcnt(0)                                       // 0000009B9C08: BF89FC07
	v_dot2acc_f32_f16 v18, v64, v1                             // 0000009B9C0C: 04240340
	v_and_b32_e32 v61, 0xffff, v61                             // 0000009B9C10: 367A7AFF 0000FFFF
	v_mul_u32_u24_e32 v68, s5, v61                             // 0000009B9C18: 16887A05
	v_mul_u32_u24_e32 v61, s7, v61                             // 0000009B9C1C: 167A7A07
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009B9C20: BF870001
	v_lshl_add_u32 v61, v61, 24, v68                           // 0000009B9C24: D646003D 0511313D
	v_mul_u32_u24_e32 v68, s5, v63                             // 0000009B9C2C: 16887E05
	v_mul_u32_u24_e32 v63, s7, v63                             // 0000009B9C30: 167E7E07
	v_lshl_add_u32 v63, v63, 24, v68                           // 0000009B9C34: D646003F 0511313F
	v_mul_u32_u24_e32 v68, s5, v65                             // 0000009B9C3C: 16888205
	v_sad_u8 v61, v61, 0, 0x6400                               // 0000009B9C40: D622003D 03FD013D 00006400
	v_mul_u32_u24_e32 v65, s7, v65                             // 0000009B9C4C: 16828207
	v_lshl_add_u32 v65, v65, 24, v68                           // 0000009B9C50: D6460041 05113141
	v_sad_u8 v63, v63, 0, 0x6400                               // 0000009B9C58: D622003F 03FD013F 00006400
	v_mul_u32_u24_e32 v68, s5, v60                             // 0000009B9C64: 16887805
	v_lshl_or_b32 v61, v61, 16, v67                            // 0000009B9C68: D656003D 050D213D
	v_mul_u32_u24_e32 v60, s7, v60                             // 0000009B9C70: 16787807
	v_sad_u8 v65, v65, 0, 0x6400                               // 0000009B9C74: D6220041 03FD0141 00006400
	v_lshl_add_u32 v60, v60, 24, v68                           // 0000009B9C80: D646003C 0511313C
	v_lshl_or_b32 v62, v63, 16, v62                            // 0000009B9C88: D656003E 04F9213F
	v_pk_fma_f16 v59, v61, s13, 0xc931 op_sel_hi:[1,0,0]       // 0000009B9C90: CC0E003B 0BFC1B3D 0000C931
	v_bfe_u32 v64, v57, 4, 16                                  // 0000009B9C9C: D6100040 02410939
	v_bfe_u32 v67, v58, 4, 16                                  // 0000009B9CA4: D6100043 0241093A
	v_sad_u8 v60, v60, 0, 0x6400                               // 0000009B9CAC: D622003C 03FD013C 00006400
	v_pk_fma_f16 v61, v62, s13, 0xc931 op_sel_hi:[1,0,0]       // 0000009B9CB8: CC0E003D 0BFC1B3E 0000C931
	v_bfe_u32 v62, v57, 12, 16                                 // 0000009B9CC4: D610003E 02411939
	v_dual_dot2acc_f32_f16 v18, v59, v2 :: v_dual_and_b32 v63, 0xffff, v65// 0000009B9CCC: CB24053B 123E82FF 0000FFFF
	v_mul_u32_u24_e32 v68, s5, v62                             // 0000009B9CD8: 16887C05
	v_mul_u32_u24_e32 v62, s7, v62                             // 0000009B9CDC: 167C7C07
	s_delay_alu instid0(VALU_DEP_2)                            // 0000009B9CE0: BF870002
	v_lshl_add_u32 v62, v62, 24, v68                           // 0000009B9CE4: D646003E 0511313E
	v_mul_u32_u24_e32 v68, s5, v64                             // 0000009B9CEC: 16888005
	v_mul_u32_u24_e32 v64, s7, v64                             // 0000009B9CF0: 16808007
	v_dot2acc_f32_f16 v18, v61, v3                             // 0000009B9CF4: 0424073D
	v_lshl_or_b32 v60, v60, 16, v63                            // 0000009B9CF8: D656003C 04FD213C
	v_bfe_u32 v63, v57, 8, 16                                  // 0000009B9D00: D610003F 02411139
	v_lshl_add_u32 v64, v64, 24, v68                           // 0000009B9D08: D6460040 05113140
	v_mul_u32_u24_e32 v68, s5, v63                             // 0000009B9D10: 16887E05
	v_mul_u32_u24_e32 v63, s7, v63                             // 0000009B9D14: 167E7E07
	v_sad_u8 v62, v62, 0, 0x6400                               // 0000009B9D18: D622003E 03FD013E 00006400
	v_lshl_add_u32 v63, v63, 24, v68                           // 0000009B9D24: D646003F 0511313F
	v_and_b32_e32 v57, 0xffff, v57                             // 0000009B9D2C: 367272FF 0000FFFF
	v_bfe_u32 v65, v58, 12, 16                                 // 0000009B9D34: D6100041 0241193A
	v_mul_u32_u24_e32 v68, s5, v57                             // 0000009B9D3C: 16887205
	v_mul_u32_u24_e32 v57, s7, v57                             // 0000009B9D40: 16727207
	s_delay_alu instid0(VALU_DEP_2)                            // 0000009B9D44: BF870002
	v_lshl_add_u32 v57, v57, 24, v68                           // 0000009B9D48: D6460039 05113139
	v_mul_u32_u24_e32 v68, s5, v65                             // 0000009B9D50: 16888205
	v_mul_u32_u24_e32 v65, s7, v65                             // 0000009B9D54: 16828207
	v_sad_u8 v64, v64, 0, 0x6400                               // 0000009B9D58: D6220040 03FD0140 00006400
	v_lshl_add_u32 v65, v65, 24, v68                           // 0000009B9D64: D6460041 05113141
	v_and_b32_e32 v62, 0xffff, v62                             // 0000009B9D6C: 367C7CFF 0000FFFF
	v_sad_u8 v63, v63, 0, 0x6400                               // 0000009B9D74: D622003F 03FD013F 00006400
	v_mul_u32_u24_e32 v68, s5, v66                             // 0000009B9D80: 16888405
	v_mul_u32_u24_e32 v66, s7, v66                             // 0000009B9D84: 16848407
	v_and_b32_e32 v64, 0xffff, v64                             // 0000009B9D88: 368080FF 0000FFFF
	v_sad_u8 v57, v57, 0, 0x6400                               // 0000009B9D90: D6220039 03FD0139 00006400
	v_sad_u8 v65, v65, 0, 0x6400                               // 0000009B9D9C: D6220041 03FD0141 00006400
	v_lshl_add_u32 v66, v66, 24, v68                           // 0000009B9DA8: D6460042 05113142
	v_lshl_or_b32 v62, v63, 16, v62                            // 0000009B9DB0: D656003E 04F9213F
	v_mul_u32_u24_e32 v68, s5, v67                             // 0000009B9DB8: 16888605
	v_lshl_or_b32 v57, v57, 16, v64                            // 0000009B9DBC: D6560039 05012139
	v_and_b32_e32 v63, 0xffff, v65                             // 0000009B9DC4: 367E82FF 0000FFFF
	v_sad_u8 v64, v66, 0, 0x6400                               // 0000009B9DCC: D6220040 03FD0142 00006400
	v_pk_fma_f16 v62, v62, s13, 0xc931 op_sel_hi:[1,0,0]       // 0000009B9DD8: CC0E003E 0BFC1B3E 0000C931
	v_mul_u32_u24_e32 v67, s7, v67                             // 0000009B9DE4: 16868607
	v_lshl_add_u32 v67, v67, 24, v68                           // 0000009B9DE8: D6460043 05113143
	v_pk_fma_f16 v57, v57, s13, 0xc931 op_sel_hi:[1,0,0]       // 0000009B9DF0: CC0E0039 0BFC1B39 0000C931
	v_lshl_or_b32 v63, v64, 16, v63                            // 0000009B9DFC: D656003F 04FD2140
	v_dual_dot2acc_f32_f16 v17, v62, v1 :: v_dual_and_b32 v58, 0xffff, v58// 0000009B9E04: CB24033E 113A74FF 0000FFFF
	v_mul_u32_u24_e32 v66, s5, v58                             // 0000009B9E10: 16847405
	v_mul_u32_u24_e32 v58, s7, v58                             // 0000009B9E14: 16747407
	v_sad_u8 v65, v67, 0, 0x6400                               // 0000009B9E18: D6220041 03FD0143 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 0000009B9E24: BF870002
	v_lshl_add_u32 v58, v58, 24, v66                           // 0000009B9E28: D646003A 0509313A
	v_pk_fma_f16 v56, v63, s13, 0xc931 op_sel_hi:[1,0,0]       // 0000009B9E30: CC0E0038 0BFC1B3F 0000C931
	v_dot2acc_f32_f16 v17, v57, v2                             // 0000009B9E3C: 04220539
	v_bfe_u32 v59, v55, 12, 16                                 // 0000009B9E40: D610003B 02411937
	v_pk_fma_f16 v57, v60, s13, 0xc931 op_sel_hi:[1,0,0]       // 0000009B9E48: CC0E0039 0BFC1B3C 0000C931
	v_sad_u8 v58, v58, 0, 0x6400                               // 0000009B9E54: D622003A 03FD013A 00006400
	v_mul_u32_u24_e32 v60, s5, v59                             // 0000009B9E60: 16787605
	v_dual_dot2acc_f32_f16 v17, v56, v3 :: v_dual_and_b32 v64, 0xffff, v65// 0000009B9E64: CB240738 114082FF 0000FFFF
	v_mul_u32_u24_e32 v59, s7, v59                             // 0000009B9E70: 16767607
	v_lshl_add_u32 v59, v59, 24, v60                           // 0000009B9E74: D646003B 04F1313B
	v_bfe_u32 v56, v55, 8, 16                                  // 0000009B9E7C: D6100038 02411137
	v_dot2acc_f32_f16 v18, v57, v4                             // 0000009B9E84: 04240939
	v_lshl_or_b32 v58, v58, 16, v64                            // 0000009B9E88: D656003A 0501213A
	v_mul_u32_u24_e32 v64, s5, v56                             // 0000009B9E90: 16807005
	v_mul_u32_u24_e32 v56, s7, v56                             // 0000009B9E94: 16707007
	v_sad_u8 v59, v59, 0, 0x6400                               // 0000009B9E98: D622003B 03FD013B 00006400
	v_lshl_add_u32 v56, v56, 24, v64                           // 0000009B9EA4: D6460038 05013138
	v_bfe_u32 v60, v55, 4, 16                                  // 0000009B9EAC: D610003C 02410937
	s_waitcnt vmcnt(5)                                         // 0000009B9EB4: BF8917F7
	v_bfe_u32 v61, v54, 12, 16                                 // 0000009B9EB8: D610003D 02411936
	v_mul_u32_u24_e32 v64, s5, v60                             // 0000009B9EC0: 16807805
	v_and_b32_e32 v59, 0xffff, v59                             // 0000009B9EC4: 367676FF 0000FFFF
	v_sad_u8 v56, v56, 0, 0x6400                               // 0000009B9ECC: D6220038 03FD0138 00006400
	v_mul_u32_u24_e32 v60, s7, v60                             // 0000009B9ED8: 16787807
	v_lshl_add_u32 v60, v60, 24, v64                           // 0000009B9EDC: D646003C 0501313C
	v_mul_u32_u24_e32 v64, s5, v61                             // 0000009B9EE4: 16807A05
	v_mul_u32_u24_e32 v61, s7, v61                             // 0000009B9EE8: 167A7A07
	v_lshl_or_b32 v56, v56, 16, v59                            // 0000009B9EEC: D6560038 04ED2138
	v_lshl_add_u32 v61, v61, 24, v64                           // 0000009B9EF4: D646003D 0501313D
	v_bfe_u32 v62, v54, 8, 16                                  // 0000009B9EFC: D610003E 02411136
	v_sad_u8 v60, v60, 0, 0x6400                               // 0000009B9F04: D622003C 03FD013C 00006400
	v_bfe_u32 v63, v54, 4, 16                                  // 0000009B9F10: D610003F 02410936
	v_pk_fma_f16 v56, v56, s13, 0xc931 op_sel_hi:[1,0,0]       // 0000009B9F18: CC0E0038 0BFC1B38 0000C931
	v_and_b32_e32 v55, 0xffff, v55                             // 0000009B9F24: 366E6EFF 0000FFFF
	v_sad_u8 v61, v61, 0, 0x6400                               // 0000009B9F2C: D622003D 03FD013D 00006400
	v_and_b32_e32 v59, 0xffff, v60                             // 0000009B9F38: 367678FF 0000FFFF
	v_alignbit_b32 v51, v51, v53, 16                           // 0000009B9F40: D6160033 02426B33
	v_dot2acc_f32_f16 v16, v56, v1                             // 0000009B9F48: 04200338
	v_mul_u32_u24_e32 v64, s5, v55                             // 0000009B9F4C: 16806E05
	v_mul_u32_u24_e32 v55, s7, v55                             // 0000009B9F50: 166E6E07
	v_lshl_add_u32 v55, v55, 24, v64                           // 0000009B9F54: D6460037 05013137
	v_mul_u32_u24_e32 v64, s5, v62                             // 0000009B9F5C: 16807C05
	v_mul_u32_u24_e32 v62, s7, v62                             // 0000009B9F60: 167C7C07
	v_lshl_add_u32 v62, v62, 24, v64                           // 0000009B9F64: D646003E 0501313E
	v_and_b32_e32 v60, 0xffff, v61                             // 0000009B9F6C: 36787AFF 0000FFFF
	v_sad_u8 v55, v55, 0, 0x6400                               // 0000009B9F74: D6220037 03FD0137 00006400
	v_bfe_u32 v56, v51, 12, 16                                 // 0000009B9F80: D6100038 02411933
	v_mul_u32_u24_e32 v65, s5, v56                             // 0000009B9F88: 16827005
	v_sad_u8 v61, v62, 0, 0x6400                               // 0000009B9F8C: D622003D 03FD013E 00006400
	v_mul_u32_u24_e32 v62, s5, v63                             // 0000009B9F98: 167C7E05
	v_mul_u32_u24_e32 v63, s7, v63                             // 0000009B9F9C: 167E7E07
	v_lshl_add_u32 v62, v63, 24, v62                           // 0000009B9FA0: D646003E 04F9313F
	v_lshl_or_b32 v55, v55, 16, v59                            // 0000009B9FA8: D6560037 04ED2137
	v_lshl_or_b32 v59, v61, 16, v60                            // 0000009B9FB0: D656003B 04F1213D
	v_mul_u32_u24_e32 v56, s7, v56                             // 0000009B9FB8: 16707007
	v_and_b32_e32 v54, 0xffff, v54                             // 0000009B9FBC: 366C6CFF 0000FFFF
	v_sad_u8 v60, v62, 0, 0x6400                               // 0000009B9FC4: D622003C 03FD013E 00006400
	v_lshl_add_u32 v56, v56, 24, v65                           // 0000009B9FD0: D6460038 05053138
	v_mul_u32_u24_e32 v61, s5, v54                             // 0000009B9FD8: 167A6C05
	v_mul_u32_u24_e32 v54, s7, v54                             // 0000009B9FDC: 166C6C07
	v_lshl_add_u32 v54, v54, 24, v61                           // 0000009B9FE0: D6460036 04F53136
	v_bfe_u32 v61, v51, 4, 16                                  // 0000009B9FE8: D610003D 02410933
	v_pk_fma_f16 v53, v59, s13, 0xc931 op_sel_hi:[1,0,0]       // 0000009B9FF0: CC0E0035 0BFC1B3B 0000C931
	v_and_b32_e32 v59, 0xffff, v60                             // 0000009B9FFC: 367678FF 0000FFFF
	v_bfe_u32 v60, v51, 8, 16                                  // 0000009BA004: D610003C 02411133
	v_mul_u32_u24_e32 v65, s5, v61                             // 0000009BA00C: 16827A05
	v_mul_u32_u24_e32 v61, s7, v61                             // 0000009BA010: 167A7A07
	v_pk_fma_f16 v55, v55, s13, 0xc931 op_sel_hi:[1,0,0]       // 0000009BA014: CC0E0037 0BFC1B37 0000C931
	v_lshl_add_u32 v61, v61, 24, v65                           // 0000009BA020: D646003D 0505313D
	v_mul_u32_u24_e32 v65, s5, v60                             // 0000009BA028: 16827805
	v_mul_u32_u24_e32 v60, s7, v60                             // 0000009BA02C: 16787807
	v_sad_u8 v56, v56, 0, 0x6400                               // 0000009BA030: D6220038 03FD0138 00006400
	v_lshl_add_u32 v60, v60, 24, v65                           // 0000009BA03C: D646003C 0505313C
	v_and_b32_e32 v51, 0xffff, v51                             // 0000009BA044: 366666FF 0000FFFF
	s_waitcnt vmcnt(4)                                         // 0000009BA04C: BF8913F7
	v_bfe_u32 v62, v52, 12, 16                                 // 0000009BA050: D610003E 02411934
	v_mul_u32_u24_e32 v65, s5, v51                             // 0000009BA058: 16826605
	v_mul_u32_u24_e32 v51, s7, v51                             // 0000009BA05C: 16666607
	v_sad_u8 v61, v61, 0, 0x6400                               // 0000009BA060: D622003D 03FD013D 00006400
	v_lshl_add_u32 v51, v51, 24, v65                           // 0000009BA06C: D6460033 05053133
	v_mul_u32_u24_e32 v65, s5, v62                             // 0000009BA074: 16827C05
	v_mul_u32_u24_e32 v62, s7, v62                             // 0000009BA078: 167C7C07
	v_dot2acc_f32_f16 v16, v55, v2                             // 0000009BA07C: 04200537
	v_lshl_add_u32 v62, v62, 24, v65                           // 0000009BA080: D646003E 0505313E
	v_and_b32_e32 v56, 0xffff, v56                             // 0000009BA088: 367070FF 0000FFFF
	v_sad_u8 v60, v60, 0, 0x6400                               // 0000009BA090: D622003C 03FD013C 00006400
	v_bfe_u32 v63, v52, 8, 16                                  // 0000009BA09C: D610003F 02411134
	v_bfe_u32 v64, v52, 4, 16                                  // 0000009BA0A4: D6100040 02410934
	v_mul_u32_u24_e32 v65, s5, v63                             // 0000009BA0AC: 16827E05
	v_mul_u32_u24_e32 v63, s7, v63                             // 0000009BA0B0: 167E7E07
	v_sad_u8 v51, v51, 0, 0x6400                               // 0000009BA0B4: D6220033 03FD0133 00006400
	v_lshl_add_u32 v63, v63, 24, v65                           // 0000009BA0C0: D646003F 0505313F
	v_mul_u32_u24_e32 v65, s5, v64                             // 0000009BA0C8: 16828005
	v_mul_u32_u24_e32 v64, s7, v64                             // 0000009BA0CC: 16808007
	v_dual_dot2acc_f32_f16 v16, v53, v3 :: v_dual_and_b32 v61, 0xffff, v61// 0000009BA0D0: CB240735 103C7AFF 0000FFFF
	v_sad_u8 v62, v62, 0, 0x6400                               // 0000009BA0DC: D622003E 03FD013E 00006400
	v_lshl_add_u32 v64, v64, 24, v65                           // 0000009BA0E8: D6460040 05053140
	v_lshl_or_b32 v56, v60, 16, v56                            // 0000009BA0F0: D6560038 04E1213C
	v_and_b32_e32 v52, 0xffff, v52                             // 0000009BA0F8: 366868FF 0000FFFF
	v_lshl_or_b32 v51, v51, 16, v61                            // 0000009BA100: D6560033 04F52133
	v_sad_u8 v61, v63, 0, 0x6400                               // 0000009BA108: D622003D 03FD013F 00006400
	v_mul_u32_u24_e32 v63, s5, v52                             // 0000009BA114: 167E6805
	v_mul_u32_u24_e32 v52, s7, v52                             // 0000009BA118: 16686807
	v_and_b32_e32 v60, 0xffff, v62                             // 0000009BA11C: 36787CFF 0000FFFF
	v_sad_u8 v62, v64, 0, 0x6400                               // 0000009BA124: D622003E 03FD0140 00006400
	v_lshl_add_u32 v52, v52, 24, v63                           // 0000009BA130: D6460034 04FD3134
	v_pk_fma_f16 v56, v56, s13, 0xc931 op_sel_hi:[1,0,0]       // 0000009BA138: CC0E0038 0BFC1B38 0000C931
	v_pk_fma_f16 v51, v51, s13, 0xc931 op_sel_hi:[1,0,0]       // 0000009BA144: CC0E0033 0BFC1B33 0000C931
	v_lshl_or_b32 v60, v61, 16, v60                            // 0000009BA150: D656003C 04F1213D
	v_and_b32_e32 v61, 0xffff, v62                             // 0000009BA158: 367A7CFF 0000FFFF
	v_sad_u8 v52, v52, 0, 0x6400                               // 0000009BA160: D6220034 03FD0134 00006400
	v_dot2acc_f32_f16 v15, v56, v1                             // 0000009BA16C: 041E0338
	v_sad_u8 v54, v54, 0, 0x6400                               // 0000009BA170: D6220036 03FD0136 00006400
	v_pk_fma_f16 v55, v60, s13, 0xc931 op_sel_hi:[1,0,0]       // 0000009BA17C: CC0E0037 0BFC1B3C 0000C931
	v_alignbit_b32 v49, v49, v50, 16                           // 0000009BA188: D6160031 02426531
	v_lshl_or_b32 v52, v52, 16, v61                            // 0000009BA190: D6560034 04F52134
	v_dot2acc_f32_f16 v15, v51, v2                             // 0000009BA198: 041E0533
	v_lshl_or_b32 v54, v54, 16, v59                            // 0000009BA19C: D6560036 04ED2136
	v_alignbit_b32 v46, v46, v47, 16                           // 0000009BA1A4: D616002E 02425F2E
	v_alignbit_b32 v43, v43, v44, 16                           // 0000009BA1AC: D616002B 0242592B
	v_pk_fma_f16 v50, v52, s13, 0xc931 op_sel_hi:[1,0,0]       // 0000009BA1B4: CC0E0032 0BFC1B34 0000C931
	v_dot2acc_f32_f16 v15, v55, v3                             // 0000009BA1C0: 041E0737
	v_pk_fma_f16 v51, v54, s13, 0xc931 op_sel_hi:[1,0,0]       // 0000009BA1C4: CC0E0033 0BFC1B36 0000C931
	v_bfe_u32 v52, v49, 12, 16                                 // 0000009BA1D0: D6100034 02411931
	v_mul_u32_u24_e32 v53, s5, v52                             // 0000009BA1D8: 166A6805
	v_mul_u32_u24_e32 v52, s7, v52                             // 0000009BA1DC: 16686807
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009BA1E0: BF870001
	v_lshl_add_u32 v52, v52, 24, v53                           // 0000009BA1E4: D6460034 04D53134
	v_dot2acc_f32_f16 v15, v50, v4                             // 0000009BA1EC: 041E0932
	v_bfe_u32 v50, v49, 8, 16                                  // 0000009BA1F0: D6100032 02411131
	v_dot2acc_f32_f16 v16, v51, v4                             // 0000009BA1F8: 04200933
	v_bfe_u32 v51, v49, 4, 16                                  // 0000009BA1FC: D6100033 02410931
	v_mul_u32_u24_e32 v56, s5, v50                             // 0000009BA204: 16706405
	v_mul_u32_u24_e32 v50, s7, v50                             // 0000009BA208: 16646407
	v_lshl_add_u32 v50, v50, 24, v56                           // 0000009BA20C: D6460032 04E13132
	v_mul_u32_u24_e32 v56, s5, v51                             // 0000009BA214: 16706605
	v_mul_u32_u24_e32 v51, s7, v51                             // 0000009BA218: 16666607
	v_sad_u8 v52, v52, 0, 0x6400                               // 0000009BA21C: D6220034 03FD0134 00006400
	v_lshl_add_u32 v51, v51, 24, v56                           // 0000009BA228: D6460033 04E13133
	s_waitcnt vmcnt(3)                                         // 0000009BA230: BF890FF7
	v_bfe_u32 v53, v48, 12, 16                                 // 0000009BA234: D6100035 02411930
	v_and_b32_e32 v49, 0xffff, v49                             // 0000009BA23C: 366262FF 0000FFFF
	v_mul_u32_u24_e32 v56, s5, v53                             // 0000009BA244: 16706A05
	v_mul_u32_u24_e32 v53, s7, v53                             // 0000009BA248: 166A6A07
	s_delay_alu instid0(VALU_DEP_2)                            // 0000009BA24C: BF870002
	v_lshl_add_u32 v53, v53, 24, v56                           // 0000009BA250: D6460035 04E13135
	v_mul_u32_u24_e32 v56, s5, v49                             // 0000009BA258: 16706205
	v_mul_u32_u24_e32 v49, s7, v49                             // 0000009BA25C: 16626207
	v_and_b32_e32 v52, 0xffff, v52                             // 0000009BA260: 366868FF 0000FFFF
	v_sad_u8 v50, v50, 0, 0x6400                               // 0000009BA268: D6220032 03FD0132 00006400
	v_sad_u8 v51, v51, 0, 0x6400                               // 0000009BA274: D6220033 03FD0133 00006400
	v_lshl_add_u32 v49, v49, 24, v56                           // 0000009BA280: D6460031 04E13131
	v_bfe_u32 v54, v48, 8, 16                                  // 0000009BA288: D6100036 02411130
	v_mul_u32_u24_e32 v56, s5, v54                             // 0000009BA290: 16706C05
	v_mul_u32_u24_e32 v54, s7, v54                             // 0000009BA294: 166C6C07
	v_sad_u8 v53, v53, 0, 0x6400                               // 0000009BA298: D6220035 03FD0135 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 0000009BA2A4: BF870002
	v_lshl_add_u32 v54, v54, 24, v56                           // 0000009BA2A8: D6460036 04E13136
	v_and_b32_e32 v51, 0xffff, v51                             // 0000009BA2B0: 366666FF 0000FFFF
	v_sad_u8 v49, v49, 0, 0x6400                               // 0000009BA2B8: D6220031 03FD0131 00006400
	v_lshl_or_b32 v50, v50, 16, v52                            // 0000009BA2C4: D6560032 04D12132
	v_and_b32_e32 v53, 0xffff, v53                             // 0000009BA2CC: 366A6AFF 0000FFFF
	v_sad_u8 v54, v54, 0, 0x6400                               // 0000009BA2D4: D6220036 03FD0136 00006400
	v_bfe_u32 v55, v48, 4, 16                                  // 0000009BA2E0: D6100037 02410930
	v_lshl_or_b32 v49, v49, 16, v51                            // 0000009BA2E8: D6560031 04CD2131
	v_pk_fma_f16 v50, v50, s13, 0xc931 op_sel_hi:[1,0,0]       // 0000009BA2F0: CC0E0032 0BFC1B32 0000C931
	v_mul_u32_u24_e32 v56, s5, v55                             // 0000009BA2FC: 16706E05
	v_mul_u32_u24_e32 v55, s7, v55                             // 0000009BA300: 166E6E07
	v_lshl_add_u32 v55, v55, 24, v56                           // 0000009BA304: D6460037 04E13137
	v_lshl_or_b32 v51, v54, 16, v53                            // 0000009BA30C: D6560033 04D52136
	v_pk_fma_f16 v47, v49, s13, 0xc931 op_sel_hi:[1,0,0]       // 0000009BA314: CC0E002F 0BFC1B31 0000C931
	v_dual_dot2acc_f32_f16 v13, v50, v1 :: v_dual_and_b32 v48, 0xffff, v48// 0000009BA320: CB240332 0D3060FF 0000FFFF
	v_mul_u32_u24_e32 v56, s5, v48                             // 0000009BA32C: 16706005
	v_mul_u32_u24_e32 v48, s7, v48                             // 0000009BA330: 16606007
	v_sad_u8 v55, v55, 0, 0x6400                               // 0000009BA334: D6220037 03FD0137 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 0000009BA340: BF870002
	v_lshl_add_u32 v48, v48, 24, v56                           // 0000009BA344: D6460030 04E13130
	v_pk_fma_f16 v49, v51, s13, 0xc931 op_sel_hi:[1,0,0]       // 0000009BA34C: CC0E0031 0BFC1B33 0000C931
	v_dot2acc_f32_f16 v13, v47, v2                             // 0000009BA358: 041A052F
	v_bfe_u32 v50, v46, 12, 16                                 // 0000009BA35C: D6100032 0241192E
	v_mul_u32_u24_e32 v56, s5, v50                             // 0000009BA364: 16706405
	v_sad_u8 v48, v48, 0, 0x6400                               // 0000009BA368: D6220030 03FD0130 00006400
	v_mul_u32_u24_e32 v50, s7, v50                             // 0000009BA374: 16646407
	v_dot2acc_f32_f16 v13, v49, v3                             // 0000009BA378: 041A0731
	v_and_b32_e32 v52, 0xffff, v55                             // 0000009BA37C: 36686EFF 0000FFFF
	v_lshl_add_u32 v50, v50, 24, v56                           // 0000009BA384: D6460032 04E13132
	v_bfe_u32 v51, v46, 8, 16                                  // 0000009BA38C: D6100033 0241112E
	s_waitcnt vmcnt(2)                                         // 0000009BA394: BF890BF7
	v_bfe_u32 v53, v45, 12, 16                                 // 0000009BA398: D6100035 0241192D
	v_bfe_u32 v54, v45, 8, 16                                  // 0000009BA3A0: D6100036 0241112D
	v_lshl_or_b32 v48, v48, 16, v52                            // 0000009BA3A8: D6560030 04D12130
	v_bfe_u32 v52, v46, 4, 16                                  // 0000009BA3B0: D6100034 0241092E
	v_mul_u32_u24_e32 v56, s5, v52                             // 0000009BA3B8: 16706805
	v_mul_u32_u24_e32 v52, s7, v52                             // 0000009BA3BC: 16686807
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009BA3C0: BF870001
	v_lshl_add_u32 v52, v52, 24, v56                           // 0000009BA3C4: D6460034 04E13134
	v_mul_u32_u24_e32 v56, s5, v51                             // 0000009BA3CC: 16706605
	v_mul_u32_u24_e32 v51, s7, v51                             // 0000009BA3D0: 16666607
	v_sad_u8 v50, v50, 0, 0x6400                               // 0000009BA3D4: D6220032 03FD0132 00006400
	v_lshl_add_u32 v51, v51, 24, v56                           // 0000009BA3E0: D6460033 04E13133
	v_and_b32_e32 v46, 0xffff, v46                             // 0000009BA3E8: 365C5CFF 0000FFFF
	v_mul_u32_u24_e32 v56, s5, v46                             // 0000009BA3F0: 16705C05
	v_mul_u32_u24_e32 v46, s7, v46                             // 0000009BA3F4: 165C5C07
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009BA3F8: BF870001
	v_lshl_add_u32 v46, v46, 24, v56                           // 0000009BA3FC: D646002E 04E1312E
	v_mul_u32_u24_e32 v56, s5, v53                             // 0000009BA404: 16706A05
	v_mul_u32_u24_e32 v53, s7, v53                             // 0000009BA408: 166A6A07
	v_sad_u8 v52, v52, 0, 0x6400                               // 0000009BA40C: D6220034 03FD0134 00006400
	v_lshl_add_u32 v53, v53, 24, v56                           // 0000009BA418: D6460035 04E13135
	v_and_b32_e32 v50, 0xffff, v50                             // 0000009BA420: 366464FF 0000FFFF
	v_sad_u8 v51, v51, 0, 0x6400                               // 0000009BA428: D6220033 03FD0133 00006400
	v_mul_u32_u24_e32 v56, s5, v54                             // 0000009BA434: 16706C05
	v_mul_u32_u24_e32 v54, s7, v54                             // 0000009BA438: 166C6C07
	v_and_b32_e32 v52, 0xffff, v52                             // 0000009BA43C: 366868FF 0000FFFF
	v_sad_u8 v46, v46, 0, 0x6400                               // 0000009BA444: D622002E 03FD012E 00006400
	v_sad_u8 v53, v53, 0, 0x6400                               // 0000009BA450: D6220035 03FD0135 00006400
	v_lshl_add_u32 v54, v54, 24, v56                           // 0000009BA45C: D6460036 04E13136
	v_lshl_or_b32 v50, v51, 16, v50                            // 0000009BA464: D6560032 04C92133
	v_bfe_u32 v55, v45, 4, 16                                  // 0000009BA46C: D6100037 0241092D
	v_mul_u32_u24_e32 v56, s5, v55                             // 0000009BA474: 16706E05
	v_mul_u32_u24_e32 v55, s7, v55                             // 0000009BA478: 166E6E07
	v_lshl_or_b32 v46, v46, 16, v52                            // 0000009BA47C: D656002E 04D1212E
	v_and_b32_e32 v51, 0xffff, v53                             // 0000009BA484: 36666AFF 0000FFFF
	v_sad_u8 v52, v54, 0, 0x6400                               // 0000009BA48C: D6220034 03FD0136 00006400
	v_pk_fma_f16 v50, v50, s13, 0xc931 op_sel_hi:[1,0,0]       // 0000009BA498: CC0E0032 0BFC1B32 0000C931
	v_lshl_add_u32 v55, v55, 24, v56                           // 0000009BA4A4: D6460037 04E13137
	v_and_b32_e32 v45, 0xffff, v45                             // 0000009BA4AC: 365A5AFF 0000FFFF
	v_mul_u32_u24_e32 v54, s5, v45                             // 0000009BA4B4: 166C5A05
	v_mul_u32_u24_e32 v45, s7, v45                             // 0000009BA4B8: 165A5A07
	v_pk_fma_f16 v46, v46, s13, 0xc931 op_sel_hi:[1,0,0]       // 0000009BA4BC: CC0E002E 0BFC1B2E 0000C931
	v_lshl_or_b32 v51, v52, 16, v51                            // 0000009BA4C8: D6560033 04CD2134
	v_dot2acc_f32_f16 v12, v50, v1                             // 0000009BA4D0: 04180332
	v_sad_u8 v53, v55, 0, 0x6400                               // 0000009BA4D4: D6220035 03FD0137 00006400
	v_lshl_add_u32 v45, v45, 24, v54                           // 0000009BA4E0: D646002D 04D9312D
	v_bfe_u32 v47, v43, 12, 16                                 // 0000009BA4E8: D610002F 0241192B
	v_pk_fma_f16 v44, v51, s13, 0xc931 op_sel_hi:[1,0,0]       // 0000009BA4F0: CC0E002C 0BFC1B33 0000C931
	v_dot2acc_f32_f16 v12, v46, v2                             // 0000009BA4FC: 0418052E
	v_and_b32_e32 v52, 0xffff, v53                             // 0000009BA500: 36686AFF 0000FFFF
	v_sad_u8 v45, v45, 0, 0x6400                               // 0000009BA508: D622002D 03FD012D 00006400
	v_pk_fma_f16 v46, v48, s13, 0xc931 op_sel_hi:[1,0,0]       // 0000009BA514: CC0E002E 0BFC1B30 0000C931
	v_mul_u32_u24_e32 v48, s5, v47                             // 0000009BA520: 16605E05
	v_mul_u32_u24_e32 v47, s7, v47                             // 0000009BA524: 165E5E07
	v_lshl_add_u32 v47, v47, 24, v48                           // 0000009BA528: D646002F 04C1312F
	v_dot2acc_f32_f16 v12, v44, v3                             // 0000009BA530: 0418072C
	v_bfe_u32 v44, v43, 8, 16                                  // 0000009BA534: D610002C 0241112B
	v_lshl_or_b32 v45, v45, 16, v52                            // 0000009BA53C: D656002D 04D1212D
	v_mul_u32_u24_e32 v52, s5, v44                             // 0000009BA544: 16685805
	v_mul_u32_u24_e32 v44, s7, v44                             // 0000009BA548: 16585807
	v_bfe_u32 v48, v43, 4, 16                                  // 0000009BA54C: D6100030 0241092B
	v_sad_u8 v47, v47, 0, 0x6400                               // 0000009BA554: D622002F 03FD012F 00006400
	v_lshl_add_u32 v44, v44, 24, v52                           // 0000009BA560: D646002C 04D1312C
	s_waitcnt vmcnt(1)                                         // 0000009BA568: BF8907F7
	v_bfe_u32 v49, v26, 12, 16                                 // 0000009BA56C: D6100031 0241191A
	v_mul_u32_u24_e32 v52, s5, v48                             // 0000009BA574: 16686005
	v_mul_u32_u24_e32 v48, s7, v48                             // 0000009BA578: 16606007
	v_lshl_add_u32 v48, v48, 24, v52                           // 0000009BA57C: D6460030 04D13130
	v_mul_u32_u24_e32 v52, s5, v49                             // 0000009BA584: 16686205
	v_mul_u32_u24_e32 v49, s7, v49                             // 0000009BA588: 16626207
	v_lshl_add_u32 v49, v49, 24, v52                           // 0000009BA58C: D6460031 04D13131
	v_and_b32_e32 v43, 0xffff, v43                             // 0000009BA594: 365656FF 0000FFFF
	v_and_b32_e32 v47, 0xffff, v47                             // 0000009BA59C: 365E5EFF 0000FFFF
	v_sad_u8 v44, v44, 0, 0x6400                               // 0000009BA5A4: D622002C 03FD012C 00006400
	v_bfe_u32 v50, v26, 8, 16                                  // 0000009BA5B0: D6100032 0241111A
	v_mul_u32_u24_e32 v52, s5, v43                             // 0000009BA5B8: 16685605
	v_mul_u32_u24_e32 v43, s7, v43                             // 0000009BA5BC: 16565607
	v_lshl_add_u32 v43, v43, 24, v52                           // 0000009BA5C0: D646002B 04D1312B
	v_mul_u32_u24_e32 v52, s5, v50                             // 0000009BA5C8: 16686405
	v_mul_u32_u24_e32 v50, s7, v50                             // 0000009BA5CC: 16646407
	v_sad_u8 v48, v48, 0, 0x6400                               // 0000009BA5D0: D6220030 03FD0130 00006400
	v_sad_u8 v49, v49, 0, 0x6400                               // 0000009BA5DC: D6220031 03FD0131 00006400
	v_lshl_add_u32 v50, v50, 24, v52                           // 0000009BA5E8: D6460032 04D13132
	v_lshl_or_b32 v44, v44, 16, v47                            // 0000009BA5F0: D656002C 04BD212C
	v_bfe_u32 v51, v26, 4, 16                                  // 0000009BA5F8: D6100033 0241091A
	v_and_b32_e32 v47, 0xffff, v48                             // 0000009BA600: 365E60FF 0000FFFF
	v_and_b32_e32 v48, 0xffff, v49                             // 0000009BA608: 366062FF 0000FFFF
	v_sad_u8 v49, v50, 0, 0x6400                               // 0000009BA610: D6220031 03FD0132 00006400
	v_mul_u32_u24_e32 v50, s5, v51                             // 0000009BA61C: 16646605
	v_sad_u8 v43, v43, 0, 0x6400                               // 0000009BA620: D622002B 03FD012B 00006400
	v_mul_u32_u24_e32 v51, s7, v51                             // 0000009BA62C: 16666607
	v_lshl_add_u32 v50, v51, 24, v50                           // 0000009BA630: D6460032 04C93133
	v_pk_fma_f16 v44, v44, s13, 0xc931 op_sel_hi:[1,0,0]       // 0000009BA638: CC0E002C 0BFC1B2C 0000C931
	v_alignbit_b32 v22, v22, v24, 16                           // 0000009BA644: D6160016 02423116
	v_and_b32_e32 v26, 0xffff, v26                             // 0000009BA64C: 363434FF 0000FFFF
	v_lshl_or_b32 v43, v43, 16, v47                            // 0000009BA654: D656002B 04BD212B
	v_lshl_or_b32 v47, v49, 16, v48                            // 0000009BA65C: D656002F 04C12131
	v_sad_u8 v48, v50, 0, 0x6400                               // 0000009BA664: D6220030 03FD0132 00006400
	v_mul_u32_u24_e32 v49, s5, v26                             // 0000009BA670: 16623405
	v_mul_u32_u24_e32 v26, s7, v26                             // 0000009BA674: 16343407
	v_dot2acc_f32_f16 v11, v44, v1                             // 0000009BA678: 0416032C
	v_bfe_u32 v44, v22, 12, 16                                 // 0000009BA67C: D610002C 02411916
	v_lshl_add_u32 v26, v26, 24, v49                           // 0000009BA684: D646001A 04C5311A
	v_bfe_u32 v49, v22, 4, 16                                  // 0000009BA68C: D6100031 02410916
	v_mul_u32_u24_e32 v53, s5, v44                             // 0000009BA694: 166A5805
	v_mul_u32_u24_e32 v44, s7, v44                             // 0000009BA698: 16585807
	v_lshl_add_u32 v44, v44, 24, v53                           // 0000009BA69C: D646002C 04D5312C
	v_mul_u32_u24_e32 v53, s5, v49                             // 0000009BA6A4: 166A6205
	v_mul_u32_u24_e32 v49, s7, v49                             // 0000009BA6A8: 16626207
	v_lshl_add_u32 v49, v49, 24, v53                           // 0000009BA6AC: D6460031 04D53131
	v_pk_fma_f16 v24, v47, s13, 0xc931 op_sel_hi:[1,0,0]       // 0000009BA6B4: CC0E0018 0BFC1B2F 0000C931
	v_and_b32_e32 v47, 0xffff, v48                             // 0000009BA6C0: 365E60FF 0000FFFF
	v_bfe_u32 v48, v22, 8, 16                                  // 0000009BA6C8: D6100030 02411116
	v_and_b32_e32 v22, 0xffff, v22                             // 0000009BA6D0: 362C2CFF 0000FFFF
	v_mul_u32_u24_e32 v53, s5, v48                             // 0000009BA6D8: 166A6005
	v_mul_u32_u24_e32 v48, s7, v48                             // 0000009BA6DC: 16606007
	s_waitcnt vmcnt(0)                                         // 0000009BA6E0: BF8903F7
	v_bfe_u32 v50, v19, 12, 16                                 // 0000009BA6E4: D6100032 02411913
	v_lshl_add_u32 v48, v48, 24, v53                           // 0000009BA6EC: D6460030 04D53130
	v_mul_u32_u24_e32 v53, s5, v22                             // 0000009BA6F4: 166A2C05
	v_mul_u32_u24_e32 v22, s7, v22                             // 0000009BA6F8: 162C2C07
	v_lshl_add_u32 v22, v22, 24, v53                           // 0000009BA6FC: D6460016 04D53116
	v_mul_u32_u24_e32 v53, s5, v50                             // 0000009BA704: 166A6405
	v_mul_u32_u24_e32 v50, s7, v50                             // 0000009BA708: 16646407
	v_sad_u8 v44, v44, 0, 0x6400                               // 0000009BA70C: D622002C 03FD012C 00006400
	v_sad_u8 v49, v49, 0, 0x6400                               // 0000009BA718: D6220031 03FD0131 00006400
	v_lshl_add_u32 v50, v50, 24, v53                           // 0000009BA724: D6460032 04D53132
	v_bfe_u32 v51, v19, 8, 16                                  // 0000009BA72C: D6100033 02411113
	v_mul_u32_u24_e32 v53, s5, v51                             // 0000009BA734: 166A6605
	v_mul_u32_u24_e32 v51, s7, v51                             // 0000009BA738: 16666607
	v_and_b32_e32 v44, 0xffff, v44                             // 0000009BA73C: 365858FF 0000FFFF
	v_sad_u8 v48, v48, 0, 0x6400                               // 0000009BA744: D6220030 03FD0130 00006400
	v_and_b32_e32 v49, 0xffff, v49                             // 0000009BA750: 366262FF 0000FFFF
	v_sad_u8 v22, v22, 0, 0x6400                               // 0000009BA758: D6220016 03FD0116 00006400
	v_sad_u8 v50, v50, 0, 0x6400                               // 0000009BA764: D6220032 03FD0132 00006400
	v_lshl_add_u32 v51, v51, 24, v53                           // 0000009BA770: D6460033 04D53133
	v_lshl_or_b32 v44, v48, 16, v44                            // 0000009BA778: D656002C 04B12130
	v_bfe_u32 v52, v19, 4, 16                                  // 0000009BA780: D6100034 02410913
	v_lshl_or_b32 v22, v22, 16, v49                            // 0000009BA788: D6560016 04C52116
	v_dual_mov_b32 v55, v32 :: v_dual_and_b32 v48, 0xffff, v50 // 0000009BA790: CA240120 373064FF 0000FFFF
	v_sad_u8 v49, v51, 0, 0x6400                               // 0000009BA79C: D6220031 03FD0133 00006400
	v_sad_u8 v26, v26, 0, 0x6400                               // 0000009BA7A8: D622001A 03FD011A 00006400
	v_mul_u32_u24_e32 v53, s5, v52                             // 0000009BA7B4: 166A6805
	v_mul_u32_u24_e32 v52, s7, v52                             // 0000009BA7B8: 16686807
	v_pk_fma_f16 v44, v44, s13, 0xc931 op_sel_hi:[1,0,0]       // 0000009BA7BC: CC0E002C 0BFC1B2C 0000C931
	v_lshl_or_b32 v48, v49, 16, v48                            // 0000009BA7C8: D6560030 04C12131
	v_lshl_add_u32 v52, v52, 24, v53                           // 0000009BA7D0: D6460034 04D53134
	v_and_b32_e32 v19, 0xffff, v19                             // 0000009BA7D8: 362626FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009BA7E0: BF870004
	v_dual_dot2acc_f32_f16 v13, v46, v4 :: v_dual_dot2acc_f32_f16 v14, v44, v1// 0000009BA7E4: CB18092E 0D0E032C
	v_mov_b32_e32 v46, v29                                     // 0000009BA7EC: 7E5C031D
	v_lshl_or_b32 v1, v26, 16, v47                             // 0000009BA7F0: D6560001 04BD211A
	v_pk_fma_f16 v26, v48, s13, 0xc931 op_sel_hi:[1,0,0]       // 0000009BA7F8: CC0E001A 0BFC1B30 0000C931
	v_mov_b32_e32 v48, v38                                     // 0000009BA804: 7E600326
	v_mul_u32_u24_e32 v51, s5, v19                             // 0000009BA808: 16662605
	v_mul_u32_u24_e32 v19, s7, v19                             // 0000009BA80C: 16262607
	v_sad_u8 v50, v52, 0, 0x6400                               // 0000009BA810: D6220032 03FD0134 00006400
	v_lshl_add_u32 v19, v19, 24, v51                           // 0000009BA81C: D6460013 04CD3113
	v_pk_fma_f16 v43, v43, s13, 0xc931 op_sel_hi:[1,0,0]       // 0000009BA824: CC0E002B 0BFC1B2B 0000C931
	v_pk_fma_f16 v22, v22, s13, 0xc931 op_sel_hi:[1,0,0]       // 0000009BA830: CC0E0016 0BFC1B16 0000C931
	v_dual_mov_b32 v54, v40 :: v_dual_add_nc_u32 v5, 1, v5     // 0000009BA83C: CA200128 36040A81
	v_dual_mov_b32 v52, v39 :: v_dual_and_b32 v49, 0xffff, v50 // 0000009BA844: CA240127 343064FF 0000FFFF
	v_sad_u8 v19, v19, 0, 0x6400                               // 0000009BA850: D6220013 03FD0113 00006400
	v_dot2acc_f32_f16 v11, v43, v2                             // 0000009BA85C: 0416052B
	v_dot2acc_f32_f16 v14, v22, v2                             // 0000009BA860: 041C0516
	v_pk_fma_f16 v58, v58, s13, 0xc931 op_sel_hi:[1,0,0]       // 0000009BA864: CC0E003A 0BFC1B3A 0000C931
	v_pk_fma_f16 v45, v45, s13, 0xc931 op_sel_hi:[1,0,0]       // 0000009BA870: CC0E002D 0BFC1B2D 0000C931
	v_lshl_or_b32 v19, v19, 16, v49                            // 0000009BA87C: D6560013 04C52113
	v_dot2acc_f32_f16 v11, v24, v3                             // 0000009BA884: 04160718
	v_dual_dot2acc_f32_f16 v14, v26, v3 :: v_dual_add_nc_u32 v3, v20, v5// 0000009BA888: CB20071A 0E020B14
	v_pk_fma_f16 v1, v1, s13, 0xc931 op_sel_hi:[1,0,0]         // 0000009BA890: CC0E0001 0BFC1B01 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000009BA89C: BF870224
	v_pk_fma_f16 v2, v19, s13, 0xc931 op_sel_hi:[1,0,0]        // 0000009BA8A0: CC0E0002 0BFC1B13 0000C931
	v_dual_dot2acc_f32_f16 v17, v58, v4 :: v_dual_mov_b32 v58, v41// 0000009BA8AC: CB10093A 113A0129
	v_cmp_eq_u32_e32 vcc_lo, 6, v3                             // 0000009BA8B4: 7C940686
	v_dot2acc_f32_f16 v12, v45, v4                             // 0000009BA8B8: 0418092D
	v_dot2acc_f32_f16 v11, v1, v4                              // 0000009BA8BC: 04160901
	v_dual_dot2acc_f32_f16 v14, v2, v4 :: v_dual_add_nc_u32 v23, 32, v23// 0000009BA8C0: CB200902 0E162EA0
	v_dual_mov_b32 v56, v40 :: v_dual_mov_b32 v19, v34         // 0000009BA8C8: CA100128 38120122
	v_mov_b32_e32 v24, v34                                     // 0000009BA8D0: 7E300322
	v_mov_b32_e32 v22, v27                                     // 0000009BA8D4: 7E2C031B
	v_mov_b32_e32 v26, v36                                     // 0000009BA8D8: 7E340324
	v_mov_b32_e32 v44, v36                                     // 0000009BA8DC: 7E580324
	v_mov_b32_e32 v43, v28                                     // 0000009BA8E0: 7E56031C
	v_mov_b32_e32 v45, v37                                     // 0000009BA8E4: 7E5A0325
	v_dual_mov_b32 v47, v37 :: v_dual_mov_b32 v50, v38         // 0000009BA8E8: CA100125 2F320126
	v_mov_b32_e32 v49, v30                                     // 0000009BA8F0: 7E62031E
	v_mov_b32_e32 v53, v39                                     // 0000009BA8F4: 7E6A0327
	v_mov_b32_e32 v51, v31                                     // 0000009BA8F8: 7E66031F
	v_dual_mov_b32 v59, v41 :: v_dual_mov_b32 v60, v42         // 0000009BA8FC: CA100129 3B3C012A
	v_dual_mov_b32 v57, v35 :: v_dual_mov_b32 v2, v42          // 0000009BA904: CA100123 3902012A
	v_mov_b32_e32 v1, v33                                      // 0000009BA90C: 7E020321
	s_or_b32 s4, vcc_lo, s4                                    // 0000009BA910: 8C04046A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000009BA914: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000009BA918: 917E047E
	s_cbranch_execz 55                                         // 0000009BA91C: BFA50037 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi4ELi8ELi2ELb0EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x11fc>
	s_mov_b32 s14, exec_lo                                     // 0000009BA920: BE8E007E
	.long 0xd4c9007e                                           // 0000009BA924: D4C9007E
	v_cndmask_b32_e32 v1, v5, v10, vcc_lo                      // 0000009BA928: 02021505
	s_cbranch_execz 64626                                      // 0000009BA92C: BFA5FC72 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi4ELi8ELi2ELb0EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x2f8>
	.long 0xd73c0003                                           // 0000009BA930: D73C0003
	v_cndmask_b32_e32 v1, 10, v5, vcc_lo                       // 0000009BA934: 02020A8A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009BA938: BF870091
	.long 0xd7006a1b                                           // 0000009BA93C: D7006A1B
	v_cndmask_b32_e32 v1, s1, v3, vcc_lo                       // 0000009BA940: 02020601
	v_add_co_ci_u32_e64 v28, null, s2, v4, vcc_lo              // 0000009BA944: D5207C1C 01AA0802
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009BA94C: BF870092
	.long 0xd7006a03                                           // 0000009BA950: D7006A03
	v_cndmask_b32_e32 v1, v27, v25, vcc_lo                     // 0000009BA954: 0202331B
	v_add_co_ci_u32_e64 v4, null, 0, v28, vcc_lo               // 0000009BA958: D5207C04 01AA3880
	.long 0xd7006a3d                                           // 0000009BA960: D7006A3D
	v_cndmask_b32_e32 v1, v27, v21, vcc_lo                     // 0000009BA964: 02022B1B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009BA968: BF870001
	v_add_co_ci_u32_e64 v62, null, 0, v28, vcc_lo              // 0000009BA96C: D5207C3E 01AA3880
	s_clause 0xf                                               // 0000009BA974: BF85000F
	global_load_b32 v33, v[3:4], off                           // 0000009BA978: DC520000 217C0003
	global_load_b32 v35, v[3:4], off offset:128                // 0000009BA980: DC520080 237C0003
	global_load_b32 v32, v[3:4], off offset:256                // 0000009BA988: DC520100 207C0003
	global_load_b32 v31, v[3:4], off offset:384                // 0000009BA990: DC520180 1F7C0003
	global_load_b32 v30, v[3:4], off offset:512                // 0000009BA998: DC520200 1E7C0003
	global_load_b32 v29, v[3:4], off offset:640                // 0000009BA9A0: DC520280 1D7C0003
	global_load_b32 v28, v[3:4], off offset:768                // 0000009BA9A8: DC520300 1C7C0003
	global_load_b32 v27, v[3:4], off offset:896                // 0000009BA9B0: DC520380 1B7C0003
	global_load_b32 v42, v[61:62], off                         // 0000009BA9B8: DC520000 2A7C003D
	global_load_b32 v41, v[61:62], off offset:128              // 0000009BA9C0: DC520080 297C003D
	global_load_b32 v40, v[61:62], off offset:256              // 0000009BA9C8: DC520100 287C003D
	global_load_b32 v39, v[61:62], off offset:384              // 0000009BA9D0: DC520180 277C003D
	global_load_b32 v38, v[61:62], off offset:512              // 0000009BA9D8: DC520200 267C003D
	global_load_b32 v37, v[61:62], off offset:640              // 0000009BA9E0: DC520280 257C003D
	global_load_b32 v36, v[61:62], off offset:768              // 0000009BA9E8: DC520300 247C003D
	global_load_b32 v34, v[61:62], off offset:896              // 0000009BA9F0: DC520380 227C003D
	s_branch 64575                                             // 0000009BA9F8: BFA0FC3F <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi4ELi8ELi2ELb0EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x2f8>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000009BA9FC: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000009BAA00: BF870009
	s_or_b32 exec_lo, exec_lo, s0                              // 0000009BAA04: 8C7E007E
	s_waitcnt vmcnt(15)                                        // 0000009BAA08: BF893FF7
	v_dual_mov_b32 v1, v18 :: v_dual_mov_b32 v2, v17           // 0000009BAA0C: CA100112 01020111
	v_dual_mov_b32 v3, v16 :: v_dual_mov_b32 v10, v15          // 0000009BAA14: CA100110 030A010F
	v_dual_mov_b32 v4, v13 :: v_dual_mov_b32 v5, v12           // 0000009BAA1C: CA10010D 0404010C
	s_waitcnt vmcnt(0)                                         // 0000009BAA24: BF8903F7
	v_dual_mov_b32 v6, v11 :: v_dual_mov_b32 v19, v14          // 0000009BAA28: CA10010B 0612010E
	s_mov_b32 s0, 0x76543210                                   // 0000009BAA30: BE8000FF 76543210
	v_cmp_gt_u32_e32 vcc_lo, 16, v9                            // 0000009BAA38: 7C981290
	v_permlanex16_b32 v1, v1, s0, 0xfedcba98                   // 0000009BAA3C: D65C0001 03FC0101 FEDCBA98
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 0000009BAA48: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 0000009BAA54: D65C0003 03FC0103 FEDCBA98
	v_permlanex16_b32 v10, v10, s0, 0xfedcba98                 // 0000009BAA60: D65C000A 03FC010A FEDCBA98
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 0000009BAA6C: D65C0004 03FC0104 FEDCBA98
	v_permlanex16_b32 v5, v5, s0, 0xfedcba98                   // 0000009BAA78: D65C0005 03FC0105 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 0000009BAA84: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v19, v19, s0, 0xfedcba98                 // 0000009BAA90: D65C0013 03FC0113 FEDCBA98
	s_barrier                                                  // 0000009BAA9C: BFBD0000
	buffer_gl0_inv                                             // 0000009BAAA0: E0AC0000 00000000
	s_and_saveexec_b32 s0, vcc_lo                              // 0000009BAAA8: BE80206A
	s_cbranch_execz 18                                         // 0000009BAAAC: BFA50012 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi4ELi8ELi2ELb0EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x12f8>
	v_dual_add_f32 v9, v14, v19 :: v_dual_add_f32 v2, v17, v2  // 0000009BAAB0: C908270E 09020511
	v_dual_add_f32 v1, v18, v1 :: v_dual_add_f32 v10, v15, v10 // 0000009BAAB8: C9080312 010A150F
	v_lshl_or_b32 v8, v7, 9, v8                                // 0000009BAAC0: D6560008 04211307
	v_dual_add_f32 v3, v16, v3 :: v_dual_add_f32 v4, v13, v4   // 0000009BAAC8: C9080710 0304090D
	v_dual_add_f32 v5, v12, v5 :: v_dual_add_f32 v6, v11, v6   // 0000009BAAD0: C9080B0C 05060D0B
	ds_store_2addr_b32 v8, v1, v2 offset1:16                   // 0000009BAAD8: D8381000 00020108
	ds_store_2addr_b32 v8, v3, v10 offset0:32 offset1:48       // 0000009BAAE0: D8383020 000A0308
	ds_store_2addr_b32 v8, v4, v5 offset0:64 offset1:80        // 0000009BAAE8: D8385040 00050408
	ds_store_2addr_b32 v8, v6, v9 offset0:96 offset1:112       // 0000009BAAF0: D8387060 00090608
	s_or_b32 exec_lo, exec_lo, s0                              // 0000009BAAF8: 8C7E007E
	s_waitcnt lgkmcnt(0)                                       // 0000009BAAFC: BF89FC07
	s_barrier                                                  // 0000009BAB00: BFBD0000
	buffer_gl0_inv                                             // 0000009BAB04: E0AC0000 00000000
	s_mov_b32 s1, exec_lo                                      // 0000009BAB0C: BE81007E
	v_cmpx_eq_u32_e32 0, v7                                    // 0000009BAB10: 7D940E80
	s_cbranch_execz 510                                        // 0000009BAB14: BFA501FE <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi4ELi8ELi2ELb0EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x1b10>
	v_and_b32_e32 v1, 15, v0                                   // 0000009BAB18: 3602008F
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009BAB1C: BF870001
	v_lshlrev_b32_e32 v16, 2, v1                               // 0000009BAB20: 30200282
	ds_load_2addr_b32 v[2:3], v16 offset1:16                   // 0000009BAB24: D8DC1000 02000010
	ds_load_2addr_b32 v[4:5], v16 offset0:128 offset1:144      // 0000009BAB2C: D8DC9080 04000010
	s_waitcnt lgkmcnt(1)                                       // 0000009BAB34: BF89FC17
	v_dual_add_f32 v53, 0, v3 :: v_dual_add_f32 v52, 0, v2     // 0000009BAB38: C9080680 35340480
	v_add_nc_u32_e32 v48, 0x400, v16                           // 0000009BAB40: 4A6020FF 00000400
	v_add_nc_u32_e32 v50, 0x800, v16                           // 0000009BAB48: 4A6420FF 00000800
	v_add_nc_u32_e32 v51, 0xc00, v16                           // 0000009BAB50: 4A6620FF 00000C00
	s_waitcnt lgkmcnt(0)                                       // 0000009BAB58: BF89FC07
	v_add_f32_e32 v53, v53, v5                                 // 0000009BAB5C: 066A0B35
	ds_load_2addr_b32 v[6:7], v16 offset0:32 offset1:48        // 0000009BAB60: D8DC3020 06000010
	ds_load_2addr_b32 v[8:9], v16 offset0:160 offset1:176      // 0000009BAB68: D8DCB0A0 08000010
	ds_load_2addr_b32 v[10:11], v16 offset0:64 offset1:80      // 0000009BAB70: D8DC5040 0A000010
	ds_load_2addr_b32 v[12:13], v16 offset0:192 offset1:208    // 0000009BAB78: D8DCD0C0 0C000010
	ds_load_2addr_b32 v[14:15], v16 offset0:96 offset1:112     // 0000009BAB80: D8DC7060 0E000010
	ds_load_2addr_b32 v[16:17], v16 offset0:224 offset1:240    // 0000009BAB88: D8DCF0E0 10000010
	ds_load_2addr_b32 v[18:19], v48 offset1:16                 // 0000009BAB90: D8DC1000 12000030
	ds_load_2addr_b32 v[20:21], v48 offset0:128 offset1:144    // 0000009BAB98: D8DC9080 14000030
	ds_load_2addr_b32 v[22:23], v50 offset1:16                 // 0000009BABA0: D8DC1000 16000032
	ds_load_2addr_b32 v[24:25], v50 offset0:128 offset1:144    // 0000009BABA8: D8DC9080 18000032
	ds_load_2addr_b32 v[26:27], v51 offset1:16                 // 0000009BABB0: D8DC1000 1A000033
	ds_load_2addr_b32 v[28:29], v51 offset0:128 offset1:144    // 0000009BABB8: D8DC9080 1C000033
	ds_load_2addr_b32 v[30:31], v48 offset0:32 offset1:48      // 0000009BABC0: D8DC3020 1E000030
	ds_load_2addr_b32 v[32:33], v48 offset0:160 offset1:176    // 0000009BABC8: D8DCB0A0 20000030
	ds_load_2addr_b32 v[34:35], v50 offset0:32 offset1:48      // 0000009BABD0: D8DC3020 22000032
	ds_load_2addr_b32 v[36:37], v50 offset0:160 offset1:176    // 0000009BABD8: D8DCB0A0 24000032
	ds_load_2addr_b32 v[38:39], v51 offset0:32 offset1:48      // 0000009BABE0: D8DC3020 26000033
	ds_load_2addr_b32 v[40:41], v51 offset0:160 offset1:176    // 0000009BABE8: D8DCB0A0 28000033
	ds_load_2addr_b32 v[42:43], v48 offset0:64 offset1:80      // 0000009BABF0: D8DC5040 2A000030
	ds_load_2addr_b32 v[44:45], v48 offset0:192 offset1:208    // 0000009BABF8: D8DCD0C0 2C000030
	ds_load_2addr_b32 v[46:47], v50 offset0:64 offset1:80      // 0000009BAC00: D8DC5040 2E000032
	s_waitcnt lgkmcnt(20)                                      // 0000009BAC08: BF89FD47
	v_add_f32_e32 v6, 0, v6                                    // 0000009BAC0C: 060C0C80
	s_waitcnt lgkmcnt(18)                                      // 0000009BAC10: BF89FD27
	v_dual_add_f32 v52, v52, v4 :: v_dual_add_f32 v11, 0, v11  // 0000009BAC14: C9080934 340A1680
	ds_load_2addr_b32 v[2:3], v48 offset0:96 offset1:112       // 0000009BAC1C: D8DC7060 02000030
	ds_load_2addr_b32 v[48:49], v48 offset0:224 offset1:240    // 0000009BAC24: D8DCF0E0 30000030
	v_dual_add_f32 v7, 0, v7 :: v_dual_add_f32 v6, v6, v8      // 0000009BAC2C: C9080E80 07061106
	s_waitcnt lgkmcnt(16)                                      // 0000009BAC34: BF89FD07
	v_dual_add_f32 v15, 0, v15 :: v_dual_add_f32 v8, v52, v18  // 0000009BAC38: C9081E80 0F082534
	v_add_f32_e32 v10, 0, v10                                  // 0000009BAC40: 06141480
	ds_load_2addr_b32 v[4:5], v50 offset0:96 offset1:112       // 0000009BAC44: D8DC7060 04000032
	v_add_f32_e32 v18, v53, v19                                // 0000009BAC4C: 06242735
	v_dual_add_f32 v14, 0, v14 :: v_dual_add_f32 v7, v7, v9    // 0000009BAC50: C9081C80 0E061307
	s_waitcnt lgkmcnt(11)                                      // 0000009BAC58: BF89FCB7
	v_add_f32_e32 v6, v6, v30                                  // 0000009BAC5C: 060C3D06
	v_add_f32_e32 v9, v10, v12                                 // 0000009BAC60: 0612190A
	v_add_f32_e32 v8, v8, v20                                  // 0000009BAC64: 06102908
	v_add_f32_e32 v12, v11, v13                                // 0000009BAC68: 06181B0B
	v_dual_add_f32 v18, v18, v21 :: v_dual_add_f32 v7, v7, v31 // 0000009BAC6C: C9082B12 12063F07
	s_waitcnt lgkmcnt(5)                                       // 0000009BAC74: BF89FC57
	v_add_f32_e32 v9, v9, v42                                  // 0000009BAC78: 06125509
	v_dual_add_f32 v8, v8, v22 :: v_dual_add_f32 v13, v14, v16 // 0000009BAC7C: C9082D08 080C210E
	v_dual_add_f32 v14, v15, v17 :: v_dual_add_f32 v15, v12, v43// 0000009BAC84: C908230F 0E0E570C
	v_add_f32_e32 v6, v6, v32                                  // 0000009BAC8C: 060C4106
	s_delay_alu instid0(VALU_DEP_3)                            // 0000009BAC90: BF870003
	v_add_f32_e32 v8, v8, v24                                  // 0000009BAC94: 06103108
	s_waitcnt lgkmcnt(4)                                       // 0000009BAC98: BF89FC47
	v_add_f32_e32 v19, v9, v44                                 // 0000009BAC9C: 06265909
	s_waitcnt lgkmcnt(2)                                       // 0000009BACA0: BF89FC27
	v_add_f32_e32 v17, v14, v3                                 // 0000009BACA4: 0622070E
	v_dual_add_f32 v18, v18, v23 :: v_dual_add_f32 v23, v15, v45// 0000009BACA8: C9082F12 12165B0F
	v_add_f32_e32 v6, v6, v34                                  // 0000009BACB0: 060C4506
	v_add_f32_e32 v16, v13, v2                                 // 0000009BACB4: 0620050D
	s_waitcnt lgkmcnt(1)                                       // 0000009BACB8: BF89FC17
	v_add_f32_e32 v17, v17, v49                                // 0000009BACBC: 06226311
	v_dual_add_f32 v10, v18, v25 :: v_dual_add_f32 v19, v19, v46// 0000009BACC0: C9083312 0A125D13
	v_dual_add_f32 v23, v23, v47 :: v_dual_add_f32 v6, v6, v36 // 0000009BACC8: C9085F17 17064906
	s_waitcnt lgkmcnt(0)                                       // 0000009BACD0: BF89FC07
	s_delay_alu instid0(VALU_DEP_3)                            // 0000009BACD4: BF870003
	v_add_f32_e32 v5, v17, v5                                  // 0000009BACD8: 060A0B11
	ds_load_2addr_b32 v[2:3], v51 offset0:192 offset1:208      // 0000009BACDC: D8DCD0C0 02000033
	ds_load_2addr_b32 v[14:15], v51 offset0:224 offset1:240    // 0000009BACE4: D8DCF0E0 0E000033
	v_add_f32_e32 v18, v7, v33                                 // 0000009BACEC: 06244307
	v_add_f32_e32 v6, v6, v38                                  // 0000009BACF0: 060C4D06
	ds_load_2addr_b32 v[12:13], v51 offset0:96 offset1:112     // 0000009BACF4: D8DC7060 0C000033
	v_add_f32_e32 v22, v6, v40                                 // 0000009BACFC: 062C5106
	ds_load_2addr_b32 v[6:7], v50 offset0:192 offset1:208      // 0000009BAD00: D8DCD0C0 06000032
	s_waitcnt lgkmcnt(0)                                       // 0000009BAD08: BF89FC07
	v_dual_add_f32 v8, v8, v26 :: v_dual_add_f32 v7, v23, v7   // 0000009BAD0C: C9083508 08060F17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000009BAD14: BF8700C1
	v_add_f32_e32 v20, v8, v28                                 // 0000009BAD18: 06283908
	ds_load_2addr_b32 v[8:9], v50 offset0:224 offset1:240      // 0000009BAD1C: D8DCF0E0 08000032
	s_waitcnt lgkmcnt(0)                                       // 0000009BAD24: BF89FC07
	v_dual_add_f32 v10, v10, v27 :: v_dual_add_f32 v5, v5, v9  // 0000009BAD28: C908370A 0A041305
	v_add_f32_e32 v21, v10, v29                                // 0000009BAD30: 062A3B0A
	ds_load_2addr_b32 v[10:11], v51 offset0:64 offset1:80      // 0000009BAD34: D8DC5040 0A000033
	v_add_f32_e32 v5, v5, v13                                  // 0000009BAD3C: 060A1B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000009BAD40: BF8700A1
	v_dual_add_f32 v5, v5, v15 :: v_dual_add_f32 v6, v19, v6   // 0000009BAD44: C9081F05 05060D13
	s_waitcnt lgkmcnt(0)                                       // 0000009BAD4C: BF89FC07
	v_dual_add_f32 v6, v6, v10 :: v_dual_add_f32 v7, v7, v11   // 0000009BAD50: C9081506 06061707
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000009BAD58: BF8701B1
	v_dual_add_f32 v2, v6, v2 :: v_dual_add_f32 v3, v7, v3     // 0000009BAD5C: C9080506 02020707
	v_sub_f32_e32 v7, v20, v21                                 // 0000009BAD64: 080E2B14
	v_add_f32_e32 v6, v20, v21                                 // 0000009BAD68: 060C2B14
	v_add_f32_e32 v10, v2, v3                                  // 0000009BAD6C: 06140702
	v_sub_f32_e32 v2, v2, v3                                   // 0000009BAD70: 08040702
	v_add_f32_e32 v16, v16, v48                                // 0000009BAD74: 06206110
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009BAD78: BF870091
	v_add_f32_e32 v4, v16, v4                                  // 0000009BAD7C: 06080910
	v_add_f32_e32 v4, v4, v8                                   // 0000009BAD80: 06081104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009BAD84: BF870091
	v_add_f32_e32 v4, v4, v12                                  // 0000009BAD88: 06081904
	v_add_f32_e32 v4, v4, v14                                  // 0000009BAD8C: 06081D04
	v_add_f32_e32 v18, v18, v35                                // 0000009BAD90: 06244712
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009BAD94: BF870112
	v_dual_add_f32 v11, v4, v5 :: v_dual_and_b32 v14, 1, v0    // 0000009BAD98: C9240B04 0B0E0081
	v_add_f32_e32 v16, v18, v37                                // 0000009BADA0: 06204B12
	v_sub_f32_e32 v3, v4, v5                                   // 0000009BADA4: 08060B04
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009BADA8: BF870213
	.long 0xd44a0000                                           // 0000009BADAC: D44A0000
	v_cndmask_b32_e32 v1, 0, v14, vcc_lo                       // 0000009BADB0: 02021C80
	v_add_f32_e32 v5, v10, v11                                 // 0000009BADB4: 060A170A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009BADB8: BF870214
	v_add_f32_e32 v8, v16, v39                                 // 0000009BADBC: 06104F10
	v_add_f32_e32 v13, v2, v3                                  // 0000009BADC0: 061A0702
	v_dual_sub_f32 v2, v2, v3 :: v_dual_and_b32 v3, 2, v0      // 0000009BADC4: C9640702 02020082
	v_sub_f32_e32 v10, v10, v11                                // 0000009BADCC: 0814170A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009BADD0: BF870194
	v_add_f32_e32 v8, v8, v41                                  // 0000009BADD4: 06105308
	.long 0xd44a0001                                           // 0000009BADD8: D44A0001
	v_cndmask_b32_e32 v1, 0, v3, vcc_lo                        // 0000009BADDC: 02020680
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000009BADE0: BF870122
	v_add_f32_e32 v9, v22, v8                                  // 0000009BADE4: 06121116
	v_sub_f32_e32 v8, v22, v8                                  // 0000009BADE8: 08101116
	v_add_f32_e32 v4, v6, v9                                   // 0000009BADEC: 06081306
	v_sub_f32_e32 v6, v6, v9                                   // 0000009BADF0: 080C1306
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000009BADF4: BF8701A2
	v_dual_add_f32 v12, v7, v8 :: v_dual_add_f32 v9, v4, v5    // 0000009BADF8: C9081107 0C080B04
	v_sub_f32_e32 v5, v4, v5                                   // 0000009BAE00: 080A0B04
	v_add_f32_e32 v3, v6, v10                                  // 0000009BAE04: 06061506
	v_sub_f32_e32 v10, v6, v10                                 // 0000009BAE08: 08141506
	v_and_b32_e32 v6, 4, v0                                    // 0000009BAE0C: 360C0084
	v_mov_b32_dpp v11, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009BAE10: 7E1602FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 0000009BAE18: D5010009 20021309
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009BAE20: BF870113
	.long 0xd44a0002                                           // 0000009BAE24: D44A0002
	v_cndmask_b32_e32 v1, 0, v6, vcc_lo                        // 0000009BAE28: 02020C80
	v_dual_add_f32 v4, v9, v11 :: v_dual_sub_f32 v9, v12, v13  // 0000009BAE2C: C90A1709 04081B0C
	v_dual_sub_f32 v7, v7, v8 :: v_dual_add_f32 v8, v12, v13   // 0000009BAE34: C9481107 07081B0C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000009BAE3C: BF8701A2
	v_mov_b32_dpp v11, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009BAE40: 7E1602FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 0000009BAE48: D5010004 20060904
	v_add_f32_e32 v13, v7, v2                                  // 0000009BAE50: 061A0507
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000009BAE54: BF870224
	v_mov_b32_dpp v14, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009BAE58: 7E1C02FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, s0                          // 0000009BAE60: D5010008 20021108
	v_dual_sub_f32 v7, v7, v2 :: v_dual_add_f32 v4, v4, v11    // 0000009BAE68: C9480507 07041704
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009BAE70: BF870194
	v_mov_b32_dpp v11, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009BAE74: 7E1602FA FF01610D
	v_add_f32_e32 v8, v8, v14                                  // 0000009BAE7C: 06101D08
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000009BAE80: BF8701A3
	v_mov_b32_dpp v6, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009BAE84: 7E0C02FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s2                          // 0000009BAE8C: D5010004 200A0904
	v_mov_b32_dpp v12, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009BAE94: 7E1802FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s1                          // 0000009BAE9C: D5010008 20061108
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000009BAEA4: BF8701C1
	v_add_f32_e32 v8, v8, v12                                  // 0000009BAEA8: 06101908
	v_cndmask_b32_e64 v12, -v13, v13, s0                       // 0000009BAEAC: D501000C 20021B0D
	v_mov_b32_dpp v13, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009BAEB4: 7E1A02FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 0000009BAEBC: D5010003 20020703
	v_add_f32_e32 v11, v12, v11                                // 0000009BAEC4: 0616170C
	v_mov_b32_dpp v12, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009BAEC8: 7E1802FA FF016408
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000009BAED0: BF870223
	v_add_f32_e32 v3, v3, v13                                  // 0000009BAED4: 06061B03
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 0000009BAED8: D5010008 200A1108
	v_mov_b32_dpp v13, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009BAEE0: 7E1A02FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 0000009BAEE8: D501000B 2006170B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000009BAEF0: BF870254
	v_mov_b32_dpp v14, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009BAEF4: 7E1C02FA FF016203
	v_cndmask_b32_e64 v15, -v3, v3, s1                         // 0000009BAEFC: D501000F 20060703
	v_add_f32_e32 v3, v4, v6                                   // 0000009BAF04: 06060D04
	v_add_f32_e32 v6, v8, v12                                  // 0000009BAF08: 060C1908
	v_add_f32_e32 v8, v11, v13                                 // 0000009BAF0C: 06101B0B
	v_add_f32_e32 v11, v15, v14                                // 0000009BAF10: 06161D0F
	v_mov_b32_dpp v14, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009BAF14: 7E1C02FA FF016105
	v_cndmask_b32_e64 v15, -v5, v5, s0                         // 0000009BAF1C: D501000F 20020B05
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009BAF24: BF870004
	v_mov_b32_dpp v12, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009BAF28: 7E1802FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 0000009BAF30: D5010008 200A1108
	v_mov_b32_dpp v13, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009BAF38: 7E1A02FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s2                       // 0000009BAF40: D501000B 200A170B
	v_mov_b32_dpp v2, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009BAF48: 7E0402FA FF016803
	v_mov_b32_dpp v4, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009BAF50: 7E0802FA FF016806
	v_add_f32_e32 v5, v8, v12                                  // 0000009BAF58: 060A1908
	v_mov_b32_dpp v8, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009BAF5C: 7E1002FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 0000009BAF64: D5010009 20021309
	v_add_f32_e32 v12, v15, v14                                // 0000009BAF6C: 06181D0F
	v_mov_b32_dpp v14, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009BAF70: 7E1C02FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, s0                       // 0000009BAF78: D501000A 2002150A
	v_mov_b32_dpp v15, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009BAF80: 7E1E02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s0                          // 0000009BAF88: D5010007 20020F07
	v_add_f32_e32 v8, v9, v8                                   // 0000009BAF90: 06101109
	v_mov_b32_dpp v9, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009BAF94: 7E1202FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 0000009BAF9C: D501000C 2006190C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009BAFA4: BF870214
	v_dual_add_f32 v10, v10, v14 :: v_dual_add_f32 v7, v7, v15 // 0000009BAFA8: C9081D0A 0A061F07
	v_mov_b32_dpp v14, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009BAFB0: 7E1C02FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s1                          // 0000009BAFB8: D5010008 20061108
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009BAFC0: BF870214
	v_add_f32_e32 v9, v12, v9                                  // 0000009BAFC4: 0612130C
	v_mov_b32_dpp v12, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009BAFC8: 7E1802FA FF01620A
	v_mov_b32_dpp v15, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009BAFD0: 7E1E02FA FF016207
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 0000009BAFD8: D501000A 2006150A
	v_cndmask_b32_e64 v16, -v7, v7, s1                         // 0000009BAFE0: D5010010 20060F07
	v_dual_add_f32 v8, v8, v14 :: v_dual_add_f32 v7, v11, v13  // 0000009BAFE8: C9081D08 08061B0B
	v_mov_b32_dpp v11, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009BAFF0: 7E1602FA FF016409
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009BAFF8: BF870214
	v_add_f32_e32 v10, v10, v12                                // 0000009BAFFC: 0614190A
	v_add_f32_e32 v12, v16, v15                                // 0000009BB000: 06181F10
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009BB004: BF870004
	v_mov_b32_dpp v13, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009BB008: 7E1A02FA FF016408
	v_cndmask_b32_e64 v15, -v8, v8, s2                         // 0000009BB010: D501000F 200A1108
	v_cndmask_b32_e64 v9, -v9, v9, s2                          // 0000009BB018: D5010009 200A1309
	v_mov_b32_dpp v17, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009BB020: 7E2202FA FF01640A
	v_mov_b32_dpp v18, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009BB028: 7E2402FA FF01640C
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 0000009BB030: D501000A 200A150A
	v_cndmask_b32_e64 v12, -v12, v12, s2                       // 0000009BB038: D501000C 200A190C
	v_add_f32_e32 v14, v9, v11                                 // 0000009BB040: 061C1709
	v_add_f32_e32 v16, v15, v13                                // 0000009BB044: 06201B0F
	v_mov_b32_dpp v8, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009BB048: 7E1002FA FF016807
	v_add_f32_e32 v15, v10, v17                                // 0000009BB050: 061E230A
	v_add_f32_e32 v17, v12, v18                                // 0000009BB054: 0622250C
	v_mov_b32_dpp v9, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009BB058: 7E1202FA FF016805
	v_mov_b32_dpp v10, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009BB060: 7E1402FA FF01680E
	v_mov_b32_dpp v11, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009BB068: 7E1602FA FF016810
	v_mov_b32_dpp v12, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009BB070: 7E1802FA FF01680F
	v_mov_b32_dpp v13, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009BB078: 7E1A02FA FF016811
	s_and_b32 exec_lo, exec_lo, vcc_lo                         // 0000009BB080: 8B7E6A7E
	s_cbranch_execz 162                                        // 0000009BB084: BFA500A2 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi4ELi8ELi2ELb0EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x1b10>
	v_and_b32_e32 v0, 8, v0                                    // 0000009BB088: 36000088
	s_mul_i32 s0, s3, 0x1400                                   // 0000009BB08C: 9600FF03 00001400
	s_mul_hi_i32 s1, s3, 0x1400                                // 0000009BB094: 9701FF03 00001400
	s_add_u32 s2, s10, s0                                      // 0000009BB09C: 8002000A
	s_addc_u32 s3, s11, s1                                     // 0000009BB0A0: 8203010B
	v_cmp_eq_u32_e32 vcc_lo, 0, v0                             // 0000009BB0A4: 7C940080
	s_lshl_b32 s0, s6, 7                                       // 0000009BB0A8: 84008706
	.long 0x7f243880                                           // 0000009BB0AC: 7F243880
	s_ashr_i32 s1, s0, 31                                      // 0000009BB0B0: 86019F00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000009BB0B4: BF870009
	s_lshl_b64 s[0:1], s[0:1], 1                               // 0000009BB0B8: 84808100
	v_cndmask_b32_e64 v0, -v6, v6, vcc_lo                      // 0000009BB0BC: D5010000 21AA0D06
	v_lshlrev_b32_e32 v1, 1, v1                                // 0000009BB0C4: 30020281
	s_add_u32 s2, s2, s0                                       // 0000009BB0C8: 80020002
	s_addc_u32 s3, s3, s1                                      // 0000009BB0CC: 82030103
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 0000009BB0D0: D5010003 21AA0703
	v_add_f32_e32 v0, v0, v4                                   // 0000009BB0D8: 06000900
	s_clause 0x7                                               // 0000009BB0DC: BF850007
	global_load_d16_b16 v18, v1, s[2:3] offset:32              // 0000009BB0E0: DC820020 12020001
	global_load_d16_b16 v19, v1, s[2:3]                        // 0000009BB0E8: DC820000 13020001
	global_load_d16_b16 v20, v1, s[2:3] offset:64              // 0000009BB0F0: DC820040 14020001
	global_load_d16_b16 v21, v1, s[2:3] offset:96              // 0000009BB0F8: DC820060 15020001
	global_load_d16_b16 v22, v1, s[2:3] offset:128             // 0000009BB100: DC820080 16020001
	global_load_d16_b16 v23, v1, s[2:3] offset:160             // 0000009BB108: DC8200A0 17020001
	global_load_d16_b16 v24, v1, s[2:3] offset:192             // 0000009BB110: DC8200C0 18020001
	global_load_d16_b16 v25, v1, s[2:3] offset:224             // 0000009BB118: DC8200E0 19020001
	v_cndmask_b32_e64 v4, -v5, v5, vcc_lo                      // 0000009BB120: D5010004 21AA0B05
	v_cndmask_b32_e64 v5, -v7, v7, vcc_lo                      // 0000009BB128: D5010005 21AA0F07
	v_cndmask_b32_e64 v7, -v16, v16, vcc_lo                    // 0000009BB130: D5010007 21AA2110
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 0000009BB138: D501000E 21AA1D0E
	v_add_f32_e32 v2, v3, v2                                   // 0000009BB140: 06040503
	v_mul_f32_e32 v0, 0x3db504f3, v0                           // 0000009BB144: 100000FF 3DB504F3
	v_dual_add_f32 v3, v5, v8 :: v_dual_add_f32 v4, v4, v9     // 0000009BB14C: C9081105 03041304
	v_cndmask_b32_e64 v16, -v17, v17, vcc_lo                   // 0000009BB154: D5010010 21AA2311
	v_cndmask_b32_e64 v15, -v15, v15, vcc_lo                   // 0000009BB15C: D501000F 21AA1F0F
	v_add_f32_e32 v5, v14, v10                                 // 0000009BB164: 060A150E
	v_add_f32_e32 v7, v7, v11                                  // 0000009BB168: 060E1707
	v_dual_mul_f32 v3, 0x3db504f3, v3 :: v_dual_mul_f32 v4, 0x3db504f3, v4// 0000009BB16C: C8C606FF 030408FF 3DB504F3
	s_waitcnt vmcnt(4)                                         // 0000009BB178: BF8913F7
	.long 0x7f2a3992                                           // 0000009BB17C: 7F2A3992
	v_dual_add_f32 v8, v15, v12 :: v_dual_add_f32 v9, v16, v13 // 0000009BB180: C908190F 08081B10
	v_dual_mul_f32 v2, 0x3db504f3, v2 :: v_dual_mul_f32 v7, 0x3db504f3, v7// 0000009BB188: C8C604FF 02060EFF 3DB504F3
	v_mul_f32_e32 v5, 0x3db504f3, v5                           // 0000009BB194: 100A0AFF 3DB504F3
	.long 0x7f263992                                           // 0000009BB19C: 7F263992
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009BB1A0: BF870004
	v_dual_mul_f32 v9, 0x3db504f3, v9 :: v_dual_mul_f32 v8, 0x3db504f3, v8// 0000009BB1A4: C8C612FF 090810FF 3DB504F3
	.long 0x7f283992                                           // 0000009BB1B0: 7F283992
	.long 0x7f0c3992                                           // 0000009BB1B4: 7F0C3992
	s_mul_i32 s3, s12, 0x1400                                  // 0000009BB1B8: 9603FF0C 00001400
	s_mul_hi_i32 s2, s12, 0x1400                               // 0000009BB1C0: 9702FF0C 00001400
	s_add_u32 s3, s8, s3                                       // 0000009BB1C8: 80030308
	s_addc_u32 s2, s9, s2                                      // 0000009BB1CC: 82020209
	s_add_u32 s0, s3, s0                                       // 0000009BB1D0: 80000003
	s_addc_u32 s1, s2, s1                                      // 0000009BB1D4: 82010102
	v_fma_mix_f32 v0, v18, v0, neg(0) op_sel_hi:[1,0,0]        // 0000009BB1D8: CC200000 8A020112
	v_fma_mix_f32 v2, v19, v2, neg(0) op_sel_hi:[1,0,0]        // 0000009BB1E0: CC200002 8A020513
	v_fma_mix_f32 v3, v20, v3, neg(0) op_sel_hi:[1,0,0]        // 0000009BB1E8: CC200003 8A020714
	v_fma_mix_f32 v4, v21, v4, neg(0) op_sel_hi:[1,0,0]        // 0000009BB1F0: CC200004 8A020915
	s_waitcnt vmcnt(3)                                         // 0000009BB1F8: BF890FF7
	v_fma_mix_f32 v5, v22, v5, neg(0) op_sel_hi:[1,0,0]        // 0000009BB1FC: CC200005 8A020B16
	.long 0x7e243980                                           // 0000009BB204: 7E243980
	s_waitcnt vmcnt(2)                                         // 0000009BB208: BF890BF7
	v_fma_mix_f32 v7, v23, v7, neg(0) op_sel_hi:[1,0,0]        // 0000009BB20C: CC200007 8A020F17
	s_waitcnt vmcnt(1)                                         // 0000009BB214: BF8907F7
	v_fma_mix_f32 v8, v24, v8, neg(0) op_sel_hi:[1,0,0]        // 0000009BB218: CC200008 8A021118
	s_waitcnt vmcnt(0)                                         // 0000009BB220: BF8903F7
	v_fma_mix_f32 v9, v25, v9, neg(0) op_sel_hi:[1,0,0]        // 0000009BB224: CC200009 8A021319
	.long 0x7e0c3982                                           // 0000009BB22C: 7E0C3982
	v_and_b32_e32 v10, 1, v18                                  // 0000009BB230: 36142481
	.long 0x7e243984                                           // 0000009BB234: 7E243984
	.long 0x7e263983                                           // 0000009BB238: 7E263983
	.long 0x7e283985                                           // 0000009BB23C: 7E283985
	.long 0x7e2a3988                                           // 0000009BB240: 7E2A3988
	v_and_b32_e32 v6, 1, v6                                    // 0000009BB244: 360C0C81
	v_and_b32_e32 v11, 1, v18                                  // 0000009BB248: 36162481
	.long 0x7e243987                                           // 0000009BB24C: 7E243987
	v_and_b32_e32 v12, 1, v19                                  // 0000009BB250: 36182681
	v_and_b32_e32 v13, 1, v20                                  // 0000009BB254: 361A2881
	v_and_b32_e32 v15, 1, v21                                  // 0000009BB258: 361E2A81
	v_add3_u32 v2, v2, v6, 0x7fff                              // 0000009BB25C: D6550002 03FE0D02 00007FFF
	v_and_b32_e32 v14, 1, v18                                  // 0000009BB268: 361C2481
	.long 0x7e243989                                           // 0000009BB26C: 7E243989
	v_add3_u32 v0, v0, v10, 0x7fff                             // 0000009BB270: D6550000 03FE1500 00007FFF
	v_add3_u32 v3, v3, v12, 0x7fff                             // 0000009BB27C: D6550003 03FE1903 00007FFF
	v_add3_u32 v4, v4, v11, 0x7fff                             // 0000009BB288: D6550004 03FE1704 00007FFF
	v_add3_u32 v5, v5, v13, 0x7fff                             // 0000009BB294: D6550005 03FE1B05 00007FFF
	v_and_b32_e32 v6, 1, v18                                   // 0000009BB2A0: 360C2481
	v_add3_u32 v8, v8, v15, 0x7fff                             // 0000009BB2A4: D6550008 03FE1F08 00007FFF
	v_add3_u32 v7, v7, v14, 0x7fff                             // 0000009BB2B0: D6550007 03FE1D07 00007FFF
	s_delay_alu instid0(VALU_DEP_3)                            // 0000009BB2BC: BF870003
	v_add3_u32 v6, v9, v6, 0x7fff                              // 0000009BB2C0: D6550006 03FE0D09 00007FFF
	s_clause 0x7                                               // 0000009BB2CC: BF850007
	global_store_d16_hi_b16 v1, v2, s[0:1]                     // 0000009BB2D0: DC960000 00000201
	global_store_d16_hi_b16 v1, v0, s[0:1] offset:32           // 0000009BB2D8: DC960020 00000001
	global_store_d16_hi_b16 v1, v3, s[0:1] offset:64           // 0000009BB2E0: DC960040 00000301
	global_store_d16_hi_b16 v1, v4, s[0:1] offset:96           // 0000009BB2E8: DC960060 00000401
	global_store_d16_hi_b16 v1, v5, s[0:1] offset:128          // 0000009BB2F0: DC960080 00000501
	global_store_d16_hi_b16 v1, v7, s[0:1] offset:160          // 0000009BB2F8: DC9600A0 00000701
	global_store_d16_hi_b16 v1, v8, s[0:1] offset:192          // 0000009BB300: DC9600C0 00000801
	global_store_d16_hi_b16 v1, v6, s[0:1] offset:224          // 0000009BB308: DC9600E0 00000601
	s_endpgm                                                   // 0000009BB310: BFB00000
		...

