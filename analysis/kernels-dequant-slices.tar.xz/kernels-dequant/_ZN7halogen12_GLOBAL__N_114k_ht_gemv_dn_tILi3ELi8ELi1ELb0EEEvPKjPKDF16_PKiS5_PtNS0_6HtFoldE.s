0000000000984600 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi3ELi8ELi1ELb0EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE>:
; _ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi3ELi8ELi1ELb0EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE():
	s_load_b256 s[4:11], s[0:1], null                          // 000000984600: F40C0100 F8000000
	s_mul_hi_i32 s3, s2, 0x66666667                            // 000000984608: 9703FF02 66666667
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000984610: BF8704A9
	s_lshr_b32 s12, s3, 31                                     // 000000984614: 850C9F03
	s_ashr_i32 s3, s3, 3                                       // 000000984618: 86038303
	s_add_i32 s12, s3, s12                                     // 00000098461C: 810C0C03
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000984620: BF870499
	s_ashr_i32 s13, s12, 31                                    // 000000984624: 860D9F0C
	s_lshl_b64 s[14:15], s[12:13], 2                           // 000000984628: 848E820C
	s_waitcnt lgkmcnt(0)                                       // 00000098462C: BF89FC07
	s_add_u32 s14, s8, s14                                     // 000000984630: 800E0E08
	s_addc_u32 s15, s9, s15                                    // 000000984634: 820F0F09
	s_load_b64 s[8:9], s[0:1], 0x20                            // 000000984638: F4040200 F8000020
	s_load_b32 s13, s[14:15], null                             // 000000984640: F4000347 F8000000
	s_mov_b32 s0, exec_lo                                      // 000000984648: BE80007E
	v_cmpx_gt_u32_e32 0x50, v0                                 // 00000098464C: 7D9800FF 00000050
	s_cbranch_execz 12                                         // 000000984654: BFA5000C <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi3ELi8ELi1ELb0EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x88>
	s_mul_i32 s1, s12, 0x500                                   // 000000984658: 9601FF0C 00000500
	v_lshlrev_b32_e32 v5, 4, v0                                // 000000984660: 300A0084
	s_mul_hi_i32 s3, s12, 0x500                                // 000000984664: 9703FF0C 00000500
	s_add_u32 s6, s6, s1                                       // 00000098466C: 80060106
	s_addc_u32 s7, s7, s3                                      // 000000984670: 82070307
	global_load_b128 v[1:4], v5, s[6:7]                        // 000000984674: DC5E0000 01060005
	s_waitcnt vmcnt(0)                                         // 00000098467C: BF8903F7
	ds_store_b128 v5, v[1:4]                                   // 000000984680: DB7C0000 00000105
	s_or_b32 exec_lo, exec_lo, s0                              // 000000984688: 8C7E007E
	v_and_b32_e32 v41, 31, v0                                  // 00000098468C: 3652009F
	v_lshrrev_b32_e32 v40, 5, v0                               // 000000984690: 32500085
	s_mul_i32 s6, s12, 0xffffffec                              // 000000984694: 9606FF0C FFFFFFEC
	s_waitcnt lgkmcnt(0)                                       // 00000098469C: BF89FC07
	s_mul_i32 s1, s13, 0x96000                                 // 0000009846A0: 9601FF0D 00096000
	s_mul_hi_i32 s0, s13, 0x96000                              // 0000009846A8: 9700FF0D 00096000
	v_mad_u32_u24 v16, v41, 24, 0x2f0                          // 0000009846B0: D60B0010 03FD3129 000002F0
	v_mul_u32_u24_e32 v3, 5, v40                               // 0000009846BC: 16065085
	v_cmp_eq_u32_e32 vcc_lo, 0, v41                            // 0000009846C0: 7C945280
	s_add_i32 s6, s6, s2                                       // 0000009846C4: 81060206
	s_add_u32 s1, s4, s1                                       // 0000009846C8: 80010104
	v_lshrrev_b32_e32 v1, 5, v16                               // 0000009846CC: 32022085
	v_min_u32_e32 v2, 35, v3                                   // 0000009846D0: 260406A3
	s_addc_u32 s3, s5, s0                                      // 0000009846D4: 82030005
	s_mul_i32 s2, s6, 0x7800                                   // 0000009846D8: 9602FF06 00007800
	v_add_nc_u32_e32 v4, 8, v16                                // 0000009846E0: 4A082088
	v_subrev_nc_u32_e32 v1, 24, v1                             // 0000009846E4: 4E020298
	v_add_nc_u32_e32 v42, 5, v2                                // 0000009846E8: 4A540485
	s_mul_hi_i32 s4, s6, 0x7800                                // 0000009846EC: 9704FF06 00007800
	s_add_u32 s2, s1, s2                                       // 0000009846F4: 80020201
	s_addc_u32 s3, s3, s4                                      // 0000009846F8: 82030403
	v_cndmask_b32_e64 v10, v1, 23, vcc_lo                      // 0000009846FC: D501000A 01A92F01
	.long 0xd4490000                                           // 000000984704: D4490000
	v_cndmask_b32_e32 v1, v3, v42, vcc_lo                      // 000000984708: 02025503
	s_barrier                                                  // 00000098470C: BFBD0000
	buffer_gl0_inv                                             // 000000984710: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 000000984718: BE842000
	s_cbranch_execz 125                                        // 00000098471C: BFA5007D <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi3ELi8ELi1ELb0EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x314>
	v_lshrrev_b32_e32 v1, 5, v4                                // 000000984720: 32020885
	.long 0xd4440001                                           // 000000984724: D4440001
	v_cndmask_b32_e32 v1, 23, v10, vcc_lo                      // 000000984728: 02021497
	v_mov_b32_e32 v11, 0                                       // 00000098472C: 7E160280
	v_mul_u32_u24_e32 v8, 0xf00, v40                           // 000000984730: 161050FF 00000F00
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000984738: BF870214
	v_subrev_nc_u32_e32 v1, 24, v1                             // 00000098473C: 4E020298
	v_cndmask_b32_e64 v2, 0xe9, 1, s1                          // 000000984740: D5010002 000502FF 000000E9
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000098474C: BF870194
	.long 0xd73c0005                                           // 000000984750: D73C0005
	v_cndmask_b32_e32 v1, 2, v10, vcc_lo                       // 000000984754: 02021482
	v_cndmask_b32_e64 v1, v1, 23, vcc_lo                       // 000000984758: D5010001 01A92F01
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000984760: BF870113
	v_dual_mov_b32 v2, v11 :: v_dual_add_nc_u32 v7, v2, v10    // 000000984764: CA20010B 02061502
	.long 0xd4440001                                           // 00000098476C: D4440001
	v_cndmask_b32_e32 v1, 23, v1, vcc_lo                       // 000000984770: 02020297
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000984774: BF870112
	v_lshlrev_b32_e32 v9, 24, v7                               // 000000984778: 30120E98
	v_cndmask_b32_e64 v11, 0xe9, 1, s1                         // 00000098477C: D501000B 000502FF 000000E9
	.long 0xd700010c                                           // 000000984788: D700010C
	v_cndmask_b32_e32 v1, s2, v8, vcc_lo                       // 00000098478C: 02021002
	v_bfe_i32 v8, v7, 7, 1                                     // 000000984790: D6110008 02050F07
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000984798: BF870214
	v_ashrrev_i32_e32 v7, 22, v9                               // 00000098479C: 340E1296
	v_add_nc_u32_e32 v9, v11, v1                               // 0000009847A0: 4A12030B
	v_add_co_ci_u32_e64 v13, null, s3, 0, s1                   // 0000009847A4: D5207C0D 00050003
	.long 0xd73c0001                                           // 0000009847AC: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000009847B0: 02020282
	.long 0xd7000105                                           // 0000009847B4: D7000105
	v_cndmask_b32_e32 v1, v12, v5, vcc_lo                      // 0000009847B8: 02020B0C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009847BC: BF870214
	v_lshlrev_b32_e32 v11, 24, v9                              // 0000009847C0: 30161298
	v_add_co_ci_u32_e64 v6, null, v13, v6, s1                  // 0000009847C4: D5207C06 00060D0D
	.long 0xd7000107                                           // 0000009847CC: D7000107
	v_cndmask_b32_e32 v1, v12, v7, vcc_lo                      // 0000009847D0: 02020F0C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000009847D4: BF8700C3
	v_ashrrev_i32_e32 v11, 22, v11                             // 0000009847D8: 34161696
	v_bfe_i32 v9, v9, 7, 1                                     // 0000009847DC: D6110009 02050F09
	v_add_co_ci_u32_e64 v8, null, v13, v8, s1                  // 0000009847E4: D5207C08 0006110D
	.long 0xd700012b                                           // 0000009847EC: D700012B
	v_cndmask_b32_e32 v1, v12, v1, vcc_lo                      // 0000009847F0: 0202030C
	v_add_co_ci_u32_e64 v44, null, v13, v2, s1                 // 0000009847F4: D5207C2C 0006050D
	.long 0xd700012d                                           // 0000009847FC: D700012D
	v_cndmask_b32_e32 v1, v12, v11, vcc_lo                     // 000000984800: 0202170C
	s_delay_alu instid0(VALU_DEP_1)                            // 000000984804: BF870001
	v_add_co_ci_u32_e64 v46, null, v13, v9, s1                 // 000000984808: D5207C2E 0006130D
	s_clause 0x1f                                              // 000000984810: BF85001F
	global_load_b32 v37, v[5:6], off                           // 000000984814: DC520000 257C0005
	global_load_b32 v2, v[5:6], off offset:96                  // 00000098481C: DC520060 027C0005
	global_load_b32 v31, v[5:6], off offset:192                // 000000984824: DC5200C0 1F7C0005
	global_load_b32 v27, v[5:6], off offset:288                // 00000098482C: DC520120 1B7C0005
	global_load_b32 v23, v[5:6], off offset:384                // 000000984834: DC520180 177C0005
	global_load_b32 v19, v[5:6], off offset:480                // 00000098483C: DC5201E0 137C0005
	global_load_b32 v13, v[5:6], off offset:576                // 000000984844: DC520240 0D7C0005
	global_load_b32 v9, v[5:6], off offset:672                 // 00000098484C: DC5202A0 097C0005
	global_load_b32 v36, v[7:8], off                           // 000000984854: DC520000 247C0007
	global_load_b32 v1, v[7:8], off offset:96                  // 00000098485C: DC520060 017C0007
	global_load_b32 v30, v[7:8], off offset:192                // 000000984864: DC5200C0 1E7C0007
	global_load_b32 v26, v[7:8], off offset:288                // 00000098486C: DC520120 1A7C0007
	global_load_b32 v22, v[7:8], off offset:384                // 000000984874: DC520180 167C0007
	global_load_b32 v18, v[7:8], off offset:480                // 00000098487C: DC5201E0 127C0007
	global_load_b32 v12, v[7:8], off offset:576                // 000000984884: DC520240 0C7C0007
	global_load_b32 v8, v[7:8], off offset:672                 // 00000098488C: DC5202A0 087C0007
	global_load_b32 v39, v[43:44], off                         // 000000984894: DC520000 277C002B
	global_load_b32 v35, v[43:44], off offset:96               // 00000098489C: DC520060 237C002B
	global_load_b32 v33, v[43:44], off offset:192              // 0000009848A4: DC5200C0 217C002B
	global_load_b32 v29, v[43:44], off offset:288              // 0000009848AC: DC520120 1D7C002B
	global_load_b32 v25, v[43:44], off offset:384              // 0000009848B4: DC520180 197C002B
	global_load_b32 v21, v[43:44], off offset:480              // 0000009848BC: DC5201E0 157C002B
	global_load_b32 v15, v[43:44], off offset:576              // 0000009848C4: DC520240 0F7C002B
	global_load_b32 v7, v[43:44], off offset:672               // 0000009848CC: DC5202A0 077C002B
	global_load_b32 v38, v[45:46], off                         // 0000009848D4: DC520000 267C002D
	global_load_b32 v34, v[45:46], off offset:96               // 0000009848DC: DC520060 227C002D
	global_load_b32 v32, v[45:46], off offset:192              // 0000009848E4: DC5200C0 207C002D
	global_load_b32 v28, v[45:46], off offset:288              // 0000009848EC: DC520120 1C7C002D
	global_load_b32 v24, v[45:46], off offset:384              // 0000009848F4: DC520180 187C002D
	global_load_b32 v20, v[45:46], off offset:480              // 0000009848FC: DC5201E0 147C002D
	global_load_b32 v14, v[45:46], off offset:576              // 000000984904: DC520240 0E7C002D
	global_load_b32 v6, v[45:46], off offset:672               // 00000098490C: DC5202A0 067C002D
	s_or_b32 exec_lo, exec_lo, s4                              // 000000984914: 8C7E047E
	v_dual_mov_b32 v5, 0 :: v_dual_mov_b32 v44, 0              // 000000984918: CA100080 052C0080
	v_dual_mov_b32 v43, 0 :: v_dual_mov_b32 v46, 0             // 000000984920: CA100080 2B2E0080
	v_dual_mov_b32 v45, 0 :: v_dual_mov_b32 v48, 0             // 000000984928: CA100080 2D300080
	v_mov_b32_e32 v47, 0                                       // 000000984930: 7E5E0280
	v_mov_b32_e32 v49, 0                                       // 000000984934: 7E620280
	s_and_saveexec_b32 s1, s0                                  // 000000984938: BE812000
	s_cbranch_execz 1038                                       // 00000098493C: BFA5040E <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi3ELi8ELi1ELb0EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x1378>
	v_lshrrev_b32_e32 v4, 5, v4                                // 000000984940: 32080885
	v_dual_mov_b32 v5, 0 :: v_dual_and_b32 v50, 16, v0         // 000000984944: CA240080 05320090
	v_and_b32_e32 v43, 0x7e0, v16                              // 00000098494C: 365620FF 000007E0
	v_mul_i32_i24_e32 v17, 0xffffffe8, v41                     // 000000984954: 122252FF FFFFFFE8
	s_delay_alu instid0(VALU_DEP_4)                            // 00000098495C: BF870004
	v_subrev_nc_u32_e32 v4, 24, v4                             // 000000984960: 4E080898
	v_lshl_or_b32 v44, v41, 3, 4                               // 000000984964: D656002C 02110729
	v_ashrrev_i32_e32 v11, 31, v10                             // 00000098496C: 3416149F
	s_mov_b32 s0, 0                                            // 000000984970: BE800080
	v_add3_u32 v51, v17, v43, 0xfffffd34                       // 000000984974: D6550033 03FE5711 FFFFFD34
	v_cndmask_b32_e64 v4, v4, 23, vcc_lo                       // 000000984980: D5010004 01A92F04
	v_cmp_gt_i32_e32 vcc_lo, 23, v10                           // 000000984988: 7C881497
	v_mad_u32_u24 v17, v44, 3, 0x2f0                           // 00000098498C: D60B0011 03FD072C 000002F0
	v_mul_i32_i24_e32 v49, -3, v44                             // 000000984998: 126258C3
	v_mov_b32_e32 v46, v5                                      // 00000098499C: 7E5C0305
	.long 0xd7030010                                           // 0000009849A0: D7030010
	v_cndmask_b32_e32 v0, v4, v129, vcc_lo                     // 0000009849A4: 02010304
	v_cndmask_b32_e64 v45, 0xe9, 1, vcc_lo                     // 0000009849A8: D501002D 01A902FF 000000E9
	v_dual_mov_b32 v44, v5 :: v_dual_and_b32 v17, 0x7e0, v17   // 0000009849B4: CA240105 2C1022FF 000007E0
	s_movk_i32 s4, 0x1eee                                      // 0000009849C0: B0041EEE
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009849C4: BF870193
	.long 0xd7624010                                           // 0000009849C8: D7624010
	v_cndmask_b32_e32 v1, 0xff, v16, vcc_lo                    // 0000009849CC: 020220FF 000000FF
	v_add_nc_u32_e32 v47, v45, v10                             // 0000009849D4: 4A5E152D
	.long 0xd73c000a                                           // 0000009849D8: D73C000A
	v_cndmask_b32_e32 v1, 2, v10, vcc_lo                       // 0000009849DC: 02021482
	v_add3_u32 v52, v49, v17, 0xfffffd34                       // 0000009849E0: D6550034 03FE2331 FFFFFD34
	v_mov_b32_e32 v49, v5                                      // 0000009849EC: 7E620305
	v_cmp_ne_u16_e32 vcc_lo, 24, v144/*Invalid register, operand has 'VGPR_32_Lo128' register class*/// 0000009849F0: 7C7B2098
	v_dual_mov_b32 v48, v5 :: v_dual_and_b32 v53, 0xff, v47    // 0000009849F4: CA240105 30345EFF 000000FF
	v_mov_b32_e32 v47, v5                                      // 000000984A00: 7E5E0305
	v_cndmask_b16 v16, 0, v16, vcc_lo                          // 000000984A04: D65D0010 01AA2080
	v_mov_b32_e32 v43, v5                                      // 000000984A0C: 7E560305
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000984A10: BF870194
	v_lshlrev_b32_e32 v53, 2, v53                              // 000000984A14: 306A6A82
	v_and_b32_e32 v54, 0xff, v16                               // 000000984A18: 366C20FF 000000FF
	.long 0xd73c0010                                           // 000000984A20: D73C0010
	v_cndmask_b32_e32 v1, 2, v4, vcc_lo                        // 000000984A24: 02020882
	s_delay_alu instid0(VALU_DEP_2)                            // 000000984A28: BF870002
	v_dual_mov_b32 v45, v5 :: v_dual_lshlrev_b32 v54, 2, v54   // 000000984A2C: CA220105 2D366C82
	s_branch 881                                               // 000000984A34: BFA00371 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi3ELi8ELi1ELb0EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x11fc>
	s_or_b32 exec_lo, exec_lo, s5                              // 000000984A38: 8C7E057E
	s_waitcnt vmcnt(23)                                        // 000000984A3C: BF895FF7
	.long 0xd73d0024                                           // 000000984A40: D73D0024
	v_cndmask_b32_e32 v1, v51, v36, vcc_lo                     // 000000984A44: 02024933
	s_waitcnt vmcnt(6)                                         // 000000984A48: BF891BF7
	.long 0xd73d0022                                           // 000000984A4C: D73D0022
	v_cndmask_b32_e32 v1, v52, v34, vcc_lo                     // 000000984A50: 02024534
	.long 0xd73d0025                                           // 000000984A54: D73D0025
	v_cndmask_b32_e32 v1, v52, v38, vcc_lo                     // 000000984A58: 02024D34
	.long 0xd73d0026                                           // 000000984A5C: D73D0026
	v_cndmask_b32_e32 v1, v51, v1, vcc_lo                      // 000000984A60: 02020333
	v_lshl_or_b32 v3, v3, 5, v50                               // 000000984A64: D6560003 04C90B03
	.long 0xd73d001e                                           // 000000984A6C: D73D001E
	v_cndmask_b32_e32 v1, v51, v30, vcc_lo                     // 000000984A70: 02023D33
	v_bfe_u32 v35, v36, 9, 16                                  // 000000984A74: D6100023 02411324
	v_bfe_u32 v39, v36, 6, 16                                  // 000000984A7C: D6100027 02410D24
	v_bfe_u32 v89, v37, 9, 16                                  // 000000984A84: D6100059 02411325
	ds_load_b128 v[1:4], v3                                    // 000000984A8C: DBFC0000 01000003
	v_bfe_u32 v90, v37, 6, 16                                  // 000000984A94: D610005A 02410D25
	.long 0xd72c0023                                           // 000000984A9C: D72C0023
	v_cndmask_b32_e32 v1, 0x83dcd12d, v35, vcc_lo              // 000000984AA0: 020246FF 83DCD12D
	.long 0xd72c0027                                           // 000000984AA8: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 000000984AAC: 02024EFF 83DCD12D
	.long 0xd72c0059                                           // 000000984AB4: D72C0059
	v_cndmask_b32_e32 v1, 0x83dcd12d, v89, vcc_lo              // 000000984AB8: 0202B2FF 83DCD12D
	v_bfe_u32 v88, v36, 3, 16                                  // 000000984AC0: D6100058 02410724
	.long 0xd72c005a                                           // 000000984AC8: D72C005A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v90, vcc_lo              // 000000984ACC: 0202B4FF 83DCD12D
	v_bfe_u32 v91, v37, 3, 16                                  // 000000984AD4: D610005B 02410725
	.long 0xd73d001a                                           // 000000984ADC: D73D001A
	v_cndmask_b32_e32 v1, v51, v26, vcc_lo                     // 000000984AE0: 02023533
	.long 0xd73d0016                                           // 000000984AE4: D73D0016
	v_cndmask_b32_e32 v1, v51, v22, vcc_lo                     // 000000984AE8: 02022D33
	v_sad_u8 v35, v35, 0, 0x6400                               // 000000984AEC: D6220023 03FD0123 00006400
	v_sad_u8 v39, v39, 0, 0x6400                               // 000000984AF8: D6220027 03FD0127 00006400
	v_sad_u8 v89, v89, 0, 0x6400                               // 000000984B04: D6220059 03FD0159 00006400
	.long 0xd72c0058                                           // 000000984B10: D72C0058
	v_cndmask_b32_e32 v1, 0x83dcd12d, v88, vcc_lo              // 000000984B14: 0202B0FF 83DCD12D
	.long 0xd72c005b                                           // 000000984B1C: D72C005B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v91, vcc_lo              // 000000984B20: 0202B6FF 83DCD12D
	v_and_b32_e32 v35, 0xffff, v35                             // 000000984B28: 364646FF 0000FFFF
	.long 0xd73d0012                                           // 000000984B30: D73D0012
	v_cndmask_b32_e32 v1, v51, v18, vcc_lo                     // 000000984B34: 02022533
	v_and_b32_e32 v89, 0xffff, v89                             // 000000984B38: 36B2B2FF 0000FFFF
	.long 0xd73d000c                                           // 000000984B40: D73D000C
	v_cndmask_b32_e32 v1, v51, v12, vcc_lo                     // 000000984B44: 02021933
	s_waitcnt vmcnt(1)                                         // 000000984B48: BF8907F7
	.long 0xd73d000d                                           // 000000984B4C: D73D000D
	v_cndmask_b32_e32 v1, v52, v14, vcc_lo                     // 000000984B50: 02021D34
	v_lshl_or_b32 v35, v39, 16, v35                            // 000000984B54: D6560023 048D2127
	v_sad_u8 v39, v90, 0, 0x6400                               // 000000984B5C: D6220027 03FD015A 00006400
	v_sad_u8 v88, v88, 0, 0x6400                               // 000000984B68: D6220058 03FD0158 00006400
	v_bfe_u32 v90, v34, 3, 16                                  // 000000984B74: D610005A 02410722
	v_bfe_u32 v15, v12, 9, 16                                  // 000000984B7C: D610000F 0241130C
	v_pk_fma_f16 v35, v35, s4, 0xc931 op_sel_hi:[1,0,0]        // 000000984B84: CC0E0023 0BFC0923 0000C931
	v_and_b32_e32 v36, 0xffff, v36                             // 000000984B90: 364848FF 0000FFFF
	v_lshl_or_b32 v39, v39, 16, v89                            // 000000984B98: D6560027 05652127
	v_bfe_u32 v89, v38, 6, 16                                  // 000000984BA0: D6100059 02410D26
	.long 0xd72c000f                                           // 000000984BA8: D72C000F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v15, vcc_lo              // 000000984BAC: 02021EFF 83DCD12D
	s_waitcnt lgkmcnt(0)                                       // 000000984BB4: BF89FC07
	v_dot2acc_f32_f16 v49, v35, v1                             // 000000984BB8: 04620323
	.long 0xd72c0024                                           // 000000984BBC: D72C0024
	v_cndmask_b32_e32 v1, 0x83dcd12d, v36, vcc_lo              // 000000984BC0: 020248FF 83DCD12D
	v_bfe_u32 v35, v38, 9, 16                                  // 000000984BC8: D6100023 02411326
	.long 0xd72c0059                                           // 000000984BD0: D72C0059
	v_cndmask_b32_e32 v1, 0x83dcd12d, v89, vcc_lo              // 000000984BD4: 0202B2FF 83DCD12D
	v_pk_fma_f16 v39, v39, s4, 0xc931 op_sel_hi:[1,0,0]        // 000000984BDC: CC0E0027 0BFC0927 0000C931
	.long 0xd73d0008                                           // 000000984BE8: D73D0008
	v_cndmask_b32_e32 v1, v51, v8, vcc_lo                      // 000000984BEC: 02021133
	s_waitcnt vmcnt(0)                                         // 000000984BF0: BF8903F7
	.long 0xd73d0006                                           // 000000984BF4: D73D0006
	v_cndmask_b32_e32 v1, v52, v6, vcc_lo                      // 000000984BF8: 02020D34
	.long 0xd72c0023                                           // 000000984BFC: D72C0023
	v_cndmask_b32_e32 v1, 0x83dcd12d, v35, vcc_lo              // 000000984C00: 020246FF 83DCD12D
	v_sad_u8 v15, v15, 0, 0x6400                               // 000000984C08: D622000F 03FD010F 00006400
	v_sad_u8 v36, v36, 0, 0x6400                               // 000000984C14: D6220024 03FD0124 00006400
	v_cmp_eq_u32_e32 vcc_lo, v87, v42                          // 000000984C20: 7C945557
	v_sad_u8 v89, v89, 0, 0x6400                               // 000000984C24: D6220059 03FD0159 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000984C30: BF870214
	v_and_b32_e32 v15, 0xffff, v15                             // 000000984C34: 361E1EFF 0000FFFF
	v_lshlrev_b32_e32 v36, 16, v36                             // 000000984C3C: 30484890
	v_sad_u8 v35, v35, 0, 0x6400                               // 000000984C40: D6220023 03FD0123 00006400
	s_or_b32 s0, vcc_lo, s0                                    // 000000984C4C: 8C00006A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000984C50: BF870112
	v_and_or_b32 v36, 0xffff, v88, v36                         // 000000984C54: D6570024 0492B0FF 0000FFFF
	v_and_b32_e32 v35, 0xffff, v35                             // 000000984C60: 364646FF 0000FFFF
	v_sad_u8 v88, v91, 0, 0x6400                               // 000000984C68: D6220058 03FD015B 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000984C74: BF870193
	v_pk_fma_f16 v36, v36, s4, 0xc931 op_sel_hi:[1,0,0]        // 000000984C78: CC0E0024 0BFC0924 0000C931
	v_lshl_or_b32 v35, v89, 16, v35                            // 000000984C84: D6560023 048D2159
	.long 0xd72c0059                                           // 000000984C8C: D72C0059
	v_cndmask_b32_e32 v1, 0x83dcd12d, v90, vcc_lo              // 000000984C90: 0202B4FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000984C98: BF870212
	v_pk_fma_f16 v35, v35, s4, 0xc931 op_sel_hi:[1,0,0]        // 000000984C9C: CC0E0023 0BFC0923 0000C931
	v_dot2acc_f32_f16 v49, v36, v2                             // 000000984CA8: 04620524
	v_bfe_u32 v36, v38, 3, 16                                  // 000000984CAC: D6100024 02410726
	v_and_b32_e32 v38, 0xffff, v38                             // 000000984CB4: 364C4CFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000984CBC: BF870214
	v_dot2acc_f32_f16 v48, v35, v1                             // 000000984CC0: 04600323
	v_dot2acc_f32_f16 v49, v39, v3                             // 000000984CC4: 04620727
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000984CC8: BF870214
	.long 0xd72c0024                                           // 000000984CCC: D72C0024
	v_cndmask_b32_e32 v1, 0x83dcd12d, v36, vcc_lo              // 000000984CD0: 020248FF 83DCD12D
	.long 0xd72c0026                                           // 000000984CD8: D72C0026
	v_cndmask_b32_e32 v1, 0x83dcd12d, v38, vcc_lo              // 000000984CDC: 02024CFF 83DCD12D
	v_bfe_u32 v39, v34, 9, 16                                  // 000000984CE4: D6100027 02411322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000984CEC: BF870211
	.long 0xd72c0027                                           // 000000984CF0: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 000000984CF4: 02024EFF 83DCD12D
	v_sad_u8 v36, v36, 0, 0x6400                               // 000000984CFC: D6220024 03FD0124 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000984D08: BF870094
	v_sad_u8 v38, v38, 0, 0x6400                               // 000000984D0C: D6220026 03FD0126 00006400
	v_lshlrev_b32_e32 v38, 16, v38                             // 000000984D18: 304C4C90
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000984D1C: BF870114
	v_sad_u8 v39, v39, 0, 0x6400                               // 000000984D20: D6220027 03FD0127 00006400
	v_and_or_b32 v36, 0xffff, v36, v38                         // 000000984D2C: D6570024 049A48FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000984D38: BF8701A2
	v_and_b32_e32 v39, 0xffff, v39                             // 000000984D3C: 364E4EFF 0000FFFF
	v_sad_u8 v38, v89, 0, 0x6400                               // 000000984D44: D6220026 03FD0159 00006400
	v_pk_fma_f16 v36, v36, s4, 0xc931 op_sel_hi:[1,0,0]        // 000000984D50: CC0E0024 0BFC0924 0000C931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000984D5C: BF870091
	v_dual_dot2acc_f32_f16 v48, v36, v2 :: v_dual_and_b32 v37, 0xffff, v37// 000000984D60: CB240524 30244AFF 0000FFFF
	.long 0xd72c0025                                           // 000000984D6C: D72C0025
	v_cndmask_b32_e32 v1, 0x83dcd12d, v37, vcc_lo              // 000000984D70: 02024AFF 83DCD12D
	v_mov_b32_e32 v36, v78                                     // 000000984D78: 7E48034E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000984D7C: BF870092
	v_sad_u8 v37, v37, 0, 0x6400                               // 000000984D80: D6220025 03FD0125 00006400
	v_lshlrev_b32_e32 v37, 16, v37                             // 000000984D8C: 304A4A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000984D90: BF8701B1
	v_and_or_b32 v37, 0xffff, v88, v37                         // 000000984D94: D6570025 0496B0FF 0000FFFF
	v_bfe_u32 v88, v34, 6, 16                                  // 000000984DA0: D6100058 02410D22
	v_and_b32_e32 v34, 0xffff, v34                             // 000000984DA8: 364444FF 0000FFFF
	v_pk_fma_f16 v37, v37, s4, 0xc931 op_sel_hi:[1,0,0]        // 000000984DB0: CC0E0025 0BFC0925 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000984DBC: BF870193
	.long 0xd72c0058                                           // 000000984DC0: D72C0058
	v_cndmask_b32_e32 v1, 0x83dcd12d, v88, vcc_lo              // 000000984DC4: 0202B0FF 83DCD12D
	.long 0xd72c0022                                           // 000000984DCC: D72C0022
	v_cndmask_b32_e32 v1, 0x83dcd12d, v34, vcc_lo              // 000000984DD0: 020244FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000984DD8: BF870223
	v_dot2acc_f32_f16 v49, v37, v4                             // 000000984DDC: 04620925
	v_mov_b32_e32 v37, v62                                     // 000000984DE0: 7E4A033E
	v_sad_u8 v88, v88, 0, 0x6400                               // 000000984DE4: D6220058 03FD0158 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000984DF0: BF870114
	v_sad_u8 v34, v34, 0, 0x6400                               // 000000984DF4: D6220022 03FD0122 00006400
	v_lshl_or_b32 v31, v88, 16, v39                            // 000000984E00: D656001F 049D2158
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000984E08: BF8701A2
	v_lshlrev_b32_e32 v34, 16, v34                             // 000000984E0C: 30444490
	v_bfe_u32 v39, v30, 9, 16                                  // 000000984E10: D6100027 0241131E
	v_pk_fma_f16 v88, v31, s4, 0xc931 op_sel_hi:[1,0,0]        // 000000984E18: CC0E0058 0BFC091F 0000C931
	.long 0xd73d001f                                           // 000000984E24: D73D001F
	v_cndmask_b32_e32 v1, v52, v32, vcc_lo                     // 000000984E28: 02024134
	s_delay_alu instid0(VALU_DEP_4)                            // 000000984E2C: BF870004
	v_and_or_b32 v32, 0xffff, v38, v34                         // 000000984E30: D6570020 048A4CFF 0000FFFF
	v_and_b32_e32 v33, 0xffff, v30                             // 000000984E3C: 36423CFF 0000FFFF
	.long 0xd72c0022                                           // 000000984E44: D72C0022
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 000000984E48: 02024EFF 83DCD12D
	v_bfe_u32 v38, v30, 6, 16                                  // 000000984E50: D6100026 02410D1E
	v_bfe_u32 v30, v30, 3, 16                                  // 000000984E58: D610001E 0241071E
	v_bfe_u32 v39, v31, 9, 16                                  // 000000984E60: D6100027 0241131F
	.long 0xd72c0021                                           // 000000984E68: D72C0021
	v_cndmask_b32_e32 v1, 0x83dcd12d, v33, vcc_lo              // 000000984E6C: 020242FF 83DCD12D
	v_bfe_u32 v89, v31, 6, 16                                  // 000000984E74: D6100059 02410D1F
	.long 0xd72c0026                                           // 000000984E7C: D72C0026
	v_cndmask_b32_e32 v1, 0x83dcd12d, v38, vcc_lo              // 000000984E80: 02024CFF 83DCD12D
	.long 0xd72c001e                                           // 000000984E88: D72C001E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v30, vcc_lo              // 000000984E8C: 02023CFF 83DCD12D
	v_sad_u8 v34, v34, 0, 0x6400                               // 000000984E94: D6220022 03FD0122 00006400
	.long 0xd72c0027                                           // 000000984EA0: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 000000984EA4: 02024EFF 83DCD12D
	v_bfe_u32 v90, v31, 3, 16                                  // 000000984EAC: D610005A 0241071F
	v_and_b32_e32 v31, 0xffff, v31                             // 000000984EB4: 363E3EFF 0000FFFF
	v_sad_u8 v33, v33, 0, 0x6400                               // 000000984EBC: D6220021 03FD0121 00006400
	v_and_b32_e32 v34, 0xffff, v34                             // 000000984EC8: 364444FF 0000FFFF
	v_sad_u8 v38, v38, 0, 0x6400                               // 000000984ED0: D6220026 03FD0126 00006400
	.long 0xd72c0059                                           // 000000984EDC: D72C0059
	v_cndmask_b32_e32 v1, 0x83dcd12d, v89, vcc_lo              // 000000984EE0: 0202B2FF 83DCD12D
	.long 0xd72c001f                                           // 000000984EE8: D72C001F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v31, vcc_lo              // 000000984EEC: 02023EFF 83DCD12D
	v_sad_u8 v30, v30, 0, 0x6400                               // 000000984EF4: D622001E 03FD011E 00006400
	v_lshlrev_b32_e32 v33, 16, v33                             // 000000984F00: 30424290
	v_sad_u8 v39, v39, 0, 0x6400                               // 000000984F04: D6220027 03FD0127 00006400
	v_lshl_or_b32 v34, v38, 16, v34                            // 000000984F10: D6560022 04892126
	.long 0xd72c005a                                           // 000000984F18: D72C005A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v90, vcc_lo              // 000000984F1C: 0202B4FF 83DCD12D
	v_dot2acc_f32_f16 v48, v88, v3                             // 000000984F24: 04600758
	v_and_or_b32 v30, 0xffff, v30, v33                         // 000000984F28: D657001E 04863CFF 0000FFFF
	v_and_b32_e32 v33, 0xffff, v39                             // 000000984F34: 36424EFF 0000FFFF
	v_sad_u8 v35, v89, 0, 0x6400                               // 000000984F3C: D6220023 03FD0159 00006400
	v_pk_fma_f16 v34, v34, s4, 0xc931 op_sel_hi:[1,0,0]        // 000000984F48: CC0E0022 0BFC0922 0000C931
	v_sad_u8 v31, v31, 0, 0x6400                               // 000000984F54: D622001F 03FD011F 00006400
	v_pk_fma_f16 v30, v30, s4, 0xc931 op_sel_hi:[1,0,0]        // 000000984F60: CC0E001E 0BFC091E 0000C931
	v_sad_u8 v38, v90, 0, 0x6400                               // 000000984F6C: D6220026 03FD015A 00006400
	v_lshl_or_b32 v33, v35, 16, v33                            // 000000984F78: D6560021 04852123
	v_dot2acc_f32_f16 v47, v34, v1                             // 000000984F80: 045E0322
	v_dual_mov_b32 v34, v85 :: v_dual_lshlrev_b32 v31, 16, v31 // 000000984F84: CA220155 221E3E90
	v_mov_b32_e32 v35, v81                                     // 000000984F8C: 7E460351
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000984F90: BF870214
	v_pk_fma_f16 v27, v33, s4, 0xc931 op_sel_hi:[1,0,0]        // 000000984F94: CC0E001B 0BFC0921 0000C931
	v_dot2acc_f32_f16 v47, v30, v2                             // 000000984FA0: 045E051E
	s_delay_alu instid0(VALU_DEP_4)                            // 000000984FA4: BF870004
	v_and_or_b32 v31, 0xffff, v38, v31                         // 000000984FA8: D657001F 047E4CFF 0000FFFF
	v_pk_fma_f16 v30, v32, s4, 0xc931 op_sel_hi:[1,0,0]        // 000000984FB4: CC0E001E 0BFC0920 0000C931
	v_bfe_u32 v32, v26, 9, 16                                  // 000000984FC0: D6100020 0241131A
	v_mov_b32_e32 v39, v83                                     // 000000984FC8: 7E4E0353
	v_dot2acc_f32_f16 v47, v27, v3                             // 000000984FCC: 045E071B
	.long 0xd73d001b                                           // 000000984FD0: D73D001B
	v_cndmask_b32_e32 v1, v52, v28, vcc_lo                     // 000000984FD4: 02023934
	v_pk_fma_f16 v31, v31, s4, 0xc931 op_sel_hi:[1,0,0]        // 000000984FD8: CC0E001F 0BFC091F 0000C931
	v_dual_dot2acc_f32_f16 v48, v30, v4 :: v_dual_and_b32 v29, 0xffff, v26// 000000984FE4: CB24091E 301C34FF 0000FFFF
	.long 0xd72c001c                                           // 000000984FF0: D72C001C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v32, vcc_lo              // 000000984FF4: 020240FF 83DCD12D
	v_bfe_u32 v30, v26, 6, 16                                  // 000000984FFC: D610001E 02410D1A
	s_delay_alu instid0(VALU_DEP_4)                            // 000000985004: BF870004
	v_dot2acc_f32_f16 v47, v31, v4                             // 000000985008: 045E091F
	v_bfe_u32 v31, v27, 9, 16                                  // 00000098500C: D610001F 0241131B
	v_bfe_u32 v26, v26, 3, 16                                  // 000000985014: D610001A 0241071A
	v_bfe_u32 v32, v27, 6, 16                                  // 00000098501C: D6100020 02410D1B
	.long 0xd72c001d                                           // 000000985024: D72C001D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v29, vcc_lo              // 000000985028: 02023AFF 83DCD12D
	v_bfe_u32 v33, v27, 3, 16                                  // 000000985030: D6100021 0241071B
	v_and_b32_e32 v27, 0xffff, v27                             // 000000985038: 363636FF 0000FFFF
	.long 0xd72c001f                                           // 000000985040: D72C001F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v31, vcc_lo              // 000000985044: 02023EFF 83DCD12D
	.long 0xd72c001a                                           // 00000098504C: D72C001A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v26, vcc_lo              // 000000985050: 020234FF 83DCD12D
	.long 0xd72c0020                                           // 000000985058: D72C0020
	v_cndmask_b32_e32 v1, 0x83dcd12d, v32, vcc_lo              // 00000098505C: 020240FF 83DCD12D
	.long 0xd72c0021                                           // 000000985064: D72C0021
	v_cndmask_b32_e32 v1, 0x83dcd12d, v33, vcc_lo              // 000000985068: 020242FF 83DCD12D
	.long 0xd72c001b                                           // 000000985070: D72C001B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v27, vcc_lo              // 000000985074: 020236FF 83DCD12D
	v_sad_u8 v29, v29, 0, 0x6400                               // 00000098507C: D622001D 03FD011D 00006400
	.long 0xd72c001e                                           // 000000985088: D72C001E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v30, vcc_lo              // 00000098508C: 02023CFF 83DCD12D
	v_sad_u8 v28, v28, 0, 0x6400                               // 000000985094: D622001C 03FD011C 00006400
	v_sad_u8 v31, v31, 0, 0x6400                               // 0000009850A0: D622001F 03FD011F 00006400
	v_sad_u8 v26, v26, 0, 0x6400                               // 0000009850AC: D622001A 03FD011A 00006400
	v_lshlrev_b32_e32 v29, 16, v29                             // 0000009850B8: 303A3A90
	v_sad_u8 v32, v32, 0, 0x6400                               // 0000009850BC: D6220020 03FD0120 00006400
	v_sad_u8 v27, v27, 0, 0x6400                               // 0000009850C8: D622001B 03FD011B 00006400
	v_and_b32_e32 v31, 0xffff, v31                             // 0000009850D4: 363E3EFF 0000FFFF
	v_and_b32_e32 v28, 0xffff, v28                             // 0000009850DC: 363838FF 0000FFFF
	v_and_or_b32 v26, 0xffff, v26, v29                         // 0000009850E4: D657001A 047634FF 0000FFFF
	v_sad_u8 v29, v33, 0, 0x6400                               // 0000009850F0: D622001D 03FD0121 00006400
	v_lshlrev_b32_e32 v27, 16, v27                             // 0000009850FC: 30363690
	v_sad_u8 v30, v30, 0, 0x6400                               // 000000985100: D622001E 03FD011E 00006400
	v_lshl_or_b32 v23, v32, 16, v31                            // 00000098510C: D6560017 047D2120
	v_pk_fma_f16 v26, v26, s4, 0xc931 op_sel_hi:[1,0,0]        // 000000985114: CC0E001A 0BFC091A 0000C931
	v_mov_b32_e32 v38, v86                                     // 000000985120: 7E4C0356
	v_and_or_b32 v27, 0xffff, v29, v27                         // 000000985124: D657001B 046E3AFF 0000FFFF
	v_and_b32_e32 v29, 0xffff, v22                             // 000000985130: 363A2CFF 0000FFFF
	v_lshl_or_b32 v28, v30, 16, v28                            // 000000985138: D656001C 0471211E
	v_bfe_u32 v30, v22, 9, 16                                  // 000000985140: D610001E 02411316
	v_pk_fma_f16 v31, v23, s4, 0xc931 op_sel_hi:[1,0,0]        // 000000985148: CC0E001F 0BFC0917 0000C931
	.long 0xd73d0017                                           // 000000985154: D73D0017
	v_cndmask_b32_e32 v1, v52, v24, vcc_lo                     // 000000985158: 02023134
	v_bfe_u32 v25, v22, 6, 16                                  // 00000098515C: D6100019 02410D16
	v_bfe_u32 v22, v22, 3, 16                                  // 000000985164: D6100016 02410716
	.long 0xd72c001d                                           // 00000098516C: D72C001D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v29, vcc_lo              // 000000985170: 02023AFF 83DCD12D
	.long 0xd72c0018                                           // 000000985178: D72C0018
	v_cndmask_b32_e32 v1, 0x83dcd12d, v30, vcc_lo              // 00000098517C: 02023CFF 83DCD12D
	v_pk_fma_f16 v28, v28, s4, 0xc931 op_sel_hi:[1,0,0]        // 000000985184: CC0E001C 0BFC091C 0000C931
	v_bfe_u32 v30, v23, 9, 16                                  // 000000985190: D610001E 02411317
	.long 0xd72c0016                                           // 000000985198: D72C0016
	v_cndmask_b32_e32 v1, 0x83dcd12d, v22, vcc_lo              // 00000098519C: 02022CFF 83DCD12D
	.long 0xd72c0019                                           // 0000009851A4: D72C0019
	v_cndmask_b32_e32 v1, 0x83dcd12d, v25, vcc_lo              // 0000009851A8: 020232FF 83DCD12D
	v_and_b32_e32 v33, 0xffff, v23                             // 0000009851B0: 36422EFF 0000FFFF
	v_bfe_u32 v32, v23, 6, 16                                  // 0000009851B8: D6100020 02410D17
	v_sad_u8 v29, v29, 0, 0x6400                               // 0000009851C0: D622001D 03FD011D 00006400
	v_sad_u8 v24, v24, 0, 0x6400                               // 0000009851CC: D6220018 03FD0118 00006400
	.long 0xd72c001e                                           // 0000009851D8: D72C001E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v30, vcc_lo              // 0000009851DC: 02023CFF 83DCD12D
	v_bfe_u32 v23, v23, 3, 16                                  // 0000009851E4: D6100017 02410717
	v_sad_u8 v22, v22, 0, 0x6400                               // 0000009851EC: D6220016 03FD0116 00006400
	v_lshlrev_b32_e32 v29, 16, v29                             // 0000009851F8: 303A3A90
	v_sad_u8 v25, v25, 0, 0x6400                               // 0000009851FC: D6220019 03FD0119 00006400
	.long 0xd72c0021                                           // 000000985208: D72C0021
	v_cndmask_b32_e32 v1, 0x83dcd12d, v33, vcc_lo              // 00000098520C: 020242FF 83DCD12D
	.long 0xd72c0020                                           // 000000985214: D72C0020
	v_cndmask_b32_e32 v1, 0x83dcd12d, v32, vcc_lo              // 000000985218: 020240FF 83DCD12D
	.long 0xd72c0017                                           // 000000985220: D72C0017
	v_cndmask_b32_e32 v1, 0x83dcd12d, v23, vcc_lo              // 000000985224: 02022EFF 83DCD12D
	v_and_or_b32 v22, 0xffff, v22, v29                         // 00000098522C: D6570016 04762CFF 0000FFFF
	v_sad_u8 v30, v30, 0, 0x6400                               // 000000985238: D622001E 03FD011E 00006400
	v_dot2acc_f32_f16 v46, v28, v1                             // 000000985244: 045C031C
	v_pk_fma_f16 v27, v27, s4, 0xc931 op_sel_hi:[1,0,0]        // 000000985248: CC0E001B 0BFC091B 0000C931
	s_delay_alu instid0(VALU_DEP_4)                            // 000000985254: BF870004
	v_pk_fma_f16 v22, v22, s4, 0xc931 op_sel_hi:[1,0,0]        // 000000985258: CC0E0016 0BFC0916 0000C931
	v_and_b32_e32 v24, 0xffff, v24                             // 000000985264: 363030FF 0000FFFF
	v_sad_u8 v28, v33, 0, 0x6400                               // 00000098526C: D622001C 03FD0121 00006400
	v_sad_u8 v29, v32, 0, 0x6400                               // 000000985278: D622001D 03FD0120 00006400
	v_sad_u8 v19, v23, 0, 0x6400                               // 000000985284: D6220013 03FD0117 00006400
	v_dot2acc_f32_f16 v46, v26, v2                             // 000000985290: 045C051A
	v_lshl_or_b32 v24, v25, 16, v24                            // 000000985294: D6560018 04612119
	v_and_b32_e32 v25, 0xffff, v30                             // 00000098529C: 36323CFF 0000FFFF
	v_dual_mov_b32 v28, v82 :: v_dual_lshlrev_b32 v23, 16, v28 // 0000009852A4: CA220152 1C163890
	v_mov_b32_e32 v32, v84                                     // 0000009852AC: 7E400354
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009852B0: BF870214
	v_pk_fma_f16 v24, v24, s4, 0xc931 op_sel_hi:[1,0,0]        // 0000009852B4: CC0E0018 0BFC0918 0000C931
	v_lshl_or_b32 v25, v29, 16, v25                            // 0000009852C0: D6560019 0465211D
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009852C8: BF870004
	v_and_or_b32 v23, 0xffff, v19, v23                         // 0000009852CC: D6570017 045E26FF 0000FFFF
	.long 0xd73d0013                                           // 0000009852D8: D73D0013
	v_cndmask_b32_e32 v1, v52, v20, vcc_lo                     // 0000009852DC: 02022934
	v_mov_b32_e32 v30, v72                                     // 0000009852E0: 7E3C0348
	v_dot2acc_f32_f16 v45, v24, v1                             // 0000009852E4: 045A0318
	v_pk_fma_f16 v24, v25, s4, 0xc931 op_sel_hi:[1,0,0]        // 0000009852E8: CC0E0018 0BFC0919 0000C931
	v_bfe_u32 v25, v18, 9, 16                                  // 0000009852F4: D6100019 02411312
	v_pk_fma_f16 v21, v23, s4, 0xc931 op_sel_hi:[1,0,0]        // 0000009852FC: CC0E0015 0BFC0917 0000C931
	v_bfe_u32 v23, v18, 3, 16                                  // 000000985308: D6100017 02410712
	v_dot2acc_f32_f16 v45, v22, v2                             // 000000985310: 045A0516
	v_bfe_u32 v22, v18, 6, 16                                  // 000000985314: D6100016 02410D12
	.long 0xd72c0014                                           // 00000098531C: D72C0014
	v_cndmask_b32_e32 v1, 0x83dcd12d, v25, vcc_lo              // 000000985320: 020232FF 83DCD12D
	v_and_b32_e32 v18, 0xffff, v18                             // 000000985328: 362424FF 0000FFFF
	v_bfe_u32 v25, v19, 6, 16                                  // 000000985330: D6100019 02410D13
	v_dot2acc_f32_f16 v45, v24, v3                             // 000000985338: 045A0718
	v_bfe_u32 v24, v19, 9, 16                                  // 00000098533C: D6100018 02411313
	.long 0xd72c0016                                           // 000000985344: D72C0016
	v_cndmask_b32_e32 v1, 0x83dcd12d, v22, vcc_lo              // 000000985348: 02022CFF 83DCD12D
	.long 0xd72c0012                                           // 000000985350: D72C0012
	v_cndmask_b32_e32 v1, 0x83dcd12d, v18, vcc_lo              // 000000985354: 020224FF 83DCD12D
	.long 0xd72c0017                                           // 00000098535C: D72C0017
	v_cndmask_b32_e32 v1, 0x83dcd12d, v23, vcc_lo              // 000000985360: 02022EFF 83DCD12D
	v_sad_u8 v20, v20, 0, 0x6400                               // 000000985368: D6220014 03FD0114 00006400
	.long 0xd72c0018                                           // 000000985374: D72C0018
	v_cndmask_b32_e32 v1, 0x83dcd12d, v24, vcc_lo              // 000000985378: 020230FF 83DCD12D
	.long 0xd72c0019                                           // 000000985380: D72C0019
	v_cndmask_b32_e32 v1, 0x83dcd12d, v25, vcc_lo              // 000000985384: 020232FF 83DCD12D
	v_and_b32_e32 v26, 0xffff, v19                             // 00000098538C: 363426FF 0000FFFF
	v_bfe_u32 v19, v19, 3, 16                                  // 000000985394: D6100013 02410713
	v_and_b32_e32 v20, 0xffff, v20                             // 00000098539C: 362828FF 0000FFFF
	v_sad_u8 v22, v22, 0, 0x6400                               // 0000009853A4: D6220016 03FD0116 00006400
	v_sad_u8 v18, v18, 0, 0x6400                               // 0000009853B0: D6220012 03FD0112 00006400
	.long 0xd72c001a                                           // 0000009853BC: D72C001A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v26, vcc_lo              // 0000009853C0: 020234FF 83DCD12D
	v_sad_u8 v24, v24, 0, 0x6400                               // 0000009853C8: D6220018 03FD0118 00006400
	v_sad_u8 v25, v25, 0, 0x6400                               // 0000009853D4: D6220019 03FD0119 00006400
	v_lshl_or_b32 v20, v22, 16, v20                            // 0000009853E0: D6560014 04512116
	v_sad_u8 v22, v23, 0, 0x6400                               // 0000009853E8: D6220016 03FD0117 00006400
	v_lshlrev_b32_e32 v18, 16, v18                             // 0000009853F4: 30242490
	v_and_b32_e32 v24, 0xffff, v24                             // 0000009853F8: 363030FF 0000FFFF
	.long 0xd72c0013                                           // 000000985400: D72C0013
	v_cndmask_b32_e32 v1, 0x83dcd12d, v19, vcc_lo              // 000000985404: 020226FF 83DCD12D
	v_sad_u8 v23, v26, 0, 0x6400                               // 00000098540C: D6220017 03FD011A 00006400
	v_pk_fma_f16 v20, v20, s4, 0xc931 op_sel_hi:[1,0,0]        // 000000985418: CC0E0014 0BFC0914 0000C931
	v_and_or_b32 v18, 0xffff, v22, v18                         // 000000985424: D6570012 044A2CFF 0000FFFF
	v_lshl_or_b32 v22, v25, 16, v24                            // 000000985430: D6560016 04612119
	v_bfe_u32 v24, v12, 6, 16                                  // 000000985438: D6100018 02410D0C
	v_lshlrev_b32_e32 v23, 16, v23                             // 000000985440: 302E2E90
	v_bfe_u32 v25, v13, 6, 16                                  // 000000985444: D6100019 02410D0D
	v_sad_u8 v19, v19, 0, 0x6400                               // 00000098544C: D6220013 03FD0113 00006400
	v_dot2acc_f32_f16 v44, v20, v1                             // 000000985458: 04580314
	.long 0xd72c0018                                           // 00000098545C: D72C0018
	v_cndmask_b32_e32 v1, 0x83dcd12d, v24, vcc_lo              // 000000985460: 020230FF 83DCD12D
	v_pk_fma_f16 v14, v18, s4, 0xc931 op_sel_hi:[1,0,0]        // 000000985468: CC0E000E 0BFC0912 0000C931
	.long 0xd72c0014                                           // 000000985474: D72C0014
	v_cndmask_b32_e32 v1, 0x83dcd12d, v25, vcc_lo              // 000000985478: 020232FF 83DCD12D
	v_and_or_b32 v19, 0xffff, v19, v23                         // 000000985480: D6570013 045E26FF 0000FFFF
	v_bfe_u32 v23, v13, 9, 16                                  // 00000098548C: D6100017 0241130D
	v_bfe_u32 v25, v13, 3, 16                                  // 000000985494: D6100019 0241070D
	v_and_b32_e32 v13, 0xffff, v13                             // 00000098549C: 361A1AFF 0000FFFF
	v_pk_fma_f16 v18, v22, s4, 0xc931 op_sel_hi:[1,0,0]        // 0000009854A4: CC0E0012 0BFC0916 0000C931
	v_sad_u8 v24, v24, 0, 0x6400                               // 0000009854B0: D6220018 03FD0118 00006400
	.long 0xd72c0017                                           // 0000009854BC: D72C0017
	v_cndmask_b32_e32 v1, 0x83dcd12d, v23, vcc_lo              // 0000009854C0: 02022EFF 83DCD12D
	v_sad_u8 v20, v20, 0, 0x6400                               // 0000009854C8: D6220014 03FD0114 00006400
	.long 0xd72c0009                                           // 0000009854D4: D72C0009
	v_cndmask_b32_e32 v1, 0x83dcd12d, v13, vcc_lo              // 0000009854D8: 02021AFF 83DCD12D
	v_dot2acc_f32_f16 v44, v14, v2                             // 0000009854E0: 0458050E
	v_lshl_or_b32 v15, v24, 16, v15                            // 0000009854E4: D656000F 043D2118
	v_bfe_u32 v24, v6, 6, 16                                   // 0000009854EC: D6100018 02410D06
	v_dot2acc_f32_f16 v46, v31, v3                             // 0000009854F4: 045C071F
	v_pk_fma_f16 v19, v19, s4, 0xc931 op_sel_hi:[1,0,0]        // 0000009854F8: CC0E0013 0BFC0913 0000C931
	v_sad_u8 v23, v23, 0, 0x6400                               // 000000985504: D6220017 03FD0117 00006400
	v_pk_fma_f16 v13, v15, s4, 0xc931 op_sel_hi:[1,0,0]        // 000000985510: CC0E000D 0BFC090F 0000C931
	v_bfe_u32 v15, v8, 9, 16                                   // 00000098551C: D610000F 02411308
	v_sad_u8 v7, v9, 0, 0x6400                                 // 000000985524: D6220007 03FD0109 00006400
	.long 0xd72c0018                                           // 000000985530: D72C0018
	v_cndmask_b32_e32 v1, 0x83dcd12d, v24, vcc_lo              // 000000985534: 020230FF 83DCD12D
	v_and_b32_e32 v23, 0xffff, v23                             // 00000098553C: 362E2EFF 0000FFFF
	v_dot2acc_f32_f16 v43, v13, v1                             // 000000985544: 0456030D
	.long 0xd72c0009                                           // 000000985548: D72C0009
	v_cndmask_b32_e32 v1, 0x83dcd12d, v15, vcc_lo              // 00000098554C: 02021EFF 83DCD12D
	v_bfe_u32 v15, v8, 6, 16                                   // 000000985554: D610000F 02410D08
	v_lshlrev_b32_e32 v7, 16, v7                               // 00000098555C: 300E0E90
	v_lshl_or_b32 v20, v20, 16, v23                            // 000000985560: D6560014 045D2114
	v_bfe_u32 v23, v6, 9, 16                                   // 000000985568: D6100017 02411306
	v_dot2acc_f32_f16 v44, v18, v3                             // 000000985570: 04580712
	.long 0xd72c000f                                           // 000000985574: D72C000F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v15, vcc_lo              // 000000985578: 02021EFF 83DCD12D
	v_dot2acc_f32_f16 v46, v27, v4                             // 000000985580: 045C091B
	v_sad_u8 v9, v9, 0, 0x6400                                 // 000000985584: D6220009 03FD0109 00006400
	v_pk_fma_f16 v14, v20, s4, 0xc931 op_sel_hi:[1,0,0]        // 000000985590: CC0E000E 0BFC0914 0000C931
	.long 0xd72c0017                                           // 00000098559C: D72C0017
	v_cndmask_b32_e32 v1, 0x83dcd12d, v23, vcc_lo              // 0000009855A0: 02022EFF 83DCD12D
	v_dot2acc_f32_f16 v44, v19, v4                             // 0000009855A8: 04580913
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000009855AC: BF870254
	v_dual_mov_b32 v18, v65 :: v_dual_and_b32 v9, 0xffff, v9   // 0000009855B0: CA240141 120812FF 0000FFFF
	v_sad_u8 v15, v15, 0, 0x6400                               // 0000009855BC: D622000F 03FD010F 00006400
	v_mov_b32_e32 v19, v57                                     // 0000009855C8: 7E260339
	v_dual_mov_b32 v29, v76 :: v_dual_mov_b32 v26, v69         // 0000009855CC: CA10014C 1D1A0145
	v_sad_u8 v23, v23, 0, 0x6400                               // 0000009855D4: D6220017 03FD0117 00006400
	v_lshl_or_b32 v9, v15, 16, v9                              // 0000009855E0: D6560009 0425210F
	v_mov_b32_e32 v27, v59                                     // 0000009855E8: 7E36033B
	v_mov_b32_e32 v33, v79                                     // 0000009855EC: 7E42034F
	v_mov_b32_e32 v31, v60                                     // 0000009855F0: 7E3E033C
	v_dot2acc_f32_f16 v45, v21, v4                             // 0000009855F4: 045A0915
	v_pk_fma_f16 v9, v9, s4, 0xc931 op_sel_hi:[1,0,0]          // 0000009855F8: CC0E0009 0BFC0909 0000C931
	v_mov_b32_e32 v21, v70                                     // 000000985604: 7E2A0346
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000985608: BF8701B2
	v_dual_dot2acc_f32_f16 v5, v9, v1 :: v_dual_and_b32 v22, 0xffff, v12// 00000098560C: CB240309 051618FF 0000FFFF
	v_bfe_u32 v12, v12, 3, 16                                  // 000000985618: D610000C 0241070C
	v_mov_b32_e32 v9, v55                                      // 000000985620: 7E120337
	.long 0xd72c0016                                           // 000000985624: D72C0016
	v_cndmask_b32_e32 v1, 0x83dcd12d, v22, vcc_lo              // 000000985628: 02022CFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000985630: BF870113
	.long 0xd72c000c                                           // 000000985634: D72C000C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v12, vcc_lo              // 000000985638: 020218FF 83DCD12D
	v_sad_u8 v22, v22, 0, 0x6400                               // 000000985640: D6220016 03FD0116 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000098564C: BF870112
	v_sad_u8 v12, v12, 0, 0x6400                               // 000000985650: D622000C 03FD010C 00006400
	v_lshlrev_b32_e32 v22, 16, v22                             // 00000098565C: 302C2C90
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000985660: BF870241
	v_and_or_b32 v12, 0xffff, v12, v22                         // 000000985664: D657000C 045A18FF 0000FFFF
	.long 0xd72c0016                                           // 000000985670: D72C0016
	v_cndmask_b32_e32 v1, 0x83dcd12d, v25, vcc_lo              // 000000985674: 020232FF 83DCD12D
	v_bfe_u32 v25, v6, 3, 16                                   // 00000098567C: D6100019 02410706
	v_and_b32_e32 v6, 0xffff, v6                               // 000000985684: 360C0CFF 0000FFFF
	v_pk_fma_f16 v12, v12, s4, 0xc931 op_sel_hi:[1,0,0]        // 00000098568C: CC0E000C 0BFC090C 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000985698: BF870193
	.long 0xd72c000f                                           // 00000098569C: D72C000F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v25, vcc_lo              // 0000009856A0: 020232FF 83DCD12D
	.long 0xd72c0006                                           // 0000009856A8: D72C0006
	v_cndmask_b32_e32 v1, 0x83dcd12d, v6, vcc_lo               // 0000009856AC: 02020CFF 83DCD12D
	v_sad_u8 v20, v22, 0, 0x6400                               // 0000009856B4: D6220014 03FD0116 00006400
	v_and_b32_e32 v22, 0xffff, v8                              // 0000009856C0: 362C10FF 0000FFFF
	v_bfe_u32 v8, v8, 3, 16                                    // 0000009856C8: D6100008 02410708
	v_dot2acc_f32_f16 v43, v12, v2                             // 0000009856D0: 0456050C
	v_mov_b32_e32 v12, v64                                     // 0000009856D4: 7E180340
	v_and_or_b32 v1, 0xffff, v20, v7                           // 0000009856D8: D6570001 041E28FF 0000FFFF
	.long 0xd72c0016                                           // 0000009856E4: D72C0016
	v_cndmask_b32_e32 v1, 0x83dcd12d, v22, vcc_lo              // 0000009856E8: 02022CFF 83DCD12D
	.long 0xd72c0008                                           // 0000009856F0: D72C0008
	v_cndmask_b32_e32 v1, 0x83dcd12d, v8, vcc_lo               // 0000009856F4: 020210FF 83DCD12D
	v_sad_u8 v6, v6, 0, 0x6400                                 // 0000009856FC: D6220006 03FD0106 00006400
	v_dot2acc_f32_f16 v43, v14, v3                             // 000000985708: 0456070E
	v_pk_fma_f16 v1, v1, s4, 0xc931 op_sel_hi:[1,0,0]          // 00000098570C: CC0E0001 0BFC0901 0000C931
	v_sad_u8 v15, v15, 0, 0x6400                               // 000000985718: D622000F 03FD010F 00006400
	v_mov_b32_e32 v14, v74                                     // 000000985724: 7E1C034A
	v_lshlrev_b32_e32 v6, 16, v6                               // 000000985728: 300C0C90
	v_sad_u8 v22, v22, 0, 0x6400                               // 00000098572C: D6220016 03FD0116 00006400
	v_sad_u8 v8, v8, 0, 0x6400                                 // 000000985738: D6220008 03FD0108 00006400
	v_dot2acc_f32_f16 v43, v1, v4                              // 000000985744: 04560901
	v_mov_b32_e32 v20, v77                                     // 000000985748: 7E28034D
	v_and_or_b32 v6, 0xffff, v15, v6                           // 00000098574C: D6570006 041A1EFF 0000FFFF
	v_dual_mov_b32 v15, v68 :: v_dual_lshlrev_b32 v22, 16, v22 // 000000985758: CA220144 0F162C90
	v_mov_b32_e32 v25, v73                                     // 000000985760: 7E320349
	v_mov_b32_e32 v1, v75                                      // 000000985764: 7E02034B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000985768: BF870093
	v_and_or_b32 v8, 0xffff, v8, v22                           // 00000098576C: D6570008 045A10FF 0000FFFF
	v_pk_fma_f16 v8, v8, s4, 0xc931 op_sel_hi:[1,0,0]          // 000000985778: CC0E0008 0BFC0908 0000C931
	s_delay_alu instid0(VALU_DEP_1)                            // 000000985784: BF870001
	v_dot2acc_f32_f16 v5, v8, v2                               // 000000985788: 040A0508
	v_pk_fma_f16 v2, v6, s4, 0xc931 op_sel_hi:[1,0,0]          // 00000098578C: CC0E0002 0BFC0906 0000C931
	v_and_b32_e32 v22, 0xffff, v23                             // 000000985798: 362C2EFF 0000FFFF
	v_sad_u8 v23, v24, 0, 0x6400                               // 0000009857A0: D6220017 03FD0118 00006400
	v_mov_b32_e32 v6, v71                                      // 0000009857AC: 7E0C0347
	v_mov_b32_e32 v8, v63                                      // 0000009857B0: 7E10033F
	v_mov_b32_e32 v24, v80                                     // 0000009857B4: 7E300350
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000009857B8: BF870124
	v_lshl_or_b32 v13, v23, 16, v22                            // 0000009857BC: D656000D 04592117
	v_dual_mov_b32 v22, v67 :: v_dual_mov_b32 v23, v58         // 0000009857C4: CA100143 1616013A
	v_pk_fma_f16 v7, v13, s4, 0xc931 op_sel_hi:[1,0,0]         // 0000009857CC: CC0E0007 0BFC090D 0000C931
	v_mov_b32_e32 v13, v56                                     // 0000009857D8: 7E1A0338
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000009857DC: BF8701B2
	v_dot2acc_f32_f16 v5, v7, v3                               // 0000009857E0: 040A0707
	v_mov_b32_e32 v7, v66                                      // 0000009857E4: 7E0E0342
	v_mov_b32_e32 v3, v87                                      // 0000009857E8: 7E060357
	v_dual_dot2acc_f32_f16 v5, v2, v4 :: v_dual_mov_b32 v2, v61// 0000009857EC: CB100902 0502013D
	s_and_not1_b32 exec_lo, exec_lo, s0                        // 0000009857F4: 917E007E
	s_cbranch_execz 94                                         // 0000009857F8: BFA5005E <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi3ELi8ELi1ELb0EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x1374>
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000009857FC: BF8700A2
	v_add_nc_u32_e32 v87, 1, v3                                // 000000985800: 4AAE0681
	s_mov_b32 s5, exec_lo                                      // 000000985804: BE85007E
	.long 0xd4c9007e                                           // 000000985808: D4C9007E
	v_cndmask_b32_e32 v1, v87, v42, vcc_lo                     // 00000098580C: 02025557
	s_cbranch_execz 64649                                      // 000000985810: BFA5FC89 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi3ELi8ELi1ELb0EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x438>
	v_mad_u64_u32 v[55:56], null, 0x300, v87, s[2:3]           // 000000985814: D6FE7C37 000AAEFF 00000300
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000985820: BF870091
	.long 0xd7006a3f                                           // 000000985824: D7006A3F
	v_cndmask_b32_e32 v1, v55, v10, vcc_lo                     // 000000985828: 02021537
	v_add_co_ci_u32_e64 v64, null, v56, v11, vcc_lo            // 00000098582C: D5207C40 01AA1738
	.long 0xd7006a46                                           // 000000985834: D7006A46
	v_cndmask_b32_e32 v1, v55, v53, vcc_lo                     // 000000985838: 02026B37
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000098583C: BF8700A1
	v_add_co_ci_u32_e64 v71, null, 0, v56, vcc_lo              // 000000985840: D5207C47 01AA7080
	.long 0xd7006a54                                           // 000000985848: D7006A54
	v_cndmask_b32_e32 v1, v55, v16, vcc_lo                     // 00000098584C: 02022137
	v_add_co_ci_u32_e64 v85, null, v56, v17, vcc_lo            // 000000985850: D5207C55 01AA2338
	.long 0xd7006a58                                           // 000000985858: D7006A58
	v_cndmask_b32_e32 v1, v55, v54, vcc_lo                     // 00000098585C: 02026D37
	s_delay_alu instid0(VALU_DEP_1)                            // 000000985860: BF870001
	v_add_co_ci_u32_e64 v89, null, 0, v56, vcc_lo              // 000000985864: D5207C59 01AA7080
	s_clause 0x1f                                              // 00000098586C: BF85001F
	global_load_b32 v62, v[63:64], off                         // 000000985870: DC520000 3E7C003F
	global_load_b32 v61, v[63:64], off offset:96               // 000000985878: DC520060 3D7C003F
	global_load_b32 v60, v[63:64], off offset:192              // 000000985880: DC5200C0 3C7C003F
	global_load_b32 v59, v[63:64], off offset:288              // 000000985888: DC520120 3B7C003F
	global_load_b32 v58, v[63:64], off offset:384              // 000000985890: DC520180 3A7C003F
	global_load_b32 v57, v[63:64], off offset:480              // 000000985898: DC5201E0 397C003F
	global_load_b32 v56, v[63:64], off offset:576              // 0000009858A0: DC520240 387C003F
	global_load_b32 v55, v[63:64], off offset:672              // 0000009858A8: DC5202A0 377C003F
	global_load_b32 v78, v[70:71], off                         // 0000009858B0: DC520000 4E7C0046
	global_load_b32 v75, v[70:71], off offset:96               // 0000009858B8: DC520060 4B7C0046
	global_load_b32 v72, v[70:71], off offset:192              // 0000009858C0: DC5200C0 487C0046
	global_load_b32 v69, v[70:71], off offset:288              // 0000009858C8: DC520120 457C0046
	global_load_b32 v67, v[70:71], off offset:384              // 0000009858D0: DC520180 437C0046
	global_load_b32 v65, v[70:71], off offset:480              // 0000009858D8: DC5201E0 417C0046
	global_load_b32 v64, v[70:71], off offset:576              // 0000009858E0: DC520240 407C0046
	global_load_b32 v63, v[70:71], off offset:672              // 0000009858E8: DC5202A0 3F7C0046
	global_load_b32 v83, v[84:85], off                         // 0000009858F0: DC520000 537C0054
	global_load_b32 v81, v[84:85], off offset:96               // 0000009858F8: DC520060 517C0054
	global_load_b32 v79, v[84:85], off offset:192              // 000000985900: DC5200C0 4F7C0054
	global_load_b32 v76, v[84:85], off offset:288              // 000000985908: DC520120 4C7C0054
	global_load_b32 v73, v[84:85], off offset:384              // 000000985910: DC520180 497C0054
	global_load_b32 v70, v[84:85], off offset:480              // 000000985918: DC5201E0 467C0054
	global_load_b32 v68, v[84:85], off offset:576              // 000000985920: DC520240 447C0054
	global_load_b32 v66, v[84:85], off offset:672              // 000000985928: DC5202A0 427C0054
	global_load_b32 v86, v[88:89], off                         // 000000985930: DC520000 567C0058
	global_load_b32 v85, v[88:89], off offset:96               // 000000985938: DC520060 557C0058
	global_load_b32 v84, v[88:89], off offset:192              // 000000985940: DC5200C0 547C0058
	global_load_b32 v82, v[88:89], off offset:288              // 000000985948: DC520120 527C0058
	global_load_b32 v80, v[88:89], off offset:384              // 000000985950: DC520180 507C0058
	global_load_b32 v77, v[88:89], off offset:480              // 000000985958: DC5201E0 4D7C0058
	global_load_b32 v74, v[88:89], off offset:576              // 000000985960: DC520240 4A7C0058
	global_load_b32 v71, v[88:89], off offset:672              // 000000985968: DC5202A0 477C0058
	s_branch 64561                                             // 000000985970: BFA0FC31 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi3ELi8ELi1ELb0EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x438>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000985974: 8C7E007E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000985978: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 00000098597C: 8C7E017E
	s_waitcnt vmcnt(22)                                        // 000000985980: BF895BF7
	v_dual_mov_b32 v1, v49 :: v_dual_mov_b32 v2, v48           // 000000985984: CA100131 01020130
	v_dual_mov_b32 v3, v47 :: v_dual_mov_b32 v4, v46           // 00000098598C: CA10012F 0304012E
	s_waitcnt vmcnt(0)                                         // 000000985994: BF8903F7
	v_dual_mov_b32 v6, v45 :: v_dual_mov_b32 v7, v44           // 000000985998: CA10012D 0606012C
	v_dual_mov_b32 v8, v43 :: v_dual_mov_b32 v9, v5            // 0000009859A0: CA10012B 08080105
	s_mov_b32 s0, 0x76543210                                   // 0000009859A8: BE8000FF 76543210
	v_cmp_gt_u32_e32 vcc_lo, 16, v41                           // 0000009859B0: 7C985290
	v_permlanex16_b32 v1, v1, s0, 0xfedcba98                   // 0000009859B4: D65C0001 03FC0101 FEDCBA98
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 0000009859C0: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 0000009859CC: D65C0003 03FC0103 FEDCBA98
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 0000009859D8: D65C0004 03FC0104 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 0000009859E4: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v7, v7, s0, 0xfedcba98                   // 0000009859F0: D65C0007 03FC0107 FEDCBA98
	v_permlanex16_b32 v8, v8, s0, 0xfedcba98                   // 0000009859FC: D65C0008 03FC0108 FEDCBA98
	v_permlanex16_b32 v9, v9, s0, 0xfedcba98                   // 000000985A08: D65C0009 03FC0109 FEDCBA98
	s_barrier                                                  // 000000985A14: BFBD0000
	buffer_gl0_inv                                             // 000000985A18: E0AC0000 00000000
	s_and_saveexec_b32 s0, vcc_lo                              // 000000985A20: BE80206A
	s_cbranch_execz 20                                         // 000000985A24: BFA50014 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi3ELi8ELi1ELb0EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x1478>
	v_dual_add_f32 v5, v5, v9 :: v_dual_add_f32 v2, v48, v2    // 000000985A28: C9081305 05020530
	v_dual_add_f32 v4, v46, v4 :: v_dual_lshlrev_b32 v9, 2, v41// 000000985A30: C922092E 04085282
	v_dual_add_f32 v1, v49, v1 :: v_dual_add_f32 v8, v43, v8   // 000000985A38: C9080331 0108112B
	v_dual_add_f32 v3, v47, v3 :: v_dual_add_f32 v6, v45, v6   // 000000985A40: C908072F 03060D2D
	s_delay_alu instid0(VALU_DEP_3)                            // 000000985A48: BF870003
	v_lshl_or_b32 v9, v40, 9, v9                               // 000000985A4C: D6560009 04251328
	v_add_f32_e32 v7, v44, v7                                  // 000000985A54: 060E0F2C
	ds_store_2addr_b32 v9, v1, v2 offset1:16                   // 000000985A58: D8381000 00020109
	ds_store_2addr_b32 v9, v3, v4 offset0:32 offset1:48        // 000000985A60: D8383020 00040309
	ds_store_2addr_b32 v9, v6, v7 offset0:64 offset1:80        // 000000985A68: D8385040 00070609
	ds_store_2addr_b32 v9, v8, v5 offset0:96 offset1:112       // 000000985A70: D8387060 00050809
	s_or_b32 exec_lo, exec_lo, s0                              // 000000985A78: 8C7E007E
	s_waitcnt lgkmcnt(0)                                       // 000000985A7C: BF89FC07
	s_barrier                                                  // 000000985A80: BFBD0000
	buffer_gl0_inv                                             // 000000985A84: E0AC0000 00000000
	s_mov_b32 s1, exec_lo                                      // 000000985A8C: BE81007E
	v_cmpx_eq_u32_e32 0, v40                                   // 000000985A90: 7D945080
	s_cbranch_execz 510                                        // 000000985A94: BFA501FE <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi3ELi8ELi1ELb0EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x1c90>
	v_and_b32_e32 v1, 15, v0                                   // 000000985A98: 3602008F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000985A9C: BF870001
	v_lshlrev_b32_e32 v16, 2, v1                               // 000000985AA0: 30200282
	ds_load_2addr_b32 v[2:3], v16 offset1:16                   // 000000985AA4: D8DC1000 02000010
	ds_load_2addr_b32 v[4:5], v16 offset0:128 offset1:144      // 000000985AAC: D8DC9080 04000010
	s_waitcnt lgkmcnt(1)                                       // 000000985AB4: BF89FC17
	v_dual_add_f32 v53, 0, v3 :: v_dual_add_f32 v52, 0, v2     // 000000985AB8: C9080680 35340480
	v_add_nc_u32_e32 v48, 0x400, v16                           // 000000985AC0: 4A6020FF 00000400
	v_add_nc_u32_e32 v50, 0x800, v16                           // 000000985AC8: 4A6420FF 00000800
	v_add_nc_u32_e32 v51, 0xc00, v16                           // 000000985AD0: 4A6620FF 00000C00
	s_waitcnt lgkmcnt(0)                                       // 000000985AD8: BF89FC07
	v_add_f32_e32 v53, v53, v5                                 // 000000985ADC: 066A0B35
	ds_load_2addr_b32 v[6:7], v16 offset0:32 offset1:48        // 000000985AE0: D8DC3020 06000010
	ds_load_2addr_b32 v[8:9], v16 offset0:160 offset1:176      // 000000985AE8: D8DCB0A0 08000010
	ds_load_2addr_b32 v[10:11], v16 offset0:64 offset1:80      // 000000985AF0: D8DC5040 0A000010
	ds_load_2addr_b32 v[12:13], v16 offset0:192 offset1:208    // 000000985AF8: D8DCD0C0 0C000010
	ds_load_2addr_b32 v[14:15], v16 offset0:96 offset1:112     // 000000985B00: D8DC7060 0E000010
	ds_load_2addr_b32 v[16:17], v16 offset0:224 offset1:240    // 000000985B08: D8DCF0E0 10000010
	ds_load_2addr_b32 v[18:19], v48 offset1:16                 // 000000985B10: D8DC1000 12000030
	ds_load_2addr_b32 v[20:21], v48 offset0:128 offset1:144    // 000000985B18: D8DC9080 14000030
	ds_load_2addr_b32 v[22:23], v50 offset1:16                 // 000000985B20: D8DC1000 16000032
	ds_load_2addr_b32 v[24:25], v50 offset0:128 offset1:144    // 000000985B28: D8DC9080 18000032
	ds_load_2addr_b32 v[26:27], v51 offset1:16                 // 000000985B30: D8DC1000 1A000033
	ds_load_2addr_b32 v[28:29], v51 offset0:128 offset1:144    // 000000985B38: D8DC9080 1C000033
	ds_load_2addr_b32 v[30:31], v48 offset0:32 offset1:48      // 000000985B40: D8DC3020 1E000030
	ds_load_2addr_b32 v[32:33], v48 offset0:160 offset1:176    // 000000985B48: D8DCB0A0 20000030
	ds_load_2addr_b32 v[34:35], v50 offset0:32 offset1:48      // 000000985B50: D8DC3020 22000032
	ds_load_2addr_b32 v[36:37], v50 offset0:160 offset1:176    // 000000985B58: D8DCB0A0 24000032
	ds_load_2addr_b32 v[38:39], v51 offset0:32 offset1:48      // 000000985B60: D8DC3020 26000033
	ds_load_2addr_b32 v[40:41], v51 offset0:160 offset1:176    // 000000985B68: D8DCB0A0 28000033
	ds_load_2addr_b32 v[42:43], v48 offset0:64 offset1:80      // 000000985B70: D8DC5040 2A000030
	ds_load_2addr_b32 v[44:45], v48 offset0:192 offset1:208    // 000000985B78: D8DCD0C0 2C000030
	ds_load_2addr_b32 v[46:47], v50 offset0:64 offset1:80      // 000000985B80: D8DC5040 2E000032
	s_waitcnt lgkmcnt(20)                                      // 000000985B88: BF89FD47
	v_add_f32_e32 v6, 0, v6                                    // 000000985B8C: 060C0C80
	s_waitcnt lgkmcnt(18)                                      // 000000985B90: BF89FD27
	v_dual_add_f32 v52, v52, v4 :: v_dual_add_f32 v11, 0, v11  // 000000985B94: C9080934 340A1680
	ds_load_2addr_b32 v[2:3], v48 offset0:96 offset1:112       // 000000985B9C: D8DC7060 02000030
	ds_load_2addr_b32 v[48:49], v48 offset0:224 offset1:240    // 000000985BA4: D8DCF0E0 30000030
	v_dual_add_f32 v7, 0, v7 :: v_dual_add_f32 v6, v6, v8      // 000000985BAC: C9080E80 07061106
	s_waitcnt lgkmcnt(16)                                      // 000000985BB4: BF89FD07
	v_dual_add_f32 v15, 0, v15 :: v_dual_add_f32 v8, v52, v18  // 000000985BB8: C9081E80 0F082534
	v_add_f32_e32 v10, 0, v10                                  // 000000985BC0: 06141480
	ds_load_2addr_b32 v[4:5], v50 offset0:96 offset1:112       // 000000985BC4: D8DC7060 04000032
	v_add_f32_e32 v18, v53, v19                                // 000000985BCC: 06242735
	v_dual_add_f32 v14, 0, v14 :: v_dual_add_f32 v7, v7, v9    // 000000985BD0: C9081C80 0E061307
	s_waitcnt lgkmcnt(11)                                      // 000000985BD8: BF89FCB7
	v_add_f32_e32 v6, v6, v30                                  // 000000985BDC: 060C3D06
	v_add_f32_e32 v9, v10, v12                                 // 000000985BE0: 0612190A
	v_add_f32_e32 v8, v8, v20                                  // 000000985BE4: 06102908
	v_add_f32_e32 v12, v11, v13                                // 000000985BE8: 06181B0B
	v_dual_add_f32 v18, v18, v21 :: v_dual_add_f32 v7, v7, v31 // 000000985BEC: C9082B12 12063F07
	s_waitcnt lgkmcnt(5)                                       // 000000985BF4: BF89FC57
	v_add_f32_e32 v9, v9, v42                                  // 000000985BF8: 06125509
	v_dual_add_f32 v8, v8, v22 :: v_dual_add_f32 v13, v14, v16 // 000000985BFC: C9082D08 080C210E
	v_dual_add_f32 v14, v15, v17 :: v_dual_add_f32 v15, v12, v43// 000000985C04: C908230F 0E0E570C
	v_add_f32_e32 v6, v6, v32                                  // 000000985C0C: 060C4106
	s_delay_alu instid0(VALU_DEP_3)                            // 000000985C10: BF870003
	v_add_f32_e32 v8, v8, v24                                  // 000000985C14: 06103108
	s_waitcnt lgkmcnt(4)                                       // 000000985C18: BF89FC47
	v_add_f32_e32 v19, v9, v44                                 // 000000985C1C: 06265909
	s_waitcnt lgkmcnt(2)                                       // 000000985C20: BF89FC27
	v_add_f32_e32 v17, v14, v3                                 // 000000985C24: 0622070E
	v_dual_add_f32 v18, v18, v23 :: v_dual_add_f32 v23, v15, v45// 000000985C28: C9082F12 12165B0F
	v_add_f32_e32 v6, v6, v34                                  // 000000985C30: 060C4506
	v_add_f32_e32 v16, v13, v2                                 // 000000985C34: 0620050D
	s_waitcnt lgkmcnt(1)                                       // 000000985C38: BF89FC17
	v_add_f32_e32 v17, v17, v49                                // 000000985C3C: 06226311
	v_dual_add_f32 v10, v18, v25 :: v_dual_add_f32 v19, v19, v46// 000000985C40: C9083312 0A125D13
	v_dual_add_f32 v23, v23, v47 :: v_dual_add_f32 v6, v6, v36 // 000000985C48: C9085F17 17064906
	s_waitcnt lgkmcnt(0)                                       // 000000985C50: BF89FC07
	s_delay_alu instid0(VALU_DEP_3)                            // 000000985C54: BF870003
	v_add_f32_e32 v5, v17, v5                                  // 000000985C58: 060A0B11
	ds_load_2addr_b32 v[2:3], v51 offset0:192 offset1:208      // 000000985C5C: D8DCD0C0 02000033
	ds_load_2addr_b32 v[14:15], v51 offset0:224 offset1:240    // 000000985C64: D8DCF0E0 0E000033
	v_add_f32_e32 v18, v7, v33                                 // 000000985C6C: 06244307
	v_add_f32_e32 v6, v6, v38                                  // 000000985C70: 060C4D06
	ds_load_2addr_b32 v[12:13], v51 offset0:96 offset1:112     // 000000985C74: D8DC7060 0C000033
	v_add_f32_e32 v22, v6, v40                                 // 000000985C7C: 062C5106
	ds_load_2addr_b32 v[6:7], v50 offset0:192 offset1:208      // 000000985C80: D8DCD0C0 06000032
	s_waitcnt lgkmcnt(0)                                       // 000000985C88: BF89FC07
	v_dual_add_f32 v8, v8, v26 :: v_dual_add_f32 v7, v23, v7   // 000000985C8C: C9083508 08060F17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000985C94: BF8700C1
	v_add_f32_e32 v20, v8, v28                                 // 000000985C98: 06283908
	ds_load_2addr_b32 v[8:9], v50 offset0:224 offset1:240      // 000000985C9C: D8DCF0E0 08000032
	s_waitcnt lgkmcnt(0)                                       // 000000985CA4: BF89FC07
	v_dual_add_f32 v10, v10, v27 :: v_dual_add_f32 v5, v5, v9  // 000000985CA8: C908370A 0A041305
	v_add_f32_e32 v21, v10, v29                                // 000000985CB0: 062A3B0A
	ds_load_2addr_b32 v[10:11], v51 offset0:64 offset1:80      // 000000985CB4: D8DC5040 0A000033
	v_add_f32_e32 v5, v5, v13                                  // 000000985CBC: 060A1B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000985CC0: BF8700A1
	v_dual_add_f32 v5, v5, v15 :: v_dual_add_f32 v6, v19, v6   // 000000985CC4: C9081F05 05060D13
	s_waitcnt lgkmcnt(0)                                       // 000000985CCC: BF89FC07
	v_dual_add_f32 v6, v6, v10 :: v_dual_add_f32 v7, v7, v11   // 000000985CD0: C9081506 06061707
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000985CD8: BF8701B1
	v_dual_add_f32 v2, v6, v2 :: v_dual_add_f32 v3, v7, v3     // 000000985CDC: C9080506 02020707
	v_sub_f32_e32 v7, v20, v21                                 // 000000985CE4: 080E2B14
	v_add_f32_e32 v6, v20, v21                                 // 000000985CE8: 060C2B14
	v_add_f32_e32 v10, v2, v3                                  // 000000985CEC: 06140702
	v_sub_f32_e32 v2, v2, v3                                   // 000000985CF0: 08040702
	v_add_f32_e32 v16, v16, v48                                // 000000985CF4: 06206110
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000985CF8: BF870091
	v_add_f32_e32 v4, v16, v4                                  // 000000985CFC: 06080910
	v_add_f32_e32 v4, v4, v8                                   // 000000985D00: 06081104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000985D04: BF870091
	v_add_f32_e32 v4, v4, v12                                  // 000000985D08: 06081904
	v_add_f32_e32 v4, v4, v14                                  // 000000985D0C: 06081D04
	v_add_f32_e32 v18, v18, v35                                // 000000985D10: 06244712
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000985D14: BF870112
	v_dual_add_f32 v11, v4, v5 :: v_dual_and_b32 v14, 1, v0    // 000000985D18: C9240B04 0B0E0081
	v_add_f32_e32 v16, v18, v37                                // 000000985D20: 06204B12
	v_sub_f32_e32 v3, v4, v5                                   // 000000985D24: 08060B04
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000985D28: BF870213
	.long 0xd44a0000                                           // 000000985D2C: D44A0000
	v_cndmask_b32_e32 v1, 0, v14, vcc_lo                       // 000000985D30: 02021C80
	v_add_f32_e32 v5, v10, v11                                 // 000000985D34: 060A170A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000985D38: BF870214
	v_add_f32_e32 v8, v16, v39                                 // 000000985D3C: 06104F10
	v_add_f32_e32 v13, v2, v3                                  // 000000985D40: 061A0702
	v_dual_sub_f32 v2, v2, v3 :: v_dual_and_b32 v3, 2, v0      // 000000985D44: C9640702 02020082
	v_sub_f32_e32 v10, v10, v11                                // 000000985D4C: 0814170A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000985D50: BF870194
	v_add_f32_e32 v8, v8, v41                                  // 000000985D54: 06105308
	.long 0xd44a0001                                           // 000000985D58: D44A0001
	v_cndmask_b32_e32 v1, 0, v3, vcc_lo                        // 000000985D5C: 02020680
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000985D60: BF870122
	v_add_f32_e32 v9, v22, v8                                  // 000000985D64: 06121116
	v_sub_f32_e32 v8, v22, v8                                  // 000000985D68: 08101116
	v_add_f32_e32 v4, v6, v9                                   // 000000985D6C: 06081306
	v_sub_f32_e32 v6, v6, v9                                   // 000000985D70: 080C1306
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000985D74: BF8701A2
	v_dual_add_f32 v12, v7, v8 :: v_dual_add_f32 v9, v4, v5    // 000000985D78: C9081107 0C080B04
	v_sub_f32_e32 v5, v4, v5                                   // 000000985D80: 080A0B04
	v_add_f32_e32 v3, v6, v10                                  // 000000985D84: 06061506
	v_sub_f32_e32 v10, v6, v10                                 // 000000985D88: 08141506
	v_and_b32_e32 v6, 4, v0                                    // 000000985D8C: 360C0084
	v_mov_b32_dpp v11, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000985D90: 7E1602FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 000000985D98: D5010009 20021309
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000985DA0: BF870113
	.long 0xd44a0002                                           // 000000985DA4: D44A0002
	v_cndmask_b32_e32 v1, 0, v6, vcc_lo                        // 000000985DA8: 02020C80
	v_dual_add_f32 v4, v9, v11 :: v_dual_sub_f32 v9, v12, v13  // 000000985DAC: C90A1709 04081B0C
	v_dual_sub_f32 v7, v7, v8 :: v_dual_add_f32 v8, v12, v13   // 000000985DB4: C9481107 07081B0C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000985DBC: BF8701A2
	v_mov_b32_dpp v11, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000985DC0: 7E1602FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000985DC8: D5010004 20060904
	v_add_f32_e32 v13, v7, v2                                  // 000000985DD0: 061A0507
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000985DD4: BF870224
	v_mov_b32_dpp v14, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000985DD8: 7E1C02FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, s0                          // 000000985DE0: D5010008 20021108
	v_dual_sub_f32 v7, v7, v2 :: v_dual_add_f32 v4, v4, v11    // 000000985DE8: C9480507 07041704
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000985DF0: BF870194
	v_mov_b32_dpp v11, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000985DF4: 7E1602FA FF01610D
	v_add_f32_e32 v8, v8, v14                                  // 000000985DFC: 06101D08
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000985E00: BF8701A3
	v_mov_b32_dpp v6, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000985E04: 7E0C02FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s2                          // 000000985E0C: D5010004 200A0904
	v_mov_b32_dpp v12, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000985E14: 7E1802FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s1                          // 000000985E1C: D5010008 20061108
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000985E24: BF8701C1
	v_add_f32_e32 v8, v8, v12                                  // 000000985E28: 06101908
	v_cndmask_b32_e64 v12, -v13, v13, s0                       // 000000985E2C: D501000C 20021B0D
	v_mov_b32_dpp v13, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000985E34: 7E1A02FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 000000985E3C: D5010003 20020703
	v_add_f32_e32 v11, v12, v11                                // 000000985E44: 0616170C
	v_mov_b32_dpp v12, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000985E48: 7E1802FA FF016408
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000985E50: BF870223
	v_add_f32_e32 v3, v3, v13                                  // 000000985E54: 06061B03
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 000000985E58: D5010008 200A1108
	v_mov_b32_dpp v13, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000985E60: 7E1A02FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 000000985E68: D501000B 2006170B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000985E70: BF870254
	v_mov_b32_dpp v14, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000985E74: 7E1C02FA FF016203
	v_cndmask_b32_e64 v15, -v3, v3, s1                         // 000000985E7C: D501000F 20060703
	v_add_f32_e32 v3, v4, v6                                   // 000000985E84: 06060D04
	v_add_f32_e32 v6, v8, v12                                  // 000000985E88: 060C1908
	v_add_f32_e32 v8, v11, v13                                 // 000000985E8C: 06101B0B
	v_add_f32_e32 v11, v15, v14                                // 000000985E90: 06161D0F
	v_mov_b32_dpp v14, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000985E94: 7E1C02FA FF016105
	v_cndmask_b32_e64 v15, -v5, v5, s0                         // 000000985E9C: D501000F 20020B05
	s_delay_alu instid0(VALU_DEP_4)                            // 000000985EA4: BF870004
	v_mov_b32_dpp v12, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000985EA8: 7E1802FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 000000985EB0: D5010008 200A1108
	v_mov_b32_dpp v13, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000985EB8: 7E1A02FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s2                       // 000000985EC0: D501000B 200A170B
	v_mov_b32_dpp v2, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000985EC8: 7E0402FA FF016803
	v_mov_b32_dpp v4, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000985ED0: 7E0802FA FF016806
	v_add_f32_e32 v5, v8, v12                                  // 000000985ED8: 060A1908
	v_mov_b32_dpp v8, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000985EDC: 7E1002FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 000000985EE4: D5010009 20021309
	v_add_f32_e32 v12, v15, v14                                // 000000985EEC: 06181D0F
	v_mov_b32_dpp v14, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000985EF0: 7E1C02FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, s0                       // 000000985EF8: D501000A 2002150A
	v_mov_b32_dpp v15, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000985F00: 7E1E02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s0                          // 000000985F08: D5010007 20020F07
	v_add_f32_e32 v8, v9, v8                                   // 000000985F10: 06101109
	v_mov_b32_dpp v9, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000985F14: 7E1202FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 000000985F1C: D501000C 2006190C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000985F24: BF870214
	v_dual_add_f32 v10, v10, v14 :: v_dual_add_f32 v7, v7, v15 // 000000985F28: C9081D0A 0A061F07
	v_mov_b32_dpp v14, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000985F30: 7E1C02FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s1                          // 000000985F38: D5010008 20061108
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000985F40: BF870214
	v_add_f32_e32 v9, v12, v9                                  // 000000985F44: 0612130C
	v_mov_b32_dpp v12, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000985F48: 7E1802FA FF01620A
	v_mov_b32_dpp v15, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000985F50: 7E1E02FA FF016207
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 000000985F58: D501000A 2006150A
	v_cndmask_b32_e64 v16, -v7, v7, s1                         // 000000985F60: D5010010 20060F07
	v_dual_add_f32 v8, v8, v14 :: v_dual_add_f32 v7, v11, v13  // 000000985F68: C9081D08 08061B0B
	v_mov_b32_dpp v11, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000985F70: 7E1602FA FF016409
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000985F78: BF870214
	v_add_f32_e32 v10, v10, v12                                // 000000985F7C: 0614190A
	v_add_f32_e32 v12, v16, v15                                // 000000985F80: 06181F10
	s_delay_alu instid0(VALU_DEP_4)                            // 000000985F84: BF870004
	v_mov_b32_dpp v13, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000985F88: 7E1A02FA FF016408
	v_cndmask_b32_e64 v15, -v8, v8, s2                         // 000000985F90: D501000F 200A1108
	v_cndmask_b32_e64 v9, -v9, v9, s2                          // 000000985F98: D5010009 200A1309
	v_mov_b32_dpp v17, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000985FA0: 7E2202FA FF01640A
	v_mov_b32_dpp v18, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000985FA8: 7E2402FA FF01640C
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 000000985FB0: D501000A 200A150A
	v_cndmask_b32_e64 v12, -v12, v12, s2                       // 000000985FB8: D501000C 200A190C
	v_add_f32_e32 v14, v9, v11                                 // 000000985FC0: 061C1709
	v_add_f32_e32 v16, v15, v13                                // 000000985FC4: 06201B0F
	v_mov_b32_dpp v8, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000985FC8: 7E1002FA FF016807
	v_add_f32_e32 v15, v10, v17                                // 000000985FD0: 061E230A
	v_add_f32_e32 v17, v12, v18                                // 000000985FD4: 0622250C
	v_mov_b32_dpp v9, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000985FD8: 7E1202FA FF016805
	v_mov_b32_dpp v10, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000985FE0: 7E1402FA FF01680E
	v_mov_b32_dpp v11, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000985FE8: 7E1602FA FF016810
	v_mov_b32_dpp v12, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000985FF0: 7E1802FA FF01680F
	v_mov_b32_dpp v13, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000985FF8: 7E1A02FA FF016811
	s_and_b32 exec_lo, exec_lo, vcc_lo                         // 000000986000: 8B7E6A7E
	s_cbranch_execz 162                                        // 000000986004: BFA500A2 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi3ELi8ELi1ELb0EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x1c90>
	v_and_b32_e32 v0, 8, v0                                    // 000000986008: 36000088
	s_mul_i32 s0, s13, 0x1400                                  // 00000098600C: 9600FF0D 00001400
	s_mul_hi_i32 s1, s13, 0x1400                               // 000000986014: 9701FF0D 00001400
	s_add_u32 s2, s10, s0                                      // 00000098601C: 8002000A
	s_addc_u32 s3, s11, s1                                     // 000000986020: 8203010B
	v_cmp_eq_u32_e32 vcc_lo, 0, v0                             // 000000986024: 7C940080
	s_lshl_b32 s0, s6, 7                                       // 000000986028: 84008706
	.long 0x7f243880                                           // 00000098602C: 7F243880
	s_ashr_i32 s1, s0, 31                                      // 000000986030: 86019F00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000986034: BF870009
	s_lshl_b64 s[0:1], s[0:1], 1                               // 000000986038: 84808100
	v_cndmask_b32_e64 v0, -v6, v6, vcc_lo                      // 00000098603C: D5010000 21AA0D06
	v_lshlrev_b32_e32 v1, 1, v1                                // 000000986044: 30020281
	s_add_u32 s2, s2, s0                                       // 000000986048: 80020002
	s_addc_u32 s3, s3, s1                                      // 00000098604C: 82030103
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000986050: D5010003 21AA0703
	v_add_f32_e32 v0, v0, v4                                   // 000000986058: 06000900
	s_clause 0x7                                               // 00000098605C: BF850007
	global_load_d16_b16 v18, v1, s[2:3] offset:32              // 000000986060: DC820020 12020001
	global_load_d16_b16 v19, v1, s[2:3]                        // 000000986068: DC820000 13020001
	global_load_d16_b16 v20, v1, s[2:3] offset:64              // 000000986070: DC820040 14020001
	global_load_d16_b16 v21, v1, s[2:3] offset:96              // 000000986078: DC820060 15020001
	global_load_d16_b16 v22, v1, s[2:3] offset:128             // 000000986080: DC820080 16020001
	global_load_d16_b16 v23, v1, s[2:3] offset:160             // 000000986088: DC8200A0 17020001
	global_load_d16_b16 v24, v1, s[2:3] offset:192             // 000000986090: DC8200C0 18020001
	global_load_d16_b16 v25, v1, s[2:3] offset:224             // 000000986098: DC8200E0 19020001
	v_cndmask_b32_e64 v4, -v5, v5, vcc_lo                      // 0000009860A0: D5010004 21AA0B05
	v_cndmask_b32_e64 v5, -v7, v7, vcc_lo                      // 0000009860A8: D5010005 21AA0F07
	v_cndmask_b32_e64 v7, -v16, v16, vcc_lo                    // 0000009860B0: D5010007 21AA2110
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 0000009860B8: D501000E 21AA1D0E
	v_add_f32_e32 v2, v3, v2                                   // 0000009860C0: 06040503
	v_mul_f32_e32 v0, 0x3db504f3, v0                           // 0000009860C4: 100000FF 3DB504F3
	v_dual_add_f32 v3, v5, v8 :: v_dual_add_f32 v4, v4, v9     // 0000009860CC: C9081105 03041304
	v_cndmask_b32_e64 v16, -v17, v17, vcc_lo                   // 0000009860D4: D5010010 21AA2311
	v_cndmask_b32_e64 v15, -v15, v15, vcc_lo                   // 0000009860DC: D501000F 21AA1F0F
	v_add_f32_e32 v5, v14, v10                                 // 0000009860E4: 060A150E
	v_add_f32_e32 v7, v7, v11                                  // 0000009860E8: 060E1707
	v_dual_mul_f32 v3, 0x3db504f3, v3 :: v_dual_mul_f32 v4, 0x3db504f3, v4// 0000009860EC: C8C606FF 030408FF 3DB504F3
	s_waitcnt vmcnt(4)                                         // 0000009860F8: BF8913F7
	.long 0x7f2a3992                                           // 0000009860FC: 7F2A3992
	v_dual_add_f32 v8, v15, v12 :: v_dual_add_f32 v9, v16, v13 // 000000986100: C908190F 08081B10
	v_dual_mul_f32 v2, 0x3db504f3, v2 :: v_dual_mul_f32 v7, 0x3db504f3, v7// 000000986108: C8C604FF 02060EFF 3DB504F3
	v_mul_f32_e32 v5, 0x3db504f3, v5                           // 000000986114: 100A0AFF 3DB504F3
	.long 0x7f263992                                           // 00000098611C: 7F263992
	s_delay_alu instid0(VALU_DEP_4)                            // 000000986120: BF870004
	v_dual_mul_f32 v9, 0x3db504f3, v9 :: v_dual_mul_f32 v8, 0x3db504f3, v8// 000000986124: C8C612FF 090810FF 3DB504F3
	.long 0x7f283992                                           // 000000986130: 7F283992
	.long 0x7f0c3992                                           // 000000986134: 7F0C3992
	s_mul_i32 s3, s12, 0x1400                                  // 000000986138: 9603FF0C 00001400
	s_mul_hi_i32 s2, s12, 0x1400                               // 000000986140: 9702FF0C 00001400
	s_add_u32 s3, s8, s3                                       // 000000986148: 80030308
	s_addc_u32 s2, s9, s2                                      // 00000098614C: 82020209
	s_add_u32 s0, s3, s0                                       // 000000986150: 80000003
	s_addc_u32 s1, s2, s1                                      // 000000986154: 82010102
	v_fma_mix_f32 v0, v18, v0, neg(0) op_sel_hi:[1,0,0]        // 000000986158: CC200000 8A020112
	v_fma_mix_f32 v2, v19, v2, neg(0) op_sel_hi:[1,0,0]        // 000000986160: CC200002 8A020513
	v_fma_mix_f32 v3, v20, v3, neg(0) op_sel_hi:[1,0,0]        // 000000986168: CC200003 8A020714
	v_fma_mix_f32 v4, v21, v4, neg(0) op_sel_hi:[1,0,0]        // 000000986170: CC200004 8A020915
	s_waitcnt vmcnt(3)                                         // 000000986178: BF890FF7
	v_fma_mix_f32 v5, v22, v5, neg(0) op_sel_hi:[1,0,0]        // 00000098617C: CC200005 8A020B16
	.long 0x7e243980                                           // 000000986184: 7E243980
	s_waitcnt vmcnt(2)                                         // 000000986188: BF890BF7
	v_fma_mix_f32 v7, v23, v7, neg(0) op_sel_hi:[1,0,0]        // 00000098618C: CC200007 8A020F17
	s_waitcnt vmcnt(1)                                         // 000000986194: BF8907F7
	v_fma_mix_f32 v8, v24, v8, neg(0) op_sel_hi:[1,0,0]        // 000000986198: CC200008 8A021118
	s_waitcnt vmcnt(0)                                         // 0000009861A0: BF8903F7
	v_fma_mix_f32 v9, v25, v9, neg(0) op_sel_hi:[1,0,0]        // 0000009861A4: CC200009 8A021319
	.long 0x7e0c3982                                           // 0000009861AC: 7E0C3982
	v_and_b32_e32 v10, 1, v18                                  // 0000009861B0: 36142481
	.long 0x7e243984                                           // 0000009861B4: 7E243984
	.long 0x7e263983                                           // 0000009861B8: 7E263983
	.long 0x7e283985                                           // 0000009861BC: 7E283985
	.long 0x7e2a3988                                           // 0000009861C0: 7E2A3988
	v_and_b32_e32 v6, 1, v6                                    // 0000009861C4: 360C0C81
	v_and_b32_e32 v11, 1, v18                                  // 0000009861C8: 36162481
	.long 0x7e243987                                           // 0000009861CC: 7E243987
	v_and_b32_e32 v12, 1, v19                                  // 0000009861D0: 36182681
	v_and_b32_e32 v13, 1, v20                                  // 0000009861D4: 361A2881
	v_and_b32_e32 v15, 1, v21                                  // 0000009861D8: 361E2A81
	v_add3_u32 v2, v2, v6, 0x7fff                              // 0000009861DC: D6550002 03FE0D02 00007FFF
	v_and_b32_e32 v14, 1, v18                                  // 0000009861E8: 361C2481
	.long 0x7e243989                                           // 0000009861EC: 7E243989
	v_add3_u32 v0, v0, v10, 0x7fff                             // 0000009861F0: D6550000 03FE1500 00007FFF
	v_add3_u32 v3, v3, v12, 0x7fff                             // 0000009861FC: D6550003 03FE1903 00007FFF
	v_add3_u32 v4, v4, v11, 0x7fff                             // 000000986208: D6550004 03FE1704 00007FFF
	v_add3_u32 v5, v5, v13, 0x7fff                             // 000000986214: D6550005 03FE1B05 00007FFF
	v_and_b32_e32 v6, 1, v18                                   // 000000986220: 360C2481
	v_add3_u32 v8, v8, v15, 0x7fff                             // 000000986224: D6550008 03FE1F08 00007FFF
	v_add3_u32 v7, v7, v14, 0x7fff                             // 000000986230: D6550007 03FE1D07 00007FFF
	s_delay_alu instid0(VALU_DEP_3)                            // 00000098623C: BF870003
	v_add3_u32 v6, v9, v6, 0x7fff                              // 000000986240: D6550006 03FE0D09 00007FFF
	s_clause 0x7                                               // 00000098624C: BF850007
	global_store_d16_hi_b16 v1, v2, s[0:1]                     // 000000986250: DC960000 00000201
	global_store_d16_hi_b16 v1, v0, s[0:1] offset:32           // 000000986258: DC960020 00000001
	global_store_d16_hi_b16 v1, v3, s[0:1] offset:64           // 000000986260: DC960040 00000301
	global_store_d16_hi_b16 v1, v4, s[0:1] offset:96           // 000000986268: DC960060 00000401
	global_store_d16_hi_b16 v1, v5, s[0:1] offset:128          // 000000986270: DC960080 00000501
	global_store_d16_hi_b16 v1, v7, s[0:1] offset:160          // 000000986278: DC9600A0 00000701
	global_store_d16_hi_b16 v1, v8, s[0:1] offset:192          // 000000986280: DC9600C0 00000801
	global_store_d16_hi_b16 v1, v6, s[0:1] offset:224          // 000000986288: DC9600E0 00000601
	s_endpgm                                                   // 000000986290: BFB00000
		...

