0000000000555200 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000555200: F4100100 F8000000
	v_dual_mov_b32 v18, 0 :: v_dual_and_b32 v1, 15, v0         // 000000555208: CA240080 1200008F
	v_lshrrev_b32_e32 v2, 2, v0                                // 000000555210: 32040082
	s_ashr_i32 s3, s2, 31                                      // 000000555214: 86039F02
	v_lshrrev_b32_e32 v14, 6, v0                               // 000000555218: 321C0086
	s_lshl_b64 s[2:3], s[2:3], 2                               // 00000055521C: 84828202
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000555220: BF8701A9
	v_dual_mov_b32 v4, s3 :: v_dual_lshlrev_b32 v1, 2, v1      // 000000555224: CA220003 04000282
	v_and_b32_e32 v2, 60, v2                                   // 00000055522C: 360404BC
	v_or_b32_e32 v3, s2, v14                                   // 000000555230: 38061C02
	v_bfe_u32 v15, v0, 5, 1                                    // 000000555234: D610000F 02050B00
	.long 0x7f0e3880                                           // 00000055523C: 7F0E3880
	v_mov_b32_e32 v17, 0                                       // 000000555240: 7E220280
	s_waitcnt lgkmcnt(0)                                       // 000000555244: BF89FC07
	s_clause 0x1                                               // 000000555248: BF850001
	global_load_b32 v5, v1, s[4:5]                             // 00000055524C: DC520000 05040001
	global_load_b32 v6, v2, s[4:5]                             // 000000555254: DC520000 06040002
	s_add_u32 s0, s4, s14                                      // 00000055525C: 80000E04
	s_addc_u32 s1, s5, s15                                     // 000000555260: 82010F05
	s_lshr_b32 s14, s11, 31                                    // 000000555264: 850E9F0B
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[3:4]                  // 000000555268: 7CA8060C
	s_add_u32 s14, s10, s14                                    // 00000055526C: 800E0E0A
	s_addc_u32 s15, s11, 0                                     // 000000555270: 820F800B
	s_ashr_i32 s20, s11, 31                                    // 000000555274: 86149F0B
	s_ashr_i64 s[14:15], s[14:15], 1                           // 000000555278: 868E810E
	s_lshr_b32 s20, s20, 27                                    // 00000055527C: 85149B14
	v_dual_cndmask_b32 v3, 0, v3 :: v_dual_and_b32 v16, 31, v0 // 000000555280: CA640680 0310009F
	s_add_u32 s20, s10, s20                                    // 000000555288: 8014140A
	s_addc_u32 s21, s11, 0                                     // 00000055528C: 8215800B
	v_cndmask_b32_e64 v4, 0, s3, vcc_lo                        // 000000555290: D5010004 01A80680
	s_lshr_b64 s[20:21], s[20:21], 5                           // 000000555298: 85948514
	.long 0xd72c0008                                           // 00000055529C: D72C0008
	v_cndmask_b32_e32 v1, s19, v3, vcc_lo                      // 0000005552A0: 02020613
	s_add_i32 s21, s20, 1                                      // 0000005552A4: 81158114
	.long 0xd72c000d                                           // 0000005552A8: D72C000D
	v_cndmask_b32_e32 v0, v3, v15, vcc_lo                      // 0000005552AC: 02001F03
	s_lshr_b32 s19, s21, 31                                    // 0000005552B0: 85139F15
	v_mad_u64_u32 v[9:10], null, v3, s14, s[0:1]               // 0000005552B4: D6FE7C09 00001D03
	s_add_i32 s21, s21, s19                                    // 0000005552BC: 81151315
	.long 0xd72c0015                                           // 0000005552C0: D72C0015
	v_cndmask_b32_e32 v0, v4, v14, vcc_lo                      // 0000005552C4: 02001D04
	s_ashr_i32 s15, s21, 1                                     // 0000005552C8: 860F8115
	s_add_u32 s0, s4, s16                                      // 0000005552CC: 80001004
	.long 0xd72c0013                                           // 0000005552D0: D72C0013
	v_cndmask_b32_e32 v1, s15, v15, vcc_lo                     // 0000005552D4: 02021E0F
	s_addc_u32 s1, s5, s17                                     // 0000005552D8: 82011105
	.long 0xd72c0016                                           // 0000005552DC: D72C0016
	v_cndmask_b32_e32 v1, s18, v4, vcc_lo                      // 0000005552E0: 02020812
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v2, 0               // 0000005552E4: CA100080 01020080
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000005552EC: BF870214
	v_add3_u32 v10, v21, v10, v13                              // 0000005552F0: D655000A 04361515
	v_add_nc_u32_e32 v4, s15, v19                              // 0000005552F8: 4A08260F
	v_add_nc_u32_e32 v19, v19, v16                             // 0000005552FC: 4A262113
	s_waitcnt vmcnt(1)                                         // 000000555300: BF8907F7
	v_bfe_u32 v11, v5, 16, 1                                   // 000000555304: D610000B 02052105
	s_waitcnt vmcnt(0)                                         // 00000055530C: BF8903F7
	v_bfe_u32 v20, v6, 16, 1                                   // 000000555310: D6100014 02052106
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000555318: BF8701A2
	v_add3_u32 v5, v5, v11, 0x7fff                             // 00000055531C: D6550005 03FE1705 00007FFF
	v_mad_u64_u32 v[11:12], null, s18, v3, s[0:1]              // 000000555328: D6FE7C0B 00020612
	v_add3_u32 v6, v6, v20, 0x7fff                             // 000000555330: D6550006 03FE2906 00007FFF
	v_mov_b32_e32 v3, 0                                        // 00000055533C: 7E060280
	v_min_i32_e32 v20, s20, v4                                 // 000000555340: 22280814
	.long 0x7e0e3985                                           // 000000555344: 7E0E3985
	v_dual_mov_b32 v4, 0 :: v_dual_lshlrev_b32 v5, 2, v0       // 000000555348: CA220080 04040082
	v_add3_u32 v21, v8, v12, v22                               // 000000555350: D6550015 045A1908
	s_delay_alu instid0(VALU_DEP_3)                            // 000000555358: BF870003
	v_and_or_b32 v6, 0xffff0000, v6, v7                        // 00000055535C: D6570006 041E0CFF FFFF0000
	v_cmp_lt_i32_e32 vcc_lo, v19, v20                          // 000000555368: 7C822913
	ds_store_b32 v5, v6                                        // 00000055536C: D8340000 00000605
	s_waitcnt lgkmcnt(0)                                       // 000000555374: BF89FC07
	s_barrier                                                  // 000000555378: BFBD0000
	buffer_gl0_inv                                             // 00000055537C: E0AC0000 00000000
	s_and_saveexec_b32 s1, vcc_lo                              // 000000555384: BE81206A
	s_cbranch_execz 21                                         // 000000555388: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x1e0>
	v_lshlrev_b32_e32 v1, 1, v19                               // 00000055538C: 30022681
	v_lshlrev_b32_e32 v3, 4, v19                               // 000000555390: 30062684
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000555394: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000555398: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 00000055539C: 3408069F
	.long 0xd7000001                                           // 0000005553A0: D7000001
	v_cndmask_b32_e32 v1, v11, v1, vcc_lo                      // 0000005553A4: 0202030B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005553A8: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v21, v2, s0                  // 0000005553AC: D5207C02 00020515
	.long 0xd7000003                                           // 0000005553B4: D7000003
	v_cndmask_b32_e32 v1, v9, v3, vcc_lo                       // 0000005553B8: 02020709
	v_add_co_ci_u32_e64 v4, null, v10, v4, s0                  // 0000005553BC: D5207C04 0002090A
	s_clause 0x1                                               // 0000005553C4: BF850001
	global_load_d16_b16 v5, v[1:2], off                        // 0000005553C8: DC820000 057C0001
	global_load_b128 v[1:4], v[3:4], off                       // 0000005553D0: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 0000005553D8: BF8907F7
	v_cvt_f32_f16_e32 v18, v5                                  // 0000005553DC: 7E241705
	s_or_b32 exec_lo, exec_lo, s1                              // 0000005553E0: 8C7E017E
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v22, 0             // 0000005553E4: CA100080 17160080
	s_and_saveexec_b32 s1, vcc_lo                              // 0000005553EC: BE81206A
	s_cbranch_execz 314                                        // 0000005553F0: BFA5013A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x6dc>
	v_dual_mov_b32 v22, 0 :: v_dual_add_nc_u32 v5, 32, v19     // 0000005553F4: CA200080 160426A0
	v_dual_mov_b32 v23, 0 :: v_dual_lshlrev_b32 v12, 5, v19    // 0000005553FC: CA220080 170C2685
	s_lshl_b64 s[4:5], s[10:11], 2                             // 000000555404: 8484820A
	s_delay_alu instid0(VALU_DEP_2)                            // 000000555408: BF870002
	v_dual_mov_b32 v17, 0 :: v_dual_lshlrev_b32 v24, 4, v5     // 00000055540C: CA220080 11180A84
	v_dual_mov_b32 v26, v18 :: v_dual_lshlrev_b32 v25, 1, v5   // 000000555414: CA220112 1A180A81
	s_mov_b32 s14, 0                                           // 00000055541C: BE8E0080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 000000555420: 848A810A
	s_branch 269                                               // 000000555424: BFA0010D <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x65c>
	s_or_b32 exec_lo, exec_lo, s15                             // 000000555428: 8C7E0F7E
	v_ashrrev_i32_e32 v13, 31, v12                             // 00000055542C: 341A189F
	v_lshrrev_b32_e32 v75, 6, v1                               // 000000555430: 32960286
	v_lshrrev_b32_e32 v76, 14, v1                              // 000000555434: 3298028E
	v_and_b32_e32 v77, 0xff, v2                                // 000000555438: 369A04FF 000000FF
	v_lshrrev_b32_e32 v78, 6, v2                               // 000000555440: 329C0486
	.long 0xd73c001b                                           // 000000555444: D73C001B
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 000000555448: 02021881
	v_and_b32_e32 v13, 0xff, v1                                // 00000055544C: 361A02FF 000000FF
	v_and_b32_e32 v75, 0x3fc, v75                              // 000000555454: 369696FF 000003FC
	v_and_b32_e32 v76, 0x3fc, v76                              // 00000055545C: 369898FF 000003FC
	v_lshrrev_b32_e32 v1, 22, v1                               // 000000555464: 32020296
	v_lshrrev_b32_e32 v79, 14, v2                              // 000000555468: 329E048E
	.long 0xd700003f                                           // 00000055546C: D700003F
	v_cndmask_b32_e32 v1, s6, v27, vcc_lo                      // 000000555470: 02023606
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000555474: BF8701A1
	v_add_co_ci_u32_e64 v64, null, s7, v28, s0                 // 000000555478: D5207C40 00023807
	v_lshlrev_b32_e32 v13, 2, v13                              // 000000555480: 301A1A82
	.long 0xd7000043                                           // 000000555484: D7000043
	v_cndmask_b32_e32 v0, v63, v10, vcc_lo                     // 000000555488: 0200153F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000055548C: BF8700A1
	v_add_co_ci_u32_e64 v68, null, s11, v64, s0                // 000000555490: D5207C44 0002800B
	.long 0xd7000047                                           // 000000555498: D7000047
	v_cndmask_b32_e32 v0, v63, v4, vcc_lo                      // 00000055549C: 0200093F
	v_add_co_ci_u32_e64 v72, null, s5, v64, s0                 // 0000005554A0: D5207C48 00028005
	s_clause 0xb                                               // 0000005554A8: BF85000B
	global_load_b128 v[27:30], v[63:64], off                   // 0000005554AC: DC5E0000 1B7C003F
	global_load_b128 v[31:34], v[67:68], off                   // 0000005554B4: DC5E0000 1F7C0043
	global_load_b128 v[35:38], v[71:72], off                   // 0000005554BC: DC5E0000 237C0047
	global_load_b128 v[39:42], v[63:64], off offset:16         // 0000005554C4: DC5E0010 277C003F
	global_load_b128 v[43:46], v[67:68], off offset:16         // 0000005554CC: DC5E0010 2B7C0043
	global_load_b128 v[47:50], v[71:72], off offset:16         // 0000005554D4: DC5E0010 2F7C0047
	global_load_b128 v[51:54], v[63:64], off offset:32         // 0000005554DC: DC5E0020 337C003F
	global_load_b128 v[55:58], v[67:68], off offset:32         // 0000005554E4: DC5E0020 377C0043
	global_load_b128 v[59:62], v[71:72], off offset:32         // 0000005554EC: DC5E0020 3B7C0047
	global_load_b128 v[63:66], v[63:64], off offset:48         // 0000005554F4: DC5E0030 3F7C003F
	global_load_b128 v[67:70], v[67:68], off offset:48         // 0000005554FC: DC5E0030 437C0043
	global_load_b128 v[71:74], v[71:72], off offset:48         // 000000555504: DC5E0030 477C0047
	ds_load_b32 v13, v13                                       // 00000055550C: D8D80000 0D00000D
	ds_load_b32 v75, v75                                       // 000000555514: D8D80000 4B00004B
	ds_load_b32 v76, v76                                       // 00000055551C: D8D80000 4C00004C
	v_lshrrev_b32_e32 v2, 22, v2                               // 000000555524: 32040496
	v_and_b32_e32 v1, 0x3fc, v1                                // 000000555528: 360202FF 000003FC
	v_lshlrev_b32_e32 v77, 2, v77                              // 000000555530: 309A9A82
	v_and_b32_e32 v78, 0x3fc, v78                              // 000000555534: 369C9CFF 000003FC
	v_and_b32_e32 v79, 0x3fc, v79                              // 00000055553C: 369E9EFF 000003FC
	v_and_b32_e32 v2, 0x3fc, v2                                // 000000555544: 360404FF 000003FC
	ds_load_b32 v1, v1                                         // 00000055554C: D8D80000 01000001
	ds_load_b32 v77, v77                                       // 000000555554: D8D80000 4D00004D
	ds_load_b32 v78, v78                                       // 00000055555C: D8D80000 4E00004E
	ds_load_b32 v79, v79                                       // 000000555564: D8D80000 4F00004F
	ds_load_b32 v2, v2                                         // 00000055556C: D8D80000 02000002
	v_and_b32_e32 v80, 0xff, v3                                // 000000555574: 36A006FF 000000FF
	v_lshrrev_b32_e32 v81, 6, v3                               // 00000055557C: 32A20686
	v_lshrrev_b32_e32 v82, 14, v3                              // 000000555580: 32A4068E
	v_lshrrev_b32_e32 v3, 22, v3                               // 000000555584: 32060696
	v_and_b32_e32 v83, 0xff, v4                                // 000000555588: 36A608FF 000000FF
	v_lshrrev_b32_e32 v84, 14, v4                              // 000000555590: 32A8088E
	v_add_nc_u32_e32 v24, 0x200, v24                           // 000000555594: 4A3030FF 00000200
	v_add_nc_u32_e32 v25, 64, v25                              // 00000055559C: 4A3232C0
	v_and_b32_e32 v3, 0x3fc, v3                                // 0000005555A0: 360606FF 000003FC
	v_add_nc_u32_e32 v12, 0x400, v12                           // 0000005555A8: 4A1818FF 00000400
	s_and_b32 s0, exec_lo, vcc_lo                              // 0000005555B0: 8B006A7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000005555B4: BF870009
	s_or_b32 s14, s0, s14                                      // 0000005555B8: 8C0E0E00
	s_waitcnt vmcnt(11) lgkmcnt(7)                             // 0000005555BC: BF892C77
	v_dot2_f32_bf16 v27, v27, v13, 0                           // 0000005555C0: CC1A401B 1A021B1B
	s_waitcnt vmcnt(10)                                        // 0000005555C8: BF892BF7
	v_dot2_f32_bf16 v31, v31, v13, 0                           // 0000005555CC: CC1A401F 1A021B1F
	s_waitcnt vmcnt(9)                                         // 0000005555D4: BF8927F7
	v_dot2_f32_bf16 v13, v35, v13, 0                           // 0000005555D8: CC1A400D 1A021B23
	v_lshrrev_b32_e32 v35, 6, v4                               // 0000005555E0: 32460886
	v_lshrrev_b32_e32 v4, 22, v4                               // 0000005555E4: 32080896
	s_waitcnt lgkmcnt(6)                                       // 0000005555E8: BF89FC67
	v_dot2_f32_bf16 v27, v28, v75, v27                         // 0000005555EC: CC1A401B 1C6E971C
	v_dot2_f32_bf16 v28, v32, v75, v31                         // 0000005555F4: CC1A401C 1C7E9720
	v_dot2_f32_bf16 v13, v36, v75, v13                         // 0000005555FC: CC1A400D 1C369724
	v_lshlrev_b32_e32 v31, 2, v80                              // 000000555604: 303EA082
	v_and_b32_e32 v32, 0x3fc, v82                              // 000000555608: 3640A4FF 000003FC
	s_waitcnt lgkmcnt(5)                                       // 000000555610: BF89FC57
	v_dot2_f32_bf16 v27, v29, v76, v27                         // 000000555614: CC1A401B 1C6E991D
	v_dot2_f32_bf16 v28, v33, v76, v28                         // 00000055561C: CC1A401C 1C729921
	v_dot2_f32_bf16 v13, v37, v76, v13                         // 000000555624: CC1A400D 1C369925
	v_and_b32_e32 v29, 0x3fc, v81                              // 00000055562C: 363AA2FF 000003FC
	ds_load_b32 v32, v32                                       // 000000555634: D8D80000 20000020
	s_waitcnt lgkmcnt(5)                                       // 00000055563C: BF89FC57
	v_dot2_f32_bf16 v27, v30, v1, v27                          // 000000555640: CC1A401B 1C6E031E
	v_dot2_f32_bf16 v28, v34, v1, v28                          // 000000555648: CC1A401C 1C720322
	v_dot2_f32_bf16 v1, v38, v1, v13                           // 000000555650: CC1A4001 1C360326
	ds_load_b32 v30, v31                                       // 000000555658: D8D80000 1E00001F
	ds_load_b32 v29, v29                                       // 000000555660: D8D80000 1D00001D
	s_waitcnt vmcnt(8) lgkmcnt(6)                              // 000000555668: BF892067
	v_dot2_f32_bf16 v27, v39, v77, v27                         // 00000055566C: CC1A401B 1C6E9B27
	s_waitcnt vmcnt(7)                                         // 000000555674: BF891FF7
	v_dot2_f32_bf16 v28, v43, v77, v28                         // 000000555678: CC1A401C 1C729B2B
	s_waitcnt vmcnt(6)                                         // 000000555680: BF891BF7
	v_dot2_f32_bf16 v1, v47, v77, v1                           // 000000555684: CC1A4001 1C069B2F
	v_lshlrev_b32_e32 v13, 2, v83                              // 00000055568C: 301AA682
	v_and_b32_e32 v31, 0x3fc, v35                              // 000000555690: 363E46FF 000003FC
	s_waitcnt lgkmcnt(5)                                       // 000000555698: BF89FC57
	v_dot2_f32_bf16 v27, v40, v78, v27                         // 00000055569C: CC1A401B 1C6E9D28
	v_dot2_f32_bf16 v28, v44, v78, v28                         // 0000005556A4: CC1A401C 1C729D2C
	v_dot2_f32_bf16 v1, v48, v78, v1                           // 0000005556AC: CC1A4001 1C069D30
	v_and_b32_e32 v33, 0x3fc, v84                              // 0000005556B4: 3642A8FF 000003FC
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000005556BC: 360808FF 000003FC
	s_waitcnt lgkmcnt(4)                                       // 0000005556C4: BF89FC47
	v_dot2_f32_bf16 v27, v41, v79, v27                         // 0000005556C8: CC1A401B 1C6E9F29
	v_dot2_f32_bf16 v28, v45, v79, v28                         // 0000005556D0: CC1A401C 1C729F2D
	v_dot2_f32_bf16 v1, v49, v79, v1                           // 0000005556D8: CC1A4001 1C069F31
	s_waitcnt lgkmcnt(3)                                       // 0000005556E0: BF89FC37
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000005556E4: BF870193
	v_dot2_f32_bf16 v27, v42, v2, v27                          // 0000005556E8: CC1A401B 1C6E052A
	v_dot2_f32_bf16 v28, v46, v2, v28                          // 0000005556F0: CC1A401C 1C72052E
	s_delay_alu instid0(VALU_DEP_3)                            // 0000005556F8: BF870003
	v_dot2_f32_bf16 v1, v50, v2, v1                            // 0000005556FC: CC1A4001 1C060532
	ds_load_b32 v2, v3                                         // 000000555704: D8D80000 02000003
	ds_load_b32 v3, v13                                        // 00000055570C: D8D80000 0300000D
	ds_load_b32 v13, v31                                       // 000000555714: D8D80000 0D00001F
	ds_load_b32 v31, v33                                       // 00000055571C: D8D80000 1F000021
	ds_load_b32 v33, v4                                        // 000000555724: D8D80000 21000004
	s_waitcnt vmcnt(5) lgkmcnt(6)                              // 00000055572C: BF891467
	v_dot2_f32_bf16 v4, v51, v30, v27                          // 000000555730: CC1A4004 1C6E3D33
	s_waitcnt vmcnt(4)                                         // 000000555738: BF8913F7
	v_dot2_f32_bf16 v27, v55, v30, v28                         // 00000055573C: CC1A401B 1C723D37
	s_waitcnt vmcnt(3)                                         // 000000555744: BF890FF7
	v_dot2_f32_bf16 v1, v59, v30, v1                           // 000000555748: CC1A4001 1C063D3B
	s_waitcnt lgkmcnt(5)                                       // 000000555750: BF89FC57
	v_dot2_f32_bf16 v4, v52, v29, v4                           // 000000555754: CC1A4004 1C123B34
	v_dot2_f32_bf16 v27, v56, v29, v27                         // 00000055575C: CC1A401B 1C6E3B38
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000555764: BF870193
	v_dot2_f32_bf16 v1, v60, v29, v1                           // 000000555768: CC1A4001 1C063B3C
	v_dot2_f32_bf16 v4, v53, v32, v4                           // 000000555770: CC1A4004 1C124135
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000555778: BF870193
	v_dot2_f32_bf16 v27, v57, v32, v27                         // 00000055577C: CC1A401B 1C6E4139
	v_dot2_f32_bf16 v1, v61, v32, v1                           // 000000555784: CC1A4001 1C06413D
	s_waitcnt lgkmcnt(4)                                       // 00000055578C: BF89FC47
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000555790: BF870193
	v_dot2_f32_bf16 v4, v54, v2, v4                            // 000000555794: CC1A4004 1C120536
	v_dot2_f32_bf16 v27, v58, v2, v27                          // 00000055579C: CC1A401B 1C6E053A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000005557A4: BF8701A3
	v_dot2_f32_bf16 v1, v62, v2, v1                            // 0000005557A8: CC1A4001 1C06053E
	s_waitcnt vmcnt(2) lgkmcnt(3)                              // 0000005557B0: BF890837
	v_dot2_f32_bf16 v2, v63, v3, v4                            // 0000005557B4: CC1A4002 1C12073F
	s_waitcnt vmcnt(1)                                         // 0000005557BC: BF8907F7
	v_dot2_f32_bf16 v4, v67, v3, v27                           // 0000005557C0: CC1A4004 1C6E0743
	s_waitcnt vmcnt(0)                                         // 0000005557C8: BF8903F7
	v_dot2_f32_bf16 v1, v71, v3, v1                            // 0000005557CC: CC1A4001 1C060747
	s_waitcnt lgkmcnt(2)                                       // 0000005557D4: BF89FC27
	v_dot2_f32_bf16 v2, v64, v13, v2                           // 0000005557D8: CC1A4002 1C0A1B40
	v_dot2_f32_bf16 v3, v68, v13, v4                           // 0000005557E0: CC1A4003 1C121B44
	s_delay_alu instid0(VALU_DEP_3)                            // 0000005557E8: BF870003
	v_dot2_f32_bf16 v1, v72, v13, v1                           // 0000005557EC: CC1A4001 1C061B48
	v_mov_b32_e32 v4, v8                                       // 0000005557F4: 7E080308
	s_waitcnt lgkmcnt(1)                                       // 0000005557F8: BF89FC17
	v_dot2_f32_bf16 v8, v65, v31, v2                           // 0000005557FC: CC1A4008 1C0A3F41
	v_dot2_f32_bf16 v13, v69, v31, v3                          // 000000555804: CC1A400D 1C0E3F45
	v_dot2_f32_bf16 v1, v73, v31, v1                           // 00000055580C: CC1A4001 1C063F49
	v_dual_mov_b32 v3, v7 :: v_dual_mov_b32 v2, v6             // 000000555814: CA100107 03020106
	s_waitcnt lgkmcnt(0)                                       // 00000055581C: BF89FC07
	v_dot2_f32_bf16 v6, v66, v33, v8                           // 000000555820: CC1A4006 1C224342
	v_dot2_f32_bf16 v7, v70, v33, v13                          // 000000555828: CC1A4007 1C364346
	v_dot2_f32_bf16 v8, v74, v33, v1                           // 000000555830: CC1A4008 1C06434A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000555838: BF870193
	v_dual_mov_b32 v1, v5 :: v_dual_fmac_f32 v22, v18, v6      // 00000055583C: CA000105 01160D12
	v_fmac_f32_e32 v23, v18, v7                                // 000000555844: 562E0F12
	s_delay_alu instid0(VALU_DEP_3)                            // 000000555848: BF870003
	v_fmac_f32_e32 v17, v18, v8                                // 00000055584C: 56221112
	v_mov_b32_e32 v18, v26                                     // 000000555850: 7E24031A
	s_and_not1_b32 exec_lo, exec_lo, s14                       // 000000555854: 917E0E7E
	s_cbranch_execz 31                                         // 000000555858: BFA5001F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x6d8>
	s_waitcnt vmcnt(0)                                         // 00000055585C: BF8903F7
	v_dual_mov_b32 v6, v2 :: v_dual_add_nc_u32 v19, 32, v19    // 000000555860: CA200102 061226A0
	v_dual_mov_b32 v5, v1 :: v_dual_mov_b32 v8, v4             // 000000555868: CA100101 05080104
	v_mov_b32_e32 v7, v3                                       // 000000555870: 7E0E0303
	s_mov_b32 s15, exec_lo                                     // 000000555874: BE8F007E
	s_delay_alu instid0(VALU_DEP_3)                            // 000000555878: BF870003
	v_cmp_ge_i32_e32 vcc_lo, v19, v20                          // 00000055587C: 7C8C2913
	.long 0xd4c1007e                                           // 000000555880: D4C1007E
	v_cndmask_b32_e32 v1, v19, v20, vcc_lo                     // 000000555884: 02022913
	s_cbranch_execz 65255                                      // 000000555888: BFA5FEE7 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x228>
	v_ashrrev_i32_e32 v6, 31, v25                              // 00000055588C: 340C329F
	v_ashrrev_i32_e32 v8, 31, v24                              // 000000555890: 3410309F
	.long 0xd7000005                                           // 000000555894: D7000005
	v_cndmask_b32_e32 v1, v11, v25, vcc_lo                     // 000000555898: 0202330B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000055589C: BF8700A1
	v_add_co_ci_u32_e64 v6, null, v21, v6, s0                  // 0000005558A0: D5207C06 00020D15
	.long 0xd7000007                                           // 0000005558A8: D7000007
	v_cndmask_b32_e32 v1, v9, v24, vcc_lo                      // 0000005558AC: 02023109
	v_add_co_ci_u32_e64 v8, null, v10, v8, s0                  // 0000005558B0: D5207C08 0002110A
	s_clause 0x1                                               // 0000005558B8: BF850001
	global_load_d16_b16 v13, v[5:6], off                       // 0000005558BC: DC820000 0D7C0005
	global_load_b128 v[5:8], v[7:8], off                       // 0000005558C4: DC5E0000 057C0007
	s_waitcnt vmcnt(1)                                         // 0000005558CC: BF8907F7
	v_cvt_f32_f16_e32 v26, v13                                 // 0000005558D0: 7E34170D
	s_branch 65236                                             // 0000005558D4: BFA0FED4 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x228>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000005558D8: 8C7E0E7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000005558DC: BF8700C9
	s_or_b32 exec_lo, exec_lo, s1                              // 0000005558E0: 8C7E017E
	s_waitcnt vmcnt(0)                                         // 0000005558E4: BF8903F7
	.long 0xd71f0001                                           // 0000005558E8: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000005558EC: 020100C1
	s_mov_b32 s0, exec_lo                                      // 0000005558F0: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 0000005558F4: 3A040290
	v_xor_b32_e32 v5, 8, v1                                    // 0000005558F8: 3A0A0288
	v_xor_b32_e32 v8, 4, v1                                    // 0000005558FC: 3A100284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000555900: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 000000555904: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 000000555908: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v5                            // 00000055590C: 7C980AA0
	v_cndmask_b32_e32 v5, v1, v5, vcc_lo                       // 000000555910: 020A0B01
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 000000555914: 7C9810A0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000555918: BF870002
	v_lshlrev_b32_e32 v5, 2, v5                                // 00000055591C: 300A0A82
	v_lshlrev_b32_e32 v2, 2, v2                                // 000000555920: 30040482
	ds_bpermute_b32 v3, v2, v22                                // 000000555924: DACC0000 03001602
	s_waitcnt lgkmcnt(0)                                       // 00000055592C: BF89FC07
	v_add_f32_e32 v3, v22, v3                                  // 000000555930: 06060716
	ds_bpermute_b32 v4, v2, v23                                // 000000555934: DACC0000 04001702
	ds_bpermute_b32 v2, v2, v17                                // 00000055593C: DACC0000 02001102
	ds_bpermute_b32 v6, v5, v3                                 // 000000555944: DACC0000 06000305
	v_cndmask_b32_e32 v8, v1, v8, vcc_lo                       // 00000055594C: 02101101
	s_waitcnt lgkmcnt(2)                                       // 000000555950: BF89FC27
	v_add_f32_e32 v4, v23, v4                                  // 000000555954: 06080917
	s_waitcnt lgkmcnt(0)                                       // 000000555958: BF89FC07
	v_add_f32_e32 v3, v3, v6                                   // 00000055595C: 06060D03
	ds_bpermute_b32 v7, v5, v4                                 // 000000555960: DACC0000 07000405
	v_add_f32_e32 v2, v17, v2                                  // 000000555968: 06040511
	v_lshlrev_b32_e32 v8, 2, v8                                // 00000055596C: 30101082
	ds_bpermute_b32 v5, v5, v2                                 // 000000555970: DACC0000 05000205
	s_waitcnt lgkmcnt(1)                                       // 000000555978: BF89FC17
	v_add_f32_e32 v4, v4, v7                                   // 00000055597C: 06080F04
	ds_bpermute_b32 v6, v8, v4                                 // 000000555980: DACC0000 06000408
	s_waitcnt lgkmcnt(0)                                       // 000000555988: BF89FC07
	v_add_f32_e32 v4, v4, v6                                   // 00000055598C: 06080D04
	v_add_f32_e32 v2, v2, v5                                   // 000000555990: 06040B02
	ds_bpermute_b32 v5, v8, v3                                 // 000000555994: DACC0000 05000308
	ds_bpermute_b32 v7, v8, v2                                 // 00000055599C: DACC0000 07000208
	v_xor_b32_e32 v8, 2, v1                                    // 0000005559A4: 3A100282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000005559A8: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 0000005559AC: 7C9810A0
	v_cndmask_b32_e32 v8, v1, v8, vcc_lo                       // 0000005559B0: 02101101
	s_waitcnt lgkmcnt(1)                                       // 0000005559B4: BF89FC17
	v_dual_add_f32 v3, v3, v5 :: v_dual_lshlrev_b32 v8, 2, v8  // 0000005559B8: C9220B03 03081082
	s_waitcnt lgkmcnt(0)                                       // 0000005559C0: BF89FC07
	v_add_f32_e32 v2, v2, v7                                   // 0000005559C4: 06040F02
	ds_bpermute_b32 v6, v8, v4                                 // 0000005559C8: DACC0000 06000408
	ds_bpermute_b32 v5, v8, v3                                 // 0000005559D0: DACC0000 05000308
	ds_bpermute_b32 v7, v8, v2                                 // 0000005559D8: DACC0000 07000208
	v_xor_b32_e32 v8, 1, v1                                    // 0000005559E0: 3A100281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005559E4: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 0000005559E8: 7C9810A0
	v_cndmask_b32_e32 v1, v1, v8, vcc_lo                       // 0000005559EC: 02021101
	v_lshlrev_b32_e32 v8, 2, v1                                // 0000005559F0: 30100282
	s_waitcnt lgkmcnt(1)                                       // 0000005559F4: BF89FC17
	v_add_f32_e32 v1, v3, v5                                   // 0000005559F8: 06020B03
	s_waitcnt lgkmcnt(0)                                       // 0000005559FC: BF89FC07
	v_dual_add_f32 v3, v4, v6 :: v_dual_add_f32 v2, v2, v7     // 000000555A00: C9080D04 03020F02
	ds_bpermute_b32 v4, v8, v1                                 // 000000555A08: DACC0000 04000108
	ds_bpermute_b32 v6, v8, v3                                 // 000000555A10: DACC0000 06000308
	ds_bpermute_b32 v5, v8, v2                                 // 000000555A18: DACC0000 05000208
	v_cmpx_eq_u32_e32 0, v16                                   // 000000555A20: 7D942080
	s_cbranch_execz 15                                         // 000000555A24: BFA5000F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x864>
	.long 0xd72c0007                                           // 000000555A28: D72C0007
	v_cndmask_b32_e32 v0, v14, v152, vcc_lo                    // 000000555A2C: 0201310E
	s_waitcnt lgkmcnt(0)                                       // 000000555A30: BF89FC07
	v_dual_add_f32 v1, v1, v4 :: v_dual_add_f32 v2, v2, v5     // 000000555A34: C9080901 01020B02
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000555A3C: BF870092
	v_mad_u32_u24 v7, v15, 12, v7                              // 000000555A40: D60B0007 041D190F
	v_dual_add_f32 v3, v3, v6 :: v_dual_add_nc_u32 v4, 0x400, v7// 000000555A48: C9200D03 03040EFF 00000400
	ds_store_2addr_b32 v4, v1, v3 offset1:1                    // 000000555A54: D8380100 00030104
	ds_store_b32 v7, v2 offset:1032                            // 000000555A5C: D8340408 00000207
	s_or_b32 exec_lo, exec_lo, s0                              // 000000555A64: 8C7E007E
	.long 0xd7050001                                           // 000000555A68: D7050001
	v_cndmask_b32_e32 v1, 0xab, v0, vcc_lo                     // 000000555A6C: 020200FF 000000AB
	.long 0x7f063880                                           // 000000555A74: 7F063880
	s_waitcnt lgkmcnt(0)                                       // 000000555A78: BF89FC07
	s_barrier                                                  // 000000555A7C: BFBD0000
	buffer_gl0_inv                                             // 000000555A80: E0AC0000 00000000
	.long 0xd7390003                                           // 000000555A88: D7390003
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 000000555A8C: 02020289
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000555A90: BF870091
	.long 0xd7000001                                           // 000000555A94: D7000001
	v_cndmask_b32_e32 v1, s2, v3, vcc_lo                       // 000000555A98: 02020602
	v_add_co_ci_u32_e64 v2, null, s3, 0, s0                    // 000000555A9C: D5207C02 00010003
	.long 0xd44c0000                                           // 000000555AA4: D44C0000
	v_cndmask_b32_e32 v1, 12, v0, vcc_lo                       // 000000555AA8: 0202008C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000555AAC: BF8704A2
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 000000555AB0: 7CA8020C
	s_and_b32 s0, s0, vcc_lo                                   // 000000555AB4: 8B006A00
	s_and_saveexec_b32 s1, s0                                  // 000000555AB8: BE812000
	s_cbranch_execz 45                                         // 000000555ABC: BFA5002D <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x974>
	.long 0xd7054000                                           // 000000555AC0: D7054000
	v_cndmask_b32_e32 v0, v3, v131, vcc_lo                     // 000000555AC4: 02010703
	v_mul_u32_u24_e32 v3, 24, v3                               // 000000555AC8: 16060698
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000555ACC: BF870092
	.long 0xd7041000                                           // 000000555AD0: D7041000
	v_cndmask_b32_e32 v1, v0, v0, vcc_lo                       // 000000555AD4: 02020100
	v_and_b32_e32 v0, 0xff, v0                                 // 000000555AD8: 360000FF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000555AE0: BF870091
	v_lshl_add_u32 v3, v0, 2, v3                               // 000000555AE4: D6460003 040D0500
	v_add_nc_u32_e32 v3, 0x400, v3                             // 000000555AEC: 4A0606FF 00000400
	ds_load_2addr_b32 v[6:7], v3 offset1:3                     // 000000555AF4: D8DC0300 06000003
	v_mad_u64_u32 v[3:4], null, s12, v0, 0                     // 000000555AFC: D6FE7C03 0202000C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000555B04: BF870091
	v_mad_u64_u32 v[4:5], null, s13, v0, v[4:5]                // 000000555B08: D6FE7C04 0412000D
	.long 0xd73c0003                                           // 000000555B10: D73C0003
	v_cndmask_b32_e32 v1, 1, v3, vcc_lo                        // 000000555B14: 02020681
	s_waitcnt lgkmcnt(0)                                       // 000000555B18: BF89FC07
	v_add_f32_e32 v0, 0, v6                                    // 000000555B1C: 06000C80
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000555B20: BF870112
	.long 0xd7006a03                                           // 000000555B24: D7006A03
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 000000555B28: 02020608
	v_add_f32_e32 v5, v0, v7                                   // 000000555B2C: 060A0F00
	.long 0xd73c0000                                           // 000000555B30: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 000000555B34: 02020281
	v_add_co_ci_u32_e64 v4, null, s9, v4, vcc_lo               // 000000555B38: D5207C04 01AA0809
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000555B40: BF870193
	v_bfe_u32 v2, v5, 16, 1                                    // 000000555B44: D6100002 02052105
	.long 0xd7006a00                                           // 000000555B4C: D7006A00
	v_cndmask_b32_e32 v1, v3, v0, vcc_lo                       // 000000555B50: 02020103
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000555B54: BF870191
	v_add_co_ci_u32_e64 v1, null, v4, v1, vcc_lo               // 000000555B58: D5207C01 01AA0304
	v_add3_u32 v2, v5, v2, 0x7fff                              // 000000555B60: D6550002 03FE0505 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off                    // 000000555B6C: DC960000 007C0200
	s_endpgm                                                   // 000000555B74: BFB00000
		...

