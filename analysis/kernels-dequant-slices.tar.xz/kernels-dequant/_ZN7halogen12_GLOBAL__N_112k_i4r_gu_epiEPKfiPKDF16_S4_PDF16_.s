000000000022f900 <_ZN7halogen12_GLOBAL__N_112k_i4r_gu_epiEPKfiPKDF16_S4_PDF16_>:
; _ZN7halogen12_GLOBAL__N_112k_i4r_gu_epiEPKfiPKDF16_S4_PDF16_():
	s_load_b32 s3, s[0:1], 0x8                                 // 00000022F900: F40000C0 F8000008
	v_lshrrev_b32_e32 v1, 5, v0                                // 00000022F908: 32020085
	s_delay_alu instid0(VALU_DEP_1)                            // 00000022F90C: BF870001
	v_lshl_or_b32 v1, s2, 3, v1                                // 00000022F910: D6560001 04050602
	s_mov_b32 s2, exec_lo                                      // 00000022F918: BE82007E
	s_waitcnt lgkmcnt(0)                                       // 00000022F91C: BF89FC07
	s_mul_i32 s3, s3, 5                                        // 00000022F920: 96038503
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000022F924: BF870481
	.long 0xd4c4007e                                           // 00000022F928: D4C4007E
	v_cndmask_b32_e32 v1, s3, v1, vcc_lo                       // 00000022F92C: 02020203
	s_cbranch_execz 627                                        // 00000022F930: BFA50273 <_ZN7halogen12_GLOBAL__N_112k_i4r_gu_epiEPKfiPKDF16_S4_PDF16_+0xa00>
	.long 0xd72e0002                                           // 00000022F934: D72E0002
	v_cndmask_b32_e32 v1, 0x66666667, v1, vcc_lo               // 00000022F938: 020202FF 66666667
	s_clause 0x1                                               // 00000022F940: BF850001
	s_load_b64 s[2:3], s[0:1], null                            // 00000022F944: F4040080 F8000000
	s_load_b128 s[4:7], s[0:1], 0x10                           // 00000022F94C: F4080100 F8000010
	v_and_b32_e32 v4, 31, v0                                   // 00000022F954: 3608009F
	s_mov_b32 s10, 0x76543210                                  // 00000022F958: BE8A00FF 76543210
	s_load_b64 s[0:1], s[0:1], 0x20                            // 00000022F960: F4040000 F8000020
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000022F968: BF8700B1
	v_lshlrev_b32_e32 v9, 4, v4                                // 00000022F96C: 30120884
	v_lshrrev_b32_e32 v3, 31, v2                               // 00000022F970: 3206049F
	v_ashrrev_i32_e32 v2, 1, v2                                // 00000022F974: 34040481
	v_add_nc_u32_e32 v3, v2, v3                                // 00000022F978: 4A060702
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000022F97C: BF870131
	.long 0xd72c0002                                           // 00000022F980: D72C0002
	v_cndmask_b32_e32 v0, v3, v197, vcc_lo                     // 00000022F984: 02018B03
	s_waitcnt lgkmcnt(0)                                       // 00000022F988: BF89FC07
	v_mad_i64_i32 v[5:6], null, 0x1400, v3, s[2:3]             // 00000022F98C: D6FF7C05 000A06FF 00001400
	v_add_lshl_u32 v1, v2, v1, 7                               // 00000022F998: D6470001 021E0302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000022F9A0: BF870091
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000022F9A4: 3404029F
	.long 0xd73c0007                                           // 00000022F9A8: D73C0007
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000022F9AC: 02020282
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000022F9B0: BF870091
	.long 0xd7006a05                                           // 00000022F9B4: D7006A05
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 00000022F9B8: 02020F05
	v_add_co_ci_u32_e64 v6, null, v6, v8, vcc_lo               // 00000022F9BC: D5207C06 01AA1106
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000022F9C4: BF870092
	.long 0xd7006a09                                           // 00000022F9C8: D7006A09
	v_cndmask_b32_e32 v1, v5, v9, vcc_lo                       // 00000022F9CC: 02021305
	v_add_co_ci_u32_e64 v10, null, 0, v6, vcc_lo               // 00000022F9D0: D5207C0A 01AA0C80
	s_clause 0x1                                               // 00000022F9D8: BF850001
	global_load_b128 v[5:8], v[9:10], off                      // 00000022F9DC: DC5E0000 057C0009
	global_load_b128 v[9:12], v[9:10], off offset:2560         // 00000022F9E4: DC5E0A00 097C0009
	v_and_b32_e32 v19, 1, v0                                   // 00000022F9EC: 36260081
	v_and_b32_e32 v20, 2, v0                                   // 00000022F9F0: 36280082
	s_waitcnt vmcnt(1)                                         // 00000022F9F4: BF8907F7
	v_add_f32_e32 v22, v5, v6                                  // 00000022F9F8: 062C0D05
	v_sub_f32_e32 v5, v5, v6                                   // 00000022F9FC: 080A0D05
	v_lshl_or_b32 v13, v4, 2, v1                               // 00000022FA00: D656000D 04050504
	v_add_f32_e32 v6, v7, v8                                   // 00000022FA08: 060C1107
	v_sub_f32_e32 v7, v7, v8                                   // 00000022FA0C: 080E1107
	v_and_b32_e32 v21, 4, v0                                   // 00000022FA10: 362A0084
	v_and_b32_e32 v0, 8, v0                                    // 00000022FA14: 36000088
	v_ashrrev_i32_e32 v14, 31, v13                             // 00000022FA18: 341C1A9F
	s_waitcnt vmcnt(0)                                         // 00000022FA1C: BF8903F7
	v_add_f32_e32 v8, v9, v10                                  // 00000022FA20: 06101509
	v_dual_sub_f32 v9, v9, v10 :: v_dual_add_f32 v10, v11, v12 // 00000022FA24: C9481509 090A190B
	v_sub_f32_e32 v11, v11, v12                                // 00000022FA2C: 0816190B
	.long 0xd73c000d                                           // 00000022FA30: D73C000D
	v_cndmask_b32_e32 v1, 1, v13, vcc_lo                       // 00000022FA34: 02021A81
	v_add_f32_e32 v23, v5, v7                                  // 00000022FA38: 062E0F05
	.long 0xd44a0002                                           // 00000022FA3C: D44A0002
	v_cndmask_b32_e32 v1, 0, v19, vcc_lo                       // 00000022FA40: 02022680
	v_dual_sub_f32 v5, v5, v7 :: v_dual_add_f32 v12, v22, v6   // 00000022FA44: C9480F05 050C0D16
	v_sub_f32_e32 v6, v22, v6                                  // 00000022FA4C: 080C0D16
	.long 0xd7006a0f                                           // 00000022FA50: D7006A0F
	v_cndmask_b32_e32 v1, s4, v13, vcc_lo                      // 00000022FA54: 02021A04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000022FA58: BF8700D1
	v_add_co_ci_u32_e64 v16, null, s5, v14, vcc_lo             // 00000022FA5C: D5207C10 01AA1C05
	s_clause 0x1                                               // 00000022FA64: BF850001
	global_load_b64 v[17:18], v[15:16], off                    // 00000022FA68: DC560000 117C000F
	global_load_b64 v[15:16], v[15:16], off offset:1280        // 00000022FA70: DC560500 0F7C000F
	.long 0xd7006a0d                                           // 00000022FA78: D7006A0D
	v_cndmask_b32_e32 v1, s6, v13, vcc_lo                      // 00000022FA7C: 02021A06
	v_add_co_ci_u32_e64 v14, null, s7, v14, vcc_lo             // 00000022FA80: D5207C0E 01AA1C07
	v_add_f32_e32 v19, v9, v11                                 // 00000022FA88: 06261709
	v_cndmask_b32_e64 v22, -v23, v23, s2                       // 00000022FA8C: D5010016 200A2F17
	v_add_f32_e32 v7, v8, v10                                  // 00000022FA94: 060E1508
	global_load_b64 v[13:14], v[13:14], off                    // 00000022FA98: DC560000 0D7C000D
	v_sub_f32_e32 v8, v8, v10                                  // 00000022FAA0: 08101508
	v_mov_b32_dpp v10, v12 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000022FAA4: 7E1402FA FF01610C
	v_mov_b32_dpp v26, v19 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000022FAAC: 7E3402FA FF016113
	v_cndmask_b32_e64 v19, -v19, v19, s2                       // 00000022FAB4: D5010013 200A2713
	.long 0xd44a0003                                           // 00000022FABC: D44A0003
	v_cndmask_b32_e32 v1, 0, v20, vcc_lo                       // 00000022FAC0: 02022880
	v_mov_b32_dpp v27, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000022FAC4: 7E3602FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 00000022FACC: D5010008 200A1108
	v_mov_b32_dpp v24, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000022FAD4: 7E3002FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, s2                          // 00000022FADC: D5010005 200A0B05
	.long 0xd44a0005                                           // 00000022FAE4: D44A0005
	v_cndmask_b32_e32 v1, 0, v21, vcc_lo                       // 00000022FAE8: 02022A80
	.long 0xd44a0004                                           // 00000022FAEC: D44A0004
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 00000022FAF0: 02020080
	v_add_f32_e32 v8, v8, v27                                  // 00000022FAF4: 06103708
	v_sub_f32_e32 v9, v9, v11                                  // 00000022FAF8: 08121709
	v_cndmask_b32_e64 v11, -v12, v12, s2                       // 00000022FAFC: D501000B 200A190C
	v_mov_b32_dpp v12, v23 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000022FB04: 7E1802FA FF016117
	v_mov_b32_dpp v23, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000022FB0C: 7E2E02FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s2                          // 00000022FB14: D5010006 200A0D06
	.long 0xd44c0006                                           // 00000022FB1C: D44C0006
	v_cndmask_b32_e32 v1, 16, v4, vcc_lo                       // 00000022FB20: 02020890
	v_add_f32_e32 v10, v11, v10                                // 00000022FB24: 0614150B
	v_add_f32_e32 v12, v22, v12                                // 00000022FB28: 06181916
	v_mov_b32_dpp v25, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000022FB2C: 7E3202FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s2                          // 00000022FB34: D5010007 200A0F07
	v_mov_b32_dpp v28, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000022FB3C: 7E3802FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s2                          // 00000022FB44: D5010009 200A1309
	v_mov_b32_dpp v22, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000022FB4C: 7E2C02FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s3                          // 00000022FB54: D5010008 200E1108
	v_dual_add_f32 v7, v7, v25 :: v_dual_add_f32 v6, v6, v23   // 00000022FB5C: C9083307 07062F06
	v_mov_b32_dpp v25, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000022FB64: 7E3202FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, s3                       // 00000022FB6C: D501000C 200E190C
	v_add_f32_e32 v19, v19, v26                                // 00000022FB74: 06263513
	v_dual_add_f32 v9, v9, v28 :: v_dual_add_f32 v8, v8, v22   // 00000022FB78: C9083909 09082D08
	v_mov_b32_dpp v11, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000022FB80: 7E1602FA FF016207
	v_cndmask_b32_e64 v7, -v7, v7, s3                          // 00000022FB88: D5010007 200E0F07
	v_add_f32_e32 v12, v12, v25                                // 00000022FB90: 0618330C
	v_mov_b32_dpp v20, v19 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000022FB94: 7E2802FA FF016213
	v_cndmask_b32_e64 v19, -v19, v19, s3                       // 00000022FB9C: D5010013 200E2713
	v_mov_b32_dpp v23, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000022FBA4: 7E2E02FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 00000022FBAC: D5010009 200E1309
	v_mov_b32_dpp v26, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000022FBB4: 7E3402FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, s3                          // 00000022FBBC: D5010006 200E0D06
	v_add_f32_e32 v5, v5, v24                                  // 00000022FBC4: 060A3105
	v_mov_b32_dpp v24, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000022FBC8: 7E3002FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, s3                       // 00000022FBD0: D501000A 200E150A
	v_add_f32_e32 v7, v7, v11                                  // 00000022FBD8: 060E1707
	v_mov_b32_dpp v21, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000022FBDC: 7E2A02FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, s5                          // 00000022FBE4: D5010008 20161108
	v_add_f32_e32 v11, v19, v20                                // 00000022FBEC: 06162913
	v_add_f32_e32 v10, v10, v24                                // 00000022FBF0: 0614310A
	v_add_f32_e32 v6, v6, v26                                  // 00000022FBF4: 060C3506
	v_mov_b32_dpp v27, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000022FBF8: 7E3602FA FF016205
	v_add_f32_e32 v8, v8, v21                                  // 00000022FC00: 06102B08
	v_mov_b32_dpp v20, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000022FC04: 7E2802FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s5                       // 00000022FC0C: D501000B 2016170B
	v_add_f32_e32 v9, v9, v23                                  // 00000022FC14: 06122F09
	v_mov_b32_dpp v23, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000022FC18: 7E2E02FA FF01640A
	v_cndmask_b32_e64 v10, -v10, v10, s5                       // 00000022FC20: D501000A 2016150A
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 00000022FC28: D5010005 200E0B05
	v_add_f32_e32 v0, v11, v20                                 // 00000022FC30: 0600290B
	v_mov_b32_dpp v22, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000022FC34: 7E2C02FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s5                          // 00000022FC3C: D5010009 20161309
	v_mov_b32_dpp v24, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000022FC44: 7E3002FA FF01640C
	v_cndmask_b32_e64 v12, -v12, v12, s5                       // 00000022FC4C: D501000C 2016190C
	v_mov_b32_dpp v25, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000022FC54: 7E3202FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s5                          // 00000022FC5C: D5010006 20160D06
	v_dual_add_f32 v9, v9, v22 :: v_dual_add_f32 v10, v10, v23 // 00000022FC64: C9082D09 090A2F0A
	v_add_f32_e32 v5, v5, v27                                  // 00000022FC6C: 060A3705
	v_mov_b32_dpp v19, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000022FC70: 7E2602FA FF016407
	v_cndmask_b32_e64 v7, -v7, v7, s5                          // 00000022FC78: D5010007 20160F07
	v_add_f32_e32 v6, v6, v25                                  // 00000022FC80: 060C3306
	v_mov_b32_dpp v22, v10 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000022FC84: 7E2C02FA FF01680A
	v_cndmask_b32_e64 v10, -v10, v10, s4                       // 00000022FC8C: D501000A 2012150A
	v_add_f32_e32 v11, v12, v24                                // 00000022FC94: 0616310C
	v_mov_b32_dpp v26, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000022FC98: 7E3402FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s5                          // 00000022FCA0: D5010005 20160B05
	v_mov_b32_dpp v20, v8 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000022FCA8: 7E2802FA FF016808
	v_cndmask_b32_e64 v8, -v8, v8, s4                          // 00000022FCB0: D5010008 20121108
	v_add_f32_e32 v7, v7, v19                                  // 00000022FCB8: 060E2707
	v_mov_b32_dpp v24, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000022FCBC: 7E3002FA FF016806
	v_cndmask_b32_e64 v6, -v6, v6, s4                          // 00000022FCC4: D5010006 20120D06
	v_add_f32_e32 v10, v10, v22                                // 00000022FCCC: 06142D0A
	v_mov_b32_dpp v23, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000022FCD0: 7E2E02FA FF01680B
	v_cndmask_b32_e64 v11, -v11, v11, s4                       // 00000022FCD8: D501000B 2012170B
	v_mov_b32_dpp v19, v0 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000022FCE0: 7E2602FA FF016800
	v_cndmask_b32_e64 v0, -v0, v0, s4                          // 00000022FCE8: D5010000 20120100
	v_dual_add_f32 v5, v5, v26 :: v_dual_add_f32 v8, v8, v20   // 00000022FCF0: C9083505 05082908
	v_mov_b32_dpp v12, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000022FCF8: 7E1802FA FF016807
	v_cndmask_b32_e64 v7, -v7, v7, s4                          // 00000022FD00: D5010007 20120F07
	v_dual_add_f32 v11, v11, v23 :: v_dual_add_f32 v6, v6, v24 // 00000022FD08: C9082F0B 0B063106
	v_add_f32_e32 v0, v0, v19                                  // 00000022FD10: 06002700
	v_mov_b32_dpp v25, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000022FD14: 7E3202FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s4                          // 00000022FD1C: D5010005 20120B05
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000022FD24: BF870234
	v_dual_add_f32 v7, v7, v12 :: v_dual_mov_b32 v22, v6       // 00000022FD28: C9101907 07160106
	v_mov_b32_dpp v21, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000022FD30: 7E2A02FA FF016809
	v_cndmask_b32_e64 v9, -v9, v9, s4                          // 00000022FD38: D5010009 20121309
	v_dual_add_f32 v5, v5, v25 :: v_dual_mov_b32 v20, v11      // 00000022FD40: C9103305 0514010B
	v_mov_b32_e32 v19, v10                                     // 00000022FD48: 7E26030A
	v_cndmask_b32_e64 v6, -v6, v6, s6                          // 00000022FD4C: D5010006 201A0D06
	v_permlanex16_b32 v22, v22, s10, 0xfedcba98                // 00000022FD54: D65C0016 03FC1516 FEDCBA98
	v_cndmask_b32_e64 v11, -v11, v11, s6                       // 00000022FD60: D501000B 201A170B
	v_cndmask_b32_e64 v10, -v10, v10, s6                       // 00000022FD68: D501000A 201A150A
	v_permlanex16_b32 v19, v19, s10, 0xfedcba98                // 00000022FD70: D65C0013 03FC1513 FEDCBA98
	v_mov_b32_e32 v23, v5                                      // 00000022FD7C: 7E2E0305
	v_permlanex16_b32 v20, v20, s10, 0xfedcba98                // 00000022FD80: D65C0014 03FC1514 FEDCBA98
	v_dual_add_f32 v9, v9, v21 :: v_dual_add_f32 v6, v6, v22   // 00000022FD8C: C9082B09 09062D06
	v_cndmask_b32_e64 v5, -v5, v5, s6                          // 00000022FD94: D5010005 201A0B05
	v_add_f32_e32 v10, v10, v19                                // 00000022FD9C: 0614270A
	v_permlanex16_b32 v23, v23, s10, 0xfedcba98                // 00000022FDA0: D65C0017 03FC1517 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000022FDAC: BF870224
	v_dual_add_f32 v11, v11, v20 :: v_dual_mul_f32 v6, 0x3db504f3, v6// 00000022FDB0: C906290B 0B060CFF 3DB504F3
	v_mov_b32_e32 v22, v8                                      // 00000022FDBC: 7E2C0308
	v_mul_f32_e32 v10, 0x3db504f3, v10                         // 00000022FDC0: 101414FF 3DB504F3
	v_cndmask_b32_e64 v12, -v7, v7, s6                         // 00000022FDC8: D501000C 201A0F07
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000022FDD0: BF8700C4
	v_mul_f32_e32 v11, 0x3db504f3, v11                         // 00000022FDD4: 101616FF 3DB504F3
	v_permlanex16_b32 v7, v7, s10, 0xfedcba98                  // 00000022FDDC: D65C0007 03FC1507 FEDCBA98
	v_cndmask_b32_e64 v8, -v8, v8, s6                          // 00000022FDE8: D5010008 201A1108
	v_permlanex16_b32 v22, v22, s10, 0xfedcba98                // 00000022FDF0: D65C0016 03FC1516 FEDCBA98
	v_add_f32_e32 v8, v8, v22                                  // 00000022FDFC: 06102D08
	s_delay_alu instid0(VALU_DEP_1)                            // 00000022FE00: BF870001
	v_mul_f32_e32 v8, 0x3db504f3, v8                           // 00000022FE04: 101010FF 3DB504F3
	s_waitcnt vmcnt(2)                                         // 00000022FE0C: BF890BF7
	v_fma_mix_f32 v6, v18, v6, neg(0) op_sel_hi:[1,0,0]        // 00000022FE10: CC200006 8A020D12
	v_add_f32_e32 v5, v5, v23                                  // 00000022FE18: 060A2F05
	v_fma_mix_f32 v11, v17, v11, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 00000022FE1C: CC20080B 8A021711
	v_mov_b32_e32 v19, v0                                      // 00000022FE24: 7E260300
	v_cndmask_b32_e64 v0, -v0, v0, s6                          // 00000022FE28: D5010000 201A0100
	v_mul_f32_e32 v20, 0xbfb8aa3b, v6                          // 00000022FE30: 10280CFF BFB8AA3B
	v_mul_f32_e32 v5, 0x3db504f3, v5                           // 00000022FE38: 100A0AFF 3DB504F3
	v_fma_mix_f32 v10, v17, v10, neg(0) op_sel_hi:[1,0,0]      // 00000022FE40: CC20000A 8A021511
	v_mov_b32_e32 v23, v9                                      // 00000022FE48: 7E2E0309
	v_cndmask_b32_e64 v9, -v9, v9, s6                          // 00000022FE4C: D5010009 201A1309
	v_exp_f32_e32 v20, v20                                     // 00000022FE54: 7E284B14
	v_fma_mix_f32 v5, v18, v5, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 00000022FE58: CC200805 8A020B12
	v_mul_f32_e32 v18, 0xbfb8aa3b, v11                         // 00000022FE60: 102416FF BFB8AA3B
	v_permlanex16_b32 v19, v19, s10, 0xfedcba98                // 00000022FE68: D65C0013 03FC1513 FEDCBA98
	v_mul_f32_e32 v17, 0xbfb8aa3b, v10                         // 00000022FE74: 102214FF BFB8AA3B
	v_permlanex16_b32 v23, v23, s10, 0xfedcba98                // 00000022FE7C: D65C0017 03FC1517 FEDCBA98
	v_mul_f32_e32 v21, 0xbfb8aa3b, v5                          // 00000022FE88: 102A0AFF BFB8AA3B
	v_exp_f32_e32 v18, v18                                     // 00000022FE90: 7E244B12
	v_add_f32_e32 v0, v0, v19                                  // 00000022FE94: 06002700
	s_waitcnt vmcnt(1)                                         // 00000022FE98: BF8907F7
	v_fma_mix_f32 v8, v16, v8, neg(0) op_sel_hi:[1,0,0]        // 00000022FE9C: CC200008 8A021110
	v_add_f32_e32 v20, 1.0, v20                                // 00000022FEA4: 062828F2
	v_exp_f32_e32 v21, v21                                     // 00000022FEA8: 7E2A4B15
	v_exp_f32_e32 v17, v17                                     // 00000022FEAC: 7E224B11
	v_mul_f32_e32 v0, 0x3db504f3, v0                           // 00000022FEB0: 100000FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_3)// 00000022FEB8: BF870392
	v_div_scale_f32 v26, null, v20, v20, v6                    // 00000022FEBC: D6FC7C1A 041A2914
	v_add_f32_e32 v18, 1.0, v18                                // 00000022FEC4: 062424F2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000022FEC8: BF870193
	v_fma_mix_f32 v0, v15, v0, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 00000022FECC: CC200800 8A02010F
	v_rcp_f32_e32 v29, v26                                     // 00000022FED4: 7E3A551A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 00000022FED8: BF870312
	v_div_scale_f32 v25, null, v18, v18, v11                   // 00000022FEDC: D6FC7C19 042E2512
	v_add_f32_e32 v17, 1.0, v17                                // 00000022FEE4: 062222F2
	v_div_scale_f32 v22, s7, v11, v18, v11                     // 00000022FEE8: D6FC0716 042E250B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000022FEF0: BF870113
	v_rcp_f32_e32 v28, v25                                     // 00000022FEF4: 7E385519
	v_div_scale_f32 v24, null, v17, v17, v10                   // 00000022FEF8: D6FC7C18 042A2311
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000022FF00: BF870296
	v_fma_f32 v33, -v26, v29, 1.0                              // 00000022FF04: D6130021 23CA3B1A
	v_fma_f32 v32, -v25, v28, 1.0                              // 00000022FF0C: D6130020 23CA3919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000022FF14: BF870091
	v_dual_add_f32 v21, 1.0, v21 :: v_dual_fmac_f32 v28, v32, v28// 00000022FF18: C9002AF2 151C3920
	v_div_scale_f32 v27, null, v21, v21, v5                    // 00000022FF20: D6FC7C1B 04162B15
	v_add_f32_e32 v9, v9, v23                                  // 00000022FF28: 06122F09
	v_div_scale_f32 v23, s8, v6, v20, v6                       // 00000022FF2C: D6FC0817 041A2906
	v_div_scale_f32 v35, s9, v5, v21, v5                       // 00000022FF34: D6FC0923 04162B05
	v_mul_f32_e32 v32, v22, v28                                // 00000022FF3C: 10403916
	v_rcp_f32_e32 v30, v27                                     // 00000022FF40: 7E3C551B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000022FF44: BF870291
	v_fma_f32 v37, -v25, v32, v22                              // 00000022FF48: D6130025 245A4119
	v_fma_f32 v34, -v27, v30, 1.0                              // 00000022FF50: D6130022 23CA3D1B
	v_add_f32_e32 v7, v12, v7                                  // 00000022FF58: 060E0F0C
	v_rcp_f32_e32 v12, v24                                     // 00000022FF5C: 7E185518
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000022FF60: BF870091
	v_dual_fmac_f32 v30, v34, v30 :: v_dual_mul_f32 v7, 0x3db504f3, v7// 00000022FF64: C8063D22 1E060EFF 3DB504F3
	v_dual_fmac_f32 v29, v33, v29 :: v_dual_mul_f32 v34, v35, v30// 00000022FF70: C8063B21 1D223D23
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000022FF78: BF870292
	v_fma_mix_f32 v7, v15, v7, neg(0) op_sel_hi:[1,0,0]        // 00000022FF7C: CC200007 8A020F0F
	v_fma_f32 v31, -v24, v12, 1.0                              // 00000022FF84: D613001F 23CA1918
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000022FF8C: BF870213
	v_mul_f32_e32 v33, v23, v29                                // 00000022FF90: 10423B17
	v_fma_f32 v39, -v27, v34, v35                              // 00000022FF94: D6130027 248E451B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000022FF9C: BF870223
	v_fmac_f32_e32 v12, v31, v12                               // 00000022FFA0: 5618191F
	v_div_scale_f32 v19, vcc_lo, v10, v17, v10                 // 00000022FFA4: D6FC6A13 042A230A
	v_fma_f32 v38, -v26, v33, v23                              // 00000022FFAC: D6130026 245E431A
	v_fmac_f32_e32 v32, v37, v28                               // 00000022FFB4: 56403925
	v_fmac_f32_e32 v34, v39, v30                               // 00000022FFB8: 56443D27
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000022FFBC: BF870214
	v_mul_f32_e32 v31, v19, v12                                // 00000022FFC0: 103E1913
	v_fmac_f32_e32 v33, v38, v29                               // 00000022FFC4: 56423B26
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000022FFC8: BF870194
	v_fma_f32 v22, -v25, v32, v22                              // 00000022FFCC: D6130016 245A4119
	v_fma_f32 v36, -v24, v31, v19                              // 00000022FFD4: D6130024 244E3F18
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000022FFDC: BF870113
	v_fma_f32 v23, -v26, v33, v23                              // 00000022FFE0: D6130017 245E431A
	v_fmac_f32_e32 v31, v36, v12                               // 00000022FFE8: 563E1924
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000022FFEC: BF870121
	v_fma_f32 v19, -v24, v31, v19                              // 00000022FFF0: D6130013 244E3F18
	v_fma_f32 v24, -v27, v34, v35                              // 00000022FFF8: D6130018 248E451B
	v_div_fmas_f32 v12, v19, v12, v31                          // 000000230000: D637000C 047E1913
	s_mov_b32 vcc_lo, s7                                       // 000000230008: BEEA0007
	v_div_fmas_f32 v19, v22, v28, v32                          // 00000023000C: D6370013 04823916
	s_mov_b32 vcc_lo, s8                                       // 000000230014: BEEA0008
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 000000230018: BF8701D2
	v_div_fixup_f32 v10, v12, v17, v10                         // 00000023001C: D627000A 042A230C
	v_div_fmas_f32 v22, v23, v29, v33                          // 000000230024: D6370016 04863B17
	s_mov_b32 vcc_lo, s9                                       // 00000023002C: BEEA0009
	v_div_fixup_f32 v11, v19, v18, v11                         // 000000230030: D627000B 042E2513
	v_div_fmas_f32 v23, v24, v30, v34                          // 000000230038: D6370017 048A3D18
	v_div_fixup_f32 v6, v22, v20, v6                           // 000000230040: D6270006 041A2916
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000230048: BF870193
	v_dual_mul_f32 v9, 0x3db504f3, v9 :: v_dual_mul_f32 v0, v0, v11// 00000023004C: C8C612FF 09001700 3DB504F3
	v_div_fixup_f32 v5, v23, v21, v5                           // 000000230058: D6270005 04162B17
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000230060: BF870193
	v_mul_f32_e32 v6, v8, v6                                   // 000000230064: 100C0D08
	v_fma_mix_f32 v9, v16, v9, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000230068: CC200809 8A021310
	s_waitcnt vmcnt(0)                                         // 000000230070: BF8903F7
	v_fma_mix_f32 v0, v13, v0, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000230074: CC200800 8A02010D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000023007C: BF870092
	v_mul_f32_e32 v5, v9, v5                                   // 000000230080: 100A0B09
	v_fma_mix_f32 v5, v14, v5, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000230084: CC200805 8A020B0E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000023008C: BF870131
	v_fma_mix_f32 v9, v6, v14, v5 op_sel_hi:[0,1,0]            // 000000230090: CC200009 14161D06
	v_mul_f32_e32 v7, v7, v10                                  // 000000230098: 100E1507
	v_fma_mix_f32 v5, v6, v14, -v5 op_sel_hi:[0,1,0]           // 00000023009C: CC200005 94161D06
	v_fma_mix_f32 v8, v7, v13, v0 op_sel_hi:[0,1,0]            // 0000002300A4: CC200008 14021B07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000002300AC: BF870131
	v_add_f32_e32 v6, v8, v9                                   // 0000002300B0: 060C1308
	v_fma_mix_f32 v0, v7, v13, -v0 op_sel_hi:[0,1,0]           // 0000002300B4: CC200000 94021B07
	v_sub_f32_e32 v8, v8, v9                                   // 0000002300BC: 08101308
	v_add_f32_e32 v7, v0, v5                                   // 0000002300C0: 060E0B00
	v_sub_f32_e32 v0, v0, v5                                   // 0000002300C4: 08000B00
	v_mov_b32_dpp v5, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000002300C8: 7E0A02FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s2                          // 0000002300D0: D5010006 200A0D06
	v_mov_b32_dpp v10, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000002300D8: 7E1402FA FF016108
	v_mov_b32_dpp v9, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000002300E0: 7E1202FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s2                          // 0000002300E8: D5010007 200A0F07
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 0000002300F0: D5010008 200A1108
	v_add_f32_e32 v5, v6, v5                                   // 0000002300F8: 060A0B06
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002300FC: BF870112
	v_dual_add_f32 v6, v7, v9 :: v_dual_add_f32 v7, v8, v10    // 000000230100: C9081307 06061508
	v_mov_b32_dpp v8, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000230108: 7E1002FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 000000230110: D5010005 200E0B05
	s_delay_alu instid0(VALU_DEP_3)                            // 000000230118: BF870003
	v_mov_b32_dpp v9, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000023011C: 7E1202FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, s3                          // 000000230124: D5010006 200E0D06
	v_mov_b32_dpp v10, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000023012C: 7E1402FA FF016207
	v_cndmask_b32_e64 v7, -v7, v7, s3                          // 000000230134: D5010007 200E0F07
	v_add_f32_e32 v5, v5, v8                                   // 00000023013C: 060A1105
	v_mov_b32_dpp v11, v0 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000230140: 7E1602FA FF016100
	v_cndmask_b32_e64 v0, -v0, v0, s2                          // 000000230148: D5010000 200A0100
	s_mov_b32 s2, 0x3db504f3                                   // 000000230150: BE8200FF 3DB504F3
	v_add_f32_e32 v7, v7, v10                                  // 000000230158: 060E1507
	v_mov_b32_dpp v8, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000023015C: 7E1002FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s5                          // 000000230164: D5010005 20160B05
	v_add_f32_e32 v0, v0, v11                                  // 00000023016C: 06001700
	v_add_f32_e32 v6, v6, v9                                   // 000000230170: 060C1306
	v_mov_b32_dpp v10, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000230174: 7E1402FA FF016407
	v_cndmask_b32_e64 v7, -v7, v7, s5                          // 00000023017C: D5010007 20160F07
	v_add_f32_e32 v5, v5, v8                                   // 000000230184: 060A1105
	v_mov_b32_dpp v11, v0 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000230188: 7E1602FA FF016200
	v_cndmask_b32_e64 v0, -v0, v0, s3                          // 000000230190: D5010000 200E0100
	v_mov_b32_dpp v9, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000230198: 7E1202FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s5                          // 0000002301A0: D5010006 20160D06
	v_lshlrev_b32_e32 v8, 3, v4                                // 0000002301A8: 30100883
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002301AC: BF870194
	v_add_f32_e32 v0, v0, v11                                  // 0000002301B0: 06001700
	v_add_f32_e32 v4, v6, v9                                   // 0000002301B4: 06081306
	v_add_f32_e32 v6, v7, v10                                  // 0000002301B8: 060C1507
	v_mov_b32_dpp v7, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000002301BC: 7E0E02FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s4                          // 0000002301C4: D5010005 20120B05
	v_mov_b32_dpp v11, v0 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000002301CC: 7E1602FA FF016400
	v_cndmask_b32_e64 v0, -v0, v0, s5                          // 0000002301D4: D5010000 20160100
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000002301DC: BF870233
	v_add_f32_e32 v5, v5, v7                                   // 0000002301E0: 060A0F05
	v_mov_b32_dpp v9, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000002301E4: 7E1202FA FF016804
	v_cndmask_b32_e64 v10, -v4, v4, s4                         // 0000002301EC: D501000A 20120904
	v_add_f32_e32 v0, v0, v11                                  // 0000002301F4: 06001700
	v_mad_i64_i32 v[3:4], null, 0x500, v3, s[0:1]              // 0000002301F8: D6FF7C03 000206FF 00000500
	s_delay_alu instid0(VALU_DEP_3)                            // 000000230204: BF870003
	v_add_f32_e32 v7, v10, v9                                  // 000000230208: 060E130A
	v_mov_b32_dpp v11, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000023020C: 7E1602FA FF016806
	v_cndmask_b32_e64 v6, -v6, v6, s4                          // 000000230214: D5010006 20120D06
	v_mov_b32_e32 v9, v5                                       // 00000023021C: 7E120305
	v_mov_b32_dpp v12, v0 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000230220: 7E1802FA FF016800
	v_cndmask_b32_e64 v0, -v0, v0, s4                          // 000000230228: D5010000 20120100
	v_mov_b32_e32 v10, v7                                      // 000000230230: 7E140307
	v_cndmask_b32_e64 v5, -v5, v5, s6                          // 000000230234: D5010005 201A0B05
	v_cndmask_b32_e64 v7, -v7, v7, s6                          // 00000023023C: D5010007 201A0F07
	v_permlanex16_b32 v9, v9, s10, 0xfedcba98                  // 000000230244: D65C0009 03FC1509 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000230250: BF8700B4
	v_permlanex16_b32 v10, v10, s10, 0xfedcba98                // 000000230254: D65C000A 03FC150A FEDCBA98
	v_add_f32_e32 v6, v6, v11                                  // 000000230260: 060C1706
	v_add_f32_e32 v0, v0, v12                                  // 000000230264: 06001900
	v_mov_b32_e32 v12, v0                                      // 000000230268: 7E180300
	v_cndmask_b32_e64 v13, -v0, v0, s6                         // 00000023026C: D501000D 201A0100
	.long 0xd73c0000                                           // 000000230274: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 000000230278: 02020281
	v_dual_add_f32 v2, v5, v9 :: v_dual_add_f32 v5, v7, v10    // 00000023027C: C9081305 02041507
	v_mov_b32_e32 v11, v6                                      // 000000230284: 7E160306
	v_cndmask_b32_e64 v6, -v6, v6, s6                          // 000000230288: D5010006 201A0D06
	v_permlanex16_b32 v12, v12, s10, 0xfedcba98                // 000000230290: D65C000C 03FC150C FEDCBA98
	.long 0xd7006a03                                           // 00000023029C: D7006A03
	v_cndmask_b32_e32 v1, v3, v0, vcc_lo                       // 0000002302A0: 02020103
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000002302A4: BF870224
	v_permlanex16_b32 v11, v11, s10, 0xfedcba98                // 0000002302A8: D65C000B 03FC150B FEDCBA98
	v_add_co_ci_u32_e64 v4, null, v4, v1, vcc_lo               // 0000002302B4: D5207C04 01AA0304
	v_add_f32_e32 v7, v13, v12                                 // 0000002302BC: 060E190D
	v_fma_mixlo_f16 v0, v2, s2, 0                              // 0000002302C0: CC210000 02000502
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000002302C8: BF870244
	v_add_f32_e32 v6, v6, v11                                  // 0000002302CC: 060C1706
	.long 0xd7006a02                                           // 0000002302D0: D7006A02
	v_cndmask_b32_e32 v1, v3, v8, vcc_lo                       // 0000002302D4: 02021103
	v_fma_mixhi_f16 v0, v5, s2, 0                              // 0000002302D8: CC220000 02000505
	v_fma_mixhi_f16 v1, v7, s2, 0                              // 0000002302E0: CC220001 02000507
	v_fma_mixlo_f16 v1, v6, s2, 0                              // 0000002302E8: CC210001 02000506
	v_add_co_ci_u32_e64 v3, null, 0, v4, vcc_lo                // 0000002302F0: D5207C03 01AA0880
	global_store_b64 v[2:3], v[0:1], off                       // 0000002302F8: DC6E0000 007C0002
	s_endpgm                                                   // 000000230300: BFB00000
		...

