000000000036e600 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi1ELi32ELi2EEEvNS0_5LqGrpEPKtl>:
; _ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi1ELi32ELi2EEEvNS0_5LqGrpEPKtl():
	s_clause 0x3                                               // 00000036E600: BF850003
	s_load_b32 s3, s[0:1], 0x120                               // 00000036E604: F40000C0 F8000120
	s_load_b32 s4, s[0:1], 0x88                                // 00000036E60C: F4000100 F8000088
	s_load_b32 s5, s[0:1], 0xd0                                // 00000036E614: F4000140 F80000D0
	s_load_b32 s6, s[0:1], 0x118                               // 00000036E61C: F4000180 F8000118
	v_lshrrev_b32_e32 v5, 5, v0                                // 00000036E624: 320A0085
	v_mov_b32_e32 v16, 0                                       // 00000036E628: 7E200280
	v_mov_b32_e32 v12, 0                                       // 00000036E62C: 7E180280
	v_dual_mov_b32 v30, 0 :: v_dual_mov_b32 v13, 0             // 00000036E630: CA100080 1E0C0080
	s_waitcnt lgkmcnt(0)                                       // 00000036E638: BF89FC07
	s_cmp_gt_i32 s3, 1                                         // 00000036E63C: BF028103
	s_cselect_b32 s7, -1, 0                                    // 00000036E640: 980780C1
	s_cmp_ge_i32 s2, s4                                        // 00000036E644: BF030402
	s_cselect_b32 s4, -1, 0                                    // 00000036E648: 980480C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000036E64C: BF870009
	s_and_b32 s4, s7, s4                                       // 00000036E650: 8B040407
	s_cmp_gt_i32 s3, 2                                         // 00000036E654: BF028203
	v_cndmask_b32_e64 v1, 0, 1, s4                             // 00000036E658: D5010001 00110280
	s_cselect_b32 s7, -1, 0                                    // 00000036E660: 980780C1
	s_cmp_ge_i32 s2, s5                                        // 00000036E664: BF030502
	s_cselect_b32 s5, -1, 0                                    // 00000036E668: 980580C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000036E66C: BF870009
	s_and_b32 s4, s7, s5                                       // 00000036E670: 8B040507
	s_cmp_gt_i32 s3, 3                                         // 00000036E674: BF028303
	v_readfirstlane_b32 s5, v1                                 // 00000036E678: 7E0A0501
	s_cselect_b32 s3, -1, 0                                    // 00000036E67C: 980380C1
	s_cmp_ge_i32 s2, s6                                        // 00000036E680: BF030602
	s_cselect_b32 s6, -1, 0                                    // 00000036E684: 980680C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000036E688: BF870009
	s_and_b32 s3, s3, s6                                       // 00000036E68C: 8B030603
	s_and_b32 s4, s4, exec_lo                                  // 00000036E690: 8B047E04
	s_cselect_b32 s4, 2, s5                                    // 00000036E694: 98040582
	s_and_b32 s3, s3, exec_lo                                  // 00000036E698: 8B037E03
	s_cselect_b32 s3, 3, s4                                    // 00000036E69C: 98030483
	s_load_b128 s[4:7], s[0:1], 0x128                          // 00000036E6A0: F4080100 F8000128
	s_mulk_i32 s3, 0x48                                        // 00000036E6A8: B8030048
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000036E6AC: BF870009
	s_add_u32 s8, s0, s3                                       // 00000036E6B0: 80080300
	s_addc_u32 s9, s1, 0                                       // 00000036E6B4: 82098001
	s_clause 0x2                                               // 00000036E6B8: BF850002
	s_load_b64 s[10:11], s[8:9], 0x30                          // 00000036E6BC: F4040284 F8000030
	s_load_b32 s12, s[8:9], 0x40                               // 00000036E6C4: F4000304 F8000040
	s_load_b64 s[0:1], s[8:9], null                            // 00000036E6CC: F4040004 F8000000
	s_waitcnt lgkmcnt(0)                                       // 00000036E6D4: BF89FC07
	.long 0xd4510011                                           // 00000036E6D8: D4510011
	v_cndmask_b32_e32 v0, s10, v137, vcc_lo                    // 00000036E6DC: 0201120A
	s_and_b32 s3, s17, exec_lo                                 // 00000036E6E0: 8B037E11
	s_cselect_b32 s16, 8, 2                                    // 00000036E6E4: 98108288
	s_cselect_b32 s18, 3, 1                                    // 00000036E6E8: 98128183
	v_cvt_f32_ubyte0_e32 v1, s16                               // 00000036E6EC: 7E022210
	s_sub_i32 s2, s2, s12                                      // 00000036E6F0: 81820C02
	s_add_i32 s14, s16, -1                                     // 00000036E6F4: 810EC110
	s_and_b32 s13, s17, exec_lo                                // 00000036E6F8: 8B0D7E11
	s_cselect_b32 s13, 0, 2                                    // 00000036E6FC: 980D8280
	v_rcp_iflag_f32_e32 v3, v1                                 // 00000036E700: 7E065701
	s_ashr_i32 s19, s7, 31                                     // 00000036E704: 86139F07
	s_mov_b32 s3, 0                                            // 00000036E708: BE830080
	v_dual_mov_b32 v2, 0 :: v_dual_and_b32 v19, s14, v5        // 00000036E70C: CA240080 02120A0E
	s_lshl_b64 s[2:3], s[2:3], s13                             // 00000036E714: 84820D02
	v_lshrrev_b32_e32 v17, s18, v5                             // 00000036E718: 32220A12
	v_mov_b32_e32 v1, 0                                        // 00000036E71C: 7E020280
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000036E720: BF870195
	v_readfirstlane_b32 s12, v3                                // 00000036E724: 7E180503
	.long 0xd7001703                                           // 00000036E728: D7001703
	v_cndmask_b32_e32 v1, s2, v17, vcc_lo                      // 00000036E72C: 02022202
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000036E730: BF8704B1
	v_add_co_ci_u32_e64 v4, null, s3, 0, s23                   // 00000036E734: D5207C04 005D0003
	s_mul_f32 s15, s12, 0x4f7ffffe                             // 00000036E73C: A20FFF0C 4F7FFFFE
	s_lshr_b32 s12, s19, 27                                    // 00000036E744: 850C9B13
	s_add_u32 s12, s6, s12                                     // 00000036E748: 800C0C06
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000036E74C: BF870009
	s_cvt_u32_f32 s15, s15                                     // 00000036E750: BE8F670F
	s_addc_u32 s13, s7, 0                                      // 00000036E754: 820D8007
	s_sub_i32 s22, 0, s16                                      // 00000036E758: 81961080
	s_lshr_b64 s[20:21], s[12:13], 5                           // 00000036E75C: 8594850C
	s_mul_i32 s22, s22, s15                                    // 00000036E760: 96160F16
	s_add_i32 s12, s14, s20                                    // 00000036E764: 810C140E
	s_mul_hi_u32 s13, s15, s22                                 // 00000036E768: 968D160F
	s_abs_i32 s21, s12                                         // 00000036E76C: BE95150C
	s_add_i32 s15, s15, s13                                    // 00000036E770: 810F0D0F
	s_ashr_i32 s12, s12, 31                                    // 00000036E774: 860C9F0C
	s_mul_hi_u32 s13, s21, s15                                 // 00000036E778: 968D0F15
	v_cmp_gt_i64_e32 vcc_lo, s[10:11], v[3:4]                  // 00000036E77C: 7CA8060A
	s_mul_i32 s15, s13, s16                                    // 00000036E780: 960F100D
	v_and_b32_e32 v18, 31, v0                                  // 00000036E784: 3624009F
	s_sub_i32 s15, s21, s15                                    // 00000036E788: 818F0F15
	s_add_i32 s21, s13, 1                                      // 00000036E78C: 8115810D
	s_sub_i32 s22, s15, s16                                    // 00000036E790: 8196100F
	s_cmp_ge_u32 s15, s16                                      // 00000036E794: BF09100F
	v_cndmask_b32_e32 v3, 0, v3, vcc_lo                        // 00000036E798: 02060680
	s_cselect_b32 s13, s21, s13                                // 00000036E79C: 980D0D15
	s_cselect_b32 s15, s22, s15                                // 00000036E7A0: 980F0F16
	s_add_i32 s21, s13, 1                                      // 00000036E7A4: 8115810D
	s_cmp_ge_u32 s15, s16                                      // 00000036E7A8: BF09100F
	v_cndmask_b32_e32 v4, 0, v4, vcc_lo                        // 00000036E7AC: 02080880
	s_cselect_b32 s13, s21, s13                                // 00000036E7B0: 980D0D15
	s_lshr_b32 s14, s7, 31                                     // 00000036E7B4: 850E9F07
	s_xor_b32 s13, s13, s12                                    // 00000036E7B8: 8D0D0C0D
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000036E7BC: BF870009
	s_sub_i32 s21, s13, s12                                    // 00000036E7C0: 81950C0D
	s_add_u32 s12, s6, s14                                     // 00000036E7C4: 800C0E06
	s_addc_u32 s13, s7, 0                                      // 00000036E7C8: 820D8007
	s_lshr_b32 s22, s19, 30                                    // 00000036E7CC: 85169E13
	s_ashr_i64 s[14:15], s[12:13], 1                           // 00000036E7D0: 868E810C
	s_add_u32 s12, s6, s22                                     // 00000036E7D4: 800C1606
	s_addc_u32 s13, s7, 0                                      // 00000036E7D8: 820D8007
	s_lshr_b32 s19, s19, 28                                    // 00000036E7DC: 85139C13
	s_ashr_i64 s[12:13], s[12:13], 2                           // 00000036E7E0: 868C820C
	s_add_u32 s6, s6, s19                                      // 00000036E7E4: 80061306
	s_addc_u32 s7, s7, 0                                       // 00000036E7E8: 82078007
	.long 0xd72c0005                                           // 00000036E7EC: D72C0005
	v_cndmask_b32_e32 v0, v19, v21, vcc_lo                     // 00000036E7F0: 02002B13
	s_ashr_i64 s[6:7], s[6:7], 4                               // 00000036E7F4: 86868406
	s_add_u32 s19, s12, s14                                    // 00000036E7F8: 80130E0C
	s_addc_u32 s22, s13, s15                                   // 00000036E7FC: 82160F0D
	s_add_u32 s6, s19, s6                                      // 00000036E800: 80060613
	s_addc_u32 s7, s22, s7                                     // 00000036E804: 82070716
	s_add_u32 s6, s6, 15                                       // 00000036E808: 80068F06
	s_addc_u32 s7, s7, 0                                       // 00000036E80C: 82078007
	v_add_nc_u32_e32 v6, s21, v5                               // 00000036E810: 4A0C0A15
	s_ashr_i32 s19, s7, 31                                     // 00000036E814: 86139F07
	v_add_nc_u32_e32 v20, v5, v18                              // 00000036E818: 4A282505
	s_lshr_b32 s19, s19, 28                                    // 00000036E81C: 85139C13
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000036E820: BF870009
	s_add_u32 s6, s6, s19                                      // 00000036E824: 80061306
	s_addc_u32 s7, s7, 0                                       // 00000036E828: 82078007
	s_and_b32 s6, s6, -16                                      // 00000036E82C: 8B06D006
	.long 0xd72c0007                                           // 00000036E830: D72C0007
	v_cndmask_b32_e32 v1, s7, v3, vcc_lo                       // 00000036E834: 02020607
	v_mad_u64_u32 v[9:10], null, s6, v3, s[0:1]                // 00000036E838: D6FE7C09 00020606
	v_mov_b32_e32 v3, 0                                        // 00000036E840: 7E060280
	.long 0xd72c0008                                           // 00000036E844: D72C0008
	v_cndmask_b32_e32 v1, s6, v4, vcc_lo                       // 00000036E848: 02020806
	v_min_i32_e32 v21, s20, v6                                 // 00000036E84C: 222A0C14
	v_mov_b32_e32 v4, 0                                        // 00000036E850: 7E080280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000036E854: BF870212
	v_cmp_lt_i32_e32 vcc_lo, v20, v21                          // 00000036E858: 7C822B14
	v_add3_u32 v22, v7, v10, v8                                // 00000036E85C: D6550016 04221507
	s_and_saveexec_b32 s1, vcc_lo                              // 00000036E864: BE81206A
	s_cbranch_execz 39                                         // 00000036E868: BFA50027 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi1ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x308>
	v_lshlrev_b32_e32 v1, 4, v20                               // 00000036E86C: 30022884
	v_lshlrev_b32_e32 v4, 1, v20                               // 00000036E870: 30082881
	v_lshlrev_b32_e32 v3, 3, v20                               // 00000036E874: 30062883
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000036E878: BF870223
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000036E87C: 3404029F
	.long 0xd7000001                                           // 00000036E880: D7000001
	v_cndmask_b32_e32 v1, v9, v1, vcc_lo                       // 00000036E884: 02020309
	v_and_b32_e32 v4, -4, v4                                   // 00000036E888: 360808C4
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000036E88C: BF870214
	v_ashrrev_i32_e32 v8, 31, v3                               // 00000036E890: 3410069F
	v_add_co_ci_u32_e64 v2, null, v22, v2, s0                  // 00000036E894: D5207C02 00020516
	.long 0xd7000006                                           // 00000036E89C: D7000006
	v_cndmask_b32_e32 v0, v9, v14, vcc_lo                      // 00000036E8A0: 02001D09
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000036E8A4: BF8701A1
	v_add_co_ci_u32_e64 v7, null, s15, v22, s0                 // 00000036E8A8: D5207C07 00022C0F
	v_ashrrev_i32_e32 v12, 31, v4                              // 00000036E8B0: 3418089F
	.long 0xd700000a                                           // 00000036E8B4: D700000A
	v_cndmask_b32_e32 v0, v6, v12, vcc_lo                      // 00000036E8B8: 02001906
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000036E8BC: BF8700A1
	v_add_co_ci_u32_e64 v11, null, s13, v7, s0                 // 00000036E8C0: D5207C0B 00020E0D
	.long 0xd7000006                                           // 00000036E8C8: D7000006
	v_cndmask_b32_e32 v1, v6, v3, vcc_lo                       // 00000036E8CC: 02020706
	v_add_co_ci_u32_e64 v7, null, v7, v8, s0                   // 00000036E8D0: D5207C07 00021107
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000036E8D8: BF870094
	.long 0xd700000a                                           // 00000036E8DC: D700000A
	v_cndmask_b32_e32 v1, v10, v4, vcc_lo                      // 00000036E8E0: 0202090A
	v_add_co_ci_u32_e64 v11, null, v11, v12, s0                // 00000036E8E4: D5207C0B 0002190B
	s_clause 0x2                                               // 00000036E8EC: BF850002
	global_load_b128 v[1:4], v[1:2], off                       // 00000036E8F0: DC5E0000 017C0001
	global_load_b64 v[12:13], v[6:7], off                      // 00000036E8F8: DC560000 0C7C0006
	global_load_b32 v30, v[10:11], off                         // 00000036E900: DC520000 1E7C000A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000036E908: 8C7E017E
	s_and_saveexec_b32 s1, vcc_lo                              // 00000036E90C: BE81206A
	s_cbranch_execz 620                                        // 00000036E910: BFA5026C <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi1ELi32ELi2EEEvNS0_5LqGrpEPKtl+0xcc4>
	.long 0xd7006a17                                           // 00000036E914: D7006A17
	v_cndmask_b32_e32 v0, v9, v14, vcc_lo                      // 00000036E918: 02001D09
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000036E91C: BF8700D1
	v_add_co_ci_u32_e64 v24, null, s15, v22, vcc_lo            // 00000036E920: D5207C18 01AA2C0F
	s_waitcnt vmcnt(0)                                         // 00000036E928: BF8903F7
	v_dual_mov_b32 v31, v30 :: v_dual_lshlrev_b32 v6, 5, v18   // 00000036E92C: CA22011E 1F062485
	v_dual_mov_b32 v16, 0 :: v_dual_add_nc_u32 v7, 32, v20     // 00000036E934: CA200080 100628A0
	.long 0xd7006a19                                           // 00000036E93C: D7006A19
	v_cndmask_b32_e32 v0, v23, v12, vcc_lo                     // 00000036E940: 02001917
	v_add_co_ci_u32_e64 v26, null, s13, v24, vcc_lo            // 00000036E944: D5207C1A 01AA300D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000036E94C: BF870214
	v_lshl_add_u32 v10, v5, 5, v6                              // 00000036E950: D646000A 04190B05
	v_lshlrev_b32_e32 v27, 4, v7                               // 00000036E958: 30360E84
	v_lshlrev_b32_e32 v28, 3, v7                               // 00000036E95C: 30380E83
	v_lshlrev_b32_e32 v29, 1, v7                               // 00000036E960: 303A0E81
	s_mov_b32 s6, 0                                            // 00000036E964: BE860080
	s_branch 558                                               // 00000036E968: BFA0022E <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi1ELi32ELi2EEEvNS0_5LqGrpEPKtl+0xc24>
	s_or_b32 exec_lo, exec_lo, s7                              // 00000036E96C: 8C7E077E
	v_ashrrev_i32_e32 v11, 31, v10                             // 00000036E970: 3416149F
	v_lshlrev_b32_e32 v48, 2, v12                              // 00000036E974: 30601882
	v_lshrrev_b32_e32 v49, 4, v1                               // 00000036E978: 32620284
	v_lshrrev_b32_e32 v50, 8, v1                               // 00000036E97C: 32640288
	v_lshrrev_b32_e32 v51, 2, v12                              // 00000036E980: 32661882
	.long 0xd73c0020                                           // 00000036E984: D73C0020
	v_cndmask_b32_e32 v1, 1, v10, vcc_lo                       // 00000036E988: 02021481
	v_lshlrev_b32_e32 v11, 4, v12                              // 00000036E98C: 30161884
	v_and_b32_e32 v48, 48, v48                                 // 00000036E990: 366060B0
	v_and_b32_e32 v52, 48, v12                                 // 00000036E994: 366818B0
	v_lshrrev_b32_e32 v53, 12, v1                              // 00000036E998: 326A028C
	v_and_b32_e32 v51, 48, v51                                 // 00000036E99C: 366666B0
	.long 0xd700002c                                           // 00000036E9A0: D700002C
	v_cndmask_b32_e32 v1, s4, v32, vcc_lo                      // 00000036E9A4: 02024004
	s_delay_alu instid0(VALU_DEP_1)                            // 00000036E9A8: BF870001
	v_add_co_ci_u32_e64 v45, null, s5, v33, s0                 // 00000036E9AC: D5207C2D 00024205
	v_and_b32_e32 v11, 48, v11                                 // 00000036E9B4: 361616B0
	v_and_or_b32 v48, v49, 15, v48                             // 00000036E9B8: D6570030 04C11F31
	v_and_or_b32 v49, v50, 15, v52                             // 00000036E9C0: D6570031 04D11F32
	s_clause 0x3                                               // 00000036E9C8: BF850003
	global_load_b128 v[32:35], v[44:45], off                   // 00000036E9CC: DC5E0000 207C002C
	global_load_b128 v[36:39], v[44:45], off offset:16         // 00000036E9D4: DC5E0010 247C002C
	global_load_b128 v[40:43], v[44:45], off offset:32         // 00000036E9DC: DC5E0020 287C002C
	global_load_b128 v[44:47], v[44:45], off offset:48         // 00000036E9E4: DC5E0030 2C7C002C
	v_and_or_b32 v50, v53, 15, v51                             // 00000036E9EC: D6570032 04CD1F35
	v_and_or_b32 v11, v1, 15, v11                              // 00000036E9F4: D657000B 042D1F01
	v_cvt_f32_ubyte0_e32 v48, v48                              // 00000036E9FC: 7E602330
	v_cvt_f32_ubyte0_e32 v49, v49                              // 00000036EA00: 7E622331
	.long 0x7f6a3880                                           // 00000036EA04: 7F6A3880
	v_cvt_f32_ubyte0_e32 v50, v50                              // 00000036EA08: 7E642332
	v_cvt_f32_ubyte0_e32 v11, v11                              // 00000036EA0C: 7E16230B
	v_fma_mix_f32 v48, v48, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000036EA10: CC206030 147A3D30
	v_fma_mix_f32 v49, v49, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000036EA18: CC206031 147A3D31
	v_lshrrev_b32_e32 v55, 10, v12                             // 00000036EA20: 326E188A
	v_fma_mix_f32 v50, v50, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000036EA24: CC206032 147A3D32
	v_fma_mix_f32 v11, v11, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000036EA2C: CC20600B 147A3D0B
	v_bfe_u32 v52, v48, 16, 1                                  // 00000036EA34: D6100034 02052130
	v_lshrrev_b32_e32 v60, 22, v12                             // 00000036EA3C: 32781896
	v_lshrrev_b32_e32 v59, 20, v2                              // 00000036EA40: 32760494
	v_bfe_u32 v54, v50, 16, 1                                  // 00000036EA44: D6100036 02052132
	v_bfe_u32 v51, v11, 16, 1                                  // 00000036EA4C: D6100033 0205210B
	v_add3_u32 v48, v48, v52, 0x7fff                           // 00000036EA54: D6550030 03FE6930 00007FFF
	v_lshrrev_b32_e32 v52, 20, v1                              // 00000036EA60: 32680294
	v_lshrrev_b32_e32 v61, 24, v2                              // 00000036EA64: 327A0498
	v_add3_u32 v50, v50, v54, 0x7fff                           // 00000036EA68: D6550032 03FE6D32 00007FFF
	v_add3_u32 v11, v11, v51, 0x7fff                           // 00000036EA74: D655000B 03FE670B 00007FFF
	v_bfe_u32 v51, v49, 16, 1                                  // 00000036EA80: D6100033 02052131
	v_lshrrev_b32_e32 v54, 24, v1                              // 00000036EA88: 326C0298
	v_lshlrev_b32_e32 v64, 4, v13                              // 00000036EA8C: 30801A84
	v_and_b32_e32 v60, 48, v60                                 // 00000036EA90: 367878B0
	.long 0x7e6a398b                                           // 00000036EA94: 7E6A398B
	v_add3_u32 v11, v49, v51, 0x7fff                           // 00000036EA98: D655000B 03FE6731 00007FFF
	v_lshrrev_b32_e32 v49, 4, v12                              // 00000036EAA4: 32621884
	v_lshrrev_b32_e32 v51, 8, v12                              // 00000036EAA8: 32661888
	v_lshrrev_b32_e32 v57, 14, v12                             // 00000036EAAC: 3272188E
	v_and_or_b32 v48, 0xffff0000, v48, v53                     // 00000036EAB0: D6570030 04D660FF FFFF0000
	.long 0x7e6a398b                                           // 00000036EABC: 7E6A398B
	v_lshrrev_b32_e32 v11, 6, v12                              // 00000036EAC0: 32161886
	v_and_b32_e32 v49, 48, v49                                 // 00000036EAC4: 366262B0
	v_and_b32_e32 v51, 48, v51                                 // 00000036EAC8: 366666B0
	v_lshrrev_b32_e32 v62, 28, v2                              // 00000036EACC: 327C049C
	v_and_or_b32 v50, 0xffff0000, v50, v53                     // 00000036EAD0: D6570032 04D664FF FFFF0000
	.long 0x7e6a3981                                           // 00000036EADC: 7E6A3981
	v_and_b32_e32 v11, 48, v11                                 // 00000036EAE0: 361616B0
	v_lshrrev_b32_e32 v1, 28, v1                               // 00000036EAE4: 3202029C
	v_and_or_b32 v51, v54, 15, v51                             // 00000036EAE8: D6570033 04CD1F36
	v_lshlrev_b32_e32 v66, 2, v13                              // 00000036EAF0: 30841A82
	v_and_or_b32 v49, v53, 15, v49                             // 00000036EAF4: D6570031 04C51F35
	v_and_or_b32 v11, v52, 15, v11                             // 00000036EAFC: D657000B 042D1F34
	v_and_or_b32 v1, v55, 48, v1                               // 00000036EB04: D6570001 04056137
	v_cvt_f32_ubyte0_e32 v51, v51                              // 00000036EB0C: 7E662333
	v_lshrrev_b32_e32 v52, 12, v12                             // 00000036EB10: 3268188C
	v_cvt_f32_ubyte0_e32 v49, v49                              // 00000036EB14: 7E622331
	v_cvt_f32_ubyte0_e32 v11, v11                              // 00000036EB18: 7E16230B
	v_cvt_f32_ubyte0_e32 v1, v1                                // 00000036EB1C: 7E022301
	v_fma_mix_f32 v51, v51, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000036EB20: CC206033 147A3D33
	v_and_or_b32 v59, v59, 15, v60                             // 00000036EB28: D657003B 04F11F3B
	v_fma_mix_f32 v49, v49, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000036EB30: CC206031 147A3D31
	v_fma_mix_f32 v11, v11, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000036EB38: CC20600B 147A3D0B
	v_fma_mix_f32 v1, v1, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000036EB40: CC206001 147A3D01
	v_lshrrev_b32_e32 v65, 4, v3                               // 00000036EB48: 32820684
	v_and_b32_e32 v67, 48, v13                                 // 00000036EB4C: 36861AB0
	v_bfe_u32 v54, v49, 16, 1                                  // 00000036EB50: D6100036 02052131
	v_bfe_u32 v56, v11, 16, 1                                  // 00000036EB58: D6100038 0205210B
	v_bfe_u32 v58, v1, 16, 1                                   // 00000036EB60: D610003A 02052101
	v_cvt_f32_ubyte0_e32 v59, v59                              // 00000036EB68: 7E76233B
	v_lshrrev_b32_e32 v68, 12, v3                              // 00000036EB6C: 3288068C
	v_add3_u32 v49, v49, v54, 0x7fff                           // 00000036EB70: D6550031 03FE6D31 00007FFF
	v_bfe_u32 v54, v51, 16, 1                                  // 00000036EB7C: D6100036 02052133
	v_add3_u32 v11, v11, v56, 0x7fff                           // 00000036EB84: D655000B 03FE710B 00007FFF
	v_add3_u32 v1, v1, v58, 0x7fff                             // 00000036EB90: D6550001 03FE7501 00007FFF
	v_lshrrev_b32_e32 v56, 18, v12                             // 00000036EB9C: 32701892
	.long 0x7e6a39b1                                           // 00000036EBA0: 7E6A39B1
	v_add3_u32 v49, v51, v54, 0x7fff                           // 00000036EBA4: D6550031 03FE6D33 00007FFF
	v_lshrrev_b32_e32 v51, 8, v2                               // 00000036EBB0: 32660488
	v_lshrrev_b32_e32 v54, 20, v12                             // 00000036EBB4: 326C1894
	v_and_b32_e32 v56, 48, v56                                 // 00000036EBB8: 367070B0
	v_and_or_b32 v11, 0xffff0000, v11, v53                     // 00000036EBBC: D657000B 04D616FF FFFF0000
	.long 0x7e6a39b1                                           // 00000036EBC8: 7E6A39B1
	v_lshrrev_b32_e32 v49, 12, v2                              // 00000036EBCC: 3262048C
	v_lshrrev_b32_e32 v58, 24, v12                             // 00000036EBD0: 32741898
	v_and_b32_e32 v54, 48, v54                                 // 00000036EBD4: 366C6CB0
	v_fma_mix_f32 v59, v59, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000036EBD8: CC20603B 147A3D3B
	v_and_or_b32 v1, 0xffff0000, v1, v53                       // 00000036EBE0: D6570001 04D602FF FFFF0000
	.long 0x7e6a398c                                           // 00000036EBEC: 7E6A398C
	v_and_or_b32 v49, v49, 15, v56                             // 00000036EBF0: D6570031 04E11F31
	v_and_b32_e32 v58, 48, v58                                 // 00000036EBF8: 367474B0
	v_lshrrev_b32_e32 v12, 26, v12                             // 00000036EBFC: 3218189A
	v_lshrrev_b32_e32 v56, 2, v13                              // 00000036EC00: 32701A82
	v_and_b32_e32 v63, 48, v53                                 // 00000036EC04: 367E6AB0
	v_cvt_f32_ubyte0_e32 v49, v49                              // 00000036EC08: 7E622331
	v_and_or_b32 v58, v61, 15, v58                             // 00000036EC0C: D657003A 04E91F3D
	v_and_or_b32 v12, v12, 48, v62                             // 00000036EC14: D657000C 04F9610C
	v_and_b32_e32 v62, 48, v66                                 // 00000036EC1C: 367C84B0
	v_and_or_b32 v51, v51, 15, v63                             // 00000036EC20: D6570033 04FD1F33
	v_fma_mix_f32 v49, v49, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000036EC28: CC206031 147A3D31
	v_lshrrev_b32_e32 v63, 8, v3                               // 00000036EC30: 327E0688
	v_cvt_f32_ubyte0_e32 v58, v58                              // 00000036EC34: 7E74233A
	v_and_b32_e32 v56, 48, v56                                 // 00000036EC38: 367070B0
	v_cvt_f32_ubyte0_e32 v51, v51                              // 00000036EC3C: 7E662333
	v_bfe_u32 v78, v49, 16, 1                                  // 00000036EC40: D610004E 02052131
	v_and_or_b32 v63, v63, 15, v67                             // 00000036EC48: D657003F 050D1F3F
	v_cvt_f32_ubyte0_e32 v12, v12                              // 00000036EC50: 7E18230C
	v_and_or_b32 v60, v65, 15, v62                             // 00000036EC54: D657003C 04F91F41
	v_fma_mix_f32 v51, v51, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000036EC5C: CC206033 147A3D33
	v_add3_u32 v49, v49, v78, 0x7fff                           // 00000036EC64: D6550031 03FE9D31 00007FFF
	v_fma_mix_f32 v58, v58, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000036EC70: CC20603A 147A3D3A
	v_and_or_b32 v56, v68, 15, v56                             // 00000036EC78: D6570038 04E11F44
	v_cvt_f32_ubyte0_e32 v61, v63                              // 00000036EC80: 7E7A233F
	v_bfe_u32 v74, v51, 16, 1                                  // 00000036EC84: D610004A 02052133
	v_fma_mix_f32 v12, v12, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000036EC8C: CC20600C 147A3D0C
	v_cvt_f32_ubyte0_e32 v60, v60                              // 00000036EC94: 7E78233C
	v_cvt_f32_ubyte0_e32 v56, v56                              // 00000036EC98: 7E702338
	v_fma_mix_f32 v61, v61, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000036EC9C: CC20603D 147A3D3D
	v_add3_u32 v51, v51, v74, 0x7fff                           // 00000036ECA4: D6550033 03FE9533 00007FFF
	v_bfe_u32 v63, v12, 16, 1                                  // 00000036ECB0: D610003F 0205210C
	v_fma_mix_f32 v60, v60, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000036ECB8: CC20603C 147A3D3C
	v_fma_mix_f32 v56, v56, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000036ECC0: CC206038 147A3D38
	v_lshrrev_b32_e32 v70, 4, v13                              // 00000036ECC8: 328C1A84
	.long 0x7e6a39b3                                           // 00000036ECCC: 7E6A39B3
	v_and_b32_e32 v51, 48, v64                                 // 00000036ECD0: 366680B0
	v_bfe_u32 v64, v59, 16, 1                                  // 00000036ECD4: D6100040 0205213B
	v_add3_u32 v12, v12, v63, 0x7fff                           // 00000036ECDC: D655000C 03FE7F0C 00007FFF
	v_lshrrev_b32_e32 v69, 8, v13                              // 00000036ECE8: 328A1A88
	v_and_or_b32 v49, 0xffff0000, v49, v53                     // 00000036ECEC: D6570031 04D662FF FFFF0000
	.long 0x7e6a3982                                           // 00000036ECF8: 7E6A3982
	v_and_or_b32 v51, v3, 15, v51                              // 00000036ECFC: D6570033 04CD1F03
	v_add3_u32 v59, v59, v64, 0x7fff                           // 00000036ED04: D655003B 03FE813B 00007FFF
	v_lshrrev_b32_e32 v72, 6, v13                              // 00000036ED10: 32901A86
	v_and_b32_e32 v63, 48, v70                                 // 00000036ED14: 367E8CB0
	v_and_or_b32 v54, v53, 15, v54                             // 00000036ED18: D6570036 04D91F35
	v_cvt_f32_ubyte0_e32 v51, v51                              // 00000036ED20: 7E662333
	v_lshrrev_b32_e32 v71, 20, v3                              // 00000036ED24: 328E0694
	v_lshrrev_b32_e32 v73, 24, v3                              // 00000036ED28: 32920698
	v_and_b32_e32 v66, 48, v72                                 // 00000036ED2C: 368490B0
	v_cvt_f32_ubyte0_e32 v54, v54                              // 00000036ED30: 7E6C2336
	v_fma_mix_f32 v51, v51, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000036ED34: CC206033 147A3D33
	v_and_b32_e32 v67, 48, v69                                 // 00000036ED3C: 36868AB0
	v_lshrrev_b32_e32 v76, 28, v3                              // 00000036ED40: 3298069C
	v_lshrrev_b32_e32 v77, 10, v13                             // 00000036ED44: 329A1A8A
	v_fma_mix_f32 v54, v54, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000036ED48: CC206036 147A3D36
	v_and_or_b32 v66, v71, 15, v66                             // 00000036ED50: D6570042 05091F47
	v_and_or_b32 v67, v73, 15, v67                             // 00000036ED58: D6570043 050D1F49
	v_and_b32_e32 v52, 48, v52                                 // 00000036ED60: 366868B0
	v_and_or_b32 v71, v77, 48, v76                             // 00000036ED64: D6570047 0531614D
	v_bfe_u32 v62, v54, 16, 1                                  // 00000036ED6C: D610003E 02052136
	v_cvt_f32_ubyte0_e32 v66, v66                              // 00000036ED74: 7E842342
	v_cvt_f32_ubyte0_e32 v67, v67                              // 00000036ED78: 7E862343
	v_lshrrev_b32_e32 v55, 4, v2                               // 00000036ED7C: 326E0484
	v_cvt_f32_ubyte0_e32 v71, v71                              // 00000036ED80: 7E8E2347
	v_add3_u32 v54, v54, v62, 0x7fff                           // 00000036ED84: D6550036 03FE7D36 00007FFF
	v_bfe_u32 v62, v58, 16, 1                                  // 00000036ED90: D610003E 0205213A
	v_fma_mix_f32 v66, v66, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000036ED98: CC206042 147A3D42
	v_fma_mix_f32 v67, v67, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000036EDA0: CC206043 147A3D43
	v_fma_mix_f32 v71, v71, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000036EDA8: CC206047 147A3D47
	.long 0x7e6a39b6                                           // 00000036EDB0: 7E6A39B6
	v_add3_u32 v54, v58, v62, 0x7fff                           // 00000036EDB4: D6550036 03FE7D3A 00007FFF
	v_bfe_u32 v58, v51, 16, 1                                  // 00000036EDC0: D610003A 02052133
	v_bfe_u32 v62, v60, 16, 1                                  // 00000036EDC8: D610003E 0205213C
	v_bfe_u32 v76, v66, 16, 1                                  // 00000036EDD0: D610004C 02052142
	v_and_or_b32 v59, 0xffff0000, v59, v53                     // 00000036EDD8: D657003B 04D676FF FFFF0000
	.long 0x7e6a39b6                                           // 00000036EDE4: 7E6A39B6
	v_add3_u32 v51, v51, v58, 0x7fff                           // 00000036EDE8: D6550033 03FE7533 00007FFF
	v_bfe_u32 v54, v61, 16, 1                                  // 00000036EDF4: D6100036 0205213D
	v_bfe_u32 v58, v56, 16, 1                                  // 00000036EDFC: D610003A 02052138
	v_add3_u32 v60, v60, v62, 0x7fff                           // 00000036EE04: D655003C 03FE7D3C 00007FFF
	v_and_or_b32 v12, 0xffff0000, v12, v53                     // 00000036EE10: D657000C 04D618FF FFFF0000
	.long 0x7e6a39b3                                           // 00000036EE1C: 7E6A39B3
	v_add3_u32 v51, v61, v54, 0x7fff                           // 00000036EE20: D6550033 03FE6D3D 00007FFF
	v_add3_u32 v56, v56, v58, 0x7fff                           // 00000036EE2C: D6550038 03FE7538 00007FFF
	v_bfe_u32 v77, v71, 16, 1                                  // 00000036EE38: D610004D 02052147
	v_add3_u32 v66, v66, v76, 0x7fff                           // 00000036EE40: D6550042 03FE9942 00007FFF
	v_and_or_b32 v58, 0xffff0000, v60, v53                     // 00000036EE4C: D657003A 04D678FF FFFF0000
	.long 0x7e6a39b3                                           // 00000036EE58: 7E6A39B3
	v_and_b32_e32 v57, 48, v57                                 // 00000036EE5C: 367272B0
	v_add3_u32 v71, v71, v77, 0x7fff                           // 00000036EE60: D6550047 03FE9B47 00007FFF
	v_and_or_b32 v2, v2, 15, v52                               // 00000036EE6C: D6570002 04D11F02
	v_lshrrev_b32_e32 v75, 12, v13                             // 00000036EE74: 32961A8C
	v_and_or_b32 v56, 0xffff0000, v56, v53                     // 00000036EE78: D6570038 04D670FF FFFF0000
	.long 0x7e6a3983                                           // 00000036EE84: 7E6A3983
	v_lshrrev_b32_e32 v51, 14, v13                             // 00000036EE88: 32661A8E
	v_lshrrev_b32_e32 v62, 20, v13                             // 00000036EE8C: 327C1A94
	v_lshrrev_b32_e32 v64, 18, v13                             // 00000036EE90: 32801A92
	v_lshrrev_b32_e32 v65, 24, v13                             // 00000036EE94: 32821A98
	v_and_or_b32 v63, v53, 15, v63                             // 00000036EE98: D657003F 04FD1F35
	v_lshrrev_b32_e32 v69, 22, v13                             // 00000036EEA0: 328A1A96
	v_lshrrev_b32_e32 v74, 26, v13                             // 00000036EEA4: 32941A9A
	v_cvt_f32_ubyte0_e32 v2, v2                                // 00000036EEA8: 7E042302
	v_lshrrev_b32_e32 v60, 8, v4                               // 00000036EEAC: 32780888
	v_cvt_f32_ubyte0_e32 v63, v63                              // 00000036EEB0: 7E7E233F
	v_lshrrev_b32_e32 v3, 12, v4                               // 00000036EEB4: 3206088C
	v_and_b32_e32 v54, 15, v4                                  // 00000036EEB8: 366C088F
	v_fma_mix_f32 v2, v2, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000036EEBC: CC206002 147A3D02
	v_lshrrev_b32_e32 v61, 4, v4                               // 00000036EEC4: 327A0884
	v_fma_mix_f32 v63, v63, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000036EEC8: CC20603F 147A3D3F
	v_lshrrev_b32_e32 v72, 28, v4                              // 00000036EED0: 3290089C
	v_and_or_b32 v54, v75, 48, v54                             // 00000036EED4: D6570036 04D9614B
	v_and_b32_e32 v51, 48, v51                                 // 00000036EEDC: 366666B0
	v_lshrrev_b32_e32 v68, 20, v4                              // 00000036EEE0: 32880894
	v_bfe_u32 v73, v63, 16, 1                                  // 00000036EEE4: D6100049 0205213F
	v_lshrrev_b32_e32 v70, 24, v4                              // 00000036EEEC: 328C0898
	v_and_b32_e32 v65, 48, v65                                 // 00000036EEF0: 368282B0
	.long 0x7f6839b5                                           // 00000036EEF4: 7F6839B5
	v_add_nc_u32_e32 v27, 0x200, v27                           // 00000036EEF8: 4A3636FF 00000200
	v_add3_u32 v63, v63, v73, 0x7fff                           // 00000036EF00: D655003F 03FE933F 00007FFF
	v_bfe_u32 v73, v67, 16, 1                                  // 00000036EF0C: D6100049 02052143
	v_add_nc_u32_e32 v28, 0x100, v28                           // 00000036EF14: 4A3838FF 00000100
	v_add_nc_u32_e32 v29, 64, v29                              // 00000036EF1C: 4A3A3AC0
	v_add_nc_u32_e32 v10, 0x400, v10                           // 00000036EF20: 4A1414FF 00000400
	.long 0x7e6a39bf                                           // 00000036EF28: 7E6A39BF
	v_add3_u32 v63, v67, v73, 0x7fff                           // 00000036EF2C: D655003F 03FE9343 00007FFF
	.long 0x7f8639b5                                           // 00000036EF38: 7F8639B5
	s_and_b32 s0, exec_lo, vcc_lo                              // 00000036EF3C: 8B006A7E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000036EF40: BF870193
	v_and_or_b32 v66, 0xffff0000, v66, v53                     // 00000036EF44: D6570042 04D684FF FFFF0000
	.long 0x7e6a39bf                                           // 00000036EF50: 7E6A39BF
	s_or_b32 s6, s0, s6                                        // 00000036EF54: 8C060600
	s_delay_alu instid0(VALU_DEP_1)                            // 00000036EF58: BF870001
	v_and_or_b32 v63, 0xffff0000, v71, v53                     // 00000036EF5C: D657003F 04D68EFF FFFF0000
	.long 0x7e6a398d                                           // 00000036EF68: 7E6A398D
	v_and_or_b32 v13, v55, 15, v57                             // 00000036EF6C: D657000D 04E51F37
	v_and_b32_e32 v57, 48, v62                                 // 00000036EF74: 36727CB0
	v_and_b32_e32 v55, 48, v64                                 // 00000036EF78: 366E80B0
	v_and_b32_e32 v64, 48, v69                                 // 00000036EF7C: 36808AB0
	v_and_b32_e32 v62, 48, v53                                 // 00000036EF80: 367C6AB0
	v_cvt_f32_ubyte0_e32 v13, v13                              // 00000036EF84: 7E1A230D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000036EF88: BF870194
	v_and_or_b32 v3, v3, 15, v55                               // 00000036EF8C: D6570003 04DD1F03
	v_and_or_b32 v60, v60, 15, v62                             // 00000036EF94: D657003C 04F91F3C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000036EF9C: BF870223
	v_fma_mix_f32 v13, v13, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000036EFA0: CC20600D 147A3D0D
	v_bfe_u32 v62, v2, 16, 1                                   // 00000036EFA8: D610003E 02052102
	v_cvt_f32_ubyte0_e32 v3, v3                                // 00000036EFB0: 7E062303
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000036EFB4: BF870193
	v_bfe_u32 v55, v13, 16, 1                                  // 00000036EFB8: D6100037 0205210D
	v_add3_u32 v2, v2, v62, 0x7fff                             // 00000036EFC0: D6550002 03FE7D02 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000036EFCC: BF870193
	v_fma_mix_f32 v3, v3, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000036EFD0: CC206003 147A3D03
	v_add3_u32 v13, v13, v55, 0x7fff                           // 00000036EFD8: D655000D 03FE6F0D 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000036EFE4: BF870093
	.long 0x7e863982                                           // 00000036EFE8: 7E863982
	v_and_or_b32 v13, 0xffff0000, v13, v67                     // 00000036EFEC: D657000D 050E1AFF FFFF0000
	s_waitcnt vmcnt(3)                                         // 00000036EFF8: BF890FF7
	v_dot2_f32_bf16 v32, v32, v48, 0                           // 00000036EFFC: CC1A4020 1A026120
	v_cvt_f32_ubyte0_e32 v48, v60                              // 00000036F004: 7E60233C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000036F008: BF870112
	v_dot2_f32_bf16 v32, v33, v50, v32                         // 00000036F00C: CC1A4020 1C826521
	v_fma_mix_f32 v33, v48, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000036F014: CC206021 147A3D30
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000036F01C: BF870112
	v_dot2_f32_bf16 v2, v34, v11, v32                          // 00000036F020: CC1A4002 1C821722
	v_bfe_u32 v11, v33, 16, 1                                  // 00000036F028: D610000B 02052121
	v_and_or_b32 v32, v74, 48, v72                             // 00000036F030: D6570020 0521614A
	v_cvt_f32_ubyte0_e32 v34, v54                              // 00000036F038: 7E442336
	s_delay_alu instid0(VALU_DEP_4)                            // 00000036F03C: BF870004
	v_dot2_f32_bf16 v1, v35, v1, v2                            // 00000036F040: CC1A4001 1C0A0323
	v_bfe_u32 v2, v3, 16, 1                                    // 00000036F048: D6100002 02052103
	v_add3_u32 v11, v33, v11, 0x7fff                           // 00000036F050: D655000B 03FE1721 00007FFF
	v_and_or_b32 v33, v61, 15, v51                             // 00000036F05C: D6570021 04CD1F3D
	s_waitcnt vmcnt(2)                                         // 00000036F064: BF890BF7
	v_dot2_f32_bf16 v1, v36, v13, v1                           // 00000036F068: CC1A4001 1C061B24
	v_add3_u32 v2, v3, v2, 0x7fff                              // 00000036F070: D6550002 03FE0503 00007FFF
	.long 0x7e6a398b                                           // 00000036F07C: 7E6A398B
	v_cvt_f32_ubyte0_e32 v13, v32                              // 00000036F080: 7E1A2320
	v_cvt_f32_ubyte0_e32 v32, v33                              // 00000036F084: 7E402321
	v_dot2_f32_bf16 v1, v37, v49, v1                           // 00000036F088: CC1A4001 1C066325
	v_and_or_b32 v3, v68, 15, v64                              // 00000036F090: D6570003 05011F44
	v_and_or_b32 v2, 0xffff0000, v2, v53                       // 00000036F098: D6570002 04D604FF FFFF0000
	.long 0x7e6a3984                                           // 00000036F0A4: 7E6A3984
	v_fma_mix_f32 v4, v34, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000036F0A8: CC206004 147A3D22
	v_dot2_f32_bf16 v1, v38, v59, v1                           // 00000036F0B0: CC1A4001 1C067726
	v_and_or_b32 v11, v70, 15, v65                             // 00000036F0B8: D657000B 05051F46
	v_fma_mix_f32 v32, v32, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000036F0C0: CC206020 147A3D20
	v_and_or_b32 v33, v53, 15, v57                             // 00000036F0C8: D6570021 04E51F35
	v_cvt_f32_ubyte0_e32 v3, v3                                // 00000036F0D0: 7E062303
	v_dot2_f32_bf16 v1, v39, v12, v1                           // 00000036F0D4: CC1A4001 1C061927
	v_fma_mix_f32 v12, v13, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000036F0DC: CC20600C 147A3D0D
	v_bfe_u32 v13, v4, 16, 1                                   // 00000036F0E4: D610000D 02052104
	v_cvt_f32_ubyte0_e32 v33, v33                              // 00000036F0EC: 7E422321
	v_cvt_f32_ubyte0_e32 v11, v11                              // 00000036F0F0: 7E16230B
	s_waitcnt vmcnt(1)                                         // 00000036F0F4: BF8907F7
	v_dot2_f32_bf16 v1, v40, v58, v1                           // 00000036F0F8: CC1A4001 1C067528
	v_fma_mix_f32 v3, v3, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000036F100: CC206003 147A3D03
	v_add3_u32 v4, v4, v13, 0x7fff                             // 00000036F108: D6550004 03FE1B04 00007FFF
	v_fma_mix_f32 v13, v33, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000036F114: CC20600D 147A3D21
	v_bfe_u32 v33, v32, 16, 1                                  // 00000036F11C: D6100021 02052120
	v_dot2_f32_bf16 v1, v41, v56, v1                           // 00000036F124: CC1A4001 1C067129
	v_fma_mix_f32 v11, v11, v30, v30 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000036F12C: CC20600B 147A3D0B
	.long 0x7e683984                                           // 00000036F134: 7E683984
	v_bfe_u32 v4, v13, 16, 1                                   // 00000036F138: D6100004 0205210D
	v_add3_u32 v30, v32, v33, 0x7fff                           // 00000036F140: D655001E 03FE4320 00007FFF
	v_dot2_f32_bf16 v1, v42, v66, v1                           // 00000036F14C: CC1A4001 1C06852A
	v_bfe_u32 v32, v3, 16, 1                                   // 00000036F154: D6100020 02052103
	v_bfe_u32 v33, v11, 16, 1                                  // 00000036F15C: D6100021 0205210B
	v_add3_u32 v4, v13, v4, 0x7fff                             // 00000036F164: D6550004 03FE090D 00007FFF
	v_and_or_b32 v13, 0xffff0000, v30, v52                     // 00000036F170: D657000D 04D23CFF FFFF0000
	v_dot2_f32_bf16 v1, v43, v63, v1                           // 00000036F17C: CC1A4001 1C067F2B
	v_bfe_u32 v30, v12, 16, 1                                  // 00000036F184: D610001E 0205210C
	v_add3_u32 v3, v3, v32, 0x7fff                             // 00000036F18C: D6550003 03FE4103 00007FFF
	.long 0x7e6a3984                                           // 00000036F198: 7E6A3984
	v_add3_u32 v4, v11, v33, 0x7fff                            // 00000036F19C: D6550004 03FE430B 00007FFF
	s_waitcnt vmcnt(0)                                         // 00000036F1A8: BF8903F7
	v_dot2_f32_bf16 v1, v44, v13, v1                           // 00000036F1AC: CC1A4001 1C061B2C
	v_add3_u32 v11, v12, v30, 0x7fff                           // 00000036F1B4: D655000B 03FE3D0C 00007FFF
	v_mov_b32_e32 v12, v14                                     // 00000036F1C0: 7E18030E
	v_and_or_b32 v3, 0xffff0000, v3, v53                       // 00000036F1C4: D6570003 04D606FF FFFF0000
	.long 0x7e6a3984                                           // 00000036F1D0: 7E6A3984
	v_dot2_f32_bf16 v1, v45, v2, v1                            // 00000036F1D4: CC1A4001 1C06052D
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v13, v15           // 00000036F1DC: CA100106 020C010F
	v_mov_b32_e32 v30, v31                                     // 00000036F1E4: 7E3C031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000036F1E8: BF870214
	v_and_or_b32 v4, 0xffff0000, v11, v53                      // 00000036F1EC: D6570004 04D616FF FFFF0000
	v_dot2_f32_bf16 v1, v46, v3, v1                            // 00000036F1F8: CC1A4001 1C06072E
	v_mov_b32_e32 v3, v7                                       // 00000036F200: 7E060307
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000036F204: BF870122
	v_dot2_f32_bf16 v1, v47, v4, v1                            // 00000036F208: CC1A4001 1C06092F
	v_mov_b32_e32 v4, v8                                       // 00000036F210: 7E080308
	v_dual_add_f32 v16, v16, v1 :: v_dual_mov_b32 v1, v5       // 00000036F214: C9100310 10000105
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000036F21C: 917E067E
	s_cbranch_execz 39                                         // 00000036F220: BFA50027 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi1ELi32ELi2EEEvNS0_5LqGrpEPKtl+0xcc0>
	s_delay_alu instid0(VALU_DEP_1)                            // 00000036F224: BF870001
	v_dual_mov_b32 v5, v1 :: v_dual_add_nc_u32 v20, 32, v20    // 00000036F228: CA200101 051428A0
	v_dual_mov_b32 v6, v2 :: v_dual_mov_b32 v7, v3             // 00000036F230: CA100102 06060103
	v_dual_mov_b32 v8, v4 :: v_dual_mov_b32 v15, v13           // 00000036F238: CA100104 080E010D
	v_mov_b32_e32 v14, v12                                     // 00000036F240: 7E1C030C
	s_mov_b32 s7, exec_lo                                      // 00000036F244: BE87007E
	v_cmp_ge_i32_e32 vcc_lo, v20, v21                          // 00000036F248: 7C8C2B14
	.long 0xd4c1007e                                           // 00000036F24C: D4C1007E
	v_cndmask_b32_e32 v1, v20, v21, vcc_lo                     // 00000036F250: 02022B14
	s_cbranch_execz 64965                                      // 00000036F254: BFA5FDC5 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi1ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x36c>
	v_and_b32_e32 v7, -4, v29                                  // 00000036F258: 360E3AC4
	v_ashrrev_i32_e32 v6, 31, v27                              // 00000036F25C: 340C369F
	v_ashrrev_i32_e32 v8, 31, v28                              // 00000036F260: 3410389F
	.long 0xd7000005                                           // 00000036F264: D7000005
	v_cndmask_b32_e32 v1, v9, v27, vcc_lo                      // 00000036F268: 02023709
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000036F26C: BF870214
	v_ashrrev_i32_e32 v11, 31, v7                              // 00000036F270: 34160E9F
	v_add_co_ci_u32_e64 v6, null, v22, v6, s0                  // 00000036F274: D5207C06 00020D16
	.long 0xd700000e                                           // 00000036F27C: D700000E
	v_cndmask_b32_e32 v1, v23, v28, vcc_lo                     // 00000036F280: 02023917
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000036F284: BF8700A1
	v_add_co_ci_u32_e64 v15, null, v24, v8, s0                 // 00000036F288: D5207C0F 00021118
	.long 0xd700001f                                           // 00000036F290: D700001F
	v_cndmask_b32_e32 v1, v25, v7, vcc_lo                      // 00000036F294: 02020F19
	v_add_co_ci_u32_e64 v32, null, v26, v11, s0                // 00000036F298: D5207C20 0002171A
	s_clause 0x2                                               // 00000036F2A0: BF850002
	global_load_b128 v[5:8], v[5:6], off                       // 00000036F2A4: DC5E0000 057C0005
	global_load_b64 v[14:15], v[14:15], off                    // 00000036F2AC: DC560000 0E7C000E
	global_load_b32 v31, v[31:32], off                         // 00000036F2B4: DC520000 1F7C001F
	s_branch 64939                                             // 00000036F2BC: BFA0FDAB <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi1ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x36c>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000036F2C0: 8C7E067E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000036F2C4: BF8700C9
	s_or_b32 exec_lo, exec_lo, s1                              // 00000036F2C8: 8C7E017E
	s_waitcnt vmcnt(2)                                         // 00000036F2CC: BF890BF7
	.long 0xd71f0001                                           // 00000036F2D0: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000036F2D4: 020100C1
	s_mov_b32 s0, exec_lo                                      // 00000036F2D8: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 00000036F2DC: 3A040290
	v_xor_b32_e32 v3, 8, v1                                    // 00000036F2E0: 3A060288
	v_xor_b32_e32 v4, 4, v1                                    // 00000036F2E4: 3A080284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000036F2E8: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 00000036F2EC: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 00000036F2F0: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v3                            // 00000036F2F4: 7C9806A0
	v_cndmask_b32_e32 v3, v1, v3, vcc_lo                       // 00000036F2F8: 02060701
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 00000036F2FC: 7C9808A0
	s_delay_alu instid0(VALU_DEP_2)                            // 00000036F300: BF870002
	v_lshlrev_b32_e32 v3, 2, v3                                // 00000036F304: 30060682
	v_lshlrev_b32_e32 v2, 2, v2                                // 00000036F308: 30040482
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo                       // 00000036F30C: 02080901
	ds_bpermute_b32 v2, v2, v16                                // 00000036F310: DACC0000 02001002
	v_lshlrev_b32_e32 v4, 2, v4                                // 00000036F318: 30080882
	s_waitcnt lgkmcnt(0)                                       // 00000036F31C: BF89FC07
	v_add_f32_e32 v2, v16, v2                                  // 00000036F320: 06040510
	ds_bpermute_b32 v3, v3, v2                                 // 00000036F324: DACC0000 03000203
	s_waitcnt lgkmcnt(0)                                       // 00000036F32C: BF89FC07
	v_add_f32_e32 v2, v2, v3                                   // 00000036F330: 06040702
	ds_bpermute_b32 v3, v4, v2                                 // 00000036F334: DACC0000 03000204
	v_xor_b32_e32 v4, 2, v1                                    // 00000036F33C: 3A080282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000036F340: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 00000036F344: 7C9808A0
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo                       // 00000036F348: 02080901
	v_lshlrev_b32_e32 v4, 2, v4                                // 00000036F34C: 30080882
	s_waitcnt lgkmcnt(0)                                       // 00000036F350: BF89FC07
	v_add_f32_e32 v2, v2, v3                                   // 00000036F354: 06040702
	ds_bpermute_b32 v3, v4, v2                                 // 00000036F358: DACC0000 03000204
	v_xor_b32_e32 v4, 1, v1                                    // 00000036F360: 3A080281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000036F364: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 00000036F368: 7C9808A0
	s_waitcnt lgkmcnt(0)                                       // 00000036F36C: BF89FC07
	v_dual_cndmask_b32 v4, v1, v4 :: v_dual_add_f32 v1, v2, v3 // 00000036F370: CA480901 04000702
	v_lshlrev_b32_e32 v2, 2, v4                                // 00000036F378: 30040882
	ds_bpermute_b32 v2, v2, v1                                 // 00000036F37C: DACC0000 02000102
	v_cmpx_eq_u32_e32 0, v18                                   // 00000036F384: 7D942480
	s_cbranch_execz 9                                          // 00000036F388: BFA50009 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi1ELi32ELi2EEEvNS0_5LqGrpEPKtl+0xdb0>
	v_lshlrev_b32_e32 v3, s18, v17                             // 00000036F38C: 30062212
	s_waitcnt lgkmcnt(0)                                       // 00000036F390: BF89FC07
	v_add_f32_e32 v1, v1, v2                                   // 00000036F394: 06020501
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000036F398: BF870092
	v_lshlrev_b32_e32 v3, 2, v3                                // 00000036F39C: 30060682
	v_lshl_add_u32 v2, v19, 2, v3                              // 00000036F3A0: D6460002 040D0513
	ds_store_b32 v2, v1                                        // 00000036F3A8: D8340000 00000102
	s_or_b32 exec_lo, exec_lo, s0                              // 00000036F3B0: 8C7E007E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000036F3B4: BF870009
	s_and_b32 s0, s17, exec_lo                                 // 00000036F3B8: 8B007E11
	s_cselect_b32 s0, 1, 4                                     // 00000036F3BC: 98008481
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000036F3C0: BF890007
	v_cmp_gt_u32_e32 vcc_lo, s0, v0                            // 00000036F3C4: 7C980000
	s_barrier                                                  // 00000036F3C8: BFBD0000
	buffer_gl0_inv                                             // 00000036F3CC: E0AC0000 00000000
	s_and_saveexec_b32 s0, vcc_lo                              // 00000036F3D4: BE80206A
	s_cbranch_execz 308                                        // 00000036F3D8: BFA50134 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi1ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x12ac>
	.long 0xd7000001                                           // 00000036F3DC: D7000001
	v_cndmask_b32_e32 v1, s2, v0, vcc_lo                       // 00000036F3E0: 02020002
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000036F3E4: BF870121
	v_add_co_ci_u32_e64 v2, null, s3, 0, s0                    // 00000036F3E8: D5207C02 00010003
	v_mov_b32_e32 v3, 0                                        // 00000036F3F0: 7E060280
	v_cmp_gt_i64_e32 vcc_lo, s[10:11], v[1:2]                  // 00000036F3F4: 7CA8020A
	s_and_b32 exec_lo, exec_lo, vcc_lo                         // 00000036F3F8: 8B7E6A7E
	s_cbranch_execz 299                                        // 00000036F3FC: BFA5012B <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi1ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x12ac>
	v_lshlrev_b32_e32 v0, s18, v0                              // 00000036F400: 30000012
	s_delay_alu instid0(VALU_DEP_1)                            // 00000036F404: BF870001
	v_lshlrev_b32_e32 v0, 2, v0                                // 00000036F408: 30000082
	ds_load_b32 v4, v0                                         // 00000036F40C: D8D80000 04000000
	v_add_nc_u32_e32 v0, 4, v0                                 // 00000036F414: 4A000084
	s_add_i32 s16, s16, -1                                     // 00000036F418: 8110C110
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000036F41C: BF870009
	s_cmp_eq_u32 s16, 0                                        // 00000036F420: BF068010
	s_waitcnt lgkmcnt(0)                                       // 00000036F424: BF89FC07
	v_add_f32_e32 v3, v3, v4                                   // 00000036F428: 06060903
	s_cbranch_scc0 65527                                       // 00000036F42C: BFA1FFF7 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi1ELi32ELi2EEEvNS0_5LqGrpEPKtl+0xe0c>
	s_clause 0x1                                               // 00000036F430: BF850001
	s_load_b64 s[2:3], s[8:9], 0x38                            // 00000036F434: F4040084 F8000038
	s_load_b64 s[0:1], s[8:9], 0x8                             // 00000036F43C: F4040004 F8000008
	s_mov_b32 s6, -1                                           // 00000036F444: BE8600C1
	s_mov_b32 s4, 0                                            // 00000036F448: BE840080
	s_mov_b32 s5, 0                                            // 00000036F44C: BE850080
	s_waitcnt lgkmcnt(0)                                       // 00000036F450: BF89FC07
	s_cmp_lt_i32 s3, 3                                         // 00000036F454: BF048303
	s_cbranch_scc1 146                                         // 00000036F458: BFA20092 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi1ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x10a4>
	s_cmp_gt_i32 s3, 3                                         // 00000036F45C: BF028303
	s_cbranch_scc0 91                                          // 00000036F460: BFA1005B <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi1ELi32ELi2EEEvNS0_5LqGrpEPKtl+0xfd0>
	s_cmp_gt_i32 s3, 4                                         // 00000036F464: BF028403
	s_cbranch_scc0 48                                          // 00000036F468: BFA10030 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi1ELi32ELi2EEEvNS0_5LqGrpEPKtl+0xf2c>
	s_cmp_eq_u32 s3, 5                                         // 00000036F46C: BF068503
	s_mov_b32 s5, -1                                           // 00000036F470: BE8500C1
	s_cbranch_scc0 44                                          // 00000036F474: BFA1002C <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi1ELi32ELi2EEEvNS0_5LqGrpEPKtl+0xf28>
	s_load_b64 s[6:7], s[8:9], 0x10                            // 00000036F478: F4040184 F8000010
	v_dual_mov_b32 v5, 0 :: v_dual_and_b32 v4, 0x1ff, v1       // 00000036F480: CA240080 050402FF 000001FF
	v_dual_mov_b32 v0, s1 :: v_dual_mov_b32 v7, s0             // 00000036F48C: CA100001 00060000
	v_and_b32_e32 v8, 7, v2                                    // 00000036F494: 36100487
	v_bfe_u32 v9, v3, 16, 1                                    // 00000036F498: D6100009 02052103
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000036F4A0: BF8700A4
	v_cmp_gt_u64_e32 vcc_lo, 0x100, v[4:5]                     // 00000036F4A4: 7CB808FF 00000100
	.long 0xd7000505                                           // 00000036F4AC: D7000505
	v_cndmask_b32_e32 v1, 0xffffff00, v4, vcc_lo               // 00000036F4B0: 020208FF FFFFFF00
	v_add_co_ci_u32_e64 v6, null, 0, -1, s5                    // 00000036F4B8: D5207C06 00158280
	s_mov_b32 s5, 0                                            // 00000036F4C0: BE850080
	v_cndmask_b32_e32 v4, v5, v4, vcc_lo                       // 00000036F4C4: 02080905
	v_cndmask_b32_e64 v5, v6, 0, vcc_lo                        // 00000036F4C8: D5010005 01A90106
	v_and_b32_e32 v6, 0xfffffe00, v1                           // 00000036F4D0: 360C02FF FFFFFE00
	s_waitcnt lgkmcnt(0)                                       // 00000036F4D8: BF89FC07
	v_cndmask_b32_e32 v7, s6, v7, vcc_lo                       // 00000036F4DC: 020E0E06
	v_cndmask_b32_e32 v0, s7, v0, vcc_lo                       // 00000036F4E0: 02000007
	.long 0xd73c0004                                           // 00000036F4E4: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 00000036F4E8: 02020881
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000036F4EC: BF870093
	.long 0xd7006a06                                           // 00000036F4F0: D7006A06
	v_cndmask_b32_e32 v1, v7, v6, vcc_lo                       // 00000036F4F4: 02020D07
	v_add_co_ci_u32_e64 v0, null, v0, v8, vcc_lo               // 00000036F4F8: D5207C00 01AA1100
	v_add3_u32 v7, v3, v9, 0x7fff                              // 00000036F500: D6550007 03FE1303 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000036F50C: BF870093
	.long 0xd7006a04                                           // 00000036F510: D7006A04
	v_cndmask_b32_e32 v1, v6, v4, vcc_lo                       // 00000036F514: 02020906
	v_add_co_ci_u32_e64 v5, null, v0, v5, vcc_lo               // 00000036F518: D5207C05 01AA0B00
	global_store_d16_hi_b16 v[4:5], v7, off                    // 00000036F520: DC960000 007C0704
	s_mov_b32 s6, 0                                            // 00000036F528: BE860080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000036F52C: BF870009
	s_and_b32 vcc_lo, exec_lo, s6                              // 00000036F530: 8B6A067E
	s_cbranch_vccz 37                                          // 00000036F534: BFA30025 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi1ELi32ELi2EEEvNS0_5LqGrpEPKtl+0xfcc>
	v_mul_f32_e32 v0, 0xbfb8aa3b, v3                           // 00000036F538: 100006FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000036F540: BF870291
	v_exp_f32_e32 v0, v0                                       // 00000036F544: 7E004B00
	v_add_f32_e32 v0, 1.0, v0                                  // 00000036F548: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000036F54C: BF870121
	v_div_scale_f32 v4, null, v0, v0, 1.0                      // 00000036F550: D6FC7C04 03CA0100
	v_div_scale_f32 v7, vcc_lo, 1.0, v0, 1.0                   // 00000036F558: D6FC6A07 03CA00F2
	v_rcp_f32_e32 v5, v4                                       // 00000036F560: 7E0A5504
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000036F564: BF870095
	v_fma_f32 v6, -v4, v5, 1.0                                 // 00000036F568: D6130006 23CA0B04
	v_fmac_f32_e32 v5, v6, v5                                  // 00000036F570: 560A0B06
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000036F574: BF870091
	v_mul_f32_e32 v6, v7, v5                                   // 00000036F578: 100C0B07
	v_fma_f32 v8, -v4, v6, v7                                  // 00000036F57C: D6130008 241E0D04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000036F584: BF870091
	v_fmac_f32_e32 v6, v8, v5                                  // 00000036F588: 560C0B08
	v_fma_f32 v4, -v4, v6, v7                                  // 00000036F58C: D6130004 241E0D04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000036F594: BF870121
	v_div_fmas_f32 v6, v4, v5, v6                              // 00000036F598: D6370006 041A0B04
	.long 0xd73c0004                                           // 00000036F5A0: D73C0004
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000036F5A4: 02020282
	v_div_fixup_f32 v0, v6, v0, 1.0                            // 00000036F5A8: D6270000 03CA0106
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000036F5B0: BF870092
	.long 0xd7006a04                                           // 00000036F5B4: D7006A04
	v_cndmask_b32_e32 v1, s0, v4, vcc_lo                       // 00000036F5B8: 02020800
	v_add_co_ci_u32_e64 v5, null, s1, v5, vcc_lo               // 00000036F5BC: D5207C05 01AA0A01
	global_store_b32 v[4:5], v0, off                           // 00000036F5C4: DC6A0000 007C0004
	s_mov_b32 s6, 0                                            // 00000036F5CC: BE860080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000036F5D0: BF870009
	s_and_b32 vcc_lo, exec_lo, s6                              // 00000036F5D4: 8B6A067E
	s_cbranch_vccz 49                                          // 00000036F5D8: BFA30031 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi1ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x10a0>
	v_bfe_u32 v0, v3, 16, 1                                    // 00000036F5DC: D6100000 02052103
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000036F5E4: BF870091
	v_add3_u32 v0, v3, v0, 0x7fff                              // 00000036F5E8: D6550000 03FE0103 00007FFF
	v_and_b32_e32 v0, 0xffff0000, v0                           // 00000036F5F4: 360000FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000036F5FC: BF870091
	v_mul_f32_e32 v0, s2, v0                                   // 00000036F600: 10000002
	v_mul_f32_e32 v0, 0xbfb8aa3b, v0                           // 00000036F604: 100000FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000036F60C: BF870291
	v_exp_f32_e32 v0, v0                                       // 00000036F610: 7E004B00
	v_add_f32_e32 v0, 1.0, v0                                  // 00000036F614: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000036F618: BF870121
	v_div_scale_f32 v4, null, v0, v0, 1.0                      // 00000036F61C: D6FC7C04 03CA0100
	v_div_scale_f32 v7, vcc_lo, 1.0, v0, 1.0                   // 00000036F624: D6FC6A07 03CA00F2
	v_rcp_f32_e32 v5, v4                                       // 00000036F62C: 7E0A5504
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000036F630: BF870095
	v_fma_f32 v6, -v4, v5, 1.0                                 // 00000036F634: D6130006 23CA0B04
	v_fmac_f32_e32 v5, v6, v5                                  // 00000036F63C: 560A0B06
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000036F640: BF870091
	v_mul_f32_e32 v6, v7, v5                                   // 00000036F644: 100C0B07
	v_fma_f32 v8, -v4, v6, v7                                  // 00000036F648: D6130008 241E0D04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000036F650: BF870091
	v_fmac_f32_e32 v6, v8, v5                                  // 00000036F654: 560C0B08
	v_fma_f32 v4, -v4, v6, v7                                  // 00000036F658: D6130004 241E0D04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000036F660: BF870091
	v_div_fmas_f32 v4, v4, v5, v6                              // 00000036F664: D6370004 041A0B04
	v_div_fixup_f32 v0, v4, v0, 1.0                            // 00000036F66C: D6270000 03CA0104
	.long 0xd73c0004                                           // 00000036F674: D73C0004
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000036F678: 02020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000036F67C: BF870112
	v_add_f32_e32 v0, v0, v0                                   // 00000036F680: 06000100
	.long 0xd7006a04                                           // 00000036F684: D7006A04
	v_cndmask_b32_e32 v1, s0, v4, vcc_lo                       // 00000036F688: 02020800
	s_delay_alu instid0(VALU_DEP_1)                            // 00000036F68C: BF870001
	v_add_co_ci_u32_e64 v5, null, s1, v5, vcc_lo               // 00000036F690: D5207C05 01AA0A01
	global_store_b32 v[4:5], v0, off                           // 00000036F698: DC6A0000 007C0004
	s_mov_b32 s6, 0                                            // 00000036F6A0: BE860080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000036F6A4: BF870009
	s_and_b32 vcc_lo, exec_lo, s6                              // 00000036F6A8: 8B6A067E
	s_cbranch_vccz 62                                          // 00000036F6AC: BFA3003E <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi1ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x11a8>
	s_cmp_gt_i32 s3, 1                                         // 00000036F6B0: BF028103
	s_mov_b32 s4, -1                                           // 00000036F6B4: BE8400C1
	s_cbranch_scc0 53                                          // 00000036F6B8: BFA10035 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi1ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x1190>
	v_bfe_u32 v0, v3, 16, 1                                    // 00000036F6BC: D6100000 02052103
	s_mov_b32 s4, 0                                            // 00000036F6C4: BE840080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000036F6C8: BF870091
	v_add3_u32 v0, v3, v0, 0x7fff                              // 00000036F6CC: D6550000 03FE0103 00007FFF
	v_and_b32_e32 v0, 0xffff0000, v0                           // 00000036F6D8: 360000FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000036F6E0: BF870091
	v_mul_f32_e32 v0, 0xbfb8aa3b, v0                           // 00000036F6E4: 100000FF BFB8AA3B
	v_exp_f32_e32 v0, v0                                       // 00000036F6EC: 7E004B00
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000036F6F0: BF870095
	v_add_f32_e32 v0, 1.0, v0                                  // 00000036F6F4: 060000F2
	v_div_scale_f32 v4, null, v0, v0, 1.0                      // 00000036F6F8: D6FC7C04 03CA0100
	v_div_scale_f32 v7, vcc_lo, 1.0, v0, 1.0                   // 00000036F700: D6FC6A07 03CA00F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000036F708: BF870292
	v_rcp_f32_e32 v5, v4                                       // 00000036F70C: 7E0A5504
	v_fma_f32 v6, -v4, v5, 1.0                                 // 00000036F710: D6130006 23CA0B04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000036F718: BF870091
	v_fmac_f32_e32 v5, v6, v5                                  // 00000036F71C: 560A0B06
	v_mul_f32_e32 v6, v7, v5                                   // 00000036F720: 100C0B07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000036F724: BF870091
	v_fma_f32 v8, -v4, v6, v7                                  // 00000036F728: D6130008 241E0D04
	v_fmac_f32_e32 v6, v8, v5                                  // 00000036F730: 560C0B08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000036F734: BF870091
	v_fma_f32 v4, -v4, v6, v7                                  // 00000036F738: D6130004 241E0D04
	v_div_fmas_f32 v4, v4, v5, v6                              // 00000036F740: D6370004 041A0B04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000036F748: BF870121
	v_div_fixup_f32 v0, v4, v0, 1.0                            // 00000036F74C: D6270000 03CA0104
	.long 0xd73c0004                                           // 00000036F754: D73C0004
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000036F758: 02020281
	v_bfe_u32 v6, v0, 16, 1                                    // 00000036F75C: D6100006 02052100
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000036F764: BF870092
	.long 0xd7006a04                                           // 00000036F768: D7006A04
	v_cndmask_b32_e32 v1, s0, v4, vcc_lo                       // 00000036F76C: 02020800
	v_add_co_ci_u32_e64 v5, null, s1, v5, vcc_lo               // 00000036F770: D5207C05 01AA0A01
	s_delay_alu instid0(VALU_DEP_3)                            // 00000036F778: BF870003
	v_add3_u32 v0, v0, v6, 0x7fff                              // 00000036F77C: D6550000 03FE0D00 00007FFF
	global_store_d16_hi_b16 v[4:5], v0, off                    // 00000036F788: DC960000 007C0004
	s_and_not1_b32 vcc_lo, exec_lo, s4                         // 00000036F790: 916A047E
	s_mov_b32 s4, 0                                            // 00000036F794: BE840080
	s_cbranch_vccnz 3                                          // 00000036F798: BFA40003 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi1ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x11a8>
	s_cmp_lg_u32 s3, 1                                         // 00000036F79C: BF078103
	s_mov_b32 s4, -1                                           // 00000036F7A0: BE8400C1
	s_cselect_b32 s5, -1, 0                                    // 00000036F7A4: 980580C1
	v_bfe_u32 v4, v3, 16, 1                                    // 00000036F7A8: D6100004 02052103
	.long 0xd73c0000                                           // 00000036F7B0: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000036F7B4: 02020281
	s_and_b32 vcc_lo, exec_lo, s5                              // 00000036F7B8: 8B6A057E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000036F7BC: BF870002
	v_add3_u32 v2, v3, v4, 0x7fff                              // 00000036F7C0: D6550002 03FE0903 00007FFF
	s_cbranch_vccz 8                                           // 00000036F7CC: BFA30008 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi1ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x11f0>
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000036F7D0: BF870092
	.long 0xd7006a03                                           // 00000036F7D4: D7006A03
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 00000036F7D8: 02020000
	v_add_co_ci_u32_e64 v4, null, s1, v1, vcc_lo               // 00000036F7DC: D5207C04 01AA0201
	s_mov_b32 s4, 0                                            // 00000036F7E4: BE840080
	global_store_d16_hi_b16 v[3:4], v2, off                    // 00000036F7E8: DC960000 007C0203
	s_and_not1_b32 vcc_lo, exec_lo, s4                         // 00000036F7F0: 916A047E
	s_cbranch_vccnz 45                                         // 00000036F7F4: BFA4002D <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi1ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x12ac>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000036F7F8: BF870091
	v_and_b32_e32 v2, 0xffff0000, v2                           // 00000036F7FC: 360404FF FFFF0000
	v_mul_f32_e32 v2, s2, v2                                   // 00000036F804: 10040402
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000036F808: BF870091
	v_mul_f32_e32 v3, 0xbfb8aa3b, v2                           // 00000036F80C: 100604FF BFB8AA3B
	v_exp_f32_e32 v3, v3                                       // 00000036F814: 7E064B03
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000036F818: BF870095
	v_add_f32_e32 v3, 1.0, v3                                  // 00000036F81C: 060606F2
	v_div_scale_f32 v4, null, v3, v3, v2                       // 00000036F820: D6FC7C04 040A0703
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000036F828: BF870291
	v_rcp_f32_e32 v5, v4                                       // 00000036F82C: 7E0A5504
	v_fma_f32 v6, -v4, v5, 1.0                                 // 00000036F830: D6130006 23CA0B04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000036F838: BF8700A1
	v_fmac_f32_e32 v5, v6, v5                                  // 00000036F83C: 560A0B06
	v_div_scale_f32 v7, vcc_lo, v2, v3, v2                     // 00000036F840: D6FC6A07 040A0702
	v_mul_f32_e32 v6, v7, v5                                   // 00000036F848: 100C0B07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000036F84C: BF870091
	v_fma_f32 v8, -v4, v6, v7                                  // 00000036F850: D6130008 241E0D04
	v_fmac_f32_e32 v6, v8, v5                                  // 00000036F858: 560C0B08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000036F85C: BF870091
	v_fma_f32 v4, -v4, v6, v7                                  // 00000036F860: D6130004 241E0D04
	v_div_fmas_f32 v4, v4, v5, v6                              // 00000036F868: D6370004 041A0B04
	.long 0xd7006a00                                           // 00000036F870: D7006A00
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 00000036F874: 02020000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000036F878: BF870191
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 00000036F87C: D5207C01 01AA0201
	v_div_fixup_f32 v2, v4, v3, v2                             // 00000036F884: D6270002 040A0704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000036F88C: BF870091
	v_bfe_u32 v3, v2, 16, 1                                    // 00000036F890: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 00000036F898: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off                    // 00000036F8A4: DC960000 007C0200
	s_endpgm                                                   // 00000036F8AC: BFB00000
		...

