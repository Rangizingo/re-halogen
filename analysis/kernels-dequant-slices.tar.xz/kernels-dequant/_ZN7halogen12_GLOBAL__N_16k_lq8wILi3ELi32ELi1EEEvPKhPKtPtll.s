00000000002e4500 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi3ELi32ELi1EEEvPKhPKtPtll>:
; _ZN7halogen12_GLOBAL__N_16k_lq8wILi3ELi32ELi1EEEvPKhPKtPtll():
	s_clause 0x1                                               // 0000002E4500: BF850001
	s_load_b64 s[12:13], s[0:1], 0x20                          // 0000002E4504: F4040300 F8000020
	s_load_b256 s[4:11], s[0:1], null                          // 0000002E450C: F40C0100 F8000000
	v_lshrrev_b32_e32 v1, 5, v0                                // 0000002E4514: 32020085
	s_mov_b32 s3, 0                                            // 0000002E4518: BE830080
	v_dual_mov_b32 v16, 0 :: v_dual_and_b32 v15, 31, v0        // 0000002E451C: CA240080 100E009F
	s_lshl_b64 s[0:1], s[2:3], 3                               // 0000002E4524: 84808302
	v_mov_b32_e32 v21, 0                                       // 0000002E4528: 7E2A0280
	v_or_b32_e32 v9, s0, v1                                    // 0000002E452C: 38120200
	v_dual_mov_b32 v10, s1 :: v_dual_mov_b32 v3, 0             // 0000002E4530: CA100001 0A020080
	v_lshlrev_b32_e32 v11, 4, v15                              // 0000002E4538: 30161E84
	s_waitcnt lgkmcnt(0)                                       // 0000002E453C: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000002E4540: BF8704A2
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[9:10]                 // 0000002E4544: 7CA8120C
	s_ashr_i32 s0, s11, 31                                     // 0000002E4548: 86009F0B
	s_lshr_b32 s0, s0, 28                                      // 0000002E454C: 85009C00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 0000002E4550: BF8704D9
	s_add_u32 s2, s10, s0                                      // 0000002E4554: 8002000A
	s_addc_u32 s3, s11, 0                                      // 0000002E4558: 8203800B
	v_cndmask_b32_e32 v1, 0, v9, vcc_lo                        // 0000002E455C: 02021280
	v_cndmask_b32_e64 v2, 0, s1, vcc_lo                        // 0000002E4560: D5010002 01A80280
	s_ashr_i64 s[2:3], s[2:3], 4                               // 0000002E4568: 86828402
	s_add_u32 s0, s2, s10                                      // 0000002E456C: 80000A02
	s_addc_u32 s1, s3, s11                                     // 0000002E4570: 82010B03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000002E4574: BF870251
	.long 0xd72c0004                                           // 0000002E4578: D72C0004
	v_cndmask_b32_e32 v0, v2, v0, vcc_lo                       // 0000002E457C: 02000102
	v_mad_u64_u32 v[5:6], null, v1, s0, 0                      // 0000002E4580: D6FE7C05 02000101
	.long 0xd72c0007                                           // 0000002E4588: D72C0007
	v_cndmask_b32_e32 v0, v1, v1, vcc_lo                       // 0000002E458C: 02000301
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v2, 0               // 0000002E4590: CA100080 01020080
	.long 0xd4440000                                           // 0000002E4598: D4440000
	v_cndmask_b32_e32 v1, s2, v15, vcc_lo                      // 0000002E459C: 02021E02
	.long 0xd7000111                                           // 0000002E45A0: D7000111
	v_cndmask_b32_e32 v1, s4, v5, vcc_lo                       // 0000002E45A4: 02020A04
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002E45A8: BF870124
	v_add3_u32 v6, v6, v7, v4                                  // 0000002E45AC: D6550006 04120F06
	v_mov_b32_e32 v4, 0                                        // 0000002E45B4: 7E080280
	v_add_co_ci_u32_e64 v18, null, s5, v6, s1                  // 0000002E45B8: D5207C12 00060C05
	s_and_saveexec_b32 s3, s0                                  // 0000002E45C0: BE832000
	s_cbranch_execz 21                                         // 0000002E45C4: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi3ELi32ELi1EEEvPKhPKtPtll+0x11c>
	v_lshlrev_b32_e32 v1, 4, v15                               // 0000002E45C8: 30021E84
	.long 0xd7000103                                           // 0000002E45CC: D7000103
	v_cndmask_b32_e32 v0, v17, v10, vcc_lo                     // 0000002E45D0: 02001511
	v_and_b32_e32 v7, 28, v0                                   // 0000002E45D4: 360E009C
	v_add_co_ci_u32_e64 v4, null, s11, v18, s1                 // 0000002E45D8: D5207C04 0006240B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E45E0: BF870094
	.long 0xd7000101                                           // 0000002E45E4: D7000101
	v_cndmask_b32_e32 v1, v17, v1, vcc_lo                      // 0000002E45E8: 02020311
	v_add_co_ci_u32_e64 v2, null, 0, v18, s1                   // 0000002E45EC: D5207C02 00062480
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E45F4: BF870094
	.long 0xd7000107                                           // 0000002E45F8: D7000107
	v_cndmask_b32_e32 v1, v3, v7, vcc_lo                       // 0000002E45FC: 02020F03
	v_add_co_ci_u32_e64 v8, null, 0, v4, s1                    // 0000002E4600: D5207C08 00060880
	s_clause 0x1                                               // 0000002E4608: BF850001
	global_load_b128 v[1:4], v[1:2], off                       // 0000002E460C: DC5E0000 017C0001
	global_load_b32 v21, v[7:8], off                           // 0000002E4614: DC520000 157C0007
	s_or_b32 exec_lo, exec_lo, s3                              // 0000002E461C: 8C7E037E
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v20, 0             // 0000002E4620: CA100080 13140080
	s_and_saveexec_b32 s3, s0                                  // 0000002E4628: BE832000
	s_cbranch_execz 328                                        // 0000002E462C: BFA50148 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi3ELi32ELi1EEEvPKhPKtPtll+0x650>
	v_and_or_b32 v0, v0, 28, 32                                // 0000002E4630: D6570000 02813900
	.long 0xd7000005                                           // 0000002E4638: D7000005
	v_cndmask_b32_e32 v1, s10, v5, vcc_lo                      // 0000002E463C: 02020A0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002E4640: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s11, v6, s0                  // 0000002E4644: D5207C06 00020C0B
	v_mov_b32_e32 v12, 0                                       // 0000002E464C: 7E180280
	.long 0xd7000000                                           // 0000002E4650: D7000000
	v_cndmask_b32_e32 v1, v5, v0, vcc_lo                       // 0000002E4654: 02020105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002E4658: BF870191
	v_add_co_ci_u32_e64 v5, null, 0, v6, s0                    // 0000002E465C: D5207C05 00020C80
	v_mov_b32_e32 v20, v12                                     // 0000002E4664: 7E28030C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E4668: BF870093
	.long 0xd700000d                                           // 0000002E466C: D700000D
	v_cndmask_b32_e32 v1, s4, v0, vcc_lo                       // 0000002E4670: 02020004
	v_add_co_ci_u32_e64 v14, null, s5, v5, s0                  // 0000002E4674: D5207C0E 00020A05
	v_dual_mov_b32 v0, v15 :: v_dual_mov_b32 v19, v12          // 0000002E467C: CA10010F 0012010C
	v_mov_b32_e32 v16, v12                                     // 0000002E4684: 7E20030C
	s_lshl_b64 s[4:5], s[10:11], 2                             // 0000002E4688: 8484820A
	s_mov_b32 s14, 0                                           // 0000002E468C: BE8E0080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 0000002E4690: 848A810A
	s_branch 272                                               // 0000002E4694: BFA00110 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi3ELi32ELi1EEEvPKhPKtPtll+0x5d8>
	s_or_b32 exec_lo, exec_lo, s15                             // 0000002E4698: 8C7E0F7E
	.long 0xd73c0018                                           // 0000002E469C: D73C0018
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 0000002E46A0: 02021681
	v_cvt_f32_ubyte0_e32 v11, v1                               // 0000002E46A4: 7E162301
	v_cvt_f32_ubyte1_e32 v49, v1                               // 0000002E46A8: 7E622501
	v_cvt_f32_ubyte2_e32 v50, v1                               // 0000002E46AC: 7E642701
	v_cvt_f32_ubyte3_e32 v1, v1                                // 0000002E46B0: 7E022901
	v_cvt_f32_ubyte0_e32 v51, v2                               // 0000002E46B4: 7E662302
	.long 0xd7000124                                           // 0000002E46B8: D7000124
	v_cndmask_b32_e32 v1, s6, v24, vcc_lo                      // 0000002E46BC: 02023006
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002E46C0: BF8701A1
	v_add_co_ci_u32_e64 v37, null, s7, v25, s1                 // 0000002E46C4: D5207C25 00063207
	v_cvt_f32_ubyte1_e32 v52, v2                               // 0000002E46CC: 7E682502
	.long 0xd7000128                                           // 0000002E46D0: D7000128
	v_cndmask_b32_e32 v0, v36, v10, vcc_lo                     // 0000002E46D4: 02001524
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002E46D8: BF8700A1
	v_add_co_ci_u32_e64 v41, null, s11, v37, s1                // 0000002E46DC: D5207C29 00064A0B
	.long 0xd700012c                                           // 0000002E46E4: D700012C
	v_cndmask_b32_e32 v0, v36, v4, vcc_lo                      // 0000002E46E8: 02000924
	v_add_co_ci_u32_e64 v45, null, s5, v37, s1                 // 0000002E46EC: D5207C2D 00064A05
	s_clause 0x5                                               // 0000002E46F4: BF850005
	global_load_b128 v[24:27], v[36:37], off                   // 0000002E46F8: DC5E0000 187C0024
	global_load_b128 v[28:31], v[40:41], off                   // 0000002E4700: DC5E0000 1C7C0028
	global_load_b128 v[32:35], v[44:45], off                   // 0000002E4708: DC5E0000 207C002C
	global_load_b128 v[36:39], v[36:37], off offset:16         // 0000002E4710: DC5E0010 247C0024
	global_load_b128 v[40:43], v[40:41], off offset:16         // 0000002E4718: DC5E0010 287C0028
	global_load_b128 v[44:47], v[44:45], off offset:16         // 0000002E4720: DC5E0010 2C7C002C
	v_cvt_f32_ubyte2_e32 v53, v2                               // 0000002E4728: 7E6A2702
	v_cvt_f32_ubyte3_e32 v2, v2                                // 0000002E472C: 7E042902
	v_cvt_f32_ubyte0_e32 v54, v3                               // 0000002E4730: 7E6C2303
	v_cvt_f32_ubyte1_e32 v55, v3                               // 0000002E4734: 7E6E2503
	v_cvt_f32_ubyte2_e32 v56, v3                               // 0000002E4738: 7E702703
	v_cvt_f32_ubyte3_e32 v3, v3                                // 0000002E473C: 7E062903
	v_cvt_f32_ubyte0_e32 v57, v4                               // 0000002E4740: 7E722304
	v_cvt_f32_ubyte1_e32 v58, v4                               // 0000002E4744: 7E742504
	v_cvt_f32_ubyte2_e32 v59, v4                               // 0000002E4748: 7E762704
	v_cvt_f32_ubyte3_e32 v4, v4                                // 0000002E474C: 7E082904
	v_fma_mix_f32 v11, v11, v21, v21 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E4750: CC20600B 14562B0B
	v_fma_mix_f32 v49, v49, v21, v21 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E4758: CC206031 14562B31
	v_fma_mix_f32 v50, v50, v21, v21 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E4760: CC206032 14562B32
	v_fma_mix_f32 v1, v1, v21, v21 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E4768: CC206001 14562B01
	v_fma_mix_f32 v51, v51, v21, v21 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E4770: CC206033 14562B33
	v_fma_mix_f32 v52, v52, v21, v21 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E4778: CC206034 14562B34
	v_fma_mix_f32 v53, v53, v21, v21 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E4780: CC206035 14562B35
	v_fma_mix_f32 v2, v2, v21, v21 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E4788: CC206002 14562B02
	v_fma_mix_f32 v54, v54, v21, v21 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E4790: CC206036 14562B36
	v_fma_mix_f32 v55, v55, v21, v21 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E4798: CC206037 14562B37
	v_fma_mix_f32 v56, v56, v21, v21 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E47A0: CC206038 14562B38
	v_fma_mix_f32 v3, v3, v21, v21 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E47A8: CC206003 14562B03
	v_fma_mix_f32 v57, v57, v21, v21 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E47B0: CC206039 14562B39
	v_fma_mix_f32 v58, v58, v21, v21 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E47B8: CC20603A 14562B3A
	v_fma_mix_f32 v59, v59, v21, v21 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E47C0: CC20603B 14562B3B
	v_fma_mix_f32 v4, v4, v21, v21 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002E47C8: CC206004 14562B04
	v_bfe_u32 v21, v11, 16, 1                                  // 0000002E47D0: D6100015 0205210B
	v_bfe_u32 v64, v49, 16, 1                                  // 0000002E47D8: D6100040 02052131
	v_bfe_u32 v65, v50, 16, 1                                  // 0000002E47E0: D6100041 02052132
	.long 0x7f603880                                           // 0000002E47E8: 7F603880
	v_bfe_u32 v66, v1, 16, 1                                   // 0000002E47EC: D6100042 02052101
	v_add3_u32 v11, v11, v21, 0x7fff                           // 0000002E47F4: D655000B 03FE2B0B 00007FFF
	v_bfe_u32 v67, v51, 16, 1                                  // 0000002E4800: D6100043 02052133
	v_add3_u32 v21, v49, v64, 0x7fff                           // 0000002E4808: D6550015 03FE8131 00007FFF
	v_add3_u32 v49, v50, v65, 0x7fff                           // 0000002E4814: D6550031 03FE8332 00007FFF
	.long 0x7f7839b0                                           // 0000002E4820: 7F7839B0
	.long 0x7e60398b                                           // 0000002E4824: 7E60398B
	v_bfe_u32 v68, v52, 16, 1                                  // 0000002E4828: D6100044 02052134
	v_bfe_u32 v69, v53, 16, 1                                  // 0000002E4830: D6100045 02052135
	v_add3_u32 v1, v1, v66, 0x7fff                             // 0000002E4838: D6550001 03FE8501 00007FFF
	v_add3_u32 v50, v51, v67, 0x7fff                           // 0000002E4844: D6550032 03FE8733 00007FFF
	.long 0x7e7839b1                                           // 0000002E4850: 7E7839B1
	v_and_or_b32 v21, 0xffff0000, v21, v48                     // 0000002E4854: D6570015 04C22AFF FFFF0000
	v_bfe_u32 v70, v2, 16, 1                                   // 0000002E4860: D6100046 02052102
	v_bfe_u32 v71, v54, 16, 1                                  // 0000002E4868: D6100047 02052136
	v_add3_u32 v51, v52, v68, 0x7fff                           // 0000002E4870: D6550033 03FE8934 00007FFF
	v_add3_u32 v52, v53, v69, 0x7fff                           // 0000002E487C: D6550034 03FE8B35 00007FFF
	v_and_or_b32 v1, 0xffff0000, v1, v60                       // 0000002E4888: D6570001 04F202FF FFFF0000
	.long 0x7e6039b2                                           // 0000002E4894: 7E6039B2
	.long 0x7f7a39b0                                           // 0000002E4898: 7F7A39B0
	v_bfe_u32 v72, v55, 16, 1                                  // 0000002E489C: D6100048 02052137
	v_bfe_u32 v73, v56, 16, 1                                  // 0000002E48A4: D6100049 02052138
	v_add3_u32 v2, v2, v70, 0x7fff                             // 0000002E48AC: D6550002 03FE8D02 00007FFF
	v_add3_u32 v53, v54, v71, 0x7fff                           // 0000002E48B8: D6550035 03FE8F36 00007FFF
	.long 0x7e7a39b4                                           // 0000002E48C4: 7E7A39B4
	v_bfe_u32 v74, v3, 16, 1                                   // 0000002E48C8: D610004A 02052103
	v_bfe_u32 v75, v57, 16, 1                                  // 0000002E48D0: D610004B 02052139
	v_add3_u32 v54, v55, v72, 0x7fff                           // 0000002E48D8: D6550036 03FE9137 00007FFF
	v_add3_u32 v55, v56, v73, 0x7fff                           // 0000002E48E4: D6550037 03FE9338 00007FFF
	v_and_or_b32 v2, 0xffff0000, v2, v61                       // 0000002E48F0: D6570002 04F604FF FFFF0000
	.long 0x7f7c39b0                                           // 0000002E48FC: 7F7C39B0
	v_bfe_u32 v76, v58, 16, 1                                  // 0000002E4900: D610004C 0205213A
	v_bfe_u32 v77, v59, 16, 1                                  // 0000002E4908: D610004D 0205213B
	v_add3_u32 v3, v3, v74, 0x7fff                             // 0000002E4910: D6550003 03FE9503 00007FFF
	v_add3_u32 v11, v57, v75, 0x7fff                           // 0000002E491C: D655000B 03FE9739 00007FFF
	.long 0x7e7c39b7                                           // 0000002E4928: 7E7C39B7
	v_bfe_u32 v78, v4, 16, 1                                   // 0000002E492C: D610004E 02052104
	v_add3_u32 v49, v58, v76, 0x7fff                           // 0000002E4934: D6550031 03FE993A 00007FFF
	v_add3_u32 v56, v59, v77, 0x7fff                           // 0000002E4940: D6550038 03FE9B3B 00007FFF
	.long 0x7f7e39b0                                           // 0000002E494C: 7F7E39B0
	s_and_b32 s1, exec_lo, s0                                  // 0000002E4950: 8B01007E
	v_add3_u32 v4, v4, v78, 0x7fff                             // 0000002E4954: D6550004 03FE9D04 00007FFF
	.long 0xd700000d                                           // 0000002E4960: D700000D
	v_cndmask_b32_e32 v0, v13, v160, vcc_lo                    // 0000002E4964: 0201410D
	.long 0x7e7e39b8                                           // 0000002E4968: 7E7E39B8
	v_add_co_ci_u32_e64 v14, null, 0, v14, s0                  // 0000002E496C: D5207C0E 00021C80
	s_or_b32 s14, s1, s14                                      // 0000002E4974: 8C0E0E01
	s_waitcnt vmcnt(5)                                         // 0000002E4978: BF8917F7
	v_dot2_f32_bf16 v24, v24, v21, 0                           // 0000002E497C: CC1A4018 1A022B18
	s_waitcnt vmcnt(4)                                         // 0000002E4984: BF8913F7
	v_dot2_f32_bf16 v28, v28, v21, 0                           // 0000002E4988: CC1A401C 1A022B1C
	s_waitcnt vmcnt(3)                                         // 0000002E4990: BF890FF7
	v_dot2_f32_bf16 v21, v32, v21, 0                           // 0000002E4994: CC1A4015 1A022B20
	v_and_or_b32 v32, 0xffff0000, v51, v48                     // 0000002E499C: D6570020 04C266FF FFFF0000
	.long 0x7e6039b5                                           // 0000002E49A8: 7E6039B5
	v_dot2_f32_bf16 v24, v25, v1, v24                          // 0000002E49AC: CC1A4018 1C620319
	v_dot2_f32_bf16 v25, v29, v1, v28                          // 0000002E49B4: CC1A4019 1C72031D
	v_dot2_f32_bf16 v1, v33, v1, v21                           // 0000002E49BC: CC1A4001 1C560321
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002E49C4: BF870193
	v_dot2_f32_bf16 v21, v26, v32, v24                         // 0000002E49C8: CC1A4015 1C62411A
	v_dot2_f32_bf16 v24, v30, v32, v25                         // 0000002E49D0: CC1A4018 1C66411E
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002E49D8: BF870003
	v_dot2_f32_bf16 v1, v34, v32, v1                           // 0000002E49DC: CC1A4001 1C064122
	v_and_or_b32 v25, 0xffff0000, v54, v48                     // 0000002E49E4: D6570019 04C26CFF FFFF0000
	.long 0x7e60398b                                           // 0000002E49F0: 7E60398B
	v_dot2_f32_bf16 v21, v27, v2, v21                          // 0000002E49F4: CC1A4015 1C56051B
	v_dot2_f32_bf16 v24, v31, v2, v24                          // 0000002E49FC: CC1A4018 1C62051F
	v_dot2_f32_bf16 v1, v35, v2, v1                            // 0000002E4A04: CC1A4001 1C060523
	v_and_or_b32 v2, 0xffff0000, v3, v62                       // 0000002E4A0C: D6570002 04FA06FF FFFF0000
	s_waitcnt vmcnt(2)                                         // 0000002E4A18: BF890BF7
	v_dot2_f32_bf16 v3, v36, v25, v21                          // 0000002E4A1C: CC1A4003 1C563324
	s_waitcnt vmcnt(1)                                         // 0000002E4A24: BF8907F7
	v_dot2_f32_bf16 v11, v40, v25, v24                         // 0000002E4A28: CC1A400B 1C623328
	s_waitcnt vmcnt(0)                                         // 0000002E4A30: BF8903F7
	v_dot2_f32_bf16 v1, v44, v25, v1                           // 0000002E4A34: CC1A4001 1C06332C
	v_and_or_b32 v21, 0xffff0000, v49, v48                     // 0000002E4A3C: D6570015 04C262FF FFFF0000
	v_dot2_f32_bf16 v3, v37, v2, v3                            // 0000002E4A48: CC1A4003 1C0E0525
	v_dot2_f32_bf16 v24, v41, v2, v11                          // 0000002E4A50: CC1A4018 1C2E0529
	s_delay_alu instid0(VALU_DEP_4)                            // 0000002E4A58: BF870004
	v_dot2_f32_bf16 v1, v45, v2, v1                            // 0000002E4A5C: CC1A4001 1C06052D
	v_mov_b32_e32 v11, v22                                     // 0000002E4A64: 7E160316
	v_and_or_b32 v2, 0xffff0000, v4, v63                       // 0000002E4A68: D6570002 04FE08FF FFFF0000
	v_dot2_f32_bf16 v22, v38, v21, v3                          // 0000002E4A74: CC1A4016 1C0E2B26
	v_dot2_f32_bf16 v24, v42, v21, v24                         // 0000002E4A7C: CC1A4018 1C622B2A
	v_dot2_f32_bf16 v1, v46, v21, v1                           // 0000002E4A84: CC1A4001 1C062B2E
	v_dual_mov_b32 v4, v8 :: v_dual_mov_b32 v3, v7             // 0000002E4A8C: CA100108 04020107
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002E4A94: BF870214
	v_dot2_f32_bf16 v7, v39, v2, v22                           // 0000002E4A98: CC1A4007 1C5A0527
	v_dot2_f32_bf16 v8, v43, v2, v24                           // 0000002E4AA0: CC1A4008 1C62052B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002E4AA8: BF8701A4
	v_dot2_f32_bf16 v21, v47, v2, v1                           // 0000002E4AAC: CC1A4015 1C06052F
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v1, v5             // 0000002E4AB4: CA100106 02000105
	v_dual_add_f32 v20, v20, v7 :: v_dual_add_f32 v19, v19, v8 // 0000002E4ABC: C9080F14 14121113
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002E4AC4: BF870003
	v_dual_add_f32 v16, v16, v21 :: v_dual_mov_b32 v21, v23    // 0000002E4AC8: C9102B10 10140117
	s_and_not1_b32 exec_lo, exec_lo, s14                       // 0000002E4AD0: 917E0E7E
	s_cbranch_execz 29                                         // 0000002E4AD4: BFA5001D <_ZN7halogen12_GLOBAL__N_16k_lq8wILi3ELi32ELi1EEEvPKhPKtPtll+0x64c>
	v_add_nc_u32_e32 v0, 32, v0                                // 0000002E4AD8: 4A0000A0
	v_add_nc_u32_e32 v22, 0x200, v11                           // 0000002E4ADC: 4A2C16FF 00000200
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000002E4AE4: BF8704A2
	.long 0xd4430000                                           // 0000002E4AE8: D4430000
	v_cndmask_b32_e32 v1, s2, v0, vcc_lo                       // 0000002E4AEC: 02020002
	s_and_saveexec_b32 s1, s0                                  // 0000002E4AF0: BE812000
	s_xor_b32 s1, exec_lo, s1                                  // 0000002E4AF4: 8D01017E
	v_add_nc_u32_e32 v22, 0x200, v11                           // 0000002E4AF8: 4A2C16FF 00000200
	s_or_saveexec_b32 s15, s1                                  // 0000002E4B00: BE8F2201
	s_waitcnt vmcnt(0)                                         // 0000002E4B04: BF8903F7
	v_dual_mov_b32 v23, v21 :: v_dual_mov_b32 v6, v2           // 0000002E4B08: CA100115 17060102
	v_dual_mov_b32 v5, v1 :: v_dual_mov_b32 v8, v4             // 0000002E4B10: CA100101 05080104
	v_mov_b32_e32 v7, v3                                       // 0000002E4B18: 7E0E0303
	s_xor_b32 exec_lo, exec_lo, s15                            // 0000002E4B1C: 8D7E0F7E
	s_cbranch_execz 65245                                      // 0000002E4B20: BFA5FEDD <_ZN7halogen12_GLOBAL__N_16k_lq8wILi3ELi32ELi1EEEvPKhPKtPtll+0x198>
	.long 0xd7000105                                           // 0000002E4B24: D7000105
	v_cndmask_b32_e32 v1, v17, v22, vcc_lo                     // 0000002E4B28: 02022D11
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002E4B2C: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v18, s1                   // 0000002E4B30: D5207C06 00062480
	global_load_b128 v[5:8], v[5:6], off                       // 0000002E4B38: DC5E0000 057C0005
	global_load_b32 v23, v[13:14], off                         // 0000002E4B40: DC520000 177C000D
	s_branch 65235                                             // 0000002E4B48: BFA0FED3 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi3ELi32ELi1EEEvPKhPKtPtll+0x198>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000002E4B4C: 8C7E0E7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002E4B50: BF8700B9
	s_or_b32 exec_lo, exec_lo, s3                              // 0000002E4B54: 8C7E037E
	.long 0xd71f0000                                           // 0000002E4B58: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000002E4B5C: 020100C1
	s_waitcnt vmcnt(1)                                         // 0000002E4B60: BF8907F7
	v_xor_b32_e32 v1, 16, v0                                   // 0000002E4B64: 3A020090
	v_xor_b32_e32 v4, 8, v0                                    // 0000002E4B68: 3A080088
	v_xor_b32_e32 v7, 4, v0                                    // 0000002E4B6C: 3A0E0084
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E4B70: BF870093
	.long 0xd44c0000                                           // 0000002E4B74: D44C0000
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 0000002E4B78: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s0                           // 0000002E4B7C: D5010001 00020300
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002E4B84: BF870114
	.long 0xd44c0000                                           // 0000002E4B88: D44C0000
	v_cndmask_b32_e32 v1, 32, v4, vcc_lo                       // 0000002E4B8C: 020208A0
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000002E4B90: 30020282
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002E4B94: BF870002
	v_cndmask_b32_e64 v4, v0, v4, s0                           // 0000002E4B98: D5010004 00020900
	.long 0xd44c0000                                           // 0000002E4BA0: D44C0000
	v_cndmask_b32_e32 v1, 32, v7, vcc_lo                       // 0000002E4BA4: 02020EA0
	ds_bpermute_b32 v2, v1, v20                                // 0000002E4BA8: DACC0000 02001401
	v_cndmask_b32_e64 v7, v0, v7, s0                           // 0000002E4BB0: D5010007 00020F00
	s_waitcnt lgkmcnt(0)                                       // 0000002E4BB8: BF89FC07
	v_add_f32_e32 v2, v20, v2                                  // 0000002E4BBC: 06040514
	ds_bpermute_b32 v3, v1, v19                                // 0000002E4BC0: DACC0000 03001301
	v_lshlrev_b32_e32 v4, 2, v4                                // 0000002E4BC8: 30080882
	ds_bpermute_b32 v1, v1, v16                                // 0000002E4BCC: DACC0000 01001001
	s_waitcnt lgkmcnt(1)                                       // 0000002E4BD4: BF89FC17
	v_add_f32_e32 v3, v19, v3                                  // 0000002E4BD8: 06060713
	ds_bpermute_b32 v5, v4, v2                                 // 0000002E4BDC: DACC0000 05000204
	v_lshlrev_b32_e32 v7, 2, v7                                // 0000002E4BE4: 300E0E82
	ds_bpermute_b32 v6, v4, v3                                 // 0000002E4BE8: DACC0000 06000304
	s_waitcnt lgkmcnt(1)                                       // 0000002E4BF0: BF89FC17
	v_add_f32_e32 v2, v2, v5                                   // 0000002E4BF4: 06040B02
	v_add_f32_e32 v1, v16, v1                                  // 0000002E4BF8: 06020310
	ds_bpermute_b32 v4, v4, v1                                 // 0000002E4BFC: DACC0000 04000104
	s_waitcnt lgkmcnt(0)                                       // 0000002E4C04: BF89FC07
	v_add_f32_e32 v1, v1, v4                                   // 0000002E4C08: 06020901
	ds_bpermute_b32 v4, v7, v2                                 // 0000002E4C0C: DACC0000 04000207
	s_waitcnt lgkmcnt(0)                                       // 0000002E4C14: BF89FC07
	v_dual_add_f32 v2, v2, v4 :: v_dual_add_f32 v3, v3, v6     // 0000002E4C18: C9080902 02020D03
	ds_bpermute_b32 v6, v7, v1                                 // 0000002E4C20: DACC0000 06000107
	ds_bpermute_b32 v5, v7, v3                                 // 0000002E4C28: DACC0000 05000307
	v_xor_b32_e32 v7, 2, v0                                    // 0000002E4C30: 3A0E0082
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E4C34: BF870091
	.long 0xd44c0000                                           // 0000002E4C38: D44C0000
	v_cndmask_b32_e32 v1, 32, v7, vcc_lo                       // 0000002E4C3C: 02020EA0
	v_cndmask_b32_e64 v7, v0, v7, s0                           // 0000002E4C40: D5010007 00020F00
	s_waitcnt lgkmcnt(1)                                       // 0000002E4C48: BF89FC17
	v_add_f32_e32 v1, v1, v6                                   // 0000002E4C4C: 06020D01
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002E4C50: BF870002
	v_lshlrev_b32_e32 v7, 2, v7                                // 0000002E4C54: 300E0E82
	ds_bpermute_b32 v4, v7, v2                                 // 0000002E4C58: DACC0000 04000207
	ds_bpermute_b32 v6, v7, v1                                 // 0000002E4C60: DACC0000 06000107
	s_waitcnt lgkmcnt(1)                                       // 0000002E4C68: BF89FC17
	v_dual_add_f32 v2, v2, v4 :: v_dual_add_f32 v3, v3, v5     // 0000002E4C6C: C9080902 02020B03
	ds_bpermute_b32 v5, v7, v3                                 // 0000002E4C74: DACC0000 05000307
	v_xor_b32_e32 v7, 1, v0                                    // 0000002E4C7C: 3A0E0081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002E4C80: BF870091
	.long 0xd44c0000                                           // 0000002E4C84: D44C0000
	v_cndmask_b32_e32 v1, 32, v7, vcc_lo                       // 0000002E4C88: 02020EA0
	v_cndmask_b32_e64 v0, v0, v7, s0                           // 0000002E4C8C: D5010000 00020F00
	.long 0xd44a0000                                           // 0000002E4C94: D44A0000
	v_cndmask_b32_e32 v1, 0, v15, vcc_lo                       // 0000002E4C98: 02021E80
	s_waitcnt lgkmcnt(1)                                       // 0000002E4C9C: BF89FC17
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002E4CA0: BF870002
	v_dual_add_f32 v0, v1, v6 :: v_dual_lshlrev_b32 v7, 2, v0  // 0000002E4CA4: C9220D01 00060082
	s_and_b32 s0, s0, vcc_lo                                   // 0000002E4CAC: 8B006A00
	s_waitcnt lgkmcnt(0)                                       // 0000002E4CB0: BF89FC07
	v_add_f32_e32 v3, v3, v5                                   // 0000002E4CB4: 06060B03
	ds_bpermute_b32 v4, v7, v2                                 // 0000002E4CB8: DACC0000 04000207
	ds_bpermute_b32 v1, v7, v0                                 // 0000002E4CC0: DACC0000 01000007
	ds_bpermute_b32 v5, v7, v3                                 // 0000002E4CC8: DACC0000 05000307
	s_and_saveexec_b32 s1, s0                                  // 0000002E4CD0: BE812000
	s_cbranch_execz 48                                         // 0000002E4CD4: BFA50030 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi3ELi32ELi1EEEvPKhPKtPtll+0x898>
	s_waitcnt lgkmcnt(0)                                       // 0000002E4CD8: BF89FC07
	v_dual_add_f32 v5, v3, v5 :: v_dual_add_f32 v4, v2, v4     // 0000002E4CDC: C9080B03 05040902
	.long 0x7f0c3880                                           // 0000002E4CE4: 7F0C3880
	.long 0xd73c0002                                           // 0000002E4CE8: D73C0002
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 0000002E4CEC: 02021281
	s_lshl_b64 s[0:1], s[12:13], 1                             // 0000002E4CF0: 8480810C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000002E4CF4: BF8700D3
	.long 0x7e0c3985                                           // 0000002E4CF8: 7E0C3985
	.long 0x7e0e3984                                           // 0000002E4CFC: 7E0E3984
	.long 0x7f0e3986                                           // 0000002E4D00: 7F0E3986
	v_add_f32_e32 v8, v0, v1                                   // 0000002E4D04: 06100300
	.long 0xd7006a00                                           // 0000002E4D08: D7006A00
	v_cndmask_b32_e32 v1, s8, v2, vcc_lo                       // 0000002E4D0C: 02020408
	v_add_co_ci_u32_e64 v1, null, s9, v3, vcc_lo               // 0000002E4D10: D5207C01 01AA0609
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000002E4D18: BF870224
	v_and_b32_e32 v7, 1, v7                                    // 0000002E4D1C: 360E0E81
	v_and_b32_e32 v6, 1, v6                                    // 0000002E4D20: 360C0C81
	.long 0xd7006a02                                           // 0000002E4D24: D7006A02
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 0000002E4D28: 02000100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002E4D2C: BF870211
	v_add_co_ci_u32_e64 v3, null, s1, v1, vcc_lo               // 0000002E4D30: D5207C03 01AA0201
	v_add3_u32 v7, v4, v7, 0x7fff                              // 0000002E4D38: D6550007 03FE0F04 00007FFF
	v_bfe_u32 v4, v8, 16, 1                                    // 0000002E4D44: D6100004 02052108
	s_lshl_b64 s[0:1], s[12:13], 2                             // 0000002E4D4C: 8480820C
	v_add3_u32 v6, v5, v6, 0x7fff                              // 0000002E4D50: D6550006 03FE0D05 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002E4D5C: BF8700A2
	v_add3_u32 v8, v8, v4, 0x7fff                              // 0000002E4D60: D6550008 03FE0908 00007FFF
	.long 0xd7006a04                                           // 0000002E4D6C: D7006A04
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 0000002E4D70: 02000100
	v_add_co_ci_u32_e64 v5, null, s1, v1, vcc_lo               // 0000002E4D74: D5207C05 01AA0201
	s_clause 0x2                                               // 0000002E4D7C: BF850002
	global_store_d16_hi_b16 v[0:1], v7, off                    // 0000002E4D80: DC960000 007C0700
	global_store_d16_hi_b16 v[2:3], v6, off                    // 0000002E4D88: DC960000 007C0602
	global_store_d16_hi_b16 v[4:5], v8, off                    // 0000002E4D90: DC960000 007C0804
	s_endpgm                                                   // 0000002E4D98: BFB00000
		...

