0000000000834d00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000834D00: F4100100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 000000834D08: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 000000834D0C: 32040082
	s_lshl_b64 s[2:3], s[2:3], 3                               // 000000834D10: 84828302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000834D14: BF8701A9
	v_dual_mov_b32 v10, s3 :: v_dual_and_b32 v1, 15, v0        // 000000834D18: CA240003 0A00008F
	.long 0x7f103880                                           // 000000834D20: 7F103880
	v_and_b32_e32 v2, 60, v2                                   // 000000834D24: 360404BC
	s_delay_alu instid0(VALU_DEP_3)                            // 000000834D28: BF870003
	v_dual_mov_b32 v18, 0 :: v_dual_lshlrev_b32 v1, 2, v1      // 000000834D2C: CA220080 12000282
	v_dual_mov_b32 v3, 0 :: v_dual_and_b32 v16, 31, v0         // 000000834D34: CA240080 0310009F
	v_mov_b32_e32 v17, 0                                       // 000000834D3C: 7E220280
	s_waitcnt lgkmcnt(0)                                       // 000000834D40: BF89FC07
	s_clause 0x1                                               // 000000834D44: BF850001
	global_load_b32 v4, v1, s[4:5]                             // 000000834D48: DC520000 04040001
	global_load_b32 v7, v2, s[4:5]                             // 000000834D50: DC520000 07040002
	v_lshrrev_b32_e32 v2, 5, v0                                // 000000834D58: 32040085
	v_mov_b32_e32 v1, 0                                        // 000000834D5C: 7E020280
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000834D60: BF870122
	v_or_b32_e32 v9, s2, v2                                    // 000000834D64: 38120402
	v_mov_b32_e32 v2, 0                                        // 000000834D68: 7E040280
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[9:10]                 // 000000834D6C: 7CA8120C
	s_add_u32 s12, s4, s14                                     // 000000834D70: 800C0E04
	s_addc_u32 s13, s5, s15                                    // 000000834D74: 820D0F05
	s_lshr_b32 s2, s11, 31                                     // 000000834D78: 85029F0B
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000834D7C: BF870009
	s_add_u32 s14, s10, s2                                     // 000000834D80: 800E020A
	v_cndmask_b32_e32 v11, 0, v9, vcc_lo                       // 000000834D84: 02161280
	v_cndmask_b32_e64 v14, 0, s3, vcc_lo                       // 000000834D88: D501000E 01A80680
	s_addc_u32 s15, s11, 0                                     // 000000834D90: 820F800B
	s_ashr_i32 s20, s11, 31                                    // 000000834D94: 86149F0B
	s_ashr_i64 s[2:3], s[14:15], 1                             // 000000834D98: 8682810E
	s_lshr_b32 s14, s20, 27                                    // 000000834D9C: 850E9B14
	.long 0xd72c0014                                           // 000000834DA0: D72C0014
	v_cndmask_b32_e32 v0, v14, v2, vcc_lo                      // 000000834DA4: 0200050E
	.long 0xd72c000e                                           // 000000834DA8: D72C000E
	v_cndmask_b32_e32 v1, s18, v14, vcc_lo                     // 000000834DAC: 02021C12
	s_add_u32 s10, s10, s14                                    // 000000834DB0: 800A0E0A
	s_addc_u32 s11, s11, 0                                     // 000000834DB4: 820B800B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000834DB8: BF870159
	s_lshr_b64 s[10:11], s[10:11], 5                           // 000000834DBC: 858A850A
	s_waitcnt vmcnt(1)                                         // 000000834DC0: BF8907F7
	v_bfe_u32 v12, v4, 16, 1                                   // 000000834DC4: D610000C 02052104
	s_waitcnt vmcnt(0)                                         // 000000834DCC: BF8903F7
	v_bfe_u32 v19, v7, 16, 1                                   // 000000834DD0: D6100013 02052107
	v_add3_u32 v4, v4, v12, 0x7fff                             // 000000834DD8: D6550004 03FE1904 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000834DE4: BF8701A2
	v_add3_u32 v7, v7, v19, 0x7fff                             // 000000834DE8: D6550007 03FE2707 00007FFF
	v_lshlrev_b32_e32 v19, 2, v0                               // 000000834DF4: 30260082
	.long 0x7e103984                                           // 000000834DF8: 7E103984
	v_mov_b32_e32 v4, 0                                        // 000000834DFC: 7E080280
	.long 0xd72c000d                                           // 000000834E00: D72C000D
	v_cndmask_b32_e32 v1, s19, v11, vcc_lo                     // 000000834E04: 02021613
	v_mad_u64_u32 v[5:6], null, s18, v11, 0                    // 000000834E08: D6FE7C05 02021612
	.long 0xd72c000f                                           // 000000834E10: D72C000F
	v_cndmask_b32_e32 v0, v11, v3, vcc_lo                      // 000000834E14: 0200070B
	v_mad_u64_u32 v[11:12], null, v11, s2, s[12:13]            // 000000834E18: D6FE7C0B 0030050B
	v_and_or_b32 v7, 0xffff0000, v7, v8                        // 000000834E20: D6570007 04220EFF FFFF0000
	.long 0xd4440002                                           // 000000834E2C: D4440002
	v_cndmask_b32_e32 v1, s10, v16, vcc_lo                     // 000000834E30: 0202200A
	v_add3_u32 v6, v6, v14, v13                                // 000000834E34: D6550006 04361D06
	ds_store_b32 v19, v7                                       // 000000834E3C: D8340000 00000713
	v_add3_u32 v0, v20, v12, v15                               // 000000834E44: D6550000 043E1914
	s_waitcnt lgkmcnt(0)                                       // 000000834E4C: BF89FC07
	s_barrier                                                  // 000000834E50: BFBD0000
	buffer_gl0_inv                                             // 000000834E54: E0AC0000 00000000
	s_and_saveexec_b32 s11, s2                                 // 000000834E5C: BE8B2002
	s_cbranch_execz 26                                         // 000000834E60: BFA5001A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x1cc>
	s_add_u32 s3, s4, s16                                      // 000000834E64: 80031004
	s_addc_u32 s12, s5, s17                                    // 000000834E68: 820C1105
	v_lshlrev_b32_e32 v1, 1, v16                               // 000000834E6C: 30022081
	.long 0xd7000302                                           // 000000834E70: D7000302
	v_cndmask_b32_e32 v1, s3, v5, vcc_lo                       // 000000834E74: 02020A03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000834E78: BF8701A1
	v_add_co_ci_u32_e64 v3, null, s12, v6, s3                  // 000000834E7C: D5207C03 000E0C0C
	v_lshlrev_b32_e32 v4, 4, v16                               // 000000834E84: 30082084
	.long 0xd7000301                                           // 000000834E88: D7000301
	v_cndmask_b32_e32 v1, v2, v1, vcc_lo                       // 000000834E8C: 02020302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000834E90: BF870191
	v_add_co_ci_u32_e64 v2, null, 0, v3, s3                    // 000000834E94: D5207C02 000E0680
	.long 0xd7000303                                           // 000000834E9C: D7000303
	v_cndmask_b32_e32 v1, v11, v4, vcc_lo                      // 000000834EA0: 0202090B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000834EA4: BF870001
	v_add_co_ci_u32_e64 v4, null, 0, v0, s3                    // 000000834EA8: D5207C04 000E0080
	s_clause 0x1                                               // 000000834EB0: BF850001
	global_load_d16_b16 v7, v[1:2], off                        // 000000834EB4: DC820000 077C0001
	global_load_b128 v[1:4], v[3:4], off                       // 000000834EBC: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 000000834EC4: BF8907F7
	v_cvt_f32_f16_e32 v18, v7                                  // 000000834EC8: 7E241707
	s_or_b32 exec_lo, exec_lo, s11                             // 000000834ECC: 8C7E0B7E
	s_and_saveexec_b32 s11, s2                                 // 000000834ED0: BE8B2002
	s_cbranch_execz 227                                        // 000000834ED4: BFA500E3 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x564>
	v_dual_mov_b32 v20, v16 :: v_dual_lshlrev_b32 v7, 1, v16   // 000000834ED8: CA220110 14062081
	.long 0xd7000205                                           // 000000834EE0: D7000205
	v_cndmask_b32_e32 v1, s16, v5, vcc_lo                      // 000000834EE4: 02020A10
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000834EE8: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s17, v6, s2                  // 000000834EEC: D5207C06 000A0C11
	v_dual_mov_b32 v13, 0 :: v_dual_lshlrev_b32 v12, 5, v16    // 000000834EF4: CA220080 0D0C2085
	.long 0xd7000205                                           // 000000834EFC: D7000205
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 000000834F00: 02020F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000834F04: BF8701A1
	v_add_co_ci_u32_e64 v6, null, 0, v6, s2                    // 000000834F08: D5207C06 000A0C80
	v_lshl_or_b32 v19, v16, 4, 0x200                           // 000000834F10: D6560013 03FD0910 00000200
	.long 0xd7000205                                           // 000000834F1C: D7000205
	v_cndmask_b32_e32 v1, s4, v5, vcc_lo                       // 000000834F20: 02020A04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000834F24: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s5, v6, s2                   // 000000834F28: D5207C06 000A0C05
	v_mov_b32_e32 v17, v13                                     // 000000834F30: 7E22030D
	.long 0xd700020e                                           // 000000834F34: D700020E
	v_cndmask_b32_e32 v0, v5, v192, vcc_lo                     // 000000834F38: 02018105
	s_delay_alu instid0(VALU_DEP_1)                            // 000000834F3C: BF870001
	v_add_co_ci_u32_e64 v15, null, 0, v6, s2                   // 000000834F40: D5207C0F 000A0C80
	v_mov_b32_e32 v21, v18                                     // 000000834F48: 7E2A0312
	s_mov_b32 s4, 0                                            // 000000834F4C: BE840080
	s_branch 170                                               // 000000834F50: BFA000AA <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x4fc>
	s_or_b32 exec_lo, exec_lo, s5                              // 000000834F54: 8C7E057E
	.long 0xd73c0016                                           // 000000834F58: D73C0016
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 000000834F5C: 02021881
	v_and_b32_e32 v38, 0xff, v1                                // 000000834F60: 364C02FF 000000FF
	v_lshrrev_b32_e32 v39, 6, v1                               // 000000834F68: 324E0286
	v_lshrrev_b32_e32 v40, 14, v1                              // 000000834F6C: 3250028E
	v_lshrrev_b32_e32 v1, 22, v1                               // 000000834F70: 32020296
	v_and_b32_e32 v41, 0xff, v2                                // 000000834F74: 365204FF 000000FF
	.long 0xd7000322                                           // 000000834F7C: D7000322
	v_cndmask_b32_e32 v1, s6, v22, vcc_lo                      // 000000834F80: 02022C06
	s_delay_alu instid0(VALU_DEP_1)                            // 000000834F84: BF870001
	v_add_co_ci_u32_e64 v35, null, s7, v23, s3                 // 000000834F88: D5207C23 000E2E07
	v_lshlrev_b32_e32 v38, 2, v38                              // 000000834F90: 304C4C82
	v_and_b32_e32 v39, 0x3fc, v39                              // 000000834F94: 364E4EFF 000003FC
	v_and_b32_e32 v40, 0x3fc, v40                              // 000000834F9C: 365050FF 000003FC
	s_clause 0x3                                               // 000000834FA4: BF850003
	global_load_b128 v[22:25], v[34:35], off                   // 000000834FA8: DC5E0000 167C0022
	global_load_b128 v[26:29], v[34:35], off offset:16         // 000000834FB0: DC5E0010 1A7C0022
	global_load_b128 v[30:33], v[34:35], off offset:32         // 000000834FB8: DC5E0020 1E7C0022
	global_load_b128 v[34:37], v[34:35], off offset:48         // 000000834FC0: DC5E0030 227C0022
	v_lshrrev_b32_e32 v42, 6, v2                               // 000000834FC8: 32540486
	ds_load_b32 v38, v38                                       // 000000834FCC: D8D80000 26000026
	ds_load_b32 v39, v39                                       // 000000834FD4: D8D80000 27000027
	ds_load_b32 v40, v40                                       // 000000834FDC: D8D80000 28000028
	v_lshrrev_b32_e32 v43, 14, v2                              // 000000834FE4: 3256048E
	v_lshrrev_b32_e32 v2, 22, v2                               // 000000834FE8: 32040496
	v_and_b32_e32 v1, 0x3fc, v1                                // 000000834FEC: 360202FF 000003FC
	v_lshlrev_b32_e32 v41, 2, v41                              // 000000834FF4: 30525282
	v_and_b32_e32 v42, 0x3fc, v42                              // 000000834FF8: 365454FF 000003FC
	v_and_b32_e32 v43, 0x3fc, v43                              // 000000835000: 365656FF 000003FC
	v_and_b32_e32 v2, 0x3fc, v2                                // 000000835008: 360404FF 000003FC
	ds_load_b32 v1, v1                                         // 000000835010: D8D80000 01000001
	ds_load_b32 v41, v41                                       // 000000835018: D8D80000 29000029
	ds_load_b32 v42, v42                                       // 000000835020: D8D80000 2A00002A
	ds_load_b32 v43, v43                                       // 000000835028: D8D80000 2B00002B
	ds_load_b32 v2, v2                                         // 000000835030: D8D80000 02000002
	s_and_b32 s3, exec_lo, s2                                  // 000000835038: 8B03027E
	.long 0xd700020e                                           // 00000083503C: D700020E
	v_cndmask_b32_e32 v0, v14, v192, vcc_lo                    // 000000835040: 0201810E
	v_add_nc_u32_e32 v12, 0x400, v12                           // 000000835044: 4A1818FF 00000400
	v_add_nc_u32_e32 v19, 0x200, v19                           // 00000083504C: 4A2626FF 00000200
	v_add_co_ci_u32_e64 v15, null, 0, v15, s2                  // 000000835054: D5207C0F 000A1E80
	s_or_b32 s4, s3, s4                                        // 00000083505C: 8C040403
	s_waitcnt vmcnt(3) lgkmcnt(7)                              // 000000835060: BF890C77
	v_dot2_f32_bf16 v22, v22, v38, 0                           // 000000835064: CC1A4016 1A024D16
	v_lshrrev_b32_e32 v38, 14, v3                              // 00000083506C: 324C068E
	s_waitcnt lgkmcnt(6)                                       // 000000835070: BF89FC67
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000835074: BF8701A2
	v_dot2_f32_bf16 v22, v23, v39, v22                         // 000000835078: CC1A4016 1C5A4F17
	v_and_b32_e32 v23, 0xff, v3                                // 000000835080: 362E06FF 000000FF
	v_and_b32_e32 v38, 0x3fc, v38                              // 000000835088: 364C4CFF 000003FC
	s_waitcnt lgkmcnt(5)                                       // 000000835090: BF89FC57
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000835094: BF8701C3
	v_dot2_f32_bf16 v22, v24, v40, v22                         // 000000835098: CC1A4016 1C5A5118
	v_lshrrev_b32_e32 v24, 6, v3                               // 0000008350A0: 32300686
	v_lshrrev_b32_e32 v3, 22, v3                               // 0000008350A4: 32060696
	s_waitcnt lgkmcnt(4)                                       // 0000008350A8: BF89FC47
	v_dot2_f32_bf16 v1, v25, v1, v22                           // 0000008350AC: CC1A4001 1C5A0319
	v_lshlrev_b32_e32 v22, 2, v23                              // 0000008350B4: 302C2E82
	v_and_b32_e32 v24, 0x3fc, v24                              // 0000008350B8: 363030FF 000003FC
	v_and_b32_e32 v23, 0xff, v4                                // 0000008350C0: 362E08FF 000000FF
	v_lshrrev_b32_e32 v25, 6, v4                               // 0000008350C8: 32320886
	s_waitcnt vmcnt(2) lgkmcnt(3)                              // 0000008350CC: BF890837
	v_dot2_f32_bf16 v1, v26, v41, v1                           // 0000008350D0: CC1A4001 1C06531A
	ds_load_b32 v22, v22                                       // 0000008350D8: D8D80000 16000016
	ds_load_b32 v24, v24                                       // 0000008350E0: D8D80000 18000018
	v_lshrrev_b32_e32 v26, 14, v4                              // 0000008350E8: 3234088E
	v_lshrrev_b32_e32 v4, 22, v4                               // 0000008350EC: 32080896
	s_waitcnt lgkmcnt(4)                                       // 0000008350F0: BF89FC47
	v_dot2_f32_bf16 v1, v27, v42, v1                           // 0000008350F4: CC1A4001 1C06551B
	ds_load_b32 v27, v38                                       // 0000008350FC: D8D80000 1B000026
	v_and_b32_e32 v3, 0x3fc, v3                                // 000000835104: 360606FF 000003FC
	v_lshlrev_b32_e32 v23, 2, v23                              // 00000083510C: 302E2E82
	v_and_b32_e32 v25, 0x3fc, v25                              // 000000835110: 363232FF 000003FC
	s_waitcnt lgkmcnt(4)                                       // 000000835118: BF89FC47
	v_dot2_f32_bf16 v1, v28, v43, v1                           // 00000083511C: CC1A4001 1C06571C
	v_and_b32_e32 v26, 0x3fc, v26                              // 000000835124: 363434FF 000003FC
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000083512C: 360808FF 000003FC
	s_waitcnt lgkmcnt(3)                                       // 000000835134: BF89FC37
	s_delay_alu instid0(VALU_DEP_3)                            // 000000835138: BF870003
	v_dot2_f32_bf16 v1, v29, v2, v1                            // 00000083513C: CC1A4001 1C06051D
	ds_load_b32 v2, v3                                         // 000000835144: D8D80000 02000003
	ds_load_b32 v3, v23                                        // 00000083514C: D8D80000 03000017
	ds_load_b32 v23, v25                                       // 000000835154: D8D80000 17000019
	ds_load_b32 v25, v26                                       // 00000083515C: D8D80000 1900001A
	ds_load_b32 v4, v4                                         // 000000835164: D8D80000 04000004
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 00000083516C: BF890477
	v_dot2_f32_bf16 v1, v30, v22, v1                           // 000000835170: CC1A4001 1C062D1E
	s_waitcnt lgkmcnt(6)                                       // 000000835178: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000083517C: BF8700A1
	v_dot2_f32_bf16 v1, v31, v24, v1                           // 000000835180: CC1A4001 1C06311F
	s_waitcnt lgkmcnt(5)                                       // 000000835188: BF89FC57
	v_dot2_f32_bf16 v1, v32, v27, v1                           // 00000083518C: CC1A4001 1C063720
	s_waitcnt lgkmcnt(4)                                       // 000000835194: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000835198: BF870131
	v_dot2_f32_bf16 v1, v33, v2, v1                            // 00000083519C: CC1A4001 1C060521
	v_mov_b32_e32 v2, v6                                       // 0000008351A4: 7E040306
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 0000008351A8: BF890037
	v_dot2_f32_bf16 v1, v34, v3, v1                            // 0000008351AC: CC1A4001 1C060722
	v_mov_b32_e32 v3, v7                                       // 0000008351B4: 7E060307
	s_waitcnt lgkmcnt(2)                                       // 0000008351B8: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008351BC: BF8700A2
	v_dot2_f32_bf16 v1, v35, v23, v1                           // 0000008351C0: CC1A4001 1C062F23
	s_waitcnt lgkmcnt(1)                                       // 0000008351C8: BF89FC17
	v_dot2_f32_bf16 v1, v36, v25, v1                           // 0000008351CC: CC1A4001 1C063324
	s_waitcnt lgkmcnt(0)                                       // 0000008351D4: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008351D8: BF870121
	v_dot2_f32_bf16 v22, v37, v4, v1                           // 0000008351DC: CC1A4016 1C060925
	v_dual_mov_b32 v4, v8 :: v_dual_mov_b32 v1, v5             // 0000008351E4: CA100108 04000105
	v_dual_fmac_f32 v17, v18, v22 :: v_dual_mov_b32 v18, v21   // 0000008351EC: C8102D12 11120115
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000008351F4: 917E047E
	s_cbranch_execz 25                                         // 0000008351F8: BFA50019 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x560>
	s_waitcnt vmcnt(0)                                         // 0000008351FC: BF8903F7
	v_dual_mov_b32 v5, v1 :: v_dual_add_nc_u32 v20, 32, v20    // 000000835200: CA200101 051428A0
	v_dual_mov_b32 v6, v2 :: v_dual_mov_b32 v7, v3             // 000000835208: CA100102 06060103
	v_mov_b32_e32 v8, v4                                       // 000000835210: 7E100304
	s_delay_alu instid0(VALU_DEP_3)                            // 000000835214: BF870003
	.long 0xd4430002                                           // 000000835218: D4430002
	v_cndmask_b32_e32 v1, s10, v20, vcc_lo                     // 00000083521C: 0202280A
	s_mov_b32 s5, exec_lo                                      // 000000835220: BE85007E
	.long 0xd4c4007e                                           // 000000835224: D4C4007E
	v_cndmask_b32_e32 v1, s10, v20, vcc_lo                     // 000000835228: 0202280A
	s_cbranch_execz 65353                                      // 00000083522C: BFA5FF49 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x254>
	.long 0xd7000305                                           // 000000835230: D7000305
	v_cndmask_b32_e32 v1, v11, v19, vcc_lo                     // 000000835234: 0202270B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000835238: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v0, s3                    // 00000083523C: D5207C06 000E0080
	global_load_d16_b16 v21, v[14:15], off                     // 000000835244: DC820000 157C000E
	global_load_b128 v[5:8], v[5:6], off                       // 00000083524C: DC5E0000 057C0005
	s_waitcnt vmcnt(1)                                         // 000000835254: BF8907F7
	v_cvt_f32_f16_e32 v21, v21                                 // 000000835258: 7E2A1715
	s_branch 65341                                             // 00000083525C: BFA0FF3D <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x254>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000835260: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000835264: BF8700B9
	s_or_b32 exec_lo, exec_lo, s11                             // 000000835268: 8C7E0B7E
	.long 0xd71f0000                                           // 00000083526C: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000835270: 020100C1
	s_waitcnt vmcnt(0)                                         // 000000835274: BF8903F7
	v_xor_b32_e32 v1, 16, v0                                   // 000000835278: 3A020090
	v_xor_b32_e32 v2, 8, v0                                    // 00000083527C: 3A040088
	v_xor_b32_e32 v3, 4, v0                                    // 000000835280: 3A060084
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000835284: BF870093
	.long 0xd44c0002                                           // 000000835288: D44C0002
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 00000083528C: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s2                           // 000000835290: D5010001 000A0300
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000835298: BF870114
	.long 0xd44c0002                                           // 00000083529C: D44C0002
	v_cndmask_b32_e32 v1, 32, v2, vcc_lo                       // 0000008352A0: 020204A0
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000008352A4: 30020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000008352A8: BF8700D2
	v_cndmask_b32_e64 v2, v0, v2, s2                           // 0000008352AC: D5010002 000A0500
	.long 0xd44c0002                                           // 0000008352B4: D44C0002
	v_cndmask_b32_e32 v1, 32, v3, vcc_lo                       // 0000008352B8: 020206A0
	ds_bpermute_b32 v1, v1, v17                                // 0000008352BC: DACC0000 01001101
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000008352C4: 30040482
	v_cndmask_b32_e64 v3, v0, v3, s2                           // 0000008352C8: D5010003 000A0700
	v_lshlrev_b32_e32 v3, 2, v3                                // 0000008352D0: 30060682
	s_waitcnt lgkmcnt(0)                                       // 0000008352D4: BF89FC07
	v_add_f32_e32 v1, v17, v1                                  // 0000008352D8: 06020311
	ds_bpermute_b32 v2, v2, v1                                 // 0000008352DC: DACC0000 02000102
	s_waitcnt lgkmcnt(0)                                       // 0000008352E4: BF89FC07
	v_add_f32_e32 v1, v1, v2                                   // 0000008352E8: 06020501
	ds_bpermute_b32 v2, v3, v1                                 // 0000008352EC: DACC0000 02000103
	v_xor_b32_e32 v3, 2, v0                                    // 0000008352F4: 3A060082
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008352F8: BF870091
	.long 0xd44c0002                                           // 0000008352FC: D44C0002
	v_cndmask_b32_e32 v1, 32, v3, vcc_lo                       // 000000835300: 020206A0
	v_cndmask_b32_e64 v3, v0, v3, s2                           // 000000835304: D5010003 000A0700
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000083530C: BF8700D1
	v_lshlrev_b32_e32 v3, 2, v3                                // 000000835310: 30060682
	s_waitcnt lgkmcnt(0)                                       // 000000835314: BF89FC07
	v_add_f32_e32 v1, v1, v2                                   // 000000835318: 06020501
	ds_bpermute_b32 v2, v3, v1                                 // 00000083531C: DACC0000 02000103
	v_xor_b32_e32 v3, 1, v0                                    // 000000835324: 3A060081
	.long 0xd44c0002                                           // 000000835328: D44C0002
	v_cndmask_b32_e32 v1, 32, v3, vcc_lo                       // 00000083532C: 020206A0
	s_delay_alu instid0(VALU_DEP_1)                            // 000000835330: BF870001
	v_cndmask_b32_e64 v3, v0, v3, s2                           // 000000835334: D5010003 000A0700
	.long 0xd44a0002                                           // 00000083533C: D44A0002
	v_cndmask_b32_e32 v1, 0, v16, vcc_lo                       // 000000835340: 02022080
	s_and_b32 s2, s2, vcc_lo                                   // 000000835344: 8B026A02
	s_waitcnt lgkmcnt(0)                                       // 000000835348: BF89FC07
	v_dual_add_f32 v0, v1, v2 :: v_dual_lshlrev_b32 v1, 2, v3  // 00000083534C: C9220501 00000682
	ds_bpermute_b32 v1, v1, v0                                 // 000000835354: DACC0000 01000001
	s_and_saveexec_b32 s3, s2                                  // 00000083535C: BE832002
	s_cbranch_execz 53                                         // 000000835360: BFA50035 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x738>
	s_load_b32 s0, s[0:1], 0x48                                // 000000835364: F4000000 F8000048
	s_waitcnt lgkmcnt(0)                                       // 00000083536C: BF89FC07
	v_add_f32_e32 v0, v0, v1                                   // 000000835370: 06000300
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000835374: BF870091
	v_bfe_u32 v1, v0, 16, 1                                    // 000000835378: D6100001 02052100
	v_add3_u32 v0, v0, v1, 0x7fff                              // 000000835380: D6550000 03FE0300 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000083538C: BF870091
	v_and_b32_e32 v0, 0xffff0000, v0                           // 000000835390: 360000FF FFFF0000
	v_mul_f32_e32 v0, s0, v0                                   // 000000835398: 10000000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000083539C: BF870091
	v_mul_f32_e32 v0, 0xbfb8aa3b, v0                           // 0000008353A0: 100000FF BFB8AA3B
	v_exp_f32_e32 v0, v0                                       // 0000008353A8: 7E004B00
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008353AC: BF870095
	v_add_f32_e32 v0, 1.0, v0                                  // 0000008353B0: 060000F2
	v_div_scale_f32 v1, null, v0, v0, 1.0                      // 0000008353B4: D6FC7C01 03CA0100
	v_div_scale_f32 v4, vcc_lo, 1.0, v0, 1.0                   // 0000008353BC: D6FC6A04 03CA00F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000008353C4: BF870292
	v_rcp_f32_e32 v2, v1                                       // 0000008353C8: 7E045501
	v_fma_f32 v3, -v1, v2, 1.0                                 // 0000008353CC: D6130003 23CA0501
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008353D4: BF870091
	v_fmac_f32_e32 v2, v3, v2                                  // 0000008353D8: 56040503
	v_mul_f32_e32 v3, v4, v2                                   // 0000008353DC: 10060504
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008353E0: BF870091
	v_fma_f32 v5, -v1, v3, v4                                  // 0000008353E4: D6130005 24120701
	v_fmac_f32_e32 v3, v5, v2                                  // 0000008353EC: 56060505
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008353F0: BF870091
	v_fma_f32 v1, -v1, v3, v4                                  // 0000008353F4: D6130001 24120701
	v_div_fmas_f32 v1, v1, v2, v3                              // 0000008353FC: D6370001 040E0501
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000835404: BF870121
	v_div_fixup_f32 v2, v1, v0, 1.0                            // 000000835408: D6270002 03CA0101
	.long 0xd73c0000                                           // 000000835410: D73C0000
	v_cndmask_b32_e32 v1, 2, v9, vcc_lo                        // 000000835414: 02021282
	v_add_f32_e32 v2, v2, v2                                   // 000000835418: 06040502
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000083541C: BF870092
	.long 0xd7006a00                                           // 000000835420: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 000000835424: 02020008
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 000000835428: D5207C01 01AA0209
	global_store_b32 v[0:1], v2, off                           // 000000835430: DC6A0000 007C0200
	s_endpgm                                                   // 000000835438: BFB00000
		...

