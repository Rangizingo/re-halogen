0000000000804e00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000804E00: F4100100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 000000804E08: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 000000804E0C: 32040082
	v_lshrrev_b32_e32 v22, 5, v0                               // 000000804E10: 322C0085
	v_and_b32_e32 v23, 31, v0                                  // 000000804E14: 362E009F
	.long 0x7f0a3880                                           // 000000804E18: 7F0A3880
	v_lshlrev_b32_e32 v21, 2, v0                               // 000000804E1C: 302A0082
	s_waitcnt lgkmcnt(0)                                       // 000000804E20: BF89FC07
	.long 0xd4510000                                           // 000000804E24: D4510000
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 000000804E28: 02001802
	s_and_b32 s0, s0, exec_lo                                  // 000000804E2C: 8B007E00
	s_cselect_b32 s20, s3, 0                                   // 000000804E30: 98148003
	s_cselect_b32 s21, s2, 0                                   // 000000804E34: 98158002
	s_add_u32 s0, s4, s16                                      // 000000804E38: 80001004
	s_addc_u32 s1, s5, s17                                     // 000000804E3C: 82011105
	v_and_b32_e32 v1, 15, v0                                   // 000000804E40: 3602008F
	v_and_b32_e32 v2, 60, v2                                   // 000000804E44: 360404BC
	s_ashr_i32 s16, s11, 31                                    // 000000804E48: 86109F0B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000804E4C: BF870119
	s_lshr_b32 s16, s16, 27                                    // 000000804E50: 85109B10
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000804E54: 30020282
	s_add_u32 s16, s10, s16                                    // 000000804E58: 8010100A
	s_clause 0x1                                               // 000000804E5C: BF850001
	global_load_b32 v3, v1, s[4:5]                             // 000000804E60: DC520000 03040001
	global_load_b32 v4, v2, s[4:5]                             // 000000804E68: DC520000 04040002
	s_addc_u32 s17, s11, 0                                     // 000000804E70: 8211800B
	v_mov_b32_e32 v2, s1                                       // 000000804E74: 7E040201
	s_lshr_b64 s[16:17], s[16:17], 5                           // 000000804E78: 85908510
	v_mov_b32_e32 v1, s0                                       // 000000804E7C: 7E020200
	s_add_i32 s17, s16, 7                                      // 000000804E80: 81118710
	s_mul_i32 s1, s19, s21                                     // 000000804E84: 96011513
	s_ashr_i32 s22, s17, 31                                    // 000000804E88: 86169F11
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000804E8C: BF8704B9
	s_lshr_b32 s0, s22, 29                                     // 000000804E90: 85009D16
	v_mad_u64_u32 v[17:18], null, s18, s21, v[1:2]             // 000000804E94: D6FE7C11 04042A12
	s_add_i32 s17, s17, s0                                     // 000000804E9C: 81110011
	s_ashr_i32 s0, s17, 3                                      // 000000804EA0: 86008311
	s_cmpk_lt_i32 s16, 0x801                                   // 000000804EA4: B3900801
	.long 0xd72c0001                                           // 000000804EA8: D72C0001
	v_cndmask_b32_e32 v1, s0, v22, vcc_lo                      // 000000804EAC: 02022C00
	s_mul_i32 s17, s18, s20                                    // 000000804EB0: 96111412
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000804EB4: BF870141
	v_add_nc_u32_e32 v7, s0, v1                                // 000000804EB8: 4A0E0200
	v_add_nc_u32_e32 v24, v1, v23                              // 000000804EBC: 4A302F01
	s_cselect_b32 s0, -1, 0                                    // 000000804EC0: 980080C1
	s_cmpk_gt_i32 s16, 0x800                                   // 000000804EC4: B2900800
	v_min_i32_e32 v25, s16, v7                                 // 000000804EC8: 22320E10
	s_cselect_b32 s16, -1, 0                                   // 000000804ECC: 981080C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000804ED0: BF870159
	s_and_b32 vcc_lo, exec_lo, s16                             // 000000804ED4: 8B6A107E
	s_waitcnt vmcnt(1)                                         // 000000804ED8: BF8907F7
	v_bfe_u32 v2, v3, 16, 1                                    // 000000804EDC: D6100002 02052103
	s_waitcnt vmcnt(0)                                         // 000000804EE4: BF8903F7
	v_bfe_u32 v6, v4, 16, 1                                    // 000000804EE8: D6100006 02052104
	v_add3_u32 v2, v3, v2, 0x7fff                              // 000000804EF0: D6550002 03FE0503 00007FFF
	v_add_nc_u32_e32 v3, s1, v18                               // 000000804EFC: 4A062401
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000804F00: BF870223
	v_add3_u32 v4, v4, v6, 0x7fff                              // 000000804F04: D6550004 03FE0D04 00007FFF
	.long 0xd4410001                                           // 000000804F10: D4410001
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 000000804F14: 02023318
	.long 0x7e0a3982                                           // 000000804F18: 7E0A3982
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000804F1C: BF870114
	v_add_nc_u32_e32 v26, s17, v3                              // 000000804F20: 4A340611
	v_and_or_b32 v1, 0xffff0000, v4, v5                        // 000000804F24: D6570001 041608FF FFFF0000
	ds_store_b32 v21, v1                                       // 000000804F30: D8340000 00000115
	s_waitcnt lgkmcnt(0)                                       // 000000804F38: BF89FC07
	s_barrier                                                  // 000000804F3C: BFBD0000
	buffer_gl0_inv                                             // 000000804F40: E0AC0000 00000000
	s_cbranch_vccnz 154                                        // 000000804F48: BFA4009A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x3b4>
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v1, 0               // 000000804F4C: CA100080 02000080
	s_and_saveexec_b32 s17, s1                                 // 000000804F54: BE912001
	s_cbranch_execz 11                                         // 000000804F58: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x188>
	v_lshlrev_b32_e32 v1, 1, v24                               // 000000804F5C: 30023081
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000804F60: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v1                               // 000000804F64: 3408029F
	.long 0xd7006a03                                           // 000000804F68: D7006A03
	v_cndmask_b32_e32 v1, v17, v1, vcc_lo                      // 000000804F6C: 02020311
	v_add_co_ci_u32_e64 v4, null, v26, v4, vcc_lo              // 000000804F70: D5207C04 01AA091A
	global_load_d16_b16 v1, v[3:4], off                        // 000000804F78: DC820000 017C0003
	s_waitcnt vmcnt(0)                                         // 000000804F80: BF8903F7
	v_cvt_f32_f16_e32 v1, v1                                   // 000000804F84: 7E021701
	s_or_b32 exec_lo, exec_lo, s17                             // 000000804F88: 8C7E117E
	v_add_nc_u32_e32 v3, 32, v24                               // 000000804F8C: 4A0630A0
	s_mov_b32 s1, exec_lo                                      // 000000804F90: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000804F94: BF870001
	.long 0xd4c1007e                                           // 000000804F98: D4C1007E
	v_cndmask_b32_e32 v1, v3, v25, vcc_lo                      // 000000804F9C: 02023303
	s_cbranch_execz 11                                         // 000000804FA0: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x1d0>
	v_lshlrev_b32_e32 v2, 1, v3                                // 000000804FA4: 30040681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000804FA8: BF8700A1
	v_ashrrev_i32_e32 v3, 31, v2                               // 000000804FAC: 3406049F
	.long 0xd7006a02                                           // 000000804FB0: D7006A02
	v_cndmask_b32_e32 v1, v17, v2, vcc_lo                      // 000000804FB4: 02020511
	v_add_co_ci_u32_e64 v3, null, v26, v3, vcc_lo              // 000000804FB8: D5207C03 01AA071A
	global_load_d16_b16 v2, v[2:3], off                        // 000000804FC0: DC820000 027C0002
	s_waitcnt vmcnt(0)                                         // 000000804FC8: BF8903F7
	v_cvt_f32_f16_e32 v2, v2                                   // 000000804FCC: 7E041702
	s_or_b32 exec_lo, exec_lo, s1                              // 000000804FD0: 8C7E017E
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v5, 64, v24      // 000000804FD4: CA200080 040430C0
	v_mov_b32_e32 v3, 0                                        // 000000804FDC: 7E060280
	s_mov_b32 s1, exec_lo                                      // 000000804FE0: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000804FE4: BF870002
	.long 0xd4c1007e                                           // 000000804FE8: D4C1007E
	v_cndmask_b32_e32 v1, v5, v25, vcc_lo                      // 000000804FEC: 02023305
	s_cbranch_execz 11                                         // 000000804FF0: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x220>
	v_lshlrev_b32_e32 v3, 1, v5                                // 000000804FF4: 30060A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000804FF8: BF8700A1
	v_ashrrev_i32_e32 v6, 31, v3                               // 000000804FFC: 340C069F
	.long 0xd7006a05                                           // 000000805000: D7006A05
	v_cndmask_b32_e32 v1, v17, v3, vcc_lo                      // 000000805004: 02020711
	v_add_co_ci_u32_e64 v6, null, v26, v6, vcc_lo              // 000000805008: D5207C06 01AA0D1A
	global_load_d16_b16 v3, v[5:6], off                        // 000000805010: DC820000 037C0005
	s_waitcnt vmcnt(0)                                         // 000000805018: BF8903F7
	v_cvt_f32_f16_e32 v3, v3                                   // 00000080501C: 7E061703
	s_or_b32 exec_lo, exec_lo, s1                              // 000000805020: 8C7E017E
	v_add_nc_u32_e32 v5, 0x60, v24                             // 000000805024: 4A0A30FF 00000060
	s_mov_b32 s1, exec_lo                                      // 00000080502C: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000805030: BF870001
	.long 0xd4c1007e                                           // 000000805034: D4C1007E
	v_cndmask_b32_e32 v1, v5, v25, vcc_lo                      // 000000805038: 02023305
	s_cbranch_execz 11                                         // 00000080503C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x26c>
	v_lshlrev_b32_e32 v4, 1, v5                                // 000000805040: 30080A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000805044: BF8700A1
	v_ashrrev_i32_e32 v5, 31, v4                               // 000000805048: 340A089F
	.long 0xd7006a04                                           // 00000080504C: D7006A04
	v_cndmask_b32_e32 v1, v17, v4, vcc_lo                      // 000000805050: 02020911
	v_add_co_ci_u32_e64 v5, null, v26, v5, vcc_lo              // 000000805054: D5207C05 01AA0B1A
	global_load_d16_b16 v4, v[4:5], off                        // 00000080505C: DC820000 047C0004
	s_waitcnt vmcnt(0)                                         // 000000805064: BF8903F7
	v_cvt_f32_f16_e32 v4, v4                                   // 000000805068: 7E081704
	s_or_b32 exec_lo, exec_lo, s1                              // 00000080506C: 8C7E017E
	v_dual_mov_b32 v6, 0 :: v_dual_add_nc_u32 v7, 0x80, v24    // 000000805070: CA200080 060630FF 00000080
	v_mov_b32_e32 v5, 0                                        // 00000080507C: 7E0A0280
	s_mov_b32 s1, exec_lo                                      // 000000805080: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000805084: BF870002
	.long 0xd4c1007e                                           // 000000805088: D4C1007E
	v_cndmask_b32_e32 v1, v7, v25, vcc_lo                      // 00000080508C: 02023307
	s_cbranch_execz 11                                         // 000000805090: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x2c0>
	v_lshlrev_b32_e32 v5, 1, v7                                // 000000805094: 300A0E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000805098: BF8700A1
	v_ashrrev_i32_e32 v8, 31, v5                               // 00000080509C: 34100A9F
	.long 0xd7006a07                                           // 0000008050A0: D7006A07
	v_cndmask_b32_e32 v1, v17, v5, vcc_lo                      // 0000008050A4: 02020B11
	v_add_co_ci_u32_e64 v8, null, v26, v8, vcc_lo              // 0000008050A8: D5207C08 01AA111A
	global_load_d16_b16 v5, v[7:8], off                        // 0000008050B0: DC820000 057C0007
	s_waitcnt vmcnt(0)                                         // 0000008050B8: BF8903F7
	v_cvt_f32_f16_e32 v5, v5                                   // 0000008050BC: 7E0A1705
	s_or_b32 exec_lo, exec_lo, s1                              // 0000008050C0: 8C7E017E
	v_add_nc_u32_e32 v7, 0xa0, v24                             // 0000008050C4: 4A0E30FF 000000A0
	s_mov_b32 s1, exec_lo                                      // 0000008050CC: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008050D0: BF870001
	.long 0xd4c1007e                                           // 0000008050D4: D4C1007E
	v_cndmask_b32_e32 v1, v7, v25, vcc_lo                      // 0000008050D8: 02023307
	s_cbranch_execz 11                                         // 0000008050DC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x30c>
	v_lshlrev_b32_e32 v6, 1, v7                                // 0000008050E0: 300C0E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008050E4: BF8700A1
	v_ashrrev_i32_e32 v7, 31, v6                               // 0000008050E8: 340E0C9F
	.long 0xd7006a06                                           // 0000008050EC: D7006A06
	v_cndmask_b32_e32 v1, v17, v6, vcc_lo                      // 0000008050F0: 02020D11
	v_add_co_ci_u32_e64 v7, null, v26, v7, vcc_lo              // 0000008050F4: D5207C07 01AA0F1A
	global_load_d16_b16 v6, v[6:7], off                        // 0000008050FC: DC820000 067C0006
	s_waitcnt vmcnt(0)                                         // 000000805104: BF8903F7
	v_cvt_f32_f16_e32 v6, v6                                   // 000000805108: 7E0C1706
	s_or_b32 exec_lo, exec_lo, s1                              // 00000080510C: 8C7E017E
	v_dual_mov_b32 v8, 0 :: v_dual_add_nc_u32 v9, 0xc0, v24    // 000000805110: CA200080 080830FF 000000C0
	v_mov_b32_e32 v7, 0                                        // 00000080511C: 7E0E0280
	s_mov_b32 s1, exec_lo                                      // 000000805120: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000805124: BF870002
	.long 0xd4c1007e                                           // 000000805128: D4C1007E
	v_cndmask_b32_e32 v1, v9, v25, vcc_lo                      // 00000080512C: 02023309
	s_cbranch_execz 11                                         // 000000805130: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x360>
	v_lshlrev_b32_e32 v7, 1, v9                                // 000000805134: 300E1281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000805138: BF8700A1
	v_ashrrev_i32_e32 v10, 31, v7                              // 00000080513C: 34140E9F
	.long 0xd7006a09                                           // 000000805140: D7006A09
	v_cndmask_b32_e32 v1, v17, v7, vcc_lo                      // 000000805144: 02020F11
	v_add_co_ci_u32_e64 v10, null, v26, v10, vcc_lo            // 000000805148: D5207C0A 01AA151A
	global_load_d16_b16 v7, v[9:10], off                       // 000000805150: DC820000 077C0009
	s_waitcnt vmcnt(0)                                         // 000000805158: BF8903F7
	v_cvt_f32_f16_e32 v7, v7                                   // 00000080515C: 7E0E1707
	s_or_b32 exec_lo, exec_lo, s1                              // 000000805160: 8C7E017E
	v_add_nc_u32_e32 v9, 0xe0, v24                             // 000000805164: 4A1230FF 000000E0
	s_mov_b32 s1, exec_lo                                      // 00000080516C: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000805170: BF870001
	.long 0xd4c1007e                                           // 000000805174: D4C1007E
	v_cndmask_b32_e32 v1, v9, v25, vcc_lo                      // 000000805178: 02023309
	s_cbranch_execz 11                                         // 00000080517C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x3ac>
	v_lshlrev_b32_e32 v8, 1, v9                                // 000000805180: 30101281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000805184: BF8700A1
	v_ashrrev_i32_e32 v9, 31, v8                               // 000000805188: 3412109F
	.long 0xd7006a08                                           // 00000080518C: D7006A08
	v_cndmask_b32_e32 v1, v17, v8, vcc_lo                      // 000000805190: 02021111
	v_add_co_ci_u32_e64 v9, null, v26, v9, vcc_lo              // 000000805194: D5207C09 01AA131A
	global_load_d16_b16 v8, v[8:9], off                        // 00000080519C: DC820000 087C0008
	s_waitcnt vmcnt(0)                                         // 0000008051A4: BF8903F7
	v_cvt_f32_f16_e32 v8, v8                                   // 0000008051A8: 7E101708
	s_or_b32 exec_lo, exec_lo, s1                              // 0000008051AC: 8C7E017E
	s_branch 9                                                 // 0000008051B0: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x3d8>
	v_mov_b32_e32 v1, 0                                        // 0000008051B4: 7E020280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008051B8: BF870001
	v_mov_b32_e32 v2, v1                                       // 0000008051BC: 7E040301
	v_mov_b32_e32 v3, v1                                       // 0000008051C0: 7E060301
	v_mov_b32_e32 v4, v1                                       // 0000008051C4: 7E080301
	v_mov_b32_e32 v5, v1                                       // 0000008051C8: 7E0A0301
	v_mov_b32_e32 v6, v1                                       // 0000008051CC: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 0000008051D0: 7E0E0301
	v_mov_b32_e32 v8, v1                                       // 0000008051D4: 7E100301
	s_add_u32 s4, s4, s14                                      // 0000008051D8: 80040E04
	s_addc_u32 s5, s5, s15                                     // 0000008051DC: 82050F05
	s_lshr_b32 s1, s11, 31                                     // 0000008051E0: 85019F0B
	v_dual_mov_b32 v9, s21 :: v_dual_mov_b32 v20, 0            // 0000008051E4: CA100015 09140080
	s_add_u32 s14, s10, s1                                     // 0000008051EC: 800E010A
	s_addc_u32 s15, s11, 0                                     // 0000008051F0: 820F800B
	.long 0xd4410001                                           // 0000008051F4: D4410001
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 0000008051F8: 02023318
	s_ashr_i64 s[14:15], s[14:15], 1                           // 0000008051FC: 868E810E
	v_dual_mov_b32 v13, 0 :: v_dual_mov_b32 v14, 0             // 000000805200: CA100080 0D0E0080
	v_mad_u64_u32 v[18:19], null, v9, s14, s[4:5]              // 000000805208: D6FE7C12 00101D09
	.long 0xd72c0009                                           // 000000805210: D72C0009
	v_cndmask_b32_e32 v0, s21, v15, vcc_lo                     // 000000805214: 02001E15
	.long 0xd72c000a                                           // 000000805218: D72C000A
	v_cndmask_b32_e32 v0, s20, v14, vcc_lo                     // 00000080521C: 02001C14
	v_dual_mov_b32 v27, 0 :: v_dual_mov_b32 v16, 0             // 000000805220: CA100080 1B100080
	v_cndmask_b32_e64 v28, 0, 1, s16                           // 000000805228: D501001C 00410280
	v_mov_b32_e32 v15, 0                                       // 000000805230: 7E1E0280
	s_delay_alu instid0(VALU_DEP_4)                            // 000000805234: BF870004
	v_add3_u32 v29, v10, v19, v9                               // 000000805238: D655001D 0426270A
	s_and_saveexec_b32 s4, s1                                  // 000000805240: BE842001
	s_cbranch_execz 22                                         // 000000805244: BFA50016 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x4a0>
	v_dual_mov_b32 v20, 0 :: v_dual_lshlrev_b32 v9, 4, v24     // 000000805248: CA220080 14083084
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000805250: BF8700A1
	v_ashrrev_i32_e32 v10, 31, v9                              // 000000805254: 3414129F
	.long 0xd7006a09                                           // 000000805258: D7006A09
	v_cndmask_b32_e32 v1, v18, v9, vcc_lo                      // 00000080525C: 02021312
	v_add_co_ci_u32_e64 v10, null, v29, v10, vcc_lo            // 000000805260: D5207C0A 01AA151D
	s_and_not1_b32 vcc_lo, exec_lo, s16                        // 000000805268: 916A107E
	global_load_b128 v[13:16], v[9:10], off                    // 00000080526C: DC5E0000 0D7C0009
	s_cbranch_vccnz 10                                         // 000000805274: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x4a0>
	v_lshlrev_b32_e32 v9, 1, v24                               // 000000805278: 30123081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000080527C: BF870091
	.long 0xd7006a09                                           // 000000805280: D7006A09
	v_cndmask_b32_e32 v1, v17, v9, vcc_lo                      // 000000805284: 02021311
	v_add_co_ci_u32_e64 v10, null, 0, v26, vcc_lo              // 000000805288: D5207C0A 01AA3480
	global_load_d16_b16 v9, v[9:10], off                       // 000000805290: DC820000 097C0009
	s_waitcnt vmcnt(0)                                         // 000000805298: BF8903F7
	v_cvt_f32_f16_e32 v20, v9                                  // 00000080529C: 7E281709
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008052A0: 8C7E047E
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v32, 0             // 0000008052A4: CA100080 1F200080
	v_mov_b32_e32 v30, 0                                       // 0000008052AC: 7E3C0280
	s_and_saveexec_b32 s14, s1                                 // 0000008052B0: BE8E2001
	s_cbranch_execz 429                                        // 0000008052B4: BFA501AD <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0xb6c>
	v_dual_mov_b32 v30, 0 :: v_dual_add_nc_u32 v9, 32, v24     // 0000008052B8: CA200080 1E0830A0
	v_dual_mov_b32 v32, 0 :: v_dual_lshlrev_b32 v19, 5, v24    // 0000008052C0: CA220080 20123085
	v_mov_b32_e32 v27, 0                                       // 0000008052C8: 7E360280
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008052CC: BF870003
	v_lshlrev_b32_e32 v33, 4, v9                               // 0000008052D0: 30421284
	v_dual_mov_b32 v31, 0 :: v_dual_lshlrev_b32 v34, 1, v9     // 0000008052D4: CA220080 1F221281
	v_mov_b32_e32 v35, v20                                     // 0000008052DC: 7E460314
	s_mul_i32 s1, s11, 6                                       // 0000008052E0: 9601860B
	s_mul_hi_u32 s15, s10, 6                                   // 0000008052E4: 968F860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 0000008052E8: 8484820A
	s_add_i32 s15, s15, s1                                     // 0000008052EC: 810F010F
	s_mul_i32 s17, s10, 6                                      // 0000008052F0: 9611860A
	s_mov_b32 s16, 0                                           // 0000008052F4: BE900080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 0000008052F8: 848A810A
	s_branch 375                                               // 0000008052FC: BFA00177 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0xadc>
	s_or_b32 exec_lo, exec_lo, s18                             // 000000805300: 8C7E127E
	v_cndmask_b32_e64 v50, v20, v1, s0                         // 000000805304: D5010032 00020314
	v_cndmask_b32_e64 v36, v1, v2, s0                          // 00000080530C: D5010024 00020501
	v_and_b32_e32 v1, 0xff, v13                                // 000000805314: 36021AFF 000000FF
	v_cndmask_b32_e64 v42, v7, v8, s0                          // 00000080531C: D501002A 00021107
	v_cndmask_b32_e64 v41, v6, v7, s0                          // 000000805324: D5010029 00020F06
	v_cndmask_b32_e64 v40, v5, v6, s0                          // 00000080532C: D5010028 00020D05
	v_cndmask_b32_e64 v39, v4, v5, s0                          // 000000805334: D5010027 00020B04
	v_lshlrev_b32_e32 v1, 2, v1                                // 00000080533C: 30020282
	v_cndmask_b32_e64 v38, v3, v4, s0                          // 000000805340: D5010026 00020903
	v_cndmask_b32_e64 v37, v2, v3, s0                          // 000000805348: D5010025 00020702
	v_mov_b32_e32 v43, v8                                      // 000000805350: 7E560308
	v_ashrrev_i32_e32 v20, 31, v19                             // 000000805354: 3428269F
	ds_load_b32 v51, v1                                        // 000000805358: D8D80000 33000001
	v_lshrrev_b32_e32 v1, 6, v13                               // 000000805360: 32021A86
	v_add_nc_u32_e32 v33, 0x200, v33                           // 000000805364: 4A4242FF 00000200
	s_and_b32 s1, exec_lo, s1                                  // 00000080536C: 8B01017E
	v_add_nc_u32_e32 v34, 64, v34                              // 000000805370: 4A4444C0
	s_or_b32 s16, s1, s16                                      // 000000805374: 8C101001
	v_and_b32_e32 v1, 0x3fc, v1                                // 000000805378: 360202FF 000003FC
	ds_load_b32 v52, v1                                        // 000000805380: D8D80000 34000001
	v_lshrrev_b32_e32 v1, 14, v13                              // 000000805388: 32021A8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000080538C: BF8700B1
	v_and_b32_e32 v1, 0x3fc, v1                                // 000000805390: 360202FF 000003FC
	ds_load_b32 v53, v1                                        // 000000805398: D8D80000 35000001
	v_lshrrev_b32_e32 v1, 22, v13                              // 0000008053A0: 32021A96
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000008053A4: 360202FF 000003FC
	ds_load_b32 v54, v1                                        // 0000008053AC: D8D80000 36000001
	v_and_b32_e32 v1, 0xff, v14                                // 0000008053B4: 36021CFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008053BC: BF8700B1
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000008053C0: 30020282
	ds_load_b32 v55, v1                                        // 0000008053C4: D8D80000 37000001
	v_lshrrev_b32_e32 v1, 6, v14                               // 0000008053CC: 32021C86
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000008053D0: 360202FF 000003FC
	ds_load_b32 v56, v1                                        // 0000008053D8: D8D80000 38000001
	v_lshrrev_b32_e32 v1, 14, v14                              // 0000008053E0: 32021C8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008053E4: BF8700B1
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000008053E8: 360202FF 000003FC
	ds_load_b32 v57, v1                                        // 0000008053F0: D8D80000 39000001
	v_lshrrev_b32_e32 v1, 22, v14                              // 0000008053F8: 32021C96
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000008053FC: 360202FF 000003FC
	ds_load_b32 v58, v1                                        // 000000805404: D8D80000 3A000001
	v_and_b32_e32 v1, 0xff, v15                                // 00000080540C: 36021EFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000805414: BF8700B1
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000805418: 30020282
	ds_load_b32 v59, v1                                        // 00000080541C: D8D80000 3B000001
	v_lshrrev_b32_e32 v1, 6, v15                               // 000000805424: 32021E86
	v_and_b32_e32 v1, 0x3fc, v1                                // 000000805428: 360202FF 000003FC
	ds_load_b32 v60, v1                                        // 000000805430: D8D80000 3C000001
	v_lshrrev_b32_e32 v1, 14, v15                              // 000000805438: 32021E8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000080543C: BF8700B1
	v_and_b32_e32 v1, 0x3fc, v1                                // 000000805440: 360202FF 000003FC
	ds_load_b32 v61, v1                                        // 000000805448: D8D80000 3D000001
	v_lshrrev_b32_e32 v1, 22, v15                              // 000000805450: 32021E96
	v_and_b32_e32 v1, 0x3fc, v1                                // 000000805454: 360202FF 000003FC
	ds_load_b32 v62, v1                                        // 00000080545C: D8D80000 3E000001
	v_and_b32_e32 v1, 0xff, v16                                // 000000805464: 360220FF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000080546C: BF8700B1
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000805470: 30020282
	ds_load_b32 v63, v1                                        // 000000805474: D8D80000 3F000001
	v_lshrrev_b32_e32 v1, 6, v16                               // 00000080547C: 32022086
	v_and_b32_e32 v1, 0x3fc, v1                                // 000000805480: 360202FF 000003FC
	ds_load_b32 v64, v1                                        // 000000805488: D8D80000 40000001
	v_lshrrev_b32_e32 v1, 14, v16                              // 000000805490: 3202208E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000805494: BF8700B1
	v_and_b32_e32 v1, 0x3fc, v1                                // 000000805498: 360202FF 000003FC
	ds_load_b32 v65, v1                                        // 0000008054A0: D8D80000 41000001
	v_lshrrev_b32_e32 v1, 22, v16                              // 0000008054A8: 32022096
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000008054AC: 360202FF 000003FC
	ds_load_b32 v66, v1                                        // 0000008054B4: D8D80000 42000001
	.long 0xd73c0001                                           // 0000008054BC: D73C0001
	v_cndmask_b32_e32 v1, 1, v19, vcc_lo                       // 0000008054C0: 02022681
	v_dual_mov_b32 v20, v35 :: v_dual_add_nc_u32 v19, 0x400, v19// 0000008054C4: CA200123 141226FF 00000400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008054D0: BF870092
	.long 0xd7006a30                                           // 0000008054D4: D7006A30
	v_cndmask_b32_e32 v1, s6, v1, vcc_lo                       // 0000008054D8: 02020206
	v_add_co_ci_u32_e64 v49, null, s7, v2, vcc_lo              // 0000008054DC: D5207C31 01AA0407
	s_clause 0x3                                               // 0000008054E4: BF850003
	global_load_b128 v[1:4], v[48:49], off                     // 0000008054E8: DC5E0000 017C0030
	global_load_b128 v[5:8], v[48:49], off offset:16           // 0000008054F0: DC5E0010 057C0030
	global_load_b128 v[13:16], v[48:49], off offset:32         // 0000008054F8: DC5E0020 0D7C0030
	global_load_b128 v[44:47], v[48:49], off offset:48         // 000000805500: DC5E0030 2C7C0030
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 000000805508: BF890CF7
	v_dot2_f32_bf16 v1, v1, v51, 0                             // 00000080550C: CC1A4001 1A026701
	s_waitcnt lgkmcnt(14)                                      // 000000805514: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000805518: BF8700A1
	v_dot2_f32_bf16 v1, v2, v52, v1                            // 00000080551C: CC1A4001 1C066902
	s_waitcnt lgkmcnt(13)                                      // 000000805524: BF89FCD7
	v_dot2_f32_bf16 v1, v3, v53, v1                            // 000000805528: CC1A4001 1C066B03
	s_waitcnt lgkmcnt(12)                                      // 000000805530: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000805534: BF8700A1
	v_dot2_f32_bf16 v1, v4, v54, v1                            // 000000805538: CC1A4001 1C066D04
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 000000805540: BF8908B7
	v_dot2_f32_bf16 v1, v5, v55, v1                            // 000000805544: CC1A4001 1C066F05
	s_waitcnt lgkmcnt(10)                                      // 00000080554C: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000805550: BF8700A1
	v_dot2_f32_bf16 v1, v6, v56, v1                            // 000000805554: CC1A4001 1C067106
	s_waitcnt lgkmcnt(9)                                       // 00000080555C: BF89FC97
	v_dot2_f32_bf16 v1, v7, v57, v1                            // 000000805560: CC1A4001 1C067307
	s_waitcnt lgkmcnt(8)                                       // 000000805568: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000080556C: BF8700A1
	v_dot2_f32_bf16 v1, v8, v58, v1                            // 000000805570: CC1A4001 1C067508
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 000000805578: BF890477
	v_dot2_f32_bf16 v1, v13, v59, v1                           // 00000080557C: CC1A4001 1C06770D
	s_waitcnt lgkmcnt(6)                                       // 000000805584: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000805588: BF8700A1
	v_dot2_f32_bf16 v1, v14, v60, v1                           // 00000080558C: CC1A4001 1C06790E
	s_waitcnt lgkmcnt(5)                                       // 000000805594: BF89FC57
	v_dot2_f32_bf16 v1, v15, v61, v1                           // 000000805598: CC1A4001 1C067B0F
	s_waitcnt lgkmcnt(4)                                       // 0000008055A0: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008055A4: BF8700A1
	v_dot2_f32_bf16 v1, v16, v62, v1                           // 0000008055A8: CC1A4001 1C067D10
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 0000008055B0: BF890037
	v_dot2_f32_bf16 v1, v44, v63, v1                           // 0000008055B4: CC1A4001 1C067F2C
	.long 0xd7006a2c                                           // 0000008055BC: D7006A2C
	v_cndmask_b32_e32 v0, v48, v10, vcc_lo                     // 0000008055C0: 02001530
	s_waitcnt lgkmcnt(2)                                       // 0000008055C4: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000008055C8: BF870132
	v_dot2_f32_bf16 v1, v45, v64, v1                           // 0000008055CC: CC1A4001 1C06812D
	v_add_co_ci_u32_e64 v45, null, s11, v49, vcc_lo            // 0000008055D4: D5207C2D 01AA620B
	s_waitcnt lgkmcnt(1)                                       // 0000008055DC: BF89FC17
	v_dot2_f32_bf16 v1, v46, v65, v1                           // 0000008055E0: CC1A4001 1C06832E
	s_waitcnt lgkmcnt(0)                                       // 0000008055E8: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008055EC: BF870091
	v_dot2_f32_bf16 v1, v47, v66, v1                           // 0000008055F0: CC1A4001 1C06852F
	v_fmac_f32_e32 v30, v50, v1                                // 0000008055F8: 563C0332
	s_clause 0x3                                               // 0000008055FC: BF850003
	global_load_b128 v[1:4], v[44:45], off                     // 000000805600: DC5E0000 017C002C
	global_load_b128 v[5:8], v[44:45], off offset:16           // 000000805608: DC5E0010 057C002C
	global_load_b128 v[13:16], v[44:45], off offset:32         // 000000805610: DC5E0020 0D7C002C
	global_load_b128 v[44:47], v[44:45], off offset:48         // 000000805618: DC5E0030 2C7C002C
	s_waitcnt vmcnt(3)                                         // 000000805620: BF890FF7
	v_dot2_f32_bf16 v1, v1, v51, 0                             // 000000805624: CC1A4001 1A026701
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000080562C: BF870091
	v_dot2_f32_bf16 v1, v2, v52, v1                            // 000000805630: CC1A4001 1C066902
	v_dot2_f32_bf16 v1, v3, v53, v1                            // 000000805638: CC1A4001 1C066B03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000805640: BF8700A1
	v_dot2_f32_bf16 v1, v4, v54, v1                            // 000000805644: CC1A4001 1C066D04
	s_waitcnt vmcnt(2)                                         // 00000080564C: BF890BF7
	v_dot2_f32_bf16 v1, v5, v55, v1                            // 000000805650: CC1A4001 1C066F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000805658: BF870091
	v_dot2_f32_bf16 v1, v6, v56, v1                            // 00000080565C: CC1A4001 1C067106
	v_dot2_f32_bf16 v1, v7, v57, v1                            // 000000805664: CC1A4001 1C067307
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000080566C: BF8700A1
	v_dot2_f32_bf16 v1, v8, v58, v1                            // 000000805670: CC1A4001 1C067508
	s_waitcnt vmcnt(1)                                         // 000000805678: BF8907F7
	v_dot2_f32_bf16 v1, v13, v59, v1                           // 00000080567C: CC1A4001 1C06770D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000805684: BF870091
	v_dot2_f32_bf16 v1, v14, v60, v1                           // 000000805688: CC1A4001 1C06790E
	v_dot2_f32_bf16 v1, v15, v61, v1                           // 000000805690: CC1A4001 1C067B0F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000805698: BF8700A1
	v_dot2_f32_bf16 v1, v16, v62, v1                           // 00000080569C: CC1A4001 1C067D10
	s_waitcnt vmcnt(0)                                         // 0000008056A4: BF8903F7
	v_dot2_f32_bf16 v1, v44, v63, v1                           // 0000008056A8: CC1A4001 1C067F2C
	.long 0xd7006a2c                                           // 0000008056B0: D7006A2C
	v_cndmask_b32_e32 v0, v48, v4, vcc_lo                      // 0000008056B4: 02000930
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008056B8: BF870122
	v_dot2_f32_bf16 v1, v45, v64, v1                           // 0000008056BC: CC1A4001 1C06812D
	v_add_co_ci_u32_e64 v45, null, s5, v49, vcc_lo             // 0000008056C4: D5207C2D 01AA6205
	v_dot2_f32_bf16 v1, v46, v65, v1                           // 0000008056CC: CC1A4001 1C06832E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008056D4: BF870091
	v_dot2_f32_bf16 v1, v47, v66, v1                           // 0000008056D8: CC1A4001 1C06852F
	v_fmac_f32_e32 v32, v50, v1                                // 0000008056E0: 56400332
	s_clause 0x3                                               // 0000008056E4: BF850003
	global_load_b128 v[1:4], v[44:45], off                     // 0000008056E8: DC5E0000 017C002C
	global_load_b128 v[5:8], v[44:45], off offset:16           // 0000008056F0: DC5E0010 057C002C
	global_load_b128 v[13:16], v[44:45], off offset:32         // 0000008056F8: DC5E0020 0D7C002C
	global_load_b128 v[44:47], v[44:45], off offset:48         // 000000805700: DC5E0030 2C7C002C
	s_waitcnt vmcnt(3)                                         // 000000805708: BF890FF7
	v_dot2_f32_bf16 v1, v1, v51, 0                             // 00000080570C: CC1A4001 1A026701
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000805714: BF870091
	v_dot2_f32_bf16 v1, v2, v52, v1                            // 000000805718: CC1A4001 1C066902
	v_dot2_f32_bf16 v1, v3, v53, v1                            // 000000805720: CC1A4001 1C066B03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000805728: BF8700A1
	v_dot2_f32_bf16 v1, v4, v54, v1                            // 00000080572C: CC1A4001 1C066D04
	s_waitcnt vmcnt(2)                                         // 000000805734: BF890BF7
	v_dot2_f32_bf16 v1, v5, v55, v1                            // 000000805738: CC1A4001 1C066F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000805740: BF870091
	v_dot2_f32_bf16 v1, v6, v56, v1                            // 000000805744: CC1A4001 1C067106
	v_dot2_f32_bf16 v1, v7, v57, v1                            // 00000080574C: CC1A4001 1C067307
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000805754: BF8700A1
	v_dot2_f32_bf16 v1, v8, v58, v1                            // 000000805758: CC1A4001 1C067508
	s_waitcnt vmcnt(1)                                         // 000000805760: BF8907F7
	v_dot2_f32_bf16 v1, v13, v59, v1                           // 000000805764: CC1A4001 1C06770D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000080576C: BF870091
	v_dot2_f32_bf16 v1, v14, v60, v1                           // 000000805770: CC1A4001 1C06790E
	v_dot2_f32_bf16 v1, v15, v61, v1                           // 000000805778: CC1A4001 1C067B0F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000805780: BF8700A1
	v_dot2_f32_bf16 v1, v16, v62, v1                           // 000000805784: CC1A4001 1C067D10
	s_waitcnt vmcnt(0)                                         // 00000080578C: BF8903F7
	v_dot2_f32_bf16 v1, v44, v63, v1                           // 000000805790: CC1A4001 1C067F2C
	.long 0xd7006a2c                                           // 000000805798: D7006A2C
	v_cndmask_b32_e32 v0, v48, v17, vcc_lo                     // 00000080579C: 02002330
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008057A0: BF870122
	v_dot2_f32_bf16 v1, v45, v64, v1                           // 0000008057A4: CC1A4001 1C06812D
	v_add_co_ci_u32_e64 v45, null, s15, v49, vcc_lo            // 0000008057AC: D5207C2D 01AA620F
	v_dot2_f32_bf16 v1, v46, v65, v1                           // 0000008057B4: CC1A4001 1C06832E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008057BC: BF870091
	v_dot2_f32_bf16 v1, v47, v66, v1                           // 0000008057C0: CC1A4001 1C06852F
	v_fmac_f32_e32 v31, v50, v1                                // 0000008057C8: 563E0332
	s_clause 0x3                                               // 0000008057CC: BF850003
	global_load_b128 v[1:4], v[44:45], off                     // 0000008057D0: DC5E0000 017C002C
	global_load_b128 v[5:8], v[44:45], off offset:16           // 0000008057D8: DC5E0010 057C002C
	global_load_b128 v[13:16], v[44:45], off offset:32         // 0000008057E0: DC5E0020 0D7C002C
	global_load_b128 v[44:47], v[44:45], off offset:48         // 0000008057E8: DC5E0030 2C7C002C
	s_waitcnt vmcnt(3)                                         // 0000008057F0: BF890FF7
	v_dot2_f32_bf16 v1, v1, v51, 0                             // 0000008057F4: CC1A4001 1A026701
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008057FC: BF870091
	v_dot2_f32_bf16 v1, v2, v52, v1                            // 000000805800: CC1A4001 1C066902
	v_dot2_f32_bf16 v1, v3, v53, v1                            // 000000805808: CC1A4001 1C066B03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000805810: BF8700A1
	v_dot2_f32_bf16 v1, v4, v54, v1                            // 000000805814: CC1A4001 1C066D04
	s_waitcnt vmcnt(2)                                         // 00000080581C: BF890BF7
	v_dot2_f32_bf16 v1, v5, v55, v1                            // 000000805820: CC1A4001 1C066F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000805828: BF870091
	v_dot2_f32_bf16 v1, v6, v56, v1                            // 00000080582C: CC1A4001 1C067106
	v_dot2_f32_bf16 v1, v7, v57, v1                            // 000000805834: CC1A4001 1C067307
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000080583C: BF8700A1
	v_dot2_f32_bf16 v1, v8, v58, v1                            // 000000805840: CC1A4001 1C067508
	s_waitcnt vmcnt(1)                                         // 000000805848: BF8907F7
	v_dot2_f32_bf16 v1, v13, v59, v1                           // 00000080584C: CC1A4001 1C06770D
	v_mov_b32_e32 v13, v9                                      // 000000805854: 7E1A0309
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000805858: BF870122
	v_dot2_f32_bf16 v1, v14, v60, v1                           // 00000080585C: CC1A4001 1C06790E
	v_mov_b32_e32 v14, v10                                     // 000000805864: 7E1C030A
	v_dot2_f32_bf16 v1, v15, v61, v1                           // 000000805868: CC1A4001 1C067B0F
	v_mov_b32_e32 v15, v11                                     // 000000805870: 7E1E030B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000805874: BF870132
	v_dot2_f32_bf16 v1, v16, v62, v1                           // 000000805878: CC1A4001 1C067D10
	v_mov_b32_e32 v16, v12                                     // 000000805880: 7E20030C
	s_waitcnt vmcnt(0)                                         // 000000805884: BF8903F7
	v_dot2_f32_bf16 v1, v44, v63, v1                           // 000000805888: CC1A4001 1C067F2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000805890: BF870091
	v_dot2_f32_bf16 v1, v45, v64, v1                           // 000000805894: CC1A4001 1C06812D
	v_dot2_f32_bf16 v1, v46, v65, v1                           // 00000080589C: CC1A4001 1C06832E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008058A4: BF870091
	v_dot2_f32_bf16 v1, v47, v66, v1                           // 0000008058A8: CC1A4001 1C06852F
	v_fmac_f32_e32 v27, v50, v1                                // 0000008058B0: 56360332
	v_dual_mov_b32 v1, v36 :: v_dual_mov_b32 v2, v37           // 0000008058B4: CA100124 01020125
	v_dual_mov_b32 v3, v38 :: v_dual_mov_b32 v4, v39           // 0000008058BC: CA100126 03040127
	v_dual_mov_b32 v5, v40 :: v_dual_mov_b32 v6, v41           // 0000008058C4: CA100128 05060129
	v_dual_mov_b32 v7, v42 :: v_dual_mov_b32 v8, v43           // 0000008058CC: CA10012A 0708012B
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 0000008058D4: 917E107E
	s_cbranch_execz 35                                         // 0000008058D8: BFA50023 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0xb68>
	s_waitcnt vmcnt(0)                                         // 0000008058DC: BF8903F7
	v_dual_mov_b32 v9, v13 :: v_dual_add_nc_u32 v24, 32, v24   // 0000008058E0: CA20010D 091830A0
	v_dual_mov_b32 v10, v14 :: v_dual_mov_b32 v11, v15         // 0000008058E8: CA10010E 0A0A010F
	v_mov_b32_e32 v12, v16                                     // 0000008058F0: 7E180310
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008058F4: BF870003
	.long 0xd4460001                                           // 0000008058F8: D4460001
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 0000008058FC: 02023318
	s_mov_b32 s18, exec_lo                                     // 000000805900: BE92007E
	.long 0xd4c1007e                                           // 000000805904: D4C1007E
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 000000805908: 02023318
	s_cbranch_execz 65148                                      // 00000080590C: BFA5FE7C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x500>
	v_ashrrev_i32_e32 v10, 31, v33                             // 000000805910: 3414429F
	.long 0xd7006a09                                           // 000000805914: D7006A09
	v_cndmask_b32_e32 v1, v18, v33, vcc_lo                     // 000000805918: 02024312
	v_mov_b32_e32 v35, v20                                     // 00000080591C: 7E460314
	s_delay_alu instid0(VALU_DEP_3)                            // 000000805920: BF870003
	v_add_co_ci_u32_e64 v10, null, v29, v10, vcc_lo            // 000000805924: D5207C0A 01AA151D
	v_cmp_ne_u32_e32 vcc_lo, 1, v28                            // 00000080592C: 7C9A3881
	global_load_b128 v[9:12], v[9:10], off                     // 000000805930: DC5E0000 097C0009
	s_cbranch_vccnz 65137                                      // 000000805938: BFA4FE71 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x500>
	v_ashrrev_i32_e32 v36, 31, v34                             // 00000080593C: 3448449F
	.long 0xd7006a23                                           // 000000805940: D7006A23
	v_cndmask_b32_e32 v1, v17, v34, vcc_lo                     // 000000805944: 02024511
	s_delay_alu instid0(VALU_DEP_1)                            // 000000805948: BF870001
	v_add_co_ci_u32_e64 v36, null, v26, v36, vcc_lo            // 00000080594C: D5207C24 01AA491A
	global_load_d16_b16 v35, v[35:36], off                     // 000000805954: DC820000 237C0023
	s_waitcnt vmcnt(0)                                         // 00000080595C: BF8903F7
	v_cvt_f32_f16_e32 v35, v35                                 // 000000805960: 7E461723
	s_branch 65126                                             // 000000805964: BFA0FE66 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x500>
	s_or_b32 exec_lo, exec_lo, s16                             // 000000805968: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000080596C: BF8700B9
	s_or_b32 exec_lo, exec_lo, s14                             // 000000805970: 8C7E0E7E
	.long 0xd71f0001                                           // 000000805974: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000805978: 020100C1
	s_mov_b32 s0, exec_lo                                      // 00000080597C: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 000000805980: 3A040290
	v_xor_b32_e32 v6, 8, v1                                    // 000000805984: 3A0C0288
	v_xor_b32_e32 v10, 4, v1                                   // 000000805988: 3A140284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000080598C: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 000000805990: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 000000805994: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 000000805998: 7C980CA0
	s_delay_alu instid0(VALU_DEP_2)                            // 00000080599C: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000008059A0: 30040482
	ds_bpermute_b32 v5, v2, v31                                // 0000008059A4: DACC0000 05001F02
	s_waitcnt lgkmcnt(0)                                       // 0000008059AC: BF89FC07
	v_add_f32_e32 v5, v31, v5                                  // 0000008059B0: 060A0B1F
	ds_bpermute_b32 v3, v2, v30                                // 0000008059B4: DACC0000 03001E02
	ds_bpermute_b32 v4, v2, v32                                // 0000008059BC: DACC0000 04002002
	ds_bpermute_b32 v2, v2, v27                                // 0000008059C4: DACC0000 02001B02
	s_waitcnt lgkmcnt(2)                                       // 0000008059CC: BF89FC27
	v_dual_add_f32 v3, v30, v3 :: v_dual_cndmask_b32 v6, v1, v6// 0000008059D0: C912071E 03060D01
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 0000008059D8: 7C9814A0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008059DC: BF870002
	v_lshlrev_b32_e32 v6, 2, v6                                // 0000008059E0: 300C0C82
	v_cndmask_b32_e32 v10, v1, v10, vcc_lo                     // 0000008059E4: 02141501
	ds_bpermute_b32 v9, v6, v5                                 // 0000008059E8: DACC0000 09000506
	s_waitcnt lgkmcnt(0)                                       // 0000008059F0: BF89FC07
	v_dual_add_f32 v5, v5, v9 :: v_dual_lshlrev_b32 v10, 2, v10// 0000008059F4: C9221305 050A1482
	ds_bpermute_b32 v7, v6, v3                                 // 0000008059FC: DACC0000 07000306
	v_add_f32_e32 v2, v27, v2                                  // 000000805A04: 0604051B
	s_waitcnt lgkmcnt(0)                                       // 000000805A08: BF89FC07
	v_dual_add_f32 v3, v3, v7 :: v_dual_add_f32 v4, v32, v4    // 000000805A0C: C9080F03 03040920
	ds_bpermute_b32 v8, v6, v4                                 // 000000805A14: DACC0000 08000406
	ds_bpermute_b32 v6, v6, v2                                 // 000000805A1C: DACC0000 06000206
	s_waitcnt lgkmcnt(0)                                       // 000000805A24: BF89FC07
	v_add_f32_e32 v2, v2, v6                                   // 000000805A28: 06040D02
	ds_bpermute_b32 v6, v10, v3                                // 000000805A2C: DACC0000 0600030A
	ds_bpermute_b32 v9, v10, v2                                // 000000805A34: DACC0000 0900020A
	s_waitcnt lgkmcnt(1)                                       // 000000805A3C: BF89FC17
	v_dual_add_f32 v3, v3, v6 :: v_dual_add_f32 v4, v4, v8     // 000000805A40: C9080D03 03041104
	ds_bpermute_b32 v8, v10, v5                                // 000000805A48: DACC0000 0800050A
	s_waitcnt lgkmcnt(1)                                       // 000000805A50: BF89FC17
	v_add_f32_e32 v6, v2, v9                                   // 000000805A54: 060C1302
	ds_bpermute_b32 v7, v10, v4                                // 000000805A58: DACC0000 0700040A
	v_xor_b32_e32 v10, 2, v1                                   // 000000805A60: 3A140282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000805A64: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 000000805A68: 7C9814A0
	v_cndmask_b32_e32 v10, v1, v10, vcc_lo                     // 000000805A6C: 02141501
	s_waitcnt lgkmcnt(1)                                       // 000000805A70: BF89FC17
	v_dual_add_f32 v5, v5, v8 :: v_dual_lshlrev_b32 v10, 2, v10// 000000805A74: C9221105 050A1482
	ds_bpermute_b32 v2, v10, v3                                // 000000805A7C: DACC0000 0200030A
	s_waitcnt lgkmcnt(1)                                       // 000000805A84: BF89FC17
	v_add_f32_e32 v4, v4, v7                                   // 000000805A88: 06080F04
	ds_bpermute_b32 v8, v10, v5                                // 000000805A8C: DACC0000 0800050A
	ds_bpermute_b32 v9, v10, v6                                // 000000805A94: DACC0000 0900060A
	ds_bpermute_b32 v7, v10, v4                                // 000000805A9C: DACC0000 0700040A
	v_xor_b32_e32 v10, 1, v1                                   // 000000805AA4: 3A140281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000805AA8: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 000000805AAC: 7C9814A0
	v_cndmask_b32_e32 v1, v1, v10, vcc_lo                      // 000000805AB0: 02021501
	s_waitcnt lgkmcnt(3)                                       // 000000805AB4: BF89FC37
	v_dual_add_f32 v1, v3, v2 :: v_dual_lshlrev_b32 v10, 2, v1 // 000000805AB8: C9220503 010A0282
	s_waitcnt lgkmcnt(2)                                       // 000000805AC0: BF89FC27
	v_add_f32_e32 v3, v5, v8                                   // 000000805AC4: 06061105
	s_waitcnt lgkmcnt(0)                                       // 000000805AC8: BF89FC07
	v_dual_add_f32 v5, v6, v9 :: v_dual_add_f32 v2, v4, v7     // 000000805ACC: C9081306 05020F04
	ds_bpermute_b32 v4, v10, v1                                // 000000805AD4: DACC0000 0400010A
	ds_bpermute_b32 v7, v10, v3                                // 000000805ADC: DACC0000 0700030A
	ds_bpermute_b32 v8, v10, v5                                // 000000805AE4: DACC0000 0800050A
	ds_bpermute_b32 v6, v10, v2                                // 000000805AEC: DACC0000 0600020A
	v_cmpx_eq_u32_e32 0, v23                                   // 000000805AF4: 7D942E80
	s_cbranch_execz 9                                          // 000000805AF8: BFA50009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0xd20>
	s_waitcnt lgkmcnt(1)                                       // 000000805AFC: BF89FC17
	v_dual_add_f32 v8, v5, v8 :: v_dual_add_f32 v7, v3, v7     // 000000805B00: C9081105 08060F03
	s_waitcnt lgkmcnt(0)                                       // 000000805B08: BF89FC07
	v_dual_add_f32 v6, v2, v6 :: v_dual_add_f32 v5, v1, v4     // 000000805B0C: C9080D02 06040901
	v_lshlrev_b32_e32 v1, 4, v22                               // 000000805B14: 30022C84
	ds_store_b128 v1, v[5:8] offset:1024                       // 000000805B18: DB7C0400 00000501
	s_or_b32 exec_lo, exec_lo, s0                              // 000000805B20: 8C7E007E
	.long 0xd4510000                                           // 000000805B24: D4510000
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 000000805B28: 02001802
	v_cmp_gt_u32_e32 vcc_lo, 4, v0                             // 000000805B2C: 7C980084
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000805B30: BF890007
	s_barrier                                                  // 000000805B34: BFBD0000
	buffer_gl0_inv                                             // 000000805B38: E0AC0000 00000000
	s_and_b32 s0, vcc_lo, s0                                   // 000000805B40: 8B00006A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000805B44: BF870009
	s_and_saveexec_b32 s1, s0                                  // 000000805B48: BE812000
	s_cbranch_execz 88                                         // 000000805B4C: BFA50058 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0xeb0>
	v_add_nc_u32_e32 v7, 0x400, v21                            // 000000805B50: 4A0E2AFF 00000400
	s_lshl_b64 s[0:1], s[2:3], 1                               // 000000805B58: 84808102
	ds_load_2addr_b32 v[1:2], v7 offset1:4                     // 000000805B5C: D8DC0400 01000007
	ds_load_2addr_b32 v[3:4], v7 offset0:8 offset1:12          // 000000805B64: D8DC0C08 03000007
	ds_load_2addr_b32 v[5:6], v7 offset0:16 offset1:20         // 000000805B6C: D8DC1410 05000007
	s_waitcnt lgkmcnt(2)                                       // 000000805B74: BF89FC27
	v_add_f32_e32 v1, 0, v1                                    // 000000805B78: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000805B7C: BF8700C1
	v_add_f32_e32 v8, v1, v2                                   // 000000805B80: 06100501
	ds_load_2addr_b32 v[1:2], v7 offset0:24 offset1:28         // 000000805B84: D8DC1C18 01000007
	s_waitcnt lgkmcnt(2)                                       // 000000805B8C: BF89FC27
	v_add_f32_e32 v3, v8, v3                                   // 000000805B90: 06060708
	v_add_f32_e32 v3, v3, v4                                   // 000000805B94: 06060903
	s_waitcnt lgkmcnt(1)                                       // 000000805B98: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000805B9C: BF870091
	v_add_f32_e32 v3, v3, v5                                   // 000000805BA0: 06060B03
	v_add_f32_e32 v3, v3, v6                                   // 000000805BA4: 06060D03
	s_waitcnt lgkmcnt(0)                                       // 000000805BA8: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000805BAC: BF870091
	v_add_f32_e32 v1, v3, v1                                   // 000000805BB0: 06020303
	v_add_f32_e32 v1, v1, v2                                   // 000000805BB4: 06020501
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000805BB8: BF870091
	v_bfe_u32 v2, v1, 16, 1                                    // 000000805BBC: D6100002 02052101
	v_add3_u32 v1, v1, v2, 0x7fff                              // 000000805BC4: D6550001 03FE0501 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000805BD0: BF870091
	v_and_b32_e32 v1, 0xffff0000, v1                           // 000000805BD4: 360202FF FFFF0000
	v_mul_f32_e32 v1, 0xbfb8aa3b, v1                           // 000000805BDC: 100202FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000805BE4: BF870291
	v_exp_f32_e32 v1, v1                                       // 000000805BE8: 7E024B01
	v_add_f32_e32 v4, 1.0, v1                                  // 000000805BEC: 060802F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000805BF0: BF870121
	v_div_scale_f32 v3, null, v4, v4, 1.0                      // 000000805BF4: D6FC7C03 03CA0904
	v_div_scale_f32 v6, vcc_lo, 1.0, v4, 1.0                   // 000000805BFC: D6FC6A06 03CA08F2
	v_rcp_f32_e32 v5, v3                                       // 000000805C04: 7E0A5503
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000805C08: BF870095
	v_fma_f32 v1, -v3, v5, 1.0                                 // 000000805C0C: D6130001 23CA0B03
	v_fmac_f32_e32 v5, v1, v5                                  // 000000805C14: 560A0B01
	v_mad_u64_u32 v[1:2], null, s12, v0, 0                     // 000000805C18: D6FE7C01 0202000C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000805C20: BF870092
	v_mul_f32_e32 v7, v6, v5                                   // 000000805C24: 100E0B06
	v_fma_f32 v8, -v3, v7, v6                                  // 000000805C28: D6130008 241A0F03
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000805C30: BF870091
	v_fmac_f32_e32 v7, v8, v5                                  // 000000805C34: 560E0B08
	v_fma_f32 v6, -v3, v7, v6                                  // 000000805C38: D6130006 241A0F03
	v_mad_u64_u32 v[2:3], null, s13, v0, v[2:3]                // 000000805C40: D6FE7C02 040A000D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000805C48: BF870092
	v_div_fmas_f32 v0, v6, v5, v7                              // 000000805C4C: D6370000 041E0B06
	v_div_fixup_f32 v3, v0, v4, 1.0                            // 000000805C54: D6270003 03CA0900
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000805C5C: BF870113
	.long 0xd73c0000                                           // 000000805C60: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 000000805C64: 02020281
	v_bfe_u32 v2, v3, 16, 1                                    // 000000805C68: D6100002 02052103
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000805C70: BF870092
	.long 0xd7006a00                                           // 000000805C74: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 000000805C78: 02020008
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 000000805C7C: D5207C01 01AA0209
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000805C84: BF870193
	v_add3_u32 v2, v3, v2, 0x7fff                              // 000000805C88: D6550002 03FE0503 00007FFF
	.long 0xd7006a00                                           // 000000805C94: D7006A00
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 000000805C98: 02000100
	s_delay_alu instid0(VALU_DEP_1)                            // 000000805C9C: BF870001
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 000000805CA0: D5207C01 01AA0201
	global_store_d16_hi_b16 v[0:1], v2, off                    // 000000805CA8: DC960000 007C0200
	s_endpgm                                                   // 000000805CB0: BFB00000
		...

