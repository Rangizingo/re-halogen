0000000000713600 <_ZN7halogen12_GLOBAL__N_16k_lq6kILi4ELi32ELi2ELb1EEEvPKhPKtPvll>:
; _ZN7halogen12_GLOBAL__N_16k_lq6kILi4ELi32ELi2ELb1EEEvPKhPKtPvll():
	s_load_b256 s[4:11], s[0:1], null                          // 000000713600: F40C0100 F8000000
	s_mov_b32 s3, 0                                            // 000000713608: BE830080
	v_bfe_u32 v5, v0, 5, 1                                     // 00000071360C: D6100005 02050B00
	s_lshl_b64 s[14:15], s[2:3], 2                             // 000000713614: 848E8202
	v_dual_mov_b32 v12, 0 :: v_dual_and_b32 v7, 31, v0         // 000000713618: CA240080 0C06009F
	v_lshrrev_b32_e32 v6, 6, v0                                // 000000713620: 320C0086
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v11, 0             // 000000713624: CA100080 0A0A0080
	v_mov_b32_e32 v13, 0                                       // 00000071362C: 7E1A0280
	s_waitcnt lgkmcnt(0)                                       // 000000713630: BF89FC07
	s_ashr_i32 s12, s11, 31                                    // 000000713634: 860C9F0B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000713638: BF870499
	s_lshr_b32 s12, s12, 28                                    // 00000071363C: 850C9C0C
	s_add_u32 s12, s10, s12                                    // 000000713640: 800C0C0A
	s_addc_u32 s13, s11, 0                                     // 000000713644: 820D800B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000713648: BF870499
	s_lshr_b64 s[16:17], s[12:13], 4                           // 00000071364C: 8590840C
	s_add_i32 s2, s16, 1                                       // 000000713650: 81028110
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000713654: BF870499
	s_lshr_b32 s12, s2, 31                                     // 000000713658: 850C9F02
	s_add_i32 s2, s2, s12                                      // 00000071365C: 81020C02
	s_load_b64 s[12:13], s[0:1], 0x20                          // 000000713660: F4040300 F8000020
	s_ashr_i32 s2, s2, 1                                       // 000000713668: 86028102
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071366C: BF870099
	.long 0xd72c0001                                           // 000000713670: D72C0001
	v_cndmask_b32_e32 v1, s2, v5, vcc_lo                       // 000000713674: 02020A02
	v_add_nc_u32_e32 v2, s2, v1                                // 000000713678: 4A040202
	v_add_nc_u32_e32 v8, v1, v7                                // 00000071367C: 4A100F01
	s_mov_b32 s2, exec_lo                                      // 000000713680: BE82007E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000713684: BF870092
	v_min_i32_e32 v9, s16, v2                                  // 000000713688: 22120410
	.long 0xd4c1007e                                           // 00000071368C: D4C1007E
	v_cndmask_b32_e32 v1, v8, v9, vcc_lo                       // 000000713690: 02021308
	s_cbranch_execz 465                                        // 000000713694: BFA501D1 <_ZN7halogen12_GLOBAL__N_16k_lq6kILi4ELi32ELi2ELb1EEEvPKhPKtPvll+0x7dc>
	.long 0xd7000001                                           // 000000713698: D7000001
	v_cndmask_b32_e32 v1, s14, v6, vcc_lo                      // 00000071369C: 02020C0E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007136A0: BF870001
	v_add_co_ci_u32_e64 v2, null, s15, 0, s0                   // 0000007136A4: D5207C02 0001000F
	s_ashr_i32 s0, s11, 31                                     // 0000007136AC: 86009F0B
	v_dual_mov_b32 v10, 0 :: v_dual_lshlrev_b32 v3, 4, v8      // 0000007136B0: CA220080 0A021084
	s_lshr_b32 s0, s0, 24                                      // 0000007136B8: 85009800
	s_waitcnt lgkmcnt(0)                                       // 0000007136BC: BF89FC07
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 0000007136C0: 7CA8020C
	s_add_u32 s0, s10, s0                                      // 0000007136C4: 8000000A
	s_addc_u32 s1, s11, 0                                      // 0000007136C8: 8201800B
	v_dual_mov_b32 v13, 0 :: v_dual_mov_b32 v12, 0             // 0000007136CC: CA100080 0D0C0080
	s_ashr_i64 s[0:1], s[0:1], 8                               // 0000007136D4: 86808800
	v_dual_cndmask_b32 v2, 0, v2 :: v_dual_cndmask_b32 v1, 0, v1// 0000007136D8: CA520480 02000280
	s_mulk_i32 s1, 0xd2                                        // 0000007136E0: B80100D2
	s_mul_hi_u32 s16, s0, 0xd2                                 // 0000007136E4: 9690FF00 000000D2
	s_mulk_i32 s0, 0xd2                                        // 0000007136EC: B80000D2
	s_add_i32 s16, s16, s1                                     // 0000007136F0: 81100110
	.long 0xd72c000b                                           // 0000007136F4: D72C000B
	v_cndmask_b32_e32 v1, s0, v2, vcc_lo                       // 0000007136F8: 02020400
	.long 0xd72c0004                                           // 0000007136FC: D72C0004
	v_cndmask_b32_e32 v1, s16, v1, vcc_lo                      // 000000713700: 02020210
	v_mad_u64_u32 v[1:2], null, s0, v1, s[4:5]                 // 000000713704: D6FE7C01 00120200
	s_mul_i32 s0, s11, 6                                       // 00000071370C: 9600860B
	s_mul_hi_u32 s1, s10, 6                                    // 000000713710: 9681860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 000000713714: 8484820A
	s_add_i32 s16, s1, s0                                      // 000000713718: 81100001
	s_mul_i32 s17, s10, 6                                      // 00000071371C: 9611860A
	s_lshl_b64 s[10:11], s[10:11], 1                           // 000000713720: 848A810A
	v_add3_u32 v2, v4, v2, v11                                 // 000000713724: D6550002 042E0504
	v_mov_b32_e32 v11, 0                                       // 00000071372C: 7E160280
	v_ashrrev_i32_e32 v14, 4, v8                               // 000000713730: 341C1084
	v_bfe_u32 v16, v8, 3, 1                                    // 000000713734: D6100010 02050708
	v_and_b32_e32 v17, 32, v3                                  // 00000071373C: 362206A0
	v_and_b32_e32 v15, 15, v8                                  // 000000713740: 361E108F
	v_and_b32_e32 v18, 16, v3                                  // 000000713744: 36240690
	.long 0xd72c000e                                           // 000000713748: D72C000E
	v_cndmask_b32_e32 v1, 0xd2, v14, vcc_lo                    // 00000071374C: 02021CFF 000000D2
	v_lshlrev_b32_e32 v19, 6, v16                              // 000000713754: 30262086
	v_lshlrev_b32_e32 v16, 5, v16                              // 000000713758: 30202085
	v_ashrrev_i32_e32 v4, 31, v3                               // 00000071375C: 3408069F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000713760: BF8700A4
	v_ashrrev_i32_e32 v20, 31, v14                             // 000000713764: 34281C9F
	.long 0xd7006a16                                           // 000000713768: D7006A16
	v_cndmask_b32_e32 v1, v1, v14, vcc_lo                      // 00000071376C: 02021D01
	v_add_co_ci_u32_e64 v23, null, v2, v20, vcc_lo             // 000000713770: D5207C17 01AA2902
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000713778: BF8701A2
	.long 0xd7006a13                                           // 00000071377C: D7006A13
	v_cndmask_b32_e32 v1, v22, v19, vcc_lo                     // 000000713780: 02022716
	.long 0xd7000010                                           // 000000713784: D7000010
	v_cndmask_b32_e32 v1, v22, v16, vcc_lo                     // 000000713788: 02022116
	v_add_co_ci_u32_e64 v20, null, 0, v23, vcc_lo              // 00000071378C: D5207C14 01AA2E80
	s_delay_alu instid0(VALU_DEP_3)                            // 000000713794: BF870003
	.long 0xd7006a13                                           // 000000713798: D7006A13
	v_cndmask_b32_e32 v1, v19, v17, vcc_lo                     // 00000071379C: 02022313
	v_add_co_ci_u32_e64 v17, null, 0, v23, s0                  // 0000007137A0: D5207C11 00022E80
	.long 0xd700010e                                           // 0000007137A8: D700010E
	v_cndmask_b32_e32 v1, v22, v15, vcc_lo                     // 0000007137AC: 02021F16
	.long 0xd7000010                                           // 0000007137B0: D7000010
	v_cndmask_b32_e32 v1, v16, v18, vcc_lo                     // 0000007137B4: 02022510
	v_add_co_ci_u32_e64 v20, null, 0, v20, vcc_lo              // 0000007137B8: D5207C14 01AA2880
	v_add_co_ci_u32_e64 v15, null, 0, v23, s1                  // 0000007137C0: D5207C0F 00062E80
	v_add_co_ci_u32_e64 v17, null, 0, v17, s0                  // 0000007137C8: D5207C11 00022280
	.long 0xd7006a12                                           // 0000007137D0: D7006A12
	v_cndmask_b32_e32 v1, v19, v18, vcc_lo                     // 0000007137D4: 02022513
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007137D8: BF870001
	v_add_co_ci_u32_e64 v19, null, 0, v20, vcc_lo              // 0000007137DC: D5207C13 01AA2880
	s_clause 0x3                                               // 0000007137E4: BF850003
	global_load_i8 v54, v[14:15], off offset:192               // 0000007137E8: DC4600C0 367C000E
	global_load_b128 v[14:17], v[16:17], off offset:128        // 0000007137F0: DC5E0080 0E7C0010
	global_load_b128 v[18:21], v[18:19], off                   // 0000007137F8: DC5E0000 127C0012
	global_load_d16_b16 v55, v[22:23], off offset:208          // 000000713800: DC8200D0 377C0016
	.long 0xd73c0016                                           // 000000713808: D73C0016
	v_cndmask_b32_e32 v1, 1, v3, vcc_lo                        // 00000071380C: 02020681
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000713810: BF870091
	.long 0xd7006a26                                           // 000000713814: D7006A26
	v_cndmask_b32_e32 v1, s6, v22, vcc_lo                      // 000000713818: 02022C06
	v_add_co_ci_u32_e64 v39, null, s7, v23, vcc_lo             // 00000071381C: D5207C27 01AA2E07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000713824: BF870092
	.long 0xd7006a2a                                           // 000000713828: D7006A2A
	v_cndmask_b32_e32 v0, v38, v10, vcc_lo                     // 00000071382C: 02001526
	v_add_co_ci_u32_e64 v43, null, s11, v39, vcc_lo            // 000000713830: D5207C2B 01AA4E0B
	.long 0xd7006a2e                                           // 000000713838: D7006A2E
	v_cndmask_b32_e32 v0, v38, v4, vcc_lo                      // 00000071383C: 02000926
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000713840: BF8700A1
	v_add_co_ci_u32_e64 v47, null, s5, v39, vcc_lo             // 000000713844: D5207C2F 01AA4E05
	.long 0xd7006a32                                           // 00000071384C: D7006A32
	v_cndmask_b32_e32 v0, v38, v17, vcc_lo                     // 000000713850: 02002326
	v_add_co_ci_u32_e64 v51, null, s16, v39, vcc_lo            // 000000713854: D5207C33 01AA4E10
	s_clause 0x7                                               // 00000071385C: BF850007
	global_load_b128 v[22:25], v[38:39], off                   // 000000713860: DC5E0000 167C0026
	global_load_b128 v[26:29], v[42:43], off                   // 000000713868: DC5E0000 1A7C002A
	global_load_b128 v[30:33], v[46:47], off                   // 000000713870: DC5E0000 1E7C002E
	global_load_b128 v[34:37], v[50:51], off                   // 000000713878: DC5E0000 227C0032
	global_load_b128 v[38:41], v[38:39], off offset:16         // 000000713880: DC5E0010 267C0026
	global_load_b128 v[42:45], v[42:43], off offset:16         // 000000713888: DC5E0010 2A7C002A
	global_load_b128 v[46:49], v[46:47], off offset:16         // 000000713890: DC5E0010 2E7C002E
	global_load_b128 v[50:53], v[50:51], off offset:16         // 000000713898: DC5E0010 327C0032
	s_waitcnt vmcnt(11)                                        // 0000007138A0: BF892FF7
	v_cvt_f32_i32_e32 v54, v54                                 // 0000007138A4: 7E6C0B36
	s_waitcnt vmcnt(8)                                         // 0000007138A8: BF8923F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000007138AC: BF870131
	v_fma_mix_f32 v54, v55, v54, neg(0) op_sel_hi:[1,0,0]      // 0000007138B0: CC200036 8A026D37
	v_and_b32_e32 v56, 6, v8                                   // 0000007138B8: 36701086
	v_and_b32_e32 v4, 4, v8                                    // 0000007138BC: 36081084
	v_or_b32_e32 v60, 16, v56                                  // 0000007138C0: 38787090
	v_or_b32_e32 v58, 8, v56                                   // 0000007138C4: 38747088
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007138C8: BF870003
	v_or_b32_e32 v59, 16, v4                                   // 0000007138CC: 38760890
	v_or_b32_e32 v62, 24, v56                                  // 0000007138D0: 387C7098
	v_lshrrev_b32_e32 v63, v56, v14                            // 0000007138D4: 327E1D38
	v_lshrrev_b32_e32 v65, v60, v14                            // 0000007138D8: 32821D3C
	v_or_b32_e32 v57, 8, v4                                    // 0000007138DC: 38720888
	v_or_b32_e32 v61, 24, v4                                   // 0000007138E0: 387A0898
	v_lshrrev_b32_e32 v64, v58, v14                            // 0000007138E4: 32801D3A
	v_lshrrev_b32_e32 v14, v62, v14                            // 0000007138E8: 321C1D3E
	v_lshrrev_b32_e32 v66, v56, v15                            // 0000007138EC: 32841F38
	v_lshrrev_b32_e32 v67, v58, v15                            // 0000007138F0: 32861F3A
	v_lshrrev_b32_e32 v68, v60, v15                            // 0000007138F4: 32881F3C
	v_lshrrev_b32_e32 v15, v62, v15                            // 0000007138F8: 321E1F3E
	v_lshrrev_b32_e32 v69, v56, v16                            // 0000007138FC: 328A2138
	v_lshrrev_b32_e32 v70, v58, v16                            // 000000713900: 328C213A
	v_lshrrev_b32_e32 v71, v60, v16                            // 000000713904: 328E213C
	v_lshrrev_b32_e32 v16, v62, v16                            // 000000713908: 3220213E
	v_lshrrev_b32_e32 v56, v56, v17                            // 00000071390C: 32702338
	v_lshrrev_b32_e32 v58, v58, v17                            // 000000713910: 3274233A
	v_lshrrev_b32_e32 v60, v60, v17                            // 000000713914: 3278233C
	v_lshrrev_b32_e32 v17, v62, v17                            // 000000713918: 3222233E
	v_bfe_u32 v55, v18, v4, 4                                  // 00000071391C: D6100037 02120912
	v_lshlrev_b32_e32 v62, 4, v63                              // 000000713924: 307C7E84
	v_bfe_u32 v72, v18, v59, 4                                 // 000000713928: D6100048 02127712
	v_lshlrev_b32_e32 v65, 4, v65                              // 000000713930: 30828284
	v_bfe_u32 v63, v18, v57, 4                                 // 000000713934: D610003F 02127312
	v_bfe_u32 v74, v19, v57, 4                                 // 00000071393C: D610004A 02127313
	v_bfe_u32 v76, v20, v4, 4                                  // 000000713944: D610004C 02120914
	v_bfe_u32 v77, v20, v57, 4                                 // 00000071394C: D610004D 02127314
	v_bfe_u32 v78, v20, v59, 4                                 // 000000713954: D610004E 02127714
	v_bfe_u32 v20, v20, v61, 4                                 // 00000071395C: D6100014 02127B14
	v_lshlrev_b32_e32 v16, 4, v16                              // 000000713964: 30202084
	v_bfe_u32 v57, v21, v57, 4                                 // 000000713968: D6100039 02127315
	v_lshlrev_b32_e32 v58, 4, v58                              // 000000713970: 30747484
	v_and_or_b32 v55, v62, 48, v55                             // 000000713974: D6570037 04DD613E
	v_and_or_b32 v62, v65, 48, v72                             // 00000071397C: D657003E 05216141
	v_and_or_b32 v16, v16, 48, v20                             // 000000713984: D6570010 04516110
	v_lshlrev_b32_e32 v56, 4, v56                              // 00000071398C: 30707084
	v_and_or_b32 v20, v58, 48, v57                             // 000000713990: D6570014 04E5613A
	v_bfe_u32 v75, v19, v59, 4                                 // 000000713998: D610004B 02127713
	v_subrev_nc_u32_e32 v57, 32, v62                           // 0000007139A0: 4E727CA0
	v_bfe_u32 v59, v21, v59, 4                                 // 0000007139A4: D610003B 02127715
	v_lshlrev_b32_e32 v60, 4, v60                              // 0000007139AC: 30787884
	v_subrev_nc_u32_e32 v20, 32, v20                           // 0000007139B0: 4E2828A0
	v_lshlrev_b32_e32 v17, 4, v17                              // 0000007139B4: 30222284
	v_cvt_f32_i32_e32 v57, v57                                 // 0000007139B8: 7E720B39
	v_subrev_nc_u32_e32 v16, 32, v16                           // 0000007139BC: 4E2020A0
	v_bfe_u32 v18, v18, v61, 4                                 // 0000007139C0: D6100012 02127B12
	v_cvt_f32_i32_e32 v20, v20                                 // 0000007139C8: 7E280B14
	v_lshlrev_b32_e32 v69, 4, v69                              // 0000007139CC: 308A8A84
	v_mul_f32_e32 v57, v54, v57                                // 0000007139D0: 10727336
	v_bfe_u32 v73, v19, v4, 4                                  // 0000007139D4: D6100049 02120913
	v_bfe_u32 v4, v21, v4, 4                                   // 0000007139DC: D6100004 02120915
	v_bfe_u32 v19, v19, v61, 4                                 // 0000007139E4: D6100013 02127B13
	v_bfe_u32 v21, v21, v61, 4                                 // 0000007139EC: D6100015 02127B15
	v_mul_f32_e32 v20, v54, v20                                // 0000007139F4: 10282936
	v_lshlrev_b32_e32 v66, 4, v66                              // 0000007139F8: 30848484
	v_and_or_b32 v4, v56, 48, v4                               // 0000007139FC: D6570004 04116138
	v_and_or_b32 v56, v60, 48, v59                             // 000000713A04: D6570038 04ED613C
	v_and_or_b32 v17, v17, 48, v21                             // 000000713A0C: D6570011 04556111
	v_lshlrev_b32_e32 v68, 4, v68                              // 000000713A14: 30888884
	v_lshlrev_b32_e32 v70, 4, v70                              // 000000713A18: 308C8C84
	v_subrev_nc_u32_e32 v4, 32, v4                             // 000000713A1C: 4E0808A0
	v_subrev_nc_u32_e32 v56, 32, v56                           // 000000713A20: 4E7070A0
	v_subrev_nc_u32_e32 v17, 32, v17                           // 000000713A24: 4E2222A0
	v_cvt_f32_i32_e32 v16, v16                                 // 000000713A28: 7E200B10
	v_lshlrev_b32_e32 v67, 4, v67                              // 000000713A2C: 30868684
	v_cvt_f32_i32_e32 v4, v4                                   // 000000713A30: 7E080B04
	v_lshlrev_b32_e32 v15, 4, v15                              // 000000713A34: 301E1E84
	v_cvt_f32_i32_e32 v56, v56                                 // 000000713A38: 7E700B38
	v_lshlrev_b32_e32 v71, 4, v71                              // 000000713A3C: 308E8E84
	v_cvt_f32_i32_e32 v17, v17                                 // 000000713A40: 7E220B11
	v_mul_f32_e32 v4, v54, v4                                  // 000000713A44: 10080936
	v_and_or_b32 v15, v15, 48, v19                             // 000000713A48: D657000F 044D610F
	v_and_or_b32 v19, v69, 48, v76                             // 000000713A50: D6570013 05316145
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000713A58: BF870234
	v_dual_mul_f32 v17, v54, v17 :: v_dual_lshlrev_b32 v14, 4, v14// 000000713A5C: C8E22336 110E1C84
	v_and_or_b32 v65, v70, 48, v77                             // 000000713A64: D6570041 05356146
	v_subrev_nc_u32_e32 v21, 32, v55                           // 000000713A6C: 4E2A6EA0
	v_subrev_nc_u32_e32 v19, 32, v19                           // 000000713A70: 4E2626A0
	s_delay_alu instid0(VALU_DEP_4)                            // 000000713A74: BF870004
	v_and_or_b32 v14, v14, 48, v18                             // 000000713A78: D657000E 0449610E
	v_and_or_b32 v18, v66, 48, v73                             // 000000713A80: D6570012 05256142
	v_mul_f32_e32 v16, v54, v16                                // 000000713A88: 10202136
	v_mul_f32_e32 v56, v54, v56                                // 000000713A8C: 10707136
	v_cvt_f32_i32_e32 v19, v19                                 // 000000713A90: 7E260B13
	v_lshlrev_b32_e32 v64, 4, v64                              // 000000713A94: 30808084
	v_and_or_b32 v66, v71, 48, v78                             // 000000713A98: D6570042 05396147
	v_subrev_nc_u32_e32 v14, 32, v14                           // 000000713AA0: 4E1C1CA0
	v_subrev_nc_u32_e32 v18, 32, v18                           // 000000713AA4: 4E2424A0
	v_mul_f32_e32 v19, v54, v19                                // 000000713AA8: 10262736
	v_and_or_b32 v61, v64, 48, v63                             // 000000713AAC: D657003D 04FD6140
	v_and_or_b32 v63, v67, 48, v74                             // 000000713AB4: D657003F 05296143
	v_and_or_b32 v64, v68, 48, v75                             // 000000713ABC: D6570040 052D6144
	v_subrev_nc_u32_e32 v15, 32, v15                           // 000000713AC4: 4E1E1EA0
	v_subrev_nc_u32_e32 v60, 32, v65                           // 000000713AC8: 4E7882A0
	v_subrev_nc_u32_e32 v55, 32, v61                           // 000000713ACC: 4E6E7AA0
	v_subrev_nc_u32_e32 v58, 32, v63                           // 000000713AD0: 4E747EA0
	v_subrev_nc_u32_e32 v59, 32, v64                           // 000000713AD4: 4E7680A0
	v_subrev_nc_u32_e32 v61, 32, v66                           // 000000713AD8: 4E7A84A0
	v_cvt_f32_i32_e32 v21, v21                                 // 000000713ADC: 7E2A0B15
	v_cvt_f32_i32_e32 v55, v55                                 // 000000713AE0: 7E6E0B37
	v_cvt_f32_i32_e32 v14, v14                                 // 000000713AE4: 7E1C0B0E
	v_cvt_f32_i32_e32 v18, v18                                 // 000000713AE8: 7E240B12
	v_cvt_f32_i32_e32 v58, v58                                 // 000000713AEC: 7E740B3A
	v_cvt_f32_i32_e32 v59, v59                                 // 000000713AF0: 7E760B3B
	v_cvt_f32_i32_e32 v15, v15                                 // 000000713AF4: 7E1E0B0F
	v_cvt_f32_i32_e32 v60, v60                                 // 000000713AF8: 7E780B3C
	v_cvt_f32_i32_e32 v61, v61                                 // 000000713AFC: 7E7A0B3D
	v_mul_f32_e32 v21, v54, v21                                // 000000713B00: 102A2B36
	v_dual_mul_f32 v55, v54, v55 :: v_dual_add_nc_u32 v8, 32, v8// 000000713B04: C8E06F36 370810A0
	v_mul_f32_e32 v15, v54, v15                                // 000000713B0C: 101E1F36
	v_mul_f32_e32 v14, v54, v14                                // 000000713B10: 101C1D36
	v_mul_f32_e32 v18, v54, v18                                // 000000713B14: 10242536
	v_mul_f32_e32 v58, v54, v58                                // 000000713B18: 10747536
	v_mul_f32_e32 v59, v54, v59                                // 000000713B1C: 10767736
	v_mul_f32_e32 v60, v54, v60                                // 000000713B20: 10787936
	v_mul_f32_e32 v61, v54, v61                                // 000000713B24: 107A7B36
	v_bfe_u32 v54, v21, 16, 1                                  // 000000713B28: D6100036 02052115
	v_bfe_u32 v62, v55, 16, 1                                  // 000000713B30: D610003E 02052137
	v_bfe_u32 v63, v57, 16, 1                                  // 000000713B38: D610003F 02052139
	v_bfe_u32 v64, v14, 16, 1                                  // 000000713B40: D6100040 0205210E
	v_bfe_u32 v65, v18, 16, 1                                  // 000000713B48: D6100041 02052112
	v_add3_u32 v21, v21, v54, 0x7fff                           // 000000713B50: D6550015 03FE6D15 00007FFF
	v_add3_u32 v54, v55, v62, 0x7fff                           // 000000713B5C: D6550036 03FE7D37 00007FFF
	v_add3_u32 v55, v57, v63, 0x7fff                           // 000000713B68: D6550037 03FE7F39 00007FFF
	v_bfe_u32 v66, v58, 16, 1                                  // 000000713B74: D6100042 0205213A
	v_add3_u32 v14, v14, v64, 0x7fff                           // 000000713B7C: D655000E 03FE810E 00007FFF
	.long 0x7e6c3995                                           // 000000713B88: 7E6C3995
	v_bfe_u32 v67, v59, 16, 1                                  // 000000713B8C: D6100043 0205213B
	v_add3_u32 v18, v18, v65, 0x7fff                           // 000000713B94: D6550012 03FE8312 00007FFF
	.long 0x7e1c39b7                                           // 000000713BA0: 7E1C39B7
	v_bfe_u32 v68, v15, 16, 1                                  // 000000713BA4: D6100044 0205210F
	s_waitcnt vmcnt(7)                                         // 000000713BAC: BF891FF7
	v_dot2_f32_bf16 v21, v22, v54, 0                           // 000000713BB0: CC1A4015 1A026D16
	s_waitcnt vmcnt(6)                                         // 000000713BB8: BF891BF7
	v_dot2_f32_bf16 v22, v26, v54, 0                           // 000000713BBC: CC1A4016 1A026D1A
	s_waitcnt vmcnt(5)                                         // 000000713BC4: BF8917F7
	v_dot2_f32_bf16 v26, v30, v54, 0                           // 000000713BC8: CC1A401A 1A026D1E
	s_waitcnt vmcnt(4)                                         // 000000713BD0: BF8913F7
	v_dot2_f32_bf16 v30, v34, v54, 0                           // 000000713BD4: CC1A401E 1A026D22
	v_add3_u32 v57, v58, v66, 0x7fff                           // 000000713BDC: D6550039 03FE853A 00007FFF
	v_bfe_u32 v69, v19, 16, 1                                  // 000000713BE8: D6100045 02052113
	v_add3_u32 v58, v59, v67, 0x7fff                           // 000000713BF0: D655003A 03FE873B 00007FFF
	.long 0x7e723992                                           // 000000713BFC: 7E723992
	v_dot2_f32_bf16 v18, v23, v14, v21                         // 000000713C00: CC1A4012 1C561D17
	v_dot2_f32_bf16 v21, v27, v14, v22                         // 000000713C08: CC1A4015 1C5A1D1B
	v_dot2_f32_bf16 v22, v31, v14, v26                         // 000000713C10: CC1A4016 1C6A1D1F
	v_dot2_f32_bf16 v14, v35, v14, v30                         // 000000713C18: CC1A400E 1C7A1D23
	v_bfe_u32 v70, v60, 16, 1                                  // 000000713C20: D6100046 0205213C
	v_add3_u32 v15, v15, v68, 0x7fff                           // 000000713C28: D655000F 03FE890F 00007FFF
	v_bfe_u32 v71, v61, 16, 1                                  // 000000713C34: D6100047 0205213D
	v_add3_u32 v19, v19, v69, 0x7fff                           // 000000713C3C: D6550013 03FE8B13 00007FFF
	.long 0x7e1e39ba                                           // 000000713C48: 7E1E39BA
	v_dot2_f32_bf16 v18, v24, v57, v18                         // 000000713C4C: CC1A4012 1C4A7318
	v_dot2_f32_bf16 v21, v28, v57, v21                         // 000000713C54: CC1A4015 1C56731C
	v_dot2_f32_bf16 v22, v32, v57, v22                         // 000000713C5C: CC1A4016 1C5A7320
	v_dot2_f32_bf16 v14, v36, v57, v14                         // 000000713C64: CC1A400E 1C3A7324
	v_bfe_u32 v72, v16, 16, 1                                  // 000000713C6C: D6100048 02052110
	v_add3_u32 v59, v60, v70, 0x7fff                           // 000000713C74: D655003B 03FE8D3C 00007FFF
	v_bfe_u32 v73, v4, 16, 1                                   // 000000713C80: D6100049 02052104
	v_add3_u32 v60, v61, v71, 0x7fff                           // 000000713C88: D655003C 03FE8F3D 00007FFF
	.long 0x7e763993                                           // 000000713C94: 7E763993
	v_dot2_f32_bf16 v18, v25, v15, v18                         // 000000713C98: CC1A4012 1C4A1F19
	v_dot2_f32_bf16 v19, v29, v15, v21                         // 000000713CA0: CC1A4013 1C561F1D
	v_dot2_f32_bf16 v21, v33, v15, v22                         // 000000713CA8: CC1A4015 1C5A1F21
	v_dot2_f32_bf16 v14, v37, v15, v14                         // 000000713CB0: CC1A400E 1C3A1F25
	v_bfe_u32 v74, v20, 16, 1                                  // 000000713CB8: D610004A 02052114
	v_add3_u32 v16, v16, v72, 0x7fff                           // 000000713CC0: D6550010 03FE9110 00007FFF
	v_bfe_u32 v75, v56, 16, 1                                  // 000000713CCC: D610004B 02052138
	v_add3_u32 v4, v4, v73, 0x7fff                             // 000000713CD4: D6550004 03FE9304 00007FFF
	.long 0x7e2039bc                                           // 000000713CE0: 7E2039BC
	s_waitcnt vmcnt(3)                                         // 000000713CE4: BF890FF7
	v_dot2_f32_bf16 v15, v38, v59, v18                         // 000000713CE8: CC1A400F 1C4A7726
	s_waitcnt vmcnt(2)                                         // 000000713CF0: BF890BF7
	v_dot2_f32_bf16 v18, v42, v59, v19                         // 000000713CF4: CC1A4012 1C4E772A
	s_waitcnt vmcnt(1)                                         // 000000713CFC: BF8907F7
	v_dot2_f32_bf16 v19, v46, v59, v21                         // 000000713D00: CC1A4013 1C56772E
	s_waitcnt vmcnt(0)                                         // 000000713D08: BF8903F7
	v_dot2_f32_bf16 v14, v50, v59, v14                         // 000000713D0C: CC1A400E 1C3A7732
	v_bfe_u32 v76, v17, 16, 1                                  // 000000713D14: D610004C 02052111
	v_add3_u32 v20, v20, v74, 0x7fff                           // 000000713D1C: D6550014 03FE9514 00007FFF
	v_add3_u32 v56, v56, v75, 0x7fff                           // 000000713D28: D6550038 03FE9738 00007FFF
	.long 0x7e283984                                           // 000000713D34: 7E283984
	v_dot2_f32_bf16 v4, v39, v16, v15                          // 000000713D38: CC1A4004 1C3E2127
	v_dot2_f32_bf16 v15, v43, v16, v18                         // 000000713D40: CC1A400F 1C4A212B
	v_dot2_f32_bf16 v18, v47, v16, v19                         // 000000713D48: CC1A4012 1C4E212F
	v_dot2_f32_bf16 v14, v51, v16, v14                         // 000000713D50: CC1A400E 1C3A2133
	v_add3_u32 v17, v17, v76, 0x7fff                           // 000000713D58: D6550011 03FE9911 00007FFF
	.long 0x7e2239b8                                           // 000000713D64: 7E2239B8
	v_dot2_f32_bf16 v4, v40, v20, v4                           // 000000713D68: CC1A4004 1C122928
	v_dot2_f32_bf16 v15, v44, v20, v15                         // 000000713D70: CC1A400F 1C3E292C
	v_dot2_f32_bf16 v16, v48, v20, v18                         // 000000713D78: CC1A4010 1C4A2930
	v_dot2_f32_bf16 v14, v52, v20, v14                         // 000000713D80: CC1A400E 1C3A2934
	v_cmp_ge_i32_e32 vcc_lo, v8, v9                            // 000000713D88: 7C8C1308
	v_dot2_f32_bf16 v4, v41, v17, v4                           // 000000713D8C: CC1A4004 1C122329
	v_dot2_f32_bf16 v15, v45, v17, v15                         // 000000713D94: CC1A400F 1C3E232D
	v_dot2_f32_bf16 v16, v49, v17, v16                         // 000000713D9C: CC1A4010 1C422331
	v_dot2_f32_bf16 v14, v53, v17, v14                         // 000000713DA4: CC1A400E 1C3A2335
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000713DAC: BF870194
	v_dual_add_f32 v10, v10, v4 :: v_dual_add_nc_u32 v3, 0x200, v3// 000000713DB0: C920090A 0A0206FF 00000200
	v_dual_add_f32 v13, v13, v15 :: v_dual_add_f32 v12, v12, v16// 000000713DBC: C9081F0D 0D0C210C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000713DC4: BF8704A3
	v_add_f32_e32 v11, v11, v14                                // 000000713DC8: 06161D0B
	s_or_b32 s3, vcc_lo, s3                                    // 000000713DCC: 8C03036A
	s_and_not1_b32 exec_lo, exec_lo, s3                        // 000000713DD0: 917E037E
	s_cbranch_execnz 65110                                     // 000000713DD4: BFA6FE56 <_ZN7halogen12_GLOBAL__N_16k_lq6kILi4ELi32ELi2ELb1EEEvPKhPKtPvll+0x130>
	s_or_b32 exec_lo, exec_lo, s3                              // 000000713DD8: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000713DDC: BF8700B9
	s_or_b32 exec_lo, exec_lo, s2                              // 000000713DE0: 8C7E027E
	.long 0xd71f0001                                           // 000000713DE4: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000713DE8: 020100C1
	s_mov_b32 s0, exec_lo                                      // 000000713DEC: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 000000713DF0: 3A040290
	v_xor_b32_e32 v9, 8, v1                                    // 000000713DF4: 3A120288
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000713DF8: BF8701A2
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 000000713DFC: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 000000713E00: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v9                            // 000000713E04: 7C9812A0
	v_cndmask_b32_e32 v9, v1, v9, vcc_lo                       // 000000713E08: 02121301
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000713E0C: BF870211
	v_lshlrev_b32_e32 v9, 2, v9                                // 000000713E10: 30121282
	v_lshlrev_b32_e32 v2, 2, v2                                // 000000713E14: 30040482
	ds_bpermute_b32 v3, v2, v10                                // 000000713E18: DACC0000 03000A02
	s_waitcnt lgkmcnt(0)                                       // 000000713E20: BF89FC07
	v_add_f32_e32 v3, v10, v3                                  // 000000713E24: 0606070A
	ds_bpermute_b32 v4, v2, v13                                // 000000713E28: DACC0000 04000D02
	ds_bpermute_b32 v8, v2, v12                                // 000000713E30: DACC0000 08000C02
	ds_bpermute_b32 v2, v2, v11                                // 000000713E38: DACC0000 02000B02
	ds_bpermute_b32 v10, v9, v3                                // 000000713E40: DACC0000 0A000309
	s_waitcnt lgkmcnt(3)                                       // 000000713E48: BF89FC37
	v_add_f32_e32 v4, v13, v4                                  // 000000713E4C: 0608090D
	v_xor_b32_e32 v13, 4, v1                                   // 000000713E50: 3A1A0284
	s_waitcnt lgkmcnt(2)                                       // 000000713E54: BF89FC27
	v_add_f32_e32 v8, v12, v8                                  // 000000713E58: 0610110C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000713E5C: BF8700D2
	v_cmp_gt_u32_e32 vcc_lo, 32, v13                           // 000000713E60: 7C981AA0
	s_waitcnt lgkmcnt(1)                                       // 000000713E64: BF89FC17
	v_add_f32_e32 v2, v11, v2                                  // 000000713E68: 0604050B
	ds_bpermute_b32 v12, v9, v8                                // 000000713E6C: DACC0000 0C000809
	v_cndmask_b32_e32 v13, v1, v13, vcc_lo                     // 000000713E74: 021A1B01
	v_lshlrev_b32_e32 v13, 2, v13                              // 000000713E78: 301A1A82
	ds_bpermute_b32 v11, v9, v4                                // 000000713E7C: DACC0000 0B000409
	ds_bpermute_b32 v9, v9, v2                                 // 000000713E84: DACC0000 09000209
	s_waitcnt lgkmcnt(2)                                       // 000000713E8C: BF89FC27
	v_dual_add_f32 v3, v3, v10 :: v_dual_add_f32 v8, v8, v12   // 000000713E90: C9081503 03081908
	s_waitcnt lgkmcnt(1)                                       // 000000713E98: BF89FC17
	v_add_f32_e32 v4, v4, v11                                  // 000000713E9C: 06081704
	s_waitcnt lgkmcnt(0)                                       // 000000713EA0: BF89FC07
	v_add_f32_e32 v2, v2, v9                                   // 000000713EA4: 06041302
	ds_bpermute_b32 v9, v13, v3                                // 000000713EA8: DACC0000 0900030D
	ds_bpermute_b32 v11, v13, v8                               // 000000713EB0: DACC0000 0B00080D
	ds_bpermute_b32 v10, v13, v4                               // 000000713EB8: DACC0000 0A00040D
	ds_bpermute_b32 v12, v13, v2                               // 000000713EC0: DACC0000 0C00020D
	v_xor_b32_e32 v13, 2, v1                                   // 000000713EC8: 3A1A0282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000713ECC: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v13                           // 000000713ED0: 7C981AA0
	v_cndmask_b32_e32 v13, v1, v13, vcc_lo                     // 000000713ED4: 021A1B01
	v_lshlrev_b32_e32 v13, 2, v13                              // 000000713ED8: 301A1A82
	s_waitcnt lgkmcnt(2)                                       // 000000713EDC: BF89FC27
	v_dual_add_f32 v3, v3, v9 :: v_dual_add_f32 v8, v8, v11    // 000000713EE0: C9081303 03081708
	s_waitcnt lgkmcnt(1)                                       // 000000713EE8: BF89FC17
	v_add_f32_e32 v4, v4, v10                                  // 000000713EEC: 06081504
	ds_bpermute_b32 v11, v13, v8                               // 000000713EF0: DACC0000 0B00080D
	ds_bpermute_b32 v10, v13, v4                               // 000000713EF8: DACC0000 0A00040D
	s_waitcnt lgkmcnt(2)                                       // 000000713F00: BF89FC27
	v_add_f32_e32 v9, v2, v12                                  // 000000713F04: 06121902
	ds_bpermute_b32 v2, v13, v3                                // 000000713F08: DACC0000 0200030D
	ds_bpermute_b32 v12, v13, v9                               // 000000713F10: DACC0000 0C00090D
	v_xor_b32_e32 v13, 1, v1                                   // 000000713F18: 3A1A0281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000713F1C: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v13                           // 000000713F20: 7C981AA0
	v_cndmask_b32_e32 v1, v1, v13, vcc_lo                      // 000000713F24: 02021B01
	v_lshlrev_b32_e32 v13, 2, v1                               // 000000713F28: 301A0282
	s_waitcnt lgkmcnt(1)                                       // 000000713F2C: BF89FC17
	v_add_f32_e32 v1, v3, v2                                   // 000000713F30: 06020503
	v_add_f32_e32 v2, v4, v10                                  // 000000713F34: 06041504
	s_waitcnt lgkmcnt(0)                                       // 000000713F38: BF89FC07
	v_dual_add_f32 v3, v8, v11 :: v_dual_add_f32 v8, v9, v12   // 000000713F3C: C9081708 03081909
	ds_bpermute_b32 v4, v13, v1                                // 000000713F44: DACC0000 0400010D
	ds_bpermute_b32 v9, v13, v2                                // 000000713F4C: DACC0000 0900020D
	ds_bpermute_b32 v10, v13, v3                               // 000000713F54: DACC0000 0A00030D
	ds_bpermute_b32 v11, v13, v8                               // 000000713F5C: DACC0000 0B00080D
	v_cmpx_eq_u32_e32 0, v7                                    // 000000713F64: 7D940E80
	s_cbranch_execz 12                                         // 000000713F68: BFA5000C <_ZN7halogen12_GLOBAL__N_16k_lq6kILi4ELi32ELi2ELb1EEEvPKhPKtPvll+0x99c>
	s_waitcnt lgkmcnt(1)                                       // 000000713F6C: BF89FC17
	v_dual_add_f32 v10, v3, v10 :: v_dual_lshlrev_b32 v5, 4, v5// 000000713F70: C9221503 0A040A84
	s_waitcnt lgkmcnt(0)                                       // 000000713F78: BF89FC07
	v_dual_add_f32 v11, v8, v11 :: v_dual_add_f32 v8, v1, v4   // 000000713F7C: C9081708 0B080901
	v_add_f32_e32 v9, v2, v9                                   // 000000713F84: 06121302
	s_delay_alu instid0(VALU_DEP_3)                            // 000000713F88: BF870003
	v_lshl_or_b32 v1, v6, 5, v5                                // 000000713F8C: D6560001 04150B06
	ds_store_b128 v1, v[8:11]                                  // 000000713F94: DB7C0000 00000801
	s_or_b32 exec_lo, exec_lo, s0                              // 000000713F9C: 8C7E007E
	v_lshrrev_b32_e32 v3, 2, v0                                // 000000713FA0: 32060082
	v_mov_b32_e32 v2, s15                                      // 000000713FA4: 7E04020F
	.long 0xd44c0000                                           // 000000713FA8: D44C0000
	v_cndmask_b32_e32 v1, 16, v0, vcc_lo                       // 000000713FAC: 02020090
	s_waitcnt lgkmcnt(0)                                       // 000000713FB0: BF89FC07
	s_barrier                                                  // 000000713FB4: BFBD0000
	v_or_b32_e32 v1, s14, v3                                   // 000000713FB8: 3802060E
	buffer_gl0_inv                                             // 000000713FBC: E0AC0000 00000000
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 000000713FC4: 7CA8020C
	s_and_b32 s0, s0, vcc_lo                                   // 000000713FC8: 8B006A00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000713FCC: BF870009
	s_and_saveexec_b32 s1, s0                                  // 000000713FD0: BE812000
	s_cbranch_execz 31                                         // 000000713FD4: BFA5001F <_ZN7halogen12_GLOBAL__N_16k_lq6kILi4ELi32ELi2ELb1EEEvPKhPKtPvll+0xa54>
	v_and_b32_e32 v0, 3, v0                                    // 000000713FD8: 36000083
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000713FDC: BF870091
	v_lshlrev_b32_e32 v4, 2, v0                                // 000000713FE0: 30080082
	v_lshl_or_b32 v5, v3, 5, v4                                // 000000713FE4: D6560005 04110B03
	v_mad_u64_u32 v[3:4], null, s12, v0, 0                     // 000000713FEC: D6FE7C03 0202000C
	ds_load_2addr_b32 v[6:7], v5 offset1:4                     // 000000713FF4: D8DC0400 06000005
	v_mad_u64_u32 v[4:5], null, s13, v0, v[4:5]                // 000000713FFC: D6FE7C04 0412000D
	.long 0xd73c0000                                           // 000000714004: D73C0000
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000714008: 02020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000071400C: BF870092
	.long 0xd73c0003                                           // 000000714010: D73C0003
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 000000714014: 02020682
	.long 0xd7006a03                                           // 000000714018: D7006A03
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 00000071401C: 02020608
	s_waitcnt lgkmcnt(0)                                       // 000000714020: BF89FC07
	v_add_f32_e32 v2, 0, v6                                    // 000000714024: 06040C80
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000714028: BF870193
	v_add_co_ci_u32_e64 v4, null, s9, v4, vcc_lo               // 00000071402C: D5207C04 01AA0809
	.long 0xd7006a00                                           // 000000714034: D7006A00
	v_cndmask_b32_e32 v1, v3, v0, vcc_lo                       // 000000714038: 02020103
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000071403C: BF870193
	v_add_f32_e32 v2, v2, v7                                   // 000000714040: 06040F02
	v_add_co_ci_u32_e64 v1, null, v4, v1, vcc_lo               // 000000714044: D5207C01 01AA0304
	global_store_b32 v[0:1], v2, off                           // 00000071404C: DC6A0000 007C0200
	s_endpgm                                                   // 000000714054: BFB00000
		...

