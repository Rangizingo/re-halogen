000000000084b800 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[8:23], s[0:1], null                          // 00000084B800: F4100200 F8000000
	v_and_b32_e32 v30, 15, v0                                  // 00000084B808: 363C008F
	v_lshrrev_b32_e32 v1, 4, v0                                // 00000084B80C: 32020084
	s_ashr_i32 s3, s2, 31                                      // 00000084B810: 86039F02
	v_lshlrev_b32_e32 v7, 2, v0                                // 00000084B814: 300E0082
	s_lshl_b64 s[2:3], s[2:3], 4                               // 00000084B818: 84828402
	v_lshlrev_b32_e32 v2, 2, v30                               // 00000084B81C: 30043C82
	v_dual_mov_b32 v24, s3 :: v_dual_lshlrev_b32 v3, 2, v1     // 00000084B820: CA220003 18020282
	v_or_b32_e32 v23, s2, v1                                   // 00000084B828: 382E0202
	.long 0x7f0c3880                                           // 00000084B82C: 7F0C3880
	s_waitcnt lgkmcnt(0)                                       // 00000084B830: BF89FC07
	s_clause 0x1                                               // 00000084B834: BF850001
	global_load_b32 v4, v2, s[8:9]                             // 00000084B838: DC520000 04080002
	global_load_b32 v3, v3, s[8:9]                             // 00000084B840: DC520000 03080003
	.long 0xd4540002                                           // 00000084B848: D4540002
	v_cndmask_b32_e32 v1, s16, v23, vcc_lo                     // 00000084B84C: 02022E10
	s_add_u32 s24, s8, s20                                     // 00000084B850: 80181408
	s_addc_u32 s25, s9, s21                                    // 00000084B854: 82191509
	s_ashr_i32 s4, s15, 31                                     // 00000084B858: 86049F0F
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 00000084B85C: BF870159
	s_lshr_b32 s4, s4, 27                                      // 00000084B860: 85049B04
	v_cndmask_b32_e64 v2, 0, v23, s2                           // 00000084B864: D5010002 000A2E80
	v_cndmask_b32_e64 v5, 0, s3, s2                            // 00000084B86C: D5010005 00080680
	s_add_u32 s4, s14, s4                                      // 00000084B874: 8004040E
	s_addc_u32 s5, s15, 0                                      // 00000084B878: 8205800F
	.long 0xd72c0008                                           // 00000084B87C: D72C0008
	v_cndmask_b32_e32 v1, s23, v2, vcc_lo                      // 00000084B880: 02020417
	v_mad_u64_u32 v[0:1], null, s22, v2, 0                     // 00000084B884: D6FE7C00 02020416
	s_lshr_b64 s[6:7], s[4:5], 5                               // 00000084B88C: 85868504
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 00000084B890: BF8704D9
	s_cmpk_lt_i32 s6, 0x81                                     // 00000084B894: B3860081
	.long 0xd4440004                                           // 00000084B898: D4440004
	v_cndmask_b32_e32 v1, s6, v30, vcc_lo                      // 00000084B89C: 02023C06
	s_cselect_b32 s3, -1, 0                                    // 00000084B8A0: 980380C1
	s_cmpk_gt_i32 s6, 0x80                                     // 00000084B8A4: B2860080
	s_cselect_b32 s7, -1, 0                                    // 00000084B8A8: 980780C1
	s_and_b32 vcc_lo, exec_lo, s7                              // 00000084B8AC: 8B6A077E
	s_waitcnt vmcnt(1)                                         // 00000084B8B0: BF8907F7
	v_bfe_u32 v9, v4, 16, 1                                    // 00000084B8B4: D6100009 02052104
	s_waitcnt vmcnt(0)                                         // 00000084B8BC: BF8903F7
	v_bfe_u32 v10, v3, 16, 1                                   // 00000084B8C0: D610000A 02052103
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000084B8C8: BF8701A2
	v_add3_u32 v4, v4, v9, 0x7fff                              // 00000084B8CC: D6550004 03FE1304 00007FFF
	.long 0xd72c0009                                           // 00000084B8D8: D72C0009
	v_cndmask_b32_e32 v1, s22, v5, vcc_lo                      // 00000084B8DC: 02020A16
	v_add3_u32 v3, v3, v10, 0x7fff                             // 00000084B8E0: D6550003 03FE1503 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000084B8EC: BF870193
	.long 0x7e0c3984                                           // 00000084B8F0: 7E0C3984
	v_add3_u32 v1, v1, v9, v8                                  // 00000084B8F4: D6550001 04221301
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084B8FC: BF8700A2
	v_and_or_b32 v6, 0xffff0000, v3, v6                        // 00000084B900: D6570006 041A06FF FFFF0000
	.long 0xd7000503                                           // 00000084B90C: D7000503
	v_cndmask_b32_e32 v1, s24, v0, vcc_lo                      // 00000084B910: 02020018
	v_add_co_ci_u32_e64 v4, null, s25, v1, s5                  // 00000084B914: D5207C04 00160219
	ds_store_b32 v7, v6                                        // 00000084B91C: D8340000 00000607
	s_waitcnt lgkmcnt(0)                                       // 00000084B924: BF89FC07
	s_barrier                                                  // 00000084B928: BFBD0000
	buffer_gl0_inv                                             // 00000084B92C: E0AC0000 00000000
	s_cbranch_vccnz 144                                        // 00000084B934: BFA40090 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x378>
	v_dual_mov_b32 v8, 0 :: v_dual_mov_b32 v7, 0               // 00000084B938: CA100080 08060080
	s_and_saveexec_b32 s5, s4                                  // 00000084B940: BE852004
	s_cbranch_execz 10                                         // 00000084B944: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x170>
	v_lshlrev_b32_e32 v6, 1, v30                               // 00000084B948: 300C3C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084B94C: BF870091
	.long 0xd7006a06                                           // 00000084B950: D7006A06
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000084B954: 02020D03
	v_add_co_ci_u32_e64 v7, null, 0, v4, vcc_lo                // 00000084B958: D5207C07 01AA0880
	global_load_d16_b16 v6, v[6:7], off                        // 00000084B960: DC820000 067C0006
	s_waitcnt vmcnt(0)                                         // 00000084B968: BF8903F7
	v_cvt_f32_f16_e32 v7, v6                                   // 00000084B96C: 7E0E1706
	s_or_b32 exec_lo, exec_lo, s5                              // 00000084B970: 8C7E057E
	v_or_b32_e32 v6, 16, v30                                   // 00000084B974: 380C3C90
	s_mov_b32 s4, exec_lo                                      // 00000084B978: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000084B97C: BF870001
	.long 0xd4c4007e                                           // 00000084B980: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 00000084B984: 02020C06
	s_cbranch_execz 10                                         // 00000084B988: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x1b4>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000084B98C: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084B990: BF870091
	.long 0xd7006a08                                           // 00000084B994: D7006A08
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000084B998: 02020D03
	v_add_co_ci_u32_e64 v9, null, 0, v4, vcc_lo                // 00000084B99C: D5207C09 01AA0880
	global_load_d16_b16 v6, v[8:9], off                        // 00000084B9A4: DC820000 067C0008
	s_waitcnt vmcnt(0)                                         // 00000084B9AC: BF8903F7
	v_cvt_f32_f16_e32 v8, v6                                   // 00000084B9B0: 7E101706
	s_or_b32 exec_lo, exec_lo, s4                              // 00000084B9B4: 8C7E047E
	v_or_b32_e32 v6, 32, v30                                   // 00000084B9B8: 380C3CA0
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v9, 0              // 00000084B9BC: CA100080 0A080080
	s_mov_b32 s4, exec_lo                                      // 00000084B9C4: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000084B9C8: BF870002
	.long 0xd4c4007e                                           // 00000084B9CC: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 00000084B9D0: 02020C06
	s_cbranch_execz 10                                         // 00000084B9D4: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x200>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000084B9D8: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084B9DC: BF870091
	.long 0xd7006a0b                                           // 00000084B9E0: D7006A0B
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000084B9E4: 02020D03
	v_add_co_ci_u32_e64 v12, null, 0, v4, vcc_lo               // 00000084B9E8: D5207C0C 01AA0880
	global_load_d16_b16 v6, v[11:12], off                      // 00000084B9F0: DC820000 067C000B
	s_waitcnt vmcnt(0)                                         // 00000084B9F8: BF8903F7
	v_cvt_f32_f16_e32 v9, v6                                   // 00000084B9FC: 7E121706
	s_or_b32 exec_lo, exec_lo, s4                              // 00000084BA00: 8C7E047E
	v_or_b32_e32 v6, 48, v30                                   // 00000084BA04: 380C3CB0
	s_mov_b32 s4, exec_lo                                      // 00000084BA08: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000084BA0C: BF870001
	.long 0xd4c4007e                                           // 00000084BA10: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 00000084BA14: 02020C06
	s_cbranch_execz 10                                         // 00000084BA18: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x244>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000084BA1C: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084BA20: BF870091
	.long 0xd7006a0a                                           // 00000084BA24: D7006A0A
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000084BA28: 02020D03
	v_add_co_ci_u32_e64 v11, null, 0, v4, vcc_lo               // 00000084BA2C: D5207C0B 01AA0880
	global_load_d16_b16 v6, v[10:11], off                      // 00000084BA34: DC820000 067C000A
	s_waitcnt vmcnt(0)                                         // 00000084BA3C: BF8903F7
	v_cvt_f32_f16_e32 v10, v6                                  // 00000084BA40: 7E141706
	s_or_b32 exec_lo, exec_lo, s4                              // 00000084BA44: 8C7E047E
	v_or_b32_e32 v6, 64, v30                                   // 00000084BA48: 380C3CC0
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v11, 0             // 00000084BA4C: CA100080 0C0A0080
	s_mov_b32 s4, exec_lo                                      // 00000084BA54: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000084BA58: BF870002
	.long 0xd4c4007e                                           // 00000084BA5C: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 00000084BA60: 02020C06
	s_cbranch_execz 10                                         // 00000084BA64: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x290>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000084BA68: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084BA6C: BF870091
	.long 0xd7006a0d                                           // 00000084BA70: D7006A0D
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000084BA74: 02020D03
	v_add_co_ci_u32_e64 v14, null, 0, v4, vcc_lo               // 00000084BA78: D5207C0E 01AA0880
	global_load_d16_b16 v6, v[13:14], off                      // 00000084BA80: DC820000 067C000D
	s_waitcnt vmcnt(0)                                         // 00000084BA88: BF8903F7
	v_cvt_f32_f16_e32 v11, v6                                  // 00000084BA8C: 7E161706
	s_or_b32 exec_lo, exec_lo, s4                              // 00000084BA90: 8C7E047E
	v_or_b32_e32 v6, 0x50, v30                                 // 00000084BA94: 380C3CFF 00000050
	s_mov_b32 s4, exec_lo                                      // 00000084BA9C: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000084BAA0: BF870001
	.long 0xd4c4007e                                           // 00000084BAA4: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 00000084BAA8: 02020C06
	s_cbranch_execz 10                                         // 00000084BAAC: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x2d8>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000084BAB0: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084BAB4: BF870091
	.long 0xd7006a0c                                           // 00000084BAB8: D7006A0C
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000084BABC: 02020D03
	v_add_co_ci_u32_e64 v13, null, 0, v4, vcc_lo               // 00000084BAC0: D5207C0D 01AA0880
	global_load_d16_b16 v6, v[12:13], off                      // 00000084BAC8: DC820000 067C000C
	s_waitcnt vmcnt(0)                                         // 00000084BAD0: BF8903F7
	v_cvt_f32_f16_e32 v12, v6                                  // 00000084BAD4: 7E181706
	s_or_b32 exec_lo, exec_lo, s4                              // 00000084BAD8: 8C7E047E
	v_or_b32_e32 v6, 0x60, v30                                 // 00000084BADC: 380C3CFF 00000060
	v_dual_mov_b32 v14, 0 :: v_dual_mov_b32 v13, 0             // 00000084BAE4: CA100080 0E0C0080
	s_mov_b32 s4, exec_lo                                      // 00000084BAEC: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000084BAF0: BF870002
	.long 0xd4c4007e                                           // 00000084BAF4: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 00000084BAF8: 02020C06
	s_cbranch_execz 10                                         // 00000084BAFC: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x328>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000084BB00: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084BB04: BF870091
	.long 0xd7006a0f                                           // 00000084BB08: D7006A0F
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000084BB0C: 02020D03
	v_add_co_ci_u32_e64 v16, null, 0, v4, vcc_lo               // 00000084BB10: D5207C10 01AA0880
	global_load_d16_b16 v6, v[15:16], off                      // 00000084BB18: DC820000 067C000F
	s_waitcnt vmcnt(0)                                         // 00000084BB20: BF8903F7
	v_cvt_f32_f16_e32 v13, v6                                  // 00000084BB24: 7E1A1706
	s_or_b32 exec_lo, exec_lo, s4                              // 00000084BB28: 8C7E047E
	v_or_b32_e32 v6, 0x70, v30                                 // 00000084BB2C: 380C3CFF 00000070
	s_mov_b32 s4, exec_lo                                      // 00000084BB34: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000084BB38: BF870001
	.long 0xd4c4007e                                           // 00000084BB3C: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 00000084BB40: 02020C06
	s_cbranch_execz 10                                         // 00000084BB44: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x370>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000084BB48: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084BB4C: BF870091
	.long 0xd7006a0e                                           // 00000084BB50: D7006A0E
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000084BB54: 02020D03
	v_add_co_ci_u32_e64 v15, null, 0, v4, vcc_lo               // 00000084BB58: D5207C0F 01AA0880
	global_load_d16_b16 v6, v[14:15], off                      // 00000084BB60: DC820000 067C000E
	s_waitcnt vmcnt(0)                                         // 00000084BB68: BF8903F7
	v_cvt_f32_f16_e32 v14, v6                                  // 00000084BB6C: 7E1C1706
	s_or_b32 exec_lo, exec_lo, s4                              // 00000084BB70: 8C7E047E
	s_branch 9                                                 // 00000084BB74: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x39c>
	v_mov_b32_e32 v7, 0                                        // 00000084BB78: 7E0E0280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000084BB7C: BF870001
	v_mov_b32_e32 v8, v7                                       // 00000084BB80: 7E100307
	v_mov_b32_e32 v9, v7                                       // 00000084BB84: 7E120307
	v_mov_b32_e32 v10, v7                                      // 00000084BB88: 7E140307
	v_mov_b32_e32 v11, v7                                      // 00000084BB8C: 7E160307
	v_mov_b32_e32 v12, v7                                      // 00000084BB90: 7E180307
	v_mov_b32_e32 v13, v7                                      // 00000084BB94: 7E1A0307
	v_mov_b32_e32 v14, v7                                      // 00000084BB98: 7E1C0307
	s_add_u32 s4, s8, s18                                      // 00000084BB9C: 80041208
	s_addc_u32 s5, s9, s19                                     // 00000084BBA0: 82051309
	s_lshr_b32 s18, s15, 31                                    // 00000084BBA4: 85129F0F
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v20, 0             // 00000084BBA8: CA100080 13140080
	s_add_u32 s18, s14, s18                                    // 00000084BBB0: 8012120E
	s_addc_u32 s19, s15, 0                                     // 00000084BBB4: 8213800F
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v22, 0             // 00000084BBB8: CA100080 21160080
	s_ashr_i64 s[18:19], s[18:19], 1                           // 00000084BBC0: 86928112
	v_cndmask_b32_e64 v31, 0, 1, s7                            // 00000084BBC4: D501001F 001D0280
	v_mad_u64_u32 v[25:26], null, v2, s18, s[4:5]              // 00000084BBCC: D6FE7C19 00102502
	.long 0xd72c0002                                           // 00000084BBD4: D72C0002
	v_cndmask_b32_e32 v0, v2, v19, vcc_lo                      // 00000084BBD8: 02002702
	.long 0xd72c0005                                           // 00000084BBDC: D72C0005
	v_cndmask_b32_e32 v0, v5, v18, vcc_lo                      // 00000084BBE0: 02002505
	.long 0xd4440004                                           // 00000084BBE4: D4440004
	v_cndmask_b32_e32 v1, s6, v30, vcc_lo                      // 00000084BBE8: 02023C06
	v_mov_b32_e32 v41, 0                                       // 00000084BBEC: 7E520280
	v_mov_b32_e32 v21, 0                                       // 00000084BBF0: 7E2A0280
	s_delay_alu instid0(VALU_DEP_4)                            // 00000084BBF4: BF870004
	v_add3_u32 v32, v5, v26, v2                                // 00000084BBF8: D6550020 040A3505
	s_and_saveexec_b32 s5, s4                                  // 00000084BC00: BE852004
	s_cbranch_execz 21                                         // 00000084BC04: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x45c>
	v_dual_mov_b32 v41, 0 :: v_dual_lshlrev_b32 v2, 4, v30     // 00000084BC08: CA220080 29023C84
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084BC10: BF870091
	.long 0xd7006a05                                           // 00000084BC14: D7006A05
	v_cndmask_b32_e32 v1, v25, v2, vcc_lo                      // 00000084BC18: 02020519
	v_add_co_ci_u32_e64 v6, null, 0, v32, vcc_lo               // 00000084BC1C: D5207C06 01AA4080
	s_and_not1_b32 vcc_lo, exec_lo, s7                         // 00000084BC24: 916A077E
	global_load_b128 v[19:22], v[5:6], off                     // 00000084BC28: DC5E0000 137C0005
	s_cbranch_vccnz 10                                         // 00000084BC30: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x45c>
	v_lshlrev_b32_e32 v2, 1, v30                               // 00000084BC34: 30043C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084BC38: BF870091
	.long 0xd7006a02                                           // 00000084BC3C: D7006A02
	v_cndmask_b32_e32 v1, v3, v2, vcc_lo                       // 00000084BC40: 02020503
	v_add_co_ci_u32_e64 v3, null, 0, v4, vcc_lo                // 00000084BC44: D5207C03 01AA0880
	global_load_d16_b16 v2, v[2:3], off                        // 00000084BC4C: DC820000 027C0002
	s_waitcnt vmcnt(0)                                         // 00000084BC54: BF8903F7
	v_cvt_f32_f16_e32 v41, v2                                  // 00000084BC58: 7E521702
	s_or_b32 exec_lo, exec_lo, s5                              // 00000084BC5C: 8C7E057E
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v35, 0             // 00000084BC60: CA100080 22220080
	v_dual_mov_b32 v36, 0 :: v_dual_mov_b32 v37, 0             // 00000084BC68: CA100080 24240080
	s_and_saveexec_b32 s5, s4                                  // 00000084BC70: BE852004
	s_cbranch_execz 507                                        // 00000084BC74: BFA501FB <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0xc64>
	v_dual_mov_b32 v27, 0 :: v_dual_lshlrev_b32 v2, 1, v30     // 00000084BC78: CA220080 1B023C81
	.long 0xd7006a00                                           // 00000084BC80: D7006A00
	v_cndmask_b32_e32 v1, s20, v0, vcc_lo                      // 00000084BC84: 02020014
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000084BC88: BF8701A1
	v_add_co_ci_u32_e64 v1, null, s21, v1, vcc_lo              // 00000084BC8C: D5207C01 01AA0215
	v_dual_mov_b32 v39, v30 :: v_dual_lshlrev_b32 v26, 5, v30  // 00000084BC94: CA22011E 271A3C85
	.long 0xd7006a00                                           // 00000084BC9C: D7006A00
	v_cndmask_b32_e32 v1, v0, v2, vcc_lo                       // 00000084BCA0: 02020500
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000084BCA4: BF8701A1
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 00000084BCA8: D5207C01 01AA0280
	v_lshl_or_b32 v38, v30, 4, 0x100                           // 00000084BCB0: D6560026 03FD091E 00000100
	.long 0xd7006a00                                           // 00000084BCBC: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 00000084BCC0: 02020008
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000084BCC4: BF8701A1
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 00000084BCC8: D5207C01 01AA0209
	v_dual_mov_b32 v37, v27 :: v_dual_mov_b32 v40, v41         // 00000084BCD0: CA10011B 25280129
	.long 0xd7006a1c                                           // 00000084BCD8: D7006A1C
	v_cndmask_b32_e32 v0, v0, v160, vcc_lo                     // 00000084BCDC: 02014100
	s_delay_alu instid0(VALU_DEP_1)                            // 00000084BCE0: BF870001
	v_add_co_ci_u32_e64 v29, null, 0, v1, vcc_lo               // 00000084BCE4: D5207C1D 01AA0280
	v_mov_b32_e32 v36, v27                                     // 00000084BCEC: 7E48031B
	v_mov_b32_e32 v35, v27                                     // 00000084BCF0: 7E46031B
	v_mov_b32_e32 v34, v27                                     // 00000084BCF4: 7E44031B
	v_mov_b32_e32 v33, v27                                     // 00000084BCF8: 7E42031B
	s_mul_i32 s4, s15, 6                                       // 00000084BCFC: 9604860F
	s_mul_hi_u32 s7, s14, 6                                    // 00000084BD00: 9687860E
	s_lshl_b64 s[18:19], s[14:15], 2                           // 00000084BD04: 8492820E
	s_add_i32 s7, s7, s4                                       // 00000084BD08: 81070407
	s_mul_i32 s21, s14, 6                                      // 00000084BD0C: 9615860E
	s_mov_b32 s20, 0                                           // 00000084BD10: BE940080
	s_lshl_b64 s[8:9], s[14:15], 1                             // 00000084BD14: 8488810E
	s_branch 437                                               // 00000084BD18: BFA001B5 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0xbf0>
	s_or_b32 exec_lo, exec_lo, s14                             // 00000084BD1C: 8C7E0E7E
	v_cndmask_b32_e64 v51, v41, v7, s3                         // 00000084BD20: D5010033 000E0F29
	v_cndmask_b32_e64 v1, v8, v9, s3                           // 00000084BD28: D5010001 000E1308
	v_cndmask_b32_e64 v0, v7, v8, s3                           // 00000084BD30: D5010000 000E1107
	v_dual_mov_b32 v7, v14 :: v_dual_and_b32 v8, 0xff, v19     // 00000084BD38: CA24010E 070826FF 000000FF
	v_cndmask_b32_e64 v6, v13, v14, s3                         // 00000084BD44: D5010006 000E1D0D
	v_cndmask_b32_e64 v5, v12, v13, s3                         // 00000084BD4C: D5010005 000E1B0C
	v_cndmask_b32_e64 v4, v11, v12, s3                         // 00000084BD54: D5010004 000E190B
	v_cndmask_b32_e64 v3, v10, v11, s3                         // 00000084BD5C: D5010003 000E170A
	v_lshlrev_b32_e32 v8, 2, v8                                // 00000084BD64: 30101082
	v_cndmask_b32_e64 v2, v9, v10, s3                          // 00000084BD68: D5010002 000E1509
	s_and_b32 s4, exec_lo, s4                                  // 00000084BD70: 8B04047E
	v_add_nc_u32_e32 v38, 0x100, v38                           // 00000084BD74: 4A4C4CFF 00000100
	s_or_b32 s20, s4, s20                                      // 00000084BD7C: 8C141404
	ds_load_b32 v14, v8                                        // 00000084BD80: D8D80000 0E000008
	v_lshrrev_b32_e32 v8, 6, v19                               // 00000084BD88: 32102686
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000084BD8C: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000084BD90: 361010FF 000003FC
	ds_load_b32 v52, v8                                        // 00000084BD98: D8D80000 34000008
	v_lshrrev_b32_e32 v8, 14, v19                              // 00000084BDA0: 3210268E
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000084BDA4: 361010FF 000003FC
	ds_load_b32 v53, v8                                        // 00000084BDAC: D8D80000 35000008
	v_lshrrev_b32_e32 v8, 22, v19                              // 00000084BDB4: 32102696
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000084BDB8: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000084BDBC: 361010FF 000003FC
	ds_load_b32 v54, v8                                        // 00000084BDC4: D8D80000 36000008
	v_and_b32_e32 v8, 0xff, v20                                // 00000084BDCC: 361028FF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 00000084BDD4: 30101082
	ds_load_b32 v55, v8                                        // 00000084BDD8: D8D80000 37000008
	v_lshrrev_b32_e32 v8, 6, v20                               // 00000084BDE0: 32102886
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000084BDE4: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000084BDE8: 361010FF 000003FC
	ds_load_b32 v56, v8                                        // 00000084BDF0: D8D80000 38000008
	v_lshrrev_b32_e32 v8, 14, v20                              // 00000084BDF8: 3210288E
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000084BDFC: 361010FF 000003FC
	ds_load_b32 v57, v8                                        // 00000084BE04: D8D80000 39000008
	v_lshrrev_b32_e32 v8, 22, v20                              // 00000084BE0C: 32102896
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000084BE10: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000084BE14: 361010FF 000003FC
	ds_load_b32 v58, v8                                        // 00000084BE1C: D8D80000 3A000008
	v_and_b32_e32 v8, 0xff, v21                                // 00000084BE24: 36102AFF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 00000084BE2C: 30101082
	ds_load_b32 v59, v8                                        // 00000084BE30: D8D80000 3B000008
	v_lshrrev_b32_e32 v8, 6, v21                               // 00000084BE38: 32102A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000084BE3C: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000084BE40: 361010FF 000003FC
	ds_load_b32 v60, v8                                        // 00000084BE48: D8D80000 3C000008
	v_lshrrev_b32_e32 v8, 14, v21                              // 00000084BE50: 32102A8E
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000084BE54: 361010FF 000003FC
	ds_load_b32 v61, v8                                        // 00000084BE5C: D8D80000 3D000008
	v_lshrrev_b32_e32 v8, 22, v21                              // 00000084BE64: 32102A96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000084BE68: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000084BE6C: 361010FF 000003FC
	ds_load_b32 v62, v8                                        // 00000084BE74: D8D80000 3E000008
	v_and_b32_e32 v8, 0xff, v22                                // 00000084BE7C: 36102CFF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 00000084BE84: 30101082
	ds_load_b32 v63, v8                                        // 00000084BE88: D8D80000 3F000008
	v_lshrrev_b32_e32 v8, 6, v22                               // 00000084BE90: 32102C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000084BE94: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000084BE98: 361010FF 000003FC
	ds_load_b32 v64, v8                                        // 00000084BEA0: D8D80000 40000008
	v_lshrrev_b32_e32 v8, 14, v22                              // 00000084BEA8: 32102C8E
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000084BEAC: 361010FF 000003FC
	ds_load_b32 v65, v8                                        // 00000084BEB4: D8D80000 41000008
	v_lshrrev_b32_e32 v8, 22, v22                              // 00000084BEBC: 32102C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000084BEC0: BF870141
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000084BEC4: 361010FF 000003FC
	ds_load_b32 v66, v8                                        // 00000084BECC: D8D80000 42000008
	.long 0xd73c0008                                           // 00000084BED4: D73C0008
	v_cndmask_b32_e32 v1, 1, v26, vcc_lo                       // 00000084BED8: 02023481
	v_add_nc_u32_e32 v26, 0x200, v26                           // 00000084BEDC: 4A3434FF 00000200
	.long 0xd7006a0c                                           // 00000084BEE4: D7006A0C
	v_cndmask_b32_e32 v1, s10, v8, vcc_lo                      // 00000084BEE8: 0202100A
	s_delay_alu instid0(VALU_DEP_1)                            // 00000084BEEC: BF870001
	v_add_co_ci_u32_e64 v13, null, s11, v9, vcc_lo             // 00000084BEF0: D5207C0D 01AA120B
	s_clause 0x3                                               // 00000084BEF8: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 00000084BEFC: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 00000084BF04: DC5E0010 137C000C
	global_load_b128 v[41:44], v[12:13], off offset:32         // 00000084BF0C: DC5E0020 297C000C
	global_load_b128 v[45:48], v[12:13], off offset:48         // 00000084BF14: DC5E0030 2D7C000C
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 00000084BF1C: BF890CF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000084BF20: CC1A4008 1A021D08
	s_waitcnt lgkmcnt(14)                                      // 00000084BF28: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084BF2C: BF8700A1
	v_dot2_f32_bf16 v8, v9, v52, v8                            // 00000084BF30: CC1A4008 1C226909
	s_waitcnt lgkmcnt(13)                                      // 00000084BF38: BF89FCD7
	v_dot2_f32_bf16 v8, v10, v53, v8                           // 00000084BF3C: CC1A4008 1C226B0A
	s_waitcnt lgkmcnt(12)                                      // 00000084BF44: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084BF48: BF8700A1
	v_dot2_f32_bf16 v8, v11, v54, v8                           // 00000084BF4C: CC1A4008 1C226D0B
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 00000084BF54: BF8908B7
	v_dot2_f32_bf16 v8, v19, v55, v8                           // 00000084BF58: CC1A4008 1C226F13
	s_waitcnt lgkmcnt(10)                                      // 00000084BF60: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084BF64: BF8700A1
	v_dot2_f32_bf16 v8, v20, v56, v8                           // 00000084BF68: CC1A4008 1C227114
	s_waitcnt lgkmcnt(9)                                       // 00000084BF70: BF89FC97
	v_dot2_f32_bf16 v8, v21, v57, v8                           // 00000084BF74: CC1A4008 1C227315
	s_waitcnt lgkmcnt(8)                                       // 00000084BF7C: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084BF80: BF8700A1
	v_dot2_f32_bf16 v8, v22, v58, v8                           // 00000084BF84: CC1A4008 1C227516
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 00000084BF8C: BF890477
	v_dot2_f32_bf16 v8, v41, v59, v8                           // 00000084BF90: CC1A4008 1C227729
	s_waitcnt lgkmcnt(6)                                       // 00000084BF98: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084BF9C: BF8700A1
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 00000084BFA0: CC1A4008 1C22792A
	s_waitcnt lgkmcnt(5)                                       // 00000084BFA8: BF89FC57
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 00000084BFAC: CC1A4008 1C227B2B
	s_waitcnt lgkmcnt(4)                                       // 00000084BFB4: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084BFB8: BF8700A1
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 00000084BFBC: CC1A4008 1C227D2C
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 00000084BFC4: BF890037
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 00000084BFC8: CC1A4008 1C227F2D
	.long 0xd7006a2d                                           // 00000084BFD0: D7006A2D
	v_cndmask_b32_e32 v0, v12, v8, vcc_lo                      // 00000084BFD4: 0200110C
	s_waitcnt lgkmcnt(2)                                       // 00000084BFD8: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000084BFDC: BF8701C2
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 00000084BFE0: CC1A4008 1C22812E
	v_add_co_ci_u32_e64 v46, null, s9, v13, vcc_lo             // 00000084BFE8: D5207C2E 01AA1A09
	.long 0xd7006a31                                           // 00000084BFF0: D7006A31
	v_cndmask_b32_e32 v0, v12, v18, vcc_lo                     // 00000084BFF4: 0200250C
	s_waitcnt lgkmcnt(1)                                       // 00000084BFF8: BF89FC17
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 00000084BFFC: CC1A4008 1C22832F
	v_add_co_ci_u32_e64 v50, null, s19, v13, vcc_lo            // 00000084C004: D5207C32 01AA1A13
	.long 0xd7006a0c                                           // 00000084C00C: D7006A0C
	v_cndmask_b32_e32 v0, v12, v21, vcc_lo                     // 00000084C010: 02002B0C
	s_waitcnt lgkmcnt(0)                                       // 00000084C014: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000084C018: BF870123
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 00000084C01C: CC1A4008 1C228530
	v_add_co_ci_u32_e64 v13, null, s7, v13, vcc_lo             // 00000084C024: D5207C0D 01AA1A07
	v_fmac_f32_e32 v37, v51, v8                                // 00000084C02C: 564A1133
	s_clause 0x3                                               // 00000084C030: BF850003
	global_load_b128 v[8:11], v[45:46], off                    // 00000084C034: DC5E0000 087C002D
	global_load_b128 v[19:22], v[45:46], off offset:16         // 00000084C03C: DC5E0010 137C002D
	global_load_b128 v[41:44], v[45:46], off offset:32         // 00000084C044: DC5E0020 297C002D
	global_load_b128 v[45:48], v[45:46], off offset:48         // 00000084C04C: DC5E0030 2D7C002D
	s_waitcnt vmcnt(3)                                         // 00000084C054: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000084C058: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084C060: BF870091
	v_dot2_f32_bf16 v8, v9, v52, v8                            // 00000084C064: CC1A4008 1C226909
	v_dot2_f32_bf16 v8, v10, v53, v8                           // 00000084C06C: CC1A4008 1C226B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084C074: BF8700A1
	v_dot2_f32_bf16 v8, v11, v54, v8                           // 00000084C078: CC1A4008 1C226D0B
	s_waitcnt vmcnt(2)                                         // 00000084C080: BF890BF7
	v_dot2_f32_bf16 v8, v19, v55, v8                           // 00000084C084: CC1A4008 1C226F13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084C08C: BF870091
	v_dot2_f32_bf16 v8, v20, v56, v8                           // 00000084C090: CC1A4008 1C227114
	v_dot2_f32_bf16 v8, v21, v57, v8                           // 00000084C098: CC1A4008 1C227315
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084C0A0: BF8700A1
	v_dot2_f32_bf16 v8, v22, v58, v8                           // 00000084C0A4: CC1A4008 1C227516
	s_waitcnt vmcnt(1)                                         // 00000084C0AC: BF8907F7
	v_dot2_f32_bf16 v8, v41, v59, v8                           // 00000084C0B0: CC1A4008 1C227729
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084C0B8: BF870091
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 00000084C0BC: CC1A4008 1C22792A
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 00000084C0C4: CC1A4008 1C227B2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084C0CC: BF8700A1
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 00000084C0D0: CC1A4008 1C227D2C
	s_waitcnt vmcnt(0)                                         // 00000084C0D8: BF8903F7
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 00000084C0DC: CC1A4008 1C227F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084C0E4: BF870091
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 00000084C0E8: CC1A4008 1C22812E
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 00000084C0F0: CC1A4008 1C22832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084C0F8: BF870091
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 00000084C0FC: CC1A4008 1C228530
	v_fmac_f32_e32 v36, v51, v8                                // 00000084C104: 56481133
	s_clause 0x3                                               // 00000084C108: BF850003
	global_load_b128 v[8:11], v[49:50], off                    // 00000084C10C: DC5E0000 087C0031
	global_load_b128 v[19:22], v[49:50], off offset:16         // 00000084C114: DC5E0010 137C0031
	global_load_b128 v[41:44], v[49:50], off offset:32         // 00000084C11C: DC5E0020 297C0031
	global_load_b128 v[45:48], v[49:50], off offset:48         // 00000084C124: DC5E0030 2D7C0031
	s_waitcnt vmcnt(3)                                         // 00000084C12C: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000084C130: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084C138: BF870091
	v_dot2_f32_bf16 v8, v9, v52, v8                            // 00000084C13C: CC1A4008 1C226909
	v_dot2_f32_bf16 v8, v10, v53, v8                           // 00000084C144: CC1A4008 1C226B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084C14C: BF8700A1
	v_dot2_f32_bf16 v8, v11, v54, v8                           // 00000084C150: CC1A4008 1C226D0B
	s_waitcnt vmcnt(2)                                         // 00000084C158: BF890BF7
	v_dot2_f32_bf16 v8, v19, v55, v8                           // 00000084C15C: CC1A4008 1C226F13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084C164: BF870091
	v_dot2_f32_bf16 v8, v20, v56, v8                           // 00000084C168: CC1A4008 1C227114
	v_dot2_f32_bf16 v8, v21, v57, v8                           // 00000084C170: CC1A4008 1C227315
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084C178: BF8700A1
	v_dot2_f32_bf16 v8, v22, v58, v8                           // 00000084C17C: CC1A4008 1C227516
	s_waitcnt vmcnt(1)                                         // 00000084C184: BF8907F7
	v_dot2_f32_bf16 v8, v41, v59, v8                           // 00000084C188: CC1A4008 1C227729
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084C190: BF870091
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 00000084C194: CC1A4008 1C22792A
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 00000084C19C: CC1A4008 1C227B2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084C1A4: BF8700A1
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 00000084C1A8: CC1A4008 1C227D2C
	s_waitcnt vmcnt(0)                                         // 00000084C1B0: BF8903F7
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 00000084C1B4: CC1A4008 1C227F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084C1BC: BF870091
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 00000084C1C0: CC1A4008 1C22812E
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 00000084C1C8: CC1A4008 1C22832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084C1D0: BF870091
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 00000084C1D4: CC1A4008 1C228530
	v_fmac_f32_e32 v35, v51, v8                                // 00000084C1DC: 56461133
	s_clause 0x3                                               // 00000084C1E0: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 00000084C1E4: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 00000084C1EC: DC5E0010 137C000C
	global_load_b128 v[41:44], v[12:13], off offset:32         // 00000084C1F4: DC5E0020 297C000C
	global_load_b128 v[45:48], v[12:13], off offset:48         // 00000084C1FC: DC5E0030 2D7C000C
	.long 0xd7006a0c                                           // 00000084C204: D7006A0C
	v_cndmask_b32_e32 v0, v49, v18, vcc_lo                     // 00000084C208: 02002531
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084C20C: BF8700A1
	v_add_co_ci_u32_e64 v13, null, s19, v50, vcc_lo            // 00000084C210: D5207C0D 01AA6413
	.long 0xd7006a1c                                           // 00000084C218: D7006A1C
	v_cndmask_b32_e32 v0, v28, v160, vcc_lo                    // 00000084C21C: 0201411C
	v_add_co_ci_u32_e64 v29, null, 0, v29, vcc_lo              // 00000084C220: D5207C1D 01AA3A80
	s_waitcnt vmcnt(3)                                         // 00000084C228: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000084C22C: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084C234: BF870091
	v_dot2_f32_bf16 v8, v9, v52, v8                            // 00000084C238: CC1A4008 1C226909
	v_dot2_f32_bf16 v8, v10, v53, v8                           // 00000084C240: CC1A4008 1C226B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084C248: BF8700A1
	v_dot2_f32_bf16 v8, v11, v54, v8                           // 00000084C24C: CC1A4008 1C226D0B
	s_waitcnt vmcnt(2)                                         // 00000084C254: BF890BF7
	v_dot2_f32_bf16 v8, v19, v55, v8                           // 00000084C258: CC1A4008 1C226F13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084C260: BF870091
	v_dot2_f32_bf16 v8, v20, v56, v8                           // 00000084C264: CC1A4008 1C227114
	v_dot2_f32_bf16 v8, v21, v57, v8                           // 00000084C26C: CC1A4008 1C227315
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084C274: BF8700A1
	v_dot2_f32_bf16 v8, v22, v58, v8                           // 00000084C278: CC1A4008 1C227516
	s_waitcnt vmcnt(1)                                         // 00000084C280: BF8907F7
	v_dot2_f32_bf16 v8, v41, v59, v8                           // 00000084C284: CC1A4008 1C227729
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084C28C: BF870091
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 00000084C290: CC1A4008 1C22792A
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 00000084C298: CC1A4008 1C227B2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084C2A0: BF8700A1
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 00000084C2A4: CC1A4008 1C227D2C
	s_waitcnt vmcnt(0)                                         // 00000084C2AC: BF8903F7
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 00000084C2B0: CC1A4008 1C227F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084C2B8: BF870091
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 00000084C2BC: CC1A4008 1C22812E
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 00000084C2C4: CC1A4008 1C22832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084C2CC: BF870091
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 00000084C2D0: CC1A4008 1C228530
	v_fmac_f32_e32 v34, v51, v8                                // 00000084C2D8: 56441133
	s_clause 0x3                                               // 00000084C2DC: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 00000084C2E0: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 00000084C2E8: DC5E0010 137C000C
	global_load_b128 v[41:44], v[12:13], off offset:32         // 00000084C2F0: DC5E0020 297C000C
	global_load_b128 v[45:48], v[12:13], off offset:48         // 00000084C2F8: DC5E0030 2D7C000C
	s_waitcnt vmcnt(3)                                         // 00000084C300: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000084C304: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084C30C: BF870091
	v_dot2_f32_bf16 v8, v9, v52, v8                            // 00000084C310: CC1A4008 1C226909
	v_dot2_f32_bf16 v8, v10, v53, v8                           // 00000084C318: CC1A4008 1C226B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084C320: BF8700A1
	v_dot2_f32_bf16 v8, v11, v54, v8                           // 00000084C324: CC1A4008 1C226D0B
	s_waitcnt vmcnt(2)                                         // 00000084C32C: BF890BF7
	v_dot2_f32_bf16 v8, v19, v55, v8                           // 00000084C330: CC1A4008 1C226F13
	v_mov_b32_e32 v19, v15                                     // 00000084C338: 7E26030F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000084C33C: BF870122
	v_dot2_f32_bf16 v8, v20, v56, v8                           // 00000084C340: CC1A4008 1C227114
	v_mov_b32_e32 v20, v16                                     // 00000084C348: 7E280310
	v_dot2_f32_bf16 v8, v21, v57, v8                           // 00000084C34C: CC1A4008 1C227315
	v_mov_b32_e32 v21, v17                                     // 00000084C354: 7E2A0311
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000084C358: BF870132
	v_dot2_f32_bf16 v8, v22, v58, v8                           // 00000084C35C: CC1A4008 1C227516
	v_mov_b32_e32 v22, v18                                     // 00000084C364: 7E2C0312
	s_waitcnt vmcnt(1)                                         // 00000084C368: BF8907F7
	v_dot2_f32_bf16 v8, v41, v59, v8                           // 00000084C36C: CC1A4008 1C227729
	v_mov_b32_e32 v41, v40                                     // 00000084C374: 7E520328
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084C378: BF870092
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 00000084C37C: CC1A4008 1C22792A
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 00000084C384: CC1A4008 1C227B2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084C38C: BF8700A1
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 00000084C390: CC1A4008 1C227D2C
	s_waitcnt vmcnt(0)                                         // 00000084C398: BF8903F7
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 00000084C39C: CC1A4008 1C227F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084C3A4: BF870091
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 00000084C3A8: CC1A4008 1C22812E
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 00000084C3B0: CC1A4008 1C22832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084C3B8: BF870091
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 00000084C3BC: CC1A4008 1C228530
	v_fmac_f32_e32 v33, v51, v8                                // 00000084C3C4: 56421133
	v_mov_b32_e32 v14, v7                                      // 00000084C3C8: 7E1C0307
	v_dual_mov_b32 v13, v6 :: v_dual_mov_b32 v12, v5           // 00000084C3CC: CA100106 0D0C0105
	v_dual_mov_b32 v11, v4 :: v_dual_mov_b32 v10, v3           // 00000084C3D4: CA100104 0B0A0103
	v_dual_mov_b32 v9, v2 :: v_dual_mov_b32 v8, v1             // 00000084C3DC: CA100102 09080101
	v_mov_b32_e32 v7, v0                                       // 00000084C3E4: 7E0E0300
	s_and_not1_b32 exec_lo, exec_lo, s20                       // 00000084C3E8: 917E147E
	s_cbranch_execz 28                                         // 00000084C3EC: BFA5001C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0xc60>
	s_waitcnt vmcnt(0)                                         // 00000084C3F0: BF8903F7
	v_dual_mov_b32 v16, v20 :: v_dual_add_nc_u32 v39, 16, v39  // 00000084C3F4: CA200114 10264E90
	v_dual_mov_b32 v15, v19 :: v_dual_mov_b32 v18, v22         // 00000084C3FC: CA100113 0F120116
	v_mov_b32_e32 v17, v21                                     // 00000084C404: 7E220315
	s_delay_alu instid0(VALU_DEP_3)                            // 00000084C408: BF870003
	.long 0xd4430004                                           // 00000084C40C: D4430004
	v_cndmask_b32_e32 v1, s6, v39, vcc_lo                      // 00000084C410: 02024E06
	s_mov_b32 s14, exec_lo                                     // 00000084C414: BE8E007E
	.long 0xd4c4007e                                           // 00000084C418: D4C4007E
	v_cndmask_b32_e32 v1, s6, v39, vcc_lo                      // 00000084C41C: 02024E06
	s_cbranch_execz 65086                                      // 00000084C420: BFA5FE3E <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x51c>
	.long 0xd7006a00                                           // 00000084C424: D7006A00
	v_cndmask_b32_e32 v1, v25, v38, vcc_lo                     // 00000084C428: 02024D19
	s_delay_alu instid0(VALU_DEP_1)                            // 00000084C42C: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v32, vcc_lo               // 00000084C430: D5207C01 01AA4080
	v_cmp_ne_u32_e32 vcc_lo, 1, v31                            // 00000084C438: 7C9A3E81
	v_mov_b32_e32 v40, v41                                     // 00000084C43C: 7E500329
	global_load_b128 v[15:18], v[0:1], off                     // 00000084C440: DC5E0000 0F7C0000
	s_cbranch_vccnz 65076                                      // 00000084C448: BFA4FE34 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x51c>
	global_load_d16_b16 v0, v[28:29], off                      // 00000084C44C: DC820000 007C001C
	s_waitcnt vmcnt(0)                                         // 00000084C454: BF8903F7
	v_cvt_f32_f16_e32 v40, v0                                  // 00000084C458: 7E501700
	s_branch 65071                                             // 00000084C45C: BFA0FE2F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x51c>
	s_or_b32 exec_lo, exec_lo, s20                             // 00000084C460: 8C7E147E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084C464: BF8700A9
	s_or_b32 exec_lo, exec_lo, s5                              // 00000084C468: 8C7E057E
	.long 0xd71f0000                                           // 00000084C46C: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000084C470: 020100C1
	v_xor_b32_e32 v1, 8, v0                                    // 00000084C474: 3A020088
	v_xor_b32_e32 v6, 4, v0                                    // 00000084C478: 3A0C0084
	v_xor_b32_e32 v11, 2, v0                                   // 00000084C47C: 3A160082
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000084C480: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v1                            // 00000084C484: 7C9802A0
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 00000084C488: 02020300
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 00000084C48C: 7C980CA0
	v_cndmask_b32_e32 v6, v0, v6, vcc_lo                       // 00000084C490: 020C0D00
	v_cmp_gt_u32_e32 vcc_lo, 32, v11                           // 00000084C494: 7C9816A0
	s_delay_alu instid0(VALU_DEP_2)                            // 00000084C498: BF870002
	v_lshlrev_b32_e32 v6, 2, v6                                // 00000084C49C: 300C0C82
	v_lshlrev_b32_e32 v1, 2, v1                                // 00000084C4A0: 30020282
	ds_bpermute_b32 v2, v1, v37                                // 00000084C4A4: DACC0000 02002501
	s_waitcnt lgkmcnt(0)                                       // 00000084C4AC: BF89FC07
	v_add_f32_e32 v2, v37, v2                                  // 00000084C4B0: 06040525
	ds_bpermute_b32 v3, v1, v36                                // 00000084C4B4: DACC0000 03002401
	ds_bpermute_b32 v4, v1, v35                                // 00000084C4BC: DACC0000 04002301
	ds_bpermute_b32 v5, v1, v34                                // 00000084C4C4: DACC0000 05002201
	ds_bpermute_b32 v1, v1, v33                                // 00000084C4CC: DACC0000 01002101
	ds_bpermute_b32 v7, v6, v2                                 // 00000084C4D4: DACC0000 07000206
	s_waitcnt lgkmcnt(3)                                       // 00000084C4DC: BF89FC37
	v_dual_add_f32 v3, v36, v3 :: v_dual_add_f32 v4, v35, v4   // 00000084C4E0: C9080724 03040923
	s_waitcnt lgkmcnt(2)                                       // 00000084C4E8: BF89FC27
	v_add_f32_e32 v5, v34, v5                                  // 00000084C4EC: 060A0B22
	s_waitcnt lgkmcnt(0)                                       // 00000084C4F0: BF89FC07
	v_dual_add_f32 v1, v33, v1 :: v_dual_add_f32 v2, v2, v7    // 00000084C4F4: C9080321 01020F02
	ds_bpermute_b32 v8, v6, v3                                 // 00000084C4FC: DACC0000 08000306
	ds_bpermute_b32 v9, v6, v4                                 // 00000084C504: DACC0000 09000406
	ds_bpermute_b32 v10, v6, v5                                // 00000084C50C: DACC0000 0A000506
	ds_bpermute_b32 v6, v6, v1                                 // 00000084C514: DACC0000 06000106
	v_cndmask_b32_e32 v11, v0, v11, vcc_lo                     // 00000084C51C: 02161700
	s_waitcnt lgkmcnt(2)                                       // 00000084C520: BF89FC27
	v_dual_add_f32 v3, v3, v8 :: v_dual_add_f32 v4, v4, v9     // 00000084C524: C9081103 03041304
	s_waitcnt lgkmcnt(0)                                       // 00000084C52C: BF89FC07
	v_add_f32_e32 v8, v1, v6                                   // 00000084C530: 06100D01
	v_xor_b32_e32 v6, 1, v0                                    // 00000084C534: 3A0C0081
	v_lshlrev_b32_e32 v11, 2, v11                              // 00000084C538: 30161682
	s_delay_alu instid0(VALU_DEP_2)                            // 00000084C53C: BF870002
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 00000084C540: 7C980CA0
	ds_bpermute_b32 v1, v11, v2                                // 00000084C544: DACC0000 0100020B
	ds_bpermute_b32 v9, v11, v4                                // 00000084C54C: DACC0000 0900040B
	v_cndmask_b32_e32 v0, v0, v6, vcc_lo                       // 00000084C554: 02000D00
	v_add_f32_e32 v5, v5, v10                                  // 00000084C558: 060A1505
	ds_bpermute_b32 v7, v11, v3                                // 00000084C55C: DACC0000 0700030B
	v_cmp_eq_u32_e32 vcc_lo, 0, v30                            // 00000084C564: 7C943C80
	v_lshlrev_b32_e32 v12, 2, v0                               // 00000084C568: 30180082
	ds_bpermute_b32 v10, v11, v5                               // 00000084C56C: DACC0000 0A00050B
	ds_bpermute_b32 v11, v11, v8                               // 00000084C574: DACC0000 0B00080B
	s_and_b32 s2, vcc_lo, s2                                   // 00000084C57C: 8B02026A
	s_waitcnt lgkmcnt(4)                                       // 00000084C580: BF89FC47
	v_add_f32_e32 v6, v2, v1                                   // 00000084C584: 060C0302
	s_waitcnt lgkmcnt(2)                                       // 00000084C588: BF89FC27
	v_dual_add_f32 v0, v4, v9 :: v_dual_add_f32 v7, v3, v7     // 00000084C58C: C9081304 00060F03
	s_waitcnt lgkmcnt(0)                                       // 00000084C594: BF89FC07
	v_dual_add_f32 v1, v5, v10 :: v_dual_add_f32 v2, v8, v11   // 00000084C598: C9081505 01021708
	ds_bpermute_b32 v8, v12, v6                                // 00000084C5A0: DACC0000 0800060C
	ds_bpermute_b32 v9, v12, v7                                // 00000084C5A8: DACC0000 0900070C
	ds_bpermute_b32 v3, v12, v0                                // 00000084C5B0: DACC0000 0300000C
	ds_bpermute_b32 v4, v12, v1                                // 00000084C5B8: DACC0000 0400010C
	ds_bpermute_b32 v5, v12, v2                                // 00000084C5C0: DACC0000 0500020C
	s_and_saveexec_b32 s3, s2                                  // 00000084C5C8: BE832002
	s_cbranch_execz 229                                        // 00000084C5CC: BFA500E5 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x1164>
	s_load_b32 s0, s[0:1], 0x48                                // 00000084C5D0: F4000000 F8000048
	s_waitcnt lgkmcnt(0)                                       // 00000084C5D8: BF89FC07
	v_dual_add_f32 v6, v6, v8 :: v_dual_add_f32 v7, v7, v9     // 00000084C5DC: C9081106 06061307
	v_dual_add_f32 v0, v0, v3 :: v_dual_add_f32 v1, v1, v4     // 00000084C5E4: C9080700 00000901
	s_lshl_b64 s[4:5], s[16:17], 2                             // 00000084C5EC: 84848210
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000084C5F0: BF870192
	v_bfe_u32 v8, v6, 16, 1                                    // 00000084C5F4: D6100008 02052106
	v_bfe_u32 v9, v7, 16, 1                                    // 00000084C5FC: D6100009 02052107
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000084C604: BF8701A2
	v_add3_u32 v3, v6, v8, 0x7fff                              // 00000084C608: D6550003 03FE1106 00007FFF
	v_add_f32_e32 v2, v2, v5                                   // 00000084C614: 06040B02
	v_add3_u32 v4, v7, v9, 0x7fff                              // 00000084C618: D6550004 03FE1307 00007FFF
	v_bfe_u32 v6, v1, 16, 1                                    // 00000084C624: D6100006 02052101
	v_bfe_u32 v5, v0, 16, 1                                    // 00000084C62C: D6100005 02052100
	v_and_b32_e32 v3, 0xffff0000, v3                           // 00000084C634: 360606FF FFFF0000
	v_bfe_u32 v7, v2, 16, 1                                    // 00000084C63C: D6100007 02052102
	v_and_b32_e32 v4, 0xffff0000, v4                           // 00000084C644: 360808FF FFFF0000
	v_add3_u32 v1, v1, v6, 0x7fff                              // 00000084C64C: D6550001 03FE0D01 00007FFF
	v_add3_u32 v0, v0, v5, 0x7fff                              // 00000084C658: D6550000 03FE0B00 00007FFF
	v_mul_f32_e32 v3, s0, v3                                   // 00000084C664: 10060600
	v_add3_u32 v2, v2, v7, 0x7fff                              // 00000084C668: D6550002 03FE0F02 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000084C674: BF870214
	v_dual_mul_f32 v4, s0, v4 :: v_dual_and_b32 v1, 0xffff0000, v1// 00000084C678: C8E40800 040002FF FFFF0000
	v_and_b32_e32 v0, 0xffff0000, v0                           // 00000084C684: 360000FF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000084C68C: BF870112
	v_dual_mul_f32 v3, 0xbfb8aa3b, v3 :: v_dual_mul_f32 v4, 0xbfb8aa3b, v4// 00000084C690: C8C606FF 030408FF BFB8AA3B
	v_dual_mul_f32 v1, s0, v1 :: v_dual_mul_f32 v0, s0, v0     // 00000084C69C: C8C60200 01000000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000084C6A4: BF8701A2
	v_exp_f32_e32 v3, v3                                       // 00000084C6A8: 7E064B03
	v_and_b32_e32 v2, 0xffff0000, v2                           // 00000084C6AC: 360404FF FFFF0000
	v_exp_f32_e32 v4, v4                                       // 00000084C6B4: 7E084B04
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000084C6B8: BF870122
	v_dual_mul_f32 v6, 0xbfb8aa3b, v1 :: v_dual_mul_f32 v5, 0xbfb8aa3b, v0// 00000084C6BC: C8C602FF 060400FF BFB8AA3B
	.long 0xd73c0000                                           // 00000084C6C8: D73C0000
	v_cndmask_b32_e32 v1, 2, v23, vcc_lo                       // 00000084C6CC: 02022E82
	v_exp_f32_e32 v5, v5                                       // 00000084C6D0: 7E0A4B05
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 00000084C6D4: BF870317
	v_dual_add_f32 v7, 1.0, v3 :: v_dual_mul_f32 v2, s0, v2    // 00000084C6D8: C90606F2 07020400
	v_add_f32_e32 v8, 1.0, v4                                  // 00000084C6E0: 061008F2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000084C6E4: BF870193
	.long 0xd7006a03                                           // 00000084C6E8: D7006A03
	v_cndmask_b32_e32 v1, s12, v0, vcc_lo                      // 00000084C6EC: 0202000C
	v_div_scale_f32 v0, null, v7, v7, 1.0                      // 00000084C6F0: D6FC7C00 03CA0F07
	v_add_co_ci_u32_e64 v4, null, s13, v1, vcc_lo              // 00000084C6F8: D5207C04 01AA020D
	v_div_scale_f32 v14, vcc_lo, 1.0, v7, 1.0                  // 00000084C700: D6FC6A0E 03CA0EF2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000084C708: BF870125
	v_add_f32_e32 v1, 1.0, v5                                  // 00000084C70C: 06020AF2
	v_div_scale_f32 v5, null, v8, v8, 1.0                      // 00000084C710: D6FC7C05 03CA1108
	v_div_scale_f32 v10, null, v1, v1, 1.0                     // 00000084C718: D6FC7C0A 03CA0301
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000084C720: BF870132
	v_rcp_f32_e32 v11, v5                                      // 00000084C724: 7E165505
	s_waitcnt vmcnt(0)                                         // 00000084C728: BF8903F7
	v_div_scale_f32 v20, s1, 1.0, v1, 1.0                      // 00000084C72C: D6FC0114 03CA02F2
	v_rcp_f32_e32 v15, v10                                     // 00000084C734: 7E1E550A
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084C738: BF870096
	v_fma_f32 v21, -v5, v11, 1.0                               // 00000084C73C: D6130015 23CA1705
	v_fmac_f32_e32 v11, v21, v11                               // 00000084C744: 56161715
	v_exp_f32_e32 v6, v6                                       // 00000084C748: 7E0C4B06
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000084C74C: BF870135
	v_add_f32_e32 v9, 1.0, v6                                  // 00000084C750: 06120CF2
	v_rcp_f32_e32 v6, v0                                       // 00000084C754: 7E0C5500
	v_div_scale_f32 v16, s0, 1.0, v8, 1.0                      // 00000084C758: D6FC0010 03CA10F2
	v_div_scale_f32 v12, null, v9, v9, 1.0                     // 00000084C760: D6FC7C0C 03CA1309
	v_div_scale_f32 v22, s2, 1.0, v9, 1.0                      // 00000084C768: D6FC0216 03CA12F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 00000084C770: BF870312
	v_rcp_f32_e32 v17, v12                                     // 00000084C774: 7E22550C
	v_fma_f32 v19, -v0, v6, 1.0                                // 00000084C778: D6130013 23CA0D00
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000084C780: BF870115
	v_fma_f32 v21, -v12, v17, 1.0                              // 00000084C784: D6130015 23CA230C
	v_fmac_f32_e32 v6, v19, v6                                 // 00000084C78C: 560C0D13
	v_fma_f32 v19, -v10, v15, 1.0                              // 00000084C790: D6130013 23CA1F0A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000084C798: BF870113
	v_dual_mul_f32 v2, 0xbfb8aa3b, v2 :: v_dual_fmac_f32 v17, v21, v17// 00000084C79C: C8C004FF 02102315 BFB8AA3B
	v_fmac_f32_e32 v15, v19, v15                               // 00000084C7A8: 561E1F13
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000084C7AC: BF870142
	v_exp_f32_e32 v2, v2                                       // 00000084C7B0: 7E044B02
	v_mul_f32_e32 v25, v14, v6                                 // 00000084C7B4: 10320D0E
	v_mul_f32_e32 v19, v16, v11                                // 00000084C7B8: 10261710
	v_mul_f32_e32 v27, v22, v17                                // 00000084C7BC: 10362316
	v_fma_f32 v26, -v5, v19, v16                               // 00000084C7C0: D613001A 24422705
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_1)   // 00000084C7C8: BF870085
	v_dual_add_f32 v2, 1.0, v2 :: v_dual_fmac_f32 v19, v26, v11// 00000084C7CC: C90004F2 0212171A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000084C7D4: BF870113
	v_fma_f32 v26, -v12, v27, v22                              // 00000084C7D8: D613001A 245A370C
	v_div_scale_f32 v13, null, v2, v2, 1.0                     // 00000084C7E0: D6FC7C0D 03CA0502
	v_div_scale_f32 v23, s3, 1.0, v2, 1.0                      // 00000084C7E8: D6FC0317 03CA04F2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000084C7F0: BF870214
	v_fma_f32 v5, -v5, v19, v16                                // 00000084C7F4: D6130005 24422705
	v_fmac_f32_e32 v27, v26, v17                               // 00000084C7FC: 5636231A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000084C800: BF870294
	v_rcp_f32_e32 v18, v13                                     // 00000084C804: 7E24550D
	v_fma_f32 v24, -v13, v18, 1.0                              // 00000084C808: D6130018 23CA250D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000084C810: BF8701B1
	v_fmac_f32_e32 v18, v24, v18                               // 00000084C814: 56242518
	v_mul_f32_e32 v24, v20, v15                                // 00000084C818: 10301F14
	v_fma_f32 v21, -v0, v25, v14                               // 00000084C81C: D6130015 243A3300
	v_mul_f32_e32 v28, v23, v18                                // 00000084C824: 10382517
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000084C828: BF870212
	v_fmac_f32_e32 v25, v21, v6                                // 00000084C82C: 56320D15
	v_fma_f32 v21, -v10, v24, v20                              // 00000084C830: D6130015 2452310A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000084C838: BF870193
	v_fma_f32 v29, -v13, v28, v23                              // 00000084C83C: D613001D 245E390D
	v_fma_f32 v0, -v0, v25, v14                                // 00000084C844: D6130000 243A3300
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000084C84C: BF870113
	v_fmac_f32_e32 v24, v21, v15                               // 00000084C850: 56301F15
	v_div_fmas_f32 v0, v0, v6, v25                             // 00000084C854: D6370000 04660D00
	s_mov_b32 vcc_lo, s0                                       // 00000084C85C: BEEA0000
	s_delay_alu instid0(VALU_DEP_2)                            // 00000084C860: BF870002
	v_fma_f32 v6, -v10, v24, v20                               // 00000084C864: D6130006 2452310A
	v_div_fmas_f32 v5, v5, v11, v19                            // 00000084C86C: D6370005 044E1705
	s_mov_b32 vcc_lo, s1                                       // 00000084C874: BEEA0001
	v_div_fixup_f32 v0, v0, v7, 1.0                            // 00000084C878: D6270000 03CA0F00
	v_fmac_f32_e32 v28, v29, v18                               // 00000084C880: 5638251D
	v_div_fmas_f32 v7, v6, v15, v24                            // 00000084C884: D6370007 04621F06
	v_div_fixup_f32 v5, v5, v8, 1.0                            // 00000084C88C: D6270005 03CA1105
	s_lshl_b64 s[0:1], s[16:17], 3                             // 00000084C894: 84808310
	v_add_f32_e32 v11, v0, v0                                  // 00000084C898: 06160100
	v_fma_f32 v0, -v12, v27, v22                               // 00000084C89C: D6130000 245A370C
	v_div_fixup_f32 v1, v7, v1, 1.0                            // 00000084C8A4: D6270001 03CA0307
	v_add_f32_e32 v14, v5, v5                                  // 00000084C8AC: 061C0B05
	.long 0xd7006a05                                           // 00000084C8B0: D7006A05
	v_cndmask_b32_e32 v0, v3, v4, vcc_lo                       // 00000084C8B4: 02000903
	v_fma_f32 v7, -v13, v28, v23                               // 00000084C8B8: D6130007 245E390D
	v_add_co_ci_u32_e64 v6, null, s5, v4, vcc_lo               // 00000084C8C0: D5207C06 01AA0805
	s_mov_b32 vcc_lo, s2                                       // 00000084C8C8: BEEA0002
	v_add_f32_e32 v12, v1, v1                                  // 00000084C8CC: 06180301
	v_div_fmas_f32 v8, v0, v17, v27                            // 00000084C8D0: D6370008 046E2300
	s_mov_b32 vcc_lo, s3                                       // 00000084C8D8: BEEA0003
	v_mad_u64_u32 v[0:1], null, s16, 12, v[3:4]                // 00000084C8DC: D6FE7C00 040D1810
	v_div_fmas_f32 v7, v7, v18, v28                            // 00000084C8E4: D6370007 04722507
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000084C8EC: BF870113
	v_div_fixup_f32 v9, v8, v9, 1.0                            // 00000084C8F0: D6270009 03CA1308
	v_div_fixup_f32 v10, v7, v2, 1.0                           // 00000084C8F8: D627000A 03CA0507
	.long 0xd7006a07                                           // 00000084C900: D7006A07
	v_cndmask_b32_e32 v0, v3, v0, vcc_lo                       // 00000084C904: 02000103
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000084C908: BF870221
	v_add_co_ci_u32_e64 v8, null, s1, v4, vcc_lo               // 00000084C90C: D5207C08 01AA0801
	v_mad_u64_u32 v[1:2], null, s17, 12, v[1:2]                // 00000084C914: D6FE7C01 04051811
	v_dual_add_f32 v13, v9, v9 :: v_dual_add_f32 v2, v10, v10  // 00000084C91C: C9081309 0D02150A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084C924: BF870094
	.long 0xd7006a09                                           // 00000084C928: D7006A09
	v_cndmask_b32_e32 v0, v7, v0, vcc_lo                       // 00000084C92C: 02000107
	v_add_co_ci_u32_e64 v10, null, s1, v8, vcc_lo              // 00000084C930: D5207C0A 01AA1001
	s_clause 0x4                                               // 00000084C938: BF850004
	global_store_b32 v[3:4], v11, off                          // 00000084C93C: DC6A0000 007C0B03
	global_store_b32 v[5:6], v14, off                          // 00000084C944: DC6A0000 007C0E05
	global_store_b32 v[7:8], v12, off                          // 00000084C94C: DC6A0000 007C0C07
	global_store_b32 v[0:1], v13, off                          // 00000084C954: DC6A0000 007C0D00
	global_store_b32 v[9:10], v2, off                          // 00000084C95C: DC6A0000 007C0209
	s_endpgm                                                   // 00000084C964: BFB00000
		...

