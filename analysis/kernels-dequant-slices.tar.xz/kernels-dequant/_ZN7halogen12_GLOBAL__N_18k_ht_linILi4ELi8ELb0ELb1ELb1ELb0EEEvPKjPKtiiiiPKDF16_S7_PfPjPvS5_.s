0000000000491800 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_>:
; _ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_():
	s_clause 0x3                                               // 000000491800: BF850003
	s_load_b256 s[12:19], s[0:1], null                         // 000000491804: F40C0300 F8000000
	s_load_b256 s[20:27], s[0:1], 0x20                         // 00000049180C: F40C0500 F8000020
	s_load_b128 s[28:31], s[0:1], 0x40                         // 000000491814: F4080700 F8000040
	s_load_b32 s33, s[0:1], 0x54                               // 00000049181C: F4000840 F8000054
	v_lshrrev_b32_e32 v35, 5, v0                               // 000000491824: 32460085
	v_and_b32_e32 v36, 31, v0                                  // 000000491828: 3648009F
	s_mov_b32 s10, s3                                          // 00000049182C: BE8A0003
	s_mov_b32 s34, exec_lo                                     // 000000491830: BEA2007E
	s_waitcnt lgkmcnt(0)                                       // 000000491834: BF89FC07
	s_ashr_i32 s11, s17, 31                                    // 000000491838: 860B9F11
	s_mul_i32 s9, s19, s3                                      // 00000049183C: 96090313
	s_lshr_b32 s0, s11, 25                                     // 000000491840: 8500990B
	s_add_i32 s1, s9, s19                                      // 000000491844: 81011309
	s_add_i32 s0, s17, s0                                      // 000000491848: 81000011
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000049184C: BF870499
	s_ashr_i32 s0, s0, 7                                       // 000000491850: 86008700
	s_min_i32 s0, s0, s1                                       // 000000491854: 89000100
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000491858: BF870499
	s_sub_i32 s1, s0, s9                                       // 00000049185C: 81810900
	s_lshl_b32 s19, s1, 3                                      // 000000491860: 84138301
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000491864: BF870009
	.long 0xd4c4007e                                           // 000000491868: D4C4007E
	v_cndmask_b32_e32 v1, s19, v35, vcc_lo                     // 00000049186C: 02024613
	s_cbranch_execz 504                                        // 000000491870: BFA501F8 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x854>
	s_add_i32 s35, s16, -1                                     // 000000491874: 8123C110
	s_cmp_lg_u64 s[30:31], 0                                   // 000000491878: BF11801E
	v_and_b32_e32 v2, 1, v0                                    // 00000049187C: 36040081
	s_cselect_b32 s36, -1, 0                                   // 000000491880: 982480C1
	s_abs_i32 s37, s1                                          // 000000491884: BEA51501
	v_lshlrev_b32_e32 v7, 3, v36                               // 000000491888: 300E4883
	s_cvt_f32_u32 s0, s37                                      // 00000049188C: BE806525
	v_dual_mov_b32 v8, v35 :: v_dual_lshlrev_b32 v1, 2, v36    // 000000491890: CA220123 08004882
	v_and_b32_e32 v4, 2, v0                                    // 000000491898: 36080082
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000049189C: BF870009
	v_rcp_iflag_f32_e32 v3, s0                                 // 0000004918A0: 7E065600
	v_and_b32_e32 v5, 4, v0                                    // 0000004918A4: 360A0084
	v_and_b32_e32 v6, 8, v0                                    // 0000004918A8: 360C0088
	v_add_nc_u32_e32 v9, s9, v35                               // 0000004918AC: 4A124609
	s_ashr_i32 s40, s1, 31                                     // 0000004918B0: 86289F01
	s_lshl_b32 s41, s1, 8                                      // 0000004918B4: 84298801
	s_lshl_b32 s6, s1, 7                                       // 0000004918B8: 84068701
	.long 0xd44a0001                                           // 0000004918BC: D44A0001
	v_cndmask_b32_e32 v1, 0, v2, vcc_lo                        // 0000004918C0: 02020480
	v_lshl_or_b32 v2, v35, 8, v7                               // 0000004918C4: D6560002 041D1123
	s_sub_i32 s8, 0, s37                                       // 0000004918CC: 81882580
	v_readfirstlane_b32 s4, v3                                 // 0000004918D0: 7E080503
	s_mul_i32 s43, s40, 0x1400                                 // 0000004918D4: 962BFF28 00001400
	.long 0xd44c0000                                           // 0000004918DC: D44C0000
	v_cndmask_b32_e32 v1, 16, v36, vcc_lo                      // 0000004918E0: 02024890
	.long 0xd44a0003                                           // 0000004918E4: D44A0003
	v_cndmask_b32_e32 v1, 0, v4, vcc_lo                        // 0000004918E8: 02020880
	.long 0xd44a0005                                           // 0000004918EC: D44A0005
	v_cndmask_b32_e32 v1, 0, v6, vcc_lo                        // 0000004918F0: 02020C80
	s_mul_f32 s7, s4, 0x4f7ffffe                               // 0000004918F4: A207FF04 4F7FFFFE
	.long 0xd44a0004                                           // 0000004918FC: D44A0004
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 000000491900: 02020A80
	v_lshl_or_b32 v1, v9, 7, v1                                // 000000491904: D6560001 04050F09
	v_subrev_nc_u32_e32 v9, s43, v2                            // 00000049190C: 4E12042B
	s_cvt_u32_f32 s7, s7                                       // 000000491910: BE876707
	s_sub_i32 s42, 0, s6                                       // 000000491914: 81AA0680
	s_mov_b32 s38, s17                                         // 000000491918: BEA60011
	s_mov_b32 s39, 0                                           // 00000049191C: BEA70080
	s_mul_i32 s8, s8, s7                                       // 000000491920: 96080708
	s_mov_b32 s44, 0x76543210                                  // 000000491924: BEAC00FF 76543210
	s_mul_hi_u32 s6, s7, s8                                    // 00000049192C: 96860807
	s_mov_b32 s45, 0x3db504f3                                  // 000000491930: BEAD00FF 3DB504F3
	s_add_i32 s43, s7, s6                                      // 000000491938: 812B0607
	s_branch 164                                               // 00000049193C: BFA000A4 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x3d0>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000491940: BF870091
	.long 0xd7006a02                                           // 000000491944: D7006A02
	v_cndmask_b32_e32 v1, s20, v2, vcc_lo                      // 000000491948: 02020414
	v_add_co_ci_u32_e64 v3, null, s21, v3, vcc_lo              // 00000049194C: D5207C03 01AA0615
	v_sub_f32_e32 v4, v15, v13                                 // 000000491954: 08081B0F
	v_add_nc_u32_e32 v1, 0x400, v1                             // 000000491958: 4A0202FF 00000400
	global_load_d16_b16 v2, v[2:3], off offset:6               // 000000491960: DC820006 027C0002
	s_waitcnt vmcnt(0)                                         // 000000491968: BF8903F7
	v_fma_mix_f32 v5, v14, v2, v12 op_sel_hi:[0,1,0]           // 00000049196C: CC200005 1432050E
	v_fma_mix_f32 v2, -v14, v2, v12 op_sel_hi:[0,1,0]          // 000000491974: CC200002 3432050E
	v_add_f32_e32 v3, v15, v13                                 // 00000049197C: 06061B0F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000491980: BF8701A2
	v_add_f32_e32 v7, v4, v2                                   // 000000491984: 060E0504
	v_sub_f32_e32 v2, v4, v2                                   // 000000491988: 08040504
	v_add_f32_e32 v6, v3, v5                                   // 00000049198C: 060C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 000000491990: 08060B03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000491994: BF870193
	v_mov_b32_dpp v13, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000491998: 7E1A02FA FF016102
	v_mov_b32_dpp v4, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004919A0: 7E0802FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 0000004919A8: D5010006 20060D06
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 0000004919B0: D5010002 20060502
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000004919B8: BF870142
	v_add_f32_e32 v4, v6, v4                                   // 0000004919BC: 06080906
	v_mov_b32_dpp v5, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004919C0: 7E0A02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 0000004919C8: D5010007 20060F07
	.long 0xd72c0006                                           // 0000004919D0: D72C0006
	v_cndmask_b32_e32 v1, 0x1400, v11, vcc_lo                  // 0000004919D4: 020216FF 00001400
	v_add_f32_e32 v5, v7, v5                                   // 0000004919DC: 060A0B07
	v_mov_b32_dpp v7, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000004919E0: 7E0E02FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 0000004919E8: D5010004 200E0904
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004919F0: BF870001
	v_add_f32_e32 v4, v4, v7                                   // 0000004919F4: 06080F04
	v_mov_b32_dpp v12, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004919F8: 7E1802FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 000000491A00: D5010003 20060703
	.long 0xd72c0007                                           // 000000491A08: D72C0007
	v_cndmask_b32_e32 v1, s41, v10, vcc_lo                     // 000000491A0C: 02021429
	v_add_f32_e32 v2, v2, v13                                  // 000000491A10: 06041B02
	v_mov_b32_dpp v10, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000491A14: 7E1402FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s4                          // 000000491A1C: D5010004 20120904
	v_add_f32_e32 v3, v3, v12                                  // 000000491A24: 06061903
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000491A28: BF870224
	v_mov_b32_dpp v13, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000491A2C: 7E1A02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 000000491A34: D5010002 200E0502
	v_add_f32_e32 v4, v4, v10                                  // 000000491A3C: 06081504
	v_mov_b32_dpp v11, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000491A40: 7E1602FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 000000491A48: D5010005 200E0B05
	v_mov_b32_dpp v12, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000491A50: 7E1802FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 000000491A58: D5010003 200E0703
	v_add_f32_e32 v2, v2, v13                                  // 000000491A60: 06041B02
	v_mov_b32_dpp v10, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000491A64: 7E1402FA FF016804
	v_add_f32_e32 v5, v5, v11                                  // 000000491A6C: 060A1705
	v_cndmask_b32_e64 v4, -v4, v4, s5                          // 000000491A70: D5010004 20160904
	v_add_f32_e32 v3, v3, v12                                  // 000000491A78: 06061903
	v_mov_b32_dpp v13, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000491A7C: 7E1A02FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s4                          // 000000491A84: D5010002 20120502
	v_mov_b32_dpp v11, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000491A8C: 7E1602FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s4                          // 000000491A94: D5010005 20120B05
	v_mov_b32_dpp v12, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000491A9C: 7E1802FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s4                          // 000000491AA4: D5010003 20120703
	v_add_f32_e32 v2, v2, v13                                  // 000000491AAC: 06041B02
	v_sub_nc_u32_e32 v6, v6, v7                                // 000000491AB0: 4C0C0F06
	v_add_f32_e32 v5, v5, v11                                  // 000000491AB4: 060A1705
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000491AB8: BF870214
	v_add_f32_e32 v3, v3, v12                                  // 000000491ABC: 06061903
	v_mov_b32_dpp v13, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000491AC0: 7E1A02FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s5                          // 000000491AC8: D5010002 20160502
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000491AD0: BF870254
	v_mov_b32_dpp v11, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000491AD4: 7E1602FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s5                          // 000000491ADC: D5010005 20160B05
	v_add_nc_u32_e32 v8, 8, v8                                 // 000000491AE4: 4A101088
	v_mov_b32_dpp v12, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000491AE8: 7E1802FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s5                          // 000000491AF0: D5010003 20160703
	v_dual_add_f32 v4, v4, v10 :: v_dual_add_f32 v5, v5, v11   // 000000491AF8: C9081504 04041705
	v_add_f32_e32 v2, v2, v13                                  // 000000491B00: 06041B02
	v_cmp_le_i32_e32 vcc_lo, s19, v8                           // 000000491B04: 7C861013
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000491B08: BF870214
	v_dual_add_f32 v3, v3, v12 :: v_dual_add_nc_u32 v6, v9, v6 // 000000491B0C: C9201903 03060D09
	v_dual_mov_b32 v11, v5 :: v_dual_mov_b32 v10, v4           // 000000491B14: CA100105 0B0A0104
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000491B1C: BF870234
	v_mov_b32_e32 v13, v2                                      // 000000491B20: 7E1A0302
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 000000491B24: D5010005 20020B05
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 000000491B2C: D5010004 20020904
	v_permlanex16_b32 v11, v11, s44, 0xfedcba98                // 000000491B34: D65C000B 03FC590B FEDCBA98
	v_mov_b32_e32 v12, v3                                      // 000000491B40: 7E180303
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 000000491B44: D5010002 20020502
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 000000491B4C: D5010003 20020703
	v_permlanex16_b32 v10, v10, s44, 0xfedcba98                // 000000491B54: D65C000A 03FC590A FEDCBA98
	v_permlanex16_b32 v13, v13, s44, 0xfedcba98                // 000000491B60: D65C000D 03FC590D FEDCBA98
	v_add_f32_e32 v5, v5, v11                                  // 000000491B6C: 060A1705
	v_permlanex16_b32 v12, v12, s44, 0xfedcba98                // 000000491B70: D65C000C 03FC590C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000491B7C: BF870214
	v_dual_add_f32 v4, v4, v10 :: v_dual_add_nc_u32 v9, 0x800, v9// 000000491B80: C9201504 040812FF 00000800
	v_add_f32_e32 v7, v2, v13                                  // 000000491B8C: 060E1B02
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000491B90: BF870214
	v_fma_mixhi_f16 v2, v5, s45, 0                             // 000000491B94: CC220002 02005B05
	v_add_f32_e32 v10, v3, v12                                 // 000000491B9C: 06141903
	s_or_b32 s39, vcc_lo, s39                                  // 000000491BA0: 8C27276A
	v_fma_mixlo_f16 v2, v4, s45, 0                             // 000000491BA4: CC210002 02005B04
	v_fma_mixhi_f16 v3, v7, s45, 0                             // 000000491BAC: CC220003 02005B07
	s_delay_alu instid0(VALU_DEP_3)                            // 000000491BB4: BF870003
	v_fma_mixlo_f16 v3, v10, s45, 0                            // 000000491BB8: CC210003 02005B0A
	ds_store_b64 v6, v[2:3]                                    // 000000491BC0: D9340000 00000206
	s_and_not1_b32 exec_lo, exec_lo, s39                       // 000000491BC8: 917E277E
	s_cbranch_execz 289                                        // 000000491BCC: BFA50121 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x854>
	.long 0xd72d0002                                           // 000000491BD0: D72D0002
	v_cndmask_b32_e32 v0, v8, v43, vcc_lo                      // 000000491BD4: 02005708
	s_mov_b32 s6, -1                                           // 000000491BD8: BE8600C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000491BDC: BF870091
	.long 0xd72c0003                                           // 000000491BE0: D72C0003
	v_cndmask_b32_e32 v0, v2, v37, vcc_lo                      // 000000491BE4: 02004B02
	v_sub_nc_u32_e32 v3, v8, v3                                // 000000491BE8: 4C060708
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000491BEC: BF870121
	v_subrev_nc_u32_e32 v5, s37, v3                            // 000000491BF0: 4E0A0625
	v_cmp_le_u32_e32 vcc_lo, s37, v3                           // 000000491BF4: 7C960625
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_add_nc_u32 v4, 1, v2// 000000491BF8: CA600B03 03040481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000491C00: BF870111
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000491C04: 02040902
	v_cmp_le_u32_e32 vcc_lo, s37, v3                           // 000000491C08: 7C960625
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000491C0C: BF870092
	v_add_nc_u32_e32 v4, 1, v2                                 // 000000491C10: 4A080481
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000491C14: 02040902
	s_and_not1_b32 vcc_lo, exec_lo, s36                        // 000000491C18: 916A247E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000491C1C: BF870091
	v_xor_b32_e32 v11, s40, v2                                 // 000000491C20: 3A160428
	v_subrev_nc_u32_e32 v10, s40, v11                          // 000000491C24: 4E141628
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000491C28: BF8700A1
	v_mad_u64_u32 v[6:7], null, s42, v10, v[1:2]               // 000000491C2C: D6FE7C06 0406142A
	v_min_i32_e32 v2, s35, v10                                 // 000000491C34: 22041423
	v_mad_i64_i32 v[4:5], null, v2, s38, 0                     // 000000491C38: D6FF7C04 02004D02
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000491C40: BF870093
	v_ashrrev_i32_e32 v7, 31, v6                               // 000000491C44: 340E0C9F
	.long 0xd73c0002                                           // 000000491C48: D73C0002
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000491C4C: 02020C81
	s_cbranch_vccnz 212                                        // 000000491C50: BFA400D4 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x7a4>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000491C54: BF870093
	.long 0xd7006a06                                           // 000000491C58: D7006A06
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 000000491C5C: 02020D04
	v_add_co_ci_u32_e64 v7, null, v5, v7, vcc_lo               // 000000491C60: D5207C07 01AA0F05
	.long 0x7f383880                                           // 000000491C68: 7F383880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000491C6C: BF870112
	.long 0xd73c0006                                           // 000000491C70: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000491C74: 02020C81
	.long 0x7f3e399c                                           // 000000491C78: 7F3E399C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000491C7C: BF870092
	.long 0xd7006a0c                                           // 000000491C80: D7006A0C
	v_cndmask_b32_e32 v1, s14, v6, vcc_lo                      // 000000491C84: 02020C0E
	v_add_co_ci_u32_e64 v13, null, s15, v7, vcc_lo             // 000000491C88: D5207C0D 01AA0E0F
	.long 0xd7006a06                                           // 000000491C90: D7006A06
	v_cndmask_b32_e32 v1, s30, v6, vcc_lo                      // 000000491C94: 02020C1E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000491C98: BF870001
	v_add_co_ci_u32_e64 v7, null, s31, v7, vcc_lo              // 000000491C9C: D5207C07 01AA0E1F
	global_load_b64 v[12:13], v[12:13], off                    // 000000491CA4: DC560000 0C7C000C
	.long 0xd7006a0e                                           // 000000491CAC: D7006A0E
	v_cndmask_b32_e32 v1, s20, v2, vcc_lo                      // 000000491CB0: 02020414
	global_load_b64 v[6:7], v[6:7], off                        // 000000491CB4: DC560000 067C0006
	v_add_co_ci_u32_e64 v15, null, s21, v3, vcc_lo             // 000000491CBC: D5207C0F 01AA0615
	s_clause 0x1                                               // 000000491CC4: BF850001
	global_load_b32 v16, v[14:15], off                         // 000000491CC8: DC520000 107C000E
	global_load_d16_b16 v14, v[14:15], off offset:4            // 000000491CD0: DC820004 0E7C000E
	s_waitcnt vmcnt(3)                                         // 000000491CD8: BF890FF7
	.long 0x7e1e390c                                           // 000000491CDC: 7E1E390C
	s_waitcnt vmcnt(2)                                         // 000000491CE0: BF890BF7
	v_and_b32_e32 v40, 0xffff0000, v6                          // 000000491CE4: 36500CFF FFFF0000
	v_lshlrev_b32_e32 v6, 16, v6                               // 000000491CEC: 300C0C90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000491CF0: BF870093
	v_lshlrev_b32_e32 v15, 16, v15                             // 000000491CF4: 301E1E90
	v_mul_f32_e32 v19, 0xbfb8aa3b, v15                         // 000000491CF8: 10261EFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000491D00: BF870291
	v_exp_f32_e32 v19, v19                                     // 000000491D04: 7E264B13
	v_dual_add_f32 v19, 1.0, v19 :: v_dual_and_b32 v12, 0xffff0000, v12// 000000491D08: C92426F2 130C18FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000491D14: BF870111
	v_mul_f32_e32 v18, 0xbfb8aa3b, v12                         // 000000491D18: 102418FF BFB8AA3B
	v_div_scale_f32 v23, null, v19, v19, v15                   // 000000491D20: D6FC7C17 043E2713
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000491D28: BF8701B2
	v_exp_f32_e32 v18, v18                                     // 000000491D2C: 7E244B12
	v_lshlrev_b32_e32 v17, 16, v13                             // 000000491D30: 30221A90
	v_div_scale_f32 v38, s7, v15, v19, v15                     // 000000491D34: D6FC0726 043E270F
	v_rcp_f32_e32 v27, v23                                     // 000000491D3C: 7E365517
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000491D40: BF870196
	v_add_f32_e32 v18, 1.0, v18                                // 000000491D44: 062424F2
	v_mul_f32_e32 v20, 0xbfb8aa3b, v17                         // 000000491D48: 102822FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000491D50: BF870195
	v_fma_f32 v37, -v23, v27, 1.0                              // 000000491D54: D6130025 23CA3717
	v_div_scale_f32 v22, null, v18, v18, v12                   // 000000491D5C: D6FC7C16 04322512
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000491D64: BF8701B3
	v_exp_f32_e32 v20, v20                                     // 000000491D68: 7E284B14
	v_and_b32_e32 v13, 0xffff0000, v13                         // 000000491D6C: 361A1AFF FFFF0000
	v_div_scale_f32 v32, vcc_lo, v12, v18, v12                 // 000000491D74: D6FC6A20 0432250C
	v_rcp_f32_e32 v25, v22                                     // 000000491D7C: 7E325516
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_2)   // 000000491D80: BF870106
	v_dual_add_f32 v20, 1.0, v20 :: v_dual_mul_f32 v21, 0xbfb8aa3b, v13// 000000491D84: C90628F2 14141AFF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000491D90: BF870115
	v_fma_f32 v33, -v22, v25, 1.0                              // 000000491D94: D6130021 23CA3316
	v_div_scale_f32 v24, null, v20, v20, v17                   // 000000491D9C: D6FC7C18 04462914
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000491DA4: BF8701A3
	v_exp_f32_e32 v21, v21                                     // 000000491DA8: 7E2A4B15
	v_div_scale_f32 v34, s6, v17, v20, v17                     // 000000491DAC: D6FC0622 04462911
	v_fmac_f32_e32 v25, v33, v25                               // 000000491DB4: 56323321
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000491DB8: BF870313
	v_rcp_f32_e32 v29, v24                                     // 000000491DBC: 7E3A5518
	v_add_f32_e32 v21, 1.0, v21                                // 000000491DC0: 062A2AF2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000491DC4: BF870115
	v_fma_f32 v39, -v24, v29, 1.0                              // 000000491DC8: D6130027 23CA3B18
	v_div_scale_f32 v26, null, v21, v21, v13                   // 000000491DD0: D6FC7C1A 04362B15
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000491DD8: BF8701A2
	v_fmac_f32_e32 v29, v39, v29                               // 000000491DDC: 563A3B27
	v_mul_f32_e32 v39, v32, v25                                // 000000491DE0: 104E3320
	v_rcp_f32_e32 v30, v26                                     // 000000491DE4: 7E3C551A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000491DE8: BF870112
	v_mul_f32_e32 v41, v34, v29                                // 000000491DEC: 10523B22
	v_fma_f32 v42, -v22, v39, v32                              // 000000491DF0: D613002A 24824F16
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000491DF8: BF870112
	v_fma_f32 v45, -v24, v41, v34                              // 000000491DFC: D613002D 248A5318
	v_fmac_f32_e32 v39, v42, v25                               // 000000491E04: 564E332A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000491E08: BF870195
	v_fma_f32 v33, -v26, v30, 1.0                              // 000000491E0C: D6130021 23CA3D1A
	v_fmac_f32_e32 v41, v45, v29                               // 000000491E14: 56523B2D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000491E18: BF870193
	v_fma_f32 v22, -v22, v39, v32                              // 000000491E1C: D6130016 24824F16
	v_fmac_f32_e32 v30, v33, v30                               // 000000491E24: 563C3D21
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000491E28: BF870193
	v_fma_f32 v24, -v24, v41, v34                              // 000000491E2C: D6130018 248A5318
	v_div_fmas_f32 v22, v22, v25, v39                          // 000000491E34: D6370016 049E3316
	s_mov_b32 vcc_lo, s7                                       // 000000491E3C: BEEA0007
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000491E40: BF870131
	v_div_fixup_f32 v12, v22, v18, v12                         // 000000491E44: D627000C 04322516
	v_fmac_f32_e32 v27, v37, v27                               // 000000491E4C: 56363725
	v_div_scale_f32 v37, s8, v13, v21, v13                     // 000000491E50: D6FC0825 04362B0D
	v_dual_mul_f32 v12, v12, v40 :: v_dual_mul_f32 v33, v38, v27// 000000491E58: C8C6510C 0C203726
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000491E60: BF870112
	v_mul_f32_e32 v43, v37, v30                                // 000000491E64: 10563D25
	.long 0x7e38398c                                           // 000000491E68: 7E38398C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000491E6C: BF870193
	v_fma_f32 v44, -v23, v33, v38                              // 000000491E70: D613002C 249A4317
	v_fma_f32 v42, -v26, v43, v37                              // 000000491E78: D613002A 2496571A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000491E80: BF870112
	v_fmac_f32_e32 v33, v44, v27                               // 000000491E84: 5642372C
	v_fmac_f32_e32 v43, v42, v30                               // 000000491E88: 56563D2A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000491E8C: BF870112
	v_fma_f32 v23, -v23, v33, v38                              // 000000491E90: D6130017 249A4317
	v_fma_f32 v22, -v26, v43, v37                              // 000000491E98: D6130016 2496571A
	s_delay_alu instid0(VALU_DEP_2)                            // 000000491EA0: BF870002
	v_div_fmas_f32 v23, v23, v27, v33                          // 000000491EA4: D6370017 04863717
	s_mov_b32 vcc_lo, s6                                       // 000000491EAC: BEEA0006
	s_mov_b32 s6, 0                                            // 000000491EB0: BE860080
	v_div_fmas_f32 v18, v24, v29, v41                          // 000000491EB4: D6370012 04A63B18
	s_mov_b32 vcc_lo, s8                                       // 000000491EBC: BEEA0008
	v_div_fixup_f32 v15, v23, v19, v15                         // 000000491EC0: D627000F 043E2717
	v_lshlrev_b32_e32 v19, 16, v7                              // 000000491EC8: 30260E90
	v_and_b32_e32 v7, 0xffff0000, v7                           // 000000491ECC: 360E0EFF FFFF0000
	v_div_fixup_f32 v17, v18, v20, v17                         // 000000491ED4: D6270011 04462912
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000491EDC: BF8701A4
	v_mul_f32_e32 v6, v15, v6                                  // 000000491EE0: 100C0D0F
	v_div_fmas_f32 v15, v22, v30, v43                          // 000000491EE4: D637000F 04AE3D16
	v_mul_f32_e32 v17, v17, v19                                // 000000491EEC: 10222711
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000491EF0: BF870193
	.long 0x7e3e3986                                           // 000000491EF4: 7E3E3986
	v_div_fixup_f32 v13, v15, v21, v13                         // 000000491EF8: D627000D 04362B0F
	v_and_b32_e32 v15, 1, v28                                  // 000000491F00: 361E3881
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000491F04: BF870214
	v_bfe_u32 v18, v17, 16, 1                                  // 000000491F08: D6100012 02052111
	v_and_b32_e32 v19, 1, v31                                  // 000000491F10: 36263E81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000491F14: BF870214
	v_mul_f32_e32 v7, v13, v7                                  // 000000491F18: 100E0F0D
	v_add3_u32 v12, v12, v15, 0x7fff                           // 000000491F1C: D655000C 03FE1F0C 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000491F28: BF870214
	v_add3_u32 v13, v17, v18, 0x7fff                           // 000000491F2C: D655000D 03FE2511 00007FFF
	v_add3_u32 v6, v6, v19, 0x7fff                             // 000000491F38: D6550006 03FE2706 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000491F44: BF870214
	v_bfe_u32 v15, v7, 16, 1                                   // 000000491F48: D610000F 02052107
	v_and_b32_e32 v12, 0xffff0000, v12                         // 000000491F50: 361818FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000491F58: BF870214
	v_and_b32_e32 v17, 0xffff0000, v13                         // 000000491F5C: 36221AFF FFFF0000
	v_and_b32_e32 v6, 0xffff0000, v6                           // 000000491F64: 360C0CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4)                            // 000000491F6C: BF870004
	v_add3_u32 v7, v7, v15, 0x7fff                             // 000000491F70: D6550007 03FE1F07 00007FFF
	s_waitcnt vmcnt(1)                                         // 000000491F7C: BF8907F7
	v_fma_mix_f32 v13, v16, v12, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000491F80: CC20080D 8A021910
	s_waitcnt vmcnt(0)                                         // 000000491F88: BF8903F7
	v_fma_mix_f32 v12, v14, v17, neg(0) op_sel_hi:[1,0,0]      // 000000491F8C: CC20000C 8A02230E
	v_fma_mix_f32 v15, v16, v6, neg(0) op_sel_hi:[1,0,0]       // 000000491F94: CC20000F 8A020D10
	v_and_b32_e32 v14, 0xffff0000, v7                          // 000000491F9C: 361C0EFF FFFF0000
	s_and_not1_b32 vcc_lo, exec_lo, s6                         // 000000491FA4: 916A067E
	s_cbranch_vccnz 65125                                      // 000000491FA8: BFA4FE65 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x140>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000491FAC: BF870093
	.long 0xd73c0004                                           // 000000491FB0: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 000000491FB4: 02020881
	.long 0xd7006a04                                           // 000000491FB8: D7006A04
	v_cndmask_b32_e32 v1, s14, v4, vcc_lo                      // 000000491FBC: 0202080E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000491FC0: BF870111
	v_add_co_ci_u32_e64 v5, null, s15, v5, vcc_lo              // 000000491FC4: D5207C05 01AA0A0F
	.long 0xd7006a04                                           // 000000491FCC: D7006A04
	v_cndmask_b32_e32 v1, v4, v2, vcc_lo                       // 000000491FD0: 02020504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000491FD4: BF8700A1
	v_add_co_ci_u32_e64 v5, null, v5, v3, vcc_lo               // 000000491FD8: D5207C05 01AA0705
	.long 0xd7006a06                                           // 000000491FE0: D7006A06
	v_cndmask_b32_e32 v1, s20, v2, vcc_lo                      // 000000491FE4: 02020414
	v_add_co_ci_u32_e64 v7, null, s21, v3, vcc_lo              // 000000491FE8: D5207C07 01AA0615
	global_load_b64 v[4:5], v[4:5], off                        // 000000491FF0: DC560000 047C0004
	s_clause 0x1                                               // 000000491FF8: BF850001
	global_load_b32 v14, v[6:7], off                           // 000000491FFC: DC520000 0E7C0006
	global_load_d16_b16 v6, v[6:7], off offset:4               // 000000492004: DC820004 067C0006
	s_waitcnt vmcnt(2)                                         // 00000049200C: BF890BF7
	.long 0x7e0e3904                                           // 000000492010: 7E0E3904
	v_and_b32_e32 v4, 0xffff0000, v4                           // 000000492014: 360808FF FFFF0000
	v_lshlrev_b32_e32 v12, 16, v5                              // 00000049201C: 30180A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000492020: BF8701A3
	v_lshlrev_b32_e32 v7, 16, v7                               // 000000492024: 300E0E90
	s_waitcnt vmcnt(1)                                         // 000000492028: BF8907F7
	v_fma_mix_f32 v13, v14, v4, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 00000049202C: CC20080D 8A02090E
	s_waitcnt vmcnt(0)                                         // 000000492034: BF8903F7
	v_fma_mix_f32 v12, v6, v12, neg(0) op_sel_hi:[1,0,0]       // 000000492038: CC20000C 8A021906
	v_fma_mix_f32 v15, v14, v7, neg(0) op_sel_hi:[1,0,0]       // 000000492040: CC20000F 8A020F0E
	v_and_b32_e32 v14, 0xffff0000, v5                          // 000000492048: 361C0AFF FFFF0000
	s_branch 65083                                             // 000000492050: BFA0FE3B <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x140>
	s_or_b32 exec_lo, exec_lo, s34                             // 000000492054: 8C7E227E
	s_ashr_i32 s0, s19, 31                                     // 000000492058: 86009F13
	s_lshr_b32 s1, s11, 28                                     // 00000049205C: 85019C0B
	s_lshr_b32 s0, s0, 29                                      // 000000492060: 85009D00
	s_add_i32 s1, s17, s1                                      // 000000492064: 81010111
	s_add_i32 s0, s0, s19                                      // 000000492068: 81001300
	s_waitcnt lgkmcnt(0)                                       // 00000049206C: BF89FC07
	s_add_i32 s0, s0, 7                                        // 000000492070: 81008700
	s_barrier                                                  // 000000492074: BFBD0000
	s_ashr_i32 s0, s0, 3                                       // 000000492078: 86008300
	buffer_gl0_inv                                             // 00000049207C: E0AC0000 00000000
	.long 0xd72c0001                                           // 000000492084: D72C0001
	v_cndmask_b32_e32 v1, s0, v35, vcc_lo                      // 000000492088: 02024600
	s_delay_alu instid0(VALU_DEP_1)                            // 00000049208C: BF870001
	v_add_nc_u32_e32 v2, s0, v1                                // 000000492090: 4A040200
	s_ashr_i32 s0, s1, 4                                       // 000000492094: 86008401
	s_lshl_b32 s1, s9, 3                                       // 000000492098: 84018309
	s_mul_hi_i32 s3, s0, s2                                    // 00000049209C: 97030200
	s_mul_i32 s0, s0, s2                                       // 0000004920A0: 96000200
	v_min_i32_e32 v101, s19, v2                                // 0000004920A4: 22CA0413
	s_ashr_i32 s4, s1, 31                                      // 0000004920A8: 86049F01
	s_add_u32 s0, s0, s1                                       // 0000004920AC: 80000100
	s_addc_u32 s1, s3, s4                                      // 0000004920B0: 82010403
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000004920B4: BF870009
	s_lshl_b64 s[4:5], s[0:1], 10                              // 0000004920B8: 84848A00
	v_cmp_lt_i32_e32 vcc_lo, v1, v101                          // 0000004920BC: 7C82CB01
	s_add_u32 s1, s12, s4                                      // 0000004920C0: 8001040C
	s_addc_u32 s4, s13, s5                                     // 0000004920C4: 8204050D
	s_and_saveexec_b32 s3, vcc_lo                              // 0000004920C8: BE83206A
	s_cbranch_execz 94                                         // 0000004920CC: BFA5005E <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xa48>
	.long 0xd7010002                                           // 0000004920D0: D7010002
	v_cndmask_b32_e32 v0, v36, v129, vcc_lo                    // 0000004920D4: 02010324
	v_lshlrev_b32_e32 v8, 2, v36                               // 0000004920D8: 30104882
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000004920DC: BF870122
	v_cndmask_b32_e64 v3, v2, 31, s0                           // 0000004920E0: D5010003 00013F02
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000004920E8: 3404029F
	.long 0xd44c0000                                           // 0000004920EC: D44C0000
	v_cndmask_b32_e32 v1, 31, v3, vcc_lo                       // 0000004920F0: 0202069F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004920F4: BF870091
	v_cndmask_b32_e64 v5, 0xe1, 1, s0                          // 0000004920F8: D5010005 000102FF 000000E1
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v7, v5, v3       // 000000492104: CA200080 04060705
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000049210C: BF870114
	.long 0xd73c0005                                           // 000000492110: D73C0005
	v_cndmask_b32_e32 v1, 10, v1, vcc_lo                       // 000000492114: 0202028A
	.long 0xd73c0002                                           // 000000492118: D73C0002
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 00000049211C: 02020682
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000492120: BF870223
	v_lshlrev_b32_e32 v4, 24, v7                               // 000000492124: 30080E98
	v_bfe_i32 v7, v7, 7, 1                                     // 000000492128: D6110007 02050F07
	.long 0xd7000009                                           // 000000492130: D7000009
	v_cndmask_b32_e32 v1, s1, v5, vcc_lo                       // 000000492134: 02020A01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000492138: BF870211
	v_add_co_ci_u32_e64 v10, null, s4, v6, s0                  // 00000049213C: D5207C0A 00020C04
	v_ashrrev_i32_e32 v6, 22, v4                               // 000000492144: 340C0896
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000492148: BF870093
	.long 0xd7000004                                           // 00000049214C: D7000004
	v_cndmask_b32_e32 v1, v9, v2, vcc_lo                       // 000000492150: 02020509
	v_add_co_ci_u32_e64 v5, null, v10, v3, s0                  // 000000492154: D5207C05 0002070A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000049215C: BF870093
	.long 0xd7000006                                           // 000000492160: D7000006
	v_cndmask_b32_e32 v1, v9, v6, vcc_lo                       // 000000492164: 02020D09
	v_add_co_ci_u32_e64 v7, null, v10, v7, s0                  // 000000492168: D5207C07 00020F0A
	.long 0xd7000008                                           // 000000492170: D7000008
	v_cndmask_b32_e32 v1, v9, v8, vcc_lo                       // 000000492174: 02021109
	s_delay_alu instid0(VALU_DEP_1)                            // 000000492178: BF870001
	v_add_co_ci_u32_e64 v9, null, 0, v10, s0                   // 00000049217C: D5207C09 00021480
	s_clause 0x17                                              // 000000492184: BF850017
	global_load_b32 v2, v[4:5], off                            // 000000492188: DC520000 027C0004
	global_load_b32 v139, v[4:5], off offset:128               // 000000492190: DC520080 8B7C0004
	global_load_b32 v136, v[4:5], off offset:256               // 000000492198: DC520100 887C0004
	global_load_b32 v133, v[4:5], off offset:384               // 0000004921A0: DC520180 857C0004
	global_load_b32 v130, v[4:5], off offset:512               // 0000004921A8: DC520200 827C0004
	global_load_b32 v127, v[4:5], off offset:640               // 0000004921B0: DC520280 7F7C0004
	global_load_b32 v124, v[4:5], off offset:768               // 0000004921B8: DC520300 7C7C0004
	global_load_b32 v122, v[4:5], off offset:896               // 0000004921C0: DC520380 7A7C0004
	global_load_b32 v3, v[6:7], off                            // 0000004921C8: DC520000 037C0006
	global_load_b32 v141, v[6:7], off offset:128               // 0000004921D0: DC520080 8D7C0006
	global_load_b32 v138, v[6:7], off offset:256               // 0000004921D8: DC520100 8A7C0006
	global_load_b32 v135, v[6:7], off offset:384               // 0000004921E0: DC520180 877C0006
	global_load_b32 v132, v[6:7], off offset:512               // 0000004921E8: DC520200 847C0006
	global_load_b32 v129, v[6:7], off offset:640               // 0000004921F0: DC520280 817C0006
	global_load_b32 v126, v[6:7], off offset:768               // 0000004921F8: DC520300 7E7C0006
	global_load_b32 v123, v[6:7], off offset:896               // 000000492200: DC520380 7B7C0006
	global_load_b32 v25, v[8:9], off                           // 000000492208: DC520000 197C0008
	global_load_b32 v140, v[8:9], off offset:128               // 000000492210: DC520080 8C7C0008
	global_load_b32 v137, v[8:9], off offset:256               // 000000492218: DC520100 897C0008
	global_load_b32 v134, v[8:9], off offset:384               // 000000492220: DC520180 867C0008
	global_load_b32 v131, v[8:9], off offset:512               // 000000492228: DC520200 837C0008
	global_load_b32 v128, v[8:9], off offset:640               // 000000492230: DC520280 807C0008
	global_load_b32 v125, v[8:9], off offset:768               // 000000492238: DC520300 7D7C0008
	global_load_b32 v106, v[8:9], off offset:896               // 000000492240: DC520380 6A7C0008
	s_or_b32 exec_lo, exec_lo, s3                              // 000000492248: 8C7E037E
	v_dual_mov_b32 v37, 0 :: v_dual_mov_b32 v38, 0             // 00000049224C: CA100080 25260080
	v_dual_mov_b32 v39, 0 :: v_dual_mov_b32 v40, 0             // 000000492254: CA100080 27280080
	v_dual_mov_b32 v41, 0 :: v_dual_mov_b32 v42, 0             // 00000049225C: CA100080 292A0080
	v_dual_mov_b32 v43, 0 :: v_dual_mov_b32 v44, 0             // 000000492264: CA100080 2B2C0080
	v_dual_mov_b32 v45, 0 :: v_dual_mov_b32 v46, 0             // 00000049226C: CA100080 2D2E0080
	v_dual_mov_b32 v47, 0 :: v_dual_mov_b32 v48, 0             // 000000492274: CA100080 2F300080
	v_dual_mov_b32 v49, 0 :: v_dual_mov_b32 v50, 0             // 00000049227C: CA100080 31320080
	v_dual_mov_b32 v51, 0 :: v_dual_mov_b32 v52, 0             // 000000492284: CA100080 33340080
	v_dual_mov_b32 v53, 0 :: v_dual_mov_b32 v54, 0             // 00000049228C: CA100080 35360080
	v_dual_mov_b32 v55, 0 :: v_dual_mov_b32 v56, 0             // 000000492294: CA100080 37380080
	v_dual_mov_b32 v57, 0 :: v_dual_mov_b32 v58, 0             // 00000049229C: CA100080 393A0080
	v_dual_mov_b32 v59, 0 :: v_dual_mov_b32 v60, 0             // 0000004922A4: CA100080 3B3C0080
	v_dual_mov_b32 v61, 0 :: v_dual_mov_b32 v62, 0             // 0000004922AC: CA100080 3D3E0080
	v_dual_mov_b32 v63, 0 :: v_dual_mov_b32 v64, 0             // 0000004922B4: CA100080 3F400080
	v_dual_mov_b32 v65, 0 :: v_dual_mov_b32 v66, 0             // 0000004922BC: CA100080 41420080
	v_dual_mov_b32 v67, 0 :: v_dual_mov_b32 v68, 0             // 0000004922C4: CA100080 43440080
	v_dual_mov_b32 v69, 0 :: v_dual_mov_b32 v70, 0             // 0000004922CC: CA100080 45460080
	v_dual_mov_b32 v71, 0 :: v_dual_mov_b32 v72, 0             // 0000004922D4: CA100080 47480080
	v_dual_mov_b32 v73, 0 :: v_dual_mov_b32 v74, 0             // 0000004922DC: CA100080 494A0080
	v_dual_mov_b32 v75, 0 :: v_dual_mov_b32 v76, 0             // 0000004922E4: CA100080 4B4C0080
	v_dual_mov_b32 v77, 0 :: v_dual_mov_b32 v78, 0             // 0000004922EC: CA100080 4D4E0080
	v_dual_mov_b32 v79, 0 :: v_dual_mov_b32 v80, 0             // 0000004922F4: CA100080 4F500080
	v_dual_mov_b32 v81, 0 :: v_dual_mov_b32 v82, 0             // 0000004922FC: CA100080 51520080
	v_dual_mov_b32 v83, 0 :: v_dual_mov_b32 v84, 0             // 000000492304: CA100080 53540080
	v_dual_mov_b32 v86, 0 :: v_dual_mov_b32 v95, 0             // 00000049230C: CA100080 565E0080
	v_dual_mov_b32 v88, 0 :: v_dual_mov_b32 v97, 0             // 000000492314: CA100080 58600080
	v_dual_mov_b32 v92, 0 :: v_dual_mov_b32 v99, 0             // 00000049231C: CA100080 5C620080
	v_dual_mov_b32 v94, 0 :: v_dual_mov_b32 v85, 0             // 000000492324: CA100080 5E540080
	v_dual_mov_b32 v98, 0 :: v_dual_mov_b32 v87, 0             // 00000049232C: CA100080 62560080
	v_dual_mov_b32 v89, 0 :: v_dual_mov_b32 v90, 0             // 000000492334: CA100080 595A0080
	v_dual_mov_b32 v93, 0 :: v_dual_mov_b32 v96, 0             // 00000049233C: CA100080 5D600080
	v_dual_mov_b32 v91, 0 :: v_dual_mov_b32 v100, 0            // 000000492344: CA100080 5B640080
	s_ashr_i32 s3, s2, 31                                      // 00000049234C: 86039F02
	s_and_saveexec_b32 s0, vcc_lo                              // 000000492350: BE80206A
	s_cbranch_execz 1329                                       // 000000492354: BFA50531 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x201c>
	v_dual_mov_b32 v37, 0 :: v_dual_add_nc_u32 v4, -1, v0      // 000000492358: CA200080 250400C1
	v_dual_mov_b32 v38, 0 :: v_dual_and_b32 v5, 16, v0         // 000000492360: CA240080 26040090
	v_dual_mov_b32 v40, 0 :: v_dual_add_nc_u32 v33, 1, v1      // 000000492368: CA200080 28200281
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000492370: BF870243
	v_dual_mov_b32 v39, 0 :: v_dual_and_b32 v4, 31, v4         // 000000492374: CA240080 2704089F
	v_sub_nc_u32_e32 v102, 0, v101                             // 00000049237C: 4CCCCA80
	v_dual_mov_b32 v42, 0 :: v_dual_lshlrev_b32 v103, 2, v36   // 000000492380: CA220080 2A664882
	v_lshl_or_b32 v104, v1, 5, v5                              // 000000492388: D6560068 04150B01
	v_dual_mov_b32 v44, 0 :: v_dual_lshlrev_b32 v105, 2, v4    // 000000492390: CA220080 2C680882
	v_dual_mov_b32 v41, 0 :: v_dual_mov_b32 v46, 0             // 000000492398: CA100080 292E0080
	v_dual_mov_b32 v43, 0 :: v_dual_mov_b32 v48, 0             // 0000004923A0: CA100080 2B300080
	v_dual_mov_b32 v45, 0 :: v_dual_mov_b32 v50, 0             // 0000004923A8: CA100080 2D320080
	v_dual_mov_b32 v47, 0 :: v_dual_mov_b32 v52, 0             // 0000004923B0: CA100080 2F340080
	v_dual_mov_b32 v49, 0 :: v_dual_mov_b32 v54, 0             // 0000004923B8: CA100080 31360080
	v_dual_mov_b32 v51, 0 :: v_dual_mov_b32 v56, 0             // 0000004923C0: CA100080 33380080
	v_dual_mov_b32 v53, 0 :: v_dual_mov_b32 v58, 0             // 0000004923C8: CA100080 353A0080
	v_dual_mov_b32 v55, 0 :: v_dual_mov_b32 v60, 0             // 0000004923D0: CA100080 373C0080
	v_dual_mov_b32 v57, 0 :: v_dual_mov_b32 v62, 0             // 0000004923D8: CA100080 393E0080
	v_dual_mov_b32 v59, 0 :: v_dual_mov_b32 v64, 0             // 0000004923E0: CA100080 3B400080
	v_dual_mov_b32 v61, 0 :: v_dual_mov_b32 v66, 0             // 0000004923E8: CA100080 3D420080
	v_dual_mov_b32 v63, 0 :: v_dual_mov_b32 v68, 0             // 0000004923F0: CA100080 3F440080
	v_dual_mov_b32 v65, 0 :: v_dual_mov_b32 v70, 0             // 0000004923F8: CA100080 41460080
	v_dual_mov_b32 v67, 0 :: v_dual_mov_b32 v72, 0             // 000000492400: CA100080 43480080
	v_dual_mov_b32 v69, 0 :: v_dual_mov_b32 v74, 0             // 000000492408: CA100080 454A0080
	v_dual_mov_b32 v71, 0 :: v_dual_mov_b32 v76, 0             // 000000492410: CA100080 474C0080
	v_dual_mov_b32 v73, 0 :: v_dual_mov_b32 v78, 0             // 000000492418: CA100080 494E0080
	v_dual_mov_b32 v75, 0 :: v_dual_mov_b32 v80, 0             // 000000492420: CA100080 4B500080
	v_dual_mov_b32 v77, 0 :: v_dual_mov_b32 v82, 0             // 000000492428: CA100080 4D520080
	v_dual_mov_b32 v79, 0 :: v_dual_mov_b32 v84, 0             // 000000492430: CA100080 4F540080
	v_dual_mov_b32 v81, 0 :: v_dual_mov_b32 v86, 0             // 000000492438: CA100080 51560080
	v_dual_mov_b32 v83, 0 :: v_dual_mov_b32 v88, 0             // 000000492440: CA100080 53580080
	v_dual_mov_b32 v92, 0 :: v_dual_mov_b32 v95, 0             // 000000492448: CA100080 5C5E0080
	v_dual_mov_b32 v94, 0 :: v_dual_mov_b32 v97, 0             // 000000492450: CA100080 5E600080
	v_dual_mov_b32 v98, 0 :: v_dual_mov_b32 v99, 0             // 000000492458: CA100080 62620080
	v_dual_mov_b32 v85, 0 :: v_dual_mov_b32 v90, 0             // 000000492460: CA100080 555A0080
	v_dual_mov_b32 v87, 0 :: v_dual_mov_b32 v96, 0             // 000000492468: CA100080 57600080
	v_dual_mov_b32 v89, 0 :: v_dual_mov_b32 v100, 0            // 000000492470: CA100080 59640080
	v_mov_b32_e32 v93, 0                                       // 000000492478: 7EBA0280
	v_mov_b32_e32 v91, 0                                       // 00000049247C: 7EB60280
	s_mov_b32 s5, 0                                            // 000000492480: BE850080
	s_mov_b32 s6, 0xdcd12d                                     // 000000492484: BE8600FF 00DCD12D
	s_movk_i32 s7, 0x83                                        // 00000049248C: B0070083
	s_movk_i32 s8, 0x1eee                                      // 000000492490: B0081EEE
	s_branch 1192                                              // 000000492494: BFA004A8 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1f38>
	s_or_b32 exec_lo, exec_lo, s9                              // 000000492498: 8C7E097E
	s_waitcnt vmcnt(15)                                        // 00000049249C: BF893FF7
	v_alignbit_b32 v26, v2, v3, 16                             // 0000004924A0: D616001A 02420702
	ds_load_b128 v[9:12], v104 offset:15360                    // 0000004924A8: DBFC3C00 09000068
	ds_load_b128 v[5:8], v104 offset:20480                     // 0000004924B0: DBFC5000 05000068
	ds_load_b128 v[21:24], v104                                // 0000004924B8: DBFC0000 15000068
	ds_load_b128 v[1:4], v104 offset:35840                     // 0000004924C0: DBFC8C00 01000068
	ds_load_b128 v[13:16], v104 offset:5120                    // 0000004924C8: DBFC1400 0D000068
	ds_load_b128 v[17:20], v104 offset:10240                   // 0000004924D0: DBFC2800 11000068
	s_waitcnt vmcnt(7)                                         // 0000004924D8: BF891FF7
	v_bfe_u32 v30, v25, 12, 16                                 // 0000004924DC: D610001E 02411919
	v_bfe_u32 v31, v25, 8, 16                                  // 0000004924E4: D610001F 02411119
	v_bfe_u32 v27, v26, 12, 16                                 // 0000004924EC: D610001B 0241191A
	v_mul_u32_u24_e32 v142, s6, v27                            // 0000004924F4: 171C3606
	v_mul_u32_u24_e32 v27, s7, v27                             // 0000004924F8: 16363607
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000004924FC: BF870151
	v_lshl_add_u32 v27, v27, 24, v142                          // 000000492500: D646001B 0639311B
	v_bfe_u32 v29, v26, 4, 16                                  // 000000492508: D610001D 0241091A
	v_bfe_u32 v28, v26, 8, 16                                  // 000000492510: D610001C 0241111A
	v_mul_u32_u24_e32 v142, s6, v29                            // 000000492518: 171C3A06
	v_mul_u32_u24_e32 v29, s7, v29                             // 00000049251C: 163A3A07
	v_lshl_add_u32 v29, v29, 24, v142                          // 000000492520: D646001D 0639311D
	v_mul_u32_u24_e32 v142, s6, v28                            // 000000492528: 171C3806
	v_mul_u32_u24_e32 v28, s7, v28                             // 00000049252C: 16383807
	v_sad_u8 v27, v27, 0, 0x6400                               // 000000492530: D622001B 03FD011B 00006400
	v_lshl_add_u32 v28, v28, 24, v142                          // 00000049253C: D646001C 0639311C
	v_and_b32_e32 v26, 0xffff, v26                             // 000000492544: 363434FF 0000FFFF
	v_mul_u32_u24_e32 v142, s6, v26                            // 00000049254C: 171C3406
	v_mul_u32_u24_e32 v26, s7, v26                             // 000000492550: 16343407
	v_sad_u8 v29, v29, 0, 0x6400                               // 000000492554: D622001D 03FD011D 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 000000492560: BF870002
	v_lshl_add_u32 v26, v26, 24, v142                          // 000000492564: D646001A 0639311A
	v_and_b32_e32 v27, 0xffff, v27                             // 00000049256C: 363636FF 0000FFFF
	v_sad_u8 v28, v28, 0, 0x6400                               // 000000492574: D622001C 03FD011C 00006400
	v_mul_u32_u24_e32 v142, s6, v30                            // 000000492580: 171C3C06
	v_and_b32_e32 v29, 0xffff, v29                             // 000000492584: 363A3AFF 0000FFFF
	v_sad_u8 v26, v26, 0, 0x6400                               // 00000049258C: D622001A 03FD011A 00006400
	v_mul_u32_u24_e32 v30, s7, v30                             // 000000492598: 163C3C07
	v_lshl_or_b32 v27, v28, 16, v27                            // 00000049259C: D656001B 046D211C
	v_bfe_u32 v32, v25, 4, 16                                  // 0000004925A4: D6100020 02410919
	v_lshl_add_u32 v30, v30, 24, v142                          // 0000004925AC: D646001E 0639311E
	v_mul_u32_u24_e32 v142, s6, v31                            // 0000004925B4: 171C3E06
	v_mul_u32_u24_e32 v31, s7, v31                             // 0000004925B8: 163E3E07
	v_lshl_add_u32 v31, v31, 24, v142                          // 0000004925BC: D646001F 0639311F
	v_mul_u32_u24_e32 v142, s6, v32                            // 0000004925C4: 171C4006
	v_mul_u32_u24_e32 v32, s7, v32                             // 0000004925C8: 16404007
	v_lshl_add_u32 v32, v32, 24, v142                          // 0000004925CC: D6460020 06393120
	v_lshl_or_b32 v26, v26, 16, v29                            // 0000004925D4: D656001A 0475211A
	v_pk_fma_f16 v142, v27, s8, 0xc931 op_sel_hi:[1,0,0]       // 0000004925DC: CC0E008E 0BFC111B 0000C931
	v_sad_u8 v30, v30, 0, 0x6400                               // 0000004925E8: D622001E 03FD011E 00006400
	v_sad_u8 v29, v31, 0, 0x6400                               // 0000004925F4: D622001D 03FD011F 00006400
	v_alignbit_b32 v139, v139, v141, 16                        // 000000492600: D616008B 02431B8B
	v_pk_fma_f16 v143, v26, s8, 0xc931 op_sel_hi:[1,0,0]       // 000000492608: CC0E008F 0BFC111A 0000C931
	s_waitcnt lgkmcnt(3)                                       // 000000492614: BF89FC37
	v_dot2acc_f32_f16 v100, v142, v21                          // 000000492618: 04C82B8E
	v_and_b32_e32 v25, 0xffff, v25                             // 00000049261C: 363232FF 0000FFFF
	v_dual_dot2acc_f32_f16 v93, v142, v5 :: v_dual_and_b32 v28, 0xffff, v30// 000000492624: CB240B8E 5D1C3CFF 0000FFFF
	v_sad_u8 v30, v32, 0, 0x6400                               // 000000492630: D622001E 03FD0120 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 00000049263C: BF870004
	v_dot2acc_f32_f16 v100, v143, v22                          // 000000492640: 04C82D8F
	v_mul_u32_u24_e32 v31, s6, v25                             // 000000492644: 163E3206
	v_mul_u32_u24_e32 v25, s7, v25                             // 000000492648: 16323207
	v_lshl_add_u32 v25, v25, 24, v31                           // 00000049264C: D6460019 047D3119
	v_lshl_or_b32 v144, v29, 16, v28                           // 000000492654: D6560090 0471211D
	s_waitcnt lgkmcnt(1)                                       // 00000049265C: BF89FC17
	v_dual_dot2acc_f32_f16 v96, v142, v13 :: v_dual_and_b32 v145, 0xffff, v30// 000000492660: CB241B8E 60903CFF 0000FFFF
	s_waitcnt lgkmcnt(0)                                       // 00000049266C: BF89FC07
	v_dot2acc_f32_f16 v91, v142, v17                           // 000000492670: 04B6238E
	v_sad_u8 v146, v25, 0, 0x6400                              // 000000492674: D6220092 03FD0119 00006400
	ds_load_b128 v[25:28], v104 offset:25600                   // 000000492680: DBFC6400 19000068
	ds_load_b128 v[29:32], v104 offset:30720                   // 000000492688: DBFC7800 1D000068
	v_pk_fma_f16 v144, v144, s8, 0xc931 op_sel_hi:[1,0,0]      // 000000492690: CC0E0090 0BFC1190 0000C931
	v_dot2acc_f32_f16 v96, v143, v14                           // 00000049269C: 04C01D8F
	v_dual_dot2acc_f32_f16 v90, v142, v9 :: v_dual_dot2acc_f32_f16 v91, v143, v18// 0000004926A0: CB18138E 5A5A258F
	v_lshl_or_b32 v145, v146, 16, v145                         // 0000004926A8: D6560091 06452192
	v_dot2acc_f32_f16 v85, v142, v1                            // 0000004926B0: 04AA038E
	v_bfe_u32 v141, v139, 12, 16                               // 0000004926B4: D610008D 0241198B
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004926BC: BF870004
	v_dot2acc_f32_f16 v90, v143, v10                           // 0000004926C0: 04B4158F
	v_dot2acc_f32_f16 v93, v143, v6                            // 0000004926C4: 04BA0D8F
	v_pk_fma_f16 v145, v145, s8, 0xc931 op_sel_hi:[1,0,0]      // 0000004926C8: CC0E0091 0BFC1191 0000C931
	v_dot2acc_f32_f16 v85, v143, v2                            // 0000004926D4: 04AA058F
	v_mul_u32_u24_e32 v149, s6, v141                           // 0000004926D8: 172B1A06
	v_mul_u32_u24_e32 v141, s7, v141                           // 0000004926DC: 171B1A07
	v_lshl_add_u32 v141, v141, 24, v149                        // 0000004926E0: D646008D 0655318D
	s_waitcnt vmcnt(6)                                         // 0000004926E8: BF891BF7
	v_bfe_u32 v146, v140, 12, 16                               // 0000004926EC: D6100092 0241198C
	v_bfe_u32 v147, v140, 8, 16                                // 0000004926F4: D6100093 0241118C
	v_bfe_u32 v148, v140, 4, 16                                // 0000004926FC: D6100094 0241098C
	s_waitcnt lgkmcnt(1)                                       // 000000492704: BF89FC17
	v_dual_dot2acc_f32_f16 v89, v142, v25 :: v_dual_and_b32 v140, 0xffff, v140// 000000492708: CB24338E 598D18FF 0000FFFF
	s_waitcnt lgkmcnt(0)                                       // 000000492714: BF89FC07
	v_dual_dot2acc_f32_f16 v96, v144, v15 :: v_dual_dot2acc_f32_f16 v87, v142, v29// 000000492718: CB181F90 60563B8E
	v_bfe_u32 v142, v139, 8, 16                                // 000000492720: D610008E 0241118B
	v_sad_u8 v141, v141, 0, 0x6400                             // 000000492728: D622008D 03FD018D 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000492734: BF870213
	v_dual_dot2acc_f32_f16 v89, v143, v26 :: v_dual_dot2acc_f32_f16 v96, v145, v16// 000000492738: CB18358F 59602191
	v_dot2acc_f32_f16 v87, v143, v30                           // 000000492740: 04AE3D8F
	v_bfe_u32 v143, v139, 4, 16                                // 000000492744: D610008F 0241098B
	v_mul_u32_u24_e32 v149, s6, v143                           // 00000049274C: 172B1E06
	v_mul_u32_u24_e32 v143, s7, v143                           // 000000492750: 171F1E07
	s_delay_alu instid0(VALU_DEP_1)                            // 000000492754: BF870001
	v_lshl_add_u32 v143, v143, 24, v149                        // 000000492758: D646008F 0655318F
	v_and_b32_e32 v139, 0xffff, v139                           // 000000492760: 371716FF 0000FFFF
	v_mul_u32_u24_e32 v149, s6, v142                           // 000000492768: 172B1C06
	v_mul_u32_u24_e32 v142, s7, v142                           // 00000049276C: 171D1C07
	v_lshl_add_u32 v142, v142, 24, v149                        // 000000492770: D646008E 0655318E
	v_mul_u32_u24_e32 v149, s6, v139                           // 000000492778: 172B1606
	v_mul_u32_u24_e32 v139, s7, v139                           // 00000049277C: 17171607
	v_sad_u8 v143, v143, 0, 0x6400                             // 000000492780: D622008F 03FD018F 00006400
	v_lshl_add_u32 v139, v139, 24, v149                        // 00000049278C: D646008B 0655318B
	v_mul_u32_u24_e32 v149, s6, v146                           // 000000492794: 172B2406
	v_mul_u32_u24_e32 v146, s7, v146                           // 000000492798: 17252407
	v_lshl_add_u32 v146, v146, 24, v149                        // 00000049279C: D6460092 06553192
	v_and_b32_e32 v143, 0xffff, v143                           // 0000004927A4: 371F1EFF 0000FFFF
	v_sad_u8 v139, v139, 0, 0x6400                             // 0000004927AC: D622008B 03FD018B 00006400
	v_sad_u8 v142, v142, 0, 0x6400                             // 0000004927B8: D622008E 03FD018E 00006400
	v_mul_u32_u24_e32 v149, s6, v147                           // 0000004927C4: 172B2606
	v_mul_u32_u24_e32 v147, s7, v147                           // 0000004927C8: 17272607
	v_sad_u8 v146, v146, 0, 0x6400                             // 0000004927CC: D6220092 03FD0192 00006400
	v_lshl_or_b32 v139, v139, 16, v143                         // 0000004927D8: D656008B 063D218B
	v_lshl_add_u32 v147, v147, 24, v149                        // 0000004927E0: D6460093 06553193
	v_mul_u32_u24_e32 v149, s6, v148                           // 0000004927E8: 172B2806
	v_mul_u32_u24_e32 v148, s7, v148                           // 0000004927EC: 17292807
	v_lshl_add_u32 v148, v148, 24, v149                        // 0000004927F0: D6460094 06553194
	v_pk_fma_f16 v139, v139, s8, 0xc931 op_sel_hi:[1,0,0]      // 0000004927F8: CC0E008B 0BFC118B 0000C931
	v_and_b32_e32 v141, 0xffff, v141                           // 000000492804: 371B1AFF 0000FFFF
	v_sad_u8 v143, v147, 0, 0x6400                             // 00000049280C: D622008F 03FD0193 00006400
	v_dot2acc_f32_f16 v89, v144, v27                           // 000000492818: 04B23790
	v_mul_u32_u24_e32 v147, s6, v140                           // 00000049281C: 17271806
	v_mul_u32_u24_e32 v140, s7, v140                           // 000000492820: 17191807
	v_lshl_or_b32 v141, v142, 16, v141                         // 000000492824: D656008D 0635218E
	v_and_b32_e32 v142, 0xffff, v146                           // 00000049282C: 371D24FF 0000FFFF
	v_sad_u8 v146, v148, 0, 0x6400                             // 000000492834: D6220092 03FD0194 00006400
	v_lshl_add_u32 v140, v140, 24, v147                        // 000000492840: D646008C 064D318C
	v_alignbit_b32 v136, v136, v138, 16                        // 000000492848: D6160088 02431588
	v_pk_fma_f16 v141, v141, s8, 0xc931 op_sel_hi:[1,0,0]      // 000000492850: CC0E008D 0BFC118D 0000C931
	v_lshl_or_b32 v142, v143, 16, v142                         // 00000049285C: D656008E 0639218F
	v_dot2acc_f32_f16 v100, v144, v23                          // 000000492864: 04C82F90
	v_sad_u8 v140, v140, 0, 0x6400                             // 000000492868: D622008C 03FD018C 00006400
	v_bfe_u32 v138, v136, 12, 16                               // 000000492874: D610008A 02411988
	v_dual_dot2acc_f32_f16 v98, v141, v13 :: v_dual_dot2acc_f32_f16 v87, v144, v31// 00000049287C: CB181B8D 62563F90
	v_dot2acc_f32_f16 v94, v141, v5                            // 000000492884: 04BC0B8D
	v_pk_fma_f16 v142, v142, s8, 0xc931 op_sel_hi:[1,0,0]      // 000000492888: CC0E008E 0BFC118E 0000C931
	v_dual_dot2acc_f32_f16 v92, v141, v25 :: v_dual_dot2acc_f32_f16 v85, v144, v3// 000000492894: CB18338D 5C540790
	v_dot2acc_f32_f16 v88, v141, v29                           // 00000049289C: 04B03B8D
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004928A0: BF870004
	v_dot2acc_f32_f16 v94, v139, v6                            // 0000004928A4: 04BC0D8B
	v_and_b32_e32 v143, 0xffff, v146                           // 0000004928A8: 371F24FF 0000FFFF
	v_mul_u32_u24_e32 v147, s6, v138                           // 0000004928B0: 17271406
	v_mul_u32_u24_e32 v138, s7, v138                           // 0000004928B4: 17151407
	v_lshl_add_u32 v138, v138, 24, v147                        // 0000004928B8: D646008A 064D318A
	v_dot2acc_f32_f16 v94, v142, v7                            // 0000004928C0: 04BC0F8E
	v_lshl_or_b32 v140, v140, 16, v143                         // 0000004928C4: D656008C 063D218C
	v_bfe_u32 v143, v136, 4, 16                                // 0000004928CC: D610008F 02410988
	v_dual_dot2acc_f32_f16 v85, v145, v4 :: v_dual_dot2acc_f32_f16 v88, v139, v30// 0000004928D4: CB180991 55583D8B
	v_dot2acc_f32_f16 v97, v141, v17                           // 0000004928DC: 04C2238D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000004928E0: BF870224
	v_pk_fma_f16 v140, v140, s8, 0xc931 op_sel_hi:[1,0,0]      // 0000004928E4: CC0E008C 0BFC118C 0000C931
	v_dot2acc_f32_f16 v99, v141, v21                           // 0000004928F0: 04C62B8D
	v_dual_dot2acc_f32_f16 v95, v141, v9 :: v_dual_dot2acc_f32_f16 v88, v142, v31// 0000004928F4: CB18138D 5F583F8E
	v_dot2acc_f32_f16 v86, v141, v1                            // 0000004928FC: 04AC038D
	s_delay_alu instid0(VALU_DEP_3)                            // 000000492900: BF870003
	v_dual_dot2acc_f32_f16 v94, v140, v8 :: v_dual_dot2acc_f32_f16 v99, v139, v22// 000000492904: CB18118C 5E622D8B
	v_bfe_u32 v141, v136, 8, 16                                // 00000049290C: D610008D 02411188
	v_mul_u32_u24_e32 v147, s6, v143                           // 000000492914: 17271E06
	v_mul_u32_u24_e32 v143, s7, v143                           // 000000492918: 171F1E07
	v_lshl_add_u32 v143, v143, 24, v147                        // 00000049291C: D646008F 064D318F
	v_mul_u32_u24_e32 v147, s6, v141                           // 000000492924: 17271A06
	v_mul_u32_u24_e32 v141, s7, v141                           // 000000492928: 171B1A07
	v_sad_u8 v138, v138, 0, 0x6400                             // 00000049292C: D622008A 03FD018A 00006400
	v_lshl_add_u32 v141, v141, 24, v147                        // 000000492938: D646008D 064D318D
	v_dual_dot2acc_f32_f16 v99, v142, v23 :: v_dual_and_b32 v136, 0xffff, v136// 000000492940: CB242F8E 638910FF 0000FFFF
	v_mul_u32_u24_e32 v147, s6, v136                           // 00000049294C: 17271006
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000492950: BF870193
	v_and_b32_e32 v138, 0xffff, v138                           // 000000492954: 371514FF 0000FFFF
	v_sad_u8 v141, v141, 0, 0x6400                             // 00000049295C: D622008D 03FD018D 00006400
	v_mul_u32_u24_e32 v136, s7, v136                           // 000000492968: 17111007
	v_sad_u8 v143, v143, 0, 0x6400                             // 00000049296C: D622008F 03FD018F 00006400
	v_lshl_add_u32 v136, v136, 24, v147                        // 000000492978: D6460088 064D3188
	v_dual_dot2acc_f32_f16 v100, v145, v24 :: v_dual_dot2acc_f32_f16 v91, v144, v19// 000000492980: CB183191 645A2790
	v_lshl_or_b32 v138, v141, 16, v138                         // 000000492988: D656008A 0629218D
	v_dot2acc_f32_f16 v90, v144, v11                           // 000000492990: 04B41790
	s_delay_alu instid0(VALU_DEP_4)                            // 000000492994: BF870004
	v_sad_u8 v136, v136, 0, 0x6400                             // 000000492998: D6220088 03FD0188 00006400
	v_dot2acc_f32_f16 v93, v144, v7                            // 0000004929A4: 04BA0F90
	v_dot2acc_f32_f16 v91, v145, v20                           // 0000004929A8: 04B62991
	v_pk_fma_f16 v138, v138, s8, 0xc931 op_sel_hi:[1,0,0]      // 0000004929AC: CC0E008A 0BFC118A 0000C931
	v_and_b32_e32 v143, 0xffff, v143                           // 0000004929B8: 371F1EFF 0000FFFF
	v_dual_dot2acc_f32_f16 v97, v139, v18 :: v_dual_dot2acc_f32_f16 v90, v145, v12// 0000004929C0: CB18258B 615A1991
	s_waitcnt vmcnt(5)                                         // 0000004929C8: BF8917F7
	v_bfe_u32 v144, v137, 12, 16                               // 0000004929CC: D6100090 02411989
	v_dot2acc_f32_f16 v82, v138, v17                           // 0000004929D4: 04A4238A
	v_lshl_or_b32 v136, v136, 16, v143                         // 0000004929D8: D6560088 063D2188
	v_dual_dot2acc_f32_f16 v99, v140, v24 :: v_dual_dot2acc_f32_f16 v86, v139, v2// 0000004929E0: CB18318C 6356058B
	v_mul_u32_u24_e32 v147, s6, v144                           // 0000004929E8: 17272006
	v_mul_u32_u24_e32 v144, s7, v144                           // 0000004929EC: 17212007
	s_delay_alu instid0(VALU_DEP_2)                            // 0000004929F0: BF870002
	v_pk_fma_f16 v136, v136, s8, 0xc931 op_sel_hi:[1,0,0]      // 0000004929F4: CC0E0088 0BFC1188 0000C931
	v_dot2acc_f32_f16 v84, v138, v21                           // 000000492A00: 04A82B8A
	v_dot2acc_f32_f16 v97, v142, v19                           // 000000492A04: 04C2278E
	v_lshl_add_u32 v144, v144, 24, v147                        // 000000492A08: D6460090 064D3190
	v_dual_dot2acc_f32_f16 v93, v145, v8 :: v_dual_dot2acc_f32_f16 v98, v139, v14// 000000492A10: CB181191 5D621D8B
	v_dual_dot2acc_f32_f16 v89, v145, v28 :: v_dual_dot2acc_f32_f16 v92, v139, v26// 000000492A18: CB183991 595C358B
	v_dot2acc_f32_f16 v87, v145, v32                           // 000000492A20: 04AE4191
	v_bfe_u32 v145, v137, 8, 16                                // 000000492A24: D6100091 02411189
	v_bfe_u32 v146, v137, 4, 16                                // 000000492A2C: D6100092 02410989
	v_mul_u32_u24_e32 v147, s6, v145                           // 000000492A34: 17272206
	v_mul_u32_u24_e32 v145, s7, v145                           // 000000492A38: 17232207
	s_delay_alu instid0(VALU_DEP_2)                            // 000000492A3C: BF870002
	v_lshl_add_u32 v145, v145, 24, v147                        // 000000492A40: D6460091 064D3191
	v_mul_u32_u24_e32 v147, s6, v146                           // 000000492A48: 17272406
	v_mul_u32_u24_e32 v146, s7, v146                           // 000000492A4C: 17252407
	v_dot2acc_f32_f16 v84, v136, v22                           // 000000492A50: 04A82D88
	v_dual_dot2acc_f32_f16 v97, v140, v20 :: v_dual_dot2acc_f32_f16 v86, v142, v3// 000000492A54: CB18298C 6156078E
	v_sad_u8 v144, v144, 0, 0x6400                             // 000000492A5C: D6220090 03FD0190 00006400
	v_lshl_add_u32 v146, v146, 24, v147                        // 000000492A68: D6460092 064D3192
	v_and_b32_e32 v137, 0xffff, v137                           // 000000492A70: 371312FF 0000FFFF
	v_sad_u8 v143, v145, 0, 0x6400                             // 000000492A78: D622008F 03FD0191 00006400
	v_dot2acc_f32_f16 v86, v140, v4                            // 000000492A84: 04AC098C
	v_mul_u32_u24_e32 v145, s6, v137                           // 000000492A88: 17231206
	v_mul_u32_u24_e32 v137, s7, v137                           // 000000492A8C: 17131207
	v_dual_dot2acc_f32_f16 v82, v136, v18 :: v_dual_and_b32 v141, 0xffff, v144// 000000492A90: CB242588 528D20FF 0000FFFF
	v_sad_u8 v144, v146, 0, 0x6400                             // 000000492A9C: D6220090 03FD0192 00006400
	v_lshl_add_u32 v137, v137, 24, v145                        // 000000492AA8: D6460089 06453189
	v_dual_dot2acc_f32_f16 v92, v142, v27 :: v_dual_dot2acc_f32_f16 v95, v139, v10// 000000492AB0: CB18378E 5C5E158B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000492AB8: BF870214
	v_lshl_or_b32 v141, v143, 16, v141                         // 000000492ABC: D656008D 0635218F
	v_dual_dot2acc_f32_f16 v80, v138, v5 :: v_dual_and_b32 v143, 0xffff, v144// 000000492AC4: CB240B8A 508F20FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000492AD0: BF870214
	v_sad_u8 v137, v137, 0, 0x6400                             // 000000492AD4: D6220089 03FD0189 00006400
	v_dual_dot2acc_f32_f16 v92, v140, v28 :: v_dual_dot2acc_f32_f16 v95, v142, v11// 000000492AE0: CB18398C 5C5E178E
	v_dot2acc_f32_f16 v88, v140, v32                           // 000000492AE8: 04B0418C
	v_pk_fma_f16 v139, v141, s8, 0xc931 op_sel_hi:[1,0,0]      // 000000492AEC: CC0E008B 0BFC118D 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000492AF8: BF870234
	v_lshl_or_b32 v137, v137, 16, v143                         // 000000492AFC: D6560089 063D2189
	v_dot2acc_f32_f16 v81, v138, v9                            // 000000492B04: 04A2138A
	v_dual_dot2acc_f32_f16 v95, v140, v12 :: v_dual_dot2acc_f32_f16 v78, v138, v29// 000000492B08: CB18198C 5F4E3B8A
	v_dot2acc_f32_f16 v84, v139, v23                           // 000000492B10: 04A82F8B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000492B14: BF8701C4
	v_pk_fma_f16 v137, v137, s8, 0xc931 op_sel_hi:[1,0,0]      // 000000492B18: CC0E0089 0BFC1189 0000C931
	v_dual_dot2acc_f32_f16 v83, v138, v13 :: v_dual_dot2acc_f32_f16 v82, v139, v19// 000000492B24: CB181B8A 5352278B
	v_dot2acc_f32_f16 v77, v138, v1                            // 000000492B2C: 049A038A
	v_alignbit_b32 v133, v133, v135, 16                        // 000000492B30: D6160085 02430F85
	v_dual_dot2acc_f32_f16 v84, v137, v24 :: v_dual_dot2acc_f32_f16 v83, v136, v14// 000000492B38: CB183189 54521D88
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000492B40: BF8701A4
	v_dot2acc_f32_f16 v82, v137, v20                           // 000000492B44: 04A42989
	v_dual_dot2acc_f32_f16 v78, v136, v30 :: v_dual_dot2acc_f32_f16 v79, v138, v25// 000000492B48: CB183D88 4E4E338A
	v_dual_dot2acc_f32_f16 v80, v136, v6 :: v_dual_dot2acc_f32_f16 v83, v139, v15// 000000492B50: CB180D88 50521F8B
	v_dual_dot2acc_f32_f16 v98, v142, v15 :: v_dual_dot2acc_f32_f16 v77, v136, v2// 000000492B58: CB181F8E 624C0588
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000492B60: BF870223
	v_dot2acc_f32_f16 v78, v139, v31                           // 000000492B64: 049C3F8B
	v_bfe_u32 v135, v133, 12, 16                               // 000000492B68: D6100087 02411985
	v_dot2acc_f32_f16 v83, v137, v16                           // 000000492B70: 04A62189
	v_mul_u32_u24_e32 v143, s6, v135                           // 000000492B74: 171F0E06
	v_mul_u32_u24_e32 v135, s7, v135                           // 000000492B78: 170F0E07
	v_bfe_u32 v138, v133, 4, 16                                // 000000492B7C: D610008A 02410985
	v_lshl_add_u32 v135, v135, 24, v143                        // 000000492B84: D6460087 063D3187
	v_dual_dot2acc_f32_f16 v81, v136, v10 :: v_dual_dot2acc_f32_f16 v80, v139, v7// 000000492B8C: CB181588 51500F8B
	v_dot2acc_f32_f16 v79, v136, v26                           // 000000492B94: 049E3588
	v_bfe_u32 v136, v133, 8, 16                                // 000000492B98: D6100088 02411185
	v_mul_u32_u24_e32 v143, s6, v138                           // 000000492BA0: 171F1406
	v_mul_u32_u24_e32 v138, s7, v138                           // 000000492BA4: 17151407
	v_dual_dot2acc_f32_f16 v78, v137, v32 :: v_dual_and_b32 v133, 0xffff, v133// 000000492BA8: CB244189 4E850AFF 0000FFFF
	v_lshl_add_u32 v138, v138, 24, v143                        // 000000492BB4: D646008A 063D318A
	v_mul_u32_u24_e32 v143, s6, v136                           // 000000492BBC: 171F1006
	v_mul_u32_u24_e32 v136, s7, v136                           // 000000492BC0: 17111007
	v_dot2acc_f32_f16 v98, v140, v16                           // 000000492BC4: 04C4218C
	s_waitcnt vmcnt(4)                                         // 000000492BC8: BF8913F7
	v_bfe_u32 v140, v134, 12, 16                               // 000000492BCC: D610008C 02411986
	v_lshl_add_u32 v136, v136, 24, v143                        // 000000492BD4: D6460088 063D3188
	v_mul_u32_u24_e32 v143, s6, v133                           // 000000492BDC: 171F0A06
	v_mul_u32_u24_e32 v133, s7, v133                           // 000000492BE0: 170B0A07
	v_lshl_add_u32 v133, v133, 24, v143                        // 000000492BE4: D6460085 063D3185
	v_mul_u32_u24_e32 v143, s6, v140                           // 000000492BEC: 171F1806
	v_mul_u32_u24_e32 v140, s7, v140                           // 000000492BF0: 17191807
	v_sad_u8 v135, v135, 0, 0x6400                             // 000000492BF4: D6220087 03FD0187 00006400
	v_lshl_add_u32 v140, v140, 24, v143                        // 000000492C00: D646008C 063D318C
	v_sad_u8 v138, v138, 0, 0x6400                             // 000000492C08: D622008A 03FD018A 00006400
	v_sad_u8 v136, v136, 0, 0x6400                             // 000000492C14: D6220088 03FD0188 00006400
	v_bfe_u32 v141, v134, 8, 16                                // 000000492C20: D610008D 02411186
	v_and_b32_e32 v135, 0xffff, v135                           // 000000492C28: 370F0EFF 0000FFFF
	v_sad_u8 v140, v140, 0, 0x6400                             // 000000492C30: D622008C 03FD018C 00006400
	v_mul_u32_u24_e32 v143, s6, v141                           // 000000492C3C: 171F1A06
	v_mul_u32_u24_e32 v141, s7, v141                           // 000000492C40: 171B1A07
	v_and_b32_e32 v138, 0xffff, v138                           // 000000492C44: 371514FF 0000FFFF
	v_sad_u8 v133, v133, 0, 0x6400                             // 000000492C4C: D6220085 03FD0185 00006400
	v_lshl_add_u32 v141, v141, 24, v143                        // 000000492C58: D646008D 063D318D
	v_lshl_or_b32 v135, v136, 16, v135                         // 000000492C60: D6560087 061D2188
	v_dual_dot2acc_f32_f16 v79, v139, v27 :: v_dual_and_b32 v136, 0xffff, v140// 000000492C68: CB24378B 4F8918FF 0000FFFF
	v_dual_dot2acc_f32_f16 v81, v139, v11 :: v_dual_dot2acc_f32_f16 v80, v137, v8// 000000492C74: CB18178B 51501189
	v_bfe_u32 v142, v134, 4, 16                                // 000000492C7C: D610008E 02410986
	v_mul_u32_u24_e32 v143, s6, v142                           // 000000492C84: 171F1C06
	v_mul_u32_u24_e32 v142, s7, v142                           // 000000492C88: 171D1C07
	s_delay_alu instid0(VALU_DEP_1)                            // 000000492C8C: BF870001
	v_lshl_add_u32 v142, v142, 24, v143                        // 000000492C90: D646008E 063D318E
	v_lshl_or_b32 v133, v133, 16, v138                         // 000000492C98: D6560085 06292185
	v_sad_u8 v138, v141, 0, 0x6400                             // 000000492CA0: D622008A 03FD018D 00006400
	v_pk_fma_f16 v135, v135, s8, 0xc931 op_sel_hi:[1,0,0]      // 000000492CAC: CC0E0087 0BFC1187 0000C931
	v_dual_dot2acc_f32_f16 v81, v137, v12 :: v_dual_and_b32 v134, 0xffff, v134// 000000492CB8: CB241989 51870CFF 0000FFFF
	v_mul_u32_u24_e32 v141, s6, v134                           // 000000492CC4: 171B0C06
	v_mul_u32_u24_e32 v134, s7, v134                           // 000000492CC8: 170D0C07
	v_sad_u8 v140, v142, 0, 0x6400                             // 000000492CCC: D622008C 03FD018E 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 000000492CD8: BF870002
	v_lshl_add_u32 v134, v134, 24, v141                        // 000000492CDC: D6460086 06353186
	v_dual_dot2acc_f32_f16 v79, v137, v28 :: v_dual_dot2acc_f32_f16 v76, v135, v21// 000000492CE4: CB183989 4F4C2B87
	v_pk_fma_f16 v133, v133, s8, 0xc931 op_sel_hi:[1,0,0]      // 000000492CEC: CC0E0085 0BFC1185 0000C931
	v_lshl_or_b32 v136, v138, 16, v136                         // 000000492CF8: D6560088 0621218A
	v_and_b32_e32 v138, 0xffff, v140                           // 000000492D00: 371518FF 0000FFFF
	v_sad_u8 v134, v134, 0, 0x6400                             // 000000492D08: D6220086 03FD0186 00006400
	v_alignbit_b32 v130, v130, v132, 16                        // 000000492D14: D6160082 02430982
	v_dot2acc_f32_f16 v76, v133, v22                           // 000000492D1C: 04982D85
	v_pk_fma_f16 v136, v136, s8, 0xc931 op_sel_hi:[1,0,0]      // 000000492D20: CC0E0088 0BFC1188 0000C931
	v_dot2acc_f32_f16 v75, v135, v13                           // 000000492D2C: 04961B87
	v_lshl_or_b32 v134, v134, 16, v138                         // 000000492D30: D6560086 06292186
	v_dot2acc_f32_f16 v72, v135, v5                            // 000000492D38: 04900B87
	v_bfe_u32 v132, v130, 12, 16                               // 000000492D3C: D6100084 02411982
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000492D44: BF870214
	v_dual_dot2acc_f32_f16 v76, v136, v23 :: v_dual_dot2acc_f32_f16 v75, v133, v14// 000000492D48: CB182F88 4C4A1D85
	v_pk_fma_f16 v134, v134, s8, 0xc931 op_sel_hi:[1,0,0]      // 000000492D50: CC0E0086 0BFC1186 0000C931
	v_dot2acc_f32_f16 v77, v139, v3                            // 000000492D5C: 049A078B
	v_mul_u32_u24_e32 v141, s6, v132                           // 000000492D60: 171B0806
	v_mul_u32_u24_e32 v132, s7, v132                           // 000000492D64: 17090807
	v_dual_dot2acc_f32_f16 v75, v136, v15 :: v_dual_dot2acc_f32_f16 v72, v133, v6// 000000492D68: CB181F88 4B480D85
	v_dot2acc_f32_f16 v71, v135, v25                           // 000000492D70: 048E3387
	v_lshl_add_u32 v132, v132, 24, v141                        // 000000492D74: D6460084 06353184
	v_dot2acc_f32_f16 v74, v135, v17                           // 000000492D7C: 04942387
	v_dual_dot2acc_f32_f16 v73, v135, v9 :: v_dual_dot2acc_f32_f16 v76, v134, v24// 000000492D80: CB181387 494C3186
	v_dot2acc_f32_f16 v77, v137, v4                            // 000000492D88: 049A0989
	v_bfe_u32 v137, v130, 4, 16                                // 000000492D8C: D6100089 02410982
	v_dual_dot2acc_f32_f16 v75, v134, v16 :: v_dual_dot2acc_f32_f16 v70, v135, v29// 000000492D94: CB182186 4B463B87
	v_dot2acc_f32_f16 v69, v135, v1                            // 000000492D9C: 048A0387
	v_bfe_u32 v135, v130, 8, 16                                // 000000492DA0: D6100087 02411182
	v_mul_u32_u24_e32 v141, s6, v137                           // 000000492DA8: 171B1206
	v_mul_u32_u24_e32 v137, s7, v137                           // 000000492DAC: 17131207
	v_lshl_add_u32 v137, v137, 24, v141                        // 000000492DB0: D6460089 06353189
	v_mul_u32_u24_e32 v141, s6, v135                           // 000000492DB8: 171B0E06
	v_mul_u32_u24_e32 v135, s7, v135                           // 000000492DBC: 170F0E07
	v_dual_dot2acc_f32_f16 v72, v136, v7 :: v_dual_dot2acc_f32_f16 v71, v133, v26// 000000492DC0: CB180F88 48463585
	v_sad_u8 v132, v132, 0, 0x6400                             // 000000492DC8: D6220084 03FD0184 00006400
	v_lshl_add_u32 v135, v135, 24, v141                        // 000000492DD4: D6460087 06353187
	v_dot2acc_f32_f16 v74, v133, v18                           // 000000492DDC: 04942585
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000492DE0: BF870214
	v_dual_dot2acc_f32_f16 v73, v133, v10 :: v_dual_dot2acc_f32_f16 v72, v134, v8// 000000492DE4: CB181585 49481186
	v_dual_dot2acc_f32_f16 v71, v136, v27 :: v_dual_and_b32 v132, 0xffff, v132// 000000492DEC: CB243788 478508FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000492DF8: BF870214
	v_sad_u8 v135, v135, 0, 0x6400                             // 000000492DFC: D6220087 03FD0187 00006400
	v_dot2acc_f32_f16 v74, v136, v19                           // 000000492E08: 04942788
	s_delay_alu instid0(VALU_DEP_4)                            // 000000492E0C: BF870004
	v_dual_dot2acc_f32_f16 v73, v136, v11 :: v_dual_and_b32 v130, 0xffff, v130// 000000492E10: CB241788 498304FF 0000FFFF
	s_waitcnt vmcnt(3)                                         // 000000492E1C: BF890FF7
	v_bfe_u32 v138, v131, 12, 16                               // 000000492E20: D610008A 02411983
	v_lshl_or_b32 v132, v135, 16, v132                         // 000000492E28: D6560084 06112187
	v_dot2acc_f32_f16 v74, v134, v20                           // 000000492E30: 04942986
	v_dot2acc_f32_f16 v73, v134, v12                           // 000000492E34: 04921986
	v_mul_u32_u24_e32 v141, s6, v130                           // 000000492E38: 171B0406
	v_mul_u32_u24_e32 v130, s7, v130                           // 000000492E3C: 17050407
	v_lshl_add_u32 v130, v130, 24, v141                        // 000000492E40: D6460082 06353182
	v_mul_u32_u24_e32 v141, s6, v138                           // 000000492E48: 171B1406
	v_mul_u32_u24_e32 v138, s7, v138                           // 000000492E4C: 17151407
	v_sad_u8 v137, v137, 0, 0x6400                             // 000000492E50: D6220089 03FD0189 00006400
	v_lshl_add_u32 v138, v138, 24, v141                        // 000000492E5C: D646008A 0635318A
	v_pk_fma_f16 v132, v132, s8, 0xc931 op_sel_hi:[1,0,0]      // 000000492E64: CC0E0084 0BFC1184 0000C931
	v_bfe_u32 v139, v131, 8, 16                                // 000000492E70: D610008B 02411183
	v_mul_u32_u24_e32 v141, s6, v139                           // 000000492E78: 171B1606
	v_mul_u32_u24_e32 v139, s7, v139                           // 000000492E7C: 17171607
	v_bfe_u32 v140, v131, 4, 16                                // 000000492E80: D610008C 02410983
	v_dual_dot2acc_f32_f16 v68, v132, v21 :: v_dual_and_b32 v131, 0xffff, v131// 000000492E88: CB242B84 448306FF 0000FFFF
	v_and_b32_e32 v137, 0xffff, v137                           // 000000492E94: 371312FF 0000FFFF
	v_sad_u8 v130, v130, 0, 0x6400                             // 000000492E9C: D6220082 03FD0182 00006400
	v_sad_u8 v138, v138, 0, 0x6400                             // 000000492EA8: D622008A 03FD018A 00006400
	v_lshl_add_u32 v139, v139, 24, v141                        // 000000492EB4: D646008B 0635318B
	v_mul_u32_u24_e32 v141, s6, v140                           // 000000492EBC: 171B1806
	v_mul_u32_u24_e32 v140, s7, v140                           // 000000492EC0: 17191807
	v_lshl_add_u32 v140, v140, 24, v141                        // 000000492EC4: D646008C 0635318C
	v_lshl_or_b32 v130, v130, 16, v137                         // 000000492ECC: D6560082 06252182
	v_sad_u8 v137, v139, 0, 0x6400                             // 000000492ED4: D6220089 03FD018B 00006400
	v_dot2acc_f32_f16 v70, v133, v30                           // 000000492EE0: 048C3D85
	v_and_b32_e32 v135, 0xffff, v138                           // 000000492EE4: 370F14FF 0000FFFF
	v_mul_u32_u24_e32 v139, s6, v131                           // 000000492EEC: 17170606
	v_mul_u32_u24_e32 v131, s7, v131                           // 000000492EF0: 17070607
	v_sad_u8 v138, v140, 0, 0x6400                             // 000000492EF4: D622008A 03FD018C 00006400
	v_lshl_add_u32 v131, v131, 24, v139                        // 000000492F00: D6460083 062D3183
	v_pk_fma_f16 v130, v130, s8, 0xc931 op_sel_hi:[1,0,0]      // 000000492F08: CC0E0082 0BFC1182 0000C931
	v_dot2acc_f32_f16 v70, v136, v31                           // 000000492F14: 048C3F88
	v_lshl_or_b32 v135, v137, 16, v135                         // 000000492F18: D6560087 061D2189
	v_dot2acc_f32_f16 v69, v133, v2                            // 000000492F20: 048A0585
	v_sad_u8 v131, v131, 0, 0x6400                             // 000000492F24: D6220083 03FD0183 00006400
	v_dot2acc_f32_f16 v68, v130, v22                           // 000000492F30: 04882D82
	v_dual_dot2acc_f32_f16 v71, v134, v28 :: v_dual_dot2acc_f32_f16 v66, v132, v17// 000000492F34: CB183986 47422384
	v_pk_fma_f16 v133, v135, s8, 0xc931 op_sel_hi:[1,0,0]      // 000000492F3C: CC0E0085 0BFC1187 0000C931
	v_and_b32_e32 v137, 0xffff, v138                           // 000000492F48: 371314FF 0000FFFF
	v_dot2acc_f32_f16 v67, v132, v13                           // 000000492F50: 04861B84
	v_alignbit_b32 v127, v127, v129, 16                        // 000000492F54: D616007F 0243037F
	v_dot2acc_f32_f16 v70, v134, v32                           // 000000492F5C: 048C4186
	v_dot2acc_f32_f16 v68, v133, v23                           // 000000492F60: 04882F85
	v_lshl_or_b32 v131, v131, 16, v137                         // 000000492F64: D6560083 06252183
	v_dot2acc_f32_f16 v66, v130, v18                           // 000000492F6C: 04842582
	v_dot2acc_f32_f16 v67, v130, v14                           // 000000492F70: 04861D82
	v_bfe_u32 v129, v127, 12, 16                               // 000000492F74: D6100081 0241197F
	v_mul_u32_u24_e32 v138, s6, v129                           // 000000492F7C: 17150206
	v_pk_fma_f16 v131, v131, s8, 0xc931 op_sel_hi:[1,0,0]      // 000000492F80: CC0E0083 0BFC1183 0000C931
	v_dot2acc_f32_f16 v69, v136, v3                            // 000000492F8C: 048A0788
	v_mul_u32_u24_e32 v129, s7, v129                           // 000000492F90: 17030207
	v_lshl_add_u32 v129, v129, 24, v138                        // 000000492F94: D6460081 06293181
	v_dot2acc_f32_f16 v64, v132, v5                            // 000000492F9C: 04800B84
	v_dot2acc_f32_f16 v68, v131, v24                           // 000000492FA0: 04883183
	v_dot2acc_f32_f16 v69, v134, v4                            // 000000492FA4: 048A0986
	v_bfe_u32 v134, v127, 4, 16                                // 000000492FA8: D6100086 0241097F
	s_delay_alu instid0(VALU_DEP_4)                            // 000000492FB0: BF870004
	v_dual_dot2acc_f32_f16 v65, v132, v9 :: v_dual_dot2acc_f32_f16 v64, v130, v6// 000000492FB4: CB181384 41400D82
	v_dual_dot2acc_f32_f16 v66, v133, v19 :: v_dual_dot2acc_f32_f16 v63, v132, v25// 000000492FBC: CB182785 423E3384
	v_dual_dot2acc_f32_f16 v67, v133, v15 :: v_dual_dot2acc_f32_f16 v62, v132, v29// 000000492FC4: CB181F85 433E3B84
	v_dot2acc_f32_f16 v61, v132, v1                            // 000000492FCC: 047A0384
	v_bfe_u32 v132, v127, 8, 16                                // 000000492FD0: D6100084 0241117F
	v_mul_u32_u24_e32 v138, s6, v134                           // 000000492FD8: 17150C06
	v_mul_u32_u24_e32 v134, s7, v134                           // 000000492FDC: 170D0C07
	v_lshl_add_u32 v134, v134, 24, v138                        // 000000492FE0: D6460086 06293186
	v_mul_u32_u24_e32 v138, s6, v132                           // 000000492FE8: 17150806
	v_mul_u32_u24_e32 v132, s7, v132                           // 000000492FEC: 17090807
	v_sad_u8 v129, v129, 0, 0x6400                             // 000000492FF0: D6220081 03FD0181 00006400
	v_lshl_add_u32 v132, v132, 24, v138                        // 000000492FFC: D6460084 06293184
	v_dual_dot2acc_f32_f16 v67, v131, v16 :: v_dual_dot2acc_f32_f16 v62, v130, v30// 000000493004: CB182183 433E3D82
	s_waitcnt vmcnt(2)                                         // 00000049300C: BF890BF7
	v_bfe_u32 v135, v128, 12, 16                               // 000000493010: D6100087 02411980
	v_and_b32_e32 v129, 0xffff, v129                           // 000000493018: 370302FF 0000FFFF
	v_sad_u8 v132, v132, 0, 0x6400                             // 000000493020: D6220084 03FD0184 00006400
	v_dual_dot2acc_f32_f16 v65, v130, v10 :: v_dual_dot2acc_f32_f16 v64, v133, v7// 00000049302C: CB181582 41400F85
	v_dot2acc_f32_f16 v62, v133, v31                           // 000000493034: 047C3F85
	v_dot2acc_f32_f16 v66, v131, v20                           // 000000493038: 04842983
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000049303C: BF870214
	v_lshl_or_b32 v129, v132, 16, v129                         // 000000493040: D6560081 06052184
	v_dual_dot2acc_f32_f16 v63, v130, v26 :: v_dual_dot2acc_f32_f16 v64, v131, v8// 000000493048: CB183582 3F401183
	v_sad_u8 v134, v134, 0, 0x6400                             // 000000493050: D6220086 03FD0186 00006400
	v_bfe_u32 v136, v128, 8, 16                                // 00000049305C: D6100088 02411180
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000493064: BF870244
	v_pk_fma_f16 v129, v129, s8, 0xc931 op_sel_hi:[1,0,0]      // 000000493068: CC0E0081 0BFC1181 0000C931
	v_and_b32_e32 v127, 0xffff, v127                           // 000000493074: 36FEFEFF 0000FFFF
	v_dot2acc_f32_f16 v65, v133, v11                           // 00000049307C: 04821785
	v_dual_dot2acc_f32_f16 v63, v133, v27 :: v_dual_and_b32 v134, 0xffff, v134// 000000493080: CB243785 3F870CFF 0000FFFF
	v_dot2acc_f32_f16 v60, v129, v21                           // 00000049308C: 04782B81
	v_mul_u32_u24_e32 v138, s6, v127                           // 000000493090: 1714FE06
	v_mul_u32_u24_e32 v127, s7, v127                           // 000000493094: 16FEFE07
	v_lshl_add_u32 v127, v127, 24, v138                        // 000000493098: D646007F 0629317F
	v_mul_u32_u24_e32 v138, s6, v135                           // 0000004930A0: 17150E06
	v_mul_u32_u24_e32 v135, s7, v135                           // 0000004930A4: 170F0E07
	v_lshl_add_u32 v135, v135, 24, v138                        // 0000004930A8: D6460087 06293187
	v_mul_u32_u24_e32 v138, s6, v136                           // 0000004930B0: 17151006
	v_mul_u32_u24_e32 v136, s7, v136                           // 0000004930B4: 17111007
	v_sad_u8 v127, v127, 0, 0x6400                             // 0000004930B8: D622007F 03FD017F 00006400
	v_lshl_add_u32 v136, v136, 24, v138                        // 0000004930C4: D6460088 06293188
	v_sad_u8 v135, v135, 0, 0x6400                             // 0000004930CC: D6220087 03FD0187 00006400
	v_bfe_u32 v137, v128, 4, 16                                // 0000004930D8: D6100089 02410980
	v_mul_u32_u24_e32 v138, s6, v137                           // 0000004930E0: 17151206
	v_mul_u32_u24_e32 v137, s7, v137                           // 0000004930E4: 17131207
	v_and_b32_e32 v128, 0xffff, v128                           // 0000004930E8: 370100FF 0000FFFF
	v_dual_dot2acc_f32_f16 v65, v131, v12 :: v_dual_and_b32 v132, 0xffff, v135// 0000004930F0: CB241983 41850EFF 0000FFFF
	v_lshl_add_u32 v137, v137, 24, v138                        // 0000004930FC: D6460089 06293189
	v_lshl_or_b32 v127, v127, 16, v134                         // 000000493104: D656007F 0619217F
	v_sad_u8 v134, v136, 0, 0x6400                             // 00000049310C: D6220086 03FD0188 00006400
	v_mul_u32_u24_e32 v136, s6, v128                           // 000000493118: 17110006
	v_mul_u32_u24_e32 v128, s7, v128                           // 00000049311C: 17010007
	v_sad_u8 v135, v137, 0, 0x6400                             // 000000493120: D6220087 03FD0189 00006400
	v_lshl_add_u32 v128, v128, 24, v136                        // 00000049312C: D6460080 06213180
	v_pk_fma_f16 v127, v127, s8, 0xc931 op_sel_hi:[1,0,0]      // 000000493134: CC0E007F 0BFC117F 0000C931
	v_lshl_or_b32 v132, v134, 16, v132                         // 000000493140: D6560084 06112186
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000493148: BF870214
	v_dual_dot2acc_f32_f16 v63, v131, v28 :: v_dual_and_b32 v134, 0xffff, v135// 00000049314C: CB243983 3F870EFF 0000FFFF
	v_sad_u8 v128, v128, 0, 0x6400                             // 000000493158: D6220080 03FD0180 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 000000493164: BF870004
	v_dot2acc_f32_f16 v60, v127, v22                           // 000000493168: 04782D7F
	v_dual_dot2acc_f32_f16 v61, v130, v2 :: v_dual_dot2acc_f32_f16 v62, v131, v32// 00000049316C: CB180582 3D3E4183
	v_pk_fma_f16 v130, v132, s8, 0xc931 op_sel_hi:[1,0,0]      // 000000493174: CC0E0082 0BFC1184 0000C931
	v_dot2acc_f32_f16 v59, v129, v13                           // 000000493180: 04761B81
	v_lshl_or_b32 v128, v128, 16, v134                         // 000000493184: D6560080 06192180
	v_dot2acc_f32_f16 v58, v129, v17                           // 00000049318C: 04742381
	v_dot2acc_f32_f16 v54, v129, v29                           // 000000493190: 046C3B81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000493194: BF870214
	v_dual_dot2acc_f32_f16 v60, v130, v23 :: v_dual_dot2acc_f32_f16 v59, v127, v14// 000000493198: CB182F82 3C3A1D7F
	v_pk_fma_f16 v128, v128, s8, 0xc931 op_sel_hi:[1,0,0]      // 0000004931A0: CC0E0080 0BFC1180 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000004931AC: BF870224
	v_dual_dot2acc_f32_f16 v58, v127, v18 :: v_dual_dot2acc_f32_f16 v57, v129, v9// 0000004931B0: CB18257F 3A381381
	v_dot2acc_f32_f16 v61, v133, v3                            // 0000004931B8: 047A0785
	v_dot2acc_f32_f16 v59, v130, v15                           // 0000004931BC: 04761F82
	v_alignbit_b32 v124, v124, v126, 16                        // 0000004931C0: D616007C 0242FD7C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000004931C8: BF870224
	v_dual_dot2acc_f32_f16 v58, v130, v19 :: v_dual_dot2acc_f32_f16 v57, v127, v10// 0000004931CC: CB182782 3A38157F
	v_dot2acc_f32_f16 v60, v128, v24                           // 0000004931D4: 04783180
	v_dot2acc_f32_f16 v59, v128, v16                           // 0000004931D8: 04762180
	v_dual_dot2acc_f32_f16 v61, v131, v4 :: v_dual_dot2acc_f32_f16 v56, v129, v5// 0000004931DC: CB180983 3D380B81
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000004931E4: BF8701A4
	v_dot2acc_f32_f16 v58, v128, v20                           // 0000004931E8: 04742980
	v_dual_dot2acc_f32_f16 v54, v127, v30 :: v_dual_dot2acc_f32_f16 v57, v130, v11// 0000004931EC: CB183D7F 36381782
	v_dual_dot2acc_f32_f16 v55, v129, v25 :: v_dual_dot2acc_f32_f16 v56, v127, v6// 0000004931F4: CB183381 37380D7F
	v_bfe_u32 v126, v124, 12, 16                               // 0000004931FC: D610007E 0241197C
	s_delay_alu instid0(VALU_DEP_3)                            // 000000493204: BF870003
	v_dual_dot2acc_f32_f16 v54, v130, v31 :: v_dual_dot2acc_f32_f16 v57, v128, v12// 000000493208: CB183F82 36381980
	v_mul_u32_u24_e32 v135, s6, v126                           // 000000493210: 170EFC06
	v_mul_u32_u24_e32 v126, s7, v126                           // 000000493214: 16FCFC07
	v_dual_dot2acc_f32_f16 v55, v127, v26 :: v_dual_dot2acc_f32_f16 v56, v130, v7// 000000493218: CB18357F 37380F82
	v_lshl_add_u32 v126, v126, 24, v135                        // 000000493220: D646007E 061D317E
	v_bfe_u32 v131, v124, 4, 16                                // 000000493228: D6100083 0241097C
	v_dual_dot2acc_f32_f16 v54, v128, v32 :: v_dual_dot2acc_f32_f16 v53, v129, v1// 000000493230: CB184180 36340381
	v_bfe_u32 v129, v124, 8, 16                                // 000000493238: D6100081 0241117C
	v_mul_u32_u24_e32 v135, s6, v131                           // 000000493240: 170F0606
	v_mul_u32_u24_e32 v131, s7, v131                           // 000000493244: 17070607
	v_lshl_add_u32 v131, v131, 24, v135                        // 000000493248: D6460083 061D3183
	v_mul_u32_u24_e32 v135, s6, v129                           // 000000493250: 170F0206
	v_mul_u32_u24_e32 v129, s7, v129                           // 000000493254: 17030207
	v_dual_dot2acc_f32_f16 v55, v130, v27 :: v_dual_dot2acc_f32_f16 v56, v128, v8// 000000493258: CB183782 37381180
	v_sad_u8 v126, v126, 0, 0x6400                             // 000000493260: D622007E 03FD017E 00006400
	v_lshl_add_u32 v129, v129, 24, v135                        // 00000049326C: D6460081 061D3181
	v_sad_u8 v131, v131, 0, 0x6400                             // 000000493274: D6220083 03FD0183 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 000000493280: BF870004
	v_dot2acc_f32_f16 v55, v128, v28                           // 000000493284: 046E3980
	s_waitcnt vmcnt(1)                                         // 000000493288: BF8907F7
	v_bfe_u32 v132, v125, 12, 16                               // 00000049328C: D6100084 0241197D
	v_and_b32_e32 v126, 0xffff, v126                           // 000000493294: 36FCFCFF 0000FFFF
	v_sad_u8 v129, v129, 0, 0x6400                             // 00000049329C: D6220081 03FD0181 00006400
	v_bfe_u32 v133, v125, 8, 16                                // 0000004932A8: D6100085 0241117D
	v_bfe_u32 v134, v125, 4, 16                                // 0000004932B0: D6100086 0241097D
	v_dot2acc_f32_f16 v53, v127, v2                            // 0000004932B8: 046A057F
	v_alignbit_b32 v122, v122, v123, 16                        // 0000004932BC: D616007A 0242F77A
	v_lshl_or_b32 v126, v129, 16, v126                         // 0000004932C4: D656007E 05F92181
	v_dual_mov_b32 v139, v114 :: v_dual_add_nc_u32 v104, 32, v104// 0000004932CC: CA200172 8B68D0A0
	v_mov_b32_e32 v141, v120                                   // 0000004932D4: 7F1A0378
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004932D8: BF870214
	v_bfe_u32 v123, v122, 12, 16                               // 0000004932DC: D610007B 0241197A
	v_pk_fma_f16 v126, v126, s8, 0xc931 op_sel_hi:[1,0,0]      // 0000004932E4: CC0E007E 0BFC117E 0000C931
	v_and_b32_e32 v124, 0xffff, v124                           // 0000004932F0: 36F8F8FF 0000FFFF
	v_dual_mov_b32 v140, v120 :: v_dual_and_b32 v131, 0xffff, v131// 0000004932F8: CA240178 8C8306FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3)                            // 000000493304: BF870003
	v_dual_mov_b32 v136, v111 :: v_dual_dot2acc_f32_f16 v51, v126, v13// 000000493308: CA18016F 88321B7E
	v_mul_u32_u24_e32 v135, s6, v124                           // 000000493310: 170EF806
	v_mul_u32_u24_e32 v124, s7, v124                           // 000000493314: 16F8F807
	v_lshl_add_u32 v124, v124, 24, v135                        // 000000493318: D646007C 061D317C
	v_mul_u32_u24_e32 v135, s6, v132                           // 000000493320: 170F0806
	v_mul_u32_u24_e32 v132, s7, v132                           // 000000493324: 17090807
	v_lshl_add_u32 v132, v132, 24, v135                        // 000000493328: D6460084 061D3184
	v_mul_u32_u24_e32 v135, s6, v133                           // 000000493330: 170F0A06
	v_sad_u8 v124, v124, 0, 0x6400                             // 000000493334: D622007C 03FD017C 00006400
	v_mul_u32_u24_e32 v133, s7, v133                           // 000000493340: 170B0A07
	v_dot2acc_f32_f16 v52, v126, v21                           // 000000493344: 04682B7E
	v_sad_u8 v132, v132, 0, 0x6400                             // 000000493348: D6220084 03FD0184 00006400
	v_lshl_add_u32 v133, v133, 24, v135                        // 000000493354: D6460085 061D3185
	v_lshl_or_b32 v124, v124, 16, v131                         // 00000049335C: D656007C 060D217C
	v_mul_u32_u24_e32 v135, s6, v134                           // 000000493364: 170F0C06
	v_mul_u32_u24_e32 v134, s7, v134                           // 000000493368: 170D0C07
	v_lshl_add_u32 v134, v134, 24, v135                        // 00000049336C: D6460086 061D3186
	v_dual_dot2acc_f32_f16 v50, v126, v17 :: v_dual_and_b32 v129, 0xffff, v132// 000000493374: CB24237E 328108FF 0000FFFF
	v_pk_fma_f16 v124, v124, s8, 0xc931 op_sel_hi:[1,0,0]      // 000000493380: CC0E007C 0BFC117C 0000C931
	v_sad_u8 v131, v133, 0, 0x6400                             // 00000049338C: D6220083 03FD0185 00006400
	v_and_b32_e32 v125, 0xffff, v125                           // 000000493398: 36FAFAFF 0000FFFF
	v_sad_u8 v132, v134, 0, 0x6400                             // 0000004933A0: D6220084 03FD0186 00006400
	v_dot2acc_f32_f16 v48, v126, v5                            // 0000004933AC: 04600B7E
	v_dot2acc_f32_f16 v52, v124, v22                           // 0000004933B0: 04682D7C
	v_mul_u32_u24_e32 v133, s6, v125                           // 0000004933B4: 170AFA06
	v_mul_u32_u24_e32 v125, s7, v125                           // 0000004933B8: 16FAFA07
	v_lshl_add_u32 v125, v125, 24, v133                        // 0000004933BC: D646007D 0615317D
	v_lshl_or_b32 v129, v131, 16, v129                         // 0000004933C4: D6560081 06052183
	v_dot2acc_f32_f16 v50, v124, v18                           // 0000004933CC: 0464257C
	v_dot2acc_f32_f16 v46, v126, v29                           // 0000004933D0: 045C3B7E
	v_dot2acc_f32_f16 v47, v126, v25                           // 0000004933D4: 045E337E
	v_sad_u8 v125, v125, 0, 0x6400                             // 0000004933D8: D622007D 03FD017D 00006400
	v_pk_fma_f16 v127, v129, s8, 0xc931 op_sel_hi:[1,0,0]      // 0000004933E4: CC0E007F 0BFC1181 0000C931
	v_and_b32_e32 v131, 0xffff, v132                           // 0000004933F0: 370708FF 0000FFFF
	v_dot2acc_f32_f16 v51, v124, v14                           // 0000004933F8: 04661D7C
	v_dual_dot2acc_f32_f16 v45, v126, v1 :: v_dual_dot2acc_f32_f16 v48, v124, v6// 0000004933FC: CB18037E 2D300D7C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000493404: BF870214
	v_dot2acc_f32_f16 v52, v127, v23                           // 000000493408: 04682F7F
	v_lshl_or_b32 v125, v125, 16, v131                         // 00000049340C: D656007D 060D217D
	v_dot2acc_f32_f16 v50, v127, v19                           // 000000493414: 0464277F
	v_dot2acc_f32_f16 v51, v127, v15                           // 000000493418: 04661F7F
	v_dot2acc_f32_f16 v48, v127, v7                            // 00000049341C: 04600F7F
	v_dot2acc_f32_f16 v46, v124, v30                           // 000000493420: 045C3D7C
	v_pk_fma_f16 v125, v125, s8, 0xc931 op_sel_hi:[1,0,0]      // 000000493424: CC0E007D 0BFC117D 0000C931
	v_dot2acc_f32_f16 v49, v126, v9                            // 000000493430: 0462137E
	v_bfe_u32 v126, v122, 4, 16                                // 000000493434: D610007E 0241097A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000049343C: BF870214
	v_dual_dot2acc_f32_f16 v47, v124, v26 :: v_dual_dot2acc_f32_f16 v46, v127, v31// 000000493440: CB18357C 2F2E3F7F
	v_dual_dot2acc_f32_f16 v52, v125, v24 :: v_dual_dot2acc_f32_f16 v53, v130, v3// 000000493448: CB18317D 34340782
	v_dot2acc_f32_f16 v51, v125, v16                           // 000000493450: 0466217D
	v_dual_dot2acc_f32_f16 v50, v125, v20 :: v_dual_dot2acc_f32_f16 v49, v124, v10// 000000493454: CB18297D 3230157C
	v_dot2acc_f32_f16 v48, v125, v8                            // 00000049345C: 0460117D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000493460: BF870004
	v_dot2acc_f32_f16 v53, v128, v4                            // 000000493464: 046A0980
	v_mul_u32_u24_e32 v128, s6, v126                           // 000000493468: 1700FC06
	v_mul_u32_u24_e32 v126, s7, v126                           // 00000049346C: 16FCFC07
	v_lshl_add_u32 v126, v126, 24, v128                        // 000000493470: D646007E 0601317E
	v_dot2acc_f32_f16 v49, v127, v11                           // 000000493478: 0462177F
	v_dual_dot2acc_f32_f16 v47, v127, v27 :: v_dual_dot2acc_f32_f16 v46, v125, v32// 00000049347C: CB18377F 2F2E417D
	s_waitcnt vmcnt(0)                                         // 000000493484: BF8903F7
	v_bfe_u32 v128, v106, 8, 16                                // 000000493488: D6100080 0241116A
	v_sad_u8 v126, v126, 0, 0x6400                             // 000000493490: D622007E 03FD017E 00006400
	v_dot2acc_f32_f16 v49, v125, v12                           // 00000049349C: 0462197D
	v_dual_dot2acc_f32_f16 v47, v125, v28 :: v_dual_mov_b32 v138, v119// 0000004934A0: CB10397D 2F8A0177
	s_delay_alu instid0(VALU_DEP_3)                            // 0000004934A8: BF870003
	v_dual_mov_b32 v137, v119 :: v_dual_and_b32 v126, 0xffff, v126// 0000004934AC: CA240177 897EFCFF 0000FFFF
	v_dot2acc_f32_f16 v45, v124, v2                            // 0000004934B8: 045A057C
	v_mul_u32_u24_e32 v124, s6, v123                           // 0000004934BC: 16F8F606
	v_mul_u32_u24_e32 v123, s7, v123                           // 0000004934C0: 16F6F607
	v_lshl_add_u32 v123, v123, 24, v124                        // 0000004934C4: D646007B 05F1317B
	v_bfe_u32 v124, v122, 8, 16                                // 0000004934CC: D610007C 0241117A
	v_and_b32_e32 v122, 0xffff, v122                           // 0000004934D4: 36F4F4FF 0000FFFF
	v_mul_u32_u24_e32 v129, s6, v122                           // 0000004934DC: 1702F406
	v_mul_u32_u24_e32 v122, s7, v122                           // 0000004934E0: 16F4F407
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004934E4: BF870001
	v_lshl_add_u32 v122, v122, 24, v129                        // 0000004934E8: D646007A 0605317A
	v_dot2acc_f32_f16 v45, v127, v3                            // 0000004934F0: 045A077F
	v_mul_u32_u24_e32 v127, s6, v124                           // 0000004934F4: 16FEF806
	v_mul_u32_u24_e32 v124, s7, v124                           // 0000004934F8: 16F8F807
	v_sad_u8 v123, v123, 0, 0x6400                             // 0000004934FC: D622007B 03FD017B 00006400
	v_sad_u8 v122, v122, 0, 0x6400                             // 000000493508: D622007A 03FD017A 00006400
	v_lshl_add_u32 v124, v124, 24, v127                        // 000000493514: D646007C 05FD317C
	v_bfe_u32 v127, v106, 12, 16                               // 00000049351C: D610007F 0241196A
	v_mul_u32_u24_e32 v129, s6, v127                           // 000000493524: 1702FE06
	v_mul_u32_u24_e32 v127, s7, v127                           // 000000493528: 16FEFE07
	v_lshl_or_b32 v122, v122, 16, v126                         // 00000049352C: D656007A 05F9217A
	v_sad_u8 v124, v124, 0, 0x6400                             // 000000493534: D622007C 03FD017C 00006400
	v_lshl_add_u32 v127, v127, 24, v129                        // 000000493540: D646007F 0605317F
	v_bfe_u32 v129, v106, 4, 16                                // 000000493548: D6100081 0241096A
	v_mul_u32_u24_e32 v126, s6, v129                           // 000000493550: 16FD0206
	v_pk_fma_f16 v122, v122, s8, 0xc931 op_sel_hi:[1,0,0]      // 000000493554: CC0E007A 0BFC117A 0000C931
	v_and_b32_e32 v123, 0xffff, v123                           // 000000493560: 36F6F6FF 0000FFFF
	v_dual_mov_b32 v133, v110 :: v_dual_and_b32 v106, 0xffff, v106// 000000493568: CA24016E 856AD4FF 0000FFFF
	v_mov_b32_e32 v135, v118                                   // 000000493574: 7F0E0376
	v_mov_b32_e32 v134, v118                                   // 000000493578: 7F0C0376
	s_delay_alu instid0(VALU_DEP_4)                            // 00000049357C: BF870004
	v_lshl_or_b32 v123, v124, 16, v123                         // 000000493580: D656007B 05ED217C
	v_sad_u8 v124, v127, 0, 0x6400                             // 000000493588: D622007C 03FD017F 00006400
	v_mul_u32_u24_e32 v127, s7, v129                           // 000000493594: 16FF0207
	v_lshl_add_u32 v126, v127, 24, v126                        // 000000493598: D646007E 05F9317F
	v_mul_u32_u24_e32 v127, s6, v128                           // 0000004935A0: 16FF0006
	v_mul_u32_u24_e32 v128, s7, v128                           // 0000004935A4: 17010007
	v_lshl_add_u32 v127, v128, 24, v127                        // 0000004935A8: D646007F 05FD3180
	v_pk_fma_f16 v123, v123, s8, 0xc931 op_sel_hi:[1,0,0]      // 0000004935B0: CC0E007B 0BFC117B 0000C931
	v_mul_u32_u24_e32 v128, s6, v106                           // 0000004935BC: 1700D406
	v_mul_u32_u24_e32 v106, s7, v106                           // 0000004935C0: 16D4D407
	v_and_b32_e32 v124, 0xffff, v124                           // 0000004935C4: 36F8F8FF 0000FFFF
	v_sad_u8 v126, v126, 0, 0x6400                             // 0000004935CC: D622007E 03FD017E 00006400
	v_lshl_add_u32 v106, v106, 24, v128                        // 0000004935D8: D646006A 0601316A
	v_sad_u8 v127, v127, 0, 0x6400                             // 0000004935E0: D622007F 03FD017F 00006400
	v_dot2acc_f32_f16 v42, v123, v17                           // 0000004935EC: 0454237B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004935F0: BF870214
	v_dual_dot2acc_f32_f16 v43, v123, v13 :: v_dual_and_b32 v126, 0xffff, v126// 0000004935F4: CB241B7B 2B7EFCFF 0000FFFF
	v_sad_u8 v106, v106, 0, 0x6400                             // 000000493600: D622006A 03FD016A 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000049360C: BF870214
	v_lshl_or_b32 v124, v127, 16, v124                         // 000000493610: D656007C 05F1217F
	v_dot2acc_f32_f16 v42, v122, v18                           // 000000493618: 0454257A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000049361C: BF870214
	v_dual_dot2acc_f32_f16 v44, v123, v21 :: v_dual_dot2acc_f32_f16 v43, v122, v14// 000000493620: CB182B7B 2C2A1D7A
	v_lshl_or_b32 v13, v106, 16, v126                          // 000000493628: D656000D 05F9216A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000493630: BF870224
	v_pk_fma_f16 v17, v124, s8, 0xc931 op_sel_hi:[1,0,0]       // 000000493634: CC0E0011 0BFC117C 0000C931
	v_dual_dot2acc_f32_f16 v45, v125, v4 :: v_dual_dot2acc_f32_f16 v40, v123, v5// 000000493640: CB18097D 2D280B7B
	v_dual_dot2acc_f32_f16 v44, v122, v22 :: v_dual_dot2acc_f32_f16 v41, v123, v9// 000000493648: CB182D7A 2C28137B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000493650: BF870214
	v_pk_fma_f16 v13, v13, s8, 0xc931 op_sel_hi:[1,0,0]        // 000000493654: CC0E000D 0BFC110D 0000C931
	v_dot2acc_f32_f16 v43, v17, v15                            // 000000493660: 04561F11
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000493664: BF870213
	v_dual_dot2acc_f32_f16 v39, v123, v25 :: v_dual_dot2acc_f32_f16 v44, v17, v23// 000000493668: CB18337B 272C2F11
	v_dual_dot2acc_f32_f16 v42, v17, v19 :: v_dual_dot2acc_f32_f16 v41, v122, v10// 000000493670: CB182711 2A28157A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000493678: BF870193
	v_dual_dot2acc_f32_f16 v43, v13, v16 :: v_dual_dot2acc_f32_f16 v38, v123, v29// 00000049367C: CB18210D 2B263B7B
	v_dot2acc_f32_f16 v44, v13, v24                            // 000000493684: 0458310D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000493688: BF870213
	v_dual_dot2acc_f32_f16 v40, v122, v6 :: v_dual_dot2acc_f32_f16 v41, v17, v11// 00000049368C: CB180D7A 28281711
	v_dual_dot2acc_f32_f16 v42, v13, v20 :: v_dual_dot2acc_f32_f16 v37, v123, v1// 000000493694: CB18290D 2A24037B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000049369C: BF870192
	v_dual_dot2acc_f32_f16 v39, v122, v26 :: v_dual_dot2acc_f32_f16 v40, v17, v7// 0000004936A0: CB18357A 27280F11
	v_dual_dot2acc_f32_f16 v41, v13, v12 :: v_dual_dot2acc_f32_f16 v38, v122, v30// 0000004936A8: CB18190D 29263D7A
	v_add_nc_u32_e32 v33, 1, v33                               // 0000004936B0: 4A424281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004936B4: BF870213
	v_dual_dot2acc_f32_f16 v37, v122, v2 :: v_dual_dot2acc_f32_f16 v40, v13, v8// 0000004936B8: CB18057A 2528110D
	v_dot2acc_f32_f16 v39, v17, v27                            // 0000004936C0: 044E3711
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004936C4: BF870193
	v_dual_dot2acc_f32_f16 v38, v17, v31 :: v_dual_add_nc_u32 v1, v102, v33// 0000004936C8: CB203F11 26004366
	v_dual_dot2acc_f32_f16 v37, v17, v3 :: v_dual_mov_b32 v2, v112// 0000004936D0: CB100711 25020170
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004936D8: BF870193
	v_dot2acc_f32_f16 v39, v13, v28                            // 0000004936DC: 044E390D
	v_dot2acc_f32_f16 v38, v13, v32                            // 0000004936E0: 044C410D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004936E4: BF870214
	v_cmp_eq_u32_e32 vcc_lo, 1, v1                             // 0000004936E8: 7C940281
	v_dot2acc_f32_f16 v37, v13, v4                             // 0000004936EC: 044A090D
	v_mov_b32_e32 v3, v121                                     // 0000004936F0: 7E060379
	v_mov_b32_e32 v25, v121                                    // 0000004936F4: 7E320379
	v_mov_b32_e32 v130, v109                                   // 0000004936F8: 7F04036D
	v_mov_b32_e32 v132, v117                                   // 0000004936FC: 7F080375
	v_dual_mov_b32 v131, v117 :: v_dual_mov_b32 v122, v34      // 000000493700: CA100175 837A0122
	v_dual_mov_b32 v127, v108 :: v_dual_mov_b32 v106, v113     // 000000493708: CA10016C 7F6A0171
	v_mov_b32_e32 v129, v116                                   // 000000493710: 7F020374
	v_mov_b32_e32 v128, v116                                   // 000000493714: 7F000374
	v_mov_b32_e32 v124, v107                                   // 000000493718: 7EF8036B
	v_mov_b32_e32 v126, v115                                   // 00000049371C: 7EFC0373
	v_mov_b32_e32 v125, v115                                   // 000000493720: 7EFA0373
	v_mov_b32_e32 v123, v113                                   // 000000493724: 7EF60371
	s_or_b32 s5, vcc_lo, s5                                    // 000000493728: 8C05056A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000049372C: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 000000493730: 917E057E
	s_cbranch_execz 56                                         // 000000493734: BFA50038 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2018>
	s_mov_b32 s9, exec_lo                                      // 000000493738: BE89007E
	.long 0xd4c1007e                                           // 00000049373C: D4C1007E
	v_cndmask_b32_e32 v1, v33, v101, vcc_lo                    // 000000493740: 0202CB21
	s_cbranch_execz 64340                                      // 000000493744: BFA5FB54 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xc98>
	v_ashrrev_i32_e32 v34, 31, v33                             // 000000493748: 3444429F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000049374C: BF870091
	.long 0xd73c0004                                           // 000000493750: D73C0004
	v_cndmask_b32_e32 v1, 10, v33, vcc_lo                      // 000000493754: 0202428A
	.long 0xd7006a01                                           // 000000493758: D7006A01
	v_cndmask_b32_e32 v1, s1, v4, vcc_lo                       // 00000049375C: 02020801
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000493760: BF870111
	v_add_co_ci_u32_e64 v7, null, s4, v5, vcc_lo               // 000000493764: D5207C07 01AA0A04
	.long 0xd7006a04                                           // 00000049376C: D7006A04
	v_cndmask_b32_e32 v1, v1, v105, vcc_lo                     // 000000493770: 0202D301
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000493774: BF8700A1
	v_add_co_ci_u32_e64 v5, null, 0, v7, vcc_lo                // 000000493778: D5207C05 01AA0E80
	.long 0xd7006a06                                           // 000000493780: D7006A06
	v_cndmask_b32_e32 v1, v1, v103, vcc_lo                     // 000000493784: 0202CF01
	v_add_co_ci_u32_e64 v7, null, 0, v7, vcc_lo                // 000000493788: D5207C07 01AA0E80
	s_clause 0xf                                               // 000000493790: BF85000F
	global_load_b32 v112, v[4:5], off                          // 000000493794: DC520000 707C0004
	global_load_b32 v114, v[4:5], off offset:128               // 00000049379C: DC520080 727C0004
	global_load_b32 v111, v[4:5], off offset:256               // 0000004937A4: DC520100 6F7C0004
	global_load_b32 v110, v[4:5], off offset:384               // 0000004937AC: DC520180 6E7C0004
	global_load_b32 v109, v[4:5], off offset:512               // 0000004937B4: DC520200 6D7C0004
	global_load_b32 v108, v[4:5], off offset:640               // 0000004937BC: DC520280 6C7C0004
	global_load_b32 v107, v[4:5], off offset:768               // 0000004937C4: DC520300 6B7C0004
	global_load_b32 v34, v[4:5], off offset:896                // 0000004937CC: DC520380 227C0004
	global_load_b32 v121, v[6:7], off                          // 0000004937D4: DC520000 797C0006
	global_load_b32 v120, v[6:7], off offset:128               // 0000004937DC: DC520080 787C0006
	global_load_b32 v119, v[6:7], off offset:256               // 0000004937E4: DC520100 777C0006
	global_load_b32 v118, v[6:7], off offset:384               // 0000004937EC: DC520180 767C0006
	global_load_b32 v117, v[6:7], off offset:512               // 0000004937F4: DC520200 757C0006
	global_load_b32 v116, v[6:7], off offset:640               // 0000004937FC: DC520280 747C0006
	global_load_b32 v115, v[6:7], off offset:768               // 000000493804: DC520300 737C0006
	global_load_b32 v113, v[6:7], off offset:896               // 00000049380C: DC520380 717C0006
	s_branch 64288                                             // 000000493814: BFA0FB20 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xc98>
	s_or_b32 exec_lo, exec_lo, s5                              // 000000493818: 8C7E057E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000049381C: BF870009
	s_or_b32 exec_lo, exec_lo, s0                              // 000000493820: 8C7E007E
	v_dual_mov_b32 v1, v100 :: v_dual_mov_b32 v4, v90          // 000000493824: CA100164 0104015A
	s_waitcnt vmcnt(15)                                        // 00000049382C: BF893FF7
	v_dual_mov_b32 v2, v96 :: v_dual_mov_b32 v3, v91           // 000000493830: CA100160 0202015B
	v_dual_mov_b32 v5, v93 :: v_dual_mov_b32 v10, v98          // 000000493838: CA10015D 050A0162
	v_dual_mov_b32 v6, v89 :: v_dual_mov_b32 v7, v87           // 000000493840: CA100159 06060157
	v_dual_mov_b32 v8, v85 :: v_dual_mov_b32 v9, v99           // 000000493848: CA100155 08080163
	v_dual_mov_b32 v11, v97 :: v_dual_mov_b32 v12, v95         // 000000493850: CA100161 0B0C015F
	v_dual_mov_b32 v13, v94 :: v_dual_mov_b32 v14, v92         // 000000493858: CA10015E 0D0E015C
	v_dual_mov_b32 v15, v88 :: v_dual_mov_b32 v16, v86         // 000000493860: CA100158 0F100156
	v_dual_mov_b32 v17, v84 :: v_dual_mov_b32 v18, v83         // 000000493868: CA100154 11120153
	v_dual_mov_b32 v19, v82 :: v_dual_mov_b32 v20, v81         // 000000493870: CA100152 13140151
	v_dual_mov_b32 v21, v80 :: v_dual_mov_b32 v22, v79         // 000000493878: CA100150 1516014F
	v_dual_mov_b32 v23, v78 :: v_dual_mov_b32 v24, v77         // 000000493880: CA10014E 1718014D
	s_waitcnt vmcnt(7)                                         // 000000493888: BF891FF7
	v_dual_mov_b32 v25, v76 :: v_dual_mov_b32 v26, v75         // 00000049388C: CA10014C 191A014B
	v_dual_mov_b32 v27, v74 :: v_dual_mov_b32 v28, v73         // 000000493894: CA10014A 1B1C0149
	v_dual_mov_b32 v29, v72 :: v_dual_mov_b32 v30, v71         // 00000049389C: CA100148 1D1E0147
	v_dual_mov_b32 v31, v70 :: v_dual_mov_b32 v32, v69         // 0000004938A4: CA100146 1F200145
	v_dual_mov_b32 v33, v68 :: v_dual_mov_b32 v34, v67         // 0000004938AC: CA100144 21220143
	v_dual_mov_b32 v101, v66 :: v_dual_mov_b32 v102, v65       // 0000004938B4: CA100142 65660141
	v_dual_mov_b32 v103, v64 :: v_dual_mov_b32 v104, v63       // 0000004938BC: CA100140 6768013F
	s_waitcnt vmcnt(0)                                         // 0000004938C4: BF8903F7
	v_dual_mov_b32 v105, v62 :: v_dual_mov_b32 v106, v61       // 0000004938C8: CA10013E 696A013D
	v_dual_mov_b32 v107, v60 :: v_dual_mov_b32 v108, v59       // 0000004938D0: CA10013C 6B6C013B
	v_dual_mov_b32 v109, v58 :: v_dual_mov_b32 v110, v57       // 0000004938D8: CA10013A 6D6E0139
	v_dual_mov_b32 v111, v56 :: v_dual_mov_b32 v112, v55       // 0000004938E0: CA100138 6F700137
	v_dual_mov_b32 v113, v54 :: v_dual_mov_b32 v114, v53       // 0000004938E8: CA100136 71720135
	v_dual_mov_b32 v115, v52 :: v_dual_mov_b32 v116, v51       // 0000004938F0: CA100134 73740133
	v_dual_mov_b32 v117, v50 :: v_dual_mov_b32 v118, v49       // 0000004938F8: CA100132 75760131
	v_dual_mov_b32 v119, v48 :: v_dual_mov_b32 v120, v47       // 000000493900: CA100130 7778012F
	v_dual_mov_b32 v121, v46 :: v_dual_mov_b32 v122, v45       // 000000493908: CA10012E 797A012D
	v_dual_mov_b32 v123, v44 :: v_dual_mov_b32 v124, v43       // 000000493910: CA10012C 7B7C012B
	v_dual_mov_b32 v125, v42 :: v_dual_mov_b32 v126, v41       // 000000493918: CA10012A 7D7E0129
	v_dual_mov_b32 v127, v40 :: v_dual_mov_b32 v128, v39       // 000000493920: CA100128 7F800127
	v_dual_mov_b32 v129, v38 :: v_dual_mov_b32 v130, v37       // 000000493928: CA100126 81820125
	s_mov_b32 s0, 0x76543210                                   // 000000493930: BE8000FF 76543210
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000493938: BF870009
	v_permlanex16_b32 v1, v1, s0, 0xfedcba98                   // 00000049393C: D65C0001 03FC0101 FEDCBA98
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 000000493948: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 000000493954: D65C0003 03FC0103 FEDCBA98
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 000000493960: D65C0004 03FC0104 FEDCBA98
	v_permlanex16_b32 v5, v5, s0, 0xfedcba98                   // 00000049396C: D65C0005 03FC0105 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 000000493978: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v7, v7, s0, 0xfedcba98                   // 000000493984: D65C0007 03FC0107 FEDCBA98
	v_permlanex16_b32 v8, v8, s0, 0xfedcba98                   // 000000493990: D65C0008 03FC0108 FEDCBA98
	v_permlanex16_b32 v9, v9, s0, 0xfedcba98                   // 00000049399C: D65C0009 03FC0109 FEDCBA98
	v_permlanex16_b32 v10, v10, s0, 0xfedcba98                 // 0000004939A8: D65C000A 03FC010A FEDCBA98
	v_permlanex16_b32 v11, v11, s0, 0xfedcba98                 // 0000004939B4: D65C000B 03FC010B FEDCBA98
	v_permlanex16_b32 v12, v12, s0, 0xfedcba98                 // 0000004939C0: D65C000C 03FC010C FEDCBA98
	v_permlanex16_b32 v13, v13, s0, 0xfedcba98                 // 0000004939CC: D65C000D 03FC010D FEDCBA98
	v_permlanex16_b32 v14, v14, s0, 0xfedcba98                 // 0000004939D8: D65C000E 03FC010E FEDCBA98
	v_permlanex16_b32 v15, v15, s0, 0xfedcba98                 // 0000004939E4: D65C000F 03FC010F FEDCBA98
	v_permlanex16_b32 v16, v16, s0, 0xfedcba98                 // 0000004939F0: D65C0010 03FC0110 FEDCBA98
	v_permlanex16_b32 v17, v17, s0, 0xfedcba98                 // 0000004939FC: D65C0011 03FC0111 FEDCBA98
	v_permlanex16_b32 v18, v18, s0, 0xfedcba98                 // 000000493A08: D65C0012 03FC0112 FEDCBA98
	v_permlanex16_b32 v19, v19, s0, 0xfedcba98                 // 000000493A14: D65C0013 03FC0113 FEDCBA98
	v_permlanex16_b32 v20, v20, s0, 0xfedcba98                 // 000000493A20: D65C0014 03FC0114 FEDCBA98
	v_permlanex16_b32 v21, v21, s0, 0xfedcba98                 // 000000493A2C: D65C0015 03FC0115 FEDCBA98
	v_permlanex16_b32 v22, v22, s0, 0xfedcba98                 // 000000493A38: D65C0016 03FC0116 FEDCBA98
	v_permlanex16_b32 v23, v23, s0, 0xfedcba98                 // 000000493A44: D65C0017 03FC0117 FEDCBA98
	v_permlanex16_b32 v24, v24, s0, 0xfedcba98                 // 000000493A50: D65C0018 03FC0118 FEDCBA98
	v_permlanex16_b32 v25, v25, s0, 0xfedcba98                 // 000000493A5C: D65C0019 03FC0119 FEDCBA98
	v_permlanex16_b32 v26, v26, s0, 0xfedcba98                 // 000000493A68: D65C001A 03FC011A FEDCBA98
	v_permlanex16_b32 v27, v27, s0, 0xfedcba98                 // 000000493A74: D65C001B 03FC011B FEDCBA98
	v_permlanex16_b32 v28, v28, s0, 0xfedcba98                 // 000000493A80: D65C001C 03FC011C FEDCBA98
	v_permlanex16_b32 v29, v29, s0, 0xfedcba98                 // 000000493A8C: D65C001D 03FC011D FEDCBA98
	v_permlanex16_b32 v30, v30, s0, 0xfedcba98                 // 000000493A98: D65C001E 03FC011E FEDCBA98
	v_permlanex16_b32 v31, v31, s0, 0xfedcba98                 // 000000493AA4: D65C001F 03FC011F FEDCBA98
	v_permlanex16_b32 v32, v32, s0, 0xfedcba98                 // 000000493AB0: D65C0020 03FC0120 FEDCBA98
	v_permlanex16_b32 v33, v33, s0, 0xfedcba98                 // 000000493ABC: D65C0021 03FC0121 FEDCBA98
	v_permlanex16_b32 v34, v34, s0, 0xfedcba98                 // 000000493AC8: D65C0022 03FC0122 FEDCBA98
	v_permlanex16_b32 v101, v101, s0, 0xfedcba98               // 000000493AD4: D65C0065 03FC0165 FEDCBA98
	v_permlanex16_b32 v102, v102, s0, 0xfedcba98               // 000000493AE0: D65C0066 03FC0166 FEDCBA98
	v_permlanex16_b32 v103, v103, s0, 0xfedcba98               // 000000493AEC: D65C0067 03FC0167 FEDCBA98
	v_permlanex16_b32 v104, v104, s0, 0xfedcba98               // 000000493AF8: D65C0068 03FC0168 FEDCBA98
	v_permlanex16_b32 v105, v105, s0, 0xfedcba98               // 000000493B04: D65C0069 03FC0169 FEDCBA98
	v_permlanex16_b32 v106, v106, s0, 0xfedcba98               // 000000493B10: D65C006A 03FC016A FEDCBA98
	v_permlanex16_b32 v107, v107, s0, 0xfedcba98               // 000000493B1C: D65C006B 03FC016B FEDCBA98
	v_permlanex16_b32 v108, v108, s0, 0xfedcba98               // 000000493B28: D65C006C 03FC016C FEDCBA98
	v_permlanex16_b32 v109, v109, s0, 0xfedcba98               // 000000493B34: D65C006D 03FC016D FEDCBA98
	v_permlanex16_b32 v110, v110, s0, 0xfedcba98               // 000000493B40: D65C006E 03FC016E FEDCBA98
	v_permlanex16_b32 v111, v111, s0, 0xfedcba98               // 000000493B4C: D65C006F 03FC016F FEDCBA98
	v_permlanex16_b32 v112, v112, s0, 0xfedcba98               // 000000493B58: D65C0070 03FC0170 FEDCBA98
	v_permlanex16_b32 v113, v113, s0, 0xfedcba98               // 000000493B64: D65C0071 03FC0171 FEDCBA98
	v_permlanex16_b32 v114, v114, s0, 0xfedcba98               // 000000493B70: D65C0072 03FC0172 FEDCBA98
	v_permlanex16_b32 v115, v115, s0, 0xfedcba98               // 000000493B7C: D65C0073 03FC0173 FEDCBA98
	v_permlanex16_b32 v116, v116, s0, 0xfedcba98               // 000000493B88: D65C0074 03FC0174 FEDCBA98
	v_permlanex16_b32 v117, v117, s0, 0xfedcba98               // 000000493B94: D65C0075 03FC0175 FEDCBA98
	v_permlanex16_b32 v118, v118, s0, 0xfedcba98               // 000000493BA0: D65C0076 03FC0176 FEDCBA98
	v_permlanex16_b32 v119, v119, s0, 0xfedcba98               // 000000493BAC: D65C0077 03FC0177 FEDCBA98
	v_permlanex16_b32 v120, v120, s0, 0xfedcba98               // 000000493BB8: D65C0078 03FC0178 FEDCBA98
	v_permlanex16_b32 v121, v121, s0, 0xfedcba98               // 000000493BC4: D65C0079 03FC0179 FEDCBA98
	v_permlanex16_b32 v122, v122, s0, 0xfedcba98               // 000000493BD0: D65C007A 03FC017A FEDCBA98
	v_permlanex16_b32 v123, v123, s0, 0xfedcba98               // 000000493BDC: D65C007B 03FC017B FEDCBA98
	v_permlanex16_b32 v124, v124, s0, 0xfedcba98               // 000000493BE8: D65C007C 03FC017C FEDCBA98
	v_permlanex16_b32 v125, v125, s0, 0xfedcba98               // 000000493BF4: D65C007D 03FC017D FEDCBA98
	v_permlanex16_b32 v126, v126, s0, 0xfedcba98               // 000000493C00: D65C007E 03FC017E FEDCBA98
	v_permlanex16_b32 v127, v127, s0, 0xfedcba98               // 000000493C0C: D65C007F 03FC017F FEDCBA98
	v_permlanex16_b32 v128, v128, s0, 0xfedcba98               // 000000493C18: D65C0080 03FC0180 FEDCBA98
	v_permlanex16_b32 v129, v129, s0, 0xfedcba98               // 000000493C24: D65C0081 03FC0181 FEDCBA98
	v_permlanex16_b32 v130, v130, s0, 0xfedcba98               // 000000493C30: D65C0082 03FC0182 FEDCBA98
	.long 0xd44c0000                                           // 000000493C3C: D44C0000
	v_cndmask_b32_e32 v1, 16, v36, vcc_lo                      // 000000493C40: 02024890
	s_barrier                                                  // 000000493C44: BFBD0000
	buffer_gl0_inv                                             // 000000493C48: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 000000493C50: BE812000
	s_cbranch_execz 138                                        // 000000493C54: BFA5008A <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2680>
	v_dual_add_f32 v7, v87, v7 :: v_dual_lshlrev_b32 v36, 2, v36// 000000493C58: C9220F57 07244882
	v_dual_add_f32 v10, v98, v10 :: v_dual_add_f32 v9, v99, v9 // 000000493C60: C9081562 0A081363
	v_dual_add_f32 v8, v85, v8 :: v_dual_add_f32 v1, v100, v1  // 000000493C68: C9081155 08000364
	s_delay_alu instid0(VALU_DEP_3)                            // 000000493C70: BF870003
	v_lshl_or_b32 v36, v35, 12, v36                            // 000000493C74: D6560024 04911923
	v_add_f32_e32 v2, v96, v2                                  // 000000493C7C: 06040560
	v_dual_add_f32 v34, v67, v34 :: v_dual_add_f32 v33, v68, v33// 000000493C80: C9084543 22204344
	v_dual_add_f32 v12, v95, v12 :: v_dual_add_f32 v11, v97, v11// 000000493C88: C908195F 0C0A1761
	v_dual_add_f32 v6, v89, v6 :: v_dual_add_f32 v3, v91, v3   // 000000493C90: C9080D59 0602075B
	v_add_nc_u32_e32 v67, 0x400, v36                           // 000000493C98: 4A8648FF 00000400
	v_dual_add_f32 v5, v93, v5 :: v_dual_add_f32 v4, v90, v4   // 000000493CA0: C9080B5D 0504095A
	v_dual_add_f32 v14, v92, v14 :: v_dual_add_f32 v13, v94, v13// 000000493CA8: C9081D5C 0E0C1B5E
	ds_store_2addr_b32 v36, v1, v9 offset1:16                  // 000000493CB0: D8381000 00090124
	v_add_nc_u32_e32 v1, 0x800, v36                            // 000000493CB8: 4A0248FF 00000800
	v_dual_add_f32 v16, v86, v16 :: v_dual_add_f32 v15, v88, v15// 000000493CC0: C9082156 100E1F58
	ds_store_2addr_b32 v36, v2, v10 offset0:128 offset1:144    // 000000493CC8: D8389080 000A0224
	v_dual_add_f32 v37, v37, v130 :: v_dual_add_nc_u32 v2, 0xc00, v36// 000000493CD0: C9210525 250248FF 00000C00
	v_dual_add_f32 v38, v38, v129 :: v_dual_add_f32 v39, v39, v128// 000000493CDC: C9090326 26270127
	v_dual_add_f32 v40, v40, v127 :: v_dual_add_f32 v41, v41, v126// 000000493CE4: C908FF28 2828FD29
	v_dual_add_f32 v42, v42, v125 :: v_dual_add_f32 v43, v43, v124// 000000493CEC: C908FB2A 2A2AF92B
	v_dual_add_f32 v44, v44, v123 :: v_dual_add_f32 v45, v45, v122// 000000493CF4: C908F72C 2C2CF52D
	v_dual_add_f32 v46, v46, v121 :: v_dual_add_f32 v47, v47, v120// 000000493CFC: C908F32E 2E2EF12F
	v_dual_add_f32 v48, v48, v119 :: v_dual_add_f32 v49, v49, v118// 000000493D04: C908EF30 3030ED31
	v_dual_add_f32 v50, v50, v117 :: v_dual_add_f32 v51, v51, v116// 000000493D0C: C908EB32 3232E933
	v_dual_add_f32 v52, v52, v115 :: v_dual_add_f32 v53, v53, v114// 000000493D14: C908E734 3434E535
	v_dual_add_f32 v54, v54, v113 :: v_dual_add_f32 v55, v55, v112// 000000493D1C: C908E336 3636E137
	v_dual_add_f32 v56, v56, v111 :: v_dual_add_f32 v57, v57, v110// 000000493D24: C908DF38 3838DD39
	v_dual_add_f32 v58, v58, v109 :: v_dual_add_f32 v59, v59, v108// 000000493D2C: C908DB3A 3A3AD93B
	v_dual_add_f32 v60, v60, v107 :: v_dual_add_f32 v61, v61, v106// 000000493D34: C908D73C 3C3CD53D
	v_dual_add_f32 v62, v62, v105 :: v_dual_add_f32 v63, v63, v104// 000000493D3C: C908D33E 3E3ED13F
	v_dual_add_f32 v64, v64, v103 :: v_dual_add_f32 v65, v65, v102// 000000493D44: C908CF40 4040CD41
	v_add_f32_e32 v66, v66, v101                               // 000000493D4C: 0684CB42
	v_dual_add_f32 v32, v69, v32 :: v_dual_add_f32 v31, v70, v31// 000000493D50: C9084145 201E3F46
	v_dual_add_f32 v30, v71, v30 :: v_dual_add_f32 v29, v72, v29// 000000493D58: C9083D47 1E1C3B48
	v_dual_add_f32 v28, v73, v28 :: v_dual_add_f32 v27, v74, v27// 000000493D60: C9083949 1C1A374A
	v_dual_add_f32 v26, v75, v26 :: v_dual_add_f32 v25, v76, v25// 000000493D68: C908354B 1A18334C
	v_dual_add_f32 v24, v77, v24 :: v_dual_add_f32 v23, v78, v23// 000000493D70: C908314D 18162F4E
	v_dual_add_f32 v22, v79, v22 :: v_dual_add_f32 v21, v80, v21// 000000493D78: C9082D4F 16142B50
	v_dual_add_f32 v20, v81, v20 :: v_dual_add_f32 v19, v82, v19// 000000493D80: C9082951 14122752
	v_dual_add_f32 v18, v83, v18 :: v_dual_add_f32 v17, v84, v17// 000000493D88: C9082553 12102354
	ds_store_2addr_b32 v67, v3, v11 offset1:16                 // 000000493D90: D8381000 000B0343
	ds_store_2addr_b32 v67, v4, v12 offset0:128 offset1:144    // 000000493D98: D8389080 000C0443
	ds_store_2addr_b32 v1, v5, v13 offset1:16                  // 000000493DA0: D8381000 000D0501
	ds_store_2addr_b32 v1, v6, v14 offset0:128 offset1:144     // 000000493DA8: D8389080 000E0601
	ds_store_2addr_b32 v2, v7, v15 offset1:16                  // 000000493DB0: D8381000 000F0702
	ds_store_2addr_b32 v2, v8, v16 offset0:128 offset1:144     // 000000493DB8: D8389080 00100802
	ds_store_2addr_b32 v36, v17, v25 offset0:32 offset1:48     // 000000493DC0: D8383020 00191124
	ds_store_2addr_b32 v36, v18, v26 offset0:160 offset1:176   // 000000493DC8: D838B0A0 001A1224
	ds_store_2addr_b32 v67, v19, v27 offset0:32 offset1:48     // 000000493DD0: D8383020 001B1343
	ds_store_2addr_b32 v67, v20, v28 offset0:160 offset1:176   // 000000493DD8: D838B0A0 001C1443
	ds_store_2addr_b32 v1, v21, v29 offset0:32 offset1:48      // 000000493DE0: D8383020 001D1501
	ds_store_2addr_b32 v1, v22, v30 offset0:160 offset1:176    // 000000493DE8: D838B0A0 001E1601
	ds_store_2addr_b32 v2, v23, v31 offset0:32 offset1:48      // 000000493DF0: D8383020 001F1702
	ds_store_2addr_b32 v2, v24, v32 offset0:160 offset1:176    // 000000493DF8: D838B0A0 00201802
	ds_store_2addr_b32 v36, v33, v60 offset0:64 offset1:80     // 000000493E00: D8385040 003C2124
	ds_store_2addr_b32 v36, v34, v59 offset0:192 offset1:208   // 000000493E08: D838D0C0 003B2224
	ds_store_2addr_b32 v67, v66, v58 offset0:64 offset1:80     // 000000493E10: D8385040 003A4243
	ds_store_2addr_b32 v67, v65, v57 offset0:192 offset1:208   // 000000493E18: D838D0C0 00394143
	ds_store_2addr_b32 v1, v64, v56 offset0:64 offset1:80      // 000000493E20: D8385040 00384001
	ds_store_2addr_b32 v1, v63, v55 offset0:192 offset1:208    // 000000493E28: D838D0C0 00373F01
	ds_store_2addr_b32 v2, v62, v54 offset0:64 offset1:80      // 000000493E30: D8385040 00363E02
	ds_store_2addr_b32 v2, v61, v53 offset0:192 offset1:208    // 000000493E38: D838D0C0 00353D02
	ds_store_2addr_b32 v36, v52, v44 offset0:96 offset1:112    // 000000493E40: D8387060 002C3424
	ds_store_2addr_b32 v36, v51, v43 offset0:224 offset1:240   // 000000493E48: D838F0E0 002B3324
	ds_store_2addr_b32 v67, v50, v42 offset0:96 offset1:112    // 000000493E50: D8387060 002A3243
	ds_store_2addr_b32 v67, v49, v41 offset0:224 offset1:240   // 000000493E58: D838F0E0 00293143
	ds_store_2addr_b32 v1, v48, v40 offset0:96 offset1:112     // 000000493E60: D8387060 00283001
	ds_store_2addr_b32 v1, v47, v39 offset0:224 offset1:240    // 000000493E68: D838F0E0 00272F01
	ds_store_2addr_b32 v2, v46, v38 offset0:96 offset1:112     // 000000493E70: D8387060 00262E02
	ds_store_2addr_b32 v2, v45, v37 offset0:224 offset1:240    // 000000493E78: D838F0E0 00252D02
	s_or_b32 exec_lo, exec_lo, s1                              // 000000493E80: 8C7E017E
	v_mov_b32_e32 v1, v0                                       // 000000493E84: 7E020300
	s_mov_b32 s1, 0                                            // 000000493E88: BE810080
	s_waitcnt lgkmcnt(0)                                       // 000000493E8C: BF89FC07
	s_barrier                                                  // 000000493E90: BFBD0000
	buffer_gl0_inv                                             // 000000493E94: E0AC0000 00000000
	s_nop 0                                                    // 000000493E9C: BF800000
	s_nop 0                                                    // 000000493EA0: BF800000
	s_nop 0                                                    // 000000493EA4: BF800000
	s_nop 0                                                    // 000000493EA8: BF800000
	s_nop 0                                                    // 000000493EAC: BF800000
	s_nop 0                                                    // 000000493EB0: BF800000
	s_nop 0                                                    // 000000493EB4: BF800000
	s_nop 0                                                    // 000000493EB8: BF800000
	s_nop 0                                                    // 000000493EBC: BF800000
	v_lshlrev_b32_e32 v8, 2, v1                                // 000000493EC0: 30100282
	v_cmp_lt_u32_e32 vcc_lo, 0x2ff, v1                         // 000000493EC4: 7C9202FF 000002FF
	ds_load_2addr_stride64_b32 v[2:3], v8 offset1:16           // 000000493ECC: D8E01000 02000008
	ds_load_2addr_stride64_b32 v[4:5], v8 offset0:32 offset1:48// 000000493ED4: D8E03020 04000008
	ds_load_2addr_stride64_b32 v[6:7], v8 offset0:64 offset1:80// 000000493EDC: D8E05040 06000008
	s_or_b32 s1, vcc_lo, s1                                    // 000000493EE4: 8C01016A
	s_waitcnt lgkmcnt(2)                                       // 000000493EE8: BF89FC27
	v_add_f32_e32 v2, 0, v2                                    // 000000493EEC: 06040480
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000493EF0: BF8700C1
	v_add_f32_e32 v9, v2, v3                                   // 000000493EF4: 06120702
	ds_load_2addr_stride64_b32 v[2:3], v8 offset0:96 offset1:112// 000000493EF8: D8E07060 02000008
	s_waitcnt lgkmcnt(2)                                       // 000000493F00: BF89FC27
	v_add_f32_e32 v4, v9, v4                                   // 000000493F04: 06080909
	v_add_f32_e32 v4, v4, v5                                   // 000000493F08: 06080B04
	s_waitcnt lgkmcnt(1)                                       // 000000493F0C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000493F10: BF870091
	v_add_f32_e32 v4, v4, v6                                   // 000000493F14: 06080D04
	v_add_f32_e32 v4, v4, v7                                   // 000000493F18: 06080F04
	s_waitcnt lgkmcnt(0)                                       // 000000493F1C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000493F20: BF8700A1
	v_add_f32_e32 v2, v4, v2                                   // 000000493F24: 06040504
	v_add_nc_u32_e32 v4, 0x100, v1                             // 000000493F28: 4A0802FF 00000100
	v_dual_add_f32 v2, v2, v3 :: v_dual_mov_b32 v1, v4         // 000000493F30: C9100702 02000104
	ds_store_b32 v8, v2 offset:32768                           // 000000493F38: D8348000 00000208
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 000000493F40: 917E017E
	s_cbranch_execnz 65502                                     // 000000493F44: BFA6FFDE <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x26c0>
	s_or_b32 exec_lo, exec_lo, s1                              // 000000493F48: 8C7E017E
	s_cmp_lt_i32 s33, 2                                        // 000000493F4C: BF048221
	s_mov_b32 s1, -1                                           // 000000493F50: BE8100C1
	s_cbranch_scc1 197                                         // 000000493F54: BFA200C5 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2a6c>
	v_dual_mov_b32 v4, v0 :: v_dual_and_b32 v1, 0x7f, v0       // 000000493F58: CA240100 040000FF 0000007F
	s_lshl_b32 s4, s2, 7                                       // 000000493F64: 84048702
	s_ashr_i32 s11, s10, 31                                    // 000000493F68: 860B9F0A
	s_ashr_i32 s5, s4, 31                                      // 000000493F6C: 86059F04
	s_delay_alu instid0(VALU_DEP_1)                            // 000000493F70: BF870001
	v_lshlrev_b32_e32 v2, 2, v1                                // 000000493F74: 30040282
	s_lshl_b64 s[4:5], s[4:5], 2                               // 000000493F78: 84848204
	s_lshl_b64 s[6:7], s[10:11], 3                             // 000000493F7C: 8486830A
	s_ashr_i32 s19, s18, 31                                    // 000000493F80: 86139F12
	s_add_u32 s1, s24, s4                                      // 000000493F84: 80010418
	s_addc_u32 s8, s25, s5                                     // 000000493F88: 82080519
	.long 0xd7000102                                           // 000000493F8C: D7000102
	v_cndmask_b32_e32 v1, s1, v2, vcc_lo                       // 000000493F90: 02020401
	s_delay_alu instid0(VALU_DEP_1)                            // 000000493F94: BF870001
	v_add_co_ci_u32_e64 v3, null, s8, 0, s1                    // 000000493F98: D5207C03 00050008
	s_mov_b32 s8, 0                                            // 000000493FA0: BE880080
	s_waitcnt lgkmcnt(0)                                       // 000000493FA4: BF89FC07
	s_barrier                                                  // 000000493FA8: BFBD0000
	buffer_gl0_inv                                             // 000000493FAC: E0AC0000 00000000
	s_nop 0                                                    // 000000493FB4: BF800000
	s_nop 0                                                    // 000000493FB8: BF800000
	s_nop 0                                                    // 000000493FBC: BF800000
	v_lshrrev_b32_e32 v5, 7, v4                                // 000000493FC0: 320A0887
	v_cmp_lt_u32_e32 vcc_lo, 0x2ff, v4                         // 000000493FC4: 7C9208FF 000002FF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000493FCC: BF870092
	.long 0xd7000105                                           // 000000493FD0: D7000105
	v_cndmask_b32_e32 v1, s6, v5, vcc_lo                       // 000000493FD4: 02020A06
	v_add_co_ci_u32_e64 v6, null, s7, 0, s1                    // 000000493FD8: D5207C06 00050007
	s_or_b32 s8, vcc_lo, s8                                    // 000000493FE0: 8C08086A
	.long 0xd72c0009                                           // 000000493FE4: D72C0009
	v_cndmask_b32_e32 v0, v5, v19, vcc_lo                      // 000000493FE8: 02002705
	.long 0xd72c0008                                           // 000000493FEC: D72C0008
	v_cndmask_b32_e32 v0, v6, v18, vcc_lo                      // 000000493FF0: 02002506
	v_mad_u64_u32 v[5:6], null, v5, s18, 0                     // 000000493FF4: D6FE7C05 02002505
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000493FFC: BF8701B1
	v_add3_u32 v6, v6, v9, v8                                  // 000000494000: D6550006 04221306
	v_add_nc_u32_e32 v8, 0x100, v4                             // 000000494008: 4A1008FF 00000100
	v_lshlrev_b32_e32 v7, 2, v4                                // 000000494010: 300E0882
	.long 0xd73c0005                                           // 000000494014: D73C0005
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 000000494018: 02020A82
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000049401C: BF8700B3
	v_mov_b32_e32 v4, v8                                       // 000000494020: 7E080308
	ds_load_b32 v7, v7 offset:32768                            // 000000494024: D8D88000 07000007
	.long 0xd7000105                                           // 00000049402C: D7000105
	v_cndmask_b32_e32 v1, v2, v5, vcc_lo                       // 000000494030: 02020B02
	v_add_co_ci_u32_e64 v6, null, v3, v6, s1                   // 000000494034: D5207C06 00060D03
	s_waitcnt lgkmcnt(0)                                       // 00000049403C: BF89FC07
	global_store_b32 v[5:6], v7, off                           // 000000494040: DC6A0000 007C0705
	s_and_not1_b32 exec_lo, exec_lo, s8                        // 000000494048: 917E087E
	s_cbranch_execnz 65500                                     // 00000049404C: BFA6FFDC <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x27c0>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000494050: 8C7E087E
	.long 0xd44a0001                                           // 000000494054: D44A0001
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 000000494058: 02020080
	s_waitcnt_vscnt null, 0x0                                  // 00000049405C: BC7C0000
	buffer_gl1_inv                                             // 000000494060: E0B00000 00000000
	buffer_gl0_inv                                             // 000000494068: E0AC0000 00000000
	s_barrier                                                  // 000000494070: BFBD0000
	buffer_gl0_inv                                             // 000000494074: E0AC0000 00000000
	s_and_saveexec_b32 s6, s1                                  // 00000049407C: BE862001
	s_cbranch_execz 29                                         // 000000494080: BFA5001D <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x28f8>
	s_mov_b32 s8, exec_lo                                      // 000000494084: BE88007E
	s_mov_b32 s7, exec_lo                                      // 000000494088: BE87007E
	.long 0xd71f0002                                           // 00000049408C: D71F0002
	v_cndmask_b32_e32 v0, s8, v128, vcc_lo                     // 000000494090: 02010008
	s_delay_alu instid0(VALU_DEP_1)                            // 000000494094: BF870001
	v_cmpx_eq_u32_e32 0, v2                                    // 000000494098: 7D940480
	s_cbranch_execz 9                                          // 00000049409C: BFA50009 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x28c4>
	s_lshl_b64 s[10:11], s[2:3], 2                             // 0000004940A0: 848A8202
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000004940A4: BF8704B9
	s_add_u32 s10, s26, s10                                    // 0000004940A8: 800A0A1A
	s_addc_u32 s11, s27, s11                                   // 0000004940AC: 820B0B1B
	s_bcnt1_i32_b32 s8, s8                                     // 0000004940B0: BE881808
	v_dual_mov_b32 v3, 0 :: v_dual_mov_b32 v4, s8              // 0000004940B4: CA100080 03040008
	global_atomic_add_u32 v3, v3, v4, s[10:11] glc             // 0000004940BC: DCD64000 030A0403
	s_or_b32 exec_lo, exec_lo, s7                              // 0000004940C4: 8C7E077E
	s_waitcnt vmcnt(0)                                         // 0000004940C8: BF8903F7
	v_readfirstlane_b32 s7, v3                                 // 0000004940CC: 7E0E0503
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004940D0: BF870001
	v_dual_mov_b32 v3, 0 :: v_dual_add_nc_u32 v2, s7, v2       // 0000004940D4: CA200080 03020407
	s_add_i32 s7, s33, -1                                      // 0000004940DC: 8107C121
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000004940E0: BF870481
	v_cmp_eq_u32_e32 vcc_lo, s7, v2                            // 0000004940E4: 7C940407
	v_cndmask_b32_e64 v2, 0, 1, vcc_lo                         // 0000004940E8: D5010002 01A90280
	ds_store_b32 v3, v2 offset:40960                           // 0000004940F0: D834A000 00000203
	s_or_b32 exec_lo, exec_lo, s6                              // 0000004940F8: 8C7E067E
	v_mov_b32_e32 v2, 0                                        // 0000004940FC: 7E040280
	s_waitcnt lgkmcnt(0)                                       // 000000494100: BF89FC07
	s_barrier                                                  // 000000494104: BFBD0000
	buffer_gl0_inv                                             // 000000494108: E0AC0000 00000000
	s_mov_b32 s10, 0                                           // 000000494110: BE8A0080
	ds_load_b32 v2, v2 offset:40960                            // 000000494114: D8D8A000 02000002
	s_waitcnt lgkmcnt(0)                                       // 00000049411C: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v2                             // 000000494120: 7C940480
	s_cbranch_vccnz 465                                        // 000000494124: BFA401D1 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x306c>
	v_lshrrev_b32_e32 v2, 7, v0                                // 000000494128: 32040087
	v_lshlrev_b32_e32 v1, 2, v1                                // 00000049412C: 30020282
	v_mov_b32_e32 v5, v0                                       // 000000494130: 7E0A0300
	s_lshl_b64 s[6:7], s[18:19], 3                             // 000000494134: 84868312
	s_lshl_b64 s[8:9], s[18:19], 5                             // 000000494138: 84888512
	v_mad_i64_i32 v[2:3], null, v2, s18, 0                     // 00000049413C: D6FF7C02 02002502
	buffer_gl1_inv                                             // 000000494144: E0B00000 00000000
	buffer_gl0_inv                                             // 00000049414C: E0AC0000 00000000
	.long 0xd73c0002                                           // 000000494154: D73C0002
	v_cndmask_b32_e32 v1, 2, v2, vcc_lo                        // 000000494158: 02020482
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000049415C: BF870091
	.long 0xd7006a02                                           // 000000494160: D7006A02
	v_cndmask_b32_e32 v0, v2, v4, vcc_lo                       // 000000494164: 02000902
	v_add_co_ci_u32_e64 v3, null, s5, v3, vcc_lo               // 000000494168: D5207C03 01AA0605
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000494170: BF870092
	.long 0xd7006a01                                           // 000000494174: D7006A01
	v_cndmask_b32_e32 v1, v2, v1, vcc_lo                       // 000000494178: 02020302
	v_add_co_ci_u32_e64 v2, null, 0, v3, vcc_lo                // 00000049417C: D5207C02 01AA0680
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000494184: BF870092
	.long 0xd7006a01                                           // 000000494188: D7006A01
	v_cndmask_b32_e32 v1, s24, v1, vcc_lo                      // 00000049418C: 02020218
	v_add_co_ci_u32_e64 v2, null, s25, v2, vcc_lo              // 000000494190: D5207C02 01AA0419
	s_nop 0                                                    // 000000494198: BF800000
	s_nop 0                                                    // 00000049419C: BF800000
	s_nop 0                                                    // 0000004941A0: BF800000
	s_nop 0                                                    // 0000004941A4: BF800000
	s_nop 0                                                    // 0000004941A8: BF800000
	s_nop 0                                                    // 0000004941AC: BF800000
	s_nop 0                                                    // 0000004941B0: BF800000
	s_nop 0                                                    // 0000004941B4: BF800000
	s_nop 0                                                    // 0000004941B8: BF800000
	s_nop 0                                                    // 0000004941BC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004941C0: BF870191
	v_mov_b32_e32 v4, v2                                       // 0000004941C4: 7E080302
	v_dual_mov_b32 v6, 0 :: v_dual_mov_b32 v3, v1              // 0000004941C8: CA100080 06020101
	s_mov_b32 s4, s33                                          // 0000004941D0: BE840021
	global_load_b32 v7, v[3:4], off glc                        // 0000004941D4: DC524000 077C0003
	.long 0xd7006a03                                           // 0000004941DC: D7006A03
	v_cndmask_b32_e32 v0, v3, v8, vcc_lo                       // 0000004941E0: 02001103
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000004941E4: BF8704A1
	v_add_co_ci_u32_e64 v4, null, s9, v4, vcc_lo               // 0000004941E8: D5207C04 01AA0809
	s_add_i32 s4, s4, -1                                       // 0000004941F0: 8104C104
	s_cmp_eq_u32 s4, 0                                         // 0000004941F4: BF068004
	s_waitcnt vmcnt(0)                                         // 0000004941F8: BF8903F7
	v_add_f32_e32 v6, v6, v7                                   // 0000004941FC: 060C0F06
	s_cbranch_scc0 65524                                       // 000000494200: BFA1FFF4 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x29d4>
	v_add_nc_u32_e32 v4, 0x100, v5                             // 000000494204: 4A080AFF 00000100
	v_cmp_lt_u32_e32 vcc_lo, 0x2ff, v5                         // 00000049420C: 7C920AFF 000002FF
	.long 0xd7000401                                           // 000000494214: D7000401
	v_cndmask_b32_e32 v0, v1, v6, vcc_lo                       // 000000494218: 02000D01
	v_lshlrev_b32_e32 v3, 2, v5                                // 00000049421C: 30060A82
	v_add_co_ci_u32_e64 v2, null, s7, v2, s4                   // 000000494220: D5207C02 00120407
	v_mov_b32_e32 v5, v4                                       // 000000494228: 7E0A0304
	s_or_b32 s10, vcc_lo, s10                                  // 00000049422C: 8C0A0A6A
	ds_store_b32 v3, v6 offset:32768                           // 000000494230: D8348000 00000603
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 000000494238: 917E0A7E
	s_cbranch_execnz 65504                                     // 00000049423C: BFA6FFE0 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x29c0>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000494240: 8C7E0A7E
	s_and_saveexec_b32 s4, s1                                  // 000000494244: BE842001
	s_cbranch_execz 6                                          // 000000494248: BFA50006 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2a64>
	s_lshl_b64 s[6:7], s[2:3], 2                               // 00000049424C: 84868202
	v_mov_b32_e32 v1, 0                                        // 000000494250: 7E020280
	s_add_u32 s6, s26, s6                                      // 000000494254: 8006061A
	s_addc_u32 s7, s27, s7                                     // 000000494258: 8207071B
	global_store_b32 v1, v1, s[6:7]                            // 00000049425C: DC6A0000 00060101
	s_or_b32 exec_lo, exec_lo, s4                              // 000000494264: 8C7E047E
	s_mov_b32 s1, -1                                           // 000000494268: BE8100C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000049426C: BF870009
	s_and_b32 vcc_lo, exec_lo, s1                              // 000000494270: 8B6A017E
	s_cbranch_vccz 381                                         // 000000494274: BFA3017D <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x306c>
	v_cmp_gt_i32_e32 vcc_lo, s16, v35                          // 000000494278: 7C884610
	.long 0xd44c0001                                           // 00000049427C: D44C0001
	v_cndmask_b32_e32 v1, 0x100, v0, vcc_lo                    // 000000494280: 020200FF 00000100
	s_waitcnt lgkmcnt(0)                                       // 000000494288: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 00000049428C: BC7C0000
	s_barrier                                                  // 000000494290: BFBD0000
	buffer_gl0_inv                                             // 000000494294: E0AC0000 00000000
	s_and_b32 s1, vcc_lo, s1                                   // 00000049429C: 8B01016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000004942A0: BF870009
	s_and_saveexec_b32 s3, s1                                  // 0000004942A4: BE832001
	s_cbranch_execz 368                                        // 0000004942A8: BFA50170 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x306c>
	v_and_b32_e32 v1, 15, v0                                   // 0000004942AC: 3602008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004942B0: BF870091
	v_lshlrev_b32_e32 v2, 2, v1                                // 0000004942B4: 30040282
	v_lshl_or_b32 v2, v35, 9, v2                               // 0000004942B8: D6560002 04091323
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004942C0: BF870001
	v_add_nc_u32_e32 v8, 0x8000, v2                            // 0000004942C4: 4A1004FF 00008000
	ds_load_2addr_b32 v[2:3], v8 offset1:16                    // 0000004942CC: D8DC1000 02000008
	ds_load_2addr_b32 v[4:5], v8 offset0:32 offset1:48         // 0000004942D4: D8DC3020 04000008
	ds_load_2addr_b32 v[6:7], v8 offset0:64 offset1:80         // 0000004942DC: D8DC5040 06000008
	ds_load_2addr_b32 v[8:9], v8 offset0:96 offset1:112        // 0000004942E4: D8DC7060 08000008
	v_and_b32_e32 v10, 1, v0                                   // 0000004942EC: 36140081
	v_and_b32_e32 v11, 2, v0                                   // 0000004942F0: 36160082
	s_waitcnt lgkmcnt(3)                                       // 0000004942F4: BF89FC37
	v_dual_add_f32 v13, v2, v3 :: v_dual_and_b32 v12, 4, v0    // 0000004942F8: C9240702 0D0C0084
	s_waitcnt lgkmcnt(2)                                       // 000000494300: BF89FC27
	v_dual_sub_f32 v2, v2, v3 :: v_dual_add_f32 v3, v4, v5     // 000000494304: C9480702 02020B04
	s_waitcnt lgkmcnt(1)                                       // 00000049430C: BF89FC17
	v_dual_sub_f32 v4, v4, v5 :: v_dual_add_f32 v5, v6, v7     // 000000494310: C9480B04 04040F06
	s_waitcnt lgkmcnt(0)                                       // 000000494318: BF89FC07
	v_dual_sub_f32 v6, v6, v7 :: v_dual_add_f32 v7, v8, v9     // 00000049431C: C9480F06 06061308
	v_dual_sub_f32 v8, v8, v9 :: v_dual_add_f32 v9, v13, v3    // 000000494324: C9481308 0808070D
	v_sub_f32_e32 v3, v13, v3                                  // 00000049432C: 0806070D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000494330: BF870243
	v_dual_add_f32 v13, v2, v4 :: v_dual_add_f32 v14, v5, v7   // 000000494334: C9080902 0D0E0F05
	v_dual_sub_f32 v2, v2, v4 :: v_dual_sub_f32 v5, v5, v7     // 00000049433C: C94A0902 02040F05
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 000000494344: 7C941480
	.long 0xd44a0001                                           // 000000494348: D44A0001
	v_cndmask_b32_e32 v1, 0, v12, vcc_lo                       // 00000049434C: 02021880
	v_dual_add_f32 v7, v9, v14 :: v_dual_add_f32 v4, v6, v8    // 000000494350: C9081D09 07041106
	v_sub_f32_e32 v6, v6, v8                                   // 000000494358: 080C1106
	v_sub_f32_e32 v8, v9, v14                                  // 00000049435C: 08101D09
	s_delay_alu instid0(VALU_DEP_3)                            // 000000494360: BF870003
	v_add_f32_e32 v9, v13, v4                                  // 000000494364: 0612090D
	v_dual_sub_f32 v4, v13, v4 :: v_dual_add_f32 v13, v3, v5   // 000000494368: C948090D 040C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 000000494370: 08060B03
	v_add_f32_e32 v5, v2, v6                                   // 000000494374: 060A0D02
	v_sub_f32_e32 v2, v2, v6                                   // 000000494378: 08040D02
	v_mov_b32_dpp v6, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000049437C: 7E0C02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000494384: D5010007 21AA0F07
	v_mov_b32_dpp v10, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000049438C: 7E1402FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000494394: D5010009 21AA1309
	v_mov_b32_dpp v14, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000049439C: 7E1C02FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 0000004943A4: D501000D 21AA1B0D
	v_mov_b32_dpp v15, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004943AC: 7E1E02FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 0000004943B4: D5010005 21AA0B05
	v_mov_b32_dpp v16, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004943BC: 7E2002FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 0000004943C4: D5010008 21AA1108
	v_mov_b32_dpp v17, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004943CC: 7E2202FA FF016104
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 0000004943D4: D5010004 21AA0904
	v_mov_b32_dpp v18, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004943DC: 7E2402FA FF016103
	v_cndmask_b32_e64 v19, -v3, v3, vcc_lo                     // 0000004943E4: D5010013 21AA0703
	v_cndmask_b32_e64 v21, -v2, v2, vcc_lo                     // 0000004943EC: D5010015 21AA0502
	v_cmp_eq_u32_e32 vcc_lo, 0, v11                            // 0000004943F4: 7C941680
	v_dual_add_f32 v3, v7, v6 :: v_dual_add_f32 v8, v8, v16    // 0000004943F8: C9080D07 03082108
	v_mov_b32_dpp v20, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000494400: 7E2802FA FF016102
	v_dual_add_f32 v2, v9, v10 :: v_dual_add_f32 v9, v4, v17   // 000000494408: C9081509 02082304
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000494410: BF870233
	v_mov_b32_dpp v4, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000494414: 7E0802FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 00000049441C: D5010003 21AA0703
	v_add_f32_e32 v6, v13, v14                                 // 000000494424: 060C1D0D
	v_mov_b32_dpp v7, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000494428: 7E0E02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 000000494430: D5010002 21AA0502
	v_mov_b32_dpp v12, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000494438: 7E1802FA FF016208
	v_add_f32_e32 v3, v3, v4                                   // 000000494440: 06060903
	v_mov_b32_dpp v10, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000494444: 7E1402FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 00000049444C: D5010006 21AA0D06
	v_add_f32_e32 v5, v5, v15                                  // 000000494454: 060A1F05
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000494458: D5010008 21AA1108
	v_add_f32_e32 v13, v21, v20                                // 000000494460: 061A2915
	v_mov_b32_dpp v14, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000494464: 7E1C02FA FF016209
	v_add_f32_e32 v6, v6, v10                                  // 00000049446C: 060C1506
	v_mov_b32_dpp v11, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000494470: 7E1602FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000494478: D5010005 21AA0B05
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000494480: D5010009 21AA1309
	v_add_f32_e32 v8, v8, v12                                  // 000000494488: 06101908
	v_mov_b32_dpp v15, v13 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000049448C: 7E1E02FA FF01620D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 000000494494: D501000D 21AA1B0D
	v_add_f32_e32 v4, v5, v11                                  // 00000049449C: 06081705
	v_mov_b32_dpp v5, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000004944A0: 7E0A02FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 0000004944A8: D5010003 20060703
	v_add_f32_e32 v2, v2, v7                                   // 0000004944B0: 06040F02
	v_mov_b32_dpp v11, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000004944B4: 7E1602FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 0000004944BC: D5010006 20060D06
	v_add_f32_e32 v9, v9, v14                                  // 0000004944C4: 06121D09
	v_add_f32_e32 v3, v3, v5                                   // 0000004944C8: 06060B03
	v_cndmask_b32_e64 v7, -v2, v2, s1                          // 0000004944CC: D5010007 20060502
	v_mov_b32_dpp v2, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000004944D4: 7E0402FA FF016402
	v_add_f32_e32 v6, v6, v11                                  // 0000004944DC: 060C1706
	v_mov_b32_dpp v11, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000004944E0: 7E1602FA FF016408
	v_cndmask_b32_e64 v14, -v8, v8, s1                         // 0000004944E8: D501000E 20061108
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000004944F0: BF870234
	v_add_f32_e32 v7, v7, v2                                   // 0000004944F4: 060E0507
	v_mov_b32_dpp v10, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000004944F8: 7E1402FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000494500: D5010004 20060904
	v_add_f32_e32 v14, v14, v11                                // 000000494508: 061C170E
	v_mov_b32_dpp v2, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000049450C: 7E0402FA FF016803
	v_mov_b32_dpp v5, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000494514: 7E0A02FA FF016807
	v_mov_b32_dpp v8, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000049451C: 7E1002FA FF016806
	v_add_f32_e32 v4, v4, v10                                  // 000000494524: 06081504
	v_add_f32_e32 v10, v19, v18                                // 000000494528: 06142513
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000049452C: BF8700A1
	v_mov_b32_dpp v12, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000494530: 7E1802FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 000000494538: D501000A 21AA150A
	v_add_f32_e32 v10, v10, v12                                // 000000494540: 0614190A
	v_add_f32_e32 v12, v13, v15                                // 000000494544: 06181F0D
	v_mov_b32_dpp v13, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000494548: 7E1A02FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 000000494550: D5010009 20061309
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000494558: BF870214
	v_mov_b32_dpp v15, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000049455C: 7E1E02FA FF01640A
	v_mov_b32_dpp v17, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000494564: 7E2202FA FF01640C
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 00000049456C: D501000A 2006150A
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 000000494574: D501000C 2006190C
	v_add_f32_e32 v16, v9, v13                                 // 00000049457C: 06201B09
	v_mov_b32_dpp v9, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000494580: 7E1202FA FF016804
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000494588: BF870214
	v_add_f32_e32 v15, v10, v15                                // 00000049458C: 061E1F0A
	v_add_f32_e32 v17, v12, v17                                // 000000494590: 0622230C
	v_mov_b32_dpp v10, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000494594: 7E1402FA FF01680E
	v_mov_b32_dpp v11, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000049459C: 7E1602FA FF016810
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004945A4: BF870214
	v_mov_b32_dpp v12, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004945A8: 7E1802FA FF01680F
	v_mov_b32_dpp v13, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004945B0: 7E1A02FA FF016811
	s_and_b32 exec_lo, exec_lo, s0                             // 0000004945B8: 8B7E007E
	s_cbranch_execz 171                                        // 0000004945BC: BFA500AB <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x306c>
	v_lshl_or_b32 v18, s2, 7, v1                               // 0000004945C0: D6560012 04050E02
	.long 0x7f2c3880                                           // 0000004945C8: 7F2C3880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004945CC: BF870112
	v_ashrrev_i32_e32 v19, 31, v18                             // 0000004945D0: 3426249F
	.long 0x7f2e3996                                           // 0000004945D4: 7F2E3996
	.long 0x7f303996                                           // 0000004945D8: 7F303996
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004945DC: BF870093
	.long 0xd73c0012                                           // 0000004945E0: D73C0012
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 0000004945E4: 02022481
	.long 0xd7006a14                                           // 0000004945E8: D7006A14
	v_cndmask_b32_e32 v1, s22, v18, vcc_lo                     // 0000004945EC: 02022416
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004945F0: BF870001
	v_add_co_ci_u32_e64 v21, null, s23, v19, vcc_lo            // 0000004945F4: D5207C15 01AA2617
	s_clause 0x7                                               // 0000004945FC: BF850007
	global_load_d16_b16 v22, v[20:21], off offset:32           // 000000494600: DC820020 167C0014
	global_load_d16_b16 v23, v[20:21], off                     // 000000494608: DC820000 177C0014
	global_load_d16_b16 v24, v[20:21], off offset:64           // 000000494610: DC820040 187C0014
	global_load_d16_b16 v25, v[20:21], off offset:96           // 000000494618: DC820060 197C0014
	global_load_d16_b16 v26, v[20:21], off offset:128          // 000000494620: DC820080 1A7C0014
	global_load_d16_b16 v27, v[20:21], off offset:160          // 000000494628: DC8200A0 1B7C0014
	global_load_d16_b16 v28, v[20:21], off offset:192          // 000000494630: DC8200C0 1C7C0014
	global_load_d16_b16 v20, v[20:21], off offset:224          // 000000494638: DC8200E0 147C0014
	v_and_b32_e32 v21, 8, v0                                   // 000000494640: 362A0088
	v_mad_i64_i32 v[0:1], null, s18, v35, 0                    // 000000494644: D6FF7C00 02024612
	s_waitcnt vmcnt(0)                                         // 00000049464C: BF8903F7
	.long 0x7f283996                                           // 000000494650: 7F283996
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000494654: BF870223
	v_cmp_eq_u32_e32 vcc_lo, 0, v21                            // 000000494658: 7C942A80
	.long 0x7f2a3996                                           // 00000049465C: 7F2A3996
	.long 0xd73c0000                                           // 000000494660: D73C0000
	v_cndmask_b32_e32 v1, 1, v0, vcc_lo                        // 000000494664: 02020081
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000494668: D5010007 21AA0F07
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000494670: D5010003 21AA0703
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000494678: D5010004 21AA0904
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 000000494680: D5010006 21AA0D06
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 000000494688: D501000E 21AA1D0E
	v_add_f32_e32 v5, v7, v5                                   // 000000494690: 060A0B07
	v_cndmask_b32_e64 v7, -v16, v16, vcc_lo                    // 000000494694: D5010007 21AA2110
	v_cndmask_b32_e64 v16, -v17, v17, vcc_lo                   // 00000049469C: D5010010 21AA2311
	v_cndmask_b32_e64 v15, -v15, v15, vcc_lo                   // 0000004946A4: D501000F 21AA1F0F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000004946AC: BF870124
	v_dual_add_f32 v2, v3, v2 :: v_dual_mul_f32 v3, 0x3db504f3, v5// 0000004946B0: C9060503 02020AFF 3DB504F3
	v_dual_add_f32 v5, v6, v8 :: v_dual_add_f32 v4, v4, v9     // 0000004946BC: C9081106 05041304
	v_dual_add_f32 v7, v7, v11 :: v_dual_mul_f32 v2, 0x3db504f3, v2// 0000004946C4: C9061707 070204FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004946D0: BF870194
	v_dual_add_f32 v8, v15, v12 :: v_dual_add_f32 v9, v16, v13 // 0000004946D4: C908190F 08081B10
	v_mul_f32_e32 v4, 0x3db504f3, v4                           // 0000004946DC: 100808FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004946E4: BF870193
	v_dual_add_f32 v6, v14, v10 :: v_dual_mul_f32 v7, 0x3db504f3, v7// 0000004946E8: C906150E 06060EFF 3DB504F3
	v_dual_mul_f32 v8, 0x3db504f3, v8 :: v_dual_mul_f32 v5, 0x3db504f3, v5// 0000004946F4: C8C610FF 08040AFF 3DB504F3
	.long 0xd7006a00                                           // 000000494700: D7006A00
	v_cndmask_b32_e32 v1, s28, v0, vcc_lo                      // 000000494704: 0202001C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000494708: BF8701A3
	v_mul_f32_e32 v6, 0x3db504f3, v6                           // 00000049470C: 100C0CFF 3DB504F3
	v_add_co_ci_u32_e64 v1, null, s29, v1, vcc_lo              // 000000494714: D5207C01 01AA021D
	.long 0xd7006a00                                           // 00000049471C: D7006A00
	v_cndmask_b32_e32 v1, v0, v18, vcc_lo                      // 000000494720: 02022500
	s_delay_alu instid0(VALU_DEP_1)                            // 000000494724: BF870001
	v_add_co_ci_u32_e64 v1, null, v1, v19, vcc_lo              // 000000494728: D5207C01 01AA2701
	v_fma_mix_f32 v3, v22, v3, neg(0) op_sel_hi:[1,0,0]        // 000000494730: CC200003 8A020716
	v_fma_mix_f32 v2, v23, v2, neg(0) op_sel_hi:[1,0,0]        // 000000494738: CC200002 8A020517
	v_fma_mix_f32 v5, v24, v5, neg(0) op_sel_hi:[1,0,0]        // 000000494740: CC200005 8A020B18
	v_fma_mix_f32 v4, v25, v4, neg(0) op_sel_hi:[1,0,0]        // 000000494748: CC200004 8A020919
	v_fma_mix_f32 v6, v26, v6, neg(0) op_sel_hi:[1,0,0]        // 000000494750: CC200006 8A020D1A
	.long 0x7e2c3983                                           // 000000494758: 7E2C3983
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 00000049475C: 101212FF 3DB504F3
	v_fma_mix_f32 v7, v27, v7, neg(0) op_sel_hi:[1,0,0]        // 000000494764: CC200007 8A020F1B
	v_fma_mix_f32 v8, v28, v8, neg(0) op_sel_hi:[1,0,0]        // 00000049476C: CC200008 8A02111C
	.long 0x7e2a3985                                           // 000000494774: 7E2A3985
	v_and_b32_e32 v10, 1, v22                                  // 000000494778: 36142C81
	.long 0x7e2c3984                                           // 00000049477C: 7E2C3984
	v_fma_mix_f32 v9, v20, v9, neg(0) op_sel_hi:[1,0,0]        // 000000494780: CC200009 8A021314
	.long 0x7e283982                                           // 000000494788: 7E283982
	.long 0x7e2e3986                                           // 00000049478C: 7E2E3986
	.long 0x7e303988                                           // 000000494790: 7E303988
	v_and_b32_e32 v11, 1, v22                                  // 000000494794: 36162C81
	.long 0x7e2c3987                                           // 000000494798: 7E2C3987
	v_and_b32_e32 v12, 1, v20                                  // 00000049479C: 36182881
	v_and_b32_e32 v13, 1, v21                                  // 0000004947A0: 361A2A81
	v_and_b32_e32 v14, 1, v23                                  // 0000004947A4: 361C2E81
	v_and_b32_e32 v16, 1, v24                                  // 0000004947A8: 36203081
	v_and_b32_e32 v15, 1, v22                                  // 0000004947AC: 361E2C81
	.long 0x7e2c3989                                           // 0000004947B0: 7E2C3989
	v_add3_u32 v3, v3, v10, 0x7fff                             // 0000004947B4: D6550003 03FE1503 00007FFF
	v_add3_u32 v2, v2, v12, 0x7fff                             // 0000004947C0: D6550002 03FE1902 00007FFF
	v_add3_u32 v5, v5, v13, 0x7fff                             // 0000004947CC: D6550005 03FE1B05 00007FFF
	v_add3_u32 v4, v4, v11, 0x7fff                             // 0000004947D8: D6550004 03FE1704 00007FFF
	v_and_b32_e32 v10, 1, v22                                  // 0000004947E4: 36142C81
	v_add3_u32 v6, v6, v14, 0x7fff                             // 0000004947E8: D6550006 03FE1D06 00007FFF
	v_add3_u32 v8, v8, v16, 0x7fff                             // 0000004947F4: D6550008 03FE2108 00007FFF
	v_add3_u32 v7, v7, v15, 0x7fff                             // 000000494800: D6550007 03FE1F07 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 00000049480C: BF870004
	v_add3_u32 v9, v9, v10, 0x7fff                             // 000000494810: D6550009 03FE1509 00007FFF
	s_clause 0x7                                               // 00000049481C: BF850007
	global_store_d16_hi_b16 v[0:1], v2, off                    // 000000494820: DC960000 007C0200
	global_store_d16_hi_b16 v[0:1], v3, off offset:32          // 000000494828: DC960020 007C0300
	global_store_d16_hi_b16 v[0:1], v5, off offset:64          // 000000494830: DC960040 007C0500
	global_store_d16_hi_b16 v[0:1], v4, off offset:96          // 000000494838: DC960060 007C0400
	global_store_d16_hi_b16 v[0:1], v6, off offset:128         // 000000494840: DC960080 007C0600
	global_store_d16_hi_b16 v[0:1], v7, off offset:160         // 000000494848: DC9600A0 007C0700
	global_store_d16_hi_b16 v[0:1], v8, off offset:192         // 000000494850: DC9600C0 007C0800
	global_store_d16_hi_b16 v[0:1], v9, off offset:224         // 000000494858: DC9600E0 007C0900
	s_nop 0                                                    // 000000494860: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000494864: BFB60003
	s_endpgm                                                   // 000000494868: BFB00000
	s_nop 0                                                    // 00000049486C: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000494870: BFB60003
	s_endpgm                                                   // 000000494874: BFB00000
		...

