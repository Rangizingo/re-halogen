00000000008daf00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 0000008DAF00: F4100100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 0000008DAF08: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 0000008DAF0C: 32040082
	s_lshl_b64 s[20:21], s[2:3], 2                             // 0000008DAF10: 84948202
	v_and_b32_e32 v1, 15, v0                                   // 0000008DAF14: 3602008F
	v_mov_b32_e32 v5, 0                                        // 0000008DAF18: 7E0A0280
	v_lshrrev_b32_e32 v14, 6, v0                               // 0000008DAF1C: 321C0086
	v_and_b32_e32 v2, 60, v2                                   // 0000008DAF20: 360404BC
	s_delay_alu instid0(VALU_DEP_4)                            // 0000008DAF24: BF870004
	v_dual_mov_b32 v6, 0 :: v_dual_lshlrev_b32 v1, 2, v1       // 0000008DAF28: CA220080 06000282
	v_bfe_u32 v15, v0, 5, 1                                    // 0000008DAF30: D610000F 02050B00
	v_dual_mov_b32 v17, 0 :: v_dual_and_b32 v16, 31, v0        // 0000008DAF38: CA240080 1110009F
	.long 0x7f103880                                           // 0000008DAF40: 7F103880
	s_waitcnt lgkmcnt(0)                                       // 0000008DAF44: BF89FC07
	s_clause 0x1                                               // 0000008DAF48: BF850001
	global_load_b32 v3, v1, s[4:5]                             // 0000008DAF4C: DC520000 03040001
	global_load_b32 v4, v2, s[4:5]                             // 0000008DAF54: DC520000 04040002
	v_mov_b32_e32 v2, s21                                      // 0000008DAF5C: 7E040215
	v_or_b32_e32 v1, s20, v14                                  // 0000008DAF60: 38021C14
	s_add_u32 s2, s4, s14                                      // 0000008DAF64: 80020E04
	s_addc_u32 s3, s5, s15                                     // 0000008DAF68: 82030F05
	s_lshr_b32 s14, s11, 31                                    // 0000008DAF6C: 850E9F0B
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000008DAF70: BF870009
	s_add_u32 s14, s10, s14                                    // 0000008DAF74: 800E0E0A
	s_addc_u32 s15, s11, 0                                     // 0000008DAF78: 820F800B
	s_ashr_i32 s22, s11, 31                                    // 0000008DAF7C: 86169F0B
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 0000008DAF80: 7CA8020C
	s_lshr_b32 s22, s22, 27                                    // 0000008DAF84: 85169B16
	s_ashr_i64 s[14:15], s[14:15], 1                           // 0000008DAF88: 868E810E
	s_add_u32 s22, s10, s22                                    // 0000008DAF8C: 8016160A
	s_addc_u32 s23, s11, 0                                     // 0000008DAF90: 8217800B
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000008DAF94: 02020280
	s_lshr_b64 s[22:23], s[22:23], 5                           // 0000008DAF98: 85968516
	v_cndmask_b32_e64 v7, 0, s21, vcc_lo                       // 0000008DAF9C: D5010007 01A82A80
	s_add_i32 s23, s22, 1                                      // 0000008DAFA4: 81178116
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008DAFA8: BF870002
	.long 0xd72c0002                                           // 0000008DAFAC: D72C0002
	v_cndmask_b32_e32 v1, s19, v1, vcc_lo                      // 0000008DAFB0: 02020213
	s_lshr_b32 s19, s23, 31                                    // 0000008DAFB4: 85139F17
	.long 0xd72c000d                                           // 0000008DAFB8: D72C000D
	v_cndmask_b32_e32 v0, v1, v15, vcc_lo                      // 0000008DAFBC: 02001F01
	s_add_i32 s23, s23, s19                                    // 0000008DAFC0: 81171317
	v_mad_u64_u32 v[9:10], null, v1, s14, s[2:3]               // 0000008DAFC4: D6FE7C09 00081D01
	s_ashr_i32 s15, s23, 1                                     // 0000008DAFCC: 860F8117
	s_add_u32 s2, s4, s16                                      // 0000008DAFD0: 80021004
	.long 0xd72c0012                                           // 0000008DAFD4: D72C0012
	v_cndmask_b32_e32 v1, s15, v15, vcc_lo                     // 0000008DAFD8: 02021E0F
	s_addc_u32 s3, s5, s17                                     // 0000008DAFDC: 82031105
	.long 0xd72c0014                                           // 0000008DAFE0: D72C0014
	v_cndmask_b32_e32 v0, v7, v14, vcc_lo                      // 0000008DAFE4: 02001D07
	.long 0xd72c0015                                           // 0000008DAFE8: D72C0015
	v_cndmask_b32_e32 v1, s18, v7, vcc_lo                      // 0000008DAFEC: 02020E12
	v_mov_b32_e32 v29, 0                                       // 0000008DAFF0: 7E3A0280
	v_mov_b32_e32 v7, 0                                        // 0000008DAFF4: 7E0E0280
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000008DAFF8: BF870154
	v_add3_u32 v10, v20, v10, v13                              // 0000008DAFFC: D655000A 04361514
	s_waitcnt vmcnt(1)                                         // 0000008DB004: BF8907F7
	v_bfe_u32 v11, v3, 16, 1                                   // 0000008DB008: D610000B 02052103
	s_waitcnt vmcnt(0)                                         // 0000008DB010: BF8903F7
	v_bfe_u32 v19, v4, 16, 1                                   // 0000008DB014: D6100013 02052104
	v_add3_u32 v3, v3, v11, 0x7fff                             // 0000008DB01C: D6550003 03FE1703 00007FFF
	v_mad_u64_u32 v[11:12], null, s18, v1, s[2:3]              // 0000008DB028: D6FE7C0B 000A0212
	v_add_nc_u32_e32 v1, s15, v18                              // 0000008DB030: 4A02240F
	s_delay_alu instid0(VALU_DEP_4)                            // 0000008DB034: BF870004
	v_add3_u32 v4, v4, v19, 0x7fff                             // 0000008DB038: D6550004 03FE2704 00007FFF
	v_add_nc_u32_e32 v18, v18, v16                             // 0000008DB044: 4A242112
	.long 0x7e103983                                           // 0000008DB048: 7E103983
	v_lshlrev_b32_e32 v3, 2, v0                                // 0000008DB04C: 30060082
	v_min_i32_e32 v19, s22, v1                                 // 0000008DB050: 22260216
	v_add3_u32 v20, v2, v12, v21                               // 0000008DB054: D6550014 04561902
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000008DB05C: BF870224
	v_and_or_b32 v1, 0xffff0000, v4, v8                        // 0000008DB060: D6570001 042208FF FFFF0000
	v_mov_b32_e32 v8, 0                                        // 0000008DB06C: 7E100280
	v_cmp_lt_i32_e32 vcc_lo, v18, v19                          // 0000008DB070: 7C822712
	ds_store_b32 v3, v1                                        // 0000008DB074: D8340000 00000103
	s_waitcnt lgkmcnt(0)                                       // 0000008DB07C: BF89FC07
	s_barrier                                                  // 0000008DB080: BFBD0000
	buffer_gl0_inv                                             // 0000008DB084: E0AC0000 00000000
	s_and_saveexec_b32 s3, vcc_lo                              // 0000008DB08C: BE83206A
	s_cbranch_execz 21                                         // 0000008DB090: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x1e8>
	v_lshlrev_b32_e32 v1, 1, v18                               // 0000008DB094: 30022481
	v_lshlrev_b32_e32 v3, 4, v18                               // 0000008DB098: 30062484
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008DB09C: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000008DB0A0: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000008DB0A4: 3408069F
	.long 0xd7000201                                           // 0000008DB0A8: D7000201
	v_cndmask_b32_e32 v1, v11, v1, vcc_lo                      // 0000008DB0AC: 0202030B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008DB0B0: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v20, v2, s2                  // 0000008DB0B4: D5207C02 000A0514
	.long 0xd7000203                                           // 0000008DB0BC: D7000203
	v_cndmask_b32_e32 v1, v9, v3, vcc_lo                       // 0000008DB0C0: 02020709
	v_add_co_ci_u32_e64 v4, null, v10, v4, s2                  // 0000008DB0C4: D5207C04 000A090A
	s_clause 0x1                                               // 0000008DB0CC: BF850001
	global_load_d16_b16 v1, v[1:2], off                        // 0000008DB0D0: DC820000 017C0001
	global_load_b128 v[5:8], v[3:4], off                       // 0000008DB0D8: DC5E0000 057C0003
	s_waitcnt vmcnt(1)                                         // 0000008DB0E0: BF8907F7
	v_cvt_f32_f16_e32 v29, v1                                  // 0000008DB0E4: 7E3A1701
	s_or_b32 exec_lo, exec_lo, s3                              // 0000008DB0E8: 8C7E037E
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v23, 0             // 0000008DB0EC: CA100080 16160080
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v25, 0             // 0000008DB0F4: CA100080 18180080
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v21, 0             // 0000008DB0FC: CA100080 1A140080
	s_and_saveexec_b32 s3, vcc_lo                              // 0000008DB104: BE83206A
	s_cbranch_execz 579                                        // 0000008DB108: BFA50243 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0xb18>
	v_dual_mov_b32 v26, 0 :: v_dual_add_nc_u32 v1, 32, v18     // 0000008DB10C: CA200080 1A0024A0
	v_dual_mov_b32 v21, 0 :: v_dual_lshlrev_b32 v12, 5, v18    // 0000008DB114: CA220080 150C2485
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v22, 0             // 0000008DB11C: CA100080 17160080
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008DB124: BF870003
	v_dual_mov_b32 v24, 0 :: v_dual_lshlrev_b32 v27, 4, v1     // 0000008DB128: CA220080 181A0284
	v_dual_mov_b32 v25, 0 :: v_dual_lshlrev_b32 v28, 1, v1     // 0000008DB130: CA220080 191C0281
	v_dual_mov_b32 v17, 0 :: v_dual_mov_b32 v30, v29           // 0000008DB138: CA100080 111E011D
	s_mul_i32 s2, s11, 6                                       // 0000008DB140: 9602860B
	s_mul_hi_u32 s14, s10, 6                                   // 0000008DB144: 968E860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 0000008DB148: 8484820A
	s_add_i32 s14, s14, s2                                     // 0000008DB14C: 810E020E
	s_mul_i32 s16, s10, 6                                      // 0000008DB150: 9610860A
	s_mov_b32 s15, 0                                           // 0000008DB154: BE8F0080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 0000008DB158: 848A810A
	s_branch 526                                               // 0000008DB15C: BFA0020E <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0xa98>
	s_or_b32 exec_lo, exec_lo, s17                             // 0000008DB160: 8C7E117E
	v_and_b32_e32 v13, 0xff, v5                                // 0000008DB164: 361A0AFF 000000FF
	s_and_b32 s2, exec_lo, vcc_lo                              // 0000008DB16C: 8B026A7E
	v_add_nc_u32_e32 v27, 0x200, v27                           // 0000008DB170: 4A3636FF 00000200
	s_or_b32 s15, s2, s15                                      // 0000008DB178: 8C0F0F02
	v_add_nc_u32_e32 v28, 64, v28                              // 0000008DB17C: 4A3838C0
	v_lshlrev_b32_e32 v13, 2, v13                              // 0000008DB180: 301A1A82
	ds_load_b32 v47, v13                                       // 0000008DB184: D8D80000 2F00000D
	v_lshrrev_b32_e32 v13, 6, v5                               // 0000008DB18C: 321A0A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000008DB190: BF870141
	v_and_b32_e32 v13, 0x3fc, v13                              // 0000008DB194: 361A1AFF 000003FC
	ds_load_b32 v48, v13                                       // 0000008DB19C: D8D80000 3000000D
	v_lshrrev_b32_e32 v13, 14, v5                              // 0000008DB1A4: 321A0A8E
	v_lshrrev_b32_e32 v5, 22, v5                               // 0000008DB1A8: 320A0A96
	v_and_b32_e32 v13, 0x3fc, v13                              // 0000008DB1AC: 361A1AFF 000003FC
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000008DB1B4: BF870152
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000008DB1B8: 360A0AFF 000003FC
	ds_load_b32 v49, v13                                       // 0000008DB1C0: D8D80000 3100000D
	ds_load_b32 v50, v5                                        // 0000008DB1C8: D8D80000 32000005
	v_and_b32_e32 v5, 0xff, v6                                 // 0000008DB1D0: 360A0CFF 000000FF
	v_ashrrev_i32_e32 v13, 31, v12                             // 0000008DB1D8: 341A189F
	v_lshlrev_b32_e32 v5, 2, v5                                // 0000008DB1DC: 300A0A82
	ds_load_b32 v51, v5                                        // 0000008DB1E0: D8D80000 33000005
	v_lshrrev_b32_e32 v5, 6, v6                                // 0000008DB1E8: 320A0C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008DB1EC: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000008DB1F0: 360A0AFF 000003FC
	ds_load_b32 v52, v5                                        // 0000008DB1F8: D8D80000 34000005
	v_lshrrev_b32_e32 v5, 14, v6                               // 0000008DB200: 320A0C8E
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000008DB204: 360A0AFF 000003FC
	ds_load_b32 v53, v5                                        // 0000008DB20C: D8D80000 35000005
	v_lshrrev_b32_e32 v5, 22, v6                               // 0000008DB214: 320A0C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008DB218: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000008DB21C: 360A0AFF 000003FC
	ds_load_b32 v54, v5                                        // 0000008DB224: D8D80000 36000005
	v_and_b32_e32 v5, 0xff, v7                                 // 0000008DB22C: 360A0EFF 000000FF
	v_lshlrev_b32_e32 v5, 2, v5                                // 0000008DB234: 300A0A82
	ds_load_b32 v55, v5                                        // 0000008DB238: D8D80000 37000005
	v_lshrrev_b32_e32 v5, 6, v7                                // 0000008DB240: 320A0E86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008DB244: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000008DB248: 360A0AFF 000003FC
	ds_load_b32 v56, v5                                        // 0000008DB250: D8D80000 38000005
	v_lshrrev_b32_e32 v5, 14, v7                               // 0000008DB258: 320A0E8E
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000008DB25C: 360A0AFF 000003FC
	ds_load_b32 v57, v5                                        // 0000008DB264: D8D80000 39000005
	v_lshrrev_b32_e32 v5, 22, v7                               // 0000008DB26C: 320A0E96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008DB270: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000008DB274: 360A0AFF 000003FC
	ds_load_b32 v58, v5                                        // 0000008DB27C: D8D80000 3A000005
	v_and_b32_e32 v5, 0xff, v8                                 // 0000008DB284: 360A10FF 000000FF
	v_lshlrev_b32_e32 v5, 2, v5                                // 0000008DB28C: 300A0A82
	ds_load_b32 v59, v5                                        // 0000008DB290: D8D80000 3B000005
	v_lshrrev_b32_e32 v5, 6, v8                                // 0000008DB298: 320A1086
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008DB29C: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000008DB2A0: 360A0AFF 000003FC
	ds_load_b32 v60, v5                                        // 0000008DB2A8: D8D80000 3C000005
	v_lshrrev_b32_e32 v5, 14, v8                               // 0000008DB2B0: 320A108E
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000008DB2B4: 360A0AFF 000003FC
	ds_load_b32 v61, v5                                        // 0000008DB2BC: D8D80000 3D000005
	v_lshrrev_b32_e32 v5, 22, v8                               // 0000008DB2C4: 320A1096
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000008DB2C8: BF870141
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000008DB2CC: 360A0AFF 000003FC
	ds_load_b32 v62, v5                                        // 0000008DB2D4: D8D80000 3E000005
	.long 0xd73c0005                                           // 0000008DB2DC: D73C0005
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 0000008DB2E0: 02021881
	v_add_nc_u32_e32 v12, 0x400, v12                           // 0000008DB2E4: 4A1818FF 00000400
	.long 0xd7006a2b                                           // 0000008DB2EC: D7006A2B
	v_cndmask_b32_e32 v1, s6, v5, vcc_lo                       // 0000008DB2F0: 02020A06
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008DB2F4: BF870001
	v_add_co_ci_u32_e64 v44, null, s7, v6, vcc_lo              // 0000008DB2F8: D5207C2C 01AA0C07
	s_clause 0x3                                               // 0000008DB300: BF850003
	global_load_b128 v[5:8], v[43:44], off                     // 0000008DB304: DC5E0000 057C002B
	global_load_b128 v[31:34], v[43:44], off offset:16         // 0000008DB30C: DC5E0010 1F7C002B
	global_load_b128 v[35:38], v[43:44], off offset:32         // 0000008DB314: DC5E0020 237C002B
	global_load_b128 v[39:42], v[43:44], off offset:48         // 0000008DB31C: DC5E0030 277C002B
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 0000008DB324: BF890CF7
	v_dot2_f32_bf16 v5, v5, v47, 0                             // 0000008DB328: CC1A4005 1A025F05
	s_waitcnt lgkmcnt(14)                                      // 0000008DB330: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008DB334: BF8700A1
	v_dot2_f32_bf16 v5, v6, v48, v5                            // 0000008DB338: CC1A4005 1C166106
	s_waitcnt lgkmcnt(13)                                      // 0000008DB340: BF89FCD7
	v_dot2_f32_bf16 v5, v7, v49, v5                            // 0000008DB344: CC1A4005 1C166307
	s_waitcnt lgkmcnt(12)                                      // 0000008DB34C: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008DB350: BF8700A1
	v_dot2_f32_bf16 v5, v8, v50, v5                            // 0000008DB354: CC1A4005 1C166508
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 0000008DB35C: BF8908B7
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 0000008DB360: CC1A4005 1C16671F
	s_waitcnt lgkmcnt(10)                                      // 0000008DB368: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008DB36C: BF8700A1
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 0000008DB370: CC1A4005 1C166920
	s_waitcnt lgkmcnt(9)                                       // 0000008DB378: BF89FC97
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 0000008DB37C: CC1A4005 1C166B21
	s_waitcnt lgkmcnt(8)                                       // 0000008DB384: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008DB388: BF8700A1
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 0000008DB38C: CC1A4005 1C166D22
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 0000008DB394: BF890477
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 0000008DB398: CC1A4005 1C166F23
	s_waitcnt lgkmcnt(6)                                       // 0000008DB3A0: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008DB3A4: BF8700A1
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 0000008DB3A8: CC1A4005 1C167124
	s_waitcnt lgkmcnt(5)                                       // 0000008DB3B0: BF89FC57
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 0000008DB3B4: CC1A4005 1C167325
	s_waitcnt lgkmcnt(4)                                       // 0000008DB3BC: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008DB3C0: BF8700A1
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 0000008DB3C4: CC1A4005 1C167526
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 0000008DB3CC: BF890037
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 0000008DB3D0: CC1A4005 1C167727
	.long 0xd7006a27                                           // 0000008DB3D8: D7006A27
	v_cndmask_b32_e32 v0, v43, v10, vcc_lo                     // 0000008DB3DC: 0200152B
	s_waitcnt lgkmcnt(2)                                       // 0000008DB3E0: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000008DB3E4: BF8701C2
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 0000008DB3E8: CC1A4005 1C167928
	v_add_co_ci_u32_e64 v40, null, s11, v44, vcc_lo            // 0000008DB3F0: D5207C28 01AA580B
	.long 0xd7006a2d                                           // 0000008DB3F8: D7006A2D
	v_cndmask_b32_e32 v0, v43, v4, vcc_lo                      // 0000008DB3FC: 0200092B
	s_waitcnt lgkmcnt(1)                                       // 0000008DB400: BF89FC17
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 0000008DB404: CC1A4005 1C167B29
	v_add_co_ci_u32_e64 v46, null, s5, v44, vcc_lo             // 0000008DB40C: D5207C2E 01AA5805
	.long 0xd7006a2b                                           // 0000008DB414: D7006A2B
	v_cndmask_b32_e32 v0, v43, v16, vcc_lo                     // 0000008DB418: 0200212B
	s_waitcnt lgkmcnt(0)                                       // 0000008DB41C: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008DB420: BF870123
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 0000008DB424: CC1A4005 1C167D2A
	v_add_co_ci_u32_e64 v44, null, s14, v44, vcc_lo            // 0000008DB42C: D5207C2C 01AA580E
	v_fmac_f32_e32 v21, v29, v5                                // 0000008DB434: 562A0B1D
	s_clause 0x3                                               // 0000008DB438: BF850003
	global_load_b128 v[5:8], v[39:40], off                     // 0000008DB43C: DC5E0000 057C0027
	global_load_b128 v[31:34], v[39:40], off offset:16         // 0000008DB444: DC5E0010 1F7C0027
	global_load_b128 v[35:38], v[39:40], off offset:32         // 0000008DB44C: DC5E0020 237C0027
	global_load_b128 v[39:42], v[39:40], off offset:48         // 0000008DB454: DC5E0030 277C0027
	s_waitcnt vmcnt(3)                                         // 0000008DB45C: BF890FF7
	v_dot2_f32_bf16 v5, v5, v47, 0                             // 0000008DB460: CC1A4005 1A025F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DB468: BF870091
	v_dot2_f32_bf16 v5, v6, v48, v5                            // 0000008DB46C: CC1A4005 1C166106
	v_dot2_f32_bf16 v5, v7, v49, v5                            // 0000008DB474: CC1A4005 1C166307
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008DB47C: BF8700A1
	v_dot2_f32_bf16 v5, v8, v50, v5                            // 0000008DB480: CC1A4005 1C166508
	s_waitcnt vmcnt(2)                                         // 0000008DB488: BF890BF7
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 0000008DB48C: CC1A4005 1C16671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DB494: BF870091
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 0000008DB498: CC1A4005 1C166920
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 0000008DB4A0: CC1A4005 1C166B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008DB4A8: BF8700A1
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 0000008DB4AC: CC1A4005 1C166D22
	s_waitcnt vmcnt(1)                                         // 0000008DB4B4: BF8907F7
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 0000008DB4B8: CC1A4005 1C166F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DB4C0: BF870091
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 0000008DB4C4: CC1A4005 1C167124
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 0000008DB4CC: CC1A4005 1C167325
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008DB4D4: BF8700A1
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 0000008DB4D8: CC1A4005 1C167526
	s_waitcnt vmcnt(0)                                         // 0000008DB4E0: BF8903F7
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 0000008DB4E4: CC1A4005 1C167727
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DB4EC: BF870091
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 0000008DB4F0: CC1A4005 1C167928
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 0000008DB4F8: CC1A4005 1C167B29
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DB500: BF870091
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 0000008DB504: CC1A4005 1C167D2A
	v_fmac_f32_e32 v26, v29, v5                                // 0000008DB50C: 56340B1D
	s_clause 0x3                                               // 0000008DB510: BF850003
	global_load_b128 v[5:8], v[45:46], off                     // 0000008DB514: DC5E0000 057C002D
	global_load_b128 v[31:34], v[45:46], off offset:16         // 0000008DB51C: DC5E0010 1F7C002D
	global_load_b128 v[35:38], v[45:46], off offset:32         // 0000008DB524: DC5E0020 237C002D
	global_load_b128 v[39:42], v[45:46], off offset:48         // 0000008DB52C: DC5E0030 277C002D
	.long 0xd7006a2d                                           // 0000008DB534: D7006A2D
	v_cndmask_b32_e32 v0, v45, v4, vcc_lo                      // 0000008DB538: 0200092D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008DB53C: BF8700B1
	v_add_co_ci_u32_e64 v46, null, s5, v46, vcc_lo             // 0000008DB540: D5207C2E 01AA5C05
	s_waitcnt vmcnt(3)                                         // 0000008DB548: BF890FF7
	v_dot2_f32_bf16 v5, v5, v47, 0                             // 0000008DB54C: CC1A4005 1A025F05
	v_dot2_f32_bf16 v5, v6, v48, v5                            // 0000008DB554: CC1A4005 1C166106
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DB55C: BF870091
	v_dot2_f32_bf16 v5, v7, v49, v5                            // 0000008DB560: CC1A4005 1C166307
	v_dot2_f32_bf16 v5, v8, v50, v5                            // 0000008DB568: CC1A4005 1C166508
	s_waitcnt vmcnt(2)                                         // 0000008DB570: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DB574: BF870091
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 0000008DB578: CC1A4005 1C16671F
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 0000008DB580: CC1A4005 1C166920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DB588: BF870091
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 0000008DB58C: CC1A4005 1C166B21
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 0000008DB594: CC1A4005 1C166D22
	s_waitcnt vmcnt(1)                                         // 0000008DB59C: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DB5A0: BF870091
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 0000008DB5A4: CC1A4005 1C166F23
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 0000008DB5AC: CC1A4005 1C167124
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DB5B4: BF870091
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 0000008DB5B8: CC1A4005 1C167325
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 0000008DB5C0: CC1A4005 1C167526
	s_waitcnt vmcnt(0)                                         // 0000008DB5C8: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DB5CC: BF870091
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 0000008DB5D0: CC1A4005 1C167727
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 0000008DB5D8: CC1A4005 1C167928
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DB5E0: BF870091
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 0000008DB5E4: CC1A4005 1C167B29
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 0000008DB5EC: CC1A4005 1C167D2A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008DB5F4: BF870001
	v_fmac_f32_e32 v25, v29, v5                                // 0000008DB5F8: 56320B1D
	s_clause 0x3                                               // 0000008DB5FC: BF850003
	global_load_b128 v[5:8], v[43:44], off                     // 0000008DB600: DC5E0000 057C002B
	global_load_b128 v[31:34], v[43:44], off offset:16         // 0000008DB608: DC5E0010 1F7C002B
	global_load_b128 v[35:38], v[43:44], off offset:32         // 0000008DB610: DC5E0020 237C002B
	global_load_b128 v[39:42], v[43:44], off offset:48         // 0000008DB618: DC5E0030 277C002B
	s_waitcnt vmcnt(3)                                         // 0000008DB620: BF890FF7
	v_dot2_f32_bf16 v5, v5, v47, 0                             // 0000008DB624: CC1A4005 1A025F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DB62C: BF870091
	v_dot2_f32_bf16 v5, v6, v48, v5                            // 0000008DB630: CC1A4005 1C166106
	v_dot2_f32_bf16 v5, v7, v49, v5                            // 0000008DB638: CC1A4005 1C166307
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008DB640: BF8700A1
	v_dot2_f32_bf16 v5, v8, v50, v5                            // 0000008DB644: CC1A4005 1C166508
	s_waitcnt vmcnt(2)                                         // 0000008DB64C: BF890BF7
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 0000008DB650: CC1A4005 1C16671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DB658: BF870091
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 0000008DB65C: CC1A4005 1C166920
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 0000008DB664: CC1A4005 1C166B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008DB66C: BF8700A1
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 0000008DB670: CC1A4005 1C166D22
	s_waitcnt vmcnt(1)                                         // 0000008DB678: BF8907F7
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 0000008DB67C: CC1A4005 1C166F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DB684: BF870091
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 0000008DB688: CC1A4005 1C167124
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 0000008DB690: CC1A4005 1C167325
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008DB698: BF8700A1
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 0000008DB69C: CC1A4005 1C167526
	s_waitcnt vmcnt(0)                                         // 0000008DB6A4: BF8903F7
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 0000008DB6A8: CC1A4005 1C167727
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DB6B0: BF870091
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 0000008DB6B4: CC1A4005 1C167928
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 0000008DB6BC: CC1A4005 1C167B29
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DB6C4: BF870091
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 0000008DB6C8: CC1A4005 1C167D2A
	v_fmac_f32_e32 v24, v29, v5                                // 0000008DB6D0: 56300B1D
	s_clause 0x3                                               // 0000008DB6D4: BF850003
	global_load_b128 v[5:8], v[45:46], off                     // 0000008DB6D8: DC5E0000 057C002D
	global_load_b128 v[31:34], v[45:46], off offset:16         // 0000008DB6E0: DC5E0010 1F7C002D
	global_load_b128 v[35:38], v[45:46], off offset:32         // 0000008DB6E8: DC5E0020 237C002D
	global_load_b128 v[39:42], v[45:46], off offset:48         // 0000008DB6F0: DC5E0030 277C002D
	s_waitcnt vmcnt(3)                                         // 0000008DB6F8: BF890FF7
	v_dot2_f32_bf16 v5, v5, v47, 0                             // 0000008DB6FC: CC1A4005 1A025F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DB704: BF870091
	v_dot2_f32_bf16 v5, v6, v48, v5                            // 0000008DB708: CC1A4005 1C166106
	v_dot2_f32_bf16 v5, v7, v49, v5                            // 0000008DB710: CC1A4005 1C166307
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008DB718: BF8700A1
	v_dot2_f32_bf16 v5, v8, v50, v5                            // 0000008DB71C: CC1A4005 1C166508
	s_waitcnt vmcnt(2)                                         // 0000008DB724: BF890BF7
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 0000008DB728: CC1A4005 1C16671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DB730: BF870091
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 0000008DB734: CC1A4005 1C166920
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 0000008DB73C: CC1A4005 1C166B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008DB744: BF8700A1
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 0000008DB748: CC1A4005 1C166D22
	s_waitcnt vmcnt(1)                                         // 0000008DB750: BF8907F7
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 0000008DB754: CC1A4005 1C166F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DB75C: BF870091
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 0000008DB760: CC1A4005 1C167124
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 0000008DB768: CC1A4005 1C167325
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008DB770: BF8700A1
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 0000008DB774: CC1A4005 1C167526
	s_waitcnt vmcnt(0)                                         // 0000008DB77C: BF8903F7
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 0000008DB780: CC1A4005 1C167727
	.long 0xd7006a27                                           // 0000008DB788: D7006A27
	v_cndmask_b32_e32 v0, v43, v4, vcc_lo                      // 0000008DB78C: 0200092B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008DB790: BF870122
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 0000008DB794: CC1A4005 1C167928
	v_add_co_ci_u32_e64 v40, null, s5, v44, vcc_lo             // 0000008DB79C: D5207C28 01AA5805
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 0000008DB7A4: CC1A4005 1C167B29
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DB7AC: BF870091
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 0000008DB7B0: CC1A4005 1C167D2A
	v_fmac_f32_e32 v23, v29, v5                                // 0000008DB7B8: 562E0B1D
	s_clause 0x3                                               // 0000008DB7BC: BF850003
	global_load_b128 v[5:8], v[39:40], off                     // 0000008DB7C0: DC5E0000 057C0027
	global_load_b128 v[31:34], v[39:40], off offset:16         // 0000008DB7C8: DC5E0010 1F7C0027
	global_load_b128 v[35:38], v[39:40], off offset:32         // 0000008DB7D0: DC5E0020 237C0027
	global_load_b128 v[39:42], v[39:40], off offset:48         // 0000008DB7D8: DC5E0030 277C0027
	s_waitcnt vmcnt(3)                                         // 0000008DB7E0: BF890FF7
	v_dot2_f32_bf16 v5, v5, v47, 0                             // 0000008DB7E4: CC1A4005 1A025F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DB7EC: BF870091
	v_dot2_f32_bf16 v5, v6, v48, v5                            // 0000008DB7F0: CC1A4005 1C166106
	v_dot2_f32_bf16 v5, v7, v49, v5                            // 0000008DB7F8: CC1A4005 1C166307
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008DB800: BF8700A1
	v_dot2_f32_bf16 v5, v8, v50, v5                            // 0000008DB804: CC1A4005 1C166508
	s_waitcnt vmcnt(2)                                         // 0000008DB80C: BF890BF7
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 0000008DB810: CC1A4005 1C16671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DB818: BF870091
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 0000008DB81C: CC1A4005 1C166920
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 0000008DB824: CC1A4005 1C166B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008DB82C: BF8700A1
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 0000008DB830: CC1A4005 1C166D22
	s_waitcnt vmcnt(1)                                         // 0000008DB838: BF8907F7
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 0000008DB83C: CC1A4005 1C166F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DB844: BF870091
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 0000008DB848: CC1A4005 1C167124
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 0000008DB850: CC1A4005 1C167325
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008DB858: BF8700A1
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 0000008DB85C: CC1A4005 1C167526
	s_waitcnt vmcnt(0)                                         // 0000008DB864: BF8903F7
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 0000008DB868: CC1A4005 1C167727
	.long 0xd7006a27                                           // 0000008DB870: D7006A27
	v_cndmask_b32_e32 v0, v45, v4, vcc_lo                      // 0000008DB874: 0200092D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008DB878: BF870122
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 0000008DB87C: CC1A4005 1C167928
	v_add_co_ci_u32_e64 v40, null, s5, v46, vcc_lo             // 0000008DB884: D5207C28 01AA5C05
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 0000008DB88C: CC1A4005 1C167B29
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DB894: BF870091
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 0000008DB898: CC1A4005 1C167D2A
	v_fmac_f32_e32 v22, v29, v5                                // 0000008DB8A0: 562C0B1D
	s_clause 0x3                                               // 0000008DB8A4: BF850003
	global_load_b128 v[5:8], v[39:40], off                     // 0000008DB8A8: DC5E0000 057C0027
	global_load_b128 v[31:34], v[39:40], off offset:16         // 0000008DB8B0: DC5E0010 1F7C0027
	global_load_b128 v[35:38], v[39:40], off offset:32         // 0000008DB8B8: DC5E0020 237C0027
	global_load_b128 v[39:42], v[39:40], off offset:48         // 0000008DB8C0: DC5E0030 277C0027
	s_waitcnt vmcnt(3)                                         // 0000008DB8C8: BF890FF7
	v_dot2_f32_bf16 v5, v5, v47, 0                             // 0000008DB8CC: CC1A4005 1A025F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008DB8D4: BF870121
	v_dot2_f32_bf16 v5, v6, v48, v5                            // 0000008DB8D8: CC1A4005 1C166106
	v_mov_b32_e32 v6, v2                                       // 0000008DB8E0: 7E0C0302
	v_dot2_f32_bf16 v5, v7, v49, v5                            // 0000008DB8E4: CC1A4005 1C166307
	v_mov_b32_e32 v7, v3                                       // 0000008DB8EC: 7E0E0303
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000008DB8F0: BF870132
	v_dot2_f32_bf16 v5, v8, v50, v5                            // 0000008DB8F4: CC1A4005 1C166508
	v_mov_b32_e32 v8, v4                                       // 0000008DB8FC: 7E100304
	s_waitcnt vmcnt(2)                                         // 0000008DB900: BF890BF7
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 0000008DB904: CC1A4005 1C16671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DB90C: BF870091
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 0000008DB910: CC1A4005 1C166920
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 0000008DB918: CC1A4005 1C166B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008DB920: BF8700A1
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 0000008DB924: CC1A4005 1C166D22
	s_waitcnt vmcnt(1)                                         // 0000008DB92C: BF8907F7
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 0000008DB930: CC1A4005 1C166F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DB938: BF870091
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 0000008DB93C: CC1A4005 1C167124
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 0000008DB944: CC1A4005 1C167325
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008DB94C: BF8700A1
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 0000008DB950: CC1A4005 1C167526
	s_waitcnt vmcnt(0)                                         // 0000008DB958: BF8903F7
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 0000008DB95C: CC1A4005 1C167727
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DB964: BF870091
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 0000008DB968: CC1A4005 1C167928
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 0000008DB970: CC1A4005 1C167B29
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DB978: BF870091
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 0000008DB97C: CC1A4005 1C167D2A
	v_fmac_f32_e32 v17, v29, v5                                // 0000008DB984: 56220B1D
	v_mov_b32_e32 v5, v1                                       // 0000008DB988: 7E0A0301
	v_mov_b32_e32 v29, v30                                     // 0000008DB98C: 7E3A031E
	s_and_not1_b32 exec_lo, exec_lo, s15                       // 0000008DB990: 917E0F7E
	s_cbranch_execz 31                                         // 0000008DB994: BFA5001F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0xb14>
	s_waitcnt vmcnt(0)                                         // 0000008DB998: BF8903F7
	v_dual_mov_b32 v1, v5 :: v_dual_add_nc_u32 v18, 32, v18    // 0000008DB99C: CA200105 011224A0
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v3, v7             // 0000008DB9A4: CA100106 02020107
	v_mov_b32_e32 v4, v8                                       // 0000008DB9AC: 7E080308
	s_mov_b32 s17, exec_lo                                     // 0000008DB9B0: BE91007E
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008DB9B4: BF870003
	v_cmp_ge_i32_e32 vcc_lo, v18, v19                          // 0000008DB9B8: 7C8C2712
	.long 0xd4c1007e                                           // 0000008DB9BC: D4C1007E
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 0000008DB9C0: 02022712
	s_cbranch_execz 64998                                      // 0000008DB9C4: BFA5FDE6 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x260>
	v_ashrrev_i32_e32 v2, 31, v28                              // 0000008DB9C8: 3404389F
	v_ashrrev_i32_e32 v4, 31, v27                              // 0000008DB9CC: 3408369F
	.long 0xd7000201                                           // 0000008DB9D0: D7000201
	v_cndmask_b32_e32 v1, v11, v28, vcc_lo                     // 0000008DB9D4: 0202390B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008DB9D8: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v20, v2, s2                  // 0000008DB9DC: D5207C02 000A0514
	.long 0xd7000203                                           // 0000008DB9E4: D7000203
	v_cndmask_b32_e32 v1, v9, v27, vcc_lo                      // 0000008DB9E8: 02023709
	v_add_co_ci_u32_e64 v4, null, v10, v4, s2                  // 0000008DB9EC: D5207C04 000A090A
	s_clause 0x1                                               // 0000008DB9F4: BF850001
	global_load_d16_b16 v13, v[1:2], off                       // 0000008DB9F8: DC820000 0D7C0001
	global_load_b128 v[1:4], v[3:4], off                       // 0000008DBA00: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 0000008DBA08: BF8907F7
	v_cvt_f32_f16_e32 v30, v13                                 // 0000008DBA0C: 7E3C170D
	s_branch 64979                                             // 0000008DBA10: BFA0FDD3 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x260>
	s_or_b32 exec_lo, exec_lo, s15                             // 0000008DBA14: 8C7E0F7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008DBA18: BF8700B9
	s_or_b32 exec_lo, exec_lo, s3                              // 0000008DBA1C: 8C7E037E
	.long 0xd71f0001                                           // 0000008DBA20: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000008DBA24: 020100C1
	s_mov_b32 s2, exec_lo                                      // 0000008DBA28: BE82007E
	v_xor_b32_e32 v2, 16, v1                                   // 0000008DBA2C: 3A040290
	v_xor_b32_e32 v9, 8, v1                                    // 0000008DBA30: 3A120288
	v_xor_b32_e32 v19, 4, v1                                   // 0000008DBA34: 3A260284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000008DBA38: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000008DBA3C: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 0000008DBA40: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v9                            // 0000008DBA44: 7C9812A0
	v_cndmask_b32_e32 v9, v1, v9, vcc_lo                       // 0000008DBA48: 02121301
	v_cmp_gt_u32_e32 vcc_lo, 32, v19                           // 0000008DBA4C: 7C9826A0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008DBA50: BF870002
	v_lshlrev_b32_e32 v9, 2, v9                                // 0000008DBA54: 30121282
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000008DBA58: 30040482
	ds_bpermute_b32 v3, v2, v21                                // 0000008DBA5C: DACC0000 03001502
	s_waitcnt lgkmcnt(0)                                       // 0000008DBA64: BF89FC07
	v_add_f32_e32 v3, v21, v3                                  // 0000008DBA68: 06060715
	s_waitcnt vmcnt(0)                                         // 0000008DBA6C: BF8903F7
	ds_bpermute_b32 v5, v2, v25                                // 0000008DBA70: DACC0000 05001902
	ds_bpermute_b32 v6, v2, v24                                // 0000008DBA78: DACC0000 06001802
	ds_bpermute_b32 v4, v2, v26                                // 0000008DBA80: DACC0000 04001A02
	ds_bpermute_b32 v7, v2, v23                                // 0000008DBA88: DACC0000 07001702
	ds_bpermute_b32 v8, v2, v22                                // 0000008DBA90: DACC0000 08001602
	ds_bpermute_b32 v2, v2, v17                                // 0000008DBA98: DACC0000 02001102
	ds_bpermute_b32 v10, v9, v3                                // 0000008DBAA0: DACC0000 0A000309
	s_waitcnt lgkmcnt(5)                                       // 0000008DBAA8: BF89FC57
	v_dual_add_f32 v5, v25, v5 :: v_dual_add_f32 v6, v24, v6   // 0000008DBAAC: C9080B19 05060D18
	s_waitcnt lgkmcnt(3)                                       // 0000008DBAB4: BF89FC37
	v_dual_add_f32 v4, v26, v4 :: v_dual_add_f32 v7, v23, v7   // 0000008DBAB8: C908091A 04060F17
	s_waitcnt lgkmcnt(2)                                       // 0000008DBAC0: BF89FC27
	v_add_f32_e32 v8, v22, v8                                  // 0000008DBAC4: 06101116
	ds_bpermute_b32 v12, v9, v5                                // 0000008DBAC8: DACC0000 0C000509
	ds_bpermute_b32 v13, v9, v6                                // 0000008DBAD0: DACC0000 0D000609
	ds_bpermute_b32 v11, v9, v4                                // 0000008DBAD8: DACC0000 0B000409
	v_cndmask_b32_e32 v19, v1, v19, vcc_lo                     // 0000008DBAE0: 02262701
	ds_bpermute_b32 v18, v9, v8                                // 0000008DBAE4: DACC0000 12000809
	s_waitcnt lgkmcnt(4)                                       // 0000008DBAEC: BF89FC47
	v_add_f32_e32 v3, v3, v10                                  // 0000008DBAF0: 06061503
	s_waitcnt lgkmcnt(2)                                       // 0000008DBAF4: BF89FC27
	v_dual_add_f32 v5, v5, v12 :: v_dual_add_f32 v6, v6, v13   // 0000008DBAF8: C9081905 05061B06
	v_dual_add_f32 v2, v17, v2 :: v_dual_lshlrev_b32 v19, 2, v19// 0000008DBB00: C9220511 02122682
	ds_bpermute_b32 v17, v9, v7                                // 0000008DBB08: DACC0000 11000709
	s_waitcnt lgkmcnt(2)                                       // 0000008DBB10: BF89FC27
	v_add_f32_e32 v4, v4, v11                                  // 0000008DBB14: 06081704
	s_waitcnt lgkmcnt(1)                                       // 0000008DBB18: BF89FC17
	v_add_f32_e32 v8, v8, v18                                  // 0000008DBB1C: 06102508
	ds_bpermute_b32 v9, v9, v2                                 // 0000008DBB20: DACC0000 09000209
	ds_bpermute_b32 v11, v19, v5                               // 0000008DBB28: DACC0000 0B000513
	ds_bpermute_b32 v12, v19, v6                               // 0000008DBB30: DACC0000 0C000613
	ds_bpermute_b32 v10, v19, v4                               // 0000008DBB38: DACC0000 0A000413
	s_waitcnt lgkmcnt(4)                                       // 0000008DBB40: BF89FC47
	v_add_f32_e32 v7, v7, v17                                  // 0000008DBB44: 060E2307
	ds_bpermute_b32 v17, v19, v8                               // 0000008DBB48: DACC0000 11000813
	s_waitcnt lgkmcnt(4)                                       // 0000008DBB50: BF89FC47
	v_add_f32_e32 v2, v2, v9                                   // 0000008DBB54: 06041302
	ds_bpermute_b32 v9, v19, v3                                // 0000008DBB58: DACC0000 09000313
	s_waitcnt lgkmcnt(3)                                       // 0000008DBB60: BF89FC37
	v_add_f32_e32 v6, v6, v12                                  // 0000008DBB64: 060C1906
	s_waitcnt lgkmcnt(2)                                       // 0000008DBB68: BF89FC27
	v_add_f32_e32 v4, v4, v10                                  // 0000008DBB6C: 06081504
	ds_bpermute_b32 v13, v19, v7                               // 0000008DBB70: DACC0000 0D000713
	ds_bpermute_b32 v18, v19, v2                               // 0000008DBB78: DACC0000 12000213
	v_xor_b32_e32 v19, 2, v1                                   // 0000008DBB80: 3A260282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008DBB84: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v19                           // 0000008DBB88: 7C9826A0
	v_cndmask_b32_e32 v19, v1, v19, vcc_lo                     // 0000008DBB8C: 02262701
	v_lshlrev_b32_e32 v19, 2, v19                              // 0000008DBB90: 30262682
	s_waitcnt lgkmcnt(2)                                       // 0000008DBB94: BF89FC27
	v_add_f32_e32 v3, v3, v9                                   // 0000008DBB98: 06061303
	s_waitcnt lgkmcnt(0)                                       // 0000008DBB9C: BF89FC07
	v_dual_add_f32 v7, v7, v13 :: v_dual_add_f32 v2, v2, v18   // 0000008DBBA0: C9081B07 07022502
	ds_bpermute_b32 v10, v19, v4                               // 0000008DBBA8: DACC0000 0A000413
	ds_bpermute_b32 v12, v19, v6                               // 0000008DBBB0: DACC0000 0C000613
	ds_bpermute_b32 v13, v19, v7                               // 0000008DBBB8: DACC0000 0D000713
	ds_bpermute_b32 v18, v19, v2                               // 0000008DBBC0: DACC0000 12000213
	v_add_f32_e32 v5, v5, v11                                  // 0000008DBBC8: 060A1705
	v_add_f32_e32 v9, v8, v17                                  // 0000008DBBCC: 06122308
	ds_bpermute_b32 v8, v19, v3                                // 0000008DBBD0: DACC0000 08000313
	ds_bpermute_b32 v11, v19, v5                               // 0000008DBBD8: DACC0000 0B000513
	s_waitcnt lgkmcnt(2)                                       // 0000008DBBE0: BF89FC27
	v_add_f32_e32 v2, v2, v18                                  // 0000008DBBE4: 06042502
	ds_bpermute_b32 v17, v19, v9                               // 0000008DBBE8: DACC0000 11000913
	v_xor_b32_e32 v19, 1, v1                                   // 0000008DBBF0: 3A260281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008DBBF4: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v19                           // 0000008DBBF8: 7C9826A0
	v_cndmask_b32_e32 v1, v1, v19, vcc_lo                      // 0000008DBBFC: 02022701
	v_lshlrev_b32_e32 v19, 2, v1                               // 0000008DBC00: 30260282
	s_waitcnt lgkmcnt(2)                                       // 0000008DBC04: BF89FC27
	v_add_f32_e32 v1, v3, v8                                   // 0000008DBC08: 06021103
	v_dual_add_f32 v3, v4, v10 :: v_dual_add_f32 v8, v7, v13   // 0000008DBC0C: C9081504 03081B07
	s_waitcnt lgkmcnt(1)                                       // 0000008DBC14: BF89FC17
	v_dual_add_f32 v4, v5, v11 :: v_dual_add_f32 v5, v6, v12   // 0000008DBC18: C9081705 04041906
	s_waitcnt lgkmcnt(0)                                       // 0000008DBC20: BF89FC07
	v_add_f32_e32 v10, v9, v17                                 // 0000008DBC24: 06142309
	ds_bpermute_b32 v6, v19, v1                                // 0000008DBC28: DACC0000 06000113
	ds_bpermute_b32 v9, v19, v3                                // 0000008DBC30: DACC0000 09000313
	ds_bpermute_b32 v11, v19, v4                               // 0000008DBC38: DACC0000 0B000413
	ds_bpermute_b32 v12, v19, v5                               // 0000008DBC40: DACC0000 0C000513
	ds_bpermute_b32 v13, v19, v8                               // 0000008DBC48: DACC0000 0D000813
	ds_bpermute_b32 v17, v19, v10                              // 0000008DBC50: DACC0000 11000A13
	ds_bpermute_b32 v7, v19, v2                                // 0000008DBC58: DACC0000 07000213
	v_cmpx_eq_u32_e32 0, v16                                   // 0000008DBC60: 7D942080
	s_cbranch_execz 29                                         // 0000008DBC64: BFA5001D <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0xddc>
	.long 0xd72c000e                                           // 0000008DBC68: D72C000E
	v_cndmask_b32_e32 v0, v14, v184, vcc_lo                    // 0000008DBC6C: 0201710E
	s_waitcnt lgkmcnt(2)                                       // 0000008DBC70: BF89FC27
	v_dual_add_f32 v8, v8, v13 :: v_dual_add_f32 v1, v1, v6    // 0000008DBC74: C9081B08 08000D01
	v_dual_add_f32 v4, v4, v11 :: v_dual_add_f32 v3, v3, v9    // 0000008DBC7C: C9081704 04021303
	s_waitcnt lgkmcnt(1)                                       // 0000008DBC84: BF89FC17
	v_dual_add_f32 v10, v10, v17 :: v_dual_add_f32 v5, v5, v12 // 0000008DBC88: C908230A 0A041905
	s_waitcnt lgkmcnt(0)                                       // 0000008DBC90: BF89FC07
	v_add_f32_e32 v2, v2, v7                                   // 0000008DBC94: 06040F02
	v_mad_u32_u24 v13, v15, 28, v14                            // 0000008DBC98: D60B000D 0439390F
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008DBCA0: BF870001
	v_add_nc_u32_e32 v6, 0x400, v13                            // 0000008DBCA4: 4A0C1AFF 00000400
	v_add_nc_u32_e32 v9, 0x408, v13                            // 0000008DBCAC: 4A121AFF 00000408
	v_add_nc_u32_e32 v11, 0x410, v13                           // 0000008DBCB4: 4A161AFF 00000410
	ds_store_2addr_b32 v6, v1, v3 offset1:1                    // 0000008DBCBC: D8380100 00030106
	ds_store_2addr_b32 v9, v4, v5 offset1:1                    // 0000008DBCC4: D8380100 00050409
	ds_store_2addr_b32 v11, v8, v10 offset1:1                  // 0000008DBCCC: D8380100 000A080B
	ds_store_b32 v13, v2 offset:1048                           // 0000008DBCD4: D8340418 0000020D
	s_or_b32 exec_lo, exec_lo, s2                              // 0000008DBCDC: 8C7E027E
	.long 0xd7050001                                           // 0000008DBCE0: D7050001
	v_cndmask_b32_e32 v0, v0, v165, vcc_lo                     // 0000008DBCE4: 02014B00
	.long 0x7f063880                                           // 0000008DBCE8: 7F063880
	s_waitcnt lgkmcnt(0)                                       // 0000008DBCEC: BF89FC07
	s_barrier                                                  // 0000008DBCF0: BFBD0000
	buffer_gl0_inv                                             // 0000008DBCF4: E0AC0000 00000000
	.long 0xd7390001                                           // 0000008DBCFC: D7390001
	v_cndmask_b32_e32 v1, 8, v1, vcc_lo                        // 0000008DBD00: 02020288
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DBD04: BF870091
	.long 0xd7044001                                           // 0000008DBD08: D7044001
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 0000008DBD0C: 02020300
	.long 0xd7395001                                           // 0000008DBD10: D7395001
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000008DBD14: 02020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DBD18: BF870091
	.long 0xd7625001                                           // 0000008DBD1C: D7625001
	v_cndmask_b32_e32 v1, 0x7f, v1, vcc_lo                     // 0000008DBD20: 020202FF 0000007F
	.long 0xd7030801                                           // 0000008DBD28: D7030801
	v_cndmask_b32_e32 v1, v1, v1, vcc_lo                       // 0000008DBD2C: 02020301
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DBD30: BF870091
	.long 0xd7390003                                           // 0000008DBD34: D7390003
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000008DBD38: 02020282
	.long 0xd7000201                                           // 0000008DBD3C: D7000201
	v_cndmask_b32_e32 v1, s20, v3, vcc_lo                      // 0000008DBD40: 02020614
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008DBD44: BF870121
	v_add_co_ci_u32_e64 v2, null, s21, 0, s2                   // 0000008DBD48: D5207C02 00090015
	.long 0xd44c0002                                           // 0000008DBD50: D44C0002
	v_cndmask_b32_e32 v1, 28, v0, vcc_lo                       // 0000008DBD54: 0202009C
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 0000008DBD58: 7CA8020C
	s_and_b32 s2, s2, vcc_lo                                   // 0000008DBD5C: 8B026A02
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000008DBD60: BF870009
	s_and_saveexec_b32 s3, s2                                  // 0000008DBD64: BE832002
	s_cbranch_execz 84                                         // 0000008DBD68: BFA50054 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0xfbc>
	.long 0xd7054000                                           // 0000008DBD6C: D7054000
	v_cndmask_b32_e32 v0, v3, v135, vcc_lo                     // 0000008DBD70: 02010F03
	s_lshr_b32 s2, s13, 31                                     // 0000008DBD74: 85029F0D
	v_mul_u32_u24_e32 v3, 56, v3                               // 0000008DBD78: 160606B8
	s_add_u32 s2, s12, s2                                      // 0000008DBD7C: 8002020C
	s_addc_u32 s3, s13, 0                                      // 0000008DBD80: 8203800D
	.long 0xd7041000                                           // 0000008DBD84: D7041000
	v_cndmask_b32_e32 v1, v0, v0, vcc_lo                       // 0000008DBD88: 02020100
	s_load_b64 s[4:5], s[0:1], 0x40                            // 0000008DBD8C: F4040100 F8000040
	s_lshr_b64 s[0:1], s[2:3], 1                               // 0000008DBD94: 85808102
	s_lshr_b32 s1, s3, 1                                       // 0000008DBD98: 85018103
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008DBD9C: BF870121
	v_dual_mov_b32 v10, s9 :: v_dual_and_b32 v7, 0xff, v0      // 0000008DBDA0: CA240009 0A0600FF 000000FF
	v_lshrrev_b32_e32 v0, 23, v2                               // 0000008DBDAC: 32000497
	v_lshl_add_u32 v3, v7, 2, v3                               // 0000008DBDB0: D6460003 040D0507
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DBDB8: BF870092
	.long 0xd7006a00                                           // 0000008DBDBC: D7006A00
	v_cndmask_b32_e32 v1, v1, v0, vcc_lo                       // 0000008DBDC0: 02020101
	v_add_co_ci_u32_e64 v8, null, 0, v2, vcc_lo                // 0000008DBDC4: D5207C08 01AA0480
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008DBDCC: BF870193
	v_add_nc_u32_e32 v3, 0x400, v3                             // 0000008DBDD0: 4A0606FF 00000400
	v_and_b32_e32 v9, 0xfffffe00, v0                           // 0000008DBDD8: 361200FF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000008DBDE0: BF8701B1
	.long 0xd7016a05                                           // 0000008DBDE4: D7016A05
	v_cndmask_b32_e32 v1, v1, v9, vcc_lo                       // 0000008DBDE8: 02021301
	v_mad_u64_u32 v[0:1], null, s0, v7, 0                      // 0000008DBDEC: D6FE7C00 02020E00
	v_sub_co_ci_u32_e64 v6, null, v2, v8, vcc_lo               // 0000008DBDF4: D5217C06 01AA1102
	.long 0xd700000b                                           // 0000008DBDFC: D700000B
	v_cndmask_b32_e32 v1, 0xffffff00, v5, vcc_lo               // 0000008DBE00: 02020AFF FFFFFF00
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008DBE08: BF870002
	v_cmp_gt_i64_e32 vcc_lo, 0x100, v[5:6]                     // 0000008DBE0C: 7CA80AFF 00000100
	v_add_co_ci_u32_e64 v12, null, -1, v6, s0                  // 0000008DBE14: D5207C0C 00020CC1
	v_mad_u64_u32 v[1:2], null, s1, v7, v[1:2]                 // 0000008DBE1C: D6FE7C01 04060E01
	v_mov_b32_e32 v2, s8                                       // 0000008DBE24: 7E040208
	ds_load_2addr_b32 v[3:4], v3 offset1:7                     // 0000008DBE28: D8DC0700 03000003
	s_waitcnt lgkmcnt(0)                                       // 0000008DBE30: BF89FC07
	v_cndmask_b32_e32 v7, s5, v10, vcc_lo                      // 0000008DBE34: 020E1405
	v_cndmask_b32_e32 v6, v12, v6, vcc_lo                      // 0000008DBE38: 020C0D0C
	.long 0xd73c0000                                           // 0000008DBE3C: D73C0000
	v_cndmask_b32_e32 v1, 1, v0, vcc_lo                        // 0000008DBE40: 02020081
	v_dual_add_f32 v10, 0, v3 :: v_dual_cndmask_b32 v5, v11, v5// 0000008DBE44: C9120680 0A040B0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008DBE4C: BF870111
	v_dual_cndmask_b32 v11, s4, v2 :: v_dual_add_f32 v4, v10, v4// 0000008DBE50: CA480404 0B04090A
	.long 0xd73c0002                                           // 0000008DBE58: D73C0002
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 0000008DBE5C: 02020A81
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DBE60: BF870092
	.long 0xd7006a00                                           // 0000008DBE64: D7006A00
	v_cndmask_b32_e32 v1, v11, v0, vcc_lo                      // 0000008DBE68: 0202010B
	v_add_co_ci_u32_e64 v1, null, v7, v1, vcc_lo               // 0000008DBE6C: D5207C01 01AA0307
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008DBE74: BF870194
	v_bfe_u32 v5, v4, 16, 1                                    // 0000008DBE78: D6100005 02052104
	.long 0xd7006a00                                           // 0000008DBE80: D7006A00
	v_cndmask_b32_e32 v1, v0, v9, vcc_lo                       // 0000008DBE84: 02021300
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008DBE88: BF870191
	v_add_co_ci_u32_e64 v1, null, v1, v8, vcc_lo               // 0000008DBE8C: D5207C01 01AA1101
	v_add3_u32 v4, v4, v5, 0x7fff                              // 0000008DBE94: D6550004 03FE0B04 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008DBEA0: BF870093
	.long 0xd7006a00                                           // 0000008DBEA4: D7006A00
	v_cndmask_b32_e32 v1, v0, v2, vcc_lo                       // 0000008DBEA8: 02020500
	v_add_co_ci_u32_e64 v1, null, v1, v3, vcc_lo               // 0000008DBEAC: D5207C01 01AA0701
	global_store_d16_hi_b16 v[0:1], v4, off                    // 0000008DBEB4: DC960000 007C0400
	s_endpgm                                                   // 0000008DBEBC: BFB00000
		...

