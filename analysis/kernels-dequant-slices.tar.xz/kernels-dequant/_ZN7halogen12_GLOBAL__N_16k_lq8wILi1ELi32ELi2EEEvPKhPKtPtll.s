00000000002df500 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi1ELi32ELi2EEEvPKhPKtPtll>:
; _ZN7halogen12_GLOBAL__N_16k_lq8wILi1ELi32ELi2EEEvPKhPKtPtll():
	s_clause 0x1                                               // 0000002DF500: BF850001
	s_load_b256 s[4:11], s[0:1], null                          // 0000002DF504: F40C0100 F8000000
	s_load_b64 s[12:13], s[0:1], 0x20                          // 0000002DF50C: F4040300 F8000020
	s_mov_b32 s3, 0                                            // 0000002DF514: BE830080
	v_lshrrev_b32_e32 v13, 6, v0                               // 0000002DF518: 321A0086
	s_lshl_b64 s[2:3], s[2:3], 2                               // 0000002DF51C: 84828202
	v_bfe_u32 v14, v0, 5, 1                                    // 0000002DF520: D610000E 02050B00
	v_dual_mov_b32 v16, 0 :: v_dual_and_b32 v15, 31, v0        // 0000002DF528: CA240080 100E009F
	v_mov_b32_e32 v23, 0                                       // 0000002DF530: 7E2E0280
	v_or_b32_e32 v1, s2, v13                                   // 0000002DF534: 38021A02
	v_dual_mov_b32 v2, s3 :: v_dual_mov_b32 v3, 0              // 0000002DF538: CA100003 02020080
	s_waitcnt lgkmcnt(0)                                       // 0000002DF540: BF89FC07
	s_ashr_i32 s0, s11, 31                                     // 0000002DF544: 86009F0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000002DF548: BF8704A1
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 0000002DF54C: 7CA8020C
	s_lshr_b32 s0, s0, 28                                      // 0000002DF550: 85009C00
	s_add_u32 s0, s10, s0                                      // 0000002DF554: 8000000A
	s_addc_u32 s1, s11, 0                                      // 0000002DF558: 8201800B
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002DF55C: BF870009
	s_ashr_i64 s[0:1], s[0:1], 4                               // 0000002DF560: 86808400
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000002DF564: 02020280
	s_add_u32 s14, s0, s10                                     // 0000002DF568: 800E0A00
	s_addc_u32 s1, s1, s11                                     // 0000002DF56C: 82010B01
	s_add_i32 s15, s0, 1                                       // 0000002DF570: 810F8100
	v_cndmask_b32_e64 v2, 0, s3, vcc_lo                        // 0000002DF574: D5010002 01A80680
	s_lshr_b32 s16, s15, 31                                    // 0000002DF57C: 85109F0F
	v_mad_u64_u32 v[9:10], null, v1, s14, s[4:5]               // 0000002DF580: D6FE7C09 00101D01
	s_add_i32 s15, s15, s16                                    // 0000002DF588: 810F100F
	.long 0xd72c0006                                           // 0000002DF58C: D72C0006
	v_cndmask_b32_e32 v0, v1, v1, vcc_lo                       // 0000002DF590: 02000301
	s_ashr_i32 s15, s15, 1                                     // 0000002DF594: 860F810F
	.long 0xd72c0005                                           // 0000002DF598: D72C0005
	v_cndmask_b32_e32 v0, v2, v14, vcc_lo                      // 0000002DF59C: 02001D02
	.long 0xd72c0004                                           // 0000002DF5A0: D72C0004
	v_cndmask_b32_e32 v1, s15, v14, vcc_lo                     // 0000002DF5A4: 02021C0F
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v2, 0               // 0000002DF5A8: CA100080 01020080
	.long 0xd7006a13                                           // 0000002DF5B0: D7006A13
	v_cndmask_b32_e32 v0, v9, v10, vcc_lo                      // 0000002DF5B4: 02001509
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002DF5B8: BF870214
	v_add3_u32 v10, v5, v10, v6                                // 0000002DF5BC: D655000A 041A1505
	v_add_nc_u32_e32 v7, s15, v4                               // 0000002DF5C4: 4A0E080F
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v17, v4, v15     // 0000002DF5C8: CA200080 04101F04
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002DF5D0: BF870193
	v_add_co_ci_u32_e64 v20, null, s11, v10, vcc_lo            // 0000002DF5D4: D5207C14 01AA140B
	v_min_i32_e32 v18, s0, v7                                  // 0000002DF5DC: 22240E00
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002DF5E0: BF870113
	v_lshlrev_b32_e32 v11, 4, v17                              // 0000002DF5E4: 30162284
	v_cmp_lt_i32_e32 vcc_lo, v17, v18                          // 0000002DF5E8: 7C822511
	s_and_saveexec_b32 s1, vcc_lo                              // 0000002DF5EC: BE81206A
	s_cbranch_execz 19                                         // 0000002DF5F0: BFA50013 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi1ELi32ELi2EEEvPKhPKtPtll+0x140>
	v_lshlrev_b32_e32 v1, 4, v17                               // 0000002DF5F4: 30022284
	v_and_b32_e32 v3, -4, v17                                  // 0000002DF5F8: 360622C4
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002DF5FC: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000002DF600: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000002DF604: 3408069F
	.long 0xd7000001                                           // 0000002DF608: D7000001
	v_cndmask_b32_e32 v1, v9, v1, vcc_lo                       // 0000002DF60C: 02020309
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002DF610: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v10, v2, s0                  // 0000002DF614: D5207C02 0002050A
	.long 0xd7000005                                           // 0000002DF61C: D7000005
	v_cndmask_b32_e32 v1, v19, v3, vcc_lo                      // 0000002DF620: 02020713
	v_add_co_ci_u32_e64 v6, null, v20, v4, s0                  // 0000002DF624: D5207C06 00020914
	s_clause 0x1                                               // 0000002DF62C: BF850001
	global_load_b128 v[1:4], v[1:2], off                       // 0000002DF630: DC5E0000 017C0001
	global_load_b32 v23, v[5:6], off                           // 0000002DF638: DC520000 177C0005
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002DF640: 8C7E017E
	s_and_saveexec_b32 s1, vcc_lo                              // 0000002DF644: BE81206A
	s_cbranch_execz 255                                        // 0000002DF648: BFA500FF <_ZN7halogen12_GLOBAL__N_16k_lq8wILi1ELi32ELi2EEEvPKhPKtPtll+0x548>
	v_dual_mov_b32 v16, 0 :: v_dual_add_nc_u32 v21, 0x200, v11 // 0000002DF64C: CA200080 101416FF 00000200
	s_waitcnt vmcnt(0)                                         // 0000002DF658: BF8903F7
	v_mov_b32_e32 v22, v23                                     // 0000002DF65C: 7E2C0317
	s_mov_b32 s4, 0                                            // 0000002DF660: BE840080
	s_branch 217                                               // 0000002DF664: BFA000D9 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi1ELi32ELi2EEEvPKhPKtPtll+0x4cc>
	s_or_b32 exec_lo, exec_lo, s5                              // 0000002DF668: 8C7E057E
	v_ashrrev_i32_e32 v12, 31, v11                             // 0000002DF66C: 3418169F
	v_cvt_f32_ubyte1_e32 v33, v1                               // 0000002DF670: 7E422501
	v_cvt_f32_ubyte2_e32 v34, v1                               // 0000002DF674: 7E442701
	v_cvt_f32_ubyte0_e32 v35, v2                               // 0000002DF678: 7E462302
	v_cvt_f32_ubyte1_e32 v36, v2                               // 0000002DF67C: 7E482502
	.long 0xd73c0018                                           // 0000002DF680: D73C0018
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 0000002DF684: 02021681
	v_cvt_f32_ubyte0_e32 v12, v1                               // 0000002DF688: 7E182301
	v_cvt_f32_ubyte3_e32 v1, v1                                // 0000002DF68C: 7E022901
	v_cvt_f32_ubyte2_e32 v37, v2                               // 0000002DF690: 7E4A2702
	v_cvt_f32_ubyte3_e32 v2, v2                                // 0000002DF694: 7E042902
	v_cvt_f32_ubyte0_e32 v38, v3                               // 0000002DF698: 7E4C2303
	.long 0xd700001c                                           // 0000002DF69C: D700001C
	v_cndmask_b32_e32 v1, s6, v24, vcc_lo                      // 0000002DF6A0: 02023006
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002DF6A4: BF870001
	v_add_co_ci_u32_e64 v29, null, s7, v25, s0                 // 0000002DF6A8: D5207C1D 00023207
	v_cvt_f32_ubyte1_e32 v39, v3                               // 0000002DF6B0: 7E4E2503
	v_cvt_f32_ubyte2_e32 v40, v3                               // 0000002DF6B4: 7E502703
	v_cvt_f32_ubyte3_e32 v3, v3                                // 0000002DF6B8: 7E062903
	s_clause 0x1                                               // 0000002DF6BC: BF850001
	global_load_b128 v[24:27], v[28:29], off                   // 0000002DF6C0: DC5E0000 187C001C
	global_load_b128 v[28:31], v[28:29], off offset:16         // 0000002DF6C8: DC5E0010 1C7C001C
	v_cvt_f32_ubyte0_e32 v41, v4                               // 0000002DF6D0: 7E522304
	v_cvt_f32_ubyte1_e32 v42, v4                               // 0000002DF6D4: 7E542504
	v_cvt_f32_ubyte2_e32 v43, v4                               // 0000002DF6D8: 7E562704
	v_cvt_f32_ubyte3_e32 v4, v4                                // 0000002DF6DC: 7E082904
	v_fma_mix_f32 v12, v12, v23, v23 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002DF6E0: CC20600C 145E2F0C
	v_fma_mix_f32 v33, v33, v23, v23 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002DF6E8: CC206021 145E2F21
	v_fma_mix_f32 v34, v34, v23, v23 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002DF6F0: CC206022 145E2F22
	v_fma_mix_f32 v1, v1, v23, v23 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002DF6F8: CC206001 145E2F01
	v_fma_mix_f32 v35, v35, v23, v23 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002DF700: CC206023 145E2F23
	v_fma_mix_f32 v36, v36, v23, v23 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002DF708: CC206024 145E2F24
	v_fma_mix_f32 v37, v37, v23, v23 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002DF710: CC206025 145E2F25
	v_fma_mix_f32 v2, v2, v23, v23 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002DF718: CC206002 145E2F02
	v_fma_mix_f32 v38, v38, v23, v23 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002DF720: CC206026 145E2F26
	v_fma_mix_f32 v39, v39, v23, v23 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002DF728: CC206027 145E2F27
	v_fma_mix_f32 v40, v40, v23, v23 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002DF730: CC206028 145E2F28
	v_fma_mix_f32 v3, v3, v23, v23 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002DF738: CC206003 145E2F03
	v_fma_mix_f32 v41, v41, v23, v23 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002DF740: CC206029 145E2F29
	v_fma_mix_f32 v42, v42, v23, v23 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002DF748: CC20602A 145E2F2A
	v_fma_mix_f32 v43, v43, v23, v23 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002DF750: CC20602B 145E2F2B
	v_fma_mix_f32 v4, v4, v23, v23 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002DF758: CC206004 145E2F04
	v_bfe_u32 v23, v12, 16, 1                                  // 0000002DF760: D6100017 0205210C
	v_bfe_u32 v47, v33, 16, 1                                  // 0000002DF768: D610002F 02052121
	v_bfe_u32 v48, v34, 16, 1                                  // 0000002DF770: D6100030 02052122
	.long 0x7f403880                                           // 0000002DF778: 7F403880
	v_bfe_u32 v49, v1, 16, 1                                   // 0000002DF77C: D6100031 02052101
	v_add3_u32 v12, v12, v23, 0x7fff                           // 0000002DF784: D655000C 03FE2F0C 00007FFF
	v_bfe_u32 v50, v35, 16, 1                                  // 0000002DF790: D6100032 02052123
	v_add3_u32 v34, v34, v48, 0x7fff                           // 0000002DF798: D6550022 03FE6122 00007FFF
	v_add3_u32 v33, v33, v47, 0x7fff                           // 0000002DF7A4: D6550021 03FE5F21 00007FFF
	.long 0x7f5839a0                                           // 0000002DF7B0: 7F5839A0
	.long 0x7e40398c                                           // 0000002DF7B4: 7E40398C
	v_bfe_u32 v51, v36, 16, 1                                  // 0000002DF7B8: D6100033 02052124
	v_bfe_u32 v52, v37, 16, 1                                  // 0000002DF7C0: D6100034 02052125
	v_add3_u32 v1, v1, v49, 0x7fff                             // 0000002DF7C8: D6550001 03FE6301 00007FFF
	.long 0x7e5839a2                                           // 0000002DF7D4: 7E5839A2
	v_add3_u32 v34, v35, v50, 0x7fff                           // 0000002DF7D8: D6550022 03FE6523 00007FFF
	v_and_or_b32 v33, 0xffff0000, v33, v32                     // 0000002DF7E4: D6570021 048242FF FFFF0000
	v_bfe_u32 v53, v2, 16, 1                                   // 0000002DF7F0: D6100035 02052102
	v_bfe_u32 v54, v38, 16, 1                                  // 0000002DF7F8: D6100036 02052126
	v_add3_u32 v35, v36, v51, 0x7fff                           // 0000002DF800: D6550023 03FE6724 00007FFF
	v_add3_u32 v36, v37, v52, 0x7fff                           // 0000002DF80C: D6550024 03FE6925 00007FFF
	v_and_or_b32 v1, 0xffff0000, v1, v44                       // 0000002DF818: D6570001 04B202FF FFFF0000
	.long 0x7e4039a2                                           // 0000002DF824: 7E4039A2
	.long 0x7f5a39a0                                           // 0000002DF828: 7F5A39A0
	v_bfe_u32 v55, v39, 16, 1                                  // 0000002DF82C: D6100037 02052127
	v_bfe_u32 v56, v40, 16, 1                                  // 0000002DF834: D6100038 02052128
	v_add3_u32 v2, v2, v53, 0x7fff                             // 0000002DF83C: D6550002 03FE6B02 00007FFF
	.long 0x7e5a39a4                                           // 0000002DF848: 7E5A39A4
	v_and_or_b32 v34, 0xffff0000, v35, v32                     // 0000002DF84C: D6570022 048246FF FFFF0000
	v_bfe_u32 v57, v3, 16, 1                                   // 0000002DF858: D6100039 02052103
	v_bfe_u32 v58, v41, 16, 1                                  // 0000002DF860: D610003A 02052129
	.long 0x7f5c39a0                                           // 0000002DF868: 7F5C39A0
	v_and_or_b32 v2, 0xffff0000, v2, v45                       // 0000002DF86C: D6570002 04B604FF FFFF0000
	v_bfe_u32 v23, v42, 16, 1                                  // 0000002DF878: D6100017 0205212A
	v_bfe_u32 v59, v43, 16, 1                                  // 0000002DF880: D610003B 0205212B
	v_add3_u32 v3, v3, v57, 0x7fff                             // 0000002DF888: D6550003 03FE7303 00007FFF
	v_bfe_u32 v12, v4, 16, 1                                   // 0000002DF894: D610000C 02052104
	v_add_nc_u32_e32 v21, 0x200, v21                           // 0000002DF89C: 4A2A2AFF 00000200
	v_add_nc_u32_e32 v11, 0x200, v11                           // 0000002DF8A4: 4A1616FF 00000200
	s_and_b32 s0, exec_lo, vcc_lo                              // 0000002DF8AC: 8B006A7E
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000002DF8B0: BF870153
	v_add3_u32 v4, v4, v12, 0x7fff                             // 0000002DF8B4: D6550004 03FE1904 00007FFF
	s_or_b32 s4, s0, s4                                        // 0000002DF8C0: 8C040400
	s_waitcnt vmcnt(1)                                         // 0000002DF8C4: BF8907F7
	v_dot2_f32_bf16 v24, v24, v33, 0                           // 0000002DF8C8: CC1A4018 1A024318
	v_add3_u32 v33, v38, v54, 0x7fff                           // 0000002DF8D0: D6550021 03FE6D26 00007FFF
	v_dot2_f32_bf16 v1, v25, v1, v24                           // 0000002DF8DC: CC1A4001 1C620319
	v_add3_u32 v24, v39, v55, 0x7fff                           // 0000002DF8E4: D6550018 03FE6F27 00007FFF
	v_add3_u32 v25, v40, v56, 0x7fff                           // 0000002DF8F0: D6550019 03FE7128 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002DF8FC: BF870214
	.long 0x7e4039a1                                           // 0000002DF900: 7E4039A1
	v_dot2_f32_bf16 v1, v26, v34, v1                           // 0000002DF904: CC1A4001 1C06451A
	v_add3_u32 v26, v41, v58, 0x7fff                           // 0000002DF90C: D655001A 03FE7529 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002DF918: BF870214
	.long 0x7e5c3999                                           // 0000002DF91C: 7E5C3999
	v_and_or_b32 v24, 0xffff0000, v24, v32                     // 0000002DF920: D6570018 048230FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4)                            // 0000002DF92C: BF870004
	v_dot2_f32_bf16 v1, v27, v2, v1                            // 0000002DF930: CC1A4001 1C06051B
	v_add3_u32 v2, v42, v23, 0x7fff                            // 0000002DF938: D6550002 03FE2F2A 00007FFF
	v_add3_u32 v23, v43, v59, 0x7fff                           // 0000002DF944: D6550017 03FE772B 00007FFF
	v_and_or_b32 v3, 0xffff0000, v3, v46                       // 0000002DF950: D6570003 04BA06FF FFFF0000
	.long 0x7e40399a                                           // 0000002DF95C: 7E40399A
	s_waitcnt vmcnt(0)                                         // 0000002DF960: BF8903F7
	v_dot2_f32_bf16 v1, v28, v24, v1                           // 0000002DF964: CC1A4001 1C06311C
	.long 0x7f3039a0                                           // 0000002DF96C: 7F3039A0
	.long 0x7e303997                                           // 0000002DF970: 7E303997
	v_mov_b32_e32 v23, v22                                     // 0000002DF974: 7E2E0316
	v_and_or_b32 v2, 0xffff0000, v2, v32                       // 0000002DF978: D6570002 048204FF FFFF0000
	v_dot2_f32_bf16 v1, v29, v3, v1                            // 0000002DF984: CC1A4001 1C06071D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002DF98C: BF8701A4
	v_and_or_b32 v3, 0xffff0000, v4, v24                       // 0000002DF990: D6570003 046208FF FFFF0000
	v_mov_b32_e32 v4, v8                                       // 0000002DF99C: 7E080308
	v_dot2_f32_bf16 v1, v30, v2, v1                            // 0000002DF9A0: CC1A4001 1C06051E
	v_mov_b32_e32 v2, v6                                       // 0000002DF9A8: 7E040306
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002DF9AC: BF870122
	v_dot2_f32_bf16 v8, v31, v3, v1                            // 0000002DF9B0: CC1A4008 1C06071F
	v_mov_b32_e32 v3, v7                                       // 0000002DF9B8: 7E060307
	v_dual_mov_b32 v1, v5 :: v_dual_add_f32 v16, v16, v8       // 0000002DF9BC: CA080105 01101110
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000002DF9C4: 917E047E
	s_cbranch_execz 30                                         // 0000002DF9C8: BFA5001E <_ZN7halogen12_GLOBAL__N_16k_lq8wILi1ELi32ELi2EEEvPKhPKtPtll+0x544>
	v_dual_mov_b32 v6, v2 :: v_dual_add_nc_u32 v17, 32, v17    // 0000002DF9CC: CA200102 061022A0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000002DF9D4: BF8701B2
	v_dual_mov_b32 v5, v1 :: v_dual_mov_b32 v8, v4             // 0000002DF9D8: CA100101 05080104
	v_mov_b32_e32 v7, v3                                       // 0000002DF9E0: 7E0E0303
	s_mov_b32 s5, exec_lo                                      // 0000002DF9E4: BE85007E
	v_cmp_ge_i32_e32 vcc_lo, v17, v18                          // 0000002DF9E8: 7C8C2511
	.long 0xd4c1007e                                           // 0000002DF9EC: D4C1007E
	v_cndmask_b32_e32 v1, v17, v18, vcc_lo                     // 0000002DF9F0: 02022511
	s_cbranch_execz 65308                                      // 0000002DF9F4: BFA5FF1C <_ZN7halogen12_GLOBAL__N_16k_lq8wILi1ELi32ELi2EEEvPKhPKtPtll+0x168>
	v_and_b32_e32 v7, -4, v17                                  // 0000002DF9F8: 360E22C4
	v_ashrrev_i32_e32 v6, 31, v21                              // 0000002DF9FC: 340C2A9F
	.long 0xd7000005                                           // 0000002DFA00: D7000005
	v_cndmask_b32_e32 v1, v9, v21, vcc_lo                      // 0000002DFA04: 02022B09
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002DFA08: BF870193
	v_ashrrev_i32_e32 v8, 31, v7                               // 0000002DFA0C: 34100E9F
	v_add_co_ci_u32_e64 v6, null, v10, v6, s0                  // 0000002DFA10: D5207C06 00020D0A
	.long 0xd7000018                                           // 0000002DFA18: D7000018
	v_cndmask_b32_e32 v1, v19, v7, vcc_lo                      // 0000002DFA1C: 02020F13
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002DFA20: BF870001
	v_add_co_ci_u32_e64 v25, null, v20, v8, s0                 // 0000002DFA24: D5207C19 00021114
	s_clause 0x1                                               // 0000002DFA2C: BF850001
	global_load_b128 v[5:8], v[5:6], off                       // 0000002DFA30: DC5E0000 057C0005
	global_load_b32 v22, v[24:25], off                         // 0000002DFA38: DC520000 167C0018
	s_branch 65289                                             // 0000002DFA40: BFA0FF09 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi1ELi32ELi2EEEvPKhPKtPtll+0x168>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000002DFA44: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000002DFA48: BF8700C9
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002DFA4C: 8C7E017E
	s_waitcnt vmcnt(1)                                         // 0000002DFA50: BF8907F7
	.long 0xd71f0001                                           // 0000002DFA54: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000002DFA58: 020100C1
	s_mov_b32 s0, exec_lo                                      // 0000002DFA5C: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 0000002DFA60: 3A040290
	v_xor_b32_e32 v3, 8, v1                                    // 0000002DFA64: 3A060288
	v_xor_b32_e32 v4, 4, v1                                    // 0000002DFA68: 3A080284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000002DFA6C: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000002DFA70: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 0000002DFA74: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v3                            // 0000002DFA78: 7C9806A0
	v_cndmask_b32_e32 v3, v1, v3, vcc_lo                       // 0000002DFA7C: 02060701
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 0000002DFA80: 7C9808A0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002DFA84: BF870002
	v_lshlrev_b32_e32 v3, 2, v3                                // 0000002DFA88: 30060682
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000002DFA8C: 30040482
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo                       // 0000002DFA90: 02080901
	ds_bpermute_b32 v2, v2, v16                                // 0000002DFA94: DACC0000 02001002
	v_lshlrev_b32_e32 v4, 2, v4                                // 0000002DFA9C: 30080882
	s_waitcnt lgkmcnt(0)                                       // 0000002DFAA0: BF89FC07
	v_add_f32_e32 v2, v16, v2                                  // 0000002DFAA4: 06040510
	ds_bpermute_b32 v3, v3, v2                                 // 0000002DFAA8: DACC0000 03000203
	s_waitcnt lgkmcnt(0)                                       // 0000002DFAB0: BF89FC07
	v_add_f32_e32 v2, v2, v3                                   // 0000002DFAB4: 06040702
	ds_bpermute_b32 v3, v4, v2                                 // 0000002DFAB8: DACC0000 03000204
	v_xor_b32_e32 v4, 2, v1                                    // 0000002DFAC0: 3A080282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002DFAC4: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 0000002DFAC8: 7C9808A0
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo                       // 0000002DFACC: 02080901
	v_lshlrev_b32_e32 v4, 2, v4                                // 0000002DFAD0: 30080882
	s_waitcnt lgkmcnt(0)                                       // 0000002DFAD4: BF89FC07
	v_add_f32_e32 v2, v2, v3                                   // 0000002DFAD8: 06040702
	ds_bpermute_b32 v3, v4, v2                                 // 0000002DFADC: DACC0000 03000204
	v_xor_b32_e32 v4, 1, v1                                    // 0000002DFAE4: 3A080281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002DFAE8: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 0000002DFAEC: 7C9808A0
	s_waitcnt lgkmcnt(0)                                       // 0000002DFAF0: BF89FC07
	v_dual_cndmask_b32 v4, v1, v4 :: v_dual_add_f32 v1, v2, v3 // 0000002DFAF4: CA480901 04000702
	v_lshlrev_b32_e32 v2, 2, v4                                // 0000002DFAFC: 30040882
	ds_bpermute_b32 v2, v2, v1                                 // 0000002DFB00: DACC0000 02000102
	v_cmpx_eq_u32_e32 0, v15                                   // 0000002DFB08: 7D941E80
	s_cbranch_execz 8                                          // 0000002DFB0C: BFA50008 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi1ELi32ELi2EEEvPKhPKtPtll+0x630>
	v_lshlrev_b32_e32 v3, 2, v14                               // 0000002DFB10: 30061C82
	s_waitcnt lgkmcnt(0)                                       // 0000002DFB14: BF89FC07
	v_add_f32_e32 v1, v1, v2                                   // 0000002DFB18: 06020501
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002DFB1C: BF870002
	v_lshl_or_b32 v2, v13, 3, v3                               // 0000002DFB20: D6560002 040D070D
	ds_store_b32 v2, v1                                        // 0000002DFB28: D8340000 00000102
	s_or_b32 exec_lo, exec_lo, s0                              // 0000002DFB30: 8C7E007E
	v_or_b32_e32 v1, s2, v0                                    // 0000002DFB34: 38020002
	s_waitcnt lgkmcnt(0)                                       // 0000002DFB38: BF89FC07
	v_mov_b32_e32 v2, s3                                       // 0000002DFB3C: 7E040203
	.long 0xd44c0000                                           // 0000002DFB40: D44C0000
	v_cndmask_b32_e32 v1, 4, v0, vcc_lo                        // 0000002DFB44: 02020084
	s_waitcnt vmcnt(0)                                         // 0000002DFB48: BF8903F7
	s_barrier                                                  // 0000002DFB4C: BFBD0000
	buffer_gl0_inv                                             // 0000002DFB50: E0AC0000 00000000
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 0000002DFB58: 7CA8020C
	s_and_b32 s0, s0, vcc_lo                                   // 0000002DFB5C: 8B006A00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002DFB60: BF870009
	s_and_saveexec_b32 s1, s0                                  // 0000002DFB64: BE812000
	s_cbranch_execz 22                                         // 0000002DFB68: BFA50016 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi1ELi32ELi2EEEvPKhPKtPtll+0x6c4>
	v_lshlrev_b32_e32 v0, 3, v0                                // 0000002DFB6C: 30000083
	ds_load_b64 v[3:4], v0                                     // 0000002DFB70: D9D80000 03000000
	s_waitcnt lgkmcnt(0)                                       // 0000002DFB78: BF89FC07
	v_add_f32_e32 v0, 0, v3                                    // 0000002DFB7C: 06000680
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002DFB80: BF870121
	v_add_f32_e32 v3, v0, v4                                   // 0000002DFB84: 06060900
	.long 0xd73c0000                                           // 0000002DFB88: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000002DFB8C: 02020281
	v_bfe_u32 v4, v3, 16, 1                                    // 0000002DFB90: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002DFB98: BF870092
	.long 0xd7006a00                                           // 0000002DFB9C: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 0000002DFBA0: 02020008
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 0000002DFBA4: D5207C01 01AA0209
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002DFBAC: BF870003
	v_add3_u32 v2, v3, v4, 0x7fff                              // 0000002DFBB0: D6550002 03FE0903 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off                    // 0000002DFBBC: DC960000 007C0200
	s_endpgm                                                   // 0000002DFBC4: BFB00000
		...

