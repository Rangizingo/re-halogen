00000000007bb600 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[8:23], s[0:1], null                          // 0000007BB600: F4100200 F8000000
	v_and_b32_e32 v1, 15, v0                                   // 0000007BB608: 3602008F
	v_lshrrev_b32_e32 v2, 2, v0                                // 0000007BB60C: 32040082
	s_ashr_i32 s3, s2, 31                                      // 0000007BB610: 86039F02
	v_lshrrev_b32_e32 v3, 5, v0                                // 0000007BB614: 32060085
	s_lshl_b64 s[2:3], s[2:3], 3                               // 0000007BB618: 84828302
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000007BB61C: 30020282
	v_dual_mov_b32 v17, s3 :: v_dual_and_b32 v2, 60, v2        // 0000007BB620: CA240003 110204BC
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007BB628: BF870003
	v_or_b32_e32 v16, s2, v3                                   // 0000007BB62C: 38200602
	.long 0x7f063880                                           // 0000007BB630: 7F063880
	v_and_b32_e32 v23, 31, v0                                  // 0000007BB634: 362E009F
	v_lshlrev_b32_e32 v0, 2, v0                                // 0000007BB638: 30000082
	s_waitcnt lgkmcnt(0)                                       // 0000007BB63C: BF89FC07
	s_clause 0x1                                               // 0000007BB640: BF850001
	global_load_b32 v1, v1, s[8:9]                             // 0000007BB644: DC520000 01080001
	global_load_b32 v2, v2, s[8:9]                             // 0000007BB64C: DC520000 02080002
	.long 0xd4540002                                           // 0000007BB654: D4540002
	v_cndmask_b32_e32 v1, s16, v16, vcc_lo                     // 0000007BB658: 02022010
	s_add_u32 s16, s8, s20                                     // 0000007BB65C: 80101408
	s_addc_u32 s17, s9, s21                                    // 0000007BB660: 82111509
	s_ashr_i32 s4, s15, 31                                     // 0000007BB664: 86049F0F
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000007BB668: BF870159
	s_lshr_b32 s4, s4, 27                                      // 0000007BB66C: 85049B04
	v_cndmask_b32_e64 v8, 0, v16, s2                           // 0000007BB670: D5010008 000A2080
	v_cndmask_b32_e64 v9, 0, s3, s2                            // 0000007BB678: D5010009 00080680
	s_add_u32 s4, s14, s4                                      // 0000007BB680: 8004040E
	s_addc_u32 s5, s15, 0                                      // 0000007BB684: 8205800F
	.long 0xd72c0004                                           // 0000007BB688: D72C0004
	v_cndmask_b32_e32 v1, s23, v8, vcc_lo                      // 0000007BB68C: 02021017
	v_mad_u64_u32 v[12:13], null, s22, v8, 0                   // 0000007BB690: D6FE7C0C 02021016
	s_lshr_b64 s[6:7], s[4:5], 5                               // 0000007BB698: 85868504
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000007BB69C: BF870009
	s_cmpk_lt_i32 s6, 0x101                                    // 0000007BB6A0: B3860101
	.long 0xd4440004                                           // 0000007BB6A4: D4440004
	v_cndmask_b32_e32 v1, s6, v23, vcc_lo                      // 0000007BB6A8: 02022E06
	s_cselect_b32 s3, -1, 0                                    // 0000007BB6AC: 980380C1
	s_cmpk_gt_i32 s6, 0x100                                    // 0000007BB6B0: B2860100
	.long 0xd700050e                                           // 0000007BB6B4: D700050E
	v_cndmask_b32_e32 v1, s16, v12, vcc_lo                     // 0000007BB6B8: 02021810
	s_cselect_b32 s7, -1, 0                                    // 0000007BB6BC: 980780C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000007BB6C0: BF870159
	s_and_b32 vcc_lo, exec_lo, s7                              // 0000007BB6C4: 8B6A077E
	s_waitcnt vmcnt(1)                                         // 0000007BB6C8: BF8907F7
	v_bfe_u32 v5, v1, 16, 1                                    // 0000007BB6CC: D6100005 02052101
	s_waitcnt vmcnt(0)                                         // 0000007BB6D4: BF8903F7
	v_bfe_u32 v6, v2, 16, 1                                    // 0000007BB6D8: D6100006 02052102
	v_add3_u32 v1, v1, v5, 0x7fff                              // 0000007BB6E0: D6550001 03FE0B01 00007FFF
	.long 0xd72c0005                                           // 0000007BB6EC: D72C0005
	v_cndmask_b32_e32 v1, s22, v9, vcc_lo                      // 0000007BB6F0: 02021216
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007BB6F4: BF870193
	v_add3_u32 v2, v2, v6, 0x7fff                              // 0000007BB6F8: D6550002 03FE0D02 00007FFF
	.long 0x7e063981                                           // 0000007BB704: 7E063981
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007BB708: BF870113
	v_add3_u32 v13, v13, v5, v4                                // 0000007BB70C: D655000D 04120B0D
	v_and_or_b32 v1, 0xffff0000, v2, v3                        // 0000007BB714: D6570001 040E04FF FFFF0000
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007BB720: BF870002
	v_add_co_ci_u32_e64 v15, null, s17, v13, s5                // 0000007BB724: D5207C0F 00161A11
	ds_store_b32 v0, v1                                        // 0000007BB72C: D8340000 00000100
	s_waitcnt lgkmcnt(0)                                       // 0000007BB734: BF89FC07
	s_barrier                                                  // 0000007BB738: BFBD0000
	buffer_gl0_inv                                             // 0000007BB73C: E0AC0000 00000000
	s_cbranch_vccnz 146                                        // 0000007BB744: BFA40092 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x390>
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v0, 0               // 0000007BB748: CA100080 01000080
	s_and_saveexec_b32 s5, s4                                  // 0000007BB750: BE852004
	s_cbranch_execz 10                                         // 0000007BB754: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x180>
	v_lshlrev_b32_e32 v0, 1, v23                               // 0000007BB758: 30002E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BB75C: BF870091
	.long 0xd7006a02                                           // 0000007BB760: D7006A02
	v_cndmask_b32_e32 v1, v14, v0, vcc_lo                      // 0000007BB764: 0202010E
	v_add_co_ci_u32_e64 v3, null, 0, v15, vcc_lo               // 0000007BB768: D5207C03 01AA1E80
	global_load_d16_b16 v0, v[2:3], off                        // 0000007BB770: DC820000 007C0002
	s_waitcnt vmcnt(0)                                         // 0000007BB778: BF8903F7
	v_cvt_f32_f16_e32 v0, v0                                   // 0000007BB77C: 7E001700
	s_or_b32 exec_lo, exec_lo, s5                              // 0000007BB780: 8C7E057E
	v_or_b32_e32 v2, 32, v23                                   // 0000007BB784: 38042EA0
	s_mov_b32 s4, exec_lo                                      // 0000007BB788: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007BB78C: BF870001
	.long 0xd4c4007e                                           // 0000007BB790: D4C4007E
	v_cndmask_b32_e32 v1, s6, v2, vcc_lo                       // 0000007BB794: 02020406
	s_cbranch_execz 10                                         // 0000007BB798: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x1c4>
	v_lshlrev_b32_e32 v1, 1, v2                                // 0000007BB79C: 30020481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BB7A0: BF870091
	.long 0xd7006a01                                           // 0000007BB7A4: D7006A01
	v_cndmask_b32_e32 v1, v14, v1, vcc_lo                      // 0000007BB7A8: 0202030E
	v_add_co_ci_u32_e64 v2, null, 0, v15, vcc_lo               // 0000007BB7AC: D5207C02 01AA1E80
	global_load_d16_b16 v1, v[1:2], off                        // 0000007BB7B4: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000007BB7BC: BF8903F7
	v_cvt_f32_f16_e32 v1, v1                                   // 0000007BB7C0: 7E021701
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007BB7C4: 8C7E047E
	v_or_b32_e32 v4, 64, v23                                   // 0000007BB7C8: 38082EC0
	v_dual_mov_b32 v3, 0 :: v_dual_mov_b32 v2, 0               // 0000007BB7CC: CA100080 03020080
	s_mov_b32 s4, exec_lo                                      // 0000007BB7D4: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007BB7D8: BF870002
	.long 0xd4c4007e                                           // 0000007BB7DC: D4C4007E
	v_cndmask_b32_e32 v1, s6, v4, vcc_lo                       // 0000007BB7E0: 02020806
	s_cbranch_execz 10                                         // 0000007BB7E4: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x210>
	v_lshlrev_b32_e32 v2, 1, v4                                // 0000007BB7E8: 30040881
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BB7EC: BF870091
	.long 0xd7006a04                                           // 0000007BB7F0: D7006A04
	v_cndmask_b32_e32 v1, v14, v2, vcc_lo                      // 0000007BB7F4: 0202050E
	v_add_co_ci_u32_e64 v5, null, 0, v15, vcc_lo               // 0000007BB7F8: D5207C05 01AA1E80
	global_load_d16_b16 v2, v[4:5], off                        // 0000007BB800: DC820000 027C0004
	s_waitcnt vmcnt(0)                                         // 0000007BB808: BF8903F7
	v_cvt_f32_f16_e32 v2, v2                                   // 0000007BB80C: 7E041702
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007BB810: 8C7E047E
	v_or_b32_e32 v4, 0x60, v23                                 // 0000007BB814: 38082EFF 00000060
	s_mov_b32 s4, exec_lo                                      // 0000007BB81C: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007BB820: BF870001
	.long 0xd4c4007e                                           // 0000007BB824: D4C4007E
	v_cndmask_b32_e32 v1, s6, v4, vcc_lo                       // 0000007BB828: 02020806
	s_cbranch_execz 10                                         // 0000007BB82C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x258>
	v_lshlrev_b32_e32 v3, 1, v4                                // 0000007BB830: 30060881
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BB834: BF870091
	.long 0xd7006a03                                           // 0000007BB838: D7006A03
	v_cndmask_b32_e32 v1, v14, v3, vcc_lo                      // 0000007BB83C: 0202070E
	v_add_co_ci_u32_e64 v4, null, 0, v15, vcc_lo               // 0000007BB840: D5207C04 01AA1E80
	global_load_d16_b16 v3, v[3:4], off                        // 0000007BB848: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 0000007BB850: BF8903F7
	v_cvt_f32_f16_e32 v3, v3                                   // 0000007BB854: 7E061703
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007BB858: 8C7E047E
	v_or_b32_e32 v6, 0x80, v23                                 // 0000007BB85C: 380C2EFF 00000080
	v_dual_mov_b32 v5, 0 :: v_dual_mov_b32 v4, 0               // 0000007BB864: CA100080 05040080
	s_mov_b32 s4, exec_lo                                      // 0000007BB86C: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007BB870: BF870002
	.long 0xd4c4007e                                           // 0000007BB874: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 0000007BB878: 02020C06
	s_cbranch_execz 10                                         // 0000007BB87C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x2a8>
	v_lshlrev_b32_e32 v4, 1, v6                                // 0000007BB880: 30080C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BB884: BF870091
	.long 0xd7006a06                                           // 0000007BB888: D7006A06
	v_cndmask_b32_e32 v1, v14, v4, vcc_lo                      // 0000007BB88C: 0202090E
	v_add_co_ci_u32_e64 v7, null, 0, v15, vcc_lo               // 0000007BB890: D5207C07 01AA1E80
	global_load_d16_b16 v4, v[6:7], off                        // 0000007BB898: DC820000 047C0006
	s_waitcnt vmcnt(0)                                         // 0000007BB8A0: BF8903F7
	v_cvt_f32_f16_e32 v4, v4                                   // 0000007BB8A4: 7E081704
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007BB8A8: 8C7E047E
	v_or_b32_e32 v6, 0xa0, v23                                 // 0000007BB8AC: 380C2EFF 000000A0
	s_mov_b32 s4, exec_lo                                      // 0000007BB8B4: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007BB8B8: BF870001
	.long 0xd4c4007e                                           // 0000007BB8BC: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 0000007BB8C0: 02020C06
	s_cbranch_execz 10                                         // 0000007BB8C4: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x2f0>
	v_lshlrev_b32_e32 v5, 1, v6                                // 0000007BB8C8: 300A0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BB8CC: BF870091
	.long 0xd7006a05                                           // 0000007BB8D0: D7006A05
	v_cndmask_b32_e32 v1, v14, v5, vcc_lo                      // 0000007BB8D4: 02020B0E
	v_add_co_ci_u32_e64 v6, null, 0, v15, vcc_lo               // 0000007BB8D8: D5207C06 01AA1E80
	global_load_d16_b16 v5, v[5:6], off                        // 0000007BB8E0: DC820000 057C0005
	s_waitcnt vmcnt(0)                                         // 0000007BB8E8: BF8903F7
	v_cvt_f32_f16_e32 v5, v5                                   // 0000007BB8EC: 7E0A1705
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007BB8F0: 8C7E047E
	v_or_b32_e32 v10, 0xc0, v23                                // 0000007BB8F4: 38142EFF 000000C0
	v_dual_mov_b32 v7, 0 :: v_dual_mov_b32 v6, 0               // 0000007BB8FC: CA100080 07060080
	s_mov_b32 s4, exec_lo                                      // 0000007BB904: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007BB908: BF870002
	.long 0xd4c4007e                                           // 0000007BB90C: D4C4007E
	v_cndmask_b32_e32 v1, s6, v10, vcc_lo                      // 0000007BB910: 02021406
	s_cbranch_execz 10                                         // 0000007BB914: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x340>
	v_lshlrev_b32_e32 v6, 1, v10                               // 0000007BB918: 300C1481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BB91C: BF870091
	.long 0xd7006a0a                                           // 0000007BB920: D7006A0A
	v_cndmask_b32_e32 v1, v14, v6, vcc_lo                      // 0000007BB924: 02020D0E
	v_add_co_ci_u32_e64 v11, null, 0, v15, vcc_lo              // 0000007BB928: D5207C0B 01AA1E80
	global_load_d16_b16 v6, v[10:11], off                      // 0000007BB930: DC820000 067C000A
	s_waitcnt vmcnt(0)                                         // 0000007BB938: BF8903F7
	v_cvt_f32_f16_e32 v6, v6                                   // 0000007BB93C: 7E0C1706
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007BB940: 8C7E047E
	v_or_b32_e32 v10, 0xe0, v23                                // 0000007BB944: 38142EFF 000000E0
	s_mov_b32 s4, exec_lo                                      // 0000007BB94C: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007BB950: BF870001
	.long 0xd4c4007e                                           // 0000007BB954: D4C4007E
	v_cndmask_b32_e32 v1, s6, v10, vcc_lo                      // 0000007BB958: 02021406
	s_cbranch_execz 10                                         // 0000007BB95C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x388>
	v_lshlrev_b32_e32 v7, 1, v10                               // 0000007BB960: 300E1481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BB964: BF870091
	.long 0xd7006a0a                                           // 0000007BB968: D7006A0A
	v_cndmask_b32_e32 v1, v14, v7, vcc_lo                      // 0000007BB96C: 02020F0E
	v_add_co_ci_u32_e64 v11, null, 0, v15, vcc_lo              // 0000007BB970: D5207C0B 01AA1E80
	global_load_d16_b16 v7, v[10:11], off                      // 0000007BB978: DC820000 077C000A
	s_waitcnt vmcnt(0)                                         // 0000007BB980: BF8903F7
	v_cvt_f32_f16_e32 v7, v7                                   // 0000007BB984: 7E0E1707
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007BB988: 8C7E047E
	s_branch 9                                                 // 0000007BB98C: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x3b4>
	v_mov_b32_e32 v0, 0                                        // 0000007BB990: 7E000280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007BB994: BF870001
	v_mov_b32_e32 v1, v0                                       // 0000007BB998: 7E020300
	v_mov_b32_e32 v2, v0                                       // 0000007BB99C: 7E040300
	v_mov_b32_e32 v3, v0                                       // 0000007BB9A0: 7E060300
	v_mov_b32_e32 v4, v0                                       // 0000007BB9A4: 7E080300
	v_mov_b32_e32 v5, v0                                       // 0000007BB9A8: 7E0A0300
	v_mov_b32_e32 v6, v0                                       // 0000007BB9AC: 7E0C0300
	v_mov_b32_e32 v7, v0                                       // 0000007BB9B0: 7E0E0300
	s_add_u32 s4, s8, s18                                      // 0000007BB9B4: 80041208
	s_addc_u32 s5, s9, s19                                     // 0000007BB9B8: 82051309
	s_lshr_b32 s16, s15, 31                                    // 0000007BB9BC: 85109F0F
	v_mov_b32_e32 v26, 0                                       // 0000007BB9C0: 7E340280
	s_add_u32 s14, s14, s16                                    // 0000007BB9C4: 800E100E
	s_addc_u32 s15, s15, 0                                     // 0000007BB9C8: 820F800F
	v_cndmask_b32_e64 v24, 0, 1, s7                            // 0000007BB9CC: D5010018 001D0280
	s_ashr_i64 s[14:15], s[14:15], 1                           // 0000007BB9D4: 868E810E
	v_mov_b32_e32 v27, 0                                       // 0000007BB9D8: 7E360280
	v_mad_u64_u32 v[18:19], null, v8, s14, s[4:5]              // 0000007BB9DC: D6FE7C12 00101D08
	.long 0xd72c000b                                           // 0000007BB9E4: D72C000B
	v_cndmask_b32_e32 v0, v8, v15, vcc_lo                      // 0000007BB9E8: 02001F08
	.long 0xd72c0014                                           // 0000007BB9EC: D72C0014
	v_cndmask_b32_e32 v0, v9, v14, vcc_lo                      // 0000007BB9F0: 02001D09
	.long 0xd4440004                                           // 0000007BB9F4: D4440004
	v_cndmask_b32_e32 v1, s6, v23, vcc_lo                      // 0000007BB9F8: 02022E06
	v_dual_mov_b32 v8, 0 :: v_dual_mov_b32 v9, 0               // 0000007BB9FC: CA100080 08080080
	v_mov_b32_e32 v10, 0                                       // 0000007BBA04: 7E140280
	s_delay_alu instid0(VALU_DEP_4)                            // 0000007BBA08: BF870004
	v_add3_u32 v25, v20, v19, v11                              // 0000007BBA0C: D6550019 042E2714
	v_mov_b32_e32 v11, 0                                       // 0000007BBA14: 7E160280
	s_and_saveexec_b32 s5, s4                                  // 0000007BBA18: BE852004
	s_cbranch_execz 21                                         // 0000007BBA1C: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x474>
	v_dual_mov_b32 v27, 0 :: v_dual_lshlrev_b32 v8, 4, v23     // 0000007BBA20: CA220080 1B082E84
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BBA28: BF870091
	.long 0xd7006a08                                           // 0000007BBA2C: D7006A08
	v_cndmask_b32_e32 v1, v18, v8, vcc_lo                      // 0000007BBA30: 02021112
	v_add_co_ci_u32_e64 v9, null, 0, v25, vcc_lo               // 0000007BBA34: D5207C09 01AA3280
	s_and_not1_b32 vcc_lo, exec_lo, s7                         // 0000007BBA3C: 916A077E
	global_load_b128 v[8:11], v[8:9], off                      // 0000007BBA40: DC5E0000 087C0008
	s_cbranch_vccnz 10                                         // 0000007BBA48: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x474>
	v_lshlrev_b32_e32 v19, 1, v23                              // 0000007BBA4C: 30262E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BBA50: BF870091
	.long 0xd7006a0e                                           // 0000007BBA54: D7006A0E
	v_cndmask_b32_e32 v1, v14, v19, vcc_lo                     // 0000007BBA58: 0202270E
	v_add_co_ci_u32_e64 v15, null, 0, v15, vcc_lo              // 0000007BBA5C: D5207C0F 01AA1E80
	global_load_d16_b16 v14, v[14:15], off                     // 0000007BBA64: DC820000 0E7C000E
	s_waitcnt vmcnt(0)                                         // 0000007BBA6C: BF8903F7
	v_cvt_f32_f16_e32 v27, v14                                 // 0000007BBA70: 7E36170E
	s_or_b32 exec_lo, exec_lo, s5                              // 0000007BBA74: 8C7E057E
	s_and_saveexec_b32 s5, s4                                  // 0000007BBA78: BE852004
	s_cbranch_execz 256                                        // 0000007BBA7C: BFA50100 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x880>
	v_dual_mov_b32 v29, v23 :: v_dual_lshlrev_b32 v14, 1, v23  // 0000007BBA80: CA220117 1D0E2E81
	.long 0xd7006a0c                                           // 0000007BBA88: D7006A0C
	v_cndmask_b32_e32 v1, s20, v12, vcc_lo                     // 0000007BBA8C: 02021814
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007BBA90: BF8701A1
	v_add_co_ci_u32_e64 v13, null, s21, v13, vcc_lo            // 0000007BBA94: D5207C0D 01AA1A15
	v_dual_mov_b32 v20, 0 :: v_dual_lshlrev_b32 v19, 5, v23    // 0000007BBA9C: CA220080 14122E85
	.long 0xd7006a0c                                           // 0000007BBAA4: D7006A0C
	v_cndmask_b32_e32 v1, v12, v14, vcc_lo                     // 0000007BBAA8: 02021D0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007BBAAC: BF8701A1
	v_add_co_ci_u32_e64 v13, null, 0, v13, vcc_lo              // 0000007BBAB0: D5207C0D 01AA1A80
	v_lshl_or_b32 v28, v23, 4, 0x200                           // 0000007BBAB8: D656001C 03FD0917 00000200
	.long 0xd7006a0c                                           // 0000007BBAC4: D7006A0C
	v_cndmask_b32_e32 v1, s8, v12, vcc_lo                      // 0000007BBAC8: 02021808
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007BBACC: BF8701A1
	v_add_co_ci_u32_e64 v13, null, s9, v13, vcc_lo             // 0000007BBAD0: D5207C0D 01AA1A09
	v_mov_b32_e32 v26, v20                                     // 0000007BBAD8: 7E340314
	.long 0xd7006a15                                           // 0000007BBADC: D7006A15
	v_cndmask_b32_e32 v0, v12, v192, vcc_lo                    // 0000007BBAE0: 0201810C
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007BBAE4: BF870001
	v_add_co_ci_u32_e64 v22, null, 0, v13, vcc_lo              // 0000007BBAE8: D5207C16 01AA1A80
	v_mov_b32_e32 v30, v27                                     // 0000007BBAF0: 7E3C031B
	s_mov_b32 s7, 0                                            // 0000007BBAF4: BE870080
	s_branch 196                                               // 0000007BBAF8: BFA000C4 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x80c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000007BBAFC: 8C7E087E
	.long 0xd73c001f                                           // 0000007BBB00: D73C001F
	v_cndmask_b32_e32 v1, 1, v19, vcc_lo                       // 0000007BBB04: 02022681
	v_and_b32_e32 v47, 0xff, v8                                // 0000007BBB08: 365E10FF 000000FF
	v_lshrrev_b32_e32 v48, 6, v8                               // 0000007BBB10: 32601086
	v_lshrrev_b32_e32 v49, 14, v8                              // 0000007BBB14: 3262108E
	v_lshrrev_b32_e32 v8, 22, v8                               // 0000007BBB18: 32101096
	v_and_b32_e32 v50, 0xff, v9                                // 0000007BBB1C: 366412FF 000000FF
	.long 0xd7006a2b                                           // 0000007BBB24: D7006A2B
	v_cndmask_b32_e32 v1, s10, v31, vcc_lo                     // 0000007BBB28: 02023E0A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007BBB2C: BF870001
	v_add_co_ci_u32_e64 v44, null, s11, v32, vcc_lo            // 0000007BBB30: D5207C2C 01AA400B
	v_lshlrev_b32_e32 v47, 2, v47                              // 0000007BBB38: 305E5E82
	v_and_b32_e32 v48, 0x3fc, v48                              // 0000007BBB3C: 366060FF 000003FC
	v_and_b32_e32 v49, 0x3fc, v49                              // 0000007BBB44: 366262FF 000003FC
	s_clause 0x3                                               // 0000007BBB4C: BF850003
	global_load_b128 v[31:34], v[43:44], off                   // 0000007BBB50: DC5E0000 1F7C002B
	global_load_b128 v[35:38], v[43:44], off offset:16         // 0000007BBB58: DC5E0010 237C002B
	global_load_b128 v[39:42], v[43:44], off offset:32         // 0000007BBB60: DC5E0020 277C002B
	global_load_b128 v[43:46], v[43:44], off offset:48         // 0000007BBB68: DC5E0030 2B7C002B
	v_lshrrev_b32_e32 v51, 6, v9                               // 0000007BBB70: 32661286
	ds_load_b32 v47, v47                                       // 0000007BBB74: D8D80000 2F00002F
	ds_load_b32 v48, v48                                       // 0000007BBB7C: D8D80000 30000030
	ds_load_b32 v49, v49                                       // 0000007BBB84: D8D80000 31000031
	v_lshrrev_b32_e32 v52, 14, v9                              // 0000007BBB8C: 3268128E
	v_lshrrev_b32_e32 v9, 22, v9                               // 0000007BBB90: 32121296
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000007BBB94: 361010FF 000003FC
	v_lshlrev_b32_e32 v50, 2, v50                              // 0000007BBB9C: 30646482
	v_and_b32_e32 v51, 0x3fc, v51                              // 0000007BBBA0: 366666FF 000003FC
	v_and_b32_e32 v52, 0x3fc, v52                              // 0000007BBBA8: 366868FF 000003FC
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000007BBBB0: 361212FF 000003FC
	ds_load_b32 v8, v8                                         // 0000007BBBB8: D8D80000 08000008
	ds_load_b32 v50, v50                                       // 0000007BBBC0: D8D80000 32000032
	ds_load_b32 v51, v51                                       // 0000007BBBC8: D8D80000 33000033
	ds_load_b32 v52, v52                                       // 0000007BBBD0: D8D80000 34000034
	ds_load_b32 v9, v9                                         // 0000007BBBD8: D8D80000 09000009
	.long 0xd7006a15                                           // 0000007BBBE0: D7006A15
	v_cndmask_b32_e32 v0, v21, v192, vcc_lo                    // 0000007BBBE4: 02018115
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000007BBBE8: BF8704A1
	v_add_co_ci_u32_e64 v22, null, 0, v22, vcc_lo              // 0000007BBBEC: D5207C16 01AA2C80
	s_and_b32 s4, exec_lo, s4                                  // 0000007BBBF4: 8B04047E
	s_or_b32 s7, s4, s7                                        // 0000007BBBF8: 8C070704
	s_waitcnt vmcnt(3) lgkmcnt(7)                              // 0000007BBBFC: BF890C77
	v_dot2_f32_bf16 v31, v31, v47, 0                           // 0000007BBC00: CC1A401F 1A025F1F
	v_lshrrev_b32_e32 v47, 14, v10                             // 0000007BBC08: 325E148E
	s_waitcnt lgkmcnt(6)                                       // 0000007BBC0C: BF89FC67
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000007BBC10: BF870132
	v_dot2_f32_bf16 v31, v32, v48, v31                         // 0000007BBC14: CC1A401F 1C7E6120
	v_and_b32_e32 v32, 0xff, v10                               // 0000007BBC1C: 364014FF 000000FF
	s_waitcnt lgkmcnt(5)                                       // 0000007BBC24: BF89FC57
	v_dot2_f32_bf16 v31, v33, v49, v31                         // 0000007BBC28: CC1A401F 1C7E6321
	v_lshrrev_b32_e32 v33, 6, v10                              // 0000007BBC30: 32421486
	v_lshrrev_b32_e32 v10, 22, v10                             // 0000007BBC34: 32141496
	s_waitcnt lgkmcnt(4)                                       // 0000007BBC38: BF89FC47
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007BBC3C: BF870003
	v_dot2_f32_bf16 v8, v34, v8, v31                           // 0000007BBC40: CC1A4008 1C7E1122
	v_lshlrev_b32_e32 v31, 2, v32                              // 0000007BBC48: 303E4082
	v_and_b32_e32 v33, 0x3fc, v33                              // 0000007BBC4C: 364242FF 000003FC
	v_and_b32_e32 v32, 0xff, v11                               // 0000007BBC54: 364016FF 000000FF
	v_lshrrev_b32_e32 v34, 6, v11                              // 0000007BBC5C: 32441686
	s_waitcnt vmcnt(2) lgkmcnt(3)                              // 0000007BBC60: BF890837
	v_dot2_f32_bf16 v8, v35, v50, v8                           // 0000007BBC64: CC1A4008 1C226523
	ds_load_b32 v31, v31                                       // 0000007BBC6C: D8D80000 1F00001F
	ds_load_b32 v33, v33                                       // 0000007BBC74: D8D80000 21000021
	v_lshrrev_b32_e32 v35, 14, v11                             // 0000007BBC7C: 3246168E
	v_lshrrev_b32_e32 v11, 22, v11                             // 0000007BBC80: 32161696
	s_waitcnt lgkmcnt(4)                                       // 0000007BBC84: BF89FC47
	v_dot2_f32_bf16 v8, v36, v51, v8                           // 0000007BBC88: CC1A4008 1C226724
	v_lshlrev_b32_e32 v32, 2, v32                              // 0000007BBC90: 30404082
	v_and_b32_e32 v34, 0x3fc, v34                              // 0000007BBC94: 364444FF 000003FC
	v_and_b32_e32 v35, 0x3fc, v35                              // 0000007BBC9C: 364646FF 000003FC
	s_waitcnt lgkmcnt(3)                                       // 0000007BBCA4: BF89FC37
	v_dot2_f32_bf16 v8, v37, v52, v8                           // 0000007BBCA8: CC1A4008 1C226925
	v_cndmask_b32_e64 v37, v6, v7, s3                          // 0000007BBCB0: D5010025 000E0F06
	v_and_b32_e32 v47, 0x3fc, v47                              // 0000007BBCB8: 365E5EFF 000003FC
	s_waitcnt lgkmcnt(2)                                       // 0000007BBCC0: BF89FC27
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007BBCC4: BF870003
	v_dot2_f32_bf16 v8, v38, v9, v8                            // 0000007BBCC8: CC1A4008 1C221326
	ds_load_b32 v36, v47                                       // 0000007BBCD0: D8D80000 2400002F
	s_waitcnt vmcnt(1) lgkmcnt(2)                              // 0000007BBCD8: BF890427
	v_dot2_f32_bf16 v8, v39, v31, v8                           // 0000007BBCDC: CC1A4008 1C223F27
	v_cndmask_b32_e64 v31, v0, v1, s3                          // 0000007BBCE4: D501001F 000E0300
	v_cndmask_b32_e64 v39, v27, v0, s3                         // 0000007BBCEC: D5010027 000E011B
	v_mov_b32_e32 v27, v30                                     // 0000007BBCF4: 7E36031E
	s_waitcnt lgkmcnt(1)                                       // 0000007BBCF8: BF89FC17
	v_dot2_f32_bf16 v8, v40, v33, v8                           // 0000007BBCFC: CC1A4008 1C224328
	v_cndmask_b32_e64 v33, v2, v3, s3                          // 0000007BBD04: D5010021 000E0702
	s_waitcnt lgkmcnt(0)                                       // 0000007BBD0C: BF89FC07
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007BBD10: BF870002
	v_dot2_f32_bf16 v8, v41, v36, v8                           // 0000007BBD14: CC1A4008 1C224929
	v_cndmask_b32_e64 v36, v5, v6, s3                          // 0000007BBD1C: D5010024 000E0D05
	v_and_b32_e32 v10, 0x3fc, v10                              // 0000007BBD24: 361414FF 000003FC
	v_and_b32_e32 v11, 0x3fc, v11                              // 0000007BBD2C: 361616FF 000003FC
	ds_load_b32 v9, v10                                        // 0000007BBD34: D8D80000 0900000A
	ds_load_b32 v10, v32                                       // 0000007BBD3C: D8D80000 0A000020
	ds_load_b32 v38, v34                                       // 0000007BBD44: D8D80000 26000022
	ds_load_b32 v47, v35                                       // 0000007BBD4C: D8D80000 2F000023
	ds_load_b32 v48, v11                                       // 0000007BBD54: D8D80000 3000000B
	v_cndmask_b32_e64 v32, v1, v2, s3                          // 0000007BBD5C: D5010020 000E0501
	v_cndmask_b32_e64 v35, v4, v5, s3                          // 0000007BBD64: D5010023 000E0B04
	v_cndmask_b32_e64 v34, v3, v4, s3                          // 0000007BBD6C: D5010022 000E0903
	v_mov_b32_e32 v11, v15                                     // 0000007BBD74: 7E16030F
	s_waitcnt lgkmcnt(4)                                       // 0000007BBD78: BF89FC47
	v_dot2_f32_bf16 v8, v42, v9, v8                            // 0000007BBD7C: CC1A4008 1C22132A
	v_mov_b32_e32 v9, v13                                      // 0000007BBD84: 7E12030D
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 0000007BBD88: BF890037
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000007BBD8C: BF8701C2
	v_dot2_f32_bf16 v6, v43, v10, v8                           // 0000007BBD90: CC1A4006 1C22152B
	v_mov_b32_e32 v10, v14                                     // 0000007BBD98: 7E14030E
	v_mov_b32_e32 v8, v12                                      // 0000007BBD9C: 7E10030C
	s_waitcnt lgkmcnt(2)                                       // 0000007BBDA0: BF89FC27
	v_dot2_f32_bf16 v2, v44, v38, v6                           // 0000007BBDA4: CC1A4002 1C1A4D2C
	v_dual_mov_b32 v38, v7 :: v_dual_add_nc_u32 v19, 0x400, v19// 0000007BBDAC: CA200107 261226FF 00000400
	v_add_nc_u32_e32 v28, 0x200, v28                           // 0000007BBDB8: 4A3838FF 00000200
	s_waitcnt lgkmcnt(1)                                       // 0000007BBDC0: BF89FC17
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007BBDC4: BF8700A3
	v_dot2_f32_bf16 v0, v45, v47, v2                           // 0000007BBDC8: CC1A4000 1C0A5F2D
	s_waitcnt lgkmcnt(0)                                       // 0000007BBDD0: BF89FC07
	v_dot2_f32_bf16 v0, v46, v48, v0                           // 0000007BBDD4: CC1A4000 1C02612E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007BBDDC: BF870001
	v_fmac_f32_e32 v26, v39, v0                                // 0000007BBDE0: 56340127
	v_dual_mov_b32 v0, v31 :: v_dual_mov_b32 v1, v32           // 0000007BBDE4: CA10011F 00000120
	v_dual_mov_b32 v2, v33 :: v_dual_mov_b32 v3, v34           // 0000007BBDEC: CA100121 02020122
	v_dual_mov_b32 v4, v35 :: v_dual_mov_b32 v5, v36           // 0000007BBDF4: CA100123 04040124
	v_dual_mov_b32 v6, v37 :: v_dual_mov_b32 v7, v38           // 0000007BBDFC: CA100125 06060126
	s_and_not1_b32 exec_lo, exec_lo, s7                        // 0000007BBE04: 917E077E
	s_cbranch_execz 28                                         // 0000007BBE08: BFA5001C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x87c>
	s_waitcnt vmcnt(0)                                         // 0000007BBE0C: BF8903F7
	v_dual_mov_b32 v12, v8 :: v_dual_add_nc_u32 v29, 32, v29   // 0000007BBE10: CA200108 0C1C3AA0
	v_dual_mov_b32 v13, v9 :: v_dual_mov_b32 v14, v10          // 0000007BBE18: CA100109 0D0E010A
	v_mov_b32_e32 v15, v11                                     // 0000007BBE20: 7E1E030B
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007BBE24: BF870003
	.long 0xd4430004                                           // 0000007BBE28: D4430004
	v_cndmask_b32_e32 v1, s6, v29, vcc_lo                      // 0000007BBE2C: 02023A06
	s_mov_b32 s8, exec_lo                                      // 0000007BBE30: BE88007E
	.long 0xd4c4007e                                           // 0000007BBE34: D4C4007E
	v_cndmask_b32_e32 v1, s6, v29, vcc_lo                      // 0000007BBE38: 02023A06
	s_cbranch_execz 65327                                      // 0000007BBE3C: BFA5FF2F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x4fc>
	.long 0xd7006a0c                                           // 0000007BBE40: D7006A0C
	v_cndmask_b32_e32 v1, v18, v28, vcc_lo                     // 0000007BBE44: 02023912
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007BBE48: BF870001
	v_add_co_ci_u32_e64 v13, null, 0, v25, vcc_lo              // 0000007BBE4C: D5207C0D 01AA3280
	v_cmp_ne_u32_e32 vcc_lo, 1, v24                            // 0000007BBE54: 7C9A3081
	v_mov_b32_e32 v30, v27                                     // 0000007BBE58: 7E3C031B
	global_load_b128 v[12:15], v[12:13], off                   // 0000007BBE5C: DC5E0000 0C7C000C
	s_cbranch_vccnz 65317                                      // 0000007BBE64: BFA4FF25 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x4fc>
	global_load_d16_b16 v30, v[21:22], off                     // 0000007BBE68: DC820000 1E7C0015
	s_waitcnt vmcnt(0)                                         // 0000007BBE70: BF8903F7
	v_cvt_f32_f16_e32 v30, v30                                 // 0000007BBE74: 7E3C171E
	s_branch 65312                                             // 0000007BBE78: BFA0FF20 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x4fc>
	s_or_b32 exec_lo, exec_lo, s7                              // 0000007BBE7C: 8C7E077E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007BBE80: BF8700A9
	s_or_b32 exec_lo, exec_lo, s5                              // 0000007BBE84: 8C7E057E
	.long 0xd71f0000                                           // 0000007BBE88: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000007BBE8C: 020100C1
	v_xor_b32_e32 v1, 16, v0                                   // 0000007BBE90: 3A020090
	v_xor_b32_e32 v2, 8, v0                                    // 0000007BBE94: 3A040088
	v_xor_b32_e32 v3, 4, v0                                    // 0000007BBE98: 3A060084
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000007BBE9C: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v1                            // 0000007BBEA0: 7C9802A0
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 0000007BBEA4: 02020300
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000007BBEA8: 7C9804A0
	v_cndmask_b32_e32 v2, v0, v2, vcc_lo                       // 0000007BBEAC: 02040500
	v_cmp_gt_u32_e32 vcc_lo, 32, v3                            // 0000007BBEB0: 7C9806A0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007BBEB4: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000007BBEB8: 30040482
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000007BBEBC: 30020282
	v_cndmask_b32_e32 v3, v0, v3, vcc_lo                       // 0000007BBEC0: 02060700
	ds_bpermute_b32 v1, v1, v26                                // 0000007BBEC4: DACC0000 01001A01
	v_lshlrev_b32_e32 v3, 2, v3                                // 0000007BBECC: 30060682
	s_waitcnt lgkmcnt(0)                                       // 0000007BBED0: BF89FC07
	v_add_f32_e32 v1, v26, v1                                  // 0000007BBED4: 0602031A
	ds_bpermute_b32 v2, v2, v1                                 // 0000007BBED8: DACC0000 02000102
	s_waitcnt lgkmcnt(0)                                       // 0000007BBEE0: BF89FC07
	v_add_f32_e32 v1, v1, v2                                   // 0000007BBEE4: 06020501
	ds_bpermute_b32 v2, v3, v1                                 // 0000007BBEE8: DACC0000 02000103
	v_xor_b32_e32 v3, 2, v0                                    // 0000007BBEF0: 3A060082
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007BBEF4: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v3                            // 0000007BBEF8: 7C9806A0
	v_cndmask_b32_e32 v3, v0, v3, vcc_lo                       // 0000007BBEFC: 02060700
	v_lshlrev_b32_e32 v3, 2, v3                                // 0000007BBF00: 30060682
	s_waitcnt lgkmcnt(0)                                       // 0000007BBF04: BF89FC07
	v_add_f32_e32 v1, v1, v2                                   // 0000007BBF08: 06020501
	ds_bpermute_b32 v2, v3, v1                                 // 0000007BBF0C: DACC0000 02000103
	v_xor_b32_e32 v3, 1, v0                                    // 0000007BBF14: 3A060081
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000007BBF18: BF870151
	v_cmp_gt_u32_e32 vcc_lo, 32, v3                            // 0000007BBF1C: 7C9806A0
	v_cndmask_b32_e32 v3, v0, v3, vcc_lo                       // 0000007BBF20: 02060700
	v_cmp_eq_u32_e32 vcc_lo, 0, v23                            // 0000007BBF24: 7C942E80
	s_and_b32 s2, vcc_lo, s2                                   // 0000007BBF28: 8B02026A
	s_waitcnt lgkmcnt(0)                                       // 0000007BBF2C: BF89FC07
	v_dual_add_f32 v0, v1, v2 :: v_dual_lshlrev_b32 v1, 2, v3  // 0000007BBF30: C9220501 00000682
	ds_bpermute_b32 v1, v1, v0                                 // 0000007BBF38: DACC0000 01000001
	s_and_saveexec_b32 s3, s2                                  // 0000007BBF40: BE832002
	s_cbranch_execz 58                                         // 0000007BBF44: BFA5003A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0xa30>
	s_load_b32 s0, s[0:1], 0x48                                // 0000007BBF48: F4000000 F8000048
	s_waitcnt lgkmcnt(0)                                       // 0000007BBF50: BF89FC07
	v_add_f32_e32 v0, v0, v1                                   // 0000007BBF54: 06000300
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BBF58: BF870091
	v_bfe_u32 v1, v0, 16, 1                                    // 0000007BBF5C: D6100001 02052100
	v_add3_u32 v0, v0, v1, 0x7fff                              // 0000007BBF64: D6550000 03FE0300 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BBF70: BF870091
	v_and_b32_e32 v0, 0xffff0000, v0                           // 0000007BBF74: 360000FF FFFF0000
	v_mul_f32_e32 v0, s0, v0                                   // 0000007BBF7C: 10000000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BBF80: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 0000007BBF84: 100200FF BFB8AA3B
	v_exp_f32_e32 v1, v1                                       // 0000007BBF8C: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BBF90: BF870095
	v_add_f32_e32 v1, 1.0, v1                                  // 0000007BBF94: 060202F2
	v_div_scale_f32 v2, null, v1, v1, v0                       // 0000007BBF98: D6FC7C02 04020301
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000007BBFA0: BF870291
	v_rcp_f32_e32 v3, v2                                       // 0000007BBFA4: 7E065502
	v_fma_f32 v4, -v2, v3, 1.0                                 // 0000007BBFA8: D6130004 23CA0702
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007BBFB0: BF8700A1
	v_fmac_f32_e32 v3, v4, v3                                  // 0000007BBFB4: 56060704
	v_div_scale_f32 v5, vcc_lo, v0, v1, v0                     // 0000007BBFB8: D6FC6A05 04020300
	v_mul_f32_e32 v4, v5, v3                                   // 0000007BBFC0: 10080705
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BBFC4: BF870091
	v_fma_f32 v6, -v2, v4, v5                                  // 0000007BBFC8: D6130006 24160902
	v_fmac_f32_e32 v4, v6, v3                                  // 0000007BBFD0: 56080706
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BBFD4: BF870091
	v_fma_f32 v2, -v2, v4, v5                                  // 0000007BBFD8: D6130002 24160902
	v_div_fmas_f32 v2, v2, v3, v4                              // 0000007BBFE0: D6370002 04120702
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007BBFE8: BF870121
	v_div_fixup_f32 v2, v2, v1, v0                             // 0000007BBFEC: D6270002 04020302
	.long 0xd73c0000                                           // 0000007BBFF4: D73C0000
	v_cndmask_b32_e32 v1, 1, v16, vcc_lo                       // 0000007BBFF8: 02022081
	v_bfe_u32 v3, v2, 16, 1                                    // 0000007BBFFC: D6100003 02052102
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BC004: BF870092
	.long 0xd7006a00                                           // 0000007BC008: D7006A00
	v_cndmask_b32_e32 v1, s12, v0, vcc_lo                      // 0000007BC00C: 0202000C
	v_add_co_ci_u32_e64 v1, null, s13, v1, vcc_lo              // 0000007BC010: D5207C01 01AA020D
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007BC018: BF870003
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000007BC01C: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off                    // 0000007BC028: DC960000 007C0200
	s_endpgm                                                   // 0000007BC030: BFB00000
		...

