000000000054c500 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi16ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi16ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 00000054C500: F4100100 F8000000
	v_and_b32_e32 v16, 15, v0                                  // 00000054C508: 3620008F
	v_lshrrev_b32_e32 v1, 4, v0                                // 00000054C50C: 32020084
	s_ashr_i32 s3, s2, 31                                      // 00000054C510: 86039F02
	.long 0x7f103880                                           // 00000054C514: 7F103880
	s_lshl_b64 s[0:1], s[2:3], 4                               // 00000054C518: 84808402
	v_mov_b32_e32 v17, 0                                       // 00000054C51C: 7E220280
	v_dual_mov_b32 v10, s1 :: v_dual_lshlrev_b32 v3, 2, v1     // 00000054C520: CA220001 0A020282
	v_or_b32_e32 v9, s0, v1                                    // 00000054C528: 38120200
	v_dual_mov_b32 v1, 0 :: v_dual_lshlrev_b32 v2, 2, v16      // 00000054C52C: CA220080 01022082
	s_waitcnt lgkmcnt(0)                                       // 00000054C534: BF89FC07
	s_clause 0x1                                               // 00000054C538: BF850001
	global_load_b32 v4, v2, s[4:5]                             // 00000054C53C: DC520000 04040002
	global_load_b32 v7, v3, s[4:5]                             // 00000054C544: DC520000 07040003
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[9:10]                 // 00000054C54C: 7CA8120C
	s_add_u32 s2, s4, s14                                      // 00000054C550: 80020E04
	s_addc_u32 s3, s5, s15                                     // 00000054C554: 82030F05
	s_lshr_b32 s0, s11, 31                                     // 00000054C558: 85009F0B
	v_mov_b32_e32 v18, 0                                       // 00000054C55C: 7E240280
	s_add_u32 s12, s10, s0                                     // 00000054C560: 800C000A
	v_cndmask_b32_e32 v11, 0, v9, vcc_lo                       // 00000054C564: 02161280
	v_cndmask_b32_e64 v14, 0, s1, vcc_lo                       // 00000054C568: D501000E 01A80280
	s_addc_u32 s13, s11, 0                                     // 00000054C570: 820D800B
	s_ashr_i32 s14, s11, 31                                    // 00000054C574: 860E9F0B
	s_ashr_i64 s[0:1], s[12:13], 1                             // 00000054C578: 8680810C
	.long 0xd72c000d                                           // 00000054C57C: D72C000D
	v_cndmask_b32_e32 v1, s19, v11, vcc_lo                     // 00000054C580: 02021613
	v_mad_u64_u32 v[5:6], null, s18, v11, 0                    // 00000054C584: D6FE7C05 02021612
	.long 0xd72c000f                                           // 00000054C58C: D72C000F
	v_cndmask_b32_e32 v0, v11, v1, vcc_lo                      // 00000054C590: 0200030B
	.long 0xd72c0014                                           // 00000054C594: D72C0014
	v_cndmask_b32_e32 v0, v14, v0, vcc_lo                      // 00000054C598: 0200010E
	.long 0xd72c000e                                           // 00000054C59C: D72C000E
	v_cndmask_b32_e32 v1, s18, v14, vcc_lo                     // 00000054C5A0: 02021C12
	s_lshr_b32 s12, s14, 27                                    // 00000054C5A4: 850C9B0E
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, 0               // 00000054C5A8: CA100080 02020080
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 00000054C5B0: BF870152
	v_add3_u32 v6, v6, v14, v13                                // 00000054C5B4: D6550006 04361D06
	s_waitcnt vmcnt(1)                                         // 00000054C5BC: BF8907F7
	v_bfe_u32 v12, v4, 16, 1                                   // 00000054C5C0: D610000C 02052104
	s_waitcnt vmcnt(0)                                         // 00000054C5C8: BF8903F7
	v_bfe_u32 v19, v7, 16, 1                                   // 00000054C5CC: D6100013 02052107
	v_add3_u32 v4, v4, v12, 0x7fff                             // 00000054C5D4: D6550004 03FE1904 00007FFF
	v_mad_u64_u32 v[11:12], null, v11, s0, s[2:3]              // 00000054C5E0: D6FE7C0B 0008010B
	s_add_u32 s2, s10, s12                                     // 00000054C5E8: 80020C0A
	v_add3_u32 v7, v7, v19, 0x7fff                             // 00000054C5EC: D6550007 03FE2707 00007FFF
	s_addc_u32 s3, s11, 0                                      // 00000054C5F8: 8203800B
	.long 0x7e103984                                           // 00000054C5FC: 7E103984
	s_lshr_b64 s[2:3], s[2:3], 5                               // 00000054C600: 85828502
	v_dual_mov_b32 v4, 0 :: v_dual_lshlrev_b32 v19, 2, v0      // 00000054C604: CA220080 04120082
	.long 0xd4440000                                           // 00000054C60C: D4440000
	v_cndmask_b32_e32 v1, s2, v16, vcc_lo                      // 00000054C610: 02022002
	s_delay_alu instid0(VALU_DEP_3)                            // 00000054C614: BF870003
	v_and_or_b32 v7, 0xffff0000, v7, v8                        // 00000054C618: D6570007 04220EFF FFFF0000
	v_add3_u32 v0, v20, v12, v15                               // 00000054C624: D6550000 043E1914
	ds_store_b32 v19, v7                                       // 00000054C62C: D8340000 00000713
	s_waitcnt lgkmcnt(0)                                       // 00000054C634: BF89FC07
	s_barrier                                                  // 00000054C638: BFBD0000
	buffer_gl0_inv                                             // 00000054C63C: E0AC0000 00000000
	s_and_saveexec_b32 s3, s0                                  // 00000054C644: BE832000
	s_cbranch_execz 26                                         // 00000054C648: BFA5001A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi16ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x1b4>
	s_add_u32 s1, s4, s16                                      // 00000054C64C: 80011004
	s_addc_u32 s10, s5, s17                                    // 00000054C650: 820A1105
	v_lshlrev_b32_e32 v1, 1, v16                               // 00000054C654: 30022081
	.long 0xd7000102                                           // 00000054C658: D7000102
	v_cndmask_b32_e32 v1, s1, v5, vcc_lo                       // 00000054C65C: 02020A01
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000054C660: BF8701A1
	v_add_co_ci_u32_e64 v3, null, s10, v6, s1                  // 00000054C664: D5207C03 00060C0A
	v_lshlrev_b32_e32 v4, 4, v16                               // 00000054C66C: 30082084
	.long 0xd7000101                                           // 00000054C670: D7000101
	v_cndmask_b32_e32 v1, v2, v1, vcc_lo                       // 00000054C674: 02020302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000054C678: BF870191
	v_add_co_ci_u32_e64 v2, null, 0, v3, s1                    // 00000054C67C: D5207C02 00060680
	.long 0xd7000103                                           // 00000054C684: D7000103
	v_cndmask_b32_e32 v1, v11, v4, vcc_lo                      // 00000054C688: 0202090B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000054C68C: BF870001
	v_add_co_ci_u32_e64 v4, null, 0, v0, s1                    // 00000054C690: D5207C04 00060080
	s_clause 0x1                                               // 00000054C698: BF850001
	global_load_d16_b16 v7, v[1:2], off                        // 00000054C69C: DC820000 077C0001
	global_load_b128 v[1:4], v[3:4], off                       // 00000054C6A4: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 00000054C6AC: BF8907F7
	v_cvt_f32_f16_e32 v18, v7                                  // 00000054C6B0: 7E241707
	s_or_b32 exec_lo, exec_lo, s3                              // 00000054C6B4: 8C7E037E
	s_and_saveexec_b32 s3, s0                                  // 00000054C6B8: BE832000
	s_cbranch_execz 227                                        // 00000054C6BC: BFA500E3 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi16ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x54c>
	v_dual_mov_b32 v20, v16 :: v_dual_lshlrev_b32 v7, 1, v16   // 00000054C6C0: CA220110 14062081
	.long 0xd7000005                                           // 00000054C6C8: D7000005
	v_cndmask_b32_e32 v1, s16, v5, vcc_lo                      // 00000054C6CC: 02020A10
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000054C6D0: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s17, v6, s0                  // 00000054C6D4: D5207C06 00020C11
	v_dual_mov_b32 v13, 0 :: v_dual_lshlrev_b32 v12, 5, v16    // 00000054C6DC: CA220080 0D0C2085
	.long 0xd7000005                                           // 00000054C6E4: D7000005
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 00000054C6E8: 02020F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000054C6EC: BF8701A1
	v_add_co_ci_u32_e64 v6, null, 0, v6, s0                    // 00000054C6F0: D5207C06 00020C80
	v_lshl_or_b32 v19, v16, 4, 0x100                           // 00000054C6F8: D6560013 03FD0910 00000100
	.long 0xd7000005                                           // 00000054C704: D7000005
	v_cndmask_b32_e32 v1, s4, v5, vcc_lo                       // 00000054C708: 02020A04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000054C70C: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s5, v6, s0                   // 00000054C710: D5207C06 00020C05
	v_mov_b32_e32 v17, v13                                     // 00000054C718: 7E22030D
	.long 0xd700000e                                           // 00000054C71C: D700000E
	v_cndmask_b32_e32 v0, v5, v160, vcc_lo                     // 00000054C720: 02014105
	s_delay_alu instid0(VALU_DEP_1)                            // 00000054C724: BF870001
	v_add_co_ci_u32_e64 v15, null, 0, v6, s0                   // 00000054C728: D5207C0F 00020C80
	v_mov_b32_e32 v21, v18                                     // 00000054C730: 7E2A0312
	s_mov_b32 s4, 0                                            // 00000054C734: BE840080
	s_branch 170                                               // 00000054C738: BFA000AA <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi16ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x4e4>
	s_or_b32 exec_lo, exec_lo, s5                              // 00000054C73C: 8C7E057E
	.long 0xd73c0016                                           // 00000054C740: D73C0016
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 00000054C744: 02021881
	v_and_b32_e32 v38, 0xff, v1                                // 00000054C748: 364C02FF 000000FF
	v_lshrrev_b32_e32 v39, 6, v1                               // 00000054C750: 324E0286
	v_lshrrev_b32_e32 v40, 14, v1                              // 00000054C754: 3250028E
	v_lshrrev_b32_e32 v1, 22, v1                               // 00000054C758: 32020296
	v_and_b32_e32 v41, 0xff, v2                                // 00000054C75C: 365204FF 000000FF
	.long 0xd7000122                                           // 00000054C764: D7000122
	v_cndmask_b32_e32 v1, s6, v22, vcc_lo                      // 00000054C768: 02022C06
	s_delay_alu instid0(VALU_DEP_1)                            // 00000054C76C: BF870001
	v_add_co_ci_u32_e64 v35, null, s7, v23, s1                 // 00000054C770: D5207C23 00062E07
	v_lshlrev_b32_e32 v38, 2, v38                              // 00000054C778: 304C4C82
	v_and_b32_e32 v39, 0x3fc, v39                              // 00000054C77C: 364E4EFF 000003FC
	v_and_b32_e32 v40, 0x3fc, v40                              // 00000054C784: 365050FF 000003FC
	s_clause 0x3                                               // 00000054C78C: BF850003
	global_load_b128 v[22:25], v[34:35], off                   // 00000054C790: DC5E0000 167C0022
	global_load_b128 v[26:29], v[34:35], off offset:16         // 00000054C798: DC5E0010 1A7C0022
	global_load_b128 v[30:33], v[34:35], off offset:32         // 00000054C7A0: DC5E0020 1E7C0022
	global_load_b128 v[34:37], v[34:35], off offset:48         // 00000054C7A8: DC5E0030 227C0022
	v_lshrrev_b32_e32 v42, 6, v2                               // 00000054C7B0: 32540486
	ds_load_b32 v38, v38                                       // 00000054C7B4: D8D80000 26000026
	ds_load_b32 v39, v39                                       // 00000054C7BC: D8D80000 27000027
	ds_load_b32 v40, v40                                       // 00000054C7C4: D8D80000 28000028
	v_lshrrev_b32_e32 v43, 14, v2                              // 00000054C7CC: 3256048E
	v_lshrrev_b32_e32 v2, 22, v2                               // 00000054C7D0: 32040496
	v_and_b32_e32 v1, 0x3fc, v1                                // 00000054C7D4: 360202FF 000003FC
	v_lshlrev_b32_e32 v41, 2, v41                              // 00000054C7DC: 30525282
	v_and_b32_e32 v42, 0x3fc, v42                              // 00000054C7E0: 365454FF 000003FC
	v_and_b32_e32 v43, 0x3fc, v43                              // 00000054C7E8: 365656FF 000003FC
	v_and_b32_e32 v2, 0x3fc, v2                                // 00000054C7F0: 360404FF 000003FC
	ds_load_b32 v1, v1                                         // 00000054C7F8: D8D80000 01000001
	ds_load_b32 v41, v41                                       // 00000054C800: D8D80000 29000029
	ds_load_b32 v42, v42                                       // 00000054C808: D8D80000 2A00002A
	ds_load_b32 v43, v43                                       // 00000054C810: D8D80000 2B00002B
	ds_load_b32 v2, v2                                         // 00000054C818: D8D80000 02000002
	s_and_b32 s1, exec_lo, s0                                  // 00000054C820: 8B01007E
	.long 0xd700000e                                           // 00000054C824: D700000E
	v_cndmask_b32_e32 v0, v14, v160, vcc_lo                    // 00000054C828: 0201410E
	v_add_nc_u32_e32 v12, 0x200, v12                           // 00000054C82C: 4A1818FF 00000200
	v_add_nc_u32_e32 v19, 0x100, v19                           // 00000054C834: 4A2626FF 00000100
	v_add_co_ci_u32_e64 v15, null, 0, v15, s0                  // 00000054C83C: D5207C0F 00021E80
	s_or_b32 s4, s1, s4                                        // 00000054C844: 8C040401
	s_waitcnt vmcnt(3) lgkmcnt(7)                              // 00000054C848: BF890C77
	v_dot2_f32_bf16 v22, v22, v38, 0                           // 00000054C84C: CC1A4016 1A024D16
	v_lshrrev_b32_e32 v38, 14, v3                              // 00000054C854: 324C068E
	s_waitcnt lgkmcnt(6)                                       // 00000054C858: BF89FC67
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000054C85C: BF8701A2
	v_dot2_f32_bf16 v22, v23, v39, v22                         // 00000054C860: CC1A4016 1C5A4F17
	v_and_b32_e32 v23, 0xff, v3                                // 00000054C868: 362E06FF 000000FF
	v_and_b32_e32 v38, 0x3fc, v38                              // 00000054C870: 364C4CFF 000003FC
	s_waitcnt lgkmcnt(5)                                       // 00000054C878: BF89FC57
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000054C87C: BF8701C3
	v_dot2_f32_bf16 v22, v24, v40, v22                         // 00000054C880: CC1A4016 1C5A5118
	v_lshrrev_b32_e32 v24, 6, v3                               // 00000054C888: 32300686
	v_lshrrev_b32_e32 v3, 22, v3                               // 00000054C88C: 32060696
	s_waitcnt lgkmcnt(4)                                       // 00000054C890: BF89FC47
	v_dot2_f32_bf16 v1, v25, v1, v22                           // 00000054C894: CC1A4001 1C5A0319
	v_lshlrev_b32_e32 v22, 2, v23                              // 00000054C89C: 302C2E82
	v_and_b32_e32 v24, 0x3fc, v24                              // 00000054C8A0: 363030FF 000003FC
	v_and_b32_e32 v23, 0xff, v4                                // 00000054C8A8: 362E08FF 000000FF
	v_lshrrev_b32_e32 v25, 6, v4                               // 00000054C8B0: 32320886
	s_waitcnt vmcnt(2) lgkmcnt(3)                              // 00000054C8B4: BF890837
	v_dot2_f32_bf16 v1, v26, v41, v1                           // 00000054C8B8: CC1A4001 1C06531A
	ds_load_b32 v22, v22                                       // 00000054C8C0: D8D80000 16000016
	ds_load_b32 v24, v24                                       // 00000054C8C8: D8D80000 18000018
	v_lshrrev_b32_e32 v26, 14, v4                              // 00000054C8D0: 3234088E
	v_lshrrev_b32_e32 v4, 22, v4                               // 00000054C8D4: 32080896
	s_waitcnt lgkmcnt(4)                                       // 00000054C8D8: BF89FC47
	v_dot2_f32_bf16 v1, v27, v42, v1                           // 00000054C8DC: CC1A4001 1C06551B
	ds_load_b32 v27, v38                                       // 00000054C8E4: D8D80000 1B000026
	v_and_b32_e32 v3, 0x3fc, v3                                // 00000054C8EC: 360606FF 000003FC
	v_lshlrev_b32_e32 v23, 2, v23                              // 00000054C8F4: 302E2E82
	v_and_b32_e32 v25, 0x3fc, v25                              // 00000054C8F8: 363232FF 000003FC
	s_waitcnt lgkmcnt(4)                                       // 00000054C900: BF89FC47
	v_dot2_f32_bf16 v1, v28, v43, v1                           // 00000054C904: CC1A4001 1C06571C
	v_and_b32_e32 v26, 0x3fc, v26                              // 00000054C90C: 363434FF 000003FC
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000054C914: 360808FF 000003FC
	s_waitcnt lgkmcnt(3)                                       // 00000054C91C: BF89FC37
	s_delay_alu instid0(VALU_DEP_3)                            // 00000054C920: BF870003
	v_dot2_f32_bf16 v1, v29, v2, v1                            // 00000054C924: CC1A4001 1C06051D
	ds_load_b32 v2, v3                                         // 00000054C92C: D8D80000 02000003
	ds_load_b32 v3, v23                                        // 00000054C934: D8D80000 03000017
	ds_load_b32 v23, v25                                       // 00000054C93C: D8D80000 17000019
	ds_load_b32 v25, v26                                       // 00000054C944: D8D80000 1900001A
	ds_load_b32 v4, v4                                         // 00000054C94C: D8D80000 04000004
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 00000054C954: BF890477
	v_dot2_f32_bf16 v1, v30, v22, v1                           // 00000054C958: CC1A4001 1C062D1E
	s_waitcnt lgkmcnt(6)                                       // 00000054C960: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000054C964: BF8700A1
	v_dot2_f32_bf16 v1, v31, v24, v1                           // 00000054C968: CC1A4001 1C06311F
	s_waitcnt lgkmcnt(5)                                       // 00000054C970: BF89FC57
	v_dot2_f32_bf16 v1, v32, v27, v1                           // 00000054C974: CC1A4001 1C063720
	s_waitcnt lgkmcnt(4)                                       // 00000054C97C: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000054C980: BF870131
	v_dot2_f32_bf16 v1, v33, v2, v1                            // 00000054C984: CC1A4001 1C060521
	v_mov_b32_e32 v2, v6                                       // 00000054C98C: 7E040306
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 00000054C990: BF890037
	v_dot2_f32_bf16 v1, v34, v3, v1                            // 00000054C994: CC1A4001 1C060722
	v_mov_b32_e32 v3, v7                                       // 00000054C99C: 7E060307
	s_waitcnt lgkmcnt(2)                                       // 00000054C9A0: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000054C9A4: BF8700A2
	v_dot2_f32_bf16 v1, v35, v23, v1                           // 00000054C9A8: CC1A4001 1C062F23
	s_waitcnt lgkmcnt(1)                                       // 00000054C9B0: BF89FC17
	v_dot2_f32_bf16 v1, v36, v25, v1                           // 00000054C9B4: CC1A4001 1C063324
	s_waitcnt lgkmcnt(0)                                       // 00000054C9BC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000054C9C0: BF870121
	v_dot2_f32_bf16 v22, v37, v4, v1                           // 00000054C9C4: CC1A4016 1C060925
	v_dual_mov_b32 v4, v8 :: v_dual_mov_b32 v1, v5             // 00000054C9CC: CA100108 04000105
	v_dual_fmac_f32 v17, v18, v22 :: v_dual_mov_b32 v18, v21   // 00000054C9D4: C8102D12 11120115
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000054C9DC: 917E047E
	s_cbranch_execz 25                                         // 00000054C9E0: BFA50019 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi16ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x548>
	s_waitcnt vmcnt(0)                                         // 00000054C9E4: BF8903F7
	v_dual_mov_b32 v5, v1 :: v_dual_add_nc_u32 v20, 16, v20    // 00000054C9E8: CA200101 05142890
	v_dual_mov_b32 v6, v2 :: v_dual_mov_b32 v7, v3             // 00000054C9F0: CA100102 06060103
	v_mov_b32_e32 v8, v4                                       // 00000054C9F8: 7E100304
	s_delay_alu instid0(VALU_DEP_3)                            // 00000054C9FC: BF870003
	.long 0xd4430000                                           // 00000054CA00: D4430000
	v_cndmask_b32_e32 v1, s2, v20, vcc_lo                      // 00000054CA04: 02022802
	s_mov_b32 s5, exec_lo                                      // 00000054CA08: BE85007E
	.long 0xd4c4007e                                           // 00000054CA0C: D4C4007E
	v_cndmask_b32_e32 v1, s2, v20, vcc_lo                      // 00000054CA10: 02022802
	s_cbranch_execz 65353                                      // 00000054CA14: BFA5FF49 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi16ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x23c>
	.long 0xd7000105                                           // 00000054CA18: D7000105
	v_cndmask_b32_e32 v1, v11, v19, vcc_lo                     // 00000054CA1C: 0202270B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000054CA20: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v0, s1                    // 00000054CA24: D5207C06 00060080
	global_load_d16_b16 v21, v[14:15], off                     // 00000054CA2C: DC820000 157C000E
	global_load_b128 v[5:8], v[5:6], off                       // 00000054CA34: DC5E0000 057C0005
	s_waitcnt vmcnt(1)                                         // 00000054CA3C: BF8907F7
	v_cvt_f32_f16_e32 v21, v21                                 // 00000054CA40: 7E2A1715
	s_branch 65341                                             // 00000054CA44: BFA0FF3D <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi16ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x23c>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000054CA48: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000054CA4C: BF8700B9
	s_or_b32 exec_lo, exec_lo, s3                              // 00000054CA50: 8C7E037E
	.long 0xd71f0000                                           // 00000054CA54: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000054CA58: 020100C1
	s_waitcnt vmcnt(0)                                         // 00000054CA5C: BF8903F7
	v_xor_b32_e32 v1, 8, v0                                    // 00000054CA60: 3A020088
	v_xor_b32_e32 v2, 4, v0                                    // 00000054CA64: 3A040084
	v_xor_b32_e32 v3, 2, v0                                    // 00000054CA68: 3A060082
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000054CA6C: BF870093
	.long 0xd44c0000                                           // 00000054CA70: D44C0000
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 00000054CA74: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s0                           // 00000054CA78: D5010001 00020300
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000054CA80: BF870114
	.long 0xd44c0000                                           // 00000054CA84: D44C0000
	v_cndmask_b32_e32 v1, 32, v2, vcc_lo                       // 00000054CA88: 020204A0
	v_lshlrev_b32_e32 v1, 2, v1                                // 00000054CA8C: 30020282
	s_delay_alu instid0(VALU_DEP_2)                            // 00000054CA90: BF870002
	v_cndmask_b32_e64 v2, v0, v2, s0                           // 00000054CA94: D5010002 00020500
	.long 0xd44c0000                                           // 00000054CA9C: D44C0000
	v_cndmask_b32_e32 v1, 32, v3, vcc_lo                       // 00000054CAA0: 020206A0
	ds_bpermute_b32 v1, v1, v17                                // 00000054CAA4: DACC0000 01001101
	v_lshlrev_b32_e32 v2, 2, v2                                // 00000054CAAC: 30040482
	v_cndmask_b32_e64 v3, v0, v3, s0                           // 00000054CAB0: D5010003 00020700
	s_waitcnt lgkmcnt(0)                                       // 00000054CAB8: BF89FC07
	v_add_f32_e32 v1, v17, v1                                  // 00000054CABC: 06020311
	ds_bpermute_b32 v2, v2, v1                                 // 00000054CAC0: DACC0000 02000102
	s_waitcnt lgkmcnt(0)                                       // 00000054CAC8: BF89FC07
	v_add_f32_e32 v1, v1, v2                                   // 00000054CACC: 06020501
	v_lshlrev_b32_e32 v3, 2, v3                                // 00000054CAD0: 30060682
	ds_bpermute_b32 v2, v3, v1                                 // 00000054CAD4: DACC0000 02000103
	v_xor_b32_e32 v3, 1, v0                                    // 00000054CADC: 3A060081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000054CAE0: BF870091
	.long 0xd44c0000                                           // 00000054CAE4: D44C0000
	v_cndmask_b32_e32 v1, 32, v3, vcc_lo                       // 00000054CAE8: 020206A0
	v_cndmask_b32_e64 v3, v0, v3, s0                           // 00000054CAEC: D5010003 00020700
	.long 0xd44a0000                                           // 00000054CAF4: D44A0000
	v_cndmask_b32_e32 v1, 0, v16, vcc_lo                       // 00000054CAF8: 02022080
	s_and_b32 s0, s0, vcc_lo                                   // 00000054CAFC: 8B006A00
	s_waitcnt lgkmcnt(0)                                       // 00000054CB00: BF89FC07
	v_dual_add_f32 v0, v1, v2 :: v_dual_lshlrev_b32 v1, 2, v3  // 00000054CB04: C9220501 00000682
	ds_bpermute_b32 v1, v1, v0                                 // 00000054CB0C: DACC0000 01000001
	s_and_saveexec_b32 s1, s0                                  // 00000054CB14: BE812000
	s_cbranch_execz 17                                         // 00000054CB18: BFA50011 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi16ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x660>
	s_waitcnt lgkmcnt(0)                                       // 00000054CB1C: BF89FC07
	v_add_f32_e32 v2, v0, v1                                   // 00000054CB20: 06040300
	.long 0xd73c0000                                           // 00000054CB24: D73C0000
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 00000054CB28: 02021281
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000054CB2C: BF870112
	v_bfe_u32 v3, v2, 16, 1                                    // 00000054CB30: D6100003 02052102
	.long 0xd7006a00                                           // 00000054CB38: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 00000054CB3C: 02020008
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000054CB40: BF870191
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 00000054CB44: D5207C01 01AA0209
	v_add3_u32 v2, v2, v3, 0x7fff                              // 00000054CB4C: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off                    // 00000054CB58: DC960000 007C0200
	s_endpgm                                                   // 00000054CB60: BFB00000
		...

