000000000059af00 <_ZN7halogen12_GLOBAL__N_16k_lq6kILi3ELi32ELi2ELb0EEEvPKhPKtPvll>:
; _ZN7halogen12_GLOBAL__N_16k_lq6kILi3ELi32ELi2ELb0EEEvPKhPKtPvll():
	s_load_b256 s[4:11], s[0:1], null                          // 00000059AF00: F40C0100 F8000000
	s_mov_b32 s3, 0                                            // 00000059AF08: BE830080
	v_bfe_u32 v5, v0, 5, 1                                     // 00000059AF0C: D6100005 02050B00
	s_lshl_b64 s[14:15], s[2:3], 2                             // 00000059AF14: 848E8202
	v_dual_mov_b32 v12, 0 :: v_dual_and_b32 v7, 31, v0         // 00000059AF18: CA240080 0C06009F
	v_lshrrev_b32_e32 v6, 6, v0                                // 00000059AF20: 320C0086
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v11, 0             // 00000059AF24: CA100080 0A0A0080
	s_waitcnt lgkmcnt(0)                                       // 00000059AF2C: BF89FC07
	s_ashr_i32 s12, s11, 31                                    // 00000059AF30: 860C9F0B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000059AF34: BF870499
	s_lshr_b32 s12, s12, 28                                    // 00000059AF38: 850C9C0C
	s_add_u32 s12, s10, s12                                    // 00000059AF3C: 800C0C0A
	s_addc_u32 s13, s11, 0                                     // 00000059AF40: 820D800B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000059AF44: BF870499
	s_lshr_b64 s[16:17], s[12:13], 4                           // 00000059AF48: 8590840C
	s_add_i32 s2, s16, 1                                       // 00000059AF4C: 81028110
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000059AF50: BF870499
	s_lshr_b32 s12, s2, 31                                     // 00000059AF54: 850C9F02
	s_add_i32 s2, s2, s12                                      // 00000059AF58: 81020C02
	s_load_b64 s[12:13], s[0:1], 0x20                          // 00000059AF5C: F4040300 F8000020
	s_ashr_i32 s2, s2, 1                                       // 00000059AF64: 86028102
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000059AF68: BF870099
	.long 0xd72c0001                                           // 00000059AF6C: D72C0001
	v_cndmask_b32_e32 v1, s2, v5, vcc_lo                       // 00000059AF70: 02020A02
	v_add_nc_u32_e32 v2, s2, v1                                // 00000059AF74: 4A040202
	v_add_nc_u32_e32 v8, v1, v7                                // 00000059AF78: 4A100F01
	s_mov_b32 s2, exec_lo                                      // 00000059AF7C: BE82007E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000059AF80: BF870092
	v_min_i32_e32 v9, s16, v2                                  // 00000059AF84: 22120410
	.long 0xd4c1007e                                           // 00000059AF88: D4C1007E
	v_cndmask_b32_e32 v1, v8, v9, vcc_lo                       // 00000059AF8C: 02021308
	s_cbranch_execz 434                                        // 00000059AF90: BFA501B2 <_ZN7halogen12_GLOBAL__N_16k_lq6kILi3ELi32ELi2ELb0EEEvPKhPKtPvll+0x75c>
	.long 0xd7000001                                           // 00000059AF94: D7000001
	v_cndmask_b32_e32 v1, s14, v6, vcc_lo                      // 00000059AF98: 02020C0E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000059AF9C: BF870001
	v_add_co_ci_u32_e64 v2, null, s15, 0, s0                   // 00000059AFA0: D5207C02 0001000F
	s_ashr_i32 s0, s11, 31                                     // 00000059AFA8: 86009F0B
	v_dual_mov_b32 v10, 0 :: v_dual_lshlrev_b32 v3, 4, v8      // 00000059AFAC: CA220080 0A021084
	s_lshr_b32 s0, s0, 24                                      // 00000059AFB4: 85009800
	s_waitcnt lgkmcnt(0)                                       // 00000059AFB8: BF89FC07
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 00000059AFBC: 7CA8020C
	s_add_u32 s0, s10, s0                                      // 00000059AFC0: 8000000A
	s_addc_u32 s1, s11, 0                                      // 00000059AFC4: 8201800B
	v_mov_b32_e32 v12, 0                                       // 00000059AFC8: 7E180280
	s_ashr_i64 s[0:1], s[0:1], 8                               // 00000059AFCC: 86808800
	v_dual_cndmask_b32 v2, 0, v2 :: v_dual_cndmask_b32 v1, 0, v1// 00000059AFD0: CA520480 02000280
	s_mulk_i32 s1, 0xd2                                        // 00000059AFD8: B80100D2
	s_mul_hi_u32 s16, s0, 0xd2                                 // 00000059AFDC: 9690FF00 000000D2
	s_mulk_i32 s0, 0xd2                                        // 00000059AFE4: B80000D2
	s_add_i32 s16, s16, s1                                     // 00000059AFE8: 81100110
	.long 0xd72c000b                                           // 00000059AFEC: D72C000B
	v_cndmask_b32_e32 v1, s0, v2, vcc_lo                       // 00000059AFF0: 02020400
	.long 0xd72c0004                                           // 00000059AFF4: D72C0004
	v_cndmask_b32_e32 v1, s16, v1, vcc_lo                      // 00000059AFF8: 02020210
	v_mad_u64_u32 v[1:2], null, s0, v1, s[4:5]                 // 00000059AFFC: D6FE7C01 00120200
	s_lshl_b64 s[4:5], s[10:11], 2                             // 00000059B004: 8484820A
	s_lshl_b64 s[10:11], s[10:11], 1                           // 00000059B008: 848A810A
	v_add3_u32 v2, v4, v2, v11                                 // 00000059B00C: D6550002 042E0504
	v_mov_b32_e32 v11, 0                                       // 00000059B014: 7E160280
	v_ashrrev_i32_e32 v4, 4, v8                                // 00000059B018: 34081084
	v_bfe_u32 v14, v8, 3, 1                                    // 00000059B01C: D610000E 02050708
	v_and_b32_e32 v15, 32, v3                                  // 00000059B024: 361E06A0
	v_and_b32_e32 v13, 15, v8                                  // 00000059B028: 361A108F
	v_and_b32_e32 v17, 16, v3                                  // 00000059B02C: 36220690
	.long 0xd72c0004                                           // 00000059B030: D72C0004
	v_cndmask_b32_e32 v1, 0xd2, v4, vcc_lo                     // 00000059B034: 020208FF 000000D2
	v_lshlrev_b32_e32 v16, 6, v14                              // 00000059B03C: 30201C86
	v_lshlrev_b32_e32 v14, 5, v14                              // 00000059B040: 301C1C85
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000059B044: BF8700A3
	v_ashrrev_i32_e32 v18, 31, v4                              // 00000059B048: 3424089F
	.long 0xd7006a15                                           // 00000059B04C: D7006A15
	v_cndmask_b32_e32 v1, v1, v4, vcc_lo                       // 00000059B050: 02020901
	v_add_co_ci_u32_e64 v22, null, v2, v18, vcc_lo             // 00000059B054: D5207C16 01AA2502
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000059B05C: BF8701A2
	.long 0xd7006a04                                           // 00000059B060: D7006A04
	v_cndmask_b32_e32 v1, v21, v16, vcc_lo                     // 00000059B064: 02022115
	.long 0xd7000010                                           // 00000059B068: D7000010
	v_cndmask_b32_e32 v1, v21, v14, vcc_lo                     // 00000059B06C: 02021D15
	v_add_co_ci_u32_e64 v18, null, 0, v22, vcc_lo              // 00000059B070: D5207C12 01AA2C80
	v_add_co_ci_u32_e64 v19, null, 0, v22, s0                  // 00000059B078: D5207C13 00022C80
	s_delay_alu instid0(VALU_DEP_4)                            // 00000059B080: BF870004
	.long 0xd7006a04                                           // 00000059B084: D7006A04
	v_cndmask_b32_e32 v1, v4, v15, vcc_lo                      // 00000059B088: 02021F04
	.long 0xd700010d                                           // 00000059B08C: D700010D
	v_cndmask_b32_e32 v1, v21, v13, vcc_lo                     // 00000059B090: 02021B15
	.long 0xd700000f                                           // 00000059B094: D700000F
	v_cndmask_b32_e32 v1, v16, v17, vcc_lo                     // 00000059B098: 02022310
	v_add_co_ci_u32_e64 v18, null, 0, v18, vcc_lo              // 00000059B09C: D5207C12 01AA2480
	v_add_co_ci_u32_e64 v14, null, 0, v22, s1                  // 00000059B0A4: D5207C0E 00062C80
	v_add_co_ci_u32_e64 v16, null, 0, v19, s0                  // 00000059B0AC: D5207C10 00022680
	.long 0xd7006a11                                           // 00000059B0B4: D7006A11
	v_cndmask_b32_e32 v1, v4, v17, vcc_lo                      // 00000059B0B8: 02022304
	s_delay_alu instid0(VALU_DEP_1)                            // 00000059B0BC: BF870001
	v_add_co_ci_u32_e64 v18, null, 0, v18, vcc_lo              // 00000059B0C0: D5207C12 01AA2480
	s_clause 0x3                                               // 00000059B0C8: BF850003
	global_load_i8 v45, v[13:14], off offset:192               // 00000059B0CC: DC4600C0 2D7C000D
	global_load_b128 v[13:16], v[15:16], off offset:128        // 00000059B0D4: DC5E0080 0D7C000F
	global_load_b128 v[17:20], v[17:18], off                   // 00000059B0DC: DC5E0000 117C0011
	global_load_d16_b16 v46, v[21:22], off offset:208          // 00000059B0E4: DC8200D0 2E7C0015
	v_ashrrev_i32_e32 v4, 31, v3                               // 00000059B0EC: 3408069F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000059B0F0: BF870121
	.long 0xd73c0015                                           // 00000059B0F4: D73C0015
	v_cndmask_b32_e32 v1, 1, v3, vcc_lo                        // 00000059B0F8: 02020681
	v_add_nc_u32_e32 v3, 0x200, v3                             // 00000059B0FC: 4A0606FF 00000200
	.long 0xd7006a21                                           // 00000059B104: D7006A21
	v_cndmask_b32_e32 v1, s6, v21, vcc_lo                      // 00000059B108: 02022A06
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000059B10C: BF870111
	v_add_co_ci_u32_e64 v34, null, s7, v22, vcc_lo             // 00000059B110: D5207C22 01AA2C07
	.long 0xd7006a25                                           // 00000059B118: D7006A25
	v_cndmask_b32_e32 v0, v33, v10, vcc_lo                     // 00000059B11C: 02001521
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000059B120: BF8700A1
	v_add_co_ci_u32_e64 v38, null, s11, v34, vcc_lo            // 00000059B124: D5207C26 01AA440B
	.long 0xd7006a29                                           // 00000059B12C: D7006A29
	v_cndmask_b32_e32 v0, v33, v4, vcc_lo                      // 00000059B130: 02000921
	v_add_co_ci_u32_e64 v42, null, s5, v34, vcc_lo             // 00000059B134: D5207C2A 01AA4405
	s_clause 0x5                                               // 00000059B13C: BF850005
	global_load_b128 v[21:24], v[33:34], off                   // 00000059B140: DC5E0000 157C0021
	global_load_b128 v[25:28], v[37:38], off                   // 00000059B148: DC5E0000 197C0025
	global_load_b128 v[29:32], v[41:42], off                   // 00000059B150: DC5E0000 1D7C0029
	global_load_b128 v[33:36], v[33:34], off offset:16         // 00000059B158: DC5E0010 217C0021
	global_load_b128 v[37:40], v[37:38], off offset:16         // 00000059B160: DC5E0010 257C0025
	global_load_b128 v[41:44], v[41:42], off offset:16         // 00000059B168: DC5E0010 297C0029
	s_waitcnt vmcnt(9)                                         // 00000059B170: BF8927F7
	v_cvt_f32_i32_e32 v45, v45                                 // 00000059B174: 7E5A0B2D
	s_waitcnt vmcnt(6)                                         // 00000059B178: BF891BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000059B17C: BF8701C1
	v_fma_mix_f32 v45, v46, v45, neg(0) op_sel_hi:[1,0,0]      // 00000059B180: CC20002D 8A025B2E
	v_and_b32_e32 v47, 6, v8                                   // 00000059B188: 365E1086
	v_and_b32_e32 v4, 4, v8                                    // 00000059B18C: 36081084
	v_add_nc_u32_e32 v8, 32, v8                                // 00000059B190: 4A1010A0
	v_or_b32_e32 v49, 8, v47                                   // 00000059B194: 38625E88
	v_or_b32_e32 v51, 16, v47                                  // 00000059B198: 38665E90
	v_or_b32_e32 v53, 24, v47                                  // 00000059B19C: 386A5E98
	v_or_b32_e32 v48, 8, v4                                    // 00000059B1A0: 38600888
	v_or_b32_e32 v50, 16, v4                                   // 00000059B1A4: 38640890
	v_or_b32_e32 v52, 24, v4                                   // 00000059B1A8: 38680898
	v_lshrrev_b32_e32 v54, v47, v13                            // 00000059B1AC: 326C1B2F
	v_lshrrev_b32_e32 v55, v49, v13                            // 00000059B1B0: 326E1B31
	v_lshrrev_b32_e32 v58, v49, v14                            // 00000059B1B4: 32741D31
	v_lshrrev_b32_e32 v60, v47, v15                            // 00000059B1B8: 32781F2F
	v_lshrrev_b32_e32 v61, v49, v15                            // 00000059B1BC: 327A1F31
	v_lshrrev_b32_e32 v62, v51, v15                            // 00000059B1C0: 327C1F33
	v_lshrrev_b32_e32 v15, v53, v15                            // 00000059B1C4: 321E1F35
	v_lshrrev_b32_e32 v49, v49, v16                            // 00000059B1C8: 32622131
	v_lshrrev_b32_e32 v56, v51, v13                            // 00000059B1CC: 32701B33
	v_lshrrev_b32_e32 v57, v47, v14                            // 00000059B1D0: 32721D2F
	v_lshrrev_b32_e32 v59, v51, v14                            // 00000059B1D4: 32761D33
	v_lshrrev_b32_e32 v47, v47, v16                            // 00000059B1D8: 325E212F
	v_lshrrev_b32_e32 v51, v51, v16                            // 00000059B1DC: 32662133
	v_lshrrev_b32_e32 v13, v53, v13                            // 00000059B1E0: 321A1B35
	v_lshrrev_b32_e32 v14, v53, v14                            // 00000059B1E4: 321C1D35
	v_lshrrev_b32_e32 v16, v53, v16                            // 00000059B1E8: 32202135
	v_lshlrev_b32_e32 v53, 4, v54                              // 00000059B1EC: 306A6C84
	v_bfe_u32 v54, v17, v48, 4                                 // 00000059B1F0: D6100036 02126111
	v_bfe_u32 v65, v18, v48, 4                                 // 00000059B1F8: D6100041 02126112
	v_bfe_u32 v67, v19, v4, 4                                  // 00000059B200: D6100043 02120913
	v_bfe_u32 v68, v19, v48, 4                                 // 00000059B208: D6100044 02126113
	v_bfe_u32 v69, v19, v50, 4                                 // 00000059B210: D6100045 02126513
	v_bfe_u32 v19, v19, v52, 4                                 // 00000059B218: D6100013 02126913
	v_lshlrev_b32_e32 v15, 4, v15                              // 00000059B220: 301E1E84
	v_bfe_u32 v48, v20, v48, 4                                 // 00000059B224: D6100030 02126114
	v_lshlrev_b32_e32 v49, 4, v49                              // 00000059B22C: 30626284
	v_bfe_u32 v46, v17, v4, 4                                  // 00000059B230: D610002E 02120911
	v_bfe_u32 v63, v17, v50, 4                                 // 00000059B238: D610003F 02126511
	v_bfe_u32 v64, v18, v4, 4                                  // 00000059B240: D6100040 02120912
	v_bfe_u32 v66, v18, v50, 4                                 // 00000059B248: D6100042 02126512
	v_bfe_u32 v4, v20, v4, 4                                   // 00000059B250: D6100004 02120914
	v_lshlrev_b32_e32 v47, 4, v47                              // 00000059B258: 305E5E84
	v_bfe_u32 v50, v20, v50, 4                                 // 00000059B25C: D6100032 02126514
	v_lshlrev_b32_e32 v51, 4, v51                              // 00000059B264: 30666684
	v_and_or_b32 v15, v15, 48, v19                             // 00000059B268: D657000F 044D610F
	v_and_or_b32 v19, v49, 48, v48                             // 00000059B270: D6570013 04C16131
	v_and_or_b32 v4, v47, 48, v4                               // 00000059B278: D6570004 0411612F
	v_bfe_u32 v18, v18, v52, 4                                 // 00000059B280: D6100012 02126912
	v_and_or_b32 v47, v51, 48, v50                             // 00000059B288: D657002F 04C96133
	v_bfe_u32 v20, v20, v52, 4                                 // 00000059B290: D6100014 02126914
	v_subrev_nc_u32_e32 v19, 32, v19                           // 00000059B298: 4E2626A0
	v_lshlrev_b32_e32 v16, 4, v16                              // 00000059B29C: 30202084
	v_subrev_nc_u32_e32 v15, 32, v15                           // 00000059B2A0: 4E1E1EA0
	v_subrev_nc_u32_e32 v47, 32, v47                           // 00000059B2A4: 4E5E5EA0
	v_subrev_nc_u32_e32 v4, 32, v4                             // 00000059B2A8: 4E0808A0
	v_cvt_f32_i32_e32 v19, v19                                 // 00000059B2AC: 7E260B13
	v_lshlrev_b32_e32 v14, 4, v14                              // 00000059B2B0: 301C1C84
	v_and_or_b32 v16, v16, 48, v20                             // 00000059B2B4: D6570010 04516110
	v_cvt_f32_i32_e32 v47, v47                                 // 00000059B2BC: 7E5E0B2F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000059B2C0: BF870214
	v_dual_mul_f32 v19, v45, v19 :: v_dual_lshlrev_b32 v60, 4, v60// 00000059B2C4: C8E2272D 133C7884
	v_and_or_b32 v14, v14, 48, v18                             // 00000059B2CC: D657000E 0449610E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000059B2D4: BF870214
	v_subrev_nc_u32_e32 v16, 32, v16                           // 00000059B2D8: 4E2020A0
	v_mul_f32_e32 v47, v45, v47                                // 00000059B2DC: 105E5F2D
	s_delay_alu instid0(VALU_DEP_4)                            // 00000059B2E0: BF870004
	v_and_or_b32 v18, v60, 48, v67                             // 00000059B2E4: D6570012 050D613C
	v_lshlrev_b32_e32 v56, 4, v56                              // 00000059B2EC: 30707084
	v_subrev_nc_u32_e32 v14, 32, v14                           // 00000059B2F0: 4E1C1CA0
	v_bfe_u32 v17, v17, v52, 4                                 // 00000059B2F4: D6100011 02126911
	v_lshlrev_b32_e32 v61, 4, v61                              // 00000059B2FC: 307A7A84
	v_subrev_nc_u32_e32 v18, 32, v18                           // 00000059B300: 4E2424A0
	v_lshlrev_b32_e32 v62, 4, v62                              // 00000059B304: 307C7C84
	v_cvt_f32_i32_e32 v14, v14                                 // 00000059B308: 7E1C0B0E
	v_lshlrev_b32_e32 v55, 4, v55                              // 00000059B30C: 306E6E84
	v_and_or_b32 v46, v53, 48, v46                             // 00000059B310: D657002E 04B96135
	v_cvt_f32_i32_e32 v18, v18                                 // 00000059B318: 7E240B12
	v_lshlrev_b32_e32 v13, 4, v13                              // 00000059B31C: 301A1A84
	v_cvt_f32_i32_e32 v15, v15                                 // 00000059B320: 7E1E0B0F
	v_lshlrev_b32_e32 v58, 4, v58                              // 00000059B324: 30747484
	v_cvt_f32_i32_e32 v4, v4                                   // 00000059B328: 7E080B04
	v_lshlrev_b32_e32 v57, 4, v57                              // 00000059B32C: 30727284
	v_cvt_f32_i32_e32 v16, v16                                 // 00000059B330: 7E200B10
	v_dual_mul_f32 v14, v45, v14 :: v_dual_lshlrev_b32 v59, 4, v59// 00000059B334: C8E21D2D 0E3A7684
	v_and_or_b32 v52, v55, 48, v54                             // 00000059B33C: D6570034 04D96137
	v_and_or_b32 v53, v56, 48, v63                             // 00000059B344: D6570035 04FD6138
	v_and_or_b32 v56, v61, 48, v68                             // 00000059B34C: D6570038 0511613D
	v_subrev_nc_u32_e32 v20, 32, v46                           // 00000059B354: 4E285CA0
	v_mul_f32_e32 v18, v45, v18                                // 00000059B358: 1024252D
	v_and_or_b32 v13, v13, 48, v17                             // 00000059B35C: D657000D 0445610D
	v_mul_f32_e32 v15, v45, v15                                // 00000059B364: 101E1F2D
	v_and_or_b32 v54, v58, 48, v65                             // 00000059B368: D6570036 0505613A
	v_mul_f32_e32 v4, v45, v4                                  // 00000059B370: 1008092D
	v_and_or_b32 v17, v57, 48, v64                             // 00000059B374: D6570011 05016139
	v_and_or_b32 v57, v62, 48, v69                             // 00000059B37C: D6570039 0515613E
	v_mul_f32_e32 v16, v45, v16                                // 00000059B384: 1020212D
	v_and_or_b32 v55, v59, 48, v66                             // 00000059B388: D6570037 0509613B
	v_subrev_nc_u32_e32 v46, 32, v52                           // 00000059B390: 4E5C68A0
	v_subrev_nc_u32_e32 v48, 32, v53                           // 00000059B394: 4E606AA0
	v_subrev_nc_u32_e32 v13, 32, v13                           // 00000059B398: 4E1A1AA0
	v_subrev_nc_u32_e32 v17, 32, v17                           // 00000059B39C: 4E2222A0
	v_subrev_nc_u32_e32 v49, 32, v54                           // 00000059B3A0: 4E626CA0
	v_subrev_nc_u32_e32 v50, 32, v55                           // 00000059B3A4: 4E646EA0
	v_subrev_nc_u32_e32 v51, 32, v56                           // 00000059B3A8: 4E6670A0
	v_subrev_nc_u32_e32 v52, 32, v57                           // 00000059B3AC: 4E6872A0
	v_cvt_f32_i32_e32 v20, v20                                 // 00000059B3B0: 7E280B14
	v_cvt_f32_i32_e32 v46, v46                                 // 00000059B3B4: 7E5C0B2E
	v_cvt_f32_i32_e32 v48, v48                                 // 00000059B3B8: 7E600B30
	v_cvt_f32_i32_e32 v13, v13                                 // 00000059B3BC: 7E1A0B0D
	v_cvt_f32_i32_e32 v17, v17                                 // 00000059B3C0: 7E220B11
	v_cvt_f32_i32_e32 v49, v49                                 // 00000059B3C4: 7E620B31
	v_cvt_f32_i32_e32 v50, v50                                 // 00000059B3C8: 7E640B32
	v_cvt_f32_i32_e32 v51, v51                                 // 00000059B3CC: 7E660B33
	v_cvt_f32_i32_e32 v52, v52                                 // 00000059B3D0: 7E680B34
	v_mul_f32_e32 v20, v45, v20                                // 00000059B3D4: 1028292D
	v_mul_f32_e32 v46, v45, v46                                // 00000059B3D8: 105C5D2D
	v_mul_f32_e32 v48, v45, v48                                // 00000059B3DC: 1060612D
	v_mul_f32_e32 v13, v45, v13                                // 00000059B3E0: 101A1B2D
	v_mul_f32_e32 v17, v45, v17                                // 00000059B3E4: 1022232D
	v_mul_f32_e32 v49, v45, v49                                // 00000059B3E8: 1062632D
	v_mul_f32_e32 v50, v45, v50                                // 00000059B3EC: 1064652D
	v_mul_f32_e32 v51, v45, v51                                // 00000059B3F0: 1066672D
	v_mul_f32_e32 v52, v45, v52                                // 00000059B3F4: 1068692D
	v_bfe_u32 v45, v20, 16, 1                                  // 00000059B3F8: D610002D 02052114
	v_bfe_u32 v53, v46, 16, 1                                  // 00000059B400: D6100035 0205212E
	v_bfe_u32 v54, v48, 16, 1                                  // 00000059B408: D6100036 02052130
	v_bfe_u32 v55, v13, 16, 1                                  // 00000059B410: D6100037 0205210D
	v_bfe_u32 v56, v17, 16, 1                                  // 00000059B418: D6100038 02052111
	v_add3_u32 v20, v20, v45, 0x7fff                           // 00000059B420: D6550014 03FE5B14 00007FFF
	v_add3_u32 v45, v46, v53, 0x7fff                           // 00000059B42C: D655002D 03FE6B2E 00007FFF
	v_add3_u32 v46, v48, v54, 0x7fff                           // 00000059B438: D655002E 03FE6D30 00007FFF
	v_bfe_u32 v57, v49, 16, 1                                  // 00000059B444: D6100039 02052131
	v_add3_u32 v13, v13, v55, 0x7fff                           // 00000059B44C: D655000D 03FE6F0D 00007FFF
	.long 0x7e5a3994                                           // 00000059B458: 7E5A3994
	v_bfe_u32 v58, v50, 16, 1                                  // 00000059B45C: D610003A 02052132
	v_add3_u32 v17, v17, v56, 0x7fff                           // 00000059B464: D6550011 03FE7111 00007FFF
	.long 0x7e1a39ae                                           // 00000059B470: 7E1A39AE
	v_bfe_u32 v59, v14, 16, 1                                  // 00000059B474: D610003B 0205210E
	s_waitcnt vmcnt(5)                                         // 00000059B47C: BF8917F7
	v_dot2_f32_bf16 v21, v21, v45, 0                           // 00000059B480: CC1A4015 1A025B15
	s_waitcnt vmcnt(4)                                         // 00000059B488: BF8913F7
	v_dot2_f32_bf16 v25, v25, v45, 0                           // 00000059B48C: CC1A4019 1A025B19
	s_waitcnt vmcnt(3)                                         // 00000059B494: BF890FF7
	v_dot2_f32_bf16 v29, v29, v45, 0                           // 00000059B498: CC1A401D 1A025B1D
	v_add3_u32 v48, v49, v57, 0x7fff                           // 00000059B4A0: D6550030 03FE7331 00007FFF
	v_bfe_u32 v60, v18, 16, 1                                  // 00000059B4AC: D610003C 02052112
	v_add3_u32 v49, v50, v58, 0x7fff                           // 00000059B4B4: D6550031 03FE7532 00007FFF
	.long 0x7e603991                                           // 00000059B4C0: 7E603991
	v_dot2_f32_bf16 v17, v22, v13, v21                         // 00000059B4C4: CC1A4011 1C561B16
	v_dot2_f32_bf16 v21, v26, v13, v25                         // 00000059B4CC: CC1A4015 1C661B1A
	v_dot2_f32_bf16 v13, v30, v13, v29                         // 00000059B4D4: CC1A400D 1C761B1E
	v_bfe_u32 v61, v51, 16, 1                                  // 00000059B4DC: D610003D 02052133
	v_add3_u32 v14, v14, v59, 0x7fff                           // 00000059B4E4: D655000E 03FE770E 00007FFF
	v_bfe_u32 v62, v52, 16, 1                                  // 00000059B4F0: D610003E 02052134
	v_add3_u32 v18, v18, v60, 0x7fff                           // 00000059B4F8: D6550012 03FE7912 00007FFF
	.long 0x7e1c39b1                                           // 00000059B504: 7E1C39B1
	v_dot2_f32_bf16 v17, v23, v48, v17                         // 00000059B508: CC1A4011 1C466117
	v_dot2_f32_bf16 v21, v27, v48, v21                         // 00000059B510: CC1A4015 1C56611B
	v_dot2_f32_bf16 v13, v31, v48, v13                         // 00000059B518: CC1A400D 1C36611F
	v_bfe_u32 v63, v15, 16, 1                                  // 00000059B520: D610003F 0205210F
	v_add3_u32 v20, v51, v61, 0x7fff                           // 00000059B528: D6550014 03FE7B33 00007FFF
	v_bfe_u32 v64, v4, 16, 1                                   // 00000059B534: D6100040 02052104
	v_add3_u32 v45, v52, v62, 0x7fff                           // 00000059B53C: D655002D 03FE7D34 00007FFF
	.long 0x7e283992                                           // 00000059B548: 7E283992
	v_dot2_f32_bf16 v17, v24, v14, v17                         // 00000059B54C: CC1A4011 1C461D18
	v_dot2_f32_bf16 v18, v28, v14, v21                         // 00000059B554: CC1A4012 1C561D1C
	v_dot2_f32_bf16 v13, v32, v14, v13                         // 00000059B55C: CC1A400D 1C361D20
	v_bfe_u32 v65, v19, 16, 1                                  // 00000059B564: D6100041 02052113
	v_add3_u32 v15, v15, v63, 0x7fff                           // 00000059B56C: D655000F 03FE7F0F 00007FFF
	v_bfe_u32 v66, v47, 16, 1                                  // 00000059B578: D6100042 0205212F
	v_add3_u32 v4, v4, v64, 0x7fff                             // 00000059B580: D6550004 03FE8104 00007FFF
	.long 0x7e1e39ad                                           // 00000059B58C: 7E1E39AD
	s_waitcnt vmcnt(2)                                         // 00000059B590: BF890BF7
	v_dot2_f32_bf16 v17, v33, v20, v17                         // 00000059B594: CC1A4011 1C462921
	s_waitcnt vmcnt(1)                                         // 00000059B59C: BF8907F7
	v_dot2_f32_bf16 v18, v37, v20, v18                         // 00000059B5A0: CC1A4012 1C4A2925
	s_waitcnt vmcnt(0)                                         // 00000059B5A8: BF8903F7
	v_dot2_f32_bf16 v13, v41, v20, v13                         // 00000059B5AC: CC1A400D 1C362929
	v_bfe_u32 v67, v16, 16, 1                                  // 00000059B5B4: D6100043 02052110
	v_add3_u32 v14, v19, v65, 0x7fff                           // 00000059B5BC: D655000E 03FE8313 00007FFF
	v_add3_u32 v19, v47, v66, 0x7fff                           // 00000059B5C8: D6550013 03FE852F 00007FFF
	.long 0x7e1c3984                                           // 00000059B5D4: 7E1C3984
	v_dot2_f32_bf16 v4, v34, v15, v17                          // 00000059B5D8: CC1A4004 1C461F22
	v_dot2_f32_bf16 v17, v38, v15, v18                         // 00000059B5E0: CC1A4011 1C4A1F26
	v_dot2_f32_bf16 v13, v42, v15, v13                         // 00000059B5E8: CC1A400D 1C361F2A
	v_add3_u32 v15, v16, v67, 0x7fff                           // 00000059B5F0: D655000F 03FE8710 00007FFF
	.long 0x7e1e3993                                           // 00000059B5FC: 7E1E3993
	v_dot2_f32_bf16 v4, v35, v14, v4                           // 00000059B600: CC1A4004 1C121D23
	v_dot2_f32_bf16 v16, v39, v14, v17                         // 00000059B608: CC1A4010 1C461D27
	v_dot2_f32_bf16 v13, v43, v14, v13                         // 00000059B610: CC1A400D 1C361D2B
	v_cmp_ge_i32_e32 vcc_lo, v8, v9                            // 00000059B618: 7C8C1308
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000059B61C: BF870214
	v_dot2_f32_bf16 v4, v36, v15, v4                           // 00000059B620: CC1A4004 1C121F24
	v_dot2_f32_bf16 v14, v40, v15, v16                         // 00000059B628: CC1A400E 1C421F28
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000059B630: BF8701A4
	v_dot2_f32_bf16 v13, v44, v15, v13                         // 00000059B634: CC1A400D 1C361F2C
	s_or_b32 s3, vcc_lo, s3                                    // 00000059B63C: 8C03036A
	v_add_f32_e32 v10, v10, v4                                 // 00000059B640: 0614090A
	s_delay_alu instid0(VALU_DEP_2)                            // 00000059B644: BF870002
	v_dual_add_f32 v12, v12, v14 :: v_dual_add_f32 v11, v11, v13// 00000059B648: C9081D0C 0C0A1B0B
	s_and_not1_b32 exec_lo, exec_lo, s3                        // 00000059B650: 917E037E
	s_cbranch_execnz 65136                                     // 00000059B654: BFA6FE70 <_ZN7halogen12_GLOBAL__N_16k_lq6kILi3ELi32ELi2ELb0EEEvPKhPKtPvll+0x118>
	s_or_b32 exec_lo, exec_lo, s3                              // 00000059B658: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000059B65C: BF8700B9
	s_or_b32 exec_lo, exec_lo, s2                              // 00000059B660: 8C7E027E
	.long 0xd71f0001                                           // 00000059B664: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000059B668: 020100C1
	s_mov_b32 s0, exec_lo                                      // 00000059B66C: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 00000059B670: 3A040290
	v_xor_b32_e32 v8, 8, v1                                    // 00000059B674: 3A100288
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000059B678: BF8701A2
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 00000059B67C: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 00000059B680: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 00000059B684: 7C9810A0
	s_delay_alu instid0(VALU_DEP_2)                            // 00000059B688: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 00000059B68C: 30040482
	v_cndmask_b32_e32 v8, v1, v8, vcc_lo                       // 00000059B690: 02101101
	ds_bpermute_b32 v3, v2, v10                                // 00000059B694: DACC0000 03000A02
	ds_bpermute_b32 v4, v2, v12                                // 00000059B69C: DACC0000 04000C02
	ds_bpermute_b32 v2, v2, v11                                // 00000059B6A4: DACC0000 02000B02
	s_waitcnt lgkmcnt(0)                                       // 00000059B6AC: BF89FC07
	v_dual_add_f32 v3, v10, v3 :: v_dual_add_f32 v4, v12, v4   // 00000059B6B0: C908070A 0304090C
	v_add_f32_e32 v2, v11, v2                                  // 00000059B6B8: 0604050B
	v_xor_b32_e32 v11, 4, v1                                   // 00000059B6BC: 3A160284
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000059B6C0: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v11                           // 00000059B6C4: 7C9816A0
	v_cndmask_b32_e32 v11, v1, v11, vcc_lo                     // 00000059B6C8: 02161701
	v_lshlrev_b32_e32 v11, 2, v11                              // 00000059B6CC: 30161682
	v_lshlrev_b32_e32 v8, 2, v8                                // 00000059B6D0: 30101082
	ds_bpermute_b32 v9, v8, v3                                 // 00000059B6D4: DACC0000 09000308
	s_waitcnt lgkmcnt(0)                                       // 00000059B6DC: BF89FC07
	v_add_f32_e32 v3, v3, v9                                   // 00000059B6E0: 06061303
	ds_bpermute_b32 v10, v8, v4                                // 00000059B6E4: DACC0000 0A000408
	ds_bpermute_b32 v8, v8, v2                                 // 00000059B6EC: DACC0000 08000208
	s_waitcnt lgkmcnt(0)                                       // 00000059B6F4: BF89FC07
	v_add_f32_e32 v2, v2, v8                                   // 00000059B6F8: 06041102
	ds_bpermute_b32 v8, v11, v3                                // 00000059B6FC: DACC0000 0800030B
	v_add_f32_e32 v4, v4, v10                                  // 00000059B704: 06081504
	ds_bpermute_b32 v10, v11, v2                               // 00000059B708: DACC0000 0A00020B
	s_waitcnt lgkmcnt(1)                                       // 00000059B710: BF89FC17
	v_add_f32_e32 v3, v3, v8                                   // 00000059B714: 06061103
	ds_bpermute_b32 v9, v11, v4                                // 00000059B718: DACC0000 0900040B
	v_xor_b32_e32 v11, 2, v1                                   // 00000059B720: 3A160282
	s_waitcnt lgkmcnt(1)                                       // 00000059B724: BF89FC17
	v_add_f32_e32 v2, v2, v10                                  // 00000059B728: 06041502
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000059B72C: BF8700A2
	v_cmp_gt_u32_e32 vcc_lo, 32, v11                           // 00000059B730: 7C9816A0
	v_cndmask_b32_e32 v11, v1, v11, vcc_lo                     // 00000059B734: 02161701
	v_lshlrev_b32_e32 v11, 2, v11                              // 00000059B738: 30161682
	ds_bpermute_b32 v8, v11, v3                                // 00000059B73C: DACC0000 0800030B
	s_waitcnt lgkmcnt(1)                                       // 00000059B744: BF89FC17
	v_add_f32_e32 v4, v4, v9                                   // 00000059B748: 06081304
	ds_bpermute_b32 v10, v11, v2                               // 00000059B74C: DACC0000 0A00020B
	ds_bpermute_b32 v9, v11, v4                                // 00000059B754: DACC0000 0900040B
	v_xor_b32_e32 v11, 1, v1                                   // 00000059B75C: 3A160281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000059B760: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v11                           // 00000059B764: 7C9816A0
	v_cndmask_b32_e32 v1, v1, v11, vcc_lo                      // 00000059B768: 02021701
	v_lshlrev_b32_e32 v11, 2, v1                               // 00000059B76C: 30160282
	s_waitcnt lgkmcnt(1)                                       // 00000059B770: BF89FC17
	v_dual_add_f32 v1, v3, v8 :: v_dual_add_f32 v2, v2, v10    // 00000059B774: C9081103 01021502
	s_waitcnt lgkmcnt(0)                                       // 00000059B77C: BF89FC07
	v_add_f32_e32 v3, v4, v9                                   // 00000059B780: 06061304
	ds_bpermute_b32 v4, v11, v1                                // 00000059B784: DACC0000 0400010B
	ds_bpermute_b32 v8, v11, v2                                // 00000059B78C: DACC0000 0800020B
	ds_bpermute_b32 v9, v11, v3                                // 00000059B794: DACC0000 0900030B
	v_cmpx_eq_u32_e32 0, v7                                    // 00000059B79C: 7D940E80
	s_cbranch_execz 12                                         // 00000059B7A0: BFA5000C <_ZN7halogen12_GLOBAL__N_16k_lq6kILi3ELi32ELi2ELb0EEEvPKhPKtPvll+0x8d4>
	v_mul_u32_u24_e32 v5, 12, v5                               // 00000059B7A4: 160A0A8C
	s_waitcnt lgkmcnt(0)                                       // 00000059B7A8: BF89FC07
	v_dual_add_f32 v3, v3, v9 :: v_dual_add_f32 v2, v2, v8     // 00000059B7AC: C9081303 03021102
	v_add_f32_e32 v1, v1, v4                                   // 00000059B7B4: 06020901
	s_delay_alu instid0(VALU_DEP_3)                            // 00000059B7B8: BF870003
	v_mad_u32_u24 v4, v6, 24, v5                               // 00000059B7BC: D60B0004 04153106
	ds_store_2addr_b32 v4, v1, v3 offset1:1                    // 00000059B7C4: D8380100 00030104
	ds_store_b32 v4, v2 offset:8                               // 00000059B7CC: D8340008 00000204
	s_or_b32 exec_lo, exec_lo, s0                              // 00000059B7D4: 8C7E007E
	.long 0xd7050001                                           // 00000059B7D8: D7050001
	v_cndmask_b32_e32 v1, 0xab, v0, vcc_lo                     // 00000059B7DC: 020200FF 000000AB
	.long 0x7f063880                                           // 00000059B7E4: 7F063880
	s_waitcnt lgkmcnt(0)                                       // 00000059B7E8: BF89FC07
	s_barrier                                                  // 00000059B7EC: BFBD0000
	buffer_gl0_inv                                             // 00000059B7F0: E0AC0000 00000000
	.long 0xd7390003                                           // 00000059B7F8: D7390003
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 00000059B7FC: 02020289
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000059B800: BF870091
	.long 0xd7000001                                           // 00000059B804: D7000001
	v_cndmask_b32_e32 v1, s14, v3, vcc_lo                      // 00000059B808: 0202060E
	v_add_co_ci_u32_e64 v2, null, s15, 0, s0                   // 00000059B80C: D5207C02 0001000F
	.long 0xd44c0000                                           // 00000059B814: D44C0000
	v_cndmask_b32_e32 v1, 12, v0, vcc_lo                       // 00000059B818: 0202008C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000059B81C: BF8704A2
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 00000059B820: 7CA8020C
	s_and_b32 s0, s0, vcc_lo                                   // 00000059B824: 8B006A00
	s_and_saveexec_b32 s1, s0                                  // 00000059B828: BE812000
	s_cbranch_execz 43                                         // 00000059B82C: BFA5002B <_ZN7halogen12_GLOBAL__N_16k_lq6kILi3ELi32ELi2ELb0EEEvPKhPKtPvll+0x9dc>
	.long 0xd7054000                                           // 00000059B830: D7054000
	v_cndmask_b32_e32 v0, v3, v131, vcc_lo                     // 00000059B834: 02010703
	v_mul_u32_u24_e32 v3, 24, v3                               // 00000059B838: 16060698
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000059B83C: BF870092
	.long 0xd7041000                                           // 00000059B840: D7041000
	v_cndmask_b32_e32 v1, v0, v0, vcc_lo                       // 00000059B844: 02020100
	v_and_b32_e32 v0, 0xff, v0                                 // 00000059B848: 360000FF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000059B850: BF8700B1
	v_lshl_add_u32 v3, v0, 2, v3                               // 00000059B854: D6460003 040D0500
	ds_load_2addr_b32 v[6:7], v3 offset1:3                     // 00000059B85C: D8DC0300 06000003
	v_mad_u64_u32 v[3:4], null, s12, v0, 0                     // 00000059B864: D6FE7C03 0202000C
	v_mad_u64_u32 v[4:5], null, s13, v0, v[4:5]                // 00000059B86C: D6FE7C04 0412000D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000059B874: BF870131
	.long 0xd73c0003                                           // 00000059B878: D73C0003
	v_cndmask_b32_e32 v1, 1, v3, vcc_lo                        // 00000059B87C: 02020681
	s_waitcnt lgkmcnt(0)                                       // 00000059B880: BF89FC07
	v_add_f32_e32 v0, 0, v6                                    // 00000059B884: 06000C80
	.long 0xd7006a03                                           // 00000059B888: D7006A03
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 00000059B88C: 02020608
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000059B890: BF8701B2
	v_add_f32_e32 v5, v0, v7                                   // 00000059B894: 060A0F00
	.long 0xd73c0000                                           // 00000059B898: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000059B89C: 02020281
	v_add_co_ci_u32_e64 v4, null, s9, v4, vcc_lo               // 00000059B8A0: D5207C04 01AA0809
	v_bfe_u32 v2, v5, 16, 1                                    // 00000059B8A8: D6100002 02052105
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000059B8B0: BF870093
	.long 0xd7006a00                                           // 00000059B8B4: D7006A00
	v_cndmask_b32_e32 v1, v3, v0, vcc_lo                       // 00000059B8B8: 02020103
	v_add_co_ci_u32_e64 v1, null, v4, v1, vcc_lo               // 00000059B8BC: D5207C01 01AA0304
	s_delay_alu instid0(VALU_DEP_3)                            // 00000059B8C4: BF870003
	v_add3_u32 v2, v5, v2, 0x7fff                              // 00000059B8C8: D6550002 03FE0505 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off                    // 00000059B8D4: DC960000 007C0200
	s_endpgm                                                   // 00000059B8DC: BFB00000
		...

