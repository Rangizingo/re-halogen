0000000000729a00 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi4ELi32ELi2ELb1EEEvPKhPKtPvll>:
; _ZN7halogen12_GLOBAL__N_18k_lq8s32ILi4ELi32ELi2ELb1EEEvPKhPKtPvll():
	s_clause 0x1                                               // 000000729A00: BF850001
	s_load_b256 s[4:11], s[0:1], null                          // 000000729A04: F40C0100 F8000000
	s_load_b64 s[12:13], s[0:1], 0x20                          // 000000729A0C: F4040300 F8000020
	s_mov_b32 s3, 0                                            // 000000729A14: BE830080
	v_lshrrev_b32_e32 v14, 6, v0                               // 000000729A18: 321C0086
	s_lshl_b64 s[2:3], s[2:3], 2                               // 000000729A1C: 84828202
	v_bfe_u32 v15, v0, 5, 1                                    // 000000729A20: D610000F 02050B00
	v_dual_mov_b32 v17, 0 :: v_dual_and_b32 v16, 31, v0        // 000000729A28: CA240080 1110009F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000729A30: BF870153
	v_or_b32_e32 v1, s2, v14                                   // 000000729A34: 38021C02
	v_mov_b32_e32 v2, s3                                       // 000000729A38: 7E040203
	.long 0x7e343880                                           // 000000729A3C: 7E343880
	s_waitcnt lgkmcnt(0)                                       // 000000729A40: BF89FC07
	s_ashr_i32 s0, s11, 31                                     // 000000729A44: 86009F0B
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 000000729A48: 7CA8020C
	s_lshr_b32 s0, s0, 28                                      // 000000729A4C: 85009C00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000729A50: BF8704A9
	s_add_u32 s0, s10, s0                                      // 000000729A54: 8000000A
	s_addc_u32 s1, s11, 0                                      // 000000729A58: 8201800B
	s_ashr_i64 s[0:1], s[0:1], 4                               // 000000729A5C: 86808400
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000729A60: 02020280
	s_add_u32 s14, s10, s0                                     // 000000729A64: 800E000A
	s_addc_u32 s1, s11, s1                                     // 000000729A68: 8201010B
	s_add_u32 s14, s14, 15                                     // 000000729A6C: 800E8F0E
	s_addc_u32 s1, s1, 0                                       // 000000729A70: 82018001
	s_add_i32 s15, s0, 1                                       // 000000729A74: 810F8100
	v_cndmask_b32_e64 v2, 0, s3, vcc_lo                        // 000000729A78: D5010002 01A80680
	s_lshr_b32 s16, s15, 31                                    // 000000729A80: 85109F0F
	s_and_b32 s14, s14, -16                                    // 000000729A84: 8B0ED00E
	s_add_i32 s15, s15, s16                                    // 000000729A88: 810F100F
	.long 0xd72c0005                                           // 000000729A8C: D72C0005
	v_cndmask_b32_e32 v0, v1, v1, vcc_lo                       // 000000729A90: 02000301
	s_ashr_i32 s15, s15, 1                                     // 000000729A94: 860F810F
	.long 0xd72c0006                                           // 000000729A98: D72C0006
	v_cndmask_b32_e32 v0, v2, v14, vcc_lo                      // 000000729A9C: 02001D02
	.long 0xd72c0004                                           // 000000729AA0: D72C0004
	v_cndmask_b32_e32 v1, s15, v15, vcc_lo                     // 000000729AA4: 02021E0F
	v_mad_u64_u32 v[10:11], null, v1, s14, s[4:5]              // 000000729AA8: D6FE7C0A 00101D01
	v_mov_b32_e32 v3, 0                                        // 000000729AB0: 7E060280
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v2, 0               // 000000729AB4: CA100080 01020080
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000729ABC: BF870214
	v_add_nc_u32_e32 v7, s15, v4                               // 000000729AC0: 4A0E080F
	v_add3_u32 v11, v6, v11, v5                                // 000000729AC4: D655000B 04161706
	v_add_nc_u32_e32 v18, v4, v16                              // 000000729ACC: 4A242104
	v_mov_b32_e32 v4, 0                                        // 000000729AD0: 7E080280
	.long 0xd7006a14                                           // 000000729AD4: D7006A14
	v_cndmask_b32_e32 v0, v10, v10, vcc_lo                     // 000000729AD8: 0200150A
	v_min_i32_e32 v19, s0, v7                                  // 000000729ADC: 22260E00
	v_add_co_ci_u32_e64 v21, null, s11, v11, vcc_lo            // 000000729AE0: D5207C15 01AA160B
	v_lshlrev_b32_e32 v12, 4, v18                              // 000000729AE8: 30182484
	s_delay_alu instid0(VALU_DEP_3)                            // 000000729AEC: BF870003
	v_cmp_lt_i32_e32 vcc_lo, v18, v19                          // 000000729AF0: 7C822712
	s_and_saveexec_b32 s1, vcc_lo                              // 000000729AF4: BE81206A
	s_cbranch_execz 19                                         // 000000729AF8: BFA50013 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi4ELi32ELi2ELb1EEEvPKhPKtPvll+0x148>
	v_lshlrev_b32_e32 v1, 4, v18                               // 000000729AFC: 30022484
	v_and_b32_e32 v3, -2, v18                                  // 000000729B00: 360624C2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000729B04: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000729B08: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000729B0C: 3408069F
	.long 0xd7000001                                           // 000000729B10: D7000001
	v_cndmask_b32_e32 v1, v10, v1, vcc_lo                      // 000000729B14: 0202030A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000729B18: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v11, v2, s0                  // 000000729B1C: D5207C02 0002050B
	.long 0xd7000005                                           // 000000729B24: D7000005
	v_cndmask_b32_e32 v1, v20, v3, vcc_lo                      // 000000729B28: 02020714
	v_add_co_ci_u32_e64 v6, null, v21, v4, s0                  // 000000729B2C: D5207C06 00020915
	s_clause 0x1                                               // 000000729B34: BF850001
	global_load_b128 v[1:4], v[1:2], off                       // 000000729B38: DC5E0000 017C0001
	global_load_d16_b16 v26, v[5:6], off                       // 000000729B40: DC820000 1A7C0005
	s_or_b32 exec_lo, exec_lo, s1                              // 000000729B48: 8C7E017E
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v24, 0             // 000000729B4C: CA100080 17180080
	v_mov_b32_e32 v22, 0                                       // 000000729B54: 7E2C0280
	s_and_saveexec_b32 s1, vcc_lo                              // 000000729B58: BE81206A
	s_cbranch_execz 371                                        // 000000729B5C: BFA50173 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi4ELi32ELi2ELb1EEEvPKhPKtPvll+0x72c>
	v_dual_mov_b32 v22, 0 :: v_dual_add_nc_u32 v25, 0x200, v12 // 000000729B60: CA200080 161818FF 00000200
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v23, 0             // 000000729B6C: CA100080 18160080
	v_mov_b32_e32 v17, 0                                       // 000000729B74: 7E220280
	s_mul_i32 s0, s11, 6                                       // 000000729B78: 9600860B
	s_mul_hi_u32 s14, s10, 6                                   // 000000729B7C: 968E860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 000000729B80: 8484820A
	s_add_i32 s14, s14, s0                                     // 000000729B84: 810E000E
	s_mul_i32 s16, s10, 6                                      // 000000729B88: 9610860A
	s_mov_b32 s15, 0                                           // 000000729B8C: BE8F0080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 000000729B90: 848A810A
	s_branch 324                                               // 000000729B94: BFA00144 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi4ELi32ELi2ELb1EEEvPKhPKtPvll+0x6a8>
	s_or_b32 exec_lo, exec_lo, s17                             // 000000729B98: 8C7E117E
	v_ashrrev_i32_e32 v13, 31, v12                             // 000000729B9C: 341A189F
	v_bfe_i32 v59, v1, 8, 8                                    // 000000729BA0: D611003B 02211101
	v_bfe_i32 v60, v1, 16, 8                                   // 000000729BA8: D611003C 02212101
	v_bfe_i32 v61, v2, 0, 8                                    // 000000729BB0: D611003D 02210102
	v_bfe_i32 v62, v2, 8, 8                                    // 000000729BB8: D611003E 02211102
	.long 0xd73c001b                                           // 000000729BC0: D73C001B
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 000000729BC4: 02021881
	v_bfe_i32 v13, v1, 0, 8                                    // 000000729BC8: D611000D 02210101
	v_bfe_i32 v63, v2, 16, 8                                   // 000000729BD0: D611003F 02212102
	v_ashrrev_i32_e32 v64, 24, v2                              // 000000729BD8: 34800498
	v_bfe_i32 v65, v3, 0, 8                                    // 000000729BDC: D6110041 02210103
	v_bfe_i32 v66, v3, 8, 8                                    // 000000729BE4: D6110042 02211103
	.long 0xd700002b                                           // 000000729BEC: D700002B
	v_cndmask_b32_e32 v1, s6, v27, vcc_lo                      // 000000729BF0: 02023606
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000729BF4: BF8701A1
	v_add_co_ci_u32_e64 v44, null, s7, v28, s0                 // 000000729BF8: D5207C2C 00023807
	v_bfe_i32 v67, v3, 16, 8                                   // 000000729C00: D6110043 02212103
	.long 0xd700002f                                           // 000000729C08: D700002F
	v_cndmask_b32_e32 v0, v43, v10, vcc_lo                     // 000000729C0C: 0200152B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000729C10: BF8700A1
	v_add_co_ci_u32_e64 v48, null, s11, v44, s0                // 000000729C14: D5207C30 0002580B
	.long 0xd7000033                                           // 000000729C1C: D7000033
	v_cndmask_b32_e32 v0, v43, v4, vcc_lo                      // 000000729C20: 0200092B
	v_add_co_ci_u32_e64 v52, null, s5, v44, s0                 // 000000729C24: D5207C34 00025805
	.long 0xd7000037                                           // 000000729C2C: D7000037
	v_cndmask_b32_e32 v0, v43, v16, vcc_lo                     // 000000729C30: 0200212B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000729C34: BF870001
	v_add_co_ci_u32_e64 v56, null, s14, v44, s0                // 000000729C38: D5207C38 0002580E
	s_clause 0x7                                               // 000000729C40: BF850007
	global_load_b128 v[27:30], v[43:44], off                   // 000000729C44: DC5E0000 1B7C002B
	global_load_b128 v[31:34], v[47:48], off                   // 000000729C4C: DC5E0000 1F7C002F
	global_load_b128 v[35:38], v[51:52], off                   // 000000729C54: DC5E0000 237C0033
	global_load_b128 v[39:42], v[55:56], off                   // 000000729C5C: DC5E0000 277C0037
	global_load_b128 v[43:46], v[43:44], off offset:16         // 000000729C64: DC5E0010 2B7C002B
	global_load_b128 v[47:50], v[47:48], off offset:16         // 000000729C6C: DC5E0010 2F7C002F
	global_load_b128 v[51:54], v[51:52], off offset:16         // 000000729C74: DC5E0010 337C0033
	global_load_b128 v[55:58], v[55:56], off offset:16         // 000000729C7C: DC5E0010 377C0037
	v_ashrrev_i32_e32 v68, 24, v3                              // 000000729C84: 34880698
	s_waitcnt vmcnt(9)                                         // 000000729C88: BF8927F7
	v_dual_mov_b32 v3, v7 :: v_dual_mov_b32 v2, v6             // 000000729C8C: CA100107 03020106
	v_cvt_f32_i32_e32 v6, v13                                  // 000000729C94: 7E0C0B0D
	.long 0x7f343880                                           // 000000729C98: 7F343880
	v_ashrrev_i32_e32 v1, 24, v1                               // 000000729C9C: 34020298
	v_bfe_i32 v69, v4, 0, 8                                    // 000000729CA0: D6110045 02210104
	v_bfe_i32 v70, v4, 8, 8                                    // 000000729CA8: D6110046 02211104
	v_bfe_i32 v71, v4, 16, 8                                   // 000000729CB0: D6110047 02212104
	v_ashrrev_i32_e32 v72, 24, v4                              // 000000729CB8: 34900898
	v_dual_mov_b32 v4, v8 :: v_dual_add_nc_u32 v25, 0x200, v25 // 000000729CBC: CA200108 041832FF 00000200
	v_cvt_f32_i32_e32 v7, v59                                  // 000000729CC8: 7E0E0B3B
	v_cvt_f32_i32_e32 v8, v60                                  // 000000729CCC: 7E100B3C
	v_fma_mix_f32 v6, v26, v6, neg(0) op_sel_hi:[1,0,0]        // 000000729CD0: CC200006 8A020D1A
	v_cvt_f32_i32_e32 v1, v1                                   // 000000729CD8: 7E020B01
	v_cvt_f32_i32_e32 v59, v61                                 // 000000729CDC: 7E760B3D
	v_fma_mix_f32 v7, v26, v7, neg(0) op_sel_hi:[1,0,0]        // 000000729CE0: CC200007 8A020F1A
	v_fma_mix_f32 v8, v26, v8, neg(0) op_sel_hi:[1,0,0]        // 000000729CE8: CC200008 8A02111A
	v_bfe_u32 v74, v6, 16, 1                                   // 000000729CF0: D610004A 02052106
	v_cvt_f32_i32_e32 v60, v62                                 // 000000729CF8: 7E780B3E
	v_cvt_f32_i32_e32 v61, v63                                 // 000000729CFC: 7E7A0B3F
	v_cvt_f32_i32_e32 v63, v64                                 // 000000729D00: 7E7E0B40
	v_cvt_f32_i32_e32 v64, v65                                 // 000000729D04: 7E800B41
	v_cvt_f32_i32_e32 v65, v66                                 // 000000729D08: 7E820B42
	v_cvt_f32_i32_e32 v66, v67                                 // 000000729D0C: 7E840B43
	v_cvt_f32_i32_e32 v68, v68                                 // 000000729D10: 7E880B44
	v_cvt_f32_i32_e32 v69, v69                                 // 000000729D14: 7E8A0B45
	v_cvt_f32_i32_e32 v70, v70                                 // 000000729D18: 7E8C0B46
	v_cvt_f32_i32_e32 v71, v71                                 // 000000729D1C: 7E8E0B47
	v_cvt_f32_i32_e32 v72, v72                                 // 000000729D20: 7E900B48
	v_fma_mix_f32 v1, v26, v1, neg(0) op_sel_hi:[1,0,0]        // 000000729D24: CC200001 8A02031A
	v_fma_mix_f32 v59, v26, v59, neg(0) op_sel_hi:[1,0,0]      // 000000729D2C: CC20003B 8A02771A
	v_bfe_u32 v75, v7, 16, 1                                   // 000000729D34: D610004B 02052107
	v_bfe_u32 v76, v8, 16, 1                                   // 000000729D3C: D610004C 02052108
	v_add3_u32 v6, v6, v74, 0x7fff                             // 000000729D44: D6550006 03FE9506 00007FFF
	v_fma_mix_f32 v60, v26, v60, neg(0) op_sel_hi:[1,0,0]      // 000000729D50: CC20003C 8A02791A
	v_fma_mix_f32 v61, v26, v61, neg(0) op_sel_hi:[1,0,0]      // 000000729D58: CC20003D 8A027B1A
	v_fma_mix_f32 v63, v26, v63, neg(0) op_sel_hi:[1,0,0]      // 000000729D60: CC20003F 8A027F1A
	v_fma_mix_f32 v64, v26, v64, neg(0) op_sel_hi:[1,0,0]      // 000000729D68: CC200040 8A02811A
	v_fma_mix_f32 v65, v26, v65, neg(0) op_sel_hi:[1,0,0]      // 000000729D70: CC200041 8A02831A
	v_fma_mix_f32 v66, v26, v66, neg(0) op_sel_hi:[1,0,0]      // 000000729D78: CC200042 8A02851A
	v_fma_mix_f32 v68, v26, v68, neg(0) op_sel_hi:[1,0,0]      // 000000729D80: CC200044 8A02891A
	v_fma_mix_f32 v69, v26, v69, neg(0) op_sel_hi:[1,0,0]      // 000000729D88: CC200045 8A028B1A
	v_fma_mix_f32 v70, v26, v70, neg(0) op_sel_hi:[1,0,0]      // 000000729D90: CC200046 8A028D1A
	v_fma_mix_f32 v71, v26, v71, neg(0) op_sel_hi:[1,0,0]      // 000000729D98: CC200047 8A028F1A
	v_fma_mix_f32 v72, v26, v72, neg(0) op_sel_hi:[1,0,0]      // 000000729DA0: CC200048 8A02911A
	v_bfe_u32 v77, v1, 16, 1                                   // 000000729DA8: D610004D 02052101
	v_bfe_u32 v78, v59, 16, 1                                  // 000000729DB0: D610004E 0205213B
	v_add3_u32 v7, v7, v75, 0x7fff                             // 000000729DB8: D6550007 03FE9707 00007FFF
	v_add3_u32 v8, v8, v76, 0x7fff                             // 000000729DC4: D6550008 03FE9908 00007FFF
	.long 0x7e343986                                           // 000000729DD0: 7E343986
	.long 0x7f1a399a                                           // 000000729DD4: 7F1A399A
	v_bfe_u32 v79, v60, 16, 1                                  // 000000729DD8: D610004F 0205213C
	v_bfe_u32 v80, v61, 16, 1                                  // 000000729DE0: D6100050 0205213D
	v_add3_u32 v1, v1, v77, 0x7fff                             // 000000729DE8: D6550001 03FE9B01 00007FFF
	v_add3_u32 v59, v59, v78, 0x7fff                           // 000000729DF4: D655003B 03FE9D3B 00007FFF
	.long 0x7e1a3988                                           // 000000729E00: 7E1A3988
	v_and_or_b32 v6, 0xffff0000, v7, v26                       // 000000729E04: D6570006 046A0EFF FFFF0000
	v_bfe_u32 v81, v63, 16, 1                                  // 000000729E10: D6100051 0205213F
	v_bfe_u32 v82, v64, 16, 1                                  // 000000729E18: D6100052 02052140
	v_add3_u32 v60, v60, v79, 0x7fff                           // 000000729E20: D655003C 03FE9F3C 00007FFF
	v_add3_u32 v61, v61, v80, 0x7fff                           // 000000729E2C: D655003D 03FEA13D 00007FFF
	v_and_or_b32 v1, 0xffff0000, v1, v13                       // 000000729E38: D6570001 043602FF FFFF0000
	.long 0x7e3439bb                                           // 000000729E44: 7E3439BB
	.long 0x7f7c399a                                           // 000000729E48: 7F7C399A
	v_bfe_u32 v83, v65, 16, 1                                  // 000000729E4C: D6100053 02052141
	v_bfe_u32 v84, v66, 16, 1                                  // 000000729E54: D6100054 02052142
	v_add3_u32 v63, v63, v81, 0x7fff                           // 000000729E5C: D655003F 03FEA33F 00007FFF
	v_add3_u32 v64, v64, v82, 0x7fff                           // 000000729E68: D6550040 03FEA540 00007FFF
	.long 0x7e7c39bd                                           // 000000729E74: 7E7C39BD
	v_bfe_u32 v85, v68, 16, 1                                  // 000000729E78: D6100055 02052144
	v_bfe_u32 v86, v69, 16, 1                                  // 000000729E80: D6100056 02052145
	v_add3_u32 v65, v65, v83, 0x7fff                           // 000000729E88: D6550041 03FEA741 00007FFF
	v_add3_u32 v66, v66, v84, 0x7fff                           // 000000729E94: D6550042 03FEA942 00007FFF
	v_and_or_b32 v7, 0xffff0000, v63, v62                      // 000000729EA0: D6570007 04FA7EFF FFFF0000
	.long 0x7f86399a                                           // 000000729EAC: 7F86399A
	v_bfe_u32 v87, v70, 16, 1                                  // 000000729EB0: D6100057 02052146
	v_bfe_u32 v88, v71, 16, 1                                  // 000000729EB8: D6100058 02052147
	v_add3_u32 v68, v68, v85, 0x7fff                           // 000000729EC0: D6550044 03FEAB44 00007FFF
	v_add3_u32 v69, v69, v86, 0x7fff                           // 000000729ECC: D6550045 03FEAD45 00007FFF
	.long 0x7e8639c2                                           // 000000729ED8: 7E8639C2
	v_bfe_u32 v89, v72, 16, 1                                  // 000000729EDC: D6100059 02052148
	v_add3_u32 v70, v70, v87, 0x7fff                           // 000000729EE4: D6550046 03FEAF46 00007FFF
	v_add3_u32 v71, v71, v88, 0x7fff                           // 000000729EF0: D6550047 03FEB147 00007FFF
	.long 0x7f92399a                                           // 000000729EFC: 7F92399A
	v_and_or_b32 v8, 0xffff0000, v68, v67                      // 000000729F00: D6570008 050E88FF FFFF0000
	v_add3_u32 v72, v72, v89, 0x7fff                           // 000000729F0C: D6550048 03FEB348 00007FFF
	s_and_b32 s0, exec_lo, vcc_lo                              // 000000729F18: 8B006A7E
	.long 0x7e9239c7                                           // 000000729F1C: 7E9239C7
	s_or_b32 s15, s0, s15                                      // 000000729F20: 8C0F0F00
	v_add_nc_u32_e32 v12, 0x200, v12                           // 000000729F24: 4A1818FF 00000200
	s_waitcnt vmcnt(7)                                         // 000000729F2C: BF891FF7
	v_dot2_f32_bf16 v13, v27, v6, 0                            // 000000729F30: CC1A400D 1A020D1B
	s_waitcnt vmcnt(6)                                         // 000000729F38: BF891BF7
	v_dot2_f32_bf16 v27, v31, v6, 0                            // 000000729F3C: CC1A401B 1A020D1F
	s_waitcnt vmcnt(5)                                         // 000000729F44: BF8917F7
	v_dot2_f32_bf16 v31, v35, v6, 0                            // 000000729F48: CC1A401F 1A020D23
	s_waitcnt vmcnt(4)                                         // 000000729F50: BF8913F7
	v_dot2_f32_bf16 v6, v39, v6, 0                             // 000000729F54: CC1A4006 1A020D27
	v_and_or_b32 v35, 0xffff0000, v60, v26                     // 000000729F5C: D6570023 046A78FF FFFF0000
	v_dot2_f32_bf16 v13, v28, v1, v13                          // 000000729F68: CC1A400D 1C36031C
	v_dot2_f32_bf16 v27, v32, v1, v27                          // 000000729F70: CC1A401B 1C6E0320
	v_dot2_f32_bf16 v28, v36, v1, v31                          // 000000729F78: CC1A401C 1C7E0324
	v_dot2_f32_bf16 v1, v40, v1, v6                            // 000000729F80: CC1A4001 1C1A0328
	.long 0x7e3439c0                                           // 000000729F88: 7E3439C0
	v_dot2_f32_bf16 v6, v29, v35, v13                          // 000000729F8C: CC1A4006 1C36471D
	v_dot2_f32_bf16 v13, v33, v35, v27                         // 000000729F94: CC1A400D 1C6E4721
	v_dot2_f32_bf16 v27, v37, v35, v28                         // 000000729F9C: CC1A401B 1C724725
	v_dot2_f32_bf16 v1, v41, v35, v1                           // 000000729FA4: CC1A4001 1C064729
	v_and_or_b32 v28, 0xffff0000, v65, v26                     // 000000729FAC: D657001C 046A82FF FFFF0000
	v_dot2_f32_bf16 v6, v30, v7, v6                            // 000000729FB8: CC1A4006 1C1A0F1E
	v_dot2_f32_bf16 v13, v34, v7, v13                          // 000000729FC0: CC1A400D 1C360F22
	v_dot2_f32_bf16 v27, v38, v7, v27                          // 000000729FC8: CC1A401B 1C6E0F26
	v_dot2_f32_bf16 v1, v42, v7, v1                            // 000000729FD0: CC1A4001 1C060F2A
	.long 0x7e3439c5                                           // 000000729FD8: 7E3439C5
	s_waitcnt vmcnt(3)                                         // 000000729FDC: BF890FF7
	v_dot2_f32_bf16 v6, v43, v28, v6                           // 000000729FE0: CC1A4006 1C1A392B
	s_waitcnt vmcnt(2)                                         // 000000729FE8: BF890BF7
	v_dot2_f32_bf16 v7, v47, v28, v13                          // 000000729FEC: CC1A4007 1C36392F
	s_waitcnt vmcnt(1)                                         // 000000729FF4: BF8907F7
	v_dot2_f32_bf16 v13, v51, v28, v27                         // 000000729FF8: CC1A400D 1C6E3933
	s_waitcnt vmcnt(0)                                         // 00000072A000: BF8903F7
	v_dot2_f32_bf16 v1, v55, v28, v1                           // 00000072A004: CC1A4001 1C063937
	v_and_or_b32 v26, 0xffff0000, v70, v26                     // 00000072A00C: D657001A 046A8CFF FFFF0000
	v_dot2_f32_bf16 v6, v44, v8, v6                            // 00000072A018: CC1A4006 1C1A112C
	v_dot2_f32_bf16 v7, v48, v8, v7                            // 00000072A020: CC1A4007 1C1E1130
	v_dot2_f32_bf16 v13, v52, v8, v13                          // 00000072A028: CC1A400D 1C361134
	v_dot2_f32_bf16 v1, v56, v8, v1                            // 00000072A030: CC1A4001 1C061138
	v_and_or_b32 v8, 0xffff0000, v72, v73                      // 00000072A038: D6570008 052690FF FFFF0000
	v_dot2_f32_bf16 v6, v45, v26, v6                           // 00000072A044: CC1A4006 1C1A352D
	v_dot2_f32_bf16 v7, v49, v26, v7                           // 00000072A04C: CC1A4007 1C1E3531
	v_dot2_f32_bf16 v13, v53, v26, v13                         // 00000072A054: CC1A400D 1C363535
	v_dot2_f32_bf16 v26, v57, v26, v1                          // 00000072A05C: CC1A401A 1C063539
	v_mov_b32_e32 v1, v5                                       // 00000072A064: 7E020305
	v_dot2_f32_bf16 v5, v46, v8, v6                            // 00000072A068: CC1A4005 1C1A112E
	v_dot2_f32_bf16 v6, v50, v8, v7                            // 00000072A070: CC1A4006 1C1E1132
	v_dot2_f32_bf16 v7, v54, v8, v13                           // 00000072A078: CC1A4007 1C361136
	v_dot2_f32_bf16 v8, v58, v8, v26                           // 00000072A080: CC1A4008 1C6A113A
	.long 0x7e343909                                           // 00000072A088: 7E343909
	v_add_f32_e32 v22, v22, v5                                 // 00000072A08C: 062C0B16
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000072A090: BF870214
	v_dual_add_f32 v24, v24, v6 :: v_dual_add_f32 v23, v23, v7 // 00000072A094: C9080D18 18160F17
	v_add_f32_e32 v17, v17, v8                                 // 00000072A09C: 06221111
	s_and_not1_b32 exec_lo, exec_lo, s15                       // 00000072A0A0: 917E0F7E
	s_cbranch_execz 32                                         // 00000072A0A4: BFA50020 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi4ELi32ELi2ELb1EEEvPKhPKtPvll+0x728>
	s_waitcnt vmcnt(1)                                         // 00000072A0A8: BF8907F7
	v_dual_mov_b32 v5, v1 :: v_dual_add_nc_u32 v18, 32, v18    // 00000072A0AC: CA200101 051224A0
	s_waitcnt vmcnt(0)                                         // 00000072A0B4: BF8903F7
	.long 0x7e12391a                                           // 00000072A0B8: 7E12391A
	v_dual_mov_b32 v6, v2 :: v_dual_mov_b32 v7, v3             // 00000072A0BC: CA100102 06060103
	v_mov_b32_e32 v8, v4                                       // 00000072A0C4: 7E100304
	s_mov_b32 s17, exec_lo                                     // 00000072A0C8: BE91007E
	v_cmp_ge_i32_e32 vcc_lo, v18, v19                          // 00000072A0CC: 7C8C2712
	.long 0xd4c1007e                                           // 00000072A0D0: D4C1007E
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 00000072A0D4: 02022712
	s_cbranch_execz 65199                                      // 00000072A0D8: BFA5FEAF <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi4ELi32ELi2ELb1EEEvPKhPKtPvll+0x198>
	v_and_b32_e32 v7, -2, v18                                  // 00000072A0DC: 360E24C2
	v_ashrrev_i32_e32 v6, 31, v25                              // 00000072A0E0: 340C329F
	.long 0xd7000005                                           // 00000072A0E4: D7000005
	v_cndmask_b32_e32 v1, v10, v25, vcc_lo                     // 00000072A0E8: 0202330A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000072A0EC: BF870193
	v_ashrrev_i32_e32 v8, 31, v7                               // 00000072A0F0: 34100E9F
	v_add_co_ci_u32_e64 v6, null, v11, v6, s0                  // 00000072A0F4: D5207C06 00020D0B
	.long 0xd700001b                                           // 00000072A0FC: D700001B
	v_cndmask_b32_e32 v1, v20, v7, vcc_lo                      // 00000072A100: 02020F14
	s_delay_alu instid0(VALU_DEP_1)                            // 00000072A104: BF870001
	v_add_co_ci_u32_e64 v28, null, v21, v8, s0                 // 00000072A108: D5207C1C 00021115
	s_clause 0x1                                               // 00000072A110: BF850001
	global_load_b128 v[5:8], v[5:6], off                       // 00000072A114: DC5E0000 057C0005
	global_load_d16_b16 v9, v[27:28], off                      // 00000072A11C: DC820000 097C001B
	s_branch 65180                                             // 00000072A124: BFA0FE9C <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi4ELi32ELi2ELb1EEEvPKhPKtPvll+0x198>
	s_or_b32 exec_lo, exec_lo, s15                             // 00000072A128: 8C7E0F7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000072A12C: BF8700C9
	s_or_b32 exec_lo, exec_lo, s1                              // 00000072A130: 8C7E017E
	s_waitcnt vmcnt(1)                                         // 00000072A134: BF8907F7
	.long 0xd71f0001                                           // 00000072A138: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000072A13C: 020100C1
	s_mov_b32 s0, exec_lo                                      // 00000072A140: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 00000072A144: 3A040290
	v_xor_b32_e32 v6, 8, v1                                    // 00000072A148: 3A0C0288
	v_xor_b32_e32 v10, 4, v1                                   // 00000072A14C: 3A140284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000072A150: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 00000072A154: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 00000072A158: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 00000072A15C: 7C980CA0
	s_delay_alu instid0(VALU_DEP_2)                            // 00000072A160: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 00000072A164: 30040482
	ds_bpermute_b32 v5, v2, v23                                // 00000072A168: DACC0000 05001702
	s_waitcnt lgkmcnt(0)                                       // 00000072A170: BF89FC07
	v_add_f32_e32 v5, v23, v5                                  // 00000072A174: 060A0B17
	ds_bpermute_b32 v3, v2, v22                                // 00000072A178: DACC0000 03001602
	ds_bpermute_b32 v4, v2, v24                                // 00000072A180: DACC0000 04001802
	ds_bpermute_b32 v2, v2, v17                                // 00000072A188: DACC0000 02001102
	s_waitcnt lgkmcnt(2)                                       // 00000072A190: BF89FC27
	v_dual_add_f32 v3, v22, v3 :: v_dual_cndmask_b32 v6, v1, v6// 00000072A194: C9120716 03060D01
	s_waitcnt lgkmcnt(0)                                       // 00000072A19C: BF89FC07
	v_add_f32_e32 v2, v17, v2                                  // 00000072A1A0: 06040511
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 00000072A1A4: 7C9814A0
	s_delay_alu instid0(VALU_DEP_3)                            // 00000072A1A8: BF870003
	v_lshlrev_b32_e32 v6, 2, v6                                // 00000072A1AC: 300C0C82
	v_cndmask_b32_e32 v10, v1, v10, vcc_lo                     // 00000072A1B0: 02141501
	ds_bpermute_b32 v9, v6, v5                                 // 00000072A1B4: DACC0000 09000506
	s_waitcnt lgkmcnt(0)                                       // 00000072A1BC: BF89FC07
	v_add_f32_e32 v5, v5, v9                                   // 00000072A1C0: 060A1305
	ds_bpermute_b32 v7, v6, v3                                 // 00000072A1C4: DACC0000 07000306
	s_waitcnt lgkmcnt(0)                                       // 00000072A1CC: BF89FC07
	v_dual_add_f32 v3, v3, v7 :: v_dual_lshlrev_b32 v10, 2, v10// 00000072A1D0: C9220F03 030A1482
	v_add_f32_e32 v4, v24, v4                                  // 00000072A1D8: 06080918
	ds_bpermute_b32 v8, v6, v4                                 // 00000072A1DC: DACC0000 08000406
	ds_bpermute_b32 v6, v6, v2                                 // 00000072A1E4: DACC0000 06000206
	s_waitcnt lgkmcnt(0)                                       // 00000072A1EC: BF89FC07
	v_add_f32_e32 v2, v2, v6                                   // 00000072A1F0: 06040D02
	ds_bpermute_b32 v6, v10, v3                                // 00000072A1F4: DACC0000 0600030A
	s_waitcnt lgkmcnt(0)                                       // 00000072A1FC: BF89FC07
	v_dual_add_f32 v3, v3, v6 :: v_dual_add_f32 v4, v4, v8     // 00000072A200: C9080D03 03041104
	ds_bpermute_b32 v8, v10, v5                                // 00000072A208: DACC0000 0800050A
	s_waitcnt lgkmcnt(0)                                       // 00000072A210: BF89FC07
	v_add_f32_e32 v5, v5, v8                                   // 00000072A214: 060A1105
	ds_bpermute_b32 v7, v10, v4                                // 00000072A218: DACC0000 0700040A
	ds_bpermute_b32 v9, v10, v2                                // 00000072A220: DACC0000 0900020A
	v_xor_b32_e32 v10, 2, v1                                   // 00000072A228: 3A140282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000072A22C: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 00000072A230: 7C9814A0
	v_cndmask_b32_e32 v10, v1, v10, vcc_lo                     // 00000072A234: 02141501
	v_lshlrev_b32_e32 v10, 2, v10                              // 00000072A238: 30141482
	s_waitcnt lgkmcnt(0)                                       // 00000072A23C: BF89FC07
	v_add_f32_e32 v6, v2, v9                                   // 00000072A240: 060C1302
	ds_bpermute_b32 v2, v10, v3                                // 00000072A244: DACC0000 0200030A
	v_add_f32_e32 v4, v4, v7                                   // 00000072A24C: 06080F04
	ds_bpermute_b32 v8, v10, v5                                // 00000072A250: DACC0000 0800050A
	ds_bpermute_b32 v9, v10, v6                                // 00000072A258: DACC0000 0900060A
	ds_bpermute_b32 v7, v10, v4                                // 00000072A260: DACC0000 0700040A
	v_xor_b32_e32 v10, 1, v1                                   // 00000072A268: 3A140281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000072A26C: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 00000072A270: 7C9814A0
	v_cndmask_b32_e32 v1, v1, v10, vcc_lo                      // 00000072A274: 02021501
	s_waitcnt lgkmcnt(3)                                       // 00000072A278: BF89FC37
	v_dual_add_f32 v1, v3, v2 :: v_dual_lshlrev_b32 v10, 2, v1 // 00000072A27C: C9220503 010A0282
	s_waitcnt lgkmcnt(2)                                       // 00000072A284: BF89FC27
	v_add_f32_e32 v3, v5, v8                                   // 00000072A288: 06061105
	s_waitcnt lgkmcnt(0)                                       // 00000072A28C: BF89FC07
	v_dual_add_f32 v5, v6, v9 :: v_dual_add_f32 v2, v4, v7     // 00000072A290: C9081306 05020F04
	ds_bpermute_b32 v4, v10, v1                                // 00000072A298: DACC0000 0400010A
	ds_bpermute_b32 v7, v10, v3                                // 00000072A2A0: DACC0000 0700030A
	ds_bpermute_b32 v8, v10, v5                                // 00000072A2A8: DACC0000 0800050A
	ds_bpermute_b32 v6, v10, v2                                // 00000072A2B0: DACC0000 0600020A
	v_cmpx_eq_u32_e32 0, v16                                   // 00000072A2B8: 7D942080
	s_cbranch_execz 12                                         // 00000072A2BC: BFA5000C <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi4ELi32ELi2ELb1EEEvPKhPKtPvll+0x8f0>
	s_waitcnt lgkmcnt(1)                                       // 00000072A2C0: BF89FC17
	v_dual_add_f32 v8, v5, v8 :: v_dual_lshlrev_b32 v9, 4, v15 // 00000072A2C4: C9221105 08081E84
	s_waitcnt lgkmcnt(0)                                       // 00000072A2CC: BF89FC07
	v_dual_add_f32 v7, v3, v7 :: v_dual_add_f32 v6, v2, v6     // 00000072A2D0: C9080F03 07060D02
	v_add_f32_e32 v5, v1, v4                                   // 00000072A2D8: 060A0901
	s_delay_alu instid0(VALU_DEP_3)                            // 00000072A2DC: BF870003
	v_lshl_or_b32 v1, v14, 5, v9                               // 00000072A2E0: D6560001 04250B0E
	ds_store_b128 v1, v[5:8]                                   // 00000072A2E8: DB7C0000 00000501
	s_or_b32 exec_lo, exec_lo, s0                              // 00000072A2F0: 8C7E007E
	v_lshrrev_b32_e32 v3, 2, v0                                // 00000072A2F4: 32060082
	v_mov_b32_e32 v2, s3                                       // 00000072A2F8: 7E040203
	.long 0xd44c0000                                           // 00000072A2FC: D44C0000
	v_cndmask_b32_e32 v1, 16, v0, vcc_lo                       // 00000072A300: 02020090
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000072A304: BF890007
	s_barrier                                                  // 00000072A308: BFBD0000
	v_or_b32_e32 v1, s2, v3                                    // 00000072A30C: 38020602
	buffer_gl0_inv                                             // 00000072A310: E0AC0000 00000000
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 00000072A318: 7CA8020C
	s_and_b32 s0, s0, vcc_lo                                   // 00000072A31C: 8B006A00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000072A320: BF870009
	s_and_saveexec_b32 s1, s0                                  // 00000072A324: BE812000
	s_cbranch_execz 31                                         // 00000072A328: BFA5001F <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi4ELi32ELi2ELb1EEEvPKhPKtPvll+0x9a8>
	v_and_b32_e32 v0, 3, v0                                    // 00000072A32C: 36000083
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000072A330: BF870091
	v_lshlrev_b32_e32 v4, 2, v0                                // 00000072A334: 30080082
	v_lshl_or_b32 v5, v3, 5, v4                                // 00000072A338: D6560005 04110B03
	v_mad_u64_u32 v[3:4], null, s12, v0, 0                     // 00000072A340: D6FE7C03 0202000C
	ds_load_2addr_b32 v[6:7], v5 offset1:4                     // 00000072A348: D8DC0400 06000005
	v_mad_u64_u32 v[4:5], null, s13, v0, v[4:5]                // 00000072A350: D6FE7C04 0412000D
	.long 0xd73c0000                                           // 00000072A358: D73C0000
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000072A35C: 02020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000072A360: BF870092
	.long 0xd73c0003                                           // 00000072A364: D73C0003
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 00000072A368: 02020682
	.long 0xd7006a03                                           // 00000072A36C: D7006A03
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 00000072A370: 02020608
	s_waitcnt lgkmcnt(0)                                       // 00000072A374: BF89FC07
	v_add_f32_e32 v2, 0, v6                                    // 00000072A378: 06040C80
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000072A37C: BF870193
	v_add_co_ci_u32_e64 v4, null, s9, v4, vcc_lo               // 00000072A380: D5207C04 01AA0809
	.long 0xd7006a00                                           // 00000072A388: D7006A00
	v_cndmask_b32_e32 v1, v3, v0, vcc_lo                       // 00000072A38C: 02020103
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000072A390: BF870193
	v_add_f32_e32 v2, v2, v7                                   // 00000072A394: 06040F02
	v_add_co_ci_u32_e64 v1, null, v4, v1, vcc_lo               // 00000072A398: D5207C01 01AA0304
	global_store_b32 v[0:1], v2, off                           // 00000072A3A0: DC6A0000 007C0200
	s_endpgm                                                   // 00000072A3A8: BFB00000
		...

