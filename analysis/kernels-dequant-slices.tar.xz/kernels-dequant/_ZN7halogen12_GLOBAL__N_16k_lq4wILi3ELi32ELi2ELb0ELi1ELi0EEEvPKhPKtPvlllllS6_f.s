00000000007c4600 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 0000007C4600: F4100100 F8000000
	v_dual_mov_b32 v18, 0 :: v_dual_and_b32 v1, 15, v0         // 0000007C4608: CA240080 1200008F
	v_lshrrev_b32_e32 v2, 2, v0                                // 0000007C4610: 32040082
	s_ashr_i32 s3, s2, 31                                      // 0000007C4614: 86039F02
	v_lshrrev_b32_e32 v14, 6, v0                               // 0000007C4618: 321C0086
	s_lshl_b64 s[20:21], s[2:3], 2                             // 0000007C461C: 84948202
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007C4620: BF8701A9
	v_dual_mov_b32 v4, s21 :: v_dual_lshlrev_b32 v1, 2, v1     // 0000007C4624: CA220015 04000282
	v_and_b32_e32 v2, 60, v2                                   // 0000007C462C: 360404BC
	v_or_b32_e32 v3, s20, v14                                  // 0000007C4630: 38061C14
	v_bfe_u32 v15, v0, 5, 1                                    // 0000007C4634: D610000F 02050B00
	.long 0x7f0e3880                                           // 0000007C463C: 7F0E3880
	v_mov_b32_e32 v17, 0                                       // 0000007C4640: 7E220280
	s_waitcnt lgkmcnt(0)                                       // 0000007C4644: BF89FC07
	s_clause 0x1                                               // 0000007C4648: BF850001
	global_load_b32 v5, v1, s[4:5]                             // 0000007C464C: DC520000 05040001
	global_load_b32 v6, v2, s[4:5]                             // 0000007C4654: DC520000 06040002
	s_add_u32 s2, s4, s14                                      // 0000007C465C: 80020E04
	s_addc_u32 s3, s5, s15                                     // 0000007C4660: 82030F05
	s_lshr_b32 s14, s11, 31                                    // 0000007C4664: 850E9F0B
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[3:4]                  // 0000007C4668: 7CA8060C
	s_add_u32 s14, s10, s14                                    // 0000007C466C: 800E0E0A
	s_addc_u32 s15, s11, 0                                     // 0000007C4670: 820F800B
	s_ashr_i32 s22, s11, 31                                    // 0000007C4674: 86169F0B
	s_ashr_i64 s[14:15], s[14:15], 1                           // 0000007C4678: 868E810E
	s_lshr_b32 s22, s22, 27                                    // 0000007C467C: 85169B16
	v_dual_cndmask_b32 v3, 0, v3 :: v_dual_and_b32 v16, 31, v0 // 0000007C4680: CA640680 0310009F
	s_add_u32 s22, s10, s22                                    // 0000007C4688: 8016160A
	s_addc_u32 s23, s11, 0                                     // 0000007C468C: 8217800B
	v_cndmask_b32_e64 v4, 0, s21, vcc_lo                       // 0000007C4690: D5010004 01A82A80
	s_lshr_b64 s[22:23], s[22:23], 5                           // 0000007C4698: 85968516
	.long 0xd72c0008                                           // 0000007C469C: D72C0008
	v_cndmask_b32_e32 v1, s19, v3, vcc_lo                      // 0000007C46A0: 02020613
	s_add_i32 s23, s22, 1                                      // 0000007C46A4: 81178116
	.long 0xd72c000d                                           // 0000007C46A8: D72C000D
	v_cndmask_b32_e32 v0, v3, v15, vcc_lo                      // 0000007C46AC: 02001F03
	s_lshr_b32 s19, s23, 31                                    // 0000007C46B0: 85139F17
	v_mad_u64_u32 v[9:10], null, v3, s14, s[2:3]               // 0000007C46B4: D6FE7C09 00081D03
	s_add_i32 s23, s23, s19                                    // 0000007C46BC: 81171317
	.long 0xd72c0015                                           // 0000007C46C0: D72C0015
	v_cndmask_b32_e32 v0, v4, v14, vcc_lo                      // 0000007C46C4: 02001D04
	s_ashr_i32 s15, s23, 1                                     // 0000007C46C8: 860F8117
	s_add_u32 s2, s4, s16                                      // 0000007C46CC: 80021004
	.long 0xd72c0013                                           // 0000007C46D0: D72C0013
	v_cndmask_b32_e32 v1, s15, v15, vcc_lo                     // 0000007C46D4: 02021E0F
	s_addc_u32 s3, s5, s17                                     // 0000007C46D8: 82031105
	.long 0xd72c0016                                           // 0000007C46DC: D72C0016
	v_cndmask_b32_e32 v1, s18, v4, vcc_lo                      // 0000007C46E0: 02020812
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v2, 0               // 0000007C46E4: CA100080 01020080
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000007C46EC: BF870214
	v_add3_u32 v10, v21, v10, v13                              // 0000007C46F0: D655000A 04361515
	v_add_nc_u32_e32 v4, s15, v19                              // 0000007C46F8: 4A08260F
	v_add_nc_u32_e32 v19, v19, v16                             // 0000007C46FC: 4A262113
	s_waitcnt vmcnt(1)                                         // 0000007C4700: BF8907F7
	v_bfe_u32 v11, v5, 16, 1                                   // 0000007C4704: D610000B 02052105
	s_waitcnt vmcnt(0)                                         // 0000007C470C: BF8903F7
	v_bfe_u32 v20, v6, 16, 1                                   // 0000007C4710: D6100014 02052106
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007C4718: BF8701A2
	v_add3_u32 v5, v5, v11, 0x7fff                             // 0000007C471C: D6550005 03FE1705 00007FFF
	v_mad_u64_u32 v[11:12], null, s18, v3, s[2:3]              // 0000007C4728: D6FE7C0B 000A0612
	v_add3_u32 v6, v6, v20, 0x7fff                             // 0000007C4730: D6550006 03FE2906 00007FFF
	v_mov_b32_e32 v3, 0                                        // 0000007C473C: 7E060280
	v_min_i32_e32 v20, s22, v4                                 // 0000007C4740: 22280816
	.long 0x7e0e3985                                           // 0000007C4744: 7E0E3985
	v_dual_mov_b32 v4, 0 :: v_dual_lshlrev_b32 v5, 2, v0       // 0000007C4748: CA220080 04040082
	v_add3_u32 v21, v8, v12, v22                               // 0000007C4750: D6550015 045A1908
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007C4758: BF870003
	v_and_or_b32 v6, 0xffff0000, v6, v7                        // 0000007C475C: D6570006 041E0CFF FFFF0000
	v_cmp_lt_i32_e32 vcc_lo, v19, v20                          // 0000007C4768: 7C822913
	ds_store_b32 v5, v6                                        // 0000007C476C: D8340000 00000605
	s_waitcnt lgkmcnt(0)                                       // 0000007C4774: BF89FC07
	s_barrier                                                  // 0000007C4778: BFBD0000
	buffer_gl0_inv                                             // 0000007C477C: E0AC0000 00000000
	s_and_saveexec_b32 s3, vcc_lo                              // 0000007C4784: BE83206A
	s_cbranch_execz 21                                         // 0000007C4788: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x1e0>
	v_lshlrev_b32_e32 v1, 1, v19                               // 0000007C478C: 30022681
	v_lshlrev_b32_e32 v3, 4, v19                               // 0000007C4790: 30062684
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007C4794: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000007C4798: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000007C479C: 3408069F
	.long 0xd7000201                                           // 0000007C47A0: D7000201
	v_cndmask_b32_e32 v1, v11, v1, vcc_lo                      // 0000007C47A4: 0202030B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007C47A8: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v21, v2, s2                  // 0000007C47AC: D5207C02 000A0515
	.long 0xd7000203                                           // 0000007C47B4: D7000203
	v_cndmask_b32_e32 v1, v9, v3, vcc_lo                       // 0000007C47B8: 02020709
	v_add_co_ci_u32_e64 v4, null, v10, v4, s2                  // 0000007C47BC: D5207C04 000A090A
	s_clause 0x1                                               // 0000007C47C4: BF850001
	global_load_d16_b16 v5, v[1:2], off                        // 0000007C47C8: DC820000 057C0001
	global_load_b128 v[1:4], v[3:4], off                       // 0000007C47D0: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 0000007C47D8: BF8907F7
	v_cvt_f32_f16_e32 v18, v5                                  // 0000007C47DC: 7E241705
	s_or_b32 exec_lo, exec_lo, s3                              // 0000007C47E0: 8C7E037E
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v22, 0             // 0000007C47E4: CA100080 17160080
	s_and_saveexec_b32 s3, vcc_lo                              // 0000007C47EC: BE83206A
	s_cbranch_execz 314                                        // 0000007C47F0: BFA5013A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x6dc>
	v_dual_mov_b32 v22, 0 :: v_dual_add_nc_u32 v5, 32, v19     // 0000007C47F4: CA200080 160426A0
	v_dual_mov_b32 v23, 0 :: v_dual_lshlrev_b32 v12, 5, v19    // 0000007C47FC: CA220080 170C2685
	s_lshl_b64 s[4:5], s[10:11], 2                             // 0000007C4804: 8484820A
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007C4808: BF870002
	v_dual_mov_b32 v17, 0 :: v_dual_lshlrev_b32 v24, 4, v5     // 0000007C480C: CA220080 11180A84
	v_dual_mov_b32 v26, v18 :: v_dual_lshlrev_b32 v25, 1, v5   // 0000007C4814: CA220112 1A180A81
	s_mov_b32 s14, 0                                           // 0000007C481C: BE8E0080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 0000007C4820: 848A810A
	s_branch 269                                               // 0000007C4824: BFA0010D <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x65c>
	s_or_b32 exec_lo, exec_lo, s15                             // 0000007C4828: 8C7E0F7E
	v_ashrrev_i32_e32 v13, 31, v12                             // 0000007C482C: 341A189F
	v_lshrrev_b32_e32 v75, 6, v1                               // 0000007C4830: 32960286
	v_lshrrev_b32_e32 v76, 14, v1                              // 0000007C4834: 3298028E
	v_and_b32_e32 v77, 0xff, v2                                // 0000007C4838: 369A04FF 000000FF
	v_lshrrev_b32_e32 v78, 6, v2                               // 0000007C4840: 329C0486
	.long 0xd73c001b                                           // 0000007C4844: D73C001B
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 0000007C4848: 02021881
	v_and_b32_e32 v13, 0xff, v1                                // 0000007C484C: 361A02FF 000000FF
	v_and_b32_e32 v75, 0x3fc, v75                              // 0000007C4854: 369696FF 000003FC
	v_and_b32_e32 v76, 0x3fc, v76                              // 0000007C485C: 369898FF 000003FC
	v_lshrrev_b32_e32 v1, 22, v1                               // 0000007C4864: 32020296
	v_lshrrev_b32_e32 v79, 14, v2                              // 0000007C4868: 329E048E
	.long 0xd700023f                                           // 0000007C486C: D700023F
	v_cndmask_b32_e32 v1, s6, v27, vcc_lo                      // 0000007C4870: 02023606
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007C4874: BF8701A1
	v_add_co_ci_u32_e64 v64, null, s7, v28, s2                 // 0000007C4878: D5207C40 000A3807
	v_lshlrev_b32_e32 v13, 2, v13                              // 0000007C4880: 301A1A82
	.long 0xd7000243                                           // 0000007C4884: D7000243
	v_cndmask_b32_e32 v0, v63, v10, vcc_lo                     // 0000007C4888: 0200153F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007C488C: BF8700A1
	v_add_co_ci_u32_e64 v68, null, s11, v64, s2                // 0000007C4890: D5207C44 000A800B
	.long 0xd7000247                                           // 0000007C4898: D7000247
	v_cndmask_b32_e32 v0, v63, v4, vcc_lo                      // 0000007C489C: 0200093F
	v_add_co_ci_u32_e64 v72, null, s5, v64, s2                 // 0000007C48A0: D5207C48 000A8005
	s_clause 0xb                                               // 0000007C48A8: BF85000B
	global_load_b128 v[27:30], v[63:64], off                   // 0000007C48AC: DC5E0000 1B7C003F
	global_load_b128 v[31:34], v[67:68], off                   // 0000007C48B4: DC5E0000 1F7C0043
	global_load_b128 v[35:38], v[71:72], off                   // 0000007C48BC: DC5E0000 237C0047
	global_load_b128 v[39:42], v[63:64], off offset:16         // 0000007C48C4: DC5E0010 277C003F
	global_load_b128 v[43:46], v[67:68], off offset:16         // 0000007C48CC: DC5E0010 2B7C0043
	global_load_b128 v[47:50], v[71:72], off offset:16         // 0000007C48D4: DC5E0010 2F7C0047
	global_load_b128 v[51:54], v[63:64], off offset:32         // 0000007C48DC: DC5E0020 337C003F
	global_load_b128 v[55:58], v[67:68], off offset:32         // 0000007C48E4: DC5E0020 377C0043
	global_load_b128 v[59:62], v[71:72], off offset:32         // 0000007C48EC: DC5E0020 3B7C0047
	global_load_b128 v[63:66], v[63:64], off offset:48         // 0000007C48F4: DC5E0030 3F7C003F
	global_load_b128 v[67:70], v[67:68], off offset:48         // 0000007C48FC: DC5E0030 437C0043
	global_load_b128 v[71:74], v[71:72], off offset:48         // 0000007C4904: DC5E0030 477C0047
	ds_load_b32 v13, v13                                       // 0000007C490C: D8D80000 0D00000D
	ds_load_b32 v75, v75                                       // 0000007C4914: D8D80000 4B00004B
	ds_load_b32 v76, v76                                       // 0000007C491C: D8D80000 4C00004C
	v_lshrrev_b32_e32 v2, 22, v2                               // 0000007C4924: 32040496
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000007C4928: 360202FF 000003FC
	v_lshlrev_b32_e32 v77, 2, v77                              // 0000007C4930: 309A9A82
	v_and_b32_e32 v78, 0x3fc, v78                              // 0000007C4934: 369C9CFF 000003FC
	v_and_b32_e32 v79, 0x3fc, v79                              // 0000007C493C: 369E9EFF 000003FC
	v_and_b32_e32 v2, 0x3fc, v2                                // 0000007C4944: 360404FF 000003FC
	ds_load_b32 v1, v1                                         // 0000007C494C: D8D80000 01000001
	ds_load_b32 v77, v77                                       // 0000007C4954: D8D80000 4D00004D
	ds_load_b32 v78, v78                                       // 0000007C495C: D8D80000 4E00004E
	ds_load_b32 v79, v79                                       // 0000007C4964: D8D80000 4F00004F
	ds_load_b32 v2, v2                                         // 0000007C496C: D8D80000 02000002
	v_and_b32_e32 v80, 0xff, v3                                // 0000007C4974: 36A006FF 000000FF
	v_lshrrev_b32_e32 v81, 6, v3                               // 0000007C497C: 32A20686
	v_lshrrev_b32_e32 v82, 14, v3                              // 0000007C4980: 32A4068E
	v_lshrrev_b32_e32 v3, 22, v3                               // 0000007C4984: 32060696
	v_and_b32_e32 v83, 0xff, v4                                // 0000007C4988: 36A608FF 000000FF
	v_lshrrev_b32_e32 v84, 14, v4                              // 0000007C4990: 32A8088E
	v_add_nc_u32_e32 v24, 0x200, v24                           // 0000007C4994: 4A3030FF 00000200
	v_add_nc_u32_e32 v25, 64, v25                              // 0000007C499C: 4A3232C0
	v_and_b32_e32 v3, 0x3fc, v3                                // 0000007C49A0: 360606FF 000003FC
	v_add_nc_u32_e32 v12, 0x400, v12                           // 0000007C49A8: 4A1818FF 00000400
	s_and_b32 s2, exec_lo, vcc_lo                              // 0000007C49B0: 8B026A7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000007C49B4: BF870009
	s_or_b32 s14, s2, s14                                      // 0000007C49B8: 8C0E0E02
	s_waitcnt vmcnt(11) lgkmcnt(7)                             // 0000007C49BC: BF892C77
	v_dot2_f32_bf16 v27, v27, v13, 0                           // 0000007C49C0: CC1A401B 1A021B1B
	s_waitcnt vmcnt(10)                                        // 0000007C49C8: BF892BF7
	v_dot2_f32_bf16 v31, v31, v13, 0                           // 0000007C49CC: CC1A401F 1A021B1F
	s_waitcnt vmcnt(9)                                         // 0000007C49D4: BF8927F7
	v_dot2_f32_bf16 v13, v35, v13, 0                           // 0000007C49D8: CC1A400D 1A021B23
	v_lshrrev_b32_e32 v35, 6, v4                               // 0000007C49E0: 32460886
	v_lshrrev_b32_e32 v4, 22, v4                               // 0000007C49E4: 32080896
	s_waitcnt lgkmcnt(6)                                       // 0000007C49E8: BF89FC67
	v_dot2_f32_bf16 v27, v28, v75, v27                         // 0000007C49EC: CC1A401B 1C6E971C
	v_dot2_f32_bf16 v28, v32, v75, v31                         // 0000007C49F4: CC1A401C 1C7E9720
	v_dot2_f32_bf16 v13, v36, v75, v13                         // 0000007C49FC: CC1A400D 1C369724
	v_lshlrev_b32_e32 v31, 2, v80                              // 0000007C4A04: 303EA082
	v_and_b32_e32 v32, 0x3fc, v82                              // 0000007C4A08: 3640A4FF 000003FC
	s_waitcnt lgkmcnt(5)                                       // 0000007C4A10: BF89FC57
	v_dot2_f32_bf16 v27, v29, v76, v27                         // 0000007C4A14: CC1A401B 1C6E991D
	v_dot2_f32_bf16 v28, v33, v76, v28                         // 0000007C4A1C: CC1A401C 1C729921
	v_dot2_f32_bf16 v13, v37, v76, v13                         // 0000007C4A24: CC1A400D 1C369925
	v_and_b32_e32 v29, 0x3fc, v81                              // 0000007C4A2C: 363AA2FF 000003FC
	ds_load_b32 v32, v32                                       // 0000007C4A34: D8D80000 20000020
	s_waitcnt lgkmcnt(5)                                       // 0000007C4A3C: BF89FC57
	v_dot2_f32_bf16 v27, v30, v1, v27                          // 0000007C4A40: CC1A401B 1C6E031E
	v_dot2_f32_bf16 v28, v34, v1, v28                          // 0000007C4A48: CC1A401C 1C720322
	v_dot2_f32_bf16 v1, v38, v1, v13                           // 0000007C4A50: CC1A4001 1C360326
	ds_load_b32 v30, v31                                       // 0000007C4A58: D8D80000 1E00001F
	ds_load_b32 v29, v29                                       // 0000007C4A60: D8D80000 1D00001D
	s_waitcnt vmcnt(8) lgkmcnt(6)                              // 0000007C4A68: BF892067
	v_dot2_f32_bf16 v27, v39, v77, v27                         // 0000007C4A6C: CC1A401B 1C6E9B27
	s_waitcnt vmcnt(7)                                         // 0000007C4A74: BF891FF7
	v_dot2_f32_bf16 v28, v43, v77, v28                         // 0000007C4A78: CC1A401C 1C729B2B
	s_waitcnt vmcnt(6)                                         // 0000007C4A80: BF891BF7
	v_dot2_f32_bf16 v1, v47, v77, v1                           // 0000007C4A84: CC1A4001 1C069B2F
	v_lshlrev_b32_e32 v13, 2, v83                              // 0000007C4A8C: 301AA682
	v_and_b32_e32 v31, 0x3fc, v35                              // 0000007C4A90: 363E46FF 000003FC
	s_waitcnt lgkmcnt(5)                                       // 0000007C4A98: BF89FC57
	v_dot2_f32_bf16 v27, v40, v78, v27                         // 0000007C4A9C: CC1A401B 1C6E9D28
	v_dot2_f32_bf16 v28, v44, v78, v28                         // 0000007C4AA4: CC1A401C 1C729D2C
	v_dot2_f32_bf16 v1, v48, v78, v1                           // 0000007C4AAC: CC1A4001 1C069D30
	v_and_b32_e32 v33, 0x3fc, v84                              // 0000007C4AB4: 3642A8FF 000003FC
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000007C4ABC: 360808FF 000003FC
	s_waitcnt lgkmcnt(4)                                       // 0000007C4AC4: BF89FC47
	v_dot2_f32_bf16 v27, v41, v79, v27                         // 0000007C4AC8: CC1A401B 1C6E9F29
	v_dot2_f32_bf16 v28, v45, v79, v28                         // 0000007C4AD0: CC1A401C 1C729F2D
	v_dot2_f32_bf16 v1, v49, v79, v1                           // 0000007C4AD8: CC1A4001 1C069F31
	s_waitcnt lgkmcnt(3)                                       // 0000007C4AE0: BF89FC37
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007C4AE4: BF870193
	v_dot2_f32_bf16 v27, v42, v2, v27                          // 0000007C4AE8: CC1A401B 1C6E052A
	v_dot2_f32_bf16 v28, v46, v2, v28                          // 0000007C4AF0: CC1A401C 1C72052E
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007C4AF8: BF870003
	v_dot2_f32_bf16 v1, v50, v2, v1                            // 0000007C4AFC: CC1A4001 1C060532
	ds_load_b32 v2, v3                                         // 0000007C4B04: D8D80000 02000003
	ds_load_b32 v3, v13                                        // 0000007C4B0C: D8D80000 0300000D
	ds_load_b32 v13, v31                                       // 0000007C4B14: D8D80000 0D00001F
	ds_load_b32 v31, v33                                       // 0000007C4B1C: D8D80000 1F000021
	ds_load_b32 v33, v4                                        // 0000007C4B24: D8D80000 21000004
	s_waitcnt vmcnt(5) lgkmcnt(6)                              // 0000007C4B2C: BF891467
	v_dot2_f32_bf16 v4, v51, v30, v27                          // 0000007C4B30: CC1A4004 1C6E3D33
	s_waitcnt vmcnt(4)                                         // 0000007C4B38: BF8913F7
	v_dot2_f32_bf16 v27, v55, v30, v28                         // 0000007C4B3C: CC1A401B 1C723D37
	s_waitcnt vmcnt(3)                                         // 0000007C4B44: BF890FF7
	v_dot2_f32_bf16 v1, v59, v30, v1                           // 0000007C4B48: CC1A4001 1C063D3B
	s_waitcnt lgkmcnt(5)                                       // 0000007C4B50: BF89FC57
	v_dot2_f32_bf16 v4, v52, v29, v4                           // 0000007C4B54: CC1A4004 1C123B34
	v_dot2_f32_bf16 v27, v56, v29, v27                         // 0000007C4B5C: CC1A401B 1C6E3B38
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007C4B64: BF870193
	v_dot2_f32_bf16 v1, v60, v29, v1                           // 0000007C4B68: CC1A4001 1C063B3C
	v_dot2_f32_bf16 v4, v53, v32, v4                           // 0000007C4B70: CC1A4004 1C124135
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007C4B78: BF870193
	v_dot2_f32_bf16 v27, v57, v32, v27                         // 0000007C4B7C: CC1A401B 1C6E4139
	v_dot2_f32_bf16 v1, v61, v32, v1                           // 0000007C4B84: CC1A4001 1C06413D
	s_waitcnt lgkmcnt(4)                                       // 0000007C4B8C: BF89FC47
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007C4B90: BF870193
	v_dot2_f32_bf16 v4, v54, v2, v4                            // 0000007C4B94: CC1A4004 1C120536
	v_dot2_f32_bf16 v27, v58, v2, v27                          // 0000007C4B9C: CC1A401B 1C6E053A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007C4BA4: BF8701A3
	v_dot2_f32_bf16 v1, v62, v2, v1                            // 0000007C4BA8: CC1A4001 1C06053E
	s_waitcnt vmcnt(2) lgkmcnt(3)                              // 0000007C4BB0: BF890837
	v_dot2_f32_bf16 v2, v63, v3, v4                            // 0000007C4BB4: CC1A4002 1C12073F
	s_waitcnt vmcnt(1)                                         // 0000007C4BBC: BF8907F7
	v_dot2_f32_bf16 v4, v67, v3, v27                           // 0000007C4BC0: CC1A4004 1C6E0743
	s_waitcnt vmcnt(0)                                         // 0000007C4BC8: BF8903F7
	v_dot2_f32_bf16 v1, v71, v3, v1                            // 0000007C4BCC: CC1A4001 1C060747
	s_waitcnt lgkmcnt(2)                                       // 0000007C4BD4: BF89FC27
	v_dot2_f32_bf16 v2, v64, v13, v2                           // 0000007C4BD8: CC1A4002 1C0A1B40
	v_dot2_f32_bf16 v3, v68, v13, v4                           // 0000007C4BE0: CC1A4003 1C121B44
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007C4BE8: BF870003
	v_dot2_f32_bf16 v1, v72, v13, v1                           // 0000007C4BEC: CC1A4001 1C061B48
	v_mov_b32_e32 v4, v8                                       // 0000007C4BF4: 7E080308
	s_waitcnt lgkmcnt(1)                                       // 0000007C4BF8: BF89FC17
	v_dot2_f32_bf16 v8, v65, v31, v2                           // 0000007C4BFC: CC1A4008 1C0A3F41
	v_dot2_f32_bf16 v13, v69, v31, v3                          // 0000007C4C04: CC1A400D 1C0E3F45
	v_dot2_f32_bf16 v1, v73, v31, v1                           // 0000007C4C0C: CC1A4001 1C063F49
	v_dual_mov_b32 v3, v7 :: v_dual_mov_b32 v2, v6             // 0000007C4C14: CA100107 03020106
	s_waitcnt lgkmcnt(0)                                       // 0000007C4C1C: BF89FC07
	v_dot2_f32_bf16 v6, v66, v33, v8                           // 0000007C4C20: CC1A4006 1C224342
	v_dot2_f32_bf16 v7, v70, v33, v13                          // 0000007C4C28: CC1A4007 1C364346
	v_dot2_f32_bf16 v8, v74, v33, v1                           // 0000007C4C30: CC1A4008 1C06434A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007C4C38: BF870193
	v_dual_mov_b32 v1, v5 :: v_dual_fmac_f32 v22, v18, v6      // 0000007C4C3C: CA000105 01160D12
	v_fmac_f32_e32 v23, v18, v7                                // 0000007C4C44: 562E0F12
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007C4C48: BF870003
	v_fmac_f32_e32 v17, v18, v8                                // 0000007C4C4C: 56221112
	v_mov_b32_e32 v18, v26                                     // 0000007C4C50: 7E24031A
	s_and_not1_b32 exec_lo, exec_lo, s14                       // 0000007C4C54: 917E0E7E
	s_cbranch_execz 31                                         // 0000007C4C58: BFA5001F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x6d8>
	s_waitcnt vmcnt(0)                                         // 0000007C4C5C: BF8903F7
	v_dual_mov_b32 v6, v2 :: v_dual_add_nc_u32 v19, 32, v19    // 0000007C4C60: CA200102 061226A0
	v_dual_mov_b32 v5, v1 :: v_dual_mov_b32 v8, v4             // 0000007C4C68: CA100101 05080104
	v_mov_b32_e32 v7, v3                                       // 0000007C4C70: 7E0E0303
	s_mov_b32 s15, exec_lo                                     // 0000007C4C74: BE8F007E
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007C4C78: BF870003
	v_cmp_ge_i32_e32 vcc_lo, v19, v20                          // 0000007C4C7C: 7C8C2913
	.long 0xd4c1007e                                           // 0000007C4C80: D4C1007E
	v_cndmask_b32_e32 v1, v19, v20, vcc_lo                     // 0000007C4C84: 02022913
	s_cbranch_execz 65255                                      // 0000007C4C88: BFA5FEE7 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x228>
	v_ashrrev_i32_e32 v6, 31, v25                              // 0000007C4C8C: 340C329F
	v_ashrrev_i32_e32 v8, 31, v24                              // 0000007C4C90: 3410309F
	.long 0xd7000205                                           // 0000007C4C94: D7000205
	v_cndmask_b32_e32 v1, v11, v25, vcc_lo                     // 0000007C4C98: 0202330B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007C4C9C: BF8700A1
	v_add_co_ci_u32_e64 v6, null, v21, v6, s2                  // 0000007C4CA0: D5207C06 000A0D15
	.long 0xd7000207                                           // 0000007C4CA8: D7000207
	v_cndmask_b32_e32 v1, v9, v24, vcc_lo                      // 0000007C4CAC: 02023109
	v_add_co_ci_u32_e64 v8, null, v10, v8, s2                  // 0000007C4CB0: D5207C08 000A110A
	s_clause 0x1                                               // 0000007C4CB8: BF850001
	global_load_d16_b16 v13, v[5:6], off                       // 0000007C4CBC: DC820000 0D7C0005
	global_load_b128 v[5:8], v[7:8], off                       // 0000007C4CC4: DC5E0000 057C0007
	s_waitcnt vmcnt(1)                                         // 0000007C4CCC: BF8907F7
	v_cvt_f32_f16_e32 v26, v13                                 // 0000007C4CD0: 7E34170D
	s_branch 65236                                             // 0000007C4CD4: BFA0FED4 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x228>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000007C4CD8: 8C7E0E7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000007C4CDC: BF8700C9
	s_or_b32 exec_lo, exec_lo, s3                              // 0000007C4CE0: 8C7E037E
	s_waitcnt vmcnt(0)                                         // 0000007C4CE4: BF8903F7
	.long 0xd71f0001                                           // 0000007C4CE8: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000007C4CEC: 020100C1
	s_mov_b32 s2, exec_lo                                      // 0000007C4CF0: BE82007E
	v_xor_b32_e32 v2, 16, v1                                   // 0000007C4CF4: 3A040290
	v_xor_b32_e32 v5, 8, v1                                    // 0000007C4CF8: 3A0A0288
	v_xor_b32_e32 v8, 4, v1                                    // 0000007C4CFC: 3A100284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000007C4D00: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000007C4D04: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 0000007C4D08: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v5                            // 0000007C4D0C: 7C980AA0
	v_cndmask_b32_e32 v5, v1, v5, vcc_lo                       // 0000007C4D10: 020A0B01
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 0000007C4D14: 7C9810A0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007C4D18: BF870002
	v_lshlrev_b32_e32 v5, 2, v5                                // 0000007C4D1C: 300A0A82
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000007C4D20: 30040482
	ds_bpermute_b32 v3, v2, v22                                // 0000007C4D24: DACC0000 03001602
	s_waitcnt lgkmcnt(0)                                       // 0000007C4D2C: BF89FC07
	v_add_f32_e32 v3, v22, v3                                  // 0000007C4D30: 06060716
	ds_bpermute_b32 v4, v2, v23                                // 0000007C4D34: DACC0000 04001702
	ds_bpermute_b32 v2, v2, v17                                // 0000007C4D3C: DACC0000 02001102
	ds_bpermute_b32 v6, v5, v3                                 // 0000007C4D44: DACC0000 06000305
	v_cndmask_b32_e32 v8, v1, v8, vcc_lo                       // 0000007C4D4C: 02101101
	s_waitcnt lgkmcnt(2)                                       // 0000007C4D50: BF89FC27
	v_add_f32_e32 v4, v23, v4                                  // 0000007C4D54: 06080917
	s_waitcnt lgkmcnt(0)                                       // 0000007C4D58: BF89FC07
	v_add_f32_e32 v3, v3, v6                                   // 0000007C4D5C: 06060D03
	ds_bpermute_b32 v7, v5, v4                                 // 0000007C4D60: DACC0000 07000405
	v_add_f32_e32 v2, v17, v2                                  // 0000007C4D68: 06040511
	v_lshlrev_b32_e32 v8, 2, v8                                // 0000007C4D6C: 30101082
	ds_bpermute_b32 v5, v5, v2                                 // 0000007C4D70: DACC0000 05000205
	s_waitcnt lgkmcnt(1)                                       // 0000007C4D78: BF89FC17
	v_add_f32_e32 v4, v4, v7                                   // 0000007C4D7C: 06080F04
	ds_bpermute_b32 v6, v8, v4                                 // 0000007C4D80: DACC0000 06000408
	s_waitcnt lgkmcnt(0)                                       // 0000007C4D88: BF89FC07
	v_add_f32_e32 v4, v4, v6                                   // 0000007C4D8C: 06080D04
	v_add_f32_e32 v2, v2, v5                                   // 0000007C4D90: 06040B02
	ds_bpermute_b32 v5, v8, v3                                 // 0000007C4D94: DACC0000 05000308
	ds_bpermute_b32 v7, v8, v2                                 // 0000007C4D9C: DACC0000 07000208
	v_xor_b32_e32 v8, 2, v1                                    // 0000007C4DA4: 3A100282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007C4DA8: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 0000007C4DAC: 7C9810A0
	v_cndmask_b32_e32 v8, v1, v8, vcc_lo                       // 0000007C4DB0: 02101101
	s_waitcnt lgkmcnt(1)                                       // 0000007C4DB4: BF89FC17
	v_dual_add_f32 v3, v3, v5 :: v_dual_lshlrev_b32 v8, 2, v8  // 0000007C4DB8: C9220B03 03081082
	s_waitcnt lgkmcnt(0)                                       // 0000007C4DC0: BF89FC07
	v_add_f32_e32 v2, v2, v7                                   // 0000007C4DC4: 06040F02
	ds_bpermute_b32 v6, v8, v4                                 // 0000007C4DC8: DACC0000 06000408
	ds_bpermute_b32 v5, v8, v3                                 // 0000007C4DD0: DACC0000 05000308
	ds_bpermute_b32 v7, v8, v2                                 // 0000007C4DD8: DACC0000 07000208
	v_xor_b32_e32 v8, 1, v1                                    // 0000007C4DE0: 3A100281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007C4DE4: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 0000007C4DE8: 7C9810A0
	v_cndmask_b32_e32 v1, v1, v8, vcc_lo                       // 0000007C4DEC: 02021101
	v_lshlrev_b32_e32 v8, 2, v1                                // 0000007C4DF0: 30100282
	s_waitcnt lgkmcnt(1)                                       // 0000007C4DF4: BF89FC17
	v_add_f32_e32 v1, v3, v5                                   // 0000007C4DF8: 06020B03
	s_waitcnt lgkmcnt(0)                                       // 0000007C4DFC: BF89FC07
	v_dual_add_f32 v3, v4, v6 :: v_dual_add_f32 v2, v2, v7     // 0000007C4E00: C9080D04 03020F02
	ds_bpermute_b32 v4, v8, v1                                 // 0000007C4E08: DACC0000 04000108
	ds_bpermute_b32 v6, v8, v3                                 // 0000007C4E10: DACC0000 06000308
	ds_bpermute_b32 v5, v8, v2                                 // 0000007C4E18: DACC0000 05000208
	v_cmpx_eq_u32_e32 0, v16                                   // 0000007C4E20: 7D942080
	s_cbranch_execz 15                                         // 0000007C4E24: BFA5000F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x864>
	.long 0xd72c0007                                           // 0000007C4E28: D72C0007
	v_cndmask_b32_e32 v0, v14, v152, vcc_lo                    // 0000007C4E2C: 0201310E
	s_waitcnt lgkmcnt(0)                                       // 0000007C4E30: BF89FC07
	v_dual_add_f32 v1, v1, v4 :: v_dual_add_f32 v2, v2, v5     // 0000007C4E34: C9080901 01020B02
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C4E3C: BF870092
	v_mad_u32_u24 v7, v15, 12, v7                              // 0000007C4E40: D60B0007 041D190F
	v_dual_add_f32 v3, v3, v6 :: v_dual_add_nc_u32 v4, 0x400, v7// 0000007C4E48: C9200D03 03040EFF 00000400
	ds_store_2addr_b32 v4, v1, v3 offset1:1                    // 0000007C4E54: D8380100 00030104
	ds_store_b32 v7, v2 offset:1032                            // 0000007C4E5C: D8340408 00000207
	s_or_b32 exec_lo, exec_lo, s2                              // 0000007C4E64: 8C7E027E
	.long 0xd7050001                                           // 0000007C4E68: D7050001
	v_cndmask_b32_e32 v1, 0xab, v0, vcc_lo                     // 0000007C4E6C: 020200FF 000000AB
	.long 0x7f063880                                           // 0000007C4E74: 7F063880
	s_waitcnt lgkmcnt(0)                                       // 0000007C4E78: BF89FC07
	s_barrier                                                  // 0000007C4E7C: BFBD0000
	buffer_gl0_inv                                             // 0000007C4E80: E0AC0000 00000000
	.long 0xd7390003                                           // 0000007C4E88: D7390003
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 0000007C4E8C: 02020289
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C4E90: BF870091
	.long 0xd7000201                                           // 0000007C4E94: D7000201
	v_cndmask_b32_e32 v1, s20, v3, vcc_lo                      // 0000007C4E98: 02020614
	v_add_co_ci_u32_e64 v2, null, s21, 0, s2                   // 0000007C4E9C: D5207C02 00090015
	.long 0xd44c0002                                           // 0000007C4EA4: D44C0002
	v_cndmask_b32_e32 v1, 12, v0, vcc_lo                       // 0000007C4EA8: 0202008C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000007C4EAC: BF8704A2
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 0000007C4EB0: 7CA8020C
	s_and_b32 s2, s2, vcc_lo                                   // 0000007C4EB4: 8B026A02
	s_and_saveexec_b32 s3, s2                                  // 0000007C4EB8: BE832002
	s_cbranch_execz 85                                         // 0000007C4EBC: BFA50055 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0xa14>
	.long 0xd7054000                                           // 0000007C4EC0: D7054000
	v_cndmask_b32_e32 v0, v3, v131, vcc_lo                     // 0000007C4EC4: 02010703
	v_mul_u32_u24_e32 v3, 24, v3                               // 0000007C4EC8: 16060698
	s_load_b32 s0, s[0:1], 0x48                                // 0000007C4ECC: F4000000 F8000048
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C4ED4: BF870092
	.long 0xd7041000                                           // 0000007C4ED8: D7041000
	v_cndmask_b32_e32 v1, v0, v0, vcc_lo                       // 0000007C4EDC: 02020100
	v_and_b32_e32 v0, 0xff, v0                                 // 0000007C4EE0: 360000FF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C4EE8: BF870091
	v_lshl_add_u32 v3, v0, 2, v3                               // 0000007C4EEC: D6460003 040D0500
	v_add_nc_u32_e32 v3, 0x400, v3                             // 0000007C4EF4: 4A0606FF 00000400
	ds_load_2addr_b32 v[3:4], v3 offset1:3                     // 0000007C4EFC: D8DC0300 03000003
	s_waitcnt lgkmcnt(0)                                       // 0000007C4F04: BF89FC07
	v_add_f32_e32 v3, 0, v3                                    // 0000007C4F08: 06060680
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C4F0C: BF870091
	v_add_f32_e32 v3, v3, v4                                   // 0000007C4F10: 06060903
	v_bfe_u32 v4, v3, 16, 1                                    // 0000007C4F14: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C4F1C: BF870091
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000007C4F20: D6550003 03FE0903 00007FFF
	v_and_b32_e32 v3, 0xffff0000, v3                           // 0000007C4F2C: 360606FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C4F34: BF870091
	v_mul_f32_e32 v6, s0, v3                                   // 0000007C4F38: 100C0600
	v_mul_f32_e32 v3, 0xbfb8aa3b, v6                           // 0000007C4F3C: 10060CFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000007C4F44: BF870291
	v_exp_f32_e32 v3, v3                                       // 0000007C4F48: 7E064B03
	v_add_f32_e32 v7, 1.0, v3                                  // 0000007C4F4C: 060E06F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C4F50: BF870091
	v_div_scale_f32 v5, null, v7, v7, v6                       // 0000007C4F54: D6FC7C05 041A0F07
	v_rcp_f32_e32 v8, v5                                       // 0000007C4F5C: 7E105505
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C4F60: BF870095
	v_fma_f32 v3, -v5, v8, 1.0                                 // 0000007C4F64: D6130003 23CA1105
	v_fmac_f32_e32 v8, v3, v8                                  // 0000007C4F6C: 56101103
	v_div_scale_f32 v9, vcc_lo, v6, v7, v6                     // 0000007C4F70: D6FC6A09 041A0F06
	v_mad_u64_u32 v[3:4], null, s12, v0, 0                     // 0000007C4F78: D6FE7C03 0202000C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C4F80: BF870092
	v_mul_f32_e32 v10, v9, v8                                  // 0000007C4F84: 10141109
	v_fma_f32 v11, -v5, v10, v9                                // 0000007C4F88: D613000B 24261505
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C4F90: BF870091
	v_fmac_f32_e32 v10, v11, v8                                // 0000007C4F94: 5614110B
	v_fma_f32 v9, -v5, v10, v9                                 // 0000007C4F98: D6130009 24261505
	v_mad_u64_u32 v[4:5], null, s13, v0, v[4:5]                // 0000007C4FA0: D6FE7C04 0412000D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007C4FA8: BF870112
	v_div_fmas_f32 v0, v9, v8, v10                             // 0000007C4FAC: D6370000 042A1109
	.long 0xd73c0003                                           // 0000007C4FB4: D73C0003
	v_cndmask_b32_e32 v1, 1, v3, vcc_lo                        // 0000007C4FB8: 02020681
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007C4FBC: BF8701A2
	v_div_fixup_f32 v5, v0, v7, v6                             // 0000007C4FC0: D6270005 041A0F00
	.long 0xd73c0000                                           // 0000007C4FC8: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000007C4FCC: 02020281
	.long 0xd7006a03                                           // 0000007C4FD0: D7006A03
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 0000007C4FD4: 02020608
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007C4FD8: BF8701A3
	v_bfe_u32 v2, v5, 16, 1                                    // 0000007C4FDC: D6100002 02052105
	v_add_co_ci_u32_e64 v4, null, s9, v4, vcc_lo               // 0000007C4FE4: D5207C04 01AA0809
	.long 0xd7006a00                                           // 0000007C4FEC: D7006A00
	v_cndmask_b32_e32 v1, v3, v0, vcc_lo                       // 0000007C4FF0: 02020103
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007C4FF4: BF870193
	v_add3_u32 v2, v5, v2, 0x7fff                              // 0000007C4FF8: D6550002 03FE0505 00007FFF
	v_add_co_ci_u32_e64 v1, null, v4, v1, vcc_lo               // 0000007C5004: D5207C01 01AA0304
	global_store_d16_hi_b16 v[0:1], v2, off                    // 0000007C500C: DC960000 007C0200
	s_endpgm                                                   // 0000007C5014: BFB00000
		...

