000000000027d300 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi4ELb0EEEvPKhPtjjllllNS0_5DeqCbE>:
; _ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi4ELb0EEEvPKhPtjjllllNS0_5DeqCbE():
	s_load_b128 s[12:15], s[0:1], null                         // 00000027D300: F4080300 F8000000
	s_mov_b32 s3, exec_lo                                      // 00000027D308: BE83007E
	v_cmpx_gt_u32_e32 16, v0                                   // 00000027D30C: 7D980090
	s_cbranch_execz 7                                          // 00000027D310: BFA50007 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi4ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0x30>
	v_lshlrev_b32_e32 v1, 2, v0                                // 00000027D314: 30020082
	s_waitcnt lgkmcnt(0)                                       // 00000027D318: BF89FC07
	global_load_b32 v2, v1, s[12:13]                           // 00000027D31C: DC520000 020C0001
	s_waitcnt vmcnt(0)                                         // 00000027D324: BF8903F7
	ds_store_b32 v1, v2                                        // 00000027D328: D8340000 00000201
	s_or_b32 exec_lo, exec_lo, s3                              // 00000027D330: 8C7E037E
	s_load_b64 s[16:17], s[0:1], 0x10                          // 00000027D334: F4040400 F8000010
	s_lshl_b32 s21, s2, 10                                     // 00000027D33C: 84158A02
	s_waitcnt lgkmcnt(0)                                       // 00000027D340: BF89FC07
	s_cmp_ge_u32 s21, s17                                      // 00000027D344: BF091115
	s_cbranch_scc1 1571                                        // 00000027D348: BFA20623 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi4ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0x18d8>
	s_load_b256 s[4:11], s[0:1], 0x18                          // 00000027D34C: F40C0100 F8000018
	s_cvt_f32_u32 s3, s16                                      // 00000027D354: BE836510
	v_mov_b32_e32 v8, 0                                        // 00000027D358: 7E100280
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 00000027D35C: BF8702AA
	v_rcp_iflag_f32_e32 v1, s3                                 // 00000027D360: 7E025603
	s_load_b32 s3, s[0:1], 0x78                                // 00000027D364: F40000C0 F8000078
	v_readfirstlane_b32 s18, v1                                // 00000027D36C: 7E240501
	s_mul_f32 s18, s18, 0x4f7ffffe                             // 00000027D370: A212FF12 4F7FFFFE
	s_waitcnt lgkmcnt(0)                                       // 00000027D378: BF89FC07
	s_lshr_b32 s0, s5, 31                                      // 00000027D37C: 85009F05
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000027D380: BF870009
	s_add_u32 s0, s4, s0                                       // 00000027D384: 80000004
	s_addc_u32 s1, s5, 0                                       // 00000027D388: 82018005
	s_cvt_u32_f32 s20, s18                                     // 00000027D38C: BE946712
	s_ashr_i64 s[18:19], s[0:1], 1                             // 00000027D390: 86928100
	s_add_u32 s6, s12, s6                                      // 00000027D394: 8006060C
	s_addc_u32 s7, s13, s7                                     // 00000027D398: 8207070D
	s_add_u32 s8, s12, s8                                      // 00000027D39C: 8008080C
	s_addc_u32 s9, s13, s9                                     // 00000027D3A0: 8209090D
	s_sub_i32 s0, 0, s16                                       // 00000027D3A4: 81801080
	s_mov_b32 s12, 0                                           // 00000027D3A8: BE8C0080
	s_mul_i32 s0, s0, s20                                      // 00000027D3AC: 96001400
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000027D3B0: BF870499
	s_mul_hi_u32 s0, s20, s0                                   // 00000027D3B4: 96800014
	s_add_i32 s13, s20, s0                                     // 00000027D3B8: 810D0014
	s_mov_b32 s20, -1                                          // 00000027D3BC: BE9400C1
	s_branch 7                                                 // 00000027D3C0: BFA00007 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi4ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0xe0>
	s_or_b32 exec_lo, exec_lo, s1                              // 00000027D3C4: 8C7E017E
	s_add_i32 s2, s2, s3                                       // 00000027D3C8: 81020302
	s_mov_b32 s20, 0                                           // 00000027D3CC: BE940080
	s_lshl_b32 s21, s2, 10                                     // 00000027D3D0: 84158A02
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000027D3D4: BF870009
	s_cmp_lt_u32 s21, s17                                      // 00000027D3D8: BF0A1115
	s_cbranch_scc0 1534                                        // 00000027D3DC: BFA105FE <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi4ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0x18d8>
	v_or_b32_e32 v21, s21, v0                                  // 00000027D3E0: 382A0015
	s_add_i32 s0, s21, 0x400                                   // 00000027D3E4: 8100FF15 00000400
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000027D3EC: BF870009
	s_cmp_le_u32 s0, s17                                       // 00000027D3F0: BF0B1100
	s_cselect_b32 s21, -1, 0                                   // 00000027D3F4: 981580C1
	s_waitcnt vmcnt(3)                                         // 00000027D3F8: BF890FF7
	.long 0xd72d0001                                           // 00000027D3FC: D72D0001
	v_cndmask_b32_e32 v0, v21, v13, vcc_lo                     // 00000027D400: 02001B15
	v_add_nc_u32_e32 v11, 0x300, v21                           // 00000027D404: 4A162AFF 00000300
	s_cmp_gt_u32 s0, s17                                       // 00000027D40C: BF081100
	s_mov_b32 s0, -1                                           // 00000027D410: BE8000C1
	v_add_nc_u32_e32 v14, 0x100, v21                           // 00000027D414: 4A1C2AFF 00000100
	v_add_nc_u32_e32 v12, 0x200, v21                           // 00000027D41C: 4A182AFF 00000200
	.long 0xd72d0005                                           // 00000027D424: D72D0005
	v_cndmask_b32_e32 v0, v11, v13, vcc_lo                     // 00000027D428: 02001B0B
	s_waitcnt vmcnt(2)                                         // 00000027D42C: BF890BF7
	.long 0xd72c0002                                           // 00000027D430: D72C0002
	v_cndmask_b32_e32 v0, v1, v16, vcc_lo                      // 00000027D434: 02002101
	.long 0xd72d0007                                           // 00000027D438: D72D0007
	v_cndmask_b32_e32 v0, v14, v13, vcc_lo                     // 00000027D43C: 02001B0E
	.long 0xd72d0006                                           // 00000027D440: D72D0006
	v_cndmask_b32_e32 v0, v12, v13, vcc_lo                     // 00000027D444: 02001B0C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000027D448: BF870093
	v_sub_nc_u32_e32 v2, v21, v2                               // 00000027D44C: 4C040515
	v_subrev_nc_u32_e32 v4, s16, v2                            // 00000027D450: 4E080410
	v_cmp_le_u32_e32 vcc_lo, s16, v2                           // 00000027D454: 7C960410
	s_waitcnt vmcnt(1)                                         // 00000027D458: BF8907F7
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000027D45C: BF870092
	v_dual_cndmask_b32 v2, v2, v4 :: v_dual_add_nc_u32 v3, 1, v1// 00000027D460: CA600902 02020281
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 00000027D468: 02020701
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000027D46C: BF870112
	v_cmp_le_u32_e32 vcc_lo, s16, v2                           // 00000027D470: 7C960410
	v_add_nc_u32_e32 v3, 1, v1                                 // 00000027D474: 4A060281
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000027D478: BF870091
	v_cndmask_b32_e32 v15, v1, v3, vcc_lo                      // 00000027D47C: 021E0701
	.long 0xd72c0001                                           // 00000027D480: D72C0001
	v_cndmask_b32_e32 v0, v15, v16, vcc_lo                     // 00000027D484: 0200210F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000027D488: BF870091
	v_sub_nc_u32_e32 v1, v21, v1                               // 00000027D48C: 4C020315
	v_lshlrev_b32_e32 v16, 3, v1                               // 00000027D490: 30200283
	s_cbranch_scc1 174                                         // 00000027D494: BFA200AE <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi4ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0x450>
	.long 0xd72c0003                                           // 00000027D498: D72C0003
	v_cndmask_b32_e32 v0, v7, v16, vcc_lo                      // 00000027D49C: 02002107
	v_add_nc_u32_e32 v10, 1, v7                                // 00000027D4A0: 4A140E81
	v_mad_u64_u32 v[1:2], null, s18, v15, s[6:7]               // 00000027D4A4: D6FE7C01 001A1E12
	.long 0xd72c0012                                           // 00000027D4AC: D72C0012
	v_cndmask_b32_e32 v0, v6, v16, vcc_lo                      // 00000027D4B0: 02002106
	v_lshrrev_b32_e32 v17, 4, v16                              // 00000027D4B4: 32222084
	s_waitcnt vmcnt(0)                                         // 00000027D4B8: BF8903F7
	v_add_nc_u32_e32 v22, 1, v6                                // 00000027D4BC: 4A2C0C81
	v_lshrrev_b32_e32 v13, 1, v16                              // 00000027D4C0: 321A2081
	.long 0xd72c0017                                           // 00000027D4C4: D72C0017
	v_cndmask_b32_e32 v0, v5, v16, vcc_lo                      // 00000027D4C8: 02002105
	v_sub_nc_u32_e32 v9, v14, v3                               // 00000027D4CC: 4C12070E
	v_mad_u64_u32 v[3:4], null, s10, v15, s[8:9]               // 00000027D4D0: D6FE7C03 00221E0A
	v_and_b32_e32 v24, 0xffffffe, v17                          // 00000027D4D8: 363022FF 0FFFFFFE
	.long 0xd700001a                                           // 00000027D4E0: D700001A
	v_cndmask_b32_e32 v1, v1, v13, vcc_lo                      // 00000027D4E4: 02021B01
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000027D4E8: BF870124
	v_subrev_nc_u32_e32 v19, s16, v9                           // 00000027D4EC: 4E261210
	v_cmp_le_u32_e32 vcc_lo, s16, v9                           // 00000027D4F0: 7C961210
	v_dual_cndmask_b32 v20, v7, v10 :: v_dual_cndmask_b32 v19, v9, v19// 00000027D4F4: CA521507 14122709
	v_mad_u64_u32 v[9:10], null, s19, v15, v[2:3]              // 00000027D4FC: D6FE7C09 040A1E13
	v_sub_nc_u32_e32 v2, v12, v18                              // 00000027D504: 4C04250C
	v_mad_u64_u32 v[17:18], null, s11, v15, v[4:5]             // 00000027D508: D6FE7C11 04121E0B
	s_delay_alu instid0(VALU_DEP_4)                            // 00000027D510: BF870004
	v_add_nc_u32_e32 v25, 1, v20                               // 00000027D514: 4A322881
	v_cmp_le_u32_e32 vcc_lo, s16, v19                          // 00000027D518: 7C962610
	v_sub_nc_u32_e32 v10, v11, v23                             // 00000027D51C: 4C142F0B
	v_subrev_nc_u32_e32 v18, s16, v2                           // 00000027D520: 4E240410
	v_add_co_ci_u32_e64 v27, null, 0, v9, s0                   // 00000027D524: D5207C1B 00021280
	v_cndmask_b32_e32 v20, v20, v25, vcc_lo                    // 00000027D52C: 02283314
	v_cmp_le_u32_e32 vcc_lo, s16, v2                           // 00000027D530: 7C960410
	v_cndmask_b32_e32 v4, v6, v22, vcc_lo                      // 00000027D534: 02082D06
	v_cndmask_b32_e32 v9, v2, v18, vcc_lo                      // 00000027D538: 02122502
	.long 0xd7006a1c                                           // 00000027D53C: D7006A1C
	v_cndmask_b32_e32 v1, v3, v24, vcc_lo                      // 00000027D540: 02023103
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000027D544: BF870211
	v_add_co_ci_u32_e64 v29, null, 0, v17, vcc_lo              // 00000027D548: D5207C1D 01AA2280
	v_add_nc_u32_e32 v13, 1, v4                                // 00000027D550: 4A1A0881
	s_delay_alu instid0(VALU_DEP_4)                            // 00000027D554: BF870004
	v_cmp_le_u32_e32 vcc_lo, s16, v9                           // 00000027D558: 7C961210
	.long 0xd72c0013                                           // 00000027D55C: D72C0013
	v_cndmask_b32_e32 v0, v20, v16, vcc_lo                     // 00000027D560: 02002114
	v_mad_u64_u32 v[1:2], null, s18, v20, s[6:7]               // 00000027D564: D6FE7C01 001A2812
	v_add_nc_u32_e32 v9, 1, v5                                 // 00000027D56C: 4A120A81
	v_cndmask_b32_e32 v17, v4, v13, vcc_lo                     // 00000027D570: 02221B04
	v_mad_u64_u32 v[3:4], null, s10, v20, s[8:9]               // 00000027D574: D6FE7C03 0022280A
	v_subrev_nc_u32_e32 v13, s16, v10                          // 00000027D57C: 4E1A1410
	v_cmp_le_u32_e32 vcc_lo, s16, v10                          // 00000027D580: 7C961410
	v_sub_nc_u32_e32 v22, v14, v19                             // 00000027D584: 4C2C270E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000027D588: BF8701A4
	v_mad_u64_u32 v[18:19], null, s19, v20, v[2:3]             // 00000027D58C: D6FE7C12 040A2813
	.long 0xd72c0002                                           // 00000027D594: D72C0002
	v_cndmask_b32_e32 v0, v17, v16, vcc_lo                     // 00000027D598: 02002111
	v_lshlrev_b32_e32 v23, 3, v22                              // 00000027D59C: 302E2C83
	v_mad_u64_u32 v[24:25], null, s11, v20, v[4:5]             // 00000027D5A0: D6FE7C18 0412280B
	v_cndmask_b32_e32 v4, v10, v13, vcc_lo                     // 00000027D5A8: 02081B0A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 00000027D5AC: BF870254
	v_sub_nc_u32_e32 v34, v12, v2                              // 00000027D5B0: 4C44050C
	v_cndmask_b32_e32 v19, v5, v9, vcc_lo                      // 00000027D5B4: 02261305
	v_lshrrev_b32_e32 v9, 1, v22                               // 00000027D5B8: 32122C81
	v_lshrrev_b32_e32 v22, 1, v23                              // 00000027D5BC: 322C2E81
	v_cmp_le_u32_e32 vcc_lo, s16, v4                           // 00000027D5C0: 7C960810
	v_add_nc_u32_e32 v13, 1, v19                               // 00000027D5C4: 4A1A2681
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000027D5C8: BF8701A4
	v_and_b32_e32 v25, 0xffffffe, v9                           // 00000027D5CC: 363212FF 0FFFFFFE
	v_mad_u64_u32 v[9:10], null, s18, v17, s[6:7]              // 00000027D5D4: D6FE7C09 001A2212
	v_cndmask_b32_e32 v13, v19, v13, vcc_lo                    // 00000027D5DC: 021A1B13
	.long 0xd7006a1e                                           // 00000027D5E0: D7006A1E
	v_cndmask_b32_e32 v1, v1, v22, vcc_lo                      // 00000027D5E4: 02022D01
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000027D5E8: BF8700B1
	v_add_co_ci_u32_e64 v31, null, 0, v18, vcc_lo              // 00000027D5EC: D5207C1F 01AA2480
	v_lshlrev_b32_e32 v18, 3, v34                              // 00000027D5F4: 30244483
	.long 0xd7006a20                                           // 00000027D5F8: D7006A20
	v_cndmask_b32_e32 v1, v3, v25, vcc_lo                      // 00000027D5FC: 02023303
	v_add_co_ci_u32_e64 v33, null, 0, v24, vcc_lo              // 00000027D600: D5207C21 01AA3080
	v_mad_u64_u32 v[24:25], null, s19, v17, v[10:11]           // 00000027D608: D6FE7C18 042A2213
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000027D610: BF8701B4
	v_lshrrev_b32_e32 v10, 1, v18                              // 00000027D614: 32142481
	v_lshrrev_b32_e32 v19, 1, v34                              // 00000027D618: 32264481
	v_mad_u64_u32 v[1:2], null, s10, v17, s[8:9]               // 00000027D61C: D6FE7C01 0022220A
	.long 0xd7006a22                                           // 00000027D624: D7006A22
	v_cndmask_b32_e32 v1, v9, v10, vcc_lo                      // 00000027D628: 02021509
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000027D62C: BF870243
	v_and_b32_e32 v10, 0xffffffe, v19                          // 00000027D630: 361426FF 0FFFFFFE
	.long 0xd72c0004                                           // 00000027D638: D72C0004
	v_cndmask_b32_e32 v0, v13, v16, vcc_lo                     // 00000027D63C: 0200210D
	v_add_co_ci_u32_e64 v35, null, 0, v24, vcc_lo              // 00000027D640: D5207C23 01AA3080
	v_mad_u64_u32 v[24:25], null, s18, v13, s[6:7]             // 00000027D648: D6FE7C18 001A1A12
	.long 0xd7006a01                                           // 00000027D650: D7006A01
	v_cndmask_b32_e32 v1, v1, v10, vcc_lo                      // 00000027D654: 02021501
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000027D658: BF870124
	v_sub_nc_u32_e32 v22, v11, v4                              // 00000027D65C: 4C2C090B
	v_mad_u64_u32 v[3:4], null, s10, v13, s[8:9]               // 00000027D660: D6FE7C03 00221A0A
	v_lshlrev_b32_e32 v9, 3, v22                               // 00000027D668: 30122C83
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000027D66C: BF870222
	v_mad_u64_u32 v[36:37], null, s11, v17, v[2:3]             // 00000027D670: D6FE7C24 040A220B
	v_lshrrev_b32_e32 v2, 1, v22                               // 00000027D678: 32042C81
	v_mad_u64_u32 v[37:38], null, s11, v13, v[4:5]             // 00000027D67C: D6FE7C25 04121A0B
	v_mad_u64_u32 v[38:39], null, s19, v13, v[25:26]           // 00000027D684: D6FE7C26 04661A13
	v_lshrrev_b32_e32 v10, 1, v9                               // 00000027D68C: 32141281
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000027D690: BF870124
	v_and_b32_e32 v4, 0xffffffe, v2                            // 00000027D694: 360804FF 0FFFFFFE
	v_add_co_ci_u32_e64 v2, null, 0, v36, vcc_lo               // 00000027D69C: D5207C02 01AA4880
	.long 0xd7006a24                                           // 00000027D6A4: D7006A24
	v_cndmask_b32_e32 v1, v3, v4, vcc_lo                       // 00000027D6A8: 02020903
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000027D6AC: BF8700A1
	v_add_co_ci_u32_e64 v37, null, 0, v37, vcc_lo              // 00000027D6B0: D5207C25 01AA4A80
	.long 0xd7006a18                                           // 00000027D6B8: D7006A18
	v_cndmask_b32_e32 v1, v24, v10, vcc_lo                     // 00000027D6BC: 02021518
	v_add_co_ci_u32_e64 v25, null, 0, v38, vcc_lo              // 00000027D6C0: D5207C19 01AA4C80
	s_clause 0x7                                               // 00000027D6C8: BF850007
	global_load_d16_b16 v4, v[28:29], off                      // 00000027D6CC: DC820000 047C001C
	global_load_d16_hi_b16 v4, v[32:33], off                   // 00000027D6D4: DC8E0000 047C0020
	global_load_d16_b16 v10, v[1:2], off                       // 00000027D6DC: DC820000 0A7C0001
	global_load_d16_hi_b16 v10, v[36:37], off                  // 00000027D6E4: DC8E0000 0A7C0024
	global_load_b32 v1, v[26:27], off                          // 00000027D6EC: DC520000 017C001A
	global_load_b32 v2, v[30:31], off                          // 00000027D6F4: DC520000 027C001E
	global_load_b32 v3, v[34:35], off                          // 00000027D6FC: DC520000 037C0022
	global_load_b32 v22, v[24:25], off                         // 00000027D704: DC520000 167C0018
	s_waitcnt vmcnt(6)                                         // 00000027D70C: BF891BF7
	v_cvt_f32_f16_e32 v26, v4                                  // 00000027D710: 7E341704
	v_cvt_f32_f16_e32 v25, v132/*Invalid register, operand has 'VS_32_Lo128' register class*/// 00000027D714: 7E321784
	s_waitcnt vmcnt(4)                                         // 00000027D718: BF8913F7
	v_cvt_f32_f16_e32 v24, v10                                 // 00000027D71C: 7E30170A
	v_cvt_f32_f16_e32 v19, v138/*Invalid register, operand has 'VS_32_Lo128' register class*/// 00000027D720: 7E26178A
	s_cbranch_execz 12                                         // 00000027D724: BFA5000C <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi4ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0x458>
	s_and_not1_b32 vcc_lo, exec_lo, s20                        // 00000027D728: 916A147E
	s_cbranch_vccnz 255                                        // 00000027D72C: BFA400FF <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi4ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0x82c>
	s_waitcnt vmcnt(0)                                         // 00000027D730: BF8903F7
	s_barrier                                                  // 00000027D734: BFBD0000
	buffer_gl0_inv                                             // 00000027D738: E0AC0000 00000000
	s_and_not1_b32 vcc_lo, exec_lo, s21                        // 00000027D740: 916A157E
	s_cbranch_vccz 251                                         // 00000027D744: BFA300FB <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi4ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0x834>
	s_mov_b32 s0, 0                                            // 00000027D748: BE800080
	s_branch 744                                               // 00000027D74C: BFA002E8 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi4ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0xff0>
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 00000027D750: 916A007E
	s_cbranch_vccnz 65524                                      // 00000027D754: BFA4FFF4 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi4ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0x428>
	s_mov_b32 s0, exec_lo                                      // 00000027D758: BE80007E
	.long 0xd4cb007e                                           // 00000027D75C: D4CB007E
	v_cndmask_b32_e32 v1, s17, v21, vcc_lo                     // 00000027D760: 02022A11
	s_xor_b32 s0, exec_lo, s0                                  // 00000027D764: 8D00007E
	s_cbranch_execz 2                                          // 00000027D768: BFA50002 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi4ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0x474>
	s_waitcnt vmcnt(1)                                         // 00000027D76C: BF8907F7
	v_mov_b32_e32 v1, s12                                      // 00000027D770: 7E02020C
	s_or_saveexec_b32 s0, s0                                   // 00000027D774: BE802200
	v_mov_b32_e32 v26, 0                                       // 00000027D778: 7E340280
	s_xor_b32 exec_lo, exec_lo, s0                             // 00000027D77C: 8D7E007E
	s_cbranch_execz 33                                         // 00000027D780: BFA50021 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi4ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0x508>
	s_waitcnt vmcnt(2)                                         // 00000027D784: BF890BF7
	v_mad_u64_u32 v[1:2], null, s10, v15, s[8:9]               // 00000027D788: D6FE7C01 00221E0A
	s_waitcnt vmcnt(1)                                         // 00000027D790: BF8907F7
	v_mad_u64_u32 v[3:4], null, s18, v15, s[6:7]               // 00000027D794: D6FE7C03 001A1E12
	v_lshrrev_b32_e32 v13, 4, v16                              // 00000027D79C: 321A2084
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000027D7A0: BF870112
	v_mad_u64_u32 v[9:10], null, s11, v15, v[2:3]              // 00000027D7A4: D6FE7C09 040A1E0B
	v_and_b32_e32 v2, 0xffffffe, v13                           // 00000027D7AC: 36041AFF 0FFFFFFE
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000027D7B4: BF8701A4
	v_mad_u64_u32 v[17:18], null, s19, v15, v[4:5]             // 00000027D7B8: D6FE7C11 04121E13
	v_lshrrev_b32_e32 v4, 1, v16                               // 00000027D7C0: 32082081
	.long 0xd7006a01                                           // 00000027D7C4: D7006A01
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 00000027D7C8: 02020501
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000027D7CC: BF870191
	v_add_co_ci_u32_e64 v2, null, 0, v9, vcc_lo                // 00000027D7D0: D5207C02 01AA1280
	.long 0xd7006a03                                           // 00000027D7D8: D7006A03
	v_cndmask_b32_e32 v1, v3, v4, vcc_lo                       // 00000027D7DC: 02020903
	s_delay_alu instid0(VALU_DEP_1)                            // 00000027D7E0: BF870001
	v_add_co_ci_u32_e64 v4, null, 0, v17, vcc_lo               // 00000027D7E4: D5207C04 01AA2280
	s_clause 0x1                                               // 00000027D7EC: BF850001
	global_load_d16_b16 v2, v[1:2], off                        // 00000027D7F0: DC820000 027C0001
	global_load_b32 v1, v[3:4], off                            // 00000027D7F8: DC520000 017C0003
	s_waitcnt vmcnt(1)                                         // 00000027D800: BF8907F7
	v_cvt_f32_f16_e32 v26, v2                                  // 00000027D804: 7E341702
	s_or_b32 exec_lo, exec_lo, s0                              // 00000027D808: 8C7E007E
	.long 0xd72c0004                                           // 00000027D80C: D72C0004
	v_cndmask_b32_e32 v0, v7, v16, vcc_lo                      // 00000027D810: 02002107
	.long 0xd44b0001                                           // 00000027D814: D44B0001
	v_cndmask_b32_e32 v1, s17, v14, vcc_lo                     // 00000027D818: 02021C11
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000027D81C: BF870092
	v_sub_nc_u32_e32 v4, v14, v4                               // 00000027D820: 4C08090E
	v_subrev_nc_u32_e32 v9, s16, v4                            // 00000027D824: 4E120810
	v_cmp_le_u32_e32 vcc_lo, s16, v4                           // 00000027D828: 7C960810
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000027D82C: BF870092
	v_cndmask_b32_e32 v4, v4, v9, vcc_lo                       // 00000027D830: 02081304
	.long 0xd44b0000                                           // 00000027D834: D44B0000
	v_cndmask_b32_e32 v1, s16, v4, vcc_lo                      // 00000027D838: 02020810
	s_and_saveexec_b32 s22, s1                                 // 00000027D83C: BE962001
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000027D840: BF870009
	s_xor_b32 s1, exec_lo, s22                                 // 00000027D844: 8D01167E
	s_cbranch_execz 2                                          // 00000027D848: BFA50002 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi4ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0x554>
	s_waitcnt vmcnt(2)                                         // 00000027D84C: BF890BF7
	v_mov_b32_e32 v2, s12                                      // 00000027D850: 7E04020C
	s_or_saveexec_b32 s1, s1                                   // 00000027D854: BE812201
	v_dual_mov_b32 v25, 0 :: v_dual_add_nc_u32 v4, 1, v7       // 00000027D858: CA200080 19040E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000027D860: BF870091
	v_cndmask_b32_e32 v4, v7, v4, vcc_lo                       // 00000027D864: 02080907
	v_add_nc_u32_e32 v7, 1, v4                                 // 00000027D868: 4A0E0881
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000027D86C: BF870091
	v_cndmask_b32_e64 v20, v4, v7, s0                          // 00000027D870: D5010014 00020F04
	.long 0xd72c0004                                           // 00000027D878: D72C0004
	v_cndmask_b32_e32 v0, v20, v16, vcc_lo                     // 00000027D87C: 02002114
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000027D880: BF870091
	v_sub_nc_u32_e32 v4, v14, v4                               // 00000027D884: 4C08090E
	v_lshlrev_b32_e32 v23, 3, v4                               // 00000027D888: 302E0883
	s_xor_b32 exec_lo, exec_lo, s1                             // 00000027D88C: 8D7E017E
	s_cbranch_execz 30                                         // 00000027D890: BFA5001E <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi4ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0x60c>
	v_mad_u64_u32 v[9:10], null, s10, v20, s[8:9]              // 00000027D894: D6FE7C09 0022280A
	v_mad_u64_u32 v[17:18], null, s18, v20, s[6:7]             // 00000027D89C: D6FE7C11 001A2812
	s_waitcnt vmcnt(2)                                         // 00000027D8A4: BF890BF7
	v_lshrrev_b32_e32 v2, 4, v23                               // 00000027D8A8: 32042E84
	v_lshrrev_b32_e32 v4, 1, v23                               // 00000027D8AC: 32082E81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000027D8B0: BF8701B2
	v_and_b32_e32 v2, 0xffffffe, v2                            // 00000027D8B4: 360404FF 0FFFFFFE
	v_mad_u64_u32 v[24:25], null, s11, v20, v[10:11]           // 00000027D8BC: D6FE7C18 042A280B
	v_mad_u64_u32 v[18:19], null, s19, v20, v[18:19]           // 00000027D8C4: D6FE7C12 044A2813
	.long 0xd7006a09                                           // 00000027D8CC: D7006A09
	v_cndmask_b32_e32 v1, v9, v2, vcc_lo                       // 00000027D8D0: 02020509
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000027D8D4: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v24, vcc_lo              // 00000027D8D8: D5207C0A 01AA3080
	.long 0xd7006a11                                           // 00000027D8E0: D7006A11
	v_cndmask_b32_e32 v1, v17, v4, vcc_lo                      // 00000027D8E4: 02020911
	v_add_co_ci_u32_e64 v18, null, 0, v18, vcc_lo              // 00000027D8E8: D5207C12 01AA2480
	s_clause 0x1                                               // 00000027D8F0: BF850001
	global_load_d16_b16 v4, v[9:10], off                       // 00000027D8F4: DC820000 047C0009
	global_load_b32 v2, v[17:18], off                          // 00000027D8FC: DC520000 027C0011
	s_waitcnt vmcnt(1)                                         // 00000027D904: BF8907F7
	v_cvt_f32_f16_e32 v25, v4                                  // 00000027D908: 7E321704
	s_or_b32 exec_lo, exec_lo, s1                              // 00000027D90C: 8C7E017E
	.long 0xd72c0004                                           // 00000027D910: D72C0004
	v_cndmask_b32_e32 v0, v6, v16, vcc_lo                      // 00000027D914: 02002106
	.long 0xd44b0001                                           // 00000027D918: D44B0001
	v_cndmask_b32_e32 v1, s17, v12, vcc_lo                     // 00000027D91C: 02021811
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000027D920: BF870092
	v_sub_nc_u32_e32 v4, v12, v4                               // 00000027D924: 4C08090C
	v_subrev_nc_u32_e32 v7, s16, v4                            // 00000027D928: 4E0E0810
	v_cmp_le_u32_e32 vcc_lo, s16, v4                           // 00000027D92C: 7C960810
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000027D930: BF870092
	v_cndmask_b32_e32 v4, v4, v7, vcc_lo                       // 00000027D934: 02080F04
	.long 0xd44b0000                                           // 00000027D938: D44B0000
	v_cndmask_b32_e32 v1, s16, v4, vcc_lo                      // 00000027D93C: 02020810
	s_and_saveexec_b32 s22, s1                                 // 00000027D940: BE962001
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000027D944: BF870009
	s_xor_b32 s1, exec_lo, s22                                 // 00000027D948: 8D01167E
	s_cbranch_execz 2                                          // 00000027D94C: BFA50002 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi4ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0x658>
	s_waitcnt vmcnt(1)                                         // 00000027D950: BF8907F7
	v_mov_b32_e32 v3, s12                                      // 00000027D954: 7E06020C
	s_or_saveexec_b32 s1, s1                                   // 00000027D958: BE812201
	v_add_nc_u32_e32 v4, 1, v6                                 // 00000027D95C: 4A080C81
	v_mov_b32_e32 v24, 0                                       // 00000027D960: 7E300280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000027D964: BF870092
	v_cndmask_b32_e32 v4, v6, v4, vcc_lo                       // 00000027D968: 02080906
	v_add_nc_u32_e32 v6, 1, v4                                 // 00000027D96C: 4A0C0881
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000027D970: BF870091
	v_cndmask_b32_e64 v17, v4, v6, s0                          // 00000027D974: D5010011 00020D04
	.long 0xd72c0004                                           // 00000027D97C: D72C0004
	v_cndmask_b32_e32 v0, v17, v16, vcc_lo                     // 00000027D980: 02002111
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000027D984: BF870091
	v_sub_nc_u32_e32 v4, v12, v4                               // 00000027D988: 4C08090C
	v_lshlrev_b32_e32 v18, 3, v4                               // 00000027D98C: 30240883
	s_xor_b32 exec_lo, exec_lo, s1                             // 00000027D990: 8D7E017E
	s_cbranch_execz 32                                         // 00000027D994: BFA50020 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi4ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0x718>
	s_waitcnt vmcnt(1)                                         // 00000027D998: BF8907F7
	v_mad_u64_u32 v[3:4], null, s10, v17, s[8:9]               // 00000027D99C: D6FE7C03 0022220A
	v_mad_u64_u32 v[6:7], null, s18, v17, s[6:7]               // 00000027D9A4: D6FE7C06 001A2212
	v_lshrrev_b32_e32 v13, 4, v18                              // 00000027D9AC: 321A2484
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000027D9B0: BF870113
	v_mad_u64_u32 v[9:10], null, s11, v17, v[4:5]              // 00000027D9B4: D6FE7C09 0412220B
	v_and_b32_e32 v4, 0xffffffe, v13                           // 00000027D9BC: 36081AFF 0FFFFFFE
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000027D9C4: BF8701A4
	v_mad_u64_u32 v[27:28], null, s19, v17, v[7:8]             // 00000027D9C8: D6FE7C1B 041E2213
	v_lshrrev_b32_e32 v7, 1, v18                               // 00000027D9D0: 320E2481
	.long 0xd7006a03                                           // 00000027D9D4: D7006A03
	v_cndmask_b32_e32 v1, v3, v4, vcc_lo                       // 00000027D9D8: 02020903
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000027D9DC: BF870191
	v_add_co_ci_u32_e64 v4, null, 0, v9, vcc_lo                // 00000027D9E0: D5207C04 01AA1280
	.long 0xd7006a06                                           // 00000027D9E8: D7006A06
	v_cndmask_b32_e32 v1, v6, v7, vcc_lo                       // 00000027D9EC: 02020F06
	s_delay_alu instid0(VALU_DEP_1)                            // 00000027D9F0: BF870001
	v_add_co_ci_u32_e64 v7, null, 0, v27, vcc_lo               // 00000027D9F4: D5207C07 01AA3680
	s_clause 0x1                                               // 00000027D9FC: BF850001
	global_load_d16_b16 v4, v[3:4], off                        // 00000027DA00: DC820000 047C0003
	global_load_b32 v3, v[6:7], off                            // 00000027DA08: DC520000 037C0006
	s_waitcnt vmcnt(1)                                         // 00000027DA10: BF8907F7
	v_cvt_f32_f16_e32 v24, v4                                  // 00000027DA14: 7E301704
	s_or_b32 exec_lo, exec_lo, s1                              // 00000027DA18: 8C7E017E
	.long 0xd72c0004                                           // 00000027DA1C: D72C0004
	v_cndmask_b32_e32 v0, v5, v16, vcc_lo                      // 00000027DA20: 02002105
	.long 0xd44b0001                                           // 00000027DA24: D44B0001
	v_cndmask_b32_e32 v1, s17, v11, vcc_lo                     // 00000027DA28: 02021611
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000027DA2C: BF870092
	v_sub_nc_u32_e32 v4, v11, v4                               // 00000027DA30: 4C08090B
	v_subrev_nc_u32_e32 v6, s16, v4                            // 00000027DA34: 4E0C0810
	v_cmp_le_u32_e32 vcc_lo, s16, v4                           // 00000027DA38: 7C960810
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000027DA3C: BF870092
	v_cndmask_b32_e32 v4, v4, v6, vcc_lo                       // 00000027DA40: 02080D04
	.long 0xd44b0000                                           // 00000027DA44: D44B0000
	v_cndmask_b32_e32 v1, s16, v4, vcc_lo                      // 00000027DA48: 02020810
	s_and_saveexec_b32 s22, s1                                 // 00000027DA4C: BE962001
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000027DA50: BF870499
	s_xor_b32 s1, exec_lo, s22                                 // 00000027DA54: 8D01167E
	s_or_saveexec_b32 s1, s1                                   // 00000027DA58: BE812201
	v_dual_mov_b32 v19, 0 :: v_dual_add_nc_u32 v4, 1, v5       // 00000027DA5C: CA200080 13040A81
	s_waitcnt vmcnt(0)                                         // 00000027DA64: BF8903F7
	v_mov_b32_e32 v22, 0                                       // 00000027DA68: 7E2C0280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000027DA6C: BF870092
	v_cndmask_b32_e32 v4, v5, v4, vcc_lo                       // 00000027DA70: 02080905
	v_add_nc_u32_e32 v5, 1, v4                                 // 00000027DA74: 4A0A0881
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000027DA78: BF870091
	v_cndmask_b32_e64 v13, v4, v5, s0                          // 00000027DA7C: D501000D 00020B04
	.long 0xd72c0004                                           // 00000027DA84: D72C0004
	v_cndmask_b32_e32 v0, v13, v16, vcc_lo                     // 00000027DA88: 0200210D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000027DA8C: BF870091
	v_sub_nc_u32_e32 v4, v11, v4                               // 00000027DA90: 4C08090B
	v_lshlrev_b32_e32 v9, 3, v4                                // 00000027DA94: 30120883
	s_xor_b32 exec_lo, exec_lo, s1                             // 00000027DA98: 8D7E017E
	s_cbranch_execz 31                                         // 00000027DA9C: BFA5001F <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi4ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0x81c>
	v_mad_u64_u32 v[4:5], null, s10, v13, s[8:9]               // 00000027DAA0: D6FE7C04 00221A0A
	v_mad_u64_u32 v[6:7], null, s18, v13, s[6:7]               // 00000027DAA8: D6FE7C06 001A1A12
	v_lshrrev_b32_e32 v10, 4, v9                               // 00000027DAB0: 32141284
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000027DAB4: BF870112
	v_mad_u64_u32 v[27:28], null, s11, v13, v[5:6]             // 00000027DAB8: D6FE7C1B 04161A0B
	v_and_b32_e32 v5, 0xffffffe, v10                           // 00000027DAC0: 360A14FF 0FFFFFFE
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000027DAC8: BF8701A4
	v_mad_u64_u32 v[28:29], null, s19, v13, v[7:8]             // 00000027DACC: D6FE7C1C 041E1A13
	v_lshrrev_b32_e32 v7, 1, v9                                // 00000027DAD4: 320E1281
	.long 0xd7006a04                                           // 00000027DAD8: D7006A04
	v_cndmask_b32_e32 v1, v4, v5, vcc_lo                       // 00000027DADC: 02020B04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000027DAE0: BF870191
	v_add_co_ci_u32_e64 v5, null, 0, v27, vcc_lo               // 00000027DAE4: D5207C05 01AA3680
	.long 0xd7006a06                                           // 00000027DAEC: D7006A06
	v_cndmask_b32_e32 v1, v6, v7, vcc_lo                       // 00000027DAF0: 02020F06
	s_delay_alu instid0(VALU_DEP_1)                            // 00000027DAF4: BF870001
	v_add_co_ci_u32_e64 v7, null, 0, v28, vcc_lo               // 00000027DAF8: D5207C07 01AA3880
	s_clause 0x1                                               // 00000027DB00: BF850001
	global_load_d16_b16 v4, v[4:5], off                        // 00000027DB04: DC820000 047C0004
	global_load_b32 v22, v[6:7], off                           // 00000027DB0C: DC520000 167C0006
	s_waitcnt vmcnt(1)                                         // 00000027DB14: BF8907F7
	v_cvt_f32_f16_e32 v19, v4                                  // 00000027DB18: 7E261704
	s_or_b32 exec_lo, exec_lo, s1                              // 00000027DB1C: 8C7E017E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000027DB20: BF870009
	s_and_not1_b32 vcc_lo, exec_lo, s20                        // 00000027DB24: 916A147E
	s_cbranch_vccz 65281                                       // 00000027DB28: BFA3FF01 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi4ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0x430>
	s_and_not1_b32 vcc_lo, exec_lo, s21                        // 00000027DB2C: 916A157E
	s_cbranch_vccnz 65285                                      // 00000027DB30: BFA4FF05 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi4ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0x448>
	s_waitcnt vmcnt(3)                                         // 00000027DB34: BF890FF7
	v_lshrrev_b32_e32 v5, 2, v1                                // 00000027DB38: 320A0282
	v_lshrrev_b32_e32 v6, 6, v1                                // 00000027DB3C: 320C0286
	v_lshrrev_b32_e32 v7, 10, v1                               // 00000027DB40: 320E028A
	v_lshrrev_b32_e32 v10, 14, v1                              // 00000027DB44: 3214028E
	v_lshrrev_b32_e32 v27, 18, v1                              // 00000027DB48: 32360292
	v_and_b32_e32 v5, 60, v5                                   // 00000027DB4C: 360A0ABC
	v_and_b32_e32 v6, 60, v6                                   // 00000027DB50: 360C0CBC
	s_waitcnt vmcnt(2)                                         // 00000027DB54: BF890BF7
	v_and_b32_e32 v32, 15, v2                                  // 00000027DB58: 3640048F
	v_and_b32_e32 v10, 60, v10                                 // 00000027DB5C: 361414BC
	v_and_b32_e32 v27, 60, v27                                 // 00000027DB60: 363636BC
	ds_load_b32 v29, v5                                        // 00000027DB64: D8D80000 1D000005
	ds_load_b32 v6, v6                                         // 00000027DB6C: D8D80000 06000006
	v_and_b32_e32 v7, 60, v7                                   // 00000027DB74: 360E0EBC
	v_lshrrev_b32_e32 v5, 26, v1                               // 00000027DB78: 320A029A
	v_lshlrev_b32_e32 v32, 2, v32                              // 00000027DB7C: 30404082
	.long 0x7f523880                                           // 00000027DB80: 7F523880
	v_lshrrev_b32_e32 v33, 2, v2                               // 00000027DB84: 32420482
	v_lshrrev_b32_e32 v34, 6, v2                               // 00000027DB88: 32440486
	s_waitcnt vmcnt(1)                                         // 00000027DB8C: BF8907F7
	v_lshrrev_b32_e32 v45, 22, v3                              // 00000027DB90: 325A0696
	v_lshrrev_b32_e32 v43, 14, v3                              // 00000027DB94: 3256068E
	v_lshrrev_b32_e32 v44, 18, v3                              // 00000027DB98: 32580692
	v_lshrrev_b32_e32 v46, 26, v3                              // 00000027DB9C: 325C069A
	s_mov_b32 s0, -1                                           // 00000027DBA0: BE8000C1
	ds_load_b32 v32, v32                                       // 00000027DBA4: D8D80000 20000020
	v_and_b32_e32 v44, 60, v44                                 // 00000027DBAC: 365858BC
	v_and_b32_e32 v46, 60, v46                                 // 00000027DBB0: 365C5CBC
	v_and_b32_e32 v45, 60, v45                                 // 00000027DBB4: 365A5ABC
	v_and_b32_e32 v43, 60, v43                                 // 00000027DBB8: 365656BC
	s_waitcnt lgkmcnt(2)                                       // 00000027DBBC: BF89FC27
	v_mul_f32_e32 v29, v26, v29                                // 00000027DBC0: 103A3B1A
	s_waitcnt lgkmcnt(1)                                       // 00000027DBC4: BF89FC17
	v_mul_f32_e32 v6, v26, v6                                  // 00000027DBC8: 100C0D1A
	ds_load_b32 v7, v7                                         // 00000027DBCC: D8D80000 07000007
	ds_load_b32 v10, v10                                       // 00000027DBD4: D8D80000 0A00000A
	ds_load_b32 v27, v27                                       // 00000027DBDC: D8D80000 1B00001B
	v_and_b32_e32 v4, 15, v1                                   // 00000027DBE4: 3608028F
	s_waitcnt lgkmcnt(3)                                       // 00000027DBE8: BF89FC37
	v_dual_mul_f32 v32, v25, v32 :: v_dual_and_b32 v31, 60, v5 // 00000027DBEC: C8E44119 201E0ABC
	s_waitcnt lgkmcnt(2)                                       // 00000027DBF4: BF89FC27
	s_delay_alu instid0(VALU_DEP_2)                            // 00000027DBF8: BF870002
	v_dual_mul_f32 v7, v26, v7 :: v_dual_lshlrev_b32 v4, 2, v4 // 00000027DBFC: C8E20F1A 07040882
	s_waitcnt lgkmcnt(0)                                       // 00000027DC04: BF89FC07
	v_mul_f32_e32 v36, v26, v27                                // 00000027DC08: 1048371A
	ds_load_b32 v31, v31                                       // 00000027DC0C: D8D80000 1F00001F
	v_mul_f32_e32 v10, v26, v10                                // 00000027DC14: 1014151A
	v_bfe_u32 v27, v29, 16, 1                                  // 00000027DC18: D610001B 0205211D
	ds_load_b32 v28, v4                                        // 00000027DC20: D8D80000 1C000004
	v_lshrrev_b32_e32 v4, 22, v1                               // 00000027DC28: 32080296
	v_bfe_u32 v37, v7, 16, 1                                   // 00000027DC2C: D6100025 02052107
	v_add3_u32 v27, v29, v27, 0x7fff                           // 00000027DC34: D655001B 03FE371D 00007FFF
	v_bfe_u32 v29, v36, 16, 1                                  // 00000027DC40: D610001D 02052124
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000027DC48: BF870214
	v_and_b32_e32 v4, 60, v4                                   // 00000027DC4C: 360808BC
	v_add3_u32 v7, v7, v37, 0x7fff                             // 00000027DC50: D6550007 03FE4B07 00007FFF
	v_lshrrev_b32_e32 v37, 26, v2                              // 00000027DC5C: 324A049A
	s_delay_alu instid0(VALU_DEP_4)                            // 00000027DC60: BF870004
	v_add3_u32 v29, v36, v29, 0x7fff                           // 00000027DC64: D655001D 03FE3B24 00007FFF
	ds_load_b32 v30, v4                                        // 00000027DC70: D8D80000 1E000004
	v_mad_u64_u32 v[4:5], null, s4, v15, 0                     // 00000027DC78: D6FE7C04 02021E04
	v_lshrrev_b32_e32 v36, 22, v2                              // 00000027DC80: 32480496
	v_and_b32_e32 v37, 60, v37                                 // 00000027DC84: 364A4ABC
	s_waitcnt lgkmcnt(2)                                       // 00000027DC88: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000027DC8C: BF8700B2
	v_dual_mul_f32 v31, v26, v31 :: v_dual_and_b32 v36, 60, v36// 00000027DC90: C8E43F1A 1F2448BC
	s_waitcnt lgkmcnt(1)                                       // 00000027DC98: BF89FC17
	v_mul_f32_e32 v28, v26, v28                                // 00000027DC9C: 1038391A
	v_bfe_u32 v35, v28, 16, 1                                  // 00000027DCA0: D6100023 0205211C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000027DCA8: BF870121
	v_add3_u32 v28, v28, v35, 0x7fff                           // 00000027DCAC: D655001C 03FE471C 00007FFF
	v_bfe_u32 v35, v6, 16, 1                                   // 00000027DCB8: D6100023 02052106
	.long 0x7e52399c                                           // 00000027DCC0: 7E52399C
	s_delay_alu instid0(VALU_DEP_2)                            // 00000027DCC4: BF870002
	v_add3_u32 v6, v6, v35, 0x7fff                             // 00000027DCC8: D6550006 03FE4706 00007FFF
	v_bfe_u32 v28, v10, 16, 1                                  // 00000027DCD4: D610001C 0205210A
	v_lshrrev_b32_e32 v35, 18, v2                              // 00000027DCDC: 32460492
	s_waitcnt lgkmcnt(0)                                       // 00000027DCE0: BF89FC07
	v_mul_f32_e32 v30, v26, v30                                // 00000027DCE4: 103C3D1A
	v_and_or_b32 v27, 0xffff0000, v27, v41                     // 00000027DCE8: D657001B 04A636FF FFFF0000
	.long 0x7e523986                                           // 00000027DCF4: 7E523986
	v_add3_u32 v6, v10, v28, 0x7fff                            // 00000027DCF8: D6550006 03FE390A 00007FFF
	v_and_b32_e32 v35, 60, v35                                 // 00000027DD04: 364646BC
	v_bfe_u32 v10, v30, 16, 1                                  // 00000027DD08: D610000A 0205211E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000027DD10: BF870214
	v_and_or_b32 v28, 0xffff0000, v7, v41                      // 00000027DD14: D657001C 04A60EFF FFFF0000
	.long 0x7e523986                                           // 00000027DD20: 7E523986
	v_mad_u64_u32 v[5:6], null, s5, v15, v[5:6]                // 00000027DD24: D6FE7C05 04161E05
	s_delay_alu instid0(VALU_DEP_4)                            // 00000027DD2C: BF870004
	v_add3_u32 v7, v30, v10, 0x7fff                            // 00000027DD30: D6550007 03FE151E 00007FFF
	v_and_b32_e32 v10, 60, v33                                 // 00000027DD3C: 361442BC
	v_and_b32_e32 v30, 60, v34                                 // 00000027DD40: 363C44BC
	ds_load_b32 v6, v10                                        // 00000027DD44: D8D80000 0600000A
	ds_load_b32 v10, v30                                       // 00000027DD4C: D8D80000 0A00001E
	v_lshrrev_b32_e32 v30, 10, v2                              // 00000027DD54: 323C048A
	v_lshrrev_b32_e32 v34, 14, v2                              // 00000027DD58: 3244048E
	v_bfe_u32 v33, v31, 16, 1                                  // 00000027DD5C: D6100021 0205211F
	.long 0xd73c0004                                           // 00000027DD64: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 00000027DD68: 02020881
	v_and_or_b32 v29, 0xffff0000, v29, v41                     // 00000027DD6C: D657001D 04A63AFF FFFF0000
	v_and_b32_e32 v30, 60, v30                                 // 00000027DD78: 363C3CBC
	v_and_b32_e32 v34, 60, v34                                 // 00000027DD7C: 364444BC
	ds_load_b32 v38, v30                                       // 00000027DD80: D8D80000 2600001E
	ds_load_b32 v34, v34                                       // 00000027DD88: D8D80000 22000022
	ds_load_b32 v35, v35                                       // 00000027DD90: D8D80000 23000023
	ds_load_b32 v36, v36                                       // 00000027DD98: D8D80000 24000024
	ds_load_b32 v37, v37                                       // 00000027DDA0: D8D80000 25000025
	.long 0x7e523987                                           // 00000027DDA8: 7E523987
	v_add3_u32 v7, v31, v33, 0x7fff                            // 00000027DDAC: D6550007 03FE431F 00007FFF
	v_bfe_u32 v31, v32, 16, 1                                  // 00000027DDB8: D610001F 02052120
	.long 0xd7006a27                                           // 00000027DDC0: D7006A27
	v_cndmask_b32_e32 v1, s14, v4, vcc_lo                      // 00000027DDC4: 0202080E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000027DDC8: BF870001
	v_add_co_ci_u32_e64 v40, null, s15, v5, vcc_lo             // 00000027DDCC: D5207C28 01AA0A0F
	s_waitcnt lgkmcnt(6)                                       // 00000027DDD4: BF89FC67
	v_mul_f32_e32 v6, v25, v6                                  // 00000027DDD8: 100C0D19
	s_waitcnt lgkmcnt(5)                                       // 00000027DDDC: BF89FC57
	v_mul_f32_e32 v10, v25, v10                                // 00000027DDE0: 10141519
	v_and_or_b32 v30, 0xffff0000, v7, v41                      // 00000027DDE4: D657001E 04A60EFF FFFF0000
	v_add3_u32 v7, v32, v31, 0x7fff                            // 00000027DDF0: D6550007 03FE3F20 00007FFF
	v_bfe_u32 v4, v6, 16, 1                                    // 00000027DDFC: D6100004 02052106
	s_delay_alu instid0(VALU_DEP_4)                            // 00000027DE04: BF870004
	v_bfe_u32 v5, v10, 16, 1                                   // 00000027DE08: D6100005 0205210A
	s_waitcnt lgkmcnt(4)                                       // 00000027DE10: BF89FC47
	v_mul_f32_e32 v32, v25, v38                                // 00000027DE14: 10404D19
	s_waitcnt lgkmcnt(3)                                       // 00000027DE18: BF89FC37
	v_mul_f32_e32 v33, v25, v34                                // 00000027DE1C: 10424519
	.long 0x7e523987                                           // 00000027DE20: 7E523987
	v_add3_u32 v4, v6, v4, 0x7fff                              // 00000027DE24: D6550004 03FE0906 00007FFF
	v_add3_u32 v5, v10, v5, 0x7fff                             // 00000027DE30: D6550005 03FE0B0A 00007FFF
	v_bfe_u32 v6, v32, 16, 1                                   // 00000027DE3C: D6100006 02052120
	v_bfe_u32 v10, v33, 16, 1                                  // 00000027DE44: D610000A 02052121
	v_mov_b32_e32 v7, v16                                      // 00000027DE4C: 7E0E0310
	v_and_or_b32 v31, 0xffff0000, v4, v41                      // 00000027DE50: D657001F 04A608FF FFFF0000
	.long 0x7e523985                                           // 00000027DE5C: 7E523985
	v_add3_u32 v4, v32, v6, 0x7fff                             // 00000027DE60: D6550004 03FE0D20 00007FFF
	s_waitcnt lgkmcnt(2)                                       // 00000027DE6C: BF89FC27
	v_mul_f32_e32 v6, v25, v35                                 // 00000027DE70: 100C4719
	v_add3_u32 v5, v33, v10, 0x7fff                            // 00000027DE74: D6550005 03FE1521 00007FFF
	s_waitcnt lgkmcnt(1)                                       // 00000027DE80: BF89FC17
	v_mul_f32_e32 v10, v25, v36                                // 00000027DE84: 10144919
	.long 0xd73c0021                                           // 00000027DE88: D73C0021
	v_cndmask_b32_e32 v1, 1, v7, vcc_lo                        // 00000027DE8C: 02020E81
	v_and_b32_e32 v36, 15, v3                                  // 00000027DE90: 3648068F
	v_bfe_u32 v7, v6, 16, 1                                    // 00000027DE94: D6100007 02052106
	v_and_or_b32 v32, 0xffff0000, v4, v41                      // 00000027DE9C: D6570020 04A608FF FFFF0000
	.long 0x7e523985                                           // 00000027DEA8: 7E523985
	v_mad_u64_u32 v[4:5], null, s4, v20, 0                     // 00000027DEAC: D6FE7C04 02022804
	v_bfe_u32 v35, v10, 16, 1                                  // 00000027DEB4: D6100023 0205210A
	v_add3_u32 v38, v6, v7, 0x7fff                             // 00000027DEBC: D6550026 03FE0F06 00007FFF
	v_lshlrev_b32_e32 v7, 2, v36                               // 00000027DEC8: 300E4882
	v_lshrrev_b32_e32 v36, 6, v3                               // 00000027DECC: 32480686
	s_waitcnt lgkmcnt(0)                                       // 00000027DED0: BF89FC07
	v_mul_f32_e32 v37, v25, v37                                // 00000027DED4: 104A4B19
	v_add3_u32 v10, v10, v35, 0x7fff                           // 00000027DED8: D655000A 03FE470A 00007FFF
	v_lshrrev_b32_e32 v35, 2, v3                               // 00000027DEE4: 32460682
	v_mad_u64_u32 v[5:6], null, s5, v20, v[5:6]                // 00000027DEE8: D6FE7C05 04162805
	ds_load_b32 v6, v7                                         // 00000027DEF0: D8D80000 06000007
	v_bfe_u32 v42, v37, 16, 1                                  // 00000027DEF8: D610002A 02052125
	v_and_b32_e32 v7, 60, v35                                  // 00000027DF00: 360E46BC
	v_and_b32_e32 v35, 60, v36                                 // 00000027DF04: 364648BC
	v_lshrrev_b32_e32 v36, 10, v3                              // 00000027DF08: 3248068A
	.long 0xd73c0004                                           // 00000027DF0C: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 00000027DF10: 02020881
	s_delay_alu instid0(VALU_DEP_2)                            // 00000027DF14: BF870002
	v_and_b32_e32 v36, 60, v36                                 // 00000027DF18: 364848BC
	ds_load_b32 v47, v7                                        // 00000027DF1C: D8D80000 2F000007
	ds_load_b32 v35, v35                                       // 00000027DF24: D8D80000 23000023
	ds_load_b32 v36, v36                                       // 00000027DF2C: D8D80000 24000024
	ds_load_b32 v43, v43                                       // 00000027DF34: D8D80000 2B00002B
	ds_load_b32 v44, v44                                       // 00000027DF3C: D8D80000 2C00002C
	ds_load_b32 v45, v45                                       // 00000027DF44: D8D80000 2D00002D
	ds_load_b32 v46, v46                                       // 00000027DF4C: D8D80000 2E00002E
	s_waitcnt lgkmcnt(7)                                       // 00000027DF54: BF89FC77
	v_mul_f32_e32 v48, v24, v6                                 // 00000027DF58: 10600D18
	.long 0xd7006a06                                           // 00000027DF5C: D7006A06
	v_cndmask_b32_e32 v1, v39, v33, vcc_lo                     // 00000027DF60: 02024327
	s_delay_alu instid0(VALU_DEP_1)                            // 00000027DF64: BF870001
	v_add_co_ci_u32_e64 v7, null, v40, v34, vcc_lo             // 00000027DF68: D5207C07 01AA4528
	v_and_or_b32 v33, 0xffff0000, v38, v41                     // 00000027DF70: D6570021 04A64CFF FFFF0000
	.long 0x7e52398a                                           // 00000027DF7C: 7E52398A
	v_add3_u32 v10, v37, v42, 0x7fff                           // 00000027DF80: D655000A 03FE5525 00007FFF
	global_store_b128 v[6:7], v[27:30], off                    // 00000027DF8C: DC760000 007C1B06
	s_waitcnt lgkmcnt(6)                                       // 00000027DF94: BF89FC67
	v_mul_f32_e32 v7, v24, v47                                 // 00000027DF98: 100E5F18
	v_bfe_u32 v37, v48, 16, 1                                  // 00000027DF9C: D6100025 02052130
	.long 0xd7006a1e                                           // 00000027DFA4: D7006A1E
	v_cndmask_b32_e32 v1, s14, v4, vcc_lo                      // 00000027DFA8: 0202080E
	v_and_or_b32 v34, 0xffff0000, v10, v41                     // 00000027DFAC: D6570022 04A614FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000027DFB8: BF870214
	v_bfe_u32 v4, v7, 16, 1                                    // 00000027DFBC: D6100004 02052107
	v_add3_u32 v6, v48, v37, 0x7fff                            // 00000027DFC4: D6550006 03FE4B30 00007FFF
	s_waitcnt lgkmcnt(5)                                       // 00000027DFD0: BF89FC57
	v_mul_f32_e32 v10, v24, v35                                // 00000027DFD4: 10144718
	v_add_co_ci_u32_e64 v37, null, s15, v5, vcc_lo             // 00000027DFD8: D5207C25 01AA0A0F
	v_add3_u32 v4, v7, v4, 0x7fff                              // 00000027DFE0: D6550004 03FE0907 00007FFF
	v_mov_b32_e32 v7, v23                                      // 00000027DFEC: 7E0E0317
	.long 0x7e523986                                           // 00000027DFF0: 7E523986
	s_waitcnt lgkmcnt(3)                                       // 00000027DFF4: BF89FC37
	v_mul_f32_e32 v6, v24, v43                                 // 00000027DFF8: 100C5718
	s_waitcnt vmcnt(0)                                         // 00000027DFFC: BF8903F7
	v_lshrrev_b32_e32 v43, 14, v22                             // 00000027E000: 32562C8E
	v_mul_f32_e32 v28, v24, v36                                // 00000027E004: 10384918
	.long 0xd73c0023                                           // 00000027E008: D73C0023
	v_cndmask_b32_e32 v1, 1, v7, vcc_lo                        // 00000027E00C: 02020E81
	s_waitcnt lgkmcnt(1)                                       // 00000027E010: BF89FC17
	v_mul_f32_e32 v7, v24, v45                                 // 00000027E014: 100E5B18
	v_lshrrev_b32_e32 v45, 22, v22                             // 00000027E018: 325A2C96
	v_bfe_u32 v29, v6, 16, 1                                   // 00000027E01C: D610001D 02052106
	v_and_b32_e32 v43, 60, v43                                 // 00000027E024: 365656BC
	v_and_or_b32 v27, 0xffff0000, v4, v41                      // 00000027E028: D657001B 04A608FF FFFF0000
	v_lshrrev_b32_e32 v42, 10, v22                             // 00000027E034: 32542C8A
	v_and_b32_e32 v45, 60, v45                                 // 00000027E038: 365A5ABC
	v_bfe_u32 v5, v10, 16, 1                                   // 00000027E03C: D6100005 0205210A
	v_add3_u32 v6, v6, v29, 0x7fff                             // 00000027E044: D6550006 03FE3B06 00007FFF
	v_lshrrev_b32_e32 v29, 2, v22                              // 00000027E050: 323A2C82
	s_waitcnt lgkmcnt(0)                                       // 00000027E054: BF89FC07
	v_mul_f32_e32 v39, v24, v46                                // 00000027E058: 104E5D18
	v_lshrrev_b32_e32 v46, 26, v22                             // 00000027E05C: 325C2C9A
	v_add3_u32 v5, v10, v5, 0x7fff                             // 00000027E060: D6550005 03FE0B0A 00007FFF
	v_bfe_u32 v10, v28, 16, 1                                  // 00000027E06C: D610000A 0205211C
	v_and_b32_e32 v42, 60, v42                                 // 00000027E074: 365454BC
	v_bfe_u32 v40, v39, 16, 1                                  // 00000027E078: D6100028 02052127
	v_and_b32_e32 v46, 60, v46                                 // 00000027E080: 365C5CBC
	.long 0x7e523985                                           // 00000027E084: 7E523985
	v_add3_u32 v4, v28, v10, 0x7fff                            // 00000027E088: D6550004 03FE151C 00007FFF
	v_mul_f32_e32 v5, v24, v44                                 // 00000027E094: 100A5918
	v_bfe_u32 v10, v7, 16, 1                                   // 00000027E098: D610000A 02052107
	v_lshrrev_b32_e32 v44, 18, v22                             // 00000027E0A0: 32582C92
	.long 0xd7006a23                                           // 00000027E0A4: D7006A23
	v_cndmask_b32_e32 v1, v30, v35, vcc_lo                     // 00000027E0A8: 0202471E
	v_and_or_b32 v28, 0xffff0000, v4, v41                      // 00000027E0AC: D657001C 04A608FF FFFF0000
	v_bfe_u32 v4, v5, 16, 1                                    // 00000027E0B8: D6100004 02052105
	.long 0x7e523986                                           // 00000027E0C0: 7E523986
	v_and_b32_e32 v6, 15, v22                                  // 00000027E0C4: 360C2C8F
	v_and_b32_e32 v44, 60, v44                                 // 00000027E0C8: 365858BC
	v_add_co_ci_u32_e64 v36, null, v37, v36, vcc_lo            // 00000027E0CC: D5207C24 01AA4925
	v_add3_u32 v38, v5, v4, 0x7fff                             // 00000027E0D4: D6550026 03FE0905 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 00000027E0E0: BF870004
	v_lshlrev_b32_e32 v4, 2, v6                                // 00000027E0E4: 30080C82
	v_add3_u32 v6, v7, v10, 0x7fff                             // 00000027E0E8: D6550006 03FE1507 00007FFF
	v_and_b32_e32 v7, 60, v29                                  // 00000027E0F4: 360E3ABC
	v_lshrrev_b32_e32 v10, 6, v22                              // 00000027E0F8: 32142C86
	global_store_b128 v[35:36], v[31:34], off                  // 00000027E0FC: DC760000 007C1F23
	ds_load_b32 v29, v4                                        // 00000027E104: D8D80000 1D000004
	ds_load_b32 v7, v7                                         // 00000027E10C: D8D80000 07000007
	v_and_b32_e32 v10, 60, v10                                 // 00000027E114: 361414BC
	ds_load_b32 v10, v10                                       // 00000027E118: D8D80000 0A00000A
	ds_load_b32 v42, v42                                       // 00000027E120: D8D80000 2A00002A
	ds_load_b32 v43, v43                                       // 00000027E128: D8D80000 2B00002B
	ds_load_b32 v44, v44                                       // 00000027E130: D8D80000 2C00002C
	ds_load_b32 v45, v45                                       // 00000027E138: D8D80000 2D00002D
	ds_load_b32 v46, v46                                       // 00000027E140: D8D80000 2E00002E
	v_mad_u64_u32 v[4:5], null, s4, v17, 0                     // 00000027E148: D6FE7C04 02022204
	s_waitcnt lgkmcnt(7)                                       // 00000027E150: BF89FC77
	v_mul_f32_e32 v47, v19, v29                                // 00000027E154: 105E3B13
	v_and_or_b32 v29, 0xffff0000, v38, v41                     // 00000027E158: D657001D 04A64CFF FFFF0000
	.long 0x7e523986                                           // 00000027E164: 7E523986
	s_delay_alu instid0(VALU_DEP_4)                            // 00000027E168: BF870004
	v_mad_u64_u32 v[5:6], null, s5, v17, v[5:6]                // 00000027E16C: D6FE7C05 04162205
	v_add3_u32 v38, v39, v40, 0x7fff                           // 00000027E174: D6550026 03FE5127 00007FFF
	v_bfe_u32 v6, v47, 16, 1                                   // 00000027E180: D6100006 0205212F
	s_waitcnt lgkmcnt(6)                                       // 00000027E188: BF89FC67
	v_mul_f32_e32 v39, v19, v7                                 // 00000027E18C: 104E0F13
	s_waitcnt lgkmcnt(5)                                       // 00000027E190: BF89FC57
	v_dual_mul_f32 v10, v19, v10 :: v_dual_mov_b32 v7, v18     // 00000027E194: C8D01513 0A060112
	v_and_or_b32 v30, 0xffff0000, v38, v41                     // 00000027E19C: D657001E 04A64CFF FFFF0000
	v_add3_u32 v6, v47, v6, 0x7fff                             // 00000027E1A8: D6550006 03FE0D2F 00007FFF
	v_bfe_u32 v40, v39, 16, 1                                  // 00000027E1B4: D6100028 02052127
	.long 0xd73c0025                                           // 00000027E1BC: D73C0025
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 00000027E1C0: 02020881
	v_bfe_u32 v5, v10, 16, 1                                   // 00000027E1C4: D6100005 0205210A
	s_delay_alu instid0(VALU_DEP_4)                            // 00000027E1CC: BF870004
	.long 0x7e523986                                           // 00000027E1D0: 7E523986
	s_waitcnt lgkmcnt(4)                                       // 00000027E1D4: BF89FC47
	v_mul_f32_e32 v6, v19, v42                                 // 00000027E1D8: 100C5513
	s_waitcnt lgkmcnt(3)                                       // 00000027E1DC: BF89FC37
	v_mul_f32_e32 v42, v19, v43                                // 00000027E1E0: 10545713
	v_add3_u32 v4, v39, v40, 0x7fff                            // 00000027E1E4: D6550004 03FE5127 00007FFF
	.long 0xd73c0027                                           // 00000027E1F0: D73C0027
	v_cndmask_b32_e32 v1, 1, v7, vcc_lo                        // 00000027E1F4: 02020E81
	v_add3_u32 v5, v10, v5, 0x7fff                             // 00000027E1F8: D6550005 03FE0B0A 00007FFF
	v_bfe_u32 v7, v6, 16, 1                                    // 00000027E204: D6100007 02052106
	v_bfe_u32 v10, v42, 16, 1                                  // 00000027E20C: D610000A 0205212A
	s_waitcnt lgkmcnt(2)                                       // 00000027E214: BF89FC27
	v_mul_f32_e32 v43, v19, v44                                // 00000027E218: 10565913
	s_waitcnt lgkmcnt(1)                                       // 00000027E21C: BF89FC17
	v_mul_f32_e32 v44, v19, v45                                // 00000027E220: 10585B13
	v_and_or_b32 v4, 0xffff0000, v4, v41                       // 00000027E224: D6570004 04A608FF FFFF0000
	.long 0x7e523985                                           // 00000027E230: 7E523985
	v_add3_u32 v5, v6, v7, 0x7fff                              // 00000027E234: D6550005 03FE0F06 00007FFF
	v_add3_u32 v6, v42, v10, 0x7fff                            // 00000027E240: D6550006 03FE152A 00007FFF
	v_bfe_u32 v7, v43, 16, 1                                   // 00000027E24C: D6100007 0205212B
	v_bfe_u32 v10, v44, 16, 1                                  // 00000027E254: D610000A 0205212C
	s_waitcnt lgkmcnt(0)                                       // 00000027E25C: BF89FC07
	v_mul_f32_e32 v42, v19, v46                                // 00000027E260: 10545D13
	v_and_or_b32 v5, 0xffff0000, v5, v41                       // 00000027E264: D6570005 04A60AFF FFFF0000
	.long 0x7e523986                                           // 00000027E270: 7E523986
	v_add3_u32 v6, v43, v7, 0x7fff                             // 00000027E274: D6550006 03FE0F2B 00007FFF
	v_add3_u32 v7, v44, v10, 0x7fff                            // 00000027E280: D6550007 03FE152C 00007FFF
	v_bfe_u32 v10, v42, 16, 1                                  // 00000027E28C: D610000A 0205212A
	.long 0xd7006a25                                           // 00000027E294: D7006A25
	v_cndmask_b32_e32 v1, s14, v37, vcc_lo                     // 00000027E298: 02024A0E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000027E29C: BF8700D1
	v_add_co_ci_u32_e64 v38, null, s15, v38, vcc_lo            // 00000027E2A0: D5207C26 01AA4C0F
	v_and_or_b32 v6, 0xffff0000, v6, v41                       // 00000027E2A8: D6570006 04A60CFF FFFF0000
	.long 0x7e523987                                           // 00000027E2B4: 7E523987
	v_add3_u32 v7, v42, v10, 0x7fff                            // 00000027E2B8: D6550007 03FE152A 00007FFF
	.long 0xd7006a25                                           // 00000027E2C4: D7006A25
	v_cndmask_b32_e32 v1, v37, v39, vcc_lo                     // 00000027E2C8: 02024F25
	v_add_co_ci_u32_e64 v38, null, v38, v40, vcc_lo            // 00000027E2CC: D5207C26 01AA5126
	s_delay_alu instid0(VALU_DEP_3)                            // 00000027E2D4: BF870003
	v_and_or_b32 v7, 0xffff0000, v7, v41                       // 00000027E2D8: D6570007 04A60EFF FFFF0000
	global_store_b128 v[37:38], v[27:30], off                  // 00000027E2E4: DC760000 007C1B25
	s_cbranch_execnz 397                                       // 00000027E2EC: BFA6018D <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi4ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0x1624>
	s_mov_b32 s1, exec_lo                                      // 00000027E2F0: BE81007E
	.long 0xd4cc007e                                           // 00000027E2F4: D4CC007E
	v_cndmask_b32_e32 v1, s17, v21, vcc_lo                     // 00000027E2F8: 02022A11
	s_cbranch_execz 421                                        // 00000027E2FC: BFA501A5 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi4ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0x1694>
	s_waitcnt vmcnt(3)                                         // 00000027E300: BF890FF7
	v_lshrrev_b32_e32 v4, 22, v1                               // 00000027E304: 32080296
	v_lshrrev_b32_e32 v5, 26, v1                               // 00000027E308: 320A029A
	v_lshrrev_b32_e32 v7, 14, v1                               // 00000027E30C: 320E028E
	v_lshrrev_b32_e32 v10, 10, v1                              // 00000027E310: 3214028A
	v_lshrrev_b32_e32 v6, 18, v1                               // 00000027E314: 320C0292
	v_and_b32_e32 v4, 60, v4                                   // 00000027E318: 360808BC
	v_lshrrev_b32_e32 v21, 6, v1                               // 00000027E31C: 322A0286
	v_lshrrev_b32_e32 v27, 2, v1                               // 00000027E320: 32360282
	v_and_b32_e32 v1, 15, v1                                   // 00000027E324: 3602028F
	v_and_b32_e32 v6, 60, v6                                   // 00000027E328: 360C0CBC
	ds_load_b32 v28, v4                                        // 00000027E32C: D8D80000 1C000004
	v_and_b32_e32 v5, 60, v5                                   // 00000027E334: 360A0ABC
	v_and_b32_e32 v4, 60, v7                                   // 00000027E338: 36080EBC
	v_and_b32_e32 v7, 60, v10                                  // 00000027E33C: 360E14BC
	v_and_b32_e32 v10, 60, v21                                 // 00000027E340: 36142ABC
	v_and_b32_e32 v21, 60, v27                                 // 00000027E344: 362A36BC
	v_lshlrev_b32_e32 v1, 2, v1                                // 00000027E348: 30020282
	ds_load_b32 v31, v7                                        // 00000027E34C: D8D80000 1F000007
	ds_load_b32 v10, v10                                       // 00000027E354: D8D80000 0A00000A
	ds_load_b32 v21, v21                                       // 00000027E35C: D8D80000 15000015
	ds_load_b32 v1, v1                                         // 00000027E364: D8D80000 01000001
	v_mov_b32_e32 v7, v16                                      // 00000027E36C: 7E0E0310
	.long 0x7f403880                                           // 00000027E370: 7F403880
	s_waitcnt lgkmcnt(4)                                       // 00000027E374: BF89FC47
	v_mul_f32_e32 v16, v26, v28                                // 00000027E378: 1020391A
	ds_load_b32 v27, v5                                        // 00000027E37C: D8D80000 1B000005
	ds_load_b32 v29, v6                                        // 00000027E384: D8D80000 1D000006
	ds_load_b32 v30, v4                                        // 00000027E38C: D8D80000 1E000004
	v_mad_u64_u32 v[4:5], null, s4, v15, 0                     // 00000027E394: D6FE7C04 02021E04
	v_bfe_u32 v28, v16, 16, 1                                  // 00000027E39C: D610001C 02052110
	s_waitcnt lgkmcnt(5)                                       // 00000027E3A4: BF89FC57
	v_mul_f32_e32 v10, v26, v10                                // 00000027E3A8: 1014151A
	s_waitcnt lgkmcnt(4)                                       // 00000027E3AC: BF89FC47
	v_mul_f32_e32 v21, v26, v21                                // 00000027E3B0: 102A2B1A
	s_waitcnt lgkmcnt(3)                                       // 00000027E3B4: BF89FC37
	v_mul_f32_e32 v1, v26, v1                                  // 00000027E3B8: 1002031A
	v_mad_u64_u32 v[5:6], null, s5, v15, v[5:6]                // 00000027E3BC: D6FE7C05 04161E05
	v_add3_u32 v16, v16, v28, 0x7fff                           // 00000027E3C4: D6550010 03FE3910 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000027E3D0: BF870191
	.long 0x7e403990                                           // 00000027E3D4: 7E403990
	.long 0xd73c0004                                           // 00000027E3D8: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 00000027E3DC: 02020881
	s_waitcnt lgkmcnt(2)                                       // 00000027E3E0: BF89FC27
	v_mul_f32_e32 v6, v26, v27                                 // 00000027E3E4: 100C371A
	s_waitcnt lgkmcnt(1)                                       // 00000027E3E8: BF89FC17
	v_mul_f32_e32 v15, v26, v29                                // 00000027E3EC: 101E3B1A
	s_waitcnt lgkmcnt(0)                                       // 00000027E3F0: BF89FC07
	v_mul_f32_e32 v27, v26, v30                                // 00000027E3F4: 10363D1A
	v_mul_f32_e32 v30, v26, v31                                // 00000027E3F8: 103C3F1A
	v_bfe_u32 v29, v6, 16, 1                                   // 00000027E3FC: D610001D 02052106
	v_bfe_u32 v26, v15, 16, 1                                  // 00000027E404: D610001A 0205210F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000027E40C: BF870194
	v_bfe_u32 v28, v27, 16, 1                                  // 00000027E410: D610001C 0205211B
	v_add3_u32 v6, v6, v29, 0x7fff                             // 00000027E418: D6550006 03FE3B06 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000027E424: BF870193
	v_add3_u32 v15, v15, v26, 0x7fff                           // 00000027E428: D655000F 03FE350F 00007FFF
	v_add3_u32 v16, v27, v28, 0x7fff                           // 00000027E434: D6550010 03FE391B 00007FFF
	v_bfe_u32 v27, v10, 16, 1                                  // 00000027E440: D610001B 0205210A
	v_bfe_u32 v28, v30, 16, 1                                  // 00000027E448: D610001C 0205211E
	v_and_or_b32 v29, 0xffff0000, v6, v32                      // 00000027E450: D657001D 04820CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000027E45C: BF870214
	.long 0x7e403990                                           // 00000027E460: 7E403990
	v_add3_u32 v6, v10, v27, 0x7fff                            // 00000027E464: D6550006 03FE370A 00007FFF
	v_bfe_u32 v10, v1, 16, 1                                   // 00000027E470: D610000A 02052101
	v_add3_u32 v26, v30, v28, 0x7fff                           // 00000027E478: D655001A 03FE391E 00007FFF
	v_bfe_u32 v16, v21, 16, 1                                  // 00000027E484: D6100010 02052115
	v_and_or_b32 v28, 0xffff0000, v15, v32                     // 00000027E48C: D657001C 04821EFF FFFF0000
	.long 0x7e403986                                           // 00000027E498: 7E403986
	v_add3_u32 v1, v1, v10, 0x7fff                             // 00000027E49C: D6550001 03FE1501 00007FFF
	.long 0xd73c0006                                           // 00000027E4A8: D73C0006
	v_cndmask_b32_e32 v1, 1, v7, vcc_lo                        // 00000027E4AC: 02020E81
	v_add3_u32 v10, v21, v16, 0x7fff                           // 00000027E4B0: D655000A 03FE2115 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000027E4BC: BF870214
	v_and_or_b32 v27, 0xffff0000, v26, v32                     // 00000027E4C0: D657001B 048234FF FFFF0000
	.long 0x7e403981                                           // 00000027E4CC: 7E403981
	.long 0xd7006a01                                           // 00000027E4D0: D7006A01
	v_cndmask_b32_e32 v1, s14, v4, vcc_lo                      // 00000027E4D4: 0202080E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000027E4D8: BF870191
	v_add_co_ci_u32_e64 v5, null, s15, v5, vcc_lo              // 00000027E4DC: D5207C05 01AA0A0F
	v_and_or_b32 v26, 0xffff0000, v10, v32                     // 00000027E4E4: D657001A 048214FF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000027E4F0: BF870093
	.long 0xd7006a04                                           // 00000027E4F4: D7006A04
	v_cndmask_b32_e32 v1, v1, v6, vcc_lo                       // 00000027E4F8: 02020D01
	v_add_co_ci_u32_e64 v5, null, v5, v7, vcc_lo               // 00000027E4FC: D5207C05 01AA0F05
	global_store_b128 v[4:5], v[26:29], off                    // 00000027E504: DC760000 007C1A04
	s_or_b32 exec_lo, exec_lo, s1                              // 00000027E50C: 8C7E017E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000027E510: BF870009
	s_mov_b32 s1, exec_lo                                      // 00000027E514: BE81007E
	.long 0xd4cc007e                                           // 00000027E518: D4CC007E
	v_cndmask_b32_e32 v1, s17, v14, vcc_lo                     // 00000027E51C: 02021C11
	s_cbranch_execnz 290                                       // 00000027E520: BFA60122 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi4ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0x16ac>
	s_or_b32 exec_lo, exec_lo, s1                              // 00000027E524: 8C7E017E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000027E528: BF870009
	s_mov_b32 s1, exec_lo                                      // 00000027E52C: BE81007E
	.long 0xd4cc007e                                           // 00000027E530: D4CC007E
	v_cndmask_b32_e32 v1, s17, v12, vcc_lo                     // 00000027E534: 02021811
	s_cbranch_execz 130                                        // 00000027E538: BFA50082 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi4ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0x1444>
	s_waitcnt vmcnt(1)                                         // 00000027E53C: BF8907F7
	v_lshrrev_b32_e32 v1, 22, v3                               // 00000027E540: 32020696
	v_lshrrev_b32_e32 v2, 26, v3                               // 00000027E544: 3204069A
	v_lshrrev_b32_e32 v4, 18, v3                               // 00000027E548: 32080692
	v_lshrrev_b32_e32 v5, 14, v3                               // 00000027E54C: 320A068E
	v_lshrrev_b32_e32 v6, 10, v3                               // 00000027E550: 320C068A
	v_and_b32_e32 v1, 60, v1                                   // 00000027E554: 360202BC
	v_lshrrev_b32_e32 v7, 6, v3                                // 00000027E558: 320E0686
	v_lshrrev_b32_e32 v10, 2, v3                               // 00000027E55C: 32140682
	v_and_b32_e32 v2, 60, v2                                   // 00000027E560: 360404BC
	v_and_b32_e32 v4, 60, v4                                   // 00000027E564: 360808BC
	ds_load_b32 v12, v1                                        // 00000027E568: D8D80000 0C000001
	v_and_b32_e32 v1, 60, v5                                   // 00000027E570: 36020ABC
	v_and_b32_e32 v5, 60, v6                                   // 00000027E574: 360A0CBC
	v_and_b32_e32 v6, 60, v7                                   // 00000027E578: 360C0EBC
	v_and_b32_e32 v7, 60, v10                                  // 00000027E57C: 360E14BC
	ds_load_b32 v10, v2                                        // 00000027E580: D8D80000 0A000002
	ds_load_b32 v4, v4                                         // 00000027E588: D8D80000 04000004
	ds_load_b32 v14, v1                                        // 00000027E590: D8D80000 0E000001
	v_and_b32_e32 v3, 15, v3                                   // 00000027E598: 3606068F
	.long 0x7f283880                                           // 00000027E59C: 7F283880
	s_delay_alu instid0(VALU_DEP_2)                            // 00000027E5A0: BF870002
	v_lshlrev_b32_e32 v1, 2, v3                                // 00000027E5A4: 30020682
	ds_load_b32 v5, v5                                         // 00000027E5A8: D8D80000 05000005
	ds_load_b32 v6, v6                                         // 00000027E5B0: D8D80000 06000006
	ds_load_b32 v15, v7                                        // 00000027E5B8: D8D80000 0F000007
	ds_load_b32 v16, v1                                        // 00000027E5C0: D8D80000 10000001
	v_mad_u64_u32 v[1:2], null, s4, v17, 0                     // 00000027E5C8: D6FE7C01 02022204
	s_waitcnt lgkmcnt(7)                                       // 00000027E5D0: BF89FC77
	v_dual_mov_b32 v7, v18 :: v_dual_mul_f32 v12, v24, v12     // 00000027E5D4: CA060112 070C1918
	s_delay_alu instid0(VALU_DEP_2)                            // 00000027E5DC: BF870002
	v_mad_u64_u32 v[2:3], null, s5, v17, v[2:3]                // 00000027E5E0: D6FE7C02 040A2205
	s_waitcnt lgkmcnt(6)                                       // 00000027E5E8: BF89FC67
	v_mul_f32_e32 v3, v24, v10                                 // 00000027E5EC: 10061518
	s_waitcnt lgkmcnt(5)                                       // 00000027E5F0: BF89FC57
	v_mul_f32_e32 v4, v24, v4                                  // 00000027E5F4: 10080918
	s_waitcnt lgkmcnt(4)                                       // 00000027E5F8: BF89FC47
	v_mul_f32_e32 v10, v24, v14                                // 00000027E5FC: 10141D18
	v_bfe_u32 v14, v12, 16, 1                                  // 00000027E600: D610000E 0205210C
	s_delay_alu instid0(VALU_DEP_3)                            // 00000027E608: BF870003
	v_bfe_u32 v18, v4, 16, 1                                   // 00000027E60C: D6100012 02052104
	s_waitcnt lgkmcnt(3)                                       // 00000027E614: BF89FC37
	v_mul_f32_e32 v5, v24, v5                                  // 00000027E618: 100A0B18
	s_waitcnt lgkmcnt(2)                                       // 00000027E61C: BF89FC27
	v_mul_f32_e32 v6, v24, v6                                  // 00000027E620: 100C0D18
	s_waitcnt lgkmcnt(1)                                       // 00000027E624: BF89FC17
	v_mul_f32_e32 v17, v24, v15                                // 00000027E628: 10221F18
	v_bfe_u32 v15, v3, 16, 1                                   // 00000027E62C: D610000F 02052103
	v_add3_u32 v12, v12, v14, 0x7fff                           // 00000027E634: D655000C 03FE1D0C 00007FFF
	v_bfe_u32 v14, v10, 16, 1                                  // 00000027E640: D610000E 0205210A
	s_waitcnt lgkmcnt(0)                                       // 00000027E648: BF89FC07
	v_mul_f32_e32 v16, v24, v16                                // 00000027E64C: 10202118
	v_add3_u32 v3, v3, v15, 0x7fff                             // 00000027E650: D6550003 03FE1F03 00007FFF
	.long 0x7e28398c                                           // 00000027E65C: 7E28398C
	v_add3_u32 v10, v10, v14, 0x7fff                           // 00000027E660: D655000A 03FE1D0A 00007FFF
	v_bfe_u32 v12, v6, 16, 1                                   // 00000027E66C: D610000C 02052106
	v_bfe_u32 v14, v5, 16, 1                                   // 00000027E674: D610000E 02052105
	v_add3_u32 v15, v4, v18, 0x7fff                            // 00000027E67C: D655000F 03FE2504 00007FFF
	v_and_or_b32 v4, 0xffff0000, v3, v20                       // 00000027E688: D6570004 045206FF FFFF0000
	.long 0x7e28398a                                           // 00000027E694: 7E28398A
	v_add3_u32 v6, v6, v12, 0x7fff                             // 00000027E698: D6550006 03FE1906 00007FFF
	v_bfe_u32 v10, v16, 16, 1                                  // 00000027E6A4: D610000A 02052110
	v_add3_u32 v18, v5, v14, 0x7fff                            // 00000027E6AC: D6550012 03FE1D05 00007FFF
	v_bfe_u32 v12, v17, 16, 1                                  // 00000027E6B8: D610000C 02052111
	v_and_or_b32 v3, 0xffff0000, v15, v20                      // 00000027E6C0: D6570003 04521EFF FFFF0000
	.long 0x7e283986                                           // 00000027E6CC: 7E283986
	.long 0xd73c0005                                           // 00000027E6D0: D73C0005
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000027E6D4: 02020281
	v_add3_u32 v10, v16, v10, 0x7fff                           // 00000027E6D8: D655000A 03FE1510 00007FFF
	.long 0xd73c000e                                           // 00000027E6E4: D73C000E
	v_cndmask_b32_e32 v1, 1, v7, vcc_lo                        // 00000027E6E8: 02020E81
	v_add3_u32 v1, v17, v12, 0x7fff                            // 00000027E6EC: D6550001 03FE1911 00007FFF
	v_and_or_b32 v2, 0xffff0000, v18, v20                      // 00000027E6F8: D6570002 045224FF FFFF0000
	.long 0xd7006a05                                           // 00000027E704: D7006A05
	v_cndmask_b32_e32 v1, s14, v5, vcc_lo                      // 00000027E708: 02020A0E
	.long 0x7e28398a                                           // 00000027E70C: 7E28398A
	v_add_co_ci_u32_e64 v6, null, s15, v6, vcc_lo              // 00000027E710: D5207C06 01AA0C0F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000027E718: BF870193
	.long 0xd7006a05                                           // 00000027E71C: D7006A05
	v_cndmask_b32_e32 v1, v5, v14, vcc_lo                      // 00000027E720: 02021D05
	v_and_or_b32 v1, 0xffff0000, v1, v20                       // 00000027E724: D6570001 045202FF FFFF0000
	s_delay_alu instid0(VALU_DEP_3)                            // 00000027E730: BF870003
	v_add_co_ci_u32_e64 v6, null, v6, v15, vcc_lo              // 00000027E734: D5207C06 01AA1F06
	global_store_b128 v[5:6], v[1:4], off                      // 00000027E73C: DC760000 007C0105
	s_or_b32 exec_lo, exec_lo, s1                              // 00000027E744: 8C7E017E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000027E748: BF870009
	s_mov_b32 s1, exec_lo                                      // 00000027E74C: BE81007E
	.long 0xd4cc007e                                           // 00000027E750: D4CC007E
	v_cndmask_b32_e32 v1, s17, v11, vcc_lo                     // 00000027E754: 02021611
	s_cbranch_execz 113                                        // 00000027E758: BFA50071 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi4ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0x1620>
	s_waitcnt vmcnt(0)                                         // 00000027E75C: BF8903F7
	v_lshrrev_b32_e32 v2, 26, v22                              // 00000027E760: 32042C9A
	v_lshrrev_b32_e32 v3, 18, v22                              // 00000027E764: 32062C92
	v_lshrrev_b32_e32 v4, 14, v22                              // 00000027E768: 32082C8E
	v_lshrrev_b32_e32 v1, 22, v22                              // 00000027E76C: 32022C96
	v_lshrrev_b32_e32 v5, 10, v22                              // 00000027E770: 320A2C8A
	v_and_b32_e32 v2, 60, v2                                   // 00000027E774: 360404BC
	v_and_b32_e32 v3, 60, v3                                   // 00000027E778: 360606BC
	v_and_b32_e32 v4, 60, v4                                   // 00000027E77C: 360808BC
	v_lshrrev_b32_e32 v6, 6, v22                               // 00000027E780: 320C2C86
	v_lshrrev_b32_e32 v7, 2, v22                               // 00000027E784: 320E2C82
	ds_load_b32 v2, v2                                         // 00000027E788: D8D80000 02000002
	ds_load_b32 v3, v3                                         // 00000027E790: D8D80000 03000003
	ds_load_b32 v4, v4                                         // 00000027E798: D8D80000 04000004
	v_and_b32_e32 v1, 60, v1                                   // 00000027E7A0: 360202BC
	v_and_b32_e32 v10, 15, v22                                 // 00000027E7A4: 36142C8F
	v_and_b32_e32 v5, 60, v5                                   // 00000027E7A8: 360A0ABC
	v_and_b32_e32 v6, 60, v6                                   // 00000027E7AC: 360C0CBC
	v_and_b32_e32 v7, 60, v7                                   // 00000027E7B0: 360E0EBC
	.long 0x7f163880                                           // 00000027E7B4: 7F163880
	v_lshlrev_b32_e32 v10, 2, v10                              // 00000027E7B8: 30141482
	ds_load_b32 v5, v5                                         // 00000027E7BC: D8D80000 05000005
	ds_load_b32 v6, v6                                         // 00000027E7C4: D8D80000 06000006
	ds_load_b32 v7, v7                                         // 00000027E7CC: D8D80000 07000007
	ds_load_b32 v10, v10                                       // 00000027E7D4: D8D80000 0A00000A
	s_or_b32 s0, s0, exec_lo                                   // 00000027E7DC: 8C007E00
	s_waitcnt lgkmcnt(6)                                       // 00000027E7E0: BF89FC67
	v_mul_f32_e32 v2, v19, v2                                  // 00000027E7E4: 10040513
	ds_load_b32 v1, v1                                         // 00000027E7E8: D8D80000 01000001
	s_waitcnt lgkmcnt(5)                                       // 00000027E7F0: BF89FC57
	v_mul_f32_e32 v4, v19, v4                                  // 00000027E7F4: 10080913
	v_mul_f32_e32 v3, v19, v3                                  // 00000027E7F8: 10060713
	s_waitcnt lgkmcnt(4)                                       // 00000027E7FC: BF89FC47
	v_mul_f32_e32 v5, v19, v5                                  // 00000027E800: 100A0B13
	s_waitcnt lgkmcnt(3)                                       // 00000027E804: BF89FC37
	v_mul_f32_e32 v6, v19, v6                                  // 00000027E808: 100C0D13
	s_waitcnt lgkmcnt(2)                                       // 00000027E80C: BF89FC27
	v_mul_f32_e32 v14, v19, v7                                 // 00000027E810: 101C0F13
	v_bfe_u32 v7, v2, 16, 1                                    // 00000027E814: D6100007 02052102
	s_waitcnt lgkmcnt(1)                                       // 00000027E81C: BF89FC17
	v_mul_f32_e32 v10, v19, v10                                // 00000027E820: 10141513
	v_bfe_u32 v15, v3, 16, 1                                   // 00000027E824: D610000F 02052103
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000027E82C: BF870113
	v_add3_u32 v2, v2, v7, 0x7fff                              // 00000027E830: D6550002 03FE0F02 00007FFF
	v_add3_u32 v3, v3, v15, 0x7fff                             // 00000027E83C: D6550003 03FE1F03 00007FFF
	s_waitcnt lgkmcnt(0)                                       // 00000027E848: BF89FC07
	v_mul_f32_e32 v1, v19, v1                                  // 00000027E84C: 10020313
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000027E850: BF870091
	v_bfe_u32 v12, v1, 16, 1                                   // 00000027E854: D610000C 02052101
	v_add3_u32 v1, v1, v12, 0x7fff                             // 00000027E85C: D6550001 03FE1901 00007FFF
	v_bfe_u32 v12, v4, 16, 1                                   // 00000027E868: D610000C 02052104
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000027E870: BF870112
	.long 0x7e163981                                           // 00000027E874: 7E163981
	v_add3_u32 v1, v4, v12, 0x7fff                             // 00000027E878: D6550001 03FE1904 00007FFF
	v_bfe_u32 v4, v6, 16, 1                                    // 00000027E884: D6100004 02052106
	v_bfe_u32 v12, v5, 16, 1                                   // 00000027E88C: D610000C 02052105
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000027E894: BF870214
	v_and_or_b32 v7, 0xffff0000, v2, v11                       // 00000027E898: D6570007 042E04FF FFFF0000
	.long 0x7e163981                                           // 00000027E8A4: 7E163981
	s_delay_alu instid0(VALU_DEP_4)                            // 00000027E8A8: BF870004
	v_add3_u32 v1, v6, v4, 0x7fff                              // 00000027E8AC: D6550001 03FE0906 00007FFF
	v_bfe_u32 v2, v10, 16, 1                                   // 00000027E8B8: D6100002 0205210A
	v_bfe_u32 v4, v14, 16, 1                                   // 00000027E8C0: D6100004 0205210E
	v_add3_u32 v5, v5, v12, 0x7fff                             // 00000027E8C8: D6550005 03FE1905 00007FFF
	v_and_or_b32 v6, 0xffff0000, v3, v11                       // 00000027E8D4: D6570006 042E06FF FFFF0000
	.long 0x7e163981                                           // 00000027E8E0: 7E163981
	v_add3_u32 v1, v10, v2, 0x7fff                             // 00000027E8E4: D6550001 03FE050A 00007FFF
	v_add3_u32 v2, v14, v4, 0x7fff                             // 00000027E8F0: D6550002 03FE090E 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000027E8FC: BF870193
	v_and_or_b32 v5, 0xffff0000, v5, v11                       // 00000027E900: D6570005 042E0AFF FFFF0000
	.long 0x7e163981                                           // 00000027E90C: 7E163981
	s_delay_alu instid0(VALU_DEP_1)                            // 00000027E910: BF870001
	v_and_or_b32 v4, 0xffff0000, v2, v11                       // 00000027E914: D6570004 042E04FF FFFF0000
	s_or_b32 exec_lo, exec_lo, s1                              // 00000027E920: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000027E924: BE812000
	s_cbranch_execz 64166                                      // 00000027E928: BFA5FAA6 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi4ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0xc4>
	s_waitcnt vmcnt(2)                                         // 00000027E92C: BF890BF7
	v_mad_u64_u32 v[1:2], null, s4, v13, 0                     // 00000027E930: D6FE7C01 02021A04
	v_mov_b32_e32 v10, v8                                      // 00000027E938: 7E140308
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000027E93C: BF8701A1
	.long 0xd73c0009                                           // 00000027E940: D73C0009
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 00000027E944: 02021281
	s_waitcnt vmcnt(1)                                         // 00000027E948: BF8907F7
	v_mad_u64_u32 v[2:3], null, s5, v13, v[2:3]                // 00000027E94C: D6FE7C02 040A1A05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000027E954: BF870091
	.long 0xd73c0001                                           // 00000027E958: D73C0001
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000027E95C: 02020281
	.long 0xd7006a01                                           // 00000027E960: D7006A01
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 00000027E964: 0202020E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000027E968: BF870111
	v_add_co_ci_u32_e64 v2, null, s15, v2, vcc_lo              // 00000027E96C: D5207C02 01AA040F
	.long 0xd7006a01                                           // 00000027E974: D7006A01
	v_cndmask_b32_e32 v1, v1, v9, vcc_lo                       // 00000027E978: 02021301
	s_delay_alu instid0(VALU_DEP_1)                            // 00000027E97C: BF870001
	v_add_co_ci_u32_e64 v2, null, v2, v10, vcc_lo              // 00000027E980: D5207C02 01AA1502
	global_store_b128 v[1:2], v[4:7], off                      // 00000027E988: DC760000 007C0401
	s_branch 64140                                             // 00000027E990: BFA0FA8C <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi4ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0xc4>
	s_or_b32 exec_lo, exec_lo, s1                              // 00000027E994: 8C7E017E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000027E998: BF870009
	s_mov_b32 s1, exec_lo                                      // 00000027E99C: BE81007E
	.long 0xd4cc007e                                           // 00000027E9A0: D4CC007E
	v_cndmask_b32_e32 v1, s17, v14, vcc_lo                     // 00000027E9A4: 02021C11
	s_cbranch_execz 65246                                      // 00000027E9A8: BFA5FEDE <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi4ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0x1224>
	s_waitcnt vmcnt(2)                                         // 00000027E9AC: BF890BF7
	v_lshrrev_b32_e32 v7, 10, v2                               // 00000027E9B0: 320E048A
	v_lshrrev_b32_e32 v10, 6, v2                               // 00000027E9B4: 32140486
	v_lshrrev_b32_e32 v14, 2, v2                               // 00000027E9B8: 321C0482
	v_lshrrev_b32_e32 v1, 22, v2                               // 00000027E9BC: 32020496
	v_lshrrev_b32_e32 v4, 26, v2                               // 00000027E9C0: 3208049A
	v_lshrrev_b32_e32 v5, 18, v2                               // 00000027E9C4: 320A0492
	v_lshrrev_b32_e32 v6, 14, v2                               // 00000027E9C8: 320C048E
	v_and_b32_e32 v2, 15, v2                                   // 00000027E9CC: 3604048F
	v_and_b32_e32 v7, 60, v7                                   // 00000027E9D0: 360E0EBC
	v_and_b32_e32 v10, 60, v10                                 // 00000027E9D4: 361414BC
	v_and_b32_e32 v14, 60, v14                                 // 00000027E9D8: 361C1CBC
	v_and_b32_e32 v4, 60, v4                                   // 00000027E9DC: 360808BC
	v_lshlrev_b32_e32 v2, 2, v2                                // 00000027E9E0: 30040482
	ds_load_b32 v26, v7                                        // 00000027E9E4: D8D80000 1A000007
	ds_load_b32 v10, v10                                       // 00000027E9EC: D8D80000 0A00000A
	ds_load_b32 v14, v14                                       // 00000027E9F4: D8D80000 0E00000E
	ds_load_b32 v2, v2                                         // 00000027E9FC: D8D80000 02000002
	v_and_b32_e32 v5, 60, v5                                   // 00000027EA04: 360A0ABC
	v_dual_mov_b32 v7, v23 :: v_dual_and_b32 v6, 60, v6        // 00000027EA08: CA240117 07060CBC
	.long 0x7f3a3880                                           // 00000027EA10: 7F3A3880
	s_waitcnt lgkmcnt(2)                                       // 00000027EA14: BF89FC27
	v_mul_f32_e32 v10, v25, v10                                // 00000027EA18: 10141519
	ds_load_b32 v15, v4                                        // 00000027EA1C: D8D80000 0F000004
	ds_load_b32 v16, v5                                        // 00000027EA24: D8D80000 10000005
	ds_load_b32 v21, v6                                        // 00000027EA2C: D8D80000 15000006
	v_mad_u64_u32 v[4:5], null, s4, v20, 0                     // 00000027EA34: D6FE7C04 02022804
	s_waitcnt lgkmcnt(4)                                       // 00000027EA3C: BF89FC47
	v_dual_mul_f32 v14, v25, v14 :: v_dual_and_b32 v1, 60, v1  // 00000027EA40: C8E41D19 0E0002BC
	s_waitcnt lgkmcnt(3)                                       // 00000027EA48: BF89FC37
	v_mul_f32_e32 v2, v25, v2                                  // 00000027EA4C: 10040519
	s_delay_alu instid0(VALU_DEP_3)                            // 00000027EA50: BF870003
	v_mad_u64_u32 v[5:6], null, s5, v20, v[5:6]                // 00000027EA54: D6FE7C05 04162805
	s_waitcnt lgkmcnt(2)                                       // 00000027EA5C: BF89FC27
	v_mul_f32_e32 v6, v25, v15                                 // 00000027EA60: 100C1F19
	ds_load_b32 v1, v1                                         // 00000027EA64: D8D80000 01000001
	s_waitcnt lgkmcnt(2)                                       // 00000027EA6C: BF89FC27
	v_mul_f32_e32 v15, v25, v16                                // 00000027EA70: 101E2119
	s_waitcnt lgkmcnt(1)                                       // 00000027EA74: BF89FC17
	v_mul_f32_e32 v16, v25, v21                                // 00000027EA78: 10202B19
	v_mul_f32_e32 v21, v25, v26                                // 00000027EA7C: 102A3519
	v_bfe_u32 v23, v6, 16, 1                                   // 00000027EA80: D6100017 02052106
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000027EA88: BF870141
	v_add3_u32 v6, v6, v23, 0x7fff                             // 00000027EA8C: D6550006 03FE2F06 00007FFF
	s_waitcnt lgkmcnt(0)                                       // 00000027EA98: BF89FC07
	v_mul_f32_e32 v1, v25, v1                                  // 00000027EA9C: 10020319
	v_bfe_u32 v25, v15, 16, 1                                  // 00000027EAA0: D6100019 0205210F
	v_bfe_u32 v20, v1, 16, 1                                   // 00000027EAA8: D6100014 02052101
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000027EAB0: BF870112
	v_add3_u32 v15, v15, v25, 0x7fff                           // 00000027EAB4: D655000F 03FE330F 00007FFF
	v_add3_u32 v1, v1, v20, 0x7fff                             // 00000027EAC0: D6550001 03FE2901 00007FFF
	v_bfe_u32 v20, v16, 16, 1                                  // 00000027EACC: D6100014 02052110
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000027EAD4: BF870112
	.long 0x7e3a3981                                           // 00000027EAD8: 7E3A3981
	v_add3_u32 v1, v16, v20, 0x7fff                            // 00000027EADC: D6550001 03FE2910 00007FFF
	v_bfe_u32 v16, v10, 16, 1                                  // 00000027EAE8: D6100010 0205210A
	v_bfe_u32 v20, v21, 16, 1                                  // 00000027EAF0: D6100014 02052115
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000027EAF8: BF870214
	v_and_or_b32 v28, 0xffff0000, v6, v29                      // 00000027EAFC: D657001C 04760CFF FFFF0000
	.long 0x7e3a3981                                           // 00000027EB08: 7E3A3981
	s_delay_alu instid0(VALU_DEP_4)                            // 00000027EB0C: BF870004
	v_add3_u32 v1, v10, v16, 0x7fff                            // 00000027EB10: D6550001 03FE210A 00007FFF
	v_bfe_u32 v6, v2, 16, 1                                    // 00000027EB1C: D6100006 02052102
	v_bfe_u32 v10, v14, 16, 1                                  // 00000027EB24: D610000A 0205210E
	v_add3_u32 v16, v21, v20, 0x7fff                           // 00000027EB2C: D6550010 03FE2915 00007FFF
	v_and_or_b32 v27, 0xffff0000, v15, v29                     // 00000027EB38: D657001B 04761EFF FFFF0000
	.long 0x7e3a3981                                           // 00000027EB44: 7E3A3981
	v_add3_u32 v6, v2, v6, 0x7fff                              // 00000027EB48: D6550006 03FE0D02 00007FFF
	.long 0xd73c0001                                           // 00000027EB54: D73C0001
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 00000027EB58: 02020881
	.long 0xd73c0004                                           // 00000027EB5C: D73C0004
	v_cndmask_b32_e32 v1, 1, v7, vcc_lo                        // 00000027EB60: 02020E81
	v_add3_u32 v7, v14, v10, 0x7fff                            // 00000027EB64: D6550007 03FE150E 00007FFF
	v_and_or_b32 v26, 0xffff0000, v16, v29                     // 00000027EB70: D657001A 047620FF FFFF0000
	.long 0x7e3a3986                                           // 00000027EB7C: 7E3A3986
	.long 0xd7006a01                                           // 00000027EB80: D7006A01
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 00000027EB84: 0202020E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000027EB88: BF870191
	v_add_co_ci_u32_e64 v2, null, s15, v2, vcc_lo              // 00000027EB8C: D5207C02 01AA040F
	v_and_or_b32 v25, 0xffff0000, v7, v29                      // 00000027EB94: D6570019 04760EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000027EBA0: BF870093
	.long 0xd7006a01                                           // 00000027EBA4: D7006A01
	v_cndmask_b32_e32 v1, v1, v4, vcc_lo                       // 00000027EBA8: 02020901
	v_add_co_ci_u32_e64 v2, null, v2, v5, vcc_lo               // 00000027EBAC: D5207C02 01AA0B02
	global_store_b128 v[1:2], v[25:28], off                    // 00000027EBB4: DC760000 007C1901
	s_or_b32 exec_lo, exec_lo, s1                              // 00000027EBBC: 8C7E017E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000027EBC0: BF870009
	s_mov_b32 s1, exec_lo                                      // 00000027EBC4: BE81007E
	.long 0xd4cc007e                                           // 00000027EBC8: D4CC007E
	v_cndmask_b32_e32 v1, s17, v12, vcc_lo                     // 00000027EBCC: 02021811
	s_cbranch_execz 65244                                      // 00000027EBD0: BFA5FEDC <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi4ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0x1444>
	s_branch 65113                                             // 00000027EBD4: BFA0FE59 <_ZN7halogen12_GLOBAL__N_114k_deq_q4cp_v8uILi4ELb0EEEvPKhPtjjllllNS0_5DeqCbE+0x123c>
	s_endpgm                                                   // 00000027EBD8: BFB00000
		...

