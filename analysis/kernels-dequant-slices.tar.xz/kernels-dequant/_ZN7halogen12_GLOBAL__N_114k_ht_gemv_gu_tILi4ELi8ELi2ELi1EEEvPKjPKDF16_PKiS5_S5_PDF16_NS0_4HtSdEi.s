000000000098d800 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi>:
; _ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi():
	s_clause 0x1                                               // 00000098D800: BF850001
	s_load_b32 s3, s[0:1], 0x88                                // 00000098D804: F40000C0 F8000088
	s_load_b512 s[12:27], s[0:1], null                         // 00000098D80C: F4100300 F8000000
	v_and_b32_e32 v12, 31, v0                                  // 00000098D814: 3618009F
	v_lshrrev_b32_e32 v11, 5, v0                               // 00000098D818: 32160085
	s_mov_b32 s4, -1                                           // 00000098D81C: BE8400C1
	s_waitcnt lgkmcnt(0)                                       // 00000098D820: BF89FC07
	s_cmp_lt_i32 s2, s3                                        // 00000098D824: BF040302
	s_cbranch_scc1 2422                                        // 00000098D828: BFA20976 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2604>
	s_load_b64 s[8:9], s[0:1], 0x7c                            // 00000098D82C: F4040200 F800007C
	s_sub_i32 s3, s2, s3                                       // 00000098D834: 81830302
	s_clause 0x1                                               // 00000098D838: BF850001
	s_load_b256 s[44:51], s[0:1], 0x60                         // 00000098D83C: F40C0B00 F8000060
	s_load_b256 s[36:43], s[0:1], 0x40                         // 00000098D844: F40C0900 F8000040
	s_mov_b32 s34, 0                                           // 00000098D84C: BEA20080
	s_mov_b32 s33, exec_lo                                     // 00000098D850: BEA1007E
	s_waitcnt lgkmcnt(0)                                       // 00000098D854: BF89FC07
	s_abs_i32 s4, s9                                           // 00000098D858: BE841509
	s_ashr_i32 s7, s9, 31                                      // 00000098D85C: 86079F09
	s_cvt_f32_u32 s5, s4                                       // 00000098D860: BE856504
	s_sub_i32 s6, 0, s4                                        // 00000098D864: 81860480
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000098D868: BF87029A
	v_rcp_iflag_f32_e32 v1, s5                                 // 00000098D86C: 7E025605
	v_readfirstlane_b32 s5, v1                                 // 00000098D870: 7E0A0501
	s_mul_f32 s5, s5, 0x4f7ffffe                               // 00000098D874: A205FF05 4F7FFFFE
	s_delay_alu instid0(SALU_CYCLE_3) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 00000098D87C: BF87059B
	s_cvt_u32_f32 s5, s5                                       // 00000098D880: BE856705
	s_mul_i32 s6, s6, s5                                       // 00000098D884: 96060506
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000098D888: BF870499
	s_mul_hi_u32 s6, s5, s6                                    // 00000098D88C: 96860605
	s_add_i32 s5, s5, s6                                       // 00000098D890: 81050605
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000098D894: BF870499
	s_mul_hi_u32 s5, s3, s5                                    // 00000098D898: 96850503
	s_mul_i32 s6, s5, s4                                       // 00000098D89C: 96060405
	s_add_i32 s10, s5, 1                                       // 00000098D8A0: 810A8105
	s_sub_i32 s6, s3, s6                                       // 00000098D8A4: 81860603
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000098D8A8: BF870009
	s_sub_i32 s11, s6, s4                                      // 00000098D8AC: 818B0406
	s_cmp_ge_u32 s6, s4                                        // 00000098D8B0: BF090406
	s_cselect_b32 s5, s10, s5                                  // 00000098D8B4: 9805050A
	s_cselect_b32 s6, s11, s6                                  // 00000098D8B8: 9806060B
	s_add_i32 s10, s5, 1                                       // 00000098D8BC: 810A8105
	s_cmp_ge_u32 s6, s4                                        // 00000098D8C0: BF090406
	s_cselect_b32 s4, s10, s5                                  // 00000098D8C4: 9804050A
	s_ashr_i32 s11, s50, 31                                    // 00000098D8C8: 860B9F32
	s_xor_b32 s4, s4, s7                                       // 00000098D8CC: 8D040704
	s_lshr_b32 s1, s11, 25                                     // 00000098D8D0: 8501990B
	s_sub_i32 s10, s4, s7                                      // 00000098D8D4: 818A0704
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000098D8D8: BF870499
	s_mul_i32 s0, s10, s9                                      // 00000098D8DC: 9600090A
	s_sub_i32 s30, s3, s0                                      // 00000098D8E0: 819E0003
	s_add_i32 s0, s50, s1                                      // 00000098D8E4: 81000132
	s_mul_i32 s31, s30, s8                                     // 00000098D8E8: 961F081E
	s_ashr_i32 s0, s0, 7                                       // 00000098D8EC: 86008700
	s_add_i32 s1, s31, s8                                      // 00000098D8F0: 8101081F
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000098D8F4: BF870499
	s_min_i32 s0, s0, s1                                       // 00000098D8F8: 89000100
	s_sub_i32 s29, s0, s31                                     // 00000098D8FC: 819D1F00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000098D900: BF870499
	s_lshl_b32 s28, s29, 1                                     // 00000098D904: 841C811D
	.long 0xd4c4007e                                           // 00000098D908: D4C4007E
	v_cndmask_b32_e32 v1, s28, v11, vcc_lo                     // 00000098D90C: 0202161C
	s_cbranch_execz 505                                        // 00000098D910: BFA501F9 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x8f8>
	s_add_i32 s35, s48, -1                                     // 00000098D914: 8123C130
	s_cmp_lg_u64 s[40:41], 0                                   // 00000098D918: BF118028
	v_dual_mov_b32 v8, v11 :: v_dual_and_b32 v1, 1, v0         // 00000098D91C: CA24010B 08000081
	s_cselect_b32 s51, -1, 0                                   // 00000098D924: 983380C1
	s_abs_i32 s52, s29                                         // 00000098D928: BEB4151D
	v_and_b32_e32 v2, 2, v0                                    // 00000098D92C: 36040082
	s_cvt_f32_u32 s0, s52                                      // 00000098D930: BE806534
	v_lshlrev_b32_e32 v6, 3, v12                               // 00000098D934: 300C1883
	v_lshlrev_b32_e32 v7, 7, v11                               // 00000098D938: 300E1687
	v_and_b32_e32 v3, 4, v0                                    // 00000098D93C: 36060084
	v_rcp_iflag_f32_e32 v4, s0                                 // 00000098D940: 7E085600
	v_and_b32_e32 v5, 8, v0                                    // 00000098D944: 360A0088
	.long 0xd44a0001                                           // 00000098D948: D44A0001
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000098D94C: 02020280
	.long 0xd44a0003                                           // 00000098D950: D44A0003
	v_cndmask_b32_e32 v1, 0, v2, vcc_lo                        // 00000098D954: 02020480
	v_lshl_or_b32 v1, v11, 8, v6                               // 00000098D958: D6560001 0419110B
	v_lshl_add_u32 v2, s31, 7, v7                              // 00000098D960: D6460002 041D0E1F
	s_ashr_i32 s54, s29, 31                                    // 00000098D968: 86369F1D
	s_sub_i32 s56, 0, s52                                      // 00000098D96C: 81B83480
	s_mul_i32 s8, s54, 0x1400                                  // 00000098D970: 9608FF36 00001400
	.long 0xd44c0000                                           // 00000098D978: D44C0000
	v_cndmask_b32_e32 v1, 16, v12, vcc_lo                      // 00000098D97C: 02021890
	v_readfirstlane_b32 s5, v4                                 // 00000098D980: 7E0A0504
	.long 0xd44a0004                                           // 00000098D984: D44A0004
	v_cndmask_b32_e32 v1, 0, v3, vcc_lo                        // 00000098D988: 02020680
	v_subrev_nc_u32_e32 v9, s8, v1                             // 00000098D98C: 4E120208
	v_lshl_or_b32 v1, v12, 2, v2                               // 00000098D990: D6560001 0409050C
	s_lshl_b32 s6, s29, 7                                      // 00000098D998: 8406871D
	s_mul_f32 s7, s5, 0x4f7ffffe                               // 00000098D99C: A207FF05 4F7FFFFE
	.long 0xd44a0005                                           // 00000098D9A4: D44A0005
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 00000098D9A8: 02020A80
	s_mov_b32 s53, 0x76543210                                  // 00000098D9AC: BEB500FF 76543210
	s_lshl_b32 s55, s29, 8                                     // 00000098D9B4: 8437881D
	s_cvt_u32_f32 s7, s7                                       // 00000098D9B8: BE876707
	s_mov_b32 s58, 0x3db504f3                                  // 00000098D9BC: BEBA00FF 3DB504F3
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000098D9C4: BF87049A
	s_mul_i32 s56, s56, s7                                     // 00000098D9C8: 96380738
	s_mul_hi_u32 s8, s7, s56                                   // 00000098D9CC: 96883807
	s_sub_i32 s56, 0, s6                                       // 00000098D9D0: 81B80680
	s_add_i32 s57, s7, s8                                      // 00000098D9D4: 81390807
	s_branch 166                                               // 00000098D9D8: BFA000A6 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x474>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000098D9DC: BF870091
	.long 0xd7006a02                                           // 00000098D9E0: D7006A02
	v_cndmask_b32_e32 v1, s26, v2, vcc_lo                      // 00000098D9E4: 0202041A
	v_add_co_ci_u32_e64 v3, null, s27, v3, vcc_lo              // 00000098D9E8: D5207C03 01AA061B
	v_add_nc_u32_e32 v1, 0x400, v1                             // 00000098D9F0: 4A0202FF 00000400
	v_add_nc_u32_e32 v8, 8, v8                                 // 00000098D9F8: 4A101088
	global_load_d16_b16 v2, v[2:3], off offset:6               // 00000098D9FC: DC820006 027C0002
	v_cmp_le_i32_e32 vcc_lo, s28, v8                           // 00000098DA04: 7C86101C
	s_or_b32 s34, vcc_lo, s34                                  // 00000098DA08: 8C22226A
	s_waitcnt vmcnt(0)                                         // 00000098DA0C: BF8903F7
	v_fma_mix_f32 v5, v16, v2, v14 op_sel_hi:[0,1,0]           // 00000098DA10: CC200005 143A0510
	v_sub_f32_e32 v4, v17, v15                                 // 00000098DA18: 08081F11
	v_fma_mix_f32 v2, -v16, v2, v14 op_sel_hi:[0,1,0]          // 00000098DA1C: CC200002 343A0510
	v_add_f32_e32 v3, v17, v15                                 // 00000098DA24: 06061F11
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000098DA28: BF8701A2
	v_add_f32_e32 v7, v4, v2                                   // 00000098DA2C: 060E0504
	v_sub_f32_e32 v2, v4, v2                                   // 00000098DA30: 08040504
	v_add_f32_e32 v6, v3, v5                                   // 00000098DA34: 060C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 00000098DA38: 08060B03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000098DA3C: BF870193
	v_mov_b32_dpp v15, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000098DA40: 7E1E02FA FF016102
	v_mov_b32_dpp v4, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000098DA48: 7E0802FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 00000098DA50: D5010006 20060D06
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000098DA58: BF870234
	v_mov_b32_dpp v14, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000098DA5C: 7E1C02FA FF016103
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 00000098DA64: D5010002 20060502
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 00000098DA6C: D5010003 20060703
	v_add_f32_e32 v4, v6, v4                                   // 00000098DA74: 06080906
	v_mov_b32_dpp v5, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000098DA78: 7E0A02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 00000098DA80: D5010007 20060F07
	.long 0xd72c0006                                           // 00000098DA88: D72C0006
	v_cndmask_b32_e32 v1, 0x1400, v13, vcc_lo                  // 00000098DA8C: 02021AFF 00001400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000098DA94: BF870242
	v_dual_add_f32 v2, v2, v15 :: v_dual_add_f32 v5, v7, v5    // 00000098DA98: C9081F02 02040B07
	v_mov_b32_dpp v7, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000098DAA0: 7E0E02FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 00000098DAA8: D5010004 200E0904
	v_add_f32_e32 v3, v3, v14                                  // 00000098DAB0: 06061D03
	v_mov_b32_dpp v15, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000098DAB4: 7E1E02FA FF016202
	v_mov_b32_dpp v13, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000098DABC: 7E1A02FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 00000098DAC4: D5010005 200E0B05
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 00000098DACC: D5010002 200E0502
	v_add_f32_e32 v4, v4, v7                                   // 00000098DAD4: 06080F04
	v_mov_b32_dpp v14, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000098DAD8: 7E1C02FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 00000098DAE0: D5010003 200E0703
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000098DAE8: BF870234
	v_dual_add_f32 v5, v5, v13 :: v_dual_add_f32 v2, v2, v15   // 00000098DAEC: C9081B05 05021F02
	.long 0xd72c0007                                           // 00000098DAF4: D72C0007
	v_cndmask_b32_e32 v1, s55, v10, vcc_lo                     // 00000098DAF8: 02021437
	v_mov_b32_dpp v10, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000098DAFC: 7E1402FA FF016404
	v_add_f32_e32 v3, v3, v14                                  // 00000098DB04: 06061D03
	s_delay_alu instid0(VALU_DEP_4)                            // 00000098DB08: BF870004
	v_mov_b32_dpp v13, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000098DB0C: 7E1A02FA FF016405
	v_cndmask_b32_e64 v4, -v4, v4, s4                          // 00000098DB14: D5010004 20120904
	v_cndmask_b32_e64 v5, -v5, v5, s4                          // 00000098DB1C: D5010005 20120B05
	v_mov_b32_dpp v15, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000098DB24: 7E1E02FA FF016402
	v_mov_b32_dpp v14, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000098DB2C: 7E1C02FA FF016403
	v_cndmask_b32_e64 v2, -v2, v2, s4                          // 00000098DB34: D5010002 20120502
	v_cndmask_b32_e64 v3, -v3, v3, s4                          // 00000098DB3C: D5010003 20120703
	v_dual_add_f32 v4, v4, v10 :: v_dual_add_f32 v5, v5, v13   // 00000098DB44: C9081504 04041B05
	v_sub_nc_u32_e32 v6, v6, v7                                // 00000098DB4C: 4C0C0F06
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000098DB50: BF870193
	v_dual_add_f32 v2, v2, v15 :: v_dual_add_f32 v3, v3, v14   // 00000098DB54: C9081F02 02021D03
	v_mov_b32_dpp v10, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000098DB5C: 7E1402FA FF016804
	s_delay_alu instid0(VALU_DEP_4)                            // 00000098DB64: BF870004
	v_mov_b32_dpp v13, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000098DB68: 7E1A02FA FF016805
	v_cndmask_b32_e64 v4, -v4, v4, s5                          // 00000098DB70: D5010004 20160904
	v_cndmask_b32_e64 v5, -v5, v5, s5                          // 00000098DB78: D5010005 20160B05
	v_mov_b32_dpp v14, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000098DB80: 7E1C02FA FF016803
	v_mov_b32_dpp v15, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000098DB88: 7E1E02FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s5                          // 00000098DB90: D5010002 20160502
	v_cndmask_b32_e64 v3, -v3, v3, s5                          // 00000098DB98: D5010003 20160703
	v_dual_add_f32 v4, v4, v10 :: v_dual_add_f32 v5, v5, v13   // 00000098DBA0: C9081504 04041B05
	v_add_nc_u32_e32 v6, v9, v6                                // 00000098DBA8: 4A0C0D09
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000098DBAC: BF870193
	v_dual_add_f32 v2, v2, v15 :: v_dual_add_f32 v3, v3, v14   // 00000098DBB0: C9081F02 02021D03
	v_dual_mov_b32 v10, v4 :: v_dual_mov_b32 v13, v5           // 00000098DBB8: CA100104 0A0C0105
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 00000098DBC0: D5010005 20020B05
	s_delay_alu instid0(VALU_DEP_3)                            // 00000098DBC8: BF870003
	v_mov_b32_e32 v15, v2                                      // 00000098DBCC: 7E1E0302
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 00000098DBD0: D5010004 20020904
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 00000098DBD8: D5010002 20020502
	v_permlanex16_b32 v13, v13, s53, 0xfedcba98                // 00000098DBE0: D65C000D 03FC6B0D FEDCBA98
	v_mov_b32_e32 v14, v3                                      // 00000098DBEC: 7E1C0303
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 00000098DBF0: D5010003 20020703
	v_permlanex16_b32 v10, v10, s53, 0xfedcba98                // 00000098DBF8: D65C000A 03FC6B0A FEDCBA98
	v_permlanex16_b32 v15, v15, s53, 0xfedcba98                // 00000098DC04: D65C000F 03FC6B0F FEDCBA98
	v_add_f32_e32 v5, v5, v13                                  // 00000098DC10: 060A1B05
	v_permlanex16_b32 v14, v14, s53, 0xfedcba98                // 00000098DC14: D65C000E 03FC6B0E FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000098DC20: BF870214
	v_dual_add_f32 v4, v4, v10 :: v_dual_add_nc_u32 v9, 0x800, v9// 00000098DC24: C9201504 040812FF 00000800
	v_add_f32_e32 v7, v2, v15                                  // 00000098DC30: 060E1F02
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000098DC34: BF870214
	v_fma_mixhi_f16 v2, v5, s58, 0                             // 00000098DC38: CC220002 02007505
	v_add_f32_e32 v10, v3, v14                                 // 00000098DC40: 06141D03
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000098DC44: BF870214
	v_fma_mixlo_f16 v2, v4, s58, 0                             // 00000098DC48: CC210002 02007504
	v_fma_mixhi_f16 v3, v7, s58, 0                             // 00000098DC50: CC220003 02007507
	s_delay_alu instid0(VALU_DEP_3)                            // 00000098DC58: BF870003
	v_fma_mixlo_f16 v3, v10, s58, 0                            // 00000098DC5C: CC210003 0200750A
	ds_store_b64 v6, v[2:3]                                    // 00000098DC64: D9340000 00000206
	s_and_not1_b32 exec_lo, exec_lo, s34                       // 00000098DC6C: 917E227E
	s_cbranch_execz 289                                        // 00000098DC70: BFA50121 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x8f8>
	.long 0xd72d0002                                           // 00000098DC74: D72D0002
	v_cndmask_b32_e32 v0, v8, v57, vcc_lo                      // 00000098DC78: 02007308
	s_mov_b32 s6, -1                                           // 00000098DC7C: BE8600C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000098DC80: BF870091
	.long 0xd72c0003                                           // 00000098DC84: D72C0003
	v_cndmask_b32_e32 v0, v2, v52, vcc_lo                      // 00000098DC88: 02006902
	v_sub_nc_u32_e32 v3, v8, v3                                // 00000098DC8C: 4C060708
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000098DC90: BF870121
	v_subrev_nc_u32_e32 v5, s52, v3                            // 00000098DC94: 4E0A0634
	v_cmp_le_u32_e32 vcc_lo, s52, v3                           // 00000098DC98: 7C960634
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_add_nc_u32 v4, 1, v2// 00000098DC9C: CA600B03 03040481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000098DCA4: BF870111
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 00000098DCA8: 02040902
	v_cmp_le_u32_e32 vcc_lo, s52, v3                           // 00000098DCAC: 7C960634
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000098DCB0: BF870092
	v_add_nc_u32_e32 v4, 1, v2                                 // 00000098DCB4: 4A080481
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 00000098DCB8: 02040902
	s_and_not1_b32 vcc_lo, exec_lo, s51                        // 00000098DCBC: 916A337E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000098DCC0: BF870091
	v_xor_b32_e32 v13, s54, v2                                 // 00000098DCC4: 3A1A0436
	v_subrev_nc_u32_e32 v10, s54, v13                          // 00000098DCC8: 4E141A36
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000098DCCC: BF8700A1
	v_mad_u64_u32 v[6:7], null, s56, v10, v[1:2]               // 00000098DCD0: D6FE7C06 04061438
	v_min_i32_e32 v2, s35, v10                                 // 00000098DCD8: 22041423
	v_mad_i64_i32 v[4:5], null, v2, s50, 0                     // 00000098DCDC: D6FF7C04 02006502
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000098DCE4: BF870093
	v_ashrrev_i32_e32 v7, 31, v6                               // 00000098DCE8: 340E0C9F
	.long 0xd73c0002                                           // 00000098DCEC: D73C0002
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 00000098DCF0: 02020C81
	s_cbranch_vccnz 212                                        // 00000098DCF4: BFA400D4 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x848>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000098DCF8: BF870093
	.long 0xd7006a06                                           // 00000098DCFC: D7006A06
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 00000098DD00: 02020D04
	v_add_co_ci_u32_e64 v7, null, v5, v7, vcc_lo               // 00000098DD04: D5207C07 01AA0F05
	.long 0x7f3c3880                                           // 00000098DD0C: 7F3C3880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000098DD10: BF870112
	.long 0xd73c0006                                           // 00000098DD14: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 00000098DD18: 02020C81
	.long 0x7f42399e                                           // 00000098DD1C: 7F42399E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000098DD20: BF870092
	.long 0xd7006a0e                                           // 00000098DD24: D7006A0E
	v_cndmask_b32_e32 v1, s38, v6, vcc_lo                      // 00000098DD28: 02020C26
	v_add_co_ci_u32_e64 v15, null, s39, v7, vcc_lo             // 00000098DD2C: D5207C0F 01AA0E27
	.long 0xd7006a06                                           // 00000098DD34: D7006A06
	v_cndmask_b32_e32 v1, s40, v6, vcc_lo                      // 00000098DD38: 02020C28
	s_delay_alu instid0(VALU_DEP_1)                            // 00000098DD3C: BF870001
	v_add_co_ci_u32_e64 v7, null, s41, v7, vcc_lo              // 00000098DD40: D5207C07 01AA0E29
	global_load_b64 v[14:15], v[14:15], off                    // 00000098DD48: DC560000 0E7C000E
	.long 0xd7006a10                                           // 00000098DD50: D7006A10
	v_cndmask_b32_e32 v1, s26, v2, vcc_lo                      // 00000098DD54: 0202041A
	global_load_b64 v[6:7], v[6:7], off                        // 00000098DD58: DC560000 067C0006
	v_add_co_ci_u32_e64 v17, null, s27, v3, vcc_lo             // 00000098DD60: D5207C11 01AA061B
	s_clause 0x1                                               // 00000098DD68: BF850001
	global_load_b32 v18, v[16:17], off                         // 00000098DD6C: DC520000 127C0010
	global_load_d16_b16 v16, v[16:17], off offset:4            // 00000098DD74: DC820004 107C0010
	s_waitcnt vmcnt(3)                                         // 00000098DD7C: BF890FF7
	.long 0x7e22390e                                           // 00000098DD80: 7E22390E
	s_waitcnt vmcnt(2)                                         // 00000098DD84: BF890BF7
	v_and_b32_e32 v40, 0xffff0000, v6                          // 00000098DD88: 36500CFF FFFF0000
	v_lshlrev_b32_e32 v6, 16, v6                               // 00000098DD90: 300C0C90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000098DD94: BF870093
	v_lshlrev_b32_e32 v17, 16, v17                             // 00000098DD98: 30222290
	v_mul_f32_e32 v21, 0xbfb8aa3b, v17                         // 00000098DD9C: 102A22FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000098DDA4: BF870291
	v_exp_f32_e32 v21, v21                                     // 00000098DDA8: 7E2A4B15
	v_dual_add_f32 v21, 1.0, v21 :: v_dual_and_b32 v14, 0xffff0000, v14// 00000098DDAC: C9242AF2 150E1CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000098DDB8: BF870111
	v_mul_f32_e32 v20, 0xbfb8aa3b, v14                         // 00000098DDBC: 10281CFF BFB8AA3B
	v_div_scale_f32 v25, null, v21, v21, v17                   // 00000098DDC4: D6FC7C19 04462B15
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000098DDCC: BF8701B2
	v_exp_f32_e32 v20, v20                                     // 00000098DDD0: 7E284B14
	v_lshlrev_b32_e32 v19, 16, v15                             // 00000098DDD4: 30261E90
	v_div_scale_f32 v38, s7, v17, v21, v17                     // 00000098DDD8: D6FC0726 04462B11
	v_rcp_f32_e32 v29, v25                                     // 00000098DDE0: 7E3A5519
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000098DDE4: BF870196
	v_add_f32_e32 v20, 1.0, v20                                // 00000098DDE8: 062828F2
	v_mul_f32_e32 v22, 0xbfb8aa3b, v19                         // 00000098DDEC: 102C26FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000098DDF4: BF870195
	v_fma_f32 v37, -v25, v29, 1.0                              // 00000098DDF8: D6130025 23CA3B19
	v_div_scale_f32 v24, null, v20, v20, v14                   // 00000098DE00: D6FC7C18 043A2914
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000098DE08: BF8701B3
	v_exp_f32_e32 v22, v22                                     // 00000098DE0C: 7E2C4B16
	v_and_b32_e32 v15, 0xffff0000, v15                         // 00000098DE10: 361E1EFF FFFF0000
	v_div_scale_f32 v34, vcc_lo, v14, v20, v14                 // 00000098DE18: D6FC6A22 043A290E
	v_rcp_f32_e32 v27, v24                                     // 00000098DE20: 7E365518
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_2)   // 00000098DE24: BF870106
	v_dual_add_f32 v22, 1.0, v22 :: v_dual_mul_f32 v23, 0xbfb8aa3b, v15// 00000098DE28: C9062CF2 16161EFF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000098DE34: BF870115
	v_fma_f32 v35, -v24, v27, 1.0                              // 00000098DE38: D6130023 23CA3718
	v_div_scale_f32 v26, null, v22, v22, v19                   // 00000098DE40: D6FC7C1A 044E2D16
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000098DE48: BF8701A3
	v_exp_f32_e32 v23, v23                                     // 00000098DE4C: 7E2E4B17
	v_div_scale_f32 v36, s6, v19, v22, v19                     // 00000098DE50: D6FC0624 044E2D13
	v_fmac_f32_e32 v27, v35, v27                               // 00000098DE58: 56363723
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 00000098DE5C: BF870313
	v_rcp_f32_e32 v31, v26                                     // 00000098DE60: 7E3E551A
	v_add_f32_e32 v23, 1.0, v23                                // 00000098DE64: 062E2EF2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000098DE68: BF870115
	v_fma_f32 v39, -v26, v31, 1.0                              // 00000098DE6C: D6130027 23CA3F1A
	v_div_scale_f32 v28, null, v23, v23, v15                   // 00000098DE74: D6FC7C1C 043E2F17
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000098DE7C: BF8701A2
	v_fmac_f32_e32 v31, v39, v31                               // 00000098DE80: 563E3F27
	v_mul_f32_e32 v39, v34, v27                                // 00000098DE84: 104E3722
	v_rcp_f32_e32 v32, v28                                     // 00000098DE88: 7E40551C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000098DE8C: BF870091
	v_fma_f32 v42, -v24, v39, v34                              // 00000098DE90: D613002A 248A4F18
	v_fmac_f32_e32 v39, v42, v27                               // 00000098DE98: 564E372A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000098DE9C: BF870115
	v_fma_f32 v35, -v28, v32, 1.0                              // 00000098DEA0: D6130023 23CA411C
	v_fma_f32 v24, -v24, v39, v34                              // 00000098DEA8: D6130018 248A4F18
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000098DEB0: BF870112
	v_fmac_f32_e32 v32, v35, v32                               // 00000098DEB4: 56404123
	v_div_fmas_f32 v24, v24, v27, v39                          // 00000098DEB8: D6370018 049E3718
	s_mov_b32 vcc_lo, s7                                       // 00000098DEC0: BEEA0007
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000098DEC4: BF8701B1
	v_div_fixup_f32 v14, v24, v20, v14                         // 00000098DEC8: D627000E 043A2918
	v_fmac_f32_e32 v29, v37, v29                               // 00000098DED0: 563A3B25
	v_div_scale_f32 v37, s8, v15, v23, v15                     // 00000098DED4: D6FC0825 043E2F0F
	v_mul_f32_e32 v14, v14, v40                                // 00000098DEDC: 101C510E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000098DEE0: BF870193
	v_mul_f32_e32 v35, v38, v29                                // 00000098DEE4: 10463B26
	v_mul_f32_e32 v43, v37, v32                                // 00000098DEE8: 10564125
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000098DEEC: BF870193
	.long 0x7e3c398e                                           // 00000098DEF0: 7E3C398E
	v_fma_f32 v44, -v25, v35, v38                              // 00000098DEF4: D613002C 249A4719
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000098DEFC: BF870113
	v_fma_f32 v42, -v28, v43, v37                              // 00000098DF00: D613002A 2496571C
	v_fmac_f32_e32 v35, v44, v29                               // 00000098DF08: 56463B2C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000098DF0C: BF870112
	v_fmac_f32_e32 v43, v42, v32                               // 00000098DF10: 5656412A
	v_fma_f32 v25, -v25, v35, v38                              // 00000098DF14: D6130019 249A4719
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000098DF1C: BF870112
	v_fma_f32 v24, -v28, v43, v37                              // 00000098DF20: D6130018 2496571C
	v_div_fmas_f32 v25, v25, v29, v35                          // 00000098DF28: D6370019 048E3B19
	s_mov_b32 vcc_lo, s6                                       // 00000098DF30: BEEA0006
	s_mov_b32 s6, 0                                            // 00000098DF34: BE860080
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000098DF38: BF870121
	v_div_fixup_f32 v17, v25, v21, v17                         // 00000098DF3C: D6270011 04462B19
	v_lshlrev_b32_e32 v21, 16, v7                              // 00000098DF44: 302A0E90
	v_dual_mul_f32 v6, v17, v6 :: v_dual_and_b32 v7, 0xffff0000, v7// 00000098DF48: C8E40D11 06060EFF FFFF0000
	v_mul_f32_e32 v41, v36, v31                                // 00000098DF54: 10523F24
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000098DF58: BF870112
	.long 0x7e423986                                           // 00000098DF5C: 7E423986
	v_fma_f32 v45, -v26, v41, v36                              // 00000098DF60: D613002D 2492531A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000098DF68: BF870091
	v_fmac_f32_e32 v41, v45, v31                               // 00000098DF6C: 56523F2D
	v_fma_f32 v26, -v26, v41, v36                              // 00000098DF70: D613001A 2492531A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000098DF78: BF870131
	v_div_fmas_f32 v20, v26, v31, v41                          // 00000098DF7C: D6370014 04A63F1A
	s_mov_b32 vcc_lo, s8                                       // 00000098DF84: BEEA0008
	v_div_fmas_f32 v17, v24, v32, v43                          // 00000098DF88: D6370011 04AE4118
	v_div_fixup_f32 v19, v20, v22, v19                         // 00000098DF90: D6270013 044E2D14
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000098DF98: BF8701A2
	v_div_fixup_f32 v15, v17, v23, v15                         // 00000098DF9C: D627000F 043E2F11
	v_and_b32_e32 v17, 1, v30                                  // 00000098DFA4: 36223C81
	v_mul_f32_e32 v19, v19, v21                                // 00000098DFA8: 10262B13
	v_and_b32_e32 v21, 1, v33                                  // 00000098DFAC: 362A4281
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000098DFB0: BF870214
	v_mul_f32_e32 v7, v15, v7                                  // 00000098DFB4: 100E0F0F
	v_add3_u32 v14, v14, v17, 0x7fff                           // 00000098DFB8: D655000E 03FE230E 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000098DFC4: BF870214
	v_bfe_u32 v20, v19, 16, 1                                  // 00000098DFC8: D6100014 02052113
	v_add3_u32 v6, v6, v21, 0x7fff                             // 00000098DFD0: D6550006 03FE2B06 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000098DFDC: BF870214
	v_bfe_u32 v17, v7, 16, 1                                   // 00000098DFE0: D6100011 02052107
	v_and_b32_e32 v14, 0xffff0000, v14                         // 00000098DFE8: 361C1CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000098DFF0: BF870214
	v_add3_u32 v15, v19, v20, 0x7fff                           // 00000098DFF4: D655000F 03FE2913 00007FFF
	v_and_b32_e32 v6, 0xffff0000, v6                           // 00000098E000: 360C0CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000098E008: BF870194
	v_add3_u32 v7, v7, v17, 0x7fff                             // 00000098E00C: D6550007 03FE2307 00007FFF
	v_and_b32_e32 v19, 0xffff0000, v15                         // 00000098E018: 36261EFF FFFF0000
	s_waitcnt vmcnt(1)                                         // 00000098E020: BF8907F7
	v_fma_mix_f32 v15, v18, v14, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 00000098E024: CC20080F 8A021D12
	v_fma_mix_f32 v17, v18, v6, neg(0) op_sel_hi:[1,0,0]       // 00000098E02C: CC200011 8A020D12
	s_waitcnt vmcnt(0)                                         // 00000098E034: BF8903F7
	v_fma_mix_f32 v14, v16, v19, neg(0) op_sel_hi:[1,0,0]      // 00000098E038: CC20000E 8A022710
	v_and_b32_e32 v16, 0xffff0000, v7                          // 00000098E040: 36200EFF FFFF0000
	s_and_not1_b32 vcc_lo, exec_lo, s6                         // 00000098E048: 916A067E
	s_cbranch_vccnz 65123                                      // 00000098E04C: BFA4FE63 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1dc>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000098E050: BF870093
	.long 0xd73c0004                                           // 00000098E054: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 00000098E058: 02020881
	.long 0xd7006a04                                           // 00000098E05C: D7006A04
	v_cndmask_b32_e32 v1, s38, v4, vcc_lo                      // 00000098E060: 02020826
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000098E064: BF870111
	v_add_co_ci_u32_e64 v5, null, s39, v5, vcc_lo              // 00000098E068: D5207C05 01AA0A27
	.long 0xd7006a04                                           // 00000098E070: D7006A04
	v_cndmask_b32_e32 v1, v4, v2, vcc_lo                       // 00000098E074: 02020504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000098E078: BF8700A1
	v_add_co_ci_u32_e64 v5, null, v5, v3, vcc_lo               // 00000098E07C: D5207C05 01AA0705
	.long 0xd7006a06                                           // 00000098E084: D7006A06
	v_cndmask_b32_e32 v1, s26, v2, vcc_lo                      // 00000098E088: 0202041A
	v_add_co_ci_u32_e64 v7, null, s27, v3, vcc_lo              // 00000098E08C: D5207C07 01AA061B
	global_load_b64 v[4:5], v[4:5], off                        // 00000098E094: DC560000 047C0004
	s_clause 0x1                                               // 00000098E09C: BF850001
	global_load_b32 v16, v[6:7], off                           // 00000098E0A0: DC520000 107C0006
	global_load_d16_b16 v6, v[6:7], off offset:4               // 00000098E0A8: DC820004 067C0006
	s_waitcnt vmcnt(2)                                         // 00000098E0B0: BF890BF7
	.long 0x7e0e3904                                           // 00000098E0B4: 7E0E3904
	v_and_b32_e32 v4, 0xffff0000, v4                           // 00000098E0B8: 360808FF FFFF0000
	v_lshlrev_b32_e32 v14, 16, v5                              // 00000098E0C0: 301C0A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000098E0C4: BF8701A3
	v_lshlrev_b32_e32 v7, 16, v7                               // 00000098E0C8: 300E0E90
	s_waitcnt vmcnt(1)                                         // 00000098E0CC: BF8907F7
	v_fma_mix_f32 v15, v16, v4, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 00000098E0D0: CC20080F 8A020910
	s_waitcnt vmcnt(0)                                         // 00000098E0D8: BF8903F7
	v_fma_mix_f32 v14, v6, v14, neg(0) op_sel_hi:[1,0,0]       // 00000098E0DC: CC20000E 8A021D06
	v_fma_mix_f32 v17, v16, v7, neg(0) op_sel_hi:[1,0,0]       // 00000098E0E4: CC200011 8A020F10
	v_and_b32_e32 v16, 0xffff0000, v5                          // 00000098E0EC: 36200AFF FFFF0000
	s_branch 65081                                             // 00000098E0F4: BFA0FE39 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1dc>
	s_or_b32 exec_lo, exec_lo, s33                             // 00000098E0F8: 8C7E217E
	s_bfe_i32 s28, s29, 0x1001c                                // 00000098E0FC: 939CFF1D 0001001C
	s_lshr_b32 s3, s11, 28                                     // 00000098E104: 85039C0B
	s_lshr_b64 s[0:1], s[28:29], 29                            // 00000098E108: 85809D1C
	s_add_i32 s3, s50, s3                                      // 00000098E10C: 81030332
	s_add_i32 s0, s0, 7                                        // 00000098E110: 81008700
	s_lshl_b32 s1, s29, 3                                      // 00000098E114: 8401831D
	s_ashr_i32 s0, s0, 3                                       // 00000098E118: 86008300
	s_lshl_b32 s4, s31, 3                                      // 00000098E11C: 8404831F
	.long 0xd72c0001                                           // 00000098E120: D72C0001
	v_cndmask_b32_e32 v1, s0, v11, vcc_lo                      // 00000098E124: 02021600
	v_lshlrev_b32_e32 v13, 2, v12                              // 00000098E128: 301A1882
	s_waitcnt lgkmcnt(0)                                       // 00000098E12C: BF89FC07
	s_barrier                                                  // 00000098E130: BFBD0000
	buffer_gl0_inv                                             // 00000098E134: E0AC0000 00000000
	v_add_nc_u32_e32 v2, s0, v1                                // 00000098E13C: 4A040200
	s_ashr_i32 s0, s3, 4                                       // 00000098E140: 86008403
	s_ashr_i32 s3, s4, 31                                      // 00000098E144: 86039F04
	s_mul_hi_i32 s5, s10, s0                                   // 00000098E148: 9705000A
	s_mul_i32 s0, s10, s0                                      // 00000098E14C: 9600000A
	v_min_i32_e32 v14, s1, v2                                  // 00000098E150: 221C0401
	s_add_u32 s0, s0, s4                                       // 00000098E154: 80000400
	s_addc_u32 s1, s5, s3                                      // 00000098E158: 82010305
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000098E15C: BF870099
	s_lshl_b64 s[4:5], s[0:1], 10                              // 00000098E160: 84848A00
	v_cmp_lt_i32_e32 vcc_lo, v1, v14                           // 00000098E164: 7C821D01
	s_add_u32 s1, s24, s4                                      // 00000098E168: 80010418
	s_addc_u32 s3, s25, s5                                     // 00000098E16C: 82030519
	s_and_saveexec_b32 s4, vcc_lo                              // 00000098E170: BE84206A
	s_cbranch_execz 93                                         // 00000098E174: BFA5005D <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0xaec>
	.long 0xd7010002                                           // 00000098E178: D7010002
	v_cndmask_b32_e32 v0, v12, v129, vcc_lo                    // 00000098E17C: 0201030C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000098E180: BF870121
	v_cndmask_b32_e64 v3, v2, 31, s0                           // 00000098E184: D5010003 00013F02
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000098E18C: 3404029F
	.long 0xd44c0000                                           // 00000098E190: D44C0000
	v_cndmask_b32_e32 v1, 31, v3, vcc_lo                       // 00000098E194: 0202069F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000098E198: BF870091
	v_cndmask_b32_e64 v5, 0xe1, 1, s0                          // 00000098E19C: D5010005 000102FF 000000E1
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v7, v5, v3       // 00000098E1A8: CA200080 04060705
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000098E1B0: BF870114
	.long 0xd73c0005                                           // 00000098E1B4: D73C0005
	v_cndmask_b32_e32 v1, 10, v1, vcc_lo                       // 00000098E1B8: 0202028A
	.long 0xd73c0002                                           // 00000098E1BC: D73C0002
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 00000098E1C0: 02020682
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000098E1C4: BF870223
	v_lshlrev_b32_e32 v4, 24, v7                               // 00000098E1C8: 30080E98
	v_bfe_i32 v8, v7, 7, 1                                     // 00000098E1CC: D6110008 02050F07
	.long 0xd7000009                                           // 00000098E1D4: D7000009
	v_cndmask_b32_e32 v1, s1, v5, vcc_lo                       // 00000098E1D8: 02020A01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000098E1DC: BF870211
	v_add_co_ci_u32_e64 v10, null, s3, v6, s0                  // 00000098E1E0: D5207C0A 00020C03
	v_ashrrev_i32_e32 v4, 22, v4                               // 00000098E1E8: 34080896
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000098E1EC: BF870093
	.long 0xd7000005                                           // 00000098E1F0: D7000005
	v_cndmask_b32_e32 v1, v9, v2, vcc_lo                       // 00000098E1F4: 02020509
	v_add_co_ci_u32_e64 v6, null, v10, v3, s0                  // 00000098E1F8: D5207C06 0002070A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000098E200: BF870093
	.long 0xd7000007                                           // 00000098E204: D7000007
	v_cndmask_b32_e32 v1, v9, v4, vcc_lo                       // 00000098E208: 02020909
	v_add_co_ci_u32_e64 v8, null, v10, v8, s0                  // 00000098E20C: D5207C08 0002110A
	.long 0xd7000009                                           // 00000098E214: D7000009
	v_cndmask_b32_e32 v1, v9, v13, vcc_lo                      // 00000098E218: 02021B09
	s_delay_alu instid0(VALU_DEP_1)                            // 00000098E21C: BF870001
	v_add_co_ci_u32_e64 v10, null, 0, v10, s0                  // 00000098E220: D5207C0A 00021480
	s_clause 0x17                                              // 00000098E228: BF850017
	global_load_b32 v4, v[5:6], off                            // 00000098E22C: DC520000 047C0005
	global_load_b32 v2, v[5:6], off offset:128                 // 00000098E234: DC520080 027C0005
	global_load_b32 v65, v[5:6], off offset:256                // 00000098E23C: DC520100 417C0005
	global_load_b32 v62, v[5:6], off offset:384                // 00000098E244: DC520180 3E7C0005
	global_load_b32 v59, v[5:6], off offset:512                // 00000098E24C: DC520200 3B7C0005
	global_load_b32 v56, v[5:6], off offset:640                // 00000098E254: DC520280 387C0005
	global_load_b32 v53, v[5:6], off offset:768                // 00000098E25C: DC520300 357C0005
	global_load_b32 v35, v[5:6], off offset:896                // 00000098E264: DC520380 237C0005
	global_load_b32 v6, v[7:8], off                            // 00000098E26C: DC520000 067C0007
	global_load_b32 v3, v[7:8], off offset:128                 // 00000098E274: DC520080 037C0007
	global_load_b32 v66, v[7:8], off offset:256                // 00000098E27C: DC520100 427C0007
	global_load_b32 v63, v[7:8], off offset:384                // 00000098E284: DC520180 3F7C0007
	global_load_b32 v60, v[7:8], off offset:512                // 00000098E28C: DC520200 3C7C0007
	global_load_b32 v57, v[7:8], off offset:640                // 00000098E294: DC520280 397C0007
	global_load_b32 v55, v[7:8], off offset:768                // 00000098E29C: DC520300 377C0007
	global_load_b32 v36, v[7:8], off offset:896                // 00000098E2A4: DC520380 247C0007
	global_load_b32 v5, v[9:10], off                           // 00000098E2AC: DC520000 057C0009
	global_load_b32 v67, v[9:10], off offset:128               // 00000098E2B4: DC520080 437C0009
	global_load_b32 v64, v[9:10], off offset:256               // 00000098E2BC: DC520100 407C0009
	global_load_b32 v61, v[9:10], off offset:384               // 00000098E2C4: DC520180 3D7C0009
	global_load_b32 v58, v[9:10], off offset:512               // 00000098E2CC: DC520200 3A7C0009
	global_load_b32 v54, v[9:10], off offset:640               // 00000098E2D4: DC520280 367C0009
	global_load_b32 v52, v[9:10], off offset:768               // 00000098E2DC: DC520300 347C0009
	global_load_b32 v34, v[9:10], off offset:896               // 00000098E2E4: DC520380 227C0009
	s_or_b32 exec_lo, exec_lo, s4                              // 00000098E2EC: 8C7E047E
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v18, 0             // 00000098E2F0: CA100080 0F120080
	v_dual_mov_b32 v17, 0 :: v_dual_mov_b32 v20, 0             // 00000098E2F8: CA100080 11140080
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v22, 0             // 00000098E300: CA100080 15160080
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v25, 0             // 00000098E308: CA100080 18180080
	v_dual_mov_b32 v16, 0 :: v_dual_mov_b32 v19, 0             // 00000098E310: CA100080 10120080
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v23, 0             // 00000098E318: CA100080 1A160080
	v_dual_mov_b32 v28, 0 :: v_dual_mov_b32 v29, 0             // 00000098E320: CA100080 1C1C0080
	v_dual_mov_b32 v27, 0 :: v_dual_mov_b32 v30, 0             // 00000098E328: CA100080 1B1E0080
	s_ashr_i32 s11, s10, 31                                    // 00000098E330: 860B9F0A
	s_and_saveexec_b32 s0, vcc_lo                              // 00000098E334: BE80206A
	s_cbranch_execz 1008                                       // 00000098E338: BFA503F0 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1afc>
	v_dual_mov_b32 v18, 0 :: v_dual_add_nc_u32 v7, -1, v0      // 00000098E33C: CA200080 120600C1
	v_dual_mov_b32 v15, 0 :: v_dual_lshlrev_b32 v32, 2, v12    // 00000098E344: CA220080 0F201882
	v_dual_mov_b32 v20, 0 :: v_dual_and_b32 v31, 16, v0        // 00000098E34C: CA240080 141E0090
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000098E354: BF8701B3
	v_dual_mov_b32 v24, 0 :: v_dual_and_b32 v7, 31, v7         // 00000098E358: CA240080 18060E9F
	v_dual_mov_b32 v17, 0 :: v_dual_mov_b32 v22, 0             // 00000098E360: CA100080 11160080
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v16, 0             // 00000098E368: CA100080 15100080
	v_dual_mov_b32 v26, 0 :: v_dual_lshlrev_b32 v33, 2, v7     // 00000098E370: CA220080 1A200E82
	v_dual_mov_b32 v25, 0 :: v_dual_mov_b32 v28, 0             // 00000098E378: CA100080 191C0080
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v30, 0             // 00000098E380: CA100080 131E0080
	v_mov_b32_e32 v23, 0                                       // 00000098E388: 7E2E0280
	v_mov_b32_e32 v29, 0                                       // 00000098E38C: 7E3A0280
	v_mov_b32_e32 v27, 0                                       // 00000098E390: 7E360280
	s_mov_b32 s4, 0                                            // 00000098E394: BE840080
	s_movk_i32 s5, 0x1eee                                      // 00000098E398: B0051EEE
	s_branch 924                                               // 00000098E39C: BFA0039C <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1a10>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000098E3A0: 8C7E067E
	s_waitcnt vmcnt(15)                                        // 00000098E3A4: BF893FF7
	v_alignbit_b32 v4, v4, v6, 16                              // 00000098E3A8: D6160004 02420D04
	s_waitcnt vmcnt(7)                                         // 00000098E3B0: BF891FF7
	v_bfe_u32 v68, v5, 12, 16                                  // 00000098E3B4: D6100044 02411905
	v_bfe_u32 v69, v5, 8, 16                                   // 00000098E3BC: D6100045 02411105
	v_bfe_u32 v70, v5, 4, 16                                   // 00000098E3C4: D6100046 02410905
	v_lshl_or_b32 v1, v1, 5, v31                               // 00000098E3CC: D6560001 047D0B01
	v_and_b32_e32 v7, 0xffff, v4                               // 00000098E3D4: 360E08FF 0000FFFF
	v_bfe_u32 v74, v4, 4, 16                                   // 00000098E3DC: D610004A 02410904
	.long 0xd72c0044                                           // 00000098E3E4: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 00000098E3E8: 020288FF 83DCD12D
	.long 0xd72c0045                                           // 00000098E3F0: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 00000098E3F4: 02028AFF 83DCD12D
	v_bfe_u32 v6, v4, 12, 16                                   // 00000098E3FC: D6100006 02411904
	.long 0xd72c004c                                           // 00000098E404: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v7, vcc_lo               // 00000098E408: 02020EFF 83DCD12D
	.long 0xd72c004a                                           // 00000098E410: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 00000098E414: 020294FF 83DCD12D
	v_alignbit_b32 v72, v2, v3, 16                             // 00000098E41C: D6160048 02420702
	.long 0xd72c0046                                           // 00000098E424: D72C0046
	v_cndmask_b32_e32 v1, 0x83dcd12d, v70, vcc_lo              // 00000098E428: 02028CFF 83DCD12D
	.long 0xd72c0049                                           // 00000098E430: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v6, vcc_lo               // 00000098E434: 02020CFF 83DCD12D
	v_sad_u8 v68, v68, 0, 0x6400                               // 00000098E43C: D6220044 03FD0144 00006400
	v_sad_u8 v69, v69, 0, 0x6400                               // 00000098E448: D6220045 03FD0145 00006400
	s_waitcnt vmcnt(6)                                         // 00000098E454: BF891BF7
	v_bfe_u32 v77, v67, 4, 16                                  // 00000098E458: D610004D 02410943
	v_sad_u8 v76, v76, 0, 0x6400                               // 00000098E460: D622004C 03FD014C 00006400
	v_sad_u8 v74, v74, 0, 0x6400                               // 00000098E46C: D622004A 03FD014A 00006400
	v_and_b32_e32 v68, 0xffff, v68                             // 00000098E478: 368888FF 0000FFFF
	v_sad_u8 v70, v70, 0, 0x6400                               // 00000098E480: D6220046 03FD0146 00006400
	v_sad_u8 v73, v73, 0, 0x6400                               // 00000098E48C: D6220049 03FD0149 00006400
	v_lshlrev_b32_e32 v76, 16, v76                             // 00000098E498: 30989890
	v_alignbit_b32 v65, v65, v66, 16                           // 00000098E49C: D6160041 02428541
	v_lshl_or_b32 v68, v69, 16, v68                            // 00000098E4A4: D6560044 05112145
	v_alignbit_b32 v62, v62, v63, 16                           // 00000098E4AC: D616003E 02427F3E
	v_alignbit_b32 v59, v59, v60, 16                           // 00000098E4B4: D616003B 0242793B
	v_and_or_b32 v74, 0xffff, v74, v76                         // 00000098E4BC: D657004A 053294FF 0000FFFF
	v_bfe_u32 v76, v67, 8, 16                                  // 00000098E4C8: D610004C 02411143
	v_pk_fma_f16 v68, v68, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000098E4D0: CC0E0044 0BFC0B44 0000C931
	v_alignbit_b32 v56, v56, v57, 16                           // 00000098E4DC: D6160038 02427338
	v_alignbit_b32 v53, v53, v55, 16                           // 00000098E4E4: D6160035 02426F35
	v_pk_fma_f16 v69, v74, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000098E4EC: CC0E0045 0BFC0B4A 0000C931
	v_and_b32_e32 v71, 0xffff, v5                              // 00000098E4F8: 368E0AFF 0000FFFF
	v_bfe_u32 v5, v4, 8, 16                                    // 00000098E500: D6100005 02411104
	v_bfe_u32 v74, v72, 12, 16                                 // 00000098E508: D610004A 02411948
	.long 0xd72c004c                                           // 00000098E510: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 00000098E514: 020298FF 83DCD12D
	v_bfe_u32 v55, v53, 12, 16                                 // 00000098E51C: D6100037 02411935
	v_alignbit_b32 v35, v35, v36, 16                           // 00000098E524: D6160023 02424923
	.long 0xd72c004b                                           // 00000098E52C: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v5, vcc_lo               // 00000098E530: 02020AFF 83DCD12D
	ds_load_b128 v[5:8], v1                                    // 00000098E538: DBFC0000 05000001
	ds_load_b128 v[1:4], v1 offset:5120                        // 00000098E540: DBFC1400 01000001
	v_and_b32_e32 v73, 0xffff, v73                             // 00000098E548: 369292FF 0000FFFF
	.long 0xd72c004a                                           // 00000098E550: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 00000098E554: 020294FF 83DCD12D
	.long 0xd72c0037                                           // 00000098E55C: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 00000098E560: 02026EFF 83DCD12D
	v_sad_u8 v76, v76, 0, 0x6400                               // 00000098E568: D622004C 03FD014C 00006400
	v_cmp_eq_u32_e32 vcc_lo, v9, v14                           // 00000098E574: 7C941D09
	v_sad_u8 v75, v75, 0, 0x6400                               // 00000098E578: D622004B 03FD014B 00006400
	v_sad_u8 v74, v74, 0, 0x6400                               // 00000098E584: D622004A 03FD014A 00006400
	v_sad_u8 v55, v55, 0, 0x6400                               // 00000098E590: D6220037 03FD0137 00006400
	s_delay_alu instid0(VALU_DEP_3)                            // 00000098E59C: BF870003
	v_lshl_or_b32 v73, v75, 16, v73                            // 00000098E5A0: D6560049 0525214B
	v_bfe_u32 v75, v72, 8, 16                                  // 00000098E5A8: D610004B 02411148
	s_or_b32 s4, vcc_lo, s4                                    // 00000098E5B0: 8C04046A
	v_and_b32_e32 v74, 0xffff, v74                             // 00000098E5B4: 369494FF 0000FFFF
	v_and_b32_e32 v55, 0xffff, v55                             // 00000098E5BC: 366E6EFF 0000FFFF
	v_pk_fma_f16 v73, v73, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000098E5C4: CC0E0049 0BFC0B49 0000C931
	.long 0xd72c004b                                           // 00000098E5D0: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 00000098E5D4: 020296FF 83DCD12D
	s_waitcnt lgkmcnt(1)                                       // 00000098E5DC: BF89FC17
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000098E5E0: BF870242
	v_dot2acc_f32_f16 v30, v73, v5                             // 00000098E5E4: 043C0B49
	s_waitcnt lgkmcnt(0)                                       // 00000098E5E8: BF89FC07
	v_dot2acc_f32_f16 v27, v73, v1                             // 00000098E5EC: 04360349
	v_bfe_u32 v73, v67, 12, 16                                 // 00000098E5F0: D6100049 02411943
	v_sad_u8 v75, v75, 0, 0x6400                               // 00000098E5F8: D622004B 03FD014B 00006400
	v_dot2acc_f32_f16 v30, v69, v6                             // 00000098E604: 043C0D45
	.long 0xd72c0047                                           // 00000098E608: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 00000098E60C: 02028EFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 00000098E614: BF870254
	.long 0xd72c0049                                           // 00000098E618: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 00000098E61C: 020292FF 83DCD12D
	v_dot2acc_f32_f16 v27, v69, v2                             // 00000098E624: 04360545
	v_lshl_or_b32 v74, v75, 16, v74                            // 00000098E628: D656004A 0529214B
	v_dot2acc_f32_f16 v30, v68, v7                             // 00000098E630: 043C0F44
	.long 0xd72c004b                                           // 00000098E634: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 00000098E638: 02029AFF 83DCD12D
	v_dot2acc_f32_f16 v27, v68, v3                             // 00000098E640: 04360744
	v_sad_u8 v71, v71, 0, 0x6400                               // 00000098E644: D6220047 03FD0147 00006400
	v_sad_u8 v73, v73, 0, 0x6400                               // 00000098E650: D6220049 03FD0149 00006400
	v_bfe_u32 v68, v65, 4, 16                                  // 00000098E65C: D6100044 02410941
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000098E664: BF870113
	v_lshlrev_b32_e32 v71, 16, v71                             // 00000098E668: 308E8E90
	.long 0xd72c0044                                           // 00000098E66C: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 00000098E670: 020288FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000098E678: BF8701B2
	v_and_or_b32 v70, 0xffff, v70, v71                         // 00000098E67C: D6570046 051E8CFF 0000FFFF
	v_and_b32_e32 v71, 0xffff, v72                             // 00000098E688: 368E90FF 0000FFFF
	v_bfe_u32 v72, v72, 4, 16                                  // 00000098E690: D6100048 02410948
	v_pk_fma_f16 v70, v70, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000098E698: CC0E0046 0BFC0B46 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000098E6A4: BF870193
	.long 0xd72c0047                                           // 00000098E6A8: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 00000098E6AC: 02028EFF 83DCD12D
	.long 0xd72c0048                                           // 00000098E6B4: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 00000098E6B8: 020290FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3)                            // 00000098E6C0: BF870003
	v_dot2acc_f32_f16 v27, v70, v4                             // 00000098E6C4: 04360946
	v_dot2acc_f32_f16 v30, v70, v8                             // 00000098E6C8: 043C1146
	s_waitcnt vmcnt(5)                                         // 00000098E6CC: BF8917F7
	v_bfe_u32 v70, v64, 8, 16                                  // 00000098E6D0: D6100046 02411140
	v_sad_u8 v71, v71, 0, 0x6400                               // 00000098E6D8: D6220047 03FD0147 00006400
	v_sad_u8 v72, v72, 0, 0x6400                               // 00000098E6E4: D6220048 03FD0148 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000098E6F0: BF870193
	.long 0xd72c0046                                           // 00000098E6F4: D72C0046
	v_cndmask_b32_e32 v1, 0x83dcd12d, v70, vcc_lo              // 00000098E6F8: 02028CFF 83DCD12D
	v_lshlrev_b32_e32 v71, 16, v71                             // 00000098E700: 308E8E90
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000098E704: BF870241
	v_and_or_b32 v69, 0xffff, v72, v71                         // 00000098E708: D6570045 051E90FF 0000FFFF
	v_pk_fma_f16 v71, v74, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000098E714: CC0E0047 0BFC0B4A 0000C931
	v_and_b32_e32 v67, 0xffff, v67                             // 00000098E720: 368686FF 0000FFFF
	v_sad_u8 v70, v70, 0, 0x6400                               // 00000098E728: D6220046 03FD0146 00006400
	v_pk_fma_f16 v69, v69, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000098E734: CC0E0045 0BFC0B45 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000098E740: BF870214
	v_dot2acc_f32_f16 v28, v71, v1                             // 00000098E744: 04380347
	.long 0xd72c0043                                           // 00000098E748: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 00000098E74C: 020286FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000098E754: BF870122
	v_dual_dot2acc_f32_f16 v29, v71, v5 :: v_dual_dot2acc_f32_f16 v28, v69, v2// 00000098E758: CB180B47 1D1C0545
	v_and_b32_e32 v73, 0xffff, v73                             // 00000098E760: 369292FF 0000FFFF
	v_dot2acc_f32_f16 v29, v69, v6                             // 00000098E768: 043A0D45
	v_bfe_u32 v69, v64, 12, 16                                 // 00000098E76C: D6100045 02411940
	v_sad_u8 v67, v67, 0, 0x6400                               // 00000098E774: D6220043 03FD0143 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000098E780: BF870224
	v_lshl_or_b32 v72, v76, 16, v73                            // 00000098E784: D6560048 0525214C
	v_sad_u8 v73, v75, 0, 0x6400                               // 00000098E78C: D6220049 03FD014B 00006400
	.long 0xd72c0045                                           // 00000098E798: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 00000098E79C: 02028AFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000098E7A4: BF870133
	v_pk_fma_f16 v71, v72, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000098E7A8: CC0E0047 0BFC0B48 0000C931
	s_waitcnt vmcnt(4)                                         // 00000098E7B4: BF8913F7
	v_bfe_u32 v72, v61, 4, 16                                  // 00000098E7B8: D6100048 0241093D
	v_dot2acc_f32_f16 v28, v71, v3                             // 00000098E7C0: 04380747
	v_lshlrev_b32_e32 v67, 16, v67                             // 00000098E7C4: 30868690
	v_dot2acc_f32_f16 v29, v71, v7                             // 00000098E7C8: 043A0F47
	v_and_b32_e32 v71, 0xffff, v64                             // 00000098E7CC: 368E80FF 0000FFFF
	v_bfe_u32 v64, v64, 4, 16                                  // 00000098E7D4: D6100040 02410940
	v_sad_u8 v69, v69, 0, 0x6400                               // 00000098E7DC: D6220045 03FD0145 00006400
	v_and_or_b32 v67, 0xffff, v73, v67                         // 00000098E7E8: D6570043 050E92FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000098E7F4: BF870214
	.long 0xd72c0047                                           // 00000098E7F8: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 00000098E7FC: 02028EFF 83DCD12D
	.long 0xd72c0040                                           // 00000098E804: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 00000098E808: 020280FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000098E810: BF870214
	v_and_b32_e32 v69, 0xffff, v69                             // 00000098E814: 368A8AFF 0000FFFF
	v_pk_fma_f16 v66, v67, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000098E81C: CC0E0042 0BFC0B43 0000C931
	v_bfe_u32 v67, v65, 12, 16                                 // 00000098E828: D6100043 02411941
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000098E830: BF870193
	v_lshl_or_b32 v63, v70, 16, v69                            // 00000098E834: D656003F 05152146
	v_dot2acc_f32_f16 v29, v66, v8                             // 00000098E83C: 043A1142
	s_delay_alu instid0(VALU_DEP_3)                            // 00000098E840: BF870003
	.long 0xd72c0043                                           // 00000098E844: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 00000098E848: 020286FF 83DCD12D
	v_dot2acc_f32_f16 v28, v66, v4                             // 00000098E850: 04380942
	v_bfe_u32 v66, v65, 8, 16                                  // 00000098E854: D6100042 02411141
	v_and_b32_e32 v65, 0xffff, v65                             // 00000098E85C: 368282FF 0000FFFF
	v_sad_u8 v64, v64, 0, 0x6400                               // 00000098E864: D6220040 03FD0140 00006400
	v_bfe_u32 v69, v62, 8, 16                                  // 00000098E870: D6100045 0241113E
	v_bfe_u32 v70, v61, 12, 16                                 // 00000098E878: D6100046 0241193D
	.long 0xd72c0042                                           // 00000098E880: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 00000098E884: 020284FF 83DCD12D
	.long 0xd72c0041                                           // 00000098E88C: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 00000098E890: 020282FF 83DCD12D
	v_sad_u8 v67, v67, 0, 0x6400                               // 00000098E898: D6220043 03FD0143 00006400
	.long 0xd72c0045                                           // 00000098E8A4: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 00000098E8A8: 02028AFF 83DCD12D
	.long 0xd72c0046                                           // 00000098E8B0: D72C0046
	v_cndmask_b32_e32 v1, 0x83dcd12d, v70, vcc_lo              // 00000098E8B4: 02028CFF 83DCD12D
	v_pk_fma_f16 v63, v63, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000098E8BC: CC0E003F 0BFC0B3F 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 00000098E8C8: BF870254
	v_and_b32_e32 v67, 0xffff, v67                             // 00000098E8CC: 368686FF 0000FFFF
	v_sad_u8 v66, v66, 0, 0x6400                               // 00000098E8D4: D6220042 03FD0142 00006400
	v_sad_u8 v65, v65, 0, 0x6400                               // 00000098E8E0: D6220041 03FD0141 00006400
	v_sad_u8 v69, v69, 0, 0x6400                               // 00000098E8EC: D6220045 03FD0145 00006400
	v_sad_u8 v70, v70, 0, 0x6400                               // 00000098E8F8: D6220046 03FD0146 00006400
	v_lshl_or_b32 v66, v66, 16, v67                            // 00000098E904: D6560042 050D2142
	v_sad_u8 v67, v68, 0, 0x6400                               // 00000098E90C: D6220043 03FD0144 00006400
	v_sad_u8 v68, v71, 0, 0x6400                               // 00000098E918: D6220044 03FD0147 00006400
	v_lshlrev_b32_e32 v65, 16, v65                             // 00000098E924: 30828290
	v_bfe_u32 v71, v61, 8, 16                                  // 00000098E928: D6100047 0241113D
	v_pk_fma_f16 v66, v66, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000098E930: CC0E0042 0BFC0B42 0000C931
	v_and_b32_e32 v61, 0xffff, v61                             // 00000098E93C: 367A7AFF 0000FFFF
	v_lshlrev_b32_e32 v68, 16, v68                             // 00000098E944: 30888890
	v_and_or_b32 v65, 0xffff, v67, v65                         // 00000098E948: D6570041 050686FF 0000FFFF
	v_bfe_u32 v67, v62, 12, 16                                 // 00000098E954: D6100043 0241193E
	v_dot2acc_f32_f16 v23, v66, v5                             // 00000098E95C: 042E0B42
	v_dot2acc_f32_f16 v19, v66, v1                             // 00000098E960: 04260342
	v_and_or_b32 v64, 0xffff, v64, v68                         // 00000098E964: D6570040 051280FF 0000FFFF
	v_and_b32_e32 v68, 0xffff, v62                             // 00000098E970: 36887CFF 0000FFFF
	.long 0xd72c0043                                           // 00000098E978: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 00000098E97C: 020286FF 83DCD12D
	v_bfe_u32 v62, v62, 4, 16                                  // 00000098E984: D610003E 0241093E
	.long 0xd72c0047                                           // 00000098E98C: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 00000098E990: 02028EFF 83DCD12D
	.long 0xd72c003d                                           // 00000098E998: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 00000098E99C: 02027AFF 83DCD12D
	.long 0xd72c0044                                           // 00000098E9A4: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 00000098E9A8: 020288FF 83DCD12D
	v_pk_fma_f16 v65, v65, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000098E9B0: CC0E0041 0BFC0B41 0000C931
	.long 0xd72c003e                                           // 00000098E9BC: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 00000098E9C0: 02027CFF 83DCD12D
	v_pk_fma_f16 v64, v64, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000098E9C8: CC0E0040 0BFC0B40 0000C931
	v_sad_u8 v67, v67, 0, 0x6400                               // 00000098E9D4: D6220043 03FD0143 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000098E9E0: BF870234
	v_dot2acc_f32_f16 v23, v65, v6                             // 00000098E9E4: 042E0D41
	v_sad_u8 v61, v61, 0, 0x6400                               // 00000098E9E8: D622003D 03FD013D 00006400
	v_sad_u8 v68, v68, 0, 0x6400                               // 00000098E9F4: D6220044 03FD0144 00006400
	v_and_b32_e32 v67, 0xffff, v67                             // 00000098EA00: 368686FF 0000FFFF
	v_sad_u8 v62, v62, 0, 0x6400                               // 00000098EA08: D622003E 03FD013E 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000098EA14: BF870214
	v_lshlrev_b32_e32 v61, 16, v61                             // 00000098EA18: 307A7A90
	v_lshlrev_b32_e32 v68, 16, v68                             // 00000098EA1C: 30888890
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000098EA20: BF870234
	v_lshl_or_b32 v67, v69, 16, v67                            // 00000098EA24: D6560043 050D2145
	v_and_b32_e32 v69, 0xffff, v70                             // 00000098EA2C: 368A8CFF 0000FFFF
	v_sad_u8 v70, v71, 0, 0x6400                               // 00000098EA34: D6220046 03FD0147 00006400
	v_and_or_b32 v62, 0xffff, v62, v68                         // 00000098EA40: D657003E 05127CFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000098EA4C: BF870224
	v_pk_fma_f16 v66, v67, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000098EA50: CC0E0042 0BFC0B43 0000C931
	.long 0xd72c0044                                           // 00000098EA5C: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 00000098EA60: 020290FF 83DCD12D
	v_lshl_or_b32 v67, v70, 16, v69                            // 00000098EA68: D6560043 05152146
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000098EA70: BF870214
	v_pk_fma_f16 v62, v62, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000098EA74: CC0E003E 0BFC0B3E 0000C931
	v_dot2acc_f32_f16 v26, v66, v5                             // 00000098EA80: 04340B42
	v_dot2acc_f32_f16 v25, v66, v1                             // 00000098EA84: 04320342
	s_waitcnt vmcnt(2)                                         // 00000098EA88: BF890BF7
	v_bfe_u32 v66, v54, 4, 16                                  // 00000098EA8C: D6100042 02410936
	v_sad_u8 v68, v68, 0, 0x6400                               // 00000098EA94: D6220044 03FD0144 00006400
	v_dot2acc_f32_f16 v26, v62, v6                             // 00000098EAA0: 04340D3E
	v_dual_dot2acc_f32_f16 v25, v62, v2 :: v_dual_and_b32 v62, 0xffff, v59// 00000098EAA4: CB24053E 193E76FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000098EAB0: BF870113
	v_and_or_b32 v61, 0xffff, v68, v61                         // 00000098EAB4: D657003D 04F688FF 0000FFFF
	.long 0xd72c003e                                           // 00000098EAC0: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 00000098EAC4: 02027CFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000098EACC: BF8701A2
	v_pk_fma_f16 v60, v61, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000098EAD0: CC0E003C 0BFC0B3D 0000C931
	v_bfe_u32 v61, v59, 12, 16                                 // 00000098EADC: D610003D 0241193B
	v_sad_u8 v62, v62, 0, 0x6400                               // 00000098EAE4: D622003E 03FD013E 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000098EAF0: BF870112
	.long 0xd72c003d                                           // 00000098EAF4: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 00000098EAF8: 02027AFF 83DCD12D
	v_lshlrev_b32_e32 v62, 16, v62                             // 00000098EB00: 307C7C90
	v_dot2acc_f32_f16 v19, v65, v2                             // 00000098EB04: 04260541
	v_pk_fma_f16 v65, v67, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000098EB08: CC0E0041 0BFC0B43 0000C931
	v_mov_b32_e32 v67, v50                                     // 00000098EB14: 7E860332
	v_sad_u8 v61, v61, 0, 0x6400                               // 00000098EB18: D622003D 03FD013D 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000098EB24: BF8701B3
	v_dot2acc_f32_f16 v26, v65, v7                             // 00000098EB28: 04340F41
	v_dot2acc_f32_f16 v25, v65, v3                             // 00000098EB2C: 04320741
	v_bfe_u32 v65, v58, 4, 16                                  // 00000098EB30: D6100041 0241093A
	v_dot2acc_f32_f16 v26, v60, v8                             // 00000098EB38: 0434113C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000098EB3C: BF8701C3
	v_dot2acc_f32_f16 v25, v60, v4                             // 00000098EB40: 0432093C
	v_bfe_u32 v60, v59, 8, 16                                  // 00000098EB44: D610003C 0241113B
	v_bfe_u32 v59, v59, 4, 16                                  // 00000098EB4C: D610003B 0241093B
	.long 0xd72c0041                                           // 00000098EB54: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 00000098EB58: 020282FF 83DCD12D
	.long 0xd72c003c                                           // 00000098EB60: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 00000098EB64: 020278FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000098EB6C: BF870193
	.long 0xd72c003b                                           // 00000098EB70: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 00000098EB74: 020276FF 83DCD12D
	v_sad_u8 v65, v65, 0, 0x6400                               // 00000098EB7C: D6220041 03FD0141 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000098EB88: BF870193
	v_sad_u8 v60, v60, 0, 0x6400                               // 00000098EB8C: D622003C 03FD013C 00006400
	v_sad_u8 v59, v59, 0, 0x6400                               // 00000098EB98: D622003B 03FD013B 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000098EBA4: BF870121
	v_and_or_b32 v59, 0xffff, v59, v62                         // 00000098EBA8: D657003B 04FA76FF 0000FFFF
	v_dual_dot2acc_f32_f16 v23, v63, v7 :: v_dual_and_b32 v62, 0xffff, v56// 00000098EBB4: CB240F3F 173E70FF 0000FFFF
	v_pk_fma_f16 v59, v59, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000098EBC0: CC0E003B 0BFC0B3B 0000C931
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000098EBCC: BF870192
	.long 0xd72c003e                                           // 00000098EBD0: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 00000098EBD4: 02027CFF 83DCD12D
	v_dot2acc_f32_f16 v23, v64, v8                             // 00000098EBDC: 042E1140
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000098EBE0: BF870132
	v_sad_u8 v62, v62, 0, 0x6400                               // 00000098EBE4: D622003E 03FD013E 00006400
	v_dot2acc_f32_f16 v19, v63, v3                             // 00000098EBF0: 0426073F
	v_bfe_u32 v63, v58, 12, 16                                 // 00000098EBF4: D610003F 0241193A
	v_dual_dot2acc_f32_f16 v19, v64, v4 :: v_dual_lshlrev_b32 v62, 16, v62// 00000098EBFC: CB220940 133E7C90
	v_bfe_u32 v64, v58, 8, 16                                  // 00000098EC04: D6100040 0241113A
	v_and_b32_e32 v58, 0xffff, v58                             // 00000098EC0C: 367474FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000098EC14: BF870194
	.long 0xd72c003f                                           // 00000098EC18: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 00000098EC1C: 02027EFF 83DCD12D
	.long 0xd72c0040                                           // 00000098EC24: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 00000098EC28: 020280FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000098EC30: BF870193
	.long 0xd72c003a                                           // 00000098EC34: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 00000098EC38: 020274FF 83DCD12D
	v_sad_u8 v63, v63, 0, 0x6400                               // 00000098EC40: D622003F 03FD013F 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000098EC4C: BF870193
	v_sad_u8 v64, v64, 0, 0x6400                               // 00000098EC50: D6220040 03FD0140 00006400
	v_sad_u8 v58, v58, 0, 0x6400                               // 00000098EC5C: D622003A 03FD013A 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000098EC68: BF870091
	v_lshlrev_b32_e32 v58, 16, v58                             // 00000098EC6C: 30747490
	v_and_or_b32 v58, 0xffff, v65, v58                         // 00000098EC70: D657003A 04EA82FF 0000FFFF
	v_bfe_u32 v65, v54, 8, 16                                  // 00000098EC7C: D6100041 02411136
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000098EC84: BF870232
	v_pk_fma_f16 v58, v58, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000098EC88: CC0E003A 0BFC0B3A 0000C931
	v_and_b32_e32 v61, 0xffff, v61                             // 00000098EC94: 367A7AFF 0000FFFF
	v_and_b32_e32 v63, 0xffff, v63                             // 00000098EC9C: 367E7EFF 0000FFFF
	.long 0xd72c0041                                           // 00000098ECA4: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 00000098ECA8: 020282FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000098ECB0: BF870193
	v_lshl_or_b32 v60, v60, 16, v61                            // 00000098ECB4: D656003C 04F5213C
	v_lshl_or_b32 v57, v64, 16, v63                            // 00000098ECBC: D6560039 04FD2140
	v_bfe_u32 v61, v56, 12, 16                                 // 00000098ECC4: D610003D 02411938
	v_bfe_u32 v63, v56, 8, 16                                  // 00000098ECCC: D610003F 02411138
	v_bfe_u32 v56, v56, 4, 16                                  // 00000098ECD4: D6100038 02410938
	v_bfe_u32 v64, v54, 12, 16                                 // 00000098ECDC: D6100040 02411936
	v_and_b32_e32 v54, 0xffff, v54                             // 00000098ECE4: 366C6CFF 0000FFFF
	.long 0xd72c003d                                           // 00000098ECEC: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 00000098ECF0: 02027AFF 83DCD12D
	.long 0xd72c003f                                           // 00000098ECF8: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 00000098ECFC: 02027EFF 83DCD12D
	.long 0xd72c0038                                           // 00000098ED04: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 00000098ED08: 020270FF 83DCD12D
	v_pk_fma_f16 v60, v60, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000098ED10: CC0E003C 0BFC0B3C 0000C931
	.long 0xd72c0036                                           // 00000098ED1C: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 00000098ED20: 02026CFF 83DCD12D
	v_pk_fma_f16 v57, v57, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000098ED28: CC0E0039 0BFC0B39 0000C931
	.long 0xd72c0040                                           // 00000098ED34: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 00000098ED38: 020280FF 83DCD12D
	v_sad_u8 v61, v61, 0, 0x6400                               // 00000098ED40: D622003D 03FD013D 00006400
	v_sad_u8 v63, v63, 0, 0x6400                               // 00000098ED4C: D622003F 03FD013F 00006400
	v_sad_u8 v56, v56, 0, 0x6400                               // 00000098ED58: D6220038 03FD0138 00006400
	v_dot2acc_f32_f16 v16, v60, v5                             // 00000098ED64: 04200B3C
	v_sad_u8 v54, v54, 0, 0x6400                               // 00000098ED68: D6220036 03FD0136 00006400
	v_dot2acc_f32_f16 v24, v60, v1                             // 00000098ED74: 0430033C
	v_sad_u8 v64, v64, 0, 0x6400                               // 00000098ED78: D6220040 03FD0140 00006400
	v_and_or_b32 v56, 0xffff, v56, v62                         // 00000098ED84: D6570038 04FA70FF 0000FFFF
	.long 0xd72c003e                                           // 00000098ED90: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 00000098ED94: 020284FF 83DCD12D
	v_lshlrev_b32_e32 v54, 16, v54                             // 00000098ED9C: 306C6C90
	v_dot2acc_f32_f16 v16, v59, v6                             // 00000098EDA0: 04200D3B
	v_dot2acc_f32_f16 v24, v59, v2                             // 00000098EDA4: 0430053B
	v_pk_fma_f16 v56, v56, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000098EDA8: CC0E0038 0BFC0B38 0000C931
	v_mov_b32_e32 v66, v49                                     // 00000098EDB4: 7E840331
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000098EDB8: BF8701B4
	v_dot2acc_f32_f16 v16, v57, v7                             // 00000098EDBC: 04200F39
	v_sad_u8 v62, v62, 0, 0x6400                               // 00000098EDC0: D622003E 03FD013E 00006400
	v_dot2acc_f32_f16 v24, v57, v3                             // 00000098EDCC: 04300739
	v_dot2acc_f32_f16 v16, v58, v8                             // 00000098EDD0: 0420113A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000098EDD4: BF870193
	v_and_or_b32 v54, 0xffff, v62, v54                         // 00000098EDD8: D6570036 04DA7CFF 0000FFFF
	v_dot2acc_f32_f16 v24, v58, v4                             // 00000098EDE4: 0430093A
	s_waitcnt vmcnt(1)                                         // 00000098EDE8: BF8907F7
	v_bfe_u32 v58, v52, 12, 16                                 // 00000098EDEC: D610003A 02411934
	v_mov_b32_e32 v62, v40                                     // 00000098EDF4: 7E7C0328
	v_pk_fma_f16 v54, v54, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000098EDF8: CC0E0036 0BFC0B36 0000C931
	v_and_b32_e32 v61, 0xffff, v61                             // 00000098EE04: 367A7AFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000098EE0C: BF870114
	.long 0xd72c003a                                           // 00000098EE10: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 00000098EE14: 020274FF 83DCD12D
	v_lshl_or_b32 v61, v63, 16, v61                            // 00000098EE1C: D656003D 04F5213F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000098EE24: BF870112
	v_sad_u8 v58, v58, 0, 0x6400                               // 00000098EE28: D622003A 03FD013A 00006400
	v_pk_fma_f16 v60, v61, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000098EE34: CC0E003C 0BFC0B3D 0000C931
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000098EE40: BF870112
	v_and_b32_e32 v58, 0xffff, v58                             // 00000098EE44: 367474FF 0000FFFF
	v_dot2acc_f32_f16 v22, v60, v5                             // 00000098EE4C: 042C0B3C
	v_dot2acc_f32_f16 v21, v60, v1                             // 00000098EE50: 042A033C
	v_bfe_u32 v60, v52, 4, 16                                  // 00000098EE54: D610003C 02410934
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000098EE5C: BF870193
	v_dot2acc_f32_f16 v22, v56, v6                             // 00000098EE60: 042C0D38
	v_dot2acc_f32_f16 v21, v56, v2                             // 00000098EE64: 042A0538
	v_bfe_u32 v56, v53, 8, 16                                  // 00000098EE68: D6100038 02411135
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000098EE70: BF870114
	.long 0xd72c003c                                           // 00000098EE74: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 00000098EE78: 020278FF 83DCD12D
	.long 0xd72c0038                                           // 00000098EE80: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 00000098EE84: 020270FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000098EE8C: BF870112
	v_sad_u8 v60, v60, 0, 0x6400                               // 00000098EE90: D622003C 03FD013C 00006400
	v_sad_u8 v56, v56, 0, 0x6400                               // 00000098EE9C: D6220038 03FD0138 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000098EEA8: BF870121
	v_lshl_or_b32 v55, v56, 16, v55                            // 00000098EEAC: D6560037 04DD2138
	v_bfe_u32 v56, v35, 12, 16                                 // 00000098EEB4: D6100038 02411923
	v_pk_fma_f16 v55, v55, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000098EEBC: CC0E0037 0BFC0B37 0000C931
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000098EEC8: BF870112
	.long 0xd72c0038                                           // 00000098EECC: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 00000098EED0: 020270FF 83DCD12D
	v_dot2acc_f32_f16 v18, v55, v1                             // 00000098EED8: 04240337
	v_and_b32_e32 v57, 0xffff, v53                             // 00000098EEDC: 36726AFF 0000FFFF
	v_bfe_u32 v53, v53, 4, 16                                  // 00000098EEE4: D6100035 02410935
	v_dot2acc_f32_f16 v20, v55, v5                             // 00000098EEEC: 04280B37
	v_sad_u8 v56, v56, 0, 0x6400                               // 00000098EEF0: D6220038 03FD0138 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000098EEFC: BF870214
	.long 0xd72c0039                                           // 00000098EF00: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 00000098EF04: 020272FF 83DCD12D
	.long 0xd72c0035                                           // 00000098EF0C: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 00000098EF10: 02026AFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000098EF18: BF870193
	v_and_b32_e32 v56, 0xffff, v56                             // 00000098EF1C: 367070FF 0000FFFF
	v_sad_u8 v57, v57, 0, 0x6400                               // 00000098EF24: D6220039 03FD0139 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000098EF30: BF870113
	v_sad_u8 v53, v53, 0, 0x6400                               // 00000098EF34: D6220035 03FD0135 00006400
	v_lshlrev_b32_e32 v57, 16, v57                             // 00000098EF40: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000098EF44: BF870091
	v_and_or_b32 v53, 0xffff, v53, v57                         // 00000098EF48: D6570035 04E66AFF 0000FFFF
	v_pk_fma_f16 v53, v53, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000098EF54: CC0E0035 0BFC0B35 0000C931
	v_and_b32_e32 v63, 0xffff, v64                             // 00000098EF60: 367E80FF 0000FFFF
	v_sad_u8 v64, v65, 0, 0x6400                               // 00000098EF68: D6220040 03FD0141 00006400
	v_mov_b32_e32 v65, v41                                     // 00000098EF74: 7E820329
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000098EF78: BF870224
	v_dot2acc_f32_f16 v20, v53, v6                             // 00000098EF7C: 04280D35
	v_dot2acc_f32_f16 v18, v53, v2                             // 00000098EF80: 04240535
	v_lshl_or_b32 v61, v64, 16, v63                            // 00000098EF84: D656003D 04FD2140
	v_mov_b32_e32 v63, v48                                     // 00000098EF8C: 7E7E0330
	v_mov_b32_e32 v53, v37                                     // 00000098EF90: 7E6A0325
	v_mov_b32_e32 v64, v49                                     // 00000098EF94: 7E800331
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000098EF98: BF870134
	v_pk_fma_f16 v59, v61, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000098EF9C: CC0E003B 0BFC0B3D 0000C931
	s_waitcnt vmcnt(0)                                         // 00000098EFA8: BF8903F7
	v_bfe_u32 v61, v34, 4, 16                                  // 00000098EFAC: D610003D 02410922
	v_dot2acc_f32_f16 v22, v59, v7                             // 00000098EFB4: 042C0F3B
	v_dot2acc_f32_f16 v21, v59, v3                             // 00000098EFB8: 042A073B
	v_bfe_u32 v59, v52, 8, 16                                  // 00000098EFBC: D610003B 02411134
	v_and_b32_e32 v52, 0xffff, v52                             // 00000098EFC4: 366868FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000098EFCC: BF870214
	v_dot2acc_f32_f16 v22, v54, v8                             // 00000098EFD0: 042C1136
	v_dot2acc_f32_f16 v21, v54, v4                             // 00000098EFD4: 042A0936
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000098EFD8: BF870214
	.long 0xd72c003b                                           // 00000098EFDC: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 00000098EFE0: 020276FF 83DCD12D
	.long 0xd72c0034                                           // 00000098EFE8: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 00000098EFEC: 020268FF 83DCD12D
	v_mov_b32_e32 v54, v46                                     // 00000098EFF4: 7E6C032E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000098EFF8: BF870193
	v_sad_u8 v59, v59, 0, 0x6400                               // 00000098EFFC: D622003B 03FD013B 00006400
	v_sad_u8 v52, v52, 0, 0x6400                               // 00000098F008: D6220034 03FD0134 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000098F014: BF870112
	v_lshl_or_b32 v36, v59, 16, v58                            // 00000098F018: D6560024 04E9213B
	v_lshlrev_b32_e32 v52, 16, v52                             // 00000098F020: 30686890
	v_bfe_u32 v58, v35, 8, 16                                  // 00000098F024: D610003A 02411123
	v_bfe_u32 v59, v34, 12, 16                                 // 00000098F02C: D610003B 02411922
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000098F034: BF870214
	v_pk_fma_f16 v36, v36, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000098F038: CC0E0024 0BFC0B24 0000C931
	v_and_or_b32 v52, 0xffff, v60, v52                         // 00000098F044: D6570034 04D278FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 00000098F050: BF870004
	.long 0xd72c003a                                           // 00000098F054: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 00000098F058: 020274FF 83DCD12D
	v_bfe_u32 v60, v34, 8, 16                                  // 00000098F060: D610003C 02411122
	.long 0xd72c003b                                           // 00000098F068: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 00000098F06C: 020276FF 83DCD12D
	v_dot2acc_f32_f16 v18, v36, v3                             // 00000098F074: 04240724
	v_pk_fma_f16 v52, v52, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000098F078: CC0E0034 0BFC0B34 0000C931
	v_and_b32_e32 v57, 0xffff, v35                             // 00000098F084: 367246FF 0000FFFF
	v_bfe_u32 v35, v35, 4, 16                                  // 00000098F08C: D6100023 02410923
	v_and_b32_e32 v34, 0xffff, v34                             // 00000098F094: 364444FF 0000FFFF
	v_sad_u8 v58, v58, 0, 0x6400                               // 00000098F09C: D622003A 03FD013A 00006400
	v_dot2acc_f32_f16 v18, v52, v4                             // 00000098F0A8: 04240934
	.long 0xd72c0039                                           // 00000098F0AC: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 00000098F0B0: 020272FF 83DCD12D
	.long 0xd72c0023                                           // 00000098F0B8: D72C0023
	v_cndmask_b32_e32 v1, 0x83dcd12d, v35, vcc_lo              // 00000098F0BC: 020246FF 83DCD12D
	.long 0xd72c003c                                           // 00000098F0C4: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 00000098F0C8: 020278FF 83DCD12D
	.long 0xd72c0022                                           // 00000098F0D0: D72C0022
	v_cndmask_b32_e32 v1, 0x83dcd12d, v34, vcc_lo              // 00000098F0D4: 020244FF 83DCD12D
	v_sad_u8 v59, v59, 0, 0x6400                               // 00000098F0DC: D622003B 03FD013B 00006400
	v_lshl_or_b32 v56, v58, 16, v56                            // 00000098F0E8: D6560038 04E1213A
	v_dot2acc_f32_f16 v20, v36, v7                             // 00000098F0F0: 04280F24
	v_mov_b32_e32 v36, v43                                     // 00000098F0F4: 7E48032B
	v_sad_u8 v57, v57, 0, 0x6400                               // 00000098F0F8: D6220039 03FD0139 00006400
	v_sad_u8 v35, v35, 0, 0x6400                               // 00000098F104: D6220023 03FD0123 00006400
	v_pk_fma_f16 v55, v56, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000098F110: CC0E0037 0BFC0B38 0000C931
	v_and_b32_e32 v58, 0xffff, v59                             // 00000098F11C: 367476FF 0000FFFF
	v_sad_u8 v59, v60, 0, 0x6400                               // 00000098F124: D622003B 03FD013C 00006400
	v_lshlrev_b32_e32 v57, 16, v57                             // 00000098F130: 30727290
	v_sad_u8 v34, v34, 0, 0x6400                               // 00000098F134: D6220022 03FD0122 00006400
	v_dot2acc_f32_f16 v17, v55, v5                             // 00000098F140: 04220B37
	v_dot2acc_f32_f16 v15, v55, v1                             // 00000098F144: 041E0337
	v_lshl_or_b32 v56, v59, 16, v58                            // 00000098F148: D6560038 04E9213B
	v_and_or_b32 v35, 0xffff, v35, v57                         // 00000098F150: D6570023 04E646FF 0000FFFF
	.long 0xd72c0039                                           // 00000098F15C: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 00000098F160: 02027AFF 83DCD12D
	v_lshlrev_b32_e32 v34, 16, v34                             // 00000098F168: 30444490
	v_dot2acc_f32_f16 v20, v52, v8                             // 00000098F16C: 04281134
	v_pk_fma_f16 v1, v56, s5, 0xc931 op_sel_hi:[1,0,0]         // 00000098F170: CC0E0001 0BFC0B38 0000C931
	v_pk_fma_f16 v35, v35, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000098F17C: CC0E0023 0BFC0B23 0000C931
	v_mov_b32_e32 v56, v38                                     // 00000098F188: 7E700326
	v_mov_b32_e32 v58, v47                                     // 00000098F18C: 7E74032F
	v_mov_b32_e32 v60, v47                                     // 00000098F190: 7E78032F
	v_sad_u8 v57, v57, 0, 0x6400                               // 00000098F194: D6220039 03FD0139 00006400
	v_dot2acc_f32_f16 v17, v35, v6                             // 00000098F1A0: 04220D23
	v_dot2acc_f32_f16 v15, v35, v2                             // 00000098F1A4: 041E0523
	v_mov_b32_e32 v59, v39                                     // 00000098F1A8: 7E760327
	v_dual_mov_b32 v61, v48 :: v_dual_mov_b32 v6, v51          // 00000098F1AC: CA100130 3D060133
	v_and_or_b32 v5, 0xffff, v57, v34                          // 00000098F1B4: D6570005 048A72FF 0000FFFF
	v_dot2acc_f32_f16 v17, v1, v7                              // 00000098F1C0: 04220F01
	v_dot2acc_f32_f16 v15, v1, v3                              // 00000098F1C4: 041E0701
	v_mov_b32_e32 v57, v46                                     // 00000098F1C8: 7E72032E
	v_dual_mov_b32 v3, v50 :: v_dual_mov_b32 v34, v43          // 00000098F1CC: CA100132 0322012B
	v_pk_fma_f16 v2, v5, s5, 0xc931 op_sel_hi:[1,0,0]          // 00000098F1D4: CC0E0002 0BFC0B05 0000C931
	v_mov_b32_e32 v5, v51                                      // 00000098F1E0: 7E0A0333
	v_mov_b32_e32 v55, v45                                     // 00000098F1E4: 7E6E032D
	v_dual_mov_b32 v52, v45 :: v_dual_mov_b32 v35, v10         // 00000098F1E8: CA10012D 3422010A
	s_delay_alu instid0(VALU_DEP_4)                            // 00000098F1F0: BF870004
	v_dot2acc_f32_f16 v17, v2, v8                              // 00000098F1F4: 04221102
	v_dual_dot2acc_f32_f16 v15, v2, v4 :: v_dual_mov_b32 v2, v44// 00000098F1F8: CB100902 0F02012C
	v_dual_mov_b32 v4, v42 :: v_dual_mov_b32 v1, v9            // 00000098F200: CA10012A 04000109
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000098F208: 917E047E
	s_cbranch_execz 58                                         // 00000098F20C: BFA5003A <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1af8>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000098F210: BF8700A1
	v_add_nc_u32_e32 v9, 1, v1                                 // 00000098F214: 4A120281
	s_mov_b32 s6, exec_lo                                      // 00000098F218: BE86007E
	.long 0xd4c1007e                                           // 00000098F21C: D4C1007E
	v_cndmask_b32_e32 v1, v9, v14, vcc_lo                      // 00000098F220: 02021D09
	s_cbranch_execz 64606                                      // 00000098F224: BFA5FC5E <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0xba0>
	v_ashrrev_i32_e32 v10, 31, v9                              // 00000098F228: 3414129F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000098F22C: BF870091
	.long 0xd73c0007                                           // 00000098F230: D73C0007
	v_cndmask_b32_e32 v1, 10, v9, vcc_lo                       // 00000098F234: 0202128A
	.long 0xd7006a0a                                           // 00000098F238: D7006A0A
	v_cndmask_b32_e32 v1, s1, v7, vcc_lo                       // 00000098F23C: 02020E01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000098F240: BF870111
	v_add_co_ci_u32_e64 v37, null, s3, v8, vcc_lo              // 00000098F244: D5207C25 01AA1003
	.long 0xd7006a07                                           // 00000098F24C: D7006A07
	v_cndmask_b32_e32 v1, v10, v33, vcc_lo                     // 00000098F250: 0202430A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000098F254: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v37, vcc_lo               // 00000098F258: D5207C08 01AA4A80
	.long 0xd7006a44                                           // 00000098F260: D7006A44
	v_cndmask_b32_e32 v1, v10, v32, vcc_lo                     // 00000098F264: 0202410A
	v_add_co_ci_u32_e64 v69, null, 0, v37, vcc_lo              // 00000098F268: D5207C45 01AA4A80
	s_clause 0xf                                               // 00000098F270: BF85000F
	global_load_b32 v42, v[7:8], off                           // 00000098F274: DC520000 2A7C0007
	global_load_b32 v44, v[7:8], off offset:128                // 00000098F27C: DC520080 2C7C0007
	global_load_b32 v41, v[7:8], off offset:256                // 00000098F284: DC520100 297C0007
	global_load_b32 v40, v[7:8], off offset:384                // 00000098F28C: DC520180 287C0007
	global_load_b32 v39, v[7:8], off offset:512                // 00000098F294: DC520200 277C0007
	global_load_b32 v38, v[7:8], off offset:640                // 00000098F29C: DC520280 267C0007
	global_load_b32 v37, v[7:8], off offset:768                // 00000098F2A4: DC520300 257C0007
	global_load_b32 v10, v[7:8], off offset:896                // 00000098F2AC: DC520380 0A7C0007
	global_load_b32 v51, v[68:69], off                         // 00000098F2B4: DC520000 337C0044
	global_load_b32 v50, v[68:69], off offset:128              // 00000098F2BC: DC520080 327C0044
	global_load_b32 v49, v[68:69], off offset:256              // 00000098F2C4: DC520100 317C0044
	global_load_b32 v48, v[68:69], off offset:384              // 00000098F2CC: DC520180 307C0044
	global_load_b32 v47, v[68:69], off offset:512              // 00000098F2D4: DC520200 2F7C0044
	global_load_b32 v46, v[68:69], off offset:640              // 00000098F2DC: DC520280 2E7C0044
	global_load_b32 v45, v[68:69], off offset:768              // 00000098F2E4: DC520300 2D7C0044
	global_load_b32 v43, v[68:69], off offset:896              // 00000098F2EC: DC520380 2B7C0044
	s_branch 64554                                             // 00000098F2F4: BFA0FC2A <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0xba0>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000098F2F8: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000098F2FC: BF870009
	s_or_b32 exec_lo, exec_lo, s0                              // 00000098F300: 8C7E007E
	s_waitcnt vmcnt(22)                                        // 00000098F304: BF895BF7
	v_dual_mov_b32 v1, v30 :: v_dual_mov_b32 v2, v27           // 00000098F308: CA10011E 0102011B
	s_waitcnt vmcnt(14)                                        // 00000098F310: BF893BF7
	v_dual_mov_b32 v3, v29 :: v_dual_mov_b32 v6, v28           // 00000098F314: CA10011D 0306011C
	v_dual_mov_b32 v4, v23 :: v_dual_mov_b32 v9, v25           // 00000098F31C: CA100117 04080119
	s_waitcnt vmcnt(7)                                         // 00000098F324: BF891FF7
	v_dual_mov_b32 v5, v19 :: v_dual_mov_b32 v8, v26           // 00000098F328: CA100113 0508011A
	v_dual_mov_b32 v7, v16 :: v_dual_mov_b32 v14, v22          // 00000098F330: CA100110 070E0116
	v_dual_mov_b32 v10, v24 :: v_dual_mov_b32 v31, v21         // 00000098F338: CA100118 0A1E0115
	v_dual_mov_b32 v32, v20 :: v_dual_mov_b32 v33, v18         // 00000098F340: CA100114 20200112
	s_waitcnt vmcnt(0)                                         // 00000098F348: BF8903F7
	v_dual_mov_b32 v34, v17 :: v_dual_mov_b32 v35, v15         // 00000098F34C: CA100111 2222010F
	s_mov_b32 s0, 0x76543210                                   // 00000098F354: BE8000FF 76543210
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000098F35C: BF870009
	v_permlanex16_b32 v1, v1, s0, 0xfedcba98                   // 00000098F360: D65C0001 03FC0101 FEDCBA98
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 00000098F36C: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 00000098F378: D65C0003 03FC0103 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 00000098F384: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 00000098F390: D65C0004 03FC0104 FEDCBA98
	v_permlanex16_b32 v5, v5, s0, 0xfedcba98                   // 00000098F39C: D65C0005 03FC0105 FEDCBA98
	v_permlanex16_b32 v8, v8, s0, 0xfedcba98                   // 00000098F3A8: D65C0008 03FC0108 FEDCBA98
	v_permlanex16_b32 v9, v9, s0, 0xfedcba98                   // 00000098F3B4: D65C0009 03FC0109 FEDCBA98
	v_permlanex16_b32 v7, v7, s0, 0xfedcba98                   // 00000098F3C0: D65C0007 03FC0107 FEDCBA98
	v_permlanex16_b32 v10, v10, s0, 0xfedcba98                 // 00000098F3CC: D65C000A 03FC010A FEDCBA98
	v_permlanex16_b32 v14, v14, s0, 0xfedcba98                 // 00000098F3D8: D65C000E 03FC010E FEDCBA98
	v_permlanex16_b32 v31, v31, s0, 0xfedcba98                 // 00000098F3E4: D65C001F 03FC011F FEDCBA98
	v_permlanex16_b32 v32, v32, s0, 0xfedcba98                 // 00000098F3F0: D65C0020 03FC0120 FEDCBA98
	v_permlanex16_b32 v33, v33, s0, 0xfedcba98                 // 00000098F3FC: D65C0021 03FC0121 FEDCBA98
	v_permlanex16_b32 v34, v34, s0, 0xfedcba98                 // 00000098F408: D65C0022 03FC0122 FEDCBA98
	v_permlanex16_b32 v35, v35, s0, 0xfedcba98                 // 00000098F414: D65C0023 03FC0123 FEDCBA98
	.long 0xd44c0000                                           // 00000098F420: D44C0000
	v_cndmask_b32_e32 v1, 16, v12, vcc_lo                      // 00000098F424: 02021890
	s_barrier                                                  // 00000098F428: BFBD0000
	buffer_gl0_inv                                             // 00000098F42C: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 00000098F434: BE812000
	s_cbranch_execz 34                                         // 00000098F438: BFA50022 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1cc4>
	v_dual_add_f32 v8, v26, v8 :: v_dual_add_f32 v3, v29, v3   // 00000098F43C: C908111A 0802071D
	v_dual_add_f32 v6, v28, v6 :: v_dual_add_f32 v1, v30, v1   // 00000098F444: C9080D1C 0600031E
	v_lshl_or_b32 v13, v11, 10, v13                            // 00000098F44C: D656000D 0435150B
	v_dual_add_f32 v2, v27, v2 :: v_dual_add_f32 v7, v16, v7   // 00000098F454: C908051B 02060F10
	v_add_f32_e32 v4, v23, v4                                  // 00000098F45C: 06080917
	v_dual_add_f32 v10, v24, v10 :: v_dual_add_f32 v9, v25, v9 // 00000098F460: C9081518 0A081319
	v_add_f32_e32 v5, v19, v5                                  // 00000098F468: 060A0B13
	v_dual_add_f32 v21, v21, v31 :: v_dual_add_f32 v14, v22, v14// 00000098F46C: C9083F15 150E1D16
	v_dual_add_f32 v15, v15, v35 :: v_dual_add_f32 v18, v18, v33// 00000098F474: C908470F 0F124312
	v_dual_add_f32 v17, v17, v34 :: v_dual_add_f32 v20, v20, v32// 00000098F47C: C9084511 11144114
	ds_store_2addr_b32 v13, v1, v3 offset1:16                  // 00000098F484: D8381000 0003010D
	ds_store_2addr_b32 v13, v2, v6 offset0:128 offset1:144     // 00000098F48C: D8389080 0006020D
	ds_store_2addr_b32 v13, v4, v8 offset0:32 offset1:48       // 00000098F494: D8383020 0008040D
	ds_store_2addr_b32 v13, v5, v9 offset0:160 offset1:176     // 00000098F49C: D838B0A0 0009050D
	ds_store_2addr_b32 v13, v7, v14 offset0:64 offset1:80      // 00000098F4A4: D8385040 000E070D
	ds_store_2addr_b32 v13, v10, v21 offset0:192 offset1:208   // 00000098F4AC: D838D0C0 00150A0D
	ds_store_2addr_b32 v13, v20, v17 offset0:96 offset1:112    // 00000098F4B4: D8387060 0011140D
	ds_store_2addr_b32 v13, v18, v15 offset0:224 offset1:240   // 00000098F4BC: D838F0E0 000F120D
	s_or_b32 exec_lo, exec_lo, s1                              // 00000098F4C4: 8C7E017E
	.long 0xd44c0001                                           // 00000098F4C8: D44C0001
	v_cndmask_b32_e32 v1, 0x100, v0, vcc_lo                    // 00000098F4CC: 020200FF 00000100
	s_waitcnt lgkmcnt(0)                                       // 00000098F4D4: BF89FC07
	s_barrier                                                  // 00000098F4D8: BFBD0000
	buffer_gl0_inv                                             // 00000098F4DC: E0AC0000 00000000
	s_and_saveexec_b32 s3, s1                                  // 00000098F4E4: BE832001
	s_cbranch_execnz 7                                         // 00000098F4E8: BFA60007 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1d08>
	s_or_b32 exec_lo, exec_lo, s3                              // 00000098F4EC: 8C7E037E
	s_cmp_lt_i32 s9, 2                                         // 00000098F4F0: BF048209
	s_mov_b32 s3, -1                                           // 00000098F4F4: BE8300C1
	s_cbranch_scc0 33                                          // 00000098F4F8: BFA10021 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1d80>
	s_and_b32 vcc_lo, exec_lo, s3                              // 00000098F4FC: 8B6A037E
	s_cbranch_vccnz 196                                        // 00000098F500: BFA400C4 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2014>
	s_branch 574                                               // 00000098F504: BFA0023E <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2600>
	v_lshlrev_b32_e32 v7, 2, v0                                // 00000098F508: 300E0082
	ds_load_2addr_stride64_b32 v[1:2], v7 offset1:4            // 00000098F50C: D8E00400 01000007
	ds_load_2addr_stride64_b32 v[3:4], v7 offset0:8 offset1:12 // 00000098F514: D8E00C08 03000007
	ds_load_2addr_stride64_b32 v[5:6], v7 offset0:16 offset1:20// 00000098F51C: D8E01410 05000007
	s_waitcnt lgkmcnt(2)                                       // 00000098F524: BF89FC27
	v_add_f32_e32 v1, 0, v1                                    // 00000098F528: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000098F52C: BF8700A1
	v_add_f32_e32 v1, v1, v2                                   // 00000098F530: 06020501
	s_waitcnt lgkmcnt(1)                                       // 00000098F534: BF89FC17
	v_add_f32_e32 v3, v1, v3                                   // 00000098F538: 06060701
	ds_load_2addr_stride64_b32 v[1:2], v7 offset0:24 offset1:28// 00000098F53C: D8E01C18 01000007
	v_add_f32_e32 v3, v3, v4                                   // 00000098F544: 06060903
	s_waitcnt lgkmcnt(1)                                       // 00000098F548: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000098F54C: BF870091
	v_add_f32_e32 v3, v3, v5                                   // 00000098F550: 06060B03
	v_add_f32_e32 v3, v3, v6                                   // 00000098F554: 06060D03
	s_waitcnt lgkmcnt(0)                                       // 00000098F558: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000098F55C: BF870091
	v_add_f32_e32 v1, v3, v1                                   // 00000098F560: 06020303
	v_add_f32_e32 v1, v1, v2                                   // 00000098F564: 06020501
	ds_store_b32 v7, v1 offset:8192                            // 00000098F568: D8342000 00000107
	s_or_b32 exec_lo, exec_lo, s3                              // 00000098F570: 8C7E037E
	s_cmp_lt_i32 s9, 2                                         // 00000098F574: BF048209
	s_mov_b32 s3, -1                                           // 00000098F578: BE8300C1
	s_cbranch_scc1 65503                                       // 00000098F57C: BFA2FFDF <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1cfc>
	s_waitcnt lgkmcnt(0)                                       // 00000098F580: BF89FC07
	s_barrier                                                  // 00000098F584: BFBD0000
	buffer_gl0_inv                                             // 00000098F588: E0AC0000 00000000
	s_and_saveexec_b32 s3, s1                                  // 00000098F590: BE832001
	s_cbranch_execz 41                                         // 00000098F594: BFA50029 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1e3c>
	v_lshrrev_b32_e32 v1, 7, v0                                // 00000098F598: 32020087
	s_ashr_i32 s4, s49, 31                                     // 00000098F59C: 86049F31
	v_lshlrev_b32_e32 v4, 2, v0                                // 00000098F5A0: 30080082
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 00000098F5A4: BF8704D2
	v_lshl_or_b32 v1, s30, 1, v1                               // 00000098F5A8: D6560001 0405021E
	ds_load_b32 v4, v4 offset:8192                             // 00000098F5B0: D8D82000 04000004
	.long 0xd72c0003                                           // 00000098F5B8: D72C0003
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 00000098F5BC: 02000901
	v_mad_u64_u32 v[1:2], null, v1, s49, 0                     // 00000098F5C0: D6FE7C01 02006301
	s_ashr_i32 s4, s30, 31                                     // 00000098F5C8: 86049F1E
	s_mul_i32 s4, s4, s49                                      // 00000098F5CC: 96043104
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000098F5D0: BF870149
	v_add3_u32 v2, v2, v3, s4                                  // 00000098F5D4: D6550002 00120702
	s_lshl_b32 s4, s10, 7                                      // 00000098F5DC: 8404870A
	v_and_b32_e32 v3, 0x7f, v0                                 // 00000098F5E0: 360600FF 0000007F
	s_ashr_i32 s5, s4, 31                                      // 00000098F5E8: 86059F04
	.long 0xd73c0001                                           // 00000098F5EC: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000098F5F0: 02020282
	s_lshl_b64 s[4:5], s[4:5], 2                               // 00000098F5F4: 84848204
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000098F5F8: BF870132
	v_lshlrev_b32_e32 v3, 2, v3                                // 00000098F5FC: 30060682
	s_add_u32 s4, s44, s4                                      // 00000098F600: 8004042C
	s_addc_u32 s5, s45, s5                                     // 00000098F604: 8205052D
	.long 0xd7006a01                                           // 00000098F608: D7006A01
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 00000098F60C: 02020204
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000098F610: BF870111
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 00000098F614: D5207C02 01AA0405
	.long 0xd7006a01                                           // 00000098F61C: D7006A01
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 00000098F620: 02020701
	s_delay_alu instid0(VALU_DEP_1)                            // 00000098F624: BF870001
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 00000098F628: D5207C02 01AA0480
	s_waitcnt lgkmcnt(0)                                       // 00000098F630: BF89FC07
	global_store_b32 v[1:2], v4, off                           // 00000098F634: DC6A0000 007C0401
	s_or_b32 exec_lo, exec_lo, s3                              // 00000098F63C: 8C7E037E
	.long 0xd44a0003                                           // 00000098F640: D44A0003
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 00000098F644: 02020080
	s_waitcnt_vscnt null, 0x0                                  // 00000098F648: BC7C0000
	buffer_gl1_inv                                             // 00000098F64C: E0B00000 00000000
	buffer_gl0_inv                                             // 00000098F654: E0AC0000 00000000
	s_barrier                                                  // 00000098F65C: BFBD0000
	buffer_gl0_inv                                             // 00000098F660: E0AC0000 00000000
	s_and_saveexec_b32 s4, s3                                  // 00000098F668: BE842003
	s_cbranch_execz 29                                         // 00000098F66C: BFA5001D <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1ee4>
	s_mov_b32 s6, exec_lo                                      // 00000098F670: BE86007E
	s_mov_b32 s5, exec_lo                                      // 00000098F674: BE85007E
	.long 0xd71f0001                                           // 00000098F678: D71F0001
	v_cndmask_b32_e32 v0, s6, v128, vcc_lo                     // 00000098F67C: 02010006
	s_delay_alu instid0(VALU_DEP_1)                            // 00000098F680: BF870001
	v_cmpx_eq_u32_e32 0, v1                                    // 00000098F684: 7D940280
	s_cbranch_execz 9                                          // 00000098F688: BFA50009 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1eb0>
	s_lshl_b64 s[24:25], s[10:11], 2                           // 00000098F68C: 8498820A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000098F690: BF8704B9
	s_add_u32 s24, s46, s24                                    // 00000098F694: 8018182E
	s_addc_u32 s25, s47, s25                                   // 00000098F698: 8219192F
	s_bcnt1_i32_b32 s6, s6                                     // 00000098F69C: BE861806
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, s6              // 00000098F6A0: CA100080 02020006
	global_atomic_add_u32 v2, v2, v3, s[24:25] glc             // 00000098F6A8: DCD64000 02180302
	s_or_b32 exec_lo, exec_lo, s5                              // 00000098F6B0: 8C7E057E
	s_waitcnt vmcnt(0)                                         // 00000098F6B4: BF8903F7
	v_readfirstlane_b32 s5, v2                                 // 00000098F6B8: 7E0A0502
	s_delay_alu instid0(VALU_DEP_1)                            // 00000098F6BC: BF870001
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s5, v1       // 00000098F6C0: CA200080 02000205
	s_add_i32 s5, s9, -1                                       // 00000098F6C8: 8105C109
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000098F6CC: BF870481
	v_cmp_eq_u32_e32 vcc_lo, s5, v1                            // 00000098F6D0: 7C940205
	v_cndmask_b32_e64 v1, 0, 1, vcc_lo                         // 00000098F6D4: D5010001 01A90280
	ds_store_b32 v2, v1 offset:18432                           // 00000098F6DC: D8344800 00000102
	s_or_b32 exec_lo, exec_lo, s4                              // 00000098F6E4: 8C7E047E
	v_mov_b32_e32 v1, 0                                        // 00000098F6E8: 7E020280
	s_waitcnt lgkmcnt(0)                                       // 00000098F6EC: BF89FC07
	s_barrier                                                  // 00000098F6F0: BFBD0000
	buffer_gl0_inv                                             // 00000098F6F4: E0AC0000 00000000
	ds_load_b32 v1, v1 offset:18432                            // 00000098F6FC: D8D84800 01000001
	s_waitcnt lgkmcnt(0)                                       // 00000098F704: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 00000098F708: 7C940280
	s_cbranch_vccnz 64                                         // 00000098F70C: BFA40040 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2010>
	buffer_gl1_inv                                             // 00000098F710: E0B00000 00000000
	buffer_gl0_inv                                             // 00000098F718: E0AC0000 00000000
	s_and_saveexec_b32 s4, s1                                  // 00000098F720: BE842001
	s_cbranch_execz 46                                         // 00000098F724: BFA5002E <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1fe0>
	v_and_b32_e32 v2, 0x7f, v0                                 // 00000098F728: 360400FF 0000007F
	s_lshl_b32 s6, s10, 7                                      // 00000098F730: 8406870A
	s_ashr_i32 s1, s49, 31                                     // 00000098F734: 86019F31
	s_ashr_i32 s7, s6, 31                                      // 00000098F738: 86079F06
	v_lshrrev_b32_e32 v1, 7, v0                                // 00000098F73C: 32020087
	v_dual_mov_b32 v2, 0 :: v_dual_lshlrev_b32 v3, 2, v2       // 00000098F740: CA220080 02020482
	s_lshl_b64 s[6:7], s[6:7], 2                               // 00000098F748: 84868206
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000098F74C: BF8700A9
	s_add_u32 s5, s44, s6                                      // 00000098F750: 8005062C
	s_addc_u32 s6, s45, s7                                     // 00000098F754: 8206072D
	.long 0xd7000503                                           // 00000098F758: D7000503
	v_cndmask_b32_e32 v1, s5, v3, vcc_lo                       // 00000098F75C: 02020605
	s_delay_alu instid0(VALU_DEP_1)                            // 00000098F760: BF870001
	v_add_co_ci_u32_e64 v4, null, s6, 0, s5                    // 00000098F764: D5207C04 00150006
	s_mov_b32 s5, s49                                          // 00000098F76C: BE850031
	s_nop 0                                                    // 00000098F770: BF800000
	s_nop 0                                                    // 00000098F774: BF800000
	s_nop 0                                                    // 00000098F778: BF800000
	s_nop 0                                                    // 00000098F77C: BF800000
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000098F780: BF8704A9
	v_mad_u64_u32 v[5:6], null, v1, s5, 0                      // 00000098F784: D6FE7C05 02000B01
	s_add_i32 s9, s9, -1                                       // 00000098F78C: 8109C109
	s_cmp_eq_u32 s9, 0                                         // 00000098F790: BF068009
	v_mad_u64_u32 v[6:7], null, v1, s1, v[6:7]                 // 00000098F794: D6FE7C06 04180301
	v_add_nc_u32_e32 v1, 2, v1                                 // 00000098F79C: 4A020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000098F7A0: BF870092
	.long 0xd73c0005                                           // 00000098F7A4: D73C0005
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 00000098F7A8: 02020A82
	.long 0xd7006a05                                           // 00000098F7AC: D7006A05
	v_cndmask_b32_e32 v1, v3, v5, vcc_lo                       // 00000098F7B0: 02020B03
	s_delay_alu instid0(VALU_DEP_1)                            // 00000098F7B4: BF870001
	v_add_co_ci_u32_e64 v6, null, v4, v6, vcc_lo               // 00000098F7B8: D5207C06 01AA0D04
	global_load_b32 v5, v[5:6], off glc                        // 00000098F7C0: DC524000 057C0005
	s_waitcnt vmcnt(0)                                         // 00000098F7C8: BF8903F7
	v_add_f32_e32 v2, v2, v5                                   // 00000098F7CC: 06040B02
	s_cbranch_scc0 65515                                       // 00000098F7D0: BFA1FFEB <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x1f80>
	v_lshlrev_b32_e32 v1, 2, v0                                // 00000098F7D4: 30020082
	ds_store_b32 v1, v2 offset:8192                            // 00000098F7D8: D8342000 00000201
	s_or_b32 exec_lo, exec_lo, s4                              // 00000098F7E0: 8C7E047E
	s_and_saveexec_b32 s1, s3                                  // 00000098F7E4: BE812003
	s_cbranch_execz 6                                          // 00000098F7E8: BFA50006 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2004>
	s_lshl_b64 s[4:5], s[10:11], 2                             // 00000098F7EC: 8484820A
	v_mov_b32_e32 v1, 0                                        // 00000098F7F0: 7E020280
	s_add_u32 s4, s46, s4                                      // 00000098F7F4: 8004042E
	s_addc_u32 s5, s47, s5                                     // 00000098F7F8: 8205052F
	global_store_b32 v1, v1, s[4:5]                            // 00000098F7FC: DC6A0000 00040101
	s_or_b32 exec_lo, exec_lo, s1                              // 00000098F804: 8C7E017E
	s_cbranch_execnz 2                                         // 00000098F808: BFA60002 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2014>
	s_branch 380                                               // 00000098F80C: BFA0017C <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2600>
	s_branch 379                                               // 00000098F810: BFA0017B <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2600>
	v_cmp_gt_i32_e32 vcc_lo, s48, v11                          // 00000098F814: 7C881630
	.long 0xd44c0001                                           // 00000098F818: D44C0001
	v_cndmask_b32_e32 v1, 64, v0, vcc_lo                       // 00000098F81C: 020200C0
	s_waitcnt lgkmcnt(0)                                       // 00000098F820: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 00000098F824: BC7C0000
	s_barrier                                                  // 00000098F828: BFBD0000
	buffer_gl0_inv                                             // 00000098F82C: E0AC0000 00000000
	s_and_b32 s1, vcc_lo, s1                                   // 00000098F834: 8B01016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000098F838: BF870009
	s_and_saveexec_b32 s3, s1                                  // 00000098F83C: BE832001
	s_cbranch_execz 366                                        // 00000098F840: BFA5016E <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x25fc>
	v_and_b32_e32 v1, 15, v0                                   // 00000098F844: 3602008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000098F848: BF870091
	v_lshlrev_b32_e32 v2, 2, v1                                // 00000098F84C: 30040282
	v_lshl_or_b32 v2, v11, 9, v2                               // 00000098F850: D6560002 0409130B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000098F858: BF870001
	v_add_nc_u32_e32 v8, 0x2000, v2                            // 00000098F85C: 4A1004FF 00002000
	ds_load_2addr_b32 v[2:3], v8 offset1:16                    // 00000098F864: D8DC1000 02000008
	ds_load_2addr_b32 v[4:5], v8 offset0:32 offset1:48         // 00000098F86C: D8DC3020 04000008
	ds_load_2addr_b32 v[6:7], v8 offset0:64 offset1:80         // 00000098F874: D8DC5040 06000008
	ds_load_2addr_b32 v[8:9], v8 offset0:96 offset1:112        // 00000098F87C: D8DC7060 08000008
	v_and_b32_e32 v10, 1, v0                                   // 00000098F884: 36140081
	v_and_b32_e32 v13, 2, v0                                   // 00000098F888: 361A0082
	s_waitcnt lgkmcnt(3)                                       // 00000098F88C: BF89FC37
	v_dual_add_f32 v15, v2, v3 :: v_dual_and_b32 v14, 4, v0    // 00000098F890: C9240702 0F0E0084
	s_waitcnt lgkmcnt(2)                                       // 00000098F898: BF89FC27
	v_dual_sub_f32 v2, v2, v3 :: v_dual_add_f32 v3, v4, v5     // 00000098F89C: C9480702 02020B04
	s_waitcnt lgkmcnt(1)                                       // 00000098F8A4: BF89FC17
	v_dual_sub_f32 v4, v4, v5 :: v_dual_add_f32 v5, v6, v7     // 00000098F8A8: C9480B04 04040F06
	s_waitcnt lgkmcnt(0)                                       // 00000098F8B0: BF89FC07
	v_dual_sub_f32 v6, v6, v7 :: v_dual_add_f32 v7, v8, v9     // 00000098F8B4: C9480F06 06061308
	v_dual_sub_f32 v8, v8, v9 :: v_dual_add_f32 v9, v15, v3    // 00000098F8BC: C9481308 0808070F
	v_sub_f32_e32 v3, v15, v3                                  // 00000098F8C4: 0806070F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000098F8C8: BF870243
	v_dual_add_f32 v15, v2, v4 :: v_dual_add_f32 v16, v5, v7   // 00000098F8CC: C9080902 0F100F05
	v_dual_sub_f32 v2, v2, v4 :: v_dual_sub_f32 v5, v5, v7     // 00000098F8D4: C94A0902 02040F05
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 00000098F8DC: 7C941480
	.long 0xd44a0001                                           // 00000098F8E0: D44A0001
	v_cndmask_b32_e32 v1, 0, v14, vcc_lo                       // 00000098F8E4: 02021C80
	v_add_f32_e32 v7, v9, v16                                  // 00000098F8E8: 060E2109
	v_add_f32_e32 v4, v6, v8                                   // 00000098F8EC: 06081106
	v_sub_f32_e32 v6, v6, v8                                   // 00000098F8F0: 080C1106
	v_sub_f32_e32 v8, v9, v16                                  // 00000098F8F4: 08102109
	s_delay_alu instid0(VALU_DEP_3)                            // 00000098F8F8: BF870003
	v_add_f32_e32 v9, v15, v4                                  // 00000098F8FC: 0612090F
	v_sub_f32_e32 v4, v15, v4                                  // 00000098F900: 0808090F
	v_add_f32_e32 v15, v3, v5                                  // 00000098F904: 061E0B03
	v_sub_f32_e32 v3, v3, v5                                   // 00000098F908: 08060B03
	v_add_f32_e32 v5, v2, v6                                   // 00000098F90C: 060A0D02
	v_sub_f32_e32 v2, v2, v6                                   // 00000098F910: 08040D02
	v_mov_b32_dpp v10, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000098F914: 7E1402FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 00000098F91C: D5010009 21AA1309
	v_mov_b32_dpp v6, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000098F924: 7E0C02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 00000098F92C: D5010007 21AA0F07
	v_mov_b32_dpp v16, v15 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000098F934: 7E2002FA FF01610F
	v_cndmask_b32_e64 v15, -v15, v15, vcc_lo                   // 00000098F93C: D501000F 21AA1F0F
	v_mov_b32_dpp v17, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000098F944: 7E2202FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 00000098F94C: D5010005 21AA0B05
	v_mov_b32_dpp v18, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000098F954: 7E2402FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 00000098F95C: D5010008 21AA1108
	v_mov_b32_dpp v19, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000098F964: 7E2602FA FF016104
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 00000098F96C: D5010004 21AA0904
	v_cndmask_b32_e64 v21, -v3, v3, vcc_lo                     // 00000098F974: D5010015 21AA0703
	v_mov_b32_dpp v22, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000098F97C: 7E2C02FA FF016102
	v_cndmask_b32_e64 v23, -v2, v2, vcc_lo                     // 00000098F984: D5010017 21AA0502
	s_delay_alu instid0(VALU_DEP_4)                            // 00000098F98C: BF870004
	v_dual_add_f32 v2, v9, v10 :: v_dual_add_f32 v9, v4, v19   // 00000098F990: C9081509 02082704
	v_cmp_eq_u32_e32 vcc_lo, 0, v13                            // 00000098F998: 7C941A80
	v_mov_b32_dpp v20, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000098F99C: 7E2802FA FF016103
	v_add_f32_e32 v3, v7, v6                                   // 00000098F9A4: 06060D07
	v_dual_add_f32 v5, v5, v17 :: v_dual_add_f32 v6, v15, v16  // 00000098F9A8: C9082305 0506210F
	v_mov_b32_dpp v7, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000098F9B0: 7E0E02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 00000098F9B8: D5010002 21AA0502
	v_mov_b32_dpp v16, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000098F9C0: 7E2002FA FF016209
	s_delay_alu instid0(VALU_DEP_4)                            // 00000098F9C8: BF870004
	v_mov_b32_dpp v13, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000098F9CC: 7E1A02FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 00000098F9D4: D5010005 21AA0B05
	v_mov_b32_dpp v10, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000098F9DC: 7E1402FA FF016206
	v_add_f32_e32 v2, v2, v7                                   // 00000098F9E4: 06040F02
	v_mov_b32_dpp v4, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000098F9E8: 7E0802FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 00000098F9F0: D5010003 21AA0703
	v_add_f32_e32 v8, v8, v18                                  // 00000098F9F8: 06102508
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 00000098F9FC: D5010006 21AA0D06
	v_cndmask_b32_e64 v7, -v2, v2, s1                          // 00000098FA04: D5010007 20060502
	v_mov_b32_dpp v2, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000098FA0C: 7E0402FA FF016402
	v_dual_add_f32 v3, v3, v4 :: v_dual_add_f32 v4, v5, v13    // 00000098FA14: C9080903 03041B05
	v_mov_b32_dpp v14, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000098FA1C: 7E1C02FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 00000098FA24: D5010008 21AA1108
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000098FA2C: BF870214
	v_add_f32_e32 v7, v7, v2                                   // 00000098FA30: 060E0507
	v_mov_b32_dpp v5, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000098FA34: 7E0A02FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 00000098FA3C: D5010003 20060703
	v_add_f32_e32 v6, v6, v10                                  // 00000098FA44: 060C1506
	v_mov_b32_dpp v10, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000098FA48: 7E1402FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 00000098FA50: D5010004 20060904
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 00000098FA58: D5010009 21AA1309
	v_add_f32_e32 v15, v23, v22                                // 00000098FA60: 061E2D17
	v_dual_add_f32 v8, v8, v14 :: v_dual_add_f32 v3, v3, v5    // 00000098FA64: C9081D08 08020B03
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000098FA6C: BF870223
	v_dual_add_f32 v4, v4, v10 :: v_dual_add_f32 v9, v9, v16   // 00000098FA70: C9081504 04082109
	v_add_f32_e32 v10, v21, v20                                // 00000098FA78: 06142915
	v_mov_b32_dpp v17, v15 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000098FA7C: 7E2202FA FF01620F
	v_cndmask_b32_e64 v15, -v15, v15, vcc_lo                   // 00000098FA84: D501000F 21AA1F0F
	v_mov_b32_dpp v13, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000098FA8C: 7E1A02FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 00000098FA94: D5010006 20060D06
	v_mov_b32_dpp v14, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000098FA9C: 7E1C02FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 00000098FAA4: D501000A 21AA150A
	v_mov_b32_dpp v2, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000098FAAC: 7E0402FA FF016803
	v_mov_b32_dpp v5, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000098FAB4: 7E0A02FA FF016807
	v_add_f32_e32 v6, v6, v13                                  // 00000098FABC: 060C1B06
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000098FAC0: BF870244
	v_add_f32_e32 v10, v10, v14                                // 00000098FAC4: 06141D0A
	v_add_f32_e32 v14, v15, v17                                // 00000098FAC8: 061C230F
	v_mov_b32_dpp v15, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000098FACC: 7E1E02FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 00000098FAD4: D5010009 20061309
	v_mov_b32_dpp v17, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000098FADC: 7E2202FA FF01640A
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 00000098FAE4: D501000A 2006150A
	v_mov_b32_dpp v19, v14 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000098FAEC: 7E2602FA FF01640E
	v_cndmask_b32_e64 v14, -v14, v14, s1                       // 00000098FAF4: D501000E 20061D0E
	v_add_f32_e32 v18, v9, v15                                 // 00000098FAFC: 06241F09
	v_mov_b32_dpp v9, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000098FB00: 7E1202FA FF016804
	v_add_f32_e32 v17, v10, v17                                // 00000098FB08: 0622230A
	v_mov_b32_dpp v13, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000098FB0C: 7E1A02FA FF016408
	v_cndmask_b32_e64 v16, -v8, v8, s1                         // 00000098FB14: D5010010 20061108
	v_add_f32_e32 v19, v14, v19                                // 00000098FB1C: 0626270E
	v_mov_b32_dpp v8, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000098FB20: 7E1002FA FF016806
	v_mov_b32_dpp v14, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000098FB28: 7E1C02FA FF016811
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000098FB30: BF8701B4
	v_add_f32_e32 v16, v16, v13                                // 00000098FB34: 06201B10
	v_mov_b32_dpp v13, v18 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000098FB38: 7E1A02FA FF016812
	v_mov_b32_dpp v15, v19 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000098FB40: 7E1E02FA FF016813
	v_mov_b32_dpp v10, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000098FB48: 7E1402FA FF016810
	s_and_b32 exec_lo, exec_lo, s0                             // 00000098FB50: 8B7E007E
	s_cbranch_execz 169                                        // 00000098FB54: BFA500A9 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x25fc>
	v_lshl_or_b32 v20, s10, 7, v1                              // 00000098FB58: D6560014 04050E0A
	v_and_b32_e32 v1, 8, v0                                    // 00000098FB60: 36020088
	.long 0x7f303880                                           // 00000098FB64: 7F303880
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000098FB68: BF870113
	v_ashrrev_i32_e32 v21, 31, v20                             // 00000098FB6C: 342A289F
	.long 0x7f363998                                           // 00000098FB70: 7F363998
	.long 0x7f323998                                           // 00000098FB74: 7F323998
	.long 0x7f343998                                           // 00000098FB78: 7F343998
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000098FB7C: BF870094
	.long 0xd73c0014                                           // 00000098FB80: D73C0014
	v_cndmask_b32_e32 v1, 1, v20, vcc_lo                       // 00000098FB84: 02022881
	.long 0xd7006a16                                           // 00000098FB88: D7006A16
	v_cndmask_b32_e32 v1, s36, v20, vcc_lo                     // 00000098FB8C: 02022824
	s_delay_alu instid0(VALU_DEP_1)                            // 00000098FB90: BF870001
	v_add_co_ci_u32_e64 v23, null, s37, v21, vcc_lo            // 00000098FB94: D5207C17 01AA2A25
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 00000098FB9C: 7C940280
	s_clause 0x7                                               // 00000098FBA0: BF850007
	global_load_d16_b16 v24, v[22:23], off offset:32           // 00000098FBA4: DC820020 187C0016
	global_load_d16_b16 v25, v[22:23], off                     // 00000098FBAC: DC820000 197C0016
	global_load_d16_b16 v26, v[22:23], off offset:64           // 00000098FBB4: DC820040 1A7C0016
	global_load_d16_b16 v27, v[22:23], off offset:96           // 00000098FBBC: DC820060 1B7C0016
	global_load_d16_b16 v28, v[22:23], off offset:128          // 00000098FBC4: DC820080 1C7C0016
	global_load_d16_b16 v29, v[22:23], off offset:160          // 00000098FBCC: DC8200A0 1D7C0016
	global_load_d16_b16 v30, v[22:23], off offset:192          // 00000098FBD4: DC8200C0 1E7C0016
	global_load_d16_b16 v31, v[22:23], off offset:224          // 00000098FBDC: DC8200E0 1F7C0016
	v_mad_i64_i32 v[22:23], null, s49, v11, 0                  // 00000098FBE4: D6FF7C16 02021631
	v_cndmask_b32_e64 v1, -v7, v7, vcc_lo                      // 00000098FBEC: D5010001 21AA0F07
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 00000098FBF4: D5010003 21AA0703
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 00000098FBFC: D5010004 21AA0904
	v_cndmask_b32_e64 v16, -v16, v16, vcc_lo                   // 00000098FC04: D5010010 21AA2110
	v_cndmask_b32_e64 v17, -v17, v17, vcc_lo                   // 00000098FC0C: D5010011 21AA2311
	v_add_f32_e32 v1, v1, v5                                   // 00000098FC14: 06020B01
	v_cndmask_b32_e64 v5, -v6, v6, vcc_lo                      // 00000098FC18: D5010005 21AA0D06
	.long 0xd73c0016                                           // 00000098FC20: D73C0016
	v_cndmask_b32_e32 v1, 1, v22, vcc_lo                       // 00000098FC24: 02022C81
	v_cndmask_b32_e64 v6, -v18, v18, vcc_lo                    // 00000098FC28: D5010006 21AA2512
	v_cndmask_b32_e64 v18, -v19, v19, vcc_lo                   // 00000098FC30: D5010012 21AA2713
	v_dual_add_f32 v3, v3, v2 :: v_dual_add_f32 v4, v4, v9     // 00000098FC38: C9080503 03041304
	v_add_f32_e32 v9, v17, v14                                 // 00000098FC40: 06121D11
	.long 0xd7006a13                                           // 00000098FC44: D7006A13
	v_cndmask_b32_e32 v1, s42, v22, vcc_lo                     // 00000098FC48: 02022C2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 00000098FC4C: BF8701D1
	v_add_co_ci_u32_e64 v22, null, s43, v23, vcc_lo            // 00000098FC50: D5207C16 01AA2E2B
	v_dual_add_f32 v6, v6, v13 :: v_dual_add_f32 v5, v5, v8    // 00000098FC58: C9081B06 06041105
	v_dual_add_f32 v8, v16, v10 :: v_dual_mul_f32 v23, 0x3db504f3, v1// 00000098FC60: C9061510 081602FF 3DB504F3
	v_add_f32_e32 v10, v18, v15                                // 00000098FC6C: 06141F12
	v_dual_mul_f32 v4, 0x3db504f3, v4 :: v_dual_mul_f32 v3, 0x3db504f3, v3// 00000098FC70: C8C608FF 040206FF 3DB504F3
	v_mul_f32_e32 v8, 0x3db504f3, v8                           // 00000098FC7C: 101010FF 3DB504F3
	v_dual_mul_f32 v6, 0x3db504f3, v6 :: v_dual_mul_f32 v5, 0x3db504f3, v5// 00000098FC84: C8C60CFF 06040AFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000098FC90: BF8700C4
	v_mul_f32_e32 v10, 0x3db504f3, v10                         // 00000098FC94: 101414FF 3DB504F3
	s_waitcnt vmcnt(7)                                         // 00000098FC9C: BF891FF7
	.long 0x7f0e3998                                           // 00000098FCA0: 7F0E3998
	.long 0xd7006a01                                           // 00000098FCA4: D7006A01
	v_cndmask_b32_e32 v1, v19, v20, vcc_lo                     // 00000098FCA8: 02022913
	v_add_co_ci_u32_e64 v2, null, v22, v21, vcc_lo             // 00000098FCAC: D5207C02 01AA2B16
	v_fma_mix_f32 v13, v24, v23, neg(0) op_sel_hi:[1,0,0]      // 00000098FCB4: CC20000D 8A022F18
	s_waitcnt vmcnt(6)                                         // 00000098FCBC: BF891BF7
	v_fma_mix_f32 v3, v25, v3, neg(0) op_sel_hi:[1,0,0]        // 00000098FCC0: CC200003 8A020719
	s_waitcnt vmcnt(5)                                         // 00000098FCC8: BF8917F7
	v_fma_mix_f32 v5, v26, v5, neg(0) op_sel_hi:[1,0,0]        // 00000098FCCC: CC200005 8A020B1A
	s_waitcnt vmcnt(4)                                         // 00000098FCD4: BF8913F7
	v_fma_mix_f32 v4, v27, v4, neg(0) op_sel_hi:[1,0,0]        // 00000098FCD8: CC200004 8A02091B
	s_waitcnt vmcnt(3)                                         // 00000098FCE0: BF890FF7
	v_fma_mix_f32 v8, v28, v8, neg(0) op_sel_hi:[1,0,0]        // 00000098FCE4: CC200008 8A02111C
	.long 0x7e30398d                                           // 00000098FCEC: 7E30398D
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 00000098FCF0: 101212FF 3DB504F3
	s_waitcnt vmcnt(2)                                         // 00000098FCF8: BF890BF7
	v_fma_mix_f32 v6, v29, v6, neg(0) op_sel_hi:[1,0,0]        // 00000098FCFC: CC200006 8A020D1D
	s_waitcnt vmcnt(0)                                         // 00000098FD04: BF8903F7
	v_fma_mix_f32 v10, v31, v10, neg(0) op_sel_hi:[1,0,0]      // 00000098FD08: CC20000A 8A02151F
	.long 0x7e0e3983                                           // 00000098FD10: 7E0E3983
	v_and_b32_e32 v14, 1, v24                                  // 00000098FD14: 361C3081
	.long 0x7e303984                                           // 00000098FD18: 7E303984
	v_fma_mix_f32 v9, v30, v9, neg(0) op_sel_hi:[1,0,0]        // 00000098FD1C: CC200009 8A02131E
	.long 0x7e323985                                           // 00000098FD24: 7E323985
	.long 0x7e343988                                           // 00000098FD28: 7E343988
	v_and_b32_e32 v7, 1, v7                                    // 00000098FD2C: 360E0E81
	v_and_b32_e32 v15, 1, v24                                  // 00000098FD30: 361E3081
	.long 0x7e303986                                           // 00000098FD34: 7E303986
	.long 0x7e363989                                           // 00000098FD38: 7E363989
	v_and_b32_e32 v16, 1, v25                                  // 00000098FD3C: 36203281
	v_and_b32_e32 v17, 1, v26                                  // 00000098FD40: 36223481
	v_add3_u32 v3, v3, v7, 0x7fff                              // 00000098FD44: D6550003 03FE0F03 00007FFF
	v_and_b32_e32 v18, 1, v24                                  // 00000098FD50: 36243081
	.long 0x7e30398a                                           // 00000098FD54: 7E30398A
	v_and_b32_e32 v19, 1, v27                                  // 00000098FD58: 36263681
	v_add3_u32 v13, v13, v14, 0x7fff                           // 00000098FD5C: D655000D 03FE1D0D 00007FFF
	v_add3_u32 v5, v5, v16, 0x7fff                             // 00000098FD68: D6550005 03FE2105 00007FFF
	v_add3_u32 v4, v4, v15, 0x7fff                             // 00000098FD74: D6550004 03FE1F04 00007FFF
	v_and_b32_e32 v7, 1, v24                                   // 00000098FD80: 360E3081
	v_add3_u32 v8, v8, v17, 0x7fff                             // 00000098FD84: D6550008 03FE2308 00007FFF
	v_add3_u32 v9, v9, v19, 0x7fff                             // 00000098FD90: D6550009 03FE2709 00007FFF
	v_add3_u32 v6, v6, v18, 0x7fff                             // 00000098FD9C: D6550006 03FE2506 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 00000098FDA8: BF870004
	v_add3_u32 v7, v10, v7, 0x7fff                             // 00000098FDAC: D6550007 03FE0F0A 00007FFF
	s_clause 0x7                                               // 00000098FDB8: BF850007
	global_store_d16_hi_b16 v[1:2], v3, off                    // 00000098FDBC: DC960000 007C0301
	global_store_d16_hi_b16 v[1:2], v13, off offset:32         // 00000098FDC4: DC960020 007C0D01
	global_store_d16_hi_b16 v[1:2], v5, off offset:64          // 00000098FDCC: DC960040 007C0501
	global_store_d16_hi_b16 v[1:2], v4, off offset:96          // 00000098FDD4: DC960060 007C0401
	global_store_d16_hi_b16 v[1:2], v8, off offset:128         // 00000098FDDC: DC960080 007C0801
	global_store_d16_hi_b16 v[1:2], v6, off offset:160         // 00000098FDE4: DC9600A0 007C0601
	global_store_d16_hi_b16 v[1:2], v9, off offset:192         // 00000098FDEC: DC9600C0 007C0901
	global_store_d16_hi_b16 v[1:2], v7, off offset:224         // 00000098FDF4: DC9600E0 007C0701
	s_or_b32 exec_lo, exec_lo, s3                              // 00000098FDFC: 8C7E037E
	s_mov_b32 s4, 0                                            // 00000098FE00: BE840080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000098FE04: BF870009
	s_and_b32 vcc_lo, exec_lo, s4                              // 00000098FE08: 8B6A047E
	s_cbranch_vccz 3504                                        // 00000098FE0C: BFA30DB0 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x5cd0>
	s_mul_hi_i32 s0, s2, 0x66666667                            // 00000098FE10: 9700FF02 66666667
	v_mov_b32_e32 v1, 0                                        // 00000098FE18: 7E020280
	s_lshr_b32 s1, s0, 31                                      // 00000098FE1C: 85019F00
	s_ashr_i32 s0, s0, 1                                       // 00000098FE20: 86008100
	s_mov_b32 s3, exec_lo                                      // 00000098FE24: BE83007E
	s_add_i32 s10, s0, s1                                      // 00000098FE28: 810A0100
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000098FE2C: BF870499
	s_ashr_i32 s11, s10, 31                                    // 00000098FE30: 860B9F0A
	s_lshl_b64 s[0:1], s[10:11], 2                             // 00000098FE34: 8480820A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000098FE38: BF870009
	s_add_u32 s0, s16, s0                                      // 00000098FE3C: 80000010
	s_addc_u32 s1, s17, s1                                     // 00000098FE40: 82010111
	global_load_b32 v1, v1, s[0:1]                             // 00000098FE44: DC520000 01000001
	s_waitcnt vmcnt(0)                                         // 00000098FE4C: BF8903F7
	v_readfirstlane_b32 s1, v1                                 // 00000098FE50: 7E020501
	v_cmpx_gt_u32_e32 0x140, v0                                // 00000098FE54: 7D9800FF 00000140
	s_cbranch_execz 44                                         // 00000098FE5C: BFA5002C <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2710>
	s_mul_hi_i32 s0, s2, 0x51eb851f                            // 00000098FE60: 9700FF02 51EB851F
	v_lshlrev_b32_e32 v4, 4, v0                                // 00000098FE68: 30080084
	s_lshr_b32 s4, s0, 31                                      // 00000098FE6C: 85049F00
	s_ashr_i32 s0, s0, 4                                       // 00000098FE70: 86008400
	v_or_b32_e32 v3, 0xffffff00, v0                            // 00000098FE74: 380600FF FFFFFF00
	s_add_i32 s0, s0, s4                                       // 00000098FE7C: 81000400
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000098FE80: BF8700D9
	s_mul_i32 s4, s0, 0x1400                                   // 00000098FE84: 9604FF00 00001400
	s_mul_hi_i32 s0, s0, 0x1400                                // 00000098FE8C: 9700FF00 00001400
	s_add_u32 s4, s14, s4                                      // 00000098FE94: 8004040E
	s_addc_u32 s0, s15, s0                                     // 00000098FE98: 8200000F
	.long 0xd7000401                                           // 00000098FE9C: D7000401
	v_cndmask_b32_e32 v1, s4, v4, vcc_lo                       // 00000098FEA0: 02020804
	v_add_co_ci_u32_e64 v2, null, s0, 0, s4                    // 00000098FEA4: D5207C02 00110000
	s_mov_b32 s4, 0                                            // 00000098FEAC: BE840080
	s_nop 0                                                    // 00000098FEB0: BF800000
	s_nop 0                                                    // 00000098FEB4: BF800000
	s_nop 0                                                    // 00000098FEB8: BF800000
	s_nop 0                                                    // 00000098FEBC: BF800000
	global_load_b128 v[5:8], v[1:2], off                       // 00000098FEC0: DC5E0000 057C0001
	v_add_nc_u32_e32 v3, 0x100, v3                             // 00000098FEC8: 4A0606FF 00000100
	.long 0xd7006a01                                           // 00000098FED0: D7006A01
	v_cndmask_b32_e32 v1, 0x1000, v1, vcc_lo                   // 00000098FED4: 020202FF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000098FEDC: BF870191
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 00000098FEE0: D5207C02 01AA0480
	.long 0xd4490000                                           // 00000098FEE8: D4490000
	v_cndmask_b32_e32 v1, 63, v3, vcc_lo                       // 00000098FEEC: 020206BF
	s_or_b32 s4, s0, s4                                        // 00000098FEF0: 8C040400
	s_waitcnt vmcnt(0)                                         // 00000098FEF4: BF8903F7
	ds_store_b128 v4, v[5:8] offset:10240                      // 00000098FEF8: DB7C2800 00000504
	v_add_nc_u32_e32 v4, 0x1000, v4                            // 00000098FF00: 4A0808FF 00001000
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000098FF08: 917E047E
	s_cbranch_execnz 65516                                     // 00000098FF0C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x26c0>
	s_or_b32 exec_lo, exec_lo, s3                              // 00000098FF10: 8C7E037E
	v_mul_u32_u24_e32 v1, 20, v11                              // 00000098FF14: 16021694
	s_mul_i32 s0, s10, -5                                      // 00000098FF18: 9600C50A
	s_mul_i32 s4, s1, 0x190000                                 // 00000098FF1C: 9604FF01 00190000
	s_mul_hi_i32 s3, s1, 0x190000                              // 00000098FF24: 9703FF01 00190000
	s_add_i32 s2, s0, s2                                       // 00000098FF2C: 81020200
	v_min_u32_e32 v2, 0x8c, v1                                 // 00000098FF30: 260402FF 0000008C
	s_add_u32 s0, s12, s4                                      // 00000098FF38: 8000040C
	s_addc_u32 s4, s13, s3                                     // 00000098FF3C: 8204030D
	s_mul_i32 s3, s2, 0x50000                                  // 00000098FF40: 9603FF02 00050000
	v_lshlrev_b32_e32 v7, 2, v12                               // 00000098FF48: 300E1882
	v_add_nc_u32_e32 v8, 20, v2                                // 00000098FF4C: 4A100494
	s_mul_hi_i32 s5, s2, 0x50000                               // 00000098FF50: 9705FF02 00050000
	s_add_u32 s3, s0, s3                                       // 00000098FF58: 80030300
	s_addc_u32 s4, s4, s5                                      // 00000098FF5C: 82040504
	s_waitcnt lgkmcnt(0)                                       // 00000098FF60: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 00000098FF64: BC7C0000
	v_cmp_lt_u32_e32 vcc_lo, v1, v8                            // 00000098FF68: 7C921101
	s_barrier                                                  // 00000098FF6C: BFBD0000
	buffer_gl0_inv                                             // 00000098FF70: E0AC0000 00000000
	s_and_saveexec_b32 s5, vcc_lo                              // 00000098FF78: BE85206A
	s_cbranch_execz 139                                        // 00000098FF7C: BFA5008B <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x29ac>
	.long 0xd7010002                                           // 00000098FF80: D7010002
	v_cndmask_b32_e32 v0, v12, v129, vcc_lo                    // 00000098FF84: 0201030C
	v_mul_u32_u24_e32 v5, 0xa000, v11                          // 00000098FF88: 160A16FF 0000A000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000098FF90: BF870092
	v_cndmask_b32_e64 v2, v2, 31, s0                           // 00000098FF94: D5010002 00013F02
	.long 0xd44c0000                                           // 00000098FF9C: D44C0000
	v_cndmask_b32_e32 v1, 31, v2, vcc_lo                       // 00000098FFA0: 0202049F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000098FFA4: BF8700B1
	v_cndmask_b32_e64 v4, 0xe1, 1, s0                          // 00000098FFA8: D5010004 000102FF 000000E1
	v_mov_b32_e32 v3, 0                                        // 00000098FFB4: 7E060280
	.long 0xd700000d                                           // 00000098FFB8: D700000D
	v_cndmask_b32_e32 v1, s3, v5, vcc_lo                       // 00000098FFBC: 02020A03
	v_add_co_ci_u32_e64 v14, null, s4, 0, s0                   // 00000098FFC0: D5207C0E 00010004
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000098FFC8: BF870214
	v_add_nc_u32_e32 v4, v4, v2                                // 00000098FFCC: 4A080504
	.long 0xd73c0002                                           // 00000098FFD0: D73C0002
	v_cndmask_b32_e32 v1, 2, v2, vcc_lo                        // 00000098FFD4: 02020482
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000098FFD8: BF8701A2
	v_lshlrev_b32_e32 v6, 24, v4                               // 00000098FFDC: 300C0898
	v_bfe_i32 v4, v4, 7, 1                                     // 00000098FFE0: D6110004 02050F04
	.long 0xd7000005                                           // 00000098FFE8: D7000005
	v_cndmask_b32_e32 v1, v13, v2, vcc_lo                      // 00000098FFEC: 0202050D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000098FFF0: BF870123
	v_ashrrev_i32_e32 v9, 22, v6                               // 00000098FFF4: 34120C96
	v_add_co_ci_u32_e64 v6, null, v14, v3, s0                  // 00000098FFF8: D5207C06 0002070E
	.long 0xd7000009                                           // 000000990000: D7000009
	v_cndmask_b32_e32 v1, v13, v9, vcc_lo                      // 000000990004: 0202130D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000990008: BF8700A1
	v_add_co_ci_u32_e64 v10, null, v14, v4, s0                 // 00000099000C: D5207C0A 0002090E
	.long 0xd700000d                                           // 000000990014: D700000D
	v_cndmask_b32_e32 v1, v13, v7, vcc_lo                      // 000000990018: 02020F0D
	v_add_co_ci_u32_e64 v14, null, 0, v14, s0                  // 00000099001C: D5207C0E 00021C80
	s_clause 0x1f                                              // 000000990024: BF85001F
	global_load_b32 v2, v[5:6], off                            // 000000990028: DC520000 027C0005
	global_load_b32 v105, v[5:6], off offset:128               // 000000990030: DC520080 697C0005
	global_load_b32 v102, v[5:6], off offset:256               // 000000990038: DC520100 667C0005
	global_load_b32 v99, v[5:6], off offset:384                // 000000990040: DC520180 637C0005
	global_load_b32 v96, v[5:6], off offset:512                // 000000990048: DC520200 607C0005
	global_load_b32 v93, v[5:6], off offset:640                // 000000990050: DC520280 5D7C0005
	global_load_b32 v90, v[5:6], off offset:768                // 000000990058: DC520300 5A7C0005
	global_load_b32 v87, v[5:6], off offset:896                // 000000990060: DC520380 577C0005
	global_load_b32 v4, v[9:10], off                           // 000000990068: DC520000 047C0009
	global_load_b32 v106, v[9:10], off offset:128              // 000000990070: DC520080 6A7C0009
	global_load_b32 v103, v[9:10], off offset:256              // 000000990078: DC520100 677C0009
	global_load_b32 v100, v[9:10], off offset:384              // 000000990080: DC520180 647C0009
	global_load_b32 v97, v[9:10], off offset:512               // 000000990088: DC520200 617C0009
	global_load_b32 v94, v[9:10], off offset:640               // 000000990090: DC520280 5E7C0009
	global_load_b32 v91, v[9:10], off offset:768               // 000000990098: DC520300 5B7C0009
	global_load_b32 v88, v[9:10], off offset:896               // 0000009900A0: DC520380 587C0009
	global_load_b32 v3, v[13:14], off                          // 0000009900A8: DC520000 037C000D
	global_load_b32 v104, v[13:14], off offset:128             // 0000009900B0: DC520080 687C000D
	global_load_b32 v101, v[13:14], off offset:256             // 0000009900B8: DC520100 657C000D
	global_load_b32 v98, v[13:14], off offset:384              // 0000009900C0: DC520180 627C000D
	global_load_b32 v95, v[13:14], off offset:512              // 0000009900C8: DC520200 5F7C000D
	global_load_b32 v92, v[13:14], off offset:640              // 0000009900D0: DC520280 5C7C000D
	global_load_b32 v89, v[13:14], off offset:768              // 0000009900D8: DC520300 597C000D
	global_load_b32 v86, v[13:14], off offset:896              // 0000009900E0: DC520380 567C000D
	global_load_b32 v84, v[5:6], off offset:1024               // 0000009900E8: DC520400 547C0005
	global_load_b32 v81, v[5:6], off offset:1152               // 0000009900F0: DC520480 517C0005
	global_load_b32 v78, v[5:6], off offset:1280               // 0000009900F8: DC520500 4E7C0005
	global_load_b32 v75, v[5:6], off offset:1408               // 000000990100: DC520580 4B7C0005
	global_load_b32 v63, v[5:6], off offset:1536               // 000000990108: DC520600 3F7C0005
	global_load_b32 v37, v[5:6], off offset:1664               // 000000990110: DC520680 257C0005
	global_load_b32 v31, v[5:6], off offset:1792               // 000000990118: DC520700 1F7C0005
	global_load_b32 v26, v[5:6], off offset:1920               // 000000990120: DC520780 1A7C0005
	s_clause 0xf                                               // 000000990128: BF85000F
	global_load_b32 v85, v[9:10], off offset:1024              // 00000099012C: DC520400 557C0009
	global_load_b32 v82, v[9:10], off offset:1152              // 000000990134: DC520480 527C0009
	global_load_b32 v79, v[9:10], off offset:1280              // 00000099013C: DC520500 4F7C0009
	global_load_b32 v76, v[9:10], off offset:1408              // 000000990144: DC520580 4C7C0009
	global_load_b32 v73, v[9:10], off offset:1536              // 00000099014C: DC520600 497C0009
	global_load_b32 v38, v[9:10], off offset:1664              // 000000990154: DC520680 267C0009
	global_load_b32 v32, v[9:10], off offset:1792              // 00000099015C: DC520700 207C0009
	global_load_b32 v29, v[9:10], off offset:1920              // 000000990164: DC520780 1D7C0009
	global_load_b32 v83, v[13:14], off offset:1024             // 00000099016C: DC520400 537C000D
	global_load_b32 v80, v[13:14], off offset:1152             // 000000990174: DC520480 507C000D
	global_load_b32 v77, v[13:14], off offset:1280             // 00000099017C: DC520500 4D7C000D
	global_load_b32 v74, v[13:14], off offset:1408             // 000000990184: DC520580 4A7C000D
	global_load_b32 v39, v[13:14], off offset:1536             // 00000099018C: DC520600 277C000D
	global_load_b32 v36, v[13:14], off offset:1664             // 000000990194: DC520680 247C000D
	global_load_b32 v30, v[13:14], off offset:1792             // 00000099019C: DC520700 1E7C000D
	global_load_b32 v18, v[13:14], off offset:1920             // 0000009901A4: DC520780 127C000D
	s_or_b32 exec_lo, exec_lo, s5                              // 0000009901AC: 8C7E057E
	v_dual_mov_b32 v17, 0 :: v_dual_mov_b32 v10, 0             // 0000009901B0: CA100080 110A0080
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v14, 0              // 0000009901B8: CA100080 090E0080
	v_dual_mov_b32 v13, 0 :: v_dual_mov_b32 v16, 0             // 0000009901C0: CA100080 0D100080
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v20, 0             // 0000009901C8: CA100080 0F140080
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v22, 0             // 0000009901D0: CA100080 13160080
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v24, 0             // 0000009901D8: CA100080 15180080
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v28, 0             // 0000009901E0: CA100080 171C0080
	v_mov_b32_e32 v25, 0                                       // 0000009901E8: 7E320280
	v_mov_b32_e32 v27, 0                                       // 0000009901EC: 7E360280
	s_and_saveexec_b32 s0, vcc_lo                              // 0000009901F0: BE80206A
	s_cbranch_execz 1779                                       // 0000009901F4: BFA506F3 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x45c4>
	v_dual_mov_b32 v6, 0 :: v_dual_add_nc_u32 v5, -1, v0       // 0000009901F8: CA200080 060400C1
	v_dual_mov_b32 v10, 0 :: v_dual_lshlrev_b32 v33, 2, v12    // 000000990200: CA220080 0A201882
	v_and_or_b32 v34, v0, 16, 0x2800                           // 000000990208: D6570022 03FD2100 00002800
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000990214: BF870243
	v_dual_mov_b32 v16, 0 :: v_dual_and_b32 v5, 31, v5         // 000000990218: CA240080 10040A9F
	v_dual_mov_b32 v17, 0 :: v_dual_mov_b32 v14, 0             // 000000990220: CA100080 110E0080
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v20, 0              // 000000990228: CA100080 09140080
	v_dual_mov_b32 v13, 0 :: v_dual_mov_b32 v22, 0             // 000000990230: CA100080 0D160080
	v_dual_mov_b32 v24, 0 :: v_dual_lshlrev_b32 v35, 2, v5     // 000000990238: CA220080 18220A82
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v28, 0             // 000000990240: CA100080 0F1C0080
	v_mov_b32_e32 v19, 0                                       // 000000990248: 7E260280
	v_mov_b32_e32 v21, 0                                       // 00000099024C: 7E2A0280
	v_mov_b32_e32 v23, 0                                       // 000000990250: 7E2E0280
	v_mov_b32_e32 v25, 0                                       // 000000990254: 7E320280
	v_mov_b32_e32 v27, 0                                       // 000000990258: 7E360280
	s_mov_b32 s5, 0                                            // 00000099025C: BE850080
	s_movk_i32 s6, 0x1eee                                      // 000000990260: B0061EEE
	s_branch 1661                                              // 000000990264: BFA0067D <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x445c>
	s_or_b32 exec_lo, exec_lo, s7                              // 000000990268: 8C7E077E
	s_waitcnt vmcnt(39)                                        // 00000099026C: BF899FF7
	v_alignbit_b32 v107, v2, v4, 16                            // 000000990270: D616006B 02420902
	s_waitcnt vmcnt(31)                                        // 000000990278: BF897FF7
	v_bfe_u32 v108, v3, 12, 16                                 // 00000099027C: D610006C 02411903
	v_lshl_add_u32 v1, v1, 5, v34                              // 000000990284: D6460001 04890B01
	v_bfe_u32 v109, v3, 8, 16                                  // 00000099028C: D610006D 02411103
	v_bfe_u32 v110, v3, 4, 16                                  // 000000990294: D610006E 02410903
	v_bfe_u32 v111, v107, 12, 16                               // 00000099029C: D610006F 0241196B
	v_bfe_u32 v114, v107, 8, 16                                // 0000009902A4: D6100072 0241116B
	.long 0xd72c006c                                           // 0000009902AC: D72C006C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v108, vcc_lo             // 0000009902B0: 0202D8FF 83DCD12D
	v_and_b32_e32 v112, 0xffff, v3                             // 0000009902B8: 36E006FF 0000FFFF
	ds_load_b128 v[1:4], v1                                    // 0000009902C0: DBFC0000 01000001
	.long 0xd72c006f                                           // 0000009902C8: D72C006F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v111, vcc_lo             // 0000009902CC: 0202DEFF 83DCD12D
	.long 0xd72c0072                                           // 0000009902D4: D72C0072
	v_cndmask_b32_e32 v1, 0x83dcd12d, v114, vcc_lo             // 0000009902D8: 0202E4FF 83DCD12D
	.long 0xd72c006d                                           // 0000009902E0: D72C006D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v109, vcc_lo             // 0000009902E4: 0202DAFF 83DCD12D
	.long 0xd72c0070                                           // 0000009902EC: D72C0070
	v_cndmask_b32_e32 v1, 0x83dcd12d, v112, vcc_lo             // 0000009902F0: 0202E0FF 83DCD12D
	.long 0xd72c006e                                           // 0000009902F8: D72C006E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v110, vcc_lo             // 0000009902FC: 0202DCFF 83DCD12D
	v_sad_u8 v108, v108, 0, 0x6400                             // 000000990304: D622006C 03FD016C 00006400
	v_alignbit_b32 v105, v105, v106, 16                        // 000000990310: D6160069 0242D569
	v_alignbit_b32 v102, v102, v103, 16                        // 000000990318: D6160066 0242CF66
	v_sad_u8 v111, v111, 0, 0x6400                             // 000000990320: D622006F 03FD016F 00006400
	v_sad_u8 v114, v114, 0, 0x6400                             // 00000099032C: D6220072 03FD0172 00006400
	v_sad_u8 v109, v109, 0, 0x6400                             // 000000990338: D622006D 03FD016D 00006400
	v_and_b32_e32 v108, 0xffff, v108                           // 000000990344: 36D8D8FF 0000FFFF
	v_sad_u8 v106, v112, 0, 0x6400                             // 00000099034C: D622006A 03FD0170 00006400
	v_and_b32_e32 v111, 0xffff, v111                           // 000000990358: 36DEDEFF 0000FFFF
	v_sad_u8 v110, v110, 0, 0x6400                             // 000000990360: D622006E 03FD016E 00006400
	v_and_b32_e32 v112, 0xffff, v105                           // 00000099036C: 36E0D2FF 0000FFFF
	v_lshl_or_b32 v108, v109, 16, v108                         // 000000990374: D656006C 05B1216D
	v_lshlrev_b32_e32 v106, 16, v106                           // 00000099037C: 30D4D490
	v_lshl_or_b32 v111, v114, 16, v111                         // 000000990380: D656006F 05BD2172
	s_waitcnt vmcnt(30)                                        // 000000990388: BF897BF7
	v_and_b32_e32 v114, 0xffff, v104                           // 00000099038C: 36E4D0FF 0000FFFF
	.long 0xd72c0070                                           // 000000990394: D72C0070
	v_cndmask_b32_e32 v1, 0x83dcd12d, v112, vcc_lo             // 000000990398: 0202E0FF 83DCD12D
	v_pk_fma_f16 v108, v108, s6, 0xc931 op_sel_hi:[1,0,0]      // 0000009903A0: CC0E006C 0BFC0D6C 0000C931
	v_and_or_b32 v106, 0xffff, v110, v106                      // 0000009903AC: D657006A 05AADCFF 0000FFFF
	v_pk_fma_f16 v109, v111, s6, 0xc931 op_sel_hi:[1,0,0]      // 0000009903B8: CC0E006D 0BFC0D6F 0000C931
	v_and_b32_e32 v113, 0xffff, v107                           // 0000009903C4: 36E2D6FF 0000FFFF
	v_bfe_u32 v107, v107, 4, 16                                // 0000009903CC: D610006B 0241096B
	v_bfe_u32 v111, v105, 12, 16                               // 0000009903D4: D610006F 02411969
	v_bfe_u32 v110, v105, 8, 16                                // 0000009903DC: D610006E 02411169
	s_waitcnt lgkmcnt(0)                                       // 0000009903E4: BF89FC07
	v_dot2acc_f32_f16 v28, v109, v1                            // 0000009903E8: 0438036D
	.long 0xd72c0071                                           // 0000009903EC: D72C0071
	v_cndmask_b32_e32 v1, 0x83dcd12d, v113, vcc_lo             // 0000009903F0: 0202E2FF 83DCD12D
	.long 0xd72c006b                                           // 0000009903F8: D72C006B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v107, vcc_lo             // 0000009903FC: 0202D6FF 83DCD12D
	.long 0xd72c006f                                           // 000000990404: D72C006F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v111, vcc_lo             // 000000990408: 0202DEFF 83DCD12D
	v_bfe_u32 v105, v105, 4, 16                                // 000000990410: D6100069 02410969
	.long 0xd72c006e                                           // 000000990418: D72C006E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v110, vcc_lo             // 00000099041C: 0202DCFF 83DCD12D
	v_bfe_u32 v109, v104, 12, 16                               // 000000990424: D610006D 02411968
	v_pk_fma_f16 v106, v106, s6, 0xc931 op_sel_hi:[1,0,0]      // 00000099042C: CC0E006A 0BFC0D6A 0000C931
	v_sad_u8 v112, v112, 0, 0x6400                             // 000000990438: D6220070 03FD0170 00006400
	v_sad_u8 v113, v113, 0, 0x6400                             // 000000990444: D6220071 03FD0171 00006400
	v_sad_u8 v107, v107, 0, 0x6400                             // 000000990450: D622006B 03FD016B 00006400
	v_sad_u8 v111, v111, 0, 0x6400                             // 00000099045C: D622006F 03FD016F 00006400
	.long 0xd72c0069                                           // 000000990468: D72C0069
	v_cndmask_b32_e32 v1, 0x83dcd12d, v105, vcc_lo             // 00000099046C: 0202D2FF 83DCD12D
	v_sad_u8 v110, v110, 0, 0x6400                             // 000000990474: D622006E 03FD016E 00006400
	v_lshlrev_b32_e32 v113, 16, v113                           // 000000990480: 30E2E290
	.long 0xd72c006d                                           // 000000990484: D72C006D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v109, vcc_lo             // 000000990488: 0202DAFF 83DCD12D
	.long 0xd72c0072                                           // 000000990490: D72C0072
	v_cndmask_b32_e32 v1, 0x83dcd12d, v114, vcc_lo             // 000000990494: 0202E4FF 83DCD12D
	v_lshlrev_b32_e32 v112, 16, v112                           // 00000099049C: 30E0E090
	v_alignbit_b32 v99, v99, v100, 16                          // 0000009904A0: D6160063 0242C963
	v_and_or_b32 v107, 0xffff, v107, v113                      // 0000009904A8: D657006B 05C6D6FF 0000FFFF
	v_bfe_u32 v113, v104, 8, 16                                // 0000009904B4: D6100071 02411168
	v_bfe_u32 v104, v104, 4, 16                                // 0000009904BC: D6100068 02410968
	v_sad_u8 v105, v105, 0, 0x6400                             // 0000009904C4: D6220069 03FD0169 00006400
	v_sad_u8 v109, v109, 0, 0x6400                             // 0000009904D0: D622006D 03FD016D 00006400
	v_pk_fma_f16 v107, v107, s6, 0xc931 op_sel_hi:[1,0,0]      // 0000009904DC: CC0E006B 0BFC0D6B 0000C931
	.long 0xd72c0071                                           // 0000009904E8: D72C0071
	v_cndmask_b32_e32 v1, 0x83dcd12d, v113, vcc_lo             // 0000009904EC: 0202E2FF 83DCD12D
	.long 0xd72c0068                                           // 0000009904F4: D72C0068
	v_cndmask_b32_e32 v1, 0x83dcd12d, v104, vcc_lo             // 0000009904F8: 0202D0FF 83DCD12D
	v_and_or_b32 v105, 0xffff, v105, v112                      // 000000990500: D6570069 05C2D2FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000099050C: BF870234
	v_dual_dot2acc_f32_f16 v28, v107, v2 :: v_dual_and_b32 v109, 0xffff, v109// 000000990510: CB24056B 1C6CDAFF 0000FFFF
	v_alignbit_b32 v96, v96, v97, 16                           // 00000099051C: D6160060 0242C360
	v_alignbit_b32 v93, v93, v94, 16                           // 000000990524: D616005D 0242BD5D
	v_pk_fma_f16 v105, v105, s6, 0xc931 op_sel_hi:[1,0,0]      // 00000099052C: CC0E0069 0BFC0D69 0000C931
	v_alignbit_b32 v90, v90, v91, 16                           // 000000990538: D616005A 0242B75A
	v_dot2acc_f32_f16 v28, v108, v3                            // 000000990540: 0438076C
	v_and_b32_e32 v111, 0xffff, v111                           // 000000990544: 36DEDEFF 0000FFFF
	v_sad_u8 v104, v104, 0, 0x6400                             // 00000099054C: D6220068 03FD0168 00006400
	v_bfe_u32 v108, v102, 12, 16                               // 000000990558: D610006C 02411966
	v_alignbit_b32 v87, v87, v88, 16                           // 000000990560: D6160057 0242B157
	v_dot2acc_f32_f16 v28, v106, v4                            // 000000990568: 0438096A
	v_lshl_or_b32 v110, v110, 16, v111                         // 00000099056C: D656006E 05BD216E
	v_sad_u8 v111, v113, 0, 0x6400                             // 000000990574: D622006F 03FD0171 00006400
	v_bfe_u32 v106, v102, 4, 16                                // 000000990580: D610006A 02410966
	s_waitcnt vmcnt(15)                                        // 000000990588: BF893FF7
	v_alignbit_b32 v84, v84, v85, 16                           // 00000099058C: D6160054 0242AB54
	s_waitcnt vmcnt(14)                                        // 000000990594: BF893BF7
	v_alignbit_b32 v81, v81, v82, 16                           // 000000990598: D6160051 0242A551
	v_pk_fma_f16 v107, v110, s6, 0xc931 op_sel_hi:[1,0,0]      // 0000009905A0: CC0E006B 0BFC0D6E 0000C931
	v_sad_u8 v110, v114, 0, 0x6400                             // 0000009905AC: D622006E 03FD0172 00006400
	v_lshl_or_b32 v109, v111, 16, v109                         // 0000009905B8: D656006D 05B5216F
	.long 0xd72c006a                                           // 0000009905C0: D72C006A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v106, vcc_lo             // 0000009905C4: 0202D4FF 83DCD12D
	s_waitcnt vmcnt(13)                                        // 0000009905CC: BF8937F7
	v_alignbit_b32 v78, v78, v79, 16                           // 0000009905D0: D616004E 02429F4E
	v_dot2acc_f32_f16 v27, v107, v1                            // 0000009905D8: 0436036B
	v_lshlrev_b32_e32 v103, 16, v110                           // 0000009905DC: 30CEDC90
	v_pk_fma_f16 v107, v109, s6, 0xc931 op_sel_hi:[1,0,0]      // 0000009905E0: CC0E006B 0BFC0D6D 0000C931
	v_and_b32_e32 v109, 0xffff, v101                           // 0000009905EC: 36DACAFF 0000FFFF
	v_bfe_u32 v110, v98, 4, 16                                 // 0000009905F4: D610006E 02410962
	v_dot2acc_f32_f16 v27, v105, v2                            // 0000009905FC: 04360569
	v_and_or_b32 v103, 0xffff, v104, v103                      // 000000990600: D6570067 059ED0FF 0000FFFF
	.long 0xd72c0068                                           // 00000099060C: D72C0068
	v_cndmask_b32_e32 v1, 0x83dcd12d, v108, vcc_lo             // 000000990610: 0202D8FF 83DCD12D
	v_bfe_u32 v105, v102, 8, 16                                // 000000990618: D6100069 02411166
	v_bfe_u32 v108, v101, 8, 16                                // 000000990620: D610006C 02411165
	v_dot2acc_f32_f16 v27, v107, v3                            // 000000990628: 0436076B
	v_bfe_u32 v107, v101, 12, 16                               // 00000099062C: D610006B 02411965
	v_bfe_u32 v101, v101, 4, 16                                // 000000990634: D6100065 02410965
	.long 0xd72c0069                                           // 00000099063C: D72C0069
	v_cndmask_b32_e32 v1, 0x83dcd12d, v105, vcc_lo             // 000000990640: 0202D2FF 83DCD12D
	.long 0xd72c006d                                           // 000000990648: D72C006D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v109, vcc_lo             // 00000099064C: 0202DAFF 83DCD12D
	v_sad_u8 v104, v104, 0, 0x6400                             // 000000990654: D6220068 03FD0168 00006400
	v_pk_fma_f16 v103, v103, s6, 0xc931 op_sel_hi:[1,0,0]      // 000000990660: CC0E0067 0BFC0D67 0000C931
	v_and_b32_e32 v102, 0xffff, v102                           // 00000099066C: 36CCCCFF 0000FFFF
	.long 0xd72c0065                                           // 000000990674: D72C0065
	v_cndmask_b32_e32 v1, 0x83dcd12d, v101, vcc_lo             // 000000990678: 0202CAFF 83DCD12D
	.long 0xd72c006b                                           // 000000990680: D72C006B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v107, vcc_lo             // 000000990684: 0202D6FF 83DCD12D
	v_and_b32_e32 v104, 0xffff, v104                           // 00000099068C: 36D0D0FF 0000FFFF
	v_sad_u8 v105, v105, 0, 0x6400                             // 000000990694: D6220069 03FD0169 00006400
	v_dot2acc_f32_f16 v27, v103, v4                            // 0000009906A0: 04360967
	.long 0xd72c0066                                           // 0000009906A4: D72C0066
	v_cndmask_b32_e32 v1, 0x83dcd12d, v102, vcc_lo             // 0000009906A8: 0202CCFF 83DCD12D
	.long 0xd72c006c                                           // 0000009906B0: D72C006C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v108, vcc_lo             // 0000009906B4: 0202D8FF 83DCD12D
	v_bfe_u32 v103, v95, 4, 16                                 // 0000009906BC: D6100067 0241095F
	v_lshl_or_b32 v104, v105, 16, v104                         // 0000009906C4: D6560068 05A12169
	v_sad_u8 v105, v106, 0, 0x6400                             // 0000009906CC: D6220069 03FD016A 00006400
	v_sad_u8 v106, v109, 0, 0x6400                             // 0000009906D8: D622006A 03FD016D 00006400
	v_sad_u8 v101, v101, 0, 0x6400                             // 0000009906E4: D6220065 03FD0165 00006400
	v_sad_u8 v107, v107, 0, 0x6400                             // 0000009906F0: D622006B 03FD016B 00006400
	v_sad_u8 v102, v102, 0, 0x6400                             // 0000009906FC: D6220066 03FD0166 00006400
	v_sad_u8 v108, v108, 0, 0x6400                             // 000000990708: D622006C 03FD016C 00006400
	v_lshlrev_b32_e32 v106, 16, v106                           // 000000990714: 30D4D490
	v_bfe_u32 v109, v98, 8, 16                                 // 000000990718: D610006D 02411162
	v_and_b32_e32 v107, 0xffff, v107                           // 000000990720: 36D6D6FF 0000FFFF
	v_pk_fma_f16 v104, v104, s6, 0xc931 op_sel_hi:[1,0,0]      // 000000990728: CC0E0068 0BFC0D68 0000C931
	s_waitcnt vmcnt(12)                                        // 000000990734: BF8933F7
	v_alignbit_b32 v75, v75, v76, 16                           // 000000990738: D616004B 0242994B
	v_and_or_b32 v101, 0xffff, v101, v106                      // 000000990740: D6570065 05AACAFF 0000FFFF
	v_and_b32_e32 v106, 0xffff, v99                            // 00000099074C: 36D4C6FF 0000FFFF
	.long 0xd72c006d                                           // 000000990754: D72C006D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v109, vcc_lo             // 000000990758: 0202DAFF 83DCD12D
	v_dot2acc_f32_f16 v25, v104, v1                            // 000000990760: 04320368
	v_bfe_u32 v76, v75, 12, 16                                 // 000000990764: D610004C 0241194B
	v_pk_fma_f16 v101, v101, s6, 0xc931 op_sel_hi:[1,0,0]      // 00000099076C: CC0E0065 0BFC0D65 0000C931
	v_lshlrev_b32_e32 v102, 16, v102                           // 000000990778: 30CCCC90
	.long 0xd72c006a                                           // 00000099077C: D72C006A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v106, vcc_lo             // 000000990780: 0202D4FF 83DCD12D
	s_waitcnt vmcnt(11)                                        // 000000990788: BF892FF7
	v_alignbit_b32 v63, v63, v73, 16                           // 00000099078C: D616003F 0242933F
	.long 0xd72c004c                                           // 000000990794: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000990798: 020298FF 83DCD12D
	s_waitcnt vmcnt(10)                                        // 0000009907A0: BF892BF7
	v_alignbit_b32 v37, v37, v38, 16                           // 0000009907A4: D6160025 02424D25
	v_and_or_b32 v100, 0xffff, v105, v102                      // 0000009907AC: D6570064 059AD2FF 0000FFFF
	v_bfe_u32 v105, v99, 12, 16                                // 0000009907B8: D6100069 02411963
	v_lshl_or_b32 v102, v108, 16, v107                         // 0000009907C0: D6560066 05AD216C
	v_bfe_u32 v107, v99, 8, 16                                 // 0000009907C8: D610006B 02411163
	v_bfe_u32 v99, v99, 4, 16                                  // 0000009907D0: D6100063 02410963
	v_bfe_u32 v108, v98, 12, 16                                // 0000009907D8: D610006C 02411962
	.long 0xd72c0069                                           // 0000009907E0: D72C0069
	v_cndmask_b32_e32 v1, 0x83dcd12d, v105, vcc_lo             // 0000009907E4: 0202D2FF 83DCD12D
	v_sad_u8 v106, v106, 0, 0x6400                             // 0000009907EC: D622006A 03FD016A 00006400
	.long 0xd72c006b                                           // 0000009907F8: D72C006B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v107, vcc_lo             // 0000009907FC: 0202D6FF 83DCD12D
	.long 0xd72c0063                                           // 000000990804: D72C0063
	v_cndmask_b32_e32 v1, 0x83dcd12d, v99, vcc_lo              // 000000990808: 0202C6FF 83DCD12D
	.long 0xd72c006c                                           // 000000990810: D72C006C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v108, vcc_lo             // 000000990814: 0202D8FF 83DCD12D
	v_pk_fma_f16 v100, v100, s6, 0xc931 op_sel_hi:[1,0,0]      // 00000099081C: CC0E0064 0BFC0D64 0000C931
	v_lshlrev_b32_e32 v106, 16, v106                           // 000000990828: 30D4D490
	v_pk_fma_f16 v102, v102, s6, 0xc931 op_sel_hi:[1,0,0]      // 00000099082C: CC0E0066 0BFC0D66 0000C931
	v_sad_u8 v105, v105, 0, 0x6400                             // 000000990838: D6220069 03FD0169 00006400
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000990844: D622004C 03FD014C 00006400
	v_sad_u8 v107, v107, 0, 0x6400                             // 000000990850: D622006B 03FD016B 00006400
	v_sad_u8 v99, v99, 0, 0x6400                               // 00000099085C: D6220063 03FD0163 00006400
	v_sad_u8 v108, v108, 0, 0x6400                             // 000000990868: D622006C 03FD016C 00006400
	v_and_b32_e32 v105, 0xffff, v105                           // 000000990874: 36D2D2FF 0000FFFF
	v_dual_dot2acc_f32_f16 v25, v100, v2 :: v_dual_and_b32 v76, 0xffff, v76// 00000099087C: CB240564 194C98FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000990888: BF870214
	v_and_or_b32 v99, 0xffff, v99, v106                        // 00000099088C: D6570063 05AAC6FF 0000FFFF
	v_and_b32_e32 v106, 0xffff, v108                           // 000000990898: 36D4D8FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009908A0: BF870004
	v_lshl_or_b32 v104, v107, 16, v105                         // 0000009908A4: D6560068 05A5216B
	v_sad_u8 v107, v109, 0, 0x6400                             // 0000009908AC: D622006B 03FD016D 00006400
	v_dot2acc_f32_f16 v25, v102, v3                            // 0000009908B8: 04320766
	v_pk_fma_f16 v99, v99, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000009908BC: CC0E0063 0BFC0D63 0000C931
	v_bfe_u32 v102, v95, 8, 16                                 // 0000009908C8: D6100066 0241115F
	v_pk_fma_f16 v100, v104, s6, 0xc931 op_sel_hi:[1,0,0]      // 0000009908D0: CC0E0064 0BFC0D68 0000C931
	v_lshl_or_b32 v104, v107, 16, v106                         // 0000009908DC: D6560068 05A9216B
	v_dot2acc_f32_f16 v25, v101, v4                            // 0000009908E4: 04320965
	v_bfe_u32 v101, v95, 12, 16                                // 0000009908E8: D6100065 0241195F
	.long 0xd72c0066                                           // 0000009908F0: D72C0066
	v_cndmask_b32_e32 v1, 0x83dcd12d, v102, vcc_lo             // 0000009908F4: 0202CCFF 83DCD12D
	v_dot2acc_f32_f16 v24, v100, v1                            // 0000009908FC: 04300364
	v_pk_fma_f16 v97, v104, s6, 0xc931 op_sel_hi:[1,0,0]       // 000000990900: CC0E0061 0BFC0D68 0000C931
	v_and_b32_e32 v100, 0xffff, v96                            // 00000099090C: 36C8C0FF 0000FFFF
	.long 0xd72c0065                                           // 000000990914: D72C0065
	v_cndmask_b32_e32 v1, 0x83dcd12d, v101, vcc_lo             // 000000990918: 0202CAFF 83DCD12D
	.long 0xd72c0069                                           // 000000990920: D72C0069
	v_cndmask_b32_e32 v1, 0x83dcd12d, v110, vcc_lo             // 000000990924: 0202DCFF 83DCD12D
	v_dot2acc_f32_f16 v24, v99, v2                             // 00000099092C: 04300563
	v_bfe_u32 v99, v96, 12, 16                                 // 000000990930: D6100063 02411960
	.long 0xd72c0064                                           // 000000990938: D72C0064
	v_cndmask_b32_e32 v1, 0x83dcd12d, v100, vcc_lo             // 00000099093C: 0202C8FF 83DCD12D
	v_sad_u8 v102, v102, 0, 0x6400                             // 000000990944: D6220066 03FD0166 00006400
	s_waitcnt vmcnt(9)                                         // 000000990950: BF8927F7
	v_alignbit_b32 v31, v31, v32, 16                           // 000000990954: D616001F 0242411F
	v_dot2acc_f32_f16 v24, v97, v3                             // 00000099095C: 04300761
	.long 0xd72c0061                                           // 000000990960: D72C0061
	v_cndmask_b32_e32 v1, 0x83dcd12d, v99, vcc_lo              // 000000990964: 0202C6FF 83DCD12D
	v_bfe_u32 v99, v96, 8, 16                                  // 00000099096C: D6100063 02411160
	v_bfe_u32 v96, v96, 4, 16                                  // 000000990974: D6100060 02410960
	v_and_b32_e32 v95, 0xffff, v95                             // 00000099097C: 36BEBEFF 0000FFFF
	v_sad_u8 v100, v100, 0, 0x6400                             // 000000990984: D6220064 03FD0164 00006400
	v_sad_u8 v101, v101, 0, 0x6400                             // 000000990990: D6220065 03FD0165 00006400
	.long 0xd72c0063                                           // 00000099099C: D72C0063
	v_cndmask_b32_e32 v1, 0x83dcd12d, v99, vcc_lo              // 0000009909A0: 0202C6FF 83DCD12D
	.long 0xd72c0060                                           // 0000009909A8: D72C0060
	v_cndmask_b32_e32 v1, 0x83dcd12d, v96, vcc_lo              // 0000009909AC: 0202C0FF 83DCD12D
	v_sad_u8 v97, v97, 0, 0x6400                               // 0000009909B4: D6220061 03FD0161 00006400
	.long 0xd72c005f                                           // 0000009909C0: D72C005F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v95, vcc_lo              // 0000009909C4: 0202BEFF 83DCD12D
	v_and_b32_e32 v101, 0xffff, v101                           // 0000009909CC: 36CACAFF 0000FFFF
	v_sad_u8 v105, v105, 0, 0x6400                             // 0000009909D4: D6220069 03FD0169 00006400
	s_waitcnt vmcnt(8)                                         // 0000009909E0: BF8923F7
	v_alignbit_b32 v26, v26, v29, 16                           // 0000009909E4: D616001A 02423B1A
	v_and_b32_e32 v97, 0xffff, v97                             // 0000009909EC: 36C2C2FF 0000FFFF
	v_sad_u8 v99, v99, 0, 0x6400                               // 0000009909F4: D6220063 03FD0163 00006400
	v_sad_u8 v96, v96, 0, 0x6400                               // 000000990A00: D6220060 03FD0160 00006400
	v_lshl_or_b32 v94, v102, 16, v101                          // 000000990A0C: D656005E 05952166
	v_sad_u8 v95, v95, 0, 0x6400                               // 000000990A14: D622005F 03FD015F 00006400
	v_and_b32_e32 v101, 0xffff, v93                            // 000000990A20: 36CABAFF 0000FFFF
	v_lshl_or_b32 v97, v99, 16, v97                            // 000000990A28: D6560061 05852163
	v_lshlrev_b32_e32 v99, 16, v100                            // 000000990A30: 30C6C890
	.long 0xd72c0064                                           // 000000990A34: D72C0064
	v_cndmask_b32_e32 v1, 0x83dcd12d, v103, vcc_lo             // 000000990A38: 0202CEFF 83DCD12D
	v_lshlrev_b32_e32 v95, 16, v95                             // 000000990A40: 30BEBE90
	.long 0xd72c0065                                           // 000000990A44: D72C0065
	v_cndmask_b32_e32 v1, 0x83dcd12d, v101, vcc_lo             // 000000990A48: 0202CAFF 83DCD12D
	v_pk_fma_f16 v97, v97, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000990A50: CC0E0061 0BFC0D61 0000C931
	v_and_or_b32 v96, 0xffff, v96, v99                         // 000000990A5C: D6570060 058EC0FF 0000FFFF
	v_bfe_u32 v102, v92, 8, 16                                 // 000000990A68: D6100066 0241115C
	v_and_b32_e32 v103, 0xffff, v92                            // 000000990A70: 36CEB8FF 0000FFFF
	v_pk_fma_f16 v94, v94, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000990A78: CC0E005E 0BFC0D5E 0000C931
	v_sad_u8 v99, v100, 0, 0x6400                              // 000000990A84: D6220063 03FD0164 00006400
	v_bfe_u32 v100, v93, 12, 16                                // 000000990A90: D6100064 0241195D
	v_dot2acc_f32_f16 v23, v97, v1                             // 000000990A98: 042E0361
	v_bfe_u32 v97, v92, 12, 16                                 // 000000990A9C: D6100061 0241195C
	v_sad_u8 v101, v101, 0, 0x6400                             // 000000990AA4: D6220065 03FD0165 00006400
	v_and_or_b32 v95, 0xffff, v99, v95                         // 000000990AB0: D657005F 057EC6FF 0000FFFF
	v_bfe_u32 v99, v93, 8, 16                                  // 000000990ABC: D6100063 0241115D
	.long 0xd72c0064                                           // 000000990AC4: D72C0064
	v_cndmask_b32_e32 v1, 0x83dcd12d, v100, vcc_lo             // 000000990AC8: 0202C8FF 83DCD12D
	v_bfe_u32 v93, v93, 4, 16                                  // 000000990AD0: D610005D 0241095D
	.long 0xd72c0061                                           // 000000990AD8: D72C0061
	v_cndmask_b32_e32 v1, 0x83dcd12d, v97, vcc_lo              // 000000990ADC: 0202C2FF 83DCD12D
	.long 0xd72c0066                                           // 000000990AE4: D72C0066
	v_cndmask_b32_e32 v1, 0x83dcd12d, v102, vcc_lo             // 000000990AE8: 0202CCFF 83DCD12D
	.long 0xd72c0063                                           // 000000990AF0: D72C0063
	v_cndmask_b32_e32 v1, 0x83dcd12d, v99, vcc_lo              // 000000990AF4: 0202C6FF 83DCD12D
	v_bfe_u32 v92, v92, 4, 16                                  // 000000990AFC: D610005C 0241095C
	.long 0xd72c005d                                           // 000000990B04: D72C005D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v93, vcc_lo              // 000000990B08: 0202BAFF 83DCD12D
	.long 0xd72c0067                                           // 000000990B10: D72C0067
	v_cndmask_b32_e32 v1, 0x83dcd12d, v103, vcc_lo             // 000000990B14: 0202CEFF 83DCD12D
	v_sad_u8 v100, v100, 0, 0x6400                             // 000000990B1C: D6220064 03FD0164 00006400
	v_pk_fma_f16 v96, v96, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000990B28: CC0E0060 0BFC0D60 0000C931
	v_lshlrev_b32_e32 v101, 16, v101                           // 000000990B34: 30CACA90
	v_sad_u8 v97, v97, 0, 0x6400                               // 000000990B38: D6220061 03FD0161 00006400
	v_sad_u8 v99, v99, 0, 0x6400                               // 000000990B44: D6220063 03FD0163 00006400
	v_and_b32_e32 v100, 0xffff, v100                           // 000000990B50: 36C8C8FF 0000FFFF
	v_sad_u8 v93, v93, 0, 0x6400                               // 000000990B58: D622005D 03FD015D 00006400
	.long 0xd72c005c                                           // 000000990B64: D72C005C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v92, vcc_lo              // 000000990B68: 0202B8FF 83DCD12D
	v_and_b32_e32 v97, 0xffff, v97                             // 000000990B70: 36C2C2FF 0000FFFF
	v_dot2acc_f32_f16 v23, v96, v2                             // 000000990B78: 042E0560
	v_lshl_or_b32 v99, v99, 16, v100                           // 000000990B7C: D6560063 05912163
	v_and_or_b32 v93, 0xffff, v93, v101                        // 000000990B84: D657005D 0596BAFF 0000FFFF
	v_sad_u8 v100, v102, 0, 0x6400                             // 000000990B90: D6220064 03FD0166 00006400
	v_pk_fma_f16 v95, v95, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000990B9C: CC0E005F 0BFC0D5F 0000C931
	v_dot2acc_f32_f16 v23, v94, v3                             // 000000990BA8: 042E075E
	v_pk_fma_f16 v96, v99, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000990BAC: CC0E0060 0BFC0D63 0000C931
	v_sad_u8 v99, v103, 0, 0x6400                              // 000000990BB8: D6220063 03FD0167 00006400
	v_pk_fma_f16 v93, v93, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000990BC4: CC0E005D 0BFC0D5D 0000C931
	v_lshl_or_b32 v97, v100, 16, v97                           // 000000990BD0: D6560061 05852164
	v_sad_u8 v92, v92, 0, 0x6400                               // 000000990BD8: D622005C 03FD015C 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000990BE4: BF870224
	v_dual_dot2acc_f32_f16 v22, v96, v1 :: v_dual_lshlrev_b32 v91, 16, v99// 000000990BE8: CB220360 165AC690
	v_bfe_u32 v96, v90, 12, 16                                 // 000000990BF0: D6100060 0241195A
	v_pk_fma_f16 v94, v97, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000990BF8: CC0E005E 0BFC0D61 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000990C04: BF870213
	v_dual_dot2acc_f32_f16 v22, v93, v2 :: v_dual_and_b32 v97, 0xffff, v89// 000000990C08: CB24055D 1660B2FF 0000FFFF
	v_and_or_b32 v91, 0xffff, v92, v91                         // 000000990C14: D657005B 056EB8FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000990C20: BF870254
	.long 0xd72c005c                                           // 000000990C24: D72C005C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v96, vcc_lo              // 000000990C28: 0202C0FF 83DCD12D
	v_bfe_u32 v93, v90, 8, 16                                  // 000000990C30: D610005D 0241115A
	v_dual_dot2acc_f32_f16 v23, v95, v4 :: v_dual_and_b32 v98, 0xffff, v98// 000000990C38: CB24095F 1762C4FF 0000FFFF
	v_dot2acc_f32_f16 v22, v94, v3                             // 000000990C44: 042C075E
	v_bfe_u32 v94, v90, 4, 16                                  // 000000990C48: D610005E 0241095A
	.long 0xd72c005d                                           // 000000990C50: D72C005D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v93, vcc_lo              // 000000990C54: 0202BAFF 83DCD12D
	v_bfe_u32 v95, v89, 12, 16                                 // 000000990C5C: D610005F 02411959
	v_sad_u8 v92, v92, 0, 0x6400                               // 000000990C64: D622005C 03FD015C 00006400
	v_bfe_u32 v96, v89, 8, 16                                  // 000000990C70: D6100060 02411159
	v_bfe_u32 v89, v89, 4, 16                                  // 000000990C78: D6100059 02410959
	.long 0xd72c005e                                           // 000000990C80: D72C005E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v94, vcc_lo              // 000000990C84: 0202BCFF 83DCD12D
	.long 0xd72c0061                                           // 000000990C8C: D72C0061
	v_cndmask_b32_e32 v1, 0x83dcd12d, v97, vcc_lo              // 000000990C90: 0202C2FF 83DCD12D
	v_and_b32_e32 v92, 0xffff, v92                             // 000000990C98: 36B8B8FF 0000FFFF
	v_sad_u8 v93, v93, 0, 0x6400                               // 000000990CA0: D622005D 03FD015D 00006400
	.long 0xd72c0059                                           // 000000990CAC: D72C0059
	v_cndmask_b32_e32 v1, 0x83dcd12d, v89, vcc_lo              // 000000990CB0: 0202B2FF 83DCD12D
	.long 0xd72c005f                                           // 000000990CB8: D72C005F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v95, vcc_lo              // 000000990CBC: 0202BEFF 83DCD12D
	.long 0xd72c0060                                           // 000000990CC4: D72C0060
	v_cndmask_b32_e32 v1, 0x83dcd12d, v96, vcc_lo              // 000000990CC8: 0202C0FF 83DCD12D
	.long 0xd72c0062                                           // 000000990CD0: D72C0062
	v_cndmask_b32_e32 v1, 0x83dcd12d, v98, vcc_lo              // 000000990CD4: 0202C4FF 83DCD12D
	v_lshl_or_b32 v92, v93, 16, v92                            // 000000990CDC: D656005C 0571215D
	v_sad_u8 v93, v94, 0, 0x6400                               // 000000990CE4: D622005D 03FD015E 00006400
	v_sad_u8 v94, v97, 0, 0x6400                               // 000000990CF0: D622005E 03FD0161 00006400
	v_bfe_u32 v97, v86, 8, 16                                  // 000000990CFC: D6100061 02411156
	v_sad_u8 v89, v89, 0, 0x6400                               // 000000990D04: D6220059 03FD0159 00006400
	v_sad_u8 v95, v95, 0, 0x6400                               // 000000990D10: D622005F 03FD015F 00006400
	v_sad_u8 v96, v96, 0, 0x6400                               // 000000990D1C: D6220060 03FD0160 00006400
	v_lshlrev_b32_e32 v94, 16, v94                             // 000000990D28: 30BCBC90
	v_pk_fma_f16 v92, v92, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000990D2C: CC0E005C 0BFC0D5C 0000C931
	.long 0xd72c0061                                           // 000000990D38: D72C0061
	v_cndmask_b32_e32 v1, 0x83dcd12d, v97, vcc_lo              // 000000990D3C: 0202C2FF 83DCD12D
	v_and_b32_e32 v95, 0xffff, v95                             // 000000990D44: 36BEBEFF 0000FFFF
	v_sad_u8 v98, v98, 0, 0x6400                               // 000000990D4C: D6220062 03FD0162 00006400
	v_and_or_b32 v89, 0xffff, v89, v94                         // 000000990D58: D6570059 057AB2FF 0000FFFF
	v_dual_dot2acc_f32_f16 v21, v92, v1 :: v_dual_and_b32 v94, 0xffff, v87// 000000990D64: CB24035C 155EAEFF 0000FFFF
	v_pk_fma_f16 v91, v91, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000990D70: CC0E005B 0BFC0D5B 0000C931
	v_cmp_eq_u32_e32 vcc_lo, v5, v8                            // 000000990D7C: 7C941105
	s_delay_alu instid0(VALU_DEP_4)                            // 000000990D80: BF870004
	v_pk_fma_f16 v89, v89, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000990D84: CC0E0059 0BFC0D59 0000C931
	v_and_b32_e32 v90, 0xffff, v90                             // 000000990D90: 36B4B4FF 0000FFFF
	.long 0xd72c005e                                           // 000000990D98: D72C005E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v94, vcc_lo              // 000000990D9C: 0202BCFF 83DCD12D
	v_dot2acc_f32_f16 v22, v91, v4                             // 000000990DA4: 042C095B
	s_waitcnt vmcnt(7)                                         // 000000990DA8: BF891FF7
	v_bfe_u32 v91, v83, 4, 16                                  // 000000990DAC: D610005B 02410953
	v_mov_b32_e32 v99, v50                                     // 000000990DB4: 7EC60332
	.long 0xd72c005a                                           // 000000990DB8: D72C005A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v90, vcc_lo              // 000000990DBC: 0202B4FF 83DCD12D
	v_mov_b32_e32 v101, v68                                    // 000000990DC4: 7ECA0344
	v_mov_b32_e32 v103, v68                                    // 000000990DC8: 7ECE0344
	.long 0xd72c005b                                           // 000000990DCC: D72C005B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v91, vcc_lo              // 000000990DD0: 0202B6FF 83DCD12D
	v_sad_u8 v94, v94, 0, 0x6400                               // 000000990DD8: D622005E 03FD015E 00006400
	s_or_b32 s5, vcc_lo, s5                                    // 000000990DE4: 8C05056A
	v_mov_b32_e32 v106, v70                                    // 000000990DE8: 7ED40346
	v_mov_b32_e32 v104, v70                                    // 000000990DEC: 7ED00346
	v_sad_u8 v90, v90, 0, 0x6400                               // 000000990DF0: D622005A 03FD015A 00006400
	v_lshlrev_b32_e32 v94, 16, v94                             // 000000990DFC: 30BCBC90
	v_mov_b32_e32 v102, v53                                    // 000000990E00: 7ECC0335
	v_sad_u8 v91, v91, 0, 0x6400                               // 000000990E04: D622005B 03FD015B 00006400
	v_mov_b32_e32 v100, v66                                    // 000000990E10: 7EC80342
	v_lshlrev_b32_e32 v90, 16, v90                             // 000000990E14: 30B4B490
	s_delay_alu instid0(VALU_DEP_1)                            // 000000990E18: BF870001
	v_and_or_b32 v88, 0xffff, v93, v90                         // 000000990E1C: D6570058 056ABAFF 0000FFFF
	v_bfe_u32 v93, v87, 12, 16                                 // 000000990E28: D610005D 02411957
	v_lshl_or_b32 v90, v96, 16, v95                            // 000000990E30: D656005A 057D2160
	v_bfe_u32 v95, v87, 8, 16                                  // 000000990E38: D610005F 02411157
	v_bfe_u32 v87, v87, 4, 16                                  // 000000990E40: D6100057 02410957
	v_bfe_u32 v96, v86, 12, 16                                 // 000000990E48: D6100060 02411956
	.long 0xd72c005d                                           // 000000990E50: D72C005D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v93, vcc_lo              // 000000990E54: 0202BAFF 83DCD12D
	v_pk_fma_f16 v88, v88, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000990E5C: CC0E0058 0BFC0D58 0000C931
	.long 0xd72c005f                                           // 000000990E68: D72C005F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v95, vcc_lo              // 000000990E6C: 0202BEFF 83DCD12D
	.long 0xd72c0057                                           // 000000990E74: D72C0057
	v_cndmask_b32_e32 v1, 0x83dcd12d, v87, vcc_lo              // 000000990E78: 0202AEFF 83DCD12D
	.long 0xd72c0060                                           // 000000990E80: D72C0060
	v_cndmask_b32_e32 v1, 0x83dcd12d, v96, vcc_lo              // 000000990E84: 0202C0FF 83DCD12D
	v_pk_fma_f16 v90, v90, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000990E8C: CC0E005A 0BFC0D5A 0000C931
	v_dot2acc_f32_f16 v21, v88, v2                             // 000000990E98: 042A0558
	v_lshlrev_b32_e32 v98, 16, v98                             // 000000990E9C: 30C4C490
	v_sad_u8 v93, v93, 0, 0x6400                               // 000000990EA0: D622005D 03FD015D 00006400
	v_sad_u8 v95, v95, 0, 0x6400                               // 000000990EAC: D622005F 03FD015F 00006400
	v_sad_u8 v87, v87, 0, 0x6400                               // 000000990EB8: D6220057 03FD0157 00006400
	v_sad_u8 v96, v96, 0, 0x6400                               // 000000990EC4: D6220060 03FD0160 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 000000990ED0: BF870004
	v_and_b32_e32 v93, 0xffff, v93                             // 000000990ED4: 36BABAFF 0000FFFF
	v_dot2acc_f32_f16 v21, v90, v3                             // 000000990EDC: 042A075A
	v_bfe_u32 v90, v83, 8, 16                                  // 000000990EE0: D610005A 02411153
	v_and_or_b32 v87, 0xffff, v87, v94                         // 000000990EE8: D6570057 057AAEFF 0000FFFF
	v_and_b32_e32 v94, 0xffff, v96                             // 000000990EF4: 36BCC0FF 0000FFFF
	v_lshl_or_b32 v92, v95, 16, v93                            // 000000990EFC: D656005C 0575215F
	v_sad_u8 v95, v97, 0, 0x6400                               // 000000990F04: D622005F 03FD0161 00006400
	v_dot2acc_f32_f16 v21, v89, v4                             // 000000990F10: 042A0959
	v_pk_fma_f16 v87, v87, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000990F14: CC0E0057 0BFC0D57 0000C931
	v_bfe_u32 v89, v83, 12, 16                                 // 000000990F20: D6100059 02411953
	v_pk_fma_f16 v88, v92, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000990F28: CC0E0058 0BFC0D5C 0000C931
	v_lshl_or_b32 v92, v95, 16, v94                            // 000000990F34: D656005C 0579215F
	v_and_b32_e32 v83, 0xffff, v83                             // 000000990F3C: 36A6A6FF 0000FFFF
	.long 0xd72c005a                                           // 000000990F44: D72C005A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v90, vcc_lo              // 000000990F48: 0202B4FF 83DCD12D
	.long 0xd72c0059                                           // 000000990F50: D72C0059
	v_cndmask_b32_e32 v1, 0x83dcd12d, v89, vcc_lo              // 000000990F54: 0202B2FF 83DCD12D
	v_dot2acc_f32_f16 v20, v88, v1                             // 000000990F5C: 04280358
	v_pk_fma_f16 v85, v92, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000990F60: CC0E0055 0BFC0D5C 0000C931
	v_and_b32_e32 v88, 0xffff, v84                             // 000000990F6C: 36B0A8FF 0000FFFF
	.long 0xd72c0053                                           // 000000990F74: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000990F78: 0202A6FF 83DCD12D
	v_and_or_b32 v98, 0xffff, v105, v98                        // 000000990F80: D6570062 058AD2FF 0000FFFF
	v_dot2acc_f32_f16 v20, v87, v2                             // 000000990F8C: 04280557
	v_bfe_u32 v87, v84, 12, 16                                 // 000000990F90: D6100057 02411954
	v_sad_u8 v89, v89, 0, 0x6400                               // 000000990F98: D6220059 03FD0159 00006400
	.long 0xd72c0058                                           // 000000990FA4: D72C0058
	v_cndmask_b32_e32 v1, 0x83dcd12d, v88, vcc_lo              // 000000990FA8: 0202B0FF 83DCD12D
	v_sad_u8 v90, v90, 0, 0x6400                               // 000000990FB0: D622005A 03FD015A 00006400
	v_dot2acc_f32_f16 v20, v85, v3                             // 000000990FBC: 04280755
	v_bfe_u32 v85, v84, 8, 16                                  // 000000990FC0: D6100055 02411154
	.long 0xd72c0057                                           // 000000990FC8: D72C0057
	v_cndmask_b32_e32 v1, 0x83dcd12d, v87, vcc_lo              // 000000990FCC: 0202AEFF 83DCD12D
	v_bfe_u32 v84, v84, 4, 16                                  // 000000990FD4: D6100054 02410954
	v_sad_u8 v83, v83, 0, 0x6400                               // 000000990FDC: D6220053 03FD0153 00006400
	v_and_b32_e32 v89, 0xffff, v89                             // 000000990FE8: 36B2B2FF 0000FFFF
	.long 0xd72c0055                                           // 000000990FF0: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 000000990FF4: 0202AAFF 83DCD12D
	v_sad_u8 v88, v88, 0, 0x6400                               // 000000990FFC: D6220058 03FD0158 00006400
	.long 0xd72c0054                                           // 000000991008: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 00000099100C: 0202A8FF 83DCD12D
	v_lshlrev_b32_e32 v83, 16, v83                             // 000000991014: 30A6A690
	v_sad_u8 v87, v87, 0, 0x6400                               // 000000991018: D6220057 03FD0157 00006400
	v_pk_fma_f16 v98, v98, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000991024: CC0E0062 0BFC0D62 0000C931
	v_lshlrev_b32_e32 v88, 16, v88                             // 000000991030: 30B0B090
	v_mov_b32_e32 v92, v61                                     // 000000991034: 7EB8033D
	v_sad_u8 v85, v85, 0, 0x6400                               // 000000991038: D6220055 03FD0155 00006400
	v_and_b32_e32 v87, 0xffff, v87                             // 000000991044: 36AEAEFF 0000FFFF
	v_sad_u8 v84, v84, 0, 0x6400                               // 00000099104C: D6220054 03FD0154 00006400
	v_and_or_b32 v82, 0xffff, v91, v83                         // 000000991058: D6570052 054EB6FF 0000FFFF
	s_waitcnt vmcnt(5)                                         // 000000991064: BF8917F7
	v_bfe_u32 v91, v77, 4, 16                                  // 000000991068: D610005B 0241094D
	v_dot2acc_f32_f16 v24, v98, v4                             // 000000991070: 04300962
	v_lshl_or_b32 v85, v85, 16, v87                            // 000000991074: D6560055 055D2155
	v_lshl_or_b32 v87, v90, 16, v89                            // 00000099107C: D6560057 0565215A
	v_and_or_b32 v84, 0xffff, v84, v88                         // 000000991084: D6570054 0562A8FF 0000FFFF
	v_bfe_u32 v88, v80, 12, 16                                 // 000000991090: D6100058 02411950
	v_bfe_u32 v89, v81, 8, 16                                  // 000000991098: D6100059 02411151
	v_pk_fma_f16 v83, v85, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000009910A0: CC0E0053 0BFC0D55 0000C931
	v_pk_fma_f16 v85, v87, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000009910AC: CC0E0055 0BFC0D57 0000C931
	v_bfe_u32 v87, v81, 12, 16                                 // 0000009910B8: D6100057 02411951
	v_pk_fma_f16 v84, v84, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000009910C0: CC0E0054 0BFC0D54 0000C931
	.long 0xd72c0058                                           // 0000009910CC: D72C0058
	v_cndmask_b32_e32 v1, 0x83dcd12d, v88, vcc_lo              // 0000009910D0: 0202B0FF 83DCD12D
	v_dot2acc_f32_f16 v19, v83, v1                             // 0000009910D8: 04260353
	v_and_b32_e32 v83, 0xffff, v81                             // 0000009910DC: 36A6A2FF 0000FFFF
	.long 0xd72c0057                                           // 0000009910E4: D72C0057
	v_cndmask_b32_e32 v1, 0x83dcd12d, v87, vcc_lo              // 0000009910E8: 0202AEFF 83DCD12D
	v_bfe_u32 v81, v81, 4, 16                                  // 0000009910F0: D6100051 02410951
	v_bfe_u32 v90, v80, 8, 16                                  // 0000009910F8: D610005A 02411150
	.long 0xd72c0059                                           // 000000991100: D72C0059
	v_cndmask_b32_e32 v1, 0x83dcd12d, v89, vcc_lo              // 000000991104: 0202B2FF 83DCD12D
	.long 0xd72c0053                                           // 00000099110C: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000991110: 0202A6FF 83DCD12D
	v_dot2acc_f32_f16 v19, v84, v2                             // 000000991118: 04260554
	.long 0xd72c0051                                           // 00000099111C: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000991120: 0202A2FF 83DCD12D
	.long 0xd72c0054                                           // 000000991128: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v90, vcc_lo              // 00000099112C: 0202B4FF 83DCD12D
	v_sad_u8 v87, v87, 0, 0x6400                               // 000000991134: D6220057 03FD0157 00006400
	v_sad_u8 v88, v88, 0, 0x6400                               // 000000991140: D6220058 03FD0158 00006400
	v_dot2acc_f32_f16 v19, v85, v3                             // 00000099114C: 04260755
	v_sad_u8 v89, v89, 0, 0x6400                               // 000000991150: D6220059 03FD0159 00006400
	v_sad_u8 v83, v83, 0, 0x6400                               // 00000099115C: D6220053 03FD0153 00006400
	v_and_b32_e32 v87, 0xffff, v87                             // 000000991168: 36AEAEFF 0000FFFF
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000991170: D6220051 03FD0151 00006400
	v_and_b32_e32 v88, 0xffff, v88                             // 00000099117C: 36B0B0FF 0000FFFF
	v_sad_u8 v84, v84, 0, 0x6400                               // 000000991184: D6220054 03FD0154 00006400
	v_lshlrev_b32_e32 v83, 16, v83                             // 000000991190: 30A6A690
	v_lshl_or_b32 v87, v89, 16, v87                            // 000000991194: D6560057 055D2159
	v_bfe_u32 v85, v78, 12, 16                                 // 00000099119C: D6100055 0241194E
	v_bfe_u32 v90, v80, 4, 16                                  // 0000009911A4: D610005A 02410950
	v_and_b32_e32 v80, 0xffff, v80                             // 0000009911AC: 36A0A0FF 0000FFFF
	v_and_or_b32 v81, 0xffff, v81, v83                         // 0000009911B4: D6570051 054EA2FF 0000FFFF
	v_lshl_or_b32 v83, v84, 16, v88                            // 0000009911C0: D6560053 05612154
	v_pk_fma_f16 v79, v87, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000009911C8: CC0E004F 0BFC0D57 0000C931
	v_and_b32_e32 v87, 0xffff, v78                             // 0000009911D4: 36AE9CFF 0000FFFF
	v_bfe_u32 v88, v78, 8, 16                                  // 0000009911DC: D6100058 0241114E
	.long 0xd72c0055                                           // 0000009911E4: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 0000009911E8: 0202AAFF 83DCD12D
	v_bfe_u32 v78, v78, 4, 16                                  // 0000009911F0: D610004E 0241094E
	v_bfe_u32 v89, v77, 12, 16                                 // 0000009911F8: D6100059 0241194D
	.long 0xd72c0057                                           // 000000991200: D72C0057
	v_cndmask_b32_e32 v1, 0x83dcd12d, v87, vcc_lo              // 000000991204: 0202AEFF 83DCD12D
	.long 0xd72c0058                                           // 00000099120C: D72C0058
	v_cndmask_b32_e32 v1, 0x83dcd12d, v88, vcc_lo              // 000000991210: 0202B0FF 83DCD12D
	.long 0xd72c0054                                           // 000000991218: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v90, vcc_lo              // 00000099121C: 0202B4FF 83DCD12D
	.long 0xd72c0050                                           // 000000991224: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 000000991228: 0202A0FF 83DCD12D
	v_bfe_u32 v90, v77, 8, 16                                  // 000000991230: D610005A 0241114D
	v_sad_u8 v85, v85, 0, 0x6400                               // 000000991238: D6220055 03FD0155 00006400
	.long 0xd72c004e                                           // 000000991244: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000991248: 02029CFF 83DCD12D
	.long 0xd72c0059                                           // 000000991250: D72C0059
	v_cndmask_b32_e32 v1, 0x83dcd12d, v89, vcc_lo              // 000000991254: 0202B2FF 83DCD12D
	v_and_b32_e32 v77, 0xffff, v77                             // 00000099125C: 369A9AFF 0000FFFF
	v_sad_u8 v87, v87, 0, 0x6400                               // 000000991264: D6220057 03FD0157 00006400
	v_and_b32_e32 v85, 0xffff, v85                             // 000000991270: 36AAAAFF 0000FFFF
	v_sad_u8 v88, v88, 0, 0x6400                               // 000000991278: D6220058 03FD0158 00006400
	.long 0xd72c005a                                           // 000000991284: D72C005A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v90, vcc_lo              // 000000991288: 0202B4FF 83DCD12D
	.long 0xd72c004d                                           // 000000991290: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000991294: 02029AFF 83DCD12D
	v_sad_u8 v80, v80, 0, 0x6400                               // 00000099129C: D6220050 03FD0150 00006400
	v_sad_u8 v78, v78, 0, 0x6400                               // 0000009912A8: D622004E 03FD014E 00006400
	v_lshlrev_b32_e32 v87, 16, v87                             // 0000009912B4: 30AEAE90
	v_sad_u8 v89, v89, 0, 0x6400                               // 0000009912B8: D6220059 03FD0159 00006400
	v_lshl_or_b32 v85, v88, 16, v85                            // 0000009912C4: D6560055 05552158
	v_dot2acc_f32_f16 v16, v79, v1                             // 0000009912CC: 0420034F
	.long 0xd72c004f                                           // 0000009912D0: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v91, vcc_lo              // 0000009912D4: 0202B6FF 83DCD12D
	v_pk_fma_f16 v81, v81, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000009912DC: CC0E0051 0BFC0D51 0000C931
	v_sad_u8 v84, v84, 0, 0x6400                               // 0000009912E8: D6220054 03FD0154 00006400
	v_lshlrev_b32_e32 v80, 16, v80                             // 0000009912F4: 30A0A090
	v_and_or_b32 v78, 0xffff, v78, v87                         // 0000009912F8: D657004E 055E9CFF 0000FFFF
	v_and_b32_e32 v87, 0xffff, v89                             // 000000991304: 36AEB2FF 0000FFFF
	v_sad_u8 v77, v77, 0, 0x6400                               // 00000099130C: D622004D 03FD014D 00006400
	v_sad_u8 v88, v90, 0, 0x6400                               // 000000991318: D6220058 03FD015A 00006400
	v_pk_fma_f16 v85, v85, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000991324: CC0E0055 0BFC0D55 0000C931
	v_pk_fma_f16 v83, v83, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000991330: CC0E0053 0BFC0D53 0000C931
	v_pk_fma_f16 v78, v78, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000099133C: CC0E004E 0BFC0D4E 0000C931
	v_sad_u8 v79, v79, 0, 0x6400                               // 000000991348: D622004F 03FD014F 00006400
	v_lshlrev_b32_e32 v77, 16, v77                             // 000000991354: 309A9A90
	v_lshl_or_b32 v87, v88, 16, v87                            // 000000991358: D6560057 055D2158
	v_dot2acc_f32_f16 v15, v85, v1                             // 000000991360: 041E0355
	v_and_or_b32 v80, 0xffff, v84, v80                         // 000000991364: D6570050 0542A8FF 0000FFFF
	v_dot2acc_f32_f16 v16, v81, v2                             // 000000991370: 04200551
	v_and_or_b32 v77, 0xffff, v79, v77                         // 000000991374: D657004D 05369EFF 0000FFFF
	v_pk_fma_f16 v79, v87, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000991380: CC0E004F 0BFC0D57 0000C931
	v_dot2acc_f32_f16 v15, v78, v2                             // 00000099138C: 041E054E
	v_pk_fma_f16 v78, v80, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000991390: CC0E004E 0BFC0D50 0000C931
	v_dot2acc_f32_f16 v16, v83, v3                             // 00000099139C: 04200753
	v_pk_fma_f16 v77, v77, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000009913A0: CC0E004D 0BFC0D4D 0000C931
	s_waitcnt vmcnt(4)                                         // 0000009913AC: BF8913F7
	v_bfe_u32 v80, v74, 8, 16                                  // 0000009913B0: D6100050 0241114A
	v_dot2acc_f32_f16 v15, v79, v3                             // 0000009913B8: 041E074F
	v_bfe_u32 v79, v74, 12, 16                                 // 0000009913BC: D610004F 0241194A
	v_dot2acc_f32_f16 v16, v78, v4                             // 0000009913C4: 0420094E
	v_and_b32_e32 v78, 0xffff, v75                             // 0000009913C8: 369C96FF 0000FFFF
	.long 0xd72c0050                                           // 0000009913D0: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 0000009913D4: 0202A0FF 83DCD12D
	v_dot2acc_f32_f16 v15, v77, v4                             // 0000009913DC: 041E094D
	v_bfe_u32 v77, v75, 8, 16                                  // 0000009913E0: D610004D 0241114B
	v_bfe_u32 v75, v75, 4, 16                                  // 0000009913E8: D610004B 0241094B
	.long 0xd72c004e                                           // 0000009913F0: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 0000009913F4: 02029CFF 83DCD12D
	.long 0xd72c004f                                           // 0000009913FC: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 000000991400: 02029EFF 83DCD12D
	v_bfe_u32 v81, v74, 4, 16                                  // 000000991408: D6100051 0241094A
	.long 0xd72c004d                                           // 000000991410: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000991414: 02029AFF 83DCD12D
	.long 0xd72c004b                                           // 00000099141C: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000991420: 020296FF 83DCD12D
	v_and_b32_e32 v74, 0xffff, v74                             // 000000991428: 369494FF 0000FFFF
	v_sad_u8 v80, v80, 0, 0x6400                               // 000000991430: D6220050 03FD0150 00006400
	v_pk_fma_f16 v82, v82, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000099143C: CC0E0052 0BFC0D52 0000C931
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000991448: D622004E 03FD014E 00006400
	v_sad_u8 v79, v79, 0, 0x6400                               // 000000991454: D622004F 03FD014F 00006400
	.long 0xd72c004a                                           // 000000991460: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000991464: 020294FF 83DCD12D
	v_sad_u8 v77, v77, 0, 0x6400                               // 00000099146C: D622004D 03FD014D 00006400
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000991478: D622004B 03FD014B 00006400
	v_lshlrev_b32_e32 v78, 16, v78                             // 000000991484: 309C9C90
	v_and_b32_e32 v79, 0xffff, v79                             // 000000991488: 369E9EFF 0000FFFF
	v_bfe_u32 v98, v86, 4, 16                                  // 000000991490: D6100062 02410956
	v_lshl_or_b32 v76, v77, 16, v76                            // 000000991498: D656004C 0531214D
	.long 0xd72c004d                                           // 0000009914A0: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 0000009914A4: 0202A2FF 83DCD12D
	v_and_or_b32 v75, 0xffff, v75, v78                         // 0000009914AC: D657004B 053A96FF 0000FFFF
	v_bfe_u32 v78, v63, 12, 16                                 // 0000009914B8: D610004E 0241193F
	v_lshl_or_b32 v73, v80, 16, v79                            // 0000009914C0: D6560049 053D2150
	v_and_b32_e32 v79, 0xffff, v63                             // 0000009914C8: 369E7EFF 0000FFFF
	v_bfe_u32 v80, v63, 8, 16                                  // 0000009914D0: D6100050 0241113F
	v_bfe_u32 v63, v63, 4, 16                                  // 0000009914D8: D610003F 0241093F
	.long 0xd72c004e                                           // 0000009914E0: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 0000009914E4: 02029CFF 83DCD12D
	s_waitcnt vmcnt(3)                                         // 0000009914EC: BF890FF7
	v_bfe_u32 v81, v39, 12, 16                                 // 0000009914F0: D6100051 02411927
	.long 0xd72c004f                                           // 0000009914F8: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 0000009914FC: 02029EFF 83DCD12D
	.long 0xd72c0050                                           // 000000991504: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 000000991508: 0202A0FF 83DCD12D
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000991510: D622004A 03FD014A 00006400
	v_dual_dot2acc_f32_f16 v19, v82, v4 :: v_dual_and_b32 v86, 0xffff, v86// 00000099151C: CB240952 1356ACFF 0000FFFF
	v_bfe_u32 v82, v39, 8, 16                                  // 000000991528: D6100052 02411127
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000991530: D622004E 03FD014E 00006400
	.long 0xd72c003f                                           // 00000099153C: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000991540: 02027EFF 83DCD12D
	.long 0xd72c0051                                           // 000000991548: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 00000099154C: 0202A2FF 83DCD12D
	v_sad_u8 v77, v77, 0, 0x6400                               // 000000991554: D622004D 03FD014D 00006400
	v_lshlrev_b32_e32 v74, 16, v74                             // 000000991560: 30949490
	v_sad_u8 v79, v79, 0, 0x6400                               // 000000991564: D622004F 03FD014F 00006400
	v_and_b32_e32 v78, 0xffff, v78                             // 000000991570: 369C9CFF 0000FFFF
	v_sad_u8 v80, v80, 0, 0x6400                               // 000000991578: D6220050 03FD0150 00006400
	.long 0xd72c0052                                           // 000000991584: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000991588: 0202A4FF 83DCD12D
	v_pk_fma_f16 v76, v76, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000991590: CC0E004C 0BFC0D4C 0000C931
	v_sad_u8 v63, v63, 0, 0x6400                               // 00000099159C: D622003F 03FD013F 00006400
	v_lshlrev_b32_e32 v79, 16, v79                             // 0000009915A8: 309E9E90
	v_sad_u8 v81, v81, 0, 0x6400                               // 0000009915AC: D6220051 03FD0151 00006400
	v_and_or_b32 v74, 0xffff, v77, v74                         // 0000009915B8: D657004A 052A9AFF 0000FFFF
	v_lshl_or_b32 v77, v80, 16, v78                            // 0000009915C4: D656004D 05392150
	.long 0xd72c0056                                           // 0000009915CC: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 0000009915D0: 0202ACFF 83DCD12D
	v_sad_u8 v80, v82, 0, 0x6400                               // 0000009915D8: D6220050 03FD0152 00006400
	v_dot2acc_f32_f16 v14, v76, v1                             // 0000009915E4: 041C034C
	v_mov_b32_e32 v82, v69                                     // 0000009915E8: 7EA40345
	v_and_or_b32 v63, 0xffff, v63, v79                         // 0000009915EC: D657003F 053E7EFF 0000FFFF
	v_dual_mov_b32 v84, v55 :: v_dual_and_b32 v79, 0xffff, v81 // 0000009915F8: CA240137 544EA2FF 0000FFFF
	v_pk_fma_f16 v76, v77, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000991604: CC0E004C 0BFC0D4D 0000C931
	.long 0xd72c005d                                           // 000000991610: D72C005D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v98, vcc_lo              // 000000991614: 0202C4FF 83DCD12D
	v_pk_fma_f16 v75, v75, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000099161C: CC0E004B 0BFC0D4B 0000C931
	v_bfe_u32 v83, v39, 4, 16                                  // 000000991628: D6100053 02410927
	v_and_b32_e32 v39, 0xffff, v39                             // 000000991630: 364E4EFF 0000FFFF
	v_pk_fma_f16 v63, v63, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000991638: CC0E003F 0BFC0D3F 0000C931
	v_lshl_or_b32 v77, v80, 16, v79                            // 000000991644: D656004D 053D2150
	v_dot2acc_f32_f16 v13, v76, v1                             // 00000099164C: 041A034C
	v_sad_u8 v86, v86, 0, 0x6400                               // 000000991650: D6220056 03FD0156 00006400
	v_pk_fma_f16 v73, v73, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000099165C: CC0E0049 0BFC0D49 0000C931
	v_dot2acc_f32_f16 v14, v75, v2                             // 000000991668: 041C054B
	v_pk_fma_f16 v38, v77, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000099166C: CC0E0026 0BFC0D4D 0000C931
	v_dot2acc_f32_f16 v13, v63, v2                             // 000000991678: 041A053F
	v_pk_fma_f16 v63, v74, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000099167C: CC0E003F 0BFC0D4A 0000C931
	v_bfe_u32 v74, v37, 12, 16                                 // 000000991688: D610004A 02411925
	s_waitcnt vmcnt(2)                                         // 000000991690: BF890BF7
	v_bfe_u32 v75, v36, 12, 16                                 // 000000991694: D610004B 02411924
	v_mov_b32_e32 v80, v69                                     // 00000099169C: 7EA00345
	.long 0xd72c0027                                           // 0000009916A0: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 0000009916A4: 02024EFF 83DCD12D
	v_sad_u8 v93, v93, 0, 0x6400                               // 0000009916AC: D622005D 03FD015D 00006400
	v_dual_dot2acc_f32_f16 v13, v38, v3 :: v_dual_lshlrev_b32 v86, 16, v86// 0000009916B8: CB220726 0D56AC90
	.long 0xd72c004e                                           // 0000009916C0: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 0000009916C4: 0202A6FF 83DCD12D
	v_dot2acc_f32_f16 v14, v73, v3                             // 0000009916CC: 041C0749
	v_bfe_u32 v38, v37, 8, 16                                  // 0000009916D0: D6100026 02411125
	.long 0xd72c0049                                           // 0000009916D8: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 0000009916DC: 020294FF 83DCD12D
	v_and_b32_e32 v74, 0xffff, v37                             // 0000009916E4: 36944AFF 0000FFFF
	v_bfe_u32 v76, v36, 8, 16                                  // 0000009916EC: D610004C 02411124
	v_bfe_u32 v77, v36, 4, 16                                  // 0000009916F4: D610004D 02410924
	v_and_b32_e32 v36, 0xffff, v36                             // 0000009916FC: 364848FF 0000FFFF
	.long 0xd72c004b                                           // 000000991704: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000991708: 020296FF 83DCD12D
	v_and_or_b32 v86, 0xffff, v93, v86                         // 000000991710: D6570056 055ABAFF 0000FFFF
	v_sad_u8 v39, v39, 0, 0x6400                               // 00000099171C: D6220027 03FD0127 00006400
	v_bfe_u32 v37, v37, 4, 16                                  // 000000991728: D6100025 02410925
	.long 0xd72c004a                                           // 000000991730: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000991734: 020294FF 83DCD12D
	.long 0xd72c0026                                           // 00000099173C: D72C0026
	v_cndmask_b32_e32 v1, 0x83dcd12d, v38, vcc_lo              // 000000991740: 02024CFF 83DCD12D
	.long 0xd72c0024                                           // 000000991748: D72C0024
	v_cndmask_b32_e32 v1, 0x83dcd12d, v36, vcc_lo              // 00000099174C: 020248FF 83DCD12D
	.long 0xd72c004c                                           // 000000991754: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000991758: 020298FF 83DCD12D
	v_pk_fma_f16 v86, v86, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000991760: CC0E0056 0BFC0D56 0000C931
	v_sad_u8 v78, v78, 0, 0x6400                               // 00000099176C: D622004E 03FD014E 00006400
	v_lshlrev_b32_e32 v39, 16, v39                             // 000000991778: 304E4E90
	v_sad_u8 v73, v73, 0, 0x6400                               // 00000099177C: D6220049 03FD0149 00006400
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000991788: D622004B 03FD014B 00006400
	.long 0xd72c0025                                           // 000000991794: D72C0025
	v_cndmask_b32_e32 v1, 0x83dcd12d, v37, vcc_lo              // 000000991798: 02024AFF 83DCD12D
	.long 0xd72c004d                                           // 0000009917A0: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 0000009917A4: 02029AFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009917AC: BF870004
	v_dual_dot2acc_f32_f16 v20, v86, v4 :: v_dual_and_b32 v73, 0xffff, v73// 0000009917B0: CB240956 144892FF 0000FFFF
	v_mov_b32_e32 v88, v56                                     // 0000009917BC: 7EB00338
	v_sad_u8 v74, v74, 0, 0x6400                               // 0000009917C0: D622004A 03FD014A 00006400
	v_sad_u8 v38, v38, 0, 0x6400                               // 0000009917CC: D6220026 03FD0126 00006400
	v_sad_u8 v36, v36, 0, 0x6400                               // 0000009917D8: D6220024 03FD0124 00006400
	v_dual_mov_b32 v90, v44 :: v_dual_and_b32 v75, 0xffff, v75 // 0000009917E4: CA24012C 5A4A96FF 0000FFFF
	v_sad_u8 v76, v76, 0, 0x6400                               // 0000009917F0: D622004C 03FD014C 00006400
	v_mov_b32_e32 v86, v56                                     // 0000009917FC: 7EAC0338
	v_and_or_b32 v39, 0xffff, v78, v39                         // 000000991800: D6570027 049E9CFF 0000FFFF
	v_sad_u8 v37, v37, 0, 0x6400                               // 00000099180C: D6220025 03FD0125 00006400
	v_lshlrev_b32_e32 v74, 16, v74                             // 000000991818: 30949490
	v_sad_u8 v77, v77, 0, 0x6400                               // 00000099181C: D622004D 03FD014D 00006400
	v_lshlrev_b32_e32 v36, 16, v36                             // 000000991828: 30484890
	v_pk_fma_f16 v39, v39, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000099182C: CC0E0027 0BFC0D27 0000C931
	v_lshl_or_b32 v38, v38, 16, v73                            // 000000991838: D6560026 05252126
	v_lshl_or_b32 v32, v76, 16, v75                            // 000000991840: D6560020 052D214C
	v_bfe_u32 v73, v31, 12, 16                                 // 000000991848: D6100049 0241191F
	s_waitcnt vmcnt(1)                                         // 000000991850: BF8907F7
	v_bfe_u32 v75, v30, 12, 16                                 // 000000991854: D610004B 0241191E
	v_and_or_b32 v36, 0xffff, v77, v36                         // 00000099185C: D6570024 04929AFF 0000FFFF
	v_pk_fma_f16 v38, v38, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000991868: CC0E0026 0BFC0D26 0000C931
	v_bfe_u32 v76, v31, 8, 16                                  // 000000991874: D610004C 0241111F
	.long 0xd72c0049                                           // 00000099187C: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000991880: 020292FF 83DCD12D
	.long 0xd72c004b                                           // 000000991888: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 00000099188C: 020296FF 83DCD12D
	v_bfe_u32 v77, v30, 8, 16                                  // 000000991894: D610004D 0241111E
	v_dot2acc_f32_f16 v13, v39, v4                             // 00000099189C: 041A0927
	v_mov_b32_e32 v39, v62                                     // 0000009918A0: 7E4E033E
	v_and_or_b32 v37, 0xffff, v37, v74                         // 0000009918A4: D6570025 052A4AFF 0000FFFF
	v_and_b32_e32 v74, 0xffff, v31                             // 0000009918B0: 36943EFF 0000FFFF
	v_bfe_u32 v31, v31, 4, 16                                  // 0000009918B8: D610001F 0241091F
	.long 0xd72c004c                                           // 0000009918C0: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 0000009918C4: 020298FF 83DCD12D
	v_dot2acc_f32_f16 v10, v38, v1                             // 0000009918CC: 04140326
	.long 0xd72c0026                                           // 0000009918D0: D72C0026
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 0000009918D4: 02029AFF 83DCD12D
	v_dual_dot2acc_f32_f16 v14, v63, v4 :: v_dual_mov_b32 v63, v45// 0000009918DC: CB10093F 0E3E012D
	.long 0xd72c004a                                           // 0000009918E4: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 0000009918E8: 020294FF 83DCD12D
	v_pk_fma_f16 v37, v37, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000009918F0: CC0E0025 0BFC0D25 0000C931
	v_sad_u8 v73, v73, 0, 0x6400                               // 0000009918FC: D6220049 03FD0149 00006400
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000991908: D622004B 03FD014B 00006400
	.long 0xd72c001f                                           // 000000991914: D72C001F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v31, vcc_lo              // 000000991918: 02023EFF 83DCD12D
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000991920: D622004C 03FD014C 00006400
	v_sad_u8 v38, v38, 0, 0x6400                               // 00000099192C: D6220026 03FD0126 00006400
	v_and_b32_e32 v73, 0xffff, v73                             // 000000991938: 369292FF 0000FFFF
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000991940: D622004A 03FD014A 00006400
	v_dual_mov_b32 v94, v61 :: v_dual_and_b32 v75, 0xffff, v75 // 00000099194C: CA24013D 5E4A96FF 0000FFFF
	v_dot2acc_f32_f16 v10, v37, v2                             // 000000991958: 04140525
	v_bfe_u32 v37, v26, 12, 16                                 // 00000099195C: D6100025 0241191A
	v_sad_u8 v31, v31, 0, 0x6400                               // 000000991964: D622001F 03FD011F 00006400
	v_lshlrev_b32_e32 v74, 16, v74                             // 000000991970: 30949490
	v_bfe_u32 v77, v30, 4, 16                                  // 000000991974: D610004D 0241091E
	v_lshl_or_b32 v73, v76, 16, v73                            // 00000099197C: D6560049 0525214C
	v_lshl_or_b32 v38, v38, 16, v75                            // 000000991984: D6560026 052D2126
	.long 0xd72c0025                                           // 00000099198C: D72C0025
	v_cndmask_b32_e32 v1, 0x83dcd12d, v37, vcc_lo              // 000000991990: 02024AFF 83DCD12D
	v_bfe_u32 v75, v26, 8, 16                                  // 000000991998: D610004B 0241111A
	s_waitcnt vmcnt(0)                                         // 0000009919A0: BF8903F7
	v_bfe_u32 v76, v18, 12, 16                                 // 0000009919A4: D610004C 02411912
	v_and_or_b32 v31, 0xffff, v31, v74                         // 0000009919AC: D657001F 052A3EFF 0000FFFF
	.long 0xd72c004a                                           // 0000009919B8: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 0000009919BC: 02029AFF 83DCD12D
	v_bfe_u32 v77, v18, 8, 16                                  // 0000009919C4: D610004D 02411112
	.long 0xd72c004b                                           // 0000009919CC: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 0000009919D0: 020296FF 83DCD12D
	.long 0xd72c004c                                           // 0000009919D8: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 0000009919DC: 020298FF 83DCD12D
	v_sad_u8 v37, v37, 0, 0x6400                               // 0000009919E4: D6220025 03FD0125 00006400
	v_and_b32_e32 v30, 0xffff, v30                             // 0000009919F0: 363C3CFF 0000FFFF
	.long 0xd72c004d                                           // 0000009919F8: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 0000009919FC: 02029AFF 83DCD12D
	v_dual_mov_b32 v96, v48 :: v_dual_mov_b32 v79, v67         // 000000991A04: CA100130 604E0143
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000991A0C: BF870254
	v_and_b32_e32 v37, 0xffff, v37                             // 000000991A10: 364A4AFF 0000FFFF
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000991A18: D622004B 03FD014B 00006400
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000991A24: D622004C 03FD014C 00006400
	v_bfe_u32 v78, v18, 4, 16                                  // 000000991A30: D610004E 02410912
	v_dual_mov_b32 v81, v52 :: v_dual_and_b32 v18, 0xffff, v18 // 000000991A38: CA240134 511224FF 0000FFFF
	v_lshl_or_b32 v37, v75, 16, v37                            // 000000991A44: D6560025 0495214B
	s_delay_alu instid0(VALU_DEP_4)                            // 000000991A4C: BF870004
	v_and_b32_e32 v75, 0xffff, v76                             // 000000991A50: 369698FF 0000FFFF
	v_sad_u8 v76, v77, 0, 0x6400                               // 000000991A58: D622004C 03FD014D 00006400
	v_mov_b32_e32 v77, v67                                     // 000000991A64: 7E9A0343
	.long 0xd72c001d                                           // 000000991A68: D72C001D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v30, vcc_lo              // 000000991A6C: 02023CFF 83DCD12D
	v_pk_fma_f16 v30, v73, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000991A74: CC0E001E 0BFC0D49 0000C931
	v_sad_u8 v73, v74, 0, 0x6400                               // 000000991A80: D6220049 03FD014A 00006400
	v_and_b32_e32 v74, 0xffff, v26                             // 000000991A8C: 369434FF 0000FFFF
	v_bfe_u32 v26, v26, 4, 16                                  // 000000991A94: D610001A 0241091A
	.long 0xd72c0012                                           // 000000991A9C: D72C0012
	v_cndmask_b32_e32 v1, 0x83dcd12d, v18, vcc_lo              // 000000991AA0: 020224FF 83DCD12D
	v_mov_b32_e32 v83, v71                                     // 000000991AA8: 7EA60347
	v_dot2acc_f32_f16 v9, v30, v1                              // 000000991AAC: 0412031E
	.long 0xd72c004a                                           // 000000991AB0: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000991AB4: 020294FF 83DCD12D
	.long 0xd72c001a                                           // 000000991ABC: D72C001A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v26, vcc_lo              // 000000991AC0: 020234FF 83DCD12D
	v_sad_u8 v29, v29, 0, 0x6400                               // 000000991AC8: D622001D 03FD011D 00006400
	v_pk_fma_f16 v30, v37, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000991AD4: CC0E001E 0BFC0D25 0000C931
	v_pk_fma_f16 v31, v31, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000991AE0: CC0E001F 0BFC0D1F 0000C931
	v_sad_u8 v18, v18, 0, 0x6400                               // 000000991AEC: D6220012 03FD0112 00006400
	v_lshl_or_b32 v37, v76, 16, v75                            // 000000991AF8: D6560025 052D214C
	v_dual_mov_b32 v98, v66 :: v_dual_lshlrev_b32 v29, 16, v29 // 000000991B00: CA220142 621C3A90
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000991B08: D622004A 03FD014A 00006400
	v_sad_u8 v26, v26, 0, 0x6400                               // 000000991B14: D622001A 03FD011A 00006400
	v_dual_mov_b32 v85, v71 :: v_dual_lshlrev_b32 v18, 16, v18 // 000000991B20: CA220147 55122490
	s_delay_alu instid0(VALU_DEP_3)                            // 000000991B28: BF870003
	v_dual_dot2acc_f32_f16 v17, v30, v1 :: v_dual_lshlrev_b32 v74, 16, v74// 000000991B2C: CB22031E 114A9490
	v_pk_fma_f16 v32, v32, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000991B34: CC0E0020 0BFC0D20 0000C931
	v_pk_fma_f16 v38, v38, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000991B40: CC0E0026 0BFC0D26 0000C931
	v_and_or_b32 v1, 0xffff, v73, v29                          // 000000991B4C: D6570001 047692FF 0000FFFF
	v_dot2acc_f32_f16 v9, v31, v2                              // 000000991B58: 0412051F
	v_and_or_b32 v26, 0xffff, v26, v74                         // 000000991B5C: D657001A 052A34FF 0000FFFF
	.long 0xd72c004a                                           // 000000991B68: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000991B6C: 02029CFF 83DCD12D
	v_pk_fma_f16 v29, v37, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000991B74: CC0E001D 0BFC0D25 0000C931
	v_pk_fma_f16 v36, v36, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000991B80: CC0E0024 0BFC0D24 0000C931
	v_dot2acc_f32_f16 v10, v32, v3                             // 000000991B8C: 04140720
	v_pk_fma_f16 v26, v26, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000991B90: CC0E001A 0BFC0D1A 0000C931
	v_pk_fma_f16 v1, v1, s6, 0xc931 op_sel_hi:[1,0,0]          // 000000991B9C: CC0E0001 0BFC0D01 0000C931
	v_dot2acc_f32_f16 v9, v38, v3                              // 000000991BA8: 04120726
	v_mov_b32_e32 v30, v58                                     // 000000991BAC: 7E3C033A
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000991BB0: D622004A 03FD014A 00006400
	v_dual_dot2acc_f32_f16 v17, v26, v2 :: v_dual_dot2acc_f32_f16 v10, v36, v4// 000000991BBC: CB18051A 110A0924
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000991BC4: BF870194
	v_dual_dot2acc_f32_f16 v9, v1, v4 :: v_dual_mov_b32 v26, v40// 000000991BC8: CB100901 091A0128
	v_and_or_b32 v18, 0xffff, v74, v18                         // 000000991BD0: D6570012 044A94FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000991BDC: BF870233
	v_dot2acc_f32_f16 v17, v29, v3                             // 000000991BE0: 0422071D
	v_dual_mov_b32 v29, v51 :: v_dual_mov_b32 v32, v58         // 000000991BE4: CA100133 1D20013A
	v_mov_b32_e32 v31, v41                                     // 000000991BEC: 7E3E0329
	v_pk_fma_f16 v2, v18, s6, 0xc931 op_sel_hi:[1,0,0]         // 000000991BF0: CC0E0002 0BFC0D12 0000C931
	v_mov_b32_e32 v18, v51                                     // 000000991BFC: 7E240333
	v_mov_b32_e32 v36, v60                                     // 000000991C00: 7E48033C
	v_dual_mov_b32 v38, v60 :: v_dual_mov_b32 v37, v43         // 000000991C04: CA10013C 2624012B
	s_delay_alu instid0(VALU_DEP_4)                            // 000000991C0C: BF870004
	v_dot2acc_f32_f16 v17, v2, v4                              // 000000991C10: 04220902
	v_dual_mov_b32 v73, v62 :: v_dual_mov_b32 v74, v65         // 000000991C14: CA10013E 494A0141
	v_dual_mov_b32 v76, v65 :: v_dual_mov_b32 v75, v47         // 000000991C1C: CA100141 4C4A012F
	v_dual_mov_b32 v78, v49 :: v_dual_mov_b32 v87, v42         // 000000991C24: CA100131 4E56012A
	v_mov_b32_e32 v89, v59                                     // 000000991C2C: 7EB2033B
	v_mov_b32_e32 v91, v59                                     // 000000991C30: 7EB6033B
	v_dual_mov_b32 v93, v46 :: v_dual_mov_b32 v4, v72          // 000000991C34: CA10012E 5D040148
	v_dual_mov_b32 v95, v64 :: v_dual_mov_b32 v2, v54          // 000000991C3C: CA100140 5F020136
	v_mov_b32_e32 v97, v64                                     // 000000991C44: 7EC20340
	v_mov_b32_e32 v105, v57                                    // 000000991C48: 7ED20339
	v_mov_b32_e32 v3, v72                                      // 000000991C4C: 7E060348
	v_mov_b32_e32 v1, v5                                       // 000000991C50: 7E020305
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 000000991C54: 917E057E
	s_cbranch_execz 89                                         // 000000991C58: BFA50059 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x45c0>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000991C5C: BF8700A1
	v_add_nc_u32_e32 v5, 1, v1                                 // 000000991C60: 4A0A0281
	s_mov_b32 s7, exec_lo                                      // 000000991C64: BE87007E
	.long 0xd4c9007e                                           // 000000991C68: D4C9007E
	v_cndmask_b32_e32 v1, v5, v8, vcc_lo                       // 000000991C6C: 02021105
	s_cbranch_execz 63869                                      // 000000991C70: BFA5F97D <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2a68>
	.long 0xd73c0028                                           // 000000991C74: D73C0028
	v_cndmask_b32_e32 v1, 11, v5, vcc_lo                       // 000000991C78: 02020A8B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000991C7C: BF870091
	.long 0xd7006a28                                           // 000000991C80: D7006A28
	v_cndmask_b32_e32 v1, s3, v40, vcc_lo                      // 000000991C84: 02025003
	v_add_co_ci_u32_e64 v41, null, s4, v41, vcc_lo             // 000000991C88: D5207C29 01AA5204
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000991C90: BF870092
	.long 0xd7006a6b                                           // 000000991C94: D7006A6B
	v_cndmask_b32_e32 v1, v40, v35, vcc_lo                     // 000000991C98: 02024728
	v_add_co_ci_u32_e64 v108, null, 0, v41, vcc_lo             // 000000991C9C: D5207C6C 01AA5280
	.long 0xd7006a6d                                           // 000000991CA4: D7006A6D
	v_cndmask_b32_e32 v1, v40, v33, vcc_lo                     // 000000991CA8: 02024328
	s_delay_alu instid0(VALU_DEP_1)                            // 000000991CAC: BF870001
	v_add_co_ci_u32_e64 v110, null, 0, v41, vcc_lo             // 000000991CB0: D5207C6E 01AA5280
	s_clause 0x1f                                              // 000000991CB8: BF85001F
	global_load_b32 v54, v[107:108], off                       // 000000991CBC: DC520000 367C006B
	global_load_b32 v57, v[107:108], off offset:128            // 000000991CC4: DC520080 397C006B
	global_load_b32 v53, v[107:108], off offset:256            // 000000991CCC: DC520100 357C006B
	global_load_b32 v50, v[107:108], off offset:384            // 000000991CD4: DC520180 327C006B
	global_load_b32 v48, v[107:108], off offset:512            // 000000991CDC: DC520200 307C006B
	global_load_b32 v46, v[107:108], off offset:640            // 000000991CE4: DC520280 2E7C006B
	global_load_b32 v44, v[107:108], off offset:768            // 000000991CEC: DC520300 2C7C006B
	global_load_b32 v42, v[107:108], off offset:896            // 000000991CF4: DC520380 2A7C006B
	global_load_b32 v72, v[109:110], off                       // 000000991CFC: DC520000 487C006D
	global_load_b32 v70, v[109:110], off offset:128            // 000000991D04: DC520080 467C006D
	global_load_b32 v68, v[109:110], off offset:256            // 000000991D0C: DC520100 447C006D
	global_load_b32 v66, v[109:110], off offset:384            // 000000991D14: DC520180 427C006D
	global_load_b32 v64, v[109:110], off offset:512            // 000000991D1C: DC520200 407C006D
	global_load_b32 v61, v[109:110], off offset:640            // 000000991D24: DC520280 3D7C006D
	global_load_b32 v59, v[109:110], off offset:768            // 000000991D2C: DC520300 3B7C006D
	global_load_b32 v56, v[109:110], off offset:896            // 000000991D34: DC520380 387C006D
	global_load_b32 v55, v[107:108], off offset:1024           // 000000991D3C: DC520400 377C006B
	global_load_b32 v52, v[107:108], off offset:1152           // 000000991D44: DC520480 347C006B
	global_load_b32 v49, v[107:108], off offset:1280           // 000000991D4C: DC520500 317C006B
	global_load_b32 v47, v[107:108], off offset:1408           // 000000991D54: DC520580 2F7C006B
	global_load_b32 v45, v[107:108], off offset:1536           // 000000991D5C: DC520600 2D7C006B
	global_load_b32 v43, v[107:108], off offset:1664           // 000000991D64: DC520680 2B7C006B
	global_load_b32 v41, v[107:108], off offset:1792           // 000000991D6C: DC520700 297C006B
	global_load_b32 v40, v[107:108], off offset:1920           // 000000991D74: DC520780 287C006B
	global_load_b32 v71, v[109:110], off offset:1024           // 000000991D7C: DC520400 477C006D
	global_load_b32 v69, v[109:110], off offset:1152           // 000000991D84: DC520480 457C006D
	global_load_b32 v67, v[109:110], off offset:1280           // 000000991D8C: DC520500 437C006D
	global_load_b32 v65, v[109:110], off offset:1408           // 000000991D94: DC520580 417C006D
	global_load_b32 v62, v[109:110], off offset:1536           // 000000991D9C: DC520600 3E7C006D
	global_load_b32 v60, v[109:110], off offset:1664           // 000000991DA4: DC520680 3C7C006D
	global_load_b32 v58, v[109:110], off offset:1792           // 000000991DAC: DC520700 3A7C006D
	global_load_b32 v51, v[109:110], off offset:1920           // 000000991DB4: DC520780 337C006D
	s_branch 63786                                             // 000000991DBC: BFA0F92A <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x2a68>
	s_or_b32 exec_lo, exec_lo, s5                              // 000000991DC0: 8C7E057E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000991DC4: BF870009
	s_or_b32 exec_lo, exec_lo, s0                              // 000000991DC8: 8C7E007E
	s_waitcnt vmcnt(47)                                        // 000000991DCC: BF89BFF7
	v_dual_mov_b32 v1, v28 :: v_dual_mov_b32 v2, v27           // 000000991DD0: CA10011C 0102011B
	s_waitcnt vmcnt(31)                                        // 000000991DD8: BF897FF7
	v_dual_mov_b32 v3, v25 :: v_dual_mov_b32 v4, v24           // 000000991DDC: CA100119 03040118
	s_waitcnt vmcnt(17)                                        // 000000991DE4: BF8947F7
	v_dual_mov_b32 v8, v23 :: v_dual_mov_b32 v31, v21          // 000000991DE8: CA100117 081E0115
	s_waitcnt vmcnt(16)                                        // 000000991DF0: BF8943F7
	v_dual_mov_b32 v26, v22 :: v_dual_mov_b32 v5, v20          // 000000991DF4: CA100116 1A040114
	v_dual_mov_b32 v6, v19 :: v_dual_mov_b32 v33, v10          // 000000991DFC: CA100113 0620010A
	s_waitcnt vmcnt(0)                                         // 000000991E04: BF8903F7
	v_dual_mov_b32 v18, v16 :: v_dual_mov_b32 v29, v15         // 000000991E08: CA100110 121C010F
	v_dual_mov_b32 v30, v14 :: v_dual_mov_b32 v35, v17         // 000000991E10: CA10010E 1E220111
	v_mov_b32_e32 v32, v13                                     // 000000991E18: 7E40030D
	v_mov_b32_e32 v34, v9                                      // 000000991E1C: 7E440309
	s_mov_b32 s0, 0x76543210                                   // 000000991E20: BE8000FF 76543210
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000991E28: BF870009
	v_permlanex16_b32 v1, v1, s0, 0xfedcba98                   // 000000991E2C: D65C0001 03FC0101 FEDCBA98
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 000000991E38: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 000000991E44: D65C0003 03FC0103 FEDCBA98
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 000000991E50: D65C0004 03FC0104 FEDCBA98
	v_permlanex16_b32 v8, v8, s0, 0xfedcba98                   // 000000991E5C: D65C0008 03FC0108 FEDCBA98
	v_permlanex16_b32 v26, v26, s0, 0xfedcba98                 // 000000991E68: D65C001A 03FC011A FEDCBA98
	v_permlanex16_b32 v31, v31, s0, 0xfedcba98                 // 000000991E74: D65C001F 03FC011F FEDCBA98
	v_permlanex16_b32 v5, v5, s0, 0xfedcba98                   // 000000991E80: D65C0005 03FC0105 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 000000991E8C: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v18, v18, s0, 0xfedcba98                 // 000000991E98: D65C0012 03FC0112 FEDCBA98
	v_permlanex16_b32 v29, v29, s0, 0xfedcba98                 // 000000991EA4: D65C001D 03FC011D FEDCBA98
	v_permlanex16_b32 v30, v30, s0, 0xfedcba98                 // 000000991EB0: D65C001E 03FC011E FEDCBA98
	v_permlanex16_b32 v32, v32, s0, 0xfedcba98                 // 000000991EBC: D65C0020 03FC0120 FEDCBA98
	v_permlanex16_b32 v33, v33, s0, 0xfedcba98                 // 000000991EC8: D65C0021 03FC0121 FEDCBA98
	v_permlanex16_b32 v34, v34, s0, 0xfedcba98                 // 000000991ED4: D65C0022 03FC0122 FEDCBA98
	v_permlanex16_b32 v35, v35, s0, 0xfedcba98                 // 000000991EE0: D65C0023 03FC0123 FEDCBA98
	.long 0xd44c0000                                           // 000000991EEC: D44C0000
	v_cndmask_b32_e32 v1, 16, v12, vcc_lo                      // 000000991EF0: 02021890
	s_barrier                                                  // 000000991EF4: BFBD0000
	buffer_gl0_inv                                             // 000000991EF8: E0AC0000 00000000
	s_and_saveexec_b32 s3, s0                                  // 000000991F00: BE832000
	s_cbranch_execz 37                                         // 000000991F04: BFA50025 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x479c>
	v_lshl_or_b32 v7, v11, 10, v7                              // 000000991F08: D6560007 041D150B
	v_dual_add_f32 v12, v17, v35 :: v_dual_add_f32 v1, v28, v1 // 000000991F10: C9084711 0C00031C
	v_dual_add_f32 v2, v27, v2 :: v_dual_add_f32 v3, v25, v3   // 000000991F18: C908051B 02020719
	s_delay_alu instid0(VALU_DEP_3)                            // 000000991F20: BF870003
	v_dual_add_f32 v14, v14, v30 :: v_dual_add_nc_u32 v7, 0x2800, v7// 000000991F24: C9203D0E 0E060EFF 00002800
	v_dual_add_f32 v4, v24, v4 :: v_dual_add_f32 v17, v22, v26 // 000000991F30: C9080918 04103516
	v_dual_add_f32 v8, v23, v8 :: v_dual_add_f32 v21, v21, v31 // 000000991F38: C9081117 08143F15
	v_dual_add_f32 v5, v20, v5 :: v_dual_add_f32 v6, v19, v6   // 000000991F40: C9080B14 05060D13
	v_dual_add_f32 v16, v16, v18 :: v_dual_add_f32 v15, v15, v29// 000000991F48: C9082510 100E3B0F
	v_dual_add_f32 v13, v13, v32 :: v_dual_add_f32 v10, v10, v33// 000000991F50: C908410D 0D0A430A
	v_add_f32_e32 v9, v9, v34                                  // 000000991F58: 06124509
	ds_store_2addr_b32 v7, v1, v2 offset1:16                   // 000000991F5C: D8381000 00020107
	ds_store_2addr_b32 v7, v3, v4 offset0:32 offset1:48        // 000000991F64: D8383020 00040307
	ds_store_2addr_b32 v7, v8, v17 offset0:64 offset1:80       // 000000991F6C: D8385040 00110807
	ds_store_2addr_b32 v7, v21, v5 offset0:96 offset1:112      // 000000991F74: D8387060 00051507
	ds_store_2addr_b32 v7, v6, v16 offset0:128 offset1:144     // 000000991F7C: D8389080 00100607
	ds_store_2addr_b32 v7, v15, v14 offset0:160 offset1:176    // 000000991F84: D838B0A0 000E0F07
	ds_store_2addr_b32 v7, v13, v10 offset0:192 offset1:208    // 000000991F8C: D838D0C0 000A0D07
	ds_store_2addr_b32 v7, v9, v12 offset0:224 offset1:240     // 000000991F94: D838F0E0 000C0907
	s_or_b32 exec_lo, exec_lo, s3                              // 000000991F9C: 8C7E037E
	s_waitcnt lgkmcnt(0)                                       // 000000991FA0: BF89FC07
	s_barrier                                                  // 000000991FA4: BFBD0000
	buffer_gl0_inv                                             // 000000991FA8: E0AC0000 00000000
	s_mov_b32 s3, exec_lo                                      // 000000991FB0: BE83007E
	v_cmpx_eq_u32_e32 0, v11                                   // 000000991FB4: 7D941680
	s_cbranch_execz 1349                                       // 000000991FB8: BFA50545 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x5cd0>
	v_and_b32_e32 v47, 15, v0                                  // 000000991FBC: 365E008F
	s_mul_i32 s3, s1, 0xa00                                    // 000000991FC0: 9603FF01 00000A00
	s_mul_hi_i32 s4, s1, 0xa00                                 // 000000991FC8: 9704FF01 00000A00
	s_add_u32 s5, s18, s3                                      // 000000991FD0: 80050312
	s_addc_u32 s4, s19, s4                                     // 000000991FD4: 82040413
	v_lshlrev_b32_e32 v3, 2, v47                               // 000000991FD8: 30065E82
	s_lshl_b32 s2, s2, 7                                       // 000000991FDC: 84028702
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000991FE0: BF870499
	s_ashr_i32 s3, s2, 31                                      // 000000991FE4: 86039F02
	s_lshl_b64 s[12:13], s[2:3], 1                             // 000000991FE8: 848C8102
	s_delay_alu instid0(VALU_DEP_1)                            // 000000991FEC: BF870001
	v_add_nc_u32_e32 v48, 0x2800, v3                           // 000000991FF0: 4A6006FF 00002800
	v_add_nc_u32_e32 v51, 0x3400, v3                           // 000000991FF8: 4A6606FF 00003400
	v_add_nc_u32_e32 v52, 0x3800, v3                           // 000000992000: 4A6806FF 00003800
	v_add_nc_u32_e32 v53, 0x3c00, v3                           // 000000992008: 4A6A06FF 00003C00
	v_add_nc_u32_e32 v54, 0x4000, v3                           // 000000992010: 4A6C06FF 00004000
	ds_load_2addr_b32 v[1:2], v48 offset1:16                   // 000000992018: D8DC1000 01000030
	v_add_nc_u32_e32 v55, 0x4400, v3                           // 000000992020: 4A6E06FF 00004400
	s_add_u32 s6, s5, s12                                      // 000000992028: 80060C05
	s_addc_u32 s7, s4, s13                                     // 00000099202C: 82070D04
	s_mul_i32 s2, s1, 0x500                                    // 000000992030: 9602FF01 00000500
	s_mul_hi_i32 s1, s1, 0x500                                 // 000000992038: 9701FF01 00000500
	s_add_u32 s2, s20, s2                                      // 000000992040: 80020214
	s_addc_u32 s1, s21, s1                                     // 000000992044: 82010115
	s_add_u32 s8, s2, s12                                      // 000000992048: 80080C02
	s_addc_u32 s9, s1, s13                                     // 00000099204C: 82090D01
	s_waitcnt lgkmcnt(0)                                       // 000000992050: BF89FC07
	v_dual_add_f32 v2, 0, v2 :: v_dual_add_nc_u32 v49, 0x2c00, v3// 000000992054: C9200480 023006FF 00002C00
	v_dual_add_f32 v1, 0, v1 :: v_dual_add_nc_u32 v50, 0x3000, v3// 000000992060: C9200280 013206FF 00003000
	ds_load_2addr_b32 v[3:4], v48 offset0:128 offset1:144      // 00000099206C: D8DC9080 03000030
	ds_load_2addr_b32 v[5:6], v49 offset1:16                   // 000000992074: D8DC1000 05000031
	ds_load_2addr_b32 v[7:8], v49 offset0:128 offset1:144      // 00000099207C: D8DC9080 07000031
	ds_load_2addr_b32 v[9:10], v50 offset1:16                  // 000000992084: D8DC1000 09000032
	ds_load_2addr_b32 v[11:12], v50 offset0:128 offset1:144    // 00000099208C: D8DC9080 0B000032
	ds_load_2addr_b32 v[13:14], v51 offset1:16                 // 000000992094: D8DC1000 0D000033
	ds_load_2addr_b32 v[15:16], v51 offset0:128 offset1:144    // 00000099209C: D8DC9080 0F000033
	ds_load_2addr_b32 v[17:18], v52 offset1:16                 // 0000009920A4: D8DC1000 11000034
	ds_load_2addr_b32 v[19:20], v52 offset0:128 offset1:144    // 0000009920AC: D8DC9080 13000034
	ds_load_2addr_b32 v[21:22], v53 offset1:16                 // 0000009920B4: D8DC1000 15000035
	ds_load_2addr_b32 v[23:24], v53 offset0:128 offset1:144    // 0000009920BC: D8DC9080 17000035
	ds_load_2addr_b32 v[25:26], v54 offset1:16                 // 0000009920C4: D8DC1000 19000036
	ds_load_2addr_b32 v[27:28], v54 offset0:128 offset1:144    // 0000009920CC: D8DC9080 1B000036
	ds_load_2addr_b32 v[29:30], v55 offset1:16                 // 0000009920D4: D8DC1000 1D000037
	ds_load_2addr_b32 v[31:32], v55 offset0:128 offset1:144    // 0000009920DC: D8DC9080 1F000037
	ds_load_2addr_b32 v[33:34], v48 offset0:32 offset1:48      // 0000009920E4: D8DC3020 21000030
	ds_load_2addr_b32 v[35:36], v48 offset0:160 offset1:176    // 0000009920EC: D8DCB0A0 23000030
	ds_load_2addr_b32 v[37:38], v49 offset0:32 offset1:48      // 0000009920F4: D8DC3020 25000031
	s_waitcnt lgkmcnt(17)                                      // 0000009920FC: BF89FD17
	v_add_f32_e32 v56, 0, v4                                   // 000000992100: 06700880
	s_waitcnt lgkmcnt(16)                                      // 000000992104: BF89FD07
	v_dual_add_f32 v2, v2, v6 :: v_dual_add_f32 v1, v1, v5     // 000000992108: C9080D02 02000B01
	ds_load_2addr_b32 v[39:40], v49 offset0:160 offset1:176    // 000000992110: D8DCB0A0 27000031
	ds_load_2addr_b32 v[41:42], v50 offset0:32 offset1:48      // 000000992118: D8DC3020 29000032
	ds_load_2addr_b32 v[43:44], v50 offset0:160 offset1:176    // 000000992120: D8DCB0A0 2B000032
	s_waitcnt lgkmcnt(18)                                      // 000000992128: BF89FD27
	v_add_f32_e32 v8, v56, v8                                  // 00000099212C: 06101138
	s_waitcnt lgkmcnt(17)                                      // 000000992130: BF89FD17
	v_dual_add_f32 v2, v2, v10 :: v_dual_add_f32 v3, 0, v3     // 000000992134: C9081502 02020680
	v_add_f32_e32 v1, v1, v9                                   // 00000099213C: 06021301
	ds_load_2addr_b32 v[45:46], v51 offset0:32 offset1:48      // 000000992140: D8DC3020 2D000033
	s_waitcnt lgkmcnt(17)                                      // 000000992148: BF89FD17
	v_add_f32_e32 v8, v8, v12                                  // 00000099214C: 06101908
	s_waitcnt lgkmcnt(16)                                      // 000000992150: BF89FD07
	v_dual_add_f32 v2, v2, v14 :: v_dual_add_f32 v3, v3, v7    // 000000992154: C9081D02 02020F03
	v_add_f32_e32 v1, v1, v13                                  // 00000099215C: 06021B01
	ds_load_2addr_b32 v[4:5], v51 offset0:160 offset1:176      // 000000992160: D8DCB0A0 04000033
	s_waitcnt lgkmcnt(16)                                      // 000000992168: BF89FD07
	v_add_f32_e32 v8, v8, v16                                  // 00000099216C: 06102108
	s_waitcnt lgkmcnt(15)                                      // 000000992170: BF89FCF7
	v_dual_add_f32 v2, v2, v18 :: v_dual_add_f32 v3, v3, v11   // 000000992174: C9082502 02021703
	s_waitcnt lgkmcnt(6)                                       // 00000099217C: BF89FC67
	v_dual_add_f32 v1, v1, v17 :: v_dual_add_f32 v12, 0, v35   // 000000992180: C9082301 010C4680
	v_add_f32_e32 v8, v8, v20                                  // 000000992188: 06102908
	ds_load_2addr_b32 v[6:7], v52 offset0:32 offset1:48        // 00000099218C: D8DC3020 06000034
	v_add_f32_e32 v3, v3, v15                                  // 000000992194: 06061F03
	v_add_f32_e32 v9, 0, v33                                   // 000000992198: 06124280
	v_add_f32_e32 v15, v2, v22                                 // 00000099219C: 061E2D02
	v_dual_add_f32 v1, v1, v21 :: v_dual_add_f32 v16, v8, v24  // 0000009921A0: C9082B01 01103108
	s_waitcnt lgkmcnt(6)                                       // 0000009921A8: BF89FC67
	s_delay_alu instid0(VALU_DEP_3)                            // 0000009921AC: BF870003
	v_dual_add_f32 v3, v3, v19 :: v_dual_add_f32 v14, v9, v37  // 0000009921B0: C9082703 030E4B09
	ds_load_2addr_b32 v[10:11], v53 offset0:32 offset1:48      // 0000009921B8: D8DC3020 0A000035
	v_dual_add_f32 v18, v15, v26 :: v_dual_add_f32 v1, v1, v25 // 0000009921C0: C908350F 12003301
	v_dual_add_f32 v16, v16, v28 :: v_dual_add_f32 v3, v3, v23 // 0000009921C8: C9083910 10022F03
	s_waitcnt lgkmcnt(5)                                       // 0000009921D0: BF89FC57
	v_add_f32_e32 v14, v14, v41                                // 0000009921D4: 061C530E
	ds_load_2addr_b32 v[8:9], v52 offset0:160 offset1:176      // 0000009921D8: D8DCB0A0 08000034
	v_dual_add_f32 v56, v1, v29 :: v_dual_lshlrev_b32 v1, 1, v47// 0000009921E0: C9223B01 38005E81
	s_waitcnt lgkmcnt(4)                                       // 0000009921E8: BF89FC47
	v_dual_add_f32 v17, v3, v27 :: v_dual_add_f32 v20, v14, v45// 0000009921EC: C9083703 11145B0E
	v_lshlrev_b32_e32 v47, 1, v0                               // 0000009921F4: 305E0081
	ds_load_2addr_b32 v[14:15], v54 offset0:32 offset1:48      // 0000009921F8: D8DC3020 0E000036
	ds_load_2addr_b32 v[24:25], v49 offset0:64 offset1:80      // 000000992200: D8DC5040 18000031
	ds_load_2addr_b32 v[26:27], v49 offset0:192 offset1:208    // 000000992208: D8DCD0C0 1A000031
	s_waitcnt lgkmcnt(5)                                       // 000000992210: BF89FC57
	v_dual_add_f32 v41, v17, v31 :: v_dual_add_f32 v6, v20, v6 // 000000992214: C9083F11 29060D14
	v_add_f32_e32 v3, v12, v39                                 // 00000099221C: 06064F0C
	ds_load_2addr_b32 v[12:13], v53 offset0:160 offset1:176    // 000000992220: D8DCB0A0 0C000035
	ds_load_2addr_b32 v[20:21], v48 offset0:192 offset1:208    // 000000992228: D8DCD0C0 14000030
	ds_load_2addr_b32 v[22:23], v55 offset0:32 offset1:48      // 000000992230: D8DC3020 16000037
	global_load_d16_b16 v2, v1, s[6:7]                         // 000000992238: DC820000 02060001
	s_waitcnt lgkmcnt(7)                                       // 000000992240: BF89FC77
	v_dual_add_f32 v6, v6, v10 :: v_dual_add_f32 v19, v3, v43  // 000000992244: C9081506 06125703
	v_add_f32_e32 v45, v16, v32                                // 00000099224C: 065A4110
	ds_load_2addr_b32 v[16:17], v54 offset0:160 offset1:176    // 000000992250: D8DCB0A0 10000036
	v_dual_add_f32 v43, v18, v30 :: v_dual_add_f32 v10, 0, v36 // 000000992258: C9083D12 2B0A4880
	v_add_f32_e32 v4, v19, v4                                  // 000000992260: 06080913
	ds_load_2addr_b32 v[18:19], v48 offset0:64 offset1:80      // 000000992264: D8DC5040 12000030
	ds_load_2addr_b32 v[36:37], v52 offset0:192 offset1:208    // 00000099226C: D8DCD0C0 24000034
	ds_load_2addr_b32 v[28:29], v50 offset0:64 offset1:80      // 000000992274: D8DC5040 1C000032
	ds_load_2addr_b32 v[30:31], v50 offset0:192 offset1:208    // 00000099227C: D8DCD0C0 1E000032
	ds_load_2addr_b32 v[32:33], v55 offset0:160 offset1:176    // 000000992284: D8DCB0A0 20000037
	v_add_f32_e32 v10, v10, v40                                // 00000099228C: 0614510A
	s_waitcnt lgkmcnt(12)                                      // 000000992290: BF89FCC7
	v_add_f32_e32 v4, v4, v8                                   // 000000992294: 06081104
	v_add_f32_e32 v8, 0, v34                                   // 000000992298: 06104480
	ds_load_2addr_b32 v[34:35], v51 offset0:64 offset1:80      // 00000099229C: D8DC5040 22000033
	v_or_b32_e32 v39, 32, v47                                  // 0000009922A4: 384E5EA0
	v_add_f32_e32 v8, v8, v38                                  // 0000009922A8: 06104D08
	s_waitcnt lgkmcnt(9)                                       // 0000009922AC: BF89FC97
	v_add_f32_e32 v4, v4, v12                                  // 0000009922B0: 06081904
	v_add_f32_e32 v12, v6, v14                                 // 0000009922B4: 06181D06
	global_load_d16_b16 v3, v39, s[6:7]                        // 0000009922B8: DC820000 03060027
	v_add_f32_e32 v6, v8, v42                                  // 0000009922C0: 060C5508
	v_add_f32_e32 v8, v10, v44                                 // 0000009922C4: 0610590A
	s_waitcnt lgkmcnt(6)                                       // 0000009922C8: BF89FC67
	v_add_f32_e32 v14, v4, v16                                 // 0000009922CC: 061C2104
	v_add_f32_e32 v38, v12, v22                                // 0000009922D0: 064C2D0C
	s_waitcnt lgkmcnt(5)                                       // 0000009922D4: BF89FC57
	v_add_f32_e32 v16, 0, v18                                  // 0000009922D8: 06202480
	v_add_f32_e32 v8, v8, v5                                   // 0000009922DC: 06100B08
	ds_load_2addr_b32 v[4:5], v51 offset0:192 offset1:208      // 0000009922E0: D8DCD0C0 04000033
	v_add_f32_e32 v6, v6, v46                                  // 0000009922E8: 060C5D06
	v_add_f32_e32 v18, 0, v20                                  // 0000009922EC: 06242880
	v_add_f32_e32 v12, v16, v24                                // 0000009922F0: 06183110
	v_add_f32_e32 v8, v8, v9                                   // 0000009922F4: 06101308
	s_waitcnt lgkmcnt(2)                                       // 0000009922F8: BF89FC27
	v_add_f32_e32 v40, v14, v32                                // 0000009922FC: 0650410E
	v_add_f32_e32 v10, v6, v7                                  // 000000992300: 06140F06
	ds_load_2addr_b32 v[6:7], v52 offset0:64 offset1:80        // 000000992304: D8DC5040 06000034
	v_dual_add_f32 v16, v18, v26 :: v_dual_add_f32 v13, v8, v13// 00000099230C: C9083512 100C1B08
	ds_load_2addr_b32 v[8:9], v53 offset0:64 offset1:80        // 000000992314: D8DC5040 08000035
	v_add_f32_e32 v18, v10, v11                                // 00000099231C: 0624170A
	v_add_f32_e32 v12, v12, v28                                // 000000992320: 0618390C
	v_add_f32_e32 v16, v16, v30                                // 000000992324: 06203D10
	v_add_f32_e32 v30, v13, v17                                // 000000992328: 063C230D
	v_add_f32_e32 v20, 0, v19                                  // 00000099232C: 06282680
	v_add_f32_e32 v22, v18, v15                                // 000000992330: 062C1F12
	s_waitcnt lgkmcnt(3)                                       // 000000992334: BF89FC37
	v_add_f32_e32 v18, v12, v34                                // 000000992338: 0624450C
	ds_load_2addr_b32 v[12:13], v54 offset0:64 offset1:80      // 00000099233C: D8DC5040 0C000036
	ds_load_2addr_b32 v[14:15], v54 offset0:192 offset1:208    // 000000992344: D8DCD0C0 0E000036
	v_add_f32_e32 v28, 0, v21                                  // 00000099234C: 06382A80
	ds_load_2addr_b32 v[10:11], v53 offset0:192 offset1:208    // 000000992350: D8DCD0C0 0A000035
	v_add_f32_e32 v42, v22, v23                                // 000000992358: 06542F16
	s_waitcnt lgkmcnt(5)                                       // 00000099235C: BF89FC57
	v_add_f32_e32 v4, v16, v4                                  // 000000992360: 06080910
	v_add_f32_e32 v32, v20, v25                                // 000000992364: 06403314
	ds_load_2addr_b32 v[20:21], v48 offset0:96 offset1:112     // 000000992368: D8DC7060 14000030
	ds_load_2addr_b32 v[24:25], v48 offset0:224 offset1:240    // 000000992370: D8DCF0E0 18000030
	ds_load_2addr_b32 v[22:23], v50 offset0:96 offset1:112     // 000000992378: D8DC7060 16000032
	s_waitcnt lgkmcnt(7)                                       // 000000992380: BF89FC77
	v_add_f32_e32 v6, v18, v6                                  // 000000992384: 060C0D12
	ds_load_2addr_b32 v[16:17], v55 offset0:64 offset1:80      // 000000992388: D8DC5040 10000037
	ds_load_2addr_b32 v[18:19], v55 offset0:192 offset1:208    // 000000992390: D8DCD0C0 12000037
	v_add_f32_e32 v32, v32, v29                                // 000000992398: 06403B20
	v_or_b32_e32 v46, 0x60, v47                                // 00000099239C: 385C5EFF 00000060
	s_waitcnt lgkmcnt(8)                                       // 0000009923A4: BF89FC87
	v_add_f32_e32 v6, v6, v8                                   // 0000009923A8: 060C1106
	v_add_f32_e32 v8, v28, v27                                 // 0000009923AC: 0610371C
	s_waitcnt lgkmcnt(7)                                       // 0000009923B0: BF89FC77
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009923B4: BF870112
	v_add_f32_e32 v6, v6, v12                                  // 0000009923B8: 060C1906
	v_add_f32_e32 v8, v8, v31                                  // 0000009923BC: 06103F08
	v_add_f32_e32 v12, v32, v35                                // 0000009923C0: 06184720
	s_waitcnt lgkmcnt(4)                                       // 0000009923C4: BF89FC47
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000009923C8: BF870132
	v_dual_add_f32 v5, v8, v5 :: v_dual_add_f32 v8, 0, v20     // 0000009923CC: C9080B08 05082880
	s_waitcnt lgkmcnt(1)                                       // 0000009923D4: BF89FC17
	v_add_f32_e32 v16, v6, v16                                 // 0000009923D8: 06202106
	v_dual_add_f32 v6, v12, v7 :: v_dual_add_f32 v7, v5, v37   // 0000009923DC: C9080F0C 06064B05
	v_add_f32_e32 v12, 0, v24                                  // 0000009923E4: 06183080
	global_load_d16_b16 v5, v1, s[6:7] offset:1280             // 0000009923E8: DC820500 05060001
	v_dual_add_f32 v44, v6, v9 :: v_dual_add_f32 v7, v7, v11   // 0000009923F0: C9081306 2C061707
	s_clause 0x1                                               // 0000009923F8: BF850001
	global_load_d16_b16 v6, v39, s[6:7] offset:1280            // 0000009923FC: DC820500 06060027
	global_load_d16_b16 v9, v46, s[6:7]                        // 000000992404: DC820000 0906002E
	v_add_f32_e32 v13, v44, v13                                // 00000099240C: 061A1B2C
	v_add_f32_e32 v7, v7, v15                                  // 000000992410: 060E1F07
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000992414: BF870122
	v_add_f32_e32 v13, v13, v17                                // 000000992418: 061A230D
	s_waitcnt lgkmcnt(0)                                       // 00000099241C: BF89FC07
	v_dual_add_f32 v19, v7, v19 :: v_dual_add_f32 v26, v4, v36 // 000000992420: C9082707 131A4904
	ds_load_2addr_b32 v[34:35], v52 offset0:96 offset1:112     // 000000992428: D8DC7060 22000034
	ds_load_2addr_b32 v[36:37], v52 offset0:224 offset1:240    // 000000992430: D8DCF0E0 24000034
	global_load_d16_b16 v4, v1, s[6:7] offset:64               // 000000992438: DC820040 04060001
	v_add_f32_e32 v10, v26, v10                                // 000000992440: 0614151A
	ds_load_2addr_b32 v[26:27], v49 offset0:96 offset1:112     // 000000992444: D8DC7060 1A000031
	ds_load_2addr_b32 v[28:29], v49 offset0:224 offset1:240    // 00000099244C: D8DCF0E0 1C000031
	v_add_f32_e32 v10, v10, v14                                // 000000992454: 06141D0A
	v_add_f32_e32 v14, v30, v33                                // 000000992458: 061C431E
	ds_load_2addr_b32 v[30:31], v51 offset0:96 offset1:112     // 00000099245C: D8DC7060 1E000033
	ds_load_2addr_b32 v[32:33], v51 offset0:224 offset1:240    // 000000992464: D8DCF0E0 20000033
	v_add_f32_e32 v18, v10, v18                                // 00000099246C: 0624250A
	ds_load_2addr_b32 v[10:11], v50 offset0:224 offset1:240    // 000000992470: D8DCF0E0 0A000032
	s_waitcnt lgkmcnt(4)                                       // 000000992478: BF89FC47
	v_add_f32_e32 v8, v8, v26                                  // 00000099247C: 06103508
	s_waitcnt lgkmcnt(3)                                       // 000000992480: BF89FC37
	v_add_f32_e32 v12, v12, v28                                // 000000992484: 0618390C
	v_add_f32_e32 v26, 0, v21                                  // 000000992488: 06342A80
	v_add_f32_e32 v28, 0, v25                                  // 00000099248C: 06383280
	ds_load_2addr_b32 v[20:21], v53 offset0:96 offset1:112     // 000000992490: D8DC7060 14000035
	ds_load_2addr_b32 v[24:25], v53 offset0:224 offset1:240    // 000000992498: D8DCF0E0 18000035
	v_add_f32_e32 v22, v8, v22                                 // 0000009924A0: 062C2D08
	global_load_d16_b16 v8, v39, s[8:9]                        // 0000009924A4: DC820000 08080027
	s_waitcnt lgkmcnt(4)                                       // 0000009924AC: BF89FC47
	v_dual_add_f32 v39, v28, v29 :: v_dual_add_f32 v30, v22, v30// 0000009924B0: C9083B1C 271E3D16
	s_waitcnt lgkmcnt(2)                                       // 0000009924B8: BF89FC27
	v_add_f32_e32 v10, v12, v10                                // 0000009924BC: 0614150C
	v_add_f32_e32 v12, v26, v27                                // 0000009924C0: 0618371A
	ds_load_2addr_b32 v[26:27], v54 offset0:96 offset1:112     // 0000009924C4: D8DC7060 1A000036
	ds_load_2addr_b32 v[28:29], v54 offset0:224 offset1:240    // 0000009924CC: D8DCF0E0 1C000036
	v_dual_add_f32 v39, v39, v11 :: v_dual_add_f32 v30, v30, v34// 0000009924D4: C9081727 271E451E
	v_add_f32_e32 v32, v10, v32                                // 0000009924DC: 0640410A
	v_add_f32_e32 v12, v12, v23                                // 0000009924E0: 06182F0C
	ds_load_2addr_b32 v[10:11], v55 offset0:96 offset1:112     // 0000009924E4: D8DC7060 0A000037
	ds_load_2addr_b32 v[22:23], v55 offset0:224 offset1:240    // 0000009924EC: D8DCF0E0 16000037
	v_add_f32_e32 v32, v32, v36                                // 0000009924F4: 06404920
	v_dual_add_f32 v12, v12, v31 :: v_dual_add_f32 v31, v39, v33// 0000009924F8: C9083F0C 0C1E4327
	s_waitcnt lgkmcnt(5)                                       // 000000992500: BF89FC57
	v_add_f32_e32 v15, v30, v20                                // 000000992504: 061E291E
	s_waitcnt lgkmcnt(4)                                       // 000000992508: BF89FC47
	v_add_f32_e32 v20, v32, v24                                // 00000099250C: 06283120
	v_dual_add_f32 v12, v12, v35 :: v_dual_add_f32 v31, v31, v37// 000000992510: C908470C 0C1E4B1F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000992518: BF870111
	v_dual_add_f32 v12, v12, v21 :: v_dual_and_b32 v37, 1, v0  // 00000099251C: C9242B0C 0C240081
	v_add_f32_e32 v21, v31, v25                                // 000000992524: 062A331F
	s_waitcnt lgkmcnt(3)                                       // 000000992528: BF89FC37
	v_add_f32_e32 v15, v15, v26                                // 00000099252C: 061E350F
	s_waitcnt lgkmcnt(2)                                       // 000000992530: BF89FC27
	v_add_f32_e32 v17, v20, v28                                // 000000992534: 06223914
	v_add_f32_e32 v25, v18, v19                                // 000000992538: 06322712
	v_add_f32_e32 v12, v12, v27                                // 00000099253C: 0618370C
	s_waitcnt lgkmcnt(1)                                       // 000000992540: BF89FC17
	v_dual_add_f32 v20, v21, v29 :: v_dual_add_f32 v7, v15, v10// 000000992544: C9083B15 1406150F
	s_waitcnt lgkmcnt(0)                                       // 00000099254C: BF89FC07
	v_dual_add_f32 v10, v17, v22 :: v_dual_sub_f32 v17, v56, v43// 000000992550: C90A2D11 0A105738
	v_add_f32_e32 v11, v12, v11                                // 000000992558: 0616170C
	s_delay_alu instid0(VALU_DEP_3)                            // 00000099255C: BF870003
	v_dual_add_f32 v12, v20, v23 :: v_dual_add_f32 v23, v41, v45// 000000992560: C9082F14 0C165B29
	v_add_f32_e32 v24, v40, v14                                // 000000992568: 06301D28
	.long 0xd44a0002                                           // 00000099256C: D44A0002
	v_cndmask_b32_e32 v1, 0, v37, vcc_lo                       // 000000992570: 02024A80
	v_sub_f32_e32 v37, v41, v45                                // 000000992574: 084A5B29
	v_sub_f32_e32 v21, v38, v42                                // 000000992578: 082A5526
	v_add_f32_e32 v27, v10, v12                                // 00000099257C: 0636190A
	v_dual_add_f32 v30, v23, v24 :: v_dual_add_f32 v15, v56, v43// 000000992580: C9083117 1E0E5738
	v_add_f32_e32 v20, v38, v42                                // 000000992588: 06285526
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000099258C: BF870214
	v_add_f32_e32 v36, v17, v21                                // 000000992590: 06482B11
	v_add_f32_e32 v31, v25, v27                                // 000000992594: 063E3719
	v_dual_sub_f32 v18, v18, v19 :: v_dual_and_b32 v19, 2, v0  // 000000992598: C9642712 12120082
	v_sub_f32_e32 v17, v17, v21                                // 0000009925A0: 08222B11
	v_add_f32_e32 v29, v15, v20                                // 0000009925A4: 063A290F
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009925A8: BF870004
	v_add_f32_e32 v21, v30, v31                                // 0000009925AC: 062A3F1E
	v_sub_f32_e32 v10, v10, v12                                // 0000009925B0: 0814190A
	.long 0xd44a0003                                           // 0000009925B4: D44A0003
	v_cndmask_b32_e32 v1, 0, v19, vcc_lo                       // 0000009925B8: 02022680
	v_sub_f32_e32 v19, v23, v24                                // 0000009925BC: 08263117
	v_dual_sub_f32 v23, v25, v27 :: v_dual_add_f32 v22, v16, v13// 0000009925C0: C9483719 17161B10
	v_dual_sub_f32 v13, v16, v13 :: v_dual_add_f32 v16, v7, v11// 0000009925C8: C9481B10 0D101707
	v_sub_f32_e32 v11, v7, v11                                 // 0000009925D0: 08161707
	v_sub_f32_e32 v15, v15, v20                                // 0000009925D4: 081E290F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009925D8: BF870214
	v_dual_add_f32 v27, v19, v23 :: v_dual_and_b32 v24, 4, v0  // 0000009925DC: C9242F13 1B180084
	v_add_f32_e32 v39, v22, v16                                // 0000009925E4: 064E2116
	v_sub_f32_e32 v16, v22, v16                                // 0000009925E8: 08202116
	v_mov_b32_dpp v22, v21 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009925EC: 7E2C02FA FF016115
	v_cndmask_b32_e64 v21, -v21, v21, s2                       // 0000009925F4: D5010015 200A2B15
	.long 0xd44a0004                                           // 0000009925FC: D44A0004
	v_cndmask_b32_e32 v1, 0, v24, vcc_lo                       // 000000992600: 02023080
	v_mov_b32_dpp v24, v27 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000992604: 7E3002FA FF01611B
	v_and_b32_e32 v0, 8, v0                                    // 00000099260C: 36000088
	v_or_b32_e32 v28, 0xa0, v47                                // 000000992610: 38385EFF 000000A0
	v_add_f32_e32 v12, v21, v22                                // 000000992618: 06182D15
	v_add_f32_e32 v21, v13, v11                                // 00000099261C: 062A170D
	v_dual_sub_f32 v11, v13, v11 :: v_dual_sub_f32 v14, v40, v14// 000000992620: C94A170D 0B0E1D28
	v_add_f32_e32 v40, v18, v10                                // 000000992628: 06501512
	s_delay_alu instid0(VALU_DEP_4)                            // 00000099262C: BF870004
	v_mov_b32_dpp v41, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000992630: 7E5202FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, s3                       // 000000992638: D501000C 200E190C
	.long 0xd44a0001                                           // 000000992640: D44A0001
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 000000992644: 02020080
	v_add_f32_e32 v22, v37, v14                                // 000000992648: 062C1D25
	v_sub_f32_e32 v0, v37, v14                                 // 00000099264C: 08001D25
	v_sub_f32_e32 v10, v18, v10                                // 000000992650: 08141512
	v_add_f32_e32 v12, v12, v41                                // 000000992654: 0618530C
	v_or_b32_e32 v20, 0xe0, v47                                // 000000992658: 38285EFF 000000E0
	v_add_f32_e32 v13, v22, v40                                // 000000992660: 061A5116
	s_clause 0x4                                               // 000000992664: BF850004
	global_load_d16_b16 v32, v28, s[6:7]                       // 000000992668: DC820000 2006001C
	global_load_d16_b16 v33, v1, s[6:7] offset:1344            // 000000992670: DC820540 21060001
	global_load_d16_b16 v7, v1, s[6:7] offset:1408             // 000000992678: DC820580 07060001
	global_load_d16_b16 v34, v1, s[6:7] offset:1472            // 000000992680: DC8205C0 22060001
	global_load_d16_b16 v35, v1, s[6:7] offset:192             // 000000992688: DC8200C0 23060001
	v_sub_f32_e32 v22, v22, v40                                // 000000992690: 082C5116
	v_mov_b32_dpp v41, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000992694: 7E5202FA FF01640C
	v_cndmask_b32_e64 v12, -v12, v12, s4                       // 00000099269C: D501000C 2012190C
	v_mov_b32_dpp v25, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009926A4: 7E3202FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, s2                       // 0000009926AC: D501000D 200A1B0D
	global_load_d16_b16 v38, v20, s[6:7]                       // 0000009926B4: DC820000 26060014
	v_add_f32_e32 v43, v36, v21                                // 0000009926BC: 06562B24
	v_add_f32_e32 v12, v12, v41                                // 0000009926C0: 0618530C
	s_clause 0x3                                               // 0000009926C4: BF850003
	global_load_d16_b16 v37, v1, s[8:9]                        // 0000009926C8: DC820000 25080001
	global_load_d16_b16 v40, v1, s[8:9] offset:64              // 0000009926D0: DC820040 28080001
	global_load_d16_b16 v41, v1, s[8:9] offset:128             // 0000009926D8: DC820080 29080001
	global_load_d16_b16 v42, v1, s[8:9] offset:192             // 0000009926E0: DC8200C0 2A080001
	v_add_f32_e32 v13, v13, v25                                // 0000009926E8: 061A330D
	v_cndmask_b32_e64 v25, -v27, v27, s2                       // 0000009926EC: D5010019 200A371B
	v_mov_b32_dpp v45, v43 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009926F4: 7E5A02FA FF01612B
	v_cndmask_b32_e64 v43, -v43, v43, s2                       // 0000009926FC: D501002B 200A572B
	v_mov_b32_dpp v47, v22 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000992704: 7E5E02FA FF016116
	v_mov_b32_dpp v27, v13 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000099270C: 7E3602FA FF01620D
	v_cndmask_b32_e64 v13, -v13, v13, s3                       // 000000992714: D501000D 200E1B0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000099271C: BF8701A4
	v_dual_add_f32 v24, v25, v24 :: v_dual_add_f32 v43, v43, v45// 000000992720: C9083119 182A5B2B
	v_cndmask_b32_e64 v22, -v22, v22, s2                       // 000000992728: D5010016 200A2D16
	v_add_f32_e32 v13, v13, v27                                // 000000992730: 061A370D
	s_delay_alu instid0(VALU_DEP_3)                            // 000000992734: BF870003
	v_mov_b32_dpp v14, v24 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000992738: 7E1C02FA FF016218
	v_cndmask_b32_e64 v18, -v24, v24, s3                       // 000000992740: D5010012 200E3118
	v_sub_f32_e32 v24, v30, v31                                // 000000992748: 08303F1E
	global_load_d16_b16 v27, v46, s[6:7] offset:1280           // 00000099274C: DC820500 1B06002E
	v_mov_b32_dpp v25, v13 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000992754: 7E3202FA FF01640D
	v_cndmask_b32_e64 v13, -v13, v13, s4                       // 00000099275C: D501000D 20121B0D
	v_add_f32_e32 v14, v18, v14                                // 000000992764: 061C1D12
	v_dual_sub_f32 v18, v19, v23 :: v_dual_add_f32 v19, v0, v10// 000000992768: C9482F13 12121500
	v_mov_b32_dpp v23, v12 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000992770: 7E2E02FA FF01680C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000992778: BF870214
	v_add_f32_e32 v13, v13, v25                                // 00000099277C: 061A330D
	v_mov_b32_dpp v25, v14 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000992780: 7E3202FA FF01640E
	v_cndmask_b32_e64 v14, -v14, v14, s4                       // 000000992788: D501000E 20121D0E
	v_mov_b32_dpp v30, v19 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000992790: 7E3C02FA FF016113
	v_cndmask_b32_e64 v19, -v19, v19, s2                       // 000000992798: D5010013 200A2713
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 0000009927A0: D501000C 2006190C
	v_mov_b32_dpp v31, v13 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009927A8: 7E3E02FA FF01680D
	v_cndmask_b32_e64 v13, -v13, v13, s1                       // 0000009927B0: D501000D 20061B0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000009927B8: BF870234
	v_dual_add_f32 v14, v14, v25 :: v_dual_add_f32 v19, v19, v30// 0000009927BC: C908330E 0E123D13
	v_sub_f32_e32 v0, v0, v10                                  // 0000009927C4: 08001500
	v_add_f32_e32 v10, v12, v23                                // 0000009927C8: 06142F0C
	v_add_f32_e32 v12, v13, v31                                // 0000009927CC: 06183F0D
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009927D0: BF870004
	v_mov_b32_dpp v13, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009927D4: 7E1A02FA FF01680E
	v_mov_b32_dpp v23, v19 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009927DC: 7E2E02FA FF016213
	v_cndmask_b32_e64 v19, -v19, v19, s3                       // 0000009927E4: D5010013 200E2713
	v_cndmask_b32_e64 v14, -v14, v14, s1                       // 0000009927EC: D501000E 20061D0E
	v_mov_b32_dpp v25, v24 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009927F4: 7E3202FA FF016118
	v_cndmask_b32_e64 v24, -v24, v24, s2                       // 0000009927FC: D5010018 200A3118
	v_add_f32_e32 v31, v29, v39                                // 000000992804: 063E4F1D
	v_add_f32_e32 v19, v19, v23                                // 000000992808: 06262F13
	v_add_f32_e32 v13, v14, v13                                // 00000099280C: 061A1B0E
	global_load_d16_b16 v23, v28, s[6:7] offset:1280           // 000000992810: DC820500 1706001C
	v_add_f32_e32 v14, v24, v25                                // 000000992818: 061C3318
	s_clause 0x1                                               // 00000099281C: BF850001
	global_load_d16_b16 v25, v20, s[6:7] offset:1280           // 000000992820: DC820500 19060014
	global_load_d16_b16 v26, v1, s[6:7] offset:128             // 000000992828: DC820080 1A060001
	v_mov_b32_dpp v24, v19 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000992830: 7E3002FA FF016413
	v_cndmask_b32_e64 v19, -v19, v19, s4                       // 000000992838: D5010013 20122713
	s_clause 0x1                                               // 000000992840: BF850001
	global_load_d16_b16 v28, v28, s[8:9]                       // 000000992844: DC820000 1C08001C
	global_load_d16_b16 v20, v20, s[8:9]                       // 00000099284C: DC820000 14080014
	v_mov_b32_dpp v30, v14 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000992854: 7E3C02FA FF01620E
	v_cndmask_b32_e64 v14, -v14, v14, s3                       // 00000099285C: D501000E 200E1D0E
	v_add_f32_e32 v19, v19, v24                                // 000000992864: 06263113
	global_load_d16_b16 v24, v46, s[8:9]                       // 000000992868: DC820000 1808002E
	v_add_f32_e32 v22, v22, v47                                // 000000992870: 062C5F16
	v_mul_f32_e32 v10, 0x3db504f3, v10                         // 000000992874: 101414FF 3DB504F3
	v_add_f32_e32 v14, v14, v30                                // 00000099287C: 061C3D0E
	v_mov_b32_dpp v30, v31 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000992880: 7E3C02FA FF01611F
	v_cndmask_b32_e64 v31, -v31, v31, s2                       // 000000992888: D501001F 200A3F1F
	v_mov_b32_dpp v44, v19 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000992890: 7E5802FA FF016813
	v_cndmask_b32_e64 v19, -v19, v19, s1                       // 000000992898: D5010013 20062713
	v_dual_sub_f32 v29, v29, v39 :: v_dual_mul_f32 v12, 0x3db504f3, v12// 0000009928A0: C9464F1D 1D0C18FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009928AC: BF870004
	v_add_f32_e32 v30, v31, v30                                // 0000009928B0: 063C3D1F
	v_mov_b32_dpp v31, v14 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009928B4: 7E3E02FA FF01640E
	v_cndmask_b32_e64 v14, -v14, v14, s4                       // 0000009928BC: D501000E 20121D0E
	v_add_f32_e32 v19, v19, v44                                // 0000009928C4: 06265913
	v_mul_f32_e32 v13, 0x3db504f3, v13                         // 0000009928C8: 101A1AFF 3DB504F3
	v_mov_b32_dpp v46, v30 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009928D0: 7E5C02FA FF01621E
	v_cndmask_b32_e64 v30, -v30, v30, s3                       // 0000009928D8: D501001E 200E3D1E
	v_add_f32_e32 v14, v14, v31                                // 0000009928E0: 061C3F0E
	v_mov_b32_dpp v31, v43 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009928E4: 7E3E02FA FF01622B
	v_cndmask_b32_e64 v43, -v43, v43, s3                       // 0000009928EC: D501002B 200E572B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000009928F4: BF870234
	v_dual_mul_f32 v19, 0x3db504f3, v19 :: v_dual_add_f32 v30, v30, v46// 0000009928F8: C8C826FF 131E5D1E 3DB504F3
	v_mov_b32_dpp v46, v22 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000992904: 7E5C02FA FF016216
	v_cndmask_b32_e64 v22, -v22, v22, s3                       // 00000099290C: D5010016 200E2D16
	v_add_f32_e32 v31, v43, v31                                // 000000992914: 063E3F2B
	v_mov_b32_dpp v43, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000992918: 7E5602FA FF01680E
	v_mov_b32_dpp v45, v30 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000992920: 7E5A02FA FF01641E
	v_cndmask_b32_e64 v30, -v30, v30, s4                       // 000000992928: D501001E 20123D1E
	v_add_f32_e32 v22, v22, v46                                // 000000992930: 062C5D16
	v_mov_b32_dpp v44, v31 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000992934: 7E5802FA FF01641F
	v_cndmask_b32_e64 v31, -v31, v31, s4                       // 00000099293C: D501001F 20123F1F
	v_mov_b32_dpp v46, v18 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000992944: 7E5C02FA FF016112
	v_add_f32_e32 v30, v30, v45                                // 00000099294C: 063C5B1E
	v_cndmask_b32_e64 v18, -v18, v18, s2                       // 000000992950: D5010012 200A2512
	v_cndmask_b32_e64 v14, -v14, v14, s1                       // 000000992958: D501000E 20061D0E
	v_add_f32_e32 v31, v31, v44                                // 000000992960: 063E591F
	v_mov_b32_dpp v44, v22 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000992964: 7E5802FA FF016416
	v_mov_b32_dpp v45, v30 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000099296C: 7E5A02FA FF01681E
	v_cndmask_b32_e64 v30, -v30, v30, s1                       // 000000992974: D501001E 20063D1E
	v_add_f32_e32 v18, v18, v46                                // 00000099297C: 06245D12
	v_cndmask_b32_e64 v22, -v22, v22, s4                       // 000000992980: D5010016 20122D16
	v_add_f32_e32 v14, v14, v43                                // 000000992988: 061C570E
	s_delay_alu instid0(VALU_DEP_4)                            // 00000099298C: BF870004
	v_add_f32_e32 v30, v30, v45                                // 000000992990: 063C5B1E
	v_mov_b32_dpp v45, v31 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000992994: 7E5A02FA FF01681F
	v_cndmask_b32_e64 v31, -v31, v31, s1                       // 00000099299C: D501001F 20063F1F
	v_mov_b32_dpp v46, v18 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009929A4: 7E5C02FA FF016212
	v_cndmask_b32_e64 v18, -v18, v18, s3                       // 0000009929AC: D5010012 200E2512
	v_mul_f32_e32 v30, 0x3db504f3, v30                         // 0000009929B4: 103C3CFF 3DB504F3
	v_add_f32_e32 v22, v22, v44                                // 0000009929BC: 062C5916
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000009929C0: BF8701A3
	v_add_f32_e32 v18, v18, v46                                // 0000009929C4: 06245D12
	s_waitcnt vmcnt(23)                                        // 0000009929C8: BF895FF7
	v_fma_mix_f32 v2, v2, v30, neg(0) op_sel_hi:[1,0,0]        // 0000009929CC: CC200002 8A023D02
	v_add_f32_e32 v30, v31, v45                                // 0000009929D4: 063C5B1F
	v_mov_b32_dpp v31, v22 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009929D8: 7E3E02FA FF016816
	v_cndmask_b32_e64 v22, -v22, v22, s1                       // 0000009929E0: D5010016 20062D16
	v_mov_b32_dpp v44, v18 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009929E8: 7E5802FA FF016412
	v_mul_f32_e32 v43, 0xbfb8aa3b, v2                          // 0000009929F0: 105604FF BFB8AA3B
	v_mul_f32_e32 v30, 0x3db504f3, v30                         // 0000009929F8: 103C3CFF 3DB504F3
	v_cndmask_b32_e64 v18, -v18, v18, s4                       // 000000992A00: D5010012 20122512
	v_dual_add_f32 v22, v22, v31 :: v_dual_add_f32 v31, v15, v16// 000000992A08: C9083F16 161E210F
	s_delay_alu instid0(VALU_DEP_4)                            // 000000992A10: BF870004
	v_exp_f32_e32 v43, v43                                     // 000000992A14: 7E564B2B
	s_waitcnt vmcnt(22)                                        // 000000992A18: BF895BF7
	v_fma_mix_f32 v3, v3, v30, neg(0) op_sel_hi:[1,0,0]        // 000000992A1C: CC200003 8A023D03
	v_add_f32_e32 v18, v18, v44                                // 000000992A24: 06245912
	v_mov_b32_dpp v44, v0 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000992A28: 7E5802FA FF016100
	v_cndmask_b32_e64 v0, -v0, v0, s2                          // 000000992A30: D5010000 200A0100
	v_mov_b32_dpp v45, v31 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000992A38: 7E5A02FA FF01611F
	v_mul_f32_e32 v30, 0xbfb8aa3b, v3                          // 000000992A40: 103C06FF BFB8AA3B
	v_cndmask_b32_e64 v31, -v31, v31, s2                       // 000000992A48: D501001F 200A3F1F
	v_mul_f32_e32 v22, 0x3db504f3, v22                         // 000000992A50: 102C2CFF 3DB504F3
	v_dual_add_f32 v0, v0, v44 :: v_dual_add_f32 v43, 1.0, v43 // 000000992A58: C9085900 002A56F2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000992A60: BF870194
	v_exp_f32_e32 v30, v30                                     // 000000992A64: 7E3C4B1E
	v_add_f32_e32 v31, v31, v45                                // 000000992A68: 063E5B1F
	v_mov_b32_dpp v44, v18 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000992A6C: 7E5802FA FF016812
	s_delay_alu instid0(VALU_DEP_3)                            // 000000992A74: BF870003
	v_mov_b32_dpp v45, v0 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000992A78: 7E5A02FA FF016200
	v_cndmask_b32_e64 v0, -v0, v0, s3                          // 000000992A80: D5010000 200E0100
	v_div_scale_f32 v46, null, v43, v43, v2                    // 000000992A88: D6FC7C2E 040A572B
	v_cndmask_b32_e64 v18, -v18, v18, s1                       // 000000992A90: D5010012 20062512
	v_mov_b32_dpp v48, v31 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000992A98: 7E6002FA FF01621F
	v_cndmask_b32_e64 v31, -v31, v31, s3                       // 000000992AA0: D501001F 200E3F1F
	v_add_f32_e32 v0, v0, v45                                  // 000000992AA8: 06005B00
	v_add_f32_e32 v30, 1.0, v30                                // 000000992AAC: 063C3CF2
	v_rcp_f32_e32 v47, v46                                     // 000000992AB0: 7E5E552E
	v_add_f32_e32 v18, v18, v44                                // 000000992AB4: 06245912
	v_add_f32_e32 v31, v31, v48                                // 000000992AB8: 063E611F
	v_mov_b32_dpp v44, v0 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000992ABC: 7E5802FA FF016400
	v_div_scale_f32 v45, null, v30, v30, v3                    // 000000992AC4: D6FC7C2D 040E3D1E
	v_cndmask_b32_e64 v0, -v0, v0, s4                          // 000000992ACC: D5010000 20120100
	v_mul_f32_e32 v18, 0x3db504f3, v18                         // 000000992AD4: 102424FF 3DB504F3
	v_mov_b32_dpp v50, v31 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000992ADC: 7E6402FA FF01641F
	v_cndmask_b32_e64 v31, -v31, v31, s4                       // 000000992AE4: D501001F 20123F1F
	v_rcp_f32_e32 v48, v45                                     // 000000992AEC: 7E60552D
	v_add_f32_e32 v0, v0, v44                                  // 000000992AF0: 06005900
	v_add_f32_e32 v44, v17, v11                                // 000000992AF4: 06581711
	v_fma_f32 v49, -v46, v47, 1.0                              // 000000992AF8: D6130031 23CA5F2E
	v_add_f32_e32 v31, v31, v50                                // 000000992B00: 063E651F
	v_sub_f32_e32 v11, v17, v11                                // 000000992B04: 08161711
	s_delay_alu instid0(VALU_DEP_4)                            // 000000992B08: BF870004
	v_mov_b32_dpp v51, v44 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000992B0C: 7E6602FA FF01612C
	v_cndmask_b32_e64 v44, -v44, v44, s2                       // 000000992B14: D501002C 200A592C
	v_fmac_f32_e32 v47, v49, v47                               // 000000992B1C: 565E5F31
	v_div_scale_f32 v49, vcc_lo, v2, v43, v2                   // 000000992B20: D6FC6A31 040A5702
	v_fma_f32 v50, -v45, v48, 1.0                              // 000000992B28: D6130032 23CA612D
	v_mov_b32_dpp v52, v31 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000992B30: 7E6802FA FF01681F
	v_cndmask_b32_e64 v31, -v31, v31, s1                       // 000000992B38: D501001F 20063F1F
	v_add_f32_e32 v44, v44, v51                                // 000000992B40: 0658672C
	v_mov_b32_dpp v51, v0 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000992B44: 7E6602FA FF016800
	v_fmac_f32_e32 v48, v50, v48                               // 000000992B4C: 56606132
	v_div_scale_f32 v50, s5, v3, v30, v3                       // 000000992B50: D6FC0532 040E3D03
	v_dual_add_f32 v31, v31, v52 :: v_dual_mul_f32 v52, v49, v47// 000000992B58: C906691F 1F345F31
	v_mov_b32_dpp v54, v44 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000992B60: 7E6C02FA FF01622C
	v_cndmask_b32_e64 v44, -v44, v44, s3                       // 000000992B68: D501002C 200E592C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000992B70: BF870214
	v_mul_f32_e32 v53, v50, v48                                // 000000992B74: 106A6132
	v_mul_f32_e32 v31, 0x3db504f3, v31                         // 000000992B78: 103E3EFF 3DB504F3
	v_fma_f32 v55, -v46, v52, v49                              // 000000992B80: D6130037 24C6692E
	v_cndmask_b32_e64 v0, -v0, v0, s1                          // 000000992B88: D5010000 20060100
	v_add_f32_e32 v44, v44, v54                                // 000000992B90: 06586D2C
	v_fma_f32 v56, -v45, v53, v50                              // 000000992B94: D6130038 24CA6B2D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000992B9C: BF870214
	v_fmac_f32_e32 v52, v55, v47                               // 000000992BA0: 56685F37
	v_add_f32_e32 v0, v0, v51                                  // 000000992BA4: 06006700
	s_waitcnt vmcnt(21)                                        // 000000992BA8: BF8957F7
	v_fma_mix_f32 v5, v5, v10, neg(0) op_sel_hi:[1,0,0]        // 000000992BAC: CC200005 8A021505
	v_fmac_f32_e32 v53, v56, v48                               // 000000992BB4: 566A6138
	s_waitcnt vmcnt(20)                                        // 000000992BB8: BF8953F7
	v_fma_mix_f32 v6, v6, v12, neg(0) op_sel_hi:[1,0,0]        // 000000992BBC: CC200006 8A021906
	v_fma_f32 v46, -v46, v52, v49                              // 000000992BC4: D613002E 24C6692E
	v_mul_f32_e32 v0, 0x3db504f3, v0                           // 000000992BCC: 100000FF 3DB504F3
	v_fma_f32 v45, -v45, v53, v50                              // 000000992BD4: D613002D 24CA6B2D
	s_waitcnt vmcnt(18)                                        // 000000992BDC: BF894BF7
	v_fma_mix_f32 v4, v4, v31, neg(0) op_sel_hi:[1,0,0]        // 000000992BE0: CC200004 8A023F04
	v_mov_b32_dpp v31, v44 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000992BE8: 7E3E02FA FF01642C
	v_cndmask_b32_e64 v44, -v44, v44, s4                       // 000000992BF0: D501002C 2012592C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000992BF8: BF8701A3
	v_mul_f32_e32 v51, 0xbfb8aa3b, v4                          // 000000992BFC: 106608FF BFB8AA3B
	v_sub_f32_e32 v21, v36, v21                                // 000000992C04: 082A2B24
	v_add_f32_e32 v31, v44, v31                                // 000000992C08: 063E3F2C
	v_div_fmas_f32 v44, v46, v47, v52                          // 000000992C0C: D637002C 04D25F2E
	s_mov_b32 vcc_lo, s5                                       // 000000992C14: BEEA0005
	v_exp_f32_e32 v49, v51                                     // 000000992C18: 7E624B33
	v_div_fmas_f32 v45, v45, v48, v53                          // 000000992C1C: D637002D 04D6612D
	v_mov_b32_dpp v46, v31 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000992C24: 7E5C02FA FF01681F
	v_cndmask_b32_e64 v31, -v31, v31, s1                       // 000000992C2C: D501001F 20063F1F
	v_div_fixup_f32 v2, v44, v43, v2                           // 000000992C34: D6270002 040A572C
	v_mov_b32_dpp v36, v21 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000992C3C: 7E4802FA FF016115
	v_div_fixup_f32 v3, v45, v30, v3                           // 000000992C44: D6270003 040E3D2D
	v_cndmask_b32_e64 v21, -v21, v21, s2                       // 000000992C4C: D5010015 200A2B15
	v_add_f32_e32 v10, v31, v46                                // 000000992C54: 06145D1F
	v_mov_b32_dpp v31, v29 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000992C58: 7E3E02FA FF01611D
	v_cndmask_b32_e64 v29, -v29, v29, s2                       // 000000992C60: D501001D 200A3B1D
	v_dual_add_f32 v47, 1.0, v49 :: v_dual_mul_f32 v2, v5, v2  // 000000992C68: C90662F2 2F020505
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000992C70: BF870194
	v_dual_mul_f32 v10, 0x3db504f3, v10 :: v_dual_sub_f32 v15, v15, v16// 000000992C74: C8CA14FF 0A0E210F 3DB504F3
	v_add_f32_e32 v5, v29, v31                                 // 000000992C80: 060A3F1D
	v_mul_f32_e32 v3, v6, v3                                   // 000000992C84: 10060706
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000992C88: BF870214
	v_div_scale_f32 v30, null, v47, v47, v4                    // 000000992C8C: D6FC7C1E 04125F2F
	v_fma_mix_f32 v6, v9, v10, neg(0) op_sel_hi:[1,0,0]        // 000000992C94: CC200006 8A021509
	v_add_f32_e32 v9, v21, v36                                 // 000000992C9C: 06124915
	v_mov_b32_dpp v21, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000992CA0: 7E2A02FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 000000992CA8: D5010005 200E0B05
	v_mov_b32_dpp v16, v15 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000992CB0: 7E2002FA FF01610F
	v_cndmask_b32_e64 v15, -v15, v15, s2                       // 000000992CB8: D501000F 200A1F0F
	v_mov_b32_dpp v29, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000992CC0: 7E3A02FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 000000992CC8: D5010009 200E1309
	v_add_f32_e32 v5, v5, v21                                  // 000000992CD0: 060A2B05
	s_waitcnt vmcnt(17)                                        // 000000992CD4: BF8947F7
	v_fma_mix_f32 v3, v8, v3, neg(0) op_sel_hi:[1,0,0]         // 000000992CD8: CC200003 8A020708
	v_add_f32_e32 v15, v15, v16                                // 000000992CE0: 061E210F
	v_mov_b32_dpp v16, v11 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000992CE4: 7E2002FA FF01610B
	v_cndmask_b32_e64 v11, -v11, v11, s2                       // 000000992CEC: D501000B 200A170B
	v_add_f32_e32 v9, v9, v29                                  // 000000992CF4: 06123B09
	v_mov_b32_dpp v17, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000992CF8: 7E2202FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s4                          // 000000992D00: D5010005 20120B05
	v_mov_b32_dpp v29, v15 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000992D08: 7E3A02FA FF01620F
	v_cndmask_b32_e64 v15, -v15, v15, s3                       // 000000992D10: D501000F 200E1F0F
	v_dual_add_f32 v11, v11, v16 :: v_dual_mul_f32 v8, 0xbfb8aa3b, v6// 000000992D18: C906210B 0B080CFF BFB8AA3B
	v_mov_b32_dpp v21, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000992D24: 7E2A02FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s4                          // 000000992D2C: D5010009 20121309
	v_add_f32_e32 v5, v5, v17                                  // 000000992D34: 060A2305
	v_add_f32_e32 v15, v15, v29                                // 000000992D38: 061E3B0F
	v_mov_b32_dpp v16, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000992D3C: 7E2002FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s3                       // 000000992D44: D501000B 200E170B
	v_exp_f32_e32 v8, v8                                       // 000000992D4C: 7E104B08
	v_add_f32_e32 v9, v9, v21                                  // 000000992D50: 06122B09
	v_mov_b32_dpp v17, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000992D54: 7E2202FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s1                          // 000000992D5C: D5010005 20060B05
	v_mov_b32_dpp v21, v15 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000992D64: 7E2A02FA FF01640F
	v_cndmask_b32_e64 v15, -v15, v15, s4                       // 000000992D6C: D501000F 20121F0F
	v_add_f32_e32 v11, v11, v16                                // 000000992D74: 0616210B
	v_rcp_f32_e32 v12, v30                                     // 000000992D78: 7E18551E
	v_mov_b32_dpp v16, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000992D7C: 7E2002FA FF016809
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 000000992D84: D5010009 20061309
	v_add_f32_e32 v5, v5, v17                                  // 000000992D8C: 060A2305
	v_add_f32_e32 v15, v15, v21                                // 000000992D90: 061E2B0F
	v_mov_b32_dpp v17, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000992D94: 7E2202FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s4                       // 000000992D9C: D501000B 2012170B
	v_add_f32_e32 v8, 1.0, v8                                  // 000000992DA4: 061010F2
	v_add_f32_e32 v9, v9, v16                                  // 000000992DA8: 06122109
	v_mov_b32_dpp v16, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000992DAC: 7E2002FA FF01680F
	v_cndmask_b32_e64 v15, -v15, v15, s1                       // 000000992DB4: D501000F 20061F0F
	v_add_f32_e32 v11, v11, v17                                // 000000992DBC: 0616230B
	v_fma_f32 v10, -v30, v12, 1.0                              // 000000992DC0: D613000A 23CA191E
	v_mul_f32_e32 v5, 0x3db504f3, v5                           // 000000992DC8: 100A0AFF 3DB504F3
	v_div_scale_f32 v17, null, v8, v8, v6                      // 000000992DD0: D6FC7C11 041A1108
	v_add_f32_e32 v15, v15, v16                                // 000000992DD8: 061E210F
	v_mov_b32_dpp v16, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000992DDC: 7E2002FA FF01680B
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 000000992DE4: D501000B 2006170B
	v_fmac_f32_e32 v12, v10, v12                               // 000000992DEC: 5618190A
	v_div_scale_f32 v10, vcc_lo, v4, v47, v4                   // 000000992DF0: D6FC6A0A 04125F04
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 000000992DF8: 101212FF 3DB504F3
	v_rcp_f32_e32 v21, v17                                     // 000000992E00: 7E2A5511
	v_add_f32_e32 v11, v11, v16                                // 000000992E04: 0616210B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000992E08: BF870113
	v_dual_mul_f32 v15, 0x3db504f3, v15 :: v_dual_mul_f32 v16, v10, v12// 000000992E0C: C8C61EFF 0F10190A 3DB504F3
	v_mul_f32_e32 v11, 0x3db504f3, v11                         // 000000992E18: 101616FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000992E20: BF870092
	v_fma_f32 v31, -v30, v16, v10                              // 000000992E24: D613001F 242A211E
	v_fmac_f32_e32 v16, v31, v12                               // 000000992E2C: 5620191F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000992E30: BF870091
	v_fma_f32 v10, -v30, v16, v10                              // 000000992E34: D613000A 242A211E
	v_div_fmas_f32 v10, v10, v12, v16                          // 000000992E3C: D637000A 0442190A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000992E44: BF870001
	v_div_fixup_f32 v4, v10, v47, v4                           // 000000992E48: D6270004 04125F0A
	s_waitcnt vmcnt(16)                                        // 000000992E50: BF8943F7
	v_fma_mix_f32 v9, v32, v9, neg(0) op_sel_hi:[1,0,0]        // 000000992E54: CC200009 8A021320
	v_fma_f32 v32, -v17, v21, 1.0                              // 000000992E5C: D6130020 23CA2B11
	s_waitcnt vmcnt(15)                                        // 000000992E64: BF893FF7
	v_fma_mix_f32 v13, v33, v13, neg(0) op_sel_hi:[1,0,0]      // 000000992E68: CC20000D 8A021B21
	s_waitcnt vmcnt(12)                                        // 000000992E70: BF8933F7
	v_fma_mix_f32 v15, v35, v15, neg(0) op_sel_hi:[1,0,0]      // 000000992E74: CC20000F 8A021F23
	v_mul_f32_e32 v29, 0xbfb8aa3b, v9                          // 000000992E7C: 103A12FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000992E84: BF870193
	v_dual_fmac_f32 v21, v32, v21 :: v_dual_mul_f32 v4, v13, v4// 000000992E88: C8062B20 1504090D
	v_mul_f32_e32 v35, 0xbfb8aa3b, v15                         // 000000992E90: 10461EFF BFB8AA3B
	s_waitcnt vmcnt(11)                                        // 000000992E98: BF892FF7
	v_fma_mix_f32 v11, v38, v11, neg(0) op_sel_hi:[1,0,0]      // 000000992E9C: CC20000B 8A021726
	v_exp_f32_e32 v29, v29                                     // 000000992EA4: 7E3A4B1D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000992EA8: BF870092
	v_exp_f32_e32 v31, v35                                     // 000000992EAC: 7E3E4B23
	v_mul_f32_e32 v32, 0xbfb8aa3b, v11                         // 000000992EB0: 104016FF BFB8AA3B
	v_div_scale_f32 v35, s5, v6, v8, v6                        // 000000992EB8: D6FC0523 041A1106
	s_mov_b32 vcc_lo, s5                                       // 000000992EC0: BEEA0005
	v_exp_f32_e32 v30, v32                                     // 000000992EC4: 7E3C4B20
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000992EC8: BF870317
	v_add_f32_e32 v29, 1.0, v29                                // 000000992ECC: 063A3AF2
	v_dual_mul_f32 v32, v35, v21 :: v_dual_add_f32 v31, 1.0, v31// 000000992ED0: C8C82B23 201E3EF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000992ED8: BF870112
	v_div_scale_f32 v39, null, v29, v29, v9                    // 000000992EDC: D6FC7C27 04263B1D
	v_fma_f32 v16, -v17, v32, v35                              // 000000992EE4: D6130010 248E4111
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000992EEC: BF870293
	v_div_scale_f32 v12, null, v31, v31, v15                   // 000000992EF0: D6FC7C0C 043E3F1F
	v_add_f32_e32 v30, 1.0, v30                                // 000000992EF8: 063C3CF2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000992EFC: BF870194
	v_rcp_f32_e32 v43, v39                                     // 000000992F00: 7E565527
	v_fmac_f32_e32 v32, v16, v21                               // 000000992F04: 56402B10
	s_waitcnt vmcnt(6)                                         // 000000992F08: BF891BF7
	v_fma_mix_f32 v19, v27, v19, neg(0) op_sel_hi:[1,0,0]      // 000000992F0C: CC200013 8A02271B
	v_rcp_f32_e32 v45, v12                                     // 000000992F14: 7E5A550C
	v_div_scale_f32 v33, null, v30, v30, v11                   // 000000992F18: D6FC7C21 042E3D1E
	v_fma_f32 v17, -v17, v32, v35                              // 000000992F20: D6130011 248E4111
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000992F28: BF870092
	v_rcp_f32_e32 v16, v33                                     // 000000992F2C: 7E205521
	v_div_fmas_f32 v17, v17, v21, v32                          // 000000992F30: D6370011 04822B11
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000992F38: BF870116
	v_fma_f32 v13, -v12, v45, 1.0                              // 000000992F3C: D613000D 23CA5B0C
	v_div_fixup_f32 v6, v17, v8, v6                            // 000000992F44: D6270006 041A1111
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000992F4C: BF870292
	v_fmac_f32_e32 v45, v13, v45                               // 000000992F50: 565A5B0D
	v_fma_f32 v46, -v33, v16, 1.0                              // 000000992F54: D613002E 23CA2121
	v_div_scale_f32 v13, s8, v15, v31, v15                     // 000000992F5C: D6FC080D 043E3F0F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000992F64: BF870194
	v_mul_f32_e32 v6, v19, v6                                  // 000000992F68: 100C0D13
	v_fmac_f32_e32 v16, v46, v16                               // 000000992F6C: 5620212E
	v_div_scale_f32 v46, s5, v11, v30, v11                     // 000000992F70: D6FC052E 042E3D0B
	s_delay_alu instid0(VALU_DEP_4)                            // 000000992F78: BF870004
	v_mul_f32_e32 v47, v13, v45                                // 000000992F7C: 105E5B0D
	s_waitcnt vmcnt(4)                                         // 000000992F80: BF8913F7
	v_fma_mix_f32 v0, v25, v0, neg(0) op_sel_hi:[1,0,0]        // 000000992F84: CC200000 8A020119
	s_waitcnt vmcnt(3)                                         // 000000992F8C: BF890FF7
	v_fma_mix_f32 v5, v26, v5, neg(0) op_sel_hi:[1,0,0]        // 000000992F90: CC200005 8A020B1A
	v_fma_f32 v17, -v12, v47, v13                              // 000000992F98: D6130011 24365F0C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000992FA0: BF870112
	v_mul_f32_e32 v26, 0xbfb8aa3b, v5                          // 000000992FA4: 10340AFF BFB8AA3B
	v_fmac_f32_e32 v47, v17, v45                               // 000000992FAC: 565E5B11
	s_waitcnt vmcnt(0)                                         // 000000992FB0: BF8903F7
	v_fma_mix_f32 v6, v24, v6, neg(0) op_sel_hi:[1,0,0]        // 000000992FB4: CC200006 8A020D18
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000992FBC: BF870293
	v_exp_f32_e32 v26, v26                                     // 000000992FC0: 7E344B1A
	v_add_f32_e32 v26, 1.0, v26                                // 000000992FC4: 063434F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(TRANS32_DEP_1)// 000000992FC8: BF8702C1
	v_div_scale_f32 v36, null, v26, v26, v5                    // 000000992FCC: D6FC7C24 0416351A
	v_div_scale_f32 v10, s6, v5, v26, v5                       // 000000992FD4: D6FC060A 04163505
	s_mov_b32 vcc_lo, s6                                       // 000000992FDC: BEEA0006
	v_rcp_f32_e32 v38, v36                                     // 000000992FE0: 7E4C5524
	v_fma_f32 v44, -v36, v38, 1.0                              // 000000992FE4: D613002C 23CA4D24
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000992FEC: BF870121
	v_fmac_f32_e32 v38, v44, v38                               // 000000992FF0: 564C4D2C
	v_fma_f32 v44, -v39, v43, 1.0                              // 000000992FF4: D613002C 23CA5727
	v_mul_f32_e32 v35, v10, v38                                // 000000992FFC: 10464D0A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000993000: BF8701A2
	v_fmac_f32_e32 v43, v44, v43                               // 000000993004: 5656572C
	v_div_scale_f32 v44, s7, v9, v29, v9                       // 000000993008: D6FC072C 04263B09
	v_fma_f32 v21, -v36, v35, v10                              // 000000993010: D6130015 242A4724
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000993018: BF870121
	v_dual_mul_f32 v32, v44, v43 :: v_dual_fmac_f32 v35, v21, v38// 00000099301C: C8C0572C 20224D15
	v_mul_f32_e32 v21, v46, v16                                // 000000993024: 102A212E
	v_fma_f32 v8, -v39, v32, v44                               // 000000993028: D6130008 24B24127
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000993030: BF870113
	v_fma_f32 v10, -v36, v35, v10                              // 000000993034: D613000A 242A4724
	v_fmac_f32_e32 v32, v8, v43                                // 00000099303C: 56405708
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000993040: BF870194
	v_fma_f32 v8, -v33, v21, v46                               // 000000993044: D6130008 24BA2B21
	v_div_fmas_f32 v10, v10, v38, v35                          // 00000099304C: D637000A 048E4D0A
	s_mov_b32 vcc_lo, s7                                       // 000000993054: BEEA0007
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000993058: BF870193
	v_fma_f32 v17, -v39, v32, v44                              // 00000099305C: D6130011 24B24127
	v_fmac_f32_e32 v21, v8, v16                                // 000000993064: 562A2108
	v_fma_f32 v8, -v12, v47, v13                               // 000000993068: D6130008 24365F0C
	v_div_fixup_f32 v5, v10, v26, v5                           // 000000993070: D6270005 0416350A
	v_mul_f32_e32 v14, 0x3db504f3, v14                         // 000000993078: 101C1CFF 3DB504F3
	v_div_fmas_f32 v12, v17, v43, v32                          // 000000993080: D637000C 04825711
	v_fma_f32 v13, -v33, v21, v46                              // 000000993088: D613000D 24BA2B21
	s_mov_b32 vcc_lo, s8                                       // 000000993090: BEEA0008
	v_fma_mix_f32 v10, v34, v18, neg(0) op_sel_hi:[1,0,0]      // 000000993094: CC20000A 8A022522
	v_div_fmas_f32 v8, v8, v45, v47                            // 00000099309C: D6370008 04BE5B08
	s_mov_b32 vcc_lo, s5                                       // 0000009930A4: BEEA0005
	v_div_fixup_f32 v9, v12, v29, v9                           // 0000009930A8: D6270009 04263B0C
	v_div_fmas_f32 v13, v13, v16, v21                          // 0000009930B0: D637000D 0456210D
	v_fma_mix_f32 v12, v23, v22, neg(0) op_sel_hi:[1,0,0]      // 0000009930B8: CC20000C 8A022D17
	v_fma_mix_f32 v7, v7, v14, neg(0) op_sel_hi:[1,0,0]        // 0000009930C0: CC200007 8A021D07
	v_div_fixup_f32 v8, v8, v31, v15                           // 0000009930C8: D6270008 043E3F08
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009930D0: BF870214
	v_div_fixup_f32 v11, v13, v30, v11                         // 0000009930D4: D627000B 042E3D0D
	v_mul_f32_e32 v9, v12, v9                                  // 0000009930DC: 1012130C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000009930E0: BF870223
	v_dual_mul_f32 v5, v7, v5 :: v_dual_mul_f32 v8, v10, v8    // 0000009930E4: C8C60B07 0508110A
	v_fma_mix_f32 v10, v4, v40, v6 op_sel_hi:[0,1,0]           // 0000009930EC: CC20000A 141A5104
	v_mul_f32_e32 v0, v0, v11                                  // 0000009930F4: 10001700
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009930F8: BF870004
	v_fma_mix_f32 v7, v28, v9, neg(0) op_sel_hi:[1,0,0]        // 0000009930FC: CC200007 8A02131C
	v_fma_mix_f32 v9, v2, v37, v3 op_sel_hi:[0,1,0]            // 000000993104: CC200009 140E4B02
	v_fma_mix_f32 v2, v2, v37, -v3 op_sel_hi:[0,1,0]           // 00000099310C: CC200002 940E4B02
	v_fma_mix_f32 v3, v4, v40, -v6 op_sel_hi:[0,1,0]           // 000000993114: CC200003 941A5104
	v_fma_mix_f32 v0, v20, v0, neg(0) op_sel_hi:[1,0,0]        // 00000099311C: CC200000 8A020114
	v_fma_mix_f32 v11, v5, v41, v7 op_sel_hi:[0,1,0]           // 000000993124: CC20000B 141E5305
	v_fma_mix_f32 v4, v5, v41, -v7 op_sel_hi:[0,1,0]           // 00000099312C: CC200004 941E5305
	v_add_f32_e32 v5, v9, v10                                  // 000000993134: 060A1509
	v_sub_f32_e32 v7, v9, v10                                  // 000000993138: 080E1509
	v_fma_mix_f32 v12, v8, v42, v0 op_sel_hi:[0,1,0]           // 00000099313C: CC20000C 14025508
	v_fma_mix_f32 v0, v8, v42, -v0 op_sel_hi:[0,1,0]           // 000000993144: CC200000 94025508
	v_add_f32_e32 v8, v2, v3                                   // 00000099314C: 06100702
	v_sub_f32_e32 v2, v2, v3                                   // 000000993150: 08040702
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000993154: BF8701B4
	v_add_f32_e32 v6, v11, v12                                 // 000000993158: 060C190B
	v_sub_f32_e32 v9, v11, v12                                 // 00000099315C: 0812190B
	v_add_f32_e32 v10, v4, v0                                  // 000000993160: 06140104
	v_dual_sub_f32 v0, v4, v0 :: v_dual_add_f32 v3, v5, v6     // 000000993164: C9480104 00020D05
	v_sub_f32_e32 v4, v5, v6                                   // 00000099316C: 08080D05
	s_delay_alu instid0(VALU_DEP_3)                            // 000000993170: BF870003
	v_add_f32_e32 v6, v8, v10                                  // 000000993174: 060C1508
	v_sub_f32_e32 v8, v8, v10                                  // 000000993178: 08101508
	v_add_f32_e32 v10, v7, v9                                  // 00000099317C: 06141307
	v_mov_b32_dpp v5, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000993180: 7E0A02FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s2                          // 000000993188: D5010003 200A0703
	v_sub_f32_e32 v7, v7, v9                                   // 000000993190: 080E1307
	v_mov_b32_dpp v14, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000993194: 7E1C02FA FF016104
	v_mov_b32_dpp v9, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000099319C: 7E1202FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 0000009931A4: D501000A 200A150A
	v_add_f32_e32 v3, v3, v5                                   // 0000009931AC: 06060B03
	v_mov_b32_dpp v5, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009931B0: 7E0A02FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s2                          // 0000009931B8: D5010006 200A0D06
	v_cndmask_b32_e64 v15, -v4, v4, s2                         // 0000009931C0: D501000F 200A0904
	v_add_f32_e32 v9, v10, v9                                  // 0000009931C8: 0612130A
	v_mov_b32_dpp v11, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009931CC: 7E1602FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 0000009931D4: D5010003 200E0703
	v_add_f32_e32 v5, v6, v5                                   // 0000009931DC: 060A0B06
	v_add_f32_e32 v6, v2, v0                                   // 0000009931E0: 060C0102
	v_sub_f32_e32 v10, v2, v0                                  // 0000009931E4: 08140102
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009931E8: BF870214
	v_add_f32_e32 v0, v3, v11                                  // 0000009931EC: 06001703
	v_mov_b32_dpp v2, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009931F0: 7E0402FA FF016205
	v_cndmask_b32_e64 v3, -v5, v5, s3                          // 0000009931F8: D5010003 200E0B05
	v_mov_b32_dpp v5, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000993200: 7E0A02FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 000000993208: D5010009 200E1309
	v_mov_b32_dpp v11, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000993210: 7E1602FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s2                          // 000000993218: D5010006 200A0D06
	v_add_f32_e32 v2, v3, v2                                   // 000000993220: 06040503
	v_mov_b32_dpp v16, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000993224: 7E2002FA FF01610A
	v_add_f32_e32 v5, v9, v5                                   // 00000099322C: 060A0B09
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 000000993230: D501000A 200A150A
	v_add_f32_e32 v6, v6, v11                                  // 000000993238: 060C1706
	v_mov_b32_dpp v9, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000099323C: 7E1202FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s4                          // 000000993244: D5010002 20120502
	v_mov_b32_dpp v11, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000099324C: 7E1602FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s4                          // 000000993254: D5010005 20120B05
	v_mov_b32_dpp v12, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000099325C: 7E1802FA FF016206
	v_cndmask_b32_e64 v13, -v6, v6, s3                         // 000000993264: D501000D 200E0D06
	v_add_f32_e32 v4, v2, v9                                   // 00000099326C: 06081302
	v_add_f32_e32 v10, v10, v16                                // 000000993270: 0614210A
	v_dual_add_f32 v6, v5, v11 :: v_dual_add_f32 v11, v15, v14 // 000000993274: C9081705 060A1D0F
	v_mov_b32_dpp v14, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000099327C: 7E1C02FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 000000993284: D5010008 200A1108
	v_mov_b32_dpp v15, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000099328C: 7E1E02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s2                          // 000000993294: D5010007 200A0F07
	v_add_f32_e32 v9, v13, v12                                 // 00000099329C: 0612190D
	v_mov_b32_dpp v13, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009932A0: 7E1A02FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s3                       // 0000009932A8: D501000B 200E170B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000009932B0: BF870234
	v_dual_add_f32 v8, v8, v14 :: v_dual_add_f32 v7, v7, v15   // 0000009932B4: C9081D08 08061F07
	v_mov_b32_dpp v15, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009932BC: 7E1E02FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, s3                       // 0000009932C4: D501000A 200E150A
	v_add_f32_e32 v11, v11, v13                                // 0000009932CC: 06161B0B
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009932D0: BF870004
	v_mov_b32_dpp v13, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009932D4: 7E1A02FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s3                          // 0000009932DC: D5010008 200E1108
	v_mov_b32_dpp v14, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009932E4: 7E1C02FA FF016207
	v_cndmask_b32_e64 v7, -v7, v7, s3                          // 0000009932EC: D5010007 200E0F07
	v_add_f32_e32 v10, v10, v15                                // 0000009932F4: 06141F0A
	v_mov_b32_dpp v3, v0 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009932F8: 7E0602FA FF016400
	v_add_f32_e32 v8, v8, v13                                  // 000000993300: 06101B08
	v_cndmask_b32_e64 v0, -v0, v0, s4                          // 000000993304: D5010000 20120100
	v_add_f32_e32 v7, v7, v14                                  // 00000099330C: 060E1D07
	v_mov_b32_dpp v12, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000993310: 7E1802FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s4                          // 000000993318: D5010009 20121309
	v_mov_b32_dpp v13, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000993320: 7E1A02FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s4                       // 000000993328: D501000B 2012170B
	v_mov_b32_dpp v14, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000993330: 7E1C02FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, s4                          // 000000993338: D5010008 20121108
	v_mov_b32_dpp v15, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000993340: 7E1E02FA FF016407
	v_cndmask_b32_e64 v7, -v7, v7, s4                          // 000000993348: D5010007 20120F07
	v_mov_b32_dpp v16, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000993350: 7E2002FA FF01640A
	v_cndmask_b32_e64 v17, -v10, v10, s4                       // 000000993358: D5010011 2012150A
	v_dual_add_f32 v0, v0, v3 :: v_dual_add_f32 v9, v9, v12    // 000000993360: C9080700 00081909
	v_dual_add_f32 v10, v11, v13 :: v_dual_add_f32 v11, v8, v14// 000000993368: C9081B0B 0A0A1D08
	v_add_f32_e32 v13, v7, v15                                 // 000000993370: 061A1F07
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000993374: BF870214
	v_add_f32_e32 v15, v17, v16                                // 000000993378: 061E2111
	v_mov_b32_dpp v2, v0 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000099337C: 7E0402FA FF016800
	v_mov_b32_dpp v3, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000993384: 7E0602FA FF016804
	v_mov_b32_dpp v5, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000099338C: 7E0A02FA FF016806
	v_mov_b32_dpp v7, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000993394: 7E0E02FA FF016809
	v_mov_b32_dpp v8, v10 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000099339C: 7E1002FA FF01680A
	v_mov_b32_dpp v12, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009933A4: 7E1802FA FF01680B
	v_mov_b32_dpp v14, v13 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009933AC: 7E1C02FA FF01680D
	v_mov_b32_dpp v16, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009933B4: 7E2002FA FF01680F
	s_mov_b32 s2, 0x3db504f3                                   // 0000009933BC: BE8200FF 3DB504F3
	s_and_b32 exec_lo, exec_lo, s0                             // 0000009933C4: 8B7E007E
	s_cbranch_execz 65                                         // 0000009933C8: BFA50041 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_gu_tILi4ELi8ELi2ELi1EEEvPKjPKDF16_PKiS5_S5_PDF16_NS0_4HtSdEi+0x5cd0>
	v_cndmask_b32_e64 v15, -v15, v15, s1                       // 0000009933CC: D501000F 20061F0F
	v_cndmask_b32_e64 v0, -v0, v0, s1                          // 0000009933D4: D5010000 20060100
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 0000009933DC: D5010004 20060904
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 0000009933E4: D5010006 20060D06
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 0000009933EC: D5010009 20061309
	v_cndmask_b32_e64 v13, -v13, v13, s1                       // 0000009933F4: D501000D 20061B0D
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 0000009933FC: D501000A 2006150A
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 000000993404: D501000B 2006170B
	v_dual_add_f32 v15, v15, v16 :: v_dual_add_f32 v0, v0, v2  // 00000099340C: C908210F 0F000500
	v_add_f32_e32 v3, v4, v3                                   // 000000993414: 06060704
	v_add_f32_e32 v5, v6, v5                                   // 000000993418: 060A0B06
	v_add_f32_e32 v7, v9, v7                                   // 00000099341C: 060E0F09
	s_mul_i32 s0, s10, 0x500                                   // 000000993420: 9600FF0A 00000500
	v_dual_add_f32 v13, v13, v14 :: v_dual_add_f32 v8, v10, v8 // 000000993428: C9081D0D 0D08110A
	s_mul_hi_i32 s1, s10, 0x500                                // 000000993430: 9701FF0A 00000500
	v_add_f32_e32 v11, v11, v12                                // 000000993438: 0616190B
	s_add_u32 s0, s22, s0                                      // 00000099343C: 80000016
	v_fma_mixlo_f16 v0, v0, s2, 0                              // 000000993440: CC210000 02000500
	s_addc_u32 s1, s23, s1                                     // 000000993448: 82010117
	v_fma_mixhi_f16 v0, v3, s2, 0                              // 00000099344C: CC220000 02000503
	s_add_u32 s0, s0, s12                                      // 000000993454: 80000C00
	v_fma_mixlo_f16 v2, v5, s2, 0                              // 000000993458: CC210002 02000505
	s_addc_u32 s1, s1, s13                                     // 000000993460: 82010D01
	v_fma_mixhi_f16 v2, v7, s2, 0                              // 000000993464: CC220002 02000507
	v_fma_mixlo_f16 v3, v8, s2, 0                              // 00000099346C: CC210003 02000508
	v_fma_mixhi_f16 v3, v11, s2, 0                             // 000000993474: CC220003 0200050B
	v_fma_mixlo_f16 v4, v13, s2, 0                             // 00000099347C: CC210004 0200050D
	v_fma_mixhi_f16 v4, v15, s2, 0                             // 000000993484: CC220004 0200050F
	s_clause 0x7                                               // 00000099348C: BF850007
	global_store_b16 v1, v0, s[0:1]                            // 000000993490: DC660000 00000001
	global_store_d16_hi_b16 v1, v0, s[0:1] offset:32           // 000000993498: DC960020 00000001
	global_store_b16 v1, v2, s[0:1] offset:64                  // 0000009934A0: DC660040 00000201
	global_store_d16_hi_b16 v1, v2, s[0:1] offset:96           // 0000009934A8: DC960060 00000201
	global_store_b16 v1, v3, s[0:1] offset:128                 // 0000009934B0: DC660080 00000301
	global_store_d16_hi_b16 v1, v3, s[0:1] offset:160          // 0000009934B8: DC9600A0 00000301
	global_store_b16 v1, v4, s[0:1] offset:192                 // 0000009934C0: DC6600C0 00000401
	global_store_d16_hi_b16 v1, v4, s[0:1] offset:224          // 0000009934C8: DC9600E0 00000401
	s_nop 0                                                    // 0000009934D0: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000009934D4: BFB60003
	s_endpgm                                                   // 0000009934D8: BFB00000
		...

