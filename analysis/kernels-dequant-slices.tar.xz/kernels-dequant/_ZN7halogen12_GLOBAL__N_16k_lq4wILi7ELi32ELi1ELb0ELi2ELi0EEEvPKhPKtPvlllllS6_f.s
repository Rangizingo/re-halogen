0000000000825100 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000825100: F4100100 F8000000
	v_dual_mov_b32 v4, 0 :: v_dual_and_b32 v1, 15, v0          // 000000825108: CA240080 0400008F
	v_lshrrev_b32_e32 v2, 2, v0                                // 000000825110: 32040082
	s_ashr_i32 s3, s2, 31                                      // 000000825114: 86039F02
	s_delay_alu instid0(VALU_DEP_2)                            // 000000825118: BF870002
	v_dual_mov_b32 v16, 0 :: v_dual_lshlrev_b32 v1, 2, v1      // 00000082511C: CA220080 10000282
	s_lshl_b64 s[0:1], s[2:3], 3                               // 000000825124: 84808302
	s_delay_alu instid0(VALU_DEP_2) | instid1(SALU_CYCLE_1)    // 000000825128: BF870482
	v_dual_mov_b32 v9, s1 :: v_dual_and_b32 v2, 60, v2         // 00000082512C: CA240001 090204BC
	.long 0x7f183880                                           // 000000825134: 7F183880
	v_and_b32_e32 v15, 31, v0                                  // 000000825138: 361E009F
	v_dual_mov_b32 v27, 0 :: v_dual_mov_b32 v6, 0              // 00000082513C: CA100080 1B060080
	s_waitcnt lgkmcnt(0)                                       // 000000825144: BF89FC07
	s_clause 0x1                                               // 000000825148: BF850001
	global_load_b32 v3, v1, s[4:5]                             // 00000082514C: DC520000 03040001
	global_load_b32 v7, v2, s[4:5]                             // 000000825154: DC520000 07040002
	v_lshrrev_b32_e32 v1, 5, v0                                // 00000082515C: 32020085
	s_add_u32 s2, s4, s14                                      // 000000825160: 80020E04
	s_addc_u32 s3, s5, s15                                     // 000000825164: 82030F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000825168: BF8704A1
	v_or_b32_e32 v8, s0, v1                                    // 00000082516C: 38100200
	s_lshr_b32 s0, s11, 31                                     // 000000825170: 85009F0B
	s_add_u32 s14, s10, s0                                     // 000000825174: 800E000A
	s_addc_u32 s15, s11, 0                                     // 000000825178: 820F800B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000082517C: BF870001
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[8:9]                  // 000000825180: 7CA8100C
	v_mov_b32_e32 v5, 0                                        // 000000825184: 7E0A0280
	s_ashr_i32 s20, s11, 31                                    // 000000825188: 86149F0B
	v_cndmask_b32_e32 v10, 0, v8, vcc_lo                       // 00000082518C: 02141080
	v_cndmask_b32_e64 v14, 0, s1, vcc_lo                       // 000000825190: D501000E 01A80280
	s_ashr_i64 s[0:1], s[14:15], 1                             // 000000825198: 8680810E
	s_lshr_b32 s14, s20, 27                                    // 00000082519C: 850E9B14
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008251A0: BF870002
	.long 0xd72c000d                                           // 0000008251A4: D72C000D
	v_cndmask_b32_e32 v1, s19, v10, vcc_lo                     // 0000008251A8: 02021413
	v_mad_u64_u32 v[1:2], null, s18, v10, 0                    // 0000008251AC: D6FE7C01 02021412
	.long 0xd72c0011                                           // 0000008251B4: D72C0011
	v_cndmask_b32_e32 v0, v10, v1, vcc_lo                      // 0000008251B8: 0200030A
	.long 0xd72c0013                                           // 0000008251BC: D72C0013
	v_cndmask_b32_e32 v0, v14, v0, vcc_lo                      // 0000008251C0: 0200010E
	s_waitcnt vmcnt(1)                                         // 0000008251C4: BF8907F7
	v_bfe_u32 v11, v3, 16, 1                                   // 0000008251C8: D610000B 02052103
	s_waitcnt vmcnt(0)                                         // 0000008251D0: BF8903F7
	v_bfe_u32 v18, v7, 16, 1                                   // 0000008251D4: D6100012 02052107
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008251DC: BF870002
	v_add3_u32 v3, v3, v11, 0x7fff                             // 0000008251E0: D6550003 03FE1703 00007FFF
	v_mad_u64_u32 v[10:11], null, v10, s0, s[2:3]              // 0000008251EC: D6FE7C0A 0008010A
	s_add_u32 s2, s10, s14                                     // 0000008251F4: 80020E0A
	v_add3_u32 v7, v7, v18, 0x7fff                             // 0000008251F8: D6550007 03FE2507 00007FFF
	s_addc_u32 s3, s11, 0                                      // 000000825204: 8203800B
	.long 0x7e183983                                           // 000000825208: 7E183983
	.long 0xd72c0003                                           // 00000082520C: D72C0003
	v_cndmask_b32_e32 v1, s18, v14, vcc_lo                     // 000000825210: 02021C12
	s_lshr_b64 s[2:3], s[2:3], 5                               // 000000825214: 85828502
	v_lshlrev_b32_e32 v14, 2, v0                               // 000000825218: 301C0082
	.long 0xd4440000                                           // 00000082521C: D4440000
	v_cndmask_b32_e32 v1, s2, v15, vcc_lo                      // 000000825220: 02021E02
	v_and_or_b32 v12, 0xffff0000, v7, v12                      // 000000825224: D657000C 04320EFF FFFF0000
	v_mov_b32_e32 v7, 0                                        // 000000825230: 7E0E0280
	v_add3_u32 v17, v19, v11, v17                              // 000000825234: D6550011 04461713
	v_add3_u32 v0, v2, v3, v13                                 // 00000082523C: D6550000 04360702
	ds_store_b32 v14, v12                                      // 000000825244: D8340000 00000C0E
	s_waitcnt lgkmcnt(0)                                       // 00000082524C: BF89FC07
	s_barrier                                                  // 000000825250: BFBD0000
	buffer_gl0_inv                                             // 000000825254: E0AC0000 00000000
	s_and_saveexec_b32 s3, s0                                  // 00000082525C: BE832000
	s_cbranch_execz 26                                         // 000000825260: BFA5001A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0x1cc>
	s_add_u32 s1, s4, s16                                      // 000000825264: 80011004
	s_addc_u32 s14, s5, s17                                    // 000000825268: 820E1105
	v_lshlrev_b32_e32 v2, 1, v15                               // 00000082526C: 30041E81
	.long 0xd7000103                                           // 000000825270: D7000103
	v_cndmask_b32_e32 v1, s1, v1, vcc_lo                       // 000000825274: 02020201
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000825278: BF8701A1
	v_add_co_ci_u32_e64 v4, null, s14, v0, s1                  // 00000082527C: D5207C04 0006000E
	v_lshlrev_b32_e32 v5, 4, v15                               // 000000825284: 300A1E84
	.long 0xd7000102                                           // 000000825288: D7000102
	v_cndmask_b32_e32 v1, v3, v2, vcc_lo                       // 00000082528C: 02020503
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000825290: BF870191
	v_add_co_ci_u32_e64 v3, null, 0, v4, s1                    // 000000825294: D5207C03 00060880
	.long 0xd7000104                                           // 00000082529C: D7000104
	v_cndmask_b32_e32 v1, v10, v5, vcc_lo                      // 0000008252A0: 02020B0A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008252A4: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v17, s1                   // 0000008252A8: D5207C05 00062280
	s_clause 0x1                                               // 0000008252B0: BF850001
	global_load_d16_b16 v2, v[2:3], off                        // 0000008252B4: DC820000 027C0002
	global_load_b128 v[4:7], v[4:5], off                       // 0000008252BC: DC5E0000 047C0004
	s_waitcnt vmcnt(1)                                         // 0000008252C4: BF8907F7
	v_cvt_f32_f16_e32 v27, v2                                  // 0000008252C8: 7E361702
	s_or_b32 exec_lo, exec_lo, s3                              // 0000008252CC: 8C7E037E
	v_dual_mov_b32 v18, 0 :: v_dual_mov_b32 v19, 0             // 0000008252D0: CA100080 12120080
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v21, 0             // 0000008252D8: CA100080 14140080
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v23, 0             // 0000008252E0: CA100080 16160080
	s_and_saveexec_b32 s3, s0                                  // 0000008252E8: BE832000
	s_cbranch_execz 597                                        // 0000008252EC: BFA50255 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0xb44>
	s_mul_i32 s0, s11, 6                                       // 0000008252F0: 9600860B
	s_mul_hi_u32 s1, s10, 6                                    // 0000008252F4: 9681860A
	v_dual_mov_b32 v25, v15 :: v_dual_lshlrev_b32 v2, 1, v15   // 0000008252F8: CA22010F 19021E81
	s_add_i32 s18, s1, s0                                      // 000000825300: 81120001
	.long 0xd7000001                                           // 000000825304: D7000001
	v_cndmask_b32_e32 v1, s16, v1, vcc_lo                      // 000000825308: 02020210
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000082530C: BF8701A1
	v_add_co_ci_u32_e64 v0, null, s17, v0, s0                  // 000000825310: D5207C00 00020011
	v_dual_mov_b32 v12, 0 :: v_dual_lshlrev_b32 v11, 5, v15    // 000000825318: CA220080 0C0A1E85
	.long 0xd7000001                                           // 000000825320: D7000001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 000000825324: 02020501
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000825328: BF8701A1
	v_add_co_ci_u32_e64 v0, null, 0, v0, s0                    // 00000082532C: D5207C00 00020080
	v_lshl_or_b32 v24, v15, 4, 0x200                           // 000000825334: D6560018 03FD090F 00000200
	.long 0xd7000001                                           // 000000825340: D7000001
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 000000825344: 02020204
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000825348: BF8701A1
	v_add_co_ci_u32_e64 v0, null, s5, v0, s0                   // 00000082534C: D5207C00 00020005
	v_dual_mov_b32 v23, v12 :: v_dual_mov_b32 v26, v27         // 000000825354: CA10010C 171A011B
	.long 0xd700000d                                           // 00000082535C: D700000D
	v_cndmask_b32_e32 v0, v1, v192, vcc_lo                     // 000000825360: 02018101
	s_delay_alu instid0(VALU_DEP_1)                            // 000000825364: BF870001
	v_add_co_ci_u32_e64 v14, null, 0, v0, s0                   // 000000825368: D5207C0E 00020080
	v_mov_b32_e32 v22, v12                                     // 000000825370: 7E2C030C
	v_mov_b32_e32 v21, v12                                     // 000000825374: 7E2A030C
	v_mov_b32_e32 v20, v12                                     // 000000825378: 7E28030C
	v_mov_b32_e32 v19, v12                                     // 00000082537C: 7E26030C
	v_mov_b32_e32 v18, v12                                     // 000000825380: 7E24030C
	v_mov_b32_e32 v16, v12                                     // 000000825384: 7E20030C
	s_lshl_b64 s[14:15], s[10:11], 2                           // 000000825388: 848E820A
	s_mul_i32 s17, s10, 6                                      // 00000082538C: 9611860A
	s_mov_b32 s16, 0                                           // 000000825390: BE900080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 000000825394: 8484810A
	s_branch 528                                               // 000000825398: BFA00210 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0xadc>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000082539C: 8C7E0A7E
	v_and_b32_e32 v28, 0xff, v4                                // 0000008253A0: 363808FF 000000FF
	s_and_b32 s0, exec_lo, s0                                  // 0000008253A8: 8B00007E
	v_add_nc_u32_e32 v24, 0x200, v24                           // 0000008253AC: 4A3030FF 00000200
	s_or_b32 s16, s0, s16                                      // 0000008253B4: 8C101000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008253B8: BF8700B2
	v_lshlrev_b32_e32 v28, 2, v28                              // 0000008253BC: 30383882
	ds_load_b32 v44, v28                                       // 0000008253C0: D8D80000 2C00001C
	v_lshrrev_b32_e32 v28, 6, v4                               // 0000008253C8: 32380886
	v_and_b32_e32 v28, 0x3fc, v28                              // 0000008253CC: 363838FF 000003FC
	ds_load_b32 v45, v28                                       // 0000008253D4: D8D80000 2D00001C
	v_lshrrev_b32_e32 v28, 14, v4                              // 0000008253DC: 3238088E
	v_lshrrev_b32_e32 v4, 22, v4                               // 0000008253E0: 32080896
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008253E4: BF870112
	v_and_b32_e32 v28, 0x3fc, v28                              // 0000008253E8: 363838FF 000003FC
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000008253F0: 360808FF 000003FC
	ds_load_b32 v46, v28                                       // 0000008253F8: D8D80000 2E00001C
	ds_load_b32 v47, v4                                        // 000000825400: D8D80000 2F000004
	v_and_b32_e32 v4, 0xff, v5                                 // 000000825408: 36080AFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000825410: BF8700B1
	v_lshlrev_b32_e32 v4, 2, v4                                // 000000825414: 30080882
	ds_load_b32 v48, v4                                        // 000000825418: D8D80000 30000004
	v_lshrrev_b32_e32 v4, 6, v5                                // 000000825420: 32080A86
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000825424: 360808FF 000003FC
	ds_load_b32 v49, v4                                        // 00000082542C: D8D80000 31000004
	v_lshrrev_b32_e32 v4, 14, v5                               // 000000825434: 32080A8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000825438: BF8700B1
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000082543C: 360808FF 000003FC
	ds_load_b32 v50, v4                                        // 000000825444: D8D80000 32000004
	v_lshrrev_b32_e32 v4, 22, v5                               // 00000082544C: 32080A96
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000825450: 360808FF 000003FC
	ds_load_b32 v51, v4                                        // 000000825458: D8D80000 33000004
	v_and_b32_e32 v4, 0xff, v6                                 // 000000825460: 36080CFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000825468: BF8700B1
	v_lshlrev_b32_e32 v4, 2, v4                                // 00000082546C: 30080882
	ds_load_b32 v52, v4                                        // 000000825470: D8D80000 34000004
	v_lshrrev_b32_e32 v4, 6, v6                                // 000000825478: 32080C86
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000082547C: 360808FF 000003FC
	ds_load_b32 v53, v4                                        // 000000825484: D8D80000 35000004
	v_lshrrev_b32_e32 v4, 14, v6                               // 00000082548C: 32080C8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000825490: BF8700B1
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000825494: 360808FF 000003FC
	ds_load_b32 v54, v4                                        // 00000082549C: D8D80000 36000004
	v_lshrrev_b32_e32 v4, 22, v6                               // 0000008254A4: 32080C96
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000008254A8: 360808FF 000003FC
	ds_load_b32 v55, v4                                        // 0000008254B0: D8D80000 37000004
	v_and_b32_e32 v4, 0xff, v7                                 // 0000008254B8: 36080EFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008254C0: BF8700B1
	v_lshlrev_b32_e32 v4, 2, v4                                // 0000008254C4: 30080882
	ds_load_b32 v56, v4                                        // 0000008254C8: D8D80000 38000004
	v_lshrrev_b32_e32 v4, 6, v7                                // 0000008254D0: 32080E86
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000008254D4: 360808FF 000003FC
	ds_load_b32 v57, v4                                        // 0000008254DC: D8D80000 39000004
	v_lshrrev_b32_e32 v4, 14, v7                               // 0000008254E4: 32080E8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008254E8: BF8700B1
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000008254EC: 360808FF 000003FC
	ds_load_b32 v58, v4                                        // 0000008254F4: D8D80000 3A000004
	v_lshrrev_b32_e32 v4, 22, v7                               // 0000008254FC: 32080E96
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000825500: 360808FF 000003FC
	ds_load_b32 v59, v4                                        // 000000825508: D8D80000 3B000004
	.long 0xd73c0004                                           // 000000825510: D73C0004
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 000000825514: 02021681
	v_add_nc_u32_e32 v11, 0x400, v11                           // 000000825518: 4A1616FF 00000400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000825520: BF870092
	.long 0xd7000028                                           // 000000825524: D7000028
	v_cndmask_b32_e32 v1, s6, v4, vcc_lo                       // 000000825528: 02020806
	v_add_co_ci_u32_e64 v41, null, s7, v5, s0                  // 00000082552C: D5207C29 00020A07
	s_clause 0x3                                               // 000000825534: BF850003
	global_load_b128 v[4:7], v[40:41], off                     // 000000825538: DC5E0000 047C0028
	global_load_b128 v[28:31], v[40:41], off offset:16         // 000000825540: DC5E0010 1C7C0028
	global_load_b128 v[32:35], v[40:41], off offset:32         // 000000825548: DC5E0020 207C0028
	global_load_b128 v[36:39], v[40:41], off offset:48         // 000000825550: DC5E0030 247C0028
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 000000825558: BF890CF7
	v_dot2_f32_bf16 v4, v4, v44, 0                             // 00000082555C: CC1A4004 1A025904
	s_waitcnt lgkmcnt(14)                                      // 000000825564: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000825568: BF8700A1
	v_dot2_f32_bf16 v4, v5, v45, v4                            // 00000082556C: CC1A4004 1C125B05
	s_waitcnt lgkmcnt(13)                                      // 000000825574: BF89FCD7
	v_dot2_f32_bf16 v4, v6, v46, v4                            // 000000825578: CC1A4004 1C125D06
	s_waitcnt lgkmcnt(12)                                      // 000000825580: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000825584: BF8700A1
	v_dot2_f32_bf16 v4, v7, v47, v4                            // 000000825588: CC1A4004 1C125F07
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 000000825590: BF8908B7
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 000000825594: CC1A4004 1C12611C
	s_waitcnt lgkmcnt(10)                                      // 00000082559C: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008255A0: BF8700A1
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 0000008255A4: CC1A4004 1C12631D
	s_waitcnt lgkmcnt(9)                                       // 0000008255AC: BF89FC97
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 0000008255B0: CC1A4004 1C12651E
	s_waitcnt lgkmcnt(8)                                       // 0000008255B8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008255BC: BF8700A1
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 0000008255C0: CC1A4004 1C12671F
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 0000008255C8: BF890477
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 0000008255CC: CC1A4004 1C126920
	s_waitcnt lgkmcnt(6)                                       // 0000008255D4: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008255D8: BF8700A1
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 0000008255DC: CC1A4004 1C126B21
	s_waitcnt lgkmcnt(5)                                       // 0000008255E4: BF89FC57
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 0000008255E8: CC1A4004 1C126D22
	s_waitcnt lgkmcnt(4)                                       // 0000008255F0: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008255F4: BF8700A1
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 0000008255F8: CC1A4004 1C126F23
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 000000825600: BF890037
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 000000825604: CC1A4004 1C127124
	.long 0xd7000024                                           // 00000082560C: D7000024
	v_cndmask_b32_e32 v0, v40, v4, vcc_lo                      // 000000825610: 02000928
	s_waitcnt lgkmcnt(2)                                       // 000000825614: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000825618: BF8701C2
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 00000082561C: CC1A4004 1C127325
	v_add_co_ci_u32_e64 v37, null, s5, v41, s0                 // 000000825624: D5207C25 00025205
	.long 0xd700002a                                           // 00000082562C: D700002A
	v_cndmask_b32_e32 v0, v40, v14, vcc_lo                     // 000000825630: 02001D28
	s_waitcnt lgkmcnt(1)                                       // 000000825634: BF89FC17
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 000000825638: CC1A4004 1C127526
	v_add_co_ci_u32_e64 v43, null, s15, v41, s0                // 000000825640: D5207C2B 0002520F
	.long 0xd7000028                                           // 000000825648: D7000028
	v_cndmask_b32_e32 v0, v40, v17, vcc_lo                     // 00000082564C: 02002328
	s_waitcnt lgkmcnt(0)                                       // 000000825650: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000825654: BF870123
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 000000825658: CC1A4004 1C127727
	v_add_co_ci_u32_e64 v41, null, s18, v41, s0                // 000000825660: D5207C29 00025212
	v_fmac_f32_e32 v23, v27, v4                                // 000000825668: 562E091B
	s_clause 0x3                                               // 00000082566C: BF850003
	global_load_b128 v[4:7], v[36:37], off                     // 000000825670: DC5E0000 047C0024
	global_load_b128 v[28:31], v[36:37], off offset:16         // 000000825678: DC5E0010 1C7C0024
	global_load_b128 v[32:35], v[36:37], off offset:32         // 000000825680: DC5E0020 207C0024
	global_load_b128 v[36:39], v[36:37], off offset:48         // 000000825688: DC5E0030 247C0024
	s_waitcnt vmcnt(3)                                         // 000000825690: BF890FF7
	v_dot2_f32_bf16 v4, v4, v44, 0                             // 000000825694: CC1A4004 1A025904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000082569C: BF870091
	v_dot2_f32_bf16 v4, v5, v45, v4                            // 0000008256A0: CC1A4004 1C125B05
	v_dot2_f32_bf16 v4, v6, v46, v4                            // 0000008256A8: CC1A4004 1C125D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008256B0: BF8700A1
	v_dot2_f32_bf16 v4, v7, v47, v4                            // 0000008256B4: CC1A4004 1C125F07
	s_waitcnt vmcnt(2)                                         // 0000008256BC: BF890BF7
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 0000008256C0: CC1A4004 1C12611C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008256C8: BF870091
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 0000008256CC: CC1A4004 1C12631D
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 0000008256D4: CC1A4004 1C12651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008256DC: BF8700A1
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 0000008256E0: CC1A4004 1C12671F
	s_waitcnt vmcnt(1)                                         // 0000008256E8: BF8907F7
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 0000008256EC: CC1A4004 1C126920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008256F4: BF870091
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 0000008256F8: CC1A4004 1C126B21
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 000000825700: CC1A4004 1C126D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000825708: BF8700A1
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 00000082570C: CC1A4004 1C126F23
	s_waitcnt vmcnt(0)                                         // 000000825714: BF8903F7
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 000000825718: CC1A4004 1C127124
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000825720: BF870091
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 000000825724: CC1A4004 1C127325
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 00000082572C: CC1A4004 1C127526
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000825734: BF870091
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 000000825738: CC1A4004 1C127727
	v_fmac_f32_e32 v22, v27, v4                                // 000000825740: 562C091B
	s_clause 0x3                                               // 000000825744: BF850003
	global_load_b128 v[4:7], v[42:43], off                     // 000000825748: DC5E0000 047C002A
	global_load_b128 v[28:31], v[42:43], off offset:16         // 000000825750: DC5E0010 1C7C002A
	global_load_b128 v[32:35], v[42:43], off offset:32         // 000000825758: DC5E0020 207C002A
	global_load_b128 v[36:39], v[42:43], off offset:48         // 000000825760: DC5E0030 247C002A
	.long 0xd700002a                                           // 000000825768: D700002A
	v_cndmask_b32_e32 v0, v42, v14, vcc_lo                     // 00000082576C: 02001D2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000825770: BF8700B1
	v_add_co_ci_u32_e64 v43, null, s15, v43, s0                // 000000825774: D5207C2B 0002560F
	s_waitcnt vmcnt(3)                                         // 00000082577C: BF890FF7
	v_dot2_f32_bf16 v4, v4, v44, 0                             // 000000825780: CC1A4004 1A025904
	v_dot2_f32_bf16 v4, v5, v45, v4                            // 000000825788: CC1A4004 1C125B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000825790: BF870091
	v_dot2_f32_bf16 v4, v6, v46, v4                            // 000000825794: CC1A4004 1C125D06
	v_dot2_f32_bf16 v4, v7, v47, v4                            // 00000082579C: CC1A4004 1C125F07
	s_waitcnt vmcnt(2)                                         // 0000008257A4: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008257A8: BF870091
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 0000008257AC: CC1A4004 1C12611C
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 0000008257B4: CC1A4004 1C12631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008257BC: BF870091
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 0000008257C0: CC1A4004 1C12651E
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 0000008257C8: CC1A4004 1C12671F
	s_waitcnt vmcnt(1)                                         // 0000008257D0: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008257D4: BF870091
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 0000008257D8: CC1A4004 1C126920
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 0000008257E0: CC1A4004 1C126B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008257E8: BF870091
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 0000008257EC: CC1A4004 1C126D22
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 0000008257F4: CC1A4004 1C126F23
	s_waitcnt vmcnt(0)                                         // 0000008257FC: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000825800: BF870091
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 000000825804: CC1A4004 1C127124
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 00000082580C: CC1A4004 1C127325
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000825814: BF870091
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 000000825818: CC1A4004 1C127526
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 000000825820: CC1A4004 1C127727
	s_delay_alu instid0(VALU_DEP_1)                            // 000000825828: BF870001
	v_fmac_f32_e32 v21, v27, v4                                // 00000082582C: 562A091B
	s_clause 0x3                                               // 000000825830: BF850003
	global_load_b128 v[4:7], v[40:41], off                     // 000000825834: DC5E0000 047C0028
	global_load_b128 v[28:31], v[40:41], off offset:16         // 00000082583C: DC5E0010 1C7C0028
	global_load_b128 v[32:35], v[40:41], off offset:32         // 000000825844: DC5E0020 207C0028
	global_load_b128 v[36:39], v[40:41], off offset:48         // 00000082584C: DC5E0030 247C0028
	s_waitcnt vmcnt(3)                                         // 000000825854: BF890FF7
	v_dot2_f32_bf16 v4, v4, v44, 0                             // 000000825858: CC1A4004 1A025904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000825860: BF870091
	v_dot2_f32_bf16 v4, v5, v45, v4                            // 000000825864: CC1A4004 1C125B05
	v_dot2_f32_bf16 v4, v6, v46, v4                            // 00000082586C: CC1A4004 1C125D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000825874: BF8700A1
	v_dot2_f32_bf16 v4, v7, v47, v4                            // 000000825878: CC1A4004 1C125F07
	s_waitcnt vmcnt(2)                                         // 000000825880: BF890BF7
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 000000825884: CC1A4004 1C12611C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000082588C: BF870091
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 000000825890: CC1A4004 1C12631D
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 000000825898: CC1A4004 1C12651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008258A0: BF8700A1
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 0000008258A4: CC1A4004 1C12671F
	s_waitcnt vmcnt(1)                                         // 0000008258AC: BF8907F7
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 0000008258B0: CC1A4004 1C126920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008258B8: BF870091
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 0000008258BC: CC1A4004 1C126B21
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 0000008258C4: CC1A4004 1C126D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008258CC: BF8700A1
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 0000008258D0: CC1A4004 1C126F23
	s_waitcnt vmcnt(0)                                         // 0000008258D8: BF8903F7
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 0000008258DC: CC1A4004 1C127124
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008258E4: BF870091
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 0000008258E8: CC1A4004 1C127325
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 0000008258F0: CC1A4004 1C127526
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008258F8: BF870091
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 0000008258FC: CC1A4004 1C127727
	v_fmac_f32_e32 v20, v27, v4                                // 000000825904: 5628091B
	s_clause 0x3                                               // 000000825908: BF850003
	global_load_b128 v[4:7], v[42:43], off                     // 00000082590C: DC5E0000 047C002A
	global_load_b128 v[28:31], v[42:43], off offset:16         // 000000825914: DC5E0010 1C7C002A
	global_load_b128 v[32:35], v[42:43], off offset:32         // 00000082591C: DC5E0020 207C002A
	global_load_b128 v[36:39], v[42:43], off offset:48         // 000000825924: DC5E0030 247C002A
	s_waitcnt vmcnt(3)                                         // 00000082592C: BF890FF7
	v_dot2_f32_bf16 v4, v4, v44, 0                             // 000000825930: CC1A4004 1A025904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000825938: BF870091
	v_dot2_f32_bf16 v4, v5, v45, v4                            // 00000082593C: CC1A4004 1C125B05
	v_dot2_f32_bf16 v4, v6, v46, v4                            // 000000825944: CC1A4004 1C125D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000082594C: BF8700A1
	v_dot2_f32_bf16 v4, v7, v47, v4                            // 000000825950: CC1A4004 1C125F07
	s_waitcnt vmcnt(2)                                         // 000000825958: BF890BF7
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 00000082595C: CC1A4004 1C12611C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000825964: BF870091
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 000000825968: CC1A4004 1C12631D
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 000000825970: CC1A4004 1C12651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000825978: BF8700A1
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 00000082597C: CC1A4004 1C12671F
	s_waitcnt vmcnt(1)                                         // 000000825984: BF8907F7
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 000000825988: CC1A4004 1C126920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000825990: BF870091
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 000000825994: CC1A4004 1C126B21
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 00000082599C: CC1A4004 1C126D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008259A4: BF8700A1
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 0000008259A8: CC1A4004 1C126F23
	s_waitcnt vmcnt(0)                                         // 0000008259B0: BF8903F7
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 0000008259B4: CC1A4004 1C127124
	.long 0xd7000024                                           // 0000008259BC: D7000024
	v_cndmask_b32_e32 v0, v40, v14, vcc_lo                     // 0000008259C0: 02001D28
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008259C4: BF870122
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 0000008259C8: CC1A4004 1C127325
	v_add_co_ci_u32_e64 v37, null, s15, v41, s0                // 0000008259D0: D5207C25 0002520F
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 0000008259D8: CC1A4004 1C127526
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008259E0: BF870091
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 0000008259E4: CC1A4004 1C127727
	v_fmac_f32_e32 v19, v27, v4                                // 0000008259EC: 5626091B
	s_clause 0x3                                               // 0000008259F0: BF850003
	global_load_b128 v[4:7], v[36:37], off                     // 0000008259F4: DC5E0000 047C0024
	global_load_b128 v[28:31], v[36:37], off offset:16         // 0000008259FC: DC5E0010 1C7C0024
	global_load_b128 v[32:35], v[36:37], off offset:32         // 000000825A04: DC5E0020 207C0024
	global_load_b128 v[36:39], v[36:37], off offset:48         // 000000825A0C: DC5E0030 247C0024
	s_waitcnt vmcnt(3)                                         // 000000825A14: BF890FF7
	v_dot2_f32_bf16 v4, v4, v44, 0                             // 000000825A18: CC1A4004 1A025904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000825A20: BF870091
	v_dot2_f32_bf16 v4, v5, v45, v4                            // 000000825A24: CC1A4004 1C125B05
	v_dot2_f32_bf16 v4, v6, v46, v4                            // 000000825A2C: CC1A4004 1C125D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000825A34: BF8700A1
	v_dot2_f32_bf16 v4, v7, v47, v4                            // 000000825A38: CC1A4004 1C125F07
	s_waitcnt vmcnt(2)                                         // 000000825A40: BF890BF7
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 000000825A44: CC1A4004 1C12611C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000825A4C: BF870091
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 000000825A50: CC1A4004 1C12631D
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 000000825A58: CC1A4004 1C12651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000825A60: BF8700A1
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 000000825A64: CC1A4004 1C12671F
	s_waitcnt vmcnt(1)                                         // 000000825A6C: BF8907F7
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 000000825A70: CC1A4004 1C126920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000825A78: BF870091
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 000000825A7C: CC1A4004 1C126B21
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 000000825A84: CC1A4004 1C126D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000825A8C: BF8700A1
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 000000825A90: CC1A4004 1C126F23
	s_waitcnt vmcnt(0)                                         // 000000825A98: BF8903F7
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 000000825A9C: CC1A4004 1C127124
	.long 0xd7000024                                           // 000000825AA4: D7000024
	v_cndmask_b32_e32 v0, v42, v14, vcc_lo                     // 000000825AA8: 02001D2A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000825AAC: BF8701B2
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 000000825AB0: CC1A4004 1C127325
	v_add_co_ci_u32_e64 v37, null, s15, v43, s0                // 000000825AB8: D5207C25 0002560F
	.long 0xd700000d                                           // 000000825AC0: D700000D
	v_cndmask_b32_e32 v0, v13, v192, vcc_lo                    // 000000825AC4: 0201810D
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 000000825AC8: CC1A4004 1C127526
	v_add_co_ci_u32_e64 v14, null, 0, v14, s0                  // 000000825AD0: D5207C0E 00021C80
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000825AD8: BF870092
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 000000825ADC: CC1A4004 1C127727
	v_fmac_f32_e32 v18, v27, v4                                // 000000825AE4: 5624091B
	s_clause 0x3                                               // 000000825AE8: BF850003
	global_load_b128 v[4:7], v[36:37], off                     // 000000825AEC: DC5E0000 047C0024
	global_load_b128 v[28:31], v[36:37], off offset:16         // 000000825AF4: DC5E0010 1C7C0024
	global_load_b128 v[32:35], v[36:37], off offset:32         // 000000825AFC: DC5E0020 207C0024
	global_load_b128 v[36:39], v[36:37], off offset:48         // 000000825B04: DC5E0030 247C0024
	s_waitcnt vmcnt(3)                                         // 000000825B0C: BF890FF7
	v_dot2_f32_bf16 v4, v4, v44, 0                             // 000000825B10: CC1A4004 1A025904
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000825B18: BF870121
	v_dot2_f32_bf16 v4, v5, v45, v4                            // 000000825B1C: CC1A4004 1C125B05
	v_mov_b32_e32 v5, v1                                       // 000000825B24: 7E0A0301
	v_dot2_f32_bf16 v4, v6, v46, v4                            // 000000825B28: CC1A4004 1C125D06
	v_mov_b32_e32 v6, v2                                       // 000000825B30: 7E0C0302
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000825B34: BF870132
	v_dot2_f32_bf16 v4, v7, v47, v4                            // 000000825B38: CC1A4004 1C125F07
	v_mov_b32_e32 v7, v3                                       // 000000825B40: 7E0E0303
	s_waitcnt vmcnt(2)                                         // 000000825B44: BF890BF7
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 000000825B48: CC1A4004 1C12611C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000825B50: BF870091
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 000000825B54: CC1A4004 1C12631D
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 000000825B5C: CC1A4004 1C12651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000825B64: BF8700A1
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 000000825B68: CC1A4004 1C12671F
	s_waitcnt vmcnt(1)                                         // 000000825B70: BF8907F7
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 000000825B74: CC1A4004 1C126920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000825B7C: BF870091
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 000000825B80: CC1A4004 1C126B21
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 000000825B88: CC1A4004 1C126D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000825B90: BF8700A1
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 000000825B94: CC1A4004 1C126F23
	s_waitcnt vmcnt(0)                                         // 000000825B9C: BF8903F7
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 000000825BA0: CC1A4004 1C127124
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000825BA8: BF870091
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 000000825BAC: CC1A4004 1C127325
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 000000825BB4: CC1A4004 1C127526
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000825BBC: BF870091
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 000000825BC0: CC1A4004 1C127727
	v_fmac_f32_e32 v16, v27, v4                                // 000000825BC8: 5620091B
	v_dual_mov_b32 v4, v0 :: v_dual_mov_b32 v27, v26           // 000000825BCC: CA100100 041A011A
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 000000825BD4: 917E107E
	s_cbranch_execz 25                                         // 000000825BD8: BFA50019 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0xb40>
	s_waitcnt vmcnt(0)                                         // 000000825BDC: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000825BE0: BF8701B1
	v_dual_mov_b32 v0, v4 :: v_dual_add_nc_u32 v25, 32, v25    // 000000825BE4: CA200104 001832A0
	v_dual_mov_b32 v1, v5 :: v_dual_mov_b32 v2, v6             // 000000825BEC: CA100105 01020106
	v_mov_b32_e32 v3, v7                                       // 000000825BF4: 7E060307
	.long 0xd4430000                                           // 000000825BF8: D4430000
	v_cndmask_b32_e32 v1, s2, v25, vcc_lo                      // 000000825BFC: 02023202
	s_mov_b32 s10, exec_lo                                     // 000000825C00: BE8A007E
	.long 0xd4c4007e                                           // 000000825C04: D4C4007E
	v_cndmask_b32_e32 v1, s2, v25, vcc_lo                      // 000000825C08: 02023202
	s_cbranch_execz 64995                                      // 000000825C0C: BFA5FDE3 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0x29c>
	.long 0xd7000100                                           // 000000825C10: D7000100
	v_cndmask_b32_e32 v1, v10, v24, vcc_lo                     // 000000825C14: 0202310A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000825C18: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v17, s1                   // 000000825C1C: D5207C01 00062280
	global_load_d16_b16 v26, v[13:14], off                     // 000000825C24: DC820000 1A7C000D
	global_load_b128 v[0:3], v[0:1], off                       // 000000825C2C: DC5E0000 007C0000
	s_waitcnt vmcnt(1)                                         // 000000825C34: BF8907F7
	v_cvt_f32_f16_e32 v26, v26                                 // 000000825C38: 7E34171A
	s_branch 64983                                             // 000000825C3C: BFA0FDD7 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0x29c>
	s_or_b32 exec_lo, exec_lo, s16                             // 000000825C40: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000825C44: BF8700A9
	s_or_b32 exec_lo, exec_lo, s3                              // 000000825C48: 8C7E037E
	.long 0xd71f0000                                           // 000000825C4C: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000825C50: 020100C1
	v_xor_b32_e32 v1, 16, v0                                   // 000000825C54: 3A020090
	v_xor_b32_e32 v10, 8, v0                                   // 000000825C58: 3A140088
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000825C5C: BF870092
	.long 0xd44c0000                                           // 000000825C60: D44C0000
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 000000825C64: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s0                           // 000000825C68: D5010001 00020300
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000825C70: BF870113
	.long 0xd44c0000                                           // 000000825C74: D44C0000
	v_cndmask_b32_e32 v1, 32, v10, vcc_lo                      // 000000825C78: 020214A0
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000825C7C: 30020282
	s_delay_alu instid0(VALU_DEP_2)                            // 000000825C80: BF870002
	v_cndmask_b32_e64 v10, v0, v10, s0                         // 000000825C84: D501000A 00021500
	ds_bpermute_b32 v2, v1, v23                                // 000000825C8C: DACC0000 02001701
	s_waitcnt lgkmcnt(0)                                       // 000000825C94: BF89FC07
	v_add_f32_e32 v2, v23, v2                                  // 000000825C98: 06040517
	s_waitcnt vmcnt(0)                                         // 000000825C9C: BF8903F7
	ds_bpermute_b32 v4, v1, v21                                // 000000825CA0: DACC0000 04001501
	ds_bpermute_b32 v3, v1, v22                                // 000000825CA8: DACC0000 03001601
	ds_bpermute_b32 v5, v1, v20                                // 000000825CB0: DACC0000 05001401
	ds_bpermute_b32 v6, v1, v19                                // 000000825CB8: DACC0000 06001301
	ds_bpermute_b32 v7, v1, v18                                // 000000825CC0: DACC0000 07001201
	ds_bpermute_b32 v1, v1, v16                                // 000000825CC8: DACC0000 01001001
	v_lshlrev_b32_e32 v10, 2, v10                              // 000000825CD0: 30141482
	s_waitcnt lgkmcnt(4)                                       // 000000825CD4: BF89FC47
	v_dual_add_f32 v4, v21, v4 :: v_dual_add_f32 v3, v22, v3   // 000000825CD8: C9080915 04020716
	s_waitcnt lgkmcnt(2)                                       // 000000825CE0: BF89FC27
	v_dual_add_f32 v5, v20, v5 :: v_dual_add_f32 v6, v19, v6   // 000000825CE4: C9080B14 05060D13
	s_waitcnt lgkmcnt(1)                                       // 000000825CEC: BF89FC17
	v_add_f32_e32 v7, v18, v7                                  // 000000825CF0: 060E0F12
	ds_bpermute_b32 v13, v10, v4                               // 000000825CF4: DACC0000 0D00040A
	ds_bpermute_b32 v11, v10, v2                               // 000000825CFC: DACC0000 0B00020A
	ds_bpermute_b32 v12, v10, v3                               // 000000825D04: DACC0000 0C00030A
	ds_bpermute_b32 v14, v10, v5                               // 000000825D0C: DACC0000 0E00050A
	v_xor_b32_e32 v18, 4, v0                                   // 000000825D14: 3A240084
	ds_bpermute_b32 v17, v10, v7                               // 000000825D18: DACC0000 1100070A
	.long 0xd44c0000                                           // 000000825D20: D44C0000
	v_cndmask_b32_e32 v1, 32, v18, vcc_lo                      // 000000825D24: 020224A0
	s_delay_alu instid0(VALU_DEP_1)                            // 000000825D28: BF870001
	v_cndmask_b32_e64 v18, v0, v18, s0                         // 000000825D2C: D5010012 00022500
	s_waitcnt lgkmcnt(5)                                       // 000000825D34: BF89FC57
	v_add_f32_e32 v1, v16, v1                                  // 000000825D38: 06020310
	ds_bpermute_b32 v16, v10, v6                               // 000000825D3C: DACC0000 1000060A
	v_lshlrev_b32_e32 v18, 2, v18                              // 000000825D44: 30242482
	ds_bpermute_b32 v10, v10, v1                               // 000000825D48: DACC0000 0A00010A
	s_waitcnt lgkmcnt(6)                                       // 000000825D50: BF89FC67
	v_add_f32_e32 v4, v4, v13                                  // 000000825D54: 06081B04
	s_waitcnt lgkmcnt(4)                                       // 000000825D58: BF89FC47
	v_dual_add_f32 v2, v2, v11 :: v_dual_add_f32 v3, v3, v12   // 000000825D5C: C9081702 02021903
	s_waitcnt lgkmcnt(3)                                       // 000000825D64: BF89FC37
	v_add_f32_e32 v5, v5, v14                                  // 000000825D68: 060A1D05
	s_waitcnt lgkmcnt(2)                                       // 000000825D6C: BF89FC27
	v_add_f32_e32 v7, v7, v17                                  // 000000825D70: 060E2307
	ds_bpermute_b32 v12, v18, v4                               // 000000825D74: DACC0000 0C000412
	ds_bpermute_b32 v11, v18, v3                               // 000000825D7C: DACC0000 0B000312
	ds_bpermute_b32 v13, v18, v5                               // 000000825D84: DACC0000 0D000512
	s_waitcnt lgkmcnt(4)                                       // 000000825D8C: BF89FC47
	v_add_f32_e32 v6, v6, v16                                  // 000000825D90: 060C2106
	ds_bpermute_b32 v16, v18, v7                               // 000000825D94: DACC0000 10000712
	s_waitcnt lgkmcnt(4)                                       // 000000825D9C: BF89FC47
	v_add_f32_e32 v1, v1, v10                                  // 000000825DA0: 06021501
	ds_bpermute_b32 v14, v18, v6                               // 000000825DA4: DACC0000 0E000612
	ds_bpermute_b32 v10, v18, v2                               // 000000825DAC: DACC0000 0A000212
	s_waitcnt lgkmcnt(5)                                       // 000000825DB4: BF89FC57
	v_add_f32_e32 v4, v4, v12                                  // 000000825DB8: 06081904
	ds_bpermute_b32 v17, v18, v1                               // 000000825DBC: DACC0000 11000112
	v_xor_b32_e32 v18, 2, v0                                   // 000000825DC4: 3A240082
	s_waitcnt lgkmcnt(4)                                       // 000000825DC8: BF89FC47
	v_add_f32_e32 v5, v5, v13                                  // 000000825DCC: 060A1B05
	v_add_f32_e32 v3, v3, v11                                  // 000000825DD0: 06061703
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000825DD4: BF870133
	.long 0xd44c0000                                           // 000000825DD8: D44C0000
	v_cndmask_b32_e32 v1, 32, v18, vcc_lo                      // 000000825DDC: 020224A0
	s_waitcnt lgkmcnt(3)                                       // 000000825DE0: BF89FC37
	v_add_f32_e32 v12, v7, v16                                 // 000000825DE4: 06182107
	v_cndmask_b32_e64 v18, v0, v18, s0                         // 000000825DE8: D5010012 00022500
	v_xor_b32_e32 v7, 1, v0                                    // 000000825DF0: 3A0E0081
	s_waitcnt lgkmcnt(2)                                       // 000000825DF4: BF89FC27
	v_add_f32_e32 v11, v6, v14                                 // 000000825DF8: 06161D06
	s_waitcnt lgkmcnt(1)                                       // 000000825DFC: BF89FC17
	v_add_f32_e32 v2, v2, v10                                  // 000000825E00: 06041502
	v_lshlrev_b32_e32 v18, 2, v18                              // 000000825E04: 30242482
	.long 0xd44c0000                                           // 000000825E08: D44C0000
	v_cndmask_b32_e32 v1, 32, v7, vcc_lo                       // 000000825E0C: 02020EA0
	ds_bpermute_b32 v6, v18, v3                                // 000000825E10: DACC0000 06000312
	v_cndmask_b32_e64 v0, v0, v7, s0                           // 000000825E18: D5010000 00020F00
	s_waitcnt lgkmcnt(1)                                       // 000000825E20: BF89FC17
	v_add_f32_e32 v13, v1, v17                                 // 000000825E24: 061A2301
	ds_bpermute_b32 v1, v18, v2                                // 000000825E28: DACC0000 01000212
	ds_bpermute_b32 v14, v18, v4                               // 000000825E30: DACC0000 0E000412
	ds_bpermute_b32 v16, v18, v5                               // 000000825E38: DACC0000 10000512
	ds_bpermute_b32 v17, v18, v11                              // 000000825E40: DACC0000 11000B12
	ds_bpermute_b32 v19, v18, v12                              // 000000825E48: DACC0000 13000C12
	v_lshlrev_b32_e32 v20, 2, v0                               // 000000825E50: 30280082
	ds_bpermute_b32 v18, v18, v13                              // 000000825E54: DACC0000 12000D12
	.long 0xd44a0000                                           // 000000825E5C: D44A0000
	v_cndmask_b32_e32 v1, 0, v15, vcc_lo                       // 000000825E60: 02021E80
	s_and_b32 s0, s0, vcc_lo                                   // 000000825E64: 8B006A00
	s_waitcnt lgkmcnt(5)                                       // 000000825E68: BF89FC57
	v_dual_add_f32 v10, v3, v6 :: v_dual_add_f32 v7, v2, v1    // 000000825E6C: C9080D03 0A060302
	s_waitcnt lgkmcnt(4)                                       // 000000825E74: BF89FC47
	v_add_f32_e32 v6, v4, v14                                  // 000000825E78: 060C1D04
	s_waitcnt lgkmcnt(2)                                       // 000000825E7C: BF89FC27
	v_dual_add_f32 v0, v5, v16 :: v_dual_add_f32 v1, v11, v17  // 000000825E80: C9082105 0000230B
	s_waitcnt lgkmcnt(1)                                       // 000000825E88: BF89FC17
	v_add_f32_e32 v2, v12, v19                                 // 000000825E8C: 0604270C
	ds_bpermute_b32 v14, v20, v10                              // 000000825E90: DACC0000 0E000A14
	s_waitcnt lgkmcnt(1)                                       // 000000825E98: BF89FC17
	v_add_f32_e32 v11, v13, v18                                // 000000825E9C: 0616250D
	ds_bpermute_b32 v13, v20, v7                               // 000000825EA0: DACC0000 0D000714
	ds_bpermute_b32 v12, v20, v6                               // 000000825EA8: DACC0000 0C000614
	ds_bpermute_b32 v3, v20, v0                                // 000000825EB0: DACC0000 03000014
	ds_bpermute_b32 v4, v20, v1                                // 000000825EB8: DACC0000 04000114
	ds_bpermute_b32 v5, v20, v2                                // 000000825EC0: DACC0000 05000214
	ds_bpermute_b32 v16, v20, v11                              // 000000825EC8: DACC0000 10000B14
	s_and_saveexec_b32 s1, s0                                  // 000000825ED0: BE812000
	s_cbranch_execz 346                                        // 000000825ED4: BFA5015A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0x1340>
	s_waitcnt lgkmcnt(5)                                       // 000000825ED8: BF89FC57
	v_dual_add_f32 v7, v7, v13 :: v_dual_add_f32 v10, v10, v14 // 000000825EDC: C9081B07 070A1D0A
	s_waitcnt lgkmcnt(3)                                       // 000000825EE4: BF89FC37
	v_dual_add_f32 v6, v6, v12 :: v_dual_add_f32 v3, v0, v3    // 000000825EE8: C9081906 06020700
	s_waitcnt lgkmcnt(0)                                       // 000000825EF0: BF89FC07
	v_dual_add_f32 v11, v11, v16 :: v_dual_add_f32 v2, v2, v5  // 000000825EF4: C908210B 0B020B02
	v_bfe_u32 v12, v7, 16, 1                                   // 000000825EFC: D610000C 02052107
	v_bfe_u32 v13, v10, 16, 1                                  // 000000825F04: D610000D 0205210A
	s_lshl_b64 s[0:1], s[12:13], 1                             // 000000825F0C: 8480810C
	s_delay_alu instid0(VALU_DEP_3)                            // 000000825F10: BF870003
	v_bfe_u32 v15, v11, 16, 1                                  // 000000825F14: D610000F 0205210B
	v_bfe_u32 v14, v2, 16, 1                                   // 000000825F1C: D610000E 02052102
	v_add3_u32 v5, v7, v12, 0x7fff                             // 000000825F24: D6550005 03FE1907 00007FFF
	v_add_f32_e32 v4, v1, v4                                   // 000000825F30: 06080901
	.long 0xd73c0000                                           // 000000825F34: D73C0000
	v_cndmask_b32_e32 v1, 1, v8, vcc_lo                        // 000000825F38: 02021081
	v_bfe_u32 v9, v6, 16, 1                                    // 000000825F3C: D6100009 02052106
	v_bfe_u32 v12, v3, 16, 1                                   // 000000825F44: D610000C 02052103
	v_add3_u32 v7, v10, v13, 0x7fff                            // 000000825F4C: D6550007 03FE1B0A 00007FFF
	v_and_b32_e32 v5, 0xffff0000, v5                           // 000000825F58: 360A0AFF FFFF0000
	v_bfe_u32 v13, v4, 16, 1                                   // 000000825F60: D610000D 02052104
	v_add3_u32 v6, v6, v9, 0x7fff                              // 000000825F68: D6550006 03FE1306 00007FFF
	v_add3_u32 v3, v3, v12, 0x7fff                             // 000000825F74: D6550003 03FE1903 00007FFF
	v_add3_u32 v9, v2, v14, 0x7fff                             // 000000825F80: D6550009 03FE1D02 00007FFF
	v_add3_u32 v11, v11, v15, 0x7fff                           // 000000825F8C: D655000B 03FE1F0B 00007FFF
	v_add3_u32 v4, v4, v13, 0x7fff                             // 000000825F98: D6550004 03FE1B04 00007FFF
	v_and_b32_e32 v6, 0xffff0000, v6                           // 000000825FA4: 360C0CFF FFFF0000
	v_and_b32_e32 v2, 0xffff0000, v3                           // 000000825FAC: 360406FF FFFF0000
	.long 0xd7006a00                                           // 000000825FB4: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 000000825FB8: 02020008
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000825FBC: BF870214
	v_and_b32_e32 v4, 0xffff0000, v4                           // 000000825FC0: 360808FF FFFF0000
	v_mul_f32_e32 v3, 0xbfb8aa3b, v6                           // 000000825FC8: 10060CFF BFB8AA3B
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 000000825FD0: D5207C01 01AA0209
	.long 0x7f143880                                           // 000000825FD8: 7F143880
	s_lshl_b64 s[4:5], s[12:13], 2                             // 000000825FDC: 8484820C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000825FE0: BF870143
	v_exp_f32_e32 v14, v3                                      // 000000825FE4: 7E1C4B03
	v_and_b32_e32 v7, 0xffff0000, v7                           // 000000825FE8: 360E0EFF FFFF0000
	v_mul_f32_e32 v4, 0xbfb8aa3b, v4                           // 000000825FF0: 100808FF BFB8AA3B
	.long 0x7f10398a                                           // 000000825FF8: 7F10398A
	v_exp_f32_e32 v4, v4                                       // 000000825FFC: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_3)   // 000000826000: BF870186
	v_dual_add_f32 v14, 1.0, v14 :: v_dual_mul_f32 v7, 0xbfb8aa3b, v7// 000000826004: C9061CF2 0E060EFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000826010: BF870111
	v_div_scale_f32 v21, null, v14, v14, 1.0                   // 000000826014: D6FC7C15 03CA1D0E
	v_exp_f32_e32 v7, v7                                       // 00000082601C: 7E0E4B07
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000826020: BF870095
	v_add_f32_e32 v7, 1.0, v7                                  // 000000826024: 060E0EF2
	v_div_scale_f32 v12, null, v7, v7, 1.0                     // 000000826028: D6FC7C0C 03CA0F07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000826030: BF870291
	v_rcp_f32_e32 v16, v12                                     // 000000826034: 7E20550C
	v_fma_f32 v18, -v12, v16, 1.0                              // 000000826038: D6130012 23CA210C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000826040: BF870091
	v_dual_mul_f32 v5, 0xbfb8aa3b, v5 :: v_dual_fmac_f32 v16, v18, v16// 000000826044: C8C00AFF 05102112 BFB8AA3B
	v_exp_f32_e32 v5, v5                                       // 000000826050: 7E0A4B05
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000826054: BF870095
	v_add_f32_e32 v5, 1.0, v5                                  // 000000826058: 060A0AF2
	v_div_scale_f32 v6, null, v5, v5, 1.0                      // 00000082605C: D6FC7C06 03CA0B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000826064: BF870291
	v_rcp_f32_e32 v15, v6                                      // 000000826068: 7E1E5506
	v_fma_f32 v17, -v6, v15, 1.0                               // 00000082606C: D6130011 23CA1F06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000826074: BF8700B1
	v_fmac_f32_e32 v15, v17, v15                               // 000000826078: 561E1F11
	v_mul_f32_e32 v13, 0xbfb8aa3b, v2                          // 00000082607C: 101A04FF BFB8AA3B
	.long 0xd7006a02                                           // 000000826084: D7006A02
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 000000826088: 02000100
	v_add_co_ci_u32_e64 v3, null, s1, v1, vcc_lo               // 00000082608C: D5207C03 01AA0201
	v_div_scale_f32 v19, vcc_lo, 1.0, v5, 1.0                  // 000000826094: D6FC6A13 03CA0AF2
	v_div_scale_f32 v20, s0, 1.0, v7, 1.0                      // 00000082609C: D6FC0014 03CA0EF2
	v_rcp_f32_e32 v17, v21                                     // 0000008260A4: 7E225515
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008260A8: BF870112
	v_mul_f32_e32 v18, v19, v15                                // 0000008260AC: 10241F13
	v_mul_f32_e32 v22, v20, v16                                // 0000008260B0: 102C2114
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008260B4: BF870112
	v_fma_f32 v23, -v6, v18, v19                               // 0000008260B8: D6130017 244E2506
	v_fma_f32 v24, -v12, v22, v20                              // 0000008260C0: D6130018 24522D0C
	v_and_b32_e32 v9, 0xffff0000, v9                           // 0000008260C8: 361212FF FFFF0000
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000008260D0: BF870215
	v_fma_f32 v26, -v21, v17, 1.0                              // 0000008260D4: D613001A 23CA2315
	v_fmac_f32_e32 v18, v23, v15                               // 0000008260DC: 56241F17
	v_exp_f32_e32 v13, v13                                     // 0000008260E0: 7E1A4B0D
	v_fmac_f32_e32 v22, v24, v16                               // 0000008260E4: 562C2118
	v_div_scale_f32 v23, s1, 1.0, v14, 1.0                     // 0000008260E8: D6FC0117 03CA1CF2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008260F0: BF870193
	v_fma_f32 v6, -v6, v18, v19                                // 0000008260F4: D6130006 244E2506
	v_fma_f32 v12, -v12, v22, v20                              // 0000008260FC: D613000C 24522D0C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000826104: BF870292
	v_div_fmas_f32 v6, v6, v15, v18                            // 000000826108: D6370006 044A1F06
	v_add_f32_e32 v13, 1.0, v13                                // 000000826110: 061A1AF2
	s_mov_b32 vcc_lo, s0                                       // 000000826114: BEEA0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000826118: BF870112
	v_div_fixup_f32 v5, v6, v5, 1.0                            // 00000082611C: D6270005 03CA0B06
	v_div_scale_f32 v25, null, v13, v13, 1.0                   // 000000826124: D6FC7C19 03CA1B0D
	v_div_scale_f32 v19, s2, 1.0, v13, 1.0                     // 00000082612C: D6FC0213 03CA1AF2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000826134: BF870193
	.long 0x7e103985                                           // 000000826138: 7E103985
	v_rcp_f32_e32 v24, v25                                     // 00000082613C: 7E305519
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000826140: BF8701B1
	v_dual_fmac_f32 v17, v26, v17 :: v_dual_and_b32 v8, 1, v8  // 000000826144: C824231A 11081081
	v_and_b32_e32 v11, 0xffff0000, v11                         // 00000082614C: 361616FF FFFF0000
	v_add_f32_e32 v15, 1.0, v4                                 // 000000826154: 061E08F2
	v_add3_u32 v5, v5, v8, 0x7fff                              // 000000826158: D6550005 03FE1105 00007FFF
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000826164: BF8700D5
	v_fma_f32 v6, -v25, v24, 1.0                               // 000000826168: D6130006 23CA3119
	v_mul_f32_e32 v9, 0xbfb8aa3b, v9                           // 000000826170: 101212FF BFB8AA3B
	global_store_d16_hi_b16 v[0:1], v5, off                    // 000000826178: DC960000 007C0500
	v_fmac_f32_e32 v24, v6, v24                                // 000000826180: 56303106
	v_exp_f32_e32 v9, v9                                       // 000000826184: 7E124B09
	v_mul_f32_e32 v18, v19, v24                                // 000000826188: 10243113
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000082618C: BF870291
	v_fma_f32 v8, -v25, v18, v19                               // 000000826190: D6130008 244E2519
	v_add_f32_e32 v9, 1.0, v9                                  // 000000826198: 061212F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000082619C: BF870112
	v_dual_mul_f32 v11, 0xbfb8aa3b, v11 :: v_dual_fmac_f32 v18, v8, v24// 0000008261A0: C8C016FF 0B123108 BFB8AA3B
	v_div_scale_f32 v6, null, v9, v9, 1.0                      // 0000008261AC: D6FC7C06 03CA1309
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000008261B4: BF870152
	v_exp_f32_e32 v4, v11                                      // 0000008261B8: 7E084B0B
	v_div_fmas_f32 v11, v12, v16, v22                          // 0000008261BC: D637000B 045A210C
	v_mul_f32_e32 v16, v23, v17                                // 0000008261C4: 10202317
	s_mov_b32 vcc_lo, s1                                       // 0000008261C8: BEEA0001
	v_rcp_f32_e32 v22, v6                                      // 0000008261CC: 7E2C5506
	v_div_fixup_f32 v7, v11, v7, 1.0                           // 0000008261D0: D6270007 03CA0F0B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000008261D8: BF870312
	v_fma_f32 v11, -v21, v16, v23                              // 0000008261DC: D613000B 245E2115
	v_add_f32_e32 v8, 1.0, v4                                  // 0000008261E4: 061008F2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008261E8: BF870193
	.long 0x7e143987                                           // 0000008261EC: 7E143987
	v_fmac_f32_e32 v16, v11, v17                               // 0000008261F0: 5620230B
	v_div_scale_f32 v12, null, v15, v15, 1.0                   // 0000008261F4: D6FC7C0C 03CA1F0F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008261FC: BF870193
	v_and_b32_e32 v11, 1, v10                                  // 000000826200: 36161481
	v_fma_f32 v21, -v21, v16, v23                              // 000000826204: D6130015 245E2115
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000082620C: BF870113
	v_rcp_f32_e32 v20, v12                                     // 000000826210: 7E28550C
	v_add3_u32 v7, v7, v11, 0x7fff                             // 000000826214: D6550007 03FE1707 00007FFF
	s_delay_alu instid0(VALU_DEP_2)                            // 000000826220: BF870002
	v_div_fmas_f32 v4, v21, v17, v16                           // 000000826224: D6370004 04422315
	v_div_scale_f32 v17, null, v8, v8, 1.0                     // 00000082622C: D6FC7C11 03CA1108
	v_fma_f32 v16, -v25, v18, v19                              // 000000826234: D6130010 244E2519
	s_mov_b32 vcc_lo, s2                                       // 00000082623C: BEEA0002
	v_fma_f32 v11, -v6, v22, 1.0                               // 000000826240: D613000B 23CA2D06
	global_store_d16_hi_b16 v[2:3], v7, off                    // 000000826248: DC960000 007C0702
	v_rcp_f32_e32 v19, v17                                     // 000000826250: 7E265511
	v_div_fmas_f32 v16, v16, v24, v18                          // 000000826254: D6370010 044A3110
	v_fma_f32 v5, -v12, v20, 1.0                               // 00000082625C: D6130005 23CA290C
	v_div_fixup_f32 v14, v4, v14, 1.0                          // 000000826264: D627000E 03CA1D04
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000082626C: BF870293
	v_div_fixup_f32 v2, v16, v13, 1.0                          // 000000826270: D6270002 03CA1B10
	v_fma_f32 v13, -v17, v19, 1.0                              // 000000826278: D613000D 23CA2711
	v_fmac_f32_e32 v22, v11, v22                               // 000000826280: 562C2D0B
	v_div_scale_f32 v11, s1, 1.0, v9, 1.0                      // 000000826284: D6FC010B 03CA12F2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000082628C: BF870214
	.long 0x7e143982                                           // 000000826290: 7E143982
	v_fmac_f32_e32 v19, v13, v19                               // 000000826294: 5626270D
	s_delay_alu instid0(VALU_DEP_3)                            // 000000826298: BF870003
	v_dual_fmac_f32 v20, v5, v20 :: v_dual_mul_f32 v21, v11, v22// 00000082629C: C8062905 14142D0B
	v_div_scale_f32 v5, s0, 1.0, v15, 1.0                      // 0000008262A4: D6FC0005 03CA1EF2
	.long 0x7e1a398e                                           // 0000008262AC: 7E1A398E
	.long 0x7f1a398a                                           // 0000008262B0: 7F1A398A
	s_mov_b32 vcc_lo, s0                                       // 0000008262B4: BEEA0000
	v_fma_f32 v7, -v6, v21, v11                                // 0000008262B8: D6130007 242E2B06
	v_mul_f32_e32 v18, v5, v20                                 // 0000008262C0: 10242905
	v_and_b32_e32 v16, 1, v10                                  // 0000008262C4: 36201481
	v_and_b32_e32 v13, 1, v13                                  // 0000008262C8: 361A1A81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000008262CC: BF870214
	v_fmac_f32_e32 v21, v7, v22                                // 0000008262D0: 562A2D07
	v_fma_f32 v3, -v12, v18, v5                                // 0000008262D4: D6130003 2416250C
	v_div_scale_f32 v7, s2, 1.0, v8, 1.0                       // 0000008262DC: D6FC0207 03CA10F2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000008262E4: BF870214
	v_add3_u32 v13, v14, v13, 0x7fff                           // 0000008262E8: D655000D 03FE1B0E 00007FFF
	v_fma_f32 v4, -v6, v21, v11                                // 0000008262F4: D6130004 242E2B06
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008262FC: BF870094
	v_fmac_f32_e32 v18, v3, v20                                // 000000826300: 56242903
	v_fma_f32 v3, -v12, v18, v5                                // 000000826304: D6130003 2416250C
	v_mul_f32_e32 v5, v7, v19                                  // 00000082630C: 100A2707
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000826310: BF870122
	v_div_fmas_f32 v6, v3, v20, v18                            // 000000826314: D6370006 044A2903
	s_mov_b32 vcc_lo, s1                                       // 00000082631C: BEEA0001
	v_fma_f32 v12, -v17, v5, v7                                // 000000826320: D613000C 241E0B11
	v_div_fmas_f32 v11, v4, v22, v21                           // 000000826328: D637000B 04562D04
	.long 0xd7006a03                                           // 000000826330: D7006A03
	v_cndmask_b32_e32 v0, v0, v4, vcc_lo                       // 000000826334: 02000900
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000826338: BF870191
	v_add_co_ci_u32_e64 v4, null, s5, v1, vcc_lo               // 00000082633C: D5207C04 01AA0205
	v_div_fixup_f32 v9, v11, v9, 1.0                           // 000000826344: D6270009 03CA130B
	v_mad_u64_u32 v[0:1], null, s12, 6, v[0:1]                 // 00000082634C: D6FE7C00 04010C0C
	v_div_fixup_f32 v11, v6, v15, 1.0                          // 000000826354: D627000B 03CA1F06
	s_mov_b32 vcc_lo, s2                                       // 00000082635C: BEEA0002
	.long 0x7f0c398a                                           // 000000826360: 7F0C398A
	.long 0x7e143989                                           // 000000826364: 7E143989
	v_fmac_f32_e32 v5, v12, v19                                // 000000826368: 560A270C
	v_add3_u32 v12, v2, v16, 0x7fff                            // 00000082636C: D655000C 03FE2102 00007FFF
	.long 0x7e0c398b                                           // 000000826378: 7E0C398B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000082637C: BF870113
	v_fma_f32 v2, -v17, v5, v7                                 // 000000826380: D6130002 241E0B11
	v_and_b32_e32 v7, 1, v6                                    // 000000826388: 360E0C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000082638C: BF870232
	v_div_fmas_f32 v5, v2, v19, v5                             // 000000826390: D6370005 04162702
	v_mad_u64_u32 v[1:2], null, s13, 6, v[1:2]                 // 000000826398: D6FE7C01 04050C0D
	v_and_b32_e32 v2, 1, v10                                   // 0000008263A0: 36041481
	v_add3_u32 v11, v11, v7, 0x7fff                            // 0000008263A4: D655000B 03FE0F0B 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000008263B0: BF870224
	v_div_fixup_f32 v10, v5, v8, 1.0                           // 0000008263B4: D627000A 03CA1105
	.long 0xd7006a05                                           // 0000008263BC: D7006A05
	v_cndmask_b32_e32 v0, v3, v4, vcc_lo                       // 0000008263C0: 02000903
	v_add3_u32 v2, v9, v2, 0x7fff                              // 0000008263C4: D6550002 03FE0509 00007FFF
	v_add_co_ci_u32_e64 v6, null, s5, v4, vcc_lo               // 0000008263D0: D5207C06 01AA0805
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008263D8: BF8700A4
	v_bfe_u32 v9, v10, 16, 1                                   // 0000008263DC: D6100009 0205210A
	.long 0xd7006a07                                           // 0000008263E4: D7006A07
	v_cndmask_b32_e32 v0, v0, v4, vcc_lo                       // 0000008263E8: 02000900
	v_add_co_ci_u32_e64 v8, null, s5, v1, vcc_lo               // 0000008263EC: D5207C08 01AA0205
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008263F4: BF8700A3
	v_add3_u32 v14, v10, v9, 0x7fff                            // 0000008263F8: D655000E 03FE130A 00007FFF
	.long 0xd7006a09                                           // 000000826404: D7006A09
	v_cndmask_b32_e32 v0, v5, v4, vcc_lo                       // 000000826408: 02000905
	v_add_co_ci_u32_e64 v10, null, s5, v6, vcc_lo              // 00000082640C: D5207C0A 01AA0C05
	s_clause 0x4                                               // 000000826414: BF850004
	global_store_d16_hi_b16 v[3:4], v13, off                   // 000000826418: DC960000 007C0D03
	global_store_d16_hi_b16 v[0:1], v12, off                   // 000000826420: DC960000 007C0C00
	global_store_d16_hi_b16 v[5:6], v11, off                   // 000000826428: DC960000 007C0B05
	global_store_d16_hi_b16 v[7:8], v2, off                    // 000000826430: DC960000 007C0207
	global_store_d16_hi_b16 v[9:10], v14, off                  // 000000826438: DC960000 007C0E09
	s_endpgm                                                   // 000000826440: BFB00000
		...

